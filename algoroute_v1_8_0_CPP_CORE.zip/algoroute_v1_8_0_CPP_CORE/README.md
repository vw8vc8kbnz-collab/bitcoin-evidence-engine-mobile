# AlgoRoute v1.8.0 CPP CORE

Deze build vervangt de Python greedy optimizer door een echte C++ optimizer-core.

## Nieuw in v1.8.0

- C++ optimizer-core toegevoegd in `services/optimizer-core/algoroute_core.cpp`.
- FastAPI endpoint `/api/planning/optimize` roept nu de C++ binary aan.
- Nieuw endpoint `/api/optimizer/status` toont of de C++ core beschikbaar is.
- Routeoptimalisatie + load optimalisatie tegelijk:
  - gewicht kg
  - volume m³
  - europallets
  - rolcontainers
- Nog géén 3D loading/bin packing; dat blijft bewust latere fase.
- CSV import normaliseert nu ook `volume_m3`.
- Wagenpark ondersteunt nu ook `max_volume_m3`.
- C++ core geeft ETA, load utilization, waarschuwingen en unplanned orders terug.

## Belangrijke scope

Python/FastAPI is alleen de API- en normalisatielaag. De optimalisatiebeslissing gebeurt in C++.
