# AlgoRoute v1.8.0 CPP CORE — Termius update

```bash
cd /home/ubuntu
rm -rf algoroute_latest
mkdir -p algoroute_latest
cd algoroute_latest

# Vervang deze URL door de GitHub raw URL van deze ZIP zodra je hem uploadt.
wget -O algoroute_v1_8_0_CPP_CORE.zip "GITHUB_RAW_ZIP_URL_HIER"
unzip -o algoroute_v1_8_0_CPP_CORE.zip
cd algoroute_v1_8_0_CPP_CORE

# Rebuild is verplicht, want de C++ optimizer-core wordt tijdens Docker build gecompileerd.
docker compose down
docker compose build --no-cache algoroute-api
docker compose up -d

# Checks
docker compose ps
docker logs --tail=80 algoroute-api
curl -s http://127.0.0.1:8787/api/health | python3 -m json.tool
curl -s http://127.0.0.1:8787/api/optimizer/status | python3 -m json.tool

# Open daarna:
# http://51.195.102.180:8787
```

Let op: `/api/optimizer/status` moet `core_mode: c++` en `available: true` tonen.
