const CACHE_NAME = 'bee-mobile-10_16_69_tm_fast_learning_completion';
const VERSION = '10_16_69_tm_fast_learning_completion';
const STATIC_ASSETS = [
  '/static/css/mobile_app.css?v=10_16_69_tm_fast_learning_completion',
  '/static/js/mobile_app.js?v=10_16_69_tm_fast_learning_completion',
  '/static/icons/icon-180.png',
  '/static/icons/icon-192.png',
  '/static/icons/icon-512.png'
];

async function purgeOldCaches(){
  try{
    const keys = await caches.keys();
    await Promise.all(keys.filter(k => k.startsWith('bee-mobile-') && k !== CACHE_NAME).map(k => caches.delete(k)));
  }catch(e){}
}
async function cacheStatic(){
  const cache = await caches.open(CACHE_NAME);
  await Promise.all(STATIC_ASSETS.map(async (url)=>{
    try{
      const res = await fetch(url, {cache:'reload'});
      if(res && res.ok) await cache.put(url, res.clone());
    }catch(e){}
  }));
}
self.addEventListener('install', event => {
  self.skipWaiting();
  event.waitUntil((async()=>{ await purgeOldCaches(); await cacheStatic(); })());
});
self.addEventListener('activate', event => {
  event.waitUntil((async()=>{
    await purgeOldCaches();
    if(self.registration.navigationPreload){ try{ await self.registration.navigationPreload.enable(); }catch(e){} }
    await self.clients.claim();
    const clients = await self.clients.matchAll({type:'window', includeUncontrolled:true});
    for(const c of clients){
      try{ c.postMessage({type:'BEE_SW_UPDATED', version: VERSION, force:true}); }catch(e){}
    }
  })());
});
function timeout(ms){ return new Promise((_,rej)=>setTimeout(()=>rej(new Error('sw-timeout')),ms)); }
async function fetchFreshMobile(){
  return await Promise.race([
    fetch('/mobile?app_v='+VERSION+'&swfresh='+Date.now(), {cache:'reload', credentials:'same-origin'}),
    timeout(3500)
  ]);
}
self.addEventListener('fetch', event => {
  const req = event.request;
  const url = new URL(req.url);
  if(req.method !== 'GET') return;
  if(url.pathname.startsWith('/api/')) return;
  if(url.pathname === '/service-worker.js') return;

  // CRITICAL v10.16.65: never serve an old cached /mobile navigation again.
  // Navigation is network-first and old app shells are not cached under /mobile.
  if(req.mode === 'navigate' || url.pathname === '/mobile' || url.pathname === '/'){
    event.respondWith((async()=>{
      try{
        const fresh = await fetchFreshMobile();
        if(fresh && fresh.ok) return fresh;
      }catch(e){}
      return new Response('<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#061327"><style>html,body{margin:0;background:#061327;color:#eef5ff;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;height:100%;display:grid;place-items:center}.c{text-align:center;padding:26px}.l{width:58px;height:58px;border-radius:18px;background:#ffbe3d;color:#061327;display:grid;place-items:center;font-weight:950;font-size:34px;margin:0 auto 14px}.b{height:7px;background:rgba(255,255,255,.10);border-radius:99px;overflow:hidden;margin-top:18px}.b i{display:block;height:100%;width:50%;background:linear-gradient(90deg,#348bff,#1fd5ff,#48e6ad);border-radius:99px;animation:a 1s infinite alternate}@keyframes a{to{transform:translateX(100%)}}</style></head><body><div class="c"><div class="l">₿</div><h2>Bitcoin Evidence</h2><p>Nieuwe app-versie wordt geladen…</p><div class="b"><i></i></div></div><script>try{caches.keys().then(keys=>Promise.all(keys.filter(k=>k.indexOf("bee-mobile-")===0).map(k=>caches.delete(k)))).finally(()=>setTimeout(()=>location.replace("/mobile?app_v='+VERSION+'&r="+Date.now()),500));}catch(e){setTimeout(()=>location.replace("/mobile?app_v='+VERSION+'&r="+Date.now()),700)}</script></body></html>', {headers:{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store, no-cache, must-revalidate, max-age=0'}});
    })());
    return;
  }

  if(url.pathname.startsWith('/static/') || url.pathname.endsWith('.webmanifest')){
    event.respondWith((async()=>{
      const cache = await caches.open(CACHE_NAME);
      const cached = await cache.match(req);
      if(cached) return cached;
      try{
        const res = await fetch(req, {cache:'reload'});
        if(res && res.ok) cache.put(req, res.clone()).catch(()=>{});
        return res;
      }catch(e){ return new Response('', {status:504}); }
    })());
  }
});
