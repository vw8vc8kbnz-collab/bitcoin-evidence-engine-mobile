#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="/opt/adzaagt/metod-pax"
ENV_DIR="/etc/adzaagt/metod-pax"
ENV_FILE="$ENV_DIR/metod-pax.env"
SERVICE_FILE="/etc/systemd/system/metod-pax.service"
NGINX_SITE="/etc/nginx/sites-available/metod-pax-8790"

if [[ "${EUID}" -ne 0 ]]; then
  echo "Voer dit script met sudo uit." >&2
  exit 1
fi

mkdir -p "$ENV_DIR" "$APP_DIR/app/backups" "$APP_DIR/app/decor_media" "$APP_DIR/app/system/catalog_imports/history" "$APP_DIR/app/system/catalog_legacy_archive"
touch "$ENV_FILE" "$APP_DIR/app/backups/.keep" "$APP_DIR/app/decor_media/.keep"

# Acceptatie blijft bewust HTTP/development zoals de voorgaande releases. Productie-
# hardening/TLS volgt pas na functionele acceptatie.
sed -i \
  '/^METOD_PORT=/d;/^PRODUCTION_HARDENING=/d;/^ADMIN_HASH_ONLY=/d;/^APP_ENV=/d;/^ADMIN_CREDENTIALS_FILE=/d;/^ADMIN_STAGING_OPEN=/d;/^PUBLIC_JOB_MAX_CONCURRENT=/d;/^PUBLIC_JOB_MAX_CONCURRENT_PER_IP=/d;/^ALLOWED_ADMIN_ORIGINS=/d;/^ALLOWED_ORIGINS=/d;/^PUBLIC_JSON_MAX_BYTES=/d;/^PUBLIC_JOB_TOTAL_QTY_LIMIT=/d;/^PUBLIC_JOB_MAX_AREA_LB=/d;/^JOB_OUTPUT_MAX_BYTES=/d;/^CATALOG_IMAGE_WORKERS=/d;/^PUBLIC_DXF_BLOB_MAX_BYTES=/d' \
  "$ENV_FILE"
cat >> "$ENV_FILE" <<'ENVEOF'
METOD_PORT=8792
PRODUCTION_HARDENING=0
ADMIN_HASH_ONLY=0
APP_ENV=development
ADMIN_CREDENTIALS_FILE=/etc/adzaagt/metod-pax/admin_credentials.live.json
ADMIN_STAGING_OPEN=0
PUBLIC_JOB_MAX_CONCURRENT=1
PUBLIC_JOB_MAX_CONCURRENT_PER_IP=1
PUBLIC_JSON_MAX_BYTES=134217728
PUBLIC_JOB_TOTAL_QTY_LIMIT=250
PUBLIC_JOB_MAX_AREA_LB=250
JOB_OUTPUT_MAX_BYTES=536870912
CATALOG_IMAGE_WORKERS=4
PUBLIC_DXF_BLOB_MAX_BYTES=2097152
ALLOWED_ADMIN_ORIGINS=http://51.195.102.180:8790
ALLOWED_ORIGINS=http://51.195.102.180:8790
ENVEOF

cat > "$SERVICE_FILE" <<'SVCEOF'
[Unit]
Description=METOD PAX Tool
After=network.target

[Service]
Type=simple
WorkingDirectory=/opt/adzaagt/metod-pax/app
EnvironmentFile=/etc/adzaagt/metod-pax/metod-pax.env
ExecStart=/usr/bin/python3 /opt/adzaagt/metod-pax/app/server_py.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
SVCEOF
rm -f /etc/systemd/system/metod-pax.service.d/10-http-test.conf

cat > "$NGINX_SITE" <<'NGINXEOF'
server {
    listen 8790;
    listen [::]:8790;
    server_name 51.195.102.180 _;
    client_max_body_size 160m;

    location / {
        proxy_pass http://127.0.0.1:8792;
        proxy_http_version 1.1;
        proxy_set_header Host $http_host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header X-Forwarded-Host $http_host;
        proxy_set_header X-Forwarded-Port $server_port;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_connect_timeout 30s;
        proxy_send_timeout 1800s;
        proxy_read_timeout 1800s;
        proxy_buffering off;
    }
}
NGINXEOF
ln -sfn "$NGINX_SITE" /etc/nginx/sites-enabled/metod-pax-8790

# Keep the CSV-only catalog invariant from FIX652.
python3 "$APP_DIR/tools/fix652_catalog_only_migrate.py" \
  --library "$APP_DIR/app/material_library.json" \
  --archive-dir "$APP_DIR/app/system/catalog_legacy_archive" \
  --registry "$APP_DIR/app/system/catalog_public_ids.json"

# Prebuild lightweight image variants from the already-local CSV image cache. This
# performs no network requests. Missing raw caches remain a safe fallback and will be
# prepared during the next Admin CSV review before publication.
python3 "$APP_DIR/tools/fix654_prepare_catalog_media.py" --app-dir "$APP_DIR/app" || true

python3 -m py_compile \
  "$APP_DIR/app/server_py.py" \
  "$APP_DIR/app/catalog_importer.py" \
  "$APP_DIR/app/pricing_helpers.py" \
  "$APP_DIR/tools/migrate_decor_library.py" \
  "$APP_DIR/tools/fix652_catalog_only_migrate.py" \
  "$APP_DIR/tools/fix654_prepare_catalog_media.py" \
  "$APP_DIR/tools/final_preflight.py"

# FIX654 output contracts retained + FIX656 overview/performance contracts.
grep -Fq "FIX654_OUTPUT_PIPELINE_AUDIT" "$APP_DIR/app/server_py.py"
grep -Fq "def _finalize_subjob_outputs" "$APP_DIR/app/server_py.py"
grep -Fq "_generate_stickertool_json(job_root)" "$APP_DIR/app/server_py.py"
grep -Fq "_build_admin_dxf_exports(job_root)" "$APP_DIR/app/server_py.py"
grep -Fq "output/finalization.json" "$APP_DIR/app/server_py.py" || grep -Fq "finalization.json" "$APP_DIR/app/server_py.py"
grep -Fq "st['job'] =" "$APP_DIR/app/server_py.py"
# FIX656: one authoritative overview controller + faster pre-job DXF transport.
grep -Fq "FIX656_LIBRARY_AND_OPTIMIZER_SPEED" "$APP_DIR/app/server_py.py"
grep -Fq "\"toolA_overview_fix655.js\"" "$APP_DIR/app/server_py.py"
grep -Fq "def _expand_dxf_payload" "$APP_DIR/app/server_py.py"
grep -Fq "relevant_part_ids" "$APP_DIR/app/server_py.py"
grep -Fq "masterDxfHardlinks" "$APP_DIR/app/server_py.py"
grep -Fq "_link_or_copy_file" "$APP_DIR/app/server_py.py"
grep -Fq "FIX656_LIBRARY_INSTANT_BOOTSTRAP" "$APP_DIR/app/decor_library.js"
grep -Fq "INITIAL_VISIBLE = 16" "$APP_DIR/app/decor_library.js"
grep -Fq "decor_library.js?v=656" "$APP_DIR/app/toolA.html"
grep -Fq "toolA_overview_fix655.js?v=655" "$APP_DIR/app/toolA.html"
grep -Fq "FIX655_DXF_REF_V1" "$APP_DIR/app/toolA.html"
grep -Fq "compactDxfPayload" "$APP_DIR/app/toolA.html"
grep -Fq "_DXF_TRANSFORMED_TEXT_CACHE" "$APP_DIR/app/toolA.html"
grep -Fq "PUBLIC_MATERIAL_CATALOG_CACHE_PATH" "$APP_DIR/app/server_py.py"
grep -Fq "Content-Encoding', 'gzip" "$APP_DIR/app/server_py.py"
grep -Fq "fixedGridLowerBound" "$APP_DIR/app/dxf_nesting_optimizer.py"
grep -Fq "earlyOptimalLowerBound" "$APP_DIR/app/dxf_nesting_optimizer.py"
grep -Fq "dxfGeometryReuses" "$APP_DIR/app/dxf_nesting_optimizer.py"
grep -Fq "const __payloadJson = JSON.stringify(payload)" "$APP_DIR/app/toolA.html"
grep -Fq "body: __payloadJson" "$APP_DIR/app/toolA.html"
grep -Fq "FIX655_OVERVIEW_SINGLE_CONTROLLER" "$APP_DIR/app/toolA_overview_fix655.js"
grep -Fq "window.openOverviewOverlay=show" "$APP_DIR/app/toolA_overview_fix655.js"
grep -Fq "renderOverviewSafe" "$APP_DIR/app/toolA.html"
grep -Fq "MAX_STATUS_OUTAGE_MS" "$APP_DIR/app/toolA.html"
grep -Fq "Afbeeldingen voorbereiden vóór publicatie" "$APP_DIR/app/server_py.py"
grep -Fq "_promote_catalog_stage_images" "$APP_DIR/app/server_py.py"
grep -Fq "thumb.webp" "$APP_DIR/app/catalog_importer.py"
grep -Fq "ALLOWED_THICKNESSES_MM = (18.0, 19.0, 20.0)" "$APP_DIR/app/catalog_importer.py"
grep -Fq "CSV_CATALOG_ONLY" "$APP_DIR/tools/fix652_catalog_only_migrate.py"
! grep -Fq 'id="priceSheetFactor"' "$APP_DIR/app/server_py.py"

grep -Fq "FIX644_STEP2_KEYBOARD_STABILITY_ALL_FIELDS" "$APP_DIR/app/toolA.html"
grep -Fq "FIX645_STEP2_KEYBOARD_FOOTER_HIDE" "$APP_DIR/app/toolA.html"
grep -Fq "FIX648_VERTICAL_GRAIN_RESTORE" "$APP_DIR/app/toolA.html"
grep -Fq "FIX650_PREVIEW_BUTTON_RELIABLE" "$APP_DIR/app/toolA.html"

# Preserve Admin prices exactly, including intentional zero values. Only the obsolete
# general material factor is removed.
python3 - "$APP_DIR/app/config/pricing_active.json" <<'PY'
import json,os,sys
p=sys.argv[1]
try: obj=json.load(open(p,encoding='utf-8'))
except Exception: obj={}
if not isinstance(obj,dict): obj={}
sp=obj.get('sellPricing') if isinstance(obj.get('sellPricing'),dict) else {}
sp.pop('sheetPriceFactor',None)
for key,default in (('edgeBandPricePerM',4.5),('cncCostPerSheet',0.0),('drawingCostFixed',0.0),('transportCostFixed',0.0)):
    try: sp[key]=float(sp[key]) if key in sp and sp[key] is not None else float(default)
    except Exception: sp[key]=float(default)
obj['sellPricing']=sp
obj['pricingModel']='catalog_sell_price_v1'
tmp=p+'.fix656.tmp'
with open(tmp,'w',encoding='utf-8') as f:
    json.dump(obj,f,ensure_ascii=False,indent=2); f.flush(); os.fsync(f.fileno())
os.replace(tmp,p)
print('Pricing genormaliseerd: CSV-verkoopprijs + bestaande Admin-kosten; 0 blijft 0.')
PY

python3 - "$APP_DIR/app/config/pricing_active.json" <<'PY'
import json,sys
obj=json.load(open(sys.argv[1],encoding='utf-8')); sp=obj.get('sellPricing') or {}
assert 'sheetPriceFactor' not in sp
for key in ('edgeBandPricePerM','cncCostPerSheet','drawingCostFixed','transportCostFixed'):
    assert key in sp and isinstance(float(sp[key]),float)
assert obj.get('pricingModel')=='catalog_sell_price_v1'
print('Actieve pricingconfig OK.')
PY

# Safe server-side smoke: compact DXF references must expand deterministically and reject path traversal.
python3 - "$APP_DIR/app" <<'PY'
import importlib.util,sys
from pathlib import Path
root=Path(sys.argv[1]); sys.path.insert(0,str(root))
spec=importlib.util.spec_from_file_location('fix656_server_smoke', root/'server_py.py')
mod=importlib.util.module_from_spec(spec); sys.modules['fix656_server_smoke']=mod; spec.loader.exec_module(mod)
out=mod._expand_dxf_payload({'dxfBlobs':{'g0001':'0\nEOF\n'},'dxfPartRefs':{'p001':'g0001'}})
assert out=={'p001':'0\nEOF\n'}
try:
    mod._expand_dxf_payload({'dxfBlobs':{'g0001':'0\nEOF\n'},'dxfPartRefs':{'../bad':'g0001'}})
except ValueError:
    pass
else:
    raise SystemExit('FIX656 DXF PartId traversal guard faalde')
print('FIX656 compact DXF transport smoke OK.')
PY

systemctl daemon-reload
systemctl enable metod-pax.service >/dev/null
systemctl restart metod-pax.service
nginx -t
systemctl reload nginx
sleep 3

HTML_CHECK="$(mktemp /tmp/fix656_html_XXXXXX)"
ADMIN_CHECK="$(mktemp /tmp/fix656_admin_XXXXXX)"
PUBLIC_CHECK="$(mktemp /tmp/fix656_public_XXXXXX)"
trap 'rm -f "$HTML_CHECK" "$ADMIN_CHECK" "$PUBLIC_CHECK"' EXIT
curl -fsS "http://127.0.0.1:8792/toolA.html?v=655" -o "$HTML_CHECK"
curl -fsS "http://127.0.0.1:8792/admin/?v=655" -o "$ADMIN_CHECK"
curl -fsS --compressed "http://127.0.0.1:8792/api/materials/library" -o "$PUBLIC_CHECK"
grep -Fq "FIX654_OUTPUT_PIPELINE_AUDIT" "$HTML_CHECK"
grep -Fq "decor_library.js?v=656" "$HTML_CHECK"
grep -Fq "toolA_overview_fix655.js?v=655" "$HTML_CHECK"
grep -Fq "FIX656_LIBRARY_AND_OPTIMIZER_SPEED" "$HTML_CHECK"
grep -Fq "renderOverviewSafe" "$HTML_CHECK"
grep -Eq "Admin|login|METOD" "$ADMIN_CHECK"

python3 - "$PUBLIC_CHECK" "$APP_DIR/app/material_library.json" <<'PY'
import json,re,sys
pub=json.load(open(sys.argv[1],encoding='utf-8'))
internal=json.load(open(sys.argv[2],encoding='utf-8'))
assert pub.get('ok') is True
records=pub.get('records') or []; active=internal.get('records') or []
assert internal.get('source')=='CSV_CATALOG_ONLY'
assert len(records)==len(active),(len(records),len(active))
allowed={"publicMaterialId","publicName","brand","decorType","visualFamily","visualTags","colorGroup","searchTags","thicknessMm","sheetSizeMm","hasGrain","grainDefaultOn","active","published","isPopular","isNew","imageAvailable","imageThumbUrl","imagePreviewUrl"}
for r in records:
    assert set(r).issubset(allowed), set(r)-allowed
    assert re.fullmatch(r'decor_[a-f0-9]{20,40}',str(r.get('publicMaterialId') or ''))
    assert float(r.get('thicknessMm') or 0) in (18.0,19.0,20.0)
forbidden={"articleNumber","articleNo","materialCode","purchasePrice","purchasePricePerSheet","supplier","supplierName","leverancier","imageSourceUrl","imageSourceUrls","sellPriceInclVatPerSheet","sellPriceExVatPerSheet"}
assert not any(forbidden.intersection(r) for r in records)
articles={str(r.get('articleNo') or r.get('articleNumber') or r.get('materialCode') or '') for r in active if isinstance(r,dict)}; articles.discard('')
def walk(v):
    if isinstance(v,dict):
        for x in v.values(): yield from walk(x)
    elif isinstance(v,list):
        for x in v: yield from walk(x)
    elif isinstance(v,str): yield v
for value in walk(pub):
    assert value not in articles, f'intern artikelnummer gelekt: {value}'
print(f'Publieke library privacy OK: {len(records)} records.')
PY

if python3 - <<'PY' >/dev/null 2>&1
from PIL import Image
PY
then
  echo "Pillow beschikbaar: Tool A gebruikt voorbereide WebP-thumbnails waar broncache aanwezig is."
else
  echo "LET OP: Pillow niet beschikbaar; lokale catalog.img blijft functionele cache. Volgende optimalisatie kan later nog met WebP-conversie worden uitgebreid."
fi

echo "FIX656 ACTIEF."
echo "Tool A: http://51.195.102.180:8790/toolA.html?v=655"
echo "Admin:  http://51.195.102.180:8790/admin/?v=655"
