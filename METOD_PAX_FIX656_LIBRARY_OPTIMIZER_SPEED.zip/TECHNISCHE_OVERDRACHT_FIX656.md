# Technische overdracht — FIX656 Library + Optimizer Speed

## Basis
FIX656 bouwt rechtstreeks voort op FIX655. Geen architectuur-reset. De enige functionele scope is latency van de publieke Decor Library en de bestaande productie-optimalisatieketen.

## Library datapad
`toolA.html` bevat direct na viewport `fix656EarlyCatalogBootstrap`.
- leest alleen de eerder verkregen PUBLIC-only API-records uit `localStorage` key `toolA_public_catalog_v656`;
- normaliseert publicMaterialId naar de bestaande client compatibility aliases;
- zet `window.MATERIAL_CATALOG` vóór de late runtime;
- start onmiddellijk `/api/materials/library` met `cache:no-cache`;
- achtergrondresponse vervangt cache en dispatcht `adzaagt-material-catalog-updated`.

De latere `refreshMaterialCatalogLive()` hergebruikt de early bootstrap Promise bij de initiële sync en start niet opnieuw dezelfde request.

Server:
- `PUBLIC_MATERIAL_CATALOG_CACHE_PATH = app/system/public_material_catalog_v1.json`
- sidecar meta bevat source `material_library.json` mtimeNs en ETag.
- `_public_materials_response_bytes()` gebruikt memory -> disk -> rebuild.
- material library mtime is cache truth; `_save_material_library_bundle()` invalideert memory.
- Admin catalog publish force-rebuildt de public cache.
- public endpoint ondersteunt ETag/304 en gzip.
- cachebestand bevat uitsluitend de bestaande minimale publieke API-contractvelden; nooit intern artikelnummer of prijzen.

## Optimizer datapad
FIX655 `dxfBlobs + dxfPartRefs` blijft de wire-contractlaag.

FIX656 houdt deduplicatie daarna vast:
1. `_create_job_from_payload` SHA-256 dedupe op DXF-body.
2. Eerste body wordt geschreven; gelijke PartId-bestanden worden `_link_or_copy_file` hardlinks.
3. Subjobs linken alleen hun relevante PartIds.
4. `dxf_nesting_optimizer.py` cachet `PartData` op `(st_dev, st_ino, st_size)` en valideert bbox nog per logische panelrow.
5. Admin DXF-export gebruikt hardlink-or-copy waar mogelijk.

## Lower-bound optimalisatie
`pack_maxrects_optimal()` behoudt de primary objective: minimaal aantal platen.
- bestaande area/clique lower bounds blijven;
- nieuwe `fixedGridLowerBound` geldt alleen wanneer alle packing-items singles zijn, exact dezelfde w/h hebben en niet roteerbaar zijn;
- capaciteit wordt deterministisch uit bruikbare plaatmaat, itemmaat en gap bepaald;
- lower bound wordt nooit gebruikt als heuristische timeout;
- als een geldige placement exact `lb` gebruikt, is minder platen mathematisch onmogelijk en returnt de functie direct.

Er is dus bewust GEEN algemene 'fast mode' die mogelijk een extra plaat accepteert.

## Live data/deploy
Deployment moet blijven uitsluiten/behouden:
- app/jobs
- app/requests
- app/queue
- app/archive
- app/backups
- app/drafts
- app/system
- app/decor_media
- app/material_library.json
- pricing_active + pricing_versions/audit
- embedded_dxfs + manifest

`app/system/public_material_catalog_v1*` is afgeleid public-only cachedata en mag worden behouden. Mtime mismatch maakt een oude cache automatisch ongeldig.

## Privacy
Tool A/API blijft uitsluitend opaque `decor_<hex>` IDs gebruiken. Catalogus browsercache is veilig omdat exact de public API-records worden opgeslagen. Interne artikelcodes zijn niet indexeerbaar/zoekbaar in de clientcache.

## Acceptatie na deployment
1. Eerste mobiele Step 1-load na deploy meten; tegels horen veel eerder zichtbaar te worden en repeat load hoort cached onmiddellijk te renderen.
2. Dezelfde echte order als FIX655 opnieuw berekenen.
3. Noteer tijd tot job submit, tijd optimizer, totaal tot DONE.
4. Controleer Admin DXF_Zaagplaten, DXF_Onderdelen en StickerTool.
5. Controleer plaat-aantal tegen FIX655 voor dezelfde order.
