# METOD/PAX FIX657R3 — HTTP :8790 STABLE BRIDGE

**Build marker:** `FIX657R3_HTTP8790_STABLE_VAT_TRUTH`  
**Golden basis:** exact FIX656 functional baseline + FIX657 VAT/idempotency/security corrections.  
**Live URL contract:** **UNCHANGED** — `http://51.195.102.180:8790/`

## FIX657R3 installer privilege correction

FIX657R2 correctly stopped before touching the live application because its staged production preflight was executed as the unprivileged SSH user while the existing Admin credentials file is intentionally root-only (`0600`). FIX657R3 does **not** weaken those permissions. The installer now validates root readability and runs only the production preflight through `sudo env`, after all non-privileged regressions have passed and still before any live backup/switch. Application/business logic is otherwise the same hardened same-URL release contract.



FIX657R3 exists because the first FIX657 production installer tried to combine the
functional/security update with a transport migration to HTTPS. That was intentionally
fail-closed, but the transport migration was too large a change for this release.

FIX657R3 therefore keeps the existing network architecture exactly:

`browser -> http://51.195.102.180:8790 -> nginx -> 127.0.0.1:8792 -> server_py.py`

The Python backend stays loopback-only. Nginx remains the only public listener for Tool A.

## What is fixed

### 1. Website CSV sheet price is already INCLUDING VAT
The CSV column `Prijs per plaat inclusief BTW` is authoritative. The exact CSV amount is
used as the gross material amount. It is not multiplied by 1.21 again and it is not
presented as a commercial ex-VAT sheet price.

Other Admin costs remain ex-VAT:
- edge banding
- CNC
- drawing
- transport

21% VAT is added only to those other Admin costs.

Verified example:
- sheet: EUR 69.57 incl. VAT
- other costs: EUR 69.00 ex. VAT
- VAT on other costs: EUR 14.49
- final total: EUR 153.06 incl. VAT

The supplied current website CSV was regression-tested directly but is NOT shipped in
this release. Result: 606 rows read, 597 eligible 18/19/20 mm records, 9 excluded by
thickness, 0 blocking import errors.

### 2. Submit no longer optimizes the same order again
`/api/jobs` is the only optimization entry point. Final submit links the already finalized
parent job, requires its bearer token and is idempotent. Double-clicking submit does not
launch another optimizer job.

### 3. Security/stability hardening retained without changing the URL
- `APP_ENV=production`
- `PRODUCTION_HARDENING=1`
- `ADMIN_HASH_ONLY=1`
- external PBKDF2-SHA256 Admin credentials
- public/admin write origin checks fail closed
- exact allowed origin: `http://51.195.102.180:8790`
- public SSE only exposes `dxf_changed` + `dxfVersion`
- public job token only via `Authorization: Bearer`
- job token stored in `sessionStorage`, not durable `localStorage`
- request limits reduced
- backend stays on `127.0.0.1:8792`

The one compatibility exception is explicit and narrow: `LEGACY_HTTP_COMPAT=1` accepts
only the exact existing reverse-proxy origin `http://51.195.102.180:8790`. It is not a
generic HTTP bypass.

## Important security note

HTTP itself is not encrypted. FIX657R3 keeps it only to avoid changing the live URL in the
same release as pricing/job/security changes. The Admin cookie therefore cannot carry the
`Secure` attribute on this HTTP path. A later HTTPS migration should be a separate,
controlled release. All application-layer hardening above remains active now.

## State that MUST be preserved

The installer preserves the current live state, including:
- `app/jobs/`
- `app/requests/`
- `app/queue/`
- `app/archive/`
- `app/backups/`
- `app/drafts/`
- `app/system/`
- `app/decor_media/`
- `app/material_library.json`
- `app/config/pricing_active.json`
- `app/config/pricing_versions/`
- `app/config/pricing_audit.jsonl`
- `app/embedded_dxfs/`
- `app/embedded_dxfs_manifest.json`

The release ZIP intentionally contains an empty `CSV_CATALOG_ONLY` material seed. The
existing published CSV catalog wins during an update.

## About the failed FIX657R1 HTTPS attempt

FIX657R1 stopped before the live application switch. FIX657R3 removes only the
FIX657R1-specific Nginx ACME/HTTPS site and `metod-pax-certbot-renew` systemd units if they
were left behind. It does NOT delete certificate files, the Certbot venv, or generic VPS
firewall rules.

Use `INSTALL_FIX657R3_FROM_STAGE.sh` through the supplied Termius one-shot. Do not run the
old FIX657/FIX657R1 installers again.
