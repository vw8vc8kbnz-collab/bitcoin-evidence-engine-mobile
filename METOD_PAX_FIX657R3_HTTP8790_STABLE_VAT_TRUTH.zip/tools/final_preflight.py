#!/usr/bin/env python3
"""METOD/PAX FIX657R3 production preflight.

Fails closed on runtime security, mixed-VAT price contract, queue idempotency, and
release markers. This script is safe to run repeatedly; it does not mutate state.
"""
from __future__ import annotations

import json
import os
import re
import sys
from pathlib import Path
from urllib.parse import urlparse

APP_DIR = Path(os.environ.get('APP_DIR', '/opt/adzaagt/metod-pax'))
ENV_FILE = Path(os.environ.get('METOD_ENV_FILE', '/etc/adzaagt/metod-pax/metod-pax.env'))
DEFAULT_CREDS = Path('/etc/adzaagt/metod-pax/admin_credentials.live.json')
MAX_PUBLIC_JSON = 16 * 1024 * 1024
MAX_SUBMIT_JSON = 8 * 1024 * 1024
MAX_DXF_BLOB = 2 * 1024 * 1024
FIX657R3_LEGACY_ORIGIN = 'http://51.195.102.180:8790'


def read_env(path: Path) -> dict[str, str]:
    out: dict[str, str] = {}
    if path.exists():
        for line in path.read_text(encoding='utf-8', errors='ignore').splitlines():
            line = line.strip()
            if not line or line.startswith('#') or '=' not in line:
                continue
            key, value = line.split('=', 1)
            out[key.strip()] = value.strip().strip('"').strip("'")
    return out


def truthy(value: str | None) -> bool:
    return str(value or '').strip().lower() in {'1', 'true', 'yes', 'on', 'prod', 'production'}


def add_ok(message: str) -> None:
    print('OK:  ', message)


def add_fail(message: str, errors: list[str]) -> None:
    errors.append(message)
    print('FAIL:', message)


def check_origin_list(name: str, raw: str, errors: list[str], *, legacy_http_origin: str = '') -> None:
    values = [x.strip() for x in str(raw or '').split(',') if x.strip()]
    if not values:
        add_fail(f'{name} missing', errors)
        return
    for value in values:
        try:
            u = urlparse(value)
            structural_ok = bool(
                u.hostname and not u.username and not u.password and '*' not in value
                and not u.query and not u.fragment and u.path in ('', '/')
            )
            https_ok = structural_ok and u.scheme.lower() == 'https'
            legacy_ok = structural_ok and bool(legacy_http_origin) and value == legacy_http_origin
            assert https_ok or legacy_ok
        except Exception:
            add_fail(f'{name} contains unsafe origin: {value}', errors)
            return
    if legacy_http_origin:
        if values != [legacy_http_origin]:
            add_fail(f'{name} must equal LEGACY_HTTP_ORIGIN in legacy HTTP mode', errors)
            return
        add_ok(f'{name} exact legacy HTTP allowlist valid')
    else:
        add_ok(f'{name} HTTPS allowlist valid ({len(values)})')


def int_env(env: dict[str, str], name: str, default: int) -> int:
    try:
        return int(env.get(name, str(default)) or default)
    except Exception:
        return -1


def main() -> int:
    errors: list[str] = []
    env = read_env(ENV_FILE)
    if not ENV_FILE.exists():
        add_fail(f'env file missing: {ENV_FILE}', errors)

    if str(env.get('APP_ENV', '')).lower() in {'prod', 'production'}:
        add_ok('APP_ENV=production')
    else:
        add_fail('APP_ENV must be production', errors)
    if truthy(env.get('PRODUCTION_HARDENING')):
        add_ok('PRODUCTION_HARDENING=1')
    else:
        add_fail('PRODUCTION_HARDENING must be 1', errors)
    if truthy(env.get('ADMIN_HASH_ONLY')):
        add_ok('ADMIN_HASH_ONLY=1')
    else:
        add_fail('ADMIN_HASH_ONLY must be 1', errors)
    if not truthy(env.get('ADMIN_STAGING_OPEN')):
        add_ok('ADMIN_STAGING_OPEN disabled')
    else:
        add_fail('ADMIN_STAGING_OPEN must be 0', errors)

    legacy_http_origin = ''
    if truthy(env.get('LEGACY_HTTP_COMPAT')):
        raw_legacy = str(env.get('LEGACY_HTTP_ORIGIN') or '').strip()
        try:
            u = urlparse(raw_legacy)
            assert raw_legacy == FIX657R3_LEGACY_ORIGIN
            assert u.scheme.lower() == 'http' and u.hostname and u.port == 8790
            assert not u.username and not u.password and '*' not in raw_legacy
            assert not u.query and not u.fragment and u.path in ('', '/')
            legacy_http_origin = raw_legacy
            add_ok(f'LEGACY_HTTP_COMPAT explicitly pinned to {legacy_http_origin}')
        except Exception:
            add_fail(f'LEGACY_HTTP_ORIGIN must be exactly {FIX657R3_LEGACY_ORIGIN} when LEGACY_HTTP_COMPAT=1', errors)
    else:
        add_ok('LEGACY_HTTP_COMPAT disabled; HTTPS-only origin policy applies')

    check_origin_list('ALLOWED_ORIGINS', env.get('ALLOWED_ORIGINS', ''), errors, legacy_http_origin=legacy_http_origin)
    check_origin_list('ALLOWED_ADMIN_ORIGINS', env.get('ALLOWED_ADMIN_ORIGINS', ''), errors, legacy_http_origin=legacy_http_origin)

    limits = [
        ('PUBLIC_JSON_MAX_BYTES', MAX_PUBLIC_JSON),
        ('SUBMIT_MAX_BYTES', MAX_SUBMIT_JSON),
        ('PUBLIC_DXF_BLOB_MAX_BYTES', MAX_DXF_BLOB),
    ]
    for name, maximum in limits:
        value = int_env(env, name, maximum)
        if 0 < value <= maximum:
            add_ok(f'{name}={value}')
        else:
            add_fail(f'{name} must be 1..{maximum}, got {value}', errors)
    for name in ('PUBLIC_JOB_MAX_CONCURRENT', 'PUBLIC_JOB_MAX_CONCURRENT_PER_IP'):
        if int_env(env, name, 1) == 1:
            add_ok(f'{name}=1')
        else:
            add_fail(f'{name} must be 1 on current production baseline', errors)

    creds = Path(env.get('ADMIN_CREDENTIALS_FILE') or str(DEFAULT_CREDS))
    try:
        app_resolved = APP_DIR.resolve()
        c_resolved = creds.resolve()
        if c_resolved == app_resolved or app_resolved in c_resolved.parents:
            add_fail('admin credentials must live outside APP_DIR', errors)
        else:
            add_ok('admin credentials outside APP_DIR')
    except Exception as exc:
        add_fail(f'cannot resolve admin credentials path: {exc}', errors)
    if creds.exists():
        try:
            data = json.loads(creds.read_text(encoding='utf-8'))
            if str(data.get('password_hash', '')).startswith('pbkdf2_sha256$') and not str(data.get('password') or '').strip():
                add_ok('admin credentials are hash-only PBKDF2-SHA256')
            else:
                add_fail('admin credentials must be PBKDF2-SHA256 hash-only', errors)
            if os.name == 'nt' or (creds.stat().st_mode & 0o777) == 0o600:
                add_ok('admin credentials permissions 0600')
            else:
                add_fail(f'admin credentials permissions {oct(creds.stat().st_mode & 0o777)}, expected 0o600', errors)
        except Exception as exc:
            add_fail(f'cannot read credentials JSON: {exc}', errors)
    else:
        add_fail(f'admin credentials file missing: {creds}', errors)

    reset_file = Path(env.get('ADMIN_PASSWORD_RESET_ACTIVATION_FILE') or APP_DIR / 'app/config/admin_password_reset_activation.json')
    if reset_file.exists():
        try:
            obj = json.loads(reset_file.read_text(encoding='utf-8'))
            if obj.get('enabled') is True:
                add_fail('admin password reset activation is enabled', errors)
            else:
                add_ok('admin password reset activation disabled')
        except Exception:
            add_ok('admin password reset activation file is not active JSON')
    else:
        add_ok('admin password reset activation absent')

    server = APP_DIR / 'app/server_py.py'
    helper = APP_DIR / 'app/server_helpers.py'
    toola = APP_DIR / 'app/toolA.html'
    optimizer = APP_DIR / 'app/dxf_nesting_optimizer.py'
    importer = APP_DIR / 'app/catalog_importer.py'
    pricing_helper = APP_DIR / 'app/pricing_helpers.py'
    required = [server, helper, toola, optimizer, importer, pricing_helper]
    for path in required:
        if path.exists():
            add_ok(f'present: {path.relative_to(APP_DIR)}')
        else:
            add_fail(f'missing: {path.relative_to(APP_DIR)}', errors)

    if all(path.exists() for path in [server, helper, toola]):
        src = server.read_text(encoding='utf-8', errors='ignore')
        hs = helper.read_text(encoding='utf-8', errors='ignore')
        html = toola.read_text(encoding='utf-8', errors='ignore')
        checks = [
            ('FIX657R3 build marker', 'FIX657R3_HTTP8790_STABLE_VAT_TRUTH' in src and 'FIX657R3_HTTP8790_STABLE_VAT_TRUTH' in html),
            ('public SSE allowlist only dxf_changed', "_PUBLIC_SSE_EVENT_ALLOWLIST = frozenset({'dxf_changed'})" in src),
            ('Secure cookie is conditional on actual HTTPS transport', "'; Secure' if _is_https_request(self)" in src),
            ('explicit legacy HTTP proxy bridge is pinned', 'def _is_legacy_http_proxy_request(handler)' in src and 'LEGACY_HTTP_ORIGIN' in src),
            ('header-only token helper', "Authorization" in hs and "parsed`` and ``body``" in hs and 'parse_qs' not in hs),
            ('submit requires finalized job', '_finalization_complete(parent_root)' in src and 'submit-config-link' in src),
            ('queue duplicate optimization removed', '_create_job_from_payload(payload)' not in src[src.find('def process_one_queue_item'):src.find('def _recover_processing_queue_items_fix657')]),
            ('gross CSV material pricing v2', 'catalog_sell_price_incl_vat_v2' in src and 'CSV_SELL_PRICE_INCL_VAT' in src),
            ('Tool A submit sends bearer header', "buildJobTokenHeaders(state?.lastJobAccessToken" in html),
            ('Tool A job token is session-scoped', "sessionStorage.setItem('metod_last_job_access_token'" in html and "localStorage.setItem('metod_last_job_access_token'" not in html),
        ]
        for label, passed in checks:
            add_ok(label) if passed else add_fail(label, errors)

    library = APP_DIR / 'app/material_library.json'
    if library.exists():
        try:
            obj = json.loads(library.read_text(encoding='utf-8'))
            if obj.get('source') == 'CSV_CATALOG_ONLY':
                add_ok('material library source CSV_CATALOG_ONLY')
            else:
                add_fail('material library source must be CSV_CATALOG_ONLY', errors)
            for rec in obj.get('records') or []:
                if not isinstance(rec, dict):
                    continue
                if str(rec.get('sourceKind') or '').upper() != 'CATALOG_IMPORT':
                    add_fail('active material library contains non-CATALOG_IMPORT record', errors)
                    break
                try:
                    if float(rec.get('thicknessMm') or 0) not in (18.0, 19.0, 20.0):
                        add_fail('active material library contains forbidden thickness', errors)
                        break
                    if float(rec.get('sellPriceInclVatPerSheet') or 0) <= 0:
                        add_fail('active material library contains missing gross CSV sheet price', errors)
                        break
                except Exception:
                    add_fail('active material library contains invalid pricing/thickness', errors)
                    break
            else:
                add_ok(f'active catalog records valid ({len(obj.get("records") or [])})')
        except Exception as exc:
            add_fail(f'cannot validate material_library.json: {exc}', errors)
    else:
        add_fail('material_library.json missing', errors)

    pricing = APP_DIR / 'app/config/pricing_active.json'
    if pricing.exists():
        try:
            obj = json.loads(pricing.read_text(encoding='utf-8'))
            sp = obj.get('sellPricing') if isinstance(obj.get('sellPricing'), dict) else {}
            if 'sheetPriceFactor' in sp:
                add_fail('obsolete sheetPriceFactor must not be active', errors)
            else:
                add_ok('no general material factor active')
            for key in ('edgeBandPricePerM', 'cncCostPerSheet', 'drawingCostFixed', 'transportCostFixed'):
                float(sp[key])
            add_ok('all four Admin other-cost fields present')
            if obj.get('pricingModel') == 'catalog_sell_price_incl_vat_v2':
                add_ok('pricing model is mixed-VAT v2')
            else:
                add_fail('pricingModel must be catalog_sell_price_incl_vat_v2', errors)
        except Exception as exc:
            add_fail(f'pricing config invalid: {exc}', errors)

    print('\nRESULT:', 'PASS' if not errors else f'FAIL ({len(errors)} issue(s))')
    return 1 if errors else 0


if __name__ == '__main__':
    raise SystemExit(main())
