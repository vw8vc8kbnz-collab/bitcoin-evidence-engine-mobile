# Outrun IQ v8.4.4 — Wallet UX & Interaction Hardening

- Wallet herbouwd richting premium fintech-ervaring.
- Nieuwe wallet hero met totaal saldo, dagontvangsten, daguitgaven, verwacht vrij en mini cashflowgrafiek.
- AI Cash Insights toegevoegd bovenaan de zakelijke Wallet.
- Snelle acties zijn nu echte navigatie-acties in plaats van statische/disabled UI.
- Transacties uitgebreid met filterchips en doorklikbare regels.
- Donut/saldoverdeling interactiever gemaakt via links naar relevante secties.
- “Orders in je wallet” hernoemd naar openstaande betalingen/escrow-focus.
- Finance preview compacter gemaakt en lager in de pagina geplaatst.
- Grootboek verplaatst naar uitklapbare append-only sectie.
- App-brede tap/klik hardening toegevoegd: `touch-action: manipulation`, hogere dock-z-index, minimale touch targets en betere active feedback.

Safety baseline blijft v8.4.2/v8.4.3 finance-hardening: geen live payments zonder expliciete `PAYMENT_LIVE_ENABLED=true` en provider-live vrijgave.
