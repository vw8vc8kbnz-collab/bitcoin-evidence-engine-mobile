# Volgende stap — R9O6 externe Chromium/WebKit-heruitvoering

## Doel

Bewijs op de externe VPS dat R9O5 alle 15 geregistreerde browserfixtures en alle 100 contractasserties slaagt in echte Chromium en echte WebKit, inclusief desktop- en iPhone-contexten.

## Voorwaarden

- Gebruik deze complete checkpointmap ongewijzigd.
- De VPS heeft Docker, tmux, Git, unzip en sha256sum.
- Gebruik het vastgepinde image-digest in de runner.
- Wijzig R8Z, registry, oracles, profielen, timeouts of assertions niet.

## Eén startregel in Termius

Ga in de uitgepakte checkpointmap staan en voer uit:

```bash
bash operations/RUN_R9O6_EXTERNAL_BROWSER_GATE_TMUX.sh
```

De runner start `metod-r9o6-browser-gate` losgekoppeld. Termius mag daarna sluiten. Volgen kan met:

```bash
tmux attach -t metod-r9o6-browser-gate
```

## Uitkomst lezen

Na afloop staat het bewijs in `/home/ubuntu/metod-r9o6-audit/evidence`. Vereist voor PASS:

- `R9O6_DOCKER_EXIT=0`;
- reportstatus `PASS`;
- 15 fixtures, 15 PASS, 0 FAIL;
- 100 contractasserties;
- `enginesPassed` bevat `chromium` en `webkit`;
- geen blockers;
- `SHA256SUMS.txt` verifieert alle bewijsbestanden.

Bij exit 1, een ontbrekend rapport, minder fixtures/asserties/profielen of een permissie-/toolchainfout blijft de status NO-GO. Upload dan de volledige evidencefolder als ZIP; pas na beoordeling wordt een volgende fase bepaald.

## Na een browser-PASS

Een R9O6 PASS sluit alleen deze externe browserpoort. Daarna volgen nog echte iPhone/Safari-acceptatie, onafhankelijke securityaudit, productieoperations en restoreobservatie, CAM-werkplaats/businessacceptatie en formele release-signoff.
