# Complete technische overdracht — R9O5

## 1. Wat deze tool is

METOD/PAX is een webconfigurator met een publieke klantwizard en een afgeschermde Adminomgeving. De klant selecteert materialen, voert panelen en nerfrichting in, controleert een aanvraag en verstuurt die. De backend beheert duurzame aanvragen en jobs, voert de echte DXF/nesting-optimizer uit, verzegelt outputs en maakt downloadprojecties. Admin beheert inbox/jobs, DXF-presentatie, CSV-catalogus en prijzen via een geauthenticeerde sessie.

De productieruntime is Python-standard-library-only. De browserpresentatie is modulair gesplitst. Tool A heeft externe shell-CSS en 34 externe shell-scripts plus native componenten/state/API-eigenaren. Admin heeft afzonderlijke HTML-templates en geauthenticeerde externe `admin.css`, `admin.js` en `dxf.js`; login gebruikt afzonderlijke `login.css` en `login.js`. De preflight bewijst dat Tool A en Admin geen inline style- of scriptpresentatie bevatten.

## 2. Architectuur- en veiligheidsgrenzen

- R8Z is immutable en uitsluitend de behavior oracle.
- R9O5 is de actuele audit-candidate; FIX660R8 blijft alleen de runtime-compatibiliteitsnaam.
- Optimizer, geometrie, prijswaarheid en outputhashing zijn hash-vergrendeld.
- Aanvraagmutaties, jobplanning, procesgroepen, finalisatie en downloads hebben afzonderlijke eigenaren en fail-closed tests.
- Adminassets zijn anoniem 404 en alleen binnen een geldige Adminsessie beschikbaar.
- Het externe browseroracle draait echte Chromium en echte WebKit met `--network none`, verse profielen en verplichte DOM/network/state/privacy/security/runtime-asserties.

## 3. Bewezen voorgeschiedenis

R9O2 leverde 8/15 browserfixtures PASS. R9O3 herstelde vier echte WebKit-foutgroepen: DXF-requestlifecycle, ResizeObserver-loops, per-profiel cancellation-hold en de eerste mobiele Admin-shrinkregels.

De authentieke R9O4-run op de externe VPS leverde daarna 14/15 fixtures en 99/100 contractasserties PASS. Alleen `webkit-iphone` in `admin-presentation-session-assets` bleef rood: `bodyScrollWidth=492`, `viewportWidth=393`. Chromium desktop, WebKit desktop en Chromium iPhone slaagden voor dezelfde fixture. De ontvangen evidence-ZIP heeft SHA-256 `930a576b4331feb773b5e1a98706fbfcf8509bae4bece77b1c287b8e9330608a`; de interne checksums kloppen.

## 4. R9O5-wijzigingen

### Functionele correctie

De inbox-tabstrip is een wrapping flexcontainer die in WebKit als flex-item zijn automatische intrinsieke minimumbreedte behield. Binnen de mobiele Admin-grid was maar 301px contentruimte beschikbaar, waardoor de gecombineerde tabbreedte de body tot circa 492px verlengde. In de bestaande `@media (max-width:640px)`-grens krijgt uitsluitend `.tabs` nu `min-width:0` en `max-width:100%`. De tabs mogen daardoor binnen hun eigen container wrappen. Er is geen `overflow-x:hidden`, geen viewportmaskering en geen assertionverlaging toegevoegd.

### Bewijsverbetering

De bestaande `admin-layout-fits-viewport`-assertie blijft exact fail-closed. Bij overflow legt de browserdriver nu maximaal veertig zichtbare overschrijdende elementen vast met selectorinformatie, bounding-box, client/scrollbreedte en relevante computed CSS. Dat verandert geen PASS-voorwaarde.

### Operationele correctie

De R9O4-run produceerde geldige root-owned Docker-evidence, maar de post-processing probeerde die vóór `chown` te hashen. De R9O6-runner herstelt ownership direct na Docker, schrijft daarna de exitstatus en bouwt een expliciet zelf-uitsluitend `SHA256SUMS.txt`.

### Extra auditbevinding tijdens build

De eerste volledige R9O5-preflight ontdekte dat drie oudere hermetic tests de nieuwe Tool A-releasemetadatahash al kenden, maar nog de R9O3-bytecount verwachtten. De bytecount is herverzegeld. Ook is een bestaande variabeleschaduwing in de R9I clean-code gate gecorrigeerd en met een nieuwe regressietest afgedekt.

## 5. Verificatie-uitkomst

- runtime-ZIP: 459 leden, één top-level directory, geen Gitmetadata;
- runtime SHA-256: `2a03120c80cb88991d52897ca70d7b9930be77da9fc1358ffcb25d273eb0a4dd`;
- standalone full-preflight: PASS;
- repository/provenance gate: PASS op commit `631f7cb2918f61f4d8dd5db1cfee2f258fe9fe64`;
- security/supply-chain gate: PASS, geen secret- of SAST-bevindingen, geen verplichte third-party Pythonpackages;
- R9O5 identity gate: PASS en expliciet `releaseEligible=false`;
- gerichte R9O5 regressies: 7/7 PASS;
- R8Z SHA-256: `d3e8656d8d7d5a581a8186ef8fe2c91c19b2137a8654b2f2874497dd85255e62`.

## 6. Git en reproduceerbaarheid

- actuele commit: `631f7cb2918f61f4d8dd5db1cfee2f258fe9fe64`;
- tag: `r9o5-webkit-iphone-admin-overflow-remediation-candidate-checkpoint`;
- volledige bundle: `git/METOD_PAX_R9_FULL_HISTORY_THROUGH_R9O5.bundle`;
- de bundle bevat alle branches en tags door R9O5 en is met `git bundle verify` gecontroleerd.

Herstellen: `git clone git/METOD_PAX_R9_FULL_HISTORY_THROUGH_R9O5.bundle repo` en daarna `git -C repo checkout --detach r9o5-webkit-iphone-admin-overflow-remediation-candidate-checkpoint`.

## 7. Wat nog openstaat

R9O6 moet de volledige externe 15-fixture/100-assertion gate in echte Chromium en WebKit opnieuw uitvoeren. Ook bij een R9O6 PASS blijven echte iPhone/Safari-acceptatie, onafhankelijke securityaudit, productieoperations/restoreobservatie, CAM-werkplaatsvalidatie en formele release-signoff afzonderlijke NO-GO-poorten. Er is dus nog geen claim dat deze audit-candidate productie-GO is.
