# README FIRST — METOD/PAX R9O5 complete checkpoint

Dit is de volledige, zelfstandige overdracht van de METOD/PAX-configurator na R9O5. Een nieuwe auditor of nieuwe chat kan met uitsluitend deze map de runtime verifiëren, de immutable R8Z-oracle herstellen, de volledige Git-geschiedenis openen, het authentieke R9O4-bewijs controleren en de verplichte R9O6-browsergate uitvoeren.

## Status

- Lokale volledige preflight: **PASS**.
- Standalone runtime-artifact na extractie in lege map: **PASS**.
- Repository/provenance, supply-chain en release-identiteit: **PASS**.
- R9O4 externe browsergate: **FAIL, 14/15 fixtures PASS, 99/100 contractasserties PASS**.
- Enige R9O4-fout: `admin-presentation-session-assets` / `admin-layout-fits-viewport` / `webkit-iphone`, 492px body bij 393px viewport.
- R9O5 bevat de smalle correctie; onafhankelijke R9O6-heruitvoering is nog verplicht.
- Productiestatus: **NO-GO**. R9O5 is `PROVISIONAL_DEVELOPMENT_ONLY` en `releaseEligible=false`.

## Begin hier

1. Lees `docs/01_COMPLETE_TECHNICAL_HANDOFF_R9O5.md`.
2. Verifieer deze package met `sha256sum -c PACKAGE_MANIFEST_SHA256.txt`.
3. Verifieer de runtime met het `.sha256`-bestand in `runtime/`.
4. Lees `docs/02_NEXT_STEP_R9O6.md` en voer daarna `operations/RUN_R9O6_EXTERNAL_BROWSER_GATE_TMUX.sh` uit op de VPS.

Geen document of script in deze package mag een PASS simuleren of een productie-GO zetten. Alleen nieuw, compleet en cryptografisch gebonden extern bewijs kan de R9O6-browserpoort sluiten.
