from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from typing import Any

from app.core.config import settings
from app.core.debug import append_jsonl, write_json
from app.core.time_utils import utc_now
from app.db.database import db


DIMENSION_TO_SIGNALS: dict[str, list[str]] = {
    "rsi_state": ["rsi_14:"],
    "funding_rate": ["funding_rate:"],
    "open_interest_change_24h": ["open_interest_change_24h:"],
    "long_short_ratio": ["long_short_ratio:"],
    "taker_buy_sell_ratio": ["taker_delta_ratio:", "taker_buy_sell_ratio:"],
    "fear_greed": ["fear_greed:"],
    "spot_premium": ["spot_coinbase_premium:", "spot_cross_exchange_spread:", "spot_kraken_premium:"],
    "volume_zscore": ["volume_zscore:"],
    "drawdown_from_ath": ["drawdown_from_ath:"],
    "regime_code": ["regime:"],
    "data_completeness": ["data_completeness:"],
    "trend": ["trend:"],
    "volatility_24": ["volatility_24:"],
    "forecast_confidence": ["confidence:", "forecast_edge_abs:"],
}

DEFAULT_FEATURE_WEIGHTS: dict[str, float] = {
    "rsi_state": 0.95,
    "funding_rate": 1.35,
    "open_interest_change_24h": 1.45,
    "long_short_ratio": 0.95,
    "taker_buy_sell_ratio": 1.20,
    "fear_greed": 0.60,
    "spot_premium": 1.05,
    "volume_zscore": 0.85,
    "drawdown_from_ath": 0.75,
    "regime_code": 0.55,
    "data_completeness": 0.25,
    "trend": 0.85,
    "volatility_24": 0.95,
    "forecast_confidence": 0.70,
}


def _safe_float(v: Any, default: float = 0.0) -> float:
    try:
        if v is None:
            return default
        x = float(v)
        if x != x or x in (float("inf"), float("-inf")):
            return default
        return x
    except Exception:
        return default


def _clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


class AdaptiveLearningService:
    """Turns Time Machine results into durable adaptive weights.

    v10.16.36 changes the project from "tests are stored" to "tests update the
    engine". The rules are deliberately conservative and inspectable:

    * Unknown/missing signal buckets do not train a positive feature weight.
    * Every feature dimension is compared against the actual baseline hitrate for
      the same horizon/regime so we do not reward easy market periods.
    * Model weights are rebuilt from model_scores and consumed by ModelArena.
    * Rebuild is idempotent: running it twice gives the same table state.
    """

    def rebuild(self, *, source_batch_id: str | None = None, min_total: int = 20) -> dict[str, Any]:
        run_id = str(uuid.uuid4())
        now = utc_now()
        try:
            baseline = self._baseline_by_horizon_regime()
            feature_rows, feature_summary = self._build_feature_weights(baseline, min_total=min_total)
            model_rows, model_summary = self._build_model_weights()
            regime_rows, regime_summary = self._build_regime_weights()
            db.execute("DELETE FROM adaptive_feature_weights")
            if feature_rows:
                db.executemany(
                    "INSERT OR REPLACE INTO adaptive_feature_weights(dimension, weight, quality, sample, matched_signals, updated_at) VALUES (?, ?, ?, ?, ?, ?)",
                    [[r[0], r[1], r[2], r[3], r[4], now] for r in feature_rows],
                )
            db.execute("DELETE FROM adaptive_model_weights")
            if model_rows:
                db.executemany(
                    "INSERT OR REPLACE INTO adaptive_model_weights(model_id, horizon, weight, hitrate, sample, avg_price_error_pct, quality, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    [[r[0], r[1], r[2], r[3], r[4], r[5], r[6], now] for r in model_rows],
                )
            db.execute("CREATE TABLE IF NOT EXISTS adaptive_regime_weights (regime TEXT NOT NULL, horizon TEXT NOT NULL, sample BIGINT DEFAULT 0, wins BIGINT DEFAULT 0, partials BIGINT DEFAULT 0, fails BIGINT DEFAULT 0, hitrate DOUBLE DEFAULT 0.0, hitrate_with_partial DOUBLE DEFAULT 0.0, avg_score DOUBLE DEFAULT 0.0, weight DOUBLE DEFAULT 1.0, quality DOUBLE DEFAULT 0.5, updated_at TIMESTAMP, PRIMARY KEY(regime, horizon))")
            db.execute("DELETE FROM adaptive_regime_weights")
            if regime_rows:
                db.executemany(
                    "INSERT OR REPLACE INTO adaptive_regime_weights(regime, horizon, sample, wins, partials, fails, hitrate, hitrate_with_partial, avg_score, weight, quality, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    [[r[0], r[1], r[2], r[3], r[4], r[5], r[6], r[7], r[8], r[9], r[10], now] for r in regime_rows],
                )
            snapshot_rows = self._count("SELECT COUNT(*) FROM time_machine_feature_snapshots")
            signal_buckets = self._count("SELECT COUNT(*) FROM time_machine_signal_scores")
            payload = {
                "ok": True,
                "engine_version": settings.engine_version,
                "run_id": run_id,
                "source_batch_id": source_batch_id,
                "feature_dimensions": len(feature_rows),
                "model_dimensions": len(model_rows),
                "regime_dimensions": len(regime_rows),
                "signal_buckets": signal_buckets,
                "snapshot_rows": snapshot_rows,
                "features": feature_summary,
                "models": model_summary,
                "regimes": regime_summary,
                "created_at": datetime.now(timezone.utc).isoformat(),
                "message": "adaptive evidence learning rebuilt",
            }
            db.execute(
                "INSERT OR REPLACE INTO adaptive_learning_runs(run_id, created_at, source_batch_id, status, feature_dimensions, model_dimensions, signal_buckets, snapshot_rows, summary_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                [run_id, now, source_batch_id, "completed", len(feature_rows), len(model_rows), signal_buckets, snapshot_rows, json.dumps(payload, default=str)],
            )
            db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ["adaptive_learning", f"active {len(feature_rows)} feature dims · {len(model_rows)} model weights · {len(regime_rows)} regimes · signals {signal_buckets}", now])
            write_json("adaptive_learning_summary.json", payload)
            append_jsonl("adaptive_learning_audit.jsonl", {"event": "adaptive_learning_rebuilt_v101636", **payload})
            return payload
        except Exception as exc:
            append_jsonl("adaptive_learning_audit.jsonl", {"event": "adaptive_learning_failed_v101636", "run_id": run_id, "error": str(exc)})
            try:
                db.execute(
                    "INSERT OR REPLACE INTO adaptive_learning_runs(run_id, created_at, source_batch_id, status, summary_json) VALUES (?, ?, ?, ?, ?)",
                    [run_id, now, source_batch_id, "error", json.dumps({"error": str(exc)})],
                )
            except Exception:
                pass
            return {"ok": False, "error": str(exc), "run_id": run_id}

    def _count(self, sql: str) -> int:
        row = db.fetchone(sql)
        return int(row[0] or 0) if row else 0

    def _baseline_by_horizon_regime(self) -> dict[tuple[str, str], float]:
        rows = db.df(
            """
            SELECT horizon, regime,
                   COUNT(*) AS total,
                   AVG(CASE WHEN target_reached OR partial_reached THEN 1.0 ELSE 0.0 END) AS hwp
            FROM time_machine_feature_snapshots
            GROUP BY horizon, regime
            """
        ).to_dict("records")
        out: dict[tuple[str, str], float] = {}
        global_rows = db.df(
            """
            SELECT horizon,
                   AVG(CASE WHEN target_reached OR partial_reached THEN 1.0 ELSE 0.0 END) AS hwp
            FROM time_machine_feature_snapshots
            GROUP BY horizon
            """
        ).to_dict("records")
        global_by_h = {str(r.get("horizon")): _safe_float(r.get("hwp"), 0.5) for r in global_rows}
        for r in rows:
            h = str(r.get("horizon") or "unknown")
            reg = str(r.get("regime") or "unknown")
            out[(h, reg)] = _safe_float(r.get("hwp"), global_by_h.get(h, 0.5))
        return out

    def _build_feature_weights(self, baseline: dict[tuple[str, str], float], min_total: int) -> tuple[list[list[Any]], list[dict[str, Any]]]:
        rows = db.df(
            """
            SELECT signal_key, signal_label, signal_type, horizon, regime, total, wins, partials, fails,
                   hitrate, hitrate_with_partial, avg_score, avg_target_gap_pct
            FROM time_machine_signal_scores
            WHERE total >= ?
            """,
            [int(min_total)],
        ).to_dict("records")
        by_dim: dict[str, dict[str, Any]] = {}
        for dim, prefixes in DIMENSION_TO_SIGNALS.items():
            base_weight = DEFAULT_FEATURE_WEIGHTS.get(dim, 1.0)
            acc = {"sample": 0.0, "matched": 0, "quality_sum": 0.0, "edge_sum": 0.0, "best": [], "worst": []}
            for r in rows:
                key = str(r.get("signal_key") or "")
                # Unknown/missing buckets are diagnostic, not positive learning.
                if key.endswith(":unknown") or ":unknown" in key:
                    continue
                if not any(key.startswith(p) for p in prefixes):
                    continue
                n = float(r.get("total") or 0)
                if n <= 0:
                    continue
                h = str(r.get("horizon") or "unknown")
                reg = str(r.get("regime") or "unknown")
                hwp = _safe_float(r.get("hitrate_with_partial"), 0.0)
                hit = _safe_float(r.get("hitrate"), 0.0)
                avg_score = _safe_float(r.get("avg_score"), 0.0) / 100.0
                gap_penalty = max(0.0, 1.0 - min(_safe_float(r.get("avg_target_gap_pct"), 0.0), 10.0) / 10.0)
                b = baseline.get((h, reg), baseline.get((h, "unknown"), 0.5))
                edge = hwp - b
                # Quality combines absolute performance and regime-relative edge.
                q = 0.46 * hwp + 0.24 * hit + 0.20 * avg_score + 0.10 * gap_penalty + 0.35 * edge
                acc["sample"] += n
                acc["matched"] += 1
                acc["quality_sum"] += q * n
                acc["edge_sum"] += edge * n
                rec = {"signal": key, "label": r.get("signal_label"), "horizon": h, "regime": reg, "sample": int(n), "hwp": round(hwp, 4), "edge": round(edge, 4)}
                (acc["best"] if edge >= 0 else acc["worst"]).append(rec)
            if acc["sample"] <= 0:
                continue
            sample = int(acc["sample"])
            quality = acc["quality_sum"] / acc["sample"]
            edge = acc["edge_sum"] / acc["sample"]
            maturity = _clamp(sample / 1000.0, 0.15, 1.0)
            # Conservative but real: weak dimensions can go below base, useful ones above base.
            multiplier = _clamp(1.0 + edge * (1.2 + 0.8 * maturity) + (quality - 0.50) * 0.45, 0.50, 1.85)
            weight = _clamp(base_weight * multiplier, 0.10, 2.85)
            by_dim[dim] = {
                "dimension": dim,
                "weight": round(weight, 6),
                "quality": round(quality, 6),
                "sample": sample,
                "matched_signals": int(acc["matched"]),
                "edge": round(edge, 6),
                "base_weight": base_weight,
                "best": sorted(acc["best"], key=lambda x: (x["edge"], x["sample"]), reverse=True)[:6],
                "worst": sorted(acc["worst"], key=lambda x: (x["edge"], -x["sample"]))[:6],
            }
        ordered = sorted(by_dim.values(), key=lambda r: (r["sample"], abs(r["weight"] - DEFAULT_FEATURE_WEIGHTS.get(r["dimension"], 1.0))), reverse=True)
        table_rows = [[r["dimension"], r["weight"], r["quality"], r["sample"], r["matched_signals"]] for r in ordered]
        return table_rows, ordered

    def _build_model_weights(self) -> tuple[list[list[Any]], list[dict[str, Any]]]:
        rows = db.df("SELECT model_id, horizon, total, hitrate, avg_price_error_pct FROM model_scores WHERE total > 0").to_dict("records")
        out_rows: list[list[Any]] = []
        summary: list[dict[str, Any]] = []
        for r in rows:
            total = int(r.get("total") or 0)
            hitrate = _safe_float(r.get("hitrate"), 0.5)
            err = _safe_float(r.get("avg_price_error_pct"), 0.0)
            maturity = _clamp(total / 1000.0, 0.10, 1.0)
            # 50% is neutral. Reward evidence slowly until enough sample exists.
            quality = _clamp(0.5 + (hitrate - 0.5) * (0.9 + 0.6 * maturity) - min(err, 5.0) * 0.015, 0.05, 0.95)
            weight = _clamp(0.65 + quality * 1.25, 0.45, 1.90)
            rec = {
                "model_id": str(r.get("model_id")), "horizon": str(r.get("horizon")),
                "sample": total, "hitrate": round(hitrate, 4), "avg_price_error_pct": round(err, 4),
                "quality": round(quality, 6), "weight": round(weight, 6),
            }
            summary.append(rec)
            out_rows.append([rec["model_id"], rec["horizon"], rec["weight"], rec["hitrate"], rec["sample"], rec["avg_price_error_pct"], rec["quality"]])
        summary.sort(key=lambda x: (x["horizon"], -x["quality"], -x["sample"]))
        return out_rows, summary

    def status(self) -> dict[str, Any]:
        latest = db.fetchone("SELECT run_id, created_at, status, feature_dimensions, model_dimensions, signal_buckets, snapshot_rows, summary_json FROM adaptive_learning_runs ORDER BY created_at DESC LIMIT 1")
        feature_rows = db.df("SELECT * FROM adaptive_feature_weights ORDER BY sample DESC, quality DESC").to_dict("records")
        model_rows = db.df("SELECT * FROM adaptive_model_weights ORDER BY horizon, quality DESC, sample DESC LIMIT 250").to_dict("records")
        try:
            regime_rows = db.df("SELECT * FROM adaptive_regime_weights ORDER BY horizon, quality DESC, sample DESC LIMIT 250").to_dict("records")
        except Exception:
            regime_rows = []
        top_signals = db.df(
            """
            SELECT signal_key, signal_label, signal_type, horizon, regime, total, wins, partials, fails,
                   hitrate, hitrate_with_partial, avg_score, avg_target_gap_pct
            FROM time_machine_signal_scores
            WHERE total >= 20 AND signal_key NOT LIKE '%:unknown%'
            ORDER BY hitrate_with_partial DESC, total DESC, avg_score DESC
            LIMIT 60
            """
        ).to_dict("records")
        payload = {
            "ok": True,
            "engine_version": settings.engine_version,
            "latest_run": {
                "run_id": latest[0], "created_at": latest[1], "status": latest[2], "feature_dimensions": int(latest[3] or 0),
                "model_dimensions": int(latest[4] or 0), "signal_buckets": int(latest[5] or 0), "snapshot_rows": int(latest[6] or 0)
            } if latest else None,
            "feature_weights": feature_rows,
            "model_weights": model_rows,
            "regime_weights": regime_rows,
            "top_signals": top_signals,
            "summary": {
                "feature_dimensions": len(feature_rows),
                "model_dimensions": len(model_rows),
                "regime_dimensions": len(regime_rows),
                "top_signal_buckets": len(top_signals),
                "active": bool(feature_rows or model_rows or regime_rows),
            },
        }
        write_json("adaptive_learning_status.json", payload)
        return payload
