from pathlib import Path
import os
from pydantic import BaseModel

class Settings(BaseModel):
    app_name: str = "Bitcoin Evidence Engine V10.16.32 Cursor Repair Backfill"
    host: str = os.environ.get("BEE_HOST", "127.0.0.1")
    port: int = int(os.environ.get("PORT", os.environ.get("BEE_PORT", "8787")))
    base_dir: Path = Path(__file__).resolve().parents[2]
    data_dir: Path = Path(os.environ.get("BEE_DATA_DIR", str(Path.home() / "bitcoin_evidence_data")))
    db_path: Path = data_dir / "bitcoin_evidence_engine.duckdb"
    symbol: str = "BTCUSDT"
    horizons: tuple[str, ...] = ("1h", "4h", "8h", "24h", "7d", "30d", "90d")
    min_forecast_gap_minutes: int = 10
    bootstrap_candles_limit: int = 1000
    # V4: deep hourly history. Binance BTCUSDT hourly data starts in 2017.
    # The app backfills in chunks so it can resume cleanly after interruption.
    historical_start_ms: int = 1502928000000  # 2017-08-17 00:00:00 UTC
    backfill_chunk_limit: int = 1000
    backfill_max_chunks_per_sync: int = 1
    historical_target_years: int = 8
    historical_target_rows_1h: int = 70000
    historical_backfill_max_chunks_background: int = 10000
    historical_backfill_batch_pause_seconds: float = 0.02
    request_timeout_seconds: float = 5.0
    binance_backfill_timeout_seconds: float = 18.0
    binance_backfill_retries: int = 4
    binance_backfill_retry_pause_seconds: float = 1.25
    futures_symbol: str = "BTCUSDT"
    adaptive_min_signal_total: int = 25
    adaptive_activation_sample: int = 100
    adaptive_strong_activation_sample: int = 500
    adaptive_min_rows_used: int = 10
    feature_progressive_rebuild_every_chunks: int = 25
    historical_daemon_pass_chunks: int = 24
    historical_daemon_pause_seconds: float = 0.75
    historical_daemon_autostart_delay_seconds: float = 1.0
    historical_daemon_stall_backoff_seconds: float = 20.0
    historical_feature_rebuild_min_new_rows: int = 1000000000
    learning_bootstrap_enabled: bool = False
    learning_bootstrap_min_history_rows: int = 8000
    learning_bootstrap_target_rows_used: int = 25
    learning_bootstrap_batch_size: int = 100
    learning_bootstrap_max_batches_per_pass: int = 2
    historical_auto_complete_on_startup: bool = True
    external_backfill_enabled: bool = os.environ.get("BEE_EXTERNAL_BACKFILL", "1") == "1"
    # V10.16.23: external evidence is important, but may never block Forecast/UI.
    # It runs as a resumable daemon with short per-call limits and persistent checkpoints.
    external_backfill_passes_per_sync: int = int(os.environ.get("BEE_EXTERNAL_BACKFILL_PASSES", "8"))
    external_backfill_max_feeds: int = int(os.environ.get("BEE_EXTERNAL_BACKFILL_MAX_FEEDS", "10"))
    external_backfill_pause_seconds: float = float(os.environ.get("BEE_EXTERNAL_BACKFILL_PAUSE", "0.75"))
    external_daemon_start_delay_seconds: float = float(os.environ.get("BEE_EXTERNAL_DAEMON_DELAY", "45"))
    external_daemon_loop_sleep_seconds: float = float(os.environ.get("BEE_EXTERNAL_DAEMON_SLEEP", "120"))
    external_provider_timeout_seconds: float = float(os.environ.get("BEE_EXTERNAL_PROVIDER_TIMEOUT", "7"))
    coinmetrics_enabled: bool = os.environ.get("BEE_COINMETRICS_ENABLED", "0") == "1"
    coinmetrics_api_key: str = os.environ.get("BEE_COINMETRICS_API_KEY", "").strip()

    # V10.16.25: persistent historical external warehouse. One-time backfills
    # are resumable and stored in /home/ubuntu/bitcoin_evidence_data. Forecast
    # and Time Machine read the same feature/state-vector table.
    external_history_target_start_ms: int = int(os.environ.get("BEE_EXTERNAL_HISTORY_START_MS", "1502928000000"))
    external_history_pages_per_daemon_pass: int = int(os.environ.get("BEE_EXTERNAL_HISTORY_PAGES", "6"))
    external_history_rebuild_features_after_rows: int = int(os.environ.get("BEE_EXTERNAL_REBUILD_AFTER_ROWS", "200"))
    engine_version: str = "v10.16.39-visual-tm-forecast-regime"
    cloud_mode: bool = os.environ.get("BEE_CLOUD_MODE", "0") == "1"
    public_base_url: str = os.environ.get("BEE_PUBLIC_BASE_URL", "").strip()

settings = Settings()
settings.data_dir.mkdir(parents=True, exist_ok=True)
