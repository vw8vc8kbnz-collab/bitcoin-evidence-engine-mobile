from __future__ import annotations
import httpx
from datetime import datetime, timezone, timedelta
from app.core.config import settings

class CoinMetricsProvider:
    source = "coinmetrics_community"
    base_url = "https://community-api.coinmetrics.io/v4"

    async def fetch_asset_metrics(self, metrics: list[str], days: int = 3000) -> list[dict]:
        # Community API availability varies by metric. Failures are captured by SyncService data_health.
        start = (datetime.now(timezone.utc) - timedelta(days=days)).date().isoformat()
        params = {"assets":"btc", "metrics": ",".join(metrics), "frequency":"1d", "start_time": start}
        async with httpx.AsyncClient(timeout=max(settings.request_timeout_seconds, 25.0)) as client:
            r = await client.get(f"{self.base_url}/timeseries/asset-metrics", params=params)
            r.raise_for_status()
            data = r.json().get("data", [])
        rows=[]
        for item in data:
            ts = int(datetime.fromisoformat(item["time"].replace("Z","+00:00")).timestamp()*1000)
            for m in metrics:
                val = item.get(m)
                if val is not None:
                    try: rows.append({"metric": m, "timestamp_ms": ts, "value": float(val)})
                    except ValueError: pass
        return rows
