#!/usr/bin/env python3
"""Stock Evidence Engine v2.0.0 — Honest Validation Build.

Methodological break vs v1.9.x:
- Entry at NEXT-DAY OPEN (no same-close entry optimism).
- Drift = unconditional h-day return of the ticker itself (not other setups).
- validated_edge tested vs drift (excess CI), not vs zero.
- evidence_score/quant_elite computed on n_eff, no now-snapshot leakage.
- Row-level AI scale detection (no more 7/100 -> 70 corruption).
- Word-boundary + recency-aware headline scoring.
- NTFY: ASCII-safe headers (emoji header bug fixed), priority levels,
  cross-run dedup, enabled by default, test mode: python engine.py --ntfy-test
"""
import os, sys, json, math, time, zipfile, csv, re
from pathlib import Path
from datetime import datetime, timezone
import requests
import pandas as pd
import numpy as np
from dotenv import load_dotenv

VERSION='v2.1.1'
BASE=Path(__file__).resolve().parent
OUT=BASE/'output'; OUT.mkdir(exist_ok=True)
load_dotenv(BASE/'.env')
BLACKLIST_DEFAULT={'LAZR'}
HEALTH_FILE=OUT/'ticker_health.json'
FAIL_LOG=OUT/'download_failures.log'
NTFY_STATE=OUT/'ntfy_state.json'
LAST_RUN=OUT/'last_run.json'
TRADE_COST_PCT=float(os.getenv('SEE_TRADE_COST_PCT','0.20'))
try:
    DATA_CACHE=Path(os.getenv('SEE_DATA_CACHE','/home/ubuntu/stock_evidence_data_cache'))
    for sub in ('price_cache','news_cache','metadata_cache','stock_lab'):
        (DATA_CACHE/sub).mkdir(parents=True, exist_ok=True)
except Exception:
    DATA_CACHE=BASE/'data_cache'
    for sub in ('price_cache','news_cache','metadata_cache','stock_lab'):
        (DATA_CACHE/sub).mkdir(parents=True, exist_ok=True)

DEFAULT_UNIVERSE = "BB,PLTR,IONQ,SOUN,NVDA,AMD,TSLA,AI,BBAI,RKLB,SMR,ACHR,JOBY,UPST,HOOD,COIN,MARA,RIOT,LCID,RIVN,RGTI,QBTS,OKLO,ASTS,LUNR,OUST,PATH,SOFI,AFRM,ROKU,SHOP,NET,CRWD,DDOG,SNOW,ARM,MU,AVGO,TSM,SMCI,APP,MRVL,INTC,ORCL,MSFT,GOOGL,META,AMZN,CRSP,BEAM,EDIT,NTLA,PLUG,ENPH,FSLR,CCJ,UEC,UUUU,EVGO,CHPT,QS,OPEN,DKNG,TDOC,SPCE,ENVX,STEM,SERV,TER,ISRG,IRDM,KTOS,AVAV,HIMS,NU,SE,GRAB,TOST,U,LMND,ROOT,CVNA"
THEME_MAP={
 'AI':['SOUN','BBAI','AI','PLTR','NVDA','AMD','SMCI','ARM','AVGO','MRVL','ORCL','MSFT','GOOGL','META'],
 'QUANTUM':['IONQ','RGTI','QBTS'], 'SPACE':['RKLB','LUNR','ASTS','SPCE','IRDM'],
 'NUCLEAR':['SMR','OKLO','CCJ','UEC','UUUU'], 'CRYPTO':['COIN','MARA','RIOT'],
 'EV_ROBOTICS':['ACHR','JOBY','LCID','RIVN','TSLA','OUST','SERV'],
 'FINTECH':['HOOD','SOFI','AFRM','NU','TOST'], 'CYBER_CLOUD':['CRWD','NET','DDOG','SNOW','PATH'],
 'BIOTECH':['CRSP','BEAM','EDIT','NTLA'], 'DEFENSE':['KTOS','AVAV','PLTR']
}
SPECIAL={t:theme for theme,arr in THEME_MAP.items() for t in arr}

def env_float(k,d):
    try: return float(os.getenv(k,d))
    except: return d

def env_int(k,d):
    try: return int(os.getenv(k,d))
    except: return d

def clamp100(x, default=0.0):
    """Plain 0-100 clamp. NEVER applies a 0-10 -> 0-100 heuristic.
    Use for internal engine scores (evidence, validation, attention)."""
    try: v=float(x)
    except Exception: return float(default)
    if math.isnan(v): return float(default)
    return round(max(0.0, min(100.0, v)), 2)

def safe_float(x, default=0):
    try:
        v=float(x)
        return default if math.isnan(v) else v
    except Exception: return default

def clean_universe(tickers):
    seen=[]
    for raw in tickers:
        t=str(raw).strip().upper()
        if not t or t in seen or t in BLACKLIST_DEFAULT:
            continue
        seen.append(t)
    return seen

# ---------------- ticker health ----------------
def _load_health():
    try: return json.loads(HEALTH_FILE.read_text())
    except Exception: return {}

def _save_health(h):
    HEALTH_FILE.write_text(json.dumps(h, indent=2, sort_keys=True))

def _mark_fail(ticker, reason):
    h=_load_health(); rec=h.get(ticker, {'fails':0,'last_error':''})
    rec['fails']=int(rec.get('fails',0))+1; rec['last_error']=str(reason)[:300]; rec['last_failed_at']=datetime.now(timezone.utc).isoformat()
    if rec['fails']>=3: rec['auto_blacklisted']=True
    h[ticker]=rec; _save_health(h)
    with FAIL_LOG.open('a', encoding='utf-8') as f:
        f.write(f"{datetime.now(timezone.utc).isoformat()} {ticker} {str(reason)[:300]}\n")

def _mark_ok(ticker, rows):
    h=_load_health(); rec=h.get(ticker, {})
    rec.update({'fails':0,'last_ok_at':datetime.now(timezone.utc).isoformat(),'rows':int(rows),'auto_blacklisted':False})
    h[ticker]=rec; _save_health(h)

# ---------------- price cache ----------------
def _cache_key(ticker, period, interval='1d'):
    safe=''.join(ch if ch.isalnum() or ch in ('-','_','.') else '_' for ch in str(ticker).upper())
    return f"{safe}_{period}_{interval}.csv"

def _price_cache_path(ticker, period, interval='1d'):
    return DATA_CACHE/'price_cache'/_cache_key(ticker, period, interval)

def _read_price_cache(ticker, period, interval='1d'):
    """v2.0.0: default max last-bar age is 3 days (was 7). Live mode must not
    score on week-old prices; 3 days still covers weekends."""
    p=_price_cache_path(ticker, period, interval)
    if not p.exists(): return None
    try:
        df=pd.read_csv(p, index_col=0, parse_dates=True)
        if df is None or df.empty or 'Close' not in df or 'Volume' not in df:
            return None
        last=pd.to_datetime(df.index[-1]).date()
        age=(datetime.now(timezone.utc).date()-last).days
        if age > env_int('SEE_PRICE_CACHE_MAX_LAST_BAR_AGE_DAYS', 3):
            return None
        return df.dropna().copy()
    except Exception:
        return None

def _write_price_cache(ticker, period, df, interval='1d'):
    try:
        p=_price_cache_path(ticker, period, interval)
        tmp=p.with_suffix('.tmp')
        df.to_csv(tmp); tmp.replace(p)
        return True
    except Exception:
        return False

def fetch_hist(tickers, period='2y'):
    import yfinance as yf
    data={}; health=_load_health()
    for t in clean_universe(tickers):
        cached=_read_price_cache(t, period)
        if cached is not None and len(cached)>=80:
            data[t]=cached; _mark_ok(t, len(cached)); print(f'[CACHE] {t} {period} rows={len(cached)}')
            continue
        hrec=health.get(t,{})
        if hrec.get('auto_blacklisted'):
            try:
                age_h=(datetime.now(timezone.utc)-pd.to_datetime(hrec.get('last_failed_at'))).total_seconds()/3600
            except Exception:
                age_h=999
            if age_h < env_float('SEE_BLACKLIST_EXPIRY_HOURS',24):
                print(f'[SKIP] {t} auto-blacklisted ({age_h:.0f}h geleden); vervalt na 24h')
                continue
            print(f'[RETRY] {t} blacklist verlopen, opnieuw proberen')
        last_err=None
        for attempt in range(1,4):
            try:
                df=yf.download(t, period=period, interval='1d', auto_adjust=True, progress=False, threads=False)
                if df is None or df.empty or len(df)<80:
                    raise RuntimeError(f'no usable price data rows={0 if df is None else len(df)}')
                if isinstance(df.columns, pd.MultiIndex): df.columns=[c[0] for c in df.columns]
                df=df.dropna().copy()
                if df.empty or 'Close' not in df or 'Volume' not in df:
                    raise RuntimeError('missing OHLCV columns after cleanup')
                data[t]=df; _write_price_cache(t, period, df); _mark_ok(t,len(df)); print(f'[DL] {t} {period} rows={len(df)}'); break
            except Exception as e:
                last_err=e
                time.sleep(0.6*attempt)
        if t not in data:
            print(f'[WARN] {t} skipped after retries: {last_err}')
            _mark_fail(t,last_err)
    return data

# ---------------- live metrics (snapshot; live mode only) ----------------
def metrics_for(df, bench=None):
    close=df['Close']; vol=df['Volume']
    ret1=(close.iloc[-1]/close.iloc[-2]-1)*100 if len(close)>2 else 0
    ret3=(close.iloc[-1]/close.iloc[-4]-1)*100 if len(close)>4 else ret1
    ret20=(close.iloc[-1]/close.iloc[-21]-1)*100 if len(close)>21 else ret3
    ma20=close.rolling(20).mean().iloc[-1]; ma50=close.rolling(50).mean().iloc[-1]
    rv=float(vol.iloc[-1]/max(1,vol.rolling(20).mean().iloc[-1])) if len(vol)>20 else 1
    high52=float(close.tail(252).max()) if len(close)>20 else float(close.max())
    pos52=float(close.iloc[-1]/high52*100) if high52 else 0
    rs=0
    if bench is not None and len(bench)>21:
        b=bench['Close']; br=(b.iloc[-1]/b.iloc[-21]-1)*100
        rs=ret20-br
    score=clamp100(45 + ret20*1.8 + (rv-1)*8 + rs*1.2 + (5 if close.iloc[-1]>ma50 else -5))
    return dict(price=float(close.iloc[-1]),ret1=ret1,ret3=ret3,ret20=ret20,relative_volume=rv,position_52w=pos52,rs_vs_bench=rs,technical_score=score,above_ma50=bool(close.iloc[-1]>ma50),above_ma20=bool(close.iloc[-1]>ma20))

# ---------------- backtest signal generation ----------------
def setup_rows(ticker, df, m):
    """v2.0.0 honest execution model:
    - Signal evaluated on Close of bar i (all inputs known at that close).
    - ENTRY at Open of bar i+1 (you cannot trade the close that formed the signal).
    - EXIT at Close of bar i+h.
    - Flat cost TRADE_COST_PCT subtracted per round trip.
    Snapshot fields (price/ret20/technical_score) are attached as LIVE CONTEXT
    ONLY and are never part of any historical evidence calculation."""
    holds=[3,5,10,20]
    rows=[]; trades=[]
    close=df['Close']; vol=df['Volume']
    openp=df['Open'] if 'Open' in df else close
    ma20=close.rolling(20).mean(); ma50=close.rolling(50).mean(); avgvol=vol.rolling(20).mean()
    engines=['momentum_continuation_legacy','relative_strength_leader','momentum_rs_continuation','theme_momentum_leader','catalyst_momentum_proxy','price_reaction_confirmed']
    n_bars=len(df)
    def _cond(eng, i):
        if i<21: return False
        r20=(close.iloc[i]/close.iloc[i-20]-1)*100; rv=vol.iloc[i]/max(1,avgvol.iloc[i])
        if eng=='momentum_continuation_legacy': return r20>8 and rv>1.1 and close.iloc[i]>ma50.iloc[i]
        if eng=='relative_strength_leader': return r20>12 and close.iloc[i]>ma20.iloc[i]
        if eng=='momentum_rs_continuation': return r20>10 and rv>1.25
        if eng=='theme_momentum_leader': return ticker in SPECIAL and r20>8
        if eng=='catalyst_momentum_proxy': return ticker in SPECIAL and r20>5 and rv>1.2
        if eng=='price_reaction_confirmed': return i>=3 and (close.iloc[i]/close.iloc[i-3]-1)*100>5 and rv>1.5
        return False
    for eng in engines:
        dates=[i for i in range(60, n_bars-2) if _cond(eng, i)]
        # v2.1.0: is this engine's condition true on the LAST completed bar?
        # Used by forward tracking to log signals that are actionable today.
        active_today=int(bool(_cond(eng, n_bars-1)))
        for h in holds:
            rets=[]
            for i in dates:
                if i+h >= n_bars: continue
                entry=float(openp.iloc[i+1]) if safe_float(openp.iloc[i+1])>0 else float(close.iloc[i+1])
                exitp=float(close.iloc[i+h])
                r=(exitp/entry-1)*100 - TRADE_COST_PCT
                rets.append(r)
                trades.append(dict(ticker=ticker,setup=eng,hold_days=h,signal_date=str(df.index[i].date()),entry_date=str(df.index[i+1].date()),exit_date=str(df.index[i+h].date()),return_pct=round(r,4),execution='next_open_entry_v2'))
            n=len(rets); avg=float(np.mean(rets)) if n else 0; win=float(np.mean([x>0 for x in rets])*100) if n else 0
            # Raw stats only. evidence_score / elite / usable are decided later
            # by the validation layer on NON-OVERLAPPING samples (n_eff).
            rows.append(dict(ticker=ticker,theme=SPECIAL.get(ticker,'GENERAL'),setup=eng,hold_days=h,trades=n,avg_return_pct=round(avg,3),winrate_pct=round(win,2),evidence_score=0.0,fake_alpha_warning=1 if n<15 else 0,usable=0,good_candidate=0,elite=0,signal_active_today=active_today,last_bar_date=str(df.index[-1].date()),price=round(m['price'],3),ret3=round(m['ret3'],2),ret20=round(m['ret20'],2),relative_volume=round(m['relative_volume'],2),rs_vs_bench=round(m['rs_vs_bench'],2),position_52w=round(m['position_52w'],1),technical_score=round(m['technical_score'],1),snapshot_fields_note='live_context_only_not_in_evidence'))
    return rows,trades

# ---------------- news ----------------
def _parse_news_ts(ts):
    """Return (iso_string, age_days) from yfinance epoch or ISO pubDate."""
    try:
        if ts in (None,''): return '', None
        if isinstance(ts,(int,float)) and ts>1_000_000_000:
            dt=datetime.fromtimestamp(float(ts), tz=timezone.utc)
        else:
            dt=pd.to_datetime(str(ts), utc=True).to_pydatetime()
        age=(datetime.now(timezone.utc)-dt).total_seconds()/86400.0
        return dt.isoformat(), round(age,2)
    except Exception:
        return str(ts), None

def get_news(ticker, maxn=20):
    import yfinance as yf
    items=[]
    try:
        news=yf.Ticker(ticker).news or []
        for n in news[:maxn]:
            title=n.get('title') or n.get('content',{}).get('title') or ''
            pub=n.get('publisher') or n.get('content',{}).get('provider',{}).get('displayName') or ''
            link=n.get('link') or n.get('content',{}).get('canonicalUrl',{}).get('url') or ''
            ts=n.get('providerPublishTime') or n.get('content',{}).get('pubDate') or ''
            iso,age=_parse_news_ts(ts)
            items.append(dict(ticker=ticker,title=title,publisher=pub,link=link,published=iso,age_days=age))
    except Exception:
        pass
    # dedupe identical titles (Yahoo repeats syndicated headlines)
    seen=set(); out=[]
    for x in items:
        key=x['title'].strip().lower()
        if x['title'] and key not in seen:
            seen.add(key); out.append(x)
    return out

_BULL_WORDS=['partnership','contract','deal','upgrade','beats','beat','guidance','approval','launch','merger','acquisition','ai','nvidia','government','billion','award','expands','record']
_BEAR_WORDS=['offering','dilution','downgrade','lawsuit','misses','miss','bankruptcy','investigation','recall','probe','delisting','halt']
_WORD_RE={w:re.compile(r'\b'+re.escape(w)+r'\b') for w in _BULL_WORDS+_BEAR_WORDS}

def _recency_weight(age_days):
    """1.0 for <=1d old, decaying to 0 at 7d. Unknown age counts half."""
    if age_days is None: return 0.5
    if age_days<=1: return 1.0
    if age_days>=7: return 0.0
    return max(0.0, 1.0-(age_days-1)/6.0)

def local_event_score(ticker, news, m):
    """v2.0.0: word-boundary matching (no more 'said' counting as 'ai') and
    recency weighting (a 3-week-old headline is not a catalyst of today)."""
    b=0.0; r=0.0
    for item in news:
        w=_recency_weight(item.get('age_days'))
        if w<=0: continue
        t=str(item.get('title','')).lower()
        b+=w*sum(1 for word in _BULL_WORDS if _WORD_RE[word].search(t))
        r+=w*sum(1 for word in _BEAR_WORDS if _WORD_RE[word].search(t))
    catalyst=clamp100(45+b*7-r*12 + (10 if ticker in SPECIAL else 0))
    reaction=clamp100(45+m['ret3']*2+(m['relative_volume']-1)*10+m['rs_vs_bench']*1.5)
    return catalyst,reaction

# ---------------- AI normalization ----------------
AI_SCORE_FIELDS = ['ai_final_score','final_score','materiality','market_confirmation','priced_in_risk','continuation_3d','continuation_10d','rarity','repricing_potential','volume_confirmation','relative_strength_confirmation','fade_risk']

def normalize_score(x, default=0, scale_0_10=False):
    """0-100 clamp. Only multiplies by 10 when scale_0_10 is explicitly True.
    v2.0.0 removes the old per-field <=10 heuristic that corrupted honest low
    scores (a real 7/100 used to become 70)."""
    if x is None or x=='':
        return float(default)
    try: v=float(x)
    except Exception: return float(default)
    if math.isnan(v): return float(default)
    if scale_0_10: v*=10.0
    return round(max(0.0, min(100.0, v)), 2)

def ai_tier(score):
    s=safe_float(score,0)
    if s>=90: return 'AI_EXTREME'
    if s>=80: return 'AI_ELITE'
    if s>=70: return 'AI_HIGH'
    if s>=55: return 'AI_GOOD'
    return 'AI_LOW'

def _row_is_0_10_scale(row):
    """Row-level scale detection: only if ALL present numeric score fields are
    <=10 do we treat the row as 0-10. A single field like priced_in_risk=7 in
    an otherwise 0-100 row stays 7."""
    vals=[]
    for k in AI_SCORE_FIELDS:
        if k in row and row.get(k) not in (None,''):
            try:
                v=float(row[k])
                if not math.isnan(v): vals.append(v)
            except Exception: continue
    return bool(vals) and all(0<=v<=10 for v in vals) and any(v>0 for v in vals)

def normalize_ai_row(row):
    row=dict(row or {})
    if 'ai_final_score' not in row and 'final_score' in row:
        row['ai_final_score']=row.get('final_score')
    if 'market_confirmation' not in row and 'market_reaction_confirmation' in row:
        row['market_confirmation']=row.get('market_reaction_confirmation')
    if 'materiality' not in row and 'news_importance' in row:
        row['materiality']=row.get('news_importance')
    scale=_row_is_0_10_scale(row)
    for k in AI_SCORE_FIELDS:
        if k in row:
            row[k]=normalize_score(row.get(k), 0, scale_0_10=scale)
    if 'ai_final_score' in row:
        row['final_score']=normalize_score(row.get('ai_final_score'), 0)
    else:
        row['ai_final_score']=normalize_score(row.get('final_score'), 0)
        row['final_score']=row['ai_final_score']
    row['ai_tier']=ai_tier(row.get('ai_final_score'))
    if not row.get('conviction') or str(row.get('conviction')).upper() in ('', 'WATCH', 'GOOD', 'HIGH', 'ELITE', 'EXTREME'):
        row['conviction']={'AI_EXTREME':'EXTREME','AI_ELITE':'ELITE','AI_HIGH':'HIGH','AI_GOOD':'GOOD','AI_LOW':'WATCH'}[row['ai_tier']]
    row['normalization_version']='v2.0.0_row_scale_detect'
    return row

def summarize_setups_for_ticker(summary_rows, ticker, limit=6):
    rows=[r for r in summary_rows if r.get('ticker')==ticker]
    rows=sorted(rows, key=lambda r: (int(r.get('elite',0)), safe_float(r.get('evidence_score')), safe_float(r.get('avg_return_pct'))), reverse=True)[:limit]
    return [{
        'setup':r.get('setup'), 'hold_days':r.get('hold_days'), 'trades':r.get('trades'),
        'n_eff':r.get('n_eff'), 'avg_return_pct':r.get('avg_return_pct'), 'winrate_pct':r.get('winrate_pct'),
        'avg_nonoverlap':r.get('avg_nonoverlap'), 'excess_vs_drift':r.get('excess_vs_drift'),
        'evidence_score':r.get('evidence_score'), 'quant_elite':int(r.get('elite',0)),
        'validated_edge':int(r.get('validated_edge',0) or 0), 'usable':int(r.get('usable',0))
    } for r in rows]

def deepseek_analyze(ticker, theme, news, m, cost_rows, setup_context=None, consensus=None, reaction=None, analog=None):
    key=os.getenv('DEEPSEEK_API_KEY','').strip(); use=os.getenv('USE_DEEPSEEK','1')=='1'
    if not key or not use:
        return None
    prompt_path=BASE/'deepseek_prompt.md'
    system=prompt_path.read_text() if prompt_path.exists() else 'Return JSON only.'
    headlines=[{'title':n.get('title',''), 'publisher':n.get('publisher',''), 'published':n.get('published',''), 'age_days':n.get('age_days'), 'link':n.get('link','')} for n in news[:env_int('DEEPSEEK_MAX_HEADLINES',50)]]
    payload={
        'ticker':ticker,
        'theme':theme,
        'market_data':m,
        'quant_setup_context':setup_context or [],
        'news_consensus':consensus or {},
        'price_reaction_context':reaction or {},
        'historical_analog_context':analog or {},
        'headlines':headlines,
        'scoring_rules':'Return all numeric scores on 0-100 scale. If uncertain, use 45-60, not 8/10. ai_final_score is the final catalyst-continuation score. Headlines older than 7 days (age_days) are context, not fresh catalysts.',
        'instruction':'Act as an institutional catalyst analyst. Connect headlines to market reaction, volume, relative strength, theme relevance, priced-in risk, and quant setup evidence. Weight fresh headlines (age_days <= 2) far more than stale ones. Be strict but do not block a confirmed high-quality setup just because it is not perfect. Return JSON only.'
    }
    try:
        res=requests.post('https://api.deepseek.com/chat/completions',headers={'Authorization':f'Bearer {key}','Content-Type':'application/json'},json={
            'model':os.getenv('DEEPSEEK_MODEL','deepseek-chat'),
            'messages':[{'role':'system','content':system},{'role':'user','content':json.dumps(payload, default=str)[:32000]}],
            'temperature':0.12,'max_tokens':env_int('DEEPSEEK_MAX_OUTPUT_TOKENS',4000),'response_format':{'type':'json_object'}
        },timeout=60)
        data=res.json(); content=data['choices'][0]['message']['content']; out=json.loads(content)
        usage=data.get('usage',{}); inp=usage.get('prompt_tokens',0); opt=usage.get('completion_tokens',0)
        cost=inp/1_000_000*env_float('DEEPSEEK_INPUT_USD_PER_M',0.14)+opt/1_000_000*env_float('DEEPSEEK_OUTPUT_USD_PER_M',0.28)
        cost_rows.append(dict(timestamp=datetime.now(timezone.utc).isoformat(),ticker=ticker,input_tokens=inp,output_tokens=opt,estimated_cost_usd=round(cost,6),provider='deepseek'))
        out=normalize_ai_row(out); out['provider']='deepseek'; return out
    except Exception as e:
        cost_rows.append(dict(timestamp=datetime.now(timezone.utc).isoformat(),ticker=ticker,input_tokens=0,output_tokens=0,estimated_cost_usd=0,provider='local_fallback_after_error',error=str(e)[:160]))
        return None

# ---------------- validation (NO AI, NO current news) ----------------
def _business_days_between(a, b):
    try:
        return int(np.busday_count(pd.to_datetime(a).date(), pd.to_datetime(b).date()))
    except Exception:
        try: return max(0, (pd.to_datetime(b) - pd.to_datetime(a)).days)
        except Exception: return 0

def non_overlap_returns(trade_rows, hold_days):
    rows=[]
    for r in trade_rows:
        try:
            rr=float(r.get('return_pct',0)); ed=r.get('entry_date') or r.get('signal_date')
            if ed: rows.append((pd.to_datetime(ed).date().isoformat(), rr, r))
        except Exception:
            continue
    rows=sorted(rows, key=lambda x:x[0])
    kept=[]; last=None
    for d,ret,row in rows:
        if last is None or _business_days_between(last, d) >= int(hold_days or 1):
            kept.append(ret); last=d
    return kept

def bootstrap_ci(vals, level=0.90, seed=190, reps=700):
    vals=[float(v) for v in vals if pd.notna(v)]
    n=len(vals)
    if n==0: return (0.0,0.0)
    if n==1: return (round(vals[0],3), round(vals[0],3))
    rng=np.random.default_rng(seed+n)
    arr=np.array(vals, dtype=float)
    means=[float(np.mean(rng.choice(arr, size=n, replace=True))) for _ in range(reps)]
    lo=(1-level)/2; hi=1-lo
    return (round(float(np.quantile(means,lo)),3), round(float(np.quantile(means,hi)),3))

def unconditional_drift(df, h):
    """TRUE baseline: mean h-day return of the ticker itself over the whole
    eligible sample window, with the same next-open execution and cost as the
    setups. v1.9.x compared setups against other setups of the same ticker,
    which made excess artificially ~0 because the engines overlap heavily."""
    try:
        close=df['Close']; openp=df['Open'] if 'Open' in df else df['Close']
        n=len(df)
        if n<60+h+2: return 0.0
        entries=openp.shift(-1).iloc[60:n-h-1]
        exits=close.shift(-h).iloc[60:n-h-1]
        rets=(exits.values/np.where(entries.values>0,entries.values,np.nan)-1)*100 - TRADE_COST_PCT
        rets=rets[~np.isnan(rets)]
        return round(float(np.mean(rets)),3) if len(rets) else 0.0
    except Exception:
        return 0.0

def build_validation_tables(summary, trades, price_data=None):
    price_data=price_data or {}
    by_cell={}
    for tr in trades:
        key=(tr.get('ticker'), tr.get('setup'), int(tr.get('hold_days',0) or 0))
        by_cell.setdefault(key,[]).append(tr)
    drift_cache={}
    validation=[]; excess_rows=[]; val_map={}
    for r in summary:
        t=r.get('ticker'); setup=r.get('setup'); h=int(r.get('hold_days',0) or 0)
        key=(t,setup,h); cell=by_cell.get(key,[])
        no=non_overlap_returns(cell,h)
        n_orig=len(cell); n_eff=len(no)
        avg_no=round(float(np.mean(no)),3) if no else 0.0
        win_no=round(float(np.mean([x>0 for x in no])*100),2) if no else 0.0
        dk=(t,h)
        if dk not in drift_cache:
            drift_cache[dk]=unconditional_drift(price_data.get(t), h) if price_data.get(t) is not None else 0.0
        drift=drift_cache[dk]
        excess=round(avg_no-drift,3)
        ci_low,ci_high=bootstrap_ci(no, seed=190+h+n_orig)
        excess_ci_low=round(ci_low-drift,3); excess_ci_high=round(ci_high-drift,3)
        overlap_ratio=round(1-(n_eff/max(1,n_orig)),3)
        ci_positive=int(n_eff>=8 and ci_low>0)
        excess_positive=int(excess>0.5)
        # v2.0.0 core rule: validated edge means the setup beats the ticker's
        # own drift with statistical support, not just "goes up".
        validated_edge=int(n_eff>=10 and excess_ci_low>0 and excess>0.5)
        overlap_risk='HIGH' if overlap_ratio>=0.75 else 'MEDIUM' if overlap_ratio>=0.45 else 'LOW'
        n_component = min(22.0, max(0.0, n_eff) * 0.85)
        excess_component = max(-18.0, min(24.0, excess * 3.0))
        ci_component = max(-18.0, min(20.0, excess_ci_low * 2.0))
        avg_component = max(-10.0, min(12.0, avg_no * 0.9))
        quality_penalty = 0.0
        if n_eff < 10: quality_penalty += 14.0
        if overlap_ratio >= 0.75: quality_penalty += 8.0
        if excess <= 0: quality_penalty += 10.0
        if excess_ci_low <= 0: quality_penalty += 8.0
        val_score=max(0,min(100, 35.0 + n_component + excess_component + ci_component + avg_component - quality_penalty))
        # Honest quant-evidence score: exclusively historical, exclusively n_eff.
        evidence=clamp100(35 + avg_no*2.5 + (win_no-50)*0.7 + min(n_eff,40)*1.0 + excess*2.5)
        quant_elite=int(n_eff>=12 and avg_no>2.5 and win_no>=55 and excess>0.5)
        good=int(n_eff>=8 and avg_no>1.5 and excess>0)
        usable=int(n_eff>=8 and avg_no>0)
        edge_grade = 'A' if validated_edge and val_score>=78 else 'B' if validated_edge and val_score>=65 else 'C' if validated_edge else 'WATCH' if excess>0 and n_eff>=8 else 'NO_EDGE'
        row=dict(ticker=t,theme=r.get('theme',''),setup=setup,hold_days=h,n_orig=n_orig,n_eff=n_eff,overlap_ratio=overlap_ratio,overlap_risk=overlap_risk,avg_orig=float(r.get('avg_return_pct',0) or 0),avg_nonoverlap=avg_no,winrate_nonoverlap=win_no,ci90_low=ci_low,ci90_high=ci_high,ticker_drift_unconditional=drift,excess_vs_drift=excess,excess_ci90_low=excess_ci_low,excess_ci90_high=excess_ci_high,ci_positive=ci_positive,excess_positive=excess_positive,validated_edge=validated_edge,validation_score=round(val_score,2),evidence_score=evidence,quant_elite=quant_elite,good_candidate=good,usable=usable,edge_grade=edge_grade,validation_mode='NO_AI_NEXT_OPEN_ENTRY_TRUE_DRIFT_EXCESS_CI_v2_0_0')
        validation.append(row)
        excess_rows.append({k:row[k] for k in ['ticker','theme','setup','hold_days','n_eff','avg_nonoverlap','ticker_drift_unconditional','excess_vs_drift','excess_ci90_low','validated_edge','validation_score']})
        val_map[key]=row
    return validation, excess_rows, val_map

def apply_validation_to_summary(summary, val_map):
    for r in summary:
        key=(r.get('ticker'), r.get('setup'), int(r.get('hold_days',0) or 0))
        v=val_map.get(key,{})
        for k in ['n_eff','overlap_ratio','overlap_risk','avg_nonoverlap','winrate_nonoverlap','ci90_low','ci90_high','ticker_drift_unconditional','excess_vs_drift','excess_ci90_low','excess_ci90_high','validated_edge','validation_score','edge_grade']:
            r[k]=v.get(k,0 if k!='overlap_risk' else '')
        # v2.0.0: quant quality fields now come FROM the validation layer
        # (n_eff-based, no snapshot leakage, no theme bonus).
        r['evidence_score']=v.get('evidence_score',0)
        r['elite']=int(v.get('quant_elite',0))
        r['good_candidate']=int(v.get('good_candidate',0))
        r['usable']=int(v.get('usable',0))
    return summary

def apply_final_ranking(summary, ai_rows):
    ai_map={r['ticker']:normalize_ai_row(r) for r in ai_rows}
    for r in summary:
        old_quant_elite=int(r.get('elite',0))
        ai=ai_map.get(r['ticker'],{})
        ai_score=safe_float(ai.get('ai_final_score') or ai.get('final_score'),0) if ai else 0
        materiality=safe_float(ai.get('materiality'),0) if ai else 0
        market_conf=safe_float(ai.get('market_confirmation'),0) if ai else 0
        priced_risk=safe_float(ai.get('priced_in_risk'),50) if ai else 50
        quant_score=clamp100(r.get('evidence_score'))
        validation_score=clamp100(r.get('validation_score'))
        validated_edge=int(r.get('validated_edge',0) or 0)
        live_attention_score=round(quant_score*0.22 + ai_score*0.32 + materiality*0.16 + market_conf*0.16 - max(0, priced_risk-65)*0.30,2)
        validated_edge_score=round(validation_score,2)
        validation_support = 1.0 if validated_edge else 0.55 if validation_score>=55 and safe_float(r.get('excess_vs_drift'))>0 else 0.25
        hybrid_signal_score=round((live_attention_score*0.50 + validated_edge_score*0.50) * validation_support,2)
        tier=ai_tier(ai_score)
        live_elite = bool(old_quant_elite and ai_score>=70 and live_attention_score>=70)
        live_extreme = bool(old_quant_elite and ai_score>=80 and materiality>=80 and market_conf>=75 and live_attention_score>=78)
        hybrid_watchlist = bool(live_attention_score>=68 and validated_edge and validation_score>=58)
        validation_warning=[]
        if str(r.get('overlap_risk',''))=='HIGH': validation_warning.append('HIGH_OVERLAP')
        if int(r.get('n_eff',0) or 0)<10: validation_warning.append('LOW_EFFECTIVE_N')
        if safe_float(r.get('excess_vs_drift'))<=0: validation_warning.append('NO_EXCESS_VS_DRIFT')
        if priced_risk>=75: validation_warning.append('HIGH_PRICED_IN_RISK')
        if not validated_edge: validation_warning.append('NOT_VALIDATED_EDGE')
        r['quant_elite']=old_quant_elite
        r['ai_final_score']=ai_score
        r['ai_tier']=tier
        r['ai_conviction']=ai.get('conviction','') if ai else ''
        r['ai_good']=int(ai_score>=55)
        r['ai_high']=int(ai_score>=70)
        r['ai_elite']=int(ai_score>=80)
        r['ai_extreme']=int(ai_score>=90)
        r['materiality']=materiality
        r['market_confirmation']=market_conf
        r['priced_in_risk']=priced_risk
        r['live_attention_score']=live_attention_score
        r['validated_edge_score']=validated_edge_score
        r['hybrid_signal_score']=hybrid_signal_score
        r['combined_score']=hybrid_signal_score
        r['final_score']=hybrid_signal_score
        r['live_elite']=int(live_elite)
        r['live_extreme']=int(live_extreme)
        r['final_elite']=int(live_elite)
        r['hybrid_watchlist']=int(hybrid_watchlist)
        r['final_extreme']=int(live_extreme and validated_edge and validation_score>=70)
        r['elite']=int(hybrid_watchlist or (live_extreme and validated_edge))
        r['validation_warning']=';'.join(validation_warning)
        r['signal_claim']='LIVE_ATTENTION_NOT_BACKTEST_PROOF' if live_elite else 'RESEARCH_ONLY'
        r['good_candidate']=1 if (int(r.get('good_candidate',0)) or ai_score>=55 or hybrid_signal_score>=55 or validated_edge) else 0
    return summary

# ---------------- forward tracking (v2.1.0) ----------------
FORWARD_LOG=DATA_CACHE/'forward_log.csv'  # persistent: survives version bumps
FWD_HORIZONS=(1,3,5,10)

def _read_forward_log():
    try:
        with FORWARD_LOG.open(encoding='utf-8') as f:
            return [dict(r) for r in csv.DictReader(f)]
    except Exception:
        return []

def _write_forward_log(rows):
    if not rows: return
    keys=sorted(set().union(*[r.keys() for r in rows]))
    tmp=FORWARD_LOG.with_suffix('.tmp')
    with tmp.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=keys); w.writeheader(); w.writerows(rows)
    tmp.replace(FORWARD_LOG)

def _fwd_tier(r):
    if int(r.get('final_extreme',0) or 0): return 'FINAL_EXTREME'
    if int(r.get('hybrid_watchlist',0) or 0): return 'HYBRID_WATCHLIST'
    if int(r.get('validated_edge',0) or 0): return 'VALIDATED_ACTIVE'
    if int(r.get('live_extreme',0) or 0): return 'LIVE_EXTREME'
    if int(r.get('live_elite',0) or 0): return 'LIVE_ELITE'
    if safe_float(r.get('live_attention_score'))>=env_float('NTFY_LIVE_MIN_ATTENTION',75) and int(r.get('ai_high',0) or 0): return 'LIVE_HIGH'
    return ''

def update_forward_tracking(summary, price_data, bench=None):
    """The only hindsight-free validation there is:
    1. LOG today's actionable signals (setup condition true on the last bar,
       AND the cell is validated or a live alert tier).
    2. FILL realized returns for older log entries once enough bars exist:
       entry = next-day Open after signal, exit = Close at +1/3/5/10 bars,
       minus TRADE_COST_PCT, plus excess vs QQQ over the identical window.
    The log lives in the persistent data cache and is append-only."""
    rows=_read_forward_log()
    seen={(r.get('signal_date'),r.get('ticker'),r.get('setup'),str(r.get('hold_days'))) for r in rows}
    # -- 1. append today's actionable signals --
    validated_active=[r for r in summary if int(r.get('signal_active_today',0) or 0) and int(r.get('validated_edge',0) or 0)]
    live_best={}
    for r in summary:
        if not int(r.get('signal_active_today',0) or 0): continue
        tier=_fwd_tier(r)
        if tier in ('','VALIDATED_ACTIVE'): continue
        t=r.get('ticker'); cur=live_best.get(t)
        if cur is None or safe_float(r.get('hybrid_signal_score'))>safe_float(cur.get('hybrid_signal_score')):
            live_best[t]=r
    new=0
    for r in list(validated_active)+list(live_best.values()):
        t=r.get('ticker'); df=price_data.get(t)
        if df is None or not len(df): continue
        sig=str(df.index[-1].date())
        key=(sig,t,r.get('setup'),str(r.get('hold_days')))
        if key in seen: continue
        entry=dict(signal_date=sig,ticker=t,theme=r.get('theme',''),setup=r.get('setup'),hold_days=r.get('hold_days'),
                   tier=_fwd_tier(r),signal_close=round(safe_float(df['Close'].iloc[-1]),4),
                   live_attention=safe_float(r.get('live_attention_score')),validation_score=safe_float(r.get('validation_score')),
                   ai_score=safe_float(r.get('ai_final_score')),hist_excess=safe_float(r.get('excess_vs_drift')),
                   hist_n_eff=r.get('n_eff',''),logged_at=datetime.now(timezone.utc).isoformat(),engine_version=VERSION,
                   entry_date='',entry_open='')
        for h in FWD_HORIZONS:
            entry[f'ret_{h}d']=''; entry[f'exs_qqq_{h}d']=''
        rows.append(entry); seen.add(key); new+=1
    # -- 2. fill realized returns where bars now exist --
    bmap={}
    if bench is not None and len(bench):
        bdates=[d.date().isoformat() for d in bench.index]
        bmap={d:j for j,d in enumerate(bdates)}
    filled=0
    for row in rows:
        t=row.get('ticker'); df=price_data.get(t)
        if df is None or not len(df): continue
        dates=[d.date().isoformat() for d in df.index]
        dmap={d:i for i,d in enumerate(dates)}
        i=dmap.get(row.get('signal_date'))
        if i is None or i+1>=len(df): continue
        openp=df['Open'] if 'Open' in df else df['Close']
        e=safe_float(openp.iloc[i+1])
        if e<=0: e=safe_float(df['Close'].iloc[i+1])
        if e<=0: continue
        row['entry_open']=round(e,4); row['entry_date']=dates[i+1]
        j=bmap.get(row.get('signal_date'))
        for h in FWD_HORIZONS:
            k=f'ret_{h}d'
            if str(row.get(k,'')).strip()!='': continue
            if i+h>=len(df): continue
            r_=(safe_float(df['Close'].iloc[i+h])/e-1)*100 - TRADE_COST_PCT
            row[k]=round(r_,3); filled+=1
            if j is not None and j+1<len(bench) and j+h<len(bench):
                bo=bench['Open'] if 'Open' in bench else bench['Close']
                be=safe_float(bo.iloc[j+1])
                if be>0:
                    br=(safe_float(bench['Close'].iloc[j+h])/be-1)*100
                    row[f'exs_qqq_{h}d']=round(r_-br,3)
    # -- 3. per-tier + overall performance --
    perf=[]
    tiers=sorted({r.get('tier') for r in rows if r.get('tier')})
    for tier in tiers+['ALL']:
        sel=[r for r in rows if tier=='ALL' or r.get('tier')==tier]
        rec=dict(tier=tier,signals_logged=len(sel))
        for h in FWD_HORIZONS:
            vals=[safe_float(r.get(f'ret_{h}d')) for r in sel if str(r.get(f'ret_{h}d','')).strip()!='']
            exs=[safe_float(r.get(f'exs_qqq_{h}d')) for r in sel if str(r.get(f'exs_qqq_{h}d','')).strip()!='']
            rec[f'n_{h}d']=len(vals)
            rec[f'avg_{h}d']=round(float(np.mean(vals)),3) if vals else ''
            rec[f'win_{h}d']=round(float(np.mean([v>0 for v in vals])*100),1) if vals else ''
            rec[f'avg_exs_qqq_{h}d']=round(float(np.mean(exs)),3) if exs else ''
        perf.append(rec)
    _write_forward_log(rows)
    print(f'[FWD] forward log: {len(rows)} totaal, {new} nieuw gelogd, {filled} rendementen ingevuld')
    rows_sorted=sorted(rows, key=lambda r: str(r.get('signal_date','')), reverse=True)
    return rows_sorted, perf


def _json_cache_path(kind, key):
    safe=''.join(ch if ch.isalnum() or ch in ('-','_','.') else '_' for ch in str(key).upper())
    return DATA_CACHE/kind/f'{safe}.json'

def _read_json_cache(kind, key, max_age_hours=24):
    p=_json_cache_path(kind,key)
    if not p.exists(): return None
    try:
        age=(time.time()-p.stat().st_mtime)/3600
        if age>float(max_age_hours): return None
        return json.loads(p.read_text(encoding='utf-8'))
    except Exception: return None

def _write_json_cache(kind, key, obj):
    try:
        p=_json_cache_path(kind,key)
        p.write_text(json.dumps(obj, indent=2, default=str), encoding='utf-8')
    except Exception: pass

def get_ticker_metadata(ticker):
    cached=_read_json_cache('metadata_cache', ticker, env_int('SEE_METADATA_CACHE_HOURS',24))
    if cached: return cached
    import yfinance as yf
    info={}
    try:
        raw=yf.Ticker(ticker).info or {}
        keep=['symbol','shortName','longName','quoteType','exchange','currency','marketCap','enterpriseValue','sector','industry','website','longBusinessSummary','floatShares','sharesOutstanding','averageVolume','averageVolume10days','volume','fiftyTwoWeekHigh','fiftyTwoWeekLow','fiftyDayAverage','twoHundredDayAverage','beta','trailingPE','forwardPE','priceToSalesTrailing12Months','profitMargins','revenueGrowth','earningsGrowth','totalCash','totalDebt','debtToEquity','currentPrice','targetMeanPrice','recommendationKey','numberOfAnalystOpinions']
        info={k:raw.get(k) for k in keep if k in raw}
        info['cached_at']=datetime.now(timezone.utc).isoformat()
    except Exception as e:
        info={'symbol':ticker,'error':str(e)[:200],'cached_at':datetime.now(timezone.utc).isoformat()}
    _write_json_cache('metadata_cache', ticker, info)
    return info

_RISK_PHRASES=['offering','dilution','reverse split','warrant','shelf','going concern','delisting','nasdaq notice','bankruptcy','atm offering']
_RISK_RE={w:re.compile(r'\b'+re.escape(w)+r'\b') for w in _RISK_PHRASES}

def score_lowcap_risk(info, m, news):
    mc=safe_float(info.get('marketCap'),0)
    vol=safe_float(info.get('averageVolume') or info.get('volume'),0)
    qtype=str(info.get('quoteType') or '').upper()
    text=' '.join([x.get('title','') for x in news]).lower()
    risk=0
    if mc and mc<300_000_000: risk+=35
    elif mc and mc<1_000_000_000: risk+=20
    if vol and vol<500_000: risk+=15
    if qtype not in ('EQUITY','ETF') and qtype: risk+=15
    if m.get('relative_volume',1)>4: risk+=10
    risk+=sum(12 for w in _RISK_PHRASES if _RISK_RE[w].search(text))
    return round(max(0,min(100,risk)),2)

def deepseek_stock_lab(ticker, info, m, news, lowcap_risk, cost_rows):
    key=os.getenv('DEEPSEEK_API_KEY','').strip(); use=os.getenv('USE_DEEPSEEK','1')=='1'
    if not key or not use: return None
    system="""You are SEE Stock Search Lab, an institutional single-stock intelligence analyst. Analyze ONE Yahoo ticker at a time. This is NOT the broad screener. Be especially strict for low caps, new listings, meme stocks, biotech binary events, SPAC-like names, crypto-linked equities and illiquid names. Return JSON only. Numeric scores must be 0-100. Do not hype. Separate attention from investability. Flag priced-in moves, dilution, reverse split, offering, liquidity and pump risk. Weight fresh headlines (age_days <= 2) far more than stale ones. Include concrete triggers that would make the stock elite."""
    payload={
        'ticker':ticker,
        'metadata':info,
        'market_data':m,
        'lowcap_risk_proxy':lowcap_risk,
        'headlines':[{'title':n.get('title',''), 'publisher':n.get('publisher',''), 'published':n.get('published',''), 'age_days':n.get('age_days'), 'link':n.get('link','')} for n in news[:env_int('DEEPSEEK_STOCK_LAB_MAX_HEADLINES',40)]],
        'required_output_fields':['company_summary','event_type','narrative','opportunity_score','catalyst_strength','risk_score','priced_in_risk','lowcap_danger_score','quality_score','tradeability_score','grade','bull_case','bear_case','key_risks','what_would_make_this_elite','concrete_triggers','reasoning']
    }
    try:
        res=requests.post('https://api.deepseek.com/chat/completions',headers={'Authorization':f'Bearer {key}','Content-Type':'application/json'},json={
            'model':os.getenv('DEEPSEEK_MODEL','deepseek-chat'),
            'messages':[{'role':'system','content':system},{'role':'user','content':json.dumps(payload, default=str)[:32000]}],
            'temperature':0.10,'max_tokens':env_int('DEEPSEEK_STOCK_LAB_MAX_OUTPUT_TOKENS',3500),'response_format':{'type':'json_object'}
        },timeout=75)
        data=res.json(); content=data['choices'][0]['message']['content']; out=json.loads(content)
        usage=data.get('usage',{}); inp=usage.get('prompt_tokens',0); opt=usage.get('completion_tokens',0)
        cost=inp/1_000_000*env_float('DEEPSEEK_INPUT_USD_PER_M',0.14)+opt/1_000_000*env_float('DEEPSEEK_OUTPUT_USD_PER_M',0.28)
        cost_rows.append(dict(timestamp=datetime.now(timezone.utc).isoformat(),ticker=ticker,input_tokens=inp,output_tokens=opt,estimated_cost_usd=round(cost,6),provider='deepseek_stock_lab'))
        lab_fields=['opportunity_score','catalyst_strength','risk_score','priced_in_risk','lowcap_danger_score','quality_score','tradeability_score']
        vals=[safe_float(out.get(k)) for k in lab_fields if out.get(k) not in (None,'')]
        scale=bool(vals) and all(0<=v<=10 for v in vals) and any(v>0 for v in vals)
        for k in lab_fields:
            out[k]=normalize_score(out.get(k),0,scale_0_10=scale)
        return out
    except Exception as e:
        cost_rows.append(dict(timestamp=datetime.now(timezone.utc).isoformat(),ticker=ticker,input_tokens=0,output_tokens=0,estimated_cost_usd=0,provider='stock_lab_error',error=str(e)[:200]))
        return None

def analyze_single_stock(ticker, period='1y', fresh=False):
    ticker=str(ticker or '').strip().upper()
    if not ticker: raise ValueError('empty ticker')
    if not re.fullmatch(r'[A-Z0-9.\-\^=]{1,12}', ticker): raise ValueError('invalid ticker format')
    if not fresh:
        cached=_read_json_cache('stock_lab', ticker, env_float('SEE_STOCK_LAB_CACHE_HOURS',2))
        if cached:
            cached['from_cache']=True
            return cached
    cost_rows=[]
    data=fetch_hist([ticker], period)
    if ticker not in data: raise RuntimeError(f'No Yahoo price data for {ticker}')
    bench=fetch_hist(['QQQ'], period).get('QQQ')
    df=data[ticker]; m=metrics_for(df, bench)
    info=get_ticker_metadata(ticker)
    news=get_news(ticker, env_int('DEEPSEEK_STOCK_LAB_MAX_HEADLINES',40))
    cat,react=local_event_score(ticker, news, m)
    lowrisk=score_lowcap_risk(info, m, news)
    ai=deepseek_stock_lab(ticker, info, m, news, lowrisk, cost_rows)
    if not ai:
        q=safe_float(info.get('marketCap'),0)
        risk=max(lowrisk, 70 if q and q<300_000_000 else 40)
        opp=clamp100(m['technical_score']*.35 + cat*.25 + react*.25 - risk*.15)
        ai={'company_summary':info.get('longName') or info.get('shortName') or ticker,'event_type':'local_single_stock_analysis','narrative':'Local fallback analysis using Yahoo market data, metadata, headlines and risk proxies.','opportunity_score':round(opp,2),'catalyst_strength':round(cat,2),'risk_score':round(risk,2),'priced_in_risk':clamp100(50+m['ret3']*3),'lowcap_danger_score':lowrisk,'quality_score':clamp100(100-risk),'tradeability_score':clamp100(50+(m['relative_volume']-1)*10 + (10 if safe_float(info.get('averageVolume'))>1_000_000 else 0)),'grade':'B' if opp>=70 and risk<60 else 'C' if opp>=55 else 'D','bull_case':['Strong recent technical score or catalyst proxy.'],'bear_case':['Fallback mode: no DeepSeek judgement available. Verify news manually.'],'key_risks':['Low liquidity/dilution/priced-in risk must be checked.'],'what_would_make_this_elite':'Fresh material catalyst, improving volume quality, lower priced-in risk, and confirmed follow-through above key levels.','concrete_triggers':['Breakout with sustained volume','Material news not already priced in','Risk score below 50'],'reasoning':'Local fallback only.'}
    result={'version':VERSION,'mode':'stock_search_lab','ticker':ticker,'generated_at':datetime.now(timezone.utc).isoformat(),'from_cache':False,'metadata':info,'market_data':m,'news':news,'local_scores':{'catalyst_proxy':cat,'price_reaction_proxy':react,'lowcap_risk_proxy':lowrisk},'analysis':ai,'cost_rows':cost_rows,'cache_base':str(DATA_CACHE)}
    _write_json_cache('stock_lab', ticker, result)
    if cost_rows:
        try:
            existing=[]; p=OUT/f'see_stock_lab_costs_{VERSION}.csv'
            if p.exists():
                with p.open(encoding='utf-8') as f: existing=list(csv.DictReader(f))
            write_csv(f'see_stock_lab_costs_{VERSION}.csv', existing+cost_rows)
        except Exception: pass
    return result

# ---------------- main scan ----------------
def run(tickers, period):
    bench=fetch_hist(['QQQ'],period).get('QQQ')
    data=fetch_hist(tickers,period)
    summary=[]; trades=[]; news_items=[]; ai_rows=[]; reaction_rows=[]; consensus_rows=[]; analog_rows=[]; cost_rows=[]
    metrics={}
    for t,df in data.items(): metrics[t]=metrics_for(df,bench)
    shortlist=sorted(metrics.keys(), key=lambda t: metrics[t]['technical_score'] + abs(metrics[t]['ret3'])*1.5 + (12 if t in SPECIAL else 0), reverse=True)[:env_int('DEEPSEEK_MAX_TICKERS',30)]
    for t,df in data.items():
        rows,tr=setup_rows(t,df,metrics[t]); summary+=rows; trades+=tr
    validation_rows, excess_rows, val_map = build_validation_tables(summary, trades, price_data=data)
    summary = apply_validation_to_summary(summary, val_map)
    for t in shortlist:
        news=get_news(t, env_int('DEEPSEEK_MAX_HEADLINES',50)); news_items += news
        cat,react=local_event_score(t,news,metrics[t])
        consensus=dict(ticker=t,headline_count=len(news),fresh_headline_count=sum(1 for n in news if (n.get('age_days') is not None and n['age_days']<=2)),consensus_score=cat,theme=SPECIAL.get(t,'GENERAL'),headline_titles=' | '.join([n.get('title','') for n in news[:8]]))
        reaction=dict(ticker=t,price_reaction_score=react,ret1=metrics[t]['ret1'],ret3=metrics[t]['ret3'],ret20=metrics[t]['ret20'],relative_volume=metrics[t]['relative_volume'],rs_vs_bench=metrics[t]['rs_vs_bench'],position_52w=metrics[t]['position_52w'],above_ma20=metrics[t]['above_ma20'],above_ma50=metrics[t]['above_ma50'])
        analog=dict(ticker=t,closest_analog_theme=SPECIAL.get(t,'GENERAL'),analog_quality=round((cat+react)/2,2),expected_3d=round((cat+react)/22,2),expected_10d=round((cat+react)/14,2))
        consensus_rows.append(consensus); reaction_rows.append(reaction); analog_rows.append(analog)
        setup_ctx=summarize_setups_for_ticker(summary,t,limit=8)
        ai=deepseek_analyze(t,SPECIAL.get(t,'GENERAL'),news,metrics[t],cost_rows,setup_ctx,consensus,reaction,analog)
        if not ai:
            fs=round(cat*.35+react*.35+metrics[t]['technical_score']*.20+(10 if any(x.get('quant_elite') for x in setup_ctx) else 0),2)
            conv='EXTREME' if fs>=90 else 'ELITE' if fs>=80 else 'HIGH' if fs>=70 else 'GOOD' if fs>=55 else 'WATCH'
            ai=dict(ticker=t,event_type='local_catalyst',event_quality=conv,materiality=cat,market_confirmation=react,continuation_3d=min(95,fs),continuation_10d=max(0,min(95,fs-7)),ai_final_score=fs,final_score=fs,conviction=conv,reasoning='Local fallback: catalyst proxy linked with price reaction, relative strength, volume and quant setup context.',provider='local_fallback')
        ai=normalize_ai_row(ai); ai['ticker']=t; ai['theme']=SPECIAL.get(t,'GENERAL'); ai['quant_setup_count']=len(setup_ctx); ai_rows.append(ai)
    summary=apply_final_ranking(summary, ai_rows)
    fwd_rows,fwd_perf=update_forward_tracking(summary, data, bench)
    write_outputs(summary,trades,news_items,ai_rows,reaction_rows,consensus_rows,analog_rows,cost_rows,validation_rows,excess_rows,fwd_rows,fwd_perf)
    send_ntfy(summary, ai_rows, data)
    print(f"Done. trades={len(trades)} summary_rows={len(summary)} live_elite={sum(int(r.get('live_elite',0)) for r in summary)} validated_edges={sum(int(r.get('validated_edge',0)) for r in summary)} final_extreme={sum(int(r.get('final_extreme',0)) for r in summary)} ai_high={sum(1 for r in ai_rows if safe_float(r.get('ai_final_score'))>=70)} ai_elite={sum(1 for r in ai_rows if safe_float(r.get('ai_final_score'))>=80)} quant_elite={sum(int(r.get('quant_elite',0)) for r in summary)} deepseek_rows={len(ai_rows)}")

def write_csv(name, rows):
    p=OUT/name
    if not rows:
        p.write_text('empty\n'); return
    keys=sorted(set().union(*[r.keys() for r in rows]))
    with p.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=keys); w.writeheader(); w.writerows(rows)

def write_outputs(summary,trades,news,ai,reaction,consensus,analog,cost,validation_rows=None,excess_rows=None,fwd_rows=None,fwd_perf=None):
    write_csv(f'see_summary_{VERSION}.csv',summary); write_csv(f'see_trades_{VERSION}.csv',trades)
    write_csv(f'see_elite_{VERSION}.csv',[r for r in summary if int(r.get('elite',0))])
    write_csv(f'see_final_elite_{VERSION}.csv',[r for r in summary if int(r.get('final_elite',0))])
    write_csv(f'see_final_extreme_{VERSION}.csv',[r for r in summary if int(r.get('final_extreme',0))])
    write_csv(f'see_ai_elite_{VERSION}.csv',[r for r in summary if int(r.get('ai_elite',0)) or int(r.get('ai_extreme',0))])
    write_csv(f'see_ai_high_{VERSION}.csv',[r for r in summary if int(r.get('ai_high',0))])
    write_csv(f'see_quant_elite_{VERSION}.csv',[r for r in summary if int(r.get('quant_elite',0))])
    write_csv(f'see_usable_{VERSION}.csv',[r for r in summary if int(r.get('usable',0))])
    write_csv(f'see_validation_overlap_{VERSION}.csv', validation_rows or [])
    write_csv(f'see_forward_log_{VERSION}.csv', fwd_rows or [])
    write_csv(f'see_forward_performance_{VERSION}.csv', fwd_perf or [])
    write_csv(f'see_excess_vs_drift_{VERSION}.csv', excess_rows or [])
    write_csv(f'see_validated_setups_{VERSION}.csv',[r for r in summary if int(r.get('validated_edge',0))])
    write_csv(f'see_live_signals_{VERSION}.csv',[r for r in summary if int(r.get('live_elite',0)) or int(r.get('live_extreme',0))])
    best_live_by_ticker={}; best_val_by_ticker={}; best_hybrid_by_ticker={}
    for r in summary:
        t=r.get('ticker')
        if not t: continue
        if int(r.get('live_elite',0)) or int(r.get('live_extreme',0)):
            cur=best_live_by_ticker.get(t)
            if cur is None or safe_float(r.get('live_attention_score'))>safe_float(cur.get('live_attention_score')): best_live_by_ticker[t]=r
        if int(r.get('validated_edge',0)):
            cur=best_val_by_ticker.get(t)
            if cur is None or safe_float(r.get('validation_score'))>safe_float(cur.get('validation_score')): best_val_by_ticker[t]=r
        if int(r.get('hybrid_watchlist',0)):
            cur=best_hybrid_by_ticker.get(t)
            if cur is None or safe_float(r.get('hybrid_signal_score'))>safe_float(cur.get('hybrid_signal_score')): best_hybrid_by_ticker[t]=r
    write_csv(f'see_live_signals_by_ticker_{VERSION}.csv', sorted(best_live_by_ticker.values(), key=lambda r: safe_float(r.get('live_attention_score')), reverse=True))
    write_csv(f'see_validated_setups_by_ticker_{VERSION}.csv', sorted(best_val_by_ticker.values(), key=lambda r: safe_float(r.get('validation_score')), reverse=True))
    write_csv(f'see_hybrid_watchlist_{VERSION}.csv', sorted(best_hybrid_by_ticker.values(), key=lambda r: safe_float(r.get('hybrid_signal_score')), reverse=True))
    df=pd.DataFrame(summary) if summary else pd.DataFrame()
    by_setup=[]
    if not df.empty:
        for s,g in df.groupby('setup'):
            by_setup.append(dict(setup=s,rows=len(g),trades=int(g['trades'].sum()),quant_elite=int(g['quant_elite'].sum()),live_elite=int(g['live_elite'].sum()),validated_edges=int(g['validated_edge'].sum()),final_extreme=int(g['final_extreme'].sum()),avg_expectancy=round(g['avg_return_pct'].mean(),3),avg_nonoverlap=round(g['avg_nonoverlap'].mean(),3),avg_excess_vs_drift=round(g['excess_vs_drift'].mean(),3),avg_live_attention=round(g['live_attention_score'].mean(),2),avg_validation_score=round(g['validation_score'].mean(),2)))
    by_ticker=[]
    if not df.empty:
        for s,g in df.groupby('ticker'):
            by_ticker.append(dict(ticker=s,theme=SPECIAL.get(s,'GENERAL'),rows=len(g),trades=int(g['trades'].sum()),quant_elite=int(g['quant_elite'].sum()),live_elite=int(g['live_elite'].sum()),validated_edges=int(g['validated_edge'].sum()),final_extreme=int(g['final_extreme'].sum()),avg_expectancy=round(g['avg_return_pct'].mean(),3),avg_excess_vs_drift=round(g['excess_vs_drift'].mean(),3),max_live_attention=round(g['live_attention_score'].max(),2),max_validation_score=round(g['validation_score'].max(),2),max_ai_score=round(g['ai_final_score'].max(),2)))
    write_csv(f'see_by_setup_{VERSION}.csv',by_setup); write_csv(f'see_by_ticker_{VERSION}.csv',by_ticker)
    write_csv(f'see_news_items_{VERSION}.csv',news); write_csv(f'see_ai_analyst_{VERSION}.csv',ai)
    write_csv(f'see_price_reaction_{VERSION}.csv',reaction); write_csv(f'see_news_consensus_{VERSION}.csv',consensus); write_csv(f'see_historical_analog_memory_{VERSION}.csv',analog); write_csv(f'see_deepseek_costs_{VERSION}.csv',cost)
    health_rows=[]
    try:
        health=json.loads(HEALTH_FILE.read_text())
        health_rows=[dict(ticker=k, **v) for k,v in health.items()]
    except Exception: pass
    write_csv(f'see_ticker_health_{VERSION}.csv',health_rows)
    total_cost=sum(float(r.get('estimated_cost_usd',0) or 0) for r in cost); scans=env_int('DEEPSEEK_SCANS_PER_DAY',4)
    ai_scores=[safe_float(r.get('ai_final_score'),0) for r in ai]
    cells_tested=len(validation_rows or [])
    monitor=[dict(version=VERSION,run_cost_usd=round(total_cost,6),monthly_estimate_usd=round(total_cost*scans*30,4),budget_usd=env_float('DEEPSEEK_MONTHLY_BUDGET_USD',5),deepseek_rows=len(ai),ai_good=sum(1 for s in ai_scores if s>=55),ai_high=sum(1 for s in ai_scores if s>=70),ai_elite=sum(1 for s in ai_scores if s>=80),ai_extreme=sum(1 for s in ai_scores if s>=90),usable=sum(int(r.get('usable',0)) for r in summary),quant_elite=sum(int(r.get('quant_elite',0)) for r in summary),live_elite=sum(int(r.get('live_elite',0)) for r in summary),live_elite_tickers=len(best_live_by_ticker),validated_edges=sum(int(r.get('validated_edge',0)) for r in summary),validated_edge_tickers=len(best_val_by_ticker),hybrid_watchlist=sum(int(r.get('hybrid_watchlist',0)) for r in summary),hybrid_watchlist_tickers=len(best_hybrid_by_ticker),final_elite=sum(int(r.get('final_elite',0)) for r in summary),final_extreme=sum(int(r.get('final_extreme',0)) for r in summary),validation_cells_tested=cells_tested,multiple_testing_note='with ~2000 cells expect some false positives at 90pct CI; treat single-cell validated edges as candidates, not proof',validation_mode='v2_0_0_next_open_entry_true_drift_excess_ci',generated_at=datetime.now(timezone.utc).isoformat())]
    write_csv(f'see_cost_monitor_{VERSION}.csv',monitor)
    try:
        LAST_RUN.write_text(json.dumps({'version':VERSION,'generated_at':datetime.now(timezone.utc).isoformat(),'tickers':len({r.get('ticker') for r in summary}),'trades':len(trades)}))
    except Exception: pass
    with zipfile.ZipFile(OUT/'all.zip','w',zipfile.ZIP_DEFLATED) as z:
        for f in OUT.glob(f'*{VERSION}*.csv'): z.write(f,f.name)
        if HEALTH_FILE.exists(): z.write(HEALTH_FILE, HEALTH_FILE.name)
        if FAIL_LOG.exists(): z.write(FAIL_LOG, FAIL_LOG.name)

# ---------------- NTFY (fixed) ----------------
def _ascii_header(s, maxlen=120):
    """HTTP headers must be latin-1. v1.9.2 put an emoji in the Title header,
    which made requests raise UnicodeEncodeError on EVERY alert -> silently
    swallowed -> zero notifications ever delivered. Never again."""
    return str(s).encode('ascii','ignore').decode('ascii').strip()[:maxlen]

def _load_ntfy_state():
    try: return json.loads(NTFY_STATE.read_text())
    except Exception: return {}

def _save_ntfy_state(st):
    try: NTFY_STATE.write_text(json.dumps(st, indent=2))
    except Exception: pass

def ntfy_publish(topic, title, message, priority='default', tags='chart_with_upwards_trend'):
    """Returns True only if ntfy accepted the message (HTTP 200)."""
    try:
        r=requests.post(f'https://ntfy.sh/{topic}', data=message.encode('utf-8'),
            headers={'Title':_ascii_header(title), 'Tags':_ascii_header(tags), 'Priority':_ascii_header(priority)}, timeout=10)
        ok=(200<=r.status_code<300)
        if not ok: print(f'[NTFY] publish failed status={r.status_code} body={r.text[:200]}')
        return ok
    except Exception as e:
        print(f'[NTFY] publish error: {e}')
        return False

def ntfy_test():
    topic=os.getenv('NTFY_TOPIC','stock-signals-Stijn-2026')
    ok=ntfy_publish(topic, f'SEE {VERSION} test alert', f'Als je dit ziet werkt ntfy weer.\nEngine {VERSION}, {datetime.now(timezone.utc).isoformat()}', priority='high', tags='white_check_mark')
    print(f'[NTFY] test -> topic={topic} delivered={ok}')
    return ok

def _atr14(df):
    """Average True Range (14) as absolute price units."""
    try:
        h=df['High']; l=df['Low']; c=df['Close']; pc=c.shift(1)
        tr=pd.concat([h-l,(h-pc).abs(),(l-pc).abs()],axis=1).max(axis=1)
        v=float(tr.rolling(14).mean().iloc[-1])
        return v if v==v and v>0 else float(c.iloc[-1])*0.03
    except Exception:
        try: return float(df['Close'].iloc[-1])*0.03
        except Exception: return 0.0

def build_trade_plan(r, df):
    """Mechanical trade plan for an alert. HONEST framing:
    - 'verwacht' = the historical non-overlap average of this exact cell, with
      its 90% CI. It is measured history, not a forecast.
    - TP = price * (1 + hist avg). SL = price - 2*ATR14 (volatility stop).
    - R:R derived from those two. No opinions, only arithmetic."""
    try:
        px=float(df['Close'].iloc[-1])
    except Exception:
        px=safe_float(r.get('price'))
    if px<=0: return None
    avg=safe_float(r.get('avg_nonoverlap')); ci_lo=safe_float(r.get('ci90_low')); ci_hi=safe_float(r.get('ci90_high'))
    atr=_atr14(df) if df is not None else px*0.03
    tp=px*(1+max(avg,0.1)/100)
    sl=max(px-2*atr, px*0.75)
    risk=px-sl; reward=tp-px
    rr=round(reward/risk,2) if risk>0 else 0
    return dict(px=px, avg=avg, ci_lo=ci_lo, ci_hi=ci_hi, tp=tp, sl=sl,
                sl_pct=round((sl/px-1)*100,1), tp_pct=round((tp/px-1)*100,1), rr=rr,
                win=safe_float(r.get('winrate_nonoverlap')), n_eff=r.get('n_eff'), h=r.get('hold_days'))

_TIER_VERDICT={
    'FINAL_EXTREME':   ('TRADE-KANDIDAAT (sterkste tier)', True),
    'HYBRID_WATCHLIST':('TRADE-KANDIDAAT: live signaal + gevalideerde edge', True),
    'LIVE_EXTREME_UNVALIDATED': ('GEEN TRADE-BEWIJS: alleen live aandacht, niet gevalideerd', False),
    'LIVE_HIGH_UNVALIDATED':    ('GEEN TRADE-BEWIJS: alleen live aandacht, niet gevalideerd', False),
}

def send_ntfy(summary_rows, ai_rows, price_data=None):
    price_data=price_data or {}
    # v2.0.0: enabled by default. Set NTFY_ENABLED=0 to disable.
    if os.getenv('NTFY_ENABLED','1')!='1':
        print('[NTFY] disabled via NTFY_ENABLED'); return
    topic=os.getenv('NTFY_TOPIC','stock-signals-Stijn-2026'); maxn=env_int('NTFY_MAX_ALERTS',5)
    realert_hours=env_float('NTFY_REALERT_HOURS',12)
    live_min=env_float('NTFY_LIVE_MIN_ATTENTION',75)
    state=_load_ntfy_state(); now=time.time()
    state={k:v for k,v in state.items() if now-float(v)<7*86400}
    top_by_ticker={}
    for r in summary_rows:
        t=r.get('ticker')
        if not t: continue
        supported = int(r.get('hybrid_watchlist',0)) or (int(r.get('live_extreme',0)) and int(r.get('validated_edge',0)))
        unsup_extreme = int(r.get('live_extreme',0)) and not int(r.get('validated_edge',0))
        # v2.0.0 extra tier: strong live attention + AI_HIGH also alerts, clearly
        # labelled as unvalidated, so the topic is not dead-silent for months
        # while gates are honest-strict.
        live_high = safe_float(r.get('live_attention_score'))>=live_min and int(r.get('ai_high',0))
        if supported or unsup_extreme or live_high:
            cur=top_by_ticker.get(t)
            if cur is None or safe_float(r.get('hybrid_signal_score'))>safe_float(cur.get('hybrid_signal_score')):
                top_by_ticker[t]=r
    ai_map={r.get('ticker'):r for r in ai_rows}
    rows=sorted(top_by_ticker.values(), key=lambda r: (int(r.get('final_extreme',0)), int(r.get('hybrid_watchlist',0)), safe_float(r.get('hybrid_signal_score')), safe_float(r.get('live_attention_score'))), reverse=True)
    sent=0
    for r in rows:
        if sent>=maxn: break
        t=r.get('ticker'); ai=ai_map.get(t,{})
        if int(r.get('final_extreme',0)): signal, prio, tags='FINAL_EXTREME','urgent','rotating_light,chart_with_upwards_trend'
        elif int(r.get('hybrid_watchlist',0)): signal, prio, tags='HYBRID_WATCHLIST','high','star,chart_with_upwards_trend'
        elif int(r.get('live_extreme',0)): signal, prio, tags='LIVE_EXTREME_UNVALIDATED','high','warning,chart_with_upwards_trend'
        else: signal, prio, tags='LIVE_HIGH_UNVALIDATED','default','eyes,chart_with_upwards_trend'
        skey=f'{t}:{signal}'
        if skey in state and (now-float(state[skey]))<realert_hours*3600:
            continue
        score=safe_float(r.get('final_score')); ai_score=safe_float(r.get('ai_final_score'))
        title=f"{signal} {t} | live {safe_float(r.get('live_attention_score')):.1f} / val {safe_float(r.get('validation_score')):.1f}"
        verdict,tradeable=_TIER_VERDICT.get(signal,('GEEN TRADE-BEWIJS',False))
        plan=build_trade_plan(r, price_data.get(t))
        lines=[verdict]
        if plan and tradeable:
            lines.append(f"Entry: rond volgende open (~${plan['px']:.2f})")
            lines.append(f"Historisch bij dit signaal ({plan['h']}d hold): gem {plan['avg']:+.1f}% | winrate {plan['win']:.0f}% | n_eff {plan['n_eff']}")
            lines.append(f"90% CI van dat gemiddelde: {plan['ci_lo']:+.1f}% tot {plan['ci_hi']:+.1f}% (gemiddelde, geen voorspelling)")
            lines.append(f"Take profit (hist. gem.): ${plan['tp']:.2f} ({plan['tp_pct']:+.1f}%)")
            lines.append(f"Stop loss (2x ATR14): ${plan['sl']:.2f} ({plan['sl_pct']:+.1f}%)")
            lines.append(f"R:R ~ {plan['rr']}")
        elif plan:
            lines.append(f"Prijs ~${plan['px']:.2f}. Geen gevalideerde edge achter dit signaal; geen TP/SL-plan. Alleen op de radar zetten.")
        lines.append(f"AI {ai_score:.1f} ({r.get('ai_tier')}) | Mat {r.get('materiality')} | Mkt {r.get('market_confirmation')} | Priced-in {r.get('priced_in_risk')}")
        lines.append(f"Setup: {r.get('setup')} {r.get('hold_days')}d | excess vs drift {r.get('excess_vs_drift')}% (CI low {r.get('excess_ci90_low')})")
        if r.get('validation_warning'): lines.append(f"Warnings: {r.get('validation_warning')}")
        lines.append(f"Event: {ai.get('event_type','?')} - {str(ai.get('reasoning',''))[:280]}")
        msg='\n'.join(lines)
        if ntfy_publish(topic, title, msg, priority=prio, tags=tags):
            state[skey]=now; sent+=1
    _save_ntfy_state(state)
    print(f'[NTFY] alerts sent this run: {sent} (candidates: {len(rows)})')

if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='--ntfy-test':
        sys.exit(0 if ntfy_test() else 1)
    tickers=(sys.argv[1] if len(sys.argv)>1 and sys.argv[1].strip() else DEFAULT_UNIVERSE).replace(' ','').split(',')
    period=sys.argv[2] if len(sys.argv)>2 else '2y'
    run(clean_universe([t for t in tickers if t]), period)
