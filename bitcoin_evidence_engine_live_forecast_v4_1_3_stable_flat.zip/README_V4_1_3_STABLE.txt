BEE Live Forecast V4.1.3 Stable

This ZIP is intentionally flat at root level:
- live_forecast/
- scripts/
- systemd/

No wrapper folder.

After GitHub update on VPS:
cd /home/ubuntu/bitcoin-engine-deploy/current
chmod +x scripts/install_live_forecast.sh
./scripts/install_live_forecast.sh
cd live_forecast
source .venv/bin/activate
nano bee_live_config.json
python bee_live_forecast_v4_1_paper.py --test-fetch
python bee_live_forecast_v4_1_paper.py --test-ntfy
python bee_live_forecast_v4_1_paper.py --once

Supported CLI:
--test-fetch
--test-ntfy
--once
--loop
--daemon
--force-notify
