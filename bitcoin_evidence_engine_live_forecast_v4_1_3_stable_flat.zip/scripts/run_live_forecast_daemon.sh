#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="${BEE_ROOT_DIR:-/home/ubuntu/bitcoin-engine-deploy/current}"
cd "$ROOT_DIR/live_forecast"
source .venv/bin/activate
python bee_live_forecast_v4_1_paper.py --loop
