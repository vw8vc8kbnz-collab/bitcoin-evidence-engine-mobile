#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="${BEE_ROOT_DIR:-/home/ubuntu/bitcoin-engine-deploy/current}"
LIVE_DIR="$ROOT_DIR/live_forecast"
PYTHON_BIN="${PYTHON_BIN:-python3}"

cd "$ROOT_DIR"

# Repair older mistaken wrapper extraction if present.
if [ ! -d "$LIVE_DIR" ] && [ -d "$ROOT_DIR/BEE_GITHUB_SERVER_READY_V4_1_1_LIVE_FORECAST/live_forecast" ]; then
  echo "Found old wrapper folder; moving live_forecast/ into root..."
  mv "$ROOT_DIR/BEE_GITHUB_SERVER_READY_V4_1_1_LIVE_FORECAST/live_forecast" "$LIVE_DIR"
fi
if [ ! -d "$ROOT_DIR/scripts" ] && [ -d "$ROOT_DIR/BEE_GITHUB_SERVER_READY_V4_1_1_LIVE_FORECAST/scripts" ]; then
  mv "$ROOT_DIR/BEE_GITHUB_SERVER_READY_V4_1_1_LIVE_FORECAST/scripts" "$ROOT_DIR/scripts"
fi

if [ ! -d "$LIVE_DIR" ]; then
  echo "ERROR: live_forecast directory not found: $LIVE_DIR"
  echo "The ZIP must contain live_forecast/ directly at the root."
  exit 1
fi

cd "$LIVE_DIR"

echo "Live forecast directory: $LIVE_DIR"
ls -lah

if ! command -v "$PYTHON_BIN" >/dev/null 2>&1; then
  echo "ERROR: python3 not found"
  exit 1
fi

if [ ! -d .venv ]; then
  "$PYTHON_BIN" -m venv .venv
fi

source .venv/bin/activate
python -m pip install --upgrade pip >/dev/null
if [ -f requirements.txt ]; then
  pip install -r requirements.txt
else
  pip install requests >/dev/null || true
fi

mkdir -p state

if [ ! -f bee_live_config.json ]; then
  if [ -f bee_live_config.example.json ]; then
    cp bee_live_config.example.json bee_live_config.json
    echo "Created bee_live_config.json from example."
  else
    cat > bee_live_config.json <<'JSON'
{
  "paper_only": true,
  "ntfy_server": "https://ntfy.sh",
  "ntfy_topic": "PASTE_PRIVATE_NTFY_TOPIC_HERE",
  "check_interval_hours": 24,
  "active_specialists": ["cycle_reversal", "elite_reversal", "reversal"],
  "min_notify_tier": "push",
  "include_trade_plan_in_ntfy": true,
  "live_exit_policy": "wide_trailing_paper",
  "dedup_days_by_specialist": {"cycle_reversal": 7, "elite_reversal": 14, "reversal": 14},
  "binance_base_urls": ["https://api.binance.com", "https://api.binance.us"],
  "use_coinbase_premium": false,
  "alpha_vantage_api_key": "PASTE_ALPHA_VANTAGE_KEY_HERE"
}
JSON
  fi
else
  echo "bee_live_config.json already exists; keeping it."
fi

chmod +x bee_live_forecast_v4_1_paper.py || true

echo ""
echo "✅ Live forecast install OK."
echo "Next commands:"
echo "  cd $LIVE_DIR"
echo "  source .venv/bin/activate"
echo "  nano bee_live_config.json"
echo "  python bee_live_forecast_v4_1_paper.py --test-fetch"
echo "  python bee_live_forecast_v4_1_paper.py --test-ntfy"
echo "  python bee_live_forecast_v4_1_paper.py --once"
