BEE GitHub Server-Ready Add-on — V4.1.1 Live Forecast Paper Mode
=================================================================

Doel
----
Deze build is bedoeld om in dezelfde GitHub/VPS-route mee te deployen als de bestaande
Bitcoin Evidence Engine server-tool. Hij voegt een aparte map toe:

  live_forecast/

De bestaande app hoeft hiervoor niet aangepast te worden. De live forecast is een losse
paper-forecast daemon met ntfy-output en lokale logs/state.

Belangrijk
----------
- Geen automatische trading.
- Alleen paper alerts.
- Fase 1 activeert alleen: cycle_reversal, elite_reversal, reversal.
- Config/secrets horen NIET in GitHub: bee_live_config.json staat in .gitignore.
- De voorbeeldconfig heet: live_forecast/bee_live_config.example.json

GitHub-route
------------
1. Pak deze ZIP uit in je lokale repository/root van de bestaande server-tool.
2. Commit/push de nieuwe mappen:
   - live_forecast/
   - scripts/
   - systemd/
3. Deploy via je bestaande GitHub updater naar:
   /home/ubuntu/bitcoin-engine-deploy/current
4. Draai op de VPS eenmalig:

   cd /home/ubuntu/bitcoin-engine-deploy/current
   chmod +x scripts/install_live_forecast.sh
   ./scripts/install_live_forecast.sh

5. Vul ntfy topic in:

   nano /home/ubuntu/bitcoin-engine-deploy/current/live_forecast/bee_live_config.json

6. Test:

   cd /home/ubuntu/bitcoin-engine-deploy/current/live_forecast
   source .venv/bin/activate
   python bee_live_forecast_v4_1_paper.py --test-fetch
   python bee_live_forecast_v4_1_paper.py --test-ntfy
   python bee_live_forecast_v4_1_paper.py --once

7. Als dit goed is, tijdelijk handmatig draaien:

   python bee_live_forecast_v4_1_paper.py --loop

Systemd later
-------------
Als je hem automatisch wil laten draaien:

  sudo cp /home/ubuntu/bitcoin-engine-deploy/current/systemd/bee-live-forecast.service.example /etc/systemd/system/bee-live-forecast.service
  sudo systemctl daemon-reload
  sudo systemctl enable bee-live-forecast
  sudo systemctl start bee-live-forecast
  sudo systemctl status bee-live-forecast

Logs/state
----------
De daemon schrijft lokaal naar:

  live_forecast/state/

Daarin komen cache/state/signals/logs. Deze map wordt niet naar GitHub gecommit.
