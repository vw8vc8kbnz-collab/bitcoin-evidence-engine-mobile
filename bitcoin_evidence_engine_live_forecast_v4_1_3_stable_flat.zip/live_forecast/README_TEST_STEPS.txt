BEE Live Forecast V4.1.1 — Paper Mode + Trade Plan ntfy
=========================================================

Doel
----
Deze server-versie draait NIET in Pythonista. Pythonista blijft alleen voor research/backtests.
Live paper forecast hoort op de VPS/server te draaien, omdat daar API-calls, ntfy, logging,
state/cache en een background loop betrouwbaar kunnen draaien.

Nieuw in V4.1.1
---------------
De ntfy-alert toont nu direct:
- model/specialist
- timeframe/horizon
- entry price
- take profit / target price
- stoploss / initial trailing-stop price
- exit policy
- historische winrate van dat model op dat timeframe uit alle historische data
- walk-forward OOS-samenvatting waar beschikbaar

Belangrijke interpretatie
-------------------------
De take-profit prijs is een PAPER/monitoring target op basis van de historische gemiddelde
move van dat model/timeframe. De live safety-exit blijft wide_trailing_paper. Er worden geen
orders geplaatst en er is geen automatische trading.

Actieve fase-1 modellen
-----------------------
Alleen deze modellen kunnen push-notificaties sturen:
- cycle_reversal
- elite_reversal
- reversal

Niet actief in fase 1:
- trend_continuation
- elite_continuation
- funding_squeeze_reversal

Installatie op server
---------------------
Plaats de map bijvoorbeeld hier:
/home/ubuntu/bitcoin-engine-deploy/current/live_forecast

Maak/activeer een Python 3.12 venv:
python3.12 -m venv .venv
source .venv/bin/activate

Deze versie gebruikt alleen standard library voor de loop zelf.

Config
------
Kopieer:
cp bee_live_config.example.json bee_live_config.json

Vul minimaal in:
- ntfy_topic

Optioneel via environment variable:
export BEE_NTFY_TOPIC="jouw-geheime-topic"
export ALPHAVANTAGE_API_KEY="..."

Testvolgorde
------------
1) Test ntfy:
python bee_live_forecast_v4_1_paper.py --test-ntfy

2) Test één run zonder loop:
python bee_live_forecast_v4_1_paper.py --once

3) Forceer één test-notificatie met de actuele decision/logica:
python bee_live_forecast_v4_1_paper.py --once --force-notify

4) Pas daarna als daemon:
python bee_live_forecast_v4_1_paper.py --loop

Logs/output
-----------
- bee_live_signals.jsonl       alle signalen en no-trades
- bee_live_state.json          dedup/cache/state
- bee_live_system.log          systeemmeldingen/fouten
- bee_live_last_feature_snapshot.json  laatste live feature + decision + trade_plan

Databronnen
-----------
- Binance spot klines voor BTCUSDT candles
- Alternative.me voor Fear & Greed
- Binance futures funding als diagnostiek
- Coinbase premium optioneel
- Alpha Vantage SPY weekly macro optioneel; continuation staat uit in fase 1

Fail-safes
----------
- Geen automatische trading
- BTC candles falen => iteratie overslaan
- Fear & Greed faalt => cache gebruiken indien aanwezig
- ntfy faalt => signaal blijft lokaal gelogd
- no forward-return columns live
- dedup per specialist voorkomt spam
