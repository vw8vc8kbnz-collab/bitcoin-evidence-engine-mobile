#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
BEE Research Backtest v4.0 Walk-Forward Time Machine — Out-of-Sample Audit

Pythonista-safe standalone research sandbox for Bitcoin Evidence Engine.
- Standard library only: csv, os, sys, math, time, zipfile, tempfile
- Reads BTC_alle_lagen_gecombineerd.csv / BTC alle lagen gecombineerd*.csv
- Can read the CSV from the ZIP if selected/found
- Writes ONE visible export ZIP: bee_research_results.zip
- CSV is created temporarily, compressed into ZIP, then removed to keep Pythonista export small
- Adds multi-horizon evaluation: 1h, 4h, 8h, 24h, 7d, 30d, 90d
- Adds FundingSqueezeEngine as the only standalone short-horizon specialist:
    * funding_rate < -0.0001 and fear_greed < 20 -> LONG, primary horizon 24h/1d
    * evaluated mainly with independent_day because 4h/8h are diagnostic only
- Adds CycleReversalEngine per multi-horizon audit:
    * Early recovery LONG: fear_greed < 25 and short momentum turns up (return_4 > 0), primary horizon 30d
    * Late-cycle WARNING/SHORT: fear_greed > 80 and past 7d momentum > 0, primary horizon 90d
- Keeps v2.3 fixes:
    * clean macro return from spx_ret_1d (dataset's clean weekly macro proxy)
    * macro sanity clamp
    * continuation fear gate < 40
    * Coinbase premium > 0
    * trend filter remains close > ma50 and close > ma200

Important: forward returns are labels only. They are never used inside decision logic.
"""
import csv, os, sys, math, time, zipfile, tempfile, datetime
from collections import deque

VERSION = "v4.0_walk_forward_time_machine"
CSV_NAMES = [
    "BTC_alle_lagen_gecombineerd.csv",
    "BTC alle lagen gecombineerd.csv",
    "BTC alle lagen gecombineerd(1).csv",
]
RESULTS_CSV = "bee_research_results.csv"
SUMMARY_TXT = "bee_research_v4_0_walk_forward_summary.txt"
RESULTS_ZIP = "bee_research_results.zip"
FOCUSED_TRADE_HORIZONS = ["24h", "7d", "30d", "90d"]
EXIT_TRAIL_PCTS = []  # V3.1 uses one family-specific wide trailing-stop per selected specialist, not three slow brute-force trailing scans.
EXIT_MODES = ["fixed_target_stop", "horizon_exit", "wide_trailing_bar_by_bar", "portfolio_equal_weight", "portfolio_confidence_weight", "portfolio_smart_engine_weight", "portfolio_reality_full_mtm"]
START_EQUITY_USD = 10000.0
PORTFOLIO_EXPOSURE_CAP = 1.00
PORTFOLIO_USE_DEDUP_FIELD = "independent_week"  # one signal per specialist/setup/week to avoid duplicate hourly clustering

# Macro + flow parameters
RISK_ON_THRESHOLD = 0.50
RISK_OFF_THRESHOLD = -0.50
MACRO_ABS_CLAMP = 20.0
COINBASE_THRESHOLD = 0.0

# Continuation v2.3 parameters
CONT_FEAR_MAX = 40.0
CONT_REGIMES = ("bull_trend", "transition")

# Existing reversal specialist
REV_REGIMES = ("capitulation", "bear_trend")

# New cycle specialist parameters
CYCLE_FEAR_LONG_MAX = 25.0       # early recovery: extreme fear
CYCLE_GREED_SHORT_MIN = 80.0     # late-cycle warning: extreme greed

# v2.7 FundingSqueezeReversalEngine parameters.
# This is no longer treated as a naive 24h scalp engine. It is evaluated as
# capitulation/recovery context with 1d diagnostic + 7d/30d/90d recovery labels.
FUNDING_SQUEEZE_RATE_MAX = -0.00008  # v2.8 loose-selected: target more usable sample than v2.7
FUNDING_SQUEEZE_FEAR_MAX = 25.0
FUNDING_SQUEEZE_DRAWDOWN_MAX = -25.0
FUNDING_SQUEEZE_RSI_MAX = 38.0
FUNDING_SQUEEZE_PAST_RET_4H_MAX = -1.0
FUNDING_SQUEEZE_COINBASE_MIN = -0.05

# v2.7 restores the v2.5 confluence-elite volume rule.
# The stricter v2.6 guard was too conservative: count dropped from ~2257 to ~1068.
# Keep strict diagnostics in debug output, but SELECT the v2.5-style rule.
CONFLUENCE_ELITE_STRICT_MIN_CYCLE_PROB = 0.70
CONFLUENCE_ELITE_STRICT_DEEP_FEAR_MAX = 18.0

MAX_HOURLY_JUMP_PCT = 35.0
COST_BPS = 8.0
SUBSET_STRIDE = 1

HORIZONS = [
    ("1h", 1),
    ("4h", 4),
    ("8h", 8),
    ("24h", 24),
    ("7d", 168),
    ("30d", 720),
    ("90d", 2160),
]

# label caps only; values beyond these are marked unsafe in horizon_valid_* fields
HORIZON_ABS_CAPS = {
    "1h": 50.0,
    "4h": 80.0,
    "8h": 100.0,
    "24h": 150.0,
    "7d": 200.0,
    "30d": 300.0,
    "90d": 500.0,
}

USED_COLS = [
    "open_time", "dt", "open", "high", "low", "close", "return_1", "return_4", "return_24",
    "ma_20", "ma_50", "ma_200", "rsi_14", "volatility_24", "volume_zscore", "drawdown_from_ath",
    "regime", "fear_greed", "funding_rate", "coinbase_premium_pct", "spx_close", "spx_ret_1d",
    "fwd_ret_1", "fwd_ret_4", "fwd_ret_24", "fwd_ret_168",
]


def safe_float(v):
    if v is None:
        return None
    s = str(v).strip()
    if not s or s.lower() in ("nan", "none", "null"):
        return None
    try:
        x = float(s)
        return None if x != x else x
    except Exception:
        return None


def safe_int(v):
    x = safe_float(v)
    return int(x) if x is not None else 0


def _safe_abs_dir(p):
    try:
        if not p:
            return None
        return os.path.dirname(os.path.abspath(p)) if not os.path.isdir(p) else os.path.abspath(p)
    except Exception:
        return None


def script_dir():
    # Pythonista can throw PermissionError for os.getcwd(); never use cwd.
    try:
        import editor
        p = editor.get_path()
        d = _safe_abs_dir(p)
        if d:
            return d
    except Exception:
        pass
    try:
        d = _safe_abs_dir(__file__)
        if d:
            return d
    except Exception:
        pass
    try:
        return os.path.expanduser("~/Documents")
    except Exception:
        return "."


def candidate_dirs():
    dirs = []
    for d in [script_dir(), os.path.expanduser("~/Documents"), os.path.expanduser("~/Documents/Downloads"), tempfile.gettempdir()]:
        try:
            if d and os.path.isdir(d) and d not in dirs:
                dirs.append(d)
        except Exception:
            continue
    return dirs


def is_target_csv(path):
    base = os.path.basename(path)
    return base in CSV_NAMES or (base.lower().endswith(".csv") and "btc" in base.lower() and "lagen" in base.lower())


def find_local_csv():
    # Direct checks only. No recursive scans.
    for d in candidate_dirs():
        for name in CSV_NAMES:
            p = os.path.join(d, name)
            try:
                if os.path.isfile(p):
                    return p
            except Exception:
                pass
        try:
            for fn in os.listdir(d):
                p = os.path.join(d, fn)
                try:
                    if is_target_csv(p) and os.path.isfile(p):
                        return p
                except Exception:
                    pass
        except Exception:
            pass
    return None


def find_zip_with_csv():
    for d in candidate_dirs():
        try:
            files = os.listdir(d)
        except Exception:
            continue
        for fn in files:
            if not fn.lower().endswith(".zip"):
                continue
            p = os.path.join(d, fn)
            try:
                with zipfile.ZipFile(p, "r") as z:
                    for n in z.namelist():
                        if is_target_csv(n):
                            return p, n
            except Exception:
                pass
    return None, None


def pick_file_pythonista():
    try:
        import dialogs
        return dialogs.pick_document(types=["public.comma-separated-values-text", "public.zip-archive", "public.data"])
    except Exception:
        return None


def find_data_source():
    p = find_local_csv()
    if p:
        return ("csv", p, None)
    zp, member = find_zip_with_csv()
    if zp:
        return ("zip", zp, member)
    picked = pick_file_pythonista()
    if picked:
        if picked.lower().endswith(".zip"):
            try:
                with zipfile.ZipFile(picked, "r") as z:
                    for n in z.namelist():
                        if is_target_csv(n):
                            return ("zip", picked, n)
            except Exception:
                pass
        if is_target_csv(picked) or picked.lower().endswith(".csv"):
            return ("csv", picked, None)
    return (None, None, None)


def open_data_source(kind, path, member):
    if kind == "csv":
        return open(path, "r", newline="", encoding="utf-8-sig")
    if kind == "zip":
        z = zipfile.ZipFile(path, "r")
        raw = z.open(member, "r")
        import io
        txt = io.TextIOWrapper(raw, encoding="utf-8-sig", newline="")
        txt._bee_zip = z
        return txt
    raise RuntimeError("Geen data source")


def load_data(kind, path, member):
    rows = []
    with open_data_source(kind, path, member) as fh:
        reader = csv.DictReader(fh)
        missing = [c for c in ["open_time", "dt", "close", "regime", "fwd_ret_24"] if c not in (reader.fieldnames or [])]
        if missing:
            raise RuntimeError("CSV mist verplichte kolommen: " + ", ".join(missing))
        for i, raw in enumerate(reader):
            if SUBSET_STRIDE > 1 and i % SUBSET_STRIDE != 0:
                continue
            r = {}
            for c in USED_COLS:
                if c in ("dt", "regime"):
                    r[c] = raw.get(c, "")
                elif c == "open_time":
                    r[c] = safe_int(raw.get(c))
                else:
                    r[c] = safe_float(raw.get(c))
            rows.append(r)
    return rows


def add_macro_week_return(rows):
    """
    Use the dataset's clean macro return column (spx_ret_1d) as the weekly risk-on proxy,
    based on Claude's audit. Never recalculate via fixed 168h windows across forward-filled
    weekdata unless the clean column is missing. Clamp impossible values.
    """
    bad_macro = 0; used_existing = 0; used_fallback = 0
    for i, r in enumerate(rows):
        r["spx_ret_1w_calc"] = None
        r["macro_safe"] = False
        r["macro_source"] = "missing"
        r["macro_bad"] = False
        x = r.get("spx_ret_1d")
        source = "spx_ret_1d_clean"
        if x is None and i >= 168:
            now = r.get("close")
            prev = rows[i-168].get("close")
            if now is not None and prev not in (None, 0):
                x = (now / prev - 1.0) * 100.0
                source = "fallback_168h_BTC_NOT_SPX_UNSAFE"
        if x is not None:
            if abs(x) > MACRO_ABS_CLAMP:
                r["macro_bad"] = True
                r["macro_source"] = source + "_CLAMPED_BAD"
                bad_macro += 1
            else:
                r["spx_ret_1w_calc"] = x
                r["macro_safe"] = True
                r["macro_source"] = source
                if source == "spx_ret_1d_clean": used_existing += 1
                else: used_fallback += 1
    return {"bad_macro": bad_macro, "used_existing": used_existing, "used_fallback": used_fallback}


def mark_corrupt(rows):
    bad = 0; prev = None
    for r in rows:
        r["corrupt"] = False
        c = r.get("close")
        if prev not in (None, 0) and c not in (None, 0):
            jump = abs(c / prev - 1.0) * 100.0
            if jump > MAX_HOURLY_JUMP_PCT:
                r["corrupt"] = True; bad += 1
        if c is not None:
            prev = c
    return bad


def add_past_and_forward_returns(rows):
    """Add past returns used for timing/context and forward returns used only for labels/evaluation."""
    n = len(rows)
    for i, r in enumerate(rows):
        c = r.get("close")
        # past returns
        for label, bars in [("4h", 4), ("24h", 24), ("7d", 168), ("30d", 720)]:
            k = "past_ret_" + label
            val = None
            if i >= bars and c is not None:
                prev = rows[i-bars].get("close")
                if prev not in (None, 0):
                    val = (c / prev - 1.0) * 100.0
            r[k] = val
        # forward returns
        for label, bars in HORIZONS:
            key = "ret_" + label
            valid_key = "ret_" + label + "_valid"
            val = None
            if label == "1h": val = r.get("fwd_ret_1")
            elif label == "4h": val = r.get("fwd_ret_4")
            elif label == "24h": val = r.get("fwd_ret_24")
            elif label == "7d": val = r.get("fwd_ret_168")
            if val is None and i + bars < n and c not in (None, 0):
                future = rows[i+bars].get("close")
                if future is not None:
                    val = (future / c - 1.0) * 100.0
            if val is not None and abs(val) > HORIZON_ABS_CAPS.get(label, 999.0):
                r[key] = None; r[valid_key] = False
            else:
                r[key] = val; r[valid_key] = val is not None


def risk_state(row):
    x = row.get("spx_ret_1w_calc")
    if x is None: return "UNKNOWN"
    if x > RISK_ON_THRESHOLD: return "RISK_ON"
    if x < RISK_OFF_THRESHOLD: return "RISK_OFF"
    return "NEUTRAL"


def continuation_debug(row):
    close = row.get("close"); ma50 = row.get("ma_50"); ma200 = row.get("ma_200")
    ret24 = row.get("return_24"); prem = row.get("coinbase_premium_pct")
    rsi = row.get("rsi_14"); fg = row.get("fear_greed")
    reg = row.get("regime") or ""; rs = risk_state(row)
    canonical_trend_ok = bool(close is not None and ma50 is not None and ma200 is not None and close > ma50 and close > ma200)
    ma50_dist = ((close - ma50) / ma50 * 100.0) if close is not None and ma50 not in (None, 0) else None
    ma200_dist = ((close - ma200) / ma200 * 100.0) if close is not None and ma200 not in (None, 0) else None
    bug_trend_ok = bool(ma50_dist is not None and ma200_dist is not None and ma50_dist < 0 and ma200_dist < 0)
    out = {
        "risk_state": rs,
        "macro_safe": bool(row.get("macro_safe")),
        "spx_ret_1w": row.get("spx_ret_1w_calc"),
        "canonical_trend_ok": canonical_trend_ok,
        "bug_trend_ok": bug_trend_ok,
        "trend_ok_used": canonical_trend_ok,
        "ma50_distance_canonical": ma50_dist,
        "ma200_distance_canonical": ma200_dist,
        "cont_risk_on_ok": rs == "RISK_ON",
        "cont_regime_ok": reg in CONT_REGIMES,
        "cont_momentum_ok": ret24 is not None and ret24 > 0,
        "cont_coinbase_ok": prem is not None and prem > COINBASE_THRESHOLD,
        "cont_sentiment_ok": fg is not None and fg < CONT_FEAR_MAX,
        "cont_overheat": bool(rsi is not None and fg is not None and rsi > 80 and fg > 85),
    }
    reason = "PASS"
    if not out["macro_safe"]: reason = "MACRO_NOT_SAFE"
    elif not out["cont_risk_on_ok"]: reason = "RISK_NOT_ON"
    elif not out["cont_regime_ok"]: reason = "WRONG_REGIME"
    elif not out["trend_ok_used"]: reason = "TREND_FAIL"
    elif not out["cont_momentum_ok"]: reason = "MOMENTUM_FAIL"
    elif not out["cont_coinbase_ok"]: reason = "COINBASE_TOO_NEGATIVE"
    elif not out["cont_sentiment_ok"]: reason = "SENTIMENT_TOO_GREEDY"
    elif out["cont_overheat"]: reason = "OVERHEAT"
    out["cont_reject_reason"] = reason
    out["continuation_applies"] = reason == "PASS"
    return out


def reversal_debug(row):
    reg = row.get("regime") or ""; fg = row.get("fear_greed")
    prem = row.get("coinbase_premium_pct"); fund = row.get("funding_rate")
    applies = bool(reg in REV_REGIMES and fg is not None and fg < 30 and ((fund is not None and fund < 0) or (prem is not None and prem > 0)))
    score = 0.52
    if applies:
        score += max(0.0, (30.0 - fg) / 30.0) * 0.12
        if fund is not None and fund < 0: score += 0.04
        if prem is not None and prem > 0: score += 0.04
    return {"reversal_applies": applies, "reversal_prob": min(score, 0.80) if applies else None}


def cycle_debug(row):
    fg = row.get("fear_greed")
    mom4 = row.get("past_ret_4h")
    mom7d = row.get("past_ret_7d")
    dd = row.get("drawdown_from_ath")
    rs = risk_state(row)
    early_long = bool(fg is not None and fg < CYCLE_FEAR_LONG_MAX and mom4 is not None and mom4 > 0)
    late_short = bool(fg is not None and fg > CYCLE_GREED_SHORT_MIN and mom7d is not None and mom7d > 0)
    prob_long = None
    prob_short = None
    if early_long:
        prob_long = 0.62
        prob_long += max(0.0, (CYCLE_FEAR_LONG_MAX - fg) / CYCLE_FEAR_LONG_MAX) * 0.12
        if dd is not None and dd < -30: prob_long += 0.04
        if rs == "RISK_ON": prob_long += 0.02
        prob_long = min(prob_long, 0.88)
    if late_short:
        prob_short = 0.62
        prob_short += max(0.0, (fg - CYCLE_GREED_SHORT_MIN) / (100.0 - CYCLE_GREED_SHORT_MIN)) * 0.12
        prob_short = min(prob_short, 0.88)
    reason = "NONE"
    if early_long: reason = "EARLY_RECOVERY_LONG"
    elif late_short: reason = "LATE_CYCLE_WARNING_SHORT"
    return {
        "cycle_early_recovery_long": early_long,
        "cycle_late_warning_short": late_short,
        "cycle_reason": reason,
        "cycle_prob_long": prob_long,
        "cycle_prob_short": prob_short,
        "cycle_mom_4h": mom4,
        "cycle_mom_7d": mom7d,
    }


def funding_squeeze_debug(row):
    """FundingSqueezeReversalEngine v2.7.

    V2.6 proved that plain funding_rate < -0.0001 + fear_greed < 20 was too
    weak as a selected 24h engine. V2.7 keeps the idea, but treats it as a
    capitulation/reversal context:
      - negative funding: leveraged shorts / stressed perps
      - extreme fear: sentiment capitulation
      - drawdown / RSI / prior 4h selloff: market damage is real
      - Coinbase not too negative: spot flow is not fully absent

    Primary selected horizon is 30d because the V2.6 result showed the edge was
    recovery/capitulation-like, not a reliable tomorrow-bounce signal.
    24h remains in the CSV for diagnostics via ret_24h/win_24h.
    """
    fg = row.get("fear_greed")
    fund = row.get("funding_rate")
    prem = row.get("coinbase_premium_pct")
    reg = row.get("regime") or ""
    dd = row.get("drawdown_from_ath")
    rsi = row.get("rsi_14")
    past4 = row.get("past_ret_4h")
    mom4 = row.get("return_4")

    funding_ok = fund is not None and fund < FUNDING_SQUEEZE_RATE_MAX
    fear_ok = fg is not None and fg < FUNDING_SQUEEZE_FEAR_MAX
    drawdown_ok = dd is not None and dd < FUNDING_SQUEEZE_DRAWDOWN_MAX
    rsi_ok = rsi is not None and rsi < FUNDING_SQUEEZE_RSI_MAX
    selloff_ok = past4 is not None and past4 < FUNDING_SQUEEZE_PAST_RET_4H_MAX
    coinbase_ok = prem is not None and prem > FUNDING_SQUEEZE_COINBASE_MIN
    regime_ok = reg in ("capitulation", "bear_trend", "transition")
    reversal_hint = bool((mom4 is not None and mom4 > 0) or (prem is not None and prem > 0))

    core_ok = funding_ok and fear_ok
    context_score = 0
    for ok in (drawdown_ok, rsi_ok, selloff_ok, coinbase_ok, regime_ok, reversal_hint):
        if ok:
            context_score += 1

    # Selected engine requires core squeeze + enough confirmation. This keeps it
    # from being the naive V2.6 coinflip while still preserving rows for diagnostics.
    applies = bool(core_ok and context_score >= 3)

    prob = None
    reason = "NONE"
    if applies:
        reason = "NEGATIVE_FUNDING_CAPITULATION_REVERSAL"
        prob = 0.60
        prob += min(0.07, abs(fund - FUNDING_SQUEEZE_RATE_MAX) * 100.0)
        prob += max(0.0, (FUNDING_SQUEEZE_FEAR_MAX - fg) / FUNDING_SQUEEZE_FEAR_MAX) * 0.06
        prob += min(0.08, context_score * 0.012)
        if reversal_hint:
            prob += 0.025
        prob = min(prob, 0.78)

    reject = "PASS" if applies else "NO_SQUEEZE_REVERSAL"
    if fund is None:
        reject = "FUNDING_MISSING"
    elif not funding_ok:
        reject = "FUNDING_NOT_NEGATIVE_ENOUGH"
    elif fg is None:
        reject = "FEAR_GREED_MISSING"
    elif not fear_ok:
        reject = "FEAR_NOT_EXTREME_ENOUGH"
    elif context_score < 3:
        reject = "CONTEXT_NOT_STRONG_ENOUGH"

    # Also preserve the old simple V2.6 hypothesis as a diagnostic flag.
    simple_applies = bool(funding_ok and fg is not None and fg < 20.0)

    return {
        "funding_squeeze_applies": applies,
        "funding_squeeze_simple_applies": simple_applies,
        "funding_squeeze_prob": prob,
        "funding_squeeze_reason": reason,
        "funding_squeeze_reject_reason": reject,
        "funding_squeeze_funding_ok": funding_ok,
        "funding_squeeze_fear_ok": fear_ok,
        "funding_squeeze_drawdown_ok": drawdown_ok,
        "funding_squeeze_rsi_ok": rsi_ok,
        "funding_squeeze_selloff_ok": selloff_ok,
        "funding_squeeze_coinbase_ok": coinbase_ok,
        "funding_squeeze_regime_ok": regime_ok,
        "funding_squeeze_reversal_hint": reversal_hint,
        "funding_squeeze_context_score": context_score,
    }

def tier_from_prob(prob, specialist):
    if prob is None: return "none"
    if specialist == "cycle_reversal":
        if prob >= 0.78: return "elite"
        if prob >= 0.70: return "strong"
        if prob >= 0.62: return "push"
        return "watch"
    if specialist == "reversal":
        if prob >= 0.68: return "elite"
        if prob >= 0.62: return "strong"
        if prob >= 0.56: return "push"
        return "watch"
    if specialist == "trend_continuation":
        if prob >= 0.66: return "elite"
        if prob >= 0.60: return "strong"
        if prob >= 0.55: return "push"
        return "watch"
    if specialist in ("funding_squeeze", "funding_squeeze_reversal"):
        if prob >= 0.70: return "elite"
        if prob >= 0.64: return "strong"
        if prob >= 0.58: return "push"
        return "watch"
    return "none"



def elite_continuation_v2_debug(row, cont):
    """V2.9 rebuilt bull-continuation elite bucket.

    The previous elite_continuation was almost empty because it only came from
    cycle + continuation confluence, which mostly selects reversal/capitulation
    rows. This detector is a separate healthy-bull continuation family.
    """
    reg = row.get("regime") or ""
    fg = row.get("fear_greed")
    prem = row.get("coinbase_premium_pct")
    r24 = row.get("return_24")
    r4 = row.get("return_4")
    rsi = row.get("rsi_14")
    close = row.get("close")
    ma50 = row.get("ma_50")
    ma200 = row.get("ma_200")
    risk_ok = bool(cont.get("cont_risk_on_ok"))
    trend_ok = close is not None and ma50 is not None and ma200 is not None and close > ma50 and close > ma200
    regime_ok = reg in ("bull_trend", "transition")
    sentiment_ok = fg is not None and fg >= 35.0 and fg <= 65.0
    coinbase_ok = prem is not None and prem > 0.05
    momentum_ok = (r24 is not None and r24 > 2.0)
    not_overheated = (rsi is not None and rsi <= 68.0)
    applies = bool(regime_ok and trend_ok and risk_ok and sentiment_ok and coinbase_ok and momentum_ok and not_overheated)
    score = 0
    for ok in (regime_ok, trend_ok, risk_ok, sentiment_ok, coinbase_ok, momentum_ok, not_overheated):
        if ok: score += 1
    prob = None
    if applies:
        prob = 0.68
        if fg is not None and 40.0 <= fg <= 68.0: prob += 0.04
        if prem is not None and prem > 0.05: prob += 0.03
        if r24 is not None and r24 > 1.0: prob += 0.03
        if rsi is not None and 45.0 <= rsi <= 68.0: prob += 0.02
        prob = min(prob, 0.82)
    reject = "PASS" if applies else "ELITE_CONTINUATION_FILTER_FAIL"
    return {
        "elite_continuation_v2_applies": applies,
        "elite_continuation_v2_prob": prob,
        "elite_continuation_v2_score": score,
        "elite_continuation_v2_reject_reason": reject,
        "elite_continuation_v2_regime_ok": regime_ok,
        "elite_continuation_v2_trend_ok": trend_ok,
        "elite_continuation_v2_risk_ok": risk_ok,
        "elite_continuation_v2_sentiment_ok": sentiment_ok,
        "elite_continuation_v2_coinbase_ok": coinbase_ok,
        "elite_continuation_v2_momentum_ok": momentum_ok,
        "elite_continuation_v2_not_overheated": not_overheated,
    }

def decide(row):
    cont = continuation_debug(row)
    rev = reversal_debug(row)
    cyc = cycle_debug(row)
    fund = funding_squeeze_debug(row)
    elite_cont_v2 = elite_continuation_v2_debug(row, cont)

    bullish_engines = []
    if cyc["cycle_early_recovery_long"]:
        bullish_engines.append("cycle_early_recovery_30d")
    if rev["reversal_applies"]:
        bullish_engines.append("reversal_90d")
    if cont["continuation_applies"]:
        bullish_engines.append("continuation_7d")

    confluence_count = len(bullish_engines)
    # v2.5-style volume rule: restore the broad high-quality bucket that produced
    # ~2257 rows instead of the overly strict v2.6 ~1068 rows.
    confluence_elite_v25_long = bool(cyc["cycle_early_recovery_long"] and (rev["reversal_applies"] or cont["continuation_applies"]))
    # Keep the stricter v2.6 rule only as a diagnostic column, not as selected bucket.
    confluence_elite_strict_long = bool(
        cyc["cycle_early_recovery_long"]
        and (rev["reversal_applies"] or cont["continuation_applies"])
        and (
            (cyc.get("cycle_prob_long") is not None and cyc.get("cycle_prob_long") >= CONFLUENCE_ELITE_STRICT_MIN_CYCLE_PROB)
            or (row.get("fear_greed") is not None and row.get("fear_greed") <= CONFLUENCE_ELITE_STRICT_DEEP_FEAR_MAX)
            or confluence_count >= 3
        )
    )
    confluence_elite_long = confluence_elite_v25_long
    confluence_label = "+".join(bullish_engines)

    selected = "none"; action = "NO_TRADE"; prob = None; primary_horizon = "none"; setup = "none"

    # Horizon-aware priority v2.5:
    # 0) bullish confluence gets its own elite bucket for analysis.
    # 1) cycle warnings/early recovery dominate because they are long-horizon context.
    # 2) reversal is now evaluated primarily on 90d (not 24h/7d).
    # 3) trend continuation remains primarily a 7d setup; 90d is reported as secondary in output.
    if confluence_elite_long:
        selected, setup = elite_family_from_debug(row, rev, cont, cyc)
        action = "LONG"
        prob = 0.90
        primary_horizon = "7d" if selected == "elite_continuation" else "30d"
    elif elite_cont_v2["elite_continuation_v2_applies"]:
        selected = "elite_continuation"; action = "LONG"; prob = elite_cont_v2["elite_continuation_v2_prob"]; primary_horizon = "7d"; setup = "healthy_bull_continuation_v2"
    elif cyc["cycle_late_warning_short"]:
        selected = "cycle_reversal"; action = "SHORT"; prob = cyc["cycle_prob_short"]; primary_horizon = "90d"; setup = "late_cycle_warning"
    elif cyc["cycle_early_recovery_long"]:
        selected = "cycle_reversal"; action = "LONG"; prob = cyc["cycle_prob_long"]; primary_horizon = "30d"; setup = "early_recovery"
    elif rev["reversal_applies"]:
        selected = "reversal"; action = "LONG"; prob = rev["reversal_prob"]; primary_horizon = "90d"; setup = "bear_capitulation_reversal"
    elif fund["funding_squeeze_applies"]:
        selected = "funding_squeeze_reversal"; action = "LONG"; prob = fund["funding_squeeze_prob"]; primary_horizon = "30d"; setup = "negative_funding_capitulation_reversal"
    elif cont["continuation_applies"]:
        selected = "trend_continuation"; action = "LONG"; prob = 0.56; primary_horizon = "7d"; setup = "risk_on_fear_dip_continuation"

    tier = tier_from_prob(prob, selected if selected not in ("elite_reversal", "elite_continuation") else "cycle_reversal")
    if confluence_elite_long:
        tier = "elite"
    if tier == "none":
        action = "NO_TRADE"
    out = {}; out.update(cont); out.update(rev); out.update(cyc); out.update(fund); out.update(elite_cont_v2); out.update(funding_mode_flags(row))
    out.update({
        "selected_specialist": selected,
        "decision": action,
        "prob": prob,
        "tier": tier,
        "primary_horizon": primary_horizon,
        "setup_type": setup,
        "bullish_confluence_count": confluence_count,
        "bullish_confluence_label": confluence_label,
        "confluence_elite_long": confluence_elite_long,
        "confluence_elite_v25_long": confluence_elite_v25_long,
        "confluence_elite_strict_long": confluence_elite_strict_long,
        "secondary_horizon": "90d" if selected == "trend_continuation" else ("30d" if selected == "reversal" else ""),
    })
    return out


def date_keys(dt_text):
    """Return day/week/month keys for overlap-aware analysis without unsafe filesystem calls."""
    s = (dt_text or "")[:10]
    if len(s) != 10:
        return "", "", ""
    try:
        y, m, d = [int(x) for x in s.split("-")]
        dt = datetime.date(y, m, d)
        iso = dt.isocalendar()
        # Pythonista may return tuple on older Python or namedtuple on newer.
        iso_year = iso[0]
        iso_week = iso[1]
        return s, "%04d-W%02d" % (iso_year, iso_week), "%04d-%02d" % (y, m)
    except Exception:
        return s, s[:7], s[:7]


def output_dir_for_source(path):
    candidates = []
    try:
        if path and not str(path).lower().endswith(".zip"):
            d = os.path.dirname(os.path.abspath(path))
            if d: candidates.append(d)
    except Exception:
        pass
    candidates += [script_dir(), os.path.expanduser("~/Documents"), tempfile.gettempdir()]
    seen = []
    for d in candidates:
        try:
            if not d or d in seen or not os.path.isdir(d): continue
            seen.append(d)
            test = os.path.join(d, ".bee_write_test")
            with open(test, "w") as f: f.write("ok")
            try: os.remove(test)
            except Exception: pass
            return d
        except Exception:
            continue
    return script_dir()


def fmt(x, nd=6):
    if x is None: return ""
    if isinstance(x, bool): return "1" if x else "0"
    if isinstance(x, float): return ("%%.%df" % nd) % x
    return x


def signed_return_for_action(raw_ret, action):
    if raw_ret is None or action == "NO_TRADE": return None
    if action == "LONG": return raw_ret
    if action == "SHORT": return -raw_ret
    return None


def elite_family_from_debug(row, rev, cont, cyc):
    """Split the former confluence_elite bucket without losing v2.5 volume."""
    fg = row.get("fear_greed")
    dd = row.get("drawdown_from_ath")
    fund = row.get("funding_rate")
    reg = row.get("regime") or ""
    rev_like = bool(
        rev.get("reversal_applies")
        or reg in ("capitulation", "bear_trend")
        or (fg is not None and fg <= 25.0)
        or (dd is not None and dd <= -25.0)
        or (fund is not None and fund < 0.0 and fg is not None and fg < 35.0)
    )
    cont_like = bool(cont.get("continuation_applies") or reg in ("bull_trend", "transition"))
    if rev_like and not cont_like:
        return "elite_reversal", "elite_reversal_cycle_plus_reversal"
    if cont_like and not rev_like:
        return "elite_continuation", "elite_continuation_cycle_plus_continuation"
    if (fg is not None and fg <= 22.0) or (dd is not None and dd <= -30.0):
        return "elite_reversal", "elite_reversal_deep_fear_confluence"
    return "elite_continuation", "elite_continuation_recovery_trend_confluence"


def funding_mode_flags(row):
    fund = row.get("funding_rate")
    fg = row.get("fear_greed")
    if fund is None or fg is None:
        return {"funding_mode_strict": False, "funding_mode_medium": False, "funding_mode_loose": False}
    return {
        "funding_mode_strict": bool(fund < -0.00012 and fg < 22.0),
        "funding_mode_medium": bool(fund < -0.00010 and fg < 24.0),
        "funding_mode_loose": bool(fund < -0.00008 and fg < 25.0),
    }


def target_stop_model(row, selected, action, horizon):
    if action not in ("LONG", "SHORT") or selected == "none" or horizon == "none":
        return {}
    bars_by_h = dict(HORIZONS)
    bars = bars_by_h.get(horizon, 24)
    vol = row.get("volatility_24")
    if vol is None or vol <= 0:
        vol = 2.0
    caps = {
        "1h": (0.4, 2.0), "4h": (0.8, 3.5), "8h": (1.0, 4.5), "24h": (1.5, 6.0),
        "7d": (3.0, 12.0), "30d": (7.0, 25.0), "90d": (10.0, 40.0),
    }
    min_t, max_t = caps.get(horizon, (2.0, 15.0))
    raw_target = vol * math.sqrt(max(1.0, bars / 24.0)) * 1.25
    target_pct = max(min_t, min(max_t, raw_target))
    rr_by_specialist = {
        "funding_squeeze_reversal": 1.8,
        "trend_continuation": 1.7,
        "elite_continuation": 2.0,
        "reversal": 2.2,
        "cycle_reversal": 2.2,
        "elite_reversal": 2.5,
        "confluence_elite": 2.2,
    }
    rr = rr_by_specialist.get(selected, 2.0)
    stop_pct = max(0.5, target_pct / rr)
    entry = row.get("close")
    if entry in (None, 0):
        return {}
    if action == "LONG":
        target = entry * (1.0 + target_pct / 100.0)
        stop = entry * (1.0 - stop_pct / 100.0)
        target_delta = target - entry
        stop_delta = stop - entry
    else:
        target = entry * (1.0 - target_pct / 100.0)
        stop = entry * (1.0 + stop_pct / 100.0)
        target_delta = entry - target
        stop_delta = entry - stop
    return {
        "entry_price": entry,
        "target_price": target,
        "stop_price": stop,
        "planned_target_pct": target_pct,
        "planned_stop_pct": stop_pct,
        "planned_rr": rr,
        "target_delta_usd": target_delta,
        "stop_delta_usd": stop_delta,
    }


def precompute_future_extremes(rows):
    """Precompute future max(high)/min(low) for focused horizons in O(n).

    V2.9 needs per-timeframe trade quality. The old exact forward scan became too
    slow when repeated for 24h/7d/30d/90d on every selected row. This keeps MFE/MAE
    and target/stop hit detection fast enough for Pythonista.
    """
    n = len(rows)
    for label, bars in HORIZONS:
        if label not in FOCUSED_TRADE_HORIZONS and label not in ("1h", "4h", "8h"):
            continue
        dq_hi = deque(); dq_lo = deque()
        for i in range(n - 1, -1, -1):
            j = i + 1
            if j < n:
                hi = rows[j].get("high")
                lo = rows[j].get("low")
                if hi is not None:
                    while dq_hi and (rows[dq_hi[-1]].get("high") is None or rows[dq_hi[-1]].get("high") <= hi):
                        dq_hi.pop()
                    dq_hi.append(j)
                if lo is not None:
                    while dq_lo and (rows[dq_lo[-1]].get("low") is None or rows[dq_lo[-1]].get("low") >= lo):
                        dq_lo.pop()
                    dq_lo.append(j)
            max_j = i + bars
            while dq_hi and dq_hi[0] > max_j:
                dq_hi.popleft()
            while dq_lo and dq_lo[0] > max_j:
                dq_lo.popleft()
            rows[i]["__future_max_high_" + label] = rows[dq_hi[0]].get("high") if dq_hi else None
            rows[i]["__future_min_low_" + label] = rows[dq_lo[0]].get("low") if dq_lo else None


def future_trade_path_metrics(rows, idx, action, entry, target, stop, horizon):
    """Fast target/stop path metrics for V3.1 exit benchmark.

    V2.9.1 did exact bar-by-bar first-touch. V3.1 benchmarks multiple exit modes
    and position sizing, so it uses the precomputed future high/low envelope for speed.
    Critical safety retained: if target and stop both appear inside the same horizon,
    it is NOT forced to a loss; it is marked ambiguous and realised fixed PnL falls
    back to horizon-exit through pnl_from_trade_path.
    """
    bars_by_h = dict(HORIZONS)
    bars = bars_by_h.get(horizon, 0)
    if not bars or action not in ("LONG", "SHORT") or entry in (None, 0) or target is None or stop is None:
        return {}
    max_high = rows[idx].get("__future_max_high_" + horizon)
    min_low = rows[idx].get("__future_min_low_" + horizon)
    if max_high is None or min_low is None:
        return {}
    if action == "LONG":
        mfe_usd = max_high - entry
        mae_usd = min_low - entry
        mfe_pct = (max_high / entry - 1.0) * 100.0
        mae_pct = (min_low / entry - 1.0) * 100.0
        target_hit = max_high >= target
        stop_hit = min_low <= stop
    else:
        mfe_usd = entry - min_low
        mae_usd = entry - max_high
        mfe_pct = (entry / min_low - 1.0) * 100.0 if min_low not in (None, 0) else None
        mae_pct = (entry / max_high - 1.0) * 100.0 if max_high not in (None, 0) else None
        target_hit = min_low <= target
        stop_hit = max_high >= stop
    if target_hit and stop_hit:
        first_touch = "ambiguous_both_hit_mark_to_horizon"
    elif target_hit:
        first_touch = "target_first_envelope"
    elif stop_hit:
        first_touch = "stop_first_envelope"
    else:
        first_touch = "neither"
    return {
        "mfe_usd": mfe_usd, "mae_usd": mae_usd, "mfe_pct": mfe_pct, "mae_pct": mae_pct,
        "first_touch": first_touch,
        "target_hit": first_touch.startswith("target"),
        "stop_hit": first_touch.startswith("stop"),
        "bars_to_touch": "",
    }


def create_results_zip(out_path, summary_path=None):
    out_dir = os.path.dirname(os.path.abspath(out_path))
    zip_path = os.path.join(out_dir, RESULTS_ZIP)
    try:
        zf = zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=1)
    except TypeError:
        zf = zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED)
    with zf as z:
        z.write(out_path, os.path.basename(out_path))
        if summary_path and os.path.isfile(summary_path):
            z.write(summary_path, os.path.basename(summary_path))
    return zip_path





def recommended_trailing_pct(selected):
    """Family-specific wide trailing stop used by V3.1 exit benchmark.

    This is deliberately simple and auditable:
    - Funding squeeze: tighter because it can be tactical.
    - Continuation: medium-wide to survive normal trend pullbacks.
    - Reversal/cycle/elite reversal: wide because capitulation recoveries can shake out deeply.
    """
    s = (selected or "").lower()
    if "funding" in s:
        return 8.0
    if "continuation" in s:
        return 12.0
    if "reversal" in s or "cycle" in s:
        return 18.0
    return 15.0


def sizing_preview_fraction(selected, horizon, prob, signed_ret_pct, horizon_pnl_pct):
    """Very conservative position-sizing preview, not live advice.

    It converts engine class + confidence + horizon return into an indicative allocation bucket.
    This does NOT change raw trade PnL; it adds a portfolio-layer diagnostic so we can later
    study how big each setup should be.
    """
    s = (selected or "").lower()
    try:
        p = float(prob or 0.0)
    except Exception:
        p = 0.0
    try:
        edge = float(horizon_pnl_pct or signed_ret_pct or 0.0)
    except Exception:
        edge = 0.0
    base = 0.02
    if "elite_reversal" in s:
        base = 0.12
    elif "funding" in s:
        base = 0.10
    elif "cycle" in s:
        base = 0.09
    elif s == "reversal" or "reversal" in s:
        base = 0.08
    elif "trend_continuation" in s:
        base = 0.06
    elif "elite_continuation" in s:
        base = 0.05
    # horizon adjustment: short horizons get smaller, long-horizon alpha can be sized slightly larger.
    hmul = {"24h":0.70, "7d":0.90, "30d":1.00, "90d":1.05}.get(horizon, 0.85)
    # confidence adjustment. Prob in this research file is 0..1-ish.
    cmul = 0.75 + min(max(p, 0.0), 1.0) * 0.50
    # never reward negative expected horizon edge.
    emul = 1.0 if edge > 0 else 0.35
    frac = base * hmul * cmul * emul
    return max(0.0, min(frac, 0.25))

def horizon_exit_pnl(plan, signed_ret_pct):
    """Exit at the selected forecast horizon. This is the audit baseline.

    For long-horizon reversal/continuation engines, the external audit showed that
    fixed targets cut off most of the alpha. Horizon-exit keeps the full forecast
    window and lets us compare the engine edge against fixed target/stop.
    """
    entry = plan.get("entry_price")
    if entry in (None, "", 0) or signed_ret_pct in (None, ""):
        return {"pnl_usd": "", "pnl_pct": ""}
    try:
        pct = float(signed_ret_pct)
        return {"pnl_usd": float(entry) * pct / 100.0, "pnl_pct": pct}
    except Exception:
        return {"pnl_usd": "", "pnl_pct": ""}


def trailing_exit_eval(rows, idx, action, entry, horizon, trail_pct, signed_ret_pct):
    """No-lookahead bar-by-bar wide trailing exit.

    V3.4 fix: the old V3.4 implementation used future max_high/min_low from the
    whole horizon and could therefore set the trailing stop from a peak that had
    not happened yet. This function walks forward candle by candle and updates
    the running peak/trough only after the prior trailing level has been tested.

    Conservative intrabar rule:
    - LONG: test the existing trailing level against the current bar low first,
      then update the peak with the current bar high.
    - SHORT: test the existing trailing level against the current bar high first,
      then update the trough with the current bar low.

    This removes the lookahead and may understate some same-bar wins, which is
    safer for research than overstating them.
    """
    if action not in ("LONG", "SHORT") or entry in (None, "", 0):
        return {"pnl_usd": "", "pnl_pct": "", "exit_type": "", "bars_to_exit": ""}
    try:
        entry = float(entry)
        trail_pct = float(trail_pct)
    except Exception:
        return {"pnl_usd": "", "pnl_pct": "", "exit_type": "", "bars_to_exit": ""}
    bars = int(dict(HORIZONS).get(horizon, 24) or 24)
    if idx >= len(rows) - 1:
        hz = horizon_exit_pnl({"entry_price": entry}, signed_ret_pct)
        hz["exit_type"] = "horizon_exit_no_future_bars"
        hz["bars_to_exit"] = 0
        return hz

    end_idx = min(len(rows) - 1, idx + bars)
    if action == "LONG":
        running_peak = entry
        for j in range(idx + 1, end_idx + 1):
            try:
                low = float(rows[j].get("low") or rows[j].get("close") or 0.0)
                high = float(rows[j].get("high") or rows[j].get("close") or 0.0)
            except Exception:
                continue
            trail_level = running_peak * (1.0 - trail_pct / 100.0)
            if running_peak > entry and low <= trail_level:
                pct = (trail_level / entry - 1.0) * 100.0
                return {"pnl_usd": entry * pct / 100.0, "pnl_pct": pct, "exit_type": "wide_trailing_bar_by_bar", "bars_to_exit": j - idx}
            if high > running_peak:
                running_peak = high
    else:
        running_trough = entry
        for j in range(idx + 1, end_idx + 1):
            try:
                high = float(rows[j].get("high") or rows[j].get("close") or 0.0)
                low = float(rows[j].get("low") or rows[j].get("close") or 0.0)
            except Exception:
                continue
            trail_level = running_trough * (1.0 + trail_pct / 100.0)
            if running_trough < entry and high >= trail_level:
                pct = (entry / trail_level - 1.0) * 100.0
                return {"pnl_usd": entry * pct / 100.0, "pnl_pct": pct, "exit_type": "wide_trailing_bar_by_bar", "bars_to_exit": j - idx}
            if low < running_trough:
                running_trough = low

    # No trailing hit: exit at the horizon close / forward return.
    hz = horizon_exit_pnl({"entry_price": entry}, signed_ret_pct)
    hz["exit_type"] = "horizon_exit"
    hz["bars_to_exit"] = end_idx - idx
    return hz

def add_exit_mode_evals(rec, rows, idx, selected, action, plan, horizon, suffix=""):
    signed = rec.get("signed_ret_" + horizon)
    hz = horizon_exit_pnl(plan, signed)
    rec["horizon_exit_pnl_usd" + suffix] = hz.get("pnl_usd", "")
    rec["horizon_exit_pnl_pct" + suffix] = hz.get("pnl_pct", "")
    tp = recommended_trailing_pct(selected)
    tr = trailing_exit_eval(rows, idx, action, plan.get("entry_price"), horizon, tp, signed)
    rec["wide_trailing_pct" + suffix] = tp
    rec["wide_trailing_pnl_usd" + suffix] = tr.get("pnl_usd", "")
    rec["wide_trailing_pnl_pct" + suffix] = tr.get("pnl_pct", "")
    rec["wide_trailing_exit_type" + suffix] = tr.get("exit_type", "")
    rec["wide_trailing_bars_to_exit" + suffix] = tr.get("bars_to_exit", "")
    size = sizing_preview_fraction(selected, horizon, rec.get("prob", ""), signed, hz.get("pnl_pct", ""))
    rec["position_size_preview_pct" + suffix] = size * 100.0
    rec["sized_horizon_pnl_pct" + suffix] = (float(hz.get("pnl_pct") or 0.0) * size) if hz.get("pnl_pct", "") != "" else ""
    rec["sized_wide_trailing_pnl_pct" + suffix] = (float(tr.get("pnl_pct") or 0.0) * size) if tr.get("pnl_pct", "") != "" else ""

def pnl_from_trade_path(plan, pathq, signed_ret_pct):
    """Realised PnL proxy for a horizon.

    V2.9.1: target_first -> planned target; stop_first -> planned stop;
    neither or ambiguous_same_bar_mark_to_horizon -> horizon-exit signed return.
    This prevents the long-horizon both-hit measurement bug from forcing losses.
    """
    entry = plan.get("entry_price")
    if entry in (None, "", 0):
        return {"pnl_usd": "", "pnl_pct": ""}
    ft = pathq.get("first_touch", "")
    if ft.startswith("target"):
        return {"pnl_usd": plan.get("target_delta_usd", ""), "pnl_pct": plan.get("planned_target_pct", "")}
    if ft.startswith("stop"):
        return {"pnl_usd": plan.get("stop_delta_usd", ""), "pnl_pct": -abs(plan.get("planned_stop_pct", 0.0) or 0.0)}
    if signed_ret_pct in (None, ""):
        return {"pnl_usd": "", "pnl_pct": ""}
    try:
        pct = float(signed_ret_pct)
        return {"pnl_usd": float(entry) * pct / 100.0, "pnl_pct": pct}
    except Exception:
        return {"pnl_usd": "", "pnl_pct": ""}


def add_trade_quality_for_horizon(rec, rows, idx, r, selected, action, horizon, suffix=""):
    plan = target_stop_model(r, selected, action, horizon)
    pathq = future_trade_path_metrics(rows, idx, action, plan.get("entry_price"), plan.get("target_price"), plan.get("stop_price"), horizon)
    signed = rec.get("signed_ret_" + horizon)
    pnl = pnl_from_trade_path(plan, pathq, signed)
    base_keys = [
        "entry_price", "target_price", "stop_price", "planned_target_pct", "planned_stop_pct", "planned_rr",
        "target_delta_usd", "stop_delta_usd", "mfe_usd", "mae_usd", "mfe_pct", "mae_pct",
        "first_touch", "target_hit", "stop_hit", "bars_to_touch", "pnl_usd", "pnl_pct",
    ]
    for k in base_keys:
        if k in ("pnl_usd", "pnl_pct"):
            val = pnl.get(k, "")
        else:
            val = pathq.get(k, plan.get(k, ""))
        rec[k + suffix] = val
    add_exit_mode_evals(rec, rows, idx, selected, action, plan, horizon, suffix)

def write_results(rows, source_path):
    precompute_future_extremes(rows)
    out_dir = output_dir_for_source(source_path)
    out_path = os.path.join(out_dir, RESULTS_CSV)
    base_fields = [
        "version", "row_index", "open_time", "dt", "year", "day_key", "week_key", "month_key", "close", "regime",
        "risk_state", "spx_ret_1w", "macro_safe", "macro_source", "macro_bad",
        "selected_specialist", "setup_type", "decision", "primary_horizon", "secondary_horizon", "tier", "prob",
        "return_primary", "win_primary", "independent_week", "independent_month", "independent_day",
        "bullish_confluence_count", "bullish_confluence_label", "confluence_elite_long", "confluence_elite_v25_long", "confluence_elite_strict_long",
    ]
    horizon_fields = []
    for label, _bars in HORIZONS:
        horizon_fields += ["ret_" + label, "ret_" + label + "_valid", "signed_ret_" + label, "win_" + label]
    trade_fields = [
        "entry_price", "target_price", "stop_price", "planned_target_pct", "planned_stop_pct", "planned_rr",
        "target_delta_usd", "stop_delta_usd", "mfe_usd", "mae_usd", "mfe_pct", "mae_pct",
        "first_touch", "target_hit", "stop_hit", "bars_to_touch", "pnl_usd", "pnl_pct",
    ]
    # V2.9/V3.0: extra trade-quality blocks for each relevant forecast timeframe.
    exit_base_fields = [
        "horizon_exit_pnl_usd", "horizon_exit_pnl_pct",
        "wide_trailing_pct", "wide_trailing_pnl_usd", "wide_trailing_pnl_pct", "wide_trailing_exit_type", "wide_trailing_bars_to_exit",
        "position_size_preview_pct", "sized_horizon_pnl_pct", "sized_wide_trailing_pnl_pct",
    ]
    trade_fields += exit_base_fields
    for _h in FOCUSED_TRADE_HORIZONS:
        trade_fields += [
            "entry_price_" + _h, "target_price_" + _h, "stop_price_" + _h,
            "planned_target_pct_" + _h, "planned_stop_pct_" + _h, "planned_rr_" + _h,
            "target_delta_usd_" + _h, "stop_delta_usd_" + _h,
            "mfe_usd_" + _h, "mae_usd_" + _h, "mfe_pct_" + _h, "mae_pct_" + _h,
            "first_touch_" + _h, "target_hit_" + _h, "stop_hit_" + _h, "bars_to_touch_" + _h,
            "pnl_usd_" + _h, "pnl_pct_" + _h,
            "horizon_exit_pnl_usd_" + _h, "horizon_exit_pnl_pct_" + _h,
            "wide_trailing_pct_" + _h, "wide_trailing_pnl_usd_" + _h, "wide_trailing_pnl_pct_" + _h, "wide_trailing_exit_type_" + _h, "wide_trailing_bars_to_exit_" + _h,
            "position_size_preview_pct_" + _h, "sized_horizon_pnl_pct_" + _h, "sized_wide_trailing_pnl_pct_" + _h,
        ]
    diag_fields = [
        "canonical_trend_ok", "bug_trend_ok", "trend_ok_used", "ma50_distance_canonical", "ma200_distance_canonical",
        "cont_risk_on_ok", "cont_regime_ok", "cont_momentum_ok", "cont_coinbase_ok", "cont_sentiment_ok", "cont_overheat", "cont_reject_reason", "continuation_applies",
        "reversal_applies", "reversal_prob",
        "cycle_early_recovery_long", "cycle_late_warning_short", "cycle_reason", "cycle_prob_long", "cycle_prob_short", "cycle_mom_4h", "cycle_mom_7d",
        "elite_continuation_v2_applies", "elite_continuation_v2_prob", "elite_continuation_v2_score", "elite_continuation_v2_reject_reason", "elite_continuation_v2_regime_ok", "elite_continuation_v2_trend_ok", "elite_continuation_v2_risk_ok", "elite_continuation_v2_sentiment_ok", "elite_continuation_v2_coinbase_ok", "elite_continuation_v2_momentum_ok", "elite_continuation_v2_not_overheated",
        "funding_squeeze_applies", "funding_squeeze_simple_applies", "funding_mode_strict", "funding_mode_medium", "funding_mode_loose", "funding_squeeze_prob", "funding_squeeze_reason", "funding_squeeze_reject_reason", "funding_squeeze_funding_ok", "funding_squeeze_fear_ok", "funding_squeeze_drawdown_ok", "funding_squeeze_rsi_ok", "funding_squeeze_selloff_ok", "funding_squeeze_coinbase_ok", "funding_squeeze_regime_ok", "funding_squeeze_reversal_hint", "funding_squeeze_context_score",
        "coinbase_premium_pct", "funding_rate", "fear_greed", "rsi_14", "return_1", "return_4", "return_24", "past_ret_4h", "past_ret_7d", "past_ret_30d", "ma_50", "ma_200", "drawdown_from_ath",
    ]
    fields = base_fields + horizon_fields + trade_fields + diag_fields
    n = 0
    seen_week = set(); seen_month = set(); seen_day = set()
    with open(out_path, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=fields)
        w.writeheader()
        for idx, r in enumerate(rows):
            if r.get("corrupt"):
                continue
            d = decide(r)
            day_key, week_key, month_key = date_keys(r.get("dt"))
            ind_day = ind_week = ind_month = False
            if d["decision"] in ("LONG", "SHORT"):
                dedup_key_day = (d["selected_specialist"], d["setup_type"], d["decision"], d["primary_horizon"], day_key)
                dedup_key_week = (d["selected_specialist"], d["setup_type"], d["decision"], d["primary_horizon"], week_key)
                dedup_key_month = (d["selected_specialist"], d["setup_type"], d["decision"], d["primary_horizon"], month_key)
                if dedup_key_day not in seen_day:
                    ind_day = True; seen_day.add(dedup_key_day)
                if dedup_key_week not in seen_week:
                    ind_week = True; seen_week.add(dedup_key_week)
                if dedup_key_month not in seen_month:
                    ind_month = True; seen_month.add(dedup_key_month)
            rec = {
                "version": VERSION, "row_index": idx, "open_time": r.get("open_time"), "dt": r.get("dt"), "year": (r.get("dt") or "0000")[:4],
                "day_key": day_key, "week_key": week_key, "month_key": month_key,
                "close": r.get("close"), "regime": r.get("regime"),
                "risk_state": d["risk_state"], "spx_ret_1w": d["spx_ret_1w"], "macro_safe": d["macro_safe"], "macro_source": r.get("macro_source"), "macro_bad": r.get("macro_bad"),
                "selected_specialist": d["selected_specialist"], "setup_type": d["setup_type"], "decision": d["decision"], "primary_horizon": d["primary_horizon"], "secondary_horizon": d.get("secondary_horizon", ""), "tier": d["tier"], "prob": d["prob"],
                "independent_week": ind_week, "independent_month": ind_month, "independent_day": ind_day,
                "bullish_confluence_count": d.get("bullish_confluence_count", 0), "bullish_confluence_label": d.get("bullish_confluence_label", ""), "confluence_elite_long": d.get("confluence_elite_long", False), "confluence_elite_v25_long": d.get("confluence_elite_v25_long", False), "confluence_elite_strict_long": d.get("confluence_elite_strict_long", False),
            }
            # all horizon eval labels
            for label, _bars in HORIZONS:
                raw = r.get("ret_" + label)
                signed = signed_return_for_action(raw, d["decision"])
                rec["ret_" + label] = raw
                rec["ret_" + label + "_valid"] = r.get("ret_" + label + "_valid")
                rec["signed_ret_" + label] = signed
                rec["win_" + label] = "" if signed is None else (1 if signed > 0 else 0)
            ph = d["primary_horizon"]
            if ph != "none":
                rec["return_primary"] = rec.get("signed_ret_" + ph)
                rec["win_primary"] = rec.get("win_" + ph)
            else:
                rec["return_primary"] = None
                rec["win_primary"] = ""
            add_trade_quality_for_horizon(rec, rows, idx, r, d["selected_specialist"], d["decision"], d["primary_horizon"])
            for _h in FOCUSED_TRADE_HORIZONS:
                add_trade_quality_for_horizon(rec, rows, idx, r, d["selected_specialist"], d["decision"], _h, "_" + _h)
            for k in trade_fields:
                if k not in rec:
                    rec[k] = ""
            for k in diag_fields:
                rec[k] = d.get(k, r.get(k, ""))
            w.writerow({k: fmt(rec.get(k)) for k in fields})
            n += 1
    return out_path, n


def summarize_output(path):
    counts = {}; by_primary = {}; tiers = {}; horizon_stats = {}; setup_stats = {}; reasons = {}
    weekly_primary = {}; monthly_primary = {}; daily_primary = {}; confluence = {}
    funding_all_24h = {"raw":{"n":0,"w":0,"sum":0.0}, "day":{"n":0,"w":0,"sum":0.0}, "week":{"n":0,"w":0,"sum":0.0}}
    funding_seen_day = set(); funding_seen_week = set()
    trade_quality = {}
    for label, _bars in HORIZONS:
        horizon_stats[label] = {"n":0, "w":0, "sum":0.0}
    with open(path, newline="", encoding="utf-8") as fh:
        for r in csv.DictReader(fh):
            s = r["selected_specialist"]; counts[s] = counts.get(s, 0) + 1
            reasons[r.get("cont_reject_reason", "")] = reasons.get(r.get("cont_reject_reason", ""), 0) + 1
            # FundingSqueeze diagnostic across ALL rows where the condition applies,
            # even when a higher-priority long-horizon specialist selected the row.
            if r.get("funding_squeeze_applies") == "1" and r.get("ret_24h", "") != "":
                try:
                    xfs = float(r.get("ret_24h") or 0.0)
                    funding_all_24h["raw"]["n"] += 1
                    funding_all_24h["raw"]["sum"] += xfs
                    if xfs > 0: funding_all_24h["raw"]["w"] += 1
                    dk = r.get("day_key", "")
                    wk = r.get("week_key", "")
                    if dk and dk not in funding_seen_day:
                        funding_seen_day.add(dk)
                        funding_all_24h["day"]["n"] += 1
                        funding_all_24h["day"]["sum"] += xfs
                        if xfs > 0: funding_all_24h["day"]["w"] += 1
                    if wk and wk not in funding_seen_week:
                        funding_seen_week.add(wk)
                        funding_all_24h["week"]["n"] += 1
                        funding_all_24h["week"]["sum"] += xfs
                        if xfs > 0: funding_all_24h["week"]["w"] += 1
                except Exception:
                    pass
            if r["decision"] in ("LONG", "SHORT"):
                ph = r["primary_horizon"]
                key = (s, ph)
                tq = trade_quality.setdefault(key, {"n":0,"target_hit":0,"stop_hit":0,"neither":0,"entry_sum":0.0,"target_delta_sum":0.0,"stop_delta_sum":0.0,"mfe_sum":0.0,"mae_sum":0.0,"rr_sum":0.0})
                tq["n"] += 1
                try: tq["entry_sum"] += float(r.get("entry_price") or 0.0)
                except Exception: pass
                try: tq["target_delta_sum"] += float(r.get("target_delta_usd") or 0.0)
                except Exception: pass
                try: tq["stop_delta_sum"] += float(r.get("stop_delta_usd") or 0.0)
                except Exception: pass
                try: tq["mfe_sum"] += float(r.get("mfe_usd") or 0.0)
                except Exception: pass
                try: tq["mae_sum"] += float(r.get("mae_usd") or 0.0)
                except Exception: pass
                try: tq["rr_sum"] += float(r.get("planned_rr") or 0.0)
                except Exception: pass
                if r.get("target_hit") == "1": tq["target_hit"] += 1
                elif r.get("stop_hit") == "1": tq["stop_hit"] += 1
                else: tq["neither"] += 1
                by_primary.setdefault(key, {"n":0,"w":0,"sum":0.0})
                by_primary[key]["n"] += 1
                if r.get("win_primary") == "1": by_primary[key]["w"] += 1
                try: by_primary[key]["sum"] += float(r.get("return_primary") or 0)
                except Exception: pass
                if r.get("independent_week") == "1":
                    weekly_primary.setdefault(key, {"n":0,"w":0,"sum":0.0})
                    weekly_primary[key]["n"] += 1
                    if r.get("win_primary") == "1": weekly_primary[key]["w"] += 1
                    try: weekly_primary[key]["sum"] += float(r.get("return_primary") or 0)
                    except Exception: pass
                if r.get("independent_month") == "1":
                    monthly_primary.setdefault(key, {"n":0,"w":0,"sum":0.0})
                    monthly_primary[key]["n"] += 1
                    if r.get("win_primary") == "1": monthly_primary[key]["w"] += 1
                    try: monthly_primary[key]["sum"] += float(r.get("return_primary") or 0)
                    except Exception: pass
                if r.get("independent_day") == "1":
                    daily_primary.setdefault(key, {"n":0,"w":0,"sum":0.0})
                    daily_primary[key]["n"] += 1
                    if r.get("win_primary") == "1": daily_primary[key]["w"] += 1
                    try: daily_primary[key]["sum"] += float(r.get("return_primary") or 0)
                    except Exception: pass
                tier_key = (s, r.get("tier", "none"), ph)
                tiers.setdefault(tier_key, {"n":0,"w":0,"sum":0.0})
                tiers[tier_key]["n"] += 1
                if r.get("win_primary") == "1": tiers[tier_key]["w"] += 1
                try: tiers[tier_key]["sum"] += float(r.get("return_primary") or 0)
                except Exception: pass
                setup_key = (s, r.get("setup_type", "none"), ph)
                setup_stats.setdefault(setup_key, {"n":0,"w":0,"sum":0.0})
                setup_stats[setup_key]["n"] += 1
                if r.get("win_primary") == "1": setup_stats[setup_key]["w"] += 1
                try: setup_stats[setup_key]["sum"] += float(r.get("return_primary") or 0)
                except Exception: pass
                if r.get("confluence_elite_long") == "1":
                    ck = ("confluence_elite_long", ph)
                    confluence.setdefault(ck, {"n":0,"w":0,"sum":0.0})
                    confluence[ck]["n"] += 1
                    if r.get("win_primary") == "1": confluence[ck]["w"] += 1
                    try: confluence[ck]["sum"] += float(r.get("return_primary") or 0)
                    except Exception: pass
                for label, _bars in HORIZONS:
                    val = r.get("signed_ret_" + label, "")
                    if val != "":
                        try:
                            x = float(val)
                            horizon_stats[label]["n"] += 1
                            horizon_stats[label]["sum"] += x
                            if x > 0: horizon_stats[label]["w"] += 1
                        except Exception:
                            pass
    def line_stats(name, st):
        n = st["n"]; wr = (st["w"] / n * 100.0) if n else 0.0; avg = (st["sum"] / n) if n else 0.0
        print("%s: n=%d winrate=%.1f%% avg=%.3f%%" % (name, n, wr, avg))
    print("\nSamenvatting:")
    print("selected_specialist:", counts)
    print("\nPrimary horizon stats hourly/all signals:")
    for key in sorted(by_primary.keys()): line_stats(str(key), by_primary[key])
    print("\nOverlap-aware primary stats: independent one per DAY:")
    for key in sorted(daily_primary.keys()): line_stats(str(key), daily_primary[key])
    print("\nOverlap-aware primary stats: independent one per WEEK:")
    for key in sorted(weekly_primary.keys()): line_stats(str(key), weekly_primary[key])
    print("\nOverlap-aware primary stats: independent one per MONTH:")
    for key in sorted(monthly_primary.keys()): line_stats(str(key), monthly_primary[key])
    print("\nAll signals by horizon:")
    for label, _bars in HORIZONS: line_stats(label, horizon_stats[label])
    print("\nSetup stats:")
    for key in sorted(setup_stats.keys()): line_stats(str(key), setup_stats[key])
    print("\nTier stats:")
    for key in sorted(tiers.keys()): line_stats(str(key), tiers[key])
    print("\nConfluence stats:")
    for key in sorted(confluence.keys()): line_stats(str(key), confluence[key])
    print("\nTrade Quality / dollar metrics by selected specialist + primary horizon:")
    for key in sorted(trade_quality.keys()):
        tq = trade_quality[key]; n = tq.get("n", 0) or 1
        print("%s: n=%d avg_entry=$%.0f avg_target_delta=$%.0f avg_stop_delta=$%.0f avg_mfe=$%.0f avg_mae=$%.0f target_hit=%.1f%% stop_hit=%.1f%% neither=%.1f%% avg_rr=%.2f" % (
            str(key), tq.get("n",0), tq["entry_sum"]/n, tq["target_delta_sum"]/n, tq["stop_delta_sum"]/n,
            tq["mfe_sum"]/n, tq["mae_sum"]/n, tq["target_hit"]/n*100.0, tq["stop_hit"]/n*100.0, tq["neither"]/n*100.0, tq["rr_sum"]/n))

    print("\nFundingSqueeze diagnostics: selected v2.8 reversal engine uses loose-selected squeeze filters; strict/medium/loose flags are exported for comparison:")
    for key in ["raw", "day", "week"]:
        line_stats("funding_squeeze_simple_all_24h_" + key, funding_all_24h[key])
    top = sorted(reasons.items(), key=lambda kv: kv[1], reverse=True)[:8]
    print("\ncontinuation reject top:", top)




def _bars_for_horizon(h):
    return dict(HORIZONS).get(h, 24)


def _best_exit_mode_for_engine(selected):
    """V3.2 default engine-specific exit choice from V3.1 audit.

    This is not final trading advice. It is a research-policy benchmark:
    - ReversalAlpha + EliteReversal: horizon exit, because fixed targets cut the swing short.
    - CycleReversal + TrendContinuation + FundingSqueeze: wide trailing, because V3.1 showed better capture.
    - EliteContinuation: wide trailing while the engine remains under investigation.
    """
    s=(selected or '').lower()
    if 'funding' in s:
        return 'wide_trailing'
    if 'cycle' in s:
        return 'wide_trailing'
    if 'trend_continuation' in s or 'elite_continuation' in s:
        return 'wide_trailing'
    # V3.4 audit correction: EliteReversal captures more alpha with wide trailing than horizon exit.
    if 'elite_reversal' in s:
        return 'wide_trailing'
    if s == 'reversal' or 'reversal' in s:
        return 'horizon_exit'
    return 'horizon_exit'


def _confidence_size_pct(prob):
    try:
        p=float(prob or 0.0)
    except Exception:
        p=0.0
    if p >= 0.90: return 0.15
    if p >= 0.80: return 0.12
    if p >= 0.70: return 0.08
    if p >= 0.60: return 0.05
    return 0.03


def _smart_engine_size_pct(selected):
    s=(selected or '').lower()
    # User requested a 10,000 USD account. These are conservative allocation buckets.
    if 'elite_reversal' in s: return 0.15
    if 'funding' in s: return 0.12
    if 'cycle' in s: return 0.10
    if s == 'reversal' or 'reversal' in s: return 0.08
    if 'trend_continuation' in s: return 0.05
    if 'elite_continuation' in s: return 0.03
    return 0.02


def _pnl_pct_for_exit(row, h, exit_mode):
    if exit_mode == 'fixed_target_stop':
        col='pnl_pct_' + h
    elif exit_mode == 'wide_trailing':
        col='wide_trailing_pnl_pct_' + h
    else:
        col='horizon_exit_pnl_pct_' + h
    try:
        return float(row.get(col) or 0.0)
    except Exception:
        return 0.0



def _cluster_type(selected):
    s=(selected or '').lower()
    if 'funding' in s:
        return 'funding'
    if 'trend_continuation' in s or 'elite_continuation' in s:
        return 'continuation'
    if 'reversal' in s or 'cycle' in s:
        return 'reversal'
    return 'other'


def _signal_priority(row):
    s=(row.get('selected_specialist') or '').lower()
    # Pick the strongest representative when multiple engines fire in the same correlated event.
    if 'elite_reversal' in s: return 90
    if 'funding' in s: return 85
    if 'cycle' in s: return 80
    if s == 'reversal' or 'reversal' in s: return 70
    if 'trend_continuation' in s: return 60
    if 'elite_continuation' in s: return 55
    return 10


def _friction_per_side_pct(row):
    """Fee + slippage per side.

    Fee assumption: 0.10%.
    Normal slippage assumption: 0.15%.
    Capitulation / panic-style signals: 0.40% slippage, so 0.50% total per side.
    This deliberately penalizes the exact moments where these engines often fire.
    """
    s=(row.get('selected_specialist') or '').lower()
    reg=(row.get('regime') or '').lower()
    panic = ('capitulation' in reg) or ('funding' in s) or ('cycle' in s) or ('elite_reversal' in s)
    return 0.50 if panic else 0.25


def _dedup_correlation_windows(raw_rows, window_bars=48):
    """Collapse highly correlated signals into one event per cluster family.

    The v3.2 audit showed that a single capitulation month can trigger hundreds of
    overlapping LONG signals. Treating Reversal, CycleReversal and EliteReversal as
    independent positions double-counts the same BTC bounce. This function groups
    signals by cluster type and direction inside a rolling 48h window, keeping only the
    strongest representative signal for that event.
    """
    removed = 0
    clusters = {}
    out = []
    # raw_rows: list of (entry_idx, row)
    for entry_idx, row in sorted(raw_rows, key=lambda x: x[0]):
        ctype = _cluster_type(row.get('selected_specialist'))
        direction = row.get('decision') or 'LONG'
        key = (ctype, direction)
        cur = clusters.get(key)
        if cur is None or entry_idx > cur['end_idx']:
            if cur is not None:
                out.append((cur['best_idx'], cur['best_row'], cur['members']))
            clusters[key] = {
                'start_idx': entry_idx,
                'end_idx': entry_idx + window_bars,
                'best_idx': entry_idx,
                'best_row': row,
                'best_pri': _signal_priority(row),
                'members': 1,
            }
        else:
            cur['members'] += 1
            removed += 1
            pri = _signal_priority(row)
            if pri > cur['best_pri']:
                cur['best_idx'] = entry_idx
                cur['best_row'] = row
                cur['best_pri'] = pri
            # Keep the event window anchored to the first signal, not endlessly extended.
    for cur in clusters.values():
        out.append((cur['best_idx'], cur['best_row'], cur['members']))
    out.sort(key=lambda x: x[0])
    return out, removed



def simulate_portfolio_from_csv(path, sizing_mode='equal_weight', exit_policy='engine_best', price_rows=None, reality_mode=True):
    """V3.4 portfolio reality simulator.

    Fixes from the v3.3 Claude audit:
    1) Full mark-to-market equity is calculated on every candle from cash plus the
       current value of every open trade, so overlapping open losses stack.
    2) Correlation-aware clustering remains enabled so clustered capitulation
       signals are not counted as independent positions.
    3) Fees/slippage remain applied.

    This is intentionally more conservative and should replace the V3.4 flash-MAE
    proxy that only injected each trade's worst drawdown on its entry bar.
    """
    raw=[]
    with open(path, newline='', encoding='utf-8') as fh:
        for r in csv.DictReader(fh):
            if r.get('decision') not in ('LONG','SHORT'):
                continue
            if PORTFOLIO_USE_DEDUP_FIELD and r.get(PORTFOLIO_USE_DEDUP_FIELD) != '1':
                continue
            h=r.get('primary_horizon') or '24h'
            if h not in FOCUSED_TRADE_HORIZONS:
                continue
            try:
                entry_idx=int(float(r.get('row_index') or 0))
            except Exception:
                continue
            raw.append((entry_idx, r))
    raw.sort(key=lambda x: x[0])
    if reality_mode:
        clustered, corr_removed = _dedup_correlation_windows(raw, 48)
    else:
        clustered=[(i,r,1) for i,r in raw]; corr_removed=0

    entries_by_idx={}
    for entry_idx, row, members in clustered:
        entries_by_idx.setdefault(entry_idx, []).append((row, members))

    n_bars = len(price_rows or [])
    if n_bars <= 0:
        n_bars = max([i for i,_,_ in clustered], default=0) + 1

    cash=START_EQUITY_USD
    peak=START_EQUITY_USD
    max_dd=0.0
    dd_sum=0.0; dd_n=0
    worst_open_trade_dd=0.0
    open_trades=[]  # dicts: exit_idx, stake, pnl_pct, eng, action, entry_price, friction_side
    trades=0; skipped=0; wins=0
    gross_profit=0.0; gross_loss=0.0
    by_engine={}
    curve=[]
    recovery_bars_max=0; current_underwater_start=None

    def _close_price_at(idx):
        if price_rows and 0 <= idx < len(price_rows):
            try:
                return float(price_rows[idx].get('close') or 0.0)
            except Exception:
                return 0.0
        return 0.0

    def total_equity_mtm(idx):
        close=_close_price_at(idx)
        eq=cash
        for t in open_trades:
            entry=t.get('entry_price') or 0.0
            stake=t.get('stake') or 0.0
            if entry <= 0 or close <= 0:
                value=stake
            elif t.get('action') == 'SHORT':
                pct=(entry / close - 1.0) * 100.0
                value=stake * (1.0 + pct/100.0)
            else:
                pct=(close / entry - 1.0) * 100.0
                value=stake * (1.0 + pct/100.0)
            # Hypothetical exit friction if marked to market right now.
            value -= stake * (t.get('friction_side') or 0.0) / 100.0
            if value < 0:
                value = 0.0
            eq += value
        return eq

    def mark_equity(idx, eq):
        nonlocal peak, max_dd, dd_sum, dd_n, current_underwater_start, recovery_bars_max
        if eq > peak:
            if current_underwater_start is not None:
                recovery_bars_max=max(recovery_bars_max, idx-current_underwater_start)
                current_underwater_start=None
            peak=eq
        dd=(eq/peak-1.0)*100.0 if peak else 0.0
        if dd < 0 and current_underwater_start is None:
            current_underwater_start=idx
        if dd < max_dd: max_dd=dd
        dd_sum += dd; dd_n += 1
        # Store a compact curve, not every single flat hour if nothing is open.
        if open_trades or idx in entries_by_idx or (len(curve) == 0) or idx == n_bars - 1:
            curve.append((idx, eq))

    def close_due(idx):
        nonlocal cash, open_trades, wins, gross_profit, gross_loss
        remaining=[]
        for t in open_trades:
            if t['exit_idx'] <= idx:
                pnl = t['stake'] * t['pnl_pct'] / 100.0
                cash += t['stake'] + pnl
                if pnl >= 0:
                    wins += 1; gross_profit += pnl
                else:
                    gross_loss += abs(pnl)
                eng=t['eng']
                be=by_engine.setdefault(eng, {'n':0,'wins':0,'pnl':0.0})
                be['n'] += 1; be['pnl'] += pnl
                if pnl >= 0: be['wins'] += 1
            else:
                remaining.append(t)
        open_trades=remaining

    # Simulate bar by bar so overlapping open losses are stacked in equity.
    max_idx = n_bars - 1
    if clustered:
        max_exit_possible = max(i + _bars_for_horizon((r.get('primary_horizon') or '24h')) for i,r,_m in clustered)
        max_idx = min(n_bars - 1, max(max_idx, min(n_bars - 1, max_exit_possible)))

    for idx in range(0, max_idx + 1):
        close_due(idx)
        mark_equity(idx, total_equity_mtm(idx))

        if idx not in entries_by_idx:
            continue
        for r, members in entries_by_idx[idx]:
            eq_now=total_equity_mtm(idx)
            used=sum(t['stake'] for t in open_trades)
            h=r.get('primary_horizon') or '24h'
            eng=r.get('selected_specialist') or 'unknown'
            action=r.get('decision') or 'LONG'
            if exit_policy == 'engine_best':
                exit_mode=_best_exit_mode_for_engine(eng)
            else:
                exit_mode=exit_policy
            pnl_pct=_pnl_pct_for_exit(r, h, exit_mode)
            if sizing_mode == 'equal_weight':
                frac=0.10
            elif sizing_mode == 'confidence_weight':
                frac=_confidence_size_pct(r.get('prob'))
            else:
                frac=_smart_engine_size_pct(eng)
            stake=eq_now*frac
            cap=eq_now*PORTFOLIO_EXPOSURE_CAP
            if used + stake > cap:
                skipped += 1
                continue
            try:
                entry_price=float(r.get('entry_price_' + h) or r.get('entry_price') or _close_price_at(idx) or 0.0)
            except Exception:
                entry_price=_close_price_at(idx)
            if entry_price <= 0:
                skipped += 1
                continue
            friction_side=_friction_per_side_pct(r)
            entry_cost = stake * friction_side / 100.0
            cash -= (stake + entry_cost)
            pnl_after_cost = pnl_pct - friction_side  # exit-side cost; entry-side already paid.
            # Use real trailing exit timing when available; otherwise horizon.
            exit_bars=_bars_for_horizon(h)
            if exit_mode == 'wide_trailing':
                try:
                    b=float(r.get('wide_trailing_bars_to_exit_' + h) or r.get('wide_trailing_bars_to_exit') or '')
                    if b >= 0:
                        exit_bars=int(b)
                except Exception:
                    pass
            elif exit_mode == 'fixed_target_stop':
                try:
                    b=float(r.get('bars_to_touch_' + h) or r.get('bars_to_touch') or '')
                    if b >= 0:
                        exit_bars=int(b)
                except Exception:
                    pass
            exit_idx=min(n_bars - 1, idx + max(1, exit_bars))
            open_trades.append({'exit_idx':exit_idx,'stake':stake,'pnl_pct':pnl_after_cost,'eng':eng,'action':action,'entry_price':entry_price,'friction_side':friction_side})
            trades += 1
            # Diagnostic: individual open-trade MAE still exported, but portfolio DD now comes from full MtM stacking.
            try:
                mae_pct=float(r.get('mae_pct_' + h) or 0.0)
            except Exception:
                mae_pct=0.0
            if mae_pct > 0:
                mae_pct = -abs(mae_pct)
            mae_pct -= friction_side
            if mae_pct < worst_open_trade_dd:
                worst_open_trade_dd = mae_pct
            mark_equity(idx, total_equity_mtm(idx))

    # Close anything left at its modelled PnL after the data end.
    close_due(10**12)
    final_equity=cash + sum(t['stake'] for t in open_trades)
    mark_equity(max_idx, final_equity)
    pf=(gross_profit/gross_loss) if gross_loss>0 else (999.0 if gross_profit>0 else 0.0)
    total_return=(final_equity/START_EQUITY_USD-1.0)*100.0
    winrate=(wins/trades*100.0) if trades else 0.0
    avg_dd=(dd_sum/dd_n) if dd_n else 0.0
    return {
        'mode': sizing_mode,
        'exit_policy': exit_policy,
        'start_equity': START_EQUITY_USD,
        'end_equity': final_equity,
        'total_return_pct': total_return,
        'max_drawdown_pct': max_dd,
        'avg_drawdown_pct': avg_dd,
        'worst_open_trade_drawdown_pct': worst_open_trade_dd,
        'max_recovery_bars': recovery_bars_max,
        'trades': trades,
        'raw_signals': len(raw),
        'clustered_signals': len(clustered),
        'correlation_removed': corr_removed,
        'overlap_reduction_pct': (corr_removed / len(raw) * 100.0) if raw else 0.0,
        'skipped': skipped,
        'winrate_pct': winrate,
        'profit_factor': pf,
        'gross_profit': gross_profit,
        'gross_loss': gross_loss,
        'by_engine': by_engine,
        'curve_points': len(curve),
    }

def summarize_output_v34(path, source_rows=None):
    """Build a real summary.txt audit with specialist x timeframe trade economics."""
    lines = []
    def add(x=""):
        lines.append(str(x))
    counts = {}
    primary = {}
    per_tf = {}
    independent = {"day":{}, "week":{}, "month":{}}
    funding_modes = {"strict":0, "medium":0, "loose":0}
    with open(path, newline="", encoding="utf-8") as fh:
        for r in csv.DictReader(fh):
            s = r.get("selected_specialist", "none")
            counts[s] = counts.get(s, 0) + 1
            for m in funding_modes:
                if r.get("funding_mode_" + m) == "1": funding_modes[m] += 1
            if r.get("decision") not in ("LONG", "SHORT"):
                continue
            ph = r.get("primary_horizon", "none")
            keyp = (s, ph)
            st = primary.setdefault(keyp, {"n":0,"w":0,"ret":0.0})
            st["n"] += 1
            if r.get("win_primary") == "1": st["w"] += 1
            try: st["ret"] += float(r.get("return_primary") or 0.0)
            except Exception: pass
            for mode, col in (("day","independent_day"),("week","independent_week"),("month","independent_month")):
                if r.get(col) == "1":
                    ss = independent[mode].setdefault(keyp, {"n":0,"w":0,"ret":0.0})
                    ss["n"] += 1
                    if r.get("win_primary") == "1": ss["w"] += 1
                    try: ss["ret"] += float(r.get("return_primary") or 0.0)
                    except Exception: pass
            for h in FOCUSED_TRADE_HORIZONS:
                key = (s, h)
                q = per_tf.setdefault(key, {
                    "n":0,"wins":0,"ret_sum":0.0,"entry":0.0,"target":0.0,"stop":0.0,"mfe":0.0,"mae":0.0,
                    "target_hit":0,"stop_hit":0,"neither":0,"pnl":0.0,"pnl_pos":0.0,"pnl_neg_abs":0.0,
                    "rr":0.0,"valid_pnl":0,
                    "horizon_exit_pnl":0.0,"horizon_exit_pos":0.0,"horizon_exit_neg_abs":0.0,"horizon_exit_valid":0,
                    "wide_trailing_pnl":0.0,"wide_trailing_pos":0.0,"wide_trailing_neg_abs":0.0,"wide_trailing_valid":0,
                    "sized_horizon_pnl":0.0,"sized_horizon_valid":0,"sized_wide_trailing_pnl":0.0,"sized_wide_trailing_valid":0,
                    "size_sum":0.0,
                })
                win = r.get("win_" + h)
                if win == "":
                    continue
                q["n"] += 1
                if win == "1": q["wins"] += 1
                try: q["ret_sum"] += float(r.get("signed_ret_" + h) or 0.0)
                except Exception: pass
                def addf(field, bucket):
                    try: q[bucket] += float(r.get(field + "_" + h) or 0.0)
                    except Exception: pass
                addf("entry_price", "entry")
                addf("target_delta_usd", "target")
                addf("stop_delta_usd", "stop")
                addf("mfe_usd", "mfe")
                addf("mae_usd", "mae")
                addf("planned_rr", "rr")
                if r.get("target_hit_" + h) == "1": q["target_hit"] += 1
                elif r.get("stop_hit_" + h) == "1": q["stop_hit"] += 1
                else: q["neither"] += 1
                try:
                    pnl = float(r.get("pnl_usd_" + h) or 0.0)
                    q["pnl"] += pnl; q["valid_pnl"] += 1
                    if pnl > 0: q["pnl_pos"] += pnl
                    elif pnl < 0: q["pnl_neg_abs"] += abs(pnl)
                except Exception:
                    pass
                for mode, col_prefix in (("horizon_exit", "horizon_exit"), ("wide_trailing", "wide_trailing")):
                    try:
                        mp = float(r.get(col_prefix + "_pnl_usd_" + h) or 0.0)
                        q[mode + "_pnl"] += mp; q[mode + "_valid"] += 1
                        if mp > 0: q[mode + "_pos"] += mp
                        elif mp < 0: q[mode + "_neg_abs"] += abs(mp)
                    except Exception:
                        pass
                try:
                    q["size_sum"] += float(r.get("position_size_preview_pct_" + h) or 0.0)
                    q["sized_horizon_pnl"] += float(r.get("sized_horizon_pnl_pct_" + h) or 0.0); q["sized_horizon_valid"] += 1
                    q["sized_wide_trailing_pnl"] += float(r.get("sized_wide_trailing_pnl_pct_" + h) or 0.0); q["sized_wide_trailing_valid"] += 1
                except Exception:
                    pass
    def pct(a,b): return (a/b*100.0) if b else 0.0
    def avg(total,n): return total/n if n else 0.0
    def fmt_stats(st):
        n=st.get("n",0); return "n=%d winrate=%.1f%% avg_ret=%.3f%%" % (n, pct(st.get("w",0),n), avg(st.get("ret",0.0),n))
    add("BITCOIN EVIDENCE ENGINE RESEARCH BACKTEST V3.4")
    add("Portfolio Reality Fix: Mark-to-Market Drawdown + Correlation-Aware Overlap")
    add("Generated: " + datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    add("Version: " + VERSION)
    add("Audit intent: apply Claude v3.2 portfolio audit fixes: mark-to-market drawdown, correlation-aware overlap and fees/slippage friction.")
    add("Fixes: both-hit is never forced to loss; portfolio equity is marked to market on every candle; correlated signals inside 48h are collapsed into one cluster position; capital is locked; fees/slippage are applied. Start equity is $10,000. Research only, not trading advice.")
    add("")
    add("SELECTED SPECIALIST COUNTS")
    add("--------------------------")
    for k in sorted(counts.keys(), key=lambda x: counts[x], reverse=True):
        add("%-32s %8d" % (k, counts[k]))
    add("")
    add("FUNDING MODE DIAGNOSTIC COUNTS")
    add("------------------------------")
    for k,v in funding_modes.items(): add("%-10s %8d" % (k, v))
    add("")
    add("PRIMARY HORIZON STATS")
    add("---------------------")
    for key in sorted(primary.keys()): add("%-45s %s" % (str(key), fmt_stats(primary[key])))
    for mode in ("day", "week", "month"):
        add("")
        add("OVERLAP-AWARE PRIMARY STATS: INDEPENDENT " + mode.upper())
        add("------------------------------------------------")
        for key in sorted(independent[mode].keys()): add("%-45s %s" % (str(key), fmt_stats(independent[mode][key])))
    add("")
    add("SPECIALIST x TIMEFRAME TRADE QUALITY")
    add("------------------------------------")
    specialists = [k for k in sorted(counts.keys()) if k != "none"]
    for s in specialists:
        add("")
        add("========================================")
        add(s.upper())
        add("========================================")
        for h in FOCUSED_TRADE_HORIZONS:
            q = per_tf.get((s,h))
            if not q or q.get("n",0)==0:
                add("%s: no trades" % h.upper()); continue
            n=q["n"]; pf = (q["pnl_pos"] / q["pnl_neg_abs"]) if q["pnl_neg_abs"] > 0 else (999.0 if q["pnl_pos"] > 0 else 0.0)
            add("%s | count=%d | winrate=%.1f%% | avg_ret=%.3f%% | avg_entry=$%.0f" % (h.upper(), n, pct(q["wins"],n), avg(q["ret_sum"],n), avg(q["entry"],n)))
            add("     avg_target=$%+.0f | avg_stop=$%+.0f | avg_MFE=$%+.0f | avg_MAE=$%+.0f | avg_RR=%.2f" % (avg(q["target"],n), avg(q["stop"],n), avg(q["mfe"],n), avg(q["mae"],n), avg(q["rr"],n)))
            add("     FIXED target/stop: target_first=%.1f%% | stop_first=%.1f%% | neither=%.1f%% | avg_PnL=$%+.0f | PF=%.2f" % (pct(q["target_hit"],n), pct(q["stop_hit"],n), pct(q["neither"],n), avg(q["pnl"], max(1,q["valid_pnl"])), pf))
            def mode_line(label, key):
                valid=max(1,q.get(key+"_valid",0)); pos=q.get(key+"_pos",0.0); neg=q.get(key+"_neg_abs",0.0); mpf=(pos/neg) if neg>0 else (999.0 if pos>0 else 0.0)
                return "%s: avg_PnL=$%+.0f | PF=%.2f" % (label, avg(q.get(key+"_pnl",0.0), valid), mpf)
            add("     " + mode_line("HORIZON EXIT", "horizon_exit"))
            add("     " + mode_line("WIDE TRAILING", "wide_trailing"))
            add("     POSITION SIZE PREVIEW: avg_size=%.2f%% | sized_horizon_avg=%.3f%% | sized_trailing_avg=%.3f%%" % (avg(q.get("size_sum",0.0), n), avg(q.get("sized_horizon_pnl",0.0), max(1,q.get("sized_horizon_valid",0))), avg(q.get("sized_wide_trailing_pnl",0.0), max(1,q.get("sized_wide_trailing_valid",0)))))
    add("")
    add("PORTFOLIO REALITY SIMULATION — $10,000 ACCOUNT")
    add("------------------------------------")
    add("Rules: weekly-deduplicated signals, 48h correlation-aware clustering, mark-to-market equity every candle, capital lock, max 100% open exposure, no leverage, fee/slippage friction.")
    add("Exit policy for engine_best: Funding/Cycle/Continuation/EliteReversal => wide trailing; ReversalAlpha => horizon exit.")
    add("")
    sims=[]
    for smode in ("equal_weight", "confidence_weight", "smart_engine_weight"):
        sims.append(simulate_portfolio_from_csv(path, smode, "engine_best", source_rows, True))
    for sim in sims:
        add("%s | exit=%s" % (sim['mode'].upper(), sim['exit_policy']))
        add("     start=$%.0f | end=$%.0f | return=%+.1f%% | maxDD=%.1f%% | avgDD=%.1f%% | worstOpen=%.1f%% | trades=%d | skipped=%d | winrate=%.1f%% | PF=%.2f" % (
            sim['start_equity'], sim['end_equity'], sim['total_return_pct'], sim['max_drawdown_pct'], sim.get('avg_drawdown_pct',0.0), sim.get('worst_open_trade_drawdown_pct',0.0), sim['trades'], sim['skipped'], sim['winrate_pct'], sim['profit_factor']))
        add("     raw_signals=%d | clustered=%d | correlation_removed=%d | overlap_reduction=%.1f%% | curve_points=%d | max_recovery_bars=%d" % (
            sim.get('raw_signals',0), sim.get('clustered_signals',0), sim.get('correlation_removed',0), sim.get('overlap_reduction_pct',0.0), sim.get('curve_points',0), sim.get('max_recovery_bars',0)))
        # Show top engine contributors for transparency.
        ranked=sorted(sim['by_engine'].items(), key=lambda kv: kv[1].get('pnl',0.0), reverse=True)
        for eng, st in ranked[:8]:
            n=st.get('n',0); wr=(st.get('wins',0)/n*100.0) if n else 0.0
            add("       %-30s n=%4d winrate=%5.1f%% pnl=$%+.0f" % (eng, n, wr, st.get('pnl',0.0)))
        add("")
    add("Also benchmark exit policy sensitivity with SMART_ENGINE_WEIGHT sizing:")
    for epol in ("fixed_target_stop", "horizon_exit", "wide_trailing", "engine_best"):
        sim=simulate_portfolio_from_csv(path, "smart_engine_weight", epol, source_rows, True)
        add("     %-18s end=$%.0f return=%+.1f%% maxDD=%.1f%% avgDD=%.1f%% worstOpen=%.1f%% trades=%d removed=%d PF=%.2f" % (epol, sim['end_equity'], sim['total_return_pct'], sim['max_drawdown_pct'], sim.get('avg_drawdown_pct',0.0), sim.get('worst_open_trade_drawdown_pct',0.0), sim['trades'], sim.get('correlation_removed',0), sim['profit_factor']))
    add("")

    summary_path = os.path.join(os.path.dirname(os.path.abspath(path)), SUMMARY_TXT)
    with open(summary_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print("\n".join(lines[:80]))
    if len(lines) > 80:
        print("... summary.txt bevat volledige audit (%d regels)" % len(lines))
    return summary_path


def _wf_float(v, default=0.0):
    try:
        if v is None or v == '':
            return default
        return float(v)
    except Exception:
        return default


def _wf_int(v, default=0):
    try:
        if v is None or v == '':
            return default
        return int(float(v))
    except Exception:
        return default


def _wf_pnl_pct(row, exit_policy='wide_trailing'):
    h = row.get('primary_horizon') or '24h'
    if exit_policy == 'wide_trailing':
        return _wf_float(row.get('wide_trailing_pnl_pct_' + h) or row.get('wide_trailing_pnl_pct'))
    if exit_policy == 'horizon_exit':
        return _wf_float(row.get('horizon_exit_pnl_pct_' + h) or row.get('horizon_exit_pnl_pct'))
    return _wf_float(row.get('pnl_pct_' + h) or row.get('pnl_pct'))


def _wf_pf(vals):
    gp = sum(x for x in vals if x > 0)
    gl = -sum(x for x in vals if x < 0)
    if gl <= 0:
        return 999.0 if gp > 0 else 0.0
    return gp / gl


def _wf_stats(rows, exit_policy='wide_trailing'):
    vals = [_wf_pnl_pct(r, exit_policy) for r in rows]
    n = len(vals)
    wins = sum(1 for x in vals if x > 0)
    avg = sum(vals) / n if n else 0.0
    pf = _wf_pf(vals)
    return {'n': n, 'winrate': (wins/n*100.0 if n else 0.0), 'avg': avg, 'pf': pf}


def _wf_train_engine_calibration(train_rows):
    """Train-only engine eligibility.

    This is deliberately simple and transparent: for each fold we only use rows before
    the test year to decide which engines are allowed in the out-of-sample test.
    No test-year data is used here.
    """
    by_eng = {}
    for r in train_rows:
        eng = r.get('selected_specialist') or 'none'
        if eng == 'none' or r.get('decision') not in ('LONG','SHORT'):
            continue
        if r.get('independent_week') != '1':
            continue
        by_eng.setdefault(eng, []).append(r)
    calib = {}
    for eng, rr in sorted(by_eng.items()):
        st = _wf_stats(rr, 'wide_trailing')
        # transparent train-only gate: enough historical examples and positive train PF.
        enabled = bool(st['n'] >= 8 and st['pf'] >= 1.15 and st['avg'] > 0)
        calib[eng] = {'enabled': enabled, 'n': st['n'], 'pf': st['pf'], 'avg': st['avg'], 'winrate': st['winrate']}
    return calib


def _write_temp_wf_csv(base_path, header, rows, name):
    p = os.path.join(os.path.dirname(os.path.abspath(base_path)), name)
    with open(p, 'w', newline='', encoding='utf-8') as fh:
        w = csv.DictWriter(fh, fieldnames=header, extrasaction='ignore')
        w.writeheader()
        for r in rows:
            w.writerow(r)
    return p



def summarize_output_v40_basic(path, source_rows=None):
    """Fast V4.0 summary without heavy in-sample portfolio simulations.

    V4.0 priority is walk-forward/out-of-sample testing. We intentionally avoid the
    expensive V3.x full-portfolio in-sample audit here so the script stays Pythonista-safe.
    """
    out_dir = os.path.dirname(os.path.abspath(path))
    summary_path = os.path.join(out_dir, SUMMARY_TXT)
    counts = {}
    years = {}
    total = 0
    with open(path, newline='', encoding='utf-8') as fh:
        for r in csv.DictReader(fh):
            total += 1
            s = r.get('selected_specialist') or 'none'
            counts[s] = counts.get(s, 0) + 1
            y = r.get('year') or ''
            years[y] = years.get(y, 0) + 1
    lines = []
    lines.append('BEE Research Backtest %s' % VERSION)
    lines.append('='*92)
    lines.append('V4.0 focus: Walk-Forward Time Machine / out-of-sample audit.')
    lines.append('This build intentionally stops doing new engine tweaks and heavy in-sample sim tweaks.')
    lines.append('The goal is to answer: does the V3.4 alpha survive on unseen future years?')
    lines.append('')
    lines.append('Output rows: %d' % total)
    lines.append('Specialist counts:')
    for k,v in sorted(counts.items(), key=lambda kv: (-kv[1], kv[0])):
        lines.append('  %-30s %8d' % (k, v))
    lines.append('')
    lines.append('Rows by year:')
    for k,v in sorted(years.items()):
        lines.append('  %-8s %8d' % (k, v))
    lines.append('')
    lines.append('Locked next roadmap after this if OOS passes: V4.1 Live Forecast Loop in PAPER mode only: FETCH -> BUILD -> DECIDE -> DEDUP -> NOTIFY -> PERSIST -> SLEEP.')
    with open(summary_path, 'w', encoding='utf-8') as fh:
        fh.write('\n'.join(lines) + '\n')
    return summary_path


def _wf_size_frac(row):
    return _smart_engine_size_pct(row.get('selected_specialist') or '')


def _wf_closed_equity_proxy(rows, exit_policy='wide_trailing'):
    """Fast walk-forward portfolio proxy.

    Uses chronological closed-trade compounding with smart engine sizing. It is not a full
    MTM simulator; V4.0 uses it only as an OOS sanity metric. Full MTM remains in V3.4.
    """
    eq = START_EQUITY_USD
    peak = eq
    max_dd = 0.0
    gp = 0.0
    gl = 0.0
    wins = 0
    trades = 0
    for r in sorted(rows, key=lambda x: _wf_int(x.get('row_index'))):
        ret = _wf_pnl_pct(r, exit_policy) / 100.0
        frac = _wf_size_frac(r)
        pnl = eq * frac * ret
        eq += pnl
        trades += 1
        if pnl > 0:
            gp += pnl; wins += 1
        elif pnl < 0:
            gl += -pnl
        if eq > peak: peak = eq
        dd = (eq / peak - 1.0) * 100.0 if peak else 0.0
        if dd < max_dd: max_dd = dd
    return {
        'start_equity': START_EQUITY_USD,
        'end_equity': eq,
        'total_return_pct': (eq/START_EQUITY_USD - 1.0) * 100.0,
        'max_drawdown_pct': max_dd,
        'profit_factor': (gp/gl if gl>0 else (999.0 if gp>0 else 0.0)),
        'trades': trades,
        'winrate_pct': wins/trades*100.0 if trades else 0.0,
    }

def append_walk_forward_summary_v40(results_csv_path, source_rows, summary_path):
    """Append a real V4.0 walk-forward audit to the summary.

    Windows:
      train <= 2022, test 2023
      train <= 2023, test 2024
      train <= 2024, test 2025
      train <= 2025, test 2026 YTD

    Key rule: engine eligibility/calibration is calculated only from train rows before
    the test year. The test rows are never used to choose enabled engines.
    """
    try:
        with open(results_csv_path, newline='', encoding='utf-8') as fh:
            reader = csv.DictReader(fh)
            header = reader.fieldnames or []
            all_rows = list(reader)
    except Exception as e:
        with open(summary_path, 'a', encoding='utf-8') as out:
            out.write('\n\nV4.0 WALK-FORWARD ERROR: could not read output CSV: %s\n' % e)
        return summary_path

    folds = [(2022, 2023), (2023, 2024), (2024, 2025), (2025, 2026)]
    lines = []
    lines.append('')
    lines.append('='*92)
    lines.append('V4.0 WALK-FORWARD TIME MACHINE — OUT-OF-SAMPLE AUDIT')
    lines.append('='*92)
    lines.append('Purpose: test whether the V3.4 specialist alpha survives on unseen future years.')
    lines.append('Hard rule: per fold, train-only calibration uses only rows before the test year.')
    lines.append('Live-safety policy used for OOS portfolio: wide_trailing exit, smart_engine_weight sizing, 48h correlation clustering, fees/slippage and full MTM stacking.')
    lines.append('This is still research, not trading advice. It is the bridge toward the later live paper-forecast loop.')
    lines.append('')

    combined_oos = []
    combined_all_oos = []
    for train_end, test_year in folds:
        train = [r for r in all_rows if _wf_int(r.get('year')) <= train_end]
        test_all = [r for r in all_rows if _wf_int(r.get('year')) == test_year and r.get('decision') in ('LONG','SHORT') and r.get('independent_week') == '1']
        if not test_all:
            lines.append('Fold train<=%d test=%d: no test rows available.' % (train_end, test_year))
            continue
        calib = _wf_train_engine_calibration(train)
        enabled = set(k for k,v in calib.items() if v.get('enabled'))
        test_enabled = [r for r in test_all if (r.get('selected_specialist') or 'none') in enabled]
        combined_all_oos.extend(test_all)
        combined_oos.extend(test_enabled)
        # alpha stats, no portfolio compounding
        st_wide = _wf_stats(test_enabled, 'wide_trailing')
        st_hz = _wf_stats(test_enabled, 'horizon_exit')
        # Fast closed-equity proxy for OOS sanity. Full MTM is intentionally not rerun here.
        sim = _wf_closed_equity_proxy(test_enabled, 'wide_trailing')
        lines.append('Fold train<=%d -> test %d' % (train_end, test_year))
        lines.append('  train rows: %d | test signals all: %d | enabled OOS signals: %d' % (len(train), len(test_all), len(test_enabled)))
        lines.append('  enabled engines from TRAIN only: %s' % (', '.join(sorted(enabled)) if enabled else 'none'))
        lines.append('  OOS wide-trailing: n=%d win=%.1f%% avg=%.2f%% PF=%.2f' % (st_wide['n'], st_wide['winrate'], st_wide['avg'], st_wide['pf']))
        lines.append('  OOS horizon-exit compare: n=%d win=%.1f%% avg=%.2f%% PF=%.2f' % (st_hz['n'], st_hz['winrate'], st_hz['avg'], st_hz['pf']))
        if 'error' in sim:
            lines.append('  portfolio sim error: %s' % sim['error'])
        else:
            lines.append('  OOS closed-equity proxy wide/smart: $%.0f -> $%.0f | return %.1f%% | maxDD %.1f%% | PF %.2f | trades %d' % (
                sim.get('start_equity',0), sim.get('end_equity',0), sim.get('total_return_pct',0), sim.get('max_drawdown_pct',0), sim.get('profit_factor',0), sim.get('trades',0)))
        # per engine OOS quick stats
        by = {}
        for r in test_enabled:
            by.setdefault(r.get('selected_specialist') or 'none', []).append(r)
        if by:
            lines.append('  OOS by engine, wide trailing:')
            for eng, rr in sorted(by.items()):
                st = _wf_stats(rr, 'wide_trailing')
                lines.append('    %-28s n=%4d win=%5.1f%% avg=%7.2f%% PF=%6.2f' % (eng, st['n'], st['winrate'], st['avg'], st['pf']))
        lines.append('')

    # Combined OOS diagnostic across all test years after train-only engine gates per fold.
    if combined_oos:
        sim = _wf_closed_equity_proxy(combined_oos, 'wide_trailing')
        st = _wf_stats(combined_oos, 'wide_trailing')
        lines.append('-'*92)
        lines.append('COMBINED WALK-FORWARD OOS, train-gated engines only')
        lines.append('  OOS signals: %d | wide win %.1f%% | avg %.2f%% | PF %.2f' % (st['n'], st['winrate'], st['avg'], st['pf']))
        if 'error' in sim:
            lines.append('  portfolio sim error: %s' % sim['error'])
        else:
            lines.append('  closed-equity proxy: $%.0f -> $%.0f | return %.1f%% | maxDD %.1f%% | PF %.2f | trades %d' % (
                sim.get('start_equity',0), sim.get('end_equity',0), sim.get('total_return_pct',0), sim.get('max_drawdown_pct',0), sim.get('profit_factor',0), sim.get('trades',0)))
    lines.append('')
    lines.append('Interpretation rules:')
    lines.append('- This is a first walk-forward audit, not yet the live server loop.')
    lines.append('- If OOS PF stays >1.8 with tolerable DD, alpha likely survives the in-sample concern.')
    lines.append('- If OOS collapses, the V3.4 result was mostly overfit/regime bias and live forecast must wait.')
    lines.append('- Next step after a passing V4.0: V4.1 server paper-forecast loop with ntfy, no auto-trading.')

    with open(summary_path, 'a', encoding='utf-8') as out:
        out.write('\n'.join(lines) + '\n')
    print('Walk-forward V4.0 audit appended to summary.')
    return summary_path

def main():
    t0 = time.time()
    print("BEE Research Backtest", VERSION)
    kind, path, member = find_data_source()
    if not kind:
        print("\nCSV niet gevonden.")
        print("Zet de CSV naast dit script, of zet deze ZIP + CSV in Pythonista Documents.")
        print("Gezochte namen:")
        for n in CSV_NAMES: print("-", n)
        return
    print("Data source:", kind, path, member or "")
    rows = load_data(kind, path, member)
    print("Rijen geladen:", len(rows))
    bad = mark_corrupt(rows)
    macro_stats = add_macro_week_return(rows)
    add_past_and_forward_returns(rows)
    macro_cov = sum(1 for r in rows if r.get("macro_safe")) / max(1, len(rows)) * 100.0
    print("Corrupte candles:", bad)
    print("Macro coverage:", "%.2f%%" % macro_cov)
    print("Macro source existing/fallback/bad:", macro_stats.get("used_existing"), macro_stats.get("used_fallback"), macro_stats.get("bad_macro"))
    out, n = write_results(rows, path)
    print("\nTijdelijke CSV gebouwd voor compressie:", out)
    print("Rijen in output:", n)
    summary_path = summarize_output_v40_basic(out, rows)
    summary_path = append_walk_forward_summary_v40(out, rows, summary_path)
    zip_out = create_results_zip(out, summary_path)
    # Keep the user-facing export small: only the ZIP should remain/open.
    # The CSV inside the ZIP is unchanged, but the loose CSV file is removed after summarizing.
    try:
        if os.path.isfile(out):
            os.remove(out)
        if summary_path and os.path.isfile(summary_path):
            os.remove(summary_path)
        print("Losse CSV en summary verwijderd; export staat alleen in ZIP.")
    except Exception as e:
        print("Waarschuwing: losse exportbestanden konden niet worden verwijderd:", e)
    print("\nOutput ZIP geschreven:", zip_out)
    print("Runtime: %.2fs" % (time.time() - t0))
    try:
        import console
        console.open_in(zip_out)
    except Exception:
        pass

if __name__ == "__main__":
    main()
