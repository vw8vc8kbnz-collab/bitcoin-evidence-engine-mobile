#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Bitcoin Evidence Engine — V4.1 Live Forecast Loop (Paper Mode)

Doel:
- Draait op de bestaande server als simpele Python-loop.
- Haalt live marktdata op.
- Bouwt een row-dict met dezelfde veldnamen als de V4.0 backtest.
- Draait exact dezelfde decision core via bee_research_core_v4_0.decide(row).
- Meldt alleen paper-forecast signalen via ntfy en logt alles lokaal.

Belangrijke scope V4.1:
- GEEN automatische handel.
- Alleen actieve engines uit de walk-forward analyse:
  cycle_reversal, elite_reversal, reversal.
- Continuation en funding-squeeze worden wel diagnostisch berekend door de core,
  maar in fase 1 niet genotificeerd.
- Standaard daily check; funding-squeeze snelle loop komt pas later.

Standaard library only: urllib, json, csv, time, datetime, statistics.
"""
import argparse
import csv
import datetime as _dt
import json
import math
import os
import sys
import time
import traceback
import urllib.parse
import urllib.request
from pathlib import Path

try:
    import bee_research_core_v4_0 as core
except Exception as e:
    print("FOUT: bee_research_core_v4_0.py staat niet naast dit script of importeert niet:", e)
    raise

VERSION = "v4.1.2_live_paper_forecast_trade_plan_ntfy"
APP_DIR = Path(__file__).resolve().parent
CONFIG_PATH = APP_DIR / "bee_live_config.json"
CONFIG_EXAMPLE_PATH = APP_DIR / "bee_live_config.example.json"
STATE_PATH = APP_DIR / "bee_live_state.json"
SIGNAL_LOG_PATH = APP_DIR / "bee_live_signals.jsonl"
SYSTEM_LOG_PATH = APP_DIR / "bee_live_system.log"
GOLDEN_FEATURE_LOG = APP_DIR / "bee_live_last_feature_snapshot.json"

DEFAULT_CONFIG = {
    "ntfy_topic": "",
    "ntfy_server": "https://ntfy.sh",
    "alpha_vantage_api_key": "",
    "check_interval_hours": 24,
    "active_specialists": ["cycle_reversal", "elite_reversal", "reversal"],
    "min_notify_tier": "push",
    "dedup_days_by_specialist": {"cycle_reversal": 7, "elite_reversal": 14, "reversal": 14},
    "binance_base_urls": ["https://api.binance.com", "https://api.binance.us"],
    "use_coinbase_premium": True,
    "paper_only": True,
    "macro_cache_hours": 24,
    "fear_greed_cache_hours": 12,
    "btc_1h_limit": 1000,
    "btc_1d_limit": 1000,
    "min_closed_1h_candles": 220,
    "include_trade_plan_in_ntfy": True,
    "live_exit_policy": "wide_trailing_paper",
}

TIER_RANK = {"none": 0, "watch": 1, "push": 2, "strong": 3, "elite": 4}
ACTIVE_SCOPE_NOTE = "V4.1 phase 1 live paper: only CycleReversal, EliteReversal, Reversal notify. No trading."


# Historical model metrics used only for context in notifications.
# These are NOT used as live decision inputs. They are copied from the V4.0/V3.4 research export.
# all_history = all available historical rows in the research CSV for that model/timeframe.
# oos_walk_forward = train-gated walk-forward summary where available; smaller but more honest.
MODEL_TIMEFRAME_STATS = {
    "cycle_reversal": {
        "24h": {"n": 7865, "winrate": 49.9, "avg_return_pct": 0.74, "pf": 1.51, "source": "all_history"},
        "7d":  {"n": 7850, "winrate": 60.7, "avg_return_pct": 5.66, "pf": 2.72, "source": "all_history"},
        "30d": {"n": 7830, "winrate": 79.5, "avg_return_pct": 21.66, "pf": 10.44, "source": "all_history"},
        "90d": {"n": 7361, "winrate": 91.6, "avg_return_pct": 38.86, "pf": 29.24, "source": "all_history"},
    },
    "elite_reversal": {
        "24h": {"n": 2231, "winrate": 54.7, "avg_return_pct": 1.53, "pf": 2.39, "source": "all_history"},
        "7d":  {"n": 2231, "winrate": 71.8, "avg_return_pct": 9.59, "pf": 8.35, "source": "all_history"},
        "30d": {"n": 2231, "winrate": 82.7, "avg_return_pct": 23.22, "pf": 17.27, "source": "all_history"},
        "90d": {"n": 2175, "winrate": 94.9, "avg_return_pct": 40.98, "pf": 54.56, "source": "all_history"},
    },
    "reversal": {
        "24h": {"n": 3311, "winrate": 58.0, "avg_return_pct": 2.06, "pf": 3.23, "source": "all_history"},
        "7d":  {"n": 3311, "winrate": 60.2, "avg_return_pct": 7.74, "pf": 5.16, "source": "all_history"},
        "30d": {"n": 3311, "winrate": 76.6, "avg_return_pct": 19.47, "pf": 13.50, "source": "all_history"},
        "90d": {"n": 3311, "winrate": 91.8, "avg_return_pct": 37.65, "pf": 59.16, "source": "all_history"},
    },
}

OOS_WALK_FORWARD_STATS = {
    # Small sample but more honest: train-gated walk-forward OOS from V4.0 summary.
    "cycle_reversal": {"n": 45, "winrate": 57.8, "avg_return_pct": 9.62, "pf_note": "fold PFs: 3.45 / 5.05 / 2.86", "source": "walk_forward_oos_2024_2026"},
    "elite_reversal": {"n": 15, "winrate": 73.3, "avg_return_pct": 14.42, "pf": 5.61, "source": "walk_forward_oos_2026_only"},
    "reversal": {"n": 16, "winrate": 62.5, "avg_return_pct": 3.92, "pf_note": "2026 PF 1.80; 2023 n=2", "source": "walk_forward_oos_2023_2026"},
}


def get_model_stats(spec, horizon):
    spec = (spec or "").lower()
    horizon = horizon or ""
    return (MODEL_TIMEFRAME_STATS.get(spec) or {}).get(horizon) or {}


def get_oos_stats(spec):
    return OOS_WALK_FORWARD_STATS.get((spec or "").lower()) or {}


def _fmt_usd(v):
    try:
        return "$" + format(float(v), ",.0f")
    except Exception:
        return "n/a"


def build_trade_plan(row, decision, cfg=None):
    """Build the paper trade plan shown in ntfy.

    This is NOT execution logic. It gives a paper entry/TP/SL snapshot so the alert is usable.
    Live phase 1 uses wide trailing as the safety policy. Therefore TP is shown as an
    indicative historical move target, while SL is the initial wide-trailing invalidation level.
    """
    cfg = cfg or {}
    spec = decision.get("selected_specialist") or "none"
    action = decision.get("decision") or "NO_TRADE"
    horizon = decision.get("primary_horizon") or "none"
    entry = row.get("close")
    try:
        entry_f = float(entry)
    except Exception:
        entry_f = None
    stats = get_model_stats(spec, horizon)
    avg_pct = stats.get("avg_return_pct")
    try:
        avg_pct_f = float(avg_pct)
    except Exception:
        avg_pct_f = None
    try:
        trail_pct = float(core.recommended_trailing_pct(spec))
    except Exception:
        trail_pct = 18.0
    tp = sl = None
    if entry_f is not None:
        # Use a conservative minimum TP if no stats are available; active models should have stats.
        effective_tp_pct = avg_pct_f if avg_pct_f is not None else 10.0
        if action == "LONG":
            tp = entry_f * (1.0 + effective_tp_pct / 100.0)
            sl = entry_f * (1.0 - trail_pct / 100.0)
        elif action == "SHORT":
            tp = entry_f * (1.0 - abs(effective_tp_pct) / 100.0)
            sl = entry_f * (1.0 + trail_pct / 100.0)
    return {
        "model": spec,
        "action": action,
        "timeframe": horizon,
        "exit_policy": cfg.get("live_exit_policy", "wide_trailing_paper"),
        "entry_price": entry_f,
        "take_profit_price": tp,
        "stoploss_price": sl,
        "take_profit_pct": avg_pct_f,
        "initial_trailing_stop_pct": trail_pct,
        "stats_all_history": stats,
        "stats_oos_walk_forward": get_oos_stats(spec),
        "note": "TP is an indicative historical-average target; V4.1 paper exit policy is wide trailing, not automatic trading.",
    }



def utc_now():
    return _dt.datetime.utcnow().replace(microsecond=0)


def iso_now():
    return utc_now().isoformat() + "Z"


def log(msg):
    line = f"{iso_now()} {msg}"
    print(line)
    try:
        with open(SYSTEM_LOG_PATH, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def load_json(path, default):
    try:
        if path.exists():
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                merged = dict(default)
                merged.update(data)
                return merged
    except Exception as e:
        log(f"WARN load_json failed for {path}: {e}")
    return dict(default)


def save_json(path, data):
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, sort_keys=True)
    os.replace(tmp, path)


def load_config():
    cfg = load_json(CONFIG_PATH, DEFAULT_CONFIG)
    # env overrides, so secrets do not need to live in the file
    cfg["ntfy_topic"] = os.environ.get("BEE_NTFY_TOPIC", cfg.get("ntfy_topic", ""))
    cfg["alpha_vantage_api_key"] = os.environ.get("ALPHAVANTAGE_API_KEY", cfg.get("alpha_vantage_api_key", ""))
    return cfg


def load_state():
    default = {"created_at": iso_now(), "last_notified": {}, "cache": {}, "last_decision": None}
    return load_json(STATE_PATH, default)


def save_state(state):
    save_json(STATE_PATH, state)


def http_json(url, timeout=20, headers=None):
    req = urllib.request.Request(url, headers=headers or {"User-Agent": "BEE-LiveForecast/4.1.2"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        raw = resp.read().decode("utf-8")
    return json.loads(raw)


def fetch_binance_klines(symbol="BTCUSDT", interval="1h", limit=1000, base_urls=None):
    base_urls = base_urls or ["https://api.binance.com", "https://api.binance.us"]
    last_err = None
    for base in base_urls:
        url = f"{base}/api/v3/klines?" + urllib.parse.urlencode({"symbol": symbol, "interval": interval, "limit": int(limit)})
        try:
            data = http_json(url, timeout=20)
            out = []
            now_ms = int(time.time() * 1000)
            for k in data:
                # Binance kline: [open_time, open, high, low, close, volume, close_time, ...]
                close_time = int(k[6])
                # skip still-open candle
                if close_time > now_ms:
                    continue
                out.append({
                    "open_time_ms": int(k[0]),
                    "close_time_ms": close_time,
                    "dt": _dt.datetime.utcfromtimestamp(int(k[0]) / 1000.0).replace(microsecond=0).isoformat() + "Z",
                    "open": float(k[1]),
                    "high": float(k[2]),
                    "low": float(k[3]),
                    "close": float(k[4]),
                    "volume": float(k[5]),
                })
            if out:
                return out
        except Exception as e:
            last_err = e
            log(f"WARN Binance klines failed base={base} interval={interval}: {e}")
    raise RuntimeError(f"All Binance kline endpoints failed: {last_err}")


def fetch_funding(base_urls=None):
    # Futures endpoint is only available on global Binance. If blocked, return cached/missing.
    urls = ["https://fapi.binance.com/fapi/v1/fundingRate?symbol=BTCUSDT&limit=20"]
    last_err = None
    for url in urls:
        try:
            data = http_json(url, timeout=20)
            if data:
                latest = data[-1]
                return {"funding_rate": float(latest.get("fundingRate", 0.0)), "funding_time": latest.get("fundingTime")}
        except Exception as e:
            last_err = e
            log(f"WARN funding fetch failed: {e}")
    raise RuntimeError(f"funding fetch failed: {last_err}")


def fetch_fear_greed():
    data = http_json("https://api.alternative.me/fng/?limit=10&format=json", timeout=20)
    rows = data.get("data") or []
    if not rows:
        raise RuntimeError("alternative.me returned no fear&greed data")
    latest = rows[0]
    return {"fear_greed": float(latest.get("value")), "fear_greed_label": latest.get("value_classification"), "fear_greed_ts": latest.get("timestamp")}


def fetch_spy_weekly(api_key):
    if not api_key:
        raise RuntimeError("Alpha Vantage key missing. Set ALPHAVANTAGE_API_KEY or config alpha_vantage_api_key.")
    params = {"function": "TIME_SERIES_WEEKLY", "symbol": "SPY", "apikey": api_key}
    url = "https://www.alphavantage.co/query?" + urllib.parse.urlencode(params)
    data = http_json(url, timeout=25)
    series = data.get("Weekly Time Series")
    if not series:
        raise RuntimeError("Alpha Vantage weekly SPY missing. Response keys: " + ",".join(data.keys()))
    dates = sorted(series.keys())
    if len(dates) < 2:
        raise RuntimeError("not enough SPY weekly bars")
    # Use only completed weekly closes. AlphaVantage weekly bar updates after week close; daily loop cache is fine.
    d1, d0 = dates[-1], dates[-2]
    c1 = float(series[d1]["4. close"])
    c0 = float(series[d0]["4. close"])
    ret = (c1 / c0 - 1.0) * 100.0
    return {"spx_close": c1, "spx_ret_1w_calc": ret, "spx_week_date": d1, "spx_prev_week_date": d0, "macro_safe": abs(ret) <= core.MACRO_ABS_CLAMP, "macro_source": "alpha_vantage_spy_weekly"}


def fetch_coinbase_premium(binance_close):
    data = http_json("https://api.exchange.coinbase.com/products/BTC-USD/ticker", timeout=20)
    cb = float(data.get("price"))
    prem = (cb / binance_close - 1.0) * 100.0 if binance_close else None
    return {"coinbase_price": cb, "coinbase_premium_pct": prem}


def cache_get_or_fetch(state, cache_key, max_age_hours, fetch_fn):
    cache = state.setdefault("cache", {})
    item = cache.get(cache_key)
    now_ts = time.time()
    if item and isinstance(item, dict):
        age_h = (now_ts - float(item.get("fetched_ts", 0))) / 3600.0
        if age_h <= max_age_hours and item.get("data") is not None:
            return item["data"], True
    data = fetch_fn()
    cache[cache_key] = {"fetched_ts": now_ts, "fetched_at": iso_now(), "data": data}
    return data, False


def sma(vals, n):
    if len(vals) < n:
        return None
    chunk = vals[-n:]
    return sum(chunk) / float(n)


def pct(now, prev):
    if now is None or prev in (None, 0):
        return None
    return (now / prev - 1.0) * 100.0


def rsi(closes, period=14):
    if len(closes) < period + 1:
        return None
    gains = []
    losses = []
    window = closes[-(period+1):]
    for a, b in zip(window[:-1], window[1:]):
        diff = b - a
        if diff >= 0:
            gains.append(diff); losses.append(0.0)
        else:
            gains.append(0.0); losses.append(-diff)
    avg_gain = sum(gains) / period
    avg_loss = sum(losses) / period
    if avg_loss == 0:
        return 100.0
    rs = avg_gain / avg_loss
    return 100.0 - (100.0 / (1.0 + rs))


def stdev(vals):
    vals = [v for v in vals if v is not None]
    if len(vals) < 2:
        return None
    m = sum(vals) / len(vals)
    return math.sqrt(sum((v-m)*(v-m) for v in vals) / (len(vals)-1))


def infer_regime(close, ma50, ma200, drawdown, fear_greed):
    # Heuristic live mirror of the dataset regime labels used by the decision core.
    # The exact historical regime column is unavailable live, so this keeps the same label vocabulary.
    if drawdown is not None and fear_greed is not None and drawdown <= -35.0 and fear_greed < 25.0:
        return "capitulation"
    if close is not None and ma200 is not None and close < ma200:
        return "bear_trend"
    if drawdown is not None and drawdown <= -25.0 and fear_greed is not None and fear_greed < 35.0:
        return "bear_trend"
    if close is not None and ma50 is not None and ma200 is not None and close > ma50 and ma50 > ma200:
        return "bull_trend"
    return "transition"


def build_live_row(candles_1h, candles_1d, market):
    if len(candles_1h) < 220:
        raise RuntimeError(f"Need at least 220 closed 1h candles, got {len(candles_1h)}")
    closes = [c["close"] for c in candles_1h]
    highs = [c["high"] for c in candles_1h]
    lows = [c["low"] for c in candles_1h]
    vols = [c["volume"] for c in candles_1h]
    last = candles_1h[-1]
    close = closes[-1]
    # Drawdown from recent daily ATH. Live loop can later switch to persistent all-time high if desired.
    daily_highs = [c["high"] for c in candles_1d] if candles_1d else highs
    recent_ath = max(daily_highs) if daily_highs else max(highs)
    drawdown = (close / recent_ath - 1.0) * 100.0 if recent_ath else None
    rets_24 = []
    for i in range(max(1, len(closes)-24), len(closes)):
        rets_24.append(pct(closes[i], closes[i-1]) if i > 0 else None)
    vol24 = stdev(rets_24)
    volume_z = None
    if len(vols) >= 50:
        m = sum(vols[-50:]) / 50.0
        sd = stdev(vols[-50:]) or 0.0
        volume_z = (vols[-1] - m) / sd if sd > 0 else 0.0
    ma20 = sma(closes, 20); ma50 = sma(closes, 50); ma200 = sma(closes, 200)
    fg = market.get("fear_greed")
    row = {
        "version": VERSION,
        "open_time": last.get("open_time_ms"),
        "dt": last.get("dt"),
        "open": last.get("open"),
        "high": last.get("high"),
        "low": last.get("low"),
        "close": close,
        "return_1": pct(closes[-1], closes[-2]) if len(closes) >= 2 else None,
        "return_4": pct(closes[-1], closes[-5]) if len(closes) >= 5 else None,
        "return_24": pct(closes[-1], closes[-25]) if len(closes) >= 25 else None,
        "past_ret_4h": pct(closes[-1], closes[-5]) if len(closes) >= 5 else None,
        "past_ret_24h": pct(closes[-1], closes[-25]) if len(closes) >= 25 else None,
        "past_ret_7d": pct(closes[-1], closes[-169]) if len(closes) >= 169 else None,
        "past_ret_30d": pct(closes[-1], closes[-721]) if len(closes) >= 721 else None,
        "ma_20": ma20,
        "ma_50": ma50,
        "ma_200": ma200,
        "rsi_14": rsi(closes, 14),
        "volatility_24": vol24,
        "volume_zscore": volume_z,
        "drawdown_from_ath": drawdown,
        "fear_greed": fg,
        "funding_rate": market.get("funding_rate"),
        "coinbase_premium_pct": market.get("coinbase_premium_pct"),
        "spx_close": market.get("spx_close"),
        "spx_ret_1d": market.get("spx_ret_1w_calc"),
        "spx_ret_1w_calc": market.get("spx_ret_1w_calc"),
        "macro_safe": bool(market.get("macro_safe")),
        "macro_source": market.get("macro_source", "live"),
        "macro_bad": not bool(market.get("macro_safe")),
    }
    row["regime"] = infer_regime(close, ma50, ma200, drawdown, fg)
    return row


def fetch_all_and_build_row(cfg, state):
    candles_1h = fetch_binance_klines(interval="1h", limit=int(cfg.get("btc_1h_limit", 1000)), base_urls=cfg.get("binance_base_urls"))
    candles_1d = fetch_binance_klines(interval="1d", limit=int(cfg.get("btc_1d_limit", 1000)), base_urls=cfg.get("binance_base_urls"))
    market = {}
    # Fear & greed cache.
    try:
        fg, cached = cache_get_or_fetch(state, "fear_greed", float(cfg.get("fear_greed_cache_hours", 12)), fetch_fear_greed)
        market.update(fg); market["fear_greed_cached"] = cached
    except Exception as e:
        log(f"WARN fear&greed failed: {e}")
        cached = state.get("cache", {}).get("fear_greed", {}).get("data")
        if cached:
            market.update(cached); market["fear_greed_cached_after_error"] = True
    # Macro cache.
    try:
        macro, cached = cache_get_or_fetch(state, "macro_spy_weekly", float(cfg.get("macro_cache_hours", 24)), lambda: fetch_spy_weekly(cfg.get("alpha_vantage_api_key")))
        market.update(macro); market["macro_cached"] = cached
    except Exception as e:
        log(f"WARN macro failed; continuation will abstain: {e}")
        cached = state.get("cache", {}).get("macro_spy_weekly", {}).get("data")
        if cached:
            market.update(cached); market["macro_cached_after_error"] = True
        else:
            market.update({"macro_safe": False, "spx_ret_1w_calc": None, "macro_source": "missing_live"})
    # Funding diagnostic. Not notified in phase 1, but keep for feature parity.
    try:
        funding = fetch_funding(cfg.get("binance_base_urls"))
        market.update(funding)
    except Exception as e:
        log(f"WARN funding failed; using 0/None: {e}")
        market.setdefault("funding_rate", None)
    # Coinbase premium optional.
    if cfg.get("use_coinbase_premium", True):
        try:
            market.update(fetch_coinbase_premium(candles_1h[-1]["close"]))
        except Exception as e:
            log(f"WARN coinbase premium failed; using 0.0 fallback: {e}")
            market.setdefault("coinbase_premium_pct", 0.0)
    else:
        market.setdefault("coinbase_premium_pct", 0.0)
    row = build_live_row(candles_1h, candles_1d, market)
    return row, market


def active_decision_only(decision, cfg):
    active = set(cfg.get("active_specialists") or [])
    spec = decision.get("selected_specialist") or "none"
    if decision.get("decision") == "NO_TRADE":
        return False
    return spec in active


def should_notify(decision, cfg, state):
    if not active_decision_only(decision, cfg):
        return False, "not_active_scope_or_no_trade"
    tier = decision.get("tier") or "none"
    min_tier = cfg.get("min_notify_tier", "push")
    if TIER_RANK.get(tier, 0) < TIER_RANK.get(min_tier, 2):
        return False, "below_min_tier"
    spec = decision.get("selected_specialist")
    last_map = state.setdefault("last_notified", {})
    last = last_map.get(spec)
    now = utc_now()
    dedup_days = float((cfg.get("dedup_days_by_specialist") or {}).get(spec, 7))
    if last:
        try:
            last_dt = _dt.datetime.fromisoformat(last.get("notified_at", "").replace("Z", ""))
            age_days = (now - last_dt).total_seconds() / 86400.0
            last_tier = last.get("tier", "none")
            if age_days < dedup_days and TIER_RANK.get(tier, 0) <= TIER_RANK.get(last_tier, 0):
                return False, f"dedup_{age_days:.1f}d_since_{spec}_{last_tier}"
        except Exception:
            pass
    return True, "new_signal"


def format_signal_message(row, decision, market, cfg=None):
    cfg = cfg or {}
    spec = decision.get("selected_specialist")
    price = row.get("close")
    fg = row.get("fear_greed")
    regime = row.get("regime")
    horizon = decision.get("primary_horizon")
    tier = decision.get("tier")
    prob = decision.get("prob")
    setup = decision.get("setup_type")
    plan = build_trade_plan(row, decision, cfg)
    hist = plan.get("stats_all_history") or {}
    oos = plan.get("stats_oos_walk_forward") or {}
    parts = [
        f"BEE LIVE PAPER SIGNAL — {spec}",
        f"Model: {spec} | Setup: {setup}",
        f"Action: {decision.get('decision')} | Tier: {tier} | Timeframe: {horizon}",
        f"BTC: {_fmt_usd(price)}" if isinstance(price, (int, float)) else f"BTC: {price}",
        "",
        "PAPER TRADE PLAN",
        f"Entry: {_fmt_usd(plan.get('entry_price'))}",
        f"Take profit / target: {_fmt_usd(plan.get('take_profit_price'))} ({plan.get('take_profit_pct'):.2f}% historical avg move)" if isinstance(plan.get('take_profit_pct'), (int, float)) else f"Take profit / target: {_fmt_usd(plan.get('take_profit_price'))}",
        f"Stoploss / initial trailing stop: {_fmt_usd(plan.get('stoploss_price'))} ({plan.get('initial_trailing_stop_pct'):.1f}% trail)",
        f"Exit policy: {plan.get('exit_policy')}",
        "",
        "MODEL HISTORY",
        f"All historical data — {spec} / {horizon}: n={hist.get('n','?')} | winrate={hist.get('winrate','?')}% | avg={hist.get('avg_return_pct','?')}% | PF={hist.get('pf','?')}",
        f"Walk-forward OOS: n={oos.get('n','?')} | winrate={oos.get('winrate','?')}% | avg={oos.get('avg_return_pct','?')}% | PF={oos.get('pf', oos.get('pf_note','?'))}",
        "",
        f"Regime: {regime} | Fear&Greed: {fg}",
        f"Probability/core score: {prob:.3f}" if isinstance(prob, (int, float)) else f"Probability/core score: {prob}",
        "",
        "Paper forecast only — no automatic trade.",
        "TP/SL are paper levels for monitoring, not an exchange order.",
        ACTIVE_SCOPE_NOTE,
    ]
    if spec == "cycle_reversal":
        parts.append(f"Cycle reason: {decision.get('cycle_reason')} | mom4h={decision.get('cycle_mom_4h')} | mom7d={decision.get('cycle_mom_7d')}")
    if spec in ("reversal", "elite_reversal"):
        parts.append(f"Reversal applies: {decision.get('reversal_applies')} | cycle early: {decision.get('cycle_early_recovery_long')} | confluence: {decision.get('bullish_confluence_label')}")
    return "\n".join(parts)

def send_ntfy(cfg, title, message, priority="default", tags="chart_with_upwards_trend"):
    topic = (cfg.get("ntfy_topic") or "").strip()
    if not topic or topic == "PASTE_PRIVATE_NTFY_TOPIC_HERE":
        log("Ntfy topic missing; signal logged but not pushed.")
        return False
    server = (cfg.get("ntfy_server") or "https://ntfy.sh").rstrip("/")
    url = f"{server}/{urllib.parse.quote(topic)}"
    data = message.encode("utf-8")
    headers = {"Title": title, "Priority": priority, "Tags": tags, "User-Agent": "BEE-LiveForecast/4.1.2"}
    req = urllib.request.Request(url, data=data, headers=headers, method="POST")
    with urllib.request.urlopen(req, timeout=15) as resp:
        resp.read()
    return True


def append_signal_log(payload):
    with open(SIGNAL_LOG_PATH, "a", encoding="utf-8") as f:
        f.write(json.dumps(payload, sort_keys=True, ensure_ascii=False) + "\n")


def run_once(cfg, state, force_notify=False):
    row, market = fetch_all_and_build_row(cfg, state)
    decision = core.decide(row)
    snapshot = {"created_at": iso_now(), "row": row, "decision": decision, "market": market, "version": VERSION}
    save_json(GOLDEN_FEATURE_LOG, snapshot)
    state["last_decision"] = snapshot
    log(f"Decision: {decision.get('decision')} specialist={decision.get('selected_specialist')} tier={decision.get('tier')} horizon={decision.get('primary_horizon')} price={row.get('close')}")
    notify, reason = should_notify(decision, cfg, state)
    if force_notify:
        notify = True; reason = "forced_test"
    payload = {
        "logged_at": iso_now(),
        "version": VERSION,
        "notify_reason": reason,
        "paper_only": True,
        "row": row,
        "decision": decision,
        "trade_plan": build_trade_plan(row, decision, cfg),
        "market": market,
        "active_scope": cfg.get("active_specialists"),
    }
    append_signal_log(payload)
    if notify:
        title = f"BEE {decision.get('selected_specialist')} {decision.get('decision')} {decision.get('tier')}"
        priority = "high" if decision.get("tier") == "elite" else "default"
        msg = format_signal_message(row, decision, market, cfg)
        try:
            pushed = send_ntfy(cfg, title, msg, priority=priority)
            payload["ntfy_pushed"] = pushed
        except Exception as e:
            payload["ntfy_error"] = str(e)
            log(f"WARN ntfy failed: {e}")
        spec = decision.get("selected_specialist") or "unknown"
        state.setdefault("last_notified", {})[spec] = {"notified_at": iso_now(), "tier": decision.get("tier"), "decision": decision.get("decision"), "price": row.get("close")}
    save_state(state)
    return payload


def test_ntfy(cfg):
    msg = "BEE V4.1.3 ntfy test — paper forecast loop is configured. No trading."
    send_ntfy(cfg, "BEE V4.1.3 test", msg, priority="default", tags="test_tube")
    log("Sent ntfy test message.")


def test_fetch(cfg, state):
    row, market = fetch_all_and_build_row(cfg, state)
    print(json.dumps({
        "ok": True,
        "version": VERSION,
        "price": row.get("close"),
        "dt": row.get("dt"),
        "fear_greed": row.get("fear_greed"),
        "regime": row.get("regime"),
        "row_keys": sorted(list(row.keys())),
        "market_keys": sorted(list(market.keys())),
    }, indent=2, sort_keys=True, ensure_ascii=False))
    log("Fetch/build test OK.")


def main():
    parser = argparse.ArgumentParser(description="BEE V4.1.3 Live Forecast Loop — paper mode only")
    parser.add_argument("--once", action="store_true", help="Run one forecast iteration and exit")
    parser.add_argument("--loop", action="store_true", help="Run forever with check_interval_hours")
    parser.add_argument("--daemon", action="store_true", help="Alias for --loop")
    parser.add_argument("--test-ntfy", action="store_true", help="Send one dummy ntfy test and exit")
    parser.add_argument("--test-fetch", action="store_true", help="Fetch live data, build feature row, print result, then exit")
    parser.add_argument("--force-notify", action="store_true", help="Force notify even if no active signal; for testing only")
    args = parser.parse_args()

    if not CONFIG_PATH.exists():
        log(f"Config not found: {CONFIG_PATH.name}. Copy bee_live_config.example.json to bee_live_config.json and fill ntfy/api settings.")
        if CONFIG_EXAMPLE_PATH.exists():
            log(f"Example config exists: {CONFIG_EXAMPLE_PATH}")
    cfg = load_config()
    state = load_state()
    log(f"Starting {VERSION}. Paper only={cfg.get('paper_only')} active={cfg.get('active_specialists')}")
    if args.test_ntfy:
        test_ntfy(cfg); return
    if args.test_fetch:
        test_fetch(cfg, state); return
    if args.daemon:
        args.loop = True
    if args.once or not args.loop:
        run_once(cfg, state, force_notify=args.force_notify)
        return
    interval = max(1.0, float(cfg.get("check_interval_hours", 24))) * 3600.0
    while True:
        try:
            state = load_state()
            run_once(cfg, state)
        except KeyboardInterrupt:
            raise
        except Exception as e:
            log("LOOP ERROR: " + str(e))
            log(traceback.format_exc())
        log(f"Sleeping {interval/3600.0:.1f}h")
        time.sleep(interval)


if __name__ == "__main__":
    main()
