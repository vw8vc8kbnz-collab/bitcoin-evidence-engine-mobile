// M1.1-wereld: Amsterdam 1599 tegen de echte Pieter Bast-kaart.
// Opbouwvolgorde bepaalt wat "wint": platteland → stad → IJ →
// kade → wal+bastions → straten → pleinen → grachten → paalwerk → kades.
import { GRID, T, SEED } from './config.js';
import { fnoise, hash2d } from './rng.js';
import { strokePolyline, fillPolygon, fillRect } from './mapbuild.js';
import MAP from './maps/amsterdam1599.js';

// Schuine IJ-oever: y van de oever op kolom x (met golving)
function shoreY(x) {
  const s = MAP.ijShore;
  const base = s.y0 + ((s.y1 - s.y0) * (x - s.x0)) / (s.x1 - s.x0);
  return base + 4 * fnoise(x / 9, 3.7, SEED ^ 0x11);
}

export function generateWorld() {
  const tiles = new Uint8Array(GRID * GRID);

  // 1. Platteland: veenweide met onregelmatige ontwateringssloten
  for (let y = 0; y < GRID; y++) {
    for (let x = 0; x < GRID; x++) {
      const n = fnoise(x / 13, y / 13, SEED);
      const sloot = (y % 14 === 7) && fnoise(x / 17, y / 5, SEED ^ 0x33) > 0.42;
      tiles[y * GRID + x] = sloot ? T.CANAL : (n > 0.56 ? T.GRASS : T.MARSH);
    }
  }

  // 2. De stad: bouwgrond met hofjes en tuinen
  fillPolygon(tiles, MAP.cityBounds, (x, y) =>
    fnoise(x / 9, y / 9, SEED ^ 0x55) > 0.78 ? T.GRASS : T.DIRT
  );

  // 3. Het IJ: schuine noordelijke waterband
  for (let x = 0; x < GRID; x++) {
    const edge = shoreY(x);
    for (let y = 0; y < edge; y++) tiles[y * GRID + x] = T.IJ;
  }

  // 4. De IJ-kade: havenfront tussen water en stad
  for (let x = MAP.harbor.x0; x <= MAP.harbor.x1; x++) {
    const edge = Math.floor(shoreY(x));
    for (let y = edge; y < edge + 3; y++) {
      const i = y * GRID + x;
      if (tiles[i] !== T.IJ) tiles[i] = T.QUAY;
    }
  }

  // 5. De omwalling: aarden wal met puntbastions
  strokePolyline(tiles, MAP.wall.pts, 1.8, T.WALL);
  for (let i = 0; i < MAP.wall.pts.length; i += MAP.wall.bastionEvery) {
    const [bx, by] = MAP.wall.pts[i];
    strokePolyline(tiles, [[bx, by], [bx, by]], MAP.wall.bastionR * 2, T.WALL);
  }

  // 6. Straten en pleinen
  for (const s of MAP.streets) strokePolyline(tiles, s.pts, s.w, T.STREET);
  for (const p of MAP.plazas) fillRect(tiles, ...p.rect, T.STREET);

  // 7. Waterlopen (snijden nu nog door straten: bruggen zijn M9)
  for (const c of MAP.canals) strokePolyline(tiles, c.pts, c.w, T.CANAL);

  // 8. Paalwerk in het IJ: rijen palen met openingen voor schepen
  for (const p of MAP.palisade) {
    for (let x = p.x0; x <= p.x1; x++) {
      const period = p.dash + p.gap;
      if ((x - p.x0) % period >= p.dash) continue; // opening
      const y = Math.floor(shoreY(x)) + p.yOffset;
      if (y >= 0 && tiles[y * GRID + x] === T.IJ) tiles[y * GRID + x] = T.WALL;
    }
  }

  // 9. Kades: bouwgrond die direct aan grachtwater grenst wordt kade
  const out = new Uint8Array(tiles);
  for (let y = 1; y < GRID - 1; y++) {
    for (let x = 1; x < GRID - 1; x++) {
      const i = y * GRID + x;
      if (tiles[i] !== T.DIRT) continue;
      if (
        tiles[i - 1] === T.CANAL || tiles[i + 1] === T.CANAL ||
        tiles[i - GRID] === T.CANAL || tiles[i + GRID] === T.CANAL
      ) {
        out[i] = T.QUAY;
      }
    }
  }

  return out;
}

export function tileAt(tiles, x, y) {
  if (x < 0 || y < 0 || x >= GRID || y >= GRID) return -1;
  return tiles[y * GRID + x];
}

// Deterministische visuele variant per tegel (spriteselectie).
export function variantAt(x, y) {
  return hash2d(x, y, SEED ^ 0x77) < 0.5 ? 0 : 1;
}
