// Amsterdam anno 1599 — naar de vogelvluchtkaart van Pieter Bast.
// Getekend tegen de echte kaart. De herkenbare elementen:
//   · de asymmetrische halve maan aan het IJ
//   · de oostelijke uitbreiding (Tweede Uitleg, 1593) met de
//     rechthoekige haveneilanden Uilenburg, Valkenburg en Rapenburg
//   · de waaier van burgwallen die naar de Dam toelopen
//   · de omwalling met puntbastions
//   · het dubbele paalwerk (havenpalissade) in het IJ
//
// Coördinaten: tegels op het 256×256-grid, noord (het IJ) boven.
// Tegel ≈ 10 m. Alles is aanpasbaar: verschuif een punt, refresh.

export default {
  name: 'Amsterdam 1599 (naar Pieter Bast)',

  // Zuidoever van het IJ: loopt licht schuin (west hoger dan oost)
  ijShore: { x0: 0, y0: 34, x1: 255, y1: 46 },

  // De stad als polygon, inclusief de oostelijke uitbreiding.
  // Met de klok mee vanaf de westelijke IJ-oever.
  cityBounds: [
    [66, 40],                                   // Haarlemmerpoort-hoek aan het IJ
    [120, 43], [150, 44], [200, 48],            // IJ-oever west → oost (incl. eilanden-front)
    [204, 58],                                  // oostpunt bij de Montelbaanstoren
    [180, 82], [172, 92],                       // Oudeschans zuidwaarts naar de Nieuwmarkt
    [168, 104], [160, 122], [148, 136],         // Kloveniersburgwal
    [140, 144],                                 // Amstel verlaat de stad (Regulierspoort)
    [126, 146], [104, 138], [86, 122],          // zuidelijke Singel
    [72, 100], [64, 72],                        // westelijke Singel
  ],

  // De IJ-kade: havenfront over de volle stadsbreedte
  harbor: { x0: 66, x1: 204 },

  // Dubbel paalwerk in het IJ: rijen palen evenwijdig aan de oever,
  // met openingen voor de schepen (zoals op de Bast-kaart)
  palisade: [
    { yOffset: -5, x0: 78, x1: 196, dash: 7, gap: 3 },
    { yOffset: -9, x0: 90, x1: 184, dash: 9, gap: 4 },
  ],

  // Waterlopen: [punten, breedte]
  canals: [
    // Damrak — open havenwater tot aan de Dam
    { pts: [[122, 40], [121, 58], [123, 76], [125, 90]], w: 5, name: 'Damrak' },
    // Rokin — van de Dam zuidwaarts
    { pts: [[126, 98], [129, 112], [134, 126], [138, 138]], w: 4, name: 'Rokin' },
    // De Amstel — breed de stad uit, meanderend naar het zuiden
    { pts: [[138, 138], [134, 158], [140, 184], [148, 212], [142, 242], [144, 255]], w: 8, name: 'Amstel' },
    // Singel — westelijke en zuidelijke stadsgracht
    { pts: [[66, 38], [63, 70], [71, 100], [86, 124], [105, 140], [126, 148], [139, 145]], w: 4, name: 'Singel' },
    // Geldersekade — vanaf het IJ naar de Nieuwmarkt
    { pts: [[157, 42], [156, 58], [155, 72]], w: 4, name: 'Geldersekade' },
    // Kloveniersburgwal — van de Nieuwmarkt naar de Amstel
    { pts: [[155, 76], [158, 100], [154, 120], [146, 134], [141, 140]], w: 4, name: 'Kloveniersburgwal' },
    // Oudeschans — grens van de Tweede Uitleg, met de Montelbaanstoren
    { pts: [[161, 80], [176, 72], [192, 62], [201, 52]], w: 4, name: 'Oudeschans' },
    // Uilenburgergracht en Valkenburgergracht — de eilandgrachten
    { pts: [[157, 66], [172, 58], [188, 50]], w: 2.5, name: 'Uilenburgergracht' },
    { pts: [[160, 73], [178, 65], [196, 56]], w: 2.5, name: 'Valkenburgergracht' },
    // Oudezijds Voorburgwal
    { pts: [[138, 44], [136, 66], [133, 90], [130, 110], [132, 122]], w: 2, name: 'OZ Voorburgwal' },
    // Oudezijds Achterburgwal
    { pts: [[146, 46], [144, 70], [140, 94], [135, 114], [136, 124]], w: 2, name: 'OZ Achterburgwal' },
    // Nieuwezijds Voorburgwal
    { pts: [[112, 42], [110, 66], [113, 94], [119, 114], [125, 126]], w: 2, name: 'NZ Voorburgwal' },
    // Nieuwezijds Achterburgwal
    { pts: [[100, 44], [98, 72], [104, 102], [113, 124], [121, 134]], w: 2, name: 'NZ Achterburgwal' },
  ],

  // De omwalling: aarden wal met puntbastions, net binnen de stadsgracht
  wall: {
    pts: [
      [69, 42], [66, 70], [74, 99], [88, 121], [106, 136],
      [126, 143], [139, 141], [146, 133], [153, 119], [157, 101],
      [158, 79], [163, 77], [179, 69], [195, 59], [201, 52],
    ],
    bastionEvery: 4,   // om de N punten een bastion
    bastionR: 2.6,
  },

  // Straten: [punten, breedte]
  streets: [
    { pts: [[130, 44], [129, 64], [130, 84], [130, 90]], w: 1.4, name: 'Warmoesstraat' },
    { pts: [[116, 44], [114, 62], [116, 82], [119, 90]], w: 1.4, name: 'Nieuwendijk' },
    { pts: [[122, 98], [118, 112], [116, 126], [119, 136]], w: 1.4, name: 'Kalverstraat' },
    { pts: [[130, 98], [132, 110], [136, 122]], w: 1.2, name: 'Nes' },
    { pts: [[140, 42], [148, 50], [154, 60], [156, 70]], w: 1.4, name: 'Zeedijk' },
    // Sint Antoniesbreestraat — vanaf de Nieuwmarkt de uitbreiding in
    { pts: [[162, 82], [172, 78], [182, 72]], w: 1.4, name: 'Sint Antoniesbreestraat' },
    // Oost-west stegen (bruggen komen in M9)
    { pts: [[102, 86], [122, 86]], w: 1.2, name: 'Gasthuissteeg' },
    { pts: [[127, 102], [156, 98]], w: 1.2, name: 'Oude Doelenstraat' },
    { pts: [[128, 58], [156, 56]], w: 1.2, name: 'Oudebrugsteeg' },
  ],

  // Pleinen: [x0, y0, x1, y1]
  plazas: [
    { rect: [119, 91, 129, 97], name: 'de Dam' },
    { rect: [153, 74, 161, 80], name: 'Nieuwmarkt' },
  ],
};
