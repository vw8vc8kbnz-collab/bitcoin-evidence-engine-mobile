# Stock Evidence Engine v1.9.0

SEE v1.9.0 is the Validation Split Build.

It separates:

1. **Live Opportunity Mode**
   - current technicals
   - current news/catalysts
   - DeepSeek qualitative analysis
   - `live_attention_score`

2. **Validation Mode**
   - no DeepSeek/current news
   - overlap-aware effective n
   - non-overlap average return
   - 90% bootstrap CI
   - excess return vs ticker drift
   - `validated_edge_score`

The dashboard now clearly warns that live signals are not backtest proof.
