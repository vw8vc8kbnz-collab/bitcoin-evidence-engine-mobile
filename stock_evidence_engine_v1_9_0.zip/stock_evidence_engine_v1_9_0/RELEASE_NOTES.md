# Stock Evidence Engine v1.9.0

Validation Split Build.

## Main changes
- Split live opportunity scoring from historical validation.
- DeepSeek is now explicitly live-only: catalyst classification, event quality, priced-in risk and reasoning.
- Historical validation uses no AI/current news.
- Added overlap-aware metrics: original n, effective n, overlap ratio/risk, non-overlap average return, 90% bootstrap CI.
- Added excess vs ticker drift.
- Added validated edge flags requiring effective sample size, positive CI and positive excess.
- Rebuilt scoring into:
  - `live_attention_score`
  - `validated_edge_score`
  - `hybrid_signal_score`
- Added validation warnings: `HIGH_OVERLAP`, `LOW_EFFECTIVE_N`, `NO_EXCESS_VS_DRIFT`, `HIGH_PRICED_IN_RISK`, `NOT_VALIDATED_EDGE`.
- Fixed usable export to only include `usable == 1` rows.
- Added new exports:
  - `see_validation_overlap_v1.9.0.csv`
  - `see_excess_vs_drift_v1.9.0.csv`
  - `see_live_signals_v1.9.0.csv`
  - `see_validated_setups_v1.9.0.csv`

## Important methodology note
Live signals are attention/catalyst opportunities, not proof of historical alpha. Validated setup metrics are calculated separately without DeepSeek/current news.
