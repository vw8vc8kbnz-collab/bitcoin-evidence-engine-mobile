# Outrun IQ v8.4.11 — Business Logout & Account Switch

Correctiebuild bovenop v8.4.10.

## Gefixt
- Zakelijke gebruikers kunnen nu expliciet uitloggen vanuit de Partner Hub.
- Nieuwe zakelijke pagina `/partner/account` toegevoegd voor account, sessie en account wisselen.
- Vanuit zakelijk account kun je direct kiezen:
  - uitloggen en persoonlijk inloggen;
  - uitloggen en met een ander zakelijk account inloggen;
  - alleen uitloggen.
- Partner dashboard heeft nu een duidelijke accountknop in de header.
- Storefront-instellingen bevat ook een account/sessieblok, zodat uitloggen niet verstopt zit.
- Desktop partner sidebar bevat nu ook Account.

## Belangrijk gedrag
- Persoonlijk en zakelijk blijven gescheiden accounts.
- Account wisselen beëindigt eerst veilig de huidige sessie via `/api/auth/logout`.
- Daarna opent `/welkom` meteen met het juiste accounttype: persoonlijk of zakelijk.

## Niet veranderd
- Wallet/finance hardening blijft intact.
- Buyer AI Brain blijft intact.
- Logo/app-icon polish uit v8.4.10 blijft intact.
- Payment live blijft geblokkeerd totdat expliciet veilig vrijgegeven.
