import Link from "next/link";
import { redirect } from "next/navigation";
import { getUser, isPersonalBuyer } from "@/lib/auth";
import { getNotifications, markNotificationsRead } from "@/lib/data";
import { Empty } from "@/components/Empty";
import { Chev } from "@/components/icons";

export const dynamic = "force-dynamic";

const fmt = (iso: string) =>
  new Date(iso).toLocaleString("nl-NL", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });

export default async function Meldingen() {
  const user = await getUser();
  if (!user) redirect("/welkom?next=/meldingen");
  if (!isPersonalBuyer(user)) redirect("/partner");
  const items = await getNotifications(user.id);
  await markNotificationsRead(user.id);
  return (
    <main className="page narrow">
      <h1 className="h1big" style={{ marginTop: 20 }}>Meldingen</h1>
      {items.length === 0 && <Empty title="Nog geen meldingen" text="Orderupdates en belangrijke gebeurtenissen verschijnen hier." cta="Ontdek deals" href="/" />}
      {items.length > 0 && (
        <div className="group" style={{ marginTop: 10 }}>
          {items.map(n => (
            <Link key={n.id} href={n.href} className="li">
              <b>{n.title}<small>{n.body} · {fmt(n.at)}</small></b>
              {!n.read && <span className="nbadge am">NIEUW</span>}
              <Chev />
            </Link>
          ))}
        </div>
      )}
    </main>
  );
}
