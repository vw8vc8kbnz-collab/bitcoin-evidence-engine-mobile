import Link from "next/link";
import { notFound } from "next/navigation";
import { getListing, getSeller, getSellerStats, bumpViews, getSaved, getMyBid, getSellerReviews, ratingOf } from "@/lib/data";
import { getUser } from "@/lib/auth";
import { ListingBody } from "@/components/ListingBody";
import { Gallery } from "@/components/Gallery";
import { explainListingAI } from "@/lib/ai/brain";

export const dynamic = "force-dynamic";

export default async function ListingPage({ params }:{ params: Promise<{ id: string }> }) {
  const { id } = await params;
  const l = await getListing(id);
  if (!l) notFound();
  bumpViews(id);
  const seller = await getSeller(l.sellerSlug);
  const stats = await getSellerStats(l.sellerSlug);
  const rating = ratingOf(await getSellerReviews(l.sellerSlug));
  const user = await getUser();
  const myBid = user ? await getMyBid(l.id, user.id) : null;
  const aiInsight = explainListingAI(l, seller ? [seller] : [], [], user);
  const savedOn = user ? (await getSaved(user.id)).some(s => s.item.listingId === l.id) : false;
  return (
    <main className="page lpg" style={{ paddingBottom: 0 }}>
      <div className="media">
        <Gallery photos={l.photos} fallback={l.fallback} defect={l.defect} title={l.title} />
        <Link href="/" className="back2" aria-label="Terug">
          <svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7" /></svg>
        </Link>
        <span style={{ position: "absolute", zIndex: 4, top: "calc(14px + env(safe-area-inset-top))", right: 14 }}>
        </span>
      </div>
      <ListingBody l={l} sellerName={seller?.name ?? l.sellerSlug} sellerOrders={stats.orders.length} sellerLogo={seller?.logo} myBid={myBid ? { id: myBid.id, amount: myBid.amount, counterAmount: myBid.counterAmount, status: myBid.status } : null} savedOn={savedOn} rating={rating} aiInsight={aiInsight} />
    </main>
  );
}
