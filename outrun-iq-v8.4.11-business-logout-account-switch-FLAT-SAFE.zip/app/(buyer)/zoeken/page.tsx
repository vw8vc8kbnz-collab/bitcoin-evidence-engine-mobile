import Link from "next/link";
import { eur } from "@/lib/data";
import { getUser } from "@/lib/auth";
import { Img } from "@/components/Img";
import { Check, Score } from "@/components/icons";
import { Empty } from "@/components/Empty";
import { rankListingsForBuyer } from "@/lib/ai/brain";

export const dynamic = "force-dynamic";

const SORTS = [
  { v: "ai", label: "AI beste" },
  { v: "waarde", label: "Waarde" },
  { v: "prijs", label: "Prijs ↑" },
  { v: "korting", label: "Korting ↓" },
  { v: "nieuw", label: "Nieuw" },
] as const;

export default async function Zoeken({ searchParams }:{
  searchParams: Promise<{ q?: string; sort?: string; max?: string }>;
}) {
  const { q = "", sort = "ai", max = "" } = await searchParams;
  const user = await getUser();
  const maxPrice = max ? Number(max) : undefined;
  const { ranked } = await rankListingsForBuyer({ user, query: q, sort: sort === "waarde" ? "ai" : sort, maxPrice });
  if (sort === "waarde") ranked.sort((a,b)=>b.ai.priceScore + b.ai.dealScore - (a.ai.priceScore + a.ai.dealScore));
  return (
    <main className="page searchBrainPage">
      <header className="hd">
        <Link href="/" className="back" aria-label="Terug">
          <svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7" /></svg>
        </Link>
        <form action="/zoeken" className="srchbar">
          <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="6.5" /><path d="M20 20l-4.2-4.2" /></svg>
          <input name="q" defaultValue={q} placeholder="Zoek producten, merken of stores" autoComplete="off" />
        </form>
      </header>
      <section className="searchBrainIntro">
        <span>AI DISCOVERY</span>
        <b>{q ? `Beste matches voor “${q}”` : "Live voorraad, slim gerangschikt"}</b>
        <p>Outrun sorteert niet alleen op nieuw of prijs, maar op waarde, vertrouwen, schaarste, deal-score en relevantie.</p>
      </section>
      <div className="fbar aiSortBar">
        {SORTS.map(s2 => (
          <Link key={s2.v} href={`/zoeken?q=${encodeURIComponent(q)}&sort=${s2.v}${max ? `&max=${encodeURIComponent(max)}` : ""}`} className={`f${sort === s2.v ? " on" : ""}`}>{s2.label}</Link>
        ))}
      </div>
      <div className="count">{ranked.length} {ranked.length === 1 ? "AI-MATCH" : "AI-MATCHES"}{q ? ` · "${q.toUpperCase()}"` : ""}</div>
      {ranked.length === 0 && (
        <Empty title="Niets gevonden" text={q ? `Geen sterke AI-match voor "${q}". Probeer een ander woord of AI Vinder.` : "Er staan nog geen listings live."} cta="Open AI Vinder" href="/vinder" />
      )}
      <div className="rows aiRows">
        {ranked.map(({ listing: l, ai }) => (
          <Link key={l.id} href={`/listing/${l.id}`} className="rowc aiResultRow">
            <Img src={l.photos[0]} fallback={l.fallback}><Score v={ai.finalScore} /></Img>
            <span className="tx">
              <span className="aiMatchLine"><b>{ai.label}</b><em>{ai.finalScore}/100</em></span>
              <span className="t">{l.title}</span>
              <span className="c">{ai.reason}</span>
              <span className="s"><Check />{l.pickupCity}</span>
              <span className="bot">
                <b>{eur(l.price)}{l.perUnit && "/st"}</b>
                <span className="d">−{Math.round((1 - l.price / l.newPrice) * 100)}%</span>
                <span className="km">Trust {ai.trustScore}</span>
              </span>
            </span>
          </Link>
        ))}
      </div>
    </main>
  );
}
