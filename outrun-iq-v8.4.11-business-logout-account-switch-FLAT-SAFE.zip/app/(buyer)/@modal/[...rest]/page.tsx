/** Catch-all voor het @modal-slot: elke route die niet expliciet geïntercept wordt
 *  (bv. /checkout/*) rendert null in het slot, zodat de sheet sluit bij navigatie.
 *  Zonder dit bestand blijft de laatst geopende sheet over de nieuwe pagina hangen. */
export default function ModalCatchAll() {
  return null;
}
