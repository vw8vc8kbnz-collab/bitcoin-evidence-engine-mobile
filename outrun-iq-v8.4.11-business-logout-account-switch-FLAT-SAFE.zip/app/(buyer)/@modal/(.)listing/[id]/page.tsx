import { notFound } from "next/navigation";
import { getUser } from "@/lib/auth";
import { getListing, getSeller, getSellerStats, bumpViews, getMyBid, getSellerReviews, ratingOf, getSaved } from "@/lib/data";
import { BottomSheet } from "@/components/BottomSheet";
import { ListingBody } from "@/components/ListingBody";
import { Gallery } from "@/components/Gallery";
import { explainListingAI } from "@/lib/ai/brain";

export const dynamic = "force-dynamic";

export default async function ListingModal({ params }:{ params: Promise<{ id: string }> }) {
  const { id } = await params;
  const l = await getListing(id);
  if (!l) notFound();
  bumpViews(id);
  const seller = await getSeller(l.sellerSlug);
  const stats = await getSellerStats(l.sellerSlug);
  const rating = ratingOf(await getSellerReviews(l.sellerSlug));
  const user = await getUser();
  const myBid = user ? await getMyBid(l.id, user.id) : null;
  const aiInsight = explainListingAI(l, seller ? [seller] : [], [], user);
  const savedOn = user ? (await getSaved(user.id)).some(x => x.item.listingId === l.id) : false;
  return (
    <BottomSheet title={l.title}>
      <div className="media nativeMedia">
        <Gallery photos={l.photos} fallback={l.fallback} defect={l.defect} title={l.title} />
      </div>
      <ListingBody l={l} sellerName={seller?.name ?? l.sellerSlug} sellerOrders={stats.orders.length} sellerLogo={seller?.logo} myBid={myBid ? { id: myBid.id, amount: myBid.amount, counterAmount: myBid.counterAmount, status: myBid.status } : null} savedOn={savedOn} rating={rating} aiInsight={aiInsight} />
    </BottomSheet>
  );
}
