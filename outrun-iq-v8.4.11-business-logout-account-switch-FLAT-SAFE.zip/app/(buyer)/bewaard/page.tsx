import Link from "next/link";
import { redirect } from "next/navigation";
import { getUser, isPersonalBuyer } from "@/lib/auth";
import { getSaved, eur } from "@/lib/data";
import { Img } from "@/components/Img";
import { Check, Score } from "@/components/icons";
import { Empty } from "@/components/Empty";
import { SavedMigrator } from "@/components/SaveButton";

export const dynamic = "force-dynamic";

export default async function Bewaard() {
  const user = await getUser();
  if (!user) redirect("/welkom?next=/bewaard");
  if (!isPersonalBuyer(user)) redirect("/partner");
  const saved = await getSaved(user.id);
  return (
    <main className="page">
      <SavedMigrator />
      <h1 className="h1big" style={{ marginTop: 20 }}>Bewaard</h1>
      <div className="count" style={{ marginTop: 4 }}>{saved.length} {saved.length === 1 ? "ITEM" : "ITEMS"}</div>
      {saved.length === 0 && (
        <Empty title="Nog niets bewaard" text="Tik op het bladwijzer-icoon bij een listing om hem hier te bewaren." cta="Ontdek deals" href="/" />
      )}
      <div className="rows">
        {saved.map(({ item, listing: l }) => {
          const drop = item.savedAtPrice - l.price;
          return (
            <Link key={l.id} href={`/listing/${l.id}`} className="rowc">
              <Img src={l.photos[0]} fallback={l.fallback}><Score v={l.confidence} /></Img>
              <span className="tx">
                <span className="t">{l.title}</span>
                <span className="c">{l.condition || `Conditie ${l.conditionScore}/10`}</span>
                <span className="s"><Check />{l.pickupCity}</span>
                <span className="bot">
                  <b>{eur(l.price)}{l.perUnit && "/st"}</b>
                  <span className="d">−{Math.round((1 - l.price / l.newPrice) * 100)}%</span>
                  {drop > 0 && <span className="km" style={{ color: "var(--ok)", fontWeight: 700 }}>↓ {eur(drop)} SINDS BEWAARD</span>}
                </span>
              </span>
            </Link>
          );
        })}
      </div>
    </main>
  );
}
