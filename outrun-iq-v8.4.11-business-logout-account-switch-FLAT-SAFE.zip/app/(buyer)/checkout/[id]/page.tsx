import Link from "next/link";
import { notFound } from "next/navigation";
import { paymentsMode } from "@/lib/payments";
import { getListing, getSeller, eur, getMyBid } from "@/lib/data";
import { getUser, isPersonalBuyer } from "@/lib/auth";
import { redirect } from "next/navigation";
import { Img } from "@/components/Img";
import { CheckoutForm } from "@/components/CheckoutForm";

export const dynamic = "force-dynamic";

export default async function Checkout({ params, searchParams }:{
  params: Promise<{ id: string }>; searchParams: Promise<{ bid?: string }>;
}) {
  const { id } = await params;
  const { bid: bidParam } = await searchParams;
  const l = await getListing(id);
  if (!l || l.status !== "active") notFound();
  const user = await getUser();
  if (!user) redirect(`/welkom?next=/checkout/${id}`);
  if (!isPersonalBuyer(user)) redirect("/partner");
  const seller = await getSeller(l.sellerSlug);
  const myBid = bidParam ? await getMyBid(l.id, user.id) : null;
  const bidActive = !!(myBid && myBid.id === bidParam && myBid.status === "accepted");
  const effectivePrice = bidActive ? myBid!.amount : l.price;
  return (
    <main className="page narrow" style={{ paddingBottom: 170 }}>
      <header className="hd">
        <Link href={`/listing/${l.id}`} className="back">
          <svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7" /></svg>Terug
        </Link>
        <span className="sp" /><span className="mini">AFREKENEN</span>
      </header>
      <h1 className="h1big">Afrekenen</h1>
      <div style={{ height: 8 }} />
      <div className="oprod">
        <Img src={l.photos[0]} fallback={l.fallback} />
        <span><b>{l.title}</b><span>{seller?.name ?? l.sellerSlug} ✓</span></span>
        <span className="pr">{eur(l.price)}</span>
      </div>
      <CheckoutForm
        listingId={l.id} price={effectivePrice} perUnit={l.perUnit} bidId={bidActive ? myBid!.id : undefined}
        deliveryLabel={l.delivery} deliveryPrice={l.deliveryPrice} pickupCity={l.pickupCity}
        pickupAddress={seller?.address ? `${seller.address.street}, ${seller.address.postcode} ${seller.address.city}` : undefined}
        buyerName={user.name}
      />
    </main>
  );
}
