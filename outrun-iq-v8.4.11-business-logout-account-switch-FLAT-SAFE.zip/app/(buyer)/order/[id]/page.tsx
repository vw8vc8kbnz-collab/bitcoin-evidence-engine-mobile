import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { getOrder, getListing, getSeller, eur, sweepOrders, releaseDaysFor, RETURN_WINDOW_DAYS, paidOutAt, getSellerReviews } from "@/lib/data";
import { getUser, isPersonalBuyer } from "@/lib/auth";
import type { OrderStatus } from "@/lib/types";
import { Img } from "@/components/Img";
import { ConfirmDelivery } from "@/components/ConfirmDelivery";
import { DisputeForm } from "@/components/DisputeForm";
import { ReturnSection } from "@/components/ReturnSection";
import { SlotPicker } from "@/components/SlotPicker";
import { ChatSection } from "@/components/ChatSection";

export const dynamic = "force-dynamic";

const STEPS: { s: OrderStatus; label: string; sub: string }[] = [
  { s: "paid", label: "Betaald (testmodus)", sub: "Geld staat veilig bij Outrun IQ" },
  { s: "confirmed", label: "Partner heeft bevestigd", sub: "Partner maakt je bestelling klaar" },
  { s: "delivery_planned", label: "Levering gepland", sub: "Partner plant het moment met je" },
  { s: "delivered", label: "Geleverd — bevestig ontvangst", sub: "Of meld een probleem" },
  { s: "paid_out", label: "Afgerond · partner uitbetaald", sub: "Na jouw bevestiging" },
];
const ORDER: OrderStatus[] = ["paid", "confirmed", "delivery_planned", "delivered", "delivered_buyer_confirmed", "paid_out"];

const fmt = (iso: string) =>
  new Date(iso).toLocaleString("nl-NL", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
const fmtDay = (d: Date) => d.toLocaleDateString("nl-NL", { weekday: "short", day: "numeric", month: "short" });

export default async function Order({ params }:{ params: Promise<{ id: string }> }) {
  const { id } = await params;
  await sweepOrders();
  const o = await getOrder(id);
  if (!o) notFound();
  const user = await getUser();
  if (!user) redirect(`/welkom?next=/order/${id}`);
  if (!isPersonalBuyer(user)) redirect("/partner");
  if (o.buyerId !== user.id && user.role !== "admin") notFound();
  const l = await getListing(o.listingId);
  const seller = await getSeller(o.sellerSlug);
  const idx = ORDER.indexOf(o.status);
  const deliveredAt = o.events.find(e => e.status === "delivered")?.at;
  const releaseDays = releaseDaysFor(seller?.trusted);
  const releaseAt = deliveredAt ? new Date(+new Date(deliveredAt) + releaseDays * 864e5) : null;
  const openReturn = !!o.returnRequest && o.returnRequest.status !== "completed";
  const myReview = (await getSellerReviews(o.sellerSlug)).find(r => r.orderId === o.id);
  const canConfirm = ["delivery_planned", "delivered"].includes(o.status) && !openReturn;
  const paidAt = paidOutAt(o);
  const withinReturnWindow = !!paidAt && Date.now() - +new Date(paidAt) <= RETURN_WINDOW_DAYS * 864e5;
  const done = <svg viewBox="0 0 12 12"><path d="M2.5 6l2.5 2.5L9.5 3.5" /></svg>;

  return (
    <main className="page narrow" style={{ paddingBottom: canConfirm ? 170 : undefined }}>
      <header className="hd">
        <Link href="/account" className="back">
          <svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7" /></svg>Account
        </Link>
        <span className="sp" /><span className="mini">{o.id}</span>
      </header>
      <section className="orderHero">
        <span className="eyebrow">ORDER {o.id}</span>
        <h1>Je bestelling</h1>
        <p>{o.status === "paid_out" ? "Afgerond. De partner is uitbetaald." : o.status === "disputed" ? "Uitbetaling gepauzeerd. Outrun IQ kijkt mee." : "Je betaling blijft beschermd tot de levering is bevestigd."}</p>
      </section>
      <div className="oprod">
        <Img src={l?.photos[0]} fallback={l?.fallback ?? "tv"} />
        <span><b>{o.itemTitle}</b><span>{o.deliveryChoice === "bezorgen" ? "Bezorging" : "Ophalen"} · testmodus</span></span>
        <span className="pr">{eur(o.totalPaid)}</span>
      </div>

      {o.deliveryChoice === "bezorgen" && o.deliveryAddress && (
        <>
          <div className="slabel">BEZORGADRES</div>
          <div className="group"><div className="li">
            <b>{o.deliveryAddress.name || user.name}<small>{o.deliveryAddress.street} · {o.deliveryAddress.postcode} {o.deliveryAddress.city}</small></b>
          </div></div>
        </>
      )}
      {o.deliveryChoice === "ophalen" && (
        <>
          <div className="slabel">OPHALEN BIJ {seller?.name?.toUpperCase() ?? "PARTNER"}</div>
          <div className="group">
            <div className="li">
              <b>{seller?.address ? `${seller.address.street}` : "Adres volgt via de partner"}
                <small>{seller?.address ? `${seller.address.postcode} ${seller.address.city}` : seller?.city ?? ""}</small></b>
            </div>
            {o.pickupCode && (
              <div className="li">
                <b>Jouw afhaalcode<small>toon deze bij het ophalen</small></b>
                <span className="val mono" style={{ fontSize: 17, letterSpacing: 3, color: "var(--petrol)" }}>{o.pickupCode}</span>
              </div>
            )}
          </div>
        </>
      )}

      {o.status === "delivery_planned" && o.deliverySlots && !o.chosenSlotAt && (
        <SlotPicker orderId={o.id} slots={o.deliverySlots} />
      )}
      {o.chosenSlotAt && (
        <>
          <div className="slabel">BEZORGMOMENT</div>
          <div className="group"><div className="li">
            <b>{new Date(o.chosenSlotAt).toLocaleString("nl-NL", { weekday: "long", day: "numeric", month: "long", hour: "2-digit", minute: "2-digit" })}
              <small>afgestemd met de partner</small></b>
          </div></div>
        </>
      )}
      <div className="orderShield buyerOnly">
        <div><b>{eur(o.totalPaid)}</b><span>betaald in testmodus</span></div>
        <div><b>Beschermd</b><span>je betaling blijft veilig tot levering is bevestigd</span></div>
      </div>

      <div className="slabel">STATUS · GELD VEILIG IN ESCROW</div>
      {o.status === "disputed" && (
        <p className="note" style={{ color: "var(--amber-deep)", fontWeight: 700 }}>
          ⚠ Probleem gemeld ({o.dispute?.category}). De order is bevroren en de uitbetaling geblokkeerd tot Outrun IQ dit heeft afgehandeld.
        </p>
      )}
      {o.status === "cancelled" && <p className="note" style={{ fontWeight: 700 }}>Deze order is geannuleerd.</p>}
      <div className="stepper">
        {STEPS.map(step => {
          const stepIdx = ORDER.indexOf(step.s);
          const state = idx > stepIdx || o.status === "paid_out" && step.s === "paid_out" ? "done"
            : stepIdx === idx ? "now" : "todo";
          const ev = o.events.find(e => e.status === step.s);
          return (
            <div key={step.s} className={`st ${state}`}>
              <span className="rl"><i>{state === "done" ? done : null}</i><u /></span>
              <span className="tx2"><b>{step.label}</b><span>{ev ? `${fmt(ev.at)}${ev.note ? ` · ${ev.note}` : ""}` : step.sub}</span></span>
            </div>
          );
        })}
      </div>

      {o.status === "delivered" && openReturn && (
        <p className="note" style={{ color: "var(--amber-deep)", fontWeight: 700 }}>De uitbetaling is gepauzeerd zolang je retouraanvraag loopt — het geld staat nog veilig in escrow.</p>
      )}
      {o.status === "delivered" && !openReturn && releaseAt && (
        <p className="note" style={{ color: "var(--amber-deep)" }}>
          Bevestig je ontvangst of meld een probleem vóór <b>{fmtDay(releaseAt)}</b> — daarna geven we de uitbetaling automatisch vrij.
        </p>
      )}
      {!["paid_out", "cancelled", "disputed"].includes(o.status) && <DisputeForm orderId={o.id} />}
      {canConfirm && o.status !== "disputed" && <ConfirmDelivery orderId={o.id} />}
      {o.status !== "cancelled" && (
        <>
          <div className="slabel">CHAT MET DE PARTNER</div>
          <ChatSection orderId={o.id} messages={o.messages ?? []} me="buyer" inset />
        </>
      )}
      {o.status === "paid_out" && <p className="note">Afgerond. De bestelling is bevestigd en veilig afgerond.</p>}
      {o.status === "paid_out" && !myReview && (
        <section className="reviewPrompt">
          <b>Help de volgende koper</b>
          <span>Laat kort weten hoe deze partner leverde. Reviews blijven gekoppeld aan geverifieerde aankopen.</span>
        </section>
      )}
      {["paid_out", "delivered"].includes(o.status) && (
        <ReturnSection
          orderId={o.id} ret={o.returnRequest}
          withinWindow={o.status === "delivered" ? true : withinReturnWindow}
          supportEmail={seller?.support?.email} supportPhone={seller?.support?.phone} returnsInfo={seller?.support?.returnsInfo}
        />
      )}
    </main>
  );
}
