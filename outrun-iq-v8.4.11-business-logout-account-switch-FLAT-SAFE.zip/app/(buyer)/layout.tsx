import { redirect } from "next/navigation";
import { BuyerDock, TopNav } from "@/components/Dock";
import { SplashIntro } from "@/components/SplashIntro";
import { getUser, isAdmin, isApprovedPartner } from "@/lib/auth";

export const dynamic = "force-dynamic";

export default async function BuyerLayout({
  children, modal,
}: { children: React.ReactNode; modal: React.ReactNode }) {
  const user = await getUser();
  // Gesloten werelden: zakelijke/admin sessies krijgen nooit de buyer-shell of buyer dock te zien.
  if (isAdmin(user)) redirect("/beheer");
  if (isApprovedPartner(user)) redirect("/partner");
  return (
    <div className="app">
      <SplashIntro />
      <TopNav />
      {children}
      {modal}
      <BuyerDock />
    </div>
  );
}
