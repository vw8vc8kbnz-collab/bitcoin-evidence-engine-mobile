import Link from "next/link";
import { Stars } from "@/components/Reviews";
import { notFound } from "next/navigation";
import { getSellerReviews, ratingOf, getSeller, getSellerStats, eur } from "@/lib/data";
import { Img } from "@/components/Img";
import { Check, Score } from "@/components/icons";
import { Empty } from "@/components/Empty";

export const dynamic = "force-dynamic";

export default async function Store({ params }:{ params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const s = await getSeller(slug);
  if (!s) notFound();
  const stats = await getSellerStats(slug);
  const reviews = await getSellerReviews(slug);
  const rating = ratingOf(reviews);
  const items = stats.listings.filter(l => l.status === "active" && l.stock > 0);
  return (
    <main className="page">
      <header className="hd">
        <Link href="/" className="back">
          <svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7" /></svg>Terug
        </Link>
      </header>
      <div className="sfprev" style={{ margin: "4px 16px 0", ...(s.banner
        ? { backgroundImage: `linear-gradient(rgba(9,20,22,.5), rgba(9,20,22,.75)), url(${s.banner})`, backgroundSize: "cover", backgroundPosition: "center" }
        : { background: "var(--petrol-deep)" }) }}>
        <span className="sh2" />
        <span className="in">
          <span className="av" style={{ width: 50, height: 50, flex: "none", overflow: "hidden", borderRadius: 13 }}>{s.logo
            ? /* eslint-disable-next-line @next/next/no-img-element */
              <img src={s.logo} alt="" style={{ width: "100%", height: "100%", objectFit: "cover", borderRadius: "inherit" }} />
            : s.name.slice(0, 2).toUpperCase()}</span>
          <span><b>{s.name} ✓</b><span>{s.city.toUpperCase()} · {stats.orders.length} ORDERS{rating ? ` · ★ ${rating.avg} (${rating.count})` : ""} · KVK-GEVERIFIEERD</span></span>
        </span>
      </div>
      {s.about && <p className="note" style={{ marginTop: 10 }}>{s.about}</p>}
      {reviews.length > 0 && (
        <>
          <div className="sec"><h2>Reviews</h2><span className="mono">★ {rating!.avg} · {rating!.count}</span></div>
          {reviews.slice(0, 10).map(r => (
            <div key={r.id} className="group" style={{ marginTop: 8 }}>
              <div className="li" style={{ display: "block" }}>
                <span style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <Stars n={r.rating} />
                  <b style={{ fontSize: 13 }}>{r.buyerName}</b>
                  <span className="mini" style={{ marginLeft: "auto" }}>{new Date(r.at).toLocaleDateString("nl-NL", { day: "numeric", month: "short" }).toUpperCase()} · GEVERIFIEERD</span>
                </span>
                {r.text && <p style={{ margin: "8px 0 0", fontSize: 13, lineHeight: 1.55, color: "var(--txt2)" }}>{r.text}</p>}
                {r.reply && (
                  <p style={{ margin: "8px 0 0", fontSize: 12.5, lineHeight: 1.5, color: "var(--txt2)", borderLeft: "3px solid var(--petrol-soft)", paddingLeft: 10 }}>
                    <b style={{ color: "var(--petrol-deep)" }}>{s.name}:</b> {r.reply.text}
                  </p>
                )}
              </div>
            </div>
          ))}
        </>
      )}
      <div className="sec"><h2>Aanbod</h2><span className="mono">{items.length} LIVE</span></div>
      {items.length === 0 && <Empty title="Nog geen live listings" text={`${s.name} heeft momenteel niets in de verkoop.`} />}
      <div className="rows">
        {items.map(l => (
          <Link key={l.id} href={`/listing/${l.id}`} className="rowc">
            <Img src={l.photos[0]} fallback={l.fallback}><Score v={l.confidence} /></Img>
            <span className="tx">
              <span className="t">{l.title}</span>
              <span className="c">{l.condition || `Conditie ${l.conditionScore}/10`}</span>
              <span className="s"><Check />{l.pickupCity}</span>
              <span className="bot"><b>{eur(l.price)}{l.perUnit && "/st"}</b>
                <span className="d">−{Math.round((1 - l.price / l.newPrice) * 100)}%</span></span>
            </span>
          </Link>
        ))}
      </div>
    </main>
  );
}
