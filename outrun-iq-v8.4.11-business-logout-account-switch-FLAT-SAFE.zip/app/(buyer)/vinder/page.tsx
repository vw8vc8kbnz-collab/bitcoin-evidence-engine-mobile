"use client";
import Link from "next/link";
import { useState } from "react";
import { eur, type Listing } from "@/lib/types";
import { Img } from "@/components/Img";
import { Check, Score } from "@/components/icons";

export default function Vinder() {
  const [prompt, setPrompt] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [res, setRes] = useState<{ interpretation: string; maxPrice?: number; source: string; listings: Listing[]; scores?: { id: string; score: number; reason: string; label: string }[] } | null>(null);

  async function go() {
    setBusy(true); setErr(""); setRes(null);
    const r = await fetch("/api/vinder", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ prompt }),
    });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (r.ok) setRes(j); else setErr(j.error || "Zoeken mislukt");
  }

  return (
    <main className="page aiFinderPage">
      <section className="aiFinderHero"><span>OUTRUN AI VINDER 2.0</span><h1>Vertel wat je zoekt. AI maakt je shortlist.</h1><p>Outrun vertaalt je wens naar prijs, categorie, trust, voorraad en plaats. Promotie telt alleen mee als de deal echt relevant blijft.</p></section>
      <div className="authcard" style={{ margin: "10px 16px 0" }}>
        <textarea
          value={prompt} onChange={e => setPrompt(e.target.value)} rows={3}
          placeholder={"Bijv.: stille wasmachine voor een gezin van vijf, liefst Bosch of Siemens, max €600"}
          style={{ width: "100%", border: "1px solid var(--line)", borderRadius: 13, padding: "13px 14px", font: "inherit", fontSize: 14, background: "var(--card)", outline: "none", resize: "vertical", color: "var(--txt)" }}
        />
        <button className="btn pri abtn" onClick={go} disabled={busy || prompt.trim().length < 3}>
          {busy ? "AI zoekt…" : "Vind het voor me"}
        </button>
        {err && <p className="note" style={{ color: "var(--amber-deep)", marginTop: 10 }}>{err}</p>}
      </div>
      {res && (
        <>
          <div className="count" style={{ marginTop: 18 }}>
            {res.listings.length} {res.listings.length === 1 ? "MATCH" : "MATCHES"}{res.maxPrice ? ` · MAX €${res.maxPrice}` : ""} · {res.source.toUpperCase()}
          </div>
          <p className="note" style={{ marginTop: 6 }}>✦ {res.interpretation}</p>
          <div className="rows">
            {res.listings.map(l => { const ai = res.scores?.find(s => s.id === l.id); return (
              <Link key={l.id} href={`/listing/${l.id}`} className="rowc aiResultRow">
                <Img src={l.photos[0]} fallback={l.fallback}><Score v={l.confidence} /></Img>
                <span className="tx">
                  <span className="aiMatchLine"><b>{ai?.label ?? "AI match"}</b><em>{ai?.score ?? l.confidence}/100</em></span>
                  <span className="t">{l.title}</span>
                  <span className="c">{ai?.reason ?? l.condition ?? `Conditie ${l.conditionScore}/10`}</span>
                  <span className="s"><Check />{l.pickupCity}</span>
                  <span className="bot"><b>{eur(l.price)}{l.perUnit && "/st"}</b>
                    <span className="d">−{Math.round((1 - l.price / l.newPrice) * 100)}%</span></span>
                </span>
              </Link>
            )})}
          </div>
        </>
      )}
    </main>
  );
}
