import Link from "next/link";
import { Mark } from "@/components/icons";
import { BackButton } from "@/components/BackButton";

export default function JuridischLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="app">
      <main className="page narrow legal">
        <header className="hd" style={{ display: "flex" }}>
          <BackButton />
          <span className="sp" />
          <Link href="/" className="lock"><Mark />OUTRUN <b>IQ</b></Link>
        </header>
        {children}
        <Link href="/" className="btn sec" style={{ display: "block", textAlign: "center", marginTop: 26 }}>Terug naar de app</Link>
        <p className="note" style={{ marginTop: 16 }}>
          <Link href="/juridisch/gebruiksvoorwaarden">Gebruiksvoorwaarden</Link> · <Link href="/juridisch/partnervoorwaarden">Partnervoorwaarden</Link> · <Link href="/juridisch/retourvoorwaarden">Retouren</Link> · <Link href="/juridisch/privacy">Privacy</Link> · <Link href="/juridisch/cookies">Cookies</Link>
        </p>
      </main>
    </div>
  );
}
