export const metadata = { title: "Cookieverklaring — Outrun IQ" };

export default function Cookies() {
  return (
    <article>
      <h1 className="h1big">Cookieverklaring Outrun IQ</h1>
      <p className="lmeta">Versie 1.0 · juli 2026</p>

      <h2>Welke cookies we gebruiken</h2>
      <p>Outrun IQ gebruikt uitsluitend functionele en technisch noodzakelijke opslag. Concreet: het sessiecookie <code>oiq_sessie</code> (httpOnly, 30 dagen) om je ingelogd te houden, en lokale browseropslag voor kleine voorkeuren zoals het eenmalig tonen van de intro-animatie. Deze zijn strikt noodzakelijk voor de werking van het platform.</p>

      <h2>Geen tracking</h2>
      <p>Wij plaatsen géén analytische, advertentie- of trackingcookies en geen cookies van derden. Omdat we uitsluitend functionele cookies gebruiken, is op grond van de Telecommunicatiewet en de AVG geen voorafgaande toestemming (cookiebanner) vereist. Mocht dit in de toekomst veranderen — bijvoorbeeld bij het toevoegen van statistiek met impact op je privacy — dan vragen we eerst je toestemming en werken we deze verklaring bij.</p>

      <h2>Cookies verwijderen</h2>
      <p>Je kunt cookies en lokale opslag altijd wissen via de instellingen van je browser. Verwijder je het sessiecookie, dan word je uitgelogd.</p>
    </article>
  );
}
