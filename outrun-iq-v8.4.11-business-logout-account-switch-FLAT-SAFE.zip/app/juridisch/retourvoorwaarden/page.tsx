export const metadata = { title: "Retourvoorwaarden — Outrun IQ" };

export default function Retourvoorwaarden() {
  return (
    <article>
      <h1 className="h1big">Retourvoorwaarden Outrun IQ</h1>
      <p className="lmeta">Versie 1.0 · juli 2026 · aanvulling op de Gebruiksvoorwaarden en Partnervoorwaarden</p>

      <h2>1. Uitgangspunt: de Partner is je verkoper</h2>
      <p>Koopovereenkomsten komen tot stand tussen jou en de Partner. Retouren, herroeping, terugbetaling en garantieafhandeling verlopen daarom rechtstreeks via de Partner. Outrun IQ is bemiddelaar: wij faciliteren het retourproces in de app, bewaken de reactietermijnen en kunnen bemiddelen bij escalatie, maar zijn geen partij bij de koop en zelf niet gehouden tot terugbetaling, vervanging of schadevergoeding.</p>

      <h2>2. Retour aanvragen</h2>
      <p>Je dient een retouraanvraag in via de orderpagina in de app, vanaf het moment van levering en uiterlijk 14 dagen na afronding van de order, onder vermelding van de reden. Dien je de aanvraag in terwijl de uitbetaling aan de Partner nog niet heeft plaatsgevonden, dan wordt die uitbetaling automatisch gepauzeerd totdat de retour is afgehandeld; bij een correct afgeronde retour in die fase ontvang je het bedrag rechtstreeks terug uit escrow. Buiten de app om gemelde retouren vallen buiten dit proces; gebruik altijd de app zodat termijnen en communicatie vastliggen.</p>

      <h2>3. Reactieplicht van de Partner</h2>
      <p>De Partner reageert binnen 3 dagen op je aanvraag met concrete retourinstructies (retouradres, wijze van verzending of ophalen, en de verdere afhandeling). De klantenservicegegevens van de Partner (e-mail en waar beschikbaar telefoon) staan bij je retouraanvraag in de app.</p>

      <h2>4. Geen reactie? Escalatie naar Outrun IQ</h2>
      <p>Reageert de Partner niet binnen de termijn, dan kun je de aanvraag in de app escaleren naar Outrun IQ. Wij spreken de Partner aan en bewaken de afhandeling. Herhaald niet-reageren heeft gevolgen voor de partnerstatus (waaronder schorsing van het account en opschorting van toekomstige uitbetalingen als drukmiddel), conform de Partnervoorwaarden. Escalatie maakt Outrun IQ géén partij bij de koopovereenkomst en vestigt geen zelfstandige betalingsverplichting van Outrun IQ.</p>

      <h2>5. Terugbetaling</h2>
      <p>Na ontvangst van de retour betaalt de Partner het aankoopbedrag terug binnen de wettelijke termijn (uiterlijk 14 dagen na herroeping, waarbij de Partner mag wachten tot ontvangst van de zaak of bewijs van terugzending). Retourkosten en -transport, zwart-wit: (a) herroeping zonder gebrek ("spijt") — jij regelt en betaalt de terugzending volgens de instructies van de Partner; (b) defect product — de Partner regelt of vergoedt het transport; (c) product wijkt af van de listing — de Partner regelt of vergoedt het transport; (d) verkeerde levering — de Partner regelt of vergoedt het transport. Bij grote artikelen (zoals witgoed en keukens) geldt in de gevallen b t/m d dat de Partner het ophalen verzorgt. Zolang het platform in testfase draait, zijn betalingen en terugbetalingen gesimuleerd.</p>

      <h2>6. Uitzonderingen en staat van het product</h2>
      <p>Wettelijke uitzonderingen op het herroepingsrecht blijven van toepassing (waaronder verzegelde hygiënegevoelige producten na verbreking van de verzegeling en op maat gemaakte zaken). Je mag het product beoordelen zoals in een winkel; waardevermindering door verdergaand gebruik kan door de Partner op de terugbetaling in mindering worden gebracht. Outletconditie en in de listing vermelde gebreken maken deel uit van wat je mocht verwachten en zijn geen zelfstandige retourgrond.</p>

      <h2>7. Verhouding tot problemen vóór afronding</h2>
      <p>Is je order nog niet afgerond (nog geen vrijgegeven uitbetaling), gebruik dan "Probleem melden" op de orderpagina: dat bevriest de uitbetaling. Deze Retourvoorwaarden zien op de fase ná afronding.</p>
    </article>
  );
}
