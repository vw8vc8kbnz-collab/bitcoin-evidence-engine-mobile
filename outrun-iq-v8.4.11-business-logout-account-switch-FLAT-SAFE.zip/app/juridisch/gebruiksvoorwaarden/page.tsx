export const metadata = { title: "Gebruiksvoorwaarden — Outrun IQ" };

export default function Gebruiksvoorwaarden() {
  return (
    <article>
      <h1 className="h1big">Gebruiksvoorwaarden Outrun IQ</h1>
      <p className="lmeta">Versie 1.0 · juli 2026 · voor consumenten ("je/jij")</p>

      <h2>1. Wat Outrun IQ is</h2>
      <p>Outrun IQ is een marktplaats waarop geverifieerde bedrijven (Partners) outletproducten aanbieden: overstock, showroommodellen, retouren en eindseries. Koop je iets, dan sluit je de koopovereenkomst met de Partner — die is jouw verkoper en verantwoordelijk voor het product, de levering en de wettelijke garanties. Outrun IQ bemiddelt, verzorgt het betaalproces (escrow) en toont bij elke listing een eerlijk prijsbewijs.</p>

      <h2>2. Je account</h2>
      <p>Je maakt een account met een geldig e-mailadres en houdt je inloggegevens geheim; activiteiten via jouw account gelden als door jou verricht. Je bent minimaal 18 jaar of hebt toestemming van een wettelijk vertegenwoordiger. Bij misbruik, fraude of schending van deze voorwaarden kan je account worden geschorst of beëindigd.</p>

      <h2>3. Kopen, betalen en escrow</h2>
      <p>Bij een bestelling betaal je aan Outrun IQ; wij houden het bedrag vast en betalen de Partner pas uit nadat jij de ontvangst hebt bevestigd of nadat een redelijke termijn zonder gemeld probleem is verstreken. Meld een probleem daarom altijd vóór je bevestigt. Let op: in de huidige testfase zijn betalingen gesimuleerd — er wordt niets afgeschreven en "bestellingen" dienen uitsluitend om het platform te testen.</p>

      <h2>4. Herroeping en garantie</h2>
      <p>Als consument heb je bij aankoop op afstand in beginsel 14 dagen bedenktijd en recht op een product dat aan de overeenkomst beantwoordt (wettelijke garantie). Deze rechten oefen je uit richting de Partner als verkoper; de conditie en eventueel vermelde gebreken in de listing maken deel uit van wat je mocht verwachten. Outrun IQ kan bemiddelen via de geschilprocedure in de app.</p>

      <h2>5. Eerlijk gebruik</h2>
      <p>Je gebruikt het platform niet voor onrechtmatige doeleinden, plaatst geen misleidende of inbreukmakende content, probeert geen beveiligingen te omzeilen en benadert Partners niet buiten het platform om met het doel afspraken buiten Outrun IQ om te sluiten. Geautomatiseerd scrapen of overbelasten van het platform is niet toegestaan.</p>

      <h2>6. AI-functies</h2>
      <p>Functies zoals de AI Vinder en het AI-prijsbewijs zijn hulpmiddelen. Uitkomsten zijn indicatief en kunnen onjuistheden bevatten; controleer belangrijke informatie altijd in de listing zelf. Aan AI-uitkomsten kun je geen rechten ontlenen.</p>

      <h2>7. Aansprakelijkheid</h2>
      <p>Outrun IQ is niet de verkoper en niet aansprakelijk voor tekortkomingen van Partners. Voor het overige is onze aansprakelijkheid, behoudens opzet of bewuste roekeloosheid en onverminderd dwingend consumentenrecht, beperkt tot directe schade tot maximaal het bedrag van de betreffende bestelling.</p>

      <h2>8. Overig</h2>
      <p>Wij kunnen deze voorwaarden wijzigen; bij wezenlijke wijzigingen informeren we je vooraf. Op deze voorwaarden is Nederlands recht van toepassing. Vragen of klachten: via het notificatie-/supportkanaal in de app. Zie ook onze Privacyverklaring en Cookieverklaring.</p>
    </article>
  );
}
