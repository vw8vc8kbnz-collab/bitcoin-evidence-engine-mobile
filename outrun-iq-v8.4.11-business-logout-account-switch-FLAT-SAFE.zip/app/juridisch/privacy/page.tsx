export const metadata = { title: "Privacyverklaring — Outrun IQ" };

export default function Privacy() {
  return (
    <article>
      <h1 className="h1big">Privacyverklaring Outrun IQ</h1>
      <p className="lmeta">Versie 1.0 · juli 2026 · verwerkingsverantwoordelijke: Outrun IQ (vestigings- en contactgegevens worden vóór commerciële livegang hier vermeld)</p>

      <h2>Welke gegevens we verwerken</h2>
      <p>Accountgegevens (naam, e-mailadres, versleuteld wachtwoord), bij zakelijke accounts bedrijfsgegevens (bedrijfsnaam, KvK-nummer, plaats), transactiegegevens (bestellingen, biedingen, uitbetalingen), door jou geplaatste content (listings, productfoto's, berichten), gebruiksgegevens die nodig zijn voor de werking (sessies, meldingen, bewaarde items) en technische logs (zoals IP-adres en tijdstip) voor beveiliging en foutopsporing.</p>

      <h2>Waarvoor en op welke grondslag</h2>
      <p>Wij verwerken gegevens voor het leveren van de marktplaats en het uitvoeren van de overeenkomst met jou (uitvoering overeenkomst), voor verificatie van Partners, fraudepreventie en beveiliging (gerechtvaardigd belang), en voor het voldoen aan wettelijke plichten zoals administratie- en bewaarplichten (wettelijke verplichting). Wij verkopen geen persoonsgegevens en gebruiken geen gegevens voor advertentiedoeleinden van derden.</p>

      <h2>AI-verwerking — belangrijk om te weten</h2>
      <p>Voor het prijsadvies en de zoekfunctie sturen wij productgegevens (zoals titel, merk, conditie en nieuwprijs) naar onze AI-dienstverlener DeepSeek. Voor fotoherkenning sturen wij de door de Partner geüploade productfoto naar OpenAI. Upload daarom geen foto's waarop personen of privégegevens herkenbaar zijn; productfoto's horen uitsluitend het product te tonen. Wij sturen nooit je naam, e-mailadres of accountgegevens mee naar AI-dienstverleners. Met deze dienstverleners gelden verwerkings-/API-voorwaarden van de betreffende aanbieder; bij doorgifte buiten de EER steunen wij op door de aanbieder geboden passende waarborgen. Waar mogelijk kiezen wij voor EU-gehoste alternatieven.</p>

      <h2>Ontvangers en opslag</h2>
      <p>Gegevens worden opgeslagen op onze eigen server binnen de EU. Verwerkers zijn onze hostingprovider en de hierboven genoemde AI-dienstverleners; met toekomstige betaaldienstverleners (bij activering van echte betalingen) informeren we je vooraf via een bijgewerkte versie van deze verklaring. Wij delen gegevens met Partners voor zover nodig voor de uitvoering van jouw bestelling (zoals ordergegevens en leverafspraken).</p>

      <h2>Bewaartermijnen</h2>
      <p>Accountgegevens bewaren we zolang je account bestaat en tot maximaal 12 maanden daarna; transactiegegevens conform de fiscale bewaarplicht (7 jaar); technische logs kort en doelgebonden; verificatiecodes maximaal 15 minuten. In de testfase kunnen testdata tussentijds worden gewist.</p>

      <h2>Beveiliging</h2>
      <p>Wachtwoorden worden uitsluitend versleuteld opgeslagen (scrypt met salt), sessies via beveiligde httpOnly-cookies, en toegang tot de partneromgeving en het beheer is rolgebonden. Meld kwetsbaarheden verantwoord via het contactkanaal.</p>

      <h2>Jouw rechten</h2>
      <p>Je hebt recht op inzage, rectificatie, verwijdering, beperking, overdraagbaarheid en bezwaar. Dien een verzoek in via het contactkanaal in de app; we reageren binnen de wettelijke termijn van één maand. Je kunt daarnaast een klacht indienen bij de Autoriteit Persoonsgegevens.</p>
    </article>
  );
}
