export const metadata = { title: "Partnervoorwaarden — Outrun IQ" };

export default function Partnervoorwaarden() {
  return (
    <article>
      <h1 className="h1big">Partnervoorwaarden Outrun IQ</h1>
      <p className="lmeta">Versie 1.0 · juli 2026 · van toepassing op ieder zakelijk account ("Partner")</p>

      <h2>Artikel 1 — Definities en het platform</h2>
      <p>Outrun IQ ("het Platform", gegevens exploitant en KvK-nummer worden vóór commerciële livegang op deze pagina vermeld) biedt een online marktplaats waarop geverifieerde ondernemingen ("Partners") outletgoederen — waaronder overstock, showroommodellen, retouren en eindseries — aanbieden aan consumenten ("Klanten"). Het Platform is uitsluitend bemiddelaar en faciliteert de totstandkoming van koopovereenkomsten; de koopovereenkomst komt tot stand tussen de Partner en de Klant. Het Platform is geen partij bij die overeenkomst en wordt op geen enkel moment eigenaar van de aangeboden goederen.</p>

      <h2>Artikel 2 — Toelating en verificatie</h2>
      <p>Deelname als Partner staat uitsluitend open voor in Nederland ingeschreven ondernemingen met een geldig KvK-nummer. De Partner staat ervoor in dat alle bij aanmelding en nadien verstrekte gegevens juist, actueel en volledig zijn. Het Platform verifieert aanvragen en behoudt zich het recht voor een aanvraag zonder opgave van redenen te weigeren, dan wel een toelating in te trekken bij gebleken onjuistheden, fraude, herhaalde klachten of schending van deze voorwaarden. Het partneraccount is bedrijfsgebonden en niet overdraagbaar.</p>

      <h2>Artikel 3 — Aanbod en informatieplicht</h2>
      <p>De Partner is volledig verantwoordelijk voor de juistheid en volledigheid van zijn listings, waaronder titel, merk, conditieomschrijving, conditiescore, zichtbare gebreken, voorraad, prijs en leveringsvoorwaarden. Gebreken worden altijd expliciet vermeld en waar mogelijk gefotografeerd; het bewust verhullen van gebreken geldt als ernstige schending. De Partner biedt uitsluitend goederen aan waarover hij beschikkingsbevoegd is en die vrij zijn van rechten van derden, en houdt zich aan alle toepasselijke wet- en regelgeving, waaronder productveiligheids- en etiketteringsvoorschriften.</p>

      <h2>Artikel 4 — AI-prijsadvies en prijsbewijs</h2>
      <p>Het Platform stelt geautomatiseerde hulpmiddelen beschikbaar, waaronder prijsadvies en fotoherkenning ("AI-functies"). Deze zijn ondersteunend en indicatief: de Partner bepaalt en verantwoordt zelf de uiteindelijke verkoopprijs en de inhoud van de listing. Aan AI-uitkomsten kunnen geen rechten worden ontleend. Het Platform toont bij listings een prijsbewijs (fast · outlet · nieuwprijs) op basis van door de Partner aangeleverde gegevens; de Partner staat in voor de juistheid van de aangeleverde nieuwprijs/adviesprijs.</p>

      <h2>Artikel 5 — Bestellingen, escrow en levering</h2>
      <p>Betalingen van Klanten lopen via het Platform (derdengelden-/escrowmodel): de Klant betaalt aan het Platform en het Platform betaalt de Partner uit nadat de Klant de levering heeft bevestigd, dan wel na het verstrijken van een redelijke bevestigingstermijn zonder gemeld gebrek. De Partner bevestigt bestellingen voortvarend, plant de levering of afhaalafspraak binnen een redelijke termijn en levert het product conform de listing. Zolang het Platform in testfase verkeert, zijn betalingen gesimuleerd en worden geen gelden verwerkt; zodra echte betalingen worden geactiveerd, worden Partners daarover vooraf geïnformeerd, inclusief de dan geldende betaal- en uitbetalingsvoorwaarden.</p>

      <h2>Artikel 6 — Vergoeding</h2>
      <p>Het Platform brengt de Partner een commissie van 10% (tien procent) over de itemprijs per geslaagde transactie in rekening, verrekend bij uitbetaling. In de pilotfase gelden geen abonnements- of plaatsingskosten. Wijzigingen in de vergoedingsstructuur worden ten minste 30 dagen vooraf aangekondigd; voortgezet gebruik na ingangsdatum geldt als aanvaarding.</p>

      <h2>Artikel 7 — Consumentenrechten</h2>
      <p>De Partner verkoopt als handelaar aan consumenten en is gehouden aan het Nederlandse en Europese consumentenrecht, waaronder de wettelijke conformiteitseis (art. 7:17 BW), het herroepingsrecht bij verkoop op afstand (voor zover van toepassing, met inachtneming van de wettelijke uitzonderingen), en correcte informatievoorziening over prijzen en eigenschappen. Kortingen worden uitsluitend afgezet tegen een reële, door de Partner te onderbouwen referentieprijs. De afhandeling van herroepingen, garantie- en conformiteitsclaims is de verantwoordelijkheid van de Partner; het Platform kan hierin faciliteren via zijn dispute-proces.</p>

      <h2>Artikel 8 — Communicatie en omzeiling</h2>
      <p>Communicatie over biedingen, bestellingen en leveringen verloopt via het Platform. Het is niet toegestaan Klanten actief buiten het Platform om te leiden om de commissie te ontwijken. Bij vastgestelde structurele omzeiling kan het Platform het partneraccount schorsen of beëindigen.</p>

      <h2>Artikel 9 — Beschikbaarheid en aansprakelijkheid</h2>
      <p>Het Platform spant zich in voor een goede beschikbaarheid, maar garandeert geen ononderbroken of foutloze werking; onderhoud en storingen kunnen tot tijdelijke onbereikbaarheid leiden. Behoudens opzet of bewuste roekeloosheid is de aansprakelijkheid van het Platform jegens de Partner beperkt tot directe schade en per gebeurtenis gemaximeerd op het bedrag aan commissie dat het Platform in de drie maanden voorafgaand aan de gebeurtenis van de Partner heeft ontvangen. Het Platform is nimmer aansprakelijk voor indirecte schade, gederfde winst of schade door onjuiste listinggegevens van de Partner. De Partner vrijwaart het Platform voor aanspraken van Klanten en derden die voortvloeien uit zijn aanbod of nakoming.</p>

      <h2>Artikel 10 — Gegevens en intellectuele eigendom</h2>
      <p>De Partner verleent het Platform een niet-exclusieve licentie om aangeleverde content (waaronder foto's en productteksten) te gebruiken voor de werking en promotie van het Platform. Voor de verwerking van persoonsgegevens geldt de Privacyverklaring; waar het Platform als verwerker optreedt voor klantgegevens van de Partner, geldt dit artikel samen met de Privacyverklaring als verwerkersafspraak in de zin van art. 28 AVG, totdat een afzonderlijke verwerkersovereenkomst wordt gesloten.</p>

      <h2>Artikel 11 — Duur, schorsing en beëindiging</h2>
      <p>De overeenkomst geldt voor onbepaalde tijd. De Partner kan op ieder moment opzeggen; lopende bestellingen worden eerst correct afgewikkeld. Het Platform kan het account schorsen of beëindigen bij schending van deze voorwaarden, fraude(vermoeden), aanhoudende klachten of wettelijke noodzaak. Bij beëindiging blijven bepalingen die naar hun aard doorwerken (waaronder artikelen 7, 9 en 10) van kracht.</p>

      <h2>Artikel 13 — Retouren en klantenservice</h2>
      <p>De Partner handelt herroepingen, retouren en garantieclaims zelf, rechtstreeks en voortvarend af. De Partner houdt actuele klantenservicegegevens (ten minste een e-mailadres) in het Platform geregistreerd; zonder deze gegevens kan niet worden gepubliceerd. De Partner reageert binnen 3 dagen inhoudelijk op een via het Platform ingediende retouraanvraag met concrete instructies, en betaalt na een rechtsgeldige herroeping terug binnen de wettelijke termijn. Bij het uitblijven van een tijdige reactie kan de Klant escaleren naar het Platform; het Platform kan in dat geval maatregelen treffen, waaronder het opschorten van toekomstige uitbetalingen totdat de retour correct is afgehandeld, schorsing of beëindiging van het partneraccount, en het doorbelasten van redelijke afhandelingskosten. Escalatie maakt het Platform geen partij bij de koopovereenkomst en vestigt geen betalingsverplichting van het Platform jegens de Klant; de nakomingsplicht blijft volledig bij de Partner. Het Platform is voorts bevoegd al hetgeen het van de Partner te vorderen heeft — waaronder aan Klanten verschuldigde terugbetalingen die het Platform bij wijze van coulance of uit escrow heeft voldaan, alsmede afhandelingskosten — te verrekenen met (toekomstige) uitbetalingen aan de Partner. Bij producten die non-conform zijn (defect, afwijkend van de listing of verkeerd geleverd) draagt en regelt de Partner het retourtransport; bij herroeping zonder gebrek draagt de Klant de kosten van terugzending conform de Retourvoorwaarden. Voor nieuwe Partners kan een langere escrow-vrijgavetermijn gelden dan voor Partners met bewezen trackrecord; het Platform stelt deze termijn vast en kan hem aanpassen op basis van onder meer retour- en klachtenhistorie. De separate Retourvoorwaarden maken integraal deel uit van deze Partnervoorwaarden.</p>

      <h2>Artikel 14 — Wijzigingen, recht en forum</h2>
      <p>Het Platform kan deze voorwaarden wijzigen; wezenlijke wijzigingen worden ten minste 30 dagen vooraf aangekondigd. Op deze voorwaarden is Nederlands recht van toepassing; geschillen worden voorgelegd aan de bevoegde rechter van de vestigingsplaats van het Platform, onverminderd dwingendrechtelijke bevoegdheidsregels.</p>
    </article>
  );
}
