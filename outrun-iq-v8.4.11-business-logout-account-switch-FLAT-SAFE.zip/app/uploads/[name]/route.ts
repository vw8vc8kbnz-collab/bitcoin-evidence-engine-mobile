import { NextResponse } from "next/server";
import { promises as fs } from "fs";
import path from "path";
import { UPLOAD_DIR, LEGACY_UPLOAD_DIR } from "@/lib/store";
export const runtime = "nodejs";

const MIME: Record<string, string> = {
  ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png",
  ".webp": "image/webp", ".heic": "image/heic",
};

export async function GET(_req: Request, ctx: { params: Promise<{ name: string }> }) {
  const { name } = await ctx.params;
  const safe = path.basename(name);                 // padtraversal onmogelijk
  const type = MIME[path.extname(safe).toLowerCase()];
  if (!type) return new NextResponse("Niet gevonden", { status: 404 });
  for (const dir of [UPLOAD_DIR, LEGACY_UPLOAD_DIR]) {
    try {
      const buf = await fs.readFile(path.join(dir, safe));
      return new NextResponse(new Uint8Array(buf), {
        headers: { "Content-Type": type, "Cache-Control": "public, max-age=31536000, immutable" },
      });
    } catch { /* volgende locatie */ }
  }
  return new NextResponse("Niet gevonden", { status: 404 });
}
