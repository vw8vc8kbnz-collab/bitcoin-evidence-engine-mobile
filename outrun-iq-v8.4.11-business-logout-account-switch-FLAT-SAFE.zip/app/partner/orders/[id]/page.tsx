import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { read } from "@/lib/store";
import { getUser, isApprovedPartner } from "@/lib/auth";
import { eur } from "@/lib/types";
import { ChatSection } from "@/components/ChatSection";

export const dynamic = "force-dynamic";

export default async function PartnerOrderDetail({ params }:{ params: Promise<{ id: string }> }) {
  const { id } = await params;
  const user = await getUser();
  if (!isApprovedPartner(user)) redirect("/word-partner");
  const db = await read();
  const o = db.orders.find(x => x.id === id && x.sellerSlug === user!.partnerSlug);
  if (!o) notFound();
  const slot = o.chosenSlotAt
    ? new Date(o.chosenSlotAt).toLocaleString("nl-NL", { weekday: "long", day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })
    : null;

  return (
    <main className="dpage">
      <header className="dhd">
        <Link href="/partner/orders" className="back" style={{ color: "#8B96A0" }}>
          <svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7" /></svg>Orders
        </Link>
        <span className="sp" /><span className="mini" style={{ color: "#5F6873" }}>{o.id}</span>
      </header>
      <h1 className="dh1">{o.itemTitle}{o.partnerRef ? ` · ${o.partnerRef}` : ""}</h1>
      <p className="note" style={{ color: "#8B96A0", margin: "4px 0 0" }}>
        {o.status.replaceAll("_", " ").toUpperCase()} · {eur(o.sellerNet)} netto ·{" "}
        {o.deliveryChoice === "bezorgen" && o.deliveryAddress
          ? `${o.deliveryAddress.name ?? ""} · ${o.deliveryAddress.street}, ${o.deliveryAddress.postcode} ${o.deliveryAddress.city}`
          : `AFHAAL · code ${o.pickupCode ?? "—"}`}
        {slot ? ` · moment: ${slot}` : ""}
      </p>
      <div className="dgroup" style={{ marginTop: 16, padding: 16, display: "block" }}>
        <div className="slabel" style={{ margin: "0 0 10px", color: "#5F6873" }}>CHAT MET DE KOPER</div>
        <ChatSection orderId={o.id} messages={o.messages ?? []} me="partner" dark />
      </div>
    </main>
  );
}
