import Link from "next/link";
import { NewListingFlow } from "@/components/NewListingFlow";

export default function Nieuw() {
  return (
    <main className="page narrow" style={{ paddingBottom: 170 }}>
      <header className="hd">
        <Link href="/partner" className="back" style={{ color: "#fff" }}>
          <svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7" /></svg>Stop
        </Link>
        <span className="sp" /><span className="mini" style={{ color: "#8B96A0" }}>NIEUW PRODUCT</span>
      </header>
      <h1 className="h1big">Nieuw product</h1>
      <NewListingFlow />
    </main>
  );
}
