import Link from "next/link";
import { read } from "@/lib/store";
import { getUser } from "@/lib/auth";
import { Empty } from "@/components/Empty";
import { StorefrontEditor } from "@/components/StorefrontEditor";
import { ReviewReply, Stars } from "@/components/Reviews";
import { getSellerReviews, ratingOf } from "@/lib/data";
import { AccountSwitchActions } from "@/components/AccountSwitchActions";

export const dynamic = "force-dynamic";

export default async function Storefront() {
  const db = await read();
  const user = await getUser();
  const s = db.sellers.find(x => x.slug === user?.partnerSlug);
  const reviews = user?.partnerSlug ? await getSellerReviews(user.partnerSlug) : [];
  const rating = ratingOf(reviews);
  const count = s ? db.listings.filter(l => l.sellerSlug === s.slug && l.status === "active").length : 0;
  const orders = s ? db.orders.filter(o => o.sellerSlug === s.slug).length : 0;
  return (
    <main className="page">
      <header className="hd">
        <Link href="/partner" className="back" style={{ color: "#fff" }}>
          <svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7" /></svg>Dash
        </Link>
        <span className="sp" /><span className="mini" style={{ color: "#8B96A0" }}>STOREFRONT</span>
      </header>
      <h1 className="h1big">Jouw outlet store</h1>
      {!s && <Empty title="Nog geen storefront" text="Je storefront wordt aangemaakt zodra je partneraccount is goedgekeurd." />}
      {s && (
        <>
          <div className="sfprev" style={s.banner
            ? { backgroundImage: `linear-gradient(rgba(9,20,22,.55), rgba(9,20,22,.78)), url(${s.banner})`, backgroundSize: "cover", backgroundPosition: "center" }
            : { background: "var(--petrol-deep)" }}>
            <span className="sh2" />
            <span className="in">
              <span className="av" style={{ overflow: "hidden", width: 46, height: 46, flex: "none", borderRadius: 12 }}>{s.logo
                ? /* eslint-disable-next-line @next/next/no-img-element */
                  <img src={s.logo} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                : s.name.slice(0, 2).toUpperCase()}</span>
              <span><b>{s.name} ✓</b><span>{s.city.toUpperCase()} · {count} LIVE · {orders} ORDERS{s.kvk ? ` · KVK ${s.kvk}` : ""}</span></span>
            </span>
          </div>
          <Link href={`/store/${s.slug}`} className="act" style={{ marginTop: 12 }}>
            <span className="n2">↗</span>
            <span><b>Bekijk je store als koper</b><span>/store/{s.slug}</span></span>
            <span className="go">OPEN →</span>
          </Link>
          {reviews.length > 0 && (
            <>
              <div className="dsec" style={{ marginTop: 18 }}><h2>Reviews</h2><span>★ {rating!.avg} · {rating!.count}</span></div>
              {reviews.slice(0, 8).map(r => (
                <div key={r.id} className="orow" style={{ flexWrap: "wrap", gap: 8, alignItems: "flex-start" }}>
                  <span style={{ flex: 1 }}>
                    <b><Stars n={r.rating} size={11} /> {r.buyerName}{r.text ? ` — "${r.text.slice(0, 90)}"` : ""}</b>
                    <span>{new Date(r.at).toLocaleDateString("nl-NL", { day: "numeric", month: "short" }).toUpperCase()}{r.reply ? ` · JOUW REACTIE: "${r.reply.text.slice(0, 60)}"` : ""}</span>
                  </span>
                  {!r.reply && <ReviewReply reviewId={r.id} />}
                </div>
              ))}
            </>
          )}
          <StorefrontEditor logo={s.logo} banner={s.banner} about={s.about} address={s.address} support={s.support} />
          <div className="dsec" style={{ marginTop: 18 }}><h2>Account</h2><span>SESSIE</span></div>
          <div className="group settingsGroup partnerSessionGroup">
            <div className="li" style={{ display: "block" }}>
              <b>Uitloggen of account wisselen<small>Gebruik dit om daarna als particulier of met een ander zakelijk account in te loggen.</small></b>
              <AccountSwitchActions variant="dark" />
            </div>
          </div>
          <p className="note">Je logo en "over jullie" verschijnen bij al je listings en op je storefront — dat bouwt vertrouwen. Het afhaaladres zien klanten pas ná een ophaal-bestelling.</p>
        </>
      )}
    </main>
  );
}
