import { redirect } from "next/navigation";
import { getUser, isApprovedPartner } from "@/lib/auth";
import { SellerDock, SellerSide } from "@/components/Dock";

export const dynamic = "force-dynamic";

export default async function PartnerLayout({ children }: { children: React.ReactNode }) {
  const user = await getUser();
  if (!user) redirect("/welkom?next=/partner");
  if (!isApprovedPartner(user)) redirect("/word-partner");
  return (
    <div className="app dark partnerApp">
      <SellerSide />
      <div className="smain">{children}</div>
      <SellerDock />
    </div>
  );
}
