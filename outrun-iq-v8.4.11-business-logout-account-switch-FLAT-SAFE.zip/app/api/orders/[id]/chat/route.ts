import { NextResponse, type NextRequest } from "next/server";
import { getUser } from "@/lib/auth";
import { addOrderMessage } from "@/lib/data";
export const runtime = "nodejs";

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const u = await getUser();
  if (!u) return NextResponse.json({ error: "Log in" }, { status: 401 });
  const { id } = await ctx.params;
  const b = await req.json().catch(() => ({}));
  const text = String(b.text ?? "").trim();
  if (text.length < 1) return NextResponse.json({ error: "Leeg bericht" }, { status: 400 });
  const out = await addOrderMessage(u.id, id, text);
  return "error" in out ? NextResponse.json(out, { status: 403 }) : NextResponse.json(out);
}
