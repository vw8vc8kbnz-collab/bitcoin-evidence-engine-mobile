import { NextResponse, type NextRequest } from "next/server";
import { getUser, isPersonalBuyer } from "@/lib/auth";
import { disputeOrder } from "@/lib/data";
export const runtime = "nodejs";

const CATS = ["Niet geleverd", "Beschadigd", "Wijkt af van listing", "Anders"];

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const u = await getUser();
  if (!u) return NextResponse.json({ error: "Log in" }, { status: 401 });
  if (!isPersonalBuyer(u)) return NextResponse.json({ error: "Alleen persoonlijke kopersaccounts" }, { status: 403 });
  const { id } = await ctx.params;
  const b = await req.json().catch(() => ({}));
  const category = CATS.includes(b.category) ? b.category : "";
  const text = String(b.text ?? "").trim().slice(0, 600);
  if (!category || text.length < 10) {
    return NextResponse.json({ error: "Kies een categorie en beschrijf het probleem (min. 10 tekens)" }, { status: 400 });
  }
  const out = await disputeOrder(id, u.id, category, text);
  return "error" in out ? NextResponse.json(out, { status: 403 }) : NextResponse.json(out);
}
