import { NextResponse, type NextRequest } from "next/server";
import { advanceOrder, getOrder } from "@/lib/data";
import { getUser, isPersonalBuyer } from "@/lib/auth";
export const runtime = "nodejs";

export async function POST(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const u = await getUser();
  const o = await getOrder(id);
  if (u && !isPersonalBuyer(u)) return NextResponse.json({ error: "Alleen persoonlijke kopersaccounts" }, { status: 403 });
  if (!u || !o || o.buyerId !== u.id) return NextResponse.json({ error: "Niet jouw order" }, { status: 403 });
  const out = await advanceOrder(id, "delivered_buyer_confirmed", "Klant bevestigde ontvangst.");
  if (out && "error" in out) return NextResponse.json(out, { status: 409 });
  return NextResponse.json({ ok: true });
}
