import { NextResponse, type NextRequest } from "next/server";
import { getUser, isPersonalBuyer } from "@/lib/auth";
import { requestReturn, escalateReturn } from "@/lib/data";
export const runtime = "nodejs";

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const u = await getUser();
  if (!u) return NextResponse.json({ error: "Log in" }, { status: 401 });
  if (!isPersonalBuyer(u)) return NextResponse.json({ error: "Alleen persoonlijke kopersaccounts" }, { status: 403 });
  const { id } = await ctx.params;
  const b = await req.json().catch(() => ({}));
  if (b.action === "escalate") {
    const out = await escalateReturn(id, u.id);
    return "error" in out ? NextResponse.json(out, { status: 400 }) : NextResponse.json(out);
  }
  const reason = String(b.reason ?? "").trim().slice(0, 600);
  if (reason.length < 10) return NextResponse.json({ error: "Beschrijf je retourreden (min. 10 tekens)" }, { status: 400 });
  const out = await requestReturn(id, u.id, reason);
  return "error" in out ? NextResponse.json(out, { status: 400 }) : NextResponse.json(out);
}
