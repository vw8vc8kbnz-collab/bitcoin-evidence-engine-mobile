import { NextResponse, type NextRequest } from "next/server";
import { mutate } from "@/lib/store";
import { getUser } from "@/lib/auth";
import type { FlowEvent } from "@/lib/types";
export const runtime = "nodejs";

const allowedTypes = new Set(["start", "stop", "route", "click", "submit", "error", "snapshot", "api", "visibility"]);
function maskSensitive(input?: unknown) {
  let s = String(input ?? "");
  s = s.replace(/([?&](?:pin|token|code|secret|key|session|auth|password)=)[^&#\s]+/gi, "$1•••");
  s = s.replace(/\b[A-Z0-9._%+-]+@([A-Z0-9.-]+\.[A-Z]{2,})\b/gi, "•••@$1");
  s = s.replace(/\b(?:sk|pk|rk|whsec|ntfy|ds)-[A-Za-z0-9_\-]{8,}\b/g, "•••KEY•••");
  s = s.replace(/\b\d{4}\s?[A-Z]{2}\b/gi, "••••••");
  s = s.replace(/\b(?:\d[ -]*?){13,19}\b/g, "••••CARD••••");
  return s;
}
const text = (v: unknown, max = 300) => maskSensitive(v).replace(/\s+/g, " ").trim().slice(0, max);
function cleanMeta(input: any) {
  if (!input || typeof input !== "object") return undefined;
  return Object.fromEntries(Object.entries(input).slice(0, 24).map(([k, v]) => [
    text(k, 40),
    typeof v === "string" ? text(v, 240) : (typeof v === "number" || typeof v === "boolean" || v == null ? v as any : text(String(v), 120))
  ]));
}
function clean(input: any, userId?: string, role?: any): FlowEvent | null {
  if (!input || typeof input !== "object") return null;
  const type = String(input.type || "");
  if (!allowedTypes.has(type)) return null;
  const sessionId = text(input.sessionId, 80);
  if (!sessionId) return null;
  const ev: FlowEvent = {
    id: text(input.id, 40) || Math.random().toString(36).slice(2, 10),
    sessionId,
    at: text(input.at, 40) || new Date().toISOString(),
    userId,
    role,
    path: text(input.path, 320) || "/",
    type: type as FlowEvent["type"],
    label: text(input.label, 260) || undefined,
    target: text(input.target, 320) || undefined,
    text: text(input.text, 320) || undefined,
    x: Number.isFinite(Number(input.x)) ? Math.round(Number(input.x)) : undefined,
    y: Number.isFinite(Number(input.y)) ? Math.round(Number(input.y)) : undefined,
    scrollY: Number.isFinite(Number(input.scrollY)) ? Math.round(Number(input.scrollY)) : undefined,
    viewport: input.viewport && typeof input.viewport === "object" ? { w: Math.round(Number(input.viewport.w) || 0), h: Math.round(Number(input.viewport.h) || 0), dpr: Number(input.viewport.dpr) || undefined } : undefined,
    ua: text(input.ua, 260) || undefined,
    html: typeof input.html === "string" ? maskSensitive(input.html).slice(0, 60000) : undefined,
    meta: cleanMeta(input.meta),
  };
  return ev;
}

export async function POST(req: NextRequest) {
  const me = await getUser();
  let body: any;
  try { body = await req.json(); } catch { return NextResponse.json({ ok: false }, { status: 400 }); }
  const ev = clean(body, me?.id, me?.role);
  if (!ev) return NextResponse.json({ ok: false }, { status: 400 });
  await mutate(db => {
    (db.flowEvents ??= []).push(ev);
    if (db.flowEvents.length > 20000) db.flowEvents = db.flowEvents.slice(-20000);
  });
  return NextResponse.json({ ok: true });
}
