import { NextResponse, type NextRequest } from "next/server";
export const runtime = "nodejs";

/** Stripe-webhook-skelet (M4). Nu: logt en bevestigt, verwerkt niets.
 *  Bij activering: signatuur verifiëren met STRIPE_WEBHOOK_SECRET
 *  (stripe.webhooks.constructEvent) en events mappen:
 *  checkout.session.completed → order paid · charge.refunded → order-notitie. */
export async function POST(req: NextRequest) {
  if (!process.env.STRIPE_WEBHOOK_SECRET) {
    return NextResponse.json({ error: "Stripe niet geconfigureerd" }, { status: 501 });
  }
  const body = await req.text();
  console.log("[stripe] webhook ontvangen (nog niet verwerkt):", body.slice(0, 120));
  return NextResponse.json({ received: true });
}
