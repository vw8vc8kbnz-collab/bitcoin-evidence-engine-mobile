import { NextResponse, type NextRequest } from "next/server";
import { mutate } from "@/lib/store";
import { hashPassword, rateLimit } from "@/lib/auth";
export const runtime = "nodejs";

/** Wachtwoord-reset stap 2: code + nieuw wachtwoord → alle sessies vervallen. */
export async function POST(req: NextRequest) {
  const b = await req.json().catch(() => ({}));
  const e = String(b.email ?? "").trim().toLowerCase();
  const code = String(b.code ?? "").trim();
  const pass = String(b.password ?? "");
  if (pass.length < 8) return NextResponse.json({ error: "Wachtwoord: minimaal 8 tekens" }, { status: 400 });
  if (!rateLimit(`resetv:${e}`, 6, 10 * 60_000)) {
    return NextResponse.json({ error: "Te veel pogingen" }, { status: 429 });
  }
  const out = await mutate(db => {
    const c = db.codes.find(x => x.email === e && new Date(x.expiresAt) > new Date());
    if (!c || c.tries >= 5) return { error: "Code verlopen — vraag een nieuwe aan" };
    c.tries++;
    if (c.code !== code) return { error: "Code onjuist" };
    const u = db.users.find(x => x.email === e);
    if (!u) return { error: "Account niet gevonden" };
    const { salt, passHash } = hashPassword(pass);
    u.salt = salt; u.passHash = passHash;
    db.codes = db.codes.filter(x => x.email !== e);
    db.sessions = db.sessions.filter(x => x.userId !== u.id);   // overal uitgelogd
    return { ok: true };
  });
  return "error" in out ? NextResponse.json(out, { status: 400 }) : NextResponse.json(out);
}
