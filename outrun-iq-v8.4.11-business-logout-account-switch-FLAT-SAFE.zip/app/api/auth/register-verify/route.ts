import { NextResponse, type NextRequest } from "next/server";
import { mutate } from "@/lib/store";
import { hashPassword, createSession, SESSION_COOKIE, rateLimit } from "@/lib/auth";
import type { User } from "@/lib/types";
export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  const b = await req.json().catch(() => ({}));
  const e = String(b.email ?? "").trim().toLowerCase();
  const code = String(b.code ?? "").trim();
  const name = String(b.name ?? "").trim().slice(0, 60);
  const pass = String(b.password ?? "");
  const zakelijk = b.accountType === "zakelijk";
  const companyName = String(b.companyName ?? "").trim().slice(0, 80);
  const kvk = String(b.kvk ?? "").replace(/\D/g, "");
  const city = String(b.city ?? "").trim().slice(0, 40);
  if (!e || !code || name.length < 2 || pass.length < 8) {
    return NextResponse.json({ error: "Naam (min. 2) en wachtwoord (min. 8 tekens) verplicht" }, { status: 400 });
  }
  if (zakelijk && b.termsAccepted !== true) {
    return NextResponse.json({ error: "Akkoord met de Partnervoorwaarden is verplicht" }, { status: 400 });
  }
  if (zakelijk && (companyName.length < 2 || kvk.length !== 8 || city.length < 2)) {
    return NextResponse.json({ error: "Bedrijfsnaam, KvK-nummer (8 cijfers) en plaats zijn verplicht voor een zakelijk account" }, { status: 400 });
  }
  if (!rateLimit(`verify:${e}`, 8, 10 * 60_000)) {
    return NextResponse.json({ error: "Te veel pogingen" }, { status: 429 });
  }
  const out = await mutate(db => {
    const c = db.codes.find(x => x.email === e);
    if (!c || new Date(c.expiresAt) < new Date()) return { error: "Code verlopen — vraag een nieuwe aan" };
    c.tries++;
    if (c.tries > 6) return { error: "Te veel foute codes — vraag een nieuwe aan" };
    if (c.code !== code) return { error: "Onjuiste code" };
    if (db.users.some(u => u.email === e)) return { error: "Account bestaat al" };
    const { salt, passHash } = hashPassword(pass);
    const user: User = {
      id: Math.random().toString(36).slice(2, 10) + Date.now().toString(36),
      email: e, name, salt, passHash, role: zakelijk ? "partner" : "consument",
      partnerProfile: zakelijk ? { companyName, kvk, city, status: "pending", termsAcceptedAt: new Date().toISOString(), appliedAt: new Date().toISOString() } : undefined,
      createdAt: new Date().toISOString(),
    };
    db.users.push(user);
    db.codes = db.codes.filter(x => x.email !== e);
    return { user };
  });
  if ("error" in out) return NextResponse.json(out, { status: 400 });
  const { token, expires } = await createSession(out.user.id);
  const res = NextResponse.json({ ok: true, role: out.user.role, name: out.user.name, partnerPending: out.user.partnerProfile?.status === "pending" });
  res.cookies.set(SESSION_COOKIE, token, { httpOnly: true, sameSite: "lax", path: "/", expires });
  return res;
}
