import { NextResponse, type NextRequest } from "next/server";
import { mutate, read } from "@/lib/store";
import { rateLimit } from "@/lib/auth";
import { sendMail } from "@/lib/mail";
export const runtime = "nodejs";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

/** Wachtwoord-reset stap 1. Antwoordt altijd ok (geen account-enumeratie). */
export async function POST(req: NextRequest) {
  const { email } = await req.json().catch(() => ({}));
  const e = String(email ?? "").trim().toLowerCase();
  if (!EMAIL_RE.test(e)) return NextResponse.json({ error: "Ongeldig e-mailadres" }, { status: 400 });
  if (!rateLimit(`reset:${e}`, 4, 10 * 60_000)) {
    return NextResponse.json({ error: "Te veel pogingen. Probeer het over 10 minuten opnieuw." }, { status: 429 });
  }
  const db = await read();
  if (db.users.some(u => u.email === e)) {
    const code = String(Math.floor(100000 + Math.random() * 900000));
    await mutate(d => {
      d.codes = d.codes.filter(c => c.email !== e && new Date(c.expiresAt) > new Date());
      d.codes.push({ email: e, code, expiresAt: new Date(Date.now() + 15 * 60_000).toISOString(), tries: 0 });
    });
    await sendMail(e, "Wachtwoord herstellen — Outrun IQ", `Herstelcode: ${code} (15 minuten geldig)`);
  }
  return NextResponse.json({ ok: true });
}
