import { NextResponse } from "next/server";
import { getActiveListings } from "@/lib/data";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const listings = await getActiveListings();
  return NextResponse.json({ listings });
}
