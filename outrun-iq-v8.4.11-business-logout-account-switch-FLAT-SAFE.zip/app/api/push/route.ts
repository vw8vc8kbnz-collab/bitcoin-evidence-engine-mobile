import { NextResponse, type NextRequest } from "next/server";
import { getUser } from "@/lib/auth";
import { mutate } from "@/lib/store";
import { pushEnabled } from "@/lib/push";
export const runtime = "nodejs";

export async function GET() {
  return NextResponse.json({ enabled: pushEnabled(), key: process.env.VAPID_PUBLIC_KEY ?? null });
}

export async function POST(req: NextRequest) {
  const u = await getUser();
  if (!u) return NextResponse.json({ error: "Log in" }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  const sub = b.subscription;
  const endpoint = String(sub?.endpoint ?? "");
  const p256dh = String(sub?.keys?.p256dh ?? "");
  const auth = String(sub?.keys?.auth ?? "");
  if (!endpoint.startsWith("https://") || !p256dh || !auth) {
    return NextResponse.json({ error: "Ongeldige subscription" }, { status: 400 });
  }
  await mutate(db => {
    db.pushSubs = db.pushSubs.filter(x => x.endpoint !== endpoint);
    db.pushSubs.push({ userId: u.id, endpoint, keys: { p256dh, auth }, at: new Date().toISOString() });
    if (db.pushSubs.filter(x => x.userId === u.id).length > 5) {
      const mine = db.pushSubs.filter(x => x.userId === u.id).sort((a, z) => a.at.localeCompare(z.at));
      db.pushSubs = db.pushSubs.filter(x => x !== mine[0]);   // max 5 apparaten
    }
  });
  return NextResponse.json({ ok: true });
}

export async function DELETE(req: NextRequest) {
  const u = await getUser();
  if (!u) return NextResponse.json({ error: "Log in" }, { status: 401 });
  const b = await req.json().catch(() => ({}));
  const endpoint = String(b.endpoint ?? "");
  await mutate(db => {
    db.pushSubs = db.pushSubs.filter(x => !(x.userId === u.id && (endpoint ? x.endpoint === endpoint : true)));
  });
  return NextResponse.json({ ok: true });
}
