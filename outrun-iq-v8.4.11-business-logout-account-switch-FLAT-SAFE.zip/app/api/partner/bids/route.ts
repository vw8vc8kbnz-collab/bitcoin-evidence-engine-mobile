import { NextResponse, type NextRequest } from "next/server";
import { getUser, isApprovedPartner } from "@/lib/auth";
import { respondBid } from "@/lib/data";
export const runtime = "nodejs";

export async function PATCH(req: NextRequest) {
  const u = await getUser();
  if (!isApprovedPartner(u) || !u?.partnerSlug) {
    return NextResponse.json({ error: "Alleen voor goedgekeurde partners" }, { status: 403 });
  }
  const b = await req.json().catch(() => ({}));
  const action = ["accept", "reject", "counter"].includes(b.action) ? b.action : null;
  if (!action) return NextResponse.json({ error: "Onbekende actie" }, { status: 400 });
  const out = await respondBid(u.partnerSlug, String(b.bidId), action, b.counterAmount ? Math.round(Number(b.counterAmount)) : undefined);
  return "error" in out ? NextResponse.json(out, { status: 400 }) : NextResponse.json(out);
}
