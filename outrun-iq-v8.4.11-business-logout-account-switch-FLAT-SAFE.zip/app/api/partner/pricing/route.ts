import { NextResponse, type NextRequest } from "next/server";
import { getUser, isApprovedPartner } from "@/lib/auth";
import { getPriceAdvice } from "@/lib/ai";
export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  const __u = await getUser();
  if (!isApprovedPartner(__u)) return NextResponse.json({ error: "Alleen voor goedgekeurde partners" }, { status: 403 });
  const b = await req.json().catch(() => null);
  if (!b?.title || !b?.newPrice || !b?.category) {
    return NextResponse.json({ error: "title, category en newPrice zijn verplicht" }, { status: 400 });
  }
  const advice = await getPriceAdvice({
    title: String(b.title), brand: b.brand ? String(b.brand) : undefined,
    category: String(b.category), condition: String(b.condition ?? ""),
    conditionScore: Number(b.conditionScore) || 7,
    newPrice: Number(b.newPrice), stock: Number(b.stock) || 1,
    photosCount: Number(b.photosCount) || 0,
    defect: b.defect ? String(b.defect) : undefined,
  });
  return NextResponse.json(advice);
}
