import { NextResponse } from "next/server";
import { getUser, isApprovedPartner } from "@/lib/auth";
import { financeSafetyMode, getFinanceSnapshot, getPaymentProviderStatus } from "@/lib/payments";
import { getPartnerWallet } from "@/lib/data";

export const runtime = "nodejs";

export async function GET() {
  const user = await getUser();
  if (!isApprovedPartner(user) || !user?.partnerSlug) return NextResponse.json({ error: "Alleen partners" }, { status: 403 });
  const [finance, wallet] = await Promise.all([getFinanceSnapshot(user.partnerSlug), getPartnerWallet(user.partnerSlug)]);
  return NextResponse.json({ finance, provider: getPaymentProviderStatus(), safety: financeSafetyMode(), ledger: wallet.ledger });
}
