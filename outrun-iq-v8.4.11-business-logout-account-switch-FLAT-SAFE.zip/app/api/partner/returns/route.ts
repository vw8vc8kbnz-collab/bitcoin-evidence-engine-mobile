import { NextResponse, type NextRequest } from "next/server";
import { getUser, isApprovedPartner } from "@/lib/auth";
import { respondReturn, completeReturn } from "@/lib/data";
export const runtime = "nodejs";

export async function PATCH(req: NextRequest) {
  const u = await getUser();
  if (!isApprovedPartner(u) || !u?.partnerSlug) {
    return NextResponse.json({ error: "Alleen voor goedgekeurde partners" }, { status: 403 });
  }
  const b = await req.json().catch(() => ({}));
  const id = String(b.orderId ?? "");
  if (b.action === "respond") {
    const instructions = String(b.instructions ?? "").trim().slice(0, 600);
    if (instructions.length < 10) return NextResponse.json({ error: "Geef duidelijke retourinstructies (min. 10 tekens)" }, { status: 400 });
    const out = await respondReturn(id, u.partnerSlug, instructions);
    return "error" in out ? NextResponse.json(out, { status: 400 }) : NextResponse.json(out);
  }
  if (b.action === "complete") {
    const out = await completeReturn(id, u.partnerSlug);
    return "error" in out ? NextResponse.json(out, { status: 400 }) : NextResponse.json(out);
  }
  return NextResponse.json({ error: "Onbekende actie" }, { status: 400 });
}
