import { NextResponse, type NextRequest } from "next/server";
import { getUser, isApprovedPartner } from "@/lib/auth";
import { replyReview } from "@/lib/data";
export const runtime = "nodejs";

export async function PATCH(req: NextRequest) {
  const u = await getUser();
  if (!isApprovedPartner(u) || !u?.partnerSlug) {
    return NextResponse.json({ error: "Alleen voor goedgekeurde partners" }, { status: 403 });
  }
  const b = await req.json().catch(() => ({}));
  const text = String(b.text ?? "").trim();
  if (text.length < 5) return NextResponse.json({ error: "Reactie: minimaal 5 tekens" }, { status: 400 });
  const out = await replyReview(String(b.reviewId), u.partnerSlug, text);
  return "error" in out ? NextResponse.json(out, { status: 400 }) : NextResponse.json(out);
}
