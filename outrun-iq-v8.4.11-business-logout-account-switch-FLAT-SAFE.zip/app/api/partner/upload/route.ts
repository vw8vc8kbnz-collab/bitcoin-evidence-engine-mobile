import { NextResponse, type NextRequest } from "next/server";
import { getUser, isApprovedPartner } from "@/lib/auth";
import { promises as fs } from "fs";
import path from "path";
import { UPLOAD_DIR } from "@/lib/store";
export const runtime = "nodejs";

const OK_TYPES: Record<string, string> = {
  "image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp", "image/heic": ".heic",
};
const MAX = 8 * 1024 * 1024;

export async function POST(req: NextRequest) {
  const __u = await getUser();
  if (!isApprovedPartner(__u)) return NextResponse.json({ error: "Alleen voor goedgekeurde partners" }, { status: 403 });
  const form = await req.formData();
  const files = form.getAll("photos").filter((f): f is File => f instanceof File);
  if (!files.length) return NextResponse.json({ error: "Geen bestanden" }, { status: 400 });
  await fs.mkdir(UPLOAD_DIR, { recursive: true });
  const urls: string[] = [];
  for (const f of files.slice(0, 8)) {
    const ext = OK_TYPES[f.type];
    if (!ext) return NextResponse.json({ error: `Bestandstype ${f.type} niet toegestaan` }, { status: 415 });
    if (f.size > MAX) return NextResponse.json({ error: "Foto groter dan 8MB" }, { status: 413 });
    const name = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}${ext}`;
    await fs.writeFile(path.join(UPLOAD_DIR, name), Buffer.from(await f.arrayBuffer()));
    urls.push(`/uploads/${name}`);
  }
  return NextResponse.json({ urls });
}
