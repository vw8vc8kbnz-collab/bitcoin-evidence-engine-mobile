import { NextResponse, type NextRequest } from "next/server";
import { getUser, isApprovedPartner } from "@/lib/auth";
import { mutate } from "@/lib/store";
export const runtime = "nodejs";

export async function PATCH(req: NextRequest) {
  const u = await getUser();
  if (!isApprovedPartner(u)) return NextResponse.json({ error: "Alleen voor goedgekeurde partners" }, { status: 403 });
  const b = await req.json().catch(() => ({}));
  const out = await mutate(db => {
    const s = db.sellers.find(x => x.slug === u!.partnerSlug);
    if (!s) return { error: "Storefront niet gevonden" };
    if (typeof b.logoUrl === "string" && (b.logoUrl === "" || b.logoUrl.startsWith("/uploads/"))) s.logo = b.logoUrl || undefined;
    if (typeof b.bannerUrl === "string" && (b.bannerUrl === "" || b.bannerUrl.startsWith("/uploads/"))) s.banner = b.bannerUrl || undefined;
    if (typeof b.about === "string") s.about = b.about.trim().slice(0, 280) || undefined;
    if (b.support) {
      const email = String(b.support.email ?? "").trim().toLowerCase();
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) return { error: "Vul een geldig klantenservice-e-mailadres in" };
      s.support = {
        email,
        phone: String(b.support.phone ?? "").trim().slice(0, 20) || undefined,
        returnsInfo: String(b.support.returnsInfo ?? "").trim().slice(0, 280) || undefined,
      };
    }
    if (b.address) {
      const street = String(b.address.street ?? "").trim().slice(0, 80);
      const postcode = String(b.address.postcode ?? "").toUpperCase().replace(/\s+/g, " ").trim();
      const city = String(b.address.city ?? "").trim().slice(0, 40);
      if (street.length < 3 || !/^\d{4}\s?[A-Z]{2}$/.test(postcode) || city.length < 2) {
        return { error: "Vul een geldig afhaaladres in (straat + nr, postcode 1234 AB, plaats)" };
      }
      s.address = { street, postcode, city };
      s.city = city;
    }
    return { ok: true, logo: s.logo ?? null };
  });
  return "error" in out ? NextResponse.json(out, { status: 400 }) : NextResponse.json(out);
}
