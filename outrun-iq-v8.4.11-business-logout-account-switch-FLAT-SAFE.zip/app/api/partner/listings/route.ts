import { NextResponse, type NextRequest } from "next/server";
import { getUser, isApprovedPartner } from "@/lib/auth";
import { createListing, getSeller } from "@/lib/data";
import { FALLBACK_BY_CATEGORY, type Listing } from "@/lib/types";
export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  const u = await getUser();
  if (!isApprovedPartner(u) || !u?.partnerSlug || !u.partnerProfile) {
    return NextResponse.json({ error: "Alleen voor goedgekeurde partners" }, { status: 403 });
  }
  const b = await req.json().catch(() => null);
  for (const k of ["title", "category", "newPrice", "price"]) {
    if (!b?.[k]) return NextResponse.json({ error: `${k} is verplicht` }, { status: 400 });
  }
  const seller0 = await getSeller(u.partnerSlug);
  if (!seller0?.support?.email) {
    return NextResponse.json({ error: "Vul eerst je klantenservicegegevens in (Storefront → klantenservice) — verplicht vóór publiceren" }, { status: 400 });
  }
  const cat = (["witgoed","meubels","keukens","tuin","overig"] as const).includes(b.category) ? b.category : "overig";
  const price = Math.round(Number(b.price));
  const newPrice = Math.round(Number(b.newPrice));
  if (!(price > 0 && newPrice > 0 && price < newPrice)) {
    return NextResponse.json({ error: "Prijs moet > 0 en lager dan nieuwprijs zijn" }, { status: 400 });
  }
  const listing = await createListing({
    sellerSlug: u.partnerSlug,
    title: String(b.title).slice(0, 90),
    brand: b.brand ? String(b.brand).slice(0, 40) : undefined,
    partnerRef: b.partnerRef ? String(b.partnerRef).slice(0, 40) : undefined,
    category: cat as Listing["category"],
    condition: String(b.condition ?? "").slice(0, 140),
    conditionScore: Math.min(10, Math.max(1, Number(b.conditionScore) || 7)),
    defect: b.defect ? String(b.defect).slice(0, 120) : undefined,
    photos: Array.isArray(b.photos) ? b.photos.filter((x: unknown) => typeof x === "string" && (x as string).startsWith("/uploads/")).slice(0, 8) : [],
    fallback: FALLBACK_BY_CATEGORY[cat as Listing["category"]],
    stock: Math.max(1, Math.round(Number(b.stock) || 1)),
    perUnit: Boolean(b.perUnit) && Number(b.stock) > 1,
    newPrice, price,
    fast: Math.round(Number(b.fast)) || Math.round(price * 0.87),
    premium: Math.round(Number(b.premium)) || Math.round(price * 1.09),
    expectedDays: Math.round(Number(b.expectedDays)) || 7,
    confidence: Math.min(100, Math.max(0, Math.round(Number(b.confidence)) || 0)),
    comps: Math.max(0, Math.round(Number(b.comps)) || 0),
    aiSource: b.aiSource === "deepseek" ? "deepseek" : "heuristiek",
    delivery: String(b.delivery ?? "Bezorging in overleg").slice(0, 60),
    deliveryPrice: Math.max(0, Math.round(Number(b.deliveryPrice) || 0)),
    pickupCity: u.partnerProfile.city,
  });
  return NextResponse.json({ id: listing.id });
}
