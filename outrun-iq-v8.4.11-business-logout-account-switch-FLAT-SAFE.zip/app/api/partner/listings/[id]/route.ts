import { NextResponse, type NextRequest } from "next/server";
import { getUser, isApprovedPartner } from "@/lib/auth";
import { mutate } from "@/lib/store";
export const runtime = "nodejs";

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const u = await getUser();
  if (!isApprovedPartner(u)) return NextResponse.json({ error: "Alleen voor goedgekeurde partners" }, { status: 403 });
  const { id } = await ctx.params;
  const b = await req.json().catch(() => ({}));
  const out = await mutate(db => {
    const l = db.listings.find(x => x.id === id);
    if (!l || l.sellerSlug !== u!.partnerSlug) return { error: "Niet jouw listing" };
    if (b.action === "pause" && l.status === "active") { l.status = "paused"; return { ok: true }; }
    if (b.action === "activate" && l.status === "paused") { l.status = l.stock > 0 ? "active" : "sold"; return { ok: true }; }
    if (b.action === "price") {
      const p = Math.round(Number(b.price));
      if (!(p > 0 && p < l.newPrice)) return { error: "Prijs moet > 0 en onder de nieuwprijs blijven" };
      (l.priceLog ??= []).push({ at: new Date().toISOString(), from: l.price, to: p });
      l.price = p;
      if (l.fast >= p) l.fast = Math.max(1, Math.round((p * 0.9) / 5) * 5);
      if (l.premium <= p) l.premium = Math.round((p * 1.08) / 5) * 5;
      return { ok: true };
    }
    return { error: "Onbekende actie" };
  });
  return "error" in out ? NextResponse.json(out, { status: 400 }) : NextResponse.json(out);
}

export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const u = await getUser();
  if (!isApprovedPartner(u)) return NextResponse.json({ error: "Alleen voor goedgekeurde partners" }, { status: 403 });
  const { id } = await ctx.params;
  const out = await mutate(db => {
    const i = db.listings.findIndex(x => x.id === id);
    if (i < 0 || db.listings[i].sellerSlug !== u!.partnerSlug) return { error: "Niet jouw listing" };
    db.listings.splice(i, 1);   // orders behouden hun titel-snapshot
    return { ok: true };
  });
  return "error" in out ? NextResponse.json(out, { status: 404 }) : NextResponse.json(out);
}
