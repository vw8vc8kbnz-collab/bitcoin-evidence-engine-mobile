import { NextResponse, type NextRequest } from "next/server";
import { promises as fs } from "fs";
import path from "path";
import { getUser, isApprovedPartner } from "@/lib/auth";
import { analyzeProductPhoto } from "@/lib/ai/vision";
import { UPLOAD_DIR, LEGACY_UPLOAD_DIR } from "@/lib/store";
export const runtime = "nodejs";

const MIME: Record<string, string> = { ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".webp": "image/webp", ".heic": "image/heic" };

export async function POST(req: NextRequest) {
  const u = await getUser();
  if (!isApprovedPartner(u)) return NextResponse.json({ error: "Alleen voor goedgekeurde partners" }, { status: 403 });
  const { photoUrl } = await req.json().catch(() => ({}));
  const name = path.basename(String(photoUrl ?? ""));       // padtraversal onmogelijk
  const ext = path.extname(name).toLowerCase();
  if (!String(photoUrl ?? "").startsWith("/uploads/") || !MIME[ext]) {
    return NextResponse.json({ error: "Ongeldige foto" }, { status: 400 });
  }
  let buf: Buffer | null = null;
  for (const dir of [UPLOAD_DIR, LEGACY_UPLOAD_DIR]) {
    try { buf = await fs.readFile(path.join(dir, name)); break; } catch { /* volgende */ }
  }
  if (!buf) return NextResponse.json({ error: "Foto niet gevonden" }, { status: 404 });
  const fields = await analyzeProductPhoto(`data:${MIME[ext]};base64,${buf.toString("base64")}`);
  if (!fields) {
    return NextResponse.json({ error: "AI-herkenning niet beschikbaar (provider ondersteunt mogelijk geen beelden — zie serverlog)" }, { status: 502 });
  }
  return NextResponse.json(fields);
}
