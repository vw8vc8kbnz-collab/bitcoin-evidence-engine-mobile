import { NextResponse, type NextRequest } from "next/server";
import { getUser, isApprovedPartner } from "@/lib/auth";
import { advanceOrder, getOrder } from "@/lib/data";
import type { OrderStatus } from "@/lib/types";
export const runtime = "nodejs";

const ALLOWED: OrderStatus[] = ["confirmed", "delivered"];

export async function PATCH(req: NextRequest) {
  const __u = await getUser();
  if (!isApprovedPartner(__u)) return NextResponse.json({ error: "Alleen voor goedgekeurde partners" }, { status: 403 });
  const b = await req.json().catch(() => null);
  if (!b?.id || !ALLOWED.includes(b.to)) {
    return NextResponse.json({ error: "id en geldige to-status verplicht" }, { status: 400 });
  }
  const own = await getOrder(String(b.id));
  if (!own || own.sellerSlug !== __u!.partnerSlug) return NextResponse.json({ error: "Niet jouw order" }, { status: 403 });
  if (own.returnRequest && own.returnRequest.status !== "completed") {
    return NextResponse.json({ error: "Order is bevroren door een open retouraanvraag" }, { status: 409 });
  }
  if (b.to === "confirmed" && own.status !== "paid") {
    return NextResponse.json({ error: "Bevestigen kan alleen direct na betaling" }, { status: 409 });
  }
  if (b.to === "delivered" && own.status !== "delivery_planned") {
    return NextResponse.json({ error: "Geleverd melden kan pas na geplande levering" }, { status: 409 });
  }
  const out = await advanceOrder(String(b.id), b.to, b.note ? String(b.note).slice(0, 120) : undefined);
  if (out && "error" in out) return NextResponse.json(out, { status: 409 });
  return NextResponse.json({ ok: true });
}
