import { NextResponse, type NextRequest } from "next/server";
import { getUser } from "@/lib/auth";
import { buyerBidAction } from "@/lib/data";
export const runtime = "nodejs";

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const u = await getUser();
  if (!u) return NextResponse.json({ error: "Log in" }, { status: 401 });
  const { id } = await ctx.params;
  const b = await req.json().catch(() => ({}));
  const out = await buyerBidAction(u.id, id, b.action === "withdraw" ? "withdraw" : "accept-counter");
  return "error" in out ? NextResponse.json(out, { status: 400 }) : NextResponse.json(out);
}
