import { NextResponse, type NextRequest } from "next/server";
import { getUser, isPersonalBuyer } from "@/lib/auth";
import { placeBid } from "@/lib/data";
export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  const u = await getUser();
  if (!u) return NextResponse.json({ error: "Log in om te bieden" }, { status: 401 });
  if (!isPersonalBuyer(u)) return NextResponse.json({ error: "Alleen persoonlijke kopersaccounts" }, { status: 403 });
  const b = await req.json().catch(() => ({}));
  const out = await placeBid(u.id, String(b.listingId), Math.round(Number(b.amount)), b.message ? String(b.message) : undefined);
  return "error" in out ? NextResponse.json(out, { status: 400 }) : NextResponse.json(out);
}
