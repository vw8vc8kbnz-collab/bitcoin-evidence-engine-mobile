import { NextResponse } from "next/server";
import { getUser } from "@/lib/auth";
import { getNotifications, markNotificationsRead, unreadCount } from "@/lib/data";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const u = await getUser();
  if (!u) return NextResponse.json({ error: "Log in" }, { status: 401 });
  return NextResponse.json({ notifications: await getNotifications(u.id), unread: await unreadCount(u.id) });
}

export async function POST() {
  const u = await getUser();
  if (!u) return NextResponse.json({ error: "Log in" }, { status: 401 });
  await markNotificationsRead(u.id);
  return NextResponse.json({ ok: true });
}
