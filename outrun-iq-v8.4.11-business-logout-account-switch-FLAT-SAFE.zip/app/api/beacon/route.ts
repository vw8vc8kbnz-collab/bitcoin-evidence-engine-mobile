import { NextResponse, type NextRequest } from "next/server";
import { recordVisit } from "@/lib/traffic";
export const runtime = "nodejs";

/** Anonieme bezoekmeting (geen tracking van derden; alleen een random id-cookie). */
export async function POST(req: NextRequest) {
  let vid = req.cookies.get("oiq_v")?.value;
  const fresh = !vid;
  if (!vid) vid = Math.random().toString(36).slice(2, 14);
  recordVisit(vid);
  const res = NextResponse.json({ ok: true });
  if (fresh) res.cookies.set("oiq_v", vid, { maxAge: 400 * 86400, sameSite: "lax", path: "/", httpOnly: true });
  return res;
}
