import { NextResponse } from "next/server";
import { getUser, isAdmin } from "@/lib/auth";
import { aiProviderMatrix } from "@/lib/ai/brain";
export const runtime = "nodejs";
export async function GET() {
  const u = await getUser();
  if (!isAdmin(u)) return NextResponse.json({ error: "Admin vereist" }, { status: 403 });
  return NextResponse.json({
    mode: process.env.AI_ROUTER_MODE || "hybrid",
    openai: { available: !!process.env.OPENAI_API_KEY, model: process.env.OPENAI_MODEL || "gpt-4o-mini" },
    deepseek: { available: !!process.env.DEEPSEEK_API_KEY, model: process.env.DEEPSEEK_MODEL || "deepseek-chat" },
    matrix: aiProviderMatrix(),
  });
}
