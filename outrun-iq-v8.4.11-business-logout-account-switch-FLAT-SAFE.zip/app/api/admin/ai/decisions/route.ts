import { NextResponse } from "next/server";
import { getUser, isAdmin } from "@/lib/auth";
import { read } from "@/lib/store";
export const runtime = "nodejs";
export async function GET() {
  const u = await getUser();
  if (!isAdmin(u)) return NextResponse.json({ error: "Admin vereist" }, { status: 403 });
  const db = await read();
  return NextResponse.json({ decisions: [...(db.aiDecisions ?? [])].sort((a,b)=>b.at.localeCompare(a.at)).slice(0, 250) });
}
