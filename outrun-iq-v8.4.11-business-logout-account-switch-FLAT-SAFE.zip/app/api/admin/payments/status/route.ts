import { NextResponse } from "next/server";
import { getUser, isAdmin } from "@/lib/auth";
import { paymentAdminStatus } from "@/lib/payments";

export const runtime = "nodejs";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const user = await getUser();
  const pin = url.searchParams.get("pin") || "";
  const pinOk = Boolean(process.env.ADMIN_PIN && pin === process.env.ADMIN_PIN);
  if (!pinOk && !isAdmin(user)) {
    return NextResponse.json({ error: "Alleen beheer" }, { status: 403 });
  }
  return NextResponse.json(await paymentAdminStatus());
}
