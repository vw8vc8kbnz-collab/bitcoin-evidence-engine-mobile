import { NextResponse, type NextRequest } from "next/server";
import { resolveDispute } from "@/lib/data";
export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  const b = await req.json().catch(() => ({}));
  if (!process.env.ADMIN_PIN || b.pin !== process.env.ADMIN_PIN) {
    return NextResponse.json({ error: "Geen toegang" }, { status: 401 });
  }
  const out = await resolveDispute(String(b.orderId), b.action === "cancel" ? "cancel" : "release");
  return "error" in out ? NextResponse.json(out, { status: 404 }) : NextResponse.json(out);
}
