import Link from "next/link";
import { Mark } from "@/components/icons";

export default function NotFound() {
  return (
    <div className="app">
      <main className="page narrow" style={{ textAlign: "center", paddingTop: 90 }}>
        <span style={{ opacity: .5, display: "inline-block" }}><Mark size={44} /></span>
        <h1 className="h1big" style={{ marginTop: 16 }}>Niet gevonden</h1>
        <p className="note">Deze pagina of listing bestaat niet (meer). Mogelijk is het product verkocht of verwijderd.</p>
        <Link href="/" className="btn pri" style={{ display: "inline-block", marginTop: 18, padding: "13px 26px" }}>Naar de shop</Link>
      </main>
    </div>
  );
}
