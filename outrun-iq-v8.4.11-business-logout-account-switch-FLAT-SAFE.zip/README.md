# Outrun IQ v8.4.11

Flat SAFE deployment build.

Deze versie voegt zakelijke uitlog- en accountwissel-functionaliteit toe. Partners kunnen nu vanuit de Partner Hub veilig uitloggen en daarna als particulier of met een ander zakelijk account inloggen.

## Routes
- Buyer: `/`
- AI Vinder: `/vinder`
- Account particulier: `/account`
- Partner Hub: `/partner`
- Partner account/sessie: `/partner/account`
- Partner wallet: `/partner/geld`
- Admin: `/beheer`

## Deployment
Gebruik de meegeleverde Termius update-regel. De ZIP is flat en bevat `package.json` in de root.
