import type { CapacitorConfig } from "@capacitor/cli";

/** Fase 2 (App Store / Play Store): native schil om de live web-app.
 *  De schil laadt outruniq.nl en voegt native waarde toe (push, camera, haptics)
 *  — zie docs/CAPACITOR.md voor het volledige draaiboek. */
const config: CapacitorConfig = {
  appId: "nl.outruniq.app",
  appName: "Outrun IQ",
  webDir: "public",              // dummy; we draaien remote (server.url)
  server: {
    url: "https://outruniq.nl",
    allowNavigation: ["outruniq.nl", "www.outruniq.nl"],
  },
  ios: { contentInset: "automatic" },
};

export default config;
