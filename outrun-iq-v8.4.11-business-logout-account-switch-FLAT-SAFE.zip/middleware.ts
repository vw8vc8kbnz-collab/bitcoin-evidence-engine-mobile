import { NextResponse, type NextRequest } from "next/server";

const PUBLIC = ["/welkom", "/api/auth/", "/juridisch", "/offline", "/api/beacon", "/manifest.webmanifest", "/sw.js", "/icons/"];
const NEEDS_AUTH_SOFT = ["/partner", "/api/partner", "/api/me", "/checkout", "/order", "/bewaard", "/account", "/vinder", "/api/vinder", "/meldingen", "/api/orders", "/word-partner", "/api/partner-aanvraag"];

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  if (PUBLIC.some(p => pathname === p || pathname.startsWith(p))) return NextResponse.next();
  if (pathname.startsWith("/beheer") || pathname.startsWith("/api/admin")) return NextResponse.next(); // eigen PIN-check

  const hasSession = !!req.cookies.get("oiq_sessie")?.value;
  const hard = (process.env.REQUIRE_AUTH ?? "hard") !== "soft";
  const needsAuth = hard || NEEDS_AUTH_SOFT.some(p => pathname.startsWith(p));

  if (needsAuth && !hasSession) {
    if (pathname.startsWith("/api/")) return NextResponse.json({ error: "Log in" }, { status: 401 });
    const url = req.nextUrl.clone();
    url.pathname = "/welkom";
    url.searchParams.set("next", pathname);
    return NextResponse.redirect(url);
  }
  return NextResponse.next();
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|uploads/|favicon.ico).*)"],
};
