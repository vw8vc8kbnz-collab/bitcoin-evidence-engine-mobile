# Outrun IQ v8.4.1 — Finance & Security Hardening

## Status
De Finance/Wallet-laag is bewust **provider-onafhankelijk** en blijft standaard in **Finance Preview** totdat:

- Stripe Connect volledig is geconfigureerd;
- Stripe live mode expliciet aan staat;
- `PAYMENT_LIVE_ENABLED=true` bewust in productie is gezet;
- ledger-integrity en provider-reconciliatie schoon zijn.

## Principes

1. AI mag adviseren, maar nooit geld verplaatsen.
2. Saldo wordt niet handmatig overschreven; alleen append-only ledgerregels zijn toegestaan.
3. Campagnes reserveren budget vooraf.
4. Ongebruikt campagnebudget komt alleen via ledger-refund terug.
5. Admin kan controleren/auditen, maar finance-correcties moeten later altijd als aparte correctietransactie worden geboekt.
6. Stripe is een adapter achter de Payment Engine, geen directe dependency in UI/businesslogica.

## Volgende productie-eisen

- Geen admin PIN in URL voor echte productie.
- Stripe webhook-reconciliatie voor betalingen, refunds, disputes en payouts.
- Database met echte transacties/row-locks vóór live geldstromen.
- Periodieke finance integrity check en alerting.
- 2FA/step-up auth voor uitbetalingen.
