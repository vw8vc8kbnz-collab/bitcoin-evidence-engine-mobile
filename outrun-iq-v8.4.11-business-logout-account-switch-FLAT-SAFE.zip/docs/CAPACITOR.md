# Outrun IQ — native apps via Capacitor (fase 2)

Doel: officiële iOS/Android-apps als schil om https://outruniq.nl, met native
meerwaarde (vereist door Apple-richtlijn 4.2): pushmeldingen, camera, haptics.

## Vereisten
- Apple Developer Program ($99/jaar) · Google Play Console ($25 eenmalig)
- iOS-builds: Mac met Xcode, of cloud-build via Codemagic
- Domein + TLS live (klaar) · mail-adapter live (klaar) · account-verwijderen (klaar, App Store-eis)

## Stappen (op een ontwikkelmachine, niet de VPS)
1. Repo clonen, dan: `npm i -D @capacitor/cli && npm i @capacitor/core @capacitor/ios @capacitor/android`
2. `npx cap add ios && npx cap add android`  (capacitor.config.ts staat al klaar)
3. `npx cap open ios` / `npx cap open android` → iconen/splash instellen
   (bron: public/icons/icon-512.png), bundle-id nl.outruniq.app.
4. Testen op toestel; de schil laadt de live site — elke webdeploy update de app dus direct.

## Push in de schil (native, naast de bestaande Web Push)
- Web Push (v6.9) dekt PWA/Android/iOS-PWA al af via dezelfde meldingen.
- In de Capacitor-app later: @capacitor/push-notifications (APNs/FCM) →
  registreer het native token via een extra veld op POST /api/push en breid
  lib/push.ts uit met een FCM-tak. De adapter-structuur is hierop voorbereid.

## Reviewrisico's (Apple)
- "Alleen een website" → afwijzing: zorg dat push + camera + haptics werken in de schil.
- Testaccount aanleveren in App Store Connect (reviewer moet kunnen inloggen).
- Betalingen: fysieke goederen → externe betaling (Stripe) is TOEGESTAAN (geen IAP-plicht).
