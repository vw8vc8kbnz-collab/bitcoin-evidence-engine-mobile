# Outrun Payment Engine v1

Outrun gebruikt vanaf v8.4 een provider-onafhankelijke betaalarchitectuur. Stripe Connect is de eerste echte provider, maar de app praat niet rechtstreeks met Stripe vanuit UI of business flows.

## Lagen

```text
Outrun UI / AI Brain / Marketplace
        ↓
Wallet Engine
        ↓
Payment Engine
        ↓
Provider Adapter
        ↓
Stripe Connect / later Mollie / Adyen / Mangopay
```

## Principes

- Stripe beheert het echte geld.
- Outrun toont Financiën/Wallet als productlaag bovenop providerdata.
- AI mag alleen adviseren, nooit geld verplaatsen.
- Campagnes gebruiken eerst wallet-reserveringen en geven ongebruikt budget terug via grootboekregels.
- De app gebruikt functies zoals `getFinanceSnapshot`, `createCheckoutIntent` en `requestProviderPayout`, niet direct `stripe.*`.
- Later kan een nieuwe provider als adapter worden toegevoegd zonder de gebruikerservaring opnieuw te bouwen.

## Providers

### Nu
- `test`: veilige testmodus zonder echt geld.
- `stripe`: Stripe Connect-ready adapter.

### Later
- `mollie` voor NL/EU-gebruiksvriendelijkheid.
- `adyen` voor enterprise/platform-schaal.
- `mangopay` voor marketplace/wallet/escrow-achtige flows.

## Security

- Geen directe saldo-mutaties.
- Geen geldacties door AI.
- Idempotency keys voor financiële acties.
- Ledger/hash-chain blijft de interne auditlaag.
- Provider-webhooks worden later per adapter gevalideerd en gemapt naar interne events.
