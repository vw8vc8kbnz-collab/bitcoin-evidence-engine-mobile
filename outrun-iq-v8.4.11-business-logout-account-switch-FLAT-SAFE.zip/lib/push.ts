/** Web Push-adapter (VAPID). Zelfde filosofie als mail/AI: zonder keys stilletjes
 *  uit, met keys echte pushmeldingen naar geïnstalleerde PWA's (iOS 16.4+ / Android).
 *  Env: VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY, VAPID_SUBJECT (mailto:…).
 *  Genereren: npx web-push generate-vapid-keys */
import type { PushSub } from "./types";
import { mutate } from "./store";

export function pushEnabled() {
  return !!(process.env.VAPID_PUBLIC_KEY && process.env.VAPID_PRIVATE_KEY);
}

/** Fire-and-forget: verstuurt naar alle subscriptions van een user; ruimt dode op. */
export function sendWebPush(subs: PushSub[], payload: { title: string; body: string; href: string }) {
  if (!pushEnabled() || subs.length === 0) return;
  void (async () => {
    try {
      const webpush = (await import("web-push")).default;
      webpush.setVapidDetails(
        process.env.VAPID_SUBJECT || "mailto:beheer@outruniq.nl",
        process.env.VAPID_PUBLIC_KEY!, process.env.VAPID_PRIVATE_KEY!,
      );
      const dead: string[] = [];
      await Promise.all(subs.map(s =>
        webpush.sendNotification(
          { endpoint: s.endpoint, keys: s.keys },
          JSON.stringify(payload),
          { TTL: 3600 },
        ).catch((e: { statusCode?: number }) => {
          if (e?.statusCode === 404 || e?.statusCode === 410) dead.push(s.endpoint);
          else console.error("[push] verzendfout:", e?.statusCode ?? e);
        }),
      ));
      if (dead.length > 0) {
        await mutate(db => { db.pushSubs = db.pushSubs.filter(x => !dead.includes(x.endpoint)); });
      }
    } catch (e) { console.error("[push] adapterfout:", e); }
  })();
}
