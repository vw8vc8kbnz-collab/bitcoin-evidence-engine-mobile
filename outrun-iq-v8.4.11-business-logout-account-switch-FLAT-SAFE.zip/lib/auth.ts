import { randomBytes, scryptSync, timingSafeEqual, createHash } from "node:crypto";
import { cookies } from "next/headers";
import { read, mutate } from "./store";
import type { User } from "./types";

const SESSION_DAYS = 30;
export const SESSION_COOKIE = "oiq_sessie";

export function hashPassword(pass: string): { salt: string; passHash: string } {
  const salt = randomBytes(16).toString("hex");
  const passHash = scryptSync(pass, salt, 64).toString("hex");
  return { salt, passHash };
}

export function verifyPassword(pass: string, salt: string, passHash: string): boolean {
  try {
    const test = scryptSync(pass, salt, 64);
    return timingSafeEqual(test, Buffer.from(passHash, "hex"));
  } catch { return false; }
}

const sha256 = (s: string) => createHash("sha256").update(s).digest("hex");

export async function createSession(userId: string): Promise<{ token: string; expires: Date }> {
  const token = randomBytes(32).toString("hex");
  const expires = new Date(Date.now() + SESSION_DAYS * 864e5);
  await mutate(db => {
    db.sessions = db.sessions.filter(s => new Date(s.expiresAt) > new Date()); // opschonen
    db.sessions.push({ tokenHash: sha256(token), userId, expiresAt: expires.toISOString() });
  });
  return { token, expires };
}

export async function destroySession(token: string) {
  const h = sha256(token);
  await mutate(db => { db.sessions = db.sessions.filter(s => s.tokenHash !== h); });
}

/**
 * Huidige gebruiker o.b.v. sessie-cookie; null indien uitgelogd/verlopen.
 *
 * Belangrijk voor gesloten werelden: oude pilotdata kan vervuilde flags bevatten
 * (bijv. admin + partnerProfile). Runtime-permissies volgen alleen `role`;
 * partner/admin/koper-flags worden hier effectief gescheiden zonder data te wissen.
 */
function effectiveUser(u: User): User {
  if (u.role === "admin") return { ...u, partnerProfile: undefined, partnerSlug: undefined };
  if (u.role === "consument") return { ...u, partnerProfile: undefined, partnerSlug: undefined };
  return u;
}

export async function getUser(): Promise<User | null> {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  const db = await read();
  const s = db.sessions.find(x => x.tokenHash === sha256(token));
  if (!s || new Date(s.expiresAt) < new Date()) return null;
  const u = db.users.find(u => u.id === s.userId);
  return u ? effectiveUser(u) : null;
}

export const isApprovedPartner = (u: User | null) =>
  !!u && u.role === "partner" && u.partnerProfile?.status === "approved" && !!u.partnerSlug;

export const isPendingPartner = (u: User | null) =>
  !!u && u.role === "partner" && u.partnerProfile?.status === "pending";

export const isAdmin = (u: User | null) => !!u && u.role === "admin";

/** Simpele in-memory rate-limiter (per proces): max n pogingen per venster. */
const buckets = new Map<string, { n: number; reset: number }>();
export function rateLimit(key: string, max: number, windowMs: number): boolean {
  const now = Date.now();
  const b = buckets.get(key);
  if (!b || b.reset < now) { buckets.set(key, { n: 1, reset: now + windowMs }); return true; }
  if (b.n >= max) return false;
  b.n++; return true;
}

export const isPersonalBuyer = (u: User | null) => !!u && u.role === "consument";
