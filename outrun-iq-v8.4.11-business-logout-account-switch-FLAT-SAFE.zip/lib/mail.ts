/** Mail-abstractie, zelfde patroon als de AI-laag: adapter is vervangbaar.
 *  Met RESEND_API_KEY gezet worden mails écht verstuurd (Resend); zonder key —
 *  of als verzenden faalt — valt hij terug op de serverlog zodat codes nooit
 *  verloren gaan in de testfase. Env: RESEND_API_KEY, MAIL_FROM. */
export async function sendMail(to: string, subject: string, body: string) {
  const key = process.env.RESEND_API_KEY;
  if (key) {
    try {
      const ctl = new AbortController();
      const t = setTimeout(() => ctl.abort(), 10_000);
      const res = await fetch("https://api.resend.com/emails", {
        method: "POST", signal: ctl.signal,
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
        body: JSON.stringify({
          from: process.env.MAIL_FROM || "Outrun IQ <onboarding@resend.dev>",
          to: [to], subject, text: body,
          html: `<div style="font-family:system-ui,sans-serif;max-width:480px;margin:0 auto;padding:24px">
            <p style="font-size:15px;font-weight:800;letter-spacing:.4px;color:#0E4B46">OUTRUN IQ</p>
            <p style="font-size:14px;line-height:1.6;color:#333">${body.replace(/</g, "&lt;")}</p>
            <p style="font-size:11px;color:#999">Vraag je dit niet zelf aan? Negeer deze mail.</p>
          </div>`,
        }),
      });
      clearTimeout(t);
      if (res.ok) return;
      console.error("[mail] Resend weigerde:", res.status, (await res.text()).slice(0, 200));
    } catch (e) {
      console.error("[mail] verzendfout:", e);
    }
  }
  console.log(`[mail] aan=${to} | ${subject} | ${body}`);
}
