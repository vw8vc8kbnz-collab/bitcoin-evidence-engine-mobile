/** Bezorg-abstractie (Brenger-voorbereiding). Zonder BRENGER_API_KEY is de
 *  modus "manual": partner stelt zelf momenten voor (SlotProposer) en regelt
 *  transport. Mét key wordt dit het inhaakpunt:
 *
 *  Integratiepad (na partnertraject bij Brenger, zie mega-overdracht DEEL 13):
 *  1. getQuote(order): POST naar Brenger business-API met afhaaladres
 *     (Seller.address) + bezorgadres (Order.deliveryAddress) + productmaat.
 *  2. bookDelivery(order, slot): boeking → Order.deliveryRef; statuswebhook
 *     → order "delivered" automatisch i.p.v. handmatig GELEVERD.
 */
export function deliveryMode(): "manual" | "brenger" {
  return process.env.BRENGER_API_KEY ? "brenger" : "manual";
}
