/** Vision-taakroute van de AI Model Abstraction Layer.
 *  Default: zelfde endpoint/key als DeepSeek (OpenAI-compatibel beeldformaat).
 *  Overschrijfbaar met VISION_BASE_URL / VISION_MODEL / VISION_API_KEY (bv. EU-hosted). */

export type VisionFields = {
  title: string;
  brand: string;
  category: "witgoed" | "meubels" | "keukens" | "tuin" | "overig";
  condition: string;
  conditionScore: number;     // 1-10
  defect: string;             // leeg = geen zichtbaar gebrek
  newPriceEstimate: number;   // geschatte adviesprijs in hele euro's, 0 = onbekend
  source: string;
};

const CATS = ["witgoed", "meubels", "keukens", "tuin", "overig"] as const;

function num(x: unknown): number {
  if (typeof x === "number" && isFinite(x)) return Math.round(x);
  if (typeof x === "string") {
    const v = parseFloat(x.replace(/[^\d,.-]/g, "").replace(/\.(?=\d{3}\b)/g, "").replace(",", "."));
    if (isFinite(v)) return Math.round(v);
  }
  return 0;
}

export async function analyzeProductPhoto(dataUrl: string): Promise<VisionFields | null> {
  const key = process.env.VISION_API_KEY || process.env.DEEPSEEK_API_KEY;
  if (!key) return null;
  const api = process.env.VISION_BASE_URL || process.env.DEEPSEEK_BASE_URL || "https://api.deepseek.com/chat/completions";
  const model = process.env.VISION_MODEL || process.env.DEEPSEEK_MODEL || "deepseek-chat";

  const sys = `Je bent de productherkenning van een Nederlandse outlet-marketplace. Je krijgt één productfoto. Antwoord UITSLUITEND met geldige JSON, exact deze sleutels:
{"title":"","brand":"","category":"","condition":"","conditionScore":0,"defect":"","newPriceEstimate":0}
Regels: "title" = korte Nederlandse producttitel incl. merk en type (max 70 tekens). "brand" = merknaam of "". "category" = precies één uit: witgoed, meubels, keukens, tuin, overig. "condition" = korte NL conditieomschrijving van wat je ZIET (bv. "Showroommodel · lichte gebruikssporen"). "conditionScore" 1-10 op basis van zichtbare staat (onzeker = 7). "defect" = zichtbaar gebrek of "". "newPriceEstimate" = realistische Nederlandse adviesprijs nieuw in hele euro's (onbekend = 0). Verzin geen typenummers die je niet kunt lezen.`;

  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), 25_000);
  try {
    const res = await fetch(api, {
      method: "POST",
      signal: ctl.signal,
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
      body: JSON.stringify({
        model,
        temperature: 0.1,
        response_format: { type: "json_object" },
        messages: [
          { role: "system", content: sys },
          { role: "user", content: [
            { type: "image_url", image_url: { url: dataUrl } },
            { type: "text", text: "Herken dit product en vul het JSON-schema in." },
          ] },
        ],
      }),
    });
    if (!res.ok) {
      console.error("[ai-vision] provider weigerde:", res.status, (await res.text().catch(() => "")).slice(0, 300));
      return null;
    }
    const data = await res.json();
    const raw = String(data?.choices?.[0]?.message?.content ?? "");
    const p = JSON.parse(raw.replace(/```json|```/g, "").trim());
    const cat = CATS.includes(p.category) ? p.category : "overig";
    const score = Math.min(10, Math.max(1, num(p.conditionScore) || 7));
    const out: VisionFields = {
      title: String(p.title ?? "").slice(0, 70).trim(),
      brand: String(p.brand ?? "").slice(0, 40).trim(),
      category: cat,
      condition: String(p.condition ?? "").slice(0, 140).trim(),
      conditionScore: score,
      defect: String(p.defect ?? "").slice(0, 120).trim(),
      newPriceEstimate: Math.max(0, num(p.newPriceEstimate)),
      source: String(data?.model ?? model),
    };
    return out.title ? out : null;
  } catch (e) {
    console.error("[ai-vision] fout:", e);
    return null;
  } finally { clearTimeout(t); }
}
