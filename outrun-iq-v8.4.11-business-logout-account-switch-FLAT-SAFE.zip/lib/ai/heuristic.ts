import type { PriceAdvice, PricingInput } from "./index";

/** Deterministische fallback zonder externe AI: anker = nieuwprijs, korting o.b.v. conditie. */
export function heuristicPricing(i: PricingInput): PriceAdvice {
  const cond = Math.min(10, Math.max(1, i.conditionScore));
  // conditie 10 → 78% van nieuw; conditie 5 → 55%; lineair
  const base = i.newPrice * (0.55 + (cond - 5) * 0.046);
  const outlet = Math.max(1, Math.round(base / 5) * 5);
  return {
    fast: Math.max(1, Math.round((outlet * 0.87) / 5) * 5),
    outlet,
    premium: Math.round((outlet * 1.09) / 5) * 5,
    expectedDaysFast: 3, expectedDaysOutlet: 7, expectedDaysPremium: 16,
    confidence: 35 + cond * 2,      // bewust laag: dit is géén marktscan
    comps: 0,
    reasoning: "Heuristische schatting op basis van nieuwprijs en conditie — geen live marktscan (AI offline of geen API-key).",
    source: "heuristiek",
  };
}
