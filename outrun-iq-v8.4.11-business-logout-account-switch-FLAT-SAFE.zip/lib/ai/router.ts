export type AiProvider = "openai" | "deepseek" | "rules";
export type AiTask =
  | "vinder"
  | "copy"
  | "partner_coach"
  | "deal_quality"
  | "ranking"
  | "home_builder"
  | "promotion"
  | "inventory";

export type AiJsonRequest = {
  task: AiTask;
  system: string;
  user: unknown;
  temperature?: number;
  timeoutMs?: number;
  provider?: AiProvider;
};

export type AiJsonResult<T> = {
  ok: boolean;
  provider: AiProvider | "fallback";
  model?: string;
  data?: T;
  raw?: string;
  error?: string;
};

const TASK_PROVIDER: Record<AiTask, AiProvider[]> = {
  // OpenAI = beste voor natuurlijke taal / UX / uitleg.
  vinder: ["openai", "deepseek"],
  copy: ["openai", "deepseek"],
  partner_coach: ["openai", "deepseek"],
  // DeepSeek = sterk voor gestructureerde JSON-analyse en ranking-achtige taken.
  deal_quality: ["deepseek", "openai"],
  ranking: ["deepseek", "openai"],
  home_builder: ["deepseek", "openai"],
  promotion: ["deepseek", "openai"],
  inventory: ["deepseek", "openai"],
};

function cfg(provider: AiProvider) {
  if (provider === "openai") return {
    key: process.env.OPENAI_API_KEY,
    api: process.env.OPENAI_BASE_URL || "https://api.openai.com/v1/chat/completions",
    model: process.env.OPENAI_MODEL || "gpt-4o-mini",
  };
  if (provider === "deepseek") return {
    key: process.env.DEEPSEEK_API_KEY,
    api: process.env.DEEPSEEK_BASE_URL || "https://api.deepseek.com/chat/completions",
    model: process.env.DEEPSEEK_MODEL || "deepseek-chat",
  };
  return { key: undefined, api: "", model: "rules" };
}

function orderFor(task: AiTask, forced?: AiProvider): AiProvider[] {
  if (forced) return [forced];
  const env = (process.env.AI_ROUTER_MODE || "hybrid").toLowerCase();
  if (env === "openai") return ["openai", "deepseek"];
  if (env === "deepseek") return ["deepseek", "openai"];
  if (env === "rules") return ["rules"];
  return TASK_PROVIDER[task];
}

export function providerPlan(task: AiTask) {
  return orderFor(task).map(p => {
    const c = cfg(p);
    return { provider: p, model: c.model, available: p === "rules" || !!c.key };
  });
}

export async function aiJson<T>(req: AiJsonRequest): Promise<AiJsonResult<T>> {
  for (const provider of orderFor(req.task, req.provider)) {
    if (provider === "rules") break;
    const c = cfg(provider);
    if (!c.key) continue;
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), req.timeoutMs ?? 18_000);
    try {
      const res = await fetch(c.api, {
        method: "POST",
        signal: ctl.signal,
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${c.key}` },
        body: JSON.stringify({
          model: c.model,
          temperature: req.temperature ?? 0.15,
          response_format: { type: "json_object" },
          messages: [
            { role: "system", content: req.system },
            { role: "user", content: typeof req.user === "string" ? req.user : JSON.stringify(req.user) },
          ],
        }),
      });
      if (!res.ok) throw new Error(`${provider} ${res.status}: ${(await res.text().catch(() => "")).slice(0, 220)}`);
      const json = await res.json();
      const raw = String(json?.choices?.[0]?.message?.content ?? "").replace(/```json|```/g, "").trim();
      return { ok: true, provider, model: String(json?.model ?? c.model), raw, data: JSON.parse(raw) as T };
    } catch (e) {
      console.error(`[ai-router] ${provider} faalde voor ${req.task}:`, e);
    } finally { clearTimeout(t); }
  }
  return { ok: false, provider: "fallback", error: `Geen AI-provider beschikbaar voor ${req.task}` };
}
