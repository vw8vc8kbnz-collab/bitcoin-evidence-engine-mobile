import { read, mutate } from "@/lib/store";
import type {
  AiDecision,
  Listing,
  PromotionCampaign,
  PromotionCreative,
  Seller,
  User,
} from "@/lib/types";
import { aiJson, providerPlan } from "./router";

const DAY = 864e5;
const clamp = (n: number, a = 0, b = 100) => Math.max(a, Math.min(b, n));
const discount = (l: Listing) =>
  l.newPrice > 0 ? clamp((1 - l.price / l.newPrice) * 100) : 0;
const ageDays = (iso: string) =>
  Math.max(0, (Date.now() - +new Date(iso)) / DAY);

function freshness(l: Listing) {
  return clamp(100 - ageDays(l.createdAt) * 8);
}
function stockPressure(l: Listing) {
  return l.stock <= 1 ? 100 : l.stock <= 3 ? 72 : l.stock <= 8 ? 38 : 15;
}
function sellerTrust(l: Listing, sellers: Seller[]) {
  return sellers.find((s) => s.slug === l.sellerSlug)?.trusted ? 94 : 68;
}

type UserSignalProfile = {
  categories: Map<string, number>;
  sellers: Map<string, number>;
  brands: Map<string, number>;
  avgPrice?: number;
  savedIds: Set<string>;
  orderIds: Set<string>;
};

function add(map: Map<string, number>, key: string | undefined, value: number) {
  if (!key) return;
  map.set(key, (map.get(key) ?? 0) + value);
}

function buildUserSignalProfile(
  user: User | null | undefined,
  db: Awaited<ReturnType<typeof read>>,
  listings: Listing[],
): UserSignalProfile {
  const savedIds = new Set<string>();
  const orderIds = new Set<string>();
  const categories = new Map<string, number>();
  const sellers = new Map<string, number>();
  const brands = new Map<string, number>();
  const prices: number[] = [];
  if (!user) return { categories, sellers, brands, savedIds, orderIds };

  for (const s of db.saved.filter((x) => x.userId === user.id)) {
    savedIds.add(s.listingId);
    const l =
      listings.find((x) => x.id === s.listingId) ??
      db.listings.find((x) => x.id === s.listingId);
    if (!l) continue;
    add(categories, l.category, 30);
    add(sellers, l.sellerSlug, 18);
    add(brands, l.brand, 14);
    prices.push(l.price);
  }
  for (const o of db.orders.filter((x) => x.buyerId === user.id)) {
    orderIds.add(o.listingId);
    const l =
      listings.find((x) => x.id === o.listingId) ??
      db.listings.find((x) => x.id === o.listingId);
    if (!l) continue;
    add(categories, l.category, 58);
    add(sellers, l.sellerSlug, 24);
    add(brands, l.brand, 20);
    prices.push(o.itemPrice || l.price);
  }
  const avgPrice = prices.length
    ? prices.reduce((a, b) => a + b, 0) / prices.length
    : undefined;
  return { categories, sellers, brands, avgPrice, savedIds, orderIds };
}

function topKeys(map: Map<string, number>, n = 4) {
  return [...map.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, n)
    .map(([key]) => key);
}

function personalMatchScore(l: Listing, profile: UserSignalProfile) {
  let s = 0;
  s += profile.categories.get(l.category) ?? 0;
  s += profile.sellers.get(l.sellerSlug) ?? 0;
  s += profile.brands.get(l.brand ?? "") ?? 0;
  if (profile.savedIds.has(l.id)) s += 12;
  if (profile.avgPrice) {
    const diff =
      Math.abs(l.price - profile.avgPrice) / Math.max(1, profile.avgPrice);
    s += clamp(22 - diff * 35, 0, 22);
  }
  return clamp(s, 0, 100);
}

function activeCampaigns(campaigns: PromotionCampaign[]) {
  const now = Date.now();
  return campaigns.filter(
    (c) =>
      c.status === "active" &&
      +new Date(c.startsAt) <= now &&
      (!c.endsAt || +new Date(c.endsAt) >= now) &&
      c.budgetDaily > 0,
  );
}

function campaignListingsFor(campaign: PromotionCampaign, listings: Listing[]) {
  return sellerListings(campaign.sellerSlug, listings, campaign);
}

function campaignRelevance(
  c: PromotionCampaign,
  listings: Listing[],
  sellers: Seller[],
  profile: UserSignalProfile,
) {
  const related = campaignListingsFor(c, listings);
  if (!related.length) return 0;
  const avgDeal =
    related.reduce((a, l) => a + dealQualityScore(l, sellers), 0) /
    related.length;
  const personal =
    related.reduce((a, l) => a + personalMatchScore(l, profile), 0) /
    related.length;
  const budget = clamp(c.budgetDaily * 4, 0, 100);
  const ctr =
    c.impressions > 20
      ? clamp((c.clicks / Math.max(1, c.impressions)) * 900, 0, 100)
      : 50;
  const fairness = clamp(
    100 - c.impressions / Math.max(1, c.budgetDaily * 70),
    8,
    100,
  );
  const freshnessBoost = ageDays(c.createdAt) < 2 ? 8 : 0;
  const score =
    personal * 0.32 +
    avgDeal * 0.23 +
    budget * 0.18 +
    fairness * 0.17 +
    ctr * 0.07 +
    freshnessBoost;
  return Math.round(clamp(score));
}

function selectCampaignCards(input: {
  campaigns: PromotionCampaign[];
  listings: Listing[];
  sellers: Seller[];
  profile: UserSignalProfile;
  max?: number;
  userId?: string;
}) {
  const active = activeCampaigns(input.campaigns);
  const scored = active
    .map((c) => ({
      c,
      score: campaignRelevance(c, input.listings, input.sellers, input.profile),
    }))
    .filter((x) => x.score > 18)
    .sort((a, b) => b.score - a.score);
  const out: DiscoveryCard[] = [];
  const usedSellers = new Set<string>();
  for (const x of scored) {
    if (
      usedSellers.has(x.c.sellerSlug) &&
      out.length < Math.min(3, scored.length)
    )
      continue;
    const card = campaignToCard(x.c, input.listings, input.sellers);
    if (!card) continue;
    card.reason = `Promote Rotation: relevantie ${x.score}/100 · budget €${x.c.budgetDaily}/dag · fairness voorkomt herhaling.`;
    out.push(card);
    usedSellers.add(x.c.sellerSlug);
    void logAiDecision({
      agent: "promotion",
      provider: "rules",
      userId: input.userId,
      context: "promote-rotation",
      subjectType: "campaign",
      subjectId: x.c.id,
      score: x.score,
      confidence: 82,
      reason: `Campagne geselecteerd via relevantie + budget + fairness.`,
      features: {
        budgetDaily: x.c.budgetDaily,
        impressions: x.c.impressions,
        clicks: x.c.clicks,
        sellerSlug: x.c.sellerSlug,
      },
    }).catch(() => undefined);
    if (out.length >= (input.max ?? 4)) break;
  }
  return out;
}

async function proposeHomeSections(input: {
  liveListings: number;
  aiPicks: number;
  campaigns: number;
  prefCats: string[];
}) {
  const res = await aiJson<{
    sections: string[];
    reason: string;
    confidence: number;
  }>({
    task: "home_builder",
    system: `Je bent Outrun Home Builder AI. Geef uitsluitend JSON {"sections":[...],"reason":"","confidence":0}. Kies 5-7 secties uit: discovery, deal_of_day, ai_picks, partner_spotlight, new, trending, last_chance, collections, ai_finder. Houd Home rustig, premium en niet advertentieachtig.`,
    user: input,
    temperature: 0.12,
    timeoutMs: 10_000,
  });
  if (res.ok && res.data?.sections?.length)
    return {
      provider: res.provider,
      sections: res.data.sections,
      reason: res.data.reason,
      confidence: clamp(Number(res.data.confidence) || 78),
    };
  return {
    provider: "rules" as const,
    sections: [
      "discovery",
      "deal_of_day",
      "ai_picks",
      "partner_spotlight",
      "new",
      "collections",
      "ai_finder",
    ],
    reason: "Rules fallback: rustige premium volgorde met beperkte promotie.",
    confidence: 76,
  };
}

export type DiscoveryCard = {
  id: string;
  kind: "campaign" | "collection" | "product" | "deal";
  title: string;
  subtitle: string;
  badge?: string;
  cta: string;
  href: string;
  style:
    "premium_dark" | "clean_light" | "product_grid" | "collection" | "urgent";
  image?: string;
  fallback?: Listing["fallback"];
  productImages?: { src?: string; fallback: Listing["fallback"] }[];
  price?: number;
  discount?: number;
  sellerName?: string;
  promoted?: boolean;
  reason?: string;
};

const creativeStyles: PromotionCreative["style"][] = [
  "premium_dark",
  "collection",
  "product_grid",
  "clean_light",
  "urgent",
];

function fallbackCreatives(input: {
  seller?: Seller;
  listings: Listing[];
  objective: PromotionCampaign["objective"];
  name: string;
}): PromotionCreative[] {
  const sellerName = input.seller?.name ?? "Outrun Partner";
  const cats = Array.from(new Set(input.listings.map((l) => l.category)))
    .slice(0, 2)
    .join(" & ");
  const bestDiscount = Math.max(
    0,
    ...input.listings.map((l) => Math.round((1 - l.price / l.newPrice) * 100)),
  );
  const count = input.listings.length;
  const base = [
    {
      title: input.name || `${sellerName} Outlet Selectie`,
      subtitle: `${count || "Nieuwe"} gecontroleerde deals${bestDiscount ? ` tot ${bestDiscount}% korting` : ""}.`,
      cta: "Bekijk collectie",
      style: "premium_dark" as const,
      badge: "Partner Spotlight",
      predictedCtr: 3.8,
      confidence: 76,
      reason: "Premium donkere campagnekaart met duidelijke partnerbelofte.",
    },
    {
      title: `${sellerName} vandaag uitgelicht`,
      subtitle: cats
        ? `Nieuwe voorraad in ${cats}.`
        : "Nieuwe outletvoorraad van een geverifieerde partner.",
      cta: "Naar store",
      style: "collection" as const,
      badge: "Outrun Promote",
      predictedCtr: 3.2,
      confidence: 72,
      reason: "Collectievariant focust op partner en aanbodbreedte.",
    },
    {
      title: input.listings[0]?.title
        ? `${input.listings[0].title}`
        : "Laatste stuks beschikbaar",
      subtitle: input.listings[0]
        ? `${sellerName} · ${input.listings[0].condition} · ${input.listings[0].pickupCity}`
        : "Schaarse voorraad die snel weg kan zijn.",
      cta: "Bekijk deal",
      style: "product_grid" as const,
      badge: "AI Selectie",
      predictedCtr: 4.1,
      confidence: 70,
      reason:
        "Productgerichte variant voor kopers die direct op dealniveau klikken.",
    },
    {
      title: `Nieuw binnen bij ${sellerName}`,
      subtitle: `${count || 1} deals uit gecontroleerde voorraad.`,
      cta: "Bekijk nieuw",
      style: "clean_light" as const,
      badge: "Nieuw",
      predictedCtr: 2.9,
      confidence: 68,
      reason: "Rustige variant voor minder advertentiegevoel.",
    },
    {
      title: bestDiscount
        ? `Tot ${bestDiscount}% goedkoper`
        : "Sneller verkopen",
      subtitle: `AI toont deze campagne alleen waar hij relevant is.`,
      cta: "Ontdek deals",
      style: "urgent" as const,
      badge: "Slimme boost",
      predictedCtr: 3.5,
      confidence: 74,
      reason: "Urgentievariant voor beperkte voorraad en korting.",
    },
  ];
  return base.map((x, i) => ({ id: `v${i + 1}`, ...x }));
}

export async function generatePromotionCreatives(input: {
  seller?: Seller;
  listings: Listing[];
  objective: PromotionCampaign["objective"];
  name: string;
  kind: PromotionCampaign["kind"];
}): Promise<{ variants: PromotionCreative[]; provider: string }> {
  const system = `Je bent Outrun Promote AI. Maak exact 5 premium campagnevarianten voor een subtiele homepage/discovery campagne. Geef uitsluitend JSON: {"variants":[{"title":"","subtitle":"","cta":"","style":"premium_dark|clean_light|product_grid|collection|urgent","badge":"","predictedCtr":0,"confidence":0,"reason":""}]}. Geen schreeuwerige advertenties, geen misleiding, geen claims zonder basis. Nederlands. Max titel 42 tekens, subtitle 90 tekens.`;
  const res = await aiJson<{ variants: Omit<PromotionCreative, "id">[] }>({
    task: "copy",
    provider: "openai",
    system,
    user: {
      partner: input.seller?.name,
      type: input.kind,
      campagneNaam: input.name,
      doel: input.objective,
      producten: input.listings
        .slice(0, 8)
        .map((l) => ({
          titel: l.title,
          categorie: l.category,
          prijs: l.price,
          nieuwprijs: l.newPrice,
          conditie: l.condition,
          voorraad: l.stock,
          plaats: l.pickupCity,
        })),
    },
    temperature: 0.45,
    timeoutMs: 14_000,
  });
  if (res.ok && res.data?.variants?.length) {
    const variants = res.data.variants.slice(0, 5).map((v, i) => ({
      id: `v${i + 1}`,
      title: String(v.title || input.name || "Outrun Promote").slice(0, 52),
      subtitle: String(v.subtitle || "Geselecteerd door Outrun AI.").slice(
        0,
        110,
      ),
      cta: String(v.cta || "Bekijk collectie").slice(0, 30),
      style: creativeStyles.includes(v.style as PromotionCreative["style"])
        ? (v.style as PromotionCreative["style"])
        : "premium_dark",
      badge: v.badge ? String(v.badge).slice(0, 28) : "Outrun Promote",
      predictedCtr: Math.max(1, Math.min(12, Number(v.predictedCtr) || 3.5)),
      confidence: Math.max(
        50,
        Math.min(96, Math.round(Number(v.confidence) || 74)),
      ),
      reason: String(
        v.reason || "AI-campagnevariant voor subtiele zichtbaarheid.",
      ).slice(0, 160),
    }));
    return { variants, provider: res.provider };
  }
  return { variants: fallbackCreatives(input), provider: "rules" };
}

function sellerListings(
  sellerSlug: string,
  listings: Listing[],
  campaign: PromotionCampaign,
) {
  if (campaign.kind === "listing") {
    const ids = new Set(
      (campaign.listingIds?.length
        ? campaign.listingIds
        : campaign.listingId
          ? [campaign.listingId]
          : []
      ).filter(Boolean),
    );
    return listings
      .filter((l) => ids.has(l.id) && l.sellerSlug === sellerSlug)
      .slice(0, 8);
  }
  if (campaign.kind === "category")
    return listings
      .filter(
        (l) => l.sellerSlug === sellerSlug && l.category === campaign.category,
      )
      .slice(0, 6);
  return listings.filter((l) => l.sellerSlug === sellerSlug).slice(0, 6);
}

function campaignToCard(
  c: PromotionCampaign,
  listings: Listing[],
  sellers: Seller[],
): DiscoveryCard | null {
  const seller = sellers.find((s) => s.slug === c.sellerSlug);
  const related = sellerListings(c.sellerSlug, listings, c);
  if (!seller || related.length === 0) return null;
  const variant =
    c.creativeVariants?.find((v) => v.id === c.selectedVariantId) ??
    c.creativeVariants?.[0] ??
    fallbackCreatives({
      seller,
      listings: related,
      objective: c.objective,
      name: c.name,
    })[0];
  const primary = related[0];
  const bestDiscount = Math.max(
    0,
    ...related.map((l) => Math.round((1 - l.price / l.newPrice) * 100)),
  );
  return {
    id: `campaign-${c.id}`,
    kind: "campaign",
    title: variant.title,
    subtitle: variant.subtitle,
    badge: variant.badge ?? "Partner Spotlight",
    cta: variant.cta || "Bekijk collectie",
    href:
      c.kind === "listing" && related.length === 1
        ? `/listing/${related[0].id}`
        : `/store/${seller.slug}`,
    style: variant.style,
    image: seller.banner || primary.photos[0],
    fallback: primary.fallback,
    productImages: related
      .slice(0, 4)
      .map((l) => ({ src: l.photos[0], fallback: l.fallback })),
    sellerName: seller.name,
    promoted: true,
    discount: bestDiscount,
    reason: variant.reason,
  };
}

export function dealQualityScore(l: Listing, sellers: Seller[]) {
  const d = discount(l);
  const score =
    d * 0.28 +
    clamp(l.confidence) * 0.22 +
    clamp(l.conditionScore * 10) * 0.18 +
    sellerTrust(l, sellers) * 0.14 +
    freshness(l) * 0.1 +
    stockPressure(l) * 0.08;
  return Math.round(clamp(score));
}

export function promotionBoost(l: Listing, campaigns: PromotionCampaign[]) {
  const now = Date.now();
  const active = campaigns.filter(
    (c) =>
      c.status === "active" &&
      +new Date(c.startsAt) <= now &&
      (!c.endsAt || +new Date(c.endsAt) >= now),
  );
  const hits = active.filter(
    (c) =>
      c.sellerSlug === l.sellerSlug &&
      (c.kind === "seller" ||
        (c.kind === "listing" &&
          (c.listingIds?.length
            ? c.listingIds
            : c.listingId
              ? [c.listingId]
              : []
          ).includes(l.id)) ||
        (c.kind === "category" && c.category === l.category)),
  );
  if (!hits.length) return { boost: 0, campaignIds: [] as string[] };
  // Promotie is een subtiele factor, nooit een garantie op plek 1.
  const budget = hits.reduce(
    (a, c) => a + Math.min(25, Math.max(0, c.budgetDaily)),
    0,
  );
  return {
    boost: Math.min(14, 5 + budget * 0.35),
    campaignIds: hits.map((h) => h.id),
  };
}

function preferenceScore(
  l: Listing,
  prefCats: Set<string>,
  savedIds: Set<string>,
) {
  let s = 0;
  if (prefCats.has(l.category)) s += 28;
  if (savedIds.has(l.id)) s += 10;
  if (l.stock <= 1) s += 5;
  return s;
}

function diversify(list: Listing[], maxPerSeller = 2) {
  const seen = new Map<string, number>();
  const out: Listing[] = [];
  for (const l of list) {
    const n = seen.get(l.sellerSlug) ?? 0;
    if (n >= maxPerSeller) continue;
    out.push(l);
    seen.set(l.sellerSlug, n + 1);
  }
  return out.length >= Math.min(4, list.length) ? out : list;
}

export async function logAiDecision(input: Omit<AiDecision, "id" | "at">) {
  return mutate((db) => {
    db.aiDecisions ??= [];
    db.aiDecisions.push({
      id: Math.random().toString(36).slice(2, 10),
      at: new Date().toISOString(),
      ...input,
    });
    if (db.aiDecisions.length > 3000)
      db.aiDecisions.splice(0, db.aiDecisions.length - 3000);
  });
}

export async function buildHomeBrain(user?: User | null) {
  const db = await read();
  const listings = db.listings.filter(
    (l) => l.status === "active" && l.stock > 0,
  );
  const sellers = db.sellers;
  const campaigns = db.promotionCampaigns ?? [];
  const profile = buildUserSignalProfile(user, db, listings);
  const prefCats = new Set(topKeys(profile.categories, 5));

  const ranked = listings
    .map((l) => {
      const dq = dealQualityScore(l, sellers);
      const promo = promotionBoost(l, campaigns);
      const personal = personalMatchScore(l, profile);
      const score =
        dq * 0.42 +
        personal * 0.28 +
        freshness(l) * 0.1 +
        stockPressure(l) * 0.08 +
        sellerTrust(l, sellers) * 0.05 +
        promo.boost +
        Math.random() * 1.5;
      return { l, score, dq, personal, promo };
    })
    .sort((a, b) => b.score - a.score);

  const aiPicks = diversify(
    ranked.map((x) => x.l),
    2,
  ).slice(0, 8);
  const hero = aiPicks.slice(0, 5);
  const newListings = [...listings]
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
    .slice(0, 10);
  const lastChance = ranked
    .filter((x) => x.l.stock <= 2)
    .map((x) => x.l)
    .slice(0, 8);
  const trending = [...ranked]
    .sort((a, b) => b.l.views + b.dq - (a.l.views + a.dq))
    .map((x) => x.l)
    .slice(0, 8);
  const dealOfDay = [...ranked].sort((a, b) => b.dq - a.dq)[0]?.l;
  const promoted = ranked.filter((x) => x.promo.boost > 0).slice(0, 6);
  const partnerSpotlight = promoted[0]?.l ?? null;
  const now = Date.now();
  const campaignCards = selectCampaignCards({
    campaigns,
    listings,
    sellers,
    profile,
    max: 4,
    userId: user?.id,
  });
  const collectionCards: DiscoveryCard[] = [
    {
      id: "collection-ai",
      kind: "collection",
      title: "Beste prijsbewijs",
      subtitle: "Deals met sterke korting én hoge AI-score.",
      badge: "AI Collectie",
      cta: "Bekijk collectie",
      href: "/zoeken?sort=score",
      style: "collection",
    },
    {
      id: "collection-under250",
      kind: "collection",
      title: "Onder €250",
      subtitle: "Lage instap, gecontroleerde voorraad.",
      badge: "Collectie",
      cta: "Bekijk deals",
      href: "/zoeken?max=250",
      style: "clean_light",
    },
    {
      id: "collection-last",
      kind: "collection",
      title: "Laatste stuks",
      subtitle: "Voorraad die snel weg kan zijn.",
      badge: "Schaarste",
      cta: "Bekijk laatste",
      href: "/zoeken?q=laatste",
      style: "urgent",
    },
  ];
  const sectionPlan = await proposeHomeSections({
    liveListings: listings.length,
    aiPicks: aiPicks.length,
    campaigns: campaignCards.length,
    prefCats: topKeys(profile.categories, 4),
  });
  const discoveryCards: DiscoveryCard[] = [
    ...campaignCards.slice(0, 1),
    ...hero
      .slice(0, 1)
      .map((l) => ({
        id: `hero-${l.id}`,
        kind: "product" as const,
        title: l.title,
        subtitle: `AI gekozen · Deal Score ${dealQualityScore(l, sellers)}/100 · ${l.pickupCity}`,
        badge: "Voor jou",
        cta: "Bekijk deal",
        href: `/listing/${l.id}`,
        style: "premium_dark" as const,
        image: l.photos[0],
        fallback: l.fallback,
        price: l.price,
        discount: Math.round((1 - l.price / l.newPrice) * 100),
        sellerName: sellers.find((s) => s.slug === l.sellerSlug)?.name,
      })),
    ...campaignCards.slice(1, 3),
    ...collectionCards.slice(0, 2),
  ].slice(0, 6);

  void logAiDecision({
    agent: "home_builder",
    provider: "hybrid",
    userId: user?.id,
    role: user?.role,
    context: "home-render",
    subjectType: "home",
    confidence: listings.length ? 86 : 40,
    reason: `Home samengesteld uit ${listings.length} live producten. ${sectionPlan.reason}`,
    features: {
      liveListings: listings.length,
      aiPicks: aiPicks.length,
      promoted: promoted.length,
      campaignCards: campaignCards.length,
      discoveryCards: discoveryCards.length,
      prefCats: prefCats.size,
      provider: sectionPlan.provider,
      sections: sectionPlan.sections.join(","),
    },
  }).catch(() => undefined);

  void logAiDecision({
    agent: "ranking",
    provider: "rules",
    userId: user?.id,
    role: user?.role,
    context: "home-ranking",
    subjectType: "home",
    confidence: 84,
    reason:
      "Ranking op persoonlijke match, dealkwaliteit, partnertrust, voorraadschaarste, versheid en subtiele promotieboost.",
    features: {
      topCategories: topKeys(profile.categories, 3).join(","),
      topSellers: topKeys(profile.sellers, 3).join(","),
      avgPrice: profile.avgPrice ? Math.round(profile.avgPrice) : undefined,
    },
  }).catch(() => undefined);

  return {
    hero,
    aiPicks,
    newListings,
    lastChance,
    trending,
    dealOfDay,
    partnerSpotlight,
    promoted: promoted.map((x) => x.l),
    discoveryCards,
    prefCats,
    sectionPlan,
  };
}



export type BuyerAiFeatures = {
  dealScore: number;
  trustScore: number;
  priceScore: number;
  urgencyScore: number;
  personalScore: number;
  promoteScore: number;
  finalScore: number;
  label: string;
  reason: string;
};

export function buyerAiFeatures(l: Listing, sellers: Seller[], campaigns: PromotionCampaign[] = [], user?: User | null, profile?: UserSignalProfile): BuyerAiFeatures {
  const localProfile = profile ?? { categories: new Map(), sellers: new Map(), brands: new Map(), savedIds: new Set<string>(), orderIds: new Set<string>() };
  const dealScore = dealQualityScore(l, sellers);
  const trustScore = sellerTrust(l, sellers);
  const priceScore = Math.round(clamp(discount(l) * 1.7 + clamp(l.confidence) * 0.35 + clamp(l.conditionScore * 10) * 0.18));
  const urgencyScore = Math.round(clamp(stockPressure(l) * 0.75 + freshness(l) * 0.25));
  const personalScore = Math.round(personalMatchScore(l, localProfile));
  const promo = promotionBoost(l, campaigns);
  const promoteScore = Math.round(clamp(promo.boost * 5, 0, 70));
  const finalScore = Math.round(clamp(
    dealScore * 0.38 +
    priceScore * 0.18 +
    trustScore * 0.14 +
    urgencyScore * 0.12 +
    personalScore * 0.13 +
    promoteScore * 0.05
  ));
  const label = finalScore >= 86 ? "Topmatch" : finalScore >= 76 ? "Sterke deal" : finalScore >= 66 ? "Interessant" : "Normaal";
  const seller = sellers.find(s => s.slug === l.sellerSlug);
  const bits = [
    `Deal Score ${dealScore}/100`,
    `${Math.round(discount(l))}% onder nieuwprijs`,
    seller?.trusted ? "geverifieerde trusted partner" : "geverifieerde partner",
    l.stock <= 2 ? "beperkte voorraad" : `${l.stock} op voorraad`,
  ];
  if (personalScore > 20) bits.push("past bij je eerdere interesse");
  if (promo.boost > 0) bits.push("subtiel gepromoot, maar relevantie blijft leidend");
  return { dealScore, trustScore, priceScore, urgencyScore, personalScore, promoteScore, finalScore, label, reason: bits.join(" · ") };
}

export async function rankListingsForBuyer(input: { user?: User | null; query?: string; maxPrice?: number; category?: Listing["category"]; sort?: string; limit?: number; }) {
  const db = await read();
  const sellers = db.sellers;
  const campaigns = db.promotionCampaigns ?? [];
  let listings = db.listings.filter(l => l.status === "active" && l.stock > 0);
  const q = String(input.query ?? "").trim().toLowerCase();
  if (input.category) listings = listings.filter(l => l.category === input.category);
  if (input.maxPrice) listings = listings.filter(l => l.price <= input.maxPrice!);
  if (q) {
    const words = [...new Set(q.split(/[^a-z0-9à-ÿ]+/).filter(w => w.length > 2))];
    listings = listings.filter(l => {
      const hay = `${l.title} ${l.brand ?? ""} ${l.category} ${l.condition} ${l.pickupCity}`.toLowerCase();
      return words.some(w => hay.includes(w));
    });
  }
  const profile = buildUserSignalProfile(input.user, db, listings);
  const ranked = listings.map(l => ({ listing: l, ai: buyerAiFeatures(l, sellers, campaigns, input.user, profile) }));
  if (input.sort === "prijs") ranked.sort((a,b)=>a.listing.price-b.listing.price);
  else if (input.sort === "korting") ranked.sort((a,b)=>discount(b.listing)-discount(a.listing));
  else if (input.sort === "nieuw") ranked.sort((a,b)=>b.listing.createdAt.localeCompare(a.listing.createdAt));
  else ranked.sort((a,b)=>b.ai.finalScore-a.ai.finalScore);
  return { ranked: ranked.slice(0, input.limit ?? 80), sellers, campaigns, profile };
}

export function explainListingAI(l: Listing, sellers: Seller[], campaigns: PromotionCampaign[] = [], user?: User | null) {
  const ai = buyerAiFeatures(l, sellers, campaigns, user);
  const betterPrice = Math.max(0, Math.round(l.newPrice - l.price));
  const alternativesHint = ai.finalScore >= 82 ? "Sterke match: prijs, trust en voorraad zitten tegelijk goed." : "Goede optie, maar vergelijk nog op prijs, conditie en levertijd.";
  return {
    ...ai,
    priceText: betterPrice ? `Prijsvoordeel: ongeveer €${betterPrice.toLocaleString("nl-NL")} onder nieuwprijs.` : "Prijsvoordeel is beperkt of niet duidelijk t.o.v. nieuwprijs.",
    trustText: ai.trustScore >= 90 ? "Partner is sterk geverifieerd en escrow blijft actief." : "Partner is gecontroleerd; escrow beschermt de betaling.",
    urgencyText: l.stock <= 1 ? "Laatste stuk: wacht niet te lang als dit precies past." : l.stock <= 3 ? "Beperkte voorraad: kans op snelle verkoop is hoger." : "Voorraad is nog ruim genoeg; minder haast.",
    alternativesHint,
  };
}

export function aiProviderMatrix() {
  return [
    "vinder",
    "copy",
    "partner_coach",
    "deal_quality",
    "ranking",
    "home_builder",
    "promotion",
    "inventory",
  ].map((task) => ({
    task,
    plan: providerPlan(task as Parameters<typeof providerPlan>[0]),
  }));
}

export async function promotionAdvice(input: {
  listing: Listing;
  seller: Seller | undefined;
}) {
  const system = `Je bent Outrun Promotion AI. Geef uitsluitend JSON: {"promote":true,"budgetDaily":0,"confidence":0,"reason":"","expectedViews":0,"objective":""}. Wees conservatief. Promotie mag nooit irritant zijn; alleen zinvol als product extra zichtbaarheid nodig heeft.`;
  const res = await aiJson<{
    promote: boolean;
    budgetDaily: number;
    confidence: number;
    reason: string;
    expectedViews: number;
    objective: string;
  }>({
    task: "promotion",
    system,
    user: {
      titel: input.listing.title,
      categorie: input.listing.category,
      prijs: input.listing.price,
      nieuwprijs: input.listing.newPrice,
      views: input.listing.views,
      voorraad: input.listing.stock,
      conditie: input.listing.conditionScore,
      partner: input.seller?.name,
    },
    temperature: 0.1,
    timeoutMs: 12_000,
  });
  if (res.ok && res.data) return { ...res.data, provider: res.provider };
  const dq = dealQualityScore(
    input.listing,
    input.seller ? [input.seller] : [],
  );
  const need = input.listing.views < 20 || input.listing.stock > 2 || dq < 74;
  const budgetDaily = dq > 82 ? 5 : dq > 68 ? 7 : 9;
  const expectedViews = Math.round(budgetDaily * 42 * (dq / 75));
  return {
    promote: need && input.listing.stock > 0,
    budgetDaily,
    confidence: dq > 70 ? 72 : 61,
    reason: need
      ? "Rules-advies: zichtbaarheid kan helpen; AI houdt relevantie leidend."
      : "Rules-advies: organisch bereik lijkt voldoende.",
    expectedViews,
    objective: "Meer relevante bezoekers",
    provider: "rules",
  };
}

export async function inventoryPromotionCoach(input: {
  seller: Seller | undefined;
  listings: Listing[];
}) {
  const scored = input.listings
    .map((l) => ({
      listing: l,
      dq: dealQualityScore(l, input.seller ? [input.seller] : []),
      urgency: stockPressure(l),
      views: l.views,
    }))
    .sort(
      (a, b) =>
        b.dq + b.urgency - b.views * 0.15 - (a.dq + a.urgency - a.views * 0.15),
    )
    .slice(0, 6);
  const res = await aiJson<{
    advice: {
      listingId: string;
      action: string;
      reason: string;
      budgetDaily: number;
      confidence: number;
    }[];
    summary: string;
  }>({
    task: "partner_coach",
    system: `Je bent Outrun Partner Coach AI. Geef uitsluitend JSON {"summary":"","advice":[{"listingId":"","action":"promote|improve|wait","reason":"","budgetDaily":0,"confidence":0}]}. Nederlands, concreet, conservatief.`,
    user: {
      partner: input.seller?.name,
      listings: scored.map((x) => ({
        id: x.listing.id,
        title: x.listing.title,
        price: x.listing.price,
        newPrice: x.listing.newPrice,
        views: x.views,
        stock: x.listing.stock,
        dealScore: x.dq,
      })),
    },
    temperature: 0.12,
    timeoutMs: 12_000,
  });
  if (res.ok && res.data?.advice?.length)
    return { provider: res.provider, ...res.data };
  return {
    provider: "rules" as const,
    summary:
      "AI-rules selecteert producten met hoge dealwaarde en lage views voor promotie.",
    advice: scored
      .slice(0, 3)
      .map((x) => ({
        listingId: x.listing.id,
        action: x.views < 25 ? "promote" : "wait",
        reason: `${x.listing.title}: dealScore ${x.dq}/100 en ${x.views} views.`,
        budgetDaily: x.dq > 75 ? 5 : 8,
        confidence: 70,
      })),
  };
}
