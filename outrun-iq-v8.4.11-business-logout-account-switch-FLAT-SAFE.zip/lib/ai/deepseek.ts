import type { PriceAdvice, PricingInput } from "./index";
import { heuristicPricing } from "./heuristic";

const API = process.env.DEEPSEEK_BASE_URL || "https://api.deepseek.com/chat/completions";
const MODEL = process.env.DEEPSEEK_MODEL || "deepseek-chat";

/** Robuuste getal-parser: accepteert 575, "575", "€575", "1.249,50". */
function num(x: unknown): number {
  if (typeof x === "number" && isFinite(x)) return Math.round(x);
  if (typeof x === "string") {
    const v = parseFloat(x.replace(/[^\d,.-]/g, "").replace(/\.(?=\d{3}\b)/g, "").replace(",", "."));
    if (isFinite(v)) return Math.round(v);
  }
  return NaN;
}

export async function deepseekPricing(i: PricingInput): Promise<PriceAdvice> {
  const key = process.env.DEEPSEEK_API_KEY;
  if (!key) throw new Error("DEEPSEEK_API_KEY ontbreekt");

  const sys = `Je bent de pricing-engine van een Nederlandse outlet-marketplace (overstock, showroommodellen, retouren van B2B-sellers aan consumenten). Je krijgt productgegevens en geeft prijsadvies in hele euro's. Wees realistisch en conservatief. Antwoord UITSLUITEND met geldige JSON, exact deze sleutels, alle prijzen als kale integers zonder valutateken:
{"fast":0,"outlet":0,"premium":0,"expectedDaysFast":0,"expectedDaysOutlet":0,"expectedDaysPremium":0,"confidence":0,"comps":0,"reasoning":""}
BELANGRIJK: "fast" = de LAAGSTE prijs (snelle verkoop), "outlet" = de middelste (aanbevolen), "premium" = de HOOGSTE (geduld). Dus altijd: fast < outlet < premium < nieuwprijs. Rond op €5. "confidence" 0-100. "comps" = aantal vergelijkbare prijspunten dat je kennis onderbouwt (laag getal + lagere confidence zonder echte marktdata). "reasoning" = één Nederlandse zin, max 140 tekens.`;

  const user = JSON.stringify({
    titel: i.title, merk: i.brand ?? null, categorie: i.category,
    conditie_tekst: i.condition, conditie_score_op_10: i.conditionScore,
    nieuwprijs_eur: i.newPrice, voorraad: i.stock,
    aantal_fotos: i.photosCount, gebrek: i.defect ?? null,
  });

  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), 25_000);
  try {
    const res = await fetch(API, {
      method: "POST",
      signal: ctl.signal,
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
      body: JSON.stringify({
        model: MODEL,
        temperature: 0.2,
        response_format: { type: "json_object" },
        messages: [{ role: "system", content: sys }, { role: "user", content: user }],
      }),
    });
    if (!res.ok) throw new Error(`DeepSeek ${res.status}: ${await res.text().catch(() => "")}`);
    const data = await res.json();
    const raw = data?.choices?.[0]?.message?.content ?? "";
    let p: Record<string, unknown> = {};
    try { p = JSON.parse(raw.replace(/```json|```/g, "").trim()); }
    catch { console.error("[ai] deepseek: geen parsebare JSON:", raw); return heuristicPricing(i); }

    const out: PriceAdvice = {
      fast: num(p.fast), outlet: num(p.outlet), premium: num(p.premium),
      expectedDaysFast: num(p.expectedDaysFast) || 3,
      expectedDaysOutlet: num(p.expectedDaysOutlet) || 7,
      expectedDaysPremium: num(p.expectedDaysPremium) || 16,
      confidence: Math.min(100, Math.max(0, num(p.confidence) || 0)),
      comps: Math.max(0, num(p.comps) || 0),
      reasoning: String(p.reasoning ?? "").slice(0, 160) || "Prijsadvies o.b.v. modelkennis.",
      source: "deepseek",
    };

    // Auto-reparatie: modellen halen fast/outlet/premium soms door elkaar -> sorteren i.p.v. afkeuren.
    let trio = [out.fast, out.outlet, out.premium].filter(v => isFinite(v) && v > 0);
    if (trio.length === 3) {
      trio = trio.map(v => Math.min(v, Math.round((i.newPrice * 0.95) / 5) * 5)).sort((a, b) => a - b);
      if (trio[1] <= trio[0]) trio[1] = trio[0] + 5;
      if (trio[2] <= trio[1]) trio[2] = trio[1] + 5;
      [out.fast, out.outlet, out.premium] = trio;
    }
    const sane = out.fast > 0 && out.fast < out.outlet && out.outlet < out.premium && out.outlet < i.newPrice;
    if (!sane) {
      console.error("[ai] deepseek onherstelbaar. Ruw antwoord:", raw);
      return { ...heuristicPricing(i), reasoning: "Modeloutput onbruikbaar \u2192 heuristiek." };
    }
    return out;
  } finally { clearTimeout(t); }
}
