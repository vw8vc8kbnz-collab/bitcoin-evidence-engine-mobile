/** Bezoekersmeting: in-memory tellen (views, unieke bezoekers per dag, live nu),
 *  met lazy flush naar db.traffic zodat niet elke pageview een schijfschrijf is.
 *  Bewust simpel: uniekheid per serverproces (herstart = kleine ondertelling). */
import { mutate } from "./store";

type Mem = {
  day: string;
  viewsDelta: number;
  newUniques: Set<string>;   // deze boot nog niet meegeteld
  seen: Set<string>;         // alle ids gezien deze boot (vandaag)
  live: Map<string, number>; // visitorId -> laatst gezien (ms)
  flushing: boolean;
};
const g = globalThis as unknown as { __oiqTraffic?: Mem };
const today = () => new Date().toISOString().slice(0, 10);

function mem(): Mem {
  const d = today();
  if (!g.__oiqTraffic || g.__oiqTraffic.day !== d) {
    g.__oiqTraffic = { day: d, viewsDelta: 0, newUniques: new Set(), seen: new Set(), live: new Map(), flushing: false };
  }
  return g.__oiqTraffic;
}

export function recordVisit(visitorId: string) {
  const m = mem();
  m.viewsDelta++;
  if (!m.seen.has(visitorId)) { m.seen.add(visitorId); m.newUniques.add(visitorId); }
  m.live.set(visitorId, Date.now());
  if (m.live.size > 2000) {                       // opruimen bij drukte
    const cutoff = Date.now() - 10 * 60_000;
    for (const [k, v] of m.live) if (v < cutoff) m.live.delete(k);
  }
  if (m.viewsDelta >= 20) void flushTraffic();    // fire-and-forget
}

export function liveNow(): number {
  const cutoff = Date.now() - 5 * 60_000;
  return [...mem().live.values()].filter(t => t > cutoff).length;
}

export async function flushTraffic() {
  const m = mem();
  if (m.flushing || (m.viewsDelta === 0 && m.newUniques.size === 0)) return;
  m.flushing = true;
  const views = m.viewsDelta, uniques = m.newUniques.size, day = m.day;
  m.viewsDelta = 0; m.newUniques = new Set();
  try {
    await mutate(db => {
      const t = (db.traffic[day] ??= { views: 0, visitors: 0 });
      t.views += views; t.visitors += uniques;
    });
  } finally { m.flushing = false; }
}
