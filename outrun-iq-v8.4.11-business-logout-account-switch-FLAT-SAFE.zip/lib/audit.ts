import type { AuditEvent, DB, User } from "./types";

type ActorInput =
  | { type: AuditEvent["actorType"]; id?: string; label?: string }
  | User
  | null
  | undefined;

function actorFrom(input: ActorInput): Pick<AuditEvent, "actorType" | "actorId" | "actorLabel"> {
  if (!input) return { actorType: "system" };
  if ("type" in input) return { actorType: input.type, actorId: input.id, actorLabel: input.label };
  const actorType: AuditEvent["actorType"] = input.role === "admin" ? "admin" : input.partnerSlug ? "partner" : "buyer";
  return { actorType, actorId: input.id, actorLabel: input.email };
}

export function audit(db: DB, input: {
  actor?: ActorInput;
  action: string;
  entity: AuditEvent["entity"];
  entityId?: string;
  summary: string;
  meta?: AuditEvent["meta"];
}) {
  const ev: AuditEvent = {
    id: Math.random().toString(36).slice(2, 10),
    at: new Date().toISOString(),
    ...actorFrom(input.actor),
    action: input.action,
    entity: input.entity,
    entityId: input.entityId,
    summary: input.summary.slice(0, 240),
    meta: input.meta,
  };
  (db.auditLog ??= []).push(ev);
  if (db.auditLog.length > 5000) db.auditLog = db.auditLog.slice(-5000);
  return ev;
}

export function auditToJsonl(events: AuditEvent[]) {
  return events.map(e => JSON.stringify(e)).join("\n") + (events.length ? "\n" : "");
}

export function auditToCsv(events: AuditEvent[]) {
  const headers = ["at", "actorType", "actorId", "actorLabel", "action", "entity", "entityId", "summary", "meta"];
  const esc = (v: unknown) => `"${String(v ?? "").replaceAll('"', '""')}"`;
  return [headers.join(","), ...events.map(e => headers.map(h => esc(h === "meta" ? JSON.stringify(e.meta ?? {}) : (e as any)[h])).join(","))].join("\n") + "\n";
}
