"use client";
import { useRouter } from "next/navigation";

export function LogoutButton() {
  const router = useRouter();
  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    router.replace("/welkom");
    router.refresh();
  }
  return (
    <button className="li" onClick={logout} style={{ width: "100%", textAlign: "left", background: "none", border: 0, font: "inherit", cursor: "pointer" }}>
      <b>Uitloggen<small>sessie op dit apparaat beëindigen</small></b>
    </button>
  );
}
