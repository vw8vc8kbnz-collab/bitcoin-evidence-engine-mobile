"use client";
import { useEffect, useState } from "react";

const ACTIVE = "oiq_flow_active";
const SESSION = "oiq_flow_session";
const EVENTS = "oiq_flow_events";
function rid() { return Math.random().toString(36).slice(2, 10); }
function maskSensitive(input?: string | null) {
  let s = String(input ?? "");
  s = s.replace(/([?&](?:pin|token|code|secret|key|session|auth|password)=)[^&#\s]+/gi, "$1•••");
  s = s.replace(/\b[A-Z0-9._%+-]+@([A-Z0-9.-]+\.[A-Z]{2,})\b/gi, "•••@$1");
  s = s.replace(/\b(?:sk|pk|rk|whsec|ntfy|ds)-[A-Za-z0-9_\-]{8,}\b/g, "•••KEY•••");
  s = s.replace(/\b\d{4}\s?[A-Z]{2}\b/gi, "••••••");
  return s;
}
function download(name: string, body: string, type = "application/json") {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([maskSensitive(body)], { type }));
  a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}
export function AdminFlowControls({ jsonlHref, replayHref }: { jsonlHref: string; replayHref: string }) {
  const [active, setActive] = useState(false);
  const [count, setCount] = useState(0);
  useEffect(() => {
    const sync = () => { setActive(localStorage.getItem(ACTIVE) === "1"); try { setCount(JSON.parse(localStorage.getItem(EVENTS) || "[]").length); } catch { setCount(0); } };
    sync(); window.addEventListener("storage", sync); window.addEventListener("oiq-flow-toggle", sync as EventListener);
    const t = window.setInterval(sync, 1000);
    return () => { window.removeEventListener("storage", sync); window.removeEventListener("oiq-flow-toggle", sync as EventListener); window.clearInterval(t); };
  }, []);
  const start = () => {
    const sid = `flow-${Date.now()}-${rid()}`;
    localStorage.setItem(SESSION, sid); localStorage.setItem(EVENTS, "[]"); localStorage.setItem(ACTIVE, "1");
    window.dispatchEvent(new Event("oiq-flow-toggle")); setActive(true); setCount(0);
    fetch("/api/flow/events", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: rid(), sessionId: sid, at: new Date().toISOString(), path: maskSensitive(location.pathname + location.search), type: "start", label: "beheer start testsessie", viewport: { w: innerWidth, h: innerHeight, dpr: devicePixelRatio || 1 }, ua: navigator.userAgent }) }).catch(() => {});
  };
  const stop = () => { localStorage.setItem(ACTIVE, "0"); window.dispatchEvent(new Event("oiq-flow-toggle")); setActive(false); };
  const local = () => download(`outrun-flow-local-${new Date().toISOString().slice(0,19).replace(/[:]/g,"-")}.json`, localStorage.getItem(EVENTS) || "[]");
  return <div className="orow" style={{ gap: 10, flexWrap: "wrap", borderColor: active ? "rgba(239,68,68,.45)" : undefined }}>
    <span><b>Flow Recorder {active ? "· REC" : ""}</b><span>Neemt route, clicks, fouten, snapshots en API-calls op. Pin/e-mail/adres/tokens worden gemaskeerd.</span></span>
    <button className="go" onClick={start} style={{ fontFamily: "var(--mono)", fontSize: 10, color: active ? "#888" : "var(--petrol-glow)" }}>{active ? "OPNIEUW STARTEN" : "START TESTSESSIE"}</button>
    <button className="go" onClick={stop} style={{ fontFamily: "var(--mono)", fontSize: 10, color: "#f1a632" }}>STOP</button>
    <button className="go" onClick={local} style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--petrol-glow)" }}>LOKAAL JSON ↓ ({count})</button>
    <a href={jsonlHref} className="go" style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--petrol-glow)" }}>SERVER JSONL ↓</a>
    <a href={replayHref} className="go" style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--petrol-glow)" }}>REPLAY HTML ↓</a>
  </div>;
}
