"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

const CATS = ["Niet geleverd", "Beschadigd", "Wijkt af van listing", "Anders"];

export function DisputeForm({ orderId }: { orderId: string }) {
  const [open, setOpen] = useState(false);
  const [cat, setCat] = useState("");
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const router = useRouter();

  async function submit() {
    setBusy(true); setErr("");
    const r = await fetch(`/api/orders/${orderId}/dispute`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ category: cat, text }),
    });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (r.ok) { setOpen(false); router.refresh(); }
    else setErr(j.error || "Melden mislukt");
  }

  if (!open) {
    return (
      <button className="btn sec" style={{ width: "calc(100% - 32px)", margin: "10px 16px 0", display: "block" }} onClick={() => setOpen(true)}>
        Probleem melden — bevriest de uitbetaling
      </button>
    );
  }
  return (
    <div className="authcard" style={{ margin: "12px 16px 0", padding: 16 }}>
      <label className="alabel" style={{ marginTop: 0 }}>WAT IS ER AAN DE HAND?</label>
      <div className="typerow" style={{ gridTemplateColumns: "1fr 1fr" }}>
        {CATS.map(c => (
          <button key={c} className={`typebtn${cat === c ? " on" : ""}`} onClick={() => setCat(c)}><b>{c}</b></button>
        ))}
      </div>
      <label className="alabel">TOELICHTING</label>
      <textarea
        rows={3} value={text} onChange={e => setText(e.target.value)}
        placeholder="Beschrijf het probleem zo concreet mogelijk (min. 10 tekens)"
        style={{ width: "100%", border: "1px solid var(--line)", borderRadius: 13, padding: "12px 14px", font: "inherit", fontSize: 13.5, background: "var(--card)", outline: "none", resize: "vertical", color: "var(--txt)" }}
      />
      {err && <p className="note" style={{ color: "var(--amber-deep)", margin: "8px 0 0" }}>{err}</p>}
      <div style={{ display: "flex", gap: 10, marginTop: 12 }}>
        <button className="btn pri" style={{ flex: 1 }} disabled={busy || !cat || text.trim().length < 10} onClick={submit}>
          {busy ? "Bezig…" : "Meld probleem"}
        </button>
        <button className="btn sec" style={{ flex: "none", padding: "0 18px" }} onClick={() => setOpen(false)}>Annuleer</button>
      </div>
    </div>
  );
}
