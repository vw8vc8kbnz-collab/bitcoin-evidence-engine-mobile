"use client";
import { useEffect } from "react";

/** Registreert de service worker (werkt alleen op HTTPS of localhost). */
export function PwaRegister() {
  useEffect(() => {
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js").catch(() => { /* http/IP: stil overslaan */ });
    }
  }, []);
  return null;
}
