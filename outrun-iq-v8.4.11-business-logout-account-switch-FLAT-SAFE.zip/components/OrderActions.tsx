"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import type { OrderStatus } from "@/lib/types";

export function OrderAction({ id, to, label }:{
  id: string; to: OrderStatus; label: string;
}) {
  const [busy, setBusy] = useState(false);
  const router = useRouter();
  async function go() {
    setBusy(true);
    await fetch("/api/partner/orders", {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, to }),
    });
    router.refresh();
    setBusy(false);
  }
  return (
    <button className="go" onClick={go} disabled={busy}
      style={{ marginLeft: "auto", fontFamily: "var(--mono)", fontSize: 9, color: "var(--amber)", fontWeight: 600 }}>
      {busy ? "…" : label + " →"}
    </button>
  );
}
