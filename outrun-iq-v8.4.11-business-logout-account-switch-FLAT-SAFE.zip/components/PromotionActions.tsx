"use client";
import { useState } from "react";
import type { PromotionCampaign } from "@/lib/types";

export function PromotionActions({ campaign }: { campaign: Pick<PromotionCampaign, "id" | "status" | "refundedCents" | "spentCents" | "reservedCents"> }) {
  const [busy, setBusy] = useState<string>("");
  const [msg, setMsg] = useState("");
  async function act(status: "active" | "paused" | "stopped") {
    if (status === "stopped" && !confirm("Campagne stoppen? Ongebruikt budget gaat automatisch terug naar je Outrun Wallet.")) return;
    setBusy(status); setMsg("");
    try {
      const r = await fetch("/api/partner/promote", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "status", id: campaign.id, status, reason: status === "stopped" ? "Gestopt door partner" : "" }),
      });
      const j = await r.json().catch(() => ({}));
      if (!r.ok || j.error) throw new Error(j.error || "Actie mislukt");
      if (status === "stopped") {
        const refund = Number(j.refundedCents ?? j.campaign?.refundedCents ?? 0) / 100;
        setMsg(`Gestopt. €${refund.toLocaleString("nl-NL")} terug naar je Wallet.`);
      } else setMsg(status === "paused" ? "Campagne gepauzeerd." : "Campagne hervat.");
      setTimeout(() => location.reload(), 900);
    } catch (e) { setMsg(e instanceof Error ? e.message : "Fout"); }
    finally { setBusy(""); }
  }
  if (campaign.status === "stopped" || campaign.status === "ended") {
    const refund = (campaign.refundedCents ?? 0) / 100;
    return <div className="promotionActions settled"><span>Afgesloten · refund €{refund.toLocaleString("nl-NL")}</span></div>;
  }
  return (
    <div className="promotionActions">
      {campaign.status === "active" ? <button onClick={() => act("paused")} disabled={!!busy}>Pauzeer</button> : <button onClick={() => act("active")} disabled={!!busy}>Hervat</button>}
      <button className="danger" onClick={() => act("stopped")} disabled={!!busy}>Stop + refund</button>
      {msg && <span>{msg}</span>}
    </div>
  );
}
