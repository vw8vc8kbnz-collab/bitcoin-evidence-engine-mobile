"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

const inp: React.CSSProperties = {
  width: "100%", border: "1px solid var(--line)", borderRadius: 13, padding: "13px 14px",
  font: "inherit", fontSize: 14, background: "var(--card)", outline: "none", color: "var(--txt)",
};

export function PartnerApply() {
  const [f, setF] = useState({ companyName: "", kvk: "", city: "" });
  const [terms, setTerms] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const router = useRouter();
  async function submit() {
    setBusy(true); setErr("");
    const r = await fetch("/api/partner-aanvraag", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...f, termsAccepted: terms }),
    });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (r.ok) router.refresh();
    else setErr(j.error || "Aanvragen mislukt");
  }
  return (
    <div className="authcard" style={{ marginTop: 16 }}>
      <label className="alabel">BEDRIJFSNAAM</label>
      <input style={inp} value={f.companyName} onChange={e => setF({ ...f, companyName: e.target.value })} placeholder="Expert Outlet Rotterdam B.V." />
      <label className="alabel">KVK-NUMMER</label>
      <input style={inp} inputMode="numeric" maxLength={8} value={f.kvk} onChange={e => setF({ ...f, kvk: e.target.value.replace(/\D/g, "") })} placeholder="12345678" />
      {f.kvk.length > 0 && f.kvk.length < 8 && (
        <p style={{ fontSize: 11, color: "var(--amber-deep)", margin: "6px 2px 0", fontFamily: "var(--mono)" }}>
          {f.kvk.length}/8 cijfers — nog {8 - f.kvk.length} te gaan
        </p>
      )}
      <label className="alabel">PLAATS</label>
      <input style={inp} value={f.city} onChange={e => setF({ ...f, city: e.target.value })} placeholder="Rotterdam" />
      <label className="lcheck">
        <input type="checkbox" checked={terms} onChange={e => setTerms(e.target.checked)} />
        <span>Ik ga namens dit bedrijf akkoord met de <Link href="/juridisch/partnervoorwaarden" target="_blank">Partnervoorwaarden</Link>.</span>
      </label>
      {err && <p className="note" style={{ color: "var(--amber-deep)", marginTop: 10 }}>{err}</p>}
      <button className="btn pri abtn" onClick={submit} disabled={busy || !f.companyName || f.kvk.length !== 8 || !f.city || !terms}>
        {busy ? "Bezig…" : "Vraag partneraccount aan"}
      </button>
    </div>
  );
}
