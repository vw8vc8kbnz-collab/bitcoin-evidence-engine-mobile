"use client";
import { useEffect } from "react";
import { usePathname } from "next/navigation";

export function Track() {
  const pathname = usePathname();
  useEffect(() => {
    fetch("/api/beacon", { method: "POST", keepalive: true }).catch(() => {});
  }, [pathname]);
  return null;
}
