"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { eur } from "@/lib/types";

const inp: React.CSSProperties = {
  width: "100%", border: "1px solid var(--line)", borderRadius: 13, padding: "12px 14px",
  font: "inherit", fontSize: 14, background: "var(--card)", outline: "none", color: "var(--txt)",
};

export function CheckoutForm({ listingId, price, perUnit, deliveryLabel, deliveryPrice, pickupCity, pickupAddress, buyerName, bidId }:{
  listingId: string; price: number; perUnit: boolean;
  deliveryLabel: string; deliveryPrice: number; pickupCity: string;
  pickupAddress?: string; buyerName: string; bidId?: string;
}) {
  const [delivery, setDelivery] = useState<"bezorgen" | "ophalen">("bezorgen");
  const [pay, setPay] = useState<"ideal" | "applepay">("ideal");
  const [a, setA] = useState({ name: buyerName, street: "", postcode: "", city: "" });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const router = useRouter();
  const total = price + (delivery === "bezorgen" ? deliveryPrice : 0);
  const addrOk = delivery === "ophalen" || (a.street.trim().length >= 3 && /^\d{4}\s?[a-zA-Z]{2}$/.test(a.postcode.trim()) && a.city.trim().length >= 2);

  async function submit() {
    setBusy(true); setErr("");
    const r = await fetch("/api/orders", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ listingId, delivery, bidId, address: delivery === "bezorgen" ? a : undefined }),
    });
    const j = await r.json().catch(() => ({}));
    if (r.ok && j.id) { router.push(`/order/${j.id}`); return; }
    setBusy(false);
    setErr(j.error || "Bestellen mislukt. Probeer opnieuw.");
  }

  return (
    <>
      {bidId && <p className="note" style={{ color: "var(--petrol)", fontWeight: 700 }}>✦ Je rekent af tegen je geaccepteerde bodprijs.</p>}

      <div className="checkoutTrust">
        <div><b>1</b><span><strong>Jij plaatst de order</strong><small>betaling is in deze versie nog testmodus</small></span></div>
        <div><b>2</b><span><strong>Partner levert</strong><small>bezorgen of ophalen met duidelijke status</small></span></div>
        <div><b>3</b><span><strong>Geld pas vrij na levering</strong><small>probleem melden pauzeert uitbetaling</small></span></div>
      </div>

      <div className="slabel">LEVERING</div>
      <div className="radios">
        <button className={`rad${delivery === "bezorgen" ? " on" : ""}`} onClick={() => setDelivery("bezorgen")}>
          <span className="o" /><span><b>{deliveryLabel}</b><span>bezorging op jouw adres</span></span>
          <span className="p2">{deliveryPrice > 0 ? eur(deliveryPrice) : "Gratis"}</span>
        </button>
        <button className={`rad${delivery === "ophalen" ? " on" : ""}`} onClick={() => setDelivery("ophalen")}>
          <span className="o" /><span><b>Ophalen in {pickupCity}</b><span>{pickupAddress ? `adres: ${pickupAddress}` : "adres zie je na de bestelling"}</span></span>
          <span className="p2">Gratis</span>
        </button>
      </div>

      {delivery === "bezorgen" && (
        <>
          <div className="slabel">BEZORGADRES</div>
          <div className="authcard" style={{ margin: "0 16px", padding: 16 }}>
            <label className="alabel" style={{ marginTop: 0 }}>NAAM</label>
            <input style={inp} value={a.name} onChange={e => setA({ ...a, name: e.target.value })} autoComplete="name" />
            <label className="alabel">STRAAT + HUISNUMMER</label>
            <input style={inp} value={a.street} onChange={e => setA({ ...a, street: e.target.value })} placeholder="Outletstraat 12" autoComplete="street-address" />
            <div style={{ display: "grid", gridTemplateColumns: "130px 1fr", gap: 10 }}>
              <span><label className="alabel">POSTCODE</label>
                <input style={inp} value={a.postcode} onChange={e => setA({ ...a, postcode: e.target.value })} placeholder="1234 AB" autoComplete="postal-code" /></span>
              <span><label className="alabel">PLAATS</label>
                <input style={inp} value={a.city} onChange={e => setA({ ...a, city: e.target.value })} autoComplete="address-level2" /></span>
            </div>
          </div>
        </>
      )}
      {delivery === "ophalen" && (
        <p className="note">Na je bestelling krijg je een persoonlijke <b>afhaalcode</b>. Die toon je bij het ophalen — zo weet het magazijn zeker dat jij de koper bent.</p>
      )}

      <div className="slabel">BETALING · TESTMODUS</div>
      <div className="radios">
        <button className={`rad${pay === "ideal" ? " on" : ""}`} onClick={() => setPay("ideal")}>
          <span className="o" /><span><b>iDEAL</b><span>gesimuleerd — geen echte afschrijving</span></span>
        </button>
        <button className={`rad${pay === "applepay" ? " on" : ""}`} onClick={() => setPay("applepay")}>
          <span className="o" /><span><b>Apple Pay</b><span>gesimuleerd — geen echte afschrijving</span></span>
        </button>
      </div>
      <div className="slabel">TOTAAL · GELD IN ESCROW TOT LEVERING</div>
      <div className="orderSummary">
        <div><span>Artikel</span><b>{eur(price)}{perUnit && <small> per stuk ×1</small>}</b></div>
        <div><span>{delivery === "bezorgen" ? "Levering" : "Ophalen"}</span><b>{delivery === "bezorgen" ? eur(deliveryPrice) : "Gratis"}</b></div>
        <div className="total"><span>Totaal</span><b>{eur(total)}</b></div>
      </div>
      {err && <p className="note" style={{ color: "var(--amber-deep)" }}>{err}</p>}
      <p className="note">Je betaalt aan Outrun IQ, niet direct aan de partner. Uitbetaling volgt pas na jouw leverbevestiging. Door te bestellen ga je akkoord met de <a href="/juridisch/gebruiksvoorwaarden" target="_blank" style={{ color: "var(--petrol)", fontWeight: 700 }}>Gebruiksvoorwaarden</a>.</p>
      <div className="foot checkoutFoot">
        <button className="btn pri" style={{ width: "100%" }} onClick={submit} disabled={busy || !addrOk}>
          {busy ? "Bezig…" : delivery === "bezorgen" && !addrOk ? "Vul je bezorgadres in" : `Plaats testorder — ${eur(total)}`}
        </button>
      </div>
    </>
  );
}
