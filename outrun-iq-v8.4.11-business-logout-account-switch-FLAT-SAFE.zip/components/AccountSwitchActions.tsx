"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export function AccountSwitchActions({ variant = "light" }: { variant?: "light" | "dark" }) {
  const router = useRouter();
  const [busy, setBusy] = useState<"logout" | "personal" | "business" | null>(null);

  async function endSession(dest: string, mode: "logout" | "personal" | "business") {
    setBusy(mode);
    try {
      await fetch("/api/auth/logout", { method: "POST", cache: "no-store" });
      router.replace(dest);
      router.refresh();
    } finally {
      setBusy(null);
    }
  }

  return (
    <div className={`accountSwitchActions ${variant === "dark" ? "dark" : ""}`}>
      <button type="button" className="btn pri" disabled={!!busy} onClick={() => endSession("/welkom?type=persoonlijk&next=/", "personal")}>
        {busy === "personal" ? "Uitloggen…" : "Uitloggen en persoonlijk inloggen"}
      </button>
      <button type="button" className="btn ghost" disabled={!!busy} onClick={() => endSession("/welkom?type=zakelijk&next=/partner", "business")}>
        {busy === "business" ? "Uitloggen…" : "Ander zakelijk account"}
      </button>
      <button type="button" className="btn sec" disabled={!!busy} onClick={() => endSession("/welkom", "logout")}>
        {busy === "logout" ? "Uitloggen…" : "Alleen uitloggen"}
      </button>
    </div>
  );
}
