"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import type { Address } from "@/lib/types";

const inp: React.CSSProperties = {
  width: "100%", background: "none", border: "1px solid #2A3540", borderRadius: 11,
  padding: "11px 12px", color: "#fff", font: "inherit", fontSize: 13, outline: "none",
};

export function StorefrontEditor({ logo, banner, about, address, support }:{
  logo?: string; banner?: string; about?: string; address?: Address;
  support?: { email: string; phone?: string; returnsInfo?: string };
}) {
  const [f, setF] = useState({
    about: about ?? "", street: address?.street ?? "", postcode: address?.postcode ?? "", city: address?.city ?? "",
    supEmail: support?.email ?? "", supPhone: support?.phone ?? "", supReturns: support?.returnsInfo ?? "",
  });
  const [logoUrl, setLogoUrl] = useState(logo ?? "");
  const [bannerUrl, setBannerUrl] = useState(banner ?? "");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");
  const router = useRouter();

  async function upload(file: File | undefined, kind: "logo" | "banner") {
    if (!file) return;
    setBusy(true); setMsg("");
    const fd = new FormData();
    fd.append("photos", file);
    const r = await fetch("/api/partner/upload", { method: "POST", body: fd });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (r.ok && j.urls?.[0]) (kind === "logo" ? setLogoUrl : setBannerUrl)(j.urls[0]);
    else setMsg(j.error || "Upload mislukt");
  }

  async function save() {
    setBusy(true); setMsg("");
    const body: Record<string, unknown> = { logoUrl, bannerUrl, about: f.about };
    if (f.street || f.postcode || f.city) body.address = { street: f.street, postcode: f.postcode, city: f.city };
    if (f.supEmail) body.support = { email: f.supEmail, phone: f.supPhone, returnsInfo: f.supReturns };
    const r = await fetch("/api/partner/profile", {
      method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
    });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (r.ok) { setMsg("Opgeslagen ✓"); router.refresh(); }
    else setMsg(j.error || "Opslaan mislukt");
  }

  return (
    <div className="dgroup" style={{ marginTop: 14, padding: "14px 16px", display: "block" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
        <span className="av" style={{ width: 52, height: 52, flex: "none", overflow: "hidden" }}>
          {logoUrl
            ? /* eslint-disable-next-line @next/next/no-img-element */
              <img src={logoUrl} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
            : "LO"}
        </span>
        <label className="go" style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--petrol-glow)", cursor: "pointer" }}>
          {logoUrl ? "LOGO VERVANGEN →" : "LOGO UPLOADEN →"}
          <input type="file" accept="image/*" hidden onChange={e => upload(e.target.files?.[0], "logo")} />
        </label>
      </div>
      <label className="alabel" style={{ color: "#5F6873" }}>BANNER (BREED, OPTIONEEL)</label>
      <div style={{ height: 74, borderRadius: 12, overflow: "hidden", background: "#1A222B", display: "grid", placeItems: "center", position: "relative" }}>
        {bannerUrl
          ? /* eslint-disable-next-line @next/next/no-img-element */
            <img src={bannerUrl} alt="" style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover" }} />
          : <span style={{ fontFamily: "var(--mono)", fontSize: 10, color: "#5F6873" }}>NOG GEEN BANNER</span>}
      </div>
      <label className="go" style={{ display: "inline-block", marginTop: 8, fontFamily: "var(--mono)", fontSize: 10, color: "var(--petrol-glow)", cursor: "pointer" }}>
        {bannerUrl ? "BANNER VERVANGEN →" : "BANNER UPLOADEN →"}
        <input type="file" accept="image/*" hidden onChange={e => upload(e.target.files?.[0], "banner")} />
      </label>
      <label className="alabel" style={{ color: "#5F6873" }}>OVER JULLIE (MAX 280)</label>
      <textarea rows={3} maxLength={280} value={f.about} onChange={e => setF({ ...f, about: e.target.value })}
        placeholder="Bijv.: Officieel dealer sinds 2004. Outlet uit eigen showroom en retourstromen."
        style={{ ...inp, resize: "vertical" }} />
      <label className="alabel" style={{ color: "#5F6873" }}>AFHAAL- / MAGAZIJNADRES</label>
      <input style={{ ...inp, marginBottom: 8 }} value={f.street} onChange={e => setF({ ...f, street: e.target.value })} placeholder="Straat + nummer" />
      <div style={{ display: "grid", gridTemplateColumns: "120px 1fr", gap: 8 }}>
        <input style={inp} value={f.postcode} onChange={e => setF({ ...f, postcode: e.target.value })} placeholder="1234 AB" />
        <input style={inp} value={f.city} onChange={e => setF({ ...f, city: e.target.value })} placeholder="Plaats" />
      </div>
      <label className="alabel" style={{ color: "#5F6873" }}>KLANTENSERVICE — VERPLICHT VÓÓR PUBLICEREN</label>
      <input style={{ ...inp, marginBottom: 8 }} type="email" value={f.supEmail} onChange={e => setF({ ...f, supEmail: e.target.value })} placeholder="service@jouwbedrijf.nl" />
      <input style={{ ...inp, marginBottom: 8 }} value={f.supPhone} onChange={e => setF({ ...f, supPhone: e.target.value })} placeholder="Telefoon (optioneel)" />
      <input style={inp} value={f.supReturns} onChange={e => setF({ ...f, supReturns: e.target.value })} placeholder="Retourinfo (optioneel) — bv. retouren o.v.v. ordernummer" />
      <button className="btn pri" style={{ width: "100%", marginTop: 14, border: 0 }} onClick={save} disabled={busy}>
        {busy ? "Bezig…" : "Opslaan"}
      </button>
      {msg && <p className="note" style={{ margin: "10px 0 0", color: msg.includes("✓") ? "var(--petrol-glow)" : "var(--amber)" }}>{msg}</p>}
    </div>
  );
}
