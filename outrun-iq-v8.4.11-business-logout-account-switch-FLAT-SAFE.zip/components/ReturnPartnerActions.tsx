"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export function ReturnPartnerActions({ orderId, status }:{ orderId: string; status: string }) {
  const [open, setOpen] = useState(false);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const router = useRouter();

  async function patch(body: object) {
    setBusy(true); setErr("");
    const r = await fetch("/api/partner/returns", {
      method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ orderId, ...body }),
    });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (r.ok) { setOpen(false); router.refresh(); }
    else setErr(j.error || "Mislukt");
  }

  const btn: React.CSSProperties = {
    fontFamily: "var(--mono)", fontSize: 9.5, fontWeight: 600, letterSpacing: .8,
    background: "none", border: "1px solid #2A3540", borderRadius: 9, padding: "7px 11px",
    color: "var(--petrol-glow)", cursor: "pointer",
  };

  if (status === "responded") {
    return (
      <div style={{ margin: "8px 16px 14px" }}>
        <button style={{ ...btn, color: "#4CBE8B" }} disabled={busy} onClick={() => patch({ action: "complete" })}>RETOUR ONTVANGEN → RONDT AF</button>
        {err && <span style={{ fontSize: 10.5, color: "var(--amber)", marginLeft: 8 }}>{err}</span>}
      </div>
    );
  }
  return (
    <div style={{ margin: "8px 16px 14px", maxWidth: 760 }}>
      {!open ? (
        <button style={btn} onClick={() => setOpen(true)}>STUUR RETOURINSTRUCTIES →</button>
      ) : (
        <>
          <textarea rows={3} value={text} onChange={e => setText(e.target.value)}
            placeholder="Bijv.: stuur naar ons magazijnadres o.v.v. het ordernummer; wij betalen terug binnen 14 dagen na ontvangst."
            style={{ width: "100%", background: "none", border: "1px solid #2A3540", borderRadius: 11, padding: "10px 12px", color: "#fff", font: "inherit", fontSize: 12.5, resize: "vertical" }} />
          <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
            <button style={{ ...btn, color: "#4CBE8B" }} disabled={busy || text.trim().length < 10} onClick={() => patch({ action: "respond", instructions: text })}>VERSTUUR</button>
            <button style={btn} onClick={() => setOpen(false)}>ANNULEER</button>
          </div>
        </>
      )}
      {err && <p style={{ fontSize: 10.5, color: "var(--amber)", margin: "6px 0 0" }}>{err}</p>}
    </div>
  );
}
