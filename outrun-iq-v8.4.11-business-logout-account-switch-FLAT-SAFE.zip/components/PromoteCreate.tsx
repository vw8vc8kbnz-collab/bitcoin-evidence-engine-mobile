"use client";
import { useMemo, useState } from "react";
import type { Listing } from "@/lib/types";

type MiniListing = Pick<Listing, "id" | "title" | "category" | "price" | "newPrice" | "views" | "stock" | "conditionScore" | "photos">;

const objectives = [
  { id: "views", title: "Meer views", text: "Breed bereik met lage kosten per impressie.", mult: 1.0 },
  { id: "chats", title: "Meer chats", text: "Optimaliseer voor kopers met sterke intentie.", mult: 0.82 },
  { id: "sell_faster", title: "Sneller verkopen", text: "Meer druk op producten met goede deal-score.", mult: 1.12 },
  { id: "brand", title: "Nieuwe klanten", text: "Meer winkelbezoeken en partnervertrouwen.", mult: 0.72 },
] as const;
const budgets = [10, 25, 50, 100];

function score(l?: MiniListing) {
  if (!l) return 72;
  const discount = l.newPrice > 0 ? Math.max(0, Math.min(45, ((l.newPrice - l.price) / l.newPrice) * 100)) : 16;
  const stockBoost = Math.min(12, l.stock * 3);
  const lowViewBoost = l.views < 25 ? 12 : l.views < 80 ? 6 : 0;
  return Math.max(42, Math.min(96, Math.round(42 + discount * 0.65 + l.conditionScore * 2.2 + stockBoost + lowViewBoost)));
}

export function PromoteCreate({ listings }:{ listings: MiniListing[] }) {
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");
  const [step, setStep] = useState(1);
  const [kind, setKind] = useState<"seller" | "listing" | "category">("listing");
  const [objective, setObjective] = useState<(typeof objectives)[number]["id"]>("sell_faster");
  const [budgetDaily, setBudgetDaily] = useState(25);
  const [days, setDays] = useState(7);
  const [name, setName] = useState("AI Boost Campagne");
  const [category, setCategory] = useState("");
  const [selected, setSelected] = useState<string[]>(listings.slice(0, 3).map(l => l.id));
  const selectedSet = useMemo(() => new Set(selected), [selected]);
  const chosen = useMemo(() => listings.filter(l => selectedSet.has(l.id)), [listings, selectedSet]);
  const main = chosen[0] ?? listings[0];
  const objectiveMeta = objectives.find(o => o.id === objective) ?? objectives[2];
  const aiScore = Math.round((chosen.reduce((s, l) => s + score(l), 0) / Math.max(1, chosen.length)) || score(main));
  const expectedViews = Math.round(budgetDaily * days * 36 * objectiveMeta.mult * (aiScore / 76));
  const expectedChats = Math.max(1, Math.round(expectedViews * (objective === "chats" ? 0.055 : objective === "sell_faster" ? 0.038 : 0.025)));
  const roi = Math.max(1.4, Math.min(7.8, (aiScore / 23) * objectiveMeta.mult));
  const confidence = Math.max(58, Math.min(94, Math.round(aiScore * 0.82 + chosen.length * 2)));

  function toggle(id: string) {
    setSelected(cur => cur.includes(id) ? cur.filter(x => x !== id) : [...cur, id].slice(0, 20));
  }
  async function submit(e?: React.FormEvent<HTMLFormElement>) {
    e?.preventDefault();
    setBusy(true); setMsg("");
    const listingIds = selected;
    try {
      if (kind === "listing" && listingIds.length === 0) throw new Error("Kies minimaal één product voor een productcampagne");
      const r = await fetch("/api/partner/promote", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ kind, listingIds, category, name, objective, budgetDaily, days, requestId: crypto.randomUUID?.() ?? `${Date.now()}-${Math.random()}` }),
      });
      const j = await r.json().catch(() => ({}));
      if (!r.ok || j.error) throw new Error(j.error || "Campagne kon niet starten");
      setMsg(`Campagne gestart. Budget gereserveerd: €${budgetDaily * days}. AI maakt varianten en monitort rendement.`);
      setTimeout(() => location.reload(), 650);
    } catch (err) { setMsg(err instanceof Error ? err.message : "Fout"); }
    finally { setBusy(false); }
  }

  return (
    <form className="promoteWizard" onSubmit={submit}>
      <div className="wizardSteps" aria-label="Campagne stappen">
        {["Product", "Doel", "Budget", "AI forecast"].map((s, i) => <button key={s} type="button" className={step === i + 1 ? "on" : ""} onClick={() => setStep(i + 1)}><b>{i + 1}</b><span>{s}</span></button>)}
      </div>

      {step === 1 && <section className="wizardPanel">
        <span className="eyebrow">Stap 1 · kies wat je promoot</span>
        <h3>Producten met commerciële kans</h3>
        <p>AI geeft voorrang aan producten met goede deal-score, lage views en genoeg voorraad.</p>
        <div className="campaignTypeGrid">
          {(["listing", "seller", "category"] as const).map(k => <button key={k} type="button" onClick={() => setKind(k)} className={kind === k ? "on" : ""}><b>{k === "listing" ? "Producten" : k === "seller" ? "Bedrijf" : "Categorie"}</b><small>{k === "listing" ? "Meest meetbaar" : k === "seller" ? "Partner Spotlight" : "Breed in categorie"}</small></button>)}
        </div>
        <label className="wizardInput">Campagnenaam<input value={name} onChange={e => setName(e.target.value)} /></label>
        {kind === "category" && <label className="wizardInput">Categorie<select value={category} onChange={e => setCategory(e.target.value)}><option value="">— kies categorie —</option><option value="witgoed">Witgoed</option><option value="meubels">Meubels</option><option value="keukens">Keukens</option><option value="tuin">Tuin</option><option value="overig">Overig</option></select></label>}
        <div className="promoteChecks coachProductGrid">
          {listings.slice(0, 40).map(l => <button key={l.id} type="button" onClick={() => toggle(l.id)} className={selectedSet.has(l.id) ? "on" : ""}>
            <span>{selectedSet.has(l.id) ? "✓" : "+"}</span><b>{l.title}</b><small>{l.category} · score {score(l)} · {l.views} views</small>
          </button>)}
        </div>
        <div className="promoteSelectBar"><b>{selected.length}</b><span>producten geselecteerd</span><button type="button" onClick={() => setSelected(listings.sort((a,b)=>score(b)-score(a)).slice(0, 5).map(l => l.id))}>AI selectie</button><button type="button" onClick={() => setSelected([])}>Wis</button></div>
      </section>}

      {step === 2 && <section className="wizardPanel">
        <span className="eyebrow">Stap 2 · doel</span>
        <h3>Waar moet AI op sturen?</h3>
        <div className="objectiveGrid">
          {objectives.map(o => <button key={o.id} type="button" onClick={() => setObjective(o.id)} className={objective === o.id ? "on" : ""}><b>{o.title}</b><span>{o.text}</span></button>)}
        </div>
      </section>}

      {step === 3 && <section className="wizardPanel">
        <span className="eyebrow">Stap 3 · budget</span>
        <h3>Kies gecontroleerd promotiebudget</h3>
        <div className="budgetPills">{budgets.map(b => <button type="button" key={b} onClick={() => setBudgetDaily(b)} className={budgetDaily === b ? "on" : ""}>€{b}<small>/dag</small></button>)}</div>
        <div className="promoteSplit"><label className="wizardInput">Budget/dag<input value={budgetDaily} onChange={e => setBudgetDaily(Number(e.target.value || 0))} type="number" min="3" max="100" /></label><label className="wizardInput">Dagen<input value={days} onChange={e => setDays(Number(e.target.value || 1))} type="number" min="1" max="30" /></label></div>
        <article className="promoteFairness"><b>Wallet-reservering</b><span>Bij starten reserveert Outrun €{budgetDaily * days} in de wallet. Ongebruikt budget komt terug zodra je stopt.</span></article>
      </section>}

      {step === 4 && <section className="wizardPanel forecastPanel">
        <span className="eyebrow">Stap 4 · AI forecast</span>
        <h3>Verwachte campagneprestatie</h3>
        <div className="forecastHero"><strong>{confidence}%</strong><span>AI confidence</span><p>{objectiveMeta.title} · {chosen.length || "AI"} product(en) · {days} dagen</p></div>
        <div className="forecastGrid"><span><b>{expectedViews}</b><small>views</small></span><span><b>{expectedChats}</b><small>chats</small></span><span><b>{roi.toFixed(1)}×</b><small>ROI indicatie</small></span><span><b>€{budgetDaily * days}</b><small>reservering</small></span></div>
        <article className="aiForecastCopy"><b>AI advies</b><p>{aiScore > 82 ? "Sterke campagnekans: goede deal-score en genoeg voorraad." : aiScore > 68 ? "Prima om klein te testen. AI bewaakt de relevantie en fatigue." : "Start voorzichtig. Verbeter titel/foto/prijs voor meer rendement."}</p></article>
      </section>}

      <div className="wizardFooter">
        <button type="button" className="btn ghost" disabled={step === 1 || busy} onClick={() => setStep(s => Math.max(1, s - 1))}>Terug</button>
        {step < 4 ? <button type="button" className="btn pri" onClick={() => setStep(s => Math.min(4, s + 1))}>Volgende</button> : <button className="btn pri" disabled={busy}>{busy ? "AI start campagne..." : "Start campagne"}</button>}
      </div>
      {msg && <p className="note">{msg}</p>}
    </form>
  );
}
