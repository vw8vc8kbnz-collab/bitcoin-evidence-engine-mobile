"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

/** Partner stelt max. 3 bezorgmomenten voor (vervangt de kale PLAN LEVERING-knop). */
export function SlotProposer({ orderId }:{ orderId: string }) {
  const [open, setOpen] = useState(false);
  const [slots, setSlots] = useState(["", "", ""]);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const router = useRouter();

  async function submit() {
    setBusy(true); setErr("");
    const r = await fetch("/api/partner/orders", {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ orderId, to: "delivery_planned", slots: slots.filter(Boolean) }),
    });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (r.ok) { setOpen(false); router.refresh(); }
    else setErr(j.error || "Mislukt");
  }
  const btn: React.CSSProperties = {
    fontFamily: "var(--mono)", fontSize: 9.5, fontWeight: 600, letterSpacing: .8,
    background: "none", border: "1px solid #2A3540", borderRadius: 9, padding: "7px 11px",
    color: "var(--petrol-glow)", cursor: "pointer",
  };
  if (!open) return <button style={btn} onClick={() => setOpen(true)}>STEL MOMENTEN VOOR →</button>;
  return (
    <span style={{ display: "flex", flexDirection: "column", gap: 6 }}>
      {slots.map((s, i) => (
        <input key={i} type="datetime-local" value={s}
          onChange={e => setSlots(slots.map((x, j) => (j === i ? e.target.value : x)))}
          style={{ ...btn, colorScheme: "dark", color: "#fff", cursor: "text" }} />
      ))}
      <span style={{ display: "flex", gap: 8 }}>
        <button style={{ ...btn, color: "#4CBE8B" }} disabled={busy || !slots.some(Boolean)} onClick={submit}>VERSTUUR</button>
        <button style={{ ...btn, color: "#8B96A0" }} onClick={() => setOpen(false)}>ANNULEER</button>
      </span>
      {err && <span style={{ fontSize: 10.5, color: "var(--amber)" }}>{err}</span>}
    </span>
  );
}
