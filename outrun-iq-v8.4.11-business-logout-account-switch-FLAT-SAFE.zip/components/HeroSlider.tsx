"use client";
import { useRef, useState } from "react";
import Link from "next/link";
import type { Listing } from "@/lib/types";
import { eur } from "@/lib/types";
import { EvidenceStrip } from "./EvidenceStrip";

const disc = (p: number, n: number) => Math.round((1 - p / n) * 100);

/** "Voor jou": swipebare hero met de bestaande .feat-kaartstijl + dots. */
export function HeroSlider({ items, personalized }:{ items: Listing[]; personalized: boolean }) {
  const [i, setI] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  function onScroll() {
    const el = ref.current;
    if (el) setI(Math.round(el.scrollLeft / el.clientWidth));
  }
  if (items.length === 0) return null;
  return (
    <div style={{ position: "relative" }}>
      <div ref={ref} onScroll={onScroll} className="heroslide">
        {items.map((feat, idx) => (
          <Link key={feat.id} href={`/listing/${feat.id}`} className="feat" style={{ flex: "0 0 calc(100% - 32px)", scrollSnapAlign: "center" }}>
            {feat.photos[0] && /* eslint-disable-next-line @next/next/no-img-element */
              <img src={feat.photos[0]} alt="" />}
            <span className="shade" />
            <span className="tag">{personalized ? "VOOR JOU" : idx === 0 ? "NIEUWSTE DEAL" : "UITGELICHT"} · AI-GEPRIJSD</span>
            <h3>{feat.title}</h3>
            {feat.stock === 1 && <span className="stick">SLECHTS 1 STUK</span>}
            <div className="strip">
              <div className="l1"><b>{eur(feat.price)}{feat.perUnit && "/st"}</b><s>nieuw {eur(feat.newPrice)}</s><span className="d">−{disc(feat.price, feat.newPrice)}%</span></div>
              <EvidenceStrip l={feat} labels={false} />
            </div>
          </Link>
        ))}
      </div>
      {items.length > 1 && (
        <span className="herodots">
          {items.map((_, j) => <i key={j} className={j === i ? "on" : ""} />)}
        </span>
      )}
    </div>
  );
}
