"use client";
import type { ReactNode } from "react";
import { useRouter } from "next/navigation";

export function BusinessAccountLink({ className = "", children = "Zakelijk account aanmaken" }:{ className?: string; children?: ReactNode }) {
  const router = useRouter();
  async function go() {
    await fetch("/api/auth/logout", { method: "POST" });
    router.replace("/welkom?type=zakelijk&next=/partner");
    router.refresh();
  }
  return (
    <button type="button" className={className || "btn pri"} onClick={go}>
      {children}
    </button>
  );
}
