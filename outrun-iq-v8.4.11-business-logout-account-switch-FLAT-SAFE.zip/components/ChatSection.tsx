"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

type Msg = { from: "buyer" | "partner"; text: string; at: string };

export function ChatSection({ orderId, messages, me, dark, inset }:{
  orderId: string; messages: Msg[]; me: "buyer" | "partner"; dark?: boolean; inset?: boolean;
}) {
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const router = useRouter();

  async function send() {
    if (!text.trim()) return;
    setBusy(true);
    await fetch(`/api/orders/${orderId}/chat`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text: text.trim() }),
    });
    setText(""); setBusy(false);
    router.refresh();
  }
  const fmt = (iso: string) => new Date(iso).toLocaleString("nl-NL", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });

  return (
    <div style={inset ? { margin: "0 16px" } : undefined}>
      <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 10 }}>
        {messages.length === 0 && (
          <p className="note" style={{ margin: 0, color: dark ? "#5F6873" : undefined }}>Nog geen berichten — stel gerust een vraag over levering of het product.</p>
        )}
        {messages.slice(-30).map((m, i) => {
          const mine = m.from === me;
          return (
            <div key={i} style={{
              alignSelf: mine ? "flex-end" : "flex-start", maxWidth: "82%",
              background: mine ? "var(--petrol)" : dark ? "#1A222B" : "var(--card)",
              color: mine ? "#fff" : dark ? "#E7ECF0" : "var(--txt)",
              border: mine ? "none" : `1px solid ${dark ? "#2A3540" : "var(--line)"}`,
              borderRadius: 14, padding: "9px 13px", fontSize: 13.5, lineHeight: 1.45,
            }}>
              {m.text}
              <div style={{ fontSize: 9.5, opacity: .65, marginTop: 3, fontFamily: "var(--mono)" }}>{fmt(m.at)}</div>
            </div>
          );
        })}
      </div>
      <div style={{ display: "flex", gap: 8 }}>
        <input
          value={text} onChange={e => setText(e.target.value)} maxLength={500}
          onKeyDown={e => e.key === "Enter" && send()} placeholder="Typ een bericht…"
          style={{ flex: 1, border: `1px solid ${dark ? "#2A3540" : "var(--line)"}`, borderRadius: 13, padding: "11px 14px", font: "inherit", fontSize: 13.5, background: dark ? "none" : "var(--card)", outline: "none", color: dark ? "#fff" : "var(--txt)" }}
        />
        <button className="btn pri" style={{ flex: "none", padding: "0 18px", border: 0 }} disabled={busy || !text.trim()} onClick={send}>→</button>
      </div>
    </div>
  );
}
