"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export function Stars({ n, size = 13 }: { n: number; size?: number }) {
  return (
    <span aria-label={`${n} van 5 sterren`} style={{ display: "inline-flex", gap: 1 }}>
      {[1, 2, 3, 4, 5].map(i => (
        <svg key={i} width={size} height={size} viewBox="0 0 24 24"
          fill={i <= Math.round(n) ? "var(--amber)" : "none"}
          stroke={i <= Math.round(n) ? "var(--amber-deep)" : "var(--line)"} strokeWidth="1.6">
          <path d="M12 3l2.7 5.6 6.1.8-4.5 4.2 1.1 6-5.4-3-5.4 3 1.1-6L3.2 9.4l6.1-.8z" />
        </svg>
      ))}
    </span>
  );
}

export function ReviewForm({ orderId }: { orderId: string }) {
  const [rating, setRating] = useState(0);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const router = useRouter();

  async function submit() {
    setBusy(true); setErr("");
    const r = await fetch(`/api/orders/${orderId}/review`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ rating, text: text || undefined }),
    });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (r.ok) router.refresh();
    else setErr(j.error || "Plaatsen mislukt");
  }
  return (
    <div className="authcard" style={{ margin: "12px 16px 0", padding: 16 }}>
      <div className="slabel" style={{ margin: "0 0 8px" }}>BEOORDEEL JE AANKOOP</div>
      <div style={{ display: "flex", gap: 4 }}>
        {[1, 2, 3, 4, 5].map(i => (
          <button key={i} onClick={() => setRating(i)} aria-label={`${i} sterren`}
            style={{ background: "none", border: 0, cursor: "pointer", padding: 2 }}>
            <svg width={30} height={30} viewBox="0 0 24 24"
              fill={i <= rating ? "var(--amber)" : "none"}
              stroke={i <= rating ? "var(--amber-deep)" : "var(--line)"} strokeWidth="1.6">
              <path d="M12 3l2.7 5.6 6.1.8-4.5 4.2 1.1 6-5.4-3-5.4 3 1.1-6L3.2 9.4l6.1-.8z" />
            </svg>
          </button>
        ))}
      </div>
      <textarea rows={3} value={text} onChange={e => setText(e.target.value)} maxLength={600}
        placeholder="Optioneel: hoe beviel het product en de levering?"
        style={{ width: "100%", marginTop: 10, border: "1px solid var(--line)", borderRadius: 13, padding: "12px 14px", font: "inherit", fontSize: 13.5, background: "var(--card)", outline: "none", resize: "vertical", color: "var(--txt)" }} />
      {err && <p className="note" style={{ color: "var(--amber-deep)", margin: "8px 0 0" }}>{err}</p>}
      <button className="btn pri" style={{ width: "100%", marginTop: 10 }} disabled={busy || rating === 0} onClick={submit}>
        {busy ? "Bezig…" : "Plaats review (geverifieerde aankoop)"}
      </button>
    </div>
  );
}

export function ReviewReply({ reviewId }: { reviewId: string }) {
  const [open, setOpen] = useState(false);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const router = useRouter();
  async function submit() {
    setBusy(true); setErr("");
    const r = await fetch("/api/partner/reviews", {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ reviewId, text }),
    });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (r.ok) { setOpen(false); router.refresh(); }
    else setErr(j.error || "Mislukt");
  }
  const btn: React.CSSProperties = {
    fontFamily: "var(--mono)", fontSize: 9.5, fontWeight: 600, letterSpacing: .8,
    background: "none", border: "1px solid #2A3540", borderRadius: 9, padding: "6px 10px",
    color: "var(--petrol-glow)", cursor: "pointer",
  };
  if (!open) return <button style={btn} onClick={() => setOpen(true)}>REAGEER →</button>;
  return (
    <span style={{ display: "flex", flexDirection: "column", gap: 6, width: "100%" }}>
      <textarea rows={2} value={text} onChange={e => setText(e.target.value)} maxLength={400}
        placeholder="Publieke reactie namens je bedrijf…"
        style={{ width: "100%", background: "none", border: "1px solid #2A3540", borderRadius: 10, padding: "9px 11px", color: "#fff", font: "inherit", fontSize: 12.5, resize: "vertical" }} />
      <span style={{ display: "flex", gap: 8 }}>
        <button style={{ ...btn, color: "#4CBE8B" }} disabled={busy || text.trim().length < 5} onClick={submit}>PLAATS</button>
        <button style={{ ...btn, color: "#8B96A0" }} onClick={() => setOpen(false)}>ANNULEER</button>
      </span>
      {err && <span style={{ fontSize: 10.5, color: "var(--amber)" }}>{err}</span>}
    </span>
  );
}
