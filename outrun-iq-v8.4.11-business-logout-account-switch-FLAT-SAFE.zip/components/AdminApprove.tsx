"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export function AdminApprove({ userId, label }: { userId: string; label: string }) {
  const [pin, setPin] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const router = useRouter();
  async function act(approve: boolean) {
    setBusy(true); setErr("");
    const r = await fetch("/api/admin/approve", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId, approve, pin }),
    });
    setBusy(false);
    if (r.ok) router.refresh();
    else setErr((await r.json().catch(() => ({}))).error || "Mislukt");
  }
  return (
    <div className="scan" style={{ marginTop: 12 }}>
      <div className="r" style={{ display: "block" }}>{label}</div>
      <div className="r" style={{ gap: 8 }}>
        <input type="password" value={pin} onChange={e => setPin(e.target.value)} placeholder="ADMIN_PIN"
          style={{ flex: 1, background: "none", border: "1px solid #2A3540", borderRadius: 9, padding: "8px 10px", color: "#fff", font: "inherit", fontSize: 12 }} />
        <button className="go" style={{ color: "#4CBE8B", fontFamily: "var(--mono)", fontSize: 10 }} disabled={busy || !pin} onClick={() => act(true)}>KEUR GOED →</button>
        <button className="go" style={{ color: "var(--amber)", fontFamily: "var(--mono)", fontSize: 10 }} disabled={busy || !pin} onClick={() => act(false)}>WIJS AF</button>
      </div>
      {err && <div className="r" style={{ color: "var(--amber)" }}>{err}</div>}
    </div>
  );
}
