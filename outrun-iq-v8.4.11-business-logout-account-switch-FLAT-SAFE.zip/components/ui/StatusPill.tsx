import type { ReactNode } from "react";

export function StatusPill({ children, tone = "neutral" }:{ children: ReactNode; tone?: "neutral" | "ok" | "warn" | "dark" }) {
  return <span className={`uiPill ${tone}`}>{children}</span>;
}
