import type { ReactNode } from "react";

export function SectionHeader({ title, action, eyebrow }:{ title: ReactNode; action?: ReactNode; eyebrow?: ReactNode }) {
  return (
    <div className="uiSectionHeader">
      <span>{eyebrow}</span>
      <h2>{title}</h2>
      {action && <div>{action}</div>}
    </div>
  );
}
