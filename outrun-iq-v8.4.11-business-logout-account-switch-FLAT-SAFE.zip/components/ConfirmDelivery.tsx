"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export function ConfirmDelivery({ orderId }: { orderId: string }) {
  const [busy, setBusy] = useState(false);
  const router = useRouter();
  async function go() {
    setBusy(true);
    await fetch(`/api/orders/${orderId}/confirm`, { method: "POST" });
    router.refresh();
    setBusy(false);
  }
  return (
    <div className="foot">
      <button className="btn pri" style={{ width: "100%" }} onClick={go} disabled={busy}>
        {busy ? "Bezig…" : "Bevestig ontvangst — geef uitbetaling vrij"}
      </button>
    </div>
  );
}
