"use client";
import { useRef, useState } from "react";
import Link from "next/link";
import { Img } from "./Img";
import { eur } from "@/lib/types";
import type { DiscoveryCard } from "@/lib/ai/brain";

export function DiscoveryCarousel({ cards }: { cards: DiscoveryCard[] }) {
  const [i, setI] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  function onScroll() {
    const el = ref.current;
    if (!el) return;
    setI(Math.round(el.scrollLeft / el.clientWidth));
  }
  if (!cards.length) return null;
  return (
    <section className="discoveryBlock">
      <div className="v2SectionHead discoveryHead"><h2>Ontdek vandaag</h2><span>{i + 1} / {cards.length} AI MIX</span></div>
      <div ref={ref} onScroll={onScroll} className="discoveryCarousel">
        {cards.map(card => (
          <Link key={card.id} href={card.href} className={`discoveryCard ${card.style} ${card.promoted ? "isPromoted" : ""}`}>
            <span className="discoveryShade" />
            {card.image && <Img src={card.image} fallback={card.fallback ?? "tv"} />}
            {!card.image && <span className="discoveryPattern" />}
            <span className="discoveryContent">
              <span className="discoveryMeta"><b>{card.badge ?? "Outrun AI"}</b>{card.promoted && <em>Promote</em>}</span>
              <strong>{card.title}</strong>
              <small>{card.subtitle}</small>
              <span className="discoveryCta">{card.cta} →</span>
            </span>
            {card.productImages?.length ? <span className="discoveryProducts">
              {card.productImages.slice(0, 4).map((p, idx) => <span key={idx}><Img src={p.src} fallback={p.fallback} /></span>)}
            </span> : null}
            {card.price !== undefined && <span className="discoveryPrice"><b>{eur(card.price)}</b>{card.discount !== undefined && <em>−{card.discount}%</em>}</span>}
          </Link>
        ))}
      </div>
      {cards.length > 1 && <span className="discoveryDots">{cards.map((_, j) => <i key={j} className={j === i ? "on" : ""} />)}</span>}
    </section>
  );
}
