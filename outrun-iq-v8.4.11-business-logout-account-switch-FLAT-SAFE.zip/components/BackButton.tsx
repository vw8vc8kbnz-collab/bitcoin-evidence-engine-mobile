"use client";
import { useRouter } from "next/navigation";

export function BackButton() {
  const router = useRouter();
  return (
    <button
      className="back" style={{ background: "none", border: 0, font: "inherit", cursor: "pointer", padding: 0 }}
      onClick={() => (window.history.length > 1 ? router.back() : router.push("/"))}
    >
      <svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7" /></svg>Terug
    </button>
  );
}
