"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

type R = { reason: string; at: string; deadlineAt: string; status: string; instructions?: string };

export function ReturnSection({ orderId, ret, withinWindow, supportEmail, supportPhone, returnsInfo }:{
  orderId: string; ret?: R; withinWindow: boolean;
  supportEmail?: string; supportPhone?: string; returnsInfo?: string;
}) {
  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const router = useRouter();

  async function post(body: object) {
    setBusy(true); setErr("");
    const r = await fetch(`/api/orders/${orderId}/return`, {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
    });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (r.ok) { setOpen(false); router.refresh(); }
    else setErr(j.error || "Mislukt");
  }

  const fmtDay = (iso: string) => new Date(iso).toLocaleDateString("nl-NL", { weekday: "short", day: "numeric", month: "short" });

  if (!ret) {
    if (!withinWindow) return null;
    return (
      <>
        <div className="slabel">RETOUR</div>
        {!open ? (
          <button className="btn sec" style={{ width: "calc(100% - 32px)", margin: "10px 16px 0", display: "block" }} onClick={() => setOpen(true)}>
            Retour aanvragen (binnen 14 dagen)
          </button>
        ) : (
          <div className="authcard" style={{ margin: "0 16px", padding: 16 }}>
            <label className="alabel" style={{ marginTop: 0 }}>WAAROM WIL JE RETOURNEREN?</label>
            <textarea rows={3} value={reason} onChange={e => setReason(e.target.value)}
              placeholder="Bijv.: past niet in de nis, wijkt af van verwachting…"
              style={{ width: "100%", border: "1px solid var(--line)", borderRadius: 13, padding: "12px 14px", font: "inherit", fontSize: 13.5, background: "var(--card)", outline: "none", resize: "vertical", color: "var(--txt)" }} />
            {err && <p className="note" style={{ color: "var(--amber-deep)", margin: "8px 0 0" }}>{err}</p>}
            <div style={{ display: "flex", gap: 10, marginTop: 12 }}>
              <button className="btn pri" style={{ flex: 1 }} disabled={busy || reason.trim().length < 10} onClick={() => post({ reason })}>
                {busy ? "Bezig…" : "Vraag retour aan"}
              </button>
              <button className="btn sec" style={{ flex: "none", padding: "0 18px" }} onClick={() => setOpen(false)}>Annuleer</button>
            </div>
            <p className="note" style={{ margin: "10px 0 0" }}>Retouren lopen via de partner (jouw verkoper), conform de Retourvoorwaarden. De partner reageert binnen 3 dagen met instructies.</p>
          </div>
        )}
      </>
    );
  }

  return (
    <>
      <div className="slabel">RETOUR · {ret.status === "completed" ? "AFGEROND" : ret.status === "escalated" ? "BIJ OUTRUN IQ" : ret.status === "responded" ? "IN BEHANDELING" : "AANGEVRAAGD"}</div>
      <div className="group">
        <div className="li"><b>Je aanvraag<small>{ret.reason}</small></b></div>
        {ret.status === "requested" && (
          <div className="li"><b>Partner reageert vóór {fmtDay(ret.deadlineAt)}<small>daarna kun je escaleren naar Outrun IQ</small></b></div>
        )}
        {ret.instructions && (
          <div className="li"><b>Retourinstructies van de partner<small>{ret.instructions}</small></b></div>
        )}
        {(supportEmail || supportPhone) && (
          <div className="li"><b>Klantenservice partner<small>{supportEmail}{supportPhone ? ` · ${supportPhone}` : ""}{returnsInfo ? ` · ${returnsInfo}` : ""}</small></b></div>
        )}
      </div>
      {ret.status === "requested" && Date.now() > +new Date(ret.deadlineAt) && (
        <button className="btn pri" style={{ width: "calc(100% - 32px)", margin: "10px 16px 0", display: "block" }} disabled={busy} onClick={() => post({ action: "escalate" })}>
          {busy ? "Bezig…" : "Geen reactie — escaleer naar Outrun IQ"}
        </button>
      )}
      {ret.status === "completed" && <p className="note">Retour afgerond. Terugbetaling verloopt via de partner conform de Retourvoorwaarden (testmodus: gesimuleerd).</p>}
      {err && <p className="note" style={{ color: "var(--amber-deep)" }}>{err}</p>}
    </>
  );
}
