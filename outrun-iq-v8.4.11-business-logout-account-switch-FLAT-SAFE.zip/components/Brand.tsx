import Link from "next/link";

export function BrandLockup({ href = "/", variant = "paper", className = "" }:{ href?: string; variant?: "paper" | "ink" | "mark"; className?: string }) {
  const src = variant === "mark" ? "/brand/mark_dark.png" : variant === "ink" ? "/brand/lockup_on_ink.png" : "/brand/lockup_on_paper.png";
  const img = <img src={src} alt="Outrun IQ" className={`brandLockupImg ${variant === "mark" ? "markOnly" : ""}`} />;
  if (!href) return <span className={`brandLockup ${className}`}>{img}</span>;
  return <Link href={href} className={`brandLockup ${className}`}>{img}</Link>;
}
