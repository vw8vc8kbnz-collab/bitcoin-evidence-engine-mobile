"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export function AdminTrust({ slug, trusted }: { slug: string; trusted?: boolean }) {
  const [pin, setPin] = useState("");
  const [busy, setBusy] = useState(false);
  const router = useRouter();
  async function toggle() {
    setBusy(true);
    await fetch("/api/admin/trust", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ pin, slug, trusted: !trusted }),
    });
    setBusy(false);
    router.refresh();
  }
  return (
    <span style={{ display: "inline-flex", gap: 6, alignItems: "center" }}>
      <input type="password" value={pin} onChange={e => setPin(e.target.value)} placeholder="PIN"
        style={{ width: 64, background: "none", border: "1px solid #2A3540", borderRadius: 8, padding: "5px 8px", color: "#fff", font: "inherit", fontSize: 11 }} />
      <button className="go" disabled={busy || !pin} onClick={toggle}
        style={{ fontFamily: "var(--mono)", fontSize: 9.5, color: trusted ? "#4CBE8B" : "var(--amber)" }}>
        {trusted ? "✓ VERTROUWD (7D) — ZET TERUG" : "NIEUW (14D) — MARKEER VERTROUWD"}
      </button>
    </span>
  );
}
