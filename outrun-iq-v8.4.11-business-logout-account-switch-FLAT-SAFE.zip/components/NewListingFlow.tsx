"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { eur } from "@/lib/types";
import type { PriceAdvice } from "@/lib/ai";

type Cat = "witgoed" | "meubels" | "keukens" | "tuin" | "overig";
const CATS: { v: Cat; label: string }[] = [
  { v: "witgoed", label: "Witgoed" }, { v: "meubels", label: "Meubels" },
  { v: "keukens", label: "Keukens" }, { v: "tuin", label: "Tuin" }, { v: "overig", label: "Overig" },
];

const inputStyle: React.CSSProperties = {
  border: 0, background: "none", font: "inherit", width: "100%", outline: "none", color: "#fff",
};

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="dli" style={{ cursor: "default" }}>
      <b style={{ flex: "none", width: 108, fontSize: 11 }}>{label}</b>
      <span style={{ flex: 1 }}>{children}</span>
    </div>
  );
}

export function NewListingFlow() {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  // stap 1
  const [photos, setPhotos] = useState<string[]>([]);
  const [vision, setVision] = useState<"idle" | "busy" | "done" | "failed">("idle");
  const [visionNote, setVisionNote] = useState("");
  // stap 2
  const [f, setF] = useState({
    title: "", brand: "", partnerRef: "", category: "witgoed" as Cat, condition: "", conditionScore: 8,
    defect: "", newPrice: "", stock: "1", delivery: "Bezorging in overleg", deliveryPrice: "0",
  });
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
    setF({ ...f, [k]: e.target.value });
  // stap 3
  const [advice, setAdvice] = useState<PriceAdvice | null>(null);
  const [choice, setChoice] = useState<"fast" | "outlet" | "premium">("outlet");
  const [ownPrice, setOwnPrice] = useState("");

  async function upload(files: FileList | null) {
    if (!files?.length) return;
    setBusy(true); setErr("");
    const fd = new FormData();
    Array.from(files).slice(0, 8).forEach(x => fd.append("photos", x));
    const r = await fetch("/api/partner/upload", { method: "POST", body: fd });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (r.ok) {
      const next = [...photos, ...j.urls].slice(0, 8);
      setPhotos(next);
      if (vision === "idle" && next[0]) recognize(next[0]);
    } else setErr(j.error || "Upload mislukt");
  }

  /** AI vult velden vooraf in — nooit over eigen invoer heen. */
  async function recognize(photoUrl: string) {
    setVision("busy"); setVisionNote("");
    const r = await fetch("/api/partner/vision", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ photoUrl }),
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) { setVision("failed"); setVisionNote(j.error || "AI-herkenning mislukt — vul de velden zelf in."); return; }
    setF(prev => ({
      ...prev,
      title: prev.title || j.title || "",
      brand: prev.brand || j.brand || "",
      category: (prev.title || prev.brand) ? prev.category : (j.category ?? prev.category),
      condition: prev.condition || j.condition || "",
      conditionScore: prev.condition ? prev.conditionScore : (j.conditionScore ?? prev.conditionScore),
      defect: prev.defect || j.defect || "",
      newPrice: prev.newPrice || (j.newPriceEstimate > 0 ? String(j.newPriceEstimate) : ""),
    }));
    setVision("done");
    setVisionNote(`AI heeft de velden ingevuld o.b.v. je foto${j.newPriceEstimate > 0 ? " (nieuwprijs is een schatting)" : ""} — controleer en pas aan.`);
  }

  const step2ok = f.title && f.newPrice && Number(f.newPrice) > 0;

  async function runAi() {
    setBusy(true); setErr(""); setAdvice(null); setStep(3);
    const r = await fetch("/api/partner/pricing", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        title: f.title, brand: f.brand, category: f.category, condition: f.condition,
        conditionScore: Number(f.conditionScore), newPrice: Number(f.newPrice),
        stock: Number(f.stock), photosCount: photos.length, defect: f.defect || undefined,
      }),
    });
    const j = await r.json().catch(() => null);
    setBusy(false);
    if (r.ok && j?.outlet) setAdvice(j);
    else { setErr(j?.error || "Prijsadvies mislukt"); setStep(2); }
  }

  async function publish() {
    if (!advice) return;
    const price = ownPrice ? Math.round(Number(ownPrice)) : advice[choice];
    setBusy(true); setErr("");
    const r = await fetch("/api/partner/listings", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...f, conditionScore: Number(f.conditionScore), newPrice: Number(f.newPrice),
        stock: Number(f.stock), deliveryPrice: Number(f.deliveryPrice),
        perUnit: Number(f.stock) > 1, photos,
        price, fast: advice.fast, premium: advice.premium,
        expectedDays: choice === "fast" ? advice.expectedDaysFast : choice === "premium" ? advice.expectedDaysPremium : advice.expectedDaysOutlet,
        confidence: advice.confidence, comps: advice.comps, aiSource: advice.source,
      }),
    });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (r.ok && j.id) { router.push("/partner/voorraad"); router.refresh(); }
    else setErr(j.error || "Publiceren mislukt");
  }

  const chosen = advice ? (ownPrice ? Math.round(Number(ownPrice)) : advice[choice]) : 0;

  return (
    <>
      <div className="dots">{[1, 2, 3, 4].map(i => <i key={i} className={step >= i ? "on" : ""} />)}</div>

      {step === 1 && (
        <>
          <div className="upl">
            <div className="thumbs">
              {photos.map(u => (
                <span key={u} className="imw dk">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={u} alt="" />
                </span>
              ))}
              <label className="add" style={{ cursor: "pointer" }}>+
                <input type="file" accept="image/*" multiple hidden onChange={e => upload(e.target.files)} />
              </label>
            </div>
            <p>{photos.length === 0 ? "Voorkant · zijkant · verpakking · schade close-up" : `${photos.length} foto's — voeg gerust meer toe`}</p>
          </div>
          {vision === "busy" && (
            <div className="scan"><div className="r">AI herkent je product <span>analyseren…</span></div></div>
          )}
          {vision === "done" && (
            <div className="scan"><div className="r">AI-herkenning <span className="done">klaar — stap 2 is ingevuld</span></div></div>
          )}
          {vision === "failed" && visionNote && (
            <p className="note" style={{ color: "var(--amber)" }}>{visionNote}{" "}
              {photos[0] && <button className="alink" style={{ color: "var(--petrol-glow)" }} onClick={() => recognize(photos[0])}>Herken opnieuw →</button>}
            </p>
          )}
          <p className="note">Foto's mogen ook later; zonder foto toont de app een nette illustratie.</p>
          <div className="foot"><button className="btn pri" style={{ width: "100%" }} onClick={() => setStep(2)} disabled={busy}>
            {busy ? "Uploaden…" : vision === "busy" ? "AI herkent je product…" : "Verder — productgegevens"}</button></div>
        </>
      )}

      {step === 2 && (
        <>
          {vision === "done" && visionNote && (
            <p className="note" style={{ margin: "0 4px 10px", color: "var(--petrol-glow)" }}>✦ {visionNote}</p>
          )}
          <div className="dgroup">
            <Field label="Titel"><input style={inputStyle} value={f.title} onChange={set("title")} placeholder="Bosch Serie 6 wasmachine 9kg" /></Field>
            <Field label="Merk"><input style={inputStyle} value={f.brand} onChange={set("brand")} placeholder="Bosch" /></Field>
            <Field label="Ref / SKU"><input style={inputStyle} value={f.partnerRef} onChange={set("partnerRef")} placeholder="optioneel — bv. MAG-A12-0433" /></Field>
            <Field label="Categorie">
              <select style={{ ...inputStyle, appearance: "none" }} value={f.category} onChange={set("category")}>
                {CATS.map(c => <option key={c.v} value={c.v} style={{ color: "#000" }}>{c.label}</option>)}
              </select>
            </Field>
            <Field label="Conditie"><input style={inputStyle} value={f.condition} onChange={set("condition")} placeholder="Retour, ongebruikt · doos beschadigd" /></Field>
            <Field label="Score /10"><input style={inputStyle} type="number" min={1} max={10} value={f.conditionScore} onChange={set("conditionScore")} /></Field>
            <Field label="Gebrek"><input style={inputStyle} value={f.defect} onChange={set("defect")} placeholder="optioneel — bv. kras zijkant, foto 3" /></Field>
            <Field label="Nieuwprijs €"><input style={inputStyle} type="number" min={1} value={f.newPrice} onChange={set("newPrice")} placeholder="899" /></Field>
            <Field label="Voorraad"><input style={inputStyle} type="number" min={1} value={f.stock} onChange={set("stock")} /></Field>
            <Field label="Levering"><input style={inputStyle} value={f.delivery} onChange={set("delivery")} /></Field>
            <Field label="Bezorgkosten €"><input style={inputStyle} type="number" min={0} value={f.deliveryPrice} onChange={set("deliveryPrice")} /></Field>
          </div>
          {err && <p className="note" style={{ color: "var(--amber)" }}>{err}</p>}
          <div className="foot"><button className="btn pri" style={{ width: "100%" }} onClick={runAi} disabled={!step2ok || busy}>
            Start AI-prijsanalyse</button></div>
        </>
      )}

      {step === 3 && (
        <>
          <div className="scan">
            <div className="r">Productherkenning <span className={advice ? "done" : ""}>{advice ? (f.brand || f.title.split(" ")[0]) : "analyseren…"}</span></div>
            <div className="r">Conditieweging <span className={advice ? "done" : ""}>{advice ? `${f.conditionScore}/10` : "…"}</span></div>
            <div className="r">Prijsanalyse <span className={advice ? "done" : ""}>{advice ? (advice.comps > 0 ? `${advice.comps} prijspunten` : "modelkennis") : "…"}</span></div>
            <div className="r">Confidence <span className={advice ? "done" : ""}>{advice ? `${advice.confidence}/100` : "…"}</span></div>
          </div>
          {advice && (
            <>
              <p className="note">{advice.reasoning} <span className="mono" style={{ color: advice.source === "deepseek" ? "var(--petrol-glow)" : "var(--amber)" }}>[{advice.source.toUpperCase()}]</span></p>
              <div className="dsec"><h2>Kies je strategie</h2></div>
              <div className="pk3">
                {(["fast", "outlet", "premium"] as const).map(k => (
                  <button key={k} className={`pk${choice === k && !ownPrice ? " on" : ""}`} onClick={() => { setChoice(k); setOwnPrice(""); }}>
                    <label>{k.toUpperCase()}</label><b>{eur(advice[k])}</b>
                    <span>± {k === "fast" ? advice.expectedDaysFast : k === "premium" ? advice.expectedDaysPremium : advice.expectedDaysOutlet} dagen</span>
                  </button>
                ))}
              </div>
              <div className="slabel" style={{ color: "#5F6873" }}>OF ZELF</div>
              <div className="dgroup"><Field label="Eigen prijs €"><input style={inputStyle} type="number" min={1} value={ownPrice} onChange={e => setOwnPrice(e.target.value)} placeholder={String(advice.outlet)} /></Field></div>
              <div className="foot"><button className="btn pri" style={{ width: "100%" }} onClick={() => setStep(4)} disabled={!chosen || chosen <= 0 || chosen >= Number(f.newPrice)}>
                Verder — controleren</button></div>
            </>
          )}
          {!advice && !err && <p className="note">De AI analyseert je product…</p>}
          {err && <p className="note" style={{ color: "var(--amber)" }}>{err}</p>}
        </>
      )}

      {step === 4 && advice && (
        <>
          <div className="scan">
            <div className="r">{f.title} <span className="done">{eur(chosen)}{Number(f.stock) > 1 ? "/st" : ""}</span></div>
            <div className="r">Nieuwprijs <span className="done">{eur(Number(f.newPrice))}</span></div>
            <div className="r">Voorraad <span className="done">{f.stock} stuks</span></div>
            <div className="r">Levering <span className="done">{f.delivery} · {eur(Number(f.deliveryPrice))}</span></div>
          </div>
          <p className="note">Kopers zien het prijsbewijs (fast → outlet → nieuwprijs) bij je listing. Eerlijkheid verkoopt.</p>
          {err && <p className="note" style={{ color: "var(--amber)" }}>{err}</p>}
          <div className="foot"><button className="btn pri" style={{ width: "100%" }} onClick={publish} disabled={busy}>
            {busy ? "Publiceren…" : `Publiceer listing — ${eur(chosen)}`}</button></div>
        </>
      )}
    </>
  );
}
