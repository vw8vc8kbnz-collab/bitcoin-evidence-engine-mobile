"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export function DeleteAccount() {
  const [open, setOpen] = useState(false);
  const [pass, setPass] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const router = useRouter();

  async function del() {
    setBusy(true); setErr("");
    const r = await fetch("/api/auth/delete-account", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ password: pass }),
    });
    const j = await r.json().catch(() => ({}));
    if (r.ok) { router.replace("/welkom"); router.refresh(); return; }
    setBusy(false);
    setErr(j.error || "Verwijderen mislukt");
  }
  if (!open) {
    return (
      <button className="li" style={{ width: "100%", background: "none", border: 0, font: "inherit", cursor: "pointer", textAlign: "left" }} onClick={() => setOpen(true)}>
        <b style={{ color: "var(--amber-deep)" }}>Account verwijderen</b>
      </button>
    );
  }
  return (
    <div className="li" style={{ display: "block" }}>
      <p style={{ margin: "0 0 10px", fontSize: 12.5, color: "var(--txt2)", lineHeight: 1.5 }}>
        Dit anonimiseert je gegevens definitief (AVG). Ordergeschiedenis blijft bewaard voor de wettelijke administratie, maar is niet meer aan je account gekoppeld. Bevestig met je wachtwoord.
      </p>
      <input type="password" value={pass} onChange={e => setPass(e.target.value)} placeholder="Wachtwoord"
        style={{ width: "100%", border: "1px solid var(--line)", borderRadius: 12, padding: "11px 13px", font: "inherit", fontSize: 13.5, background: "var(--card)", outline: "none", color: "var(--txt)" }} />
      {err && <p className="note" style={{ color: "var(--amber-deep)", margin: "8px 0 0" }}>{err}</p>}
      <div style={{ display: "flex", gap: 10, marginTop: 10 }}>
        <button className="btn pri" style={{ flex: 1, background: "var(--amber-deep)" }} disabled={busy || !pass} onClick={del}>
          {busy ? "Bezig…" : "Verwijder definitief"}
        </button>
        <button className="btn sec" style={{ flex: "none", padding: "0 16px" }} onClick={() => setOpen(false)}>Annuleer</button>
      </div>
    </div>
  );
}
