"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

export function SaveButton({ id, initialOn }: { id: string; initialOn?: boolean }) {
  const [on, setOn] = useState(!!initialOn);
  const router = useRouter();
  useEffect(() => { setOn(!!initialOn); }, [initialOn]);
  async function toggle() {
    setOn(v => !v); // optimistisch
    const r = await fetch("/api/me/saved", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ listingId: id }),
    });
    if (r.status === 401) { setOn(false); router.push(`/welkom?next=/listing/${id}`); return; }
    const j = await r.json().catch(() => ({}));
    if (r.ok) setOn(!!j.on);
  }
  return (
    <button
      className="icbtn" aria-pressed={on} aria-label={on ? "Verwijder uit bewaard" : "Bewaar"}
      onClick={toggle}
      style={on ? { background: "var(--amber-soft)", borderColor: "var(--amber)" } : undefined}
    >
      <svg viewBox="0 0 24 24" style={on ? { fill: "var(--amber)", stroke: "var(--amber-deep)" } : undefined}>
        <path d="M6 3h12v18l-6-4-6 4z" />
      </svg>
    </button>
  );
}

/** Eenmalige migratie van oude localStorage-bewaarlijst naar het account. */
export function SavedMigrator() {
  useEffect(() => {
    try {
      const old = JSON.parse(localStorage.getItem("oiq_saved") || "[]");
      if (Array.isArray(old) && old.length) {
        fetch("/api/me/saved", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ listingIds: old }),
        }).then(r => { if (r.ok) localStorage.removeItem("oiq_saved"); });
      }
    } catch {}
  }, []);
  return null;
}
