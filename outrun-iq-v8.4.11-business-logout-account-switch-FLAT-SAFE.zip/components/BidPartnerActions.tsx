"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export function BidPartnerActions({ bidId, amount, price }:{ bidId: string; amount: number; price: number }) {
  const [counter, setCounter] = useState("");
  const [mode, setMode] = useState<"idle" | "counter">("idle");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const router = useRouter();

  async function act(action: "accept" | "reject" | "counter") {
    setBusy(true); setErr("");
    const r = await fetch("/api/partner/bids", {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ bidId, action, counterAmount: action === "counter" ? Number(counter) : undefined }),
    });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (r.ok) { setMode("idle"); router.refresh(); }
    else setErr(j.error || "Mislukt");
  }
  const btn: React.CSSProperties = {
    fontFamily: "var(--mono)", fontSize: 9.5, fontWeight: 600, letterSpacing: .8,
    background: "none", border: "1px solid #2A3540", borderRadius: 9, padding: "7px 11px", cursor: "pointer",
  };
  return (
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center", margin: "8px 16px 14px" }}>
      {mode === "idle" ? (
        <>
          <button style={{ ...btn, color: "#4CBE8B" }} disabled={busy} onClick={() => act("accept")}>ACCEPTEER €{amount}</button>
          <button style={{ ...btn, color: "var(--petrol-glow)" }} disabled={busy} onClick={() => setMode("counter")}>TEGENBOD</button>
          <button style={{ ...btn, color: "#8B96A0" }} disabled={busy} onClick={() => act("reject")}>WIJS AF</button>
        </>
      ) : (
        <>
          <input type="number" min={amount + 1} max={price - 1} value={counter} onChange={e => setCounter(e.target.value)}
            placeholder={`${amount + 1}–${price - 1}`} autoFocus
            style={{ ...btn, width: 110, color: "#fff", cursor: "text" }} />
          <button style={{ ...btn, color: "#4CBE8B" }} disabled={busy || !(Number(counter) > amount)} onClick={() => act("counter")}>VERSTUUR</button>
          <button style={{ ...btn, color: "#8B96A0" }} onClick={() => setMode("idle")}>ANNULEER</button>
        </>
      )}
      {err && <span style={{ fontSize: 10.5, color: "var(--amber)" }}>{err}</span>}
    </div>
  );
}
