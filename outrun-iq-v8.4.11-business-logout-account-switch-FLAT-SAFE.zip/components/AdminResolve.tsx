"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export function AdminResolve({ orderId, label }: { orderId: string; label: string }) {
  const [pin, setPin] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const router = useRouter();
  async function act(action: "release" | "cancel") {
    setBusy(true); setErr("");
    const r = await fetch("/api/admin/resolve", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ orderId, action, pin }),
    });
    setBusy(false);
    if (r.ok) router.refresh();
    else setErr((await r.json().catch(() => ({}))).error || "Mislukt");
  }
  return (
    <div className="scan" style={{ marginTop: 12 }}>
      <div className="r" style={{ display: "block" }}>{label}</div>
      <div className="r" style={{ gap: 8 }}>
        <input type="password" value={pin} onChange={e => setPin(e.target.value)} placeholder="ADMIN_PIN"
          style={{ flex: 1, background: "none", border: "1px solid #2A3540", borderRadius: 9, padding: "8px 10px", color: "#fff", font: "inherit", fontSize: 12 }} />
        <button className="go" style={{ color: "#4CBE8B", fontFamily: "var(--mono)", fontSize: 10 }} disabled={busy || !pin} onClick={() => act("release")}>GEEF VRIJ →</button>
        <button className="go" style={{ color: "var(--amber)", fontFamily: "var(--mono)", fontSize: 10 }} disabled={busy || !pin} onClick={() => act("cancel")}>ANNULEER ORDER</button>
      </div>
      {err && <div className="r" style={{ color: "var(--amber)" }}>{err}</div>}
    </div>
  );
}
