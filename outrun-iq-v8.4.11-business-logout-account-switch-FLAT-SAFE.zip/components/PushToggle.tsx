"use client";
import { useEffect, useState } from "react";

function b64ToUint8(base64: string) {
  const pad = "=".repeat((4 - (base64.length % 4)) % 4);
  const raw = atob((base64 + pad).replace(/-/g, "+").replace(/_/g, "/"));
  return Uint8Array.from([...raw].map(c => c.charCodeAt(0)));
}

export function PushToggle() {
  const [state, setState] = useState<"laden" | "uit" | "aan" | "geblokkeerd" | "niet-beschikbaar" | "server-uit">("laden");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    (async () => {
      if (!("serviceWorker" in navigator) || !("PushManager" in window)) { setState("niet-beschikbaar"); return; }
      const { enabled } = await fetch("/api/push").then(r => r.json()).catch(() => ({ enabled: false }));
      if (!enabled) { setState("server-uit"); return; }
      if (Notification.permission === "denied") { setState("geblokkeerd"); return; }
      const reg = await navigator.serviceWorker.ready;
      const sub = await reg.pushManager.getSubscription();
      setState(sub ? "aan" : "uit");
    })();
  }, []);

  async function toggle() {
    setBusy(true);
    try {
      const reg = await navigator.serviceWorker.ready;
      const existing = await reg.pushManager.getSubscription();
      if (existing) {
        await fetch("/api/push", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ endpoint: existing.endpoint }) });
        await existing.unsubscribe();
        setState("uit");
      } else {
        const perm = await Notification.requestPermission();
        if (perm !== "granted") { setState(perm === "denied" ? "geblokkeerd" : "uit"); setBusy(false); return; }
        const { key } = await fetch("/api/push").then(r => r.json());
        const sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64ToUint8(key) });
        await fetch("/api/push", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ subscription: sub.toJSON() }) });
        setState("aan");
      }
    } catch { setState("niet-beschikbaar"); }
    setBusy(false);
  }

  const sub: Record<string, string> = {
    laden: "status ophalen…",
    uit: "krijg meldingen bij biedingen, orders en chat",
    aan: "actief op dit apparaat",
    geblokkeerd: "geblokkeerd in je systeeminstellingen",
    "niet-beschikbaar": "op iPhone: zet de app eerst op je beginscherm (Safari → Deel)",
    "server-uit": "nog niet geconfigureerd op de server (VAPID-keys)",
  };
  const clickable = state === "aan" || state === "uit";

  return (
    <button className="li" style={{ width: "100%", background: "none", border: 0, font: "inherit", cursor: clickable ? "pointer" : "default", textAlign: "left" }}
      onClick={clickable && !busy ? toggle : undefined}>
      <b>Pushmeldingen<small>{sub[state]}</small></b>
      <span className="val" style={{ color: state === "aan" ? "var(--petrol)" : undefined, fontWeight: 700 }}>
        {busy ? "…" : state === "aan" ? "AAN" : state === "uit" ? "ZET AAN" : ""}
      </span>
    </button>
  );
}
