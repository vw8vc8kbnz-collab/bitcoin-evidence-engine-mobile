"use client";
import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";

type Props = {
  children: React.ReactNode;
  title?: string;
};

// v7.3.6: native-style fullscreen product sheet.
// Open bijna fullscreen, content scrollt intern en omlaag slepen sluit de sheet.
const OPEN = 0.965;

export function BottomSheet({ children, title = "Product" }: Props) {
  const router = useRouter();
  const [h, setH] = useState(0);
  const [drag, setDrag] = useState(false);
  const start = useRef({ y: 0, h: OPEN });

  useEffect(() => {
    const t = requestAnimationFrame(() => setH(OPEN));
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const esc = (e: KeyboardEvent) => e.key === "Escape" && router.back();
    window.addEventListener("keydown", esc);
    return () => {
      cancelAnimationFrame(t);
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", esc);
    };
  }, [router]);

  function close() { router.back(); }

  function down(e: React.PointerEvent) {
    setDrag(true);
    start.current = { y: e.clientY, h };
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
  }

  function move(e: React.PointerEvent) {
    if (!drag) return;
    const delta = e.clientY - start.current.y;
    const next = start.current.h - delta / window.innerHeight;
    setH(Math.min(OPEN, Math.max(0.45, next)));
  }

  function up(e: React.PointerEvent) {
    if (!drag) return;
    setDrag(false);
    const dy = e.clientY - start.current.y;
    if (dy > 115 || h < 0.82) { close(); return; }
    setH(OPEN);
  }

  return (
    <>
      <div className="scrim nativeScrim" onClick={close} />
      <div
        className="sheet nativeSheet"
        style={{ height: `${h * 100}dvh`, transition: drag ? "none" : "height .28s cubic-bezier(.32,.72,.28,1)" }}
        role="dialog" aria-modal="true"
      >
        <div className="sheetTopbar">
          <button type="button" onClick={close} aria-label="Terug">← <span>Terug</span></button>
          <strong>{title}</strong>
          <button type="button" onClick={close} aria-label="Sluiten">×</button>
        </div>
        <div className="sgrab nativeGrab" onPointerDown={down} onPointerMove={move} onPointerUp={up} onPointerCancel={up}>
          <i />
        </div>
        <div className="sbody nativeBody">{children}</div>
      </div>
    </>
  );
}
