import Link from "next/link";
import { Mark } from "./icons";

export function Empty({ title, text, cta, href }:{
  title: string; text: string; cta?: string; href?: string;
}) {
  return (
    <div style={{ textAlign: "center", padding: "56px 32px" }}>
      <div style={{ opacity: .5, display: "inline-block" }}><Mark size={44} /></div>
      <h2 style={{ fontSize: 17, fontWeight: 800, margin: "14px 0 6px" }}>{title}</h2>
      <p style={{ fontSize: 12, color: "var(--txt2)", lineHeight: 1.6, maxWidth: 280, margin: "0 auto" }}>{text}</p>
      {cta && href && (
        <Link href={href} className="btn pri" style={{ display: "inline-block", flex: "none", marginTop: 18, padding: "12px 22px" }}>
          {cta}
        </Link>
      )}
    </div>
  );
}
