import type { Listing } from "@/lib/types";

export function EvidenceStrip({ l, light = false, labels = true }:{
  l: Pick<Listing, "fast" | "price" | "newPrice">; light?: boolean; labels?: boolean;
}) {
  const p = Math.min(96, Math.max(4, Math.round((l.price / l.newPrice) * 100)));
  return (
    <div aria-label={`Prijspositie: fast €${l.fast}, outlet €${l.price}, nieuwprijs €${l.newPrice}`}>
      <div className={`ev ${light ? "lt" : ""}`} style={{ ["--p" as string]: `${p}%` }} role="img"><i /><u /></div>
      {labels && <div className="evl"><span>FAST €{l.fast}</span><span>OUTLET</span><span>NIEUW €{l.newPrice}</span></div>}
    </div>
  );
}
