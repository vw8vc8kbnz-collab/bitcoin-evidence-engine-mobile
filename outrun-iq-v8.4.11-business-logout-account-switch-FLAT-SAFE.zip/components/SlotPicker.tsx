"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export function SlotPicker({ orderId, slots }:{ orderId: string; slots: { at: string }[] }) {
  const [busy, setBusy] = useState(false);
  const router = useRouter();
  const fmt = (iso: string) => new Date(iso).toLocaleString("nl-NL", { weekday: "long", day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });

  async function pick(at: string) {
    setBusy(true);
    await fetch(`/api/orders/${orderId}/slot`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ at }),
    });
    setBusy(false);
    router.refresh();
  }
  return (
    <>
      <div className="slabel">KIES JE BEZORGMOMENT</div>
      <div className="radios">
        {slots.map(s => (
          <button key={s.at} className="rad" disabled={busy} onClick={() => pick(s.at)}>
            <span className="o" /><span><b>{fmt(s.at)}</b><span>tik om te bevestigen</span></span>
          </button>
        ))}
      </div>
    </>
  );
}
