def add_features(df):
    import pandas as pd
    d = df.copy()
    d['ret1'] = d['Close'].pct_change()
    d['ma20'] = d['Close'].rolling(20).mean()
    d['ma50'] = d['Close'].rolling(50).mean()
    d['vol20'] = d['Volume'].rolling(20).mean()
    d['relvol'] = d['Volume'] / d['vol20']
    delta = d['Close'].diff()
    gain = delta.clip(lower=0).rolling(14).mean()
    loss = (-delta.clip(upper=0)).rolling(14).mean()
    rs = gain / loss.replace(0, 1e-9)
    d['rsi14'] = 100 - (100 / (1 + rs))
    d['breakout20'] = d['Close'] > d['Close'].rolling(20).max().shift(1)
    d['reclaim50'] = (d['Close'] > d['ma50']) & (d['Close'].shift(1) <= d['ma50'].shift(1))
    d['volume_spike'] = d['relvol'] >= 2.5
    d['oversold_recovery'] = (d['rsi14'] > 35) & (d['rsi14'].shift(1) <= 35)
    return d.dropna().reset_index(drop=True)
