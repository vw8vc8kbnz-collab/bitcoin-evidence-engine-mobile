from stock_evidence_engine.engines.features import add_features
from stock_evidence_engine.engines.setups import SETUPS, HOLDS

FEE_SLIPPAGE = 0.004  # 0.4% round-trip estimate

def backtest_ticker(ticker, df):
    d = add_features(df)
    out = []
    for name, rule in SETUPS.items():
        signal_idxs = [i for i, row in d.iterrows() if rule(row)]
        for hold in HOLDS:
            rets = []
            for i in signal_idxs:
                j = i + hold
                if j >= len(d):
                    continue
                entry = float(d.loc[i, 'Close'])
                exitp = float(d.loc[j, 'Close'])
                rets.append((exitp / entry - 1.0) - FEE_SLIPPAGE)
            if rets:
                wins = [x for x in rets if x > 0]
                out.append({
                    'ticker': ticker.upper(), 'setup': name, 'hold_days': hold,
                    'trades': len(rets), 'winrate': len(wins)/len(rets),
                    'expectancy': sum(rets)/len(rets), 'avg_return': sum(rets)/len(rets),
                    'best_return': max(rets), 'worst_return': min(rets),
                    'max_drawdown': min(rets)
                })
            else:
                out.append({'ticker': ticker.upper(), 'setup': name, 'hold_days': hold, 'trades': 0})
    return out
