SETUPS = {
    'volume_breakout': lambda r: bool(r.get('breakout20')) and bool(r.get('volume_spike')),
    'ma50_reclaim_volume': lambda r: bool(r.get('reclaim50')) and bool(r.get('volume_spike')),
    'oversold_recovery': lambda r: bool(r.get('oversold_recovery')),
    'momentum_continuation': lambda r: bool(r.get('Close') > r.get('ma20') > r.get('ma50')) and float(r.get('relvol',0)) >= 1.5,
}
HOLDS = [1,3,5,10,20]
