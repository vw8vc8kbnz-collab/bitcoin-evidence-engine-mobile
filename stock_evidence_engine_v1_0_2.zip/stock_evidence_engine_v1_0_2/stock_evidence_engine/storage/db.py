import sqlite3
from pathlib import Path
from stock_evidence_engine.config.settings import DB_PATH

def connect():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    init_db(con)
    return con

def init_db(con):
    con.execute('''CREATE TABLE IF NOT EXISTS results (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        ticker TEXT NOT NULL,
        setup TEXT NOT NULL,
        hold_days INTEGER NOT NULL,
        trades INTEGER DEFAULT 0,
        winrate REAL DEFAULT 0,
        expectancy REAL DEFAULT 0,
        avg_return REAL DEFAULT 0,
        best_return REAL DEFAULT 0,
        worst_return REAL DEFAULT 0,
        max_drawdown REAL DEFAULT 0
    )''')
    con.execute('CREATE INDEX IF NOT EXISTS idx_results_created ON results(created_at)')
    con.commit()

def save_results(rows):
    con = connect()
    with con:
        for r in rows:
            con.execute('''INSERT INTO results(ticker,setup,hold_days,trades,winrate,expectancy,avg_return,best_return,worst_return,max_drawdown)
            VALUES(?,?,?,?,?,?,?,?,?,?)''', (
                r.get('ticker'), r.get('setup'), int(r.get('hold_days',0)), int(r.get('trades',0)),
                float(r.get('winrate',0)), float(r.get('expectancy',0)), float(r.get('avg_return',0)),
                float(r.get('best_return',0)), float(r.get('worst_return',0)), float(r.get('max_drawdown',0))
            ))
    con.close()

def latest_results(limit=500):
    con = connect()
    rows = [dict(x) for x in con.execute('SELECT * FROM results ORDER BY created_at DESC, expectancy DESC LIMIT ?', (limit,))]
    con.close()
    return rows
