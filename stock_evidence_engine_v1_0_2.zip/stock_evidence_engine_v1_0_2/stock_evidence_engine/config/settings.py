import os
from pathlib import Path
APP_DIR = Path(os.environ.get('SEE_APP_DIR', '/home/ubuntu/stock_evidence_engine'))
DB_PATH = Path(os.environ.get('SEE_DB_PATH', str(APP_DIR / 'data' / 'see.sqlite')))
