import argparse
from stock_evidence_engine.data.yahoo_client import load_history
from stock_evidence_engine.engines.backtester import backtest_ticker
from stock_evidence_engine.storage.db import save_results, connect

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--tickers', required=True, help='Comma separated tickers, e.g. BB,PLTR,NVDA')
    p.add_argument('--period', default='2y')
    args = p.parse_args()
    connect().close()
    all_rows = []
    for t in [x.strip().upper() for x in args.tickers.split(',') if x.strip()]:
        print(f'[SEE] downloading {t} {args.period}')
        df = load_history(t, args.period)
        if df is None:
            print(f'[SEE] no data for {t}')
            continue
        rows = backtest_ticker(t, df)
        all_rows.extend(rows)
        best = sorted([r for r in rows if r.get('trades',0)>0], key=lambda r: r.get('expectancy',0), reverse=True)[:1]
        if best:
            b=best[0]
            print(f"[SEE] best {t}: {b['setup']} hold={b['hold_days']}d trades={b['trades']} exp={b['expectancy']:.2%}")
    if all_rows:
        save_results(all_rows)
    print(f'[SEE] saved {len(all_rows)} rows')

if __name__ == '__main__':
    main()
