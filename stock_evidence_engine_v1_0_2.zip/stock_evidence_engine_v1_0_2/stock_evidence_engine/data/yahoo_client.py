def load_history(ticker: str, period: str = '2y'):
    import yfinance as yf
    df = yf.download(ticker, period=period, interval='1d', auto_adjust=True, progress=False, threads=False)
    if df is None or df.empty:
        return None
    df = df.reset_index()
    # yfinance sometimes returns multiindex columns
    df.columns = [c[0] if isinstance(c, tuple) else c for c in df.columns]
    return df
