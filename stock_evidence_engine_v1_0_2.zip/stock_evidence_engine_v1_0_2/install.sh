#!/usr/bin/env bash
set -euo pipefail
APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PORT="8798"
cd "$APP_DIR"

echo "[SEE] Installing in $APP_DIR on port $PORT"
python3 --version
rm -rf venv .venv
python3 -m venv venv
venv/bin/python -m pip install --upgrade pip wheel setuptools
venv/bin/python -m pip install -r requirements.txt
mkdir -p data logs
SEE_APP_DIR="$APP_DIR" SEE_DB_PATH="$APP_DIR/data/see.sqlite" venv/bin/python - <<'PY'
from stock_evidence_engine.storage.db import connect
from stock_evidence_engine import __version__
connect().close()
print('[SEE] import/db smoke OK', __version__)
PY
cat > /tmp/stock-evidence-dashboard.service <<SERVICE
[Unit]
Description=Stock Evidence Engine Dashboard
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=$APP_DIR
Environment=PYTHONPATH=$APP_DIR
Environment=SEE_APP_DIR=$APP_DIR
Environment=SEE_DB_PATH=$APP_DIR/data/see.sqlite
ExecStart=$APP_DIR/venv/bin/python $APP_DIR/server.py --host 0.0.0.0 --port $PORT
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
SERVICE
sudo cp /tmp/stock-evidence-dashboard.service /etc/systemd/system/stock-evidence-dashboard.service
sudo systemctl daemon-reload
sudo systemctl enable stock-evidence-dashboard.service
sudo systemctl restart stock-evidence-dashboard.service
sudo ufw allow ${PORT}/tcp || true
sleep 2
sudo systemctl status stock-evidence-dashboard.service --no-pager || true
curl -fsS http://127.0.0.1:${PORT}/health || true
echo ""
echo "[SEE] Installed. Open http://51.195.102.180:${PORT}"
