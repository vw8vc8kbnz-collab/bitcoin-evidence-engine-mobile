# Masterplan

V1.0.1 is a stable foundation: backtest-first, deterministic hypotheses, SQLite storage, stdlib dashboard, systemd on port 8798. Next: add news/catalyst research datasets, then only later live ntfy alerts for validated setups.
