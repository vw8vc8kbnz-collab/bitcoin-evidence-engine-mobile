# Stock Evidence Engine v1.0.2

Fixed VPS package structure:
- dashboard starts via root `server.py`, not missing `stock_evidence_engine.dashboard`
- installer uses the folder it is run from, not a hardcoded path
- one venv: `venv`
- port: 8798
- no FastAPI/uvicorn dependency for dashboard

Install:
```bash
chmod +x install.sh run_backtest.sh
./install.sh
./run_backtest.sh "BB,PLTR,IONQ,SOUN,NVDA,AMD,TSLA" "2y"
```
