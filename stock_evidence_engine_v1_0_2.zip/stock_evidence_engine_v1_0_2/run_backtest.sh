#!/usr/bin/env bash
set -euo pipefail
APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$APP_DIR"
TICKERS="${1:-BB,PLTR,IONQ,SOUN,NVDA,AMD,TSLA}"
PERIOD="${2:-2y}"
SEE_APP_DIR="$APP_DIR" SEE_DB_PATH="$APP_DIR/data/see.sqlite" venv/bin/python -m stock_evidence_engine.cli --tickers "$TICKERS" --period "$PERIOD"
