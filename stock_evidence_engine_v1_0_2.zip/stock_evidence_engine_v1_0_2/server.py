#!/usr/bin/env python3
import argparse, html, json
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse
from stock_evidence_engine import __version__
from stock_evidence_engine.storage.db import latest_results, connect

CSS = """
body{margin:0;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Arial,sans-serif;background:#f6f7fb;color:#101827}.wrap{max-width:1100px;margin:0 auto;padding:28px}.hero{background:linear-gradient(135deg,#0d2b4d,#1f6fab);color:white;border-radius:28px;padding:28px;box-shadow:0 20px 40px #0b1b331f}.eyebrow{letter-spacing:.22em;text-transform:uppercase;color:#d7a64a;font-weight:800;font-size:13px}.title{font-size:42px;line-height:1;margin:10px 0 8px;font-weight:900}.sub{font-size:18px;opacity:.9}.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin:20px 0}.card{background:white;border-radius:22px;padding:22px;box-shadow:0 10px 25px #15213d14;border:1px solid #e8ecf4}.num{font-size:34px;font-weight:900}.muted{color:#647084;font-weight:700}.btn{display:inline-block;margin-top:16px;background:#ffca50;color:#071426;border-radius:18px;padding:14px 20px;text-decoration:none;font-weight:900}.table{width:100%;border-collapse:collapse;background:white;border-radius:20px;overflow:hidden;box-shadow:0 10px 25px #15213d14}th,td{padding:12px 14px;border-bottom:1px solid #eef1f6;text-align:left;font-size:14px}th{background:#101827;color:white}.pos{color:#07833f;font-weight:900}.neg{color:#b91c1c;font-weight:900}@media(max-width:760px){.grid{grid-template-columns:repeat(2,1fr)}.title{font-size:34px}.wrap{padding:18px}th,td{font-size:12px;padding:9px}.hide-sm{display:none}}
"""

def pct(x):
    try: return f"{float(x)*100:.2f}%"
    except Exception: return '-'

def html_page():
    rows = latest_results(1000)
    best = sorted([r for r in rows if int(r.get('trades') or 0)>0], key=lambda r: float(r.get('expectancy') or 0), reverse=True)[:30]
    total = len(rows)
    trades = sum(int(r.get('trades') or 0) for r in rows)
    avg_exp = sum(float(r.get('expectancy') or 0) for r in rows)/total if total else 0
    elite = len([r for r in rows if int(r.get('trades') or 0)>=3 and float(r.get('expectancy') or 0)>0.03])
    body = []
    for r in best:
        exp = float(r.get('expectancy') or 0)
        body.append(f"<tr><td><b>{html.escape(str(r.get('ticker','')))}</b></td><td>{html.escape(str(r.get('setup','')))}</td><td>{int(r.get('hold_days') or 0)}d</td><td>{int(r.get('trades') or 0)}</td><td>{pct(r.get('winrate'))}</td><td class='{'pos' if exp>=0 else 'neg'}'>{pct(exp)}</td><td class='hide-sm'>{pct(r.get('best_return'))}</td><td class='hide-sm'>{pct(r.get('worst_return'))}</td></tr>")
    if not body:
        body.append("<tr><td colspan='8'>Nog geen backtest-resultaten. Run: <b>./run_backtest.sh \"BB,PLTR,IONQ,SOUN,NVDA,AMD,TSLA\" \"2y\"</b></td></tr>")
    return f"""<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'><title>Stock Evidence Engine</title><style>{CSS}</style></head><body><div class='wrap'><div class='hero'><div class='eyebrow'>Backtest-first stock alpha lab</div><div class='title'>Stock Evidence Engine</div><div class='sub'>Research vóór live signals — stdlib dashboard, vaste service, geen uvicorn/module gedoe.</div><a class='btn' href='/api/results'>API results</a></div><div class='grid'><div class='card'><div class='num'>{total}</div><div class='muted'>result rows</div></div><div class='card'><div class='num'>{trades}</div><div class='muted'>historical trades</div></div><div class='card'><div class='num'>{pct(avg_exp)}</div><div class='muted'>avg expectancy</div></div><div class='card'><div class='num'>{elite}</div><div class='muted'>positive candidates</div></div></div><h2>Beste evidence-resultaten</h2><table class='table'><thead><tr><th>Ticker</th><th>Setup</th><th>Hold</th><th>Trades</th><th>Winrate</th><th>Expectancy</th><th class='hide-sm'>Best</th><th class='hide-sm'>Worst</th></tr></thead><tbody>{''.join(body)}</tbody></table><p class='muted'>Version {__version__} · Port 8798</p></div></body></html>"""

class Handler(BaseHTTPRequestHandler):
    def send(self, code, body, ctype='text/html; charset=utf-8'):
        data = body.encode('utf-8') if isinstance(body, str) else body
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)
    def do_GET(self):
        path = urlparse(self.path).path
        try:
            if path == '/health':
                connect().close(); self.send(200, json.dumps({'ok':True,'version':__version__}), 'application/json'); return
            if path == '/api/results':
                self.send(200, json.dumps(latest_results(500), default=str), 'application/json'); return
            self.send(200, html_page())
        except Exception as e:
            self.send(500, f"Internal error: {html.escape(repr(e))}")
    def log_message(self, fmt, *args):
        print('[SEE]', self.address_string(), fmt%args)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--host', default='0.0.0.0')
    ap.add_argument('--port', type=int, default=8798)
    a = ap.parse_args()
    connect().close()
    print(f'[SEE] dashboard {__version__} listening on {a.host}:{a.port}', flush=True)
    ThreadingHTTPServer((a.host, a.port), Handler).serve_forever()

if __name__ == '__main__': main()
