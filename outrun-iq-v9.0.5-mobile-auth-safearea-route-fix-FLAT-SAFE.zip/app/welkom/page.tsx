import Link from "next/link";
import { redirect } from "next/navigation";
import { getUser, isApprovedPartner, isAdmin } from "@/lib/auth";
import { Mark, Check } from "@/components/icons";
import { AuthFlow } from "@/components/AuthFlow";
import { SplashIntro } from "@/components/SplashIntro";

export const dynamic = "force-dynamic";

export default async function Welkom({ searchParams }:{ searchParams: Promise<{ next?: string; type?: string }> }) {
  const { next, type } = await searchParams;
  const initialAccountType = type === "zakelijk" ? "zakelijk" : "persoonlijk";
  const user = await getUser();
  if (user) redirect(isAdmin(user) ? "/beheer" : isApprovedPartner(user) ? "/partner" : (next || "/"));
  return (
    <div className="app">
      <SplashIntro />
      <main className="welkom">
        <section className="hero">
          <div className="lock" style={{ color: "#fff", fontSize: 19 }}><Mark size={34} glow />OUTRUN <b style={{ color: "var(--petrol-glow)" }}>IQ</b></div>
          <h1>Log in wanneer je verder wilt gaan.</h1>
          <p>Je kunt vrij rondkijken op Outrun. Inloggen is pas nodig voor kopen, bewaren, chatten of verkopen.</p>
          <ul>
            <li><Check /> Snuffelen zonder account</li>
            <li><Check /> Terug naar exact dezelfde plek na login</li>
            <li><Check /> Zakelijk en persoonlijk strikt gescheiden</li>
          </ul>
        </section>
        <section className="authwrap">
          <p className="note" style={{ textAlign: "center", margin: "0 0 12px" }}><Link href="/" style={{ color: "var(--petrol)", fontWeight: 800 }}>← Eerst deals bekijken</Link></p>
          <AuthFlow next={next || "/"} initialAccountType={initialAccountType} />
          <p className="note" style={{ textAlign: "center", marginTop: 16 }}>
            Zakelijk verkopen? <Link href="/word-partner" style={{ color: "var(--petrol)", fontWeight: 700 }}>Outrun IQ Partner →</Link>
          </p>
          <p className="note" style={{ textAlign: "center", marginTop: 8, fontSize: 10.5 }}>
            <Link href="/juridisch/gebruiksvoorwaarden">Voorwaarden</Link> · <Link href="/juridisch/partnervoorwaarden">Partnervoorwaarden</Link> · <Link href="/juridisch/retourvoorwaarden">Retouren</Link> · <Link href="/juridisch/privacy">Privacy</Link> · <Link href="/juridisch/cookies">Cookies</Link>
          </p>
        </section>
      </main>
    </div>
  );
}
