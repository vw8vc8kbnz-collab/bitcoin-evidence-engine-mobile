# Outrun IQ v9.0.5 — Mobile Auth / Safe-Area / Route Fix

- Testmodus/dummy-login UI verwijderd uit het normale inlogscherm.
- `/api/auth/test-login` en `/api/auth/dummy-login` uitgeschakeld.
- iOS/PWA statusbar/top safe-area geforceerd donker zodat de witte balk niet meer zichtbaar is.
- Buyer meldingen-route redirect niet meer onverwacht naar Partner Hub.
- Buyer accountpagina opnieuw geforceerd naar licht en leesbaar.
- Partner darkmode behouden.
- Product toevoegen: vervolgknoppen gefixeerd boven de dock.
