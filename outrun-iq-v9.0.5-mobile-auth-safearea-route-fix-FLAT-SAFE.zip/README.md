# Outrun IQ v9.0.5

Mobiele stabilisatiefix: normale login terug, test/dummy login uit, witte iOS safe-area strip aangepakt, buyer alerts-route gecorrigeerd en partner/productflow behouden.
