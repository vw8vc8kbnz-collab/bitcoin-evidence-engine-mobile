import Link from "next/link";
import { redirect } from "next/navigation";
import { getUser, isApprovedPartner } from "@/lib/auth";
import { Mark, Check } from "@/components/icons";
import { AuthFlow } from "@/components/AuthFlow";
import { SplashIntro } from "@/components/SplashIntro";

export const dynamic = "force-dynamic";

export default async function Welkom({ searchParams }:{ searchParams: Promise<{ next?: string }> }) {
  const { next } = await searchParams;
  const user = await getUser();
  if (user) redirect(isApprovedPartner(user) ? "/partner" : (next || "/"));
  return (
    <div className="app">
      <SplashIntro />
      <main className="welkom">
        <section className="hero">
          <div className="lock" style={{ color: "#fff", fontSize: 19 }}><Mark size={34} glow />OUTRUN <b style={{ color: "var(--petrol-glow)" }}>IQ</b></div>
          <h1>Premium outletdeals van geverifieerde bedrijven.</h1>
          <p>Overstock, showroommodellen en retouren — met AI-prijsbewijs bij elke deal.</p>
          <ul>
            <li><Check /> Alleen KvK-geverifieerde partners</li>
            <li><Check /> Je betaling in escrow tot levering</li>
            <li><Check /> Eerlijk prijsbewijs: fast · outlet · nieuwprijs</li>
          </ul>
        </section>
        <section className="authwrap">
          <AuthFlow next={next || "/"} />
          <p className="note" style={{ textAlign: "center", marginTop: 16 }}>
            Zakelijk verkopen? <Link href="/word-partner" style={{ color: "var(--petrol)", fontWeight: 700 }}>Outrun IQ Partner →</Link>
          </p>
          <p className="note" style={{ textAlign: "center", marginTop: 8, fontSize: 10.5 }}>
            <Link href="/juridisch/gebruiksvoorwaarden">Voorwaarden</Link> · <Link href="/juridisch/partnervoorwaarden">Partnervoorwaarden</Link> · <Link href="/juridisch/retourvoorwaarden">Retouren</Link> · <Link href="/juridisch/privacy">Privacy</Link> · <Link href="/juridisch/cookies">Cookies</Link>
          </p>
        </section>
      </main>
    </div>
  );
}
