import Link from "next/link";
import { redirect } from "next/navigation";
import { getUser, isApprovedPartner } from "@/lib/auth";
import { PartnerApply } from "@/components/PartnerApply";
import { Check } from "@/components/icons";

export const dynamic = "force-dynamic";

export default async function WordPartner() {
  const user = await getUser();
  if (!user) redirect("/welkom?next=/word-partner");
  if (isApprovedPartner(user)) redirect("/partner");
  const status = user.partnerProfile?.status;
  return (
    <main className="page narrow">
      <h1 className="h1big" style={{ marginTop: 20 }}>Outrun IQ Partner</h1>
      {!status || status === "rejected" ? (
        <>
          <p className="note" style={{ marginTop: 4 }}>
            Verkoop je overstock, showroommodellen en retouren aan consumenten — met AI-prijsadvies,
            escrow-betalingen en je eigen storefront. Alleen voor geverifieerde bedrijven.
          </p>
          <div className="group" style={{ marginTop: 6 }}>
            <div className="li"><span className="icb"><Check /></span><b>10% commissie, verder niets<small>geen abonnement in de pilotfase</small></b></div>
            <div className="li"><span className="icb"><Check /></span><b>AI prijst je voorraad<small>fast / outlet / premium met verwachte verkooptijd</small></b></div>
            <div className="li"><span className="icb"><Check /></span><b>Uitbetaling na leverbevestiging<small>veilig via escrow</small></b></div>
          </div>
          {status === "rejected" && <p className="note" style={{ color: "var(--amber-deep)" }}>Je eerdere aanvraag is afgewezen. Je kunt opnieuw aanvragen met de juiste gegevens.</p>}
          <PartnerApply />
        </>
      ) : (
        <>
          <div className="group" style={{ marginTop: 8 }}>
            <div className="li">
              <b>Aanvraag in behandeling<small>{user.partnerProfile!.companyName} · KvK {user.partnerProfile!.kvk}</small></b>
              <span className="flag hot">IN BEHANDELING</span>
            </div>
          </div>
          <p className="note">We verifiëren je bedrijfsgegevens. Je krijgt een melding zodra je partneraccount actief is.</p>
          <Link href="/" className="btn sec" style={{ display: "block", textAlign: "center", marginTop: 14 }}>Terug naar de shop</Link>
        </>
      )}
    </main>
  );
}
