import Link from "next/link";
import { redirect } from "next/navigation";
import { getUser } from "@/lib/auth";
import { read } from "@/lib/store";
import { eur } from "@/lib/types";
import { DeleteAccount } from "@/components/DeleteAccount";
import { PushToggle } from "@/components/PushToggle";
import { Chev } from "@/components/icons";
import { LogoutButton } from "@/components/LogoutButton";

export const dynamic = "force-dynamic";

export default async function Account() {
  const user = await getUser();
  if (!user) redirect("/welkom?next=/account");
  const db = await read();
  const orders = db.orders.filter(o => o.buyerId === user.id).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  const savedCount = db.saved.filter(s => s.userId === user.id).length;
  const pStatus = user.partnerProfile?.status;

  return (
    <main className="page narrow">
      <h1 className="h1big" style={{ marginTop: 20 }}>Account</h1>
      <div className="prof">
        <span className="av2">{user.name.slice(0, 2).toUpperCase()}</span>
        <span><b>{user.name}</b><span>{user.email} · lid sinds {new Date(user.createdAt).getFullYear()}</span></span>
        <span className="badge">✓ ACCOUNT</span>
      </div>

      <div className="slabel">BESTELLINGEN{orders.length ? ` · ${orders.length}` : ""}</div>
      <div className="group">
        {orders.length === 0 && <div className="li"><b>Nog geen bestellingen<small>je testorders verschijnen hier</small></b></div>}
        {orders.slice(0, 8).map(o => (
          <Link key={o.id} href={`/order/${o.id}`} className="li">
            <b>{o.itemTitle}<small className="mono">{o.id} · {o.status === "paid_out" ? "AFGEROND" : "IN ESCROW"}</small></b>
            <span className="val">{eur(o.totalPaid)}</span>
            <Chev />
          </Link>
        ))}
      </div>

      <div className="slabel">VOOR JOU</div>
      <div className="group">
        <Link href="/bewaard" className="li"><b>Bewaard<small>{savedCount} {savedCount === 1 ? "item" : "items"}</small></b><Chev /></Link>
        <Link href="/meldingen" className="li"><b>Meldingen<small>orderupdates en nieuws</small></b><Chev /></Link>
        <Link href="/vinder" className="li"><b>✦ AI Vinder<small>beschrijf wat je zoekt</small></b><Chev /></Link>
      </div>

      <div className="slabel">GEVARENZONE</div>
      <div className="group"><DeleteAccount /></div>

      <div className="slabel">JURIDISCH</div>
      <div className="group">
        <Link href="/juridisch/gebruiksvoorwaarden" className="li"><b>Gebruiksvoorwaarden</b><Chev /></Link>
        <Link href="/juridisch/retourvoorwaarden" className="li"><b>Retourvoorwaarden</b><Chev /></Link>
        <Link href="/juridisch/privacy" className="li"><b>Privacyverklaring</b><Chev /></Link>
        <Link href="/juridisch/cookies" className="li"><b>Cookieverklaring</b><Chev /></Link>
      </div>

      <div className="slabel">INSTELLINGEN</div>
      <div className="group">
        <PushToggle />
        <LogoutButton />
      </div>

      <p className="note" style={{ marginTop: 22 }}>
        Zakelijk verkopen op Outrun IQ?{" "}
        <Link href={pStatus === "approved" ? "/partner" : "/word-partner"} style={{ color: "var(--petrol)", fontWeight: 700 }}>
          {pStatus === "approved" ? "Naar de Partner Hub →" : pStatus === "pending" ? "Aanvraag in behandeling →" : "Word partner →"}
        </Link>
      </p>
    </main>
  );
}
