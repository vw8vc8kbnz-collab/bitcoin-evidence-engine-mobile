(function(){
  'use strict';
  window.__TOOLA_DECOR_LIBRARY_BUILD='FIX660R8F_CATALOG_IMAGES';

  const INITIAL_VISIBLE = 16;
  const CHUNK_SIZE = 24;
  const EAGER_IMAGE_COUNT = 4;

  const UI = {
    filter: 'all',
    brand: '',
    color: '',
    search: '',
    searchText: '',
    visible: INITIAL_VISIBLE,
    indexVersion: '',
    indexedRows: [],
    initialized: false,
    sheetOpen: false,
    sheetTouchStartY: null,
    infiniteObserver: null,
    scrollFallbackBound: false,
  };

  function esc(value){
    return String(value == null ? '' : value)
      .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  }
  function catalog(){ return Array.isArray(window.MATERIAL_CATALOG) ? window.MATERIAL_CATALOG : []; }
  function keyOf(m){ return String(m?.publicMaterialId || m?.articleNumber || m?.materialCode || '').trim(); }
  function nameOf(m){ return String(m?.publicName || m?.displayName || m?.productName || m?.decorName || 'Decor').trim(); }
  function brandOf(m){ return String(m?.brand || 'Overig').trim() || 'Overig'; }
  function typeOf(m){ return String(m?.decorType || m?.categoryName || 'Overig').trim() || 'Overig'; }
  function colorOf(m){ return String(m?.colorGroup || 'Overig').trim() || 'Overig'; }
  function familyOf(m){ return String(m?.primaryVisualFamily || m?.visualFamily || m?.decorType || 'Onbekend').trim() || 'Onbekend'; }
  function searchTagsOf(m){ return Array.isArray(m?.searchTags) ? m.searchTags.map(x=>String(x||'').trim()).filter(Boolean) : []; }
  function visualTagsOf(m){ const tags=Array.isArray(m?.visualTags)?m.visualTags:[]; return Array.from(new Set([familyOf(m),...tags].map(x=>String(x||'').trim()).filter(Boolean))); }
  function selectedKey(){ return String(window.state?.activeMaterialKey || '').trim(); }
  function activeMaterial(){ return window.state?.material || null; }
  function isMobile(){ return !!(window.matchMedia && window.matchMedia('(max-width:700px)').matches); }
  function isMaterialStep(){
    const step = String(document.body?.dataset?.uiStep || '').toLowerCase();
    return step === 'material' || step === 'materials';
  }
  function typeBucket(m){
    // FIX658: hoofdfilters zijn uitsluitend gebaseerd op één geverifieerde primaire familie.
    // Zoekwoorden/secondary tags mogen een product nooit meer in een tweede hoofdfilter duwen.
    const family = familyOf(m).toLowerCase();
    if(family === 'hout') return 'wood';
    if(family === 'uni') return 'uni';
    if(family === 'steen & beton' || family === 'steen' || family === 'beton') return 'stone';
    if(family === 'metaal') return 'metal';
    if(family === 'textiel & leer' || family === 'textiel') return 'textile';
    if(family === 'grafisch') return 'graphic';
    if(family === 'fantasie') return 'fantasy';
    return 'other';
  }
  function typeLabel(m){
    return ({wood:'Hout',uni:'Uni',stone:'Steen & beton',metal:'Metaal',textile:'Textiel & leer',graphic:'Grafisch',fantasy:'Fantasie',other:'Decor'})[typeBucket(m)] || 'Decor';
  }
  function substrateLabel(m){
    const explicit=String(m?.substrateLabel||'').trim();
    if(explicit) return explicit;
    return ({MDF:'MDF',SPAANPLAAT:'Spaanplaat',MULTIPLEX:'Multiplex',OVERIG:'Overig',ONBEKEND:'Onbekend'})[String(m?.substrateType||'').toUpperCase()] || 'Onbekend';
  }
  function sheetSizeLabel(m){
    const w=Number(m?.sheetSizeMm?.width), h=Number(m?.sheetSizeMm?.height);
    if(!(w>0)||!(h>0)) return '';
    const fmt=n=>Number.isInteger(n)?String(n):String(Math.round(n*10)/10).replace('.',',');
    return `${fmt(h)} × ${fmt(w)} mm`;
  }
  function activeBatch(){
    const key = selectedKey();
    return (window.state?.materialBatches || []).find(x=>String(x?.key||'') === key) || null;
  }
  function grainIsOn(){
    const batch = activeBatch();
    if(batch && typeof batch.grainEnabled === 'boolean') return batch.grainEnabled;
    if(typeof window.state?.grainEnabled === 'boolean') return window.state.grainEnabled;
    const m = activeMaterial();
    if(m?.hasGrain === false) return false;
    return m?.grainDefaultOn !== false;
  }
  function thicknessLabel(m){
    const t = Number(m?.thicknessMm);
    return Number.isFinite(t) ? `${String(t).replace('.0','')} mm` : '';
  }
  function thumbHtml(m, cls, preferPreview, priority){
    const src = String((preferPreview ? m?.imagePreviewUrl : m?.imageThumbUrl) || m?.imageThumbUrl || '').trim();
    if(src){
      const eager = priority === true;
      return `<img src="${esc(src)}" alt="${esc(nameOf(m))}" data-decor-image-type="${esc(typeBucket(m))}" loading="${eager?'eager':'lazy'}" decoding="async"${eager?' fetchpriority="high"':''}>`;
    }
    return `<div class="decorPlaceholder ${cls||''}" data-type="${esc(typeBucket(m))}" aria-hidden="true">${typeBucket(m)==='wood'?'▥':typeBucket(m)==='stone'?'◫':typeBucket(m)==='metal'?'▦':'○'}</div>`;
  }

  function ensureStyle(){
    if(document.getElementById('decorLibraryStyles')) return;
    const style = document.createElement('style');
    style.id = 'decorLibraryStyles';
    style.textContent = `
      #decorLibraryPanel{display:none;flex:1 1 auto;min-height:0;padding:22px 24px 104px;scroll-padding-bottom:104px;overflow:auto;background:linear-gradient(180deg,#fff,#fbfcfb);box-sizing:border-box;}
      body[data-ui-step="material"] #decorLibraryPanel,body[data-ui-step="materials"] #decorLibraryPanel{display:block;}
      body[data-ui-step="material"] .left #canvasWrap,body[data-ui-step="materials"] .left #canvasWrap{display:none!important;}
      .decorMobileStepBadge,.decorMobileSearchWrap{display:none;}
      .decorLibraryHead{display:flex;align-items:flex-start;justify-content:space-between;gap:18px;margin-bottom:18px;}
      .decorLibraryTitle{margin:0;color:#14231d;font-size:clamp(24px,2.1vw,34px);font-weight:850;letter-spacing:-.03em;}
      .decorLibrarySub{margin:6px 0 0;color:#68766f;font-size:14px;line-height:1.45;}
      .decorFilterRow{display:flex;align-items:center;gap:10px;flex-wrap:wrap;padding-bottom:16px;border-bottom:1px solid rgba(39,59,49,.08);}
      .decorFilterBtn{border:1px solid rgba(60,83,105,.15);background:#fff;color:#34434d;border-radius:999px;padding:10px 16px;font:inherit;font-size:13px;font-weight:780;cursor:pointer;box-shadow:0 4px 12px rgba(25,39,32,.04);transition:.16s ease;white-space:nowrap;}
      .decorFilterBtn:hover{transform:translateY(-1px);border-color:rgba(72,111,151,.34);}
      .decorFilterBtn.is-active{background:linear-gradient(180deg,#6687aa,#4f7399);color:#fff;border-color:#55789d;box-shadow:0 9px 22px rgba(70,106,145,.22);}
      .decorFilterIcon{display:none;margin-right:6px;}
      .decorMoreFilters{display:none;grid-template-columns:repeat(2,minmax(180px,260px));gap:12px;padding:14px 0 2px;}
      .decorMoreFilters.is-open{display:grid;}
      .decorMoreFilters label{font-size:12px;font-weight:760;color:#607068;display:grid;gap:6px;}
      .decorMoreFilters select{width:100%;border:1px solid rgba(58,78,68,.13);border-radius:13px;background:#fff;padding:11px 12px;color:#26352e;outline:none;}
      .decorSectionHead{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:18px 0 12px;}
      .decorSectionTitle{font-size:13px;font-weight:850;color:#21342a;}
      .decorSectionCount{font-size:12px;color:#748079;}
      .decorGrid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:16px;}
      .decorCard{content-visibility:auto;contain-intrinsic-size:320px 410px;position:relative;border:1px solid rgba(49,68,58,.10);border-radius:17px;background:#fff;overflow:hidden;cursor:pointer;text-align:left;padding:0;color:#17261e;box-shadow:0 5px 16px rgba(24,37,31,.05);transition:.17s ease;min-width:0;-webkit-tap-highlight-color:transparent;}
      .decorCard:hover{transform:translateY(-2px);box-shadow:0 12px 28px rgba(24,37,31,.10);border-color:rgba(75,111,148,.28);}
      .decorCard.is-selected{border-color:#537ca6;box-shadow:0 0 0 2px rgba(83,124,166,.20),0 12px 30px rgba(54,92,130,.13);}
      .decorCardMedia{aspect-ratio:4/3;background:linear-gradient(145deg,#ece8df,#d7d1c6);overflow:hidden;position:relative;}
      .decorCardMedia img{width:100%;height:100%;object-fit:cover;display:block;}
      .decorPlaceholder{width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:34px;color:rgba(33,52,42,.38);background:linear-gradient(135deg,#f2eee8,#ddd6cc);}
      .decorPlaceholder[data-type="uni"]{background:linear-gradient(135deg,#f2f1ed,#d9d9d4);}
      .decorPlaceholder[data-type="stone"]{background:linear-gradient(135deg,#e5e4df,#bbbcb8);}
      .decorPlaceholder[data-type="metal"]{background:linear-gradient(135deg,#dfe3e5,#9da4a8);}
      .decorPlaceholder[data-type="textile"]{background:linear-gradient(135deg,#e9e1d8,#c8b9aa);}
      .decorSelectedCheck{position:absolute;right:10px;top:10px;width:28px;height:28px;border-radius:50%;display:none;align-items:center;justify-content:center;background:#557ca3;color:#fff;font-weight:900;box-shadow:0 4px 14px rgba(42,77,111,.25);}
      .decorCard.is-selected .decorSelectedCheck{display:flex;}
      .decorCardBody{padding:13px 14px 14px;min-height:126px;}
      .decorBrand{font-size:10px;letter-spacing:.055em;text-transform:uppercase;color:#69766f;font-weight:820;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
      .decorName{font-size:15px;font-weight:850;margin-top:5px;line-height:1.25;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;}
      .decorTags{display:flex;gap:7px;flex-wrap:wrap;margin-top:10px;}
      .decorTag{font-size:11px;color:#53615a;background:#f2f4f2;border-radius:8px;padding:5px 8px;}
      .decorInfiniteSentinel{display:flex;align-items:center;justify-content:center;min-height:52px;padding:18px 0 6px;color:#7a857f;font-size:12px;font-weight:720;text-align:center;}
      .decorInfiniteSentinel.is-done{opacity:.72;}
      .decorEmpty{padding:36px 20px;border:1px dashed rgba(58,78,68,.18);border-radius:18px;text-align:center;color:#6c7972;background:#fbfcfb;}
      #decorSelectedSummary{margin:16px 0 8px;}
      #matSuggest{display:none!important;}
      body[data-ui-step="material"] .leftHeader,body[data-ui-step="materials"] .leftHeader{min-height:62px!important;height:62px!important;box-sizing:border-box!important;align-items:center!important;overflow:visible!important;padding:10px 20px!important;background:rgba(255,255,255,.98)!important;border-bottom:1px solid rgba(49,68,58,.07)!important;position:relative!important;z-index:5!important;}
      body[data-ui-step="material"] .leftHeader #brandLogo,body[data-ui-step="materials"] .leftHeader #brandLogo{height:38px!important;max-height:38px!important;width:auto!important;object-fit:contain!important;display:block!important;}
      body[data-ui-step="material"] #stepMaterial,body[data-ui-step="materials"] #stepMaterial{background:linear-gradient(180deg,#fff,#fbfcfb);border:1px solid rgba(49,68,58,.08);border-radius:24px;padding:22px!important;box-shadow:0 14px 36px rgba(25,39,32,.08);}
      body[data-ui-step="material"] #stepMaterial>h3,body[data-ui-step="materials"] #stepMaterial>h3{margin:0 0 14px;color:#14231d;font-size:25px;line-height:1.08;font-weight:880;letter-spacing:-.03em;}
      body[data-ui-step="material"] #stepMaterial>label,body[data-ui-step="materials"] #stepMaterial>label{display:none!important;}
      body[data-ui-step="material"] #stepMaterial #matChosen,body[data-ui-step="materials"] #stepMaterial #matChosen,
      body[data-ui-step="material"] #stepMaterial #matClearBtn,body[data-ui-step="materials"] #stepMaterial #matClearBtn,
      body[data-ui-step="material"] #stepMaterial #grainByMaterialWrap,body[data-ui-step="materials"] #stepMaterial #grainByMaterialWrap,
      body[data-ui-step="material"] #stepMaterial>.help,body[data-ui-step="materials"] #stepMaterial>.help{display:none!important;}
      body[data-ui-step="material"] #stepMaterial #matSearch,body[data-ui-step="materials"] #stepMaterial #matSearch{height:52px;border-radius:16px;border:1px solid rgba(63,84,73,.14);background:#fff;padding:0 16px;font-size:14px;box-shadow:0 5px 16px rgba(25,39,32,.04);}
      body[data-ui-step="material"] #stepMaterial #matSearch:focus,body[data-ui-step="materials"] #stepMaterial #matSearch:focus{border-color:rgba(83,124,166,.58);box-shadow:0 0 0 3px rgba(83,124,166,.11);}
      .decorSelectedCard{border:1px solid rgba(49,68,58,.10);border-radius:22px;background:linear-gradient(180deg,#fff,#f8faf9);padding:18px;box-shadow:0 12px 30px rgba(25,39,32,.07);}
      .decorSelectedLabel{font-size:12px;font-weight:850;color:#58675f;margin-bottom:12px;text-transform:uppercase;letter-spacing:.055em;}
      .decorSelectedMain{display:grid;grid-template-columns:118px minmax(0,1fr);gap:17px;align-items:center;}
      .decorSelectedThumb{width:118px;aspect-ratio:1;border-radius:18px;overflow:hidden;background:#ece8df;box-shadow:0 8px 22px rgba(24,37,31,.09);}
      .decorSelectedThumb img{width:100%;height:100%;object-fit:cover;display:block;}
      .decorSelectedBrand{font-size:11px;text-transform:uppercase;letter-spacing:.055em;color:#6b7771;font-weight:850;}
      .decorSelectedName{font-size:22px;font-weight:880;color:#182820;margin-top:5px;line-height:1.12;letter-spacing:-.025em;}
      .decorSelectedMeta{display:flex;gap:7px;flex-wrap:wrap;margin-top:11px;}
      .decorDesktopChoiceLabel{font-size:13px;font-weight:850;color:#425149;margin:18px 0 9px;}
      .decorDesktopChoice{display:grid;grid-template-columns:1fr 1fr;gap:10px;}
      .decorDesktopChoiceBtn{min-height:60px;border-radius:15px;border:1px solid rgba(61,82,103,.18);background:#fff;color:#34434d;font:inherit;font-weight:820;cursor:pointer;padding:10px 12px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;}
      .decorDesktopChoiceBtn small{font-size:11px;font-weight:650;color:#748079;}
      .decorDesktopChoiceBtn.is-active{border-color:#557ca3;background:linear-gradient(180deg,#f5f8fc,#eef4fb);color:#3f638b;box-shadow:0 0 0 1px rgba(85,124,163,.16);}
      .decorDesktopBatchTitle{font-size:12px;font-weight:850;color:#58675f;margin:18px 0 8px;text-transform:uppercase;letter-spacing:.05em;}
      .decorDesktopBatchList{display:grid;gap:8px;}
      .decorDesktopBatchRow{display:grid;grid-template-columns:42px minmax(0,1fr) auto;gap:10px;align-items:center;padding:8px;border:1px solid rgba(49,68,58,.09);border-radius:14px;background:#fff;cursor:pointer;text-align:left;color:inherit;}
      .decorDesktopBatchRow.is-active{border-color:rgba(83,124,166,.58);background:#f3f7fb;box-shadow:0 0 0 1px rgba(83,124,166,.12);}
      .decorDesktopBatchThumb{width:42px;height:42px;border-radius:10px;overflow:hidden;background:#ece8df;}
      .decorDesktopBatchThumb img{width:100%;height:100%;object-fit:cover;display:block;}
      .decorDesktopBatchName{min-width:0;font-size:13px;font-weight:820;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
      .decorDesktopBatchRemove{width:34px;height:34px;border-radius:50%;border:1px solid rgba(75,92,83,.13);background:#fff;color:#6c7771;cursor:pointer;font-size:16px;}
      .decorDesktopActions{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:16px;}
      .decorDesktopAction{min-height:52px;border-radius:15px;font:inherit;font-weight:850;cursor:pointer;padding:0 14px;}
      .decorDesktopActionSecondary{border:1px solid rgba(61,82,103,.18);background:#fff;color:#34434d;}
      .decorDesktopActionPrimary{border:0;background:linear-gradient(180deg,#5279a3,#3f6894);color:#fff;box-shadow:0 12px 28px rgba(63,104,148,.24);}
      .decorDesktopEmpty{border:1px dashed rgba(58,78,68,.18);border-radius:18px;background:#fbfcfb;padding:26px 18px;text-align:center;color:#68766f;}
      .decorDesktopEmpty strong{display:block;color:#1c2d24;font-size:18px;margin-bottom:7px;}

      #decorMobileSticky{display:none;}
      #decorMobileSheetBackdrop{display:none;position:fixed;inset:0;z-index:2147483000;background:rgba(15,23,20,.34);backdrop-filter:blur(7px);-webkit-backdrop-filter:blur(7px);align-items:flex-end;justify-content:center;padding:0;box-sizing:border-box;}
      #decorMobileSheetBackdrop.is-open{display:flex;}
      #decorMobileSheet{position:relative;width:100%;max-width:700px;max-height:min(72dvh,680px);overflow:auto;overscroll-behavior:contain;border-radius:28px 28px 0 0;background:linear-gradient(180deg,#fff,#fbfcfb);box-shadow:0 -24px 70px rgba(0,0,0,.22);padding:12px 18px calc(18px + env(safe-area-inset-bottom,0px));box-sizing:border-box;transform:translateY(0);touch-action:pan-y;}
      .decorSheetHandle{width:54px;height:5px;border-radius:999px;background:#cbd1cd;margin:2px auto 14px;border:0;display:block;cursor:grab;padding:0;}
      .decorSheetClose{position:absolute;right:16px;top:14px;width:38px;height:38px;border-radius:50%;border:1px solid rgba(47,67,57,.12);background:#f6f8f6;color:#34423b;font-size:20px;line-height:1;display:flex;align-items:center;justify-content:center;cursor:pointer;}
      .decorSheetMain{display:grid;grid-template-columns:150px minmax(0,1fr);gap:18px;align-items:center;padding:10px 0 2px;}
      .decorSheetMedia{width:150px;aspect-ratio:1;border-radius:18px;overflow:hidden;background:#ece8df;box-shadow:0 8px 22px rgba(24,37,31,.09);}
      .decorSheetMedia img{width:100%;height:100%;object-fit:cover;display:block;}
      .decorSheetBrand{font-size:11px;letter-spacing:.055em;text-transform:uppercase;color:#6a7770;font-weight:820;}
      .decorSheetName{margin:5px 44px 0 0;color:#17261e;font-size:25px;line-height:1.12;font-weight:870;letter-spacing:-.025em;}
      .decorSheetTags{display:flex;gap:8px;flex-wrap:wrap;margin-top:13px;}
      .decorSheetChoiceLabel{font-size:13px;font-weight:820;color:#425149;margin:18px 0 9px;}
      .decorSheetChoice{display:grid;grid-template-columns:1fr 1fr;gap:10px;}
      .decorSheetChoiceBtn{min-height:58px;border-radius:15px;border:1px solid rgba(61,82,103,.18);background:#fff;color:#34434d;font:inherit;font-weight:800;cursor:pointer;padding:10px 12px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;}
      .decorSheetChoiceBtn small{font-size:11px;font-weight:650;color:#748079;}
      .decorSheetChoiceBtn.is-active{border-color:#557ca3;background:linear-gradient(180deg,#f5f8fc,#eef4fb);color:#3f638b;box-shadow:0 0 0 1px rgba(85,124,163,.16);}
      .decorSheetActions{display:grid;grid-template-columns:1fr;gap:10px;margin-top:16px;}
      .decorSheetAction{width:100%;min-height:54px;border-radius:15px;font:inherit;font-size:16px;font-weight:850;cursor:pointer;padding:0 14px;}
      .decorSheetAddMore{border:0;background:linear-gradient(180deg,#5279a3,#3f6894);color:#fff;box-shadow:0 12px 28px rgba(63,104,148,.24);}
      .decorSheetGoPanels{border:1px solid rgba(61,82,103,.18);background:#fff;color:#34434d;}

      @media (max-width:1250px){.decorGrid{grid-template-columns:repeat(3,minmax(0,1fr));}}
      @media (max-width:920px){.decorGrid{grid-template-columns:repeat(2,minmax(0,1fr));}}
      @media (max-width:700px){
        body[data-ui-step="material"] .app,body[data-ui-step="materials"] .app{display:flex!important;flex-direction:column!important;width:100%!important;min-height:100dvh!important;height:auto!important;padding:8px 8px calc(118px + env(safe-area-inset-bottom,0px))!important;gap:0!important;overflow:visible!important;background:#f6f8f7!important;}
        body[data-ui-step="material"] .left,body[data-ui-step="materials"] .left{display:block!important;visibility:visible!important;opacity:1!important;position:relative!important;width:calc(100vw - 16px)!important;height:auto!important;min-height:0!important;max-height:none!important;margin:0 auto!important;padding:0!important;overflow:hidden!important;pointer-events:auto!important;border-radius:24px!important;order:1!important;background:#fff!important;box-shadow:0 12px 30px rgba(16,32,24,.10)!important;}
        body[data-ui-step="material"] .leftHeader,body[data-ui-step="materials"] .leftHeader{display:flex!important;visibility:visible!important;position:relative!important;height:auto!important;min-height:54px!important;padding:10px 14px!important;background:#fff!important;border-bottom:1px solid rgba(46,68,57,.08)!important;}
        body[data-ui-step="material"] #decorLibraryPanel,body[data-ui-step="materials"] #decorLibraryPanel{display:block!important;visibility:visible!important;opacity:1!important;width:100%!important;height:auto!important;max-height:none!important;padding:16px 12px 126px!important;overflow:visible!important;}
        body[data-ui-step="material"] .right,body[data-ui-step="materials"] .right{display:none!important;visibility:hidden!important;opacity:0!important;pointer-events:none!important;height:0!important;min-height:0!important;max-height:0!important;overflow:hidden!important;margin:0!important;padding:0!important;}
        .decorMobileStepBadge{display:inline-flex;align-items:center;justify-content:center;margin-bottom:10px;border-radius:999px;padding:7px 11px;background:#f0f4f8;color:#466b94;font-size:12px;font-weight:850;}
        .decorLibraryHead{margin-bottom:14px;}
        .decorLibraryTitle{font-size:26px;}
        .decorLibrarySub{display:none;}
        .decorMobileSearchWrap{display:block;position:relative;margin-bottom:12px;}
        .decorMobileSearchIcon{position:absolute;left:14px;top:50%;transform:translateY(-50%);color:#7b8781;font-size:20px;pointer-events:none;}
        #decorMobileSearch{width:100%;height:50px;border:1px solid rgba(63,84,73,.14);border-radius:15px;background:#fff;padding:0 14px 0 44px;box-sizing:border-box;font:inherit;font-size:15px;color:#26352e;outline:none;box-shadow:0 4px 14px rgba(25,39,32,.04);}
        #decorMobileSearch:focus{border-color:rgba(83,124,166,.58);box-shadow:0 0 0 3px rgba(83,124,166,.11);}
        .decorFilterRow{flex-wrap:nowrap;overflow-x:auto;padding:2px 0 12px;border-bottom:0;scrollbar-width:none;scroll-snap-type:x proximity;}
        .decorFilterRow::-webkit-scrollbar{display:none;}
        .decorFilterBtn{flex:0 0 auto;padding:9px 13px;scroll-snap-align:start;}
        .decorFilterIcon{display:inline;}
        .decorMoreFilters{grid-template-columns:1fr 1fr;padding:12px;border:1px solid rgba(58,78,68,.10);border-radius:16px;background:#f8faf8;margin-bottom:4px;}
        .decorSectionHead{margin:14px 2px 10px;}
        .decorGrid{grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;}
        .decorCard{border-radius:15px;}
        .decorCardMedia{aspect-ratio:4/3;}
        .decorCardBody{padding:10px 10px 11px;min-height:104px;}
        .decorName{font-size:13px;line-height:1.2;}
        .decorBrand{font-size:9px;}
        .decorTags{gap:5px;margin-top:8px;}
        .decorTag{font-size:10px;padding:4px 7px;}
        .decorSelectedCheck{width:27px;height:27px;right:8px;top:8px;}
        #decorSelectedSummary{display:none!important;}
        #decorMobileSticky{position:fixed;left:10px;right:10px;bottom:calc(10px + env(safe-area-inset-bottom,0px));z-index:2147482000;display:none;grid-template-columns:minmax(0,1fr) auto;gap:10px;align-items:center;padding:9px;border-radius:20px;background:rgba(255,255,255,.97);border:1px solid rgba(52,73,63,.11);box-shadow:0 18px 48px rgba(12,25,18,.22);backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);}
        #decorMobileSticky.is-visible{display:grid;}
        .decorMobileStickyInfo{min-width:0;border:0;background:transparent;padding:0;display:grid;grid-template-columns:52px minmax(0,1fr);gap:10px;align-items:center;text-align:left;cursor:pointer;color:inherit;}
        .decorMobileStickyThumb{width:52px;height:52px;border-radius:12px;overflow:hidden;background:#ece8df;}
        .decorMobileStickyThumb img{width:100%;height:100%;object-fit:cover;display:block;}
        .decorMobileStickyName{font-size:14px;font-weight:850;color:#1b2a23;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
        .decorMobileStickyMeta{font-size:12px;color:#6b7771;margin-top:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
        .decorMobileStickyNext{height:48px;min-width:98px;border:0;border-radius:14px;background:linear-gradient(180deg,#5279a3,#3f6894);color:#fff;font:inherit;font-weight:850;cursor:pointer;padding:0 16px;box-shadow:0 9px 22px rgba(63,104,148,.22);}
        #decorMobileSheet{max-height:min(78dvh,720px);}
      }
      @media (max-width:390px){
        .decorGrid{grid-template-columns:1fr 1fr;}
        .decorMoreFilters{grid-template-columns:1fr;}
        .decorSheetMain{grid-template-columns:112px minmax(0,1fr);gap:13px;}
        .decorSheetMedia{width:112px;}
        .decorSheetName{font-size:21px;}
      }
      @media (prefers-reduced-motion:reduce){
        .decorCard,.decorFilterBtn,.decorSheetChoiceBtn{transition:none!important;}
      }
    `;
    document.head.appendChild(style);
  }

  function restoreMobileMaterialLibraryShell(){
    try{
      const left = document.querySelector('.left');
      const right = document.querySelector('.right');
      if(!left) return;
      const mobileMaterial = isMobile() && isMaterialStep();
      const leftProps = ['display','visibility','opacity','position','width','height','min-height','max-height','margin','padding','overflow','pointer-events'];
      const hideTarget = (el,key)=>{
        if(!el) return;
        if(el.dataset[key] !== '1'){
          el.dataset[key] = '1';
          el.dataset[`${key}PrevDisplay`] = el.style.getPropertyValue('display') || '';
          el.dataset[`${key}PrevDisplayPriority`] = el.style.getPropertyPriority('display') || '';
        }
        if(el.style.getPropertyValue('display') !== 'none' || el.style.getPropertyPriority('display') !== 'important') el.style.setProperty('display','none','important');
      };
      const restoreTarget = (el,key)=>{
        if(!el || el.dataset[key] !== '1') return;
        const value = el.dataset[`${key}PrevDisplay`] || '';
        const priority = el.dataset[`${key}PrevDisplayPriority`] || '';
        if(value) el.style.setProperty('display',value,priority); else el.style.removeProperty('display');
        delete el.dataset[key];
        delete el.dataset[`${key}PrevDisplay`];
        delete el.dataset[`${key}PrevDisplayPriority`];
      };
      if(!mobileMaterial){
        if(left.dataset.decorLibraryShellOverride === '1'){
          leftProps.forEach(prop=>left.style.removeProperty(prop));
          delete left.dataset.decorLibraryShellOverride;
        }
        restoreTarget(right,'decorLibraryRightHidden');
        if(!isMaterialStep()) closeMobileSheet(false);
        return;
      }
      left.dataset.decorLibraryShellOverride = '1';
      left.style.setProperty('display','block','important');
      left.style.setProperty('visibility','visible','important');
      left.style.setProperty('opacity','1','important');
      left.style.setProperty('position','relative','important');
      left.style.setProperty('width','calc(100vw - 16px)','important');
      left.style.setProperty('height','auto','important');
      left.style.setProperty('min-height','0','important');
      left.style.setProperty('max-height','none','important');
      left.style.setProperty('margin','0 auto','important');
      left.style.setProperty('padding','0','important');
      left.style.setProperty('overflow','hidden','important');
      left.style.setProperty('pointer-events','auto','important');
      hideTarget(right,'decorLibraryRightHidden');
    }catch(_){ }
  }

  function ensureMobileSelectionUi(){
    if(document.getElementById('decorMobileSticky') && document.getElementById('decorMobileSheetBackdrop')) return;

    const sticky = document.createElement('div');
    sticky.id = 'decorMobileSticky';
    sticky.setAttribute('aria-hidden','true');
    sticky.innerHTML = `
      <button type="button" class="decorMobileStickyInfo" id="decorMobileStickyOpen" aria-label="Open materiaalinstellingen">
        <span class="decorMobileStickyThumb" id="decorMobileStickyThumb"></span>
        <span><span class="decorMobileStickyName" id="decorMobileStickyName"></span><span class="decorMobileStickyMeta" id="decorMobileStickyMeta"></span></span>
      </button>
      <button type="button" class="decorMobileStickyNext" id="decorMobileStickyNext">Verder&nbsp; →</button>`;
    document.body.appendChild(sticky);

    const backdrop = document.createElement('div');
    backdrop.id = 'decorMobileSheetBackdrop';
    backdrop.setAttribute('aria-hidden','true');
    backdrop.innerHTML = `
      <section id="decorMobileSheet" role="dialog" aria-modal="true" aria-labelledby="decorMobileSheetTitle">
        <button type="button" class="decorSheetHandle" id="decorSheetHandle" aria-label="Sleep omlaag om te sluiten"></button>
        <button type="button" class="decorSheetClose" id="decorSheetClose" aria-label="Sluiten">×</button>
        <div class="decorSheetMain">
          <div class="decorSheetMedia" id="decorSheetMedia"></div>
          <div>
            <div class="decorSheetBrand" id="decorSheetBrand"></div>
            <h2 class="decorSheetName" id="decorMobileSheetTitle"></h2>
            <div class="decorSheetTags" id="decorSheetTags"></div>
          </div>
        </div>
        <div class="decorSheetChoiceLabel">Nerfrichting</div>
        <div class="decorSheetChoice" role="group" aria-label="Nerfrichting">
          <button type="button" class="decorSheetChoiceBtn" id="decorSheetGrainOn" data-grain-choice="on">Nerf aan<small>Niet roteren</small></button>
          <button type="button" class="decorSheetChoiceBtn" id="decorSheetGrainOff" data-grain-choice="off">Nerf uit<small>Vrij roteren</small></button>
        </div>
        <div class="decorSheetActions">
          <button type="button" class="decorSheetAction decorSheetAddMore" id="decorSheetAddMore">Nog een materiaal toevoegen</button>
          <button type="button" class="decorSheetAction decorSheetGoPanels" id="decorSheetGoPanels">Naar panelen&nbsp; →</button>
        </div>
      </section>`;
    document.body.appendChild(backdrop);

    document.getElementById('decorMobileStickyOpen')?.addEventListener('click',openMobileSheet);
    document.getElementById('decorMobileStickyNext')?.addEventListener('click',()=>goToPanels());
    document.getElementById('decorSheetClose')?.addEventListener('click',()=>closeMobileSheet(true));
    document.getElementById('decorSheetGrainOn')?.addEventListener('click',()=>setGrainForActive(true));
    document.getElementById('decorSheetGrainOff')?.addEventListener('click',()=>setGrainForActive(false));
    document.getElementById('decorSheetAddMore')?.addEventListener('click',()=>{
      closeMobileSheet(true);
      setTimeout(()=>focusDecorLibrary(),80);
    });
    document.getElementById('decorSheetGoPanels')?.addEventListener('click',()=>goToPanels());
    backdrop.addEventListener('click',ev=>{ if(ev.target === backdrop) closeMobileSheet(true); });

    const handle = document.getElementById('decorSheetHandle');
    const sheet = document.getElementById('decorMobileSheet');
    if(handle && sheet){
      handle.addEventListener('pointerdown',ev=>{
        UI.sheetTouchStartY = ev.clientY;
        try{ handle.setPointerCapture(ev.pointerId); }catch(_){ }
      });
      handle.addEventListener('pointermove',ev=>{
        if(UI.sheetTouchStartY == null) return;
        const dy = Math.max(0, ev.clientY - UI.sheetTouchStartY);
        sheet.style.transform = `translateY(${Math.min(180,dy)}px)`;
      });
      const finish = ev=>{
        if(UI.sheetTouchStartY == null) return;
        const dy = Math.max(0, ev.clientY - UI.sheetTouchStartY);
        UI.sheetTouchStartY = null;
        sheet.style.transform = '';
        if(dy > 80) closeMobileSheet(true);
      };
      handle.addEventListener('pointerup',finish);
      handle.addEventListener('pointercancel',()=>{ UI.sheetTouchStartY = null; sheet.style.transform=''; });
    }

    document.addEventListener('keydown',ev=>{ if(ev.key === 'Escape' && UI.sheetOpen) closeMobileSheet(true); });
  }

  function lockBodyForSheet(){
    try{
      if(document.body.dataset.decorSheetLocked === '1') return;
      const y = window.scrollY || 0;
      document.body.dataset.decorSheetLocked = '1';
      document.body.dataset.decorSheetScrollY = String(y);
      document.body.dataset.decorSheetPrevPosition = document.body.style.position || '';
      document.body.dataset.decorSheetPrevTop = document.body.style.top || '';
      document.body.dataset.decorSheetPrevWidth = document.body.style.width || '';
      document.body.style.position = 'fixed';
      document.body.style.top = `-${y}px`;
      document.body.style.width = '100%';
    }catch(_){ }
  }
  function unlockBodyForSheet(restoreScroll){
    try{
      if(document.body.dataset.decorSheetLocked !== '1') return;
      const y = Number(document.body.dataset.decorSheetScrollY || 0) || 0;
      document.body.style.position = document.body.dataset.decorSheetPrevPosition || '';
      document.body.style.top = document.body.dataset.decorSheetPrevTop || '';
      document.body.style.width = document.body.dataset.decorSheetPrevWidth || '';
      delete document.body.dataset.decorSheetLocked;
      delete document.body.dataset.decorSheetScrollY;
      delete document.body.dataset.decorSheetPrevPosition;
      delete document.body.dataset.decorSheetPrevTop;
      delete document.body.dataset.decorSheetPrevWidth;
      if(restoreScroll !== false) window.scrollTo(0,y);
    }catch(_){ }
  }

  function openMobileSheet(){
    ensureMobileSelectionUi();
    if(!isMobile() || !isMaterialStep() || !activeMaterial()) return;
    const backdrop = document.getElementById('decorMobileSheetBackdrop');
    if(!backdrop) return;
    UI.sheetOpen = true;
    renderMobileSelection();
    backdrop.classList.add('is-open');
    backdrop.setAttribute('aria-hidden','false');
    document.body.dataset.decorSheetOpen = '1';
    lockBodyForSheet();
    setTimeout(()=>{ try{ document.getElementById('decorSheetClose')?.focus({preventScroll:true}); }catch(_){ } },40);
  }
  function closeMobileSheet(restoreScroll){
    const backdrop = document.getElementById('decorMobileSheetBackdrop');
    if(backdrop){ backdrop.classList.remove('is-open'); backdrop.setAttribute('aria-hidden','true'); }
    UI.sheetOpen = false;
    delete document.body?.dataset?.decorSheetOpen;
    unlockBodyForSheet(restoreScroll !== false);
    try{ renderMobileSelection(); }catch(_){ }
  }

  function findExistingGrainButton(key, next){
    const groups = Array.from(document.querySelectorAll('.grainChoice[data-gkey]'));
    const group = groups.find(el=>String(el.getAttribute('data-gkey')||'') === String(key||''));
    return group?.querySelector(`.grainChoiceBtn[data-gval="${next?'on':'off'}"]`) || null;
  }
  function setGrainForActive(next){
    try{
      const key = selectedKey();
      if(!key) return;
      const existing = findExistingGrainButton(key,next);
      if(existing){
        existing.click();
      }else{
        const batch = activeBatch();
        if(batch) batch.grainEnabled = !!next;
        if(window.state) window.state.grainEnabled = !!next;
      }
      setTimeout(()=>{ renderMobileSelection(); renderSelected(); },0);
    }catch(_){ }
  }

  function goToPanels(){
    closeMobileSheet(false);
    try{
      if(typeof window.__showWizardStep === 'function') window.__showWizardStep('panels');
      else if(typeof window.showStep === 'function') window.showStep('panels');
    }catch(_){ }
  }

  function focusDecorLibrary(){
    try{
      const panel = document.getElementById('decorLibraryPanel');
      if(isMobile()){
        const selected = document.querySelector('.decorCard.is-selected');
        selected?.scrollIntoView({block:'center',behavior:'smooth'});
      }else{
        panel?.scrollTo({top:0,behavior:'smooth'});
        panel?.classList.add('decorLibraryAttention');
        setTimeout(()=>panel?.classList.remove('decorLibraryAttention'),500);
      }
    }catch(_){ }
  }

  function materialBatches(){ return Array.isArray(window.state?.materialBatches) ? window.state.materialBatches : []; }

  function desktopBatchRowsHtml(){
    const active = selectedKey();
    return materialBatches().map(batch=>{
      const m = batch?.mat || {};
      const key = String(batch?.key || keyOf(m));
      return `<div class="decorDesktopBatchRow${key===active?' is-active':''}" data-desktop-batch-key="${esc(key)}" role="button" tabindex="0">
        <span class="decorDesktopBatchThumb">${thumbHtml(m,'',false)}</span>
        <span class="decorDesktopBatchName">${esc(nameOf(m))}</span>
        <button type="button" class="decorDesktopBatchRemove" data-desktop-remove-key="${esc(key)}" aria-label="Verwijder ${esc(nameOf(m))}">×</button>
      </div>`;
    }).join('');
  }

  function bindDesktopSelectionEvents(){
    document.getElementById('decorDesktopGrainOn')?.addEventListener('click',()=>setGrainForActive(true));
    document.getElementById('decorDesktopGrainOff')?.addEventListener('click',()=>setGrainForActive(false));
    document.getElementById('decorDesktopAddMore')?.addEventListener('click',focusDecorLibrary);
    document.getElementById('decorDesktopGoPanels')?.addEventListener('click',goToPanels);
    document.querySelectorAll('[data-desktop-batch-key]').forEach(row=>{
      const activate=()=>{
        const key=String(row.getAttribute('data-desktop-batch-key')||'');
        if(key && typeof window.__setActiveMaterial==='function'){
          window.__setActiveMaterial(key);
          try{ document.dispatchEvent(new CustomEvent('adzaagt-material-selection-updated')); }catch(_){ }
          render();
        }
      };
      row.addEventListener('click',ev=>{ if(ev.target.closest('[data-desktop-remove-key]')) return; activate(); });
      row.addEventListener('keydown',ev=>{ if(ev.key==='Enter'||ev.key===' '){ev.preventDefault();activate();} });
    });
    document.querySelectorAll('[data-desktop-remove-key]').forEach(btn=>btn.addEventListener('click',ev=>{
      ev.preventDefault();ev.stopPropagation();
      const key=String(btn.getAttribute('data-desktop-remove-key')||'');
      if(key && typeof window.removeMaterialBatch==='function'){
        window.removeMaterialBatch(key);
        setTimeout(render,0);
      }
    }));
  }

  function ensureUi(){
    restoreMobileMaterialLibraryShell();
    ensureStyle();
    ensureMobileSelectionUi();
    if(UI.initialized) return;
    const left = document.querySelector('.left');
    const leftHeader = left?.querySelector('.leftHeader');
    const stepMaterial = document.getElementById('stepMaterial');
    if(!left || !leftHeader || !stepMaterial) return;

    let panel = document.getElementById('decorLibraryPanel');
    if(!panel){
      panel = document.createElement('section');
      panel.id = 'decorLibraryPanel';
      panel.setAttribute('aria-label','Decorbibliotheek');
      panel.innerHTML = `
        <div class="decorLibraryHead"><div><div class="decorMobileStepBadge">Stap 1 van 5</div><h2 class="decorLibraryTitle">Kies jouw decor</h2><p class="decorLibrarySub">Zoek of filter direct in de tegelbibliotheek.</p></div></div>
        <div class="decorMobileSearchWrap"><span class="decorMobileSearchIcon">⌕</span><input id="decorMobileSearch" type="search" placeholder="Zoek op merk, decornaam, kleur of type…" autocomplete="off" enterkeyhint="search"></div>
        <div class="decorFilterRow" id="decorFilterRow">
          <button class="decorFilterBtn is-active" type="button" data-filter="all"><span class="decorFilterIcon">▦</span>Alle</button>
          <button class="decorFilterBtn" type="button" data-filter="wood"><span class="decorFilterIcon">▥</span>Hout</button>
          <button class="decorFilterBtn" type="button" data-filter="uni"><span class="decorFilterIcon">○</span>Uni</button>
          <button class="decorFilterBtn" type="button" data-filter="stone"><span class="decorFilterIcon">◫</span>Steen</button>
          <button class="decorFilterBtn" type="button" data-filter="metal"><span class="decorFilterIcon">▦</span>Metaal</button>
          <button class="decorFilterBtn" type="button" data-filter="textile"><span class="decorFilterIcon">▧</span>Textiel & leer</button>
          <button class="decorFilterBtn" type="button" data-filter="graphic"><span class="decorFilterIcon">◇</span>Grafisch</button>
          <button class="decorFilterBtn" type="button" data-filter="fantasy"><span class="decorFilterIcon">✦</span>Fantasie</button>
          <button class="decorFilterBtn" id="decorMoreFiltersBtn" type="button"><span class="decorFilterIcon">⌄</span>Filters</button>
        </div>
        <div class="decorMoreFilters" id="decorMoreFilters">
          <label>Merk<select id="decorBrandFilter"><option value="">Alle merken</option></select></label>
          <label>Kleurgroep<select id="decorColorFilter"><option value="">Alle kleuren</option></select></label>
        </div>
        <div class="decorSectionHead"><div class="decorSectionTitle" id="decorSectionTitle">Alle decors</div><div class="decorSectionCount" id="decorSectionCount">Laden…</div></div>
        <div class="decorGrid" id="decorGrid"></div>
        <div class="decorInfiniteSentinel" id="decorInfiniteSentinel" aria-live="polite"></div>`;
      left.insertBefore(panel, left.querySelector('#canvasWrap'));
    }

    let selected = document.getElementById('decorSelectedSummary');
    if(!selected){
      selected = document.createElement('div');
      selected.id = 'decorSelectedSummary';
      const searchWrap = document.getElementById('matSearch')?.parentElement;
      if(searchWrap?.parentElement) searchWrap.parentElement.insertBefore(selected, searchWrap.nextSibling);
    }

    const gridEl = panel.querySelector('#decorGrid');
    if(panel && !panel.__decorImageFallbackBound){
      panel.__decorImageFallbackBound = true;
      // Image errors do not bubble, therefore use capture. A stale/corrupt derived
      // cache may never leave Safari's broken-image icon visible to customers.
      panel.addEventListener('error',ev=>{
        const img=ev.target;
        if(!img || String(img.tagName||'').toUpperCase()!=='IMG' || !img.hasAttribute('data-decor-image-type')) return;
        const fallback=document.createElement('div');
        const bucket=String(img.getAttribute('data-decor-image-type')||'other');
        fallback.className='decorPlaceholder';
        fallback.dataset.type=bucket;
        fallback.setAttribute('aria-hidden','true');
        fallback.textContent=bucket==='wood'?'▥':bucket==='stone'?'◫':bucket==='metal'?'▦':'○';
        try{img.replaceWith(fallback);}catch(_){try{img.remove();}catch(__){}}
      },true);
    }
    if(gridEl && !gridEl.__decorDelegated){
      gridEl.__decorDelegated = true;
      gridEl.addEventListener('click',ev=>{
        const btn = ev.target?.closest?.('[data-decor-id]');
        if(!btn || !gridEl.contains(btn)) return;
        const id = btn.getAttribute('data-decor-id') || '';
        const mat = catalog().find(x=>keyOf(x)===id);
        if(mat && typeof window.setMaterial === 'function'){
          const wasSelected = id === selectedKey();
          window.setMaterial(mat);
          syncSearchInputs(UI.searchText);
          render();
          if(isMobile()) setTimeout(()=>openMobileSheet(),wasSelected?0:90);
          else { try{ document.getElementById('decorSelectedSummary')?.scrollIntoView({block:'nearest',behavior:'smooth'}); }catch(_){ } }
        }
      });
    }

    panel.querySelectorAll('[data-filter]').forEach(btn=>btn.addEventListener('click',()=>{
      UI.filter = btn.getAttribute('data-filter') || 'all';
      UI.visible = INITIAL_VISIBLE;
      scrollLibraryTop();
      panel.querySelectorAll('[data-filter]').forEach(x=>x.classList.toggle('is-active',x===btn));
      render();
    }));
    panel.querySelector('#decorMoreFiltersBtn')?.addEventListener('click',()=>{
      panel.querySelector('#decorMoreFilters')?.classList.toggle('is-open');
    });
    panel.querySelector('#decorBrandFilter')?.addEventListener('change',ev=>{UI.brand=ev.target.value||'';UI.visible=INITIAL_VISIBLE;scrollLibraryTop();render();});
    panel.querySelector('#decorColorFilter')?.addEventListener('change',ev=>{UI.color=ev.target.value||'';UI.visible=INITIAL_VISIBLE;scrollLibraryTop();render();});
    let searchTimer = null;
    const applySearch = value=>{
      clearTimeout(searchTimer);
      searchTimer = setTimeout(()=>{
        UI.searchText=String(value||'');
        UI.search=UI.searchText.trim().toLowerCase();
        UI.visible=INITIAL_VISIBLE;
        syncSearchInputs(UI.searchText);
        scrollLibraryTop();
        render();
      },90);
    };
    panel.querySelector('#decorMobileSearch')?.addEventListener('input',ev=>applySearch(ev.target.value));
    const desktopSearch = document.getElementById('matSearch');
    desktopSearch?.addEventListener('input',ev=>applySearch(ev.target.value));
    desktopSearch?.addEventListener('search',ev=>applySearch(ev.target.value));

    try{
      const leftStyleObserver = new MutationObserver(()=>restoreMobileMaterialLibraryShell());
      leftStyleObserver.observe(left,{attributes:true,attributeFilter:['style']});
      const bodyStepObserver = new MutationObserver(()=>{restoreMobileMaterialLibraryShell();render();});
      bodyStepObserver.observe(document.body,{attributes:true,attributeFilter:['data-ui-step']});
      const right = document.querySelector('.right');
      if(right){
        const rightStyleObserver = new MutationObserver(()=>restoreMobileMaterialLibraryShell());
        rightStyleObserver.observe(right,{attributes:true,attributeFilter:['style']});
      }
    }catch(_){ }
    try{
      const mq = window.matchMedia('(max-width:700px)');
      const onMq = ()=>{ restoreMobileMaterialLibraryShell(); render(); };
      if(mq.addEventListener) mq.addEventListener('change',onMq); else mq.addListener(onMq);
    }catch(_){ }

    UI.initialized = true;
    restoreMobileMaterialLibraryShell();
    render();
  }

  function syncSearchInputs(value){
    const text = String(value == null ? '' : value);
    const mobile = document.getElementById('decorMobileSearch');
    const desktop = document.getElementById('matSearch');
    if(mobile && mobile.value !== text) mobile.value = text;
    if(desktop && desktop.value !== text) desktop.value = text;
    const suggest = document.getElementById('matSuggest');
    if(suggest){ suggest.style.display='none'; suggest.innerHTML=''; }
  }

  function scrollLibraryTop(){
    const panel = document.getElementById('decorLibraryPanel');
    if(panel && panel.scrollTop > 0) panel.scrollTop = 0;
    if(isMobile()){ try{ panel?.scrollIntoView({block:'start',behavior:'auto'}); }catch(_){ } }
  }

  function updateSentinel(rows){
    const sentinel = document.getElementById('decorInfiniteSentinel');
    if(!sentinel) return;
    const remaining = Math.max(0, rows.length - UI.visible);
    sentinel.classList.toggle('is-done', remaining === 0);
    sentinel.textContent = remaining > 0 ? `Nog ${remaining} decor${remaining===1?'':'s'} laden…` : (rows.length ? `${rows.length} decor${rows.length===1?'':'s'} geladen` : '');
  }

  function loadNextChunk(){
    const rows = filteredCatalog();
    if(UI.visible >= rows.length) return;
    const grid = document.getElementById('decorGrid');
    if(!grid) return;
    const from = UI.visible;
    UI.visible = Math.min(rows.length, UI.visible + CHUNK_SIZE);
    const chunk = rows.slice(from,UI.visible);
    if(chunk.length) grid.insertAdjacentHTML('beforeend',chunk.map((m,i)=>cardHtml(m,from+i)).join(''));
    updateSentinel(rows);
  }

  function ensureInfiniteLoading(){
    const sentinel = document.getElementById('decorInfiniteSentinel');
    const panel = document.getElementById('decorLibraryPanel');
    if(!sentinel || !panel) return;
    if(!UI.infiniteObserver && 'IntersectionObserver' in window){
      UI.infiniteObserver = new IntersectionObserver(entries=>{
        if(entries.some(entry=>entry.isIntersecting)) loadNextChunk();
      },{root:null,rootMargin:'320px 0px 320px 0px',threshold:0.01});
      UI.infiniteObserver.observe(sentinel);
    }
    if(!UI.scrollFallbackBound){
      UI.scrollFallbackBound = true;
      panel.addEventListener('scroll',()=>{
        if(panel.scrollHeight - panel.scrollTop - panel.clientHeight < 420) loadNextChunk();
      },{passive:true});
      window.addEventListener('scroll',()=>{
        if(!isMobile() || !isMaterialStep()) return;
        const rect=sentinel.getBoundingClientRect();
        if(rect.top < window.innerHeight + 420) loadNextChunk();
      },{passive:true});
    }
  }

  function populateSelect(select, values, current, allLabel){
    if(!select) return;
    const sig = JSON.stringify([allLabel,values]);
    if(select.dataset.optionsSig !== sig){
      const opts = [`<option value="">${esc(allLabel)}</option>`].concat(values.map(v=>`<option value="${esc(v)}">${esc(v)}</option>`));
      select.innerHTML = opts.join('');
      select.dataset.optionsSig = sig;
    }
    select.value = current || '';
  }

  function indexedCatalog(){
    const src = catalog();
    const signature = `${src.length}|${src[0]?.publicMaterialId||''}|${src[src.length-1]?.publicMaterialId||''}`;
    if(UI.indexVersion === signature && UI.indexedRows.length === src.length) return UI.indexedRows;
    UI.indexVersion = signature;
    UI.indexedRows = src.map(m=>{
      const visualTags = visualTagsOf(m);
      return {
        m,
        brand: brandOf(m), color: colorOf(m), bucket: typeBucket(m),
        visualLower: new Set(visualTags.map(x=>x.toLowerCase())),
        hay: `${brandOf(m)} ${nameOf(m)} ${familyOf(m)} ${visualTags.join(' ')} ${typeOf(m)} ${substrateLabel(m)} ${sheetSizeLabel(m)} ${m?.collection||''} ${colorOf(m)} ${searchTagsOf(m).join(' ')}`.toLowerCase(),
        sort: `${brandOf(m)} ${nameOf(m)}`,
        score: (m?.isPopular?4:0)+(m?.isNew?2:0),
      };
    });
    return UI.indexedRows;
  }

  function filteredCatalog(){
    let idx = indexedCatalog().filter(x=>x.m && x.m.active !== false && x.m.published !== false);
    if(UI.filter !== 'all') idx = idx.filter(x=>x.bucket===UI.filter);
    if(UI.brand) idx = idx.filter(x=>x.brand===UI.brand);
    if(UI.color) idx = idx.filter(x=>x.color===UI.color);
    if(UI.search){
      const terms = UI.search.split(/\s+/).filter(Boolean);
      idx = idx.filter(x=>terms.every(term=>x.hay.includes(term)));
    }
    idx.sort((a,b)=>{
      if(a.score!==b.score) return b.score-a.score;
      return a.sort.localeCompare(b.sort,'nl',{numeric:true,sensitivity:'base'});
    });
    return idx.map(x=>x.m);
  }

  function cardHtml(m, position){
    const key = keyOf(m);
    const selected = key && key === selectedKey();
    const thickness = thicknessLabel(m);
    const substrate = substrateLabel(m);
    const sheetSize = sheetSizeLabel(m);
    const priority = Number(position) >= 0 && Number(position) < EAGER_IMAGE_COUNT;
    return `<button class="decorCard${selected?' is-selected':''}" type="button" data-decor-id="${esc(key)}" aria-pressed="${selected?'true':'false'}">
      <div class="decorCardMedia">${thumbHtml(m,'',false,priority)}<span class="decorSelectedCheck">✓</span></div>
      <div class="decorCardBody"><div class="decorBrand">${esc(brandOf(m))}</div><div class="decorName">${esc(nameOf(m))}</div><div class="decorTags"><span class="decorTag">${esc(typeLabel(m))}</span><span class="decorTag">${esc(substrate)}</span>${thickness?`<span class="decorTag">${esc(thickness)}</span>`:''}${sheetSize?`<span class="decorTag">${esc(sheetSize)}</span>`:''}</div></div>
    </button>`;
  }

  function renderSelected(){
    const wrap = document.getElementById('decorSelectedSummary');
    if(!wrap) return;
    const m = activeMaterial();
    if(!m){
      wrap.innerHTML = `<div class="decorDesktopEmpty"><strong>Nog geen materiaal gekozen</strong>Kies links een decor of gebruik de zoekbalk hierboven.</div>`;
      return;
    }
    const thickness = thicknessLabel(m);
    const substrate = substrateLabel(m);
    const sheetSize = sheetSizeLabel(m);
    const batches = materialBatches();
    wrap.innerHTML = `<div class="decorSelectedCard">
      <div class="decorSelectedLabel">Actief materiaal</div>
      <div class="decorSelectedMain">
        <div class="decorSelectedThumb">${thumbHtml(m,'',true)}</div>
        <div>
          <div class="decorSelectedBrand">${esc(brandOf(m))}</div>
          <div class="decorSelectedName">${esc(nameOf(m))}</div>
          <div class="decorSelectedMeta"><span class="decorTag">${esc(typeLabel(m))}</span><span class="decorTag">${esc(substrate)}</span>${thickness?`<span class="decorTag">${esc(thickness)}</span>`:''}${sheetSize?`<span class="decorTag">${esc(sheetSize)}</span>`:''}<span class="decorTag">${grainIsOn()?'Nerf':'Vrij roteren'}</span></div>
        </div>
      </div>
      <div class="decorDesktopChoiceLabel">Nerfrichting</div>
      <div class="decorDesktopChoice" role="group" aria-label="Nerfrichting">
        <button type="button" class="decorDesktopChoiceBtn${grainIsOn()?' is-active':''}" id="decorDesktopGrainOn">Nerf aan<small>Niet roteren</small></button>
        <button type="button" class="decorDesktopChoiceBtn${!grainIsOn()?' is-active':''}" id="decorDesktopGrainOff">Nerf uit<small>Vrij roteren</small></button>
      </div>
      ${batches.length?`<div class="decorDesktopBatchTitle">Geselecteerde materialen (${batches.length})</div><div class="decorDesktopBatchList">${desktopBatchRowsHtml()}</div>`:''}
      <div class="decorDesktopActions">
        <button type="button" class="decorDesktopAction decorDesktopActionSecondary" id="decorDesktopAddMore">Nog een materiaal toevoegen</button>
        <button type="button" class="decorDesktopAction decorDesktopActionPrimary" id="decorDesktopGoPanels">Naar panelen&nbsp; →</button>
      </div>
    </div>`;
    bindDesktopSelectionEvents();
  }

  function renderMobileSelection(){
    ensureMobileSelectionUi();
    const sticky = document.getElementById('decorMobileSticky');
    const m = activeMaterial();
    // FIX660R8O: Tool A now owns one multi-material basket trigger. Keeping the
    // older single-material sticky bar underneath it duplicated the same swatch,
    // title and navigation action on mobile. Leave the legacy sheet available as
    // a fallback for older pages, but do not render its trigger when the new
    // basket module is active.
    const supersededByMaterialCart = !!window.ToolAMobileMaterialCart;
    const visible = !!(m && isMobile() && isMaterialStep() && !supersededByMaterialCart);
    if(sticky){
      sticky.classList.toggle('is-visible',visible && !UI.sheetOpen);
      sticky.setAttribute('aria-hidden',visible && !UI.sheetOpen ? 'false':'true');
    }
    if(!m) return;

    const thickness = thicknessLabel(m);
    const substrate = substrateLabel(m);
    const sheetSize = sheetSizeLabel(m);
    const grainText = grainIsOn() ? 'Nerf' : 'Vrij roteren';
    const stickyThumb = document.getElementById('decorMobileStickyThumb');
    if(stickyThumb) stickyThumb.innerHTML = thumbHtml(m,'',false);
    const stickyName = document.getElementById('decorMobileStickyName');
    if(stickyName) stickyName.textContent = nameOf(m);
    const stickyMeta = document.getElementById('decorMobileStickyMeta');
    if(stickyMeta) stickyMeta.textContent = [substrate,thickness,sheetSize].filter(Boolean).join(' · ');

    const sheetMedia = document.getElementById('decorSheetMedia');
    if(sheetMedia) sheetMedia.innerHTML = thumbHtml(m,'',true);
    const sheetBrand = document.getElementById('decorSheetBrand');
    if(sheetBrand) sheetBrand.textContent = brandOf(m);
    const sheetName = document.getElementById('decorMobileSheetTitle');
    if(sheetName) sheetName.textContent = nameOf(m);
    const sheetTags = document.getElementById('decorSheetTags');
    if(sheetTags) sheetTags.innerHTML = `<span class="decorTag">${esc(typeLabel(m))}</span><span class="decorTag">${esc(substrate)}</span>${thickness?`<span class="decorTag">${esc(thickness)}</span>`:''}${sheetSize?`<span class="decorTag">${esc(sheetSize)}</span>`:''}<span class="decorTag">${grainText}</span>`;
    document.getElementById('decorSheetGrainOn')?.classList.toggle('is-active',grainIsOn());
    document.getElementById('decorSheetGrainOff')?.classList.toggle('is-active',!grainIsOn());
  }

  function render(){
    restoreMobileMaterialLibraryShell();
    ensureUi();
    const panel = document.getElementById('decorLibraryPanel');
    const grid = document.getElementById('decorGrid');
    if(!panel || !grid) return;
    const all = catalog().filter(m=>m && m.active !== false && m.published !== false);
    const brands = Array.from(new Set(all.map(brandOf).filter(Boolean))).sort((a,b)=>a.localeCompare(b,'nl',{sensitivity:'base'}));
    const colors = Array.from(new Set(all.map(colorOf).filter(v=>v && v!=='Overig'))).sort((a,b)=>a.localeCompare(b,'nl',{sensitivity:'base'}));
    populateSelect(document.getElementById('decorBrandFilter'),brands,UI.brand,'Alle merken');
    populateSelect(document.getElementById('decorColorFilter'),colors,UI.color,'Alle kleuren');
    const rows = filteredCatalog();
    const shown = rows.slice(0,UI.visible);
    const sectionTitle = document.getElementById('decorSectionTitle');
    if(sectionTitle) sectionTitle.textContent = UI.search ? 'Zoekresultaten' : (UI.filter==='all' ? (rows.some(x=>x.isPopular)?'Populair en alle decors':'Alle decors') : ({wood:'Houtdecors',uni:'Uni kleuren',stone:'Steen & beton',metal:'Metaal',textile:'Textiel & leer',graphic:'Grafisch',fantasy:'Fantasie'}[UI.filter]||'Decors'));
    const sectionCount = document.getElementById('decorSectionCount');
    if(sectionCount) sectionCount.textContent = `${rows.length} decor${rows.length===1?'':'s'}`;
    grid.innerHTML = shown.length ? shown.map((m,i)=>cardHtml(m,i)).join('') : `<div class="decorEmpty" style="grid-column:1/-1">Geen decors gevonden met deze filters.</div>`;
    updateSentinel(rows);
    ensureInfiniteLoading();
    renderSelected();
    renderMobileSelection();
  }

  document.addEventListener('DOMContentLoaded',()=>{ ensureUi(); setTimeout(render,0); });
  document.addEventListener('adzaagt-material-catalog-updated',()=>{UI.indexVersion='';UI.indexedRows=[];UI.visible=INITIAL_VISIBLE;render();});
  document.addEventListener('adzaagt-material-selection-updated',render);
  window.addEventListener('pageshow',()=>setTimeout(render,0));
  window.addEventListener('resize',()=>setTimeout(()=>{restoreMobileMaterialLibraryShell();renderMobileSelection();},40));
  setTimeout(()=>{ensureUi();render();},500);
})();
