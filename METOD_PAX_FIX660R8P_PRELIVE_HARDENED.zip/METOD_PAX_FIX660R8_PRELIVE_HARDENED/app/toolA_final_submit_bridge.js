(function(root){
  'use strict';

  const BUILD = 'FIX660R8P_SINGLE_SUBMIT_CAPTURE_BRIDGE';
  let bound = false;

  function submitButtonFromTarget(target){
    try{
      const button = target && target.closest ? target.closest('#sendConfigBtn, #btnSendConfig') : null;
      return button && String(button.id || '') ? button : null;
    }catch(_){ return null; }
  }

  function routeClick(event){
    const button = submitButtonFromTarget(event && event.target);
    if(!button) return false;

    // Own this event at document-capture level, before any retired listener on
    // the button itself can swallow it. One physical tap therefore produces at
    // most one canonical submission attempt.
    try{ event.preventDefault(); }catch(_){ }
    try{ event.stopImmediatePropagation(); }catch(_){ try{ event.stopPropagation(); }catch(__){ } }

    const submit = root.__metodSubmitFinalConfiguration;
    if(typeof submit !== 'function'){
      try{
        if(typeof root.statusMsg === 'function') root.statusMsg('De verzendfunctie is nog niet gereed. Herlaad de pagina en probeer opnieuw.', true);
        else root.alert && root.alert('De verzendfunctie is nog niet gereed. Herlaad de pagina en probeer opnieuw.');
      }catch(_){ }
      return true;
    }
    try{
      const result = submit(button);
      if(result && typeof result.catch === 'function'){
        result.catch(function(error){
          try{ root.console && root.console.error && root.console.error('Final submit failed', error); }catch(_){ }
        });
      }
    }catch(error){
      try{ root.console && root.console.error && root.console.error('Final submit failed', error); }catch(_){ }
    }
    return true;
  }

  function bind(documentRef){
    const doc = documentRef || root.document;
    if(bound || !doc || typeof doc.addEventListener !== 'function') return false;
    doc.addEventListener('click', routeClick, true);
    bound = true;
    return true;
  }

  root.ToolAFinalSubmitBridge = Object.freeze({ BUILD, submitButtonFromTarget, routeClick, bind });
  root.__TOOLA_FINAL_SUBMIT_BUILD = BUILD;
  bind(root.document);
})(typeof window !== 'undefined' ? window : globalThis);
