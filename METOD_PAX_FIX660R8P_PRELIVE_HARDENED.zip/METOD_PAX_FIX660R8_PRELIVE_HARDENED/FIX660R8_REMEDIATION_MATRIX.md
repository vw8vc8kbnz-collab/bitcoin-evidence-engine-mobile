# FIX660R8 remediatiematrix

Bron: `METOD_PAX_FIX660R7_PRELIVE_AUDIT_2026-08-12.md`.  
Legenda: **Groen** = bronherstel plus geautomatiseerde gate; **Live gate** = mechanisme is aanwezig maar echte infrastructuur/device/werkplaats-evidence blijft verplicht; **Partieel** = P2-restwerk, niet als opgelost voorgesteld.

## P0

| ID | R8-maatregel | Gate/status |
|---|---|---|
| P0-01 | Eén bottom-to-top nerfcontract; asymmetrische 3-paneels golden fixture controleert placements en sheetgeometrie. | Groen |
| P0-02 | `panel_contract.py` valideert finite dimensies, integer Qty, unieke PartId, bekende edges, bool rotation, aaneengesloten unieke grainposities en gelijke breedte. | Groen |
| P0-03 | Bboxafwijking, lege geometrie, overlap en buiten-plaatentities zijn fatal; geen sheet wordt gepubliceerd. | Groen |
| P0-04 | Centrale DXF-transformatie roteert ARC-centra én start/eindhoeken voor 0/90/180/270. | Groen; onafhankelijke CAM-proef blijft live gate |
| P0-05 | Geen machining-droppende fallback; optimizerreport + manifest + exacte counts/identities + artifacthashes zijn verplicht. | Groen |
| P0-06 | Publieke opaque materiaal-ID wordt tegen actieve catalogus gebonden aan artikel, dikte, plaatmaat en grainpolicy; productie-CSV is server-canonical. | Groen |
| P0-07 | Pricing komt uitsluitend uit live serverconfig; browserpricing wordt verwijderd en edge-input is strict. | Groen |
| P0-08 | Strict IDs, vaste-root resolve, master/subjobrelation en sealed-file allowlist voor iedere download. | Groen |
| P0-09 | Productie is exact HTTPS, valideert domein/certificaat/key en redirect HTTP; legacy HTTP is verboden. | Live gate: extern TLS/firewallbewijs |
| P0-10 | Dedicated `metod-pax` user, nul capabilities, strict systemd-sandbox en alleen externe state schrijfbaar. | Live gate: `systemctl show`/procesbewijs |
| P0-11 | Bounded HTTP/SSE, Nginx rate/connection limits, genormaliseerd IP, Basic uit productie en pre-hash loginlimit. | Live gate: representatieve load/slow-client-SLO |
| P0-12 | Entry/blob/total/Qty/output/quota-limits; live plaatmaat; vrije bytes/inodes vóór jobwrite; extra DXF faalt. | Groen; disk/inode fault-injection blijft live gate |
| P0-13 | Alle mutable state, idempotency, notifyconfig en logs staan buiten de release en worden gemigreerd. | Groen; staging state-diff vereist |
| P0-14 | Immutable releasefolders, maintenance/drain, atomische pointer en statebehoudende rollback. | Live gate: geforceerde chaosdeploy |
| P0-15 | Volledige consistente statebackup, per-file manifest/hash, byteherverificatie en veilige atomische restoretool. | Groen lokaal; encrypted off-host restore blijft live gate |
| P0-16 | Berekenen creëert geen salesrequest; finale submit reserveert duurzaam één idempotencyclaim en linkt bestaande finalized job. | Groen |
| P0-17 | Durable runtime states, startupreconciliatie naar FAILED/CANCELLED, childprocess terminate/kill en finalization-blokkade na cancel. | Groen broncontract; restart/cancel per fase blijft live chaosgate |
| P0-18 | Submit vereist een zichtbaar gerenderde actuele Grain Studio-preview; mobiele sizing/orderfixtures zijn groen. | Open live gate: echte iPhone/Safari-acceptatie |
| P0-19 | R8M verwijdert status/I-O-feedbackcontentie en gebruikt een begrensde FIFO met één actieve optimizer en acht wachtplaatsen; meerdere klanten veroorzaken geen onbegrensde parallelle optimizerprocessen. | Groen broncontract; representatieve VPS-load blijft live gate |
| P0-20 | R8O houdt de finale submit-CTA herstelbaar na een snelle DONE-respons, bewaart de vóór optimalisatie vastgelegde klantstate en onderdrukt de dubbele legacy mobiele materiaalbalk. | Groen bron- en regressiecontract; echte iPhone/Safari-submit blijft live gate |
| P0-21 | R8P routeert één fysieke eindknoptik vóór retired listeners naar exact één canonieke submitfunctie en maakt de compacte mobiele materiaal-drawer/verwijderactie deterministisch. | Groen bron- en uitvoerend Node-regressiecontract; echte iPhone/Safari-acceptatie blijft live gate |

## P1

| ID | R8-maatregel | Gate/status |
|---|---|---|
| P1-01 | Staging/production runtimepreflight vereist een niet-lege actieve catalogus; productie default minimum is 597. | Groen; actuele count live verifiëren |
| P1-02 | Centrale strict JSON-load/dump weigert NaN/Infinity en valideert recursief finite waarden. | Groen |
| P1-03 | Submit bouwt een allowlisted DTO en prijsstatus uitsluitend uit verzegelde serveroutput. | Groen |
| P1-04 | Publieke grens accepteert alleen geldige opaque IDs; minimale public DTO lekt geen intern artikel. | Groen |
| P1-05 | PII-draftopslag in localStorage is verwijderd; job/canceltokens zijn tab/session-scoped. | Groen |
| P1-06 | POST logout/revoke, HttpOnly/SameSite/Secure-cookie, idle/absolute TTL en bounded sessions. | Groen |
| P1-07 | Nonce-CSP, DXF-only uploadcontract, allowlisted static types en `nosniff`. | Groen |
| P1-08 | Eén request per flow en duurzame relaties voorkomen het oude gedeelde mirrorrequestprobleem. | Groen |
| P1-09 | Jobgebonden clientlog vereist bearer/admin; algemene sink is vast, bounded, geredigeerd en geratelimit. | Groen |
| P1-10 | JSONL-rotatie/locking en streaming file/backup/exportdownloads met maxima. | Groen |
| P1-11 | Pythonruntimecontract, stdlib-only requirements, optionele Pillowrange, SBOM en reproduceerbare ZIP-builder. | Groen |
| P1-12 | Liveness/readiness controleren build, catalogus, pricing, state, disk/inodes, DXF en production evidence. | Live gate: metrics, extern synthetic en alert/escalatie |
| P1-13 | Preview toont warnings/exclusions; approvalhash bindt de review en signoff bindt de actieve libraryhash. | Live gate: echte CSV-businesssignoff |
| P1-14 | Notifyconfig staat extern; ntfy vereist toegelaten HTTPS-host, redigeert fouten en logt geen topicsecret. | Live gate als notificatie operationeel vereist is |
| P1-15 | Individuele accounts, TOTP, rollen, server-derived actor en audit-events voor kritieke changes. | Live gate: echte accounts/eigenaren/revocatietest |

## P2

| ID | R8-maatregel | Gate/status |
|---|---|---|
| P2-01 | De onveilige dubbele filehandler, lazy Admin-export en oude migratietools zijn verwijderd; één strict finalizer is actief. | Partieel: verdere monolietopsplitsing/dode helpercleanup blijft backlog |
| P2-02 | Kritieke pipelinefouten zetten ERROR/FAILED en auditten; publieke fouten zijn generiek. | Partieel: niet-kritieke UI/reportinghelpers bevatten nog brede best-effort catches |
| P2-03 | Kritieke JSON/text/bytes/copy/markerwrites gebruiken fsync + replace + directory-fsync; gerelateerde inputbestanden worden volledig voorbereid en daarna met één directoryflush per map gepubliceerd. | Groen |
| P2-04 | JSONL append/rotatie gebruikt thread- en cross-process file locking met bounded backups. | Groen |
| P2-05 | Catalogusimage connect gebruikt één gevalideerde DNS-uitkomst en exact gepind IP met correcte TLS-hostverificatie. | Groen |
| P2-06 | Preflight draait echte adversarial, optimizer-, lifecycle-, backup/restore- en regressie-uitkomsten. | Groen |
| P2-07 | CI-releasegate, runtime/importcheck, SBOM, exacte checksums en deterministische artifactbuilder zijn aanwezig. | Partieel: coverage/SAST/secrets/dependency-CVE-attestatie nog toevoegen |

## Besluit

De oorspronkelijke bronblokkers zijn in R8 fail-closed gemaakt of omgezet in expliciete production gates. R8 is geschikt voor gecontroleerde staging en externe acceptatie. Publiek live blijft NO-GO zolang één van de live gates in `GO_LIVE_GATES_FIX660R8.md` openstaat.
