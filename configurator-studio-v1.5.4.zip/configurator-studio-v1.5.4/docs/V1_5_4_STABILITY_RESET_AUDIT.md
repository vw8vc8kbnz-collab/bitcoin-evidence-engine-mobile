# v1.5.4 Stability Reset Audit

- Homepage is independent of 3D engine.
- 3D lazy-loads only after builder opens.
- Builder is hidden until explicitly opened.
- Force close/capture handlers protect mobile exit.
- No fake fallback model is reintroduced.
