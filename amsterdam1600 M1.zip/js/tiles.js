// Sprites worden éénmalig voorgerenderd naar offscreen canvases.
// In de render-loop is elke tegel dan één drawImage-call — een orde
// van grootte sneller dan per frame paths tekenen op mobiel.
import { TILE_W, TILE_H, T, WATER_FRAMES, VARIANTS } from './config.js';
import { mulberry32 } from './rng.js';

const SS = 2; // supersample: scherp op retina-schermen

const PALETTE = {
  [T.IJ]:     ['#2b4a50', '#2e5057', '#294449'],   // per waterframe
  [T.CANAL]:  ['#39625c', '#3d6a62', '#365b55'],
  [T.GRASS]:  ['#7c9256', '#748a4f'],              // per variant
  [T.MARSH]:  ['#616f45', '#5a683f'],
  [T.DIRT]:   ['#a08a63', '#98835e'],
  [T.STREET]: ['#8a8479', '#827c72'],
  [T.QUAY]:   ['#ab9d7e', '#a39676'],
};

function diamondPath(ctx, cx, cy, hw, hh) {
  ctx.beginPath();
  ctx.moveTo(cx, cy - hh);
  ctx.lineTo(cx + hw, cy);
  ctx.lineTo(cx, cy + hh);
  ctx.lineTo(cx - hw, cy);
  ctx.closePath();
}

function makeSprite(draw) {
  const c = document.createElement('canvas');
  c.width = TILE_W * SS;
  c.height = TILE_H * SS;
  const ctx = c.getContext('2d');
  ctx.scale(SS, SS);
  draw(ctx, TILE_W / 2, TILE_H / 2, TILE_W / 2, TILE_H / 2);
  return c;
}

// Spikkels binnen de ruit (deterministisch per sprite)
function speckle(ctx, cx, cy, hw, hh, seed, count, colors, r) {
  const rnd = mulberry32(seed);
  diamondPath(ctx, cx, cy, hw, hh);
  ctx.save();
  ctx.clip();
  for (let i = 0; i < count; i++) {
    const u = rnd() * 2 - 1, v = rnd() * 2 - 1;
    if (Math.abs(u) + Math.abs(v) > 0.92) continue; // binnen de ruit blijven
    ctx.fillStyle = colors[(rnd() * colors.length) | 0];
    ctx.beginPath();
    ctx.arc(cx + u * hw, cy + v * hh, r * (0.6 + rnd() * 0.8), 0, 7);
    ctx.fill();
  }
  ctx.restore();
}

function base(ctx, cx, cy, hw, hh, fill) {
  diamondPath(ctx, cx, cy, hw, hh);
  ctx.fillStyle = fill;
  ctx.fill();
  // subtiele gridlijn zodat het isometrische raster leesbaar blijft
  ctx.strokeStyle = 'rgba(0,0,0,0.13)';
  ctx.lineWidth = 0.6;
  ctx.stroke();
}

export function buildSprites() {
  // sprites[type] = [variant of frame][canvas]
  const sprites = {};

  // Water: 3 animatieframes met lichtstreepjes die verschuiven
  for (const type of [T.IJ, T.CANAL]) {
    sprites[type] = [];
    for (let f = 0; f < WATER_FRAMES; f++) {
      sprites[type].push(makeSprite((ctx, cx, cy, hw, hh) => {
        base(ctx, cx, cy, hw, hh, PALETTE[type][f]);
        diamondPath(ctx, cx, cy, hw, hh);
        ctx.save();
        ctx.clip();
        ctx.strokeStyle = 'rgba(210, 228, 222, 0.16)';
        ctx.lineWidth = 1;
        const rnd = mulberry32(1600 + type * 10 + f);
        for (let i = 0; i < 3; i++) {
          const ly = cy - hh * 0.5 + (i + rnd()) * (hh * 0.5) + f * 1.4;
          const lx = cx - hw * 0.55 + rnd() * hw * 0.35;
          ctx.beginPath();
          ctx.moveTo(lx, ly);
          ctx.lineTo(lx + hw * (0.35 + rnd() * 0.3), ly);
          ctx.stroke();
        }
        ctx.restore();
      }));
    }
  }

  // Landtypes: 2 varianten voor visuele afwisseling
  const landDetail = {
    [T.GRASS]:  { colors: ['rgba(60,78,34,0.5)', 'rgba(148,168,104,0.5)'], count: 22, r: 0.7 },
    [T.MARSH]:  { colors: ['rgba(43,74,80,0.45)', 'rgba(38,50,24,0.5)'],   count: 26, r: 0.8 },
    [T.DIRT]:   { colors: ['rgba(74,60,38,0.4)', 'rgba(196,178,140,0.4)'], count: 16, r: 0.7 },
    [T.STREET]: { colors: ['rgba(50,48,44,0.4)', 'rgba(178,172,162,0.35)'],count: 30, r: 0.9 },
    [T.QUAY]:   { colors: ['rgba(72,62,44,0.35)', 'rgba(206,194,166,0.4)'], count: 20, r: 0.8 },
  };

  for (const type of [T.GRASS, T.MARSH, T.DIRT, T.STREET, T.QUAY]) {
    sprites[type] = [];
    for (let v = 0; v < VARIANTS; v++) {
      sprites[type].push(makeSprite((ctx, cx, cy, hw, hh) => {
        base(ctx, cx, cy, hw, hh, PALETTE[type][v]);
        const d = landDetail[type];
        speckle(ctx, cx, cy, hw, hh, type * 100 + v, d.count, d.colors, d.r);
      }));
    }
  }

  // Selectie-highlight (messing-kleurige ruit-outline)
  const selection = makeSprite((ctx, cx, cy, hw, hh) => {
    diamondPath(ctx, cx, cy, hw - 1, hh - 0.5);
    ctx.strokeStyle = '#c9a45c';
    ctx.lineWidth = 1.6;
    ctx.stroke();
    diamondPath(ctx, cx, cy, hw - 1, hh - 0.5);
    ctx.fillStyle = 'rgba(201, 164, 92, 0.14)';
    ctx.fill();
  });

  return { sprites, selection };
}
