// Amsterdam anno 1599 — naar de kaart van Pieter Bast.
// Handgecodeerde benadering van de stadsplattegrond vóór de Derde Uitleg:
// de halvemaanvormige stad aan het IJ, doorsneden door Damrak/Rokin/Amstel,
// met de vier burgwallen en de stadsgrachten Singel (west) en
// Kloveniersburgwal/Geldersekade (oost).
//
// Coördinaten zijn tegelposities op het 256×256-grid, noord (het IJ) boven.
// Tegel ≈ 10 m. Alles hieronder is gewoon aanpasbaar — verschuif een punt
// en de kaart verandert mee.

export default {
  name: 'Amsterdam 1599 (naar Pieter Bast)',

  // Zuidgrens van het IJ, met lichte golving via noise in world.js
  ijShoreY: 38,

  // De ommuurde stad als polygon (halve maan aan het IJ).
  // Volgorde: IJ-oever west→oost, dan de oostflank omlaag
  // (Geldersekade/Kloveniersburgwal), zuidpunt bij de Amstel,
  // en de westflank (Singel) weer omhoog.
  cityBounds: [
    [76, 44], [176, 44],                       // IJ-oever
    [178, 68], [172, 96], [162, 122], [148, 140], // oostflank
    [138, 146],                                 // zuidpunt (Amstel verlaat de stad)
    [128, 144], [112, 136], [92, 120], [78, 96], [72, 68], // westflank
  ],

  // De IJ-kade: havenfront tussen het water en de stad
  harbor: { x0: 72, x1: 180 },

  // Waterlopen: [punten, breedte]
  canals: [
    // Damrak — open havenwater tot aan de Dam
    { pts: [[127, 40], [125, 60], [126, 78], [128, 92]], w: 5, name: 'Damrak' },
    // Rokin — van de Dam naar het zuiden
    { pts: [[129, 100], [132, 112], [136, 126], [138, 138]], w: 4, name: 'Rokin' },
    // De Amstel — de stad uit, meanderend naar het zuiden
    { pts: [[138, 138], [133, 158], [138, 182], [146, 210], [140, 240], [142, 255]], w: 7, name: 'Amstel' },
    // Singel — westelijke stadsgracht (verdedigingsmoat)
    { pts: [[76, 42], [74, 68], [80, 96], [94, 120], [114, 136], [130, 142], [137, 141]], w: 4, name: 'Singel' },
    // Geldersekade — oostelijke toegang vanaf het IJ
    { pts: [[176, 42], [174, 56], [171, 68]], w: 4, name: 'Geldersekade' },
    // Kloveniersburgwal — oostelijke stadsgracht
    { pts: [[171, 68], [168, 94], [160, 120], [148, 136], [140, 140]], w: 4, name: 'Kloveniersburgwal' },
    // Oudezijds Voorburgwal
    { pts: [[144, 46], [142, 70], [140, 94], [137, 114], [135, 124]], w: 2, name: 'OZ Voorburgwal' },
    // Oudezijds Achterburgwal
    { pts: [[154, 48], [152, 74], [148, 98], [143, 116], [139, 126]], w: 2, name: 'OZ Achterburgwal' },
    // Nieuwezijds Voorburgwal
    { pts: [[114, 44], [112, 70], [115, 98], [121, 116], [127, 126]], w: 2, name: 'NZ Voorburgwal' },
    // Nieuwezijds Achterburgwal
    { pts: [[103, 46], [101, 74], [106, 102], [114, 122], [122, 132]], w: 2, name: 'NZ Achterburgwal' },
  ],

  // Straten: [punten, breedte]
  streets: [
    // Warmoesstraat — de oudste straat, oostzijde van het Damrak
    { pts: [[133, 46], [132, 66], [133, 86], [133, 92]], w: 1.4, name: 'Warmoesstraat' },
    // Nieuwendijk — westzijde van het Damrak
    { pts: [[121, 46], [119, 64], [121, 84], [123, 92]], w: 1.4, name: 'Nieuwendijk' },
    // Kalverstraat — van de Dam naar het Spui
    { pts: [[125, 100], [122, 114], [120, 128], [122, 136]], w: 1.4, name: 'Kalverstraat' },
    // Nes — oostzijde van het Rokin
    { pts: [[133, 100], [135, 112], [139, 124]], w: 1.2, name: 'Nes' },
    // Zeedijk — van de haven naar de Nieuwmarkt
    { pts: [[148, 44], [158, 52], [166, 62], [169, 68]], w: 1.4, name: 'Zeedijk' },
    // Oost-west verbindingen (bruggen komen in M9; grachten snijden ze nu nog)
    { pts: [[104, 88], [126, 88]], w: 1.2, name: 'Gasthuissteeg' },
    { pts: [[130, 104], [168, 100]], w: 1.2, name: 'Oude Doelenstraat' },
    { pts: [[134, 60], [172, 58]], w: 1.2, name: 'Oudebrugsteeg' },
  ],

  // Pleinen: [x0, y0, x1, y1]
  plazas: [
    { rect: [122, 93, 132, 99], name: 'de Dam' },
    { rect: [164, 66, 172, 72], name: 'Nieuwmarkt' },
  ],
};
