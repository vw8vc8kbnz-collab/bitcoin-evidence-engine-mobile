// M1-wereld: Amsterdam 1599 opgebouwd uit de vectorkaart
// (js/maps/amsterdam1599.js), gerasterd naar het tegelgrid.
// Opbouwvolgorde bepaalt wat "wint": platteland → stad → IJ →
// kade → straten → pleinen → grachten → kades langs het water.
import { GRID, T, SEED } from './config.js';
import { fnoise, hash2d } from './rng.js';
import { strokePolyline, fillPolygon, fillRect } from './mapbuild.js';
import MAP from './maps/amsterdam1599.js';

export function generateWorld() {
  const tiles = new Uint8Array(GRID * GRID);

  // 1. Platteland: veenweide met ontwateringssloten
  for (let y = 0; y < GRID; y++) {
    for (let x = 0; x < GRID; x++) {
      const n = fnoise(x / 13, y / 13, SEED);
      const sloot = (y % 16 === 8) && fnoise(x / 21, y / 3, SEED ^ 0x33) > 0.3;
      tiles[y * GRID + x] = sloot ? T.CANAL : (n > 0.56 ? T.GRASS : T.MARSH);
    }
  }

  // 2. De ommuurde stad: bouwgrond met hofjes en tuinen
  fillPolygon(tiles, MAP.cityBounds, (x, y) =>
    fnoise(x / 9, y / 9, SEED ^ 0x55) > 0.76 ? T.GRASS : T.DIRT
  );

  // 3. Het IJ: noordelijke waterband met gerafelde oever
  for (let x = 0; x < GRID; x++) {
    const edge = MAP.ijShoreY + 5 * fnoise(x / 9, 3.7, SEED ^ 0x11);
    for (let y = 0; y < edge; y++) tiles[y * GRID + x] = T.IJ;
  }

  // 4. De IJ-kade: havenfront tussen water en stad
  for (let x = MAP.harbor.x0; x <= MAP.harbor.x1; x++) {
    const edge = Math.floor(MAP.ijShoreY + 5 * fnoise(x / 9, 3.7, SEED ^ 0x11));
    for (let y = edge; y < 45; y++) {
      if (tiles[y * GRID + x] !== T.IJ) tiles[y * GRID + x] = T.QUAY;
    }
  }

  // 5. Straten en pleinen (grachten snijden er daarna doorheen —
  //    bruggen bestaan pas vanaf M9, dus dat is historisch eerlijk)
  for (const s of MAP.streets) strokePolyline(tiles, s.pts, s.w, T.STREET);
  for (const p of MAP.plazas) fillRect(tiles, ...p.rect, T.STREET);

  // 6. Waterlopen
  for (const c of MAP.canals) strokePolyline(tiles, c.pts, c.w, T.CANAL);

  // 7. Kades: bouwgrond die direct aan grachtwater grenst wordt kade
  const out = new Uint8Array(tiles);
  for (let y = 1; y < GRID - 1; y++) {
    for (let x = 1; x < GRID - 1; x++) {
      const i = y * GRID + x;
      if (tiles[i] !== T.DIRT) continue;
      if (
        tiles[i - 1] === T.CANAL || tiles[i + 1] === T.CANAL ||
        tiles[i - GRID] === T.CANAL || tiles[i + GRID] === T.CANAL
      ) {
        out[i] = T.QUAY;
      }
    }
  }

  return out;
}

export function tileAt(tiles, x, y) {
  if (x < 0 || y < 0 || x >= GRID || y >= GRID) return -1;
  return tiles[y * GRID + x];
}

// Deterministische visuele variant per tegel (spriteselectie).
export function variantAt(x, y) {
  return hash2d(x, y, SEED ^ 0x77) < 0.5 ? 0 : 1;
}
