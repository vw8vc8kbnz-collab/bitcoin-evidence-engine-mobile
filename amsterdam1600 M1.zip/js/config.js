// Amsterdam 1600 — M0 configuratie
// Alle sim-relevante constanten op één plek. Geen magic numbers elders.

export const GRID = 256;          // 256×256 tegels, tegel ≈ 8×8 m echt
export const TILE_W = 64;         // schermbreedte van een tegel op zoom 1
export const TILE_H = 32;
export const HALF_W = TILE_W / 2;
export const HALF_H = TILE_H / 2;

export const MIN_ZOOM = 0.12;     // hele kaart past op een telefoonscherm
export const MAX_ZOOM = 3.0;
export const START_ZOOM = 0.9;

// Onder deze zoom schakelt de renderer naar de vooraf gerenderde
// overzichtskaart (1 drawImage i.p.v. duizenden) — cruciaal voor 60 fps
// op mobiel bij ver uitzoomen.
export const OVERVIEW_CUTOFF = 0.5;
export const OVERVIEW_SCALE = 1 / 8;

export const SEED = 1600;

// Tegeltypes (Uint8 in de wereld-array)
export const T = Object.freeze({
  IJ: 0,        // open water van het IJ
  CANAL: 1,     // gracht / rivier / sloot
  GRASS: 2,     // grasland
  MARSH: 3,     // veenmoeras (toekomstige bouwgrond, eerst heien!)
  DIRT: 4,      // bouwgrond binnen de stad
  STREET: 5,    // straat
  QUAY: 6,      // kade langs gracht of IJ
});

export const TYPE_NAMES = Object.freeze({
  [T.IJ]: 'IJ-water',
  [T.CANAL]: 'Grachtwater',
  [T.GRASS]: 'Grasland',
  [T.MARSH]: 'Veenmoeras',
  [T.DIRT]: 'Bouwgrond',
  [T.STREET]: 'Straat',
  [T.QUAY]: 'Kade',
});

export const WATER_FRAMES = 3;
export const WATER_FRAME_MS = 450;
export const VARIANTS = 2; // visuele variatie per landtype
