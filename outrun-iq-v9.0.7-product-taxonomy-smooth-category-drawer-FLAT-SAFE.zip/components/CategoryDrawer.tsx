"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { TAXONOMY, POPULAR_TAXONOMY_ITEMS, parentLabel } from "@/lib/taxonomy";

function urlFor(parent?: string, q?: string, extra = "") {
  const p = new URLSearchParams();
  if (q) p.set("q", q);
  if (parent) p.set("cat", parent);
  p.set("sort", extra || "ai");
  return `/zoeken?${p.toString()}`;
}

export function CategoryDrawerButton({ variant = "menu", label = "Alle categorieën" }: { variant?: "menu" | "pill"; label?: string }) {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const [min, setMin] = useState("");
  const [max, setMax] = useState("");
  const [distance, setDistance] = useState("nl");
  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return TAXONOMY;
    return TAXONOMY.map(g => ({ ...g, items: g.items.filter(i => `${i.label} ${i.keywords.join(" ")} ${g.title}`.toLowerCase().includes(s)) })).filter(g => g.items.length);
  }, [q]);
  const filterHref = `/zoeken?${new URLSearchParams({ ...(max ? { max } : {}), ...(q ? { q } : {}), sort: "ai", ...(distance ? { afstand: distance } : {}), ...(min ? { min } : {}) }).toString()}`;

  return (
    <>
      <button type="button" className={variant === "menu" ? "catMenuButton" : "catFeedPill"} onClick={() => setOpen(true)} aria-label="Open categorieën en filters">
        {variant === "menu" ? <><span /><span /><span /></> : label}
      </button>
      {open && (
        <div className="catDrawerLayer" role="dialog" aria-modal="true" aria-label="Categorieën en filters">
          <button className="catDrawerBackdrop" type="button" onClick={() => setOpen(false)} aria-label="Sluiten" />
          <aside className="catDrawerPanel">
            <div className="catDrawerHandle" />
            <header className="catDrawerHead">
              <div><span>OUTRUN EXPLORER</span><b>Ontdek categorieën</b></div>
              <button type="button" onClick={() => setOpen(false)} aria-label="Sluiten">×</button>
            </header>
            <label className="catDrawerSearch">
              <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.2-4.2"/></svg>
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Zoek categorie, merk of productsoort" autoFocus />
            </label>
            <section className="catDrawerQuick">
              <Link href="/zoeken?sort=ai" onClick={() => setOpen(false)}>🔥 Populair</Link>
              <Link href="/zoeken?sort=waarde" onClick={() => setOpen(false)}>⭐ Voor jou</Link>
              <Link href="/zoeken?sort=nieuw" onClick={() => setOpen(false)}>🆕 Nieuw</Link>
              <Link href="/zoeken?sort=korting" onClick={() => setOpen(false)}>💰 Beste deals</Link>
            </section>
            <section className="catDrawerPopular">
              <h3>Vaak gezocht</h3>
              <div>
                {POPULAR_TAXONOMY_ITEMS.map(item => <Link key={item.id} href={urlFor(item.parent, item.label)} onClick={() => setOpen(false)}>{item.label}</Link>)}
              </div>
            </section>
            <section className="catDrawerGroups">
              {filtered.map(group => (
                <details key={group.id} open className="catDrawerGroup">
                  <summary><span>{group.icon}</span><b>{group.title}</b><em>{group.items.length}</em></summary>
                  <div>
                    <Link className="catAll" href={`/zoeken?cat=${group.parent}&sort=ai`} onClick={() => setOpen(false)}>Alles in {parentLabel(group.parent)}</Link>
                    {group.items.map(item => <Link key={item.id} href={urlFor(item.parent, item.label)} onClick={() => setOpen(false)}>{item.label}</Link>)}
                  </div>
                </details>
              ))}
            </section>
            <section className="catDrawerFilters">
              <h3>Filters</h3>
              <div className="catFilterGrid">
                <label><span>Min prijs</span><input inputMode="numeric" value={min} onChange={(e)=>setMin(e.target.value.replace(/\D/g,""))} placeholder="€ min" /></label>
                <label><span>Max prijs</span><input inputMode="numeric" value={max} onChange={(e)=>setMax(e.target.value.replace(/\D/g,""))} placeholder="€ max" /></label>
                <label className="wide"><span>Afstand</span><select value={distance} onChange={(e)=>setDistance(e.target.value)}><option value="nl">Heel Nederland</option><option value="25">25 km</option><option value="50">50 km</option><option value="100">100 km</option></select></label>
              </div>
              <div className="catFilterChips">
                <Link href="/zoeken?sort=ai" onClick={() => setOpen(false)}>AI score 70+</Link>
                <Link href="/zoeken?sort=korting" onClick={() => setOpen(false)}>Hoge korting</Link>
                <Link href="/zoeken?sort=nieuw" onClick={() => setOpen(false)}>Nieuw binnen</Link>
                <Link href="/zoeken?sort=waarde" onClick={() => setOpen(false)}>Beste waarde</Link>
              </div>
              <Link className="catApply" href={filterHref} onClick={() => setOpen(false)}>Toon resultaten</Link>
            </section>
          </aside>
        </div>
      )}
    </>
  );
}
