# Outrun IQ v9.0.7 — Product Taxonomy + Smooth Category Drawer

Deze versie vervangt de oude grote categorieblokken door een schaalbare discovery/feed-opzet.

Belangrijk:
- categoriepagina toont direct producten;
- categorieën zitten in een smooth left drawer;
- drawer opent via linksboven menu én via de chip “Alle categorieën”;
- overlay bevat categorieën, zoekfunctie en filters;
- centrale taxonomie staat in `lib/taxonomy.ts` en wordt de basis voor verdere AI/category-logica.
