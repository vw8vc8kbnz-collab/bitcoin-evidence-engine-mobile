import { redirect } from "next/navigation";
import { BuyerDock, TopNav } from "@/components/Dock";
import { SplashIntro } from "@/components/SplashIntro";
import { getUser, isAdmin, isPersonalBuyer } from "@/lib/auth";

export const dynamic = "force-dynamic";

export default async function BuyerLayout({
  children, modal,
}: { children: React.ReactNode; modal: React.ReactNode }) {
  const user = await getUser();
  // Admin blijft in beheer. Partners mogen de publieke shop bekijken,
  // maar de koper-navigatie/accountknoppen blijven strikt persoonlijk.
  if (isAdmin(user)) redirect("/beheer");
  const buyer = isPersonalBuyer(user);
  return (
    <div className="app">
      <SplashIntro />
      <TopNav isLoggedIn={buyer} isPartner={false} isBuyer={buyer} />
      {children}
      {modal}
      <BuyerDock isBuyer={buyer} />
    </div>
  );
}
