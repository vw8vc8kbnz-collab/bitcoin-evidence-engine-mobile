import Link from "next/link";
import { eur } from "@/lib/data";
import { getUser } from "@/lib/auth";
import { Img } from "@/components/Img";
import { Check, Score } from "@/components/icons";
import { Empty } from "@/components/Empty";
import { CategoryDrawerButton } from "@/components/CategoryDrawer";
import { rankListingsForBuyer } from "@/lib/ai/brain";
import type { Listing } from "@/lib/types";

export const dynamic = "force-dynamic";

const SORTS = [
  { v: "ai", label: "AI beste" },
  { v: "waarde", label: "Waarde" },
  { v: "prijs", label: "Prijs ↑" },
  { v: "korting", label: "Korting ↓" },
  { v: "nieuw", label: "Nieuw" },
] as const;

const CATS: { key: Listing["category"]; title: string }[] = [
  { key: "witgoed", title: "Witgoed" },
  { key: "meubels", title: "Meubels" },
  { key: "keukens", title: "Keuken" },
  { key: "tuin", title: "Tuin" },
  { key: "overig", title: "Overig" },
];

const FEEDS = [
  { href: "/zoeken?sort=ai", label: "🔥 Populair" },
  { href: "/zoeken?sort=waarde", label: "⭐ Voor jou" },
  { href: "/zoeken?sort=nieuw", label: "🆕 Nieuw" },
  { href: "/zoeken?sort=korting", label: "💰 Beste deals" },
] as const;

function catLabel(cat?: string) {
  return CATS.find(c => c.key === cat)?.title;
}

export default async function Zoeken({ searchParams }:{
  searchParams: Promise<{ q?: string; sort?: string; max?: string; cat?: string }>;
}) {
  const { q = "", sort = "ai", max = "", cat = "" } = await searchParams;
  const user = await getUser();
  const maxPrice = max ? Number(max) : undefined;
  const category = CATS.some(c => c.key === cat) ? cat as Listing["category"] : undefined;
  const { ranked } = await rankListingsForBuyer({ user, query: q, sort: sort === "waarde" ? "ai" : sort, maxPrice, category });
  if (sort === "waarde") ranked.sort((a,b)=>b.ai.priceScore + b.ai.dealScore - (a.ai.priceScore + a.ai.dealScore));
  const base = `/zoeken?q=${encodeURIComponent(q)}${category ? `&cat=${category}` : ""}${max ? `&max=${encodeURIComponent(max)}` : ""}`;
  const isCategoryHome = !q && !category;

  return (
    <main className="page searchBrainPage categoriesPage">
      <header className="hd categorySearchHead">
        <CategoryDrawerButton variant="menu" />
        <form action="/zoeken" className="srchbar">
          <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="6.5" /><path d="M20 20l-4.2-4.2" /></svg>
          <input name="q" defaultValue={q} placeholder="Zoek producten, merken of stores" autoComplete="off" />
        </form>
      </header>

      {!isCategoryHome && (
        <section className="searchBrainIntro compactSearchIntro">
          <span>AI DISCOVERY</span>
          <b>{q ? `Beste matches voor “${q}”` : `${catLabel(category)} deals`}</b>
          <p>Gesorteerd op waarde, vertrouwen, schaarste en deal-score.</p>
        </section>
      )}

      <div className="feedModeBar">
        {FEEDS.map(f => <Link key={f.href} href={f.href}>{f.label}</Link>)}
        <CategoryDrawerButton variant="pill" label="🏪 Alle categorieën" />
      </div>

      <div className="fbar aiSortBar">
        {SORTS.map(s2 => (
          <Link key={s2.v} href={`${base}&sort=${s2.v}`} className={`f${sort === s2.v ? " on" : ""}`}>{s2.label}</Link>
        ))}
      </div>
      <div className="count">{ranked.length} {ranked.length === 1 ? "AI-MATCH" : "AI-MATCHES"}{category ? ` · ${catLabel(category)?.toUpperCase()}` : ""}{q ? ` · "${q.toUpperCase()}"` : ""}</div>
      {ranked.length === 0 && (
        <Empty title="Niets gevonden" text={q ? `Geen sterke AI-match voor "${q}". Probeer een ander woord of AI Vinder.` : "Er staan nog geen listings live."} cta="Open AI Vinder" href="/vinder" />
      )}
      <div className="rows aiRows">
        {ranked.map(({ listing: l, ai }) => (
          <Link key={l.id} href={`/listing/${l.id}`} className="rowc aiResultRow">
            <Img src={l.photos[0]} fallback={l.fallback}><Score v={ai.finalScore} /></Img>
            <span className="tx">
              <span className="aiMatchLine"><b>{ai.label}</b><em>{ai.finalScore}/100</em></span>
              <span className="t">{l.title}</span>
              <span className="c">{ai.reason}</span>
              <span className="s"><Check />{l.pickupCity}</span>
              <span className="bot">
                <b>{eur(l.price)}{l.perUnit && "/st"}</b>
                <span className="d">−{Math.round((1 - l.price / l.newPrice) * 100)}%</span>
                <span className="km">Trust {ai.trustScore}</span>
              </span>
            </span>
          </Link>
        ))}
      </div>
    </main>
  );
}
