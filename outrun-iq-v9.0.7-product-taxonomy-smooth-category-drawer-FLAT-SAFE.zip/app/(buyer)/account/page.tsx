import Link from "next/link";
import { redirect } from "next/navigation";
import { getUser, isPersonalBuyer } from "@/lib/auth";
import { read } from "@/lib/store";
import { eur } from "@/lib/types";
import { DeleteAccount } from "@/components/DeleteAccount";
import { PushToggle } from "@/components/PushToggle";
import { Chev } from "@/components/icons";
import { LogoutButton } from "@/components/LogoutButton";
import { BusinessAccountLink } from "@/components/BusinessAccountLink";

export const dynamic = "force-dynamic";

export default async function Account() {
  const user = await getUser();
  if (!user) redirect("/welkom?next=/account");
  if (!isPersonalBuyer(user)) redirect("/welkom?type=persoonlijk&next=/account");
  const db = await read();
  const orders = db.orders.filter(o => o.buyerId === user.id).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  const savedCount = db.saved.filter(s => s.userId === user.id).length;
  const isBusinessAccount = user.role === "partner";
  const pStatus = isBusinessAccount ? user.partnerProfile?.status : undefined;
  const canEnterPartnerHub = user.role === "partner" && user.partnerProfile?.status === "approved" && !!user.partnerSlug && db.sellers.some(s => s.slug === user.partnerSlug);

  return (
    <main className="page narrow">
      <section className="accountHero"><span className="eyebrow">Persoonlijk dashboard</span><h1>Account</h1><p>Beheer je bestellingen, meldingen en kopersbescherming.</p></section>
      <div className="prof accountProfile">
        <span className="av2">{user.name.slice(0, 2).toUpperCase()}</span>
        <span><b>{user.name}</b><span>{user.email} · lid sinds {new Date(user.createdAt).getFullYear()}</span></span>
        <span className="badge">✓ ACCOUNT</span>
      </div>

      <div className="slabel">BESTELLINGEN{orders.length ? ` · ${orders.length}` : ""}</div>
      <div className="group settingsGroup">
        {orders.length === 0 && <div className="li"><b>Nog geen bestellingen<small>je testorders verschijnen hier</small></b></div>}
        {orders.slice(0, 8).map(o => (
          <Link key={o.id} href={`/order/${o.id}`} className="li">
            <b>{o.itemTitle}<small className="mono">{o.id} · {o.status === "paid_out" ? "AFGEROND" : "IN ESCROW"}</small></b>
            <span className="val">{eur(o.totalPaid)}</span>
            <Chev />
          </Link>
        ))}
      </div>

      <div className="slabel">VOOR JOU</div>
      <div className="group settingsGroup">
        <Link href="/bewaard" className="li"><b>Bewaard<small>{savedCount} {savedCount === 1 ? "item" : "items"}</small></b><Chev /></Link>
        <Link href="/meldingen" className="li"><b>Meldingen<small>orderupdates en nieuws</small></b><Chev /></Link>
        <Link href="/vinder" className="li"><b>✦ AI Vinder<small>beschrijf wat je zoekt</small></b><Chev /></Link>
      </div>

      <div className="slabel">GEVARENZONE</div>
      <div className="group settingsGroup"><DeleteAccount /></div>

      <div className="slabel">JURIDISCH</div>
      <div className="group settingsGroup">
        <Link href="/juridisch/gebruiksvoorwaarden" className="li"><b>Gebruiksvoorwaarden</b><Chev /></Link>
        <Link href="/juridisch/retourvoorwaarden" className="li"><b>Retourvoorwaarden</b><Chev /></Link>
        <Link href="/juridisch/privacy" className="li"><b>Privacyverklaring</b><Chev /></Link>
        <Link href="/juridisch/cookies" className="li"><b>Cookieverklaring</b><Chev /></Link>
      </div>

      <div className="slabel">INSTELLINGEN</div>
      <div className="group settingsGroup">
        <PushToggle />
        <LogoutButton />
      </div>

      <div className="slabel">ZAKELIJK</div>
      <div className="group settingsGroup">
        {canEnterPartnerHub ? (
          <Link href="/partner" className="li"><b>Naar de Partner Hub<small>beheer voorraad, orders en uitbetalingen</small></b><Chev /></Link>
        ) : pStatus === "pending" ? (
          <Link href="/word-partner" className="li"><b>Aanvraag in behandeling<small>we verifiëren je bedrijfsgegevens</small></b><Chev /></Link>
        ) : (
          <div className="li" style={{ display: "block" }}>
            <b>Zakelijk verkopen<small>maak hiervoor een apart zakelijk account aan. Je kopersaccount blijft persoonlijk.</small></b>
            <BusinessAccountLink className="btn sec" />
          </div>
        )}
      </div>
    </main>
  );
}
