# Changelog — Outrun IQ v9.0.7

## Product Taxonomy + Smooth Category Drawer
- Grote categorie-tegels verwijderd uit de categorie/discovery pagina.
- Productfeed begint nu veel hoger met compacte discovery chips.
- Nieuwe horizontale feedbar: Populair, Voor jou, Nieuw, Beste deals, Alle categorieën.
- Nieuwe smooth left-slide categorie/filter drawer.
- Drawer is bereikbaar via linksboven menu-knop én via “Alle categorieën”.
- Drawer bevat uitgebreide categorieboom voor witgoed, elektronica, meubels, keuken, tuin, gereedschap, sport/hobby en auto/mobiliteit.
- Drawer bevat filters voor min/max prijs, afstand en snelle deal-filters.
- Centrale taxonomie toegevoegd in `lib/taxonomy.ts` als basis voor buyer filters, zakelijke producttoevoeging en toekomstige AI Resolver 3.0.
- Productfeed en bestaande account world isolation uit v9.0.6 blijven behouden.

## Validatie
- TypeScript check: OK.
- Next build compile gestart; sandbox time-out tijdens production build fase.
