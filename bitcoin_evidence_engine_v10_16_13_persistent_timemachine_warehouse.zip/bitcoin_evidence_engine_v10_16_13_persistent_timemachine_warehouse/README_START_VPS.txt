Bitcoin Evidence Engine v10.16.13

Doel van deze versie:
- 70.001 candles blijven persistent in /home/ubuntu/bitcoin_evidence_data.
- /api/health bestaat weer en toont raw_candles + Time Machine warehouse counts.
- Random100/Random1000 schrijft time_machine_tests direct weg voordat de API terugkomt.
- Learning/signal enrichment draait daarna op de achtergrond.
- Oude C++ native binary met std::stoul-crash wordt automatisch vervangen door de Go native core.

Update op VPS:
cd ~/bitcoin-engine-deploy
bash update.sh

Test na update:
curl http://127.0.0.1:8787/api/health

Daarna in de app:
1. Data moet direct 70.001 candles tonen.
2. Machine -> Random100.
3. Check /api/health: time_machine_tests moet +700 worden.
4. Machine -> Random1000.
5. Check /api/health: time_machine_tests moet +7000 worden.
6. Download export via /api/time-machine/export/download.
