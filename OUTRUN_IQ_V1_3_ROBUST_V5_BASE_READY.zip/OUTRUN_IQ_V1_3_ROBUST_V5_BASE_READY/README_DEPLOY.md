# Outrun IQ V1.3 Robust V5 Base

Deze versie is gebaseerd op `outrun-iq-v5-app(1).zip` en is robuuster gemaakt voor VPS deployment:

- echte Next.js app, geen mockup-frame
- package-lock toegevoegd
- `start_8795.sh` installeert dependencies, bouwt automatisch en start op `0.0.0.0:8795`
- geen FastAPI/Python nodig

## Start lokaal/VPS

```bash
HOST=0.0.0.0 PORT=8795 ./start_8795.sh
```

Open:

```text
http://51.195.102.180:8795/
```
