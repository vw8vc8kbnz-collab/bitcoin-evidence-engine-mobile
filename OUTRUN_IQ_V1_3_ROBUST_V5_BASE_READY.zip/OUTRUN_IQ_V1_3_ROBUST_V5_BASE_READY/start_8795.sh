#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export HOST="${HOST:-0.0.0.0}"
export PORT="${PORT:-8795}"
export NEXT_TELEMETRY_DISABLED=1

if ! command -v node >/dev/null 2>&1; then
  echo "ERROR: Node.js is niet geïnstalleerd. Installeer Node 20+ en start opnieuw." >&2
  echo "Tip: curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash - && sudo apt-get install -y nodejs" >&2
  exit 1
fi
if ! command -v npm >/dev/null 2>&1; then
  echo "ERROR: npm is niet geïnstalleerd." >&2
  exit 1
fi
NODE_MAJOR="$(node -p "parseInt(process.versions.node.split('.')[0],10)")"
if [ "$NODE_MAJOR" -lt 18 ]; then
  echo "ERROR: Node.js $NODE_MAJOR gevonden, maar Next.js vereist Node 18+. Installeer Node 20+." >&2
  exit 1
fi

echo "=== Outrun IQ V1.3 robust start ==="
echo "Node: $(node -v) | npm: $(npm -v)"

if [ ! -d node_modules ]; then
  echo "=== Dependencies installeren ==="
  if [ -f package-lock.json ]; then
    npm ci --no-audit --no-fund
  else
    npm install --no-audit --no-fund
  fi
fi

if [ ! -d .next ]; then
  echo "=== Production build maken ==="
  npm run build
fi

echo "=== Start op http://${HOST}:${PORT} ==="
exec npx next start -H "$HOST" -p "$PORT"
