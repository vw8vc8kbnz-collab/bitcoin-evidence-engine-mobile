#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
pkill -f "next start" 2>/dev/null || true
pkill -f "node.*next" 2>/dev/null || true
HOST=0.0.0.0 PORT=8795 ./start_8795.sh
