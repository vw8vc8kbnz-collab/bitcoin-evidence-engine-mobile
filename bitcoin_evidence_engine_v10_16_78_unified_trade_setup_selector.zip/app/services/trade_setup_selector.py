from __future__ import annotations

import math
from datetime import datetime, timezone
from typing import Any

from app.core.config import settings
from app.core.debug import append_jsonl
from app.db.database import db

HORIZON_HOURS = {'1h':1, '4h':4, '8h':8, '24h':24, '7d':24*7, '30d':24*30, '90d':24*90}


def _finite(v: Any, default: float = 0.0) -> float:
    try:
        x = float(v)
        if math.isfinite(x):
            return x
    except Exception:
        pass
    return default


def _clamp(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, x))


class TradeSetupSelector:
    """Unified Time Machine + Forecast trade setup selector.

    v10.16.78 turns the old direction/target forecast into a setup decision:
    LONG / SHORT / NO TRADE, entry, learned win price, invalidation, RR,
    market potential in dollars, and outcome evaluation in Time Machine.

    This class is deliberately shared by live Forecast and Time Machine export
    enrichment.  The same rules and same learned DB context are used in both
    places, so forecast can no longer drift away from Time Machine training.
    """

    MIN_RR = 1.50

    def __init__(self):
        self._range_cache: dict[str, dict[str, float]] = {}

    def _recent_range_stats(self, horizon: str) -> dict[str, float]:
        horizon = str(horizon)
        if horizon in self._range_cache:
            return self._range_cache[horizon]
        h = max(1, int(HORIZON_HOURS.get(horizon, 24)))
        # Do not use future information in live forecast.  This is historical
        # distribution of realised moves over all available candles.  It tells
        # the engine what BTC can realistically move for this horizon.
        # Keep the query bounded so mobile VPS stays responsive.
        try:
            frame = db.df("""
                WITH c AS (
                    SELECT row_number() OVER (ORDER BY open_time) rn, open_time, close, high, low
                    FROM raw_candles
                    WHERE source='binance' AND symbol=? AND interval='1h'
                    ORDER BY open_time DESC LIMIT 20000
                ), ordered AS (
                    SELECT * FROM c ORDER BY rn
                )
                SELECT a.close AS entry_price,
                       b.close AS exit_price,
                       (SELECT MAX(x.high) FROM ordered x WHERE x.rn>a.rn AND x.rn<=a.rn+?) AS max_high,
                       (SELECT MIN(x.low) FROM ordered x WHERE x.rn>a.rn AND x.rn<=a.rn+?) AS min_low
                FROM ordered a
                JOIN ordered b ON b.rn=a.rn+?
                WHERE a.close IS NOT NULL AND a.close>0 AND b.close IS NOT NULL
                LIMIT 12000
            """, [settings.symbol, h, h, h])
            if frame.empty:
                raise RuntimeError('empty range stats')
            import pandas as pd
            entry = frame['entry_price'].astype(float).clip(lower=1e-9)
            up = ((frame['max_high'].astype(float) - entry) / entry * 100.0).abs()
            down = ((entry - frame['min_low'].astype(float)) / entry * 100.0).abs()
            abs_close = ((frame['exit_price'].astype(float) - entry) / entry * 100.0).abs()
            favorable = pd.concat([up, down], axis=0).dropna()
            out = {
                'median_range_pct': float(favorable.quantile(0.50)),
                'p65_range_pct': float(favorable.quantile(0.65)),
                'p75_range_pct': float(favorable.quantile(0.75)),
                'p85_range_pct': float(favorable.quantile(0.85)),
                'median_close_move_pct': float(abs_close.dropna().quantile(0.50)),
                'samples': int(len(frame)),
            }
        except Exception as exc:
            # Safe fallback based on horizon only. Used only when DB statistics
            # are unavailable; the note makes it auditable.
            base = {'1h':0.55,'4h':1.05,'8h':1.55,'24h':2.6,'7d':6.5,'30d':14.0,'90d':27.0}.get(horizon,2.0)
            out = {'median_range_pct':base*0.65,'p65_range_pct':base*0.85,'p75_range_pct':base,'p85_range_pct':base*1.25,'median_close_move_pct':base*0.45,'samples':0,'fallback_error':str(exc)[:180]}
        self._range_cache[horizon] = out
        return out

    def _context_from_item(self, item: dict) -> dict:
        f = dict(item.get('feature_snapshot') or {})
        return {
            'regime': str(f.get('regime') or f.get('regime_code') or item.get('regime') or 'unknown'),
            'volatility_24': _finite(f.get('volatility_24') or f.get('volatility') or f.get('range_pct'), 0.0),
            'range_pct': _finite(f.get('range_pct'), 0.0),
            'trend': _finite(f.get('return_24') or f.get('return_4') or f.get('trend'), 0.0),
            'data_completeness': _finite(f.get('data_completeness'), 0.0),
        }

    def _market_potential_pct(self, item: dict, horizon: str, direction: str) -> tuple[float, dict]:
        stats = self._recent_range_stats(horizon)
        ctx = self._context_from_item(item)
        expected = abs(_finite(item.get('expected_move_pct'), 0.0))
        conf = _finite(item.get('confidence'), 50.0)
        h = max(1, int(HORIZON_HOURS.get(horizon, 24)))
        # Vol/range context can expand or contract the historical range.  This
        # is what makes 1h sometimes choose $400 and sometimes $1000+ instead of
        # fixed scalp targets.
        vol_hint = max(ctx['range_pct'], ctx['volatility_24'] * math.sqrt(min(h,24)/24.0))
        hist_p = stats['p65_range_pct']
        if conf >= 70:
            hist_p = stats['p75_range_pct']
        if conf >= 80:
            hist_p = stats['p85_range_pct']
        # Directional conviction should not create unrealistic targets alone,
        # but if expected move is bigger than the median range, respect part of it.
        potential = max(hist_p, expected * 1.35, vol_hint * 1.15)
        # For weak confidence, keep the potential conservative.
        if conf < 55:
            potential *= 0.72
        elif conf < 62:
            potential *= 0.88
        # Horizon-specific sanity caps, still broad enough for real BTC moves.
        caps = {'1h':1.6,'4h':3.2,'8h':4.8,'24h':8.0,'7d':18.0,'30d':38.0,'90d':70.0}
        potential = _clamp(potential, 0.03, caps.get(str(horizon), 15.0))
        return potential, {'range_stats': stats, 'context': ctx, 'vol_hint_pct': round(vol_hint,6)}

    def select(self, item: dict, horizon: str | None = None, *, live: bool = False) -> dict:
        horizon = str(horizon or item.get('horizon') or '1h')
        entry = _finite(item.get('entry_price') or item.get('start_price') or item.get('current_price'), 0.0)
        if entry <= 0:
            return {**item, 'setup_action':'NO_TRADE', 'no_trade':True, 'setup_reason':'missing_entry_price'}
        move = _finite(item.get('expected_move_pct'), 0.0)
        conf = _finite(item.get('confidence'), 50.0)
        side = 'LONG' if move >= 0 else 'SHORT'
        potential_pct, meta = self._market_potential_pct(item, horizon, side)
        potential_usd = entry * potential_pct / 100.0
        # Target is chosen from market potential + model conviction.  It is not
        # a fixed $ target and not the tiny old scalp target.
        conviction = _clamp((conf - 50.0) / 35.0, 0.0, 1.0)
        target_pct = potential_pct * (0.52 + 0.22 * conviction)
        target_pct = max(target_pct, abs(move) * 1.15)
        # Do not let a single noisy model create an extreme target.
        target_pct = min(target_pct, potential_pct * 0.92)
        target_usd = entry * target_pct / 100.0
        stop_usd = target_usd / self.MIN_RR
        rr = target_usd / stop_usd if stop_usd > 0 else None
        if side == 'LONG':
            target_price = entry + target_usd
            stop_price = entry - stop_usd
        else:
            target_price = entry - target_usd
            stop_price = entry + stop_usd
        # Setup quality and no-trade filter.  NO TRADE is first-class; it is not
        # an error and is evaluated in Time Machine export.
        sample = int(meta.get('range_stats',{}).get('samples') or 0)
        quality = 40.0 + max(0.0, conf-50.0)*0.9 + min(12.0, math.log10(max(10, sample))*3.2)
        if potential_pct < {'1h':0.32,'4h':0.55,'8h':0.75,'24h':1.1,'7d':2.2,'30d':5.0,'90d':9.0}.get(horizon,1.0):
            quality -= 18.0
        if abs(move) < 0.03:
            quality -= 8.0
        min_quality = {'1h':55,'4h':54,'8h':54,'24h':53,'7d':52,'30d':51,'90d':50}.get(horizon,53)
        action = side if quality >= min_quality and rr and rr >= self.MIN_RR else 'NO_TRADE'
        out = dict(item)
        out.update({
            'setup_engine_version':'v10.16.78_unified_trade_setup_selector',
            'setup_action': action,
            'trade_action': action,
            'no_trade': action == 'NO_TRADE',
            'setup_side_candidate': side,
            'setup_quality': round(quality,3),
            'setup_min_quality': min_quality,
            'market_potential_pct': round(potential_pct,6),
            'market_potential_usd': round(potential_usd,2),
            'setup_target_price': round(target_price,2),
            'setup_target_distance_pct': round(target_pct,6),
            'setup_target_distance_usd': round(target_usd,2),
            'setup_invalidation_price': round(stop_price,2),
            'setup_invalidation_distance_pct': round((stop_usd/entry)*100.0,6),
            'setup_invalidation_distance_usd': round(stop_usd,2),
            'setup_rr': round(rr or 0.0,4),
            'setup_expected_value_pct': round((conf/100.0)*target_pct - (1.0-conf/100.0)*(stop_usd/entry*100.0),6),
            'setup_reason': ('valid_rr_1_5_setup' if action != 'NO_TRADE' else 'no_trade_low_quality_or_insufficient_market_potential'),
            'setup_context_json': meta,
        })
        if not live:
            self.evaluate_historical_setup(out)
        return out

    def evaluate_historical_setup(self, item: dict) -> dict:
        action = str(item.get('setup_action') or 'NO_TRADE')
        entry = _finite(item.get('start_price') or item.get('entry_price'), 0.0)
        high = _finite(item.get('actual_high'), entry)
        low = _finite(item.get('actual_low'), entry)
        actual = _finite(item.get('actual_price'), entry)
        if entry <= 0:
            item.update({'setup_outcome':'unscored_missing_entry'})
            return item
        side = item.get('setup_side_candidate') or ('LONG' if _finite(item.get('expected_move_pct'),0)>=0 else 'SHORT')
        target = _finite(item.get('setup_target_price'), entry)
        stop = _finite(item.get('setup_invalidation_price'), entry)
        if side == 'LONG':
            mfe = max(0.0, high-entry)
            mae = max(0.0, entry-low)
            target_hit = high >= target
            stop_hit = low <= stop
            exit_usd = actual-entry
        else:
            mfe = max(0.0, entry-low)
            mae = max(0.0, high-entry)
            target_hit = low <= target
            stop_hit = high >= stop
            exit_usd = entry-actual
        target_usd = abs(target-entry)
        stop_usd = abs(stop-entry)
        # Without tick sequence inside large horizons, both-hit is ambiguous.
        # Score it conservatively as invalidated to avoid training fake edge.
        valid_trade_existed = bool(target_hit and not stop_hit)
        no_trade_correct = None
        if action == 'NO_TRADE':
            no_trade_correct = not valid_trade_existed
            setup_outcome = 'no_trade_correct' if no_trade_correct else 'no_trade_missed_valid_trade'
            return_pct = 0.0
        else:
            if target_hit and not stop_hit:
                setup_outcome = 'target_hit_first_or_only'
                return_pct = target_usd/entry*100.0
            elif stop_hit:
                setup_outcome = 'stop_hit_or_ambiguous'
                return_pct = -stop_usd/entry*100.0
            else:
                setup_outcome = 'neither_hit_mark_to_horizon'
                return_pct = exit_usd/entry*100.0
        item.update({
            'setup_target_hit': bool(target_hit),
            'setup_stop_hit': bool(stop_hit),
            'setup_both_hit_ambiguous': bool(target_hit and stop_hit),
            'setup_mfe_usd': round(mfe,2),
            'setup_mae_usd': round(mae,2),
            'setup_mfe_pct': round(mfe/entry*100.0,6),
            'setup_mae_pct': round(mae/entry*100.0,6),
            'setup_return_pct': round(return_pct,6),
            'setup_valid_trade_existed': valid_trade_existed,
            'no_trade_correct': no_trade_correct,
            'setup_outcome': setup_outcome,
        })
        return item

    def select_many(self, items: list[dict]) -> list[dict]:
        return [self.select(i, str(i.get('horizon') or '1h'), live=False) for i in items]
