# Outrun OS v1.3.1 — Priklijst + Social Deep Search

Standalone acquisition cockpit voor Outrun IQ.

## Nieuw in v1.3.1

- Priklijst-aanpak: bedrijven verzamelen blijft goedkoop; deep search gebeurt alleen handmatig per lead.
- Geen automatische AI-kosten: worker staat standaard uit, deep search gebruikt geen DeepSeek/OpenAI.
- Deep search zoekt nu naast de website ook gevonden social-media profielen vanaf de bedrijfswebsite.
- Groottefilter toegevoegd: klein, middel, groot, enterprise en onbekend.
- Grotere bedrijven blijven vindbaar, maar staan apart filterbaar.
- UX-fix voor overlappende categoriechips op iPhone.
- Lead-detail heeft nu een duidelijke terugknop: “← Terug naar priklijst”.
- Deep crawl schrijft crawl-derived evidence weg met bron-URL’s.

## Belangrijk kostenprincipe

Outrun OS mag niet 24/7 dure API’s gebruiken. De standaardmodus is:

1. Discovery/priklijst: goedkoop, geen AI.
2. Deep search: alleen na jouw klik, website/social fetches, geen LLM.
3. Mail schrijven: pas na jouw actie, gebruikt AI.
4. Follow-up/reply: pas bij echte timing of reactie.

## Start lokaal

```bash
python3 -m venv .venv
./.venv/bin/pip install -r requirements.txt
./.venv/bin/python run.py
```

Open: `http://127.0.0.1:8700/`

## VPS

Service blijft `outrun-os` en poort blijft standaard `8700`.

## v1.3.3 — Company Master Database + AI Zoekfunctie

Nieuwe richting: Outrun OS gebruikt nu een permanente lokale company/KvK master in plaats van telkens kleine batches te zoeken.

Belangrijk:
- De lokale database `outrun_os.db` blijft bij updates behouden.
- Master vullen kan goedkoop zonder AI/API-calls.
- CSV-import is toegevoegd voor echte KvK/open-data exports.
- Basic analyse draait lokaal en bepaalt: actief-looking, kandidaat/irrelevant, groottebucket.
- Deep Search blijft handmatig per bedrijf en gebruikt pas daarna website/social onderzoek.
- AI zoekfunctie in de zoekbalk werkt no-cost: natuurlijke zoekzinnen worden lokaal vertaald naar filters.

Voorbeelden AI zoek:
- `actieve middelgrote wonen bedrijven zonder deep search`
- `groot sanitair >50`
- `enterprise elektronica met deep search`
- `zwolle kandidaat`

Productieregel: bij ZIP updates altijd database/data behouden:
`--exclude "outrun_os.db*" --exclude "data/"`
