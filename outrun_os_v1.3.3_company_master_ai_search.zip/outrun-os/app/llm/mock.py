"""
Deterministic mock provider. This is what makes Outrun OS fully explorable in
test mode BEFORE you add any keys: discovery, scan, scoring, drafts, replies and
the whole loop run end to end on canned-but-plausible output. Add the real keys
and the router silently switches to DeepSeek / GPT.
"""
import hashlib
from .base import LLMProvider, LLMTask


def _seed(s: str) -> int:
    return int(hashlib.md5(s.encode()).hexdigest(), 16)


class MockProvider(LLMProvider):
    def __init__(self, name="mock"):
        self.name = name
        self.kind = "mock"

    def complete(self, task: LLMTask) -> dict:
        handler = getattr(self, f"_h_{task.name}", None)
        if handler:
            data = handler(task)
        else:
            data = {"note": "mock", "task": task.name}
        return {"text": str(data), "json": data, "provider": f"{self.name}(mock)"}

    # --- scoring (DeepSeek role) ---
    def _h_score(self, task):
        s = _seed(task.user)
        fit = 60 + (s % 38)
        timing = 45 + ((s >> 7) % 52)
        return {
            "fit": fit,
            "timing": timing,
            "fit_reasons": [
                "Assortiment en prijstier sluiten aan op het partnerprofiel.",
                "Aanwijzingen voor structurele rest-/showroomstroom.",
            ],
            "timing_reasons": [
                "Recent sale-/uitverkoopsignaal gedetecteerd op de site.",
            ],
            "priority_reason": "Dubbele score boven drempel." if fit >= 78 and timing >= 75 else "Eén as onder drempel.",
        }

    # --- score verification (GPT role, priority A only) ---
    def _h_verify_score(self, task):
        s = _seed(task.user)
        agree = (s % 5) != 0
        return {
            "agree": agree,
            "adjusted_fit": None,
            "adjusted_timing": None if agree else 40,
            "note": "Eens met de scoring." if agree
                    else "GPT ziet het timingsignaal als verlopen; DeepSeek scoorde hoger. Naar founder.",
        }

    # --- outreach writing (GPT role) ---
    def _h_write_outreach(self, task):
        brand = task.meta.get("brand", "Outrun IQ")
        name = task.meta.get("company", "het bedrijf")
        first = name.split(" ")[0]
        commission = task.meta.get("commission", "10")
        sender = task.meta.get("sender", "Stijn")
        # NOTE: deliberately plant one unprovable claim so the verifier loop is visible in test mode.
        body = (
            f"Beste team van {first},\n\n"
            f"We bouwen momenteel aan {brand}, een nieuw gespecialiseerd outletplatform voor "
            f"overstock en showroommodellen. Bij het in kaart brengen van de markt kwamen jullie "
            f"naar voren: jullie zijn de grootste in de regio en werken duidelijk met wisselende "
            f"rest- en showroompartijen.\n\n"
            f"Het model is simpel: KvK-geverifieerde partners verkopen restvoorraad, wij rekenen "
            f"{commission}% commissie \u2014 geen vaste kosten. Ik denk dat dit goed bij jullie zou passen.\n\n"
            f"Zou een kort gesprek volgende week schikken?\n\n"
            f"Met vriendelijke groet,\n{sender} \u2014 {brand}"
        )
        return {
            "subject": f"Nieuw gespecialiseerd outletplatform \u2014 past {first} hierbij?",
            "body": body,
        }

    # --- claim verification (DeepSeek role) ---
    def _h_verify_claims(self, task):
        flags = []
        if "grootste in de regio" in task.user:
            flags.append({
                "quote": "jullie zijn de grootste in de regio",
                "reason": "Niet gedekt door het bewijs \u2014 geen marktaandeel-signaal gevonden.",
            })
        return {"flags": flags}

    # --- reply classification (DeepSeek role) ---
    def _h_classify_reply(self, task):
        t = task.user.lower()
        if any(w in t for w in ["interessant", "hoe werkt", "graag", "vertel", "bel"]):
            intent = "HOT"
        elif "later" in t or "druk" in t or "geen tijd" in t:
            intent = "NOT_NOW"
        elif "?" in t:
            intent = "QUESTION"
        elif "nee" in t or "geen interesse" in t:
            intent = "NO"
        else:
            intent = "WARM"
        return {"intent": intent, "summary": "Automatisch geclassificeerd (mock)."}

    # --- synthetic reply generation (test loop) ---
    def _h_synthetic_reply(self, task):
        s = _seed(task.user)
        personas = [
            ("HOT", "Klinkt interessant \u2014 hoe werkt die 10% commissie precies?"),
            ("QUESTION", "Bedankt voor jullie bericht. Wie zijn er nog meer aangesloten?"),
            ("NOT_NOW", "Nu even te druk met het seizoen, misschien later dit jaar."),
            ("WARM", "Stuur maar wat meer informatie, dan bekijken we het intern."),
            ("NO", "Bedankt, maar we hebben op dit moment geen interesse."),
        ]
        intent, body = personas[s % len(personas)]
        return {"intent": intent, "body": body}

    # --- vision scan (GPT role) ---
    def _h_vision_scan(self, task):
        return {"observations": ["Outlet-/sale-elementen zichtbaar in de layout (mock vision)."]}
