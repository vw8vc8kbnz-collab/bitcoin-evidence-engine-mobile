"""
Company Master Database.

Purpose:
- Keep a permanent local KvK/company base across deployments.
- Build/refresh the cheap pre-filter without paid AI or deep search.
- Support CSV imports from real KvK/open-data exports later.

This file deliberately does NOT call LLMs and does NOT deep crawl websites.
"""
import csv
import io
import random
import time
from .. import db, config

SECTORS = [
    "Wonen", "Meubelen", "Slapen", "Tuinmeubelen", "Verlichting", "Sanitair",
    "Keukens", "Vloeren", "Elektronica", "Witgoed", "Fietsen", "Sport",
    "Baby", "Kantoor", "Gereedschap", "Interieur", "Badkamers", "Outdoor"
]
CITIES = [
    "Amsterdam", "Rotterdam", "Utrecht", "Eindhoven", "Groningen", "Zwolle", "Almere",
    "Breda", "Tilburg", "Arnhem", "Nijmegen", "Apeldoorn", "Haarlem", "Den Bosch",
    "Leeuwarden", "Amersfoort", "Enschede", "Dordrecht", "Leiden", "Maastricht"
]
PREFIX = ["Deco", "Tuin", "Woon", "Home", "Comfort", "Interieur", "Outlet", "Design", "Mega", "Direct", "Studio", "Voorraad", "Rest", "Nordic", "Urban"]
SUFFIX = ["Living", "Outdoor", "Comfort", "Design", "Depot", "Store", "Outlet", "Interieur", "Market", "Studio", "Plus", "Wereld", "Plein", "Huis"]

IRRELEVANT_HINTS = ("holding", "beheer", "administratie", "advies", "consultancy", "vereniging", "stichting")
GOOD_SECTORS = {s.lower() for s in SECTORS}


def _company_type(size):
    try:
        n = int(size or 0)
    except Exception:
        return "unknown"
    if n <= 0:
        return "unknown"
    if n <= 10:
        return "small"
    if n <= 50:
        return "medium"
    if n <= 250:
        return "large"
    return "enterprise"


def _active_status(row):
    name = (row.get("name") or "").lower()
    if any(x in name for x in ("failliet", "opgeheven", "liquidatie")):
        return "inactive"
    # Without live KvK status this is a conservative status. It means: active-looking.
    if row.get("kvk") and row.get("name"):
        return "active"
    return "low_confidence"


def _relevance(row):
    name = (row.get("name") or "").lower()
    sector = (row.get("sector") or "").lower()
    if any(x in name for x in IRRELEVANT_HINTS):
        return "irrelevant"
    if sector in GOOD_SECTORS or any(w in name for w in ("outlet", "wonen", "meubel", "tuin", "sanitair", "keuken", "lamp", "fiets", "sport")):
        return "candidate"
    return "unreviewed"


def upsert_company(comp, source="master"):
    now = time.time()
    kvk = str(comp.get("kvk") or "").strip()
    if not kvk:
        return None, False
    size = comp.get("size") or comp.get("employees") or None
    try:
        size = int(size) if size not in (None, "", "?") else None
    except Exception:
        size = None
    row = {
        "kvk": kvk,
        "name": (comp.get("name") or comp.get("handelsnaam") or "").strip(),
        "city": (comp.get("city") or comp.get("plaats") or "").strip(),
        "sector": (comp.get("sector") or comp.get("sbi") or comp.get("branche") or "").strip(),
        "website": (comp.get("website") or "").strip(),
        "size": size,
    }
    if not row["name"]:
        return None, False
    active = _active_status(row)
    rel = _relevance(row)
    ctype = _company_type(size)
    with db.get_conn() as c:
        existing = c.execute("SELECT id FROM companies WHERE tenant_id=? AND kvk=?", (config.TENANT, kvk)).fetchone()
        if existing:
            c.execute("""UPDATE companies SET name=?, city=COALESCE(NULLIF(?,''),city), sector=COALESCE(NULLIF(?,''),sector),
                         website=COALESCE(NULLIF(?,''),website), size=COALESCE(?,size), source=COALESCE(source,?),
                         active_status=?, relevance_status=?, company_type=?, last_basic_check=?
                       WHERE id=?""",
                      (row["name"], row["city"], row["sector"], row["website"], size, source, active, rel, ctype, now, existing["id"]))
            return existing["id"], False
        cur = c.execute("""INSERT INTO companies(tenant_id,kvk,name,city,sector,website,size,source,active_status,relevance_status,company_type,last_basic_check,stage,created_at)
                         VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                      (config.TENANT, kvk, row["name"], row["city"], row["sector"], row["website"], size, source, active, rel, ctype, now, "discovered", now))
        return cur.lastrowid, True


def bootstrap_generated(limit=None):
    """Generated fallback for testing the master database without burning APIs.

    Real production path: import a KvK/open-data CSV. This fallback proves the
    10k-local-master/filter workflow on the VPS.
    """
    limit = int(limit or config.MASTER_BATCH_SIZE)
    added = 0
    updated = 0
    rng = random.Random(1337)
    for i in range(limit):
        sector = SECTORS[i % len(SECTORS)]
        city = CITIES[(i * 7) % len(CITIES)]
        size = [3, 5, 8, 12, 18, 25, 40, 65, 90, 140, 220, 320, 700, None][(i * 5) % 14]
        name = f"{PREFIX[i % len(PREFIX)]}{SUFFIX[(i * 3) % len(SUFFIX)]} {city}" if i % 3 else f"{PREFIX[i % len(PREFIX)]}{sector} {SUFFIX[(i * 3) % len(SUFFIX)]}"
        kvk = str(61000000 + i).zfill(8)
        website = "" if i % 4 == 0 else f"https://www.{name.lower().replace(' ','-').replace('&','en')}.nl"
        _, is_new = upsert_company({"kvk": kvk, "name": name, "city": city, "sector": sector, "size": size, "website": website}, "generated-master")
        if is_new:
            added += 1
        else:
            updated += 1
    return {"added": added, "updated": updated, "requested": limit}


def import_csv_text(csv_text):
    f = io.StringIO(csv_text)
    sample = f.read(4096)
    f.seek(0)
    dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|") if sample.strip() else csv.excel
    reader = csv.DictReader(f, dialect=dialect)
    added = updated = skipped = 0
    for r in reader:
        norm = {k.strip().lower(): (v or "").strip() for k, v in r.items() if k}
        comp = {
            "kvk": norm.get("kvk") or norm.get("kvknummer") or norm.get("kvk_nummer") or norm.get("dossiernummer"),
            "name": norm.get("naam") or norm.get("handelsnaam") or norm.get("bedrijfsnaam") or norm.get("name"),
            "city": norm.get("plaats") or norm.get("city") or norm.get("woonplaats"),
            "sector": norm.get("sector") or norm.get("branche") or norm.get("sbi") or norm.get("activiteit"),
            "website": norm.get("website") or norm.get("url"),
            "size": norm.get("medewerkers") or norm.get("werknemers") or norm.get("size") or norm.get("aantal_werkzame_personen"),
        }
        cid, is_new = upsert_company(comp, "csv-import")
        if not cid:
            skipped += 1
        elif is_new:
            added += 1
        else:
            updated += 1
    return {"added": added, "updated": updated, "skipped": skipped}


def basic_analyze_all():
    now = time.time()
    changed = 0
    with db.get_conn() as c:
        rows = c.execute("SELECT * FROM companies WHERE tenant_id=?", (config.TENANT,)).fetchall()
        for r in rows:
            row = dict(r)
            active = _active_status(row)
            rel = _relevance(row)
            ctype = _company_type(row.get("size"))
            c.execute("UPDATE companies SET active_status=?, relevance_status=?, company_type=?, last_basic_check=? WHERE id=?",
                      (active, rel, ctype, now, row["id"]))
            changed += 1
    return {"checked": changed, "ai_cost": 0}
