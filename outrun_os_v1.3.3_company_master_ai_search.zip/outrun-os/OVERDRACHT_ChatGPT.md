# Overdracht — Outrun OS v1.3.3 Company Master + AI Zoekfunctie

Deze build zet de architectuur om naar een permanente lokale bedrijfsbasis.

## Wat is nieuw

1. **Company Master Database**
   - Bedrijven blijven lokaal in `outrun_os.db` staan.
   - Updates mogen de DB niet overschrijven.
   - Velden toegevoegd: `active_status`, `relevance_status`, `company_type`, `last_basic_check`.

2. **10k master bootstrap**
   - Knop: `master vullen 10k`.
   - Geen AI, geen betaalde API.
   - Bedoeld als test/fallback om de workflow met grote aantallen te testen.
   - Productieroute moet later een echte KvK/open-data CSV importeren.

3. **CSV-import voorbereid**
   - Endpoint: `POST /api/master/import-csv`.
   - Accepteert kolommen zoals `kvk`, `naam`, `plaats`, `sector`, `website`, `medewerkers`.
   - Upsert op KvK, dus geen duplicaten.

4. **Basic Analyse**
   - Endpoint: `POST /api/master/basic-analyze`.
   - Draait lokaal/regelloos zonder AI.
   - Detecteert actief-looking/inactief-looking, kandidaat/irrelevant, groottebucket.

5. **No-cost AI zoekfunctie**
   - Zoekbalk begrijpt natuurlijke zinnen zonder LLM-call.
   - Voorbeelden:
     - `actieve middelgrote wonen bedrijven zonder deep search`
     - `groot sanitair >50`
     - `enterprise elektronica met deep search`

6. **Kostenprincipe blijft vast**
   - Geen 24/7 AI.
   - Geen automatische deep searches.
   - AI pas bij handmatige deep search / mailgeneratie / reply.

## Belangrijk voor deployment

Gebruik altijd rsync/unzip waarbij database/data behouden blijven:

```bash
rsync -a --exclude ".env" --exclude "outrun_os.db*" --exclude "data/" outrun-os/ /home/ubuntu/outrun-os/
```

De Termius update-regel moet de exacte GitHub Raw ZIP filename gebruiken.
