#!/usr/bin/env bash
set -euo pipefail
BASE="${BEE_BASE:-/home/ubuntu/bitcoin-engine-deploy/current}"
cd "$BASE/live_forecast"
if [ -f "$BASE/.venv/bin/activate" ]; then
  source "$BASE/.venv/bin/activate"
elif [ -f ".venv/bin/activate" ]; then
  source ".venv/bin/activate"
fi
python bee_live_forecast_v4_1_paper.py --export-debug
ls -lah /home/ubuntu/bee_latest_export.zip || true
