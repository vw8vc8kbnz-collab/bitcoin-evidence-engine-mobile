#!/usr/bin/env bash
set -euo pipefail
BASE="${BEE_BASE:-/home/ubuntu/bitcoin-engine-deploy/current}"
HOME_EXPORT="/home/ubuntu/bee_latest_export.zip"
cd "$BASE"
echo "[1/6] Installing live forecast..."
chmod +x scripts/install_live_forecast.sh
./scripts/install_live_forecast.sh
cd "$BASE/live_forecast"
if [ -f "$BASE/.venv/bin/activate" ]; then
  source "$BASE/.venv/bin/activate"
elif [ -f ".venv/bin/activate" ]; then
  source ".venv/bin/activate"
fi
echo "[2/6] Checking script version/options..."
python bee_live_forecast_v4_1_paper.py --help | grep -E "test-trade-ntfy|export-debug|inspect-live-data" || true
echo "[3/6] Testing live data fetch..."
python bee_live_forecast_v4_1_paper.py --test-fetch
echo "[4/6] Testing synthetic paper trade ntfy alert..."
python bee_live_forecast_v4_1_paper.py --test-trade-ntfy || echo "WARN: ntfy trade test failed; continuing to export debug bundle."
echo "[5/6] Creating debug export ZIP..."
python bee_live_forecast_v4_1_paper.py --export-debug
echo "[6/6] Verifying simple download path..."
ls -lah "$HOME_EXPORT"
echo ""
echo "EXPORT READY: $HOME_EXPORT"
echo "Open Termius SFTP -> home -> ubuntu -> bee_latest_export.zip"
