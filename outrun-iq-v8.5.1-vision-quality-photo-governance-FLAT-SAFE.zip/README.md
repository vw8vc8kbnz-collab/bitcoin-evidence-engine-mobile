# Outrun IQ v8.5.1 — Vision Quality & Photo Governance

Deze versie bouwt voort op v8.5.0 en maakt de AI-fotoherkenning praktischer voor echte partners.

## Belangrijkste wijziging
Partners kunnen per product maximaal 5 foto’s uploaden. De aanbevolen set is:

1. Hoofdfoto
2. Tweede hoek / zijkant
3. Conditie of schade-detail
4. Accessoires of verpakking
5. Label / artikelnummer / serienummer

Vision gebruikt alle foto’s voor herkenning, prijsadvies en metadata, maar label-/serienummerfoto’s worden niet automatisch aan buyers getoond. Ze worden intern gebruikt voor AI/OCR, tenzij ze echt nodig zijn voor de listing.

## Vision configuratie
Vision staat alleen aan wanneer de server expliciet is geconfigureerd met een multimodale provider:

```env
VISION_MODEL=gpt-4o-mini
VISION_BASE_URL=https://api.openai.com/v1/chat/completions
VISION_API_KEY=...
```

Zonder deze waarden blijft fotoherkenning netjes uit en vult de partner de listing handmatig in.

## Deploy
Flat ZIP: `package.json` staat in de root. Gebruik de Termius update-regel uit de chat.
