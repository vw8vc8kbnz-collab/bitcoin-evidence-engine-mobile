# Changelog — Outrun IQ v8.5.1

## v8.5.1 — Vision Quality & Photo Governance

Correctie/kwaliteitstap na v8.5.0. Doel: AI mag niet blijven hangen op generieke labels zoals “motorfiets” als merk/model of modelkandidaten zichtbaar of sterk aannemelijk zijn. Daarnaast is fotobeheer begrensd zodat API-kosten beheersbaar blijven.

### Gebouwd
- Maximaal 5 productfoto’s per listing in partner-uploadflow én server upload API.
- Vision-prompt aangescherpt voor merk/modelherkenning, inclusief voertuigen/motoren: bij onzekerheid geeft AI modelkandidaten en vraagt extra foto’s zoals tanklogo, dashboard/typeplaatje of zijkap.
- Vision-output uitgebreid met `modelCandidates`, `articleNumber`, `serialMasked`, `ocrText`, `confidence`, `needsExtraPhotos` en `photoRoles`.
- AI/OCR label-, serienummer- en artikelnummerfoto’s worden als interne metadata gebruikt en hoeven niet automatisch buyer-facing in de productgalerij te komen.
- Partner ziet nu bij toevoegen welke foto’s openbaar worden en welke intern voor AI/OCR blijven.
- Listing opslag ondersteunt `internalPhotos` en `visionMetadata`, inclusief gemaskeerde serienummers en photo governance.
- Publicatie stuurt alleen de door AI/governance gekozen openbare foto’s naar buyers; interne label/OCR-foto’s blijven buiten de publieke galerij.

### Checks
- `npx tsc --noEmit` OK na `npm install`.
