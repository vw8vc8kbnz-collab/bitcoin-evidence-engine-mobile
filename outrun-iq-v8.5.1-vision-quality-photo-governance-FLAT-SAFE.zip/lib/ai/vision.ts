/** Vision-taakroute van de AI Model Abstraction Layer.
 *
 * Belangrijk: vision wordt bewust NIET meer stil naar DeepSeek-text teruggezet.
 * Zet expliciet VISION_API_KEY + VISION_MODEL op een multimodaal model
 * (bijv. OpenAI gpt-4o-mini of een EU multimodaal model). Zonder die env-vars
 * blijft vision uit en vult de partner de velden handmatig in.
 */

export type VisionFields = {
  title: string;
  brand: string;
  model: string;
  category: "witgoed" | "meubels" | "keukens" | "tuin" | "overig";
  color: string;
  condition: string;
  conditionScore: number;     // 1-10
  conditionReason: string;    // korte verdedigbare motivatie
  defect: string;             // leeg = geen zichtbaar gebrek
  defects: string[];          // per-foto schade/gebrek observaties
  accessories: string[];
  energyLabel: string;
  newPriceEstimate: number;   // geschatte adviesprijs in hele euro's, 0 = onbekend
  sellingPoints: string[];
  modelCandidates: string[];
  articleNumber: string;
  serialMasked: string;
  ocrText: string;
  confidence: number;
  needsExtraPhotos: string[];
  photoRoles: { index: number; role: "hero" | "angle" | "condition" | "accessories" | "label" | "serial" | "packaging" | "irrelevant"; buyerFacing: boolean; reason?: string }[];
  uncertainty: boolean;
  source: string;
};

const CATS = ["witgoed", "meubels", "keukens", "tuin", "overig"] as const;

function num(x: unknown): number {
  if (typeof x === "number" && isFinite(x)) return Math.round(x);
  if (typeof x === "string") {
    const v = parseFloat(x.replace(/[^\d,.-]/g, "").replace(/\.(?=\d{3}\b)/g, "").replace(",", "."));
    if (isFinite(v)) return Math.round(v);
  }
  return 0;
}
function str(x: unknown, max = 160): string { return String(x ?? "").slice(0, max).trim(); }
function arr(x: unknown, maxItems = 5, maxLen = 90): string[] {
  return Array.isArray(x) ? x.map(v => str(v, maxLen)).filter(Boolean).slice(0, maxItems) : [];
}
function roles(x: unknown, maxPhotos = 5): VisionFields["photoRoles"] {
  if (!Array.isArray(x)) return [];
  const allowed = new Set(["hero", "angle", "condition", "accessories", "label", "serial", "packaging", "irrelevant"]);
  return x.map((v, i) => {
    const o = (v && typeof v === "object") ? v as Record<string, unknown> : {};
    const idx = Math.min(maxPhotos, Math.max(1, num(o.index) || (i + 1)));
    const role = allowed.has(String(o.role)) ? String(o.role) as VisionFields["photoRoles"][number]["role"] : "angle";
    const buyerFacing = typeof o.buyerFacing === "boolean" ? o.buyerFacing : !["label", "serial", "irrelevant"].includes(role);
    return { index: idx, role, buyerFacing, reason: str(o.reason, 80) || undefined };
  }).filter(x => x.index >= 1 && x.index <= maxPhotos).slice(0, maxPhotos);
}

export function isVisionConfigured() {
  return Boolean(process.env.VISION_API_KEY && process.env.VISION_MODEL);
}

export async function analyzeProductPhotos(dataUrls: string[]): Promise<VisionFields | null> {
  const key = process.env.VISION_API_KEY;
  const model = process.env.VISION_MODEL;
  if (!key || !model) {
    console.error("[ai-vision] uitgeschakeld: VISION_API_KEY en VISION_MODEL zijn verplicht voor beeldherkenning.");
    return null;
  }
  const api = process.env.VISION_BASE_URL || "https://api.openai.com/v1/chat/completions";
  const images = dataUrls.filter(Boolean).slice(0, 5);
  if (!images.length) return null;

  const sys = `Je bent de productherkenning van Outrun IQ, een Nederlandse outlet-marketplace. Je krijgt maximaal 5 foto's van hetzelfde product. Foto 1 is meestal de hoofdproductfoto; latere foto's kunnen zijkant, verpakking, label, serienummer, artikelnummer of schade tonen. Beoordeel merk, model, conditie en gebreken op basis van ALLE foto's. Antwoord UITSLUITEND met geldige JSON, exact deze sleutels:
{"title":"","brand":"","model":"","category":"","color":"","condition":"","conditionScore":0,"conditionReason":"","defect":"","defects":[],"accessories":[],"energyLabel":"","newPriceEstimate":0,"sellingPoints":[],"modelCandidates":[],"articleNumber":"","serialMasked":"","ocrText":"","confidence":0,"needsExtraPhotos":[],"photoRoles":[],"uncertainty":false}
Regels: title = korte Nederlandse producttitel incl. merk en model/kandidaat indien zichtbaar of sterk aannemelijk, max 80 tekens. Wees NIET generiek als er meer herkenbaar is: schrijf niet alleen "motorfiets", "stoel" of "koptelefoon" als merk/model/type te herkennen of sterk waarschijnlijk is. Voor voertuigen/motoren: kijk naar tankbadge, spatborden, motorblok, koffers, zadel, velgen en stijl; geef brand/model als zeker genoeg, anders 2-4 modelCandidates plus needsExtraPhotos zoals "foto van tanklogo", "dashboard/typeplaatje" of "zijkap". brand/model alleen als zichtbaar of sterk waarschijnlijk; onzekerheid = true wanneer model niet hard genoeg is. category = precies één uit: witgoed, meubels, keukens, tuin, overig. condition = korte NL conditietekst van wat je ziet. conditionScore 1-10; onzeker = 7. conditionReason = verdedigbare motivatie in één zin. defect = belangrijkste zichtbaar gebrek of leeg. defects = max 5 bullets met per foto wat opvalt, bijv. "foto 3: kras rechts". accessories = zichtbare accessoires/verpakking. energyLabel = energielabel indien zichtbaar. articleNumber = artikelnummer/SKU/EAN/modelcode indien zichtbaar via OCR. serialMasked = serienummer alleen gemaskeerd, bijv. "****1234". ocrText = korte relevante OCR-samenvatting, geen volledige lange tekst. confidence = 0-100 voor merk/model/titel. photoRoles = array met per foto {index, role, buyerFacing, reason}; role één van hero, angle, condition, accessories, label, serial, packaging, irrelevant. Label/serial/barcodefoto's zijn normaal buyerFacing=false: gebruik intern voor AI/OCR, niet in de openbare galerij tenzij ze essentieel zijn. newPriceEstimate = realistische Nederlandse nieuwprijs in hele euro's, 0 = onbekend. sellingPoints = 2-3 korte verkoopargumenten. Verzin geen typenummers, labels of schade die je niet ziet.`;

  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), 30_000);
  try {
    const content: any[] = [
      { type: "text", text: `Analyseer deze ${images.length} foto('s) als één product. Gebruik alle foto's, inclusief label-, artikelnummer-, schade- en detailfoto's. Bepaal ook welke foto's openbaar naar buyers mogen en welke intern moeten blijven.` },
      ...images.flatMap((url, idx) => ([
        { type: "text", text: `Foto ${idx + 1}` },
        { type: "image_url", image_url: { url } },
      ])),
    ];
    const res = await fetch(api, {
      method: "POST",
      signal: ctl.signal,
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
      body: JSON.stringify({
        model,
        temperature: 0.1,
        response_format: { type: "json_object" },
        messages: [
          { role: "system", content: sys },
          { role: "user", content },
        ],
      }),
    });
    if (!res.ok) {
      console.error("[ai-vision] provider weigerde:", res.status, (await res.text().catch(() => "")).slice(0, 400));
      return null;
    }
    const data = await res.json();
    const raw = String(data?.choices?.[0]?.message?.content ?? "");
    const p = JSON.parse(raw.replace(/```json|```/g, "").trim());
    const cat = CATS.includes(p.category) ? p.category : "overig";
    const score = Math.min(10, Math.max(1, num(p.conditionScore) || 7));
    const defects = arr(p.defects, 5, 100);
    const out: VisionFields = {
      title: str(p.title, 70),
      brand: str(p.brand, 40),
      model: str(p.model, 50),
      category: cat,
      color: str(p.color, 30),
      condition: str(p.condition, 140),
      conditionScore: score,
      conditionReason: str(p.conditionReason, 180),
      defect: str(p.defect, 120) || defects[0] || "",
      defects,
      accessories: arr(p.accessories, 5, 60),
      energyLabel: str(p.energyLabel, 20),
      newPriceEstimate: Math.max(0, num(p.newPriceEstimate)),
      sellingPoints: arr(p.sellingPoints, 3, 70),
      modelCandidates: arr(p.modelCandidates, 4, 70),
      articleNumber: str(p.articleNumber, 60),
      serialMasked: str(p.serialMasked, 30),
      ocrText: str(p.ocrText, 220),
      confidence: Math.min(100, Math.max(0, num(p.confidence) || (p.uncertainty ? 55 : 75))),
      needsExtraPhotos: arr(p.needsExtraPhotos, 4, 80),
      photoRoles: roles(p.photoRoles, images.length),
      uncertainty: Boolean(p.uncertainty),
      source: String(data?.model ?? model),
    };
    return out.title ? out : null;
  } catch (e) {
    console.error("[ai-vision] fout:", e);
    return null;
  } finally { clearTimeout(t); }
}

export async function analyzeProductPhoto(dataUrl: string): Promise<VisionFields | null> {
  return analyzeProductPhotos([dataUrl]);
}
