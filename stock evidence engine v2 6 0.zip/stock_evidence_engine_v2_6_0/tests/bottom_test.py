import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import engine as E, pandas as pd, numpy as np
n=120
close=np.full(n,100.0)
close[60:70]=np.linspace(100,80,10); close[70:78]=np.linspace(80,90,8)
close[78:88]=np.linspace(90,80.5,10); close[88:118]=np.linspace(80.5,96,30)
close[118]=99.0; close[119]=100.5
idx=pd.bdate_range('2026-01-05',periods=n)
df=pd.DataFrame({'Close':close},index=idx)
df['Open']=df['Close'].shift(1).fillna(100); df['High']=df['Close']*1.005; df['Low']=df['Close']*0.995
vol=np.full(n,1_000_000.0); vol[119]=1_600_000; df['Volume']=vol
m=dict(price=100.5,ret3=2,ret5=3,ret20=10,relative_volume=1.6,rs_vs_bench=0,position_52w=50,technical_score=60,above_ma20=True,above_ma50=True,ret1=1)
rows,_=E.setup_rows('BTM',df,m)
br=[r for r in rows if r['setup']=='bottom_reversal']
assert br and br[0]['signal_active_today']==1
df2=df.copy(); df2['Volume']=1_000_000.0
rows2,_=E.setup_rows('BTM',df2,m)
assert [r for r in rows2 if r['setup']=='bottom_reversal'][0]['signal_active_today']==0
print('BOTTOM REVERSAL: PASS (W-bodem + breakout + volume-eis)')
