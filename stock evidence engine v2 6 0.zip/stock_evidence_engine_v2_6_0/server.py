#!/usr/bin/env python3
"""SEE v2.0.0 dashboard server.
- Redesigned dark quant-terminal UI (amber=live attention, teal=validated edge).
- read_csv falls back to the newest available version so the dashboard is never
  empty right after a version bump.
- Optional token auth (SEE_DASH_TOKEN) + per-IP rate limit on Stock Lab so an
  open port cannot burn the DeepSeek budget.
"""
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
import json, csv, html, urllib.parse, os, time, collections, subprocess
VERSION='v2.6.0'; BASE=Path(__file__).resolve().parent; OUT=BASE/'output'; PORT=8798
SCAN_LOCK=OUT/'scan.lock'; SCAN_LOG=OUT/'scan.log'

def _scan_running():
    """True if a scan started via the dashboard (or its pid) is still alive."""
    try:
        pid=int(SCAN_LOCK.read_text().strip())
        os.kill(pid,0)
        return True
    except Exception:
        try: SCAN_LOCK.unlink()
        except Exception: pass
        return False

def start_scan():
    if _scan_running(): return False,'scan draait al'
    OUT.mkdir(exist_ok=True)
    logf=open(SCAN_LOG,'w')
    p=subprocess.Popen(['bash', str(BASE/'run_backtest.sh')], cwd=str(BASE), stdout=logf, stderr=subprocess.STDOUT)
    SCAN_LOCK.write_text(str(p.pid))
    return True,'scan gestart'

def scan_status():
    tail=''
    try:
        lines=SCAN_LOG.read_text(encoding='utf-8', errors='ignore').splitlines()
        tail='\n'.join(lines[-12:])
    except Exception: pass
    return {'running':_scan_running(),'last_run':last_run_info(),'log_tail':tail}
try:
    import engine as see_engine
except Exception:
    see_engine=None

DASH_TOKEN=os.getenv('SEE_DASH_TOKEN','').strip()
_LAB_HITS=collections.defaultdict(list)  # ip -> [timestamps]
LAB_RATE_MAX=int(os.getenv('SEE_STOCK_LAB_MAX_PER_HOUR','12'))

def read_csv(name_pattern):
    """Exact-version file first; otherwise newest matching any version.
    v1.9.2 showed an empty dashboard after every version bump."""
    files=list(OUT.glob(name_pattern))
    if not files:
        generic=name_pattern.replace(VERSION,'v*')
        files=sorted(OUT.glob(generic), key=lambda p:p.stat().st_mtime, reverse=True)
    if not files: return []
    try:
        with files[0].open(encoding='utf-8') as f:
            rows=list(csv.DictReader(f))
            return [] if (rows and list(rows[0].keys())==['empty']) else rows
    except Exception: return []

def fnum(x):
    try: return float(x or 0)
    except Exception: return 0.0

def uniq(rows, key='ticker'):
    return len({r.get(key) for r in rows if r.get(key)})

def last_run_info():
    try:
        d=json.loads((OUT/'last_run.json').read_text())
        return d.get('generated_at','')[:16].replace('T',' ')+' UTC'
    except Exception:
        return 'nog geen run'

def esc(x): return html.escape(str(x if x not in (None,'') else '—'))

def bar(value, color):
    v=max(0,min(100,fnum(value)))
    return f"<div class='bar'><i style='width:{v}%;background:{color}'></i></div>"

def chips(warn):
    parts=[w for w in str(warn or '').split(';') if w]
    return ''.join(f"<span class='chip'>{esc(w)}</span>" for w in parts[:4])

def card(r, ai_map=None, mode='live'):
    ai_map=ai_map or {}; ai=ai_map.get(r.get('ticker'), {})
    t=esc(r.get('ticker','?')); theme=esc(r.get('theme',''))
    if mode=='validated':
        score=fnum(r.get('validation_score'))
        label='VALIDATED EDGE' if str(r.get('validated_edge','0'))=='1' else 'RESEARCH'
        accent='var(--teal)'
        sub=f"n_eff {esc(r.get('n_eff'))} · avg {esc(r.get('avg_nonoverlap'))}% · excess {esc(r.get('excess_vs_drift'))}% · excess CI low {esc(r.get('excess_ci90_low'))}"
    else:
        score=fnum(r.get('live_attention_score') or r.get('hybrid_signal_score') or r.get('final_score'))
        label='LIVE EXTREME' if str(r.get('live_extreme','0'))=='1' else 'LIVE ELITE' if str(r.get('live_elite','0'))=='1' else 'HYBRID' if str(r.get('hybrid_watchlist','0'))=='1' else esc(r.get('ai_tier') or '')
        accent='var(--amber)'
        sub=f"AI {esc(r.get('ai_final_score'))} · val {esc(r.get('validation_score'))} · priced-in {esc(r.get('priced_in_risk'))}"
    ev=esc(ai.get('event_type') or r.get('setup') or '')
    reason=esc(str(ai.get('reasoning') or r.get('reasoning') or ''))[:280]
    return f"""<div class='card'><div class='top'><div><b>{t}</b> <span class='theme'>{theme}</span></div><span class='tag' style='color:{accent};border-color:{accent}'>{label}</span></div>
<div class='num' style='color:{accent}'>{score:.1f}</div>{bar(score,accent)}
<div class='muted mono'>{sub}</div><div class='muted'>{ev} · {esc(r.get('setup',''))} {esc(r.get('hold_days'))}d</div>
<div class='chips'>{chips(r.get('validation_warning'))}</div><p>{reason}</p></div>"""

def css():
    return """<style>
:root{--bg:#0B1220;--panel:#121B2E;--panel2:#0F1728;--line:#1E2A44;--text:#E7EDF7;--muted:#8FA0BC;--amber:#F5A524;--teal:#2DD4BF;--rose:#FB7185;--mono:ui-monospace,'SF Mono',Menlo,monospace}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;-webkit-font-smoothing:antialiased}
.wrap{max-width:1180px;margin:auto;padding:16px}
.hero{border:1px solid var(--line);background:linear-gradient(180deg,#15203A,#0F1728);border-radius:18px;padding:22px;margin-bottom:14px}
.hero h1{margin:8px 0 4px;font-size:26px;letter-spacing:-.03em}
.pill{display:inline-block;border:1px solid var(--line);color:var(--muted);padding:5px 10px;border-radius:999px;font-size:12px;font-family:var(--mono)}
.pill.run{color:var(--teal)}
.legend{display:flex;gap:14px;flex-wrap:wrap;margin-top:10px;font-size:13px;color:var(--muted)}
.dot{display:inline-block;width:9px;height:9px;border-radius:99px;margin-right:5px;vertical-align:1px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:8px;margin:10px 0}
.metric{background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:12px}
.metric b{font-size:22px;font-family:var(--mono);display:block}
.metric span{color:var(--muted);font-size:12px}
.metric em{display:block;color:var(--muted);font-style:normal;font-size:11px;margin-top:3px;opacity:.8}
.section{font-size:17px;margin:22px 2px 8px;letter-spacing:-.01em;color:var(--text)}
.section small{color:var(--muted);font-weight:400;margin-left:8px}
.card,.note,.best{background:var(--panel);border:1px solid var(--line);border-radius:16px;padding:14px;margin-bottom:10px}
.note{color:var(--muted);font-size:13px;line-height:1.5}
.top{display:flex;justify-content:space-between;gap:8px;align-items:center}
.top b{font-size:19px}
.theme{color:var(--muted);font-size:11px;font-family:var(--mono)}
.tag{border:1px solid;padding:4px 9px;border-radius:999px;font-weight:700;font-size:11px;font-family:var(--mono);white-space:nowrap}
.num{font-size:32px;font-weight:800;font-family:var(--mono);margin:6px 0 4px}
.bar{height:5px;background:var(--panel2);border-radius:99px;overflow:hidden;margin-bottom:8px}
.bar i{display:block;height:100%;border-radius:99px}
.muted{color:var(--muted);font-size:12.5px;margin:2px 0}
.mono{font-family:var(--mono)}
.chips{margin:6px 0}
.chip{display:inline-block;background:#2A1A22;color:var(--rose);border:1px solid #4A2433;border-radius:999px;padding:2px 8px;font-size:10.5px;font-family:var(--mono);margin:2px 3px 0 0}
p{line-height:1.45;font-size:13.5px;margin:8px 0 0}
.cols{display:grid;grid-template-columns:1fr 1fr;gap:12px}
a.btn,button{display:inline-block;text-decoration:none;background:var(--text);color:var(--bg);padding:11px 14px;border-radius:12px;font-weight:800;margin-top:10px;border:0;font-size:14px}
.search{display:flex;gap:8px;margin-top:12px}
.search input{flex:1;border:1px solid var(--line);background:var(--panel2);color:var(--text);border-radius:12px;padding:13px;font-size:16px}
.search button{background:var(--teal);color:#04211D;margin-top:0}
.scanbtn{background:var(--amber);color:#231602}
.scanbtn:disabled{opacity:.5}
.best{border-color:#2A3B5F;background:linear-gradient(180deg,#16233F,#111B30)}
.best .split{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:8px}
.best h3{margin:0;font-size:14px;color:var(--muted);font-weight:600}
.scoregrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:8px}
.scorepill{background:var(--panel2);border:1px solid var(--line);border-radius:12px;padding:10px}
.scorepill b{font-size:20px;display:block;font-family:var(--mono)}
.scorepill{font-size:11.5px;color:var(--muted)}
.pre{white-space:pre-wrap;font-family:var(--mono);font-size:11.5px;color:var(--muted)}
ul{margin:6px 0;padding-left:18px}li{margin:4px 0;font-size:13px}
details summary{cursor:pointer;color:var(--muted)}
@media(max-width:760px){.cols{grid-template-columns:1fr}.best .split{grid-template-columns:1fr}.search{flex-direction:column}.hero{padding:16px}}
</style>"""

def lab_form():
    return """<div class='search'><form style='display:contents' action='/stock_lab' method='get'><input name='ticker' placeholder='Stock Search Lab — typ een ticker: PLTR, IRDM, RGTI...' autocomplete='off'><button type='submit'>Analyze</button></form></div>"""

def best_now_card(hybrid, live_t, ai_map):
    pick=None; source=''
    if hybrid: pick=hybrid[0]; source='Hybrid: live aandacht + gevalideerde edge'
    elif live_t: pick=live_t[0]; source='Sterkste live signaal (niet gevalideerd)'
    if not pick: return "<div class='best'><h3>Beste kans nu</h3><p class='muted'>Nog geen kandidaten. Run een scan.</p></div>"
    t=esc(pick.get('ticker')); ai=ai_map.get(pick.get('ticker'),{})
    live=fnum(pick.get('live_attention_score')); val=fnum(pick.get('validation_score'))
    return f"""<div class='best'><h3>Beste kans nu — {esc(source)}</h3>
<div class='top' style='margin-top:6px'><b style='font-size:26px'>{t}</b><span class='theme'>{esc(pick.get('theme'))}</span></div>
<div class='split'>
<div><div class='muted'>Live attention</div><div class='num' style='color:var(--amber)'>{live:.1f}</div>{bar(live,'var(--amber)')}</div>
<div><div class='muted'>Validated edge</div><div class='num' style='color:var(--teal)'>{val:.1f}</div>{bar(val,'var(--teal)')}</div>
</div>
<div class='muted mono'>setup {esc(pick.get('setup'))} {esc(pick.get('hold_days'))}d · n_eff {esc(pick.get('n_eff'))} · excess {esc(pick.get('excess_vs_drift'))}% · AI {esc(pick.get('ai_final_score'))} · priced-in {esc(pick.get('priced_in_risk'))}</div>
<div class='chips'>{chips(pick.get('validation_warning'))}</div>
<p>{esc(str(ai.get('reasoning',''))[:300])}</p></div>"""

def dashboard():
    ai=read_csv(f'see_ai_analyst_{VERSION}.csv')
    live=read_csv(f'see_live_signals_{VERSION}.csv')
    validated=read_csv(f'see_validated_setups_{VERSION}.csv')
    live_t=read_csv(f'see_live_signals_by_ticker_{VERSION}.csv') or live
    validated_t=read_csv(f'see_validated_setups_by_ticker_{VERSION}.csv') or validated
    hybrid=read_csv(f'see_hybrid_watchlist_{VERSION}.csv')
    validation=read_csv(f'see_validation_overlap_{VERSION}.csv')
    final_extreme=read_csv(f'see_final_extreme_{VERSION}.csv')
    qelite=read_csv(f'see_quant_elite_{VERSION}.csv')
    usable=read_csv(f'see_usable_{VERSION}.csv')
    cost=read_csv(f'see_cost_monitor_{VERSION}.csv')
    cm=cost[0] if cost else {}
    ai_map={r.get('ticker'):r for r in ai}
    ai_scores=[fnum(r.get('ai_final_score') or r.get('final_score')) for r in ai]
    ai_high=sum(1 for s in ai_scores if s>=70); ai_elite=sum(1 for s in ai_scores if s>=80)
    live_sorted=sorted(live_t, key=lambda r: fnum(r.get('live_attention_score') or r.get('final_score')), reverse=True)[:20]
    val_sorted=sorted(validated_t, key=lambda r: fnum(r.get('validation_score')), reverse=True)[:20]
    hybrid_sorted=sorted(hybrid, key=lambda r: fnum(r.get('hybrid_signal_score')), reverse=True)[:12]
    risk_high=sum(1 for r in validation if str(r.get('overlap_risk'))=='HIGH')
    low_n=sum(1 for r in validation if fnum(r.get('n_eff'))<10)
    livecards=''.join(card(r, ai_map, 'live') for r in live_sorted) or '<div class="card muted">Nog geen live signals boven de eerlijke drempels. Dat is informatie, geen bug.</div>'
    valcards=''.join(card(r, ai_map, 'validated') for r in val_sorted) or '<div class="card muted">Nog geen setups die hun eigen ticker-drift verslaan met CI-steun. De lat ligt nu waar hij hoort.</div>'
    hybridcards=''.join(card(r, ai_map, 'live') for r in hybrid_sorted) or '<div class="card muted">Nog geen hybrid kandidaten (live hoog + validation support).</div>'
    def m(label,val,sub=''):
        return f"<div class='metric'><b>{esc(val)}</b><span>{esc(label)}</span>{('<em>'+esc(sub)+'</em>') if sub else ''}</div>"
    themes=read_csv(f'see_theme_clusters_{VERSION}.csv')
    if themes:
        theme_cards=''.join(
            f"<div class='card'><b>{esc(r.get('cluster'))}</b> "
            f"<span class='mono' style='color:{'var(--rose)' if fnum(r.get('crowding_risk'))>=70 else 'var(--amber)' if fnum(r.get('crowding_risk'))>=45 else 'var(--muted)'}'>crowding {esc(r.get('crowding_risk'))}</span>"
            f"<div class='muted' style='margin:4px 0'>{esc(r.get('driver'))}</div>"
            f"<div class='mono'>{esc(r.get('tickers'))}</div>"
            + (f"<div class='mono' style='color:var(--teal)'>2e orde: {esc(r.get('second_order'))}</div>" if str(r.get('second_order','')).strip() else '')
            + f"<div class='muted' style='margin-top:4px'>{esc(r.get('note'))}</div></div>"
            for r in themes[:5])
    else:
        theme_cards="<div class='card muted'>Nog geen thema-pass resultaat (verschijnt na de eerstvolgende scan met DeepSeek actief).</div>"
    fwd=read_csv(f'see_forward_log_{VERSION}.csv')
    fwdp=read_csv(f'see_forward_performance_{VERSION}.csv')
    fwd_all=next((r for r in fwdp if r.get('tier')=='ALL'), {})
    def fv(k):
        v=fwd_all.get(k,'')
        return v if str(v).strip() not in ('','None') else '—'
    fwd_recent=fwd[:8]
    if fwd_recent:
        frows=''.join(f"<tr><td class='mono'>{esc(r.get('signal_date'))}</td><td><b>{esc(r.get('ticker'))}</b></td><td class='mono'>{esc(str(r.get('tier','')).replace('_',' '))}</td><td class='mono'>{esc(r.get('setup'))} {esc(r.get('hold_days'))}d</td>"+''.join(f"<td class='mono' style='color:{('var(--teal)' if fnum(r.get(f'ret_{h}d'))>0 else 'var(--rose)') if str(r.get(f'ret_{h}d','')).strip() else 'var(--muted)'}'>{esc(r.get(f'ret_{h}d') if str(r.get(f'ret_{h}d','')).strip() else '…')}</td>" for h in (1,3,5,10))+f"<td class='mono' style='color:{('var(--teal)' if fnum(r.get('plan_ret'))>0 else 'var(--rose)') if str(r.get('plan_ret','')).strip() else 'var(--muted)'}'>{(('WIN ' if fnum(r.get('plan_ret'))>0 else 'LOSS ')+esc(r.get('plan_exit'))+' '+esc(r.get('plan_ret'))+'%') if str(r.get('plan_ret','')).strip() else '…'}</td></tr>" for r in fwd_recent)
        fwd_table=f"<div class='card' style='overflow-x:auto'><table style='width:100%;border-collapse:collapse;font-size:13px'><tr class='muted'><th align='left'>signaal</th><th align='left'>ticker</th><th align='left'>tier</th><th align='left'>setup</th><th>1d%</th><th>3d%</th><th>5d%</th><th>10d%</th><th>plan</th></tr>{frows}</table><div class='muted' style='margin-top:6px'>… = nog niet genoeg handelsdagen verstreken. Rendementen: next-open entry, incl. kosten.</div></div>"
    else:
        fwd_table="<div class='card muted'>Nog geen signalen gelogd. Vanaf nu wordt elk actief signaal (validated + live tiers) vastgelegd en bij elke scan aangevuld met het echte rendement na 1/3/5/10 dagen.</div>"
    fwd_metrics=f"<div class='grid'>{m('Signalen gelogd',fwd_all.get('signals_logged','0'))}{m('Ingevuld 5d',fv('n_5d'))}{m('Gem. 5d %',fv('avg_5d'))}{m('Winrate 5d %',fv('win_5d'))}{m('vs QQQ 5d %',fv('avg_exs_qqq_5d'))}{m('Plan win % (TP/SL)',fv('plan_win'))}{m('TP / SL / tijd', f"{fv('tp_hits')} / {fv('sl_hits')} / {fv('time_exits')}")}</div>"
    return f"""<!doctype html><html lang='nl'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>SEE {VERSION}</title>{css()}</head><body><div class='wrap'>
<div class='hero'><span class='pill'>Stock Evidence Engine {VERSION}</span> <span class='pill run'>laatste run: {esc(last_run_info())}</span>
<h1>Live aandacht is geen bewezen edge. Hier zie je beide, gescheiden.</h1>
<div class='legend'><span><i class='dot' style='background:var(--amber)'></i>Live attention (nu, onbewezen)</span><span><i class='dot' style='background:var(--teal)'></i>Validated edge (historisch, next-open entry, excess vs eigen drift)</span><span><i class='dot' style='background:var(--rose)'></i>Warnings</span></div>
{lab_form()}<a class='btn' href='/exports/all.zip'>Download audit ZIP</a> <button class='btn scanbtn' id='runscan' onclick='runScan()'>Run scan nu</button>
<div class='muted mono' id='scanstatus' style='margin-top:8px'></div>
<script>
async function pollScan(){{
  try{{
    const r=await fetch('/api/run_status'); const s=await r.json();
    const el=document.getElementById('scanstatus'); const btn=document.getElementById('runscan');
    if(s.running){{ el.textContent='Scan draait... laatste log: '+(s.log_tail.split('\\n').pop()||''); btn.disabled=true; setTimeout(pollScan,4000); }}
    else{{ if(btn.disabled){{ el.textContent='Scan klaar. Pagina ververst...'; setTimeout(()=>location.reload(),1500); }} btn.disabled=false; }}
  }}catch(e){{}}
}}
async function runScan(){{
  const el=document.getElementById('scanstatus');
  el.textContent='Scan starten...';
  try{{ const r=await fetch('/api/run_scan'); const s=await r.json(); el.textContent=s.message; pollScan(); }}
  catch(e){{ el.textContent='Starten mislukt: '+e; }}
}}
pollScan();
</script></div>
{best_now_card(hybrid_sorted, live_sorted, ai_map)}
<h2 class='section'>Live Opportunity Mode <small>Yahoo + headlines + DeepSeek, nu</small></h2>
<div class='grid'>{m('AI rows',len(ai))}{m('AI High ≥70',ai_high)}{m('AI Elite ≥80',ai_elite)}{m('Live tickers',uniq(live_t) if live_t else 0)}{m('Extreme + validated',len(final_extreme))}{m('Run cost','$'+str(cm.get('run_cost_usd','0')),'maand ~$'+str(cm.get('monthly_estimate_usd','0')))}</div>
<h2 class='section'>Validation Mode <small>geen AI, geen huidige news, excess-CI vs echte drift</small></h2>
<div class='grid'>{m('Cellen getest',len(validation))}{m('Validated edges',len(validated),f'{uniq(validated)} tickers')}{m('Hybrid watchlist',len(hybrid),f'{uniq(hybrid)} tickers')}{m('High overlap',risk_high)}{m('Lage n_eff',low_n)}{m('Usable',len(usable))}{m('Quant elite',len(qelite))}</div>
<div class='note'><b>Multiple testing:</b> {len(validation)} cellen getest; validated edge = KANDIDAAT op CI-criteria; de FDR-badge (fdr_confirmed) is de goud-standaard die met 2y data zelden haalbaar is. De echte scheidsrechter is Forward Tracking hierboven.</div>
<h2 class='section'>Thema-verbanden <small>cross-ticker pass: clusters, crowding, tweede-orde</small></h2>
{theme_cards}
<h2 class='section'>Forward Tracking <small>out-of-sample: gelogd bij signaal, rendement na 1/3/5/10 dagen — het enige hindsight-vrije bewijs</small></h2>
{fwd_metrics}
{fwd_table}
<h2 class='section'>Hybrid Watchlist <small>live hoog + validation support</small></h2>{hybridcards}
<div class='cols'><div><h2 class='section'>Top Live per ticker</h2>{livecards}</div><div><h2 class='section'>Top Validated per ticker</h2>{valcards}</div></div>
</div></body></html>"""

def stock_lab_page(ticker, fresh=False):
    try:
        if see_engine is None: raise RuntimeError('engine import failed')
        result=see_engine.analyze_single_stock(ticker, '1y', fresh=fresh)
        a=result.get('analysis',{}); m=result.get('market_data',{}); meta=result.get('metadata',{})
        def v(x): return esc(x)
        def join(x): return v(' · '.join(map(str,x)) if isinstance(x,list) else x)
        cache_note=" <span class='pill'>uit cache (&lt;2u)</span> <a class='pill' href='/stock_lab?ticker="+urllib.parse.quote(ticker)+"&fresh=1'>forceer vers</a>" if result.get('from_cache') else ''
        scoregrid=''.join([f"<div class='scorepill'><b>{v(a.get(k))}</b>{label}</div>" for k,label in [('grade','Grade'),('opportunity_score','Opportunity'),('catalyst_strength','Catalyst'),('risk_score','Risk'),('priced_in_risk','Priced-in'),('lowcap_danger_score','Lowcap danger'),('quality_score','Quality'),('tradeability_score','Tradeability')]])
        news=''.join(f"<li>{v(n.get('title'))} <span class='muted mono'>{v(n.get('publisher'))}{(' · '+str(n.get('age_days'))+'d') if n.get('age_days') is not None else ''}</span></li>" for n in result.get('news',[])[:12])
        body=f"""<div class='hero'><span class='pill'>Stock Search Lab {VERSION}</span>{cache_note}<h1>{v(ticker)} — {v(meta.get('longName') or meta.get('shortName') or meta.get('symbol'))}</h1><a class='btn' href='/'>← Dashboard</a>{lab_form()}</div>
<div class='card'><div class='scoregrid'>{scoregrid}</div>
<p class='mono muted'>Market cap {v(meta.get('marketCap'))} · {v(meta.get('sector'))} / {v(meta.get('industry'))} · prijs {v(m.get('price'))}</p>
<p class='mono muted'>ret3 {v(m.get('ret3'))}% · ret20 {v(m.get('ret20'))}% · rel vol {v(m.get('relative_volume'))}x · 52w pos {v(m.get('position_52w'))}%</p>
<p><b>Event:</b> {v(a.get('event_type'))}</p><p><b>Narrative:</b> {v(a.get('narrative'))}</p><p><b>Bull:</b> {join(a.get('bull_case'))}</p><p><b>Bear:</b> {join(a.get('bear_case'))}</p><p><b>Key risks:</b> {join(a.get('key_risks'))}</p><p><b>Wat maakt dit elite:</b> {v(a.get('what_would_make_this_elite'))}</p><p><b>Triggers:</b> {join(a.get('concrete_triggers'))}</p><p><b>Reasoning:</b> {v(a.get('reasoning'))}</p></div>
<h2 class='section'>Headlines</h2><div class='card'><ul>{news}</ul></div>
<details class='card'><summary>Raw JSON</summary><div class='pre'>{v(json.dumps(result, indent=2, default=str))}</div></details>"""
        return f"<!doctype html><html lang='nl'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>{v(ticker)} SEE Lab</title>{css()}</head><body><div class='wrap'>{body}</div></body></html>"
    except Exception as e:
        return f"<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>{css()}</head><body><div class='wrap'><div class='hero'><h1>Stock Search Lab error</h1><a class='btn' href='/'>← Dashboard</a>{lab_form()}</div><div class='card'>{html.escape(str(e))}</div></div></body></html>"

def _client_ip(handler):
    return handler.client_address[0] if handler.client_address else '?'

def _lab_rate_ok(ip):
    now=time.time()
    _LAB_HITS[ip]=[t for t in _LAB_HITS[ip] if now-t<3600]
    if len(_LAB_HITS[ip])>=LAB_RATE_MAX: return False
    _LAB_HITS[ip].append(now); return True

class H(BaseHTTPRequestHandler):
    def _auth_ok(self):
        if not DASH_TOKEN: return True
        qs=urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
        if (qs.get('token') or [''])[0]==DASH_TOKEN: return True
        cookie=self.headers.get('Cookie','')
        return f'see_token={DASH_TOKEN}' in cookie
    def _send(self, code, ctype, body, extra=None):
        extra=dict(extra or {}); extra.setdefault('Cache-Control','no-store, must-revalidate')
        self.send_response(code); self.send_header('Content-Type',ctype); self.send_header('Content-Length',str(len(body)))
        for k,v in (extra or {}).items(): self.send_header(k,v)
        self.end_headers(); self.wfile.write(body)
    def do_HEAD(self): self.send_response(200); self.end_headers()
    def do_GET(self):
        if not self._auth_ok():
            b=b'<html><body style="font-family:sans-serif;background:#0B1220;color:#E7EDF7;padding:40px"><h2>SEE: token vereist</h2><p>Open het dashboard met ?token=JOUW_TOKEN</p></body></html>'
            self._send(401,'text/html; charset=utf-8',b); return
        extra={}
        if DASH_TOKEN:
            qs=urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            if (qs.get('token') or [''])[0]==DASH_TOKEN:
                extra={'Set-Cookie':f'see_token={DASH_TOKEN}; Path=/; Max-Age=2592000; HttpOnly'}
        if self.path.startswith('/api/stock_lab'):
            try:
                if not _lab_rate_ok(_client_ip(self)): raise RuntimeError('rate limit: max %d Stock Lab analyses per uur per IP' % LAB_RATE_MAX)
                qs=urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
                ticker=(qs.get('ticker') or [''])[0].strip().upper()
                fresh=(qs.get('fresh') or ['0'])[0]=='1'
                if not ticker: raise ValueError('missing ticker')
                if see_engine is None: raise RuntimeError('engine import failed')
                result=see_engine.analyze_single_stock(ticker, '1y', fresh=fresh)
                self._send(200,'application/json',json.dumps({'ok':True,'version':VERSION,'result':result}, default=str).encode('utf-8'),extra); return
            except Exception as e:
                self._send(500,'application/json',json.dumps({'ok':False,'version':VERSION,'error':str(e)}).encode('utf-8')); return
        if self.path.startswith('/stock_lab'):
            qs=urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            ticker=(qs.get('ticker') or [''])[0].strip().upper()
            fresh=(qs.get('fresh') or ['0'])[0]=='1'
            if not _lab_rate_ok(_client_ip(self)):
                self._send(429,'text/html; charset=utf-8',f'<html><body style="font-family:sans-serif;background:#0B1220;color:#E7EDF7;padding:40px"><h2>Rate limit</h2><p>Max {LAB_RATE_MAX} Stock Lab analyses per uur per IP. Cached resultaten blijven beschikbaar.</p><a href="/" style="color:#2DD4BF">← Dashboard</a></body></html>'.encode('utf-8')); return
            self._send(200,'text/html; charset=utf-8',stock_lab_page(ticker, fresh).encode('utf-8'),extra); return
        if self.path.startswith('/api/run_scan'):
            ok,msg=start_scan()
            self._send(200,'application/json',json.dumps({'ok':ok,'message':msg}).encode()); return
        if self.path.startswith('/api/run_status'):
            self._send(200,'application/json',json.dumps(scan_status()).encode()); return
        if self.path.startswith('/health'):
            self._send(200,'application/json',json.dumps({'ok':True,'version':VERSION,'mode':'live_plus_validation_v2','cache_base':str(getattr(see_engine,'DATA_CACHE','')) if see_engine else ''}).encode()); return
        if self.path.startswith('/exports/all.zip'):
            p=OUT/'all.zip'
            if not p.exists(): self.send_error(404); return
            self._send(200,'application/zip',p.read_bytes(),{'Content-Disposition':f'attachment; filename="see_audit_export_{VERSION}.zip"'}); return
        self._send(200,'text/html; charset=utf-8',dashboard().encode('utf-8'),extra)
if __name__=='__main__': ThreadingHTTPServer(('0.0.0.0',PORT),H).serve_forever()
