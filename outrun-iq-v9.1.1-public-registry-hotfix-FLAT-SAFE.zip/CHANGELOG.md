# Changelog

## v9.1.1 — Public Registry Lockfile Hotfix

- Herstelt een releasefout waarbij `package-lock.json` 376 `resolved`-URL's naar een niet-publieke buildregistry bevatte.
- Alle package tarballs verwijzen nu naar `https://registry.npmjs.org/`.
- Voorkomt time-outs tijdens `npm ci` op de VPS.
- Geen functionele productwijzigingen ten opzichte van v9.1.0; alle Secure Platform Core-invarianten blijven behouden.
- Service-worker cacheversie en releaseversies zijn synchroon verhoogd naar 9.1.1.

## v9.1.0 — Secure Platform Core

### Releasekarakter

Een zware funderingsrelease gebaseerd op een volledige product-, UX-, security- en architectuuraudit van v9.0.8. De kernprioriteit is niet meer featurebreedte, maar betrouwbare datagrenzen, menselijke productwaarheid, veilige media, eerlijke pilotcopy, reproduceerbare builds en een rustigere marketplace.

### P0 privacy en publieke datacontracten

- Nieuwe expliciete `PublicListing`-allowlist; het interne listingobject wordt niet meer verspreid en vervolgens gedeeltelijk gewist.
- Afzonderlijke publieke sellerprojectie zonder KvK, btw, e-mail, telefoon, adres, support- of payoutvelden.
- Productmodal herbouwd op dezelfde publieke contextquery als de normale productdetailpagina.
- Vinderresultaten gebruiken uitsluitend buyer-safe carddata.
- Checkout en buyerorderpagina lezen geen intern listingrecord meer.
- Drafts, reviewlistings en producten zonder voorraad zijn ook via een rechtstreeks bekende ID niet publiek opvraagbaar.
- Publieke listingcontext wordt in één databasequery opgebouwd.
- Contracttests blokkeren verboden velden en toekomstige onbekende secrets.

### Private media en uploadhardening

- Nieuwe `MediaAsset`-registratie met eigenaar, visibility, purpose, hash, grootte en afmetingen.
- Private uploads zijn alleen bereikbaar voor de eigenaar of admin.
- Publieke en private assets krijgen verschillend cachebeleid.
- Vision accepteert alleen media die bij de actieve partner hoort.
- Storefrontlogo en banner vereisen mediaownership.
- Uploadbatches zijn all-or-nothing; mislukte verwerking laat geen losse bestanden achter.
- Magic-bytecontrole toegevoegd.
- Server-side decode, automatische rotatie, pixelbegrenzing, resize en WebP-re-encoding via Sharp.
- EXIF en overige metadata worden verwijderd door re-encoding.
- Veilige random bestandsnamen, mode `0600` en exclusieve filecreatie.

### Authenticatie en autorisatie

- Legacy `ADMIN_PIN` volledig verwijderd.
- Dummy- en testloginroutes verwijderd.
- Centrale guards voor admin, approved partner en persoonlijke buyer toegepast op alle betreffende API-routes.
- Sessiecookies zijn HttpOnly, SameSite Lax, Secure in productie en high priority.
- Registratie- en resetcodes gebruiken cryptografische randomisatie.
- Alleen salted hashes van verificatiecodes worden opgeslagen.
- Verificatiecodes worden nooit in mailfallback- of PM2-logs geschreven.
- Loginmeldingen verraden geen persoonlijk/zakelijk accounttype.
- Dummy scryptcheck verkleint timingverschillen voor onbekende accounts.
- Rate-limitkeys combineren doelaccount en gesaniteerde requestherkomst.
- Same-originvalidatie is reverse-proxybewust.
- FlowRecorder staat in productie uit tenzij expliciet tijdelijk ingeschakeld.

### AI en menselijke bevestiging

- AI-confidence bevestigt nooit meer zelfstandig model, prijs, conditie of publicatie.
- Listingpublicatie vereist afzonderlijke expliciete partnerbevestigingen.
- Client-supplied confidence, comps en providerdata gelden niet als menselijke waarheid.
- Activeren kan de reviewgate niet omzeilen.
- Prijswijzigingen worden opnieuw bevestigd en geaudit.
- Verwijderen archiveert een listing en zet voorraad op nul; historie blijft behouden.

### Data-integriteit en runtime

- JSON-store faalt gesloten bij corrupte, onleesbare of onverwachte databasebestanden.
- Alleen een werkelijk ontbrekend bestand (`ENOENT`) maakt een lege database.
- Copy-on-write voorkomt dat een mislukte mutatie later alsnog wordt opgeslagen.
- Tempfile, `fsync`, last-good backup en atomische rename toegevoegd.
- Productviews worden gebufferd en niet meer per view als volledige DB-write opgeslagen.
- Order- en campaignsweeps zijn uit paginalaads verwijderd.
- Nieuwe beveiligde maintenance-route voor viewflush en periodieke sweeps.

### Pilotcommerce en idempotency

- Ordercreatie gebruikt een client-command-ID.
- Een retry of dubbele tik retourneert dezelfde pilotorder zonder dubbele voorraadmutatie.
- Afhaalcode gebruikt cryptografische randomisatie.
- Finance blijft hard pilot-locked via een compile-time releaseflag.
- Stripe-, payout- en echte campagnebudgetacties blijven geblokkeerd, ook bij foutieve live-envvariabelen.
- Promote is een expliciet afgesloten voorbereidingsgebied zonder AI-call, budgetreservering of niet-bewezen ROI-claim.
- Buyer-, partner-, admin- en juridische copy benoemt betaling, reserve en payout als simulatie.

### Buyer UX

- Homepage vereenvoudigd tot zoekfunctie, heldere waardepropositie, categorieën en productrails.
- Geen live generatieve homeplanning of AI-write op anonieme paginalaads.
- Centrale AI-knop uit bottom navigation verwijderd.
- Beschrijvend zoeken is een zoekmodus, niet het hoofdproduct.
- Productdetail volgt foto, titel, prijs, conditie, levering, retour, seller en CTA.
- Misleidende labels rond escrow, verificatie, live marktdata en AI-prijsbewijs verwijderd.
- Niet-werkende afstandsfilter verwijderd; actieve prijs- en taxonomyfilters zijn gekoppeld.
- Websplash verwijderd.
- Service-workercache en releaseversie bijgewerkt.
- Externe Google Fonts verwijderd.

### Partner UX

- Dashboard is action-first: orders, blokkades, voorraad en operationele taken vóór groei/promotie.
- Listingwizard bevat expliciete bevestigingsgates.
- Upload- en mediaverwerking communiceert veilige limieten.
- Wallet benoemt alle bedragen als testsimulatie.
- Promote is niet langer een halfwerkende betaalfeature.

### Design en platformlaag

- Nieuw `platform.css` als geïsoleerde v9.1.0-laag met tokens en consistente componentcorrecties.
- Bestaande kernflows blijven compatibel, terwijl de historische globale CSS stapsgewijs kan worden afgebouwd.
- Securityheaders en Content Security Policy toegevoegd.
- Powered-by-header uitgeschakeld.

### Toolchain en releasekwaliteit

- Next.js geüpgraded naar 15.5.20.
- React en React DOM geüpgraded naar 19.2.7.
- Sharp toegevoegd voor veilige beeldverwerking.
- ESLint, typecheck, tests, build en dependency-audit als vaste scripts.
- `release:check` controleert versieconsistentie, verboden legacyfeatures, centrale guards, publieke datagrenzen, pilotlocks en buildbestanden.
- Veertien automatische unit-, security- en invarianttests toegevoegd.

### Bewezen tijdens releasebouw

- `npm ci`: geslaagd.
- ESLint: schoon.
- TypeScript: geslaagd.
- 14 tests: geslaagd.
- Volledige Next.js-productiebuild: geslaagd.
- Production dependency-audit: nul bekende kwetsbaarheden.
- Draaiende server-smoke: health, homepage, securityheaders, publieke listings, private upload-404, same-origin en maintenance-autorisatie geslaagd.

### Bewuste resterende grenzen

- JSON-persistence blijft een tijdelijke pilotbasis; PostgreSQL is de volgende grote platformstap.
- Geen live Stripe Connect, payout, refund of reconciliation.
- Geen complete Resolver 3.0/catalogus.
- Product Intelligence heeft nog geen volledig versioned evidencegraph.
- Legacy `globals.css` bestaat nog; de design-systemmigratie is gestart maar niet afgerond.
- Rate limiting is nog per applicatieproces.
- Live iPhone-, VPS- en externe provider-E2E moet na deployment worden uitgevoerd.
