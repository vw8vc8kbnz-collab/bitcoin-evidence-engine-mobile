# Securitybeleid — Outrun IQ v9.1.1

## Productiestatus

v9.1.1 is een beveiligde pilotbasis. Echte payment capture, payout en betaald Promote zijn hard vergrendeld.

## Belangrijke grenzen

- Gebruik één PM2-instance zolang JSON-persistence actief is.
- Deel `data/`, `.env` of private upload-URLs nooit publiek.
- Zet `CRON_SECRET`, mail- en AI-secrets alleen server-side.
- Schakel `NEXT_PUBLIC_FLOW_RECORDER_ENABLED` niet blijvend in op productie.
- Gebruik geen legacy admin-PIN; adminrechten lopen uitsluitend via de adminrol.
- Vertrouw nooit clientvelden als menselijke productbevestiging.

## Incidentrespons

Bij vermoeden van datalek of accountmisbruik:

1. stop of isoleer de applicatie;
2. bewaar PM2-, reverse-proxy- en auditlogs;
3. roteer sessies en relevante secrets;
4. maak een read-only kopie van `data/`;
5. controleer `data/db.json.last-good`;
6. herstel niet automatisch voordat oorzaak en integriteit bekend zijn;
7. documenteer actor, tijd, resources en genomen acties.

## Back-up

De lokale last-good backup beschermt alleen tegen een mislukte write en is geen volwaardige back-up. Maak versleutelde off-host snapshots en test herstel periodiek.

## Meldingen

Beveiligingsproblemen horen alleen via een privé beheerkanaal te worden gedeeld, nooit in publieke listings, reviews of chats.
