# Outrun IQ v9.1.1 — Security & Finance Status

## Harde status

Finance, payment capture, payouts en betaald Promote zijn in v9.1.1 **pilot-locked**. De compile-time releaseflag `COMMERCE_LIVE_READY` staat op `false` en heeft voorrang op alle environmentvariabelen.

Zelfs wanneer `PAYMENT_LIVE_ENABLED=true`, Stripekeys of liveflags per ongeluk op de server staan, mogen de adapters geen echte geldactie uitvoeren.

## Bestaande pilotlaag

De code bevat voorbereidende concepten voor:

- double-entry ledgerregels;
- idempotencykeys;
- hash chaining;
- testreserve;
- payout- en refundstates;
- campagnebudgetten.

Deze concepten zijn nuttig voor domeinontwikkeling en tests, maar vormen nog geen production-ready financieel systeem.

## Niet-onderhandelbare principes

1. AI mag nooit een geldmutatie uitvoeren.
2. Saldo is afgeleid van append-only ledgerregels.
3. Iedere financiële command moet idempotent zijn.
4. Betaling, order, refund en payout vereisen database-transacties.
5. Providerwebhooks vereisen signaturevalidatie en event-idempotency.
6. Admincorrecties zijn afzonderlijke tegenboekingen, geen edits van historie.
7. Buyer- en partnercopy mag geen live bescherming claimen zolang deze gate gesloten is.

## Voorwaarden voor een latere commerce-release

- PostgreSQL met constraints, transacties en row locks;
- order- en voorraadreserverings-state machine;
- Stripe Connect account/KYC lifecycle;
- geverifieerde webhook signature;
- webhook replay- en idempotencytests;
- refunds, disputes en partial refunds;
- payout reconciliation;
- step-up authentication voor gevoelige financeacties;
- finance backoffice en alerts;
- incident- en herstelrunbook;
- juridische en operationele beoordeling.
