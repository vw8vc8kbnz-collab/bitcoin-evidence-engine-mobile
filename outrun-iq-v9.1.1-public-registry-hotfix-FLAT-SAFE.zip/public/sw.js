/* Outrun IQ service worker v9.1.1 — conservatief:
 * - navigaties: network-first, offline-fallback
 * - statische assets (_next/static, icons): stale-while-revalidate
 * - /api en /uploads: NOOIT cachen (auth/versheid) */
const VERSION = "oiq-v9-1-1";
const OFFLINE = "/offline";

self.addEventListener("install", e => {
  e.waitUntil(caches.open(VERSION).then(c => c.add(OFFLINE)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", e => {
  e.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== VERSION).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});
self.addEventListener("fetch", e => {
  const url = new URL(e.request.url);
  if (e.request.method !== "GET" || url.origin !== location.origin) return;
  if (url.pathname.startsWith("/api/") || url.pathname.startsWith("/uploads/")) return;

  if (e.request.mode === "navigate") {
    e.respondWith(fetch(e.request).catch(() => caches.match(OFFLINE)));
    return;
  }
  if (url.pathname.startsWith("/_next/static/") || url.pathname.startsWith("/icons/")) {
    e.respondWith(
      caches.open(VERSION).then(async c => {
        const hit = await c.match(e.request);
        const net = fetch(e.request).then(res => { if (res.ok) c.put(e.request, res.clone()); return res; }).catch(() => hit);
        return hit || net;
      })
    );
  }
});

/* Web Push (v6.9) */
self.addEventListener("push", e => {
  let data = { title: "Outrun IQ", body: "", href: "/" };
  try { data = { ...data, ...e.data.json() }; } catch { /* leeg bericht */ }
  e.waitUntil(self.registration.showNotification(data.title, {
    body: data.body,
    icon: "/icons/icon-192.png",
    badge: "/icons/icon-192.png",
    data: { href: data.href },
  }));
});
self.addEventListener("notificationclick", e => {
  e.notification.close();
  const href = e.notification.data?.href || "/";
  e.waitUntil(clients.matchAll({ type: "window", includeUncontrolled: true }).then(list => {
    for (const c of list) { if ("focus" in c) { c.navigate(href); return c.focus(); } }
    return clients.openWindow(href);
  }));
});
