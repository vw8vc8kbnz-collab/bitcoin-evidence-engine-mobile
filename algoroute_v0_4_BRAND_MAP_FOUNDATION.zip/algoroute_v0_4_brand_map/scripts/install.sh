#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/.."
echo "AlgoRoute v0.4 Brand + Map Foundation"
ls -lah apps/web/static | head
