from fastapi import FastAPI
from fastapi.responses import JSONResponse
from datetime import datetime, timezone

app = FastAPI(title="AlgoRoute API", version="0.4.0")

@app.get("/api/health")
def health():
    return {"ok": True, "app": "AlgoRoute", "version": "0.4.0", "time": datetime.now(timezone.utc).isoformat()}

@app.get("/api/routes/live")
def live_routes():
    return JSONResponse({
        "routes": [
            {"id":"R001","driver":"Jan de Vries","vehicle":"V-01","stops":12,"remaining":5,"status":"active","speed_kmh":60},
            {"id":"R002","driver":"Pieter Smit","vehicle":"V-02","stops":10,"remaining":4,"status":"active","speed_kmh":54}
        ]
    })
