# AlgoRoute v0.4 — Brand + Map Foundation

Echte software build, geen mockup. Deze versie verwerkt de gekozen AlgoRoute branding als assets en bouwt de dashboard/look met echte HTML/CSS/SVG componenten.

- Exacte branding-assets uit de aangeleverde logo sheet
- Dark navy/glassmorphism UI
- Donkere Nederland-map-look als echte CSS/SVG live tracking kaart
- Glow route lines, stops en rijdende bus marker
- Nginx root fixed: `/` opent frontend, `/api/health` opent backend
