async function boot(){
  try{const r=await fetch('/api/health'); const j=await r.json(); console.log('AlgoRoute health',j)}catch(e){console.warn('health unavailable',e)}
}
boot();
