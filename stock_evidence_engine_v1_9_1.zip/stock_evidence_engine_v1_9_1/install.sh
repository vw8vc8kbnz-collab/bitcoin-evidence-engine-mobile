#!/usr/bin/env bash
set -euo pipefail
APP=/home/ubuntu/stock_evidence_latest
cd "$APP"
sudo chown -R ubuntu:ubuntu "$APP" || true
sudo mkdir -p /home/ubuntu/stock_evidence_data_cache/price_cache /home/ubuntu/stock_evidence_data_cache/news_cache /home/ubuntu/stock_evidence_data_cache/metadata_cache /home/ubuntu/stock_evidence_data_cache/stock_lab
sudo chown -R ubuntu:ubuntu /home/ubuntu/stock_evidence_data_cache
python3 -m venv venv
./venv/bin/python -m pip install --upgrade pip >/dev/null
./venv/bin/python -m pip install -r requirements.txt
./venv/bin/python - <<'PY'
import yfinance, pandas, numpy, requests, dotenv
print('[SEE install] dependency check OK')
PY
sudo tee /etc/systemd/system/stock-evidence-dashboard.service >/dev/null <<EOF
[Unit]
Description=Stock Evidence Engine Dashboard
After=network.target
[Service]
Type=simple
User=ubuntu
WorkingDirectory=$APP
ExecStart=$APP/venv/bin/python $APP/server.py
Restart=always
RestartSec=5
[Install]
WantedBy=multi-user.target
EOF
sudo tee /etc/systemd/system/stock-evidence-scan.service >/dev/null <<EOF
[Unit]
Description=Stock Evidence Engine Scheduled Scan
After=network.target
[Service]
Type=oneshot
User=ubuntu
WorkingDirectory=$APP
ExecStart=$APP/run_backtest.sh "BB,PLTR,IONQ,SOUN,NVDA,AMD,TSLA,AI,BBAI,RKLB,SMR,ACHR,JOBY,UPST,HOOD,COIN,MARA,RIOT,LCID,RIVN,RGTI,QBTS,OKLO,ASTS,LUNR,OUST,PATH,SOFI,AFRM,ROKU,SHOP,NET,CRWD,DDOG,SNOW,ARM,MU,AVGO,TSM,SMCI,APP,MRVL,INTC,ORCL,MSFT,GOOGL,META,AMZN,CRSP,BEAM,EDIT,NTLA,PLUG,ENPH,FSLR,CCJ,UEC,UUUU,EVGO,CHPT,QS,OPEN,DKNG,TDOC,SPCE,ENVX,STEM,SERV,TER,ISRG,IRDM,KTOS,AVAV,HIMS,NU,SE,GRAB,TOST,U,LMND,ROOT,CVNA" "2y"
EOF
sudo tee /etc/systemd/system/stock-evidence-scan.timer >/dev/null <<EOF
[Unit]
Description=Stock Evidence Engine 4x Daily Timer
[Timer]
OnCalendar=*-*-* 14:35:00
OnCalendar=*-*-* 17:00:00
OnCalendar=*-*-* 20:00:00
OnCalendar=*-*-* 22:30:00
Persistent=true
[Install]
WantedBy=timers.target
EOF
sudo systemctl daemon-reload
sudo systemctl enable stock-evidence-dashboard.service >/dev/null
sudo systemctl restart stock-evidence-dashboard.service
sudo systemctl enable stock-evidence-scan.timer >/dev/null
sudo systemctl restart stock-evidence-scan.timer
printf '[SEE install] OK\n'
