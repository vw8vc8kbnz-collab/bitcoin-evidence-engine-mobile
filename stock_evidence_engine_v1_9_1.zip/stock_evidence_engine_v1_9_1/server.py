#!/usr/bin/env python3
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
import json, csv, html, urllib.parse
VERSION='v1.9.1'; BASE=Path(__file__).resolve().parent; OUT=BASE/'output'; PORT=8798
try:
    import engine as see_engine
except Exception:
    see_engine=None

def read_csv(name):
    files=list(OUT.glob(name))
    if not files: return []
    try:
        with files[0].open(encoding='utf-8') as f: return list(csv.DictReader(f))
    except Exception: return []

def fnum(x):
    try: return float(x or 0)
    except Exception: return 0.0

def uniq(rows, key='ticker'):
    return len({r.get(key) for r in rows if r.get(key)})

def metric(label, value, sub=''):
    return f"<div class='metric'><b>{html.escape(str(value))}</b><br><span>{html.escape(label)}</span>{('<em>'+html.escape(str(sub))+'</em>') if sub else ''}</div>"

def card(r, ai_map=None, mode='live'):
    ai_map=ai_map or {}; ai=ai_map.get(r.get('ticker'), r)
    t=html.escape(r.get('ticker','?'))
    if mode=='validated':
        score=r.get('validation_score') or r.get('validated_edge_score') or '0'
        label='VALIDATED EDGE' if str(r.get('validated_edge','0'))=='1' else 'RESEARCH'
        sub=f"n_eff {r.get('n_eff','0')} · excess {r.get('excess_vs_drift','0')}% · CI {r.get('ci90_low','0')} to {r.get('ci90_high','0')}"
    else:
        score=r.get('live_attention_score') or r.get('final_score') or '0'
        label='LIVE EXTREME' if str(r.get('live_extreme','0'))=='1' else 'LIVE ELITE' if str(r.get('live_elite','0'))=='1' else str(r.get('ai_tier') or ai.get('ai_tier') or '')
        sub=f"AI {r.get('ai_final_score') or ai.get('ai_final_score') or '0'} · Val {r.get('validation_score','0')} · priced-in {r.get('priced_in_risk','0')}"
    ev=html.escape(str(ai.get('event_type') or r.get('setup') or ''))
    warn=html.escape(str(r.get('validation_warning','')))
    reason=html.escape(str(ai.get('reasoning') or r.get('reasoning') or ''))[:300]
    setup=html.escape(str(r.get('setup','')))
    return f"""<div class='card'><div class='top'><b>{t}</b><span>{html.escape(label)}</span></div><div class='score'>{html.escape(str(score))}</div><div class='muted'>{html.escape(sub)} · {ev} · {setup}</div><div class='warn'>{warn}</div><p>{reason}</p></div>"""

def css():
    return """<style>
body{margin:0;background:#f4f6fb;color:#111827;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif}.wrap{padding:16px;max-width:1180px;margin:auto}.hero{background:linear-gradient(135deg,#111827,#475569);color:white;border-radius:28px;padding:24px;margin:10px 0 16px;box-shadow:0 18px 40px #0002}h1{margin:6px 0 4px;font-size:32px;letter-spacing:-.04em}.pill{display:inline-block;background:#ffffff22;border:1px solid #ffffff33;padding:7px 11px;border-radius:999px;font-size:13px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(145px,1fr));gap:10px;margin-bottom:12px}.metric,.card,.note{background:white;border-radius:22px;padding:16px;box-shadow:0 10px 26px #0f172a12;border:1px solid #e5e7eb}.metric b{font-size:26px}.metric span{color:#64748b;font-size:13px}.metric em{display:block;color:#94a3b8;font-style:normal;font-size:12px;margin-top:4px}.section{font-size:22px;margin:24px 2px 10px;letter-spacing:-.03em}.top{display:flex;justify-content:space-between;gap:10px;align-items:center}.top b{font-size:22px}.top span{background:#e0f2fe;color:#075985;padding:6px 10px;border-radius:999px;font-weight:800;font-size:12px}.score{font-size:36px;font-weight:950;margin:8px 0;color:#0f172a}.muted{color:#64748b;font-size:13px}.warn{color:#b45309;font-size:12px;margin-top:7px;font-weight:800}p{line-height:1.35}a.btn,button{display:inline-block;text-decoration:none;background:white;color:#111827;padding:12px 14px;border-radius:14px;font-weight:900;margin-top:12px;border:0}.cols{display:grid;grid-template-columns:1fr 1fr;gap:12px}.lab{margin-top:14px;background:#ffffff18;border:1px solid #ffffff35;border-radius:22px;padding:14px}.search{display:flex;gap:8px;margin-top:10px}.search input{flex:1;border:0;border-radius:16px;padding:15px;font-size:17px}.search button{background:#22c55e;color:white}.scoregrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(135px,1fr));gap:8px}.scorepill{background:#f8fafc;border:1px solid #e5e7eb;border-radius:16px;padding:10px}.scorepill b{font-size:24px;display:block}.pre{white-space:pre-wrap;font-family:ui-monospace,Menlo,monospace;font-size:12px}@media(max-width:760px){.wrap{padding:10px}.hero{padding:18px;border-radius:22px}.cols{grid-template-columns:1fr}.search{flex-direction:column}}
</style>"""

def lab_form():
    return """<div class='lab'><b>Stock Search Lab</b><br><span>Google-achtige single-stock analyse voor elk Yahoo ticker: market cap, technicals, news, lowcap-risk en DeepSeek dossier.</span><form class='search' action='/stock_lab' method='get'><input name='ticker' placeholder='Typ ticker, bijv. PLTR, IRDM, RGTI, COIN...' autocomplete='off'><button type='submit'>Analyze</button></form></div>"""

def dashboard():
    ai=read_csv(f'see_ai_analyst_{VERSION}.csv')
    live=read_csv(f'see_live_signals_{VERSION}.csv')
    validated=read_csv(f'see_validated_setups_{VERSION}.csv')
    validation=read_csv(f'see_validation_overlap_{VERSION}.csv')
    final_extreme=read_csv(f'see_final_extreme_{VERSION}.csv')
    qelite=read_csv(f'see_quant_elite_{VERSION}.csv')
    usable=read_csv(f'see_usable_{VERSION}.csv')
    cost=read_csv(f'see_cost_monitor_{VERSION}.csv')
    cm=cost[0] if cost else {}
    ai_map={r.get('ticker'):r for r in ai}
    ai_scores=[fnum(r.get('ai_final_score') or r.get('final_score')) for r in ai]
    ai_high=sum(1 for s in ai_scores if s>=70); ai_elite=sum(1 for s in ai_scores if s>=80)
    live_sorted=sorted(live, key=lambda r: fnum(r.get('live_attention_score') or r.get('final_score')), reverse=True)[:24]
    val_sorted=sorted(validated, key=lambda r: fnum(r.get('validation_score')), reverse=True)[:24]
    risk_high=sum(1 for r in validation if str(r.get('overlap_risk'))=='HIGH')
    low_n=sum(1 for r in validation if fnum(r.get('n_eff'))<10)
    livecards=''.join(card(r, ai_map, 'live') for r in live_sorted) or '<div class="card">Nog geen live signals. Run backtest.</div>'
    valcards=''.join(card(r, ai_map, 'validated') for r in val_sorted) or '<div class="card">Nog geen validated setups volgens overlap/excess criteria.</div>'
    return f"""<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>SEE {VERSION}</title>{css()}</head><body><div class='wrap'><div class='hero'><span class='pill'>Stock Evidence Engine {VERSION}</span><h1>Live Opportunity + Validation + Stock Search Lab</h1><div>v1.9.1 voegt een persistente Yahoo cache en een single-stock intelligence tab toe. DeepSeek analyseert hier één ticker als dossier, met extra lowcap/pump/dilution risk checks.</div><a class='btn' href='/exports/all.zip'>Download audit ZIP</a>{lab_form()}</div>
<div class='note'><b>Belangrijk:</b> Live signals zijn aandachtssignalen, geen bewezen backtest-edge. Stock Search Lab is single-name intelligence, niet automatisch een koopadvies.</div>
<h2 class='section'>Live Opportunity Mode</h2><div class='grid'>{metric('AI rows',len(ai))}{metric('AI High ≥70',ai_high)}{metric('AI Elite ≥80',ai_elite)}{metric('Live signal rows',len(live), f'{uniq(live)} tickers')}{metric('Live extreme + validated',len(final_extreme))}{metric('Run cost','$'+str(cm.get('run_cost_usd','0')), 'monthly $'+str(cm.get('monthly_estimate_usd','0')))}</div>
<h2 class='section'>Validation Mode</h2><div class='grid'>{metric('Validation cells',len(validation))}{metric('Validated edges',len(validated), f'{uniq(validated)} tickers')}{metric('High overlap cells',risk_high)}{metric('Low effective-n cells',low_n)}{metric('Usable rows',len(usable))}{metric('Quant elite rows',len(qelite))}</div>
<div class='cols'><div><h2 class='section'>Top Live Signals</h2>{livecards}</div><div><h2 class='section'>Top Validated Setups</h2>{valcards}</div></div></div></body></html>"""

def stock_lab_page(ticker):
    try:
        if see_engine is None: raise RuntimeError('engine import failed')
        result=see_engine.analyze_single_stock(ticker, '1y')
        a=result.get('analysis',{}); m=result.get('market_data',{}); meta=result.get('metadata',{})
        def v(x): return html.escape(str(x if x not in (None,'') else '?'))
        def join(x): return v(' · '.join(map(str,x)) if isinstance(x,list) else x)
        scoregrid=''.join([f"<div class='scorepill'><b>{v(a.get(k))}</b>{label}</div>" for k,label in [('grade','Grade'),('opportunity_score','Opportunity'),('catalyst_strength','Catalyst'),('risk_score','Risk'),('priced_in_risk','Priced-in'),('lowcap_danger_score','Lowcap danger'),('quality_score','Quality'),('tradeability_score','Tradeability')]])
        news=''.join(f"<li>{v(n.get('title'))} <span class='muted'>{v(n.get('publisher'))}</span></li>" for n in result.get('news',[])[:12])
        body=f"""<div class='hero'><span class='pill'>Stock Search Lab {VERSION}</span><h1>{v(ticker)} — {v(meta.get('longName') or meta.get('shortName') or meta.get('symbol'))}</h1><a class='btn' href='/'>← Dashboard</a>{lab_form()}</div><div class='card'><div class='scoregrid'>{scoregrid}</div><p><b>Market cap:</b> {v(meta.get('marketCap'))} · <b>Sector:</b> {v(meta.get('sector'))} · <b>Industry:</b> {v(meta.get('industry'))} · <b>Price:</b> {v(m.get('price'))}</p><p><b>Technicals:</b> ret3 {v(m.get('ret3'))}% · ret20 {v(m.get('ret20'))}% · rel volume {v(m.get('relative_volume'))}x · 52w pos {v(m.get('position_52w'))}%</p><p><b>Event:</b> {v(a.get('event_type'))}</p><p><b>Narrative:</b> {v(a.get('narrative'))}</p><p><b>Bull case:</b> {join(a.get('bull_case'))}</p><p><b>Bear case:</b> {join(a.get('bear_case'))}</p><p><b>Key risks:</b> {join(a.get('key_risks'))}</p><p><b>What would make this elite:</b> {v(a.get('what_would_make_this_elite'))}</p><p><b>Concrete triggers:</b> {join(a.get('concrete_triggers'))}</p><p><b>Reasoning:</b> {v(a.get('reasoning'))}</p></div><h2 class='section'>Recent headlines</h2><div class='card'><ul>{news}</ul></div><details class='card'><summary>Raw JSON</summary><div class='pre'>{v(json.dumps(result, indent=2, default=str))}</div></details>"""
        return f"<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>{v(ticker)} SEE Lab</title>{css()}</head><body><div class='wrap'>{body}</div></body></html>"
    except Exception as e:
        return f"<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>{css()}</head><body><div class='wrap'><div class='hero'><h1>Stock Search Lab error</h1><a class='btn' href='/'>← Dashboard</a>{lab_form()}</div><div class='card'>{html.escape(str(e))}</div></div></body></html>"

class H(BaseHTTPRequestHandler):
    def do_HEAD(self): self.send_response(200); self.end_headers()
    def do_GET(self):
        if self.path.startswith('/api/stock_lab'):
            try:
                qs=urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
                ticker=(qs.get('ticker') or [''])[0].strip().upper()
                if not ticker: raise ValueError('missing ticker')
                if see_engine is None: raise RuntimeError('engine import failed')
                result=see_engine.analyze_single_stock(ticker, '1y')
                b=json.dumps({'ok':True,'version':VERSION,'result':result}, default=str).encode('utf-8')
                self.send_response(200); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b); return
            except Exception as e:
                b=json.dumps({'ok':False,'version':VERSION,'error':str(e)}).encode('utf-8')
                self.send_response(500); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b); return
        if self.path.startswith('/stock_lab'):
            qs=urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            ticker=(qs.get('ticker') or [''])[0].strip().upper()
            b=stock_lab_page(ticker).encode('utf-8'); self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b); return
        if self.path.startswith('/health'):
            b=json.dumps({'ok':True,'version':VERSION,'mode':'live_plus_validation_split_stock_search_lab','cache_base':str(getattr(see_engine,'DATA_CACHE','')) if see_engine else ''}).encode(); self.send_response(200); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b); return
        if self.path.startswith('/exports/all.zip'):
            p=OUT/'all.zip'
            if not p.exists(): self.send_error(404); return
            b=p.read_bytes(); self.send_response(200); self.send_header('Content-Type','application/zip'); self.send_header('Content-Disposition',f'attachment; filename="see_audit_export_{VERSION}.zip"'); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b); return
        b=dashboard().encode('utf-8'); self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b)
if __name__=='__main__': ThreadingHTTPServer(('0.0.0.0',PORT),H).serve_forever()
