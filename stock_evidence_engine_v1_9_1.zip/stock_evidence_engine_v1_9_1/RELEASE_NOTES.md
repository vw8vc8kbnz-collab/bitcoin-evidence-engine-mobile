# SEE v1.9.1 — Stock Search Lab + Persistent Cache

Built on v1.9.0 Validation Split.

## Added
- Persistent Yahoo price cache outside the app folder: `/home/ubuntu/stock_evidence_data_cache`.
- Cache survives ZIP updates and prevents full re-downloads when bars are recent.
- Dashboard Stock Search Lab with Google-like ticker form.
- `/stock_lab?ticker=PLTR` HTML dossier endpoint.
- `/api/stock_lab?ticker=PLTR` JSON endpoint.
- Single-stock DeepSeek prompt focused on lowcap/pump/dilution/priced-in risk.
- Output scores: opportunity, catalyst, risk, priced-in, lowcap danger, quality, tradeability, grade.

## Preserved
- v1.9.0 live/validation split.
- Overlap-aware validation exports.
- DeepSeek kept out of historical validation.
