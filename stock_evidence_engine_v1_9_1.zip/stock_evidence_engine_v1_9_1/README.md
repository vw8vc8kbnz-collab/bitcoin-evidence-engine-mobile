# Stock Evidence Engine v1.9.1

Validation Split + Stock Search Lab.

Dashboard: http://51.195.102.180:8798

## New in v1.9.1

1. Persistent cache:
`/home/ubuntu/stock_evidence_data_cache`

This folder is intentionally outside `/home/ubuntu/stock_evidence_latest`, so updates do not delete historical Yahoo data.

2. Stock Search Lab:
Open dashboard and use the search bar, or direct URL:
`/stock_lab?ticker=PLTR`

It analyzes any Yahoo ticker one at a time with:
- market cap
- company metadata
- price/volume/relative strength
- recent headlines
- lowcap danger score
- priced-in risk
- DeepSeek single-stock intelligence memo
- concrete triggers that would make the stock elite

## Important
Stock Search Lab is not a backtest. It is a live single-stock dossier. Historical validation remains separate.
