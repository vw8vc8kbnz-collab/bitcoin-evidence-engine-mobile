#!/usr/bin/env bash
set -euo pipefail
ROOT="/home/ubuntu/bitcoin-engine-deploy/current/live_forecast"
OUT="/home/ubuntu/bee_state_files.zip"
cd "$ROOT"
mkdir -p state logs
# Hard overwrite the downloadable state ZIP every time.
rm -f "$OUT"
# Create placeholder files if they do not exist yet, so the ZIP is always downloadable.
[ -f state/bee_history.csv ] || printf 'timestamp_utc,candle_dt,price,fear_greed,drawdown_from_ath,return_4,return_24,rsi_14,regime,specialist,prob,cycle_prob_raw,tier,decision,notify,last_notify_status,notify_skip_reason,reason\n' > state/bee_history.csv
[ -f state/bee_signals.csv ] || printf 'signal_ts,candle_dt,specialist,decision,tier,prob,entry_price,take_profit,stop_loss,horizon,fear_greed,regime,reason,historical_winrate_pct,oos_winrate_pct,outcome_price_30d,outcome_pct_30d,outcome_filled_at\n' > state/bee_signals.csv
[ -f state/bee_status.json ] || printf '{}\n' > state/bee_status.json
[ -f logs/bee_live.log ] || printf '' > logs/bee_live.log
# -j keeps it simple in Termius: files appear directly inside the ZIP.
zip -q -j "$OUT" state/bee_history.csv state/bee_status.json state/bee_signals.csv logs/bee_live.log
printf 'STATE EXPORT READY: %s\n' "$OUT"
ls -lah "$OUT"
