#!/usr/bin/env bash
set -u
cd /home/ubuntu/bitcoin-engine-deploy/current/live_forecast || exit 1
. ../.venv/bin/activate
while true; do
  echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] BEE live run starting..."
  python bee_live_forecast_v4_1_paper.py --once
  RUN_RC=$?
  echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] BEE live run exit code: $RUN_RC"
  echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] Rebuilding /home/ubuntu/bee_state_files.zip..."
  /home/ubuntu/bitcoin-engine-deploy/current/scripts/export_state_files.sh || true
  echo "[$(date -u +%Y-%m-%dT%H:%M:%SZ)] Sleeping 3600 seconds..."
  sleep 3600
done
