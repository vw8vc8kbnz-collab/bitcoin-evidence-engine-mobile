#!/usr/bin/env bash
set -euo pipefail
cd /home/ubuntu/bitcoin-engine-deploy/current/live_forecast
. ../.venv/bin/activate
python bee_live_forecast_v4_1_paper.py --once
/home/ubuntu/bitcoin-engine-deploy/current/scripts/export_state_files.sh
