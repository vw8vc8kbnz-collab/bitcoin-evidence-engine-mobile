# Outrun IQ v1.5 — Real Foundation No Dummy

- Geen demo/nep-producten.
- Koper- en sellerroute gescheiden.
- Werkende test-switch tussen koper/seller.
- Seller kan echte listing aanmaken in localStorage.
- Buyer ziet alleen listings die via sellerroute zijn aangemaakt.
- Geen npm, geen FastAPI, geen externe install nodig.

Start:

```bash
HOST=0.0.0.0 PORT=8795 ./start_8795.sh
```

Health:

```bash
curl -s http://127.0.0.1:8795/api/health
```
