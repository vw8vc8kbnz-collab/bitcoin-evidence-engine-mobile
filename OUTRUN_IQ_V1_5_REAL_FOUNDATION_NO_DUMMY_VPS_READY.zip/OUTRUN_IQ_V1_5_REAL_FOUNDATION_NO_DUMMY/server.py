#!/usr/bin/env python3
import os, json, mimetypes
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
ROOT = Path(__file__).resolve().parent
STATIC = ROOT / "static"
HOST = os.environ.get("HOST", "0.0.0.0")
PORT = int(os.environ.get("PORT", "8795"))
class Handler(SimpleHTTPRequestHandler):
    def translate_path(self, path):
        path = path.split('?',1)[0].split('#',1)[0]
        if path in ('/', ''):
            return str(STATIC / 'index.html')
        p = (STATIC / path.lstrip('/')).resolve()
        if not str(p).startswith(str(STATIC.resolve())):
            return str(STATIC / 'index.html')
        return str(p if p.exists() else STATIC / 'index.html')
    def do_GET(self):
        if self.path.startswith('/api/health'):
            body=json.dumps({'ok':True,'app':'Outrun IQ','version':'v1.5-real-foundation-no-dummy'}).encode()
            self.send_response(200); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(body))); self.end_headers(); self.wfile.write(body); return
        return super().do_GET()
    def end_headers(self):
        self.send_header('Cache-Control','no-store, max-age=0')
        self.send_header('X-Content-Type-Options','nosniff')
        super().end_headers()
if __name__ == '__main__':
    os.chdir(STATIC)
    print(f"=== Outrun IQ v1.5 real foundation ===")
    print(f"URL lokaal: http://127.0.0.1:{PORT}")
    print(f"Bind: {HOST}:{PORT}")
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
