# SEE Masterplan v1.4.0

This release upgrades narrative intelligence from proxy scoring to real headline ingestion and local semantic classification. Next step: validate whether catalyst score improves forward returns and then build v1.4.1 dashboard polish / event drilldowns.
