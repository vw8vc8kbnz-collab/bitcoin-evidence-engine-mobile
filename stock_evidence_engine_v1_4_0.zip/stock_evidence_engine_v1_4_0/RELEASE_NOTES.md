# v1.4.0

- Added Yahoo Finance search headline ingestion fallback.
- Added local semantic catalyst classifier (partnership, government contract, earnings acceleration, product launch, dilution/offering, downgrade, etc.).
- Added continuation_impact_score, semantic_strength, theme_alignment and attention_score.
- Added see_catalyst_events export.
- Kept stable server.py runtime on port 8798.
