#!/usr/bin/env python3
import argparse, math, json, zipfile, time, re, hashlib
from pathlib import Path
from datetime import datetime
import numpy as np
import pandas as pd
import yfinance as yf
import requests

VERSION='v1.4.0'
OUT=Path('data'); OUT.mkdir(exist_ok=True)
EXPORT=Path('exports'); EXPORT.mkdir(exist_ok=True)
HOLDS=[3,5,10,20]
COST=0.002

THEMES={
 'AI':['SOUN','BBAI','PLTR','AI','NVDA','AMD'],
 'QUANTUM':['IONQ'],
 'SPACE':['RKLB','ACHR','JOBY'],
 'CRYPTO':['COIN','MARA','RIOT'],
 'EV':['TSLA','LCID','RIVN'],
 'NUCLEAR':['SMR'],
 'FINTECH':['HOOD','UPST'],
 'LEGACY_AI_TURNAROUND':['BB'],
}
THEME_BY={t:theme for theme,vals in THEMES.items() for t in vals}
CATALYST_BASE={'AI':18,'QUANTUM':20,'SPACE':16,'CRYPTO':12,'EV':6,'NUCLEAR':14,'FINTECH':8,'LEGACY_AI_TURNAROUND':24}

# v1.4.0 semantic news taxonomy: not just simple positive/negative words.
# Each class has phrases, impact, durability and quality hints. The classifier combines
# action verbs + domain nouns + business impact instead of one keyword hit.
SEMANTIC_CATALYSTS={
 'major_partnership':{
   'phrases':['strategic partnership','expanded partnership','collaboration with','teams with','partners with','integrates with','jointly develop','alliance with'],
   'verbs':['partner','collaborat','integrat','alliance','team up'], 'nouns':['nvidia','microsoft','amazon','google','government','enterprise','customer','platform'], 'impact':28, 'durability':0.85},
 'government_contract':{
   'phrases':['government contract','contract award','defense contract','federal contract','dod contract','military contract','government deal'],
   'verbs':['award','select','contract','procure','deploy'], 'nouns':['government','federal','dod','defense','navy','air force','army','military'], 'impact':34, 'durability':0.95},
 'earnings_acceleration':{
   'phrases':['beats estimates','beat expectations','raises guidance','raised guidance','record revenue','revenue growth','profitability improves','strong quarter'],
   'verbs':['beat','raise','increase','accelerat','surpass','outperform'], 'nouns':['earnings','revenue','guidance','eps','margin','bookings'], 'impact':30, 'durability':0.75},
 'product_platform_launch':{
   'phrases':['launches platform','unveils platform','new product','product launch','commercial launch','announces platform','releases model'],
   'verbs':['launch','unveil','release','introduce','ship','commercializ'], 'nouns':['platform','product','solution','chip','model','software','system'], 'impact':21, 'durability':0.65},
 'ai_transformation':{
   'phrases':['ai transformation','artificial intelligence strategy','edge ai','agentic ai','generative ai','machine learning platform','robotics ai'],
   'verbs':['transform','pivot','expand','build','deploy','automate'], 'nouns':['ai','artificial intelligence','machine learning','agentic','automation','robotics','edge'], 'impact':24, 'durability':0.8},
 'analyst_upgrade':{
   'phrases':['upgraded to buy','raises price target','price target raised','initiates buy','outperform rating'],
   'verbs':['upgrade','raise','initiate','reiterate'], 'nouns':['buy','outperform','price target','analyst','rating'], 'impact':14, 'durability':0.4},
 'capital_strength':{
   'phrases':['cash position','balance sheet','debt reduction','buyback','funding secured','strategic investment'],
   'verbs':['secure','raise','reduce','repay','buyback'], 'nouns':['cash','debt','funding','capital','investment','balance sheet'], 'impact':14, 'durability':0.7},
 'sector_rerating':{
   'phrases':['sector rally','ai stocks rally','quantum stocks jump','space stocks rise','crypto stocks climb'],
   'verbs':['rally','jump','surge','climb','rerate'], 'nouns':['sector','stocks','theme','ai','quantum','space','crypto'], 'impact':18, 'durability':0.55},
}
SEMANTIC_RISKS={
 'dilution_offering':{
   'phrases':['stock offering','share offering','public offering','registered direct offering','atm program','convertible notes','warrants'],
   'verbs':['offer','issue','sell','raise'], 'nouns':['shares','stock','offering','warrants','convertible','atm'], 'impact':-36},
 'guidance_miss':{
   'phrases':['misses estimates','missed expectations','weak guidance','cuts guidance','lowered guidance','revenue miss'],
   'verbs':['miss','cut','lower','warn'], 'nouns':['guidance','estimates','revenue','earnings','eps'], 'impact':-34},
 'legal_regulatory':{
   'phrases':['lawsuit','class action','sec investigation','regulatory probe','investigation into'],
   'verbs':['sue','investigat','probe','charge'], 'nouns':['lawsuit','class action','sec','regulatory','fraud'], 'impact':-24},
 'analyst_downgrade':{
   'phrases':['downgraded to sell','downgrade','price target cut','underperform rating','sell rating'],
   'verbs':['downgrade','cut','lower'], 'nouns':['sell','underperform','price target','rating','analyst'], 'impact':-16},
 'execution_delay':{
   'phrases':['delays launch','production delay','recall','restructuring','layoffs','delivery miss'],
   'verbs':['delay','recall','restructure','layoff','miss'], 'nouns':['launch','production','delivery','jobs','recall'], 'impact':-20},
}
SOURCE_WEIGHTS={'Reuters':1.30,'Bloomberg':1.25,'CNBC':1.12,'MarketWatch':1.05,'Yahoo Finance':1.0,'InvestorPlace':0.72,'Motley Fool':0.75,'PR Newswire':0.90,'GlobeNewswire':0.88,'Business Wire':0.90,'Accesswire':0.82}
def _norm(txt):
    return re.sub(r'\s+',' ',str(txt or '')).strip()

def _contains_any(text, words):
    t=text.lower()
    return any(w in t for w in words)

def _semantic_hits(text, taxonomy):
    """Return classes based on phrase hits OR verb+noun co-occurrence.
    This is still local/no-API, but it is context-sensitive rather than a single keyword count.
    """
    t=text.lower()
    out=[]
    for cls,cfg in taxonomy.items():
        phrase_hit=any(p in t for p in cfg.get('phrases',[]))
        verb_hit=any(v in t for v in cfg.get('verbs',[]))
        noun_hit=any(n in t for n in cfg.get('nouns',[]))
        if phrase_hit or (verb_hit and noun_hit):
            out.append(cls)
    return out

def _source_weight(publisher):
    p=(publisher or '').lower()
    for k,w in SOURCE_WEIGHTS.items():
        if k.lower() in p: return w
    return 1.0

def _recency_weight(ts):
    now=time.time()
    try:
        if isinstance(ts,(int,float)) and ts>0:
            age=max(0,(now-float(ts))/86400.0)
            return max(0.12,1/(1+age/5.0)), round(age,2)
    except Exception: pass
    return 0.45, None

def _theme_alignment(text, theme, ticker):
    t=text.lower(); score=0
    theme_words={
      'AI':['ai','artificial intelligence','machine learning','automation','agentic','robotics','edge ai'],
      'QUANTUM':['quantum','qubit','quantum computing','ion trap'],
      'SPACE':['space','launch','satellite','rocket','aerospace','orbit'],
      'CRYPTO':['bitcoin','crypto','blockchain','mining','digital asset'],
      'EV':['electric vehicle','ev','battery','vehicle','delivery'],
      'NUCLEAR':['nuclear','reactor','smr','uranium','energy'],
      'FINTECH':['fintech','trading','brokerage','payments','loan','credit'],
      'LEGACY_AI_TURNAROUND':['blackberry','ai','cybersecurity','iot','qnx','automotive software'],
    }
    words=theme_words.get(theme,[])
    hits=sum(1 for w in words if w in t)
    if ticker.lower() in t: score += 18
    score += min(45,hits*12)
    if theme.lower().replace('_',' ') in t: score += 18
    return min(100,score)

def fetch_news_yahoo_search(ticker):
    """Direct Yahoo Finance search API fallback. Usually returns news without requiring yfinance.news."""
    url='https://query1.finance.yahoo.com/v1/finance/search'
    params={'q':ticker,'quotesCount':0,'newsCount':25,'enableFuzzyQuery':'false','quotesQueryId':'tss_match_phrase_query','newsQueryId':'news_cie_vespa','listsCount':0}
    headers={'User-Agent':'Mozilla/5.0 SEE/1.4.0'}
    items=[]
    try:
        r=requests.get(url,params=params,headers=headers,timeout=12)
        if r.ok:
            data=r.json()
            for x in data.get('news',[])[:25]:
                title=_norm(x.get('title'))
                publisher=_norm(x.get('publisher'))
                link=_norm(x.get('link'))
                ts=x.get('providerPublishTime') or x.get('published_at') or 0
                summary=_norm(x.get('summary') or x.get('provider'))
                if title:
                    items.append({'ticker':ticker,'title':title,'summary':summary[:320],'publisher':publisher,'published':ts,'link':link,'source':'yahoo_search','text':_norm(title+' '+summary)})
    except Exception as e:
        print(f'[SEE] WARN yahoo search news failed {ticker}: {e}')
    return items

def fetch_news_yfinance(ticker):
    items=[]
    try:
        raw=yf.Ticker(ticker).news or []
        for x in raw[:25]:
            title=_norm(x.get('title'))
            publisher=_norm(x.get('publisher') or x.get('provider'))
            ts=x.get('providerPublishTime') or x.get('pubDate') or 0
            link=_norm(x.get('link'))
            summary=_norm(x.get('summary') or publisher)
            if title:
                items.append({'ticker':ticker,'title':title,'summary':summary[:320],'publisher':publisher,'published':ts,'link':link,'source':'yfinance','text':_norm(title+' '+summary)})
    except Exception as e:
        print(f'[SEE] WARN yfinance news failed {ticker}: {e}')
    return items

def fetch_news_intelligence(ticker, theme):
    # 1) Ingest real headlines from multiple free Yahoo paths.
    items=fetch_news_yahoo_search(ticker)
    if not items:
        items=fetch_news_yfinance(ticker)
    # De-duplicate by normalized title.
    seen=set(); clean=[]
    for it in items:
        key=hashlib.md5(it['title'].lower().encode()).hexdigest()
        if key not in seen:
            seen.add(key); clean.append(it)
    items=clean[:25]
    base=CATALYST_BASE.get(theme,4)
    if not items:
        return {'ticker':ticker,'theme':theme,'news_items':0,'catalyst_score':base,'bullish_classes':'theme_proxy_no_live_headlines','bearish_classes':'','news_quality':'proxy_no_headlines','top_headline':'','continuation_impact_score':base,'semantic_strength':0,'attention_score':0,'theme_alignment':0}, []
    scored=[]; bull_classes=[]; bear_classes=[]; clusters={}
    for it in items:
        text=it['text']
        bull=_semantic_hits(text, SEMANTIC_CATALYSTS)
        bear=_semantic_hits(text, SEMANTIC_RISKS)
        bull_classes += bull; bear_classes += bear
        srcw=_source_weight(it.get('publisher',''))
        recw,age=_recency_weight(it.get('published'))
        theme_align=_theme_alignment(text,theme,ticker)
        positive=sum(SEMANTIC_CATALYSTS[c]['impact']*SEMANTIC_CATALYSTS[c].get('durability',0.6) for c in bull)
        negative=sum(abs(SEMANTIC_RISKS[c]['impact']) for c in bear)
        semantic_strength=max(-100,min(100,positive-negative))
        # Event type for audit: strongest class wins, risk overrides if larger absolute impact.
        event_type='none'
        if bull: event_type=max(bull,key=lambda c:SEMANTIC_CATALYSTS[c]['impact'])
        if bear and (not bull or max(abs(SEMANTIC_RISKS[c]['impact']) for c in bear) > max(SEMANTIC_CATALYSTS[c]['impact'] for c in bull)):
            event_type=max(bear,key=lambda c:abs(SEMANTIC_RISKS[c]['impact']))
        clusters[event_type]=clusters.get(event_type,0)+1
        raw=base + semantic_strength*0.55 + theme_align*0.22
        score=raw*srcw*recw
        it.update({'bullish_classes':'|'.join(sorted(set(bull))),'bearish_classes':'|'.join(sorted(set(bear))),'event_type':event_type,'semantic_strength':round(semantic_strength,2),'theme_alignment':round(theme_align,2),'news_score':round(score,2),'recency_weight':round(recw,3),'age_days':age,'source_weight':srcw})
        scored.append(it)
    pos=sum(1 for x in scored if x['news_score']>10); neg=sum(1 for x in scored if x['news_score']<0)
    attention=min(35, len(scored)*2 + max(clusters.values())*5)
    avg_top=sum(x['news_score'] for x in sorted(scored,key=lambda z:z['news_score'],reverse=True)[:8])/max(1,min(8,len(scored)))
    avg_sem=sum(x['semantic_strength'] for x in scored[:12])/max(1,min(12,len(scored)))
    avg_theme=sum(x['theme_alignment'] for x in scored[:12])/max(1,min(12,len(scored)))
    continuation=max(-100,min(100, avg_top + attention + pos*3 - neg*7))
    final=max(-100,min(100, continuation*0.78 + avg_sem*0.12 + avg_theme*0.10))
    top=max(scored,key=lambda x:x['news_score']) if scored else {'title':''}
    summary={'ticker':ticker,'theme':theme,'news_items':len(items),'catalyst_score':round(final,2),'continuation_impact_score':round(continuation,2),'semantic_strength':round(avg_sem,2),'attention_score':round(attention,2),'theme_alignment':round(avg_theme,2),'bullish_classes':'|'.join(sorted(set(bull_classes)))[:220],'bearish_classes':'|'.join(sorted(set(bear_classes)))[:220],'news_quality':'live_yahoo_semantic','top_headline':top.get('title','')[:220]}
    for x in scored: x.pop('text',None)
    return summary, scored

def dl(ticker, period):
    try:
        df=yf.download(ticker, period=period, interval='1d', auto_adjust=True, progress=False, threads=False)
        if df is None or df.empty: return pd.DataFrame()
        if isinstance(df.columns, pd.MultiIndex): df.columns=[c[0] for c in df.columns]
        df=df.reset_index()
        df.columns=[str(c).lower() for c in df.columns]
        if 'date' not in df.columns: df=df.rename(columns={df.columns[0]:'date'})
        return df[['date','open','high','low','close','volume']].dropna().copy()
    except Exception as e:
        print(f'[WARN] {ticker} download failed: {e}')
        return pd.DataFrame()

def add_features(df, spy=None, qqq=None):
    d=df.copy()
    d['ret1']=d.close.pct_change()
    d['ret5']=d.close.pct_change(5)
    d['ret20']=d.close.pct_change(20)
    d['ma20']=d.close.rolling(20).mean(); d['ma50']=d.close.rolling(50).mean()
    d['vol20']=d.volume.rolling(20).mean()
    d['rv']=d.volume/d['vol20']
    d['high20']=d.high.rolling(20).max().shift(1)
    d['low10']=d.low.rolling(10).min().shift(1)
    delta=d.close.diff(); gain=delta.clip(lower=0).rolling(14).mean(); loss=(-delta.clip(upper=0)).rolling(14).mean()
    rs=gain/loss.replace(0,np.nan); d['rsi']=100-(100/(1+rs))
    if spy is not None and not spy.empty:
        s=spy[['date','close']].rename(columns={'close':'spy_close'})
        d=d.merge(s,on='date',how='left'); d['spy_ret20']=d.spy_close.pct_change(20); d['rs_spy20']=d.ret20-d.spy_ret20
    else: d['rs_spy20']=np.nan
    if qqq is not None and not qqq.empty:
        q=qqq[['date','close']].rename(columns={'close':'qqq_close'})
        d=d.merge(q,on='date',how='left'); d['qqq_ret20']=d.qqq_close.pct_change(20); d['rs_qqq20']=d.ret20-d.qqq_ret20
    else: d['rs_qqq20']=np.nan
    return d

def regime_series(spy, qqq):
    m=spy[['date','close']].rename(columns={'close':'spy'}).merge(qqq[['date','close']].rename(columns={'close':'qqq'}),on='date',how='outer').sort_values('date')
    m['spy_ma50']=m.spy.rolling(50).mean(); m['qqq_ma50']=m.qqq.rolling(50).mean()
    m['spy_ret20']=m.spy.pct_change(20); m['qqq_ret20']=m.qqq.pct_change(20)
    score=50+25*((m.spy>m.spy_ma50).astype(float)-0.5)*2+25*((m.qqq>m.qqq_ma50).astype(float)-0.5)*2+100*((m.spy_ret20.fillna(0)+m.qqq_ret20.fillna(0))/2).clip(-.1,.1)
    m['regime_score']=score.clip(0,100)
    m['regime_label']=pd.cut(m.regime_score,[-1,35,60,100],labels=['RISK_OFF','NEUTRAL','RISK_ON'])
    return m[['date','regime_score','regime_label','spy_ret20','qqq_ret20']]

def signals(d, ticker, intel=None):
    out=[]
    theme=THEME_BY.get(ticker,'GENERAL')
    theme_bonus=CATALYST_BASE.get(theme,4)
    theme_score=min(100,50+theme_bonus*2)
    catalyst_proxy=float((intel or {}).get('catalyst_score', theme_bonus))
    for i in range(60,len(d)-max(HOLDS)-1):
        r=d.iloc[i]
        common={'date':r.date,'ticker':ticker,'theme':theme,'theme_score':theme_score,'catalyst_score':catalyst_proxy,'news_quality':(intel or {}).get('news_quality','proxy'),'top_headline':(intel or {}).get('top_headline',''),'rs_spy20':r.rs_spy20,'rs_qqq20':r.rs_qqq20,'rv':r.rv,'rsi':r.rsi}
        if r.close>r.ma50 and r.ret20>.08 and r.rv>1.15:
            out.append({**common,'setup':'momentum_continuation_legacy','entry_idx':i,'entry':r.close,'trigger_strength':r.ret20*100+r.rv*5})
        if r.rs_spy20>.08 and r.rs_qqq20>.04 and r.close>r.ma20:
            out.append({**common,'setup':'relative_strength_leader','entry_idx':i,'entry':r.close,'trigger_strength':(r.rs_spy20+r.rs_qqq20)*100})
        if r.ret20>.08 and r.rs_spy20>.05 and r.rv>1.1 and r.close>r.ma20:
            out.append({**common,'setup':'momentum_rs_continuation','entry_idx':i,'entry':r.close,'trigger_strength':r.ret20*100+r.rs_spy20*100})
        if r.close>r.high20 and r.rv>1.25:
            out.append({**common,'setup':'breakout_continuation','entry_idx':i,'entry':r.close,'trigger_strength':r.rv*10})
        if r.rv>1.75 and r.ret5>.05:
            out.append({**common,'setup':'volume_expansion_followthrough','entry_idx':i,'entry':r.close,'trigger_strength':r.rv*8+r.ret5*100})
        # v1.3.0 intelligence combinations
        if r.ret20>.06 and r.rs_spy20>.05 and theme_score>=75:
            out.append({**common,'setup':'theme_momentum_leader','entry_idx':i,'entry':r.close,'trigger_strength':theme_score/2+r.rs_spy20*100})
        if catalyst_proxy>=35 and r.rv>1.2 and r.close>r.ma20:
            out.append({**common,'setup':'catalyst_momentum_proxy','entry_idx':i,'entry':r.close,'trigger_strength':catalyst_proxy*2+r.rv*5})
    return out

def summarize(trades):
    df=pd.DataFrame(trades)
    if df.empty: return pd.DataFrame()
    rows=[]
    for (ticker,setup,hold),g in df.groupby(['ticker','setup','hold_days']):
        n=len(g); avg=g.ret_net.mean(); win=(g.ret_net>0).mean()*100; med=g.ret_net.median()
        theme=g.theme.iloc[0]; theme_score=float(g.theme_score.mean()); cat=float(g.catalyst_score.mean())
        rs=float(g.rs_spy20.mean()*100) if g.rs_spy20.notna().any() else 0
        reg=float(g.regime_score.mean()) if 'regime_score' in g else 50
        evidence=(avg*100*3)+(win-50)+min(n,60)*0.6+max(rs,0)*0.5+theme_score*0.12+cat*0.25+(reg-50)*0.15
        fake= n<15 or (win>=90 and n<30)
        usable= n>=15 and not fake
        good= usable and win>=55 and avg>0.02 and evidence>=40
        elite= usable and n>=25 and win>=58 and avg>0.035 and evidence>=60
        rows.append(dict(version=VERSION,ticker=ticker,setup=setup,hold_days=hold,trades=n,winrate=round(win,2),avg_return=round(avg*100,3),median_return=round(med*100,3),expectancy=round(avg*100,3),theme=theme,theme_score=round(theme_score,2),catalyst_score=round(cat,2),avg_rs_spy20=round(rs,2),avg_regime_score=round(reg,2),evidence_score=round(evidence,2),fake_alpha_warning=int(fake),usable=int(usable),good_candidate=int(good),elite=int(elite),rank_reason=('ELITE' if elite else 'GOOD' if good else 'USABLE' if usable else 'FILTERED')))
    return pd.DataFrame(rows).sort_values(['elite','good_candidate','evidence_score'],ascending=[False,False,False])

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--tickers',required=True); ap.add_argument('--period',default='2y'); args=ap.parse_args()
    tickers=[x.strip().upper() for x in args.tickers.split(',') if x.strip()]
    print(f'[SEE {VERSION}] tickers={len(tickers)} period={args.period}')
    spy=add_features(dl('SPY',args.period)); qqq=add_features(dl('QQQ',args.period))
    reg=regime_series(spy,qqq)
    all_tr=[]
    news_rows=[]
    news_items=[]
    for t in tickers:
        raw=dl(t,args.period)
        if raw.empty or len(raw)<100: continue
        theme=THEME_BY.get(t,'GENERAL')
        intel, items = fetch_news_intelligence(t, theme)
        news_rows.append(intel); news_items.extend(items)
        d=add_features(raw,spy,qqq).merge(reg[['date','regime_score','regime_label']],on='date',how='left')
        sigs=signals(d,t,intel)
        for s in sigs:
            i=s.pop('entry_idx'); entry=s['entry']
            for h in HOLDS:
                if i+h < len(d):
                    exitp=float(d.iloc[i+h].close); ret=exitp/entry-1-COST
                    all_tr.append({**s,'hold_days':h,'exit_date':d.iloc[i+h].date,'exit':exitp,'ret_net':ret,'regime_score':float(d.iloc[i].regime_score) if pd.notna(d.iloc[i].regime_score) else 50,'regime_label':str(d.iloc[i].regime_label)})
    trades=pd.DataFrame(all_tr)
    summary=summarize(all_tr)
    # aggregate exports
    def save(df,name): df.to_csv(EXPORT/name,index=False)
    save(trades, f'see_trades_{VERSION}.csv')
    save(summary, f'see_summary_{VERSION}.csv')
    save(summary[summary.elite==1] if not summary.empty else summary, f'see_elite_{VERSION}.csv')
    save(summary[summary.usable==1] if not summary.empty else summary, f'see_usable_{VERSION}.csv')
    if not trades.empty:
        by_setup=summary.groupby('setup').agg(rows=('setup','count'),trades=('trades','sum'),good=('good_candidate','sum'),elite=('elite','sum'),avg_expectancy=('expectancy','mean'),avg_evidence=('evidence_score','mean')).reset_index().sort_values('avg_evidence',ascending=False)
        by_ticker=summary.groupby('ticker').agg(rows=('ticker','count'),trades=('trades','sum'),good=('good_candidate','sum'),elite=('elite','sum'),avg_expectancy=('expectancy','mean'),avg_evidence=('evidence_score','mean')).reset_index().sort_values('avg_evidence',ascending=False)
        diag=summary.groupby('setup').agg(total_rows=('setup','count'),usable=('usable','sum'),good=('good_candidate','sum'),elite=('elite','sum'),trades=('trades','sum'),mean_evidence=('evidence_score','mean')).reset_index()
        theme=summary.groupby('theme').agg(rows=('theme','count'),trades=('trades','sum'),elite=('elite','sum'),avg_evidence=('evidence_score','mean'),avg_expectancy=('expectancy','mean')).reset_index().sort_values('avg_evidence',ascending=False)
        catalyst=summary.groupby(['ticker','theme']).agg(rows=('ticker','count'),elite=('elite','sum'),avg_catalyst=('catalyst_score','mean'),avg_theme_score=('theme_score','mean'),avg_evidence=('evidence_score','mean')).reset_index().sort_values('avg_evidence',ascending=False)
        save(by_setup,f'see_by_setup_{VERSION}.csv'); save(by_ticker,f'see_by_ticker_{VERSION}.csv'); save(diag,f'see_engine_diagnostics_{VERSION}.csv'); save(theme,f'see_theme_rotation_{VERSION}.csv'); save(catalyst,f'see_catalyst_{VERSION}.csv'); save(reg,f'see_regime_{VERSION}.csv'); save(pd.DataFrame(news_rows), f'see_news_intelligence_{VERSION}.csv'); save(pd.DataFrame(news_items), f'see_news_items_{VERSION}.csv');
        ni=pd.DataFrame(news_items)
        if not ni.empty:
            events=ni.sort_values(['ticker','news_score'], ascending=[True,False])[[c for c in ['ticker','event_type','title','publisher','news_score','semantic_strength','theme_alignment','bullish_classes','bearish_classes','link'] if c in ni.columns]]
        else:
            events=pd.DataFrame()
        save(events, f'see_catalyst_events_{VERSION}.csv')
    else:
        for n in ['by_setup','by_ticker','engine_diagnostics','theme_rotation','catalyst','regime','news_intelligence','news_items','catalyst_events']:
            pd.DataFrame().to_csv(EXPORT/f'see_{n}_{VERSION}.csv',index=False)
    with zipfile.ZipFile(EXPORT/'all.zip','w',zipfile.ZIP_DEFLATED) as z:
        for p in EXPORT.glob(f'*.csv'): z.write(p,p.name)
    status={'ok':True,'version':VERSION,'generated_at':datetime.utcnow().isoformat()+'Z','trades':int(len(trades)),'summary_rows':int(len(summary)),'elite':int(summary.elite.sum()) if not summary.empty else 0,'good':int(summary.good_candidate.sum()) if not summary.empty else 0,'news_items':int(len(news_items))}
    (OUT/'status.json').write_text(json.dumps(status,indent=2))
    print('[SEE] Done.', status)
if __name__=='__main__': main()
