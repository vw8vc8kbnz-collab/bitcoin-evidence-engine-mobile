# Stock Evidence Engine v1.4.0

AI News Intelligence release: real Yahoo headline ingestion, local semantic catalyst classification, continuation-impact scoring, theme alignment and catalyst event exports.
