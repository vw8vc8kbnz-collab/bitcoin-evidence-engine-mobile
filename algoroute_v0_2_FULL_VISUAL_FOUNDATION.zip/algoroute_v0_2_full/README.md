# AlgoRoute v0.2 Full Visual Foundation

Werkende foundation met:
- AlgoRoute branding/stijl
- Desktop cockpit
- Live Map Nederland UI
- Import Studio sectie
- Wagenpark sectie
- Driver PWA shell
- Klanttracking shell
- FastAPI backend
- Docker Compose
- C++ optimizer-core structuur

Open na deploy:
- Web: http://SERVER-IP:8787
- API: http://SERVER-IP:8788/api/health

Poort 8912 blijft vrij voor bestaande oude tools.
