#!/usr/bin/env bash
curl -fsS http://localhost:8787 >/dev/null && echo "web ok"
curl -fsS http://localhost:8788/api/health && echo
