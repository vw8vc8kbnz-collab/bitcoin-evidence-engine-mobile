#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [ ! -f .env ]; then cp .env.example .env; fi
sudo ufw allow 8787/tcp || true
sudo ufw allow 8788/tcp || true
docker compose up -d --build
docker compose ps
