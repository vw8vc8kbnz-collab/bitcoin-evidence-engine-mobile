# Termius update - AlgoRoute v0.2 Full

```bash
cd /home/ubuntu
rm -rf algoroute_latest
rm -f algoroute_v0_2_full_visual_foundation.zip

wget -O /home/ubuntu/algoroute_v0_2_full_visual_foundation.zip "PLAK_HIER_JE_GITHUB_RAW_ZIP_LINK"

file /home/ubuntu/algoroute_v0_2_full_visual_foundation.zip
unzip -t /home/ubuntu/algoroute_v0_2_full_visual_foundation.zip

mkdir -p /home/ubuntu/algoroute_latest
unzip -o /home/ubuntu/algoroute_v0_2_full_visual_foundation.zip -d /home/ubuntu/algoroute_latest
cd /home/ubuntu/algoroute_latest
chmod +x scripts/*.sh
sudo ./scripts/install.sh
curl http://localhost:8788/api/health
```

Open:
`http://51.195.102.180:8787`
