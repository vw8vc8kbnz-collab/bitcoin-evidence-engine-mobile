# AlgoRoute Worker
Python orchestration layer for import jobs, provider calls and C++ core invocation.
