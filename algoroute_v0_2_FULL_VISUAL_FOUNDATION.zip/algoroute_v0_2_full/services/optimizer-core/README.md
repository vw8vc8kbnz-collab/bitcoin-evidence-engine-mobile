# AlgoRoute C++ Optimization Core

Placeholder structure for the production C++ core:
- route optimization
- load-route coupling
- customer promise guard
- live traffic rerouting
- pallet/roll-container capacity checks
