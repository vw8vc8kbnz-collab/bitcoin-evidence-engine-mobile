// AlgoRoute C++ core placeholder.
// Production implementation will use OR-Tools C++ + custom route/load constraints.
int main_placeholder() { return 0; }
