from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from datetime import datetime

app = FastAPI(title="AlgoRoute API", version="0.2.1")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

class Vehicle(BaseModel):
    id: str
    plate: str
    driver: str
    status: str
    load: int
    stops_done: int
    stops_total: int
    lat: float
    lng: float

VEHICLES = [
    Vehicle(id="V-01", plate="V-123-AB", driver="Jan de Vries", status="active", load=85, stops_done=7, stops_total=12, lat=52.09, lng=5.12),
    Vehicle(id="V-02", plate="V-456-CD", driver="Pieter Smit", status="active", load=72, stops_done=5, stops_total=10, lat=51.92, lng=4.48),
    Vehicle(id="V-03", plate="V-789-EF", driver="Marco Jansen", status="maintenance", load=30, stops_done=0, stops_total=0, lat=51.44, lng=5.47),
]

@app.get("/api/health")
def health():
    return {"ok": True, "app": "AlgoRoute", "version": "0.2.1", "time": datetime.utcnow().isoformat()+"Z"}

@app.get("/api/vehicles")
def vehicles():
    return [v.model_dump() for v in VEHICLES]

@app.get("/api/summary")
def summary():
    return {
        "routes": 12,
        "on_time": 98,
        "stops": 256,
        "kilometers": 1248,
        "fuel_l": 412,
        "co2_saved_kg": 125,
        "load_capacity": 84,
        "alerts": [
            {"type": "traffic", "title": "Verkeersvertraging A2", "body": "10 min extra reistijd", "time": "10:24"},
            {"type": "route", "title": "Afwijking leveradres", "body": "Route aangepast", "time": "09:15"},
            {"type": "delay", "title": "Stop vertraagd", "body": "Klant niet aanwezig", "time": "08:47"},
        ]
    }

@app.post("/api/import/preview")
def import_preview():
    return {"rows": 256, "errors": 0, "warnings": 3, "suggested_fields": ["Ordernummer", "Klantnaam", "Postcode", "Aantal Europallets"]}

@app.post("/api/optimizer/demo")
def optimizer_demo():
    return {"job_id": "demo-optimizer-001", "status": "queued", "engine": "ELR/AlgoRoute C++ core placeholder"}
