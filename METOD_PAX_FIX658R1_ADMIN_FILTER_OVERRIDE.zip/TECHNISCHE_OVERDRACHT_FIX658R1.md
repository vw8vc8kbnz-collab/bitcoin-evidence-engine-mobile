# Technische overdracht — FIX658R1_ADMIN_FILTER_OVERRIDE

## Golden basis
FIX658R1 is een minimale vervolgpatch op FIX658_LIBRARY_TAXONOMY, dat weer bovenop de live/golden FIX657R4 stability/pricing baseline staat. De bestaande publieke infrastructuur blijft exact `http://51.195.102.180:8790/` via Nginx naar Python op `127.0.0.1:8792`.

## Functioneel doel
De automatische taxonomy van FIX658 blijft de default, maar Admin kan voor een reeds gepubliceerd CSV-product de primaire Tool A-filterfamilie corrigeren. Dit lost uitzonderingen op zonder productdata of de CSV te muteren.

## UI
In Admin > Decor Library > geselecteerd Catalogusproduct staat `#matCsvOnlyFamilyOverride` met:
- AUTO
- Hout
- Uni
- Steen & beton
- Metaal
- Textiel & leer
- Grafisch
- Fantasie

`change` roept `materialsSaveFamilyOverride()` aan. De UI meldt of de huidige staat automatisch of handmatig is.

## Backend API
`POST /api/admin/materials/live_taxonomy_family`
Body:
- `publicMaterialId`: opaque `decor_...` ID
- `primaryVisualFamily`: `AUTO` of één waarde uit `CATALOG_PUBLIC_FAMILIES`

De route valt onder de bestaande `/api/admin/*` auth- en Origin-guard.

### Handmatig
`catalog_taxonomy.apply_admin_family_override()` wijzigt uitsluitend de effectieve familievelden en taxonomy auditstatus. `taxonomyManualFamilyOverride` wordt private opgeslagen.

### Automatisch
`catalog_taxonomy.clear_admin_family_override()` herberekent uitsluitend de familie via de deterministische classifier. Bestaande substrateType/substrateLabel blijven onaangetast. Als de classifier geen veilige publieke familie kan bepalen, faalt reset met een duidelijke fout in plaats van `Onbekend` live te zetten.

## Private registry
`app/system/catalog_taxonomy_registry.json` blijft backend-only. `registry_with_records()` bewaart nu ook `taxonomyManualFamilyOverride`.

Herimportgedrag:
- identieke productidentiteit: manual override wordt hergebruikt;
- alleen prijs gewijzigd: override blijft;
- alleen plaatmaat gewijzigd: override blijft;
- productnaam/merk/manufacturer identity wezenlijk gewijzigd: classificationFingerprint wijzigt en oude override wordt niet blind hergebruikt;
- product verwijderd: verdwijnt uit actieve CSV-library, registry mag orphan metadata bewaren;
- later hetzelfde product terug: registry kan override opnieuw koppelen.

## CSV-truth guard
De live endpoint maakt vóór en na wijziging een immutable snapshot van o.a.:
`articleNo`, `publicMaterialId`, `productName`, `publicName`, `sheetWid`, `sheetLen`, `thicknessMm`, `sellPriceInclVatPerSheet`, `sellPriceExVatPerSheet`, `priceVatRate`, `priceSource`, image-identiteit, `sourceKind`, `active`, `published`.
Bij verschil faalt de mutatie.

De taxonomy registry wordt eerst atomisch geschreven; een orphan registryrecord kan nooit een product activeren. Daarna wordt `material_library.json` atomisch geschreven en de publieke cataloguscache geïnvalideerd.

## Publieke privacy
`taxonomyManualFamilyOverride`, taxonomySource/confidence en artikelnummer komen niet in `_material_record_to_toola_catalog()`. Tool A krijgt alleen de effectieve categorie plus reeds toegestane publieke metadata.

## Regressiecontracten behouden
- CSV-only catalogus.
- 18/19/20 mm.
- exact replacement bij CSV-publicatie.
- stabiele opaque public IDs.
- plaatprijs exact CSV incl. BTW; geen tweede BTW.
- overige Admin-kosten excl. BTW + 21%.
- `/api/jobs` enige optimizerroute.
- final submit gebruikt finalized parentjob en is idempotent.
- bearer-only jobtokens/sessionStorage.
- publieke SSE alleen `dxf_changed`.
- production hardening/hash-only Admin.
- root-only credentials 0600.
- state-preserving deploy + rollback.
- geen `curl | grep -q` finale smokecheck onder pipefail.

## Tests
`tools/fix658r1_regression.py` test onder andere:
- huidige 597-productencatalogus;
- automatische taxonomy;
- toekomstige CSV lifecycle;
- handmatige family override;
- private registry persistence;
- price-change persistence;
- auto reset;
- echte endpointmutatie in temp state;
- immutable CSV truth;
- public privacy;
- mixed-VAT v2;
- submit/security contracts;
- deployment smokecheck contract.
