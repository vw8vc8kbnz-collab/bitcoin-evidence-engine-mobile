# FIX658R1 — Taxonomy audit huidige Material Library

**Datum audit:** 2026-08-08  
**Golden basis:** `FIX657R4_HTTP8790_STABLE_VAT_TRUTH`  
**Geteste CSV SHA-256:** `053026e2883908bed7bfd05c8c39543d91ef611ff24e40b2546003e6e3127950`  
**Doel:** eenmalig de huidige library exact classificeren én die classificatie duurzaam toepasbaar maken op volgende CSV-publicaties.

## 1. Harde architectuurgrens

FIX658 verandert de CSV-only architectuur niet. De website-CSV blijft als enige autoritatief voor:

- of een product actief is;
- productnaam;
- dikte;
- plaatlengte en -breedte;
- afbeeldingsbron;
- directe verkoopprijs per plaat **inclusief BTW**.

Taxonomy is uitsluitend aanvullende private metadata. De private registry kan nooit zelfstandig een product activeren en kan prijs, maat, dikte of CSV-lidmaatschap niet overschrijven.

## 2. Huidige CSV — resultaat

| Controle | Resultaat |
|---|---:|
| CSV-regels gelezen | 606 |
| Geldige 18/19/20-mm records | 597 |
| Uitgesloten op dikte | 9 |
| Blokkerende importfouten | 0 |
| Waarschuwingen | 18 |
| Taxonomy `REVIEW_REQUIRED` | **0** |
| Taxonomy geclassificeerd | **597 / 597** |

### Primaire decorfamilie

| Familie | Records |
|---|---:|
| Hout | 297 |
| Uni | 182 |
| Textiel & leer | 50 |
| Steen & beton | 36 |
| Metaal | 21 |
| Grafisch | 11 |
| Fantasie | 0 |
| Onbekend | **0** |

Ieder actief product heeft exact **één** `primaryVisualFamily`. De hoofdknoppen in Tool A filteren uitsluitend op dit veld; secundaire zoekwoorden mogen een product niet meer in een tweede hoofdfilter laten verschijnen.

### Drager

| Drager | Records |
|---|---:|
| Spaanplaat | 435 |
| MDF | 159 |
| Multiplex | 3 |
| Overig/onbekend | **0** |

### Merken in de huidige CSV

| Merk | Records |
|---|---:|
| DecoLegno | 236 |
| Unilin | 231 |
| Shinnoki | 36 |
| Overige / generieke plaatproducten | 94 |

## 3. Waarom oude keywordfilters niet betrouwbaar genoeg zijn

Een productnaam is geen betrouwbare decorcategorie. Voorbeelden uit officiële fabrikantdata:

- DecoLegno **FB11 Maloja** is een beton-geïnspireerd decor, terwijl dezelfde Maloja-collectie ook drie houtdecors bevat. Daarom is `Maloja = Hout` onjuist als collectieregel.
- Unilin **0U826 Stone** heet letterlijk “Stone”, maar de fabrikant classificeert het design als **Effen**. Het hoort dus bij Uni, niet Steen.
- Unilin **0U830 Mahogany** klinkt als hout, maar de fabrikant classificeert het design eveneens als **Effen**. Ook dit hoort dus bij Uni.

Daarom is FIX658 gebouwd rond één primaire taxonomy-waarheid per product in plaats van substringmatching in de UI.

## 4. Officiële fabrikanttaxonomie als bron

DecoLegno publiceert zelf de Look & Feel-hoofdgroepen:

`Hout · Uni's · Natuursteen & Beton · Stof & Leer · Metallic · Grafisch · Fantasie`

Dezelfde collectiepagina onderscheidt bovendien onder `TYPE` onder andere `Decorspaanplaat` en `MDF`, en publiceert waar relevant `Structuurrichting`.

FIX658 gebruikt officiële, gecontroleerde DecoLegno-collectieregels waar een collectie homogeen is. Gemengde collecties worden juist **per decorcode** afgehandeld. Onder andere Maloja, Talco, Taranta, Traccia en Riga hebben daarom expliciete code-regels.

Voor Unilin gebruikt FIX658 de fabrikantlogica rond Evola-designcodes en expliciet geverifieerde `0F`-decors. Een nieuwe onbekende `0F` wordt niet blind in “Andere materialen” of op basis van één los woord geplaatst.

### Officiële bronpagina's gebruikt bij de audit

- https://decolegno.nl/collectie/
- https://decolegno.nl/collectie/maloja/
- https://decolegno.nl/collectie/product/fb11-maloja/
- https://www.unilinpanels.com/nl-nl/unilin-evola-designs/0u826mst-stone
- https://www.unilinpanels.com/nl-nl/unilin-evola-designs/0u830mst-mahogany

De runtime is **niet afhankelijk** van deze websites. Er wordt dus niet live gescrapet wanneer een klant de library opent of wanneer een prijsberekening draait.

## 5. Dubbele productnamen en plaatmaten

De huidige CSV bevat **24 productnaamgroepen met meerdere plaatvarianten**, samen 54 records. Daarom is de plaatmaat vanaf FIX658 zichtbaar op iedere materiaalkaart en in de geselecteerde materiaalweergave.

Voorbeeld:

`MDF Grondeerfolie vochtwerend Wit 050 mat`

- 2440 × 1220 × 18 mm
- 3050 × 1220 × 18 mm
- 2800 × 2070 × 18 mm

Deze blijven bewust drie afzonderlijke catalogusrecords met hun eigen opaque public ID en eigen CSV-prijs. FIX658 voegt ze niet samen en verandert niets aan optimizer- of prijsbinding.

### Alle 24 huidige groepen

- Gefineerd MDF Bamboe Caramel Side Pressed A/A — 2500×1240×19; 2800×2070×19
- Gefineerd MDF Eiken Dosse A/B+ — 3050×1220×19; 2500×1240×19; 2800×2070×19
- Gefineerd MDF Eiken Dosse Mixmatch A/B — 3050×1220×19; 2800×2070×19
- Gefineerd MDF Eiken Kwartiers A/B — 3050×1220×19; 2500×1240×19
- Gefineerd MDF Eiken Mixmatch A/B+ — 2440×1220×19; 2800×2070×19
- Gefineerd MDF Eur. Eiken Mixmatch A commercial / A commercial — 3050×1220×19; 2500×1240×19
- Gefineerd MDF Kersen Amerikaans Mixmatch A/B+ — 3050×1220×19; 2800×2070×19
- Gefineerd MDF Noten Amerikaans Dosse A/B+ — 2500×1240×19; 3050×1220×19; 2800×2070×19
- Gefineerd MDF Noten Amerikaans Dosse Mixmatch A/B+ — 3050×1220×19; 2800×2070×19
- Gefineerd MDF Noten Amerikaans Mixmatch A/B+ — 3050×1220×19; 2800×2070×19
- Gefineerd MDF Oak Natural Vivace A/B — 3050×1220×19; 2500×1240×19; 2800×2070×19
- Gefineerd MDF Oak Natural Vivace A/B B1 2-zijde — 3050×1220×19; 2500×1240×19
- Gefineerd MDF Oak Naturel Adagio A/B — 3050×1220×19; 2500×1240×19
- Gefineerd MDF Oak Naturel Allegro A/B — 3050×1220×19; 2500×1240×19; 2800×2070×19
- MDF Grondeerfolie Wit 050 mat — 3050×1220×18; 2440×1220×18
- MDF Grondeerfolie vochtwerend Wit 050 mat — 2440×1220×18; 3050×1220×18; 2800×2070×18
- Unilin Evola 00025 TST Front White 70% PEFC gecert. — 3050×1250×18; 2500×1250×18; 2800×2070×18
- Unilin Evola 00113 CST Elegant Black 70% PEFC gecert. — 3050×1250×18; 2800×2070×18
- Unilin Evola 00625 CST Silicon 70% PEFC gecert. — 3050×1250×18; 2800×2070×18
- Unilin Evola 0UD81 CST Quartz 70% PEFC gecert. — 3050×1250×18; 2800×2070×18
- Unilin Evola MDF 00025 CST Front White — 3050×1220×18; 2800×2070×18
- Unilin Evola MDF V313 00025 CST Front White — 3050×1220×18; 2800×2070×18
- Unilin Evola Spaan Brandvertragend 00025 CST Front White 70% — 3050×1250×18; 2800×2070×18
- Unilin Evola Spaan V313 00025 CST Front White 70% PEFC gecert. — 3050×1250×18; 2800×2070×18

## 6. Wat bij iedere toekomstige CSV-publicatie gebeurt

FIX658 behandelt een CSV-publicatie als een gecontroleerde enrichment-pipeline:

1. CSV-parser valideert de bestaande 18/19/20-mm- en prijscontracten.
2. De importer maakt een diff: nieuw, gewijzigd, ongewijzigd en verwijderd.
3. Voor ieder artikel wordt een classificatiefingerprint berekend uit productidentiteit, niet uit prijs of plaatmaat.
4. Handmatig geverifieerde metadata wordt hergebruikt zolang de productidentiteit gelijk blijft.
5. Automatisch geverifieerde metadata wordt alleen hergebruikt wanneer ook de taxonomy-rulesetversie nog gelijk is; een software-upgrade kan dus oude auto-regels veilig opnieuw beoordelen.
6. Nieuwe producten worden met sterke fabrikant-/code-/productregels geclassificeerd.
7. Als familie of drager niet veilig bepaalbaar is, krijgt het product `REVIEW_REQUIRED` en wordt publicatie geblokkeerd.
8. Admin ziet alleen de twijfelgevallen en kiest één decorfamilie plus drager.
9. Na publicatie wordt de geverifieerde metadata in een private registry opgeslagen.
10. Verwijderde CSV-producten verdwijnen direct uit Tool A; hun private metadata mag bewaard blijven voor een eventuele latere herintroductie.

Een prijswijziging of andere plaatmaat invalideert dus niet automatisch de taxonomy. Een wezenlijk andere productidentiteit wel.

## 7. Private registry

Nieuwe private state:

`app/system/catalog_taxonomy_registry.json`

Deze bevat backend-only onder andere:

- interne article key voor koppeling;
- `primaryVisualFamily`;
- `substrateType`;
- fabrikantcode/collectie;
- status (`AUTO_VERIFIED` of `VERIFIED`);
- bron/rulesetversie;
- classificatiefingerprint.

Interne artikelnummers, fabrikantcodes, confidence en evidence worden niet via de publieke material-library API aan Tool A blootgesteld.

## 8. UI-wijzigingen

### Material card

Iedere kaart toont nu compact:

- primaire decorfamilie;
- MDF / Spaanplaat / Multiplex;
- dikte;
- **plaatmaat L × B**.

### Geselecteerd materiaal

De desktop- en mobiele geselecteerde materiaalweergave toont eveneens drager, dikte en plaatmaat.

### Hoofdfilters

De hoofdgroepen zijn:

- Hout
- Uni
- Steen & beton
- Metaal
- Textiel & leer
- Grafisch
- Fantasie

Een product kan via deze hoofdknoppen maar in één categorie voorkomen. Rijke searchTags blijven wel beschikbaar voor de zoekfunctie.

## 9. Veiligheidsgrenzen

FIX658 verandert nadrukkelijk niet:

- URL/poort (`http://51.195.102.180:8790/`);
- Nginx → Python-topologie;
- mixed-VAT v2;
- CSV-prijswaarheid;
- optimizer;
- job-finalization;
- idempotente submitflow;
- Bearer-tokencontract;
- publieke SSE-privacy;
- Admin hash-only credentials;
- state-preserving deploy/rollback.

## 10. Acceptatie-uitkomst

De aangeleverde actuele CSV doorloopt de FIX658-pipeline met:

**597 / 597 geldige actieve records geclassificeerd, 0 review required.**

Nieuwe onbekende producten worden niet gegokt. Ze verschijnen in de Admin-review vóór publicatie. Hiermee is de huidige foutklasse “steen verschijnt bij Hout” structureel opgelost in plaats van cosmetisch weggefilterd.


## FIX658R1 aanvulling
De classificatie-audit zelf is ongewijzigd. FIX658R1 voegt alleen een private Admin family-override toe voor uitzonderingen; de 597-record baseline en CSV-prijswaarheid blijven hetzelfde.
