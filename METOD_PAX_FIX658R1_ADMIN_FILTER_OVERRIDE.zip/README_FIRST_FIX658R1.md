# METOD/PAX FIX658R1 — Admin Filter Override

Dit is een kleine, geïsoleerde Library-patch bovenop FIX658.

## Wat je na deploy ziet
Open Admin > Decor Library, selecteer links een product. Rechts staat onder de productinformatie een nieuwe dropdown **Filtercategorie**.

- `Automatisch` = classifier bepaalt de categorie.
- Een concrete categorie = private Admin-override die voorrang krijgt.
- Opslaan gebeurt direct bij wijzigen van de dropdown.
- De gekozen override blijft behouden bij toekomstige CSV-imports als het hetzelfde product blijft.

## Wat NIET verandert
- Tool A: `http://51.195.102.180:8790/`
- Admin: `http://51.195.102.180:8790/admin/`
- CSV blijft enige actieve catalogusbron.
- CSV-prijs per plaat blijft incl. BTW.
- Geen wijziging aan optimizer, jobflow, DXF, submit/finalization of overige Admin-kosten.

Gebruik voor live installatie uitsluitend `INSTALL_FIX658R1_FROM_STAGE.sh` via de meegeleverde one-shot.
