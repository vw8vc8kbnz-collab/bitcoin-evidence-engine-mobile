#!/usr/bin/env bash
set -euo pipefail
APP=/home/ubuntu/stock_evidence_latest
cd "$APP"
sudo chown -R ubuntu:ubuntu "$APP" || true
python3 -m venv venv
./venv/bin/python -m pip install --upgrade pip
./venv/bin/python -m pip install -r requirements.txt
chmod +x run_backtest.sh selftest.sh engine.py server.py
sudo tee /etc/systemd/system/stock-evidence-dashboard.service >/dev/null <<EOT
[Unit]
Description=Stock Evidence Engine Dashboard
After=network.target
[Service]
Type=simple
User=ubuntu
WorkingDirectory=$APP
ExecStart=/usr/bin/python3 $APP/server.py
Restart=always
RestartSec=5
[Install]
WantedBy=multi-user.target
EOT
sudo tee /etc/systemd/system/stock-evidence-scan.service >/dev/null <<EOT
[Unit]
Description=Stock Evidence Engine DeepSeek Scan
After=network-online.target
[Service]
Type=oneshot
User=ubuntu
WorkingDirectory=$APP
ExecStart=/bin/bash -lc '$APP/run_backtest.sh "BB,PLTR,IONQ,SOUN,NVDA,AMD,TSLA,AI,BBAI,RKLB,SMR,ACHR,JOBY,UPST,HOOD,COIN,MARA,RIOT,LCID,RIVN" "2y"'
EOT
sudo tee /etc/systemd/system/stock-evidence-scan.timer >/dev/null <<EOT
[Unit]
Description=Run Stock Evidence Engine scans 4x per day
[Timer]
OnCalendar=*-*-* 13:30:00
OnCalendar=*-*-* 16:00:00
OnCalendar=*-*-* 19:00:00
OnCalendar=*-*-* 22:00:00
Persistent=true
[Install]
WantedBy=timers.target
EOT
sudo systemctl daemon-reload
sudo systemctl enable stock-evidence-dashboard.service
sudo systemctl restart stock-evidence-dashboard.service
if [ "${SEE_ENABLE_TIMER:-1}" = "1" ]; then
  sudo systemctl enable stock-evidence-scan.timer
  sudo systemctl restart stock-evidence-scan.timer
fi
