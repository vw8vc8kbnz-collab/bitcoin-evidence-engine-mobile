SEE v1.8.0 goal: combine catalyst/news reasoning with actual market reaction, multi-source consensus and analog memory while preserving stable VPS deployment.
