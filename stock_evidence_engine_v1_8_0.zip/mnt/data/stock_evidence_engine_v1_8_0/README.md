Stock Evidence Engine v1.8.0
- DeepSeek analyst brain
- Price Reaction Engine
- News Consensus Engine
- Historical Analog Memory proxy
- ntfy alerts and cost guard
Stable runtime: server.py on port 8798.
