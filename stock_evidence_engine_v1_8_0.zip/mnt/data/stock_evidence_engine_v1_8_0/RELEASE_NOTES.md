v1.8.0: adds price reaction intelligence, consensus scoring, historical analog memory exports and reaction-adjusted probabilities.
