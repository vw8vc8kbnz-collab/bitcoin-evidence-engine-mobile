#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="${BEE_ROOT_DIR:-/home/ubuntu/bitcoin-engine-deploy/current}"
LIVE_DIR="$ROOT_DIR/live_forecast"
PYTHON_BIN="${PYTHON_BIN:-python3}"

if [ ! -d "$LIVE_DIR" ]; then
  echo "ERROR: live_forecast directory not found: $LIVE_DIR"
  echo "Check that the ZIP was unpacked into $ROOT_DIR and contains live_forecast/."
  exit 1
fi

cd "$LIVE_DIR"

if ! command -v "$PYTHON_BIN" >/dev/null 2>&1; then
  echo "ERROR: python3 not found"
  exit 1
fi

if [ ! -d .venv ]; then
  "$PYTHON_BIN" -m venv .venv
fi

source .venv/bin/activate
python -m pip install --upgrade pip >/dev/null
if [ -f requirements.txt ]; then
  pip install -r requirements.txt
else
  pip install requests >/dev/null || true
fi

mkdir -p state

if [ ! -f bee_live_config.example.json ]; then
  echo "ERROR: bee_live_config.example.json missing in $LIVE_DIR"
  exit 1
fi

if [ ! -f bee_live_config.json ]; then
  cp bee_live_config.example.json bee_live_config.json
  echo "Created bee_live_config.json from example."
else
  echo "bee_live_config.json already exists; keeping it."
fi

chmod +x bee_live_forecast_v4_1_paper.py || true

echo ""
echo "✅ Live forecast install OK."
echo "Next commands:"
echo "  cd $LIVE_DIR"
echo "  source .venv/bin/activate"
echo "  nano bee_live_config.json"
echo "  python bee_live_forecast_v4_1_paper.py --test-fetch"
echo "  python bee_live_forecast_v4_1_paper.py --test-ntfy"
echo "  python bee_live_forecast_v4_1_paper.py --once"
