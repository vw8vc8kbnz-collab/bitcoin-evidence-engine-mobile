BEE Live Forecast V4.1.2 Stable Server ZIP
==========================================

Deze ZIP is bewust stabieler gemaakt:
- Geen wrapper-map in de ZIP: live_forecast/ en scripts/ staan direct in de root.
- bee_live_config.json staat alvast klaar met placeholder, zodat nano nooit een lege file opent.
- --test-fetch bestaat nu echt.
- install script maakt/controleert config automatisch.

GitHub/VPS route
----------------
1. Upload deze ZIP in GitHub root.
2. Zorg dat de naam begint met bitcoin_evidence_engine, bijvoorbeeld:
   bitcoin_evidence_engine_live_forecast_v4_1_2_stable.zip
3. Draai update.sh zoals normaal.

Na update in Termius:

cd /home/ubuntu/bitcoin-engine-deploy/current
chmod +x scripts/install_live_forecast.sh
./scripts/install_live_forecast.sh

cd live_forecast
source .venv/bin/activate
nano bee_live_config.json

Vul ntfy_topic in.

Test daarna:

python bee_live_forecast_v4_1_paper.py --test-fetch
python bee_live_forecast_v4_1_paper.py --test-ntfy
python bee_live_forecast_v4_1_paper.py --once

Belangrijk
----------
- Paper mode only.
- Geen automatische trading.
- Actieve engines fase 1: cycle_reversal, elite_reversal, reversal.
- ntfy-alert bevat model, entry, take-profit, stoploss/trailing level en historische stats.
