#!/usr/bin/env bash
set -euo pipefail
cd /home/ubuntu/bitcoin-engine-deploy/current
chmod +x scripts/install_live_forecast.sh
./scripts/install_live_forecast.sh
cd live_forecast
source .venv/bin/activate
printf '\nEdit config now with:\n  nano bee_live_config.json\n\nThen test with:\n  python bee_live_forecast_v4_1_paper.py --test-fetch\n  python bee_live_forecast_v4_1_paper.py --test-ntfy\n  python bee_live_forecast_v4_1_paper.py --once\n'
