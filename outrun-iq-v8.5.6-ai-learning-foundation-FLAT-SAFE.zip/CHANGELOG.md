# Outrun IQ v8.5.6 — AI Learning Foundation

## Nieuw
- Compacte eigen AI-learninglaag toegevoegd.
- Listings worden bij publicatie geleerd als product-/prijs-snapshot.
- Views, saves, biedingen en orders worden geaggregeerd per productkey.
- Gemiddelde listingprijs en gemiddelde verkoopprijs worden opgebouwd voor toekomstige eigen prijsdatabase.
- Admin dashboard toont learning-status, caps en top productkeys.
- Nieuwe admin JSON endpoint: `/api/admin/learning`.

## Server-safe ontwerp
- Geen ruwe klikstream in db.json.
- Geen extra fotokopieën of grote payloads.
- Product-aggregates zijn gecapt via `LEARNING_PRODUCT_CAP` (default 2000, max 5000).
- Dagaggregates zijn gecapt via `LEARNING_DAILY_CAP` (default 400, max 730).
- Oude/zwakke productkeys worden automatisch weggesnoeid.

## Checks
- `npx tsc --noEmit` OK.
