# Outrun IQ v8.5.6 — AI Learning Foundation

Deze versie bouwt de basis voor Outrun's eigen prijsdatabase en gedragsdata zonder de server vol te laten lopen.

Belangrijk:
- AI-learning bewaart alleen compacte aggregaten in `db.learning`.
- Foto's, OCR-tekst en ruwe events worden niet gedupliceerd.
- Productkeys en dagen hebben harde caps.
- Admin kan de learning-status zien in `/beheer` en JSON via `/api/admin/learning`.

Deployment blijft hetzelfde als eerdere FLAT-SAFE builds.
