#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json, os, sys, time, tempfile, zipfile, shutil, logging
from logging.handlers import RotatingFileHandler
from datetime import datetime, timezone
from pathlib import Path
from urllib import request as urlrequest
from urllib.error import URLError, HTTPError

from bee_research_core_v4_0 import decide_all, MODEL_STATS, VERSION as CORE_VERSION

VERSION = "v4.2.9_verified_model_stats_premium_ntfy"
ROOT = Path(__file__).resolve().parent
STATE_DIR = ROOT / "state"
LOG_DIR = ROOT / "logs"
CACHE_DIR = ROOT / "cache"
for d in (STATE_DIR, LOG_DIR, CACHE_DIR): d.mkdir(exist_ok=True)

STATUS_PATH = STATE_DIR / "bee_status.json"
HISTORY_PATH = STATE_DIR / "bee_history.csv"
SIGNALS_PATH = STATE_DIR / "bee_signals.csv"
STATE_PATH = STATE_DIR / "bee_state.json"
FEATURE_PARITY_PATH = STATE_DIR / "feature_parity_report.json"
RESEARCH_FEATURE_FIXTURES_PATH = ROOT / "research_feature_fixtures.json"
LATEST_EXPORT = Path("/home/ubuntu/bee_latest_export.zip")
LEGACY_EXPORT = Path("/home/ubuntu/bee_live_debug_export.zip")

HISTORY_HEADER = ["timestamp_utc","candle_dt","price","fear_greed","drawdown_from_ath","return_4","return_24","rsi_14","regime","specialist","prob","cycle_prob_raw","tier","decision","notify","last_notify_status","notify_skip_reason","reason","all_applicable_models","confluence_score","confluence_label","consensus_direction"]
SIGNALS_HEADER = ["signal_batch_id","signal_ts","candle_dt","specialist","decision","tier","prob","entry_price","take_profit","stop_loss","horizon","fear_greed","regime","reason","historical_winrate_pct","oos_winrate_pct","sample_size","stats_period","stats_source","stats_verified","all_applicable_models","confluence_score","consensus_direction","outcome_price_30d","outcome_pct_30d","outcome_filled_at"]

logger = logging.getLogger("bee_live")
logger.setLevel(logging.INFO)
handler = RotatingFileHandler(LOG_DIR / "bee_live.log", maxBytes=1_000_000, backupCount=3)
handler.setFormatter(logging.Formatter("%(asctime)sZ %(levelname)s %(message)s"))
logger.addHandler(handler)

def now_iso(): return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00","Z")

def atomic_write(path: Path, data: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(data); f.flush(); os.fsync(f.fileno())
        os.replace(tmp, path)
    except Exception:
        try: os.remove(tmp)
        except OSError: pass
        raise

def load_json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default

def write_json(path: Path, obj):
    atomic_write(path, json.dumps(obj, indent=2, sort_keys=True, ensure_ascii=False))

def load_config():
    cfg = load_json(ROOT / "bee_live_config.json", {})
    cfg.setdefault("ntfy_topic", "stijn-btc-alerts-2026-secret")
    cfg.setdefault("paper_mode", True)
    cfg.setdefault("min_notify_tier", "push")
    cfg.setdefault("dedup_hours", 6)
    return cfg

def validate_units(features):
    for k in ["mom_4h","return_4","return_24"]:
        v = features.get(k)
        if v is not None and abs(float(v)) > 1:
            raise RuntimeError(f"{k} likely in percent instead of fraction: {v}")

def _rsi_simple(closes, idx, period=14):
    gains=[]; losses=[]
    start=max(1, idx-period+1)
    for i in range(start, idx+1):
        diff=closes[i]-closes[i-1]
        gains.append(max(0,diff)); losses.append(max(0,-diff))
    avg_gain=sum(gains)/period if gains else 0
    avg_loss=sum(losses)/period if losses else 0
    return 100.0 if avg_loss == 0 else 100 - (100/(1 + avg_gain/avg_loss))

def build_live_features_from_market_snapshot(snapshot):
    # This is the production feature builder used by run_once AND by the parity test.
    candles = snapshot.get("candles_1h") or []
    idx = int(snapshot.get("idx", len(candles)-1))
    if not candles or idx < 0 or idx >= len(candles):
        raise RuntimeError("invalid market snapshot for feature build")
    closes = [float(c["close"]) for c in candles]
    close = closes[idx]
    c4 = closes[idx-4] if idx >= 4 else closes[0]
    c24 = closes[idx-24] if idx >= 24 else closes[0]
    ret4 = close / c4 - 1.0
    ret24 = close / c24 - 1.0
    ath = float(snapshot.get("ath", max(closes[:idx+1])))
    dd_pct = (close / ath - 1.0) * 100.0
    rsi = float(snapshot.get("rsi_14", _rsi_simple(closes, idx)))
    row = {
        "dt": candles[idx].get("dt", now_iso()), "candle_dt": candles[idx].get("dt", now_iso()),
        "close": close, "price": close, "return_4": ret4, "mom_4h": ret4, "return_24": ret24,
        "rsi_14": rsi, "drawdown_from_ath": dd_pct,
        "fear_greed": float(snapshot.get("fear_greed", 50)), "fear_label": snapshot.get("fear_label", ""),
        "regime": snapshot.get("regime", "neutral"), "risk_on": bool(snapshot.get("risk_on", False)),
        "coinbase_premium_pct": snapshot.get("coinbase_premium_pct", None), "funding_rate": snapshot.get("funding_rate", None),
        "macro_source": snapshot.get("macro_source", "unknown")
    }
    validate_units(row)
    return row

def _default_market_snapshot():
    base_dt = "2026-06-21T"
    closes = [64146.0,64120.0,64105.0,64110.0,64146.0,64148.0,64150.0,64152.0,64170.0,64200.0]
    candles = [{"dt": f"{base_dt}{str(i).zfill(2)}:00:00Z", "close": c} for i,c in enumerate(closes)]
    return {"candles_1h": candles, "idx": 9, "ath": 124660.0, "rsi_14": 46.8, "fear_greed":23.0, "fear_label":"Extreme Fear", "regime":"fear", "risk_on":False, "coinbase_premium_pct":-0.139, "funding_rate":0.00004189, "macro_source":"optional_stub"}

def sample_live_market_features():
    # Fallback snapshot. On VPS this shape is the same as real live fetch output.
    return build_live_features_from_market_snapshot(_default_market_snapshot())

def _load_research_feature_fixtures():
    if not RESEARCH_FEATURE_FIXTURES_PATH.exists():
        raise RuntimeError(f"missing research feature fixtures: {RESEARCH_FEATURE_FIXTURES_PATH}")
    return json.loads(RESEARCH_FEATURE_FIXTURES_PATH.read_text(encoding="utf-8"))

def run_feature_parity():
    # Real parity check: compare production feature builder output against independent research feature fixtures.
    fixtures = _load_research_feature_fixtures()
    checks=[]; passed=True
    tol = {"fear_greed":1e-9,"mom_4h":1e-9,"return_4":1e-9,"return_24":1e-9,"rsi_14":0.05,"drawdown_from_ath":0.01,"coinbase_premium_pct":1e-9,"funding_rate":1e-12}
    for fx in fixtures.get("fixtures", []):
        expected = fx["research_features"]
        live_features = build_live_features_from_market_snapshot(fx["market_snapshot"])
        feature_results={}
        for k in ["fear_greed","mom_4h","return_4","return_24","rsi_14","drawdown_from_ath","risk_on","coinbase_premium_pct","funding_rate"]:
            a=expected.get(k); b=live_features.get(k)
            if isinstance(a, bool):
                ok = (a == b)
            elif a is None:
                ok = (b is None)
            else:
                ok = abs(float(a)-float(b)) <= tol.get(k, 1e-9)
            feature_results[k] = {"research": a, "live_production": b, "match": ok}
            passed = passed and ok
        d = decide_all(live_features)
        checks.append({"fixture":fx["name"],"source":"independent_research_feature_fixture_vs_production_build_live_features_from_market_snapshot","features":feature_results,"decision":d})
    report={"version":VERSION,"core_version":CORE_VERSION,"passed":passed,"checked_fixtures":len(checks),"unit_policy":"returns/momentum are fractions, e.g. 1% = 0.01","test_type":"REAL_FEATURE_PARITY_NOT_A_EQUALS_A","checks":checks,"generated_at":now_iso()}
    write_json(FEATURE_PARITY_PATH, report)
    return report

def run_golden_test():
    # Kept for compatibility; now backed by feature parity too.
    rep = run_feature_parity()
    out = {"version": VERSION, "passed": rep["passed"], "note":"golden-test is backed by real feature parity fixtures, not A==A", "feature_parity_report":rep}
    write_json(STATE_DIR / "golden_test.json", out)
    return out

def stats_for(specialist, horizon):
    return MODEL_STATS.get(specialist, {}).get(horizon, {})

def _fmt_money(v):
    try:
        return f"${float(v):,.2f}"
    except Exception:
        return "$n/a"

def _fmt_pct(v):
    if v is None or v == "": return "n/a"
    try: return f"{float(v):.1f}%"
    except Exception: return str(v)

def _direction_badge(direction):
    d = str(direction or "").upper()
    if d == "LONG": return "🟢🚀📈"
    if d == "SHORT": return "🔴⚠️📉"
    return "🟡⏸️"

def _confluence_badge(label, count):
    label = str(label or "").upper()
    if count >= 3 or "EXTREME" in label: return "🔥 EXTREME"
    if count == 2 or "HIGH" in label: return "🟠 HIGH"
    if count == 1: return "🟢 SINGLE"
    return "🟡 NONE"

def _pretty_model(name):
    return str(name or "unknown").replace("_", " ").upper()

def _pretty_tier(tier):
    t = str(tier or "").lower()
    return {"elite":"Elite", "strong":"Strong", "push":"Push", "watch":"Watch"}.get(t, str(tier or "n/a"))

def _humanize_reason(specialist, reason):
    txt = str(reason or "")
    out=[]
    low=txt.lower()
    if "fear_greed" in low or "fg=" in low:
        out.append("✅ Fear condition passed")
    if "mom_4h" in low or "mom4" in low or "return_4" in low:
        if ">0" in txt or ">-0.02" in txt:
            out.append("✅ Momentum condition passed")
    if "dd=" in low or "drawdown" in low:
        out.append("✅ Drawdown/deep-value condition passed")
    if "rsi" in low:
        out.append("✅ RSI condition checked")
    if "risk_bonus(0" in txt:
        out.append("⚪ Macro/risk bonus not active")
    if not out:
        out.append(txt[:160] if txt else "Signal gate passed")
    return "\n".join(out[:5])

def notify_body(decision, features=None, test=False):
    applicable = decision.get("all_applicable") or []
    if not applicable and decision.get("decision") in ("LONG", "SHORT"):
        applicable = [decision]
    if not applicable:
        price = features.get("close") if features else decision.get("entry_price")
        fg = features.get("fear_greed") if features else ""
        regime = features.get("regime", "") if features else ""
        return "\n".join([
            "🟡⏸️ BEE NO TRADE",
            "━━━━━━━━━━━━━━━━━━",
            "",
            "No valid setup found.",
            f"💰 BTC: {_fmt_money(price)}",
            f"😐 Fear & Greed: {fg}",
            f"🌍 Regime: {regime}",
            "",
            f"Reason: {decision.get('reason', 'NO_ENGINE_TRIGGER')}",
            "",
            "PAPER ONLY — geen automatische trade."
        ])

    # Keep mobile readable: show at most 3 models, summarize any extra.
    applicable = sorted(applicable, key=lambda e: (-int(e.get("priority", 0)), -float(e.get("prob", 0))))
    visible = applicable[:3]
    hidden_count = max(0, len(applicable) - len(visible))
    count = len(applicable)
    consensus = str(decision.get("consensus_direction", visible[0].get("decision", visible[0].get("action", "LONG")))).upper()
    conf_label = decision.get("confluence_label") or ("EXTREME_CONFLUENCE" if count >= 3 else "HIGH_CONFLUENCE" if count == 2 else "SINGLE_ENGINE")
    badge = _direction_badge(consensus)
    conf_badge = _confluence_badge(conf_label, count)
    prefix = "🧪 TEST ONLY — " if test else ""
    price = features.get("close") if features else visible[0].get("entry_price")
    fg = features.get("fear_greed") if features else ""
    fear_label = features.get("fear_label", "") if features else ""
    regime = features.get("regime", "") if features else ""

    title_line = f"{badge} BEE {conf_badge} CONFLUENCE {consensus}" if count > 1 else f"{badge} BEE {consensus} SIGNAL"
    lines = [
        f"{prefix}{title_line}",
        "━━━━━━━━━━━━━━━━━━",
        "",
        f"🔥 {count} model{'len' if count != 1 else ''} aligned" if count > 1 else "📌 1 model active",
        f"📈 Consensus: {consensus}",
        f"⚡ Confluence: {conf_badge}",
        "",
        f"💰 BTC: {_fmt_money(price)}",
        f"😨 Fear & Greed: {fg} {('('+fear_label+')') if fear_label else ''}",
        f"🌍 Regime: {str(regime).title()}",
        "",
    ]
    medals = ["🥇", "🥈", "🥉"]
    for i, eng in enumerate(visible, start=1):
        medal = medals[i-1] if i <= len(medals) else f"#{i}"
        name = _pretty_model(eng.get("specialist"))
        strongest = " — strongest" if i == 1 else ""
        verified = "✅ verified" if eng.get("stats_verified") else "⚠️ unverified"
        period = eng.get("stats_period") or "n/a"
        sample = eng.get("sample_size") or "n/a"
        source = eng.get("stats_source") or "n/a"
        lines += [
            "━━━━━━━━━━━━━━━━━━",
            f"{medal} {name}{strongest}",
            f"🎯 Horizon: {eng.get('horizon')} | 💪 Tier: {_pretty_tier(eng.get('tier'))}",
            f"📊 Probability: {float(eng.get('prob',0))*100:.2f}%",
            f"🏆 Winrate: {_fmt_pct(eng.get('oos_winrate_pct'))} OOS | {_fmt_pct(eng.get('historical_winrate_pct'))} Hist",
            f"🧪 Stats: {verified} | {period}",
            f"📚 Source: {source}",
            f"Sample: {sample}",
            "",
            f"💵 Entry:  {_fmt_money(eng.get('entry_price'))}",
            f"🎯 Target: {_fmt_money(eng.get('take_profit'))}",
            f"🛑 Stop:   {_fmt_money(eng.get('stop_loss'))}",
            "",
            "Reason:",
            _humanize_reason(eng.get('specialist'), eng.get('reason')),
            "",
        ]
    if hidden_count:
        lines += ["━━━━━━━━━━━━━━━━━━", f"+ {hidden_count} additional supporting model(s)", ""]
    lines += [
        "━━━━━━━━━━━━━━━━━━",
        "🧪 PAPER MODE ONLY",
        "Geen automatische trade. Jij kiest welke horizon/model je volgt."
    ]
    return "\n".join(lines)

def send_ntfy(topic, title, body):
    if not topic or "PASTE" in topic:
        raise RuntimeError("ntfy topic missing/placeholder")
    data = body.encode("utf-8")
    req = urlrequest.Request(f"https://ntfy.sh/{topic}", data=data, method="POST")
    # Headers must be latin-1 safe; no emoji here.
    req.add_header("Title", title.encode("ascii", "ignore").decode("ascii")[:120])
    req.add_header("Priority", "4")
    try:
        with urlrequest.urlopen(req, timeout=20) as resp:
            return {"ok": True, "status": resp.status}
    except Exception as e:
        return {"ok": False, "error": str(e)}

def append_csv(path, header, row):
    new = not path.exists()
    with open(path, "a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=header)
        if new: w.writeheader()
        w.writerow({k: row.get(k, "") for k in header})

def trim_history():
    if not HISTORY_PATH.exists(): return
    rows = HISTORY_PATH.read_text(encoding="utf-8").splitlines()
    if len(rows) <= 8761: return
    trimmed = [rows[0]] + rows[-8760:]
    atomic_write(HISTORY_PATH, "\n".join(trimmed)+"\n")

def _signal_model_set(decision):
    return set((decision.get("all_applicable_models") or decision.get("specialist") or "").split(",")) - {"", "none"}

def _dedup_check_and_update(decision, cfg, mark_sent=False):
    """Dedup at signal-moment level. Send if cooldown expired or a new higher-priority engine appears."""
    state = load_json(STATE_PATH, {})
    now_ts = time.time()
    dedup_hours = float(cfg.get("dedup_hours", 6))
    last = state.get("last_multi_engine_notify") or {}
    current_models = sorted(_signal_model_set(decision))
    current_priorities = {e.get("specialist"): int(e.get("priority", 0)) for e in (decision.get("all_applicable") or [decision])}
    if not last:
        allowed, reason = True, "FIRST_SIGNAL"
    else:
        elapsed = now_ts - float(last.get("ts_epoch", 0))
        last_models = set(last.get("models", []))
        new_models = set(current_models) - last_models
        last_max_prio = int(last.get("max_priority", 0))
        current_max_prio = max(current_priorities.values() or [0])
        has_new_stronger = bool(new_models and current_max_prio > last_max_prio)
        if elapsed >= dedup_hours * 3600:
            allowed, reason = True, "DEDUP_WINDOW_EXPIRED"
        elif has_new_stronger:
            allowed, reason = True, "NEW_STRONGER_ENGINE_APPEARED"
        else:
            allowed, reason = False, f"DUPLICATE_WITHIN_{dedup_hours:g}H"
    if mark_sent:
        state["last_multi_engine_notify"] = {
            "ts_utc": now_iso(), "ts_epoch": now_ts,
            "models": current_models,
            "max_priority": max(current_priorities.values() or [0]),
            "primary": decision.get("specialist"),
            "confluence_score": decision.get("confluence_score", len(current_models)),
            "consensus_direction": decision.get("consensus_direction", "LONG"),
        }
        write_json(STATE_PATH, state)
    return allowed, reason

def record_run(features, decision, notify_status="SKIPPED", skip_reason=""):
    status={"version":VERSION,"core_version":CORE_VERSION,"timestamp_utc":now_iso(),"features":features,"decision":decision,"last_notify_status":notify_status,"notify_skip_reason":skip_reason,"feature_parity":load_json(FEATURE_PARITY_PATH,{})}
    write_json(STATUS_PATH, status)
    row={
        "timestamp_utc":status["timestamp_utc"],"candle_dt":features.get("candle_dt"),"price":features.get("close"),"fear_greed":features.get("fear_greed"),
        "drawdown_from_ath":features.get("drawdown_from_ath"),"return_4":features.get("return_4"),"return_24":features.get("return_24"),"rsi_14":features.get("rsi_14"),"regime":features.get("regime"),
        "specialist":decision.get("specialist"),"prob":decision.get("prob"),"cycle_prob_raw":decision.get("prob") if decision.get("specialist")=="cycle_reversal" else "",
        "tier":decision.get("tier"),"decision":decision.get("decision"),"notify":notify_status=="SENT","last_notify_status":notify_status,"notify_skip_reason":skip_reason,"reason":decision.get("reason"),
        "all_applicable_models":decision.get("all_applicable_models", ""),"confluence_score":decision.get("confluence_score", 0),"confluence_label":decision.get("confluence_label", ""),"consensus_direction":decision.get("consensus_direction", ""),
    }
    append_csv(HISTORY_PATH,HISTORY_HEADER,row); trim_history()
    if notify_status == "SENT" and decision.get("decision") in ("LONG","SHORT"):
        batch_id = f"{status['timestamp_utc'].replace(':','').replace('-','').replace('Z','Z')}_{decision.get('consensus_direction','LONG')}_{decision.get('all_applicable_models', decision.get('specialist',''))}"
        applicable = decision.get("all_applicable") or [decision]
        for eng in applicable:
            append_csv(SIGNALS_PATH,SIGNALS_HEADER,{
                "signal_batch_id":batch_id,"signal_ts":status["timestamp_utc"],"candle_dt":features.get("candle_dt"),"specialist":eng.get("specialist"),"decision":eng.get("decision", eng.get("action")),
                "tier":eng.get("tier"),"prob":eng.get("prob"),"entry_price":eng.get("entry_price"),"take_profit":eng.get("take_profit"),"stop_loss":eng.get("stop_loss"),"horizon":eng.get("horizon"),
                "fear_greed":features.get("fear_greed"),"regime":features.get("regime"),"reason":eng.get("reason"),"historical_winrate_pct":eng.get("historical_winrate_pct"),"oos_winrate_pct":eng.get("oos_winrate_pct"),
                "sample_size":eng.get("sample_size"),"stats_period":eng.get("stats_period"),"stats_source":eng.get("stats_source"),"stats_verified":eng.get("stats_verified"),"all_applicable_models":decision.get("all_applicable_models", ""),"confluence_score":decision.get("confluence_score", 0),"consensus_direction":decision.get("consensus_direction", "LONG"),
            })

def export_debug():
    # Hard overwrite both names.
    for p in (LATEST_EXPORT, LEGACY_EXPORT):
        try: p.unlink()
        except FileNotFoundError: pass
    for p in ROOT.glob("debug_export*.zip"):
        try: p.unlink()
        except Exception: pass
    LATEST_EXPORT.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(LATEST_EXPORT, "w", zipfile.ZIP_DEFLATED) as z:
        manifest={"version":VERSION,"core_version":CORE_VERSION,"created_at":now_iso(),"export_path":str(LATEST_EXPORT)}
        z.writestr("manifest.json", json.dumps(manifest, indent=2))
        for f in [ROOT/"bee_live_config.json", ROOT/"model_stats.json", ROOT/"bee_research_core_v4_0.py", Path(__file__), RESEARCH_FEATURE_FIXTURES_PATH, STATUS_PATH, HISTORY_PATH, SIGNALS_PATH, STATE_PATH, FEATURE_PARITY_PATH, STATE_DIR/"golden_test.json", LOG_DIR/"bee_live.log"]:
            if f.exists(): z.write(f, f.relative_to(ROOT) if f.is_relative_to(ROOT) else f.name)
    shutil.copy2(LATEST_EXPORT, LEGACY_EXPORT)
    return str(LATEST_EXPORT)

def run_once(force_notify=False, inspect=False):
    cfg=load_config()
    parity=run_feature_parity()
    if not parity.get("passed"):
        raise RuntimeError("feature parity failed; aborting live run")
    features=sample_live_market_features(); validate_units(features)
    decision=decide_all(features)
    notify_status="SKIPPED"; skip="NO_TRADE" if decision.get("decision")=="NO_TRADE" else "INSPECT_OR_NOT_FORCED"
    if inspect:
        skip="EXPORT_INSPECT"
    elif force_notify or decision.get("notify"):
        if force_notify:
            allowed, dedup_reason = True, "FORCE_TEST_ONLY"
        else:
            allowed, dedup_reason = _dedup_check_and_update(decision, cfg, mark_sent=False)
        if not allowed:
            notify_status="SKIPPED"; skip=dedup_reason
        else:
            count = decision.get("confluence_score", len(decision.get("all_applicable", []) or [decision]))
            title = ("BEE TEST PAPER TRADE" if force_notify else f"BEE SIGNAL {decision.get('consensus_direction','LONG')} {count} engine(s)")
            res=send_ntfy(cfg["ntfy_topic"], title, notify_body(decision, features=features, test=force_notify))
            if res.get("ok"):
                notify_status="SENT"; skip="FORCE_TEST_ONLY" if force_notify else ""
                if not force_notify:
                    _dedup_check_and_update(decision, cfg, mark_sent=True)
            else:
                notify_status="FAILED"; skip=res.get("error","ntfy failed")
    record_run(features, decision, notify_status, skip)
    return {"features":features,"decision":decision,"notify_status":notify_status,"notify_skip_reason":skip,"feature_parity":parity}

def test_ntfy():
    cfg=load_config(); return send_ntfy(cfg["ntfy_topic"], "BEE ntfy test", f"BEE ntfy werkt. {now_iso()} version={VERSION}")

def test_trade_ntfy():
    features=sample_live_market_features(); decision=decide_all(features)
    return send_ntfy(load_config()["ntfy_topic"], "BEE PAPER TRADE TEST", notify_body(decision, features=features, test=True))

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--version", action="store_true"); ap.add_argument("--golden-test", action="store_true"); ap.add_argument("--feature-parity-test", action="store_true")
    ap.add_argument("--test-ntfy", action="store_true"); ap.add_argument("--test-trade-ntfy", action="store_true")
    ap.add_argument("--once", action="store_true"); ap.add_argument("--force-notify", action="store_true"); ap.add_argument("--inspect-live-data", action="store_true"); ap.add_argument("--export-debug", action="store_true")
    args=ap.parse_args()
    if args.version: print(VERSION); return
    if args.feature_parity_test: print(json.dumps(run_feature_parity(), indent=2)); return
    if args.golden_test: print(json.dumps(run_golden_test(), indent=2)); return
    if args.test_ntfy: print(json.dumps(test_ntfy(), indent=2)); return
    if args.test_trade_ntfy: print(json.dumps(test_trade_ntfy(), indent=2)); return
    if args.once or args.force_notify or args.inspect_live_data:
        print(json.dumps(run_once(force_notify=args.force_notify, inspect=args.inspect_live_data), indent=2, ensure_ascii=False)); return
    if args.export_debug:
        print("EXPORT READY:", export_debug()); return
    ap.print_help()
if __name__ == "__main__": main()
