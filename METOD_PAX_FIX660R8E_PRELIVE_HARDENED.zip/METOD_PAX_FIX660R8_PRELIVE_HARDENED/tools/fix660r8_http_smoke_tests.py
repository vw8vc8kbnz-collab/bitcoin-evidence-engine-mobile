#!/usr/bin/env python3
from __future__ import annotations

"""Start the real server and prove its public HTTP control plane responds.

Import- and handler-unit tests do not execute ``Handler.do_GET`` through
``http.server``.  This process-level smoke test exists specifically to catch
startup/dispatch failures such as class name-mangling of module constants.
"""

import ast
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import ProxyHandler, build_opener


RELEASE_ROOT = Path(__file__).resolve().parents[1]
SERVER = RELEASE_ROOT / "app/server_py.py"
EXPECTED_BUILD = "FIX660R8_PRELIVE_HARDENED"


def reserve_loopback_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        probe.bind(("127.0.0.1", 0))
        return int(probe.getsockname()[1])


class RealHTTPProcessTests(unittest.TestCase):
    def test_01_class_methods_have_no_mangling_prone_global_names(self) -> None:
        tree = ast.parse(SERVER.read_text(encoding="utf-8", errors="strict"), filename=str(SERVER))
        violations: list[str] = []
        for class_node in (node for node in ast.walk(tree) if isinstance(node, ast.ClassDef)):
            for node in ast.walk(class_node):
                if (
                    isinstance(node, ast.Name)
                    and node.id.startswith("__")
                    and not node.id.endswith("__")
                ):
                    violations.append(f"{class_node.name}:{node.lineno}:{node.id}")
        self.assertEqual(violations, [], f"class name-mangling hazard: {violations}")

    def test_02_real_server_answers_liveness_readiness_and_tool_a(self) -> None:
        opener = build_opener(ProxyHandler({}))
        port = reserve_loopback_port()
        with tempfile.TemporaryDirectory(prefix="fix660r8_http_smoke_") as temp_dir:
            temp_root = Path(temp_dir)
            state_root = temp_root / "state"
            log_path = temp_root / "server.log"
            env = dict(os.environ)
            env.update(
                {
                    "PYTHONDONTWRITEBYTECODE": "1",
                    "PYTHONUNBUFFERED": "1",
                    "METOD_STATE_ROOT": str(state_root),
                    "METOD_HOST": "127.0.0.1",
                    "METOD_PORT": str(port),
                    "APP_ENV": "staging",
                    "PRODUCTION_HARDENING": "0",
                }
            )
            with log_path.open("wb") as log_handle:
                process = subprocess.Popen(
                    [sys.executable, "-B", str(SERVER)],
                    cwd=str(RELEASE_ROOT / "app"),
                    env=env,
                    stdin=subprocess.DEVNULL,
                    stdout=log_handle,
                    stderr=subprocess.STDOUT,
                )
                try:
                    live_status = None
                    live_body = b""
                    deadline = time.monotonic() + 30
                    last_error: Exception | None = None
                    while time.monotonic() < deadline:
                        if process.poll() is not None:
                            break
                        try:
                            with opener.open(f"http://127.0.0.1:{port}/health/live", timeout=2) as response:
                                live_status = response.status
                                live_body = response.read()
                            break
                        except HTTPError as exc:
                            last_error = exc
                            exc.close()
                            time.sleep(0.1)
                        except (URLError, TimeoutError, ConnectionError) as exc:
                            last_error = exc
                            time.sleep(0.1)

                    log_handle.flush()
                    if live_status is None:
                        log_text = log_path.read_text(encoding="utf-8", errors="replace")[-12000:]
                        self.fail(
                            f"server gaf geen livenessantwoord; exit={process.poll()}; "
                            f"laatste fout={last_error!r}\n{log_text}"
                        )

                    self.assertEqual(live_status, 200)
                    live = json.loads(live_body)
                    self.assertEqual(live, {"ok": True, "build": EXPECTED_BUILD})

                    try:
                        with opener.open(f"http://127.0.0.1:{port}/health/ready", timeout=5) as response:
                            ready_status = response.status
                            ready_body = response.read()
                    except HTTPError as exc:
                        ready_status = exc.code
                        try:
                            ready_body = exc.read()
                        finally:
                            exc.close()
                    self.assertIn(ready_status, {200, 503})
                    ready = json.loads(ready_body)
                    self.assertEqual(ready.get("build"), EXPECTED_BUILD)
                    self.assertIsInstance(ready.get("checks"), dict)

                    with opener.open(f"http://127.0.0.1:{port}/", timeout=10) as response:
                        tool_status = response.status
                        tool_body = response.read()
                    self.assertEqual(tool_status, 200)
                    self.assertIn(b"FIX660_GRAIN_STUDIO", tool_body)
                finally:
                    process.terminate()
                    try:
                        process.wait(timeout=10)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait(timeout=10)


if __name__ == "__main__":
    unittest.main(verbosity=2)
