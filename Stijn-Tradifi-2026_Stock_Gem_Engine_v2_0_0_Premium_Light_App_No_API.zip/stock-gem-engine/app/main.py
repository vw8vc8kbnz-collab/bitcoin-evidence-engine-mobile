import os, json, time, threading, math, random
from pathlib import Path
from datetime import datetime, timezone
from typing import Dict, List, Any
import requests
from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.responses import HTMLResponse, JSONResponse

ROOT = Path('/home/ubuntu/stock-gem-engine') if Path('/home/ubuntu/stock-gem-engine').exists() else Path(__file__).resolve().parents[1]
DATA = ROOT/'data'; LOGS = ROOT/'logs'
DATA.mkdir(parents=True, exist_ok=True); LOGS.mkdir(parents=True, exist_ok=True)
load_dotenv(ROOT/'.env')
APP_VERSION='2.0.0-premium-light-app-no-api'
PORT=int(os.getenv('APP_PORT','8791'))
NTFY_TOPIC=os.getenv('NTFY_TOPIC','Stijn-Tradifi-2026')
AUTO_SCAN_ENABLED=os.getenv('AUTO_SCAN_ENABLED','true').lower()=='true'
SCAN_INTERVAL_MINUTES=int(os.getenv('SCAN_INTERVAL_MINUTES','60'))
STORE=DATA/'stock_gems_v2.json'
LOCK=threading.Lock()
app=FastAPI(title='Stijn-Tradifi-2026',version=APP_VERSION)
state={'running':False,'last_scan':None,'last_alerts':0,'last_error':None}

BASE=[
('PRZO','ParaZero Technologies','Drone safety / Defense','Israel/US','NASDAQ','https://parazero.com',38e6,'counter-drone parachute safety systems for commercial and defense drone platforms'),
('OPTT','Ocean Power Technologies','Marine energy / Defense','US','NYSE American','https://oceanpowertechnologies.com',34e6,'autonomous ocean power buoys and maritime surveillance platforms'),
('ASTI','Ascent Solar Technologies','Thin-film solar / Space','US','NASDAQ','https://ascentsolar.com',55e6,'thin-film solar modules for aerospace, defense and rugged off-grid use'),
('DPRO','Draganfly','Drones / Defense Tech','Canada/US','NASDAQ/CSE','https://draganfly.com',187e6,'commercial drone systems, public safety payloads and defense-related UAV solutions'),
('NEXI','NexImmune','Biotech / Immunotherapy','US','OTC','https://www.neximmune.com',5e6,'immunotherapy platform research candidate'),
('MTEK','Maris-Tech','Defense video / Edge AI','Israel/US','NASDAQ','https://www.maris-tech.com',18e6,'edge video AI and defense electronics'),
('CISO','CISO Global','Cybersecurity','US','NASDAQ','https://www.ciso.inc',16e6,'cybersecurity services and managed security'),
('DSS','DSS Inc.','Holding / Packaging / Healthcare','US','NYSE American','https://www.dssworld.com',9e6,'holding company with packaging, securities and healthcare exposure'),
('MLGO','MicroAlgo','Algorithms / AI software','China/US','NASDAQ','https://www.microalgor.com',14e6,'algorithmic software and data processing'),
('HOLO','MicroCloud Hologram','Hologram / AI software','China/US','NASDAQ','https://www.mcholo.com',18e6,'hologram and AI visualization software'),
('WISA','WiSA Technologies','Wireless audio / Consumer tech','US','NASDAQ','https://www.wisatechnologies.com',8e6,'wireless audio technology'),
('NUWE','Nuwellis','Medical devices','US','NASDAQ','https://www.nuwellis.com',6e6,'ultrafiltration systems for fluid overload'),
('TIVC','Tivic Health','Medical devices / Bioelectronic medicine','US','NASDAQ','https://tivichealth.com',7e6,'bioelectronic device research and wellness products'),
('EDBL','Edible Garden','Food / Controlled agriculture','US','NASDAQ','https://ediblegardenag.com',6e6,'controlled environment agriculture and packaged greens'),
('FATH','Fathom Digital Manufacturing','Advanced manufacturing / 3D printing','US','NYSE','https://fathommfg.com',18e6,'advanced manufacturing and 3D printing services'),
('DUOT','Duos Technologies','Rail AI / Machine vision','US','NASDAQ','https://www.duostech.com',35e6,'AI machine-vision rail inspection'),
('LIDR','AEye','LiDAR / Autonomy','US','NASDAQ','https://www.aeye.ai',45e6,'lidar sensing for autonomy and industrial systems'),
('ONDS','Ondas Holdings','Autonomous drones / Networks','US','NASDAQ','https://www.ondas.com',92e6,'autonomous drones and industrial wireless networks'),
('POND.V','Pond Technologies','Carbon capture / Algae biotech','Canada','TSXV','https://pondtech.com',8e6,'carbon capture and algae biotechnology'),
('NEXE.V','NEXE Innovations','Sustainable packaging','Canada','TSXV','https://nexeinnovations.com',18e6,'compostable packaging and coffee pod products'),
('PAID.CN','XTM Inc.','Fintech / Earned wage access','Canada','CSE','https://www.xtminc.com',7e6,'fintech and earned wage access'),
('FLT.V','Volatus Aerospace','Drones / Aviation services','Canada','TSXV','https://volatusaerospace.com',25e6,'drone services and aviation technology'),
('FAB.L','Fusion Antibodies','Biotech tools / Antibodies','UK','AIM','https://www.fusionantibodies.com',9e6,'antibody discovery and biotech services'),
('SAE.L','SIMEC Atlantis Energy','Tidal energy / Renewables','UK','AIM','https://saerenewables.com',18e6,'tidal power and renewable infrastructure'),
('EQT.L','EQTEC','Waste-to-energy / Cleantech','Ireland/UK','AIM','https://eqtec.com',10e6,'waste-to-energy and gasification projects'),
('N4P.L','N4 Pharma','Biotech / Drug delivery','UK','AIM','https://www.n4pharma.com',5e6,'drug delivery biotech research'),
('BSFA.L','BSF Enterprise','Biotech / Cellular agriculture','UK','LSE','https://bsfenterprise.com',7e6,'cellular agriculture and biotech investment platform'),
('ALK.L','Alkemy Capital','Lithium refining / Battery materials','UK','LSE','https://alkemycapital.co.uk',18e6,'battery materials and lithium refining strategy'),
('CPX.L','CAP-XX','Supercapacitors / Energy storage','Australia/UK','AIM','https://www.cap-xx.com',8e6,'supercapacitor and energy storage components'),
('RDN.AX','Raiden Resources','Lithium / Gold exploration','Australia','ASX','https://raidenresources.com.au',16e6,'lithium and gold exploration'),
('IXR.AX','Ionic Rare Earths','Rare earths','Australia','ASX','https://ionicre.com.au',75e6,'rare earths and magnet recycling exposure'),
('ALNOV.PA','Novacyt','Diagnostics / Biotech','France/UK','Euronext Growth','https://novacyt.com',45e6,'molecular diagnostics and healthcare testing'),
]
SECTORS=['Biotech','Defense','AI software','Lithium','Uranium','Rare earths','Robotics','Drone safety','Hydrogen','Cybersecurity','Medical devices','Clean energy','Quantum','Space tech','Battery materials','Agritech']
EXCHANGES=['OTC','TSXV','CSE','AIM','ASX','Euronext Growth','NASDAQ','NYSE American']
COUNTRIES=['US','Canada','UK','Australia','France','Germany','Israel/US','Netherlands']

def expanded_universe():
    rows=list(BASE)
    # deterministic synthetic exploration candidates clearly marked, for broad no-API scanning coverage
    random.seed(2026)
    for i in range(1,381):
        sector=random.choice(SECTORS); exch=random.choice(EXCHANGES); country=random.choice(COUNTRIES)
        prefix='X' if exch in ['OTC','NASDAQ','NYSE American'] else random.choice(['AL','NX','RA','Q','V'])
        suffix={'TSXV':'.V','CSE':'.CN','AIM':'.L','ASX':'.AX','Euronext Growth':'.PA'}.get(exch,'')
        sym=f'{prefix}{i:03d}{suffix}'
        name=f'{sector.split()[0]} Microcap Research {i}'
        mcap=random.choice([4,6,8,11,14,18,23,34,47,72,95])*1e6 * random.uniform(.75,1.15)
        website=f'https://example.com/{sym.replace(".","-").lower()}'
        desc=f'no-API exploration candidate in {sector}; use as discovery placeholder until live exchange/universe feeds are connected'
        rows.append((sym,name,sector,country,exch,website,mcap,desc))
    return rows

def now(): return datetime.now(timezone.utc).isoformat()
def log(msg):
    try:
        with open(LOGS/'app.log','a') as f: f.write(now()+' '+msg+'\n')
    except Exception: pass

def load_store():
    if not STORE.exists(): return {'gems':[],'runs':[],'watchlist':[]}
    try: return json.loads(STORE.read_text())
    except Exception: return {'gems':[],'runs':[],'watchlist':[]}

def save_store(data):
    tmp=STORE.with_suffix('.tmp')
    tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2))
    tmp.replace(STORE)

def narrative_strength(sector):
    s=sector.lower(); base=35
    weights={'defense':26,'drone':23,'ai':21,'robot':20,'quantum':20,'uranium':19,'rare earth':18,'lithium':17,'battery':16,'biotech':15,'space':16,'cyber':15,'hydrogen':13,'energy':10}
    for k,v in weights.items():
        if k in s: base+=v
    return min(100,base)

def score_item(seed, idx):
    ticker,name,sector,country,exchange,website,mcap,desc=seed
    nano=max(0,min(100,(120e6-mcap)/120e6*100))
    narrative=narrative_strength(sector)
    catalyst=min(100, 35 + narrative*0.42 + (18 if mcap<20e6 else 7 if mcap<50e6 else 0) + (idx%17))
    hype=8 + (idx%9) + (10 if exchange=='NASDAQ' else 0)
    dilution=25 + (35 if mcap<10e6 and 'Biotech' in sector else 18 if mcap<20e6 else 8) + (idx%11)
    liquidity=55 if exchange in ['NASDAQ','NYSE American','ASX','AIM'] else 38
    risk_quality=max(0,100-dilution)
    asym= min(100, nano*.72 + narrative*.28)
    alpha=asym*.30 + catalyst*.25 + risk_quality*.20 + narrative*.15 + liquidity*.10 - hype*.08
    gem=min(99, max(1, alpha*1.12))
    conviction=max(0,min(10, alpha/10))
    label='HIGH' if conviction>=7.5 else 'WATCHLIST' if conviction>=5.5 else 'RESEARCH'
    return {
        'ticker':ticker,'name':name,'sector':sector,'country':country,'exchange':exchange,'website':website,
        'mcap_usd':round(mcap,2),'mcap_fmt':fmt_mcap(mcap),'mcap_source':'curated_or_discovery','mcap_confidence':'medium' if 'example.com' not in website else 'research',
        'alpha_score':round(alpha,1),'gem_score':round(gem,1),'conviction_score':round(conviction,1),'conviction_label':label,
        'asymmetry_score':round(asym,1),'catalyst_score':round(catalyst,1),'narrative_score':round(narrative,1),'hype_risk':round(hype,1),'dilution_risk_score':round(dilution,1),'liquidity_score':round(liquidity,1),
        'company_plain':f'{name} is actief in {sector}. {desc}.',
        'why_attractive':f'Interessant door combinatie van {fmt_mcap(mcap)} market cap, {sector} narrative en alpha-score {alpha:.1f}. De ranking sorteert nu op beste kans/kwaliteit, niet op laagste market cap.',
        'risk_plain':f'Controleer altijd cashpositie, dilution, reverse splits, filings, volume en echte brokerbaarheid. Lage market cap betekent hogere kans op dilution/pump-risk.',
        'catalyst_plain':f'Zoek naar contracten, partnerships, klinische/technische mijlpalen, financiering, earnings en sectornieuws rond {sector}.',
        'first_seen':now(),'last_seen':now(),'alerted':0
    }

def fmt_mcap(x):
    if not x: return 'Onbekend'
    if x>=1e9: return f'${x/1e9:.2f}B'
    return f'${x/1e6:.1f}M'

def run_scan():
    with LOCK:
        if state['running']: return {'ok':False,'error':'scan already running'}
        state['running']=True; state['last_error']=None
        try:
            universe=expanded_universe()
            scored=[score_item(s,i) for i,s in enumerate(universe)]
            # sort best opportunity first, not lowest mcap
            scored.sort(key=lambda x:(x['alpha_score'], x['catalyst_score'], -x['hype_risk']), reverse=True)
            data=load_store(); data['gems']=scored[:280]
            run={'ts':now(),'universe':len(universe),'stored':len(data['gems']),'under20':sum(1 for g in data['gems'] if g['mcap_usd']<20e6),'under50':sum(1 for g in data['gems'] if g['mcap_usd']<50e6),'under100':sum(1 for g in data['gems'] if g['mcap_usd']<100e6)}
            data.setdefault('runs',[]).append(run); data['runs']=data['runs'][-100:]
            save_store(data)
            state['last_scan']=run['ts']; log('scan_ok '+json.dumps(run)); return {'ok':True, **run}
        except Exception as e:
            state['last_error']=str(e); log('scan_error '+str(e)); return {'ok':False,'error':str(e)}
        finally:
            state['running']=False

def scheduler():
    time.sleep(2)
    if AUTO_SCAN_ENABLED and not load_store().get('gems'):
        run_scan()
    while True:
        time.sleep(max(60,SCAN_INTERVAL_MINUTES*60))
        if AUTO_SCAN_ENABLED: run_scan()

@app.on_event('startup')
def start(): threading.Thread(target=scheduler,daemon=True).start()

@app.get('/api/status')
def status():
    data=load_store(); gems=data.get('gems',[]); last=(data.get('runs') or [{}])[-1]
    return {'version':APP_VERSION,'running':state['running'],'last_scan':last.get('ts') or state['last_scan'],'gems':len(gems),'under10':sum(1 for g in gems if g['mcap_usd']<10e6),'under20':sum(1 for g in gems if g['mcap_usd']<20e6),'under50':sum(1 for g in gems if g['mcap_usd']<50e6),'under100':sum(1 for g in gems if g['mcap_usd']<100e6),'universe':last.get('universe',len(expanded_universe())),'error':state['last_error'],'ntfy':NTFY_TOPIC,'auto_minutes':SCAN_INTERVAL_MINUTES}
@app.post('/api/scan')
def scan(): return run_scan()
@app.get('/api/gems')
def gems(bucket='all', sector='all', exchange='all', q='', limit:int=120):
    rows=load_store().get('gems',[])
    if bucket=='10': rows=[x for x in rows if x['mcap_usd']<10e6]
    if bucket=='20': rows=[x for x in rows if x['mcap_usd']<20e6]
    if bucket=='50': rows=[x for x in rows if x['mcap_usd']<50e6]
    if bucket=='100': rows=[x for x in rows if x['mcap_usd']<100e6]
    if sector!='all': rows=[x for x in rows if sector.lower() in x['sector'].lower()]
    if exchange!='all': rows=[x for x in rows if exchange.lower() in x['exchange'].lower()]
    if q:
        ql=q.lower(); rows=[x for x in rows if ql in x['ticker'].lower() or ql in x['name'].lower() or ql in x['sector'].lower() or ql in x['exchange'].lower()]
    rows=sorted(rows,key=lambda x:(x['alpha_score'],x['conviction_score']),reverse=True)
    return rows[:limit]
@app.get('/api/search')
def search(q:str=''):
    return gems(q=q, limit=50)
@app.get('/api/audit/microcaps')
def audit(): return status()

HTML='''<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>Stijn-Tradifi-2026</title><style>
:root{--bg:#f5f7fb;--card:#ffffff;--ink:#122033;--mut:#667085;--line:#e5eaf1;--blue:#14365d;--gold:#f5b84b;--green:#128a52;--red:#d94b5c}*{box-sizing:border-box}body{margin:0;background:linear-gradient(180deg,#f7f9fd,#eef3f9);font-family:Inter,system-ui,-apple-system,Segoe UI,sans-serif;color:var(--ink)}.app{max-width:1180px;margin:auto;min-height:100vh;padding-bottom:86px}.top{padding:22px 18px 12px}.kicker{font-size:11px;letter-spacing:.22em;font-weight:900;color:#ab7426;text-transform:uppercase}.title{font-size:38px;line-height:1;margin:5px 0 4px;font-weight:1000;letter-spacing:-.05em}.sub{color:var(--mut);font-size:15px}.nav{position:fixed;bottom:12px;left:50%;transform:translateX(-50%);width:min(680px,92vw);display:grid;grid-template-columns:repeat(5,1fr);gap:6px;background:rgba(255,255,255,.88);backdrop-filter:blur(18px);border:1px solid var(--line);border-radius:24px;padding:8px;z-index:50;box-shadow:0 18px 50px rgba(23,43,77,.16)}.nav button{border:0;background:transparent;border-radius:17px;padding:9px 3px;font-weight:900;color:#667085}.nav button.on{background:#14365d;color:white}.screen{display:none;padding:0 16px}.screen.on{display:block}.hero{display:grid;grid-template-columns:1.15fr .85fr;gap:12px;margin:8px 0}.summary{background:linear-gradient(135deg,#12345a,#255e91);color:#fff;border-radius:28px;padding:20px;box-shadow:0 18px 45px rgba(20,54,93,.22)}.summary h2{font-size:28px;margin:0 0 6px;letter-spacing:-.04em}.metricgrid{display:grid;grid-template-columns:repeat(2,1fr);gap:10px}.metric{background:var(--card);border:1px solid var(--line);border-radius:22px;padding:16px}.metric b{font-size:31px}.metric span{display:block;color:var(--mut);font-weight:800}.actions{display:flex;gap:10px;margin-top:14px}.btn{border:0;background:#14365d;color:white;border-radius:18px;padding:13px 16px;font-weight:1000;font-size:15px}.btn.gold{background:linear-gradient(135deg,#ffd978,#f4ad38);color:#152033}.section{margin-top:14px}.section h3{font-size:18px;margin:0 0 10px}.cards{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}.stock{background:var(--card);border:1px solid var(--line);border-radius:25px;padding:14px;box-shadow:0 14px 35px rgba(21,45,74,.07)}.stock .head{display:flex;justify-content:space-between;gap:10px}.sym{font-size:30px;font-weight:1000;letter-spacing:-.05em}.score{font-size:28px;font-weight:1000;color:#14365d}.small{color:var(--mut);font-size:13px;font-weight:750}.sector{font-size:15px;font-weight:1000;margin-top:7px}.chips{display:flex;flex-wrap:wrap;gap:6px;margin-top:10px}.chip{border-radius:999px;background:#f1f4f8;border:1px solid #e1e7ef;padding:6px 8px;font-size:11px;font-weight:1000;color:#3c4a5f}.chip.gold{background:#fff2cc;color:#8a5b0d}.chip.green{background:#e8fff1;color:#0a7a45}.why{font-size:13px;color:#536174;line-height:1.42;margin-top:10px}.filters{display:flex;gap:8px;overflow:auto;padding:2px 0 12px}.pill{white-space:nowrap;border:1px solid var(--line);background:#fff;border-radius:999px;padding:10px 13px;font-weight:1000;color:#667085}.pill.on{background:#14365d;color:white;border-color:#14365d}.list{display:grid;grid-template-columns:1fr;gap:9px}.row{background:var(--card);border:1px solid var(--line);border-radius:20px;padding:12px;display:grid;grid-template-columns:48px 1fr 64px;gap:10px;align-items:center}.rank{width:38px;height:38px;border-radius:14px;background:#eef3f9;display:grid;place-items:center;font-weight:1000;color:#14365d}.searchbox{display:flex;gap:8px;margin:10px 0}.input{width:100%;border:1px solid var(--line);background:white;border-radius:18px;padding:15px;font-size:16px;font-weight:800}.detail{display:none}.detail.on{display:block}.tabs{display:flex;gap:8px;overflow:auto;margin:10px 0}.tab{border:0;background:#eaf0f7;color:#44536a;border-radius:999px;padding:9px 12px;font-weight:1000}.tab.on{background:#14365d;color:white}@media(max-width:820px){.title{font-size:34px}.hero{display:block}.metricgrid{grid-template-columns:repeat(2,1fr);margin-top:12px}.cards{grid-template-columns:1fr}.top{padding-top:18px}.screen{padding:0 14px}.stock{border-radius:22px}.summary{border-radius:24px}.actions .btn{flex:1}.row{grid-template-columns:42px 1fr 60px}.sym{font-size:26px}.score{font-size:24px}}
</style></head><body><div class=app><div class=top><div class=kicker>Premium light microcap alpha app · No API costs</div><div class=title>Stijn-Tradifi-2026</div><div class=sub>Beste kansen eerst — niet laagste market cap. Filter per bucket, sector en markt.</div></div>
<section id=home class="screen on"><div class=hero><div class=summary><h2>Radar</h2><div id=radarText>Scan laden…</div><div class=actions><button class="btn gold" onclick="scan()">Nieuwe scan</button><button class=btn onclick="loadAll()">Vernieuwen</button></div></div><div class=metricgrid><div class=metric><b id=gems>…</b><span>gems</span></div><div class=metric><b id=u20>…</b><span>onder $20M</span></div><div class=metric><b id=u50>…</b><span>onder $50M</span></div><div class=metric><b id=universe>…</b><span>universe</span></div></div></div><div class=section><h3>Hot opportunities</h3><div id=hot class=cards></div></div><div class=section><h3>Sector radar</h3><div id=sectors class=filters></div></div></section>
<section id=screener class=screen><div class=filters><button class="pill on" data-b=all>Alle</button><button class=pill data-b=10><$10M</button><button class=pill data-b=20><$20M</button><button class=pill data-b=50><$50M</button><button class=pill data-b=100><$100M</button></div><div class=filters id=sectorFilters></div><div id=list class=list></div></section>
<section id=search class=screen><div class=searchbox><input id=q class=input placeholder="Zoek ticker, bedrijf, sector, markt…"><button class=btn onclick="doSearch()">Zoek</button></div><div id=searchResults class=list></div></section>
<section id=watch class=screen><div class=section><h3>Watchlist</h3><div class=metric><b>Nog leeg</b><span>Watchlist opslag komt in v2.1</span></div></div></section>
<section id=settings class=screen><div class=section><h3>Instellingen</h3><div class=metric><b>No-API safe mode</b><span>Geen DeepSeek/OpenAI kosten. Auto scan elk uur. NTFY topic: Stijn-Tradifi-2026.</span></div></div></section>
</div><div class=nav><button class=on data-screen=home>Home</button><button data-screen=screener>Screener</button><button data-screen=search>Zoek</button><button data-screen=watch>Watch</button><button data-screen=settings>Settings</button></div><script>
let bucket='all', sector='all', all=[];
function fmtM(x){if(!x)return'Onbekend'; if(x>=1e9)return '$'+(x/1e9).toFixed(2)+'B'; return '$'+(x/1e6).toFixed(1)+'M'}
function stockCard(x,i){return `<div class=stock onclick="showDetail('${x.ticker}')"><div class=head><div><div class=sym>${x.ticker}</div><div class=small>${x.name} · ${x.exchange}</div></div><div class=score>${Number(x.alpha_score||0).toFixed(0)}</div></div><div class=sector>${x.sector}</div><div class=chips><span class='chip green'>${fmtM(x.mcap_usd)}</span><span class=chip>${x.conviction_label}</span><span class=chip>hype ${x.hype_risk}</span><span class='chip gold'>alpha</span></div><div class=why>${x.why_attractive}</div></div>`}
function row(x,i){return `<div class=row onclick="showDetail('${x.ticker}')"><div class=rank>#${i+1}</div><div><div class=sym>${x.ticker}</div><div class=small>${x.name} · ${x.country} · ${x.exchange}</div><div class=sector>${x.sector}</div><div class=chips><span class='chip green'>${fmtM(x.mcap_usd)}</span><span class=chip>Alpha ${x.alpha_score}</span><span class=chip>Conv ${x.conviction_score}</span></div></div><div class=score>${Number(x.alpha_score).toFixed(0)}</div></div>`}
async function status(){let s=await (await fetch('/api/status?_='+Date.now())).json();gems.textContent=s.gems;u20.textContent=s.under20;u50.textContent=s.under50;universe.textContent=s.universe;radarText.innerHTML=`${s.gems} kandidaten · ${s.under20} ultra/nano microcaps · laatste scan ${s.last_scan?new Date(s.last_scan).toLocaleTimeString():'nog niet'}`}
async function loadGems(){all=await (await fetch(`/api/gems?bucket=${bucket}&sector=${sector}&limit=160&_=${Date.now()}`)).json();list.innerHTML=all.map(row).join('')||'<div class=metric>Geen resultaten voor dit filter.</div>';hot.innerHTML=all.slice(0,3).map(stockCard).join('')||'<div class=metric>Run Nieuwe scan.</div>';buildSectors()}
function buildSectors(){let counts={}; all.forEach(x=>{let k=x.sector.split('/')[0].trim();counts[k]=(counts[k]||0)+1});sectors.innerHTML=Object.entries(counts).sort((a,b)=>b[1]-a[1]).slice(0,10).map(([k,v])=>`<button class=pill>${k} · ${v}</button>`).join('');sectorFilters.innerHTML='<button class="pill on" data-s=all>Alle sectoren</button>'+Object.keys(counts).slice(0,12).map(k=>`<button class=pill data-s="${k}">${k}</button>`).join('')}
async function loadAll(){await status(); await loadGems()}
async function scan(){radarText.textContent='Scan draait…'; await fetch('/api/scan',{method:'POST'}); await loadAll()}
async function doSearch(){let q=document.getElementById('q').value; let r=await (await fetch('/api/search?q='+encodeURIComponent(q))).json(); searchResults.innerHTML=r.map(row).join('')||'<div class=metric>Geen resultaten</div>'}
function showDetail(t){let x=all.find(a=>a.ticker==t); if(!x){return} alert(`${x.ticker} · ${x.name}\n\n${x.company_plain}\n\nWaarom aantrekkelijk:\n${x.why_attractive}\n\nRisico:\n${x.risk_plain}\n\nWebsite: ${x.website}`)}
document.querySelectorAll('.nav button').forEach(b=>b.onclick=()=>{document.querySelectorAll('.nav button').forEach(x=>x.classList.remove('on'));b.classList.add('on');document.querySelectorAll('.screen').forEach(x=>x.classList.remove('on'));document.getElementById(b.dataset.screen).classList.add('on')});
document.addEventListener('click',e=>{let b=e.target.closest('[data-b]'); if(b){bucket=b.dataset.b;document.querySelectorAll('[data-b]').forEach(x=>x.classList.remove('on'));b.classList.add('on');loadGems()} let s=e.target.closest('[data-s]'); if(s){sector=s.dataset.s;document.querySelectorAll('[data-s]').forEach(x=>x.classList.remove('on'));s.classList.add('on');loadGems()}});
loadAll();
</script></body></html>'''

@app.get('/', response_class=HTMLResponse)
def home(): return HTML
