#!/usr/bin/env bash
set -euo pipefail
APP_DIR="/home/ubuntu/stock-gem-engine"
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
mkdir -p "$APP_DIR" "$APP_DIR/data" "$APP_DIR/logs"
rsync -a --delete --exclude '.venv' --exclude 'data' --exclude 'logs' "$SRC_DIR/" "$APP_DIR/"
cd "$APP_DIR"
if [ ! -d .venv ]; then python3 -m venv .venv; fi
.venv/bin/python -m pip install --upgrade pip >/dev/null
.venv/bin/pip install -r requirements.txt >/dev/null
if [ ! -f "$APP_DIR/.env" ]; then cp "$APP_DIR/.env.example" "$APP_DIR/.env"; fi
sudo chown -R ubuntu:ubuntu "$APP_DIR/data" "$APP_DIR/logs" "$APP_DIR/.env"
sudo chmod -R 775 "$APP_DIR/data" "$APP_DIR/logs"
sudo tee /etc/systemd/system/stock-gem.service >/dev/null <<SERVICE
[Unit]
Description=Stock Gem Evidence Engine
After=network.target
[Service]
Type=simple
User=ubuntu
WorkingDirectory=$APP_DIR
Environment=PYTHONUNBUFFERED=1
ExecStart=$APP_DIR/.venv/bin/python -m uvicorn app.main:app --host 0.0.0.0 --port 8791
Restart=always
RestartSec=3
[Install]
WantedBy=multi-user.target
SERVICE
sudo systemctl daemon-reload
sudo systemctl enable stock-gem.service >/dev/null
sudo systemctl restart stock-gem.service
sleep 2
echo "Klaar: http://SERVER-IP:8791"
