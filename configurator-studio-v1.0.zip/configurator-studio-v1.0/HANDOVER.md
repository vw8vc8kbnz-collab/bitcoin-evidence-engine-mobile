# HANDOVER — Configurator Studio v1.0

## Doel van v1.0

De gebruiker gaf aan dat de vorige paywall/technische uitleg te wazig en te intern was. v1.0 ruimt de klantinterface volledig op.

## UI-regels vanaf v1.0

- Klant mag niet zien hoe het interne systeem werkt.
- Geen zichtbare provider-namen in UI.
- Geen zichtbare OpenAI/Tripo/Rodin/Meshy-verwijzingen in UI.
- Geen backend architecture preview in UI.
- Simpel, effectief en premium.
- Duidelijke route door de app met zo weinig mogelijk onzininfo.
- Prijsplannen blijven duidelijk uitgeschreven.
- Paywall-overlay is kort en action-oriented.
- Demo Sandbox en Pricing blijven op homepage.
- Meer visuele hiërarchie en diepere tinten in cards.

## Interne richting blijft wel behouden

Intern blijft het product gebaseerd op:
- exact-product-first
- paid production gate
- product credits
- AI/product verification
- configurator compiler
- Shopify route
Maar dit wordt niet meer uitgelegd aan klanten in de UI.
