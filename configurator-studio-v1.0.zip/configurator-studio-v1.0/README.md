# Configurator Studio v1.0 — Cleanup Build

v1.0 is een grote UX-cleanup op v0.9.

## Belangrijkste wijzigingen

- Alle zichtbare interne AI/provider-taal verwijderd uit de UI.
- Geen vermeldingen meer van OpenAI, Tripo, Rodin, Meshy, provider routing of backend architecture in de klantinterface.
- De app voelt nu alsof Configurator Studio zelf de volledige productervaring levert.
- Paywall-overlay vereenvoudigd naar een korte upgrade-flow.
- Geen lange uitleg meer over waarom de paywall hard is.
- Homepage opgeschoond:
  - hero
  - één composer
  - hoe het werkt
  - demo sandbox
  - plannen
- Exact Product Check hernoemd/vereenvoudigd naar “Productcheck”.
- Productcheck is conversationaler en minder technisch.
- Meer kleur/diepte in tegels en demo-cards.
- Slimme interne links naar Studio, Hoe het werkt, Demo en Plannen.
- Small Configurator Studio branding blijft in alle normale plannen.

## Productregels

- Geen conceptmodus.
- Gratis sandbox gebruikt alleen demo-producten.
- Eigen producten maken/publiceren vereist betaald plan.
- Bij onduidelijkheid vraagt de studio door.
- Publicatie blijft geblokkeerd totdat de productcheck voldoende compleet is.
