# DEPLOY v1.0

Gebruik na upload naar GitHub:

```bash
cd ~/apps/bitcoin-evidence-engine-mobile && git pull && \
rm -rf configurator-studio-v1.0 && unzip -o configurator-studio-v1.0.zip && \
cd configurator-studio-v1.0 && bash deploy/deploy-9999.sh && \
curl -I http://127.0.0.1:9999/ && \
echo "KLAAR — http://51.195.102.180:9999/"
```
