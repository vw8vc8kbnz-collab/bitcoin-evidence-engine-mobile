# AlgoRoute v0.9.1 MAP CLARITY + TRAFFIC SEGMENTS

Deze build verbetert de echte NL MapLibre kaartlaag.

## Nieuw
- Donkere kaart is lichter en beter leesbaar gemaakt.
- Grote Nederlandse steden worden als eigen labels boven de kaart getoond.
- Routes zijn minder rechte demo-lijnen en gebruiken meer routepunten.
- Voorbereid traffic-segment model: oranje/rode segmenten op specifieke routegedeeltes.
- API `/api/map/state` levert nu ook `traffic_segments`.

## Belangrijk
De blauwe routes zijn nog voorbeeld-polylines. Exacte weg-routes komen in de volgende stap via OSRM of een routing provider. Deze build maakt de visual layer klaar: route = blauw, verkeersvertraging = oranje/rood segment op dezelfde lijnlaag.
