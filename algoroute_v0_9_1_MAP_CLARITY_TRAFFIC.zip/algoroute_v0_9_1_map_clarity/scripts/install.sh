#!/usr/bin/env bash
set -e
sudo apt update
sudo apt install -y unzip curl ca-certificates >/dev/null
if ! command -v docker >/dev/null 2>&1; then
  echo "Docker ontbreekt. Installeer Docker eerst of gebruik eerdere install-flow."
fi
