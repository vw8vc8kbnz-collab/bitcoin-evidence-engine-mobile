from __future__ import annotations
import numpy as np

# Typical BTC movement floors by horizon. These are not “guaranteed moves”; they
# prevent the target price from collapsing to a meaningless +$100 on 30d/90d just
# because bullish and bearish specialist models cancel each other in expected
# value. The probability/confidence still tells the user how weak/strong the
# evidence is.
HORIZON_TARGET_BASE = {
    # V9.3: target distances were too tiny. These are practical BTC
    # forecast target distances per horizon. Probability/confidence still
    # tells whether the setup has edge, but the target should be meaningful.
    "1h": 0.35,
    "4h": 0.90,
    "8h": 1.35,
    "24h": 2.40,
    "7d": 6.50,
    # V10.16.72: Time Machine showed 30d/90d target hitrate was dragged down
    # by over-wide target distances. Keep long-horizon forecasts meaningful,
    # but less aggressive until adaptive evidence proves stronger edge.
    "30d": 9.50,
    "90d": 18.00,
}

class MetaJudge:
    def combine(self, models: list[dict], current_price: float) -> dict:
        if not models:
            return self._empty(current_price)
        weights = np.array([max(m.get("weight", 0.1), 0.001) for m in models], dtype=float)
        probs = np.array([m["bullish_probability"] for m in models], dtype=float)
        moves = np.array([m["expected_move_pct"] for m in models], dtype=float)
        confs = np.array([m.get("confidence", 0) for m in models], dtype=float)
        raw_bullish = float(np.average(probs, weights=weights))
        raw_ev_move = float(np.average(moves, weights=weights))
        # V9.2: extract the deep historical twin result separately. The final
        # target must be anchored in actual forward returns from similar past
        # moments, not only in tiny indicator offsets.
        twin_models = [m for m in models if m.get("model_id") == "M_TWIN"]
        twin_move = None
        twin_prob = None
        twin_evidence = 0
        if twin_models:
            tm = max(twin_models, key=lambda m: m.get("evidence_count", 0))
            twin_move = float(tm.get("expected_move_pct", 0.0) or 0.0)
            twin_prob = float(tm.get("bullish_probability", 0.5) or 0.5)
            twin_evidence = int(tm.get("evidence_count", 0) or 0)
        agreement = max(0.0, 1 - float(np.std(probs) * 2))
        evidence = int(sum(m.get("evidence_count",0) for m in models))
        avg_conf = float(np.average(confs, weights=weights))
        confidence = float(max(5, min(95, avg_conf * max(0.25, agreement) + min(evidence/20, 20))))

        # Probability calibration: allow strong stacks to move away from 50, but
        # keep weak/contradictory stacks honest.
        edge = raw_bullish - 0.5
        strength = min(1.0, max(0.0, (confidence - 32) / 42)) * max(0.25, agreement)
        if abs(edge) > 0.012:
            edge *= (1.0 + 0.95 * strength)
        bullish = float(max(0.03, min(0.97, 0.5 + edge)))

        horizon = models[0].get("horizon", "24h") if models else "24h"
        base_target = HORIZON_TARGET_BASE.get(horizon, 1.0)
        sign = 1.0 if bullish >= 0.5 else -1.0
        if twin_move is not None and abs(twin_move) > 0.001 and twin_evidence >= 80:
            # Let the actual historical forward return distribution decide the
            # preferred direction when the ensemble is nearly neutral.
            if abs(bullish - 0.5) < 0.035 and twin_prob is not None:
                sign = 1.0 if twin_prob >= 0.5 else -1.0

        # V9.0/V9.1: separate “target distance” from raw expected value.
        # A 30d forecast with 52/48 probability can still have a realistic 30d
        # target distance; confidence tells the user whether the edge is weak.
        model_move_abs = abs(raw_ev_move)
        move_dispersion = max(0.15, float(np.nanstd(moves)))
        edge_factor = min(1.25, 0.35 + abs(bullish - 0.5) * 8.0)
        conf_factor = min(1.25, max(0.45, confidence / 70.0))
        agreement_factor = min(1.20, max(0.55, agreement))
        target_magnitude = base_target * edge_factor * conf_factor * agreement_factor

        # V9.3: separate “edge” from “target distance”. A weak edge may still
        # have a realistic target if BTC normally moves a lot inside that
        # horizon. This prevents 30d/90d from forecasting only a few hundred
        # dollars.
        historical_abs = abs(twin_move) if twin_move is not None and twin_evidence >= 60 else 0.0
        minimum_meaningful_target = base_target * 0.45
        max_cap = base_target * (1.75 if confidence < 65 else 2.45)
        expected_move = sign * min(max(model_move_abs, historical_abs, target_magnitude, minimum_meaningful_target), max_cap)

        expected_price = current_price * (1 + expected_move/100)
        dispersion = max(move_dispersion, base_target * 0.25)
        bullish_low = current_price * (1 + (abs(expected_move) * 0.55)/100)
        bullish_high = current_price * (1 + (abs(expected_move) + dispersion*0.9)/100)
        bearish_low = current_price * (1 - (abs(expected_move) + dispersion*0.9)/100)
        bearish_high = current_price * (1 - (abs(expected_move) * 0.55)/100)
        return {
            "bullish_probability": bullish,
            "bearish_probability": 1-bullish,
            "expected_move_pct": expected_move,
            "expected_value_move_pct": raw_ev_move,
            "expected_price": expected_price,
            "bullish_range_low": min(bullish_low, bullish_high),
            "bullish_range_high": max(bullish_low, bullish_high),
            "bearish_risk_low": min(bearish_low, bearish_high),
            "bearish_risk_high": max(bearish_low, bearish_high),
            "confidence": confidence,
            "evidence_count": evidence,
            "contributions": models,
            "raw_bullish_probability": raw_bullish,
            "model_agreement": agreement,
            "target_base_move_pct": base_target,
            "historical_twin_move_pct": twin_move,
            "historical_twin_probability": twin_prob,
            "historical_twin_evidence": twin_evidence,
            "target_calibration_note": "V9.2 targetafstand gebruikt historische forward returns per horizon + snellere cached Time Machine context; probability/confidence geven edge-sterkte.",
        }
    def _empty(self, current_price):
        return {"bullish_probability":0.5,"bearish_probability":0.5,"expected_move_pct":0,"expected_value_move_pct":0,"expected_price":current_price,"bullish_range_low":current_price,"bullish_range_high":current_price,"bearish_risk_low":current_price,"bearish_risk_high":current_price,"confidence":0,"evidence_count":0,"contributions":[]}
