from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from typing import Any

from app.core.config import settings
from app.core.debug import append_jsonl, write_json
from app.core.time_utils import utc_now
from app.db.database import db


DIMENSION_TO_SIGNALS: dict[str, list[str]] = {
    "rsi_state": ["rsi_14:"],
    "funding_rate": ["funding_rate:"],
    "open_interest_change_24h": ["open_interest_change_24h:"],
    "long_short_ratio": ["long_short_ratio:"],
    "taker_buy_sell_ratio": ["taker_delta_ratio:", "taker_buy_sell_ratio:"],
    "fear_greed": ["fear_greed:"],
    "spot_premium": ["spot_coinbase_premium:", "spot_cross_exchange_spread:", "spot_kraken_premium:"],
    "volume_zscore": ["volume_zscore:"],
    "drawdown_from_ath": ["drawdown_from_ath:"],
    "regime_code": ["regime:"],
    "data_completeness": ["data_completeness:"],
    "trend": ["trend:"],
    "volatility_24": ["volatility_24:"],
    "forecast_confidence": ["confidence:", "forecast_edge_abs:"],
}

DEFAULT_FEATURE_WEIGHTS: dict[str, float] = {
    "rsi_state": 0.95,
    "funding_rate": 1.35,
    "open_interest_change_24h": 1.45,
    "long_short_ratio": 0.95,
    "taker_buy_sell_ratio": 1.20,
    "fear_greed": 0.60,
    "spot_premium": 1.05,
    "volume_zscore": 0.85,
    "drawdown_from_ath": 0.75,
    "regime_code": 0.55,
    "data_completeness": 0.25,
    "trend": 0.85,
    "volatility_24": 0.95,
    "forecast_confidence": 0.70,
}


# V10.16.72: Native Time Machine uses compact model IDs while the live Python
# forecast arena has older IDs. Store both so adaptive weights can actually be
# consumed by forecasts instead of only appearing in exports.
NATIVE_TO_LIVE_MODEL_ALIASES: dict[str, list[str]] = {
    "M_FAST_TWIN": ["M_TWIN"],
    "M_MOMENTUM_STACK": ["M_MOM"],
    "M_TREND_STRUCTURE": ["M_TREND", "M_MASTRUCT", "M_TRENDEX", "M_BREAKOUT"],
    "M_RSI_CONTEXT": ["M_RSI", "M_SENTEX"],
    "M_DRAWDOWN_REGIME": ["M_DD", "M_CYCDD"],
    "M_SENTIMENT_FNG": ["M_SENT"],
    "M_VOLATILITY_REGIME": ["M_VOL"],
    "M_VOLUME_VOLATILITY": ["M_VOLUME", "M_RANGE"],
    "M_FUNDING_OI": ["M_FUND", "M_OI", "M_FUTSTACK", "M_LEVFLOW"],
    "M_ORDERBOOK_IMBALANCE": ["M_OB"],
    "M_TAKER_FLOW": ["M_CVD"],
    "M_ONCHAIN_MVRV": ["M_MVRV", "M_CYCLE"],
    "M_EXTERNAL_CLUSTER": ["M_REGIME", "M_RISKCON", "M_CLUSTER", "M_ALPHA_STACK"],
    "M_BASIS_PREMIUM": ["M_BASIS", "M_SPOTFUT"],
    "M_CROSS_EXCHANGE_PREMIUM": ["M_XSPREAD"],
    "M_CROWDING": ["M_TOPTRADER"],
    "M_LIQUIDITY_STRESS_PROXY": ["M_LIQIMB", "M_LARGE", "M_SPOTAGG", "M_FUTAGG"],
}


def _safe_float(v: Any, default: float = 0.0) -> float:
    try:
        if v is None:
            return default
        x = float(v)
        if x != x or x in (float("inf"), float("-inf")):
            return default
        return x
    except Exception:
        return default


def _clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


def _bucket_feature(name: str, value: Any) -> str | None:
    """V10.16.46: stable human-readable buckets for pair learning.

    The engine should not learn only that "funding" matters; it should learn
    that funding-positive + premium-positive behaved differently from
    funding-negative + panic, etc. Buckets are deliberately coarse so Random1000
    has enough sample size per combination.
    """
    try:
        if value is None:
            return None
        if isinstance(value, str):
            txt = value.strip().lower()
            if not txt or txt in ("none", "null", "nan", "unknown"):
                return None
            return txt[:32]
        x = float(value)
        if x != x or x in (float("inf"), float("-inf")):
            return None
    except Exception:
        return None
    n = name.lower()
    if "funding" in n:
        if x >= 0.00030: return "funding_high_positive"
        if x >= 0.00008: return "funding_positive"
        if x <= -0.00012: return "funding_negative"
        return "funding_neutral"
    if "premium" in n or "spread" in n:
        if x >= 0.12: return "premium_strong_positive"
        if x >= 0.025: return "premium_positive"
        if x <= -0.08: return "premium_negative"
        return "premium_neutral"
    if "rsi" in n:
        if x >= 72: return "rsi_overheated"
        if x >= 58: return "rsi_bullish"
        if x <= 30: return "rsi_oversold"
        if x <= 44: return "rsi_weak"
        return "rsi_neutral"
    if "fear" in n:
        if x >= 75: return "greed_extreme"
        if x >= 58: return "greed"
        if x <= 25: return "fear_extreme"
        if x <= 42: return "fear"
        return "sentiment_neutral"
    if "volatility" in n or n == "volatility_24":
        if x >= 0.075: return "vol_high"
        if x >= 0.04: return "vol_mid"
        return "vol_low"
    if "long_short" in n:
        if x >= 1.35: return "crowded_longs"
        if x <= 0.78: return "crowded_shorts"
        return "crowding_neutral"
    if "open_interest" in n:
        if x >= 4: return "oi_rising_fast"
        if x <= -4: return "oi_falling_fast"
        return "oi_neutral"
    if "return_24" in n or n == "trend":
        if x >= 3: return "trend_up_strong"
        if x >= 0.5: return "trend_up"
        if x <= -3: return "trend_down_strong"
        if x <= -0.5: return "trend_down"
        return "trend_flat"
    if "drawdown" in n:
        if x <= -35: return "deep_drawdown"
        if x <= -15: return "drawdown"
        return "near_highs"
    if x > 0: return "positive"
    if x < 0: return "negative"
    return "neutral"


def _feature_context_from_snapshot(feature_json: Any, regime: str | None) -> dict[str, str]:
    try:
        if isinstance(feature_json, str):
            data = json.loads(feature_json) if feature_json.strip() else {}
        elif isinstance(feature_json, dict):
            data = feature_json
        else:
            data = {}
    except Exception:
        data = {}
    aliases = {
        "funding": ["funding_rate", "funding"],
        "premium": ["spot_premium_coinbase_pct", "spot_premium_kraken_pct", "cross_exchange_spread_pct", "spot_premium"],
        "rsi": ["rsi_14", "rsi"],
        "fear_greed": ["fear_greed"],
        "volatility": ["volatility_24", "volatility"],
        "long_short": ["long_short_ratio", "top_account_long_short_ratio", "top_position_long_short_ratio"],
        "open_interest": ["open_interest_change_24h", "open_interest_value"],
        "trend": ["return_24", "return_4", "trend"],
        "drawdown": ["drawdown_from_ath"],
    }
    out: dict[str, str] = {}
    for dim, keys in aliases.items():
        val = None
        for k in keys:
            if k in data and data.get(k) is not None:
                val = data.get(k); break
        b = _bucket_feature(dim, val)
        if b:
            out[dim] = b
    if regime:
        out["regime"] = str(regime).lower()[:32]
    return out


class AdaptiveLearningService:
    """Turns Time Machine results into durable adaptive weights.

    v10.16.36 changes the project from "tests are stored" to "tests update the
    engine". The rules are deliberately conservative and inspectable:

    * Unknown/missing signal buckets do not train a positive feature weight.
    * Every feature dimension is compared against the actual baseline hitrate for
      the same horizon/regime so we do not reward easy market periods.
    * Model weights are rebuilt from model_scores and consumed by ModelArena.
    * Rebuild is idempotent: running it twice gives the same table state.
    """

    def rebuild(self, *, source_batch_id: str | None = None, min_total: int = 20) -> dict[str, Any]:
        run_id = str(uuid.uuid4())
        now = utc_now()
        try:
            baseline = self._baseline_by_horizon_regime()
            feature_rows, feature_summary = self._build_feature_weights(baseline, min_total=min_total)
            model_rows, model_summary = self._build_model_weights()
            regime_rows, regime_summary = self._build_regime_weights()
            pair_rows, pair_summary = self._build_feature_pair_weights(baseline, min_total=max(12, min_total))
            db.execute("DELETE FROM adaptive_feature_weights")
            if feature_rows:
                db.executemany(
                    "INSERT OR REPLACE INTO adaptive_feature_weights(dimension, weight, quality, sample, matched_signals, updated_at) VALUES (?, ?, ?, ?, ?, ?)",
                    [[r[0], r[1], r[2], r[3], r[4], now] for r in feature_rows],
                )
            db.execute("DELETE FROM adaptive_model_weights")
            if model_rows:
                db.executemany(
                    "INSERT OR REPLACE INTO adaptive_model_weights(model_id, horizon, weight, hitrate, sample, avg_price_error_pct, quality, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    [[r[0], r[1], r[2], r[3], r[4], r[5], r[6], now] for r in model_rows],
                )
            db.execute("CREATE TABLE IF NOT EXISTS adaptive_regime_weights (regime TEXT NOT NULL, horizon TEXT NOT NULL, sample BIGINT DEFAULT 0, wins BIGINT DEFAULT 0, partials BIGINT DEFAULT 0, fails BIGINT DEFAULT 0, hitrate DOUBLE DEFAULT 0.0, hitrate_with_partial DOUBLE DEFAULT 0.0, avg_score DOUBLE DEFAULT 0.0, weight DOUBLE DEFAULT 1.0, quality DOUBLE DEFAULT 0.5, updated_at TIMESTAMP, PRIMARY KEY(regime, horizon))")
            db.execute("DELETE FROM adaptive_regime_weights")
            if regime_rows:
                db.executemany(
                    "INSERT OR REPLACE INTO adaptive_regime_weights(regime, horizon, sample, wins, partials, fails, hitrate, hitrate_with_partial, avg_score, weight, quality, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    [[r[0], r[1], r[2], r[3], r[4], r[5], r[6], r[7], r[8], r[9], r[10], now] for r in regime_rows],
                )
            db.execute("CREATE TABLE IF NOT EXISTS adaptive_feature_pair_weights (pair_key TEXT PRIMARY KEY, feature_a TEXT NOT NULL, bucket_a TEXT NOT NULL, feature_b TEXT NOT NULL, bucket_b TEXT NOT NULL, horizon TEXT NOT NULL, regime TEXT DEFAULT 'unknown', sample BIGINT DEFAULT 0, wins BIGINT DEFAULT 0, partials BIGINT DEFAULT 0, fails BIGINT DEFAULT 0, hitrate DOUBLE DEFAULT 0.0, hitrate_with_partial DOUBLE DEFAULT 0.0, baseline_hwp DOUBLE DEFAULT 0.0, edge DOUBLE DEFAULT 0.0, weight DOUBLE DEFAULT 1.0, quality DOUBLE DEFAULT 0.5, updated_at TIMESTAMP)")
            db.execute("DELETE FROM adaptive_feature_pair_weights")
            if pair_rows:
                db.executemany(
                    "INSERT OR REPLACE INTO adaptive_feature_pair_weights(pair_key, feature_a, bucket_a, feature_b, bucket_b, horizon, regime, sample, wins, partials, fails, hitrate, hitrate_with_partial, baseline_hwp, edge, weight, quality, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    [[*r, now] for r in pair_rows],
                )
            snapshot_rows = self._count("SELECT COUNT(*) FROM time_machine_feature_snapshots")
            signal_buckets = self._count("SELECT COUNT(*) FROM time_machine_signal_scores")
            payload = {
                "ok": True,
                "engine_version": settings.engine_version,
                "run_id": run_id,
                "source_batch_id": source_batch_id,
                "feature_dimensions": len(feature_rows),
                "model_dimensions": len(model_rows),
                "regime_dimensions": len(regime_rows),
                "pair_dimensions": len(pair_rows),
                "signal_buckets": signal_buckets,
                "snapshot_rows": snapshot_rows,
                "features": feature_summary,
                "models": model_summary,
                "regimes": regime_summary,
                "feature_pairs": pair_summary,
                "created_at": datetime.now(timezone.utc).isoformat(),
                "message": "adaptive evidence learning rebuilt",
            }
            db.execute(
                "INSERT OR REPLACE INTO adaptive_learning_runs(run_id, created_at, source_batch_id, status, feature_dimensions, model_dimensions, signal_buckets, snapshot_rows, summary_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                [run_id, now, source_batch_id, "completed", len(feature_rows), len(model_rows), signal_buckets, snapshot_rows, json.dumps(payload, default=str)],
            )
            db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ["adaptive_learning", f"active {len(feature_rows)} feature dims · {len(model_rows)} model weights · {len(regime_rows)} regimes · {len(pair_rows)} pairs · signals {signal_buckets}", now])
            write_json("adaptive_learning_summary.json", payload)
            append_jsonl("adaptive_learning_audit.jsonl", {"event": "adaptive_learning_rebuilt_v101636", **payload})
            return payload
        except Exception as exc:
            append_jsonl("adaptive_learning_audit.jsonl", {"event": "adaptive_learning_failed_v101636", "run_id": run_id, "error": str(exc)})
            try:
                db.execute(
                    "INSERT OR REPLACE INTO adaptive_learning_runs(run_id, created_at, source_batch_id, status, summary_json) VALUES (?, ?, ?, ?, ?)",
                    [run_id, now, source_batch_id, "error", json.dumps({"error": str(exc)})],
                )
            except Exception:
                pass
            return {"ok": False, "error": str(exc), "run_id": run_id}

    def _count(self, sql: str) -> int:
        row = db.fetchone(sql)
        return int(row[0] or 0) if row else 0

    def _baseline_by_horizon_regime(self) -> dict[tuple[str, str], float]:
        rows = db.df(
            """
            SELECT horizon, regime,
                   COUNT(*) AS total,
                   AVG(CASE WHEN target_reached OR partial_reached THEN 1.0 ELSE 0.0 END) AS hwp
            FROM time_machine_feature_snapshots
            GROUP BY horizon, regime
            """
        ).to_dict("records")
        out: dict[tuple[str, str], float] = {}
        global_rows = db.df(
            """
            SELECT horizon,
                   AVG(CASE WHEN target_reached OR partial_reached THEN 1.0 ELSE 0.0 END) AS hwp
            FROM time_machine_feature_snapshots
            GROUP BY horizon
            """
        ).to_dict("records")
        global_by_h = {str(r.get("horizon")): _safe_float(r.get("hwp"), 0.5) for r in global_rows}
        for r in rows:
            h = str(r.get("horizon") or "unknown")
            reg = str(r.get("regime") or "unknown")
            out[(h, reg)] = _safe_float(r.get("hwp"), global_by_h.get(h, 0.5))
        return out

    def _build_feature_weights(self, baseline: dict[tuple[str, str], float], min_total: int) -> tuple[list[list[Any]], list[dict[str, Any]]]:
        rows = db.df(
            """
            SELECT signal_key, signal_label, signal_type, horizon, regime, total, wins, partials, fails,
                   hitrate, hitrate_with_partial, avg_score, avg_target_gap_pct
            FROM time_machine_signal_scores
            WHERE total >= ?
            """,
            [int(min_total)],
        ).to_dict("records")
        by_dim: dict[str, dict[str, Any]] = {}
        for dim, prefixes in DIMENSION_TO_SIGNALS.items():
            base_weight = DEFAULT_FEATURE_WEIGHTS.get(dim, 1.0)
            acc = {"sample": 0.0, "matched": 0, "quality_sum": 0.0, "edge_sum": 0.0, "best": [], "worst": []}
            for r in rows:
                key = str(r.get("signal_key") or "")
                # Unknown/missing buckets are diagnostic, not positive learning.
                if key.endswith(":unknown") or ":unknown" in key:
                    continue
                if not any(key.startswith(p) for p in prefixes):
                    continue
                n = float(r.get("total") or 0)
                if n <= 0:
                    continue
                h = str(r.get("horizon") or "unknown")
                reg = str(r.get("regime") or "unknown")
                hwp = _safe_float(r.get("hitrate_with_partial"), 0.0)
                hit = _safe_float(r.get("hitrate"), 0.0)
                avg_score = _safe_float(r.get("avg_score"), 0.0) / 100.0
                gap_penalty = max(0.0, 1.0 - min(_safe_float(r.get("avg_target_gap_pct"), 0.0), 10.0) / 10.0)
                b = baseline.get((h, reg), baseline.get((h, "unknown"), 0.5))
                edge = hwp - b
                # Quality combines absolute performance and regime-relative edge.
                q = 0.46 * hwp + 0.24 * hit + 0.20 * avg_score + 0.10 * gap_penalty + 0.35 * edge
                acc["sample"] += n
                acc["matched"] += 1
                acc["quality_sum"] += q * n
                acc["edge_sum"] += edge * n
                rec = {"signal": key, "label": r.get("signal_label"), "horizon": h, "regime": reg, "sample": int(n), "hwp": round(hwp, 4), "edge": round(edge, 4)}
                (acc["best"] if edge >= 0 else acc["worst"]).append(rec)
            if acc["sample"] <= 0:
                continue
            sample = int(acc["sample"])
            quality = acc["quality_sum"] / acc["sample"]
            edge = acc["edge_sum"] / acc["sample"]
            maturity = _clamp(sample / 1000.0, 0.15, 1.0)
            # Conservative but real: weak dimensions can go below base, useful ones above base.
            multiplier = _clamp(1.0 + edge * (1.2 + 0.8 * maturity) + (quality - 0.50) * 0.45, 0.50, 1.85)
            weight = _clamp(base_weight * multiplier, 0.10, 2.85)
            by_dim[dim] = {
                "dimension": dim,
                "weight": round(weight, 6),
                "quality": round(quality, 6),
                "sample": sample,
                "matched_signals": int(acc["matched"]),
                "edge": round(edge, 6),
                "base_weight": base_weight,
                "best": sorted(acc["best"], key=lambda x: (x["edge"], x["sample"]), reverse=True)[:6],
                "worst": sorted(acc["worst"], key=lambda x: (x["edge"], -x["sample"]))[:6],
                "source": "signal_scores",
            }

        # V10.16.72: do not allow adaptive_feature_weights to stay empty when
        # signal bucket generation is sparse. We can learn single-feature
        # usefulness directly from feature_json on every snapshot and compare it
        # against the same horizon/regime baseline. This fills durable weights
        # for RSI, funding, premium, trend, volatility, etc. even when only a
        # subset of time_machine_signal_scores was written.
        try:
            snap_rows = db.df(
                """
                SELECT horizon, COALESCE(NULLIF(regime,''),'unknown') AS regime, feature_json,
                       target_reached, partial_reached, direction_correct, total_score, target_gap_pct
                FROM time_machine_feature_snapshots
                WHERE feature_json IS NOT NULL
                """
            ).to_dict("records")
        except Exception:
            snap_rows = []
        snap_acc: dict[str, dict[str, Any]] = {}
        for sr in snap_rows:
            h = str(sr.get("horizon") or "unknown")
            reg = str(sr.get("regime") or "unknown")
            ctx = _feature_context_from_snapshot(sr.get("feature_json"), reg)
            if not ctx:
                continue
            target = bool(sr.get("target_reached"))
            partial = bool(sr.get("partial_reached"))
            direction = bool(sr.get("direction_correct"))
            outcome = 1.0 if target else (0.62 if partial else (0.42 if direction else 0.0))
            score = _safe_float(sr.get("total_score"), 0.0) / 100.0
            gap_quality = max(0.0, 1.0 - min(_safe_float(sr.get("target_gap_pct"), 0.0), 12.0) / 12.0)
            base = baseline.get((h, reg), baseline.get((h, "unknown"), 0.5))
            for dim, bucket in ctx.items():
                if dim == "regime":
                    continue
                st = snap_acc.setdefault(dim, {"sample": 0.0, "outcome_sum": 0.0, "edge_sum": 0.0, "score_sum": 0.0, "gap_sum": 0.0, "buckets": {}})
                st["sample"] += 1
                st["outcome_sum"] += outcome
                st["edge_sum"] += (outcome - base)
                st["score_sum"] += score
                st["gap_sum"] += gap_quality
                b = st["buckets"].setdefault(str(bucket), {"n": 0, "outcome": 0.0})
                b["n"] += 1; b["outcome"] += outcome
        for dim, st in snap_acc.items():
            sample = int(st["sample"] or 0)
            if sample < max(40, int(min_total)):
                continue
            base_weight = DEFAULT_FEATURE_WEIGHTS.get(dim, 1.0)
            outcome = st["outcome_sum"] / max(1.0, st["sample"])
            edge = st["edge_sum"] / max(1.0, st["sample"])
            avg_score = st["score_sum"] / max(1.0, st["sample"])
            gap_q = st["gap_sum"] / max(1.0, st["sample"])
            maturity = _clamp(sample / 1400.0, 0.20, 1.0)
            quality = _clamp(0.48 + edge * 0.95 + (outcome - 0.50) * 0.55 + (avg_score - 0.50) * 0.25 + (gap_q - 0.50) * 0.10, 0.04, 0.96)
            weight = _clamp(base_weight * (1.0 + (quality - 0.50) * 1.85 * maturity), 0.12, 2.65)
            top_buckets = sorted([{"bucket": k, "sample": int(v["n"]), "outcome": round(v["outcome"]/max(1,v["n"]),4)} for k,v in st["buckets"].items()], key=lambda x: (x["outcome"], x["sample"]), reverse=True)[:8]
            prev = by_dim.get(dim)
            if prev:
                # Blend signal-based and snapshot-based learning. Snapshot
                # evidence is broader, signal evidence is sharper.
                old_n = float(prev.get("sample") or 0)
                new_n = sample
                blended_weight = (float(prev.get("weight") or base_weight)*min(old_n, new_n) + weight*new_n) / max(1.0, min(old_n, new_n)+new_n)
                blended_quality = max(float(prev.get("quality") or 0.5), quality)
                prev.update({"weight": round(_clamp(blended_weight, 0.10, 2.85),6), "quality": round(blended_quality,6), "sample": int(old_n+new_n), "matched_signals": int(prev.get("matched_signals") or 0)+len(top_buckets), "snapshot_edge": round(edge,6), "snapshot_outcome": round(outcome,6), "snapshot_top_buckets": top_buckets, "source": "signal_scores+feature_snapshots"})
            else:
                by_dim[dim] = {"dimension": dim, "weight": round(weight,6), "quality": round(quality,6), "sample": sample, "matched_signals": len(top_buckets), "edge": round(edge,6), "snapshot_outcome": round(outcome,6), "base_weight": base_weight, "best": top_buckets, "worst": [], "source": "feature_snapshots"}

        ordered = sorted(by_dim.values(), key=lambda r: (r["sample"], abs(r["weight"] - DEFAULT_FEATURE_WEIGHTS.get(r["dimension"], 1.0))), reverse=True)
        table_rows = [[r["dimension"], r["weight"], r["quality"], r["sample"], r["matched_signals"]] for r in ordered]
        return table_rows, ordered

    def _build_model_weights(self) -> tuple[list[list[Any]], list[dict[str, Any]]]:
        """Build horizon-specific model weights from real Time Machine outcomes.

        V10.16.72 fixes an important learning blind spot: older builds rebuilt
        adaptive_model_weights from model_scores only. That table was often
        almost flat/equal for every model, so the live ensemble did not really
        learn which specialists were useful. This version parses every
        model_contributions_json row from time_machine_tests and scores each
        specialist against the actual forward direction. It then writes both the
        native model id and the live-Python alias ids used by ModelArena.
        """
        rows: list[dict[str, Any]] = []
        try:
            rows = db.df(
                """
                SELECT horizon, actual_move_pct, model_contributions_json
                FROM time_machine_tests
                WHERE model_contributions_json IS NOT NULL AND actual_move_pct IS NOT NULL
                """
            ).to_dict("records")
        except Exception:
            rows = []

        acc: dict[tuple[str, str], dict[str, float]] = {}
        for r in rows:
            horizon = str(r.get("horizon") or "unknown")
            actual = _safe_float(r.get("actual_move_pct"), 0.0)
            actual_dir = 1 if actual >= 0 else -1
            try:
                raw = r.get("model_contributions_json")
                data = json.loads(raw) if isinstance(raw, str) and raw.strip() else raw
                contribs = data.get("contributions", []) if isinstance(data, dict) else (data if isinstance(data, list) else [])
            except Exception:
                contribs = []
            for c in contribs:
                if not isinstance(c, dict):
                    continue
                mid = str(c.get("model_id") or "").strip()
                if not mid:
                    continue
                prob = _safe_float(c.get("bullish_probability"), 0.5)
                move = _safe_float(c.get("expected_move_pct"), 0.0)
                pred_dir = 1 if (prob >= 0.5 if c.get("bullish_probability") is not None else move >= 0) else -1
                st = acc.setdefault((mid, horizon), {"sample": 0.0, "wins": 0.0, "err_sum": 0.0, "conf_sum": 0.0, "abs_move_sum": 0.0})
                st["sample"] += 1
                st["wins"] += 1 if pred_dir == actual_dir else 0
                st["err_sum"] += abs(move - actual)
                st["conf_sum"] += _safe_float(c.get("confidence"), 50.0)
                st["abs_move_sum"] += abs(move)

        out_rows: list[list[Any]] = []
        summary: list[dict[str, Any]] = []
        if acc:
            for (mid, horizon), st in acc.items():
                sample = int(st["sample"] or 0)
                if sample <= 0:
                    continue
                hitrate = st["wins"] / sample
                err = st["err_sum"] / sample
                avg_conf = st["conf_sum"] / sample
                avg_abs_move = st["abs_move_sum"] / sample
                maturity = _clamp(sample / 700.0, 0.20, 1.0)
                # Direction accuracy is the primary signal; huge target errors and
                # overconfident/oversized models are penalised. Keep the bounds
                # conservative so one Random1000 cannot make the system reckless.
                err_penalty = min(err, 12.0) * 0.010
                move_penalty = min(avg_abs_move, 30.0) * 0.0025
                quality = _clamp(0.50 + (hitrate - 0.50) * (1.15 + 0.55*maturity) - err_penalty - move_penalty, 0.04, 0.96)
                weight = _clamp(1.0 + (quality - 0.50) * 2.20 * maturity, 0.35, 2.15)
                rec = {
                    "model_id": mid, "horizon": horizon, "sample": sample,
                    "hitrate": round(hitrate, 6), "avg_price_error_pct": round(err, 6),
                    "avg_confidence": round(avg_conf, 3), "avg_abs_move_pct": round(avg_abs_move, 3),
                    "quality": round(quality, 6), "weight": round(weight, 6),
                    "source": "time_machine_model_contributions",
                }
                summary.append(rec)
                out_rows.append([mid, horizon, rec["weight"], rec["hitrate"], sample, rec["avg_price_error_pct"], rec["quality"]])
                for alias in NATIVE_TO_LIVE_MODEL_ALIASES.get(mid, []):
                    alias_rec = dict(rec)
                    alias_rec["model_id"] = alias
                    alias_rec["native_source_model_id"] = mid
                    alias_rec["source"] = "native_alias"
                    summary.append(alias_rec)
                    out_rows.append([alias, horizon, rec["weight"], rec["hitrate"], sample, rec["avg_price_error_pct"], rec["quality"]])
        else:
            # Fallback for older databases without model_contributions_json.
            legacy = db.df("SELECT model_id, horizon, total, hitrate, avg_price_error_pct FROM model_scores WHERE total > 0").to_dict("records")
            for r in legacy:
                total = int(r.get("total") or 0)
                hitrate = _safe_float(r.get("hitrate"), 0.5)
                err = _safe_float(r.get("avg_price_error_pct"), 0.0)
                maturity = _clamp(total / 1000.0, 0.10, 1.0)
                quality = _clamp(0.5 + (hitrate - 0.5) * (0.9 + 0.6 * maturity) - min(err, 5.0) * 0.015, 0.05, 0.95)
                weight = _clamp(0.65 + quality * 1.25, 0.45, 1.90)
                rec = {"model_id": str(r.get("model_id")), "horizon": str(r.get("horizon")), "sample": total, "hitrate": round(hitrate, 4), "avg_price_error_pct": round(err, 4), "quality": round(quality, 6), "weight": round(weight, 6), "source": "legacy_model_scores"}
                summary.append(rec)
                out_rows.append([rec["model_id"], rec["horizon"], rec["weight"], rec["hitrate"], rec["sample"], rec["avg_price_error_pct"], rec["quality"]])
        # De-duplicate primary key rows: keep the highest sample/quality version.
        best: dict[tuple[str, str], list[Any]] = {}
        for r in out_rows:
            key = (str(r[0]), str(r[1]))
            old = best.get(key)
            if old is None or (int(r[4] or 0), float(r[6] or 0)) > (int(old[4] or 0), float(old[6] or 0)):
                best[key] = r
        final_rows = list(best.values())
        summary.sort(key=lambda x: (x["horizon"], -x["quality"], -x["sample"]))
        return final_rows, summary

    def _build_regime_weights(self) -> tuple[list[list[Any]], list[dict[str, Any]]]:
        """Build per-regime/per-horizon weights from Time Machine snapshots.

        V10.16.41 fixes the v10.16.39/40 regression where rebuild() called
        _build_regime_weights() but the method was missing, causing adaptive
        learning exports to stay empty even though Random1000 completed.

        The output is deliberately simple and auditable:
        - sample/win/partial/fail counts per regime and horizon
        - hitrate and hitrate+partial
        - avg_score
        - conservative weight relative to the horizon baseline
        """
        try:
            rows = db.df(
                """
                SELECT
                    COALESCE(NULLIF(regime, ''), 'unknown') AS regime,
                    horizon,
                    COUNT(*) AS sample,
                    SUM(CASE WHEN target_reached THEN 1 ELSE 0 END) AS wins,
                    SUM(CASE WHEN partial_reached AND NOT target_reached THEN 1 ELSE 0 END) AS partials,
                    SUM(CASE WHEN NOT target_reached AND NOT partial_reached THEN 1 ELSE 0 END) AS fails,
                    AVG(CASE WHEN target_reached THEN 1.0 ELSE 0.0 END) AS hitrate,
                    AVG(CASE WHEN target_reached OR partial_reached THEN 1.0 ELSE 0.0 END) AS hitrate_with_partial,
                    AVG(COALESCE(total_score, 0.0)) AS avg_score
                FROM time_machine_feature_snapshots
                GROUP BY regime, horizon
                """
            ).to_dict("records")
        except Exception:
            rows = []
        baseline_rows = db.df(
            """
            SELECT horizon,
                   AVG(CASE WHEN target_reached OR partial_reached THEN 1.0 ELSE 0.0 END) AS hwp,
                   AVG(COALESCE(total_score, 0.0)) AS avg_score
            FROM time_machine_feature_snapshots
            GROUP BY horizon
            """
        ).to_dict("records")
        baseline = {str(r.get("horizon")): (_safe_float(r.get("hwp"), 0.5), _safe_float(r.get("avg_score"), 50.0)) for r in baseline_rows}
        table_rows: list[list[Any]] = []
        summary: list[dict[str, Any]] = []
        for r in rows:
            regime = str(r.get("regime") or "unknown")
            horizon = str(r.get("horizon") or "unknown")
            sample = int(r.get("sample") or 0)
            if sample <= 0:
                continue
            wins = int(r.get("wins") or 0)
            partials = int(r.get("partials") or 0)
            fails = int(r.get("fails") or 0)
            hitrate = _safe_float(r.get("hitrate"), 0.0)
            hwp = _safe_float(r.get("hitrate_with_partial"), 0.0)
            avg_score = _safe_float(r.get("avg_score"), 0.0)
            base_hwp, base_score = baseline.get(horizon, (0.5, 50.0))
            edge = hwp - base_hwp
            score_edge = (avg_score - base_score) / 100.0
            maturity = _clamp(sample / 600.0, 0.15, 1.0)
            quality = _clamp(0.50 + edge * 1.15 + score_edge * 0.60, 0.05, 0.95)
            # Conservative regime steering: enough to matter, not enough to dominate.
            weight = _clamp(1.0 + (edge * 1.60 + score_edge * 0.85) * maturity, 0.55, 1.65)
            rec = {
                "regime": regime, "horizon": horizon, "sample": sample,
                "wins": wins, "partials": partials, "fails": fails,
                "hitrate": round(hitrate, 6), "hitrate_with_partial": round(hwp, 6),
                "avg_score": round(avg_score, 6), "weight": round(weight, 6),
                "quality": round(quality, 6), "baseline_hwp": round(base_hwp, 6),
                "edge": round(edge, 6),
            }
            summary.append(rec)
            table_rows.append([regime, horizon, sample, wins, partials, fails, rec["hitrate"], rec["hitrate_with_partial"], rec["avg_score"], rec["weight"], rec["quality"]])
        summary.sort(key=lambda x: (x["horizon"], -x["quality"], -x["sample"]))
        return table_rows, summary


    def _build_feature_pair_weights(self, baseline: dict[tuple[str, str], float], min_total: int = 12) -> tuple[list[list[Any]], list[dict[str, Any]]]:
        """Learn useful feature combinations from real snapshot outcomes.

        V10.16.46 goes beyond single feature weights. It asks: does
        funding-positive + premium-positive beat the horizon/regime baseline?
        Only combinations with enough samples are stored and shown in the app.
        """
        try:
            rows = db.df(
                """
                SELECT horizon, COALESCE(NULLIF(regime,''),'unknown') AS regime, feature_json,
                       target_reached, partial_reached, total_score, target_gap_pct
                FROM time_machine_feature_snapshots
                WHERE feature_json IS NOT NULL
                """
            ).to_dict("records")
        except Exception:
            rows = []
        acc: dict[tuple[str, str, str, str, str, str], dict[str, Any]] = {}
        preferred_order = ["funding", "premium", "trend", "rsi", "volatility", "fear_greed", "long_short", "open_interest", "drawdown", "regime"]
        for r in rows:
            h = str(r.get("horizon") or "unknown")
            reg = str(r.get("regime") or "unknown")
            ctx = _feature_context_from_snapshot(r.get("feature_json"), reg)
            dims = [d for d in preferred_order if d in ctx]
            if len(dims) < 2:
                continue
            target = bool(r.get("target_reached"))
            partial = bool(r.get("partial_reached")) and not target
            score = _safe_float(r.get("total_score"), 0.0)
            for i in range(len(dims)):
                for j in range(i + 1, len(dims)):
                    a, b = dims[i], dims[j]
                    ba, bb = ctx[a], ctx[b]
                    key = (a, ba, b, bb, h, reg)
                    st = acc.setdefault(key, {"sample": 0, "wins": 0, "partials": 0, "fails": 0, "score_sum": 0.0})
                    st["sample"] += 1
                    st["score_sum"] += score
                    if target:
                        st["wins"] += 1
                    elif partial:
                        st["partials"] += 1
                    else:
                        st["fails"] += 1
        out_rows: list[list[Any]] = []
        summary: list[dict[str, Any]] = []
        for (a, ba, b, bb, h, reg), st in acc.items():
            sample = int(st["sample"] or 0)
            if sample < int(min_total):
                continue
            wins = int(st["wins"]); partials = int(st["partials"]); fails = int(st["fails"])
            hit = wins / sample if sample else 0.0
            hwp = (wins + partials) / sample if sample else 0.0
            base = baseline.get((h, reg), baseline.get((h, "unknown"), 0.5))
            edge = hwp - base
            avg_score = st["score_sum"] / sample if sample else 0.0
            maturity = _clamp(sample / 300.0, 0.15, 1.0)
            quality = _clamp(0.50 + edge * 1.35 + ((avg_score - 50.0) / 100.0) * 0.45, 0.05, 0.95)
            weight = _clamp(1.0 + (edge * 1.9 + ((avg_score - 50.0) / 100.0) * 0.55) * maturity, 0.50, 1.85)
            pair_key = f"{a}:{ba}+{b}:{bb}|{h}|{reg}"
            rec = {
                "pair_key": pair_key, "feature_a": a, "bucket_a": ba, "feature_b": b, "bucket_b": bb,
                "horizon": h, "regime": reg, "sample": sample, "wins": wins, "partials": partials, "fails": fails,
                "hitrate": round(hit, 6), "hitrate_with_partial": round(hwp, 6), "baseline_hwp": round(base, 6),
                "edge": round(edge, 6), "weight": round(weight, 6), "quality": round(quality, 6), "avg_score": round(avg_score, 3),
            }
            summary.append(rec)
            out_rows.append([pair_key, a, ba, b, bb, h, reg, sample, wins, partials, fails, rec["hitrate"], rec["hitrate_with_partial"], rec["baseline_hwp"], rec["edge"], rec["weight"], rec["quality"]])
        summary.sort(key=lambda x: (x["quality"], x["edge"], x["sample"]), reverse=True)
        return out_rows, summary[:120]

    def status(self) -> dict[str, Any]:
        latest = db.fetchone("SELECT run_id, created_at, status, feature_dimensions, model_dimensions, signal_buckets, snapshot_rows, summary_json FROM adaptive_learning_runs ORDER BY created_at DESC LIMIT 1")
        feature_rows = db.df("SELECT * FROM adaptive_feature_weights ORDER BY sample DESC, quality DESC").to_dict("records")
        model_rows = db.df("SELECT * FROM adaptive_model_weights ORDER BY horizon, quality DESC, sample DESC LIMIT 250").to_dict("records")
        try:
            regime_rows = db.df("SELECT * FROM adaptive_regime_weights ORDER BY horizon, quality DESC, sample DESC LIMIT 250").to_dict("records")
        except Exception:
            regime_rows = []
        try:
            pair_rows = db.df("SELECT * FROM adaptive_feature_pair_weights ORDER BY quality DESC, edge DESC, sample DESC LIMIT 250").to_dict("records")
        except Exception:
            pair_rows = []
        top_signals = db.df(
            """
            SELECT signal_key, signal_label, signal_type, horizon, regime, total, wins, partials, fails,
                   hitrate, hitrate_with_partial, avg_score, avg_target_gap_pct
            FROM time_machine_signal_scores
            WHERE total >= 20 AND signal_key NOT LIKE '%:unknown%'
            ORDER BY hitrate_with_partial DESC, total DESC, avg_score DESC
            LIMIT 60
            """
        ).to_dict("records")
        payload = {
            "ok": True,
            "engine_version": settings.engine_version,
            "latest_run": {
                "run_id": latest[0], "created_at": latest[1], "status": latest[2], "feature_dimensions": int(latest[3] or 0),
                "model_dimensions": int(latest[4] or 0), "signal_buckets": int(latest[5] or 0), "snapshot_rows": int(latest[6] or 0)
            } if latest else None,
            "feature_weights": feature_rows,
            "model_weights": model_rows,
            "regime_weights": regime_rows,
            "pair_weights": pair_rows,
            "top_signals": top_signals,
            "summary": {
                "feature_dimensions": len(feature_rows),
                "model_dimensions": len(model_rows),
                "regime_dimensions": len(regime_rows),
                "pair_dimensions": len(pair_rows),
                "top_signal_buckets": len(top_signals),
                "active": bool(feature_rows or model_rows or regime_rows or pair_rows),
            },
        }
        write_json("adaptive_learning_status.json", payload)
        return payload
