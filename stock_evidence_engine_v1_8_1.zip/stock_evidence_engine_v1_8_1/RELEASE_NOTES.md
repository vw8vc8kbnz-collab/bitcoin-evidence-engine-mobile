v1.8.1: adds price reaction intelligence, consensus scoring, historical analog memory exports and reaction-adjusted probabilities.

Installer fix: ZIP root paths normalized; install.sh can recover/move from any extracted folder into /home/ubuntu/stock_evidence_latest.
