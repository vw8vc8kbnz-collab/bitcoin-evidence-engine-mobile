SEE v1.8.1 goal: combine catalyst/news reasoning with actual market reaction, multi-source consensus and analog memory while preserving stable VPS deployment.

Installer fix: ZIP root paths normalized; install.sh can recover/move from any extracted folder into /home/ubuntu/stock_evidence_latest.
