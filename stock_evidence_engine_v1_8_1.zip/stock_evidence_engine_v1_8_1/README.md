Stock Evidence Engine v1.8.1
- DeepSeek analyst brain
- Price Reaction Engine
- News Consensus Engine
- Historical Analog Memory proxy
- ntfy alerts and cost guard
Stable runtime: server.py on port 8798.

Installer fix: ZIP root paths normalized; install.sh can recover/move from any extracted folder into /home/ubuntu/stock_evidence_latest.
