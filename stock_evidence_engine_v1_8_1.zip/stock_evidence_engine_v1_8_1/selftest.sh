#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
test -f server.py
test -f engine.py
test -f install.sh
test -f run_backtest.sh
test -f deepseek_prompt.md
python3 -m py_compile server.py engine.py
echo "[SEE selftest] OK"
