#!/usr/bin/env bash
set -euo pipefail
TICKERS="${1:-BB,PLTR,IONQ,SOUN,NVDA,AMD,TSLA}"
cd /home/ubuntu/stock_evidence_latest
./venv/bin/python engine.py "$TICKERS"
