const CACHE_NAME = 'bee-mobile-10_16_53_adaptive_intelligence_dashboard';
const APP_SHELL = ['/mobile', '/manifest.webmanifest', '/static/css/mobile_app.css?v=10_16_53_adaptive_intelligence_dashboard', '/static/js/mobile_app.js?v=10_16_53_adaptive_intelligence_dashboard', '/static/icons/icon-192.png', '/static/icons/icon-512.png'];
self.addEventListener('install', event => { self.skipWaiting(); event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(APP_SHELL).catch(()=>{}))); });
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))));
  self.clients.claim();
});
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  if (url.pathname.startsWith('/api/')) return;
  if (event.request.method !== 'GET') return;
  event.respondWith((async()=>{
    try {
      const fresh = await fetch(event.request, {cache:'no-store'});
      const cache = await caches.open(CACHE_NAME);
      cache.put(event.request, fresh.clone()).catch(()=>{});
      return fresh;
    } catch(e) {
      const cached = await caches.match(event.request);
      return cached || caches.match('/mobile') || new Response('Offline', {status:503});
    }
  })());
});
