from __future__ import annotations
from datetime import datetime, timezone, timedelta
from bee_short_alpha import build_daily_short_features, evaluate_euphoria_exhaustion

def _mk_hourly(days=430, close=100000.0, fg=50, ext_boost=False, outlier=False):
    start = datetime(2024, 1, 1, tzinfo=timezone.utc)
    candles=[]
    price=50000.0
    for d in range(days):
        # slow trend with optional euphoria ramp near the end
        if ext_boost and d > days-80:
            price *= 1.006
        else:
            price *= 1.0007
        if outlier and d == days-2:
            price *= 8.3
        for h in range(24):
            dt=start+timedelta(days=d,hours=h)
            intr=price*(1+0.001*((h%6)-3))
            candles.append({"dt":dt.isoformat().replace('+00:00','Z'),"open":intr*0.999,"high":intr*1.002,"low":intr*0.998,"close":intr})
    return {"candles_1h":candles,"idx":len(candles)-1,"fear_greed":fg,"ath":max(c["close"] for c in candles)}

def _case(name, snap):
    sf=build_daily_short_features(snap,{"fear_greed":snap.get("fear_greed")})
    ev=evaluate_euphoria_exhaustion(sf)
    return {"case":name,"data_quality":sf.get("data_quality"),"closed_daily_count":sf.get("closed_daily_count"),"ma50_ext":sf.get("ma50_extension_pct"),"ext_pctile":sf.get("ma50_extension_percentile_365d"),"decision":ev.get("decision"),"tier":ev.get("tier"),"score":ev.get("score"),"reason":ev.get("reason"),"rr":ev.get("rr")}

def run_short_engine_tests():
    cases=[
        _case("normal_market", _mk_hourly(fg=50, ext_boost=False)),
        _case("greed_no_overextension", _mk_hourly(fg=82, ext_boost=False)),
        _case("strong_short", _mk_hourly(fg=72, ext_boost=True)),
        _case("elite_short", _mk_hourly(fg=78, ext_boost=True)),
        _case("insufficient_history", _mk_hourly(days=80, fg=80, ext_boost=True)),
        _case("data_outlier", _mk_hourly(fg=80, ext_boost=True, outlier=True)),
    ]
    passed = True
    passed = passed and cases[0]["decision"] == "NO_TRADE"
    passed = passed and cases[4]["decision"] == "NO_TRADE"
    passed = passed and cases[5]["decision"] == "NO_TRADE"
    return {"passed":passed,"test_type":"short_engine_scenario_tests","cases":cases}
