#!/usr/bin/env python3
from __future__ import annotations
from datetime import datetime, timezone, date
import math

VERSION = "euphoria_exhaustion_v1_calibrated_paper"

SHORT_STATS = {
    "watch": {"horizon": "30d", "expected_return_pct": -15.0, "short_win_pct": 82.0, "sample_size": "calibrated_short_research"},
    "strong": {"horizon": "30d", "expected_return_pct": -18.7, "short_win_pct": 89.0, "sample_size": "n=102_8y_recent52d"},
    "elite": {"horizon": "30d", "expected_return_pct": -21.0, "short_win_pct": 97.0, "sample_size": "n=32_8y"},
}


def _f(v, default=None):
    try:
        if v is None or v == "":
            return default
        x = float(v)
        if math.isnan(x) or math.isinf(x):
            return default
        return x
    except Exception:
        return default


def _dt(raw):
    try:
        d = datetime.fromisoformat(str(raw).replace("Z", "+00:00"))
        if d.tzinfo is None:
            d = d.replace(tzinfo=timezone.utc)
        return d.astimezone(timezone.utc)
    except Exception:
        return None


def _percentile_rank(values, current):
    vals = [float(v) for v in values if v is not None and math.isfinite(float(v))]
    if current is None or not vals:
        return None
    return sum(1 for v in vals if v <= current) / float(len(vals))


def _rsi(closes, period=14):
    if len(closes) < period + 1:
        return None
    gains = []
    losses = []
    for i in range(len(closes) - period, len(closes)):
        diff = closes[i] - closes[i - 1]
        gains.append(max(diff, 0.0))
        losses.append(max(-diff, 0.0))
    avg_gain = sum(gains) / period
    avg_loss = sum(losses) / period
    if avg_loss == 0:
        return 100.0
    rs = avg_gain / avg_loss
    return 100.0 - (100.0 / (1.0 + rs))


def _aggregate_closed_daily_from_hourly(candles_1h, idx=None):
    """Build closed daily candles from hourly candles.

    The current UTC day is treated as incomplete and excluded. This prevents the
    short engine from creating a new 'daily' signal every hour while the daily
    candle is still forming.
    """
    if not candles_1h:
        return []
    if idx is None:
        idx = len(candles_1h) - 1
    idx = max(0, min(int(idx), len(candles_1h) - 1))
    rows = []
    for c in candles_1h[:idx + 1]:
        d = _dt(c.get("dt") or c.get("timestamp") or c.get("time"))
        close = _f(c.get("close"))
        if d is None or close is None or close <= 0:
            continue
        rows.append({
            "dt": d,
            "day": d.date(),
            "open": _f(c.get("open"), close),
            "high": _f(c.get("high"), close),
            "low": _f(c.get("low"), close),
            "close": close,
        })
    if not rows:
        return []
    current_day = rows[-1]["day"]
    buckets = {}
    counts = {}
    for r in rows:
        day = r["day"]
        if day == current_day:
            continue
        if day not in buckets:
            buckets[day] = {"day": day.isoformat(), "open": r["open"], "high": r["high"], "low": r["low"], "close": r["close"], "dt": r["dt"].isoformat().replace("+00:00", "Z")}
            counts[day] = 0
        buckets[day]["high"] = max(buckets[day]["high"], r["high"])
        buckets[day]["low"] = min(buckets[day]["low"], r["low"])
        buckets[day]["close"] = r["close"]
        buckets[day]["dt"] = r["dt"].isoformat().replace("+00:00", "Z")
        counts[day] += 1
    out = []
    for day in sorted(buckets):
        rec = buckets[day]
        rec["hour_count"] = counts.get(day, 0)
        rec["quality"] = "OK" if rec["hour_count"] >= 20 else "INCOMPLETE"
        out.append(rec)
    return out


def build_daily_short_features(snapshot, live_features=None):
    candles = snapshot.get("daily_candles") or snapshot.get("candles_1d") or []
    source = "daily_candles"
    if not candles:
        candles = _aggregate_closed_daily_from_hourly(snapshot.get("candles_1h") or [], snapshot.get("idx"))
        source = "aggregated_closed_hourly"

    # Normalize external daily shape if present.
    norm = []
    for c in candles:
        close = _f(c.get("close"))
        if close is None or close <= 0:
            continue
        d_raw = c.get("day") or c.get("dt") or c.get("timestamp") or c.get("time")
        d_obj = _dt(d_raw) if d_raw else None
        day_s = c.get("day") or (d_obj.date().isoformat() if d_obj else "")
        norm.append({
            "day": str(day_s)[:10],
            "open": _f(c.get("open"), close),
            "high": _f(c.get("high"), close),
            "low": _f(c.get("low"), close),
            "close": close,
            "quality": c.get("quality", "OK"),
            "hour_count": c.get("hour_count", ""),
        })
    candles = norm
    n = len(candles)
    if n == 0:
        return {"version": VERSION, "active": False, "data_quality": "NO_DAILY_CANDLES", "reason": "NO_DAILY_CANDLES", "daily_source": source}

    closes = [c["close"] for c in candles]
    current = candles[-1]
    close = closes[-1]
    fg = _f((live_features or {}).get("fear_greed"), _f(snapshot.get("fear_greed"), 50.0))
    ma50 = sum(closes[-50:]) / 50.0 if n >= 50 else None
    ma200 = sum(closes[-200:]) / 200.0 if n >= 200 else None
    ma50_ext = (close / ma50 - 1.0) if ma50 and ma50 > 0 else None
    ma200_ext = (close / ma200 - 1.0) if ma200 and ma200 > 0 else None

    ext_hist = []
    lookback = min(365, n)
    start = max(49, n - lookback)
    for i in range(start, n):
        ma = sum(closes[i-49:i+1]) / 50.0
        if ma > 0:
            ext_hist.append(closes[i] / ma - 1.0)
    ext_pctile = _percentile_rank(ext_hist, ma50_ext) if len(ext_hist) >= 365 and ma50_ext is not None else None

    ret1 = closes[-1] / closes[-2] - 1.0 if n >= 2 and closes[-2] > 0 else None
    ret3 = closes[-1] / closes[-4] - 1.0 if n >= 4 and closes[-4] > 0 else None
    ret7 = closes[-1] / closes[-8] - 1.0 if n >= 8 and closes[-8] > 0 else None
    rsi14 = _rsi(closes, 14)
    vol30 = None
    if n >= 31:
        rets = [closes[i] / closes[i-1] - 1.0 for i in range(n-30, n) if closes[i-1] > 0]
        if rets:
            mu = sum(rets) / len(rets)
            vol30 = (sum((r - mu) ** 2 for r in rets) / len(rets)) ** 0.5

    data_quality = "OK"
    warnings = []
    if n < 120:
        data_quality = "INSUFFICIENT_DAILY_HISTORY"
        warnings.append("Need at least 120 closed daily candles for short engine.")
    if ext_pctile is None:
        if n >= 120:
            data_quality = "PERCENTILE_HISTORY_INCOMPLETE"
            warnings.append("<365 daily closes; using absolute MA50 extension fallback only.")
        else:
            warnings.append("MA50 extension percentile unavailable.")
    if current.get("quality") == "INCOMPLETE":
        data_quality = "LATEST_DAILY_CANDLE_INCOMPLETE"
        warnings.append("Latest closed day appears incomplete.")

    outlier = False
    if ma50 is None or ma50 <= 0 or close <= 0:
        outlier = True; data_quality = "INVALID_MA50_OR_CLOSE"; warnings.append("Invalid MA50/close.")
    if ret1 is not None and abs(ret1) > 0.35:
        outlier = True; data_quality = "IMPOSSIBLE_DAILY_RETURN"; warnings.append("Daily return >35%; possible data gap/outlier.")
    if ma50_ext is not None and (ma50_ext > 1.50 or ma50_ext < -0.80):
        outlier = True; data_quality = "MA50_EXTENSION_OUTLIER"; warnings.append("MA50 extension outside sanity bounds.")

    return {
        "version": VERSION,
        "daily_source": source,
        "closed_daily_count": n,
        "closed_day": current.get("day", ""),
        "close": close,
        "fear_greed": fg,
        "ma50": ma50,
        "ma200": ma200,
        "ma50_extension_pct": ma50_ext,
        "ma200_extension_pct": ma200_ext,
        "ma50_extension_percentile_365d": ext_pctile,
        "rsi_14_daily": rsi14,
        "return_1d": ret1,
        "return_3d": ret3,
        "return_7d": ret7,
        "volatility_30d": vol30,
        "data_quality": data_quality,
        "data_warnings": warnings,
        "outlier_block": outlier,
        "active": False,
        "reason": data_quality if data_quality != "OK" else "READY",
    }


def _expected_move_for(tier, horizon, volatility_30d=None):
    floors = {"7d": 0.04, "14d": 0.07, "30d": 0.15}
    caps = {"7d": 0.08, "14d": 0.12, "30d": 0.22}
    if volatility_30d is None:
        return floors[horizon]
    k = {"7d": 4.0, "14d": 6.0, "30d": 10.0}[horizon]
    return min(caps[horizon], max(floors[horizon], volatility_30d * k))


def _tier_from_features(fg, ext_pctile, ma50_ext, rsi):
    # Calibrated from Claude audit: usable frequency plus strong edge.
    # With complete percentile history: use percentile tiers.
    if ext_pctile is not None:
        if fg >= 75 and ext_pctile >= 0.90:
            return "elite"
        if fg >= 70 and ext_pctile >= 0.85:
            return "strong"
        if fg >= 70 and ext_pctile >= 0.80:
            return "watch"
        # Soft one-factor routes: keep as watch only; score decides if useful.
        if fg >= 75 or ext_pctile >= 0.95:
            return "watch"
        return "none"
    # Fallback under <365 days: absolute extension warning only, no elite.
    if ma50_ext is None:
        return "none"
    if fg >= 75 and ma50_ext >= 0.20:
        return "strong"
    if fg >= 70 and ma50_ext >= 0.15:
        return "watch"
    return "none"


def evaluate_euphoria_exhaustion(features):
    """Return a paper-only SHORT candidate or a NO_TRADE diagnostic.

    This engine is deliberately independent from the validated long research core.
    It is calibrated with lower gates than the initial plan: 0.80/0.85/0.90 ext
    percentiles plus F&G 70-75, because 0.95/0.98 gates were too rare.
    """
    fg = _f(features.get("fear_greed"), 50.0)
    ext_pctile = _f(features.get("ma50_extension_percentile_365d"))
    ma50_ext = _f(features.get("ma50_extension_pct"))
    rsi = _f(features.get("rsi_14_daily"))
    close = _f(features.get("close"))
    vol30 = _f(features.get("volatility_30d"))

    base = {
        "specialist": "euphoria_exhaustion",
        "paper_only": True,
        "prob_source": "research_rule_score_v1_not_calibrated",
        "short_engine_version": VERSION,
        "data_quality": features.get("data_quality", "UNKNOWN"),
        "closed_day": features.get("closed_day", ""),
        "daily_source": features.get("daily_source", ""),
        "closed_daily_count": features.get("closed_daily_count", 0),
        "ma50_extension_pct": ma50_ext,
        "ma50_extension_percentile_365d": ext_pctile,
        "rsi_14_daily": rsi,
        "fear_greed": fg,
        "engine_conflict": False,
    }

    score = 0
    reasons = []
    if fg >= 70: score += 25; reasons.append(f"F&G {fg:.0f} >=70 greed")
    if fg >= 75: score += 12; reasons.append("F&G >=75 euphoria")
    if fg >= 80: score += 8; reasons.append("F&G >=80 extreme greed")
    if ext_pctile is not None:
        if ext_pctile >= 0.80: score += 20; reasons.append(f"MA50 extension percentile {ext_pctile:.2f} >=0.80")
        if ext_pctile >= 0.85: score += 15; reasons.append("ext_pctile >=0.85 calibrated strong zone")
        if ext_pctile >= 0.90: score += 15; reasons.append("ext_pctile >=0.90 calibrated elite zone")
        if ext_pctile >= 0.95: score += 5; reasons.append("ext_pctile >=0.95 extreme overextension")
    elif ma50_ext is not None:
        if ma50_ext >= 0.15: score += 18; reasons.append(f"absolute MA50 extension {ma50_ext*100:.1f}% >=15% fallback")
        if ma50_ext >= 0.20: score += 12; reasons.append("absolute MA50 extension >=20% fallback")
        if ma50_ext >= 0.30: score += 8; reasons.append("absolute MA50 extension >=30% historical blowoff")
    if rsi is not None:
        if rsi >= 65: score += 5; reasons.append("daily RSI >=65")
        if rsi >= 70: score += 7; reasons.append("daily RSI >=70")
        if rsi >= 75: score += 3; reasons.append("daily RSI >=75")
    ret1 = _f(features.get("return_1d"))
    if ret1 is not None:
        if ret1 >= 0.04: score += 5; reasons.append("daily return >= +4% blowoff support")
        if ret1 >= 0.06: score += 5; reasons.append("daily return >= +6% euphoria day")

    tier = _tier_from_features(fg, ext_pctile, ma50_ext, rsi)
    hard_ok = tier != "none"
    blocked = bool(features.get("outlier_block")) or features.get("data_quality") in {"NO_DAILY_CANDLES", "INSUFFICIENT_DAILY_HISTORY", "INVALID_MA50_OR_CLOSE", "IMPOSSIBLE_DAILY_RETURN", "MA50_EXTENSION_OUTLIER", "LATEST_DAILY_CANDLE_INCOMPLETE"}

    if blocked or not hard_ok or score < 45 or close is None or close <= 0:
        reason = "; ".join(reasons) if reasons else features.get("reason", "NO_EUPHORIA_SHORT_GATE")
        if blocked:
            reason = f"BLOCKED_{features.get('data_quality')}: {reason}"
        elif not hard_ok:
            reason = f"NO_CALIBRATED_SHORT_GATE: {reason}"
        elif score < 45:
            reason = f"SCORE_TOO_LOW_{score}: {reason}"
        out = dict(base)
        out.update({"action": "NO_TRADE", "decision": "NO_TRADE", "tier": tier, "score": score, "confidence_score": score, "reason": reason, "active": False, "notify": False})
        return out

    # Tier by calibrated gates first, but score can upgrade watch to strong if many supports.
    if tier == "watch" and score >= 70:
        tier = "strong"
    if tier == "strong" and score >= 88 and fg >= 75:
        tier = "elite"

    horizon = "30d" if tier in {"strong", "elite"} else "14d"
    if tier == "watch" and score < 60:
        horizon = "7d"
    expected_move = _expected_move_for(tier, horizon, vol30)
    target = close * (1.0 - expected_move)
    recent_high_stop = close * 1.08
    stop_pct_cap = {"7d": 0.12, "14d": 0.18, "30d": 0.25}[horizon]
    vol_stop = close * (1.0 + max(0.06, min(stop_pct_cap, (vol30 or 0.03) * 5.0)))
    stop = min(close * (1.0 + stop_pct_cap), max(recent_high_stop, vol_stop))
    rr = abs(close - target) / max(1e-9, abs(stop - close))
    if rr < 1.2 and tier != "elite":
        out = dict(base)
        out.update({"action": "NO_TRADE", "decision": "NO_TRADE", "tier": tier, "score": score, "confidence_score": score, "horizon": horizon, "entry_price": round(close, 2), "take_profit": round(target, 2), "stop_loss": round(stop, 2), "rr": round(rr, 2), "reason": f"POOR_RR_{rr:.2f}; " + "; ".join(reasons), "active": False, "notify": False})
        return out

    stats = SHORT_STATS.get(tier, SHORT_STATS["watch"])
    out = dict(base)
    out.update({
        "action": "SHORT", "decision": "SHORT", "active": True, "notify": True,
        "tier": tier, "score": score, "confidence_score": min(100, score), "prob": round(min(0.99, score / 100.0), 4),
        "prob_source": "confidence_score_not_calibrated_probability",
        "priority": {"watch": 1, "strong": 2, "elite": 3}.get(tier, 1),
        "horizon": horizon,
        "entry_price": round(close, 2), "take_profit": round(target, 2), "stop_loss": round(stop, 2),
        "rr": round(rr, 2),
        "exit_policy": "paper_only_euphoria_exhaustion_monitor",
        "levels_label": "indicative_short_monitoring_levels_not_fixed_exit",
        "historical_winrate_pct": 100.0 - stats.get("short_win_pct", 0.0),  # existing label is chance of price rising; keep explicit reason below
        "oos_winrate_pct": None,
        "short_win_pct": stats.get("short_win_pct"),
        "sample_size": stats.get("sample_size"),
        "stats_period": "8y_plus_recent_2023_2026_research_pdf",
        "stats_source": "Diepe Short Analyse + Verbeteringen Euphoria Short Engine",
        "stats_verified": False,
        "reason": "; ".join(reasons) + "; PAPER_ONLY; short risk asymmetric, blow-off can extend",
    })
    return out
