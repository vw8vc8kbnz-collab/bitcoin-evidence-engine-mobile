#!/usr/bin/env bash
set -euo pipefail
ROOT="/home/ubuntu/bitcoin-engine-deploy/current/live_forecast"
OUT="/home/ubuntu/bee_state_files.zip"
cd "$ROOT"
mkdir -p state logs
rm -f "$OUT" "$OUT.tmp"
[ -f state/bee_history.csv ] || printf 'timestamp_utc,candle_dt,price,fear_greed,drawdown_from_ath,return_4,return_24,rsi_14,regime,specialist,prob,cycle_prob_raw,tier,decision,notify,last_notify_status,notify_skip_reason,reason,all_applicable_models,confluence_score,confluence_label,consensus_direction,execution_version,session_label,session_hour_utc,session_window,range_24h_pct,range_24h_percentile,range_regime,noise_risk,execution_advice_short
' > state/bee_history.csv
[ -f state/bee_signals.csv ] || printf 'signal_batch_id,signal_ts,candle_dt,specialist,decision,tier,prob,entry_price,take_profit,stop_loss,horizon,fear_greed,regime,reason,historical_winrate_pct,oos_winrate_pct,sample_size,stats_period,stats_source,stats_verified,all_applicable_models,confluence_score,consensus_direction,session_label,range_regime,noise_risk,execution_advice_short,outcome_price_30d,outcome_pct_30d,outcome_filled_at
' > state/bee_signals.csv
[ -f state/bee_status.json ] || printf '{}\n' > state/bee_status.json
[ -f logs/bee_live.log ] || printf '' > logs/bee_live.log
# Do not depend on the OS zip package. Use Python's stdlib zipfile so this works on a clean VPS.
python - <<'PY'
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
root = Path('/home/ubuntu/bitcoin-engine-deploy/current/live_forecast')
out = Path('/home/ubuntu/bee_state_files.zip')
tmp = Path(str(out) + '.tmp')
files = [
    ('state/bee_history.csv', 'bee_history.csv'),
    ('state/bee_status.json', 'bee_status.json'),
    ('state/bee_signals.csv', 'bee_signals.csv'),
    ('logs/bee_live.log', 'bee_live.log'),
]
with ZipFile(tmp, 'w', ZIP_DEFLATED) as z:
    for src, arc in files:
        p = root / src
        if p.exists():
            z.write(p, arc)
tmp.replace(out)
PY
printf 'STATE EXPORT READY: %s\n' "$OUT"
ls -lah "$OUT"
