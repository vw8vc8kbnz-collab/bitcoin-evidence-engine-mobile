#!/usr/bin/env bash
set -euo pipefail
cd /home/ubuntu/bitcoin-engine-deploy/current
printf '[1/9] Installing live forecast...\n'
chmod +x scripts/install_live_forecast.sh
./scripts/install_live_forecast.sh
cd live_forecast
. ../.venv/bin/activate
printf '[2/9] Version...\n'
python bee_live_forecast_v4_1_paper.py --version
printf '[3/9] Real production feature parity test...\n'
python bee_live_forecast_v4_1_paper.py --feature-parity-test
printf '[4/10] Golden test...\n'
python bee_live_forecast_v4_1_paper.py --golden-test
printf '[5/10] Short engine scenario test...\n'
python bee_live_forecast_v4_1_paper.py --short-engine-test
printf '[6/10] Basic ntfy test...\n'
python bee_live_forecast_v4_1_paper.py --test-ntfy
printf '[7/10] Trade ntfy test with model stats...\n'
python bee_live_forecast_v4_1_paper.py --test-trade-ntfy
printf '[8/10] Inspect live data and record status...\n'
python bee_live_forecast_v4_1_paper.py --inspect-live-data
printf '[9/10] Export debug ZIP...\n'
python bee_live_forecast_v4_1_paper.py --export-debug
printf '[10/12] Export state/history files ZIP...\n'
chmod +x ../scripts/export_state_files.sh 2>/dev/null || chmod +x /home/ubuntu/bitcoin-engine-deploy/current/scripts/export_state_files.sh
/home/ubuntu/bitcoin-engine-deploy/current/scripts/export_state_files.sh
printf '[11/12] Check daemon/status...\n'
chmod +x /home/ubuntu/bitcoin-engine-deploy/current/scripts/check_live_forecast_status.sh
/home/ubuntu/bitcoin-engine-deploy/current/scripts/check_live_forecast_status.sh || true
printf '[12/12] Done. Downloads: /home/ubuntu/bee_latest_export.zip and /home/ubuntu/bee_state_files.zip\n'
ls -lah /home/ubuntu/bee_latest_export.zip /home/ubuntu/bee_live_debug_export.zip /home/ubuntu/bee_state_files.zip || true
