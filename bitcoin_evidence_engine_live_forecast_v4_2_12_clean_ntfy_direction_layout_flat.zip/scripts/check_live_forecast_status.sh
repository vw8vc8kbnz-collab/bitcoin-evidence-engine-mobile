#!/usr/bin/env bash
set -euo pipefail
ROOT="/home/ubuntu/bitcoin-engine-deploy/current/live_forecast"
printf 'BEE live forecast status check\n'
printf 'Root: %s\n' "$ROOT"
if [ ! -d "$ROOT" ]; then
  printf 'STATUS: ERROR - live_forecast folder not found\n'
  exit 1
fi
cd "$ROOT"
printf '\nVersion:\n'
if [ -x ../.venv/bin/python ]; then
  ../.venv/bin/python bee_live_forecast_v4_1_paper.py --version || true
else
  python3 bee_live_forecast_v4_1_paper.py --version || true
fi
printf '\nDaemon process:\n'
if pgrep -af "run_live_forecast_daemon.sh|bee_live_forecast_v4_1_paper.py --once" | grep -v grep; then
  printf 'DAEMON: active or run currently executing\n'
else
  printf 'DAEMON: not active\n'
  printf 'Start command:\n'
  printf 'cd /home/ubuntu/bitcoin-engine-deploy/current && nohup ./scripts/run_live_forecast_daemon.sh > /home/ubuntu/bee_live_daemon.out 2>&1 &\n'
fi
printf '\nState files:\n'
ls -lah state/bee_history.csv state/bee_status.json state/bee_signals.csv logs/bee_live.log 2>/dev/null || true
printf '\nLatest status summary:\n'
python3 - <<'PY' || true
from pathlib import Path
import json
p=Path('state/bee_status.json')
if not p.exists():
    print('No bee_status.json yet')
else:
    s=json.loads(p.read_text() or '{}')
    print('timestamp_utc:', s.get('timestamp_utc'))
    print('version:', s.get('version'))
    print('decision:', (s.get('decision') or {}).get('decision'))
    print('notify:', s.get('last_notify_status'), s.get('notify_skip_reason'))
    ex=s.get('execution_intelligence') or {}
    print('execution:', ex.get('session_label'), ex.get('range_regime'), ex.get('noise_risk'))
    sh=s.get('short_alpha') or {}
    print('short_alpha:', sh.get('decision'), sh.get('tier'), 'score=', sh.get('score'), 'quality=', sh.get('data_quality'), 'reason=', str(sh.get('reason',''))[:140])
PY
printf '\nExports:\n'
ls -lah /home/ubuntu/bee_latest_export.zip /home/ubuntu/bee_live_debug_export.zip /home/ubuntu/bee_state_files.zip /home/ubuntu/bee_live_daemon.out 2>/dev/null || true
