#!/usr/bin/env bash
set -Eeuo pipefail
export PYTHONDONTWRITEBYTECODE=1

VERSION="FIX660R8_PRELIVE_HARDENED"
STAGE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LEGACY_APP="${METOD_LEGACY_APP_DIR:-/opt/adzaagt/metod-pax}"
RELEASES_DIR="${METOD_RELEASES_DIR:-/opt/adzaagt/metod-pax-releases}"
CURRENT_LINK="${METOD_CURRENT_LINK:-/opt/adzaagt/metod-pax-current}"
STATE_DIR="${METOD_STATE_ROOT:-/var/lib/metod-pax}"
ENV_DIR="${METOD_ENV_DIR:-/etc/adzaagt/metod-pax}"
CREDS_FILE="${ADMIN_CREDENTIALS_FILE:-$ENV_DIR/admin_credentials.live.json}"
BACKUP_ROOT="${METOD_CONFIG_BACKUP_ROOT:-/var/backups/metod-pax}"
TS="$(date +%Y%m%d_%H%M%S)"
LOG="/tmp/METOD_PAX_FIX660R8_DEPLOY_${TS}.log"
CONFIG_BACKUP="$BACKUP_ROOT/${VERSION}_config_${TS}"
PREVIOUS_TARGET=""
SWITCHED=0
TOUCHED=0
SUCCESS=0
STATE_STAGE=""

info(){ echo "[$VERSION] $*"; }
fail(){ echo "[$VERSION] FOUT: $*" >&2; exit 1; }
safe_abs_path(){ [[ "$1" =~ ^/[A-Za-z0-9._/-]+$ ]] || fail "Onveilig absoluut pad: $1"; }

for value in "$LEGACY_APP" "$RELEASES_DIR" "$CURRENT_LINK" "$STATE_DIR" "$ENV_DIR" "$CREDS_FILE" "$BACKUP_ROOT"; do
  safe_abs_path "$value"
done

if [[ "$EUID" -ne 0 ]]; then
  # Do not rely on sudo -E: hardened sudo policies commonly ignore it. Forward
  # only the explicit deployment contract, as individual argv values (never as
  # shell source), so staging/production settings survive privilege elevation.
  SUDO_ENV=(
    "PYTHONDONTWRITEBYTECODE=1"
    "METOD_LEGACY_APP_DIR=$LEGACY_APP"
    "METOD_RELEASES_DIR=$RELEASES_DIR"
    "METOD_CURRENT_LINK=$CURRENT_LINK"
    "METOD_STATE_ROOT=$STATE_DIR"
    "METOD_ENV_DIR=$ENV_DIR"
    "ADMIN_CREDENTIALS_FILE=$CREDS_FILE"
    "METOD_CONFIG_BACKUP_ROOT=$BACKUP_ROOT"
  )
  for name in METOD_DEPLOY_MODE PUBLIC_ORIGIN METOD_DOMAIN TLS_CERT_FILE TLS_KEY_FILE \
              OFFSITE_BACKUP_VERIFIED OFFSITE_BACKUP_PROVIDER PRODUCTION_MIN_CATALOG_RECORDS \
              STAGING_PUBLIC_PORT STAGING_BIND_ADDRESS STAGING_ALLOWED_CIDR \
              HTTP_MAX_CONCURRENT MAX_SSE_CLIENTS PUBLIC_JOB_MAX_CONCURRENT \
              PUBLIC_JOB_MAX_QUEUED PUBLIC_JOB_MAX_CONCURRENT_PER_IP \
              OPTIMIZER_TIMEOUT_SECONDS OPTIMIZER_JOB_TIMEOUT_SECONDS \
              MIN_FREE_STATE_BYTES MIN_FREE_STATE_INODES \
              METOD_MEMORY_MAX METOD_TASKS_MAX METOD_NOFILE_MAX NTFY_ALLOWED_HOSTS \
              METOD_RELEASE_KEEP METOD_RELEASE_MAX_AGE_DAYS METOD_RELEASE_MAX_BYTES \
              METOD_CONFIG_BACKUP_KEEP METOD_CONFIG_BACKUP_MAX_AGE_DAYS \
              METOD_CONFIG_BACKUP_MAX_BYTES; do
    if [[ -v "$name" ]]; then SUDO_ENV+=("$name=${!name}"); fi
  done
  exec sudo env "${SUDO_ENV[@]}" bash "$0" "$@"
fi

# Serialize the complete root-side installer.  /run is root-owned and local to
# the boot, and the open descriptor deliberately remains alive until this shell
# exits so validation, pointer changes, rollback and history pruning share one
# deploy transaction boundary.
DEPLOY_LOCK_PATH="/run/metod-pax-deploy.lock"
[[ -d /run && ! -L /run ]] || fail "Canonieke deploy-lockroot /run ontbreekt of is een symlink"
command -v flock >/dev/null || fail "Ontbrekend commando: flock"
DEPLOY_LOCK_UMASK="$(umask)"
umask 077
exec {DEPLOY_LOCK_FD}>"$DEPLOY_LOCK_PATH"
umask "$DEPLOY_LOCK_UMASK"
[[ -f "$DEPLOY_LOCK_PATH" && ! -L "$DEPLOY_LOCK_PATH" ]] || fail "Deploy-lock is geen veilig regulier bestand"
[[ "$(stat -c '%u:%g:%h' "$DEPLOY_LOCK_PATH")" == "0:0:1" ]] || fail "Deploy-lock moet root-owned en enkelvoudig gelinkt zijn"
chmod 0600 "$DEPLOY_LOCK_PATH"
flock -n "$DEPLOY_LOCK_FD" || fail "Een andere METOD/PAX-installatie of deploy is al actief"
info "Exclusieve deploy-lock verkregen."

python3 - "$LEGACY_APP" "$RELEASES_DIR" "$CURRENT_LINK" "$STATE_DIR" "$ENV_DIR" "$CREDS_FILE" "$BACKUP_ROOT" <<'PY'
import itertools,os,sys
from pathlib import Path
raw=sys.argv[1:]
for value in raw:
    if not value.startswith('/') or value.startswith('//') or value != os.path.normpath(value):
        raise SystemExit(f'deploypad moet een canoniek absoluut pad zijn: {value}')
    if any(part in ('','.','..') for part in value.split('/')[1:]):
        raise SystemExit(f'deploypad bevat een verboden segment: {value}')
legacy,releases,current,state,env,creds,backups=map(Path,raw)
def below(path, root):
    try: path.relative_to(root); return path != root
    except ValueError: return False
def reject_symlink_components(path, *, include_leaf=True):
    parts=path.parts[1:] if include_leaf else path.parts[1:-1]
    cursor=Path('/')
    for part in parts:
        cursor /= part
        if cursor.is_symlink():
            raise SystemExit(f'symlinkcomponent is verboden in deploypad: {cursor}')
if not all(below(path,Path('/opt/adzaagt')) for path in (legacy,releases,current)):
    raise SystemExit('code/releasepaden moeten onder /opt/adzaagt liggen')
if not (below(state,Path('/var/lib')) or below(state,Path('/srv'))):
    raise SystemExit('statepad moet onder /var/lib of /srv liggen')
if not below(env,Path('/etc/adzaagt')) or creds.parent != env:
    raise SystemExit('env/credentialpaden moeten onder dezelfde /etc/adzaagt-map liggen')
if not (below(backups,Path('/var/backups')) or below(backups,Path('/srv'))):
    raise SystemExit('configbackup moet onder /var/backups of /srv liggen')
paths=[legacy,releases,current,state,env,creds,backups]
if len({str(path) for path in paths}) != len(paths):
    raise SystemExit('deploypaden moeten onderling verschillend zijn')
trees=[legacy,releases,current,state,env,backups]
for left,right in itertools.combinations(trees,2):
    if left in right.parents or right in left.parents:
        raise SystemExit(f'deploybomen mogen niet overlappen: {left} / {right}')
for path in (legacy,releases,state,env,creds,backups):
    reject_symlink_components(path)
reject_symlink_components(current,include_leaf=False)
PY

# Bind the immutable release id to the complete package, not only server_py.py.
# This prevents a rejected/contaminated package with the same backend source
# from being reused by a corrected packaging revision.
RELEASE_HASH="$(sha256sum "$STAGE/SHA256SUMS.txt" | awk '{print substr($1,1,12)}')"
RELEASE_ID="${VERSION}_${RELEASE_HASH}"
RELEASE_DIR="$RELEASES_DIR/$RELEASE_ID"

restore_config_path(){
  local live="$1" key
  key="$(printf '%s' "$live" | sha256sum | awk '{print $1}')"
  if [[ -e "$CONFIG_BACKUP/$key.present" || -L "$CONFIG_BACKUP/$key.present" ]]; then
    rm -rf -- "$live"
    cp -a --no-dereference "$CONFIG_BACKUP/$key.present" "$live"
  else
    rm -rf -- "$live"
  fi
}

rollback(){
  local rc=$?
  if [[ "$SUCCESS" -eq 1 ]]; then return 0; fi
  echo "[$VERSION] INSTALLATIE MISLUKT (code $rc). Log: $LOG" >&2
  if [[ -n "$STATE_STAGE" && "$STATE_STAGE" == "${STATE_DIR}.migrate."* && -d "$STATE_STAGE" ]]; then
    rm -rf -- "$STATE_STAGE"
  fi
  if [[ "$TOUCHED" -eq 1 ]]; then
    set +e
    if [[ "$SWITCHED" -eq 1 && -n "$PREVIOUS_TARGET" && -d "$PREVIOUS_TARGET" ]]; then
      ln -sfn "$PREVIOUS_TARGET" "$CURRENT_LINK.rollback"
      mv -Tf "$CURRENT_LINK.rollback" "$CURRENT_LINK"
    fi
    restore_config_path /etc/systemd/system/metod-pax.service
    restore_config_path /etc/adzaagt/metod-pax/metod-pax.env
    restore_config_path /etc/nginx/sites-available/metod-pax
    restore_config_path /etc/nginx/sites-enabled/metod-pax
    restore_config_path /etc/nginx/sites-available/metod-pax-8790
    restore_config_path /etc/nginx/sites-enabled/metod-pax-8790
    restore_config_path /etc/nginx/conf.d/metod-pax-limits.conf
    systemctl daemon-reload || true
    if nginx -t; then systemctl reload nginx || true; fi
    if [[ -f /etc/systemd/system/metod-pax.service ]]; then systemctl restart metod-pax.service || true; fi
    echo "[$VERSION] Releasepointer/config teruggezet; externe state is bewust nooit teruggedraaid." >&2
    set -e
  fi
  return "$rc"
}
trap rollback EXIT
exec > >(tee -a "$LOG") 2>&1

for cmd in python3 sha256sum rsync curl nginx systemctl tar flock; do command -v "$cmd" >/dev/null || fail "Ontbrekend commando: $cmd"; done
[[ -f "$CREDS_FILE" ]] || fail "Bestaande Admin credentials ontbreken: $CREDS_FILE"
[[ "$(stat -c '%a' "$CREDS_FILE")" == "600" ]] || fail "Admin credentials moeten mode 0600 hebben"

(cd "$STAGE" && sha256sum -c SHA256SUMS.txt)
python3 - "$STAGE" <<'PY'
from pathlib import Path
import json,sys
root=Path(sys.argv[1])
bad=[str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and ('__pycache__' in p.parts or p.suffix.lower() in {'.pyc','.bak'})]
if bad: raise SystemExit(f'Onschone staged release: {bad[:20]}')
lib=json.loads((root/'app/material_library.json').read_text(encoding='utf-8'))
if lib.get('source')!='CSV_CATALOG_ONLY' or lib.get('records')!=[]: raise SystemExit('Release seed must be empty CSV-only library')
print('Staged release contract OK')
PY
PYTHONDONTWRITEBYTECODE=1 python3 "$STAGE/tools/final_preflight.py" \
  --release "$STAGE" --verify-checksums

verify_legacy_r7(){
  systemctl is-active --quiet metod-pax.service || fail "Bestaande service is vóór deploy niet actief"
  curl -fsS http://127.0.0.1:8792/api/materials/library >/dev/null || fail "Bestaande backend is vóór deploy niet gezond"
  local -A EXPECTED_R7=(
    [server_py.py]="058b4692aa251ff1c4a92489d639da60027e28bd120a2ab362eec8c3a63f122f"
    [toolA.html]="aa29587f1c0bef4bde2831be646d8245eb060ebfdeb9f5ebf80385315799c310"
    [dxf_nesting_optimizer.py]="d1113f9fd35325f4dcb2199cce6f6102d51b4a0d55832558b06cb8cd574ec355"
    [toolA_grain_studio_renderer.js]="ca969d214e849257e7579325eaca5626f18ca42e63c11f4664ec8a3dcea9cd07"
    [toolA_grain_mobile_scale.js]="06dbb20fc93696b97eccdb0628085fb67717e1bb3c4e7c40011f72571afbae8e"
  )
  local file
  for file in "${!EXPECTED_R7[@]}"; do
    [[ "$(sha256sum "$LEGACY_APP/app/$file" | awk '{print $1}')" == "${EXPECTED_R7[$file]}" ]] || fail "Live baseline is niet exact FIX660R7: app/$file"
  done
  info "Exacte FIX660R7-baseline bevestigd."
}

if [[ -L "$CURRENT_LINK" ]]; then
  PREVIOUS_TARGET="$(readlink -f "$CURRENT_LINK")"
  if [[ "$PREVIOUS_TARGET" == "$LEGACY_APP" ]]; then
    [[ -d "$LEGACY_APP/app" ]] || fail "Legacy current-link mist app-map"
    verify_legacy_r7
  elif [[ "$PREVIOUS_TARGET" == "$RELEASES_DIR/"* ]]; then
    [[ -f "$PREVIOUS_TARGET/SHA256SUMS.txt" ]] || fail "Huidige immutable release mist checksummanifest"
    (cd "$PREVIOUS_TARGET" && sha256sum -c SHA256SUMS.txt >/dev/null) || fail "Huidige immutable release heeft gewijzigde bestanden"
    info "Huidige immutable release volledig geverifieerd."
  else
    fail "Current-link wijst niet naar legacy baseline of beheerde immutable release: $PREVIOUS_TARGET"
  fi
elif [[ -d "$LEGACY_APP/app" ]]; then
  PREVIOUS_TARGET="$LEGACY_APP"
  verify_legacy_r7
else
  fail "Geen bekende FIX660R7-baseline of immutable current release gevonden"
fi

install -d -o root -g root -m 0755 "$RELEASES_DIR" "$BACKUP_ROOT" "$CONFIG_BACKUP"
if [[ -e "$RELEASE_DIR" ]]; then
  [[ -f "$RELEASE_DIR/SHA256SUMS.txt" ]] || fail "Bestaande target release is incompleet"
  (cd "$RELEASE_DIR" && sha256sum -c SHA256SUMS.txt >/dev/null) || fail "Bestaande target release is gewijzigd"
else
  RELEASE_TMP="$RELEASES_DIR/.${RELEASE_ID}.stage.$$"
  [[ ! -e "$RELEASE_TMP" ]] || fail "Tijdelijke releasefolder bestaat al: $RELEASE_TMP"
  install -d -o root -g root -m 0755 "$RELEASE_TMP"
  rsync -a --delete "$STAGE/" "$RELEASE_TMP/"
  (cd "$RELEASE_TMP" && sha256sum -c SHA256SUMS.txt >/dev/null)
  find "$RELEASE_TMP" -type d -exec chmod 0555 {} +
  find "$RELEASE_TMP" -type f -exec chmod 0444 {} +
  chmod 0555 "$RELEASE_TMP/DEPLOY_FIX660.sh" "$RELEASE_TMP/INSTALL_FIX660R8_FROM_STAGE.sh" "$RELEASE_TMP"/tools/*.py
  mv "$RELEASE_TMP" "$RELEASE_DIR"
fi

for live in /etc/systemd/system/metod-pax.service /etc/adzaagt/metod-pax/metod-pax.env \
            /etc/nginx/sites-available/metod-pax /etc/nginx/sites-enabled/metod-pax \
            /etc/nginx/sites-available/metod-pax-8790 /etc/nginx/sites-enabled/metod-pax-8790 \
            /etc/nginx/conf.d/metod-pax-limits.conf; do
  key="$(printf '%s' "$live" | sha256sum | awk '{print $1}')"
  if [[ -e "$live" || -L "$live" ]]; then cp -a --no-dereference "$live" "$CONFIG_BACKUP/$key.present"; fi
done
info "Configbackup: $CONFIG_BACKUP"
TOUCHED=1

# Drain the public edge before state migration/switch. The new backend is fully
# smoke-tested behind this maintenance response; only the final nginx reload
# reopens traffic. This makes a pointer rollback unable to lose deploy-window data.
if [[ "${METOD_DEPLOY_MODE:-staging}" == "production" ]]; then
  [[ -n "${METOD_DOMAIN:-}" ]] || fail "METOD_DOMAIN ontbreekt voor production maintenance"
  python3 - "${METOD_DOMAIN}" <<'PY'
import re,sys
if not re.fullmatch(r'(?=.{4,253}\Z)(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.)+[A-Za-z]{2,63}',sys.argv[1]):
    raise SystemExit('METOD_DOMAIN is ongeldig')
PY
  MAINT_CERT="${TLS_CERT_FILE:-/etc/letsencrypt/live/${METOD_DOMAIN}/fullchain.pem}"
  MAINT_KEY="${TLS_KEY_FILE:-/etc/letsencrypt/live/${METOD_DOMAIN}/privkey.pem}"
  [[ "$MAINT_CERT" =~ ^/[A-Za-z0-9._/-]+$ && "$MAINT_KEY" =~ ^/[A-Za-z0-9._/-]+$ ]] || fail "TLS-paden hebben een onveilig formaat"
  [[ -r "$MAINT_CERT" && -r "$MAINT_KEY" ]] || fail "TLS-bestanden ontbreken voor maintenance"
  MAINT_SITE_TMP="/etc/nginx/sites-available/.metod-pax.maintenance.$$"
  cat > "$MAINT_SITE_TMP" <<EOF
server { listen 80; listen [::]:80; server_name ${METOD_DOMAIN}; return 503; }
server {
  listen 443 ssl; listen [::]:443 ssl; server_name ${METOD_DOMAIN};
  ssl_certificate $MAINT_CERT; ssl_certificate_key $MAINT_KEY;
  add_header Retry-After 120 always; return 503;
}
EOF
  chmod 0644 "$MAINT_SITE_TMP"
  mv -f "$MAINT_SITE_TMP" /etc/nginx/sites-available/metod-pax
else
  STAGING_PORT_VALUE="${STAGING_PUBLIC_PORT:-8790}"
  STAGING_BIND_VALUE="${STAGING_BIND_ADDRESS:-127.0.0.1}"
  STAGING_CIDR_VALUE="${STAGING_ALLOWED_CIDR:-}"
  python3 - "$STAGING_PORT_VALUE" "$STAGING_BIND_VALUE" "$STAGING_CIDR_VALUE" <<'PY'
import ipaddress,sys
port=int(sys.argv[1])
if not 1024 <= port <= 65535: raise SystemExit('ongeldige stagingpoort')
bind=ipaddress.ip_address(sys.argv[2])
if bind.version != 4: raise SystemExit('staging bind moet IPv4 zijn')
if not bind.is_loopback and not sys.argv[3]: raise SystemExit('remote staging vereist STAGING_ALLOWED_CIDR')
if sys.argv[3]: ipaddress.ip_network(sys.argv[3],strict=False)
PY
  MAINT_SITE_TMP="/etc/nginx/sites-available/.metod-pax.maintenance.$$"
  {
    echo 'server {'
    echo "  listen $STAGING_BIND_VALUE:$STAGING_PORT_VALUE; server_name _;"
    if [[ -n "$STAGING_CIDR_VALUE" ]]; then
      echo "  allow $STAGING_CIDR_VALUE;"
      echo '  deny all;'
    fi
    echo '  add_header Retry-After 120 always; add_header X-METOD-Environment staging-maintenance always; return 503;'
    echo '}'
  } > "$MAINT_SITE_TMP"
  chmod 0644 "$MAINT_SITE_TMP"
  mv -f "$MAINT_SITE_TMP" /etc/nginx/sites-available/metod-pax
fi
rm -f /etc/nginx/sites-enabled/metod-pax-8790
ln -sfn /etc/nginx/sites-available/metod-pax /etc/nginx/sites-enabled/metod-pax
nginx -t
systemctl reload nginx
systemctl stop metod-pax.service || true

id -u metod-pax >/dev/null 2>&1 || useradd --system --home-dir "$STATE_DIR" --shell /usr/sbin/nologin metod-pax
install -d -o metod-pax -g metod-pax -m 0750 "$STATE_DIR"
STATE_MARKER="$STATE_DIR/.fix660r8_external_state_v1.json"
if [[ ! -f "$STATE_MARKER" ]]; then
  if find "$STATE_DIR" -mindepth 1 -maxdepth 1 -print -quit | grep -q .; then
    fail "$STATE_DIR bevat al data maar mist de R8-migratiemarkering; handmatige beoordeling nodig"
  fi
  STATE_STAGE="${STATE_DIR}.migrate.${TS}.$$"
  [[ ! -e "$STATE_STAGE" ]] || fail "Tijdelijke state-migratiemap bestaat al: $STATE_STAGE"
  install -d -o metod-pax -g metod-pax -m 0750 "$STATE_STAGE"
  for dir in jobs drafts index requests queue archive system backups decor_media embedded_dxfs config; do
    if [[ -d "$LEGACY_APP/app/$dir" ]]; then
      install -d -m 0750 "$STATE_STAGE/$dir"
      rsync -a "$LEGACY_APP/app/$dir/" "$STATE_STAGE/$dir/"
    fi
  done
  if [[ -d "$LEGACY_APP/app/_client_logs" ]]; then
    install -d -m 0750 "$STATE_STAGE/client_logs"
    rsync -a "$LEGACY_APP/app/_client_logs/" "$STATE_STAGE/client_logs/"
  fi
  for file in material_library.json embedded_dxfs_manifest.json config_notify.json; do
    [[ -f "$LEGACY_APP/app/$file" ]] && cp -a "$LEGACY_APP/app/$file" "$STATE_STAGE/$file"
  done
  [[ -d "$STATE_STAGE/embedded_dxfs" ]] || cp -a "$RELEASE_DIR/app/embedded_dxfs" "$STATE_STAGE/embedded_dxfs"
  [[ -f "$STATE_STAGE/embedded_dxfs_manifest.json" ]] || cp -a "$RELEASE_DIR/app/embedded_dxfs_manifest.json" "$STATE_STAGE/embedded_dxfs_manifest.json"
  [[ -f "$STATE_STAGE/config/pricing_active.json" ]] || { install -d -m 0750 "$STATE_STAGE/config"; cp -a "$RELEASE_DIR/app/config/pricing_active.json" "$STATE_STAGE/config/pricing_active.json"; }
  python3 - "$STATE_STAGE" <<'PY'
import os,stat,sys
from pathlib import Path
root=Path(sys.argv[1])
entries=0
stack=[root]
while stack:
    directory=stack.pop()
    with os.scandir(directory) as scan:
        for item in scan:
            entries += 1
            if entries > 1_000_000:
                raise SystemExit('state-migratie bevat te veel entries')
            mode=item.stat(follow_symlinks=False).st_mode
            if stat.S_ISLNK(mode):
                raise SystemExit(f'symlink in state-migratie is verboden: {item.path}')
            if stat.S_ISDIR(mode):
                stack.append(Path(item.path))
            elif not stat.S_ISREG(mode):
                raise SystemExit(f'speciaal bestand in state-migratie is verboden: {item.path}')
print(f'State-migratie bestandstypen OK: {entries} entries')
PY
  PYTHONPATH="$RELEASE_DIR/app" python3 -B - "$STATE_STAGE/.fix660r8_external_state_v1.json" "$LEGACY_APP" <<'PY'
import sys,time
from pathlib import Path
from safety_contracts import durable_write_json
durable_write_json(Path(sys.argv[1]), {'schemaVersion':1,'migratedAt':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'source':sys.argv[2]}, mode=0o640)
PY
  chown -R metod-pax:metod-pax "$STATE_STAGE"
  rmdir "$STATE_DIR"
  mv "$STATE_STAGE" "$STATE_DIR"
  python3 - "$STATE_DIR" <<'PY'
import os,sys
from pathlib import Path
root=Path(sys.argv[1])
fd=os.open(str(root.parent),os.O_RDONLY|getattr(os,'O_DIRECTORY',0))
try: os.fsync(fd)
finally: os.close(fd)
PY
fi
python3 - "$STATE_DIR" <<'PY'
import os,stat,sys
from pathlib import Path
root=Path(sys.argv[1])
entries=0
stack=[root]
while stack:
    directory=stack.pop()
    with os.scandir(directory) as scan:
        for item in scan:
            entries += 1
            if entries > 1_000_000:
                raise SystemExit('externe state bevat te veel entries')
            mode=item.stat(follow_symlinks=False).st_mode
            if stat.S_ISLNK(mode):
                raise SystemExit(f'symlink in externe state is verboden: {item.path}')
            if stat.S_ISDIR(mode):
                stack.append(Path(item.path))
            elif not stat.S_ISREG(mode):
                raise SystemExit(f'speciaal bestand in externe state is verboden: {item.path}')
print(f'Externe-state bestandstypen OK: {entries} entries')
PY
chown -R metod-pax:metod-pax "$STATE_DIR"
chmod 0750 "$STATE_DIR"

python3 - "$STATE_DIR/material_library.json" <<'PY'
import json,sys
p=sys.argv[1]; obj=json.load(open(p,encoding='utf-8')); records=obj.get('records') if isinstance(obj,dict) else None
active=[r for r in (records or []) if isinstance(r,dict) and r.get('active') is not False and r.get('published') is True and r.get('catalogMissing') is not True and r.get('catalogExcluded') is not True]
if not active: raise SystemExit('Actieve gepubliceerde catalogus is leeg; live switch geblokkeerd')
print(f'Catalogus vóór switch: {len(active)} actieve records')
PY

ln -sfn "$RELEASE_DIR" "$CURRENT_LINK.next"
mv -Tf "$CURRENT_LINK.next" "$CURRENT_LINK"
SWITCHED=1

INSTALL_CATALOG_MIN_DEFAULT=1
if [[ "${METOD_DEPLOY_MODE:-staging}" == "production" ]]; then
  INSTALL_CATALOG_MIN_DEFAULT=597
fi
env \
  METOD_CURRENT_LINK="$CURRENT_LINK" \
  METOD_STATE_ROOT="$STATE_DIR" \
  METOD_ENV_DIR="$ENV_DIR" \
  ADMIN_CREDENTIALS_FILE="$CREDS_FILE" \
  METOD_DEPLOY_MODE="${METOD_DEPLOY_MODE:-staging}" \
  PUBLIC_ORIGIN="${PUBLIC_ORIGIN:-http://127.0.0.1:8790}" \
  METOD_DOMAIN="${METOD_DOMAIN:-}" \
  TLS_CERT_FILE="${TLS_CERT_FILE:-}" \
  TLS_KEY_FILE="${TLS_KEY_FILE:-}" \
  OFFSITE_BACKUP_VERIFIED="${OFFSITE_BACKUP_VERIFIED:-0}" \
  OFFSITE_BACKUP_PROVIDER="${OFFSITE_BACKUP_PROVIDER:-}" \
  PRODUCTION_MIN_CATALOG_RECORDS="${PRODUCTION_MIN_CATALOG_RECORDS:-$INSTALL_CATALOG_MIN_DEFAULT}" \
  bash "$CURRENT_LINK/DEPLOY_FIX660.sh"

# DEPLOY_FIX660 only returns after the atomic nginx commit. From this point on,
# automated pointer rollback is forbidden because real requests may arrive.
SUCCESS=1
[[ "$(readlink -f "$CURRENT_LINK")" == "$RELEASE_DIR" ]] || fail "Releasepointer wijst niet naar target"
(cd "$CURRENT_LINK" && sha256sum -c SHA256SUMS.txt >/dev/null)
systemctl is-active --quiet metod-pax.service || fail "Service is na deploy niet actief"
nginx -t
rm -f /etc/nginx/sites-available/metod-pax-8790 /etc/nginx/sites-enabled/metod-pax-8790
if ! python3 -B "$CURRENT_LINK/tools/prune_deploy_history.py" \
    --releases-dir "$RELEASES_DIR" \
    --backup-root "$BACKUP_ROOT" \
    --current-link "$CURRENT_LINK" \
    --previous-target "$PREVIOUS_TARGET" \
    --current-config-backup "$CONFIG_BACKUP" \
    --version "$VERSION" \
    --release-keep "${METOD_RELEASE_KEEP:-3}" \
    --release-max-age-days "${METOD_RELEASE_MAX_AGE_DAYS:-180}" \
    --release-max-bytes "${METOD_RELEASE_MAX_BYTES:-2147483648}" \
    --config-keep "${METOD_CONFIG_BACKUP_KEEP:-10}" \
    --config-max-age-days "${METOD_CONFIG_BACKUP_MAX_AGE_DAYS:-180}" \
    --config-max-bytes "${METOD_CONFIG_BACKUP_MAX_BYTES:-536870912}"; then
  info "WAARSCHUWING: begrensde release/config-historycleanup faalde; actieve en vorige release zijn niet verwijderd."
fi
info "R8 release actief: $RELEASE_DIR"
info "Externe state behouden onder: $STATE_DIR"
info "Rollback verandert uitsluitend releasepointer/config, nooit live state."
info "Deploylog: $LOG"
