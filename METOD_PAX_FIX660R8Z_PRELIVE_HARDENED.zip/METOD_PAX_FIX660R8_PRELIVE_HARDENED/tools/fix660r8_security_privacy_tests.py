#!/usr/bin/env python3
from __future__ import annotations

"""Focused security/privacy contracts for FIX660R8.

These tests intentionally exercise route ownership and notification transport
without opening sockets or writing outside an isolated state root.
"""

import os
import socket
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest import mock


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
_STATE_TEMP = tempfile.TemporaryDirectory(prefix="fix660r8_security_privacy_")
os.environ["METOD_STATE_ROOT"] = str(Path(_STATE_TEMP.name) / "state")
os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")
sys.path.insert(0, str(APP))

import server_py as server  # noqa: E402


def fake_handler(path: str):
    handler = object.__new__(server.Handler)
    handler.path = path
    handler.client_address = ("127.0.0.1", 12345)
    handler.headers = {}
    handler.responses = []

    def send_json(self, payload, status=200, headers=None):
        self.responses.append((int(status), payload))
        return (int(status), payload)

    handler._send_json = types.MethodType(send_json, handler)
    return handler


class SecurityPrivacyContractTests(unittest.TestCase):
    def test_authorization_and_cookie_values_are_fully_redacted(self) -> None:
        source = (
            "Authorization: Bearer AUTH_SECRET_VALUE\n"
            "Proxy-Authorization: Basic PROXY_SECRET_VALUE\n"
            "Cookie: adzaagt_admin_session=COOKIE_SECRET_VALUE; theme=private\n"
            "Set-Cookie: adzaagt_admin_session=SET_COOKIE_SECRET; HttpOnly\n"
            "authorization=Bearer ASSIGN_SECRET_VALUE\n"
            "headers={'Authorization': 'Bearer DICT_AUTH_SECRET', "
            "'Cookie': 'session=DICT_COOKIE_SECRET; preference=private'}"
        )
        redacted = server._redact_sensitive_text(source, max_len=4000)
        for secret in (
            "AUTH_SECRET_VALUE",
            "PROXY_SECRET_VALUE",
            "COOKIE_SECRET_VALUE",
            "SET_COOKIE_SECRET",
            "ASSIGN_SECRET_VALUE",
            "DICT_AUTH_SECRET",
            "DICT_COOKIE_SECRET",
            "theme=private",
            "preference=private",
        ):
            self.assertNotIn(secret, redacted)
        self.assertIn("[redacted-secret]", redacted)

    def test_public_readiness_is_minimal_and_admin_readiness_is_detailed(self) -> None:
        detailed = {
            "ok": True,
            "build": server.SECURITY_BUILD,
            "checks": {"freeBytes": True, "catalogSignoff": True},
            "details": {"freeBytes": 123456789, "catalogSignoffActor": "private-admin"},
        }
        with mock.patch.object(server, "_readiness_report", return_value=(detailed, 200)):
            public = fake_handler("/health/ready")
            status, payload = server.Handler.do_GET(public)
            self.assertEqual(status, 200)
            self.assertEqual(payload, {"ok": True, "build": server.SECURITY_BUILD})
            self.assertNotIn("checks", payload)
            self.assertNotIn("details", payload)

            admin = fake_handler("/api/admin/health/ready")
            admin._require_admin_auth = types.MethodType(lambda self: True, admin)
            status, payload = server.Handler.do_GET(admin)
            self.assertEqual(status, 200)
            self.assertEqual(payload, detailed)

    def test_admin_request_update_get_is_405_and_post_keeps_origin_gate(self) -> None:
        get_handler = fake_handler("/api/admin/requests/update")
        get_handler._require_admin_auth = types.MethodType(lambda self: True, get_handler)
        with mock.patch.object(
            server,
            "api_admin_requests_update",
            side_effect=AssertionError("GET must never reach the mutator"),
        ):
            status, payload = server.Handler.do_GET(get_handler)
        self.assertEqual(status, 405)
        self.assertFalse(payload["ok"])

        denied = fake_handler("/api/admin/requests/update")
        denied._require_admin_auth = types.MethodType(lambda self: True, denied)
        denied._require_admin_write_origin = types.MethodType(lambda self: False, denied)
        with mock.patch.object(
            server,
            "api_admin_requests_update",
            side_effect=AssertionError("bad-origin POST must never reach the mutator"),
        ):
            self.assertIsNone(server.Handler._do_POST_impl(denied))

        allowed = fake_handler("/api/admin/requests/update")
        allowed._require_admin_auth = types.MethodType(lambda self: True, allowed)
        allowed._require_admin_write_origin = types.MethodType(lambda self: True, allowed)
        with mock.patch.object(server, "api_admin_requests_update", return_value="updated") as update:
            self.assertEqual(server.Handler._do_POST_impl(allowed), "updated")
        update.assert_called_once_with(allowed)

    def test_ntfy_rejects_redirect_without_forwarding_authorization(self) -> None:
        created = []

        class Response:
            status = 302

            def read(self, _amount=-1):
                return b""

        class Connection:
            def __init__(self, host, pinned_ip, timeout):
                self.host = host
                self.pinned_ip = pinned_ip
                self.timeout = timeout
                self.requests = []
                self.closed = False
                created.append(self)

            def request(self, method, target, body=None, headers=None):
                self.requests.append((method, target, body, dict(headers or {})))

            def getresponse(self):
                return Response()

            def close(self):
                self.closed = True

        config = {
            "ntfy": {
                "enabled": True,
                "topic_url": "https://ntfy.sh/metod-safe-topic",
                "authorization": "NTFY_AUTH_SECRET",
            }
        }
        dns = [(socket.AF_INET, socket.SOCK_STREAM, 6, "", ("93.184.216.34", 443))]
        with (
            mock.patch.object(server, "_load_notify_config", return_value=config),
            mock.patch.object(server.socket, "getaddrinfo", return_value=dns),
            mock.patch.object(server, "_catalog_pinned_https_connection", Connection),
            mock.patch.object(server, "_ntfy_log"),
        ):
            ok, error = server._ntfy_send(message="safe notification")
        self.assertFalse(ok)
        self.assertEqual(error, "redirect_forbidden")
        self.assertEqual(len(created), 1, "a redirect must never create a second connection")
        self.assertTrue(created[0].closed)
        self.assertEqual(created[0].host, "ntfy.sh")
        self.assertEqual(created[0].requests[0][3]["Authorization"], "Bearer NTFY_AUTH_SECRET")

    def test_ntfy_rejects_private_dns_before_connect(self) -> None:
        config = {"ntfy": {"enabled": True, "topic_url": "https://ntfy.sh/topic"}}
        private_dns = [(socket.AF_INET, socket.SOCK_STREAM, 6, "", ("127.0.0.1", 443))]
        with (
            mock.patch.object(server, "_load_notify_config", return_value=config),
            mock.patch.object(server.socket, "getaddrinfo", return_value=private_dns),
            mock.patch.object(server, "_catalog_pinned_https_connection") as connection,
        ):
            ok, error = server._ntfy_send(message="must not leave")
        self.assertFalse(ok)
        self.assertEqual(error, "ntfy endpoint is invalid")
        connection.assert_not_called()

    def test_tool_a_client_log_uses_canonical_job_bearer_helper(self) -> None:
        source = (APP / "toolA.html").read_text(encoding="utf-8", errors="strict")
        start = source.index("const LOG_ENDPOINT = '/api/client_log';")
        end = source.index("window.__metod_log = enqueue;", start)
        logger = source[start:end]
        self.assertIn("buildJobTokenHeaders()", logger)
        self.assertIn("Object.assign({'Content-Type':'application/json'}, jobHeaders)", logger)
        self.assertIn("resp.status === 403", logger)

    def test_application_hsts_never_enables_all_subdomains(self) -> None:
        source = (APP / "server_py.py").read_text(encoding="utf-8", errors="strict")
        self.assertIn(
            "self.send_header('Strict-Transport-Security', 'max-age=31536000')",
            source,
        )
        self.assertNotIn("max-age=31536000; includeSubDomains", source)


if __name__ == "__main__":
    unittest.main(verbosity=2)
