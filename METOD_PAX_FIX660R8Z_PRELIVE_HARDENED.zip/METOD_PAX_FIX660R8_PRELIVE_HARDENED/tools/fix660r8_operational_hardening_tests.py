#!/usr/bin/env python3
from __future__ import annotations

"""Focused retention/archive/backup contracts; no optimizer algorithm coverage."""

import importlib
import inspect
import json
import os
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace
from unittest import mock


RELEASE_ROOT = Path(__file__).resolve().parents[1]
APP_ROOT = RELEASE_ROOT / 'app'


class OperationalHardeningTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.holder = tempfile.TemporaryDirectory(prefix='fix660r8_operations_')
        cls.old_state = os.environ.get('METOD_STATE_ROOT')
        os.environ['METOD_STATE_ROOT'] = str(Path(cls.holder.name) / 'state')
        sys.path.insert(0, str(APP_ROOT))
        cls.server = importlib.import_module('server_py')
        cls.server._initialize_external_state()

    @classmethod
    def tearDownClass(cls) -> None:
        if cls.old_state is None:
            os.environ.pop('METOD_STATE_ROOT', None)
        else:
            os.environ['METOD_STATE_ROOT'] = cls.old_state
        try:
            sys.path.remove(str(APP_ROOT))
        except ValueError:
            pass
        cls.holder.cleanup()

    def setUp(self) -> None:
        s = self.server
        for root in (
            s.JOBS, s.REQUESTS, s.ARCHIVE_ROOT, s.QUEUE_DIR,
            s.SUBMISSION_IDEMPOTENCY_DIR, s.CATALOG_IMPORT_ROOT,
            s.DECOR_MEDIA_ROOT, s.BACKUPS_DIR,
        ):
            shutil.rmtree(root, ignore_errors=True)
        s._ensure_request_dirs()
        s._ensure_archive_dirs()
        s._ensure_system_dirs()
        s.JOBS.mkdir(parents=True, exist_ok=True)
        s.DECOR_MEDIA_ROOT.mkdir(parents=True, exist_ok=True)
        s.durable_write_json(s.MATERIAL_LIBRARY_PATH, {
            'source': 'CSV_CATALOG_ONLY', 'records': [],
        })
        s._LAST_RETENTION_RUN_TS = 0.0
        s._LAST_QUEUE_MAINTENANCE_TS = 0.0
        with s._CATALOG_IMAGE_SYNC_LOCK:
            self.assertEqual(s._CATALOG_IMAGE_SYNC_ACTIVE, set())
        with s._JOB_STORAGE_RESERVATION_LOCK:
            self.assertEqual(s._JOB_STORAGE_RESERVATIONS, {})
        self._old_env = dict(os.environ)

    def tearDown(self) -> None:
        os.environ.clear()
        os.environ.update(self._old_env)

    def _request_family(self, suffix: str) -> tuple[str, str, str]:
        s = self.server
        rid = f'20260813_120000_{suffix}'
        parent = f'job_{suffix}_parent'
        subjob = f'job_{suffix}_sub'
        request_root = s.REQUESTS / rid
        request_root.mkdir(parents=True)
        s.durable_write_json(request_root / 'status.json', {
            'requestId': rid,
            'createdAt': '2026-01-01T00:00:00Z',
            'updatedAt': '2026-01-01T00:00:00Z',
            'customer': {'name': 'Private Name', 'email': 'private@example.invalid'},
            'job': {'parentJobId': parent, 'subjobs': [{'subjobId': subjob}]},
        })
        for job_id in (parent, subjob):
            (s.JOBS / job_id / 'output').mkdir(parents=True)
            s.durable_write_json(s.JOBS / job_id / 'output' / 'meta_status.json', {'status': 'DONE'})
        marker = s._submission_marker_path(parent)
        s.durable_write_json(marker, {'parentJobId': parent, 'requestId': rid})
        return rid, parent, subjob

    def test_archive_family_and_claim_commit_together(self) -> None:
        s = self.server
        rid, parent, subjob = self._request_family('commit01')
        # Force the collision-safe destination path.
        (s.ARCHIVE_REQUESTS / rid).mkdir(parents=True)
        result = s._archive_request_and_linked_jobs(rid)
        self.assertTrue(result['ok'], result)
        self.assertFalse((s.REQUESTS / rid).exists())
        self.assertFalse((s.JOBS / parent).exists())
        self.assertFalse((s.JOBS / subjob).exists())
        self.assertFalse(s._submission_marker_path(parent).exists())
        archived_request = s.ARCHIVE_REQUESTS / result['archivedRequestDir']
        self.assertTrue((archived_request / s.ARCHIVE_META_NAME).is_file())
        self.assertTrue((archived_request / '.submission_idempotency.json').is_file())
        self.assertTrue(result['queueMirrorsBestEffort'])

    def test_required_metadata_failure_rolls_every_move_back(self) -> None:
        s = self.server
        rid, parent, subjob = self._request_family('rollback01')
        original = s._write_archive_meta
        calls = {'count': 0}

        def fail_second(*args, **kwargs):
            calls['count'] += 1
            original(*args, **kwargs)
            if calls['count'] == 2:
                raise OSError('injected metadata failure')

        with mock.patch.object(s, '_write_archive_meta', side_effect=fail_second):
            result = s._archive_request_and_linked_jobs(rid)
        self.assertFalse(result['ok'])
        self.assertEqual(result['rollbackErrors'], [])
        self.assertTrue((s.REQUESTS / rid / 'status.json').is_file())
        self.assertTrue((s.JOBS / parent).is_dir())
        self.assertTrue((s.JOBS / subjob).is_dir())
        self.assertTrue(s._submission_marker_path(parent).is_file())
        self.assertFalse(any(path.name.startswith(parent) for path in s.ARCHIVE_JOBS.iterdir()))

    def test_committed_archive_is_not_rolled_back_when_journal_cleanup_fails(self) -> None:
        s = self.server
        rid, parent, subjob = self._request_family('commitcleanup01')
        real_unlink = Path.unlink

        def fail_transaction_unlink(path: Path, *args, **kwargs):
            if path.parent == s.ARCHIVE_TRANSACTIONS:
                raise OSError('injected committed journal cleanup failure')
            return real_unlink(path, *args, **kwargs)

        with mock.patch.object(Path, 'unlink', autospec=True, side_effect=fail_transaction_unlink):
            result = s._archive_request_and_linked_jobs(rid)
        self.assertTrue(result['ok'], result)
        self.assertTrue(result['commitWarnings'], result)
        self.assertFalse((s.REQUESTS / rid).exists())
        self.assertFalse((s.JOBS / parent).exists())
        self.assertFalse((s.JOBS / subjob).exists())
        journals = list(s.ARCHIVE_TRANSACTIONS.glob('archive_*.json'))
        self.assertEqual(len(journals), 1)
        self.assertEqual(s.strict_json_load(journals[0])['state'], 'COMMITTED')
        recovered = s._reconcile_archive_transactions()
        self.assertEqual(recovered, {'recovered': 1, 'errors': []})
        self.assertFalse(journals[0].exists())

    def test_missing_linked_job_is_degraded_but_retained_in_archive_meta(self) -> None:
        s = self.server
        rid, parent, subjob = self._request_family('missing01')
        shutil.rmtree(s.JOBS / subjob)
        result = s._archive_request_and_linked_jobs(rid)
        self.assertTrue(result['ok'], result)
        self.assertEqual(result['missingJobs'], [subjob])
        self.assertTrue(result['degradedArchive'])
        archived_request = s.ARCHIVE_REQUESTS / result['archivedRequestDir']
        meta = s.strict_json_load(archived_request / s.ARCHIVE_META_NAME)
        self.assertEqual(meta['missingJobs'], [subjob])
        self.assertTrue(meta['degradedArchive'])
        self.assertTrue((s.ARCHIVE_JOBS / parent).is_dir())

    def test_prepared_archive_journal_rolls_forward_after_process_loss(self) -> None:
        s = self.server
        rid, parent, subjob = self._request_family('recover01')
        request_destination = s.ARCHIVE_REQUESTS / rid
        parent_destination = s.ARCHIVE_JOBS / parent
        subjob_destination = s.ARCHIVE_JOBS / subjob
        claim_source = s._submission_marker_path(parent)
        claim_destination = request_destination / '.submission_idempotency.json'
        os.replace(s.JOBS / parent, parent_destination)
        transaction_id = 'archive_' + 'a' * 32
        journal_path = s._archive_journal_path(transaction_id)
        s._archive_journal_write(journal_path, {
            'schemaVersion': 1,
            'transactionId': transaction_id,
            'state': 'PREPARED',
            'requestId': rid,
            'archivedAt': '2026-08-13T12:00:00Z',
            'activeCreatedAt': '2026-01-01T00:00:00Z',
            'createdAt': '2026-08-13T12:00:00Z',
            'retentionReason': 'terminal-age',
            'missingJobs': [],
            'moves': [
                {'kind': 'job', 'id': parent, 'source': str(s.JOBS / parent), 'destination': str(parent_destination)},
                {'kind': 'job', 'id': subjob, 'source': str(s.JOBS / subjob), 'destination': str(subjob_destination)},
                {'kind': 'request', 'id': rid, 'source': str(s.REQUESTS / rid), 'destination': str(request_destination)},
                {'kind': 'claim', 'id': parent, 'source': str(claim_source), 'destination': str(claim_destination)},
            ],
        })
        recovered = s._reconcile_archive_transactions()
        self.assertEqual(recovered['recovered'], 1, recovered)
        self.assertEqual(recovered['errors'], [])
        self.assertFalse(journal_path.exists())
        self.assertTrue((request_destination / s.ARCHIVE_META_NAME).is_file())
        self.assertTrue((parent_destination / s.ARCHIVE_META_NAME).is_file())
        self.assertTrue((subjob_destination / s.ARCHIVE_META_NAME).is_file())
        self.assertTrue(claim_destination.is_file())
        self.assertFalse(claim_source.exists())
        self.assertFalse((s.REQUESTS / rid).exists())

    def test_forged_archive_journals_cannot_escape_or_mismatch_identity(self) -> None:
        s = self.server
        rid, parent, _subjob = self._request_family('forged01')
        transaction_id = 'archive_' + 'b' * 32
        journal_path = s._archive_journal_path(transaction_id)
        request_destination = s.ARCHIVE_REQUESTS / rid
        valid = {
            'schemaVersion': 1,
            'transactionId': transaction_id,
            'state': 'PREPARED',
            'requestId': rid,
            'archivedAt': '2026-08-13T12:00:00Z',
            'activeCreatedAt': '2026-01-01T00:00:00Z',
            'createdAt': '2026-08-13T12:00:00Z',
            'updatedAt': '2026-08-13T12:00:01Z',
            'retentionReason': 'terminal-age',
            'missingJobs': [],
            'moves': [
                {
                    'kind': 'request', 'id': rid,
                    'source': str(s.REQUESTS / rid),
                    'destination': str(request_destination),
                },
                {
                    'kind': 'claim', 'id': parent,
                    'source': str(s._submission_marker_path(parent)),
                    'destination': str(request_destination / '.submission_idempotency.json'),
                },
            ],
        }
        cases: list[tuple[str, dict, Path]] = []
        wrong_schema = json.loads(json.dumps(valid))
        wrong_schema['schemaVersion'] = 2
        cases.append(('schema', wrong_schema, journal_path))
        wrong_transaction = json.loads(json.dumps(valid))
        wrong_transaction['transactionId'] = 'archive_' + 'c' * 32
        cases.append(('transaction', wrong_transaction, journal_path))
        wrong_request = json.loads(json.dumps(valid))
        wrong_request['requestId'] = rid + '_other'
        cases.append(('request', wrong_request, journal_path))
        nested_claim = json.loads(json.dumps(valid))
        nested_claim['moves'][1]['destination'] = str(
            request_destination / 'nested' / '.submission_idempotency.json'
        )
        cases.append(('nested claim', nested_claim, journal_path))
        forged_claim = json.loads(json.dumps(valid))
        forged_claim['moves'][1]['source'] = str(s.SUBMISSION_IDEMPOTENCY_DIR / 'forged.json')
        cases.append(('claim identity', forged_claim, journal_path))
        escaped_request = json.loads(json.dumps(valid))
        escaped_request['moves'][0]['destination'] = str(s.ARCHIVE_ROOT / 'escaped-request')
        cases.append(('escaped request', escaped_request, journal_path))

        for label, forged, path in cases:
            with self.subTest(label=label):
                with self.assertRaisesRegex(RuntimeError, 'archive journal'):
                    s._complete_archive_journal(path, forged)
                self.assertTrue((s.REQUESTS / rid / 'status.json').is_file())
                self.assertTrue(s._submission_marker_path(parent).is_file())
                self.assertFalse(request_destination.exists())

    def test_server_and_worker_reconcile_archive_journal_before_serving(self) -> None:
        s = self.server
        main_source = inspect.getsource(s.main)
        self.assertLess(
            main_source.index('_reconcile_archive_transactions()'),
            main_source.index('BoundedThreadingHTTPServer'),
        )
        module_source = Path(s.__file__).read_text(encoding='utf-8')
        worker_source = module_source[module_source.index("if '--worker' in sys.argv:"):]
        self.assertLess(
            worker_source.index('_reconcile_archive_transactions()'),
            worker_source.index('worker_loop()'),
        )
        self.assertGreaterEqual(module_source.count("raise SystemExit(2)"), 2)

    def test_retention_uses_terminal_age_and_open_hard_limit(self) -> None:
        s = self.server
        now = datetime(2026, 8, 13, tzinfo=timezone.utc).replace(tzinfo=None)
        terminal_rid, _parent, _subjob = self._request_family('terminal90')
        terminal = s._load_status(terminal_rid)
        terminal.update({
            'createdAt': (now - timedelta(days=s.RETENTION_ACTIVE_DAYS + 1)).isoformat() + 'Z',
            'publicStatus': 'DONE', 'internalStatus': 'DONE', 'quoteStatus': 'DONE',
        })
        s.durable_write_json(s.REQUESTS / terminal_rid / 'status.json', terminal)

        open_rid, _parent2, _subjob2 = self._request_family('open090')
        open_status = s._load_status(open_rid)
        open_status.update({
            'createdAt': (now - timedelta(days=s.RETENTION_ACTIVE_DAYS + 1)).isoformat() + 'Z',
            'publicStatus': 'SUBMITTED', 'internalStatus': 'DONE', 'quoteStatus': 'TODO',
        })
        s.durable_write_json(s.REQUESTS / open_rid / 'status.json', open_status)

        hard_rid, _parent3, _subjob3 = self._request_family('open365')
        hard_status = s._load_status(hard_rid)
        hard_status.update({
            'createdAt': (now - timedelta(days=s.RETENTION_OPEN_REQUEST_MAX_DAYS + 1)).isoformat() + 'Z',
            'publicStatus': 'SUBMITTED', 'internalStatus': 'DONE', 'quoteStatus': 'TODO',
        })
        s.durable_write_json(s.REQUESTS / hard_rid / 'status.json', hard_status)

        result = s._archive_expired_active_data(now)
        self.assertEqual(result['requests'], 2, result)
        self.assertFalse((s.REQUESTS / terminal_rid).exists())
        self.assertTrue((s.REQUESTS / open_rid).is_dir())
        self.assertFalse((s.REQUESTS / hard_rid).exists())
        hard_archive = next(path for path in s.ARCHIVE_REQUESTS.iterdir() if path.name.startswith(hard_rid))
        hard_meta = s.strict_json_load(hard_archive / s.ARCHIVE_META_NAME)
        self.assertEqual(hard_meta['retentionReason'], 'open-hard-limit')

    def test_request_index_compaction_removes_pii_and_rotations(self) -> None:
        s = self.server
        rid, parent, _subjob = self._request_family('index001')
        s.REQUESTS_INDEX.write_text(json.dumps({
            'requestId': rid, 'customerName': 'Private Name', 'email': 'private@example.invalid',
        }) + '\n', encoding='utf-8')
        rotation = s.REQUESTS_INDEX.parent / f'{s.REQUESTS_INDEX.name}.1'
        rotation.write_text('Private Name\n', encoding='utf-8')
        result = s._compact_requests_index()
        text = s.REQUESTS_INDEX.read_text(encoding='utf-8')
        self.assertEqual(result['rows'], 1)
        self.assertNotIn('customerName', text)
        self.assertNotIn('Private Name', text)
        self.assertNotIn('private@example.invalid', text)
        self.assertIn(parent, text)
        self.assertFalse(rotation.exists())

    def test_operational_cleanup_preserves_active_catalog_and_request(self) -> None:
        s = self.server
        now = datetime.now(timezone.utc).replace(tzinfo=None)
        old = time.time() - 4 * 86400
        active_import = 'cat_' + ('a' * 24)
        stale_import = 'cat_' + ('b' * 24)
        active_public = 'decor_' + ('1' * 20)
        orphan_public = 'decor_' + ('2' * 20)
        s.durable_write_json(s.MATERIAL_LIBRARY_PATH, {
            'source': 'CSV_CATALOG_ONLY',
            'lastCatalogImport': {'importId': active_import},
            'records': [{
                'publicMaterialId': active_public, 'active': True,
                'published': True, 'archived': False,
            }],
        })
        for import_id in (active_import, stale_import):
            for path in (
                s.CATALOG_IMPORT_ROOT / f'{import_id}.json',
                s.CATALOG_IMPORT_ROOT / f'{import_id}_images.json',
            ):
                path.write_text('{}\n', encoding='utf-8')
                os.utime(path, (old, old))
            media = s.CATALOG_IMPORT_ROOT / f'{import_id}_media'
            media.mkdir()
            os.utime(media, (old, old))
        recent_history = s.CATALOG_IMPORT_HISTORY / 'recent'
        stale_history = s.CATALOG_IMPORT_HISTORY / 'stale'
        recent_history.mkdir(parents=True)
        stale_history.mkdir()
        os.utime(stale_history, (old, old))
        for public_id in (active_public, orphan_public):
            media = s.DECOR_MEDIA_ROOT / public_id
            media.mkdir()
            os.utime(media, (old, old))
        active_request = '20260813_120000_active01'
        (s.REQUESTS / active_request).mkdir()
        (s.REQUESTS / active_request / 'status.json').write_text('{}\n', encoding='utf-8')
        active_queue = s.QUEUE_DONE / f'{active_request}.json'
        active_queue.write_text(json.dumps({'requestId': active_request}), encoding='utf-8')
        orphan_queue = s.QUEUE_FAILED / 'orphan.json'
        orphan_queue.write_text(json.dumps({'requestId': '20260813_120000_missing1'}), encoding='utf-8')
        active_claim = s.SUBMISSION_IDEMPOTENCY_DIR / ('a' * 64 + '.json')
        active_claim.write_text(json.dumps({'requestId': active_request}), encoding='utf-8')
        orphan_claim = s.SUBMISSION_IDEMPOTENCY_DIR / ('b' * 64 + '.json')
        orphan_claim.write_text(json.dumps({'requestId': '20260813_120000_missing1'}), encoding='utf-8')
        stale_draft = s.DRAFTS / 'legacy_draft.json'
        stale_draft.parent.mkdir(parents=True, exist_ok=True)
        stale_draft.write_text('{}\n', encoding='utf-8')
        rotated_log = s.SYSTEM_DIR / 'system_events.jsonl.1'
        rotated_log.write_text('{}\n', encoding='utf-8')
        for path in (active_queue, orphan_queue, active_claim, orphan_claim, stale_draft, rotated_log):
            os.utime(path, (old, old))
        os.environ.update({
            'CATALOG_STAGE_RETENTION_DAYS': '1',
            'CATALOG_HISTORY_RETENTION_DAYS': '1',
            'CATALOG_HISTORY_KEEP': '1',
            'ORPHAN_DECOR_MEDIA_RETENTION_DAYS': '1',
            'ORPHAN_QUEUE_RETENTION_DAYS': '1',
            'ORPHAN_SUBMISSION_CLAIM_RETENTION_DAYS': '1',
            'ORPHAN_DRAFT_RETENTION_DAYS': '1',
            'ROTATED_LOG_RETENTION_DAYS': '1',
        })
        result = s._cleanup_operational_state(now)
        self.assertEqual(result['errors'], [])
        self.assertTrue((s.CATALOG_IMPORT_ROOT / f'{active_import}.json').exists())
        self.assertFalse((s.CATALOG_IMPORT_ROOT / f'{stale_import}.json').exists())
        self.assertTrue((s.DECOR_MEDIA_ROOT / active_public).exists())
        self.assertFalse((s.DECOR_MEDIA_ROOT / orphan_public).exists())
        self.assertTrue(active_queue.exists())
        self.assertFalse(orphan_queue.exists())
        self.assertTrue(active_claim.exists())
        self.assertFalse(orphan_claim.exists())
        self.assertFalse(stale_draft.exists())
        self.assertFalse(rotated_log.exists())
        self.assertTrue(recent_history.exists())
        self.assertFalse(stale_history.exists())

    def test_backup_cleanup_and_capacity_are_bounded(self) -> None:
        s = self.server
        now = time.time()
        old = now - 10 * 86400
        auto = s.BACKUPS_DIR / 'system_backup_auto_new.zip'
        manual = s.BACKUPS_DIR / 'system_backup_manual_new.zip'
        stale = s.BACKUPS_DIR / 'system_backup_manual_old.zip'
        for path, size in ((auto, 40 * 1024 * 1024), (manual, 40 * 1024 * 1024), (stale, 1024)):
            with open(path, 'wb') as handle:
                handle.truncate(size)
        os.utime(stale, (old, old))
        temp = s.BACKUPS_DIR / '.system_backup_manual_old.zip.deadbeef.tmp'
        temp.write_bytes(b'temp')
        os.utime(temp, (old, old))
        os.environ.update({
            'AUTO_BACKUP_KEEP': '8', 'MANUAL_BACKUP_KEEP': '12',
            'AUTO_BACKUP_MAX_AGE_DAYS': '30', 'MANUAL_BACKUP_MAX_AGE_DAYS': '2',
            'BACKUP_TOTAL_MAX_BYTES': str(64 * 1024 * 1024),
            'BACKUP_TEMP_RETENTION_HOURS': '1',
        })
        result = s._cleanup_old_backups()
        self.assertFalse(stale.exists())
        self.assertFalse(temp.exists())
        self.assertLessEqual(result['remainingBytes'], 64 * 1024 * 1024)
        low_disk = shutil._ntuple_diskusage(total=2_000_000_000, used=1_999_000_000, free=1_000_000)
        with mock.patch.object(s.shutil, 'disk_usage', return_value=low_disk):
            with self.assertRaisesRegex(RuntimeError, 'free disk'):
                s._assert_backup_capacity(1024, 1)

    def test_catalog_image_sync_is_global_reserved_and_capacity_checked(self) -> None:
        s = self.server
        handler = object.__new__(s.Handler)
        first_iid = 'cat_' + ('a' * 24)
        second_iid = 'cat_' + ('b' * 24)
        target = {
            'articleNo': 'ARTICLE-1',
            'publicMaterialId': 'decor_' + ('1' * 20),
            'urls': ['https://example.invalid/catalog-image.jpg'],
        }
        entered = threading.Event()
        release = threading.Event()

        def blocked_download(_url):
            entered.set()
            if not release.wait(5):
                raise TimeoutError('catalog image test did not release download')
            return {'data': b'image', 'mime': 'image/jpeg', 'sha256': 'a' * 64, 'bytes': 5, 'width': 1, 'height': 1}

        workers = 4
        catalog_bytes = workers * s._CATALOG_IMAGE_STORAGE_BYTES_PER_WORKER
        minimum_free = 1024 * 1024**2
        usage = SimpleNamespace(total=10 * 1024**3, used=0, free=minimum_free + catalog_bytes + 8 * 1024**2)
        vfs = SimpleNamespace(f_favail=20_000)
        real_capacity_check = s._enforce_state_capacity
        with mock.patch.dict(os.environ, {
            'CATALOG_IMAGE_WORKERS': str(workers),
            'MIN_FREE_STATE_BYTES': str(minimum_free),
            'MIN_FREE_STATE_INODES': '10000',
        }), mock.patch.object(s.shutil, 'disk_usage', return_value=usage), \
             mock.patch.object(s.os, 'statvfs', return_value=vfs), \
             mock.patch.object(s, '_catalog_download_image', side_effect=blocked_download), \
             mock.patch.object(s, '_catalog_atomic_write_cached_image', return_value={'variantGenerator': 'raw-fallback'}), \
             mock.patch.object(s, '_append_system_event'), \
             mock.patch.object(s, '_enforce_state_capacity', wraps=real_capacity_check) as capacity_check:
            started = handler._start_catalog_image_sync(first_iid, [target], staging=True)
            self.assertTrue(started)
            try:
                self.assertTrue(entered.wait(3), 'catalog downloader did not start')
                totals = s._state_capacity_reservation_totals()
                self.assertEqual(totals, {
                    'jobs': 0,
                    'bytes': catalog_bytes,
                    'inodes': workers * s._CATALOG_IMAGE_STORAGE_INODES_PER_WORKER,
                })
                self.assertFalse(
                    handler._start_catalog_image_sync(second_iid, [target], staging=True),
                    'a second importId started a second global worker pool',
                )
                # Only 8 MiB remains beyond the shared reserve; a 16 MiB job
                # must see and honor the catalog sync reservation.
                with self.assertRaises(s.SafetyContractError):
                    s._reserve_state_capacity('job_catalog_capacity_probe', 16 * 1024**2, 1)
            finally:
                release.set()

            deadline = time.monotonic() + 5
            while time.monotonic() < deadline:
                with s._CATALOG_IMAGE_SYNC_LOCK:
                    active = bool(s._CATALOG_IMAGE_SYNC_ACTIVE)
                if not active:
                    break
                time.sleep(0.02)
            self.assertFalse(active, 'catalog sync did not clear its global active marker')
            self.assertEqual(s._state_capacity_reservation_totals(), {'jobs': 0, 'bytes': 0, 'inodes': 0})
            self.assertGreaterEqual(capacity_check.call_count, 1)

    def test_catalog_image_sync_releases_reservation_when_start_status_fails(self) -> None:
        s = self.server
        handler = object.__new__(s.Handler)
        iid = 'cat_' + ('c' * 24)
        usage = SimpleNamespace(total=10 * 1024**3, used=0, free=5 * 1024**3)
        vfs = SimpleNamespace(f_favail=20_000)
        with mock.patch.object(s.shutil, 'disk_usage', return_value=usage), \
             mock.patch.object(s.os, 'statvfs', return_value=vfs), \
             mock.patch.object(s, '_atomic_write_json', side_effect=OSError('injected status write failure')):
            with self.assertRaisesRegex(OSError, 'injected status write failure'):
                handler._start_catalog_image_sync(iid, [], staging=True)
        with s._CATALOG_IMAGE_SYNC_LOCK:
            self.assertEqual(s._CATALOG_IMAGE_SYNC_ACTIVE, set())
        self.assertEqual(s._state_capacity_reservation_totals(), {'jobs': 0, 'bytes': 0, 'inodes': 0})

    def test_backup_is_verified_before_atomic_publish(self) -> None:
        s = self.server
        probe = s.STATE_ROOT / 'backup_probe.txt'
        probe.write_text('verified-before-publish\n', encoding='utf-8')
        events: list[str] = []
        real_verify = s._verify_system_backup_zip
        real_replace = s.os.replace

        def verify(path, manifest):
            events.append('verify')
            return real_verify(path, manifest)

        def replace(source, destination):
            if Path(destination).parent == s.BACKUPS_DIR and str(destination).endswith('.zip'):
                events.append('publish')
            return real_replace(source, destination)

        inventory = ([(probe, 'state/backup_probe.txt')], probe.stat().st_size)
        with mock.patch.object(s, '_backup_source_inventory', return_value=inventory), \
             mock.patch.object(s, '_assert_backup_capacity'), \
             mock.patch.object(s, '_verify_system_backup_zip', side_effect=verify), \
             mock.patch.object(s.os, 'replace', side_effect=replace):
            result = s._create_system_backup(actor='test', backup_kind='manual')
        self.assertEqual(events[:2], ['verify', 'publish'])
        self.assertTrue((s.BACKUPS_DIR / result['file']).is_file())

    def test_failed_new_backup_never_deletes_last_known_good(self) -> None:
        s = self.server
        known_good = s.BACKUPS_DIR / 'system_backup_auto_known_good.zip'
        known_good.write_bytes(b'known-good')
        old = time.time() - 500 * 86400
        os.utime(known_good, (old, old))
        with mock.patch.object(s, '_backup_source_inventory', side_effect=RuntimeError('injected inventory failure')):
            with self.assertRaisesRegex(RuntimeError, 'injected inventory failure'):
                s._create_system_backup(actor='test', backup_kind='auto')
        self.assertEqual(known_good.read_bytes(), b'known-good')

    def test_retention_snapshot_drains_live_mutation_before_cleanup(self) -> None:
        s = self.server
        with s._STATE_MUTATION_CV:
            s._STATE_MUTATION_COUNT += 1
        cleanup_entered = threading.Event()
        result_holder: list[dict] = []
        failures: list[BaseException] = []
        clean_archive = {'requests': 0, 'orphanJobsDeleted': 0, 'errors': []}
        clean_purge = {'requests': 0, 'jobs': 0, 'queue_done': 0, 'queue_failed': 0, 'errors': []}

        def cleanup(_now):
            cleanup_entered.set()
            return {'errors': []}

        def worker():
            try:
                result_holder.append(s.run_retention_maintenance(force=True))
            except BaseException as exc:
                failures.append(exc)

        try:
            with mock.patch.object(s, '_reconcile_archive_transactions', return_value={'recovered': 0, 'errors': []}), \
                 mock.patch.object(s, '_archive_expired_active_data', return_value=clean_archive), \
                 mock.patch.object(s, '_purge_old_archives', return_value=clean_purge), \
                 mock.patch.object(s, '_cleanup_operational_state', side_effect=cleanup), \
                 mock.patch.object(s, '_compact_requests_index', return_value={'rows': 0}):
                thread = threading.Thread(target=worker, daemon=True)
                thread.start()
                self.assertFalse(cleanup_entered.wait(0.25), 'retention mutated state before live POST drained')
                with s._STATE_MUTATION_CV:
                    s._STATE_MUTATION_COUNT -= 1
                    s._STATE_MUTATION_CV.notify_all()
                thread.join(5)
            self.assertFalse(thread.is_alive())
            self.assertEqual(failures, [])
            self.assertTrue(cleanup_entered.is_set())
            self.assertTrue(result_holder and result_holder[0]['ok'], result_holder)
        finally:
            with s._STATE_MUTATION_CV:
                s._STATE_MUTATION_COUNT = 0
                s._STATE_SNAPSHOT_ACTIVE = False
                s._STATE_MUTATION_CV.notify_all()

    def test_backup_snapshot_waits_until_retention_finishes(self) -> None:
        s = self.server
        probe = s.STATE_ROOT / 'maintenance_backup_probe.txt'
        probe.write_text('stable-state\n', encoding='utf-8')
        retention_entered = threading.Event()
        release_retention = threading.Event()
        backup_invoked = threading.Event()
        backup_snapshot_entered = threading.Event()
        retention_results: list[dict] = []
        backup_results: list[dict] = []
        failures: list[BaseException] = []
        real_begin = s._begin_consistent_snapshot

        def blocked_archive(_now):
            retention_entered.set()
            if not release_retention.wait(5):
                raise TimeoutError('test did not release retention')
            return {'requests': 0, 'orphanJobsDeleted': 0, 'errors': []}

        def observed_begin(*args, **kwargs):
            if threading.current_thread().name == 'backup-maintenance-test':
                backup_snapshot_entered.set()
            return real_begin(*args, **kwargs)

        def retention_worker():
            try:
                retention_results.append(s.run_retention_maintenance(force=True))
            except BaseException as exc:  # pragma: no cover - reported by assertion
                failures.append(exc)

        def backup_worker():
            backup_invoked.set()
            try:
                backup_results.append(s._create_system_backup(actor='race-test', backup_kind='manual'))
            except BaseException as exc:  # pragma: no cover - reported by assertion
                failures.append(exc)

        clean_purge = {'requests': 0, 'jobs': 0, 'queue_done': 0, 'queue_failed': 0, 'errors': []}
        clean_operational = {'errors': []}
        inventory = ([(probe, 'state/maintenance_backup_probe.txt')], probe.stat().st_size)
        with mock.patch.object(s, '_archive_expired_active_data', side_effect=blocked_archive), \
             mock.patch.object(s, '_purge_old_archives', return_value=clean_purge), \
             mock.patch.object(s, '_cleanup_operational_state', return_value=clean_operational), \
             mock.patch.object(s, '_compact_requests_index', return_value={'rows': 0}), \
             mock.patch.object(s, '_backup_source_inventory', return_value=inventory), \
             mock.patch.object(s, '_assert_backup_capacity'), \
             mock.patch.object(s, '_begin_consistent_snapshot', side_effect=observed_begin):
            retention_thread = threading.Thread(target=retention_worker, daemon=True, name='retention-maintenance-test')
            backup_thread = threading.Thread(target=backup_worker, daemon=True, name='backup-maintenance-test')
            retention_thread.start()
            self.assertTrue(retention_entered.wait(2), 'retention did not enter protected region')
            backup_thread.start()
            self.assertTrue(backup_invoked.wait(1), 'backup thread did not start')
            try:
                self.assertFalse(
                    backup_snapshot_entered.wait(0.25),
                    'backup snapshot opened while retention was still mutating state',
                )
            finally:
                release_retention.set()
            retention_thread.join(5)
            backup_thread.join(5)

        self.assertFalse(retention_thread.is_alive())
        self.assertFalse(backup_thread.is_alive())
        self.assertEqual(failures, [])
        self.assertTrue(retention_results and retention_results[0]['ok'], retention_results)
        self.assertTrue(backup_results and backup_results[0]['ok'], backup_results)
        self.assertTrue(backup_snapshot_entered.is_set())

    @unittest.skipIf(os.name == 'nt', 'POSIX flock contract')
    def test_state_maintenance_lock_serializes_separate_process(self) -> None:
        s = self.server
        if s._fcntl is None:
            self.skipTest('fcntl unavailable')
        ready = s.STATE_ROOT / 'maintenance_child_ready'
        acquired = s.STATE_ROOT / 'maintenance_child_acquired'
        code = (
            'from pathlib import Path\n'
            'import server_py as s\n'
            f'Path({str(ready)!r}).write_text("ready", encoding="utf-8")\n'
            'with s._exclusive_state_maintenance():\n'
            f'    Path({str(acquired)!r}).write_text("acquired", encoding="utf-8")\n'
        )
        env = dict(os.environ)
        env.update({
            'METOD_STATE_ROOT': str(s.STATE_ROOT),
            'PYTHONPATH': str(APP_ROOT),
            'PYTHONDONTWRITEBYTECODE': '1',
        })
        proc = None
        with s._exclusive_state_maintenance():
            proc = subprocess.Popen(
                [sys.executable, '-B', '-c', code],
                cwd=str(APP_ROOT),
                env=env,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
            )
            deadline = time.monotonic() + 5
            while not ready.exists() and proc.poll() is None and time.monotonic() < deadline:
                time.sleep(0.02)
            self.assertTrue(ready.exists(), 'child did not reach the shared lock')
            self.assertIsNone(proc.poll(), 'child unexpectedly exited before acquiring the lock')
            self.assertFalse(acquired.exists(), 'separate process bypassed the maintenance lock')
        assert proc is not None
        stdout, stderr = proc.communicate(timeout=5)
        self.assertEqual(proc.returncode, 0, f'stdout={stdout}\nstderr={stderr}')
        self.assertTrue(acquired.exists())

    def test_failed_retention_does_not_suppress_retry(self) -> None:
        s = self.server
        clean_archive = {'requests': 0, 'orphanJobsDeleted': 0, 'errors': []}
        failed_archive = {
            'requests': 0,
            'orphanJobsDeleted': 0,
            'errors': [{'requestId': 'probe', 'error': 'injected archive failure'}],
        }
        clean_purge = {'requests': 0, 'jobs': 0, 'queue_done': 0, 'queue_failed': 0, 'errors': []}
        clean_operational = {'errors': []}

        with mock.patch.object(s, '_archive_expired_active_data', return_value=failed_archive), \
             mock.patch.object(s, '_purge_old_archives', return_value=clean_purge), \
             mock.patch.object(s, '_cleanup_operational_state', return_value=clean_operational), \
             mock.patch.object(s, '_compact_requests_index', return_value={'rows': 0}):
            failed = s.run_retention_maintenance(force=True)
        self.assertFalse(failed['ok'], failed)
        self.assertEqual(s._LAST_RETENTION_RUN_TS, 0.0)

        with mock.patch.object(s, '_archive_expired_active_data', return_value=clean_archive), \
             mock.patch.object(s, '_purge_old_archives', return_value=clean_purge), \
             mock.patch.object(s, '_cleanup_operational_state', return_value=clean_operational), \
             mock.patch.object(s, '_compact_requests_index', return_value={'rows': 0}):
            retry = s.run_retention_maintenance(force=False)
        self.assertTrue(retry['ok'], retry)
        self.assertFalse(retry.get('skipped', False), retry)
        self.assertGreater(s._LAST_RETENTION_RUN_TS, 0.0)

        # A thrown fault has the same retry semantics as a structured error.
        with mock.patch.object(s, '_archive_expired_active_data', side_effect=OSError('injected crash')):
            with self.assertRaisesRegex(OSError, 'injected crash'):
                s.run_retention_maintenance(force=True)
        self.assertEqual(s._LAST_RETENTION_RUN_TS, 0.0)

    def test_queue_maintenance_waits_for_state_snapshot_lock(self) -> None:
        s = self.server
        stale = s.QUEUE_PENDING / 'stale_queue_probe.json'
        stale.write_text('{}\n', encoding='utf-8')
        old = time.time() - (s.STALE_PENDING_QUEUE_DAYS + 1) * 86400
        os.utime(stale, (old, old))
        invoked = threading.Event()
        results: list[dict] = []
        failures: list[BaseException] = []

        def queue_worker():
            invoked.set()
            try:
                results.append(s.run_queue_maintenance(force=True))
            except BaseException as exc:  # pragma: no cover - reported by assertion
                failures.append(exc)

        with s._exclusive_state_maintenance():
            thread = threading.Thread(target=queue_worker, daemon=True)
            thread.start()
            self.assertTrue(invoked.wait(1))
            time.sleep(0.2)
            self.assertTrue(thread.is_alive(), 'queue maintenance bypassed snapshot/retention lock')
            self.assertTrue(stale.exists(), 'queue entry moved during protected snapshot region')
        thread.join(5)
        self.assertFalse(thread.is_alive())
        self.assertEqual(failures, [])
        self.assertTrue(results and results[0]['ok'], results)
        self.assertEqual(results[0]['pendingFailed'], 1)
        self.assertFalse(stale.exists())
        self.assertTrue((s.QUEUE_FAILED / stale.name).exists())

    def test_failed_queue_maintenance_does_not_suppress_retry(self) -> None:
        s = self.server
        stale = s.QUEUE_PENDING / 'retry_queue_probe.json'
        stale.write_text('{}\n', encoding='utf-8')
        old = time.time() - (s.STALE_PENDING_QUEUE_DAYS + 1) * 86400
        os.utime(stale, (old, old))
        with mock.patch.object(s, '_move_queue_file_safe', side_effect=OSError('injected move failure')):
            failed = s.run_queue_maintenance(force=True)
        self.assertFalse(failed['ok'], failed)
        self.assertEqual(s._LAST_QUEUE_MAINTENANCE_TS, 0.0)

        retry = s.run_queue_maintenance(force=False)
        self.assertTrue(retry['ok'], retry)
        self.assertFalse(retry.get('skipped', False), retry)
        self.assertGreater(s._LAST_QUEUE_MAINTENANCE_TS, 0.0)
        self.assertTrue((s.QUEUE_FAILED / stale.name).is_file())

    def test_maintenance_loop_records_redacted_failures(self) -> None:
        s = self.server
        recorded: list[dict] = []
        retention_result = {
            'ok': False,
            'errors': ['Authorization: Bearer retention-secret'],
        }
        with mock.patch.object(s, 'run_retention_maintenance', return_value=retention_result), \
             mock.patch.object(s, 'run_backup_maintenance', return_value={'ok': True}), \
             mock.patch.object(s, 'run_queue_maintenance', side_effect=RuntimeError('Cookie: queue-secret')), \
             mock.patch.object(s, '_append_system_event', side_effect=lambda **kwargs: recorded.append(kwargs)), \
             mock.patch.object(s.time, 'sleep', side_effect=StopIteration):
            with self.assertRaises(StopIteration):
                s._server_maintenance_loop(interval_seconds=0)
        self.assertEqual(len(recorded), 2, recorded)
        details = '\n'.join(str(item.get('message_tech') or '') for item in recorded)
        self.assertNotIn('retention-secret', details)
        self.assertNotIn('queue-secret', details)
        self.assertIn('[redacted-secret]', details)


if __name__ == '__main__':
    unittest.main(verbosity=2)
