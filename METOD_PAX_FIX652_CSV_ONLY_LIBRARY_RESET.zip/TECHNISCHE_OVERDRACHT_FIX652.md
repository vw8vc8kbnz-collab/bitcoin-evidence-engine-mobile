# Technische overdracht — METOD/PAX Tool A FIX652

**Release:** FIX652_CSV_ONLY_LIBRARY_RESET  
**Datum:** 2026-08-07  
**Basis:** FIX651 + behoud van UX-regressiefixes t/m FIX650

## 1. Definitieve architectuurbeslissing

Vanaf FIX652 bestaat er functioneel nog maar **één actieve Decor Library**: de laatst door Admin gevalideerde en gepubliceerde website-CSV. Legacy seeddata, de oude JSON-libraryupload en losse handmatige decor-mutaties zijn geen alternatieve bron meer.

De hoofdregel is:

`Admin CSV preview -> expliciet publiceren -> exacte actieve catalogus -> geschoonde publieke API -> Tool A`

De release bevat bewust **geen website-CSV**. Op een fresh install is `app/material_library.json` een lege `CSV_CATALOG_ONLY`-container. Op een update wordt de bestaande live library eerst veilig gemigreerd/gearchiveerd.

## 2. Migratie en legacy-isolatie

Nieuw toolbestand:

`tools/fix652_catalog_only_migrate.py`

Dit wordt door `DEPLOY_FIX652.sh` vóór serverstart uitgevoerd en doet:

1. lees huidige `app/material_library.json`;
2. maak timestamped archive onder `app/system/catalog_legacy_archive/`;
3. seed/update private `app/system/catalog_public_ids.json` met bruikbare bestaande article -> opaque ID mappings;
4. behoud alleen reeds gepubliceerde, geldige `CATALOG_IMPORT` records met dikte 18/19/20 als actieve records;
5. verwijder seed/legacy/manual records uit de actieve library;
6. schrijf `source=CSV_CATALOG_ONLY`, `decorLibrarySchemaVersion=3`.

De archivebestanden zijn backend-only en mogen nooit publiek geserveerd worden.

## 3. Public ID registry

Private bestand:

`app/system/catalog_public_ids.json`

Doel: `publicMaterialId` stabiel houden over CSV-updates, tijdelijke verwijderingen en herintroducties zonder dat legacy records actief hoeven te blijven.

Artikelnummer is de interne match-key. Publiek wordt een willekeurige ID gebruikt zoals:

`decor_a84f27c91e13f0048c22`

De registry is nooit onderdeel van de publieke API.

## 4. CSV parser

Bestand:

`app/catalog_importer.py`

Ondersteunt de aangeleverde export waarbij Excel de volledige gequote regel in kolom A kan tonen, plus normale CSV-weergave.

Semantische bronvelden:

1. Product Reference Code -> intern artikelnummer
2. Product Image Urls -> interne image source URL(s)
3. Product Name -> publieke product/decornaam
4. Feature Max. dikte (mm) -> autoritatieve dikte
5. Feature Max. lengte (mm) -> plaatlengte
6. Feature Max. breedte (mm) -> plaatbreedte
7. Prijs per plaat inclusief BTW -> autoritatieve directe verkoopprijs

### Diktefilter

`ALLOWED_THICKNESSES_MM = (18.0, 19.0, 20.0)`

Dit is een whitelist. Niet `>=18`.

### Plaatmaat-resolutie

Prioriteit:

1. expliciete CSV lengte/breedte;
2. afleiding uit Adzaagt image URL;
3. alleen voor DecoLegno 18 mm: 2800x2070 fallback;
4. anders blocking/incomplete afhankelijk parsercontext.

URL-dikte mag nooit CSV-dikte overschrijven. Mismatch wordt waarschuwing.

### Prijs

`Prijs per plaat inclusief BTW` wordt genormaliseerd naar:

- `sellPriceInclVatPerSheet`
- `sellPriceExVatPerSheet`
- `priceVatRate=0.21`
- `priceSource=CSV_SALE_PRICE_INCL_VAT`

## 5. Admin UI

`ADMIN_HTML` in `app/server_py.py` bevat marker:

`FIX652_CSV_ONLY_ADMIN`

De Decor Library-pagina heet functioneel **Websitecatalogus** en bevat één beheerpad:

1. bestand kiezen;
2. `CSV controleren`;
3. preview/diff/warnings/exclusions bekijken;
4. `Catalogus publiceren`.

Geen actieve UI voor:

- Nieuw decor;
- Upload hele JSON;
- handmatig actief decor opslaan/verwijderen;
- handmatige alternatieve catalogus.

De geselecteerde catalogusregel is read-only informatief en mag in Admin intern artikelnummer tonen.

## 6. Preview vs publish

Preview mutatieert de live library niet. De import wordt staged met een import-ID.

Publish doet **exact replacement**, geen merge met legacy:

- geldige rows uit staged CSV worden nieuwe actieve `records`;
- bestaand artikel -> hergebruik public ID;
- nieuw artikel -> random opaque public ID;
- product niet in CSV -> niet actief;
- product naar verboden dikte -> niet actief;
- legacy/manual -> niet actief.

Dit voorkomt stale 18mm-data als een SKU later 10mm wordt.

## 7. Public material API

`/api/materials/library` filtert op:

- `sourceKind == CATALOG_IMPORT`;
- active/published;
- niet archived;
- niet catalogMissing/catalogExcluded;
- dikte exact 18/19/20.

Allowlisted responsevelden omvatten uitsluitend publieke presentatievelden zoals publicMaterialId, naam, merk, decorType, kleur, dikte, sheetSize, grain flags en lokale image URLs.

Verboden publiek:

- articleNo/articleNumber/materialCode;
- purchasePrice/inkoopprijs;
- supplier/leverancier;
- sellPriceInclVatPerSheet/sellPriceExVatPerSheet;
- imageSourceUrl(s);
- interne import/provenancevelden.

De klantprijs wordt server-side berekend; de ruwe catalogusplaatprijs hoeft niet als publieke librarydata naar de browser.

## 8. Pricingmodel

Actief model:

`pricingModel = catalog_sell_price_v1`

De algemene `sheetPriceFactor` wordt bij deploy uit persisted active pricing verwijderd en wordt niet gebruikt in de actieve quote-berekening.

`_material_direct_sell_ex_vat()` accepteert alleen directe sell-pricevelden. Er is geen purchase-price-factor fallback in deze actieve selector.

`_ensure_pricing_materials()` rebuildt job-material pricing altijd vanuit de live gepubliceerde interne catalogus. Oude browser/request pricing is dus niet autoritatief.

Bestaande Admin-kosten blijven behouden:

- `edgeBandPricePerM`
- `cncCostPerSheet`
- `drawingCostFixed`
- `transportCostFixed`

Technische defaults blijven behouden.

## 9. Image pipeline

Externe image URL(s) blijven interne importdata. Na publish wordt image sync/caching gestart. De publieke library gebruikt lokale thumb/preview-routes.

Downloaderregels omvatten o.a. HTTPS, toegestane Adzaagt-hosts, publieke IP-resolutie, beperkte redirects, timeout/size/type-validatie en metadata-vrije afgeleide webbeelden.

Een tijdelijke image download failure mag catalogusdata niet corrumperen; image state kan later opnieuw worden gesynchroniseerd.

## 10. Deployment

`DEPLOY_FIX652.sh`:

- behoudt acceptatie HTTP-modus van eerdere releases;
- maakt vereiste systeemmappen;
- migreert oude library naar CSV-only;
- normaliseert persisted pricing en verwijdert alleen algemene factor;
- bewaart andere Admin-pricingvelden;
- compileert/controlleert release;
- herstart service/nginx;
- doet public privacy/canonical-catalog smokechecks;
- controleert dat interne bestanden 404 geven.

De one-shot installer moet live bedrijfsdata bij rsync uitsluiten, waaronder jobs, requests, queue, archive, backups, drafts, system, decor_media, live material_library, live pricing, pricing history/audit en embedded DXFs. Hierdoor kan de migrator de echte live library archiveren voordat deze wordt opgeschoond.

## 11. Eerste live acceptatie na FIX652

1. open `/admin/?v=652`;
2. controleer dat Decor Library alleen Websitecatalogus/CSV-flow toont;
3. de oude 843 fake/seed records mogen niet meer zichtbaar zijn;
4. als er nog geen eerdere CSV-catalogus was, is actief aantal 0;
5. upload echte CSV;
6. klik `CSV controleren`;
7. verwacht voor het huidige testbestand ongeveer 606 gelezen, 597 geldig, 9 dikte-exclusions, 18 warnings, 0 blockers;
8. review warnings;
9. klik `Catalogus publiceren`;
10. controleer image sync;
11. open Tool A en verifieer materiaalkeuze;
12. controleer een offerte/prijscase tegen CSV-plaatprijs + Admin-kosten;
13. inspecteer browser/network zodat geen intern artikelnummer zichtbaar is.

## 12. Niet terugdraaien zonder expliciete productbeslissing

Toekomstige releases mogen niet opnieuw:

- een tweede handmatige actieve library introduceren;
- JSON-upload als parallelle source-of-truth toevoegen;
- oude seedmaterialen in Tool A terugbrengen;
- `sheetPriceFactor` in de actieve materiaalberekening terugzetten;
- artikelnummer als publieke material ID gebruiken.
