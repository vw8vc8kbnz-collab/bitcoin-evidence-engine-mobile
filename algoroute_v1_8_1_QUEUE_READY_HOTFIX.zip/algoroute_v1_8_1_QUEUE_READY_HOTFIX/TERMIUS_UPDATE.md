# AlgoRoute v1.8.1 QUEUE READY HOTFIX — Termius update

```bash
cd /home/ubuntu

rm -rf algoroute_latest
rm -f algoroute_v1_8_1_QUEUE_READY_HOTFIX.zip

wget -O /home/ubuntu/algoroute_v1_8_1_QUEUE_READY_HOTFIX.zip \
"https://raw.githubusercontent.com/vw8vc8kbnz-collab/bitcoin-evidence-engine-mobile/main/algoroute_v1_8_1_QUEUE_READY_HOTFIX.zip"

mkdir -p /home/ubuntu/algoroute_latest
unzip -o /home/ubuntu/algoroute_v1_8_1_QUEUE_READY_HOTFIX.zip -d /home/ubuntu/algoroute_latest

cd /home/ubuntu/algoroute_latest/algoroute_v1_8_1_QUEUE_READY_HOTFIX

chmod +x scripts/install.sh scripts/setup_osrm_nl.sh
sudo ./scripts/install.sh

sudo docker compose down --remove-orphans || true
sudo docker rm -f algoroute-api algoroute-web algoroute-nginx 2>/dev/null || true
sudo docker compose up -d --build --force-recreate

curl http://localhost:8787/api/health
curl http://localhost:8787/api/routing/status
curl http://localhost:8787/api/optimizer/status
curl http://localhost:8787/api/geocode/queue -X POST -H 'Content-Type: application/json' -d '{"limit":250,"overwrite":false}'
curl http://localhost:8787/api/planning/queue
```
