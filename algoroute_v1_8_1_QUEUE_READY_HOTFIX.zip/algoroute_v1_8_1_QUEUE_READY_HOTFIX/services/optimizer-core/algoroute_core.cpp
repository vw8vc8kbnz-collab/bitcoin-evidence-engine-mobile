#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <sstream>
#include <string>
#include <vector>

static constexpr const char* CORE_VERSION = "cpp-core-v1.0-route-load";

struct Order {
    std::string id, number, customer, delivery_date, tw_start, tw_end;
    double lat = 0, lon = 0, service_min = 15, weight_kg = 0, volume_m3 = 0;
    int pallets = 0, rolls = 0, priority = 0;
};

struct Vehicle {
    std::string id, name, status;
    double max_weight_kg = 1e12, max_volume_m3 = 1e12;
    int max_pallets = 1000000, max_rolls = 1000000;
};

struct StopPlan {
    Order order;
    double eta_min = 0;
    double leg_km = 0;
    std::string warning;
};

struct RoutePlan {
    Vehicle vehicle;
    std::vector<StopPlan> stops;
    double distance_km = 0, duration_min = 0, weight_kg = 0, volume_m3 = 0;
    int pallets = 0, rolls = 0, time_window_warnings = 0;
};

static std::vector<std::string> split(const std::string& s, char delim) {
    std::vector<std::string> out;
    std::string cur;
    std::stringstream ss(s);
    while (std::getline(ss, cur, delim)) out.push_back(cur);
    while (!s.empty() && s.back() == delim) out.push_back("");
    return out;
}

static double to_double(const std::string& s, double def = 0.0) {
    try { size_t p = 0; double v = std::stod(s, &p); return std::isfinite(v) ? v : def; }
    catch (...) { return def; }
}

static int to_int(const std::string& s, int def = 0) {
    try { size_t p = 0; int v = std::stoi(s, &p); return v; }
    catch (...) { return def; }
}

static double haversine_km(double lon1, double lat1, double lon2, double lat2) {
    const double R = 6371.0;
    const double deg = M_PI / 180.0;
    double p1 = lat1 * deg, p2 = lat2 * deg;
    double dp = (lat2 - lat1) * deg, dl = (lon2 - lon1) * deg;
    double a = std::sin(dp/2)*std::sin(dp/2) + std::cos(p1)*std::cos(p2)*std::sin(dl/2)*std::sin(dl/2);
    return R * 2.0 * std::asin(std::sqrt(std::max(0.0, a)));
}

static int parse_time_min(const std::string& s, int def = -1) {
    if (s.size() < 4) return def;
    std::string t = s;
    std::replace(t.begin(), t.end(), '.', ':');
    auto parts = split(t, ':');
    if (parts.size() < 2) return def;
    int h = to_int(parts[0], -1), m = to_int(parts[1], -1);
    if (h < 0 || h > 23 || m < 0 || m > 59) return def;
    return h * 60 + m;
}

static std::string json_escape(const std::string& s) {
    std::ostringstream o;
    for (char c : s) {
        switch (c) {
            case '"': o << "\\\""; break;
            case '\\': o << "\\\\"; break;
            case '\b': o << "\\b"; break;
            case '\f': o << "\\f"; break;
            case '\n': o << "\\n"; break;
            case '\r': o << "\\r"; break;
            case '\t': o << "\\t"; break;
            default: if (static_cast<unsigned char>(c) < 0x20) o << " "; else o << c;
        }
    }
    return o.str();
}

static bool fits(const RoutePlan& r, const Order& o) {
    return r.weight_kg + o.weight_kg <= r.vehicle.max_weight_kg + 1e-9 &&
           r.volume_m3 + o.volume_m3 <= r.vehicle.max_volume_m3 + 1e-9 &&
           r.pallets + o.pallets <= r.vehicle.max_pallets &&
           r.rolls + o.rolls <= r.vehicle.max_rolls;
}

int main() {
    double depot_lon = 4.9041, depot_lat = 52.3676;
    std::vector<Vehicle> vehicles;
    std::vector<Order> orders;
    std::string line;
    while (std::getline(std::cin, line)) {
        if (line.empty()) continue;
        auto parts = split(line, '\t');
        if (parts.empty()) continue;
        if (parts[0] == "DEPOT" && parts.size() >= 3) {
            depot_lon = to_double(parts[1], depot_lon); depot_lat = to_double(parts[2], depot_lat);
        } else if (parts[0] == "VEH" && parts.size() >= 9) {
            Vehicle v;
            v.id = parts[1]; v.name = parts[2];
            v.max_weight_kg = to_double(parts[3], 1e12);
            v.max_volume_m3 = to_double(parts[4], 1e12);
            v.max_pallets = to_int(parts[5], 1000000);
            v.max_rolls = to_int(parts[6], 1000000);
            v.status = parts[7];
            vehicles.push_back(v);
        } else if (parts[0] == "ORD" && parts.size() >= 16) {
            Order o;
            o.id = parts[1]; o.number = parts[2]; o.customer = parts[3];
            o.lon = to_double(parts[4]); o.lat = to_double(parts[5]);
            o.delivery_date = parts[6]; o.tw_start = parts[7]; o.tw_end = parts[8];
            o.service_min = to_double(parts[9], 15);
            o.weight_kg = to_double(parts[10], 0); o.volume_m3 = to_double(parts[11], 0);
            o.pallets = to_int(parts[12], 0); o.rolls = to_int(parts[13], 0); o.priority = to_int(parts[14], 0);
            orders.push_back(o);
        }
    }

    std::vector<RoutePlan> routes;
    std::vector<Order> unplanned;
    std::vector<bool> used(orders.size(), false);
    const double avg_speed_kmh = 55.0;
    const double route_start_min = 8 * 60.0;

    for (const auto& v : vehicles) {
        RoutePlan route; route.vehicle = v;
        double cur_lon = depot_lon, cur_lat = depot_lat;
        double clock = route_start_min;
        while (true) {
            int best_idx = -1;
            double best_score = std::numeric_limits<double>::infinity();
            for (size_t i = 0; i < orders.size(); ++i) {
                if (used[i]) continue;
                const auto& o = orders[i];
                if (!fits(route, o)) continue;
                double leg = haversine_km(cur_lon, cur_lat, o.lon, o.lat);
                double travel_min = leg / avg_speed_kmh * 60.0;
                double eta = clock + travel_min;
                int tw_end = parse_time_min(o.tw_end, -1);
                int tw_start = parse_time_min(o.tw_start, -1);
                double penalty = 0.0;
                if (tw_end >= 0 && eta > tw_end) penalty += (eta - tw_end) * 3.0;
                if (tw_start >= 0 && eta < tw_start) penalty += (tw_start - eta) * 0.35;
                double fill_bonus = (o.pallets * 0.35) + (o.rolls * 0.25) + (o.weight_kg / std::max(1.0, v.max_weight_kg) * 3.0);
                double score = leg + penalty - (o.priority * 1.8) - fill_bonus;
                if (score < best_score) { best_score = score; best_idx = static_cast<int>(i); }
            }
            if (best_idx < 0) break;
            Order o = orders[best_idx]; used[best_idx] = true;
            double leg = haversine_km(cur_lon, cur_lat, o.lon, o.lat);
            double travel_min = leg / avg_speed_kmh * 60.0;
            clock += travel_min;
            std::string warning;
            int tw_start = parse_time_min(o.tw_start, -1), tw_end = parse_time_min(o.tw_end, -1);
            if (tw_start >= 0 && clock < tw_start) { clock = tw_start; warning = "wacht_tot_tijdvenster"; }
            if (tw_end >= 0 && clock > tw_end) { warning = "tijdvenster_risico"; route.time_window_warnings++; }
            route.stops.push_back({o, clock, leg, warning});
            route.distance_km += leg;
            clock += std::max(0.0, o.service_min);
            route.duration_min = clock - route_start_min;
            route.weight_kg += o.weight_kg; route.volume_m3 += o.volume_m3;
            route.pallets += o.pallets; route.rolls += o.rolls;
            cur_lon = o.lon; cur_lat = o.lat;
        }
        if (!route.stops.empty()) {
            route.distance_km += haversine_km(cur_lon, cur_lat, depot_lon, depot_lat);
            route.duration_min += haversine_km(cur_lon, cur_lat, depot_lon, depot_lat) / avg_speed_kmh * 60.0;
            routes.push_back(route);
        }
    }
    for (size_t i = 0; i < orders.size(); ++i) if (!used[i]) unplanned.push_back(orders[i]);

    double total_km = 0, total_min = 0;
    int total_stops = 0, warnings = 0;
    for (const auto& r : routes) { total_km += r.distance_km; total_min += r.duration_min; total_stops += (int)r.stops.size(); warnings += r.time_window_warnings; }

    std::cout << std::fixed << std::setprecision(3);
    std::cout << "{\"ok\":true,\"core_version\":\"" << CORE_VERSION << "\",\"routes\":[";
    for (size_t ri = 0; ri < routes.size(); ++ri) {
        const auto& r = routes[ri]; if (ri) std::cout << ",";
        double w_util = r.vehicle.max_weight_kg > 0 && r.vehicle.max_weight_kg < 1e11 ? r.weight_kg / r.vehicle.max_weight_kg : 0;
        double v_util = r.vehicle.max_volume_m3 > 0 && r.vehicle.max_volume_m3 < 1e11 ? r.volume_m3 / r.vehicle.max_volume_m3 : 0;
        double p_util = r.vehicle.max_pallets > 0 && r.vehicle.max_pallets < 100000 ? (double)r.pallets / r.vehicle.max_pallets : 0;
        double rc_util = r.vehicle.max_rolls > 0 && r.vehicle.max_rolls < 100000 ? (double)r.rolls / r.vehicle.max_rolls : 0;
        double load_util = std::max(std::max(w_util, v_util), std::max(p_util, rc_util));
        std::cout << "{\"vehicle_id\":\"" << json_escape(r.vehicle.id) << "\",\"vehicle_name\":\"" << json_escape(r.vehicle.name) << "\",";
        std::cout << "\"distance_m\":" << (long long)std::round(r.distance_km * 1000.0) << ",\"duration_s\":" << (long long)std::round(r.duration_min * 60.0) << ",";
        std::cout << "\"load\":{\"weight_kg\":" << r.weight_kg << ",\"volume_m3\":" << r.volume_m3 << ",\"europallets\":" << r.pallets << ",\"roll_containers\":" << r.rolls << ",\"utilization\":" << load_util << "},";
        std::cout << "\"warnings\":" << r.time_window_warnings << ",\"stops\":[";
        for (size_t si = 0; si < r.stops.size(); ++si) {
            const auto& s = r.stops[si]; if (si) std::cout << ",";
            int eta_h = ((int)std::round(s.eta_min)) / 60, eta_m = ((int)std::round(s.eta_min)) % 60;
            std::ostringstream eta; eta << std::setw(2) << std::setfill('0') << eta_h << ":" << std::setw(2) << eta_m;
            std::cout << "{\"order_id\":\"" << json_escape(s.order.id) << "\",\"order_number\":\"" << json_escape(s.order.number) << "\",\"customer_name\":\"" << json_escape(s.order.customer) << "\",";
            std::cout << "\"eta\":\"" << eta.str() << "\",\"leg_distance_m\":" << (long long)std::round(s.leg_km * 1000.0) << ",\"warning\":\"" << json_escape(s.warning) << "\"}";
        }
        std::cout << "]}";
    }
    std::cout << "],\"unplanned\":[";
    for (size_t i = 0; i < unplanned.size(); ++i) { if (i) std::cout << ","; std::cout << "{\"order_id\":\"" << json_escape(unplanned[i].id) << "\",\"order_number\":\"" << json_escape(unplanned[i].number) << "\",\"reason\":\"past_niet_binnen_voertuigcapaciteit_of_routes\"}"; }
    std::cout << "],\"summary\":{\"routes\":" << routes.size() << ",\"planned_stops\":" << total_stops << ",\"unplanned_stops\":" << unplanned.size() << ",\"total_distance_m\":" << (long long)std::round(total_km*1000.0) << ",\"total_duration_s\":" << (long long)std::round(total_min*60.0) << ",\"time_window_warnings\":" << warnings << "}}\n";
    return 0;
}
