# AlgoRoute v1.8.1 QUEUE READY HOTFIX

Hotfix bovenop v1.8.0 CPP CORE.

## Fix
- Planning Queue bleef op `incomplete` staan als postcode uit CSV leeg was, ondanks succesvolle PDOK/BAG geocoding.
- Orders met geldige latitude/longitude worden nu `ready`, ook wanneer originele CSV geen postcode bevat.
- `/api/geocode/queue` refresht bestaande GPS-orders opnieuw naar `ready` bij een tweede validatie-run.
- C++ optimizer-core uit v1.8.0 blijft behouden: routeoptimalisatie + pallet/rolcontainer load-capaciteit; geen 3D loading.

## Check
Na deploy:

```bash
curl http://localhost:8787/api/health
curl http://localhost:8787/api/optimizer/status
curl http://localhost:8787/api/geocode/queue -X POST -H 'Content-Type: application/json' -d '{"limit":250,"overwrite":false}'
curl http://localhost:8787/api/planning/queue
```

Daarna moet `summary.ready` gevuld zijn.
