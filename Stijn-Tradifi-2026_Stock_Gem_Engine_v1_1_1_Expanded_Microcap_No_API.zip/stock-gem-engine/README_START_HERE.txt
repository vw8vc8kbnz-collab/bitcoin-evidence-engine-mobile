Stijn-Tradifi-2026 v1.1.1 Expanded Microcap Buckets No API

- Expanded universe >75 research candidates
- Sub-$20M bucket populated
- Website + extra company context
- Rebuilds old 24-only result set after scan
