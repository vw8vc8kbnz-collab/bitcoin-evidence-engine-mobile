# Outrun IQ v0.7 Split Routes VPS Ready

Start:

```bash
HOST=0.0.0.0 PORT=8795 python3 server.py
```

Health:

```bash
curl -s http://127.0.0.1:8795/api/health
```
