# RELEASE NOTES — v2.0.0 (breaking, honesty release)

Resultaten zullen LAGER zijn dan v1.9.x. Dat is de bedoeling: de optimistische biases zijn verwijderd.

## Gefixt (kritiek)
1. **ntfy-alerts kwamen nooit aan**: emoji in de HTTP `Title`-header gaf een UnicodeEncodeError die door `except: pass` werd ingeslikt — élke alert crashte vóór verzending. Headers zijn nu ASCII-safe, fouten worden gelogd, `NTFY_ENABLED` staat standaard aan, en er is `python engine.py --ntfy-test`.
2. **Snapshot-leakage**: technical_score/theme-bonus van vandaag zat in historische evidence. Snapshot-velden zijn nu alleen live-context en tellen nergens mee in validatie.
3. **Fake drift-baseline**: excess werd gemeten t.o.v. andere signaal-geconditioneerde trades (≈ zichzelf). Nu: echte unconditional drift van de ticker over hetzelfde window, zelfde executie + kosten.
4. **Entry-bias**: entry was de Close van de signaalbar zelf. Nu: Open van de volgende dag, met 0.20% round-trip kosten (SEE_TRADE_COST_PCT).
5. **Opgeblazen n**: elite/usable-gates draaien nu volledig op n_eff (non-overlapping), niet op de ~10x opgeblazen ruwe n.
6. **Schaalcorruptie**: ×10-heuristiek verminkte legitieme lage scores (7/100 → 70). Nu row-level detectie: alleen ×10 als ALLE scorevelden ≤10.
7. **News-matching**: word-boundary regex ('ai' matcht niet meer 'said'/'raise') + recency-weging (≤1d vol gewicht, ≥7d nul).
8. **CI vs nul → CI vs drift**: validated_edge vereist excess_ci90_low > 0, excess > 0.5, n_eff ≥ 10. Monitor-CSV rapporteert aantal geteste cellen (multiple-testing-context).
9. **Stock Lab**: cache wordt nu ook gelézen (2h), ticker-validatie, per-IP rate limit — DeepSeek-budget beschermd. Optionele dashboard-token via SEE_DASH_TOKEN.
10. **Dashboard leeg na versiebump**: server valt terug op nieuwste v*-CSV. Price cache max 3 dagen oud in live mode.

## Nieuw
- **Statistische controles in selftest**: positieve controle (synthetische conditionele edge → moet gedetecteerd) + negatieve controle (random walk → nul validated). Beide slagen.
- Extra ntfy-tier `LIVE_HIGH_UNVALIDATED` (live_attention ≥ 75 + AI high) met cross-run dedup (12h), zodat het topic niet maandenlang stil is terwijl validated edges schaars zijn.
- Dark quant-terminal dashboard met dubbele live/validated scorebalk, warning-chips en Nederlandse labels.
- DeepSeek prompt: freshness-discipline (age_days-weging; nieuws >7d ≠ catalyst).

# v2.0.1
- "Run scan nu"-knop in het dashboard: start run_backtest.sh op de achtergrond met lockfile (geen dubbele runs), live status via /api/run_status, pagina ververst automatisch als de scan klaar is. De automatische systemd-timer (4x/dag) blijft gewoon actief.
- Scans loggen naar output/scan.log zodat mislukte Yahoo-downloads zichtbaar zijn.
