#!/usr/bin/env bash
set -euo pipefail
for f in server.py engine.py install.sh run_backtest.sh requirements.txt deepseek_prompt.md VERSION; do
  test -f "$f" || { echo "missing $f"; exit 1; }
done
python3 -m py_compile server.py engine.py
python3 - <<'PYSELF'
import re, pathlib, importlib.util, math
import pandas as pd, numpy as np
expected=pathlib.Path('VERSION').read_text().strip()
for file in ['server.py','engine.py']:
    txt=pathlib.Path(file).read_text()
    m=re.search(r"VERSION=['\"]([^'\"]+)['\"]", txt)
    if not m or m.group(1)!=expected:
        raise SystemExit(f"VERSION mismatch in {file}: {m.group(1) if m else 'missing'} != {expected}")
spec=importlib.util.spec_from_file_location('engine','engine.py')
engine=importlib.util.module_from_spec(spec); spec.loader.exec_module(engine)

# --- AI scale detection: whole row 0-10 gets scaled ---
row=engine.normalize_ai_row({'final_score':8,'materiality':9,'market_confirmation':7.5,'priced_in_risk':6})
assert row['ai_final_score']==80 and row['materiality']==90 and row['market_confirmation']==75 and row['priced_in_risk']==60
assert row['ai_tier']=='AI_ELITE'
# --- FIXED in v2: honest low value in a 0-100 row is NOT corrupted to x10 ---
row2=engine.normalize_ai_row({'final_score':72,'materiality':65,'priced_in_risk':7})
assert row2['priced_in_risk']==7, f"low score corrupted: {row2['priced_in_risk']}"
assert row2['ai_final_score']==72

# --- word-boundary event scoring: 'said/raise/against' must not count as 'ai' ---
news=[{'title':'CEO said results will raise concerns against emails','age_days':0.5}]
m=dict(ret3=0,relative_volume=1,rs_vs_bench=0)
cat,_=engine.local_event_score('MSFT',news,m)
news_ai=[{'title':'Company announces AI partnership deal','age_days':0.5}]
cat_ai,_=engine.local_event_score('MSFT',news_ai,m)
assert cat_ai>cat, f"word boundary broken: {cat} vs {cat_ai}"
# --- recency: stale headline contributes ~nothing ---
stale=[{'title':'Company announces AI partnership deal','age_days':20}]
cat_stale,_=engine.local_event_score('MSFT',stale,m)
assert cat_stale<cat_ai

# --- NTFY header safety: emoji stripped, latin-1 encodable ---
h=engine._ascii_header('🚨 FINAL_EXTREME MU | live 82.1')
h.encode('latin-1')
assert 'FINAL_EXTREME' in h and '\U0001f6a8' not in h

# --- overlap-aware effective n ---
trades=[{'ticker':'T','setup':'s','hold_days':5,'entry_date':f'2024-01-{d:02d}','return_pct':1.0} for d in range(2,15)]
no=engine.non_overlap_returns(trades,5)
assert len(no)<len(trades)

# --- true unconditional drift + excess CI in validation ---
idx=pd.bdate_range('2023-01-02', periods=260)
rng=np.random.default_rng(7)
close=pd.Series(100*np.cumprod(1+rng.normal(0.001,0.02,len(idx))), index=idx)
df=pd.DataFrame({'Open':close.shift(1).fillna(close.iloc[0]),'Close':close,'Volume':1_000_000})
drift=engine.unconditional_drift(df,5)
assert isinstance(drift,float)
summary=[{'ticker':'T','theme':'X','setup':'s','hold_days':5,'avg_return_pct':1.0}]
validation, excess, val_map=engine.build_validation_tables(summary,trades,price_data={'T':df})
v=validation[0]
assert v['n_eff']<v['n_orig']
assert 'excess_ci90_low' in v and 'ticker_drift_unconditional' in v
assert 'winrate_nonoverlap' in v and 'evidence_score' in v

# --- next-open entry execution ---
mm=dict(price=1,ret1=0,ret3=0,ret20=0,relative_volume=1,position_52w=50,rs_vs_bench=0,technical_score=50,above_ma50=True,above_ma20=True)
rows,trs=engine.setup_rows('PLTR',df.assign(Volume=2_000_000),mm)
if trs:
    assert trs[0]['execution']=='next_open_entry_v2'
    assert trs[0]['entry_date']>trs[0]['signal_date']
# --- no snapshot leakage: raw rows carry zero evidence until validation ---
assert all(r['evidence_score']==0.0 for r in rows)

# --- clamp100 never applies x10 heuristic ---
assert engine.clamp100(7)==7 and engine.clamp100(150)==100

assert hasattr(engine, 'analyze_single_stock')
assert hasattr(engine, 'ntfy_test')
for sub in ['price_cache','metadata_cache','stock_lab']:
    assert (engine.DATA_CACHE/sub).exists()
print('[SEE selftest] v2.0.0: scale-detect + word-boundary + recency + ntfy-header + true-drift + excess-CI + next-open entry OK')
PYSELF
echo '[SEE selftest] OK'

# --- statistical controls: gate must catch real conditional edge and reject random walk ---
python3 tests/positive_control.py > /tmp/see_poscontrol.log 2>&1 && tail -1 /tmp/see_poscontrol.log || { echo '[SEE selftest] POSITIVE CONTROL FAILED'; tail -25 /tmp/see_poscontrol.log; exit 1; }
echo '[SEE selftest] statistical controls OK (edge detected, random walk rejected)'
