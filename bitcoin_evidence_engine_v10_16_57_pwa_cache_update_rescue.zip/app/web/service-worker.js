const CACHE_NAME = 'bee-mobile-10_16_57_pwa_cache_update_fix';
const VERSION = '10_16_57_pwa_cache_update_fix';
const STATIC_ASSETS = [
  '/manifest.webmanifest?v=10_16_57_pwa_cache_update_fix',
  '/static/css/mobile_app.css?v=10_16_57_pwa_cache_update_fix',
  '/static/js/mobile_app.js?v=10_16_57_pwa_cache_update_fix',
  '/static/icons/icon-180.png',
  '/static/icons/icon-192.png',
  '/static/icons/icon-512.png'
];

async function cacheStatic(){
  const cache = await caches.open(CACHE_NAME);
  await Promise.all(STATIC_ASSETS.map(async (url)=>{
    try{
      const res = await fetch(url, {cache:'reload'});
      if(res && res.ok) await cache.put(url, res.clone());
    }catch(e){}
  }));
}

self.addEventListener('install', event => {
  self.skipWaiting();
  event.waitUntil(cacheStatic());
});

self.addEventListener('activate', event => {
  event.waitUntil((async()=>{
    const keys = await caches.keys();
    await Promise.all(keys.filter(k => k.startsWith('bee-mobile-') && k !== CACHE_NAME).map(k => caches.delete(k)));
    if(self.registration.navigationPreload){ try{ await self.registration.navigationPreload.enable(); }catch(e){} }
    await self.clients.claim();
    // Force already-open iPhone PWA clients off any cached old /mobile shell.
    const clients = await self.clients.matchAll({type:'window', includeUncontrolled:true});
    for(const c of clients){
      try{
        const u = new URL(c.url);
        if(u.pathname === '/mobile' || u.pathname === '/'){
          u.pathname = '/mobile';
          u.searchParams.set('app_v', VERSION);
          c.navigate(u.toString());
        } else {
          c.postMessage({type:'BEE_SW_UPDATED', version: VERSION});
        }
      }catch(e){}
    }
  })());
});

function timeout(ms){ return new Promise((_,rej)=>setTimeout(()=>rej(new Error('sw-timeout')),ms)); }

async function networkFirst(request, cacheKey, ms){
  const cache = await caches.open(CACHE_NAME);
  try{
    const res = await Promise.race([fetch(request, {cache:'reload'}), timeout(ms || 3500)]);
    if(res && res.ok){ cache.put(cacheKey || request, res.clone()).catch(()=>{}); return res; }
  }catch(e){}
  const cached = await cache.match(cacheKey || request);
  if(cached) return cached;
  return null;
}

self.addEventListener('fetch', event => {
  const req = event.request;
  const url = new URL(req.url);
  if(req.method !== 'GET') return;
  if(url.pathname.startsWith('/api/')) return; // API must remain live; never stale-cache API.
  if(url.pathname === '/service-worker.js') return; // Always let browser update-check hit network.

  // Navigation must never return an old app version. Try fresh /mobile first.
  if(req.mode === 'navigate' || url.pathname === '/mobile' || url.pathname === '/'){
    event.respondWith((async()=>{
      const freshReq = new Request('/mobile?app_v='+VERSION+'&t='+Date.now(), {credentials:'same-origin', cache:'reload'});
      const fresh = await networkFirst(freshReq, '/mobile?app_v='+VERSION, 2800);
      if(fresh) return fresh;
      // Minimal shell only; never serve an old cached full app here.
      return new Response('<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#061327"><style>html,body{margin:0;background:#061327;color:#eef5ff;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;height:100%;display:grid;place-items:center}.c{text-align:center;padding:26px}.l{width:58px;height:58px;border-radius:18px;background:#ffbe3d;color:#061327;display:grid;place-items:center;font-weight:950;font-size:34px;margin:0 auto 14px}.b{height:7px;background:rgba(255,255,255,.10);border-radius:99px;overflow:hidden;margin-top:18px}.b i{display:block;height:100%;width:50%;background:linear-gradient(90deg,#348bff,#1fd5ff,#48e6ad);border-radius:99px;animation:a 1s infinite alternate}@keyframes a{to{transform:translateX(100%)}}</style></head><body><div class="c"><div class="l">₿</div><h2>Bitcoin Evidence</h2><p>Nieuwe app-versie wordt geladen…</p><div class="b"><i></i></div></div><script>setTimeout(()=>location.replace("/mobile?app_v='+VERSION+'&r="+Date.now()),900)</script></body></html>', {headers:{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'}});
    })());
    return;
  }

  // Versioned static assets: cache-first is okay because URL changes every build.
  if(url.pathname.startsWith('/static/') || url.pathname.endsWith('.webmanifest')){
    event.respondWith((async()=>{
      const cache = await caches.open(CACHE_NAME);
      const cached = await cache.match(req);
      if(cached) return cached;
      try{
        const res = await fetch(req, {cache:'reload'});
        if(res && res.ok) cache.put(req, res.clone()).catch(()=>{});
        return res;
      }catch(e){ return new Response('', {status:504}); }
    })());
  }
});
