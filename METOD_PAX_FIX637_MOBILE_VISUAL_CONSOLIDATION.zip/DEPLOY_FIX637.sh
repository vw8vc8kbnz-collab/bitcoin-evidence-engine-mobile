#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="/opt/adzaagt/metod-pax"
ENV_DIR="/etc/adzaagt/metod-pax"
ENV_FILE="$ENV_DIR/metod-pax.env"
SERVICE_FILE="/etc/systemd/system/metod-pax.service"
NGINX_SITE="/etc/nginx/sites-available/metod-pax-8790"

if [[ "${EUID}" -ne 0 ]]; then
  echo "Voer dit script met sudo uit." >&2
  exit 1
fi

mkdir -p "$ENV_DIR"
touch "$ENV_FILE"

# Preserve runtime data when this script is run from an unpacked .new release.
if [[ -d "$APP_DIR/app/jobs" && -d "$(pwd)/app" && "$(pwd)" != "$APP_DIR" ]]; then
  rm -rf "$(pwd)/app/jobs"
  cp -a "$APP_DIR/app/jobs" "$(pwd)/app/jobs"
fi

sed -i \
  '/^METOD_PORT=/d;/^PRODUCTION_HARDENING=/d;/^ADMIN_HASH_ONLY=/d;/^APP_ENV=/d;/^ADMIN_CREDENTIALS_FILE=/d;/^ADMIN_STAGING_OPEN=/d;/^PUBLIC_JOB_MAX_CONCURRENT=/d;/^PUBLIC_JOB_MAX_CONCURRENT_PER_IP=/d;/^ALLOWED_ADMIN_ORIGINS=/d;/^ALLOWED_ORIGINS=/d;/^PUBLIC_JSON_MAX_BYTES=/d;/^PUBLIC_JOB_TOTAL_QTY_LIMIT=/d;/^PUBLIC_JOB_MAX_AREA_LB=/d;/^JOB_OUTPUT_MAX_BYTES=/d' \
  "$ENV_FILE"
cat >> "$ENV_FILE" <<'ENVEOF'
METOD_PORT=8792
PRODUCTION_HARDENING=0
ADMIN_HASH_ONLY=0
APP_ENV=development
ADMIN_CREDENTIALS_FILE=/etc/adzaagt/metod-pax/admin_credentials.live.json
ADMIN_STAGING_OPEN=0
PUBLIC_JOB_MAX_CONCURRENT=1
PUBLIC_JOB_MAX_CONCURRENT_PER_IP=1
PUBLIC_JSON_MAX_BYTES=134217728
PUBLIC_JOB_TOTAL_QTY_LIMIT=250
PUBLIC_JOB_MAX_AREA_LB=250
JOB_OUTPUT_MAX_BYTES=536870912
ALLOWED_ADMIN_ORIGINS=http://51.195.102.180:8790
ALLOWED_ORIGINS=http://51.195.102.180:8790
ENVEOF

cat > "$SERVICE_FILE" <<'SVCEOF'
[Unit]
Description=METOD PAX Tool
After=network.target

[Service]
Type=simple
WorkingDirectory=/opt/adzaagt/metod-pax/app
EnvironmentFile=/etc/adzaagt/metod-pax/metod-pax.env
ExecStart=/usr/bin/python3 /opt/adzaagt/metod-pax/app/server_py.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
SVCEOF
rm -f /etc/systemd/system/metod-pax.service.d/10-http-test.conf

cat > "$NGINX_SITE" <<'NGINXEOF'
server {
    listen 8790;
    listen [::]:8790;
    server_name 51.195.102.180 _;
    client_max_body_size 160m;

    location / {
        proxy_pass http://127.0.0.1:8792;
        proxy_http_version 1.1;
        proxy_set_header Host $http_host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header X-Forwarded-Host $http_host;
        proxy_set_header X-Forwarded-Port $server_port;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_connect_timeout 30s;
        proxy_send_timeout 1800s;
        proxy_read_timeout 1800s;
        proxy_buffering off;
    }
}
NGINXEOF
ln -sfn "$NGINX_SITE" /etc/nginx/sites-enabled/metod-pax-8790

python3 -m py_compile "$APP_DIR/app/server_py.py"
systemctl daemon-reload
systemctl enable metod-pax.service >/dev/null
systemctl restart metod-pax.service
nginx -t
systemctl reload nginx
sleep 3

curl -fsSI http://127.0.0.1:8792/toolA.html >/dev/null
curl -fsSI http://127.0.0.1:8792/admin/ >/dev/null
curl -fsSI http://51.195.102.180:8790/toolA.html >/dev/null

echo "FIX637 actief. Open: http://51.195.102.180:8790/toolA.html?v=637"
echo "Admin: http://51.195.102.180:8790/admin/?v=637"
