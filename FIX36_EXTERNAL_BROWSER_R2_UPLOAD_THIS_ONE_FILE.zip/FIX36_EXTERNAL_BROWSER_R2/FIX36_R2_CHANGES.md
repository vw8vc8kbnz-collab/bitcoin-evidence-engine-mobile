# FIX36 R2 — auditspoor

## Aanleiding

De ontvangen R1-run van 10 september 2026 bevat 12/18 geslaagde scenario's en
121/130 geslaagde verplichte controles. Alle ZIP-checksums en de koppeling aan
FIX36 zijn gecontroleerd. Het native rapport heeft SHA256
`67b1f2933db6918905e722a1a02b250aec4dba1b247f4e7306d107c6d7fa59ae`.
Dit rapport wordt niet aangepast of achteraf als PASS aangemerkt.

| Uitkomst R1 | Bewijs en aanpassing R2 |
| --- | --- |
| Mobiele panelen | Alleen oude FIX30-buildverwachting faalt; actuele FIX31-componentlabel is in de onveranderde applicatiebron bevestigd. |
| Mobiele nerf | Alleen oude FIX30-buildverwachting faalt; actuele FIX33-componentlabel is in de onveranderde applicatiebron bevestigd. |
| Desktop/iPhone verzenden en Admin-download | Alle functionele controles slagen. Alleen sealedFileCount verschilt: 13 versus 15. Bronvergelijking toont de toegevoegde prijsdocumenten op hoofdjob en materiaaljob. Een echte lokale serverjob bevestigt beide bestanden en geslaagde downloads. R2 verifieert dat opnieuw per browserprofiel en vergelijkt ook de volledige overige bestandsinventaris. |
| WebKit verversen, golden | De geannuleerde DXF-request volgt op herladen terwijl de progressieve laadlus nog niet volledig klaar was. De oude 250-ms-netwerkbarrière kon tussentijdse rekenpauzes aanzien voor voltooiing. R2 vereist alle manifesttemplates in de template-Map vóór en na reload, plus afgeronde requests. De VPS-run moet bevestigen dat dit de gemelde fout oplost; echte laadfouten blijven FAIL. |

## Bron- en testidentiteit

- Complete applicatie candidate.zip SHA256:
  `99470896de783030bf08afa83020bfc82b7a9d5cff51041b8428edf5b21422b2`.
- Applicatiemanifest SHA256:
  `67dc33e9e86f47214e8fb01d4033a5f27c84e137754d6339bfa9df24eefc7b4a`.
- Golden ZIP SHA256:
  `d3e8656d8d7d5a581a8186ef8fe2c91c19b2137a8654b2f2874497dd85255e62`.
- Oorspronkelijke R4-broncommit:
  `1855dce5bf2ee112e88b84a6af303f6d39b0289e`.
- R2 wijzigt testcode, testverwachtingen, diagnose en bewijsaflevering. Geen
  applicatiebestand is gewijzigd. Alle 18 scenario's en 130 oude verplichte
  controle-ID's blijven behouden; acht nieuwe controles zijn toegevoegd.

De nieuwe regels wonen in één testmodule fix36_browser_contract.js. De
driver geeft de expliciete rol golden of candidate door; de rol wordt niet
afgeleid uit aangetroffen bestanden. Bestandsverschillen worden daardoor
niet automatisch als toegestane versieverschillen beschouwd.

R4_RUNNER_ADAPTATION.patch bewaart de oorspronkelijke R1-aanpassingen aan de
Python-runner. FIX36_R2_TEST_ADAPTATION.patch toont de R2-verschillen ten
opzichte van R1 in uitvoeringscode, contracten en launcher. Nieuwe testmodules
en tests worden integraal meegeleverd en door het pakketmanifest gedekt.

## Validatiegrens

Een lokale serverjob bevestigde 15 bestanden, twee gedownloade prijsdocumenten
en 13 gedeelde bestandsidentiteiten. Dit bewijst de serverkoppeling voor die
synthetische testjob; het is geen browserrun of algemene prijsacceptatie.

Unit-tests controleren ook dat ontbrekende/vervangen bestanden, verkeerde
jobs, ontbrekende of beschadigde prijsdocumenten, foutieve bedragen en
vervalste PASS-ledgers niet slagen. Het positieve synthetische rapport in de
validator-tests bestaat alleen in het geheugen en wordt niet als browserbewijs
afgeleverd.

De oude FIX33-vrijgavecontractaansluiting, verdere Admin-/iPhone-controles,
productie-inrichting en onafhankelijke acceptatie blijven aparte stappen.
