# FIX36 externe browsertest R2

Dit pakket test de complete, eerder geleverde FIX36-applicatie. `candidate.zip`
is byte voor byte dezelfde applicatie. De launcher installeert niets, herstart
geen service en heeft geen toegang tot de actieve applicatie of klantgegevens.

## Starten

Upload `FIX36_EXTERNAL_BROWSER_R2_UPLOAD_THIS_ONE_FILE.zip` naar de hoofdmap van
de bestaande GitHub-repository, op `main`. Gebruik daarna de afzonderlijk
geleverde `TERMIUS_FIX36_BROWSER_R2_START.txt`. De opdracht gebruikt de bewaarde
golden-ZIP uit de eerdere run van 10 september en controleert opnieuw de SHA256.
De oude run en de eerder ontvangen FAIL blijven behouden.

De test loopt los van de SSH-sessie door. De startopdracht geeft daarom snel
weer een shellprompt. Gebruik `TERMIUS_FIX36_BROWSER_R2_STATUS.txt` voor de
actuele fase en de laatste logregels. Start niet tegelijkertijd een tweede run.

Na afloop staat de oorspronkelijke bewijs-ZIP in de runmap. De launcher maakt
ook een identieke kopie in `/home/ubuntu`, met naam
`FIX36_BROWSER_R2_EVIDENCE_<datum>_<run-id>.zip`. Ververs de SFTP-bestandenlijst,
download deze ZIP en stuur die terug. Het statusveld `evidenceDownloadCopy`
vermeldt de kopie; `evidenceZip` vermeldt altijd het oorspronkelijke bestand.
Een probleem met de kopie wordt apart vermeld en verwijdert het origineel niet.

## Wat R2 corrigeert

- Exacte FIX36-componentlabels voor panelen en nerf-preview, gecontroleerd tegen
  de vastgepinde applicatiebron.
- De ververs-test wacht tot alle manifesttemplates daadwerkelijk zijn geparseerd,
  en daarna tot de DXF-verzoeken zijn afgerond. Een rustige netwerkperiode alleen
  was onvoldoende bij de progressieve laadlus. Geannuleerde verzoeken en
  browserfouten blijven fouten; er wordt geen poging automatisch overgedaan.
- De volledige bestandsinventaris wordt per hoofdjob en materiaaljob bewaard.
  Alle gedeelde bestanden worden vergeleken op rol, pad en soort. Dubbele
  bestanden, ongeldige paden, lege bestanden of verkeerde jobkoppelingen falen.
- Alleen de twee concrete FIX36-toevoegingen `output/calculation_pricing.json`
  worden apart beoordeeld. Beide moeten via de echte Admin-route downloadbaar
  zijn, de manifestgrootte hebben en geldige schema-, job- en bedraggegevens
  bevatten. Het hoofdbedrag moet met de autoritatieve Admin-prijs overeenkomen.
  Het ruwe aantal 15 blijft in het bewijs staan; de 13 gedeelde bestanden worden
  afzonderlijk vergeleken. Andere verschillen worden niet weggefilterd.
- De downloadlimiet blijft exact: één bestandsdownload voor de referentie,
  drie voor FIX36 (één DXF plus twee prijsdocumenten).
- Een PASS wordt opnieuw gecontroleerd op alle rapporten, profielen, afzonderlijke
  controles, actuele tijdstippen, bronhashes en daadwerkelijk gestarte engines.

Alle oorspronkelijke 18 scenario's, profielen en 130 verplichte controle-ID's
blijven aanwezig. R2 voegt acht verplichte controles toe: totaal **138**.
De oude `fix30-...` scenario-ID's blijven staan voor traceerbaarheid; hun
componentverwachtingen zijn nu expliciet voor FIX36.

## Uitvoering en bewijs

De bestaande vastgepinde Playwright-image, Node 24 en Playwright 1.62.0 blijven
gelijk. Alleen de installatie van de vastgepinde npm-afhankelijkheden heeft
netwerktoegang. De browsercontainer heeft `--network none`, geen hostpoorten,
alleen tijdelijke testgegevens en een alleen-lezen applicatiepakket.
Limieten: 1,25 CPU, 1536 MiB RAM, 512 processen, 90 minuten totaal en 10 minuten
per scenario. Chromium en WebKit zijn beide verplicht.

`LOCAL_VALIDATION.json` beschrijft uitsluitend lokale controles van de testcode,
rapportvalidatie en een echte lokale serverjob. Dit is geen nieuwe browser-PASS.
De testfixtures met synthetische rapporten zijn alleen validator-unit-tests.

Herkomst en wijzigingen staan in `FIX36_R2_CHANGES.md`, de twee patchbestanden
en `oracle/FIX36_R4_PROVENANCE.json`. De originele R1-foutuitvoer blijft als
ongewijzigde ZIP bijgevoegd onder `prior-evidence/`.

## Resterende vrijgave

Dit is een apart FIX36 R2-browsercontract met 18 scenario's en 138 controles.
Het wordt niet omgezet naar het oudere FIX33-contract met 15 scenario's.
Die aansluiting moet bij de uiteindelijke externe vrijgave expliciet worden
vastgelegd. `productionGo` en `releaseEligible` blijven `false`.

De browsertest vervangt geen fysieke iPhone-toetsenbordcontrole, controle van
alle Admin-onderdelen en Inbox-acties, schone-serverinstallatie, herstelproef,
domein/HTTPS, onafhankelijke beveiligingsaudit of praktische DXF/CAM-acceptatie.
