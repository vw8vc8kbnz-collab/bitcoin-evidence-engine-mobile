"""Synthetic schema tests only. No result here is real browser PASS evidence."""
from copy import deepcopy
from datetime import datetime, timedelta, timezone
import json
from pathlib import Path
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import run_browser as runner
from r9n_external_evidence_gate import evidence_digest


class ReportValidationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='fix36-synthetic-schema-')
        self.addCleanup(self.temp.cleanup)
        self.candidate = Path(self.temp.name) / 'candidate'
        self.golden = Path(self.temp.name) / 'golden'
        for root in (self.candidate, self.golden):
            root.mkdir()
            (root / 'SHA256SUMS.txt').write_text('SYNTHETIC MANIFEST FOR VALIDATOR UNIT TEST ONLY\n')
        self.registry = json.loads((ROOT / 'oracle/contracts/R9A_BROWSER_FIXTURES.json').read_text())
        self.started = datetime.now(timezone.utc) - timedelta(seconds=3)
        fixtures = []
        for spec in self.registry['fixtures']:
            assertions = [dict(id=name, status='PASS', actualValue=True, expectedValue=True,
                               actualDigest=evidence_digest(True), expectedDigest=evidence_digest(True))
                          for name in spec['requiredAssertionIds']]
            sides = ['candidate'] if spec['requiredEvidenceClass'] == 'candidate-conformance' else ['golden', 'candidate']
            profiles = {profile: {side: {'assertions': [{'id': name, 'ok': True} for name in spec['requiredAssertionIds']],
                                        'exception': None, 'pageErrorCount': 0, 'pageErrors': []}
                                  for side in sides} for profile in spec['profiles']}
            evidence = {'assertionResults': assertions, 'profilesExecuted': spec['profiles'], 'profiles': profiles}
            fixtures.append({'id': spec['id'], 'status': 'PASS', 'evidenceClass': spec['requiredEvidenceClass'],
                             'enginesPassed': ['chromium', 'webkit'], 'profilesPassed': spec['profiles'],
                             'assertions': len(assertions), 'assertionResults': assertions,
                             'evidence': evidence, 'evidenceSha256': evidence_digest(evidence)})
        tree = 'a' * 64
        self.report = {
            'schemaVersion': 2, 'status': 'PASS', 'blockers': [],
            'startedAtUtc': (self.started + timedelta(seconds=1)).isoformat(),
            'finishedAtUtc': (self.started + timedelta(seconds=2)).isoformat(),
            'fixtureCount': 18, 'passedFixtureCount': 18, 'assertionsTotal': 138,
            'failedFixtureCount': 0, 'skippedFixtureCount': 0, 'blockedFixtureCount': 0,
            'enginesPassed': ['chromium', 'webkit'], 'fixtures': fixtures,
            'registry': {'sha256': runner.REGISTRY_SHA},
            'bindings': {'dependencySha256': {p: runner.digest(ROOT / 'oracle' / p) for p in self.registry['oracleDependencies']}},
            'sourceMutationCheck': {'unchanged': True, 'candidateBeforeSha256': tree, 'candidateAfterSha256': tree,
                                    'goldenBeforeSha256': tree, 'goldenAfterSha256': tree},
            'runtimeProbe': {'status': 'PASS', 'playwrightPackageVersion': '1.62.0', 'nodeVersion': 'v24.18.0',
                             'engines': {engine: {'launchable': True, 'executableSha256': 'b' * 64} for engine in ['chromium', 'webkit']}}
        }
        for label, release in [('candidate', self.candidate), ('golden', self.golden)]:
            self.report[label + 'Release'] = {'manifestSha256': runner.digest(release / 'SHA256SUMS.txt'), 'sourceTreeSha256': tree}
        for label, relative in [('runner', 'tools/r9a_browser_oracle.py'), ('driver', 'tools/r9a_browser_driver.js')]:
            self.report[label] = {'sha256': runner.digest(ROOT / 'oracle' / relative)}

    def validate(self, report, code=0):
        runner.validate_current_pass(report, self.registry, self.candidate, self.golden, self.started, code)

    def test_synthetic_well_formed_ledger_is_accepted(self):
        self.validate(self.report)

    def test_invalid_pass_cases_are_rejected(self):
        mutations = {
            'old-130-assertion-contract': lambda r: r.update(assertionsTotal=130),
            'duplicate-fixture': lambda r: r['fixtures'].__setitem__(1, deepcopy(r['fixtures'][0])),
            'failed-ledger-check': lambda r: r['fixtures'][0]['assertionResults'][0].update(status='FAIL'),
            'forged-actual-value': lambda r: r['fixtures'][0]['assertionResults'][0].update(actualValue=False),
            'source-mutation': lambda r: r['sourceMutationCheck'].update(candidateAfterSha256='c' * 64),
            'missing-webkit': lambda r: r['runtimeProbe']['engines']['webkit'].update(launchable=False),
            'old-observation': lambda r: r.update(startedAtUtc=(self.started-timedelta(days=1)).isoformat()),
            'wrong-registry': lambda r: r['registry'].update(sha256='0' * 64),
            'wrong-candidate-manifest': lambda r: r['candidateRelease'].update(manifestSha256='0' * 64),
            'changed-contract-helper': lambda r: r['bindings']['dependencySha256'].update({'tools/fix36_browser_contract.js': '0' * 64}),
        }
        for name, mutate in mutations.items():
            with self.subTest(name=name):
                report = deepcopy(self.report); mutate(report)
                with self.assertRaises(ValueError): self.validate(report)

    def test_raw_failures_cannot_hide_behind_rehashed_passing_ledger(self):
        for defect in ['failed-check', 'duplicate-check', 'exception', 'page-error', 'missing-profile']:
            with self.subTest(defect=defect):
                report = deepcopy(self.report)
                fixture = report['fixtures'][0]
                profiles = fixture['evidence']['profiles']
                profile_id = next(iter(profiles))
                raw = profiles[profile_id]['candidate']
                if defect == 'failed-check': raw['assertions'][0]['ok'] = False
                elif defect == 'duplicate-check': raw['assertions'].append(deepcopy(raw['assertions'][0]))
                elif defect == 'exception': raw['exception'] = 'Browser scenario crashed'
                elif defect == 'page-error': raw.update(pageErrorCount=1, pageErrors=['Unhandled error'])
                else: del profiles[profile_id]
                fixture['evidenceSha256'] = evidence_digest(fixture['evidence'])
                with self.assertRaises(ValueError): self.validate(report)


if __name__ == '__main__':
    unittest.main()
