'use strict';

const assert = require('node:assert/strict');
const test = require('node:test');
const vm = require('node:vm');
const { EventEmitter } = require('node:events');
const fs = require('node:fs');
const path = require('node:path');
const contract = require('../oracle/tools/fix36_browser_contract');
const driver = require('../oracle/tools/r9a_browser_driver');
const probe = require('./fixtures/candidate_inventory_probe.json');
const copy = value => structuredClone(value);
const inventory = () => contract.inventoryEvidence(copy(probe.files), probe.parentJobId, 'candidate');
const pricing = () => contract.pricingEvidence(copy(probe.downloads), inventory(), probe.authoritativeTotal);
const ready = (files, state) => vm.runInNewContext(
  `(${contract.browserTemplatesReady.toString()})(files)`, { files, window: { state }, Map }
);

test('the real local server probe has 15 files, 13 shared paths and two verified pricing downloads', () => {
  assert.equal(probe.kind, 'LOCAL_REAL_SERVER_PROBE_NOT_BROWSER_EVIDENCE');
  assert.equal(inventory().rawCount, 15);
  assert.equal(inventory().comparable.length, 13);
  assert.equal(pricing().downloads.length, 2);
  assert.equal(pricing().valid, true);
});

test('only the documented pricing additions are excluded from semantic comparison', () => {
  const files = probe.files.filter(item => item.rel !== contract.PRICING_REL);
  // Deliberately synthetic reference projection; this is not golden browser evidence.
  const reference = contract.inventoryEvidence(files, probe.parentJobId, 'golden');
  const candidate = { sealedFileCount: 15, sealedFiles: inventory(), pricingSnapshots: pricing(), thankYouVisible: true };
  const golden = { sealedFileCount: 13, sealedFiles: reference,
    pricingSnapshots: contract.pricingEvidence([], reference, 0), thankYouVisible: true };
  for (const scenario of ['fullUiCheckout', 'adminProjectionDownload']) {
    assert.deepEqual(driver.normalizeScenarioObservation(scenario, candidate), driver.normalizeScenarioObservation(scenario, golden));
    const broken = copy(candidate);
    broken.sealedFiles.comparable[0].rel = 'output/renamed-required-file.txt';
    assert.notDeepEqual(driver.normalizeScenarioObservation(scenario, broken), driver.normalizeScenarioObservation(scenario, golden));
    broken.thankYouVisible = false;
    assert.notDeepEqual(driver.normalizeScenarioObservation(scenario, broken), driver.normalizeScenarioObservation(scenario, golden));
  }
});

for (const [name, mutate] of [
  ['missing snapshot', files => files.splice(files.findIndex(item => item.rel === contract.PRICING_REL), 1)],
  ['renamed snapshot', files => { files.find(item => item.rel === contract.PRICING_REL).rel += '.bak'; }],
  ['unrelated job', files => { files[0].jobId = 'other-job'; }],
  ['duplicate file identity', files => files.push(copy(files[0]))],
  ['empty file', files => { files[0].size = 0; }],
  ['path traversal', files => { files[0].rel = 'output/../secret'; }],
  ['extra material job', files => { files[0].jobId = probe.parentJobId + '__mat_002'; }]
]) test('inventory rejects ' + name, () => {
  const files = copy(probe.files); mutate(files);
  assert.throws(() => contract.inventoryEvidence(files, probe.parentJobId, 'candidate'));
});

test('a same-count unrelated file substitution cannot compare equal', () => {
  const files = copy(probe.files);
  files.find(item => item.rel.endsWith('links.json')).rel = 'output/unexpected.json';
  assert.notDeepEqual(contract.inventoryEvidence(files, probe.parentJobId, 'candidate').comparable, inventory().comparable);
});

test('an unexpected snapshot in golden is rejected', () => {
  assert.throws(() => contract.inventoryEvidence(probe.files, probe.parentJobId, 'golden'));
});

for (const [name, mutate] of [
  ['missing download', downloads => downloads.pop()],
  ['duplicate download', downloads => { downloads[1] = copy(downloads[0]); }],
  ['denied download', downloads => { downloads[0].status = 403; }],
  ['truncated body', downloads => { downloads[0].text = downloads[0].text.slice(0, -1); }],
  ['wrong body job', downloads => { downloads[0].text = downloads[0].text.replace(probe.parentJobId, 'x'.repeat(probe.parentJobId.length)); }]
]) test('pricing rejects ' + name, () => {
  const downloads = copy(probe.downloads); mutate(downloads);
  assert.throws(() => contract.pricingEvidence(downloads, inventory(), probe.authoritativeTotal));
});

for (const [name, mutate] of [
  ['wrong schema', body => { body.schemaVersion = 2; }],
  ['missing amount', body => { delete body.summary.vatAmount; }],
  ['boolean amount', body => { body.summary.vatAmount = true; }],
  ['negative amount', body => { body.summary.edgeBandTotal = -1; }],
  ['unreconciled total', body => { body.summary.totalInclVat += 1; }]
]) test('pricing rejects ' + name + ' even with an updated byte count', () => {
  const downloads = copy(probe.downloads), inv = inventory();
  const body = JSON.parse(downloads[0].text); mutate(body);
  downloads[0].text = JSON.stringify(body);
  inv.inventory.find(item => item.jobId === downloads[0].jobId && item.rel === contract.PRICING_REL).bytes = Buffer.byteLength(downloads[0].text);
  assert.throws(() => contract.pricingEvidence(downloads, inv, probe.authoritativeTotal));
});

test('pricing must match the current authoritative total', () => {
  assert.throws(() => contract.pricingEvidence(probe.downloads, inventory(), probe.authoritativeTotal + 1));
});

test('templates are not ready merely because some requests have completed', () => {
  const state = { embedIndex: { a: 'a.dxf', b: 'b.dxf' }, templates: new Map([['a', {}]]) };
  assert.equal(ready(['a.dxf', 'b.dxf'], state), false);
  state.templates.set('b', {});
  assert.equal(ready(['a.dxf', 'b.dxf'], state), true);
  assert.equal(ready(['a.dxf', 'missing.dxf'], state), false);
  assert.equal(ready([], state), false);
});

test('quiescence continues to reject cancelled DXF requests', async () => {
  const page = new EventEmitter();
  const network = driver.networkCollector(page, { value: '' });
  const request = { method: () => 'GET', url: () => 'http://127.0.0.1/embedded_dxfs/a.dxf',
    resourceType: () => 'fetch', headers: () => ({}), postData: () => null,
    failure: () => ({ errorText: 'Load request cancelled' }) };
  page.emit('request', request); page.emit('requestfailed', request);
  await assert.rejects(network.waitForQuiescence({ routePrefix: '/embedded_dxfs/', timeoutMs: 100, idleMs: 1 }), /Load request cancelled/);
});

test('refresh barrier waits for parsing before evaluating network quiescence', async () => {
  const calls = [], assertions = driver.assertionCollector();
  const page = {
    evaluate: async fn => fn === contract.browserTemplatesReady ? true : ['a.dxf', 'b.dxf'],
    waitForFunction: async fn => { assert.equal(fn, contract.browserTemplatesReady); calls.push('all-parsed'); }
  };
  const network = { waitForQuiescence: async () => { calls.push('network-complete'); return { completedCount: 2 }; } };
  const result = await driver.waitForAllEmbeddedTemplates(page, network, assertions, 'before-refresh');
  assert.deepEqual(calls, ['all-parsed', 'network-complete']);
  assert.equal(result.allTemplatesParsed, true);
  assert.equal(assertions.assertions[0].id, 'templates-complete-before-refresh');
});

test('all 18 fixtures require both engines and exactly 138 unique required assertions in total', () => {
  const registry = JSON.parse(fs.readFileSync(path.join(__dirname, '../oracle/contracts/R9A_BROWSER_FIXTURES.json')));
  assert.equal(registry.fixtures.length, 18);
  assert.equal(registry.fixtures.reduce((sum, fixture) => sum + fixture.requiredAssertionIds.length, 0), 138);
  for (const fixture of registry.fixtures) {
    assert.equal(new Set(fixture.requiredAssertionIds).size, fixture.requiredAssertionIds.length);
    assert.deepEqual([...new Set(fixture.profiles.map(id => registry.profiles[id].engine))].sort(), ['chromium', 'webkit']);
  }
});
