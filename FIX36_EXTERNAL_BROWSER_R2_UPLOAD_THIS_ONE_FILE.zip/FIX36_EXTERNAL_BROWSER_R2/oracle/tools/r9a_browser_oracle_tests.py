#!/usr/bin/env python3
from __future__ import annotations

import importlib.util
import contextlib
import json
import os
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path


WORKSPACE = Path(__file__).resolve().parents[1]
RUNNER_PATH = WORKSPACE / "tools" / "r9a_browser_oracle.py"
SPEC = importlib.util.spec_from_file_location("r9a_browser_oracle", RUNNER_PATH)
assert SPEC and SPEC.loader
ORACLE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = ORACLE
SPEC.loader.exec_module(ORACLE)


class BrowserOracleContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.registry_path = WORKSPACE / "contracts" / "R9A_BROWSER_FIXTURES.json"
        cls.registry = json.loads(cls.registry_path.read_text(encoding="utf-8"))

    def test_registry_is_fail_closed_and_covers_every_flow(self) -> None:
        ORACLE.validate_registry(self.registry)
        self.assertGreaterEqual(len(self.registry["fixtures"]), 12)
        covered = {flow for fixture in self.registry["fixtures"] for flow in fixture["criticalFlows"]}
        self.assertEqual(covered, set(ORACLE.REQUIRED_FLOWS))
        self.assertEqual(self.registry["requiredEngines"], ["webkit", "chromium"])
        for fixture in self.registry["fixtures"]:
            self.assertEqual(len(fixture["requiredAssertionIds"]), len(set(fixture["requiredAssertionIds"])))
            engines = {self.registry["profiles"][profile]["engine"] for profile in fixture["profiles"]}
            self.assertEqual(engines, {"webkit", "chromium"})

    def test_full_click_path_exists_for_desktop_and_iphone_in_each_engine(self) -> None:
        full = [fixture for fixture in self.registry["fixtures"] if fixture["scenario"] == "fullUiCheckout"]
        profiles = {profile for fixture in full for profile in fixture["profiles"]}
        self.assertEqual(
            profiles,
            {"chromium-desktop", "webkit-desktop", "chromium-iphone", "webkit-iphone"},
        )

    def test_admin_split_candidate_conformance_runs_in_every_profile(self) -> None:
        fixtures = [
            fixture for fixture in self.registry["fixtures"]
            if fixture["scenario"] == "adminPresentationSessionAssets"
        ]
        self.assertEqual(len(fixtures), 1)
        fixture = fixtures[0]
        self.assertEqual(fixture["requiredEvidenceClass"], "candidate-conformance")
        self.assertEqual(
            set(fixture["profiles"]),
            {"chromium-desktop", "webkit-desktop", "chromium-iphone", "webkit-iphone"},
        )
        self.assertNotIn("semantic-equality-per-profile", fixture["requiredAssertionIds"])
        driver = (WORKSPACE / "tools" / "r9a_browser_driver.js").read_text(encoding="utf-8")
        self.assertIn("fixture.requiredEvidenceClass === 'candidate-conformance'", driver)
        self.assertIn("scenarioAdminPresentationSessionAssets", driver)

    def test_reset_remediation_is_candidate_conformance_not_golden_equivalence(self) -> None:
        fixtures = [
            fixture for fixture in self.registry["fixtures"]
            if fixture["scenario"] == "newConfigurationReset"
        ]
        self.assertEqual(len(fixtures), 1)
        fixture = fixtures[0]
        self.assertEqual(fixture["requiredEvidenceClass"], "candidate-conformance")
        self.assertNotIn("semantic-equality-per-profile", fixture["requiredAssertionIds"])
        self.assertEqual(set(fixture["profiles"]), {"chromium-iphone", "webkit-iphone"})

    def test_fix30_mobile_regressions_are_candidate_bound_in_both_engines(self) -> None:
        expected = {
            "fix30MobileMaterialPanelProjection": {
                "fix30-two-material-groups-visible",
                "fix30-other-panel-owned-and-visible",
            },
            "fix30MobileOptimizationCheckout": {
                "fix30-optimizer-progress-reached-100",
                "fix30-checkout-review-snapshot-complete",
            },
            "fix30MobileGrainDiscoveryReorder": {
                "fix30-grain-preview-cta-copy",
                "fix30-grain-order-changed-via-mobile-control",
            },
        }
        fixtures = {
            fixture["scenario"]: fixture
            for fixture in self.registry["fixtures"]
            if fixture["scenario"] in expected
        }
        self.assertEqual(set(fixtures), set(expected))
        for scenario, required_ids in expected.items():
            fixture = fixtures[scenario]
            self.assertEqual(fixture["requiredEvidenceClass"], "candidate-conformance")
            self.assertEqual(set(fixture["profiles"]), {"chromium-iphone", "webkit-iphone"})
            self.assertNotIn("semantic-equality-per-profile", fixture["requiredAssertionIds"])
            self.assertTrue(required_ids.issubset(set(fixture["requiredAssertionIds"])))

        driver = (WORKSPACE / "tools" / "r9a_browser_driver.js").read_text(encoding="utf-8")
        self.assertIn("scenarioFix30MobileMaterialPanelProjection", driver)
        self.assertIn("scenarioFix30MobileOptimizationCheckout", driver)
        self.assertIn("scenarioFix30MobileGrainDiscoveryReorder", driver)
        self.assertIn("MutationObserver", driver)

    def test_direct_job_fixtures_follow_current_idempotency_contract(self) -> None:
        driver = (WORKSPACE / "tools" / "r9a_browser_driver.js").read_text(encoding="utf-8")
        self.assertIn("'Idempotency-Key': idempotencyKeyValue", driver)
        self.assertIn("function requireAcceptedJob(created)", driver)
        self.assertIn("job admission failed (HTTP", driver)
        self.assertNotIn("jobId: created.body.jobId || created.body.parentJobId", driver)

        fixture = next(
            item for item in self.registry["fixtures"]
            if item["scenario"] == "jobCreatePollPricing"
        )
        self.assertIn("job-idempotency-key-applied", fixture["requiredAssertionIds"])

    def test_release_specific_pricing_is_compared_by_contract_not_exact_total(self) -> None:
        driver = (WORKSPACE / "tools" / "r9a_browser_driver.js").read_text(encoding="utf-8")
        self.assertIn("function normalizeScenarioObservation(scenario, observation)", driver)
        self.assertIn("scenario !== 'jobCreatePollPricing'", driver)
        self.assertIn("'<positive-authoritative-total>'", driver)
        self.assertIn("totalInclVat: total", driver)
        fixture = next(
            item for item in self.registry["fixtures"]
            if item["scenario"] == "jobCreatePollPricing"
        )
        self.assertIn("authoritative-price-positive", fixture["requiredAssertionIds"])
        self.assertIn("semantic-equality-per-profile", fixture["requiredAssertionIds"])

    def test_cancellation_binds_real_process_hold_and_public_processing_state(self) -> None:
        driver = (WORKSPACE / "tools" / "r9a_browser_driver.js").read_text(encoding="utf-8")
        self.assertIn("async function waitForControlledOptimizerHold(rawRoot, timeoutMs)", driver)
        self.assertIn("await waitForControlledOptimizerHold(optimizerHoldRoot, 30000)", driver)
        self.assertNotIn("requiredProgressMessage: 'R9A optimizer active hold'", driver)
        fixture = next(
            item for item in self.registry["fixtures"]
            if item["scenario"] == "jobAndRequestCancellation"
        )
        self.assertIn("controlled-optimizer-process-entered", fixture["requiredAssertionIds"])
        self.assertIn("active-processing-observed", fixture["requiredAssertionIds"])

    def test_grain_network_contracts_match_each_delivery_boundary(self) -> None:
        fixtures = {
            item["id"]: item
            for item in self.registry["fixtures"]
            if item["scenario"] in {"continuousGrainPreview", "fix30MobileGrainDiscoveryReorder"}
        }
        self.assertEqual(
            fixtures["continuous-grain-iphone-preview"]["networkExpectations"],
            {"GET /api/materials/library": {"minimum": 1, "maximum": 3}},
        )
        self.assertEqual(
            fixtures["continuous-grain-desktop-preview"]["networkExpectations"],
            {"GET /api/materials/library": {"minimum": 1, "maximum": 3}},
        )
        self.assertEqual(
            fixtures["fix30-mobile-grain-discovery-reorder"]["networkExpectations"][
                "GET /tool-a/components/grain-preview.js"
            ],
            {"minimum": 1, "maximum": 2},
        )

    def test_semantic_observations_ignore_only_compatible_ui_extensions(self) -> None:
        driver = (WORKSPACE / "tools" / "r9a_browser_driver.js").read_text(encoding="utf-8")
        self.assertIn("visibleBox: snapshot.preview.width > 150", driver)
        self.assertIn("const requiredCommittedFields = [", driver)
        self.assertIn("customer-required-fields-complete", driver)
        self.assertNotIn("return snapshot;\n}\n\nasync function scenarioCustomerSnapshotRefresh", driver)

    def test_mobile_fixture_activates_visible_controls_without_overlap(self) -> None:
        driver = (WORKSPACE / "tools" / "r9a_browser_driver.js").read_text(encoding="utf-8")
        self.assertNotIn("page.locator('#extraEdgeTop').check()", driver)
        self.assertIn("async function setCheckboxThroughVisibleLabel", driver)
        self.assertIn("setCheckboxThroughVisibleLabel(page, profile, '#extraEdgeTop', true)", driver)
        self.assertIn("drawer.classList.contains('fix660DrawerClosed')", driver)
        self.assertGreaterEqual(
            driver.count("await activate(handle, profile);"),
            3,
            "the preview is opened, collapsed before reorder, and reopened for verification",
        )

    def test_dependency_hashes_bind_every_transitive_file(self) -> None:
        actual = ORACLE.dependency_hashes(WORKSPACE, self.registry)
        self.assertEqual(list(actual), self.registry["oracleDependencies"])
        self.assertTrue(all(len(value) == 64 for value in actual.values()))

    def test_canonical_evidence_hash_and_report_fixture_binding(self) -> None:
        evidence = {"z": [2, 1], "a": {"é": True}}
        self.assertEqual(ORACLE.evidence_sha256(evidence), ORACLE.evidence_sha256({"a": {"é": True}, "z": [2, 1]}))
        fixture = self.registry["fixtures"][0]
        assertion_results = [{"id": fixture["requiredAssertionIds"][0], "status": "PASS", "kind": "dom"}]
        item = ORACLE.report_fixture(fixture, "PASS", ["webkit", "chromium"], 1, evidence, assertion_results, fixture["profiles"])
        self.assertEqual(item["evidenceSha256"], ORACLE.evidence_sha256(item["evidence"]))
        self.assertEqual(item["evidence"]["assertionResults"], assertion_results)
        self.assertEqual(item["assertionResults"], assertion_results)
        self.assertEqual(set(item["profilesPassed"]), set(fixture["profiles"]))

    def test_atomic_report_is_private(self) -> None:
        with tempfile.TemporaryDirectory(prefix="r9a-browser-test-") as name:
            target = Path(name) / "report.json"
            ORACLE.atomic_json(target, {"status": "NO_GO"})
            self.assertEqual(os.stat(target).st_mode & 0o777, 0o600)
            self.assertEqual(json.loads(target.read_text(encoding="utf-8"))["status"], "NO_GO")

    def test_isolated_state_copies_release_owned_active_pricing(self) -> None:
        with tempfile.TemporaryDirectory(prefix="r9a-browser-pricing-test-") as name:
            root = Path(name)
            release = root / "release"
            state = root / "state"
            credentials = root / "credentials.json"
            pricing_seed = release / "app" / "config" / "pricing_active.json"
            pricing_seed.parent.mkdir(parents=True)
            pricing_seed.write_text(
                json.dumps(
                    {
                        "pricing": {"pricingVersion": "browser-fixture"},
                        "sellPricing": {"cncCostPerSheet": 1.0},
                        "pricingModel": "catalog_sell_price_incl_vat_v2",
                    },
                    ensure_ascii=False,
                ),
                encoding="utf-8",
            )

            ORACLE.seed_state(state, credentials, release)

            pricing_target = state / "config" / "pricing_active.json"
            self.assertEqual(pricing_target.read_bytes(), pricing_seed.read_bytes())
            self.assertEqual(os.stat(pricing_target).st_mode & 0o777, 0o600)

    def test_isolated_state_rejects_missing_release_pricing(self) -> None:
        with tempfile.TemporaryDirectory(prefix="r9a-browser-pricing-test-") as name:
            root = Path(name)
            with self.assertRaisesRegex(ORACLE.OracleError, "regular release pricing seed is missing"):
                ORACLE.seed_state(root / "state", root / "credentials.json", root / "release")

    def test_private_optimizer_hold_supports_read_only_golden_copy(self) -> None:
        with tempfile.TemporaryDirectory(prefix="r9a-browser-hold-test-") as name:
            root = Path(name)
            app = root / "app"
            app.mkdir()
            optimizer = app / "dxf_nesting_optimizer.py"
            optimizer.write_text(
                "#!/usr/bin/env python3\nfrom __future__ import annotations\nprint('optimizer')\n",
                encoding="utf-8",
            )
            optimizer.chmod(0o555)
            hold_root = root / "state" / "hold"
            hold_root.parent.mkdir()

            ORACLE.install_private_optimizer_hold(root, hold_root)

            self.assertEqual(os.stat(optimizer).st_mode & 0o777, 0o555)
            self.assertIn("R9A_PRIVATE_CANCEL_BARRIER", optimizer.read_text(encoding="utf-8"))
            self.assertEqual((hold_root / "hold-once.arm").read_text(encoding="ascii"), "armed\n")

    def test_driver_is_syntax_valid_and_package_lock_is_exact(self) -> None:
        completed = subprocess.run(
            ["node", "--check", str(WORKSPACE / "tools" / "r9a_browser_driver.js")],
            cwd=WORKSPACE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=20,
            check=False,
        )
        self.assertEqual(completed.returncode, 0, completed.stderr)
        package = json.loads((WORKSPACE / "browser" / "package.json").read_text(encoding="utf-8"))
        lock = json.loads((WORKSPACE / "browser" / "package-lock.json").read_text(encoding="utf-8"))
        self.assertEqual(package["dependencies"]["playwright"], "1.62.0")
        self.assertEqual(lock["packages"][""]["dependencies"]["playwright"], "1.62.0")
        driver = (WORKSPACE / "tools" / "r9a_browser_driver.js").read_text(encoding="utf-8")
        self.assertIn("serviceWorkers: 'block'", driver)
        self.assertIn("page.routeWebSocket", driver)
        self.assertIn("no-non-loopback-browser-egress", driver)

    def test_invalid_required_assertion_binding_is_rejected(self) -> None:
        broken = json.loads(json.dumps(self.registry))
        broken["fixtures"][0]["requiredAssertionIds"] = []
        with self.assertRaises(ORACLE.OracleError):
            ORACLE.validate_registry(broken)

    @unittest.skipUnless(sys.platform == "linux", "Linux subreaper/process-tree contract")
    def test_detached_sigterm_ignoring_descendant_is_killed_and_reaped(self) -> None:
        self.assertTrue(ORACLE.enable_child_subreaper())
        with tempfile.TemporaryDirectory(prefix="r9a-browser-process-tree-") as name:
            root = Path(name)
            state = root / "state"
            state.mkdir()
            child_pid_file = root / "child.pid"
            child_program = (
                "import os,signal,time;"
                "signal.signal(signal.SIGTERM, signal.SIG_IGN);"
                "os.chdir('/');"
                "time.sleep(60)"
            )
            parent_program = (
                "import pathlib,subprocess,sys,time;"
                f"p=subprocess.Popen([sys.executable,'-c',{child_program!r}],start_new_session=True);"
                f"pathlib.Path({str(child_pid_file)!r}).write_text(str(p.pid));"
                "time.sleep(60)"
            )
            parent = subprocess.Popen(
                [sys.executable, "-c", parent_program],
                cwd=root,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True,
            )
            try:
                deadline = time.monotonic() + 5
                while not child_pid_file.exists() and time.monotonic() < deadline:
                    time.sleep(0.02)
                self.assertTrue(child_pid_file.exists(), "detached child did not start")
                child_pid = int(child_pid_file.read_text())
                server = ORACLE.ServerProcess(
                    "tree-test", root, root, state, 1, root / "unused.log", parent
                )
                server.stop()
                self.assertEqual(server.residual_pids, [])
                self.assertFalse(ORACLE.process_exists(parent.pid))
                self.assertFalse(ORACLE.process_exists(child_pid))
            finally:
                ORACLE.terminate_owned_processes((root, state), (parent.pid,))

    def test_node_subprocess_does_not_inherit_unapproved_environment(self) -> None:
        marker = "R9A_BROWSER_UNAPPROVED_SECRET"
        previous = os.environ.get(marker)
        os.environ[marker] = "must-not-cross"
        try:
            return_code, stdout, stderr = ORACLE.run_node(
                [
                    "node",
                    "-e",
                    f"process.stdout.write(JSON.stringify({{{marker!r}:process.env[{marker!r}]||null,HOME:process.env.HOME,NO_PROXY:process.env.NO_PROXY}}))",
                ],
                WORKSPACE,
                10,
            )
        finally:
            if previous is None:
                os.environ.pop(marker, None)
            else:
                os.environ[marker] = previous
        self.assertEqual(return_code, 0, stderr)
        environment = json.loads(stdout)
        self.assertIsNone(environment[marker])
        self.assertTrue(environment["HOME"].startswith("/tmp/"))
        self.assertIn("127.0.0.1", environment["NO_PROXY"])

    @unittest.skipUnless(sys.platform == "linux", "Linux subreaper/process-tree contract")
    def test_node_timeout_reaps_detached_sigterm_ignoring_child(self) -> None:
        self.assertTrue(ORACLE.enable_child_subreaper())
        with tempfile.TemporaryDirectory(prefix="r9a-browser-node-tree-test-") as name:
            pid_file = Path(name) / "child.pid"
            script = (
                "const fs=require('fs'),cp=require('child_process');"
                "const c=cp.spawn(process.execPath,['-e',"
                + json.dumps("process.on('SIGTERM',()=>{});process.chdir('/');setInterval(()=>{},1000)")
                + "],{detached:true,stdio:'ignore'});"
                f"fs.writeFileSync({json.dumps(str(pid_file))},String(c.pid));"
                "setInterval(()=>{},1000);"
            )
            with self.assertRaises(subprocess.TimeoutExpired):
                ORACLE.run_node(["node", "-e", script], WORKSPACE, 0.5)
            self.assertTrue(pid_file.exists())
            detached_pid = int(pid_file.read_text())
            deadline = time.monotonic() + 2
            while ORACLE.process_exists(detached_pid) and time.monotonic() < deadline:
                with contextlib.suppress(ChildProcessError):
                    os.waitpid(detached_pid, os.WNOHANG)
                time.sleep(0.02)
            self.assertFalse(ORACLE.process_exists(detached_pid))


if __name__ == "__main__":
    unittest.main()
