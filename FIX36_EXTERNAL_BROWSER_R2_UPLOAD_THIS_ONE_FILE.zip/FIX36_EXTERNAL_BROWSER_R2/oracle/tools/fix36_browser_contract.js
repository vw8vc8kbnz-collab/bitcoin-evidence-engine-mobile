'use strict';

// These expectations are specific to the immutable FIX36 artifact in this kit.
const crypto = require('crypto');
const PRICING_REL = 'output/calculation_pricing.json';
const MARKERS = Object.freeze({
  panels: 'R9RC4_FIX31_COMPACT_MATERIAL_PANEL_LIST',
  grain: 'R9RC4_FIX33_GRAIN_LIFECYCLE'
});
const SUMMARY_FIELDS = Object.freeze([
  'materialsTotal', 'materialsTotalInclVat', 'materialsVatIncluded',
  'edgeBandTotal', 'cncTotal', 'drawingTotal', 'transportTotal',
  'otherCostsExVat', 'otherCostsVat', 'subtotalExVat', 'vatAmount', 'totalInclVat'
]);

// Passed directly to Playwright; only reads the application's public state.
function browserTemplatesReady(expectedFiles) {
  const state = window.state;
  if (!state || !state.embedIndex || !(state.templates instanceof Map)) return false;
  const idsByFile = new Map(Object.entries(state.embedIndex).map(([id, file]) => [file, id]));
  return expectedFiles.length > 0 && expectedFiles.every(file => {
    const id = idsByFile.get(file);
    return Boolean(id && state.templates.has(id) && state.templates.get(id));
  });
}

function inventoryEvidence(files, parentJobId, side) {
  if (!['golden', 'candidate'].includes(side)) throw new Error('Unknown release side');
  if (!Array.isArray(files) || !files.length || typeof parentJobId !== 'string' || !parentJobId) {
    throw new Error('Missing sealed file inventory or parent job');
  }
  const identities = new Set();
  const inventory = files.map(file => {
    const jobId = String(file.jobId || '');
    const role = jobId === parentJobId ? 'master'
      : jobId.startsWith(parentJobId + '__mat_') ? jobId.slice(parentJobId.length + 2) : '';
    const rel = String(file.rel || '');
    if (!role || (role !== 'master' && !/^mat_[0-9]{3}$/.test(role))) {
      throw new Error('Sealed file belongs to an unrelated or malformed job');
    }
    if (!rel.startsWith('output/') || rel.includes('\\') || rel.split('/').some(part => !part || part === '.' || part === '..')) {
      throw new Error('Invalid sealed file path');
    }
    if (typeof file.size !== 'number' || !Number.isSafeInteger(file.size) || file.size <= 0) {
      throw new Error('Empty or invalid sealed file size');
    }
    const key = jobId + '/' + rel;
    if (identities.has(key)) throw new Error('Duplicate sealed file identity');
    identities.add(key);
    return { jobId, role, rel, kind: String(file.kind || ''), bytes: file.size };
  }).sort((a, b) => (a.role + '/' + a.rel).localeCompare(b.role + '/' + b.rel, 'en'));
  const roles = [...new Set(inventory.map(item => item.role))].sort();
  // All three checkout fixtures create exactly one material subjob.
  if (JSON.stringify(roles) !== JSON.stringify(['master', 'mat_001'])) {
    throw new Error('Checkout must contain the master and exactly one material job');
  }
  const snapshots = inventory.filter(item => item.rel === PRICING_REL);
  const expected = side === 'candidate' ? roles : [];
  if (JSON.stringify(snapshots.map(item => item.role).sort()) !== JSON.stringify(expected)) {
    throw new Error('Pricing snapshot set differs from the reviewed release contract');
  }
  return {
    side,
    rawCount: inventory.length,
    inventory,
    // Only these two positively identified additions are version-specific.
    comparable: inventory.filter(item => item.rel !== PRICING_REL)
      .map(({ role, rel, kind }) => ({ role, rel, kind }))
  };
}

function pricingEvidence(downloads, inventory, authoritativeTotal) {
  const expected = inventory.inventory.filter(item => item.rel === PRICING_REL);
  if (!Array.isArray(downloads) || downloads.length !== expected.length) {
    throw new Error('Missing or extra pricing downloads');
  }
  const seen = new Set();
  const evidence = downloads.map(download => {
    const item = expected.find(file => file.jobId === download.jobId && file.rel === download.rel);
    if (!item || seen.has(item.jobId)) throw new Error('Duplicate or unrelated pricing download');
    seen.add(item.jobId);
    const text = download.text;
    if (download.status !== 200 || typeof text !== 'string' || Buffer.byteLength(text, 'utf8') !== item.bytes) {
      throw new Error('Pricing download status or byte count differs from manifest');
    }
    const body = JSON.parse(text);
    if (body.schemaVersion !== 1 || body.jobId !== item.jobId || body.pricingModel !== 'catalog_sell_price_incl_vat_v2' || body.roundingPolicy !== 'DECIMAL_HALF_UP_CENTS') {
      throw new Error('Pricing snapshot schema or job binding is invalid');
    }
    const summary = body.summary;
    if (!summary || SUMMARY_FIELDS.some(key => typeof summary[key] !== 'number' || !Number.isFinite(summary[key]) || summary[key] < 0)) {
      throw new Error('Pricing snapshot contains missing or invalid amounts');
    }
    const cents = value => Math.round(value * 100);
    if (cents(summary.totalInclVat) <= 0 || cents(summary.subtotalExVat) + cents(summary.vatAmount) !== cents(summary.totalInclVat)) {
      throw new Error('Pricing snapshot totals do not reconcile');
    }
    if (item.role === 'master' && (typeof authoritativeTotal !== 'number' || !Number.isFinite(authoritativeTotal) || cents(summary.totalInclVat) !== cents(authoritativeTotal))) {
      throw new Error('Master pricing snapshot differs from the Admin authoritative total');
    }
    return { jobId: item.jobId, role: item.role, rel: item.rel, status: download.status,
      bytes: item.bytes, sha256: crypto.createHash('sha256').update(text).digest('hex'), body };
  });
  return { downloads: evidence, valid: true };
}

function comparableCheckout(observation) {
  const { sealedFiles, pricingSnapshots, ...other } = observation;
  if (!sealedFiles || !Array.isArray(sealedFiles.comparable) || pricingSnapshots?.valid !== true) {
    throw new Error('Cannot compare checkout without validated artifact evidence');
  }
  return { ...other, sealedFileCount: sealedFiles.comparable.length, sealedFiles: sealedFiles.comparable };
}

module.exports = { MARKERS, PRICING_REL, SUMMARY_FIELDS, browserTemplatesReady,
  inventoryEvidence, pricingEvidence, comparableCheckout };
