#!/usr/bin/env python3
from __future__ import annotations

"""Safely extract a release ZIP and run its full preflight without Git metadata."""

import argparse
import hashlib
import hmac
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path, PurePosixPath

# Direct ``python -I -S -B tools/verify_standalone_artifact.py`` execution does
# not add the script directory to sys.path.  Bind the sibling import explicitly
# to the resolved directory that contains this trusted entrypoint.
TRUSTED_TOOLS_DIR = Path(__file__).resolve().parent
if str(TRUSTED_TOOLS_DIR) not in sys.path:
    sys.path.insert(0, str(TRUSTED_TOOLS_DIR))

from final_preflight import (
    MAX_SUBPROCESS_OUTPUT,
    Preflight,
    run_bounded_process,
    sanitized_process_env,
    strict_json,
    validate_checksum_manifest,
)


MAX_ARTIFACT_BYTES = 128 * 1024 * 1024
MAX_MEMBERS = 5_000
MAX_MEMBER_BYTES = 128 * 1024 * 1024
MAX_TOTAL_BYTES = 512 * 1024 * 1024
MIN_EXTRACTION_RESERVE_BYTES = 128 * 1024 * 1024
EXPECTED_ARTIFACT_NAME = "METOD_PAX_R9RC4_TOOL_A_RUNTIME_HARDENING_CANDIDATE.zip"
EXPECTED_ARTIFACT_ROOT = "METOD_PAX_R9RC4_TOOL_A_RUNTIME_HARDENING_CANDIDATE"
EXPECTED_CONTRACT_ID = "R9RC4_RELEASE_IDENTITY"
EXPECTED_RELEASE_REVISION = "R9RC4"
EXPECTED_BUILD_ID = "R9RC4_TOOL_A_RUNTIME_HARDENING"
EXPECTED_RELEASE_STATUS = "PROVISIONAL_DEVELOPMENT_ONLY"
EXPECTED_RELEASE_CHANNEL = "AUDIT_CANDIDATE"
EXPECTED_SOURCE_TAG = "r9rc4-tool-a-runtime-hardening-candidate-checkpoint"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def snapshot_and_verify_artifact(
    artifact: Path,
    destination: Path,
    *,
    expected_sha256: str,
) -> tuple[Path, str, int]:
    """Bind one no-follow input fd to the exact bytes that will be extracted."""

    flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
    try:
        descriptor = os.open(artifact, flags)
    except OSError as exc:
        raise RuntimeError(f"artifact cannot be opened without following links: {exc}") from exc
    digest = hashlib.sha256()
    copied = 0
    try:
        metadata = os.fstat(descriptor)
        if not stat.S_ISREG(metadata.st_mode):
            raise RuntimeError("artifact input is not a regular file")
        if metadata.st_size < 1 or metadata.st_size > MAX_ARTIFACT_BYTES:
            raise RuntimeError("artifact ZIP exceeds compressed-size limit")
        with destination.open("xb") as output:
            while True:
                chunk = os.read(descriptor, 1024 * 1024)
                if not chunk:
                    break
                copied += len(chunk)
                if copied > MAX_ARTIFACT_BYTES:
                    raise RuntimeError("artifact ZIP exceeds compressed-size limit while snapshotting")
                digest.update(chunk)
                output.write(chunk)
            output.flush()
            os.fsync(output.fileno())
    finally:
        os.close(descriptor)
    actual_sha256 = digest.hexdigest()
    if copied < 1 or not hmac.compare_digest(actual_sha256, expected_sha256):
        destination.unlink(missing_ok=True)
        raise RuntimeError("artifact SHA-256 differs from the mandatory out-of-band trust anchor")
    os.chmod(destination, 0o400)
    return destination, actual_sha256, copied


def safe_extract(
    artifact: Path,
    destination: Path,
    *,
    expected_root: str | None = None,
) -> tuple[Path, int]:
    artifact_bytes = artifact.stat().st_size
    if artifact_bytes < 1 or artifact_bytes > MAX_ARTIFACT_BYTES:
        raise RuntimeError("artifact ZIP exceeds compressed-size limit")
    with zipfile.ZipFile(artifact, "r") as archive:
        infos = archive.infolist()
        if not infos:
            raise RuntimeError("artifact ZIP is empty")
        if len(infos) > MAX_MEMBERS:
            raise RuntimeError("artifact ZIP exceeds member-count limit")
        names = [info.filename for info in infos]
        if len(names) != len(set(names)):
            raise RuntimeError("artifact ZIP contains duplicate members")

        top_levels: set[str] = set()
        total_bytes = 0
        for info in infos:
            raw_parts = info.filename.split("/")
            member = PurePosixPath(info.filename)
            mode = (info.external_attr >> 16) & 0xFFFF
            if (
                info.filename.startswith("/")
                or member.is_absolute()
                or len(member.parts) < 2
                or any(part in {"", ".", ".."} for part in raw_parts)
                or "\\" in info.filename
                or any(ord(character) < 32 or ord(character) == 127 for character in info.filename)
            ):
                raise RuntimeError(f"unsafe artifact ZIP member: {info.filename}")
            lowered_parts = tuple(part.lower() for part in member.parts)
            if (
                any(part in {".git", "__pycache__"} for part in lowered_parts)
                or member.suffix.lower() in {".pyc", ".pyo", ".bak"}
            ):
                raise RuntimeError(f"executable/build residue is forbidden: {info.filename}")
            if info.is_dir() or not stat.S_ISREG(mode):
                raise RuntimeError(f"non-regular artifact ZIP member: {info.filename}")
            if info.file_size < 0 or info.file_size > MAX_MEMBER_BYTES:
                raise RuntimeError(f"artifact member exceeds size limit: {info.filename}")
            total_bytes += info.file_size
            if total_bytes > MAX_TOTAL_BYTES:
                raise RuntimeError("artifact ZIP exceeds total extraction limit")
            top_levels.add(member.parts[0])

        if len(top_levels) != 1:
            raise RuntimeError(f"artifact must contain exactly one release root: {sorted(top_levels)}")
        top_level = next(iter(top_levels))
        if expected_root is not None and top_level != expected_root:
            raise RuntimeError(f"artifact release root is not canonical: {top_level}")
        destination.parent.mkdir(parents=True, exist_ok=True)
        required_free = total_bytes + MIN_EXTRACTION_RESERVE_BYTES
        if shutil.disk_usage(destination.parent).free < required_free:
            raise RuntimeError("insufficient free space for bounded artifact extraction")
        if archive.testzip() is not None:
            raise RuntimeError("artifact ZIP CRC verification failed")

        for info in infos:
            target = destination.joinpath(*PurePosixPath(info.filename).parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(info, "r") as source, target.open("xb") as output:
                shutil.copyfileobj(source, output, length=1024 * 1024)
            if target.stat().st_size != info.file_size:
                raise RuntimeError(f"extracted byte count mismatch: {info.filename}")

    release = destination / top_level
    if not release.is_dir():
        raise RuntimeError("extracted release root is missing")
    for path in release.rglob("*"):
        if path.is_symlink() or path.name.lower() == ".git":
            raise RuntimeError(f"forbidden extracted path: {path.relative_to(release)}")
    return release, len(infos)


def write_json_atomic(path: Path, value: dict[str, object]) -> None:
    path = path.expanduser().absolute()
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() or path.is_symlink():
        raise RuntimeError(f"refusing to overwrite standalone verification report: {path}")
    temporary = path.parent / f".{path.name}.tmp.{os.getpid()}"
    try:
        descriptor = os.open(
            temporary,
            os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0),
            0o600,
        )
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(json.dumps(value, indent=2, sort_keys=True) + "\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temporary, 0o444)
        os.link(temporary, path, follow_symlinks=False)
        directory = os.open(path.parent, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        temporary.unlink(missing_ok=True)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--artifact", type=Path, required=True)
    parser.add_argument(
        "--expected-sha256",
        required=True,
        help="mandatory SHA-256 obtained independently from the artifact being verified",
    )
    parser.add_argument("--json-output", type=Path)
    args = parser.parse_args()

    artifact = args.artifact.expanduser().absolute()
    artifact_display_name = artifact.name
    if artifact_display_name != EXPECTED_ARTIFACT_NAME:
        raise RuntimeError(f"artifact filename is not canonical: {artifact_display_name}")
    expected_sha256 = str(args.expected_sha256).strip().lower()
    if not re.fullmatch(r"[a-f0-9]{64}", expected_sha256):
        raise RuntimeError("expected SHA-256 must contain exactly 64 lowercase hexadecimal characters")
    trusted_preflight = Path(__file__).resolve(strict=True).with_name("final_preflight.py")
    if not trusted_preflight.is_file() or trusted_preflight.is_symlink():
        raise RuntimeError("trusted local final preflight is missing or not a regular file")

    with tempfile.TemporaryDirectory(prefix="metod_r9j_standalone_") as temporary:
        temp_root = Path(temporary)
        artifact_snapshot, actual_sha256, artifact_bytes = snapshot_and_verify_artifact(
            artifact,
            temp_root / "authenticated-artifact.snapshot.zip",
            expected_sha256=expected_sha256,
        )
        release, member_count = safe_extract(
            artifact_snapshot,
            temp_root / "empty-extraction-root",
            expected_root=EXPECTED_ARTIFACT_ROOT,
        )
        checksum_checks = Preflight()
        if not validate_checksum_manifest(checksum_checks, release, verify=True):
            raise RuntimeError("trusted verifier rejected the extracted manifest/fileset/hash boundary")

        identity = strict_json(release / "RELEASE_IDENTITY.json")
        candidate = identity.get("canonicalCandidate") if isinstance(identity, dict) else None
        expected_candidate = {
            "releaseRevision": EXPECTED_RELEASE_REVISION,
            "buildId": EXPECTED_BUILD_ID,
            "releaseChannel": EXPECTED_RELEASE_CHANNEL,
            "status": EXPECTED_RELEASE_STATUS,
            "releaseEligible": False,
            "artifactName": EXPECTED_ARTIFACT_NAME,
            "artifactRootDirectory": EXPECTED_ARTIFACT_ROOT,
            "intendedSourceTag": EXPECTED_SOURCE_TAG,
            "sourceTagVerified": False,
            "sourceCommitVerified": False,
            "sourceProvenanceStatus": "UNVERIFIED_TRANSFER_WORKSPACE_NO_GO",
        }
        if (
            not isinstance(identity, dict)
            or identity.get("schemaVersion") != 2
            or identity.get("contractId") != EXPECTED_CONTRACT_ID
            or identity.get("product") != "METOD_PAX"
            or not isinstance(candidate, dict)
            or candidate != expected_candidate
        ):
            raise RuntimeError("artifact release identity differs from the exact trusted R9RC4 schema")

        env = sanitized_process_env()
        env["METOD_STATE_ROOT"] = str(temp_root / "isolated-state")
        env["GIT_CEILING_DIRECTORIES"] = str(temp_root)
        completed = run_bounded_process(
            [
                sys.executable,
                "-I",
                "-S",
                "-B",
                str(trusted_preflight),
                "--release",
                ".",
                "--verify-checksums",
            ],
            cwd=release,
            env=env,
            timeout=1200,
        )
        output = completed.stdout
        if completed.timed_out:
            sys.stdout.write(output)
            raise RuntimeError("trusted standalone full preflight timed out; process group stopped")
        if completed.output_limit_exceeded:
            sys.stdout.write(output)
            raise RuntimeError(
                f"trusted standalone full preflight exceeded {MAX_SUBPROCESS_OUTPUT} output bytes"
            )
        if completed.returncode != 0:
            sys.stdout.write(output)
            raise RuntimeError(f"standalone full preflight failed with exit {completed.returncode}")
        report: dict[str, object] = {
            "schemaVersion": 1,
            "gate": "METOD_STANDALONE_ARTIFACT_FULL_PREFLIGHT",
            "status": "PASS",
            "artifact": artifact_display_name,
            "artifactBytes": artifact_bytes,
            "artifactSha256": actual_sha256,
            "topLevelDirectory": release.name,
            "memberCount": member_count,
            "gitMetadataPresent": False,
            "checksumVerification": "PASS",
            "fullPreflightExitCode": completed.returncode,
            "fullPreflightOutputSha256": hashlib.sha256(output.encode("utf-8")).hexdigest(),
            "fullPreflightTail": output.splitlines()[-12:],
        }
        report["releaseRevision"] = candidate.get("releaseRevision")
        report["buildId"] = candidate.get("buildId")
        report["releaseStatus"] = candidate.get("status")
        report["releaseEligible"] = candidate.get("releaseEligible")
        if args.json_output:
            write_json_atomic(args.json_output, report)
        print(json.dumps(report, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
