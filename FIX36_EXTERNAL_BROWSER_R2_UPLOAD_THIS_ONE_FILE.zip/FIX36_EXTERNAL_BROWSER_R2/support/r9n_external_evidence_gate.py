#!/usr/bin/env python3
from __future__ import annotations

"""Validate an external evidence pack without turning it into production GO.

Missing or incomplete real-world evidence is NO_GO (exit 3). Invalid JSON,
unsafe paths, hash drift and internally contradictory PASS claims are FAIL
(exit 1). A complete pack means only that the reviewed evidence is present,
current and bound to one artifact; a separate human release decision remains
mandatory.
"""

import argparse
import contextlib
import hashlib
import io
import json
import os
import sys
import tempfile
import zipfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

TRUSTED_TOOLS = Path(__file__).resolve().parent
if str(TRUSTED_TOOLS) not in sys.path:
    sys.path.insert(0, str(TRUSTED_TOOLS))
from final_preflight import Preflight, validate_checksum_manifest
from verify_standalone_artifact import safe_extract, snapshot_and_verify_artifact

EXIT_FAIL = 1
EXIT_NO_GO = 3
MAX_MANIFEST_BYTES = 16 * 1024 * 1024


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def valid_release_manifest(release: Path) -> bool:
    # Keep the public gate report machine-readable; details are represented by
    # its explicit failing boundary rather than a second preflight log stream.
    with contextlib.redirect_stdout(io.StringIO()):
        return validate_checksum_manifest(Preflight(), release, verify=True)


def manifest_bytes_from_artifact(artifact: Path, *, expected_sha256: str | None = None) -> tuple[str, bytes]:
    """Validate the complete ZIP, not merely its self-declared manifest bytes.

    Reuse the install verifier's bounded no-follow snapshot/extraction boundary;
    no code from this input ZIP is executed. Binding the observed SHA prevents a
    mutable input from changing between evidence identity and payload checks.
    """
    try:
        with tempfile.TemporaryDirectory(prefix="metod-evidence-artifact-") as temporary:
            work = Path(temporary)
            snapshot, _digest, _size = snapshot_and_verify_artifact(
                artifact, work / 'candidate.zip',
                expected_sha256=expected_sha256 or sha256_file(artifact),
            )
            release, _count = safe_extract(snapshot, work / 'release')
            manifest = release / 'SHA256SUMS.txt'
            if not manifest.is_file() or not 0 < manifest.stat().st_size <= MAX_MANIFEST_BYTES:
                raise ValueError('candidate artifact manifest is missing or exceeds bounded size')
            if not valid_release_manifest(release):
                raise ValueError('candidate artifact has an invalid checksum manifest or payload')
            return release.name, manifest.read_bytes()
    except (RuntimeError, OSError, zipfile.BadZipFile) as exc:
        raise ValueError(f"candidate artifact payload boundary failed: {exc}") from exc


def read_object(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON root must be an object: {path}")
    return value


def parse_utc(value: Any) -> datetime:
    raw = str(value or "").strip()
    parsed = datetime.fromisoformat(raw.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise ValueError("timestamp must include a timezone")
    return parsed.astimezone(timezone.utc)


def atomic_json(path: Path, value: dict[str, Any]) -> None:
    path = path.resolve()
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=path.parent, delete=False) as handle:
        os.fchmod(handle.fileno(), 0o600)
        json.dump(value, handle, ensure_ascii=False, sort_keys=True, indent=2)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
        temporary = Path(handle.name)
    os.replace(temporary, path)
    path.chmod(0o600)


def safe_attachment(root: Path, relative: Any) -> Path:
    rendered = str(relative or "")
    if not rendered or Path(rendered).is_absolute():
        raise ValueError("attachment path must be non-empty and relative")
    parts = rendered.split('/')
    if any(part in {'', '.', '..'} for part in parts) or '\\' in rendered:
        raise ValueError(f"unsafe attachment path: {rendered}")
    linked = root
    for part in parts:
        linked /= part
        if linked.is_symlink():
            raise ValueError(f"unsafe attachment symlink: {rendered}")
    target = (root / rendered).resolve(strict=True)
    if not target.is_relative_to(root) or target.is_symlink() or not target.is_file():
        raise ValueError(f"unsafe attachment path: {rendered}")
    return target


def validate_attachments(root: Path, report: dict[str, Any]) -> list[str]:
    attachments = report.get("attachments")
    if not isinstance(attachments, list) or not attachments:
        raise ValueError("report requires at least one hash-bound attachment")
    seen: set[str] = set()
    paths: list[str] = []
    for item in attachments:
        if not isinstance(item, dict):
            raise ValueError("attachment entry must be an object")
        relative = str(item.get("path") or "")
        if relative in seen:
            raise ValueError(f"duplicate attachment: {relative}")
        seen.add(relative)
        target = safe_attachment(root, relative)
        expected = str(item.get("sha256") or "").lower()
        if len(expected) != 64 or sha256_file(target) != expected:
            raise ValueError(f"attachment hash mismatch: {relative}")
        paths.append(relative)
    return paths


def validate_generic_report(
    root: Path,
    report: dict[str, Any],
    spec: dict[str, Any],
    artifact_sha: str,
    manifest_sha: str,
    now: datetime,
) -> dict[str, Any]:
    report_type = str(spec["reportType"])
    if report.get("schemaVersion") != 1 or report.get("reportType") != report_type:
        raise ValueError(f"{report_type}: schema/reportType mismatch")
    if report.get("subjectArtifactSha256") != artifact_sha or report.get("candidateManifestSha256") != manifest_sha:
        raise ValueError(f"{report_type}: artifact or candidate manifest binding mismatch")
    observed = parse_utc(report.get("observedAtUtc"))
    if observed > now + timedelta(minutes=5):
        raise ValueError(f"{report_type}: observedAtUtc is in the future")
    if observed < now - timedelta(days=int(spec["maxAgeDays"])):
        return {"reportType": report_type, "status": "NO_GO", "reason": "evidence-expired"}
    attestation = report.get("attestation")
    if not isinstance(attestation, dict) or not str(attestation.get("reviewerName") or "").strip() or not str(attestation.get("organization") or "").strip():
        return {"reportType": report_type, "status": "NO_GO", "reason": "named-attestation-missing"}
    if spec.get("independentRequired") is True and attestation.get("independentFromBuilder") is not True:
        return {"reportType": report_type, "status": "NO_GO", "reason": "independence-not-attested"}
    environment = report.get("environment")
    if not isinstance(environment, dict) or not environment:
        return {"reportType": report_type, "status": "NO_GO", "reason": "environment-missing"}
    if spec.get("actualHardwareRequired") is True and environment.get("actualHardware") is not True:
        return {"reportType": report_type, "status": "NO_GO", "reason": "actual-hardware-not-proven"}
    attachments = validate_attachments(root, report)
    checks = report.get("checks")
    if not isinstance(checks, list):
        return {"reportType": report_type, "status": "NO_GO", "reason": "checks-missing"}
    check_index = {item.get("id"): item for item in checks if isinstance(item, dict) and isinstance(item.get("id"), str)}
    required = list(spec["requiredCheckIds"])
    if len(check_index) != len(checks) or set(check_index) != set(required):
        return {"reportType": report_type, "status": "NO_GO", "reason": "required-check-set-incomplete"}
    for check_id in required:
        check = check_index[check_id]
        refs = check.get("evidenceRefs")
        if check.get("status") != "PASS" or not isinstance(refs, list) or not refs or any(ref not in attachments for ref in refs):
            return {"reportType": report_type, "status": "NO_GO", "reason": f"check-not-proven:{check_id}"}
    if report.get("status") != "PASS":
        return {"reportType": report_type, "status": "NO_GO", "reason": "report-not-pass"}
    return {"reportType": report_type, "status": "PASS", "observedAtUtc": observed.isoformat().replace("+00:00", "Z"), "attachmentCount": len(attachments)}


def exact_ids(value: Any, required: list[str]) -> bool:
    """Match identities, not just counts; reject duplicates and malformed entries."""
    return (
        isinstance(value, list)
        and all(isinstance(item, str) and item for item in value)
        and len(value) == len(required)
        and len(set(value)) == len(value)
        and set(value) == set(required)
    )


def browser_contract_ids(spec: dict[str, Any]) -> list[str] | None:
    """An absent reviewed registry is an explicit blocker, never evidence-owned."""
    fixture_ids = spec.get("requiredFixtureIds")
    registry_sha = spec.get("fixtureRegistrySha256")
    if not fixture_ids or not registry_sha:
        return None
    if (
        not isinstance(fixture_ids, list)
        or not exact_ids(fixture_ids, fixture_ids)
        or type(spec.get("requiredFixtureCount")) is not int
        or len(fixture_ids) != spec["requiredFixtureCount"]
        or not isinstance(registry_sha, str)
        or len(registry_sha) != 64
        or any(char not in "0123456789abcdef" for char in registry_sha)
    ):
        raise ValueError("browser contract requires an exact unique pinned fixture registry")
    return fixture_ids


def browser_observation(report: dict[str, Any], spec: dict[str, Any], now: datetime) -> tuple[datetime, bool]:
    observed = parse_utc(report.get("observedAtUtc"))
    if observed > now + timedelta(minutes=5):
        raise ValueError("browser observedAtUtc is in the future")
    return observed, observed < now - timedelta(days=int(spec["maxAgeDays"]))


def evidence_digest(value: Any) -> str:
    encoded = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def validate_browser_ledger(report: dict[str, Any], registry: dict[str, Any]) -> None:
    """Recheck profile and assertion ledgers before deriving engine summaries."""
    if report.get("blockers") != []:
        raise ValueError("passing browser oracle cannot contain unresolved blockers")
    fixture_specs = {item["id"]: item for item in registry["fixtures"]}
    fixtures = report.get("fixtures")
    if (
        not isinstance(fixtures, list)
        or not all(isinstance(item, dict) for item in fixtures)
        or not exact_ids([item.get("id") for item in fixtures], list(fixture_specs))
    ):
        raise ValueError("browser oracle did not return the exact reviewed fixture ledger")
    assertions_total = 0
    for item in fixtures:
        spec = fixture_specs[item["id"]]
        evidence = item.get("evidence")
        assertions = item.get("assertionResults")
        if (
            item.get("status") != "PASS"
            or item.get("evidenceClass") != spec["requiredEvidenceClass"]
            or not exact_ids(item.get("enginesPassed"), registry["requiredEngines"])
            or not exact_ids(item.get("profilesPassed"), spec["profiles"])
            or not isinstance(evidence, dict)
            or evidence.get("assertionResults") != assertions
            or item.get("evidenceSha256") != evidence_digest(evidence)
            or not exact_ids(evidence.get("profilesExecuted"), spec["profiles"])
            or not isinstance(assertions, list)
            or not all(isinstance(assertion, dict) for assertion in assertions)
            or not exact_ids([assertion.get("id") for assertion in assertions], spec["requiredAssertionIds"])
            or type(item.get("assertions")) is not int
            or item["assertions"] != len(assertions)
        ):
            raise ValueError(f"incomplete browser profile/assertion ledger: {item['id']}")
        for assertion in assertions:
            if (
                assertion.get("status") != "PASS"
                or "actualValue" not in assertion
                or "expectedValue" not in assertion
                or assertion.get("actualDigest") != evidence_digest(assertion["actualValue"])
                or assertion.get("expectedDigest") != evidence_digest(assertion["expectedValue"])
                or assertion["actualDigest"] != assertion["expectedDigest"]
            ):
                raise ValueError(f"invalid browser assertion: {item['id']}:{assertion.get('id')}")
        assertions_total += len(assertions)
    if type(report.get("assertionsTotal")) is not int or report["assertionsTotal"] != assertions_total:
        raise ValueError("browser oracle assertion total is not ledger-bound")
    mutation = report.get("sourceMutationCheck", {})
    if mutation.get("unchanged") is not True:
        raise ValueError("browser oracle did not prove unchanged source trees")
    for label in ("golden", "candidate"):
        before = mutation.get(label + "BeforeSha256")
        if not before or before != mutation.get(label + "AfterSha256") or before != report[label + "Release"].get("sourceTreeSha256"):
            raise ValueError("browser oracle source tree bindings are inconsistent")


def validate_browser_report(
    root: Path,
    wrapper: dict[str, Any],
    spec: dict[str, Any],
    artifact_sha: str,
    manifest_sha: str,
    golden_sha: str,
    now: datetime,
    registry: dict[str, Any] | None = None,
) -> dict[str, Any]:
    result: dict[str, Any] = {"reportType": "pinned-browser-oracle", "status": "NO_GO"}
    if wrapper.get("schemaVersion") != 1 or wrapper.get("reportType") != "pinned-browser-oracle":
        raise ValueError("browser wrapper schema/reportType mismatch")
    if (
        wrapper.get("subjectArtifactSha256") != artifact_sha
        or wrapper.get("candidateManifestSha256") != manifest_sha
        or wrapper.get("goldenArtifactSha256") != golden_sha
    ):
        raise ValueError("browser wrapper artifact/golden binding mismatch")
    attachments = validate_attachments(root, wrapper)
    result["attachmentCount"] = len(attachments)
    raw_relative = wrapper.get(spec["rawOracleReportPathField"])
    if raw_relative not in attachments:
        raise ValueError("raw browser oracle report is not an attachment")
    raw = read_object(safe_attachment(root, raw_relative))
    if raw.get("schemaVersion") != spec["rawSchemaVersion"] or raw.get("oracleId") != spec["oracleId"]:
        raise ValueError("raw browser oracle schema/identity mismatch")
    candidate = raw.get("candidateRelease")
    golden = raw.get("goldenRelease")
    if (
        not isinstance(candidate, dict)
        or candidate.get("artifactSha256") != artifact_sha
        or candidate.get("manifestSha256") != manifest_sha
        or not isinstance(golden, dict)
        or golden.get("artifactSha256") != golden_sha
    ):
        raise ValueError("raw browser oracle artifact/golden binding mismatch")
    wrapper_observed, wrapper_expired = browser_observation(wrapper, spec, now)
    raw_observed, raw_expired = browser_observation(raw, spec, now)
    if raw_observed > wrapper_observed + timedelta(minutes=5):
        raise ValueError("browser wrapper predates its raw observation")
    if wrapper.get("status") != "PASS" or raw.get("status") != "PASS":
        return {**result, "reason": "browser-report-not-pass"}
    if wrapper_expired or raw_expired:
        return {**result, "reason": "evidence-expired"}
    required = browser_contract_ids(spec)
    if required is None:
        return {**result, "reason": "reviewed-browser-fixture-registry-missing"}
    if raw.get("fixtureRegistrySha256") != spec["fixtureRegistrySha256"]:
        raise ValueError("raw browser oracle fixture registry binding mismatch")
    required_engines = spec["requiredEngines"]
    if not required_engines or not exact_ids(required_engines, required_engines):
        raise ValueError("browser contract requires unique engine identities")
    expected_counts = {
        "fixtureCount": len(required),
        "passedFixtureCount": len(required),
        "failedFixtureCount": 0,
        "blockedFixtureCount": spec["requiredBlockedFixtureCount"],
        "skippedFixtureCount": spec["requiredSkippedFixtureCount"],
    }
    if (
        any(type(raw.get(key)) is not int or raw[key] != count for key, count in expected_counts.items())
        or not exact_ids(raw.get("enginesPassed"), required_engines)
        or not exact_ids(raw.get("fixtureIdsPassed"), required)
    ):
        return {**result, "reason": "raw-browser-oracle-incomplete"}
    engine_results = raw.get("engineResults")
    if not isinstance(engine_results, list) or not all(isinstance(item, dict) for item in engine_results):
        return {**result, "reason": "browser-engine-results-incomplete"}
    if not exact_ids([item.get("engine") for item in engine_results], required_engines):
        return {**result, "reason": "browser-engine-results-incomplete"}
    for engine in engine_results:
        fixtures = engine.get("fixtureResults")
        if (
            engine.get("status") != "PASS"
            or not isinstance(fixtures, list)
            or not all(isinstance(item, dict) and item.get("status") == "PASS" for item in fixtures)
            or not exact_ids([item.get("fixtureId") for item in fixtures], required)
        ):
            return {**result, "reason": f"browser-engine-not-proven:{engine['engine']}"}
    if not isinstance(registry, dict) or not exact_ids([item["id"] for item in registry.get("fixtures", [])], required):
        raise ValueError("browser assertion registry is missing or does not match the contract")
    validate_browser_ledger(raw, registry)
    native_relative = raw.get("sourceOracleReportPath")
    if native_relative not in attachments or native_relative == raw_relative:
        raise ValueError("native browser oracle report is not a separate attachment")
    native_path = safe_attachment(root, native_relative)
    if sha256_file(native_path) != raw.get("sourceOracleReportSha256"):
        raise ValueError("native browser oracle report hash mismatch")
    native = read_object(native_path)
    if native.get("schemaVersion") != 2 or native.get("finishedAtUtc") != raw.get("observedAtUtc"):
        raise ValueError("native browser oracle schema/observation mismatch")
    for key in (
        "oracleId", "status", "startedAtUtc", "finishedAtUtc", "registry", "fixtures",
        "fixtureCount", "passedFixtureCount", "failedFixtureCount", "blockedFixtureCount",
        "skippedFixtureCount", "fixtureIdsPassed", "enginesPassed", "assertionsTotal",
        "sourceMutationCheck", "runtimeProbe", "blockers",
    ):
        if native.get(key) != raw.get(key):
            raise ValueError(f"native browser oracle disagrees with normalized report: {key}")
    for key in ("candidateRelease", "goldenRelease"):
        normalized_binding = {name: value for name, value in raw[key].items() if name != "artifactSha256"}
        if native.get(key) != normalized_binding:
            raise ValueError(f"native browser oracle release binding mismatch: {key}")
    return {
        **result,
        "status": "PASS",
        "reason": None,
        "observedAtUtc": raw_observed.isoformat().replace("+00:00", "Z"),
        "fixtureRegistrySha256": spec["fixtureRegistrySha256"],
    }


def evaluate(contract: dict[str, Any], artifact: Path, golden: Path, release: Path, evidence_root: Path, now: datetime | None = None) -> tuple[dict[str, Any], int]:
    if artifact.is_symlink() or golden.is_symlink():
        raise ValueError("artifact inputs must be regular non-symlink files")
    artifact = artifact.resolve(strict=True)
    golden = golden.resolve(strict=True)
    release = release.resolve(strict=True)
    evidence_root = evidence_root.resolve(strict=True)
    if artifact.is_symlink() or golden.is_symlink() or not artifact.is_file() or not golden.is_file():
        raise ValueError("artifact inputs must be regular non-symlink files")
    artifact_sha = sha256_file(artifact)
    golden_sha = sha256_file(golden)
    if golden_sha != contract.get("goldenArtifactSha256"):
        raise ValueError("immutable golden artifact hash mismatch")
    manifest = release / "SHA256SUMS.txt"
    if not manifest.is_file() or manifest.is_symlink():
        raise ValueError("candidate SHA256SUMS.txt missing or unsafe")
    source_manifest_bytes = manifest.read_bytes()
    artifact_root, artifact_manifest_bytes = manifest_bytes_from_artifact(artifact, expected_sha256=artifact_sha)
    if artifact_manifest_bytes != source_manifest_bytes:
        raise ValueError("candidate artifact embeds a different SHA256SUMS.txt")
    if not valid_release_manifest(release):
        raise ValueError('candidate source tree differs from its artifact-bound manifest')
    identity = read_object(release / "RELEASE_IDENTITY.json")
    candidate = identity.get("canonicalCandidate") if isinstance(identity, dict) else None
    if not isinstance(candidate, dict):
        raise ValueError("candidate release identity is missing")
    if artifact.name != candidate.get("artifactName") or artifact_root != candidate.get("artifactRootDirectory"):
        raise ValueError("candidate artifact name or root differs from release identity")
    manifest_sha = hashlib.sha256(artifact_manifest_bytes).hexdigest()
    moment = now or datetime.now(timezone.utc)
    results: list[dict[str, Any]] = []
    missing: list[str] = []
    browser_spec = contract["browserOracle"]
    browser_path = evidence_root / browser_spec["report"]
    if not browser_path.is_file():
        missing.append(browser_spec["report"])
    else:
        results.append(validate_browser_report(
            evidence_root, read_object(browser_path), browser_spec,
            artifact_sha, manifest_sha, golden_sha, moment,
            read_object(release / browser_spec["fixtureRegistryPath"]),
        ))
    for spec in contract["reports"]:
        report_path = evidence_root / spec["filename"]
        if not report_path.is_file():
            missing.append(spec["filename"])
            continue
        results.append(validate_generic_report(evidence_root, read_object(report_path), spec, artifact_sha, manifest_sha, moment))
    complete = not missing and all(item["status"] == "PASS" for item in results)
    status = "EVIDENCE_COMPLETE_PENDING_SEPARATE_PRODUCTION_DECISION" if complete else "NO_GO"
    output = {
        "schemaVersion": 1,
        "gateId": "R9N_EXTERNAL_EVIDENCE_GATE",
        "status": status,
        "subjectArtifact": artifact.name,
        "subjectArtifactSha256": artifact_sha,
        "subjectArtifactRoot": artifact_root,
        "candidateManifestSha256": manifest_sha,
        "goldenArtifactSha256": golden_sha,
        "missingReports": missing,
        "reportResults": results,
        "productionGo": False,
        "releaseEligible": False,
        "evidenceLimit": "This gate validates completeness, freshness, hashes and declared attestations; it does not authenticate human identity or authorize production."
    }
    return output, 0 if complete else EXIT_NO_GO


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--contract", type=Path, required=True)
    parser.add_argument("--artifact", type=Path, required=True)
    parser.add_argument("--golden-artifact", type=Path, required=True)
    parser.add_argument("--release", type=Path, required=True)
    parser.add_argument("--evidence-dir", type=Path, required=True)
    parser.add_argument("--json-output", type=Path, required=True)
    args = parser.parse_args()
    try:
        output, exit_code = evaluate(read_object(args.contract), args.artifact, args.golden_artifact, args.release, args.evidence_dir)
    except Exception as exc:
        output = {"schemaVersion": 1, "gateId": "R9N_EXTERNAL_EVIDENCE_GATE", "status": "FAIL", "error": str(exc), "productionGo": False, "releaseEligible": False}
        exit_code = EXIT_FAIL
    atomic_json(args.json_output, output)
    print(json.dumps(output, ensure_ascii=False, sort_keys=True, indent=2))
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
