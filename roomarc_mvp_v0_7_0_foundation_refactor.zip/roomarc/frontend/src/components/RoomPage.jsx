import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ChevronLeft } from 'lucide-react';
import { motion } from 'framer-motion';
import { FALLBACK_UPDATES } from '../data/fallback';

function fallbackRoom(id) {
  const update = FALLBACK_UPDATES.find((item) => item.room.id === id) || FALLBACK_UPDATES[0];
  return {
    id: update.room.id,
    name: update.room.name,
    cover_url: update.room.cover_url,
    following: false,
    followers: 124,
    home: update.home,
    updates: FALLBACK_UPDATES.filter((item) => item.room.id === update.room.id),
  };
}

export function RoomPage({ id, auth, close }) {
  const [room, setRoom] = useState(null);
  const [active, setActive] = useState(0);
  const [tab, setTab] = useState('timeline');
  const trackRef = useRef(null);

  async function load() {
    try { setRoom(await auth.req(`/api/rooms/${id}`)); }
    catch { setRoom(fallbackRoom(id)); }
  }

  useEffect(() => { load(); }, [id]);

  const updates = room?.updates || [];
  const current = updates[Math.min(active, Math.max(updates.length - 1, 0))];

  const progress = useMemo(() => {
    if (updates.length < 2) return 0;
    return active / (updates.length - 1);
  }, [active, updates.length]);

  function scrubFromClientX(clientX) {
    if (!trackRef.current || updates.length < 2) return;
    const box = trackRef.current.getBoundingClientRect();
    const ratio = Math.min(1, Math.max(0, (clientX - box.left) / box.width));
    setActive(Math.round(ratio * (updates.length - 1)));
  }

  function handlePointer(event) {
    event.currentTarget.setPointerCapture?.(event.pointerId);
    scrubFromClientX(event.clientX);
  }

  if (!room) return null;

  async function toggleFollow() {
    if (String(room.id).startsWith('demo-room')) return;
    await auth.req(`/api/rooms/${room.id}/follow`, { method: room.following ? 'DELETE' : 'POST' });
    load();
  }

  return (
    <motion.aside className="overlay overlay--dark" initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }} transition={{ type: 'spring', damping: 30, stiffness: 230 }}>
      <button className="back-button back-button--dark" onClick={close}><ChevronLeft size={18} /> Terug</button>
      <section className="room-hero">
        <img src={current?.media_url || room.cover_url} alt={room.name} />
        <span className="room-hero__gradient" />
        <div className="room-hero__text">
          <span>{room.home.title}</span>
          <h1>{room.name}</h1>
          <button onClick={toggleFollow}>{room.following ? 'Kamer volgend' : 'Volg kamer'}</button>
        </div>
      </section>
      <div className="dark-tabs">
        {['timeline', 'updates', 'info'].map((name) => (
          <button key={name} className={tab === name ? 'active' : ''} onClick={() => setTab(name)}>
            {name === 'timeline' ? 'Tijdlijn' : name === 'updates' ? 'Updates' : 'Info'}
          </button>
        ))}
      </div>
      {tab === 'timeline' ? (
        <section className="timeline-panel">
          <span className="eyebrow">Fase {active + 1} van {updates.length || 1}</span>
          <h2>{current?.phase_label || 'Nieuwe fase'}</h2>
          <p>{current?.caption || 'Deze kamer heeft nog geen updates.'}</p>
          <div className="timeline-scrub" ref={trackRef} onPointerDown={handlePointer} onPointerMove={(event) => { if (event.buttons) handlePointer(event); }}>
            <span className="timeline-scrub__fill" style={{ width: `${progress * 100}%` }} />
            {updates.map((update, index) => <button key={update.id} className={index === active ? 'active' : ''} style={{ left: `${updates.length < 2 ? 0 : (index / (updates.length - 1)) * 100}%` }} onClick={() => setActive(index)} />)}
            <i style={{ left: `${progress * 100}%` }} />
          </div>
          <div className="timeline-labels">{updates.map((update) => <span key={update.id}>{update.phase_label}</span>)}</div>
        </section>
      ) : null}
      {tab === 'updates' ? (
        <section className="update-list">{updates.map((update) => <article key={update.id}><img src={update.media_url} /><div><strong>{update.phase_label}</strong><p>{update.caption}</p></div></article>)}</section>
      ) : null}
      {tab === 'info' ? (
        <section className="timeline-panel"><h2>Over deze kamer</h2><p>Deze pagina laat zien hoe {room.name.toLowerCase()} door de tijd verandert. Volg de kamer om nieuwe fases in je feed te zien.</p><p>{room.followers} volgers</p></section>
      ) : null}
    </motion.aside>
  );
}
