import React, { useEffect, useState } from 'react';
import { Bookmark, ChevronRight, RefreshCw } from 'lucide-react';
import { motion } from 'framer-motion';
import { FALLBACK_UPDATES } from '../data/fallback';
import { TopBar } from './Layout';

function IntroCard({ goCreate }) {
  return (
    <motion.section className="intro-card" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
      <span>Welkom bij Roomarc</span>
      <h2>Bouw je huis als levend interieurprofiel.</h2>
      <p>Maak kamers aan, plaats updates op je tijdlijn en volg ruimtes van anderen alsof je een interieurproject live meemaakt.</p>
      <div>
        <button onClick={goCreate}>Start in Studio</button>
        <button className="plain-button">Bekijk voorbeeld</button>
      </div>
    </motion.section>
  );
}

export function FeedCard({ update, auth, openRoom, openHome, onRefresh }) {
  const isFallback = String(update.id).startsWith('fb');

  async function toggleSave(event) {
    event.stopPropagation();
    if (isFallback) return;
    await auth.req(`/api/updates/${update.id}/save`, { method: update.saved ? 'DELETE' : 'POST' });
    onRefresh?.();
  }

  async function followRoom(event) {
    event.stopPropagation();
    if (String(update.room.id).startsWith('demo-room')) return;
    await auth.req(`/api/rooms/${update.room.id}/follow`, { method: update.following_room ? 'DELETE' : 'POST' });
    onRefresh?.();
  }

  return (
    <motion.article className="feed-card" layout initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} whileTap={{ scale: 0.99 }}>
      <button className="feed-card__media" onClick={() => openRoom(update.room.id)}>
        <img src={update.media_url} alt={update.room.name} />
        <span className="feed-card__gradient" />
        <span className="feed-card__home" onClick={(event) => { event.stopPropagation(); openHome?.(update.home.slug); }}>{update.home.title}</span>
        <span className="feed-card__label"><small>{update.room.name}</small><strong>{update.phase_label}</strong></span>
        <span className="feed-card__hint">Open tijdlijn <ChevronRight size={15} /></span>
      </button>
      <div className="feed-card__body">
        <p>{update.caption}</p>
        <div className="feed-card__actions">
          <button onClick={followRoom} className={update.following_room ? 'is-following' : ''}>{update.following_room ? 'Kamer volgend' : 'Volg kamer'}</button>
          <button className="icon-button" onClick={toggleSave} aria-label="Bewaren"><Bookmark size={19} fill={update.saved ? 'currentColor' : 'none'} /></button>
        </div>
      </div>
    </motion.article>
  );
}

export function Feed({ auth, openRoom, openHome, version, setTab }) {
  const [items, setItems] = useState(FALLBACK_UPDATES);

  async function load() {
    try {
      await fetch('/api/seed-demo', { method: 'POST' });
      const data = await auth.req('/api/feed/following');
      setItems(data?.length ? data : FALLBACK_UPDATES);
    } catch {
      setItems(FALLBACK_UPDATES);
    }
  }

  useEffect(() => { load(); }, [version]);

  return (
    <main className="screen">
      <TopBar subtitle="Echte ruimtes die veranderen" />
      <IntroCard goCreate={() => setTab('create')} />
      <div className="tab-row">
        <strong>Volgend</strong>
        <span>Nieuw</span>
        <button onClick={load} aria-label="Vernieuwen"><RefreshCw size={15} /></button>
      </div>
      {items.map((item) => <FeedCard key={item.id} update={item} auth={auth} openRoom={openRoom} openHome={openHome} onRefresh={load} />)}
    </main>
  );
}
