export const FALLBACK_UPDATES = [
  {
    id: 'fb1',
    media_url: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1400&q=85',
    caption: 'De woonkamer heeft een warmere basis gekregen. De muren zijn klaar en de sfeer voelt direct rustiger.',
    phase_label: 'Muren afgerond',
    created_at: 'Vandaag',
    room: { id: 'demo-room-living', name: 'Woonkamer', cover_url: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1200&q=80' },
    home: { id: 'demo-home', title: 'The Atelier House', slug: 'the-atelier-house', cover_url: 'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&w=1200&q=80' },
    saved: false,
    following_room: false,
    following_home: false,
  },
  {
    id: 'fb2',
    media_url: 'https://images.unsplash.com/photo-1617325247661-675ab4b64ae2?auto=format&fit=crop&w=1400&q=85',
    caption: 'Eerste stylingronde in de slaapkamer. Linnen, donker eiken en zachter licht.',
    phase_label: 'Gestyled',
    created_at: 'Gisteren',
    room: { id: 'demo-room-bedroom', name: 'Slaapkamer', cover_url: 'https://images.unsplash.com/photo-1617325247661-675ab4b64ae2?auto=format&fit=crop&w=1200&q=80' },
    home: { id: 'demo-home', title: 'The Atelier House', slug: 'the-atelier-house', cover_url: 'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&w=1200&q=80' },
    saved: false,
    following_room: false,
    following_home: false,
  },
  {
    id: 'fb3',
    media_url: 'https://images.unsplash.com/photo-1556911220-bff31c812dba?auto=format&fit=crop&w=1400&q=85',
    caption: 'Materiaalrichting voor de keuken gekozen: lichte steen, rustige fronten en warme messing details.',
    phase_label: 'Materialen gekozen',
    created_at: 'Deze week',
    room: { id: 'demo-room-kitchen', name: 'Keuken', cover_url: 'https://images.unsplash.com/photo-1556911220-bff31c812dba?auto=format&fit=crop&w=1200&q=80' },
    home: { id: 'demo-home', title: 'The Atelier House', slug: 'the-atelier-house', cover_url: 'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&w=1200&q=80' },
    saved: false,
    following_room: false,
    following_home: false,
  },
];

export const DEFAULT_COVER = 'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&w=1200&q=80';
export const DEFAULT_ROOM = 'https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=1200&q=80';
