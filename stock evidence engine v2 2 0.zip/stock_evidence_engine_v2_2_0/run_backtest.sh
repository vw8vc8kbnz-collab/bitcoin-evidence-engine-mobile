#!/usr/bin/env bash
set -euo pipefail
cd /home/ubuntu/stock_evidence_latest
PY=./venv/bin/python
if [ ! -x "$PY" ]; then echo "[SEE] venv missing; run ./install.sh"; exit 1; fi
mkdir -p output
$PY engine.py "${1:-}" "${2:-2y}" 2>&1 | tee output/scan.log
