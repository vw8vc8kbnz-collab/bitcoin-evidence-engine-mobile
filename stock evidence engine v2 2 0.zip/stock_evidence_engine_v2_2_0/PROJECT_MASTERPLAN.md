# PROJECT MASTERPLAN — SEE v2.0.0

## Waar we staan
- Live Opportunity Engine en Validation Engine strikt gescheiden; alle bekende leakage/bias-bronnen (snapshot, entry, drift, overlap, schaal) verwijderd en afgedekt met selftest + positieve/negatieve statistische controles.
- ntfy werkt aantoonbaar (`--ntfy-test`), met tiers: VALIDATED_EDGE (hoogste prioriteit), FINAL_ELITE, LIVE_HIGH_UNVALIDATED.

## Volgende stappen (volgorde)
1. **Forward tracking**: elke live-alert loggen en na 1d/3d/5d/10d het echte rendement erbij schrijven (output/forward_log.csv). Dit is de enige echt hindsight-vrije validatie van de AI-laag.
2. **Benchmark-excess**: drift-baseline uitbreiden met excess vs SPY/QQQ over hetzelfde window (beta-correctie licht).
3. **Point-in-time news archief**: headlines dagelijks wegschrijven in de persistent cache zodat toekomstige validatie van de news/AI-laag zonder hindsight kan.
4. **Multiple-testing verharding**: bij >1500 geteste cellen een FDR-correctie (Benjamini–Hochberg) op excess-CI's overwegen.
5. **5y/10y data** via de persistent cache voor stabielere n_eff.

## Vaste regels
- DeepSeek = live analist, nooit historisch bewijs.
- Nooit één platgedrukte final_score; altijd live vs validated gescheiden tonen.
- Persistent cache `/home/ubuntu/stock_evidence_data_cache` nooit verwijderen.
- Elke release: selftest incl. statistische controles moet slagen vóór deploy.
