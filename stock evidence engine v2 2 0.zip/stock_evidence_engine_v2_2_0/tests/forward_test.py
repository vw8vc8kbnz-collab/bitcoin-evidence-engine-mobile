"""Forward-tracking test for SEE v2.1.0.
Scan 1: ticker with an active validated signal on the last bar -> must be logged, returns empty.
Scan 2: same series + 10 extra bars -> ret_1/3/5/10 must be filled with exact, cost-adjusted values.
"""
import sys, os, tempfile
from pathlib import Path
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import engine as E

tmp=Path(tempfile.mkdtemp())
E.FORWARD_LOG=tmp/'forward_log.csv'

def mkdf(n):
    close=100*np.cumprod(1+np.full(n,0.01))          # deterministic +1%/day
    idx=pd.bdate_range('2026-01-05', periods=n)
    df=pd.DataFrame(index=idx)
    df['Close']=close
    df['Open']=df['Close'].shift(1).fillna(close[0])  # open = prior close
    df['High']=df['Close']*1.001; df['Low']=df['Open']*0.999
    df['Volume']=1_000_000
    return df

df1=mkdf(120); bench1=mkdf(120)
summary=[dict(ticker='SYN',theme='TEST',setup='relative_strength_leader',hold_days=5,
              signal_active_today=1,validated_edge=1,final_extreme=0,hybrid_watchlist=0,
              live_extreme=0,live_elite=0,ai_high=0,live_attention_score=40,
              validation_score=80,ai_final_score=0,excess_vs_drift=2.0,n_eff=15,
              hybrid_signal_score=0)]

rows,perf=E.update_forward_tracking(summary,{'SYN':df1},bench1)
assert len(rows)==1 and rows[0]['tier']=='VALIDATED_ACTIVE', rows
assert str(rows[0]['ret_5d']).strip()=='' , 'returns must be empty on day 0'

# scan 2: same signal already logged (dedupe) + 10 new bars -> fill
df2=mkdf(130); bench2=mkdf(130)
rows,perf=E.update_forward_tracking(summary,{'SYN':df2},bench2)
# dedupe check: signal_date of the logged row is bar 119; today's active signal (bar 129) is NEW -> 2 rows
assert len(rows)==2, f'expected 2 rows (old + new active), got {len(rows)}'
old=[r for r in rows if r['signal_date']==str(df1.index[-1].date())][0]
# exact expectation: entry=Open[i+1]=Close[i] ; exit=Close[i+h] -> (1.01^h -1)*100 - cost
for h in (1,3,5,10):
    exp=round((1.01**h-1)*100 - E.TRADE_COST_PCT,3)
    got=float(old[f'ret_{h}d'])
    assert abs(got-exp)<0.02, (h,got,exp)
    # benchmark identical series -> excess ~ cost difference only (bench has no cost)
    exq=float(old[f'exs_qqq_{h}d'])
    assert abs(exq-(-E.TRADE_COST_PCT))<0.02, (h,exq)
allrec=[p for p in perf if p['tier']=='ALL'][0]
assert allrec['n_5d']==1 and abs(float(allrec['avg_5d'])-round((1.01**5-1)*100-E.TRADE_COST_PCT,3))<0.02
print('FORWARD TRACKING: PASS (log, dedupe, exact fill, QQQ-excess, perf-agg)')
