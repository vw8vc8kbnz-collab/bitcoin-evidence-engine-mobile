"""Positive control for SEE v2.0.0 validation gate.

Design (fixes the flawed earlier test where the edge lived in nearly all bars
and therefore leaked into the unconditional drift baseline):

- Repeating 90-bar cycle:
    bars  0-19 : run-up  +0.80%/day  -> r20 crosses +12% near bar 19 (signal zone)
    bars 20-27 : EDGE    +1.50%/day  -> genuine conditional payoff after signal
    bars 28-89 : decay   -0.44%/day  -> returns price to start; r20<0 so NO signals
- Net cycle return ~= 0  =>  unconditional drift ~= 0.
- Volume constant => relative_volume = 1.0 => only the
  'relative_strength_leader' engine (r20>12 and close>ma20) can fire.

Expectation: at least one (SYN_EDGE, relative_strength_leader, h) cell gets
validated_edge=1, while a random-walk control ticker gets zero validated cells.
"""
import sys, numpy as np, pandas as pd
import os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import engine as E

def make_edge_df(n_cycles=10, seed=7):
    rng = np.random.default_rng(seed)
    daily = []
    for _ in range(n_cycles):
        daily += [0.0080]*20            # run-up
        daily += [0.0150]*8             # conditional edge after signal
        daily += [-0.0044]*62           # slow decay back to base
    daily = np.array(daily) + rng.normal(0, 0.0015, len(daily))  # tiny noise
    close = 100 * np.cumprod(1 + daily)
    idx = pd.bdate_range('2022-06-01', periods=len(close))
    df = pd.DataFrame(index=idx)
    df['Close'] = close
    df['Open'] = df['Close'].shift(1).fillna(close[0])   # no overnight gap
    df['High'] = df[['Open','Close']].max(axis=1)*1.002
    df['Low']  = df[['Open','Close']].min(axis=1)*0.998
    df['Volume'] = 1_000_000
    return df

def make_rw_df(n=900, seed=42):
    rng = np.random.default_rng(seed)
    daily = rng.normal(0, 0.018, n)
    close = 100 * np.cumprod(1 + daily)
    idx = pd.bdate_range('2022-06-01', periods=n)
    df = pd.DataFrame(index=idx)
    df['Close'] = close
    df['Open'] = df['Close'].shift(1).fillna(close[0])
    df['High'] = df[['Open','Close']].max(axis=1)*1.002
    df['Low']  = df[['Open','Close']].min(axis=1)*0.998
    # volume spikes so several engines can fire on the RW ticker too
    vol = rng.integers(800_000, 2_500_000, n).astype(float)
    df['Volume'] = vol
    return df

def fake_meta(df):
    c = df['Close']
    return dict(price=float(c.iloc[-1]), ret3=0.0, ret20=0.0, relative_volume=1.0,
                rs_vs_bench=0.0, position_52w=50.0, technical_score=50.0)

def run():
    dfs = {'SYN_EDGE': make_edge_df(), 'SYN_RW': make_rw_df()}
    summary, trades = [], []
    for t, df in dfs.items():
        rows, trs = E.setup_rows(t, df, fake_meta(df))
        summary += rows; trades += trs
    validation, *_ = _validate(summary, trades, dfs)
    vdf = pd.DataFrame(validation)
    edge_cells = vdf[(vdf.ticker=='SYN_EDGE') & (vdf.validated_edge==1)]
    rw_cells   = vdf[(vdf.ticker=='SYN_RW')   & (vdf.validated_edge==1)]
    show_cols = ['ticker','setup','hold_days','n_orig','n_eff','avg_nonoverlap',
                 'ticker_drift_unconditional','excess_vs_drift','excess_ci90_low','validated_edge']
    print(vdf[(vdf.n_orig>0)][show_cols].to_string(index=False))
    print()
    print(f"SYN_EDGE validated cells: {len(edge_cells)}")
    print(f"SYN_RW   validated cells: {len(rw_cells)}")
    ok = len(edge_cells) >= 1 and len(rw_cells) == 0
    print('POSITIVE CONTROL:', 'PASS' if ok else 'FAIL')
    return 0 if ok else 1

def _validate(summary, trades, dfs):
    out = E.build_validation_tables(summary, trades, price_data=dfs)
    # build_validation_tables may return tuple; normalize
    if isinstance(out, tuple):
        return out
    return (out,)

if __name__ == '__main__':
    sys.exit(run())
