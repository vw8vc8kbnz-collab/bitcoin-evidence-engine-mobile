# Stock Evidence Engine v2.0.0

Twee strikt gescheiden werelden:

1. **Live Opportunity Engine** — wat verdient NU aandacht (Yahoo data, headlines met recency-weging, DeepSeek als live analist). Output: `live_attention_score`.
2. **Validation Engine** — eerlijke historische validatie. Entry op Open van de volgende dag, kosten meegerekend, non-overlapping samples (n_eff), excess vs echte unconditional drift, 90% bootstrap CI. Output: `validated_edge` / `validation_score`. Geen AI, geen snapshot-velden.

## Gebruik
```
./install.sh          # deps + .env bootstrap + systemd
bash selftest.sh      # unit checks + statistische controles (positieve + negatieve)
./run_backtest.sh     # volledige run -> output/*.csv + ntfy
python engine.py --ntfy-test   # test-alert naar je ntfy topic
```

Dashboard: poort **8798**. Stock Lab: `/stock_lab?ticker=PLTR` (cache 2h, `&fresh=1` forceert nieuwe DeepSeek-call).

## Belangrijke paden (server)
- App: `/home/ubuntu/stock_evidence_latest`
- Persistente cache (NOOIT verwijderen): `/home/ubuntu/stock_evidence_data_cache`

## Kernregel
`live_attention_score` is géén bewezen edge. `validated_edge=1` betekent: n_eff≥10, excess boven de eigen drift van de ticker >0.5% én de 90% CI van die excess ligt volledig boven nul. Verwacht dat er WEINIG validated edges zijn — dat is eerlijkheid, geen bug.
