#!/usr/bin/env bash
set -Eeuo pipefail
export PATH=/usr/sbin:/usr/bin:/sbin:/bin
export PYTHONDONTWRITEBYTECODE=1
export PYTHONSAFEPATH=1 PYTHONNOUSERSITE=1
unset PYTHONPATH PYTHONHOME PYTHONSTARTUP PYTHONINSPECT PYTHONUSERBASE

VERSION="R9RC4_FIX56_RUNTIME_PREFLIGHT"
STAGE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PREVIEW_FILE="${METOD_STAGING_PREVIEW_FILE:-/etc/adzaagt/metod-pax/preview-url}"
CURRENT_LINK="${METOD_CURRENT_LINK:-/opt/adzaagt/metod-pax-current}"
ENV_FILE="${METOD_ENV_DIR:-/etc/adzaagt/metod-pax}/metod-pax.env"
NGINX_SITE="/etc/nginx/sites-available/metod-pax"
RELEASES_DIR="${METOD_RELEASES_DIR:-/opt/adzaagt/metod-pax-releases}"

info(){ echo "[$VERSION] $*"; }
fail(){ echo "[$VERSION] FOUT: $*" >&2; exit 1; }
safe_abs_path(){ [[ "$1" =~ ^/[A-Za-z0-9._/-]+$ ]] || fail "Onveilig absoluut pad: $1"; }

source "$STAGE/ops/deploy_lock.sh"

safe_abs_path "$PREVIEW_FILE"
safe_abs_path "$CURRENT_LINK"
safe_abs_path "$ENV_FILE"
safe_abs_path "$RELEASES_DIR"

if [[ "$EUID" -ne 0 ]]; then
  SUDO_ENV=(
    "PYTHONDONTWRITEBYTECODE=1"
    "METOD_STAGING_PREVIEW_FILE=$PREVIEW_FILE"
    "METOD_CURRENT_LINK=$CURRENT_LINK"
    "METOD_ENV_DIR=$(dirname "$ENV_FILE")"
  )
  for name in METOD_LEGACY_APP_DIR METOD_RELEASES_DIR METOD_STATE_ROOT \
              ADMIN_CREDENTIALS_FILE METOD_CONFIG_BACKUP_ROOT \
              HTTP_MAX_CONNECTIONS HTTP_WORKERS ADMIN_ALLOWED_NETWORKS PUBLIC_JOB_MAX_CONCURRENT \
              PUBLIC_JOB_MAX_QUEUED PUBLIC_JOB_MAX_CONCURRENT_PER_IP \
              OPTIMIZER_TIMEOUT_SECONDS OPTIMIZER_JOB_TIMEOUT_SECONDS \
              METOD_DEPLOY_DRAIN_TIMEOUT_SECONDS \
              MIN_FREE_STATE_BYTES MIN_FREE_STATE_INODES \
              METOD_MEMORY_MAX METOD_TASKS_MAX METOD_NOFILE_MAX NTFY_ALLOWED_HOSTS \
              METOD_RELEASE_KEEP METOD_RELEASE_MAX_AGE_DAYS METOD_RELEASE_MAX_BYTES \
              METOD_CONFIG_BACKUP_KEEP METOD_CONFIG_BACKUP_MAX_AGE_DAYS \
              METOD_CONFIG_BACKUP_MAX_BYTES; do
    if [[ -v "$name" ]]; then SUDO_ENV+=("$name=${!name}"); fi
  done
  exec sudo env "${SUDO_ENV[@]}" bash "$0"
fi

for command in /usr/bin/python3 sha256sum curl systemctl nginx grep stat mktemp cmp tr flock readlink; do
  command -v "$command" >/dev/null || fail "Ontbrekend commando: $command"
done
acquire_deploy_lock
[[ -f "$STAGE/SHA256SUMS.txt" ]] || fail "Releasechecksummanifest ontbreekt"
[[ -f "$PREVIEW_FILE" && ! -L "$PREVIEW_FILE" ]] || fail "Preview-URL-bestand ontbreekt of is een symlink"
PREVIEW_METADATA="$(stat -c '%u:%a:%h' "$PREVIEW_FILE")"
[[ "$PREVIEW_METADATA" =~ ^0:(600|640|644):1$ ]] \
  || fail "Preview-URL-bestand heeft onveilige eigenaar, rechten of linkcount: $PREVIEW_METADATA"

PREVIEW_ORIGIN="$(/usr/bin/python3 -I -S -B - "$PREVIEW_FILE" <<'PY'
import re, sys
from pathlib import Path
from urllib.parse import urlparse

raw = Path(sys.argv[1]).read_text(encoding='utf-8', errors='strict').strip()
if not raw or any(char in raw for char in '\r\n\t'):
    raise SystemExit('preview origin is leeg of bevat controltekens')
value = urlparse(raw)
if (
    value.scheme != 'https'
    or not value.hostname
    or value.username
    or value.password
    or value.query
    or value.fragment
    or value.path not in ('', '/')
):
    raise SystemExit('preview origin moet exact https://host[:port] zijn')
if not re.fullmatch(r'(?=.{4,253}\Z)(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.)+[A-Za-z]{2,63}', value.hostname):
    raise SystemExit('preview origin bevat geen veilige publieke DNS-hostnaam')
try:
    port = value.port
except ValueError as exc:
    raise SystemExit('preview origin bevat een ongeldige poort') from exc
if port is not None and not 1 <= port <= 65535:
    raise SystemExit('preview origin bevat een poort buiten 1..65535')
canonical_netloc = value.hostname.lower() + (f':{port}' if port is not None else '')
if value.netloc != canonical_netloc:
    raise SystemExit('preview origin heeft geen canonieke lowercase host[:port]-vorm')
print(f'https://{canonical_netloc}')
PY
)"

info "Fase 1/4: releasechecksums controleren"
(cd "$STAGE" && sha256sum -c SHA256SUMS.txt >/dev/null)

info "Fase 2/4: één atomische stagingdeploy uitvoeren"
METOD_INSTALL_MODE=upgrade \
METOD_DEPLOY_MODE=staging \
PUBLIC_ORIGIN="http://127.0.0.1:8790" \
STAGING_PUBLIC_PORT=8790 \
STAGING_BIND_ADDRESS="127.0.0.1" \
STAGING_ALLOWED_CIDR="" \
STAGING_EXTERNAL_ORIGIN="$PREVIEW_ORIGIN" \
  bash "$STAGE/INSTALL_FROM_STAGE.sh"

info "Fase 3/4: definitieve configuratie bewijzen zonder tweede restart"
systemctl is-active --quiet metod-pax.service || fail "Backendservice is niet actief"
systemctl is-active --quiet nginx || fail "Nginx is niet actief"
nginx -t
[[ -L "$CURRENT_LINK" ]] || fail "Actieve releasepointer ontbreekt of is geen symlink"
CURRENT_TARGET="$(readlink -f -- "$CURRENT_LINK")"
RELEASES_CANONICAL="$(readlink -f -- "$RELEASES_DIR")"
[[ -n "$CURRENT_TARGET" && -d "$CURRENT_TARGET" && ! -L "$CURRENT_TARGET" ]] \
  || fail "Actieve releasetarget ontbreekt, is geen map of is een symlink"
[[ -n "$RELEASES_CANONICAL" && -d "$RELEASES_CANONICAL" && ! -L "$RELEASES_CANONICAL" ]] \
  || fail "Beheerde releaseroot ontbreekt, is geen map of is een symlink"
[[ "$CURRENT_TARGET" == "$RELEASES_CANONICAL/"* ]] \
  || fail "Actieve releasetarget valt buiten de beheerde releaseroot"
[[ "$(stat -c '%U:%G:%a' "$CURRENT_TARGET")" == "root:root:555" ]] \
  || fail "Actieve releasetarget moet exact root:root-owned en mode 0555 zijn"
[[ "$(grep -Fxc 'INSTALLER_REVISION="R9RC4_FIX56_RUNTIME_PREFLIGHT"' "$CURRENT_TARGET/INSTALL_FROM_STAGE.sh")" == "1" ]] \
  || fail "Actieve releasetarget bevat niet exact de FIX56-installerrevisie"
grep -Fxq "METOD_PUBLIC_BASE_URL=$PREVIEW_ORIGIN" "$ENV_FILE" || fail "Publieke basis-URL wijkt af"
grep -Fxq "STAGING_EXTERNAL_HTTPS_PREVIEW=1" "$ENV_FILE" || fail "HTTPS-previewmarker ontbreekt"
grep -Fxq "ALLOWED_ORIGINS=$PREVIEW_ORIGIN" "$ENV_FILE" || fail "Publieke originallowlist wijkt af"
grep -Fxq "ALLOWED_ADMIN_ORIGINS=$PREVIEW_ORIGIN" "$ENV_FILE" || fail "Admin-originallowlist wijkt af"
[[ "$(grep -Fc '    set_real_ip_from 127.0.0.1;' "$NGINX_SITE")" == "1" ]] \
  || fail "Nginx vertrouwt niet exact één lokale cloudflared-hop"
[[ "$(grep -Fc '    real_ip_header CF-Connecting-IP;' "$NGINX_SITE")" == "1" ]] \
  || fail "Nginx mist de genormaliseerde Cloudflare client-IP-header"
[[ "$(grep -Fc '    real_ip_recursive off;' "$NGINX_SITE")" == "1" ]] \
  || fail "Nginx real-IP-vertrouwensketen is niet begrensd"
[[ "$(grep -Fc 'proxy_set_header X-Forwarded-Proto https;' "$NGINX_SITE")" == "4" ]] \
  || fail "Nginx bevat niet exact vier HTTPS-forwardingheaders"
! grep -Fq 'proxy_set_header X-Forwarded-Proto $scheme;' "$NGINX_SITE" \
  || fail "Nginx leidt het externe schema nog af van de lokale HTTP-hop"

info "Fase 4/4: backend, nginx en externe preview byte-exact controleren"
for origin in "http://127.0.0.1:8792" "http://127.0.0.1:8790" "$PREVIEW_ORIGIN"; do
  /usr/bin/python3 -I -S -B "$CURRENT_TARGET/tools/probe_http_release.py" \
    --release "$CURRENT_TARGET" --origin "$origin"
done
info "FIX56_STAGING_UPDATE_OK"
info "Open: $PREVIEW_ORIGIN/?fix56=1"
info "Controleer de nieuwe versie op desktop, iPhone en in Admin. Productiegoedkeuring blijft een afzonderlijke acceptatie."
