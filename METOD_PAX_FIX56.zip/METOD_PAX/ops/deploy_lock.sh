# Internal helper shared by the installation, preview and migration entry scripts.
# The caller provides fail(); no service or filesystem mutation occurs on source.
DEPLOY_LOCK_PATH="/run/metod-pax-deploy.lock"
DEPLOY_LOCK_FD=""

validate_deploy_lock_fd(){
  local fd="$1" descriptor_inode path_inode
  [[ "$fd" =~ ^[0-9]+$ && "$fd" -ge 10 ]] || fail "Ongeldige geërfd deploy-lockdescriptor"
  # /proc/self also resolves correctly when Bash runs in a PID namespace.
  # readlink/stat inherit the descriptor, as do the nested deployment scripts.
  [[ -e "/proc/self/fd/$fd" ]] || fail "Geërfd deploy-lockdescriptor ontbreekt"
  [[ "$(readlink -f "/proc/self/fd/$fd")" == "$DEPLOY_LOCK_PATH" ]] \
    || fail "Geërfd deploy-lockdescriptor wijst niet naar $DEPLOY_LOCK_PATH"
  [[ -f "$DEPLOY_LOCK_PATH" && ! -L "$DEPLOY_LOCK_PATH" ]] \
    || fail "Deploy-lock is geen veilig regulier bestand"
  [[ "$(stat -c '%u:%g:%a:%h' "$DEPLOY_LOCK_PATH")" == "0:0:600:1" ]] \
    || fail "Deploy-lock moet root-owned, mode 0600 en enkelvoudig gelinkt zijn"
  descriptor_inode="$(stat -Lc '%d:%i' "/proc/self/fd/$fd")"
  path_inode="$(stat -Lc '%d:%i' "$DEPLOY_LOCK_PATH")"
  [[ "$descriptor_inode" == "$path_inode" ]] || fail "Deploy-lockdescriptor en lockpad verschillen"
  flock -n "$fd" || fail "Een andere METOD/PAX-installatie, export of deploy is al actief"
}

acquire_deploy_lock(){
  local previous_umask
  [[ -d /run && ! -L /run ]] || fail "Canonieke deploy-lockroot /run ontbreekt of is een symlink"
  previous_umask="$(umask)"
  umask 077
  exec {DEPLOY_LOCK_FD}>"$DEPLOY_LOCK_PATH"
  umask "$previous_umask"
  chmod 0600 "$DEPLOY_LOCK_PATH"
  validate_deploy_lock_fd "$DEPLOY_LOCK_FD"
  export METOD_DEPLOY_LOCK_FD="$DEPLOY_LOCK_FD" METOD_DEPLOY_LOCK_CONTRACT="v1"
}

acquire_or_inherit_deploy_lock(){
  if [[ -n "${METOD_DEPLOY_LOCK_FD:-}" || -n "${METOD_DEPLOY_LOCK_CONTRACT:-}" ]]; then
    require_inherited_deploy_lock
  else
    acquire_deploy_lock
  fi
}

require_inherited_deploy_lock(){
  [[ "${METOD_DEPLOY_LOCK_CONTRACT:-}" == "v1" && -n "${METOD_DEPLOY_LOCK_FD:-}" ]] \
    || fail "Onvolledig geërfd deploy-lockcontract"
  DEPLOY_LOCK_FD="$METOD_DEPLOY_LOCK_FD"
  validate_deploy_lock_fd "$DEPLOY_LOCK_FD"
}
