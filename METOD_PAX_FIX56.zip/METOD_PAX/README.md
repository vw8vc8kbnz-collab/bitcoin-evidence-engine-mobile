# METOD/PAX — FIX56

Deze map bevat de actuele applicatie, broncode, tests en het auditdossier voor `R9RC4_FIX56_RUNTIME_PREFLIGHT`. FIX56 herstelt twee fouten in de runtime-installatiecontrole: een lokale variabele overschaduwde de module `stat` zodra `backup-budget.env` aanwezig was; de geïsoleerde Python-start miste daarnaast het importpad voor de prijsvalidator. Negen regressietests en de extra Ruff-regel F823 bewaken deze correctie. De catalogus-/prijsrefactor uit FIX55 en veilige annulering uit FIX54 blijven behouden. Nerf blijft standaard aan.

Begin als beoordelaar bij **audit/README.md**. De uitgevoerde controles staan in **audit/VALIDATION.json**; de bijbehorende bewijsbestanden staan daadwerkelijk in **audit/evidence/**. Herhaal de tests volgens **docs/TESTEN.md**. Oude auditversies, ontwikkelcheckpoints, Windows-startbestanden en losse distributiearchieven zitten niet in deze map.

| Map / bestand | Doel |
| --- | --- |
| app/ | Actuele Python-applicatie, native JavaScript-modules, HTML-componenten, CSS, DXF-sjablonen en gegenereerde publieke assets |
| tests/ | Uitvoerbare regressie-, API-, herstel-, nginx- en browsertests met synthetische gegevens |
| tools/ | Build, verificatie, veilige installatiegrenzen en herstelhulpmiddelen |
| ops/ | Gedeelde deploylocking, optionele versleutelde offsite-backupdienst en voorbeeldinstellingen |
| dependencies/ | Exacte offline Waitress-runtime en bijbehorende licentie |
| ci/ | Workflow om dezelfde controles in een bronrepository te automatiseren |
| docs/ | Installatie, architectuur, testprocedure, beheer en filterbeheer |
| audit/ | Alleen het actuele auditdossier en het bewijs voor deze release |
| VERSION.json | Centrale versiebron voor de gegenereerde frontend- en Python-versie |
| SHA256SUMS.txt | Volledige bestandsinventaris; controleer met `sha256sum -c SHA256SUMS.txt` |

## Installeren

Gebruik **docs/INSTALLATIE.md** en de afzonderlijk geleverde Termius-regel. De applicatie-zip bevat geen klantgegevens, wachtwoorden of live catalogus. Bestaande gegevens blijven buiten de immutable release in `/var/lib/metod-pax`; het verwijderlogboek staat daarnaast in `/var/lib/metod-pax-privacy`.

Dit is een lokaal gevalideerde auditkandidaat. De feitelijke installatie op de VPS, tests op echte telefoons, herstel op een tweede server en onafhankelijke beoordeling moeten voor deze exacte release nog worden vastgelegd. Het pakket kent zichzelf geen productiegoedkeuring toe.
