"""Customer text, classification, catalog boundaries and nonzero pricing."""

import copy
import csv
import io
import sys
import unittest
from server_fixture import ROOT, preview_csv_text

sys.path.insert(0, str(ROOT / "app"))
from metod_app.contracts.submission import normalize_customer_contract, sanitize_note
from metod_app.catalog.filter_groups import automatic
from metod_app.pricing.quote import price_quote
from catalog_importer import parse_catalog_csv, decor_image_candidates


class ContentContractTests(unittest.TestCase):
    def test_note_punctuation_and_unicode_are_preserved_and_overflow_rejected(self):
        note = "Graag 2x 18mm! Maat 60/80? Levering: 9:00 - 50% korting #1 @Jan € + café"
        self.assertEqual(sanitize_note(note), note)
        self.assertEqual(sanitize_note("é" * 2000), "é" * 2000)
        with self.assertRaises(ValueError):
            sanitize_note("é" * 2001)

    def test_billing_and_distinct_shipping_city_and_country_survive(self):
        original = {
            "billingAddress": "Dorpsstraat",
            "houseNumber": "12/A",
            "postcode": "1000",
            "city": "Brussel",
            "country": "België",
            "shippingSameAsBilling": False,
            "shippingAddress": "Kerkstraat",
            "shippingPostcode": "2000",
            "shippingHouseNumber": "8",
            "shippingCity": "Antwerpen",
            "shippingCountry": "België",
        }
        actual = normalize_customer_contract(original)
        for key, value in original.items():
            self.assertEqual(actual[key], value)
        same = normalize_customer_contract({**original, "shippingSameAsBilling": True})
        self.assertEqual(same["shippingCity"], "Brussel")
        self.assertEqual(same["shippingHouseNumber"], "12/A")

    def test_fineer_is_explicit_and_grondeerfolie_has_its_own_group(self):
        cases = [
            ("Overig", "MDF effen", "Overig"),
            ("Nuxe", "Eiken", "Fineer"),
            ("Overig", "Gefineerd MDF eiken", "Fineer"),
            ("Overig", "MDF Grondeerfolie Wit", "Grondeerfolie"),
            ("Unilin", "Decor met grondeerfolie achterzijde", "Unilin"),
        ]
        for brand, name, expected in cases:
            self.assertEqual(automatic({"brand": brand, "productName": name}, "group")[1], expected)

    def test_import_preview_rejects_formula_article_html_and_unapproved_image_host(self):
        rows = list(csv.reader(io.StringIO(preview_csv_text())))
        for column, bad in [
            (0, '=HYPERLINK("http://example.invalid")'),
            (2, "<img src=x onerror=alert(1)>"),
            (1, "https://unapproved.invalid/image.png"),
        ]:
            changed = copy.deepcopy(rows)
            changed[1][column] = bad
            output = io.StringIO()
            csv.writer(output).writerows(changed)
            parsed = parse_catalog_csv(output.getvalue())
            self.assertGreater(parsed["summary"]["blockingErrors"], 0, (column, parsed))
            self.assertEqual(parsed["records"], [])

    def test_labelled_room_photo_is_never_a_swatch_fallback(self):
        self.assertEqual(
            decor_image_candidates(["https://adzaagt.nl/bedroom.jpg", "https://adzaagt.nl/swatch.jpg"]),
            ["https://adzaagt.nl/swatch.jpg"],
        )
        self.assertEqual(decor_image_candidates(["https://adzaagt.nl/sfeerfoto.jpg"]), [])

    def test_invalid_quote_numbers_never_become_zero_priced_materials(self):
        quote = {
            "materials": [{"sheetCount": 1, "sellPriceInclVatPerSheet": 121}],
            "edgeBanding": {"byCodeMetersWithLossExact": {"1": 2}},
        }
        settings = {
            "edgeBandPricePerM": 4,
            "cncCostPerSheet": 85,
            "drawingCostFixed": 125,
            "transportCostFixed": 50,
        }
        self.assertEqual(price_quote(quote, sell_pricing=settings, vat_rate=0.21)["totalInclVat"], 445.28)
        for key, value in [
            ("sheetCount", 0),
            ("sheetCount", 1.5),
            ("sheetCount", True),
            ("sellPriceInclVatPerSheet", float("nan")),
            ("sellPriceInclVatPerSheet", "oops"),
            ("sellPriceInclVatPerSheet", 0),
        ]:
            invalid = copy.deepcopy(quote)
            invalid["materials"][0][key] = value
            with self.assertRaises(ValueError):
                price_quote(invalid, sell_pricing=settings, vat_rate=0.21)
        invalid = copy.deepcopy(quote)
        invalid["edgeBanding"]["byCodeMetersWithLossExact"]["1"] = "bad"
        with self.assertRaises(ValueError):
            price_quote(invalid, sell_pricing=settings, vat_rate=0.21)
