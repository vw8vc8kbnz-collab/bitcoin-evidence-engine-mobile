"""Real encryption and privacy-aware restore; synthetic, isolated data only."""

import json
import os
import sys
import unittest
from server_fixture import ROOT, TestServer

sys.path.insert(0, str(ROOT / "tools"))
sys.path.insert(0, str(ROOT / "app"))
from offsite_backup import ResticBackup, OffsiteError
from metod_app.admin.privacy import CustomerPrivacyService


@unittest.skipUnless(
    os.environ.get("METOD_TEST_RESTIC"), "Set METOD_TEST_RESTIC to run real encrypted repository drill"
)
class OffsiteTests(unittest.TestCase):
    def test_encrypted_backup_dedup_current_erasure_older_restore_and_restart(self):
        with TestServer() as server:
            private = server.state / "requests/synthetic-customer"
            private.mkdir(parents=True)
            (private / "status.json").write_text(json.dumps({"customer": {"email": "erased@example.test"}}))
            status, body, _ = server.request("POST", "/api/admin/system/backup_now", {})
            self.assertEqual(status, 200, body)
            backup = max(
                (server.state / "backups").glob("system_backup_*.zip"), key=lambda p: p.stat().st_mtime
            )
            ledger = server.state.with_name(server.state.name + "-privacy")
            ledger.mkdir(exist_ok=True)
            password = server.root / "restic-password"
            password.write_text("Synthetic-Repository-Key-Never-Use-In-Production")
            password.chmod(0o600)
            env = dict(
                os.environ,
                RESTIC_REPOSITORY=str(server.root / "encrypted-repository"),
                RESTIC_PASSWORD_FILE=str(password),
            )
            client = ResticBackup(
                executable=os.environ["METOD_TEST_RESTIC"], allow_local_test=True, environment=env
            )
            client.run("init")
            first = client.push(backup, ledger)
            self.assertTrue(client.push(backup, ledger)["skippedUnchanged"])
            privacy = CustomerPrivacyService(server.state, ledger=ledger)
            privacy.erase(privacy.inventory("erased@example.test"), "synthetic-admin")
            second = client.push(backup, ledger)
            self.assertNotEqual(first["snapshot"], second["snapshot"])
            target = server.root / "restored"
            proof = client.restore(first["snapshot"], target)
            self.assertTrue(proof["privacyJournalApplied"])
            self.assertFalse((target / "requests/synthetic-customer").exists())
            client.run("check", "--read-data")
            wrong = server.root / "wrong-password"
            wrong.write_text("Deliberately-wrong-test-repository-key")
            wrong.chmod(0o600)
            invalid = ResticBackup(
                executable=os.environ["METOD_TEST_RESTIC"],
                allow_local_test=True,
                environment={**env, "RESTIC_PASSWORD_FILE": str(wrong)},
            )
            with self.assertRaises(OffsiteError):
                invalid.snapshots()
            server.stop()
            server.state = target
            server.start()
            self.assertEqual(server.request("GET", "/health/ready")[0], 200)
            self.assertEqual(server.request("GET", "/api/admin/pricing")[0], 200)
