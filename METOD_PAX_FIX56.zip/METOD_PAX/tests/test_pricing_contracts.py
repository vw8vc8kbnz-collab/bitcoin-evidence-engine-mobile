#!/usr/bin/env python3
from __future__ import annotations

"""Behavior and ownership proof for the R9C pure pricing-contract extraction."""

import math
import sys
import unittest


RELEASE = __import__("server_fixture").ROOT
APP = RELEASE / "app"
SERVER = APP / "server_py.py"
APPLICATION = APP / "metod_app/runtime/application.py"
sys.path.insert(0, str(APP))

from metod_app.pricing.contracts import (  # noqa: E402
    VAT_RATE,
    material_direct_sell_ex_vat,
    material_direct_sell_incl_vat,
)


class BrokenRecord(dict):
    def get(self, key, default=None):
        raise RuntimeError("deliberate")


class PricingContractBehaviorTests(unittest.TestCase):
    def test_authoritative_gross_field_is_selected_in_established_order(self) -> None:
        record = {
            "sellPriceInclVatPerSheet": 69.57,
            "salePriceInclVatPerSheet": 88.88,
            "directSellPriceInclVatPerSheet": 99.99,
            "sellPriceExVatPerSheet": 1.0,
        }
        self.assertEqual(material_direct_sell_incl_vat(record), 69.57)
        self.assertEqual(VAT_RATE, 0.21)

    def test_all_established_gross_aliases_remain_supported(self) -> None:
        self.assertEqual(material_direct_sell_incl_vat({"salePriceInclVatPerSheet": "123.456"}), 123.46)
        self.assertEqual(material_direct_sell_incl_vat({"directSellPriceInclVatPerSheet": 42}), 42.0)

    def test_legacy_net_aliases_are_only_a_fallback_and_receive_vat(self) -> None:
        for key in (
            "sellPriceExVatPerSheet",
            "salePriceExVatPerSheet",
            "directSellPriceExVatPerSheet",
        ):
            self.assertEqual(
                material_direct_sell_incl_vat({key: 57.5}),
                round(57.5 * 1.21, 2),
                key,
            )
        self.assertEqual(
            material_direct_sell_incl_vat(
                {
                    "sellPriceInclVatPerSheet": -1,
                    "sellPriceExVatPerSheet": 57.5,
                }
            ),
            round(57.5 * 1.21, 2),
        )

    def test_invalid_and_unrelated_values_fail_closed(self) -> None:
        for record in (
            None,
            [],
            {},
            {"purchasePrice": 99.0},
            {"retailPriceWithoutTax": 99.0},
            {"sellPriceInclVatPerSheet": "bad"},
            {"sellPriceInclVatPerSheet": 0},
            {"sellPriceInclVatPerSheet": -10},
            {"sellPriceInclVatPerSheet": float("nan")},
        ):
            self.assertEqual(material_direct_sell_incl_vat(record), 0.0, record)

    def test_unexpected_mapping_failure_is_not_silently_priced(self):
        with self.assertRaises(RuntimeError):
            material_direct_sell_incl_vat(BrokenRecord())

    def test_accounting_net_equivalent_uses_the_exact_gross_truth(self) -> None:
        gross = material_direct_sell_incl_vat({"sellPriceInclVatPerSheet": 69.57})
        net = material_direct_sell_ex_vat({"sellPriceInclVatPerSheet": 69.57})
        self.assertEqual(gross, 69.57)
        self.assertTrue(math.isclose(net, 69.57 / 1.21, rel_tol=0.0, abs_tol=1e-12))
        self.assertEqual(material_direct_sell_ex_vat({}), 0.0)

    def test_helpers_do_not_mutate_catalog_records(self) -> None:
        record = {
            "sellPriceInclVatPerSheet": "69.57",
            "priceSource": "CSV_SALE_PRICE_INCL_VAT",
            "nested": {"preserve": True},
        }
        before = repr(record)
        material_direct_sell_incl_vat(record)
        material_direct_sell_ex_vat(record)
        self.assertEqual(repr(record), before)


if __name__ == "__main__":
    unittest.main(verbosity=2)
