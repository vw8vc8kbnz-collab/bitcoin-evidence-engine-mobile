"""FIX55 guards: exact FIX54 behavior plus cache isolation at the domain boundary."""
from dataclasses import fields
import json
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import threading
import unittest
from server_fixture import ROOT

sys.path.insert(0, str(ROOT / 'app'))
from metod_app.catalog.runtime import CatalogRuntime
from metod_app.pricing.runtime import PricingRuntime
from metod_app.runtime.ports import CatalogRuntimePorts, PricingRuntimePorts, StorageCatalogPublicationPorts


class RuntimeBaselineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        run = subprocess.run(
            [sys.executable, '-B', str(ROOT / 'tests/runtime_behavior_snapshot.py'), '--release', str(ROOT)],
            cwd=ROOT, text=True, capture_output=True, timeout=30,
        )
        if run.returncode:
            raise RuntimeError(run.stdout + run.stderr)
        cls.actual = json.loads(run.stdout)
        cls.baseline = json.loads((ROOT / 'tests/fixtures/runtime-catalog-pricing-fix54.json').read_text())

    def check_section(self, name):
        self.assertEqual(self.actual[name], self.baseline[name])

    def test_material_names_and_explicit_invalidation(self):
        self.check_section('names')
        self.assertEqual(self.actual['names']['invalidation'], ['Eiken', 'Nieuw'])

    def test_catalog_lookup_refreshes_on_atomic_replacement(self):
        self.check_section('lookup')
        self.assertTrue(self.actual['lookup']['sameObjectForUnchangedFile'])

    def test_hash_cache_detects_same_size_same_mtime_mutation(self):
        self.check_section('hashCache')
        self.assertTrue(self.actual['hashCache']['sameSizeSameMtimeMutationDetected'])

    def test_publication_commit_and_rollback_invalidate_all_catalog_views(self):
        self.check_section('publication')
        publication = self.actual['publication']
        self.assertEqual(publication['rollback']['name'], publication['initialName'])
        self.assertEqual(publication['commit']['name'], 'Published decor')
        for key in ['rollback', 'commit']:
            self.assertTrue(publication[key]['journalRemoved'])
            self.assertEqual(publication[key]['responseCache'], {'mtimeNs': None, 'body': None, 'etag': None})

    def test_dxf_classification_migration_duplicates_and_manifest(self):
        self.check_section('dxf')
        self.assertEqual(self.actual['dxf']['movedAgain'], 0)

    def test_pricing_save_reload_audit_conflicts_and_rejections(self):
        self.check_section('pricing')
        self.assertTrue(self.actual['pricing']['conflictPreservedBytes'])
        self.assertTrue(self.actual['pricing']['invalidPreservedBytes'])

    def test_eighteen_full_quotes_preserve_rounding_and_fixed_costs(self):
        self.check_section('quotes')
        self.assertEqual(len(self.actual['quotes']), 18)

    def test_authoritative_snapshot_and_hash_preserve_catalog_prices(self):
        self.check_section('authority')
        self.assertIn('value', self.actual['authority'])
        self.assertEqual(self.actual['authority']['value'][1]['materials'][0]['sellPriceInclVatPerSheet'], 140.24)


class DomainOwnershipTests(unittest.TestCase):
    def test_domain_ports_do_not_inject_the_owners_own_methods(self):
        for owner, ports in [(CatalogRuntime, CatalogRuntimePorts), (PricingRuntime, PricingRuntimePorts)]:
            methods = set(vars(owner))
            for field in fields(ports):
                self.assertNotIn(field.name, methods)
                self.assertNotIn('_' + field.name, methods)

    def test_catalog_owners_have_independent_caches_and_live_path_dependencies(self):
        with tempfile.TemporaryDirectory() as temporary:
            base = Path(temporary)
            path = base / 'first.json'
            path.write_text(json.dumps({'records': [{'articleNo': 'A', 'productName': 'First'}]}))
            material_lock, price_lock, response_lock = threading.RLock(), threading.RLock(), threading.RLock()
            response_cache = {'mtimeNs': None, 'body': None, 'etag': None}
            publication = StorageCatalogPublicationPorts(
                get_catalog_import_root=lambda: base / 'imports',
                get_catalog_public_id_registry=lambda: base / 'public.json',
                get_catalog_taxonomy_registry=lambda: base / 'taxonomy.json',
                get_decor_media_root=lambda: base / 'media',
                get_material_library_path=lambda: path,
                get_system_dir=lambda: base / 'system',
                get_pricing_config_lock=lambda: price_lock,
                invalidate_material_lookup_cache=lambda: None,
                invalidate_material_name_cache=lambda: None,
                invalidate_public_materials_response_cache=lambda: None,
            )
            ports = CatalogRuntimePorts(
                get_dxf_categories=lambda: [], get_dxf_library_root=lambda: base / 'dxf',
                get_dxf_manifest_path=lambda: base / 'manifest.json',
                get_material_library_path=lambda: path, get_material_library_lock=lambda: material_lock,
                get_public_materials_response_cache=lambda: response_cache,
                get_public_materials_response_cache_lock=lambda: response_lock,
                get_public_material_id_re=lambda: re.compile(r'^decor_[a-f0-9]{20,40}$'),
                catalog=publication,
            )
            first, second = CatalogRuntime(ports), CatalogRuntime(ports)
            self.assertEqual(first._best_material_name('A'), 'First')
            self.assertEqual(second._best_material_name('A'), 'First')
            path.write_text(json.dumps({'records': [{'articleNo': 'A', 'productName': 'Updated'}]}))
            first._invalidate_material_name_cache()
            self.assertEqual(first._best_material_name('A'), 'Updated')
            self.assertEqual(second._best_material_name('A'), 'First')
            # Path suppliers remain live rather than becoming stale captured values.
            path = base / 'second.json'
            path.write_text(json.dumps({'records': [{'articleNo': 'B', 'productName': 'Other'}]}))
            first._invalidate_material_name_cache()
            self.assertEqual(first._best_material_name('B'), 'Other')
            first_map = first._material_lookup_snapshot()
            second_map = second._material_lookup_snapshot()
            self.assertEqual(first_map, second_map)
            self.assertIsNot(first_map, second_map)
            first._invalidate_material_lookup_cache()
            self.assertEqual(first_map['catalogByInternal'], {})
            self.assertIn('B', second_map['catalogByInternal'])
