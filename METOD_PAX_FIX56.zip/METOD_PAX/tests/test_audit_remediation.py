"""Behavioral regressions for the FIX50 follow-up findings."""

import csv
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest
import zipfile

from server_fixture import ROOT, TestServer, preview_csv_text

sys.path.insert(0, str(ROOT / "app"))
from catalog_importer import parse_catalog_csv
from metod_app.admin.network_policy import admin_networks, BROAD_NETWORK_ACKNOWLEDGEMENT
from metod_app.admin.privacy import CustomerPrivacyService
from metod_app.http.wsgi import ApplicationServer
from metod_app.security.redaction import redact_sensitive_text


class AuditBoundaryTests(unittest.TestCase):
    def test_network_policy_rejects_split_wildcards_and_aggregate_broad_ranges(self):
        for value in ("0.0.0.0/0", "::/0", "0.0.0.0/1,128.0.0.0/1", "::/1,8000::/1"):
            with self.subTest(value=value), self.assertRaises(ValueError):
                admin_networks(
                    {
                        "ADMIN_ALLOWED_NETWORKS": value,
                        "ADMIN_BROAD_NETWORKS_ACKNOWLEDGED": BROAD_NETWORK_ACKNOWLEDGEMENT,
                    },
                    required=True,
                )
        for value in ("10.0.0.0/8", "2001:db8::/32", "10.0.0.0/16,10.1.0.0/16", "bad", "10.1.2.3,", ""):
            with self.subTest(value=value), self.assertRaises(ValueError):
                admin_networks({"ADMIN_ALLOWED_NETWORKS": value}, required=True)
        self.assertEqual(
            len(
                admin_networks(
                    {"ADMIN_ALLOWED_NETWORKS": "10.1.0.0/24,203.0.113.4/32,2001:db8::/64"}, required=True
                )
            ),
            3,
        )
        self.assertEqual(
            len(
                admin_networks(
                    {
                        "ADMIN_ALLOWED_NETWORKS": "10.0.0.0/8",
                        "ADMIN_BROAD_NETWORKS_ACKNOWLEDGED": BROAD_NETWORK_ACKNOWLEDGEMENT,
                    },
                    required=True,
                )
            ),
            1,
        )
        self.assertEqual(admin_networks({}, required=False), ())

    def test_backend_refuses_public_listeners_before_socket_binding(self):
        for host in ("0.0.0.0", "::", "192.0.2.1"):
            with self.subTest(host=host), self.assertRaisesRegex(ValueError, "loopback"):
                ApplicationServer((host, 0), object)

    def test_email_is_fully_removed_from_diagnostic_text(self):
        source = "jan@small-company.nl en a+b@andere-onderneming.nl; NL91 ABNA 0417 1643 00"
        output = redact_sensitive_text(source, 1000)
        self.assertEqual(output.count("[redacted-email]"), 2)
        for secret in ("jan", "small-company", "andere-onderneming", "NL91", "0417"):
            self.assertNotIn(secret, output)

    def test_http_image_is_invalid_instead_of_missing_and_mixed_urls_are_rejected(self):
        rows = list(csv.reader(io.StringIO(preview_csv_text())))
        for value in (
            "http://adzaagt.nl/swatch.jpg",
            "https://adzaagt.nl/good.jpg,http://adzaagt.nl/bad.jpg",
        ):
            rows[1][1] = value
            stream = io.StringIO()
            csv.writer(stream).writerows(rows)
            result = parse_catalog_csv(stream.getvalue())
            self.assertEqual(result["records"], [])
            self.assertTrue(
                any(e["code"] == "IMAGE_URL_INVALID" and "https://" in e["message"] for e in result["errors"])
            )


class CustomerExportTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name) / "state"
        self.root.mkdir()
        self.service = CustomerPrivacyService(self.root)
        self.customer = {
            "name": "Test Klant",
            "company": "Voorbeeld BV",
            "email": "one@example.invalid",
            "billingAddress": "Teststraat",
            "houseNumber": "12A",
            "city": "Utrecht",
            "country": "Nederland",
            "shippingSameAsBilling": False,
            "shippingAddress": "Kerkstraat",
            "shippingHouseNumber": "8",
            "shippingCity": "Antwerpen",
            "shippingCountry": "België",
            "note": '<svg onload="alert(1)"> Maat 60/80? #1 €',
        }
        self.put("requests/one/status.json", {"customer": self.customer, "job": {"parentJobId": "job_one"}})
        self.put(
            "jobs/job_one/input/job.json", {"customer": self.customer, "publicAccessToken": "INTERNAL_TOKEN"}
        )
        self.put(
            "jobs/job_one/output/calculation_pricing.json",
            {"summary": {"currency": "EUR", "totalInclVat": 123.45, "internalPath": "/PRIVATE_SERVER_PATH"}},
        )
        self.put("jobs/job_one/.public_access.json", {"token": "INTERNAL_TOKEN"})
        self.put("jobs/job_one/output/toolb_cmd.txt", "/PRIVATE_SERVER_PATH/python3 --command")
        self.put(
            "requests/two/status.json",
            {"customer": {"email": "two@example.invalid", "name": "OTHER_CUSTOMER"}},
        )

    def put(self, name, data):
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data))

    def test_customer_export_is_readable_allowlisted_and_excludes_internal_and_other_customer_data(self):
        inventory = self.service.inventory("one@example.invalid")
        with (
            self.service.export_customer(inventory, "one@example.invalid") as stream,
            zipfile.ZipFile(stream) as export,
        ):
            self.assertEqual(set(export.namelist()), {"klantgegevens.json", "KLANTGEGEVENS.txt"})
            content = "\n".join(export.read(name).decode() for name in export.namelist())
            data = json.loads(export.read("klantgegevens.json"))
        for value in ("Voorbeeld BV", "Teststraat", "Kerkstraat", "Antwerpen", "België", "60/80", "123.45"):
            self.assertIn(value, content)
        for value in (
            "PRIVATE_SERVER_PATH",
            "INTERNAL_TOKEN",
            "OTHER_CUSTOMER",
            "public_access",
            "toolb_cmd",
            "two@example.invalid",
        ):
            self.assertNotIn(value, content)
        self.assertEqual(data["requests"][0]["customer"], self.customer)
        self.assertEqual(data["calculations"][0]["pricing"]["totalInclVat"], 123.45)
        with self.service.export_internal(inventory) as stream, zipfile.ZipFile(stream) as export:
            self.assertIn("jobs/job_one/output/toolb_cmd.txt", export.namelist())
            self.assertIn("NIET DOORSTUREN", export.read("LEESMIJ.txt").decode())

    def test_historical_draft_checkout_fields_and_panels_are_exported_without_internal_fields(self):
        self.put(
            "drafts/saved.json",
            {
                "payload": {
                    "checkout": {"customer": self.customer, "note": "Bel bij aankomst"},
                    "cart": [{"name": "Deur", "qty": 2, "widthMm": 597, "internalToken": "NEVER_EXPORT"}],
                },
                "sessionSecret": "NEVER_EXPORT",
            },
        )
        inventory = self.service.inventory(self.customer["email"])
        with (
            self.service.export_customer(inventory, self.customer["email"]) as stream,
            zipfile.ZipFile(stream) as archive,
        ):
            data = json.loads(archive.read("klantgegevens.json"))
        draft = data["drafts"][0]
        self.assertEqual(draft["customer"]["company"], "Voorbeeld BV")
        self.assertIn("Bel bij aankomst", draft["notes"])
        self.assertEqual(draft["items"][0]["qty"], 2)
        self.assertNotIn("NEVER_EXPORT", json.dumps(data))

    def test_canonical_csv_panels_are_projected_without_extra_columns(self):
        path = self.root / "jobs/job_one/input/panels.csv"
        path.write_text(
            "PartId;PanelName;Qty;LengthMm;WidthMm;ThicknessMm;internalPath\nP1;Deur A;2;797;597;18;/PRIVATE_PATH\n"
        )
        inventory = self.service.inventory(self.customer["email"])
        with (
            self.service.export_customer(inventory, self.customer["email"]) as stream,
            zipfile.ZipFile(stream) as archive,
        ):
            data = json.loads(archive.read("klantgegevens.json"))
            readable = archive.read("KLANTGEGEVENS.txt").decode()
        item = data["calculations"][0]["items"][0]
        self.assertEqual(item["qty"], "2")
        self.assertEqual(item["widthMm"], "597")
        self.assertIn("Breedte (mm): 597", readable)
        self.assertNotIn("PRIVATE_PATH", readable)
        path.unlink()
        path.symlink_to(self.root / "requests/two/status.json")
        with self.assertRaises(ValueError):
            self.service.export_customer(inventory, self.customer["email"])

    def test_customer_export_refuses_document_symlink_in_authorized_family(self):
        inventory = self.service.inventory("one@example.invalid")
        path = self.root / "jobs/job_one/output/calculation_pricing.json"
        path.unlink()
        path.symlink_to(self.root / "requests/two/status.json")
        with self.assertRaises(ValueError):
            self.service.export_customer(inventory, "one@example.invalid")

    def test_http_customer_export_is_default_and_internal_requires_separate_confirmation(self):
        with TestServer() as server:
            path = server.state / "requests/synthetic/status.json"
            path.parent.mkdir(parents=True)
            path.write_text(json.dumps({"customer": self.customer}))
            email = self.customer["email"]
            status, preview, _ = server.request(
                "POST", "/api/admin/privacy", {"action": "preview", "email": email}
            )
            self.assertEqual(status, 200)
            payload = {"email": email, "revision": preview["revision"], "action": "export"}
            status, content, headers = server.request("POST", "/api/admin/privacy", payload)
            self.assertEqual(status, 200)
            self.assertIn("no-store", headers["Cache-Control"])
            with zipfile.ZipFile(io.BytesIO(content)) as archive:
                self.assertEqual(len(archive.namelist()), 2)
            self.assertEqual(
                server.request("POST", "/api/admin/privacy", {**payload, "action": "export_internal"})[0], 400
            )
            self.assertEqual(
                server.request(
                    "POST",
                    "/api/admin/privacy",
                    {**payload, "action": "export_internal", "internalConfirmation": "INTERN"},
                )[0],
                200,
            )
            self.assertEqual(
                server.request("POST", "/api/admin/privacy", {**payload, "revision": "stale"})[0], 409
            )
            self.assertIn(server.request("POST", "/api/admin/privacy", payload, auth=False)[0], (401, 403))
