"""Run the installation runtime gate with deployed-style, disposable state.

The environment comes from the actual DEPLOY.sh template. No service is installed
or started. Non-root test runners emulate only root ownership of the two fixture
files; permissions, paths, budget parsing and all runtime checks stay real.
"""

from __future__ import annotations

from contextlib import redirect_stdout
import io
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from server_fixture import ROOT, seed_catalog_and_credentials

sys.path.insert(0, str(ROOT / "tools"))
import final_preflight


def seed_runtime_profile(work: Path, release: Path = ROOT) -> tuple[Path, Path, Path]:
    state = work / "state"
    config = work / "config"
    config.mkdir()
    credentials = config / "admin_credentials.live.json"
    seed_catalog_and_credentials(state, credentials)
    values = {
        "STATE_DIR": str(state),
        "APP_PUBLIC_ORIGIN": "https://preview.example.invalid",
        "APP_ENV": "staging",
        "STAGING_EXTERNAL_HTTPS_PREVIEW": "1",
        "PROD": "0",
        "ADMIN_ALLOWED_NETWORKS_VALUE": "127.0.0.1/32,::1/128",
        "PUBLIC_JOB_MAX_CONCURRENT_VALUE": "1",
        "PUBLIC_JOB_MAX_QUEUED_VALUE": "8",
        "PUBLIC_JOB_MAX_CONCURRENT_PER_IP_VALUE": "1",
        "OPTIMIZER_TIMEOUT_SECONDS_VALUE": "120",
        "OPTIMIZER_JOB_TIMEOUT_SECONDS_VALUE": "3600",
        "HTTP_MAX_CONNECTIONS_VALUE": "128",
        "HTTP_WORKERS_VALUE": "16",
        "MIN_FREE_STATE_BYTES_VALUE": "67108864",
        "MIN_FREE_STATE_INODES_VALUE": "10000",
        "CATALOG_MIN": "1",
    }
    deployment = (release / "DEPLOY.sh").read_text()
    template = re.search(r'cat > "\$ENV_FILE.tmp" <<EOF\n(.*?)\nEOF', deployment, re.S)
    if template is None:
        raise AssertionError("deployment environment template missing")
    text = re.sub(r"\$\{[A-Z_]+:-([^}]*)\}", lambda match: match[1], template[1])
    text = re.sub(r"\$([A-Z_]+)", lambda match: values[match[1]], text)
    # A deliberately unusable primary budget proves that the separate file is
    # loaded and applied, rather than merely inspected and then ignored.
    text = re.sub(r"(?m)^BACKUP_TOTAL_MAX_BYTES=.*$", "BACKUP_TOTAL_MAX_BYTES=0", text)
    env = config / "metod-pax.env"
    env.write_text(text + f"\nADMIN_CREDENTIALS_FILE={credentials}\n")
    budget = config / "backup-budget.env"
    budget.write_text("BACKUP_TOTAL_MAX_BYTES=536870912\nBACKUP_MIN_FREE_BYTES=67108864\n")
    budget.chmod(0o600)
    return state, env, budget


class RuntimePreflightTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.work = Path(temporary.name)
        self.state, self.env, self.budget = seed_runtime_profile(self.work)
        if os.geteuid() != 0:
            original = Path.lstat
            owned = {self.budget, self.env.parent / "admin_credentials.live.json"}

            def deployed_metadata(path):
                metadata = original(path)
                if path not in owned:
                    return metadata
                return SimpleNamespace(
                    st_mode=metadata.st_mode, st_uid=0, st_gid=0, st_nlink=metadata.st_nlink
                )

            owner_patch = patch.object(Path, "lstat", deployed_metadata)
            owner_patch.start()
            self.addCleanup(owner_patch.stop)

    def run_gate(self):
        checks = final_preflight.Preflight()
        output = io.StringIO()
        with redirect_stdout(output):
            final_preflight.validate_runtime(checks, ROOT, self.env, None)
        self.assertFalse(list(self.state.glob(".preflight-write-*")))
        return checks.failures, output.getvalue()

    def test_existing_budget_runs_complete_runtime_gate(self):
        failures, output = self.run_gate()
        self.assertEqual(failures, [], output)
        self.assertIn("vrije state-inodes", output)
        self.assertIn("service-identiteit kan externe state duurzaam schrijven", output)

    def test_pricing_contract_loads_with_isolated_python(self):
        # DEPLOY.sh invokes preflight with -I -S -B: no ambient app import path.
        script = """
import importlib.util, json, sys
from pathlib import Path
root = Path(sys.argv[1])
spec = importlib.util.spec_from_file_location('preflight', root / 'tools/final_preflight.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
validate, signoff = module.load_pricing_authority_contract(root)
validate(json.loads((root / 'app/config/pricing_active.json').read_text()))
assert callable(signoff)
"""
        result = subprocess.run(
            [sys.executable, "-I", "-S", "-B", "-c", script, str(ROOT)],
            capture_output=True, text=True, timeout=30, cwd=self.work,
        )
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_absent_budget_uses_primary_environment(self):
        self.budget.unlink()
        self.env.write_text(self.env.read_text().replace("BACKUP_TOTAL_MAX_BYTES=0", "BACKUP_TOTAL_MAX_BYTES=536870912"))
        failures, output = self.run_gate()
        self.assertEqual(failures, [], output)
        self.assertIn("vrije state-inodes", output)

    def test_budget_rejects_world_readable_permissions(self):
        self.budget.chmod(0o644)
        failures, _ = self.run_gate()
        self.assertEqual(failures, ["backup-budget.env must be root-owned, regular and mode 0600"])

    def test_budget_rejects_symlink(self):
        target = self.budget.with_name("target.env")
        self.budget.rename(target)
        self.budget.symlink_to(target)
        failures, _ = self.run_gate()
        self.assertEqual(failures, ["backup-budget.env must be root-owned, regular and mode 0600"])

    def test_budget_rejects_directory(self):
        self.budget.unlink()
        self.budget.mkdir(mode=0o600)
        failures, _ = self.run_gate()
        self.assertEqual(failures, ["backup-budget.env must be root-owned, regular and mode 0600"])

    def test_budget_rejects_non_root_owner(self):
        original = Path.lstat

        def wrong_owner(path):
            metadata = original(path)
            if path != self.budget:
                return metadata
            return SimpleNamespace(st_mode=metadata.st_mode, st_uid=1000)

        with patch.object(Path, "lstat", wrong_owner):
            failures, _ = self.run_gate()
        self.assertEqual(failures, ["backup-budget.env must be root-owned, regular and mode 0600"])

    def test_budget_cannot_override_unrelated_settings(self):
        with self.budget.open("a") as handle:
            handle.write("APP_ENV=production\n")
        failures, _ = self.run_gate()
        self.assertEqual(failures, ["backup-budget.env contains unsupported settings"])

    def test_insufficient_inodes_still_fails_after_budget_check(self):
        actual = os.statvfs(self.state)
        values = {name: getattr(actual, name) for name in dir(actual) if name.startswith("f_")}
        values["f_favail"] = 0
        # disk_usage also calls os.statvfs: preserve real disk capacity.
        with patch.object(final_preflight.os, "statvfs", return_value=SimpleNamespace(**values)):
            failures, _ = self.run_gate()
        self.assertEqual(failures, ["vrije state-inodes >= 10000"])
