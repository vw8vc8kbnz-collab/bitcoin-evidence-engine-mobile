"""Real loopback HTTP server, synthetic customers, isolated disposable state."""

from __future__ import annotations
import csv, hashlib, io, json, os, socket, subprocess, sys, tempfile, time
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import ProxyHandler, Request, build_opener

ROOT = Path(os.environ.get("METOD_TEST_RELEASE", Path(__file__).resolve().parents[1])).resolve()
RELEASE_ROOT = ROOT
TEST_PASSWORD = "synthetic-test-password-only"
TEST_PUBLIC_ID = "decor_0123456789abcdefabcd"
TEST_IMAGE_URL = "https://adzaagt.nl/test-fixtures/decor.png"


def minimal_jpeg(width: int = 2, height: int = 2) -> bytes:
    return (
        b"\xff\xd8\xff\xc0\x00\x11\x08"
        + int(height).to_bytes(2, "big")
        + int(width).to_bytes(2, "big")
        + b"\x03\x01\x11\x00\x02\x11\x00\x03\x11\x00\xff\xd9"
    )


def seed_catalog_and_credentials(state_root: Path, credentials_path: Path) -> bytes:
    state_root.mkdir(parents=True, exist_ok=True)
    # External state bootstrap is deliberately fail-closed when active pricing
    # is absent. Seed the process-level fixture from the same immutable release
    # document the installer validates; never rely on a runtime fallback.
    pricing_seed = RELEASE_ROOT / "app/config/pricing_active.json"
    pricing_target = state_root / "config/pricing_active.json"
    pricing_target.parent.mkdir(parents=True, exist_ok=True)
    pricing_target.write_bytes(pricing_seed.read_bytes())
    from PIL import Image

    buffer = io.BytesIO()
    Image.new("RGB", (64, 64), "#baa37f").save(buffer, "PNG")
    image = buffer.getvalue()
    image_sha = hashlib.sha256(image).hexdigest()
    image_folder = state_root / "decor_media" / TEST_PUBLIC_ID
    image_folder.mkdir(parents=True, exist_ok=True)
    (image_folder / "catalog.img").write_bytes(image)
    (image_folder / "catalog.meta.json").write_text(
        json.dumps(
            {
                "mime": "image/png",
                "sha256": image_sha,
                "bytes": len(image),
                "width": 64,
                "height": 64,
                "variantGenerator": "raw-fallback",
                "variants": {},
            }
        ),
        encoding="utf-8",
    )
    source_hash = hashlib.sha256(TEST_IMAGE_URL.encode("utf-8")).hexdigest()
    library = {
        "source": "CSV_CATALOG_ONLY",
        "pricingModel": "catalog_sell_price_incl_vat_v2",
        "decorLibrarySchemaVersion": 4,
        "records": [
            {
                "articleNo": "HTTP-SMOKE-001",
                "materialCode": "HTTP-SMOKE-001",
                "publicMaterialId": TEST_PUBLIC_ID,
                "productName": "DecoLegno B003 DECObasic FSC",
                "publicName": "DecoLegno B003 DECObasic FSC",
                "brand": "DecoLegno",
                "sourceKind": "CATALOG_IMPORT",
                "active": True,
                "published": True,
                "archived": False,
                "catalogMissing": False,
                "catalogExcluded": False,
                "thicknessMm": 18,
                "sheetWid": 2070,
                "sheetLen": 2800,
                "sellPriceInclVatPerSheet": 140.24,
                "primaryVisualFamily": "Uni",
                "visualFamily": "Uni",
                "visualTags": ["Uni"],
                "substrateType": "SPAANPLAAT",
                "substrateLabel": "Spaanplaat",
                "colorGroup": "Wit",
                "searchTags": ["uni", "wit"],
                "imageSourceUrls": [TEST_IMAGE_URL],
                "imageSourceUrl": TEST_IMAGE_URL,
                "catalogImageSourceHash": source_hash,
            }
        ],
    }
    library_path = state_root / "material_library.json"
    library_path.write_text(json.dumps(library), encoding="utf-8")

    system = state_root / "system"
    system.mkdir(parents=True, exist_ok=True)
    # Avoid racing this focused HTTP test with the independent automatic-backup
    # thread that intentionally drains mutations during its first snapshot.
    (system / "last_auto_backup.json").write_text(
        json.dumps({"ts": "2099-01-01T00:00:00", "file": "http-smoke-fixture.zip"}),
        encoding="utf-8",
    )

    salt = "0123456789abcdef0123456789abcdef"
    digest = hashlib.pbkdf2_hmac("sha256", TEST_PASSWORD.encode(), salt.encode(), 600_000).hex()
    credentials_path.write_text(
        json.dumps(
            {
                "schemaVersion": 2,
                "users": [
                    {
                        "username": "admin",
                        "password_hash": f"pbkdf2_sha256$600000${salt}${digest}",
                        "totp_secret": "",
                        "roles": ["admin"],
                        "active": True,
                    }
                ],
            }
        ),
        encoding="utf-8",
    )
    credentials_path.chmod(0o600)
    return image


def preview_csv_text() -> str:
    output = io.StringIO(newline="")
    writer = csv.writer(output, lineterminator="\n")
    writer.writerow(
        [
            "Product Reference Code",
            "Product Image Urls",
            "Product Name",
            "Feature Max. dikte (mm)",
            "Feature Max. lengte (mm)",
            "Feature Max. breedte (mm)",
            "Prijs per plaat inclusief BTW",
        ]
    )
    writer.writerow(
        [
            "HTTP-SMOKE-001",
            TEST_IMAGE_URL,
            "DecoLegno B003 DECObasic FSC",
            "18",
            "2800",
            "2070",
            "140,24",
        ]
    )
    return output.getvalue()


def reserve_loopback_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        probe.bind(("127.0.0.1", 0))
        return int(probe.getsockname()[1])


def panel_dxf(width=600, height=400):
    pairs = [(0, "SECTION"), (2, "ENTITIES"), (0, "LWPOLYLINE"), (8, "OUTLINE"), (90, 4), (70, 1)]
    for x, y in [(0, 0), (width, 0), (width, height), (0, height)]:
        pairs.extend([(10, x), (20, y)])
    pairs.extend([(0, "ENDSEC"), (0, "EOF")])
    return "".join(f"{code}\n{value}\n" for code, value in pairs).encode()


class TestServer:
    def __init__(self, *, secure=False, environment=None):
        self.secure = secure
        self.environment = environment or {}
        self.temp = tempfile.TemporaryDirectory(prefix="metod-isolated-test-")
        self.root = Path(self.temp.name)
        self.state = self.root / "state"
        self.credentials = self.root / "credentials.json"
        seed_catalog_and_credentials(self.state, self.credentials)
        self.port = reserve_loopback_port()
        self.origin = f"http://127.0.0.1:{self.port}"
        self.opener = build_opener(ProxyHandler({}))
        fixtures = self.root / "image-fixtures"
        fixtures.mkdir()
        image_data = (self.state / "decor_media" / TEST_PUBLIC_ID / "catalog.img").read_bytes()
        (fixtures / (hashlib.sha256(TEST_IMAGE_URL.encode()).hexdigest() + ".bin")).write_bytes(image_data)
        self.cookie = ""
        self.process = None
        self.history = []

    def start(self):
        env = dict(
            os.environ,
            PYTHONDONTWRITEBYTECODE="1",
            PYTHONUNBUFFERED="1",
            METOD_STATE_ROOT=str(self.state),
            METOD_HOST="127.0.0.1",
            METOD_PORT=str(self.port),
            APP_ENV="test",
            DEV_MODE="1",
            PRODUCTION_HARDENING="0",
            ADMIN_CREDENTIALS_FILE=str(self.credentials),
            HTTP_MAX_CONNECTIONS="128",
            METOD_CATALOG_FIXTURES=str(self.root / "image-fixtures"),
        )
        if self.secure:
            env.update(
                APP_ENV="staging",
                DEV_MODE="0",
                STAGING_EXTERNAL_HTTPS_PREVIEW="1",
                ALLOWED_ORIGINS=self.origin,
                ALLOWED_ADMIN_ORIGINS=self.origin,
                TRUSTED_PROXY_IPS="127.0.0.1,::1",
            )
        env.update(self.environment)
        self.log = (self.root / "server.log").open("ab")
        self.process = subprocess.Popen(
            [sys.executable, "-B", str(ROOT / "app/server_py.py")],
            cwd=ROOT / "app",
            env=env,
            stdin=subprocess.DEVNULL,
            stdout=self.log,
            stderr=subprocess.STDOUT,
        )
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline and self.process.poll() is None:
            try:
                if self.request("GET", "/health/live")[0] == 200:
                    if not self.secure:
                        self.login()
                    return self
            except (URLError, TimeoutError, ConnectionError):
                time.sleep(0.1)
        raise RuntimeError((self.root / "server.log").read_text()[-3000:])

    def login(self):
        code, body, headers = self.request(
            "POST",
            "/api/admin/login",
            {"username": "admin", "password": TEST_PASSWORD, "otp": ""},
            auth=False,
        )
        assert code == 200, (code, body)
        self.cookie = headers["Set-Cookie"].split(";", 1)[0]

    def request(self, method, path, body=None, *, auth=True, headers=None, raw=None):
        hdr = {"Accept": "application/json"}
        if auth and self.cookie:
            hdr["Cookie"] = self.cookie
        if method == "POST":
            hdr.update({"Content-Type": "application/json", "Origin": self.origin})
        hdr.update(headers or {})
        data = raw if raw is not None else (json.dumps(body).encode() if body is not None else None)
        req = Request(self.origin + path, data=data, headers=hdr, method=method)
        try:
            response = self.opener.open(req, timeout=30)
        except HTTPError as error:
            response = error
        with response:
            status, response_headers, content = response.code, response.headers, response.read()
        try:
            result = json.loads(content)
        except (ValueError, UnicodeError):
            result = content
        self.history.append({"method": method, "path": path, "status": status})
        return status, result, response_headers

    def stop(self):
        if self.process is not None:
            self.process.terminate()
            try:
                self.process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait(timeout=5)
            self.process = None
            self.log.close()

    def close(self):
        self.stop()
        self.temp.cleanup()

    def __enter__(self):
        try:
            return self.start()
        except BaseException:
            self.close()
            raise

    def __exit__(self, *args):
        self.close()
