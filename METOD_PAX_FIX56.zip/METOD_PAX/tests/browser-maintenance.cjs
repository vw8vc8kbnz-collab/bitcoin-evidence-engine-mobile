/** Real interactions through edit, error, grain and cancellation paths. */
const { chromium } = require("playwright");
const fs = require("node:fs");
const assert = require("node:assert/strict");

function coverageSummary(entries) {
  return entries
    .filter((e) => /\/assets\/tool-a\./.test(e.url))
    .map((e) => ({
      asset: new URL(e.url).pathname,
      codeUnits: (e.source || e.text || "").length,
      ranges: e.ranges || e.functions.flatMap((fn) => fn.ranges),
    }));
}

(async () => {
  const [url, widthText, output] = process.argv.slice(2),
    width = Number(widthText);
  const browser = await chromium.launch({
    headless: true,
    args: ["--no-sandbox"],
  });
  const page = await browser.newPage({
    viewport: { width, height: 844 },
    timezoneId: "Europe/Amsterdam",
  });
  page.setDefaultTimeout(8000);
  const report = {
    width,
    checks: [],
    errors: [],
    snapshots: {},
    snapshotScrollPolicy:
      "Wait for focus and transient panel hint, then reset rightScroll for reproducible layout comparison",
  };
  let failTemplates = true;
  await page.route("**/embedded_dxfs/**", (route) =>
    failTemplates
      ? route.fulfill({
          status: 503,
          contentType: "text/plain",
          body: "Synthetic temporary DXF failure",
        })
      : route.continue(),
  );
  page.on("pageerror", (e) => report.errors.push(e.message));
  await page.coverage.startJSCoverage({ resetOnNavigation: false });
  await page.coverage.startCSSCoverage({ resetOnNavigation: false });
  async function snapshot(name) {
    await page.evaluate(() => document.activeElement?.blur());
    await page.waitForTimeout(600); // Includes the component's scroll stabilization frames.
    // The added/updated hint hides itself after 1.8 seconds and affects height.
    await page.locator("#panelDockHint").waitFor({ state: "hidden" });
    // Browser focus scrolling can stop a few pixels apart. Compare layout at
    // the same scroll position after the actual interaction has been tested.
    await page
      .locator("#rightScroll")
      .evaluate((el) => el.scrollTo({ top: 0, left: 0, behavior: "instant" }));
    await page.evaluate(
      () => new Promise((resolve) => requestAnimationFrame(resolve)),
    );
    report.snapshots[name] = await page.evaluate(() => {
      const properties = [
        "display",
        "visibility",
        "color",
        "backgroundColor",
        "fontSize",
        "fontWeight",
        "borderRadius",
        "padding",
        "gap",
        "overflow",
        "position",
        "flexDirection",
      ];
      const selectors = [
        "body",
        ".left",
        ".right",
        "#rightScroll",
        ".canvasWrap",
        ".decorCard",
        ".decorFilterBtn",
        "#stepPanels",
        "#panelDock",
        "#panelDockLauncher",
        ".panelDockRow",
        "#extraOverlay",
        ".extraModal",
        "#grainOverlay",
        ".grainGrid",
        ".grainColCard",
        ".grainChip",
        "#grainGroups",
        "#grainPreview",
        "#stepCustomer",
        "#toolAlertOverlay",
        "#removeMaterialOverlay",
        "#wizardNextBtn",
      ];
      return selectors.flatMap((selector) =>
        [...document.querySelectorAll(selector)].map((el, index) => {
          const style = getComputedStyle(el),
            rect = el.getBoundingClientRect();
          return {
            selector,
            index,
            style: Object.fromEntries(properties.map((p) => [p, style[p]])),
            rect: [rect.x, rect.y, rect.width, rect.height].map(
              (v) => Math.round(v * 10) / 10,
            ),
          };
        }),
      );
    });
    await page.screenshot({
      path: output.replace(".json", `-${name}.png`),
      animations: "disabled",
    });
  }
  async function panelsReady() {
    await page.waitForFunction(() => document.body.dataset.uiStep === "panels");
    await page.waitForFunction(
      () =>
        !document.querySelector("#addBtnInline").disabled &&
        window.state.templates.has(window.state.selection.templateId),
    );
  }
  try {
    await page.goto(url, { waitUntil: "domcontentloaded" });
    await page.locator(".decorCard").first().waitFor();
    await snapshot("materials");
    const search = page.locator(
      width < 700 ? "#decorMobileSearch" : "#matSearch",
    );
    await search.fill("bestaat-geen-decor");
    await page.waitForFunction(
      () => document.querySelectorAll(".decorCard").length === 0,
    );
    assert.equal(await page.locator(".decorCard").count(), 0);
    await search.fill("");
    await page.locator(".decorCard").first().click();
    await page.locator("#wizardNextBtn").click();
    await page.locator("#templateLoadRetry").waitFor();
    assert.equal(await page.locator("#addBtnInline").isDisabled(), true);
    assert.equal(await page.evaluate(() => window.state.cart.length), 0);
    await snapshot("panel-load-error");
    failTemplates = false;
    await page.locator("#templateLoadRetry").click();
    await panelsReady();
    report.checks.push("dxf-network-error-blocks-add-and-retry-recovers");
    await snapshot("panels");
    report.checks.push("material-filter-empty-and-selection");

    await page.locator("#qty").fill("3");
    await page.locator("#addBtnInline").click();
    await page.waitForFunction(() => window.state.cart.length === 3);
    if (width >= 700) await page.locator("#panelDockLauncher").click();
    await page
      .locator('.panelDockRow [data-act="edit"]:visible')
      .first()
      .click();
    await page.waitForFunction(() => !window.__prefillingPanelEdit);
    await page.locator("#customLabelInput").fill("Deur links");
    await page.locator("#addBtnInline").click();
    await page.waitForFunction(() =>
      window.state.cart.some((p) => /Deur links/.test(JSON.stringify(p))),
    );
    assert.equal(await page.evaluate(() => window.state.cart.length), 3);
    await snapshot("panel-edit");
    report.checks.push("standard-panel-edit");

    await page.locator("#extraOverlayBtn").click();
    await page.locator("#extraName").fill("Passtuk links");
    await page.locator("#extraW").fill("200");
    await page.locator("#extraH").fill("400");
    await page.locator("#extraQty").fill("2");
    if (!(await page.locator("#extraEdgeTop").isChecked()))
      await page
        .locator("label.edgeChip")
        .filter({ has: page.locator("#extraEdgeTop") })
        .click();
    await page.locator("#addExtraBtn").click();
    await page.locator('#extraList [data-act="edit"]').first().click();
    await page.locator("#extraH").fill("450");
    await page.locator("#addExtraBtn").click();
    await snapshot("extra-panels");
    await page.locator("#extraDoneBtn").click();
    report.checks.push("extra-panel-create-edit-and-edge");

    await page.locator("#wizardNextBtn").click();
    await page.locator("#grainOverlay").waitFor();
    await page.locator("#grainNewGroupBtn").click();
    const choices = page.locator(
      width < 700
        ? "#grainEligible .grainStudioCompactPlus:not(:disabled)"
        : "#grainEligible .grainChip:not(.disabled)",
    );
    await choices.first().click();
    await choices.first().click();
    await page.waitForFunction(() =>
      window.state.grain.groups.some((g) => g.items.length === 2),
    );
    await snapshot("grain-group");
    await page
      .getByRole("button", { name: /hoger in de stapel/i })
      .filter({ visible: true })
      .last()
      .click();
    await page
      .locator(
        width < 700
          ? "#grainGroups .grainStudioRemoveBtn"
          : '#grainGroups [data-act="rm"]',
      )
      .first()
      .click();
    await choices.first().click();
    if (width < 700) {
      await page.locator("#grainStudioDrawerHandle").click();
      await snapshot("grain-preview");
      await page.locator("#grainStudioDrawerHandle").click();
    }
    await page.getByRole("button", { name: "Toepassen", exact: true }).click();
    await page.waitForFunction(
      () => document.body.dataset.uiStep === "customer",
    );
    await page.locator("#custEmail").fill("ongeldig");
    await page.locator("#wizardNextBtn").click();
    assert.equal(
      await page.evaluate(() => document.body.dataset.uiStep),
      "customer",
    );
    await snapshot("customer-validation");
    if (await page.locator("#toolAlertOkBtn").isVisible())
      await page.locator("#toolAlertOkBtn").click();
    report.checks.push(
      "grain-group-add-reorder-remove-preview-and-customer-validation",
    );

    await page.locator("#wizardPrevBtn").click();
    await page.getByRole("button", { name: "Annuleren", exact: true }).click();
    await panelsReady();
    await page.locator("#extraOverlayBtn").click();
    await page.locator('#extraList [data-act="del"]').first().click();
    await page.locator("#extraDoneBtn").click();
    await page.locator("#wizardPrevBtn").click();
    // The material pill in step 2 exposes the same removal intent on all viewports.
    await page.locator("#wizardNextBtn").click();
    await panelsReady();
    await page.locator("#matChosenStep2Chips [data-mrm]").first().click();
    await page.locator("#removeMaterialOverlay").waitFor();
    await snapshot("remove-confirmation");
    await page.locator("#removeMaterialConfirmBtn").click();
    await page.waitForFunction(() => window.state.materialBatches.length === 0);
    report.checks.push("remove-extra-and-last-material-with-confirmation");
    assert.deepEqual(report.errors, []);
    report.status = "PASS";
  } catch (error) {
    report.status = "FAIL";
    report.failure = error.stack;
    report.visible = await page
      .locator("body")
      .innerText()
      .catch(() => "unresponsive");
    await page
      .screenshot({ path: output.replace(".json", "-failure.png") })
      .catch(() => {});
  }
  fs.writeFileSync(output, JSON.stringify(report, null, 2) + "\n");
  try {
    report.coverage = {
      javascript: coverageSummary(await page.coverage.stopJSCoverage()),
      css: coverageSummary(await page.coverage.stopCSSCoverage()),
    };
  } finally {
    await browser.close();
  }
  fs.writeFileSync(output, JSON.stringify(report, null, 2) + "\n");
  console.log(
    JSON.stringify({
      status: report.status,
      checks: report.checks,
      failure: report.failure,
    }),
  );
  process.exitCode = report.status === "PASS" ? 0 : 1;
})().catch((error) => {
  console.error(error);
  process.exitCode = 2;
});
