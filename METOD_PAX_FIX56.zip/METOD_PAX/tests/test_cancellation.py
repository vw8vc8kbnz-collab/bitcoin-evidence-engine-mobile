"""Exercise the real JavaScript cancellation API, including persisted recovery."""
import subprocess
import unittest
from server_fixture import ROOT


class CancellationClientTests(unittest.TestCase):
    def test_confirmation_transport_deadlines_and_recovery(self):
        run = subprocess.run(
            ['node', '--test', '--test-reporter=tap', str(ROOT / 'tests/cancellation-api.cjs')],
            cwd=ROOT, capture_output=True, text=True, timeout=30,
        )
        self.assertEqual(run.returncode, 0, run.stdout + run.stderr)
        self.assertIn('# tests 7', run.stdout)
        self.assertIn('# fail 0', run.stdout)

    def test_real_request_confirmation_and_idempotent_retry_keep_exact_identity(self):
        import json
        from server_fixture import TestServer

        with TestServer() as server:
            request_id = 'request_cancel_contract'
            token = 'synthetic-cancel-capability-only'
            status_file = server.state / 'requests' / request_id / 'status.json'
            status_file.parent.mkdir(parents=True)
            status_file.write_text(json.dumps({
                'requestId': request_id, 'publicStatus': 'SUBMITTED',
                'internalStatus': 'QUEUED', 'quoteStatus': 'TODO', 'needsQuote': True,
                'cancelControl': {'cancelToken': token},
            }))
            original = status_file.read_bytes()
            for invalid in ['', 'another-request-capability']:
                code, body, _ = server.request('POST', '/api/cancel', {
                    'requestId': request_id, 'cancelToken': invalid,
                }, auth=False)
                self.assertEqual(code, 403, body)
                self.assertEqual(status_file.read_bytes(), original)
            payload = {'requestId': request_id, 'cancelToken': token}
            code, body, _ = server.request('POST', '/api/cancel', payload, auth=False)
            self.assertEqual(code, 200, body)
            self.assertEqual(body, {'ok': True, 'requestId': request_id, 'cancelled': True, 'idempotent': False})
            stored = status_file.read_bytes()
            self.assertNotIn(token.encode(), stored)
            self.assertEqual(json.loads(stored)['publicStatus'], 'CANCELLED')
            code, body, _ = server.request('POST', '/api/cancel', payload, auth=False)
            self.assertEqual(code, 200, body)
            self.assertEqual(body, {'ok': True, 'requestId': request_id, 'cancelled': True, 'idempotent': True})
            self.assertEqual(status_file.read_bytes(), stored)
