"""Executable release, migration and startup boundaries, without touching a VPS."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import shutil
import stat
import sys
import tarfile
import tempfile
import unittest
import zipfile

from server_fixture import ROOT, TestServer

sys.path.insert(0, str(ROOT / "tools"))
from deployment_safety import baseline_digest
from migration_bundle_tool import create_manifest, extract_archive
from probe_http_release import probe
from verify_assets import verify_assets
from verify_standalone_artifact import safe_extract, snapshot_and_verify_artifact


class ReleaseToolingTests(unittest.TestCase):
    def test_source_asset_binding_and_tampering(self):
        self.assertEqual(verify_assets(ROOT)["status"], "PASS")
        with tempfile.TemporaryDirectory() as temporary:
            target = Path(temporary) / "release"
            shutil.copytree(ROOT / "app", target / "app")
            shutil.copy2(ROOT / "VERSION.json", target / "VERSION.json")
            (target / "app/tool-a/main.js").write_text("// changed\n")
            with self.assertRaises(ValueError):
                verify_assets(target)

    def test_real_http_release_probe(self):
        with TestServer(secure=True) as server:
            self.assertEqual(probe(ROOT, server.origin)["status"], "PASS")

    def test_zip_traversal_and_link_rejected_before_extraction(self):
        with tempfile.TemporaryDirectory() as temporary:
            work = Path(temporary)
            for number, (name, mode) in enumerate(
                [
                    ("METOD_PAX/../outside", stat.S_IFREG | 0o644),
                    ("METOD_PAX/link", stat.S_IFLNK | 0o777),
                    ("/METOD_PAX/file", stat.S_IFREG | 0o644),
                    ("METOD_PAX/.git/config", stat.S_IFREG | 0o644),
                ]
            ):
                archive = work / f"{number}.zip"
                info = zipfile.ZipInfo(name)
                info.external_attr = mode << 16
                with zipfile.ZipFile(archive, "w") as output:
                    output.writestr(info, b"payload")
                with self.assertRaises(RuntimeError):
                    safe_extract(archive, work / f"extracted-{number}", expected_root="METOD_PAX")
                self.assertFalse((work / "outside").exists())

    def test_archive_hash_is_required_and_snapshot_survives_input_replacement(self):
        with tempfile.TemporaryDirectory() as temporary:
            work = Path(temporary)
            source = work / "input.zip"
            source.write_bytes(b"exact release bytes")
            with self.assertRaises(RuntimeError):
                snapshot_and_verify_artifact(source, work / "bad.zip", expected_sha256="0" * 64)
            digest = hashlib.sha256(source.read_bytes()).hexdigest()
            target, actual, _ = snapshot_and_verify_artifact(
                source, work / "good.zip", expected_sha256=digest
            )
            source.write_bytes(b"replacement")
            self.assertEqual(actual, digest)
            self.assertEqual(target.read_bytes(), b"exact release bytes")

    def test_old_directory_prefix_still_requires_trusted_exact_digest(self):
        # /tmp and its parents are not a trusted deployment root. Patch only the
        # host trust check; the directory naming and digest binding stay real.
        from unittest.mock import patch

        with patch("deployment_safety.trusted_directory_chain"):
            releases = Path("/synthetic/releases")
            digest = "a" * 64
            old = releases / ("FIX660R8_PRELIVE_HARDENED_" + digest)
            current = json.loads((ROOT / "VERSION.json").read_text())["revision"]
            self.assertEqual(baseline_digest(old, releases, current, digest), digest)
            with self.assertRaises(ValueError):
                baseline_digest(old, releases, current, "b" * 64)
            with self.assertRaises(ValueError):
                baseline_digest(releases / ("UNKNOWN_" + digest), releases, current, digest)

    def test_migration_carries_current_privacy_journal_and_budget(self):
        with tempfile.TemporaryDirectory() as temporary:
            work = Path(temporary)
            source = work / "metod-pax-migration"
            for name in ("state", "config", "privacy"):
                (source / name).mkdir(parents=True)
            (source / "config/admin_credentials.live.json").write_text('{"users": []}')
            (source / "config/backup-budget.env").write_text("BACKUP_TOTAL_MAX_BYTES=6442450944\n")
            (source / "privacy/entry.json").write_text('{"synthetic": true}')
            create_manifest(source)
            archive = work / "migration.tar"
            with tarfile.open(archive, "w") as output:
                output.add(source, arcname=source.name)
            restored = extract_archive(archive, work / "restored")
            self.assertEqual(
                (restored / "privacy/entry.json").read_bytes(), (source / "privacy/entry.json").read_bytes()
            )
            self.assertEqual(
                (restored / "config/backup-budget.env").read_bytes(),
                (source / "config/backup-budget.env").read_bytes(),
            )

    def test_migration_refuses_missing_journal(self):
        with tempfile.TemporaryDirectory() as temporary:
            source = Path(temporary) / "metod-pax-migration"
            (source / "state").mkdir(parents=True)
            (source / "config").mkdir()
            (source / "config/admin_credentials.live.json").write_text("{}")
            with self.assertRaises(ValueError):
                create_manifest(source)
