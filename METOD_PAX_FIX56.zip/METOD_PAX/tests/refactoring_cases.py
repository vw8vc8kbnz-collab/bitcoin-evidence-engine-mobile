"""Stable adversarial/legacy inputs for behavioral equivalence with the FIX50 source baseline."""

from dataclasses import asdict
import random
from types import SimpleNamespace
from catalog_importer import classify_catalog_presentation
from metod_app.requests.projections import RequestProjection
from metod_app.optimizer.packing import _maxrects_pack_k


def packing_cases():
    rng = random.Random(651)
    cases = []
    for case in range(40):
        items = []
        for idx in range(2 + case % 13):
            w = rng.choice([80, 125, 350, 597, 797, 1197, 1797])
            h = rng.choice([97, 197, 397, 597, 797, 1197])
            group = idx % 7 == 0 and case % 3 == 0
            count = 2 if group else 1
            members = []
            for number in range(count):
                row = SimpleNamespace(
                    PartId=f"P{idx}_{number}",
                    WidthMm=w,
                    LengthMm=h,
                    MaterialCode="SYNTHETIC",
                    ThicknessMm=18,
                    H1=True,
                    H2=False,
                    W1=True,
                    W2=False,
                )
                members.append(SimpleNamespace(row=row, idx=1, w=w, h=h))
            total_h = count * h + (count - 1) * 13
            items.append(
                {
                    "kind": "group" if group else "single",
                    "members": members,
                    "w": w,
                    "h": total_h,
                    "area": w * total_h,
                    "mn": min(w, total_h),
                    "mx": max(w, total_h),
                    "micro_flag": int(max(w, total_h) < 400),
                    "rot_allowed": not group and case % 2 == 0,
                }
            )
        result = _maxrects_pack_k(items, 2070, 2800, 7, 13, 1 + case % 4, {"warnings": [], "errors": []})
        cases.append([asdict(x) for x in result] if result is not None else None)
    return cases


def projection_cases():
    projection = RequestProjection(
        best_material_name=lambda code, *names: next((str(x) for x in names if x), code)
    )
    catalog = []
    for brand in ("", "DecoLegno", "Unilin", "Shinnoki", "Nuxe"):
        for decor in (
            "U123 Quercia",
            "S076 Sherwood",
            "LK00 Matrix",
            "FD22 woven",
            "0H Oak",
            "MDF Grondeerfolie Wit",
            "Walnut bruin",
            "Stone beige marble",
            "Brushed gold",
            "Supermat black",
            "Linen grey",
            "Metal copper",
            "Grafisch purple",
            "Fineer Ash",
        ):
            catalog.append(classify_catalog_presentation(brand + " " + decor, brand, "MDF"))
    orders = []
    for i in range(80):
        payload = {
            "customer": {
                "firstName": "Test",
                "lastName": "Klant",
                "mail": "audit@example.invalid",
                "billingAddress": "Straat",
                "houseNumber": "12",
                "postcode": "1234 AB",
                "city": "Utrecht",
                "country": "Nederland",
            },
            "cart": [
                {"materialCode": "a", "name": "Eiken", "qty": str(i % 4 + 1)},
                {"articleNumber": "b", "decorName": "Wit", "quantity": "bad"},
            ],
        }
        if i % 3 == 0:
            payload["materialsSummary"] = [
                {"code": "a", "name": "Eiken", "plates": i % 5},
                {"materialCode": "b", "plates": "bad"},
            ]
        if i % 2:
            payload["quote"] = {
                "totals": {"total": i * 7.12, "sheetsUsed": i % 8},
                "materials": [{"materialCode": "a", "name": "Fineer", "sheets": 2, "price": 12.5}],
            }
        if i % 5 == 0:
            payload.update(priceInclVat=i * 9.67, platesTotal=i % 7, materialsPrice="25.50")
        if i % 7 == 0:
            payload["totalPriceInclVat"] = "bad"
        orders.append(projection.extract_summary(payload))
    return {"catalog": catalog, "orders": orders}
