#!/usr/bin/env python3
"""Real HTTP API boundary coverage and Admin-to-calculation persistence proofs."""

from __future__ import annotations
import base64
import copy
import json
import os
from pathlib import Path
import re
import sys
import time
import unittest
import uuid
from urllib.parse import quote

ROOT = __import__("server_fixture").ROOT
sys.path[:0] = [str(ROOT / "tools"), str(ROOT / "app")]
from server_fixture import TestServer, panel_dxf
from server_fixture import TEST_PUBLIC_ID, preview_csv_text
from metod_app.http.routes import ROUTES

CUSTOMER = {
    "firstName": "API",
    "lastName": "Test",
    "email": "audit@example.invalid",
    "phone": "0612345678",
    "billingAddress": "Teststraat",
    "houseNumber": "1",
    "postcode": "1234AB",
    "shippingSameAsBilling": True,
    "city": "Teststad",
    "country": "Nederland",
}


def job_payload():
    return {
        "panelsCsv": f"PartId;PanelName;Qty;LengthMm;WidthMm;ThicknessMm;MaterialCode;GrainGroup;RotationAllowed;H1;H2;W1;W2\nP1;Test panel;1;200;100;18;{TEST_PUBLIC_ID};;false;1;1;1;1\n",
        "dxfParts": {"P1": panel_dxf(100, 200).decode()},
        "jobJson": {"customer": CUSTOMER, "note": "Synthetic API test"},
    }


class AdminApiTests(unittest.TestCase):
    def setUp(self):
        self.s = TestServer().start()
        self.addCleanup(self.s.close)

    def ok(self, method, path, body=None, expected=200, **options):
        code, result, headers = self.s.request(method, path, body, **options)
        self.assertEqual(code, expected, (path, code, result))
        return result, headers

    def calculate(self):
        body, _ = self.ok(
            "POST",
            "/api/jobs",
            job_payload(),
            expected=202,
            auth=False,
            headers={"Idempotency-Key": uuid.uuid4().hex * 2},
        )
        job, token = body["jobId"], body["accessToken"]
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline:
            status, _ = self.ok(
                "GET", f"/api/jobs/{job}/status", auth=False, headers={"Authorization": "Bearer " + token}
            )
            phase = str(status.get("meta", {}).get("status", "")).lower()
            if phase in {"done", "error", "failed", "cancelled"}:
                break
            time.sleep(0.05)
        self.assertEqual(phase, "done", status)
        return job, token, status

    def test_01_every_api_route_authentication_and_origin_boundary(self):
        routes = [r for r in ROUTES if r.pattern.startswith("/api/")]
        self.assertGreaterEqual(len(routes), 57)
        report = []
        for route in routes:
            with self.subTest(route=route.key):
                path = re.sub(r"\{[^}]+\}", "MISSING", route.pattern)
                code, body, _ = self.s.request(
                    route.method, path, {} if route.method == "POST" else None, auth=False
                )
                if route.access_policy == "admin-session":
                    self.assertEqual(code, 403 if path.startswith("/api/jobs/") else 401, (path, body))
                else:
                    self.assertIn(code, {200, 400, 401, 403, 404, 410}, (path, body))
                entry = {
                    "method": route.method,
                    "path": route.pattern,
                    "anonymousStatus": code,
                    "accessPolicy": route.access_policy,
                }
                if route.origin_policy == "exact-admin-origin":
                    code, body, _ = self.s.request(
                        route.method, path, {}, headers={"Origin": "https://wrong-origin.invalid"}
                    )
                    self.assertEqual(code, 403, (path, body))
                    entry["wrongOriginStatus"] = code
                report.append(entry)
        path = os.environ.get("METOD_API_REPORT")
        if path:
            Path(path).write_text(json.dumps(report, indent=2) + "\n")
        print(f"API boundary coverage: {len(routes)}/{len(routes)} routes")

    def test_02_dxf_hash_filename_full_lifecycle_and_restart(self):
        category = "Test categorie"
        body, _ = self.ok("POST", "/api/admin/dxf/create_category", {"category": "  " + category + "  "})
        self.assertEqual(body["category"], category)
        name = "#SHEET_002 (test).dxf"
        source = panel_dxf()
        payload = {"category": category, "filename": name, "dataBase64": base64.b64encode(source).decode()}
        result, _ = self.ok("POST", "/api/admin/dxf/upload", payload)
        self.assertEqual(result["filename"], name)
        self.assertTrue(result["dxfVersion"])
        result, _ = self.ok("GET", "/api/admin/dxf/list?category=" + quote(category))
        self.assertEqual(result["files"], [name])
        relative = category + "/" + name
        result, _ = self.ok("GET", "/embedded_dxfs_manifest.json", auth=False)
        self.assertIn(relative, result["files"])
        actual, _ = self.ok("GET", "/embedded_dxfs/" + quote(relative, safe=""), auth=False)
        self.assertEqual(actual, source)
        replacement = panel_dxf(500, 300)
        self.ok(
            "POST", "/api/admin/dxf/upload", dict(payload, dataBase64=base64.b64encode(replacement).decode())
        )
        self.s.stop()
        self.s.start()
        actual, _ = self.ok("GET", "/embedded_dxfs/" + quote(relative, safe=""), auth=False)
        self.assertEqual(actual, replacement)
        self.ok("POST", "/api/admin/dxf/delete", {"category": category, "filename": name})
        result, _ = self.ok("GET", "/embedded_dxfs_manifest.json", auth=False)
        self.assertNotIn(relative, result["files"])
        self.ok("GET", "/embedded_dxfs/" + quote(relative, safe=""), expected=404, auth=False)

    def test_03_dxf_invalid_inputs_leave_no_file_and_return_specific_errors(self):
        self.ok("POST", "/api/admin/dxf/create_category", {"category": "test"})
        payload = {
            "category": "test",
            "filename": "valid.dxf",
            "dataBase64": base64.b64encode(panel_dxf()).decode(),
        }
        cases = [
            (dict(payload, filename=name), "DXF_INVALID_FILENAME")
            for name in [
                "../secret.dxf",
                "a/b.dxf",
                "a\\b.dxf",
                ".hidden.dxf",
                "a..b.dxf",
                "x" * 81 + ".dxf",
                "a.txt",
                "a\x00.dxf",
            ]
        ]
        cases += [
            (dict(payload, category="../bad"), "DXF_INVALID_CATEGORY"),
            (dict(payload, dataBase64=""), "DXF_MISSING_CONTENT"),
            ([], "INVALID_JSON_BODY"),
            ("bad", "INVALID_JSON_BODY"),
        ]
        cases += [
            (dict(payload, dataBase64=base64.b64encode(data).decode()), "DXF_INVALID_GEOMETRY")
            for data in [
                b"not a DXF",
                panel_dxf().replace(b"OUTLINE", b"OTHER"),
                panel_dxf().replace(b"600", b"NaN"),
                panel_dxf(11000, 100),
            ]
        ]
        for body, error_code in cases:
            with self.subTest(body=str(body)[:95]):
                result, _ = self.ok("POST", "/api/admin/dxf/upload", body, expected=400)
                self.assertEqual(result["code"], error_code)
        self.ok("POST", "/api/admin/dxf/upload", dict(payload, dataBase64="%%%"), expected=400)
        self.ok("POST", "/api/admin/dxf/upload", dict(payload, category="Missing"), expected=404)
        result, _ = self.ok("GET", "/api/admin/dxf/list?category=test")
        self.assertEqual(result["files"], [])
        for endpoint in ["create_category", "delete"]:
            self.ok("POST", "/api/admin/dxf/" + endpoint, ["bad"], expected=400)

    def test_04_prices_saved_then_used_by_new_jobs_without_changing_old_quotes(self):
        original, headers = self.ok("GET", "/api/admin/pricing")
        self.assertIn("no-store", headers["Cache-Control"])
        old_job, old_token, old_status = self.calculate()
        old_files = {p: p.read_bytes() for p in (self.s.state / "jobs" / old_job).rglob("*") if p.is_file()}
        changed = copy.deepcopy(original)
        changed["pricing"]["defaults"].update(sheetMarginMm=11, nestingGapMm=8, kerfMm=3)
        changed["pricing"]["defaults"]["rounding"].update(moneyDecimals=2, metersDecimals=3)
        changed["sellPricing"].update(
            edgeBandPricePerM=6.25, cncCostPerSheet=95, drawingCostFixed=150, transportCostFixed=65
        )
        editor, _ = self.ok("GET", "/api/admin/pricing?view=editor")
        self.assertEqual(editor["config"], original)
        saved, _ = self.ok("POST", "/api/admin/pricing", {"config": changed, "revision": editor["revision"]})
        current, current_headers = self.ok("GET", "/api/admin/pricing")
        self.assertEqual(current, changed)
        self.assertEqual(current_headers["ETag"], saved["revision"])
        self.assertNotEqual(saved["revision"], headers["ETag"])
        conflict, _ = self.ok(
            "POST", "/api/admin/pricing", original, expected=409, headers={"If-Match": headers["ETag"]}
        )
        self.assertEqual(conflict["code"], "PRICING_REVISION_CONFLICT")
        job, token, status = self.calculate()
        snapshots = list((self.s.state / "jobs").glob(job + "*/input/pricing.json"))
        self.assertTrue(snapshots)
        for path in snapshots:
            snapshot = json.loads(path.read_text())
            self.assertEqual(snapshot["defaults"], changed["pricing"]["defaults"])
            self.assertEqual(snapshot["sellPricing"], changed["sellPricing"])
        job_json = json.loads((self.s.state / "jobs" / job / "input/job.json").read_text())
        for key in ["sheetMarginMm", "nestingGapMm", "kerfMm"]:
            self.assertEqual(job_json[key], changed["pricing"]["defaults"][key])
        new_quotes = [
            json.loads(p.read_text()) for p in (self.s.state / "jobs").glob(job + "*/output/quote.json")
        ]
        self.assertTrue(new_quotes)
        self.assertEqual(status["pricingSummary"]["totalInclVat"], 520.11)
        self.assertEqual(status["pricingSummary"]["cncTotal"], 95)
        self.assertEqual(status["pricingSummary"]["drawingTotal"], 150)
        self.assertEqual(status["pricingSummary"]["transportTotal"], 65)
        self.assertEqual(status["pricingSummary"]["edgeBandTotal"], 3.94)
        self.assertEqual(old_status["pricingSummary"]["totalInclVat"], 464.27)
        self.assertEqual(old_files, {p: p.read_bytes() for p in old_files})
        self.s.stop()
        self.s.start()
        current, _ = self.ok("GET", "/api/admin/pricing")
        self.assertEqual(current, changed)
        self.assertEqual(old_files, {p: p.read_bytes() for p in old_files})
        self.assertTrue((self.s.state / "config/pricing_versions" / saved["version"]).is_file())
        signoff = json.loads((self.s.state / "system/catalog_signoff.json").read_text())
        self.assertFalse(signoff["approved"])

    def test_05_invalid_pricing_rejected_without_replacing_saved_configuration(self):
        config, headers = self.ok("GET", "/api/admin/pricing")
        path = self.s.state / "config/pricing_active.json"
        before = path.read_bytes()
        for key, value in [("sheetMarginMm", -1), ("kerfMm", 101), ("nestingGapMm", "12oops")]:
            bad = copy.deepcopy(config)
            bad["pricing"]["defaults"][key] = value
            self.ok("POST", "/api/admin/pricing", bad, expected=400)
            self.assertEqual(path.read_bytes(), before)
        for value in [0, -1, "10", True]:
            bad = copy.deepcopy(config)
            bad["sellPricing"]["cncCostPerSheet"] = value
            self.ok("POST", "/api/admin/pricing", bad, expected=400)
            self.assertEqual(path.read_bytes(), before)
        for value in [1.5, 7]:
            bad = copy.deepcopy(config)
            bad["pricing"]["defaults"]["rounding"]["moneyDecimals"] = value
            self.ok("POST", "/api/admin/pricing", bad, expected=400)
            self.assertEqual(path.read_bytes(), before)

    def test_06_catalog_publish_taxonomy_and_price_refresh_reach_public_api(self):
        before, headers = self.ok("GET", "/api/materials/library", auth=False)
        preview, _ = self.ok(
            "POST",
            "/api/admin/materials/catalog_preview",
            {"csvText": preview_csv_text().replace("140,24", "222,22")},
        )
        import_id = preview["importId"]
        stage, _ = self.ok("GET", "/api/admin/materials/catalog_status?importId=" + quote(import_id))
        self.ok(
            "POST",
            "/api/admin/materials/catalog_publish",
            {"importId": import_id, "reviewSha256": preview["reviewSha256"]},
        )
        after, new_headers = self.ok(
            "GET", "/api/materials/library", auth=False, headers={"If-None-Match": headers["ETag"]}
        )
        self.assertNotEqual(headers["ETag"], new_headers["ETag"])
        self.assertNotEqual(before, after)
        self.assertNotIn(
            "sellPriceInclVatPerSheet", after["records"][0]
        )  # public catalog intentionally carries no pricing
        self.ok(
            "POST",
            "/api/admin/materials/live_taxonomy_family",
            {"publicMaterialId": TEST_PUBLIC_ID, "primaryVisualFamily": "Hout"},
        )
        after, _ = self.ok("GET", "/api/materials/library", auth=False)
        self.assertEqual(after["records"][0]["primaryVisualFamily"], "Hout")
        job, token, status = self.calculate()
        snapshot = json.loads((self.s.state / "jobs" / job / "input/pricing.json").read_text())
        self.assertEqual(snapshot["materials"][0]["sellPriceInclVatPerSheet"], 222.22)
        self.s.stop()
        self.s.start()
        after, _ = self.ok("GET", "/api/materials/library", auth=False)
        self.assertEqual(after["records"][0]["primaryVisualFamily"], "Hout")
        self.assertNotIn(
            "sellPriceInclVatPerSheet", after["records"][0]
        )  # public catalog intentionally carries no pricing

    def test_07_admin_read_routes_and_retired_writes(self):
        for path in [
            "control_center",
            "dxf/categories",
            "health/ready",
            "jobs",
            "materials/library",
            "metrics",
            "pricing",
            "requests",
            "system/backups",
            "system/logs",
        ]:
            self.ok("GET", "/api/admin/" + path)
        for endpoint in ["delete_item", "image_delete", "image_upload", "save_item", "upload"]:
            result, _ = self.ok("POST", "/api/admin/materials/" + endpoint, {}, expected=410)
            self.assertFalse(result["ok"])
        for path in [
            "materials/catalog_status",
            "request_download_zip",
            "request_file",
            "request_files",
            "requests/update",
        ]:
            code, body, _ = self.s.request("GET", "/api/admin/" + path)
            self.assertIn(
                code, ({200} if path == "materials/catalog_status" else {400, 404, 405}), (path, body)
            )
        self.ok("POST", "/api/admin/logout", {})
        self.ok("GET", "/api/admin/pricing", expected=401)

    def test_09_malformed_admin_json_is_an_http_error_not_a_disconnected_socket(self):
        for route in ROUTES:
            if (
                route.method != "POST"
                or not route.pattern.startswith("/api/admin/")
                or route.body.consumption != "bounded-json"
            ):
                continue
            for body in [b"[]", b"{broken", b'{"invalid":NaN}']:
                with self.subTest(route=route.key, body=body):
                    code, result, _ = self.s.request("POST", route.pattern, raw=body)
                    self.assertIn(code, {400, 401, 404, 410, 413}, (route.key, result))
        payload = b"{" + b" " * 262145
        self.ok("POST", "/api/admin/dxf/create_category", expected=413, raw=payload)

    def test_10_request_status_files_backup_and_admin_job_projection(self):
        job, token, status = self.calculate()
        submitted, _ = self.ok(
            "POST",
            "/api/submit_config",
            {"parentJobId": job, "customer": CUSTOMER, "note": "Synthetic API test"},
            auth=False,
            headers={"Authorization": "Bearer " + token},
        )
        rid = submitted["requestId"]
        self.ok("POST", "/api/admin/requests/update", {"requestId": rid, "action": "mark_quote_sent"})
        result, _ = self.ok("GET", "/api/admin/requests?requestId=" + quote(rid))
        self.assertIn(rid, json.dumps(result))
        stored = json.loads((self.s.state / "requests" / rid / "status.json").read_text())
        self.assertEqual(stored["quoteStatus"], "DONE")
        self.ok("POST", "/api/admin/requests/update", {"requestId": rid, "action": "reopen"})
        self.assertEqual(
            json.loads((self.s.state / "requests" / rid / "status.json").read_text())["quoteStatus"], "TODO"
        )
        self.ok("GET", "/api/admin/request_files?requestId=" + quote(rid))
        backup, _ = self.ok("POST", "/api/admin/system/backup_now", {})
        listing, _ = self.ok("GET", "/api/admin/system/backups")
        self.assertTrue(listing["items"])
        self.s.stop()
        self.s.start()
        self.assertEqual(
            json.loads((self.s.state / "requests" / rid / "status.json").read_text())["quoteStatus"], "TODO"
        )

    def test_10_multiple_materials_retry_and_job_token_isolation(self):
        self.s.stop()
        path = self.s.state / "material_library.json"
        catalog = json.loads(path.read_text())
        second_id = "decor_abcdef0123456789abcd"
        second = copy.deepcopy(catalog["records"][0])
        second.update(
            publicMaterialId=second_id,
            articleNo="HTTP-SMOKE-002",
            materialCode="HTTP-SMOKE-002",
            sellPriceInclVatPerSheet=300.0,
            productName="Second synthetic decor",
            publicName="Second synthetic decor",
        )
        catalog["records"].append(second)
        path.write_text(json.dumps(catalog))
        self.s.start()
        payload = job_payload()
        payload["panelsCsv"] += f"P2;Second panel;1;200;100;18;{second_id};;false;1;1;1;1\n"
        payload["dxfParts"]["P2"] = panel_dxf(100, 200).decode()
        key = uuid.uuid4().hex * 2
        created, _ = self.ok(
            "POST", "/api/jobs", payload, expected=202, auth=False, headers={"Idempotency-Key": key}
        )
        repeated, _ = self.ok(
            "POST", "/api/jobs", payload, expected=202, auth=False, headers={"Idempotency-Key": key}
        )
        self.assertEqual(repeated["jobId"], created["jobId"])
        job, token = created["jobId"], created["accessToken"]
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline:
            status, _ = self.ok(
                "GET", f"/api/jobs/{job}/status", auth=False, headers={"Authorization": "Bearer " + token}
            )
            phase = status.get("meta", {}).get("status", "").lower()
            if phase in {"done", "failed", "error", "cancelled"}:
                break
            time.sleep(0.05)
        self.assertEqual(phase, "done", status)
        summary = status["pricingSummary"]
        self.assertEqual(summary["totalInclVat"], 870.54)
        self.assertEqual(summary["cncTotal"], 170)
        self.assertEqual(summary["drawingTotal"], 125)
        self.assertEqual(summary["transportTotal"], 54.95)
        self.assertEqual(len(list((self.s.state / "jobs").glob(job + "__mat_*"))), 2)
        other_job, _, _ = self.calculate()
        self.ok(
            "GET",
            f"/api/jobs/{other_job}/status",
            expected=403,
            auth=False,
            headers={"Authorization": "Bearer " + token},
        )
        self.ok(
            "GET",
            f"/api/jobs/{job}/file/input/job.json",
            expected=403,
            auth=False,
            headers={"Authorization": "Bearer " + token},
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
