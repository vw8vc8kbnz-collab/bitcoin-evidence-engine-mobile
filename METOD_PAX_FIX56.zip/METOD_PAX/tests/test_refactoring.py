"""Refactoring gates: production placements, display compatibility and safe cleanup."""

import hashlib
import json
from pathlib import Path
import re
import sys
import tempfile
import threading
from datetime import datetime, timedelta
from types import SimpleNamespace
import unittest

from server_fixture import ROOT

sys.path.insert(0, str(ROOT / "app"))
from refactoring_cases import packing_cases, projection_cases
from metod_app.jobs.sticker_projection import project_items, rotation_0_90
from metod_app.storage.operational_cleanup import OperationalCleanup


class RefactoringTests(unittest.TestCase):
    # Recorded from immutable FIX50 commit 5d73720da6e37080668d0636e2d2da43f54076bb.
    # The hash covers full placement coordinates/rotations/IDs, not a success counter.
    def test_packing_preserves_40_baseline_layouts_including_grain_groups(self):
        data = json.dumps(packing_cases(), sort_keys=True, separators=(",", ":")).encode()
        self.assertEqual(
            hashlib.sha256(data).hexdigest(),
            "05ee71546d906a4fb7c83f0ae620d8d39b554e57e9476888063cb2709c66a61c",
        )

    def test_catalog_70_cases_and_order_80_cases_preserve_baseline_results(self):
        data = json.dumps(projection_cases(), sort_keys=True, separators=(",", ":")).encode()
        self.assertEqual(
            hashlib.sha256(data).hexdigest(),
            "e90624f6277fa4aaa1843d8bb0ffd5dde0b5971ce29c1a8140a5d44cc385e7c7",
        )

    def test_sticker_origin_rotation_edges_labels_and_duplicate_ids(self):
        placement = {
            "partId": "P1",
            "instanceIndex": 0,
            "part_mm": {"width_mm": 400, "length_mm": 800},
            "bbox_mm": {"w_mm": 800, "h_mm": 400},
            "rotation_deg": 270,
            "x_mm": 7,
            "y_mm": 13,
            "edges": {"H1": True, "W2": True},
        }
        items = project_items(
            [placement, placement], [{"PartId": "P1", "PanelName": "Deur 60/80? #1 €"}], 18, 2800
        )
        self.assertEqual([i["partId"] for i in items], ["P1__0", "P1__0__2"])
        self.assertEqual(
            items[0]["placement"], {"sheetId": "S01", "bbox": [7, 2387, 807, 2787], "rotation": 90}
        )
        self.assertEqual(items[0]["edgeBanding"], {"top": True, "right": True})
        self.assertEqual(items[0]["displayName"], "Deur 60/80? #1 €")
        self.assertEqual(items[0]["grain"], "vertical")
        with self.assertRaises(ValueError):
            rotation_0_90(45)


class CleanupTests(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        self.now = datetime(2026, 9, 27)
        names = (
            "catalog_import_history",
            "catalog_import_root",
            "decor_media_root",
            "drafts",
            "jobs",
            "queue_done",
            "queue_failed",
            "requests",
            "submission_idempotency_dir",
            "system_dir",
        )
        paths = {name: self.root / name for name in names}
        for path in paths.values():
            path.mkdir()
        paths.update(
            state_root=self.root,
            material_library_path=self.root / "catalog.json",
            system_log_file=self.root / "system.log",
        )
        attrs = {"get_" + name: (lambda value=path: value) for name, path in paths.items()}
        attrs.update(
            get_catalog_image_sync_active=lambda: {"cat_" + "c" * 24},
            get_catalog_image_sync_lock=lambda: threading.RLock(),
            get_public_material_id_re=lambda: re.compile(r"decor_[a-f0-9]{20}"),
            get_orphan_job_retention_days=lambda: 30,
            ensure_request_dirs=lambda: None,
            ensure_system_dirs=lambda: None,
            cleanup_public_job_idempotency=lambda **kwargs: {"removed": 0, "errors": []},
            path_dt=lambda path: self.now - timedelta(days=200),
        )
        self.paths = paths
        self.ports = SimpleNamespace(**attrs)
        paths["material_library_path"].write_text(
            json.dumps(
                {
                    "lastCatalogImport": {"importId": "cat_" + "a" * 24},
                    "records": [{"publicMaterialId": "decor_" + "a" * 20}],
                }
            )
        )

    def test_retention_keeps_current_and_syncing_catalog_and_linked_orders(self):
        for letter in "abc":
            (self.paths["catalog_import_root"] / ("cat_" + letter * 24 + ".json")).write_text("{}")
        for letter in "ab":
            (self.paths["decor_media_root"] / ("decor_" + letter * 20)).mkdir()
        (self.paths["requests"] / "keep").mkdir()
        (self.paths["requests"] / "keep/status.json").write_text("{}")
        for folder in ("queue_done", "submission_idempotency_dir"):
            for request in ("keep", "orphan"):
                (self.paths[folder] / (request + ".json")).write_text(json.dumps({"requestId": request}))
        result = OperationalCleanup(self.ports, self.now).run()
        self.assertEqual(result["errors"], [])
        self.assertEqual(result["catalogStages"], 1)
        self.assertEqual(result["orphanDecorMedia"], 1)
        self.assertTrue((self.paths["catalog_import_root"] / ("cat_" + "a" * 24 + ".json")).exists())
        self.assertTrue((self.paths["catalog_import_root"] / ("cat_" + "c" * 24 + ".json")).exists())
        self.assertTrue((self.paths["decor_media_root"] / ("decor_" + "a" * 20)).exists())
        for folder in ("queue_done", "submission_idempotency_dir"):
            self.assertTrue((self.paths[folder] / "keep.json").exists())
            self.assertFalse((self.paths[folder] / "orphan.json").exists())

    def test_unreadable_catalog_retains_stages_and_media(self):
        self.paths["material_library_path"].write_text("[]")
        stage = self.paths["catalog_import_root"] / ("cat_" + "b" * 24 + ".json")
        stage.write_text("{}")
        media = self.paths["decor_media_root"] / ("decor_" + "b" * 20)
        media.mkdir()
        result = OperationalCleanup(self.ports, self.now).run()
        self.assertTrue(result["errors"])
        self.assertTrue(stage.exists())
        self.assertTrue(media.exists())
