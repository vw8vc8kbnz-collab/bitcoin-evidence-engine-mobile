"""Personal-data erasure survives crashes and restores of older backups."""

import json
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
import zipfile

from server_fixture import ROOT

sys.path.insert(0, str(ROOT / "app"))
from metod_app.admin.privacy import CustomerPrivacyService, PrivacyConflict


class PrivacyTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name) / "state"
        self.root.mkdir()
        self.ledger = self.root.with_name("privacy")
        self.service = CustomerPrivacyService(self.root, ledger=self.ledger)
        self.family("one", "one@example.test")
        self.family("two", "two@example.test")

    def put(self, relative, data):
        path = self.root / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data))

    def family(self, name, email):
        self.put(f"requests/{name}/status.json", {"customer": {"email": email}, "jobId": "job_" + name})
        self.put(
            f"jobs/job_{name}/input/job.json",
            {"customer": {"email": email}, "job": {"subjobs": ["job_" + name + "__mat_001"]}},
        )
        self.put(f"jobs/job_{name}__mat_001/input/job.json", {"job": {"parentJobId": "job_" + name}})
        self.put(f"jobs/job_{name}__mat_001/output/labels.json", {"name": "Synthetic customer"})
        self.put(f"queue/pending/{name}.json", {"requestId": name, "jobId": "job_" + name})
        self.put(f"system/job_create_idempotency/aa/{name}.json", {"jobId": "job_" + name})

    def test_export_and_delete_complete_family_without_touching_other_customer(self):
        inventory = self.service.inventory("ONE@example.test")
        with self.service.export_internal(inventory) as handle, zipfile.ZipFile(handle) as export:
            names = export.namelist()
            self.assertTrue(any("labels.json" in name for name in names))
            self.assertFalse(any("/two/" in name for name in names))
        self.service.erase(inventory, "test-admin")
        self.assertFalse((self.root / "jobs/job_one__mat_001").exists())
        self.assertFalse((self.root / "system/job_create_idempotency/aa/one.json").exists())
        self.assertTrue((self.root / "requests/two/status.json").exists())
        self.assertEqual(self.service.inventory("one@example.test")["fileCount"], 0)

    def test_old_active_backup_is_erased_even_if_journal_captured_archive_paths(self):
        old = self.root.with_name("old")
        shutil.copytree(self.root, old)
        for kind in ("jobs", "requests"):
            for source in list((self.root / kind).iterdir()):
                if "one" in source.name:
                    dest = self.root / "archive" / kind / source.name
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    shutil.move(source, dest)
        self.service.erase(self.service.inventory("one@example.test"), "test-admin")
        restored = CustomerPrivacyService(old, ledger=self.ledger)
        restored.replay()
        self.assertFalse((old / "requests/one").exists())
        self.assertFalse((old / "jobs/job_one__mat_001").exists())
        self.assertTrue((old / "requests/two").exists())

    def test_mixed_customer_family_is_refused(self):
        self.put(
            "jobs/job_one__mat_001/input/job.json",
            {"parentJobId": "job_one", "customer": {"email": "two@example.test"}},
        )
        with self.assertRaises(PrivacyConflict):
            self.service.inventory("one@example.test")

    def test_changed_file_changes_preview_revision(self):
        before = self.service.inventory("one@example.test")["revision"]
        self.put("jobs/job_one__mat_001/output/labels.json", {"name": "Changed synthetic label"})
        self.assertNotEqual(before, self.service.inventory("one@example.test")["revision"])

    def test_symlink_and_traversal_never_escape(self):
        external = self.root.with_name("external")
        external.mkdir()
        (self.root / "requests/linked").symlink_to(external, target_is_directory=True)
        with self.assertRaises(ValueError):
            self.service.inventory("one@example.test")
        with self.assertRaises(ValueError):
            self.service.apply({"schemaVersion": 1, "paths": ["../external"], "identifiers": []})
        self.assertTrue(external.exists())

    def test_replay_finishes_erasure_after_crash(self):
        inventory = self.service.inventory("one@example.test")
        from unittest.mock import patch

        with patch.object(self.service, "apply", side_effect=OSError("crash")):
            with self.assertRaises(OSError):
                self.service.erase(inventory, "test-admin")
        self.assertTrue((self.root / "requests/one").exists())
        self.service.replay()
        self.assertFalse((self.root / "requests/one").exists())

    def test_restore_is_blocked_until_explicit_current_journal_replay(self):
        self.put("system/restore_requires_privacy_replay.json", {"schemaVersion": 1})
        self.ledger.mkdir()
        with self.assertRaises(ValueError):
            self.service.replay()
        self.service.replay(restored_with_current_ledger=True)
        self.assertFalse((self.root / "system/restore_requires_privacy_replay.json").exists())

    def test_ledger_cannot_be_inside_restorable_state(self):
        with self.assertRaises(ValueError):
            CustomerPrivacyService(self.root, ledger=self.root / "privacy")
