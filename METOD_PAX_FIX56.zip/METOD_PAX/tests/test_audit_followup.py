"""Reproduce the FIX51 audit's input, operator-diagnostic and export findings."""

import csv
from datetime import timezone
import io
import json
import subprocess
import sys
import time
import unittest
from unittest.mock import patch
import uuid
import zipfile

from server_fixture import ROOT, TestServer, TEST_PUBLIC_ID, panel_dxf

sys.path.insert(0, str(ROOT / "app"))
from panel_contract import REQUIRED_COLUMNS, canonical_csv, parse_panels_csv
from safety_contracts import ContractError
from metod_app.admin import customer_export_presentation as presentation
from metod_app.config import RuntimeConfig


def panel_csv(name, *, delimiter=";"):
    output = io.StringIO(newline="")
    writer = csv.writer(output, delimiter=delimiter, lineterminator="\n")
    writer.writerow(REQUIRED_COLUMNS)
    writer.writerow(["P1", name, 1, 200, 100, 18, TEST_PUBLIC_ID, "", "false", 1, 1, 1, 1])
    return output.getvalue()


class PanelNameTests(unittest.TestCase):
    def test_formula_prefixes_and_invisible_variants_are_rejected_before_csv_output(self):
        for delimiter in (";", ","):
            for name in (
                '=HYPERLINK("https://example.invalid")',
                "+1+2",
                "-1+2",
                "@SUM(1)",
                " \t=1",
                "\ufeff\t=1",
                "\u200b @SUM(1)",
                "\u202e-1",
                "＝1",
                "＋1",
                "＠SUM(1)",
                "\r=1",
                "Panel\nname",
                "\x7f=1",
                "\x00=1",
            ):
                with self.subTest(name=name, delimiter=delimiter), self.assertRaises(ContractError):
                    parse_panels_csv(panel_csv(name, delimiter=delimiter))

    def test_existing_template_names_unicode_and_embedded_punctuation_roundtrip(self):
        for name in (
            "Deuren METOD/Metod deur 20x80",
            "Ladefront METOD/Metod lade 40x40",
            "Één paneel – België",
            "Paneel A + B",
            "Paneel A - B",
            "Paneel 1 @ zijde B",
            "Paneel = test",
            "Paneel 'links' (2)",
            "A" * 240,
        ):
            with self.subTest(name=name):
                rows = parse_panels_csv(panel_csv(name))
                self.assertEqual(rows[0].PanelName, name)
                self.assertEqual(parse_panels_csv(canonical_csv(rows)), rows)
        self.assertEqual(parse_panels_csv(panel_csv("  Deur\t A  "))[0].PanelName, "Deur A")

    def test_public_api_refuses_formula_names_without_creating_jobs_and_accepts_normal_name(self):
        with TestServer() as server:

            def job_directories():
                # Rejected input may create a diagnostic log, never an accepted job.
                return sorted(path for path in server.state.glob("jobs/*") if path.name != "_crash_logs")

            initial_jobs = job_directories()
            payload = {
                "dxfParts": {"P1": panel_dxf(100, 200).decode()},
                "jobJson": {"note": "Synthetic panel-name regression"},
            }
            for name in ('=HYPERLINK("https://example.invalid")', "+1", "-1", "@SUM(1)", "\t=1", "\ufeff=1"):
                with self.subTest(name=name):
                    code, body, _ = server.request(
                        "POST",
                        "/api/jobs",
                        {**payload, "panelsCsv": panel_csv(name)},
                        auth=False,
                        headers={"Idempotency-Key": uuid.uuid4().hex * 2},
                    )
                    self.assertEqual(code, 400, body)
                    self.assertEqual(body["code"], "INVALID_CONFIGURATION")
                    self.assertEqual(job_directories(), initial_jobs)
            code, body, _ = server.request(
                "POST",
                "/api/jobs",
                {**payload, "panelsCsv": panel_csv("Deuren METOD/Metod deur 20x80")},
                auth=False,
                headers={"Idempotency-Key": uuid.uuid4().hex * 2},
            )
            self.assertEqual(code, 202, body)
            deadline = time.monotonic() + 15
            while time.monotonic() < deadline:
                status, result, _ = server.request(
                    "GET",
                    f"/api/jobs/{body['jobId']}/status",
                    auth=False,
                    headers={"Authorization": "Bearer " + body["accessToken"]},
                )
                self.assertEqual(status, 200)
                if result.get("meta", {}).get("status", "").lower() in {"done", "error", "failed"}:
                    break
                time.sleep(0.05)
            self.assertEqual(result["meta"]["status"].lower(), "done", result)
            saved = server.state / "jobs" / body["jobId"] / "input/panels.csv"
            self.assertIn("Deuren METOD/Metod deur 20x80", saved.read_text())

    def test_browser_panel_sanitizer_covers_minus_without_changing_customer_names(self):
        module = (ROOT / "app/tool-a/domain/validators.js").as_uri()
        script = """
          import assert from 'node:assert/strict';
          const {mount} = await import(MODULE);
          mount();
          const {ToolAValidators: v} = await import(MODULE);
          for (const field of ['customLabelInput', 'extraName']) {
            const kind = v.getFieldRule(field).kind;
            for (const value of ['=1', '+1', '-1', '@SUM(1)', '\\t-1', '\\ufeff-1']) {
              assert.ok(!/^[=+@-]/u.test(v.sanitizeValue(value, kind)));
            }
            assert.equal(v.sanitizeValue('Één deur - links', kind), 'Één deur - links');
          }
          assert.equal(v.sanitizeValue('- Naam', 'text'), '- Naam');
        """.replace("MODULE", json.dumps(module))
        result = subprocess.run(["node", "--input-type=module", "-e", script], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)


class StartupDiagnosticTests(unittest.TestCase):
    def test_config_accepts_only_the_supported_backend_host(self):
        for environment in ({}, {"METOD_HOST": "127.0.0.1"}, {"METOD_HOST": " 127.0.0.1 "}):
            self.assertEqual(RuntimeConfig.from_environment(environment).host, "127.0.0.1")
        for host in ("0.0.0.0", "::", "::1", "localhost", "192.0.2.1", "", "127.0.0.2"):
            with self.subTest(host=host), self.assertRaisesRegex(ValueError, "METOD_HOST moet 127.0.0.1"):
                RuntimeConfig.from_environment({"METOD_HOST": host})

    def test_wrong_host_is_a_real_process_startup_error(self):
        for host in ("0.0.0.0", "localhost", "::1"):
            with self.subTest(host=host):
                server = TestServer(environment={"METOD_HOST": host})
                self.addCleanup(server.close)
                with self.assertRaisesRegex(RuntimeError, "METOD_HOST moet 127.0.0.1"):
                    server.start()
                self.assertNotEqual(server.process.returncode, 0)

    def test_bad_staging_network_logs_once_and_preserves_tool_a_while_admin_stays_closed(self):
        for networks in ("10.0.0.0/8", "invalid-network"):
            with (
                self.subTest(networks=networks),
                TestServer(secure=True, environment={"ADMIN_ALLOWED_NETWORKS": networks}) as server,
            ):
                self.assertEqual(server.request("GET", "/")[0], 200)
                for _ in range(3):
                    for path in ("/admin/", "/api/admin/requests", "/admin/assets/admin.js"):
                        self.assertEqual(server.request("GET", path)[0], 404)
                log = (server.root / "server.log").read_text()
                self.assertEqual(log.count("ADMIN_ALLOWED_NETWORKS is ongeldig:"), 1)
                self.assertIn("Admin blijft geblokkeerd; Tool A blijft beschikbaar", log)
                self.assertIn("Corrigeer de instelling en herstart de service", log)

    def test_valid_staging_network_opens_login_without_configuration_warning(self):
        with TestServer(secure=True, environment={"ADMIN_ALLOWED_NETWORKS": "127.0.0.1/32"}) as server:
            self.assertEqual(server.request("GET", "/admin/")[0], 200)
            self.assertNotIn("ADMIN_ALLOWED_NETWORKS is ongeldig", (server.root / "server.log").read_text())

    def test_bad_production_network_still_prevents_startup(self):
        server = TestServer(environment={"APP_ENV": "production", "ADMIN_ALLOWED_NETWORKS": "10.0.0.0/8"})
        self.addCleanup(server.close)
        with self.assertRaisesRegex(RuntimeError, "Startup validation failed"):
            server.start()
        self.assertEqual(server.process.returncode, 2)
        self.assertIn("netwerken zijn samen breder", (server.root / "server.log").read_text())


class ExportPresentationTests(unittest.TestCase):
    def test_dutch_dates_apply_real_winter_summer_and_transition_offsets(self):
        for source, expected in (
            ("2026-09-27T07:10:39.983334Z", "27 september 2026, 09:10"),
            ("2026-01-27T07:10:00+00:00", "27 januari 2026, 08:10"),
            ("2026-09-27T09:10:00+02:00", "27 september 2026, 09:10"),
            ("2026-03-29T00:30:00Z", "29 maart 2026, 01:30"),
            ("2026-03-29T01:30:00Z", "29 maart 2026, 03:30"),
            ("2026-10-25T00:30:00Z", "25 oktober 2026, 02:30"),
            ("2026-10-25T02:30:00Z", "25 oktober 2026, 03:30"),
            ("2026-09-27T07:10:00", "27 september 2026, 09:10"),
            (" 2026-09-27T07:10:00Z ", "27 september 2026, 09:10"),
        ):
            with self.subTest(source=source):
                self.assertEqual(presentation.readable_date(source), expected + " (Nederlandse tijd)")

    def test_invalid_dates_and_missing_timezone_data_have_honest_fallbacks(self):
        for value in (None, 3, "", "not-a-date", "2026-02-31T00:00Z", "9999-12-31T23:59:59Z"):
            self.assertEqual(presentation.readable_date(value), "Onbekend")
        with patch.object(presentation, "DISPLAY_TIMEZONE", timezone.utc):
            self.assertEqual(
                presentation.readable_date("2026-09-27T07:10Z"), "27 september 2026, 07:10 (UTC)"
            )

    def test_all_current_statuses_are_readable_and_unknown_codes_do_not_leak_into_text(self):
        for code, description in (
            ("SUBMITTED", "Aanvraag verzonden"),
            ("DONE", "Afgehandeld"),
            ("CANCELLED", "Geannuleerd door klant"),
        ):
            self.assertEqual(
                presentation.readable_status_lines({"publicStatus": code}), ["Aanvraagstatus: " + description]
            )
        for code, description in (
            ("TODO", "Nog te behandelen"),
            ("DONE", "Afgehandeld"),
            ("CANCELLED", "Geannuleerd"),
        ):
            self.assertEqual(
                presentation.readable_status_lines({"quoteStatus": code}), ["Offertestatus: " + description]
            )
        self.assertEqual(
            presentation.readable_status_lines({"publicStatus": "FUTURE_INTERNAL_STATE"}),
            ["Aanvraagstatus: Onbekend"],
        )
        self.assertEqual(
            presentation.readable_status_lines({"publicStatusLabel": "Aanvraag verzonden"}),
            ["Aanvraagstatus: Aanvraag verzonden"],
        )

    def test_real_customer_download_translates_text_but_preserves_original_json_and_saved_record(self):
        with TestServer() as server:
            path = server.state / "requests/synthetic/status.json"
            path.parent.mkdir(parents=True)
            record = {
                "customer": {"email": "export@example.invalid"},
                "createdAt": "2026-09-27T07:10:39.983334Z",
                "updatedAt": "2026-01-27T07:10:00Z",
                "publicStatus": "SUBMITTED",
                "publicStatusLabel": "Aanvraag verzonden",
                "quoteStatus": "TODO",
            }
            path.write_text(json.dumps(record))
            original = path.read_bytes()
            code, preview, _ = server.request(
                "POST", "/api/admin/privacy", {"action": "preview", "email": "export@example.invalid"}
            )
            self.assertEqual(code, 200)
            code, body, _ = server.request(
                "POST",
                "/api/admin/privacy",
                {"action": "export", "email": "export@example.invalid", "revision": preview["revision"]},
            )
            self.assertEqual(code, 200)
            with zipfile.ZipFile(io.BytesIO(body)) as archive:
                text = archive.read("KLANTGEGEVENS.txt").decode()
                data = json.loads(archive.read("klantgegevens.json"))["requests"][0]
            for expected in (
                "Aanvraagstatus: Aanvraag verzonden",
                "Offertestatus: Nog te behandelen",
                "Ontvangen: 27 september 2026, 09:10",
                "Bijgewerkt: 27 januari 2026, 08:10",
            ):
                self.assertIn(expected, text)
            for technical in ("publicStatus", "quoteStatus", "SUBMITTED", "TODO", "2026-09-27T"):
                self.assertNotIn(technical, text)
            self.assertEqual(data["dates"]["createdAt"], record["createdAt"])
            self.assertEqual(data["status"]["quoteStatus"], "TODO")
            self.assertEqual(data["status"]["publicStatus"], "SUBMITTED")
            self.assertEqual(path.read_bytes(), original)
