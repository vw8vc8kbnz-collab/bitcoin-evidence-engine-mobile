const { chromium } = require("playwright");
const fs = require("node:fs");
const assert = require("node:assert/strict");
(async () => {
  const [url, widthText, output, mode] = process.argv.slice(2),
    width = Number(widthText);
  const browser = await chromium.launch({
    headless: true,
    args: ["--no-sandbox"],
  });
  const page = await browser.newPage({
    viewport: { width, height: width < 700 ? 844 : 1000 },
  });
  const report = { width, checks: [], errors: [], responses: [] };
  report.expectedConsoleErrors = [];
  page.on("pageerror", (e) => report.errors.push(e.message));
  page.on("console", (m) => {
    if (m.type() === "error") {
      if (
        mode?.startsWith("cancel") &&
        /\/api\/(?:jobs\/cancel|cancel)(?:$|\?)/.test(m.location().url) &&
        /(?:403|409|500|502|503|net::ERR_FAILED)/.test(m.text())
      )
        report.expectedConsoleErrors.push(m.text());
      else report.errors.push(m.text());
    }
  });
  page.on("response", (r) => {
    if (r.url().includes("/api/"))
      report.responses.push({
        path: new URL(r.url()).pathname,
        status: r.status(),
      });
  });
  try {
    await page.goto(url, { waitUntil: "domcontentloaded", timeout: 12000 });
    await page.locator(".decorCard").first().click();
    await page.locator("#wizardNextBtn").click();
    await page.waitForFunction(() => document.body.dataset.uiStep === "panels");
    await page.waitForFunction(
      () => !document.querySelector("#addBtnInline").disabled,
    );
    await page.locator("#qty").fill("3");
    await page.locator("#addBtnInline").click();
    report.checks.push("material-and-three-panels");
    await page.locator("#wizardNextBtn").click();
    await page.waitForFunction(() => document.body.dataset.uiStep === "grain");
    report.checks.push("grain-step");
    if (mode?.startsWith("cancel")) {
      await page.locator("#grainNewGroupBtn").click();
      const choices = page.locator(
        width < 700
          ? "#grainEligible .grainStudioCompactPlus:not(:disabled)"
          : "#grainEligible .grainChip:not(.disabled)",
      );
      await choices.first().click();
      await choices.first().click();
      await page.waitForFunction(() =>
        window.state.grain.groups.some((g) => g.items.length === 2),
      );
    }
    await page.getByRole("button", { name: "Toepassen", exact: true }).click();
    await page.waitForFunction(
      () => document.body.dataset.uiStep === "customer",
    );
    for (const [id, value] of Object.entries({
      custFirstName: "Test",
      custLastName: "Klant",
      custCompany: "Voorbeeld BV",
      custEmail: "isolated@example.invalid",
      custPhone: "0612345678",
      custBillingAddress: "Teststraat",
      custPostcode: "1234 AB",
      custHouseNumber: "12",
      custCity: "Teststad",
      custCountry: "Nederland",
      custNote:
        'Maat 60/80? Levering: 9:00 - 50% #1 @Jan € <svg data-audit-injection onload="alert(1)">',
    }))
      await page.locator("#" + id).fill(value);
    await page.locator("#custShipSame").uncheck();
    for (const [id, value] of Object.entries({
      custShippingAddress: "Kerkstraat",
      custShippingHouseNumber: "8",
      custShippingPostcode: "2000",
      custShippingCity: "Antwerpen",
      custShippingCountry: "België",
    }))
      await page.locator("#" + id).fill(value);
    await page.locator("#wizardNextBtn").click();
    await page.waitForFunction(
      () => document.body.dataset.uiStep === "overview",
    );
    report.checks.push("customer-to-overview");
    await page.locator("#overviewNextBtn").click();
    await page
      .locator("#sendConfigBtn")
      .waitFor({ state: "visible", timeout: 60000 });
    await page.waitForFunction(
      () => !document.querySelector("#sendConfigBtn").disabled,
      {},
      { timeout: 60000 },
    );
    report.price = await page.locator("#priceOverlayTotal").innerText();
    if (mode?.startsWith("cancel")) {
      await require("./browser-cancellation.cjs")(page, report, mode, output);
    } else {
      await page.locator("#sendConfigBtn").click();
      await page
        .locator(".submitThanksOverlay")
        .waitFor({ state: "visible", timeout: 20000 });
      report.checks.push("calculation-and-final-submit");
      const thankYouLayout = await page.evaluate(() => {
        const total = document.querySelector(".submitThanksTotal");
        const range = document.createRange();
        range.selectNodeContents(total);
        const lines = [
          ...new Set(
            [...range.getClientRects()].map((rect) => Math.round(rect.top)),
          ),
        ];
        const card = document
          .querySelector(".submitThanksCard")
          .getBoundingClientRect();
        return {
          totalLines: lines.length,
          fitsWidth: total.scrollWidth <= total.clientWidth,
          dialogInsideViewport:
            card.top >= -1 && card.bottom <= innerHeight + 1,
        };
      });
      if (
        thankYouLayout.totalLines !== 1 ||
        !thankYouLayout.fitsWidth ||
        !thankYouLayout.dialogInsideViewport
      )
        throw new Error(
          "Thank-you layout does not fit: " + JSON.stringify(thankYouLayout),
        );
      report.thankYouLayout = thankYouLayout;
      report.checks.push("thank-you-readable-total-and-bounded-dialog");
    }
    if (report.errors.length)
      throw new Error("Browser exceptions: " + report.errors.join("; "));
    report.status = "PASS";
  } catch (e) {
    report.status = "FAIL";
    report.failure = e.message;
    report.visible = await page
      .locator("body")
      .innerText({ timeout: 3000 })
      .catch(() => "<unresponsive>");
  }
  await page
    .screenshot({ path: output.replace(".json", ".png") })
    .catch(() => {});
  fs.writeFileSync(output, JSON.stringify(report, null, 2) + "\n");
  console.log(JSON.stringify(report));
  await browser.close();
  process.exitCode = report.status === "PASS" ? 0 : 1;
})().catch((e) => {
  console.error(e);
  process.exitCode = 2;
});
