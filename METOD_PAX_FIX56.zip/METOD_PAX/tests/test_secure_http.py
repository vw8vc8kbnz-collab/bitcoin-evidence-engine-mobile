"""Security behavior through real HTTP, including adversarial connection load."""

import hashlib
import json
import socket
import sys
import time
import unittest
from server_fixture import ROOT, TestServer, TEST_PASSWORD

sys.path.insert(0, str(ROOT / "app"))
from metod_app.config import externally_exposed_security_enabled as secure
from metod_app.security.credentials import totp_code

SECRET = "JBSWY3DPEHPK3PXP"


class SecureHttpTests(unittest.TestCase):
    def test_secure_default_requires_explicit_local_development(self):
        self.assertTrue(secure(environment={}))
        self.assertFalse(secure(environment={"DEV_MODE": "1", "APP_ENV": "test"}))
        for environment in (
            {"DEV_MODE": "1", "APP_ENV": "production"},
            {"DEV_MODE": "1", "METOD_HOST": "0.0.0.0"},
            {"DEV_MODE": "1", "STAGING_EXTERNAL_HTTPS_PREVIEW": "1"},
        ):
            self.assertTrue(secure(environment=environment))

    def test_account_lock_does_not_lock_out_valid_totp_and_rotation_revokes_cookie(self):
        server = TestServer(secure=True, environment={"ADMIN_ALLOWED_NETWORKS": "203.0.113.0/24"})
        self.addCleanup(server.close)
        credentials = json.loads(server.credentials.read_text())
        credentials["users"][0]["totp_secret"] = SECRET
        server.credentials.write_text(json.dumps(credentials))
        server.start()

        def headers(i):
            return {
                "X-Forwarded-Proto": "https",
                "X-Real-IP": f"203.0.113.{i}",
                "X-Forwarded-For": f"203.0.113.{i}",
            }

        for i in range(1, 13):
            status, _, _ = server.request(
                "POST",
                "/api/admin/login",
                {"username": "admin", "password": "wrong", "otp": "000000"},
                auth=False,
                headers=headers(i),
            )
            self.assertIn(status, (401, 429))
        otp = totp_code(SECRET, int(time.time()) // 30)
        status, body, response = server.request(
            "POST",
            "/api/admin/login",
            {"username": "admin", "password": TEST_PASSWORD, "otp": otp},
            auth=False,
            headers=headers(30),
        )
        self.assertEqual(status, 200, body)
        cookie = response["Set-Cookie"]
        for flag in ("Secure", "HttpOnly", "SameSite=Strict"):
            self.assertIn(flag, cookie)
        server.cookie = cookie.split(";")[0]
        self.assertEqual(server.request("GET", "/api/admin/pricing", headers=headers(30))[0], 200)
        self.assertIn(
            server.request(
                "POST",
                "/api/admin/login",
                {"username": "admin", "password": TEST_PASSWORD, "otp": otp},
                auth=False,
                headers=headers(31),
            )[0],
            (401, 429),
        )
        credentials["users"][0]["active"] = False
        replacement = server.credentials.with_suffix(".new")
        replacement.write_text(json.dumps(credentials))
        replacement.chmod(0o600)
        replacement.replace(server.credentials)
        self.assertIn(server.request("GET", "/api/admin/pricing", headers=headers(30))[0], (401, 403))

    def test_admin_network_policy_covers_shell_assets_login_and_api(self):
        for networks in ("192.0.2.0/24", "invalid-network"):
            with (
                self.subTest(networks=networks),
                TestServer(secure=True, environment={"ADMIN_ALLOWED_NETWORKS": networks}) as server,
            ):
                for path in ("/admin/", "/admin/login", "/admin/assets/admin.css", "/api/admin/pricing"):
                    self.assertIn(server.request("GET", path, auth=False)[0], (403, 404))
                self.assertEqual(server.request("POST", "/api/admin/login", {}, auth=False)[0], 404)

    def test_headers_assets_private_files_and_retired_stream(self):
        with TestServer(secure=True) as server:
            get, body, headers = server.request("GET", "/", auth=False)
            head, empty, head_headers = server.request("HEAD", "/", auth=False)
            self.assertEqual((get, head), (200, 200))
            self.assertEqual(int(head_headers["Content-Length"]), len(body))
            self.assertEqual(empty, b"")
            self.assertIn("style-src-attr 'none'", headers["Content-Security-Policy"])
            self.assertIn("no-store", headers["Cache-Control"])
            manifest = json.loads((ROOT / "app/tool-a/asset-manifest.json").read_text())
            for asset in manifest["assets"].values():
                status, content, hdr = server.request("GET", "/" + asset["path"], auth=False)
                self.assertEqual(status, 200)
                self.assertEqual(hashlib.sha256(content).hexdigest(), asset["sha256"])
                self.assertIn("immutable", hdr["Cache-Control"])
            for path in (
                "/config/pricing_active.json",
                "/metod_app/runtime/application.py",
                "/../requirements.txt",
            ):
                self.assertIn(server.request("GET", path, auth=False)[0], (400, 404))
            self.assertEqual(server.request("GET", "/health/live", auth=False)[1], {"ok": True})
            self.assertEqual(server.request("GET", "/api/events", auth=False)[0], 410)

    def test_seventy_incomplete_connections_leave_workers_available(self):
        with TestServer(secure=True) as server:
            connections = []
            try:
                for _ in range(70):
                    connection = socket.create_connection(("127.0.0.1", server.port), timeout=3)
                    connection.sendall(b"GET / HTTP/1.1\r\nHost: localhost\r\n")
                    connections.append(connection)
                started = time.monotonic()
                self.assertEqual(server.request("GET", "/health/live", auth=False)[0], 200)
                self.assertLess(time.monotonic() - started, 3)
            finally:
                for connection in connections:
                    connection.close()
