#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import os
import stat
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest import mock


ROOT = __import__("server_fixture").ROOT
sys.path.insert(0, str(ROOT / "tools"))

import restore_system_backup as restore_mod  # noqa: E402
from restore_system_backup import RestoreError, restore_backup, verify_backup  # noqa: E402


class RestoreTests(unittest.TestCase):
    def setUp(self) -> None:
        self.holder = tempfile.TemporaryDirectory(prefix="metod_test_restore_")
        self.root = Path(self.holder.name)

    def tearDown(self) -> None:
        self.holder.cleanup()

    def _backup(
        self,
        *,
        wrong_hash: bool = False,
        extra_name: str | None = None,
        target_name: str | None = None,
        state_payload: bytes = b'{"records":[]}\n',
        extra_state: dict[str, bytes] | None = None,
    ) -> Path:
        release_payload = b"FIX660R8\n"
        state_files = {"state/material_library.json": state_payload}
        state_files.update(extra_state or {})
        files = {
            name: {
                "sha256": hashlib.sha256(payload).hexdigest(),
                "size": len(payload),
            }
            for name, payload in state_files.items()
        }
        if wrong_hash:
            files["state/material_library.json"]["sha256"] = "0" * 64
        files.update(
            {
                "release/server_py.py": {
                    "sha256": hashlib.sha256(release_payload).hexdigest(),
                    "size": len(release_payload),
                },
            }
        )
        manifest = {
            "schemaVersion": 2,
            "createdAt": "2026-08-12T00:00:00Z",
            "files": files,
        }
        target = self.root / (target_name or ("bad.zip" if wrong_hash or extra_name else "good.zip"))
        with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as archive:
            for name, payload in state_files.items():
                archive.writestr(name, payload)
            archive.writestr("release/server_py.py", release_payload)
            archive.writestr("BACKUP_MANIFEST.json", json.dumps(manifest))
            if extra_name:
                archive.writestr(extra_name, b"evil")
        return target

    def test_verify_and_restore_to_new_directory(self) -> None:
        backup = self._backup()
        verified = verify_backup(backup)
        self.assertEqual(verified["stateFileCount"], 1)
        target = self.root / "restored-state"
        proof = self.root / "proof.json"
        result = restore_backup(backup, target, proof_path=proof)
        self.assertTrue(result["ok"])
        self.assertEqual((target / "material_library.json").read_bytes(), b'{"records":[]}\n')
        self.assertFalse((target / "server_py.py").exists())
        self.assertEqual(json.loads(proof.read_text())["backupSha256"], verified["backupSha256"])
        with self.assertRaises(RestoreError):
            restore_backup(backup, target)

    def test_hash_tampering_is_rejected_without_target(self) -> None:
        backup = self._backup(wrong_hash=True)
        target = self.root / "must-not-exist"
        with self.assertRaises(RestoreError):
            restore_backup(backup, target)
        self.assertFalse(target.exists())

    def test_traversal_and_extra_members_are_rejected(self) -> None:
        for name in ("../escape", "state/../escape", "/absolute", "state/control\nname"):
            with self.subTest(name=name):
                backup = self._backup(extra_name=name)
                with self.assertRaises(RestoreError):
                    verify_backup(backup)

    def test_manifest_json_and_evidence_types_are_exact(self) -> None:
        payload = b"{}\n"
        digest = hashlib.sha256(payload).hexdigest()
        manifests = {
            "duplicate.zip": (
                '{"schemaVersion":2,"schemaVersion":2,"files":'
                f'{{"state/value.json":{{"sha256":"{digest}","size":3}}}}}}'
            ),
            "string-schema.zip": json.dumps(
                {
                    "schemaVersion": "2",
                    "files": {"state/value.json": {"sha256": digest, "size": len(payload)}},
                }
            ),
            "string-size.zip": json.dumps(
                {
                    "schemaVersion": 2,
                    "files": {"state/value.json": {"sha256": digest, "size": str(len(payload))}},
                }
            ),
            "extra-evidence.zip": json.dumps(
                {
                    "schemaVersion": 2,
                    "files": {
                        "state/value.json": {
                            "sha256": digest,
                            "size": len(payload),
                            "trusted": True,
                        },
                    },
                }
            ),
        }
        for name, manifest in manifests.items():
            with self.subTest(name=name):
                backup = self.root / name
                with zipfile.ZipFile(backup, "w", zipfile.ZIP_DEFLATED) as archive:
                    archive.writestr("state/value.json", payload)
                    archive.writestr("BACKUP_MANIFEST.json", manifest)
                with self.assertRaises(RestoreError):
                    verify_backup(backup)

    def test_restore_uses_authenticated_snapshot_after_source_path_swap(self) -> None:
        original = self._backup(target_name="source.zip", state_payload=b"original\n")
        replacement = self._backup(target_name="replacement.zip", state_payload=b"replacement\n")
        original_sha256 = hashlib.sha256(original.read_bytes()).hexdigest()
        real_verify = restore_mod._verify_backup_snapshot

        def verify_then_swap(*args, **kwargs):
            result = real_verify(*args, **kwargs)
            os.replace(replacement, original)
            return result

        target = self.root / "snapshot-restored"
        with mock.patch.object(restore_mod, "_verify_backup_snapshot", side_effect=verify_then_swap):
            result = restore_backup(original, target)
        self.assertEqual((target / "material_library.json").read_bytes(), b"original\n")
        self.assertEqual(result["backupSha256"], original_sha256)

    def test_symlink_inputs_and_symlink_restore_parents_are_rejected(self) -> None:
        backup = self._backup()
        backup_link = self.root / "linked.zip"
        backup_link.symlink_to(backup)
        with self.assertRaises(RestoreError):
            verify_backup(backup_link)

        real_parent = self.root / "real-parent"
        real_parent.mkdir()
        alias_parent = self.root / "alias-parent"
        alias_parent.symlink_to(real_parent, target_is_directory=True)
        with self.assertRaises(RestoreError):
            restore_backup(backup, alias_parent / "restore-target")
        self.assertFalse((real_parent / "restore-target").exists())

    @unittest.skipIf(os.name == "nt", "POSIX mode contract")
    def test_private_job_create_capability_modes_survive_restore(self) -> None:
        private_name = "state/system/job_create_idempotency/job-1.json"
        backup = self._backup(extra_state={private_name: b'{"token":"secret"}\n'})
        target = self.root / "mode-restored"
        restore_backup(backup, target)
        self.assertEqual(stat.S_IMODE((target / "material_library.json").stat().st_mode), 0o640)
        self.assertEqual(stat.S_IMODE((target / "system").stat().st_mode), 0o750)
        private_root = target / "system/job_create_idempotency"
        self.assertEqual(stat.S_IMODE(private_root.stat().st_mode), 0o700)
        self.assertEqual(stat.S_IMODE((private_root / "job-1.json").stat().st_mode), 0o600)


if __name__ == "__main__":
    unittest.main(verbosity=2)
