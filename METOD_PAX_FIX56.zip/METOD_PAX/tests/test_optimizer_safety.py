#!/usr/bin/env python3
from __future__ import annotations

"""Executable Production-safety regression tests.

The suite intentionally uses real embedded METOD DXF templates for the golden
grain job.  It is dependency-free and safe to run from a release staging tree.
"""

import json
import hashlib
import os
import shutil
import subprocess
import sys
import tempfile
import textwrap
import unittest
from pathlib import Path
from unittest import mock


ROOT = __import__("server_fixture").ROOT
APP = ROOT / "app"
sys.path.insert(0, str(APP))

import dxf_nesting_optimizer as optimizer  # noqa: E402
import catalog_importer  # noqa: E402
import safety_contracts as safety  # noqa: E402
from dxf_geometry import entity_type, split_entities  # noqa: E402
from panel_contract import parse_panels_csv  # noqa: E402
from safety_contracts import (  # noqa: E402
    ContractError,
    append_jsonl_rotating,
    durable_write_many_bytes,
    resolve_identifier_child,
    resolve_relative_file,
    sha256_file,
    strict_json_loads,
)


HEADER = (
    "PartId;PanelName;Qty;LengthMm;WidthMm;ThicknessMm;MaterialCode;GrainGroup;RotationAllowed;H1;H2;W1;W2\n"
)


def minimal_jpeg(width: int = 2, height: int = 2) -> bytes:
    return (
        b"\xff\xd8\xff\xc0\x00\x11\x08"
        + int(height).to_bytes(2, "big")
        + int(width).to_bytes(2, "big")
        + b"\x03\x01\x11\x00\x02\x11\x00\x03\x11\x00\xff\xd9"
    )


def pricing() -> dict:
    return {
        "currency": "EUR",
        "defaults": {"sheetMarginMm": 6.5, "nestingGapMm": 13.0, "kerfMm": 3.2},
        "materials": [
            {
                "materialCode": "MAT_18",
                "publicMaterialId": "decor_0123456789abcdefabcd",
                "decorName": "Optimizer test decor",
                "thicknessMm": 18,
                "sheetSizeMm": {"width": 2800, "height": 2070},
                "purchasePricePerSheet": 100,
                "sellPriceExVatPerSheet": 150,
                "sellPriceInclVatPerSheet": 181.5,
                "materialPriceBasis": "TEST_FIXTURE",
            }
        ],
        "edgeBanding": {
            "defaultLossPercent": 10,
            "codes": [{"code": 1, "purchasePricePerUnit": 2.5}],
        },
    }


class SafetyContractTests(unittest.TestCase):
    def test_durable_batch_stages_all_files_and_flushes_directory_once(self) -> None:
        with tempfile.TemporaryDirectory(prefix="metod_test_batch_") as temp:
            folder = Path(temp)
            first = folder / "first.json"
            second = folder / "second.json"
            real_fsync = safety.os.fsync
            with mock.patch.object(safety.os, "fsync", side_effect=real_fsync) as fsync:
                durable_write_many_bytes([(first, b"one", 0o640), (second, b"two", 0o640)])
            self.assertEqual(first.read_bytes(), b"one")
            self.assertEqual(second.read_bytes(), b"two")
            self.assertEqual(fsync.call_count, 3, "two file flushes plus one directory flush")

            failed_first = folder / "failed-first.json"
            failed_second = folder / "failed-second.json"
            calls = 0

            def fail_second_flush(fd: int) -> None:
                nonlocal calls
                calls += 1
                if calls == 2:
                    raise OSError("simulated storage failure")
                real_fsync(fd)

            with (
                mock.patch.object(safety.os, "fsync", side_effect=fail_second_flush),
                self.assertRaises(OSError),
            ):
                durable_write_many_bytes(
                    [
                        (failed_first, b"not-published", 0o640),
                        (failed_second, b"not-published", 0o640),
                    ]
                )
            self.assertFalse(failed_first.exists())
            self.assertFalse(failed_second.exists())

    def test_hot_progress_snapshots_do_not_force_durable_disk_flushes(self) -> None:
        with tempfile.TemporaryDirectory(prefix="metod_test_progress_") as temp:
            output = Path(temp)
            report: dict = {}
            with mock.patch.object(
                safety,
                "durable_write_json",
                side_effect=AssertionError("transient progress must not fsync"),
            ):
                optimizer.write_progress_report(output, report, 37, "packing", "Nestings berekenen…")
            progress = json.loads((output / "progress.json").read_text(encoding="utf-8"))
            in_flight_report = json.loads((output / "report.json").read_text(encoding="utf-8"))
            self.assertEqual(progress["percent"], 37)
            self.assertEqual(in_flight_report["progress"]["phase"], "packing")

    def test_strict_json_rejects_non_finite(self) -> None:
        for raw in ('{"x": NaN}', '{"x": Infinity}', '{"x": -Infinity}'):
            with self.assertRaises(ContractError):
                strict_json_loads(raw)

    def test_paths_reject_traversal(self) -> None:
        root = Path("/tmp/fix660r8-jobs")
        for value in ("..", "../../victim", "a/b", "a\\b", ""):
            with self.assertRaises(ContractError):
                resolve_identifier_child(root, value)
        for value in ("../quote.json", "/etc/passwd", "a/../../b", "a\\..\\b"):
            with self.assertRaises(ContractError):
                resolve_relative_file(root / "JOB_1", value)

    def test_panel_contract_rejects_adversarial_values(self) -> None:
        valid = HEADER + "A;A;1;397;597;18;MAT_18;;false;0;0;0;0\n"
        self.assertEqual(len(parse_panels_csv(valid, allowed_edge_codes={0, 1})), 1)
        invalid_rows = [
            "A;A;1;NaN;597;18;MAT_18;;false;0;0;0;0",
            "A;A;1.5;397;597;18;MAT_18;;false;0;0;0;0",
            "A;A;1;397;597;18;MAT_18;;maybe;0;0;0;0",
            "A;A;1;397;597;18;MAT_18;;false;-1;0;0;0",
            "A;A;1;397;597;18;MAT_18;;false;2;0;0;0",
        ]
        for row in invalid_rows:
            with self.subTest(row=row), self.assertRaises(ContractError):
                parse_panels_csv(HEADER + row + "\n", allowed_edge_codes={0, 1})

        mixed = (
            HEADER
            + "\n".join(
                (
                    "A;A;1;397;597;18;MAT_18;G001:1;false;0;0;0;0",
                    "B;B;1;797;596;18;MAT_18;G001:2;false;0;0;0;0",
                )
            )
            + "\n"
        )
        with self.assertRaises(ContractError):
            parse_panels_csv(mixed, allowed_edge_codes={0, 1})

    def test_arc_angles_rotate_for_every_quadrant(self) -> None:
        source = ROOT / "app/embedded_dxfs/Overige panelen/Metod Hoekkast 2-2.dxf"
        part = optimizer.load_part(source, {})

        def angles(flat: list[tuple[int, str]]) -> list[list[float]]:
            return [
                [float(value) for code, value in entity if code in {50, 51}]
                for entity in split_entities(flat)
                if entity_type(entity) == "ARC"
            ]

        original = angles(part.drill_pairs)
        self.assertEqual(len(original), 2)
        for rotation in (0, 90, 180, 270):
            transformed = optimizer.rotate_translate_pairs(part.drill_pairs, rotation, 0, 0, part.w, part.h)
            expected = [[(value + rotation) % 360 for value in pair] for pair in original]
            actual = angles(transformed)
            for actual_pair, expected_pair in zip(actual, expected):
                for actual_value, expected_value in zip(actual_pair, expected_pair):
                    self.assertAlmostEqual(actual_value, expected_value, places=7)

    def test_no_machining_dropping_fallback_exists(self) -> None:
        self.assertFalse(hasattr(optimizer, "write_simple_sheet_dxf"))

    @unittest.skipUnless(os.name == "posix", "POSIX address-space limits required")
    def test_one_small_panel_has_bounded_optimizer_memory(self) -> None:
        script = textwrap.dedent("""
            import json, resource, sys
            sys.path.insert(0, sys.argv[1])
            import dxf_nesting_optimizer as optimizer
            from panel_contract import parse_panels_csv
            resource.setrlimit(resource.RLIMIT_AS, (256 * 1024**2, 256 * 1024**2))
            resource.setrlimit(resource.RLIMIT_CPU, (10, 10))
            header = ';'.join(optimizer.PanelRow.__dataclass_fields__) + '\\n'
            results = []
            for width, height, gap in ((40, 1, 13), (1, 2, 13), (0.1, 0.2, 0)):
                csv = header + f'P1;Small panel;1;{height};{width};18;MAT;;true;0;0;0;0\\n'
                row = optimizer.PanelRow(**parse_panels_csv(csv)[0].as_dict())
                instance = optimizer.Instance(row, 1, width, height, True)
                placements, sheets = optimizer.pack_maxrects_optimal(
                    [instance], 2800, 2070, 6.5, gap, False, {},
                )
                assert len(placements) == sheets == 1
                assert placements[0].partId == 'P1'
                results.append([width, height, sheets])
            print(json.dumps(results))
        """)
        result = subprocess.run(
            [sys.executable, "-B", "-c", script, str(APP)],
            capture_output=True,
            text=True,
            timeout=15,
            check=False,
        )
        self.assertEqual(result.returncode, 0, msg=result.stderr)
        self.assertEqual(len(json.loads(result.stdout)), 3)

    @unittest.skipUnless(os.name == "posix", "POSIX address-space limits required")
    def test_cli_memory_limit_does_not_affect_import_and_fails_cleanly(self) -> None:
        script = textwrap.dedent("""
            import json, os, resource, sys, tempfile
            from pathlib import Path
            sys.path.insert(0, sys.argv[1])
            before = resource.getrlimit(resource.RLIMIT_AS)
            import dxf_nesting_optimizer as optimizer
            assert resource.getrlimit(resource.RLIMIT_AS) == before
            os.environ['METOD_OPTIMIZER_MEMORY_MB'] = '128'
            with tempfile.TemporaryDirectory() as temp:
                root = Path(temp)
                (root / 'job.json').write_text('{}')
                sys.argv = ['optimizer', '--input', str(root), '--output', str(root / 'output')]
                import metod_app.optimizer.cli as optimizer_cli
                optimizer_cli.strict_json_load = lambda _path: bytearray(256 * 1024**2)
                code = optimizer.main()
                report = json.loads((root / 'output' / 'report.json').read_text())
                assert code == 1
                assert report['ok'] is False
                assert report['errorCode'] == 'OPTIMIZER_MEMORY_LIMIT'
                assert report['resourceLimits']['addressSpaceBytes'] <= 128 * 1024**2
                assert not (root / 'output' / 'optimizer_manifest.json').exists()
                print(json.dumps({'exitCode': code, 'errorCode': report['errorCode']}))
        """)
        result = subprocess.run(
            [sys.executable, "-B", "-c", script, str(APP)],
            capture_output=True,
            text=True,
            timeout=15,
            check=False,
        )
        self.assertEqual(result.returncode, 0, msg=result.stderr)
        self.assertEqual(json.loads(result.stdout)["errorCode"], "OPTIMIZER_MEMORY_LIMIT")
        self.assertIn("OPTIMIZER_MEMORY_LIMIT", result.stderr)
        self.assertNotIn("Traceback", result.stderr)

    def test_final_gate_rejects_margin_and_gap_violations_independently(self) -> None:
        rows = [
            optimizer.PanelRow(**row.as_dict())
            for row in parse_panels_csv(
                HEADER + "A;A;1;200;100;18;MAT_18;;true;0;0;0;0\n" + "B;B;1;200;100;18;MAT_18;;true;0;0;0;0\n"
            )
        ]
        materials = {item["materialCode"]: item for item in pricing()["materials"]}

        def placements():
            return [
                optimizer.Placement(
                    partId=row.PartId,
                    instanceIndex=1,
                    sheetIndex=1,
                    x=6.5 + index * 113,
                    y=6.5,
                    rotationDeg=0,
                    widthMm=100,
                    lengthMm=200,
                    materialCode="MAT_18",
                    thicknessMm=18,
                    edge={"H1": 0, "H2": 0, "W1": 0, "W2": 0},
                )
                for index, row in enumerate(rows)
            ]

        result = optimizer.validate_final_placements(
            rows,
            placements(),
            materials,
            {},
            margin=6.5,
            gap=13,
        )
        self.assertEqual(result["nestingGapMm"], 13)
        for axis, value in (("x", 6), ("y", 6), ("x", 2699), ("y", 1869)):
            mutated = placements()
            setattr(mutated[0], axis, value)
            with self.subTest(axis=axis, value=value), self.assertRaisesRegex(RuntimeError, "sheet margin"):
                optimizer.validate_final_placements(rows, mutated, materials, {}, margin=6.5, gap=13)
        too_close = placements()
        too_close[1].x = 119.3  # No overlap, but only 12.8 mm between cut contours.
        with self.assertRaisesRegex(RuntimeError, "nesting gap"):
            optimizer.validate_final_placements(rows, too_close, materials, {}, margin=6.5, gap=13)
        overlapping = placements()
        overlapping[1].x = 50
        with self.assertRaisesRegex(RuntimeError, "collision"):
            optimizer.validate_final_placements(rows, overlapping, materials, {}, margin=6.5, gap=0)

    def test_unsupported_production_entities_are_rejected_before_conversion(self) -> None:
        with tempfile.TemporaryDirectory(prefix="metod_test_entities_") as temp:
            path = Path(temp) / "unsupported.dxf"
            for kind in ("POINT", "SOLID", "TRACE", "POLYLINE", "ELLIPSE", "SPLINE", "INSERT"):
                path.write_text(f"0\nSECTION\n2\nENTITIES\n0\n{kind}\n10\n1\n20\n1\n0\nENDSEC\n0\nEOF\n")
                with (
                    self.subTest(kind=kind),
                    self.assertRaisesRegex(RuntimeError, "unsupported production DXF entities"),
                ):
                    optimizer.load_part(path, {})
            path.write_text("0\nSECTION\n2\nENTITIES\n0\nLWPOLYLINE\n8\nDRILL\n0\nENDSEC\n0\nEOF\n")
            with self.assertRaisesRegex(RuntimeError, "only an OUTLINE LWPOLYLINE"):
                optimizer.load_part(path, {})

    @unittest.skipUnless(shutil.which("node"), "Node required for browser DXF contract")
    def test_browser_arc_mirror_and_all_template_exports_preserve_geometry(self) -> None:
        script = r"""
            const fs = require('fs'), path = require('path'), vm = require('vm'), assert = require('assert');
            const app = process.argv[1], output = process.argv[2];
            const context = {window: {}, state: {templates: new Map()}};
            vm.createContext(context);
            const fixture = require(path.join(process.argv[3], 'geometry-fixture.cjs'));
            const owners = fixture.loadGeometryOwners(context, app);
            const helper = owners.helper;
            const close = (a, b) => assert(Math.abs(a - b) < 1e-8, `${a} != ${b}`);
            for(const [start, end] of [[0,90], [350,10], [224.4153,135.5847], [90,180], [270,360]]){
              const pairs = [['0','ARC'],['10','3'],['20','-4'],['40','12.5'],['50',String(start)],['51',String(end)]];
              const angle = code => Number(pairs.find(row => row[0] === code)[1]);
              helper.mirrorX(pairs, () => ({minX:2, maxX:15}));
              const sweep = (end - start + 360) % 360;
              const reflectedSweep = (angle('51') - angle('50') + 360) % 360;
              close(sweep, reflectedSweep);
              for(const fraction of [0, .25, .5, .75, 1]){
                const original = (start + (1 - fraction) * sweep) * Math.PI / 180;
                const reflected = (angle('50') + fraction * reflectedSweep) * Math.PI / 180;
                close(angle('10') + 12.5 * Math.cos(reflected), 17 - (3 + 12.5 * Math.cos(original)));
                close(angle('20') + 12.5 * Math.sin(reflected), -4 + 12.5 * Math.sin(original));
              }
              helper.mirrorX(pairs, () => ({minX:2, maxX:15}));
              close(angle('10'), 3); close(angle('20'), -4);
              close(angle('50'), start % 360); close(angle('51'), end % 360);
            }

            Object.assign(context,owners.dxfExport,owners.templateExport);
            const sourceRoot = path.join(app, 'embedded_dxfs');
            const sources = [];
            function collect(folder){
              for(const entry of fs.readdirSync(folder, {withFileTypes:true})){
                const full = path.join(folder, entry.name);
                if(entry.isDirectory()) collect(full);
                else if(entry.name.toLowerCase().endsWith('.dxf')) sources.push(path.relative(sourceRoot, full));
              }
            }
            collect(sourceRoot);
            (async()=>{
              const exports = [];
              for(const relative of sources.sort()){
                context.state.templates.set(relative, {sourceName:relative});
                context.window.__TOOLA_DXF_TEXT_CACHE[relative] = fs.readFileSync(path.join(sourceRoot, relative), 'utf8');
                for(const [hinge, extTop, extBot] of [['left',0,0], ['right',0,0], ['left',50,0], ['left',0,50]]){
                  const dxf = await context.buildDxfForMetodItem({templateId:relative, hinge, extTop, extBot});
                  const filename = `${exports.length}.dxf`;
                  fs.writeFileSync(path.join(output, filename), dxf);
                  exports.push({relative, filename, hinge, extTop, extBot});
                }
              }

              console.log(JSON.stringify(exports));
            })().catch(error => {console.error(error); process.exitCode = 1;});
        """
        with tempfile.TemporaryDirectory(prefix="metod_test_browser_dxf_") as temp:
            result = subprocess.run(
                ["node", "-e", script, str(APP), temp, str(Path(__file__).parent)],
                capture_output=True,
                text=True,
                timeout=30,
                check=False,
            )
            self.assertEqual(result.returncode, 0, msg=result.stderr)
            exports = json.loads(result.stdout)
            source_count = len(list((APP / "embedded_dxfs").rglob("*.dxf")))
            self.assertGreater(source_count, 40)
            self.assertEqual(len(exports), source_count * 4)
            for item in exports:
                with self.subTest(
                    template=item["relative"],
                    hinge=item["hinge"],
                    extTop=item["extTop"],
                    extBot=item["extBot"],
                ):
                    original = optimizer.load_part(APP / "embedded_dxfs" / item["relative"], {})
                    exported = optimizer.load_part(Path(temp) / item["filename"], {})
                    self.assertAlmostEqual(exported.w, original.w, places=5)
                    self.assertAlmostEqual(exported.h, original.h + item["extTop"] + item["extBot"], places=5)
                    self.assertEqual(exported.drill_entity_count, original.drill_entity_count)

    def test_catalog_image_dns_is_pinned_and_private_ips_fail_closed(self) -> None:
        public_info = [(2, 1, 6, "", ("93.184.216.34", 443))]
        private_info = [(2, 1, 6, "", ("127.0.0.1", 443))]
        with mock.patch.object(catalog_importer.socket, "getaddrinfo", return_value=private_info):
            with self.assertRaises(ValueError):
                catalog_importer.validate_remote_image_url("https://adzaagt.nl/image.jpg")

        calls: list[tuple[str, str]] = []

        class FakeSocket:
            def settimeout(self, _value):
                return None

        class FakeResponse:
            status = 200

            def __init__(self):
                self._data = minimal_jpeg()
                self._chunks = [self._data, b""]

            def getheader(self, name):
                return str(len(self._data)) if name == "Content-Length" else None

            def read(self, _size):
                return self._chunks.pop(0)

        class FakeConnection:
            def __init__(self, host, pinned_ip, *, timeout):
                calls.append((host, pinned_ip))
                self.sock = FakeSocket()

            def request(self, _method, _target, headers=None):
                self.headers = headers or {}

            def getresponse(self):
                return FakeResponse()

            def close(self):
                return None

        with (
            mock.patch.object(catalog_importer.socket, "getaddrinfo", return_value=public_info),
            mock.patch.object(catalog_importer, "_PinnedHTTPSConnection", FakeConnection),
        ):
            result = catalog_importer.download_catalog_image("https://adzaagt.nl/image.jpg")
        self.assertEqual(calls, [("adzaagt.nl", "93.184.216.34")])
        self.assertEqual(result["mime"], "image/jpeg")
        self.assertEqual((result["width"], result["height"]), (2, 2))

        oversized_png = (
            b"\x89PNG\r\n\x1a\n\x00\x00\x00\x0dIHDR"
            + (10_000).to_bytes(4, "big")
            + (10_000).to_bytes(4, "big")
            + b"\x08\x02\x00\x00\x00"
        )
        with self.assertRaises(ValueError):
            catalog_importer._validated_image_dimensions(oversized_png, "image/png")

    def test_catalog_cache_detects_tampering(self) -> None:
        with tempfile.TemporaryDirectory(prefix="metod_test_catalog_cache_") as temp:
            folder = Path(temp)
            data = minimal_jpeg()
            payload = {
                "data": data,
                "mime": "image/jpeg",
                "sha256": hashlib.sha256(data).hexdigest(),
                "bytes": len(data),
            }
            catalog_importer.atomic_write_cached_image(folder, payload)
            self.assertIsNotNone(catalog_importer.read_cached_image(folder))
            (folder / "catalog.img").write_bytes(data + b"tamper")
            self.assertIsNone(catalog_importer.read_cached_image(folder))

    def test_bounded_jsonl_rotates_without_dropping_new_record(self) -> None:
        with tempfile.TemporaryDirectory(prefix="metod_test_log_rotation_") as temp:
            path = Path(temp) / "audit.jsonl"
            for index in range(12):
                append_jsonl_rotating(
                    path,
                    {"index": index, "padding": "x" * 180},
                    max_bytes=1024,
                    backups=2,
                )
            self.assertTrue(path.is_file())
            self.assertTrue(path.with_name("audit.jsonl.1").is_file())
            current_records = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()]
            self.assertEqual(current_records[-1]["index"], 11)
            self.assertLessEqual(path.stat().st_size, 1024)


class GoldenOptimizerTests(unittest.TestCase):
    def _run_job(
        self, panel_rows: str, templates: dict[str, Path]
    ) -> tuple[subprocess.CompletedProcess[str], Path, tempfile.TemporaryDirectory[str]]:
        holder: tempfile.TemporaryDirectory[str] = tempfile.TemporaryDirectory(prefix="metod_test_test_")
        root = Path(holder.name)
        input_dir = root / "input"
        parts_dir = input_dir / "dxf_parts"
        output_dir = root / "output"
        parts_dir.mkdir(parents=True)
        (input_dir / "job.json").write_text(json.dumps({"grainEnabled": True}), encoding="utf-8")
        (input_dir / "pricing.json").write_text(json.dumps(pricing()), encoding="utf-8")
        (input_dir / "panels.csv").write_text(HEADER + panel_rows, encoding="utf-8")
        for part_id, template in templates.items():
            shutil.copyfile(template, parts_dir / f"{part_id}.dxf")
        result = subprocess.run(
            [
                sys.executable,
                str(APP / "dxf_nesting_optimizer.py"),
                "--input",
                str(input_dir),
                "--output",
                str(output_dir),
            ],
            cwd=str(ROOT),
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=60,
            check=False,
        )
        return result, output_dir, holder

    def test_three_panel_grain_order_and_manifest(self) -> None:
        templates = {
            "GRAIN_A": ROOT / "app/embedded_dxfs/Deuren METOD/Metod deur 60x40.dxf",
            "GRAIN_B": ROOT / "app/embedded_dxfs/Deuren METOD/Metod deur 60x80.dxf",
            "GRAIN_C": ROOT / "app/embedded_dxfs/Ladefront METOD/Metod lade 60x20.dxf",
        }
        rows = (
            "\n".join(
                (
                    "GRAIN_A;A;1;397;597;18;MAT_18;G001:1;false;0;0;0;0",
                    "GRAIN_B;B;1;797;597;18;MAT_18;G001:2;false;0;0;0;0",
                    "GRAIN_C;C;1;197;597;18;MAT_18;G001:3;false;0;0;0;0",
                )
            )
            + "\n"
        )
        result, output, holder = self._run_job(rows, templates)
        self.addCleanup(holder.cleanup)
        self.assertEqual(result.returncode, 0, msg=result.stderr)
        report = json.loads((output / "report.json").read_text(encoding="utf-8"))
        placements = json.loads((output / "placements.json").read_text(encoding="utf-8"))["placements"]
        by_id = {item["partId"]: item for item in placements}
        self.assertLess(by_id["GRAIN_A"]["y_mm"], by_id["GRAIN_B"]["y_mm"])
        self.assertLess(by_id["GRAIN_B"]["y_mm"], by_id["GRAIN_C"]["y_mm"])
        self.assertEqual({item["rotation_deg"] for item in placements}, {0})
        self.assertTrue(report["ok"])
        self.assertTrue(report["placementValidation"]["grainPositionOneIsLowestY"])

        manifest_path = output / "optimizer_manifest.json"
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        self.assertEqual(manifest["counts"]["requestedInstances"], 3)
        self.assertEqual(manifest["counts"]["placements"], 3)
        self.assertEqual(report["optimizerManifestSha256"], sha256_file(manifest_path))
        for relative, expected_hash in manifest["outputsSha256"].items():
            self.assertEqual(sha256_file(output / relative), expected_hash)

    def test_250_equal_panels_use_one_grid_candidate_without_duplicate_strategy_runs(self) -> None:
        template = ROOT / "app/embedded_dxfs/Deuren METOD/Metod deur 60x40.dxf"
        rows = "BULK;Bulk;250;397;597;18;MAT_18;;true;0;0;0;0\n"
        result, output, holder = self._run_job(rows, {"BULK": template})
        self.addCleanup(holder.cleanup)
        self.assertEqual(result.returncode, 0, msg=result.stderr)

        placements = json.loads((output / "placements.json").read_text(encoding="utf-8"))["placements"]
        manifest = json.loads((output / "optimizer_manifest.json").read_text(encoding="utf-8"))
        attempts = json.loads((output / "optimizer_attempt_summary.json").read_text(encoding="utf-8"))[
            "materials"
        ]["MAT_18"]
        report = json.loads((output / "report.json").read_text(encoding="utf-8"))

        self.assertEqual(len(placements), 250)
        placement_fingerprint = hashlib.sha256(
            json.dumps(placements, sort_keys=True, separators=(",", ":")).encode("utf-8")
        ).hexdigest()
        self.assertEqual(
            placement_fingerprint,
            "30145ef74df9aef1d4385549ae9a67e8dcb6c19f0b2e98dff63e974c059ff998",
            "performance work must not change the 250-panel nesting result",
        )
        self.assertEqual(manifest["counts"]["requestedInstances"], 250)
        self.assertEqual(manifest["counts"]["placements"], 250)
        self.assertEqual(manifest["counts"]["productionSheets"], 12)
        self.assertEqual(len(report["sheetValidation"]), 12)
        self.assertEqual(report["placementValidation"]["expectedInstances"], 250)
        self.assertEqual(report["placementValidation"]["observedPlacements"], 250)
        self.assertEqual(attempts["homogeneousGrid"]["capacityPerSheet"], 21)
        self.assertEqual(attempts["homogeneousGrid"]["sheetsUsed"], 12)
        self.assertEqual(attempts["homogeneousGrid"]["pattern"]["rotationsUsed"], [0, 90])
        self.assertEqual(attempts["greedyVariantsExecuted"], ["density_first"])
        self.assertEqual(len(attempts["greedyVariantsSkippedEquivalent"]), 4)
        self.assertEqual(attempts["finalSheetsUsed"], 12)
        for relative, expected_hash in manifest["outputsSha256"].items():
            self.assertEqual(sha256_file(output / relative), expected_hash)

    def test_200_mixed_panels_preserve_sheet_count_with_equivalent_item_pruning(self) -> None:
        specs = [
            ("A", "Deuren METOD/Metod deur 60x40.dxf", 397, 597),
            ("B", "Deuren METOD/Metod deur 60x60.dxf", 597, 597),
            ("C", "Deuren METOD/Metod deur 60x80.dxf", 797, 597),
            ("D", "Deuren METOD/Metod deur 40x40.dxf", 397, 397),
            ("E", "Deuren METOD/Metod deur 40x60.dxf", 597, 397),
            ("F", "Deuren METOD/Metod deur 30x40.dxf", 397, 297),
            ("G", "Ladefront METOD/Metod lade 80x10.dxf", 97, 797),
            ("H", "Ladefront METOD/Metod lade 80x20.dxf", 197, 797),
        ]
        rows = "".join(
            f"{part};{part};25;{length};{width};18;MAT_18;;true;0;0;0;0\n"
            for part, _relative, length, width in specs
        )
        templates = {part: ROOT / "app/embedded_dxfs" / relative for part, relative, _length, _width in specs}
        result, output, holder = self._run_job(rows, templates)
        self.addCleanup(holder.cleanup)
        self.assertEqual(result.returncode, 0, msg=result.stderr)

        placements = json.loads((output / "placements.json").read_text(encoding="utf-8"))["placements"]
        manifest = json.loads((output / "optimizer_manifest.json").read_text(encoding="utf-8"))
        attempts = json.loads((output / "optimizer_attempt_summary.json").read_text(encoding="utf-8"))[
            "materials"
        ]["MAT_18"]
        report = json.loads((output / "report.json").read_text(encoding="utf-8"))

        self.assertEqual(len(placements), 200)
        placement_fingerprint = hashlib.sha256(
            json.dumps(placements, sort_keys=True, separators=(",", ":")).encode("utf-8")
        ).hexdigest()
        self.assertEqual(
            placement_fingerprint,
            "ed60059734db859fd4588f226c8bdcb96d65863a38b2eaeed80f0228af8c1ec2",
            "performance work must not change the 200-panel nesting result",
        )
        self.assertEqual(manifest["counts"]["productionSheets"], 10)
        self.assertEqual(attempts["finalSheetsUsed"], 10)
        self.assertEqual(attempts["greedyVariantsSkippedEquivalent"].get("area_desc"), "density_first")
        self.assertEqual(report["placementValidation"]["expectedInstances"], 200)
        self.assertEqual(report["placementValidation"]["observedPlacements"], 200)
        self.assertEqual(len(report["sheetValidation"]), 10)

    def test_bbox_mismatch_is_fatal_and_publishes_no_sheet(self) -> None:
        template = ROOT / "app/embedded_dxfs/Ladefront METOD/Metod lade 80x40.dxf"
        rows = "BAD;Bad;1;397;597;18;MAT_18;;false;0;0;0;0\n"
        result, output, holder = self._run_job(rows, {"BAD": template})
        self.addCleanup(holder.cleanup)
        self.assertNotEqual(result.returncode, 0)
        report = json.loads((output / "report.json").read_text(encoding="utf-8"))
        self.assertFalse(report["ok"])
        self.assertIn("differs from CSV", report["exception"])
        sheets = list((output / "sheets").glob("*.dxf")) if (output / "sheets").exists() else []
        self.assertEqual(sheets, [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
