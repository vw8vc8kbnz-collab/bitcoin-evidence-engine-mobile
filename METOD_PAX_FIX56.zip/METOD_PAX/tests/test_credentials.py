#!/usr/bin/env python3
from __future__ import annotations

"""Behavior and ownership proof for the R9C credential-primitives extraction."""

import sys
import unittest


RELEASE = __import__("server_fixture").ROOT
APP = RELEASE / "app"
SERVER = APP / "server_py.py"
sys.path.insert(0, str(APP))

from metod_app.security.credentials import (  # noqa: E402
    PBKDF2_ITERATIONS,
    pbkdf2_hash_password,
    totp_code,
    verify_password_against_stored,
    verify_totp,
)


class BrokenString:
    def __str__(self) -> str:
        raise RuntimeError("deliberate")


class CredentialBehaviorTests(unittest.TestCase):
    def test_pbkdf2_explicit_salt_contract_is_stable(self) -> None:
        value = pbkdf2_hash_password(
            "test-password",
            salt="testsalt01234567",
        )
        self.assertEqual(
            value,
            "pbkdf2_sha256$600000$testsalt01234567$"
            "a23871f54ab4d8381e74cb646538467f5777afef11cab3ed8abc42bfcc21575a",
        )
        self.assertEqual(PBKDF2_ITERATIONS, 600_000)

    def test_pbkdf2_generated_salts_remain_random_and_valid(self) -> None:
        first = pbkdf2_hash_password("same-password")
        second = pbkdf2_hash_password("same-password")
        pattern = r"pbkdf2_sha256\$600000\$[a-f0-9]{32}\$[a-f0-9]{64}"
        self.assertRegex(first, pattern)
        self.assertRegex(second, pattern)
        self.assertNotEqual(first, second)

    def test_password_verification_accepts_exact_hash_and_rejects_changes(self) -> None:
        stored = pbkdf2_hash_password("correct", salt="testsalt01234567")
        self.assertTrue(verify_password_against_stored("correct", stored))
        self.assertFalse(verify_password_against_stored("wrong", stored))
        self.assertFalse(
            verify_password_against_stored(
                "correct",
                stored.replace("$600000$", "$600001$", 1),
            )
        )

    def test_password_verification_migrates_legacy_hash_and_rejects_plaintext(self) -> None:
        self.assertFalse(verify_password_against_stored("legacy", "legacy"))
        legacy_digest = (
            __import__("hashlib").pbkdf2_hmac("sha256", b"legacy", b"testsalt01234567", 260_000).hex()
        )
        self.assertTrue(
            verify_password_against_stored("legacy", f"pbkdf2_sha256$260000$testsalt01234567${legacy_digest}")
        )
        for stored in (
            "",
            None,
            "pbkdf2_sha256$",
            "pbkdf2_sha256$not-int$testsalt01234567$" + ("a" * 64),
            "pbkdf2_sha256$600000$short$" + ("a" * 64),
            "pbkdf2_sha256$600000$testsalt01234567$NOT-HEX",
            BrokenString(),
        ):
            self.assertFalse(verify_password_against_stored("legacy", stored), stored)

    def test_totp_matches_rfc_vector_and_normalizes_base32_spacing(self) -> None:
        secret = "GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ"
        self.assertEqual(totp_code(secret, 1, digits=8), "94287082")
        self.assertEqual(totp_code("JBSW Y3DP EHPK 3PXP", 1), totp_code("JBSWY3DPEHPK3PXP", 1))

    def test_totp_verifier_accepts_only_six_digits_in_three_step_window(self) -> None:
        secret = "JBSWY3DPEHPK3PXP"
        center = 1_000
        previous_code = totp_code(secret, center - 1)
        center_code = totp_code(secret, center)
        next_code = totp_code(secret, center + 1)
        for code in (previous_code, center_code, next_code, f" {center_code[:3]} {center_code[3:]} "):
            self.assertTrue(verify_totp(secret, code, now=center * 30))
        self.assertFalse(verify_totp(secret, totp_code(secret, center + 2), now=center * 30))
        for code in ("", "12345", "1234567", "abcdef", None):
            self.assertFalse(verify_totp(secret, code, now=center * 30), code)
        with self.assertRaises(RuntimeError):
            verify_totp(secret, BrokenString(), now=center * 30)
        self.assertFalse(verify_totp("not-base32!", center_code, now=center * 30))


if __name__ == "__main__":
    unittest.main(verbosity=2)
