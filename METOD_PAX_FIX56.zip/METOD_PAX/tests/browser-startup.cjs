const { chromium } = require("playwright");
const fs = require("node:fs");

(async () => {
  const [url, widthText, output] = process.argv.slice(2);
  const browser = await chromium.launch({ headless: true, args: ["--no-sandbox"] });
  const context = await browser.newContext({ viewport: { width: Number(widthText), height: 844 } });
  const page = await context.newPage();
  const report = { url, width: Number(widthText), errors: [], consoleErrors: [], requests: [] };
  page.on("pageerror", (error) => report.errors.push(error.message));
  page.on("console", (message) => {
    if (message.type() === "error") report.consoleErrors.push(message.text());
  });
  page.on("request", (request) => {
    if (request.url().includes("/api/")) report.requests.push(request.url().split("/api/")[1]);
  });
  try {
    await page.goto(url, { waitUntil: "domcontentloaded", timeout: 12000 });
    await page
      .locator("#decorLibraryPanel .decorCard")
      .first()
      .waitFor({ state: "visible", timeout: 10000 });
    report.responsive = await page.evaluate(() => ({
      ready: document.readyState,
      step: document.body.dataset.uiStep,
      cards: document.querySelectorAll(".decorCard").length,
    }));
    await page.screenshot({ path: output.replace(/\.json$/, ".png") });
    report.status = "PASS";
  } catch (error) {
    report.status = "FAIL";
    report.failure = error.message;
  }
  fs.writeFileSync(output, JSON.stringify(report, null, 2) + "\n");
  await browser.close();
  console.log(JSON.stringify(report));
  process.exitCode = report.status === "PASS" ? 0 : 1;
})().catch((error) => {
  console.error(error);
  process.exitCode = 2;
});
