/** Cancellation contracts, real API transport and durable browser recovery. */
const { test } = require("node:test");
const assert = require("node:assert/strict");
const { webcrypto } = require("node:crypto");
const jobId = "JOB_CANCELLATION_TEST";
const requestId = "REQ_CANCELLATION_TEST";
const confirmedJob = { ok: true, jobId, state: "cancelled" };
const confirmedRequest = {
  ok: true,
  requestId,
  cancelled: true,
  idempotent: false,
};
const response = (status, data) =>
  new Response(typeof data === "string" ? data : JSON.stringify(data), {
    status,
  });
const contracts = import("../app/tool-a/api/cancellation-response.js");
const jobs = import("../app/tool-a/api/jobs.js");

function memoryStorage() {
  const data = new Map();
  return {
    getItem: (k) => data.get(k) ?? null,
    setItem: (k, v) => data.set(k, v),
    removeItem: (k) => data.delete(k),
    snapshot: () => [...data],
  };
}
async function client(cancel, timeout = 50) {
  const storage = memoryStorage();
  const { createJobsApi } = await jobs;
  const api = createJobsApi({
    attemptStorage: storage,
    requirePersistentStartAttempt: true,
    cryptoImpl: webcrypto,
    cancelRequestTimeoutMs: timeout,
    fetchImpl: async (url, options) => {
      if (url === "/api/jobs")
        return response(202, { jobId, accessToken: "synthetic-capability" });
      assert.equal(url, "/api/jobs/cancel");
      assert.equal(
        options.headers.Authorization,
        "Bearer synthetic-capability",
      );
      return cancel(options);
    },
  });
  await api.startJob(JSON.stringify({ test: "cancellation recovery" }));
  assert(storage.getItem("metod_running_job_v1"));
  return {
    api,
    storage,
    cancel: () => api.cancelJob({ jobId, accessToken: "synthetic-capability" }),
  };
}

test("job confirmation binds HTTP status, exact identity and terminal state", async () => {
  const { isJobCancellationConfirmed: confirmed } = await contracts;
  assert(confirmed(response(200, confirmedJob), confirmedJob, jobId));
  for (const state of ["done", "ready", "ok", "cancelled", "canceled"]) {
    const data = { ok: false, jobId, state };
    assert(confirmed(response(409, data), data, jobId));
  }
  for (const status of [200, 202, 403, 404, 409, 429, 500, 502, 503]) {
    for (const data of [
      null,
      [],
      {},
      "cancelled",
      { ok: true },
      { ...confirmedJob, jobId: "ANOTHER_JOB" },
      { ...confirmedJob, state: "processing" },
    ]) {
      assert.equal(
        confirmed(response(status, data), data, jobId),
        false,
        JSON.stringify({ status, data }),
      );
    }
    if (status !== 200)
      assert.equal(
        confirmed(response(status, confirmedJob), confirmedJob, jobId),
        false,
      );
  }
});

test("request confirmation rejects deceptive success and permits duplicate cancellation", async () => {
  const { isRequestCancellationConfirmed: confirmed } = await contracts;
  for (const idempotent of [false, true]) {
    const data = { ...confirmedRequest, idempotent };
    assert(confirmed(response(200, data), data, requestId));
  }
  for (const status of [200, 202, 403, 404, 409, 429, 500, 502, 503]) {
    for (const data of [
      null,
      [],
      {},
      "cancelled",
      { ok: true },
      { ...confirmedRequest, requestId: "ANOTHER_REQUEST" },
      { ...confirmedRequest, ok: false },
      { ...confirmedRequest, cancelled: false },
      { alreadyCancelled: true },
    ]) {
      assert.equal(confirmed(response(status, data), data, requestId), false);
    }
    if (status !== 200)
      assert.equal(
        confirmed(
          response(status, confirmedRequest),
          confirmedRequest,
          requestId,
        ),
        false,
      );
  }
});

test("unreadable or deceptive responses retain actual start recovery; valid retry clears it", async () => {
  let reply = () => response(200, "<html>TECHNICAL_PROXY_MARKER</html>");
  const c = await client(() => reply());
  const before = c.storage.snapshot();
  for (const [status, body] of [
    [200, ""],
    [200, "{broken"],
    [200, "null"],
    [200, []],
    [200, "<html>TECHNICAL_PROXY_MARKER</html>"],
    [500, confirmedJob],
    [503, confirmedJob],
    [200, { ...confirmedJob, jobId: "ANOTHER_JOB" }],
    [409, { ok: false, jobId, state: "failed" }],
  ]) {
    reply = () => response(status, body);
    const r = await c.cancel();
    assert.equal(r.status, status);
    assert.deepEqual(c.storage.snapshot(), before);
  }
  reply = () => response(200, confirmedJob);
  const result = await c.cancel();
  assert.deepEqual(await result.json(), confirmedJob); // Still readable by UI after recovery checks.
  assert.equal(c.storage.getItem("metod_running_job_v1"), null);
});

test("completed-job 409 clears recovery only for the requested job", async () => {
  let reply = { ok: false, jobId: "ANOTHER_JOB", state: "done" };
  const c = await client(() => response(409, reply));
  const before = c.storage.snapshot();
  await c.cancel();
  assert.deepEqual(c.storage.snapshot(), before);
  reply = { ok: false, jobId, state: "done" };
  await c.cancel();
  assert.equal(c.storage.getItem("metod_running_job_v1"), null);
});

test("fetch rejection preserves recovery and a later request can succeed", async () => {
  let fail = true;
  const c = await client(() => {
    if (fail) throw new Error("TECHNICAL_FETCH_MARKER");
    return response(200, confirmedJob);
  });
  const before = c.storage.snapshot();
  await assert.rejects(c.cancel(), /TECHNICAL_FETCH_MARKER/);
  assert.deepEqual(c.storage.snapshot(), before);
  fail = false;
  await c.cancel();
  assert.equal(c.storage.getItem("metod_running_job_v1"), null);
});

for (const phase of ["headers", "body"]) {
  test(`deadline includes stalled ${phase}; late confirmation cannot erase recovery`, async () => {
    let resolveLate;
    const stalled = new Promise((resolve) => {
      resolveLate = resolve;
    });
    const c = await client(
      () =>
        phase === "headers"
          ? stalled
          : {
              status: 200,
              ok: true,
              text: () => stalled,
            },
      20,
    );
    const before = c.storage.snapshot();
    await assert.rejects(
      c.cancel(),
      (error) =>
        error.metodRequestTimeout === true && error.operation === "job_cancel",
    );
    assert.deepEqual(c.storage.snapshot(), before);
    resolveLate(
      phase === "headers"
        ? response(200, confirmedJob)
        : JSON.stringify(confirmedJob),
    );
    await new Promise((resolve) => setTimeout(resolve, 10));
    assert.deepEqual(c.storage.snapshot(), before);
  });
}
