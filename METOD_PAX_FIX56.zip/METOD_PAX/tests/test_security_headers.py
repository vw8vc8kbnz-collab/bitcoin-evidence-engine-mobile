#!/usr/bin/env python3
from __future__ import annotations

"""Behavior and ownership proof for the R9C pure-header extraction."""

import sys
import unittest


RELEASE = __import__("server_fixture").ROOT
APP = RELEASE / "app"
SERVER = APP / "server_py.py"
sys.path.insert(0, str(APP))

from metod_app.security.headers import (  # noqa: E402
    extract_admin_session_cookie,
    extract_bearer_token,
    extract_forwarded_client_ip,
)


class BrokenString:
    def __str__(self) -> str:
        raise RuntimeError("deliberate")


class SecurityHeaderBehaviorTests(unittest.TestCase):
    def test_forwarded_ip_accepts_one_canonical_ip(self) -> None:
        self.assertEqual(extract_forwarded_client_ip(" 192.0.2.10 "), "192.0.2.10")
        self.assertEqual(extract_forwarded_client_ip("2001:0db8::1"), "2001:db8::1")
        self.assertEqual(extract_forwarded_client_ip("[2001:db8::2]"), "2001:db8::2")
        self.assertEqual(extract_forwarded_client_ip("[2001:db8::1]:443"), "2001:db8::1")

    def test_forwarded_ip_rejects_chains_ports_zones_and_invalid_values(self) -> None:
        for value in (
            "",
            "192.0.2.1, 198.51.100.2",
            "192.0.2.1:443",
            "not-an-ip",
            None,
        ):
            self.assertEqual(extract_forwarded_client_ip(value), "", value)
        with self.assertRaises(RuntimeError):
            extract_forwarded_client_ip(BrokenString())

    def test_bearer_parser_preserves_established_case_and_spacing(self) -> None:
        self.assertEqual(extract_bearer_token("Bearer abc"), "abc")
        self.assertEqual(extract_bearer_token(" bearer   abc  "), "abc")
        self.assertEqual(extract_bearer_token("BEARER a.b-c_d"), "a.b-c_d")

    def test_bearer_parser_does_not_accept_other_schemes_or_missing_value(self) -> None:
        for value in ("", "Bearer", "Basic abc", "Token abc", None):
            self.assertEqual(extract_bearer_token(value), "", value)
        with self.assertRaises(RuntimeError):
            extract_bearer_token(BrokenString())

    def test_admin_cookie_parser_is_exact_and_keeps_embedded_equals(self) -> None:
        self.assertEqual(
            extract_admin_session_cookie("theme=dark; adzaagt_admin_session=a=b=c; other=1"),
            "a=b=c",
        )
        self.assertEqual(
            extract_admin_session_cookie("adzaagt_admin_session=first; adzaagt_admin_session=second"),
            "first",
        )
        for value in ("", "ADZAAGT_ADMIN_SESSION=x", "broken", None, BrokenString()):
            self.assertEqual(extract_admin_session_cookie(value), "", value)


if __name__ == "__main__":
    unittest.main(verbosity=2)
