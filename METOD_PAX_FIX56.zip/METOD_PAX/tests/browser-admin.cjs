const { chromium } = require("playwright");
const fs = require("node:fs");
(async () => {
  const [url, widthText, output] = process.argv.slice(2);
  const browser = await chromium.launch({
    headless: true,
    args: ["--no-sandbox"],
  });
  const page = await browser.newPage({
    viewport: { width: Number(widthText), height: 1000 },
  });
  const report = { checks: [], errors: [] };
  page.on("pageerror", (e) => report.errors.push(e.message));
  page.on("console", (m) => {
    if (m.type() === "error") report.errors.push(m.text());
  });
  const clickNav = async (name) => {
    await page.locator(`.adminNavBtn[data-section="${name}"]`).click();
    await page.locator(`#adminSection-${name}`).waitFor({ state: "visible" });
  };
  try {
    await page.goto(url + "/admin/", { waitUntil: "domcontentloaded" });
    await page.locator("#user").fill("admin");
    await page.locator("#pass").fill("synthetic-test-password-only");
    await page.locator("#otp").fill("000000");
    await page.locator("#btn").click();
    await page.locator(".adminNavBtn").first().waitFor();
    report.checks.push("login-form");
    // On mobile the list and request detail are separate screens.
    await page.locator("[data-request]").first().click();
    await page.locator("[data-customer-company]").waitFor();
    const details = await page.locator(".inbox-customer-details").innerText();
    for (const value of [
      "Voorbeeld BV",
      "Teststraat 12",
      "Teststad",
      "Nederland",
      "Kerkstraat 8",
      "Antwerpen",
      "België",
      "Afwijkend bezorgadres",
      "Maat 60/80?",
      "9:00",
      "<svg",
    ])
      if (!details.includes(value))
        throw new Error("Admin misses customer detail: " + value);
    if (await page.locator("[data-audit-injection]").count())
      throw new Error("Customer note injected an element");
    report.checks.push("billing-shipping-company-note-visible-and-escaped");
    await page.screenshot({ path: output.replace(".json", "-request.png") });

    for (const name of [
      "inbox",
      "beheer",
      "materials",
      "pricing",
      "system",
      "jobs",
      "filters",
      "privacy",
    ]) {
      await clickNav(name);
      report.checks.push("section-" + name);
    }
    await clickNav("pricing");
    await page.locator("#priceCnc").fill("111.25");
    await page.locator('[data-admin-action="savePricing"]').click();
    await page.waitForFunction(() =>
      document
        .getElementById("pricingStatus")
        .textContent.toLowerCase()
        .includes("opgeslagen"),
    );
    await page.locator('[data-admin-action="reloadPricing"]').click();
    await page.waitForFunction(
      () => document.getElementById("priceCnc").value === "111.25",
    );
    report.checks.push("pricing-save-reload");
    await clickNav("beheer");
    await page.locator("#dxfNewCat").fill("Browser categorie");
    await page.locator("#dxfCreateCatBtn").click();
    await page.waitForFunction(
      () => document.getElementById("dxfCatSel").value === "Browser categorie",
    );
    report.checks.push("dxf-category");
    await clickNav("filters");
    await page.locator("#filterNewName").fill("Browser groep");
    await page.locator("#filterCreateForm button").click();
    await page.waitForFunction(() =>
      [...document.querySelectorAll("#filterGroupList input")].some(
        (input) => input.value === "Browser groep",
      ),
    );
    await page.locator("#filterReload").click();
    await page.waitForFunction(() =>
      [...document.querySelectorAll("#filterGroupList input")].some(
        (input) => input.value === "Browser groep",
      ),
    );
    report.checks.push("filter-create");
    await clickNav("privacy");
    await page.locator("#privacyEmail").fill("isolated@example.invalid");
    await page.locator("#privacySearch").click();
    await page.locator("#privacyActions").waitFor({ state: "visible" });
    const downloadEvent = page.waitForEvent("download");
    await page.locator("#privacyExport").click();
    const download = await downloadEvent;
    if (await download.failure()) throw new Error("Privacy export failed");
    await download.saveAs(output.replace(".json", "-customer-export.zip"));
    if (download.suggestedFilename() !== "klantgegevens.zip")
      throw new Error("Wrong customer-export filename");
    report.checks.push("privacy-customer-export");
    await page.locator(".privacyInternalExport summary").click();
    if (!(await page.locator("#privacyInternalExport").isDisabled()))
      throw new Error("Internal export lacks confirmation");
    await page.locator("#privacyInternalConfirm").check();
    const internalEvent = page.waitForEvent("download");
    await page.locator("#privacyInternalExport").click();
    const internal = await internalEvent;
    if (await internal.failure()) throw new Error("Internal export failed");
    if (internal.suggestedFilename() !== "INTERN-niet-doorsturen.zip")
      throw new Error("Internal export lacks warning filename");
    report.checks.push("privacy-internal-export-explicit-confirmation");
    await page.locator("#privacyConfirm").fill("VERWIJDEREN");
    await page.locator("#privacyDelete").click();
    await page.waitForFunction(() =>
      document
        .getElementById("privacyStatus")
        .textContent.includes("bestanden verwijderd"),
    );
    report.checks.push("privacy-delete");
    await page.locator("#adminLogoutBtn").click();
    await page.locator("#loginForm").waitFor();
    report.checks.push("logout");
    if (report.errors.length)
      throw new Error("Browser errors: " + report.errors.join("; "));
    report.status = "PASS";
  } catch (e) {
    report.status = "FAIL";
    report.failure = e.message;
    report.visible = await page.locator("body").innerText();
  }
  await page.screenshot({ path: output.replace(".json", ".png") });
  fs.writeFileSync(output, JSON.stringify(report, null, 2) + "\n");
  console.log(JSON.stringify(report));
  await browser.close();
  process.exitCode = report.status === "PASS" ? 0 : 1;
})().catch((e) => {
  console.error(e);
  process.exitCode = 2;
});
