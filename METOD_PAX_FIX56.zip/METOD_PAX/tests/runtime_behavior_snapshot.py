"""Observe catalog/pricing behavior in an isolated real application composition.

Run unchanged against the FIX54 baseline and the candidate. Only the clock port
and generated version filenames are normalized; prices, errors, order, file
contents, rollback behavior and validation remain observable.
"""
from __future__ import annotations
import argparse
import copy
from dataclasses import replace
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile


def snapshot(release: Path) -> dict:
    sys.path.insert(0, str(release / 'app'))
    sys.path.insert(0, str(release / 'tests'))
    os.environ['METOD_TEST_RELEASE'] = str(release)
    from server_fixture import seed_catalog_and_credentials

    with tempfile.TemporaryDirectory(prefix='metod-composition-comparison-') as temporary:
        root = Path(temporary)
        state = root / 'state'
        credentials = root / 'credentials.json'
        seed_catalog_and_credentials(state, credentials)
        os.environ.update(METOD_STATE_ROOT=str(state), DEV_MODE='1', APP_ENV='test',
                          METOD_HOST='127.0.0.1', PRODUCTION_HARDENING='0',
                          ADMIN_CREDENTIALS_FILE=str(credentials))
        from metod_app.runtime import application as app
        from metod_app.storage.catalog_publication import CatalogPublication, catalog_guard
        from metod_app.pricing.authority import canonical_pricing_sha256
        from safety_contracts import durable_write_json

        app._PRICING_RUNTIME._ports = replace(
            app._PRICING_RUNTIME._ports, utc_now_iso=lambda: '2026-09-27T00:00:00+00:00')
        result = {}
        original_catalog = json.loads(app.MATERIAL_LIBRARY_PATH.read_text())
        original_pricing = app._load_pricing_config()
        app.SYSTEM_DIR.mkdir(parents=True, exist_ok=True)

        def write_catalog(data):
            durable_write_json(app.MATERIAL_LIBRARY_PATH, data)
            app._invalidate_material_lookup_cache()
            app._invalidate_material_name_cache()

        def outcome(call):
            try:
                return {'value': call()}
            except Exception as error:
                return {'errorType': type(error).__name__, 'message': str(error).replace(str(root), '<STATE>')}

        # Names retain first-record precedence, candidate precedence and fallbacks.
        records = [None, {'articleNo': 'A', 'productName': 'Eiken'},
                   {'articleNo': 'A', 'productName': 'Second'},
                   {'articleNumber': 'B', 'materialDisplayName': 'Één decor'},
                   {'materialCode': 'C', 'materialName': 'Steen'}]
        write_catalog({'records': records})
        names = []
        for code in ['A', 'B', 'C', 'UNKNOWN', '']:
            for candidates in [[], [''], ['123'], ['1,5', ''], ['  Eigen naam  ', '123'], ['0', '42']]:
                names.append([code, candidates, app._best_material_name(code, *candidates)])
        result['names'] = {'cases': names, 'map': app._load_material_name_by_code(),
                           'labels': [app._material_label_for_filename(c, 18) for c in ['A', 'B', 'UNKNOWN', '']]}
        # Name cache stays stable until explicit invalidation, as in FIX54.
        durable_write_json(app.MATERIAL_LIBRARY_PATH, {'records': [{'articleNo': 'A', 'productName': 'Nieuw'}]})
        before = app._best_material_name('A')
        app._invalidate_material_name_cache()
        after = app._best_material_name('A')
        result['names']['invalidation'] = [before, after]
        result['names']['malformed'] = []
        for invalid in [[], {'records': []}, {'records': 'wrong'}, 'wrong']:
            write_catalog(invalid)
            result['names']['malformed'].append(outcome(app._load_material_name_by_code))

        write_catalog(original_catalog)
        first = app._material_lookup_snapshot()
        first_maps = {k: copy.deepcopy(v) for k, v in first.items() if k != 'signature'}
        same_object = first is app._material_lookup_snapshot()
        changed = copy.deepcopy(original_catalog)
        changed['records'][0]['publicMaterialId'] = 'decor_' + 'b' * 20
        durable_write_json(app.MATERIAL_LIBRARY_PATH, changed)
        second = app._material_lookup_snapshot()
        result['lookup'] = {'initial': first_maps, 'sameObjectForUnchangedFile': same_object,
                            'afterAtomicReplacement': {k: v for k, v in second.items() if k != 'signature'}}
        write_catalog({'records': 'not-a-list'})
        result['lookup']['invalid'] = outcome(app._material_lookup_snapshot)
        write_catalog(original_catalog)

        artifact = state / 'artifact.txt'
        artifact.write_bytes(b'AAAA')
        timestamp = artifact.stat().st_mtime_ns
        h1 = app._cached_sha256_file(artifact)
        h2 = app._cached_sha256_file(artifact)
        artifact.write_bytes(b'BBBB')
        os.utime(artifact, ns=(timestamp, timestamp))
        h3 = app._cached_sha256_file(artifact)
        result['hashCache'] = {'hashes': [h1, h2, h3],
                               'sameSizeSameMtimeMutationDetected': h3 == hashlib.sha256(b'BBBB').hexdigest()}
        artifact.unlink()
        result['hashCache']['missing'] = outcome(lambda: app._cached_sha256_file(artifact))

        # Actual catalog commit/rollback must invalidate name, lookup and HTTP caches.
        initial_name = app._best_material_name('HTTP-SMOKE-001')
        publication = {}
        for fail in [True, False]:
            response_cache = app._CATALOG_RUNTIME._ports.get_public_materials_response_cache()
            response_cache.update(mtimeNs=123, body=b'stale', etag='stale')
            modified = copy.deepcopy(original_catalog)
            modified['records'][0]['productName'] = 'Published decor'
            try:
                with catalog_guard(app._CATALOG_PUBLICATION_PORTS):
                    with CatalogPublication(app._CATALOG_PUBLICATION_PORTS, [app.MATERIAL_LIBRARY_PATH]):
                        durable_write_json(app.MATERIAL_LIBRARY_PATH, modified)
                        if fail:
                            raise RuntimeError('synthetic publication failure')
            except RuntimeError:
                pass
            publication['rollback' if fail else 'commit'] = {
                'name': app._best_material_name('HTTP-SMOKE-001'),
                'record': app._material_lookup_snapshot()['catalogByInternal']['HTTP-SMOKE-001'],
                'journalRemoved': not (app.SYSTEM_DIR / 'catalog_transaction').exists(),
                'responseCache': dict(response_cache)}
        publication['initialName'] = initial_name
        result['publication'] = publication
        write_catalog(original_catalog)

        names = ['pax 50.dxf', 'metod ladefront 60.dxf', 'metod deur 80.dxf',
                 'metod apothekerslade.dxf', 'vrije vorm.dxf', '  PAX  50.dxf', 'DEUR.dxf']
        result['dxf'] = {'classifications': [[n, app._classify_dxf_filename(n), app.classify_dxf_category(n)] for n in names]}
        app.DXF_LIBRARY_ROOT.mkdir(parents=True, exist_ok=True)
        for name in names[:5]:
            (app.DXF_LIBRARY_ROOT / name).write_text('synthetic:' + name)
        result['dxf']['moved'] = app.migrate_embedded_dxfs_on_startup()
        result['dxf']['movedAgain'] = app.migrate_embedded_dxfs_on_startup()
        (app.DXF_LIBRARY_ROOT / names[0]).write_text('duplicate')
        app.migrate_embedded_dxfs_to_categories()
        app.rebuild_embedded_dxfs_manifest()
        result['dxf']['manifest'] = json.loads(app.DXF_MANIFEST_PATH.read_text())
        result['dxf']['contents'] = {p.relative_to(app.DXF_LIBRARY_ROOT).as_posix(): p.read_text()
                                    for p in sorted(app.DXF_LIBRARY_ROOT.rglob('*.dxf'))}

        result['pricing'] = {'initial': original_pricing, 'normalization': []}
        for cfg in [None, {}, {'sellPricing': {'sheetPriceFactor': 3, 'cncCostPerSheet': '12.5'}}, original_pricing]:
            result['pricing']['normalization'].append(outcome(lambda cfg=cfg: app._normalize_pricing_config_schema(cfg)))
        revision = '"' + canonical_pricing_sha256(original_pricing) + '"'
        new_cfg = copy.deepcopy(original_pricing)
        new_cfg['sellPricing']['edgeBandPricePerM'] = 2.675
        saved = app._save_pricing_config(new_cfg, actor='synthetic-admin', expected_revision=revision)
        saved.pop('version')  # timestamp/random filename; file contents stay compared below
        active = app.PRICING_ACTIVE.read_bytes()
        result['pricing']['saved'] = saved
        result['pricing']['reloaded'] = app._load_pricing_config()
        result['pricing']['conflict'] = outcome(lambda: app._save_pricing_config(original_pricing, expected_revision=revision))
        result['pricing']['conflictPreservedBytes'] = active == app.PRICING_ACTIVE.read_bytes()
        result['pricing']['versions'] = [json.loads(p.read_text()) for p in sorted(app.PRICING_VERSIONS.glob('*.json'))]
        result['pricing']['signoff'] = json.loads((app.SYSTEM_DIR / 'catalog_signoff.json').read_text())
        audit = [json.loads(line) for line in app.PRICING_AUDIT.read_text().splitlines()]
        for row in audit:
            row.pop('version')
        result['pricing']['audit'] = audit
        result['pricing']['invalid'] = []
        for value in [0, -1, True, 'bad', None]:
            invalid = copy.deepcopy(new_cfg)
            invalid['sellPricing']['cncCostPerSheet'] = value
            result['pricing']['invalid'].append(outcome(lambda invalid=invalid: app._save_pricing_config(invalid)))
        result['pricing']['invalidPreservedBytes'] = active == app.PRICING_ACTIVE.read_bytes()

        quote = {'materials': [{'materialCode': 'A', 'sheetCount': 2, 'sellPriceInclVatPerSheet': 69.57}],
                 'edgeBanding': {'byCodeMetersWithLossExact': {'1': 1.005}}}
        quotes = []
        for count in [1, 2, 5]:
            for price in [0.01, 69.57, 140.24]:
                for fixed in [False, True]:
                    q = copy.deepcopy(quote)
                    q['materials'][0].update(sheetCount=count, sellPriceInclVatPerSheet=price)
                    quotes.append(app._apply_sell_pricing_to_quote(q, include_fixed_costs=fixed))
        result['quotes'] = quotes
        csv = 'PartId,PanelName,MaterialCode,ThicknessMm,WidthMm,LengthMm,Qty,GrainGroup,RotationAllowed,H1,H2,W1,W2\nP1,Test,HTTP-SMOKE-001,18,100,200,1,,false,0,0,0,0\n'
        result['authority'] = outcome(lambda: app._capture_public_job_pricing_authority(csv))
        return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--release', type=Path, required=True)
    print(json.dumps(snapshot(parser.parse_args().release.resolve()), sort_keys=True, ensure_ascii=False))
