/** Fault injection against the real cancellation UI and API on a running fixture. */
const assert = require("node:assert/strict");

module.exports = async function cancellationJourney(
  page,
  report,
  mode,
  output,
) {
  const submitted = mode === "cancel-request";
  if (submitted) {
    await page.locator("#sendConfigBtn").click();
    await page
      .locator(".submitThanksOverlay")
      .waitFor({ state: "visible", timeout: 20000 });
    // The normal thank-you buttons start a fresh configuration. Exercise the
    // retained-request cancellation component through its existing lifecycle
    // interface, with the real submitted request/capability still in memory.
    await page.evaluate(() => {
      document.addEventListener(
        "tool-a:foundation-ready",
        (event) => {
          event.detail.closeSubmissionThankYou();
          if (!event.detail.openCheckoutReview({ state: window.state }))
            throw new Error("Submitted checkout review could not reopen");
        },
        { once: true },
      );
      document.dispatchEvent(new Event("tool-a:foundation-request"));
      window.__metodSetCancelConfigAvailable(true);
    });
    report.requestContextSetup =
      "Real UI submission; existing foundation lifecycle reopens cancellation component without reset";
  }
  const endpoint = submitted ? "/api/cancel" : "/api/jobs/cancel";
  const pattern = "**" + endpoint;
  const refs = await page.evaluate(() => ({
    jobId:
      window.__metod_last_parent_job_id ||
      window.__metod_last_job_id ||
      window.state.lastParentJobId,
    requestId: window.__metod_last_request_id,
  }));
  const confirmation = submitted
    ? {
        ok: true,
        requestId: refs.requestId,
        cancelled: true,
        idempotent: false,
      }
    : { ok: true, jobId: refs.jobId, state: "cancelled" };
  assert(submitted ? refs.requestId : refs.jobId);
  const configuration = () =>
    page.evaluate(() => ({
      cart: window.state.cart,
      extraPanels: window.state.extraPanels,
      batches: window.state.materialBatches,
      material: window.state.material,
      activeMaterialKey: window.state.activeMaterialKey,
      grain: window.state.grain,
      customer: window.state.customer,
      checkout: window.state.checkout,
      lastCalculatedCustomer: window.state.lastCalculatedCustomer,
      job: window.state.lastParentJobId,
      jobToken: window.state.lastJobAccessToken,
      refs: [
        "__metod_last_parent_job_id",
        "__metod_last_job_id",
        "__metod_last_job_access_token",
        "__metod_last_request_id",
        "__metod_last_request_cancel_token",
      ].map((key) => [key, window[key]]),
      recovery: [
        "metod_pending_job_start_v1",
        "metod_running_job_v1",
        "metod_last_request_id",
        "metod_last_request_cancel_token",
        "metod_last_parent_job_id",
        "metod_last_job_access_token",
      ].map((key) => [
        key,
        sessionStorage.getItem(key),
        localStorage.getItem(key),
      ]),
      inputs: [
        ...document.querySelectorAll(
          "#stepCustomer input, #stepCustomer textarea",
        ),
      ].map((input) => [input.id, input.value, input.checked]),
    }));
  const original = await configuration();
  report.frozenCustomerSnapshot = await page.evaluate(
    () =>
      Object.isFrozen(window.state.customer) ||
      Object.isFrozen(window.state.checkout.customer),
  );
  assert.equal(report.frozenCustomerSnapshot, true);
  assert(original.grain.groups.some((g) => g.items.length === 2));
  await page.locator("#cancelConfigBtn").click();
  await page.locator("#cancelRequestKeepBtn").click();
  await page.locator("#cancelRequestOverlay").waitFor({ state: "hidden" });
  assert.deepEqual(await configuration(), original);
  await page.locator("#cancelConfigBtn").click();

  const marker = "TECHNICAL_CANCELLATION_MARKER";
  const scenarios = [
    { name: "json-500-error", status: 500, body: { error: marker } },
    { name: "json-500-message", status: 500, body: { message: marker } },
    { name: "500-deceptive-confirmation", status: 500, body: confirmation },
    {
      name: "502-proxy-html",
      status: 502,
      body: `<html>${marker}</html>`,
      type: "text/html",
    },
    { name: "503-plain-text", status: 503, body: marker, type: "text/plain" },
    { name: "200-empty", status: 200, body: "" },
    { name: "200-invalid-json", status: 200, body: "{" + marker },
    {
      name: "200-proxy-html",
      status: 200,
      body: `<html>${marker}</html>`,
      type: "text/html",
    },
    { name: "200-json-null", status: 200, body: "null" },
    { name: "200-missing-identity", status: 200, body: { ok: true } },
    {
      name: "200-wrong-identity",
      status: 200,
      body: {
        ...confirmation,
        [submitted ? "requestId" : "jobId"]: "WRONG_ID",
      },
    },
    {
      name: "200-explicit-failure",
      status: 200,
      body: { ...confirmation, ok: false },
    },
    { name: "403-invalid-capability", status: 403, body: { error: marker } },
    { name: "network-rejection", abort: true },
  ];
  report.cancellationCases = [];
  async function verifyFailure(
    name,
    expected = "Annuleren kon niet worden bevestigd.",
  ) {
    await page
      .locator("#toolAlertDirectOkBtn")
      .waitFor({ state: "visible", timeout: 25000 });
    assert.equal(await page.locator("#toolAlertDirectBody").innerText(), expected);
    assert.equal(
      await page.locator("#toolAlertDirectDetails").innerText(),
      "Je gegevens zijn behouden. Probeer het opnieuw.",
    );
    assert.equal(
      await page.locator("#saveStatus").textContent(),
      expected + " Je gegevens zijn behouden. Probeer het opnieuw.",
    );
    assert(!(await page.locator("body").innerText()).includes(marker));
    assert.deepEqual(
      await configuration(),
      original,
      name + ": configuration or recovery changed",
    );
    assert.equal(
      await page.locator("#cancelRequestConfirmBtn").isDisabled(),
      false,
    );
    report.cancellationCases.push(name);
    if (name === "502-proxy-html") {
      await page.screenshot({
        path: output.replace(".json", "-safe-error.png"),
      });
    }
    await page.locator("#toolAlertDirectOkBtn").click();
  }
  for (const scenario of scenarios) {
    let calls = 0;
    await page.route(pattern, (route) => {
      calls++;
      if (scenario.abort) return route.abort("failed");
      return route.fulfill({
        status: scenario.status,
        contentType: scenario.type || "application/json",
        body:
          typeof scenario.body === "string"
            ? scenario.body
            : JSON.stringify(scenario.body),
      });
    });
    await page.locator("#cancelRequestConfirmBtn").click();
    await verifyFailure(scenario.name);
    assert.equal(calls, 1);
    await page.unroute(pattern);
  }
  if (submitted) {
    const cancelToken = await page.evaluate(
      () => window.__metod_last_request_cancel_token,
    );
    await page.evaluate(() => {
      window.__metod_last_request_cancel_token = "";
    });
    const withoutToken = await configuration();
    await page.locator("#cancelRequestConfirmBtn").click();
    await page.locator("#toolAlertDirectOkBtn").waitFor();
    assert.equal(
      await page.locator("#toolAlertDirectBody").innerText(),
      "De beveiligde annuleercode ontbreekt. De aanvraag is niet gewist.",
    );
    assert.deepEqual(await configuration(), withoutToken);
    await page.locator("#toolAlertDirectOkBtn").click();
    await page.evaluate((value) => {
      window.__metod_last_request_cancel_token = value;
    }, cancelToken);
    report.cancellationCases.push("missing-cancel-token");
  }
  // A resolved fetch with a body that never completes must still time out.
  // The production timeout is used unchanged (12 s request / 20 s job).
  await page.evaluate((endpoint) => {
    window.__testOriginalFetch = window.fetch;
    window.fetch = (...args) =>
      String(args[0]) === endpoint
        ? Promise.resolve(
            new Response(new ReadableStream({ start() {} }), { status: 200 }),
          )
        : window.__testOriginalFetch(...args);
  }, endpoint);
  await page.locator("#cancelRequestConfirmBtn").click();
  await verifyFailure(
    "stalled-response-body",
    "De server reageerde niet op tijd om de annulering te bevestigen.",
  );
  await page.evaluate(() => {
    window.fetch = window.__testOriginalFetch;
    delete window.__testOriginalFetch;
  });
  report.checks.push(
    "both-message-surfaces-safe-and-deep-state-preserved-for-every-failure",
  );

  // Confirm on the real backend. After a submitted request is durably
  // cancelled, failure of best-effort job cleanup may not undo that result.
  if (submitted) {
    await page.route("**/api/jobs/cancel", (route) =>
      route.fulfill({
        status: 503,
        contentType: "application/json",
        body: JSON.stringify({ error: marker }),
      }),
    );
  }
  let resetDraftCalls = 0;
  await page.route("**/api/draft/save", (route) => {
    resetDraftCalls++;
    return route.abort("failed");
  });
  let actualRequestReply = null;
  if (submitted)
    page.on("response", async (r) => {
      if (new URL(r.url()).pathname === "/api/cancel" && r.status() === 200)
        actualRequestReply = await r.json();
    });
  await page.locator("#cancelRequestConfirmBtn").click();
  await page.waitForURL(/_freshConfig=/);
  await page.locator(".decorCard").first().waitFor();
  assert.equal(await page.evaluate(() => window.state.cart.length), 0);
  assert.equal(
    await page.evaluate(() => window.state.materialBatches.length),
    0,
  );
  assert.equal(await page.locator("#custEmail").inputValue(), "");
  assert.equal(
    await page.evaluate(() => document.body.dataset.uiStep),
    "material",
  );
  assert.equal(
    resetDraftCalls,
    0,
    "Local reset must not depend on disabled server draft persistence",
  );
  if (submitted) {
    assert.equal(actualRequestReply?.cancelled, true);
    assert.equal(actualRequestReply?.requestId, refs.requestId);
  } else {
    assert(
      report.responses.some((r) => r.path === endpoint && r.status === 409),
    );
  }
  report.checks.push(
    submitted
      ? "confirmed-request-cancellation-survives-job-cleanup-failure"
      : "real-terminal-409-remains-supported",
  );
  report.checks.push(
    "valid-retry-clears-frozen-snapshots-and-reloads-material-step",
  );
};
