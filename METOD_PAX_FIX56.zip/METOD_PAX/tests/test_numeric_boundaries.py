"""Independent financial and geometric invariants at rounding and fit boundaries."""

import copy
import itertools
import random
import sys
from types import SimpleNamespace
import unittest

from server_fixture import ROOT

sys.path.insert(0, str(ROOT / "app"))
from metod_app.optimizer.packing import _maxrects_pack_k
from metod_app.pricing.amounts import money
from metod_app.pricing.quote import price_quote


def item(name, width, height, *, rotate=False, count=1, gap=0):
    members = [
        SimpleNamespace(
            row=SimpleNamespace(
                PartId=f"{name}-{n}",
                WidthMm=width,
                LengthMm=height,
                MaterialCode="TEST",
                ThicknessMm=18,
                H1=1,
                H2=0,
                W1=0,
                W2=1,
            ),
            idx=1,
            w=width,
            h=height,
        )
        for n in range(count)
    ]
    total_height = height * count + gap * (count - 1)
    return dict(
        kind="group" if count > 1 else "single",
        members=members,
        w=width,
        h=total_height,
        area=width * total_height,
        mn=min(width, total_height),
        mx=max(width, total_height),
        micro_flag=int(max(width, total_height) < 400),
        rot_allowed=rotate,
    )


def pack(items, width, height, margin, gap, sheets):
    return _maxrects_pack_k(items, width, height, margin, gap, sheets, {"warnings": [], "errors": []})


class PackingBoundaryTests(unittest.TestCase):
    def assert_valid(self, placements, items, width, height, margin, gap, sheets):
        self.assertIsNotNone(placements)
        expected = {m.row.PartId: entry for entry in items for m in entry["members"]}
        self.assertCountEqual([p.partId for p in placements], expected)
        boxes = []
        for p in placements:
            self.assertIn(p.rotationDeg, (0, 90))
            if not expected[p.partId]["rot_allowed"]:
                self.assertEqual(p.rotationDeg, 0)
            self.assertTrue(1 <= p.sheetIndex <= sheets)
            w, h = (p.widthMm, p.lengthMm) if p.rotationDeg == 0 else (p.lengthMm, p.widthMm)
            self.assertGreaterEqual(p.x, margin - 0.051)
            self.assertGreaterEqual(p.y, margin - 0.051)
            self.assertLessEqual(p.x + w, width - margin + 0.051)
            self.assertLessEqual(p.y + h, height - margin + 0.051)
            boxes.append((p.sheetIndex, p.x, p.y, w, h))
        for a, b in itertools.combinations(boxes, 2):
            if a[0] != b[0]:
                continue
            self.assertTrue(
                a[1] + a[3] + gap <= b[1] + 0.101
                or b[1] + b[3] + gap <= a[1] + 0.101
                or a[2] + a[4] + gap <= b[2] + 0.101
                or b[2] + b[4] + gap <= a[2] + 0.101,
                f"Parts overlap or violate their gap: {a}, {b}",
            )

    def test_exact_usable_sheet_and_oversize(self):
        pieces = [item("full", 987, 1987)]
        self.assert_valid(pack(pieces, 1000, 2000, 6.5, 13, 1), pieces, 1000, 2000, 6.5, 13, 1)
        self.assertIsNone(pack([item("too-wide", 987.1, 1987)], 1000, 2000, 6.5, 13, 1))

    def test_rotation_is_used_only_when_allowed(self):
        for allowed in (False, True):
            pieces = [item("rot", 300, 900, rotate=allowed)]
            result = pack(pieces, 1000, 600, 10, 3.2, 1)
            if allowed:
                self.assert_valid(result, pieces, 1000, 600, 10, 3.2, 1)
                self.assertEqual(result[0].rotationDeg, 90)
            else:
                self.assertIsNone(result)

    def test_exact_gap_and_sheet_limit(self):
        for gap in (0, 3.2, 13):
            with self.subTest(gap=gap):
                width = (980 - gap) / 2
                pieces = [item("a", width, 130), item("b", width, 130)]
                self.assert_valid(pack(pieces, 1000, 150, 10, gap, 1), pieces, 1000, 150, 10, gap, 1)
                larger = [item("a", width + 0.2, 130), item("b", width, 130)]
                self.assertIsNone(pack(larger, 1000, 150, 10, gap, 1))
                self.assert_valid(pack(larger, 1000, 150, 10, gap, 2), larger, 1000, 150, 10, gap, 2)

    def test_grain_group_preserves_order_column_and_gaps(self):
        pieces = [item("grain", 197, 397, count=3, gap=13), item("other", 197, 197)]
        result = pack(pieces, 610, 1500, 7, 13, 1)
        self.assert_valid(result, pieces, 610, 1500, 7, 13, 1)
        group = sorted((p for p in result if p.partId.startswith("grain")), key=lambda p: p.partId)
        self.assertEqual(len({(p.sheetIndex, p.x) for p in group}), 1)
        self.assertEqual([round(group[n + 1].y - group[n].y, 1) for n in range(2)], [410.0, 410.0])

    def test_seeded_mixed_sizes_preserve_identity_bounds_gap_and_rotation(self):
        rng = random.Random(5301)
        for case in range(60):
            with self.subTest(case=case):
                margin, gap = rng.choice([0, 6.5, 10]), rng.choice([0, 3.2, 13])
                pieces = [
                    item(
                        str(n),
                        rng.choice([12.5, 80, 197, 597, 987]),
                        rng.choice([97, 397, 797, 1197]),
                        rotate=bool(rng.randrange(2)),
                    )
                    for n in range(2 + case % 9)
                ]
                before = copy.deepcopy(pieces)
                self.assert_valid(
                    pack(pieces, 1200, 2000, margin, gap, len(pieces)),
                    pieces,
                    1200,
                    2000,
                    margin,
                    gap,
                    len(pieces),
                )
                self.assertEqual(pieces, before)


class PricingBoundaryTests(unittest.TestCase):
    def setUp(self):
        self.quote = {
            "materials": [
                {"materialCode": "A", "sheetCount": 2, "sellPriceInclVatPerSheet": 69.57},
                {"materialCode": "B", "sheetCount": 3, "sellPriceInclVatPerSheet": 0.01},
            ],
            "edgeBanding": {"byCodeMetersWithLossExact": {"1": 1.005}, "byCodeMetersWithLoss": {"1": 1}},
        }
        self.settings = dict(
            edgeBandPricePerM=1, cncCostPerSheet=2.005, drawingCostFixed=0.005, transportCostFixed=0.005
        )

    def test_half_cents_and_exact_edge_measurement(self):
        for value, expected in [("1.005", 1.01), ("2.675", 2.68), ("0.005", 0.01), ("-0.005", -0.01)]:
            self.assertEqual(money(value), expected)
        before = copy.deepcopy(self.quote)
        priced = price_quote(self.quote, sell_pricing=self.settings, vat_rate=0.21)
        totals = priced["totals"]
        for key, expected in dict(
            sheetCostTotalInclVat=139.17,
            sheetCostTotalExVat=115.01,
            edgeCostTotal=1.01,
            cncCostTotal=10.03,
            drawingCostTotal=0.01,
            transportCostTotal=0.01,
            otherCostsVat=2.32,
            subtotalExVat=126.07,
            vatAmount=26.48,
            totalInclVat=152.55,
        ).items():
            self.assertEqual(totals[key], expected, key)
        self.assertEqual(self.quote, before)

    def test_fixed_costs_can_be_excluded_without_changing_materials(self):
        q = price_quote(self.quote, sell_pricing=self.settings, vat_rate=0.21, include_fixed_costs=False)
        self.assertEqual(q["totals"]["sheetCostTotalInclVat"], 139.17)
        self.assertEqual(q["totals"]["totalInclVat"], 152.53)
        self.assertEqual(q["totals"]["drawingCostTotal"], 0)
        self.assertEqual(q["totals"]["transportCostTotal"], 0)

    def test_invalid_prices_counts_and_vat_do_not_become_a_quote(self):
        for field, values in {
            "sellPriceInclVatPerSheet": [True, 0, -0.01, 0.001, float("nan"), float("inf"), "69.57"],
            "sheetCount": [True, 0, -1, 1.5, float("nan"), float("inf"), "2"],
        }.items():
            for value in values:
                with self.subTest(field=field, value=value), self.assertRaises(ValueError):
                    quote = copy.deepcopy(self.quote)
                    quote["materials"][0][field] = value
                    price_quote(quote, sell_pricing=self.settings, vat_rate=0.21)
        for rate in (True, -0.01, 1.01, float("nan"), float("inf"), ".21"):
            with self.subTest(rate=rate), self.assertRaises(ValueError):
                price_quote(self.quote, sell_pricing=self.settings, vat_rate=rate)

    def test_missing_material_price_is_rejected(self):
        for field in ["sellPriceInclVatPerSheet", "sellPriceExVatPerSheet", "sheetUnitCost"]:
            self.quote["materials"][0].pop(field, None)
        with self.assertRaises(ValueError):
            price_quote(self.quote, sell_pricing=self.settings, vat_rate=0.21)
