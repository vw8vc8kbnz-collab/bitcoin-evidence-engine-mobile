"""Real flock/descriptor checks in temporary paths; never deploy or touch live state."""

import os
from pathlib import Path
import subprocess
import shutil
import tempfile
import unittest

from server_fixture import ROOT


class DeployLockTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.prefix = []
        if os.geteuid() != 0:
            if (
                not shutil.which("sudo")
                or subprocess.run(["sudo", "-n", "true"], capture_output=True, timeout=5).returncode
            ):
                raise unittest.SkipTest(
                    "Deploy-lock tests need root or passwordless sudo on the test machine"
                )
            cls.prefix = ["sudo", "-n"]

    def run_shell(self, body, directory):
        script = (
            """set -Eeuo pipefail
fail(){ echo "$*" >&2; exit 37; }
source "$1"
DEPLOY_LOCK_PATH="$2/lock"
"""
            + body
        )
        environment = {k: v for k, v in os.environ.items() if not k.startswith("METOD_DEPLOY_LOCK_")}
        return subprocess.run(
            self.prefix + ["bash", "-c", script, "test", str(ROOT / "ops/deploy_lock.sh"), directory],
            env=environment,
            capture_output=True,
            text=True,
            timeout=10,
        )

    def test_inherited_descriptor_remains_locked_and_competitor_is_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            result = self.run_shell(
                """
acquire_or_inherit_deploy_lock
bash -c 'set -Eeuo pipefail; fail(){ exit 37; }; source "$1"; DEPLOY_LOCK_PATH="$2/lock"; require_inherited_deploy_lock' test "$1" "$2"
if env -u METOD_DEPLOY_LOCK_FD -u METOD_DEPLOY_LOCK_CONTRACT bash -c 'set -Eeuo pipefail; fail(){ exit 37; }; source "$1"; DEPLOY_LOCK_PATH="$2/lock"; acquire_or_inherit_deploy_lock' test "$1" "$2"; then
  exit 9
fi
validate_deploy_lock_fd "$DEPLOY_LOCK_FD"
""",
                folder,
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual((Path(folder) / "lock").stat().st_mode & 0o777, 0o600)

    def test_missing_partial_and_wrong_descriptors_fail(self):
        for setup in [
            "",
            "export METOD_DEPLOY_LOCK_CONTRACT=v1",
            "export METOD_DEPLOY_LOCK_CONTRACT=v1 METOD_DEPLOY_LOCK_FD=9",
            "export METOD_DEPLOY_LOCK_CONTRACT=v1 METOD_DEPLOY_LOCK_FD=1234",
            "export METOD_DEPLOY_LOCK_CONTRACT=unknown METOD_DEPLOY_LOCK_FD=10",
        ]:
            with self.subTest(setup=setup), tempfile.TemporaryDirectory() as folder:
                result = self.run_shell(setup + "\nrequire_inherited_deploy_lock\n", folder)
                self.assertEqual(result.returncode, 37, result.stderr)

    def test_replaced_inode_hardlink_and_unsafe_mode_fail(self):
        for alteration in [
            'mv "$DEPLOY_LOCK_PATH" "$2/old"; touch "$DEPLOY_LOCK_PATH"; chmod 600 "$DEPLOY_LOCK_PATH"',
            'ln "$DEPLOY_LOCK_PATH" "$2/alias"',
            'chmod 644 "$DEPLOY_LOCK_PATH"',
        ]:
            with self.subTest(alteration=alteration), tempfile.TemporaryDirectory() as folder:
                result = self.run_shell(
                    "acquire_deploy_lock\n" + alteration + '\nvalidate_deploy_lock_fd "$DEPLOY_LOCK_FD"\n',
                    folder,
                )
                self.assertEqual(result.returncode, 37, result.stderr)
