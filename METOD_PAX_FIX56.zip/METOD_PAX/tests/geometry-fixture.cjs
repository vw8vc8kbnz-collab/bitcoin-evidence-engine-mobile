const esbuild = require("esbuild");
const vm = require("vm");
exports.loadGeometryOwners = (context, app) => {
  const entry = `import {mount, ToolATemplateViewHelpers} from './tool-a/domain/template-view-helpers.js';
    import {createDxfExport} from './tool-a/runtime/modules/dxf-export.js';
    import {createTemplateExport} from './tool-a/runtime/modules/template-export.js';
    mount();
    const dxfExport=createDxfExport();
    const templateExport=createTemplateExport({applicationState:{current:state},dxfExport,priceBar:{},templateCatalog:{}});
    templateExport.initialize();
    globalThis.geometryOwners={helper:ToolATemplateViewHelpers,dxfExport,templateExport};`;
  const compiled = esbuild.buildSync({
    stdin: { contents: entry, resolveDir: app },
    bundle: true,
    format: "iife",
    write: false,
  });
  vm.runInContext(compiled.outputFiles[0].text, context);
  return context.geometryOwners;
};
