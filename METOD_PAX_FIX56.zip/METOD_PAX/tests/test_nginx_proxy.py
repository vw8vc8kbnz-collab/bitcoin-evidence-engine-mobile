"""Run the deployment's exact nginx fragments against a real isolated server."""

import gzip
import os
import socket
import re
import subprocess
import time
import unittest
from urllib.request import ProxyHandler, Request, build_opener
from server_fixture import ROOT, TestServer, reserve_loopback_port


@unittest.skipUnless(os.environ.get("METOD_TEST_NGINX"), "Set METOD_TEST_NGINX for real reverse-proxy checks")
class NginxTests(unittest.TestCase):
    def test_exact_deployment_fragments_compress_only_immutable_public_assets(self):
        with TestServer(secure=True) as server:
            script = (ROOT / "DEPLOY.sh").read_text()

            def fragment(name):
                return re.search(rf"{name}\(\)\{{\ncat <<'EOF'\n(.*?)\nEOF", script, re.S).group(1)

            limits = (
                re.search(r"limit_req_zone \$binary_remote_addr zone=metod_general:.*?\nEOF", script, re.S)
                .group(0)
                .removesuffix("\nEOF")
            )
            proxy = fragment("proxy_locations").replace("127.0.0.1:8792", f"127.0.0.1:{server.port}")
            proxy = proxy.replace("/var/log/nginx/metod-pax/", str(server.root) + "/")
            port = reserve_loopback_port()
            config = server.root / "nginx.conf"
            config.write_text(f"""user root root;
daemon off;
master_process off;
pid {server.root}/nginx.pid;
error_log {server.root}/nginx-error.log;
events {{ worker_connections 256; }}
http {{
client_body_temp_path {server.root}/body;
proxy_temp_path {server.root}/proxy;
fastcgi_temp_path {server.root}/fastcgi;
uwsgi_temp_path {server.root}/uwsgi;
scgi_temp_path {server.root}/scgi;
{limits}
server {{ listen 127.0.0.1:{port}; server_name localhost;
{fragment("nginx_server_hardening")}
{proxy}
}}
}}
""")
            command = [os.environ["METOD_TEST_NGINX"], "-p", str(server.root), "-c", str(config)]
            check = subprocess.run(command + ["-t"], capture_output=True, text=True)
            self.assertEqual(check.returncode, 0, check.stderr)
            log = (server.root / "nginx-process.log").open("wb")
            process = subprocess.Popen(command, stdout=log, stderr=log)
            opener = build_opener(ProxyHandler({}))

            def request(path):
                return opener.open(
                    Request(f"http://127.0.0.1:{port}" + path, headers={"Accept-Encoding": "gzip"}), timeout=5
                )

            try:
                for _ in range(50):
                    try:
                        with request("/health/live") as response:
                            response.read()
                        break
                    except OSError:
                        time.sleep(0.05)
                import json

                manifest = json.loads((ROOT / "app/tool-a/asset-manifest.json").read_text())
                for asset in manifest["assets"].values():
                    with request("/" + asset["path"]) as response:
                        self.assertEqual(response.headers["Content-Encoding"], "gzip")
                        self.assertIn("immutable", response.headers["Cache-Control"])
                        self.assertEqual(
                            gzip.decompress(response.read()), (ROOT / "app" / asset["path"]).read_bytes()
                        )
                for path in ("/", "/health/live"):
                    with request(path) as response:
                        self.assertIsNone(response.headers.get("Content-Encoding"))
                # More incomplete requests than the backend connection budget:
                # buffering at nginx must keep these away from Waitress.
                connections = []
                try:
                    for _ in range(140):
                        connection = socket.create_connection(("127.0.0.1", port), timeout=3)
                        connection.sendall(b"GET / HTTP/1.1\r\nHost: localhost\r\n")
                        connections.append(connection)
                    started = time.monotonic()
                    with request("/health/live") as response:
                        self.assertEqual(response.status, 200)
                    self.assertLess(time.monotonic() - started, 3)
                finally:
                    for connection in connections:
                        connection.close()

            finally:
                process.terminate()
                process.wait(timeout=10)
                log.close()
