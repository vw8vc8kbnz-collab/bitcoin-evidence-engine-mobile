#!/usr/bin/env bash
set -Eeuo pipefail
export PATH=/usr/sbin:/usr/bin:/sbin:/bin
export PYTHONDONTWRITEBYTECODE=1
export PYTHONSAFEPATH=1 PYTHONNOUSERSITE=1
unset PYTHONPATH PYTHONHOME

STAGE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STATE_DIR="${METOD_STATE_ROOT:-/var/lib/metod-pax}"
ENV_DIR="${METOD_ENV_DIR:-/etc/adzaagt/metod-pax}"
CREDS_FILE="${ADMIN_CREDENTIALS_FILE:-$ENV_DIR/admin_credentials.live.json}"
CURRENT_LINK="${METOD_CURRENT_LINK:-/opt/adzaagt/metod-pax-current}"
OUTPUT="${1:-}"
WAS_ACTIVE=0
NGINX_WAS_ACTIVE=0
TEMP_ROOT=""
OUTPUT_TMP=""
SIDECAR_TMP=""

fail(){ echo "[METOD-PAX-MIGRATION] FOUT: $*" >&2; exit 1; }

source "$STAGE/ops/deploy_lock.sh"


wait_backend_healthy(){
  local attempt
  for ((attempt=0; attempt<90; attempt++)); do
    if systemctl is-active --quiet metod-pax.service \
       && curl -fsS --connect-timeout 2 --max-time 5 http://127.0.0.1:8792/health/live >/dev/null \
       && curl -fsS --connect-timeout 2 --max-time 5 http://127.0.0.1:8792/health/ready >/dev/null; then
      return 0
    fi
    sleep 1
  done
  return 1
}

resume_backend(){
  [[ "$WAS_ACTIVE" -eq 1 ]] || return 0
  systemctl start metod-pax.service || return 1
  wait_backend_healthy || return 1
  WAS_ACTIVE=0
}

resume_nginx(){
  [[ "$NGINX_WAS_ACTIVE" -eq 1 ]] || return 0
  # Fail closed: ingress wordt pas heropend nadat de oorspronkelijk actieve
  # backend aantoonbaar live én ready is.
  [[ "$WAS_ACTIVE" -eq 0 ]] || return 1
  nginx -t || return 1
  systemctl start nginx || return 1
  systemctl is-active --quiet nginx || return 1
  NGINX_WAS_ACTIVE=0
}

cleanup(){
  local rc=$?
  set +e
  unset MIGRATION_PASSPHRASE MIGRATION_PASSPHRASE_REPEAT
  if ! resume_backend; then
    echo "[METOD-PAX-MIGRATION] KRITIEK: service kon na export niet gezond worden hervat" >&2
    rc=1
  fi
  if ! resume_nginx; then
    echo "[METOD-PAX-MIGRATION] KRITIEK: Nginx blijft fail-closed omdat runtimeherstel niet is bewezen" >&2
    rc=1
  fi
  if [[ -n "$TEMP_ROOT" && -d "$TEMP_ROOT" ]]; then
    [[ "$TEMP_ROOT" == /var/tmp/metod-pax-migration.* ]] || { echo "Onverwacht tijdelijk pad; niet verwijderd: $TEMP_ROOT" >&2; return "$rc"; }
    rm -rf -- "$TEMP_ROOT" || { echo "Tijdelijke migratiemap kon niet volledig worden verwijderd: $TEMP_ROOT" >&2; rc=1; }
  fi
  [[ -z "$OUTPUT_TMP" || ! -e "$OUTPUT_TMP" ]] || rm -f -- "$OUTPUT_TMP" || rc=1
  [[ -z "$SIDECAR_TMP" || ! -e "$SIDECAR_TMP" ]] || rm -f -- "$SIDECAR_TMP" || rc=1
  return "$rc"
}
trap cleanup EXIT

[[ -n "$OUTPUT" && "$OUTPUT" == /* && "$OUTPUT" =~ ^/[A-Za-z0-9._/-]+\.gpg$ ]] || fail "Geef één veilig absoluut .gpg-uitvoerpad"
[[ ! -e "$OUTPUT" && ! -L "$OUTPUT" ]] || fail "Uitvoer bestaat al: $OUTPUT"
[[ ! -e "$OUTPUT.sha256" && ! -L "$OUTPUT.sha256" ]] || fail "Uitvoer-sidecar bestaat al: $OUTPUT.sha256"
[[ -d "$(dirname "$OUTPUT")" && ! -L "$(dirname "$OUTPUT")" ]] || fail "Uitvoermap ontbreekt of is een symlink"
if [[ "$EUID" -ne 0 ]]; then
  FORWARD=(PYTHONDONTWRITEBYTECODE=1 METOD_STATE_ROOT="$STATE_DIR" METOD_ENV_DIR="$ENV_DIR" \
    ADMIN_CREDENTIALS_FILE="$CREDS_FILE" METOD_CURRENT_LINK="$CURRENT_LINK")
  [[ -v METOD_MIGRATION_DRAIN_TIMEOUT_SECONDS ]] \
    && FORWARD+=("METOD_MIGRATION_DRAIN_TIMEOUT_SECONDS=$METOD_MIGRATION_DRAIN_TIMEOUT_SECONDS")
  exec sudo env "${FORWARD[@]}" bash "$0" "$OUTPUT"
fi
for command in python3 rsync tar gpg sha256sum systemctl mktemp awk id flock stat readlink curl nginx; do
  command -v "$command" >/dev/null || fail "Ontbrekend commando: $command"
done
[[ -x /usr/bin/python3 ]] || fail "Vertrouwde interpreter /usr/bin/python3 ontbreekt"
/usr/bin/python3 -I -S -B - "$OUTPUT" <<'PY'
import os,stat,sys
from pathlib import Path
raw=sys.argv[1]
if raw.startswith('//') or raw!=os.path.normpath(raw):
    raise SystemExit('uitvoerpad moet lexicaal canoniek absoluut zijn')
parent=Path(raw).parent
if not parent.is_absolute() or str(parent).startswith('//') or Path(os.path.normpath(parent))!=parent:
    raise SystemExit('uitvoerparent moet canoniek absoluut zijn')
resolved=parent.resolve(strict=True)
if resolved!=parent:
    raise SystemExit('symlinkcomponent in uitvoerparent is verboden')
metadata=parent.lstat()
if not stat.S_ISDIR(metadata.st_mode):
    raise SystemExit('uitvoerparent is geen werkelijke directory')
PY

printf 'Kies een sterk wachtwoord voor het versleutelde migratiebestand: ' >/dev/tty
IFS= read -rs MIGRATION_PASSPHRASE </dev/tty
printf '\nHerhaal het wachtwoord: ' >/dev/tty
IFS= read -rs MIGRATION_PASSPHRASE_REPEAT </dev/tty
printf '\n' >/dev/tty
[[ ${#MIGRATION_PASSPHRASE} -ge 16 ]] || fail "Migratiewachtwoord moet minimaal 16 tekens zijn"
[[ "$MIGRATION_PASSPHRASE" == "$MIGRATION_PASSPHRASE_REPEAT" ]] || fail "Migratiewachtwoorden zijn niet gelijk"
unset MIGRATION_PASSPHRASE_REPEAT

acquire_or_inherit_deploy_lock

PYTHONDONTWRITEBYTECODE=1 /usr/bin/python3 -I -S -B "$STAGE/tools/install_state_gate.py" \
  --state-root "$STATE_DIR" --credentials "$CREDS_FILE"

SERVICE_LOAD_STATE="$(systemctl show metod-pax.service --property=LoadState --value)" \
  || fail "Service-load-state kon niet worden bepaald"
[[ "$SERVICE_LOAD_STATE" == "loaded" ]] || fail "METOD/PAX-service is niet geladen: $SERVICE_LOAD_STATE"
ACTIVE_STATE="$(systemctl show metod-pax.service --property=ActiveState --value)" \
  || fail "Service-active-state kon niet worden bepaald"
case "$ACTIVE_STATE" in
  active) WAS_ACTIVE=1 ;;
  inactive|failed) ;;
  *) fail "Service heeft geen stabiele snapshottoestand: $ACTIVE_STATE" ;;
esac

if [[ "$WAS_ACTIVE" -eq 1 ]]; then
  NGINX_LOAD_STATE="$(systemctl show nginx --property=LoadState --value)" \
    || fail "Nginx load-state kon niet worden bepaald"
  [[ "$NGINX_LOAD_STATE" == "loaded" ]] || fail "Nginx is niet geladen; ingressquiescence kan niet worden bewezen"
  NGINX_ACTIVE_STATE="$(systemctl show nginx --property=ActiveState --value)" \
    || fail "Nginx active-state kon niet worden bepaald"
  case "$NGINX_ACTIVE_STATE" in
    active)
      NGINX_WAS_ACTIVE=1
      systemctl stop nginx || fail "Nginx-ingress kon niet gecontroleerd worden gestopt"
      NGINX_ACTIVE_STATE="$(systemctl show nginx --property=ActiveState --value)" \
        || fail "Nginx active-state kon na stop niet worden bepaald"
      [[ "$NGINX_ACTIVE_STATE" =~ ^(inactive|failed)$ ]] \
        || fail "Nginx-ingress is niet aantoonbaar gestopt: $NGINX_ACTIVE_STATE"
      ;;
    inactive|failed) ;;
    *) fail "Nginx heeft geen stabiele snapshottoestand: $NGINX_ACTIVE_STATE" ;;
  esac

  MIGRATION_DRAIN_TIMEOUT="${METOD_MIGRATION_DRAIN_TIMEOUT_SECONDS:-900}"
  [[ "$MIGRATION_DRAIN_TIMEOUT" =~ ^[0-9]{1,4}$ ]] \
    || fail "METOD_MIGRATION_DRAIN_TIMEOUT_SECONDS moet een begrensd geheel getal zijn"
  (( 10#$MIGRATION_DRAIN_TIMEOUT >= 15 && 10#$MIGRATION_DRAIN_TIMEOUT <= 3600 )) \
    || fail "METOD_MIGRATION_DRAIN_TIMEOUT_SECONDS moet 15..3600 zijn"
  /usr/bin/python3 -I -S -B - "$STATE_DIR" "$MIGRATION_DRAIN_TIMEOUT" <<'PY'
import json,os,sys,time
from pathlib import Path
root=Path(sys.argv[1]); deadline=time.monotonic()+int(sys.argv[2])
active_states={'ACCEPTED','PREPARING','PROCESSING','FINALIZING','CANCEL_REQUESTED'}
quiet_polls=0
while True:
    active=invalid=entries=0
    jobs=root/'jobs'
    if jobs.is_dir():
        with os.scandir(jobs) as scan:
            for item in scan:
                entries += 1
                if entries > 1_000_000:
                    raise SystemExit('export-jobdrain overschrijdt de entrygrens')
                if not item.is_dir(follow_symlinks=False):
                    continue
                state=Path(item.path)/'job_state.json'
                if not state.exists():
                    continue
                try:
                    value=json.loads(state.read_text(encoding='utf-8',errors='strict'))
                    status=str(value.get('state') or '').strip().upper() if isinstance(value,dict) else ''
                except Exception:
                    invalid += 1
                    continue
                if status in active_states:
                    active += 1
    processing=root/'queue'/'processing'
    queue_busy=sum(1 for item in processing.glob('*.json') if item.is_file()) if processing.is_dir() else 0
    if invalid:
        raise SystemExit(f'export-jobdrain vond {invalid} onleesbare state-record(s)')
    if active == 0 and queue_busy == 0:
        quiet_polls += 1
        if quiet_polls >= 2:
            break
    else:
        quiet_polls=0
    if time.monotonic() >= deadline:
        raise SystemExit(f'export-jobdrain timeout: {active} actieve job(s), {queue_busy} queue-item(s)')
    time.sleep(1)
PY

  systemctl stop metod-pax.service || fail "Backendservice kon niet gecontroleerd worden gestopt"
  ACTIVE_STATE="$(systemctl show metod-pax.service --property=ActiveState --value)" \
    || fail "Service-active-state kon niet worden bepaald"
  [[ "$ACTIVE_STATE" =~ ^(inactive|failed)$ ]] \
    || fail "Backendservice is niet aantoonbaar gestopt: $ACTIVE_STATE"
fi

TEMP_ROOT="$(mktemp -d /var/tmp/metod-pax-migration.XXXXXX)"
chmod 0700 "$TEMP_ROOT"
PAYLOAD="$TEMP_ROOT/metod-pax-migration"
install -d -o root -g root -m 0700 "$PAYLOAD/state" "$PAYLOAD/config" "$PAYLOAD/privacy"
[[ -d "${STATE_DIR}-privacy" && ! -L "${STATE_DIR}-privacy" ]] || fail "Actueel extern verwijderlogboek ontbreekt; export vereist de actuele applicatie"
rsync -a --delete "${STATE_DIR}-privacy/" "$PAYLOAD/privacy/"
if [[ -f "$ENV_DIR/backup-budget.env" && ! -L "$ENV_DIR/backup-budget.env" ]]; then
  cp -a --no-dereference "$ENV_DIR/backup-budget.env" "$PAYLOAD/config/backup-budget.env"
fi
rsync -a --delete "$STATE_DIR/" "$PAYLOAD/state/"
cp -a --no-dereference "$CREDS_FILE" "$PAYLOAD/config/admin_credentials.live.json"
if [[ -f "$ENV_DIR/metod-pax.env" && ! -L "$ENV_DIR/metod-pax.env" ]]; then
  cp -a --no-dereference "$ENV_DIR/metod-pax.env" "$PAYLOAD/config/metod-pax.env.previous"
fi
chmod 0600 "$PAYLOAD/config/admin_credentials.live.json"
PYTHONDONTWRITEBYTECODE=1 /usr/bin/python3 -I -S -B "$STAGE/tools/install_state_gate.py" \
  --state-root "$PAYLOAD/state" --credentials "$PAYLOAD/config/admin_credentials.live.json"
PYTHONDONTWRITEBYTECODE=1 /usr/bin/python3 -I -S -B "$STAGE/tools/migration_bundle_tool.py" manifest --payload "$PAYLOAD"

if [[ "$WAS_ACTIVE" -eq 1 ]]; then
  resume_backend || fail "Backendservice kon na snapshot niet aantoonbaar live en ready worden hervat"
  resume_nginx || fail "Nginx kon na gezond backendherstel niet worden hervat"
fi

umask 077
OUTPUT_TMP="$TEMP_ROOT/encrypted-migration.gpg"
SIDECAR_TMP="$TEMP_ROOT/encrypted-migration.gpg.sha256"
exec {PASSPHRASE_FD}<<<"$MIGRATION_PASSPHRASE"
tar --numeric-owner --format=pax -C "$TEMP_ROOT" -cf - metod-pax-migration \
  | gpg --batch --yes --pinentry-mode loopback --passphrase-fd "$PASSPHRASE_FD" --symmetric \
      --cipher-algo AES256 --s2k-mode 3 --s2k-digest-algo SHA512 --s2k-count 65011712 \
      --compress-algo none --no-symkey-cache --output "$OUTPUT_TMP"
exec {PASSPHRASE_FD}<&-
unset MIGRATION_PASSPHRASE
chmod 0600 "$OUTPUT_TMP"
printf '%s  %s\n' "$(sha256sum "$OUTPUT_TMP" | awk '{print $1}')" "$(basename "$OUTPUT")" > "$SIDECAR_TMP"
chmod 0600 "$SIDECAR_TMP"
OUTPUT_UID=0
OUTPUT_GID=0
if [[ -n "${SUDO_USER:-}" ]]; then
  OUTPUT_UID="$(id -u "$SUDO_USER")" || fail "Sudo-uitvoereigenaar kon niet worden bepaald"
  OUTPUT_GID="$(id -g "$SUDO_USER")" || fail "Sudo-uitvoergroep kon niet worden bepaald"
fi
/usr/bin/python3 -I -S -B - "$OUTPUT_TMP" "$SIDECAR_TMP" "$OUTPUT" "$OUTPUT.sha256" "$OUTPUT_UID" "$OUTPUT_GID" <<'PY'
import os,secrets,stat,sys
from pathlib import Path
temporary,sidecar_temporary,output,sidecar=map(Path,sys.argv[1:5])
output_uid=int(sys.argv[5]); output_gid=int(sys.argv[6])
parent=output.parent
if sidecar.parent!=parent:
    raise SystemExit('definitieve publicatiebestanden moeten één uitvoerdirectory delen')
if parent.resolve(strict=True)!=parent:
    raise SystemExit('uitvoerparent wijzigde naar een symlinkpad')
source_parent=temporary.parent
if sidecar_temporary.parent!=source_parent or source_parent.resolve(strict=True)!=source_parent:
    raise SystemExit('migratie-publicatiebronnen moeten één canonieke private directory delen')
source_parent_metadata=source_parent.lstat()
if not stat.S_ISDIR(source_parent_metadata.st_mode) or source_parent_metadata.st_uid!=0 \
   or stat.S_IMODE(source_parent_metadata.st_mode)!=0o700:
    raise SystemExit('migratie-publicatiebronnen staan niet in een root-private 0700-directory')

def open_directory_chain(path):
    descriptor=os.open('/',os.O_RDONLY|getattr(os,'O_DIRECTORY',0)|getattr(os,'O_CLOEXEC',0))
    try:
        for part in path.parts[1:]:
            child=os.open(part,os.O_RDONLY|getattr(os,'O_DIRECTORY',0)|getattr(os,'O_NOFOLLOW',0)|getattr(os,'O_CLOEXEC',0),dir_fd=descriptor)
            os.close(descriptor)
            descriptor=child
        return descriptor
    except Exception:
        os.close(descriptor)
        raise

directory=open_directory_chain(parent)
directory_identity=os.fstat(directory)
linked_parent=parent.lstat()
if not stat.S_ISDIR(linked_parent.st_mode) or (linked_parent.st_dev,linked_parent.st_ino)!=(directory_identity.st_dev,directory_identity.st_ino):
    os.close(directory)
    raise SystemExit('uitvoerparent wisselde tijdens openen')

def stable(metadata):
    return (metadata.st_dev,metadata.st_ino,metadata.st_mode,metadata.st_nlink,
            metadata.st_uid,metadata.st_gid,metadata.st_size,
            metadata.st_mtime_ns,metadata.st_ctime_ns)

def open_source(path,limit):
    descriptor=os.open(path,os.O_RDONLY|getattr(os,'O_NOFOLLOW',0)|getattr(os,'O_NONBLOCK',0)|getattr(os,'O_CLOEXEC',0))
    metadata=os.fstat(descriptor)
    if not stat.S_ISREG(metadata.st_mode) or metadata.st_nlink!=1 or metadata.st_uid!=0 or stat.S_IMODE(metadata.st_mode)!=0o600:
        os.close(descriptor)
        raise SystemExit(f'onveilig root-privaat publicatiebronbestand: {path.name}')
    linked=path.lstat()
    if (linked.st_dev,linked.st_ino)!=(metadata.st_dev,metadata.st_ino) or metadata.st_size<1 or metadata.st_size>limit:
        os.close(descriptor)
        raise SystemExit(f'publicatiebronbestand wisselde of overschrijdt bytegrens: {path.name}')
    os.fsync(descriptor)
    return descriptor,metadata

bundle_fd,bundle_metadata=open_source(temporary,64*1024*1024*1024)
sidecar_fd,sidecar_metadata=open_source(sidecar_temporary,4096)
stages=[]
intents=[]

def stage_copy(source_fd,source_path,source_metadata,label):
    name=f'.metod-migration-publish.{label}.{secrets.token_hex(16)}'
    flags=os.O_RDWR|os.O_CREAT|os.O_EXCL|getattr(os,'O_NOFOLLOW',0)|getattr(os,'O_CLOEXEC',0)
    target_fd=os.open(name,flags,0o600,dir_fd=directory)
    reserved=os.fstat(target_fd)
    stages.append((name,target_fd,reserved.st_dev,reserved.st_ino))
    copied=0
    os.lseek(source_fd,0,os.SEEK_SET)
    while True:
        chunk=os.read(source_fd,1024*1024)
        if not chunk:
            break
        copied += len(chunk)
        if copied>source_metadata.st_size:
            raise RuntimeError(f'publicatiebron groeide tijdens kopie: {source_path.name}')
        view=memoryview(chunk)
        while view:
            written=os.write(target_fd,view)
            if written<=0:
                raise RuntimeError(f'korte publicatiewrite: {label}')
            view=view[written:]
    os.fsync(target_fd)
    source_after=os.fstat(source_fd)
    source_linked=source_path.lstat()
    staged=os.fstat(target_fd)
    linked=os.stat(name,dir_fd=directory,follow_symlinks=False)
    if copied!=source_metadata.st_size or stable(source_metadata)!=stable(source_after) \
       or (source_linked.st_dev,source_linked.st_ino)!=(source_after.st_dev,source_after.st_ino) \
       or not stat.S_ISREG(staged.st_mode) or staged.st_nlink!=1 \
       or staged.st_uid!=0 or stat.S_IMODE(staged.st_mode)!=0o600 \
       or staged.st_size!=copied or (linked.st_dev,linked.st_ino)!=(staged.st_dev,staged.st_ino):
        raise RuntimeError(f'publicatiebron of anchored stage wisselde tijdens kopie: {label}')
    stages[-1]=(name,target_fd,staged.st_dev,staged.st_ino)
    return name,staged

def unlink_exact(name,expected_dev,expected_ino):
    try:
        current=os.stat(name,dir_fd=directory,follow_symlinks=False)
    except FileNotFoundError:
        return True
    if expected_dev is None or (current.st_dev,current.st_ino)!=(expected_dev,expected_ino):
        return False
    os.unlink(name,dir_fd=directory)
    return True

def prove_stage(name,metadata):
    linked=os.stat(name,dir_fd=directory,follow_symlinks=False)
    if (linked.st_dev,linked.st_ino)!=(metadata.st_dev,metadata.st_ino):
        raise RuntimeError(f'anchored publicatiestage wisselde vóór linkcommit: {name}')

try:
    for name in (output.name,sidecar.name):
        try:
            os.stat(name,dir_fd=directory,follow_symlinks=False)
        except FileNotFoundError:
            continue
        raise SystemExit('definitieve migratie-uitvoer verscheen tijdens publicatie')
    bundle_stage,bundle_stage_metadata=stage_copy(bundle_fd,temporary,bundle_metadata,'bundle')
    sidecar_stage,sidecar_stage_metadata=stage_copy(sidecar_fd,sidecar_temporary,sidecar_metadata,'sidecar')
    # Sidecar eerst; de bundle-link is de zichtbare commit-marker voor watchers.
    prove_stage(sidecar_stage,sidecar_stage_metadata)
    intents.append((sidecar.name,sidecar_stage_metadata.st_dev,sidecar_stage_metadata.st_ino))
    os.link(sidecar_stage,sidecar.name,src_dir_fd=directory,dst_dir_fd=directory,follow_symlinks=False)
    os.fsync(directory)
    prove_stage(bundle_stage,bundle_stage_metadata)
    intents.append((output.name,bundle_stage_metadata.st_dev,bundle_stage_metadata.st_ino))
    os.link(bundle_stage,output.name,src_dir_fd=directory,dst_dir_fd=directory,follow_symlinks=False)
    bundle_published=os.stat(output.name,dir_fd=directory,follow_symlinks=False)
    sidecar_published=os.stat(sidecar.name,dir_fd=directory,follow_symlinks=False)
    if (bundle_published.st_dev,bundle_published.st_ino)!=(bundle_stage_metadata.st_dev,bundle_stage_metadata.st_ino) \
       or (sidecar_published.st_dev,sidecar_published.st_ino)!=(sidecar_stage_metadata.st_dev,sidecar_stage_metadata.st_ino):
        raise SystemExit('publicatiebron wisselde tijdens hardlinkcommit')
    for name,expected in ((output.name,bundle_stage_metadata),(sidecar.name,sidecar_stage_metadata)):
        published_fd=os.open(name,os.O_RDONLY|getattr(os,'O_NOFOLLOW',0)|getattr(os,'O_CLOEXEC',0),dir_fd=directory)
        try:
            opened=os.fstat(published_fd)
            if (opened.st_dev,opened.st_ino)!=(expected.st_dev,expected.st_ino):
                raise RuntimeError(f'definitieve publicatie wisselde vóór ownershipcommit: {name}')
            os.fchown(published_fd,output_uid,output_gid)
            os.fsync(published_fd)
        finally:
            os.close(published_fd)
    stage_replaced=[]
    for name,_descriptor,expected_dev,expected_ino in stages:
        if not unlink_exact(name,expected_dev,expected_ino):
            stage_replaced.append(name)
    if stage_replaced:
        raise RuntimeError(f'anchored publicatiestage werd vervangen: {stage_replaced}')
    os.fsync(directory)
    linked_parent=parent.lstat()
    if (linked_parent.st_dev,linked_parent.st_ino)!=(directory_identity.st_dev,directory_identity.st_ino):
        raise SystemExit('uitvoerparent wisselde tijdens publicatie')
except BaseException as failure:
    replaced=[]
    for name,expected_dev,expected_ino in reversed(intents):
        try:
            current=os.stat(name,dir_fd=directory,follow_symlinks=False)
        except FileNotFoundError:
            continue
        if (current.st_dev,current.st_ino)!=(expected_dev,expected_ino):
            replaced.append(name)
            continue
        try: os.unlink(name,dir_fd=directory)
        except FileNotFoundError: pass
    for name,_descriptor,expected_dev,expected_ino in stages:
        if not unlink_exact(name,expected_dev,expected_ino):
            replaced.append(name)
    os.fsync(directory)
    if replaced:
        raise RuntimeError(f'weiger vervangen migratie-uitvoer tijdens rollback te verwijderen: {replaced}') from failure
    raise
finally:
    for _name,descriptor,_expected_dev,_expected_ino in stages:
        os.close(descriptor)
    os.close(bundle_fd)
    os.close(sidecar_fd)
    os.close(directory)
PY
set +e
echo "[METOD-PAX-MIGRATION] PASS: versleutelde migratiebundle: $OUTPUT" || true
echo "[METOD-PAX-MIGRATION] SHA256: $OUTPUT.sha256" || true
exit 0
