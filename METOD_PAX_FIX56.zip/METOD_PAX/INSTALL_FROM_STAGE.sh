#!/usr/bin/env bash
set -Eeuo pipefail
export PATH=/usr/sbin:/usr/bin:/sbin:/bin
export PYTHONDONTWRITEBYTECODE=1
export PYTHONSAFEPATH=1 PYTHONNOUSERSITE=1
unset PYTHONPATH PYTHONHOME

VERSION="R9RC4_FIX56_RUNTIME_PREFLIGHT"
INSTALLER_REVISION="R9RC4_FIX56_RUNTIME_PREFLIGHT"
STAGE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STAGE_SNAPSHOT=""
LEGACY_APP="${METOD_LEGACY_APP_DIR:-/opt/adzaagt/metod-pax}"
RELEASES_DIR="${METOD_RELEASES_DIR:-/opt/adzaagt/metod-pax-releases}"
CURRENT_LINK="${METOD_CURRENT_LINK:-/opt/adzaagt/metod-pax-current}"
STATE_DIR="${METOD_STATE_ROOT:-/var/lib/metod-pax}"
ENV_DIR="${METOD_ENV_DIR:-/etc/adzaagt/metod-pax}"
CREDS_FILE="${ADMIN_CREDENTIALS_FILE:-$ENV_DIR/admin_credentials.live.json}"
BACKUP_ROOT="${METOD_CONFIG_BACKUP_ROOT:-/var/backups/metod-pax}"
INSTALL_MODE="${METOD_INSTALL_MODE:-upgrade}"
RECOVERY_ACK="${METOD_RECOVERY_ACK:-}"
DEPLOY_EPOCH="$(date +%s)"
TS="$(date +%Y%m%d_%H%M%S)"
LOG=""
CONFIG_BACKUP=""
RELEASE_HASH=""
RELEASE_ID=""
RELEASE_DIR=""
RELEASE_TMP=""
PREVIOUS_TARGET=""
SWITCHED=0
TOUCHED=0
SUCCESS=0
STATE_STAGE=""
RECOVERY_CHECKPOINT=""
SERVICE_STOPPED=0
CREDENTIAL_MIGRATION_STAGE=""
RECOVERY_RESUME=0
STATE_MIGRATED=0
ROLLBACK_ERRORS=0

info(){ echo "[$VERSION/$INSTALLER_REVISION] $*"; }
fail(){ echo "[$VERSION/$INSTALLER_REVISION] FOUT: $*" >&2; exit 1; }
safe_abs_path(){ [[ "$1" =~ ^/[A-Za-z0-9._/-]+$ ]] || fail "Onveilig absoluut pad: $1"; }

source "$STAGE/ops/deploy_lock.sh"


for value in "$LEGACY_APP" "$RELEASES_DIR" "$CURRENT_LINK" "$STATE_DIR" "$ENV_DIR" "$CREDS_FILE" "$BACKUP_ROOT"; do
  safe_abs_path "$value"
done

if [[ "$EUID" -ne 0 ]]; then
  # Do not rely on sudo -E: hardened sudo policies commonly ignore it. Forward
  # only the explicit deployment contract, as individual argv values (never as
  # shell source), so staging/production settings survive privilege elevation.
  SUDO_ENV=(
    "PYTHONDONTWRITEBYTECODE=1"
    "METOD_LEGACY_APP_DIR=$LEGACY_APP"
    "METOD_RELEASES_DIR=$RELEASES_DIR"
    "METOD_CURRENT_LINK=$CURRENT_LINK"
    "METOD_STATE_ROOT=$STATE_DIR"
    "METOD_ENV_DIR=$ENV_DIR"
    "ADMIN_CREDENTIALS_FILE=$CREDS_FILE"
    "METOD_CONFIG_BACKUP_ROOT=$BACKUP_ROOT"
    "METOD_INSTALL_MODE=$INSTALL_MODE"
    "METOD_RECOVERY_ACK=$RECOVERY_ACK"
  )
  for name in METOD_DEPLOY_MODE PUBLIC_ORIGIN METOD_DOMAIN TLS_CERT_FILE TLS_KEY_FILE \
              OFFSITE_BACKUP_VERIFIED OFFSITE_BACKUP_PROVIDER PRODUCTION_MIN_CATALOG_RECORDS \
              STAGING_PUBLIC_PORT STAGING_BIND_ADDRESS STAGING_ALLOWED_CIDR STAGING_EXTERNAL_ORIGIN \
              HTTP_MAX_CONNECTIONS HTTP_WORKERS ADMIN_ALLOWED_NETWORKS PUBLIC_JOB_MAX_CONCURRENT \
              PUBLIC_JOB_MAX_QUEUED PUBLIC_JOB_MAX_CONCURRENT_PER_IP \
              OPTIMIZER_TIMEOUT_SECONDS OPTIMIZER_JOB_TIMEOUT_SECONDS \
              METOD_DEPLOY_DRAIN_TIMEOUT_SECONDS \
              MIN_FREE_STATE_BYTES MIN_FREE_STATE_INODES \
              METOD_MEMORY_MAX METOD_TASKS_MAX METOD_NOFILE_MAX NTFY_ALLOWED_HOSTS \
              METOD_RELEASE_KEEP METOD_RELEASE_MAX_AGE_DAYS METOD_RELEASE_MAX_BYTES \
              METOD_CONFIG_BACKUP_KEEP METOD_CONFIG_BACKUP_MAX_AGE_DAYS \
              METOD_CONFIG_BACKUP_MAX_BYTES \
              METOD_RECOVERY_KEEP METOD_RECOVERY_MAX_AGE_DAYS METOD_RECOVERY_MAX_BYTES; do
    if [[ -v "$name" ]]; then SUDO_ENV+=("$name=${!name}"); fi
  done
  exec sudo env "${SUDO_ENV[@]}" bash "$0" "$@"
fi

# Serialize the complete root-side transaction. Clean-install/export parents
# retain this exact open file description; nested installer/deploy shells verify
# and reuse it instead of opening the same lock again and deadlocking themselves.
for lock_command in flock stat readlink; do
  command -v "$lock_command" >/dev/null || fail "Ontbrekend commando: $lock_command"
done
acquire_or_inherit_deploy_lock

for log_command in mktemp tee stat; do
  command -v "$log_command" >/dev/null || fail "Ontbrekend commando: $log_command"
done
install -d -o root -g root -m 0750 /var/log/metod-pax
[[ -d /var/log/metod-pax && ! -L /var/log/metod-pax ]] \
  || fail "Veilige deploylogmap ontbreekt"
[[ "$(stat -c '%u:%g:%a' /var/log/metod-pax)" == "0:0:750" ]] \
  || fail "Deploylogmap heeft onveilige metadata"
LOG="$(mktemp /var/log/metod-pax/install.XXXXXXXX)"
chown root:root "$LOG"
chmod 0600 "$LOG"
[[ "$(stat -c '%u:%g:%a:%h' "$LOG")" == "0:0:600:1" ]] \
  || fail "Deploylog heeft onveilige metadata"
exec > >(tee -a "$LOG") 2>&1

/usr/bin/python3 -I -S -B - "$LEGACY_APP" "$RELEASES_DIR" "$CURRENT_LINK" "$STATE_DIR" "$ENV_DIR" "$CREDS_FILE" "$BACKUP_ROOT" <<'PY'
import itertools,os,sys
from pathlib import Path
raw=sys.argv[1:]
for value in raw:
    if not value.startswith('/') or value.startswith('//') or value != os.path.normpath(value):
        raise SystemExit(f'deploypad moet een canoniek absoluut pad zijn: {value}')
    if any(part in ('','.','..') for part in value.split('/')[1:]):
        raise SystemExit(f'deploypad bevat een verboden segment: {value}')
legacy,releases,current,state,env,creds,backups=map(Path,raw)
def below(path, root):
    try: path.relative_to(root); return path != root
    except ValueError: return False
def reject_symlink_components(path, *, include_leaf=True):
    parts=path.parts[1:] if include_leaf else path.parts[1:-1]
    cursor=Path('/')
    for part in parts:
        cursor /= part
        if cursor.is_symlink():
            raise SystemExit(f'symlinkcomponent is verboden in deploypad: {cursor}')
if not all(below(path,Path('/opt/adzaagt')) for path in (legacy,releases,current)):
    raise SystemExit('code/releasepaden moeten onder /opt/adzaagt liggen')
if not (below(state,Path('/var/lib')) or below(state,Path('/srv'))):
    raise SystemExit('statepad moet onder /var/lib of /srv liggen')
if not below(env,Path('/etc/adzaagt')) or creds.parent != env:
    raise SystemExit('env/credentialpaden moeten onder dezelfde /etc/adzaagt-map liggen')
if not (below(backups,Path('/var/backups')) or below(backups,Path('/srv'))):
    raise SystemExit('configbackup moet onder /var/backups of /srv liggen')
paths=[legacy,releases,current,state,env,creds,backups]
if len({str(path) for path in paths}) != len(paths):
    raise SystemExit('deploypaden moeten onderling verschillend zijn')
trees=[legacy,releases,current,state,env,backups]
for left,right in itertools.combinations(trees,2):
    if left in right.parents or right in left.parents:
        raise SystemExit(f'deploybomen mogen niet overlappen: {left} / {right}')
for path in (legacy,releases,state,env,creds,backups):
    reject_symlink_components(path)
reject_symlink_components(current,include_leaf=False)
PY

validate_release_manifest_tree(){
  local release_root="$1"
  local output_mode="${2:-status}"
  [[ -d "$release_root" && ! -L "$release_root" ]] \
    || fail "Releaseboom ontbreekt of is een symlink: $release_root"
  [[ "$output_mode" =~ ^(status|digest)$ ]] || fail "Ongeldige validator-uitvoermodus"
  /usr/bin/python3 -I -S -B - "$release_root" "$output_mode" <<'PY'
import hashlib
import os
import re
import stat
import sys
from pathlib import Path, PurePosixPath

root = Path(sys.argv[1])
output_mode = sys.argv[2]
manifest = root / 'SHA256SUMS.txt'
entry_limit = 5_000
manifest_byte_limit = 16 * 1024 * 1024
member_byte_limit = 128 * 1024 * 1024
tree_byte_limit = 512 * 1024 * 1024
forbidden_names = {'sitecustomize.py', 'usercustomize.py'}

def stable(metadata):
    return (
        metadata.st_dev, metadata.st_ino, metadata.st_mode, metadata.st_nlink,
        metadata.st_uid, metadata.st_gid, metadata.st_size,
        metadata.st_mtime_ns, metadata.st_ctime_ns,
    )

def open_regular(path: Path):
    flags = (
        os.O_RDONLY
        | getattr(os, 'O_CLOEXEC', 0)
        | getattr(os, 'O_NOFOLLOW', 0)
        | getattr(os, 'O_NONBLOCK', 0)
    )
    descriptor = os.open(path, flags)
    before = os.fstat(descriptor)
    if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1:
        os.close(descriptor)
        raise ValueError(f'geen enkelvoudig gelinkt regulier bestand: {path}')
    linked = path.lstat()
    if (linked.st_dev, linked.st_ino) != (before.st_dev, before.st_ino):
        os.close(descriptor)
        raise ValueError(f'bestandspad wisselde tijdens openen: {path}')
    return descriptor, before

def verify_stable(descriptor, before, path: Path) -> None:
    after = os.fstat(descriptor)
    linked = path.lstat()
    if stable(before) != stable(after):
        raise ValueError(f'bestand wijzigde tijdens validatie: {path}')
    if (linked.st_dev, linked.st_ino) != (after.st_dev, after.st_ino):
        raise ValueError(f'bestandspad wisselde tijdens validatie: {path}')

def regular_bytes(path: Path, byte_limit: int) -> bytes:
    descriptor, before = open_regular(path)
    try:
        chunks = []
        total = 0
        while True:
            chunk = os.read(descriptor, 1024 * 1024)
            if not chunk:
                verify_stable(descriptor, before, path)
                return b''.join(chunks)
            total += len(chunk)
            if total > byte_limit:
                raise ValueError(f'bestand overschrijdt bytegrens: {path}')
            chunks.append(chunk)
    finally:
        os.close(descriptor)

def regular_digest(path: Path, byte_limit: int) -> str:
    descriptor, before = open_regular(path)
    result = hashlib.sha256()
    total = 0
    try:
        while True:
            chunk = os.read(descriptor, 1024 * 1024)
            if not chunk:
                verify_stable(descriptor, before, path)
                return result.hexdigest()
            total += len(chunk)
            if total > byte_limit:
                raise ValueError(f'bestand overschrijdt bytegrens: {path}')
            result.update(chunk)
    finally:
        os.close(descriptor)

def reject_forbidden(relative: str) -> None:
    parts = PurePosixPath(relative).parts
    lowered = tuple(part.lower() for part in parts)
    if '__pycache__' in lowered:
        raise ValueError(f'__pycache__ is verboden: {relative}')
    if lowered[-1] in forbidden_names:
        raise ValueError(f'Python startup-hook is verboden: {relative}')
    if lowered[-1].endswith(('.pyc', '.pyo', '.bak')):
        raise ValueError(f'cache/backupbestand is verboden: {relative}')

manifest_metadata = manifest.lstat()
if not stat.S_ISREG(manifest_metadata.st_mode) or manifest_metadata.st_nlink != 1:
    raise SystemExit('SHA256SUMS.txt moet een enkelvoudig gelinkt regulier rootbestand zijn')
manifest_bytes = regular_bytes(manifest, manifest_byte_limit)
manifest_digest = hashlib.sha256(manifest_bytes).hexdigest()
try:
    manifest_text = manifest_bytes.decode('utf-8', errors='strict')
except UnicodeDecodeError as exc:
    raise SystemExit(f'SHA256SUMS.txt is geen strikte UTF-8: {exc}') from exc
if not manifest_text.endswith('\n') or '\r' in manifest_text or '\x00' in manifest_text:
    raise SystemExit('SHA256SUMS.txt heeft geen canonieke LF-tekstvorm')

expected = {}
line_pattern = re.compile(r'([a-f0-9]{64})  \./([^\r\n]+)')
for line_number, line in enumerate(manifest_text[:-1].split('\n'), 1):
    match = line_pattern.fullmatch(line)
    if match is None:
        raise SystemExit(f'ongeldige manifestregel {line_number}')
    digest, raw = match.groups()
    pure = PurePosixPath(raw)
    if (
        pure.is_absolute()
        or pure.as_posix() != raw
        or not pure.parts
        or any(part in {'', '.', '..'} for part in pure.parts)
        or '\\' in raw
        or any(not character.isprintable() for character in raw)
        or any(part != part.strip() for part in pure.parts)
    ):
        raise SystemExit(f'onveilig manifestpad op regel {line_number}')
    if raw == 'SHA256SUMS.txt':
        raise SystemExit('root SHA256SUMS.txt mag zichzelf niet manifesteren')
    reject_forbidden(raw)
    if raw in expected:
        raise SystemExit(f'dubbel manifestpad: {raw}')
    expected[raw] = digest

actual = set()
actual_directories = set()
stack = [root]
entries = 0
tree_bytes = 0
while stack:
    directory = stack.pop()
    with os.scandir(directory) as scan:
        for item in scan:
            entries += 1
            if entries > entry_limit:
                raise SystemExit('releaseboom overschrijdt de entrygrens')
            relative = Path(item.path).relative_to(root).as_posix()
            reject_forbidden(relative)
            metadata = item.stat(follow_symlinks=False)
            if stat.S_ISLNK(metadata.st_mode):
                raise SystemExit(f'symlink in releaseboom: {relative}')
            if stat.S_ISDIR(metadata.st_mode):
                actual_directories.add(relative)
                stack.append(Path(item.path))
            elif stat.S_ISREG(metadata.st_mode):
                if metadata.st_nlink != 1:
                    raise SystemExit(f'hardlink in releaseboom: {relative}')
                if metadata.st_size > member_byte_limit:
                    raise SystemExit(f'releasebestand overschrijdt 128 MiB: {relative}')
                tree_bytes += metadata.st_size
                if tree_bytes > tree_byte_limit:
                    raise SystemExit('releaseboom overschrijdt 512 MiB totaal')
                if relative != 'SHA256SUMS.txt':
                    actual.add(relative)
            else:
                raise SystemExit(f'speciaal bestand in releaseboom: {relative}')

missing = sorted(set(expected) - actual)
extra = sorted(actual - set(expected))
expected_directories = set()
for relative in expected:
    for parent in PurePosixPath(relative).parents:
        if parent.as_posix() != '.':
            expected_directories.add(parent.as_posix())
extra_directories = sorted(actual_directories - expected_directories)
if missing or extra or extra_directories:
    raise SystemExit(
        f'manifest-fileset wijkt af: missing={missing[:10]}, '
        f'extra={extra[:10]}, extra_dirs={extra_directories[:10]}'
    )
if not expected:
    raise SystemExit('manifest-fileset mag niet leeg zijn')
for relative, wanted in expected.items():
    observed = regular_digest(root / relative, member_byte_limit)
    if observed != wanted:
        raise SystemExit(f'manifestdigest wijkt af: {relative}')
if output_mode == 'digest':
    print(manifest_digest)
else:
    print(f'Exact manifest-fileset OK: {len(expected)} bestanden; manifest={manifest_digest}')
PY
}

run_release_python(){
  local release_root="$1" relative_script="$2"
  shift 2
  /usr/bin/python3 -I -S -B -c '
import runpy
import stat
import sys
from pathlib import Path, PurePosixPath

root = Path(sys.argv[1]).resolve(strict=True)
relative = PurePosixPath(sys.argv[2])
if relative.is_absolute() or not relative.parts or any(part in {"", ".", ".."} for part in relative.parts) or relative.suffix != ".py":
    raise SystemExit("ongeldig relatief release-Pythondoel")
candidate = root.joinpath(*relative.parts)
metadata = candidate.lstat()
if not stat.S_ISREG(metadata.st_mode) or metadata.st_nlink != 1:
    raise SystemExit("release-Pythondoel is geen enkelvoudig gelinkt regulier bestand")
target = candidate.resolve(strict=True)
if root not in target.parents:
    raise SystemExit("release-Pythondoel ontsnapte uit de gevalideerde release")
for local_root in (root, root / "app", root / "tools"):
    resolved = local_root.resolve(strict=True)
    if resolved != root and root not in resolved.parents:
        raise SystemExit("release-importroot ontsnapte uit de gevalideerde release")
    sys.path.insert(0, str(resolved))
sys.argv = [str(target), *sys.argv[3:]]
runpy.run_path(str(target), run_name="__main__")
' "$release_root" "$relative_script" "$@"
}

reserve_config_backup(){
  local attempt candidate_epoch candidate_ts candidate
  for ((attempt=0; attempt<3600; attempt++)); do
    candidate_epoch=$((DEPLOY_EPOCH + attempt))
    candidate_ts="$(date -d "@$candidate_epoch" +%Y%m%d_%H%M%S)" \
      || fail "Unieke configbackuptijd kon niet worden gemaakt"
    candidate="$BACKUP_ROOT/${VERSION}_config_${candidate_ts}"
    if mkdir -m 0755 -- "$candidate" 2>/dev/null; then
      chown root:root "$candidate"
      chmod 0755 "$candidate"
      CONFIG_BACKUP="$candidate"
      return 0
    fi
    [[ -e "$candidate" || -L "$candidate" ]] \
      || fail "Configbackup kon niet no-clobber worden gereserveerd: $candidate"
  done
  fail "Geen unieke configbackupnaam beschikbaar binnen 3600 seconden"
}

fsync_rollback_path(){
  /usr/bin/python3 -I -S -B - "$1" <<'PY'
import os,stat,sys
from pathlib import Path
path=Path(sys.argv[1])
metadata=path.lstat()
if stat.S_ISREG(metadata.st_mode):
    descriptor=os.open(path,os.O_RDONLY|getattr(os,'O_NOFOLLOW',0))
    try: os.fsync(descriptor)
    finally: os.close(descriptor)
elif not stat.S_ISLNK(metadata.st_mode):
    raise SystemExit('rollbackreplacement is geen regulier bestand of symlink')
directory=os.open(path.parent,os.O_RDONLY|getattr(os,'O_DIRECTORY',0))
try: os.fsync(directory)
finally: os.close(directory)
PY
}

fsync_rollback_directory(){
  /usr/bin/python3 -I -S -B - "$1" <<'PY'
import os,sys
descriptor=os.open(sys.argv[1],os.O_RDONLY|getattr(os,'O_DIRECTORY',0))
try: os.fsync(descriptor)
finally: os.close(descriptor)
PY
}

restore_config_path(){
  local live="$1" key backup parent base staging replacement
  key="$(printf '%s' "$live" | sha256sum | awk '{print $1}')"
  backup="$CONFIG_BACKUP/$key.present"
  parent="$(dirname "$live")"
  base="$(basename "$live")"
  if [[ -e "$backup" || -L "$backup" ]]; then
    if [[ ! -f "$backup" && ! -L "$backup" ]]; then
      echo "[$VERSION] ROLLBACK KRITIEK: unsupported backuptype voor $live" >&2
      ROLLBACK_ERRORS=1
      return 1
    fi
    staging="$(mktemp -d "$parent/.${base}.rollback.XXXXXXXX")" || {
      echo "[$VERSION] ROLLBACK KRITIEK: geen sibling stage voor $live" >&2
      ROLLBACK_ERRORS=1
      return 1
    }
    replacement="$staging/replacement"
    if ! cp -a --no-dereference "$backup" "$replacement"; then
      echo "[$VERSION] ROLLBACK KRITIEK: backupkopie voor $live faalde" >&2
      rmdir "$staging" 2>/dev/null || true
      ROLLBACK_ERRORS=1
      return 1
    fi
    if [[ -L "$backup" ]]; then
      if [[ ! -L "$replacement" || "$(readlink "$replacement")" != "$(readlink "$backup")" ]]; then
        echo "[$VERSION] ROLLBACK KRITIEK: symlinkverificatie voor $live faalde" >&2
        rm -f -- "$replacement"
        rmdir "$staging" 2>/dev/null || true
        ROLLBACK_ERRORS=1
        return 1
      fi
    elif ! cmp -s "$backup" "$replacement"; then
      echo "[$VERSION] ROLLBACK KRITIEK: byteverificatie voor $live faalde" >&2
      rm -f -- "$replacement"
      rmdir "$staging" 2>/dev/null || true
      ROLLBACK_ERRORS=1
      return 1
    fi
    if ! fsync_rollback_path "$replacement" || ! mv -Tf -- "$replacement" "$live"; then
      echo "[$VERSION] ROLLBACK KRITIEK: atomische restore voor $live faalde" >&2
      rm -f -- "$replacement" 2>/dev/null || true
      rmdir "$staging" 2>/dev/null || true
      ROLLBACK_ERRORS=1
      return 1
    fi
    fsync_rollback_directory "$parent" || ROLLBACK_ERRORS=1
    rmdir "$staging" 2>/dev/null || {
      echo "[$VERSION] ROLLBACK WAARSCHUWING: lege rollbackstage bleef staan: $staging" >&2
      ROLLBACK_ERRORS=1
    }
    return 0
  fi

  [[ -e "$live" || -L "$live" ]] || return 0
  staging="$(mktemp -d "$parent/.${base}.rollback-remove.XXXXXXXX")" || {
    echo "[$VERSION] ROLLBACK KRITIEK: geen verwijderstage voor $live" >&2
    ROLLBACK_ERRORS=1
    return 1
  }
  if ! mv -T -- "$live" "$staging/original"; then
    echo "[$VERSION] ROLLBACK KRITIEK: atomische verwijdering voor $live faalde" >&2
    rmdir "$staging" 2>/dev/null || true
    ROLLBACK_ERRORS=1
    return 1
  fi
  fsync_rollback_directory "$parent" || ROLLBACK_ERRORS=1
  if ! rm -rf -- "$staging"; then
    echo "[$VERSION] ROLLBACK WAARSCHUWING: verwijderde config bleef in quarantine: $staging" >&2
    ROLLBACK_ERRORS=1
  fi
}

rollback(){
  local rc=$?
  if [[ -n "$STAGE_SNAPSHOT" && "$STAGE_SNAPSHOT" == /var/tmp/metod-pax-stage.* && -d "$STAGE_SNAPSHOT" && ! -L "$STAGE_SNAPSHOT" ]]; then
    if ! rm -rf -- "$STAGE_SNAPSHOT"; then
      echo "[$VERSION] WAARSCHUWING: root-private stagesnapshot kon niet worden verwijderd: $STAGE_SNAPSHOT" >&2
    fi
  fi
  if [[ -n "$RELEASE_TMP" && "$RELEASE_TMP" == "$RELEASES_DIR/."*".stage."* && -d "$RELEASE_TMP" && ! -L "$RELEASE_TMP" ]]; then
    if ! rm -rf -- "$RELEASE_TMP"; then
      echo "[$VERSION] WAARSCHUWING: private releasetargetstage kon niet worden verwijderd: $RELEASE_TMP" >&2
    fi
  fi
  if [[ "$SUCCESS" -eq 1 ]]; then return 0; fi
  echo "[$VERSION] INSTALLATIE MISLUKT (code $rc). Log: $LOG" >&2
  if [[ -n "$CREDENTIAL_MIGRATION_STAGE" && "$CREDENTIAL_MIGRATION_STAGE" == /run/metod-pax-credential-migration.* && -f "$CREDENTIAL_MIGRATION_STAGE" && ! -L "$CREDENTIAL_MIGRATION_STAGE" ]]; then
    rm -f -- "$CREDENTIAL_MIGRATION_STAGE"
  fi
  if [[ -n "$STATE_STAGE" && "$STATE_STAGE" == "${STATE_DIR}.migrate."* && -d "$STATE_STAGE" ]]; then
    rm -rf -- "$STATE_STAGE"
  fi
  if [[ "$TOUCHED" -eq 1 ]]; then
    set +e
    if [[ "$INSTALL_MODE" == "recovery" && -z "$PREVIOUS_TARGET" ]]; then
      if [[ "$SERVICE_STOPPED" -eq 0 ]]; then
        restore_config_path /etc/systemd/system/metod-pax.service
        restore_config_path "$ENV_DIR/metod-pax.env"
        restore_config_path /etc/nginx/sites-available/metod-pax
        restore_config_path /etc/nginx/sites-enabled/metod-pax
        restore_config_path /etc/nginx/sites-available/metod-pax-8790
        restore_config_path /etc/nginx/sites-enabled/metod-pax-8790
        restore_config_path /etc/nginx/conf.d/metod-pax-limits.conf
        restore_config_path /etc/logrotate.d/metod-pax-nginx
        restore_config_path /etc/systemd/system/multi-user.target.wants/metod-pax.service
        systemctl daemon-reload || { echo "[$VERSION] ROLLBACK KRITIEK: systemd daemon-reload faalde" >&2; ROLLBACK_ERRORS=1; }
        if nginx -t; then
          systemctl reload nginx || { echo "[$VERSION] ROLLBACK KRITIEK: Nginx-reload faalde" >&2; ROLLBACK_ERRORS=1; }
        else
          echo "[$VERSION] ROLLBACK KRITIEK: herstelde Nginx-config faalt validatie" >&2
          ROLLBACK_ERRORS=1
        fi
        [[ "$ROLLBACK_ERRORS" -eq 0 ]] \
          || echo "[$VERSION] RECOVERY ROLLBACK ONVOLLEDIG; handmatig herstel uit $CONFIG_BACKUP vereist." >&2
        echo "[$VERSION] RECOVERY FAIL-CLOSED vóór service-stop: bestaande configuratie hersteld; het proces is niet herstart." >&2
      else
        systemctl stop metod-pax.service || true
        if systemctl is-active --quiet metod-pax.service; then
          echo "[$VERSION] RECOVERY FAIL-CLOSED KRITIEK: backendservice kon niet aantoonbaar worden gestopt; maintenance blijft actief." >&2
        else
          echo "[$VERSION] RECOVERY FAIL-CLOSED: geen herstelbare oude codebaseline; maintenance blijft actief en de service is aantoonbaar gestopt." >&2
        fi
      fi
      echo "[$VERSION] Recoverycheckpoint: ${RECOVERY_CHECKPOINT:-niet aangemaakt}" >&2
      return "$rc"
    fi
    if [[ "$SWITCHED" -eq 1 && -n "$PREVIOUS_TARGET" && -d "$PREVIOUS_TARGET" ]]; then
      if ! ln -sfn "$PREVIOUS_TARGET" "$CURRENT_LINK.rollback" \
          || ! mv -Tf "$CURRENT_LINK.rollback" "$CURRENT_LINK"; then
        echo "[$VERSION] ROLLBACK KRITIEK: releasepointer kon niet atomair worden teruggezet" >&2
        ROLLBACK_ERRORS=1
      elif ! fsync_rollback_directory "$(dirname "$CURRENT_LINK")"; then
        echo "[$VERSION] ROLLBACK KRITIEK: releasepointerdirectory kon niet worden gefsynct" >&2
        ROLLBACK_ERRORS=1
      fi
    fi
    restore_config_path /etc/systemd/system/metod-pax.service
    restore_config_path "$ENV_DIR/metod-pax.env"
    restore_config_path /etc/nginx/sites-available/metod-pax
    restore_config_path /etc/nginx/sites-enabled/metod-pax
    restore_config_path /etc/nginx/sites-available/metod-pax-8790
    restore_config_path /etc/nginx/sites-enabled/metod-pax-8790
    restore_config_path /etc/nginx/conf.d/metod-pax-limits.conf
    restore_config_path /etc/logrotate.d/metod-pax-nginx
    restore_config_path /etc/systemd/system/multi-user.target.wants/metod-pax.service
    systemctl daemon-reload || { echo "[$VERSION] ROLLBACK KRITIEK: systemd daemon-reload faalde" >&2; ROLLBACK_ERRORS=1; }
    if nginx -t; then
      systemctl reload nginx || { echo "[$VERSION] ROLLBACK KRITIEK: Nginx-reload faalde" >&2; ROLLBACK_ERRORS=1; }
    else
      echo "[$VERSION] ROLLBACK KRITIEK: herstelde Nginx-config faalt validatie" >&2
      ROLLBACK_ERRORS=1
    fi
    if [[ -f /etc/systemd/system/metod-pax.service ]]; then
      systemctl restart metod-pax.service \
        || { echo "[$VERSION] ROLLBACK KRITIEK: backendservice kon niet worden herstart" >&2; ROLLBACK_ERRORS=1; }
    fi
    if [[ "$ROLLBACK_ERRORS" -eq 0 ]]; then
      echo "[$VERSION] Releasepointer/config atomair teruggezet; externe state is bewust nooit teruggedraaid." >&2
    else
      echo "[$VERSION] ROLLBACK ONVOLLEDIG; handmatig herstel uit $CONFIG_BACKUP vereist." >&2
    fi
    set -e
  fi
  return "$rc"
}
trap rollback EXIT

for cmd in python3 sha256sum rsync curl nginx systemctl tar flock du df awk grep cmp; do command -v "$cmd" >/dev/null || fail "Ontbrekend commando: $cmd"; done
[[ -x /usr/bin/python3 ]] || fail "Vertrouwde interpreter /usr/bin/python3 ontbreekt"
[[ "$INSTALL_MODE" =~ ^(upgrade|recovery|bootstrap)$ ]] || fail "METOD_INSTALL_MODE moet upgrade, recovery of bootstrap zijn"
[[ -f "$CREDS_FILE" && ! -L "$CREDS_FILE" ]] || fail "Bestaande Admin credentials ontbreken of zijn geen regulier bestand: $CREDS_FILE"
[[ "$(stat -c '%u:%g:%a:%h' "$CREDS_FILE")" == "0:0:600:1" ]] \
  || fail "Admin credentials moeten enkelvoudig gelinkt, root:root-owned en mode 0600 zijn"

RELEASE_HASH="$(validate_release_manifest_tree "$STAGE" digest)" \
  || fail "Staged manifest-fileset kon niet vertrouwd worden gevalideerd"
[[ "$RELEASE_HASH" =~ ^[a-f0-9]{64}$ ]] || fail "Volledige manifestdigest kon niet veilig worden bepaald"

# Neem vóór de eerste staged Python-uitvoering een root-private snapshot. De
# bron kan uit een sudo-aanroep user-owned zijn; alleen deze gevalideerde kopie
# wordt vanaf hier nog als release/toolbron gebruikt.
STAGE_SOURCE="$STAGE"
STAGE_SNAPSHOT="$(mktemp -d /var/tmp/metod-pax-stage.XXXXXXXX)" \
  || fail "Root-private stagesnapshot kon niet no-clobber worden gereserveerd"
chown root:root "$STAGE_SNAPSHOT"
chmod 0700 "$STAGE_SNAPSHOT"
rsync -a --one-file-system --delete --max-size=134217728 --chown=root:root --chmod=D0700,F0600 "$STAGE_SOURCE/" "$STAGE_SNAPSHOT/"
SNAPSHOT_RELEASE_HASH="$(validate_release_manifest_tree "$STAGE_SNAPSHOT" digest)" \
  || fail "Root-private stagesnapshot faalde vertrouwde manifestvalidatie"
[[ "$SNAPSHOT_RELEASE_HASH" == "$RELEASE_HASH" ]] \
  || fail "Root-private stagesnapshot hoort niet bij de gevalideerde manifestdigest"
STAGE="$STAGE_SNAPSHOT"

if [[ "${METOD_DEPLOY_MODE:-staging}" == "production" ]]; then
  run_release_python "$STAGE" tools/deployment_safety.py production --release "$STAGE" \
    || fail "Production-install vereist onafhankelijke goedkeuring van deze exacte release"
fi

if ! run_release_python "$STAGE" tools/prune_deploy_history.py --logs-only \
    --install-log-root /var/log/metod-pax --current-install-log "$LOG"; then
  info "WAARSCHUWING: begrensde installatielogretentie faalde; huidig log blijft behouden."
fi

/usr/bin/python3 -I -S -B - "$STAGE" <<'PY'
from pathlib import Path
import json,sys
root=Path(sys.argv[1])
bad=[str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and ('__pycache__' in p.parts or p.suffix.lower() in {'.pyc','.bak'})]
if bad: raise SystemExit(f'Onschone staged release: {bad[:20]}')
lib=json.loads((root/'app/material_library.json').read_text(encoding='utf-8'))
if lib.get('source')!='CSV_CATALOG_ONLY' or lib.get('records')!=[]: raise SystemExit('Release seed must be empty CSV-only library')
print('Staged release contract OK')
PY
PYTHONDONTWRITEBYTECODE=1 /usr/bin/python3 -I -S -B "$STAGE/tools/final_preflight.py" \
  --release "$STAGE" --verify-checksums
FINAL_STAGE_RELEASE_HASH="$(validate_release_manifest_tree "$STAGE" digest)" \
  || fail "Staged release kon na final-preflight niet worden hergevalideerd"
[[ "$FINAL_STAGE_RELEASE_HASH" == "$RELEASE_HASH" ]] \
  || fail "Staged manifestdigest wijzigde tijdens final-preflight"
RELEASE_ID="${VERSION}_${RELEASE_HASH}"
RELEASE_DIR="$RELEASES_DIR/$RELEASE_ID"

verify_legacy_r7(){
  systemctl is-active --quiet metod-pax.service || fail "Bestaande service is vóór deploy niet actief"
  curl -fsS http://127.0.0.1:8792/api/materials/library >/dev/null || fail "Bestaande backend is vóór deploy niet gezond"
  local -A EXPECTED_R7=(
    [server_py.py]="058b4692aa251ff1c4a92489d639da60027e28bd120a2ab362eec8c3a63f122f"
    [toolA.html]="aa29587f1c0bef4bde2831be646d8245eb060ebfdeb9f5ebf80385315799c310"
    [dxf_nesting_optimizer.py]="d1113f9fd35325f4dcb2199cce6f6102d51b4a0d55832558b06cb8cd574ec355"
    [toolA_grain_studio_renderer.js]="ca969d214e849257e7579325eaca5626f18ca42e63c11f4664ec8a3dcea9cd07"
    [toolA_grain_mobile_scale.js]="06dbb20fc93696b97eccdb0628085fb67717e1bb3c4e7c40011f72571afbae8e"
  )
  local file
  for file in "${!EXPECTED_R7[@]}"; do
    [[ "$(sha256sum "$LEGACY_APP/app/$file" | awk '{print $1}')" == "${EXPECTED_R7[$file]}" ]] || fail "Live baseline is niet exact FIX660R7: app/$file"
  done
  info "Exacte FIX660R7-baseline bevestigd."
}

prove_live_recovery_maintenance(){
  local proof_url proof_headers proof_domain proof_port proof_bind
  systemctl is-active --quiet nginx || fail "Recovery-resume vereist een actieve lokale Nginx"
  if [[ "${METOD_DEPLOY_MODE:-staging}" == "production" ]]; then
    proof_domain="${METOD_DOMAIN:-}"
    [[ -n "$proof_domain" ]] || fail "METOD_DOMAIN ontbreekt voor production recoverybewijs"
    /usr/bin/python3 -I -S -B - "$proof_domain" <<'PY'
import re,sys
if not re.fullmatch(r'(?=.{4,253}\Z)(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.)+[A-Za-z]{2,63}',sys.argv[1]):
    raise SystemExit('METOD_DOMAIN is ongeldig')
PY
    proof_headers="$(curl --silent --show-error --max-time 5 --output /dev/null \
      --dump-header - --write-out $'\nMETOD_STATUS=%{http_code}\n' \
      --resolve "${proof_domain}:443:127.0.0.1" "https://${proof_domain}/")" \
      || fail "Live production-maintenance kon niet lokaal worden bevraagd"
  else
    proof_port="${STAGING_PUBLIC_PORT:-8790}"
    proof_bind="${STAGING_BIND_ADDRESS:-127.0.0.1}"
    proof_url="$(/usr/bin/python3 -I -S -B - "$proof_port" "$proof_bind" <<'PY'
import ipaddress,sys
try:
    port=int(sys.argv[1])
    address=ipaddress.ip_address(sys.argv[2])
except ValueError as exc:
    raise SystemExit(f'ongeldig staging recovery-eindpunt: {exc}')
if not 1024 <= port <= 65535:
    raise SystemExit('ongeldige stagingpoort voor recoverybewijs')
if address.version != 4:
    raise SystemExit('staging recoverybewijs vereist IPv4')
if address.is_unspecified:
    address=ipaddress.ip_address('127.0.0.1')
elif not address.is_loopback:
    raise SystemExit('recoverybewijs mag alleen lokale Nginx bevragen')
print(f'http://{address}:{port}/')
PY
)" || fail "Staging recovery-eindpunt is ongeldig"
    proof_headers="$(curl --silent --show-error --max-time 5 --output /dev/null \
      --dump-header - --write-out $'\nMETOD_STATUS=%{http_code}\n' "$proof_url")" \
      || fail "Live staging-maintenance kon niet lokaal worden bevraagd"
  fi
  proof_headers="${proof_headers//$'\r'/}"
  grep -Fxq 'METOD_STATUS=503' <<<"$proof_headers" \
    || fail "Recovery-resume vereist live HTTP 503 maintenance"
  grep -Fiqx 'Retry-After: 120' <<<"$proof_headers" \
    || fail "Recovery-resume mist de live maintenance Retry-After-header"
  if [[ "${METOD_DEPLOY_MODE:-staging}" != "production" ]]; then
    grep -Fiqx 'X-METOD-Environment: staging-maintenance' <<<"$proof_headers" \
      || fail "Recovery-resume mist de live staging-maintenance-identiteit"
  fi
  info "Live lokale Nginx-maintenance onafhankelijk van het configuratiebestand op schijf aangetoond."
}

seal_managed_release_tree(){
  local release_root="$1"
  [[ -d "$release_root" && ! -L "$release_root" ]] \
    || fail "Beheerde releaseboom ontbreekt of is een symlink: $release_root"
  validate_release_manifest_tree "$release_root"
  chown -R root:root -- "$release_root"
  find "$release_root" -type d -exec chmod 0555 {} +
  find "$release_root" -type f -exec chmod 0444 {} +
  find "$release_root" -type f \( -name '*.sh' -o -name '*.py' \) -exec chmod 0555 {} +
  /usr/bin/python3 -I -S -B - "$release_root" <<'PY'
import stat,sys
from pathlib import Path
root=Path(sys.argv[1])
for path in (root,*root.rglob('*')):
    metadata=path.lstat()
    if metadata.st_uid != 0 or metadata.st_gid != 0:
        raise SystemExit(f'beheerde release is niet root-owned: {path}')
    if metadata.st_mode & 0o222:
        raise SystemExit(f'beheerde release is schrijfbaar: {path}')
    if stat.S_ISREG(metadata.st_mode) and metadata.st_nlink != 1:
        raise SystemExit(f'beheerd releasebestand is meervoudig gelinkt: {path}')
PY
  validate_release_manifest_tree "$release_root"
}

verify_sealed_release_tree(){
  local release_root="$1"
  validate_release_manifest_tree "$release_root"
  /usr/bin/python3 -I -S -B - "$release_root" <<'PY'
import stat,sys
from pathlib import Path
root=Path(sys.argv[1])
for path in (root,*root.rglob('*')):
    metadata=path.lstat()
    if metadata.st_uid != 0 or metadata.st_gid != 0:
        raise SystemExit(f'verzegelde release is niet root-owned: {path}')
    if stat.S_ISDIR(metadata.st_mode):
        expected=0o555
    elif stat.S_ISREG(metadata.st_mode):
        expected=0o555 if path.suffix.lower() in {'.sh','.py'} else 0o444
        if metadata.st_nlink != 1:
            raise SystemExit(f'verzegeld releasebestand is meervoudig gelinkt: {path}')
    else:
        raise SystemExit(f'onverwacht type in verzegelde release: {path}')
    observed=stat.S_IMODE(metadata.st_mode)
    if observed != expected:
        raise SystemExit(f'verzegelde releasemode wijkt af: {path}: {observed:o}!={expected:o}')
PY
}

sealed_release_metadata_is_exact(){
  local release_root="$1"
  /usr/bin/python3 -I -S -B - "$release_root" <<'PY'
import stat,sys
from pathlib import Path
root=Path(sys.argv[1])
try:
    paths=(root,*root.rglob('*'))
    for path in paths:
        metadata=path.lstat()
        if metadata.st_uid != 0 or metadata.st_gid != 0:
            raise ValueError
        if stat.S_ISDIR(metadata.st_mode):
            expected=0o555
        elif stat.S_ISREG(metadata.st_mode):
            expected=0o555 if path.suffix.lower() in {'.sh','.py'} else 0o444
            if metadata.st_nlink != 1:
                raise ValueError
        else:
            raise ValueError
        if stat.S_IMODE(metadata.st_mode) != expected:
            raise ValueError
except (OSError,ValueError):
    raise SystemExit(1)
PY
}

STATE_GATE_ARGS=()
if [[ "${METOD_DEPLOY_MODE:-staging}" == "production" ]]; then
  STATE_GATE_ARGS+=(--production)
fi

case "$INSTALL_MODE" in
  upgrade)
    if [[ -L "$CURRENT_LINK" ]]; then
      PREVIOUS_TARGET="$(readlink -f "$CURRENT_LINK")"
      if [[ "$PREVIOUS_TARGET" == "$LEGACY_APP" ]]; then
        [[ -d "$LEGACY_APP/app" ]] || fail "Legacy current-link mist app-map"
        verify_legacy_r7
      elif [[ "$PREVIOUS_TARGET" == "$RELEASES_DIR/"* ]]; then
        [[ -f "$PREVIOUS_TARGET/SHA256SUMS.txt" ]] || fail "Huidige immutable release mist checksummanifest"
        # The old tree may be uploader-owned. Its own manifest cannot authorize
        # resealing: bind it first to the complete digest in the directory name
        # beneath an independently root-controlled release-parent chain.
        CURRENT_RELEASE_HASH_BEFORE="$(validate_release_manifest_tree "$PREVIOUS_TARGET" digest)" \
          || fail "Huidige immutable release faalde inhoudsvalidatie vóór metadataherstel"
        CURRENT_RELEASE_HASH_EXPECTED="$(run_release_python "$STAGE" tools/deployment_safety.py baseline \
          --release "$PREVIOUS_TARGET" --releases-dir "$RELEASES_DIR" --version "$VERSION" \
          --observed-manifest-sha256 "$CURRENT_RELEASE_HASH_BEFORE")" \
          || fail "Actieve baseline mist een onafhankelijk vertrouwde oorspronkelijke manifestdigest; geen metadataherstel uitgevoerd"
        if ! sealed_release_metadata_is_exact "$PREVIOUS_TARGET"; then
          info "Actieve byte-exacte baseline heeft uitsluitend verzegelingsdrift; gecontroleerd metadataherstel gestart."
          seal_managed_release_tree "$PREVIOUS_TARGET"
          CURRENT_RELEASE_HASH_AFTER="$(validate_release_manifest_tree "$PREVIOUS_TARGET" digest)" \
            || fail "Huidige immutable release faalde hervalidatie na metadataherstel"
          [[ "$CURRENT_RELEASE_HASH_AFTER" == "$CURRENT_RELEASE_HASH_BEFORE" ]] \
            || fail "Manifestdigest van actieve baseline wijzigde tijdens metadataherstel"
          [[ "$CURRENT_RELEASE_HASH_AFTER" == "$CURRENT_RELEASE_HASH_EXPECTED" ]] \
            || fail "Actieve baseline wijkt na metadataherstel af van de vertrouwde oorspronkelijke release"
          info "Actieve baseline byte-exact, root-owned en read-only opnieuw verzegeld."
        fi
        verify_sealed_release_tree "$PREVIOUS_TARGET"
        info "Huidige immutable release read-only volledig geverifieerd."
      else
        fail "Current-link wijst niet naar legacy baseline of beheerde immutable release: $PREVIOUS_TARGET"
      fi
    elif [[ -d "$LEGACY_APP/app" ]]; then
      PREVIOUS_TARGET="$LEGACY_APP"
      verify_legacy_r7
    else
      fail "Geen bekende FIX660R7-baseline of immutable current release gevonden"
    fi
    ;;
  recovery)
    [[ "$RECOVERY_ACK" == "ORPHANED_RELEASE_AND_STATE_CONFIRMED" ]] || fail "Recovery vereist exacte METOD_RECOVERY_ACK"
    [[ ! -d "$LEGACY_APP/app" ]] || fail "Recovery is alleen toegestaan wanneer de legacy-code werkelijk ontbreekt"
    if [[ -e "$CURRENT_LINK" || -L "$CURRENT_LINK" ]]; then
      [[ -L "$CURRENT_LINK" ]] || fail "Recovery-resume vereist een canonieke symlink als current-pointer"
      RECOVERY_RESUME_TARGET="$(readlink -f "$CURRENT_LINK")"
      [[ "$RECOVERY_RESUME_TARGET" == "$RELEASES_DIR/"* && -d "$RECOVERY_RESUME_TARGET" ]] || fail "Recovery-resume pointer wijst niet naar een beheerde release"
      [[ -f "$RECOVERY_RESUME_TARGET/SHA256SUMS.txt" ]] || fail "Recovery-resume release mist checksummanifest"
      RECOVERY_RESUME_HASH="$(validate_release_manifest_tree "$RECOVERY_RESUME_TARGET" digest)"
      run_release_python "$STAGE" tools/deployment_safety.py baseline \
        --release "$RECOVERY_RESUME_TARGET" --releases-dir "$RELEASES_DIR" --version "$VERSION" \
        --observed-manifest-sha256 "$RECOVERY_RESUME_HASH" \
        || fail "Recovery-resume mist de onafhankelijk vertrouwde release-identiteit"
      verify_sealed_release_tree "$RECOVERY_RESUME_TARGET"
      prove_live_recovery_maintenance
      if systemctl is-active --quiet metod-pax.service; then
        info "Achtergebleven backendproces van een eerdere fail-closed deploy wordt onder bewezen maintenance gestopt."
        systemctl stop metod-pax.service
        if systemctl is-active --quiet metod-pax.service; then
          fail "Recovery-resume kon de achtergebleven service niet stoppen"
        fi
      fi
      RECOVERY_RESUME=1
      info "Eerdere fail-closed recovery aantoonbaar hervat vanaf een immutable managed release."
    else
      [[ ! -e "$CURRENT_LINK" && ! -L "$CURRENT_LINK" ]] || fail "Recovery current-pointer heeft een ongeldige toestand"
    fi
    [[ -f /etc/systemd/system/metod-pax.service && ! -L /etc/systemd/system/metod-pax.service ]] || fail "Bestaande root-owned systemd-unit ontbreekt voor recoverybewijs"
    [[ "$(stat -c '%u:%a' /etc/systemd/system/metod-pax.service)" =~ ^0:(600|640|644)$ ]] || fail "Systemd-unit heeft onverwachte eigenaar/rechten"
    grep -Fxq "WorkingDirectory=$CURRENT_LINK/app" /etc/systemd/system/metod-pax.service || fail "Systemd-unit mist canonieke WorkingDirectory"
    grep -Fxq "ExecStart=/usr/bin/python3 -B $CURRENT_LINK/app/server_py.py" /etc/systemd/system/metod-pax.service || fail "Systemd-unit mist canonieke ExecStart"
    run_release_python "$STAGE" tools/install_state_gate.py --state-root "$STATE_DIR" --credentials "$CREDS_FILE" --allow-legacy-single-user --allow-legacy-password-hash --production
    CREDENTIAL_MIGRATION_STAGE="/run/metod-pax-credential-migration.${TS}.$$.json"
    run_release_python "$STAGE" tools/migrate_legacy_admin_credentials.py --credentials "$CREDS_FILE" --prepare "$CREDENTIAL_MIGRATION_STAGE"
    info "Orphan-recovery expliciet en fail-closed geautoriseerd; er wordt geen verdwenen baseline vervalst."
    ;;
  bootstrap)
    [[ "$RECOVERY_ACK" == "CLEAN_SERVER_STATE_IMPORT_CONFIRMED" ]] || fail "Bootstrap vereist exacte METOD_RECOVERY_ACK"
    [[ ! -e "$CURRENT_LINK" && ! -e "$LEGACY_APP" ]] || fail "Bootstrap vereist een schone canonieke coderoot"
    [[ ! -e /etc/systemd/system/metod-pax.service ]] || fail "Bootstrap weigert een reeds geïnstalleerde METOD/PAX-service"
    BOOTSTRAP_SERVICE_LOAD_STATE="$(systemctl show metod-pax.service --property=LoadState --value)" \
      || fail "Werkelijke systemd load-state kon niet worden bepaald"
    [[ "$BOOTSTRAP_SERVICE_LOAD_STATE" == "not-found" ]] \
      || fail "Bootstrap weigert een bestaande systemd-unit uit iedere load path: $BOOTSTRAP_SERVICE_LOAD_STATE"
    run_release_python "$STAGE" tools/install_state_gate.py --state-root "$STATE_DIR" --credentials "$CREDS_FILE" "${STATE_GATE_ARGS[@]}"
    info "Schone-serverbootstrap met vooraf gevalideerde externe state bevestigd."
    ;;
esac

install -d -o root -g root -m 0755 "$RELEASES_DIR" "$BACKUP_ROOT"
reserve_config_backup
if [[ -e "$RELEASE_DIR" || -L "$RELEASE_DIR" ]]; then
  [[ -d "$RELEASE_DIR" && ! -L "$RELEASE_DIR" ]] || fail "Bestaande target release is geen echte directory"
  [[ -f "$RELEASE_DIR/SHA256SUMS.txt" ]] || fail "Bestaande target release is incompleet"
  TARGET_RELEASE_HASH="$(validate_release_manifest_tree "$RELEASE_DIR" digest)" \
    || fail "Bestaande target release faalde vertrouwde manifestvalidatie"
  [[ "$TARGET_RELEASE_HASH" == "$RELEASE_HASH" ]] \
    || fail "Bestaande target release hoort niet bij de volledige manifestdigest"
  cmp -s "$STAGE/SHA256SUMS.txt" "$RELEASE_DIR/SHA256SUMS.txt" \
    || fail "Bestaande target release heeft geen byte-exact gelijk manifest"
  # Een afgebroken oudere poging kan de definitieve, nog niet actieve target
  # hebben achtergelaten voordat alle metadata duurzaam was verzegeld. Alleen
  # nadat de volledige fileset, iedere inhoudshash en het manifest zelf exact
  # gelijk zijn aan de geauthenticeerde stage mag die inactieve target worden
  # hersteld. De huidige live target is hierboven al afzonderlijk immutable
  # geverifieerd; inhoudsdrift blijft dus altijd fail-closed.
  seal_managed_release_tree "$RELEASE_DIR"
  verify_sealed_release_tree "$RELEASE_DIR"
  info "Bestaande byte-exacte target veilig opnieuw verzegeld en hergebruikt."
else
  RELEASE_TMP="$RELEASES_DIR/.${RELEASE_ID}.stage.$$"
  [[ ! -e "$RELEASE_TMP" ]] || fail "Tijdelijke releasefolder bestaat al: $RELEASE_TMP"
  # De kopie leeft direct in een root-private directory en rsync maakt alle
  # ontvangers root-owned; zo kan de eigenaar van een staged bron niet tussen
  # validatie en sealing in de targetboom schrijven.
  install -d -o root -g root -m 0700 "$RELEASE_TMP"
  rsync -a --one-file-system --delete --chown=root:root --chmod=D0700,F0600 "$STAGE/" "$RELEASE_TMP/"
  TARGET_RELEASE_HASH="$(validate_release_manifest_tree "$RELEASE_TMP" digest)" \
    || fail "Gekopieerde release faalde vertrouwde manifestvalidatie"
  [[ "$TARGET_RELEASE_HASH" == "$RELEASE_HASH" ]] \
    || fail "Gekopieerde release hoort niet bij de volledige manifestdigest"
  cmp -s "$STAGE/SHA256SUMS.txt" "$RELEASE_TMP/SHA256SUMS.txt" \
    || fail "Gekopieerde release heeft geen byte-exact gelijk staged manifest"
  seal_managed_release_tree "$RELEASE_TMP"
  mv -T "$RELEASE_TMP" "$RELEASE_DIR"
  fsync_rollback_directory "$RELEASES_DIR" \
    || fail "Releaseparent kon na targetcommit niet worden gefsynct"
  RELEASE_TMP=""
  verify_sealed_release_tree "$RELEASE_DIR"
  info "Nieuwe target na atomische publicatie opnieuw volledig geverifieerd."
fi

# Alle latere release-Python komt uit de definitief gevalideerde en verzegelde
# target. De private bronkopie is niet langer nodig en wordt pre-commit gewist.
STAGE="$RELEASE_DIR"
if ! rm -rf -- "$STAGE_SNAPSHOT"; then
  fail "Root-private stagesnapshot kon niet worden verwijderd"
fi
STAGE_SNAPSHOT=""

for live in /etc/systemd/system/metod-pax.service "$ENV_DIR/metod-pax.env" \
            /etc/nginx/sites-available/metod-pax /etc/nginx/sites-enabled/metod-pax \
            /etc/nginx/sites-available/metod-pax-8790 /etc/nginx/sites-enabled/metod-pax-8790 \
            /etc/nginx/conf.d/metod-pax-limits.conf /etc/logrotate.d/metod-pax-nginx \
            /etc/systemd/system/multi-user.target.wants/metod-pax.service; do
  key="$(printf '%s' "$live" | sha256sum | awk '{print $1}')"
  if [[ -e "$live" || -L "$live" ]]; then cp -a --no-dereference "$live" "$CONFIG_BACKUP/$key.present"; fi
done
info "Configbackup: $CONFIG_BACKUP"
TOUCHED=1

# A failed recovery can leave the generated limits file on disk after nginx
# rejected a host-level duplicate directive.  Only during a fully proven
# recovery-resume, normalize that one managed file after it has been backed up
# and before the first nginx -t.  Unknown content always fails closed.
if [[ "$RECOVERY_RESUME" -eq 1 && -e /etc/nginx/conf.d/metod-pax-limits.conf ]]; then
  /usr/bin/python3 -I -S -B - /etc/nginx/conf.d/metod-pax-limits.conf <<'PY'
import os,stat,sys
from pathlib import Path
path=Path(sys.argv[1])
metadata=path.lstat()
if not stat.S_ISREG(metadata.st_mode) or metadata.st_uid != 0 or metadata.st_nlink != 1:
    raise SystemExit('managed Nginx-limitsbestand heeft onveilige metadata')
if metadata.st_mode & 0o022:
    raise SystemExit('managed Nginx-limitsbestand is schrijfbaar voor group/other')
required=(
    'limit_req_zone $binary_remote_addr zone=metod_general:10m rate=10r/s;',
    'limit_req_zone $binary_remote_addr zone=metod_jobs:10m rate=2r/m;',
    'limit_req_zone $binary_remote_addr zone=metod_auth:10m rate=5r/m;',
    'limit_conn_zone $binary_remote_addr zone=metod_conn:10m;',
)
legacy=(
    'server_tokens off;',
    'proxy_headers_hash_max_size 1024;',
    'proxy_headers_hash_bucket_size 128;',
)
lines=tuple(line.strip() for line in path.read_text(encoding='utf-8',errors='strict').splitlines() if line.strip())
if len(lines) != len(set(lines)) or set(lines) not in (set(required),set(required+legacy)):
    raise SystemExit('managed Nginx-limitsbestand bevat onbekende of dubbele directives')
temporary=path.with_name(f'.{path.name}.resume.{os.getpid()}')
fd=os.open(temporary,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o644)
try:
    with os.fdopen(fd,'w',encoding='utf-8',newline='\n') as handle:
        handle.write('\n'.join(required)+'\n'); handle.flush(); os.fsync(handle.fileno())
    os.replace(temporary,path)
    directory_fd=os.open(path.parent,os.O_RDONLY|getattr(os,'O_DIRECTORY',0))
    try: os.fsync(directory_fd)
    finally: os.close(directory_fd)
finally:
    temporary.unlink(missing_ok=True)
PY
  chmod 0644 /etc/nginx/conf.d/metod-pax-limits.conf
  info "Beheerd Nginx-limitsbestand fail-closed genormaliseerd voor recovery-resume."
fi

if [[ -f "$STATE_DIR/.fix660r8_external_state_v1.json" ]]; then
  run_release_python "$STAGE" tools/install_state_gate.py \
    --state-root "$STATE_DIR" --credentials "$CREDS_FILE" "${STATE_GATE_ARGS[@]}"
  info "Bestaande gemarkeerde externe state vóór maintenance volledig gevalideerd."
fi

# Drain the public edge before state migration/switch. The new backend is fully
# smoke-tested behind this maintenance response; only the final nginx reload
# reopens traffic. This makes a pointer rollback unable to lose deploy-window data.
if [[ "${METOD_DEPLOY_MODE:-staging}" == "production" ]]; then
  [[ -n "${METOD_DOMAIN:-}" ]] || fail "METOD_DOMAIN ontbreekt voor production maintenance"
  /usr/bin/python3 -I -S -B - "${METOD_DOMAIN}" <<'PY'
import re,sys
if not re.fullmatch(r'(?=.{4,253}\Z)(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.)+[A-Za-z]{2,63}',sys.argv[1]):
    raise SystemExit('METOD_DOMAIN is ongeldig')
PY
  MAINT_CERT="${TLS_CERT_FILE:-/etc/letsencrypt/live/${METOD_DOMAIN}/fullchain.pem}"
  MAINT_KEY="${TLS_KEY_FILE:-/etc/letsencrypt/live/${METOD_DOMAIN}/privkey.pem}"
  [[ "$MAINT_CERT" =~ ^/[A-Za-z0-9._/-]+$ && "$MAINT_KEY" =~ ^/[A-Za-z0-9._/-]+$ ]] || fail "TLS-paden hebben een onveilig formaat"
  [[ -r "$MAINT_CERT" && -r "$MAINT_KEY" ]] || fail "TLS-bestanden ontbreken voor maintenance"
  MAINT_SITE_TMP="/etc/nginx/sites-available/.metod-pax.maintenance.$$"
  cat > "$MAINT_SITE_TMP" <<EOF
server { listen 80; listen [::]:80; server_name ${METOD_DOMAIN}; return 503; }
server {
  listen 443 ssl; listen [::]:443 ssl; server_name ${METOD_DOMAIN};
  ssl_certificate $MAINT_CERT; ssl_certificate_key $MAINT_KEY;
  add_header Retry-After 120 always; return 503;
}
EOF
  chmod 0644 "$MAINT_SITE_TMP"
  mv -f "$MAINT_SITE_TMP" /etc/nginx/sites-available/metod-pax
else
  STAGING_PORT_VALUE="${STAGING_PUBLIC_PORT:-8790}"
  STAGING_BIND_VALUE="${STAGING_BIND_ADDRESS:-127.0.0.1}"
  STAGING_CIDR_VALUE="${STAGING_ALLOWED_CIDR:-}"
  /usr/bin/python3 -I -S -B - "$STAGING_PORT_VALUE" "$STAGING_BIND_VALUE" "$STAGING_CIDR_VALUE" <<'PY'
import ipaddress,sys
port=int(sys.argv[1])
if not 1024 <= port <= 65535: raise SystemExit('ongeldige stagingpoort')
bind=ipaddress.ip_address(sys.argv[2])
if bind.version != 4: raise SystemExit('staging bind moet IPv4 zijn')
if not bind.is_loopback and not sys.argv[3]: raise SystemExit('remote staging vereist STAGING_ALLOWED_CIDR')
if sys.argv[3]: ipaddress.ip_network(sys.argv[3],strict=False)
PY
  MAINT_SITE_TMP="/etc/nginx/sites-available/.metod-pax.maintenance.$$"
  {
    echo 'server {'
    echo "  listen $STAGING_BIND_VALUE:$STAGING_PORT_VALUE; server_name _;"
    if [[ -n "$STAGING_CIDR_VALUE" ]]; then
      echo "  allow $STAGING_CIDR_VALUE;"
      echo '  deny all;'
    fi
    echo '  add_header Retry-After 120 always; add_header X-METOD-Environment staging-maintenance always; return 503;'
    echo '}'
  } > "$MAINT_SITE_TMP"
  chmod 0644 "$MAINT_SITE_TMP"
  mv -f "$MAINT_SITE_TMP" /etc/nginx/sites-available/metod-pax
fi
rm -f /etc/nginx/sites-enabled/metod-pax-8790
ln -sfn /etc/nginx/sites-available/metod-pax /etc/nginx/sites-enabled/metod-pax
nginx -t
systemctl reload nginx
if systemctl is-active --quiet metod-pax.service; then
  DEPLOY_DRAIN_TIMEOUT="${METOD_DEPLOY_DRAIN_TIMEOUT_SECONDS:-120}"
  [[ "$DEPLOY_DRAIN_TIMEOUT" =~ ^[0-9]{1,4}$ ]] \
    || fail "METOD_DEPLOY_DRAIN_TIMEOUT_SECONDS moet een begrensd geheel getal zijn"
  (( 10#$DEPLOY_DRAIN_TIMEOUT >= 15 && 10#$DEPLOY_DRAIN_TIMEOUT <= 900 )) \
    || fail "METOD_DEPLOY_DRAIN_TIMEOUT_SECONDS moet 15..900 zijn"
  /usr/bin/python3 -I -S -B - "$STATE_DIR" "$DEPLOY_DRAIN_TIMEOUT" <<'PY'
import json,os,sys,time
from pathlib import Path
root=Path(sys.argv[1]); deadline=time.monotonic()+int(sys.argv[2])
active_states={'ACCEPTED','PREPARING','PROCESSING','FINALIZING','CANCEL_REQUESTED'}
quiet_polls=0
while True:
    active=invalid=entries=0
    jobs=root/'jobs'
    if jobs.is_dir():
        with os.scandir(jobs) as scan:
            for item in scan:
                entries+=1
                if entries>1_000_000:
                    raise SystemExit('jobdrain overschrijdt de entrygrens')
                if not item.is_dir(follow_symlinks=False):
                    continue
                state=Path(item.path)/'job_state.json'
                if not state.exists():
                    continue
                try:
                    value=json.loads(state.read_text(encoding='utf-8',errors='strict'))
                    status=str(value.get('state') or '').strip().upper() if isinstance(value,dict) else ''
                except Exception:
                    invalid+=1; continue
                if status in active_states:
                    active+=1
    processing=root/'queue'/'processing'
    queue_busy=sum(1 for item in processing.glob('*.json') if item.is_file()) if processing.is_dir() else 0
    if invalid:
        raise SystemExit(f'jobdrain vond {invalid} onleesbare state-record(s)')
    if active==0 and queue_busy==0:
        quiet_polls+=1
        if quiet_polls>=2:
            break
    else:
        quiet_polls=0
    if time.monotonic()>=deadline:
        raise SystemExit(f'jobdrain timeout: {active} actieve job(s), {queue_busy} queue-item(s)')
    time.sleep(1)
PY
  info "Actieve jobs en processingqueue zijn onder maintenance aantoonbaar gedraind."
fi
SERVICE_LOAD_STATE="$(systemctl show metod-pax.service --property=LoadState --value)" \
  || fail "Systemd load-state van metod-pax kon niet worden bepaald"
if [[ "$SERVICE_LOAD_STATE" == "not-found" ]]; then
  [[ "$INSTALL_MODE" == "bootstrap" ]] \
    || fail "Bestaande installatie mist de verwachte systemd-unit"
else
  [[ "$INSTALL_MODE" != "bootstrap" ]] \
    || fail "Tijdens bootstrap verscheen onverwacht een systemd-unit; bestaande unit wordt niet gestopt"
  systemctl stop metod-pax.service \
    || fail "Backendservice kon niet gecontroleerd worden gestopt"
fi
SERVICE_ACTIVE_STATE="$(systemctl show metod-pax.service --property=ActiveState --value)" \
  || fail "Systemd active-state van metod-pax kon niet worden bepaald"
case "$SERVICE_ACTIVE_STATE" in
  inactive|failed) ;;
  *) fail "Backendservice is na stop niet aantoonbaar inactief: $SERVICE_ACTIVE_STATE" ;;
esac
SERVICE_STOPPED=1

if [[ "$INSTALL_MODE" == "recovery" ]]; then
  RECOVERY_CHECKPOINT="$(mktemp -d "$BACKUP_ROOT/ORPHAN_RECOVERY_${TS}.XXXXXXXX")" \
    || fail "Unieke recoverycheckpointmap kon niet no-clobber worden gereserveerd"
  chown root:root "$RECOVERY_CHECKPOINT"
  chmod 0700 "$RECOVERY_CHECKPOINT"
  STATE_BYTES="$(du -sb "$STATE_DIR" | awk '{print $1}')"
  AVAILABLE_BYTES="$(df -PB1 "$BACKUP_ROOT" | awk 'NR==2 {print $4}')"
  [[ "$STATE_BYTES" =~ ^[0-9]+$ && "$AVAILABLE_BYTES" =~ ^[0-9]+$ ]] || fail "Recovery-opslagcapaciteit kon niet worden bepaald"
  (( AVAILABLE_BYTES >= STATE_BYTES + 1073741824 )) || fail "Onvoldoende vrije ruimte voor volledige recoverycheckpoint plus 1 GiB reserve"
  tar --one-file-system --numeric-owner --xattrs --acls -cpf "$RECOVERY_CHECKPOINT/external-state.tar" -C "$(dirname "$STATE_DIR")" "$(basename "$STATE_DIR")"
  chmod 0600 "$RECOVERY_CHECKPOINT/external-state.tar"
  tar -tf "$RECOVERY_CHECKPOINT/external-state.tar" >/dev/null
  (cd "$RECOVERY_CHECKPOINT" && sha256sum external-state.tar > external-state.tar.sha256)
  chmod 0600 "$RECOVERY_CHECKPOINT/external-state.tar.sha256"
  install -d -o root -g root -m 0700 "$RECOVERY_CHECKPOINT/config"
  cp -a --no-dereference "$CREDS_FILE" "$RECOVERY_CHECKPOINT/config/admin_credentials.live.json"
  [[ -f "$ENV_DIR/metod-pax.env" ]] && cp -a --no-dereference "$ENV_DIR/metod-pax.env" "$RECOVERY_CHECKPOINT/config/metod-pax.env"
  chmod -R go-rwx "$RECOVERY_CHECKPOINT"
  printf 'RECOVERY_CHECKPOINT_COMPLETE_V1\n' > "$RECOVERY_CHECKPOINT/SNAPSHOT_COMPLETE"
  chmod 0600 "$RECOVERY_CHECKPOINT/SNAPSHOT_COMPLETE"
  info "Volledige pre-switch recoverycheckpoint: $RECOVERY_CHECKPOINT"
  # Only prune after the new complete snapshot is available. Until edge commit,
  # the first recovery snapshot and this current one are mandatory keeps.
  if ! run_release_python "$STAGE" tools/prune_deploy_history.py --recovery-only \
      --backup-root "$BACKUP_ROOT" --current-recovery-checkpoint "$RECOVERY_CHECKPOINT" \
      --recovery-keep "${METOD_RECOVERY_KEEP:-2}" \
      --recovery-max-age-days "${METOD_RECOVERY_MAX_AGE_DAYS:-30}" \
      --recovery-max-bytes "${METOD_RECOVERY_MAX_BYTES:-21474836480}"; then
    info "WAARSCHUWING: recoveryretentie faalde; bestaande checkpoints blijven beschikbaar."
  fi
  run_release_python "$STAGE" tools/migrate_legacy_admin_credentials.py --credentials "$CREDS_FILE" --apply "$CREDENTIAL_MIGRATION_STAGE"
  run_release_python "$STAGE" tools/install_state_gate.py --state-root "$STATE_DIR" --credentials "$CREDS_FILE" --production
  info "Admincredentials atomair naar het individuele users[]-contract gebracht en opnieuw gevalideerd."
fi

id -u metod-pax >/dev/null 2>&1 || useradd --system --home-dir "$STATE_DIR" --shell /usr/sbin/nologin metod-pax
install -d -o metod-pax -g metod-pax -m 0750 "$STATE_DIR"
STATE_MARKER="$STATE_DIR/.fix660r8_external_state_v1.json"
if [[ ! -f "$STATE_MARKER" ]]; then
  if find "$STATE_DIR" -mindepth 1 -maxdepth 1 -print -quit | grep -q .; then
    fail "$STATE_DIR bevat al data maar mist de R8-migratiemarkering; handmatige beoordeling nodig"
  fi
  STATE_STAGE="${STATE_DIR}.migrate.${TS}.$$"
  [[ ! -e "$STATE_STAGE" ]] || fail "Tijdelijke state-migratiemap bestaat al: $STATE_STAGE"
  install -d -o metod-pax -g metod-pax -m 0750 "$STATE_STAGE"
  for dir in jobs drafts index requests queue archive system backups decor_media embedded_dxfs config; do
    if [[ -d "$LEGACY_APP/app/$dir" ]]; then
      install -d -m 0750 "$STATE_STAGE/$dir"
      rsync -a "$LEGACY_APP/app/$dir/" "$STATE_STAGE/$dir/"
    fi
  done
  if [[ -d "$LEGACY_APP/app/_client_logs" ]]; then
    install -d -m 0750 "$STATE_STAGE/client_logs"
    rsync -a "$LEGACY_APP/app/_client_logs/" "$STATE_STAGE/client_logs/"
  fi
  for file in material_library.json embedded_dxfs_manifest.json config_notify.json; do
    [[ -f "$LEGACY_APP/app/$file" ]] && cp -a "$LEGACY_APP/app/$file" "$STATE_STAGE/$file"
  done
  [[ -d "$STATE_STAGE/embedded_dxfs" ]] || cp -a "$RELEASE_DIR/app/embedded_dxfs" "$STATE_STAGE/embedded_dxfs"
  [[ -f "$STATE_STAGE/embedded_dxfs_manifest.json" ]] || cp -a "$RELEASE_DIR/app/embedded_dxfs_manifest.json" "$STATE_STAGE/embedded_dxfs_manifest.json"
  [[ -f "$STATE_STAGE/config/pricing_active.json" ]] || { install -d -m 0750 "$STATE_STAGE/config"; cp -a "$RELEASE_DIR/app/config/pricing_active.json" "$STATE_STAGE/config/pricing_active.json"; }
  /usr/bin/python3 -I -S -B - "$STATE_STAGE" <<'PY'
import os,stat,sys
from pathlib import Path
root=Path(sys.argv[1])
entries=0
stack=[root]
while stack:
    directory=stack.pop()
    with os.scandir(directory) as scan:
        for item in scan:
            entries += 1
            if entries > 1_000_000:
                raise SystemExit('state-migratie bevat te veel entries')
            mode=item.stat(follow_symlinks=False).st_mode
            if stat.S_ISLNK(mode):
                raise SystemExit(f'symlink in state-migratie is verboden: {item.path}')
            if stat.S_ISDIR(mode):
                stack.append(Path(item.path))
            elif not stat.S_ISREG(mode):
                raise SystemExit(f'speciaal bestand in state-migratie is verboden: {item.path}')
print(f'State-migratie bestandstypen OK: {entries} entries')
PY
  /usr/bin/python3 -I -S -B -c 'import sys; sys.path.insert(0,sys.argv.pop(1)); exec(compile(sys.stdin.read(),"<trusted-state-marker>","exec"))' \
    "$RELEASE_DIR/app" "$STATE_STAGE/.fix660r8_external_state_v1.json" "$LEGACY_APP" <<'PY'
import sys,time
from pathlib import Path
from safety_contracts import durable_write_json
durable_write_json(Path(sys.argv[1]), {'schemaVersion':1,'migratedAt':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'source':sys.argv[2]}, mode=0o640)
PY
  chown -R metod-pax:metod-pax "$STATE_STAGE"
  rmdir "$STATE_DIR"
  mv "$STATE_STAGE" "$STATE_DIR"
  STATE_MIGRATED=1
  /usr/bin/python3 -I -S -B - "$STATE_DIR" <<'PY'
import os,sys
from pathlib import Path
root=Path(sys.argv[1])
fd=os.open(str(root.parent),os.O_RDONLY|getattr(os,'O_DIRECTORY',0))
try: os.fsync(fd)
finally: os.close(fd)
PY
fi
if [[ "$STATE_MIGRATED" -eq 1 ]]; then
  run_release_python "$STAGE" tools/install_state_gate.py \
    --state-root "$STATE_DIR" --credentials "$CREDS_FILE" "${STATE_GATE_ARGS[@]}"
  info "Gemigreerde externe state eenmaal volledig gevalideerd."
fi
# Existing marked state was already type-checked by install_state_gate before
# maintenance. Imported/migrated state is chowned exactly once in its private
# staging tree, so avoid a second full-tree ctime rewrite during downtime.
chown metod-pax:metod-pax "$STATE_DIR"
chmod 0750 "$STATE_DIR"

/usr/bin/python3 -I -S -B - "$STATE_DIR/material_library.json" <<'PY'
import json,sys
p=sys.argv[1]; obj=json.load(open(p,encoding='utf-8')); records=obj.get('records') if isinstance(obj,dict) else None
active=[r for r in (records or []) if isinstance(r,dict) and r.get('active') is not False and r.get('published') is True and r.get('catalogMissing') is not True and r.get('catalogExcluded') is not True]
if not active: raise SystemExit('Actieve gepubliceerde catalogus is leeg; live switch geblokkeerd')
print(f'Catalogus vóór switch: {len(active)} actieve records')
PY

ln -sfn "$RELEASE_DIR" "$CURRENT_LINK.next"
mv -Tf "$CURRENT_LINK.next" "$CURRENT_LINK"
SWITCHED=1
fsync_rollback_directory "$(dirname "$CURRENT_LINK")" \
  || fail "Releasepointerdirectory kon niet duurzaam worden gecommit"

INSTALL_CATALOG_MIN_DEFAULT=1
if [[ "${METOD_DEPLOY_MODE:-staging}" == "production" ]]; then
  INSTALL_CATALOG_MIN_DEFAULT=597
fi
env \
  METOD_DEPLOY_LOCK_CONTRACT="$METOD_DEPLOY_LOCK_CONTRACT" \
  METOD_DEPLOY_LOCK_FD="$METOD_DEPLOY_LOCK_FD" \
  METOD_CURRENT_LINK="$CURRENT_LINK" \
  METOD_STATE_ROOT="$STATE_DIR" \
  METOD_ENV_DIR="$ENV_DIR" \
  ADMIN_CREDENTIALS_FILE="$CREDS_FILE" \
  METOD_DEPLOY_MODE="${METOD_DEPLOY_MODE:-staging}" \
  PUBLIC_ORIGIN="${PUBLIC_ORIGIN:-http://127.0.0.1:8790}" \
  STAGING_EXTERNAL_ORIGIN="${STAGING_EXTERNAL_ORIGIN:-}" \
  METOD_DOMAIN="${METOD_DOMAIN:-}" \
  TLS_CERT_FILE="${TLS_CERT_FILE:-}" \
  TLS_KEY_FILE="${TLS_KEY_FILE:-}" \
  OFFSITE_BACKUP_VERIFIED="${OFFSITE_BACKUP_VERIFIED:-0}" \
  OFFSITE_BACKUP_PROVIDER="${OFFSITE_BACKUP_PROVIDER:-}" \
  PRODUCTION_MIN_CATALOG_RECORDS="${PRODUCTION_MIN_CATALOG_RECORDS:-$INSTALL_CATALOG_MIN_DEFAULT}" \
  bash "$CURRENT_LINK/DEPLOY.sh"

# DEPLOY.sh only returns after the atomic nginx commit. From this point on,
# automated pointer rollback is forbidden because real requests may arrive.
SUCCESS=1
# Post-commit observability and housekeeping may report an incident, but may
# never turn a live commit into a pre-commit failure for an outer clean wrapper.
set +e
POSTCOMMIT_RELEASE_VALID=1
if [[ "$(readlink -f "$CURRENT_LINK")" != "$RELEASE_DIR" ]]; then
  info "WAARSCHUWING POSTCOMMIT: releasepointer wijst niet meer naar target; live incidentprocedure vereist."
  POSTCOMMIT_RELEASE_VALID=0
fi
if ! (validate_release_manifest_tree "$RELEASE_DIR" status >/dev/null); then
  info "WAARSCHUWING POSTCOMMIT: exacte manifest-fileset faalde herverificatie; target-Python en historycleanup worden niet uitgevoerd."
  POSTCOMMIT_RELEASE_VALID=0
fi
if ! systemctl is-active --quiet metod-pax.service; then
  info "WAARSCHUWING POSTCOMMIT: backendservice is niet actief; live incidentprocedure vereist."
fi
if ! nginx -t; then
  info "WAARSCHUWING POSTCOMMIT: Nginx-config faalt herverificatie; actieve config niet automatisch teruggedraaid."
fi
if ! rm -f /etc/nginx/sites-available/metod-pax-8790 /etc/nginx/sites-enabled/metod-pax-8790; then
  info "WAARSCHUWING POSTCOMMIT: historische staging-site kon niet worden opgeschoond."
fi
if [[ "$POSTCOMMIT_RELEASE_VALID" -eq 1 ]]; then
  RECOVERY_RETENTION_ARGS=(--recovery-committed)
  if [[ -n "$RECOVERY_CHECKPOINT" ]]; then
    RECOVERY_RETENTION_ARGS+=(--current-recovery-checkpoint "$RECOVERY_CHECKPOINT")
  fi
  if ! /usr/bin/python3 -I -S -B "$RELEASE_DIR/tools/prune_deploy_history.py" \
      --releases-dir "$RELEASES_DIR" \
      --backup-root "$BACKUP_ROOT" \
      --current-link "$CURRENT_LINK" \
      --previous-target "$PREVIOUS_TARGET" \
      --current-config-backup "$CONFIG_BACKUP" \
      --version "$VERSION" \
      --release-keep "${METOD_RELEASE_KEEP:-3}" \
      --release-max-age-days "${METOD_RELEASE_MAX_AGE_DAYS:-180}" \
      --release-max-bytes "${METOD_RELEASE_MAX_BYTES:-2147483648}" \
      --config-keep "${METOD_CONFIG_BACKUP_KEEP:-10}" \
      --config-max-age-days "${METOD_CONFIG_BACKUP_MAX_AGE_DAYS:-180}" \
      --config-max-bytes "${METOD_CONFIG_BACKUP_MAX_BYTES:-536870912}" \
      "${RECOVERY_RETENTION_ARGS[@]}" \
      --recovery-keep "${METOD_RECOVERY_KEEP:-2}" \
      --recovery-max-age-days "${METOD_RECOVERY_MAX_AGE_DAYS:-30}" \
      --recovery-max-bytes "${METOD_RECOVERY_MAX_BYTES:-21474836480}" \
      --install-log-root /var/log/metod-pax --current-install-log "$LOG"; then
    info "WAARSCHUWING: begrensde deployhistorycleanup faalde; verplichte herstelpunten blijven behouden."
  fi
else
  info "WAARSCHUWING POSTCOMMIT: historycleanup overgeslagen wegens onbewezen release-integriteit."
fi
info "R8 release actief: $RELEASE_DIR"
info "Externe state behouden onder: $STATE_DIR"
info "Rollback verandert uitsluitend releasepointer/config, nooit live state."
info "Deploylog: $LOG"
exit 0
