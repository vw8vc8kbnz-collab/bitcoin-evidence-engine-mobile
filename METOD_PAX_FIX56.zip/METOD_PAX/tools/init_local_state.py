#!/usr/bin/env python3
"""Create a new, explicit local development state; never overwrite live state."""

from __future__ import annotations
import argparse
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parents[1]


def initialize(target):
    target = Path(target).absolute()
    if target.exists() or target.is_symlink():
        raise ValueError("Kies een nieuwe, nog niet bestaande map")
    if target.parent.resolve() != target.parent:
        raise ValueError("Bovenliggende map mag geen symlink zijn")
    target.mkdir(mode=0o700, parents=True)
    config = target / "config"
    config.mkdir(mode=0o700)
    shutil.copyfile(ROOT / "app/config/pricing_active.json", config / "pricing_active.json")
    (config / "pricing_active.json").chmod(0o600)
    return target


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--target", type=Path, required=True)
    args = parser.parse_args()
    target = initialize(args.target)
    print(f"Lokale ontwikkelstate aangemaakt: {target}")
    print(
        "Gebruik alleen op loopback: DEV_MODE=1 APP_ENV=development METOD_STATE_ROOT=<map> python3 -B app/server_py.py"
    )
    print("Importeer voor eigen tests een catalogus via Admin. Productie blijft apart goedgekeurd.")


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError) as error:
        print(str(error), file=sys.stderr)
        raise SystemExit(2)
