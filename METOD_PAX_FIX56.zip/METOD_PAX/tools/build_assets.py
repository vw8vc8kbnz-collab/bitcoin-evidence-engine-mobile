#!/usr/bin/env python3
"""CLI compatibility entrypoint for the pinned native ES module asset builder."""

import subprocess
import sys
from pathlib import Path

if __name__ == "__main__":
    root = Path(__file__).resolve().parents[1]
    raise SystemExit(subprocess.call(["node", str(root / "tools/build_assets.cjs"), *sys.argv[1:]], cwd=root))
