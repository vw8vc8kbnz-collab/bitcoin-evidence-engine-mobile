/** Reproducible, production asset build. No source rewriting or runtime import stripping. */
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const esbuild = require("esbuild");
const root = path.resolve(__dirname, "..");
const app = path.join(root, "app");
const check = process.argv.includes("--check");
const hash = (data) => crypto.createHash("sha256").update(data).digest("hex");
const { revision } = JSON.parse(fs.readFileSync(path.join(root, "VERSION.json"), "utf8"));
function write(relative, data) {
  const dest = path.join(root, relative);
  if (check) {
    if (!fs.existsSync(dest) || !Buffer.from(data).equals(fs.readFileSync(dest)))
      throw new Error(`Stale generated file: ${relative}`);
  } else {
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.writeFileSync(dest, data);
  }
}
(async () => {
  write(
    "app/metod_app/version.py",
    `"""Generated from VERSION.json by tools/build_assets.cjs."""\nREVISION = ${JSON.stringify(revision)}\n`,
  );
  write(
    "app/tool-a/version.js",
    `// Generated from VERSION.json by tools/build_assets.cjs.\nexport const REVISION = ${JSON.stringify(revision)};\n`,
  );
  const manifest = {
    schemaVersion: 3,
    revision,
    builder: `esbuild@${esbuild.version}`,
    assets: {},
    sources: {},
  };
  const generated = new Set();
  for (const [kind, entry] of [
    ["javascript", "tool-a/main.js"],
    ["stylesheet", "tool-a/styles/main.css"],
  ]) {
    const result = await esbuild.build({
      absWorkingDir: app,
      entryPoints: [entry],
      bundle: true,
      minify: true,
      keepNames: true,
      format: "esm",
      target: ["safari15.5", "chrome108"],
      legalComments: "none",
      charset: "utf8",
      metafile: true,
      write: false,
      outfile: `tool-a.${kind === "javascript" ? "js" : "css"}`,
      logLevel: "warning",
    });
    const bytes = result.outputFiles[0].contents;
    const name = `assets/tool-a.${hash(bytes).slice(0, 16)}.${kind === "javascript" ? "js" : "css"}`;
    manifest.assets[kind] = { path: name, bytes: bytes.length, sha256: hash(bytes) };
    generated.add(name);
    write(`app/${name}`, bytes);
    for (const source of Object.keys(result.metafile.inputs).sort()) {
      const content = fs.readFileSync(path.join(app, source));
      manifest.sources[source] = { bytes: content.length, sha256: hash(content) };
    }
  }
  const templates = path.join(app, "tool-a/templates");
  let html = fs.readFileSync(path.join(templates, "shell.html"), "utf8");
  html = html.replace(/\{\{\s*include\s+([a-z-]+)\s*\}\}/g, (_, name) =>
    fs.readFileSync(path.join(templates, `${name}.html`), "utf8").trimEnd(),
  );
  html = html
    .replace("{{ stylesheet }}", manifest.assets.stylesheet.path)
    .replace("{{ javascript }}", manifest.assets.javascript.path)
    .replaceAll("{{ revision }}", revision);
  if (/\{\{/.test(html)) throw new Error("Unresolved HTML include or asset");
  for (const name of fs.readdirSync(templates).sort()) {
    const content = fs.readFileSync(path.join(templates, name));
    manifest.sources[`tool-a/templates/${name}`] = { bytes: content.length, sha256: hash(content) };
  }
  write("app/toolA.html", html);
  write("app/tool-a/asset-manifest.json", JSON.stringify(manifest, null, 2) + "\n");
  if (!check) {
    for (const name of fs.readdirSync(path.join(app, "assets"))) {
      if (/^tool-a\.[a-f0-9]{16}\.(js|css)$/.test(name) && !generated.has(`assets/${name}`))
        fs.unlinkSync(path.join(app, "assets", name));
    }
  }
  console.log(
    JSON.stringify({
      status: "PASS",
      check,
      assets: manifest.assets,
      sourceFiles: Object.keys(manifest.sources).length,
    }),
  );
})().catch((error) => {
  console.error(error);
  process.exit(1);
});
