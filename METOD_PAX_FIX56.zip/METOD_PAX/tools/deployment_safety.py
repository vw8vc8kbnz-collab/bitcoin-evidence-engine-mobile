#!/usr/bin/env python3
"""Independent release-name trust and explicit production acceptance checks.

Run only from the verified incoming release. A baseline's own Python or manifest
cannot authorize its recovery, and a bundled candidate cannot approve itself.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timedelta, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import stat


APPROVAL_ROOT = Path("/etc/adzaagt/metod-pax-release-approvals")
REQUIRED_GATES = frozenset(
    {
        "source_provenance",
        "browser",
        "vps",
        "clean_server",
        "iphone",
        "security",
        "operations_restore",
        "cam",
        "owner_signoff",
    }
)
DIGEST = re.compile(r"[a-f0-9]{64}")


def trusted_directory_chain(directory: Path) -> None:
    """Require root-controlled directory entries all the way to filesystem root."""
    if not directory.is_absolute() or directory != Path(os.path.normpath(directory)):
        raise ValueError("trust root must be a canonical absolute path")
    for path in (directory, *directory.parents):
        details = path.lstat()
        if (
            not stat.S_ISDIR(details.st_mode)
            or details.st_uid != 0
            or details.st_gid != 0
            or details.st_mode & 0o022
        ):
            raise ValueError(f"untrusted release/acceptance parent: {path}")


def baseline_digest(release: Path, releases_dir: Path, version: str, observed: str) -> str:
    trusted_directory_chain(releases_dir)
    if release.parent != releases_dir or release.is_symlink():
        raise ValueError("baseline must be a direct managed release directory")
    # The previous installer used this directory prefix; its full trusted digest remains mandatory.
    prefixes = (version, "FIX660R8_PRELIVE_HARDENED")
    match = re.fullmatch("(?:" + "|".join(map(re.escape, prefixes)) + r")_([a-f0-9]{64})", release.name)
    if match is None:
        raise ValueError("baseline lacks its complete independently anchored manifest digest")
    expected = match.group(1)
    if observed != expected:
        raise ValueError("baseline content and manifest differ from trusted release directory identity")
    return expected


def _read_acceptance(path: Path) -> dict:
    trusted_directory_chain(path.parent)
    flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0)
    descriptor = os.open(path, flags)
    try:
        before = os.fstat(descriptor)
        if (
            not stat.S_ISREG(before.st_mode)
            or before.st_uid != 0
            or before.st_gid != 0
            or stat.S_IMODE(before.st_mode) != 0o600
            or before.st_nlink != 1
            or before.st_size > 64 * 1024
        ):
            raise ValueError("production acceptance must be root:root mode 0600, singly linked and bounded")
        data = os.read(descriptor, 64 * 1024 + 1)
        after = os.fstat(descriptor)
        linked = path.lstat()

        def stable(details):
            return (
                details.st_dev,
                details.st_ino,
                details.st_mode,
                details.st_uid,
                details.st_gid,
                details.st_nlink,
                details.st_size,
                details.st_mtime_ns,
                details.st_ctime_ns,
            )

        if stable(before) != stable(after) or (after.st_dev, after.st_ino) != (linked.st_dev, linked.st_ino):
            raise ValueError("production acceptance changed during validation")
        if len(data) > 64 * 1024:
            raise ValueError("production acceptance exceeds size limit")

        def unique_object(pairs):
            result = {}
            for key, value in pairs:
                if key in result:
                    raise ValueError("duplicate production acceptance JSON key")
                result[key] = value
            return result

        return json.loads(data, object_pairs_hook=unique_object)
    finally:
        os.close(descriptor)


def _timestamp(value: object) -> datetime:
    if not isinstance(value, str) or not value.endswith("Z"):
        raise ValueError("approval timestamps must be explicit UTC strings")
    result = datetime.fromisoformat(value[:-1] + "+00:00")
    if result.utcoffset() != timedelta(0):
        raise ValueError("approval timestamp is not UTC")
    return result


def validate_acceptance(
    record: dict, identity: dict, manifest_digest: str, *, now: datetime | None = None
) -> None:
    if (
        not isinstance(record, dict)
        or type(record.get("schemaVersion")) is not int
        or record["schemaVersion"] != 1
    ):
        raise ValueError("missing production acceptance schemaVersion 1")
    if record.get("decision") != "APPROVED_FOR_PRODUCTION":
        raise ValueError("production requires an explicit independent approval decision")
    if record.get("manifestSha256") != manifest_digest:
        raise ValueError("production approval is for another exact release manifest")
    if (
        record.get("buildId") != identity["canonicalCandidate"]["buildId"]
        or record.get("cacheRevision") != identity["application"]["cacheRevision"]
    ):
        raise ValueError("production approval has a different build/cache identity")
    approver = record.get("approvedBy")
    if not isinstance(approver, str) or not approver.strip() or len(approver) > 200:
        raise ValueError("production approval requires a named accountable owner")
    approved = _timestamp(record.get("approvedAt"))
    expires = _timestamp(record.get("expiresAt"))
    current = now or datetime.now(timezone.utc)
    if not approved <= current < expires or expires - approved > timedelta(days=90):
        raise ValueError("production approval is expired, future-dated or exceeds 90 days")
    gates = record.get("gates")
    if not isinstance(gates, dict) or set(gates) != REQUIRED_GATES:
        raise ValueError("production approval is missing the complete external acceptance gate set")
    for name, gate in gates.items():
        if (
            not isinstance(gate, dict)
            or gate.get("status") != "PASS"
            or not isinstance(gate.get("evidenceSha256"), str)
            or DIGEST.fullmatch(gate["evidenceSha256"]) is None
        ):
            raise ValueError(f"production gate lacks PASS and an evidence digest: {name}")


def production_acceptance(release: Path) -> str:
    digest = hashlib.sha256((release / "SHA256SUMS.txt").read_bytes()).hexdigest()
    identity = json.loads((release / "RELEASE_IDENTITY.json").read_text(encoding="utf-8"))
    record = _read_acceptance(APPROVAL_ROOT / f"{digest}.json")
    validate_acceptance(record, identity, digest)
    return digest


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    baseline = commands.add_parser("baseline")
    baseline.add_argument("--release", type=Path, required=True)
    baseline.add_argument("--releases-dir", type=Path, required=True)
    baseline.add_argument("--version", required=True)
    baseline.add_argument("--observed-manifest-sha256", required=True)
    production = commands.add_parser("production")
    production.add_argument("--release", type=Path, required=True)
    args = parser.parse_args()
    try:
        if args.command == "baseline":
            print(
                baseline_digest(args.release, args.releases_dir, args.version, args.observed_manifest_sha256)
            )
        else:
            print("Independent production acceptance OK: " + production_acceptance(args.release))
    except (OSError, ValueError, KeyError, TypeError) as exc:
        raise SystemExit(f"Deployment trust gate failed: {exc}") from exc
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
