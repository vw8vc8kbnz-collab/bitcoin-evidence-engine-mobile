#!/usr/bin/env python3
from __future__ import annotations

"""Verify and restore a METOD/PAX state backup into a new staging directory.

The tool never overwrites an existing target and never extracts ZIP paths directly.
Every archive member is bound to the verified manifest hash contract before
any restored state is atomically published.
"""

import argparse
import hashlib
import json
import os
import re
import secrets
import shutil
import stat
import sys
import tempfile
import zipfile
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator


RELEASE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RELEASE_ROOT / "app"))

from safety_contracts import (  # noqa: E402
    durable_write_json,
    fsync_directory,
    sha256_file,
)


HASH_RE = re.compile(r"^[a-f0-9]{64}$")
MANIFEST_NAME = "BACKUP_MANIFEST.json"
DEFAULT_MAX_FILES = 200_000
DEFAULT_MAX_BYTES = 32 * 1024 * 1024 * 1024
_PRIVATE_STATE_PREFIXES = (("system", "job_create_idempotency"), ("security",))


def _private_state_path(parts: list[str]) -> bool:
    return any(tuple(parts[: len(prefix)]) == prefix for prefix in _PRIVATE_STATE_PREFIXES)


class RestoreError(RuntimeError):
    pass


@contextmanager
def _authenticated_backup_snapshot(
    backup_path: Path,
    *,
    max_files: int,
    max_bytes: int,
) -> Iterator[tuple[Path, Path, str]]:
    """Copy one no-follow source open into a private immutable restore input.

    Verification and restore must consume the same bytes.  Reopening the caller's
    path after verification would let a path replacement select a different ZIP,
    while hashing the path separately could make the proof describe yet another
    file.  The source descriptor is therefore opened once and the private copy is
    both hashed and populated from that descriptor.
    """

    display = Path(os.path.abspath(os.fspath(Path(backup_path).expanduser())))
    if display.suffix.lower() != ".zip":
        raise RestoreError("backup moet een bestaand ZIP-bestand zijn")
    try:
        resolved_parent = display.parent.resolve(strict=True)
    except (FileNotFoundError, OSError) as exc:
        raise RestoreError("bovenliggende backupmap bestaat niet") from exc
    if resolved_parent != display.parent or not resolved_parent.is_dir():
        raise RestoreError("bovenliggende backupmap mag geen symlink zijn")

    flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_NOFOLLOW", 0)
    try:
        source_fd = os.open(display, flags)
    except OSError as exc:
        raise RestoreError("backup moet een bestaand, niet-gesymlinkt ZIP-bestand zijn") from exc
    holder: tempfile.TemporaryDirectory[str] | None = None
    try:
        before = os.fstat(source_fd)
        if not stat.S_ISREG(before.st_mode) or before.st_size <= 0:
            raise RestoreError("backup-ZIP moet een niet-leeg regulier bestand zijn")
        archive_limit = int(max_bytes) + max(16 * 1024 * 1024, int(max_files) * 1024)
        if before.st_size > archive_limit:
            raise RestoreError("gecomprimeerde backup-ZIP overschrijdt de limiet")

        holder = tempfile.TemporaryDirectory(prefix="metod-restore-snapshot-")
        snapshot = Path(holder.name) / "authenticated-backup.zip"
        destination_fd = os.open(
            snapshot,
            os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_CLOEXEC", 0),
            0o600,
        )
        digest = hashlib.sha256()
        copied = 0
        try:
            while True:
                chunk = os.read(source_fd, 1024 * 1024)
                if not chunk:
                    break
                copied += len(chunk)
                if copied > before.st_size or copied > archive_limit:
                    raise RestoreError("backup-ZIP wijzigde of overschreed de limiet tijdens snapshot")
                digest.update(chunk)
                view = memoryview(chunk)
                while view:
                    written = os.write(destination_fd, view)
                    if written <= 0:
                        raise RestoreError("backup-snapshot kon niet volledig worden geschreven")
                    view = view[written:]
            os.fsync(destination_fd)
        finally:
            os.close(destination_fd)
        after = os.fstat(source_fd)
        stable_fields = ("st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns")
        if copied != before.st_size or any(
            getattr(before, key) != getattr(after, key) for key in stable_fields
        ):
            raise RestoreError("backup-ZIP wijzigde tijdens authenticiteitssnapshot")
        yield display, snapshot, digest.hexdigest()
    finally:
        os.close(source_fd)
        if holder is not None:
            holder.cleanup()


def _safe_member_name(name: str) -> str:
    raw = str(name or "")
    if (
        not raw
        or "\\" in raw
        or raw.startswith("/")
        or any(ord(character) < 32 or ord(character) == 127 for character in raw)
    ):
        raise RestoreError(f"onveilig ZIP-pad: {raw!r}")
    parts = raw.split("/")
    if any(part in {"", ".", ".."} for part in parts):
        raise RestoreError(f"onveilig ZIP-pad: {raw!r}")
    if raw != MANIFEST_NAME and parts[0] not in {"state", "release"}:
        raise RestoreError(f"onverwacht ZIP-pad: {raw!r}")
    return raw


def _is_zip_symlink(info: zipfile.ZipInfo) -> bool:
    return stat.S_ISLNK((int(info.external_attr) >> 16) & 0xFFFF)


def _sha256_stream(handle, *, expected_size: int, max_bytes: int) -> str:
    digest = hashlib.sha256()
    total = 0
    while True:
        chunk = handle.read(1024 * 1024)
        if not chunk:
            break
        total += len(chunk)
        if total > expected_size or total > max_bytes:
            raise RestoreError("ZIP-lid overschrijdt de gemanifesteerde grootte")
        digest.update(chunk)
    if total != expected_size:
        raise RestoreError("ZIP-lidgrootte wijkt af van manifest")
    return digest.hexdigest()


def _verify_backup_snapshot(
    snapshot_path: Path,
    *,
    display_path: Path,
    backup_sha256: str,
    max_files: int = DEFAULT_MAX_FILES,
    max_bytes: int = DEFAULT_MAX_BYTES,
) -> dict[str, Any]:
    max_files = max(1, int(max_files))
    max_bytes = max(1, int(max_bytes))

    with zipfile.ZipFile(snapshot_path, "r") as archive:
        infos = archive.infolist()
        if len(infos) > max_files + 1:
            raise RestoreError("backup bevat te veel bestanden")
        names: set[str] = set()
        by_name: dict[str, zipfile.ZipInfo] = {}
        for info in infos:
            name = _safe_member_name(info.filename)
            if name in names:
                raise RestoreError(f"dubbel ZIP-pad: {name}")
            if info.is_dir() or _is_zip_symlink(info):
                raise RestoreError(f"directory/symlink-lid is verboden: {name}")
            if info.file_size < 0 or info.file_size > max_bytes:
                raise RestoreError(f"ongeldige ZIP-lidgrootte: {name}")
            names.add(name)
            by_name[name] = info
        if MANIFEST_NAME not in by_name:
            raise RestoreError("BACKUP_MANIFEST.json ontbreekt")
        if by_name[MANIFEST_NAME].file_size > 64 * 1024 * 1024:
            raise RestoreError("backupmanifest is te groot")
        manifest_raw = archive.read(MANIFEST_NAME)

        def unique_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
            value: dict[str, Any] = {}
            for key, item in pairs:
                if key in value:
                    raise RestoreError(f"dubbele JSON-sleutel in backupmanifest: {key}")
                value[key] = item
            return value

        def reject_constant(value: str) -> None:
            raise RestoreError(f"niet-eindige JSON-waarde in backupmanifest: {value}")

        try:
            manifest = json.loads(
                manifest_raw.decode("utf-8", errors="strict"),
                object_pairs_hook=unique_object,
                parse_constant=reject_constant,
            )
        except RestoreError:
            raise
        except (UnicodeError, json.JSONDecodeError) as exc:
            raise RestoreError("backupmanifest is geen strikte JSON/UTF-8") from exc
        files = manifest.get("files") if isinstance(manifest, dict) else None
        if (
            not isinstance(manifest, dict)
            or type(manifest.get("schemaVersion")) is not int
            or manifest.get("schemaVersion") != 2
        ):
            raise RestoreError("niet-ondersteunde backupmanifestversie")
        if not isinstance(files, dict) or not files:
            raise RestoreError("backupmanifest mist files")
        if len(files) > max_files:
            raise RestoreError("backupmanifest bevat te veel bestanden")

        expected_names: set[str] = {MANIFEST_NAME}
        total_bytes = 0
        state_files = 0
        for raw_name, evidence in files.items():
            name = _safe_member_name(raw_name)
            if name == MANIFEST_NAME or not isinstance(evidence, dict) or set(evidence) != {"sha256", "size"}:
                raise RestoreError(f"ongeldig manifestitem: {name}")
            size = evidence.get("size")
            expected_hash = evidence.get("sha256")
            if (
                type(size) is not int
                or size < 0
                or size > max_bytes
                or not isinstance(expected_hash, str)
                or not HASH_RE.fullmatch(expected_hash)
            ):
                raise RestoreError(f"ongeldig hash/groottecontract: {name}")
            info = by_name.get(name)
            if info is None or info.file_size != size:
                raise RestoreError(f"ZIP/manifest verschilt voor: {name}")
            total_bytes += size
            if total_bytes > max_bytes:
                raise RestoreError("totale backupgrootte overschrijdt de limiet")
            with archive.open(info, "r") as source:
                actual_hash = _sha256_stream(source, expected_size=size, max_bytes=max_bytes)
            if actual_hash != expected_hash:
                raise RestoreError(f"hash mismatch voor: {name}")
            if name.startswith("state/"):
                state_files += 1
            expected_names.add(name)
        if names != expected_names:
            extra = sorted(names - expected_names)
            missing = sorted(expected_names - names)
            raise RestoreError(
                f"ZIP bevat extra/ontbrekende leden; extra={extra[:3]}, ontbrekend={missing[:3]}"
            )
        if state_files <= 0:
            raise RestoreError("backup bevat geen herstelbare state-bestanden")

    return {
        "backup": str(display_path),
        "backupSha256": backup_sha256,
        "manifestSha256": hashlib.sha256(manifest_raw).hexdigest(),
        "manifest": manifest,
        "fileCount": len(files),
        "stateFileCount": state_files,
        "totalBytes": total_bytes,
    }


def verify_backup(
    backup_path: Path,
    *,
    max_files: int = DEFAULT_MAX_FILES,
    max_bytes: int = DEFAULT_MAX_BYTES,
) -> dict[str, Any]:
    max_files = max(1, int(max_files))
    max_bytes = max(1, int(max_bytes))
    with _authenticated_backup_snapshot(
        backup_path,
        max_files=max_files,
        max_bytes=max_bytes,
    ) as (display, snapshot, backup_sha256):
        return _verify_backup_snapshot(
            snapshot,
            display_path=display,
            backup_sha256=backup_sha256,
            max_files=max_files,
            max_bytes=max_bytes,
        )


def _validate_new_target(target_path: Path) -> Path:
    target = Path(os.path.abspath(os.fspath(Path(target_path).expanduser())))
    forbidden = {Path("/"), Path("/root"), Path("/home"), Path("/var"), Path("/var/lib")}
    if target in forbidden or target.name in {"", ".", ".."}:
        raise RestoreError("restoredoel is te breed")
    if target.exists() or target.is_symlink():
        raise RestoreError("restoredoel moet nog niet bestaan")
    try:
        parent = target.parent.resolve(strict=True)
    except (FileNotFoundError, OSError) as exc:
        raise RestoreError("bovenliggende restoremap bestaat niet") from exc
    if parent != target.parent or not parent.is_dir():
        raise RestoreError("bovenliggende restoremap mag geen symlink zijn")
    resolved_candidate = parent / target.name
    if resolved_candidate.parent != parent:
        raise RestoreError("ongeldig restoredoel")
    return resolved_candidate


def _ensure_restore_parent(staging: Path, relative_parts: list[str]) -> Path:
    """Create restore parents with capability-store modes preserved.

    Backup ZIPs intentionally do not trust member mode bits. Most state keeps
    the service's 0750/0640 contract, while public-job idempotency records carry
    reusable access tokens and the security subtree holds durable TOTP replay
    state. Both require 0700/0600 after restore too.
    """

    current = staging
    for index, part in enumerate(relative_parts):
        current = current / part
        below_private_root = _private_state_path(relative_parts[: index + 1])
        mode = 0o700 if below_private_root else 0o750
        current.mkdir(exist_ok=True, mode=mode)
        if os.name != "nt":
            os.chmod(current, mode)
    return current


def _restore_authenticated_backup(
    snapshot_path: Path,
    verified: dict[str, Any],
    target_path: Path,
    *,
    proof_path: Path | None = None,
    privacy_ledger: Path | None = None,
) -> dict[str, Any]:
    target = _validate_new_target(target_path)
    staging = target.parent / f".{target.name}.restore.{os.getpid()}.{secrets.token_hex(6)}"
    if staging.exists() or staging.is_symlink():
        raise RestoreError("tijdelijk restoredoel bestaat onverwacht al")
    staging.mkdir(mode=0o750)
    try:
        files = verified["manifest"]["files"]
        with zipfile.ZipFile(snapshot_path, "r") as archive:
            for name, evidence in sorted(files.items()):
                if not str(name).startswith("state/"):
                    continue
                relative_parts = str(name).split("/")[1:]
                destination = staging.joinpath(*relative_parts)
                _ensure_restore_parent(staging, relative_parts[:-1])
                private_record = _private_state_path(relative_parts)
                file_mode = 0o600 if private_record else 0o640
                fd = os.open(str(destination), os.O_WRONLY | os.O_CREAT | os.O_EXCL, file_mode)
                try:
                    if os.name != "nt":
                        os.fchmod(fd, file_mode)
                    digest = hashlib.sha256()
                    total = 0
                    with archive.open(str(name), "r") as source, os.fdopen(fd, "wb", closefd=False) as output:
                        while True:
                            chunk = source.read(1024 * 1024)
                            if not chunk:
                                break
                            total += len(chunk)
                            if total > int(evidence["size"]):
                                raise RestoreError(f"restoregrootte mismatch: {name}")
                            digest.update(chunk)
                            output.write(chunk)
                        output.flush()
                        os.fsync(output.fileno())
                    os.close(fd)
                except Exception:
                    try:
                        os.close(fd)
                    except Exception:
                        pass
                    raise
                if total != int(evidence["size"]) or digest.hexdigest() != str(evidence["sha256"]):
                    raise RestoreError(f"restorehash mismatch: {name}")
        # Publish the complete restored tree only after a second write-time hash check.
        for name, evidence in sorted(files.items()):
            if str(name).startswith("state/"):
                restored = staging.joinpath(*str(name).split("/")[1:])
                if not restored.is_file() or restored.stat().st_size != int(evidence["size"]):
                    raise RestoreError(f"hersteld bestand ontbreekt: {name}")
                if sha256_file(restored) != str(evidence["sha256"]):
                    raise RestoreError(f"hersteld bestand heeft verkeerde hash: {name}")
        marker = staging / "system/restore_requires_privacy_replay.json"
        durable_write_json(marker, {"schemaVersion": 1, "backupSha256": verified["backupSha256"]}, mode=0o600)
        if privacy_ledger is not None:
            from metod_app.admin.privacy import CustomerPrivacyService

            CustomerPrivacyService(staging, ledger=privacy_ledger).replay(restored_with_current_ledger=True)
        for directory in sorted((path for path in staging.rglob("*") if path.is_dir()), reverse=True):
            fsync_directory(directory)
        fsync_directory(staging)
        os.replace(staging, target)
        fsync_directory(target.parent)
    except Exception:
        shutil.rmtree(staging, ignore_errors=True)
        raise

    result = {
        "ok": True,
        "verifiedAt": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "backupSha256": verified["backupSha256"],
        "manifestSha256": verified["manifestSha256"],
        "restoredTo": str(target),
        "stateFileCount": verified["stateFileCount"],
        "totalBytes": verified["totalBytes"],
        "privacyJournalApplied": privacy_ledger is not None,
        "applicationRestartTested": False,
        "offServerRestoreTested": False,
    }
    if proof_path is not None:
        proof = Path(proof_path).expanduser().absolute()
        durable_write_json(proof, result, mode=0o600)
        result["proof"] = str(proof)
    return result


def restore_backup(
    backup_path: Path,
    target_path: Path,
    *,
    proof_path: Path | None = None,
    privacy_ledger: Path | None = None,
    max_files: int = DEFAULT_MAX_FILES,
    max_bytes: int = DEFAULT_MAX_BYTES,
) -> dict[str, Any]:
    max_files = max(1, int(max_files))
    max_bytes = max(1, int(max_bytes))
    with _authenticated_backup_snapshot(
        backup_path,
        max_files=max_files,
        max_bytes=max_bytes,
    ) as (display, snapshot, backup_sha256):
        verified = _verify_backup_snapshot(
            snapshot,
            display_path=display,
            backup_sha256=backup_sha256,
            max_files=max_files,
            max_bytes=max_bytes,
        )
        return _restore_authenticated_backup(
            snapshot,
            verified,
            target_path,
            proof_path=proof_path,
            privacy_ledger=privacy_ledger,
        )


def main() -> int:
    parser = argparse.ArgumentParser(description="Verify or restore a METOD/PAX system backup")
    parser.add_argument("backup", type=Path)
    parser.add_argument("--verify-only", action="store_true")
    parser.add_argument("--target", type=Path, help="new, non-existing staging directory")
    parser.add_argument("--proof", type=Path, help="write restore-test proof after a real restore")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--privacy-ledger", type=Path, help="current external deletion journal")
    mode.add_argument(
        "--isolated-verification", action="store_true", help="restore a blocked state for inspection only"
    )
    parser.add_argument(
        "--max-files", type=int, default=int(os.environ.get("RESTORE_MAX_FILES", DEFAULT_MAX_FILES))
    )
    parser.add_argument(
        "--max-bytes", type=int, default=int(os.environ.get("RESTORE_MAX_BYTES", DEFAULT_MAX_BYTES))
    )
    args = parser.parse_args()
    if args.verify_only:
        if args.target is not None or args.proof is not None:
            parser.error("--verify-only cannot be combined with --target/--proof")
        verified = verify_backup(args.backup, max_files=args.max_files, max_bytes=args.max_bytes)
        result = {
            "ok": True,
            "verifiedOnly": True,
            "backupSha256": verified["backupSha256"],
            "manifestSha256": verified["manifestSha256"],
            "stateFileCount": verified["stateFileCount"],
            "totalBytes": verified["totalBytes"],
        }
    else:
        if args.target is None:
            parser.error("--target is required unless --verify-only is used")
        if args.privacy_ledger is None and not args.isolated_verification:
            parser.error(
                "--privacy-ledger is required; use --isolated-verification only for a non-startable test copy"
            )
        result = restore_backup(
            args.backup,
            args.target,
            proof_path=args.proof,
            privacy_ledger=args.privacy_ledger,
            max_files=args.max_files,
            max_bytes=args.max_bytes,
        )
    import json

    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (RestoreError, ValueError, OSError, zipfile.BadZipFile) as exc:
        print(f"RESTORE FAILED: {exc}", file=sys.stderr)
        raise SystemExit(2)
