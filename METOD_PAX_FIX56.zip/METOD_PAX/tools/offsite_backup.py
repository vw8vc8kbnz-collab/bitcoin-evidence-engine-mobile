#!/usr/bin/env python3
"""Encrypted restic snapshots, bounded retention and privacy-aware restoration.

The repository and password file are operator configuration, never release data.
Restic encrypts data before transport. A real second-server restore remains an
acceptance requirement; a successful local drill does not claim that evidence.
"""

from __future__ import annotations

import argparse
from contextlib import contextmanager
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import tempfile

from restore_system_backup import (
    sha256_file,
    DEFAULT_MAX_BYTES,
    DEFAULT_MAX_FILES,
    _authenticated_backup_snapshot,
    _verify_backup_snapshot,
    restore_backup,
)


class OffsiteError(RuntimeError):
    """Safe, operator-facing failure with no repository credentials."""


class ResticBackup:
    def __init__(self, *, executable="restic", allow_local_test=False, environment=None):
        self.executable = str(executable)
        self.environment = dict(os.environ if environment is None else environment)
        repository = self.environment.get("RESTIC_REPOSITORY", "")
        if not repository:
            raise OffsiteError("RESTIC_REPOSITORY ontbreekt")
        if "http://" in repository.lower():
            raise OffsiteError("Repositorytransport moet HTTPS of een versleuteld remote protocol gebruiken")
        if not allow_local_test and not repository.startswith(
            ("sftp:", "s3:", "b2:", "azure:", "gs:", "rest:https://")
        ):
            raise OffsiteError("Productie vereist een externe repository met beveiligd transport")
        if any(self.environment.get(key) for key in ("RESTIC_PASSWORD", "RESTIC_PASSWORD_COMMAND")):
            raise OffsiteError("Gebruik uitsluitend RESTIC_PASSWORD_FILE")
        password = Path(self.environment.get("RESTIC_PASSWORD_FILE", ""))
        if not password.is_file() or password.is_symlink():
            raise OffsiteError("Een regulier wachtwoordbestand is vereist")
        if stat.S_IMODE(password.stat().st_mode) & 0o077:
            raise OffsiteError("Wachtwoordbestand moet uitsluitend voor de eigenaar leesbaar zijn")
        if not 16 <= password.stat().st_size <= 4096:
            raise OffsiteError("Gebruik een sterk, extern bewaard repositorywachtwoord")

    def run(self, *args, cwd=None, output=None):
        try:
            result = subprocess.run(
                [self.executable, "--no-cache", "--json", *map(str, args)],
                cwd=cwd,
                env=self.environment,
                stdin=subprocess.DEVNULL,
                stdout=output if output is not None else subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=3600,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired) as error:
            raise OffsiteError("Restic kon niet worden uitgevoerd of duurde te lang") from error
        if result.returncode:
            # Restic stderr can include credential-bearing repository URLs.
            raise OffsiteError(
                f"Restic mislukt (exitcode {result.returncode}); controleer verbinding, sleutel en repository"
            )
        return result.stdout

    def snapshots(self):
        rows = json.loads(self.run("snapshots", "--host", "metod-pax", "--tag", "metod-pax-system"))
        return sorted(rows or [], key=lambda row: row["time"])

    def dump(self, snapshot, name):
        if not re.fullmatch("[a-f0-9]{64}", snapshot):
            raise OffsiteError("Ongeldige snapshot-identiteit")
        return self.run("dump", snapshot, "/" + name)

    @staticmethod
    def privacy_snapshot(ledger):
        ledger = Path(ledger)
        if not ledger.is_dir() or ledger.is_symlink():
            raise OffsiteError("Actueel extern verwijderlogboek ontbreekt")
        records = {}
        for file in sorted(ledger.iterdir()):
            if file.is_symlink() or not file.is_file() or not re.fullmatch(r"[a-f0-9]{32}\.json", file.name):
                raise OffsiteError("Onverwacht bestand in verwijderlogboek")
            value = json.loads(file.read_text())
            if value.get("schemaVersion") != 1 or value.get("erasureId") + ".json" != file.name:
                raise OffsiteError("Ongeldig verwijderlogboek")
            records[file.name] = value
        return json.dumps(records, sort_keys=True, separators=(",", ":")).encode()

    def push(self, backup, ledger, *, keep_weeks=8):
        backup = Path(backup)
        if shutil.disk_usage(tempfile.gettempdir()).free < backup.stat().st_size + 2 * 1024**3:
            raise OffsiteError("Onvoldoende vrije ruimte voor gecontroleerde backupkopie plus 2 GiB reserve")
        privacy = self.privacy_snapshot(ledger)
        with _authenticated_backup_snapshot(
            backup, max_files=DEFAULT_MAX_FILES, max_bytes=DEFAULT_MAX_BYTES
        ) as (display, source, digest):
            _verify_backup_snapshot(source, display_path=display, backup_sha256=digest)
            identity = {
                "schemaVersion": 1,
                "backupSha256": digest,
                "privacySha256": hashlib.sha256(privacy).hexdigest(),
            }
            snapshots = self.snapshots()
            if snapshots and json.loads(self.dump(snapshots[-1]["id"], "identity.json")) == identity:
                return {"ok": True, "skippedUnchanged": True, "snapshot": snapshots[-1]["id"], **identity}
            with tempfile.TemporaryDirectory(prefix="metod-offsite-") as temporary:
                folder = Path(temporary)
                # Hardlink the already authenticated private snapshot, never reopen
                # the source backup after verifying it.
                try:
                    os.link(source, folder / "system-backup.zip")
                except OSError:
                    shutil.copyfile(source, folder / "system-backup.zip")
                (folder / "privacy.json").write_bytes(privacy)
                (folder / "identity.json").write_text(json.dumps(identity, sort_keys=True))
                for file in folder.iterdir():
                    file.chmod(0o600)
                self.run(
                    "backup",
                    "--host",
                    "metod-pax",
                    "--tag",
                    "metod-pax-system",
                    "system-backup.zip",
                    "privacy.json",
                    "identity.json",
                    cwd=folder,
                )
            keep_weeks = max(1, min(52, int(keep_weeks)))
            self.run(
                "forget",
                "--host",
                "metod-pax",
                "--tag",
                "metod-pax-system",
                "--group-by",
                "host,tags",
                "--keep-last",
                "2",
                "--keep-weekly",
                str(keep_weeks),
                "--prune",
            )
            self.run("check")
            return {"ok": True, "snapshot": self.snapshots()[-1]["id"], **identity}

    def restore(self, snapshot, target):
        rows = self.snapshots()
        if not rows:
            raise OffsiteError("Geen backups gevonden")
        selected = (
            rows[-1] if snapshot == "latest" else next((row for row in rows if row["id"] == snapshot), None)
        )
        if selected is None:
            raise OffsiteError("Snapshot niet gevonden")
        target = Path(target).absolute()
        ledger = target.with_name(target.name + "-privacy")
        if target.exists() or ledger.exists():
            raise OffsiteError("Hersteldoel en logboek moeten nieuw zijn")
        current = json.loads(self.dump(rows[-1]["id"], "privacy.json"))
        older = json.loads(self.dump(selected["id"], "privacy.json"))
        if any(current.get(name) != value for name, value in older.items()):
            raise OffsiteError("Het nieuwste verwijderlogboek mist historische verwijderingen")
        identity = json.loads(self.dump(selected["id"], "identity.json"))
        with tempfile.TemporaryDirectory(prefix="metod-offsite-restore-") as temporary:
            backup = Path(temporary) / "system-backup.zip"
            with backup.open("xb") as output:
                backup.chmod(0o600)
                self.run("dump", selected["id"], "/system-backup.zip", output=output)
            if sha256_file(backup) != identity["backupSha256"]:
                raise OffsiteError("Herstelde backup wijkt af van snapshot-identiteit")
            ledger.mkdir(mode=0o700, parents=False)
            try:
                for name, value in current.items():
                    if not re.fullmatch(r"[a-f0-9]{32}\.json", name):
                        raise OffsiteError("Ongeldige verwijderlogboeknaam")
                    file = ledger / name
                    file.write_text(json.dumps(value))
                    file.chmod(0o600)
                result = restore_backup(backup, target, privacy_ledger=ledger)
            except BaseException:
                shutil.rmtree(ledger)
                raise
        return {**result, "snapshot": selected["id"], "privacySnapshot": rows[-1]["id"]}


@contextmanager
def operation_lock(path):
    path = Path(path)
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    with path.open("a") as handle:
        fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        yield


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("init", "push", "check", "restore"))
    parser.add_argument("--restic", default="restic")
    parser.add_argument("--allow-local-test", action="store_true")
    parser.add_argument("--backup", type=Path)
    parser.add_argument("--privacy-ledger", type=Path, default=Path("/var/lib/metod-pax-privacy"))
    parser.add_argument("--snapshot", default="latest")
    parser.add_argument("--target", type=Path)
    parser.add_argument("--keep-weeks", type=int, default=8)
    parser.add_argument("--lock", type=Path, default=Path("/var/lib/metod-pax-offsite/operation.lock"))
    args = parser.parse_args()
    tool = ResticBackup(executable=args.restic, allow_local_test=args.allow_local_test)
    with operation_lock(args.lock):
        if args.action == "init":
            tool.run("init")
            result = {"ok": True}
        elif args.action == "check":
            tool.run("check", "--read-data")
            result = {"ok": True, "encryptedDataRead": True}
        elif args.action == "push":
            if args.backup is None:
                parser.error("--backup is required")
            result = tool.push(args.backup, args.privacy_ledger, keep_weeks=args.keep_weeks)
        else:
            if args.target is None:
                parser.error("--target is required")
            result = tool.restore(args.snapshot, args.target)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    try:
        main()
    except (OffsiteError, OSError, ValueError) as error:
        print(
            str(error)
            if isinstance(error, OffsiteError)
            else "Backupcontrole mislukt: " + type(error).__name__,
            file=sys.stderr,
        )
        raise SystemExit(2)
