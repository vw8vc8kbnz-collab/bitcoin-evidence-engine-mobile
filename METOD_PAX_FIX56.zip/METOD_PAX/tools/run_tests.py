#!/usr/bin/env python3
"""Run isolated regression/API tests and real Chromium journeys against this tree."""

from __future__ import annotations

import argparse
from contextlib import redirect_stderr, redirect_stdout
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import unittest


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, required=True, help="New evidence directory outside the release"
    )
    parser.add_argument(
        "--unit-only",
        action="store_true",
        help="Omit browser journeys; result explicitly records the omission",
    )
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    output = args.output.resolve()
    if output == root or root in output.parents or output.exists():
        parser.error("Use a new output directory outside the release")
    output.mkdir(parents=True, mode=0o700)
    sys.dont_write_bytecode = True
    os.environ.update(
        PYTHONDONTWRITEBYTECODE="1",
        METOD_TEST_RELEASE=str(root),
        METOD_API_REPORT=str(output / "api-routes.json"),
    )
    for variable, binary in [("METOD_TEST_RESTIC", "restic"), ("METOD_TEST_NGINX", "nginx")]:
        if not os.environ.get(variable) and shutil.which(binary):
            os.environ[variable] = shutil.which(binary)
    sys.path.insert(0, str(root / "tests"))
    typing = subprocess.run(
        [sys.executable, "-B", str(root / "tools/check_types.py")],
        capture_output=True,
        text=True,
        timeout=200,
    )
    (output / "type-check.json").write_text(typing.stdout)
    if typing.returncode:
        print(typing.stdout + typing.stderr, flush=True)
        return 1
    start = time.monotonic()
    suite = unittest.defaultTestLoader.discover(str(root / "tests"), pattern="test_*.py")
    with (output / "python-tests.log").open("w") as log, redirect_stdout(log), redirect_stderr(log):
        result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
    record = {
        "schemaVersion": 1,
        "checkedAt": datetime.now(timezone.utc).isoformat(),
        "revision": json.loads((root / "VERSION.json").read_text())["revision"],
        "testsRun": result.testsRun,
        "failures": len(result.failures),
        "errors": len(result.errors),
        "skipped": [{"test": str(test), "reason": reason} for test, reason in result.skipped],
        "seconds": round(time.monotonic() - start, 2),
        "status": "PASS"
        if result.wasSuccessful() and not result.skipped
        else "INCOMPLETE"
        if result.wasSuccessful()
        else "FAIL",
    }
    (output / "python-tests.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record), flush=True)
    if record["status"] != "PASS":
        print("See python-tests.log; no complete PASS is claimed.", flush=True)
        return 1
    if args.unit_only:
        print("Browser journeys omitted by --unit-only.", flush=True)
        return 0

    from server_fixture import TestServer

    def browser(script: str, server, width: int, name: str, *arguments: str):
        print("Browser: " + name, flush=True)
        run = subprocess.run(
            ["node", str(root / "tests" / script), server.origin, str(width), str(output / (name + ".json")), *arguments],
            cwd=root,
            timeout=180,
            capture_output=True,
            text=True,
        )
        (output / (name + ".log")).write_text(run.stdout + run.stderr)
        if run.returncode:
            raise RuntimeError("Browser journey failed: " + name)

    for width, name in [(1440, "browser-desktop-order"), (390, "browser-mobile-order")]:
        with TestServer(secure=True) as server:
            browser("browser-order.cjs", server, width, name)
            if width == 390:
                saved = output / "synthetic-order-state"
                for folder in ("jobs", "requests", "index"):
                    if (server.state / folder).is_dir():
                        shutil.copytree(server.state / folder, saved / folder)
    # Exercise the Admin UI with the real order just created above, not an old fixture.
    for width, name in [(1440, "browser-admin"), (390, "browser-admin-mobile")]:
        with TestServer() as server:
            for folder in ("jobs", "requests", "index"):
                if (saved / folder).is_dir():
                    shutil.copytree(saved / folder, server.state / folder, dirs_exist_ok=True)
            browser("browser-admin.cjs", server, width, name)
    shutil.rmtree(saved)

    for width in (1440, 390):
        with TestServer(secure=True) as server:
            browser("browser-maintenance.cjs", server, width, f"browser-maintenance-{width}")
        with TestServer(secure=True) as server:
            browser("browser-order.cjs", server, width, f"browser-cancellation-{width}", "cancel")
        with TestServer(secure=True) as server:
            browser("browser-order.cjs", server, width, f"browser-request-cancellation-{width}", "cancel-request")
    print(
        "PASS: regressions, API, desktop, mobile viewport and Admin. Physical devices/VPS not tested.",
        flush=True,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
