#!/usr/bin/env python3
"""Select the newest completed local backup for the encrypted offsite timer."""

from pathlib import Path
import os
import json
from offsite_backup import ResticBackup, OffsiteError, operation_lock


def main():
    state = Path(os.environ.get("METOD_STATE_ROOT", "/var/lib/metod-pax"))
    ledger = Path(os.environ.get("PRIVACY_LEDGER_DIR", str(state) + "-privacy"))
    with operation_lock("/var/lib/metod-pax-offsite/operation.lock"):
        backups = [
            p for p in (state / "backups").glob("system_backup_*.zip") if p.is_file() and not p.is_symlink()
        ]
        if not backups:
            raise OffsiteError("Geen voltooide lokale backup gevonden")
        selected = max(backups, key=lambda p: p.stat().st_mtime_ns)
        result = ResticBackup().push(
            selected, ledger, keep_weeks=int(os.environ.get("OFFSITE_KEEP_WEEKS", "8"))
        )
        print(json.dumps(result))


if __name__ == "__main__":
    try:
        main()
    except (OffsiteError, OSError, ValueError) as error:
        raise SystemExit(
            str(error)
            if isinstance(error, OffsiteError)
            else "Offsite backup mislukt: " + type(error).__name__
        )
