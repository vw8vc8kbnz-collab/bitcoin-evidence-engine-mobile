#!/usr/bin/env python3
from __future__ import annotations

"""Prove that the live backend serves the exact immutable release identity."""

import argparse
import hashlib
import json
import re
import stat
from html.parser import HTMLParser
from pathlib import Path


MAX_LIVENESS_BYTES = 16 * 1024
MAX_TOOL_A_BYTES = 5 * 1024 * 1024
MAX_HTTP_HEADERS_BYTES = 64 * 1024
SAFE_ID = re.compile(r"[A-Z0-9][A-Z0-9_]{1,127}\Z")
HTML_EXECUTABLE_TAG = re.compile(rb"<(?:script|style)(?=[\s>])", re.IGNORECASE)
HTML_NONCE_ATTRIBUTE = re.compile(rb' nonce="([A-Za-z0-9_-]{24})"')
HTTP_STATUS = re.compile(r"HTTP/(?:1\.[01]|2|3) 200(?: .*)?\Z")
HTTP_HEADER_NAME = re.compile(r"[!#$%&'*+.^_`|~0-9A-Za-z-]+\Z")


class ProbeFailure(ValueError):
    pass


def _regular_bytes(path: Path, *, maximum: int, label: str) -> bytes:
    metadata = path.lstat()
    if not stat.S_ISREG(metadata.st_mode) or metadata.st_nlink != 1:
        raise ProbeFailure(f"{label} is geen enkelvoudig regulier bestand")
    if metadata.st_size < 1 or metadata.st_size > maximum:
        raise ProbeFailure(f"{label} heeft een ongeldige grootte")
    return path.read_bytes()


def _strict_object(path: Path) -> dict:
    raw = _regular_bytes(path, maximum=1024 * 1024, label=path.name)

    def unique(pairs: list[tuple[str, object]]) -> dict:
        result: dict = {}
        for key, value in pairs:
            if key in result:
                raise ProbeFailure(f"dubbele JSON-sleutel: {key}")
            result[key] = value
        return result

    try:
        value = json.loads(raw.decode("utf-8", errors="strict"), object_pairs_hook=unique)
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise ProbeFailure(f"ongeldige JSON in {path.name}: {exc}") from exc
    if not isinstance(value, dict):
        raise ProbeFailure(f"{path.name} moet een JSON-object zijn")
    return value


def expected_identity(release: Path) -> tuple[str, str, str]:
    identity = _strict_object(release / "RELEASE_IDENTITY.json")
    candidate = identity.get("canonicalCandidate")
    application = identity.get("application")
    if (
        identity.get("schemaVersion") != 2
        or not isinstance(candidate, dict)
        or not isinstance(application, dict)
    ):
        raise ProbeFailure("canonieke release-identiteit is incompleet")
    revision = candidate.get("releaseRevision")
    build = candidate.get("buildId")
    compatibility = application.get("runtimeCompatibilityBuild")
    if not all(
        isinstance(value, str) and SAFE_ID.fullmatch(value) for value in (revision, build, compatibility)
    ):
        raise ProbeFailure("release-identiteitswaarden hebben een onveilig formaat")
    return revision, build, compatibility


class _MetadataParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.values: dict[str, list[str]] = {}

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag.lower() != "meta":
            return
        values = {str(key).lower(): value for key, value in attrs}
        name = values.get("name")
        content = values.get("content")
        if name is not None and content is not None:
            self.values.setdefault(name, []).append(content)

    def handle_startendtag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        self.handle_starttag(tag, attrs)


def validate_liveness(release: Path, probe: Path) -> None:
    expected_identity(release)
    value = _strict_object(probe)
    if value != {"ok": True}:
        raise ProbeFailure("live health-identiteit wijkt af van de immutable release")


def _strict_http_headers(path: Path) -> dict[str, list[str]]:
    raw = _regular_bytes(path, maximum=MAX_HTTP_HEADERS_BYTES, label="HTTP-headerbewijs")
    if b"\x00" in raw or b"\r" in raw.replace(b"\r\n", b""):
        raise ProbeFailure("HTTP-headerbewijs bevat ongeldige besturingsbytes")
    try:
        lines = raw.decode("iso-8859-1", errors="strict").replace("\r\n", "\n").split("\n")
    except UnicodeError as exc:
        raise ProbeFailure("HTTP-headerbewijs is niet parseerbaar") from exc
    status_indexes = [index for index, line in enumerate(lines) if line.startswith("HTTP/")]
    if len(status_indexes) != 1 or not HTTP_STATUS.fullmatch(lines[status_indexes[0]]):
        raise ProbeFailure("HTTP-headerbewijs bevat niet exact één succesvolle eindresponse")
    headers: dict[str, list[str]] = {}
    for line in lines[status_indexes[0] + 1 :]:
        if line == "":
            break
        if line[:1].isspace() or ":" not in line:
            raise ProbeFailure("HTTP-headerbewijs bevat een gevouwen of ongeldige header")
        name, value = line.split(":", 1)
        if not HTTP_HEADER_NAME.fullmatch(name):
            raise ProbeFailure("HTTP-headerbewijs bevat een ongeldige headernaam")
        clean = value.strip()
        if any(ord(character) < 32 and character != "\t" for character in clean):
            raise ProbeFailure("HTTP-headerbewijs bevat een ongeldige headerwaarde")
        headers.setdefault(name.lower(), []).append(clean)
    return headers


def _require_single_header(headers: dict[str, list[str]], name: str) -> str:
    values = headers.get(name.lower(), [])
    if len(values) != 1:
        raise ProbeFailure(f"HTTP-response bevat niet exact één {name}-header")
    return values[0]


def _validate_tool_a_headers(path: Path, *, body: bytes, nonce: bytes) -> None:
    headers = _strict_http_headers(path)
    if _require_single_header(headers, "Content-Type").lower() != "text/html; charset=utf-8":
        raise ProbeFailure("Tool A-response heeft niet het exacte HTML-contenttype")
    content_lengths = headers.get("content-length", [])
    if content_lengths:
        if len(content_lengths) != 1 or content_lengths[0] != str(len(body)):
            raise ProbeFailure("Tool A Content-Length is niet byte-exact")
    for name, expected in (
        ("X-Content-Type-Options", "nosniff"),
        ("X-Frame-Options", "DENY"),
        ("Cross-Origin-Resource-Policy", "same-origin"),
    ):
        if _require_single_header(headers, name) != expected:
            raise ProbeFailure(f"Tool A-response heeft een ongeldige {name}-header")

    csp = _require_single_header(headers, "Content-Security-Policy")
    directives: dict[str, list[str]] = {}
    for raw_directive in csp.split(";"):
        fields = raw_directive.strip().split()
        if not fields:
            continue
        name = fields[0].lower()
        if name in directives:
            raise ProbeFailure("Tool A-CSP bevat een dubbele directive")
        directives[name] = fields[1:]
    nonce_source = f"'nonce-{nonce.decode('ascii')}'"
    required = {
        "default-src": ["'self'"],
        "object-src": ["'none'"],
        "frame-ancestors": ["'none'"],
        "style-src-elem": ["'self'", nonce_source],
        "script-src": ["'self'", nonce_source],
        "script-src-attr": ["'none'"],
        "style-src-attr": ["'none'"],
    }
    for name, expected in required.items():
        if directives.get(name) != expected:
            raise ProbeFailure(f"Tool A-CSP heeft geen exact nonce-gebonden {name}-directive")


def validate_tool_a(release: Path, probe: Path, headers: Path | None = None) -> None:
    revision, build, _ = expected_identity(release)
    source = _regular_bytes(
        release / "app/toolA.html", maximum=MAX_TOOL_A_BYTES, label="immutable toolA.html"
    )
    live = _regular_bytes(probe, maximum=MAX_TOOL_A_BYTES, label="live toolA.html")
    expected_nonce_count = len(HTML_EXECUTABLE_TAG.findall(source))
    live_nonces = HTML_NONCE_ATTRIBUTE.findall(live)
    if len(live_nonces) != expected_nonce_count or (live_nonces and len(set(live_nonces)) != 1):
        raise ProbeFailure(
            "live toolA.html heeft niet exact één gedeelde CSP-nonce op alle script/style-tags"
        )
    normalized_live = HTML_NONCE_ATTRIBUTE.sub(b"", live)
    if hashlib.sha256(normalized_live).digest() != hashlib.sha256(source).digest():
        raise ProbeFailure(
            "live toolA.html is buiten de verplichte CSP-nonce niet byte-exact de immutable releasebron"
        )
    try:
        text = source.decode("utf-8", errors="strict")
    except UnicodeError as exc:
        raise ProbeFailure("toolA.html is geen geldige UTF-8") from exc
    parser = _MetadataParser()
    parser.feed(text)
    expected = {
        "metod-release-revision": revision,
        "metod-release-build": build,
    }
    for name, value in expected.items():
        if parser.values.get(name) != [value]:
            raise ProbeFailure(f"toolA.html mist exact één canonieke {name}-marker")
    if headers is not None:
        if not live_nonces:
            raise ProbeFailure("live toolA.html heeft geen nonce voor het HTTP-headerbewijs")
        _validate_tool_a_headers(headers, body=live, nonce=live_nonces[0])


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--release", type=Path, required=True)
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument("--liveness", type=Path)
    modes.add_argument("--tool-a", type=Path)
    parser.add_argument("--headers", type=Path)
    args = parser.parse_args()
    if args.headers is not None and args.tool_a is None:
        parser.error("--headers is uitsluitend geldig samen met --tool-a")
    try:
        release = args.release.resolve(strict=True)
        if not release.is_dir():
            raise ProbeFailure("releasepad is geen map")
        if args.liveness is not None:
            validate_liveness(release, args.liveness)
            label = "liveness"
        else:
            validate_tool_a(release, args.tool_a, args.headers)
            label = "tool-a"
    except (OSError, ProbeFailure) as exc:
        print(f"RUNTIME IDENTITY PROBE: FAIL: {exc}")
        return 1
    print(f"RUNTIME IDENTITY PROBE: PASS ({label})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
