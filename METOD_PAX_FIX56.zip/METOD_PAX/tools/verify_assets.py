#!/usr/bin/env python3
"""Verify shipped assets without installing Node packages on the server.

The development gate rebuilds with pinned esbuild. This deployment gate checks
the recorded input/output bytes and independently assembles the HTML template.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re


def verify_assets(root: Path) -> dict:
    app = root / "app"
    revision = json.loads((root / "VERSION.json").read_text())["revision"]
    manifest = json.loads((app / "tool-a/asset-manifest.json").read_text())
    if manifest.get("schemaVersion") != 3 or manifest.get("revision") != revision:
        raise ValueError("Asset manifest identity differs")
    if set(manifest.get("assets", {})) != {"javascript", "stylesheet"}:
        raise ValueError("Expected exactly one JavaScript and one CSS asset")
    for relative, record in list(manifest["sources"].items()) + [
        (value["path"], value) for value in manifest["assets"].values()
    ]:
        path = app / relative
        if path.is_symlink() or app.resolve() not in path.resolve().parents:
            raise ValueError("Unsafe asset input")
        payload = path.read_bytes()
        if len(payload) != record["bytes"] or hashlib.sha256(payload).hexdigest() != record["sha256"]:
            raise ValueError("Changed asset source/output: " + relative)
    for record in manifest["assets"].values():
        if not re.fullmatch(r"assets/tool-a\.[a-f0-9]{16}\.(js|css)", record["path"]):
            raise ValueError("Asset filename must contain its content hash")
        if record["path"].split(".")[1] != record["sha256"][:16]:
            raise ValueError("Asset filename hash differs")
    templates = app / "tool-a/templates"
    html = (templates / "shell.html").read_text()
    html = re.sub(
        r"\{\{\s*include\s+([a-z-]+)\s*\}\}",
        lambda match: (templates / (match[1] + ".html")).read_text().rstrip(),
        html,
    )
    for key, value in {
        "revision": revision,
        "javascript": manifest["assets"]["javascript"]["path"],
        "stylesheet": manifest["assets"]["stylesheet"]["path"],
    }.items():
        html = html.replace("{{ " + key + " }}", value)
    if "{{" in html or html != (app / "toolA.html").read_text():
        raise ValueError("HTML differs from its current components")
    if len(re.findall(r"<script\b", html)) != 1 or not re.search(r'<script type="module" src=', html):
        raise ValueError("Expected one native module entrypoint")
    if re.search(r"\s(?:on[a-z]+|style)\s*=", html, re.I) or "<style" in html:
        raise ValueError("Inline executable or style content in Tool A HTML")
    return {
        "status": "PASS",
        "revision": revision,
        "assets": len(manifest["assets"]),
        "sourceFiles": len(manifest["sources"]),
        "esbuildRebuildPerformed": False,
    }


if __name__ == "__main__":
    print(json.dumps(verify_assets(Path(__file__).resolve().parents[1]), indent=2))
