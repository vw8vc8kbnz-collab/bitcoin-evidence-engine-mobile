#!/usr/bin/env python3
"""Read-only verification of exact HTML/assets and security through an HTTP hop."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys
import tempfile
from urllib.parse import urlsplit
from urllib.request import HTTPRedirectHandler, ProxyHandler, Request, build_opener

sys.path.insert(0, str(Path(__file__).resolve().parent))
from deploy_runtime_identity_probe import validate_liveness, validate_tool_a


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


def probe(release: Path, origin: str) -> dict:
    target = urlsplit(origin)
    if (
        target.scheme not in {"https", "http"}
        or not target.hostname
        or target.username
        or target.password
        or target.query
        or target.fragment
        or target.path not in {"", "/"}
    ):
        raise ValueError("Origin must be one canonical HTTP(S) origin")
    if target.scheme == "http" and target.hostname not in {"127.0.0.1", "::1", "localhost"}:
        raise ValueError("Plain HTTP is allowed only for a local probe")
    opener = build_opener(ProxyHandler({}), NoRedirect())

    def get(path: str, maximum: int):
        request = Request(origin.rstrip("/") + path, headers={"Accept-Encoding": "identity"})
        with opener.open(request, timeout=30) as response:
            if response.status != 200:
                raise ValueError("Unsuccessful response")
            body = response.read(maximum + 1)
            if len(body) > maximum:
                raise ValueError("Response exceeds verification bound")
            return body, response.headers

    with tempfile.TemporaryDirectory(prefix="metod-http-proof-") as directory:
        work = Path(directory)
        live, _ = get("/health/live", 16384)
        (work / "live.json").write_bytes(live)
        validate_liveness(release, work / "live.json")
        ready, _ = get("/health/ready", 16384)
        if json.loads(ready).get("ok") is not True:
            raise ValueError("Application is not ready")
        html, headers = get("/toolA.html", 5 * 1024 * 1024)
        (work / "tool.html").write_bytes(html)
        header_text = (
            "HTTP/1.1 200 OK\r\n" + "".join(f"{key}: {value}\r\n" for key, value in headers.items()) + "\r\n"
        )
        (work / "headers.txt").write_bytes(header_text.encode("iso-8859-1"))
        validate_tool_a(release, work / "tool.html", work / "headers.txt")
        manifest = json.loads((release / "app/tool-a/asset-manifest.json").read_text())
        for record in manifest["assets"].values():
            body, headers = get("/" + record["path"], record["bytes"])
            if hashlib.sha256(body).hexdigest() != record["sha256"]:
                raise ValueError("Live asset differs from release")
            if "immutable" not in headers.get("Cache-Control", ""):
                raise ValueError("Live asset misses immutable caching")
        return {
            "status": "PASS",
            "revision": manifest["revision"],
            "origin": origin,
            "verifiedAssets": len(manifest["assets"]),
            "htmlAndSecurityHeaders": "PASS",
        }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--release", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--origin", required=True)
    arguments = parser.parse_args()
    print(json.dumps(probe(arguments.release.resolve(), arguments.origin), indent=2))
