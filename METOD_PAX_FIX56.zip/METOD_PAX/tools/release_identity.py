#!/usr/bin/env python3
"""Verify this installation's complete inventory, tests and current source record."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re

REVISION = "R9RC4_FIX56_RUNTIME_PREFLIGHT"
CACHE = "fix56-runtime-preflight"
ROOT_NAME = "METOD_PAX"
TOOLS = frozenset(
    {
        "bootstrap_admin_credentials.py",
        "build_assets.py",
        "check_types.py",
        "build_assets.cjs",
        "deploy_runtime_identity_probe.py",
        "deployment_safety.py",
        "final_preflight.py",
        "install_state_gate.py",
        "migrate_legacy_admin_credentials.py",
        "migration_bundle_tool.py",
        "prune_deploy_history.py",
        "restore_system_backup.py",
        "release_identity.py",
        "verify_source_provenance.py",
        "verify_standalone_artifact.py",
        "verify_assets.py",
        "probe_http_release.py",
        "run_tests.py",
        "init_local_state.py",
        "offsite_backup.py",
        "offsite_schedule.py",
    }
)
REQUIRED_VALIDATION = frozenset(
    {
        "python-regressions",
        "api-routes",
        "browser-desktop-order",
        "browser-mobile-order",
        "browser-admin",
        "asset-rebuild",
        "static-analysis",
        "type-check",
        "browser-admin-mobile",
        "browser-maintenance-1440",
        "browser-maintenance-390",
        "browser-cancellation-1440",
        "browser-cancellation-390",
        "browser-request-cancellation-1440",
        "browser-request-cancellation-390",
        "cancellation-api",
        "runtime-baseline-equivalence",
        "domain-ownership",
        "runtime-preflight",
    }
)


def read_json(path: Path):
    def pairs(items):
        output = {}
        for key, value in items:
            if key in output:
                raise ValueError("duplicate JSON key: " + key)
            output[key] = value
        return output

    def invalid(value):
        raise ValueError("non-finite JSON number: " + value)

    return json.loads(path.read_text(), object_pairs_hook=pairs, parse_constant=invalid)


def file_hash(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def code_digest(release: Path) -> str:
    """Bind the tested app, tools, operational settings, dependencies and tests."""
    digest = hashlib.sha256()
    roots = ("app/", "tools/", "tests/", "dependencies/", "ops/", "ci/")
    for path in sorted(release.rglob("*")):
        relative = path.relative_to(release).as_posix()
        if path.is_file() and (
            relative.startswith(roots)
            or path.suffix == ".sh"
            or relative
            in {
                "VERSION.json",
                "package.json",
                "package-lock.json",
                "requirements.txt",
                "requirements-dev.txt",
                "pyproject.toml",
            }
        ):
            if path.is_symlink():
                raise ValueError("symbolic link in code inventory")
            digest.update((relative + "\0" + file_hash(path) + "\n").encode())
    return digest.hexdigest()


def audit_release(release: Path) -> list[str]:
    release = release.resolve()
    failures = []

    def require(condition, message):
        if not condition:
            failures.append(message)

    try:
        paths = list(release.rglob("*"))
        require(all(not p.is_symlink() for p in paths), "links zijn niet toegestaan in de installatie")
        require(all(p.is_file() or p.is_dir() for p in paths), "speciaal bestand in de installatie")
        require(all(p.stat().st_size > 0 for p in paths if p.is_file()), "leeg bestand in de installatie")
        require(all(any(p.iterdir()) for p in paths if p.is_dir()), "lege map in de installatie")
        require(
            not any(
                p.suffix in {".zip", ".bundle", ".pyc", ".pyo", ".bak"}
                or p.name in {"__pycache__", "node_modules", ".git"}
                for p in paths
            ),
            "cache of historisch archief in installatie",
        )
        require(
            {p.name for p in release.iterdir() if p.is_dir()}
            == {"app", "tools", "docs", "audit", "dependencies", "ops", "tests", "ci"},
            "onverwachte hoofdmap",
        )
        require(
            {p.name for p in (release / "tools").iterdir()} == TOOLS, "operationele toolinventaris wijkt af"
        )
        require(
            {p.name for p in (release / "audit").iterdir()}
            == {"README.md", "SOURCE_PROVENANCE.json", "VALIDATION.json", "evidence"},
            "onbekend auditbestand",
        )
        if failures:
            return failures
        identity = read_json(release / "RELEASE_IDENTITY.json")
        from verify_standalone_artifact import validate_release_identity

        validate_release_identity(identity)
        require(identity.get("application", {}).get("cacheRevision") == CACHE, "verkeerde cacheversie")
        require(
            identity.get("externalEvidence", {}).get("productionGo") is False,
            "productie-GO is onterecht toegekend",
        )
        actual = {
            p.relative_to(release).as_posix(): file_hash(p)
            for p in paths
            if p.is_file()
            and p.relative_to(release).as_posix() not in {"RELEASE_IDENTITY.json", "SHA256SUMS.txt"}
        }
        protected, deployment = (
            identity.get("protectedCriticalFiles", {}),
            identity.get("protectedDeploymentFiles", {}),
        )
        require(not set(protected).intersection(deployment), "dubbele beschermde paden")
        require({**protected, **deployment} == actual, "beschermde inventaris of hashes wijken af")
        runtime = read_json(release / "RUNTIME_CONTRACT.json")
        require(
            runtime.get("build") == REVISION and runtime.get("runtimeCompatibilityBuild") == REVISION,
            "runtimecontract heeft een andere versie",
        )
        from verify_assets import verify_assets

        verify_assets(release)
        require(
            f'INSTALLER_REVISION="{REVISION}"' in (release / "INSTALL_FROM_STAGE.sh").read_text(),
            "installeridentiteit wijkt af",
        )
        validation = read_json(release / "audit/VALIDATION.json")
        require(
            validation.get("schemaVersion") == 2 and validation.get("revision") == REVISION,
            "validatie-identiteit wijkt af",
        )
        require(
            validation.get("status") == "PASS_INTERNAL_EXTERNAL_ACCEPTANCE_PENDING",
            "functionele validatie niet geslaagd",
        )
        require(
            validation.get("validatedCodeSha256") == code_digest(release),
            "code gewijzigd sinds functionele validatie",
        )
        rows = validation.get("checks", [])
        require(isinstance(rows, list) and bool(rows), "geen validatiecontroles")
        ids = [row.get("id") for row in rows if isinstance(row, dict)]
        require(len(ids) == len(rows) == len(set(ids)), "dubbele of ongeldige validatiecontrole")
        require(REQUIRED_VALIDATION <= set(ids), "verplichte controles ontbreken")
        for row in rows:
            require(row.get("status") == "PASS", "controle is niet PASS")
            relative = str(row.get("evidenceFile", ""))
            require(bool(re.fullmatch(r"audit/evidence/[a-z0-9.-]+", relative)), "onveilig bewijspad")
            expected = row.get("evidenceSha256")
            require(
                file_hash(release / relative) == expected,
                "testbewijs ontbreekt of hash wijkt af: " + relative,
            )
        require(
            validation.get("physicalDeviceAcceptance") is False
            and validation.get("serverDeploymentPerformed") is False,
            "externe acceptatie wordt ten onrechte geclaimd",
        )
        from verify_source_provenance import verify_snapshot

        verify_snapshot(release)
    except (OSError, ValueError, TypeError, KeyError, AttributeError, RuntimeError) as error:
        failures.append("installatiecontract kan niet worden geverifieerd: " + str(error))
    return failures


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--release", type=Path, default=Path(__file__).resolve().parents[1])
    failures = audit_release(parser.parse_args().release)
    print(json.dumps({"status": "FAIL" if failures else "PASS", "failures": failures}, indent=2))
    return int(bool(failures))


if __name__ == "__main__":
    raise SystemExit(main())
