#!/usr/bin/env python3
"""Type-check dependency wiring and HTTP contracts; imports retain their own ownership.

This gate checks declared boundaries, not every implementation in the repository.
No mypy cache is written into the distributable tree.
"""

from __future__ import annotations
import json
from pathlib import Path
import subprocess
import sys

TARGETS = (
    "app/metod_app/runtime/application.py",
    "app/metod_app/catalog/runtime.py",
    "app/metod_app/pricing/runtime.py",
    "app/metod_app/runtime/ports.py",
    "app/metod_app/runtime/callbacks",
    "app/metod_app/runtime/resource_types.py",
    "app/metod_app/http/contracts.py",
    "app/metod_app/http/routes.py",
    "app/panel_contract.py",
    "app/metod_app/config.py",
    "app/metod_app/admin/network_policy.py",
    "app/metod_app/admin/customer_export_presentation.py",
)


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "mypy",
            "--follow-imports=silent",
            "--no-incremental",
            "--cache-dir=/dev/null",
            *TARGETS,
        ],
        cwd=root,
        capture_output=True,
        text=True,
        timeout=180,
    )
    print(
        json.dumps(
            {
                "status": "PASS" if result.returncode == 0 else "FAIL",
                "scope": list(TARGETS),
                "result": (result.stdout + result.stderr).strip(),
            }
        )
    )
    return result.returncode


if __name__ == "__main__":
    raise SystemExit(main())
