#!/usr/bin/env python3
from __future__ import annotations

"""Conservatively bound release, config, recovery checkpoint and install logs.

Only direct child directories with the exact METOD naming contract are ever
eligible.  The active release, the pre-deploy release and the current config
backup are mandatory keeps.  Unknown entries and symlinks are ignored.
"""

import argparse
import fcntl
import json
import os
import re
import shutil
import stat
import time
from dataclasses import dataclass
from pathlib import Path


DEPLOY_LOCK_PATH = Path("/run/metod-pax-deploy.lock")
RECOVERY_PATTERN = re.compile(r"ORPHAN_RECOVERY_[0-9]{8}_[0-9]{6}\.[A-Za-z0-9]{8}")
INSTALL_LOG_PATTERN = re.compile(r"install\.[A-Za-z0-9]{8}")
RECOVERY_COMPLETE_MARKER = "RECOVERY_CHECKPOINT_COMPLETE_V1\n"


@dataclass(frozen=True)
class Candidate:
    path: Path
    size: int
    mtime_ns: int


def _validate_lock_descriptor(descriptor: int) -> None:
    if descriptor < 3:
        raise RuntimeError("invalid deploy-lock descriptor")
    details = os.fstat(descriptor)
    if (
        not stat.S_ISREG(details.st_mode)
        or details.st_uid != 0
        or details.st_gid != 0
        or stat.S_IMODE(details.st_mode) != 0o600
        or details.st_nlink != 1
    ):
        raise RuntimeError("deploy lock must be root:root mode 0600 and singly linked")
    linked = DEPLOY_LOCK_PATH.lstat()
    if stat.S_ISLNK(linked.st_mode) or (details.st_dev, details.st_ino) != (linked.st_dev, linked.st_ino):
        raise RuntimeError("deploy-lock descriptor and canonical path differ")
    try:
        fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError as exc:
        raise RuntimeError("another METOD/PAX deploy operation is active") from exc


def _acquire_or_inherit_deploy_lock() -> int:
    contract = os.environ.get("METOD_DEPLOY_LOCK_CONTRACT", "")
    raw_descriptor = os.environ.get("METOD_DEPLOY_LOCK_FD", "")
    if contract or raw_descriptor:
        if contract != "v1" or not raw_descriptor.isdecimal():
            raise RuntimeError("incomplete inherited deploy-lock contract")
        descriptor = int(raw_descriptor)
        _validate_lock_descriptor(descriptor)
        return descriptor
    if os.geteuid() != 0:
        raise RuntimeError("direct history pruning requires root and the global deploy lock")
    if not Path("/run").is_dir() or Path("/run").is_symlink():
        raise RuntimeError("canonical deploy-lock root is unavailable")
    descriptor = os.open(
        DEPLOY_LOCK_PATH,
        os.O_RDWR | os.O_CREAT | getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_NOFOLLOW", 0),
        0o600,
    )
    try:
        os.fchmod(descriptor, 0o600)
        _validate_lock_descriptor(descriptor)
        return descriptor
    except Exception:
        os.close(descriptor)
        raise


def _canonical_root(path: Path) -> Path:
    if not path.is_absolute():
        raise ValueError(f"root must be absolute: {path}")
    if path.is_symlink():
        raise ValueError(f"root may not be a symlink: {path}")
    resolved = path.resolve(strict=True)
    if not resolved.is_dir():
        raise ValueError(f"root is not a directory: {resolved}")
    return resolved


def _tree_size(path: Path) -> int:
    total = 0
    stack = [path]
    while stack:
        directory = stack.pop()
        with os.scandir(directory) as entries:
            for entry in entries:
                details = entry.stat(follow_symlinks=False)
                mode = details.st_mode
                if stat.S_ISDIR(mode) and not stat.S_ISLNK(mode):
                    stack.append(Path(entry.path))
                elif stat.S_ISREG(mode) or stat.S_ISLNK(mode):
                    total += max(0, int(details.st_size))
                else:
                    raise ValueError(f"special file in managed history: {entry.path}")
    return total


def _collect(root: Path, pattern: re.Pattern[str], *, files: bool = False) -> list[Candidate]:
    found: list[Candidate] = []
    with os.scandir(root) as entries:
        for entry in entries:
            if not pattern.fullmatch(entry.name) or entry.is_symlink():
                continue
            path = root / entry.name
            details = entry.stat(follow_symlinks=False)
            if files:
                if (
                    not stat.S_ISREG(details.st_mode)
                    or details.st_nlink != 1
                    or details.st_uid != 0
                    or details.st_gid != 0
                    or stat.S_IMODE(details.st_mode) != 0o600
                ):
                    continue
                size = details.st_size
            else:
                if not stat.S_ISDIR(details.st_mode):
                    continue
                size = _tree_size(path)
            found.append(Candidate(path=path, size=size, mtime_ns=details.st_mtime_ns))
    return sorted(found, key=lambda item: (item.mtime_ns, item.path.name), reverse=True)


def _resolved_if_present(path: Path | None) -> Path | None:
    if path is None:
        return None
    try:
        return path.resolve(strict=True)
    except (FileNotFoundError, OSError):
        return None


def _fsync_directory(path: Path) -> None:
    descriptor = os.open(str(path), os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def prune_history(
    *,
    root: Path,
    pattern: re.Pattern[str],
    protected: set[Path],
    keep_count: int,
    max_age_days: int,
    max_bytes: int,
    now_ns: int | None = None,
    dry_run: bool = False,
    current_link: Path | None = None,
    files: bool = False,
) -> dict[str, object]:
    root = _canonical_root(root)
    if keep_count < 1 or max_age_days < 1 or max_bytes < 1:
        raise ValueError("history limits must be positive")
    candidates = _collect(root, pattern, files=files)
    recognized = {item.path.resolve(strict=True): item for item in candidates}
    mandatory = {path for path in protected if path in recognized}
    keep: set[Path] = set(mandatory)
    threshold_ns = (
        int(now_ns if now_ns is not None else time.time_ns()) - max_age_days * 86_400 * 1_000_000_000
    )

    for item in candidates:
        resolved = item.path.resolve(strict=True)
        if resolved in keep or item.mtime_ns < threshold_ns or len(keep) >= keep_count:
            continue
        keep.add(resolved)

    def kept_bytes() -> int:
        return sum(recognized[path].size for path in keep)

    optional_oldest = sorted(
        (recognized[path] for path in keep if path not in mandatory),
        key=lambda item: (item.mtime_ns, item.path.name),
    )
    while kept_bytes() > max_bytes and optional_oldest:
        remove = optional_oldest.pop(0)
        keep.discard(remove.path.resolve(strict=True))

    deletions = [item for item in candidates if item.path.resolve(strict=True) not in keep]
    deleted: list[str] = []
    reclaimed = 0
    for item in deletions:
        # Re-check the direct-child and exact-name invariants at mutation time.
        if item.path.parent != root or not pattern.fullmatch(item.path.name) or item.path.is_symlink():
            raise RuntimeError(f"unsafe history deletion target: {item.path}")
        resolved = item.path.resolve(strict=True)
        # The installer owns a global deploy lock, but the pruner is also safe
        # when invoked directly: never delete the release named by the live
        # current pointer at the actual mutation boundary.
        live_current = _resolved_if_present(current_link)
        if live_current is not None and live_current == resolved:
            keep.add(resolved)
            continue
        if not dry_run:
            if files:
                item.path.unlink()
            else:
                shutil.rmtree(item.path)
        deleted.append(item.path.name)
        reclaimed += item.size
    if deleted and not dry_run:
        _fsync_directory(root)

    kept_names = [recognized[path].path.name for path in keep]
    kept_names.sort()
    return {
        "root": str(root),
        "recognized": len(candidates),
        "kept": kept_names,
        "deleted": deleted,
        "reclaimedBytes": reclaimed,
        "remainingBytes": kept_bytes(),
        "mandatoryBytesOverLimit": kept_bytes() > max_bytes,
        "dryRun": dry_run,
    }


def _checkpoint_is_complete(path: Path) -> bool:
    """Recognize the completion boundary, including legacy pre-marker snapshots.

    Legacy snapshots copied credentials only after tar validation/checksumming.
    This structural fallback identifies that completed transaction boundary; it
    is not a replacement for full tar checksum verification during a restore.
    """
    archive = path / "external-state.tar"
    sidecar = path / "external-state.tar.sha256"
    credentials = path / "config/admin_credentials.live.json"
    try:
        for item in (archive, sidecar, credentials):
            details = item.lstat()
            if not stat.S_ISREG(details.st_mode) or details.st_nlink != 1 or details.st_size < 1:
                return False
        if (path / "config").is_symlink() or sidecar.stat().st_size > 128:
            return False
        if re.fullmatch(r"[a-f0-9]{64}  external-state\.tar\n", sidecar.read_text()) is None:
            return False
        marker = path / "SNAPSHOT_COMPLETE"
        if marker.exists() or marker.is_symlink():
            details = marker.lstat()
            if (
                not stat.S_ISREG(details.st_mode)
                or details.st_nlink != 1
                or details.st_size != len(RECOVERY_COMPLETE_MARKER)
            ):
                return False
            return marker.read_text() == RECOVERY_COMPLETE_MARKER
        return True
    except (OSError, UnicodeError):
        return False


def prune_recovery_checkpoints(
    *,
    root: Path,
    current: Path | None,
    committed: bool,
    keep_count: int,
    max_age_days: int,
    max_bytes: int,
    dry_run: bool = False,
) -> dict[str, object]:
    root = _canonical_root(root)
    candidates = _collect(root, RECOVERY_PATTERN)
    complete = [item for item in candidates if _checkpoint_is_complete(item.path)]
    protected = set()
    if current is not None:
        resolved = current.resolve(strict=True)
        if resolved not in {item.path for item in candidates}:
            raise ValueError("current recovery checkpoint is not an exact managed child")
        if not _checkpoint_is_complete(resolved):
            raise ValueError("current recovery checkpoint has not completed its snapshot boundary")
        protected.add(resolved)
    # During repeated failed recovery, keep the original pre-mutation snapshot
    # as well as the latest complete checkpoint. Intermediate attempts can be
    # pruned once a new full checkpoint exists. No evidence of success is
    # inferred merely from an existing pointer or an active service.
    if candidates and not committed:
        if complete:
            protected.add(complete[-1].path)
            protected.add(complete[0].path)
        else:
            # Without any proven complete snapshot, preserve partial evidence;
            # an operator must resolve the failed snapshot before any pruning.
            protected.update(item.path for item in candidates)
    return prune_history(
        root=root,
        pattern=RECOVERY_PATTERN,
        protected=protected,
        keep_count=keep_count,
        max_age_days=max_age_days,
        max_bytes=max_bytes,
        dry_run=dry_run,
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    operation = parser.add_mutually_exclusive_group()
    operation.add_argument("--recovery-only", action="store_true")
    operation.add_argument("--logs-only", action="store_true")
    parser.add_argument("--releases-dir", type=Path)
    parser.add_argument("--backup-root", type=Path)
    parser.add_argument("--current-link", type=Path)
    parser.add_argument("--previous-target", type=Path)
    parser.add_argument("--current-config-backup", type=Path)
    parser.add_argument("--version", default="R9RC4_FIX56_RUNTIME_PREFLIGHT")
    parser.add_argument("--release-keep", type=int, default=3)
    parser.add_argument("--release-max-age-days", type=int, default=180)
    parser.add_argument("--release-max-bytes", type=int, default=2 * 1024 * 1024 * 1024)
    parser.add_argument("--config-keep", type=int, default=10)
    parser.add_argument("--config-max-age-days", type=int, default=180)
    parser.add_argument("--config-max-bytes", type=int, default=512 * 1024 * 1024)
    parser.add_argument("--current-recovery-checkpoint", type=Path)
    parser.add_argument("--recovery-committed", action="store_true")
    parser.add_argument("--recovery-keep", type=int, default=2)
    parser.add_argument("--recovery-max-age-days", type=int, default=30)
    parser.add_argument("--recovery-max-bytes", type=int, default=20 * 1024 * 1024 * 1024)
    parser.add_argument("--install-log-root", type=Path)
    parser.add_argument("--current-install-log", type=Path)
    parser.add_argument("--install-log-keep", type=int, default=50)
    parser.add_argument("--install-log-max-age-days", type=int, default=30)
    parser.add_argument("--install-log-max-bytes", type=int, default=64 * 1024 * 1024)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()
    if args.logs_only and (args.install_log_root is None or args.current_install_log is None):
        parser.error("--logs-only requires --install-log-root and --current-install-log")
    if not args.logs_only and args.backup_root is None:
        parser.error("--backup-root is required")
    if not (args.recovery_only or args.logs_only) and any(
        path is None for path in (args.releases_dir, args.current_link, args.current_config_backup)
    ):
        parser.error("full history pruning requires release/current/config-backup paths")

    # Retention shares the exact deployment lock with install/export.  Without
    # it, a manual pruner could delete a newly published release directory in
    # the short interval before the installer switches the current pointer.
    deploy_lock_descriptor = _acquire_or_inherit_deploy_lock()

    if not re.fullmatch(r"[A-Z0-9_]{8,80}", args.version):
        raise SystemExit("invalid version prefix")
    # The immutable release directory is keyed by the complete manifest digest.
    # Accepting the historical 12-hex prefix would make two distinct manifests
    # share one retention namespace and could prune/preserve the wrong release.
    prefixes = "(?:" + "|".join(map(re.escape, (args.version, "FIX660R8_PRELIVE_HARDENED"))) + ")"
    release_pattern = re.compile(prefixes + r"_[a-f0-9]{64}")
    config_pattern = re.compile(prefixes + r"_config_[0-9]{8}_[0-9]{6}")
    current = _resolved_if_present(args.current_link)
    previous = _resolved_if_present(args.previous_target)
    current_config = _resolved_if_present(args.current_config_backup)

    report = {"schemaVersion": 2}
    if not (args.recovery_only or args.logs_only):
        report["releases"] = prune_history(
            root=args.releases_dir,
            pattern=release_pattern,
            protected={path for path in (current, previous) if path is not None},
            keep_count=args.release_keep,
            max_age_days=args.release_max_age_days,
            max_bytes=args.release_max_bytes,
            dry_run=args.dry_run,
            current_link=args.current_link,
        )
        report["configBackups"] = prune_history(
            root=args.backup_root,
            pattern=config_pattern,
            protected={path for path in (current_config,) if path is not None},
            keep_count=args.config_keep,
            max_age_days=args.config_max_age_days,
            max_bytes=args.config_max_bytes,
            dry_run=args.dry_run,
        )
    if not args.logs_only:
        report["recoveryCheckpoints"] = prune_recovery_checkpoints(
            root=args.backup_root,
            current=args.current_recovery_checkpoint,
            committed=args.recovery_committed,
            keep_count=args.recovery_keep,
            max_age_days=args.recovery_max_age_days,
            max_bytes=args.recovery_max_bytes,
            dry_run=args.dry_run,
        )
    if args.install_log_root is not None:
        current_log = _resolved_if_present(args.current_install_log)
        report["installLogs"] = prune_history(
            root=args.install_log_root,
            pattern=INSTALL_LOG_PATTERN,
            protected={current_log} if current_log is not None else set(),
            files=True,
            keep_count=args.install_log_keep,
            max_age_days=args.install_log_max_age_days,
            max_bytes=args.install_log_max_bytes,
            dry_run=args.dry_run,
        )
    print(json.dumps(report, sort_keys=True, separators=(",", ":")))
    # Keep the descriptor live through the final report write; process exit
    # releases inherited and directly acquired locks alike.
    assert deploy_lock_descriptor >= 3
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
