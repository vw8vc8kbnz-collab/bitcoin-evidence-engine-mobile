#!/usr/bin/env python3
from __future__ import annotations

"""Prepare and atomically apply an authenticated legacy-admin upgrade."""

import argparse
import hashlib
import os
import sys
import termios
from pathlib import Path


RELEASE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RELEASE_ROOT / "app"))

from metod_app.security.credentials import (  # noqa: E402
    pbkdf2_hash_password,
    verify_password_against_stored,
)
from safety_contracts import durable_write_json  # noqa: E402
from install_state_gate import (  # noqa: E402
    legacy_single_user,
    strict_json,
    validate_credentials,
    validate_users,
)


def _require_secure_file(path: Path, label: str) -> None:
    if path.is_symlink() or not path.is_file():
        raise ValueError(f"{label} is geen regulier bestand")
    metadata = path.stat()
    if metadata.st_uid != 0 or metadata.st_nlink != 1:
        raise ValueError(f"{label} moet root-owned en enkelvoudig gelinkt zijn")
    if metadata.st_mode & 0o777 not in {0o400, 0o600}:
        raise ValueError(f"{label} moet mode 0400 of 0600 hebben")


def secure_tty_secret(prompt: str) -> str:
    """Read only from a controlling TTY after proving echo is disabled."""
    try:
        fd = os.open("/dev/tty", os.O_RDWR | getattr(os, "O_NOCTTY", 0))
    except OSError as exc:
        raise ValueError("geen veilige interactieve TTY beschikbaar") from exc
    original = None
    echo_changed = False
    try:
        try:
            original = termios.tcgetattr(fd)
        except termios.error as exc:
            raise ValueError("TTY-instellingen konden niet veilig worden gelezen") from exc
        hidden = original.copy()
        hidden[3] &= ~termios.ECHO
        termios.tcsetattr(fd, termios.TCSAFLUSH, hidden)
        echo_changed = True
        if termios.tcgetattr(fd)[3] & termios.ECHO:
            raise ValueError("TTY-echo kon niet fail-closed worden uitgeschakeld")
        os.write(fd, prompt.encode("utf-8", errors="strict"))
        value = bytearray()
        while len(value) <= 1024:
            chunk = os.read(fd, 1)
            if not chunk:
                raise ValueError("wachtwoordinvoer werd onverwacht afgesloten")
            if chunk in {b"\n", b"\r"}:
                break
            value.extend(chunk)
        else:
            raise ValueError("wachtwoordinvoer is te lang")
        return value.decode("utf-8", errors="strict")
    finally:
        if original is not None and echo_changed:
            termios.tcsetattr(fd, termios.TCSAFLUSH, original)
            os.write(fd, b"\n")
        os.close(fd)


def prepare_upgrade(
    credentials: Path,
    prepared: Path,
    *,
    secret_reader=secure_tty_secret,
    allowed_parent: Path = Path("/run"),
) -> bool:
    _require_secure_file(credentials, "credentials")
    if not prepared.is_absolute() or prepared.parent != allowed_parent:
        raise ValueError("voorbereid credentialpad moet direct onder /run staan")
    if not prepared.name.startswith("metod-pax-credential-migration.") or prepared.exists():
        raise ValueError("onveilig of bestaand voorbereid credentialpad")

    source_bytes = credentials.read_bytes()
    value = strict_json(credentials)
    users = value.get("users") if isinstance(value, dict) else None
    changed = False
    if isinstance(users, list) and users:
        validate_credentials(credentials, production=True)
        target = value
    else:
        user = legacy_single_user(value)
        validate_users([user], production=True, allow_legacy_password_hash=True)
        stored_hash = str(user["password_hash"])
        verified_password = ""
        for attempt in range(1, 4):
            password = secret_reader(f"Bestaand adminwachtwoord (verborgen, poging {attempt}/3): ")
            if verify_password_against_stored(password, stored_hash):
                verified_password = password
                break
            password = ""
            print("Wachtwoordcontrole mislukt.", file=sys.stderr)
        if not verified_password:
            raise ValueError("bestaand adminwachtwoord kon niet worden bevestigd")
        new_password = secret_reader("Nieuw adminwachtwoord (minimaal 16 tekens, verborgen): ")
        repeated = secret_reader("Herhaal nieuw adminwachtwoord (verborgen): ")
        if len(new_password) < 16:
            raise ValueError("nieuw adminwachtwoord moet minimaal 16 tekens zijn")
        if new_password != repeated:
            raise ValueError("nieuwe adminwachtwoorden zijn niet gelijk")
        if new_password == verified_password:
            raise ValueError("nieuw adminwachtwoord moet verschillen van het oude")
        user["password_hash"] = pbkdf2_hash_password(new_password)
        verified_password = password = new_password = repeated = ""
        target = {"schemaVersion": 2, "users": [user]}
        validate_users(target["users"], production=True)
        changed = True

    envelope = {
        "schemaVersion": 1,
        "sourceSha256": hashlib.sha256(source_bytes).hexdigest(),
        "credentials": target,
    }
    durable_write_json(prepared, envelope, mode=0o600)
    _require_secure_file(prepared, "voorbereide credentials")
    return changed


def apply_upgrade(credentials: Path, prepared: Path, *, allowed_parent: Path = Path("/run")) -> bool:
    _require_secure_file(credentials, "credentials")
    if not prepared.is_absolute() or prepared.parent != allowed_parent:
        raise ValueError("voorbereid credentialpad moet direct onder /run staan")
    _require_secure_file(prepared, "voorbereide credentials")
    envelope = strict_json(prepared)
    if (
        not isinstance(envelope, dict)
        or set(envelope) != {"schemaVersion", "sourceSha256", "credentials"}
        or envelope.get("schemaVersion") != 1
    ):
        raise ValueError("voorbereid credentialcontract is ongeldig")
    source_digest = hashlib.sha256(credentials.read_bytes()).hexdigest()
    if envelope.get("sourceSha256") != source_digest:
        raise ValueError("live credentials wijzigden na de wachtwoordcontrole")
    target = envelope.get("credentials")
    if not isinstance(target, dict) or target.get("schemaVersion") != 2:
        raise ValueError("voorbereide schema-v2 credentials ontbreken")
    users = target.get("users")
    if not isinstance(users, list):
        raise ValueError("voorbereide individuele users[] ontbreken")
    validate_users(users, production=True)
    before = credentials.read_bytes()
    durable_write_json(credentials, target, mode=0o600)
    validate_credentials(credentials, production=True)
    prepared.unlink()
    return credentials.read_bytes() != before


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--credentials", type=Path, required=True)
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument("--prepare", type=Path)
    modes.add_argument("--apply", type=Path)
    args = parser.parse_args()
    try:
        if not args.credentials.is_absolute():
            raise ValueError("credentialpad moet absoluut zijn")
        if args.prepare is not None:
            changed = prepare_upgrade(args.credentials, args.prepare)
            action = "voorbereid" if changed else "schema-v2 gecontroleerd"
        else:
            changed = apply_upgrade(args.credentials, args.apply)
            action = "toegepast" if changed else "ongewijzigd gecontroleerd"
    except Exception as exc:
        print(f"ADMIN CREDENTIAL MIGRATION: FAIL: {exc}")
        return 1
    print(f"ADMIN CREDENTIAL MIGRATION: PASS ({action})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
