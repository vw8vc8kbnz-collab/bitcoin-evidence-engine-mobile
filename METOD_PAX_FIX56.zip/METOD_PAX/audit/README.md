# Actueel auditdossier — FIX56

FIX56 herstelt een door de gebruiker aangetoonde mislukte FIX55-installatie. De Termius-regel had de installer bereikt; de runtime-preflight crashte. De screenshot meldde rollback van releasepointer en configuratie. De daadwerkelijke serverstatus is vanuit deze omgeving niet geïnspecteerd.

## Oorzaak en correctie

In `tools/final_preflight.py` overschaduwde `stat = os.statvfs(...)` de geïmporteerde module `stat` binnen `validate_runtime`. Een bestaand `backup-budget.env` veroorzaakte daardoor `UnboundLocalError` bij `stat.S_ISREG`. De lokale waarde heet nu `filesystem_stats`. De regels voor bestandsrechten, eigenaar, toegestane instellingen en reserves blijven behouden.

De nieuwe geïsoleerde test vond daarnaast `ModuleNotFoundError: metod_app`: de via exact bestandspad geladen prijsvalidator importeert `metod_app.pricing.tax`, terwijl de deploystart met `-I -S -B` geen app-importpad heeft. De loader voegt nu alleen het gecontroleerde app-pad binnen dezelfde release tijdelijk toe. Python-isolatie en checksumverificatie blijven ingeschakeld.

De eerdere testsuite dekte deze combinatie van bestaande serverconfiguratie en runtime-entrypoint onvoldoende. Negen nieuwe regressies leggen dit vast. Ruff-regel F823 is toegevoegd aan de bestaande lintgate en detecteert de oorspronkelijke naamoverschaduwing.

## Validatie en begrenzing

190 Python/API/regressietests en tien echte Chromium-browserjourneys worden voor deze release opnieuw uitgevoerd; `VALIDATION.json` en de gekoppelde bewijsbestanden bevatten de actuele uitkomst. Zeven Node-annuleringstests blijven binnen één Python-wrapper geteld. Mypy omvat 21 bronbestanden. De oorspronkelijke fout is vóór de correctie met dezelfde nieuwe tests gereproduceerd; het bewijs staat in `runtime-preflight-before.log`.

De volledige runtimecontrole gebruikt tijdelijke state, synthetische credentials en de environmenttemplate uit `DEPLOY.sh`. Geldige en ontbrekende budgetbestanden worden getest, naast verkeerde rechten, symlinks, directories, eigenaar, verboden extra instellingen en onvoldoende inodes. Een subprocess start met dezelfde Python-isolatie als de deploy. De definitieve ZIP krijgt bovendien een lokale proef van het echte CLI-entrypoint met checksum- en runtimecontrole. Er wordt geen hostservice of VPS veranderd.

Applicatiebron, prijsberekening, opslagformaat, frontend, CSS, templates, Admin en optimizer blijven gelijk aan FIX55, uitgezonderd gegenereerde versieaanduidingen en assets. De catalogus-/prijsuitkomsten worden opnieuw met de vastgelegde FIX54-baseline vergeleken. Nerf blijft standaard aan. W-04 blijft open; deze release doet geen aanvullende domeinrefactor.

## Herkomst en levering

`VALIDATION.json` bindt actueel bewijs aan de code. `SOURCE_PROVENANCE.json` koppelt FIX56 aan de directe FIX55-ouder `5f58b3ebd877dfac4ad8c3f6c58c1a9ee8aa1770`. De Git-bundle bewaart beschikbare lokale geschiedenis; onbekende eerdere upstreamgeschiedenis blijft ongeverifieerd. Release-identiteit, bronprovenance en checksummanifest worden na het commit gegenereerd.

Volg `docs/TESTEN.md` en `docs/INSTALLATIE.md`. Gebruik uitsluitend de definitieve `METOD_PAX_FIX56.zip` met de bijgeleverde SHA-256 en Termius-regel; hernoem geen ouder pakket. FIX55 en zijn hash blijven historische artefacten.

## Externe acceptatie

Eigen lokale verificatie met AI-ondersteuning is geen onafhankelijke audit. Exacte VPS-installatie, live Admin, echte iPhone/Safari en Android/Chrome, externe CI, werkelijke IP/VPN-allowlist, versleutelde live state en offsite-account, herstel op een tweede server en onafhankelijke security/toegankelijkheids/CAM-acceptatie blijven open. De eerdere mislukte FIX55-installatiepoging is geen geslaagde serveracceptatie. Productiegoedkeuring en `releaseEligible` blijven false. De bestaande backupgrenzen worden niet gewijzigd.
