# Filters en groepen beheren

Open Admin → **Filters & groepen**. Elke geslaagde handeling wordt direct opgeslagen. Vernieuw Tool A om de wijzigingen te zien. Een geopende configurator ververst de catalogus ook wanneer je terugkeert naar het venster.

Kies **Merk / groep**, **Uiterlijk** of **Kleurgroep**. Merk / groep staat in het uitklapfilter en bovenaan de decor-tegels; Uiterlijk bepaalt de filterknoppen boven de bibliotheek en het uiterlijklabel; Kleurgroep bepaalt de kleurkeuze. De oorspronkelijke productgegevens blijven bewaard.

- **Groep aanmaken:** vul een naam in en klik Aanmaken. De groep wordt zichtbaar voor klanten zodra er een beschikbaar materiaal in zit.
- **Hernoemen:** wijzig de naam bij een groep en klik Opslaan. De materialen blijven gekoppeld.
- **Volgorde:** gebruik de pijlen omhoog/omlaag.
- **Verplaatsen:** zoek materialen of kies hun huidige groep, vink één of meer materialen aan, kies de bestemming en klik Verplaatsen. Met ‘Alle zoekresultaten selecteren’ selecteer je ook resultaten op volgende pagina’s. De teller toont je hele selectie; ‘Selectie wissen’ maakt die leeg. Maximaal 1000 materialen per handeling.
- **Automatische indeling:** selecteer materialen en klik Automatische indeling. Dit herstelt alleen het gekozen filter; handmatige keuzes in de andere filters blijven bewaard.
- **Verwijderen:** klik bij een groep op Verwijderen, kies een andere groep en bevestig. Huidige én toekomstige automatisch ingedeelde materialen worden naar die groep verwezen. Er verdwijnen geen materialen.

De indeling geldt onmiddellijk voor de volgende catalogusopvraag. Er is geen extra publiceerknop. CSV-producten toevoegen/verwijderen en hun prijzen aanpassen blijven onderdeel van de bestaande CSV-publicatie. Filterbeheer wijzigt geen verkoopprijzen, afmetingen, DXF, nerfregels of bestaande offertes.

## Automatische indeling

Nuxe en expliciete fineerproducten horen bij Fineer. Generieke grondeerfolieproducten horen bij Grondeerfolie. Een grondeerfolie-achterzijde verandert het merk van bijvoorbeeld een Unilin-decor niet. Onbekende merken blijven Overig; een onbekend product wordt niet automatisch als Fineer geclaimd.

Bestaande handmatige keuzes blijven behouden. Het aantal beschikbare materialen komt uit de actuele live catalogus; dit document bevat geen verouderde vaste telling.

Bestaande uiterlijk- en kleurwaarden vormen de andere standaardfilters. Ook nieuwe CSV-artikelen krijgen automatisch hun indeling. Handmatige toewijzingen blijven bewaard zolang het CSV-artikelnummer gelijk blijft, ook wanneer een artikel tijdelijk ontbreekt en later terugkeert. Een geheel nieuw artikelnummer krijgt de automatische indeling.

## Gelijktijdig beheer en fouten

Als een ander Admin-venster of een CSV-publicatie de situatie inmiddels heeft veranderd, wordt een verouderde wijziging geweigerd. De editor toont een melding en bewaart je invoer totdat je herlaadt. Controleer na Herladen de actuele situatie en voer de wijziging opnieuw uit. Ook na een time-out moet je eerst herladen: een verzoek kan wel op de server zijn opgeslagen terwijl de bevestiging uitbleef.

De server bewaart de instelling in het bestaande externe state-volume: `system/material_filters.json`. De normale systeembackup neemt dit bestand mee. De installatie overschrijft het niet. Bewaar bij een servermigratie het volledige state-volume; alleen de applicatie-ZIP kopiëren is geen datamigratie.
