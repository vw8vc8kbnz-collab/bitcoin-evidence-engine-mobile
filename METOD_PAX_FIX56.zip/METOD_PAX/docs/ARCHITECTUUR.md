# Architectuur

## Frontend en HTML

`app/tool-a/templates/shell.html` beschrijft de pagina. De afzonderlijke HTML-componenten bevatten onder meer materiaalkeuze, panelen, klantgegevens, nerf, overzicht, checkout en dialoogvensters. `app/toolA.html` is het reproduceerbare resultaat; wijzig de componenten, niet het resultaat.

`app/tool-a/main.js` importeert native ES-modules. De browser laadt één gebundelde `type="module"`-entry en één stylesheet. De build verwijdert geen imports uit brontekst en zet geen losse scripts achter elkaar. `package-lock.json` legt de buildafhankelijkheden vast. De server serveert alleen expliciet toegestane publieke bestanden.

| Onderdeel | Eigenaar |
| --- | --- |
| Berekening, DXF en maatvoering in de browser | tool-a/domain/ |
| Server- en UI-koppelingen | tool-a/adapters/ en shell/ |
| Materiaalbibliotheek, overzicht en nerfweergave | tool-a/views/ en components/ |
| Gedeelde configuratietoestand | tool-a/state/ en runtime/modules/configuration-state.js |
| Runtime samenstellen | tool-a/runtime/composition-root.js |
| HTML-markup | tool-a/templates/ |
| CSS | tool-a/styles/ |

De oude verborgen routekeuze is verwijderd, inclusief eventhandlers en DOM-referenties. De twee verborgen actieknoppen voor berekenen/toevoegen zijn nog functionele eventdoelen van de wizard. Ook de mobiele handgreep is functioneel. Die onderdelen zijn geen lege placeholders.

De mobiele observerlus is verwijderd. CSS bepaalt de mobiele indeling; JavaScript wijzigt niet voortdurend dezelfde attributen waarop een observer luistert. De browsertest voert de volledige bestelling uit op 390 pixels breed en registreert browserfouten.

`styles/tokens.css` bevat uitsluitend gedeelde custom properties, inclusief hun mediaqueries. De basisregels zijn verdeeld over `foundation`, `panel-dock`, `forms-overlays`, `grain-editor`, `material-selection`, `wizard-checkout` en `responsive-foundation`. `styles/main.css` legt de cascadevolgorde vast. Bestaande component-, mobiele en checkoutregels blijven daarna in hun oorspronkelijke volgorde staan. Verplaats een regel niet alleen omdat zijn selector bij een ander scherm lijkt te horen: specificiteit en volgorde bepalen het resultaat.

De algemene entry- en routefooteradapters zijn verwijderd: er waren geen actieve afnemers. De actieve paneeladapter krijgt functies van de composition root en wordt rechtstreeks als ES-module geïmporteerd. Eenmalige eventregistraties en lokale timers zitten in hun eigen module of runtime-instantie. Overige bestaande globals, waaronder delen van paneelbewerking en gedeelde DXF-caches, zijn nog niet volledig gemigreerd.

De footer gebruikt dezelfde paneelstatus als de overige controls. Een gekozen template-ID is onvoldoende om toevoegen toe te staan: de template moet ook werkelijk in de geladen templateverzameling staan. Elke wijziging van de laadstatus ververst die controls. De submitvalidatie blijft de afzonderlijke grens vóór een paneel aan de configuratie wordt toegevoegd.

## Backend

`app/server_py.py` is de CLI-ingang. Waitress verzorgt HTTP via de WSGI-adapter. De applicatieserver bindt uitsluitend aan een numeriek loopbackadres, met begrensde verbindingen en workerthreads. Inactieve backendverbindingen verlopen na 10 seconden. nginx buffert requestbodies en begrenst langzame clients vóór zij de backend bezetten. De optimizer draait als apart, begrensd proces.

De samenstelling gebruikt expliciete, bevroren dependencies en runtime-interfaces. Een module krijgt geen `sys.modules[__name__]`-object met de volledige applicatienamespace. Standaardbibliotheken worden rechtstreeks geïmporteerd. De composition root bevat zichtbare bedrading; domeinlogica hoort in de domeinmodule. Eén bevroren `RuntimeCompositionPorts` wordt gedeeld door de beide servicebouwers. Beschikbare functies worden rechtstreeks gekoppeld; uitgestelde callbacks zijn alleen nodig bij wederzijdse afhankelijkheden of veranderlijke resources. Runtime-resources hebben concrete types en functiecontracten staan per domein in `runtime/callbacks/`. `tools/check_types.py` controleert deze grenzen en de samenstelling met mypy. Dynamische JSON blijft expliciet als JSON-data gemodelleerd; dit is geen claim dat de gehele applicatie statisch is getypeerd.

De 87 HTTP-routebeschrijvingen gebruiken benoemde `RouteDefinition`-, `BodyPolicy`- en `RateLimitPolicy`-velden. Er is geen lange positionele routetuple meer. De bestaande toegangseisen en limieten zijn inhoudelijk behouden.

Stickeruitvoer scheidt bestandsinvoer van de pure stickerprojectie. `optimizer/packing_attempt.py` bezit de toestand van één packingpoging en afzonderlijke keuzes/plaatsingsstappen. `storage/operational_cleanup.py` verdeelt retentie naar gegevenssoort en beschermt actieve catalogus-, synchronisatie- en ordergegevens. De cataloguswoordenlijsten zijn onveranderlijke gegevens in `catalog/presentation_rules.py`. Klantgegevens en bestelsamenvattingen hebben eigen pure projecties onder `requests/`.

Resterende foutmeldingen en actieve browseradapters zijn functioneel. De actuele telling en de gebruikte meetmethode staan in het auditdossier; er wordt geen nul-globalsclaim gedaan.

Jobaanmaak is opgesplitst in toelating, requestvalidatie, opslag, scheduling, uitvoering, status en finalisatie. De optimizer heeft afzonderlijke modules voor modellen, geometrie, heuristieken, packing, prijs, voortgang, profiling en CLI. De publieke optimizer-ingang blijft een kleine compatibele facade. Aanvraagvalidatie gebruikt aparte controles voor identifiers, klantgegevens, materiaalregels, quote en panelen.

Er blijven langere algoritmische functies en transacties bestaan. Het aantal regels is geen harde correctheidsgarantie. De refactor is getoetst met gedragstests, alle 46 sjablonen en 184 browser-DXF-exportcombinaties; een onafhankelijke CAM-controle van echte productie blijft nodig.

## Eigenaarschap catalogus en prijzen — FIX55

`CatalogRuntime` bezit nu zijn eigen materiaalnaamcache, lookupcache en hashcache met bijbehorende hashlock. De centrale module bezit deze vier variabelen niet meer. De HTTP-responsecache blijft expliciet gedeeld met de publieke HTTP-handler; de materiaal- en publicatielocks blijven gedeeld met prijsberekening en cataloguspublicatie. Die bestaande lockvolgorde en transacties zijn niet veranderd.

De cataloguscontracten dalen van 18 naar 9 velden en de prijscontracten van 25 naar 20. Elf verwijderde callbackvelden verwezen via de applicatiemodule terug naar de eigenaar zelf; drie andere velden leverden uitsluitend private caches/lock aan. Deze afhankelijkheden zijn verwijderd, niet achter een algemene servicezoeker verstopt. Interne methodeaanroepen zijn rechtstreeks; echte externe paden, locks en bewerkingen blijven expliciete dependencies.

De bestaande functienamen in `runtime/application.py` blijven gebonden aliases voor hun afnemers. Interne monkeypatching van verwijderde private cacheglobals of terugkoppelingen is geen ondersteunde uitbreidingsinterface. Testopstellingen gebruiken nu de eigenaar en de expliciete ports. Dynamische padsuppliers blijven dynamisch. Er zijn geen nieuwe modulebestanden nodig voor deze refactor.

`tests/runtime_behavior_snapshot.py` is ongewijzigd tegen FIX54 en FIX55 uitgevoerd in afzonderlijke processen met echte applicatiesamenstelling en tijdelijke state. Acht resultaatgroepen zijn volledig gelijk: materiaalnamen, cataloguslookup, hashcache, publicatie/rollback, DXF-classificatie/migratie/manifest, prijsopslag/audit/conflicten, achttien offertes en de gezaghebbende prijsmomentopname. Alleen de geïnjecteerde klok en gegenereerde prijsversiefilenamen zijn genormaliseerd. De fixture vermeldt FIX54 in de naam en wordt niet met een nieuwe gewenste uitkomst overschreven.

De typecheck omvat nu ook de twee aangepaste domeinimplementaties (21 bronbestanden totaal). Gemengde JSON-resultaten blijven expliciet dynamisch; dit is geen volledige strikte typering. De centrale samenstelling en frontend bevatten nog andere koppelingen en omvangrijke modules. W-04 blijft open; deze ronde claimt geen volledige herbouw.

## Prijswaarheid en fouten

Gepubliceerde plaatprijzen inclusief btw en een servermomentopname van de prijstabel bepalen een nieuwe berekening. De server gebruikt geen meegestuurde klantprijs als waarheid. Bestaande verzegelde offertes veranderen niet bij een Admin-prijswijziging. Meldingen gebruiken verzegelde prijs-JSON; ongeldige numerieke input wordt niet stil een offerte van nul euro.

Verwachte invoer- en bestandsfouten hebben gerichte afhandeling. Onverwachte fouten bereiken de request-/procesgrens of worden als herstelgebeurtenis geregistreerd. De begrensde logger registreert type en codepositie zonder exceptiontekst, bronregels of klantinhoud. Brede catches bij transactierollback, workergrenzen en optionele diagnostiek zijn bewust behouden.

## Identiteit en compatibiliteit

`VERSION.json` is de releasebron. De twee oudere **wire-schema-identifiers** `FIX655_DXF_REF_V1` en `FIX660R8_SERVER_CANONICAL_V1`, de bestaande externe-state-markering en de vorige beheerde releasemapnaam blijven leesbaar voor upgrades en bestaande data. Dat zijn protocol- en migratiecontracten. Publieke healthchecks tonen geen buildnummer. Verificatie koppelt de geserveerde HTML en assets aan de exacte huidige bestandsinhoud.

De lokale Git-snapshot en de hashinventaris zijn controleerbaar. Het afzonderlijke source-bundle bevat het importpunt en de daaropvolgende wijzigingen; onbekende oudere upstream-auteurs of tags worden niet als bewezen voorgesteld. Ontwikkeling en voorgaande reviews zijn met AI ondersteund. Eerdere commit-auteurs blijven behouden; bronhistorie wordt niet herschreven om ontwikkelhulpmiddelen te verbergen. Voorgaande reviews en onze automatische tests gelden niet als onafhankelijke menselijke audit.

## Uitgevoerde opschoning en resterend onderhoud

FIX55 bouwt voort op FIX54 en de onderhoudsronde van FIX53. De CSS-bronnen en gebouwde stylesheet zijn ongewijzigd. W-04 blijft gedeeltelijk open: onderstaande eerdere verbeteringen zijn behouden; dit is geen nieuwe brede opschoning.

De in FIX54 toegevoegde pure module `tool-a/api/cancellation-response.js` controleert annuleringen op HTTP-status, expliciete bevestigingsvelden en de exacte job-/aanvraagreferentie. Zowel de jobclient (herstelopslag) als de annuleringsinterface gebruikt hetzelfde contract. Transportdeadlines omvatten ook de antwoordbody. De interface toont uitsluitend vaste lokaal gekozen foutteksten; servervelden en onverwachte exceptionteksten worden niet als klantmelding gebruikt.

Na een bevestigde aanvraagannulering blijft jobopruiming best effort. Het lokale resetpad vervangt bevroren klantsnapshots en hangt niet meer af van de uitgeschakelde serverconceptopslag (`/api/draft/save` is voor lege writes een compatibele no-op). Een onverwachte resetfout na bevestiging meldt dat opnieuw starten niet lukte, in plaats van ten onrechte te beweren dat alles behouden is.

Coverage is opgeslagen per geteste flow en exacte asset. Niet-uitgevoerde code is geen automatische verwijderlijst.
| Onderdeel | Uitgevoerd | Resterend |
| --- | --- | --- |
| Frontend | Twee ongebruikte adapters, een lege mountfunctie en ongebruikte terugvalkoppelingen verwijderd. Lokale registratievlaggen uit de browserglobals gehaald. | Verdere globals en oude terugvalpaden domein voor domein migreren; niet volledig afgerond. |
| CSS | Echte tokens, opgesplitste basisregels, 224 identieke dubbele declaraties en 43 onbereikbare selectorvarianten verwijderd. Cascadevolgorde van alle overige schermregels behouden. | Mobiele en componentstijlen bevatten nog omvangrijke bestaande regels; een volledige herindeling vereist aanvullende acceptatie. |
| Installatie | Eén implementatie van deploylocking voor installatie, update en migratie. Eén beschreven pad voor previewupdates en één voor een nieuwe server. | Complete installatie, onderbroken update en rollback op een wegwerp-VPS blijven externe acceptatie. |
| Prijzen en nesting | Aanvullende cent-/btw-/prijsvalidatie, exacte plaatrand, gap, rotatie, nerfstapel en 60 reproduceerbare combinaties met onafhankelijke geometrische invarianten. | Controle met representatieve productieopdrachten en CAM blijft nodig. |

Geen reductiedoel in procenten en geen automatische productiegoedkeuring: een wijziging is pas geslaagd wanneer werking en herstel behouden blijven. De echte iPhone-acceptatie hoort bij deze exacte nieuwe versie. Het pakket bevat één actueel auditdossier; bronhistorie blijft in de losse Git-bundle.
