# Installatie en acceptatie

## Bestaande previewserver bijwerken

1. Bewaar de bestaande werkende installatie en controleer dat de laatste backup beschikbaar is.
2. Plaats `METOD_PAX_FIX56.zip` in de hoofdmap van de bestaande repository. Gebruik de los geleverde Termius-regel met de exacte SHA-256 van deze zip.
3. De regel controleert de zip, pakt uit naar een nieuwe tijdelijke map en voert `INSTALL_STAGING_PREVIEW_UPDATE.sh` uit. Gebruik geen extractie over een oude versie heen.
4. Wacht op `FIX56_STAGING_UPDATE_OK`. Controleer Tool A met `?fix56=1` en Admin. Browsercache wissen is normaal niet nodig: JS/CSS hebben nieuwe inhoudshashes.

Het previewscript leest de bestaande HTTPS-preview-URL uit `/etc/adzaagt/metod-pax/preview-url`. Het verandert de externe URL niet. Een verlopen Cloudflare-tunnel moet eerst door de beheerder worden hersteld. Een fout in de externe HTTP-controle na de deploy betekent niet automatisch dat de oude versie nog draait; controleer dan de actieve release en services.

## Verantwoordelijkheid van de vijf scripts

| Script | Doel |
| --- | --- |
| INSTALL_STAGING_PREVIEW_UPDATE.sh | Normale update van de bestaande preview, gevolgd door backend/nginx/externe HTTP-controle |
| INSTALL_FROM_STAGE.sh | Vergrendelde, gecontroleerde releasewissel met rollback vóór de live-commit |
| DEPLOY.sh | Service- en nginxconfiguratie; aangeroepen door de installer |
| EXPORT_METOD_PAX_MIGRATION_BUNDLE.sh | Gecontroleerde versleutelde export van actuele state, verwijderlogboek en credentials |
| INSTALL_METOD_PAX_CLEAN_SERVER.sh | Expliciete import op een schone Debian/Ubuntu-server; weigert bestaande installaties |

`ops/deploy_lock.sh` bevat de gedeelde lockfuncties. Dit bestand wordt door de scripts ingelezen en is geen los installatiepad. De lock beschermt ook geneste aanroepen; een concurrerende operatie wordt geweigerd.

Deze scripts hebben verschillende taken; ze zijn geen vijf oude installers. De beschermingen voor bronhashes, schrijfbare uploads, deploylocks, onderhoudsmodus en rollback blijven behouden. Na een geslaagde live-commit rolt een late rapportagefout de applicatie niet automatisch terug.

De nieuwe release wordt root-owned en read-only geïnstalleerd. Externe state en credentials worden niet vervangen door demo-data. Een bestaande Admin-netwerkbeperking blijft bij een update behouden. Een leeg ingestelde `ADMIN_ALLOWED_NETWORKS` is alleen toegestaan in staging; productie vereist expliciet jouw beheer-IP-adressen of VPN-netwerken.

`METOD_HOST` moet ontbreken of `127.0.0.1` zijn. Waarden zoals `0.0.0.0`, `localhost` en `::1` worden expliciet geweigerd vóór de server start. De externe verbinding loopt via nginx. Een ongeldige `ADMIN_ALLOWED_NETWORKS` blokkeert Admin; staging logt de oorzaak eenmaal bij het starten terwijl Tool A beschikbaar blijft. Productie weigert in dat geval te starten. Controleer de melding met `sudo journalctl -u metod-pax.service -n 100 --no-pager`, corrigeer de instelling in `/etc/adzaagt/metod-pax/metod-pax.env` en herstart de service. De melding toont geen volledige configuratiedump.

Het bestaande bestand `/etc/adzaagt/metod-pax/backup-budget.env` en de bestaande systemd-drop-in blijven behouden. De service leest het budget na het basisbestand. Het bedrag van 6 GiB en de reserve van 2 GiB worden dus niet teruggezet naar grotere defaults.

## Controle zonder installatie

Vanuit de uitgepakte release:

```bash
python3 -I -S -B tools/final_preflight.py --verify-checksums
```

Dit controleert bron-/bestandshashes, HTML-opbouw, evidence-binding en syntax. Het herbouwt niet met npm op de live server. De echte assetrebuild en functionele tests horen bij de aparte ontwikkeltestprocedure.

Na installatie, als root:

```bash
python3 -I -S -B /opt/adzaagt/metod-pax-current/tools/probe_http_release.py --origin http://127.0.0.1:8792
systemctl is-active metod-pax.service nginx
journalctl -u metod-pax.service -n 80 --no-pager
```

## Nieuwe grotere server

Werk eerst de oude installatie bij, maak daarna met de actuele exporttool een migratiebundle. De nieuwe migratieversie vereist het externe verwijderlogboek; een oud archief zonder dit logboek wordt niet als volledige actuele migratie behandeld. De clean installer neemt ook het bewaarde backupbudget mee. Offsite-toegangssleutels en encryptiesleutels worden afzonderlijk beheerd.

Maak voldoende tijdelijke schijfruimte vrij voor de snapshot en de versleutelde export. Verwijder de oude server pas nadat op de nieuwe machine code, gegevens, Admin, prijsberekening, DNS/TLS, backups en daadwerkelijk herstel zijn gecontroleerd.

## Productiegoedkeuring

Staging blijft bruikbaar voor acceptatie. Productie vereist een apart root-owned goedkeuringsrecord in `/etc/adzaagt/metod-pax-release-approvals/<manifestSha256>.json`. Het record moet aan deze exacte release gebonden zijn; de installer controleert het met `tools/deployment_safety.py`.

De negen bestaande gates zijn `source_provenance`, `browser`, `vps`, `clean_server`, `iphone`, `security`, `operations_restore`, `cam` en `owner_signoff`. Elke gate krijgt echte bewijsbestanden en een SHA-256; pas na beoordeling mag de verantwoordelijke eigenaar goedkeuren. De lokale tests leveren een deel van het bewijs, geen vervangende handtekening. Productiestart vereist daarnaast actuele catalogus-/prijsgoedkeuring en een recente herstelproef inclusief versleutelde externe restore, toepassing van het actuele verwijderlogboek en applicatieherstart.

De iPhone-acceptatie van FIX49 blijft historisch bewijs voor die versie; herhaal de korte route na deze frontendwijzigingen. Test ook Android Chrome en de externe integraties als die worden ingeschakeld.
