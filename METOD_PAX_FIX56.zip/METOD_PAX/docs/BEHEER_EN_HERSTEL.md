# Beheer, backups en klantgegevens

## Opslag begrenzen

Lokale backups hebben gelijktijdig grenzen voor aantal, leeftijd en totale bytes: standaard 8 automatische en 12 handmatige exemplaren, maximaal 70 respectievelijk 120 dagen. Op jouw kleine server geldt het bestaande budget van 6 GiB met 2 GiB vrije reserve. De bytegrens kan daardoor eerder exemplaren laten opruimen dan de aantallimiet. Tijdelijke backups worden op leeftijd opgeruimd; backups bevatten geen recursieve kopie van de backupmap.

De applicatie controleert ruimte vóór backupwerk en vóór publicatie. Een onbekend bestand, andere software of groei van klantdata kan nog steeds de schijf vullen: een backupbudget is geen schijfquotum voor de hele server. Bewaak totale vrije bytes/inodes en stel een externe waarschuwing in. Controleer ook deploygeschiedenis en systeemlogs. Bewaar voldoende ruimte voor herstel en servermigratie; het absolute minimum is geen aanbevolen normale bezetting.

## Versleutelde externe backup

`tools/offsite_backup.py` gebruikt restic om data vóór transport te versleutelen. Een snapshot bevat de gecontroleerde systeembackup plus het actuele externe verwijderlogboek. Identieke snapshots worden niet opnieuw toegevoegd. Retentie bewaart de laatste twee snapshots en een wekelijkse selectie over acht weken; opruimen gebeurt met restic forget/prune. Opslag bij de provider moet eveneens worden gemonitord: hoeveelheid gewijzigde data beïnvloedt de werkelijke repositorygrootte.

Richt op de doelserver een aparte remote repository in. Kopieer `ops/offsite.env.example` naar `/etc/adzaagt/metod-pax/offsite.env`, vul de echte providerwaarden in en zet rechten op 0600. Het repositorywachtwoord staat in een afzonderlijk 0600-bestand en wordt ook buiten deze VPS bewaard. Gebruik geen wachtwoordargument in de shellgeschiedenis. De voorbeeldwaarden zijn geen werkende accountconfiguratie.

Installeer restic en initialiseer de gekozen repository eenmalig. Daarna kunnen de meegeleverde systemd-unit, timer en path-watcher worden geïnstalleerd. De timer synchroniseert ieder uur; wijzigingen in het privacylogboek vragen tussentijdse synchronisatie aan. De units worden niet automatisch geactiveerd met lege voorbeeldcredentials.

```bash
sudo install -m 0644 ops/metod-pax-offsite.service ops/metod-pax-offsite.timer ops/metod-pax-offsite.path /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now metod-pax-offsite.timer metod-pax-offsite.path
sudo systemctl start metod-pax-offsite.service
sudo journalctl -u metod-pax-offsite.service -n 60 --no-pager
```

Voer deze stappen pas uit nadat de repository met dezelfde private omgeving is geïnitialiseerd. De systemd-unit gebruikt het gebruikelijke live-pad `/opt/adzaagt/metod-pax-current` en `/var/lib/metod-pax`. Pas de unit expliciet aan bij afwijkende installatiepaden. Houd de laatste geslaagde run extern in de gaten; een lokale foutlog alleen waarschuwt niemand buiten de server.

## Herstel en vergeten klanten

Admin → Klantgegevens zoekt exact op e-mailadres. De preview toont de betrokken aanvraag- en jobfamilies. **Klantgegevens downloaden** levert `klantgegevens.json` en `KLANTGEGEVENS.txt` met opgeslagen klantgegevens, aanvragen, berekeningen en historische serverprijzen. Deze projectie bevat geen ruwe jobs, toegangsbestanden, serverpaden, optimizercommando's of interne logs.

De afzonderlijk ingeklapte **Interne beheerexport** bevat de volledige betrokken bestanden voor beheer. Daarvoor moet de waarschuwing expliciet worden bevestigd. De naam `INTERN-niet-doorsturen.zip` en een waarschuwing binnen het archief maken het doel zichtbaar. Deel deze interne export niet als klantoverzicht. Verwijderen vereist de actuele previewrevisie en de getypte bevestiging `VERWIJDEREN`. Gerelateerde archief-/jobbestanden worden meegenomen; een familie met tegenstrijdige klantidentiteiten wordt geweigerd om andermans gegevens te beschermen.

Het externe 0600-verwijderlogboek bevat de benodigde identifiers en paden, geen e-mailadres. Behandel ook die pseudonieme identifiers als vertrouwelijk. Bewaar het logboek buiten de data die je terugzet; anders kan een oude backup een nieuwere verwijdering ongedaan maken.

Een lokale restore met `tools/restore_system_backup.py` vereist `--privacy-ledger` met het actuele logboek, behalve bij een expliciete geïsoleerde inspectie. Zo'n inspectiekopie krijgt een blokkademarkering; de applicatie mag daarvan niet zomaar starten. Een restic-restore combineert de gekozen databackup met het nieuwste beschikbare verwijderlogboek en past de verwijderingen vóór publicatie toe. De tests dekken ook de combinatie van een oude actieve aanvraag en een nieuwer verwijderlogboek uit het archief.

Externe synchronisatie is niet atomisch met een verwijderklik. Als de VPS verloren gaat vóór de nieuwe journalversie extern staat, ontbreekt daar recent verwijderbewijs. Daarom moet de beheerder een geslaagde synchronisatie bevestigen en bij een incident het nieuwste beschikbare logboek vaststellen vóór herstel. Gebruik periodieke herstelproeven op een **andere** server, met het echte repositorywachtwoord en applicatieherstart. Verwijdering in backups volgt deze replay en daarna de bewaartermijn; er wordt geen onmiddellijke fysieke verwijdering uit ieder oud archief geclaimd.

## Onbeheerde server

Een unmanaged server is mogelijk als het beheer daadwerkelijk is belegd. Automatiseer beveiligingsupdates, serviceherstart, logrotatie, backupretentie en monitoring. Plan updates met een herstartvenster, controleer TLS-vernieuwing, houd afhankelijkheden bij en voer herstelproeven uit. Een grotere schijf vervangt deze taken niet.

Live state en lokale ZIP-backups zijn binnen de applicatie niet per veld versleuteld. Richt voor productie een versleuteld state-volume of aantoonbare provider-encryptie in en beoordeel sleutelbeheer en snapshots. Dat kan dit codepakket niet voor de bestaande VPS bewijzen. Restic versleutelt de externe kopie wel. Dit onderscheid blijft expliciet onderdeel van de security- en operationsacceptatie.

Privacyverklaring, bewaartermijnen en eventuele wettelijke bewaarplichten moeten aansluiten op het werkelijke bedrijfsproces. De software biedt uitvoering en bewijs; de eigenaar blijft verantwoordelijk voor de vastgestelde termijnen en rechten op bronmateriaal.

## Admin-netwerkgrens en langzame clients

`ADMIN_ALLOWED_NETWORKS` accepteert maximaal 128 komma-gescheiden IP-adressen/CIDR-ranges. De parser telt het bereik van samengevoegde netwerken: standaard maximaal 65.536 IPv4-adressen en een IPv6-/48. Een geheel IPv4- of IPv6-internetbereik wordt altijd geweigerd, ook opgesplitst in meerdere ranges. Een groter maar niet onbeperkt bedrijfsnetwerk vereist de expliciete instelling `ADMIN_BROAD_NETWORKS_ACKNOWLEDGED=I_ACCEPT_BROAD_ADMIN_ACCESS`; gebruik normaal je eigen vaste beheer-IP (/32 voor IPv4 of /128 voor IPv6), VPN of kleine bedrijfsrange.

Productie weigert zonder geldige allowlist te starten. Bij preview/development blijft een niet-ingestelde allowlist bestaand gedrag; ingevulde ongeldige ranges worden geweigerd. Stel voor de extern bereikbare stagingomgeving de echte beheer-IP/VPN-ranges in. Het pakket vult geen verondersteld IP-adres in en levert dus geen bewijs dat jouw actuele staging-allowlist is ingesteld.

De backend moet achter de meegeleverde nginxconfiguratie op loopback blijven. nginx heeft requestbuffering en header-/bodytimeouts; Waitress sluit inactieve verbindingen binnen de ingestelde timeout/cleanupcyclus. De lokale proef omvat 140 onvolledige proxyverbindingen en een gelijktijdige healthcheck. Dit is geen garantie tegen onbeperkte volumetrische aanvallen of onbeperkte toegang door lokale processen; providerbescherming en extern toezicht blijven nodig.
