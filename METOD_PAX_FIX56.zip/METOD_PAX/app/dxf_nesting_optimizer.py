"""CLI entrypoint and stable imports for the production optimizer."""

from metod_app.optimizer.common import (
    safe_slug as safe_slug,
    now_iso as now_iso,
    ensure_dir as ensure_dir,
    round01 as round01,
    fatal as fatal,
    warn as warn,
)
from metod_app.optimizer.models import (
    PanelRow as PanelRow,
    Instance as Instance,
    Placement as Placement,
    PartData as PartData,
    _FreeRect as _FreeRect,
    _PlaceChoice as _PlaceChoice,
)
from metod_app.optimizer.profiling import (
    OptimizerProfiler as OptimizerProfiler,
    _profiler as _profiler,
)
from metod_app.optimizer.geometry import (
    read_panels_csv as read_panels_csv,
    dxf_pairs as dxf_pairs,
    pairs_to_dxf as pairs_to_dxf,
    _extract_entities_pairs as _extract_entities_pairs,
    _float as _float,
    compute_bbox_from_pairs as compute_bbox_from_pairs,
    shift_pairs_xy as shift_pairs_xy,
    set_layer_for_pairs as set_layer_for_pairs,
    rotate_translate_pairs as rotate_translate_pairs,
    load_part as load_part,
    validate_part_bbox as validate_part_bbox,
    compose_sheet_dxf as compose_sheet_dxf,
    validate_final_placements as validate_final_placements,
    resolve_dxf_part_sources as resolve_dxf_part_sources,
)
from metod_app.optimizer.heuristics import (
    _sort_key_variant as _sort_key_variant,
    _item_sort_key as _item_sort_key,
    _rect_contains as _rect_contains,
    _split_free_rect as _split_free_rect,
    _prune_free_rects as _prune_free_rects,
    _band_clustering_penalty as _band_clustering_penalty,
    _edge_cleanup_penalty as _edge_cleanup_penalty,
    _internal_void_compaction_penalty as _internal_void_compaction_penalty,
    _item_orientation_options as _item_orientation_options,
    _pair_can_share_sheet as _pair_can_share_sheet,
    _greedy_incompatibility_clique_bound as _greedy_incompatibility_clique_bound,
    _best_choice_for_item as _best_choice_for_item,
    _packing_equivalence_key as _packing_equivalence_key,
    _homogeneous_grid_candidate as _homogeneous_grid_candidate,
)
from metod_app.optimizer.packing import (
    _maxrects_pack_k as _maxrects_pack_k,
    _placement_bbox_usable as _placement_bbox_usable,
    _rebuild_free_rects_for_sheet as _rebuild_free_rects_for_sheet,
    _postpass_repack_micro_fillers as _postpass_repack_micro_fillers,
    pack_maxrects_optimal as pack_maxrects_optimal,
)
from metod_app.optimizer.quote import (
    build_quote as build_quote,
)
from metod_app.optimizer.progress import (
    _atomic_progress_write_json as _atomic_progress_write_json,
    _write_progress_snapshot as _write_progress_snapshot,
    _optimizer_material_work_units as _optimizer_material_work_units,
    _map_material_progress as _map_material_progress,
    write_progress_report as write_progress_report,
)
from metod_app.optimizer.cli import (
    apply_optimizer_memory_limit as apply_optimizer_memory_limit,
    main as main,
)

if __name__ == "__main__":
    raise SystemExit(main())
