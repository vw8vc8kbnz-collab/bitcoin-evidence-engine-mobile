"""Bounded ObservabilityRuntime implementation with explicit ports injection."""

from __future__ import annotations

from metod_app.identifiers import safe_identifier as _safe_id
from metod_app.security.redaction import safe_text as _safe_text
from safety_contracts import strict_json_load
from metod_app.runtime.ports import ObservabilityRuntimePorts


from metod_app.observability.failures import report_recovery


class ObservabilityRuntime:
    def __init__(self, ports: ObservabilityRuntimePorts):
        self._ports = ports

    def _guess_customer_name_from_payload(_owner, payload: dict | None) -> str:
        if not isinstance(payload, dict):
            return ""
        for key in ("customer", "client", "contact"):
            obj = payload.get(key)
            if isinstance(obj, dict):
                for nk in ("name", "fullName", "company", "companyName"):
                    val = _safe_text(obj.get(nk), 120)
                    if val:
                        return val
        for nk in ("customerName", "name", "companyName", "company"):
            val = _safe_text(payload.get(nk), 120)
            if val:
                return val
        return ""

    def _guess_customer_name(
        _owner, request_id: str = "", payload: dict | None = None, status: dict | None = None
    ) -> str:
        ports = _owner._ports
        REQUESTS = ports.get_requests()
        _guess_customer_name_from_payload = ports.guess_customer_name_from_payload

        name = _guess_customer_name_from_payload(payload)
        if name:
            return name
        if isinstance(status, dict):
            for key in ("customerName", "customer", "clientName", "name"):
                val = status.get(key)
                if isinstance(val, dict):
                    val = val.get("name") or val.get("company")
                val = _safe_text(val, 120)
                if val:
                    return val
        rid = _safe_id(request_id or "", 120)
        if rid:
            try:
                fp = REQUESTS / rid / "input" / "submit_payload.json"
                if fp.exists():
                    pl = strict_json_load(fp)
                    return _guess_customer_name_from_payload(pl)
            except Exception as recovery_error:
                report_recovery("metod_app.observability.ports._guess_customer_name.163", recovery_error)
        return ""

    def _append_system_event(
        _owner,
        *,
        level: str = "error",
        component: str = "system",
        message_user: str,
        message_tech: str = "",
        request_id: str = "",
        job_id: str = "",
        customer_name: str = "",
        status: str = "open",
        details: dict | None = None,
    ) -> None:
        ports = _owner._ports
        _OBSERVABILITY = ports.get_observability()

        return _OBSERVABILITY.append_system_event(
            level=level,
            component=component,
            message_user=message_user,
            message_tech=message_tech,
            request_id=request_id,
            job_id=job_id,
            customer_name=customer_name,
            status=status,
            details=details,
        )

    def _read_system_events(_owner, limit: int = 200) -> list[dict]:
        ports = _owner._ports
        _OBSERVABILITY = ports.get_observability()

        return _OBSERVABILITY.read_system_events(limit)

    def _observability_public_job_snapshot(_owner) -> dict[str, int]:
        ports = _owner._ports
        _PUBLIC_JOB_ACTIVE_TOTAL = ports.get_public_job_active_total()
        _PUBLIC_JOB_CREATE_LOCK = ports.get_public_job_create_lock()
        _PUBLIC_JOB_CREATE_TOTAL = ports.get_public_job_create_total()
        _PUBLIC_JOB_QUEUE = ports.get_public_job_queue()
        _PUBLIC_JOB_RESERVED_TOTAL = ports.get_public_job_reserved_total()

        with _PUBLIC_JOB_CREATE_LOCK:
            return {
                "admitted": _PUBLIC_JOB_CREATE_TOTAL,
                "active": _PUBLIC_JOB_ACTIVE_TOTAL,
                "waiting": len(_PUBLIC_JOB_QUEUE),
                "reserved": _PUBLIC_JOB_RESERVED_TOTAL,
            }

    EXPORTS = (
        "_guess_customer_name_from_payload",
        "_guess_customer_name",
        "_append_system_event",
        "_read_system_events",
        "_observability_public_job_snapshot",
    )


__all__ = ("ObservabilityRuntime",)
