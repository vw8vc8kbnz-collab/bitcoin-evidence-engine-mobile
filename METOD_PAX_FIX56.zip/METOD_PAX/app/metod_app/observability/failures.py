"""Bounded fallback diagnostics without exception messages or customer data.

Callers choose a specific fallback or propagate their failure. This owner only
records that an explicitly recoverable operation failed; it never retries,
changes business state, or reports an operation as successful.
"""

from __future__ import annotations

import logging
import re
import threading
import time
from pathlib import Path
import traceback
from collections import OrderedDict

_LOGGER = logging.getLogger("metod.recovery")
_LOCK = threading.Lock()
_RECENT: OrderedDict[tuple[str, str], float] = OrderedDict()
_LIMIT = 256
_INTERVAL_SECONDS = 300


def report_recovery(operation: str, error: BaseException) -> None:
    """Log bounded code locations only: no exception text, source lines or locals."""
    if not re.fullmatch(r"[A-Za-z0-9_.:-]{1,160}", operation):
        raise ValueError("Invalid recovery operation code")
    error_class = type(error).__name__
    if not re.fullmatch(r"[A-Za-z0-9_]{1,80}", error_class):
        error_class = "Exception"
    key = (operation, error_class)
    now = time.monotonic()
    with _LOCK:
        previous = _RECENT.get(key)
        if previous is not None and now - previous < _INTERVAL_SECONDS:
            return
        _RECENT[key] = now
        _RECENT.move_to_end(key)
        while len(_RECENT) > _LIMIT:
            _RECENT.popitem(last=False)
    frames = traceback.extract_tb(error.__traceback__)[-8:]
    locations = " > ".join(f"{Path(frame.filename).name}:{frame.name}:{frame.lineno}" for frame in frames)
    _LOGGER.warning(
        "recoverable_failure operation=%s class=%s locations=%s", operation, error_class, locations
    )


__all__ = ("report_recovery",)
