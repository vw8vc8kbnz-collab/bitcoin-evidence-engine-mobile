"""Compose the concrete HTTP handler from bounded behavior owners."""

from __future__ import annotations


from .wsgi import WsgiHandler
from .admin_operations_runtime import AdminOperationsRuntimeMixin
from .catalog_import_runtime import CatalogImportRuntimeMixin
from .material_catalog_runtime import MaterialCatalogRuntimeMixin
from .public_api_runtime import PublicApiRuntimeMixin
from .transport_runtime import TransportRuntimeMixin


def build_handler(
    *,
    public_catalog,
    catalog_import,
    transport,
    public_api,
    admin_operations,
    filter_groups,
    material_dxf,
    material_catalog,
    catalog,
):
    class Handler(
        TransportRuntimeMixin,
        MaterialCatalogRuntimeMixin,
        CatalogImportRuntimeMixin,
        AdminOperationsRuntimeMixin,
        PublicApiRuntimeMixin,
        WsgiHandler,
    ):
        _public_catalog_ports = public_catalog
        _catalog_import_ports = catalog_import
        _transport_ports = transport
        _public_api_ports = public_api
        _admin_operations_ports = admin_operations
        _filter_groups_ports = filter_groups
        _material_dxf_ports = material_dxf
        _material_catalog_ports = material_catalog
        _catalog_publication = catalog

    Handler.__name__ = "Handler"
    Handler.__qualname__ = "Handler"
    return Handler
