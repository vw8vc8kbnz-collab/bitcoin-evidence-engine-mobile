"""Focused AdminOperationsRuntimeMixin owner; dependencies resolve through the composition ports."""

from __future__ import annotations

from metod_app.observability.failures import report_recovery

from safety_contracts import ContractError as SafetyContractError
from metod_app.config import env_int as _env_int
from dxf_geometry import entities_bbox as _strict_dxf_entities_bbox
from dxf_geometry import entities_section as _strict_dxf_entities_section
from dxf_geometry import entity_bbox as _strict_dxf_entity_bbox
from dxf_geometry import entity_layer as _strict_dxf_entity_layer
from dxf_geometry import entity_type as _strict_dxf_entity_type
from dxf_geometry import parse_pairs as _strict_dxf_parse_pairs
from dxf_geometry import split_entities as _strict_dxf_split_entities
import base64
from safety_contracts import durable_write_bytes
from safety_contracts import fsync_directory
from urllib.parse import parse_qs
from safety_contracts import sha256_file
from metod_app.runtime.ports import HttpAdminOperationsRuntimePorts


class AdminOperationsRuntimeMixin:
    _admin_operations_ports: HttpAdminOperationsRuntimePorts

    def _api_admin_system_logs(self):
        ports = self._admin_operations_ports
        _append_system_event = ports.append_system_event
        _read_system_events = ports.read_system_events

        try:
            items = _read_system_events(limit=200)
            return self._send_json({"ok": True, "items": items, "count": len(items)})
        except Exception as e:
            report_recovery("metod_app.http.admin_operations_runtime.boundary.33", e)
            _append_system_event(
                level="error",
                component="system",
                message_user="Systeemlog laden is mislukt",
                message_tech=str(e),
                status="open",
            )
            return self._send_json({"ok": False, "error": "Systeemlog kon niet worden geladen"}, 500)

    def _api_admin_system_backups(self):
        ports = self._admin_operations_ports
        _append_system_event = ports.append_system_event
        _list_backups = ports.list_backups

        try:
            items = _list_backups(limit=50)
            return self._send_json({"ok": True, "items": items, "count": len(items)})
        except Exception as e:
            report_recovery("metod_app.http.admin_operations_runtime.boundary.45", e)
            _append_system_event(
                level="error",
                component="backup",
                message_user="Backuplijst laden is mislukt",
                message_tech=str(e),
                status="open",
            )
            return self._send_json({"ok": False, "error": "Backuplijst kon niet worden geladen"}, 500)

    def _api_admin_system_backup_download(self, parsed):
        ports = self._admin_operations_ports
        BACKUPS_DIR = ports.get_backups_dir()
        _append_system_event = ports.append_system_event

        try:
            qs = parse_qs(parsed.query)
            name = str((qs.get("name") or [""])[0]).strip()
            if not name or "/" in name or "\\" in name or ".." in name:
                return self._send_text("Not found", 404)
            fpath = BACKUPS_DIR / name
            if not fpath.exists() or not fpath.is_file() or fpath.suffix.lower() != ".zip":
                return self._send_text("Not found", 404)
            return self._stream_file(
                fpath,
                content_type="application/zip",
                download_name=fpath.name,
                max_bytes=max(1, _env_int("ADMIN_BACKUP_DOWNLOAD_MAX_BYTES", 4 * 1024 * 1024 * 1024)),
            )
        except Exception as e:
            report_recovery("metod_app.http.admin_operations_runtime.boundary.68", e)
            _append_system_event(
                level="error",
                component="backup",
                message_user="Backup downloaden is mislukt",
                message_tech=str(e),
                status="open",
            )
            return self._send_json({"ok": False, "error": "Backup downloaden is mislukt"}, 500)

    def _api_admin_system_backup_now(self):
        ports = self._admin_operations_ports
        _append_system_event = ports.append_system_event
        _create_system_backup = ports.create_system_backup

        try:
            actor = self._current_admin_actor() or "unknown-admin"
            res = _create_system_backup(actor=actor)
            return self._send_json(res, 200)
        except Exception as e:
            report_recovery("metod_app.http.admin_operations_runtime.boundary.81", e)
            _append_system_event(
                level="error",
                component="backup",
                message_user="Backup maken is mislukt",
                message_tech=str(e),
                status="open",
            )
            return self._send_json({"ok": False, "error": "Backup maken is mislukt"}, 500)

    def _api_admin_dxf_categories(self):
        return self._send_json({"ok": True, "categories": self._list_dxf_categories()})

    def _api_admin_dxf_list(self, parsed):
        qs = parse_qs(parsed.query)
        cat = self._sanitize_category((qs.get("category") or [""])[0])
        if not cat:
            return self._send_json({"ok": False, "error": "Invalid category"}, 400)
        self._dxf_category_folder(cat)
        files = self._list_dxf_files_in_category(cat)
        if files is None:
            return self._send_json({"ok": False, "error": "Category not found"}, 404)
        return self._send_json(
            {
                "ok": True,
                "category": cat,
                "files": files,
                "count": len(files),
            }
        )

    def _api_admin_dxf_create_category(self):
        ports = self._admin_operations_ports
        _append_system_event = ports.append_system_event
        _read_json_body_limited = ports.read_json_body_limited

        rebuild_embedded_dxfs_manifest = ports.rebuild_embedded_dxfs_manifest

        data = _read_json_body_limited(self, "ADMIN_JSON_MAX_BYTES", 262144) or {}
        if not isinstance(data, dict):
            return self._send_json(
                {
                    "ok": False,
                    "code": "DXF_INVALID_PAYLOAD",
                    "error": "Verwacht een JSON-object met een categorienaam.",
                },
                400,
            )
        cat = self._sanitize_category(data.get("category", ""))
        if not cat or cat == "(root)":
            return self._send_json({"ok": False, "error": "Invalid category"}, 400)
        folder = self._dxf_category_folder(cat)
        folder.mkdir(parents=True, exist_ok=True)
        fsync_directory(folder.parent)
        rebuild_embedded_dxfs_manifest()
        _append_system_event(
            level="info",
            component="dxf_library",
            message_user="DXF-categorie aangemaakt",
            message_tech=f"category={cat}",
            status="resolved",
            details={"actor": self._current_admin_actor() or "unknown-admin", "category": cat},
        )
        return self._send_json({"ok": True, "category": cat})

    def _api_admin_dxf_upload(self):
        ports = self._admin_operations_ports

        _append_system_event = ports.append_system_event
        _read_json_body_limited = ports.read_json_body_limited

        rebuild_embedded_dxfs_manifest = ports.rebuild_embedded_dxfs_manifest

        data = _read_json_body_limited(self, "ADMIN_DXF_UPLOAD_MAX_BYTES", 15728640) or {}
        if not isinstance(data, dict):
            return self._send_json(
                {
                    "ok": False,
                    "code": "DXF_INVALID_PAYLOAD",
                    "error": "Verwacht een JSON-object met categorie, bestandsnaam en DXF-inhoud.",
                },
                400,
            )
        cat = self._sanitize_category(data.get("category", ""))
        filename = self._sanitize_filename(data.get("filename", ""))
        b64data = data.get("dataBase64", "")
        if not cat:
            return self._send_json(
                {
                    "ok": False,
                    "code": "DXF_INVALID_CATEGORY",
                    "error": "Ongeldige categorie. Gebruik maximaal 60 letters, cijfers, spaties, streepjes of underscores.",
                },
                400,
            )
        if not filename:
            return self._send_json(
                {
                    "ok": False,
                    "code": "DXF_INVALID_FILENAME",
                    "error": "Ongeldige bestandsnaam. Gebruik maximaal 80 letters, cijfers, spaties of # _ ( ) , . - gevolgd door .dxf. Mappaden, een punt aan het begin en twee opeenvolgende punten zijn niet toegestaan.",
                },
                400,
            )
        if not isinstance(b64data, str) or not b64data:
            return self._send_json(
                {
                    "ok": False,
                    "code": "DXF_MISSING_CONTENT",
                    "error": "Het DXF-bestand bevat geen uploadgegevens.",
                },
                400,
            )

        folder = self._dxf_category_folder(cat)
        if not folder.exists() or not folder.is_dir():
            return self._send_json({"ok": False, "error": "Category not found"}, 404)

        try:
            raw = base64.b64decode(b64data, validate=True)
        except Exception as recovery_error:
            report_recovery("metod_app.http.admin_operations_runtime.boundary.154", recovery_error)
            return self._send_json({"ok": False, "error": "Invalid base64"}, 400)

        if len(raw) > 10 * 1024 * 1024:
            return self._send_json({"ok": False, "error": "File too large"}, 400)

        try:
            text = raw.decode("utf-8", errors="strict")
            pairs = _strict_dxf_parse_pairs(text)
            if len(pairs) > 500_000 or not any(
                code == 0 and str(value).strip().upper() == "EOF" for code, value in pairs[-4:]
            ):
                raise SafetyContractError("DXF is incomplete or exceeds the entity budget")
            entities = _strict_dxf_split_entities(_strict_dxf_entities_section(pairs))
            if not entities or len(entities) > 50_000:
                raise SafetyContractError("DXF entity count is outside the allowed range")
            for entity in entities:
                kind = _strict_dxf_entity_type(entity)
                if kind not in {"LINE", "CIRCLE", "ARC", "LWPOLYLINE"}:
                    raise SafetyContractError(f"Unsupported production DXF entity: {kind}")
                if kind == "LWPOLYLINE" and _strict_dxf_entity_layer(entity).upper() != "OUTLINE":
                    raise SafetyContractError("Only OUTLINE LWPOLYLINE entities are accepted")
                _strict_dxf_entity_bbox(entity)
            bbox = _strict_dxf_entities_bbox(entities)
            if bbox.width > 10_000 or bbox.height > 10_000:
                raise SafetyContractError("DXF bbox exceeds 10,000 mm")
        except Exception as error:
            report_recovery("metod_app.http.admin_operations_runtime.boundary.178", error)
            return self._send_json(
                {"ok": False, "code": "DXF_INVALID_GEOMETRY", "error": "DXF afgewezen: " + str(error)[:240]},
                400,
            )

        target = folder / filename
        replaced = target.is_file()
        durable_write_bytes(target, raw, mode=0o640)

        rebuild_embedded_dxfs_manifest()
        _append_system_event(
            level="info",
            component="dxf_library",
            message_user="DXF geüpload",
            message_tech=f"category={cat}; filename={filename}; bytes={len(raw)}",
            status="resolved",
            details={
                "actor": self._current_admin_actor() or "unknown-admin",
                "category": cat,
                "filename": filename,
                "sha256": sha256_file(target),
            },
        )
        return self._send_json(
            {
                "ok": True,
                "category": cat,
                "filename": filename,
                "replaced": replaced,
                "dxfVersion": ports.get_embedded_dxfs_version(),
            }
        )

    def _api_admin_dxf_delete(self):
        ports = self._admin_operations_ports
        _append_system_event = ports.append_system_event
        _read_json_body_limited = ports.read_json_body_limited

        rebuild_embedded_dxfs_manifest = ports.rebuild_embedded_dxfs_manifest

        data = _read_json_body_limited(self, "ADMIN_JSON_MAX_BYTES", 262144) or {}
        if not isinstance(data, dict):
            return self._send_json(
                {
                    "ok": False,
                    "code": "DXF_INVALID_PAYLOAD",
                    "error": "Verwacht een JSON-object met categorie en bestandsnaam.",
                },
                400,
            )
        cat = self._sanitize_category(data.get("category", ""))
        filename = self._sanitize_filename(data.get("filename", ""))
        if not cat or not filename:
            return self._send_json({"ok": False, "error": "Invalid payload"}, 400)
        folder = self._dxf_category_folder(cat)
        target = folder / filename
        if not target.exists() or not target.is_file():
            return self._send_json({"ok": False, "error": "File not found"}, 404)
        try:
            deleted_hash = sha256_file(target)
            target.unlink()
            fsync_directory(folder)
        except Exception as recovery_error:
            report_recovery("metod_app.http.admin_operations_runtime.boundary.212", recovery_error)
            return self._send_json({"ok": False, "error": "Delete failed"}, 500)
        rebuild_embedded_dxfs_manifest()
        _append_system_event(
            level="info",
            component="dxf_library",
            message_user="DXF verwijderd",
            message_tech=f"category={cat}; filename={filename}",
            status="resolved",
            details={
                "actor": self._current_admin_actor() or "unknown-admin",
                "category": cat,
                "filename": filename,
                "deletedSha256": deleted_hash,
            },
        )
        return self._send_json({"ok": True})
