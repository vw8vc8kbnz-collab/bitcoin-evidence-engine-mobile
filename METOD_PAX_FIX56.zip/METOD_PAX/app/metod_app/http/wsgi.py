"""WSGI transport for existing endpoint adapters, served by bounded Waitress workers.

HTTP parsing, connection timeouts, input spooling and output backpressure belong
exclusively to Waitress. This adapter owns no sockets or request threads.
"""

from dataclasses import dataclass
from email.message import Message
from email.utils import formatdate
from http import HTTPStatus
import ipaddress
import logging
import mimetypes
from pathlib import Path
import sys
from urllib.parse import quote

from metod_app.config import env_int
from metod_app.observability.failures import report_recovery

_DEPENDENCY = Path(__file__).resolve().parents[3] / "dependencies" / "waitress-3.0.2-py3-none-any.whl"
# A pinned, reviewed pure-Python wheel permits offline deployment without pip.
# The distribution manifest verifies the wheel alongside our own source.
if not _DEPENDENCY.is_file():
    raise RuntimeError("Pinned Waitress dependency is missing")
sys.path.insert(0, str(_DEPENDENCY))
from waitress import create_server


@dataclass
class ServerInfo:
    server_port: int


class ResponseWriter:
    def __init__(self, handler):
        self.handler = handler

    def write(self, data: bytes):
        handler = self.handler
        if handler._write is None:
            raise RuntimeError("Response body precedes response headers")
        if handler.command != "HEAD":
            handler._write(data)
        return len(data)

    def flush(self):
        """Waitress streams with bounded backpressure on each write."""


class WsgiHandler:
    """Minimal request/response interface, with no HTTP parser inheritance."""

    def __init__(self, environ, start_response, server):
        self.server = server
        self._start_response = start_response
        self._write = None
        self._headers_buffer = []
        self._status = 200
        self.command = environ["REQUEST_METHOD"].upper()
        # WSGI PATH_INFO is decoded latin-1; restore bytes before URL quoting.
        path = quote(environ.get("PATH_INFO", "/").encode("latin-1"), safe="/")
        self.path = path + ("?" + environ["QUERY_STRING"] if environ.get("QUERY_STRING") else "")
        self.headers = Message()
        for key, value in environ.items():
            if key.startswith("HTTP_"):
                self.headers[key[5:].replace("_", "-")] = value
        for key in ("CONTENT_TYPE", "CONTENT_LENGTH"):
            if environ.get(key):
                self.headers[key.replace("_", "-")] = environ[key]
        self.rfile = environ["wsgi.input"]
        self.wfile = ResponseWriter(self)
        self.client_address = (environ.get("REMOTE_ADDR", ""), int(environ.get("REMOTE_PORT") or 0))

    def send_response(self, code, message=None):
        if self._write is not None:
            raise RuntimeError("Response headers already sent")
        self._status = int(code)
        self._headers_buffer = []

    def send_header(self, name, value):
        name, value = str(name), str(value)
        if "\r" in name + value or "\n" in name + value:
            raise ValueError("Invalid response header")
        if name.lower() in {"connection", "transfer-encoding", "keep-alive"}:
            return  # Connection lifecycle is owned by the WSGI server.
        self._headers_buffer.append((name + ": " + value + "\r\n").encode("latin-1"))

    def end_headers(self):
        headers = []
        for line in self._headers_buffer:
            key, value = line.decode("latin-1").split(":", 1)
            headers.append((key, value.strip()))
        self._write = self._start_response(f"{self._status} {HTTPStatus(self._status).phrase}", headers)

    def guess_type(self, path):
        return mimetypes.guess_type(path)[0] or "application/octet-stream"

    def do_HEAD(self):
        # Same nonce injection and length as GET; the writer suppresses the body.
        return self.do_GET()

    def do_GET(self):
        path = Path(self.translate_path(self.path))
        try:
            source = path.open("rb")
        except (FileNotFoundError, IsADirectoryError, PermissionError):
            return self._send_text("Not found", 404)
        with source:
            size = path.stat().st_size
            self.send_response(200)
            self.send_header("Content-Type", self.guess_type(str(path)))
            self.send_header("Content-Length", str(size))
            self.send_header("Last-Modified", formatdate(path.stat().st_mtime, usegmt=True))
            self.end_headers()
            if self.command != "HEAD":
                while chunk := source.read(1024 * 1024):
                    self.wfile.write(chunk)


def build_wsgi_application(handler_class, *, port):
    server = ServerInfo(port)

    def application(environ, start_response):
        handler = handler_class(environ, start_response, server)
        try:
            method = getattr(handler, "do_" + handler.command, None)
            if method is None:
                handler._send_text("Method not allowed", 405)
            else:
                method()
        except (ConnectionError, BrokenPipeError):
            return []  # Disconnected client: Waitress owns request cleanup.
        except Exception as error:
            report_recovery("http.unexpected_request_failure", error)
            if handler._write is not None:
                raise
            handler._send_json(
                {"ok": False, "error": "Verzoek kon niet worden afgerond. Probeer opnieuw."}, 500
            )
        return []

    return application


class ApplicationServer:
    """Bind before recovery; serve only after startup checks finish."""

    def __init__(self, address, handler_class):
        host, port = address
        if not ipaddress.ip_address(host).is_loopback:
            raise ValueError("METOD backend must bind to loopback behind the reverse proxy")
        self._server = create_server(
            build_wsgi_application(handler_class, port=port),
            host=host,
            port=port,
            threads=max(4, min(64, env_int("HTTP_WORKERS", 16))),
            connection_limit=max(32, min(512, env_int("HTTP_MAX_CONNECTIONS", 128))),
            channel_timeout=10,
            cleanup_interval=1,
            ident="METOD",
            max_request_body_size=64 * 1024 * 1024,
            max_request_header_size=32768,
            inbuf_overflow=1024 * 1024,
            outbuf_overflow=1024 * 1024,
            outbuf_high_watermark=4 * 1024 * 1024,
            # Application validates forwarding headers against its own trusted peers.
            clear_untrusted_proxy_headers=False,
        )

    def serve_forever(self):
        logging.getLogger("metod.http").info("WSGI listener ready")
        self._server.run()

    def server_close(self):
        self._server.close()
        self._server.task_dispatcher.shutdown(timeout=5)
