"""Focused MaterialCatalogRuntimeMixin owner; dependencies resolve through the composition ports."""

from __future__ import annotations

from metod_app.observability.failures import report_recovery
from metod_app.errors import PublicJobInputError

from typing import Any
from catalog_importer import ALLOWED_THICKNESSES_MM as CATALOG_ALLOWED_THICKNESSES_MM
from catalog_importer import VAT_RATE as CATALOG_VAT_RATE
from pathlib import Path
from safety_contracts import ContractError as SafetyContractError
from metod_app.contracts.submission import EMAIL_RE as _EMAIL_RE
from panel_contract import canonical_csv as _canonical_panels_csv
from catalog_importer import classify_catalog_presentation as _catalog_classify_presentation
from catalog_importer import read_cached_image as _catalog_read_cached_image
from metod_app.contracts.submission import clean_text as _clean_text
from metod_app.config import env_int as _env_int
from panel_contract import parse_panels_csv as _parse_panels_csv_contract
from metod_app.contracts.submission import sanitize_house_number_text as _sanitize_house_number_text
from metod_app.contracts.submission import sanitize_phone_text as _sanitize_phone_text
from metod_app.contracts.submission import sanitize_postcode_text as _sanitize_postcode_text
from metod_app.contracts.submission import sanitize_user_text as _sanitize_user_text
from dxf_geometry import parse_pairs as _strict_dxf_parse_pairs
import csv
from safety_contracts import durable_write_json
from safety_contracts import finite_number
import hashlib
import io
import os
from urllib.parse import quote
from dataclasses import replace
import secrets
from safety_contracts import strict_json_dumps
from safety_contracts import strict_json_load
from safety_contracts import validate_public_material_id
from metod_app.runtime.ports import HttpMaterialCatalogRuntimePorts

from metod_app.storage.catalog_publication import catalog_guarded, catalog_guard

from metod_app.contracts.production_geometry import validate_panel_intent, validated_panel_geometry


from .material_dxf_runtime import MaterialDxfRuntimeMixin
from .filter_groups_runtime import FilterGroupsRuntimeMixin
from .public_catalog_runtime import PublicCatalogRuntimeMixin
from metod_app.catalog.reviewed_media import resolve_reviewed_swatch
from metod_app.catalog.public_identity import (
    INTERNAL_MATERIAL_KEYS,
    PUBLIC_MATERIAL_ID_RE,
    internal_material_codes,
    public_material_name,
)


class MaterialCatalogRuntimeMixin(
    FilterGroupsRuntimeMixin, PublicCatalogRuntimeMixin, MaterialDxfRuntimeMixin
):
    _material_catalog_ports: HttpMaterialCatalogRuntimePorts

    def _new_public_material_id(self, used: set[str] | None = None) -> str:
        used = used if isinstance(used, set) else set()
        for _ in range(100):
            value = "decor_" + secrets.token_hex(10)
            if value not in used:
                used.add(value)
                return value
        raise RuntimeError("Kon geen unieke publieke decor-ID genereren")

    def _infer_material_brand(self, rec: dict) -> str:
        existing = str((rec or {}).get("brand") or "").strip()
        if existing:
            return existing[:80]
        hay = " ".join(
            str((rec or {}).get(k) or "") for k in ("productName", "categoryName", "shortDescription")
        ).upper()
        for brand in (
            "EGGER",
            "PFLEIDERER",
            "UNILIN",
            "DECORLEGNO",
            "DECOLEGNO",
            "SHINNOKI",
            "CLEAF",
            "FINSA",
            "KRONOSPAN",
            "ARPA",
            "FENIX",
            "NUXE",
            "TOPFIX",
        ):
            if brand in hay:
                return brand if brand in ("EGGER", "ARPA", "FENIX") else brand.title()
        return "Overig"

    def _material_presentation(self, rec: dict) -> dict:
        rec = rec or {}
        return _catalog_classify_presentation(
            str(rec.get("productName") or rec.get("publicName") or rec.get("decorName") or ""),
            str(rec.get("brand") or self._infer_material_brand(rec) or ""),
            str(rec.get("categoryName") or ""),
            rec.get("imageSourceUrls") or [],
        )

    def _infer_material_decor_type(self, rec: dict) -> str:
        presentation = self._material_presentation(rec)
        return str(presentation.get("visualFamily") or "Overig")[:60]

    def _public_material_name(self, rec: dict) -> str:
        return public_material_name(rec or {})

    def _ensure_material_public_metadata(self, raw: dict, recs: list[dict]) -> bool:
        ports = self._material_catalog_ports
        _PUBLIC_MATERIAL_ID_RE = ports.get_public_material_id_re()

        changed = False
        used: set[str] = set()
        for r in recs:
            if not isinstance(r, dict):
                continue
            pid = str(r.get("publicMaterialId") or "").strip().lower()
            if _PUBLIC_MATERIAL_ID_RE.fullmatch(pid) and pid not in used:
                used.add(pid)
            else:
                r["publicMaterialId"] = self._new_public_material_id(used)
                changed = True
        for r in recs:
            if not isinstance(r, dict):
                continue
            # CSV publication already persists presentation fields. Do not run the
            # classifier four/five times again on every public library request. Only infer
            # presentation once when an older record genuinely misses one of these fields.
            brand = str(r.get("brand") or "").strip() or self._infer_material_brand(r)
            presentation_keys_ok = (
                bool(str(r.get("visualFamily") or r.get("decorType") or "").strip())
                and isinstance(r.get("visualTags"), list)
                and bool(str(r.get("colorGroup") or "").strip())
                and isinstance(r.get("searchTags"), list)
            )
            presentation = (
                None if presentation_keys_ok else self._material_presentation({**r, "brand": brand})
            )
            family = (
                str(
                    r.get("visualFamily")
                    or r.get("decorType")
                    or (presentation or {}).get("visualFamily")
                    or "Overig"
                ).strip()
                or "Overig"
            )
            defaults = {
                "publicName": self._public_material_name(r),
                "brand": brand,
                "decorType": family,
                "visualFamily": family,
                "visualTags": list(r.get("visualTags") or (presentation or {}).get("visualTags") or [family]),
                "colorGroup": str(
                    r.get("colorGroup") or (presentation or {}).get("colorGroup") or "Overig"
                ).strip()
                or "Overig",
                "searchTags": list(r.get("searchTags") or (presentation or {}).get("searchTags") or []),
                "published": bool(r.get("active", True))
                if r.get("published") is None
                else bool(r.get("published")),
                "isPopular": bool(r.get("isPopular", False)),
                "isNew": bool(r.get("isNew", False)),
                "hasGrain": True if r.get("hasGrain") is None else bool(r.get("hasGrain")),
                "grainDefaultOn": True if r.get("grainDefaultOn") is None else bool(r.get("grainDefaultOn")),
                "archived": bool(r.get("archived", False)),
                "sourceKind": str(r.get("sourceKind") or "LEGACY_LIBRARY").strip() or "LEGACY_LIBRARY",
                "catalogMissing": bool(r.get("catalogMissing", False)),
            }
            for key, value in defaults.items():
                if key not in r:
                    r[key] = value
                    changed = True
        if raw.get("decorLibrarySchemaVersion") != 4:
            raw["decorLibrarySchemaVersion"] = 4
            changed = True
        return changed

    @catalog_guarded
    def _load_material_library_bundle(self):
        ports = self._material_catalog_ports
        MATERIAL_LIBRARY_PATH = ports.get_material_library_path()
        _MATERIAL_LIBRARY_LOCK = ports.get_material_library_lock()
        _PRICING_CONFIG_LOCK = ports.get_pricing_config_lock()

        # Every logical catalog read that may normalize-and-publish shares the
        # pricing lock and the global lock order used by catalog publication and
        # public job admission. This rules out an unnoticed catalog generation
        # change between pricing capture and signoff verification.
        with _PRICING_CONFIG_LOCK:
            with _MATERIAL_LIBRARY_LOCK:
                target = MATERIAL_LIBRARY_PATH
                if target.exists():
                    raw = strict_json_load(target)
                else:
                    raw = {"source": "admin", "records": []}
                if isinstance(raw, list):
                    raw = {"source": "admin", "records": raw}
                if not isinstance(raw, dict):
                    raise ValueError("Material library must be a JSON object or list")
                recs = raw.get("records")
                if recs is None:
                    recs = []
                    raw["records"] = recs
                if not isinstance(recs, list):
                    raise ValueError("material_library.json must contain a records list")
                changed = self._ensure_material_public_metadata(raw, recs)
                if changed:
                    raw["recordCountOriginal"] = len(recs)
                    raw["recordCountFiltered"] = len(recs)
                    self._save_material_library_bundle(raw)
                return raw, recs

    @catalog_guarded
    def _save_material_library_bundle(self, raw):
        ports = self._material_catalog_ports
        MATERIAL_LIBRARY_PATH = ports.get_material_library_path()
        _MATERIAL_LIBRARY_LOCK = ports.get_material_library_lock()
        _PRICING_CONFIG_LOCK = ports.get_pricing_config_lock()
        _invalidate_material_lookup_cache = ports.invalidate_material_lookup_cache
        _invalidate_public_materials_response_cache = ports.invalidate_public_materials_response_cache

        with _PRICING_CONFIG_LOCK:
            with _MATERIAL_LIBRARY_LOCK:
                target = MATERIAL_LIBRARY_PATH
                durable_write_json(target, raw, mode=0o640)
                _invalidate_public_materials_response_cache()
                _invalidate_material_lookup_cache()
                ports.invalidate_material_name_cache()

    def _normalize_material_record_for_admin(self, rec):
        ports = self._material_catalog_ports

        DECOR_MEDIA_ROOT = ports.get_decor_media_root()
        _PUBLIC_MATERIAL_ID_RE = ports.get_public_material_id_re()

        if not isinstance(rec, dict):
            rec = {}
        out = dict(rec)
        art = str(out.get("articleNo") or out.get("articleNumber") or out.get("materialCode") or "").strip()
        out["articleNo"] = art
        out["materialCode"] = str(out.get("materialCode") or art).strip()
        if out.get("sheetWid") is None and out.get("sheetWidth") is not None:
            out["sheetWid"] = out.get("sheetWidth")
        if out.get("sheetLen") is None:
            for k in ("sheetHeight", "height"):
                if out.get(k) is not None:
                    out["sheetLen"] = out.get(k)
                    break
        if out.get("thicknessMm") is None and out.get("thickness") is not None:
            out["thicknessMm"] = out.get("thickness")

        # Direct per-material sell price is the active pricing model. Keep legacy purchase
        # fields only as internal historical data; never expose them to Tool A.
        try:
            incl = float(out.get("sellPriceInclVatPerSheet") or 0.0)
        except (ValueError, TypeError, OverflowError):
            incl = 0.0
        try:
            ex = float(out.get("sellPriceExVatPerSheet") or 0.0)
        except (ValueError, TypeError, OverflowError):
            ex = 0.0
        if incl <= 0 and ex > 0:
            incl = round(ex * (1.0 + CATALOG_VAT_RATE), 2)
        if ex <= 0 and incl > 0:
            ex = round(incl / (1.0 + CATALOG_VAT_RATE), 6)
        out["sellPriceInclVatPerSheet"] = incl if incl > 0 else None
        out["sellPriceExVatPerSheet"] = ex if ex > 0 else None

        pid = str(out.get("publicMaterialId") or "").strip().lower()
        if pid and not _PUBLIC_MATERIAL_ID_RE.fullmatch(pid):
            pid = ""
        out["publicMaterialId"] = pid
        out["publicName"] = self._public_material_name(out)
        out["brand"] = str(out.get("brand") or "").strip() or self._infer_material_brand(out)
        # fast path: imported CSV records already contain deterministic presentation
        # fields. Reclassify only legacy/incomplete records, never 597 records per request.
        have_presentation = (
            bool(str(out.get("visualFamily") or out.get("decorType") or "").strip())
            and isinstance(out.get("visualTags"), list)
            and bool(str(out.get("colorGroup") or "").strip())
            and isinstance(out.get("searchTags"), list)
        )
        presentation = {} if have_presentation else self._material_presentation(out)
        out["visualFamily"] = str(
            out.get("visualFamily") or out.get("decorType") or presentation.get("visualFamily") or "Overig"
        )
        out["visualTags"] = list(
            out.get("visualTags") or presentation.get("visualTags") or [out["visualFamily"]]
        )
        out["decorType"] = str(out.get("decorType") or out["visualFamily"])
        out["colorGroup"] = str(out.get("colorGroup") or presentation.get("colorGroup") or "Overig")
        out["searchTags"] = list(out.get("searchTags") or presentation.get("searchTags") or [])
        out["published"] = bool(out.get("published", out.get("active", True)))
        out["isPopular"] = bool(out.get("isPopular", False))
        out["isNew"] = bool(out.get("isNew", False))
        out["hasGrain"] = True if out.get("hasGrain") is None else bool(out.get("hasGrain"))
        out["grainDefaultOn"] = True if out.get("grainDefaultOn") is None else bool(out.get("grainDefaultOn"))
        out["archived"] = bool(out.get("archived", False))
        out["sourceKind"] = str(out.get("sourceKind") or "LEGACY_LIBRARY").strip() or "LEGACY_LIBRARY"
        out["catalogMissing"] = bool(out.get("catalogMissing", False))
        out["catalogExcluded"] = bool(out.get("catalogExcluded", False))

        if pid:
            version = str(out.get("imageVersion") or "").strip()
            thumb = DECOR_MEDIA_ROOT / pid / "thumb.webp"
            preview = DECOR_MEDIA_ROOT / pid / "preview.webp"
            catalog_cached = resolve_reviewed_swatch(_catalog_read_cached_image(DECOR_MEDIA_ROOT / pid))
            prefer_catalog = str(out.get("sourceKind") or "").upper() == "CATALOG_IMPORT"
            catalog_meta = catalog_cached[1] if catalog_cached else {}
            if catalog_meta.get("reviewedSwatch"):
                # Presentation revision outranks an old CSV/manual imageVersion.
                version = ""
                prefer_catalog = True
            catalog_version = str(version or catalog_meta.get("sha256") or "")[:64]
            suffix = ("?v=" + quote(catalog_version)) if catalog_version else ""
            variants = (
                catalog_meta.get("variants")
                if isinstance(catalog_meta, dict) and isinstance(catalog_meta.get("variants"), dict)
                else {}
            )
            # imported images are prepared before publication. Prefer the lightweight
            # WebP variants when the cache metadata confirms they belong to the current source.
            if (
                prefer_catalog
                and catalog_cached
                and thumb.exists()
                and preview.exists()
                and "thumb.webp" in variants
                and "preview.webp" in variants
            ):
                out["imageAvailable"] = True
                out["imageThumbUrl"] = f"/api/materials/image/{pid}/thumb.webp{suffix}"
                out["imagePreviewUrl"] = f"/api/materials/image/{pid}/preview.webp{suffix}"
                out["imageCacheKind"] = "catalog_webp"
            elif prefer_catalog and catalog_cached:
                out["imageAvailable"] = True
                out["imageThumbUrl"] = f"/api/materials/image/{pid}/catalog{suffix}"
                out["imagePreviewUrl"] = f"/api/materials/image/{pid}/catalog{suffix}"
                out["imageCacheKind"] = "catalog_cache"
            elif thumb.exists() and preview.exists():
                out["imageAvailable"] = True
                suffix = ("?v=" + quote(version)) if version else ""
                out["imageThumbUrl"] = f"/api/materials/image/{pid}/thumb.webp{suffix}"
                out["imagePreviewUrl"] = f"/api/materials/image/{pid}/preview.webp{suffix}"
                out["imageCacheKind"] = "manual_webp"
            elif catalog_cached:
                out["imageAvailable"] = True
                meta = catalog_cached[1]
                catalog_version = str(version or meta.get("sha256") or "")[:64]
                suffix = ("?v=" + quote(catalog_version)) if catalog_version else ""
                out["imageThumbUrl"] = f"/api/materials/image/{pid}/catalog{suffix}"
                out["imagePreviewUrl"] = f"/api/materials/image/{pid}/catalog{suffix}"
                out["imageCacheKind"] = "catalog_cache"
            else:
                out["imageAvailable"] = False
        return out

    def _material_record_to_toola_catalog(self, rec, already_normalized: bool = False):
        """Return the minimal public material contract.

        Internal article numbers, supplier fields and purchase prices never leave this
        method. Tool A creates its own opaque compatibility aliases client-side.
        """
        rr = (
            rec
            if already_normalized and isinstance(rec, dict)
            else self._normalize_material_record_for_admin(rec)
        )
        pid = str(rr.get("publicMaterialId") or "").strip()
        public_name = self._public_material_name(rr)
        try:
            w = float(rr.get("sheetWid") or rr.get("sheetWidth") or 0)
        except (ValueError, TypeError, OverflowError):
            w = 0.0
        try:
            h = float(rr.get("sheetLen") or rr.get("sheetHeight") or rr.get("height") or 0)
        except (ValueError, TypeError, OverflowError):
            h = 0.0
        try:
            t = float(rr.get("thicknessMm") or rr.get("thickness") or 0)
        except (ValueError, TypeError, OverflowError):
            t = 0.0
        active = bool(rr.get("active", True)) and not bool(rr.get("archived", False))
        return {
            "publicMaterialId": pid,
            "publicName": public_name,
            "brand": str(rr.get("brand") or "Overig").strip() or "Overig",
            "decorType": str(
                rr.get("primaryVisualFamily") or rr.get("decorType") or rr.get("visualFamily") or "Onbekend"
            ).strip()
            or "Onbekend",
            "primaryVisualFamily": str(
                rr.get("primaryVisualFamily") or rr.get("visualFamily") or rr.get("decorType") or "Onbekend"
            ).strip()
            or "Onbekend",
            "visualFamily": str(
                rr.get("primaryVisualFamily") or rr.get("visualFamily") or rr.get("decorType") or "Onbekend"
            ).strip()
            or "Onbekend",
            "visualTags": [str(x)[:40] for x in (rr.get("visualTags") or []) if str(x).strip()][:12],
            "substrateType": str(rr.get("substrateType") or "ONBEKEND").strip().upper() or "ONBEKEND",
            "substrateLabel": str(rr.get("substrateLabel") or "Onbekend").strip() or "Onbekend",
            "collection": str(rr.get("collection") or "").strip()[:80],
            "colorGroup": str(rr.get("colorGroup") or "Overig").strip() or "Overig",
            "searchTags": [str(x)[:60] for x in (rr.get("searchTags") or []) if str(x).strip()][:48],
            "thicknessMm": t,
            "sheetSizeMm": {"width": w, "height": h},
            "hasGrain": bool(rr.get("hasGrain", True)),
            "grainDefaultOn": bool(rr.get("grainDefaultOn", True)),
            "active": active,
            "published": bool(rr.get("published", active)),
            "isPopular": bool(rr.get("isPopular", False)),
            "isNew": bool(rr.get("isNew", False)),
            "imageAvailable": bool(rr.get("imageAvailable", False)),
            "imageThumbUrl": rr.get("imageThumbUrl") or "",
            "imagePreviewUrl": rr.get("imagePreviewUrl") or "",
        }

    def _material_id_maps(self) -> tuple[dict[str, str], dict[str, str]]:
        ports = self._material_catalog_ports
        _material_lookup_snapshot = ports.material_lookup_snapshot

        snapshot = _material_lookup_snapshot()
        # Return shallow map copies so a caller cannot mutate the shared cache.
        return dict(snapshot.get("publicToInternal") or {}), dict(snapshot.get("internalToPublic") or {})

    def _resolve_public_material_value(self, value, public_to_internal: dict[str, str]):
        if not isinstance(value, str):
            raise ValueError("Publieke materiaal-ID moet tekst zijn.")
        raw = validate_public_material_id(value.strip().lower())
        if raw not in public_to_internal:
            raise PublicJobInputError(
                "CATALOG_CHANGED", "Dit decor is niet meer beschikbaar. Kies het materiaal opnieuw."
            )
        return public_to_internal[raw]

    def _rewrite_panels_csv_material_ids(self, text: str, public_to_internal: dict[str, str]) -> str:
        text = str(text or "")
        if not text.strip():
            return text
        inp = io.StringIO(text)
        reader = csv.DictReader(inp, delimiter=";")
        if not reader.fieldnames:
            return text
        out = io.StringIO(newline="")
        writer = csv.DictWriter(
            out, fieldnames=reader.fieldnames, delimiter=";", lineterminator="\n", extrasaction="ignore"
        )
        writer.writeheader()
        for row in reader:
            for key in ("MaterialCode", "ArticleNumber", "articleNumber", "articleNo", "materialCode"):
                if key in row and row.get(key) is not None:
                    row[key] = self._resolve_public_material_value(
                        str(row.get(key) or ""), public_to_internal
                    )
            writer.writerow(row)
        return out.getvalue()

    def _canonicalize_public_job_payload(self, payload: dict) -> dict:
        """Convert browser intent into the complete server-owned production contract."""
        ports = self._material_catalog_ports

        _expand_dxf_payload = ports.expand_dxf_payload
        _material_lookup_snapshot = ports.material_lookup_snapshot

        _utc_now_iso = ports.utc_now_iso

        if not isinstance(payload, dict):
            raise SafetyContractError("Job payload must be an object")
        allowed_keys = {
            "panelsCsv",
            "dxfParts",
            "dxfBlobs",
            "dxfPartRefs",
            "jobJson",
            "pricing",
            "preflightEstimate",
            "payloadSchema",
            "panelIntents",
        }
        unknown = sorted(set(payload) - allowed_keys)
        if unknown:
            raise SafetyContractError(f"Unknown job payload fields: {unknown[:8]}")

        catalog_snapshot = _material_lookup_snapshot()
        if not (catalog_snapshot.get("publicToInternal") or {}):
            # One-time compatibility migration for a pre-public-ID library.  Normal
            # requests never enter this path once the active CSV catalog is current.
            self._load_material_library_bundle()
            catalog_snapshot = _material_lookup_snapshot()
        public_to_internal = catalog_snapshot.get("publicToInternal") or {}
        if not public_to_internal:
            raise SafetyContractError("De actieve materiaalcatalogus is leeg")
        raw_csv = payload.get("panelsCsv")
        if not isinstance(raw_csv, str):
            raise SafetyContractError("panelsCsv is required")
        rows = _parse_panels_csv_contract(
            raw_csv,
            allowed_thicknesses=CATALOG_ALLOWED_THICKNESSES_MM,
            allowed_edge_codes={0, 1},
            max_rows=_env_int("PUBLIC_JOB_MAX_PANEL_ROWS", 500),
            max_total_qty=_env_int("PUBLIC_JOB_TOTAL_QTY_LIMIT", 250),
        )

        catalog_by_internal = catalog_snapshot.get("catalogByInternal") or {}

        canonical_rows = []
        for row in rows:
            public_id = validate_public_material_id(row.MaterialCode.lower())
            internal = public_to_internal.get(public_id)
            if not internal:
                raise PublicJobInputError(
                    "CATALOG_CHANGED", "Dit decor is niet meer beschikbaar. Kies het materiaal opnieuw."
                )
            record = catalog_by_internal.get(internal)
            if not isinstance(record, dict):
                raise PublicJobInputError(
                    "CATALOG_CHANGED", "Dit decor is niet meer beschikbaar. Kies het materiaal opnieuw."
                )
            if (
                str(record.get("sourceKind") or "").upper() != "CATALOG_IMPORT"
                or record.get("catalogMissing") is True
                or record.get("active") is False
                or record.get("archived") is True
                or record.get("published") is False
                or record.get("catalogExcluded") is True
            ):
                raise PublicJobInputError(
                    "CATALOG_CHANGED", "Dit decor is niet meer beschikbaar. Kies het materiaal opnieuw."
                )
            live_thickness = finite_number(
                record.get("thicknessMm"),
                field=f"{public_id}.thicknessMm",
                minimum=0.1,
                maximum=100.0,
            )
            if abs(live_thickness - row.ThicknessMm) > 1e-9:
                raise SafetyContractError(f"{row.PartId}: plaatdikte wijkt af van de actieve catalogus")
            if row.GrainGroup and record.get("hasGrain") is False:
                raise SafetyContractError(f"{row.PartId}: dit materiaal staat geen GrainGroup toe")
            canonical_rows.append(replace(row, MaterialCode=internal, ThicknessMm=live_thickness))

        dxf_parts = _expand_dxf_payload(payload)
        expected_part_ids = {row.PartId for row in canonical_rows}
        supplied_part_ids = set(dxf_parts)
        if supplied_part_ids != expected_part_ids:
            missing = sorted(expected_part_ids - supplied_part_ids)[:10]
            extra = sorted(supplied_part_ids - expected_part_ids)[:10]
            raise SafetyContractError(
                f"DXF-set komt niet exact overeen met panelen; ontbreekt={missing}, extra={extra}"
            )

        max_blob_bytes = _env_int("PUBLIC_DXF_BLOB_MAX_BYTES", 2 * 1024 * 1024)
        max_total_bytes = _env_int("PUBLIC_DXF_TOTAL_MAX_BYTES", 12 * 1024 * 1024)
        unique_dxf_bytes = 0
        # Compact browser transport deliberately maps many PartIds to one immutable
        # DXF body. Validate that body once, then repeat only the per-panel bbox check.
        # The old loop reparsed the same potentially large DXF hundreds of times before
        # the API could even return 202 for a 200–250 panel order.
        # Browser compact transport can map hundreds of PartIds to one Python string
        # object.  Encode/hash/parse that body once, then only perform the required
        # per-panel bbox comparison.  This changes no geometry or placement policy.
        validated_body_text: dict[str, tuple[str, Any]] = {}
        canonical_dxf_blobs: dict[str, str] = {}
        canonical_dxf_refs: dict[str, str] = {}
        row_by_id = {row.PartId: row for row in canonical_rows}
        supplied_intents = payload.get("panelIntents", {})
        if not isinstance(supplied_intents, dict) or set(supplied_intents) - expected_part_ids:
            raise SafetyContractError("Ongeldige panelIntents-set")
        template_cache = {}
        canonical_intents = {}
        intent_cache = {}
        entity_cache = {}
        bbox_tolerance = finite_number(
            os.environ.get("DXF_BBOX_TOLERANCE_MM", "0.1"),
            field="DXF_BBOX_TOLERANCE_MM",
            minimum=0.0,
            maximum=1.0,
        )
        for part_id, dxf_text in dxf_parts.items():
            body_info = validated_body_text.get(dxf_text)
            if body_info is None:
                encoded = dxf_text.encode("utf-8", errors="strict")
                if len(encoded) > max_blob_bytes:
                    raise SafetyContractError(f"{part_id}: DXF is te groot")
                digest = hashlib.sha256(encoded).hexdigest()
                unique_dxf_bytes += len(encoded)
                if unique_dxf_bytes > max_total_bytes:
                    raise SafetyContractError("Totale DXF-invoer is te groot")
                pairs = _strict_dxf_parse_pairs(dxf_text)
                entities, bbox = validated_panel_geometry(pairs)
                entity_cache[digest] = entities
                validated_body_text[dxf_text] = (digest, bbox)
                previous_body = canonical_dxf_blobs.get(digest)
                if previous_body is not None and previous_body != dxf_text:
                    raise SafetyContractError("DXF content-address collision")
                canonical_dxf_blobs.setdefault(digest, dxf_text)
            else:
                digest, bbox = body_info
            intent = supplied_intents.get(part_id)
            intent_key = (digest, strict_json_dumps(intent))
            if intent_key not in intent_cache:
                intent_cache[intent_key] = validate_panel_intent(
                    entity_cache[digest], intent, ports.get_dxf_library_root(), template_cache
                )
            canonical_intents[part_id] = intent_cache[intent_key]
            canonical_dxf_refs[part_id] = digest
            row = row_by_id[part_id]
            if (
                abs(bbox.width - row.WidthMm) > bbox_tolerance
                or abs(bbox.height - row.LengthMm) > bbox_tolerance
            ):
                raise SafetyContractError(
                    f"{part_id}: DXF bbox {bbox.width:.3f}x{bbox.height:.3f} wijkt af van CSV "
                    f"{row.WidthMm:.3f}x{row.LengthMm:.3f}"
                )

        raw_job = payload.get("jobJson") if isinstance(payload.get("jobJson"), dict) else {}
        raw_customer = raw_job.get("customer") if isinstance(raw_job.get("customer"), dict) else {}
        customer: dict[str, Any] = {}
        for key in (
            "name",
            "fullName",
            "firstName",
            "lastName",
            "company",
            "companyName",
            "city",
            "country",
            "shippingCity",
            "shippingCountry",
        ):
            if raw_customer.get(key) not in (None, ""):
                customer[key] = _sanitize_user_text(raw_customer.get(key), 240)
        for key in ("email", "mail"):
            if raw_customer.get(key) not in (None, ""):
                value = _clean_text(raw_customer.get(key), 320).strip()
                if not _EMAIL_RE.fullmatch(value):
                    raise PublicJobInputError("INVALID_EMAIL", "Controleer het e-mailadres.")
                customer[key] = value
        for key in ("phone", "tel", "telephone"):
            if raw_customer.get(key) not in (None, ""):
                customer[key] = _sanitize_phone_text(raw_customer.get(key), 60)
        for key in (
            "address",
            "addressLine1",
            "street",
            "billingAddress",
            "invoiceAddress",
            "shippingAddress",
            "deliveryAddress",
            "address1",
        ):
            if raw_customer.get(key) not in (None, ""):
                customer[key] = _sanitize_user_text(raw_customer.get(key), 320)
        for key in ("houseNumber", "shippingHouseNumber", "deliveryHouseNumber"):
            if raw_customer.get(key) not in (None, ""):
                customer[key] = _sanitize_house_number_text(raw_customer.get(key), 32)
        for key in (
            "postalCode",
            "postcode",
            "shippingPostcode",
            "shippingPostalCode",
            "deliveryPostcode",
            "deliveryPostalCode",
        ):
            if raw_customer.get(key) not in (None, ""):
                customer[key] = _sanitize_postcode_text(raw_customer.get(key), 16)
        if isinstance(raw_customer.get("shippingSameAsBilling"), bool):
            customer["shippingSameAsBilling"] = bool(raw_customer.get("shippingSameAsBilling"))
        rest = raw_job.get("rest_material") if isinstance(raw_job.get("rest_material"), dict) else {}
        carry_out = rest.get("carry_out") is True
        raw_note = raw_job.get("note") or ""
        if not isinstance(raw_note, str) or len(raw_note) > 2000:
            raise PublicJobInputError("NOTE_TOO_LONG", "De opmerking mag maximaal 2000 tekens bevatten.")
        note = _sanitize_user_text(raw_note, 2000, allow_note_chars=True)
        canonical_job = {
            "createdAt": _utc_now_iso(),
            "project": "METOD_PAX",
            "grainEnabled": any(bool(row.GrainGroup) for row in canonical_rows),
            "grainPolicy": "server-canonical-v1",
            "productionIntents": canonical_intents,
            "rest_material": {"carry_out": carry_out},
            "customer": customer,
            "note": note,
        }
        return {
            "panelsCsv": _canonical_panels_csv(canonical_rows),
            "dxfBlobs": canonical_dxf_blobs,
            "dxfPartRefs": canonical_dxf_refs,
            "jobJson": canonical_job,
            "payloadSchema": "FIX660R8_SERVER_CANONICAL_V1",
        }

    def _resolve_public_material_payload(self, payload: dict) -> dict:
        if not isinstance(payload, dict):
            return payload
        public_to_internal, _ = self._material_id_maps()
        if not public_to_internal:
            raise ValueError("De actieve materiaalcatalogus is leeg.")
        if isinstance(payload.get("panelsCsv"), str):
            payload["panelsCsv"] = self._rewrite_panels_csv_material_ids(
                payload.get("panelsCsv") or "", public_to_internal
            )
        code_keys = {
            "articleNumber",
            "articleNo",
            "materialCode",
            "MaterialCode",
            "ArticleNumber",
            "materialKey",
            "material",
        }

        def walk(value, parent_key=""):
            if isinstance(value, dict):
                for key in list(value.keys()):
                    if key == "panelsCsv":
                        continue
                    item = value.get(key)
                    if key in code_keys and isinstance(item, str):
                        value[key] = self._resolve_public_material_value(item, public_to_internal)
                    else:
                        walk(item, key)
            elif isinstance(value, list):
                for item in value:
                    walk(item, parent_key)

        walk(payload)
        return payload

    def _sanitize_public_material_response(self, obj):
        """Remove or replace internal material identifiers in public job output."""
        ports = self._material_catalog_ports
        _material_lookup_snapshot = ports.material_lookup_snapshot

        catalog_snapshot = _material_lookup_snapshot()
        internal_to_public = dict(catalog_snapshot.get("internalToPublic") or {})

        # A finalized quote retains its own internal identity even after a CSV
        # publication removes the material. Use that trusted document context as
        # an independent redaction source; never keep retired catalog rows active.
        def collect_identities(value):
            if isinstance(value, dict):
                public_id = str(value.get("publicMaterialId") or "").strip()
                if not PUBLIC_MATERIAL_ID_RE.fullmatch(public_id):
                    public_id = ""
                for internal in internal_material_codes(value):
                    internal_to_public.setdefault(internal, public_id)
                for child in value.values():
                    collect_identities(child)
            elif isinstance(value, list):
                for child in value:
                    collect_identities(child)

        collect_identities(obj)
        replacements = sorted(internal_to_public.items(), key=lambda item: len(item[0]), reverse=True)
        sensitive = {
            "purchaseprice",
            "purchasepricepersheet",
            "purchase_price",
            "inkoopprijs",
            "supplier",
            "suppliername",
            "leverancier",
            "suppliercode",
            "supplierarticle",
            "internalarticle",
            "internalarticlenumber",
            "internal_article_number",
            "internalcode",
            # Raw/internal pricing audit fields never belong in customer responses.
            "sheetunitcostraw",
            "sheetcosttotalraw",
            "bycodecostraw",
            "edgecosttotalraw",
            "imagesourceurl",
            "imagesourceurls",
            "sourceimageurl",
            "catalogsourceurl",
        }
        code_keys = INTERNAL_MATERIAL_KEYS

        def replace_codes(text: str) -> str:
            result = str(text)
            for internal, public_id in replacements:
                if internal in result:
                    result = result.replace(internal, public_id)
            return result

        def clean(value, key=""):
            if isinstance(value, dict):
                out = {}
                for k, v in value.items():
                    lk = str(k).lower()
                    if lk in sensitive:
                        continue
                    if lk == "publicmaterialid":
                        out[k] = v if isinstance(v, str) and PUBLIC_MATERIAL_ID_RE.fullmatch(v) else ""
                        continue
                    if lk in {
                        "jobid",
                        "subjobid",
                        "parentjobid",
                        "partid",
                        "sheetid",
                        "status",
                        "state",
                        "phase",
                        "currency",
                        "pricingmodel",
                        "schemaversion",
                    }:
                        # These are canonical routing identities, not material
                        # labels. Substring redaction would corrupt valid IDs.
                        out[k] = v
                        continue
                    raw_code = str(v).strip() if isinstance(v, (str, int)) and not isinstance(v, bool) else ""
                    if lk in code_keys or (lk == "code" and raw_code in internal_to_public):
                        mapped = internal_to_public.get(raw_code)
                        out[k] = mapped or (raw_code if PUBLIC_MATERIAL_ID_RE.fullmatch(raw_code) else "")
                        continue
                    if lk == "code":
                        out[k] = v  # A non-material machine error/event code.
                        continue
                    out[k] = clean(v, k)
                return out
            if isinstance(value, list):
                return [clean(v, key) for v in value]
            if isinstance(value, str):
                return replace_codes(value)
            return value

        return clean(obj)

    def _public_quote_view(self, quote):
        """Return the minimum customer-safe quote projection Tool A needs.

        Internal quote.json can contain production identifiers and audit fields. Public
        callers receive only totals plus opaque public material IDs, display names and
        sheet counts. This makes article numbers unavailable even to a customer who
        inspects the network response instead of merely hiding them in the UI.
        """
        if not isinstance(quote, dict):
            return None
        safe = self._sanitize_public_material_response(quote)
        out = {"currency": str(safe.get("currency") or "EUR")}
        if str(safe.get("pricingModel") or "") == "catalog_sell_price_incl_vat_v2":
            out["pricingModel"] = "catalog_sell_price_incl_vat_v2"
        totals_in = safe.get("totals") if isinstance(safe.get("totals"), dict) else {}
        totals = {}
        for key in ("grandTotal", "total", "totalInclVat", "grandTotalInclVat", "sheetCount"):
            if totals_in.get(key) is not None:
                totals[key] = totals_in.get(key)
        if totals:
            out["totals"] = totals
        for key in (
            "grandTotal",
            "total",
            "totalInclVat",
            "grandTotalInclVat",
            "total_incl_vat",
            "sheetCount",
        ):
            if safe.get(key) is not None:
                out[key] = safe.get(key)
        mats_out = []
        raw_materials = quote.get("materials") if isinstance(quote.get("materials"), list) else []
        catalog = self._material_catalog_ports.material_lookup_snapshot()
        private_codes = set(catalog.get("internalToPublic") or {})
        for raw in raw_materials:
            if isinstance(raw, dict):
                private_codes.update(internal_material_codes(raw))
        for index, m in enumerate(safe.get("materials") or []):
            if not isinstance(m, dict):
                continue
            code = str(
                m.get("publicMaterialId")
                or m.get("materialCode")
                or m.get("code")
                or m.get("articleNumber")
                or ""
            ).strip()
            if code and not PUBLIC_MATERIAL_ID_RE.fullmatch(code):
                # Never echo an unresolved identifier to a public caller.
                code = ""
            raw = (
                raw_materials[index]
                if index < len(raw_materials) and isinstance(raw_materials[index], dict)
                else {}
            )
            # New jobs have an explicit safe display snapshot. Older quotes must
            # carry a private code or current catalog mapping to establish which
            # identifiers to remove from their untrusted legacy display fields.
            known_identity = bool(internal_material_codes(raw)) or code in (
                catalog.get("publicToInternal") or {}
            )
            name = (
                public_material_name(raw, private_codes)
                if raw.get("publicName") or known_identity
                else "Decor"
            )
            item = {}
            if code:
                item["publicMaterialId"] = code
                item["materialCode"] = code  # compatibility alias; value is opaque public ID
            if name:
                item["name"] = name
            for src, dst in (("sheetCount", "sheetCount"), ("plates", "plates"), ("sheets", "sheets")):
                if m.get(src) is not None:
                    item[dst] = m.get(src)
            if item:
                mats_out.append(item)
        if mats_out:
            out["materials"] = mats_out
        per_subjob_out = []
        for item in safe.get("perSubjob") or []:
            if not isinstance(item, dict):
                continue
            subjob_id = str(item.get("subjobId") or "").strip()
            if not subjob_id:
                continue
            projected = {
                "subjobId": subjob_id,
                "currency": str(item.get("currency") or "EUR"),
            }
            sub_totals_in = item.get("totals") if isinstance(item.get("totals"), dict) else {}
            sub_totals = {}
            for key in ("grandTotal", "total", "totalInclVat", "grandTotalInclVat", "sheetCount"):
                if sub_totals_in.get(key) is not None:
                    sub_totals[key] = sub_totals_in.get(key)
            if sub_totals:
                projected["totals"] = sub_totals
            for key in ("grandTotal", "sheetCount"):
                if item.get(key) is not None:
                    projected[key] = item.get(key)
            per_subjob_out.append(projected)
        if per_subjob_out:
            out["perSubjob"] = per_subjob_out
        return out

    def _decor_image_file(self, public_id: str, variant: str) -> Path | None:
        ports = self._material_catalog_ports
        DECOR_MEDIA_ROOT = ports.get_decor_media_root()

        _PUBLIC_MATERIAL_ID_RE = ports.get_public_material_id_re()

        pid = str(public_id or "").strip().lower()
        if not _PUBLIC_MATERIAL_ID_RE.fullmatch(pid):
            return None
        root = DECOR_MEDIA_ROOT.resolve()
        if variant == "catalog":
            cached = _catalog_read_cached_image(DECOR_MEDIA_ROOT / pid)
            if not cached:
                return None
            target = cached[0].resolve()
        elif variant in ("thumb.webp", "preview.webp"):
            target = (DECOR_MEDIA_ROOT / pid / variant).resolve()
        else:
            return None
        if root not in target.parents:
            return None
        return target

    def _webp_dimensions(self, data: bytes) -> tuple[int, int] | None:
        try:
            if len(data) < 30 or data[:4] != b"RIFF" or data[8:12] != b"WEBP":
                return None
            pos = 12
            while pos + 8 <= len(data):
                fourcc = data[pos : pos + 4]
                size = int.from_bytes(data[pos + 4 : pos + 8], "little")
                chunk = data[pos + 8 : pos + 8 + size]
                if len(chunk) < size:
                    return None
                if fourcc == b"VP8X" and len(chunk) >= 10:
                    w = 1 + int.from_bytes(chunk[4:7], "little")
                    h = 1 + int.from_bytes(chunk[7:10], "little")
                    return w, h
                if fourcc == b"VP8 " and len(chunk) >= 10 and chunk[3:6] == b"\x9d\x01\x2a":
                    w = int.from_bytes(chunk[6:8], "little") & 0x3FFF
                    h = int.from_bytes(chunk[8:10], "little") & 0x3FFF
                    return w, h
                if fourcc == b"VP8L" and len(chunk) >= 5 and chunk[0] == 0x2F:
                    b1, b2, b3, b4 = chunk[1], chunk[2], chunk[3], chunk[4]
                    w = 1 + (b1 | ((b2 & 0x3F) << 8))
                    h = 1 + ((b2 >> 6) | (b3 << 2) | ((b4 & 0x0F) << 10))
                    return w, h
                pos += 8 + size + (size & 1)
        except Exception as recovery_error:
            report_recovery("metod_app.http.material_catalog_runtime.boundary.812", recovery_error)
            return None
        return None

    @catalog_guarded
    def _api_admin_materials_library(self):
        ports = self._material_catalog_ports
        _append_system_event = ports.append_system_event

        try:
            raw, recs = self._load_material_library_bundle()
            norm = []
            for r in recs:
                if not isinstance(r, dict):
                    continue
                rr = self._normalize_material_record_for_admin(r)
                if (
                    str(rr.get("sourceKind") or "").upper() != "CATALOG_IMPORT"
                    or rr.get("catalogMissing") is True
                    or rr.get("catalogExcluded") is True
                ):
                    continue
                norm.append(rr)
            return self._send_json(
                {
                    "ok": True,
                    "records": norm,
                    "meta": {
                        "source": "CSV_CATALOG_ONLY",
                        "count": len(norm),
                        "decorLibrarySchemaVersion": raw.get("decorLibrarySchemaVersion", 4),
                        "mode": "CSV_ONLY",
                        "lastCatalogImport": raw.get("lastCatalogImport"),
                    },
                }
            )
        except Exception as e:
            report_recovery("metod_app.http.material_catalog_runtime.boundary.832", e)
            _append_system_event(
                level="error",
                component="materials",
                message_user="Materiaalbeheer laden is mislukt",
                message_tech=str(e),
                status="open",
            )
            return self._send_json({"ok": False, "error": "Materiaalbeheer kon niet worden geladen"}, 500)

    def _api_admin_materials_save_item(self):
        return self._send_json(
            {
                "ok": False,
                "error": "De actieve Decor Library wordt uitsluitend via CSV controleren + publiceren beheerd.",
            },
            410,
        )

    def _api_admin_materials_delete_item(self):
        return self._send_json(
            {
                "ok": False,
                "error": "De actieve Decor Library wordt uitsluitend via CSV controleren + publiceren beheerd.",
            },
            410,
        )

    def _api_admin_materials_upload(self):
        return self._send_json(
            {
                "ok": False,
                "error": "De actieve Decor Library wordt uitsluitend via CSV controleren + publiceren beheerd.",
            },
            410,
        )

    def _api_public_material_image(self, public_id: str, variant: str):
        ports = self._material_catalog_ports
        DECOR_MEDIA_ROOT = ports.get_decor_media_root()
        _PUBLIC_MATERIAL_ID_RE = ports.get_public_material_id_re()

        pid = str(public_id or "").strip().lower()
        if not _PUBLIC_MATERIAL_ID_RE.fullmatch(pid) or variant not in (
            "catalog",
            "thumb.webp",
            "preview.webp",
        ):
            return self._send_text("Not found", 404)
        try:
            with catalog_guard(ports.catalog):
                ctype = "image/webp"
                path = None
                cached = resolve_reviewed_swatch(_catalog_read_cached_image(DECOR_MEDIA_ROOT / pid))
                if cached and (variant == "catalog" or cached[1].get("reviewedSwatch")):
                    path, meta = cached
                    ctype = str(meta.get("mime") or "application/octet-stream")
                elif variant != "catalog":
                    path = self._decor_image_file(pid, variant)
                if path is None or not path.exists() or not path.is_file():
                    return self._send_text("Not found", 404)
                data = path.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "public, max-age=31536000, immutable")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.end_headers()
            self.wfile.write(data)
        except Exception as recovery_error:
            report_recovery("metod_app.http.material_catalog_runtime.boundary.873", recovery_error)
            return self._send_text("Image unavailable", 500)

    def _api_admin_material_image_upload(self):
        return self._send_json(
            {
                "ok": False,
                "error": "De actieve Decor Library wordt uitsluitend via CSV controleren + publiceren beheerd.",
            },
            410,
        )

    def _api_admin_material_image_delete(self):
        return self._send_json(
            {
                "ok": False,
                "error": "De actieve Decor Library wordt uitsluitend via CSV controleren + publiceren beheerd.",
            },
            410,
        )
