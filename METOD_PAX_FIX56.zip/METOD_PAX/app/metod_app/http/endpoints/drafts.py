"""HTTP endpoint adapters for drafts."""

from __future__ import annotations

from metod_app.observability.failures import report_recovery

import json
from metod_app.runtime.ports import HttpEndpointsDraftsPorts


def api_draft_save(ports: HttpEndpointsDraftsPorts, self):
    """Compatibility no-op.

    Tool A no longer stores shared server-side drafts. The historical endpoint was
    unauthenticated and could expose or overwrite data. Empty reset writes remain
    accepted so the current reset flow stays compatible.
    """
    _read_json_body_limited = ports.read_json_body_limited

    try:
        data = _read_json_body_limited(self, "PUBLIC_DRAFT_MAX_BYTES", 16384) or {}
        draft = data.get("draft")
        if draft not in (None, {}):
            return self._send_json(
                {"ok": False, "error": "Serverconcepten worden niet meer ondersteund"}, code=410
            )
        return self._send_json({"ok": True, "disabled": True})
    except Exception as recovery_error:
        report_recovery("metod_app.http.endpoints.drafts.boundary.24", recovery_error)
        return self._send_json({"ok": False, "error": "Ongeldig conceptverzoek"}, code=400)


def api_dxf_manifest_meta(ports: HttpEndpointsDraftsPorts, handler, parsed):
    """Return current embedded DXF catalog version.

    IMPORTANT: must not be cached by browsers/proxies, because Tool A relies on this
    to detect live updates when SSE is flaky or blocked.
    """
    get_embedded_dxfs_version = ports.get_embedded_dxfs_version

    try:
        version = get_embedded_dxfs_version()
        body = json.dumps({"version": version}).encode("utf-8")
        handler.send_response(200)
        handler.send_header("Content-Type", "application/json; charset=utf-8")
        handler.send_header("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate")
        handler.send_header("Pragma", "no-cache")
        handler.send_header("Expires", "0")
        handler.send_header("Content-Length", str(len(body)))
        handler.end_headers()
        handler.wfile.write(body)
    except Exception as recovery_error:
        report_recovery("metod_app.http.endpoints.drafts.boundary.47", recovery_error)
        handler._send_json({"version": None, "error": "Manifest ophalen is mislukt"}, code=500)


def api_draft_load(ports: HttpEndpointsDraftsPorts, self, parsed):
    # Shared server-side drafts are disabled. Returning an empty result preserves
    # compatibility without reading historical files containing internal data.
    return self._send_json({"ok": True, "draft": None, "disabled": True})
