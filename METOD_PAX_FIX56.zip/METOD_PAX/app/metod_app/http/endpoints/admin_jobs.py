"""HTTP endpoint adapters for admin jobs."""

from __future__ import annotations

from pathlib import Path
from safety_contracts import ContractError as SafetyContractError
from datetime import datetime
from safety_contracts import resolve_identifier_child
from safety_contracts import strict_json_load
from datetime import timezone
from safety_contracts import validate_job_id
from metod_app.runtime.ports import HttpEndpointsAdminJobsPorts

from metod_app.observability.failures import report_recovery

from metod_app.pricing.summary import read_calculation_pricing


def _edge_meters_by_decor(ports: HttpEndpointsAdminJobsPorts, job_dir: Path):
    """Read input/panels.csv and sum required edge band meters per DecorName.

    Reporting-only helper for /admin. Never affects pricing or nesting.
    """

    try:
        import csv

        panels_path = job_dir / "input" / "panels.csv"
        if not panels_path.exists():
            return {}
        out = {}
        with panels_path.open("r", encoding="utf-8-sig", newline="") as f:
            reader = csv.DictReader(f)
            for r in reader:
                try:
                    qty = int(float((r.get("Qty") or "1").strip() or "1"))
                except (ValueError, TypeError, OverflowError):
                    qty = 1
                try:
                    L = float((r.get("LengthMm") or "0").strip() or "0")
                    W = float((r.get("WidthMm") or "0").strip() or "0")
                except (ValueError, TypeError, OverflowError):
                    L = 0.0
                    W = 0.0

                decor = (r.get("DecorName") or r.get("MaterialCode") or "").strip() or "—"

                def _code(name: str) -> int:
                    try:
                        return int(float((r.get(name) or "0").strip() or "0"))
                    except (ValueError, TypeError, OverflowError):
                        return 0

                # Same meter model as Tool B quote: H* uses LengthMm, W* uses WidthMm
                meters = 0.0
                if _code("H1") != 0:
                    meters += (L / 1000.0) * qty
                if _code("H2") != 0:
                    meters += (L / 1000.0) * qty
                if _code("W1") != 0:
                    meters += (W / 1000.0) * qty
                if _code("W2") != 0:
                    meters += (W / 1000.0) * qty

                if meters <= 0:
                    continue
                out[decor] = out.get(decor, 0.0) + meters
        # round for display
        return {k: round(v, 3) for k, v in sorted(out.items(), key=lambda kv: kv[0].lower())}
    except Exception as recovery_error:
        report_recovery("metod_app.http.endpoints.admin_jobs.boundary.64", recovery_error)
        return {}


def _admin_job_metadata(ports: HttpEndpointsAdminJobsPorts, job_root: Path, *, sealed: bool) -> dict:
    """Project status without writing state or trusting an in-memory success.

    Only the master has a durable lifecycle record. Material jobs share its
    creation time and terminal failures, but can finish their own sealed output
    while the remaining materials are still processing. Preserved legacy jobs
    without a lifecycle record still require verified finalization for success.
    """
    job_id = job_root.name
    master_id = job_id.split("__mat_", 1)[0]
    with ports.get_job_lock():
        master_meta = dict(ports.get_job_meta().get(master_id, {}) or {})
        own_meta = dict(ports.get_job_meta().get(job_id, {}) or {})
    try:
        record = ports.load_job_runtime_state(master_id)
        if not isinstance(record, dict) or (
            not record.get("state") and ports.job_runtime_state_path(master_id).exists()
        ):
            record = {"state": "INVALID"}
    except Exception as recovery_error:
        report_recovery("metod_app.http.endpoints.admin_jobs.boundary.87", recovery_error)
        record = {"state": "INVALID"}
    state = str(record.get("state") or "").upper()
    memory_status = str(own_meta.get("status") or master_meta.get("status") or "").lower()
    created_at = own_meta.get("createdAt") or record.get("createdAt") or master_meta.get("createdAt") or ""

    if state in {"CANCEL_REQUESTED", "CANCELLED"}:
        status = "cancelled"
    elif state == "FAILED" or state not in {"", "ACCEPTED", "PREPARING", "PROCESSING", "FINALIZING", "DONE"}:
        status = "error"
    elif state == "DONE":
        status = "done" if sealed else "error"
    elif memory_status in {"cancelled", "cancel_requested", "canceled"}:
        status = "cancelled"
    elif memory_status in {"error", "failed"}:
        status = "error"
    elif sealed and (job_id != master_id or not state):
        status = "done"
    elif state or memory_status in {"queued", "processing"}:
        status = "queued" if memory_status == "queued" else "processing"
    elif memory_status in {"done", "ready", "ok"}:
        status = "error"
    else:
        status = "unknown"
    return {"status": status, "createdAt": created_at}


def api_admin_jobs(ports: HttpEndpointsAdminJobsPorts, self):
    JOBS = ports.get_jobs()
    _admin_sheet_download_name = ports.admin_sheet_download_name
    _classify_output_kind = ports.classify_output_kind
    _customer_name_from_job = ports.customer_name_from_job
    _edge_meters_by_decor = ports.edge_meters_by_decor
    _parse_panels_csv = ports.parse_panels_csv
    _sealed_output_artifacts = ports.sealed_output_artifacts

    jobs = []
    for p in sorted(JOBS.glob("*")):
        if not p.is_dir():
            continue
        job_id = p.name
        output_dir = p / "output"
        sealed = _sealed_output_artifacts(p)
        meta = _admin_job_metadata(ports, p, sealed=bool(sealed))
        # Read-only endpoint: production exports are created and sealed by the
        # finalizer. Admin browsing must never mutate a completed job.
        sheets_dir = output_dir / "sheets"
        sheets = []
        if sealed:
            # Tool B may output sheet files with .dxf/.DXF or (on some systems) without an extension (e.g. 'Sheet_001').
            # Also allow nested folders under sheets/.
            sheet_files = [
                fp
                for rel, fp in sorted(sealed.items())
                if rel.startswith("output/sheets/") and fp.suffix.lower() == ".dxf"
            ]
            # Return relative names (under output/sheets) so download endpoint works.
            rels = []
            for f in sheet_files:
                try:
                    rels.append(str(f.relative_to(sheets_dir)).replace("\\", "/"))
                except Exception as recovery_error:
                    report_recovery("metod_app.http.endpoints.admin_jobs.boundary.147", recovery_error)
                    rels.append(f.name)
            seen = set()
            sheets = [x for x in rels if (x.lower() not in seen and not seen.add(x.lower()))]

        # --- Zaagplaten ---
        # Return both the real filename (for download) and a human-friendly label for display.
        # Some runs use short filenames (e.g. "105574_S01.dxf") as a fallback for Windows path limits.
        # The workshop still needs to SEE customer + material in Admin.
        output_dir / "DXF_Zaagplaten"
        zaag_files = []
        if sealed:
            zaag_files = [
                fp.name
                for rel, fp in sorted(sealed.items())
                if rel.startswith("output/DXF_Zaagplaten/") and fp.suffix.lower() == ".dxf"
            ]
            seen = set()
            zaag_files = [x for x in zaag_files if (x.lower() not in seen and not seen.add(x.lower()))]
            # De-duplicate per sheet index (S01, S02, ...) in case both a short and a long filename exist.
            # Preference: short physical filename like "105574_S01.dxf", otherwise the shortest name.
            try:
                import re as _re

                def _sheet_key(fn: str):
                    mm = _re.search(r"(S\d{2})", fn or "")
                    return mm.group(1).upper() if mm else (fn or "").lower()

                def _score(fn: str):
                    low = (fn or "").lower()
                    if _re.match(r"^\d+_s\d{2}\.dxf$", low):
                        return (0, len(fn))
                    return (1, len(fn))

                chosen = {}
                for fn in zaag_files:
                    k = _sheet_key(fn)
                    if k not in chosen or _score(fn) < _score(chosen[k]):
                        chosen[k] = fn
                zaag_files = [chosen[k] for k in sorted(chosen.keys())]
            except Exception as recovery_error:
                report_recovery("metod_app.http.endpoints.admin_jobs.api_admin_jobs.175", recovery_error)

        # Build label context from input.
        customer_name = ""
        try:
            job_json_path = p / "input" / "job.json"
            if job_json_path.exists():
                jj = strict_json_load(job_json_path)
                customer_name = _customer_name_from_job(jj)
                if customer_name == "Onbekend":
                    customer_name = ""
        except Exception as recovery_error:
            report_recovery("metod_app.http.endpoints.admin_jobs.boundary.197", recovery_error)
            customer_name = ""

        try:
            panels_path = p / "input" / "panels.csv"
            if panels_path.exists():
                rows = _parse_panels_csv(panels_path.read_text(encoding="utf-8"))
                if rows:
                    r0 = rows[0]
                    (r0.get("DecorName") or r0.get("decorName") or "").strip()
                    (r0.get("MaterialCode") or r0.get("materialCode") or "").strip()
        except Exception as recovery_error:
            report_recovery("metod_app.http.endpoints.admin_jobs.boundary.208", recovery_error)
            pass

        def _label_for_file(fname: str) -> str:
            return _admin_sheet_download_name(
                p,
                fname,
                customer=customer_name or None,
            )

        zaag = [{"file": f, "label": _label_for_file(f)} for f in zaag_files]

        output_dir / "DXF_Onderdelen"
        parts = []
        if sealed:
            parts = [
                fp.name
                for rel, fp in sorted(sealed.items())
                if rel.startswith("output/DXF_Onderdelen/") and fp.suffix.lower() == ".dxf"
            ]
            seen = set()
            parts = [x for x in parts if (x.lower() not in seen and not seen.add(x.lower()))]

        jobs.append(
            {
                "jobId": job_id,
                "status": meta.get("status", "unknown"),
                "createdAt": meta.get("createdAt", ""),
                "sheets": sheets,
                "zaagplaten": zaag,
                "onderdelen": parts,
                "sealedFiles": [
                    {"rel": rel, "name": fp.name, "kind": _classify_output_kind(fp.name)}
                    for rel, fp in sorted(sealed.items())
                ],
                "edgeBandByDecorMeters": _edge_meters_by_decor(p),
                "customerName": customer_name,
            }
        )
    return self._send_json({"jobs": jobs})


def _classify_output_kind(ports: HttpEndpointsAdminJobsPorts, name: str) -> str:
    n = str(name or "").lower()
    if n.endswith(".dxf"):
        return "dxf"
    if n == "quote.json":
        return "quote"
    if n == "report.json":
        return "report"
    if n == "placements.json":
        return "placements"
    if n == "stickertool.json":
        return "stickertool"
    if n == "calculation_summary.txt":
        return "summary"
    if n == "pricing.json":
        return "pricing"
    return "other"


def _collect_job_output_files(ports: HttpEndpointsAdminJobsPorts, job_id: str) -> list[dict]:
    JOBS = ports.get_jobs()

    _best_material_name = ports.best_material_name
    _classify_output_kind = ports.classify_output_kind
    _job_material_context = ports.job_material_context
    _sealed_output_artifacts = ports.sealed_output_artifacts

    try:
        job_id = validate_job_id(job_id)
        job_root = resolve_identifier_child(JOBS, job_id)
    except SafetyContractError:
        return []
    sealed = _sealed_output_artifacts(job_root)
    if not sealed:
        return []
    ctx = _job_material_context(job_root)
    code = str(ctx.get("materialCode") or "").strip()
    material_name = str(ctx.get("materialName") or (_best_material_name(code, "") if code else "")).strip()
    rows = []
    for rel, fp in sorted(sealed.items()):
        kind = _classify_output_kind(fp.name)
        rows.append(
            {
                "jobId": job_id,
                "materialCode": code,
                "materialName": material_name,
                "name": fp.name,
                "rel": rel,
                "kind": kind,
                "size": fp.stat().st_size if fp.exists() else 0,
                "mtime": datetime.fromtimestamp(fp.stat().st_mtime, tz=timezone.utc)
                .isoformat()
                .replace("+00:00", "Z")
                if fp.exists()
                else "",
            }
        )
    return rows


def _dedupe_admin_dxf_files(ports: HttpEndpointsAdminJobsPorts, files: list[dict]) -> list[dict]:
    """Hide duplicate generic Sheet_001.dxf-style files in Admin when a renamed
    workshop-friendly S01 export exists for the same sheet. Keep generic Sheet files
    only as a fallback when no nicer counterpart is available.
    """
    try:
        import re as _re

        rows = list(files or [])

        def _sheet_key(name: str) -> str:
            n = str(name or "").strip()
            m = _re.search(r"(?:^|[^a-z0-9])s(\d{2})(?:\.dxf)?$", n, _re.I)
            if m:
                return f"S{int(m.group(1)):02d}"
            m = _re.fullmatch(r"sheet[_\- ]?(\d+)(?:\.dxf)?", n, _re.I)
            if m:
                return f"S{int(m.group(1)):02d}"
            return n.lower()

        def _is_generic_sheet(name: str) -> bool:
            return bool(_re.fullmatch(r"sheet[_\- ]?\d+(?:\.dxf)?", str(name or "").strip(), _re.I))

        chosen = {}
        for f in rows:
            name = str((f or {}).get("name") or "")
            key = _sheet_key(name)
            cur = chosen.get(key)
            if cur is None:
                chosen[key] = f
                continue
            cur_generic = _is_generic_sheet(str(cur.get("name") or ""))
            new_generic = _is_generic_sheet(name)
            if cur_generic and not new_generic:
                chosen[key] = f
                continue
            if cur_generic == new_generic:
                # Keep shorter rel/name as a deterministic fallback.
                cur_score = (
                    len(str(cur.get("rel") or cur.get("name") or "")),
                    len(str(cur.get("name") or "")),
                )
                new_score = (len(str(f.get("rel") or f.get("name") or "")), len(name))
                if new_score < cur_score:
                    chosen[key] = f

        # Preserve stable ordering from original rows.
        keep_ids = {id(v) for v in chosen.values()}
        return [f for f in rows if id(f) in keep_ids]
    except Exception as recovery_error:
        report_recovery("metod_app.http.endpoints.admin_jobs.boundary.347", recovery_error)
        return list(files or [])


def _extract_strict_calculation_pricing_summary(
    ports: HttpEndpointsAdminJobsPorts, job_ids: list[str]
) -> dict:
    """Strict authoritative pricing for Tool A status/submit flows.

    Prefer sealed machine-readable amounts; preserved legacy jobs use their TXT.
    Only return pricing when a final calculation summary exists for one of the
    candidate jobs. Never fall back to request payloads, legacy quote totals, or
    interim frontend values. This prevents stale/partial prices from surfacing in
    the first price overlay before the true server calculation is finished.
    """
    JOBS = ports.get_jobs()
    _parse_calculation_summary_totals = ports.parse_calculation_summary_totals

    out = {
        "materialsTotal": None,
        "materialsTotalInclVat": None,
        "materialsVatIncluded": None,
        "otherCostsExVat": None,
        "otherCostsVat": None,
        "edgeBandTotal": None,
        "cncTotal": None,
        "drawingTotal": None,
        "transportTotal": None,
        "subtotalExVat": None,
        "vatAmount": None,
        "totalInclVat": None,
        "currency": "EUR",
        "source": "",
    }
    for jid in job_ids or []:
        if not jid:
            continue
        try:
            jr = JOBS / jid
            calc = read_calculation_pricing(jr, _parse_calculation_summary_totals)
            if isinstance(calc, dict) and (
                calc.get("subtotalExVat") is not None or calc.get("totalInclVat") is not None
            ):
                for k in (
                    "materialsTotal",
                    "materialsTotalInclVat",
                    "materialsVatIncluded",
                    "otherCostsExVat",
                    "otherCostsVat",
                    "edgeBandTotal",
                    "cncTotal",
                    "drawingTotal",
                    "transportTotal",
                    "subtotalExVat",
                    "vatAmount",
                    "totalInclVat",
                ):
                    out[k] = calc.get(k)
                out["source"] = "calculation-summary"
                return out
        except Exception as recovery_error:
            report_recovery(
                "metod_app.http.endpoints.admin_jobs._extract_strict_calculation_pricing_summary.387",
                recovery_error,
            )
    return out


def _find_or_generate_stickertool_file(ports: HttpEndpointsAdminJobsPorts, job_id: str):
    _REQUEST_DOWNLOAD_PROJECTIONS = ports.get_request_download_projections()

    return _REQUEST_DOWNLOAD_PROJECTIONS.find_finalized_stickertool_file(job_id)
