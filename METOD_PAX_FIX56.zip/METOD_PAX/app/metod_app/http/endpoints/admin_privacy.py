"""Authenticated, same-origin customer privacy actions (POST only)."""

from metod_app.admin.privacy import PrivacyConflict


def handle_privacy(handler, service, read_json, actor):
    data = read_json(handler, "ADMIN_JSON_MAX_BYTES", 262144)
    if not isinstance(data, dict):
        return handler._send_json({"ok": False, "error": "Ongeldige privacyactie."}, 400)
    action = data.get("action")
    if action not in {"preview", "export", "export_customer", "export_internal", "delete"}:
        return handler._send_json({"ok": False, "error": "Onbekende privacyactie."}, 400)
    try:
        with service.consistent():
            inventory = service.inventory(data.get("email"))
            if action == "preview":
                return handler._send_json({"ok": True, **service.public_preview(inventory)})
            if data.get("revision") != inventory["revision"]:
                raise PrivacyConflict("Gegevens zijn gewijzigd. Zoek de klant opnieuw voordat je verdergaat.")
            if action == "delete":
                if data.get("confirmation") != "VERWIJDEREN":
                    raise ValueError("Bevestig de definitieve verwijdering met VERWIJDEREN.")
                erasure_id = service.erase(inventory, actor())
                return handler._send_json(
                    {"ok": True, "erasureId": erasure_id, "removedFiles": inventory["fileCount"]}
                )
            internal = action == "export_internal"
            if internal and data.get("internalConfirmation") != "INTERN":
                raise ValueError("Bevestig dat de interne beheerexport niet wordt doorgestuurd.")
            export = (
                service.export_internal(inventory)
                if internal
                else service.export_customer(inventory, data.get("email"))
            )
            filename = "INTERN-niet-doorsturen.zip" if internal else "klantgegevens.zip"
            with export as stream:
                stream.seek(0, 2)
                size = stream.tell()
                stream.seek(0)
                handler.send_response(200)
                handler.send_header("Content-Type", "application/zip")
                handler.send_header("Content-Disposition", f'attachment; filename="{filename}"')
                handler.send_header("Content-Length", str(size))
                handler.send_header("Cache-Control", "no-store")
                handler.end_headers()
                while chunk := stream.read(1024 * 1024):
                    handler.wfile.write(chunk)
    except PrivacyConflict as error:
        return handler._send_json({"ok": False, "error": str(error)}, 409)
    except ValueError as error:
        return handler._send_json({"ok": False, "error": str(error)}, 400)
    except RuntimeError:
        return handler._send_json(
            {"ok": False, "error": "Er loopt nog werk of systeemonderhoud. Probeer het later opnieuw."}, 409
        )
