"""HTTP endpoint adapters for admin requests."""

from __future__ import annotations

from pathlib import Path
from safety_contracts import ContractError as SafetyContractError
from metod_app.config import env_int as _env_int
from metod_app.errors import public_error_message as _public_error_message
from metod_app.identifiers import safe_identifier as _safe_id
from safety_contracts import fsync_directory
import os
from urllib.parse import parse_qs
import secrets
from urllib.parse import urlparse
from safety_contracts import validate_request_id
import zipfile
from metod_app.runtime.ports import HttpEndpointsAdminRequestsPorts


from metod_app.observability.failures import report_recovery

from ...requests.mailbox import MailboxQuery


def _dir_size_bytes(ports: HttpEndpointsAdminRequestsPorts, root: Path) -> int:
    try:
        total = 0
        if not root.exists() or not root.is_dir():
            return 0
        for fp in root.rglob("*"):
            if fp.is_file():
                total += fp.stat().st_size
        return int(total)
    except Exception as recovery_error:
        report_recovery("metod_app.http.endpoints.admin_requests.boundary.34", recovery_error)
        return 0


def _build_request_file_manifest(ports: HttpEndpointsAdminRequestsPorts, request_id: str) -> dict:
    _REQUEST_DOWNLOAD_PROJECTIONS = ports.get_request_download_projections()

    return _REQUEST_DOWNLOAD_PROJECTIONS.build_manifest(request_id)


def api_admin_request_files(ports: HttpEndpointsAdminRequestsPorts, self):
    _build_request_file_manifest = ports.build_request_file_manifest
    _load_status = ports.load_status

    parsed = urlparse(self.path)
    qs = parse_qs(parsed.query or "")
    rid = _safe_id(str((qs.get("requestId") or [""])[0]).strip(), 120)
    if not rid:
        return self._send_json({"ok": False, "error": "Missing requestId"}, 400)
    st = _load_status(rid)
    if not isinstance(st, dict):
        return self._send_json({"ok": False, "error": "Unknown requestId"}, 404)
    manifest = _build_request_file_manifest(rid)
    return self._send_json({"ok": True, "requestId": rid, "files": manifest})


def api_admin_request_file(ports: HttpEndpointsAdminRequestsPorts, self):
    _REQUEST_DOWNLOAD_PROJECTIONS = ports.get_request_download_projections()
    _load_status = ports.load_status

    api_job_file = ports.api_job_file

    parsed = urlparse(self.path)
    qs = parse_qs(parsed.query or "")
    rid = _safe_id(str((qs.get("requestId") or [""])[0]).strip(), 120)
    job_id = _safe_id(str((qs.get("jobId") or [""])[0]).strip(), 200)
    rel = str((qs.get("rel") or [""])[0]).strip()
    if not rid or not job_id or not rel:
        return self._send_text("Missing requestId/jobId/rel", 400)
    st = _load_status(rid)
    if not isinstance(st, dict):
        return self._send_text("Unknown requestId", 404)
    matched = _REQUEST_DOWNLOAD_PROJECTIONS.resolve_linked_file(rid, job_id, rel)
    if matched is None:
        return self._send_text("File not linked to this request", 404)
    return api_job_file(
        self,
        job_id,
        rel,
        download_name_override=str(matched.get("downloadName") or "").strip() or None,
    )


def api_admin_request_download_zip(ports: HttpEndpointsAdminRequestsPorts, self):
    SYSTEM_DIR = ports.get_system_dir()

    _REQUEST_DOWNLOAD_PROJECTIONS = ports.get_request_download_projections()

    _load_status = ports.load_status

    parsed = urlparse(self.path)
    qs = parse_qs(parsed.query or "")
    try:
        rid = validate_request_id(str((qs.get("requestId") or [""])[0]).strip())
    except SafetyContractError:
        return self._send_text("Invalid requestId", 400)
    scope = str((qs.get("scope") or ["all"])[0]).strip().lower()
    if scope not in {"all", "dxf"}:
        return self._send_text("Invalid scope", 400)
    st = _load_status(rid)
    if not isinstance(st, dict):
        return self._send_text("Unknown requestId", 404)
    export_limit = max(1, _env_int("ADMIN_EXPORT_MAX_INPUT_BYTES", 1024 * 1024 * 1024))
    plan = _REQUEST_DOWNLOAD_PROJECTIONS.build_export_plan(rid, scope, export_limit)
    if not plan.ok:
        return self._send_text(plan.message, plan.status)

    export_dir = SYSTEM_DIR / "exports"
    export_dir.mkdir(parents=True, exist_ok=True)
    export_path = export_dir / f".request_export_{rid}_{secrets.token_hex(8)}.zip"
    try:
        with zipfile.ZipFile(export_path, "w", zipfile.ZIP_DEFLATED, allowZip64=True) as zf:
            for source, arcname in plan.selected:
                zf.write(source, arcname)
        with export_path.open("rb") as handle:
            os.fsync(handle.fileno())
        fsync_directory(export_dir)
        if export_path.stat().st_size > export_limit:
            return self._send_text("Compressed export exceeds the configured limit", 413)
        return self._stream_file(
            export_path,
            content_type="application/zip",
            download_name=plan.download_name,
            max_bytes=export_limit,
        )
    finally:
        try:
            export_path.unlink(missing_ok=True)
            fsync_directory(export_dir)
        except Exception as recovery_error:
            report_recovery(
                "metod_app.http.endpoints.admin_requests.api_admin_request_download_zip.132", recovery_error
            )


def api_admin_requests(ports: HttpEndpointsAdminRequestsPorts, self):
    """Admin endpoint: list requests (mailbox)."""
    _REQUEST_DOWNLOAD_PROJECTIONS = ports.get_request_download_projections()

    parsed = urlparse(self.path)
    try:
        qs = parse_qs(parsed.query or "", keep_blank_values=True, max_num_fields=16)
    except ValueError:
        return self._send_json({"ok": False, "error": "Ongeldige inboxfilters."}, 400)
    if "requestId" in qs:
        try:
            if len(qs["requestId"]) != 1:
                raise ValueError("duplicate requestId")
            request_id = validate_request_id(qs["requestId"][0])
        except (ValueError, SafetyContractError):
            return self._send_json({"ok": False, "error": "Ongeldig aanvraagnummer."}, 400)
        status = _REQUEST_DOWNLOAD_PROJECTIONS.get_request(request_id)
        if status is None:
            return self._send_json({"ok": False, "error": "Aanvraag niet gevonden."}, 404)
        return self._send_json({"ok": True, "request": status})
    page_fields = {"page", "pageSize", "q", "category", "sort"}
    if page_fields.intersection(qs):
        try:
            if any(len(qs[key]) != 1 for key in page_fields.intersection(qs)):
                raise ValueError("duplicate page parameter")
            query = MailboxQuery(
                page=int(qs.get("page", ["1"])[0]),
                page_size=int(qs.get("pageSize", ["25"])[0]),
                search=qs.get("q", [""])[0],
                category=qs.get("category", ["inbox"])[0],
                sort=qs.get("sort", ["newest"])[0],
            )
        except ValueError:
            return self._send_json({"ok": False, "error": "Ongeldige inboxfilters."}, 400)
        return self._send_json({"ok": True, **_REQUEST_DOWNLOAD_PROJECTIONS.query_requests(query)})
    try:
        limit = int((qs.get("limit") or ["200"])[0])
    except (ValueError, TypeError, OverflowError):
        limit = 200
    limit = max(1, min(2000, limit))
    rows = _REQUEST_DOWNLOAD_PROJECTIONS.list_requests(limit)
    return self._send_json({"ok": True, "requests": rows})


def api_admin_requests_update(ports: HttpEndpointsAdminRequestsPorts, self):
    """Admin endpoint: update request mailbox status (e.g., mark quote sent)."""

    _append_system_event = ports.append_system_event
    _ensure_request_dirs = ports.ensure_request_dirs
    _mutate_status = ports.mutate_status

    _read_json_body_limited = ports.read_json_body_limited

    _ensure_request_dirs()
    try:
        body = _read_json_body_limited(self, "ADMIN_JSON_MAX_BYTES", 262144)
    except Exception as recovery_error:
        report_recovery("metod_app.http.endpoints.admin_requests.boundary.193", recovery_error)
        return self._send_json({"ok": False, "error": _public_error_message(400)}, 400)

    try:
        rid = validate_request_id(body.get("requestId"))
    except SafetyContractError:
        return self._send_json({"ok": False, "error": "Missing requestId"}, 400)

    action = str(body.get("action") or "").strip().lower()
    if action not in {"mark_quote_sent", "reopen"}:
        return self._send_json({"ok": False, "error": "Unknown action"}, 400)
    decision = {"kind": "unknown", "before": None}

    def _apply(current):
        if not isinstance(current, dict):
            decision["kind"] = "missing"
            return None
        if (
            str(current.get("publicStatus") or "").upper() == "CANCELLED"
            or str(current.get("internalStatus") or "").upper() == "CANCELLED"
        ):
            decision["kind"] = "cancelled"
            return None
        decision["before"] = {
            "publicStatus": current.get("publicStatus"),
            "internalStatus": current.get("internalStatus"),
            "quoteStatus": current.get("quoteStatus"),
        }
        if action == "mark_quote_sent":
            current["quoteStatus"] = "DONE"
            current["needsQuote"] = False
            current["publicStatus"] = "DONE"
            current["publicStatusLabel"] = "Afgehandeld"
            current["internalStatus"] = "DONE"
            current["internalStatusLabel"] = "Afgehandeld"
        else:
            current["quoteStatus"] = "TODO"
            current["needsQuote"] = True
            current["publicStatus"] = "SUBMITTED"
            current["publicStatusLabel"] = "Aanvraag verzonden"
            if str(current.get("internalStatus") or "").upper() in ("PROCESSING", "OFFER_SENT", ""):
                current["internalStatus"] = "QUEUED"
                current["internalStatusLabel"] = "In wachtrij"
        decision["kind"] = "updated"
        return current

    st, changed = _mutate_status(rid, _apply)
    if decision["kind"] == "missing" or not isinstance(st, dict):
        return self._send_json({"ok": False, "error": "Unknown requestId"}, 404)
    if decision["kind"] == "cancelled":
        return self._send_json(
            {"ok": False, "error": "Een geannuleerde aanvraag kan niet impliciet worden heropend."}, 409
        )
    if not changed:
        return self._send_json({"ok": False, "error": "Request status conflict"}, 409)
    before = decision["before"] or {}
    _append_system_event(
        level="info",
        component="admin_request",
        message_user="Aanvraagstatus aangepast",
        message_tech=f"request={rid}; action={action}",
        request_id=rid,
        status="resolved",
        details={
            "actor": self._current_admin_actor() or "unknown-admin",
            "action": action,
            "before": before,
            "after": {
                "publicStatus": st.get("publicStatus"),
                "internalStatus": st.get("internalStatus"),
                "quoteStatus": st.get("quoteStatus"),
            },
        },
    )
    return self._send_json({"ok": True})
