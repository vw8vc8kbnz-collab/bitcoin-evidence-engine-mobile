"""Focused PublicApiRuntimeMixin owner; dependencies resolve through the composition ports."""

from __future__ import annotations
from metod_app.http.endpoints.admin_privacy import handle_privacy

from metod_app.admin.presentation import ADMIN_HTML
from metod_app.admin.presentation import ADMIN_LOGIN_HTML
from typing import Any
from typing import Optional
from pathlib import Path
from safety_contracts import ContractError as SafetyContractError
from metod_app.config import env_int as _env_int
from metod_app.http.matcher import match_route as _match_http_route
from metod_app.errors import public_error_message as _public_error_message
from metod_app.security.redaction import redact_sensitive_text as _redact_sensitive_text
from metod_app.identifiers import safe_identifier as _safe_id
from metod_app.security.redaction import sanitize_log_value as _sanitize_log_value
from metod_app.contracts.submission import validate_submit_payload as _validate_submit_payload
from metod_app.admin.presentation import admin_asset_for_path
from safety_contracts import append_jsonl_rotating
from safety_contracts import durable_write_json
import hashlib
import hmac
from safety_contracts import resolve_identifier_child
from urllib.parse import urlparse
from safety_contracts import validate_job_id
from metod_app.runtime.ports import HttpPublicApiRuntimePorts


from metod_app.observability.failures import report_recovery

import re
from urllib.parse import parse_qs
from metod_app.pricing.authority import canonical_pricing_sha256
from metod_app.pricing.runtime import PricingRevisionConflict
from server_helpers import JsonBodyError


class PublicApiRuntimeMixin:
    _public_api_ports: HttpPublicApiRuntimePorts

    def _require_job_access(
        self, job_id: str, parsed=None, body: Optional[dict] = None, deny_as_json: bool = False
    ) -> bool:
        ports = self._public_api_ports
        JOBS = ports.get_jobs()

        _extract_request_token = ports.extract_request_token
        _read_job_access_token = ports.read_job_access_token

        try:
            job_id = validate_job_id(job_id)
            resolve_identifier_child(JOBS, job_id)
        except SafetyContractError:
            if deny_as_json:
                return self._send_json({"ok": False, "error": "Not found"}, 404)
            return self._send_text("Not found", 404)
        try:
            if self._check_admin_auth_silent():
                return True
        except Exception as recovery_error:
            report_recovery("metod_app.http.public_api_runtime._require_job_access.35", recovery_error)
        expected = _read_job_access_token(job_id)
        supplied = _extract_request_token(self, parsed=parsed, body=body)
        if expected and supplied and hmac.compare_digest(str(supplied), str(expected)):
            return True
        if deny_as_json:
            return self._send_json({"ok": False, "error": "Forbidden"}, 403)
        return self._send_text("Forbidden", 403)

    def do_HEAD(self):
        parsed = urlparse(self.path)
        if (
            parsed.path == "/admin" or parsed.path.startswith(("/admin/", "/api/admin/"))
        ) and not self._transport_ports.get_admin_access().network_allowed(self):
            return self._send_text("Not found", 404)

        route_match = _match_http_route("HEAD", self.path)
        route_key = route_match.key if route_match is not None else None
        admin_asset = admin_asset_for_path(parsed.path)
        if admin_asset is not None and route_key is not None:
            if admin_asset.requires_session and not self._check_admin_auth_silent():
                self.send_response(404)
                self.send_header("Content-Type", "text/plain; charset=utf-8")
                self.end_headers()
                return
            body = admin_asset.body.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", admin_asset.content_type)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            return
        if route_key in ("HEAD /admin", "HEAD /admin/", "HEAD /admin/index.html"):
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            return
        if route_key == "HEAD /api/admin/":
            if not self._require_admin_auth():
                return
            self.send_response(204)
            self.end_headers()
            return
        return super().do_HEAD()

    def do_GET(self):
        ports = self._public_api_ports

        ROOT = ports.get_root()
        _load_pricing_config = ports.load_pricing_config

        _prometheus_metrics = ports.prometheus_metrics
        _readiness_report = ports.readiness_report
        _safe_json = ports.safe_json

        api_admin_control_center = ports.api_admin_control_center
        api_admin_jobs = ports.api_admin_jobs
        api_admin_request_download_zip = ports.api_admin_request_download_zip
        api_admin_request_file = ports.api_admin_request_file
        api_admin_request_files = ports.api_admin_request_files
        api_admin_requests = ports.api_admin_requests
        api_download = ports.api_download
        api_draft_load = ports.api_draft_load
        api_dxf_manifest_meta = ports.api_dxf_manifest_meta
        api_job_file = ports.api_job_file
        api_subjob_file = ports.api_subjob_file

        parsed = urlparse(self.path)
        if (
            parsed.path == "/admin" or parsed.path.startswith(("/admin/", "/api/admin/"))
        ) and not self._transport_ports.get_admin_access().network_allowed(self):
            return self._send_text("Not found", 404)

        route_match = _match_http_route("GET", self.path)
        route_key = route_match.key if route_match is not None else None

        if route_key == "GET /health/live":
            return self._send_json({"ok": True})
        if route_key == "GET /health/ready":
            payload, code = _readiness_report()
            # This route is public for load-balancers. Do not disclose capacity,
            # catalog sign-off identity or internal check names here.
            return self._send_json({"ok": bool(payload.get("ok"))}, code)

        if route_key in ("GET /", "GET /toolA.html"):
            try:
                return self._send_text(
                    (ROOT / "toolA.html").read_text(encoding="utf-8"), 200, "text/html; charset=utf-8"
                )
            except Exception as recovery_error:
                report_recovery("metod_app.http.public_api_runtime.boundary.143", recovery_error)
                return self._send_text("Tool A kon niet worden geladen", 500)

        # Public SSE stream used by Tool A to refresh embedded DXF catalog live.
        if route_key == "GET /api/events":
            return self._send_json(
                {"ok": False, "error": "Live stream vervangen door verversen bij terugkeer."}, 410
            )

        if route_key == "GET /api/jobs/reconcile":
            # The idempotency key is a capability: unlike normal public GETs,
            # reconciliation is available only to the exact configured Tool A
            # origin (or local development loopback under the existing policy).
            if not self._require_same_origin_public_write():
                return
            return self._api_reconcile_job_create()

        admin_asset = admin_asset_for_path(parsed.path)
        if admin_asset is not None and route_key is not None:
            if admin_asset.requires_session and not self._check_admin_auth_silent():
                return self._send_text("Not found", 404)
            return self._send_text(admin_asset.body, 200, admin_asset.content_type)

        # Serve the Admin shell itself without browser Basic Auth.
        # The admin data/actions under /api/admin/* remain protected and the
        # Admin shell adds Authorization headers from its own login overlay.
        # This avoids iOS Safari offering /admin as a download on 401 responses.
        if parsed.path.startswith("/api/admin/"):
            if not self._require_admin_auth():
                return

        if route_key == "GET /api/admin/health/ready":
            payload, code = _readiness_report()
            return self._send_json(payload, code)

        # clean admin login rebuild.
        # /admin/ is never Basic-Auth challenged. If no valid session cookie/basic auth is
        # present, serve a standalone login page. After /api/admin/login sets the HttpOnly
        # session cookie, serve the real Admin HTML.
        if route_key in ("GET /admin", "GET /admin/", "GET /admin/index.html"):
            if self._check_admin_auth_silent():
                return self._send_text(ADMIN_HTML, 200, "text/html; charset=utf-8")
            return self._send_text(ADMIN_LOGIN_HTML, 200, "text/html; charset=utf-8")

        if route_key == "GET /favicon.ico":
            # Avoid noisy 404s in the browser console.
            self.send_response(204)
            self.end_headers()
            return

        if route_key == "GET /.well-known/appspecific/com.chrome.devtools.json":
            # Chrome DevTools sometimes probes this path; respond without crashing.
            self.send_response(204)
            self.end_headers()
            return

        if route_key == "GET /api/draft/load":
            return api_draft_load(self, parsed)

        if route_key == "GET /api/dxf_manifest_meta":
            return api_dxf_manifest_meta(self, parsed)

        if route_key == "GET /api/admin/jobs":
            return api_admin_jobs(self)

        if route_key == "GET /api/admin/metrics":
            return self._send_text(_prometheus_metrics(), 200, "text/plain; version=0.0.4; charset=utf-8")

        if route_key == "GET /api/admin/requests":
            return api_admin_requests(self)
        if route_key == "GET /api/admin/request_files":
            return api_admin_request_files(self)
        if route_key == "GET /api/admin/request_file":
            return api_admin_request_file(self)
        if route_key == "GET /api/admin/request_download_zip":
            return api_admin_request_download_zip(self)
        if route_key == "GET /api/admin/requests/update":
            # State changes are POST-only so the existing same-origin write gate
            # cannot be bypassed through a link, prefetch or cross-site GET.
            return self._send_json({"ok": False, "error": "Method not allowed"}, 405)

        if route_key == "GET /api/admin/control_center":
            return api_admin_control_center(self)

        if route_key == "GET /api/admin/dxf/categories":
            return self._api_admin_dxf_categories()

        if route_key == "GET /api/admin/dxf/list":
            return self._api_admin_dxf_list(parsed)

        if route_key == "GET /api/admin/materials/library":
            return self._api_admin_materials_library()
        if route_key == "GET /api/admin/materials/filters":
            return self._api_admin_material_filters()
        if route_key == "GET /api/admin/materials/catalog_status":
            return self._api_admin_catalog_status(parsed)

        if route_key == "GET /api/materials/library":
            return self._api_public_materials_library()

        if route_key == "GET /api/materials/image/{publicId}/{variant}":
            return self._api_public_material_image(
                route_match.parameter("publicId"), route_match.parameter("variant")
            )
        if parsed.path.startswith("/api/materials/image/"):
            return self._send_text("Not found", 404)

        if route_key == "GET /api/admin/system/logs":
            return self._api_admin_system_logs()

        if route_key == "GET /api/admin/system/backups":
            return self._api_admin_system_backups()
        if route_key == "GET /api/admin/system/backup_download":
            return self._api_admin_system_backup_download(parsed)

        if route_key == "GET /api/admin/pricing":
            cfg = _load_pricing_config()
            revision = '"' + canonical_pricing_sha256(cfg) + '"'
            # Preserve the raw-config API for existing callers. The editor uses
            # an explicit envelope so its concurrency token survives proxies.
            editor = parse_qs(parsed.query).get("view") == ["editor"]
            body, code = _safe_json({"config": cfg, "revision": revision} if editor else cfg, 200)
            self.send_response(code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("ETag", revision)
            self.end_headers()
            self.wfile.write(body)
            return

        # Deprecated: unauthenticated StickerTool v2 direct route. Admin obtains
        # the single sealed output/stickertool.json through the file manifest.
        if route_key == "GET /api/stickertool_v2/":
            return self._send_text("Deprecated. Use the authenticated Admin output manifest.", 410)

        if route_key == "GET /api/jobs/{jobId}/download/{filename}":
            return api_download(
                self, route_match.parameter("jobId"), route_match.parameter("filename"), parsed
            )

        # Subjob file serving (Stickertool v2 contract)
        # /api/jobs/<jobId>/subjobs/<subjobId>/file/<relpath>
        if route_key == "GET /api/jobs/{jobId}/subjobs/{subjobId}/file/{relativePath}":
            return api_subjob_file(
                self,
                route_match.parameter("jobId"),
                route_match.parameter("subjobId"),
                route_match.parameter("relativePath"),
                parsed,
            )

        if route_key == "GET /api/jobs/{jobId}/file/{relativePath}":
            return api_job_file(
                self, route_match.parameter("jobId"), route_match.parameter("relativePath"), parsed
            )

        if route_key == "GET /api/jobs/{jobId}/status":
            return self._api_status(route_match.parameter("jobId"), parsed)

        return super().do_GET()

    def do_POST(self):
        ports = self._public_api_ports
        _STATE_MAINTENANCE_BARRIER = ports.get_state_maintenance_barrier()

        route_match = _match_http_route("POST", self.path)
        route_key = route_match.key if route_match is not None else ""
        if route_key in ("POST /api/admin/system/backup_now", "POST /api/admin/privacy"):
            try:
                return self._do_POST_impl(route_key)
            except JsonBodyError:
                return self._send_json({"ok": False, "error": "Ongeldig JSON-verzoek."}, 400)
        if not _STATE_MAINTENANCE_BARRIER.begin_mutation():
            return self._send_json(
                {"ok": False, "error": "Systeemonderhoud actief; probeer het zo opnieuw."}, 503
            )
        try:
            return self._do_POST_impl(route_key)
        except JsonBodyError as error:
            too_large = str(error).startswith("JOB_PAYLOAD_TOO_LARGE::")
            self.close_connection = True
            return self._send_json(
                {
                    "ok": False,
                    "code": "PAYLOAD_TOO_LARGE" if too_large else "INVALID_JSON_BODY",
                    "error": "De aanvraag is te groot."
                    if too_large
                    else "Ongeldige aanvraag: verwacht een geldig JSON-object.",
                },
                413 if too_large else 400,
            )
        finally:
            _STATE_MAINTENANCE_BARRIER.end_mutation()

    def _do_POST_impl(self, route_key=None):
        ports = self._public_api_ports
        _append_system_event = ports.append_system_event

        _read_json_body_limited = ports.read_json_body_limited
        _safe_json = ports.safe_json
        _save_pricing_config = ports.save_pricing_config
        api_admin_requests_update = ports.api_admin_requests_update
        api_draft_save = ports.api_draft_save

        parsed = urlparse(self.path)
        if route_key is None:
            route_match = _match_http_route("POST", self.path)
            route_key = route_match.key if route_match is not None else ""

        if route_key == "POST /api/admin/login":
            if not self._require_admin_write_origin():
                return
            return self._api_admin_login()

        if parsed.path in ("/admin", "/admin/") or parsed.path.startswith("/api/admin/"):
            if not self._require_admin_auth():
                return
            if parsed.path.startswith("/api/admin/") and not self._require_admin_write_origin():
                return

        if route_key == "POST /api/admin/privacy":
            return handle_privacy(
                self,
                ports.get_privacy_service(),
                _read_json_body_limited,
                lambda: self._transport_ports.get_admin_access().current_actor(self),
            )

        if route_key == "POST /api/admin/logout":
            return self._api_admin_logout()

        if route_key == "POST /api/admin/materials/catalog_preview":
            return self._api_admin_catalog_preview()
        if route_key == "POST /api/admin/materials/catalog_publish":
            return self._api_admin_catalog_publish()
        if route_key == "POST /api/admin/materials/catalog_taxonomy_override":
            return self._api_admin_catalog_taxonomy_override()
        if route_key == "POST /api/admin/materials/live_taxonomy_family":
            return self._api_admin_live_taxonomy_family()
        if route_key == "POST /api/admin/materials/filters":
            return self._api_admin_material_filters()
        if route_key == "POST /api/admin/materials/catalog_retry_images":
            return self._api_admin_catalog_retry_images()

        if route_key == "POST /api/admin/materials/upload":
            return self._api_admin_materials_upload()

        if route_key == "POST /api/admin/materials/save_item":
            return self._api_admin_materials_save_item()

        if route_key == "POST /api/admin/materials/delete_item":
            return self._api_admin_materials_delete_item()

        if route_key == "POST /api/admin/materials/image_upload":
            return self._api_admin_material_image_upload()

        if route_key == "POST /api/admin/materials/image_delete":
            return self._api_admin_material_image_delete()

        if route_key == "POST /api/admin/system/backup_now":
            return self._api_admin_system_backup_now()

        if route_key == "POST /api/admin/dxf/create_category":
            return self._api_admin_dxf_create_category()

        if route_key == "POST /api/admin/dxf/upload":
            return self._api_admin_dxf_upload()

        if route_key == "POST /api/admin/dxf/delete":
            return self._api_admin_dxf_delete()

        if route_key == "POST /api/admin/requests/update":
            return api_admin_requests_update(self)

        if route_key in (
            "POST /api/submit_config",
            "POST /api/cancel",
            "POST /api/jobs/cancel",
            "POST /api/jobs",
            "POST /api/draft/save",
            "POST /api/client_log",
        ):
            if not self._require_same_origin_public_write():
                return

        if route_key == "POST /api/submit_config":
            try:
                return self._api_submit_config()
            except Exception as e:
                report_recovery("metod_app.http.public_api_runtime.boundary.418", e)
                _append_system_event(
                    level="error",
                    component="toola",
                    message_user="Aanvraag verwerken is mislukt",
                    message_tech=str(e),
                    status="open",
                )
                return self._send_json({"ok": False, "error": _public_error_message(500)}, 500)
        if route_key == "POST /api/cancel":
            return self._api_cancel_request()

        if route_key == "POST /api/client_log":
            return self._api_client_log(parsed=parsed)
        if route_key == "POST /api/send_to_odoo":
            if not self._require_admin_auth():
                return
            if not self._require_admin_write_origin():
                return
            return self._api_send_to_odoo()
        if route_key == "POST /api/jobs/cancel":
            return self._api_cancel_job(parsed=parsed)
        if route_key == "POST /api/jobs":
            return self._api_create_job()

        if route_key == "POST /api/draft/save":
            return api_draft_save(self)

        if route_key == "POST /api/admin/pricing":
            try:
                data = _read_json_body_limited(self, "ADMIN_JSON_MAX_BYTES", 262144)
                actor = self._current_admin_actor() or "unknown-admin"
                revision = self.headers.get("If-Match")
                if "config" in data or "revision" in data:
                    if set(data) != {"config", "revision"} or not isinstance(data.get("config"), dict):
                        raise ValueError("Onvolledig prijsdocument. Herlaad de actuele instellingen.")
                    token = data.get("revision")
                    if not isinstance(token, str) or not re.fullmatch(r'"[a-f0-9]{64}"', token):
                        raise ValueError("Ongeldige prijsrevisie. Herlaad de actuele instellingen.")
                    if revision is not None and revision != token:
                        raise ValueError("Tegenstrijdige prijsrevisies. Herlaad de actuele instellingen.")
                    revision, data = token, data["config"]
                res = _save_pricing_config(data, actor=actor, expected_revision=revision)
                _append_system_event(
                    level="info",
                    component="pricing",
                    message_user="Prijsinstellingen opgeslagen",
                    message_tech=f"Saved pricing config by {actor}",
                    status="resolved",
                    details={"actor": actor, "version": res.get("version")},
                )
                body, code = _safe_json(res, 200)
            except PricingRevisionConflict as error:
                body, code = _safe_json(
                    {"ok": False, "code": "PRICING_REVISION_CONFLICT", "error": str(error)}, 409
                )
            except Exception as e:
                report_recovery("metod_app.http.public_api_runtime.boundary.459", e)
                _append_system_event(
                    level="error",
                    component="pricing",
                    message_user="Prijsinstellingen konden niet worden opgeslagen",
                    message_tech=str(e),
                    status="open",
                )
                body, code = _safe_json({"ok": False, "error": str(e)}, 400)
            self.send_response(code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        return self._send_text("Not found", 404)

    def _api_send_to_odoo(self):
        """Store a payload for later Odoo integration.

        This route is admin-only and should never be exposed as a public write
        surface. It persists a bounded JSON payload inside the target job.
        """
        ports = self._public_api_ports
        JOBS = ports.get_jobs()

        _append_system_event = ports.append_system_event
        _finalization_complete = ports.finalization_complete
        _read_json_body_limited = ports.read_json_body_limited
        _utc_now_iso = ports.utc_now_iso

        try:
            payload = _read_json_body_limited(self, "ADMIN_JSON_MAX_BYTES", 262144)
        except Exception as recovery_error:
            report_recovery("metod_app.http.public_api_runtime.boundary.487", recovery_error)
            return self._send_json({"ok": False, "error": "Invalid JSON"}, 400)

        try:
            job_id = validate_job_id(payload.get("jobId"))
            job_root = resolve_identifier_child(JOBS, job_id)
            if not job_root.is_dir() or not _finalization_complete(job_root):
                return self._send_json({"ok": False, "error": "Job is niet definitief afgerond"}, 409)
            durable_write_json(
                job_root / "output" / "odoo_payload.json",
                {
                    "schemaVersion": 1,
                    "jobId": job_id,
                    "state": "STAGED_NOT_SENT",
                    "createdAt": _utc_now_iso(),
                    "actor": self._current_admin_actor() or "unknown-admin",
                    "payload": {key: value for key, value in payload.items() if key != "jobId"},
                },
            )
        except SafetyContractError:
            return self._send_json({"ok": False, "error": "Ongeldige jobId"}, 400)
        except Exception as exc:
            report_recovery("metod_app.http.public_api_runtime.boundary.505", exc)
            _append_system_event(
                level="error",
                component="odoo",
                message_user="Odoo-export kon niet worden klaargezet",
                message_tech=str(exc),
                status="open",
            )
            return self._send_json({"ok": False, "error": "Failed to store payload"}, 500)

        return self._send_json({"ok": True, "stored": True, "jobId": job_id})

    def _api_submit_config(self):
        """Finalize a customer submission by linking an already-finalized Tool A job.

        invariant: /api/jobs is the only route that performs optimization. Submit
        never nests again. It requires the parent job bearer token, verifies finalization,
        links server-derived subjobs, and is idempotent per parent job.
        """
        ports = self._public_api_ports
        JOBS = ports.get_jobs()

        _SUBMISSION_SERVICE = ports.get_submission_service()
        _client_ip = ports.client_ip
        _ensure_request_dirs = ports.ensure_request_dirs
        _finalization_complete = ports.finalization_complete
        _is_production_runtime = ports.is_production_runtime
        _job_cancel_requested = ports.job_cancel_requested
        _load_job_runtime_state = ports.load_job_runtime_state
        _public_job_family_complete = ports.public_job_family_complete

        _rate_limit_allow = ports.rate_limit_allow
        _read_json_body_limited = ports.read_json_body_limited

        _ensure_request_dirs()
        ip = _client_ip(self)
        if not _rate_limit_allow("submit_config", ip, 30, 300):
            return self._send_json(
                {"ok": False, "error": "Te veel verzoeken. Probeer het later opnieuw."}, 429
            )
        try:
            # Size limit (basic anti-abuse). Default 1 MB.
            payload = _read_json_body_limited(
                self, "SUBMIT_MAX_BYTES", 8388608 if _is_production_runtime() else 16777216
            )
            if not isinstance(payload, dict) or not payload:
                return self._send_json({"ok": False, "error": "Lege aanvraagpayload."}, 400)
        except Exception as recovery_error:
            report_recovery("metod_app.http.public_api_runtime.boundary.546", recovery_error)
            return self._send_json({"ok": False, "error": _public_error_message(400)}, 400)

        ok_payload, payload_errors, cleaned_payload = _validate_submit_payload(payload)
        if not ok_payload:
            return self._send_json({"ok": False, "error": "Validatie mislukt"}, 400)
        # Build a new request DTO. Browser quote/pricing/material summaries and unknown
        # nested checkout fields are deliberately not persisted or trusted.
        payload = {
            key: cleaned_payload[key]
            for key in ("jobId", "parentJobId", "customer", "note")
            if key in cleaned_payload
        }

        # A final submission MUST refer to the already-calculated parent job. Never accept
        # a bare cart here, because that would recreate the historical duplicate optimization.
        parent_job_id = str(payload.get("parentJobId") or payload.get("jobId") or "").strip()
        quote_for_link = payload.get("quote") if isinstance(payload.get("quote"), dict) else {}
        if not parent_job_id and isinstance(quote_for_link, dict):
            parent_job_id = str(
                quote_for_link.get("parentJobId") or quote_for_link.get("jobId") or ""
            ).strip()
        parent_job_id = _safe_id(parent_job_id, 200) if parent_job_id else ""
        if not parent_job_id:
            return self._send_json(
                {"ok": False, "error": "Bereken de prijs opnieuw voordat je de aanvraag verstuurt."}, 409
            )
        try:
            parent_root = resolve_identifier_child(JOBS, validate_job_id(parent_job_id))
        except SafetyContractError:
            return self._send_json(
                {"ok": False, "error": "Bereken de prijs opnieuw voordat je de aanvraag verstuurt."}, 409
            )
        if not parent_root.exists():
            return self._send_json(
                {
                    "ok": False,
                    "error": "De berekening is nog niet volledig afgerond. Bereken opnieuw en verstuur daarna de aanvraag.",
                },
                409,
            )
        if not self._require_job_access(parent_job_id, deny_as_json=True):
            return
        durable_state = str((_load_job_runtime_state(parent_job_id) or {}).get("state") or "").upper()
        if durable_state != "DONE":
            message = (
                "Deze berekening is geannuleerd. Bereken opnieuw."
                if durable_state in {"CANCEL_REQUESTED", "CANCELLED"}
                else "De berekening is nog niet volledig afgerond. Bereken opnieuw en verstuur daarna de aanvraag."
            )
            return self._send_json({"ok": False, "error": message}, 409)
        if not _public_job_family_complete(parent_job_id, memo={}):
            return self._send_json(
                {
                    "ok": False,
                    "error": "De productie-output kon niet opnieuw worden geverifieerd. Bereken opnieuw.",
                },
                409,
            )
        if _job_cancel_requested(parent_job_id):
            return self._send_json(
                {"ok": False, "error": "Deze berekening is geannuleerd. Bereken opnieuw."}, 409
            )

        # The authenticated durable transaction is owned outside HTTP. It still
        # preserves the exact claim -> payload -> status -> notify/SSE order and
        # retains the submit-config-link state contract.
        outcome = _SUBMISSION_SERVICE.finalize(parent_job_id, parent_root, payload)
        if outcome.kind == "customer_changed":
            return self._send_json(
                {
                    "ok": False,
                    "code": "CUSTOMER_SNAPSHOT_CHANGED",
                    "error": "Je gegevens zijn gewijzigd sinds de berekening. Ga terug naar Gegevens en bereken opnieuw voordat je verstuurt.",
                },
                409,
            )
        if outcome.kind == "invalid_customer":
            message = str(outcome.response.get("error") or "Klantgegevens zijn onvolledig.").strip()
            return self._send_json({"ok": False, "error": message}, 400)
        if outcome.kind == "missing_email":
            return self._send_json(
                {"ok": False, "error": "E-mailadres ontbreekt. Ga terug naar Gegevens en bereken opnieuw."},
                400,
            )
        if outcome.kind == "invalid_email":
            return self._send_json({"ok": False, "error": "E-mailadres is ongeldig."}, 400)
        if outcome.kind == "incomplete_output":
            return self._send_json(
                {
                    "ok": False,
                    "error": "De productie-output kon niet opnieuw worden geverifieerd. Bereken opnieuw.",
                },
                409,
            )
        if outcome.kind == "missing_price":
            return self._send_json(
                {
                    "ok": False,
                    "error": "De definitieve serverprijs ontbreekt. Bereken de prijs opnieuw voordat je verstuurt.",
                },
                409,
            )
        if outcome.kind == "in_progress":
            return self._send_json(
                {
                    "ok": False,
                    "error": "Deze aanvraag wordt al verwerkt. Gebruik de bestaande aanvraag in plaats van opnieuw te versturen.",
                },
                409,
            )
        return self._send_json(outcome.response)

    def _api_cancel_request(self):
        """Public endpoint: mark a request as cancelled by the customer."""
        ports = self._public_api_ports
        _client_ip = ports.client_ip
        _ensure_request_dirs = ports.ensure_request_dirs
        _mutate_status = ports.mutate_status

        _rate_limit_allow = ports.rate_limit_allow
        _read_json_body_limited = ports.read_json_body_limited

        _utc_now_iso = ports.utc_now_iso

        _ensure_request_dirs()
        try:
            payload = _read_json_body_limited(self, "CLIENT_LOG_MAX_BYTES", 65536)
        except Exception as recovery_error:
            report_recovery("metod_app.http.public_api_runtime.boundary.626", recovery_error)
            return self._send_json({"ok": False, "error": _public_error_message(400)}, 400)

        ip = _client_ip(self)
        if not _rate_limit_allow("public_cancel_request", ip, 10, 60):
            return self._send_json({"ok": False, "error": "Too many requests"}, 429)

        request_id = str(payload.get("requestId") or "").strip()
        if not request_id:
            return self._send_json({"ok": False, "error": "Missing requestId"}, 400)
        request_id = _safe_id(request_id, 120)

        supplied_cancel_token = str(payload.get("cancelToken") or payload.get("token") or "").strip()
        if not supplied_cancel_token:
            return self._send_json({"ok": False, "error": "Forbidden"}, 403)

        supplied_token_sha256 = hashlib.sha256(supplied_cancel_token.encode("utf-8")).hexdigest()
        decision = {"kind": "unknown"}

        def cancel_mutator(status):
            if not isinstance(status, dict):
                decision["kind"] = "unknown"
                return None

            control = (
                dict(status.get("cancelControl")) if isinstance(status.get("cancelControl"), dict) else {}
            )
            expected_token = str(control.get("cancelToken") or "").strip()
            consumed_sha256 = str(control.get("consumedCancelTokenSha256") or "").strip().lower()

            if consumed_sha256:
                if hmac.compare_digest(supplied_token_sha256, consumed_sha256):
                    decision["kind"] = "idempotent"
                else:
                    decision["kind"] = "forbidden"
                return None

            if not expected_token or not hmac.compare_digest(supplied_cancel_token, expected_token):
                decision["kind"] = "forbidden"
                return None

            cancelled_at = _utc_now_iso()
            status["publicStatus"] = "CANCELLED"
            status["publicStatusLabel"] = "Geannuleerd door klant"
            status["needsQuote"] = False
            status["quoteStatus"] = "CANCELLED"
            if status.get("internalStatus") in ("QUEUED", "RECEIVED", None, ""):
                status["internalStatus"] = "CANCELLED"
                status["internalStatusLabel"] = "Geannuleerd"
            status["cancel"] = {
                "cancelledAt": cancelled_at,
                "cancelReason": str(payload.get("reason") or "USER_CANCELLED"),
                "context": str(payload.get("context") or "PRICE_OVERLAY"),
            }
            control.pop("cancelToken", None)
            control["consumedCancelTokenSha256"] = supplied_token_sha256
            control["cancelledAt"] = cancelled_at
            status["cancelControl"] = control
            decision["kind"] = "transitioned"
            return status

        _status, changed = _mutate_status(request_id, cancel_mutator)
        kind = decision["kind"]
        if kind == "unknown":
            return self._send_json({"ok": False, "error": "Unknown requestId"}, 404)
        if kind == "forbidden":
            return self._send_json({"ok": False, "error": "Forbidden"}, 403)
        if kind == "transitioned" and changed:
            return self._send_json(
                {
                    "ok": True,
                    "requestId": request_id,
                    "cancelled": True,
                    "idempotent": False,
                }
            )
        if kind == "idempotent":
            return self._send_json(
                {
                    "ok": True,
                    "requestId": request_id,
                    "cancelled": True,
                    "idempotent": True,
                }
            )
        return self._send_json({"ok": False, "error": "Conflict"}, 409)

    def _api_cancel_job(self, parsed=None):
        ports = self._public_api_ports
        _JOB_LIFECYCLE = ports.get_job_lifecycle()

        return _JOB_LIFECYCLE.api_cancel_job(self, parsed=parsed)

    def _api_reconcile_job_create(self):
        """Resolve one durable create attempt without resending customer data."""
        ports = self._public_api_ports
        _client_ip = ports.client_ip
        _lookup_public_job_idempotency = ports.lookup_public_job_idempotency
        _rate_limit_allow = ports.rate_limit_allow

        ip = _client_ip(self)
        if not _rate_limit_allow("api_jobs_reconcile", ip, 30, 300):
            return self._send_json(
                {
                    "ok": False,
                    "error": "Te veel controleverzoeken. Probeer het later opnieuw.",
                },
                429,
            )
        key = str(self.headers.get("Idempotency-Key") or self.headers.get("X-Idempotency-Key") or "").strip()
        try:
            claim = _lookup_public_job_idempotency(key=key)
        except ValueError:
            return self._send_json(
                {
                    "ok": False,
                    "error": "De veilige aanvraag-ID is ongeldig.",
                },
                400,
            )
        except Exception as recovery_error:
            # An unreadable authority is uncertainty, never absence. Keeping the
            # browser key prevents a second charge/run after storage recovers.
            report_recovery("metod_app.http.public_api_runtime.boundary.748", recovery_error)
            return self._send_json(
                {
                    "ok": False,
                    "error": "De eerdere jobaanvraag kan nog niet veilig worden gecontroleerd.",
                    "retryable": True,
                },
                425,
            )
        if claim is None:
            return self._send_json(
                {
                    "ok": False,
                    "error": "Geen eerdere jobaanvraag gevonden.",
                },
                404,
            )
        if claim.kind == "replay" and isinstance(claim.response, dict):
            return self._send_json(dict(claim.response), 202)
        return self._send_json(
            {
                "ok": False,
                "error": "De oorspronkelijke jobaanvraag wordt nog verwerkt.",
                "retryable": True,
            },
            425,
        )

    def _send_text(self, text: str, code: int = 200, ctype: str = "text/plain; charset=utf-8"):
        ports = self._public_api_ports
        _STATIC_HTTP = ports.get_static_http()

        return _STATIC_HTTP.send_text(self, text, code, ctype)

    def _send_json(self, obj, code: int = 200):
        ports = self._public_api_ports
        _STATIC_HTTP = ports.get_static_http()

        return _STATIC_HTTP.send_json(self, obj, code)

    def _stream_file(self, path: Path, *, content_type: str, download_name: str, max_bytes: int) -> None:
        ports = self._public_api_ports

        _STATIC_HTTP = ports.get_static_http()

        return _STATIC_HTTP.stream_file(
            self, path, content_type=content_type, download_name=download_name, max_bytes=max_bytes
        )

    def _api_client_log(self, parsed=None):
        """Receive bounded client-side debug logs.

        Security policy:
        - same-origin / loopback only
        - small payloads only
        - rate-limited per client IP
        - best-effort logging with generic failures
        """
        ports = self._public_api_ports
        JOBS = ports.get_jobs()
        STATE_ROOT = ports.get_state_root()

        _client_ip = ports.client_ip

        _extract_request_token = ports.extract_request_token
        _now_iso = ports.now_iso
        _rate_limit_allow = ports.rate_limit_allow
        _read_job_access_token = ports.read_job_access_token
        _read_json_body_limited = ports.read_json_body_limited

        if not self._require_same_origin_public_write():
            return
        ip = _client_ip(self)
        if not _rate_limit_allow("client_log", ip, 120, 300):
            return self._send_json(
                {"ok": False, "error": "Te veel verzoeken. Probeer het later opnieuw."}, 429
            )
        try:
            payload = _read_json_body_limited(self, "CLIENT_LOG_MAX_BYTES", 16384)
        except Exception as recovery_error:
            report_recovery("metod_app.http.public_api_runtime.boundary.818", recovery_error)
            return self._send_json({"ok": False, "error": "Invalid JSON"}, 400)

        try:
            job_id = str(payload.get("jobId") or "").strip()
            if job_id:
                try:
                    job_id = validate_job_id(job_id)
                    job_root = resolve_identifier_child(JOBS, job_id)
                except SafetyContractError:
                    return self._send_json({"ok": False, "error": "Ongeldige job."}, 400)
                supplied = _extract_request_token(self, parsed=parsed, body=payload)
                expected = _read_job_access_token(job_id)
                is_admin = self._check_admin_auth_silent()
                if not is_admin and not (expected and supplied and hmac.compare_digest(expected, supplied)):
                    return self._send_json({"ok": False, "error": "Geen toegang tot deze job."}, 403)
                if not job_root.is_dir():
                    return self._send_json({"ok": False, "error": "Job niet gevonden."}, 404)
            level = payload.get("level")
            if not isinstance(level, str) or level.lower() not in {
                "debug",
                "info",
                "warn",
                "warning",
                "error",
            }:
                level = "info"
            event = payload.get("event")
            if not isinstance(event, str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_.:-]{0,119}", event):
                event = "client.diagnostic"
            rec = {
                "level": level.lower(),
                "event": event,
                "message": _redact_sensitive_text(payload.get("message") or "", 400),
                "url": _redact_sensitive_text(
                    str(payload.get("url") or "").split("#", 1)[0].split("?", 1)[0], 300
                ),
                "ua": "",
                "data": _sanitize_log_value(payload.get("data"), max_depth=1, max_items=10),
            }
            rec = _sanitize_log_value(rec, max_depth=3, max_items=10)
            # Time of receipt belongs to the server. Arbitrary client values
            # (including objects or arrays) cannot become log timestamp fields.
            rec["ts"] = _now_iso()
            if job_id:
                path = job_root / "client_log.jsonl"
            else:
                path = STATE_ROOT / "client_logs" / "general_client_log.jsonl"
            append_jsonl_rotating(
                path,
                rec,
                max_bytes=max(1024, _env_int("CLIENT_LOG_QUOTA_BYTES", 10 * 1024 * 1024)),
                backups=3,
            )
            return self._send_json({"ok": True})
        except Exception as recovery_error:
            report_recovery("metod_app.http.public_api_runtime.boundary.860", recovery_error)
            return self._send_json({"ok": False, "error": "Log write failed"}, 500)

    def _estimate_job_complexity(self, payload: dict) -> dict:
        ports = self._public_api_ports
        _JOB_LIFECYCLE = ports.get_job_lifecycle()

        return _JOB_LIFECYCLE.estimate_job_complexity(self, payload)

    def _start_async_job_create(
        self, payload: dict, master_job_id: str, public_access_token: str = "", acquired_ip: str = ""
    ) -> dict[str, Any]:
        ports = self._public_api_ports

        _JOB_LIFECYCLE = ports.get_job_lifecycle()

        return _JOB_LIFECYCLE.start_async_job_create(
            self, payload, master_job_id, public_access_token, acquired_ip
        )

    def _write_api_jobs_crashlog(
        self, label: str, payload: dict | None = None, err: Exception | None = None, extra: dict | None = None
    ) -> None:
        ports = self._public_api_ports
        _JOB_LIFECYCLE = ports.get_job_lifecycle()

        return _JOB_LIFECYCLE.write_api_jobs_crashlog(self, label, payload, err, extra)

    def _api_create_job(self):
        ports = self._public_api_ports
        _JOB_LIFECYCLE = ports.get_job_lifecycle()

        return _JOB_LIFECYCLE.api_create_job(self)

    def _api_status(self, job_id: str, parsed=None):
        ports = self._public_api_ports
        _JOB_LIFECYCLE = ports.get_job_lifecycle()

        return _JOB_LIFECYCLE.api_status(self, job_id, parsed=parsed)
