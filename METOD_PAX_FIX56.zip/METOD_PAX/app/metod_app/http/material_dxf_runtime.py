"""DXF category and filename boundary used by the material-catalog ports."""

from __future__ import annotations

from pathlib import Path
import re
from metod_app.runtime.ports import HttpMaterialDxfRuntimePorts


class MaterialDxfRuntimeMixin:
    _material_dxf_ports: HttpMaterialDxfRuntimePorts

    def _dxf_root(self) -> Path:
        ports = self._material_dxf_ports
        DXF_LIBRARY_ROOT = ports.get_dxf_library_root()

        return DXF_LIBRARY_ROOT

    def _sanitize_category(self, cat: str):
        if not isinstance(cat, str):
            return None
        cat = cat.strip()
        if not cat:
            return None
        # Keep legacy behavior: allow "(root)" to point to the base folder.
        if cat == "(root)":
            return cat
        # Prevent path traversal / separators.
        if "/" in cat or "\\" in cat or ".." in cat:
            return None
        # Allow categories with spaces (labels must match Tool A).
        if len(cat) > 60:
            return None
        if not re.fullmatch(r"[\w \-]{1,60}", cat, flags=re.UNICODE):
            return None
        return cat

    def _sanitize_filename(self, name: str):
        if not isinstance(name, str):
            return None
        name = name.strip()
        if not name:
            return None
        if "/" in name or "\\" in name or ".." in name:
            return None
        if not name.lower().endswith(".dxf"):
            return None
        # A hash is a normal DXF filename character (e.g. #SHEET_002.dxf).
        # The HTTP client percent-encodes the complete relative filename.
        if name.startswith("."):
            return None
        if not re.fullmatch(r"[A-Za-z0-9 #_(),.-]{1,80}\.dxf", name, flags=re.IGNORECASE):
            return None
        return name

    def _dxf_category_folder(self, cat: str) -> Path:
        root = self._dxf_root()
        root.mkdir(parents=True, exist_ok=True)
        if cat == "(root)":
            return root
        return root / cat

    def _list_dxf_categories(self):
        root = self._dxf_root()
        root.mkdir(parents=True, exist_ok=True)
        cats = ["(root)"]
        for path in sorted(root.iterdir()):
            if path.is_dir():
                cats.append(path.name)
        return cats

    def _list_dxf_files_in_category(self, cat: str):
        folder = self._dxf_category_folder(cat)
        if not folder.exists() or not folder.is_dir():
            return None
        files = []
        for path in sorted(folder.iterdir()):
            if not path.is_file():
                continue
            name = path.name
            if name.startswith("."):
                continue
            # Accept normal .dxf and (optionally) extensionless DXF files.
            if name.lower().endswith(".dxf") or path.suffix == "":
                files.append(name)
        return files
