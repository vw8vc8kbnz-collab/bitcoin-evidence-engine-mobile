"""Authenticated filter editing; one lock, one atomic commit, optimistic revisions."""

from __future__ import annotations

from metod_app.observability.failures import report_recovery

from safety_contracts import durable_write_json
from metod_app.catalog import filter_groups as filters
from metod_app.storage.catalog_publication import catalog_guarded


class FilterGroupsRuntimeMixin:
    def _filter_editor_snapshot(self):
        raw, records = self._load_material_library_bundle()
        document = filters.effective_document(
            filters.read_document(filters.document_path(self._catalog_publication.get_system_dir())), records
        )
        return document, records, filters.editor(document, records, filters.digest(raw))

    @catalog_guarded
    def _api_admin_material_filters(self):
        ports = self._filter_groups_ports
        try:
            document, records, view = self._filter_editor_snapshot()
            if self.command == "POST":
                data = ports.read_json_body_limited(self, "ADMIN_JSON_MAX_BYTES", 262144)
                if not isinstance(data, dict):
                    raise ValueError("Ongeldige filterbewerking.")
                if data.get("revision") != view["revision"]:
                    return self._send_json(
                        {
                            "ok": False,
                            "error": "De indeling of catalogus is intussen gewijzigd. Herlaad voordat je opnieuw opslaat.",
                        },
                        409,
                    )
                updated = filters.apply_operation(document, records, data)
                durable_write_json(filters.document_path(ports.catalog.get_system_dir()), updated, mode=0o640)
                ports.invalidate_public_materials_response_cache()
                ports.append_system_event(
                    level="info",
                    component="material_filters",
                    message_user="Filterindeling aangepast",
                    message_tech=str(data["operation"]),
                    status="resolved",
                    details={
                        "actor": self._current_admin_actor() or "unknown-admin",
                        "axis": data["axis"],
                        "operation": data["operation"],
                    },
                )
                _, _, view = self._filter_editor_snapshot()
            return self._send_json(view)
        except ValueError as error:
            return self._send_json({"ok": False, "error": str(error)}, 400)
        except Exception as error:
            report_recovery("metod_app.http.filter_groups_runtime.boundary.37", error)
            ports.append_system_event(
                level="error",
                component="material_filters",
                message_user="Filterbeheer kon niet worden geladen of opgeslagen",
                message_tech=str(error),
                status="open",
            )
            return self._send_json(
                {
                    "ok": False,
                    "error": "Filterbeheer is tijdelijk niet beschikbaar. Herlaad om de opgeslagen indeling te controleren.",
                },
                500,
            )
