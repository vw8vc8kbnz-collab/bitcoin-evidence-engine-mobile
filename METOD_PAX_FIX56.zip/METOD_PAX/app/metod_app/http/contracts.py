"""Immutable, transport-neutral descriptions of the current HTTP surface.

These types contain identifiers rather than callables. The HTTP handler uses
them as a declarative catalog; they do not dispatch, authorize, read bodies or
write responses.
"""

from __future__ import annotations


from dataclasses import dataclass


HTTP_METHODS = frozenset({"GET", "HEAD", "OPTIONS", "POST"})
BODY_CONSUMPTION = frozenset({"none", "bounded-json"})


@dataclass(frozen=True, slots=True, kw_only=True)
class BodyPolicy:
    consumption: str = "none"
    owner_id: str | None = None
    reader_id: str | None = None
    limit_environment: str | None = None
    default_bytes: int | None = None
    declared_maximum: str = "none"


@dataclass(frozen=True, slots=True, kw_only=True)
class RateLimitPolicy:
    owner_id: str | None = None
    bucket: str | None = None
    maximum: int | None = None
    window_seconds: int | None = None
    declared: str = "edge/global controls only"


@dataclass(frozen=True, slots=True, kw_only=True)
class RouteDefinition:
    method: str
    pattern: str
    dispatch_id: str
    handler_id: str
    access_policy: str
    origin_policy: str = "none"
    body: BodyPolicy = BodyPolicy()
    rate_limit: RateLimitPolicy = RateLimitPolicy()
    maintenance_policy: str = "none"
    response_kind: str = "json"
    business_mutation: bool = False
    runtime_mutation: bool = False
    pii_classification: str = "none"
    security_header_profile: str = "global-hardened"
    error_schema: str = "json {ok:false, error:string} unless route-specific compatibility DTO is documented"

    @property
    def key(self) -> str:
        return f"{self.method} {self.pattern}"


def validate_route_catalog(routes: tuple[RouteDefinition, ...]) -> tuple[str, ...]:
    """Return deterministic catalog errors; an empty tuple is valid."""

    errors: list[str] = []
    keys: set[str] = set()
    for index, route in enumerate(routes):
        label = route.key or f"route[{index}]"
        if route.method not in HTTP_METHODS:
            errors.append(f"{label}: unsupported method")
        if not route.pattern or not route.pattern.startswith("/") and route.pattern != "*":
            errors.append(f"{label}: unsafe pattern")
        if route.key in keys:
            errors.append(f"{label}: duplicate route")
        keys.add(route.key)
        if not route.dispatch_id or not route.handler_id:
            errors.append(f"{label}: missing owner identifier")
        if route.body.consumption not in BODY_CONSUMPTION:
            errors.append(f"{label}: unsupported body policy")
        if route.body.consumption == "none":
            if any(
                (
                    route.body.owner_id,
                    route.body.reader_id,
                    route.body.limit_environment,
                    route.body.default_bytes,
                )
            ):
                errors.append(f"{label}: bodyless route has a reader or limit")
        elif not all(
            (route.body.owner_id, route.body.reader_id, route.body.limit_environment)
        ) or not isinstance(route.body.default_bytes, int):
            errors.append(f"{label}: bounded body policy is incomplete")
        rate_values = (
            route.rate_limit.owner_id,
            route.rate_limit.bucket,
            route.rate_limit.maximum,
            route.rate_limit.window_seconds,
        )
        if any(value is not None for value in rate_values) and not all(
            value is not None for value in rate_values
        ):
            errors.append(f"{label}: partial rate-limit policy")
        if route.method in {"GET", "HEAD", "OPTIONS"} and route.business_mutation:
            errors.append(f"{label}: read method declares a business mutation")
        if route.method != "POST" and route.origin_policy not in {
            "none",
            "allowlisted-public-or-admin-origin-reflection",
            "exact-public-origin-read",
        }:
            errors.append(f"{label}: read method declares a write-origin policy")
        if route.method == "POST" and route.pattern.startswith("/api/admin/"):
            if "admin-origin" not in route.origin_policy:
                errors.append(f"{label}: Admin mutation lacks its origin policy")
    return tuple(errors)


__all__ = (
    "BODY_CONSUMPTION",
    "HTTP_METHODS",
    "BodyPolicy",
    "RateLimitPolicy",
    "RouteDefinition",
    "validate_route_catalog",
)
