"""Public catalog projection/cache owner; no mutable private fields in its DTO."""

from __future__ import annotations

from metod_app.version import REVISION

from catalog_importer import ALLOWED_THICKNESSES_MM as CATALOG_ALLOWED_THICKNESSES_MM
from safety_contracts import durable_write_bytes
import gzip
import hashlib
import json
from safety_contracts import strict_json_load
import time
from metod_app.runtime.ports import HttpPublicCatalogRuntimePorts

from metod_app.observability.failures import report_recovery
from metod_app.catalog import filter_groups
from metod_app.storage.catalog_publication import catalog_guarded


class PublicCatalogRuntimeMixin:
    _public_catalog_ports: HttpPublicCatalogRuntimePorts

    @catalog_guarded
    def _public_materials_response_bytes(self, force_rebuild: bool = False) -> tuple[bytes, str, str]:
        """Return a prebuilt PUBLIC-ONLY catalog JSON response.

        Current moves the expensive 597-record normalization/media discovery out of every
        customer page load. The cache key is material_library.json mtime, so every Admin
        publish invalidates automatically. A disk cache survives server restarts.
        """
        ports = self._public_catalog_ports

        MATERIAL_LIBRARY_PATH = ports.get_material_library_path()
        PUBLIC_MATERIAL_CATALOG_CACHE_BUILD = ports.get_public_material_catalog_cache_build()
        PUBLIC_MATERIAL_CATALOG_CACHE_META_PATH = ports.get_public_material_catalog_cache_meta_path()
        PUBLIC_MATERIAL_CATALOG_CACHE_PATH = ports.get_public_material_catalog_cache_path()
        PUBLIC_MATERIAL_CATALOG_CACHE_SCHEMA = ports.get_public_material_catalog_cache_schema()
        _PUBLIC_MATERIALS_RESPONSE_CACHE = ports.get_public_materials_response_cache()
        _PUBLIC_MATERIALS_RESPONSE_CACHE_LOCK = ports.get_public_materials_response_cache_lock()
        _atomic_write_json = ports.atomic_write_json
        _utc_now_iso = ports.utc_now_iso

        filter_document = filter_groups.read_document(
            filter_groups.document_path(ports.catalog.get_system_dir())
        )
        filter_revision = filter_groups.digest(filter_document)
        try:
            source_mtime_ns = int(MATERIAL_LIBRARY_PATH.stat().st_mtime_ns)
        except (OSError, ValueError, TypeError, OverflowError):
            source_mtime_ns = 0
        with _PUBLIC_MATERIALS_RESPONSE_CACHE_LOCK:
            if (
                not force_rebuild
                and _PUBLIC_MATERIALS_RESPONSE_CACHE.get("filterRevision") == filter_revision
                and _PUBLIC_MATERIALS_RESPONSE_CACHE.get("mtimeNs") == source_mtime_ns
                and isinstance(_PUBLIC_MATERIALS_RESPONSE_CACHE.get("body"), (bytes, bytearray))
            ):
                return (
                    bytes(_PUBLIC_MATERIALS_RESPONSE_CACHE["body"]),
                    str(_PUBLIC_MATERIALS_RESPONSE_CACHE.get("etag") or ""),
                    str(source_mtime_ns) + "-" + filter_revision,
                )

        if not force_rebuild and source_mtime_ns:
            try:
                meta = strict_json_load(PUBLIC_MATERIAL_CATALOG_CACHE_META_PATH)
                if (
                    int(meta.get("schemaVersion") or 0) == PUBLIC_MATERIAL_CATALOG_CACHE_SCHEMA
                    and str(meta.get("build") or "") == PUBLIC_MATERIAL_CATALOG_CACHE_BUILD
                    and meta.get("filterRevision") == filter_revision
                    and int(meta.get("sourceMtimeNs") or -1) == source_mtime_ns
                    and PUBLIC_MATERIAL_CATALOG_CACHE_PATH.exists()
                ):
                    body = PUBLIC_MATERIAL_CATALOG_CACHE_PATH.read_bytes()
                    etag = str(meta.get("etag") or "")
                    if body and etag:
                        with _PUBLIC_MATERIALS_RESPONSE_CACHE_LOCK:
                            _PUBLIC_MATERIALS_RESPONSE_CACHE.update(
                                {
                                    "mtimeNs": source_mtime_ns,
                                    "filterRevision": filter_revision,
                                    "body": body,
                                    "etag": etag,
                                }
                            )
                        return body, etag, str(source_mtime_ns) + "-" + filter_revision
            except Exception as recovery_error:
                report_recovery(
                    "metod_app.http.public_catalog_runtime._public_materials_response_bytes.64",
                    recovery_error,
                )

        raw, recs = self._load_material_library_bundle()
        filter_document = filter_groups.effective_document(filter_document, recs)
        norm = []
        for r in recs:
            if not isinstance(r, dict):
                continue
            rr = self._normalize_material_record_for_admin(r)
            if (
                str(rr.get("sourceKind") or "").upper() != "CATALOG_IMPORT"
                or rr.get("active") is False
                or rr.get("archived") is True
                or rr.get("published") is False
                or rr.get("catalogExcluded") is True
                or rr.get("catalogMissing") is True
            ):
                continue
            try:
                thickness_public = float(rr.get("thicknessMm") or 0.0)
            except (ValueError, TypeError, OverflowError):
                thickness_public = 0.0
            if not any(abs(thickness_public - float(x)) < 1e-9 for x in CATALOG_ALLOWED_THICKNESSES_MM):
                continue
            pub = self._material_record_to_toola_catalog(rr, already_normalized=True)
            pub["filters"] = filter_groups.public_filters(rr, filter_document)
            if pub.get("publicMaterialId"):
                norm.append(pub)
        try:
            source_mtime_ns = int(MATERIAL_LIBRARY_PATH.stat().st_mtime_ns)
        except (OSError, ValueError, TypeError, OverflowError):
            source_mtime_ns = int(time.time() * 1_000_000_000)
        version = str(source_mtime_ns) + "-" + filter_revision
        body = json.dumps(
            {"ok": True, "records": norm, "version": version, "count": len(norm), "schemaVersion": 1},
            ensure_ascii=False,
            separators=(",", ":"),
        ).encode("utf-8")
        etag = '"catalog-' + hashlib.sha256(body).hexdigest()[:24] + '"'
        try:
            durable_write_bytes(PUBLIC_MATERIAL_CATALOG_CACHE_PATH, body, mode=0o640)
            _atomic_write_json(
                PUBLIC_MATERIAL_CATALOG_CACHE_META_PATH,
                {
                    "schemaVersion": PUBLIC_MATERIAL_CATALOG_CACHE_SCHEMA,
                    "sourceMtimeNs": source_mtime_ns,
                    "etag": etag,
                    "filterRevision": filter_revision,
                    "count": len(norm),
                    "builtAt": _utc_now_iso(),
                    "build": PUBLIC_MATERIAL_CATALOG_CACHE_BUILD,
                },
            )
        except Exception as recovery_error:
            report_recovery(
                "metod_app.http.public_catalog_runtime._public_materials_response_bytes.103", recovery_error
            )
        with _PUBLIC_MATERIALS_RESPONSE_CACHE_LOCK:
            _PUBLIC_MATERIALS_RESPONSE_CACHE.update(
                {"mtimeNs": source_mtime_ns, "filterRevision": filter_revision, "body": body, "etag": etag}
            )
        return body, etag, version

    def _api_public_materials_library(self):
        ports = self._public_catalog_ports
        _append_system_event = ports.append_system_event

        try:
            body, etag, version = self._public_materials_response_bytes()
            incoming = str(self.headers.get("If-None-Match") or "").strip()
            if incoming and incoming == etag:
                self.send_response(304)
                self.send_header("ETag", etag)
                self.send_header("Cache-Control", "private, max-age=0, must-revalidate")
                self.send_header("X-ToolA-Catalog-Build", REVISION)
                self.end_headers()
                return
            accept_encoding = str(self.headers.get("Accept-Encoding") or "").lower()
            wire_body = gzip.compress(body, compresslevel=5) if "gzip" in accept_encoding else body
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(wire_body)))
            if wire_body is not body:
                self.send_header("Content-Encoding", "gzip")
            self.send_header("Vary", "Accept-Encoding")
            self.send_header("ETag", etag)
            self.send_header("Cache-Control", "private, max-age=0, must-revalidate")
            self.send_header("X-ToolA-Catalog-Build", REVISION)
            self.end_headers()
            self.wfile.write(wire_body)
        except Exception as e:
            report_recovery("metod_app.http.public_catalog_runtime.boundary.144", e)
            _append_system_event(
                level="error",
                component="materials",
                message_user="Materiaalbibliotheek laden is mislukt",
                message_tech=str(e),
                status="open",
            )
            return self._send_json(
                {"ok": False, "error": "Materiaalbibliotheek kon niet worden geladen"}, 500
            )
