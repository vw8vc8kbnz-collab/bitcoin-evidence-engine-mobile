"""HTTP contracts and explicit endpoint dispatch."""
