"""Bounded JobStateRuntime implementation with explicit ports injection."""

from __future__ import annotations

from typing import Any
from pathlib import Path
from metod_app.jobs.status import build_job_runtime_state as _build_job_runtime_state
from metod_app.jobs.status import job_cancel_requested as _runtime_job_cancel_requested
from metod_app.jobs.status import startup_recovery_decision as _startup_recovery_decision
from safety_contracts import durable_write_json
from safety_contracts import resolve_identifier_child
from safety_contracts import strict_json_load
import subprocess
import sys
from safety_contracts import validate_job_id
from metod_app.runtime.ports import JobsStateRuntimePorts


import threading
import weakref

from .contracts import canonical_job_state, state_from_record
from .status import job_state_transition_allowed


class JobStateRuntime:
    def __init__(self, ports: JobsStateRuntimePorts):
        self._ports = ports
        self._state_locks_guard = threading.Lock()
        # Retained jobs can be numerous; lock identity only needs to live while a
        # transition is in flight. Weak values preserve same-job serialization
        # without one permanent Python object per historical job.
        self._state_locks = weakref.WeakValueDictionary()

    def _state_lock_for(self, job_id: str) -> threading.RLock:
        with self._state_locks_guard:
            lock = self._state_locks.get(job_id)
            if lock is None:
                lock = threading.RLock()
                self._state_locks[job_id] = lock
            return lock

    def _get_python_base_cmd(_owner):
        # Use the same Python interpreter as the server for maximum compatibility and speed.
        # (Avoid calling the Windows py launcher for Tool B, which can be slow and may select a different Python version.)
        return [sys.executable]

    def _job_runtime_state_path(_owner, job_id: str) -> Path:
        ports = _owner._ports
        JOBS = ports.get_jobs()

        root = resolve_identifier_child(JOBS, validate_job_id(job_id))
        return root / "job_state.json"

    def _load_job_runtime_state(_owner, job_id: str) -> dict:
        ports = _owner._ports
        _job_runtime_state_path = ports.job_runtime_state_path

        path = _job_runtime_state_path(job_id)
        if not path.exists():
            return {}
        try:
            value = strict_json_load(path)
            return value if isinstance(value, dict) else {}
        except (OSError, ValueError, TypeError, OverflowError):
            # A malformed current record is not a preserved legacy job.  Keep a
            # non-empty fail-closed sentinel so public-family legacy fallbacks can
            # distinguish corruption from a genuinely absent pre-state file.
            return {"state": "INVALID", "invalid": True}

    def _transition_job_runtime_state(
        _owner,
        job_id: str,
        state: str,
        *,
        allowed_from=None,
        **extra: Any,
    ) -> tuple[bool, dict]:
        ports = _owner._ports

        _job_runtime_state_path = ports.job_runtime_state_path
        _utc_now_iso = ports.utc_now_iso

        job_id = validate_job_id(job_id)
        target = canonical_job_state(state)
        lock = _owner._state_lock_for(job_id)
        with lock:
            path = _job_runtime_state_path(job_id)
            if path.exists():
                previous = strict_json_load(path)
                if not isinstance(previous, dict):
                    raise RuntimeError(f"Invalid durable job state for {job_id}")
            else:
                previous = {}
            current = state_from_record(previous)
            if current == target:
                return False, previous
            if allowed_from is not None:
                permitted_sources = {canonical_job_state(value) for value in allowed_from}
                if current not in permitted_sources:
                    return False, previous
            if not job_state_transition_allowed(current, target):
                return False, previous
            reserved = {"schemaVersion", "jobId", "state", "createdAt", "updatedAt"}
            safe_extra = {key: value for key, value in dict(extra or {}).items() if key not in reserved}
            value = _build_job_runtime_state(
                job_id=job_id,
                state=target,
                previous=previous,
                now_iso=_utc_now_iso,
                extra=safe_extra,
            )
            durable_write_json(path, value)
            return True, value

    def _save_job_runtime_state(_owner, job_id: str, state: str, **extra: Any) -> dict:
        ports = _owner._ports

        _transition_job_runtime_state = ports.transition_job_runtime_state

        changed, value = _transition_job_runtime_state(job_id, state, **extra)
        if changed or state_from_record(value) == canonical_job_state(state):
            return value
        current = state_from_record(value) or "MISSING"
        raise RuntimeError(f"Invalid job state transition {current} -> {canonical_job_state(state)}")

    def _job_cancel_requested(_owner, job_id: str) -> bool:
        ports = _owner._ports
        _load_job_runtime_state = ports.load_job_runtime_state

        return _runtime_job_cancel_requested(_load_job_runtime_state(job_id))

    def _register_job_process(_owner, master_job_id: str, process: subprocess.Popen) -> None:
        ports = _owner._ports
        _OPTIMIZER_PROCESS_SUPERVISOR = ports.get_optimizer_process_supervisor()

        _OPTIMIZER_PROCESS_SUPERVISOR.register(master_job_id, process)

    def _unregister_job_process(_owner, master_job_id: str, process: subprocess.Popen) -> None:
        ports = _owner._ports
        _OPTIMIZER_PROCESS_SUPERVISOR = ports.get_optimizer_process_supervisor()

        _OPTIMIZER_PROCESS_SUPERVISOR.unregister(master_job_id, process)

    def _terminate_optimizer_process(
        _owner,
        process: subprocess.Popen,
        *,
        terminate_timeout: float = 5.0,
        kill_timeout: float = 2.0,
    ) -> int | None:
        ports = _owner._ports
        _OPTIMIZER_PROCESS_SUPERVISOR = ports.get_optimizer_process_supervisor()

        return _OPTIMIZER_PROCESS_SUPERVISOR.terminate(
            process,
            terminate_timeout=terminate_timeout,
            kill_timeout=kill_timeout,
        )

    def _reconcile_interrupted_jobs_on_startup(_owner) -> int:
        ports = _owner._ports
        _JOB_RESTART_RECONCILER = ports.get_job_restart_reconciler()

        return _JOB_RESTART_RECONCILER.reconcile(recovery_decision=_startup_recovery_decision)

    def _find_existing_file(_owner, base_dir: Path, candidates):
        """Return first existing path among candidates (relative to base_dir)."""

        for rel in candidates:
            p = base_dir / rel
            if p.exists():
                return p
        return None

    def _find_placements_any(_owner, output_dir: Path):
        ports = _owner._ports

        _find_existing_file = ports.find_existing_file

        # common variants (windows may hide extension; toolb may output without)
        candidates = [
            Path("placements.json"),
            Path("placements"),
            Path("Placements.json"),
            Path("Placements"),
        ]
        p = _find_existing_file(output_dir, candidates)
        if p:
            return p
        for f in output_dir.iterdir():
            if f.is_file() and f.name.lower().startswith("placements"):
                return f
        return None

    def _find_labels_any(_owner, output_dir: Path):
        ports = _owner._ports

        _find_existing_file = ports.find_existing_file

        candidates = [Path("labels.json"), Path("labels"), Path("Labels.json"), Path("Labels")]
        p = _find_existing_file(output_dir, candidates)
        if p:
            return p
        for f in output_dir.iterdir():
            if f.is_file() and f.name.lower().startswith("labels"):
                return f
        return None

    EXPORTS = (
        "_get_python_base_cmd",
        "_job_runtime_state_path",
        "_load_job_runtime_state",
        "_save_job_runtime_state",
        "_job_cancel_requested",
        "_register_job_process",
        "_unregister_job_process",
        "_terminate_optimizer_process",
        "_reconcile_interrupted_jobs_on_startup",
        "_find_existing_file",
        "_find_placements_any",
        "_find_labels_any",
    )


__all__ = ("JobStateRuntime",)
