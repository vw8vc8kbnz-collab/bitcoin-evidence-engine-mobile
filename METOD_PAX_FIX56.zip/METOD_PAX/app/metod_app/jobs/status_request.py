"""Explicit request dependencies and bounded lifecycle operations."""

from __future__ import annotations
from metod_app.observability.failures import report_recovery
from typing import Any
from metod_app.jobs.execution import job_family_live_progress
from metod_app.pricing.authority import aggregate_sell_priced_quotes, public_subjob_quote_projection
from .lifecycle_contracts import public_job_meta_projection


class JobStatusRequest:
    def __init__(self, dependencies, handler, job_id, parsed=None):
        self.dependencies = dependencies
        self.handler = handler
        self.finished = False
        self.response = None
        self.job_id = job_id
        self.parsed = parsed
        self.JOBS = self.dependencies.JOBS()
        self.CATALOG_VAT_RATE = self.dependencies.CATALOG_VAT_RATE()
        self._job_lock = self.dependencies._job_lock()
        self._job_meta = self.dependencies._job_meta()

    def _reply(self, *args, **kwargs):
        self.finished = True
        self.response = self.handler._send_json(*args, **kwargs)
        return self.response

    def _is_final(self, root: Any) -> bool:
        return self.dependencies._finalization_complete(root, _memo=self.finalization_memo)

    def _load_quote(self, path: Any):
        if not path.exists():
            return None
        try:
            q = self.dependencies.strict_json_load(path)
        except (OSError, ValueError, TypeError, OverflowError):
            return None
        try:
            if isinstance(q, dict):
                sell_snapshot = None
                vat_snapshot = None
                pricing_path = path.parent.parent / "input" / "pricing.json"
                if pricing_path.is_file():
                    pricing_input = self.dependencies.strict_json_load(pricing_path)
                    if isinstance(pricing_input, dict) and isinstance(pricing_input.get("sellPricing"), dict):
                        sell_snapshot = pricing_input.get("sellPricing")
                        vat_snapshot = pricing_input.get("vatRate")
                if sell_snapshot is not None:
                    q = self.dependencies._apply_sell_pricing_to_quote(
                        q, sell_pricing=sell_snapshot, vat_rate=vat_snapshot
                    )
                elif q.get("sellPricing") is None:
                    q = self.dependencies._apply_sell_pricing_to_quote(q)
        except Exception as recovery_error:
            report_recovery("metod_app.jobs.status_request.boundary.52", recovery_error)
            return None
        return q

    def _read_progress(self, root: Any):
        try:
            pp = root / "output" / "progress.json"
            if pp.exists():
                pdata = self.dependencies.strict_json_load(pp)
                pct = pdata.get("percent")
                msg = str(pdata.get("message") or pdata.get("phase") or "").strip()
                if pct is not None:
                    try:
                        pct = max(0, min(100, int(round(float(pct)))))
                        return {"pct": pct, "message": msg}
                    except (ValueError, TypeError, OverflowError) as recovery_error:
                        report_recovery("metod_app.jobs.lifecycle._read_progress.1155", recovery_error)
            rp = root / "output" / "report.json"
            if not rp.exists():
                return None
            data = self.dependencies.strict_json_load(rp)
            prog = data.get("progress") if isinstance(data.get("progress"), dict) else {}
            pct = prog.get("percent") if isinstance(prog, dict) else None
            msg = (
                str(prog.get("message") or prog.get("phase") or "").strip() if isinstance(prog, dict) else ""
            )
            if pct is None and data.get("ok") is True:
                pct = 100
            if pct is None:
                return None
            try:
                pct = max(0, min(100, int(round(float(pct)))))
            except (ValueError, TypeError, OverflowError):
                return None
            return {"pct": pct, "message": msg}
        except Exception as recovery_error:
            report_recovery("metod_app.jobs.status_request.boundary.85", recovery_error)
            return None

    def authorize(self):
        try:
            self.job_id = self.dependencies.validate_job_id(self.job_id)
            self.job_root = self.dependencies.resolve_identifier_child(self.JOBS, self.job_id)
        except self.dependencies.SafetyContractError:
            return self._reply({"meta": {"status": "unknown"}, "quote": None}, 404)
        if not self.handler._require_job_access(self.job_id, parsed=self.parsed, deny_as_json=True):
            self.finished = True
            return
        if not self.job_root.exists():
            return self._reply({"meta": {"status": "unknown"}, "quote": None})
        if "__mat_" in self.job_id:
            if not self.dependencies._public_job_family_complete(self.job_id, memo={}):
                master_id = self.dependencies._master_job_id_for(self.job_id)
                master_state = str(
                    self.dependencies._load_job_runtime_state(master_id).get("state") or ""
                ).lower()
                if master_state in {"done", "failed", "cancel_requested", "cancelled"}:
                    message = (
                        "Integriteitscontrole van de volledige berekening is mislukt"
                        if master_state == "done"
                        else "De volledige berekening is niet afgerond"
                    )
                    return self._reply(
                        {
                            "meta": {"status": "error", "progressPct": 0, "progressMessage": message},
                            "quote": None,
                            "pricingSummary": {},
                        },
                        409,
                    )
                return self._reply(
                    {
                        "meta": {
                            "status": "processing",
                            "progressPct": 0,
                            "progressMessage": "De volledige berekening wordt nog verwerkt",
                        },
                        "quote": None,
                        "pricingSummary": {},
                    }
                )

    def load_state(self):
        self.runtime_state = str(
            self.dependencies._load_job_runtime_state(self.job_id).get("state") or ""
        ).lower()
        with self._job_lock:
            self.meta = dict(self._job_meta.get(self.job_id, {}) or {})
        self.finalization_memo: dict[str, bool] = {}
        has_master_finalization = (self.job_root / "output" / "finalization.json").is_file()
        self.family_finalized = (
            self._is_final(self.job_root)
            if self.runtime_state == "done" or (not self.runtime_state and has_master_finalization)
            else False
        )
        if self.runtime_state in {"cancel_requested", "cancelled"}:
            return self._reply(
                {
                    "meta": {
                        "status": "cancelled",
                        "progressPct": 0,
                        "progressMessage": "Berekening geannuleerd",
                    },
                    "quote": None,
                    "pricingSummary": {},
                }
            )
        if self.runtime_state == "failed":
            return self._reply(
                {
                    "meta": {"status": "error", "progressPct": 0, "progressMessage": "Berekening mislukt"},
                    "quote": None,
                    "pricingSummary": {},
                }
            )
        if self.runtime_state == "done" and (not self.family_finalized):
            return self._reply(
                {
                    "meta": {
                        "status": "error",
                        "progressPct": 0,
                        "progressMessage": "Integriteitscontrole van productie-output is mislukt",
                    },
                    "quote": None,
                    "pricingSummary": {},
                },
                409,
            )

    def load_family(self):
        self.inferred_status = "unknown"
        self.quote = None
        linked_ids: list[str] = []
        persisted_link_ids = self.dependencies._linked_subjob_ids(self.job_id) or []
        runtime_link_ids = self.meta.get("subjobIds") or []
        for source_ids in (persisted_link_ids, runtime_link_ids):
            if not isinstance(source_ids, (list, tuple)):
                continue
            for value in source_ids:
                if not isinstance(value, str) or not value or value in linked_ids:
                    continue
                linked_ids.append(value)
        if not linked_ids and self.runtime_state in {"done", "failed", "cancelled"}:
            linked_ids = [p.name for p in sorted(self.JOBS.glob(f"{self.job_id}__mat_*")) if p.is_dir()]
        self.subjob_dirs = []
        for subjob_id in linked_ids:
            try:
                subjob_root = self.dependencies.resolve_identifier_child(
                    self.JOBS, self.dependencies.validate_job_id(subjob_id)
                )
                if subjob_root.is_dir() and subjob_root not in self.subjob_dirs:
                    self.subjob_dirs.append(subjob_root)
            except Exception as recovery_error:
                report_recovery("metod_app.jobs.status_request.boundary.143", recovery_error)
                continue
        if self.subjob_dirs:
            all_done = True
            finalization_error = ""
            sub_quotes = []
            for sp in self.subjob_dirs:
                out = sp / "output"
                fin = out / "finalization.json"
                if fin.exists():
                    try:
                        fd = self.dependencies.strict_json_load(fin)
                        fstate = str(fd.get("state") or "").upper()
                        if fstate == "ERROR":
                            finalization_error = str(
                                (fd.get("errors") or [fd.get("error") or "Outputfinalisatie mislukt"])[0]
                            )
                            all_done = False
                        elif fstate != "COMPLETE":
                            all_done = False
                    except (OSError, ValueError, TypeError, OverflowError):
                        all_done = False
                else:
                    if not (out / "placements.json").exists() or not (out / "report.json").exists():
                        all_done = False
                    if not (
                        (sp / "calculation_summary.txt").exists()
                        or (out / "calculation_summary.txt").exists()
                        or (sp / "input" / "calculation_summary.txt").exists()
                    ):
                        all_done = False
                q = self._load_quote(out / "quote.json") if self.family_finalized else None
                if isinstance(q, dict):
                    sub_quotes.append((sp.name, q))
            try:
                planned_subjobs = int(self.meta.get("subjobsTotal") or 0)
            except (TypeError, ValueError, OverflowError):
                planned_subjobs = 0
            if planned_subjobs > len(self.subjob_dirs):
                all_done = False
            if finalization_error:
                self.inferred_status = "error"
            else:
                self.inferred_status = "done" if all_done else "processing"
            parent_quote = None
            if self.family_finalized:
                try:
                    master_finalization = self.dependencies.strict_json_load(
                        self.job_root / "output" / "finalization.json"
                    )
                    master_artifacts = (master_finalization or {}).get("artifactsSha256") or {}
                    if isinstance(master_artifacts, dict) and "quote.json" in master_artifacts:
                        parent_quote = self._load_quote(self.job_root / "output" / "quote.json")
                except Exception as recovery_error:
                    report_recovery("metod_app.jobs.status_request.boundary.188", recovery_error)
                    parent_quote = None
            if isinstance(parent_quote, dict):
                self.quote = parent_quote
            elif sub_quotes:
                quote_vat_rate = self.CATALOG_VAT_RATE
                for _subjob_id, _sub_quote in sub_quotes:
                    _sell = (
                        _sub_quote.get("sellPricing")
                        if isinstance(_sub_quote.get("sellPricing"), dict)
                        else {}
                    )
                    if _sell.get("materialVatRate") is not None:
                        quote_vat_rate = _sell.get("materialVatRate")
                        break
                self.quote = aggregate_sell_priced_quotes(
                    [q for _sid, q in sub_quotes], vat_rate=quote_vat_rate
                )
                per_subjob = []
                for subjob_index, (subjob_id, sub_quote) in enumerate(sub_quotes):
                    try:
                        per_subjob.append(
                            public_subjob_quote_projection(
                                subjob_id,
                                sub_quote,
                                include_fixed_costs=subjob_index == 0,
                                vat_rate=quote_vat_rate,
                            )
                        )
                    except Exception as recovery_error:
                        report_recovery("metod_app.jobs.status_request.boundary.204", recovery_error)
                        continue
                if per_subjob:
                    self.quote["perSubjob"] = per_subjob
        else:
            out = self.job_root / "output"
            self.quote = self._load_quote(out / "quote.json")
            has_calc = (self.job_root / "calculation_summary.txt").exists() or (
                out / "calculation_summary.txt"
            ).exists()
            if self.runtime_state == "accepted" and str(self.meta.get("status") or "").lower() == "queued":
                self.inferred_status = "queued"
            elif (
                (out / "report.json").exists()
                or (out / "placements.json").exists()
                or isinstance(self.quote, dict)
            ) and has_calc:
                self.inferred_status = "done"
            elif out.exists() or isinstance(self.quote, dict):
                self.inferred_status = "processing"

    def read_progress(self):
        self.meta2 = dict(self.meta)
        queued_in_memory = self.runtime_state == "accepted" and str(self.meta2.get("phase") or "") == "queued"
        if queued_in_memory:
            self.meta2["status"] = "queued"
        elif self.inferred_status != "unknown":
            self.meta2["status"] = self.inferred_status
        else:
            self.meta2.setdefault("status", "unknown")
        progress_info = None
        meta_pct = int(self.meta2.get("progressPct") or 0)
        meta_msg = str(self.meta2.get("progressMessage") or "").strip()
        if self.subjob_dirs and self.meta2.get("status") not in ("done", "ready", "ok"):
            try:
                planned_total = int(self.meta2.get("subjobsTotal") or 0)
            except (TypeError, ValueError, OverflowError):
                planned_total = 0
            total = max(len(self.subjob_dirs), max(0, min(10000, planned_total)))
            done_count = 0
            current_subjob_pct = 0.0
            current_message = ""
            for sj in self.subjob_dirs:
                sj_out = sj / "output"
                sj_quote = self._load_quote(sj_out / "quote.json")
                has_calc_summary = (
                    (sj / "calculation_summary.txt").exists()
                    or (sj_out / "calculation_summary.txt").exists()
                    or (sj / "input" / "calculation_summary.txt").exists()
                )
                fin_path = sj_out / "finalization.json"
                if fin_path.exists():
                    try:
                        fin_obj = self.dependencies.strict_json_load(fin_path)
                        sj_done = str((fin_obj or {}).get("state") or "").upper() == "COMPLETE"
                    except (OSError, ValueError, TypeError, OverflowError):
                        sj_done = False
                else:
                    sj_done = (
                        (sj_out / "report.json").exists()
                        or (sj_out / "placements.json").exists()
                        or isinstance(sj_quote, dict)
                    ) and has_calc_summary
                if sj_done:
                    done_count += 1
                    continue
                prog = self._read_progress(sj)
                if prog and prog.get("pct", 0) > 0:
                    live_pct = max(0.0, min(100.0, float(prog["pct"])))
                    if live_pct >= current_subjob_pct:
                        current_subjob_pct = live_pct
                        current_message = prog.get("message") or current_message
            if total > 0:
                if len(self.subjob_dirs) >= total and done_count >= total:
                    master_phase = str(self.meta2.get("phase") or "").strip().lower()
                    if master_phase in {"finalize_merge", "finalize", "finalize_done"} and meta_pct > 0:
                        progress_info = {"pct": meta_pct, "message": meta_msg}
                    else:
                        progress_info = {"pct": 94, "message": meta_msg or "Materiaalberekeningen afgerond"}
                else:
                    progress_info = {
                        "pct": job_family_live_progress(done_count, current_subjob_pct, total),
                        "message": current_message or meta_msg,
                    }
        elif meta_pct > 0:
            progress_info = {"pct": meta_pct, "message": meta_msg}
        else:
            prog = self._read_progress(self.job_root)
            if prog:
                progress_info = prog
        if progress_info:
            pct_val = int(progress_info.get("pct") or 0)
            if self.meta2.get("status") not in ("done", "ready", "ok"):
                pct_val = min(99, pct_val)
            self.meta2["progressPct"] = pct_val
            if progress_info.get("message"):
                self.meta2["progressMessage"] = progress_info.get("message")
            elif pct_val >= 95 and self.meta2.get("status") not in ("done", "ready", "ok"):
                self.meta2["progressMessage"] = "Resultaten verwerken…"
        elif self.meta2.get("status") in ("done", "ready", "ok"):
            self.meta2["progressPct"] = 100
            self.meta2["progressMessage"] = self.meta2.get("progressMessage") or "Optimalisatie afgerond"

    def project_response(self):
        pricing_summary = {}
        try:
            candidate_job_ids = []
            for jid in [self.job_id] + [p.name for p in self.subjob_dirs]:
                if jid and jid not in candidate_job_ids:
                    candidate_job_ids.append(jid)
            pricing_summary = (
                self.dependencies._extract_strict_calculation_pricing_summary(candidate_job_ids)
                if candidate_job_ids and self.family_finalized
                else {}
            )
        except Exception as recovery_error:
            report_recovery("metod_app.jobs.status_request.boundary.298", recovery_error)
            pricing_summary = {}
        if self.inferred_status == "done" and (not self.family_finalized):
            if self.runtime_state in {"accepted", "preparing", "processing", "finalizing"}:
                self.meta2["status"] = "processing"
                self.meta2["progressPct"] = min(99, max(1, int(self.meta2.get("progressPct") or 99)))
                self.meta2["progressMessage"] = str(
                    self.meta2.get("progressMessage") or "Resultaten verzegelen…"
                )
            else:
                public_meta = {
                    "status": "error",
                    "progressPct": 0,
                    "progressMessage": "Integriteitscontrole van productie-output is mislukt",
                }
                return self._reply({"meta": public_meta, "quote": None, "pricingSummary": {}}, 409)
        public_quote = (
            self.handler._public_quote_view(self.quote)
            if self.quote is not None and self.family_finalized
            else None
        )
        public_pricing_summary = self.handler._sanitize_public_material_response(pricing_summary or {})
        public_meta = public_job_meta_projection(self.meta2)
        return self._reply(
            {"meta": public_meta, "quote": public_quote, "pricingSummary": public_pricing_summary}
        )

    def run(self):
        self.authorize()
        if self.finished:
            return self.response
        self.load_state()
        if self.finished:
            return self.response
        self.load_family()
        if self.finished:
            return self.response
        self.read_progress()
        if self.finished:
            return self.response
        self.project_response()
        if self.finished:
            return self.response
