"""Explicit request dependencies and bounded lifecycle operations."""

from __future__ import annotations
from dataclasses import dataclass
from typing import Any


def public_job_meta_projection(meta: object) -> dict[str, Any]:
    """Return the small, non-reflective status contract used by Tool A.

    Optimizer progress and the in-memory scheduler record are operational data.
    In particular, a failed durable-state write can leave ``error`` or a raw
    subprocess progress message in memory while the public state still appears
    active.  Never recursively sanitize and echo that record: project only
    bounded numbers plus server-owned Dutch messages.
    """
    source = dict(meta) if isinstance(meta, dict) else {}
    raw_status = str(source.get("status") or "unknown").strip().lower()
    if raw_status in {"done", "ready", "ok"}:
        status = "done"
    elif raw_status in {"cancel_requested", "cancelled", "canceled"}:
        status = "cancelled"
    elif raw_status in {"failed", "error"}:
        status = "error"
    elif raw_status == "queued":
        status = "queued"
    elif raw_status == "processing":
        status = "processing"
    else:
        status = "unknown"
    try:
        progress_pct = max(0, min(100, int(source.get("progressPct") or 0)))
    except (ValueError, TypeError, OverflowError):
        progress_pct = 0
    try:
        queue_position = max(0, int(source.get("queuePosition") or 0))
    except (ValueError, TypeError, OverflowError):
        queue_position = 0
    phase = str(source.get("phase") or "").strip().lower()
    if status == "done":
        progress_pct = 100
        message = "Optimalisatie afgerond"
    elif status == "cancelled":
        message = "Berekening geannuleerd"
    elif status == "error":
        message = "Berekening mislukt"
    elif status == "queued":
        message = (
            f"Wachtrij: positie {queue_position}" if queue_position > 0 else "Aanvraag staat in de wachtrij"
        )
    elif status == "processing":
        phase_messages = {
            "accepted": "Aanvraag gestart",
            "worker_start": "Optimalisatie wordt gestart…",
            "prepare": "Berekening wordt voorbereid…",
            "subjob_prepare": "Materiaalberekening wordt voorbereid…",
            "subjob_progress": "Materiaal wordt geoptimaliseerd…",
            "subjob_summary": "Berekening wordt opgebouwd…",
            "subjob_done": "Materiaalberekening afgerond",
            "finalize_merge": "Subjobs worden samengevoegd…",
            "finalize": "Resultaten worden verwerkt…",
            "done": "Resultaten worden verwerkt…",
        }
        message = phase_messages.get(phase, "Berekening wordt verwerkt…")
    else:
        message = "Jobstatus niet beschikbaar"
    projected = {"status": status, "progressPct": progress_pct, "progressMessage": message}
    if status == "queued" or source.get("queuePosition") is not None:
        projected["queuePosition"] = queue_position
    return projected


@dataclass(frozen=True)
class JobLifecycleDependencies:
    JOBS: Any
    CATALOG_VAT_RATE: Any
    _OPTIMIZER_PROCESS_SUPERVISOR: Any
    _cancel_queued_public_job: Any
    _client_ip: Any
    _finish_public_job_slot: Any
    _job_lock: Any
    _job_meta: Any
    _now_iso: Any
    _rate_limit_allow: Any
    _read_json_body_limited: Any
    _save_job_runtime_state: Any
    _transition_job_runtime_state: Any
    _terminate_optimizer_process: Any
    resolve_identifier_child: Any
    validate_job_id: Any
    _dxf_transport_stats: Any
    _estimate_payload_area_lower_bound: Any
    JobCancelledError: Any
    SafetyContractError: Any
    _commit_public_job_slot: Any
    _create_job_from_payload: Any
    _finalization_complete: Any
    _job_cancel_requested: Any
    durable_write_text: Any
    _atomic_write_json: Any
    _redact_sensitive_text: Any
    JOB_OUTPUT_MAX_BYTES: Any
    _append_client_log: Any
    _append_system_event: Any
    _capture_public_job_pricing_authority: Any
    _enforce_job_total_qty_limit: Any
    _env_int: Any
    _estimate_preflight_job_family_bytes: Any
    _is_production_runtime: Any
    _job_output_limit_message: Any
    _claim_public_job_idempotency: Any
    _public_job_idempotency_key_exists: Any
    _complete_public_job_idempotency: Any
    _recover_public_job_idempotency: Any
    _abandon_public_job_idempotency: Any
    _new_public_access_token: Any
    _public_error_message: Any
    _public_job_queue_limits: Any
    _release_public_job_slot: Any
    _release_state_capacity_reservation: Any
    _reserve_state_capacity: Any
    _try_acquire_public_job_slot: Any
    _utc_now_iso: Any
    fsync_directory: Any
    strict_json_load: Any
    _apply_sell_pricing_to_quote: Any
    _extract_strict_calculation_pricing_summary: Any
    _linked_subjob_ids: Any
    _load_job_runtime_state: Any
    _master_job_id_for: Any
    _public_job_family_complete: Any
