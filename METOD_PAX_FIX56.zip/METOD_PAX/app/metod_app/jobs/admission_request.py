"""Explicit request dependencies and bounded lifecycle operations."""

from __future__ import annotations
from metod_app.errors import PublicJobInputError
from metod_app.observability.failures import report_recovery
import time
import uuid


class JobAdmissionRequest:
    def __init__(self, dependencies, handler):
        self.dependencies = dependencies
        self.handler = handler
        self.finished = False
        self.response = None
        self.payload = None
        self.JOBS = self.dependencies.JOBS()
        self.JOB_OUTPUT_MAX_BYTES = self.dependencies.JOB_OUTPUT_MAX_BYTES()
        self._job_lock = self.dependencies._job_lock()
        self._job_meta = self.dependencies._job_meta()
        self.ip = self.dependencies._client_ip(self.handler)
        self.acquired = False
        self.slot_handed_off = False
        self.storage_reserved = False
        self.master_job_id = ""
        self.access_token = ""
        self.idempotency_key = ""
        self.idempotency_payload_sha256 = ""
        self.idempotency_owner_nonce = ""
        self.idempotency_owned = False
        self.idempotency_claim_attempted = False
        self.idempotency_claim_finished = False
        self.fresh_rate_authorized = False
        self.accepted_state_created = False

    def _reply(self, *args, **kwargs):
        self.finished = True
        self.response = self.handler._send_json(*args, **kwargs)
        return self.response

    def read_request(self):
        max_bytes = self.dependencies._env_int(
            "PUBLIC_JSON_MAX_BYTES", 16777216 if self.dependencies._is_production_runtime() else 134217728
        )
        try:
            content_length = int(self.handler.headers.get("Content-Length", "0") or "0")
        except (ValueError, TypeError, OverflowError):
            content_length = 0
        if content_length and content_length > max_bytes:
            actual_mb = float(content_length) / 1024.0 / 1024.0
            limit_mb = float(max_bytes) / 1024.0 / 1024.0
            try:
                self.dependencies._append_client_log(
                    "server",
                    "api_jobs_payload_block",
                    "Public job payload too large",
                    {"contentLengthMb": round(actual_mb, 1), "limitMb": round(limit_mb, 1)},
                )
            except Exception as recovery_error:
                report_recovery("metod_app.jobs.lifecycle.api_create_job.452", recovery_error)
            return self._reply(
                {
                    "ok": False,
                    "error": "De aanvraag kon niet volledig worden ontvangen. Herlaad de pagina en probeer opnieuw.",
                },
                413,
            )
        self.idempotency_key = str(
            self.handler.headers.get("Idempotency-Key") or self.handler.headers.get("X-Idempotency-Key") or ""
        ).strip()
        if not self.idempotency_key:
            return self._reply(
                {
                    "ok": False,
                    "error": "Een veilige aanvraag-ID ontbreekt. Herlaad de pagina en probeer opnieuw.",
                },
                400,
            )
        try:
            existing_idempotency_key = self.dependencies._public_job_idempotency_key_exists(
                key=self.idempotency_key
            )
        except ValueError:
            return self._reply(
                {
                    "ok": False,
                    "error": "De veilige aanvraag-ID is ongeldig. Herlaad de pagina en probeer opnieuw.",
                },
                400,
            )
        except Exception as recovery_error:
            report_recovery("metod_app.jobs.admission_request.boundary.61", recovery_error)
            return self._reply(
                {
                    "ok": False,
                    "error": "De eerdere jobaanvraag kan nog niet veilig worden gecontroleerd. Probeer dezelfde aanvraag opnieuw.",
                    "retryable": True,
                },
                425,
            )
        if not existing_idempotency_key:
            if not self.dependencies._rate_limit_allow(
                "api_jobs",
                self.ip,
                max(1, min(300, self.dependencies._env_int("PUBLIC_JOB_RATE_PER_FIVE_MINUTES", 42))),
                300,
            ):
                try:
                    self.dependencies._append_system_event(
                        level="warning",
                        component="jobs",
                        message_user="Publieke jobroute rate-limited",
                        message_tech="api_jobs rate limit",
                        status="open",
                    )
                except Exception as recovery_error:
                    report_recovery("metod_app.jobs.lifecycle.api_create_job.487", recovery_error)
                return self._reply({"ok": False, "error": self.dependencies._public_error_message(429)}, 429)
            self.fresh_rate_authorized = True
        try:
            self.payload = self.dependencies._read_json_body_limited(
                self.handler, "PUBLIC_JSON_MAX_BYTES", max_bytes
            )
        except Exception as e:
            err_text = str(e)
            if err_text.startswith("JOB_PAYLOAD_TOO_LARGE::"):
                return self._reply(
                    {
                        "ok": False,
                        "error": "De aanvraag kon niet volledig worden ontvangen. Herlaad de pagina en probeer opnieuw.",
                    },
                    413,
                )
            raise
        if not isinstance(self.payload, dict) or not self.payload:
            return self._reply({"ok": False, "error": "Lege jobpayload."}, 400)

    def claim_idempotency(self):
        for _job_id_attempt in range(8):
            candidate_job_id = self.dependencies.validate_job_id(
                time.strftime("%Y%m%d_%H%M%S_") + uuid.uuid4().hex[:24]
            )
            if not (self.JOBS / candidate_job_id).exists():
                self.master_job_id = candidate_job_id
                break
        if not self.master_job_id:
            raise RuntimeError("Unable to reserve a unique public job id")
        self.access_token = self.dependencies._new_public_access_token()
        self.idempotency_claim_attempted = True
        claim = self.dependencies._claim_public_job_idempotency(
            key=self.idempotency_key,
            payload=self.payload,
            payload_sha256=str(getattr(self.handler, "_request_body_sha256", "") or "").strip() or None,
            job_id=self.master_job_id,
            access_token=self.access_token,
        )
        self.idempotency_claim_finished = True
        self.idempotency_payload_sha256 = claim.payload_sha256
        if claim.kind == "conflict":
            return self._reply(
                {"ok": False, "error": "Deze aanvraag-ID is al gebruikt voor andere invoer."}, 409
            )
        if claim.kind == "replay":
            return self._reply(dict(claim.response or {}), 202)
        if claim.kind == "pending":
            try:
                prior_job_id = self.dependencies.validate_job_id(claim.job_id)
                prior_root = self.dependencies.resolve_identifier_child(self.JOBS, prior_job_id)
                prior_access = self.dependencies.strict_json_load(prior_root / ".public_access.json")
                prior_state = str(
                    (self.dependencies._load_job_runtime_state(prior_job_id) or {}).get("state") or ""
                ).upper()
                if (
                    isinstance(prior_access, dict)
                    and str(prior_access.get("token") or "") == claim.access_token
                    and (
                        prior_state
                        in {
                            "PREPARING",
                            "PROCESSING",
                            "FINALIZING",
                            "DONE",
                            "FAILED",
                            "CANCEL_REQUESTED",
                            "CANCELLED",
                        }
                    )
                ):
                    public_status = (
                        "done"
                        if prior_state == "DONE"
                        else "error"
                        if prior_state == "FAILED"
                        else "cancelled"
                        if prior_state in {"CANCEL_REQUESTED", "CANCELLED"}
                        else "processing"
                    )
                    recovered_response = {
                        "ok": True,
                        "jobId": prior_job_id,
                        "parentJobId": prior_job_id,
                        "subjobs": [],
                        "accessToken": claim.access_token,
                        "meta": {
                            "status": public_status,
                            "progressPct": 100 if public_status == "done" else 1,
                            "progressMessage": "Bestaande aanvraag hervat",
                            "queuePosition": 0,
                        },
                    }
                    recovered_response = self.dependencies._recover_public_job_idempotency(
                        key=self.idempotency_key,
                        payload_sha256=self.idempotency_payload_sha256,
                        response=recovered_response,
                    )
                    return self._reply(recovered_response, 202)
            except Exception as recovery_error:
                report_recovery("metod_app.jobs.lifecycle.api_create_job.580", recovery_error)
            return self._reply(
                {
                    "ok": False,
                    "error": "De oorspronkelijke jobaanvraag wordt nog verwerkt. Probeer dezelfde aanvraag opnieuw.",
                    "retryable": True,
                },
                425,
            )
        if claim.kind != "owner":
            raise RuntimeError("Invalid job idempotency claim result")
        self.idempotency_owned = True
        self.idempotency_owner_nonce = claim.owner_nonce

    def authorize_capacity(self):
        if not self.fresh_rate_authorized and (
            not self.dependencies._rate_limit_allow(
                "api_jobs",
                self.ip,
                max(1, min(300, self.dependencies._env_int("PUBLIC_JOB_RATE_PER_FIVE_MINUTES", 42))),
                300,
            )
        ):
            try:
                self.dependencies._append_system_event(
                    level="warning",
                    component="jobs",
                    message_user="Publieke jobroute rate-limited",
                    message_tech="api_jobs rate limit",
                    status="open",
                )
            except Exception as recovery_error:
                report_recovery("metod_app.jobs.lifecycle.api_create_job.598", recovery_error)
            return self._reply({"ok": False, "error": self.dependencies._public_error_message(429)}, 429)
        self.payload = self.handler._canonicalize_public_job_payload(self.payload)
        self.acquired, slot_reason = self.dependencies._try_acquire_public_job_slot(self.ip)
        if not self.acquired:
            try:
                self.dependencies._append_system_event(
                    level="warning",
                    component="jobs",
                    message_user="Publieke optimalisatiecapaciteit bereikt",
                    message_tech=f"api_jobs admission block ({slot_reason})",
                    status="open",
                )
            except Exception as recovery_error:
                report_recovery("metod_app.jobs.lifecycle.api_create_job.614", recovery_error)
            max_active, max_queued, max_per_ip = self.dependencies._public_job_queue_limits()
            if slot_reason == "ip":
                error = "Er staan al aanvragen vanaf dit netwerkadres in verwerking of in de wachtrij. Wacht tot er één klaar is en probeer het opnieuw."
            else:
                error = "De optimalisatiewachtrij is vol. Wacht even en probeer het daarna opnieuw."
            return self._reply(
                {
                    "ok": False,
                    "error": error,
                    "busy": True,
                    "queueFull": slot_reason == "queue_full",
                    "maxConcurrentOptimizations": max_active,
                    "maxQueuedOptimizations": max_queued,
                    "maxOptimizationsPerIp": max_per_ip,
                },
                429,
            )
        try:
            top_level_keys = set(self.payload.keys())
            if top_level_keys and len(top_level_keys) > 64:
                return self._reply({"ok": False, "error": "Ongeldige aanvraag."}, 400)
        except Exception as recovery_error:
            report_recovery("metod_app.jobs.lifecycle.api_create_job.635", recovery_error)
        qty_limit = self.dependencies._env_int("PUBLIC_JOB_TOTAL_QTY_LIMIT", 250)
        area_lb_limit = self.dependencies._env_int("PUBLIC_JOB_MAX_AREA_LB", 250)
        total_qty = self.dependencies._enforce_job_total_qty_limit(self.payload, qty_limit)
        self.pricing_authority, authoritative_pricing = (
            self.dependencies._capture_public_job_pricing_authority(self.payload["panelsCsv"])
        )
        self.payload = dict(self.payload)
        self.payload["pricingAuthority"] = self.pricing_authority
        area_info = self.dependencies._estimate_payload_area_lower_bound(
            {"panelsCsv": self.payload["panelsCsv"], "pricing": authoritative_pricing}
        )
        max_area_lb = int((area_info or {}).get("maxAreaLowerBound") or 0)
        try:
            self.dependencies._append_client_log(
                "server",
                "api_jobs_preflight",
                "Public job guards passed",
                {
                    "totalQty": int(total_qty),
                    "limitQty": int(qty_limit),
                    "maxAreaLowerBound": int(max_area_lb),
                    "maxAreaLowerBoundLimit": int(area_lb_limit),
                },
            )
        except Exception as recovery_error:
            report_recovery("metod_app.jobs.lifecycle.api_create_job.657", recovery_error)
        if max_area_lb > int(area_lb_limit):
            return self._reply(
                {
                    "ok": False,
                    "error": f"Deze configuratie is te groot voor één aanvraag. De geschatte minimale plaatbehoefte is minstens {max_area_lb} platen. Splits de bestelling op in meerdere aanvragen.",
                },
                413,
            )
        family_estimate = self.dependencies._estimate_preflight_job_family_bytes(self.payload)
        if int(family_estimate.get("projectedTotalBytes") or 0) > int(self.JOB_OUTPUT_MAX_BYTES):
            return self._reply(
                {
                    "ok": False,
                    "error": self.dependencies._job_output_limit_message(
                        int(family_estimate.get("projectedTotalBytes") or 0), int(self.JOB_OUTPUT_MAX_BYTES)
                    ),
                },
                413,
            )
        self.dependencies._reserve_state_capacity(
            self.master_job_id,
            int(family_estimate.get("projectedTotalBytes") or 0),
            projected_inodes=max(
                256,
                int(family_estimate.get("totalQty") or 0) * 8 + int(family_estimate.get("dxfCount") or 0) * 4,
            ),
        )
        self.storage_reserved = True

    def persist_acceptance(self):
        created_at = self.dependencies._now_iso()
        job_root = self.JOBS / self.master_job_id
        job_root.mkdir(parents=False, exist_ok=False)
        (job_root / "input").mkdir(parents=False, exist_ok=False)
        (job_root / "output").mkdir(parents=False, exist_ok=False)
        self.dependencies.fsync_directory(self.JOBS)
        self.dependencies._atomic_write_json(
            job_root / "input" / "pricing_authority.json", self.pricing_authority, mode=416
        )
        self.dependencies._atomic_write_json(
            job_root / ".public_access.json",
            {
                "token": self.access_token,
                "jobId": self.master_job_id,
                "updatedAt": self.dependencies._utc_now_iso(),
            },
        )
        self.dependencies._save_job_runtime_state(self.master_job_id, "ACCEPTED")
        self.accepted_state_created = True
        complexity = self.handler._estimate_job_complexity(self.payload)
        with self._job_lock:
            self._job_meta[self.master_job_id] = {
                "status": "processing",
                "createdAt": created_at,
                "acceptedAt": created_at,
                "progressPct": 1,
                "progressMessage": "Aanvraag gestart",
                "phase": "accepted",
                "complexity": complexity,
            }

    def schedule_execution(self):
        scheduling = self.handler._start_async_job_create(
            self.payload, self.master_job_id, self.access_token, self.ip
        )
        self.slot_handed_off = True
        scheduling_status = str(scheduling.get("status") or "queued")
        queue_position = max(0, int(scheduling.get("queuePosition") or 0))
        if scheduling_status == "queued":
            progress_message = f"Wachtrij: positie {queue_position}"
        else:
            progress_message = "Optimalisatie wordt gestart…"
        accepted_response = {
            "ok": True,
            "jobId": self.master_job_id,
            "parentJobId": self.master_job_id,
            "subjobs": [],
            "accessToken": self.access_token,
            "meta": {
                "status": scheduling_status,
                "progressPct": 1,
                "progressMessage": progress_message,
                "queuePosition": queue_position,
            },
        }
        self.dependencies._complete_public_job_idempotency(
            key=self.idempotency_key,
            payload_sha256=self.idempotency_payload_sha256,
            owner_nonce=self.idempotency_owner_nonce,
            response=accepted_response,
        )
        return self._reply(accepted_response, 202)

    def handle_failure(self, e):
        err_text = str(e)
        if self.accepted_state_created and (not self.slot_handed_off):
            try:
                self.dependencies._save_job_runtime_state(
                    self.master_job_id, "FAILED", reason="job-admission-handoff-failed", retryable=True
                )
            except Exception as recovery_error:
                report_recovery("metod_app.jobs.lifecycle.api_create_job.754", recovery_error)
        if err_text.startswith("JOB_PAYLOAD_TOO_LARGE::"):
            try:
                _, actual_s, limit_s = err_text.split("::", 2)
                actual_mb = float(actual_s) / 1024.0 / 1024.0
                limit_mb = float(limit_s) / 1024.0 / 1024.0
                return self._reply(
                    {
                        "ok": False,
                        "error": f"Deze aanvraag is te groot om veilig te verwerken ({actual_mb:.1f} MB). Het maximum is {limit_mb:.0f} MB. Splits de job op in meerdere delen en probeer het opnieuw.",
                    },
                    413,
                )
            except Exception as recovery_error:
                report_recovery("metod_app.jobs.admission_request.boundary.204", recovery_error)
                return self._reply(
                    {
                        "ok": False,
                        "error": "Deze aanvraag is te groot om veilig te verwerken. Splits de job op in meerdere delen en probeer het opnieuw.",
                    },
                    413,
                )
        if err_text.startswith("JOB_TOTAL_QTY_TOO_LARGE::"):
            try:
                _, actual_s, limit_s = err_text.split("::", 2)
                return self._reply(
                    {
                        "ok": False,
                        "error": f"Deze aanvraag bevat te veel panelen om veilig te verwerken ({int(actual_s)}). Het maximum is {int(limit_s)} panelen. Splits de job op in meerdere delen.",
                    },
                    413,
                )
            except Exception as recovery_error:
                report_recovery("metod_app.jobs.admission_request.boundary.210", recovery_error)
                return self._reply(
                    {
                        "ok": False,
                        "error": "Deze aanvraag bevat te veel panelen om veilig te verwerken. Splits de job op in meerdere delen.",
                    },
                    413,
                )
        if err_text == "JOB_BUSINESS_AUTHORITY_UNAVAILABLE":
            return self._reply(
                {
                    "ok": False,
                    "error": "De actuele catalogus en prijsinstellingen wachten op Admin-goedkeuring. Probeer het later opnieuw.",
                    "retryable": True,
                },
                503,
            )
        try:
            self.handler._write_api_jobs_crashlog(
                "api_create_job_exception",
                self.payload if isinstance(self.payload, dict) else None,
                e,
                {"path": "/api/jobs", "contentLength": str(self.handler.headers.get("Content-Length") or "")},
            )
        except Exception as recovery_error:
            report_recovery("metod_app.jobs.lifecycle.api_create_job.793", recovery_error)
        if self.accepted_state_created or (
            self.idempotency_claim_attempted
            and (not self.idempotency_claim_finished)
            and (not isinstance(e, ValueError))
        ):
            return self._reply(
                {
                    "ok": False,
                    "error": "De jobaanvraag is mogelijk al vastgelegd. Dezelfde aanvraag wordt opnieuw gecontroleerd.",
                    "retryable": True,
                },
                425,
            )
        if isinstance(e, PublicJobInputError):
            return self._reply({"ok": False, "code": e.code, "error": e.public_message}, 400)
        if isinstance(e, ValueError):
            return self._reply(
                {
                    "ok": False,
                    "code": "INVALID_CONFIGURATION",
                    "error": "Controleer de panelen en materiaalkeuze. Herlaad de catalogus als deze intussen is aangepast.",
                },
                400,
            )
        return self._reply(
            {
                "ok": False,
                "code": "JOB_CREATION_UNAVAILABLE",
                "error": "De berekening kan tijdelijk niet worden gestart. Probeer het opnieuw.",
            },
            500,
        )

    def cleanup(self):
        if self.idempotency_owned and (not self.accepted_state_created):
            try:
                self.dependencies._abandon_public_job_idempotency(
                    key=self.idempotency_key,
                    payload_sha256=self.idempotency_payload_sha256,
                    owner_nonce=self.idempotency_owner_nonce,
                )
            except Exception as recovery_error:
                report_recovery("metod_app.jobs.lifecycle.api_create_job.821", recovery_error)
        if self.storage_reserved and (not self.slot_handed_off):
            self.dependencies._release_state_capacity_reservation(self.master_job_id)
        if self.acquired and (not self.slot_handed_off):
            self.dependencies._release_public_job_slot(self.ip)

    def run(self):
        try:
            self.read_request()
            if self.finished:
                return self.response
            self.claim_idempotency()
            if self.finished:
                return self.response
            self.authorize_capacity()
            if self.finished:
                return self.response
            self.persist_acceptance()
            if self.finished:
                return self.response
            self.schedule_execution()
            if self.finished:
                return self.response
        except Exception as error:
            report_recovery("metod_app.jobs.admission_request.boundary.254", error)
            return self.handle_failure(error)
        finally:
            self.cleanup()
