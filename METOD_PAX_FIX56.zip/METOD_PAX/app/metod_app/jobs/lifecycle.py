"""Explicit request dependencies and bounded lifecycle operations."""

from __future__ import annotations
from metod_app.observability.failures import report_recovery
import json
import time
import traceback
import uuid
from typing import Any
from .lifecycle_contracts import (
    JobLifecycleDependencies as JobLifecycleDependencies,
    public_job_meta_projection as public_job_meta_projection,
)
from .admission_request import JobAdmissionRequest
from .status_request import JobStatusRequest


class JobLifecycleFacadeService:
    def __init__(self, dependencies: JobLifecycleDependencies) -> None:
        self.dependencies = dependencies

    def api_cancel_job(self, handler, parsed=None):
        """Durably cancel a job and terminate its active optimizer process."""
        d = self.dependencies
        JOBS = d.JOBS()
        _OPTIMIZER_PROCESS_SUPERVISOR = d._OPTIMIZER_PROCESS_SUPERVISOR()
        _cancel_queued_public_job = d._cancel_queued_public_job
        _client_ip = d._client_ip
        _job_lock = d._job_lock()
        _job_meta = d._job_meta()
        _now_iso = d._now_iso
        _rate_limit_allow = d._rate_limit_allow
        _read_json_body_limited = d._read_json_body_limited
        _transition_job_runtime_state = d._transition_job_runtime_state
        _terminate_optimizer_process = d._terminate_optimizer_process
        resolve_identifier_child = d.resolve_identifier_child
        validate_job_id = d.validate_job_id
        ip = _client_ip(handler)
        if not _rate_limit_allow("cancel_job", ip, 20, 300):
            return handler._send_json(
                {"ok": False, "error": "Te veel verzoeken. Probeer het later opnieuw."}, 429
            )
        try:
            payload = _read_json_body_limited(handler, "PUBLIC_JSON_MAX_BYTES", 262144)
            job_id = validate_job_id(payload.get("jobId") or payload.get("parentJobId"))
            job_root = resolve_identifier_child(JOBS, job_id)
        except Exception as recovery_error:
            report_recovery("metod_app.jobs.lifecycle.boundary.41", recovery_error)
            return handler._send_json({"ok": False, "error": "Ongeldige job."}, 400)
        if not job_root.is_dir():
            return handler._send_json({"ok": False, "error": "Job niet gevonden."}, 404)
        if not handler._require_job_access(job_id, parsed=parsed, body=payload, deny_as_json=True):
            return
        if "__mat_" in job_id:
            return handler._send_json(
                {"ok": False, "error": "Annuleer de volledige berekening via de hoofdjob."}, 409
            )
        try:
            changed, state_record = _transition_job_runtime_state(
                job_id,
                "CANCEL_REQUESTED",
                allowed_from={"ACCEPTED", "PREPARING", "PROCESSING", "FINALIZING", "CANCEL_REQUESTED"},
                reason="user-cancelled",
            )
        except Exception as recovery_error:
            report_recovery("metod_app.jobs.lifecycle.boundary.51", recovery_error)
            return handler._send_json(
                {
                    "ok": False,
                    "jobId": job_id,
                    "state": "unknown",
                    "error": "De jobstatus kon niet veilig worden geverifieerd.",
                },
                409,
            )
        current_state = str((state_record or {}).get("state") or "").upper()
        if not changed and current_state == "CANCELLED":
            return handler._send_json({"ok": True, "jobId": job_id, "state": "cancelled"})
        if not changed and current_state != "CANCEL_REQUESTED":
            return handler._send_json(
                {
                    "ok": False,
                    "jobId": job_id,
                    "state": current_state.lower() or "unknown",
                    "error": "Deze berekening kan niet meer worden geannuleerd.",
                },
                409,
            )
        _cancel_queued_public_job(job_id)
        processes = _OPTIMIZER_PROCESS_SUPERVISOR.active(job_id)
        for process in processes:
            if process.poll() is not None:
                continue
            _terminate_optimizer_process(process)
        _transition_job_runtime_state(job_id, "CANCELLED", reason="user-cancelled")
        with _job_lock:
            meta = _job_meta.get(job_id, {}) or {}
            meta.update({"status": "cancelled", "phase": "cancelled", "finishedAt": _now_iso()})
            _job_meta[job_id] = meta
        return handler._send_json({"ok": True, "jobId": job_id, "state": "cancelled"})

    def estimate_job_complexity(self, handler, payload: dict) -> dict:
        d = self.dependencies
        _dxf_transport_stats = d._dxf_transport_stats
        _estimate_payload_area_lower_bound = d._estimate_payload_area_lower_bound
        try:
            panels_csv = str((payload or {}).get("panelsCsv") or "")
        except Exception as recovery_error:
            report_recovery("metod_app.jobs.lifecycle.boundary.77", recovery_error)
            panels_csv = ""
        try:
            dxf_stats = _dxf_transport_stats(payload or {})
            dxf_count = int(dxf_stats.get("logicalCount") or 0)
            dxf_unique_count = int(dxf_stats.get("uniqueCount") or 0)
            dxf_unique_bytes = int(dxf_stats.get("uniqueBytes") or 0)
        except Exception as recovery_error:
            report_recovery("metod_app.jobs.lifecycle.boundary.84", recovery_error)
            dxf_count = 0
            dxf_unique_count = 0
            dxf_unique_bytes = 0
        try:
            panel_rows = max(0, len([ln for ln in panels_csv.splitlines() if ln.strip()]) - 1)
        except Exception as recovery_error:
            report_recovery("metod_app.jobs.lifecycle.boundary.90", recovery_error)
            panel_rows = 0
        try:
            approx_bytes = (
                len(panels_csv.encode("utf-8"))
                + dxf_unique_bytes
                + len(json.dumps((payload or {}).get("jobJson") or {}, ensure_ascii=False).encode("utf-8"))
            )
        except Exception as recovery_error:
            report_recovery("metod_app.jobs.lifecycle.boundary.94", recovery_error)
            approx_bytes = dxf_unique_bytes
        try:
            area_info = _estimate_payload_area_lower_bound(payload)
        except Exception as recovery_error:
            report_recovery("metod_app.jobs.lifecycle.boundary.98", recovery_error)
            area_info = {"maxAreaLowerBound": 0}
        return {
            "panelRows": panel_rows,
            "dxfCount": dxf_count,
            "dxfUniqueBodies": dxf_unique_count,
            "approxBytes": approx_bytes,
            "maxAreaLowerBound": int((area_info or {}).get("maxAreaLowerBound") or 0),
        }

    def start_async_job_create(
        self, handler, payload: dict, master_job_id: str, public_access_token: str = "", acquired_ip: str = ""
    ) -> dict[str, Any]:
        d = self.dependencies
        JOBS = d.JOBS()
        JobCancelledError = d.JobCancelledError
        SafetyContractError = d.SafetyContractError
        _commit_public_job_slot = d._commit_public_job_slot
        _create_job_from_payload = d._create_job_from_payload
        _finalization_complete = d._finalization_complete
        _job_cancel_requested = d._job_cancel_requested
        _job_lock = d._job_lock()
        _job_meta = d._job_meta()
        _now_iso = d._now_iso
        _save_job_runtime_state = d._save_job_runtime_state
        durable_write_text = d.durable_write_text
        resolve_identifier_child = d.resolve_identifier_child

        def _runner():
            try:
                if _job_cancel_requested(master_job_id):
                    raise JobCancelledError("Job was cancelled before optimizer start")
                _create_job_from_payload(
                    payload, master_job_id=master_job_id, public_access_token=public_access_token
                )
                if _job_cancel_requested(master_job_id):
                    raise JobCancelledError("Job was cancelled before publication")
                if not _finalization_complete(resolve_identifier_child(JOBS, master_job_id), _memo={}):
                    raise SafetyContractError("Final job family integrity verification failed")
                _save_job_runtime_state(master_job_id, "DONE")
                with _job_lock:
                    meta = _job_meta.get(master_job_id, {}) or {}
                    meta["status"] = "done"
                    meta["progressPct"] = 100
                    meta["progressMessage"] = "Optimalisatie afgerond"
                    meta["phase"] = "done"
                    meta["finishedAt"] = _now_iso()
                    _job_meta[master_job_id] = meta
            except Exception as e:
                cancelled = isinstance(e, JobCancelledError) or _job_cancel_requested(master_job_id)
                try:
                    jr = resolve_identifier_child(JOBS, master_job_id)
                    (jr / "output").mkdir(parents=True, exist_ok=True)
                    durable_write_text(jr / "output" / "create_job_error.txt", str(e))
                except Exception as recovery_error:
                    report_recovery("metod_app.jobs.lifecycle._runner.334", recovery_error)
                _save_job_runtime_state(
                    master_job_id,
                    "CANCELLED" if cancelled else "FAILED",
                    reason="user-cancelled" if cancelled else str(e)[:500],
                    retryable=not cancelled,
                )
                with _job_lock:
                    meta = _job_meta.get(master_job_id, {}) or {}
                    meta["status"] = "cancelled" if cancelled else "error"
                    meta["phase"] = "cancelled" if cancelled else "failed"
                    meta["finishedAt"] = _now_iso()
                    if not cancelled:
                        meta["error"] = str(e)
                    _job_meta[master_job_id] = meta

        return _commit_public_job_slot(acquired_ip, master_job_id, _runner)

    def write_api_jobs_crashlog(
        self,
        handler,
        label: str,
        payload: dict | None = None,
        err: Exception | None = None,
        extra: dict | None = None,
    ) -> None:
        d = self.dependencies
        JOBS = d.JOBS()
        _atomic_write_json = d._atomic_write_json
        _now_iso = d._now_iso
        _redact_sensitive_text = d._redact_sensitive_text
        try:
            log_dir = JOBS / "_crash_logs"
            log_dir.mkdir(parents=True, exist_ok=True)
            ts = time.strftime("%Y%m%d_%H%M%S_") + uuid.uuid4().hex[:6]
            rec = {
                "ts": _now_iso(),
                "label": label,
                "error": _redact_sensitive_text(str(err), 600) if err else "",
                "traceback": _redact_sensitive_text(traceback.format_exc(), 4000) if err else "",
                "extra": extra or {},
            }
            if isinstance(payload, dict):
                try:
                    rec["complexity"] = handler._estimate_job_complexity(payload)
                except Exception as recovery_error:
                    report_recovery("metod_app.jobs.lifecycle.write_api_jobs_crashlog.372", recovery_error)
                try:
                    rec["payload_keys"] = sorted(list(payload.keys()))
                except Exception as recovery_error:
                    report_recovery("metod_app.jobs.lifecycle.write_api_jobs_crashlog.376", recovery_error)
            _atomic_write_json(log_dir / f"api_jobs_{ts}.json", rec)
        except Exception as recovery_error:
            report_recovery("metod_app.jobs.lifecycle.write_api_jobs_crashlog.379", recovery_error)

    def api_create_job(self, handler):
        return JobAdmissionRequest(self.dependencies, handler).run()

    def api_status(self, handler, job_id, parsed=None):
        return JobStatusRequest(self.dependencies, handler, job_id, parsed).run()
