"""Pure construction and classification of the existing job-state document."""

from __future__ import annotations


from typing import Any, Callable, Mapping

from .contracts import (
    ACTIVE_JOB_STATES,
    CANCELLATION_JOB_STATES,
    JOB_STATE_SCHEMA_VERSION,
    TERMINAL_JOB_STATES,
    canonical_job_state,
    state_from_record,
)


NowIso = Callable[[], str]


def build_job_runtime_state(
    *,
    job_id: str,
    state: object,
    previous: Mapping[str, Any],
    now_iso: NowIso,
    extra: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Build the exact schema-v1 document without owning validation or I/O.

    ``now_iso`` remains injected and is called with the same short-circuit and
    ordering semantics as the former inline owner. Extra values intentionally
    remain last, preserving the established keyword-override behavior.
    """

    value: dict[str, Any] = {
        "schemaVersion": JOB_STATE_SCHEMA_VERSION,
        "jobId": job_id,
        "state": canonical_job_state(state),
        "createdAt": previous.get("createdAt") or now_iso(),
        "updatedAt": now_iso(),
        **dict(extra or {}),
    }
    return value


def job_cancel_requested(record: object) -> bool:
    return state_from_record(record) in CANCELLATION_JOB_STATES


def job_state_transition_allowed(current: object, target: object) -> bool:
    """Return whether one durable job-state transition is monotone.

    An empty source is retained for internal/legacy callers that create their
    first durable record directly.  Once a terminal state exists it is
    immutable; cancellation and successful completion can therefore never win
    a last-writer-wins race against each other.
    """

    source = canonical_job_state(current) if current not in (None, "") else ""
    destination = canonical_job_state(target)
    known = ACTIVE_JOB_STATES | CANCELLATION_JOB_STATES | TERMINAL_JOB_STATES
    if destination not in known:
        return False
    if not source:
        return True
    if source == destination:
        return True
    if source in TERMINAL_JOB_STATES:
        return False
    if source == "CANCEL_REQUESTED":
        return destination == "CANCELLED"
    if source not in ACTIVE_JOB_STATES:
        return False
    if destination in {"DONE", "FAILED", "CANCEL_REQUESTED"}:
        return True
    if destination in ACTIVE_JOB_STATES:
        rank = {
            "ACCEPTED": 0,
            "PREPARING": 1,
            "PROCESSING": 2,
            "FINALIZING": 3,
        }
        return rank[destination] >= rank[source]
    return False


def startup_recovery_decision(record: object) -> tuple[str, dict[str, Any]] | None:
    """Return the existing post-restart durable transition, if required."""

    current = state_from_record(record)
    if current == "CANCEL_REQUESTED":
        return "CANCELLED", {"reason": "startup-reconciliation"}
    if current in ACTIVE_JOB_STATES:
        return "FAILED", {
            "reason": "service-restarted-during-processing",
            "retryable": True,
        }
    return None


__all__ = (
    "build_job_runtime_state",
    "job_cancel_requested",
    "job_state_transition_allowed",
    "startup_recovery_decision",
)
