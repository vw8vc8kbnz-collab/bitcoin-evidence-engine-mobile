"""Durable startup reconciliation for interrupted optimizer job families."""

from __future__ import annotations

from metod_app.observability.failures import report_recovery


from typing import Any, Callable


RecoveryDecision = Callable[[object], tuple[str, dict[str, Any]] | None]


class JobRestartReconciler:
    """Scan durable job states and apply the existing pure recovery decision.

    Paths, validation, durable writes and event publication stay injected by the
    composition root. This owner does not infer completion from artifacts and
    never starts, resumes or executes an optimizer.
    """

    def __init__(
        self,
        *,
        jobs_root: Any,
        read_json: Callable[[Any], Any],
        validate_job_id: Callable[[Any], str],
        save_runtime_state: Callable[..., dict[str, Any]],
        append_system_event: Callable[..., None],
    ) -> None:
        self.jobs_root = jobs_root
        self.read_json = read_json
        self.validate_job_id = validate_job_id
        self.save_runtime_state = save_runtime_state
        self.append_system_event = append_system_event

    def reconcile(self, *, recovery_decision: RecoveryDecision) -> int:
        reconciled = 0
        for path in sorted(self.jobs_root.glob("*/job_state.json")):
            try:
                state = self.read_json(path)
                job_id = self.validate_job_id(path.parent.name)
                decision = recovery_decision(state)
                if decision is not None:
                    next_state, extra = decision
                    self.save_runtime_state(job_id, next_state, **extra)
                    reconciled += 1
            except Exception as exc:
                report_recovery("metod_app.jobs.reconciliation.boundary.46", exc)
                self.append_system_event(
                    level="error",
                    component="jobs",
                    message_user="Jobstate-reconciliatie mislukt",
                    message_tech=str(exc),
                    job_id=path.parent.name,
                    status="open",
                )
        return reconciled


__all__ = ("JobRestartReconciler",)
