"""Execute one canonical job family with explicit preparation/optimizer/seal phases."""

from __future__ import annotations

import json
import subprocess
import time
import uuid

from safety_contracts import (
    ContractError,
    durable_write_many_bytes,
    fsync_directory,
    resolve_identifier_child,
    strict_json_dumps,
    strict_json_load,
    strict_json_loads,
    validate_job_id,
)
from metod_app.config import env_int
from metod_app.jobs.process_supervisor import OptimizerDeadline
from metod_app.observability.failures import report_recovery
from metod_app.pricing.authority import validate_job_pricing_authority
from metod_app.pricing.tax import VAT_RATE
from metod_app.runtime.ports import JobsExecutionPorts


def job_family_progress_segment(index: int, total_subjobs: int) -> tuple[int, int, int, int]:
    """Return prepare, optimizer, summary and completed percentages for one subjob.

    All material work shares 5..94.  The master finalizer exclusively owns
    95..99 and the durable DONE transition owns 100.
    """

    total = max(1, int(total_subjobs))
    bounded_index = max(1, min(total, int(index)))
    start = 5 + int(round(((bounded_index - 1) / float(total)) * 89.0))
    done = 5 + int(round((bounded_index / float(total)) * 89.0))
    summary = max(start, done - 1)
    optimizer = max(start, summary - 1)
    return start, optimizer, summary, done


def job_family_live_progress(completed_subjobs: int, current_subjob_pct: float, total_subjobs: int) -> int:
    """Map discovered live subjob state to the same monotone 5..94 scale."""

    total = max(1, int(total_subjobs))
    completed = max(0, min(total, int(completed_subjobs)))
    if completed >= total:
        return 94
    start, optimizer, _summary, _done = job_family_progress_segment(completed + 1, total)
    raw_pct = max(0.0, min(100.0, float(current_subjob_pct)))
    mapped = start + int(round((raw_pct / 100.0) * max(0, optimizer - start)))
    return max(start, min(optimizer, mapped))


class JobExecution:
    """Per-invocation state; shared services enter through the typed port contract."""

    def __init__(self, ports, payload, master_job_id, public_access_token):
        if not isinstance(payload, dict) or payload.get("payloadSchema") != "FIX660R8_SERVER_CANONICAL_V1":
            raise ContractError("Internal job payload is not server-canonical")
        self.ports = ports
        self.started = time.perf_counter()
        self.deadline = OptimizerDeadline.start(
            monotonic=time.monotonic,
            timeout_seconds=max(1, min(86400, env_int("OPTIMIZER_JOB_TIMEOUT_SECONDS", 900))),
        )
        self.job_id = validate_job_id(
            str(master_job_id or (time.strftime("%Y%m%d_%H%M%S_") + uuid.uuid4().hex[:6]))
        )
        self.root = resolve_identifier_child(ports.get_jobs(), self.job_id)
        self.input = self.root / "input"
        self.output = self.root / "output"
        self.token = str(public_access_token)
        self.csv = payload.get("panelsCsv", "")
        self.blobs, self.part_refs = ports.validated_canonical_dxf_transport(payload)
        if not self.csv or not self.part_refs:
            raise ValueError("Missing panelsCsv or DXF geometry")
        rows = ports.parse_panels_csv(self.csv)
        missing = {str(row.get("PartId") or "").strip() for row in rows} - set(self.part_refs) - {""}
        if missing:
            raise ValueError(f"DXF-geometrie ontbreekt voor {len(missing)} paneelregel(s).")
        self.codes = list(dict.fromkeys(str(row.get("MaterialCode") or "").strip() for row in rows))
        self.codes = [code for code in self.codes if code]
        self.pricing = self._pricing_snapshot(payload, rows)
        self.job = dict(payload.get("jobJson") or {})
        for key in ("sheetMarginMm", "nestingGapMm", "kerfMm"):
            value = self.pricing.get("defaults", {}).get(key)
            if value is not None:
                self.job[key] = float(value)
        self.refs = {
            "schemaVersion": 1,
            "algorithm": "sha256",
            "partRefs": {key: self.part_refs[key] for key in sorted(self.part_refs)},
        }
        self.subjobs = []
        self.subjob_roots = []
        self.finalized_hashes = {}
        self.timing = {
            "schemaVersion": 1,
            "startedAt": ports.utc_now_iso(),
            "masterJobId": self.job_id,
            "subjobs": [],
            "masterDxfFiles": len(self.part_refs),
            "masterDxfUniqueBodies": len(self.blobs),
            "masterDxfHardlinks": 0,
            "masterDxfStorageMode": "content_addressed_refs_v1",
        }

    def _pricing_snapshot(self, payload, rows):
        authority_path = self.input / "pricing_authority.json"
        authority = (
            strict_json_load(authority_path) if authority_path.is_file() else payload.get("pricingAuthority")
        )
        if isinstance(authority, dict):
            pricing, sell = validate_job_pricing_authority(authority, panel_rows=rows)
        else:
            # Trusted internal callers also capture a single immutable snapshot.
            config = self.ports.load_pricing_config()
            config = config if isinstance(config, dict) else {}
            base = config.get("pricing")
            if not isinstance(base, dict):
                base = strict_json_load(self.ports.get_pricing_seed_path())
            pricing = self.ports.ensure_pricing_materials(
                strict_json_loads(strict_json_dumps(base)), self.csv
            )
            sell = config.get("sellPricing") or {}
            pricing["vatRate"] = VAT_RATE
        pricing["sellPricing"] = strict_json_loads(strict_json_dumps(sell))
        return pricing

    def _progress(self, percent, message, phase, **fields):
        with self.ports.get_job_lock():
            metadata = self.ports.get_job_meta()
            record = dict(metadata.get(self.job_id) or {})
            record.update(
                status="processing",
                createdAt=record.get("createdAt") or self.ports.now_iso(),
                progressPct=max(int(record.get("progressPct") or 0), percent),
                progressMessage=message,
                phase=phase,
                **fields,
            )
            metadata[self.job_id] = record

    def _check(self, phase):
        self.deadline.check_family(phase)
        if self.ports.job_cancel_requested(self.job_id):
            raise self.ports.JobCancelledError(f"Job cancelled during {phase}")

    def _limit_output(self):
        self.ports.enforce_job_output_limit(self.root, self.subjob_roots)

    def _token_file(self, root, *, preserve=False):
        path = root / ".public_access.json"
        if self.token and not (preserve and path.exists()):
            self.ports.atomic_write_json(
                path, {"token": self.token, "jobId": root.name, "updatedAt": self.ports.utc_now_iso()}
            )

    def _prepare_master(self):
        self.input.mkdir(parents=True, exist_ok=True)
        self.output.mkdir(parents=True, exist_ok=True)
        self._token_file(self.root, preserve=True)
        self._progress(3, "Voorbereiden van de job…", "prepare")
        blobs_dir = self.input / "dxf_blobs"
        blobs_dir.mkdir(parents=True, exist_ok=True)
        entries = [
            (self.input / "panels.csv", self.csv.encode("utf-8"), 0o640),
            (self.input / "pricing.json", json.dumps(self.pricing, indent=2).encode(), 0o640),
            (self.input / "job.json", json.dumps(self.job, indent=2).encode(), 0o600),
            (
                self.input / "dxf_part_refs.json",
                (strict_json_dumps(self.refs, indent=2) + "\n").encode(),
                0o640,
            ),
        ]
        entries.extend(
            (blobs_dir / f"{key}.dxf", text.encode("utf-8"), 0o640)
            for key, text in sorted(self.blobs.items())
        )
        durable_write_many_bytes(entries)
        self.prepared = time.perf_counter()
        self.timing["acceptedToPreparedSeconds"] = round(max(0.0, self.prepared - self.started), 3)
        self._limit_output()

    def _material_inputs(self, root, code):
        inputs = root / "input"
        outputs = root / "output"
        inputs.mkdir(parents=True, exist_ok=True)
        outputs.mkdir(parents=True, exist_ok=True)
        fsync_directory(self.ports.get_jobs())
        self._token_file(root)
        directories = set()

        def link(source, destination):
            if self.ports.link_or_copy_file(source, destination) == "hardlink":
                directories.add(destination.parent)

        csv = self.ports.filter_panels_csv_by_material(self.csv, code)
        if len(self.codes) == 1 or csv == self.csv:
            csv = self.csv
            link(self.input / "panels.csv", inputs / "panels.csv")
        else:
            self.ports.write_file(inputs / "panels.csv", csv)
        for name in ("pricing.json", "job.json"):
            link(self.input / name, inputs / name)
        part_ids = dict.fromkeys(
            str(row.get("PartId") or "").strip() for row in self.ports.parse_panels_csv(csv)
        )
        refs = {part_id: self.part_refs[part_id] for part_id in part_ids if part_id}
        blobs_dir = inputs / "dxf_blobs"
        blobs_dir.mkdir(parents=True, exist_ok=True)
        for blob_id in sorted(set(refs.values())):
            link(self.input / "dxf_blobs" / f"{blob_id}.dxf", blobs_dir / f"{blob_id}.dxf")
        document = {"schemaVersion": 1, "algorithm": "sha256", "partRefs": dict(sorted(refs.items()))}
        if document == self.refs:
            link(self.input / "dxf_part_refs.json", inputs / "dxf_part_refs.json")
        else:
            self.ports.atomic_write_json(inputs / "dxf_part_refs.json", document)
        for directory in sorted(directories):
            fsync_directory(directory)
        with self.ports.get_job_lock():
            record = self.ports.get_job_meta()[self.job_id]
            record["subjobIds"] = list(dict.fromkeys([*(record.get("subjobIds") or []), root.name]))
        self._limit_output()

    def _publish_optimizer_progress(self, root, index):
        try:
            progress = strict_json_load(root / "output/progress.json")
            if not isinstance(progress, dict) or progress.get("percent") is None:
                return
            percent = max(0, min(100, float(progress["percent"])))
        except (OSError, ValueError, TypeError):
            return  # Tool B replaces this optional progress file asynchronously.
        mapped = job_family_live_progress(index - 1, percent, len(self.codes))
        message = str(
            progress.get("message")
            or progress.get("phase")
            or f"Materiaal {index}/{len(self.codes)} optimaliseren…"
        )
        self._progress(
            mapped,
            message,
            "subjob_progress",
            currentSubjobIndex=index,
            subjobsTotal=len(self.codes),
            updatedAt=self.ports.utc_now_iso(),
        )

    def _diagnostic(self, path, value, *, text=False):
        try:
            writer = self.ports.write_replaceable_text if text else self.ports.write_replaceable_json
            writer(path, value)
        except OSError as error:
            report_recovery("jobs.optional_diagnostic_write", error)

    def _run_optimizer(self, root, index):
        self._check("optimizer start")
        app = self.ports.get_root()
        command = self.ports.get_python_base_cmd() + [
            "-u",
            str(app / self.ports.get_optimizer_tool_b()),
            "--input",
            str(root / "input"),
            "--output",
            str(root / "output"),
        ]
        self._diagnostic(root / "output/toolb_cmd.txt", " ".join(command), text=True)
        started = time.perf_counter()
        supervisor = self.ports.get_optimizer_process_supervisor()
        with (
            (root / "output/toolb_stdout.txt").open("w") as stdout,
            (root / "output/toolb_stderr.txt").open("w") as stderr,
        ):
            process = supervisor.spawn(
                popen=subprocess.Popen, command=command, cwd=str(app), stdout=stdout, stderr=stderr
            )
            self.timing.setdefault(
                "firstOptimizerSpawnSeconds", round(max(0.0, time.perf_counter() - self.started), 3)
            )
            self.ports.register_job_process(self.job_id, process)
            deadline = self.deadline.start_subjob(
                max(1, min(3600, env_int("OPTIMIZER_TIMEOUT_SECONDS", 300)))
            )
            timeout_kind = ""
            try:
                while True:
                    returncode = process.poll()
                    self._publish_optimizer_progress(root, index)
                    if returncode is not None:
                        break
                    if self.ports.job_cancel_requested(self.job_id):
                        raise self.ports.JobCancelledError("Job cancelled during optimizer")
                    timeout_kind = self.deadline.timeout_kind(deadline)
                    if timeout_kind:
                        break
                    time.sleep(0.02 if time.perf_counter() - started < 2.0 else 0.08)
            finally:
                self.ports.terminate_optimizer_process(process, terminate_timeout=0.2, kill_timeout=1.0)
                self.ports.unregister_job_process(self.job_id, process)
            self._publish_optimizer_progress(root, index)
            if timeout_kind:
                raise RuntimeError(f"Optimizer {timeout_kind} timeout for {root.name}")
            if returncode != 0:
                raise RuntimeError(f"Optimizer failed for {root.name}; inspect toolb_stderr.txt")
        self._check("optimizer completion")
        self._limit_output()
        return started, time.perf_counter()

    def _finish_material(self, root, code, index, optimizer_started, optimizer_done):
        _, _, summary_percent, done_percent = job_family_progress_segment(index, len(self.codes))
        self._progress(
            summary_percent, f"Materiaal {index}/{len(self.codes)} berekening opbouwen…", "subjob_summary"
        )
        self._check("subjob finalization")
        started = time.perf_counter()
        self.ports.finalize_subjob_outputs(root)
        self.finalized_hashes[root.name] = self.ports.cached_sha256_file(root / "output/finalization.json")
        done = time.perf_counter()
        timing = {
            "optimizerSeconds": round(max(0.0, optimizer_done - optimizer_started), 3),
            "summarySeconds": round(max(0.0, done - started), 3),
            "totalSeconds": round(max(0.0, done - optimizer_started), 3),
        }
        self._diagnostic(
            root / "output/timing_profile_server.json",
            {
                "schemaVersion": 1,
                "jobId": root.name,
                "startedAt": self.ports.utc_now_iso(),
                "updatedAt": self.ports.utc_now_iso(),
                **timing,
            },
        )
        self.timing["subjobs"].append({"subjobId": root.name, **timing})
        self._progress(done_percent, f"Materiaal {index}/{len(self.codes)} afgerond", "subjob_done")
        material = next(
            (
                m
                for m in self.pricing.get("materials", [])
                if str(m.get("materialCode") or "").strip() == code
            ),
            {},
        )
        name = str(
            material.get("decorName") or material.get("materialName") or material.get("materialCode") or code
        )
        self.subjobs.append(
            {
                "subjobId": root.name,
                "materialCode": code,
                "materialDisplayName": name,
                "status": "DONE",
                "outputsReady": True,
            }
        )
        self.ports.write_master_job_links(self.job_id, self.subjobs)

    def _seal_master(self):
        self._check("master finalization")
        self._limit_output()
        self._progress(95, "Subjobs samenvoegen…", "finalize_merge")
        started = time.perf_counter()
        self.ports.get_job_finalization_service().seal_master(
            master_root=self.root, subjobs=self.subjobs, finalized_subjob_hashes=self.finalized_hashes
        )
        self.timing["masterSummarySeconds"] = round(max(0.0, time.perf_counter() - started), 3)
        self._progress(99, "Afronden…", "finalize_done")
        self.timing.update(
            totalSeconds=round(max(0.0, time.perf_counter() - self.prepared), 3),
            finishedAt=self.ports.utc_now_iso(),
        )
        self._diagnostic(self.output / "timing_profile.json", self.timing)

    def run(self):
        self._prepare_master()
        for index, code in enumerate(self.codes, 1):
            self._check("subjob preparation")
            percent, _, _, _ = job_family_progress_segment(index, len(self.codes))
            self._progress(
                percent,
                f"Materiaal {index}/{len(self.codes)} voorbereiden…",
                "subjob_prepare",
                currentSubjobIndex=index,
                subjobsTotal=len(self.codes),
            )
            root = self.ports.get_jobs() / f"{self.job_id}__mat_{index:03d}"
            self.subjob_roots.append(root)
            self._material_inputs(root, code)
            started, done = self._run_optimizer(root, index)
            self._finish_material(root, code, index, started, done)
        self._seal_master()
        return {"jobId": self.job_id, "parentJobId": self.job_id, "subjobs": self.subjobs}


def create_job_from_payload(
    ports: JobsExecutionPorts, payload: dict, master_job_id: str | None = None, public_access_token: str = ""
) -> dict:
    """Shared execution entry for HTTP admission and the queue worker."""
    return JobExecution(ports, payload, master_job_id, public_access_token).run()
