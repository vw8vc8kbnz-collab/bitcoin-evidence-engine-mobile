"""Pure StickerTool projection: identifiers, labels, orientation and edge mapping."""


def as_int(v, default=None):
    try:
        if v is None or v == "":
            return default
        return int(round(float(str(v).replace(",", "."))))
    except (ValueError, TypeError, OverflowError):
        return default


def rotation_0_90(rot_deg) -> int:
    r = as_int(rot_deg, 0) or 0
    r = r % 360
    if r in (0, 180):
        return 0
    if r in (90, 270):
        return 90
    raise ValueError(f"Invalid rotation_deg (must be 0/90/180/270): {rot_deg}")


def panel_name(row: dict, pid_base: str) -> str:
    display_name = (
        str(
            row.get("PanelName")
            or row.get("panelName")
            or row.get("Label")
            or row.get("label")
            or row.get("Name")
            or row.get("name")
            or pid_base
        ).strip()
        or pid_base
    )
    display_name = (
        display_name.replace("Ã—", "×")
        .replace("â€“", "–")
        .replace("â€”", "—")
        .replace("Ã©", "é")
        .replace("Ã‰", "É")
        .replace("Ã¶", "ö")
        .replace("Ã–", "Ö")
    )

    return display_name


def project_item(p: dict, row: dict, pid_base: str, part_id: str, thickness_mm, sheet_h: int) -> dict | None:
    display_name = panel_name(row, pid_base)

    part_mm = p.get("part_mm") or {}
    w = as_int(part_mm.get("width_mm") or row.get("WidthMM") or row.get("Width") or row.get("width"))
    h = as_int(
        part_mm.get("length_mm")
        or row.get("LengthMM")
        or row.get("HeightMM")
        or row.get("Height")
        or row.get("height")
    )
    t = as_int(
        p.get("thicknessMm")
        or row.get("ThicknessMM")
        or row.get("Thickness")
        or row.get("thickness")
        or thickness_mm
    )
    if not w or not h or not t:
        return None

    rot = rotation_0_90(p.get("rotation_deg") or p.get("rotationDeg") or p.get("rot") or 0)
    bbox_mm = p.get("bbox_mm") or {}
    bw = as_int(bbox_mm.get("w_mm") or bbox_mm.get("w") or w)
    bh = as_int(bbox_mm.get("h_mm") or bbox_mm.get("h") or h)
    if not bw or not bh:
        return None

    x = float(p.get("x_mm") or p.get("x") or 0.0)
    y = float(p.get("y_mm") or p.get("y") or 0.0)

    # placements.json uses origin bottom-left, y up.
    # Stickertool expects origin top-left, y down.
    x1 = x
    y1 = float(sheet_h) - (y + float(bh))
    x2 = x1 + float(bw)
    y2 = y1 + float(bh)
    if x1 < 0 or y1 < 0 or x2 <= x1 or y2 <= y1:
        return None

    sheet_index = int(p.get("sheetIndex") or 1)
    sheet_id = f"S{sheet_index:02d}"

    grain = str(row.get("Grain") or row.get("grain") or row.get("Nerf") or "").strip().lower()
    if grain not in ("vertical", "horizontal"):
        grain = "vertical"

    edges = p.get("edges") or {}
    edge_banding = {
        "top": bool(edges.get("H1")),
        "right": bool(edges.get("W2")),
        "bottom": bool(edges.get("H2")),
        "left": bool(edges.get("W1")),
    }

    return {
        "partId": part_id,
        "displayName": display_name,
        "qty": 1,
        "width": int(w),
        "height": int(h),
        "thickness": int(t),
        "grain": grain,
        "placement": {
            "sheetId": sheet_id,
            "bbox": [int(round(x1)), int(round(y1)), int(round(x2)), int(round(y2))],
            "rotation": int(rot),
        },
        "edgeBanding": {k: bool(v) for k, v in edge_banding.items() if bool(v)},
    }


def project_items(placements_list: list, rows: list[dict], thickness_mm, sheet_h: int) -> list[dict]:
    panels_by_part = {}
    for row in rows:
        pid = str(row.get("PartId") or row.get("PartID") or row.get("partId") or row.get("ID") or "").strip()
        if pid and pid not in panels_by_part:
            panels_by_part[pid] = row
    items_out: list[dict] = []
    seen_part_ids: set[str] = set()

    for p in placements_list:
        if not isinstance(p, dict):
            continue
        pid_base = str(p.get("partId") or p.get("PartId") or "").strip()
        if not pid_base:
            continue
        inst = str(p.get("instanceIndex") if p.get("instanceIndex") is not None else "").strip()
        part_id = f"{pid_base}__{inst}" if inst else pid_base
        if part_id in seen_part_ids:
            k = 2
            while f"{part_id}__{k}" in seen_part_ids:
                k += 1
            part_id = f"{part_id}__{k}"
        seen_part_ids.add(part_id)

        row = panels_by_part.get(pid_base) or {}
        item = project_item(p, row, pid_base, part_id, thickness_mm, sheet_h)
        if item is not None:
            items_out.append(item)
    items_out.sort(key=lambda it: (str(it.get("displayName") or ""), str(it.get("partId") or "")))
    return items_out


def project_sheets(placements_list: list, sheet_w: int, sheet_h: int) -> list[dict]:
    max_sheet_index = 1
    try:
        if placements_list:
            max_sheet_index = max(
                int(p.get("sheetIndex") or 1) for p in placements_list if isinstance(p, dict)
            )
    except (ValueError, TypeError, OverflowError):
        max_sheet_index = 1

    sheets_out = [
        {"sheetId": f"S{si:02d}", "width": int(sheet_w), "height": int(sheet_h)}
        for si in range(1, max_sheet_index + 1)
    ]

    return sheets_out
