"""Bounded JobOutputRuntime implementation with explicit ports injection."""

from __future__ import annotations

from metod_app.version import REVISION
from .sticker_projection import as_int, project_items, project_sheets

import re

from typing import Any
from catalog_importer import ALLOWED_THICKNESSES_MM as CATALOG_ALLOWED_THICKNESSES_MM
from pathlib import Path
from safety_contracts import ContractError as SafetyContractError
from metod_app.config import env_int as _env_int
from panel_contract import parse_panels_csv as _parse_panels_csv_contract
from metod_app.identifiers import sanitize_filename as _sanitize_filename
import csv
from datetime import datetime
from safety_contracts import durable_write_json
from safety_contracts import durable_write_text
from safety_contracts import finite_number
import hmac
import io
from safety_contracts import resolve_identifier_child
from safety_contracts import sha256_file
from safety_contracts import strict_json_dumps
from safety_contracts import strict_json_load
from datetime import timezone
from safety_contracts import validate_job_id
from metod_app.runtime.ports import JobsOutputRuntimePorts


from metod_app.observability.failures import report_recovery


class JobOutputRuntime:
    def __init__(self, ports: JobsOutputRuntimePorts):
        self._ports = ports

    def _parse_panels_csv(_owner, text: str) -> list[dict]:
        """
        Parse Tool A panels.csv (semicolon-delimited) into list of dict rows.
        """

        rows = _parse_panels_csv_contract(
            str(text or ""),
            allowed_thicknesses=CATALOG_ALLOWED_THICKNESSES_MM,
            allowed_edge_codes={0, 1},
            max_rows=_env_int("PUBLIC_JOB_MAX_PANEL_ROWS", 500),
            max_total_qty=_env_int("PUBLIC_JOB_TOTAL_QTY_LIMIT", 250),
        )
        return [row.as_dict() for row in rows]

    def _is_subjob(_owner, job_id: str) -> bool:
        return "__mat_" in (job_id or "")

    def _filter_panels_csv_by_material(_owner, panels_csv: str, material_code: str) -> str:
        """Return panels.csv containing only rows whose MaterialCode matches material_code."""
        ports = _owner._ports
        _parse_panels_csv = ports.parse_panels_csv

        panels_csv = panels_csv or ""
        lines = [ln for ln in panels_csv.splitlines() if ln.strip()]
        if not lines:
            return panels_csv
        header = lines[0]
        rows = _parse_panels_csv(panels_csv)
        filt = [r for r in rows if str(r.get("MaterialCode") or "").strip() == str(material_code).strip()]
        out = io.StringIO()
        out.write(header.strip() + "\n")
        if filt:
            writer = csv.DictWriter(out, fieldnames=header.split(";"), delimiter=";", lineterminator="\n")
            for r in filt:
                # DictWriter writes header only if writeheader() called; we already wrote it
                writer.writerow({k: r.get(k, "") for k in header.split(";")})
        return out.getvalue()

    def _parts_for_panels_rows(_owner, rows: list[dict]) -> set[str]:
        part_ids = set()
        for r in rows:
            pid = str(r.get("PartId") or r.get("PartID") or r.get("partId") or "").strip()
            if pid:
                part_ids.add(pid)
        return part_ids

    def _customer_display_name(_owner, customer: Any) -> str:
        """Return one stable customer label from job or request customer data."""

        try:
            cust = customer or {}
            if isinstance(cust, dict):
                explicit = str(
                    cust.get("name")
                    or cust.get("fullName")
                    or cust.get("customerName")
                    or cust.get("displayName")
                    or ""
                ).strip()
                if explicit and explicit not in {"-", "—"}:
                    return explicit
                first = str(cust.get("firstName") or cust.get("first_name") or "").strip()
                last = str(cust.get("lastName") or cust.get("last_name") or "").strip()
                company = str(cust.get("company") or cust.get("companyName") or "").strip()
                name = f"{first} {last}".strip()
                if name:
                    return name
                if company:
                    return company
            elif isinstance(cust, str):
                name = cust.strip()
                if name and name not in {"-", "—"}:
                    return name
        except Exception as recovery_error:
            report_recovery("metod_app.jobs.output_runtime._customer_display_name.95", recovery_error)
        return "Onbekend"

    def _customer_name_from_job(_owner, job_json: dict) -> str:
        """Return a display-friendly customer name. Must always return a non-empty string."""
        ports = _owner._ports
        _customer_display_name = ports.customer_display_name

        try:
            customer = (job_json or {}).get("customer") or {}
            name = _customer_display_name(customer)
            if name != "Onbekend":
                return name
            order = (job_json or {}).get("order") or {}
            if isinstance(order, dict):
                name = _customer_display_name(
                    order.get("customer_name") or order.get("customerName") or order
                )
                if name != "Onbekend":
                    return name
        except Exception as recovery_error:
            report_recovery("metod_app.jobs.output_runtime._customer_name_from_job.117", recovery_error)
        return "Onbekend"

    def _material_name_and_thickness(_owner, pricing: dict, material_code: str) -> tuple[str, float]:
        """Lookup the human material/decor name + thickness for a material code.

        IMPORTANT for StickerTool/admin exports:
        - materialCode must remain the article number/code.
        - materialDisplayName must be the human decor/product label, never the code just
          because a pricing row duplicated materialCode into decorName.
        """
        ports = _owner._ports
        _best_material_name = ports.best_material_name

        code = str(material_code or "").strip()
        try:
            mats = (pricing or {}).get("materials") or []
            for m in mats:
                if (
                    str(m.get("materialCode") or m.get("code") or m.get("articleNumber") or "").strip()
                    == code
                ):
                    name = _best_material_name(
                        code,
                        m.get("materialDisplayName"),
                        m.get("materialName"),
                        m.get("name"),
                        m.get("productName"),
                        m.get("decorName"),
                    )
                    t = float(m.get("thicknessMm") or 0.0)
                    return (name or code or "Onbekend"), t
        except Exception as recovery_error:
            report_recovery("metod_app.jobs.output_runtime._material_name_and_thickness.148", recovery_error)
        return (_best_material_name(code, "") or code or "Onbekend"), 0.0

    def _resolve_stickertool_material_display_name(
        _owner, material_code: str, job_json: dict, panels_rows: list[dict], pricing_obj: dict
    ) -> str:
        """Resolve the StickerTool materialDisplayName from the richest available order data.

        This intentionally prefers order/catalog human labels over the subjob/material code.
        The bug fixed in was that StickerTool could output:
          materialCode: "100817-1", materialDisplayName: "100817-1"
        while the expected display name is the decor/product name, e.g. "DecoLegno LS14 ...".
        """
        ports = _owner._ports
        MATERIAL_LIBRARY_PATH = ports.get_material_library_path()
        _best_material_name = ports.best_material_name

        code = str(material_code or "").strip()

        def _code_of(rec: dict) -> str:
            return str(
                rec.get("materialCode")
                or rec.get("MaterialCode")
                or rec.get("code")
                or rec.get("articleNumber")
                or rec.get("articleNo")
                or rec.get("materialKey")
                or rec.get("ArticleNumber")
                or ""
            ).strip()

        def _name_of(rec: dict) -> str:
            return _best_material_name(
                code,
                rec.get("materialDisplayName"),
                rec.get("MaterialDisplayName"),
                rec.get("materialName"),
                rec.get("MaterialName"),
                rec.get("name"),
                rec.get("Name"),
                rec.get("productName"),
                rec.get("ProductName"),
                rec.get("decorName"),
                rec.get("DecorName"),
            )

        def _consider(rec: dict) -> str:
            if not isinstance(rec, dict):
                return ""
            rc = _code_of(rec)
            if code and rc and rc != code:
                return ""
            nm = _name_of(rec)
            # Do not accept the article number itself as display name when richer fallbacks may exist.
            if nm and (not code or nm != code):
                return nm
            return ""

        # 1) User/order payload sources are most accurate for custom/selected decor labels.
        try:
            if isinstance(job_json, dict):
                for key in (
                    "materialsSummary",
                    "materials",
                    "materialBatches",
                    "cart",
                    "panels",
                    "extraPanels",
                ):
                    arr = job_json.get(key)
                    if isinstance(arr, list):
                        for rec in arr:
                            nm = _consider(rec)
                            if nm:
                                return nm
                quote = job_json.get("quote") if isinstance(job_json.get("quote"), dict) else {}
                q_mats = quote.get("materials") if isinstance(quote.get("materials"), list) else []
                for rec in q_mats:
                    nm = _consider(rec)
                    if nm:
                        return nm
        except Exception as recovery_error:
            report_recovery(
                "metod_app.jobs.output_runtime._resolve_stickertool_material_display_name.213", recovery_error
            )

        # 2) panels.csv can carry DecorName/ProductName from Tool A.
        try:
            for rec in panels_rows or []:
                nm = _consider(rec)
                if nm:
                    return nm
        except Exception as recovery_error:
            report_recovery(
                "metod_app.jobs.output_runtime._resolve_stickertool_material_display_name.222", recovery_error
            )

        # 3) pricing.json generated by Tool B/admin.
        try:
            mats = (pricing_obj or {}).get("materials") or []
            if isinstance(mats, list):
                for rec in mats:
                    nm = _consider(rec)
                    if nm:
                        return nm
        except Exception as recovery_error:
            report_recovery(
                "metod_app.jobs.output_runtime._resolve_stickertool_material_display_name.233", recovery_error
            )

        # 4) Embedded material library fallback.
        try:
            lib = strict_json_load(MATERIAL_LIBRARY_PATH)
            recs = lib.get("records") if isinstance(lib, dict) else lib
            if isinstance(recs, list):
                for rec in recs:
                    nm = _consider(rec)
                    if nm:
                        return nm
        except Exception as recovery_error:
            report_recovery(
                "metod_app.jobs.output_runtime._resolve_stickertool_material_display_name.245", recovery_error
            )

        return _best_material_name(code, "") or code or "Onbekend"

    def _job_material_context(_owner, job_root: Path) -> dict:
        """Resolve internal material metadata for a job/subjob from its server-side inputs.

        public subjob IDs are deliberately opaque (``__mat_001`` etc.). Never
        interpret that suffix as an article/material code. Production/Admin helpers must
        resolve the real internal code from ``input/panels.csv`` (or output fallback).
        Nothing returned by this helper is itself exposed to Tool A.
        """
        ports = _owner._ports

        _material_name_and_thickness = ports.material_name_and_thickness
        _parse_panels_csv = ports.parse_panels_csv

        root = Path(job_root)
        jid = root.name
        base_jid = jid.split("__mat_", 1)[0] if "__mat_" in jid else jid
        rows = []
        for cand in (root / "input" / "panels.csv", root / "output" / "panels.csv"):
            try:
                if cand.exists():
                    rows = _parse_panels_csv(cand.read_text(encoding="utf-8"))
                    if rows:
                        break
            except Exception as recovery_error:
                report_recovery("metod_app.jobs.output_runtime.boundary.292", recovery_error)
                continue
        codes = []
        names = []
        thicknesses = []
        for row in rows:
            if not isinstance(row, dict):
                continue
            code = str(
                row.get("MaterialCode")
                or row.get("materialCode")
                or row.get("ArticleNumber")
                or row.get("articleNumber")
                or ""
            ).strip()
            if code and code not in codes:
                codes.append(code)
            name = str(
                row.get("DecorName")
                or row.get("ProductName")
                or row.get("MaterialName")
                or row.get("materialName")
                or ""
            ).strip()
            if name and name not in names:
                names.append(name)
            try:
                tv = (
                    row.get("ThicknessMm")
                    or row.get("ThicknessMM")
                    or row.get("thicknessMm")
                    or row.get("Thickness")
                    or row.get("thickness")
                )
                if tv not in (None, ""):
                    f = float(str(tv).replace(",", "."))
                    if f not in thicknesses:
                        thicknesses.append(f)
            except (ValueError, TypeError, OverflowError) as recovery_error:
                report_recovery("metod_app.jobs.output_runtime._job_material_context.295", recovery_error)
        code = codes[0] if len(codes) == 1 else ""
        name = names[0] if len(names) == 1 else ""
        thickness = thicknesses[0] if len(thicknesses) == 1 else None
        # Pricing is a secondary server-only fallback for human display metadata.
        if code and (not name or thickness is None):
            try:
                pp = root / "input" / "pricing.json"
                pricing = strict_json_load(pp) if pp.exists() else {}
                nm, th = _material_name_and_thickness(pricing, code)
                if not name and nm and nm != code:
                    name = nm
                if thickness is None and th:
                    thickness = float(th)
            except Exception as recovery_error:
                report_recovery("metod_app.jobs.output_runtime._job_material_context.310", recovery_error)
        return {
            "jobId": jid,
            "baseJobId": base_jid,
            "materialCode": code,
            "materialName": name,
            "thicknessMm": thickness,
            "rows": rows,
        }

    def _sheet_sequence_from_filename(_owner, filename: str, fallback: int = 1) -> int:
        """Read the physical optimizer sheet number without changing the artifact."""

        stem = Path(str(filename or "")).stem
        patterns = (
            r"(?:^|[^A-Za-z0-9])S(\d{1,4})(?:$|[^0-9])",
            r"(?:^|[^A-Za-z0-9])Sheet[_ -]?(\d{1,4})(?:$|[^0-9])",
            r"(\d{1,4})$",
        )
        for pattern in patterns:
            match = re.search(pattern, stem, flags=re.IGNORECASE)
            if match:
                try:
                    return max(1, min(9999, int(match.group(1))))
                except (ValueError, TypeError, OverflowError):
                    continue
        try:
            return max(1, min(9999, int(fallback)))
        except (ValueError, TypeError, OverflowError):
            return 1

    def _admin_sheet_download_name(
        _owner,
        job_root: Path,
        stored_filename: str,
        *,
        customer: Any = None,
        sequence: int | None = None,
    ) -> str:
        """Project a sealed sheet DXF as ``customer__decor__001.dxf`` for Admin.

        The stored optimizer artifact and finalization manifest deliberately keep their
        original names.  This function is only used for display/download names, so it
        also works for already completed jobs without invalidating their hashes.
        """
        ports = _owner._ports

        _best_material_name = ports.best_material_name
        _customer_display_name = ports.customer_display_name
        _customer_name_from_job = ports.customer_name_from_job
        _job_material_context = ports.job_material_context

        _sheet_sequence_from_filename = ports.sheet_sequence_from_filename

        root = Path(job_root)
        customer_name = _customer_display_name(customer) if customer is not None else "Onbekend"
        if customer_name == "Onbekend":
            try:
                job_path = root / "input" / "job.json"
                job_json = strict_json_load(job_path) if job_path.exists() else {}
                customer_name = _customer_name_from_job(job_json)
            except Exception as recovery_error:
                report_recovery("metod_app.jobs.output_runtime.boundary.390", recovery_error)
                customer_name = "Onbekend"
        try:
            context = _job_material_context(root)
        except Exception as recovery_error:
            report_recovery("metod_app.jobs.output_runtime.boundary.394", recovery_error)
            context = {}
        material_code = str(context.get("materialCode") or "").strip()
        decor_name = str(
            context.get("materialName")
            or (_best_material_name(material_code, "") if material_code else "")
            or material_code
            or "Materiaal"
        ).strip()
        safe_customer = _sanitize_filename(customer_name, 48) or "Onbekend"
        safe_decor = _sanitize_filename(decor_name, 80) or "Materiaal"
        sheet_number = _sheet_sequence_from_filename(
            stored_filename,
            fallback=sequence if sequence is not None else 1,
        )
        return f"{safe_customer}__{safe_decor}__{sheet_number:03d}.dxf"

    def _sticker_inputs(_owner, input_dir: Path, output_dir: Path):
        _parse_panels_csv = _owner._ports.parse_panels_csv
        # --- load job.json for customer/order info ---
        job_json = {}
        job_json_path = input_dir / "job.json"
        if job_json_path.exists():
            try:
                job_json = strict_json_load(job_json_path)
            except (OSError, ValueError, TypeError, OverflowError):
                job_json = {}

        # --- load placements.json ---
        placements_path = output_dir / "placements.json"
        placements_obj = {}
        if placements_path.exists():
            try:
                placements_obj = strict_json_load(placements_path)
            except (OSError, ValueError, TypeError, OverflowError):
                placements_obj = {}

        placements_list = []
        if isinstance(placements_obj, dict):
            placements_list = placements_obj.get("placements") or []
        elif isinstance(placements_obj, list):
            placements_list = placements_obj
        else:
            placements_list = []

        # --- load panels.csv (output or input) ---
        panels_rows: list[dict] = []
        for cand in [output_dir / "panels.csv", input_dir / "panels.csv"]:
            if cand.exists():
                try:
                    panels_rows = _parse_panels_csv(cand.read_text(encoding="utf-8"))
                    if panels_rows:
                        break
                except Exception as recovery_error:
                    report_recovery("metod_app.jobs.output_runtime.boundary.490", recovery_error)
                    continue

        return job_json, placements_obj, placements_list, panels_rows

    def _sticker_material(
        _owner,
        input_dir: Path,
        material_ctx: dict,
        material_code: str,
        job_json: dict,
        panels_rows: list[dict],
    ):
        _material_name_and_thickness = _owner._ports.material_name_and_thickness
        _resolve_stickertool_material_display_name = _owner._ports.resolve_stickertool_material_display_name
        # --- material display name + thickness ---
        # materialCode remains the article number/code; materialDisplayName must be
        # the human decor/product label from the order/catalog/pricing, not the code again.
        material_display_name = str(material_ctx.get("materialName") or material_code or "Onbekend")
        thickness_mm = material_ctx.get("thicknessMm")
        pricing_obj = {}
        snapshot_material_name = False
        try:
            # Current jobs persist the admission-time catalog authority in input.
            # Tool B never produces output/pricing.json; reading that path caused
            # StickerTool labels to drift to a later mutable catalog name.
            pricing_path = input_dir / "pricing.json"
            if pricing_path.exists():
                pricing_obj = strict_json_load(pricing_path)
            if material_code:
                nm, th = _material_name_and_thickness(pricing_obj, material_code)
                if nm and nm != material_code:
                    material_display_name = nm
                    snapshot_material_name = True
                if th:
                    thickness_mm = th
        except Exception as recovery_error:
            report_recovery("metod_app.jobs.output_runtime._generate_stickertool_json.516", recovery_error)
        if not snapshot_material_name:
            # Narrow legacy fallback for jobs created before catalog snapshots.
            try:
                resolved_name = _resolve_stickertool_material_display_name(
                    material_code, job_json, panels_rows, pricing_obj
                )
                if resolved_name:
                    material_display_name = resolved_name
            except Exception as recovery_error:
                report_recovery(
                    "metod_app.jobs.output_runtime._generate_stickertool_json.524", recovery_error
                )

        return material_display_name, thickness_mm

    def _sticker_sheet_dimensions(
        _owner, placements_obj, material_code: str, thickness_mm, material_display_name: str
    ):
        MATERIAL_LIBRARY_PATH = _owner._ports.get_material_library_path()
        # --- sheet size (placements meta first) ---
        sheet_w = None
        sheet_h = None
        try:
            meta_sheets = (placements_obj.get("sheets") or []) if isinstance(placements_obj, dict) else []
            pick = None
            for s in meta_sheets:
                if not isinstance(s, dict):
                    continue
                if material_code and str(s.get("materialCode") or "").strip() != material_code:
                    continue
                pick = s
                break
            if pick is None and meta_sheets:
                pick = meta_sheets[0]
            if isinstance(pick, dict):
                ss = pick.get("sheetSizeMm") or {}
                sheet_w = as_int((ss or {}).get("width"))
                sheet_h = as_int((ss or {}).get("height"))
                if thickness_mm is None:
                    thickness_mm = as_int(pick.get("thicknessMm"))
        except Exception as recovery_error:
            report_recovery("metod_app.jobs.output_runtime._generate_stickertool_json.565", recovery_error)

        # last resort: material_library.json
        if (not sheet_w) or (not sheet_h):
            try:
                lib = strict_json_load(MATERIAL_LIBRARY_PATH)
                mats = lib.get("materials") if isinstance(lib, dict) else None
                if isinstance(mats, list) and material_code:
                    hit = next(
                        (m for m in mats if str(m.get("articleNumber") or "").strip() == material_code), None
                    )
                    if isinstance(hit, dict):
                        ss = hit.get("sheetSizeMm") or hit.get("sheetSize") or {}
                        sheet_w = sheet_w or as_int(ss.get("width") or ss.get("w"))
                        sheet_h = sheet_h or as_int(ss.get("height") or ss.get("h"))
                        if thickness_mm is None:
                            thickness_mm = as_int(hit.get("thicknessMm") or hit.get("thickness"))
                        if material_display_name == (material_code or "Onbekend"):
                            material_display_name = str(
                                hit.get("productName") or hit.get("decorName") or material_display_name
                            )
            except Exception as recovery_error:
                report_recovery(
                    "metod_app.jobs.output_runtime._generate_stickertool_json.583", recovery_error
                )

        if not sheet_w:
            sheet_w = 2070
        if not sheet_h:
            sheet_h = 2800

        return sheet_w, sheet_h, thickness_mm, material_display_name

    def _generate_stickertool_json(_owner, job_root: Path) -> Path:
        """Load the captured order, project labels and publish the single contract file."""
        ports = _owner._ports
        OPTIMIZER_TOOL_B = ports.get_optimizer_tool_b()
        STICKERTOOL_V2_BUILD = ports.get_stickertool_v2_build()
        _customer_name_from_job = ports.customer_name_from_job
        output_dir, input_dir = job_root / "output", job_root / "input"
        output_dir.mkdir(parents=True, exist_ok=True)
        subjob_id = job_root.name
        material_ctx = ports.job_material_context(job_root)
        base_job_id = str(material_ctx.get("baseJobId") or subjob_id)
        material_code = str(material_ctx.get("materialCode") or "").strip()
        job_json, placements_obj, placements_list, panels_rows = _owner._sticker_inputs(input_dir, output_dir)
        customer_name = _customer_name_from_job(job_json)
        order_number = str(
            (job_json.get("order") or {}).get("orderNumber")
            or (job_json.get("order") or {}).get("order_number")
            or ""
        ).strip()

        # infer material_code if missing
        if not material_code:
            try:
                mats = sorted(
                    {
                        str(p.get("materialCode") or "").strip()
                        for p in placements_list
                        if isinstance(p, dict) and str(p.get("materialCode") or "").strip()
                    }
                )
                if len(mats) == 1:
                    material_code = mats[0]
            except Exception as recovery_error:
                report_recovery(
                    "metod_app.jobs.output_runtime._generate_stickertool_json.473", recovery_error
                )

        material_display_name, thickness_mm = _owner._sticker_material(
            input_dir, material_ctx, material_code, job_json, panels_rows
        )
        sheet_w, sheet_h, thickness_mm, material_display_name = _owner._sticker_sheet_dimensions(
            placements_obj, material_code, thickness_mm, material_display_name
        )
        sheets_out = project_sheets(placements_list, sheet_w, sheet_h)
        items_out = project_items(placements_list, panels_rows, thickness_mm, sheet_h)
        carry_out = (
            bool((job_json.get("rest_material") or {}).get("carry_out"))
            if isinstance(job_json, dict)
            else False
        )
        payload = {
            "schemaVersion": "2.0",
            "jobId": base_job_id,
            "subjobId": subjob_id,
            "customerName": customer_name,
            "materialCode": material_code or "",
            "materialDisplayName": material_display_name,
            "generatedAt": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "optimizerVersionId": f"{OPTIMIZER_TOOL_B}::{STICKERTOOL_V2_BUILD}",
            "restMaterial": {
                "carryOut": carry_out,
                "labelText": ("Restmateriaal: JA" if carry_out else "Restmateriaal: NEE"),
            },
            "sheets": sheets_out,
            "items": items_out,
        }
        if order_number:
            payload["orderNumber"] = order_number

        contract_path = output_dir / "stickertool.json"
        data_text = strict_json_dumps(payload, indent=2)
        durable_write_text(contract_path, data_text)
        return contract_path

    def _placements_item_count(_owner, placements_obj) -> int:
        try:
            if isinstance(placements_obj, dict):
                top = placements_obj.get("placements")
                if isinstance(top, list):
                    return len(top)
                total = 0
                for sh in placements_obj.get("sheets") or []:
                    if isinstance(sh, dict) and isinstance(sh.get("placements"), list):
                        total += len(sh.get("placements") or [])
                return total
            if isinstance(placements_obj, list):
                return len(placements_obj)
        except Exception as recovery_error:
            report_recovery("metod_app.jobs.output_runtime._placements_item_count.740", recovery_error)
        return 0

    def _generate_labels_json_strict(_owner, job_root: Path) -> Path:
        ports = _owner._ports
        PUBLIC_BASE_URL = ports.get_public_base_url()

        _parse_panels_csv = ports.parse_panels_csv

        input_dir = Path(job_root) / "input"
        output_dir = Path(job_root) / "output"
        placements_obj = strict_json_load(output_dir / "placements.json")
        rows = _parse_panels_csv((input_dir / "panels.csv").read_text(encoding="utf-8", errors="strict"))
        job_json = strict_json_load(input_dir / "job.json")
        placements = placements_obj.get("placements") if isinstance(placements_obj, dict) else None
        if not isinstance(placements, list):
            raise SafetyContractError("placements.json has no placements list")
        rows_by_id = {str(row["PartId"]): row for row in rows}
        labels = []
        identities = set()
        for placement in placements:
            if not isinstance(placement, dict):
                raise SafetyContractError("placement must be an object")
            part_id = str(placement.get("partId") or "")
            row = rows_by_id.get(part_id)
            if row is None:
                raise SafetyContractError(f"placement references unknown PartId {part_id}")
            instance = int(
                finite_number(
                    placement.get("instanceIndex"), field=f"{part_id}.instanceIndex", minimum=1, maximum=10000
                )
            )
            identity = (part_id, instance)
            if identity in identities:
                raise SafetyContractError(f"duplicate placement label identity {part_id}/{instance}")
            identities.add(identity)
            rotation = int(
                finite_number(
                    placement.get("rotation_deg"), field=f"{part_id}.rotation_deg", minimum=0, maximum=270
                )
            )
            if rotation not in {0, 90, 180, 270}:
                raise SafetyContractError(f"{part_id}: invalid label rotation")
            x = finite_number(placement.get("x_mm"), field=f"{part_id}.x_mm", minimum=0, maximum=10000)
            y = finite_number(placement.get("y_mm"), field=f"{part_id}.y_mm", minimum=0, maximum=10000)
            bbox = placement.get("bbox_mm") if isinstance(placement.get("bbox_mm"), dict) else {}
            bbox_w = finite_number(bbox.get("w_mm"), field=f"{part_id}.bbox.w", minimum=0.1, maximum=10000)
            bbox_h = finite_number(bbox.get("h_mm"), field=f"{part_id}.bbox.h", minimum=0.1, maximum=10000)
            label_id = f"{part_id}-{instance}"
            labels.append(
                {
                    "label_id": label_id,
                    "panel_id": part_id,
                    "instance": instance,
                    "panel_name": str(row.get("PanelName") or part_id),
                    "length_mm": float(row["LengthMm"]),
                    "width_mm": float(row["WidthMm"]),
                    "thickness_mm": float(row["ThicknessMm"]),
                    "grain_group": str(row.get("GrainGroup") or ""),
                    "edges": {key: int(row[key]) for key in ("H1", "H2", "W1", "W2")},
                    "barcode_type": "QR",
                    "barcode_value": f"{PUBLIC_BASE_URL.rstrip('/')}/m/{job_root.name}/{label_id}",
                    "placement": {
                        "sheet_index": int(placement.get("sheetIndex") or 0),
                        "origin": "bottom-left",
                        "y_axis": "up",
                        "x_mm": x,
                        "y_mm": y,
                        "bbox_mm": [x, y, x + bbox_w, y + bbox_h],
                        "rotation_deg": rotation,
                    },
                }
            )
        expected = {(str(row["PartId"]), index) for row in rows for index in range(1, int(row["Qty"]) + 1)}
        if identities != expected:
            raise SafetyContractError("labels do not match requested panel instances")
        result = {
            "schema_version": 2,
            "build": REVISION,
            "units": "mm",
            "job_id": job_root.name,
            "customer": job_json.get("customer") if isinstance(job_json.get("customer"), dict) else {},
            "note": str(job_json.get("note") or ""),
            "rest_material": {
                "carry_out": bool((job_json.get("rest_material") or {}).get("carry_out")),
            },
            "sheets": placements_obj.get("sheets") or [],
            "labels": labels,
        }
        target = output_dir / "labels.json"
        durable_write_json(target, result)
        return target

    def _input_dxf_source_map(_owner, input_dir: Path, part_ids: set[str]) -> dict[str, Path]:
        """Resolve verified per-part DXF sources for legacy or compact job input."""

        refs_path = input_dir / "dxf_part_refs.json"
        if refs_path.exists():
            manifest = strict_json_load(refs_path)
            refs = manifest.get("partRefs") if isinstance(manifest, dict) else None
            if (
                not isinstance(manifest, dict)
                or int(manifest.get("schemaVersion") or 0) != 1
                or str(manifest.get("algorithm") or "").lower() != "sha256"
                or not isinstance(refs, dict)
                or set(refs) != set(part_ids)
            ):
                raise SafetyContractError("Compact DXF-referentiemanifest is ongeldig")
            blobs_dir = input_dir / "dxf_blobs"
            if not blobs_dir.is_dir() or blobs_dir.is_symlink():
                raise SafetyContractError("Compact DXF-opslag ontbreekt of is onveilig")
            resolved: dict[str, Path] = {}
            checked: dict[str, Path] = {}
            for part_id in sorted(part_ids):
                blob_id = str(refs.get(part_id) or "").strip().lower()
                if not re.fullmatch(r"[0-9a-f]{64}", blob_id):
                    raise SafetyContractError(f"{part_id}: ongeldige DXF-referentie")
                source = blobs_dir / f"{blob_id}.dxf"
                if not source.is_file() or source.is_symlink():
                    raise SafetyContractError(f"{part_id}: DXF-bron ontbreekt of is onveilig")
                if blob_id not in checked:
                    if not hmac.compare_digest(sha256_file(source), blob_id):
                        raise SafetyContractError(f"{part_id}: DXF-bronhash wijkt af")
                    checked[blob_id] = source
                resolved[part_id] = checked[blob_id]
            return resolved
        resolved = {part_id: input_dir / "dxf_parts" / f"{part_id}.dxf" for part_id in part_ids}
        if any(not path.is_file() or path.is_symlink() for path in resolved.values()):
            raise SafetyContractError("Een of meer DXF-onderdeelbronnen ontbreken of zijn onveilig")
        return resolved

    def _finalize_subjob_outputs(_owner, job_root: Path) -> dict:
        ports = _owner._ports

        _JOB_FINALIZATION_SERVICE = ports.get_job_finalization_service()

        return _JOB_FINALIZATION_SERVICE.finalize_subjob(job_root)

    def _write_master_job_links(_owner, master_job_id: str, subjobs: list[dict]) -> None:
        """Persist the private parent/subjob relation atomically for Admin recovery."""
        ports = _owner._ports
        JOBS = ports.get_jobs()

        _utc_now_iso = ports.utc_now_iso

        master_job_id = validate_job_id(master_job_id)
        root = resolve_identifier_child(JOBS, master_job_id)
        clean_subjobs = []
        for item in subjobs or []:
            if not isinstance(item, dict):
                raise SafetyContractError("Invalid subjob link")
            subjob_id = validate_job_id(item.get("subjobId") or item.get("jobId"))
            resolve_identifier_child(JOBS, subjob_id)
            clean_subjobs.append(
                {
                    "subjobId": subjob_id,
                    "status": str(item.get("status") or ""),
                    "outputsReady": bool(item.get("outputsReady")),
                }
            )
        durable_write_json(
            root / "output" / "links.json",
            {
                "schemaVersion": 2,
                "build": REVISION,
                "parentJobId": master_job_id,
                "subjobs": clean_subjobs,
                "updatedAt": _utc_now_iso(),
            },
        )

    def _finalization_complete(_owner, job_root: Path, _memo: dict[str, bool] | None = None) -> bool:
        ports = _owner._ports

        _JOB_FINALIZATION_SERVICE = ports.get_job_finalization_service()

        return _JOB_FINALIZATION_SERVICE.finalization_complete(job_root, memo=_memo)

    def _sealed_output_artifacts(_owner, job_root: Path) -> dict[str, Path]:
        ports = _owner._ports

        _JOB_FINALIZATION_SERVICE = ports.get_job_finalization_service()

        return _JOB_FINALIZATION_SERVICE.sealed_output_artifacts(job_root)

    EXPORTS = (
        "_parse_panels_csv",
        "_is_subjob",
        "_filter_panels_csv_by_material",
        "_parts_for_panels_rows",
        "_customer_display_name",
        "_customer_name_from_job",
        "_material_name_and_thickness",
        "_resolve_stickertool_material_display_name",
        "_job_material_context",
        "_sheet_sequence_from_filename",
        "_admin_sheet_download_name",
        "_generate_stickertool_json",
        "_placements_item_count",
        "_generate_labels_json_strict",
        "_input_dxf_source_map",
        "_finalize_subjob_outputs",
        "_write_master_job_links",
        "_finalization_complete",
        "_sealed_output_artifacts",
    )


__all__ = ("JobOutputRuntime",)
