"""Durable idempotency boundary for public job creation.

The raw browser key is never persisted.  ``O_EXCL`` owns the first attempt
across processes; later requests can only replay that attempt or conflict with
its payload digest.
"""

from __future__ import annotations


from metod_app.observability.failures import report_recovery

import hashlib
import hmac
import json
import os
import re
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping

from safety_contracts import (
    durable_create_json_exclusive,
    durable_write_json,
    fsync_directory,
    strict_json_load,
)

try:
    import fcntl
except ImportError:  # pragma: no cover - Windows uses the process lock below.
    fcntl = None


SCHEMA_VERSION = 1
_KEY_PATTERN = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:-]{15,127}")
_SHA256_PATTERN = re.compile(r"[a-f0-9]{64}")
_JOB_ID_PATTERN = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.:-]{0,199}")


@dataclass(frozen=True)
class JobCreateClaim:
    kind: str
    payload_sha256: str
    job_id: str
    access_token: str
    owner_nonce: str = ""
    response: Mapping[str, Any] | None = None


def validate_idempotency_key(value: object) -> str:
    key = str(value or "").strip()
    if not _KEY_PATTERN.fullmatch(key):
        raise ValueError("Idempotency-Key must contain 16-128 safe ASCII characters")
    return key


def public_job_payload_sha256(payload: object) -> str:
    encoded = json.dumps(
        payload,
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


class JobCreateIdempotencyRepository:
    def __init__(
        self,
        *,
        root: Callable[[], Path],
        utc_now_iso: Callable[[], str],
        new_owner_nonce: Callable[[], str],
        process_id: Callable[[], int] | None = None,
        pid_is_alive: Callable[[int], bool] | None = None,
    ) -> None:
        self._root = root
        self._utc_now_iso = utc_now_iso
        self._new_owner_nonce = new_owner_nonce
        self._process_id = process_id or os.getpid
        self._pid_is_alive = pid_is_alive or self._default_pid_is_alive
        self._process_lock = threading.RLock()

    @staticmethod
    def _default_pid_is_alive(process_id: int) -> bool:
        try:
            pid = int(process_id)
        except (ValueError, TypeError, OverflowError):
            return False
        if pid <= 0:
            return False
        if pid == os.getpid():
            return True
        try:
            os.kill(pid, 0)
            return True
        except PermissionError:
            return True
        except (ProcessLookupError, OSError):
            return False

    def _path(self, key_sha256: str) -> Path:
        if not _SHA256_PATTERN.fullmatch(key_sha256):
            raise ValueError("invalid idempotency key digest")
        return Path(self._root()) / key_sha256[:2] / f"{key_sha256}.json"

    @staticmethod
    def _ensure_private_directory(path: Path) -> None:
        if path.is_symlink():
            raise RuntimeError("job idempotency directory may not be a symlink")
        existed = path.exists()
        path.mkdir(parents=True, exist_ok=True, mode=0o700)
        if os.name != "nt":
            os.chmod(path, 0o700)
        if not existed:
            fsync_directory(path.parent)

    @staticmethod
    def _ensure_private_record(path: Path) -> None:
        if path.is_symlink():
            raise RuntimeError("job idempotency record may not be a symlink")
        if not path.is_file():
            raise FileNotFoundError(path)
        if os.name != "nt":
            os.chmod(path, 0o600)

    @contextmanager
    def _transaction(self):
        """Serialize the create/read/promote boundary across threads/processes."""

        root = Path(self._root())
        self._ensure_private_directory(root)
        lock_path = root / ".claims.lock"
        with self._process_lock:
            with open(lock_path, "a+b", buffering=0) as lock_handle:
                if os.name != "nt":
                    os.chmod(lock_path, 0o600)
                if fcntl is not None:
                    fcntl.flock(lock_handle.fileno(), fcntl.LOCK_EX)
                try:
                    yield
                finally:
                    if fcntl is not None:
                        fcntl.flock(lock_handle.fileno(), fcntl.LOCK_UN)

    @staticmethod
    def _validate_record(record: object, *, key_sha256: str) -> dict[str, Any]:
        if not isinstance(record, dict):
            raise RuntimeError("corrupt job idempotency record")
        if record.get("schemaVersion") != SCHEMA_VERSION:
            raise RuntimeError("unsupported job idempotency record")
        stored_key_sha256 = str(record.get("keySha256") or "")
        if not hmac.compare_digest(stored_key_sha256, key_sha256):
            raise RuntimeError("job idempotency key digest mismatch")
        payload_sha256 = str(record.get("payloadSha256") or "")
        if not _SHA256_PATTERN.fullmatch(payload_sha256):
            raise RuntimeError("invalid job idempotency payload digest")
        status = str(record.get("status") or "")
        if status not in {"CLAIMED", "READY"}:
            raise RuntimeError("invalid job idempotency status")
        if not _JOB_ID_PATTERN.fullmatch(str(record.get("jobId") or "")):
            raise RuntimeError("job idempotency record misses jobId")
        if not str(record.get("accessToken") or ""):
            raise RuntimeError("job idempotency record misses accessToken")
        if status == "CLAIMED" and len(str(record.get("ownerNonce") or "")) < 16:
            raise RuntimeError("claimed job idempotency record misses owner")
        owner_pid = record.get("ownerPid")
        if owner_pid is not None:
            if isinstance(owner_pid, bool) or not isinstance(owner_pid, int) or owner_pid <= 0:
                raise RuntimeError("invalid job idempotency owner pid")
        if status == "READY" and not isinstance(record.get("response"), dict):
            raise RuntimeError("ready job idempotency record misses response")
        return dict(record)

    def _load_existing_record(self, path: Path, *, key_sha256: str) -> dict[str, Any]:
        """Bound the tiny O_EXCL create-before-write visibility window."""

        last_error: Exception | None = None
        for attempt in range(20):
            try:
                self._ensure_private_record(path)
                return self._validate_record(strict_json_load(path), key_sha256=key_sha256)
            except Exception as exc:
                report_recovery("metod_app.jobs.idempotency.boundary.192", exc)
                last_error = exc
                if attempt < 19:
                    time.sleep(0.01)
        if isinstance(last_error, FileNotFoundError):
            raise last_error
        raise RuntimeError("job idempotency record is unreadable") from last_error

    def claim(
        self,
        *,
        key: object,
        payload: object,
        payload_sha256: str | None = None,
        job_id: str,
        access_token: str,
    ) -> JobCreateClaim:
        # The request body can be close to the public upload limit. Canonicalize
        # and hash it before taking the process-wide record lock so one large
        # request cannot block every replay/read transaction.
        normalized_key = validate_idempotency_key(key)
        key_sha256 = hashlib.sha256(normalized_key.encode("utf-8")).hexdigest()
        if payload_sha256 is None:
            payload_sha256 = public_job_payload_sha256(payload)
        else:
            payload_sha256 = str(payload_sha256).strip().lower()
            if not _SHA256_PATTERN.fullmatch(payload_sha256):
                raise ValueError("invalid raw job payload digest")
        owner_nonce = str(self._new_owner_nonce() or "")
        if len(owner_nonce) < 16:
            raise RuntimeError("invalid idempotency owner nonce")
        owner_pid = int(self._process_id())
        if owner_pid <= 0:
            raise RuntimeError("invalid idempotency owner pid")
        with self._transaction():
            return self._claim_locked(
                key_sha256=key_sha256,
                payload_sha256=payload_sha256,
                job_id=job_id,
                access_token=access_token,
                owner_nonce=owner_nonce,
                owner_pid=owner_pid,
            )

    def _claim_locked(
        self,
        *,
        key_sha256: str,
        payload_sha256: str,
        job_id: str,
        access_token: str,
        owner_nonce: str,
        owner_pid: int,
    ) -> JobCreateClaim:
        path = self._path(key_sha256)
        record = {
            "schemaVersion": SCHEMA_VERSION,
            "keySha256": key_sha256,
            "payloadSha256": payload_sha256,
            "status": "CLAIMED",
            "ownerNonce": owner_nonce,
            "ownerPid": owner_pid,
            "jobId": str(job_id),
            "accessToken": str(access_token),
            "claimedAt": self._utc_now_iso(),
        }
        self._ensure_private_directory(path.parent.parent)
        self._ensure_private_directory(path.parent)
        if durable_create_json_exclusive(path, record, mode=0o600):
            return JobCreateClaim(
                kind="owner",
                payload_sha256=payload_sha256,
                job_id=str(job_id),
                access_token=str(access_token),
                owner_nonce=owner_nonce,
            )

        existing = self._load_existing_record(path, key_sha256=key_sha256)
        if not hmac.compare_digest(existing["payloadSha256"], payload_sha256):
            return JobCreateClaim(
                kind="conflict",
                payload_sha256=payload_sha256,
                job_id=str(existing["jobId"]),
                access_token="",
            )
        if existing["status"] == "READY":
            response = dict(existing["response"])
            if str(response.get("jobId") or response.get("parentJobId") or "") != str(
                existing["jobId"]
            ) or str(response.get("accessToken") or "") != str(existing["accessToken"]):
                raise RuntimeError("job idempotency response authority mismatch")
            return JobCreateClaim(
                kind="replay",
                payload_sha256=payload_sha256,
                job_id=str(existing["jobId"]),
                access_token=str(existing["accessToken"]),
                response=response,
            )
        return JobCreateClaim(
            kind="pending",
            payload_sha256=payload_sha256,
            job_id=str(existing["jobId"]),
            access_token=str(existing["accessToken"]),
        )

    def contains_key(self, *, key: object) -> bool:
        """Return whether a valid durable key record already exists.

        This intentionally does not reveal record state. HTTP uses it only to
        let genuine replay/reconciliation attempts bypass the *new work* rate
        gate without letting fresh abusive keys create and fsync claim files.
        """

        normalized_key = validate_idempotency_key(key)
        key_sha256 = hashlib.sha256(normalized_key.encode("utf-8")).hexdigest()
        path = self._path(key_sha256)
        with self._transaction():
            if not path.exists():
                return False
            self._load_existing_record(path, key_sha256=key_sha256)
            return True

    def lookup(self, *, key: object) -> JobCreateClaim | None:
        """Look up one key for payload-free browser restart reconciliation."""

        normalized_key = validate_idempotency_key(key)
        key_sha256 = hashlib.sha256(normalized_key.encode("utf-8")).hexdigest()
        path = self._path(key_sha256)
        with self._transaction():
            if not path.exists():
                return None
            existing = self._load_existing_record(path, key_sha256=key_sha256)
            payload_sha256 = str(existing["payloadSha256"])
            if existing["status"] == "READY":
                response = dict(existing["response"])
                if str(response.get("jobId") or response.get("parentJobId") or "") != str(
                    existing["jobId"]
                ) or str(response.get("accessToken") or "") != str(existing["accessToken"]):
                    raise RuntimeError("job idempotency response authority mismatch")
                return JobCreateClaim(
                    kind="replay",
                    payload_sha256=payload_sha256,
                    job_id=str(existing["jobId"]),
                    access_token=str(existing["accessToken"]),
                    response=response,
                )
            return JobCreateClaim(
                kind="pending",
                payload_sha256=payload_sha256,
                job_id=str(existing["jobId"]),
                access_token=str(existing["accessToken"]),
            )

    def reconcile_startup(self, *, jobs_root: Path) -> dict[str, Any]:
        """Release only pre-ACCEPTED claims whose owning process is gone.

        A worker process can restart while the HTTP server is still accepting a
        request, so age or a new local process nonce is insufficient.  The
        durable owner PID protects live preflight claims; any existing job-state
        record protects committed/corrupt jobs for normal replay/operator review.
        """

        with self._transaction():
            root = Path(self._root())
            jobs = Path(jobs_root)
            result: dict[str, Any] = {
                "removedStalePreAccepted": 0,
                "keptLiveOwner": 0,
                "keptCommitted": 0,
                "errors": [],
            }
            for path in sorted(root.glob("*/*.json")):
                try:
                    key_sha256 = path.stem
                    record = self._load_existing_record(path, key_sha256=key_sha256)
                    if record["status"] != "CLAIMED":
                        continue
                    job_root = jobs / str(record["jobId"])
                    if (job_root / "job_state.json").exists():
                        result["keptCommitted"] += 1
                        continue
                    owner_pid = record.get("ownerPid")
                    if isinstance(owner_pid, int) and self._pid_is_alive(owner_pid):
                        result["keptLiveOwner"] += 1
                        continue
                    path.unlink(missing_ok=True)
                    fsync_directory(path.parent)
                    result["removedStalePreAccepted"] += 1
                except Exception as exc:
                    report_recovery("metod_app.jobs.idempotency.boundary.388", exc)
                    result["errors"].append(f"{path.name}: {exc}")
            for shard in sorted(root.iterdir() if root.exists() else []):
                if not shard.is_dir():
                    continue
                try:
                    shard.rmdir()
                    fsync_directory(root)
                except OSError as recovery_error:
                    report_recovery("metod_app.jobs.idempotency.reconcile_startup.393", recovery_error)
            return result

    def complete(
        self,
        *,
        key: object,
        payload_sha256: str,
        owner_nonce: str,
        response: Mapping[str, Any],
    ) -> None:
        with self._transaction():
            self._complete_locked(
                key=key,
                payload_sha256=payload_sha256,
                owner_nonce=owner_nonce,
                response=response,
            )

    def _complete_locked(
        self,
        *,
        key: object,
        payload_sha256: str,
        owner_nonce: str,
        response: Mapping[str, Any],
    ) -> None:
        normalized_key = validate_idempotency_key(key)
        key_sha256 = hashlib.sha256(normalized_key.encode("utf-8")).hexdigest()
        path = self._path(key_sha256)
        existing = self._load_existing_record(path, key_sha256=key_sha256)
        if existing["status"] == "READY":
            # A retry can durably recover the same job while the original request
            # is between scheduler commit and READY. Response metadata may differ,
            # but job/capability authority may not.
            existing_response = dict(existing["response"])
            if str(existing_response.get("jobId") or existing_response.get("parentJobId") or "") != str(
                response.get("jobId") or response.get("parentJobId") or ""
            ) or str(existing_response.get("accessToken") or "") != str(response.get("accessToken") or ""):
                raise RuntimeError("job idempotency completion mismatch")
            return
        if not hmac.compare_digest(str(existing.get("payloadSha256") or ""), payload_sha256):
            raise RuntimeError("job idempotency payload changed during completion")
        if not hmac.compare_digest(str(existing.get("ownerNonce") or ""), str(owner_nonce)):
            raise RuntimeError("job idempotency claim owner mismatch")
        job_id = str(existing["jobId"])
        access_token = str(existing["accessToken"])
        if (
            str(response.get("jobId") or response.get("parentJobId") or "") != job_id
            or str(response.get("accessToken") or "") != access_token
        ):
            raise RuntimeError("job idempotency completion response mismatch")
        ready = {
            **existing,
            "status": "READY",
            "readyAt": self._utc_now_iso(),
            "response": dict(response),
        }
        ready.pop("ownerNonce", None)
        durable_write_json(path, ready, mode=0o600)

    def recover(
        self,
        *,
        key: object,
        payload_sha256: str,
        response: Mapping[str, Any],
    ) -> dict[str, Any]:
        """Promote a crash-window claim after the runner durably progressed."""

        with self._transaction():
            return self._recover_locked(
                key=key,
                payload_sha256=payload_sha256,
                response=response,
            )

    def _recover_locked(
        self,
        *,
        key: object,
        payload_sha256: str,
        response: Mapping[str, Any],
    ) -> dict[str, Any]:
        normalized_key = validate_idempotency_key(key)
        key_sha256 = hashlib.sha256(normalized_key.encode("utf-8")).hexdigest()
        path = self._path(key_sha256)
        existing = self._load_existing_record(path, key_sha256=key_sha256)
        if not hmac.compare_digest(str(existing.get("payloadSha256") or ""), payload_sha256):
            raise RuntimeError("job idempotency recovery payload mismatch")
        if existing["status"] == "READY":
            return dict(existing["response"])
        job_id = str(existing["jobId"])
        access_token = str(existing["accessToken"])
        if (
            str(response.get("jobId") or response.get("parentJobId") or "") != job_id
            or str(response.get("accessToken") or "") != access_token
        ):
            raise RuntimeError("job idempotency recovery response mismatch")
        ready = {
            **existing,
            "status": "READY",
            "readyAt": self._utc_now_iso(),
            "recovered": True,
            "response": dict(response),
        }
        ready.pop("ownerNonce", None)
        durable_write_json(path, ready, mode=0o600)
        return dict(response)

    def abandon(
        self,
        *,
        key: object,
        payload_sha256: str,
        owner_nonce: str,
    ) -> bool:
        with self._transaction():
            return self._abandon_locked(
                key=key,
                payload_sha256=payload_sha256,
                owner_nonce=owner_nonce,
            )

    def _abandon_locked(
        self,
        *,
        key: object,
        payload_sha256: str,
        owner_nonce: str,
    ) -> bool:
        normalized_key = validate_idempotency_key(key)
        key_sha256 = hashlib.sha256(normalized_key.encode("utf-8")).hexdigest()
        path = self._path(key_sha256)
        try:
            existing = self._load_existing_record(path, key_sha256=key_sha256)
        except FileNotFoundError:
            return False
        if existing["status"] != "CLAIMED":
            return False
        if not hmac.compare_digest(str(existing.get("payloadSha256") or ""), payload_sha256):
            return False
        if not hmac.compare_digest(str(existing.get("ownerNonce") or ""), str(owner_nonce)):
            return False
        path.unlink(missing_ok=True)
        fsync_directory(path.parent)
        try:
            path.parent.rmdir()
            fsync_directory(path.parent.parent)
        except OSError as recovery_error:
            report_recovery("metod_app.jobs.idempotency._abandon_locked.547", recovery_error)
        return True

    def cleanup(
        self,
        *,
        jobs_root: Path,
        cutoff_timestamp: float,
    ) -> dict[str, Any]:
        """Remove only old mappings whose authoritative job no longer exists.

        A CLAIMED record with a job directory can still be completing or can be
        needed to recover a lost READY write, so its age alone never authorizes
        deletion.  A pre-job claim gets the same multi-day orphan grace period as
        an orphan job before it can be reclaimed.
        """

        with self._transaction():
            return self._cleanup_locked(
                jobs_root=jobs_root,
                cutoff_timestamp=cutoff_timestamp,
            )

    def _cleanup_locked(
        self,
        *,
        jobs_root: Path,
        cutoff_timestamp: float,
    ) -> dict[str, Any]:
        root = Path(self._root())
        self._ensure_private_directory(root)
        jobs_root = Path(jobs_root)
        result: dict[str, Any] = {"removed": 0, "keptLive": 0, "errors": []}
        for path in sorted(root.glob("*/*.json")):
            try:
                if path.stat().st_mtime >= float(cutoff_timestamp):
                    continue
                key_sha256 = path.stem
                record = self._validate_record(strict_json_load(path), key_sha256=key_sha256)
                job_id = str(record["jobId"])
                if (jobs_root / job_id).is_dir():
                    result["keptLive"] += 1
                    continue
                # A pre-ACCEPTED owner can legitimately spend time parsing and
                # validating a large upload before the job directory exists.
                # Retention is allowed to reclaim only an abandoned/dead claim;
                # age alone must never delete a live owner's duplicate boundary.
                if record["status"] == "CLAIMED":
                    owner_pid = record.get("ownerPid")
                    if isinstance(owner_pid, int) and self._pid_is_alive(owner_pid):
                        result["keptLive"] += 1
                        continue
                path.unlink(missing_ok=True)
                fsync_directory(path.parent)
                result["removed"] += 1
            except Exception as exc:
                # Corrupt authority is fail-closed and requires operator review;
                # silently deleting it could permit a duplicate production run.
                report_recovery("metod_app.jobs.idempotency.boundary.611", exc)
                result["errors"].append(f"{path.name}: {exc}")
        for shard in sorted(root.iterdir() if root.exists() else []):
            if not shard.is_dir():
                continue
            try:
                shard.rmdir()
                fsync_directory(root)
            except OSError as recovery_error:
                report_recovery("metod_app.jobs.idempotency._cleanup_locked.618", recovery_error)
        return result


__all__ = (
    "JobCreateClaim",
    "JobCreateIdempotencyRepository",
    "public_job_payload_sha256",
    "validate_idempotency_key",
)
