"""Pure diagnostic-text and structured-log redaction.

The functions in this module preserve the established behavior. They own
no environment, paths, state, locks, logging sinks, HTTP or other I/O.
"""

from __future__ import annotations

from metod_app.observability.failures import report_recovery


import re
import ipaddress
from typing import Any


_REDACT_EMAIL_RE = re.compile(r"([A-Za-z0-9._%+-])[A-Za-z0-9._%+-]*@([A-Za-z0-9.-]+\.[A-Za-z]{2,})")
_REDACT_IBAN_RE = re.compile(r"\b[A-Z]{2}\d{2}(?:[ ]?[A-Z0-9]){10,30}\b", re.I)
_REDACT_PHONE_RE = re.compile(r"(?<!\w)(?:\+?\d[\d()\-\s]{6,}\d)(?!\w)")
_REDACT_POSTCODE_RE = re.compile(r"\b\d{4}\s?[A-Za-z]{2}\b")
_REDACT_AUTH_STRUCT_RE = re.compile(
    r"""(?i)(?:['"])?(?:authorization|proxy-authorization)(?:['"])?\s*[:=]\s*['"][^'"\r\n]*['"]"""
)
_REDACT_COOKIE_STRUCT_RE = re.compile(
    r"""(?i)(?:['"])?(?:cookie|set-cookie)(?:['"])?\s*[:=]\s*['"][^'"\r\n]*['"]"""
)
_REDACT_AUTH_HEADER_RE = re.compile(r"(?im)\b(?:authorization|proxy-authorization)\b\s*:\s*[^\r\n]*")
_REDACT_COOKIE_HEADER_RE = re.compile(r"(?im)\b(?:cookie|set-cookie)\b\s*:\s*[^\r\n]*")
_REDACT_AUTH_ASSIGN_RE = re.compile(
    r"(?i)\b(?:authorization|proxy-authorization)\b\s*=\s*(?:(?:bearer|basic)\s+)?[^,;\s]+"
)
_REDACT_BEARER_RE = re.compile(r"(?i)\bbearer[ \t]+[^\s,;\"']+")
_REDACT_COOKIE_ASSIGN_RE = re.compile(r"(?i)\b(?:cookie|set-cookie)\b\s*=\s*[^,\r\n]+")
_REDACT_TOKEN_RE = re.compile(r"(?i)\b(?:token|password|passwd|secret)\b\s*[:=]\s*[^,;\s]+")
_REDACT_URL_QUERY_RE = re.compile(
    r"([?&](?:email|mail|phone|tel|telephone|address|postcode|postalcode|token|password|secret)=[^&#]*)", re.I
)
_REDACT_IPV4_RE = re.compile(r"(?<![\w.])(?:\d{1,3}\.){3}\d{1,3}(?![\w.])")
_REDACT_IPV6_RE = re.compile(r"(?<![0-9A-Za-z])(?:[0-9A-Fa-f]{0,4}:){2,7}[0-9A-Fa-f]{0,4}(?![0-9A-Za-z])")

_SENSITIVE_LOG_KEYS = frozenset(
    {
        "iban",
        "bankaccount",
        "bank_account",
        "password",
        "passwd",
        "secret",
        "token",
        "authorization",
        "cookie",
        "set-cookie",
        "email",
        "mail",
        "phone",
        "tel",
        "telephone",
        "address",
        "billingaddress",
        "shippingaddress",
        "postcode",
        "postalcode",
        "ip",
        "clientip",
        "client_ip",
        "remoteip",
        "remote_ip",
        "remoteaddr",
        "remote_addr",
        "x-forwarded-for",
        "x-real-ip",
    }
)


def _redact_ip_candidate(match: re.Match[str]) -> str:
    candidate = match.group(0)
    try:
        ipaddress.ip_address(candidate)
        return "[redacted-ip]"
    except ValueError:
        return candidate


def safe_text(value: Any, max_len: int = 240) -> str:
    try:
        text = str(value or "").strip()
    except Exception as recovery_error:
        report_recovery("metod_app.security.redaction.boundary.52", recovery_error)
        text = ""
    if len(text) > max_len:
        text = text[: max_len - 1] + "…"
    return text


def redact_sensitive_text(value: Any, max_len: int = 240) -> str:
    text = safe_text(value, max_len=max_len * 2 if max_len and max_len > 0 else 480)
    if not text:
        return ""
    try:
        text = _REDACT_EMAIL_RE.sub("[redacted-email]", text)
        text = _REDACT_IBAN_RE.sub("[redacted-iban]", text)
        text = _REDACT_PHONE_RE.sub("[redacted-phone]", text)
        text = _REDACT_POSTCODE_RE.sub("[redacted-postcode]", text)
        # Header credentials are line-valued. Redact the complete value before
        # the generic key=value pass so a second token cannot remain visible.
        text = _REDACT_AUTH_STRUCT_RE.sub("authorization=[redacted-secret]", text)
        text = _REDACT_COOKIE_STRUCT_RE.sub("cookie=[redacted-secret]", text)
        text = _REDACT_AUTH_HEADER_RE.sub("Authorization: [redacted-secret]", text)
        text = _REDACT_COOKIE_HEADER_RE.sub("Cookie: [redacted-secret]", text)
        text = _REDACT_AUTH_ASSIGN_RE.sub("authorization=[redacted-secret]", text)
        # Credentials also surface in exception strings without an
        # ``Authorization:`` prefix. Redact every standalone Bearer value,
        # including short test/development tokens.
        text = _REDACT_BEARER_RE.sub("Bearer [redacted-secret]", text)
        text = _REDACT_COOKIE_ASSIGN_RE.sub("cookie=[redacted-secret]", text)
        text = _REDACT_TOKEN_RE.sub("[redacted-secret]", text)
        text = _REDACT_URL_QUERY_RE.sub("[redacted-query]", text)
        text = _REDACT_IPV4_RE.sub(_redact_ip_candidate, text)
        text = _REDACT_IPV6_RE.sub(_redact_ip_candidate, text)
    except Exception as recovery_error:
        report_recovery("metod_app.security.redaction.boundary.84", recovery_error)
        return "[redacted: unavailable]"
    if max_len and len(text) > max_len:
        text = text[: max_len - 1] + "…"
    return text


def sanitize_log_value(value: Any, *, max_depth: int = 2, max_items: int = 20) -> Any:
    if max_depth < 0:
        return "[truncated]"
    if value is None or isinstance(value, (bool, int, float)):
        return value
    if isinstance(value, str):
        return redact_sensitive_text(value, 300)
    if isinstance(value, dict):
        output: dict[str, Any] = {}
        for index, (key, child) in enumerate(value.items()):
            if index >= max_items:
                output["__truncated__"] = True
                break
            key_text = redact_sensitive_text(str(key), 80)
            if key_text.lower() in _SENSITIVE_LOG_KEYS:
                output[key_text] = "[redacted]"
            else:
                output[key_text] = sanitize_log_value(
                    child,
                    max_depth=max_depth - 1,
                    max_items=max_items,
                )
        return output
    if isinstance(value, (list, tuple)):
        output = []
        for index, item in enumerate(value):
            if index >= max_items:
                output.append("[truncated]")
                break
            output.append(
                sanitize_log_value(
                    item,
                    max_depth=max_depth - 1,
                    max_items=max_items,
                )
            )
        return output
    return redact_sensitive_text(value, 200)


__all__ = ("redact_sensitive_text", "safe_text", "sanitize_log_value")
