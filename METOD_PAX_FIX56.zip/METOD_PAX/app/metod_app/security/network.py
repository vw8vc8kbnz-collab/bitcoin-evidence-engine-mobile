"""Bounded DNS resolution for allowlisted outbound image downloads."""

from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutureTimeout
import socket
import threading

_RESOLVERS = ThreadPoolExecutor(max_workers=4, thread_name_prefix="catalog-dns")
_SLOTS = threading.BoundedSemaphore(4)


def resolve_public_host(host: str, *, timeout: float):
    if not _SLOTS.acquire(blocking=False):
        raise TimeoutError("DNS-resolutie is tijdelijk bezet. Probeer opnieuw.")
    try:
        future = _RESOLVERS.submit(socket.getaddrinfo, host, 443, type=socket.SOCK_STREAM)
    except RuntimeError:
        _SLOTS.release()
        raise
    future.add_done_callback(lambda _: _SLOTS.release())
    try:
        return future.result(timeout=max(0.01, min(12.0, timeout)))
    except FutureTimeout as error:
        future.cancel()
        raise TimeoutError("DNS-resolutie duurde te lang.") from error
