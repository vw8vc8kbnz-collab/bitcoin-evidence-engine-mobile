"""Server-owned template identity and the deliberately rectangular free-panel contract."""

from __future__ import annotations

import hashlib
import math
from pathlib import Path

from dxf_geometry import (
    entities_bbox,
    entities_section,
    entity_bbox,
    entity_layer,
    entity_type,
    parse_pairs,
    split_entities,
    validate_production_entity,
)
from safety_contracts import ContractError, finite_number


def validated_panel_geometry(pairs):
    """Return checked entities and bounds for an admitted production panel."""
    entities = split_entities(entities_section(pairs))
    if not entities:
        raise ContractError("DXF bevat geen geometrie")
    for entity in entities:
        validate_production_entity(entity)
        if entity_type(entity) == "LWPOLYLINE" and entity_layer(entity).upper() != "OUTLINE":
            raise ContractError("Alleen OUTLINE LWPOLYLINE is toegestaan")
        if entity_bbox(entity) is None:
            raise ContractError("DXF-entity heeft geen geldige bbox")
    return entities, entities_bbox(entities)


def rectangular_outline(entities):
    """No diagonal/internal LINE machining may be silently replaced by a rectangle."""
    outline = [entity for entity in entities if entity_type(entity) in {"LINE", "LWPOLYLINE"}]
    if len(outline) == 1 and entity_type(outline[0]) == "LWPOLYLINE":
        validate_production_entity(outline[0])
        return entities_bbox(outline)
    if not outline or any(entity_type(entity) != "LINE" for entity in outline):
        raise ContractError("Een paneel vereist precies één rechthoekige contour")
    bbox = entities_bbox(outline)
    sides = {key: [] for key in ("left", "right", "bottom", "top")}
    tolerance = 1e-5
    for entity in outline:
        values = {code: float(value) for code, value in entity if code in {10, 20, 11, 21}}
        x1, y1, x2, y2 = (values[c] for c in (10, 20, 11, 21))
        side = None
        if abs(x1 - x2) <= tolerance and abs(y1 - y2) > tolerance:
            if abs(x1 - bbox.min_x) <= tolerance:
                side = "left"
            elif abs(x1 - bbox.max_x) <= tolerance:
                side = "right"
            interval = sorted((y1, y2))
        elif abs(y1 - y2) <= tolerance and abs(x1 - x2) > tolerance:
            if abs(y1 - bbox.min_y) <= tolerance:
                side = "bottom"
            elif abs(y1 - bbox.max_y) <= tolerance:
                side = "top"
            interval = sorted((x1, x2))
        if side is None:
            raise ContractError("Diagonale, interne of lege LINE-contour")
        sides[side].append(interval)
    # Some corner-front templates split one straight edge into several LINEs.
    # Allow only a contiguous, non-overlapping covering of each rectangle edge.
    for side, intervals in sides.items():
        lower, upper = (bbox.min_y, bbox.max_y) if side in {"left", "right"} else (bbox.min_x, bbox.max_x)
        cursor = lower
        for start, end in sorted(intervals):
            if abs(start - cursor) > tolerance:
                raise ContractError("Onvolledige of overlappende LINE-contour")
            cursor = end
        if abs(cursor - upper) > tolerance:
            raise ContractError("Onvolledige LINE-contour")
    return bbox


def _machining_signature(entities, bbox, *, mirror=False, bottom=0):
    result = []
    for entity in entities:
        kind = entity_type(entity)
        if kind not in {"CIRCLE", "ARC"}:
            continue
        values = {code: float(value) for code, value in entity if code in {10, 20, 40, 50, 51}}
        x = values[10] - bbox.min_x
        y = values[20] - bbox.min_y + bottom
        if mirror:
            x = bbox.width - x
        row = [kind, x, y, values[40]]
        if kind == "ARC":
            start, end = values[50] % 360, values[51] % 360
            if mirror:
                start, end = (180 - end) % 360, (180 - start) % 360
            row.extend((start, end))
        result.append(tuple(row))
    return sorted(result)


def validate_panel_intent(entities, intent, template_root: Path, cache: dict) -> dict:
    bbox = rectangular_outline(entities)
    machining = _machining_signature(entities, bbox)
    if intent is None and not machining:
        intent = {"kind": "free"}  # legacy rectangular free panels remain valid
    if not isinstance(intent, dict):
        raise ContractError("Templategegevens ontbreken. Herlaad de tool en bereken opnieuw.")
    if intent.get("kind") == "free":
        if set(intent) != {"kind"} or machining:
            raise ContractError("Een vrij paneel mag geen templateboringen bevatten")
        return {"kind": "free", "geometryPolicy": "flat-rectangle-v1"}
    template_keys = {"kind", "sourceName", "hinge", "extTopMm", "extBottomMm"}
    if intent.get("kind") != "template" or set(intent) != template_keys:
        raise ContractError("Ongeldig productie-templatecontract")
    source_name = intent.get("sourceName")
    if not isinstance(source_name, str) or not source_name.strip() or len(source_name) > 240:
        raise ContractError("Ongeldige templatenaam")
    name = source_name.strip()
    if "\\" in name or Path(name).is_absolute() or ".." in Path(name).parts:
        raise ContractError("Ongeldig templatepad")
    if not name.lower().endswith(".dxf"):
        name += ".dxf"
    hinge = intent.get("hinge")
    if hinge not in {"left", "right"}:
        raise ContractError("Ongeldige scharnierrichting")
    top = finite_number(intent.get("extTopMm"), field="extTopMm", minimum=0, maximum=999)
    bottom = finite_number(intent.get("extBottomMm"), field="extBottomMm", minimum=0, maximum=999)
    if name not in cache:
        root = template_root.resolve(strict=True)
        # The public template manifest historically uses both basenames and paths.
        candidates = [root / name] if "/" in name else [path for path in root.rglob("*") if path.name == name]
        candidates = [
            path
            for path in candidates
            if path.is_file() and not path.is_symlink() and root in path.resolve().parents
        ]
        if len(candidates) != 1:
            raise ContractError("Template ontbreekt of is niet eenduidig. Herlaad de tool.")
        path = candidates[0]
        content = path.read_bytes()
        if len(content) > 2 * 1024 * 1024:
            raise ContractError("Productietemplate is te groot")
        source, _ = validated_panel_geometry(parse_pairs(content.decode("utf-8")))
        source_bbox = rectangular_outline(source)
        cache[name] = (
            source,
            source_bbox,
            hashlib.sha256(content).hexdigest(),
            path.relative_to(root).as_posix(),
        )
    source, source_bbox, digest, relative = cache[name]
    expected = _machining_signature(source, source_bbox, mirror=hinge == "left", bottom=bottom)
    if (
        abs(bbox.width - source_bbox.width) > 1e-5
        or abs(bbox.height - source_bbox.height - top - bottom) > 1e-5
        or len(machining) != len(expected)
    ):
        raise ContractError("Productiegeometrie wijkt af van het gekozen template")
    for actual, wanted in zip(machining, expected):
        matches = actual[0] == wanted[0] and all(
            math.isclose(a, b, rel_tol=0, abs_tol=1e-5) for a, b in zip(actual[1:], wanted[1:])
        )
        if not matches:
            raise ContractError("Boringen wijken af van het gekozen template en de opgegeven transformaties")
    return {
        **intent,
        "sourceName": relative,
        "sourceSha256": digest,
        "extTopMm": top,
        "extBottomMm": bottom,
        "geometryPolicy": "template-b-side-v1",
    }
