"""Pure validation and normalization for the final-submit payload.

This module owns no files, locks, processes, HTTP handlers or mutable global
state.  The behavior is intentionally extracted byte-for-behavior from the
server owner and is protected by the paired server oracle.
"""

from __future__ import annotations

from metod_app.observability.failures import report_recovery

import re
from typing import Any

from safety_contracts import ensure_finite_json, finite_number, strict_json_dumps


EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
ALLOWED_SUBMIT_ROOT_KEYS = frozenset(
    {
        "jobId",
        "parentJobId",
        "subjobId",
        "ts",
        "material",
        "customer",
        "note",
        "grainEnabled",
        "quote",
        "cart",
        "extraPanels",
        "priceInclVat",
        "platesTotal",
        "materialsSummary",
        "checkout",
    }
)
FORBIDDEN_FILE_CHARS = frozenset('/\\:*?"<>|')
# Customer-facing text may contain normal Dutch/business punctuation. Path
# separators, markup delimiters and control characters remain excluded.
ALLOWED_USER_TEXT_EXTRA = frozenset(" .,_-'’‘&()")
ALLOWED_NOTE_EXTRA = ALLOWED_USER_TEXT_EXTRA
MAX_NOTE_LENGTH = 2000


def sanitize_note(value: Any) -> str:
    """Preserve customer instructions; filesystem restrictions belong to filenames.

    Notes remain plain text. HTML renderers escape them at their output boundary.
    Whitespace is normalized so a note cannot impersonate a report section.
    Length is validated before this function is called by request boundaries.
    """
    text = str(value or "")
    if len(text) > MAX_NOTE_LENGTH:
        raise ValueError(f"Opmerking mag maximaal {MAX_NOTE_LENGTH} tekens bevatten.")
    text = " ".join(text.split())
    return "".join(character for character in text if character.isprintable())


def clean_text(value: Any, max_len: int = 5000) -> str:
    text = str(value or "")
    if len(text) > int(max_len):
        text = text[: int(max_len)]
    return text


def sanitize_user_text(
    value: Any,
    max_len: int = 240,
    *,
    allow_note_chars: bool = False,
) -> str:
    if allow_note_chars:
        return sanitize_note(value)
    raw = clean_text(value, max_len * 4 if max_len else 4000)
    extras = ALLOWED_NOTE_EXTRA if allow_note_chars else ALLOWED_USER_TEXT_EXTRA
    out: list[str] = []
    last_space = False
    for character in raw:
        if character in ("\r", "\n", "\t"):
            character = " "
        allowed = character.isalnum() or character in extras
        if not allowed and character in FORBIDDEN_FILE_CHARS:
            character = " "
            allowed = True
        if not allowed:
            continue
        if character.isspace():
            if last_space:
                continue
            out.append(" ")
            last_space = True
        else:
            out.append(character)
            last_space = False
    text = "".join(out).strip()
    if max_len and len(text) > int(max_len):
        text = text[: int(max_len)].rstrip()
    return text


def sanitize_phone_text(value: Any, max_len: int = 60) -> str:
    raw = clean_text(value, max_len * 2)
    out = [character for character in raw if character.isdigit() or character in " +()-"]
    return re.sub(r"\s+", " ", "".join(out)).strip()[:max_len]


def sanitize_postcode_text(value: Any, max_len: int = 16) -> str:
    raw = clean_text(value, max_len * 2)
    out = [character.upper() for character in raw if character.isalnum() or character == " "]
    return re.sub(r"\s+", " ", "".join(out)).strip()[:max_len]


def sanitize_house_number_text(value: Any, max_len: int = 32) -> str:
    """Keep a bounded house-number token, including legitimate ``12/A`` forms."""

    raw = clean_text(value, max_len * 2)
    out: list[str] = []
    last_space = False
    for character in raw:
        if character in ("\r", "\n", "\t"):
            character = " "
        allowed = character.isalnum() or character in " -/"
        if not allowed:
            continue
        if character.isspace():
            if last_space:
                continue
            out.append(" ")
            last_space = True
        else:
            out.append(character)
            last_space = False
    return "".join(out).strip()[:max_len].rstrip()


def normalize_customer_contract(value: Any) -> dict[str, Any]:
    """Return the canonical, sanitized billing/shipping customer contract."""

    source = value if isinstance(value, dict) else {}

    def first_raw(*keys: str) -> Any:
        for key in keys:
            candidate = source.get(key)
            if candidate not in (None, ""):
                return candidate
        return ""

    def user(*keys: str, max_len: int = 500) -> str:
        return sanitize_user_text(first_raw(*keys), max_len)

    first_name = user("firstName")
    last_name = user("lastName")
    full_name = user("name", "fullName") or " ".join(item for item in (first_name, last_name) if item).strip()
    billing_address = user("billingAddress", "invoiceAddress", "address", "addressLine1", "street")
    postcode = sanitize_postcode_text(first_raw("postcode", "postalCode"), 16)
    house_number = sanitize_house_number_text(first_raw("houseNumber", "housenumber"), 32)
    shipping_same = source.get("shippingSameAsBilling")
    shipping_same_as_billing = shipping_same if isinstance(shipping_same, bool) else True
    if shipping_same_as_billing:
        shipping_address = billing_address
        shipping_postcode = postcode
        shipping_house_number = house_number
    else:
        # address1 historically represented either billing or shipping. Once the
        # sender explicitly requests a distinct address it is no longer unambiguous.
        shipping_address = user("shippingAddress", "deliveryAddress")
        shipping_postcode = sanitize_postcode_text(
            first_raw("shippingPostcode", "shippingPostalCode", "deliveryPostcode", "deliveryPostalCode"),
            16,
        )
        shipping_house_number = sanitize_house_number_text(
            first_raw("shippingHouseNumber", "deliveryHouseNumber"),
            32,
        )

    return {
        "name": full_name,
        "fullName": full_name,
        "firstName": first_name,
        "lastName": last_name,
        "company": user("company", "companyName"),
        "email": clean_text(first_raw("email", "mail"), 320).strip(),
        "phone": sanitize_phone_text(first_raw("phone", "tel", "telephone"), 60),
        "billingAddress": billing_address,
        "postcode": postcode,
        "postalCode": postcode,
        "houseNumber": house_number,
        "shippingAddress": shipping_address,
        "shippingPostcode": shipping_postcode,
        "shippingHouseNumber": shipping_house_number,
        "shippingSameAsBilling": shipping_same_as_billing,
        "address1": shipping_address or billing_address,
        "address2": user("address2"),
        "city": user("city", "plaats"),
        "country": user("country"),
        "shippingCity": user("city", "plaats") if shipping_same_as_billing else user("shippingCity"),
        "shippingCountry": user("country") if shipping_same_as_billing else user("shippingCountry"),
        "note": sanitize_note(first_raw("note")),
    }


ALLOWED_CUSTOMER_KEYS = {
    "name",
    "fullName",
    "firstName",
    "lastName",
    "company",
    "companyName",
    "email",
    "mail",
    "phone",
    "tel",
    "telephone",
    "billingAddress",
    "invoiceAddress",
    "address",
    "addressLine1",
    "street",
    "shippingAddress",
    "deliveryAddress",
    "address1",
    "shippingPostcode",
    "shippingPostalCode",
    "deliveryPostcode",
    "deliveryPostalCode",
    "shippingHouseNumber",
    "deliveryHouseNumber",
    "shippingSameAsBilling",
    "shippingCity",
    "shippingCountry",
    "houseNumber",
    "postalCode",
    "postcode",
    "city",
    "plaats",
    "country",
    "note",
}

ALLOWED_PANEL_KEYS = {
    "id",
    "type",
    "size",
    "qty",
    "quantity",
    "width",
    "height",
    "length",
    "name",
    "panelName",
    "description",
    "materialCode",
    "materialKey",
    "articleNumber",
    "materialDisplayName",
    "productName",
    "decorName",
    "grainGroupId",
    "grainOrder",
    "rotation",
    "topExt",
    "bottomExt",
    "extensions",
    "edgeBanding",
    "material",
    "hingeSide",
    "swingDirection",
}


def _validate_submit_identifiers(payload, clean, errors):
    def safe_id_field(name: str, max_len: int = 200) -> None:
        value = payload.get(name)
        if value in (None, ""):
            return
        normalized = str(value).strip()
        if len(normalized) > min(120, int(max_len)) or not re.fullmatch(
            "[A-Za-z0-9][A-Za-z0-9_-]*", normalized
        ):
            errors.append(f"Ongeldige waarde voor {name}.")
        else:
            clean[name] = normalized

    safe_id_field("jobId")
    safe_id_field("parentJobId")
    safe_id_field("subjobId")
    if payload.get("ts") not in (None, ""):
        timestamp = str(payload.get("ts")).strip()
        if len(timestamp) > 80:
            errors.append("Tijdstempel is te lang.")
        else:
            clean["ts"] = timestamp
    material = payload.get("material")
    if material is not None:
        if not isinstance(material, (str, dict, list, type(None))):
            errors.append("Materiaalveld heeft een ongeldig type.")
        else:
            clean["material"] = material
    grain_enabled = payload.get("grainEnabled")
    if grain_enabled is not None and (not isinstance(grain_enabled, bool)):
        errors.append("grainEnabled moet true of false zijn.")
    else:
        clean["grainEnabled"] = bool(grain_enabled) if grain_enabled is not None else None
    note = payload.get("note")
    if "note" in payload:
        if not isinstance(note, str):
            errors.append("Opmerking moet tekst zijn.")
        elif len(note) > MAX_NOTE_LENGTH:
            errors.append(f"Opmerking mag maximaal {MAX_NOTE_LENGTH} tekens bevatten.")
        else:
            clean["note"] = sanitize_note(note)


def _validate_submit_customer(payload, clean, errors):
    customer = payload.get("customer")
    if customer is None:
        customer = {}
    if not isinstance(customer, dict):
        errors.append("Klantgegevens moeten een object zijn.")
        customer = {}
    clean_customer: dict[str, Any] = {}
    for key, value in list(customer.items())[:100]:
        if key not in ALLOWED_CUSTOMER_KEYS:
            continue
        if key == "shippingSameAsBilling":
            if not isinstance(value, bool):
                errors.append("Klantveld shippingSameAsBilling moet true of false zijn.")
            else:
                clean_customer[key] = bool(value)
            continue
        if not isinstance(value, str):
            errors.append(f"Klantveld {key} moet tekst zijn.")
            continue
        max_len = 320 if key in {"email", "mail"} else 500
        if key in {"email", "mail"}:
            clean_customer[key] = clean_text(value, max_len).strip()
        elif key in {"phone", "tel", "telephone"}:
            clean_customer[key] = sanitize_phone_text(value, min(max_len, 60))
        elif key in {
            "postalCode",
            "postcode",
            "shippingPostcode",
            "shippingPostalCode",
            "deliveryPostcode",
            "deliveryPostalCode",
        }:
            clean_customer[key] = sanitize_postcode_text(value, 16)
        elif key in {"houseNumber", "shippingHouseNumber", "deliveryHouseNumber"}:
            clean_customer[key] = sanitize_house_number_text(value, 32)
        elif key == "note":
            if len(value) > MAX_NOTE_LENGTH:
                errors.append(f"Opmerking mag maximaal {MAX_NOTE_LENGTH} tekens bevatten.")
            else:
                clean_customer[key] = sanitize_note(value)
        else:
            clean_customer[key] = sanitize_user_text(value, max_len)
    email = str(clean_customer.get("email") or clean_customer.get("mail") or "").strip()
    if email and (not EMAIL_RE.match(email)):
        errors.append("E-mailadres is ongeldig.")
    clean["customer"] = clean_customer


def _validate_submit_quote(payload, clean, errors):
    quote = payload.get("quote")
    if quote is not None and (not isinstance(quote, dict)):
        errors.append("Quote moet een object zijn.")
    elif isinstance(quote, dict):
        try:
            ensure_finite_json(quote)
            if len(strict_json_dumps(quote)) > 400000:
                errors.append("Quote is te groot.")
            else:
                clean["quote"] = quote
        except (ValueError, TypeError, OverflowError, RecursionError) as recovery_error:
            report_recovery("metod_app.contracts.submission.boundary.346", recovery_error)
            errors.append("Quote kon niet worden verwerkt.")


def _validate_submit_materials(payload, clean, errors):
    materials = payload.get("materialsSummary")
    if materials is not None:
        if not isinstance(materials, list):
            errors.append("materialsSummary moet een lijst zijn.")
        elif len(materials) > 100:
            errors.append("materialsSummary bevat te veel regels.")
        else:
            clean_materials: list[dict[str, Any]] = []
            for index, item in enumerate(materials):
                if not isinstance(item, dict):
                    errors.append(f"materialsSummary regel {index + 1} is ongeldig.")
                    continue
                row: dict[str, Any] = {}
                for key in ("code", "name"):
                    if item.get(key) not in (None, ""):
                        if not isinstance(item.get(key), str):
                            errors.append(f"materialsSummary.{key} op regel {index + 1} moet tekst zijn.")
                        else:
                            row[key] = clean_text(item.get(key), 200)
                if item.get("plates") not in (None, ""):
                    try:
                        row["plates"] = finite_number(
                            item.get("plates"), field="materialsSummary.plates", minimum=0, maximum=10000
                        )
                    except (OSError, ValueError, TypeError, OverflowError):
                        errors.append(f"materialsSummary.plates op regel {index + 1} is ongeldig.")
                clean_materials.append(row)
            clean["materialsSummary"] = clean_materials
    for number_name in ("priceInclVat", "platesTotal"):
        if payload.get(number_name) not in (None, ""):
            try:
                clean[number_name] = finite_number(
                    payload.get(number_name), field=number_name, minimum=0, maximum=100000000
                )
            except (OSError, ValueError, TypeError, OverflowError):
                errors.append(f"{number_name} is ongeldig.")


def _validate_submit_panel_list(payload, name, clean, errors) -> None:
    items = payload.get(name)
    if items is None:
        clean[name] = []
        return
    if not isinstance(items, list):
        errors.append(f"{name} moet een lijst zijn.")
        return
    if len(items) > 1000:
        errors.append(f"{name} bevat te veel regels.")
        return
    clean_items: list[dict[str, Any]] = []
    for index, item in enumerate(items):
        if not isinstance(item, dict):
            errors.append(f"{name} regel {index + 1} is ongeldig.")
            continue
        row: dict[str, Any] = {}
        for key, value in list(item.items())[:80]:
            if key not in ALLOWED_PANEL_KEYS:
                continue
            if isinstance(value, (str, int, float, bool)) or value is None:
                if isinstance(value, str):
                    if key in {"name", "panelName", "description", "productName", "articleNumber"}:
                        row[key] = sanitize_user_text(value, 240)
                    else:
                        row[key] = clean_text(value, 500)
                else:
                    row[key] = value
            elif isinstance(value, dict):
                if key == "edgeBanding":
                    edge_banding = {}
                    for edge_key, edge_value in list(value.items())[:10]:
                        if edge_key in {"top", "bottom", "left", "right"}:
                            edge_banding[edge_key] = bool(edge_value)
                    row[key] = edge_banding
                elif key == "extensions":
                    extensions = {}
                    for extension_key, extension_value in list(value.items())[:10]:
                        if extension_key in {"top", "bottom"}:
                            try:
                                extensions[extension_key] = finite_number(
                                    extension_value,
                                    field=f"{name}.{extension_key}",
                                    minimum=0,
                                    maximum=100000,
                                )
                            except (OSError, ValueError, TypeError, OverflowError) as recovery_error:
                                report_recovery(
                                    "metod_app.contracts.submission.validate_panel_list.453", recovery_error
                                )
                    row[key] = extensions
        quantity = row.get("qty", row.get("quantity", 1))
        try:
            normalized_quantity = int(quantity)
            if normalized_quantity < 1 or normalized_quantity > 10000:
                raise ValueError
            row["qty"] = normalized_quantity
            row.pop("quantity", None)
        except (ValueError, TypeError, OverflowError) as recovery_error:
            report_recovery("metod_app.contracts.submission.boundary.488", recovery_error)
            errors.append(f"{name} regel {index + 1} heeft een ongeldig aantal.")
        for number_key in ("width", "height", "length", "topExt", "bottomExt"):
            if number_key in row and row[number_key] not in (None, ""):
                try:
                    row[number_key] = finite_number(
                        row[number_key], field=f"{name}.{number_key}", minimum=0, maximum=100000
                    )
                except (OSError, ValueError, TypeError, OverflowError):
                    errors.append(f"{name} regel {index + 1} heeft een ongeldig veld {number_key}.")
        clean_items.append(row)
    clean[name] = clean_items


def validate_submit_payload(payload: Any) -> tuple[bool, list[str], dict]:
    errors: list[str] = []
    clean: dict = {}
    if not isinstance(payload, dict):
        return (False, ["Payload must be a JSON object."], {})
    if any((key not in ALLOWED_SUBMIT_ROOT_KEYS for key in payload)):
        errors.append("Onbekende velden in aanvraagpayload.")
    _validate_submit_identifiers(payload, clean, errors)
    _validate_submit_customer(payload, clean, errors)
    _validate_submit_quote(payload, clean, errors)
    _validate_submit_materials(payload, clean, errors)
    _validate_submit_panel_list(payload, "cart", clean, errors)
    _validate_submit_panel_list(payload, "extraPanels", clean, errors)
    checkout = payload.get("checkout")
    if checkout is not None:
        if not isinstance(checkout, dict):
            errors.append("checkout moet een object zijn.")
        else:
            clean["checkout"] = checkout
    return (len(errors) == 0, errors, clean)


__all__ = (
    "ALLOWED_SUBMIT_ROOT_KEYS",
    "EMAIL_RE",
    "clean_text",
    "normalize_customer_contract",
    "sanitize_house_number_text",
    "sanitize_phone_text",
    "sanitize_postcode_text",
    "sanitize_user_text",
    "validate_submit_payload",
)
