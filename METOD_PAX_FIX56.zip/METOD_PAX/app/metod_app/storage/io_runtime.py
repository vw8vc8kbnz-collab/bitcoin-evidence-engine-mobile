"""Bounded StorageIoRuntime implementation with explicit ports injection."""

from __future__ import annotations

from typing import Any
from typing import Optional
from pathlib import Path
from metod_app.http.wsgi import WsgiHandler
from server_helpers import atomic_write_json as _helpers_atomic_write_json
from server_helpers import atomic_write_text as _helpers_atomic_write_text
from server_helpers import read_json_body as _helpers_read_json_body
from server_helpers import read_json_body_limited as _helpers_read_json_body_limited
from server_helpers import safe_job_file as _helpers_safe_job_file
from datetime import datetime
from safety_contracts import durable_copy_file
from safety_contracts import durable_write_bytes
from safety_contracts import durable_write_text
from safety_contracts import fsync_directory
import os
import secrets
from safety_contracts import strict_json_dumps
import time
from datetime import timezone
from metod_app.runtime.ports import StorageIoRuntimePorts


from metod_app.observability.failures import report_recovery


class StorageIoRuntime:
    def __init__(self, ports: StorageIoRuntimePorts):
        self._ports = ports

    def _now_iso(_owner) -> str:
        return time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime())

    def _safe_json(_owner, data, code=200):
        body = strict_json_dumps(data).encode("utf-8")
        return body, code

    def _read_json_body(_owner, handler: WsgiHandler, max_bytes: Optional[int] = None) -> dict:
        return _helpers_read_json_body(handler, max_bytes=max_bytes)

    def _read_json_body_limited(_owner, handler: WsgiHandler, env_name: str, default_bytes: int) -> dict:
        return _helpers_read_json_body_limited(handler, env_name, default_bytes)

    def _safe_job_file(_owner, job_root: Path, rel: str) -> Optional[Path]:
        return _helpers_safe_job_file(job_root, rel)

    def _write_file(_owner, path: Path, text: str):
        durable_write_text(path, text)

    def _write_bytes(_owner, path: Path, b: bytes):
        durable_write_bytes(path, b)

    def _write_replaceable_bytes(_owner, path: Path, data: bytes) -> None:
        """Atomically publish diagnostic/progress data without a durability barrier."""

        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        tmp = target.parent / f".{target.name}.snapshot.{os.getpid()}.{secrets.token_hex(4)}"
        try:
            tmp.write_bytes(data)
            os.replace(tmp, target)
        finally:
            try:
                tmp.unlink(missing_ok=True)
            except (OSError, ValueError, TypeError, OverflowError) as recovery_error:
                report_recovery("metod_app.storage.io_runtime._write_replaceable_bytes.83", recovery_error)

    def _write_replaceable_text(_owner, path: Path, text: str) -> None:
        ports = _owner._ports

        _write_replaceable_bytes = ports.write_replaceable_bytes

        _write_replaceable_bytes(path, str(text).encode("utf-8"))

    def _write_replaceable_json(_owner, path: Path, value: Any) -> None:
        ports = _owner._ports

        _write_replaceable_text = ports.write_replaceable_text

        _write_replaceable_text(path, strict_json_dumps(value, indent=2) + "\n")

    def _link_or_copy_file(_owner, src: Path, dst: Path) -> str:
        """Create dst without duplicating file bytes when the filesystem supports hardlinks."""

        src = Path(src)
        dst = Path(dst)
        dst.parent.mkdir(parents=True, exist_ok=True)
        try:
            if dst.exists() or dst.is_symlink():
                dst.unlink()
            os.link(src, dst)
            return "hardlink"
        except Exception as recovery_error:
            report_recovery("metod_app.storage.io_runtime.boundary.111", recovery_error)
            durable_copy_file(src, dst)
            return "copy"

    def _atomic_write_text(_owner, path: Path, text: str) -> None:
        _helpers_atomic_write_text(path, text)

    def _atomic_write_json(_owner, path: Path, obj: dict, *, mode: int | None = 0o600) -> None:
        _helpers_atomic_write_json(path, obj, mode=mode)

    def _utc_now_iso(_owner) -> str:
        return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

    def _ensure_request_dirs(_owner) -> None:
        ports = _owner._ports
        BACKUPS_DIR = ports.get_backups_dir()
        INDEX_DIR = ports.get_index_dir()
        QUEUE_DIR = ports.get_queue_dir()
        QUEUE_DONE = ports.get_queue_done()
        QUEUE_FAILED = ports.get_queue_failed()
        QUEUE_PENDING = ports.get_queue_pending()
        QUEUE_PROCESSING = ports.get_queue_processing()
        REQUESTS = ports.get_requests()
        SUBMISSION_IDEMPOTENCY_DIR = ports.get_submission_idempotency_dir()
        SYSTEM_DIR = ports.get_system_dir()

        for d in [
            REQUESTS,
            QUEUE_DIR,
            QUEUE_PENDING,
            QUEUE_PROCESSING,
            QUEUE_DONE,
            QUEUE_FAILED,
            INDEX_DIR,
            SUBMISSION_IDEMPOTENCY_DIR,
            SYSTEM_DIR,
            BACKUPS_DIR,
        ]:
            d.mkdir(parents=True, exist_ok=True)

    def _ensure_archive_dirs(_owner) -> None:
        ports = _owner._ports
        ARCHIVE_JOBS = ports.get_archive_jobs()
        ARCHIVE_QUEUE_DONE = ports.get_archive_queue_done()
        ARCHIVE_QUEUE_FAILED = ports.get_archive_queue_failed()
        ARCHIVE_REQUESTS = ports.get_archive_requests()
        ARCHIVE_ROOT = ports.get_archive_root()
        ARCHIVE_TRANSACTIONS = ports.get_archive_transactions()

        directories = [
            ARCHIVE_ROOT,
            ARCHIVE_JOBS,
            ARCHIVE_REQUESTS,
            ARCHIVE_QUEUE_DONE,
            ARCHIVE_QUEUE_FAILED,
            ARCHIVE_TRANSACTIONS,
        ]
        created_parents: set[Path] = set()
        for d in directories:
            if not d.exists():
                created_parents.add(d.parent)
            d.mkdir(parents=True, exist_ok=True)
        for parent in sorted(created_parents, key=lambda path: len(path.parts), reverse=True):
            if parent.exists():
                fsync_directory(parent)

    EXPORTS = (
        "_now_iso",
        "_safe_json",
        "_read_json_body",
        "_read_json_body_limited",
        "_safe_job_file",
        "_write_file",
        "_write_bytes",
        "_write_replaceable_bytes",
        "_write_replaceable_text",
        "_write_replaceable_json",
        "_link_or_copy_file",
        "_atomic_write_text",
        "_atomic_write_json",
        "_utc_now_iso",
        "_ensure_request_dirs",
        "_ensure_archive_dirs",
    )


__all__ = ("StorageIoRuntime",)
