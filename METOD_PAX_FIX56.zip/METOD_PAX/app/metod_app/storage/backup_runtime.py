"""Bounded BackupRuntime implementation with explicit ports injection."""

from __future__ import annotations

from typing import Any
from pathlib import Path
from metod_app.config import env_int as _env_int
from datetime import datetime
from safety_contracts import durable_copy_file
from safety_contracts import durable_write_json
from safety_contracts import fsync_directory
import hashlib
import hmac
import os
import secrets
import shutil
import stat
from safety_contracts import strict_json_dumps
from safety_contracts import strict_json_load
from safety_contracts import strict_json_loads
import time
from datetime import timedelta
from datetime import timezone
import zipfile
from metod_app.runtime.ports import StorageBackupRuntimePorts

from metod_app.observability.failures import report_recovery

from metod_app.storage.catalog_publication import catalog_guard


class BackupRuntime:
    def __init__(self, ports: StorageBackupRuntimePorts):
        self._ports = ports
        self._catalog_publication = ports.catalog

    def _ensure_system_dirs(_owner) -> None:
        ports = _owner._ports
        BACKUPS_DIR = ports.get_backups_dir()
        CATALOG_IMPORT_HISTORY = ports.get_catalog_import_history()
        CATALOG_IMPORT_ROOT = ports.get_catalog_import_root()
        SYSTEM_DIR = ports.get_system_dir()

        for d in (SYSTEM_DIR, BACKUPS_DIR, CATALOG_IMPORT_ROOT, CATALOG_IMPORT_HISTORY):
            d.mkdir(parents=True, exist_ok=True)

    def _initialize_external_state(_owner) -> None:
        """Bootstrap mutable state once, outside the immutable release tree."""
        ports = _owner._ports
        ARCHIVE_JOBS = ports.get_archive_jobs()
        ARCHIVE_QUEUE_DONE = ports.get_archive_queue_done()
        ARCHIVE_QUEUE_FAILED = ports.get_archive_queue_failed()
        ARCHIVE_REQUESTS = ports.get_archive_requests()
        BACKUPS_DIR = ports.get_backups_dir()
        CONFIG_DIR = ports.get_config_dir()
        DECOR_MEDIA_ROOT = ports.get_decor_media_root()
        DRAFTS = ports.get_drafts()
        DXF_LIBRARY_ROOT = ports.get_dxf_library_root()
        INDEX_DIR = ports.get_index_dir()
        JOBS = ports.get_jobs()
        JOB_CREATE_IDEMPOTENCY_DIR = ports.get_job_create_idempotency_dir()
        MATERIAL_LIBRARY_PATH = ports.get_material_library_path()
        MATERIAL_LIBRARY_SEED_PATH = ports.get_material_library_seed_path()
        QUEUE_DONE = ports.get_queue_done()
        QUEUE_FAILED = ports.get_queue_failed()
        QUEUE_PENDING = ports.get_queue_pending()
        QUEUE_PROCESSING = ports.get_queue_processing()
        REQUESTS = ports.get_requests()
        ROOT = ports.get_root()
        STATE_ROOT = ports.get_state_root()
        CLIENT_LOG_ROOT = STATE_ROOT / "client_logs"
        SUBMISSION_IDEMPOTENCY_DIR = ports.get_submission_idempotency_dir()
        SYSTEM_DIR = ports.get_system_dir()

        STATE_ROOT.mkdir(parents=True, exist_ok=True)
        if os.name != "nt":
            os.chmod(STATE_ROOT, 0o750)
        directories = (
            JOBS,
            DRAFTS,
            INDEX_DIR,
            REQUESTS,
            QUEUE_PENDING,
            QUEUE_PROCESSING,
            QUEUE_DONE,
            QUEUE_FAILED,
            SUBMISSION_IDEMPOTENCY_DIR,
            ARCHIVE_JOBS,
            ARCHIVE_REQUESTS,
            ARCHIVE_QUEUE_DONE,
            ARCHIVE_QUEUE_FAILED,
            SYSTEM_DIR,
            JOB_CREATE_IDEMPOTENCY_DIR,
            BACKUPS_DIR,
            DECOR_MEDIA_ROOT,
            CONFIG_DIR,
            CLIENT_LOG_ROOT,
        )
        for directory in directories:
            directory.mkdir(parents=True, exist_ok=True)
        if os.name != "nt":
            # Customer payloads, cancellation/access tokens and archived requests
            # are service-private. Public catalog/media/config owners retain the
            # group-readable state-root contract.
            for directory in (
                JOBS,
                DRAFTS,
                REQUESTS,
                QUEUE_PENDING,
                QUEUE_PROCESSING,
                QUEUE_DONE,
                QUEUE_FAILED,
                SUBMISSION_IDEMPOTENCY_DIR,
                JOB_CREATE_IDEMPOTENCY_DIR,
                ARCHIVE_JOBS,
                ARCHIVE_REQUESTS,
                ARCHIVE_QUEUE_DONE,
                ARCHIVE_QUEUE_FAILED,
                CLIENT_LOG_ROOT,
            ):
                os.chmod(directory, 0o700)

        # Repair an interrupted publication before normalization or any server work.
        with catalog_guard(ports.catalog):
            pass

        if not MATERIAL_LIBRARY_PATH.exists() and MATERIAL_LIBRARY_SEED_PATH.is_file():
            durable_copy_file(MATERIAL_LIBRARY_SEED_PATH, MATERIAL_LIBRARY_PATH, mode=0o640)

        if not DXF_LIBRARY_ROOT.exists():
            source_root = ROOT / "embedded_dxfs"
            if not source_root.is_dir():
                raise RuntimeError("Immutable embedded DXF seed is missing")
            staging = STATE_ROOT / f".embedded_dxfs.bootstrap.{os.getpid()}.{secrets.token_hex(6)}"
            try:
                staging.mkdir(parents=True, exist_ok=False)
                for source in sorted(source_root.rglob("*")):
                    relative = source.relative_to(source_root)
                    destination = staging / relative
                    if source.is_dir():
                        destination.mkdir(parents=True, exist_ok=True)
                    elif source.is_file():
                        durable_copy_file(source, destination, mode=0o640)
                os.replace(staging, DXF_LIBRARY_ROOT)
                fsync_directory(STATE_ROOT)
            finally:
                if staging.exists():
                    shutil.rmtree(staging, ignore_errors=True)

    def _cleanup_old_backups(_owner, *, protected: set[Path] | None = None) -> dict:
        """Enforce age, count and aggregate-byte limits for every local backup."""
        ports = _owner._ports
        AUTO_BACKUP_KEEP = ports.get_auto_backup_keep()
        BACKUPS_DIR = ports.get_backups_dir()
        MANUAL_BACKUP_KEEP = ports.get_manual_backup_keep()

        _ensure_system_dirs = ports.ensure_system_dirs

        _ensure_system_dirs()
        protected_paths = {Path(path).resolve() for path in (protected or set())}
        now = time.time()
        result = {"removed": 0, "staleTemps": 0, "remainingBytes": 0, "errors": []}
        changed = False
        temp_hours = max(1, _env_int("BACKUP_TEMP_RETENTION_HOURS", 24))
        for temp in sorted(BACKUPS_DIR.glob(".system_backup_*.tmp")):
            try:
                if now - temp.stat().st_mtime >= temp_hours * 3600:
                    temp.unlink(missing_ok=True)
                    result["staleTemps"] += 1
                    changed = True
            except (OSError, ValueError, TypeError, OverflowError) as exc:
                result["errors"].append(f"{temp.name}: {exc}")

        auto_files: list[Path] = []
        manual_files: list[Path] = []
        for path in BACKUPS_DIR.glob("*.zip"):
            name = path.name.lower()
            if name.startswith("system_backup_auto_"):
                auto_files.append(path)
            elif name.startswith("system_backup_manual_") or name.startswith("system_backup_"):
                manual_files.append(path)
        auto_files.sort(key=lambda path: path.stat().st_mtime, reverse=True)
        manual_files.sort(key=lambda path: path.stat().st_mtime, reverse=True)
        keep_auto = max(1, min(1000, _env_int("AUTO_BACKUP_KEEP", AUTO_BACKUP_KEEP)))
        keep_manual = max(1, min(1000, _env_int("MANUAL_BACKUP_KEEP", MANUAL_BACKUP_KEEP)))
        auto_age = max(1, _env_int("AUTO_BACKUP_MAX_AGE_DAYS", 70))
        manual_age = max(1, _env_int("MANUAL_BACKUP_MAX_AGE_DAYS", 120))
        remove: set[Path] = set()
        for index, path in enumerate(auto_files):
            try:
                if path.resolve() not in protected_paths and (
                    index >= keep_auto or now - path.stat().st_mtime >= auto_age * 86400
                ):
                    remove.add(path)
            except Exception as exc:
                report_recovery("metod_app.storage.backup_runtime.boundary.171", exc)
                result["errors"].append(f"{path.name}: {exc}")
        for index, path in enumerate(manual_files):
            try:
                if path.resolve() not in protected_paths and (
                    index >= keep_manual or now - path.stat().st_mtime >= manual_age * 86400
                ):
                    remove.add(path)
            except Exception as exc:
                report_recovery("metod_app.storage.backup_runtime.boundary.177", exc)
                result["errors"].append(f"{path.name}: {exc}")

        def unlink_backup(path: Path) -> bool:
            nonlocal changed
            try:
                path.unlink(missing_ok=True)
                result["removed"] += 1
                changed = True
                return True
            except (OSError, ValueError, TypeError, OverflowError) as exc:
                result["errors"].append(f"{path.name}: {exc}")
                return False

        for path in sorted(remove, key=lambda item: item.stat().st_mtime):
            unlink_backup(path)

        total_cap = max(64 * 1024 * 1024, _env_int("BACKUP_TOTAL_MAX_BYTES", 20 * 1024 * 1024 * 1024))
        remaining = sorted(
            [path for path in auto_files + manual_files if path.exists()],
            key=lambda path: path.stat().st_mtime,
        )
        total = sum(path.stat().st_size for path in remaining)
        while remaining and total > total_cap:
            oldest = remaining.pop(0)
            if oldest.resolve() in protected_paths:
                remaining.append(oldest)
                if all(path.resolve() in protected_paths for path in remaining):
                    break
                continue
            size = oldest.stat().st_size
            if unlink_backup(oldest):
                total = max(0, total - size)
        # Recount the actual files. A failed unlink never releases capacity.
        total = sum(path.stat().st_size for path in BACKUPS_DIR.glob("*.zip") if path.is_file())
        result["remainingBytes"] = total
        result["limitBytes"] = total_cap
        result["overLimit"] = total > total_cap
        result["ok"] = not result["errors"] and not result["overLimit"]
        if changed:
            fsync_directory(BACKUPS_DIR)
        return result

    def _backup_source_inventory(_owner) -> tuple[list[tuple[Path, str]], int]:
        ports = _owner._ports

        ROOT = ports.get_root()
        STATE_ROOT = ports.get_state_root()

        sources: list[tuple[Path, str]] = []
        total_bytes = 0
        for child in sorted(STATE_ROOT.rglob("*")):
            if child.is_symlink():
                raise RuntimeError(f"Symlink is forbidden in backup source: {child.relative_to(STATE_ROOT)}")
            if not child.is_file():
                continue
            relative = child.relative_to(STATE_ROOT)
            if not relative.parts or relative.parts[0] == "backups":
                continue
            if relative.parts[:2] == ("system", "exports"):
                continue
            sources.append((child, f"state/{relative.as_posix()}"))
            total_bytes += child.stat().st_size
        for source in (ROOT / "pricing_v13mm.json", ROOT / "server_py.py"):
            if source.is_file():
                sources.append((source, f"release/{source.name}"))
                total_bytes += source.stat().st_size
        return sources, total_bytes

    def _assert_backup_capacity(_owner, source_bytes: int, file_count: int) -> None:
        ports = _owner._ports
        BACKUPS_DIR = ports.get_backups_dir()

        max_source_bytes = max(1, _env_int("BACKUP_MAX_SOURCE_BYTES", 16 * 1024 * 1024 * 1024))
        max_files = max(1, _env_int("BACKUP_MAX_FILES", 200_000))
        if source_bytes > max_source_bytes:
            raise RuntimeError("Backup source exceeds BACKUP_MAX_SOURCE_BYTES")
        if file_count > max_files:
            raise RuntimeError("Backup source exceeds BACKUP_MAX_FILES")
        total_cap = max(64 * 1024 * 1024, _env_int("BACKUP_TOTAL_MAX_BYTES", 20 * 1024 * 1024 * 1024))
        # ZIP_DEFLATED can expand already-compressed data slightly. Reserve source
        # size plus 10% and a small fixed margin before creating the temporary file.
        projected_temp = source_bytes + max(16 * 1024 * 1024, source_bytes // 10)
        if projected_temp > total_cap:
            raise RuntimeError("Projected backup exceeds BACKUP_TOTAL_MAX_BYTES")
        min_free = max(
            64 * 1024 * 1024,
            _env_int("BACKUP_MIN_FREE_BYTES", _env_int("MIN_FREE_STATE_BYTES", 1024 * 1024 * 1024)),
        )
        free_bytes = shutil.disk_usage(BACKUPS_DIR).free
        if free_bytes < min_free + projected_temp:
            raise RuntimeError("Insufficient free disk space for an atomic backup")
        if hasattr(os, "statvfs"):
            min_inodes = max(
                100, _env_int("BACKUP_MIN_FREE_INODES", _env_int("MIN_FREE_STATE_INODES", 10_000))
            )
            if int(os.statvfs(BACKUPS_DIR).f_favail) < min_inodes + 2:
                raise RuntimeError("Insufficient free inodes for an atomic backup")

    def _verify_system_backup_zip(_owner, path: Path, manifest: dict) -> None:
        with zipfile.ZipFile(path, "r") as check:
            if check.testzip() is not None:
                raise RuntimeError("Backup ZIP verification failed")
            stored = strict_json_loads(check.read("BACKUP_MANIFEST.json"))
            if stored.get("files") != manifest["files"]:
                raise RuntimeError("Backup manifest verification failed")
            for archive_name, evidence in manifest["files"].items():
                digest = hashlib.sha256()
                size = 0
                with check.open(archive_name, "r") as source:
                    for chunk in iter(lambda: source.read(1024 * 1024), b""):
                        digest.update(chunk)
                        size += len(chunk)
                if size != int(evidence["size"]) or not hmac.compare_digest(
                    digest.hexdigest(), str(evidence["sha256"])
                ):
                    raise RuntimeError(f"Backup content verification failed: {archive_name}")

    def _write_last_auto_backup(_owner, dt: datetime, file_name: str) -> None:
        ports = _owner._ports
        LAST_AUTO_BACKUP_FILE = ports.get_last_auto_backup_file()
        _ensure_system_dirs = ports.ensure_system_dirs

        _ensure_system_dirs()
        durable_write_json(
            LAST_AUTO_BACKUP_FILE,
            {
                "ts": dt.isoformat(),
                "file": file_name,
            },
        )

    def _read_last_auto_backup_dt(_owner) -> datetime | None:
        ports = _owner._ports
        BACKUPS_DIR = ports.get_backups_dir()
        LAST_AUTO_BACKUP_FILE = ports.get_last_auto_backup_file()

        try:
            if LAST_AUTO_BACKUP_FILE.exists():
                data = strict_json_load(LAST_AUTO_BACKUP_FILE)
                ts = str((data or {}).get("ts") or "").strip()
                if ts:
                    return datetime.fromisoformat(ts)
        except (OSError, ValueError, TypeError, OverflowError) as recovery_error:
            report_recovery("metod_app.storage.backup_runtime._read_last_auto_backup_dt.312", recovery_error)
        auto_files = sorted(
            BACKUPS_DIR.glob("system_backup_auto_*.zip"), key=lambda p: p.stat().st_mtime, reverse=True
        )
        if auto_files:
            return datetime.fromtimestamp(auto_files[0].stat().st_mtime)
        return None

    def run_backup_maintenance(_owner, force: bool = False) -> dict:
        ports = _owner._ports
        AUTO_BACKUP_INTERVAL_DAYS = ports.get_auto_backup_interval_days()
        BACKUPS_DIR = ports.get_backups_dir()
        _append_system_event = ports.append_system_event
        _cleanup_old_backups = ports.cleanup_old_backups
        _create_system_backup = ports.create_system_backup
        _ensure_system_dirs = ports.ensure_system_dirs
        _read_last_auto_backup_dt = ports.read_last_auto_backup_dt
        _write_last_auto_backup = ports.write_last_auto_backup

        try:
            _ensure_system_dirs()
            existing_backups = sorted(
                [path for path in BACKUPS_DIR.glob("*.zip") if path.is_file()],
                key=lambda path: path.stat().st_mtime,
                reverse=True,
            )
            retention = _cleanup_old_backups(protected={existing_backups[0]} if existing_backups else set())
            if not retention["ok"]:
                raise RuntimeError(
                    "Backupopruiming is niet voltooid; controleer vrije ruimte en bestandsrechten."
                )
            last_dt = _read_last_auto_backup_dt()
            now = datetime.now()
            if (not force) and last_dt and (now - last_dt) < timedelta(days=AUTO_BACKUP_INTERVAL_DAYS):
                return {
                    "ok": True,
                    "created": False,
                    "reason": "recent_auto_backup_exists",
                    "last": last_dt.isoformat(),
                }
            res = _create_system_backup(actor="system", backup_kind="auto")
            _write_last_auto_backup(now, str(res.get("file") or ""))
            return {"ok": True, "created": True, "backup": res}
        except Exception as e:
            report_recovery("metod_app.storage.backup_runtime.boundary.357", e)
            _append_system_event(
                level="error",
                component="backup",
                message_user="Automatische backup is mislukt",
                message_tech=str(e),
                status="open",
            )
            return {"ok": False, "error": str(e)}

    def _create_system_backup(_owner, actor: str = "admin", backup_kind: str = "manual") -> dict:
        ports = _owner._ports

        BACKUPS_DIR = ports.get_backups_dir()

        SECURITY_BUILD = ports.get_security_build()
        STATE_ROOT = ports.get_state_root()
        _STATE_SNAPSHOT_LOCK = ports.get_state_snapshot_lock()
        _append_system_event = ports.append_system_event
        _assert_backup_capacity = ports.assert_backup_capacity
        _backup_source_inventory = ports.backup_source_inventory
        _begin_consistent_snapshot = ports.begin_consistent_snapshot
        _cleanup_old_backups = ports.cleanup_old_backups
        _end_consistent_snapshot = ports.end_consistent_snapshot
        _ensure_system_dirs = ports.ensure_system_dirs

        _exclusive_state_maintenance = ports.exclusive_state_maintenance
        _now_iso = ports.now_iso
        _verify_system_backup_zip = ports.verify_system_backup_zip

        _ensure_system_dirs()
        ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S_%f") + "_" + secrets.token_hex(3)
        prefix = "system_backup_auto" if str(backup_kind).lower() == "auto" else "system_backup_manual"
        out = BACKUPS_DIR / f"{prefix}_{ts}.zip"
        temp = BACKUPS_DIR / f".{out.name}.{secrets.token_hex(8)}.tmp"
        manifest: dict[str, Any] = {
            "schemaVersion": 2,
            "createdAt": _now_iso(),
            "actor": str(actor or "unknown"),
            "kind": str(backup_kind),
            "releaseBuild": SECURITY_BUILD,
            "stateRoot": str(STATE_ROOT),
            "files": {},
        }
        max_source_bytes = max(1, _env_int("BACKUP_MAX_SOURCE_BYTES", 16 * 1024 * 1024 * 1024))
        max_files = max(1, _env_int("BACKUP_MAX_FILES", 200_000))
        source_bytes = 0
        file_count = 0
        with _exclusive_state_maintenance():
            snapshot_started = False
            try:
                existing = sorted(
                    BACKUPS_DIR.glob("system_backup_*.zip"),
                    key=lambda path: path.stat().st_mtime,
                    reverse=True,
                )
                retention = _cleanup_old_backups(protected={existing[0]} if existing else set())
                if not retention["ok"]:
                    raise RuntimeError(
                        "Backupopruiming is niet voltooid; er wordt geen nieuwe backup toegevoegd."
                    )
                _begin_consistent_snapshot(timeout_seconds=max(10, _env_int("BACKUP_DRAIN_TIMEOUT_SEC", 60)))
                snapshot_started = True
                with _STATE_SNAPSHOT_LOCK:
                    source_inventory, inventory_bytes = _backup_source_inventory()
                    _assert_backup_capacity(inventory_bytes, len(source_inventory))
                    with zipfile.ZipFile(temp, "w", compression=zipfile.ZIP_DEFLATED, allowZip64=True) as zf:

                        def add_file(source: Path, archive_name: str) -> None:
                            nonlocal source_bytes, file_count
                            flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
                            fd = os.open(str(source), flags)
                            try:
                                file_stat = os.fstat(fd)
                                if not stat.S_ISREG(file_stat.st_mode):
                                    raise RuntimeError(f"Backup source is not a regular file: {source}")
                                file_count += 1
                                if file_count > max_files:
                                    raise RuntimeError("Backup source exceeds BACKUP_MAX_FILES")
                                digest = hashlib.sha256()
                                copied = 0
                                with (
                                    os.fdopen(fd, "rb", closefd=False) as input_handle,
                                    zf.open(archive_name, "w", force_zip64=True) as output_handle,
                                ):
                                    while True:
                                        chunk = input_handle.read(1024 * 1024)
                                        if not chunk:
                                            break
                                        copied += len(chunk)
                                        source_bytes += len(chunk)
                                        if source_bytes > max_source_bytes:
                                            raise RuntimeError(
                                                "Backup source exceeds BACKUP_MAX_SOURCE_BYTES"
                                            )
                                        digest.update(chunk)
                                        output_handle.write(chunk)
                                manifest["files"][archive_name] = {
                                    "sha256": digest.hexdigest(),
                                    "size": copied,
                                }
                            finally:
                                os.close(fd)

                        for source, archive_name in source_inventory:
                            add_file(source, archive_name)
                        zf.writestr("BACKUP_MANIFEST.json", strict_json_dumps(manifest, indent=2) + "\n")
                    with open(temp, "rb") as backup_handle:
                        os.fsync(backup_handle.fileno())
                    if os.name != "nt":
                        os.chmod(temp, 0o600)
                    # Verify the private temporary archive in full before the single
                    # atomic publish rename. A corrupt/incomplete ZIP is never listed.
                    _verify_system_backup_zip(temp, manifest)
                    os.replace(temp, out)
                    fsync_directory(BACKUPS_DIR)
            finally:
                try:
                    temp.unlink(missing_ok=True)
                finally:
                    if snapshot_started:
                        _end_consistent_snapshot()
        # The previous recovery point remained untouched until the private temp ZIP
        # passed full verification and this new archive was atomically published.
        retention = _cleanup_old_backups(protected={out})
        if not retention["ok"]:
            _append_system_event(
                level="error",
                component="backup",
                message_user="Backup gemaakt, maar opruiming vereist aandacht",
                message_tech="Backup retention incomplete",
                status="open",
                details={
                    "remainingBytes": retention["remainingBytes"],
                    "limitBytes": retention["limitBytes"],
                },
            )
        msg = (
            "Automatische backup voltooid"
            if str(backup_kind).lower() == "auto"
            else "Handmatige backup voltooid"
        )
        if retention["ok"]:
            _append_system_event(
                level="info",
                component="backup",
                message_user=msg,
                message_tech=f"Created {out.name}",
                status="resolved",
                details={"actor": actor, "file": out.name, "kind": backup_kind},
            )
        st = out.stat()
        return {
            "ok": True,
            "file": out.name,
            "path": str(out),
            "size": st.st_size,
            "modified": datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M:%S"),
            "kind": backup_kind,
            "retention": retention,
        }

    def _list_backups(_owner, limit: int = 50) -> list[dict]:
        ports = _owner._ports
        BACKUPS_DIR = ports.get_backups_dir()
        _ensure_system_dirs = ports.ensure_system_dirs

        _ensure_system_dirs()
        items = []
        for fp in sorted(BACKUPS_DIR.glob("*.zip"), key=lambda p: p.stat().st_mtime, reverse=True)[:limit]:
            st = fp.stat()
            nm = fp.name.lower()
            kind = "auto" if nm.startswith("system_backup_auto_") else "manual"
            items.append(
                {
                    "name": fp.name,
                    "size": st.st_size,
                    "modified": datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M:%S"),
                    "kind": kind,
                }
            )
        return items

    EXPORTS = (
        "_ensure_system_dirs",
        "_initialize_external_state",
        "_cleanup_old_backups",
        "_backup_source_inventory",
        "_assert_backup_capacity",
        "_verify_system_backup_zip",
        "_write_last_auto_backup",
        "_read_last_auto_backup_dt",
        "run_backup_maintenance",
        "_create_system_backup",
        "_list_backups",
    )


__all__ = ("BackupRuntime",)
