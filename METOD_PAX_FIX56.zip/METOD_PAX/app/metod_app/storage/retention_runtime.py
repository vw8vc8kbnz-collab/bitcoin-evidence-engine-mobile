"""Bounded RetentionRuntime implementation with explicit ports injection."""

from __future__ import annotations

from .operational_cleanup import OperationalCleanup

from metod_app.observability.failures import report_recovery

from typing import Optional
from pathlib import Path
from metod_app.security.redaction import redact_sensitive_text as _redact_sensitive_text
from datetime import datetime
from safety_contracts import fsync_directory
import os
import shutil
import time
from datetime import timedelta
from datetime import timezone
from metod_app.runtime.ports import StorageRetentionRuntimePorts


class RetentionRuntime:
    def __init__(self, ports: StorageRetentionRuntimePorts):
        self._ports = ports

    def _purge_old_archives(_owner, now_dt: Optional[datetime] = None) -> dict:
        ports = _owner._ports
        ARCHIVE_JOBS = ports.get_archive_jobs()
        ARCHIVE_QUEUE_DONE = ports.get_archive_queue_done()
        ARCHIVE_QUEUE_FAILED = ports.get_archive_queue_failed()
        ARCHIVE_REQUESTS = ports.get_archive_requests()

        RETENTION_ARCHIVE_DAYS = ports.get_retention_archive_days()
        _ensure_archive_dirs = ports.ensure_archive_dirs
        _path_dt = ports.path_dt
        _request_archive_meta_dt = ports.request_archive_meta_dt

        _ensure_archive_dirs()
        now_dt = now_dt or datetime.now(timezone.utc).replace(tzinfo=None)
        purged = {"requests": 0, "jobs": 0, "queue_done": 0, "queue_failed": 0, "errors": []}

        def _purge_dir(base: Path, key: str):
            if not base.exists():
                return
            for child in sorted(base.iterdir()):
                if not child.exists():
                    continue
                dt = _request_archive_meta_dt(child) if child.is_dir() else _path_dt(child)
                if dt is None:
                    continue
                if now_dt - dt < timedelta(days=RETENTION_ARCHIVE_DAYS):
                    continue
                try:
                    if child.is_dir():
                        shutil.rmtree(child, ignore_errors=False)
                    else:
                        child.unlink(missing_ok=True)
                    fsync_directory(base)
                    purged[key] += 1
                except Exception as exc:
                    report_recovery("metod_app.storage.retention_runtime.boundary.61", exc)
                    purged["errors"].append({"path": str(child), "error": str(exc)})

        _purge_dir(ARCHIVE_REQUESTS, "requests")
        _purge_dir(ARCHIVE_JOBS, "jobs")
        _purge_dir(ARCHIVE_QUEUE_DONE, "queue_done")
        _purge_dir(ARCHIVE_QUEUE_FAILED, "queue_failed")
        return purged

    def _request_is_terminal_for_retention(_owner, status: dict | None) -> bool:
        if not isinstance(status, dict):
            return False
        public_status = str(status.get("publicStatus") or "").strip().upper()
        internal_status = str(status.get("internalStatus") or "").strip().upper()
        quote_status = str(status.get("quoteStatus") or "").strip().upper()
        return bool(
            public_status in {"DONE", "AFGEHANDELD", "CANCELLED"}
            or internal_status in {"FAILED", "CANCELLED"}
            or (internal_status == "DONE" and quote_status in {"DONE", "CANCELLED"})
        )

    def _archive_expired_active_data(_owner, now_dt: Optional[datetime] = None) -> dict:
        ports = _owner._ports
        JOBS = ports.get_jobs()
        ORPHAN_JOB_RETENTION_DAYS = ports.get_orphan_job_retention_days()

        REQUESTS = ports.get_requests()
        RETENTION_ACTIVE_DAYS = ports.get_retention_active_days()
        RETENTION_OPEN_REQUEST_MAX_DAYS = ports.get_retention_open_request_max_days()
        _append_system_event = ports.append_system_event
        _archive_request_and_linked_jobs = ports.archive_request_and_linked_jobs
        _ensure_archive_dirs = ports.ensure_archive_dirs
        _ensure_request_dirs = ports.ensure_request_dirs
        _find_request_status_for_job = ports.find_request_status_for_job
        _job_created_dt = ports.job_created_dt
        _linked_job_ids_from_status = ports.linked_job_ids_from_status
        _load_status = ports.load_status
        _request_created_dt_from_status = ports.request_created_dt_from_status
        _request_is_terminal_for_retention = ports.request_is_terminal_for_retention

        _ensure_request_dirs()
        _ensure_archive_dirs()
        now_dt = now_dt or datetime.now(timezone.utc).replace(tzinfo=None)
        archived = {"requests": 0, "orphanJobsDeleted": 0, "errors": []}
        processed_job_ids = set()

        # First archive submitted requests as the leading contract; this pulls linked parent/subjobs with it.
        for req_dir in sorted(REQUESTS.iterdir()):
            if not req_dir.is_dir():
                continue
            rid = req_dir.name
            st = _load_status(rid) or {}
            created_dt = _request_created_dt_from_status(st, req_dir)
            if created_dt is None:
                continue
            age = now_dt - created_dt
            terminal = _request_is_terminal_for_retention(st)
            retention_reason = "terminal-age" if terminal else "open-hard-limit"
            retention_days = RETENTION_ACTIVE_DAYS if terminal else RETENTION_OPEN_REQUEST_MAX_DAYS
            if age < timedelta(days=retention_days):
                continue
            for jid in _linked_job_ids_from_status(st):
                processed_job_ids.add(jid)
            res = _archive_request_and_linked_jobs(rid, retention_reason=retention_reason)
            if res.get("ok"):
                archived["requests"] += 1
                for jid in res.get("movedJobs") or []:
                    processed_job_ids.add(str(jid))
                for queue_error in res.get("queueMirrorErrors") or []:
                    archived["errors"].append({"requestId": rid, "error": str(queue_error)})
                for commit_warning in res.get("commitWarnings") or []:
                    archived["errors"].append({"requestId": rid, "error": str(commit_warning)})
                if retention_reason == "open-hard-limit" or res.get("degradedArchive"):
                    _append_system_event(
                        level="warning",
                        component="retention",
                        message_user="Een aanvraag is met bewaarschuwing gearchiveerd",
                        message_tech=(
                            f"request={rid}; reason={retention_reason}; "
                            f"missingJobs={res.get('missingJobs') or []}"
                        ),
                        request_id=rid,
                        status="open",
                    )
            else:
                archived["errors"].append({"requestId": rid, "error": res.get("error") or "archive failed"})

        # Then delete orphan jobs with no request mapping after a much shorter retention window.
        for job_dir in sorted(JOBS.iterdir()):
            if not job_dir.is_dir():
                continue
            jid = job_dir.name
            if jid in processed_job_ids:
                continue
            if _find_request_status_for_job(jid):
                continue
            created_dt = _job_created_dt(job_dir)
            if created_dt is None or (now_dt - created_dt) < timedelta(days=ORPHAN_JOB_RETENTION_DAYS):
                continue
            try:
                shutil.rmtree(job_dir, ignore_errors=False)
                fsync_directory(JOBS)
                archived["orphanJobsDeleted"] += 1
            except Exception as e:
                report_recovery("metod_app.storage.retention_runtime.boundary.165", e)
                archived["errors"].append({"jobId": jid, "error": str(e)})
        return archived

    def _cleanup_operational_state(_owner, now_dt: Optional[datetime] = None) -> dict:
        """Apply the bounded retention pass without deleting active catalog/order records."""
        return OperationalCleanup(_owner._ports, now_dt).run()

    def _move_queue_file_safe(_owner, src: Path, dest_dir: Path) -> Path:
        source_parent = Path(src).parent
        dest_dir.mkdir(parents=True, exist_ok=True)
        dest = dest_dir / src.name
        if dest.exists():
            stamp = time.strftime("%Y%m%d_%H%M%S")
            dest = dest_dir / f"{src.stem}__{stamp}{src.suffix}"
        os.replace(str(src), str(dest))
        fsync_directory(dest_dir)
        if source_parent.resolve() != dest_dir.resolve():
            fsync_directory(source_parent)
        return dest

    def _mark_request_failed_if_stale(_owner, request_id: str, *, code: str, message: str) -> None:
        ports = _owner._ports
        _load_status = ports.load_status
        _save_status = ports.save_status

        status = _load_status(request_id) or {}
        if status.get("internalStatus") in {"DONE", "FAILED", "CANCELLED"}:
            return
        status["internalStatus"] = "FAILED"
        status["internalStatusLabel"] = "Fout"
        status["error"] = {"code": code, "message": message}
        _save_status(request_id, status)

    def _record_maintenance_failure(_owner, component: str, user_message: str, failure: object) -> None:
        ports = _owner._ports
        _append_system_event = ports.append_system_event

        if isinstance(failure, BaseException):
            detail = f"{type(failure).__name__}: {failure}"
        elif isinstance(failure, dict):
            detail = str(failure.get("errors") or failure.get("error") or failure)
        else:
            detail = str(failure)
        _append_system_event(
            level="error",
            component=component,
            message_user=user_message,
            message_tech=_redact_sensitive_text(detail, 1200),
            status="open",
        )

    def _server_maintenance_loop(_owner, interval_seconds: float = 15 * 60) -> None:
        ports = _owner._ports
        _SERVER_MAINTENANCE_LOOP_SECONDS = ports.get_server_maintenance_loop_seconds()
        _record_maintenance_failure = ports.record_maintenance_failure
        run_backup_maintenance = ports.run_backup_maintenance
        run_queue_maintenance = ports.run_queue_maintenance
        run_retention_maintenance = ports.run_retention_maintenance

        while True:
            try:
                retention = run_retention_maintenance(force=False)
                if not retention.get("ok", False):
                    _record_maintenance_failure(
                        "retention", "Automatisch retentieonderhoud is niet volledig uitgevoerd", retention
                    )
            except Exception as exc:
                report_recovery("metod_app.storage.retention_runtime.boundary.478", exc)
                _record_maintenance_failure("retention", "Automatisch retentieonderhoud is gecrasht", exc)
            try:
                run_backup_maintenance(force=False)
            except Exception as exc:
                report_recovery("metod_app.storage.retention_runtime.boundary.482", exc)
                _record_maintenance_failure("backup", "Automatisch backuponderhoud is gecrasht", exc)
            try:
                queue_result = run_queue_maintenance(force=False)
                if not queue_result.get("ok", False):
                    _record_maintenance_failure(
                        "jobs", "Automatisch queue-onderhoud is niet volledig uitgevoerd", queue_result
                    )
            except Exception as exc:
                report_recovery("metod_app.storage.retention_runtime.boundary.488", exc)
                _record_maintenance_failure("jobs", "Automatisch queue-onderhoud is gecrasht", exc)
            time.sleep(interval_seconds)

    EXPORTS = (
        "_purge_old_archives",
        "_request_is_terminal_for_retention",
        "_archive_expired_active_data",
        "_cleanup_operational_state",
        "_move_queue_file_safe",
        "_mark_request_failed_if_stale",
        "_record_maintenance_failure",
        "_server_maintenance_loop",
    )


__all__ = ("RetentionRuntime",)
