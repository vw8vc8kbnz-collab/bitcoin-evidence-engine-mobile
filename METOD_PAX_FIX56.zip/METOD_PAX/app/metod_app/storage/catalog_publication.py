"""Recoverable catalog publication, using the existing global pricing lock.

The journal is durable before the first mutation. Readers share the lock and
startup restores an interrupted transaction before serving any catalog data.
The commit marker is written only after library, media, registries, approval
and import history have all been durably written.
"""

from __future__ import annotations

from metod_app.runtime.ports import StorageCatalogPublicationPorts

from contextlib import contextmanager
from contextvars import ContextVar
from functools import wraps
import hashlib
import os
from pathlib import Path
import re
import shutil
import stat

from safety_contracts import (
    PUBLIC_MATERIAL_ID_RE,
    durable_copy_file,
    durable_write_json,
    fsync_directory,
    strict_json_load,
)

_guarded_runtimes = ContextVar("catalog_guarded_runtimes", default=())
MEDIA_NAMES = ("catalog.img", "catalog.meta.json", "thumb.webp", "preview.webp")


def signoff_path(ports: StorageCatalogPublicationPorts) -> Path:
    configured = os.environ.get("CATALOG_SIGNOFF_FILE")
    return Path(configured or ports.get_system_dir() / "catalog_signoff.json").expanduser()


def _checked_target(ports: StorageCatalogPublicationPorts, target: Path) -> Path:
    target = target.absolute()
    fixed = {
        Path(p).absolute()
        for p in (
            ports.get_material_library_path(),
            ports.get_catalog_taxonomy_registry(),
            ports.get_catalog_public_id_registry(),
            signoff_path(ports),
        )
    }
    media = (
        target.parent.parent == ports.get_decor_media_root().absolute()
        and PUBLIC_MATERIAL_ID_RE.fullmatch(target.parent.name)
        and target.name in MEDIA_NAMES
    )
    stage = target.parent == ports.get_catalog_import_root().absolute() and re.fullmatch(
        r"cat_[a-f0-9]{24}\.json", target.name
    )
    if target not in fixed and not media and not stage:
        raise RuntimeError("Unexpected catalog transaction target")
    if any(path.is_symlink() for path in (target, *target.parents)):
        raise RuntimeError("Catalog transaction paths must not be symlinks")
    if target.exists() and not target.is_file():
        raise RuntimeError("Catalog transaction target is not a regular file")
    return target


def _invalidate(ports: StorageCatalogPublicationPorts) -> None:
    ports.invalidate_material_lookup_cache()
    ports.invalidate_public_materials_response_cache()
    ports.invalidate_material_name_cache()


def recover_catalog_publication(ports: StorageCatalogPublicationPorts) -> None:
    """Called while holding the pricing lock, before any catalog reader/writer."""
    folder = ports.get_system_dir() / "catalog_transaction"
    journal = folder / "journal.json"
    if not folder.exists():
        return
    if folder.is_symlink() or journal.is_symlink():
        raise RuntimeError("Unsafe catalog transaction journal")
    if journal.exists():
        value = strict_json_load(journal)
        if value.get("schemaVersion") != 1 or value.get("state") not in {"PREPARED", "COMMITTED"}:
            raise RuntimeError("Invalid catalog transaction journal; catalog stays unavailable")
        entries = value.get("entries")
        if not isinstance(entries, list):
            raise RuntimeError("Invalid catalog transaction entries")
        # Verify every backup first; never perform a partial repair from corrupt evidence.
        checked = []
        for index, entry in enumerate(entries):
            target = _checked_target(ports, Path(entry["target"]))
            backup = folder / f"{index}.backup" if entry["existed"] else None
            if backup is not None:
                if (
                    backup.is_symlink()
                    or not backup.is_file()
                    or hashlib.sha256(backup.read_bytes()).hexdigest() != entry["sha256"]
                ):
                    raise RuntimeError("Catalog rollback backup is missing or corrupt")
            checked.append((target, backup, int(entry["mode"])))
        if value["state"] == "PREPARED":
            for target, backup, mode in checked:
                if backup is None:
                    target.unlink(missing_ok=True)
                    if target.parent.exists():
                        fsync_directory(target.parent)
                else:
                    durable_copy_file(backup, target, mode=mode)
        _invalidate(ports)
        # Once this marker is removed, a second recovery must not undo newer data.
        journal.unlink()
        fsync_directory(folder)
    shutil.rmtree(folder)
    fsync_directory(folder.parent)


@contextmanager
def catalog_guard(ports: StorageCatalogPublicationPorts):
    with ports.get_pricing_config_lock():
        active = _guarded_runtimes.get()
        if id(ports) in active:
            yield
            return
        recover_catalog_publication(ports)
        token = _guarded_runtimes.set((*active, id(ports)))
        try:
            yield
        finally:
            _guarded_runtimes.reset(token)


def catalog_guarded(method):
    @wraps(method)
    def guarded(owner, *args, **kwargs):
        with catalog_guard(owner._catalog_publication):
            return method(owner, *args, **kwargs)

    return guarded


class CatalogPublication:
    """One publication within catalog_guard; no separate media or history commit."""

    def __init__(self, ports: StorageCatalogPublicationPorts, targets):
        self._ports = ports
        self.targets = sorted({_checked_target(ports, Path(p)) for p in targets})
        self.folder = ports.get_system_dir() / "catalog_transaction"
        self.journal = self.folder / "journal.json"
        self.document = {"schemaVersion": 1, "state": "PREPARED", "entries": []}

    def __enter__(self):
        self.folder.mkdir(mode=0o700, exist_ok=False)
        fsync_directory(self.folder.parent)
        for index, target in enumerate(self.targets):
            existed = target.is_file()
            mode = stat.S_IMODE(target.stat().st_mode) if existed else 0o640
            digest = None
            if existed:
                backup = self.folder / f"{index}.backup"
                durable_copy_file(target, backup, mode=0o600)
                digest = hashlib.sha256(backup.read_bytes()).hexdigest()
            self.document["entries"].append(
                {
                    "target": str(target),
                    "existed": existed,
                    "mode": mode,
                    "sha256": digest,
                }
            )
        durable_write_json(self.journal, self.document, mode=0o600)
        return self

    def __exit__(self, kind, error, traceback):
        if kind is None:
            self.document["state"] = "COMMITTED"
            durable_write_json(self.journal, self.document, mode=0o600)
        recover_catalog_publication(self._ports)
        return False
