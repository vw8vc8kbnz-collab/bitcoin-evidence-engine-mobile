"""Bounded cleanup of reconstructable operational state; active records are protected."""

from __future__ import annotations
from datetime import datetime, timedelta, timezone
from pathlib import Path
import re
import shutil
from metod_app.runtime.ports import StorageRetentionRuntimePorts
from metod_app.config import env_int as _env_int
from metod_app.identifiers import safe_identifier as _safe_id
from metod_app.observability.failures import report_recovery
from safety_contracts import strict_json_load, fsync_directory, delete_rotating_log_if_older_than


class OperationalCleanup:
    """One retention pass with separate owners for each disposable data category."""

    def __init__(self, ports: StorageRetentionRuntimePorts, now: datetime | None):
        self.ports = ports
        self.now = now
        self.catalog_import_history = self.ports.get_catalog_import_history()
        self.catalog_import_root = self.ports.get_catalog_import_root()
        self.decor_media_root = self.ports.get_decor_media_root()
        self.drafts = self.ports.get_drafts()
        self.jobs = self.ports.get_jobs()
        self.material_library_path = self.ports.get_material_library_path()
        self.queue_done = self.ports.get_queue_done()
        self.queue_failed = self.ports.get_queue_failed()
        self.requests = self.ports.get_requests()
        self.state_root = self.ports.get_state_root()
        self.submission_idempotency_dir = self.ports.get_submission_idempotency_dir()
        self.system_dir = self.ports.get_system_dir()
        self.system_log_file = self.ports.get_system_log_file()
        self.catalog_image_sync_active = self.ports.get_catalog_image_sync_active()
        self.catalog_image_sync_lock = self.ports.get_catalog_image_sync_lock()
        self.public_material_id_re = self.ports.get_public_material_id_re()
        self.ensure_request_dirs = self.ports.ensure_request_dirs
        self.ensure_system_dirs = self.ports.ensure_system_dirs
        self.cleanup_public_job_idempotency = self.ports.cleanup_public_job_idempotency
        self.path_dt = self.ports.path_dt
        self.ensure_request_dirs()
        self.ensure_system_dirs()
        self.now = self.now or datetime.now(timezone.utc).replace(tzinfo=None)
        self.result = {
            "catalogStages": 0,
            "catalogHistory": 0,
            "orphanDecorMedia": 0,
            "orphanQueueDone": 0,
            "orphanQueueFailed": 0,
            "orphanSubmissionClaims": 0,
            "orphanJobCreateClaims": 0,
            "orphanDrafts": 0,
            "rotatedLogs": 0,
            "errors": [],
        }

    def is_old(self, path: Path, days: int) -> bool:
        dt = self.path_dt(path)
        return bool(dt is not None and self.now - dt >= timedelta(days=max(1, days)))

    def load_catalog_authority(self) -> None:
        self.active_import_id = ""
        self.active_public_ids: set[str] = set()
        self.catalog_authority_ok = True
        try:
            library = strict_json_load(self.material_library_path)
            if not isinstance(library, dict) or not isinstance(library.get("records"), list):
                raise ValueError("Active catalog must contain a records list")
            if isinstance(library, dict):
                last_import = (
                    library.get("lastCatalogImport")
                    if isinstance(library.get("lastCatalogImport"), dict)
                    else {}
                )
                candidate = str(last_import.get("importId") or "").strip().lower()
                if re.fullmatch("cat_[a-f0-9]{24}", candidate):
                    self.active_import_id = candidate
                for record in library.get("records") or []:
                    if not isinstance(record, dict):
                        continue
                    if (
                        record.get("active") is False
                        or record.get("published") is False
                        or record.get("archived") is True
                    ):
                        continue
                    public_id = str(record.get("publicMaterialId") or "").strip().lower()
                    if self.public_material_id_re.fullmatch(public_id):
                        self.active_public_ids.add(public_id)
        except Exception as exc:
            report_recovery("metod_app.storage.retention_runtime.boundary.239", exc)
            self.result["errors"].append(f"active catalog unreadable: {exc}")
            self.catalog_authority_ok = False

    def cleanup_catalog_stages(self) -> None:
        with self.catalog_image_sync_lock:
            syncing_imports = set(self.catalog_image_sync_active)
        stage_days = max(1, _env_int("CATALOG_STAGE_RETENTION_DAYS", 7))
        stage_patterns = (
            re.compile("^(cat_[a-f0-9]{24})\\.json$"),
            re.compile("^(cat_[a-f0-9]{24})_images\\.json$"),
            re.compile("^(cat_[a-f0-9]{24})_media$"),
        )
        for path in sorted(self.catalog_import_root.iterdir() if self.catalog_import_root.exists() else []):
            if not self.catalog_authority_ok:
                break
            if path.name == "history":
                continue
            import_id = ""
            for pattern in stage_patterns:
                match = pattern.fullmatch(path.name)
                if match:
                    import_id = match.group(1)
                    break
            if (
                not import_id
                or import_id == self.active_import_id
                or import_id in syncing_imports
                or (not self.is_old(path, stage_days))
            ):
                continue
            try:
                if path.is_dir():
                    shutil.rmtree(path, ignore_errors=False)
                elif path.is_file():
                    path.unlink(missing_ok=True)
                else:
                    continue
                fsync_directory(self.catalog_import_root)
                self.result["catalogStages"] += 1
            except Exception as exc:
                report_recovery("metod_app.storage.retention_runtime.boundary.274", exc)
                self.result["errors"].append(f"catalog stage {path.name}: {exc}")

    def cleanup_catalog_history(self) -> None:
        history_keep = max(1, min(1000, _env_int("CATALOG_HISTORY_KEEP", 12)))
        history_days = max(1, _env_int("CATALOG_HISTORY_RETENTION_DAYS", 180))
        history_items = (
            sorted(
                [path for path in self.catalog_import_history.iterdir() if path.is_dir()],
                key=lambda path: path.stat().st_mtime,
                reverse=True,
            )
            if self.catalog_import_history.exists()
            else []
        )
        for index, path in enumerate(history_items):
            if index < history_keep and (not self.is_old(path, history_days)):
                continue
            try:
                shutil.rmtree(path, ignore_errors=False)
                fsync_directory(self.catalog_import_history)
                self.result["catalogHistory"] += 1
            except Exception as exc:
                report_recovery("metod_app.storage.retention_runtime.boundary.291", exc)
                self.result["errors"].append(f"catalog history {path.name}: {exc}")

    def cleanup_decor_media(self) -> None:
        media_days = max(1, _env_int("ORPHAN_DECOR_MEDIA_RETENTION_DAYS", 30))
        for path in sorted(self.decor_media_root.iterdir() if self.decor_media_root.exists() else []):
            if not self.catalog_authority_ok:
                break
            if not path.is_dir() or not self.public_material_id_re.fullmatch(path.name):
                continue
            if path.name in self.active_public_ids or not self.is_old(path, media_days):
                continue
            try:
                shutil.rmtree(path, ignore_errors=False)
                fsync_directory(self.decor_media_root)
                self.result["orphanDecorMedia"] += 1
            except Exception as exc:
                report_recovery("metod_app.storage.retention_runtime.boundary.306", exc)
                self.result["errors"].append(f"decor media {path.name}: {exc}")

    def cleanup_queue_mirrors(self) -> None:
        queue_days = max(1, _env_int("ORPHAN_QUEUE_RETENTION_DAYS", 30))
        for queue_dir, key in (
            (self.queue_done, "orphanQueueDone"),
            (self.queue_failed, "orphanQueueFailed"),
        ):
            for path in sorted(queue_dir.glob("*.json")):
                if not self.is_old(path, queue_days):
                    continue
                request_id = ""
                try:
                    payload = strict_json_load(path)
                    request_id = _safe_id(str((payload or {}).get("requestId") or ""), 120)
                except Exception as recovery_error:
                    report_recovery("metod_app.storage.retention_runtime.boundary.318", recovery_error)
                    self.result["errors"].append(
                        "metod_app.storage.retention_runtime._cleanup_operational_state.323"
                        + ": unreadable record; retained"
                    )
                    continue
                if request_id and (self.requests / request_id).is_dir():
                    continue
                try:
                    path.unlink(missing_ok=True)
                    fsync_directory(queue_dir)
                    self.result[key] += 1
                except Exception as exc:
                    report_recovery("metod_app.storage.retention_runtime.boundary.327", exc)
                    self.result["errors"].append(f"queue mirror {path.name}: {exc}")

    def cleanup_submission_claims(self) -> None:
        claim_days = max(1, _env_int("ORPHAN_SUBMISSION_CLAIM_RETENTION_DAYS", 1))
        for marker in sorted(self.submission_idempotency_dir.glob("*.json")):
            if not self.is_old(marker, claim_days):
                continue
            request_id = ""
            try:
                claim = strict_json_load(marker)
                request_id = _safe_id(str((claim or {}).get("requestId") or ""), 120)
            except Exception as recovery_error:
                report_recovery("metod_app.storage.retention_runtime.boundary.338", recovery_error)
                self.result["errors"].append(
                    "metod_app.storage.retention_runtime._cleanup_operational_state.342"
                    + ": unreadable record; retained"
                )
                continue
            if request_id and (self.requests / request_id / "status.json").is_file():
                continue
            try:
                marker.unlink(missing_ok=True)
                fsync_directory(self.submission_idempotency_dir)
                self.result["orphanSubmissionClaims"] += 1
            except Exception as exc:
                report_recovery("metod_app.storage.retention_runtime.boundary.347", exc)
                self.result["errors"].append(f"submission claim {marker.name}: {exc}")

    def cleanup_job_claims(self) -> None:
        job_claim_days = max(
            1, _env_int("ORPHAN_JOB_CREATE_CLAIM_RETENTION_DAYS", self.ports.get_orphan_job_retention_days())
        )
        try:
            cleanup = self.cleanup_public_job_idempotency(
                jobs_root=self.jobs, cutoff_timestamp=(self.now - timedelta(days=job_claim_days)).timestamp()
            )
            self.result["orphanJobCreateClaims"] = int(cleanup.get("removed") or 0)
            for error in cleanup.get("errors") or []:
                self.result["errors"].append(f"job-create claim: {error}")
        except Exception as exc:
            report_recovery("metod_app.storage.retention_runtime.boundary.365", exc)
            self.result["errors"].append(f"job-create claim cleanup: {exc}")

    def cleanup_drafts(self) -> None:
        draft_days = max(1, _env_int("ORPHAN_DRAFT_RETENTION_DAYS", 30))
        for draft in sorted(self.drafts.iterdir() if self.drafts.exists() else []):
            if not (draft.is_file() or draft.is_dir()) or not self.is_old(draft, draft_days):
                continue
            try:
                if draft.is_dir():
                    shutil.rmtree(draft, ignore_errors=False)
                else:
                    draft.unlink(missing_ok=True)
                fsync_directory(self.drafts)
                self.result["orphanDrafts"] += 1
            except Exception as exc:
                report_recovery("metod_app.storage.retention_runtime.boundary.379", exc)
                self.result["errors"].append(f"draft {draft.name}: {exc}")

    def cleanup_logs(self) -> None:
        log_days = max(1, _env_int("ROTATED_LOG_RETENTION_DAYS", 30))
        log_roots = [self.system_dir, self.state_root / "client_logs", self.jobs / "_crash_logs"]
        cutoff_ts = (self.now - timedelta(days=log_days)).timestamp()
        active_logs = (
            self.system_log_file,
            self.state_root / "client_logs" / "general_client_log.jsonl",
            self.state_root / "client_logs" / "ntfy.log",
        )
        for path in active_logs:
            try:
                if delete_rotating_log_if_older_than(path, cutoff_timestamp=cutoff_ts):
                    self.result["rotatedLogs"] += 1
            except Exception as exc:
                report_recovery("metod_app.storage.retention_runtime.boundary.397", exc)
                self.result["errors"].append(f"active log {path.name}: {exc}")
        for root in log_roots:
            if not root.exists():
                continue
            for path in sorted(root.rglob("*")):
                if not path.is_file() or not self.is_old(path, log_days):
                    continue
                name = path.name.lower()
                rotated = bool(
                    re.search("\\.(?:jsonl|log)\\.\\d+$", name)
                    or (
                        root == self.jobs / "_crash_logs"
                        and name.startswith("api_jobs_")
                        and name.endswith(".json")
                    )
                )
                if not rotated:
                    continue
                try:
                    path.unlink(missing_ok=True)
                    fsync_directory(path.parent)
                    self.result["rotatedLogs"] += 1
                except Exception as exc:
                    report_recovery("metod_app.storage.retention_runtime.boundary.416", exc)
                    self.result["errors"].append(f"rotated log {path.name}: {exc}")

    def run(self) -> dict:
        self.load_catalog_authority()
        self.cleanup_catalog_stages()
        self.cleanup_catalog_history()
        self.cleanup_decor_media()
        self.cleanup_queue_mirrors()
        self.cleanup_submission_claims()
        self.cleanup_job_claims()
        self.cleanup_drafts()
        self.cleanup_logs()
        return self.result
