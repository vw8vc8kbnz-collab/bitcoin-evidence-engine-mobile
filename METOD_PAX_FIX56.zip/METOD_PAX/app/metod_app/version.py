"""Generated from VERSION.json by tools/build_assets.cjs."""
REVISION = "R9RC4_FIX56_RUNTIME_PREFLIGHT"
