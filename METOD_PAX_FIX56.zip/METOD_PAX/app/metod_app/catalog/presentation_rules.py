"""Default catalog vocabulary; explicit Admin assignments take precedence downstream."""

from types import MappingProxyType

WOOD_TERMS = frozenset(
    {
        "hout",
        "wood",
        "oak",
        "eiken",
        "eik",
        "walnut",
        "noten",
        "noce",
        "beech",
        "beuken",
        "ash",
        "essen",
        "spruce",
        "vuren",
        "pine",
        "grenen",
        "teak",
        "sapele",
        "sapeli",
        "mahogany",
        "mahonie",
        "wenge",
        "eucalyptus",
        "bamboe",
        "bamboo",
        "elm",
        "iepen",
        "maple",
        "esdoorn",
        "cherry",
        "kersen",
        "acacia",
        "cedar",
        "ceder",
        "larch",
        "larix",
        "zebrano",
        "amazakoue",
        "yaya",
        "triba",
        "quercia",
        "sherwood",
        "barnwood",
        "flakewood",
        "corteccia",
        "fronda",
        "maloja",
        "fineer",
        "gefineerd",
        "veneer",
    }
)

STONE_TERMS = frozenset(
    {
        "steen",
        "stone",
        "marble",
        "marmer",
        "travertin",
        "travertine",
        "graniet",
        "granite",
        "terrazzo",
        "carrara",
        "ceppo",
        "cement",
        "mineral",
        "concrete",
        "beton",
        "concreta",
        "lime",
        "granulo",
        "leisteen",
        "slate",
    }
)

METAL_TERMS = frozenset(
    {
        "metaal",
        "metal",
        "metallic",
        "alu",
        "aluminium",
        "aluminum",
        "steel",
        "staal",
        "copper",
        "koper",
        "bronze",
        "brons",
        "gold",
        "goud",
        "oxid",
        "oxide",
        "brushed alu",
        "brushed bronze",
        "brushed gold",
    }
)

TEXTILE_TERMS = frozenset(
    {
        "textiel",
        "textile",
        "stof",
        "fabric",
        "woven",
        "linnen",
        "linen",
        "alpaca",
        "ovatta",
        "penelope",
        "taranta",
        "fiocco",
        "talco",
        "mosaico",
        "sable",
    }
)

UNI_TERMS = frozenset(
    {
        "uni",
        "effen",
        "solid",
        "front white",
        "elegant black",
        "supermat",
        "grondeerfolie",
        "wit",
        "white",
        "zwart",
        "black",
        "colour",
        "color",
    }
)

COLOR_RULES = (
    ("Zwart", ("zwart", "black", "nero", "noir", "antraciet", "anthracite")),
    ("Wit", ("wit", "white", "blanc", "chalk")),
    ("Grijs", ("grijs", "grey", "gray", "quartz", "silicon", "silver")),
    ("Beige", ("beige", "cream", "creamy", "ivory", "sand", "sahara", "greige", "fondant", "linen")),
    (
        "Bruin",
        (
            "bruin",
            "brown",
            "chocolat",
            "caramel",
            "walnut",
            "noten",
            "noce",
            "wenge",
            "teak",
            "sapele",
            "mahogany",
            "mahonie",
        ),
    ),
    ("Groen", ("groen", "green", "olive", "sage")),
    ("Blauw", ("blauw", "blue", "navy")),
    ("Rood", ("rood", "red", "bordeaux")),
    ("Roze", ("roze", "pink", "blush")),
    ("Geel", ("geel", "yellow", "oker", "ochre")),
    ("Oranje", ("oranje", "orange", "terracotta")),
)

FAMILY_SYNONYMS = MappingProxyType(
    {
        "Hout": ("hout", "houtlook", "wood", "woodlook"),
        "Uni": ("uni", "effen", "solid", "kleur"),
        "Steen": ("steen", "stone", "beton", "concrete", "marmer", "marble"),
        "Metaal": ("metaal", "metal", "metallic"),
        "Textiel": ("textiel", "stof", "fabric", "woven"),
        "Overig": ("decor",),
    }
)

COLOR_SYNONYMS = MappingProxyType(
    {
        "Zwart": ("zwart", "black"),
        "Wit": ("wit", "white"),
        "Grijs": ("grijs", "grey", "gray"),
        "Beige": ("beige", "cream", "zand"),
        "Bruin": ("bruin", "brown"),
        "Groen": ("groen", "green"),
        "Blauw": ("blauw", "blue"),
        "Rood": ("rood", "red"),
        "Roze": ("roze", "pink"),
        "Geel": ("geel", "yellow"),
        "Oranje": ("oranje", "orange"),
    }
)

TRANSLATIONS = MappingProxyType(
    {
        "oak": "eiken",
        "eiken": "oak",
        "walnut": "noten",
        "noten": "walnut",
        "beech": "beuken",
        "beuken": "beech",
        "ash": "essen",
        "essen": "ash",
        "white": "wit",
        "wit": "white",
        "black": "zwart",
        "zwart": "black",
        "grey": "grijs",
        "gray": "grijs",
        "grijs": "grey",
        "brown": "bruin",
        "bruin": "brown",
        "concrete": "beton",
        "beton": "concrete",
        "marble": "marmer",
        "marmer": "marble",
        "metal": "metaal",
        "metaal": "metal",
    }
)
