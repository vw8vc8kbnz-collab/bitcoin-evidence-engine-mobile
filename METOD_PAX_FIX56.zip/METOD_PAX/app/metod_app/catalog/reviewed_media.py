"""Content-addressed presentation corrections for reviewed catalog images.

Only exact source bytes select a correction. Material names, public identifiers,
prices and manufacturing/grain rules are not involved. Source caches remain
untouched; current imports and existing libraries share this read-only owner.
"""

from __future__ import annotations

from functools import lru_cache
import hashlib
import json
from pathlib import Path
import re


MEDIA_ROOT = Path(__file__).resolve().parent / "swatches"


@lru_cache(maxsize=1)
def _corrections() -> dict:
    data = json.loads((MEDIA_ROOT / "review.json").read_text(encoding="utf-8"))
    if data.get("schemaVersion") != 1 or not isinstance(data.get("corrections"), dict):
        raise ValueError("Invalid reviewed catalog media registry")
    for source_hash, item in data["corrections"].items():
        if not re.fullmatch(r"[a-f0-9]{64}", source_hash) or not isinstance(item, dict):
            raise ValueError("Invalid reviewed catalog source identity")
        digest = str(item.get("sha256") or "")
        if not re.fullmatch(r"[a-f0-9]{64}", digest) or item.get("asset") != digest + ".jpg":
            raise ValueError("Invalid reviewed catalog asset identity")
        if any(type(item.get(key)) is not int or item[key] <= 0 for key in ("width", "height", "bytes")):
            raise ValueError("Invalid reviewed catalog image dimensions")
    return data["corrections"]


@lru_cache(maxsize=128)
def _verify_asset(path: Path, signature: tuple, expected_hash: str, expected_bytes: int) -> None:
    # The signature includes ctime, so a changed file cannot reuse an old success
    # even when size and mtime are restored. No decoding/network/write is needed.
    data = path.read_bytes()
    if len(data) != expected_bytes or hashlib.sha256(data).hexdigest() != expected_hash:
        raise ValueError("Reviewed catalog image failed integrity verification")
    if not data.startswith(b"\xff\xd8\xff"):
        raise ValueError("Reviewed catalog image must be JPEG")


def resolve_reviewed_swatch(cached: tuple[Path, dict] | None) -> tuple[Path, dict] | None:
    """Return verified replacement media or the original validated cache tuple."""
    if cached is None:
        return None
    _, original = cached
    correction = _corrections().get(str(original.get("sha256") or ""))
    if correction is None:
        return cached
    path = MEDIA_ROOT / correction["asset"]
    if path.is_symlink() or not path.is_file():
        raise ValueError("Reviewed catalog image is unavailable")
    stat = path.stat()
    signature = (stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns)
    _verify_asset(path, signature, correction["sha256"], correction["bytes"])
    return path, {
        **original,
        "mime": "image/jpeg",
        "sha256": correction["sha256"],
        "bytes": correction["bytes"],
        "width": correction["width"],
        "height": correction["height"],
        "variants": {},
        "reviewedSwatch": True,
    }
