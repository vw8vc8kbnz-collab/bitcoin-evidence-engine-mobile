"""Pure public material identity shared by catalog and frozen job pricing."""

from __future__ import annotations


import re
from collections.abc import Iterable, Mapping


PUBLIC_MATERIAL_ID_RE = re.compile(r"decor_[a-f0-9]{20,40}")
INTERNAL_MATERIAL_KEYS = frozenset(
    {
        "articlenumber",
        "articleno",
        "article_number",
        "article_no",
        "materialcode",
        "material_code",
        "materialkey",
        "sku",
        "internalarticle",
        "internalarticlenumber",
        "internal_article_number",
        "internalcode",
    }
)


def internal_material_codes(record: Mapping) -> set[str]:
    material_record = any(
        key in record
        for key in (
            "publicMaterialId",
            "publicName",
            "decorName",
            "materialName",
            "productName",
        )
    ) or ("name" in record and any(key in record for key in ("sheetCount", "sheets", "plates")))
    codes = set()
    for key, value in record.items():
        if str(key).lower() not in INTERNAL_MATERIAL_KEYS and not (key == "code" and material_record):
            continue
        if not isinstance(value, (str, int)) or isinstance(value, bool):
            continue
        code = str(value).strip()
        if code and not PUBLIC_MATERIAL_ID_RE.fullmatch(code):
            codes.add(code)
    return codes


def public_material_name(record: Mapping, internal_codes: Iterable[str] = ()) -> str:
    """Strip private identifiers before a display name becomes a public snapshot."""
    name = next(
        (
            str(record[key]).strip()
            for key in (
                "publicName",
                "displayName",
                "materialDisplayName",
                "materialName",
                "productName",
                "decorName",
                "name",
            )
            if record.get(key)
        ),
        "Decor",
    )
    codes = internal_material_codes(record) | {str(code) for code in internal_codes if code}
    for code in sorted(codes, key=len, reverse=True):
        name = name.replace(code, "")
    return re.sub(r"\s+", " ", name).strip(" -/|")[:180] or "Decor"
