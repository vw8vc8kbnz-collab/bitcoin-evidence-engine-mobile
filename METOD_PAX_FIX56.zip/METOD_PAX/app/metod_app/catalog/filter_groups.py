"""Presentation-only filter groups. CSV truth and production taxonomy stay untouched.

Stable group IDs survive renames; overrides use private CSV article identity and
survive disappearance/reimport. Deleted automatic groups redirect future imports
as well. One durable document is the entire commit unit, under catalog_guard.
"""

from __future__ import annotations

from pathlib import Path

import copy
import hashlib
import json
import re
import secrets

from safety_contracts import strict_json_load

AXES = {"group": "Merk / groep", "appearance": "Uiterlijk", "color": "Kleurgroep"}
APPEARANCES = {
    "Hout": "wood",
    "Uni": "uni",
    "Steen & beton": "stone",
    "Metaal": "metal",
    "Textiel & leer": "textile",
    "Grafisch": "graphic",
    "Fantasie": "fantasy",
    "Onbekend": "other",
}
ID_RE = re.compile(r"^[a-z][a-z0-9_]{0,63}$")


def digest(value):
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode()
    ).hexdigest()


def document_path(system_dir: Path):
    return system_dir / "material_filters.json"


def read_document(path):
    if any(p.is_symlink() for p in (path, *path.parents)):
        raise ValueError("Unsafe filter configuration path")
    if not path.exists():
        return {
            "schemaVersion": 1,
            "axes": {a: {"groups": [], "redirects": {}, "overrides": {}} for a in AXES},
        }
    doc = strict_json_load(path)
    validate(doc)
    return doc


def label(value):
    if not isinstance(value, str):
        raise ValueError("Vul een groepsnaam in.")
    value = " ".join(value.split())
    if not 1 <= len(value) <= 60 or any(not c.isprintable() or c in "<>" for c in value):
        raise ValueError("Gebruik een groepsnaam van 1 tot 60 tekens, zonder HTML.")
    return value


def validate(doc):
    if not isinstance(doc, dict) or doc.get("schemaVersion") != 1 or set(doc.get("axes", {})) != set(AXES):
        raise ValueError("Ongeldige filterconfiguratie.")
    for axis in doc["axes"].values():
        if not isinstance(axis, dict) or set(axis) != {"groups", "redirects", "overrides"}:
            raise ValueError("Ongeldige filterindeling.")
        groups, redirects, overrides = (axis[k] for k in ("groups", "redirects", "overrides"))
        if not isinstance(groups, list) or len(groups) > 1000:
            raise ValueError("Maximaal 1000 groepen per filter.")
        ids, labels = set(), set()
        for group in groups:
            if not isinstance(group, dict) or set(group) != {"id", "label"}:
                raise ValueError("Ongeldige groep.")
            gid, title = group["id"], label(group["label"])
            if (
                not isinstance(gid, str)
                or not ID_RE.fullmatch(gid)
                or gid in ids
                or title.casefold() in labels
            ):
                raise ValueError("Groepen moeten unieke namen en IDs hebben.")
            ids.add(gid)
            labels.add(title.casefold())
        if (
            not isinstance(redirects, dict)
            or not isinstance(overrides, dict)
            or len(redirects) > 10000
            or len(overrides) > 100000
        ):
            raise ValueError("Te veel filtertoewijzingen.")
        if any(
            not isinstance(k, str) or not ID_RE.fullmatch(k) or k in ids or v not in ids
            for k, v in redirects.items()
        ):
            raise ValueError("Ongeldige verwijzing van verwijderde groep.")
        if any(not isinstance(k, str) or not k or len(k) > 256 or v not in ids for k, v in overrides.items()):
            raise ValueError("Ongeldige materiaaltoewijzing.")


def article_key(record):
    return str(
        record.get("articleNo")
        or record.get("articleNumber")
        or record.get("materialCode")
        or record.get("publicMaterialId")
        or ""
    ).strip()


def automatic(record, axis):
    if axis == "group":
        brand = str(record.get("brand") or "Overig").strip()
        name = str(record.get("productName") or record.get("publicName") or "").casefold()
        # Branded Unilin decors can have a grondeerfolie backing; keep their brand group.
        title = (
            "Grondeerfolie"
            if brand.casefold() in {"overig", "grondeerfolie"} and "grondeerfolie" in name
            else "Fineer"
            if brand.casefold() in {"nuxe", "fineer"}
            or (brand.casefold() == "overig" and any(term in name for term in ("fineer", "gefineerd")))
            else brand
        )
    elif axis == "appearance":
        title = str(
            record.get("primaryVisualFamily")
            or record.get("visualFamily")
            or record.get("decorType")
            or "Onbekend"
        ).strip()
        if title in APPEARANCES:
            return APPEARANCES[title], "Steen" if title == "Steen & beton" else title
    else:
        title = str(record.get("colorGroup") or "Overig").strip()
    return axis[0] + "_" + hashlib.sha256(title.casefold().encode()).hexdigest()[:20], title


def effective_document(doc, records):
    doc = copy.deepcopy(doc)
    for aid, axis in doc["axes"].items():
        candidates = []
        if aid == "appearance":
            candidates.extend(
                (gid, "Steen" if name == "Steen & beton" else name)
                for name, gid in APPEARANCES.items()
                if gid != "other"
            )
        candidates.extend(automatic(r, aid) for r in records)
        if aid != "appearance":
            candidates.sort(key=lambda item: item[1].casefold())
        ids = {g["id"] for g in axis["groups"]}
        names = {g["label"].casefold(): g["id"] for g in axis["groups"]}
        for gid, name in candidates:
            if gid in ids or gid in axis["redirects"]:
                continue
            # An admin-created label can absorb a newly imported automatic group.
            if name.casefold() in names:
                axis["redirects"][gid] = names[name.casefold()]
            else:
                axis["groups"].append({"id": gid, "label": label(name)})
                names[name.casefold()] = gid
                ids.add(gid)
    validate(doc)
    return doc


def assigned(record, aid, axis, *, auto=False):
    gid = automatic(record, aid)[0]
    gid = axis["redirects"].get(gid, gid)
    return gid if auto else axis["overrides"].get(article_key(record), gid)


def public_filters(record, doc):
    result = {}
    for aid, axis in doc["axes"].items():
        gid = assigned(record, aid, axis)
        index = next(i for i, g in enumerate(axis["groups"]) if g["id"] == gid)
        result[aid] = {**axis["groups"][index], "order": index}
    return result


def editable_records(records):
    return [
        r
        for r in records
        if isinstance(r, dict)
        and r.get("publicMaterialId")
        and str(r.get("sourceKind", "")).upper() == "CATALOG_IMPORT"
        and not r.get("catalogMissing")
        and not r.get("catalogExcluded")
    ]


def editor(doc, records, catalog_revision):
    rows = []
    counts = {aid: {} for aid in AXES}
    for r in editable_records(records):
        groups = {aid: assigned(r, aid, axis) for aid, axis in doc["axes"].items()}
        for aid, gid in groups.items():
            counts[aid][gid] = counts[aid].get(gid, 0) + 1
        rows.append(
            {
                "publicMaterialId": r["publicMaterialId"],
                "publicName": r.get("publicName") or r.get("productName") or "Decor",
                "brand": r.get("brand") or "",
                "groups": groups,
                "automatic": {aid: assigned(r, aid, axis, auto=True) for aid, axis in doc["axes"].items()},
                "overridden": {aid: article_key(r) in axis["overrides"] for aid, axis in doc["axes"].items()},
            }
        )
    return {
        "ok": True,
        "revision": digest([doc, catalog_revision]),
        "axes": [
            {
                "id": aid,
                "label": name,
                "groups": [{**g, "count": counts[aid].get(g["id"], 0)} for g in doc["axes"][aid]["groups"]],
            }
            for aid, name in AXES.items()
        ],
        "records": rows,
    }


def apply_operation(doc, records, data):
    aid, op = data.get("axis"), data.get("operation")
    fields = {
        "create": {"label"},
        "rename": {"groupId", "label"},
        "delete": {"groupId", "replacementId"},
        "move": {"groupId", "direction"},
        "assign": {"publicMaterialIds", "groupId"},
        "reset": {"publicMaterialIds"},
    }
    if (
        not isinstance(aid, str)
        or not isinstance(op, str)
        or aid not in AXES
        or op not in fields
        or set(data) != {"axis", "operation", "revision"} | fields[op]
    ):
        raise ValueError("Ongeldige filterbewerking.")
    doc = copy.deepcopy(doc)
    axis = doc["axes"][aid]
    groups = {g["id"]: g for g in axis["groups"]}
    gid = data.get("groupId")
    if op not in {"create", "reset"} and (not isinstance(gid, str) or gid not in groups):
        raise ValueError("De gekozen groep bestaat niet meer. Herlaad de indeling.")
    if op == "create":
        axis["groups"].append({"id": "custom_" + secrets.token_hex(10), "label": label(data["label"])})
    elif op == "rename":
        groups[gid]["label"] = label(data["label"])
    elif op == "move":
        direction = data["direction"]
        if type(direction) is not int or direction not in {-1, 1}:
            raise ValueError("Ongeldige volgorde.")
        index = axis["groups"].index(groups[gid])
        target = index + direction
        if 0 <= target < len(axis["groups"]):
            axis["groups"][index], axis["groups"][target] = axis["groups"][target], axis["groups"][index]
    elif op == "delete":
        target = data["replacementId"]
        if not isinstance(target, str) or target not in groups or target == gid:
            raise ValueError("Kies een andere groep voor huidige en toekomstige materialen.")
        axis["groups"].remove(groups[gid])
        axis["redirects"] = {k: target if v == gid else v for k, v in axis["redirects"].items()}
        axis["redirects"][gid] = target
        axis["overrides"] = {k: target if v == gid else v for k, v in axis["overrides"].items()}
    else:
        ids = data["publicMaterialIds"]
        if (
            not isinstance(ids, list)
            or not 1 <= len(ids) <= 1000
            or any(not isinstance(pid, str) for pid in ids)
            or len(set(ids)) != len(ids)
        ):
            raise ValueError("Selecteer 1 tot 1000 verschillende materialen.")
        by_id = {r["publicMaterialId"]: r for r in editable_records(records)}
        if any(pid not in by_id for pid in ids):
            raise ValueError("Een geselecteerd materiaal is niet meer beschikbaar. Herlaad de indeling.")
        for pid in ids:
            key = article_key(by_id[pid])
            if op == "reset":
                axis["overrides"].pop(key, None)
            else:
                axis["overrides"][key] = gid
    validate(doc)
    return doc
