"""Bounded NotificationRuntime implementation with explicit ports injection."""

from __future__ import annotations

from typing import Optional
from pathlib import Path
from metod_app.notifications.messages import build_failed_notification as _build_failed_notification
from metod_app.notifications.messages import build_submitted_notification as _build_submitted_notification
from catalog_importer import _PinnedHTTPSConnection as _catalog_pinned_https_connection
from metod_app.requests.projections import customer_block_from_sources as _customer_block_from_sources
from metod_app.config import env_int as _env_int
from metod_app.notifications.projections import merge_notification_pricing as _merge_ntfy_pricing
from metod_app.notifications.projections import (
    parse_calculation_summary as _parse_calculation_summary_for_ntfy,
)
from metod_app.notifications.projections import privacy_safe_customer_lines as _privacy_safe_customer_lines
from metod_app.security.redaction import redact_sensitive_text as _redact_sensitive_text
from metod_app.identifiers import safe_identifier as _safe_id
from metod_app.config import split_env_csv as _split_env_csv
from safety_contracts import append_jsonl_rotating
import ipaddress
import os
import socket
import ssl
from safety_contracts import strict_json_load
import time
from urllib.parse import urlparse
from metod_app.runtime.ports import NotificationsRuntimePorts


from metod_app.observability.failures import report_recovery


class NotificationRuntime:
    def __init__(self, ports: NotificationsRuntimePorts):
        self._ports = ports

    def _get_notify_config_file_path(_owner) -> Path:
        ports = _owner._ports
        CONFIG_NOTIFY = ports.get_config_notify()

        raw = str(os.environ.get("NOTIFY_CONFIG_FILE") or os.environ.get("CONFIG_NOTIFY_FILE") or "").strip()
        if raw:
            try:
                return Path(raw).expanduser()
            except Exception as recovery_error:
                report_recovery(
                    "metod_app.notifications.ports.get_notify_config_file_path.19", recovery_error
                )
        return CONFIG_NOTIFY

    def _ntfy_log(_owner, line: str) -> None:
        ports = _owner._ports
        NTFY_LOG = ports.get_ntfy_log()

        _now_iso = ports.now_iso

        try:
            append_jsonl_rotating(
                NTFY_LOG,
                {"ts": _now_iso(), "event": _redact_sensitive_text(line, 400)},
                max_bytes=max(1024, _env_int("NTFY_LOG_MAX_BYTES", 5 * 1024 * 1024)),
                backups=3,
            )
        except Exception as recovery_error:
            report_recovery("metod_app.notifications.ports.ntfy_log.39", recovery_error)

    def _load_notify_config(_owner) -> dict:
        """
        Notification config is OPTIONAL.
        - If app/config_notify.json exists, it overrides defaults.
        - If missing, we use safe defaults so it works out-of-the-box.
        """
        ports = _owner._ports
        _get_notify_config_file_path = ports.get_notify_config_file_path

        defaults = {
            "ntfy": {
                "enabled": False,
                "topic_url": "",
                "title": "AD Zaagt Configurator",
                "include_customer_details": False,
                "include_price_breakdown": False,
                "minimal_order_notice": True,
            }
        }
        try:
            notify_cfg_path = _get_notify_config_file_path()
            if notify_cfg_path.exists():
                cfg = strict_json_load(notify_cfg_path)
                if isinstance(cfg, dict):
                    # shallow-merge defaults
                    out = defaults.copy()
                    nt = defaults.get("ntfy", {}).copy()
                    if isinstance(cfg.get("ntfy"), dict):
                        nt.update(cfg.get("ntfy"))
                    out["ntfy"] = nt
                    return out
        except Exception as recovery_error:
            report_recovery("metod_app.notifications.ports.load_notify_config.75", recovery_error)
        return defaults

    def _validated_ntfy_target(_owner, topic_url: str) -> tuple[str, str, tuple[str, ...]]:
        """Validate and DNS-pin the one HTTPS endpoint that may receive ntfy secrets."""

        raw_url = str(topic_url or "").strip()
        if not raw_url or len(raw_url) > 2048 or any(ord(ch) < 32 or ord(ch) == 127 for ch in raw_url):
            raise ValueError("ntfy endpoint is invalid")
        parsed = urlparse(raw_url)
        host = str(parsed.hostname or "").lower().rstrip(".")
        allowed_hosts = {
            str(item or "").strip().lower().rstrip(".")
            for item in _split_env_csv("NTFY_ALLOWED_HOSTS", "ntfy.sh")
            if str(item or "").strip()
        }
        if parsed.scheme.lower() != "https" or not host or host not in allowed_hosts:
            raise ValueError("ntfy endpoint is not an allowed HTTPS host")
        if parsed.username or parsed.password or parsed.fragment:
            raise ValueError("ntfy endpoint is invalid")
        if parsed.port not in (None, 443):
            raise ValueError("ntfy endpoint must use the standard HTTPS port")

        # Resolve once, reject every non-public result, and connect to one of these
        # exact IPs below. This closes DNS-rebinding/private-network SSRF while TLS
        # still verifies the configured hostname.
        infos = socket.getaddrinfo(host, 443, type=socket.SOCK_STREAM)
        if not infos:
            raise ValueError("ntfy endpoint could not be resolved")
        public_ips: list[str] = []
        for info in infos:
            ip = ipaddress.ip_address(info[4][0])
            if (
                ip.is_private
                or ip.is_loopback
                or ip.is_link_local
                or ip.is_multicast
                or ip.is_reserved
                or ip.is_unspecified
            ):
                raise ValueError("ntfy endpoint resolves to a non-public address")
            normalized = str(ip)
            if normalized not in public_ips:
                public_ips.append(normalized)
        if not public_ips:
            raise ValueError("ntfy endpoint could not be resolved safely")
        return raw_url, host, tuple(public_ips)

    def _ntfy_send(
        _owner,
        title: Optional[str] = None,
        message: str = "",
        click_url: Optional[str] = None,
        priority: Optional[int] = None,
        tags: Optional[list[str]] = None,
    ) -> tuple[bool, str]:
        """Send ntfy notification. Never raises. Returns (ok, error)."""
        ports = _owner._ports

        _load_notify_config = ports.load_notify_config
        _ntfy_log = ports.ntfy_log
        _validated_ntfy_target = ports.validated_ntfy_target

        cfg = _load_notify_config()
        nt = cfg.get("ntfy") if isinstance(cfg, dict) else None
        if not isinstance(nt, dict):
            return (False, "ntfy config missing")
        if nt.get("enabled") is False:
            return (False, "ntfy disabled")
        topic_url = str(nt.get("topic_url") or "").strip()
        if not topic_url:
            return (False, "ntfy topic_url empty")
        try:
            safe_url, host, public_ips = _validated_ntfy_target(topic_url)
            parsed_topic = urlparse(safe_url)
        except Exception as recovery_error:
            report_recovery("metod_app.notifications.runtime.boundary.169", recovery_error)
            return (False, "ntfy endpoint is invalid")

        hdr_title = str(nt.get("title") or title or "").strip() or "Notification"
        auth = str(nt.get("authorization") or nt.get("auth") or nt.get("token") or "").strip()

        body = (message or "").encode("utf-8")
        headers = {
            "Title": hdr_title,
            "Content-Type": "text/plain; charset=utf-8",
            "User-Agent": "METOD-PAX-LocalServer/1.0",
        }
        if click_url:
            headers["Click"] = str(click_url)
        if priority is not None:
            headers["Priority"] = str(int(priority))
        if tags:
            headers["Tags"] = ",".join([str(t) for t in tags if t])
        if auth:
            # Allow both raw token and full 'Bearer ...'
            if auth.lower().startswith("bearer "):
                headers["Authorization"] = auth
            else:
                headers["Authorization"] = "Bearer " + auth

        request_target = parsed_topic.path or "/"
        if parsed_topic.query:
            request_target += "?" + parsed_topic.query
        deadline = time.monotonic() + 8.0
        for pinned_ip in public_ips:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            connection = _catalog_pinned_https_connection(host, pinned_ip, timeout=remaining)
            try:
                connection.request(
                    "POST",
                    request_target,
                    body=body,
                    headers={
                        **headers,
                        "Host": host,
                        "Accept-Encoding": "identity",
                        "Connection": "close",
                    },
                )
                response = connection.getresponse()
                # Authorization may be present, so never delegate redirect handling to
                # a generic client and never forward this request to another URL.
                if 300 <= int(response.status) < 400:
                    _ntfy_log(f"notification redirect rejected host={host}")
                    return (False, "redirect_forbidden")
                if not (200 <= int(response.status) < 300):
                    _ntfy_log(f"notification rejected host={host} status={int(response.status)}")
                    return (False, f"http_{int(response.status)}")
                response.read(1)
                _ntfy_log(f"notification delivered host={host}")
                return (True, "")
            except ssl.SSLCertVerificationError:
                _ntfy_log("notification failed: TLS verification")
                return (False, "tls_verification_failed")
            except Exception as recovery_error:
                report_recovery("metod_app.notifications.ports.ntfy_send.213", recovery_error)
            finally:
                try:
                    connection.close()
                except (OSError, ValueError, TypeError, OverflowError) as recovery_error:
                    report_recovery("metod_app.notifications.ports.ntfy_send.218", recovery_error)
        _ntfy_log("notification delivery failed")
        return (False, "delivery_failed")

    def _calculation_summary_text_for_ntfy(_owner, job_ids: list[str] | None) -> tuple[str, str]:
        """Return the first final calculation_summary.txt for the submitted order.

        ntfy must match the real backend/admin calculation, not the earlier frontend
        payload. Prefer the same human-readable calculation summary that Admin exposes.
        """
        ports = _owner._ports
        JOBS = ports.get_jobs()

        for jid in job_ids or []:
            jid = _safe_id(str(jid or "").strip(), 200)
            if not jid:
                continue
            for rel in (
                "output/calculation_summary.txt",
                "input/calculation_summary.txt",
                "calculation_summary.txt",
            ):
                try:
                    fp = JOBS / jid / rel
                    if fp.exists() and fp.is_file():
                        txt = fp.read_text(encoding="utf-8", errors="ignore")
                        if txt.strip():
                            return txt, jid
                except (OSError, ValueError, TypeError, OverflowError) as recovery_error:
                    report_recovery(
                        "metod_app.notifications.ports.calculation_summary_text_for_ntfy.245", recovery_error
                    )
        return "", ""

    def _notify_privacy_options(_owner) -> dict:
        ports = _owner._ports
        _load_notify_config = ports.load_notify_config

        cfg = _load_notify_config()
        nt = cfg.get("ntfy") if isinstance(cfg, dict) else {}
        if not isinstance(nt, dict):
            nt = {}
        return {
            "include_customer_details": bool(nt.get("include_customer_details") is True),
            "include_price_breakdown": bool(nt.get("include_price_breakdown", True) is not False),
            "minimal_order_notice": bool(nt.get("minimal_order_notice", True) is not False),
        }

    def _ntfy_public_safe_customer_lines(_owner, status: dict | None, payload: dict) -> list[str]:
        ports = _owner._ports

        _notify_privacy_options = ports.notify_privacy_options

        opts = _notify_privacy_options()
        customer_lines = _customer_block_from_sources(
            status if isinstance(status, dict) else None,
            payload if isinstance(payload, dict) else {},
        )
        return _privacy_safe_customer_lines(
            customer_lines,
            include_customer_details=bool(opts.get("include_customer_details")),
        )

    def _notify_submitted(
        _owner,
        request_id: str,
        payload: dict,
        status: dict | None = None,
        job_ids: list[str] | None = None,
        authoritative_pricing: dict | None = None,
    ) -> tuple[bool, str]:
        ports = _owner._ports

        _calculation_summary_text_for_ntfy = ports.calculation_summary_text_for_ntfy
        _extract_request_summary = ports.extract_request_summary

        _notify_privacy_options = ports.notify_privacy_options
        _ntfy_log = ports.ntfy_log
        _ntfy_public_safe_customer_lines = ports.ntfy_public_safe_customer_lines
        _ntfy_send = ports.ntfy_send

        summ = _extract_request_summary(payload or {})
        calc_text, calc_job_id = _calculation_summary_text_for_ntfy(job_ids or [])
        calc_info = _parse_calculation_summary_for_ntfy(calc_text)
        pricing = _merge_ntfy_pricing(summ, calc_info, authoritative_pricing)
        notify_opts = _notify_privacy_options()

        customer_lines: list[str] = []
        if not notify_opts.get("minimal_order_notice", True):
            try:
                customer_lines = _ntfy_public_safe_customer_lines(
                    status if isinstance(status, dict) else None,
                    payload if isinstance(payload, dict) else {},
                )
            except Exception as recovery_error:
                report_recovery("metod_app.notifications.ports._notify_submitted.307", recovery_error)
        notification = _build_submitted_notification(
            request_id,
            summ,
            calc_info,
            pricing,
            customer_lines,
            minimal_order_notice=bool(notify_opts.get("minimal_order_notice", True)),
            include_price_breakdown=bool(notify_opts.get("include_price_breakdown")),
            calculation_summary_present=bool(calc_text),
            calculation_job_id=calc_job_id,
        )
        ok, err = _ntfy_send(
            notification.title,
            notification.message,
            tags=list(notification.tags),
        )
        if not ok:
            _ntfy_log(f"SUBMIT notify failed: {err}")
        return (ok, err)

    def _notify_failed(_owner, request_id: str, err: str) -> tuple[bool, str]:
        ports = _owner._ports

        _ntfy_log = ports.ntfy_log
        _ntfy_send = ports.ntfy_send

        notification = _build_failed_notification(request_id, err)
        ok, err = _ntfy_send(
            notification.title,
            notification.message,
            tags=list(notification.tags),
        )
        if not ok:
            _ntfy_log(f"FAIL notify failed: {err}")
        return (ok, err)

    EXPORTS = (
        "_get_notify_config_file_path",
        "_ntfy_log",
        "_load_notify_config",
        "_validated_ntfy_target",
        "_ntfy_send",
        "_calculation_summary_text_for_ntfy",
        "_notify_privacy_options",
        "_ntfy_public_safe_customer_lines",
        "_notify_submitted",
        "_notify_failed",
    )


__all__ = ("NotificationRuntime",)
