"""Request display projections with explicit material-name resolution."""

from .customer import customer_address_lines, customer_block_from_sources, customer_block_from_status
from .summary import (
    MaterialNameResolver,
    customer_summary,
    price_incl_vat,
    materials_summary,
    plate_count,
    merge_quote_materials,
    materials_total,
    panel_count,
)


class RequestProjection:
    """Project display summaries; quote authority remains in server pricing."""

    def __init__(self, *, best_material_name: MaterialNameResolver) -> None:
        self._best_material_name = best_material_name

    def extract_summary(self, payload: dict) -> dict:
        quote = payload.get("quote") if isinstance(payload.get("quote"), dict) else None
        materials = materials_summary(payload, self._best_material_name)
        return {
            **customer_summary(payload),
            "priceInclVat": price_incl_vat(payload, quote),
            "materials": merge_quote_materials(materials, quote, self._best_material_name),
            "platesTotal": plate_count(payload, quote),
            "materialsPrice": materials_total(payload, quote),
            "panelsTotal": panel_count(payload),
        }


__all__ = (
    "RequestProjection",
    "customer_address_lines",
    "customer_block_from_sources",
    "customer_block_from_status",
)
