"""Pure request projections shared by submit, notifications and Admin output.

This module owns no files, locks, HTTP responses, routes or mutable global state.
Material-name resolution is injected so the existing catalog-backed behavior stays
at the composition root.
"""

from __future__ import annotations


from metod_app.observability.failures import report_recovery

import re
from typing import Any


def _first_nonempty(*values: Any) -> str:
    for value in values:
        if value is None:
            continue
        text = str(value).strip()
        if text:
            return text
    return ""


def customer_address_lines(customer: dict) -> list[str]:
    """Format billing and delivery independently, including foreign addresses.

    Aliases are read only for historical orders. New submissions store the
    canonical city/country fields and never infer the city from a postcode.
    """

    def first(*keys):
        return _first_nonempty(*(customer.get(key) for key in keys))

    def address(shipping=False):
        if shipping:
            street = first("shippingAddress", "bezorgAdres", "deliveryAddress", "address1", "deliveryStreet")
            house = first("shippingHouseNumber", "deliveryHouseNumber")
            postal = first("shippingPostcode", "shippingPostalCode", "deliveryPostcode", "deliveryPostalCode")
            city = first("shippingCity", "deliveryCity")
            country = first("shippingCountry", "deliveryCountry")
        else:
            street = first(
                "billingAddress", "invoiceAddress", "factuurAdres", "address", "addressLine1", "street"
            )
            house = first("houseNumber")
            postal = first("postcode", "postalCode")
            city = first("city", "plaats")
            country = first("country")
            if city and not postal and re.fullmatch(r"[0-9]{4}\s?[A-Za-z]{2}", city):
                postal, city = city, ""
        if street and house and not re.search(rf"(^|\s){re.escape(house)}($|\s)", street):
            street = f"{street} {house}"
        locality = " ".join(value for value in (postal, city) if value)
        return ", ".join(value for value in (street, locality, country) if value)

    billing = address()
    shipping = address(True)
    lines = [f"Factuur: {billing}"] if billing else []
    if customer.get("shippingSameAsBilling") is not True and shipping and shipping != billing:
        lines.append(f"Bezorg: {shipping}")
    return lines


def customer_block_from_status(request_status: dict | None) -> list[str]:
    if not isinstance(request_status, dict):
        return []
    lines: list[str] = []
    request_id = request_status.get("requestId") or ""
    created = request_status.get("createdAt") or request_status.get("updatedAt") or ""
    customer = request_status.get("customer")
    customer = customer if isinstance(customer, dict) else {}
    name = _first_nonempty(
        customer.get("name"),
        customer.get("fullName"),
        " ".join(str(customer.get(key) or "") for key in ("firstName", "lastName")),
    )
    contact = [
        ("Naam", name),
        ("Email", _first_nonempty(customer.get("email"), customer.get("mail"))),
        ("Telefoon", _first_nonempty(customer.get("phone"), customer.get("telephone"), customer.get("tel"))),
    ]
    if request_id or created:
        lines.extend(["Aanvraag", "-" * 40])
        lines.extend(
            f"{label}: {value}" for label, value in (("Request ID", request_id), ("Datum", created)) if value
        )
        lines.append("")
    if any(value for _, value in contact):
        lines.extend(["Klant", "-" * 40])
        lines.extend(f"{label}: {value}" for label, value in contact if value)
        lines.append("")
    address = customer_address_lines(customer)
    if address:
        lines.extend(["Adres", "-" * 40, *address, ""])
    return lines


def customer_block_from_sources(
    request_status: dict | None,
    payload: dict | None = None,
) -> list[str]:
    lines: list[str] = []
    request_id = ""
    created = ""
    customer: dict[str, Any] = {}
    note = ""
    rest_carry = None
    if isinstance(request_status, dict):
        request_id = request_status.get("requestId") or ""
        created = request_status.get("createdAt") or request_status.get("updatedAt") or ""
        stored = request_status.get("customer") if isinstance(request_status.get("customer"), dict) else {}
        if isinstance(stored, dict):
            customer.update(stored)
    if isinstance(payload, dict):
        payload_customer = payload.get("customer") if isinstance(payload.get("customer"), dict) else {}
        checkout = payload.get("checkout") if isinstance(payload.get("checkout"), dict) else {}
        checkout_customer = checkout.get("customer") if isinstance(checkout.get("customer"), dict) else {}
        try:
            if isinstance(checkout, dict):
                if "restCarry" in checkout:
                    rest_carry = bool(checkout.get("restCarry"))
                elif isinstance(checkout.get("rest_material"), dict) and "carry_out" in (
                    checkout.get("rest_material") or {}
                ):
                    rest_carry = bool((checkout.get("rest_material") or {}).get("carry_out"))
            if rest_carry is None and "restCarry" in payload:
                rest_carry = bool(payload.get("restCarry"))
        except (ValueError, TypeError, OverflowError, AttributeError) as recovery_error:
            report_recovery("metod_app.requests.projections.boundary.127", recovery_error)
            rest_carry = None
        merged: dict[str, Any] = {}
        for source in (customer, checkout_customer, payload_customer):
            if isinstance(source, dict):
                for key, value in source.items():
                    if value not in (None, ""):
                        merged[key] = value
        customer = merged
        note = _first_nonempty(
            checkout.get("note") if isinstance(checkout, dict) else "",
            payload.get("note"),
            payload_customer.get("note") if isinstance(payload_customer, dict) else "",
            checkout_customer.get("note") if isinstance(checkout_customer, dict) else "",
            payload_customer.get("comment") if isinstance(payload_customer, dict) else "",
            checkout_customer.get("comment") if isinstance(checkout_customer, dict) else "",
        )
    lines = customer_block_from_status(
        {
            "requestId": request_id,
            "createdAt": created,
            "customer": customer,
        }
    )
    if rest_carry is not None:
        lines.extend(["Restmateriaal", "-" * 40])
        lines.append(f"Meeleveren: {'JA' if rest_carry else 'NEE'}")
        lines.append("")
    if note:
        lines.extend(["Opmerking klant", "-" * 40, str(note).strip(), ""])
    return lines
