"""Single owner for durable request status and its reconstructable index.

The repository deliberately does not own submission, customer validation,
idempotency, Admin projection, archive transactions or retention. Paths and the
existing process lock are injected by the composition root so there is no second
state or lock owner.
"""

from __future__ import annotations

from metod_app.observability.failures import report_recovery


import copy
import os
from contextlib import contextmanager
from typing import Any, Callable

from safety_contracts import (
    append_jsonl_rotating,
    durable_write_json,
    durable_write_text,
    fsync_directory,
    resolve_identifier_child,
    strict_json_dumps,
    strict_json_load,
    validate_request_id,
)


PathProvider = Callable[[], Any]
LockProvider = Callable[[], Any]
IntProvider = Callable[[], int]


def request_index_row(request_id: str, status: dict) -> dict:
    """Return the established non-PII current-state request-index row."""

    job = status.get("job") if isinstance(status.get("job"), dict) else {}
    return {
        "ts": status.get("updatedAt") or status.get("createdAt"),
        "requestId": request_id,
        "publicStatus": status.get("publicStatus"),
        "internalStatus": status.get("internalStatus"),
        "quoteStatus": status.get("quoteStatus"),
        "needsQuote": bool(status.get("needsQuote")),
        "parentJobId": job.get("parentJobId"),
    }


class RequestRepository:
    """Durable request-status repository using one injected lock instance."""

    def __init__(
        self,
        *,
        requests_root: PathProvider,
        requests_index: PathProvider,
        index_lock: LockProvider,
        ensure_directories: Callable[[], None],
        utc_now_iso: Callable[[], str],
        jsonl_max_bytes: IntProvider,
        max_active_rows: IntProvider,
        file_lock_module: Callable[[], Any],
    ) -> None:
        self._requests_root = requests_root
        self._requests_index = requests_index
        self._index_lock = index_lock
        self._ensure_directories = ensure_directories
        self._utc_now_iso = utc_now_iso
        self._jsonl_max_bytes = jsonl_max_bytes
        self._max_active_rows = max_active_rows
        self._file_lock_module = file_lock_module

    @staticmethod
    def _is_cancelled(status: dict | None) -> bool:
        value = status if isinstance(status, dict) else {}
        return (
            str(value.get("publicStatus") or "").upper() == "CANCELLED"
            or str(value.get("internalStatus") or "").upper() == "CANCELLED"
        )

    @contextmanager
    def _status_transaction(self, request_id: str):
        """Serialize one request mutation in-process and across worker processes."""

        request_id = validate_request_id(request_id)
        request_root = resolve_identifier_child(self._requests_root(), request_id, kind="request")
        request_root.mkdir(parents=True, exist_ok=True, mode=0o700)
        lock_path = request_root / ".status.lock"
        with self._index_lock():
            with open(lock_path, "a+b", buffering=0) as lock_handle:
                os.chmod(lock_path, 0o600)
                file_lock = self._file_lock_module()
                if file_lock is not None:
                    file_lock.flock(lock_handle.fileno(), file_lock.LOCK_EX)
                try:
                    yield request_root
                finally:
                    if file_lock is not None:
                        file_lock.flock(lock_handle.fileno(), file_lock.LOCK_UN)

    @staticmethod
    def _load_status_path(status_path: Any) -> dict | None:
        try:
            data = strict_json_load(status_path)
            return data if isinstance(data, dict) else None
        except (OSError, ValueError, TypeError, OverflowError):
            return None

    def _write_status_locked(self, request_id: str, request_root: Any, status: dict) -> dict:
        current = self._load_status_path(request_root / "status.json") or {}
        next_status = copy.deepcopy(status)
        try:
            current_revision = max(0, int(current.get("statusRevision") or 0))
        except (ValueError, TypeError, OverflowError):
            current_revision = 0
        next_status["statusRevision"] = current_revision + 1
        next_status["updatedAt"] = self._utc_now_iso()
        # Request status contains customer contact data and cancellation capability data.
        durable_write_json(request_root / "status.json", next_status, mode=0o600)
        append_jsonl_rotating(
            self._requests_index(),
            request_index_row(request_id, next_status),
            max_bytes=self._jsonl_max_bytes(),
            backups=5,
        )
        return next_status

    def load_status(self, request_id: str) -> dict | None:
        try:
            request_id = validate_request_id(request_id)
            status_path = (
                resolve_identifier_child(self._requests_root(), request_id, kind="request") / "status.json"
            )
            return self._load_status_path(status_path)
        except Exception as recovery_error:
            report_recovery("metod_app.requests.repository.boundary.137", recovery_error)
            return None

    def save_status(self, request_id: str, status: dict) -> dict:
        """Persist a full status while preventing stale resurrection of cancellation."""

        request_id = validate_request_id(request_id)
        if not isinstance(status, dict):
            raise TypeError("request status must be an object")
        with self._status_transaction(request_id) as request_root:
            current = self._load_status_path(request_root / "status.json")
            if self._is_cancelled(current) and not self._is_cancelled(status):
                # CANCELLED is absorbing. A worker/admin writer holding an older copy
                # may never silently resurrect a customer-cancelled request.
                return copy.deepcopy(current or {})
            return copy.deepcopy(self._write_status_locked(request_id, request_root, status))

    def mutate_status(
        self,
        request_id: str,
        mutator: Callable[[dict | None], dict | None],
        *,
        allow_cancelled_restore: bool = False,
    ) -> tuple[dict | None, bool]:
        """Atomically load, mutate and save one request status.

        ``None`` from the mutator is a deliberate no-op. Unless the caller uses an
        explicit privileged restore path, CANCELLED remains an absorbing state.
        """

        request_id = validate_request_id(request_id)
        if not callable(mutator):
            raise TypeError("request status mutator must be callable")
        with self._status_transaction(request_id) as request_root:
            current = self._load_status_path(request_root / "status.json")
            candidate = mutator(copy.deepcopy(current) if isinstance(current, dict) else None)
            if candidate is None:
                return copy.deepcopy(current) if isinstance(current, dict) else None, False
            if not isinstance(candidate, dict):
                raise TypeError("request status mutator must return an object or None")
            if (
                self._is_cancelled(current)
                and not self._is_cancelled(candidate)
                and not allow_cancelled_restore
            ):
                return copy.deepcopy(current), False
            written = self._write_status_locked(request_id, request_root, candidate)
            return copy.deepcopy(written), True

    def compact_index(self) -> dict:
        """Write one PII-free row per active request to the bounded index."""

        self._ensure_directories()
        max_rows = max(1000, min(1_000_000, self._max_active_rows()))
        requests_root = self._requests_root()
        request_dirs = [path for path in sorted(requests_root.iterdir(), reverse=True) if path.is_dir()]
        truncated = len(request_dirs) > max_rows
        request_dirs = request_dirs[:max_rows]
        rows: list[str] = []
        for request_dir in request_dirs:
            status = self.load_status(request_dir.name)
            if isinstance(status, dict):
                rows.append(strict_json_dumps(request_index_row(request_dir.name, status)))
        payload = "\n".join(reversed(rows)) + ("\n" if rows else "")
        requests_index = self._requests_index()
        lock_path = requests_index.parent / f".{requests_index.name}.rotate.lock"
        removed_rotations = 0
        with self._index_lock():
            lock_path.parent.mkdir(parents=True, exist_ok=True)
            with open(lock_path, "a+b", buffering=0) as lock_handle:
                file_lock = self._file_lock_module()
                if file_lock is not None:
                    file_lock.flock(lock_handle.fileno(), file_lock.LOCK_EX)
                try:
                    durable_write_text(requests_index, payload, mode=0o640)
                    for rotated in requests_index.parent.glob(f"{requests_index.name}.*"):
                        suffix = rotated.name[len(requests_index.name) + 1 :]
                        if rotated.is_file() and suffix.isdigit():
                            rotated.unlink(missing_ok=True)
                            removed_rotations += 1
                    fsync_directory(requests_index.parent)
                finally:
                    if file_lock is not None:
                        file_lock.flock(lock_handle.fileno(), file_lock.LOCK_UN)
        return {
            "rows": len(rows),
            "truncated": truncated,
            "removedRotations": removed_rotations,
        }


__all__ = ("RequestRepository", "request_index_row")
