"""Pure, best-effort display projections of current and historical order payloads.

These helpers do not authorize prices; admission and pricing snapshots own quote authority.
"""

from typing import Any, Protocol
from metod_app.observability.failures import report_recovery
from metod_app.pricing.tax import LEGACY_VAT_RATE
from .customer import customer_address_lines


class MaterialNameResolver(Protocol):
    def __call__(self, code: str, *candidates: Any) -> str: ...


def customer_summary(payload: dict):
    out = {"customerName": "", "customerEmail": "", "customerPhone": "", "customerAddress": ""}
    try:
        customer = payload.get("customer") if isinstance(payload.get("customer"), dict) else {}
        if isinstance(customer, dict):
            first = str(customer.get("firstName") or "").strip()
            last = str(customer.get("lastName") or "").strip()
            full = " ".join([item for item in [first, last] if item]).strip()
            out["customerName"] = str(customer.get("name") or customer.get("fullName") or full or "").strip()
            out["customerEmail"] = str(customer.get("email") or customer.get("mail") or "").strip()
            out["customerPhone"] = str(
                customer.get("phone") or customer.get("tel") or customer.get("telephone") or ""
            ).strip()
            out["customerAddress"] = " | ".join(customer_address_lines(customer))
    except (ValueError, TypeError, OverflowError, AttributeError) as recovery_error:
        report_recovery("metod_app.requests.projections.extract_summary.307", recovery_error)
    return out


def price_incl_vat(payload: dict, quote: dict | None = None):
    out = {"priceInclVat": None}
    for key in ["priceInclVat", "totalPriceInclVat", "totalInclVat"]:
        try:
            if payload.get(key) is not None:
                out["priceInclVat"] = float(payload.get(key))
                break
        except (ValueError, TypeError, OverflowError) as recovery_error:
            report_recovery("metod_app.requests.projections.extract_summary.315", recovery_error)
    if out["priceInclVat"] is None and isinstance(quote, dict):
        for key in ["grandTotalInclVat", "totalInclVat", "inclVatTotal", "totalPriceInclVat"]:
            if quote.get(key) is not None:
                try:
                    out["priceInclVat"] = float(quote.get(key))
                    break
                except (ValueError, TypeError, OverflowError) as recovery_error:
                    report_recovery("metod_app.requests.projections.extract_summary.325", recovery_error)
        if out["priceInclVat"] is None:
            try:
                totals = quote.get("totals") if isinstance(quote.get("totals"), dict) else {}
                for key in ["grandTotalInclVat", "totalInclVat", "inclVatTotal", "totalPriceInclVat"]:
                    if totals.get(key) is not None:
                        out["priceInclVat"] = float(totals.get(key))
                        break
            except (ValueError, TypeError, OverflowError) as recovery_error:
                report_recovery("metod_app.requests.projections.extract_summary.334", recovery_error)
        if out["priceInclVat"] is None:
            try:
                totals = quote.get("totals") if isinstance(quote.get("totals"), dict) else {}
                base = None
                for key in ["grandTotal", "total", "subtotal"]:
                    if totals.get(key) is not None:
                        base = float(totals.get(key))
                        break
                if base is None:
                    for key in ["grandTotal", "total", "subtotal"]:
                        if quote.get(key) is not None:
                            base = float(quote.get(key))
                            break
                if base is not None:
                    out["priceInclVat"] = round(base * (1.0 + LEGACY_VAT_RATE), 2)
            except (ValueError, TypeError, OverflowError) as recovery_error:
                report_recovery("metod_app.requests.projections.extract_summary.351", recovery_error)
    return out["priceInclVat"]


def materials_summary(payload: dict, best_material_name: MaterialNameResolver):
    out = {"materials": []}
    materials = payload.get("materialsSummary")
    if isinstance(materials, list):
        for material in materials:
            if not isinstance(material, dict):
                continue
            code = str(
                material.get("code") or material.get("articleNumber") or material.get("materialCode") or ""
            ).strip()
            name = best_material_name(
                code,
                material.get("materialDisplayName"),
                material.get("materialName"),
                material.get("name"),
                material.get("productName"),
                material.get("decorName"),
            )
            plates = material.get("plates")
            try:
                plates = int(plates) if plates is not None else None
            except (ValueError, TypeError, OverflowError):
                plates = None
            if code or name:
                out["materials"].append({"code": code, "name": name, "plates": plates})
    else:
        codes: dict[str, dict[str, Any]] = {}

        def add_material(code: str, name: str = "") -> None:
            if not code and (not name):
                return
            key = code or name
            if key not in codes:
                codes[key] = {"code": code, "name": name, "plates": None}

        for array_key in ["cart", "extraPanels", "panels"]:
            items = payload.get(array_key)
            if not isinstance(items, list):
                continue
            for panel in items:
                if not isinstance(panel, dict):
                    continue
                code = str(
                    panel.get("articleNumber") or panel.get("materialKey") or panel.get("materialCode") or ""
                ).strip()
                name = best_material_name(
                    code,
                    panel.get("materialDisplayName"),
                    panel.get("productName"),
                    panel.get("decorName"),
                    panel.get("name"),
                )
                add_material(code, name)
        out["materials"] = list(codes.values())
    return out["materials"]


def plate_count(payload: dict, quote: dict | None = None):
    out = {"platesTotal": None}
    try:
        if payload.get("platesTotal") is not None:
            out["platesTotal"] = int(payload.get("platesTotal"))
    except (ValueError, TypeError, OverflowError) as recovery_error:
        report_recovery("metod_app.requests.projections.extract_summary.399", recovery_error)
    if out["platesTotal"] is None and isinstance(quote, dict):
        candidates: list[int] = []

        def walk(value: Any) -> None:
            if isinstance(value, dict):
                for key, child in value.items():
                    if (
                        str(key).lower()
                        in ("plates", "platencount", "sheetcount", "sheetsused", "boardsused", "boardscount")
                        and isinstance(child, (int, float))
                        and (child >= 0)
                    ):
                        candidates.append(int(child))
                    walk(child)
            elif isinstance(value, list):
                for child in value:
                    walk(child)

        walk(quote)
        if candidates:
            out["platesTotal"] = max(candidates)
    return out["platesTotal"]


def merge_quote_materials(
    materials: list[dict], quote: dict | None, best_material_name: MaterialNameResolver
):
    out = {"materials": materials}
    if isinstance(quote, dict):
        quote_materials = []
        try:
            raw_materials = quote.get("materials") if isinstance(quote.get("materials"), list) else None
            if raw_materials:
                for material in raw_materials:
                    if not isinstance(material, dict):
                        continue
                    code = str(
                        material.get("materialCode")
                        or material.get("code")
                        or material.get("articleNumber")
                        or ""
                    ).strip()
                    name = best_material_name(
                        code,
                        material.get("materialDisplayName"),
                        material.get("materialName"),
                        material.get("name"),
                        material.get("productName"),
                        material.get("decorName"),
                    )
                    plates = None
                    for key in ["plates", "sheets", "sheetsUsed", "boards", "boardsUsed", "sheetCount"]:
                        if material.get(key) is not None:
                            try:
                                plates = int(material.get(key))
                                break
                            except (ValueError, TypeError, OverflowError) as recovery_error:
                                report_recovery(
                                    "metod_app.requests.projections.extract_summary.438", recovery_error
                                )
                    quote_materials.append({"code": code, "name": name, "plates": plates})
        except (ValueError, TypeError, OverflowError, AttributeError) as recovery_error:
            report_recovery("metod_app.requests.projections.extract_summary.441", recovery_error)
        if quote_materials:
            existing = {item.get("code") or item.get("name"): item for item in out["materials"]}
            for material in quote_materials:
                key = material.get("code") or material.get("name")
                if not key:
                    continue
                if key in existing and material.get("plates") is not None:
                    existing[key]["plates"] = material.get("plates")
                elif key not in existing:
                    out["materials"].append(material)
    return out["materials"]


def materials_total(payload: dict, quote: dict | None = None):
    out = {"materialsPrice": None}
    for key in ["materialsPrice", "materialsTotal", "materialTotal", "materialsAmount"]:
        try:
            if payload.get(key) is not None:
                out["materialsPrice"] = float(payload.get(key))
                break
        except (ValueError, TypeError, OverflowError) as recovery_error:
            report_recovery("metod_app.requests.projections.extract_summary.459", recovery_error)
    if out["materialsPrice"] is None and isinstance(quote, dict):
        try:
            materials_total = None
            for key in ["materialsTotal", "materialTotal", "subtotalMaterials", "materialsSubtotal"]:
                if quote.get(key) is not None:
                    materials_total = quote.get(key)
                    break
            if materials_total is None:
                totals = quote.get("totals") if isinstance(quote.get("totals"), dict) else {}
                for key in ["materialsTotal", "materialTotal", "subtotalMaterials", "materialsSubtotal"]:
                    if totals.get(key) is not None:
                        materials_total = totals.get(key)
                        break
            if materials_total is None and isinstance(quote.get("materials"), list):
                values = []
                for material in quote.get("materials") or []:
                    if not isinstance(material, dict):
                        continue
                    for key in ["priceInclVat", "totalInclVat", "grandTotal", "total", "subtotal", "price"]:
                        if material.get(key) is not None:
                            try:
                                values.append(float(material.get(key)))
                                break
                            except (ValueError, TypeError, OverflowError) as recovery_error:
                                report_recovery(
                                    "metod_app.requests.projections.extract_summary.484", recovery_error
                                )
                if values:
                    materials_total = sum(values)
            if materials_total is not None:
                out["materialsPrice"] = float(materials_total)
        except (ValueError, TypeError, OverflowError, AttributeError) as recovery_error:
            report_recovery("metod_app.requests.projections.extract_summary.490", recovery_error)
    return out["materialsPrice"]


def panel_count(payload: dict, quote: dict | None = None):
    out = {"panelsTotal": None}
    try:
        panels_total = 0
        found_any = False
        for array_key in ["cart", "extraPanels", "panels"]:
            items = payload.get(array_key)
            if not isinstance(items, list):
                continue
            for panel in items:
                if not isinstance(panel, dict):
                    continue
                found_any = True
                quantity = None
                for key in ["qty", "quantity", "count", "aantal"]:
                    if panel.get(key) is not None:
                        try:
                            quantity = int(float(panel.get(key)))
                            break
                        except (ValueError, TypeError, OverflowError) as recovery_error:
                            report_recovery(
                                "metod_app.requests.projections.extract_summary.510", recovery_error
                            )
                panels_total += quantity if quantity is not None and quantity > 0 else 1
        if found_any and panels_total > 0:
            out["panelsTotal"] = panels_total
    except (ValueError, TypeError, OverflowError, AttributeError) as recovery_error:
        report_recovery("metod_app.requests.projections.extract_summary.515", recovery_error)
    return out["panelsTotal"]
