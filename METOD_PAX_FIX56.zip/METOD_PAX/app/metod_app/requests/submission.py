"""Final-request transaction without HTTP, routing or optimizer ownership.

The HTTP handler authenticates the finalized parent and maps the symbolic
outcome to the established status code. This module owns the existing durable
claim -> payload -> status -> notification/SSE order and never starts nesting.
"""

from __future__ import annotations


from metod_app.observability.failures import report_recovery

import hashlib
import time
from dataclasses import dataclass, field
from typing import Any, Callable

from metod_app.contracts.submission import normalize_customer_contract, sanitize_user_text
from safety_contracts import (
    ContractError as SafetyContractError,
    durable_create_json_exclusive,
    fsync_directory,
    strict_json_load,
    validate_job_id,
    validate_request_id,
)


Provider = Callable[[], Any]

_REQUIRED_CUSTOMER_FIELDS = (
    ("firstName", "Voornaam is verplicht."),
    ("lastName", "Achternaam is verplicht."),
    ("email", "E-mailadres is verplicht."),
    ("phone", "Telefoonnummer is verplicht."),
    ("billingAddress", "Factuuradres is verplicht."),
    ("postcode", "Postcode is verplicht."),
    ("houseNumber", "Huisnummer is verplicht."),
    ("city", "Woonplaats is verplicht."),
    ("country", "Land is verplicht."),
)
_REQUIRED_SHIPPING_FIELDS = (
    ("shippingAddress", "Bezorgadres is verplicht."),
    ("shippingPostcode", "Postcode bezorgadres is verplicht."),
    ("shippingHouseNumber", "Huisnummer bezorgadres is verplicht."),
    ("shippingCity", "Woonplaats bezorgadres is verplicht."),
    ("shippingCountry", "Land bezorgadres is verplicht."),
)


@dataclass(frozen=True)
class SubmissionOutcome:
    kind: str
    response: dict[str, Any] = field(default_factory=dict)


class SubmissionClaimRepository:
    """Exclusive durable parent-job claim with the established stale policy."""

    def __init__(
        self,
        *,
        marker_root: Provider,
        requests_root: Provider,
        utc_now_iso: Callable[[], str],
        wall_time: Callable[[], float] = time.time,
    ) -> None:
        self._marker_root = marker_root
        self._requests_root = requests_root
        self._utc_now_iso = utc_now_iso
        self._wall_time = wall_time

    def marker_path(self, parent_job_id: str):
        key = hashlib.sha256(str(parent_job_id or "").encode("utf-8")).hexdigest()
        return self._marker_root() / f"{key}.json"

    def read_claim(self, parent_job_id: str) -> str:
        """Return the persisted request or reclaim a stale incomplete marker."""

        try:
            parent = validate_job_id(parent_job_id)
        except SafetyContractError:
            return ""
        marker = self.marker_path(parent)
        try:
            if marker.exists():
                value = strict_json_load(marker)
                try:
                    request_id = validate_request_id(value.get("requestId"))
                except SafetyContractError:
                    request_id = ""
                status_path = self._requests_root() / request_id / "status.json"
                if request_id and status_path.exists():
                    status = strict_json_load(status_path)
                    status_job = status.get("job") if isinstance(status, dict) else {}
                    if (
                        value.get("parentJobId") == parent
                        and isinstance(status_job, dict)
                        and status_job.get("parentJobId") == parent
                    ):
                        return request_id
                    # An existing request for another parent is corruption, not
                    # an incomplete stale claim. Never reclaim it automatically.
                    return ""
                try:
                    if (self._wall_time() - marker.stat().st_mtime) > 300:
                        marker.unlink(missing_ok=True)
                        fsync_directory(marker.parent)
                except Exception as recovery_error:
                    report_recovery("metod_app.requests.submission.read_claim.100", recovery_error)
        except Exception as recovery_error:
            report_recovery("metod_app.requests.submission.read_claim.102", recovery_error)
        return ""

    def reserve_claim(self, parent_job_id: str, request_id: str) -> tuple[bool, str]:
        """Atomically reserve one final submission per finalized parent job."""

        try:
            parent = validate_job_id(parent_job_id)
            request_id = validate_request_id(request_id)
        except SafetyContractError:
            return False, ""
        self._marker_root().mkdir(parents=True, exist_ok=True)
        marker = self.marker_path(parent)
        existing = self.read_claim(parent)
        if existing:
            return False, existing
        data = {
            "schemaVersion": 1,
            "parentJobId": parent,
            "requestId": request_id,
            "createdAt": self._utc_now_iso(),
        }
        try:
            if not durable_create_json_exclusive(marker, data, mode=0o600):
                raise FileExistsError(str(marker))
            return True, request_id
        except FileExistsError:
            existing = self.read_claim(parent)
            if existing:
                return False, existing
            try:
                value = strict_json_load(marker)
                return False, validate_request_id(value.get("requestId"))
            except Exception as recovery_error:
                report_recovery("metod_app.requests.submission.boundary.143", recovery_error)
                return False, ""


class SubmissionService:
    """Commit one authenticated finalized calculation as a customer request."""

    def __init__(
        self,
        *,
        claims: SubmissionClaimRepository,
        claim_lock: Provider,
        read_json: Callable[[Any], Any],
        email_is_valid: Callable[[str], bool],
        linked_subjob_ids: Callable[[str], list[str]],
        resolve_job_root: Callable[[str], Any],
        finalization_complete: Callable[[Any], bool],
        pricing_summary: Callable[[list[str]], dict],
        new_request_id: Callable[[], str],
        new_cancel_token: Callable[[], str],
        resolve_request_root: Callable[[str], Any],
        atomic_write_json: Callable[[Any, dict], None],
        utc_now_iso: Callable[[], str],
        extract_summary: Callable[[dict], dict],
        save_status: Callable[[str, dict], None],
        load_status: Callable[[str], dict | None],
        request_status_exists: Callable[[str], bool],
        safe_identifier: Callable[[Any, int], str],
        notify_submitted: Callable[..., tuple[bool, str]],
    ) -> None:
        self._claims = claims
        self._claim_lock = claim_lock
        self._read_json = read_json
        self._email_is_valid = email_is_valid
        self._linked_subjob_ids = linked_subjob_ids
        self._resolve_job_root = resolve_job_root
        self._finalization_complete = finalization_complete
        self._pricing_summary = pricing_summary
        self._new_request_id = new_request_id
        self._new_cancel_token = new_cancel_token
        self._resolve_request_root = resolve_request_root
        self._atomic_write_json = atomic_write_json
        self._utc_now_iso = utc_now_iso
        self._extract_summary = extract_summary
        self._save_status = save_status
        self._load_status = load_status
        self._request_status_exists = request_status_exists
        self._safe_identifier = safe_identifier
        self._notify_submitted = notify_submitted

    def finalize(self, parent_job_id: str, parent_root: Any, payload: dict) -> SubmissionOutcome:
        customer = payload.get("customer") if isinstance(payload.get("customer"), dict) else {}
        try:
            stored_job = self._read_json(parent_root / "input" / "job.json")
            if not isinstance(stored_job, dict) or not isinstance(stored_job.get("customer"), dict):
                return SubmissionOutcome("incomplete_output")
            stored_customer = dict(stored_job["customer"])
        except Exception as recovery_error:
            report_recovery("metod_app.requests.submission.boundary.200", recovery_error)
            return SubmissionOutcome("incomplete_output")
        stored_note = sanitize_user_text(stored_job.get("note"), 2000, allow_note_chars=True)
        effective_customer: dict[str, Any] = dict(stored_customer)
        # Omitted fields retain the calculated value. Explicit empty values clear
        # it for comparison; legacy aliases cannot resurrect a cleared field.
        aliases = (
            ("name", "fullName"),
            ("company", "companyName"),
            ("email", "mail"),
            ("phone", "tel", "telephone"),
            ("billingAddress", "invoiceAddress", "address", "addressLine1", "street"),
            ("postcode", "postalCode"),
            ("shippingAddress", "deliveryAddress"),
            ("shippingPostcode", "shippingPostalCode", "deliveryPostcode", "deliveryPostalCode"),
            ("shippingHouseNumber", "deliveryHouseNumber"),
            ("city", "plaats"),
        )
        for group in aliases:
            if any(key in customer for key in group):
                for key in group:
                    effective_customer.pop(key, None)
        effective_customer.update(customer)
        customer = normalize_customer_contract(effective_customer)
        for field_name, message in _REQUIRED_CUSTOMER_FIELDS:
            if not str(customer.get(field_name) or "").strip():
                return SubmissionOutcome(
                    "invalid_customer",
                    {"error": message, "field": field_name},
                )
        effective_email = str(customer.get("email") or "").strip()
        if not self._email_is_valid(effective_email):
            return SubmissionOutcome("invalid_email")
        if customer.get("shippingSameAsBilling") is False:
            for field_name, message in _REQUIRED_SHIPPING_FIELDS:
                if not str(customer.get(field_name) or "").strip():
                    return SubmissionOutcome(
                        "invalid_customer",
                        {"error": message, "field": field_name},
                    )
        expected_customer = normalize_customer_contract(stored_customer)
        # The note is owned by the immutable job-level snapshot in calculation.
        expected_customer.pop("note", None)
        customer.pop("note", None)
        submitted_note = sanitize_user_text(payload.get("note", stored_note), 2000, allow_note_chars=True)
        customer_note = effective_customer.get("note")
        if (
            customer != expected_customer
            or submitted_note != stored_note
            or (
                customer_note is not None
                and sanitize_user_text(customer_note, 2000, allow_note_chars=True) != stored_note
            )
        ):
            return SubmissionOutcome("customer_changed")
        customer["note"] = stored_note
        payload["customer"] = customer
        payload["note"] = stored_note
        first = str(customer.get("firstName") or "").strip()
        last = str(customer.get("lastName") or "").strip()
        full = " ".join([item for item in [first, last] if item]).strip()
        customer_name = str(customer.get("name") or customer.get("fullName") or full or "").strip()

        linked_subjobs = self._linked_subjob_ids(parent_job_id)
        if not linked_subjobs or any(
            not self._finalization_complete(self._resolve_job_root(subjob_id)) for subjob_id in linked_subjobs
        ):
            return SubmissionOutcome("incomplete_output")
        candidate_job_ids = [parent_job_id] + [
            subjob_id for subjob_id in linked_subjobs if subjob_id and subjob_id != parent_job_id
        ]
        authoritative_pricing = self._pricing_summary(candidate_job_ids) or {}
        try:
            authoritative_total = float(authoritative_pricing.get("totalInclVat"))
        except (ValueError, TypeError, OverflowError):
            authoritative_total = 0.0
        if authoritative_total <= 0:
            return SubmissionOutcome("missing_price")

        with self._claim_lock():
            replay_id = self._claims.read_claim(parent_job_id)
        if replay_id:
            replay = self._existing_response(replay_id, parent_job_id)
            return SubmissionOutcome("duplicate", replay) if replay else SubmissionOutcome("in_progress")

        # Request IDs are independently unique across parents. Reserve the
        # destination exclusively before publishing its parent claim; a UUID
        # collision can never overwrite a different request directory.
        request_root = None
        for _attempt in range(128):
            request_id = validate_request_id(self._new_request_id())
            candidate = self._resolve_request_root(request_id)
            candidate.parent.mkdir(parents=True, exist_ok=True)
            try:
                candidate.mkdir(mode=0o700)
            except FileExistsError:
                continue
            fsync_directory(candidate.parent)
            request_root = candidate
            break
        if request_root is None:
            # A failed or injected ID source must not claim the parent without
            # a unique request destination. A later retry remains possible.
            return SubmissionOutcome("in_progress")
        with self._claim_lock():
            claimed, existing_request_id = self._claims.reserve_claim(parent_job_id, request_id)
        if not claimed:
            # Only our newly reserved, still-empty directory can be removed.
            request_root.rmdir()
            fsync_directory(request_root.parent)
            existing_request_id = self._safe_identifier(str(existing_request_id or "").strip(), 120)
            if existing_request_id and self._request_status_exists(existing_request_id):
                existing_response = self._existing_response(existing_request_id, parent_job_id)
                if existing_response:
                    return SubmissionOutcome("duplicate", existing_response)
            return SubmissionOutcome("in_progress")

        cancel_token = self._new_cancel_token()
        input_root = request_root / "input"
        input_root.mkdir(mode=0o700)
        self._atomic_write_json(input_root / "submit_payload.json", payload)

        created = self._utc_now_iso()
        status = {
            "schemaVersion": "1.0",
            "requestId": request_id,
            "createdAt": created,
            "updatedAt": created,
            "customer": {
                "name": customer_name,
                "fullName": customer_name,
                "firstName": str(customer.get("firstName") or "").strip(),
                "lastName": str(customer.get("lastName") or "").strip(),
                "company": str(customer.get("company") or customer.get("companyName") or "").strip(),
                "email": str(customer.get("email") or customer.get("mail") or "").strip(),
                "phone": str(
                    customer.get("phone") or customer.get("tel") or customer.get("telephone") or ""
                ).strip(),
                "billingAddress": str(
                    customer.get("billingAddress")
                    or customer.get("invoiceAddress")
                    or customer.get("address")
                    or customer.get("addressLine1")
                    or customer.get("street")
                    or ""
                ).strip(),
                "shippingAddress": str(
                    customer.get("shippingAddress")
                    or customer.get("deliveryAddress")
                    or customer.get("address1")
                    or ""
                ).strip(),
                "shippingPostcode": str(customer.get("shippingPostcode") or "").strip(),
                "shippingHouseNumber": str(customer.get("shippingHouseNumber") or "").strip(),
                "shippingSameAsBilling": bool(customer.get("shippingSameAsBilling"))
                if isinstance(customer.get("shippingSameAsBilling"), bool)
                else True,
                "houseNumber": str(customer.get("houseNumber") or "").strip(),
                "postalCode": str(customer.get("postalCode") or customer.get("postcode") or "").strip(),
                "postcode": str(customer.get("postcode") or customer.get("postalCode") or "").strip(),
                "city": str(customer.get("city") or customer.get("plaats") or "").strip(),
                "country": str(customer.get("country") or "").strip(),
                "shippingCity": str(customer.get("shippingCity") or "").strip(),
                "shippingCountry": str(customer.get("shippingCountry") or "").strip(),
                "note": str(payload.get("note") or customer.get("note") or "").strip(),
            },
            "publicStatus": "SUBMITTED",
            "publicStatusLabel": "Aanvraag verzonden",
            "needsQuote": True,
            "quoteStatus": "TODO",
            "internalStatus": "DONE",
            "internalStatusLabel": "Gekoppeld aan afgeronde berekening",
            "job": {"parentJobId": parent_job_id, "subjobs": linked_subjobs},
            "source": "submit-config-link",
            "error": None,
            "cancel": None,
            "cancelControl": {"cancelToken": cancel_token, "issuedAt": created},
        }
        try:
            status["summary"] = self._extract_summary(payload)
        except Exception as recovery_error:
            report_recovery("metod_app.requests.submission.finalize.349", recovery_error)
        self._save_status(request_id, status)

        notification_ok = False
        try:
            notification_ok, _ = self._notify_submitted(
                request_id,
                payload,
                status=status,
                job_ids=candidate_job_ids,
                authoritative_pricing=authoritative_pricing,
            )
        except Exception as recovery_error:
            report_recovery("metod_app.requests.submission.boundary.369", recovery_error)
            notification_ok = False
        return SubmissionOutcome(
            "created",
            {
                "ok": True,
                "requestId": request_id,
                "cancelToken": cancel_token,
                "notificationQueued": bool(notification_ok),
                "createdAt": created,
                "pricingSummary": authoritative_pricing,
            },
        )

    def _existing_response(self, request_id: str, parent_job_id: str) -> dict:
        status = self._load_status(request_id) or {}
        stored_job = status.get("job") if isinstance(status, dict) else None
        if not isinstance(stored_job, dict) or stored_job.get("parentJobId") != parent_job_id:
            return {}
        cancel_control = status.get("cancelControl") if isinstance(status.get("cancelControl"), dict) else {}
        candidates = [str(parent_job_id or "").strip()] + self._linked_subjob_ids(parent_job_id)
        pricing = self._pricing_summary([item for item in candidates if item]) or {}
        return {
            "ok": True,
            "duplicate": True,
            "requestId": request_id,
            "cancelToken": str(cancel_control.get("cancelToken") or ""),
            "createdAt": status.get("createdAt"),
            "pricingSummary": pricing,
        }


__all__ = ("SubmissionClaimRepository", "SubmissionOutcome", "SubmissionService")
