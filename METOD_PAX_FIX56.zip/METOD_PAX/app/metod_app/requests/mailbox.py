"""Pure Admin mailbox filtering and pagination; never mutates request state."""

from __future__ import annotations


import re
import unicodedata
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Iterable


PAGE_SIZES = frozenset({10, 25, 50, 100})
CATEGORIES = frozenset({"inbox", "processing", "errors", "done", "cancelled", "all"})
SORTS = frozenset({"newest", "oldest", "name"})


@dataclass(frozen=True)
class MailboxQuery:
    page: int = 1
    page_size: int = 25
    search: str = ""
    category: str = "inbox"
    sort: str = "newest"

    def __post_init__(self) -> None:
        if type(self.page) is not int or not 1 <= self.page <= 1_000_000:
            raise ValueError("invalid page")
        if type(self.page_size) is not int or self.page_size not in PAGE_SIZES:
            raise ValueError("invalid page size")
        if not isinstance(self.search, str) or len(self.search) > 200:
            raise ValueError("invalid search")
        if self.category not in CATEGORIES or self.sort not in SORTS:
            raise ValueError("invalid mailbox filter")


def mailbox_category(status: dict) -> str:
    """One display category, without changing the underlying business statuses."""
    public = str(status.get("publicStatus") or "").upper()
    internal = str(status.get("internalStatus") or "").upper()
    if "CANCELLED" in (public, internal):
        return "cancelled"
    if internal == "FAILED" or public in {"FAILED", "ERROR"}:
        return "errors"
    if public in {"DONE", "AFGEHANDELD"}:
        return "done"
    if internal == "PROCESSING" or public in {"OFFER_SENT", "IN_PRODUCTION"}:
        return "processing"
    if public == "SUBMITTED":
        return "inbox"
    return "errors"


def with_mailbox_category(status: dict) -> dict:
    return {**status, "mailboxCategory": mailbox_category(status)}


def _normalize(value: object) -> str:
    decomposed = unicodedata.normalize("NFD", str(value or ""))
    return "".join(char for char in decomposed if not unicodedata.combining(char)).casefold().strip()


def _created_time(status: dict) -> float:
    value = str(status.get("createdAt") or status.get("updatedAt") or "")
    try:
        stamp = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if stamp.tzinfo is None:
            stamp = stamp.replace(tzinfo=timezone.utc)
        return stamp.timestamp()
    except (ValueError, OverflowError, OSError):
        return float("-inf")


def mailbox_page(statuses: Iterable[dict], query: MailboxQuery) -> dict:
    """Search the entire supplied collection before applying category and page."""
    needle = _normalize(query.search)
    phone_needle = re.sub(r"\D", "", needle)
    search_phone = bool(re.fullmatch(r"[+()\d\s-]+", needle)) and len(phone_needle) >= 3
    counts = {category: 0 for category in sorted(CATEGORIES)}
    matching: list[dict] = []
    for status in statuses:
        customer = status.get("customer")
        customer = customer if isinstance(customer, dict) else {}
        values = (status.get("requestId"), customer.get("name"), customer.get("email"), customer.get("phone"))
        if needle and not any(needle in _normalize(value) for value in values):
            phone = re.sub(r"\D", "", str(customer.get("phone") or ""))
            if not search_phone or phone_needle not in phone:
                continue
        category = mailbox_category(status)
        counts["all"] += 1
        counts[category] += 1
        if query.category == "all" or category == query.category:
            matching.append(status)

    if query.sort == "name":

        def sort_key(status: dict) -> tuple[str, str]:
            customer = status.get("customer")
            name = customer.get("name") if isinstance(customer, dict) else ""
            return _normalize(name), str(status.get("requestId") or "")

        matching.sort(key=sort_key)
    else:
        matching.sort(
            key=lambda status: (_created_time(status), str(status.get("requestId") or "")),
            reverse=query.sort == "newest",
        )

    total = len(matching)
    page_count = max(1, (total + query.page_size - 1) // query.page_size)
    page = min(query.page, page_count)
    offset = (page - 1) * query.page_size
    return {
        "requests": [with_mailbox_category(status) for status in matching[offset : offset + query.page_size]],
        "page": page,
        "pageSize": query.page_size,
        "pageCount": page_count,
        "total": total,
        "counts": counts,
    }
