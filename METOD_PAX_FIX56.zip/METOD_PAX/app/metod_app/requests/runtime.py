"""Bounded RequestRuntime implementation with explicit ports injection."""

from __future__ import annotations

from metod_app.observability.failures import report_recovery

from typing import Optional
from safety_contracts import ContractError as SafetyContractError
from metod_app.identifiers import safe_identifier as _safe_id
from safety_contracts import resolve_identifier_child
from safety_contracts import strict_json_load
import time
import uuid
from safety_contracts import validate_job_id
from metod_app.runtime.ports import RequestsRuntimePorts


class RequestRuntime:
    def __init__(self, ports: RequestsRuntimePorts):
        self._ports = ports

    def _new_request_id(_owner) -> str:
        # Readable timestamp plus 128 random bits; the service also reserves exclusively.
        return time.strftime("%Y%m%d_%H%M%S_") + uuid.uuid4().hex

    def _linked_subjob_ids(_owner, parent_job_id: str) -> list[str]:
        """Return private material subjob ids from the finalized parent job only."""
        ports = _owner._ports
        JOBS = ports.get_jobs()

        try:
            parent = validate_job_id(parent_job_id)
            parent_root = resolve_identifier_child(JOBS, parent)
        except SafetyContractError:
            return []
        out: list[str] = []
        try:
            links_path = parent_root / "output" / "links.json"
            if links_path.exists():
                links = strict_json_load(links_path)
                raw = links.get("subjobs") if isinstance(links, dict) else []
                if isinstance(raw, list):
                    for item in raw:
                        if isinstance(item, dict):
                            value = item.get("jobId") or item.get("subjobId") or item.get("id")
                        else:
                            value = item
                        try:
                            sj = validate_job_id(value)
                            resolve_identifier_child(JOBS, sj)
                        except SafetyContractError:
                            continue
                        if sj not in out:
                            out.append(sj)
        except Exception as recovery_error:
            report_recovery("metod_app.requests.runtime.boundary.55", recovery_error)
            return []
        return out

    def _master_job_id_for(_owner, job_id: str) -> str:
        """Return the opaque master id for a master or material-subjob id."""

        job_id = validate_job_id(job_id)
        return validate_job_id(job_id.split("__mat_", 1)[0] if "__mat_" in job_id else job_id)

    def _public_job_family_complete(_owner, job_id: str, *, memo: dict[str, bool] | None = None) -> bool:
        """Authorize public result exposure only after the whole family is DONE.

        A material subjob can be sealed while later materials are still processing.
        Its bearer value is intentionally shared with the master, so subjob status and
        quote routes must never treat that partial result as an independently completed
        customer calculation.
        """
        ports = _owner._ports
        _JOB_FINALIZATION_SERVICE = ports.get_job_finalization_service()

        return _JOB_FINALIZATION_SERVICE.public_family_complete(job_id, memo=memo)

    def _iter_request_statuses(_owner):
        ports = _owner._ports
        REQUESTS = ports.get_requests()

        try:
            if not REQUESTS.exists():
                return
            for child in REQUESTS.iterdir():
                if not child.is_dir():
                    continue
                sp = child / "status.json"
                if not sp.exists():
                    continue
                try:
                    data = strict_json_load(sp)
                except (OSError, ValueError, TypeError, OverflowError):
                    continue
                if isinstance(data, dict):
                    yield data
        except Exception as recovery_error:
            report_recovery("metod_app.requests.runtime.boundary.101", recovery_error)
            return

    def _find_request_status_for_job(_owner, job_id: str) -> Optional[dict]:
        ports = _owner._ports

        _iter_request_statuses = ports.iter_request_statuses

        jid = str(job_id or "").strip()
        if not jid:
            return None
        parent = jid.split("__mat_")[0] if "__mat_" in jid else jid
        candidates = {jid, parent}
        for st in _iter_request_statuses() or []:
            job = st.get("job") if isinstance(st.get("job"), dict) else {}
            if str(job.get("parentJobId") or "").strip() in candidates:
                return st
            for sj in job.get("subjobs") or []:
                if not isinstance(sj, dict):
                    continue
                if str(sj.get("subjobId") or sj.get("jobId") or "").strip() in candidates:
                    return st
        return None

    def _load_request_payload(_owner, request_id: str) -> dict:
        ports = _owner._ports
        REQUESTS = ports.get_requests()

        try:
            rid = _safe_id(str(request_id or "").strip(), 120)
            if not rid:
                return {}
            fp = REQUESTS / rid / "input" / "submit_payload.json"
            if not fp.exists():
                return {}
            data = strict_json_load(fp)
            return data if isinstance(data, dict) else {}
        except Exception as recovery_error:
            report_recovery("metod_app.requests.runtime.boundary.140", recovery_error)
            return {}

    EXPORTS = (
        "_new_request_id",
        "_linked_subjob_ids",
        "_master_job_id_for",
        "_public_job_family_complete",
        "_iter_request_statuses",
        "_find_request_status_for_job",
        "_load_request_payload",
    )


__all__ = ("RequestRuntime",)
