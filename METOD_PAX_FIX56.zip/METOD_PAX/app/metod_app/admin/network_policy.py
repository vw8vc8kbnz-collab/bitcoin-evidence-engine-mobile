"""One fail-closed parser for operator-managed Admin networks."""

from __future__ import annotations

import ipaddress
from collections.abc import Mapping

Network = ipaddress.IPv4Network | ipaddress.IPv6Network
BROAD_NETWORK_ACKNOWLEDGEMENT = "I_ACCEPT_BROAD_ADMIN_ACCESS"
MAX_NETWORKS = 128


def admin_networks(environment: Mapping[str, str], *, required: bool) -> tuple[Network, ...]:
    raw = environment.get("ADMIN_ALLOWED_NETWORKS", "").strip()
    if not raw:
        if required:
            raise ValueError("ADMIN_ALLOWED_NETWORKS moet je eigen beheer-IP of VPN-netwerk bevatten.")
        return ()
    entries = raw.split(",")
    if len(entries) > MAX_NETWORKS or any(not item.strip() for item in entries):
        raise ValueError("Ongeldige of te lange Admin-netwerklijst.")
    try:
        networks = tuple(ipaddress.ip_network(value.strip(), strict=False) for value in entries)
    except ValueError as error:
        raise ValueError("Admin-netwerklijst bevat een ongeldig IP-adres of CIDR-netwerk.") from error
    broad_confirmed = environment.get("ADMIN_BROAD_NETWORKS_ACKNOWLEDGED") == BROAD_NETWORK_ACKNOWLEDGEMENT
    ipv4 = tuple(ipaddress.collapse_addresses(n for n in networks if isinstance(n, ipaddress.IPv4Network)))
    ipv6 = tuple(ipaddress.collapse_addresses(n for n in networks if isinstance(n, ipaddress.IPv6Network)))
    for version, minimum_prefix, merged in ((4, 16, ipv4), (6, 48, ipv6)):
        if any(network.prefixlen == 0 for network in merged):
            raise ValueError("Admin mag niet voor het volledige internet worden opengesteld.")
        address_bits = 32 if version == 4 else 128
        too_broad = sum(n.num_addresses for n in merged) > 2 ** (address_bits - minimum_prefix)
        if too_broad and not broad_confirmed:
            raise ValueError(
                f"Admin IPv{version}-netwerken zijn samen breder dan /{minimum_prefix}. "
                "Gebruik eigen IP-adressen of een kleiner VPN-netwerk. Een bewuste uitzondering "
                "vereist ADMIN_BROAD_NETWORKS_ACKNOWLEDGED=I_ACCEPT_BROAD_ADMIN_ACCESS."
            )
    return networks
