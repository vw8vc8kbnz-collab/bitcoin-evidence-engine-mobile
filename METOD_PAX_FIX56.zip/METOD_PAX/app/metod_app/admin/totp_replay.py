"""Durable, cross-process consumption of Admin TOTP time steps.

Only a credential fingerprint and its highest accepted counter are stored.
SQLite commits with FULL synchronization before a session can be issued;
its write transaction serializes concurrent attempts across threads/processes.
Storage errors propagate to the controller, which fails authentication closed.
"""

from __future__ import annotations


import os
from pathlib import Path
import re
import sqlite3
import stat


class TotpReplayStore:
    def __init__(self, state_root: Path) -> None:
        self._directory = Path(state_root) / "security"
        self._path = self._directory / "admin_totp.sqlite3"

    def consume(self, credential_fingerprint: str, counter: int) -> bool:
        if not re.fullmatch(r"[a-f0-9]{64}", credential_fingerprint):
            raise ValueError("Invalid credential fingerprint")
        if type(counter) is not int or counter < 0:
            raise ValueError("Invalid TOTP counter")
        self._directory.mkdir(mode=0o700, parents=True, exist_ok=True)
        directory_stat = self._directory.lstat()
        if not stat.S_ISDIR(directory_stat.st_mode) or (
            os.name == "posix" and directory_stat.st_mode & 0o077
        ):
            raise ValueError("Invalid TOTP state directory")
        flags = os.O_CREAT | os.O_RDWR | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_CLOEXEC", 0)
        descriptor = os.open(self._path, flags, 0o600)
        try:
            file_stat = os.fstat(descriptor)
            path_stat = self._path.lstat()
            if (
                not stat.S_ISREG(file_stat.st_mode)
                or (os.name == "posix" and file_stat.st_mode & 0o077)
                or file_stat.st_nlink != 1
                or stat.S_ISLNK(path_stat.st_mode)
                or (file_stat.st_dev, file_stat.st_ino) != (path_stat.st_dev, path_stat.st_ino)
            ):
                raise ValueError("Invalid TOTP state file")
        finally:
            os.close(descriptor)

        connection = sqlite3.connect(str(self._path), timeout=5, isolation_level=None)
        try:
            connection.execute("PRAGMA synchronous = FULL")
            connection.execute("BEGIN IMMEDIATE")
            connection.execute(
                "CREATE TABLE IF NOT EXISTS consumed ("
                "credential TEXT PRIMARY KEY, counter INTEGER NOT NULL CHECK(counter >= 0))"
            )
            row = connection.execute(
                "SELECT counter FROM consumed WHERE credential = ?", (credential_fingerprint,)
            ).fetchone()
            if row is not None and counter <= row[0]:
                connection.rollback()
                return False
            connection.execute(
                "INSERT INTO consumed (credential, counter) VALUES (?, ?) "
                "ON CONFLICT(credential) DO UPDATE SET counter = excluded.counter",
                (credential_fingerprint, counter),
            )
            connection.commit()
            # SQLite persists the transaction and journal directory. Persist
            # our initially created security directory in its state parent too,
            # before issuing the first session after an installation.
            if os.name == "posix":
                for directory in (self._directory, self._directory.parent):
                    flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) | getattr(os, "O_NOFOLLOW", 0)
                    descriptor = os.open(directory, flags)
                    try:
                        os.fsync(descriptor)
                    finally:
                        os.close(descriptor)
            return True
        finally:
            connection.close()
