"""Customer export and durable, replayable erasure of complete request families.

No production document is edited in place: deleting the whole family preserves
integrity rules for all remaining sealed orders. An external deletion journal
must accompany any restore of an older backup.
"""

from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import tempfile
import uuid
import zipfile

from safety_contracts import durable_write_json, fsync_directory, strict_json_load
from .customer_export import customer_export_stream

ROOTS = (
    "requests",
    "jobs",
    "drafts",
    "queue/pending",
    "queue/processing",
    "queue/done",
    "queue/failed",
    "archive/requests",
    "archive/jobs",
    "archive/queue_done",
    "archive/queue_failed",
    "archive/.transactions",
    "index/submission_idempotency",
    "system/job_create_idempotency",
)
ID_RE = re.compile(r"[A-Za-z0-9_-]{1,160}")


class PrivacyConflict(ValueError):
    """The preview is stale or the selected work is still running."""


def _strings(value):
    if isinstance(value, str):
        yield value
    elif isinstance(value, dict):
        for item in value.values():
            yield from _strings(item)
    elif isinstance(value, list):
        for item in value:
            yield from _strings(item)


def _email_matches(value, email):
    if isinstance(value, dict):
        return any(
            (
                str(key).casefold() in {"email", "mail", "customeremail"}
                and str(item).strip().casefold() == email
            )
            or _email_matches(item, email)
            for key, item in value.items()
        )
    return isinstance(value, list) and any(_email_matches(item, email) for item in value)


def _foreign_email(value, email):
    if isinstance(value, dict):
        return any(
            (
                str(key).casefold() in {"email", "mail", "customeremail"}
                and str(item).strip()
                and str(item).strip().casefold() != email
            )
            or _foreign_email(item, email)
            for key, item in value.items()
        )
    return isinstance(value, list) and any(_foreign_email(item, email) for item in value)


class CustomerPrivacyService:
    def __init__(self, state_root, barrier=None, *, ledger=None):
        self.root = Path(state_root).resolve()
        self.barrier = barrier
        self.ledger = Path(
            ledger or os.environ.get("PRIVACY_LEDGER_DIR") or self.root.parent / (self.root.name + "-privacy")
        ).resolve()
        if self.ledger == self.root or self.ledger.is_relative_to(self.root):
            raise ValueError("Privacy deletion journal must be outside the restorable state directory")

    @contextmanager
    def consistent(self):
        with self.barrier.exclusive():
            self.barrier.begin_consistent_snapshot(timeout_seconds=10)
            try:
                yield
            finally:
                self.barrier.end_consistent_snapshot()

    def _safe(self, relative):
        path = self.root / relative
        allowed_parent = any(path.parent == self.root / root for root in ROOTS)
        sharded_claim = path.parent.parent == self.root / "system/job_create_idempotency" and re.fullmatch(
            "[a-f0-9]{2}", path.parent.name
        )
        if not (allowed_parent or sharded_claim):
            raise ValueError("Invalid privacy record path")
        if not ID_RE.fullmatch(path.stem) or path.is_symlink():
            raise ValueError("Unsafe privacy record path")
        if any(
            parent.is_symlink()
            for parent in path.parents
            if parent != self.root and parent.is_relative_to(self.root)
        ):
            raise ValueError("Symlink in personal-data record ancestry")
        if not path.resolve().is_relative_to(self.root):
            raise ValueError("Privacy path escapes the state directory")
        return path

    @staticmethod
    def _documents(path):
        # All current customer-bearing records live in these bounded JSON
        # documents; production labels/reports are included by family ownership.
        if path.is_file():
            if path.suffix == ".json":
                yield strict_json_load(path)
            return
        for name in (
            "status.json",
            "input/job.json",
            "input/submit_payload.json",
            "output/links.json",
            ".archive_meta.json",
        ):
            file = path / name
            if file.is_file():
                yield strict_json_load(file)

    def _records(self):
        for root in ROOTS:
            folder = self.root / root
            if not folder.exists():
                continue
            if folder.is_symlink():
                raise ValueError("Symlink in personal-data storage")
            candidates = sorted(folder.iterdir())
            if root == "system/job_create_idempotency":
                candidates = [
                    item
                    for child in candidates
                    for item in (
                        sorted(child.iterdir()) if child.is_dir() and not child.is_symlink() else [child]
                    )
                ]
            for path in candidates:
                if path.name.startswith(".") or (path.is_file() and path.suffix != ".json"):
                    continue
                relative = path.relative_to(self.root).as_posix()
                self._safe(relative)
                yield relative, tuple(self._documents(path))

    def inventory(self, email):
        email = str(email or "").strip().casefold()
        if len(email) > 320 or not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
            raise ValueError("Vul een geldig e-mailadres in.")
        records = list(self._records())
        selected = {path for path, docs in records if any(_email_matches(doc, email) for doc in docs)}
        identifiers = set()
        # Resolve the closure of request -> master -> material jobs -> claims.
        # Never follow arbitrary filesystem paths from a stored document.
        for _ in range(8):
            previous = (len(selected), len(identifiers))
            for path, docs in records:
                strings = {s for doc in docs for s in _strings(doc) if ID_RE.fullmatch(s)}
                name = Path(path).stem
                master = name.split("__mat_", 1)[0]
                if path in selected or name in identifiers or master in identifiers or strings & identifiers:
                    selected.add(path)
                    if path.startswith(("requests/", "jobs/", "archive/requests/", "archive/jobs/")):
                        identifiers.add(name)
                    for doc in docs:
                        if isinstance(doc, dict):
                            job = doc.get("job") if isinstance(doc.get("job"), dict) else {}
                            for value in (
                                doc.get("requestId"),
                                doc.get("jobId"),
                                doc.get("parentJobId"),
                                job.get("parentJobId"),
                            ):
                                if isinstance(value, str) and ID_RE.fullmatch(value):
                                    identifiers.add(value)
                            identifiers.update(
                                s for s in _strings(job.get("subjobs", [])) if ID_RE.fullmatch(s)
                            )
            if previous == (len(selected), len(identifiers)):
                break
        else:
            raise PrivacyConflict("Klantkoppelingen zijn te complex; controleer de opgeslagen aanvraag.")
        for path, docs in records:
            if path in selected and any(_foreign_email(doc, email) for doc in docs):
                raise PrivacyConflict(
                    "Deze berekening is aan meerdere e-mailadressen gekoppeld. Controleer eerst de klantkoppeling."
                )
        files = []
        for relative in sorted(selected):
            path = self._safe(relative)
            for item in sorted(path.rglob("*")) if path.is_dir() else [path]:
                if item.is_symlink():
                    raise ValueError("Symlink in personal-data record")
                if item.is_file():
                    stat = item.stat()
                    files.append((item.relative_to(self.root).as_posix(), stat.st_size, stat.st_mtime_ns))
        revision = hashlib.sha256(json.dumps(files, separators=(",", ":")).encode()).hexdigest()
        return {
            "paths": sorted(selected),
            "identifiers": sorted(identifiers),
            "revision": revision,
            "fileCount": len(files),
            "bytes": sum(item[1] for item in files),
            "requestCount": sum(path.startswith(("requests/", "archive/requests/")) for path in selected),
        }

    @staticmethod
    def public_preview(inventory):
        return {key: inventory[key] for key in ("revision", "fileCount", "bytes", "requestCount")}

    def export_customer(self, inventory, email):
        if inventory["bytes"] > 512 * 1024 * 1024:
            raise ValueError("Export is groter dan 512 MB; exporteer deze klant via de beheerprocedure.")
        families = [self._safe(relative) for relative in inventory["paths"]]
        return customer_export_stream(self.root, families, str(email).strip().casefold())

    def export_internal(self, inventory):
        if inventory["bytes"] > 512 * 1024 * 1024:
            raise ValueError("Export is groter dan 512 MB; exporteer deze klant via de beheerprocedure.")
        stream = tempfile.TemporaryFile()
        try:
            with zipfile.ZipFile(stream, "w", zipfile.ZIP_DEFLATED) as archive:
                for relative in inventory["paths"]:
                    path = self._safe(relative)
                    for item in sorted(path.rglob("*")) if path.is_dir() else [path]:
                        if item.is_file() and not item.is_symlink():
                            archive.write(item, item.relative_to(self.root).as_posix())
                archive.writestr(
                    "LEESMIJ.txt",
                    "INTERNE BEHEEREXPORT — NIET DOORSTUREN AAN DE KLANT.\nDit archief bevat interne productie-, toegangs- en diagnosebestanden. Gebruik Klantexport voor het leesbare klantoverzicht. Beveilig deze interne kopie en verwijder haar na afhandeling.\n",
                )
            stream.seek(0)
            return stream
        except BaseException:
            stream.close()
            raise

    def erase(self, inventory, actor):
        if not inventory["paths"]:
            raise ValueError("Geen klantgegevens gevonden.")
        self.ledger.mkdir(mode=0o700, parents=True, exist_ok=True)
        record = {
            "schemaVersion": 1,
            "erasureId": uuid.uuid4().hex,
            "createdAt": datetime.now(timezone.utc).isoformat(),
            "actor": str(actor)[:80],
            "paths": inventory["paths"],
            "identifiers": inventory["identifiers"],
        }
        journal = self.ledger / (record["erasureId"] + ".json")
        durable_write_json(journal, record)
        journal.chmod(0o600)
        self.apply(record)
        return record["erasureId"]

    def apply(self, record):
        if record.get("schemaVersion") != 1:
            raise ValueError("Unsupported privacy journal schema")
        # Validate the whole record before performing the first deletion.
        relatives = set(record["paths"])
        paths = [self._safe(relative) for relative in relatives]
        ids = set(record["identifiers"])
        if not all(isinstance(value, str) and ID_RE.fullmatch(value) for value in ids):
            raise ValueError("Invalid privacy journal identifier")
        # An older backup can contain an active request which was archived by
        # the time it was erased. Resolve stable ownership again before deleting.
        records = list(self._records())
        for _ in range(8):
            previous = (len(relatives), len(ids))
            for relative, documents in records:
                name = Path(relative).stem
                master = name.split("__mat_", 1)[0]
                values = {value for doc in documents for value in _strings(doc)}
                if relative in relatives or name in ids or master in ids or values & ids:
                    relatives.add(relative)
                    if relative.startswith(("jobs/", "requests/", "archive/jobs/", "archive/requests/")):
                        ids.add(name)
                    for document in documents:
                        if isinstance(document, dict):
                            for key in ("requestId", "jobId", "parentJobId"):
                                value = document.get(key)
                                if isinstance(value, str) and ID_RE.fullmatch(value):
                                    ids.add(value)
            if previous == (len(relatives), len(ids)):
                break
        else:
            raise PrivacyConflict("Deletion ownership could not be resolved safely")
        paths = [self._safe(relative) for relative in sorted(relatives)]
        for path in paths:
            if path.is_dir():
                shutil.rmtree(path)
            else:
                path.unlink(missing_ok=True)
            if path.parent.exists():
                fsync_directory(path.parent)
        # The request index is append-only history; remove every row of an
        # erased family, including historical name/address projections.
        index = self.root / "index/requests_index.jsonl"
        if index.exists():
            kept = [
                line for line in index.read_text().splitlines() if not (set(_strings(json.loads(line))) & ids)
            ]
            from safety_contracts import durable_write_bytes

            durable_write_bytes(index, ("\n".join(kept) + ("\n" if kept else "")).encode())

    def replay(self, *, restored_with_current_ledger=False):
        """Run before serving after a crash, and against a restored backup."""
        marker = self.root / "system/restore_requires_privacy_replay.json"
        if marker.exists() and not restored_with_current_ledger:
            raise ValueError(
                "Restored state requires explicit replay with the current external privacy journal"
            )
        if restored_with_current_ledger and not self.ledger.is_dir():
            raise ValueError("Current external privacy journal directory is required")
        if self.ledger.exists():
            for journal in sorted(self.ledger.glob("*.json")):
                if journal.is_symlink():
                    raise ValueError("Unsafe privacy journal")
                self.apply(strict_json_load(journal))
        if restored_with_current_ledger:
            marker.unlink(missing_ok=True)
