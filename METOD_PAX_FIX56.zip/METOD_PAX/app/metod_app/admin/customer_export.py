"""Customer-facing export projections: explicit fields, never raw job files.

Ownership and the consistent snapshot are established by CustomerPrivacyService.
This module reads only named customer documents from those authorized families.
The internal archive is deliberately a different export operation.
"""

from __future__ import annotations

from datetime import datetime, timezone
import csv
import json
import math
from pathlib import Path
import tempfile
import zipfile

from safety_contracts import strict_json_load
from metod_app.admin.customer_export_presentation import readable_date, readable_status_lines

CUSTOMER_FIELDS = {
    "name": "Naam",
    "fullName": "Volledige naam",
    "firstName": "Voornaam",
    "lastName": "Achternaam",
    "company": "Bedrijf",
    "companyName": "Bedrijfsnaam",
    "email": "E-mail",
    "mail": "E-mail",
    "phone": "Telefoon",
    "tel": "Telefoon",
    "billingAddress": "Factuuradres",
    "invoiceAddress": "Factuuradres",
    "address": "Adres",
    "houseNumber": "Huisnummer",
    "postcode": "Postcode",
    "postalCode": "Postcode",
    "city": "Woonplaats",
    "country": "Land",
    "address2": "Adresaanvulling",
    "shippingSameAsBilling": "Bezorgadres gelijk aan factuuradres",
    "shippingAddress": "Bezorgadres",
    "shippingHouseNumber": "Bezorghuisnummer",
    "shippingPostcode": "Bezorgpostcode",
    "shippingCity": "Bezorgplaats",
    "shippingCountry": "Bezorgland",
    "note": "Klantopmerking",
}
PRICE_FIELDS = {
    "currency": "Valuta",
    "materialsTotal": "Plaatmateriaal excl. btw",
    "edgeBandTotal": "Kantenband excl. btw",
    "cncTotal": "CNC excl. btw",
    "drawingTotal": "Tekenen excl. btw",
    "transportTotal": "Transport excl. btw",
    "subtotalExVat": "Subtotaal excl. btw",
    "vatAmount": "Btw",
    "totalInclVat": "Totaal incl. btw",
    "sheetCount": "Aantal platen",
}
ORDER_FIELDS = (
    "displayName",
    "name",
    "label",
    "type",
    "width",
    "height",
    "widthMm",
    "heightMm",
    "w",
    "h",
    "qty",
    "quantity",
    "materialCode",
    "materialName",
    "thicknessMm",
    "grainEnabled",
    "hingeSide",
    "extTopMm",
    "extBottomMm",
)


def fields(value, allowed):
    """Project scalar data only; arbitrary nested fields cannot enter the export."""
    if not isinstance(value, dict):
        return {}
    return {
        key: child
        for key in allowed
        if (child := value.get(key)) is not None
        and isinstance(child, (str, bool, int, float))
        and (not isinstance(child, float) or math.isfinite(child))
    }


def checked_file(root: Path, family: Path, name: str) -> Path | None:
    path = family / name if family.is_dir() else family
    if not path.exists():
        return None
    if (
        path.is_symlink()
        or not path.resolve().is_relative_to(root)
        or any(p.is_symlink() for p in path.parents if p != root and p.is_relative_to(root))
    ):
        raise ValueError("Onveilig pad in klantgegevens.")
    if path.stat().st_size > 16 * 1024 * 1024:
        raise ValueError("Klantdocument is te groot voor een veilige export.")
    return path


def document(root: Path, family: Path, name: str) -> dict:
    path = checked_file(root, family, name)
    if path is None:
        return {}
    value = strict_json_load(path)
    if not isinstance(value, dict):
        raise ValueError("Klantdocument heeft een ongeldig formaat.")
    return value


def order_items(payload: dict) -> list[dict]:
    result = []
    for name in ("cart", "panels", "extraPanels"):
        rows = payload.get(name)
        if isinstance(rows, list):
            result.extend(item for row in rows if (item := fields(row, ORDER_FIELDS)))
    return result


CSV_PANEL_FIELDS = {
    "PanelName": "name",
    "Qty": "qty",
    "LengthMm": "heightMm",
    "WidthMm": "widthMm",
    "ThicknessMm": "thicknessMm",
    "MaterialCode": "materialCode",
    "GrainGroup": "grainGroup",
    "RotationAllowed": "rotationAllowed",
    "H1": "edgeTop",
    "H2": "edgeBottom",
    "W1": "edgeLeft",
    "W2": "edgeRight",
}
PANEL_LABELS = {
    "name": "Naam",
    "displayName": "Naam",
    "label": "Label",
    "type": "Type",
    "qty": "Aantal",
    "quantity": "Aantal",
    "width": "Breedte",
    "widthMm": "Breedte (mm)",
    "height": "Hoogte",
    "heightMm": "Hoogte (mm)",
    "w": "Breedte",
    "h": "Hoogte",
    "thicknessMm": "Dikte (mm)",
    "materialCode": "Materiaalcode",
    "materialName": "Materiaal",
    "grainEnabled": "Nerf",
    "grainGroup": "Nerfgroep",
    "rotationAllowed": "Draaien toegestaan",
    "hingeSide": "Scharnierzijde",
    "extTopMm": "Verlenging boven (mm)",
    "extBottomMm": "Verlenging onder (mm)",
    "edgeTop": "Kantenband boven",
    "edgeBottom": "Kantenband onder",
    "edgeLeft": "Kantenband links",
    "edgeRight": "Kantenband rechts",
}


def saved_panels(root: Path, family: Path) -> list[dict]:
    if not family.is_dir():
        return []
    path = checked_file(root, family, "input/panels.csv")
    if path is None:
        return []
    with path.open(encoding="utf-8-sig", newline="") as stream:
        rows = csv.DictReader(stream, delimiter=";")
        if not {"PanelName", "Qty", "LengthMm", "WidthMm"}.issubset(rows.fieldnames or []):
            raise ValueError("Opgeslagen paneellijst heeft een ongeldig formaat.")
        return [
            {
                target: row[source]
                for source, target in CSV_PANEL_FIELDS.items()
                if row.get(source) not in (None, "")
            }
            for row in rows
        ]


def display_value(value):
    if isinstance(value, bool):
        return "ja" if value else "nee"
    return str(value)


def customer_lines(customer: dict) -> list[str]:
    seen = set()
    lines = []
    has_name = bool(customer.get("name") or customer.get("fullName"))
    for field, value in customer.items():
        if value == "" or field == "note" or (has_name and field in {"firstName", "lastName"}):
            continue
        label = "Naam" if field in {"name", "fullName"} else CUSTOMER_FIELDS[field]
        pair = (label, display_value(value))
        if pair not in seen:
            lines.append(f"{label}: {pair[1]}")
            seen.add(pair)
    return lines


def family_record(root: Path, family: Path, *, archived: bool) -> dict:
    status = document(root, family, "status.json")
    job = document(root, family, "input/job.json") if family.is_dir() else {}
    submitted = document(root, family, "input/submit_payload.json") if family.is_dir() else {}
    customer = {}
    notes = []
    for document_value in (job, submitted, status):
        # Historical drafts can wrap the same canonical payload. Read only this
        # known envelope and checkout fields, never arbitrary recursive content.
        sources = [document_value]
        if isinstance(document_value.get("payload"), dict):
            sources.insert(0, document_value["payload"])
        for source in sources:
            checkout = source.get("checkout") if isinstance(source.get("checkout"), dict) else {}
            customer.update(fields(checkout.get("customer"), CUSTOMER_FIELDS))
            customer.update(fields(source.get("customer"), CUSTOMER_FIELDS))
            for note in (
                checkout.get("note"),
                fields(checkout.get("customer"), CUSTOMER_FIELDS).get("note"),
                source.get("note"),
                fields(source.get("customer"), CUSTOMER_FIELDS).get("note"),
            ):
                if isinstance(note, str) and note and note not in notes:
                    notes.append(note)
    saved_price = document(root, family, "output/calculation_pricing.json") if family.is_dir() else {}
    # Only server-stored prices; client-supplied totals/quote objects are never interpreted as a quote.
    pricing = fields(saved_price.get("summary") or status.get("pricingSummary"), PRICE_FIELDS)
    references = fields(status.get("job"), ("parentJobId",))
    references.update(fields(status, ("jobId", "parentJobId")))
    return {
        "reference": family.stem,
        "archived": archived,
        "dates": fields({**job, **status}, ("createdAt", "updatedAt")),
        "status": fields(status, ("publicStatus", "publicStatusLabel", "quoteStatus")),
        "customer": customer,
        "notes": notes,
        "calculationReferences": sorted(
            {value for value in references.values() if isinstance(value, str) and value.strip()}
        ),
        "items": saved_panels(root, family)
        or order_items(
            submitted or job or (status.get("payload") if isinstance(status.get("payload"), dict) else status)
        ),
        "pricing": pricing,
    }


def project_customer_export(root: Path, families: list[Path], email: str) -> dict:
    groups = {"requests": [], "calculations": [], "drafts": []}
    for family in families:
        parts = family.relative_to(root).parts
        archived = parts[0] == "archive"
        kind = parts[1] if archived else parts[0]
        group = {"requests": "requests", "jobs": "calculations", "drafts": "drafts"}.get(kind)
        if group:
            groups[group].append(family_record(root, family, archived=archived))
    return {
        "schema": "metod.customer-export/1",
        "generatedAt": datetime.now(timezone.utc).isoformat(),
        "email": email,
        **groups,
    }


def readable_export(data: dict) -> str:
    lines = [
        "ADZAAGT — UW OPGESLAGEN KLANTGEGEVENS",
        "",
        f"E-mailadres: {data['email']}",
        f"Exportdatum: {readable_date(data['generatedAt'])}",
        "Dit overzicht bevat uw opgeslagen aanvragen, berekeningen en concepten.",
        "Prijzen zijn historische vastgelegde bedragen, geen nieuwe offerte.",
        "",
    ]
    for key, title in (("requests", "AANVRAGEN"), ("calculations", "BEREKENINGEN"), ("drafts", "CONCEPTEN")):
        lines.extend([title, "=" * len(title)])
        if not data[key]:
            lines.append("Geen opgeslagen gegevens in deze categorie.")
        for record in data[key]:
            lines.extend(
                [
                    "",
                    f"Referentie: {record['reference']}",
                    f"Gearchiveerd: {'ja' if record['archived'] else 'nee'}",
                ]
            )
            for label, value in record["dates"].items():
                lines.append(
                    f"{'Ontvangen' if label == 'createdAt' else 'Bijgewerkt'}: {readable_date(value)}"
                )
            lines.extend(readable_status_lines(record["status"]))
            lines.extend(customer_lines(record["customer"]))
            lines.extend(f"Opmerking: {note}" for note in record["notes"])
            if record["calculationReferences"]:
                lines.append("Bijbehorende berekeningen: " + ", ".join(record["calculationReferences"]))
            for field, value in record["pricing"].items():
                if field not in {"currency", "sheetCount"} and isinstance(value, (int, float)):
                    value = f"{value:,.2f}".translate(str.maketrans({",": ".", ".": ","}))
                lines.append(f"{PRICE_FIELDS[field]}: {value}")
            for number, item in enumerate(record["items"], 1):
                lines.append(
                    f"Paneel {number}: "
                    + "; ".join(
                        f"{PANEL_LABELS.get(key, key)}: {display_value(value)}" for key, value in item.items()
                    )
                )
        lines.append("")
    return "\n".join(lines) + "\n"


def customer_export_stream(root: Path, families: list[Path], email: str):
    data = project_customer_export(root, families, email)
    stream = tempfile.TemporaryFile()
    try:
        with zipfile.ZipFile(stream, "w", zipfile.ZIP_DEFLATED) as archive:
            archive.writestr(
                "klantgegevens.json", json.dumps(data, indent=2, ensure_ascii=False, allow_nan=False) + "\n"
            )
            archive.writestr("KLANTGEGEVENS.txt", readable_export(data))
        stream.seek(0)
        return stream
    except BaseException:
        stream.close()
        raise
