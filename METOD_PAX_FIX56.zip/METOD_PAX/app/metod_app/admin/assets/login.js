(function () {
  const form = document.getElementById("loginForm");
  const btn = document.getElementById("btn");
  const msg = document.getElementById("msg");
  const pass = document.getElementById("pass");
  function setMsg(t) {
    msg.textContent = t || "";
  }
  try {
    sessionStorage.clear();
  } catch (e) {
    ToolAErrors.recover("metod.app.admin.assets.login.js.2", e, [
      "SecurityError",
      "QuotaExceededError",
      "SyntaxError",
    ]);
  }
  form.addEventListener("submit", async function (ev) {
    ev.preventDefault();
    setMsg("");
    const username = (document.getElementById("user").value || "admin").trim();
    const password = pass.value || "";
    if (!password) {
      setMsg("Vul je wachtwoord in.");
      pass.focus();
      return;
    }
    btn.disabled = true;
    btn.textContent = "Controleren...";
    try {
      const otp = (document.getElementById("otp").value || "").replace(/\s+/g, "");
      const r = await fetch("/api/admin/login", {
        method: "POST",
        credentials: "same-origin",
        cache: "no-store",
        headers: {
          "Content-Type": "application/json",
          "X-Requested-With": "fetch",
        },
        body: JSON.stringify({ username, password, otp }),
      });
      let j = {};
      j = await r.json();
      if (!r.ok || !j.ok) {
        throw new Error(j.error || "HTTP " + r.status);
      }
      // Safari/iOS can set the HttpOnly cookie only after the current JS turn.
      // Do not immediately call /api/admin/jobs here; redirect and let the next page load use the cookie.
      window.location.href = "/admin/";
    } catch (e) {
      setMsg("Login mislukt. Controleer gebruikersnaam/wachtwoord.");
      btn.disabled = false;
      btn.textContent = "Inloggen";
      pass.focus();
      pass.select();
    }
  });
})();
