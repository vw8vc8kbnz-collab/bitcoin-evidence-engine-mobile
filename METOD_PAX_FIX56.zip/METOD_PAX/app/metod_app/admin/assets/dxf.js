// DXF Admin: bounded requests, explicit feedback and category-scoped rendering.
let dxfListRequest = 0;
let dxfMutationBusy = false;

async function dxfRequest(url, options = {}) {
  if (String(options.method || "GET").toUpperCase() !== "GET") ToolAErrors.assertHealthy();
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 30000);
  try {
    const r = await fetch(url, {
      ...options,
      cache: "no-store",
      credentials: "same-origin",
      signal: controller.signal,
    });
    let json;
    try {
      json = await r.json();
    } catch (_) {
      throw new Error(
        "De server gaf geen leesbaar antwoord. Ververs de lijst om de opgeslagen status te controleren.",
      );
    }
    if (!r.ok || !json || json.ok !== true) {
      throw new Error(
        r.status === 401
          ? "Je sessie is verlopen. Log opnieuw in."
          : json?.error || `HTTP ${r.status}`,
      );
    }
    return { ok: true, json };
  } catch (error) {
    if (error?.name === "AbortError")
      throw new Error(
        "De aanvraag duurde te lang. Ververs de lijst om te controleren of de wijziging is opgeslagen.",
      );
    throw error;
  } finally {
    clearTimeout(timer);
  }
}
async function _postJson(url, body) {
  return dxfRequest(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
}
async function _getJson(url) {
  return dxfRequest(url);
}
function esc(s) {
  return String(s).replace(
    /[&<>"']/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c],
  );
}
function dxfStatus(text) {
  const status = document.getElementById("dxfStatus");
  if (status) status.textContent = text;
}
async function dxfWithMutation(action) {
  if (dxfMutationBusy) return;
  dxfMutationBusy = true;
  const buttons = Array.from(
    document.querySelectorAll('#dxfUploadBtn, #dxfCreateCatBtn, [data-act="delete-dxf"]'),
  );
  buttons.forEach((button) => {
    button.disabled = true;
  });
  try {
    await action();
  } catch (error) {
    dxfStatus(
      "Fout: " +
        (error?.message || "Aanvraag mislukt. Ververs om de opgeslagen status te controleren."),
    );
  } finally {
    dxfMutationBusy = false;
    document
      .querySelectorAll('#dxfUploadBtn, #dxfCreateCatBtn, [data-act="delete-dxf"]')
      .forEach((button) => {
        button.disabled = false;
      });
  }
}
async function dxf_load_categories() {
  const sel = document.getElementById("dxfCatSel");
  if (!sel) return;
  const { json } = await _getJson("/api/admin/dxf/categories");
  if (!Array.isArray(json.categories) || !json.categories.every((c) => typeof c === "string"))
    throw new Error("Ongeldige categorielijst.");
  const prev = sel.value;
  sel.innerHTML = "";
  json.categories.forEach((c) => {
    const option = document.createElement("option");
    option.value = c;
    option.textContent = c;
    sel.appendChild(option);
  });
  if (json.categories.includes(prev)) sel.value = prev;
}
async function dxf_load_files() {
  const sel = document.getElementById("dxfCatSel");
  const box = document.getElementById("dxfFiles");
  if (!sel || !box) return;
  const cat = sel.value;
  const request = ++dxfListRequest;
  box.textContent = cat ? "Bestanden laden…" : "Geen categorie geselecteerd.";
  if (!cat) return;
  try {
    const { json } = await _getJson("/api/admin/dxf/list?category=" + encodeURIComponent(cat));
    if (request !== dxfListRequest || sel.value !== cat) return;
    if (!Array.isArray(json.files) || !json.files.every((name) => typeof name === "string"))
      throw new Error("Ongeldige bestandenlijst.");
    if (!json.files.length) {
      box.textContent = "Geen DXF bestanden in deze categorie.";
      return;
    }
    box.innerHTML = json.files
      .map(
        (fn) =>
          `<div class="admin-display-flex-justify-content-space-between"><div class="admin-flex-1-1-170px-min-width-0">${esc(fn)}</div><button class="btn danger" type="button" data-act="delete-dxf" data-cat="${esc(encodeURIComponent(cat))}" data-file="${esc(encodeURIComponent(fn))}">Verwijder</button></div>`,
      )
      .join("");
    box.querySelectorAll('[data-act="delete-dxf"]').forEach((button) => {
      button.disabled = dxfMutationBusy;
      button.addEventListener("click", () =>
        dxf_delete_file(
          decodeURIComponent(button.getAttribute("data-cat")),
          decodeURIComponent(button.getAttribute("data-file")),
        ),
      );
    });
  } catch (error) {
    if (request !== dxfListRequest || sel.value !== cat) return;
    box.textContent = "Bestanden konden niet worden geladen.";
    dxfStatus("Fout: " + error.message);
  }
}
async function dxf_create_category() {
  return dxfWithMutation(async () => {
    const input = document.getElementById("dxfNewCat");
    const name = input?.value.trim();
    if (!name) throw new Error("Vul een categorienaam in.");
    dxfStatus("Categorie aanmaken…");
    const { json } = await _postJson("/api/admin/dxf/create_category", {
      category: name,
    });
    input.value = "";
    await dxf_load_categories();
    document.getElementById("dxfCatSel").value = json.category;
    await dxf_load_files();
    dxfStatus("Categorie aangemaakt: " + json.category);
  });
}
async function dxf_upload_file() {
  return dxfWithMutation(async () => {
    const cat = document.getElementById("dxfCatSel")?.value;
    const input = document.getElementById("dxfFileInput");
    const file = input?.files?.[0];
    if (!cat) throw new Error("Selecteer eerst een categorie.");
    if (!file) throw new Error("Kies eerst een DXF bestand.");
    if (file.size === 0) throw new Error("Het gekozen bestand is leeg.");
    if (file.size > 10 * 1024 * 1024)
      throw new Error("Het DXF-bestand mag maximaal 10 MB groot zijn.");
    if (!/\.dxf$/i.test(file.name)) throw new Error("Kies een bestand met de extensie .dxf.");
    dxfStatus("DXF uploaden…");
    const bytes = new Uint8Array(await file.arrayBuffer());
    let binary = "";
    for (let i = 0; i < bytes.length; i += 0x8000)
      binary += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    const { json } = await _postJson("/api/admin/dxf/upload", {
      category: cat,
      filename: file.name,
      dataBase64: btoa(binary),
    });
    input.value = "";
    await dxf_load_files();
    dxfStatus(
      "Upload opgeslagen: " +
        json.filename +
        " (" +
        json.category +
        "). Herlaad geopende configurators voordat je met de gewijzigde DXF-bibliotheek verdergaat.",
    );
  });
}
async function dxf_delete_file(cat, filename) {
  if (dxfMutationBusy || !confirm("Verwijderen: " + filename + " ?")) return;
  return dxfWithMutation(async () => {
    await _postJson("/api/admin/dxf/delete", { category: cat, filename });
    await dxf_load_files();
    dxfStatus("Verwijderd: " + filename);
  });
}
document.addEventListener("DOMContentLoaded", () => {
  const refresh = async () => {
    try {
      await dxf_load_categories();
      await dxf_load_files();
    } catch (error) {
      dxfStatus("Fout: " + error.message);
    }
  };
  document.getElementById("dxfRefreshBtn")?.addEventListener("click", refresh);
  document.getElementById("dxfCreateCatBtn")?.addEventListener("click", dxf_create_category);
  document.getElementById("dxfUploadBtn")?.addEventListener("click", dxf_upload_file);
  document.getElementById("dxfCatSel")?.addEventListener("change", () => {
    dxfStatus("");
    dxf_load_files();
  });
  refresh();
});
