/* Material filter editor: independent presentation owner, all writes revision-bound. */
(() => {
  "use strict";
  const el = (id) => document.getElementById(id);
  if (!el("filterControls")) return;
  const esc = (value) =>
    String(value ?? "").replace(
      /[&<>"']/g,
      (c) =>
        ({
          "&": "&amp;",
          "<": "&lt;",
          ">": "&gt;",
          '"': "&quot;",
          "'": "&#39;",
        })[c],
    );
  let view = null,
    busy = false,
    stale = false,
    page = 0,
    deleting = "";
  const selected = new Set(),
    pageSize = 40;
  const axisId = () => el("filterAxis").value;
  const axis = () => view?.axes.find((a) => a.id === axisId());
  const title = (gid) => axis()?.groups.find((g) => g.id === gid)?.label || "Onbekend";
  const message = (text) => {
    el("filterStatus").textContent = text;
  };
  function enable() {
    el("filterControls").disabled = busy || stale || !view;
    el("filterReload").disabled = busy;
    el("filterAssign").disabled = !selected.size;
    el("filterReset").disabled = !selected.size;
    el("filterDeleteConfirm").disabled = busy || stale;
    el("filterDeleteCancel").disabled = busy;
  }
  function filtered() {
    const words = el("filterSearch")
      .value.trim()
      .toLocaleLowerCase("nl")
      .split(/\s+/)
      .filter(Boolean);
    const source = el("filterSource").value,
      aid = axisId();
    return (view?.records || []).filter(
      (r) =>
        (!source || r.groups[aid] === source) &&
        words.every((w) => `${r.publicName} ${r.brand}`.toLocaleLowerCase("nl").includes(w)),
    );
  }
  function selectOptions(node, groups, allLabel) {
    const value = node.value;
    node.innerHTML =
      (allLabel ? `<option value="">${esc(allLabel)}</option>` : "") +
      groups
        .map((g) => `<option value="${esc(g.id)}">${esc(g.label)} (${g.count})</option>`)
        .join("");
    if (groups.some((g) => g.id === value) || (!value && allLabel)) node.value = value;
  }
  function renderRows() {
    if (!view) return;
    const rows = filtered(),
      aid = axisId();
    page = Math.max(0, Math.min(page, Math.ceil(rows.length / pageSize) - 1));
    el("filterMaterialList").innerHTML =
      rows
        .slice(page * pageSize, (page + 1) * pageSize)
        .map(
          (r) =>
            `<label class="filterMaterial"><input type="checkbox" data-filter-material="${esc(r.publicMaterialId)}" ${selected.has(r.publicMaterialId) ? "checked" : ""}><span><strong>${esc(r.publicName)}</strong><small>${esc(r.brand)} · ${esc(title(r.groups[aid]))} · ${r.overridden[aid] ? "Handmatig" : "Automatisch"}</small></span></label>`,
        )
        .join("") || '<p class="muted">Geen materialen gevonden.</p>';
    el("filterCount").textContent = `${rows.length} materialen`;
    el("filterSelected").textContent = `${selected.size} geselecteerd`;
    el("filterPage").textContent = rows.length
      ? `Pagina ${page + 1} van ${Math.ceil(rows.length / pageSize)}`
      : "Geen resultaten";
    el("filterPrevious").disabled = page === 0;
    el("filterNext").disabled = (page + 1) * pageSize >= rows.length;
    enable();
  }
  function render() {
    const groups = axis().groups;
    el("filterGroupList").innerHTML = groups
      .map(
        (g, i) =>
          `<div class="filterGroup" data-filter-group="${esc(g.id)}"><label>Groepsnaam<input data-group-name value="${esc(g.label)}" maxlength="60" aria-label="Naam van ${esc(g.label)}"></label><small>${g.count} materialen</small><div class="filterGroupActions"><button type="button" class="btn secondary" data-group-action="rename">Opslaan</button><button type="button" class="btn secondary" data-group-action="up" aria-label="${esc(g.label)} omhoog" ${i === 0 ? "disabled" : ""}>↑</button><button type="button" class="btn secondary" data-group-action="down" aria-label="${esc(g.label)} omlaag" ${i === groups.length - 1 ? "disabled" : ""}>↓</button><button type="button" class="btn secondary" data-group-action="delete" ${groups.length === 1 ? "disabled" : ""}>Verwijderen</button></div></div>`,
      )
      .join("");
    selectOptions(el("filterSource"), groups, "Alle groepen");
    selectOptions(el("filterTarget"), groups);
    renderRows();
  }
  async function request(operation) {
    if (operation) ToolAErrors.assertHealthy();
    if (busy || (operation && (stale || !view))) return false;
    busy = true;
    enable();
    message(operation ? "Wijziging opslaan…" : "Indeling laden…");
    const controller = new AbortController(),
      timer = setTimeout(() => controller.abort(), 20000);
    try {
      const response = await fetch("/api/admin/materials/filters", {
        method: operation ? "POST" : "GET",
        credentials: "same-origin",
        cache: "no-store",
        signal: controller.signal,
        headers: {
          Accept: "application/json",
          ...(operation ? { "Content-Type": "application/json" } : {}),
        },
        ...(operation
          ? {
              body: JSON.stringify({
                ...operation,
                axis: axisId(),
                revision: view.revision,
              }),
            }
          : {}),
      });
      if (response.redirected) throw new Error("Je sessie is verlopen. Open Admin opnieuw.");
      const data = await response.json();
      if (!response.ok || data.ok !== true)
        throw new Error(data.error || `Opslaan mislukt (HTTP ${response.status}).`);
      if (
        !Array.isArray(data.axes) ||
        !Array.isArray(data.records) ||
        !/^[a-f0-9]{64}$/.test(data.revision)
      )
        throw new Error("Onvolledige indeling ontvangen.");
      view = data;
      stale = false;
      const available = new Set(view.records.map((r) => r.publicMaterialId));
      for (const pid of selected) if (!available.has(pid)) selected.delete(pid);
      render();
      message(
        operation
          ? "Opgeslagen. De decorbibliotheek gebruikt deze indeling na verversen."
          : "Actuele indeling geladen.",
      );
      return true;
    } catch (error) {
      stale = true;
      message(
        (controller.signal.aborted ? "De server reageerde niet op tijd." : error.message) +
          " Klik op Herladen om de opgeslagen indeling te controleren.",
      );
      return false;
    } finally {
      clearTimeout(timer);
      busy = false;
      enable();
    }
  }
  el("filterAdminNav").addEventListener("click", () => {
    if (!view) request();
  });
  el("filterReload").addEventListener("click", () => request());
  el("filterAxis").addEventListener("change", () => {
    page = 0;
    selected.clear();
    el("filterSource").value = "";
    render();
  });
  el("filterSearch").addEventListener("input", () => {
    page = 0;
    renderRows();
  });
  el("filterSource").addEventListener("change", () => {
    page = 0;
    renderRows();
  });
  el("filterMaterialList").addEventListener("change", (event) => {
    const pid = event.target.dataset.filterMaterial;
    if (!pid) return;
    if (event.target.checked) selected.add(pid);
    else selected.delete(pid);
    renderRows();
  });
  el("filterSelectAll").addEventListener("click", () => {
    const rows = filtered();
    if (new Set([...selected, ...rows.map((r) => r.publicMaterialId)]).size > 1000) {
      message("Selecteer maximaal 1000 materialen per bewerking. Verfijn je zoekopdracht.");
      return;
    }
    rows.forEach((r) => selected.add(r.publicMaterialId));
    renderRows();
  });
  el("filterClear").addEventListener("click", () => {
    selected.clear();
    renderRows();
  });
  el("filterPrevious").addEventListener("click", () => {
    page--;
    renderRows();
  });
  el("filterNext").addEventListener("click", () => {
    page++;
    renderRows();
  });
  el("filterAssign").addEventListener("click", () =>
    request({
      operation: "assign",
      publicMaterialIds: [...selected],
      groupId: el("filterTarget").value,
    }),
  );
  el("filterReset").addEventListener("click", () =>
    request({ operation: "reset", publicMaterialIds: [...selected] }),
  );
  el("filterCreateForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    if (await request({ operation: "create", label: el("filterNewName").value }))
      el("filterNewName").value = "";
  });
  el("filterGroupList").addEventListener("click", (event) => {
    const button = event.target.closest("[data-group-action]");
    if (!button || busy || stale) return;
    const row = button.closest("[data-filter-group]"),
      gid = row.dataset.filterGroup,
      action = button.dataset.groupAction;
    if (action === "rename")
      request({
        operation: "rename",
        groupId: gid,
        label: row.querySelector("[data-group-name]").value,
      });
    if (action === "up" || action === "down")
      request({
        operation: "move",
        groupId: gid,
        direction: action === "up" ? -1 : 1,
      });
    if (action === "delete") {
      deleting = gid;
      const group = axis().groups.find((g) => g.id === gid);
      el("filterDeleteDescription").textContent =
        `‘${group.label}’ verwijderen (${group.count} materialen)? Kies waar de materialen voortaan onder vallen.`;
      selectOptions(
        el("filterReplacement"),
        axis().groups.filter((g) => g.id !== gid),
      );
      el("filterDeleteDialog").showModal();
    }
  });
  el("filterDeleteCancel").addEventListener("click", () => el("filterDeleteDialog").close());
  el("filterDeleteDialog").addEventListener("cancel", (event) => {
    if (busy) event.preventDefault();
  });
  el("filterDeleteForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const ok = await request({
      operation: "delete",
      groupId: deleting,
      replacementId: el("filterReplacement").value,
    });
    if (ok || stale) el("filterDeleteDialog").close();
  });
})();
