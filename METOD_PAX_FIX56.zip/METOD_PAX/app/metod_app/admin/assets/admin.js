// ADMIN guard: prevent double-execution (hot reload / injected twice)
if (window.__ADMIN_JS_LOADED__) {
  console.warn("Admin JS already loaded");
} else {
  window.__ADMIN_JS_LOADED__ = true;

  function _zaagFile(z) {
    return typeof z === "string" ? z : z && z.file ? z.file : "";
  }
  function _zaagLabel(z) {
    return typeof z === "string"
      ? z
      : z && (z.label || z.file)
        ? z.label || z.file
        : "";
  }
  function _h(s) {
    return String(s == null ? "" : s).replace(
      /[&<>"']/g,
      (c) =>
        ({
          "&": "&amp;",
          "<": "&lt;",
          ">": "&gt;",
          '"': "&quot;",
          "'": "&#39;",
        })[c],
    );
  }
  // Admin owns its escaping primitive. Do not depend on dxf.js load order.
  const esc = _h;
  function _jobLabel(j) {
    const cn = String(j && j.customerName ? j.customerName : "").trim();
    const id = String(j && j.jobId ? j.jobId : "");
    return cn ? _h(cn) + " · " + _h(id) : _h(id);
  }
  let pricingBusy = false;
  let pricingRevision = null;
  async function pricingRequest(options = {}) {
    if (String(options.method || "GET").toUpperCase() !== "GET")
      ToolAErrors.assertHealthy();
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 30000);
    try {
      const url =
        options.method === "POST"
          ? "/api/admin/pricing"
          : "/api/admin/pricing?view=editor";
      const response = await fetch(url, {
        ...options,
        cache: "no-store",
        credentials: "same-origin",
        signal: controller.signal,
      });
      let body;
      try {
        body = await response.json();
      } catch (_) {
        throw new Error(
          "Geen leesbaar serverantwoord. Herlaad om de opgeslagen instellingen te controleren.",
        );
      }
      if (!response.ok || !body || body.ok === false)
        throw new Error(
          response.status === 401
            ? "Je sessie is verlopen. Log opnieuw in."
            : body?.error || `HTTP ${response.status}`,
        );
      return { body };
    } catch (error) {
      if (error?.name === "AbortError")
        throw new Error(
          "De aanvraag duurde te lang. Herlaad om de opgeslagen instellingen te controleren.",
        );
      throw error;
    } finally {
      clearTimeout(timer);
    }
  }
  function pricingSetBusy(busy) {
    pricingBusy = busy;
    document
      .querySelectorAll(
        '[data-admin-action="savePricing"], [data-admin-action="reloadPricing"]',
      )
      .forEach((button) => {
        button.disabled = busy;
      });
  }
  window.reloadPricing = async function reloadPricing() {
    if (pricingBusy) return;
    const st = document.getElementById("pricingStatus");
    const meta = document.getElementById("pricingMeta");
    pricingSetBusy(true);
    if (st) st.textContent = "laden...";
    try {
      const { body: pricingDocument } = await pricingRequest();
      const { config: j, revision } = pricingDocument;
      if (
        !j?.pricing?.defaults ||
        !j.sellPricing ||
        typeof revision !== "string" ||
        !/^"[a-f0-9]{64}"$/.test(revision)
      )
        throw new Error("Onvolledige prijsconfiguratie ontvangen.");
      const defaults = j.pricing.defaults;
      const rounding = defaults.rounding || {};
      const sell = j.sellPricing;
      const setVal = (id, val) => {
        const el = document.getElementById(id);
        if (el) el.value = val == null ? "" : String(val);
      };
      setVal("priceSheetMargin", defaults.sheetMarginMm);
      setVal("priceNestingGap", defaults.nestingGapMm);
      setVal("priceKerf", defaults.kerfMm);
      setVal("priceMoneyDecimals", rounding.moneyDecimals);
      setVal("priceMetersDecimals", rounding.metersDecimals);
      setVal("priceEdgeBand", sell.edgeBandPricePerM);
      setVal("priceCnc", sell.cncCostPerSheet);
      setVal("priceDrawing", sell.drawingCostFixed);
      setVal("priceTransport", sell.transportCostFixed);
      window.__pricingCfg = j;
      pricingRevision = revision;
      if (st) st.textContent = "geladen";
      if (meta) meta.textContent = "Actuele opgeslagen instellingen geladen";
    } catch (e) {
      // Retain the entered values, but require a successful reload before a write.
      pricingRevision = null;
      if (st) st.textContent = "fout bij laden: " + e.message;
      if (meta)
        meta.textContent = "Prijsinstellingen konden niet worden geladen";
    } finally {
      pricingSetBusy(false);
    }
  };
  function pricingReadNumber(id, label, integerOnly = false) {
    const raw = String(document.getElementById(id)?.value ?? "")
      .trim()
      .replace(",", ".");
    if (!raw) throw new Error(label + " is leeg");
    if (!/^(?:\d+(?:\.\d*)?|\.\d+)$/.test(raw))
      throw new Error(label + " is ongeldig");
    const n = Number(raw);
    if (!Number.isFinite(n) || n < 0 || (integerOnly && !Number.isInteger(n)))
      throw new Error(label + " is ongeldig");
    if (integerOnly && n > 6)
      throw new Error(label + " mag maximaal 6 decimalen zijn");
    return n;
  }
  window.savePricing = async function savePricing() {
    if (pricingBusy) return;
    const st = document.getElementById("pricingStatus");
    const meta = document.getElementById("pricingMeta");
    pricingSetBusy(true);
    if (st) st.textContent = "opslaan...";
    try {
      if (!window.__pricingCfg || !pricingRevision)
        throw new Error("Herlaad eerst de actuele prijsinstellingen.");
      const cfg = JSON.parse(JSON.stringify(window.__pricingCfg));
      cfg.pricing.defaults.rounding ||= {};
      cfg.pricing.defaults.sheetMarginMm = pricingReadNumber(
        "priceSheetMargin",
        "Plaatmarge",
      );
      cfg.pricing.defaults.nestingGapMm = pricingReadNumber(
        "priceNestingGap",
        "Nesting gap",
      );
      cfg.pricing.defaults.kerfMm = pricingReadNumber("priceKerf", "Kerf");
      cfg.pricing.defaults.rounding.moneyDecimals = pricingReadNumber(
        "priceMoneyDecimals",
        "Bedragen afronden",
        true,
      );
      cfg.pricing.defaults.rounding.metersDecimals = pricingReadNumber(
        "priceMetersDecimals",
        "Meters afronden",
        true,
      );
      cfg.sellPricing.edgeBandPricePerM = pricingReadNumber(
        "priceEdgeBand",
        "Kantenband per meter",
      );
      cfg.sellPricing.cncCostPerSheet = pricingReadNumber(
        "priceCnc",
        "CNC per plaat",
      );
      cfg.sellPricing.drawingCostFixed = pricingReadNumber(
        "priceDrawing",
        "Tekenwerk vast",
      );
      cfg.sellPricing.transportCostFixed = pricingReadNumber(
        "priceTransport",
        "Transport vast",
      );
      // The application revision travels in JSON. Compression proxies may change
      // or remove HTTP ETags even when the pricing document has not changed.
      const { body: j } = await pricingRequest({
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ config: cfg, revision: pricingRevision }),
      });
      if (j.ok !== true || !j.revision)
        throw new Error(
          "Opslag niet bevestigd. Herlaad om de opgeslagen instellingen te controleren.",
        );
      window.__pricingCfg = cfg;
      pricingRevision = j.revision;
      if (st) st.textContent = "opgeslagen (" + j.version + ")";
      if (meta)
        meta.textContent =
          "Geldt voor nieuwe berekeningen. Bestaande berekeningen behouden hun prijs. Publiceer de catalogus opnieuw om de productiegoedkeuring te vernieuwen.";
    } catch (e) {
      if (st) st.textContent = "fout bij opslaan: " + e.message;
    } finally {
      pricingSetBusy(false);
    }
  };

  function _escapeHtml(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }
  function _fmtBytes(n) {
    n = Number(n || 0);
    if (n < 1024) return n + " B";
    if (n < 1024 * 1024) return (n / 1024).toFixed(1) + " KB";
    if (n < 1024 * 1024 * 1024) return (n / 1024 / 1024).toFixed(1) + " MB";
    return (n / 1024 / 1024 / 1024).toFixed(1) + " GB";
  }
  function _systemToneClass(it) {
    return it.level === "error"
      ? "systemToneError"
      : it.level === "warning"
        ? "systemToneWarning"
        : "systemToneInfo";
  }
  function _systemRefs(it) {
    return [
      it.requestId ? "Request: " + it.requestId : "",
      it.jobId ? "Job: " + it.jobId : "",
      it.customerName ? "Klant: " + it.customerName : "",
    ]
      .filter(Boolean)
      .join(" · ");
  }
  function _renderSystemDetailCard(it) {
    const user = _escapeHtml(it.messageUser || "Onbekende melding");
    const tech = _escapeHtml(it.messageTech || "—");
    const meta = [it.component || "systeem", it.level || "info", it.ts || ""]
      .filter(Boolean)
      .join(" · ");
    const refs = _systemRefs(it);
    return `<details class="card systemLogItem ${_systemToneClass(it)} admin-border-1px-solid-line">
    <summary class="admin-padding-13px">
      <div class="admin-display-flex-flex-wrap-wrap">
        <div class="admin-font-weight-500">${user}</div>
        <div class="pill">${_escapeHtml(it.status || "open")}</div>
      </div>
      <div class="muted">${_escapeHtml(meta)}</div>
      ${refs ? `<div class="admin-font-size-12px">${_escapeHtml(refs)}</div>` : ""}
    </summary>
    <div class="admin-padding-0-13px-13px">
      <div class="admin-border-1px-solid-line-border-radius-7px">
        <div class="admin-font-size-12px">Technische details</div>
        <code class="admin-font-size-12px">${tech}</code>
      </div>
    </div>
  </details>`;
  }
  function _renderSystemCompactRow(it) {
    const refs = _systemRefs(it);
    const meta = [it.component || "systeem", it.ts || ""]
      .filter(Boolean)
      .join(" · ");
    return `<div class="card ${_systemToneClass(it)} admin-padding-12px-14px-display-grid">
    <div class="admin-display-flex-flex-wrap-wrap">
      <div class="admin-font-weight-500">${_escapeHtml(it.messageUser || "Onbekende melding")}</div>
      <div class="pill">${_escapeHtml(it.status || "resolved")}</div>
    </div>
    <div class="muted">${_escapeHtml(meta)}</div>
    ${refs ? `<div class="admin-font-size-12px">${_escapeHtml(refs)}</div>` : ""}
  </div>`;
  }
  async function refreshSystemPage() {
    const logsStatus = document.getElementById("systemLogsStatus");
    const openIssuesList = document.getElementById("systemOpenIssuesList");
    const recentActionsList = document.getElementById(
      "systemRecentActionsList",
    );
    const historyList = document.getElementById("systemHistoryList");
    const backupStatus = document.getElementById("systemBackupStatus");
    const backupsList = document.getElementById("systemBackupsList");
    const openIssuesCount = document.getElementById("systemOpenIssuesCount");
    const recentActionsCount = document.getElementById(
      "systemRecentActionsCount",
    );
    const historyCount = document.getElementById("systemHistoryCount");
    const backupsCount = document.getElementById("systemBackupsCount");
    if (logsStatus) logsStatus.textContent = "Systeemmeldingen laden…";
    if (backupStatus) backupStatus.textContent = "Backups laden…";
    try {
      const [lr, br] = await Promise.all([
        fetch("/api/admin/system/logs", {
          cache: "no-store",
          credentials: "same-origin",
        }),
        fetch("/api/admin/system/backups", {
          cache: "no-store",
          credentials: "same-origin",
        }),
      ]);
      const lj = await lr
        .json()
        .catch(() => ({ ok: false, error: "Ongeldige log-response" }));
      const bj = await br
        .json()
        .catch(() => ({ ok: false, error: "Ongeldige backup-response" }));
      const logItems = lr.ok && lj.ok ? lj.items || [] : [];
      const backupItems = br.ok && bj.ok ? bj.items || [] : [];
      const openItems = logItems.filter((it) => {
        const status = String((it && it.status) || "")
          .trim()
          .toLowerCase();
        return status !== "resolved";
      });
      const recentItems = logItems
        .filter((it) => !openItems.includes(it))
        .slice(0, 5);
      if (logsStatus)
        logsStatus.textContent =
          lr.ok && lj.ok
            ? `${logItems.length || 0} meldingen geladen`
            : "Fout: " + (lj.error || "HTTP " + lr.status);
      if (backupStatus)
        backupStatus.textContent =
          br.ok && bj.ok
            ? `${backupItems.length || 0} backups gevonden`
            : "Fout: " + (bj.error || "HTTP " + br.status);
      if (openIssuesCount)
        openIssuesCount.textContent = String(openItems.length || 0);
      if (recentActionsCount)
        recentActionsCount.textContent = String(recentItems.length || 0);
      if (historyCount) historyCount.textContent = String(logItems.length || 0);
      if (backupsCount)
        backupsCount.textContent = String(backupItems.length || 0);
      if (openIssuesList) {
        openIssuesList.innerHTML = openItems.length
          ? openItems.map(_renderSystemDetailCard).join("")
          : `<div class="card admin-padding-12px-14px">Geen open fouten of waarschuwingen.</div>`;
      }
      if (recentActionsList) {
        recentActionsList.innerHTML = recentItems.length
          ? recentItems.map(_renderSystemCompactRow).join("")
          : `<div class="card admin-padding-12px-14px">Nog geen recente systeemacties.</div>`;
      }
      if (historyList) {
        historyList.innerHTML = logItems.length
          ? logItems.map(_renderSystemDetailCard).join("")
          : `<div class="card admin-padding-12px-14px">Geen systeemmeldingen gevonden.</div>`;
      }
      if (backupsList) {
        backupsList.innerHTML = backupItems.length
          ? backupItems
              .map(
                (it) =>
                  `<div class="card admin-display-flex-flex-wrap-wrap-justify-content-space-between"><div><div class="admin-font-weight-500"><span>${_escapeHtml(it.name || "")}</span><span class="pill">${(it.kind || "manual") === "auto" ? "Automatisch" : "Handmatig"}</span></div><div class="muted">${_escapeHtml(it.modified || "")}</div></div><div class="admin-display-flex-flex-wrap-wrap-justify-content-space-between-align-items-flex-start"><div class="pill">${_fmtBytes(it.size || 0)}</div><a class="btn secondary" href="/api/admin/system/backup_download?name=${encodeURIComponent(it.name || "")}">Download</a></div></div>`,
              )
              .join("")
          : `<div class="card admin-padding-12px-14px">Nog geen backups gevonden.</div>`;
      }
    } catch (err) {
      if (logsStatus)
        logsStatus.textContent = "Fout: " + ((err && err.message) || err);
      if (backupStatus)
        backupStatus.textContent = "Fout: " + ((err && err.message) || err);
    }
  }
  async function createSystemBackup() {
    ToolAErrors.assertHealthy();
    const st = document.getElementById("systemBackupStatus");
    if (st) st.textContent = "Backup wordt gemaakt…";
    try {
      const r = await fetch("/api/admin/system/backup_now", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: "{}",
      });
      const j = await r
        .json()
        .catch(() => ({ ok: false, error: "Ongeldige serverresponse" }));
      if (!r.ok || !j.ok) {
        if (st) st.textContent = "Fout: " + (j.error || "HTTP " + r.status);
        return;
      }
      await refreshSystemPage();
      if (st)
        st.textContent =
          j.retention?.ok === false
            ? "Backup gemaakt, maar opruiming is niet voltooid. Controleer ruimte en bestandsrechten bij Systeemlog."
            : `Backup gemaakt: ${j.file || ""}`;
    } catch (err) {
      if (st) st.textContent = "Fout: " + ((err && err.message) || err);
    }
  }
  window.refreshSystemPage = refreshSystemPage;
  window.createSystemBackup = createSystemBackup;

  function switchAdminSection(section) {
    document.querySelectorAll(".adminNavBtn").forEach((btn) => {
      btn.classList.toggle(
        "active",
        btn.getAttribute("data-section") === section,
      );
      btn.setAttribute(
        "aria-pressed",
        String(btn.getAttribute("data-section") === section),
      );
    });
    document.querySelectorAll(".adminSection").forEach((sec) => {
      sec.classList.toggle(
        "active",
        sec.getAttribute("data-section") === section,
      );
    });
    if (section === "system") {
      refreshSystemPage();
    }
  }

  function initAdminShell() {
    if (window.__adminShellInit) return;
    window.__adminShellInit = true;
    document.querySelectorAll(".adminNavBtn").forEach((btn) => {
      btn.addEventListener("click", () =>
        switchAdminSection(btn.getAttribute("data-section") || "inbox"),
      );
    });
    switchAdminSection("inbox");
  }

  let materialsCache = [];
  let materialsSelectedKey = "";
  function matNum(v) {
    const raw = String(v == null ? "" : v)
      .trim()
      .replace(",", ".");
    if (!raw) return null;
    const n = parseFloat(raw);
    return Number.isFinite(n) ? n : null;
  }
  function materialKeyOf(r) {
    return String(
      (r && (r.articleNo || r.articleNumber || r.materialCode)) || "",
    ).trim();
  }
  function materialDecorOf(r) {
    return String(
      (r && (r.decorName || r.productName || r.materialDisplayName || "")) ||
        "",
    ).trim();
  }
  function materialCodeOf(r) {
    return String((r && (r.materialCode || r.articleNo || "")) || "").trim();
  }
  function materialsDimensionOf(r) {
    const w = materialsFormatDim(r?.sheetWid || r?.sheetWidth || "");
    const l = materialsFormatDim(
      r?.sheetLen || r?.sheetHeight || r?.height || "",
    );
    return w && l ? w + "×" + l + " mm" : "";
  }
  function materialsThicknessOf(r) {
    return materialsFormatDim(r?.thicknessMm || r?.thickness || "");
  }
  function materialsGetFilterState() {
    return {
      search: String(document.getElementById("materialsSearch")?.value || "")
        .trim()
        .toLowerCase(),
      thickness: String(
        document.getElementById("materialsFilterThickness")?.value || "",
      ).trim(),
      dimension: String(
        document.getElementById("materialsFilterDimension")?.value || "",
      ).trim(),
      category: String(
        document.getElementById("materialsFilterCategory")?.value || "",
      )
        .trim()
        .toLowerCase(),
      brandText: String(
        document.getElementById("materialsFilterBrandText")?.value || "",
      )
        .trim()
        .toLowerCase(),
      availability: String(
        document.getElementById("materialsFilterAvailability")?.value || "",
      ).trim(),
    };
  }
  function materialsActiveFilterCount() {
    const f = materialsGetFilterState();
    return [
      f.thickness,
      f.dimension,
      f.category,
      f.brandText,
      f.availability,
    ].filter(Boolean).length;
  }
  function materialsUpdateFiltersToggleLabel() {
    const btn = document.getElementById("materialsFiltersToggle");
    if (!btn) return;
    const n = materialsActiveFilterCount();
    btn.textContent = n ? "Filters (" + n + ")" : "Filters";
  }
  const ADMIN_RUNTIME_DISPLAY_CLASSES = Object.freeze([
    "adminRuntimeHidden",
    "adminRuntimeBlock",
    "adminRuntimeGrid",
    "adminRuntimeFlex",
    "adminRuntimeTableRow",
  ]);
  const setAdminRuntimeDisplay = (element, display) => {
    if (!element) return;
    element.classList.remove(...ADMIN_RUNTIME_DISPLAY_CLASSES);
    const className = {
      none: "adminRuntimeHidden",
      block: "adminRuntimeBlock",
      grid: "adminRuntimeGrid",
      flex: "adminRuntimeFlex",
      "table-row": "adminRuntimeTableRow",
    }[display];
    if (className) element.classList.add(className);
  };
  function materialsToggleFilters(forceOpen) {
    const panel = document.getElementById("materialsFiltersPanel");
    if (!panel) return;
    const open =
      forceOpen === true
        ? true
        : !panel.classList.contains("adminRuntimeBlock");
    setAdminRuntimeDisplay(panel, open ? "block" : "none");
  }
  function materialsPopulateFilterOptions() {
    const thicknessEl = document.getElementById("materialsFilterThickness");
    const dimEl = document.getElementById("materialsFilterDimension");
    const catEl = document.getElementById("materialsFilterCategory");
    const current = materialsGetFilterState();
    const uniqueSorted = (vals, numeric = false) =>
      Array.from(new Set(vals.filter(Boolean))).sort((a, b) => {
        if (numeric) {
          return parseFloat(a) - parseFloat(b);
        }
        return String(a).localeCompare(String(b), "nl", {
          numeric: true,
          sensitivity: "base",
        });
      });
    const thicknesses = uniqueSorted(
      materialsCache.map((r) => materialsThicknessOf(r)),
      true,
    );
    const dims = uniqueSorted(
      materialsCache.map((r) => materialsDimensionOf(r)),
    );
    const cats = uniqueSorted(
      materialsCache.map((r) => String(r.categoryName || "").trim()),
    );
    if (thicknessEl)
      thicknessEl.innerHTML =
        '<option value="">Alle diktes</option>' +
        thicknesses
          .map((v) => `<option value="${esc(v)}">${esc(v)} mm</option>`)
          .join("");
    if (dimEl)
      dimEl.innerHTML =
        '<option value="">Alle afmetingen</option>' +
        dims
          .map((v) => `<option value="${esc(v)}">${esc(v)}</option>`)
          .join("");
    if (catEl)
      catEl.innerHTML =
        '<option value="">Alle plaatsoorten</option>' +
        cats
          .map((v) => `<option value="${esc(v)}">${esc(v)}</option>`)
          .join("");
    if (thicknessEl) thicknessEl.value = current.thickness;
    if (dimEl) dimEl.value = current.dimension;
    if (catEl)
      catEl.value = current.category
        ? cats.find((v) => String(v).toLowerCase() === current.category) || ""
        : "";
    materialsUpdateFiltersToggleLabel();
  }
  function materialsFilterRows() {
    const f = materialsGetFilterState();
    return materialsCache.filter((r) => {
      const hay = [
        r.articleNo,
        r.articleNumber,
        r.materialCode,
        r.decorName,
        r.productName,
        r.categoryName,
        r.shortDescription,
      ].map((v) => String(v || "").toLowerCase());
      if (f.search && !hay.some((v) => v.includes(f.search))) return false;
      const thickness = materialsThicknessOf(r);
      if (f.thickness && thickness !== f.thickness) return false;
      const dimension = materialsDimensionOf(r);
      if (f.dimension && dimension !== f.dimension) return false;
      const category = String(r.categoryName || "")
        .trim()
        .toLowerCase();
      if (f.category && category !== f.category) return false;
      if (f.brandText) {
        const brandHay = [
          r.productName,
          r.decorName,
          r.shortDescription,
          r.categoryName,
          r.articleNo,
        ]
          .map((v) => String(v || "").toLowerCase())
          .join(" | ");
        if (!brandHay.includes(f.brandText)) return false;
      }
      if (f.availability === "yes" && r.active === false) return false;
      if (f.availability === "no" && r.active !== false) return false;
      return true;
    });
  }
  function materialsSetCategoryValue(val) {
    const el = document.getElementById("matCategoryName");
    if (!el) return;
    const v = String(val || "").trim();
    if (v && !Array.from(el.options).some((o) => o.value === v)) {
      const opt = document.createElement("option");
      opt.value = v;
      opt.textContent = v;
      opt.dataset.dynamic = "1";
      el.appendChild(opt);
    }
    el.value = v;
  }
  function materialsFormatDim(n) {
    const num = Number(n);
    if (!Number.isFinite(num)) return "";
    return Number.isInteger(num)
      ? String(Math.trunc(num))
      : String(num)
          .replace(/\.0+$/, "")
          .replace(/(\.\d*?)0+$/, "$1");
  }
  function materialsUpdateDerivedFields() {
    if (materialsSelectedKey) return;
    const descEl = document.getElementById("matShortDescription");
    const w = matNum(document.getElementById("matSheetWid")?.value);
    const l = matNum(document.getElementById("matSheetLen")?.value);
    const t = matNum(document.getElementById("matThickness")?.value);
    if (!descEl) return;
    const prevAuto = descEl.dataset.auto === "1";
    const canAuto = prevAuto || !String(descEl.value || "").trim();
    if (!canAuto) return;
    if (w > 0 && l > 0 && t > 0) {
      descEl.value = `${materialsFormatDim(l)}x${materialsFormatDim(w)}x${materialsFormatDim(t)}mm`;
      descEl.dataset.auto = "1";
    } else if (prevAuto) {
      descEl.value = "";
      descEl.dataset.auto = "0";
    }
  }
  function materialsRenderPublicPreview() {
    const target = document.getElementById("matToolAPreview");
    if (!target) return;
    const publicName =
      String(
        document.getElementById("matPublicName")?.value || "Publieke decornaam",
      ).trim() || "Publieke decornaam";
    const brand =
      String(document.getElementById("matBrand")?.value || "Merk").trim() ||
      "Merk";
    const type =
      String(
        document.getElementById("matDecorType")?.value || "Overig",
      ).trim() || "Overig";
    const thickness =
      materialsFormatDim(document.getElementById("matThickness")?.value) || "—";
    const grain = !!document.getElementById("matHasGrain")?.checked;
    const source =
      document.querySelector("#matImagePreview img")?.getAttribute("src") || "";
    const media = source ? `<img src="${esc(source)}" alt="">` : "▧";
    target.innerHTML = `<div class="decorAdminToolACardMedia">${media}</div><div class="decorAdminToolACardBody"><div class="decorAdminToolACardBrand">${esc(brand)}</div><div class="decorAdminToolACardName">${esc(publicName)}</div><div class="decorAdminToolACardTags"><span class="decorAdminToolACardTag">${grain ? "Nerf" : "Uni"}</span><span class="decorAdminToolACardTag">${esc(thickness)} mm</span><span class="decorAdminToolACardTag">${esc(type)}</span></div></div>`;
  }
  function materialsSetForm(rec) {
    const state = document.getElementById("materialsDetailState");
    const empty = document.getElementById("matCsvOnlyDetailEmpty");
    const detail = document.getElementById("matCsvOnlyDetail");
    if (!rec) {
      if (state) state.textContent = "Geen product geselecteerd.";
      setAdminRuntimeDisplay(empty, "block");
      setAdminRuntimeDisplay(detail, "none");
      return;
    }
    if (state) state.textContent = "CSV-product geselecteerd";
    setAdminRuntimeDisplay(empty, "none");
    setAdminRuntimeDisplay(detail, "block");
    const txt = (id, val) => {
      const el = document.getElementById(id);
      if (el) el.textContent = String(val ?? "");
    };
    txt("matCsvOnlyBrand", rec.brand || "Overig");
    txt(
      "matCsvOnlyName",
      rec.publicName || rec.productName || rec.decorName || "Decor",
    );
    txt(
      "matCsvOnlyThickness",
      (materialsFormatDim(rec.thicknessMm || rec.thickness) || "—") + " mm",
    );
    txt("matCsvOnlySize", materialsDimensionOf(rec) || "—");
    const price = Number(rec.sellPriceInclVatPerSheet || 0);
    txt(
      "matCsvOnlyPrice",
      price > 0
        ? new Intl.NumberFormat("nl-NL", {
            style: "currency",
            currency: "EUR",
          }).format(price)
        : "—",
    );
    txt(
      "matCsvOnlyImageState",
      rec.imageAvailable ? "Lokaal beschikbaar" : "Wordt opgehaald / ontbreekt",
    );
    txt(
      "matCsvOnlyArticle",
      rec.articleNo || rec.articleNumber || rec.materialCode || "—",
    );
    txt("matCsvOnlyPublicId", rec.publicMaterialId || "—");
    const ds = String(rec.dimensionSource || "csv");
    txt(
      "matCsvOnlyDimensionSource",
      ds === "csv"
        ? "CSV"
        : ds === "image_url"
          ? "Afbeeldings-URL"
          : ds === "decolegno_18_fallback"
            ? "DecoLegno 18 mm fallback"
            : ds,
    );
    const familySelect = document.getElementById("matCsvOnlyFamilyOverride");
    const manualFamily = String(rec.taxonomyManualFamilyOverride || "").trim();
    if (familySelect) {
      familySelect.value = manualFamily || "AUTO";
      familySelect.disabled = false;
    }
    txt(
      "matCsvOnlyFamilyOverrideState",
      manualFamily
        ? "Handmatig vastgezet op " + manualFamily
        : "Automatisch · " +
            String(rec.primaryVisualFamily || rec.decorType || "Onbekend"),
    );
    const image = document.getElementById("matCsvOnlyImage");
    if (image) {
      const url = String(rec.imagePreviewUrl || rec.imageThumbUrl || "").trim();
      image.innerHTML = url
        ? `<img src="${esc(url)}" alt="Decorafbeelding" class="admin-width-100-height-100">`
        : "Geen afbeelding";
    }
  }
  async function materialsSaveFamilyOverride() {
    ToolAErrors.assertHealthy();
    const select = document.getElementById("matCsvOnlyFamilyOverride");
    const state = document.getElementById("matCsvOnlyFamilyOverrideState");
    if (!select || !materialsSelectedKey) return;
    const rec =
      materialsCache.find((x) => materialKeyOf(x) === materialsSelectedKey) ||
      null;
    const pid = String(rec?.publicMaterialId || "").trim();
    if (!pid) {
      if (state)
        state.textContent =
          "Opslaan niet mogelijk: publieke decor-ID ontbreekt.";
      return;
    }
    const requested = String(select.value || "AUTO");
    try {
      select.disabled = true;
      if (state) state.textContent = "Opslaan…";
      const r = await fetch("/api/admin/materials/live_taxonomy_family", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          publicMaterialId: pid,
          primaryVisualFamily: requested,
        }),
      });
      const j = await r.json().catch(() => ({}));
      if (!r.ok || !j.ok) throw new Error(j.error || "HTTP " + r.status);
      const idx = materialsCache.findIndex(
        (x) => materialKeyOf(x) === materialsSelectedKey,
      );
      if (idx >= 0 && j.record) materialsCache[idx] = j.record;
      const updated = idx >= 0 ? materialsCache[idx] : j.record;
      materialsSetForm(updated || null);
      materialsPopulateFilterOptions();
      materialsRenderList();
      if (state)
        state.textContent = j.manualOverride
          ? "Handmatig vastgezet op " + j.primaryVisualFamily
          : "Automatisch · " + j.primaryVisualFamily;
    } catch (e) {
      select.disabled = false;
      select.value =
        String(rec?.taxonomyManualFamilyOverride || "").trim() || "AUTO";
      if (state) state.textContent = "Opslaan mislukt: " + (e?.message || e);
    }
  }

  function materialsRenderList() {
    const list = document.getElementById("materialsList");
    const meta = document.getElementById("materialsMeta");
    if (!list) return;
    const rows = materialsFilterRows();
    const activeCount = materialsActiveFilterCount();
    if (meta)
      meta.textContent =
        rows.length +
        " van " +
        materialsCache.length +
        " materialen zichtbaar" +
        (activeCount
          ? " · " +
            activeCount +
            " filter" +
            (activeCount === 1 ? "" : "s") +
            " actief"
          : "");
    materialsUpdateFiltersToggleLabel();
    if (!rows.length) {
      list.innerHTML = '<div class="muted">Geen materialen gevonden.</div>';
      return;
    }
    list.innerHTML = rows
      .map((r) => {
        const key = materialKeyOf(r);
        const title = esc(
          r.publicName ||
            r.productName ||
            r.decorName ||
            r.articleNo ||
            "Materiaal",
        );
        const status = "CSV actief";
        const metaText = [
          r.articleNo,
          r.brand || "",
          r.primaryVisualFamily || r.decorType || "",
          r.substrateLabel || "",
          materialsDimensionOf(r),
          materialsThicknessOf(r) ? materialsThicknessOf(r) + " mm" : "",
          status,
        ]
          .filter(Boolean)
          .map(esc)
          .join("<span>·</span>");
        const thumb = r.imageThumbUrl
          ? `<img src="${esc(r.imageThumbUrl)}" alt="">`
          : "▧";
        return `<button class="materialsRow${materialsSelectedKey === key ? " active" : ""}" type="button" data-key="${esc(key)}"><div class="materialsRowWithImage"><div class="materialsRowThumb">${thumb}</div><div><div class="materialsRowTitle">${title}</div><div class="materialsRowMeta">${metaText}</div></div></div></button>`;
      })
      .join("");
    list.querySelectorAll(".materialsRow").forEach((btn) =>
      btn.addEventListener("click", () => {
        const key = btn.getAttribute("data-key") || "";
        const rec =
          materialsCache.find((x) => materialKeyOf(x) === key) || null;
        materialsSelectedKey = key;
        materialsSetForm(rec);
        materialsRenderList();
      }),
    );
  }
  window.materialsNew = function materialsNew() {
    const st = document.getElementById("materialsStatus");
    if (st)
      st.textContent =
        "Nieuwe materialen worden uitsluitend via de catalogus-CSV toegevoegd.";
  };
  window.materialsReload = async function materialsReload() {
    const st = document.getElementById("materialsStatus");
    if (st) st.textContent = "Catalogus laden…";
    try {
      const r = await fetch("/api/admin/materials/library", {
        cache: "no-store",
      });
      const j = await r.json();
      if (!r.ok || !j.ok) throw new Error(j.error || "HTTP " + r.status);
      materialsCache = Array.isArray(j.records) ? j.records : [];
      materialsPopulateFilterOptions();
      const chosen = materialsSelectedKey
        ? materialsCache.find((x) => materialKeyOf(x) === materialsSelectedKey)
        : null;
      if (materialsSelectedKey && !chosen) materialsSelectedKey = "";
      materialsSetForm(chosen || null);
      materialsRenderList();
      const state = document.getElementById("materialsCatalogStateText");
      if (state) {
        const li = j?.meta?.lastCatalogImport || null;
        if (materialsCache.length) {
          const when = li?.publishedAt
            ? " · gepubliceerd " +
              String(li.publishedAt).replace("T", " ").replace("Z", " UTC")
            : "";
          state.textContent = `${materialsCache.length} CSV-producten actief${when}`;
        } else {
          state.textContent =
            "Nog geen actieve CSV-catalogus. Upload en publiceer hierboven eerst een catalogus.";
        }
      }
      if (st) st.textContent = "CSV-only beheer actief.";
    } catch (e) {
      if (st) st.textContent = "Fout bij laden: " + (e?.message || e);
    }
  };
  window.materialsSave = async function materialsSave() {
    throw new Error(
      "Handmatig materiaalbeheer is uitgeschakeld. Publiceer een nieuwe CSV.",
    );
  };
  window.materialsDelete = async function materialsDelete() {
    throw new Error(
      "Handmatig materiaalbeheer is uitgeschakeld. Publiceer een nieuwe CSV.",
    );
  };

  document
    .getElementById("matCsvOnlyFamilyOverride")
    ?.addEventListener("change", materialsSaveFamilyOverride);

  let materialsCatalogImportId = "";
  let materialsCatalogPollTimer = null;
  let materialsCatalogCanPublishAfterImages = false;
  let materialsCatalogLastPreview = null;
  function catalogSummaryBox(value, label, detail) {
    return `<div class="admin-padding-10px-11px-border-radius-8px"><div class="admin-font-size-19px-font-weight-500">${esc(value)}</div><div class="admin-font-size-12px">${esc(label)}</div>${detail ? `<div class="muted admin-font-size-12px">${esc(detail)}</div>` : ""}</div>`;
  }
  function materialsCatalogRenderPreview(j) {
    materialsCatalogLastPreview = j || materialsCatalogLastPreview;
    const summary = document.getElementById("matCsvSummary");
    const notices = document.getElementById("matCsvNotices");
    const publish = document.getElementById("matCsvPublishBtn");
    const s = j?.summary || {};
    if (summary) {
      setAdminRuntimeDisplay(summary, "grid");
      summary.innerHTML = [
        catalogSummaryBox(s.rowsRead || 0, "CSV-regels", "gelezen"),
        catalogSummaryBox(s.eligible || 0, "Toegelaten", "18 / 19 / 20 mm"),
        catalogSummaryBox(
          s.excludedThickness || 0,
          "Uitgesloten",
          "andere dikte",
        ),
        catalogSummaryBox(s.new || 0, "Nieuw", "artikel"),
        catalogSummaryBox(s.changed || 0, "Gewijzigd", "prijs / maat / beeld"),
        catalogSummaryBox(s.unchanged || 0, "Ongewijzigd", "zelfde brondata"),
        catalogSummaryBox(
          s.missingFromSource || 0,
          "Niet meer in nieuwe CSV",
          "verdwijnt uit actief",
        ),
        catalogSummaryBox(
          s.taxonomyVerified || 0,
          "Geclassificeerd",
          "filter + drager",
        ),
        catalogSummaryBox(
          s.taxonomyReviewRequired || 0,
          "Controle nodig",
          "publicatie geblokkeerd",
        ),
        catalogSummaryBox(s.warnings || 0, "Waarschuwingen", "controleren"),
      ].join("");
    }
    const warnings = Array.isArray(j?.warnings) ? j.warnings : [];
    const errors = Array.isArray(j?.errors) ? j.errors : [];
    const excluded = Array.isArray(j?.excluded) ? j.excluded : [];
    const taxonomyReview = Array.isArray(j?.taxonomyReview)
      ? j.taxonomyReview
      : [];
    if (notices) {
      setAdminRuntimeDisplay(
        notices,
        warnings.length ||
          errors.length ||
          excluded.length ||
          taxonomyReview.length
          ? "block"
          : "none",
      );
      const section = (title, arr, kind) =>
        !arr.length
          ? ""
          : `<details class="admin-margin-top-8px"${kind === "error" ? " open" : ""}><summary class="admin-font-weight-500">${esc(title)} · ${arr.length}</summary><div class="admin-display-grid-gap-8px-margin-top-8px">${arr.map((x) => `<div class="admin-font-size-12px"><strong>${esc(x.articleNo || "regel " + (x.row || ""))}</strong> · ${esc(x.message || x.reason || "")}</div>`).join("")}</div></details>`;
      const families = Array.isArray(j?.taxonomyFamilies)
        ? j.taxonomyFamilies
        : [
            "Hout",
            "Uni",
            "Steen & beton",
            "Metaal",
            "Textiel & leer",
            "Grafisch",
            "Fantasie",
          ];
      const substrates = Array.isArray(j?.taxonomySubstrates)
        ? j.taxonomySubstrates
        : [
            { value: "MDF", label: "MDF" },
            { value: "SPAANPLAAT", label: "Spaanplaat" },
            { value: "MULTIPLEX", label: "Multiplex" },
            { value: "OVERIG", label: "Overig" },
          ];
      const reviewHtml = !taxonomyReview.length
        ? ""
        : `<details class="admin-margin-top-8px" open><summary class="admin-font-weight-500">Classificatie controleren · ${taxonomyReview.length}</summary><div class="muted admin-margin-top-8px">Alleen twijfelgevallen verschijnen hier. Publiceren blijft geblokkeerd totdat ieder product één primaire decorfamilie en drager heeft.</div><div class="admin-display-grid-gap-8px-margin-top-8px">${taxonomyReview.map((x) => `<div data-tax-row="${esc(x.articleNo)}" class="admin-padding-10px-border-radius-7px"><div class="admin-font-weight-500">${esc(x.productName || x.articleNo)}</div><div class="muted admin-font-size-12px">${esc([x.brand, x.manufacturerCode, x.collection].filter(Boolean).join(" · "))} · ${esc(x.reason || "controle nodig")}</div><div class="admin-display-grid-grid-template-columns-minmax-0-1fr"><select data-tax-family>${families.map((v) => `<option value="${esc(v)}"${v === x.suggestedFamily ? " selected" : ""}>${esc(v)}</option>`).join("")}</select><select data-tax-substrate>${substrates.map((v) => `<option value="${esc(v.value)}"${v.value === x.suggestedSubstrate ? " selected" : ""}>${esc(v.label)}</option>`).join("")}</select><button class="btn secondary" type="button" data-tax-save="${esc(x.articleNo)}">Opslaan</button></div></div>`).join("")}</div></details>`;
      notices.innerHTML =
        section("Blokkerende fouten", errors, "error") +
        reviewHtml +
        section("Waarschuwingen", warnings, "warning") +
        section("Door diktefilter uitgesloten", excluded, "excluded");
      notices
        .querySelectorAll("[data-tax-save]")
        .forEach((btn) =>
          btn.addEventListener("click", () =>
            materialsCatalogApplyTaxonomy(
              btn.getAttribute("data-tax-save"),
              btn,
            ),
          ),
        );
    }
    materialsCatalogCanPublishAfterImages =
      !!j?.canPublishAfterImages || !!j?.canPublish;
    if (publish) publish.disabled = !j?.canPublish;
  }
  async function materialsCatalogApplyTaxonomy(articleNo, btn) {
    ToolAErrors.assertHealthy();
    if (!materialsCatalogImportId || !articleNo) return;
    const row = btn?.closest?.("[data-tax-row]");
    const family = row?.querySelector?.("[data-tax-family]")?.value || "";
    const substrate = row?.querySelector?.("[data-tax-substrate]")?.value || "";
    const status = document.getElementById("matCsvStatus");
    try {
      if (btn) btn.disabled = true;
      const r = await fetch("/api/admin/materials/catalog_taxonomy_override", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          importId: materialsCatalogImportId,
          articleNo,
          primaryVisualFamily: family,
          substrateType: substrate,
        }),
      });
      const j = await r.json().catch(() => ({}));
      if (!r.ok || !j.ok) throw new Error(j.error || "HTTP " + r.status);
      const base = materialsCatalogLastPreview || {};
      base.reviewSha256 = String(j.reviewSha256 || "");
      base.taxonomySummary = j.taxonomySummary || {};
      base.taxonomyReview = j.taxonomyReview || [];
      base.canPublishAfterImages = !!j.canPublishAfterImages;
      base.canPublish = !!j.canPublish;
      base.summary = Object.assign({}, base.summary || {}, {
        taxonomyVerified: Number(j.taxonomySummary?.verified || 0),
        taxonomyReused: Number(j.taxonomySummary?.reused || 0),
        taxonomyAutoVerified: Number(j.taxonomySummary?.autoVerified || 0),
        taxonomyAdminVerified: Number(j.taxonomySummary?.adminVerified || 0),
        taxonomyReviewRequired: Number(j.taxonomySummary?.reviewRequired || 0),
      });
      materialsCatalogCanPublishAfterImages = !!j.canPublishAfterImages;
      materialsCatalogRenderPreview(base);
      if (status)
        status.textContent =
          (j.taxonomySummary?.reviewRequired || 0) > 0
            ? `${j.taxonomySummary.reviewRequired} product(en) moeten nog worden gecontroleerd.`
            : "Classificatie compleet. Wacht zo nodig nog op de afbeeldingen; daarna kun je publiceren.";
    } catch (e) {
      if (status)
        status.textContent =
          "Classificatie opslaan mislukt: " + (e?.message || e);
      if (btn) btn.disabled = false;
    }
  }

  async function materialsCatalogPreview() {
    ToolAErrors.assertHealthy();
    const input = document.getElementById("matCsvInput");
    const status = document.getElementById("matCsvStatus");
    const btn = document.getElementById("matCsvPreviewBtn");
    const pub = document.getElementById("matCsvPublishBtn");
    materialsCatalogImportId = "";
    materialsCatalogCanPublishAfterImages = false;
    if (materialsCatalogPollTimer) {
      clearInterval(materialsCatalogPollTimer);
      materialsCatalogPollTimer = null;
    }
    if (pub) pub.disabled = true;
    if (!input?.files?.length) {
      if (status) status.textContent = "Kies eerst een CSV-bestand.";
      return;
    }
    const file = input.files[0];
    if (file.size > 4 * 1024 * 1024) {
      if (status) status.textContent = "CSV is groter dan 4 MB.";
      return;
    }
    if (status) status.textContent = "CSV controleren…";
    try {
      if (btn) btn.disabled = true;
      const text = await file.text();
      const r = await fetch("/api/admin/materials/catalog_preview", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ csvText: text }),
      });
      const j = await r.json().catch(() => ({}));
      if (!r.ok || !j.ok) throw new Error(j.error || "HTTP " + r.status);
      materialsCatalogImportId = String(j.importId || "");
      materialsCatalogRenderPreview(j);
      const imageTotal = Number(j.imageSyncTotal || 0);
      if (j.canPublish) {
        if (status)
          status.textContent =
            "Controle klaar. Alle benodigde beelden zijn al lokaal beschikbaar; je kunt publiceren.";
        materialsCatalogRenderSync({
          ok: true,
          state: "DONE",
          total: 0,
          processed: 0,
          success: 0,
          failed: 0,
        });
      } else if (j.canPublishAfterImages && imageTotal > 0) {
        if (status)
          status.textContent = `CSV-data is geldig. ${imageTotal} afbeeldingen worden nu lokaal voorbereid vóór publicatie…`;
        materialsCatalogStartPolling();
      } else {
        const review = Number(j?.taxonomySummary?.reviewRequired || 0);
        if (status)
          status.textContent =
            review > 0
              ? `CSV-data is geldig, maar ${review} product(en) vereisen classificatiecontrole vóór publicatie.`
              : "Controle klaar, maar er zijn blokkerende fouten.";
      }
    } catch (e) {
      if (status) status.textContent = "Fout: " + (e?.message || e);
    } finally {
      if (btn) btn.disabled = false;
    }
  }
  function materialsCatalogRenderSync(st) {
    const el = document.getElementById("matCsvImageSync");
    if (!el) return;
    setAdminRuntimeDisplay(el, "block");
    const total = Number(st?.total || 0),
      processed = Number(st?.processed || 0),
      ok = Number(st?.success || 0),
      failed = Number(st?.failed || 0);
    const pct = total
      ? Math.min(100, Math.round((processed / total) * 100))
      : 100;
    const done = ["DONE", "DONE_WITH_ERRORS", "FAILED"].includes(
      String(st?.state || ""),
    );
    const fullyPrepared =
      String(st?.state || "") === "DONE" && failed === 0 && processed >= total;
    const readyToPublish =
      !!materialsCatalogCanPublishAfterImages &&
      fullyPrepared &&
      !st?.published;
    const publicationGate = st?.published
      ? `<div class="admin-padding-12px-border-radius-8px">Actief gepubliceerd. Tool A gebruikt nu deze catalogus en afbeeldingen.</div>`
      : readyToPublish
        ? `<div class="admin-padding-12px-border-radius-8px-margin-top-12px"><div class="admin-font-weight-500">100% voorbereid, maar nog niet actief in Tool A</div><div class="muted admin-font-size-12px">De beelden staan veilig in staging. Publiceer de catalogus nog expliciet om records en afbeeldingen samen live te zetten.</div><button class="btn admin-width-100-margin-top-10px" type="button" id="matCsvPublishReadyBtn">Nu catalogus publiceren</button></div>`
        : "";
    el.innerHTML = `<div class="admin-display-flex-flex-wrap-wrap-justify-content-space-between-align-items-flex-start-gap-10px"><strong>Afbeeldingen voorbereiden vóór publicatie</strong><span>${pct}%</span></div><div class="admin-height-7px-border-radius-10px"><div class="catalogProgressValue" data-progress-pct="${pct}"></div></div><div class="muted admin-font-size-12px">${processed} / ${total} verwerkt · ${ok} gelukt · ${failed} mislukt${done ? " · klaar" : ""}</div>${publicationGate}${failed && done ? `<button class="btn secondary admin-margin-top-8px" type="button" id="matCsvRetryImagesBtn">Afbeeldingen opnieuw proberen</button>` : ""}`;
    const progressValue = el.querySelector(".catalogProgressValue");
    if (progressValue) progressValue.style.width = `${pct}%`;
    const retry = document.getElementById("matCsvRetryImagesBtn");
    if (retry) retry.addEventListener("click", materialsCatalogRetryImages);
    const publishReady = document.getElementById("matCsvPublishReadyBtn");
    if (publishReady)
      publishReady.addEventListener("click", materialsCatalogPublish);
  }
  async function materialsCatalogPollImages() {
    if (!materialsCatalogImportId) return;
    {
      const r = await fetch(
        "/api/admin/materials/catalog_status?importId=" +
          encodeURIComponent(materialsCatalogImportId),
        { cache: "no-store" },
      );
      const st = await r.json().catch(() => ({}));
      if (r.ok && st.ok !== false) {
        materialsCatalogRenderSync(st);
        if (
          ["DONE", "DONE_WITH_ERRORS", "FAILED"].includes(
            String(st.state || ""),
          )
        ) {
          if (materialsCatalogPollTimer) {
            clearInterval(materialsCatalogPollTimer);
            materialsCatalogPollTimer = null;
          }
          const pub = document.getElementById("matCsvPublishBtn");
          const status = document.getElementById("matCsvStatus");
          const fullyPrepared =
            String(st.state || "") === "DONE" &&
            Number(st.failed || 0) === 0 &&
            Number(st.processed || 0) >= Number(st.total || 0);
          if (pub)
            pub.disabled = !(
              materialsCatalogCanPublishAfterImages && fullyPrepared
            );
          if (status && materialsCatalogCanPublishAfterImages) {
            status.textContent = fullyPrepared
              ? "100% voorbereid, maar nog niet actief in Tool A. Klik nu op Catalogus publiceren."
              : "Niet alle afbeeldingen konden worden voorbereid. Probeer de mislukte afbeeldingen opnieuw; publiceren blijft geblokkeerd.";
          }
        }
      }
    }
  }
  function materialsCatalogStartPolling() {
    if (materialsCatalogPollTimer) clearInterval(materialsCatalogPollTimer);
    materialsCatalogPollTimer = setInterval(materialsCatalogPollImages, 2000);
    materialsCatalogPollImages();
  }
  async function materialsCatalogPublish() {
    ToolAErrors.assertHealthy();
    const status = document.getElementById("matCsvStatus");
    const btn = document.getElementById("matCsvPublishBtn");
    if (!materialsCatalogImportId) {
      if (status) status.textContent = "Controleer eerst de CSV.";
      return;
    }
    const reviewSha256 = String(
      materialsCatalogLastPreview?.reviewSha256 || "",
    );
    if (!/^[a-f0-9]{64}$/.test(reviewSha256)) {
      if (status)
        status.textContent =
          "Controlebewijs ontbreekt. Controleer de CSV opnieuw.";
      return;
    }
    const warningCount = Number(
      materialsCatalogLastPreview?.warnings?.length || 0,
    );
    const excludedCount = Number(
      materialsCatalogLastPreview?.excluded?.length || 0,
    );
    if (
      !confirm(
        `Nieuwe catalogus publiceren en expliciet aftekenen? Je bevestigt ${warningCount} waarschuwing(en) en ${excludedCount} uitgesloten regel(s). De actieve Decor Library wordt exact vervangen door de toegestane 18/19/20-mm producten uit deze CSV. Producten die niet meer in de CSV staan verdwijnen uit Tool A. Er wordt vooraf automatisch een volledige snapshot gemaakt.`,
      )
    )
      return;
    try {
      if (btn) btn.disabled = true;
      if (status) status.textContent = "Catalogus veilig publiceren…";
      const r = await fetch("/api/admin/materials/catalog_publish", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          importId: materialsCatalogImportId,
          reviewSha256,
        }),
      });
      const j = await r.json().catch(() => ({}));
      if (!r.ok || !j.ok) throw new Error(j.error || "HTTP " + r.status);
      if (status)
        status.textContent = `Actief in Tool A: ${j.published || 0} CSV-producten en ${j.preparedImages || 0} voorbereide afbeeldingen gepubliceerd · ${j.excludedThickness || 0} door diktefilter uitgesloten · ${j.removedFromActive || 0} niet meer in bron verwijderd · snapshot ${j.snapshot || "gemaakt"}.`;
      await materialsReload();
      await reloadPricing();
      materialsCatalogCanPublishAfterImages = false;
      materialsCatalogRenderSync({
        ok: true,
        state: "DONE",
        published: true,
        total: Number(j.preparedImages || 0),
        processed: Number(j.preparedImages || 0),
        success: Number(j.preparedImages || 0),
        failed: 0,
      });
    } catch (e) {
      if (status) status.textContent = "Fout: " + (e?.message || e);
      if (btn) btn.disabled = false;
    }
  }
  async function materialsCatalogRetryImages() {
    ToolAErrors.assertHealthy();
    if (!materialsCatalogImportId) return;
    const status = document.getElementById("matCsvStatus");
    try {
      const r = await fetch("/api/admin/materials/catalog_retry_images", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ importId: materialsCatalogImportId }),
      });
      const j = await r.json().catch(() => ({}));
      if (!r.ok || !j.ok) throw new Error(j.error || "HTTP " + r.status);
      if (status)
        status.textContent =
          "Afbeeldingen opnieuw voorbereiden gestart. Publiceren wordt vrijgegeven zodra alles gelukt is.";
      materialsCatalogStartPolling();
    } catch (e) {
      if (status)
        status.textContent =
          "Afbeeldingen opnieuw proberen mislukt: " + (e?.message || e);
    }
  }

  function materialsResetFilters() {
    const ids = [
      "materialsFilterThickness",
      "materialsFilterDimension",
      "materialsFilterCategory",
      "materialsFilterBrandText",
      "materialsFilterAvailability",
    ];
    ids.forEach((id) => {
      const el = document.getElementById(id);
      if (el) el.value = "";
    });
    materialsRenderList();
  }
  function initMaterialsManager() {
    if (window.__materialsManagerInit) return;
    window.__materialsManagerInit = true;
    const s = document.getElementById("materialsSearch");
    if (s) s.addEventListener("input", () => materialsRenderList());
    const toggle = document.getElementById("materialsFiltersToggle");
    if (toggle)
      toggle.addEventListener("click", () => materialsToggleFilters());
    const reset = document.getElementById("materialsResetFiltersBtn");
    if (reset) reset.addEventListener("click", materialsResetFilters);
    [
      "materialsFilterThickness",
      "materialsFilterDimension",
      "materialsFilterCategory",
      "materialsFilterBrandText",
      "materialsFilterAvailability",
    ].forEach((id) => {
      const el = document.getElementById(id);
      if (el)
        el.addEventListener(
          id === "materialsFilterBrandText" ? "input" : "change",
          () => materialsRenderList(),
        );
    });
    const csvPreview = document.getElementById("matCsvPreviewBtn");
    if (csvPreview)
      csvPreview.addEventListener("click", materialsCatalogPreview);
    const csvPublish = document.getElementById("matCsvPublishBtn");
    if (csvPublish)
      csvPublish.addEventListener("click", materialsCatalogPublish);
    const csvInput = document.getElementById("matCsvInput");
    if (csvInput)
      csvInput.addEventListener("change", () => {
        materialsCatalogImportId = "";
        materialsCatalogCanPublishAfterImages = false;
        if (materialsCatalogPollTimer) {
          clearInterval(materialsCatalogPollTimer);
          materialsCatalogPollTimer = null;
        }
        const pub = document.getElementById("matCsvPublishBtn");
        if (pub) pub.disabled = true;
        const status = document.getElementById("matCsvStatus");
        if (status)
          status.textContent = csvInput.files?.length
            ? "CSV gekozen. Klik op “CSV controleren”."
            : "Nog geen CSV gekozen.";
        const summary = document.getElementById("matCsvSummary");
        if (summary) {
          setAdminRuntimeDisplay(summary, "none");
          summary.innerHTML = "";
        }
        const notices = document.getElementById("matCsvNotices");
        if (notices) {
          setAdminRuntimeDisplay(notices, "none");
          notices.innerHTML = "";
        }
      });
    materialsUpdateFiltersToggleLabel();
  }

  async function loadControlCenter() {
    const el = document.getElementById("ccOut");
    if (!el) return;
    try {
      const r = await fetch("/api/admin/control_center", { cache: "no-store" });
      const j = await r.json();
      const v = j.versions || {};
      const s = j.storage || {};
      const f = j.failures || [];
      const pricing = v.pricing || {};
      const materials = v.materials || {};
      const dxf = v.dxfLibrary || {};
      const opt = v.optimizer || {};
      function fmtBytes(n) {
        n = Number(n || 0);
        const u = ["B", "KB", "MB", "GB", "TB"];
        let i = 0;
        while (n >= 1024 && i < u.length - 1) {
          n /= 1024;
          i++;
        }
        return (i === 0 ? String(Math.round(n)) : n.toFixed(1)) + " " + u[i];
      }
      let html = "";
      html += `<div class="admin-display-grid-gap-8px">`;
      html += `<div><b>Actief nu</b></div>`;
      html += `<div>💶 Prijzen: <code>${pricing.exists ? "pricing_active.json" : "—"}</code> <span class="muted">${pricing.modified ? "(" + pricing.modified + ")" : ""}</span></div>`;
      html += `<div>🪵 Materialen: <code>${materials.file || "material_library.json"}</code> <span class="muted">${materials.modified ? "(" + materials.modified + ")" : ""}</span></div>`;
      html += `<div>📐 DXF lijst: <code>${dxf.file || "embedded_dxfs_manifest.json"}</code> <span class="muted">${dxf.modified ? "(" + dxf.modified + ")" : ""}</span></div>`;
      html += `<div>🧠 Optimizer: <code>${opt.active || "—"}</code></div>`;
      html += `<hr class="admin-border-0-border-top-1px-solid-line">`;
      html += `<div><b>Opslag</b></div>`;
      html += `<div>Jobs: <code>${s.jobsCount ?? "—"}</code> · Grootte jobs-map: <code>${fmtBytes(s.jobsBytes || 0)}</code></div>`;
      if (s.largestJob && s.largestJob.jobId) {
        html += `<div>Grootste job: <code>${_h(s.largestJob.jobId)}</code> · <code>${fmtBytes(s.largestJob.bytes || 0)}</code></div>`;
      }
      if (f && f.length) {
        html += `<hr class="admin-border-0-border-top-1px-solid-line">`;
        html += `<div><b>Laatste fouten</b> <span class="muted">(laatste 5)</span></div>`;
        for (const x of f) {
          html +=
            `<div class="admin-border-1px-solid-line-border-radius-8px">` +
            `<div><code>${_h(x.jobId || "")}</code> <span class="muted">${_h(x.modified || "")}</span></div>` +
            `<div class="muted admin-white-space-pre-wrap-overflow-wrap-anywhere">${_h(x.excerpt || "")}</div>` +
            `</div>`;
        }
      } else {
        html += `<div class="muted">Geen recente fouten gevonden.</div>`;
      }
      html += `</div>`;
      el.className = "";
      el.innerHTML = html;
    } catch (e) {
      el.className = "muted";
      el.textContent =
        "Kon beheer-info niet laden: " + (e && e.message ? e.message : e);
    }
  }

  // --- Admin inbox: one owner for list, selection, requests and actions. ---
  const AdminInbox = (() => {
    "use strict";
    const labels = {
      inbox: "Nieuw",
      processing: "In behandeling",
      errors: "Aandacht",
      done: "Afgehandeld",
      cancelled: "Geannuleerd",
      all: "Alles",
    };
    const sorts = {
      newest: "nieuwste eerst",
      oldest: "oudste eerst",
      name: "klant A–Z",
    };
    const pageSizes = [10, 25, 50, 100];
    const state = {
      tab: "inbox",
      query: "",
      sort: "newest",
      size: 25,
      page: 1,
      rows: [],
      total: 0,
      pageCount: 1,
      counts: null,
      skipped: 0,
      loaded: false,
      loading: false,
      listError: null,
      selectedId: null,
      selected: null,
      detailLoading: false,
      detailError: null,
      confirmation: null,
      pendingAction: null,
      autoSelect: true,
    };
    let root;
    let initialized = false;
    let searchTimer = null;
    let composing = false;
    let listEpoch = 0;
    let detailEpoch = 0;
    let fileEpoch = 0;
    let listController = null;
    let detailController = null;
    let fileController = null;
    const actionMessages = new Map();
    const uncertainActions = new Set();
    const moneyFormatter = new Intl.NumberFormat("nl-NL", {
      style: "currency",
      currency: "EUR",
    });
    const shortDate = new Intl.DateTimeFormat("nl-NL", {
      day: "numeric",
      month: "short",
    });
    const longDate = new Intl.DateTimeFormat("nl-NL", {
      day: "numeric",
      month: "long",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
    const time = new Intl.DateTimeFormat("nl-NL", {
      hour: "2-digit",
      minute: "2-digit",
    });
    const byId = (id) => root.querySelector("#" + id);
    const announce = (text) => {
      byId("mbFeedback").textContent = text;
    };
    const focusWithoutScroll = (element) => {
      if (element) element.focus({ preventScroll: true });
    };
    const upper = (value) => String(value || "").toUpperCase();
    const validId = (value) =>
      typeof value === "string" &&
      /^[A-Za-z0-9][A-Za-z0-9_-]{0,119}$/.test(value);

    class InboxError extends Error {
      constructor(message, kind = "server") {
        super(message);
        this.kind = kind;
      }
    }

    async function requestJson(url, { signal, body, timeoutMs = 15000 } = {}) {
      if (body !== undefined) ToolAErrors.assertHealthy();
      const controller = new AbortController();
      const forwardAbort = () => controller.abort();
      if (signal?.aborted) controller.abort();
      else signal?.addEventListener("abort", forwardAbort, { once: true });
      let timedOut = false;
      const timer = setTimeout(() => {
        timedOut = true;
        controller.abort();
      }, timeoutMs);
      try {
        const response = await fetch(url, {
          method: body === undefined ? "GET" : "POST",
          credentials: "same-origin",
          cache: "no-store",
          signal: controller.signal,
          headers:
            body === undefined
              ? { Accept: "application/json" }
              : {
                  Accept: "application/json",
                  "Content-Type": "application/json",
                },
          ...(body === undefined ? {} : { body: JSON.stringify(body) }),
        });
        if (
          response.status === 401 ||
          response.status === 403 ||
          response.redirected
        ) {
          throw new InboxError(
            "Je sessie is verlopen of je hebt geen toegang. Log opnieuw in.",
            "auth",
          );
        }
        let data;
        try {
          data = await response.json();
        } catch (error) {
          if (controller.signal.aborted) throw error;
          throw new InboxError(
            "De server gaf geen geldig antwoord. Probeer opnieuw.",
            "invalid",
          );
        }
        if (data?.authRequired)
          throw new InboxError(
            "Je sessie is verlopen. Log opnieuw in.",
            "auth",
          );
        if (!response.ok || data?.ok !== true) {
          if (response.status === 404)
            throw new InboxError(
              "Deze aanvraag is niet meer beschikbaar.",
              "missing",
            );
          if (response.status === 409)
            throw new InboxError(
              "De aanvraag is ondertussen gewijzigd. Vernieuw de status voordat je verdergaat.",
              "conflict",
            );
          throw new InboxError(
            "De server kon deze actie niet uitvoeren. Probeer opnieuw.",
            "server",
          );
        }
        return data;
      } catch (error) {
        if (signal?.aborted)
          throw new InboxError("Verzoek vervangen.", "superseded");
        if (timedOut)
          throw new InboxError(
            "Het laden duurt te lang. Probeer opnieuw.",
            "timeout",
          );
        if (error instanceof InboxError) throw error;
        throw new InboxError(
          "Geen verbinding met de server. Controleer je verbinding en probeer opnieuw.",
          "network",
        );
      } finally {
        clearTimeout(timer);
        signal?.removeEventListener("abort", forwardAbort);
      }
    }

    function errorMarkup(error, retryAction) {
      const retry =
        error.kind === "auth"
          ? '<a class="inbox-control" href="/admin/">Opnieuw inloggen</a>'
          : `<button type="button" class="inbox-control" data-inbox-action="${retryAction}">Opnieuw proberen</button>`;
      return `<p>${esc(error.message)}</p>${retry}`;
    }

    function formatDate(value, detailed = false) {
      const date = new Date(value || "");
      if (!Number.isFinite(date.getTime())) return "Datum onbekend";
      return (detailed ? longDate : shortDate).format(date);
    }

    function statusMarkup(record) {
      const category = record.mailboxCategory;
      return `<span class="inbox-state" data-status="${esc(category || "errors")}">${esc(labels[category] || "Aandacht")}</span>`;
    }

    function readHash() {
      if (!location.hash.startsWith("#request=")) return null;
      try {
        const id = decodeURIComponent(location.hash.slice(9));
        return validId(id) ? id : null;
      } catch (_error) {
        return null;
      }
    }

    function writeHash(id) {
      {
        const hash = id ? "#request=" + encodeURIComponent(id) : "";
        history.replaceState(
          history.state,
          "",
          location.pathname + location.search + hash,
        );
      }
    }

    function renderListState() {
      root
        .querySelectorAll("[data-tab]")
        .forEach((button) =>
          button.setAttribute(
            "aria-pressed",
            String(button.dataset.tab === state.tab),
          ),
        );
      byId("mbRows").setAttribute("aria-busy", String(state.loading));
      byId("mbRefreshBtn").disabled = state.loading;
      byId("mbPrev").disabled =
        state.loading || !state.loaded || !!state.listError || state.page <= 1;
      byId("mbNext").disabled =
        state.loading ||
        !state.loaded ||
        !!state.listError ||
        state.page >= state.pageCount;
      byId("mbScope").textContent =
        labels[state.tab] + " · " + sorts[state.sort];
      byId("mbListStatus").textContent = state.loading
        ? state.loaded
          ? "Overzicht vernieuwen… De vorige resultaten blijven even staan."
          : "Aanvragen laden…"
        : state.listError
          ? state.loaded
            ? "Dit is het laatst geladen overzicht."
            : "Het overzicht is nog niet geladen."
          : state.skipped
            ? `${state.skipped} aanvraagbestand(en) konden niet worden gelezen. Het overzicht is onvolledig.`
            : state.query
              ? "Zoekresultaten binnen " +
                labels[state.tab] +
                ". De tellingen tonen ook resultaten in andere categorieën."
              : "";
      const errorBox = byId("mbListError");
      errorBox.hidden = !state.listError;
      errorBox.innerHTML = state.listError
        ? errorMarkup(state.listError, "retry-list")
        : "";
      byId("mbEmpty").hidden =
        !state.loaded ||
        state.loading ||
        !!state.listError ||
        state.rows.length > 0;
    }

    function renderSelection() {
      root
        .querySelectorAll("[data-request]")
        .forEach((button) =>
          button.setAttribute(
            "aria-pressed",
            String(button.dataset.request === state.selectedId),
          ),
        );
      byId("mbDetailLabel").textContent =
        state.selectedId &&
        !state.rows.some((row) => row.requestId === state.selectedId)
          ? "Eerder geopende aanvraag"
          : "Geselecteerde aanvraag";
    }

    function renderRows() {
      byId("mbRows").innerHTML = state.rows
        .map((record) => {
          const stamp = new Date(record.createdAt || record.updatedAt || "");
          const validStamp = Number.isFinite(stamp.getTime());
          const date =
            validStamp && stamp.toDateString() === new Date().toDateString()
              ? "Vandaag"
              : formatDate(record.createdAt || record.updatedAt);
          return `<li><button type="button" class="inbox-order" data-request="${esc(record.requestId)}" aria-pressed="${record.requestId === state.selectedId}" aria-label="Open ${esc(record.customer?.name || "Onbekende klant")}, ${esc(record.requestId)}"><span class="inbox-person"><span class="inbox-name">${esc(record.customer?.name || "Onbekende klant")}</span><span class="inbox-id">${esc(record.requestId)}</span></span><span class="inbox-date">${esc(date)}${validStamp ? `<small>${esc(time.format(stamp))}</small>` : ""}</span>${statusMarkup(record)}</button></li>`;
        })
        .join("");
      root.querySelectorAll("[data-count]").forEach((node) => {
        node.textContent = String(state.counts[node.dataset.count]);
      });
      const first = (state.page - 1) * state.size + 1;
      byId("mbRange").textContent = state.total
        ? `${first}–${first + state.rows.length - 1} van ${state.total} aanvragen`
        : "0 aanvragen";
      byId("mbPage").textContent = `${state.page} / ${state.pageCount}`;
      byId("mbEmptyText").textContent = state.query
        ? `Geen resultaat binnen ${labels[state.tab]}. ${state.tab === "all" ? "Pas je zoekopdracht aan." : "Pas je zoekopdracht aan of kies Alles."}`
        : `Er staan momenteel geen aanvragen in ${labels[state.tab]}.`;
      renderSelection();
      renderListState();
    }

    function validatePage(data) {
      const isNatural = (value) => Number.isSafeInteger(value) && value >= 0;
      if (
        !Array.isArray(data.requests) ||
        data.requests.length > state.size ||
        !data.requests.every((row) => row && validId(row.requestId)) ||
        !isNatural(data.total) ||
        !isNatural(data.page) ||
        data.page < 1 ||
        !isNatural(data.pageCount) ||
        data.pageCount < data.page ||
        data.pageSize !== state.size ||
        !data.counts ||
        !["inbox", "processing", "errors", "done", "all"].every((key) =>
          isNatural(data.counts[key]),
        ) ||
        new Set(data.requests.map((row) => row.requestId)).size !==
          data.requests.length
      ) {
        throw new InboxError(
          "Het inboxantwoord is onvolledig. Probeer opnieuw.",
          "invalid",
        );
      }
    }

    function invalidateList() {
      listEpoch++;
      listController?.abort();
      state.loading = true;
      state.listError = null;
      renderListState();
    }

    async function loadList({ focusFirst = false } = {}) {
      clearTimeout(searchTimer);
      const focusOwner = document.activeElement;
      const epoch = ++listEpoch;
      listController?.abort();
      listController = new AbortController();
      state.loading = true;
      state.listError = null;
      renderListState();
      const query = new URLSearchParams({
        page: String(state.page),
        pageSize: String(state.size),
        category: state.tab,
        sort: state.sort,
        q: state.query,
      });
      try {
        const data = await requestJson("/api/admin/requests?" + query, {
          signal: listController.signal,
        });
        if (epoch !== listEpoch) return;
        validatePage(data);
        state.rows = data.requests;
        state.total = data.total;
        state.counts = data.counts;
        state.page = data.page;
        state.pageCount = data.pageCount;
        state.skipped = Number.isSafeInteger(data.skippedCount)
          ? data.skippedCount
          : 0;
        state.loaded = true;
        state.loading = false;
        byId("mbUpdated").textContent =
          "Bijgewerkt om " + time.format(new Date());
        renderRows();
        // Explicit page navigation uses native focus scrolling, never a viewport timer.
        // Do not steal focus if the user started another interaction while waiting.
        if (focusFirst && document.activeElement === focusOwner) {
          (
            root.querySelector("[data-request]") || byId("mbRefreshBtn")
          ).focus();
        }
        if (state.autoSelect && state.rows.length) {
          state.autoSelect = false;
          selectRequest(state.rows[0].requestId, {
            showMobile: false,
            updateHash: false,
          });
        }
      } catch (error) {
        if (epoch !== listEpoch || error.kind === "superseded") return;
        state.listError = error;
      } finally {
        if (epoch === listEpoch) {
          state.loading = false;
          renderListState();
        }
      }
    }

    function availableAction(record) {
      if (
        !record ||
        upper(record.publicStatus) === "CANCELLED" ||
        upper(record.internalStatus) === "CANCELLED"
      )
        return null;
      if (
        upper(record.publicStatus) === "SUBMITTED" &&
        upper(record.quoteStatus) === "TODO"
      )
        return "mark_quote_sent";
      if (["DONE", "AFGEHANDELD"].includes(upper(record.publicStatus)))
        return "reopen";
      return null;
    }

    function customerDetailsMarkup(customer) {
      const data = customer && typeof customer === "object" ? customer : {};
      const first = (...keys) =>
        keys.map((key) => String(data[key] ?? "").trim()).find(Boolean) || "";
      const address = (shipping) => {
        const street = shipping
          ? first("shippingAddress", "deliveryAddress")
          : first("billingAddress", "invoiceAddress", "address", "street");
        const house = shipping
          ? first("shippingHouseNumber", "deliveryHouseNumber")
          : first("houseNumber");
        const postal = shipping
          ? first("shippingPostcode", "deliveryPostcode")
          : first("postcode", "postalCode");
        const city = shipping
          ? first("shippingCity", "deliveryCity")
          : first("city", "plaats");
        const country = shipping
          ? first("shippingCountry", "deliveryCountry")
          : first("country");
        const streetLine =
          street && house && !street.split(/\s+/).includes(house)
            ? `${street} ${house}`
            : street || house;
        return [
          streetLine,
          [postal, city].filter(Boolean).join(" "),
          country,
        ].filter(Boolean);
      };
      const billing = address(false);
      const shipping =
        data.shippingSameAsBilling === true ? billing : address(true);
      const different =
        shipping.length > 0 && shipping.join("\n") !== billing.join("\n");
      const lines = (values) =>
        values.length ? values.map(esc).join("<br>") : "Niet opgegeven";
      const company = first("company", "companyName");
      const note = first("note");
      return `<section class="inbox-detailsection inbox-customer-details" aria-label="Adres en klantopmerking">
        ${company ? `<h4>Bedrijf</h4><p data-customer-company>${esc(company)}</p>` : ""}
        <div class="inbox-addresses"><div><h4>Factuuradres</h4><p data-customer-billing>${lines(billing)}</p></div>
        <div><h4>Bezorgadres${different ? ' <span class="inbox-address-different">Afwijkend bezorgadres</span>' : ""}</h4>
        <p data-customer-shipping>${data.shippingSameAsBilling === true || (shipping.length && !different) ? "Gelijk aan factuuradres" : lines(shipping)}</p></div></div>
        <h4>Klantopmerking</h4><p class="inbox-customer-note" data-customer-note>${esc(note || "Geen opmerking opgegeven")}</p>
      </section>`;
    }

    function renderDetails() {
      const record = state.selected;
      const body = byId("mbDetailsBody");
      const message = byId("mbActionMessage");
      const actionMessage = actionMessages.get(state.selectedId);
      message.hidden = !actionMessage;
      message.textContent = actionMessage || "";
      byId("mbTechnical").hidden = !record;
      if (!state.selectedId) {
        body.innerHTML =
          '<div class="inbox-detailblank">Open een aanvraag om klantgegevens, bestanden en acties te bekijken.</div>';
        byId("mbFilesBox").hidden = true;
        return;
      }
      const error = state.detailError
        ? `<div class="inbox-errornotice" role="alert">${errorMarkup(state.detailError, "retry-detail")}</div>`
        : "";
      if (!record) {
        body.innerHTML = `<div class="inbox-detailsection"><span class="inbox-id">${esc(state.selectedId)}</span>${error || "<p>Aanvraag laden…</p>"}</div>`;
        return;
      }
      const action = availableAction(record);
      const blocked =
        state.detailLoading ||
        !!state.detailError ||
        !!state.pendingAction ||
        uncertainActions.has(state.selectedId);
      let actions = "";
      if (action) {
        const mark = action === "mark_quote_sent";
        actions =
          state.confirmation === state.selectedId && !blocked
            ? `<div class="inbox-actions inbox-confirm"><p>${mark ? "Deze aanvraag naar Afgehandeld verplaatsen?" : "Deze aanvraag opnieuw openen?"} Er wordt geen e-mail verstuurd.</p><div class="inbox-confirmbuttons"><button type="button" class="inbox-control inbox-primary" data-inbox-action="confirm">${mark ? "Ja, afhandelen" : "Ja, heropenen"}</button><button type="button" class="inbox-control" data-inbox-action="cancel-confirm">Annuleren</button></div></div>`
            : `<div class="inbox-actions"><button type="button" class="inbox-control ${mark ? "inbox-primary" : ""}" data-inbox-action="start-confirm" ${blocked ? "disabled" : ""}>${state.pendingAction === state.selectedId ? "Bezig met opslaan…" : mark ? "Aanvraag afhandelen" : "Aanvraag heropenen"}</button></div>`;
      }
      const uncertain = uncertainActions.has(state.selectedId)
        ? '<div class="inbox-errornotice"><p>De uitkomst van de vorige actie is nog niet bevestigd.</p><button type="button" class="inbox-control" data-inbox-action="retry-detail">Vernieuw status</button></div>'
        : "";
      const warning =
        record.mailboxCategory === "errors"
          ? '<p class="inbox-errornotice">Deze aanvraag vraagt aandacht. Bekijk de technische gegevens voordat je verdergaat.</p>'
          : "";
      body.innerHTML = `<section class="inbox-detailsection">${statusMarkup(record)}<h3>${esc(record.customer?.name || "Onbekende klant")}</h3><span class="inbox-id">${esc(record.requestId)}</span><p class="inbox-detaildate">Ontvangen ${esc(formatDate(record.createdAt || record.updatedAt, true))}</p><div class="inbox-contact"><span><span class="inbox-label">E-mail</span><br>${esc(record.customer?.email || "Niet opgegeven")}</span><span><span class="inbox-label">Telefoon</span><br>${esc(record.customer?.phone || "Niet opgegeven")}</span></div>${state.detailLoading ? '<p class="inbox-detaildate">Status actualiseren…</p>' : ""}${error}${warning}${uncertain}${actions}</section>${customerDetailsMarkup(record.customer)}`;
      const subjobs = Array.isArray(record.job?.subjobs)
        ? record.job.subjobs.length
        : 0;
      byId("mbTechnicalBody").innerHTML =
        `<dl><dt>Aanvraagstatus</dt><dd>${esc(record.publicStatusLabel || "")} ${esc(record.publicStatus || "—")}</dd><dt>Interne status</dt><dd>${esc(record.internalStatusLabel || "")} ${esc(record.internalStatus || "—")}</dd><dt>Offertestatus</dt><dd>${esc(record.quoteStatus || "—")}</dd><dt>Job</dt><dd>${esc(record.job?.parentJobId || "—")}</dd><dt>Subjobs</dt><dd>${subjobs}</dd></dl>${record.error ? `<pre>${esc(JSON.stringify(record.error, null, 2))}</pre>` : ""}`;
      renderSelection();
    }

    function downloadUrl(value, id) {
      if (typeof value !== "string" || !value.startsWith("/api/admin/"))
        return null;
      try {
        const url = new URL(value, location.origin);
        if (
          url.origin !== location.origin ||
          ![
            "/api/admin/request_file",
            "/api/admin/request_download_zip",
          ].includes(url.pathname) ||
          url.searchParams.getAll("requestId").length !== 1 ||
          url.searchParams.get("requestId") !== id
        )
          return null;
        return url.pathname + url.search;
      } catch (_error) {
        return null;
      }
    }

    function fileLink(file, label, id) {
      const href = downloadUrl(file?.url, id);
      return href
        ? `<a class="inbox-control" href="${esc(href)}" download>${esc(label)}<span class="inbox-label" aria-hidden="true">↓</span></a>`
        : "";
    }

    function pricingMarkup(pricing) {
      if (!pricing || typeof pricing !== "object") return "";
      const values = [
        ["Plaatmateriaal excl. btw", pricing.materialsTotal],
        ["Kantenband excl. btw", pricing.edgeBandTotal],
        ["CNC excl. btw", pricing.cncTotal],
        ["Tekenen excl. btw", pricing.drawingTotal],
        ["Transport excl. btw", pricing.transportTotal],
        ["Subtotaal excl. btw", pricing.subtotalExVat],
        ["Totaal incl. btw", pricing.totalInclVat],
      ];
      const rows = values.filter(
        ([, value]) => typeof value === "number" && Number.isFinite(value),
      );
      if (!rows.length) return "";
      return `<section class="inbox-detailsection"><h4>Prijs bij aanvraag</h4><dl class="inbox-totals">${rows.map(([label, value]) => `<dt${label === "Totaal incl. btw" ? ' class="inbox-total"' : ""}>${esc(label)}</dt><dd${label === "Totaal incl. btw" ? ' class="inbox-total"' : ""}>${esc(moneyFormatter.format(value))}</dd>`).join("")}</dl></section>`;
    }

    function formatBytes(value) {
      if (!Number.isFinite(value) || value < 0) return "—";
      const units = ["B", "KB", "MB", "GB", "TB"];
      let unit = 0;
      while (value >= 1024 && unit < units.length - 1) {
        value /= 1024;
        unit++;
      }
      return (
        new Intl.NumberFormat("nl-NL", {
          maximumFractionDigits: unit ? 1 : 0,
        }).format(value) +
        " " +
        units[unit]
      );
    }

    function renderFiles(manifest, id) {
      const summaries = Array.isArray(manifest.summaryFiles)
        ? manifest.summaryFiles
        : [];
      const groups = Array.isArray(manifest.dxfGroups)
        ? manifest.dxfGroups
        : [];
      const allFiles = Array.isArray(manifest.allFiles)
        ? manifest.allFiles
        : [];
      const fileLabels = {
        quote: "Offerte",
        report: "Rapport",
        placements: "Plaatsingen",
        stickers: "Stickers",
        stickertool: "Stickertool",
        summary: "Berekening",
        pricing: "Prijsbestand",
      };
      const primary = [];
      if (allFiles.length)
        primary.push(
          fileLink(
            { url: manifest.zip?.allOutputsUrl },
            "Alle bestanden · ZIP",
            id,
          ),
        );
      for (const file of summaries.filter((file) => file.kind === "quote"))
        primary.push(
          fileLink(
            file,
            "Offerte" + (file.materialName ? " · " + file.materialName : ""),
            id,
          ),
        );
      if (allFiles.some((file) => file.kind === "dxf"))
        primary.push(
          fileLink(
            { url: manifest.zip?.allDxfUrl },
            "Alle DXF-bestanden · ZIP",
            id,
          ),
        );
      const others = summaries
        .filter((file) => file.kind !== "quote")
        .map((file) =>
          fileLink(
            file,
            (fileLabels[file.kind] || file.name || "Bestand") +
              (file.materialName ? " · " + file.materialName : ""),
            id,
          ),
        )
        .join("");
      const dxf = groups
        .map(
          (group) =>
            `<details class="inbox-filesmore"><summary>${esc(group.label || group.materialName || "DXF-bestanden")}</summary><div class="inbox-downloads">${(Array.isArray(group.files) ? group.files : []).map((file) => fileLink(file, file.downloadName || file.name || "DXF-bestand", id)).join("")}</div></details>`,
        )
        .join("");
      const storage = manifest.storageSummary;
      const storageMarkup =
        storage && Number.isFinite(storage.totalBytes) && storage.totalBytes > 0
          ? `<details class="inbox-filesmore"><summary>Opslag · ${esc(formatBytes(storage.totalBytes))}</summary><dl class="inbox-totals"><dt>Aanvraag</dt><dd>${esc(formatBytes(storage.requestBytes))}</dd><dt>Jobs</dt><dd>${esc(formatBytes(storage.jobsBytes))}</dd></dl></details>`
          : "";
      const downloads = primary.join("") || others || dxf;
      byId("mbFilesBox").innerHTML =
        pricingMarkup(manifest.pricingSummary) +
        `<section class="inbox-detailsection"><h4>Bestanden</h4>${downloads ? `<div class="inbox-downloads">${primary.join("")}</div>${others ? `<details class="inbox-filesmore"><summary>Overige bestanden</summary><div class="inbox-downloads">${others}</div></details>` : ""}${dxf}` : '<p class="inbox-label">Er zijn nog geen bestanden beschikbaar voor deze aanvraag.</p>'}${storageMarkup}</section>`;
    }

    async function loadFiles(id) {
      const epoch = ++fileEpoch;
      fileController?.abort();
      fileController = new AbortController();
      const box = byId("mbFilesBox");
      box.hidden = false;
      box.innerHTML =
        '<div class="inbox-detailsection inbox-label">Bestanden laden…</div>';
      try {
        const data = await requestJson(
          "/api/admin/request_files?requestId=" + encodeURIComponent(id),
          { signal: fileController.signal, timeoutMs: 30000 },
        );
        if (epoch !== fileEpoch || id !== state.selectedId) return;
        if (data.requestId !== id || !data.files || data.files.requestId !== id)
          throw new InboxError(
            "De bestanden konden niet aan deze aanvraag worden gekoppeld.",
            "invalid",
          );
        renderFiles(data.files, id);
      } catch (error) {
        if (
          epoch !== fileEpoch ||
          id !== state.selectedId ||
          error.kind === "superseded"
        )
          return;
        box.innerHTML = `<div class="inbox-detailsection"><div class="inbox-errornotice" role="alert">${errorMarkup(error, "retry-files")}</div></div>`;
      }
    }

    async function loadSelected({ manual = false, reloadFiles = false } = {}) {
      const id = state.selectedId;
      if (!id) return;
      const epoch = ++detailEpoch;
      detailController?.abort();
      detailController = new AbortController();
      state.detailLoading = true;
      state.detailError = null;
      state.confirmation = null;
      renderDetails();
      try {
        const data = await requestJson(
          "/api/admin/requests?requestId=" + encodeURIComponent(id),
          {
            signal: detailController.signal,
          },
        );
        if (epoch !== detailEpoch || id !== state.selectedId) return;
        if (!data.request || data.request.requestId !== id)
          throw new InboxError(
            "De aanvraaggegevens zijn onvolledig.",
            "invalid",
          );
        state.selected = data.request;
        if (manual) {
          uncertainActions.delete(id);
          actionMessages.delete(id);
        }
        if (reloadFiles) loadFiles(id);
      } catch (error) {
        if (
          epoch !== detailEpoch ||
          id !== state.selectedId ||
          error.kind === "superseded"
        )
          return;
        state.detailError = error;
        if (error.kind === "missing" || error.kind === "auth") {
          state.selected = null;
          fileEpoch++;
          fileController?.abort();
          byId("mbFilesBox").hidden = true;
        }
      } finally {
        if (epoch === detailEpoch && id === state.selectedId) {
          state.detailLoading = false;
          renderDetails();
        }
      }
    }

    function selectRequest(id, { showMobile = true, updateHash = true } = {}) {
      if (!validId(id)) return;
      state.autoSelect = false;
      state.selectedId = id;
      state.selected = state.rows.find((row) => row.requestId === id) || null;
      state.detailError = null;
      state.confirmation = null;
      fileEpoch++;
      fileController?.abort();
      byId("mbFilesBox").innerHTML = "";
      byId("mbFilesBox").hidden = true;
      byId("mbTechnical").open = false;
      root.classList.toggle("inbox-detail-open", showMobile);
      if (updateHash) writeHash(id);
      renderSelection();
      loadSelected({ reloadFiles: true });
      if (showMobile && window.matchMedia("(max-width: 850px)").matches)
        byId("mbBack").focus();
      announce(
        "Aanvraag geopend: " + (state.selected?.customer?.name || id) + ".",
      );
    }

    function closeDetails({ clearSelection = true, updateHash = true } = {}) {
      const previous = state.selectedId;
      root.classList.remove("inbox-detail-open");
      state.autoSelect = false;
      state.confirmation = null;
      if (clearSelection) {
        detailEpoch++;
        fileEpoch++;
        detailController?.abort();
        fileController?.abort();
        state.selectedId = null;
        state.selected = null;
      }
      if (updateHash) writeHash(null);
      renderDetails();
      renderSelection();
      const focusTarget =
        Array.from(root.querySelectorAll("[data-request]")).find(
          (button) => button.dataset.request === previous,
        ) || byId("mbRefreshBtn");
      if (window.matchMedia("(max-width: 850px)").matches) focusTarget.focus();
      else focusWithoutScroll(focusTarget);
    }

    async function confirmAction() {
      const id = state.selectedId;
      const action = availableAction(state.selected);
      if (
        !id ||
        !action ||
        state.confirmation !== id ||
        state.pendingAction ||
        state.detailLoading ||
        state.detailError ||
        uncertainActions.has(id)
      )
        return;
      state.pendingAction = id;
      state.confirmation = null;
      actionMessages.delete(id);
      renderDetails();
      let succeeded = false;
      try {
        await requestJson("/api/admin/requests/update", {
          body: { requestId: id, action },
          timeoutMs: 20000,
        });
        succeeded = true;
        const message = `${id}: ${action === "reopen" ? "aanvraag heropend" : "aanvraag afgehandeld"}.`;
        actionMessages.set(id, message);
        announce(message);
      } catch (error) {
        const ambiguous = !["auth", "missing", "conflict"].includes(error.kind);
        if (ambiguous) uncertainActions.add(id);
        actionMessages.set(
          id,
          ambiguous
            ? "De server heeft de uitkomst niet bevestigd. De actie wordt niet automatisch herhaald."
            : error.message,
        );
        if (id === state.selectedId) state.detailError = error;
        announce(`${id}: ${actionMessages.get(id)}`);
      } finally {
        state.pendingAction = null;
        // A response for a closed or different request may never replace its details.
        if (id === state.selectedId) {
          if (succeeded) await loadSelected();
          else renderDetails();
        } else renderDetails();
        if (succeeded) await loadList();
      }
    }

    function changeQuery() {
      state.query = byId("mbSearch").value;
      state.page = 1;
      clearTimeout(searchTimer);
      invalidateList();
      if (!composing) searchTimer = setTimeout(loadList, 250);
    }

    function init() {
      if (initialized) return;
      root = document.getElementById("mbCard");
      if (!root) return;
      initialized = true;
      byId("mbPageSize").value = String(state.size);
      root.addEventListener("click", (event) => {
        const button = event.target.closest("button");
        if (!button || !root.contains(button) || button.disabled) return;
        if (button.dataset.tab) {
          state.tab = button.dataset.tab;
          state.page = 1;
          loadList();
        } else if (button.dataset.request)
          selectRequest(button.dataset.request);
        else if (button.dataset.inboxAction === "retry-list") loadList();
        else if (button.dataset.inboxAction === "retry-detail")
          loadSelected({ manual: true, reloadFiles: true });
        else if (
          button.dataset.inboxAction === "retry-files" &&
          state.selectedId
        )
          loadFiles(state.selectedId);
        else if (button.dataset.inboxAction === "start-confirm") {
          if (
            state.detailLoading ||
            state.detailError ||
            state.pendingAction ||
            uncertainActions.has(state.selectedId)
          )
            return;
          state.confirmation = state.selectedId;
          renderDetails();
          focusWithoutScroll(
            root.querySelector('[data-inbox-action="confirm"]'),
          );
        } else if (button.dataset.inboxAction === "cancel-confirm") {
          state.confirmation = null;
          renderDetails();
          focusWithoutScroll(
            root.querySelector('[data-inbox-action="start-confirm"]'),
          );
        } else if (button.dataset.inboxAction === "confirm") confirmAction();
      });
      byId("mbSearch").addEventListener("compositionstart", () => {
        composing = true;
        clearTimeout(searchTimer);
      });
      byId("mbSearch").addEventListener("compositionend", () => {
        composing = false;
        changeQuery();
      });
      byId("mbSearch").addEventListener("input", changeQuery);
      byId("mbSort").addEventListener("change", (event) => {
        state.sort = event.target.value;
        state.page = 1;
        loadList();
      });
      byId("mbPageSize").addEventListener("change", (event) => {
        const size = Number(event.target.value);
        if (!pageSizes.includes(size)) return;
        state.size = size;
        state.page = 1;
        loadList();
      });
      byId("mbPrev").addEventListener("click", () => {
        state.page--;
        loadList({ focusFirst: true });
      });
      byId("mbNext").addEventListener("click", () => {
        state.page++;
        loadList({ focusFirst: true });
      });
      byId("mbRefreshBtn").addEventListener("click", () => {
        loadList();
        if (state.selectedId && !state.pendingAction)
          loadSelected({ manual: true, reloadFiles: true });
      });
      byId("mbBack").addEventListener("click", () =>
        closeDetails({ clearSelection: false }),
      );
      byId("mbClose").addEventListener("click", () => closeDetails());
      byId("mbClear").addEventListener("click", () => {
        state.query = "";
        state.tab = "all";
        state.page = 1;
        byId("mbSearch").value = "";
        loadList();
        focusWithoutScroll(byId("mbSearch"));
      });
      window.addEventListener("hashchange", () => {
        const id = readHash();
        if (id) {
          switchAdminSection("inbox");
          selectRequest(id, { updateHash: false });
        } else if (!location.hash) closeDetails({ updateHash: false });
      });
      const requestedId = readHash();
      if (requestedId) selectRequest(requestedId, { updateHash: false });
      loadList();
    }

    return Object.freeze({ init });
  })();

  async function load() {
    initAdminShell();
    reloadPricing();
    loadControlCenter();
    initMaterialsManager();
    materialsReload();
    AdminInbox.init();
    const r = await fetch("/api/admin/jobs", {
      cache: "no-store",
      credentials: "same-origin",
    });
    const data = await r.json();
    const el = document.getElementById("out");
    if (!data.jobs.length) {
      el.innerHTML = '<div class="muted">Nog geen jobs.</div>';
      return;
    }
    let html =
      "<table><thead><tr><th>JobId</th><th>Status</th><th>Created</th><th>Outputs</th></tr></thead><tbody>";
    const childrenMap = {};
    const masters = [];
    const masterSet = new Set();
    for (const jj of data.jobs) {
      const id = String(jj.jobId || "");
      if (id.includes("__mat_")) {
        const master = id.split("__mat_")[0];
        (childrenMap[master] = childrenMap[master] || []).push(jj);
      } else {
        masters.push(jj);
        masterSet.add(id);
      }
    }

    function safeKey(s) {
      return String(s || "").replace(/[^a-zA-Z0-9_-]/g, "_");
    }

    function sealedMetaLinks(j) {
      const files = (j.sealedFiles || []).filter(
        (f) => String(f.kind || "") !== "dxf",
      );
      return files
        .map((f) => {
          const rel = String(f.rel || "");
          const name = String(f.name || rel || "bestand");
          const url = `/api/jobs/${encodeURIComponent(j.jobId)}/file/${encodeURIComponent(rel)}`;
          if (name === "calculation_summary.txt") {
            return (
              `<a class="btn admin-padding-7px-10px-font-size-12px" href="${url}" download>Berekening</a>` +
              `<button class="btn secondary admin-padding-7px-10px-font-size-12px-margin-2px-0" type="button" data-open-text-url="${esc(url)}" data-open-text-title="Berekening">Bekijk</button>`
            );
          }
          if (name === "stickertool.json") {
            return `<a class="btn admin-padding-7px-10px-font-size-12px-margin-2px-0-white-space-normal" href="${url}" download>stickertool.json (v2)</a>`;
          }
          return `<a class="btn secondary admin-padding-7px-10px-font-size-12px-margin-2px-0" href="${url}" download>${esc(name)}</a>`;
        })
        .join("");
    }

    for (const j of masters) {
      const jid = String(j.jobId || "");
      const gkey = safeKey(jid);
      const kids0 = childrenMap[j.jobId] || [];
      const kids = kids0.sort((a, b) =>
        String(a.jobId || "").localeCompare(String(b.jobId || "")),
      );
      const kidCount = kids.length;

      const dlZaag =
        j.zaagplaten && j.zaagplaten.length
          ? j.zaagplaten
              .map((z) => {
                const f = _zaagFile(z),
                  t = _zaagLabel(z);
                return `<a class="btn admin-padding-7px-10px-font-size-12px-margin-2px-0-white-space-normal-max-width-100" href="/api/jobs/${encodeURIComponent(j.jobId)}/file/${encodeURIComponent("output/DXF_Zaagplaten/" + f)}">${t}</a>`;
              })
              .join("")
          : "";
      const dlParts =
        j.onderdelen && j.onderdelen.length
          ? j.onderdelen
              .map(
                (s) =>
                  `<a class="btn admin-padding-7px-10px-font-size-12px-margin-2px-0-white-space-normal-max-width-100" href="/api/jobs/${encodeURIComponent(j.jobId)}/file/${encodeURIComponent("output/DXF_Onderdelen/" + s)}">${esc(s)}</a>`,
              )
              .join("")
          : "";
      const dlSheetsFallback =
        j.sheets && j.sheets.length
          ? j.sheets
              .map(
                (s) =>
                  `<a class="btn admin-padding-7px-10px-font-size-12px-margin-2px-0-white-space-normal-max-width-100" href="/api/jobs/${encodeURIComponent(j.jobId)}/download/${encodeURIComponent(s)}">${esc(s)}</a>`,
              )
              .join("")
          : "";
      const dlSheets =
        dlZaag || dlParts
          ? `<div class="admin-margin-bottom-6px"><span class="muted">Zaagplaten:</span> ${dlZaag || '<span class=\"muted\">—</span>'}</div>` +
            `<div><span class="muted">Onderdelen:</span> ${dlParts || '<span class=\"muted\">—</span>'}</div>`
          : dlSheetsFallback || '<span class="muted">—</span>';

      const dlMeta = sealedMetaLinks(j);

      const edgeDecor = j.edgeBandByDecorMeters || {};
      let edgeHtml = "";
      {
        const keys = Object.keys(edgeDecor || {});
        if (keys.length) {
          edgeHtml =
            '<div class="admin-margin-top-8px"><div class="muted admin-margin-bottom-6px">Kantenband per decor (m):</div>' +
            keys
              .map(
                (k) =>
                  `<div class="admin-display-flex-flex-wrap-wrap-justify-content-space-between-gap-8px"><div class="admin-flex-1-1-130px-min-width-0">${esc(k)}</div><div>${Number(edgeDecor[k] || 0).toFixed(2)}</div></div>`,
              )
              .join("") +
            `<div class="admin-display-flex-flex-wrap-wrap-justify-content-space-between-gap-8px"><div class="admin-flex-1-1-130px-min-width-0-font-weight-500">Totaal</div><div>${keys.reduce((a, k) => a + Number(edgeDecor[k] || 0), 0).toFixed(2)}</div></div>` +
            "</div>";
        }
      }

      const _cntZaag =
        j.zaagplaten && j.zaagplaten.length ? j.zaagplaten.length : 0;
      const _cntOnd =
        j.onderdelen && j.onderdelen.length ? j.onderdelen.length : 0;
      const _cntMeta = (j.sealedFiles || []).filter(
        (f) => String(f.kind || "") !== "dxf",
      ).length;
      const _sum = `DXF: ${_cntZaag + _cntOnd} · Overig: ${_cntMeta}`;
      const _body =
        `<div class="jobOutBody admin-display-flex-flex-wrap-wrap-gap-7px">${dlSheets}${dlMeta}</div>` +
        edgeHtml;
      const dl = `<details class="jobOut"><summary>${_sum}</summary>${_body}</details>`;
      const toggleBtn = kidCount
        ? `<button class="groupToggle" type="button" data-group="${gkey}" aria-expanded="false">▸</button>`
        : `<span class="admin-display-inline-block-width-34px-flex-shrink-0"></span>`;
      const kidBadge = kidCount
        ? `<span class="muted admin-color-muted">(${kidCount} materiaal)</span>`
        : "";
      html += `<tr class="masterRow" data-group="${gkey}"><td><div class="admin-display-flex-align-items-flex-start">${toggleBtn}<code>${_jobLabel(j)}</code>${kidBadge}</div></td><td>${esc(j.status || "")}</td><td class="muted">${esc(j.createdAt || "")}</td><td class="outputsTd"><div class="outputsCell">${dl}</div></td></tr>`;
      for (const c of kids) {
        // reuse dl generation by temporarily mapping j->c
        const j = c;
        const masterJobId = jid;

        const hasZaag = !!(j.zaagplaten && j.zaagplaten.length);
        const dlZaag =
          j.zaagplaten && j.zaagplaten.length
            ? j.zaagplaten
                .map((z) => {
                  const f = _zaagFile(z),
                    t = _zaagLabel(z);
                  return `<a class="btn admin-padding-7px-10px-font-size-12px-margin-2px-0-white-space-normal-max-width-100" href="/api/jobs/${encodeURIComponent(j.jobId)}/file/${encodeURIComponent("output/DXF_Zaagplaten/" + f)}">${t}</a>`;
                })
                .join("")
            : "";
        const dlParts =
          j.onderdelen && j.onderdelen.length
            ? j.onderdelen
                .map(
                  (s) =>
                    `<a class="btn admin-padding-7px-10px-font-size-12px-margin-2px-0-white-space-normal-max-width-100" href="/api/jobs/${encodeURIComponent(j.jobId)}/file/${encodeURIComponent("output/DXF_Onderdelen/" + s)}">${esc(s)}</a>`,
                )
                .join("")
            : "";
        const dlSheetsFallback =
          j.sheets && j.sheets.length
            ? j.sheets
                .map(
                  (s) =>
                    `<a class="btn admin-padding-7px-10px-font-size-12px-margin-2px-0-white-space-normal-max-width-100" href="/api/jobs/${encodeURIComponent(j.jobId)}/download/${encodeURIComponent(s)}">${esc(s)}</a>`,
                )
                .join("")
            : "";
        const partsCount =
          j.onderdelen && j.onderdelen.length ? j.onderdelen.length : 0;
        const partsBlock = partsCount
          ? `<details>` +
            `<summary class="muted">Onderdelen (${partsCount})</summary>` +
            `<div class="admin-display-flex-flex-wrap-wrap-gap-7px-margin-top-8px">${dlParts}</div>` +
            `</details>`
          : `<div><span class="muted">Onderdelen:</span> <span class="muted">—</span></div>`;

        const dlSheets =
          dlZaag || dlParts
            ? `<div class="admin-margin-bottom-6px"><span class="muted">Zaagplaten:</span> <div class="admin-display-flex-flex-wrap-wrap-gap-7px-margin-top-8px">${dlZaag || '<span class=\"muted\">—</span>'}</div></div>` +
              partsBlock
            : dlSheetsFallback || '<span class="muted">—</span>';
        const dlMeta = sealedMetaLinks(j);
        const _cntZaag =
          j.zaagplaten && j.zaagplaten.length ? j.zaagplaten.length : 0;
        const _cntOnd =
          j.onderdelen && j.onderdelen.length ? j.onderdelen.length : 0;
        const _cntMeta = (j.sealedFiles || []).filter(
          (f) => String(f.kind || "") !== "dxf",
        ).length;
        const _sum = `DXF: ${_cntZaag + _cntOnd} · Overig: ${_cntMeta}`;
        const _body = `<div class="jobOutBody admin-display-flex-flex-wrap-wrap-gap-7px">${dlSheets}${dlMeta}</div>`;
        const dl = `<details class="jobOut ${hasZaag ? "zaagHi" : ""}"><summary>${_sum}</summary>${_body}</details>`;
        html += `<tr class="childRow ${hasZaag ? "zaagRow" : ""} admin-background-hover" data-parent="${gkey}"><td><span class="jobIndent"><span class="arrow">↳</span><code>${_jobLabel(j)}</code></span></td><td>${esc(j.status || "")}</td><td class="muted">${esc(j.createdAt || "")}</td><td class="outputsTd"><div class="outputsCell">${dl}</div></td></tr>`;
      }
    }
    html += "</tbody></table>";
    el.innerHTML = html;

    el.querySelectorAll("[data-open-text-url]").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        openTextModal(
          btn.getAttribute("data-open-text-url") || "",
          btn.getAttribute("data-open-text-title") || "Bestand",
        );
      });
    });

    // toggle groups
    function setGroupVisible(groupKey, visible) {
      const rows = el.querySelectorAll(
        `tr.childRow[data-parent="${groupKey}"]`,
      );
      rows.forEach((r) =>
        setAdminRuntimeDisplay(r, visible ? "table-row" : "none"),
      );
      const btn = el.querySelector(
        `button.groupToggle[data-group="${groupKey}"]`,
      );
      if (btn) {
        btn.textContent = visible ? "▾" : "▸";
        btn.setAttribute("aria-expanded", visible ? "true" : "false");
      }
    }
    el.querySelectorAll("button.groupToggle").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        const k = btn.getAttribute("data-group");
        const expanded = btn.getAttribute("aria-expanded") === "true";
        setGroupVisible(k, !expanded);
      });
    });
  }
  load();
  loadControlCenter();

  let textModalController = null;
  async function openTextModal(url, title) {
    const m = document.getElementById("textModal");
    const t = document.getElementById("textModalTitle");
    const b = document.getElementById("textModalBody");
    const dl = document.getElementById("textModalDownload");
    if (!m || !t || !b || !dl) return;
    if (textModalController) textModalController.abort();
    const controller = new AbortController();
    textModalController = controller;
    t.textContent = title || "Bestand";
    b.textContent = "Laden…";
    dl.href = url;
    if (!m.open) m.showModal();
    const deadline = setTimeout(() => controller.abort(), 15000);
    try {
      const response = await fetch(url, {
        signal: controller.signal,
        cache: "no-store",
        credentials: "same-origin",
      });
      if (!response.ok || response.redirected)
        throw new Error("Bestand niet beschikbaar");
      const text = await response.text();
      if (textModalController === controller && m.open) b.textContent = text;
    } catch (error) {
      if (textModalController === controller && m.open) {
        b.textContent = controller.signal.aborted
          ? "Bestand laden duurde te lang. Sluit dit venster en probeer opnieuw."
          : "Kon bestand niet laden. Sluit dit venster en probeer opnieuw.";
      }
    } finally {
      clearTimeout(deadline);
      if (textModalController === controller) textModalController = null;
    }
  }
  function closeTextModal() {
    if (textModalController) textModalController.abort();
    textModalController = null;
    const m = document.getElementById("textModal");
    if (m && m.open) m.close();
  }
  document
    .getElementById("textModalClose")
    ?.addEventListener("click", closeTextModal);
  document
    .getElementById("textModal")
    ?.addEventListener("cancel", closeTextModal);
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeTextModal();
  });
  document.addEventListener("click", (e) => {
    const stop = e.target.closest('[data-stop-propagation="1"]');
    if (stop) e.stopPropagation();
    const trigger = e.target.closest("[data-admin-action]");
    if (!trigger) return;
    const action = trigger.getAttribute("data-admin-action");
    const allowed = new Set([
      "materialsReload",
      "savePricing",
      "reloadPricing",
      "refreshSystemPage",
      "createSystemBackup",
      "load",
    ]);
    if (allowed.has(action) && typeof window[action] === "function")
      window[action]();
  });
  document
    .getElementById("adminLogoutBtn")
    ?.addEventListener("click", async () => {
      try {
        await fetch("/api/admin/logout", {
          method: "POST",
          credentials: "same-origin",
          headers: { "X-Requested-With": "fetch" },
        });
      } finally {
        window.location.replace("/admin/");
      }
    });

  window.load = load;
}
