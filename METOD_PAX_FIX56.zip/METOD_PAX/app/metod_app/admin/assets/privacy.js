"use strict";
(() => {
  const get = (id) => document.getElementById(id);
  const status = get("privacyStatus");
  let preview = null;
  let busy = false;
  function reset() {
    preview = null;
    get("privacyActions").hidden = true;
    get("privacyConfirm").value = "";
    get("privacyDelete").disabled = true;
    get("privacyInternalConfirm").checked = false;
  }
  function controls(value) {
    busy = value;
    for (const id of [
      "privacySearch",
      "privacyExport",
      "privacyEmail",
      "privacyInternalConfirm",
    ])
      get(id).disabled = value;
    get("privacyInternalExport").disabled =
      value || !preview || !get("privacyInternalConfirm").checked;
    get("privacyDelete").disabled =
      value || !preview || get("privacyConfirm").value !== "VERWIJDEREN";
  }
  async function action(kind) {
    if (busy) return;
    controls(true);
    status.textContent = "Bezig…";
    try {
      const response = await fetch("/api/admin/privacy", {
        method: "POST",
        credentials: "same-origin",
        cache: "no-store",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        body: JSON.stringify({
          action: kind,
          email: get("privacyEmail").value,
          revision: preview?.revision,
          confirmation: get("privacyConfirm").value,
          internalConfirmation:
            kind === "export_internal" && get("privacyInternalConfirm").checked
              ? "INTERN"
              : "",
        }),
      });
      if (!response.ok) {
        const error = await response.json().catch(() => ({}));
        if (response.status === 409) reset();
        throw new Error(
          error.error || "De actie is niet afgerond. Probeer opnieuw.",
        );
      }
      if (kind === "export_customer" || kind === "export_internal") {
        const url = URL.createObjectURL(await response.blob());
        const link = document.createElement("a");
        link.href = url;
        link.download =
          kind === "export_internal"
            ? "INTERN-niet-doorsturen.zip"
            : "klantgegevens.zip";
        document.body.append(link);
        link.click();
        link.remove();
        setTimeout(() => URL.revokeObjectURL(url), 1000);
        status.textContent =
          kind === "export_internal"
            ? "Interne beheerexport gedownload. Niet doorsturen aan de klant."
            : "Klantexport gedownload. Controleer de ontvanger voordat je dit vertrouwelijke overzicht deelt.";
      } else {
        const result = await response.json();
        reset();
        if (kind === "preview") {
          preview = result;
          get("privacyActions").hidden = result.fileCount === 0;
          status.textContent = `${result.requestCount} aanvragen · ${result.fileCount} bestanden · ${(result.bytes / 1048576).toFixed(1)} MB`;
        } else {
          status.textContent = `${result.removedFiles} bestanden verwijderd. Het verwijderregister is opgeslagen.`;
        }
      }
    } catch (error) {
      status.textContent = error.message;
    } finally {
      controls(false);
    }
  }
  get("privacyEmail").addEventListener("input", reset);
  get("privacyConfirm").addEventListener("input", () => controls(busy));
  get("privacySearch").addEventListener("click", () => action("preview"));
  get("privacyExport").addEventListener("click", () =>
    action("export_customer"),
  );
  get("privacyInternalConfirm").addEventListener("change", () =>
    controls(busy),
  );
  get("privacyInternalExport").addEventListener("click", () =>
    action("export_internal"),
  );
  get("privacyDelete").addEventListener("click", () => action("delete"));
})();
