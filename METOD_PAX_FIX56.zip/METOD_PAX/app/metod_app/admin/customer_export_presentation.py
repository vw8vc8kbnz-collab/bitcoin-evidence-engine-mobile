"""Dutch text presentation only; the machine-readable customer data stays intact."""

from __future__ import annotations

from collections.abc import Mapping
from datetime import datetime, timezone, tzinfo
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

MONTHS = (
    "januari",
    "februari",
    "maart",
    "april",
    "mei",
    "juni",
    "juli",
    "augustus",
    "september",
    "oktober",
    "november",
    "december",
)
PUBLIC_STATUSES = {
    "SUBMITTED": "Aanvraag verzonden",
    "DONE": "Afgehandeld",
    "CANCELLED": "Geannuleerd door klant",
}
QUOTE_STATUSES = {
    "TODO": "Nog te behandelen",
    "DONE": "Afgehandeld",
    "CANCELLED": "Geannuleerd",
}

DISPLAY_TIMEZONE: tzinfo
try:
    DISPLAY_TIMEZONE = ZoneInfo("Europe/Amsterdam")
except ZoneInfoNotFoundError:
    # Minimal systems may lack tzdata. Never guess a fixed Dutch UTC offset:
    # label the fallback explicitly rather than misreporting summer time.
    DISPLAY_TIMEZONE = timezone.utc


def readable_date(value: object) -> str:
    """Legacy timezone-less server timestamps are UTC, as are the current Z dates."""
    if not isinstance(value, str) or not value.strip():
        return "Onbekend"
    try:
        source = value.strip()
        date = datetime.fromisoformat(source.removesuffix("Z") + ("+00:00" if source.endswith("Z") else ""))
        if date.tzinfo is None:
            date = date.replace(tzinfo=timezone.utc)
        date = date.astimezone(DISPLAY_TIMEZONE)
    except (ValueError, OverflowError):
        return "Onbekend"
    zone_label = "UTC" if DISPLAY_TIMEZONE is timezone.utc else "Nederlandse tijd"
    return f"{date.day} {MONTHS[date.month - 1]} {date.year}, {date:%H:%M} ({zone_label})"


def readable_status_lines(status: Mapping[str, object]) -> list[str]:
    lines = []
    for field, label, descriptions in (
        ("publicStatus", "Aanvraagstatus", PUBLIC_STATUSES),
        ("quoteStatus", "Offertestatus", QUOTE_STATUSES),
    ):
        value = status.get(field)
        if value is not None:
            description = descriptions.get(str(value).strip().upper(), "Onbekend")
            lines.append(f"{label}: {description}")
    if "publicStatus" not in status and "publicStatusLabel" in status:
        saved_label = status["publicStatusLabel"]
        description = (
            saved_label
            if isinstance(saved_label, str) and saved_label in PUBLIC_STATUSES.values()
            else "Onbekend"
        )
        lines.insert(0, f"Aanvraagstatus: {description}")
    return lines
