"""Single active owner for Admin presentation, authentication and sessions.

The HTTP server deliberately keeps only narrow adapters around this boundary.
keeps this module focused on authentication and sessions. Presentation
templates and same-origin assets are owned by ``admin.presentation`` without
changing cookie, CSRF or development-only Basic-authentication contracts.
"""

from __future__ import annotations


from metod_app.observability.failures import report_recovery

import base64
import copy
import logging
import ipaddress
import os
import threading
import hashlib
import hmac
import json
import re
import secrets
import time
from dataclasses import dataclass
from typing import Any, Callable, Mapping

from .totp_replay import TotpReplayStore
from .network_policy import admin_networks


def normalized_admin_users(credentials: dict | None) -> list[dict[str, Any]]:
    creds = credentials if isinstance(credentials, dict) else {}
    raw_users = creds.get("users")
    users: list[dict[str, Any]] = []
    if isinstance(raw_users, list):
        for raw in raw_users:
            if not isinstance(raw, dict) or raw.get("active") is False:
                continue
            username = str(raw.get("username") or "").strip()
            password_hash = str(raw.get("password_hash") or raw.get("passwordHash") or "").strip()
            roles = raw.get("roles") if isinstance(raw.get("roles"), list) else ["admin"]
            roles = sorted({str(role).strip().lower() for role in roles if str(role).strip()})
            if username and password_hash:
                users.append(
                    {
                        "username": username,
                        "password_hash": password_hash,
                        "totp_secret": str(raw.get("totp_secret") or raw.get("totpSecret") or "").strip(),
                        "roles": roles or ["admin"],
                    }
                )
        return users
    username = str(creds.get("username") or "").strip()
    password_hash = str(creds.get("password_hash") or creds.get("passwordHash") or "").strip()
    if username and password_hash:
        users.append(
            {
                "username": username,
                "password_hash": password_hash,
                "totp_secret": str(creds.get("totp_secret") or creds.get("totpSecret") or "").strip(),
                "roles": ["admin"],
            }
        )
    return users


def find_admin_user(credentials: dict | None, username: str) -> dict[str, Any] | None:
    supplied = str(username or "").strip()
    if not re.fullmatch(r"[A-Za-z0-9_.@-]{3,80}", supplied):
        return None
    for user in normalized_admin_users(credentials):
        if hmac.compare_digest(str(user.get("username") or "").encode("utf-8"), supplied.encode("ascii")):
            return user
    return None


def admin_credential_fingerprint(user: Mapping[str, Any] | None) -> str:
    """Bind a session to the current account authentication/authorization state."""

    if not isinstance(user, Mapping):
        return ""
    payload = {
        "username": str(user.get("username") or "").strip(),
        "password_hash": str(user.get("password_hash") or "").strip(),
        "totp_secret": str(user.get("totp_secret") or "").strip(),
        "roles": sorted(
            {str(role).strip().lower() for role in (user.get("roles") or []) if str(role).strip()}
        ),
    }
    if not payload["username"] or not payload["password_hash"]:
        return ""
    encoded = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


class AdminSessionStore:
    """Bounded in-memory Admin session owner with idle and absolute expiry."""

    def __init__(
        self,
        *,
        idle_seconds: int,
        absolute_seconds: int,
        max_sessions: Callable[[], int],
        lock: Any,
        clock: Callable[[], float] = time.time,
        token_factory: Callable[[], str] | None = None,
    ) -> None:
        self._idle_seconds = idle_seconds
        self._absolute_seconds = absolute_seconds
        self._max_sessions = max_sessions
        self._clock = clock
        self._token_factory = token_factory or (lambda: secrets.token_urlsafe(32))
        self._lock = lock
        self._sessions: dict[str, dict[str, Any]] = {}

    @property
    def idle_seconds(self) -> int:
        return max(300, min(3600, int(self._idle_seconds or 1800)))

    @property
    def absolute_seconds(self) -> int:
        return max(self.idle_seconds, self.cookie_max_age)

    @property
    def cookie_max_age(self) -> int:
        # Preserve the historical wire contract even when an invalid custom
        # configuration makes absolute expiry shorter than idle expiry.
        return max(300, min(24 * 60 * 60, int(self._absolute_seconds or 28800)))

    def create(
        self,
        actor: str,
        roles: list[str] | None = None,
        credential_fingerprint: str = "",
    ) -> tuple[str, float]:
        token = self._token_factory()
        now = self._clock()
        idle = self.idle_seconds
        exp = now + self.absolute_seconds
        with self._lock:
            for key, value in list(self._sessions.items()):
                if (
                    float(value.get("absoluteExpiresAt") or 0) <= now
                    or float(value.get("idleExpiresAt") or 0) <= now
                ):
                    self._sessions.pop(key, None)
            max_sessions = max(8, min(4096, int(self._max_sessions())))
            while len(self._sessions) >= max_sessions:
                oldest = min(
                    self._sessions,
                    key=lambda key: float(self._sessions[key].get("lastSeenAt") or 0),
                )
                self._sessions.pop(oldest, None)
            self._sessions[token] = {
                "actor": str(actor or "").strip(),
                "roles": sorted(
                    {str(role).strip().lower() for role in (roles or ["admin"]) if str(role).strip()}
                ),
                "credentialFingerprint": str(credential_fingerprint or "").strip(),
                "createdAt": now,
                "lastSeenAt": now,
                "idleExpiresAt": now + idle,
                "absoluteExpiresAt": exp,
            }
        return token, exp

    def valid(self, token: str) -> bool:
        raw = str(token or "").strip()
        if not raw:
            return False
        with self._lock:
            session = self._sessions.get(raw)
            if not session:
                return False
            now = self._clock()
            if (
                float(session.get("absoluteExpiresAt") or 0) <= now
                or float(session.get("idleExpiresAt") or 0) <= now
            ):
                self._sessions.pop(raw, None)
                return False
            session["lastSeenAt"] = now
            session["idleExpiresAt"] = min(
                now + self.idle_seconds,
                float(session.get("absoluteExpiresAt") or now),
            )
            return True

    def revoke(self, token: str) -> None:
        raw = str(token or "").strip()
        if raw:
            with self._lock:
                self._sessions.pop(raw, None)

    def actor(self, token: str) -> str:
        raw = str(token or "").strip()
        if not raw:
            return ""
        with self._lock:
            session = self._sessions.get(raw) or {}
            return str(session.get("actor") or "").strip()

    def roles(self, token: str) -> frozenset[str]:
        raw = str(token or "").strip()
        if not raw:
            return frozenset()
        with self._lock:
            session = self._sessions.get(raw) or {}
            roles = session.get("roles") if isinstance(session.get("roles"), list) else []
            return frozenset(str(role).strip().lower() for role in roles if str(role).strip())

    def credential_fingerprint(self, token: str) -> str:
        raw = str(token or "").strip()
        if not raw:
            return ""
        with self._lock:
            session = self._sessions.get(raw) or {}
            return str(session.get("credentialFingerprint") or "").strip()


@dataclass(frozen=True)
class AdminAccessDependencies:
    root: Any
    state_root: Callable[[], Any]
    environment: Mapping[str, str]
    credentials_file_path: Callable[[], Any]
    strict_json_load: Callable[[Any], Any]
    strict_json_dumps: Callable[[Any], str]
    read_json_body_limited: Callable[[Any, str, int], dict]
    production_runtime: Callable[[], bool]
    production_hardening_enabled: Callable[[], bool]
    secure_admin_transport: Callable[[Any], bool]
    https_request: Callable[[Any], bool]
    client_ip: Callable[[Any], str]
    loopback_client: Callable[[Any], bool]
    rate_limit_is_blocked: Callable[[str, str, int, int], bool]
    rate_limit_record: Callable[[str, str], None]
    rate_limit_clear: Callable[[str, str], None]
    verify_password: Callable[[str, str], bool]
    match_totp_counter: Callable[[str, str], int | None]
    append_system_event: Callable[..., None]
    extract_bearer_token: Callable[[str], str]
    extract_session_cookie: Callable[[str], str]
    dummy_password_hash: str
    dummy_totp_secret: str
    externally_exposed_security_enabled: Callable[[], bool] | None = None


class AdminAccessController:
    """Active Admin credential, login, cookie, challenge and session owner."""

    def __init__(self, dependencies: AdminAccessDependencies, sessions: AdminSessionStore) -> None:
        self.dependencies = dependencies
        self.sessions = sessions
        self._credential_lock = threading.Lock()
        self._credential_cache = None
        self._credential_stamp = None
        self._password_slots = threading.BoundedSemaphore(4)
        self._local_credentials_warned = False

    def network_allowed(self, handler) -> bool:
        """Restrict Admin to operator-managed IP/VPN networks when configured.

        The existing trusted-proxy policy resolves client_ip; arbitrary forwarded
        headers never grant access. Production requires an explicit allowlist.
        """
        required = self.dependencies.production_hardening_enabled()
        try:
            networks = admin_networks(os.environ, required=required)
            if not networks:
                return not required
            address = ipaddress.ip_address(self.dependencies.client_ip(handler))
            return any(address in network for network in networks)
        except ValueError:
            return False

    def _security_mode_enabled(self) -> bool:
        deps = self.dependencies
        callback = deps.externally_exposed_security_enabled
        return deps.production_hardening_enabled() or callback is None or bool(callback())

    @staticmethod
    def _file_stamp(path):
        stat = path.stat()
        return (str(path), stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns)

    def load_credentials(self) -> dict | None:
        """Cache by file identity; rotation, removal or corruption fails closed.

        Never use a TTL: a revoked account must lose its sessions on the very
        next request, even when the replacement has the same byte length.
        """
        deps = self.dependencies
        path = deps.credentials_file_path()
        with self._credential_lock:
            try:
                stamp = self._file_stamp(path)
                if stamp == self._credential_stamp:
                    return copy.deepcopy(self._credential_cache)
                obj = deps.strict_json_load(path)
                if self._file_stamp(path) != stamp:
                    raise OSError("Credential file changed during read")
                if not isinstance(obj, dict) or not normalized_admin_users(obj):
                    raise ValueError("Invalid credential document")
                result = dict(obj)
                result["source"] = (
                    "config" if path == deps.root / "config/admin_credentials.json" else "external_config"
                )
                result["path"] = str(path)
                self._credential_stamp = stamp
                self._credential_cache = result
                return copy.deepcopy(result)
            except (OSError, ValueError, TypeError) as error:
                self._credential_stamp = None
                self._credential_cache = None
                report_recovery("admin.credentials.unavailable", error)
                return None

    def warn_if_local_credentials_in_production(self, handler: Any, credentials: dict | None) -> None:
        if (
            self.dependencies.production_hardening_enabled()
            and (credentials or {}).get("source") == "config"
            and not self._local_credentials_warned
        ):
            logging.getLogger("metod.security").warning(
                "Admin credentials must be stored outside the release; configure ADMIN_CREDENTIALS_FILE"
            )
            self._local_credentials_warned = True

    def _credentials(self, handler: Any) -> dict:
        credentials = self.load_credentials() or {}
        self.warn_if_local_credentials_in_production(handler, credentials)
        return credentials

    def _has_admin_session(self, token: str, credentials: dict | None) -> bool:
        raw = str(token or "").strip()
        if not raw or not self.sessions.valid(raw):
            return False
        actor = self.sessions.actor(raw)
        user = find_admin_user(credentials, actor)
        current_fingerprint = admin_credential_fingerprint(user)
        session_fingerprint = self.sessions.credential_fingerprint(raw)
        if (
            not current_fingerprint
            or not session_fingerprint
            or not hmac.compare_digest(current_fingerprint, session_fingerprint)
        ):
            self.sessions.revoke(raw)
            return False
        return "admin" in self.sessions.roles(raw)

    def login(self, handler: Any) -> None:
        if not self.network_allowed(handler):
            return handler._send_text("Not found", 404)
        deps = self.dependencies
        try:
            data = deps.read_json_body_limited(handler, "ADMIN_JSON_MAX_BYTES", 262144)
        except (ValueError, TypeError, OSError):
            return handler._send_json(
                {"ok": False, "authRequired": True, "error": "Invalid login payload"}, 400
            )
        credentials = self._credentials(handler)
        users = normalized_admin_users(credentials)
        if not users:
            return handler._send_json(
                {"ok": False, "authRequired": True, "error": "Admin authentication not configured"},
                403,
            )
        if self._security_mode_enabled() and not deps.secure_admin_transport(handler):
            return handler._send_json(
                {"ok": False, "authRequired": True, "error": "Admin authentication requires HTTPS"},
                403,
            )
        username = str(data.get("username") or "").strip()
        ip = deps.client_ip(handler)
        account_key = hashlib.sha256(username.casefold().encode("utf-8", errors="replace")).hexdigest()
        password = str(data.get("password") or "")
        otp = str(data.get("otp") or "")
        user = find_admin_user(credentials, username)
        stored_hash = str(user.get("password_hash") or "") if user else deps.dummy_password_hash
        stored_totp = str(user.get("totp_secret") or "") if user else deps.dummy_totp_secret
        matched_counter = deps.match_totp_counter(stored_totp or deps.dummy_totp_secret, otp)
        mfa_ok = bool(user and stored_totp and matched_counter is not None)
        blocked = deps.rate_limit_is_blocked("admin_auth_fail", ip, 10, 300) or deps.rate_limit_is_blocked(
            "admin_auth_fail_account", account_key, 10, 300
        )
        # A stranger cannot indefinitely lock out a holder of the account's
        # own second factor. The password and durable OTP replay check remain
        # mandatory; unknown users and the dummy factor never bypass limits.
        if (blocked and not mfa_ok) or not self._password_slots.acquire(blocking=False):
            return handler._send_json(
                {"ok": False, "authRequired": True, "error": "Too many login attempts"}, 429
            )
        try:
            password_ok = deps.verify_password(password, stored_hash)
        finally:
            self._password_slots.release()
        fingerprint = admin_credential_fingerprint(user)
        if user and password_ok and mfa_ok:
            try:
                mfa_ok = TotpReplayStore(deps.state_root()).consume(fingerprint, matched_counter)
            except (OSError, ValueError, TypeError):
                mfa_ok = False
                deps.append_system_event(
                    level="error",
                    component="auth",
                    status="open",
                    message_user="Admin login tijdelijk niet beschikbaar",
                    message_tech="TOTP replay protection storage unavailable",
                )
        if user and password_ok and (mfa_ok or (not self._security_mode_enabled() and not stored_totp)):
            deps.rate_limit_clear("admin_auth_fail", ip)
            deps.rate_limit_clear("admin_auth_fail_account", account_key)
            token, expires_at = self.sessions.create(
                username,
                list(user.get("roles") or ["admin"]),
                fingerprint,
            )
            body = deps.strict_json_dumps(
                {"ok": True, "expiresAt": int(expires_at), "actor": username}
            ).encode("utf-8")
            handler.send_response(200)
            handler.send_header("Content-Type", "application/json; charset=utf-8")
            handler.send_header("Content-Length", str(len(body)))
            secure = "; Secure" if (self._security_mode_enabled() or deps.https_request(handler)) else ""
            handler.send_header(
                "Set-Cookie",
                f"adzaagt_admin_session={token}; Path=/; SameSite=Strict; HttpOnly{secure}; "
                f"Max-Age={self.sessions.cookie_max_age}",
            )
            handler.end_headers()
            handler.wfile.write(body)
            return None
        deps.rate_limit_record("admin_auth_fail", ip)
        deps.rate_limit_record("admin_auth_fail_account", account_key)
        deps.append_system_event(
            level="warning",
            component="auth",
            message_user="Admin login mislukt",
            message_tech="Invalid overlay login",
            status="open",
        )
        return handler._send_json(
            {"ok": False, "authRequired": True, "error": "Invalid admin credentials"}, 401
        )

    def check_silent(self, handler: Any) -> bool:
        if not self.network_allowed(handler):
            return False
        deps = self.dependencies
        credentials = self._credentials(handler)
        authorization = handler.headers.get("Authorization") or ""
        bearer = deps.extract_bearer_token(authorization)
        if self._has_admin_session(bearer, credentials):
            return True
        cookie_token = deps.extract_session_cookie(handler.headers.get("Cookie") or "")
        if self._has_admin_session(cookie_token, credentials):
            return True
        if not normalized_admin_users(credentials):
            return False
        if self._security_mode_enabled():
            return False
        if not authorization.startswith("Basic "):
            return False
        try:
            decoded = base64.b64decode(authorization.split(" ", 1)[1].strip()).decode("utf-8")
            supplied_user, supplied_password = decoded.split(":", 1)
        except Exception as recovery_error:
            report_recovery("metod_app.admin.access.boundary.464", recovery_error)
            return False
        user = find_admin_user(credentials, supplied_user)
        return bool(user and deps.verify_password(supplied_password, str(user.get("password_hash") or "")))

    def current_session_token(self, handler: Any) -> str:
        deps = self.dependencies
        credentials = self._credentials(handler)
        bearer = deps.extract_bearer_token(handler.headers.get("Authorization") or "")
        if self._has_admin_session(bearer, credentials):
            return bearer
        cookie = deps.extract_session_cookie(handler.headers.get("Cookie") or "")
        if self._has_admin_session(cookie, credentials):
            return cookie
        return ""

    def current_actor(self, handler: Any) -> str:
        token = self.current_session_token(handler)
        if token:
            return self.sessions.actor(token)
        return "local-development" if not self._security_mode_enabled() else ""

    def logout(self, handler: Any) -> None:
        deps = self.dependencies
        token = self.current_session_token(handler)
        actor = self.sessions.actor(token)
        self.sessions.revoke(token)
        body = b'{"ok":true}'
        handler.send_response(200)
        handler.send_header("Content-Type", "application/json; charset=utf-8")
        handler.send_header("Content-Length", str(len(body)))
        secure = "; Secure" if (self._security_mode_enabled() or deps.https_request(handler)) else ""
        handler.send_header(
            "Set-Cookie",
            f"adzaagt_admin_session=; Path=/; SameSite=Strict; HttpOnly{secure}; Max-Age=0",
        )
        handler.end_headers()
        handler.wfile.write(body)
        if actor:
            deps.append_system_event(
                level="info",
                component="auth",
                message_user="Admin uitgelogd",
                message_tech="Session revoked",
                status="resolved",
                details={"actor": actor},
            )

    @staticmethod
    def wants_native_basic_prompt(handler: Any) -> bool:
        try:
            requested_with = (handler.headers.get("X-Requested-With") or "").lower()
            if requested_with:
                return False
            accept = (handler.headers.get("Accept") or "").lower()
            destination = (handler.headers.get("Sec-Fetch-Dest") or "").lower()
            mode = (handler.headers.get("Sec-Fetch-Mode") or "").lower()
            if destination == "empty" or mode in ("cors", "same-origin"):
                return False
            return ("text/html" in accept) or destination in ("document", "")
        except Exception as recovery_error:
            report_recovery("metod_app.admin.access.boundary.527", recovery_error)
            return False

    def send_challenge(
        self,
        handler: Any,
        code: int = 401,
        message: str = "Admin authentication required",
    ) -> bool:
        try:
            if not self.wants_native_basic_prompt(handler):
                handler.send_response(code)
                handler.send_header("Content-Type", "application/json; charset=utf-8")
                handler.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
                handler.send_header("X-Admin-Auth-Required", "1")
                handler.send_header("X-Content-Type-Options", "nosniff")
                handler.end_headers()
                body = json.dumps(
                    {"ok": False, "authRequired": True, "error": message}, ensure_ascii=False
                ).encode("utf-8")
                handler.wfile.write(body)
                return False
        except Exception as recovery_error:
            report_recovery("metod_app.admin.access.send_challenge.523", recovery_error)
        handler.send_response(code)
        if code == 401 and not self._security_mode_enabled():
            handler.send_header("WWW-Authenticate", 'Basic realm="Admin"')
        handler.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        handler.end_headers()
        try:
            handler.wfile.write(str(message).encode("utf-8"))
        except Exception as recovery_error:
            report_recovery("metod_app.admin.access.send_challenge.532", recovery_error)
        return False

    def require_auth(self, handler: Any) -> bool:
        if not self.network_allowed(handler):
            handler._send_text("Not found", 404)
            return False
        deps = self.dependencies
        if deps.environment.get("ADMIN_STAGING_OPEN") == "1":
            if (not self._security_mode_enabled()) and deps.loopback_client(handler):
                return True
            try:
                deps.append_system_event(
                    level="error",
                    component="auth",
                    message_user="Admin staging bypass geblokkeerd",
                    message_tech=("ADMIN_STAGING_OPEN was set but public admin bypass is disabled"),
                    status="open",
                )
            except Exception as recovery_error:
                report_recovery("metod_app.admin.access.require_auth.551", recovery_error)
        credentials = self._credentials(handler)
        if not normalized_admin_users(credentials):
            authorization = handler.headers.get("Authorization") or ""
            self._has_admin_session(deps.extract_bearer_token(authorization), credentials)
            self._has_admin_session(
                deps.extract_session_cookie(handler.headers.get("Cookie") or ""), credentials
            )
            deps.append_system_event(
                level="error",
                component="auth",
                message_user="Admin-login is niet geconfigureerd",
                message_tech=(
                    f"Missing username/password in {credentials.get('path') or deps.credentials_file_path()}"
                ),
                status="open",
            )
            return self.send_challenge(handler, 403, "Admin authentication not configured.")

        if self._security_mode_enabled() and not deps.secure_admin_transport(handler):
            deps.append_system_event(
                level="error",
                component="auth",
                message_user="Admin-login geblokkeerd",
                message_tech=("Admin authentication requires HTTPS in externally exposed security mode"),
                status="open",
            )
            return self.send_challenge(handler, 403, "Admin authentication requires HTTPS.")

        ip = deps.client_ip(handler)
        authorization = handler.headers.get("Authorization") or ""
        bearer = deps.extract_bearer_token(authorization)
        if self._has_admin_session(bearer, credentials):
            deps.rate_limit_clear("admin_auth_fail", ip)
            return True
        cookie_token = deps.extract_session_cookie(handler.headers.get("Cookie") or "")
        if self._has_admin_session(cookie_token, credentials):
            deps.rate_limit_clear("admin_auth_fail", ip)
            return True
        if self._security_mode_enabled():
            return self.send_challenge(handler, 401, "Admin authentication required")
        if not authorization.startswith("Basic "):
            return self.send_challenge(handler, 401, "Admin authentication required")

        encoded = authorization.split(" ", 1)[1].strip()
        try:
            decoded = base64.b64decode(encoded).decode("utf-8")
        except Exception as recovery_error:
            report_recovery("metod_app.admin.access.boundary.631", recovery_error)
            if deps.rate_limit_is_blocked("admin_auth_fail", ip, 10, 300):
                handler.send_response(429)
                handler.end_headers()
                handler.wfile.write(b"Too many login attempts.")
                return False
            deps.rate_limit_record("admin_auth_fail", ip)
            deps.append_system_event(
                level="warning",
                component="auth",
                message_user="Admin login mislukt",
                message_tech="Invalid Basic auth encoding",
                status="open",
            )
            return self.send_challenge(handler, 401, "Admin authentication required")

        username, _, password = decoded.partition(":")
        user = find_admin_user(credentials, username)
        if user and deps.verify_password(password, str(user.get("password_hash") or "")):
            deps.rate_limit_clear("admin_auth_fail", ip)
            return True

        if deps.rate_limit_is_blocked("admin_auth_fail", ip, 10, 300):
            handler.send_response(429)
            handler.end_headers()
            handler.wfile.write(b"Too many login attempts.")
            return False
        deps.rate_limit_record("admin_auth_fail", ip)
        deps.append_system_event(
            level="warning",
            component="auth",
            message_user="Admin login mislukt",
            message_tech="Invalid credentials",
            status="open",
        )
        return self.send_challenge(handler, 401, "Invalid admin credentials")
