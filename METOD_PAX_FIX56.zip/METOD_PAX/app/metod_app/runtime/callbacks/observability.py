"""Callable contracts for observability operations; parameter names and result types are explicit."""

from __future__ import annotations
from typing import Any, Protocol, TYPE_CHECKING

if TYPE_CHECKING:
    pass


class AppendSystemEventCallback(Protocol):
    def __call__(
        __callback,
        *,
        level: str = ...,
        component: str = ...,
        message_user: str,
        message_tech: str = ...,
        request_id: str = ...,
        job_id: str = ...,
        customer_name: str = ...,
        status: str = ...,
        details: dict[str, Any] | None = ...,
    ) -> None: ...


class GuessCustomerNameCallback(Protocol):
    def __call__(
        __callback,
        request_id: str = ...,
        payload: dict[str, Any] | None = ...,
        status: dict[str, Any] | None = ...,
    ) -> str: ...


class GuessCustomerNameFromPayloadCallback(Protocol):
    def __call__(__callback, payload: dict[str, Any] | None) -> str: ...


class ObservabilityPublicJobSnapshotCallback(Protocol):
    def __call__(__callback) -> dict[str, int]: ...


class ReadSystemEventsCallback(Protocol):
    def __call__(__callback, limit: int = ...) -> list[dict[str, Any]]: ...
