"""Callable contracts for pricing operations; parameter names and result types are explicit."""

from __future__ import annotations
from typing import Any, Protocol, TYPE_CHECKING
from pathlib import Path

if TYPE_CHECKING:
    pass


class AggregateMaterialsFromSubjobQuotesCallback(Protocol):
    def __call__(__callback, parent_job_id: str) -> list[dict[str, Any]]: ...


class ApplySellPricingToQuoteCallback(Protocol):
    def __call__(
        __callback,
        quote: dict[str, Any],
        *,
        sell_pricing: dict[str, Any] | None = ...,
        vat_rate: float | None = ...,
        include_fixed_costs: bool = ...,
    ) -> dict[str, Any]: ...


class CapturePublicJobPricingAuthorityCallback(Protocol):
    def __call__(__callback, panels_csv: str) -> tuple[dict[str, Any], dict[str, Any]]: ...


class DefaultPricingConfigCallback(Protocol):
    def __call__(__callback) -> dict[str, Any]: ...


class EnsurePricingConfigFilesCallback(Protocol):
    def __call__(__callback) -> None: ...


class EnsurePricingMaterialsCallback(Protocol):
    def __call__(__callback, pricing: dict[str, Any], panels_csv: str) -> dict[str, Any]: ...


class FormatEurCallback(Protocol):
    def __call__(__callback, x: float) -> str: ...


class FormatMCallback(Protocol):
    def __call__(__callback, x: float) -> str: ...


class LoadPricingConfigCallback(Protocol):
    def __call__(__callback) -> dict[str, Any]: ...


class MigrateLegacyMaterialsToDirectSellPricesCallback(Protocol):
    def __call__(__callback) -> dict[str, Any]: ...


class NormalizePricingConfigSchemaCallback(Protocol):
    def __call__(__callback, cfg: dict[str, Any]) -> dict[str, Any]: ...


class ParseCalculationSummaryTotalsCallback(Protocol):
    def __call__(__callback, job_root: Path) -> dict[str, Any]: ...


class SavePricingConfigCallback(Protocol):
    def __call__(
        __callback, new_cfg: dict[str, Any], actor: str = ..., *, expected_revision: str | None = ...
    ) -> dict[str, Any]: ...


class WriteHumanCalculationSummaryCallback(Protocol):
    def __call__(__callback, job_root: Path, request_status: dict[str, Any] | None = ...) -> None: ...
