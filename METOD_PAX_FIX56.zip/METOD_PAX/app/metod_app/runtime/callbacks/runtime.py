"""Callable contracts for runtime operations; parameter names and result types are explicit."""

from __future__ import annotations
from typing import Any, Protocol, TYPE_CHECKING
from pathlib import Path
from urllib.parse import ParseResult

if TYPE_CHECKING:
    from metod_app.http.wsgi import WsgiHandler


class ApiAdminControlCenterCallback(Protocol):
    def __call__(__callback, self: WsgiHandler) -> None: ...


class ApiAdminJobsCallback(Protocol):
    def __call__(__callback, self: WsgiHandler) -> None: ...


class ApiAdminRequestDownloadZipCallback(Protocol):
    def __call__(__callback, self: WsgiHandler) -> None: ...


class ApiAdminRequestFileCallback(Protocol):
    def __call__(__callback, self: WsgiHandler) -> None: ...


class ApiAdminRequestFilesCallback(Protocol):
    def __call__(__callback, self: WsgiHandler) -> None: ...


class ApiAdminRequestsCallback(Protocol):
    def __call__(__callback, self: WsgiHandler) -> None: ...


class ApiAdminRequestsUpdateCallback(Protocol):
    def __call__(__callback, self: WsgiHandler) -> None: ...


class ApiDownloadCallback(Protocol):
    def __call__(
        __callback, self: WsgiHandler, job_id: str, fname: str, parsed: ParseResult | None = ...
    ) -> None: ...


class ApiDraftLoadCallback(Protocol):
    def __call__(__callback, self: WsgiHandler, parsed: ParseResult | None) -> None: ...


class ApiDraftSaveCallback(Protocol):
    def __call__(__callback, self: WsgiHandler) -> None: ...


class ApiDxfManifestMetaCallback(Protocol):
    def __call__(__callback, handler: WsgiHandler, parsed: ParseResult | None) -> None: ...


class ApiJobFileCallback(Protocol):
    def __call__(
        __callback,
        self: WsgiHandler,
        job_id: str,
        rel: str,
        parsed: ParseResult | None = ...,
        *,
        download_name_override: str | None = ...,
    ) -> None: ...


class ApiSubjobFileCallback(Protocol):
    def __call__(
        __callback, self: WsgiHandler, job_id: str, subjob_id: str, rel: str, parsed: ParseResult | None = ...
    ) -> None: ...


class AppendClientLogCallback(Protocol):
    def __call__(__callback, source: str, event: str, message: str, details: object) -> None: ...


class BuildRequestFileManifestCallback(Protocol):
    def __call__(__callback, request_id: str) -> dict[str, Any]: ...


class ClassifyOutputKindCallback(Protocol):
    def __call__(__callback, name: str) -> str: ...


class CollectJobOutputFilesCallback(Protocol):
    def __call__(__callback, job_id: str) -> list[dict[str, Any]]: ...


class CreateJobFromPayloadCallback(Protocol):
    def __call__(
        __callback, payload: dict[str, Any], master_job_id: str | None = ..., public_access_token: str = ...
    ) -> dict[str, Any]: ...


class DedupeAdminDxfFilesCallback(Protocol):
    def __call__(__callback, files: list[dict[str, Any]]) -> list[dict[str, Any]]: ...


class DirSizeBytesCallback(Protocol):
    def __call__(__callback, root: Path) -> int: ...


class EdgeMetersByDecorCallback(Protocol):
    def __call__(__callback, job_dir: Path) -> dict[str, float]: ...


class ExtractStrictCalculationPricingSummaryCallback(Protocol):
    def __call__(__callback, job_ids: list[str]) -> dict[str, Any] | None: ...


class FindOrGenerateStickertoolFileCallback(Protocol):
    def __call__(__callback, job_id: str) -> Path | None: ...


class InvalidateMaterialNameCacheCallback(Protocol):
    def __call__(__callback) -> None: ...


class LoadMaterialNameByCodeCallback(Protocol):
    def __call__(__callback) -> dict[str, Any]: ...


class PrometheusMetricsCallback(Protocol):
    def __call__(__callback) -> str: ...


class ReadinessReportCallback(Protocol):
    def __call__(__callback) -> tuple[dict[str, Any], int]: ...


class RunQueueMaintenanceCallback(Protocol):
    def __call__(__callback, force: bool = ...) -> dict[str, Any]: ...


class RunRetentionMaintenanceCallback(Protocol):
    def __call__(__callback, force: bool = ...) -> dict[str, Any]: ...


class SyncPublicJobAdmissionLegacyCountersCallback(Protocol):
    def __call__(__callback) -> None: ...


class SyncPublicJobSchedulerLegacyStateCallback(Protocol):
    def __call__(__callback) -> None: ...


class WorkerLoopCallback(Protocol):
    def __call__(__callback, poll_seconds: float = ...) -> None: ...
