"""Callable contracts for storage operations; parameter names and result types are explicit."""

from __future__ import annotations
from typing import Any, Optional, Protocol, TYPE_CHECKING
from contextlib import AbstractContextManager
from datetime import datetime
from pathlib import Path

if TYPE_CHECKING:
    from metod_app.http.wsgi import WsgiHandler


class ArchiveJournalEntriesCallback(Protocol):
    def __call__(
        __callback, journal: dict[str, Any], *, journal_path: Path | None = ...
    ) -> list[dict[str, str]]: ...


class ArchiveJournalPathCallback(Protocol):
    def __call__(__callback, transaction_id: str) -> Path: ...


class ArchiveJournalWriteCallback(Protocol):
    def __call__(__callback, path: Path, journal: dict[str, Any]) -> None: ...


class ArchiveRequestAndLinkedJobsCallback(Protocol):
    def __call__(__callback, request_id: str, *, retention_reason: str = ...) -> dict[str, Any]: ...


class AssertBackupCapacityCallback(Protocol):
    def __call__(__callback, source_bytes: int, file_count: int) -> None: ...


class AtomicWriteJsonCallback(Protocol):
    def __call__(__callback, path: Path, obj: dict[str, Any], *, mode: int | None = ...) -> None: ...


class BackupSourceInventoryCallback(Protocol):
    def __call__(__callback) -> tuple[list[tuple[Path, str]], int]: ...


class BeginConsistentSnapshotCallback(Protocol):
    def __call__(__callback, timeout_seconds: float = ...) -> None: ...


class CleanupOldBackupsCallback(Protocol):
    def __call__(__callback, *, protected: set[Path] | None = ...) -> dict[str, Any]: ...


class CompleteArchiveJournalCallback(Protocol):
    def __call__(__callback, journal_path: Path, journal: dict[str, Any]) -> dict[str, Any]: ...


class CreateSystemBackupCallback(Protocol):
    def __call__(__callback, actor: str = ..., backup_kind: str = ...) -> dict[str, Any]: ...


class EndConsistentSnapshotCallback(Protocol):
    def __call__(__callback) -> None: ...


class EnsureArchiveDirsCallback(Protocol):
    def __call__(__callback) -> None: ...


class EnsureRequestDirsCallback(Protocol):
    def __call__(__callback) -> None: ...


class EnsureSystemDirsCallback(Protocol):
    def __call__(__callback) -> None: ...


class ExclusiveStateMaintenanceCallback(Protocol):
    def __call__(__callback) -> AbstractContextManager[None]: ...


class InitializeExternalStateCallback(Protocol):
    def __call__(__callback) -> None: ...


class JobCreatedDtCallback(Protocol):
    def __call__(__callback, job_dir: Path) -> Optional[datetime]: ...


class LinkOrCopyFileCallback(Protocol):
    def __call__(__callback, src: Path, dst: Path) -> str: ...


class LinkedJobIdsFromStatusCallback(Protocol):
    def __call__(__callback, st: dict[str, Any] | None) -> list[str]: ...


class ListBackupsCallback(Protocol):
    def __call__(__callback, limit: int = ...) -> list[dict[str, Any]]: ...


class MoveQueueFileSafeCallback(Protocol):
    def __call__(__callback, src: Path, dest_dir: Path) -> Path: ...


class NowIsoCallback(Protocol):
    def __call__(__callback) -> str: ...


class ParseIsoDtCallback(Protocol):
    def __call__(__callback, value: object) -> Optional[datetime]: ...


class PathDtCallback(Protocol):
    def __call__(__callback, path: Path) -> Optional[datetime]: ...


class ReadJsonBodyLimitedCallback(Protocol):
    def __call__(__callback, handler: WsgiHandler, env_name: str, default_bytes: int) -> dict[str, Any]: ...


class ReadLastAutoBackupDtCallback(Protocol):
    def __call__(__callback) -> datetime | None: ...


class ReconcileArchiveTransactionsCallback(Protocol):
    def __call__(__callback) -> dict[str, Any]: ...


class RecordMaintenanceFailureCallback(Protocol):
    def __call__(__callback, component: str, user_message: str, failure: object) -> None: ...


class RequestArchiveMetaDtCallback(Protocol):
    def __call__(__callback, req_dir: Path) -> Optional[datetime]: ...


class RequestCreatedDtFromStatusCallback(Protocol):
    def __call__(
        __callback, st: dict[str, Any] | None, request_root: Path | None = ...
    ) -> Optional[datetime]: ...


class RequestIsTerminalForRetentionCallback(Protocol):
    def __call__(__callback, status: dict[str, Any] | None) -> bool: ...


class RunBackupMaintenanceCallback(Protocol):
    def __call__(__callback, force: bool = ...) -> dict[str, Any]: ...


class SafeJsonCallback(Protocol):
    def __call__(__callback, data: object, code: int = ...) -> tuple[bytes, int]: ...


class ServerMaintenanceLoopCallback(Protocol):
    def __call__(__callback, interval_seconds: float = ...) -> None: ...


class StateSnapshotIsActiveCallback(Protocol):
    def __call__(__callback) -> bool: ...


class UniqueArchiveDestCallback(Protocol):
    def __call__(__callback, base_dir: Path, name: str) -> Path: ...


class UtcNowIsoCallback(Protocol):
    def __call__(__callback) -> str: ...


class VerifySystemBackupZipCallback(Protocol):
    def __call__(__callback, path: Path, manifest: dict[str, Any]) -> None: ...


class WriteArchiveMetaCallback(Protocol):
    def __call__(
        __callback,
        dest_dir: Path,
        *,
        kind: str,
        item_id: str,
        archived_at: datetime,
        active_created_at: Optional[datetime] = ...,
        details: dict[str, Any] | None = ...,
    ) -> None: ...


class WriteFileCallback(Protocol):
    def __call__(__callback, path: Path, text: str) -> None: ...


class WriteLastAutoBackupCallback(Protocol):
    def __call__(__callback, dt: datetime, file_name: str) -> None: ...


class WriteReplaceableBytesCallback(Protocol):
    def __call__(__callback, path: Path, data: bytes) -> None: ...


class WriteReplaceableJsonCallback(Protocol):
    def __call__(__callback, path: Path, value: Any) -> None: ...


class WriteReplaceableTextCallback(Protocol):
    def __call__(__callback, path: Path, text: str) -> None: ...
