"""Callable contracts for jobs operations; parameter names and result types are explicit."""

from __future__ import annotations
from typing import Any, Callable, Iterable, Mapping, Protocol, TYPE_CHECKING
from pathlib import Path
import subprocess

if TYPE_CHECKING:
    from metod_app.jobs.idempotency import JobCreateClaim


class AbandonPublicJobIdempotencyCallback(Protocol):
    def __call__(__callback, *, key: object, payload_sha256: str, owner_nonce: str) -> bool: ...


class AdminSheetDownloadNameCallback(Protocol):
    def __call__(
        __callback, job_root: Path, stored_filename: str, *, customer: Any = ..., sequence: int | None = ...
    ) -> str: ...


class CancelQueuedPublicJobCallback(Protocol):
    def __call__(__callback, job_id: str) -> bool: ...


class CatalogReviewSha256Callback(Protocol):
    def __call__(__callback, stage: dict[str, Any]) -> str: ...


class ClaimPublicJobIdempotencyCallback(Protocol):
    def __call__(
        __callback,
        *,
        key: object,
        payload: object,
        payload_sha256: str | None = ...,
        job_id: str,
        access_token: str,
    ) -> JobCreateClaim: ...


class CleanupPublicJobIdempotencyCallback(Protocol):
    def __call__(__callback, *, jobs_root: Path, cutoff_timestamp: float) -> dict[str, Any]: ...


class CommitPublicJobSlotCallback(Protocol):
    def __call__(__callback, ip: str, job_id: str, runner: Callable[[], None]) -> dict[str, Any]: ...


class CompactDxfTransportCallback(Protocol):
    def __call__(__callback, dxf_parts: dict[str, str]) -> tuple[dict[str, str], dict[str, str]]: ...


class CompletePublicJobIdempotencyCallback(Protocol):
    def __call__(
        __callback, *, key: object, payload_sha256: str, owner_nonce: str, response: Mapping[str, Any]
    ) -> None: ...


class CustomerDisplayNameCallback(Protocol):
    def __call__(__callback, customer: Any) -> str: ...


class CustomerNameFromJobCallback(Protocol):
    def __call__(__callback, job_json: dict[str, Any]) -> str: ...


class DxfTransportStatsCallback(Protocol):
    def __call__(__callback, payload: dict[str, Any]) -> dict[str, int]: ...


class EnforceJobOutputLimitCallback(Protocol):
    def __call__(
        __callback, master_root: Path, subjob_roots: list[Path] | None = ..., limit_bytes: int | None = ...
    ) -> int: ...


class EnforceJobTotalQtyLimitCallback(Protocol):
    def __call__(__callback, payload: dict[str, Any], limit_qty: int = ...) -> int: ...


class EnforceStateCapacityCallback(Protocol):
    def __call__(__callback, projected_bytes: int, projected_inodes: int = ...) -> dict[str, int]: ...


class EstimatePayloadAreaLowerBoundCallback(Protocol):
    def __call__(__callback, payload: dict[str, Any]) -> dict[str, Any]: ...


class EstimatePreflightJobFamilyBytesCallback(Protocol):
    def __call__(__callback, payload: dict[str, Any]) -> dict[str, Any]: ...


class ExpandDxfPayloadCallback(Protocol):
    def __call__(__callback, payload: dict[str, Any]) -> dict[str, str]: ...


class FilterPanelsCsvByMaterialCallback(Protocol):
    def __call__(__callback, panels_csv: str, material_code: str) -> str: ...


class FinalizationCompleteCallback(Protocol):
    def __call__(__callback, job_root: Path, _memo: dict[str, bool] | None = ...) -> bool: ...


class FinalizeSubjobOutputsCallback(Protocol):
    def __call__(__callback, job_root: Path) -> dict[str, Any]: ...


class FindExistingFileCallback(Protocol):
    def __call__(__callback, base_dir: Path, candidates: Iterable[str]) -> Path | None: ...


class FinishPublicJobSlotCallback(Protocol):
    def __call__(__callback, job_id: str) -> bool: ...


class GenerateLabelsJsonStrictCallback(Protocol):
    def __call__(__callback, job_root: Path) -> Path: ...


class GenerateStickertoolJsonCallback(Protocol):
    def __call__(__callback, job_root: Path) -> Path: ...


class GetPayloadTotalQtyCallback(Protocol):
    def __call__(__callback, payload: dict[str, Any]) -> int: ...


class GetPythonBaseCmdCallback(Protocol):
    def __call__(__callback) -> list[str]: ...


class InputDxfSourceMapCallback(Protocol):
    def __call__(__callback, input_dir: Path, part_ids: set[str]) -> dict[str, Path]: ...


class JobCancelRequestedCallback(Protocol):
    def __call__(__callback, job_id: str) -> bool: ...


class JobFamilySizeBytesCallback(Protocol):
    def __call__(__callback, master_root: Path, subjob_roots: list[Path] | None = ...) -> int: ...


class JobMaterialContextCallback(Protocol):
    def __call__(__callback, job_root: Path) -> dict[str, Any]: ...


class JobOutputLimitMessageCallback(Protocol):
    def __call__(__callback, size_bytes: int, limit_bytes: int) -> str: ...


class JobRuntimeStatePathCallback(Protocol):
    def __call__(__callback, job_id: str) -> Path: ...


class LaunchPublicJobItemCallback(Protocol):
    def __call__(__callback, item: dict[str, Any]) -> None: ...


class LoadJobRuntimeStateCallback(Protocol):
    def __call__(__callback, job_id: str) -> dict[str, Any]: ...


class LookupPublicJobIdempotencyCallback(Protocol):
    def __call__(__callback, *, key: object) -> JobCreateClaim | None: ...


class MaterialNameAndThicknessCallback(Protocol):
    def __call__(__callback, pricing: dict[str, Any], material_code: str) -> tuple[str, float]: ...


class ParsePanelsCsvCallback(Protocol):
    def __call__(__callback, text: str) -> list[dict[str, Any]]: ...


class PublicJobIdempotencyKeyExistsCallback(Protocol):
    def __call__(__callback, *, key: object) -> bool: ...


class PublicJobQueueLimitsCallback(Protocol):
    def __call__(__callback) -> tuple[int, int, int]: ...


class ReconcileInterruptedJobsOnStartupCallback(Protocol):
    def __call__(__callback) -> int: ...


class ReconcilePublicJobIdempotencyOnStartupCallback(Protocol):
    def __call__(__callback, *, jobs_root: Path) -> dict[str, Any]: ...


class RecoverPublicJobIdempotencyCallback(Protocol):
    def __call__(
        __callback, *, key: object, payload_sha256: str, response: Mapping[str, Any]
    ) -> dict[str, Any]: ...


class RefreshPublicJobQueueMetaLockedCallback(Protocol):
    def __call__(__callback, starting: list[dict[str, Any]], queued: list[dict[str, Any]]) -> None: ...


class RegisterJobProcessCallback(Protocol):
    def __call__(__callback, master_job_id: str, process: subprocess.Popen) -> None: ...


class ReleasePublicJobSlotCallback(Protocol):
    def __call__(__callback, ip: str) -> None: ...


class ReleaseStateCapacityReservationCallback(Protocol):
    def __call__(__callback, job_id: str) -> bool: ...


class ReserveStateCapacityCallback(Protocol):
    def __call__(
        __callback,
        job_id: str,
        projected_bytes: int,
        projected_inodes: int = ...,
        *,
        reservation_kind: str = ...,
    ) -> dict[str, int]: ...


class ResolveStickertoolMaterialDisplayNameCallback(Protocol):
    def __call__(
        __callback,
        material_code: str,
        job_json: dict[str, Any],
        panels_rows: list[dict[str, Any]],
        pricing_obj: dict[str, Any],
    ) -> str: ...


class SaveJobRuntimeStateCallback(Protocol):
    def __call__(__callback, job_id: str, state: str, **extra: Any) -> dict[str, Any]: ...


class SealedOutputArtifactsCallback(Protocol):
    def __call__(__callback, job_root: Path) -> dict[str, Path]: ...


class SheetSequenceFromFilenameCallback(Protocol):
    def __call__(__callback, filename: str, fallback: int = ...) -> int: ...


class TerminateOptimizerProcessCallback(Protocol):
    def __call__(
        __callback, process: subprocess.Popen, *, terminate_timeout: float = ..., kill_timeout: float = ...
    ) -> int | None: ...


class TransitionJobRuntimeStateCallback(Protocol):
    def __call__(
        __callback, job_id: str, state: str, *, allowed_from: set[str] | None = ..., **extra: Any
    ) -> tuple[bool, dict[str, Any]]: ...


class TryAcquirePublicJobSlotCallback(Protocol):
    def __call__(__callback, ip: str) -> tuple[bool, str]: ...


class UnregisterJobProcessCallback(Protocol):
    def __call__(__callback, master_job_id: str, process: subprocess.Popen) -> None: ...


class ValidatedCanonicalDxfTransportCallback(Protocol):
    def __call__(__callback, payload: dict[str, Any]) -> tuple[dict[str, str], dict[str, str]]: ...


class WriteMasterJobLinksCallback(Protocol):
    def __call__(__callback, master_job_id: str, subjobs: list[dict[str, Any]]) -> None: ...
