"""Explicit callback signatures grouped by the service that implements them."""
