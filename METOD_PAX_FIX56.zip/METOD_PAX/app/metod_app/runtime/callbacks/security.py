"""Callable contracts for security operations; parameter names and result types are explicit."""

from __future__ import annotations
from typing import Any, Optional, Protocol, TYPE_CHECKING
from pathlib import Path
from urllib.parse import ParseResult

if TYPE_CHECKING:
    from metod_app.http.wsgi import WsgiHandler


class AdminPasswordResetActivationIsEnabledCallback(Protocol):
    def __call__(__callback) -> bool: ...


class ClientIpCallback(Protocol):
    def __call__(__callback, handler: WsgiHandler) -> str: ...


class DirectPeerIpCallback(Protocol):
    def __call__(__callback, handler: WsgiHandler) -> str: ...


class ExtractRequestTokenCallback(Protocol):
    def __call__(
        __callback,
        handler: WsgiHandler,
        parsed: ParseResult | None = ...,
        body: Optional[dict[str, Any]] = ...,
    ) -> str: ...


class GetAdminCredentialsFilePathCallback(Protocol):
    def __call__(__callback) -> Path: ...


class GetAdminPasswordResetActivationFilePathCallback(Protocol):
    def __call__(__callback) -> Path: ...


class IpMatchesCallback(Protocol):
    def __call__(__callback, value: str, pattern: str) -> bool: ...


class IsExternallyExposedSecurityEnabledCallback(Protocol):
    def __call__(__callback) -> bool: ...


class IsHttpsRequestCallback(Protocol):
    def __call__(__callback, handler: WsgiHandler) -> bool: ...


class IsLoopbackClientCallback(Protocol):
    def __call__(__callback, handler: WsgiHandler) -> bool: ...


class IsLoopbackValueCallback(Protocol):
    def __call__(__callback, value: str) -> bool: ...


class IsPasswordHashValueCallback(Protocol):
    def __call__(__callback, v: Any) -> bool: ...


class IsProductionRuntimeCallback(Protocol):
    def __call__(__callback) -> bool: ...


class IsSecureAdminTransportCallback(Protocol):
    def __call__(__callback, handler: WsgiHandler) -> bool: ...


class IsTrustedProxyPeerCallback(Protocol):
    def __call__(__callback, handler: WsgiHandler) -> bool: ...


class LoadAdminPasswordResetActivationCallback(Protocol):
    def __call__(__callback) -> dict[str, Any] | None: ...


class NewPublicAccessTokenCallback(Protocol):
    def __call__(__callback) -> str: ...


class NormalizedAdminUsersCallback(Protocol):
    def __call__(__callback, credentials: dict[str, Any] | None) -> list[dict[str, Any]]: ...


class OriginAllowedCallback(Protocol):
    def __call__(__callback, origin: str, *, admin: bool = ...) -> bool: ...


class RateLimitAllowCallback(Protocol):
    def __call__(__callback, bucket: str, key: str, max_hits: int, window_sec: int) -> bool: ...


class RateLimitClearCallback(Protocol):
    def __call__(__callback, bucket: str, key: str) -> None: ...


class RateLimitIsBlockedCallback(Protocol):
    def __call__(__callback, bucket: str, key: str, max_hits: int, window_sec: int) -> bool: ...


class RateLimitRecordCallback(Protocol):
    def __call__(__callback, bucket: str, key: str) -> None: ...


class ReadJobAccessTokenCallback(Protocol):
    def __call__(__callback, job_id: str) -> str: ...
