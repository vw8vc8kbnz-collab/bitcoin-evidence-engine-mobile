"""Callable contracts for catalog operations; parameter names and result types are explicit."""

from __future__ import annotations
from typing import Any, Protocol, TYPE_CHECKING
from pathlib import Path

if TYPE_CHECKING:
    pass


class BestMaterialNameCallback(Protocol):
    def __call__(__callback, code: str, *candidates: Any) -> str: ...


class CachedSha256FileCallback(Protocol):
    def __call__(__callback, path: Path) -> str: ...


class ClassifyDxfCategoryCallback(Protocol):
    def __call__(__callback, filename: str) -> str: ...


class ClassifyDxfFilenameCallback(Protocol):
    def __call__(__callback, name: str) -> str: ...


class GetEmbeddedDxfsVersionCallback(Protocol):
    def __call__(__callback) -> int: ...


class InvalidateMaterialLookupCacheCallback(Protocol):
    def __call__(__callback) -> None: ...


class InvalidatePublicMaterialsResponseCacheCallback(Protocol):
    def __call__(__callback) -> None: ...


class LooksNumericMaterialNameCallback(Protocol):
    def __call__(__callback, v: str) -> bool: ...


class MaterialLookupSnapshotCallback(Protocol):
    def __call__(__callback) -> dict[str, Any]: ...


class MigrateEmbeddedDxfsToCategoriesCallback(Protocol):
    def __call__(__callback) -> None: ...


class PathContentSignatureCallback(Protocol):
    def __call__(__callback, path: Path) -> tuple[int, int, int, int, int] | None: ...


class RebuildEmbeddedDxfsManifestCallback(Protocol):
    def __call__(__callback) -> None: ...
