"""Callable contracts for requests operations; parameter names and result types are explicit."""

from __future__ import annotations
from typing import Any, Callable, Iterator, Optional, Protocol, TYPE_CHECKING
from pathlib import Path

if TYPE_CHECKING:
    pass


class ExtractRequestSummaryCallback(Protocol):
    def __call__(__callback, payload: dict[str, Any]) -> dict[str, Any]: ...


class FindRequestStatusForJobCallback(Protocol):
    def __call__(__callback, job_id: str) -> Optional[dict[str, Any]]: ...


class IterRequestStatusesCallback(Protocol):
    def __call__(__callback) -> Iterator[dict[str, Any]]: ...


class LinkedSubjobIdsCallback(Protocol):
    def __call__(__callback, parent_job_id: str) -> list[str]: ...


class LoadRequestPayloadCallback(Protocol):
    def __call__(__callback, request_id: str) -> dict[str, Any]: ...


class LoadStatusCallback(Protocol):
    def __call__(__callback, request_id: str) -> dict[str, Any] | None: ...


class MasterJobIdForCallback(Protocol):
    def __call__(__callback, job_id: str) -> str: ...


class MutateStatusCallback(Protocol):
    def __call__(
        __callback,
        request_id: str,
        mutator: Callable[[dict[str, Any] | None], dict[str, Any] | None],
        *,
        allow_cancelled_restore: bool = ...,
    ) -> tuple[dict[str, Any] | None, bool]: ...


class NewRequestIdCallback(Protocol):
    def __call__(__callback) -> str: ...


class PublicJobFamilyCompleteCallback(Protocol):
    def __call__(__callback, job_id: str, *, memo: dict[str, bool] | None = ...) -> bool: ...


class SaveStatusCallback(Protocol):
    def __call__(__callback, request_id: str, status: dict[str, Any]) -> dict[str, Any]: ...


class SubmissionMarkerPathCallback(Protocol):
    def __call__(__callback, parent_job_id: str) -> Path: ...
