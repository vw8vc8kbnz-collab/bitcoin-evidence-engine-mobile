"""Callable contracts for notifications operations; parameter names and result types are explicit."""

from __future__ import annotations
from typing import Any, Optional, Protocol, TYPE_CHECKING
from pathlib import Path

if TYPE_CHECKING:
    pass


class CalculationSummaryTextForNtfyCallback(Protocol):
    def __call__(__callback, job_ids: list[str] | None) -> tuple[str, str]: ...


class GetNotifyConfigFilePathCallback(Protocol):
    def __call__(__callback) -> Path: ...


class LoadNotifyConfigCallback(Protocol):
    def __call__(__callback) -> dict[str, Any]: ...


class NotifyPrivacyOptionsCallback(Protocol):
    def __call__(__callback) -> dict[str, Any]: ...


class NotifySubmittedCallback(Protocol):
    def __call__(
        __callback,
        request_id: str,
        payload: dict[str, Any],
        status: dict[str, Any] | None = ...,
        job_ids: list[str] | None = ...,
        authoritative_pricing: dict[str, Any] | None = ...,
    ) -> tuple[bool, str]: ...


class NtfyLogCallback(Protocol):
    def __call__(__callback, line: str) -> None: ...


class NtfyPublicSafeCustomerLinesCallback(Protocol):
    def __call__(__callback, status: dict[str, Any] | None, payload: dict[str, Any]) -> list[str]: ...


class NtfySendCallback(Protocol):
    def __call__(
        __callback,
        title: Optional[str] = ...,
        message: str = ...,
        click_url: Optional[str] = ...,
        priority: Optional[int] = ...,
        tags: Optional[list[str]] = ...,
    ) -> tuple[bool, str]: ...


class ValidatedNtfyTargetCallback(Protocol):
    def __call__(__callback, topic_url: str) -> tuple[str, str, tuple[str, ...]]: ...
