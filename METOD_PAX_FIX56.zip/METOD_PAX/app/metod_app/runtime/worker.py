"""Queue admission recovery, locking and long-running worker loop."""

from __future__ import annotations

import logging

from metod_app.identifiers import safe_identifier as _safe_id
from metod_app.security.redaction import safe_text as _safe_text
from safety_contracts import fsync_directory
import os
from safety_contracts import strict_json_load
import time
from metod_app.runtime.ports import RuntimeWorkerPorts


from metod_app.observability.failures import report_recovery

_WORKER_LOCK_FD: int | None = None


def acquire_worker_lock(ports: RuntimeWorkerPorts) -> bool:
    WORKER_LOCK = ports.get_worker_lock()
    _fcntl = ports.get_fcntl()

    global _WORKER_LOCK_FD
    try:
        WORKER_LOCK.parent.mkdir(parents=True, exist_ok=True)
        if _WORKER_LOCK_FD is not None:
            return False
        if _fcntl is None:
            fd = os.open(str(WORKER_LOCK), os.O_RDWR | os.O_CREAT | os.O_EXCL, 0o640)
        else:
            fd = os.open(str(WORKER_LOCK), os.O_RDWR | os.O_CREAT, 0o640)
            try:
                _fcntl.flock(fd, _fcntl.LOCK_EX | _fcntl.LOCK_NB)
            except (OSError, ValueError, TypeError, OverflowError):
                os.close(fd)
                return False
        os.ftruncate(fd, 0)
        os.write(fd, (str(os.getpid()) + "\n").encode("ascii"))
        os.fsync(fd)
        fsync_directory(WORKER_LOCK.parent)
        _WORKER_LOCK_FD = fd
        return True
    except Exception as recovery_error:
        report_recovery("metod_app.runtime.worker.boundary.42", recovery_error)
        return False


def release_worker_lock(ports: RuntimeWorkerPorts) -> None:
    WORKER_LOCK = ports.get_worker_lock()
    _fcntl = ports.get_fcntl()

    global _WORKER_LOCK_FD
    try:
        fd = _WORKER_LOCK_FD
        _WORKER_LOCK_FD = None
        if fd is not None:
            if _fcntl is not None:
                _fcntl.flock(fd, _fcntl.LOCK_UN)
            os.close(fd)
        if _fcntl is None and WORKER_LOCK.exists():
            WORKER_LOCK.unlink()
            fsync_directory(WORKER_LOCK.parent)
    except Exception as recovery_error:
        report_recovery("metod_app.ports.worker.release_worker_lock.53", recovery_error)


def process_one_queue_item(ports: RuntimeWorkerPorts) -> bool:
    """Process one pending queue item. Returns True if something was processed."""
    JOBS = ports.get_jobs()
    QUEUE_DONE = ports.get_queue_done()
    QUEUE_FAILED = ports.get_queue_failed()
    QUEUE_PENDING = ports.get_queue_pending()
    QUEUE_PROCESSING = ports.get_queue_processing()
    _append_system_event = ports.append_system_event
    _ensure_request_dirs = ports.ensure_request_dirs
    _finalization_complete = ports.finalization_complete
    _guess_customer_name = ports.guess_customer_name
    _linked_subjob_ids = ports.linked_subjob_ids
    _load_status = ports.load_status
    _move_queue_file_safe = ports.move_queue_file_safe

    _save_status = ports.save_status
    _state_snapshot_is_active = ports.state_snapshot_is_active

    if _state_snapshot_is_active():
        return False
    _ensure_request_dirs()
    items = sorted(QUEUE_PENDING.glob("*.json"))
    if not items:
        return False

    item_path = items[0]
    try:
        q_item = strict_json_load(item_path)
    except (OSError, ValueError, TypeError, OverflowError) as e:
        _append_system_event(
            level="error",
            component="jobs",
            message_user="Een queue-item kon niet worden gelezen",
            message_tech=str(e),
            job_id=_safe_text(item_path.stem, 120),
            status="open",
        )
        # bad queue item -> move to failed
        try:
            _move_queue_file_safe(item_path, QUEUE_FAILED)
        except Exception as recovery_error:
            report_recovery("metod_app.ports.worker.process_one_queue_item.92", recovery_error)
        return True

    request_id = _safe_id(q_item.get("requestId") or "", 120)
    if not request_id:
        _append_system_event(
            level="error",
            component="jobs",
            message_user="Een queue-item mist requestId",
            message_tech=f"Queue item {item_path.name} has no requestId",
            status="open",
        )
        try:
            _move_queue_file_safe(item_path, QUEUE_FAILED)
        except Exception as recovery_error:
            report_recovery("metod_app.ports.worker.process_one_queue_item.101", recovery_error)
        return True

    # Move to processing (atomic)
    try:
        processing_path = _move_queue_file_safe(item_path, QUEUE_PROCESSING)
    except Exception as recovery_error:
        report_recovery("metod_app.runtime.worker.boundary.112", recovery_error)
        return True

    status = _load_status(request_id) or {}
    # If cancelled, skip
    if status.get("publicStatus") == "CANCELLED" or status.get("internalStatus") == "CANCELLED":
        status["internalStatus"] = "CANCELLED"
        status["internalStatusLabel"] = "Geannuleerd"
        _save_status(request_id, status)
        try:
            _move_queue_file_safe(processing_path, QUEUE_DONE)
        except Exception as recovery_error:
            report_recovery("metod_app.ports.worker.process_one_queue_item.119", recovery_error)
        return True

    # Update status: processing
    status["internalStatus"] = "PROCESSING"
    status["internalStatusLabel"] = "Bezig"
    _save_status(request_id, status)

    try:
        # the queue is link-only. It must never call _create_job_from_payload;
        # optimization already happened under /api/jobs before final submission.
        job = status.get("job") if isinstance(status.get("job"), dict) else {}
        parent_job_id = _safe_id(str(q_item.get("parentJobId") or job.get("parentJobId") or "").strip(), 200)
        if not parent_job_id or not _finalization_complete(JOBS / parent_job_id):
            raise RuntimeError("LEGACY_QUEUE_ITEM_REQUIRES_REVIEW")
        status["internalStatus"] = "DONE"
        status["internalStatusLabel"] = "Gekoppeld aan afgeronde berekening"
        status["job"] = {
            "parentJobId": parent_job_id,
            "subjobs": _linked_subjob_ids(parent_job_id),
        }
        status["error"] = None
        _save_status(request_id, status)
        _move_queue_file_safe(processing_path, QUEUE_DONE)
    except Exception as e:
        # Fail closed. Re-optimizing a submitted request could change price/output and is
        # therefore never an acceptable recovery strategy.
        status["internalStatus"] = "FAILED"
        status["internalStatusLabel"] = "Handmatige controle nodig"
        status["error"] = {
            "code": "LEGACY_QUEUE_ITEM_REQUIRES_REVIEW",
            "message": "Bestaand queue-item kon niet veilig aan een afgeronde job worden gekoppeld.",
        }
        _save_status(request_id, status)
        _append_system_event(
            level="error",
            component="jobs",
            message_user="Bestaand queue-item vereist handmatige controle",
            message_tech=str(e),
            request_id=request_id,
            job_id=_safe_text((status.get("job") or {}).get("parentJobId"), 120),
            customer_name=_guess_customer_name(request_id=request_id, status=status),
            status="open",
        )
        try:
            _move_queue_file_safe(processing_path, QUEUE_FAILED)
        except Exception as recovery_error:
            report_recovery("metod_app.ports.worker.process_one_queue_item.158", recovery_error)

    return True


def recover_processing_queue_items(ports: RuntimeWorkerPorts) -> dict:
    """Recover only processing items that can be linked without doing new work."""
    JOBS = ports.get_jobs()
    QUEUE_FAILED = ports.get_queue_failed()
    QUEUE_PENDING = ports.get_queue_pending()
    QUEUE_PROCESSING = ports.get_queue_processing()
    _ensure_request_dirs = ports.ensure_request_dirs
    _finalization_complete = ports.finalization_complete
    _load_status = ports.load_status
    _move_queue_file_safe = ports.move_queue_file_safe

    _save_status = ports.save_status

    result = {"requeued": 0, "failed": 0}
    _ensure_request_dirs()
    for path in sorted(QUEUE_PROCESSING.glob("*.json")):
        try:
            q_item = strict_json_load(path)
            request_id = _safe_id(str(q_item.get("requestId") or path.stem).strip(), 120)
            status = _load_status(request_id) or {}
            job = status.get("job") if isinstance(status.get("job"), dict) else {}
            parent = _safe_id(str(q_item.get("parentJobId") or job.get("parentJobId") or "").strip(), 200)
            if parent and _finalization_complete(JOBS / parent):
                _move_queue_file_safe(path, QUEUE_PENDING)
                result["requeued"] += 1
                continue
            status["internalStatus"] = "FAILED"
            status["internalStatusLabel"] = "Handmatige controle nodig"
            status["error"] = {
                "code": "LEGACY_QUEUE_ITEM_REQUIRES_REVIEW",
                "message": "Queue-item uit een eerdere release kan niet veilig automatisch worden hervat.",
            }
            if request_id:
                _save_status(request_id, status)
            _move_queue_file_safe(path, QUEUE_FAILED)
            result["failed"] += 1
        except Exception:
            try:
                _move_queue_file_safe(path, QUEUE_FAILED)
                result["failed"] += 1
            except Exception as recovery_error:
                report_recovery("metod_app.ports.worker.recover_processing_queue_items.204", recovery_error)
    return result


def worker_loop(ports: RuntimeWorkerPorts, poll_seconds: float = 1.0) -> None:
    run_backup_maintenance = ports.run_backup_maintenance
    run_queue_maintenance = ports.run_queue_maintenance
    run_retention_maintenance = ports.run_retention_maintenance

    _acquire_worker_lock = lambda: acquire_worker_lock(ports)
    _release_worker_lock = lambda: release_worker_lock(ports)
    _recover_processing_queue_items = lambda: recover_processing_queue_items(ports)
    process_one_queue_item = lambda: globals()["process_one_queue_item"](ports)

    if not _acquire_worker_lock():
        logging.getLogger(__name__).info("Worker already running (lock exists).")
        return
    logging.getLogger(__name__).info("Worker started.")
    try:
        recovery = _recover_processing_queue_items()
        if recovery.get("requeued") or recovery.get("failed"):
            logging.getLogger(__name__).info("Current queue recovery: ")
    except Exception as e:
        report_recovery("metod_app.runtime.worker.boundary.228", e)
        logging.getLogger(__name__).info("Current queue recovery error:")
    try:
        while True:
            did = False
            try:
                did = process_one_queue_item()
            except Exception as e:
                report_recovery("metod_app.runtime.worker.boundary.235", e)
                logging.getLogger(__name__).info("Worker error:")
            if not did:
                try:
                    run_retention_maintenance(force=False)
                except Exception as recovery_error:
                    report_recovery("metod_app.ports.worker.worker_loop.238", recovery_error)
                try:
                    run_backup_maintenance(force=False)
                except Exception as recovery_error:
                    report_recovery("metod_app.ports.worker.worker_loop.242", recovery_error)
                try:
                    run_queue_maintenance(force=False)
                except Exception as recovery_error:
                    report_recovery("metod_app.ports.worker.worker_loop.246", recovery_error)
                time.sleep(poll_seconds)
    except KeyboardInterrupt:
        return
    finally:
        _release_worker_lock()
        logging.getLogger(__name__).info("Worker stopped.")
