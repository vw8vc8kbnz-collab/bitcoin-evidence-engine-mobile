"""Immutable dependency contracts. No module objects or reflective service lookup.

Value suppliers keep shared state live; callable fields identify business operations.
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Callable, TYPE_CHECKING
from pathlib import Path

if TYPE_CHECKING:
    from .callbacks.catalog import (
        BestMaterialNameCallback,
        CachedSha256FileCallback,
        ClassifyDxfCategoryCallback as ClassifyDxfCategoryCallback,
        ClassifyDxfFilenameCallback as ClassifyDxfFilenameCallback,
        GetEmbeddedDxfsVersionCallback,
        InvalidateMaterialLookupCacheCallback,
        InvalidatePublicMaterialsResponseCacheCallback,
        LooksNumericMaterialNameCallback as LooksNumericMaterialNameCallback,
        MaterialLookupSnapshotCallback,
        MigrateEmbeddedDxfsToCategoriesCallback,
        PathContentSignatureCallback as PathContentSignatureCallback,
        RebuildEmbeddedDxfsManifestCallback,
    )
    from .callbacks.jobs import (
        AbandonPublicJobIdempotencyCallback,
        AdminSheetDownloadNameCallback,
        CancelQueuedPublicJobCallback,
        CatalogReviewSha256Callback,
        ClaimPublicJobIdempotencyCallback,
        CleanupPublicJobIdempotencyCallback,
        CommitPublicJobSlotCallback,
        CompactDxfTransportCallback,
        CompletePublicJobIdempotencyCallback,
        CustomerDisplayNameCallback,
        CustomerNameFromJobCallback,
        DxfTransportStatsCallback,
        EnforceJobOutputLimitCallback,
        EnforceJobTotalQtyLimitCallback,
        EnforceStateCapacityCallback,
        EstimatePayloadAreaLowerBoundCallback,
        EstimatePreflightJobFamilyBytesCallback,
        ExpandDxfPayloadCallback,
        FilterPanelsCsvByMaterialCallback,
        FinalizationCompleteCallback,
        FinalizeSubjobOutputsCallback,
        FindExistingFileCallback,
        FinishPublicJobSlotCallback,
        GenerateLabelsJsonStrictCallback,
        GenerateStickertoolJsonCallback,
        GetPayloadTotalQtyCallback,
        GetPythonBaseCmdCallback,
        InputDxfSourceMapCallback,
        JobCancelRequestedCallback,
        JobFamilySizeBytesCallback,
        JobMaterialContextCallback,
        JobOutputLimitMessageCallback,
        JobRuntimeStatePathCallback,
        LaunchPublicJobItemCallback,
        LoadJobRuntimeStateCallback,
        LookupPublicJobIdempotencyCallback,
        MaterialNameAndThicknessCallback,
        ParsePanelsCsvCallback,
        PublicJobIdempotencyKeyExistsCallback,
        PublicJobQueueLimitsCallback,
        ReconcileInterruptedJobsOnStartupCallback,
        ReconcilePublicJobIdempotencyOnStartupCallback,
        RecoverPublicJobIdempotencyCallback,
        RefreshPublicJobQueueMetaLockedCallback,
        RegisterJobProcessCallback,
        ReleasePublicJobSlotCallback,
        ReleaseStateCapacityReservationCallback,
        ReserveStateCapacityCallback,
        ResolveStickertoolMaterialDisplayNameCallback,
        SaveJobRuntimeStateCallback,
        SealedOutputArtifactsCallback,
        SheetSequenceFromFilenameCallback,
        TerminateOptimizerProcessCallback,
        TransitionJobRuntimeStateCallback,
        TryAcquirePublicJobSlotCallback,
        ValidatedCanonicalDxfTransportCallback,
        WriteMasterJobLinksCallback,
    )
    from .callbacks.notifications import (
        CalculationSummaryTextForNtfyCallback,
        GetNotifyConfigFilePathCallback,
        LoadNotifyConfigCallback,
        NotifyPrivacyOptionsCallback,
        NotifySubmittedCallback,
        NtfyLogCallback,
        NtfyPublicSafeCustomerLinesCallback,
        NtfySendCallback,
        ValidatedNtfyTargetCallback,
    )
    from .callbacks.observability import (
        AppendSystemEventCallback,
        GuessCustomerNameCallback,
        GuessCustomerNameFromPayloadCallback,
        ObservabilityPublicJobSnapshotCallback,
        ReadSystemEventsCallback,
    )
    from .callbacks.pricing import (
        AggregateMaterialsFromSubjobQuotesCallback,
        ApplySellPricingToQuoteCallback,
        CapturePublicJobPricingAuthorityCallback,
        DefaultPricingConfigCallback as DefaultPricingConfigCallback,
        EnsurePricingConfigFilesCallback as EnsurePricingConfigFilesCallback,
        EnsurePricingMaterialsCallback,
        FormatEurCallback,
        FormatMCallback,
        LoadPricingConfigCallback,
        MigrateLegacyMaterialsToDirectSellPricesCallback,
        NormalizePricingConfigSchemaCallback as NormalizePricingConfigSchemaCallback,
        ParseCalculationSummaryTotalsCallback,
        SavePricingConfigCallback,
        WriteHumanCalculationSummaryCallback,
    )
    from .callbacks.requests import (
        ExtractRequestSummaryCallback,
        FindRequestStatusForJobCallback,
        IterRequestStatusesCallback,
        LinkedSubjobIdsCallback,
        LoadRequestPayloadCallback,
        LoadStatusCallback,
        MasterJobIdForCallback,
        MutateStatusCallback,
        NewRequestIdCallback,
        PublicJobFamilyCompleteCallback,
        SaveStatusCallback,
        SubmissionMarkerPathCallback,
    )
    from .callbacks.runtime import (
        ApiAdminControlCenterCallback,
        ApiAdminJobsCallback,
        ApiAdminRequestDownloadZipCallback,
        ApiAdminRequestFileCallback,
        ApiAdminRequestFilesCallback,
        ApiAdminRequestsCallback,
        ApiAdminRequestsUpdateCallback,
        ApiDownloadCallback,
        ApiDraftLoadCallback,
        ApiDraftSaveCallback,
        ApiDxfManifestMetaCallback,
        ApiJobFileCallback,
        ApiSubjobFileCallback,
        AppendClientLogCallback,
        BuildRequestFileManifestCallback,
        ClassifyOutputKindCallback,
        CollectJobOutputFilesCallback,
        CreateJobFromPayloadCallback,
        DedupeAdminDxfFilesCallback,
        DirSizeBytesCallback,
        EdgeMetersByDecorCallback,
        ExtractStrictCalculationPricingSummaryCallback,
        FindOrGenerateStickertoolFileCallback,
        InvalidateMaterialNameCacheCallback,
        LoadMaterialNameByCodeCallback as LoadMaterialNameByCodeCallback,
        PrometheusMetricsCallback,
        ReadinessReportCallback,
        RunQueueMaintenanceCallback,
        RunRetentionMaintenanceCallback,
        SyncPublicJobAdmissionLegacyCountersCallback,
        SyncPublicJobSchedulerLegacyStateCallback,
        WorkerLoopCallback,
    )
    from .callbacks.security import (
        AdminPasswordResetActivationIsEnabledCallback,
        ClientIpCallback,
        DirectPeerIpCallback,
        ExtractRequestTokenCallback,
        GetAdminCredentialsFilePathCallback,
        GetAdminPasswordResetActivationFilePathCallback,
        IpMatchesCallback,
        IsExternallyExposedSecurityEnabledCallback,
        IsHttpsRequestCallback,
        IsLoopbackClientCallback,
        IsLoopbackValueCallback,
        IsPasswordHashValueCallback,
        IsProductionRuntimeCallback,
        IsSecureAdminTransportCallback,
        IsTrustedProxyPeerCallback,
        LoadAdminPasswordResetActivationCallback,
        NewPublicAccessTokenCallback,
        NormalizedAdminUsersCallback,
        OriginAllowedCallback,
        RateLimitAllowCallback,
        RateLimitClearCallback,
        RateLimitIsBlockedCallback,
        RateLimitRecordCallback,
        ReadJobAccessTokenCallback,
    )
    from .callbacks.storage import (
        ArchiveJournalEntriesCallback,
        ArchiveJournalPathCallback,
        ArchiveJournalWriteCallback,
        ArchiveRequestAndLinkedJobsCallback,
        AssertBackupCapacityCallback,
        AtomicWriteJsonCallback,
        BackupSourceInventoryCallback,
        BeginConsistentSnapshotCallback,
        CleanupOldBackupsCallback,
        CompleteArchiveJournalCallback,
        CreateSystemBackupCallback,
        EndConsistentSnapshotCallback,
        EnsureArchiveDirsCallback,
        EnsureRequestDirsCallback,
        EnsureSystemDirsCallback,
        ExclusiveStateMaintenanceCallback,
        InitializeExternalStateCallback,
        JobCreatedDtCallback,
        LinkOrCopyFileCallback,
        LinkedJobIdsFromStatusCallback,
        ListBackupsCallback,
        MoveQueueFileSafeCallback,
        NowIsoCallback,
        ParseIsoDtCallback,
        PathDtCallback,
        ReadJsonBodyLimitedCallback,
        ReadLastAutoBackupDtCallback,
        ReconcileArchiveTransactionsCallback,
        RecordMaintenanceFailureCallback,
        RequestArchiveMetaDtCallback,
        RequestCreatedDtFromStatusCallback,
        RequestIsTerminalForRetentionCallback,
        RunBackupMaintenanceCallback,
        SafeJsonCallback,
        ServerMaintenanceLoopCallback,
        StateSnapshotIsActiveCallback,
        UniqueArchiveDestCallback,
        VerifySystemBackupZipCallback,
        WriteArchiveMetaCallback,
        WriteFileCallback,
        WriteLastAutoBackupCallback,
        WriteReplaceableBytesCallback,
        WriteReplaceableJsonCallback,
        WriteReplaceableTextCallback,
    )
    from metod_app.http.wsgi import WsgiHandler

if TYPE_CHECKING:
    from collections import deque
    from types import ModuleType
    from typing import Pattern
    from .resource_types import LockLike
    from metod_app.admin.access import AdminAccessController
    from metod_app.admin.access import AdminSessionStore
    from metod_app.admin.privacy import CustomerPrivacyService
    from metod_app.jobs.finalization import JobFinalizationService
    from metod_app.jobs.lifecycle import JobLifecycleFacadeService
    from metod_app.jobs.reconciliation import JobRestartReconciler
    from metod_app.observability.service import ObservabilityService
    from metod_app.jobs.process_supervisor import OptimizerProcessSupervisor
    from metod_app.jobs.admission import PublicJobAdmission
    from metod_app.jobs.scheduler import PublicJobScheduler
    from metod_app.requests.downloads import RequestDownloadProjectionService
    from metod_app.jobs.admission import StateCapacityReservations
    from metod_app.storage.maintenance import StateMaintenanceBarrier
    from metod_app.http.static import StaticHttpAdapterService
    from metod_app.requests.submission import SubmissionService


@dataclass(frozen=True, slots=True, kw_only=True)
class PricingReportRuntimePorts:
    """Dependencies owned by pricing.report_runtime."""

    get_cnc_cost_per_sheet: Callable[[], float]
    get_drawing_cost_fixed: Callable[[], float]
    get_edge_band_price_per_m: Callable[[], float]
    get_jobs: Callable[[], Path]
    get_transport_cost_fixed: Callable[[], float]
    aggregate_materials_from_subjob_quotes: AggregateMaterialsFromSubjobQuotesCallback
    best_material_name: BestMaterialNameCallback
    find_request_status_for_job: FindRequestStatusForJobCallback
    format_eur: FormatEurCallback
    format_m: FormatMCallback
    job_material_context: JobMaterialContextCallback
    load_pricing_config: LoadPricingConfigCallback
    load_request_payload: LoadRequestPayloadCallback
    parse_panels_csv: ParsePanelsCsvCallback


@dataclass(frozen=True, slots=True, kw_only=True)
class PricingRuntimePorts:
    """Dependencies owned by pricing.runtime."""

    get_cnc_cost_per_sheet: Callable[[], float]
    get_config_dir: Callable[[], Path]
    get_drawing_cost_fixed: Callable[[], float]
    get_edge_band_price_per_m: Callable[[], float]
    get_jobs: Callable[[], Path]
    get_legacy_sheet_price_factor_default: Callable[[], float]
    get_material_library_path: Callable[[], Path]
    get_pricing_active: Callable[[], Path]
    get_pricing_audit: Callable[[], Path]
    get_pricing_seed_path: Callable[[], Path]
    get_pricing_versions: Callable[[], Path]
    get_system_dir: Callable[[], Path]
    get_transport_cost_fixed: Callable[[], float]
    get_material_library_lock: Callable[[], LockLike]
    get_pricing_config_lock: Callable[[], LockLike]
    atomic_write_json: AtomicWriteJsonCallback
    material_lookup_snapshot: MaterialLookupSnapshotCallback
    parse_panels_csv: ParsePanelsCsvCallback
    utc_now_iso: NowIsoCallback
    catalog: StorageCatalogPublicationPorts


@dataclass(frozen=True, slots=True, kw_only=True)
class StorageArchiveRuntimePorts:
    """Dependencies owned by storage.archive_runtime."""

    get_archive_jobs: Callable[[], Path]
    get_archive_meta_name: Callable[[], str]
    get_archive_queue_done: Callable[[], Path]
    get_archive_queue_failed: Callable[[], Path]
    get_archive_requests: Callable[[], Path]
    get_archive_root: Callable[[], Path]
    get_archive_transactions: Callable[[], Path]
    get_jobs: Callable[[], Path]
    get_queue_done: Callable[[], Path]
    get_queue_failed: Callable[[], Path]
    get_requests: Callable[[], Path]
    get_submission_idempotency_dir: Callable[[], Path]
    get_archive_transaction_lock: Callable[[], LockLike]
    append_system_event: AppendSystemEventCallback
    archive_journal_entries: ArchiveJournalEntriesCallback
    archive_journal_path: ArchiveJournalPathCallback
    archive_journal_write: ArchiveJournalWriteCallback
    atomic_write_json: AtomicWriteJsonCallback
    complete_archive_journal: CompleteArchiveJournalCallback
    ensure_archive_dirs: EnsureArchiveDirsCallback
    get_fcntl: Callable[[], ModuleType | None]
    get_job_meta: Callable[[], dict[str, dict[str, Any]]]
    linked_job_ids_from_status: LinkedJobIdsFromStatusCallback
    load_status: LoadStatusCallback
    parse_iso_dt: ParseIsoDtCallback
    path_dt: PathDtCallback
    request_created_dt_from_status: RequestCreatedDtFromStatusCallback
    submission_marker_path: SubmissionMarkerPathCallback
    unique_archive_dest: UniqueArchiveDestCallback
    utc_now_iso: NowIsoCallback
    write_archive_meta: WriteArchiveMetaCallback


@dataclass(frozen=True, slots=True, kw_only=True)
class StorageCatalogPublicationPorts:
    """Dependencies owned by storage.catalog_publication."""

    get_catalog_import_root: Callable[[], Path]
    get_catalog_public_id_registry: Callable[[], Path]
    get_catalog_taxonomy_registry: Callable[[], Path]
    get_decor_media_root: Callable[[], Path]
    get_material_library_path: Callable[[], Path]
    get_system_dir: Callable[[], Path]
    get_pricing_config_lock: Callable[[], LockLike]
    invalidate_material_lookup_cache: InvalidateMaterialLookupCacheCallback
    invalidate_material_name_cache: InvalidateMaterialNameCacheCallback
    invalidate_public_materials_response_cache: InvalidatePublicMaterialsResponseCacheCallback


@dataclass(frozen=True, slots=True, kw_only=True)
class StorageBackupRuntimePorts:
    """Dependencies owned by storage.backup_runtime."""

    get_archive_jobs: Callable[[], Path]
    get_archive_queue_done: Callable[[], Path]
    get_archive_queue_failed: Callable[[], Path]
    get_archive_requests: Callable[[], Path]
    get_auto_backup_interval_days: Callable[[], int]
    get_auto_backup_keep: Callable[[], int]
    get_backups_dir: Callable[[], Path]
    get_catalog_import_history: Callable[[], Path]
    get_catalog_import_root: Callable[[], Path]
    get_config_dir: Callable[[], Path]
    get_decor_media_root: Callable[[], Path]
    get_drafts: Callable[[], Path]
    get_dxf_library_root: Callable[[], Path]
    get_index_dir: Callable[[], Path]
    get_jobs: Callable[[], Path]
    get_job_create_idempotency_dir: Callable[[], Path]
    get_last_auto_backup_file: Callable[[], Path]
    get_manual_backup_keep: Callable[[], int]
    get_material_library_path: Callable[[], Path]
    get_material_library_seed_path: Callable[[], Path]
    get_queue_done: Callable[[], Path]
    get_queue_failed: Callable[[], Path]
    get_queue_pending: Callable[[], Path]
    get_queue_processing: Callable[[], Path]
    get_requests: Callable[[], Path]
    get_root: Callable[[], Path]
    get_security_build: Callable[[], str]
    get_state_root: Callable[[], Path]
    get_submission_idempotency_dir: Callable[[], Path]
    get_system_dir: Callable[[], Path]
    get_state_snapshot_lock: Callable[[], LockLike]
    append_system_event: AppendSystemEventCallback
    assert_backup_capacity: AssertBackupCapacityCallback
    backup_source_inventory: BackupSourceInventoryCallback
    begin_consistent_snapshot: BeginConsistentSnapshotCallback
    cleanup_old_backups: CleanupOldBackupsCallback
    create_system_backup: CreateSystemBackupCallback
    end_consistent_snapshot: EndConsistentSnapshotCallback
    ensure_system_dirs: EnsureSystemDirsCallback
    exclusive_state_maintenance: ExclusiveStateMaintenanceCallback
    now_iso: NowIsoCallback
    read_last_auto_backup_dt: ReadLastAutoBackupDtCallback
    verify_system_backup_zip: VerifySystemBackupZipCallback
    write_last_auto_backup: WriteLastAutoBackupCallback
    catalog: StorageCatalogPublicationPorts


@dataclass(frozen=True, slots=True, kw_only=True)
class StorageIoRuntimePorts:
    """Dependencies owned by storage.io_runtime."""

    get_archive_jobs: Callable[[], Path]
    get_archive_queue_done: Callable[[], Path]
    get_archive_queue_failed: Callable[[], Path]
    get_archive_requests: Callable[[], Path]
    get_archive_root: Callable[[], Path]
    get_archive_transactions: Callable[[], Path]
    get_backups_dir: Callable[[], Path]
    get_index_dir: Callable[[], Path]
    get_queue_dir: Callable[[], Path]
    get_queue_done: Callable[[], Path]
    get_queue_failed: Callable[[], Path]
    get_queue_pending: Callable[[], Path]
    get_queue_processing: Callable[[], Path]
    get_requests: Callable[[], Path]
    get_submission_idempotency_dir: Callable[[], Path]
    get_system_dir: Callable[[], Path]
    write_replaceable_bytes: WriteReplaceableBytesCallback
    write_replaceable_text: WriteReplaceableTextCallback


@dataclass(frozen=True, slots=True, kw_only=True)
class StorageRetentionRuntimePorts:
    """Dependencies owned by storage.retention_runtime."""

    get_archive_jobs: Callable[[], Path]
    get_archive_queue_done: Callable[[], Path]
    get_archive_queue_failed: Callable[[], Path]
    get_archive_requests: Callable[[], Path]
    get_catalog_import_history: Callable[[], Path]
    get_catalog_import_root: Callable[[], Path]
    get_decor_media_root: Callable[[], Path]
    get_drafts: Callable[[], Path]
    get_jobs: Callable[[], Path]
    get_material_library_path: Callable[[], Path]
    get_orphan_job_retention_days: Callable[[], int]
    get_queue_done: Callable[[], Path]
    get_queue_failed: Callable[[], Path]
    get_requests: Callable[[], Path]
    get_retention_active_days: Callable[[], int]
    get_retention_archive_days: Callable[[], int]
    get_retention_open_request_max_days: Callable[[], int]
    get_state_root: Callable[[], Path]
    get_submission_idempotency_dir: Callable[[], Path]
    get_system_dir: Callable[[], Path]
    get_system_log_file: Callable[[], Path]
    get_catalog_image_sync_active: Callable[[], set[str]]
    get_catalog_image_sync_lock: Callable[[], LockLike]
    get_public_material_id_re: Callable[[], Pattern[str]]
    get_server_maintenance_loop_seconds: Callable[[], int]
    append_system_event: AppendSystemEventCallback
    archive_request_and_linked_jobs: ArchiveRequestAndLinkedJobsCallback
    cleanup_public_job_idempotency: CleanupPublicJobIdempotencyCallback
    ensure_archive_dirs: EnsureArchiveDirsCallback
    ensure_request_dirs: EnsureRequestDirsCallback
    ensure_system_dirs: EnsureSystemDirsCallback
    find_request_status_for_job: FindRequestStatusForJobCallback
    job_created_dt: JobCreatedDtCallback
    linked_job_ids_from_status: LinkedJobIdsFromStatusCallback
    load_status: LoadStatusCallback
    path_dt: PathDtCallback
    record_maintenance_failure: RecordMaintenanceFailureCallback
    request_archive_meta_dt: RequestArchiveMetaDtCallback
    request_created_dt_from_status: RequestCreatedDtFromStatusCallback
    request_is_terminal_for_retention: RequestIsTerminalForRetentionCallback
    save_status: SaveStatusCallback
    run_backup_maintenance: RunBackupMaintenanceCallback
    run_queue_maintenance: RunQueueMaintenanceCallback
    run_retention_maintenance: RunRetentionMaintenanceCallback


@dataclass(frozen=True, slots=True, kw_only=True)
class RuntimeCompositionPorts:
    """Dependencies owned by runtime.composition."""

    get_dxf_library_root: Callable[[], Path]
    get_dxf_manifest_path: Callable[[], Path]
    get_jobs: Callable[[], Path]
    get_job_output_max_bytes: Callable[[], int]
    JobCancelledError: type[RuntimeError]
    get_material_library_path: Callable[[], Path]
    get_pricing_active: Callable[[], Path]
    get_queue_pending: Callable[[], Path]
    get_queue_processing: Callable[[], Path]
    get_requests: Callable[[], Path]
    get_root: Callable[[], Path]
    get_security_build: Callable[[], str]
    get_state_root: Callable[[], Path]
    get_submission_idempotency_dir: Callable[[], Path]
    get_system_dir: Callable[[], Path]
    get_system_log_file: Callable[[], Path]
    get_admin_session_store: Callable[[], AdminSessionStore]
    get_dummy_admin_password_hash: Callable[[], str]
    get_dummy_admin_totp_secret: Callable[[], str]
    get_optimizer_process_supervisor: Callable[[], OptimizerProcessSupervisor]
    get_pricing_config_lock: Callable[[], LockLike]
    get_submission_idempotency_lock: Callable[[], LockLike]
    abandon_public_job_idempotency: AbandonPublicJobIdempotencyCallback
    admin_sheet_download_name: AdminSheetDownloadNameCallback
    append_client_log: AppendClientLogCallback
    append_system_event: AppendSystemEventCallback
    apply_sell_pricing_to_quote: ApplySellPricingToQuoteCallback
    atomic_write_json: AtomicWriteJsonCallback
    best_material_name: BestMaterialNameCallback
    build_request_file_manifest: BuildRequestFileManifestCallback
    cached_sha256_file: CachedSha256FileCallback
    cancel_queued_public_job: CancelQueuedPublicJobCallback
    capture_public_job_pricing_authority: CapturePublicJobPricingAuthorityCallback
    claim_public_job_idempotency: ClaimPublicJobIdempotencyCallback
    classify_output_kind: ClassifyOutputKindCallback
    client_ip: ClientIpCallback
    collect_job_output_files: CollectJobOutputFilesCallback
    commit_public_job_slot: CommitPublicJobSlotCallback
    complete_public_job_idempotency: CompletePublicJobIdempotencyCallback
    create_job_from_payload: CreateJobFromPayloadCallback
    dedupe_admin_dxf_files: DedupeAdminDxfFilesCallback
    dir_size_bytes: DirSizeBytesCallback
    dxf_transport_stats: DxfTransportStatsCallback
    enforce_job_total_qty_limit: EnforceJobTotalQtyLimitCallback
    ensure_request_dirs: EnsureRequestDirsCallback
    ensure_system_dirs: EnsureSystemDirsCallback
    estimate_payload_area_lower_bound: EstimatePayloadAreaLowerBoundCallback
    estimate_preflight_job_family_bytes: EstimatePreflightJobFamilyBytesCallback
    extract_request_summary: ExtractRequestSummaryCallback
    extract_strict_calculation_pricing_summary: ExtractStrictCalculationPricingSummaryCallback
    finalization_complete: FinalizationCompleteCallback
    find_or_generate_stickertool_file: FindOrGenerateStickertoolFileCallback
    finish_public_job_slot: FinishPublicJobSlotCallback
    generate_labels_json_strict: GenerateLabelsJsonStrictCallback
    generate_stickertool_json: GenerateStickertoolJsonCallback
    get_admin_credentials_file_path: GetAdminCredentialsFilePathCallback
    input_dxf_source_map: InputDxfSourceMapCallback
    is_externally_exposed_security_enabled: IsExternallyExposedSecurityEnabledCallback
    is_https_request: IsHttpsRequestCallback
    is_loopback_client: IsLoopbackClientCallback
    is_production_runtime: IsProductionRuntimeCallback
    is_secure_admin_transport: IsSecureAdminTransportCallback
    job_cancel_requested: JobCancelRequestedCallback
    get_job_lock: Callable[[], LockLike]
    job_material_context: JobMaterialContextCallback
    get_job_meta: Callable[[], dict[str, dict[str, Any]]]
    job_output_limit_message: JobOutputLimitMessageCallback
    link_or_copy_file: LinkOrCopyFileCallback
    linked_subjob_ids: LinkedSubjobIdsCallback
    load_job_runtime_state: LoadJobRuntimeStateCallback
    load_pricing_config: LoadPricingConfigCallback
    load_status: LoadStatusCallback
    master_job_id_for: MasterJobIdForCallback
    new_public_access_token: NewPublicAccessTokenCallback
    new_request_id: NewRequestIdCallback
    notify_submitted: NotifySubmittedCallback
    now_iso: NowIsoCallback
    observability_public_job_snapshot: ObservabilityPublicJobSnapshotCallback
    origin_allowed: OriginAllowedCallback
    parse_panels_csv: ParsePanelsCsvCallback
    public_job_family_complete: PublicJobFamilyCompleteCallback
    public_job_idempotency_key_exists: PublicJobIdempotencyKeyExistsCallback
    public_job_queue_limits: PublicJobQueueLimitsCallback
    rate_limit_allow: RateLimitAllowCallback
    rate_limit_clear: RateLimitClearCallback
    rate_limit_is_blocked: RateLimitIsBlockedCallback
    rate_limit_record: RateLimitRecordCallback
    read_json_body_limited: ReadJsonBodyLimitedCallback
    recover_public_job_idempotency: RecoverPublicJobIdempotencyCallback
    release_public_job_slot: ReleasePublicJobSlotCallback
    release_state_capacity_reservation: ReleaseStateCapacityReservationCallback
    reserve_state_capacity: ReserveStateCapacityCallback
    save_job_runtime_state: SaveJobRuntimeStateCallback
    save_status: SaveStatusCallback
    sealed_output_artifacts: SealedOutputArtifactsCallback
    terminate_optimizer_process: TerminateOptimizerProcessCallback
    transition_job_runtime_state: TransitionJobRuntimeStateCallback
    try_acquire_public_job_slot: TryAcquirePublicJobSlotCallback
    utc_now_iso: NowIsoCallback
    write_human_calculation_summary: WriteHumanCalculationSummaryCallback


@dataclass(frozen=True, slots=True, kw_only=True)
class RuntimeWorkerPorts:
    """Dependencies owned by runtime.worker."""

    get_jobs: Callable[[], Path]
    get_queue_done: Callable[[], Path]
    get_queue_failed: Callable[[], Path]
    get_queue_pending: Callable[[], Path]
    get_queue_processing: Callable[[], Path]
    get_worker_lock: Callable[[], Path]
    append_system_event: AppendSystemEventCallback
    ensure_request_dirs: EnsureRequestDirsCallback
    get_fcntl: Callable[[], ModuleType | None]
    finalization_complete: FinalizationCompleteCallback
    guess_customer_name: GuessCustomerNameCallback
    linked_subjob_ids: LinkedSubjobIdsCallback
    load_status: LoadStatusCallback
    move_queue_file_safe: MoveQueueFileSafeCallback
    save_status: SaveStatusCallback
    state_snapshot_is_active: StateSnapshotIsActiveCallback
    run_backup_maintenance: RunBackupMaintenanceCallback
    run_queue_maintenance: RunQueueMaintenanceCallback
    run_retention_maintenance: RunRetentionMaintenanceCallback


@dataclass(frozen=True, slots=True, kw_only=True)
class RuntimeStartupPorts:
    replay_customer_erasure: Callable[[], None]
    """Dependencies owned by runtime.startup."""
    get_host: Callable[[], str]
    Handler: type[WsgiHandler]
    get_jobs: Callable[[], Path]
    get_material_library_path: Callable[[], Path]
    get_port: Callable[[], int]
    get_pricing_active: Callable[[], Path]
    get_release_root: Callable[[], Path]
    get_root: Callable[[], Path]
    get_state_root: Callable[[], Path]
    get_system_dir: Callable[[], Path]
    admin_password_reset_activation_is_enabled: AdminPasswordResetActivationIsEnabledCallback
    ensure_archive_dirs: EnsureArchiveDirsCallback
    ensure_request_dirs: EnsureRequestDirsCallback
    ensure_system_dirs: EnsureSystemDirsCallback
    get_admin_credentials_file_path: GetAdminCredentialsFilePathCallback
    initialize_external_state: InitializeExternalStateCallback
    is_password_hash_value: IsPasswordHashValueCallback
    migrate_legacy_materials_to_direct_sell_prices: MigrateLegacyMaterialsToDirectSellPricesCallback
    normalized_admin_users: NormalizedAdminUsersCallback
    reconcile_archive_transactions: ReconcileArchiveTransactionsCallback
    reconcile_interrupted_jobs_on_startup: ReconcileInterruptedJobsOnStartupCallback
    reconcile_public_job_idempotency_on_startup: ReconcilePublicJobIdempotencyOnStartupCallback
    server_maintenance_loop: ServerMaintenanceLoopCallback
    migrate_embedded_dxfs_to_categories: MigrateEmbeddedDxfsToCategoriesCallback
    rebuild_embedded_dxfs_manifest: RebuildEmbeddedDxfsManifestCallback
    run_queue_maintenance: RunQueueMaintenanceCallback
    run_retention_maintenance: RunRetentionMaintenanceCallback
    worker_loop: WorkerLoopCallback


@dataclass(frozen=True, slots=True, kw_only=True)
class CatalogFilterGroupsPorts:
    """Dependencies owned by catalog.filter_groups."""

    get_system_dir: Callable[[], Path]


@dataclass(frozen=True, slots=True, kw_only=True)
class CatalogRuntimePorts:
    """Dependencies owned by catalog.runtime."""

    get_dxf_categories: Callable[[], list[str]]
    get_dxf_library_root: Callable[[], Path]
    get_dxf_manifest_path: Callable[[], Path]
    get_material_library_path: Callable[[], Path]
    get_material_library_lock: Callable[[], LockLike]
    get_public_materials_response_cache: Callable[[], dict[str, Any]]
    get_public_materials_response_cache_lock: Callable[[], LockLike]
    get_public_material_id_re: Callable[[], Pattern[str]]
    catalog: StorageCatalogPublicationPorts


@dataclass(frozen=True, slots=True, kw_only=True)
class NotificationsRuntimePorts:
    """Dependencies owned by notifications.runtime."""

    get_config_notify: Callable[[], Path]
    get_jobs: Callable[[], Path]
    get_ntfy_log: Callable[[], Path]
    calculation_summary_text_for_ntfy: CalculationSummaryTextForNtfyCallback
    extract_request_summary: ExtractRequestSummaryCallback
    get_notify_config_file_path: GetNotifyConfigFilePathCallback
    load_notify_config: LoadNotifyConfigCallback
    notify_privacy_options: NotifyPrivacyOptionsCallback
    now_iso: NowIsoCallback
    ntfy_log: NtfyLogCallback
    ntfy_public_safe_customer_lines: NtfyPublicSafeCustomerLinesCallback
    ntfy_send: NtfySendCallback
    validated_ntfy_target: ValidatedNtfyTargetCallback


@dataclass(frozen=True, slots=True, kw_only=True)
class JobsExecutionPorts:
    """Dependencies owned by jobs.execution."""

    get_jobs: Callable[[], Path]
    JobCancelledError: type[RuntimeError]
    get_optimizer_tool_b: Callable[[], str]
    get_pricing_seed_path: Callable[[], Path]
    get_root: Callable[[], Path]
    get_job_finalization_service: Callable[[], JobFinalizationService]
    get_optimizer_process_supervisor: Callable[[], OptimizerProcessSupervisor]
    atomic_write_json: AtomicWriteJsonCallback
    cached_sha256_file: CachedSha256FileCallback
    enforce_job_output_limit: EnforceJobOutputLimitCallback
    ensure_pricing_materials: EnsurePricingMaterialsCallback
    filter_panels_csv_by_material: FilterPanelsCsvByMaterialCallback
    finalize_subjob_outputs: FinalizeSubjobOutputsCallback
    get_python_base_cmd: GetPythonBaseCmdCallback
    job_cancel_requested: JobCancelRequestedCallback
    get_job_lock: Callable[[], LockLike]
    get_job_meta: Callable[[], dict[str, dict[str, Any]]]
    link_or_copy_file: LinkOrCopyFileCallback
    load_pricing_config: LoadPricingConfigCallback
    now_iso: NowIsoCallback
    parse_panels_csv: ParsePanelsCsvCallback
    register_job_process: RegisterJobProcessCallback
    terminate_optimizer_process: TerminateOptimizerProcessCallback
    unregister_job_process: RegisterJobProcessCallback
    utc_now_iso: NowIsoCallback
    validated_canonical_dxf_transport: ValidatedCanonicalDxfTransportCallback
    write_file: WriteFileCallback
    write_master_job_links: WriteMasterJobLinksCallback
    write_replaceable_json: WriteReplaceableJsonCallback
    write_replaceable_text: WriteReplaceableTextCallback


@dataclass(frozen=True, slots=True, kw_only=True)
class JobsOutputRuntimePorts:
    """Dependencies owned by jobs.output_runtime."""

    get_jobs: Callable[[], Path]
    get_material_library_path: Callable[[], Path]
    get_optimizer_tool_b: Callable[[], str]
    get_public_base_url: Callable[[], str]
    get_stickertool_v2_build: Callable[[], str]
    get_job_finalization_service: Callable[[], JobFinalizationService]
    best_material_name: BestMaterialNameCallback
    customer_display_name: CustomerDisplayNameCallback
    customer_name_from_job: CustomerNameFromJobCallback
    job_material_context: JobMaterialContextCallback
    material_name_and_thickness: MaterialNameAndThicknessCallback
    parse_panels_csv: ParsePanelsCsvCallback
    resolve_stickertool_material_display_name: ResolveStickertoolMaterialDisplayNameCallback
    sheet_sequence_from_filename: SheetSequenceFromFilenameCallback
    utc_now_iso: NowIsoCallback


@dataclass(frozen=True, slots=True, kw_only=True)
class JobsPayloadRuntimePorts:
    """Dependencies owned by jobs.payload_runtime."""

    get_job_output_max_bytes: Callable[[], int]
    get_state_root: Callable[[], Path]
    get_state_capacity_reservations: Callable[[], StateCapacityReservations]
    compact_dxf_transport: CompactDxfTransportCallback
    dir_size_bytes: DirSizeBytesCallback
    dxf_transport_stats: DxfTransportStatsCallback
    expand_dxf_payload: ExpandDxfPayloadCallback
    get_payload_total_qty: GetPayloadTotalQtyCallback
    job_family_size_bytes: JobFamilySizeBytesCallback
    job_output_limit_message: JobOutputLimitMessageCallback
    parse_panels_csv: ParsePanelsCsvCallback


@dataclass(frozen=True, slots=True, kw_only=True)
class JobsAdmissionRuntimePorts:
    """Dependencies owned by jobs.admission_runtime."""

    get_public_job_admission: Callable[[], PublicJobAdmission]
    get_public_job_scheduler: Callable[[], PublicJobScheduler]
    finish_public_job_slot: FinishPublicJobSlotCallback
    get_job_lock: Callable[[], LockLike]
    get_job_meta: Callable[[], dict[str, dict[str, Any]]]
    launch_public_job_item: LaunchPublicJobItemCallback
    now_iso: NowIsoCallback
    refresh_public_job_queue_meta_locked: RefreshPublicJobQueueMetaLockedCallback
    release_state_capacity_reservation: ReleaseStateCapacityReservationCallback
    save_job_runtime_state: SaveJobRuntimeStateCallback
    sync_public_job_admission_legacy_counters: SyncPublicJobAdmissionLegacyCountersCallback
    sync_public_job_scheduler_legacy_state: SyncPublicJobSchedulerLegacyStateCallback


@dataclass(frozen=True, slots=True, kw_only=True)
class JobsStateRuntimePorts:
    """Dependencies owned by jobs.state_runtime."""

    get_jobs: Callable[[], Path]
    get_job_restart_reconciler: Callable[[], JobRestartReconciler]
    get_optimizer_process_supervisor: Callable[[], OptimizerProcessSupervisor]
    find_existing_file: FindExistingFileCallback
    job_runtime_state_path: JobRuntimeStatePathCallback
    load_job_runtime_state: LoadJobRuntimeStateCallback
    transition_job_runtime_state: TransitionJobRuntimeStateCallback
    utc_now_iso: NowIsoCallback


@dataclass(frozen=True, slots=True, kw_only=True)
class RequestsRuntimePorts:
    """Dependencies owned by requests.runtime."""

    get_jobs: Callable[[], Path]
    get_requests: Callable[[], Path]
    get_job_finalization_service: Callable[[], JobFinalizationService]
    iter_request_statuses: IterRequestStatusesCallback


@dataclass(frozen=True, slots=True, kw_only=True)
class SecurityAccessRuntimePorts:
    """Dependencies owned by security.access_runtime."""

    get_jobs: Callable[[], Path]
    get_root: Callable[[], Path]
    get_admin_session_store: Callable[[], AdminSessionStore]
    get_rate_limits: Callable[[], dict[tuple[str, str], list[float]]]
    get_rate_limits_lock: Callable[[], LockLike]
    atomic_write_json: AtomicWriteJsonCallback
    client_ip: ClientIpCallback
    direct_peer_ip: DirectPeerIpCallback
    get_admin_password_reset_activation_file_path: GetAdminPasswordResetActivationFilePathCallback
    ip_matches: IpMatchesCallback
    is_externally_exposed_security_enabled: IsExternallyExposedSecurityEnabledCallback
    is_https_request: IsHttpsRequestCallback
    is_loopback_client: IsLoopbackClientCallback
    is_loopback_value: IsLoopbackValueCallback
    is_trusted_proxy_peer: IsTrustedProxyPeerCallback
    load_admin_password_reset_activation: LoadAdminPasswordResetActivationCallback
    utc_now_iso: NowIsoCallback


@dataclass(frozen=True, slots=True, kw_only=True)
class HttpPublicCatalogRuntimePorts:
    """Dependencies owned by http.public_catalog_runtime."""

    get_material_library_path: Callable[[], Path]
    get_public_material_catalog_cache_build: Callable[[], str]
    get_public_material_catalog_cache_meta_path: Callable[[], Path]
    get_public_material_catalog_cache_path: Callable[[], Path]
    get_public_material_catalog_cache_schema: Callable[[], int]
    get_public_materials_response_cache: Callable[[], dict[str, Any]]
    get_public_materials_response_cache_lock: Callable[[], LockLike]
    append_system_event: AppendSystemEventCallback
    atomic_write_json: AtomicWriteJsonCallback
    utc_now_iso: NowIsoCallback
    catalog: StorageCatalogPublicationPorts


@dataclass(frozen=True, slots=True, kw_only=True)
class HttpCatalogImportRuntimePorts:
    """Dependencies owned by http.catalog_import_runtime."""

    get_catalog_import_history: Callable[[], Path]
    get_catalog_import_root: Callable[[], Path]
    get_catalog_public_id_registry: Callable[[], Path]
    get_catalog_taxonomy_registry: Callable[[], Path]
    get_decor_media_root: Callable[[], Path]
    get_material_library_path: Callable[[], Path]
    get_pricing_active: Callable[[], Path]
    get_catalog_image_storage_bytes_per_worker: Callable[[], int]
    get_catalog_image_storage_inodes_per_worker: Callable[[], int]
    get_catalog_image_storage_reservation_id: Callable[[], str]
    get_catalog_image_sync_active: Callable[[], set[str]]
    get_catalog_image_sync_lock: Callable[[], LockLike]
    get_material_library_lock: Callable[[], LockLike]
    get_pricing_config_lock: Callable[[], LockLike]
    get_public_material_id_re: Callable[[], Pattern[str]]
    append_system_event: AppendSystemEventCallback
    atomic_write_json: AtomicWriteJsonCallback
    catalog_review_sha256: CatalogReviewSha256Callback
    enforce_state_capacity: EnforceStateCapacityCallback
    read_json_body_limited: ReadJsonBodyLimitedCallback
    release_state_capacity_reservation: ReleaseStateCapacityReservationCallback
    reserve_state_capacity: ReserveStateCapacityCallback
    utc_now_iso: NowIsoCallback
    catalog: StorageCatalogPublicationPorts


@dataclass(frozen=True, slots=True, kw_only=True)
class HttpTransportRuntimePorts:
    """Dependencies owned by http.transport_runtime."""

    get_admin_access: Callable[[], AdminAccessController]
    get_static_http: Callable[[], StaticHttpAdapterService]
    is_externally_exposed_security_enabled: IsExternallyExposedSecurityEnabledCallback
    is_loopback_client: IsLoopbackClientCallback
    is_loopback_value: IsLoopbackValueCallback
    origin_allowed: OriginAllowedCallback


@dataclass(frozen=True, slots=True, kw_only=True)
class HttpPublicApiRuntimePorts:
    get_privacy_service: Callable[[], CustomerPrivacyService]
    """Dependencies owned by http.public_api_runtime."""
    get_jobs: Callable[[], Path]
    get_root: Callable[[], Path]
    get_security_build: Callable[[], str]
    get_state_root: Callable[[], Path]
    get_job_lifecycle: Callable[[], JobLifecycleFacadeService]
    get_state_maintenance_barrier: Callable[[], StateMaintenanceBarrier]
    get_static_http: Callable[[], StaticHttpAdapterService]
    get_submission_service: Callable[[], SubmissionService]
    append_system_event: AppendSystemEventCallback
    client_ip: ClientIpCallback
    ensure_request_dirs: EnsureRequestDirsCallback
    extract_request_token: ExtractRequestTokenCallback
    finalization_complete: FinalizationCompleteCallback
    is_production_runtime: IsProductionRuntimeCallback
    job_cancel_requested: JobCancelRequestedCallback
    load_job_runtime_state: LoadJobRuntimeStateCallback
    load_pricing_config: LoadPricingConfigCallback
    lookup_public_job_idempotency: LookupPublicJobIdempotencyCallback
    mutate_status: MutateStatusCallback
    now_iso: NowIsoCallback
    prometheus_metrics: PrometheusMetricsCallback
    public_job_family_complete: PublicJobFamilyCompleteCallback
    rate_limit_allow: RateLimitAllowCallback
    read_job_access_token: ReadJobAccessTokenCallback
    read_json_body_limited: ReadJsonBodyLimitedCallback
    readiness_report: ReadinessReportCallback
    safe_json: SafeJsonCallback
    save_pricing_config: SavePricingConfigCallback
    utc_now_iso: NowIsoCallback
    api_admin_control_center: ApiAdminControlCenterCallback
    api_admin_jobs: ApiAdminJobsCallback
    api_admin_request_download_zip: ApiAdminRequestDownloadZipCallback
    api_admin_request_file: ApiAdminRequestFileCallback
    api_admin_request_files: ApiAdminRequestFilesCallback
    api_admin_requests: ApiAdminRequestsCallback
    api_admin_requests_update: ApiAdminRequestsUpdateCallback
    api_download: ApiDownloadCallback
    api_draft_load: ApiDraftLoadCallback
    api_draft_save: ApiDraftSaveCallback
    api_dxf_manifest_meta: ApiDxfManifestMetaCallback
    api_job_file: ApiJobFileCallback
    api_subjob_file: ApiSubjobFileCallback


@dataclass(frozen=True, slots=True, kw_only=True)
class HttpAdminOperationsRuntimePorts:
    """Dependencies owned by http.admin_operations_runtime."""

    get_backups_dir: Callable[[], Path]
    append_system_event: AppendSystemEventCallback
    create_system_backup: CreateSystemBackupCallback
    list_backups: ListBackupsCallback
    read_json_body_limited: ReadJsonBodyLimitedCallback
    read_system_events: ReadSystemEventsCallback
    get_embedded_dxfs_version: GetEmbeddedDxfsVersionCallback
    rebuild_embedded_dxfs_manifest: RebuildEmbeddedDxfsManifestCallback


@dataclass(frozen=True, slots=True, kw_only=True)
class HttpFilterGroupsRuntimePorts:
    """Dependencies owned by http.filter_groups_runtime."""

    append_system_event: AppendSystemEventCallback
    invalidate_public_materials_response_cache: InvalidatePublicMaterialsResponseCacheCallback
    read_json_body_limited: ReadJsonBodyLimitedCallback
    catalog: StorageCatalogPublicationPorts


@dataclass(frozen=True, slots=True, kw_only=True)
class HttpMaterialDxfRuntimePorts:
    """Dependencies owned by http.material_dxf_runtime."""

    get_dxf_library_root: Callable[[], Path]


@dataclass(frozen=True, slots=True, kw_only=True)
class HttpMaterialCatalogRuntimePorts:
    """Dependencies owned by http.material_catalog_runtime."""

    get_decor_media_root: Callable[[], Path]
    get_dxf_library_root: Callable[[], Path]
    get_material_library_path: Callable[[], Path]
    get_material_library_lock: Callable[[], LockLike]
    get_pricing_config_lock: Callable[[], LockLike]
    get_public_material_id_re: Callable[[], Pattern[str]]
    append_system_event: AppendSystemEventCallback
    expand_dxf_payload: ExpandDxfPayloadCallback
    invalidate_material_lookup_cache: InvalidateMaterialLookupCacheCallback
    invalidate_material_name_cache: InvalidateMaterialNameCacheCallback
    invalidate_public_materials_response_cache: InvalidatePublicMaterialsResponseCacheCallback
    material_lookup_snapshot: MaterialLookupSnapshotCallback
    utc_now_iso: NowIsoCallback
    catalog: StorageCatalogPublicationPorts


@dataclass(frozen=True, slots=True, kw_only=True)
class ObservabilityRuntimePorts:
    """Dependencies owned by observability.runtime."""

    get_requests: Callable[[], Path]
    get_observability: Callable[[], ObservabilityService]
    get_public_job_active_total: Callable[[], int]
    get_public_job_create_lock: Callable[[], LockLike]
    get_public_job_create_total: Callable[[], int]
    get_public_job_queue: Callable[[], deque[dict[str, Any]]]
    get_public_job_reserved_total: Callable[[], int]
    guess_customer_name_from_payload: GuessCustomerNameFromPayloadCallback
    get_embedded_dxfs_version: GetEmbeddedDxfsVersionCallback


@dataclass(frozen=True, slots=True, kw_only=True)
class HttpEndpointsAdminJobsPorts:
    """Dependencies owned by http.endpoints.admin_jobs."""

    get_jobs: Callable[[], Path]
    get_request_download_projections: Callable[[], RequestDownloadProjectionService]
    admin_sheet_download_name: AdminSheetDownloadNameCallback
    best_material_name: BestMaterialNameCallback
    classify_output_kind: ClassifyOutputKindCallback
    customer_name_from_job: CustomerNameFromJobCallback
    edge_meters_by_decor: EdgeMetersByDecorCallback
    get_job_lock: Callable[[], LockLike]
    job_material_context: JobMaterialContextCallback
    get_job_meta: Callable[[], dict[str, dict[str, Any]]]
    job_runtime_state_path: JobRuntimeStatePathCallback
    load_job_runtime_state: LoadJobRuntimeStateCallback
    parse_calculation_summary_totals: ParseCalculationSummaryTotalsCallback
    parse_panels_csv: ParsePanelsCsvCallback
    sealed_output_artifacts: SealedOutputArtifactsCallback


@dataclass(frozen=True, slots=True, kw_only=True)
class HttpEndpointsAdminRequestsPorts:
    """Dependencies owned by http.endpoints.admin_requests."""

    get_system_dir: Callable[[], Path]
    get_request_download_projections: Callable[[], RequestDownloadProjectionService]
    append_system_event: AppendSystemEventCallback
    build_request_file_manifest: BuildRequestFileManifestCallback
    ensure_request_dirs: EnsureRequestDirsCallback
    load_status: LoadStatusCallback
    mutate_status: MutateStatusCallback
    read_json_body_limited: ReadJsonBodyLimitedCallback
    api_job_file: ApiJobFileCallback


@dataclass(frozen=True, slots=True, kw_only=True)
class HttpEndpointsDownloadsPorts:
    """Dependencies owned by http.endpoints.downloads."""

    get_jobs: Callable[[], Path]
    admin_sheet_download_name: AdminSheetDownloadNameCallback
    apply_sell_pricing_to_quote: ApplySellPricingToQuoteCallback
    customer_name_from_job: CustomerNameFromJobCallback
    extract_request_token: ExtractRequestTokenCallback
    finalization_complete: FinalizationCompleteCallback
    linked_subjob_ids: LinkedSubjobIdsCallback
    public_job_family_complete: PublicJobFamilyCompleteCallback
    read_job_access_token: ReadJobAccessTokenCallback
    sealed_output_artifacts: SealedOutputArtifactsCallback


@dataclass(frozen=True, slots=True, kw_only=True)
class HttpEndpointsDraftsPorts:
    """Dependencies owned by http.endpoints.drafts."""

    read_json_body_limited: ReadJsonBodyLimitedCallback
    get_embedded_dxfs_version: GetEmbeddedDxfsVersionCallback


@dataclass(frozen=True, slots=True, kw_only=True)
class HttpEndpointsControlCenterPorts:
    """Dependencies owned by http.endpoints.control_center."""

    get_dxf_manifest_path: Callable[[], Path]
    get_jobs: Callable[[], Path]
    get_material_library_path: Callable[[], Path]
    get_optimizer_tool_b: Callable[[], str]
    get_pricing_active: Callable[[], Path]
    dir_size_bytes: DirSizeBytesCallback
    safe_json: SafeJsonCallback
