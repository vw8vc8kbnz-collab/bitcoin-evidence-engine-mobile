"""Construct long-lived application services without owning mutable ports state."""

from __future__ import annotations

from catalog_importer import VAT_RATE as CATALOG_VAT_RATE
from safety_contracts import ContractError as SafetyContractError
from metod_app.contracts.submission import EMAIL_RE as _EMAIL_RE
from metod_app.config import env_int as _env_int
from metod_app.security.headers import extract_admin_session_cookie as _extract_admin_session_cookie
from metod_app.security.headers import extract_bearer_token as _extract_bearer_token
from metod_app.config import production_hardening_enabled as _is_production_hardening_enabled
from metod_app.errors import public_error_message as _public_error_message
from metod_app.security.redaction import redact_sensitive_text as _redact_sensitive_text
from metod_app.identifiers import safe_identifier as _safe_id
from metod_app.security.redaction import safe_text as _safe_text
from metod_app.identifiers import sanitize_filename as _sanitize_filename
from metod_app.security.redaction import sanitize_log_value as _sanitize_log_value
from metod_app.security.credentials import verify_password_against_stored as _verify_password_against_stored
from safety_contracts import append_jsonl_rotating
from safety_contracts import durable_write_json
from safety_contracts import durable_write_text
from safety_contracts import ensure_finite_json
from safety_contracts import fsync_directory
import os
from safety_contracts import resolve_identifier_child
from safety_contracts import resolve_relative_file
import secrets
from safety_contracts import sha256_file
import shutil
from safety_contracts import strict_json_dumps
from safety_contracts import strict_json_load
from safety_contracts import strict_json_loads
from safety_contracts import tail_text_lines
from safety_contracts import validate_job_id
from safety_contracts import validate_request_id
from metod_app.runtime.ports import RuntimeCompositionPorts


from dataclasses import dataclass
from pathlib import Path

from metod_app.admin.access import AdminAccessController, AdminAccessDependencies
from metod_app.security.credentials import match_totp_counter
from metod_app.http.static import StaticHttpAdapterService, StaticHttpDependencies
from metod_app.jobs.finalization import JobFinalizationService
from metod_app.jobs.lifecycle import JobLifecycleDependencies, JobLifecycleFacadeService
from metod_app.observability import (
    ObservabilityDependencies,
    ObservabilityPaths,
    ObservabilityService,
)
from metod_app.requests.downloads import (
    RequestDownloadDependencies,
    RequestDownloadProjectionService,
)
from metod_app.requests.submission import SubmissionClaimRepository, SubmissionService


@dataclass(frozen=True, slots=True)
class RuntimeServices:
    submission_claims: SubmissionClaimRepository
    submission_service: SubmissionService
    request_downloads: RequestDownloadProjectionService


@dataclass(frozen=True, slots=True)
class CoreRuntimeServices:
    """Long-lived HTTP/job services composed against the live ports module."""

    job_finalization: JobFinalizationService
    observability: ObservabilityService
    admin_access: AdminAccessController
    static_http: StaticHttpAdapterService
    job_lifecycle: JobLifecycleFacadeService


def build_core_runtime_services(ports: RuntimeCompositionPorts) -> CoreRuntimeServices:
    """Build the main service graph without copying ports state or behavior."""

    finalization = JobFinalizationService(
        jobs_root=ports.get_jobs(),
        safety_error=SafetyContractError,
        validate_job_id=validate_job_id,
        resolve_identifier_child=resolve_identifier_child,
        resolve_relative_file=resolve_relative_file,
        read_json=lambda path: strict_json_load(path),
        cached_sha256_file=lambda path: ports.cached_sha256_file(path),
        parse_panels_csv=lambda text: ports.parse_panels_csv(text),
        input_dxf_source_map=lambda input_dir, part_ids: ports.input_dxf_source_map(input_dir, part_ids),
        link_or_copy_file=lambda source, destination: ports.link_or_copy_file(source, destination),
        fsync_directory=lambda path: fsync_directory(path),
        generate_labels=lambda root: ports.generate_labels_json_strict(root),
        generate_stickertool=lambda root: ports.generate_stickertool_json(root),
        write_calculation_summary=lambda root, **kwargs: ports.write_human_calculation_summary(
            root, **kwargs
        ),
        durable_write_json=lambda path, value: durable_write_json(path, value),
        atomic_write_json=lambda path, value: ports.atomic_write_json(path, value),
        load_runtime_state=lambda job_id: ports.load_job_runtime_state(job_id),
        utc_now_iso=lambda: ports.utc_now_iso(),
    )
    observability = ObservabilityService(
        ObservabilityDependencies(
            paths=ObservabilityPaths(
                system_log_file=lambda: ports.get_system_log_file(),
                system_dir=lambda: ports.get_system_dir(),
                state_root=lambda: ports.get_state_root(),
                material_library_path=lambda: ports.get_material_library_path(),
                pricing_active_path=lambda: ports.get_pricing_active(),
                dxf_library_root=lambda: ports.get_dxf_library_root(),
                jobs_root=lambda: ports.get_jobs(),
                requests_root=lambda: ports.get_requests(),
                queue_pending_root=lambda: ports.get_queue_pending(),
                queue_processing_root=lambda: ports.get_queue_processing(),
            ),
            build=ports.get_security_build(),
            environment=os.environ,
            path_factory=lambda value: Path(value),
            env_int=lambda name, default: _env_int(name, default),
            production_hardening_enabled=lambda: _is_production_hardening_enabled(),
            business_authority_lock=lambda: ports.get_pricing_config_lock(),
            ensure_system_dirs=lambda: ports.ensure_system_dirs(),
            now_iso=lambda: ports.now_iso(),
            safe_text=lambda value, limit: _safe_text(value, limit),
            redact_sensitive_text=lambda value, limit: _redact_sensitive_text(value, limit),
            sanitize_log_value=lambda value, **kwargs: _sanitize_log_value(value, **kwargs),
            append_jsonl_rotating=lambda path, value, **kwargs: append_jsonl_rotating(path, value, **kwargs),
            tail_text_lines=lambda path, count, **kwargs: tail_text_lines(path, count, **kwargs),
            strict_json_load=lambda path: strict_json_load(path),
            strict_json_loads=lambda value: strict_json_loads(value),
            sha256_file=lambda path: sha256_file(path),
            load_pricing_config=lambda: ports.load_pricing_config(),
            ensure_finite_json=lambda value: ensure_finite_json(value),
            durable_write_text=lambda path, value, **kwargs: durable_write_text(path, value, **kwargs),
            disk_usage=lambda path: shutil.disk_usage(path),
            statvfs=(lambda path: os.statvfs(path)) if hasattr(os, "statvfs") else None,
            process_id=lambda: os.getpid(),
            token_hex=lambda size: secrets.token_hex(size),
            public_job_snapshot=ports.observability_public_job_snapshot,
        )
    )
    admin_access = AdminAccessController(
        AdminAccessDependencies(
            root=ports.get_root(),
            state_root=lambda: ports.get_state_root(),
            environment=os.environ,
            credentials_file_path=ports.get_admin_credentials_file_path,
            strict_json_load=strict_json_load,
            strict_json_dumps=strict_json_dumps,
            read_json_body_limited=ports.read_json_body_limited,
            production_runtime=ports.is_production_runtime,
            production_hardening_enabled=_is_production_hardening_enabled,
            externally_exposed_security_enabled=ports.is_externally_exposed_security_enabled,
            secure_admin_transport=ports.is_secure_admin_transport,
            https_request=ports.is_https_request,
            client_ip=ports.client_ip,
            loopback_client=ports.is_loopback_client,
            rate_limit_is_blocked=ports.rate_limit_is_blocked,
            rate_limit_record=ports.rate_limit_record,
            rate_limit_clear=ports.rate_limit_clear,
            verify_password=_verify_password_against_stored,
            match_totp_counter=match_totp_counter,
            append_system_event=ports.append_system_event,
            extract_bearer_token=_extract_bearer_token,
            extract_session_cookie=_extract_admin_session_cookie,
            dummy_password_hash=ports.get_dummy_admin_password_hash(),
            dummy_totp_secret=ports.get_dummy_admin_totp_secret(),
        ),
        ports.get_admin_session_store(),
    )
    static_http = StaticHttpAdapterService(
        StaticHttpDependencies(
            root=lambda: ports.get_root(),
            state_root=lambda: ports.get_state_root(),
            dxf_manifest_path=lambda: ports.get_dxf_manifest_path(),
            dxf_library_root=lambda: ports.get_dxf_library_root(),
            resolve_relative_file=resolve_relative_file,
            sanitize_filename=_sanitize_filename,
            strict_json_dumps=strict_json_dumps,
            origin_allowed=ports.origin_allowed,
            production_hardening_enabled=_is_production_hardening_enabled,
            externally_exposed_security_enabled=ports.is_externally_exposed_security_enabled,
            https_request=ports.is_https_request,
        )
    )
    lifecycle = JobLifecycleFacadeService(
        JobLifecycleDependencies(
            JOBS=lambda: ports.get_jobs(),
            CATALOG_VAT_RATE=lambda: CATALOG_VAT_RATE,
            _OPTIMIZER_PROCESS_SUPERVISOR=lambda: ports.get_optimizer_process_supervisor(),
            _cancel_queued_public_job=lambda *args, **kwargs: ports.cancel_queued_public_job(*args, **kwargs),
            _client_ip=lambda *args, **kwargs: ports.client_ip(*args, **kwargs),
            _finish_public_job_slot=lambda *args, **kwargs: ports.finish_public_job_slot(*args, **kwargs),
            _job_lock=lambda: ports.get_job_lock(),
            _job_meta=lambda: ports.get_job_meta(),
            _now_iso=lambda *args, **kwargs: ports.now_iso(*args, **kwargs),
            _rate_limit_allow=lambda *args, **kwargs: ports.rate_limit_allow(*args, **kwargs),
            _read_json_body_limited=lambda *args, **kwargs: ports.read_json_body_limited(*args, **kwargs),
            _save_job_runtime_state=lambda *args, **kwargs: ports.save_job_runtime_state(*args, **kwargs),
            _transition_job_runtime_state=lambda *args, **kwargs: ports.transition_job_runtime_state(
                *args, **kwargs
            ),
            _terminate_optimizer_process=lambda *args, **kwargs: ports.terminate_optimizer_process(
                *args, **kwargs
            ),
            resolve_identifier_child=lambda *args, **kwargs: resolve_identifier_child(*args, **kwargs),
            validate_job_id=lambda *args, **kwargs: validate_job_id(*args, **kwargs),
            _dxf_transport_stats=lambda *args, **kwargs: ports.dxf_transport_stats(*args, **kwargs),
            _estimate_payload_area_lower_bound=lambda *args,
            **kwargs: ports.estimate_payload_area_lower_bound(*args, **kwargs),
            JobCancelledError=ports.JobCancelledError,
            SafetyContractError=SafetyContractError,
            _commit_public_job_slot=lambda *args, **kwargs: ports.commit_public_job_slot(*args, **kwargs),
            _create_job_from_payload=lambda *args, **kwargs: ports.create_job_from_payload(*args, **kwargs),
            _finalization_complete=lambda *args, **kwargs: ports.finalization_complete(*args, **kwargs),
            _job_cancel_requested=lambda *args, **kwargs: ports.job_cancel_requested(*args, **kwargs),
            durable_write_text=lambda *args, **kwargs: durable_write_text(*args, **kwargs),
            _atomic_write_json=lambda *args, **kwargs: ports.atomic_write_json(*args, **kwargs),
            _redact_sensitive_text=lambda *args, **kwargs: _redact_sensitive_text(*args, **kwargs),
            JOB_OUTPUT_MAX_BYTES=lambda: ports.get_job_output_max_bytes(),
            _append_client_log=lambda *args, **kwargs: ports.append_client_log(*args, **kwargs),
            _append_system_event=lambda *args, **kwargs: ports.append_system_event(*args, **kwargs),
            _capture_public_job_pricing_authority=lambda *args,
            **kwargs: ports.capture_public_job_pricing_authority(*args, **kwargs),
            _enforce_job_total_qty_limit=lambda *args, **kwargs: ports.enforce_job_total_qty_limit(
                *args, **kwargs
            ),
            _env_int=lambda *args, **kwargs: _env_int(*args, **kwargs),
            _estimate_preflight_job_family_bytes=lambda *args,
            **kwargs: ports.estimate_preflight_job_family_bytes(*args, **kwargs),
            _is_production_runtime=lambda *args, **kwargs: ports.is_production_runtime(*args, **kwargs),
            _job_output_limit_message=lambda *args, **kwargs: ports.job_output_limit_message(*args, **kwargs),
            _claim_public_job_idempotency=lambda *args, **kwargs: ports.claim_public_job_idempotency(
                *args, **kwargs
            ),
            _public_job_idempotency_key_exists=lambda *args,
            **kwargs: ports.public_job_idempotency_key_exists(*args, **kwargs),
            _complete_public_job_idempotency=lambda *args, **kwargs: ports.complete_public_job_idempotency(
                *args, **kwargs
            ),
            _recover_public_job_idempotency=lambda *args, **kwargs: ports.recover_public_job_idempotency(
                *args, **kwargs
            ),
            _abandon_public_job_idempotency=lambda *args, **kwargs: ports.abandon_public_job_idempotency(
                *args, **kwargs
            ),
            _new_public_access_token=lambda *args, **kwargs: ports.new_public_access_token(*args, **kwargs),
            _public_error_message=lambda *args, **kwargs: _public_error_message(*args, **kwargs),
            _public_job_queue_limits=lambda *args, **kwargs: ports.public_job_queue_limits(*args, **kwargs),
            _release_public_job_slot=lambda *args, **kwargs: ports.release_public_job_slot(*args, **kwargs),
            _release_state_capacity_reservation=lambda *args,
            **kwargs: ports.release_state_capacity_reservation(*args, **kwargs),
            _reserve_state_capacity=lambda *args, **kwargs: ports.reserve_state_capacity(*args, **kwargs),
            _try_acquire_public_job_slot=lambda *args, **kwargs: ports.try_acquire_public_job_slot(
                *args, **kwargs
            ),
            _utc_now_iso=lambda *args, **kwargs: ports.utc_now_iso(*args, **kwargs),
            fsync_directory=lambda *args, **kwargs: fsync_directory(*args, **kwargs),
            strict_json_load=lambda *args, **kwargs: strict_json_load(*args, **kwargs),
            _apply_sell_pricing_to_quote=lambda *args, **kwargs: ports.apply_sell_pricing_to_quote(
                *args, **kwargs
            ),
            _extract_strict_calculation_pricing_summary=lambda *args,
            **kwargs: ports.extract_strict_calculation_pricing_summary(*args, **kwargs),
            _linked_subjob_ids=lambda *args, **kwargs: ports.linked_subjob_ids(*args, **kwargs),
            _load_job_runtime_state=lambda *args, **kwargs: ports.load_job_runtime_state(*args, **kwargs),
            _master_job_id_for=lambda *args, **kwargs: ports.master_job_id_for(*args, **kwargs),
            _public_job_family_complete=lambda *args, **kwargs: ports.public_job_family_complete(
                *args, **kwargs
            ),
        )
    )
    return CoreRuntimeServices(
        finalization,
        observability,
        admin_access,
        static_http,
        lifecycle,
    )


def build_runtime_services(ports: RuntimeCompositionPorts) -> RuntimeServices:
    """Wire services to the live composition module through narrow callbacks."""

    claims = SubmissionClaimRepository(
        marker_root=lambda: ports.get_submission_idempotency_dir(),
        requests_root=lambda: ports.get_requests(),
        utc_now_iso=lambda: ports.utc_now_iso(),
    )
    submission = SubmissionService(
        claims=claims,
        claim_lock=lambda: ports.get_submission_idempotency_lock(),
        read_json=lambda path: strict_json_load(path),
        email_is_valid=lambda email: bool(_EMAIL_RE.fullmatch(email)),
        linked_subjob_ids=lambda parent_job_id: ports.linked_subjob_ids(parent_job_id),
        resolve_job_root=lambda job_id: resolve_identifier_child(ports.get_jobs(), job_id),
        finalization_complete=lambda job_root: (
            str(
                (ports.load_job_runtime_state(str(job_root.name).split("__mat_", 1)[0]) or {}).get("state")
                or ""
            ).upper()
            == "DONE"
            and ports.finalization_complete(job_root)
        ),
        pricing_summary=lambda job_ids: ports.extract_strict_calculation_pricing_summary(job_ids),
        new_request_id=lambda: ports.new_request_id(),
        new_cancel_token=lambda: secrets.token_urlsafe(32),
        resolve_request_root=lambda request_id: resolve_identifier_child(
            ports.get_requests(),
            validate_request_id(request_id),
            kind="request",
        ),
        atomic_write_json=lambda path, value: ports.atomic_write_json(path, value, mode=0o600),
        utc_now_iso=lambda: ports.utc_now_iso(),
        extract_summary=lambda payload: ports.extract_request_summary(payload),
        save_status=lambda request_id, status: ports.save_status(request_id, status),
        load_status=lambda request_id: ports.load_status(request_id),
        request_status_exists=lambda request_id: (ports.get_requests() / request_id / "status.json").exists(),
        safe_identifier=lambda value, max_len: _safe_id(value, max_len),
        notify_submitted=lambda *args, **kwargs: ports.notify_submitted(*args, **kwargs),
    )
    downloads = RequestDownloadProjectionService(
        RequestDownloadDependencies(
            requests_root=lambda: ports.get_requests(),
            jobs_root=lambda: ports.get_jobs(),
            ensure_request_directories=lambda: ports.ensure_request_dirs(),
            load_status=lambda request_id: ports.load_status(request_id),
            strict_json_load=lambda path: strict_json_load(path),
            safe_identifier=lambda value, max_len: _safe_id(value, max_len),
            validate_job_id=lambda job_id: validate_job_id(job_id),
            resolve_job_root=lambda job_id: resolve_identifier_child(ports.get_jobs(), job_id),
            collect_job_output_files=lambda job_id: ports.collect_job_output_files(job_id),
            find_stickertool_file=lambda job_id: ports.find_or_generate_stickertool_file(job_id),
            sealed_output_artifacts=lambda job_root: ports.sealed_output_artifacts(job_root),
            job_material_context=lambda job_root: ports.job_material_context(job_root),
            best_material_name=lambda *args: ports.best_material_name(*args),
            classify_output_kind=lambda name: ports.classify_output_kind(name),
            dedupe_admin_dxf_files=lambda files: ports.dedupe_admin_dxf_files(files),
            admin_sheet_download_name=lambda *args, **kwargs: ports.admin_sheet_download_name(
                *args, **kwargs
            ),
            strict_pricing_summary=lambda job_ids: ports.extract_strict_calculation_pricing_summary(job_ids),
            finalization_complete=lambda job_root: ports.finalization_complete(job_root),
            directory_size_bytes=lambda path: ports.dir_size_bytes(path),
            sanitize_filename=lambda value, max_len: _sanitize_filename(value, max_len),
            relative_parts=lambda relative: tuple(Path(relative).parts),
            relative_basename=lambda relative: Path(relative).name,
            build_manifest=lambda request_id: ports.build_request_file_manifest(request_id),
        )
    )
    return RuntimeServices(claims, submission, downloads)


__all__ = (
    "CoreRuntimeServices",
    "RuntimeServices",
    "build_core_runtime_services",
    "build_runtime_services",
)
