#!/usr/bin/env python3
# METOD Tool A + Tool B local server (py-only)
# Serves Tool A UI, Admin UI, and runs Tool B optimizer jobs.

from __future__ import annotations

from metod_app.version import REVISION
from metod_app.runtime import ports as contracts
from types import ModuleType

from metod_app.runtime.ports import (
    CatalogRuntimePorts,
    HttpAdminOperationsRuntimePorts,
    HttpCatalogImportRuntimePorts,
    HttpEndpointsAdminJobsPorts,
    HttpEndpointsAdminRequestsPorts,
    HttpEndpointsControlCenterPorts,
    HttpEndpointsDownloadsPorts,
    HttpEndpointsDraftsPorts,
    HttpFilterGroupsRuntimePorts,
    HttpMaterialCatalogRuntimePorts,
    HttpMaterialDxfRuntimePorts,
    HttpPublicApiRuntimePorts,
    HttpPublicCatalogRuntimePorts,
    HttpTransportRuntimePorts,
    JobsAdmissionRuntimePorts,
    JobsExecutionPorts,
    JobsOutputRuntimePorts,
    JobsPayloadRuntimePorts,
    JobsStateRuntimePorts,
    NotificationsRuntimePorts,
    ObservabilityRuntimePorts,
    PricingReportRuntimePorts,
    PricingRuntimePorts,
    RequestsRuntimePorts,
    RuntimeCompositionPorts,
    RuntimeStartupPorts,
    RuntimeWorkerPorts,
    SecurityAccessRuntimePorts,
    StorageArchiveRuntimePorts,
    StorageBackupRuntimePorts,
    StorageCatalogPublicationPorts,
    StorageIoRuntimePorts,
    StorageRetentionRuntimePorts,
)


from metod_app.observability.failures import report_recovery

# Build stamps are deliberately public module constants.  A leading double
# underscore is name-mangled when it is referenced from a class method (for
# example Handler.do_GET), which used to crash /health/live after the socket
# had already opened.
STICKERTOOL_V2_BUILD: str = REVISION
OUTPUT_PIPELINE_BUILD = REVISION
PERFORMANCE_BUILD = REVISION
SECURITY_BUILD: str = REVISION

import os
import re
import threading
import time
import secrets
import signal

try:
    import fcntl as _posix_fcntl

    _fcntl: ModuleType | None = _posix_fcntl
except ImportError:  # pragma: no cover - non-POSIX development fallback
    _fcntl = None
from datetime import datetime, timedelta, timezone
from metod_app.admin.privacy import CustomerPrivacyService
from pathlib import Path
from typing import Any

from metod_app.admin.access import (
    AdminSessionStore,
)

from metod_app.application import build_app_context
from metod_app.config import (
    env_int as _env_int,
)
from metod_app.identifiers import (
    safe_identifier as _safe_id,
)
from metod_app.jobs.idempotency import JobCreateIdempotencyRepository

from metod_app.requests.repository import (
    RequestRepository,
)
from metod_app.requests.projections import (
    RequestProjection,
)
from metod_app.storage.maintenance import StateMaintenanceBarrier
from metod_app.jobs.admission import (
    PublicJobAdmission,
    StateCapacityReservations,
)
from metod_app.jobs.scheduler import PublicJobScheduler
from metod_app.jobs.process_supervisor import OptimizerProcessSupervisor
from metod_app.jobs.reconciliation import JobRestartReconciler
from safety_contracts import (
    strict_json_load,
    validate_job_id,
)

_APP_CONTEXT = build_app_context(app_root=Path(__file__).resolve().parents[2])
_APP_PATHS = _APP_CONTEXT.paths
_RUNTIME_CONFIG = _APP_CONTEXT.config

ROOT: Path = _APP_PATHS.app_root
RELEASE_ROOT: Path = _APP_PATHS.release_root
STATE_ROOT: Path = _APP_PATHS.state_root
DXF_LIBRARY_ROOT: Path = _APP_PATHS.dxf_library_root
DXF_MANIFEST_PATH: Path = _APP_PATHS.dxf_manifest_path
PRICING_SEED_PATH: Path = _APP_PATHS.pricing_seed_path
MATERIAL_LIBRARY_SEED_PATH: Path = _APP_PATHS.material_library_seed_path
CATALOG_PRICING_BUILD = REVISION
CATALOG_PUBLICATION_BUILD = REVISION
CATALOG_CLASSIFICATION_BUILD = REVISION
BASE_DIR = str(ROOT)
MATERIAL_LIBRARY_PATH: Path = _APP_PATHS.material_library_path
CATALOG_PUBLIC_ID_REGISTRY: Path = _APP_PATHS.catalog_public_id_registry
CATALOG_TAXONOMY_REGISTRY: Path = _APP_PATHS.catalog_taxonomy_registry
DECOR_MEDIA_ROOT: Path = _APP_PATHS.decor_media_root
_MATERIAL_LIBRARY_LOCK: contracts.LockLike = threading.RLock()
_PRICING_CONFIG_LOCK: contracts.LockLike = threading.RLock()
_CATALOG_IMAGE_SYNC_LOCK: contracts.LockLike = threading.Lock()
_CATALOG_IMAGE_SYNC_ACTIVE: set[str] = set()
_CATALOG_IMAGE_STORAGE_RESERVATION_ID: str = "state_catalog_image_sync"
# One worker can hold a 12 MiB source plus durable temp/final files and the two
# bounded WebP variants. 32 MiB is a conservative fixed on-disk in-flight bound.
_CATALOG_IMAGE_STORAGE_BYTES_PER_WORKER: int = 32 * 1024 * 1024
_CATALOG_IMAGE_STORAGE_INODES_PER_WORKER: int = 16
_PUBLIC_MATERIAL_ID_RE: contracts.Pattern[str] = re.compile(r"^decor_[a-f0-9]{20,40}$")
PUBLIC_MATERIAL_CATALOG_CACHE_PATH: Path = _APP_PATHS.public_material_catalog_cache_path
PUBLIC_MATERIAL_CATALOG_CACHE_META_PATH: Path = _APP_PATHS.public_material_catalog_cache_meta_path
PUBLIC_MATERIAL_CATALOG_CACHE_SCHEMA: int = 2
PUBLIC_MATERIAL_CATALOG_CACHE_BUILD: str = REVISION
_PUBLIC_MATERIALS_RESPONSE_CACHE_LOCK: contracts.LockLike = threading.RLock()
_PUBLIC_MATERIALS_RESPONSE_CACHE: dict[str, Any] = {"mtimeNs": None, "body": None, "etag": None}


_CATALOG_PUBLICATION_PORTS: contracts.StorageCatalogPublicationPorts = StorageCatalogPublicationPorts(
    get_catalog_import_root=lambda: CATALOG_IMPORT_ROOT,
    get_catalog_public_id_registry=lambda: CATALOG_PUBLIC_ID_REGISTRY,
    get_catalog_taxonomy_registry=lambda: CATALOG_TAXONOMY_REGISTRY,
    get_decor_media_root=lambda: DECOR_MEDIA_ROOT,
    get_material_library_path=lambda: MATERIAL_LIBRARY_PATH,
    get_system_dir=lambda: SYSTEM_DIR,
    get_pricing_config_lock=lambda: _PRICING_CONFIG_LOCK,
    invalidate_material_lookup_cache=lambda *args, **kwargs: _invalidate_material_lookup_cache(
        *args, **kwargs
    ),
    invalidate_material_name_cache=lambda *args, **kwargs: _invalidate_material_name_cache(*args, **kwargs),
    invalidate_public_materials_response_cache=lambda *args,
    **kwargs: _invalidate_public_materials_response_cache(*args, **kwargs),
)

# Bounded domain owners. Each owner resolves mutable dependencies from this live
# composition module at call time, preserving operational/test overrides.
from metod_app.catalog.runtime import CatalogRuntime

_CATALOG_RUNTIME = CatalogRuntime(
    CatalogRuntimePorts(
        get_dxf_categories=lambda: DXF_CATEGORIES,
        get_dxf_library_root=lambda: DXF_LIBRARY_ROOT,
        get_dxf_manifest_path=lambda: DXF_MANIFEST_PATH,
        get_material_library_path=lambda: MATERIAL_LIBRARY_PATH,
        get_material_library_lock=lambda: _MATERIAL_LIBRARY_LOCK,
        get_public_materials_response_cache=lambda: _PUBLIC_MATERIALS_RESPONSE_CACHE,
        get_public_materials_response_cache_lock=lambda: _PUBLIC_MATERIALS_RESPONSE_CACHE_LOCK,
        get_public_material_id_re=lambda: _PUBLIC_MATERIAL_ID_RE,
        catalog=_CATALOG_PUBLICATION_PORTS,
    )
)
_invalidate_public_materials_response_cache: contracts.InvalidatePublicMaterialsResponseCacheCallback = (
    _CATALOG_RUNTIME._invalidate_public_materials_response_cache
)
_path_content_signature: contracts.PathContentSignatureCallback = _CATALOG_RUNTIME._path_content_signature
_invalidate_material_lookup_cache: contracts.InvalidateMaterialLookupCacheCallback = (
    _CATALOG_RUNTIME._invalidate_material_lookup_cache
)
_material_lookup_snapshot: contracts.MaterialLookupSnapshotCallback = (
    _CATALOG_RUNTIME._material_lookup_snapshot
)
_cached_sha256_file: contracts.CachedSha256FileCallback = _CATALOG_RUNTIME._cached_sha256_file
_classify_dxf_filename: contracts.ClassifyDxfFilenameCallback = _CATALOG_RUNTIME._classify_dxf_filename
migrate_embedded_dxfs_on_startup = _CATALOG_RUNTIME.migrate_embedded_dxfs_on_startup
classify_dxf_category: contracts.ClassifyDxfCategoryCallback = _CATALOG_RUNTIME.classify_dxf_category
migrate_embedded_dxfs_to_categories: contracts.MigrateEmbeddedDxfsToCategoriesCallback = (
    _CATALOG_RUNTIME.migrate_embedded_dxfs_to_categories
)
get_embedded_dxfs_version: contracts.GetEmbeddedDxfsVersionCallback = (
    _CATALOG_RUNTIME.get_embedded_dxfs_version
)
rebuild_embedded_dxfs_manifest: contracts.RebuildEmbeddedDxfsManifestCallback = (
    _CATALOG_RUNTIME.rebuild_embedded_dxfs_manifest
)
_looks_numeric_material_name: contracts.LooksNumericMaterialNameCallback = (
    _CATALOG_RUNTIME._looks_numeric_material_name
)
_best_material_name: contracts.BestMaterialNameCallback = _CATALOG_RUNTIME._best_material_name
_material_label_for_filename = _CATALOG_RUNTIME._material_label_for_filename
_invalidate_material_name_cache: contracts.InvalidateMaterialNameCacheCallback = (
    _CATALOG_RUNTIME._invalidate_material_name_cache
)
_load_material_name_by_code: contracts.LoadMaterialNameByCodeCallback = (
    _CATALOG_RUNTIME._load_material_name_by_code
)

from metod_app.security.access_runtime import SecurityAccessRuntime

_SECURITY_ACCESS_RUNTIME = SecurityAccessRuntime(
    SecurityAccessRuntimePorts(
        get_jobs=lambda: JOBS,
        get_root=lambda: ROOT,
        get_admin_session_store=lambda: _ADMIN_SESSION_STORE,
        get_rate_limits=lambda: _RATE_LIMITS,
        get_rate_limits_lock=lambda: _RATE_LIMITS_LOCK,
        atomic_write_json=lambda *args, **kwargs: _atomic_write_json(*args, **kwargs),
        client_ip=lambda *args, **kwargs: _client_ip(*args, **kwargs),
        direct_peer_ip=lambda *args, **kwargs: _direct_peer_ip(*args, **kwargs),
        get_admin_password_reset_activation_file_path=lambda *args,
        **kwargs: _get_admin_password_reset_activation_file_path(*args, **kwargs),
        ip_matches=lambda *args, **kwargs: _ip_matches(*args, **kwargs),
        is_externally_exposed_security_enabled=lambda *args,
        **kwargs: _is_externally_exposed_security_enabled(*args, **kwargs),
        is_https_request=lambda *args, **kwargs: _is_https_request(*args, **kwargs),
        is_loopback_client=lambda *args, **kwargs: _is_loopback_client(*args, **kwargs),
        is_loopback_value=lambda *args, **kwargs: _is_loopback_value(*args, **kwargs),
        is_trusted_proxy_peer=lambda *args, **kwargs: _is_trusted_proxy_peer(*args, **kwargs),
        load_admin_password_reset_activation=lambda *args, **kwargs: _load_admin_password_reset_activation(
            *args, **kwargs
        ),
        utc_now_iso=lambda *args, **kwargs: _utc_now_iso(*args, **kwargs),
    )
)
_direct_peer_ip: contracts.DirectPeerIpCallback = _SECURITY_ACCESS_RUNTIME._direct_peer_ip
_ip_matches: contracts.IpMatchesCallback = _SECURITY_ACCESS_RUNTIME._ip_matches
_is_trusted_proxy_peer: contracts.IsTrustedProxyPeerCallback = _SECURITY_ACCESS_RUNTIME._is_trusted_proxy_peer
_client_ip: contracts.ClientIpCallback = _SECURITY_ACCESS_RUNTIME._client_ip
_is_loopback_value: contracts.IsLoopbackValueCallback = _SECURITY_ACCESS_RUNTIME._is_loopback_value
_is_loopback_client: contracts.IsLoopbackClientCallback = _SECURITY_ACCESS_RUNTIME._is_loopback_client
_rate_limit_allow: contracts.RateLimitAllowCallback = _SECURITY_ACCESS_RUNTIME._rate_limit_allow
_rate_limit_is_blocked: contracts.RateLimitIsBlockedCallback = _SECURITY_ACCESS_RUNTIME._rate_limit_is_blocked
_rate_limit_record: contracts.RateLimitRecordCallback = _SECURITY_ACCESS_RUNTIME._rate_limit_record
_rate_limit_clear: contracts.RateLimitClearCallback = _SECURITY_ACCESS_RUNTIME._rate_limit_clear
_normalized_admin_users: contracts.NormalizedAdminUsersCallback = (
    _SECURITY_ACCESS_RUNTIME._normalized_admin_users
)
_find_admin_user = _SECURITY_ACCESS_RUNTIME._find_admin_user
_admin_session_create = _SECURITY_ACCESS_RUNTIME._admin_session_create
_admin_session_valid = _SECURITY_ACCESS_RUNTIME._admin_session_valid
_admin_session_revoke = _SECURITY_ACCESS_RUNTIME._admin_session_revoke
_admin_session_actor = _SECURITY_ACCESS_RUNTIME._admin_session_actor
_admin_session_roles = _SECURITY_ACCESS_RUNTIME._admin_session_roles
_is_password_hash_value: contracts.IsPasswordHashValueCallback = (
    _SECURITY_ACCESS_RUNTIME._is_password_hash_value
)
_is_https_request: contracts.IsHttpsRequestCallback = _SECURITY_ACCESS_RUNTIME._is_https_request
_is_secure_admin_transport: contracts.IsSecureAdminTransportCallback = (
    _SECURITY_ACCESS_RUNTIME._is_secure_admin_transport
)
_is_production_runtime: contracts.IsProductionRuntimeCallback = (
    _SECURITY_ACCESS_RUNTIME._is_production_runtime
)
_is_externally_exposed_security_enabled: contracts.IsExternallyExposedSecurityEnabledCallback = (
    _SECURITY_ACCESS_RUNTIME._is_externally_exposed_security_enabled
)
_get_admin_credentials_file_path: contracts.GetAdminCredentialsFilePathCallback = (
    _SECURITY_ACCESS_RUNTIME._get_admin_credentials_file_path
)
_get_admin_password_reset_activation_file_path: contracts.GetAdminPasswordResetActivationFilePathCallback = (
    _SECURITY_ACCESS_RUNTIME._get_admin_password_reset_activation_file_path
)
_load_admin_password_reset_activation: contracts.LoadAdminPasswordResetActivationCallback = (
    _SECURITY_ACCESS_RUNTIME._load_admin_password_reset_activation
)
_admin_password_reset_activation_is_enabled: contracts.AdminPasswordResetActivationIsEnabledCallback = (
    _SECURITY_ACCESS_RUNTIME._admin_password_reset_activation_is_enabled
)
_origin_allowed: contracts.OriginAllowedCallback = _SECURITY_ACCESS_RUNTIME._origin_allowed
_extract_request_token: contracts.ExtractRequestTokenCallback = (
    _SECURITY_ACCESS_RUNTIME._extract_request_token
)
_new_public_access_token: contracts.NewPublicAccessTokenCallback = (
    _SECURITY_ACCESS_RUNTIME._new_public_access_token
)
_write_job_access_token = _SECURITY_ACCESS_RUNTIME._write_job_access_token
_read_job_access_token: contracts.ReadJobAccessTokenCallback = _SECURITY_ACCESS_RUNTIME._read_job_access_token

from metod_app.jobs.admission_runtime import JobAdmissionRuntime

_JOB_ADMISSION_RUNTIME = JobAdmissionRuntime(
    JobsAdmissionRuntimePorts(
        get_public_job_admission=lambda: _PUBLIC_JOB_ADMISSION,
        get_public_job_scheduler=lambda: _PUBLIC_JOB_SCHEDULER,
        finish_public_job_slot=lambda *args, **kwargs: _finish_public_job_slot(*args, **kwargs),
        get_job_lock=lambda: _job_lock,
        get_job_meta=lambda: _job_meta,
        launch_public_job_item=lambda *args, **kwargs: _launch_public_job_item(*args, **kwargs),
        now_iso=lambda *args, **kwargs: _now_iso(*args, **kwargs),
        refresh_public_job_queue_meta_locked=lambda *args, **kwargs: _refresh_public_job_queue_meta_locked(
            *args, **kwargs
        ),
        release_state_capacity_reservation=lambda *args, **kwargs: _release_state_capacity_reservation(
            *args, **kwargs
        ),
        save_job_runtime_state=lambda *args, **kwargs: _save_job_runtime_state(*args, **kwargs),
        sync_public_job_admission_legacy_counters=lambda *args,
        **kwargs: _sync_public_job_admission_legacy_counters(*args, **kwargs),
        sync_public_job_scheduler_legacy_state=lambda *args,
        **kwargs: _sync_public_job_scheduler_legacy_state(*args, **kwargs),
    )
)
_public_job_queue_limits: contracts.PublicJobQueueLimitsCallback = (
    _JOB_ADMISSION_RUNTIME._public_job_queue_limits
)
_decrement_public_job_ip_locked = _JOB_ADMISSION_RUNTIME._decrement_public_job_ip_locked
_refresh_public_job_queue_meta_locked: contracts.RefreshPublicJobQueueMetaLockedCallback = (
    _JOB_ADMISSION_RUNTIME._refresh_public_job_queue_meta_locked
)
_launch_public_job_item: contracts.LaunchPublicJobItemCallback = (
    _JOB_ADMISSION_RUNTIME._launch_public_job_item
)
_try_acquire_public_job_slot: contracts.TryAcquirePublicJobSlotCallback = (
    _JOB_ADMISSION_RUNTIME._try_acquire_public_job_slot
)
_release_public_job_slot: contracts.ReleasePublicJobSlotCallback = (
    _JOB_ADMISSION_RUNTIME._release_public_job_slot
)
_commit_public_job_slot: contracts.CommitPublicJobSlotCallback = (
    _JOB_ADMISSION_RUNTIME._commit_public_job_slot
)
_finish_public_job_slot: contracts.FinishPublicJobSlotCallback = (
    _JOB_ADMISSION_RUNTIME._finish_public_job_slot
)
_cancel_queued_public_job: contracts.CancelQueuedPublicJobCallback = (
    _JOB_ADMISSION_RUNTIME._cancel_queued_public_job
)
_catalog_review_sha256: contracts.CatalogReviewSha256Callback = _JOB_ADMISSION_RUNTIME._catalog_review_sha256

from metod_app.observability.runtime import ObservabilityRuntime

_OBSERVABILITY_RUNTIME = ObservabilityRuntime(
    ObservabilityRuntimePorts(
        get_requests=lambda: REQUESTS,
        get_observability=lambda: _OBSERVABILITY,
        get_public_job_active_total=lambda: _PUBLIC_JOB_ACTIVE_TOTAL,
        get_public_job_create_lock=lambda: _PUBLIC_JOB_CREATE_LOCK,
        get_public_job_create_total=lambda: _PUBLIC_JOB_CREATE_TOTAL,
        get_public_job_queue=lambda: _PUBLIC_JOB_QUEUE,
        get_public_job_reserved_total=lambda: _PUBLIC_JOB_RESERVED_TOTAL,
        guess_customer_name_from_payload=lambda *args, **kwargs: _guess_customer_name_from_payload(
            *args, **kwargs
        ),
        get_embedded_dxfs_version=get_embedded_dxfs_version,
    )
)
_guess_customer_name_from_payload: contracts.GuessCustomerNameFromPayloadCallback = (
    _OBSERVABILITY_RUNTIME._guess_customer_name_from_payload
)
_guess_customer_name: contracts.GuessCustomerNameCallback = _OBSERVABILITY_RUNTIME._guess_customer_name
_append_system_event: contracts.AppendSystemEventCallback = _OBSERVABILITY_RUNTIME._append_system_event
_read_system_events: contracts.ReadSystemEventsCallback = _OBSERVABILITY_RUNTIME._read_system_events
_observability_public_job_snapshot: contracts.ObservabilityPublicJobSnapshotCallback = (
    _OBSERVABILITY_RUNTIME._observability_public_job_snapshot
)

from metod_app.storage.backup_runtime import BackupRuntime

_BACKUP_RUNTIME = BackupRuntime(
    StorageBackupRuntimePorts(
        get_archive_jobs=lambda: ARCHIVE_JOBS,
        get_archive_queue_done=lambda: ARCHIVE_QUEUE_DONE,
        get_archive_queue_failed=lambda: ARCHIVE_QUEUE_FAILED,
        get_archive_requests=lambda: ARCHIVE_REQUESTS,
        get_auto_backup_interval_days=lambda: AUTO_BACKUP_INTERVAL_DAYS,
        get_auto_backup_keep=lambda: AUTO_BACKUP_KEEP,
        get_backups_dir=lambda: BACKUPS_DIR,
        get_catalog_import_history=lambda: CATALOG_IMPORT_HISTORY,
        get_catalog_import_root=lambda: CATALOG_IMPORT_ROOT,
        get_config_dir=lambda: CONFIG_DIR,
        get_decor_media_root=lambda: DECOR_MEDIA_ROOT,
        get_drafts=lambda: DRAFTS,
        get_dxf_library_root=lambda: DXF_LIBRARY_ROOT,
        get_index_dir=lambda: INDEX_DIR,
        get_jobs=lambda: JOBS,
        get_job_create_idempotency_dir=lambda: JOB_CREATE_IDEMPOTENCY_DIR,
        get_last_auto_backup_file=lambda: LAST_AUTO_BACKUP_FILE,
        get_manual_backup_keep=lambda: MANUAL_BACKUP_KEEP,
        get_material_library_path=lambda: MATERIAL_LIBRARY_PATH,
        get_material_library_seed_path=lambda: MATERIAL_LIBRARY_SEED_PATH,
        get_queue_done=lambda: QUEUE_DONE,
        get_queue_failed=lambda: QUEUE_FAILED,
        get_queue_pending=lambda: QUEUE_PENDING,
        get_queue_processing=lambda: QUEUE_PROCESSING,
        get_requests=lambda: REQUESTS,
        get_root=lambda: ROOT,
        get_security_build=lambda: SECURITY_BUILD,
        get_state_root=lambda: STATE_ROOT,
        get_submission_idempotency_dir=lambda: SUBMISSION_IDEMPOTENCY_DIR,
        get_system_dir=lambda: SYSTEM_DIR,
        get_state_snapshot_lock=lambda: _STATE_SNAPSHOT_LOCK,
        append_system_event=_append_system_event,
        assert_backup_capacity=lambda *args, **kwargs: _assert_backup_capacity(*args, **kwargs),
        backup_source_inventory=lambda *args, **kwargs: _backup_source_inventory(*args, **kwargs),
        begin_consistent_snapshot=lambda *args, **kwargs: _begin_consistent_snapshot(*args, **kwargs),
        cleanup_old_backups=lambda *args, **kwargs: _cleanup_old_backups(*args, **kwargs),
        create_system_backup=lambda *args, **kwargs: _create_system_backup(*args, **kwargs),
        end_consistent_snapshot=lambda *args, **kwargs: _end_consistent_snapshot(*args, **kwargs),
        ensure_system_dirs=lambda *args, **kwargs: _ensure_system_dirs(*args, **kwargs),
        exclusive_state_maintenance=lambda *args, **kwargs: _exclusive_state_maintenance(*args, **kwargs),
        now_iso=lambda *args, **kwargs: _now_iso(*args, **kwargs),
        read_last_auto_backup_dt=lambda *args, **kwargs: _read_last_auto_backup_dt(*args, **kwargs),
        verify_system_backup_zip=lambda *args, **kwargs: _verify_system_backup_zip(*args, **kwargs),
        write_last_auto_backup=lambda *args, **kwargs: _write_last_auto_backup(*args, **kwargs),
        catalog=_CATALOG_PUBLICATION_PORTS,
    )
)
_ensure_system_dirs: contracts.EnsureSystemDirsCallback = _BACKUP_RUNTIME._ensure_system_dirs
_initialize_external_state: contracts.InitializeExternalStateCallback = (
    _BACKUP_RUNTIME._initialize_external_state
)
_cleanup_old_backups: contracts.CleanupOldBackupsCallback = _BACKUP_RUNTIME._cleanup_old_backups
_backup_source_inventory: contracts.BackupSourceInventoryCallback = _BACKUP_RUNTIME._backup_source_inventory
_assert_backup_capacity: contracts.AssertBackupCapacityCallback = _BACKUP_RUNTIME._assert_backup_capacity
_verify_system_backup_zip: contracts.VerifySystemBackupZipCallback = _BACKUP_RUNTIME._verify_system_backup_zip
_write_last_auto_backup: contracts.WriteLastAutoBackupCallback = _BACKUP_RUNTIME._write_last_auto_backup
_read_last_auto_backup_dt: contracts.ReadLastAutoBackupDtCallback = _BACKUP_RUNTIME._read_last_auto_backup_dt
run_backup_maintenance: contracts.RunBackupMaintenanceCallback = _BACKUP_RUNTIME.run_backup_maintenance
_create_system_backup: contracts.CreateSystemBackupCallback = _BACKUP_RUNTIME._create_system_backup
_list_backups: contracts.ListBackupsCallback = _BACKUP_RUNTIME._list_backups

from metod_app.notifications.runtime import NotificationRuntime

_NOTIFICATION_RUNTIME = NotificationRuntime(
    NotificationsRuntimePorts(
        get_config_notify=lambda: CONFIG_NOTIFY,
        get_jobs=lambda: JOBS,
        get_ntfy_log=lambda: NTFY_LOG,
        calculation_summary_text_for_ntfy=lambda *args, **kwargs: _calculation_summary_text_for_ntfy(
            *args, **kwargs
        ),
        extract_request_summary=lambda *args, **kwargs: _extract_request_summary(*args, **kwargs),
        get_notify_config_file_path=lambda *args, **kwargs: _get_notify_config_file_path(*args, **kwargs),
        load_notify_config=lambda *args, **kwargs: _load_notify_config(*args, **kwargs),
        notify_privacy_options=lambda *args, **kwargs: _notify_privacy_options(*args, **kwargs),
        now_iso=lambda *args, **kwargs: _now_iso(*args, **kwargs),
        ntfy_log=lambda *args, **kwargs: _ntfy_log(*args, **kwargs),
        ntfy_public_safe_customer_lines=lambda *args, **kwargs: _ntfy_public_safe_customer_lines(
            *args, **kwargs
        ),
        ntfy_send=lambda *args, **kwargs: _ntfy_send(*args, **kwargs),
        validated_ntfy_target=lambda *args, **kwargs: _validated_ntfy_target(*args, **kwargs),
    )
)
_get_notify_config_file_path: contracts.GetNotifyConfigFilePathCallback = (
    _NOTIFICATION_RUNTIME._get_notify_config_file_path
)
_ntfy_log: contracts.NtfyLogCallback = _NOTIFICATION_RUNTIME._ntfy_log
_load_notify_config: contracts.LoadNotifyConfigCallback = _NOTIFICATION_RUNTIME._load_notify_config
_validated_ntfy_target: contracts.ValidatedNtfyTargetCallback = _NOTIFICATION_RUNTIME._validated_ntfy_target
_ntfy_send: contracts.NtfySendCallback = _NOTIFICATION_RUNTIME._ntfy_send
_calculation_summary_text_for_ntfy: contracts.CalculationSummaryTextForNtfyCallback = (
    _NOTIFICATION_RUNTIME._calculation_summary_text_for_ntfy
)
_notify_privacy_options: contracts.NotifyPrivacyOptionsCallback = (
    _NOTIFICATION_RUNTIME._notify_privacy_options
)
_ntfy_public_safe_customer_lines: contracts.NtfyPublicSafeCustomerLinesCallback = (
    _NOTIFICATION_RUNTIME._ntfy_public_safe_customer_lines
)
_notify_submitted: contracts.NotifySubmittedCallback = _NOTIFICATION_RUNTIME._notify_submitted
_notify_failed = _NOTIFICATION_RUNTIME._notify_failed

from metod_app.jobs.payload_runtime import JobPayloadRuntime

_JOB_PAYLOAD_RUNTIME = JobPayloadRuntime(
    JobsPayloadRuntimePorts(
        get_job_output_max_bytes=lambda: JOB_OUTPUT_MAX_BYTES,
        get_state_root=lambda: STATE_ROOT,
        get_state_capacity_reservations=lambda: _STATE_CAPACITY_RESERVATIONS,
        compact_dxf_transport=lambda *args, **kwargs: _compact_dxf_transport(*args, **kwargs),
        dir_size_bytes=lambda *args, **kwargs: _dir_size_bytes(*args, **kwargs),
        dxf_transport_stats=lambda *args, **kwargs: _dxf_transport_stats(*args, **kwargs),
        expand_dxf_payload=lambda *args, **kwargs: _expand_dxf_payload(*args, **kwargs),
        get_payload_total_qty=lambda *args, **kwargs: _get_payload_total_qty(*args, **kwargs),
        job_family_size_bytes=lambda *args, **kwargs: _job_family_size_bytes(*args, **kwargs),
        job_output_limit_message=lambda *args, **kwargs: _job_output_limit_message(*args, **kwargs),
        parse_panels_csv=lambda *args, **kwargs: _parse_panels_csv(*args, **kwargs),
    )
)
_job_output_limit_message: contracts.JobOutputLimitMessageCallback = (
    _JOB_PAYLOAD_RUNTIME._job_output_limit_message
)
_job_family_size_bytes: contracts.JobFamilySizeBytesCallback = _JOB_PAYLOAD_RUNTIME._job_family_size_bytes
_enforce_job_output_limit: contracts.EnforceJobOutputLimitCallback = (
    _JOB_PAYLOAD_RUNTIME._enforce_job_output_limit
)
_enforce_state_capacity: contracts.EnforceStateCapacityCallback = _JOB_PAYLOAD_RUNTIME._enforce_state_capacity
_reserve_state_capacity: contracts.ReserveStateCapacityCallback = _JOB_PAYLOAD_RUNTIME._reserve_state_capacity
_release_state_capacity_reservation: contracts.ReleaseStateCapacityReservationCallback = (
    _JOB_PAYLOAD_RUNTIME._release_state_capacity_reservation
)
_state_capacity_reservation_totals = _JOB_PAYLOAD_RUNTIME._state_capacity_reservation_totals
_expand_dxf_payload: contracts.ExpandDxfPayloadCallback = _JOB_PAYLOAD_RUNTIME._expand_dxf_payload
_compact_dxf_transport: contracts.CompactDxfTransportCallback = _JOB_PAYLOAD_RUNTIME._compact_dxf_transport
_validated_canonical_dxf_transport: contracts.ValidatedCanonicalDxfTransportCallback = (
    _JOB_PAYLOAD_RUNTIME._validated_canonical_dxf_transport
)
_dxf_transport_stats: contracts.DxfTransportStatsCallback = _JOB_PAYLOAD_RUNTIME._dxf_transport_stats
_estimate_preflight_job_family_bytes: contracts.EstimatePreflightJobFamilyBytesCallback = (
    _JOB_PAYLOAD_RUNTIME._estimate_preflight_job_family_bytes
)
_preflight_job_family_limit_message = _JOB_PAYLOAD_RUNTIME._preflight_job_family_limit_message
_get_payload_total_qty: contracts.GetPayloadTotalQtyCallback = _JOB_PAYLOAD_RUNTIME._get_payload_total_qty
_enforce_job_total_qty_limit: contracts.EnforceJobTotalQtyLimitCallback = (
    _JOB_PAYLOAD_RUNTIME._enforce_job_total_qty_limit
)
_estimate_payload_area_lower_bound: contracts.EstimatePayloadAreaLowerBoundCallback = (
    _JOB_PAYLOAD_RUNTIME._estimate_payload_area_lower_bound
)

from metod_app.jobs.state_runtime import JobStateRuntime

_JOB_STATE_RUNTIME = JobStateRuntime(
    JobsStateRuntimePorts(
        get_jobs=lambda: JOBS,
        get_job_restart_reconciler=lambda: _JOB_RESTART_RECONCILER,
        get_optimizer_process_supervisor=lambda: _OPTIMIZER_PROCESS_SUPERVISOR,
        find_existing_file=lambda *args, **kwargs: _find_existing_file(*args, **kwargs),
        job_runtime_state_path=lambda *args, **kwargs: _job_runtime_state_path(*args, **kwargs),
        load_job_runtime_state=lambda *args, **kwargs: _load_job_runtime_state(*args, **kwargs),
        transition_job_runtime_state=lambda *args, **kwargs: _transition_job_runtime_state(*args, **kwargs),
        utc_now_iso=lambda *args, **kwargs: _utc_now_iso(*args, **kwargs),
    )
)
_get_python_base_cmd: contracts.GetPythonBaseCmdCallback = _JOB_STATE_RUNTIME._get_python_base_cmd
_job_runtime_state_path: contracts.JobRuntimeStatePathCallback = _JOB_STATE_RUNTIME._job_runtime_state_path
_load_job_runtime_state: contracts.LoadJobRuntimeStateCallback = _JOB_STATE_RUNTIME._load_job_runtime_state
_transition_job_runtime_state: contracts.TransitionJobRuntimeStateCallback = (
    _JOB_STATE_RUNTIME._transition_job_runtime_state
)
_save_job_runtime_state: contracts.SaveJobRuntimeStateCallback = _JOB_STATE_RUNTIME._save_job_runtime_state
_job_cancel_requested: contracts.JobCancelRequestedCallback = _JOB_STATE_RUNTIME._job_cancel_requested
_register_job_process: contracts.RegisterJobProcessCallback = _JOB_STATE_RUNTIME._register_job_process
_unregister_job_process: contracts.RegisterJobProcessCallback = _JOB_STATE_RUNTIME._unregister_job_process
_terminate_optimizer_process: contracts.TerminateOptimizerProcessCallback = (
    _JOB_STATE_RUNTIME._terminate_optimizer_process
)
_reconcile_interrupted_jobs_on_startup: contracts.ReconcileInterruptedJobsOnStartupCallback = (
    _JOB_STATE_RUNTIME._reconcile_interrupted_jobs_on_startup
)
_find_existing_file: contracts.FindExistingFileCallback = _JOB_STATE_RUNTIME._find_existing_file
_find_placements_any = _JOB_STATE_RUNTIME._find_placements_any
_find_labels_any = _JOB_STATE_RUNTIME._find_labels_any

from metod_app.storage.io_runtime import StorageIoRuntime

_STORAGE_IO_RUNTIME = StorageIoRuntime(
    StorageIoRuntimePorts(
        get_archive_jobs=lambda: ARCHIVE_JOBS,
        get_archive_queue_done=lambda: ARCHIVE_QUEUE_DONE,
        get_archive_queue_failed=lambda: ARCHIVE_QUEUE_FAILED,
        get_archive_requests=lambda: ARCHIVE_REQUESTS,
        get_archive_root=lambda: ARCHIVE_ROOT,
        get_archive_transactions=lambda: ARCHIVE_TRANSACTIONS,
        get_backups_dir=lambda: BACKUPS_DIR,
        get_index_dir=lambda: INDEX_DIR,
        get_queue_dir=lambda: QUEUE_DIR,
        get_queue_done=lambda: QUEUE_DONE,
        get_queue_failed=lambda: QUEUE_FAILED,
        get_queue_pending=lambda: QUEUE_PENDING,
        get_queue_processing=lambda: QUEUE_PROCESSING,
        get_requests=lambda: REQUESTS,
        get_submission_idempotency_dir=lambda: SUBMISSION_IDEMPOTENCY_DIR,
        get_system_dir=lambda: SYSTEM_DIR,
        write_replaceable_bytes=lambda *args, **kwargs: _write_replaceable_bytes(*args, **kwargs),
        write_replaceable_text=lambda *args, **kwargs: _write_replaceable_text(*args, **kwargs),
    )
)
_now_iso: contracts.NowIsoCallback = _STORAGE_IO_RUNTIME._now_iso
_safe_json: contracts.SafeJsonCallback = _STORAGE_IO_RUNTIME._safe_json
_read_json_body = _STORAGE_IO_RUNTIME._read_json_body
_read_json_body_limited: contracts.ReadJsonBodyLimitedCallback = _STORAGE_IO_RUNTIME._read_json_body_limited
_safe_job_file = _STORAGE_IO_RUNTIME._safe_job_file
_write_file: contracts.WriteFileCallback = _STORAGE_IO_RUNTIME._write_file
_write_bytes = _STORAGE_IO_RUNTIME._write_bytes
_write_replaceable_bytes: contracts.WriteReplaceableBytesCallback = (
    _STORAGE_IO_RUNTIME._write_replaceable_bytes
)
_write_replaceable_text: contracts.WriteReplaceableTextCallback = _STORAGE_IO_RUNTIME._write_replaceable_text
_write_replaceable_json: contracts.WriteReplaceableJsonCallback = _STORAGE_IO_RUNTIME._write_replaceable_json
_link_or_copy_file: contracts.LinkOrCopyFileCallback = _STORAGE_IO_RUNTIME._link_or_copy_file
_atomic_write_text = _STORAGE_IO_RUNTIME._atomic_write_text
_atomic_write_json: contracts.AtomicWriteJsonCallback = _STORAGE_IO_RUNTIME._atomic_write_json
_utc_now_iso: contracts.NowIsoCallback = _STORAGE_IO_RUNTIME._utc_now_iso
_ensure_request_dirs: contracts.EnsureRequestDirsCallback = _STORAGE_IO_RUNTIME._ensure_request_dirs
_ensure_archive_dirs: contracts.EnsureArchiveDirsCallback = _STORAGE_IO_RUNTIME._ensure_archive_dirs

from metod_app.storage.archive_runtime import ArchiveRuntime

_ARCHIVE_RUNTIME = ArchiveRuntime(
    StorageArchiveRuntimePorts(
        get_archive_jobs=lambda: ARCHIVE_JOBS,
        get_archive_meta_name=lambda: ARCHIVE_META_NAME,
        get_archive_queue_done=lambda: ARCHIVE_QUEUE_DONE,
        get_archive_queue_failed=lambda: ARCHIVE_QUEUE_FAILED,
        get_archive_requests=lambda: ARCHIVE_REQUESTS,
        get_archive_root=lambda: ARCHIVE_ROOT,
        get_archive_transactions=lambda: ARCHIVE_TRANSACTIONS,
        get_jobs=lambda: JOBS,
        get_queue_done=lambda: QUEUE_DONE,
        get_queue_failed=lambda: QUEUE_FAILED,
        get_requests=lambda: REQUESTS,
        get_submission_idempotency_dir=lambda: SUBMISSION_IDEMPOTENCY_DIR,
        get_archive_transaction_lock=lambda: _ARCHIVE_TRANSACTION_LOCK,
        append_system_event=_append_system_event,
        archive_journal_entries=lambda *args, **kwargs: _archive_journal_entries(*args, **kwargs),
        archive_journal_path=lambda *args, **kwargs: _archive_journal_path(*args, **kwargs),
        archive_journal_write=lambda *args, **kwargs: _archive_journal_write(*args, **kwargs),
        atomic_write_json=_atomic_write_json,
        complete_archive_journal=lambda *args, **kwargs: _complete_archive_journal(*args, **kwargs),
        ensure_archive_dirs=_ensure_archive_dirs,
        get_fcntl=lambda: _fcntl,
        get_job_meta=lambda: _job_meta,
        linked_job_ids_from_status=lambda *args, **kwargs: _linked_job_ids_from_status(*args, **kwargs),
        load_status=lambda *args, **kwargs: _load_status(*args, **kwargs),
        parse_iso_dt=lambda *args, **kwargs: _parse_iso_dt(*args, **kwargs),
        path_dt=lambda *args, **kwargs: _path_dt(*args, **kwargs),
        request_created_dt_from_status=lambda *args, **kwargs: _request_created_dt_from_status(
            *args, **kwargs
        ),
        submission_marker_path=lambda *args, **kwargs: _submission_marker_path(*args, **kwargs),
        unique_archive_dest=lambda *args, **kwargs: _unique_archive_dest(*args, **kwargs),
        utc_now_iso=_utc_now_iso,
        write_archive_meta=lambda *args, **kwargs: _write_archive_meta(*args, **kwargs),
    )
)
_parse_iso_dt: contracts.ParseIsoDtCallback = _ARCHIVE_RUNTIME._parse_iso_dt
_path_dt: contracts.PathDtCallback = _ARCHIVE_RUNTIME._path_dt
_request_status_path = _ARCHIVE_RUNTIME._request_status_path
_request_created_dt_from_status: contracts.RequestCreatedDtFromStatusCallback = (
    _ARCHIVE_RUNTIME._request_created_dt_from_status
)
_request_archive_meta_dt: contracts.RequestArchiveMetaDtCallback = _ARCHIVE_RUNTIME._request_archive_meta_dt
_job_created_dt: contracts.JobCreatedDtCallback = _ARCHIVE_RUNTIME._job_created_dt
_write_archive_meta: contracts.WriteArchiveMetaCallback = _ARCHIVE_RUNTIME._write_archive_meta
_unique_archive_dest: contracts.UniqueArchiveDestCallback = _ARCHIVE_RUNTIME._unique_archive_dest
_archive_journal_path: contracts.ArchiveJournalPathCallback = _ARCHIVE_RUNTIME._archive_journal_path
_archive_journal_write: contracts.ArchiveJournalWriteCallback = _ARCHIVE_RUNTIME._archive_journal_write
_archive_journal_entries: contracts.ArchiveJournalEntriesCallback = _ARCHIVE_RUNTIME._archive_journal_entries
_complete_archive_journal: contracts.CompleteArchiveJournalCallback = (
    _ARCHIVE_RUNTIME._complete_archive_journal
)
_reconcile_archive_transactions: contracts.ReconcileArchiveTransactionsCallback = (
    _ARCHIVE_RUNTIME._reconcile_archive_transactions
)
_linked_job_ids_from_status: contracts.LinkedJobIdsFromStatusCallback = (
    _ARCHIVE_RUNTIME._linked_job_ids_from_status
)
_archive_request_and_linked_jobs: contracts.ArchiveRequestAndLinkedJobsCallback = (
    _ARCHIVE_RUNTIME._archive_request_and_linked_jobs
)

from metod_app.storage.retention_runtime import RetentionRuntime

_RETENTION_RUNTIME = RetentionRuntime(
    StorageRetentionRuntimePorts(
        get_archive_jobs=lambda: ARCHIVE_JOBS,
        get_archive_queue_done=lambda: ARCHIVE_QUEUE_DONE,
        get_archive_queue_failed=lambda: ARCHIVE_QUEUE_FAILED,
        get_archive_requests=lambda: ARCHIVE_REQUESTS,
        get_catalog_import_history=lambda: CATALOG_IMPORT_HISTORY,
        get_catalog_import_root=lambda: CATALOG_IMPORT_ROOT,
        get_decor_media_root=lambda: DECOR_MEDIA_ROOT,
        get_drafts=lambda: DRAFTS,
        get_jobs=lambda: JOBS,
        get_material_library_path=lambda: MATERIAL_LIBRARY_PATH,
        get_orphan_job_retention_days=lambda: ORPHAN_JOB_RETENTION_DAYS,
        get_queue_done=lambda: QUEUE_DONE,
        get_queue_failed=lambda: QUEUE_FAILED,
        get_requests=lambda: REQUESTS,
        get_retention_active_days=lambda: RETENTION_ACTIVE_DAYS,
        get_retention_archive_days=lambda: RETENTION_ARCHIVE_DAYS,
        get_retention_open_request_max_days=lambda: RETENTION_OPEN_REQUEST_MAX_DAYS,
        get_state_root=lambda: STATE_ROOT,
        get_submission_idempotency_dir=lambda: SUBMISSION_IDEMPOTENCY_DIR,
        get_system_dir=lambda: SYSTEM_DIR,
        get_system_log_file=lambda: SYSTEM_LOG_FILE,
        get_catalog_image_sync_active=lambda: _CATALOG_IMAGE_SYNC_ACTIVE,
        get_catalog_image_sync_lock=lambda: _CATALOG_IMAGE_SYNC_LOCK,
        get_public_material_id_re=lambda: _PUBLIC_MATERIAL_ID_RE,
        get_server_maintenance_loop_seconds=lambda: _SERVER_MAINTENANCE_LOOP_SECONDS,
        append_system_event=_append_system_event,
        archive_request_and_linked_jobs=_archive_request_and_linked_jobs,
        cleanup_public_job_idempotency=lambda *args, **kwargs: _cleanup_public_job_idempotency(
            *args, **kwargs
        ),
        ensure_archive_dirs=_ensure_archive_dirs,
        ensure_request_dirs=_ensure_request_dirs,
        ensure_system_dirs=_ensure_system_dirs,
        find_request_status_for_job=lambda *args, **kwargs: _find_request_status_for_job(*args, **kwargs),
        job_created_dt=_job_created_dt,
        linked_job_ids_from_status=_linked_job_ids_from_status,
        load_status=lambda *args, **kwargs: _load_status(*args, **kwargs),
        path_dt=_path_dt,
        record_maintenance_failure=lambda *args, **kwargs: _record_maintenance_failure(*args, **kwargs),
        request_archive_meta_dt=_request_archive_meta_dt,
        request_created_dt_from_status=_request_created_dt_from_status,
        request_is_terminal_for_retention=lambda *args, **kwargs: _request_is_terminal_for_retention(
            *args, **kwargs
        ),
        save_status=lambda *args, **kwargs: _save_status(*args, **kwargs),
        run_backup_maintenance=run_backup_maintenance,
        run_queue_maintenance=lambda *args, **kwargs: run_queue_maintenance(*args, **kwargs),
        run_retention_maintenance=lambda *args, **kwargs: run_retention_maintenance(*args, **kwargs),
    )
)
_purge_old_archives = _RETENTION_RUNTIME._purge_old_archives
_request_is_terminal_for_retention: contracts.RequestIsTerminalForRetentionCallback = (
    _RETENTION_RUNTIME._request_is_terminal_for_retention
)
_archive_expired_active_data = _RETENTION_RUNTIME._archive_expired_active_data
_cleanup_operational_state = _RETENTION_RUNTIME._cleanup_operational_state
_move_queue_file_safe: contracts.MoveQueueFileSafeCallback = _RETENTION_RUNTIME._move_queue_file_safe
_mark_request_failed_if_stale = _RETENTION_RUNTIME._mark_request_failed_if_stale
_record_maintenance_failure: contracts.RecordMaintenanceFailureCallback = (
    _RETENTION_RUNTIME._record_maintenance_failure
)
_server_maintenance_loop: contracts.ServerMaintenanceLoopCallback = (
    _RETENTION_RUNTIME._server_maintenance_loop
)

from metod_app.requests.runtime import RequestRuntime

_REQUEST_RUNTIME = RequestRuntime(
    RequestsRuntimePorts(
        get_jobs=lambda: JOBS,
        get_requests=lambda: REQUESTS,
        get_job_finalization_service=lambda: _JOB_FINALIZATION_SERVICE,
        iter_request_statuses=lambda *args, **kwargs: _iter_request_statuses(*args, **kwargs),
    )
)
_new_request_id: contracts.NewRequestIdCallback = _REQUEST_RUNTIME._new_request_id
_linked_subjob_ids: contracts.LinkedSubjobIdsCallback = _REQUEST_RUNTIME._linked_subjob_ids
_master_job_id_for: contracts.MasterJobIdForCallback = _REQUEST_RUNTIME._master_job_id_for
_public_job_family_complete: contracts.PublicJobFamilyCompleteCallback = (
    _REQUEST_RUNTIME._public_job_family_complete
)
_iter_request_statuses: contracts.IterRequestStatusesCallback = _REQUEST_RUNTIME._iter_request_statuses
_find_request_status_for_job: contracts.FindRequestStatusForJobCallback = (
    _REQUEST_RUNTIME._find_request_status_for_job
)
_load_request_payload: contracts.LoadRequestPayloadCallback = _REQUEST_RUNTIME._load_request_payload

from metod_app.pricing.runtime import PricingRuntime

_PRICING_RUNTIME = PricingRuntime(
    PricingRuntimePorts(
        get_cnc_cost_per_sheet=lambda: CNC_COST_PER_SHEET,
        get_config_dir=lambda: CONFIG_DIR,
        get_drawing_cost_fixed=lambda: DRAWING_COST_FIXED,
        get_edge_band_price_per_m=lambda: EDGE_BAND_PRICE_PER_M,
        get_jobs=lambda: JOBS,
        get_legacy_sheet_price_factor_default=lambda: LEGACY_SHEET_PRICE_FACTOR_DEFAULT,
        get_material_library_path=lambda: MATERIAL_LIBRARY_PATH,
        get_pricing_active=lambda: PRICING_ACTIVE,
        get_pricing_audit=lambda: PRICING_AUDIT,
        get_pricing_seed_path=lambda: PRICING_SEED_PATH,
        get_pricing_versions=lambda: PRICING_VERSIONS,
        get_system_dir=lambda: SYSTEM_DIR,
        get_transport_cost_fixed=lambda: TRANSPORT_COST_FIXED,
        get_material_library_lock=lambda: _MATERIAL_LIBRARY_LOCK,
        get_pricing_config_lock=lambda: _PRICING_CONFIG_LOCK,
        atomic_write_json=_atomic_write_json,
        material_lookup_snapshot=_material_lookup_snapshot,
        parse_panels_csv=lambda *args, **kwargs: _parse_panels_csv(*args, **kwargs),
        utc_now_iso=_utc_now_iso,
        catalog=_CATALOG_PUBLICATION_PORTS,
    )
)
_default_pricing_config: contracts.DefaultPricingConfigCallback = _PRICING_RUNTIME._default_pricing_config
_normalize_pricing_config_schema: contracts.NormalizePricingConfigSchemaCallback = (
    _PRICING_RUNTIME._normalize_pricing_config_schema
)
_load_pricing_config: contracts.LoadPricingConfigCallback = _PRICING_RUNTIME._load_pricing_config
_capture_public_job_pricing_authority: contracts.CapturePublicJobPricingAuthorityCallback = (
    _PRICING_RUNTIME._capture_public_job_pricing_authority
)
_ensure_pricing_config_files: contracts.EnsurePricingConfigFilesCallback = (
    _PRICING_RUNTIME._ensure_pricing_config_files
)
_save_pricing_config: contracts.SavePricingConfigCallback = _PRICING_RUNTIME._save_pricing_config
_migrate_legacy_materials_to_direct_sell_prices: contracts.MigrateLegacyMaterialsToDirectSellPricesCallback = _PRICING_RUNTIME._migrate_legacy_materials_to_direct_sell_prices
_ensure_pricing_materials: contracts.EnsurePricingMaterialsCallback = (
    _PRICING_RUNTIME._ensure_pricing_materials
)
_apply_sell_pricing_to_quote: contracts.ApplySellPricingToQuoteCallback = (
    _PRICING_RUNTIME._apply_sell_pricing_to_quote
)
_format_eur: contracts.FormatEurCallback = _PRICING_RUNTIME._format_eur
_format_m: contracts.FormatMCallback = _PRICING_RUNTIME._format_m
_extract_pricing_from_any = _PRICING_RUNTIME._extract_pricing_from_any
_aggregate_materials_from_subjob_quotes: contracts.AggregateMaterialsFromSubjobQuotesCallback = (
    _PRICING_RUNTIME._aggregate_materials_from_subjob_quotes
)
_parse_calculation_summary_totals: contracts.ParseCalculationSummaryTotalsCallback = (
    _PRICING_RUNTIME._parse_calculation_summary_totals
)

from metod_app.pricing.report_runtime import PricingReportRuntime

_PRICING_REPORT_RUNTIME = PricingReportRuntime(
    PricingReportRuntimePorts(
        get_cnc_cost_per_sheet=lambda: CNC_COST_PER_SHEET,
        get_drawing_cost_fixed=lambda: DRAWING_COST_FIXED,
        get_edge_band_price_per_m=lambda: EDGE_BAND_PRICE_PER_M,
        get_jobs=lambda: JOBS,
        get_transport_cost_fixed=lambda: TRANSPORT_COST_FIXED,
        aggregate_materials_from_subjob_quotes=_aggregate_materials_from_subjob_quotes,
        best_material_name=_best_material_name,
        find_request_status_for_job=_find_request_status_for_job,
        format_eur=_format_eur,
        format_m=_format_m,
        job_material_context=lambda *args, **kwargs: _job_material_context(*args, **kwargs),
        load_pricing_config=_load_pricing_config,
        load_request_payload=_load_request_payload,
        parse_panels_csv=lambda *args, **kwargs: _parse_panels_csv(*args, **kwargs),
    )
)
_write_human_calculation_summary: contracts.WriteHumanCalculationSummaryCallback = (
    _PRICING_REPORT_RUNTIME._write_human_calculation_summary
)

from metod_app.jobs.output_runtime import JobOutputRuntime

_JOB_OUTPUT_RUNTIME = JobOutputRuntime(
    JobsOutputRuntimePorts(
        get_jobs=lambda: JOBS,
        get_material_library_path=lambda: MATERIAL_LIBRARY_PATH,
        get_optimizer_tool_b=lambda: OPTIMIZER_TOOL_B,
        get_public_base_url=lambda: PUBLIC_BASE_URL,
        get_stickertool_v2_build=lambda: STICKERTOOL_V2_BUILD,
        get_job_finalization_service=lambda: _JOB_FINALIZATION_SERVICE,
        best_material_name=_best_material_name,
        customer_display_name=lambda *args, **kwargs: _customer_display_name(*args, **kwargs),
        customer_name_from_job=lambda *args, **kwargs: _customer_name_from_job(*args, **kwargs),
        job_material_context=lambda *args, **kwargs: _job_material_context(*args, **kwargs),
        material_name_and_thickness=lambda *args, **kwargs: _material_name_and_thickness(*args, **kwargs),
        parse_panels_csv=lambda *args, **kwargs: _parse_panels_csv(*args, **kwargs),
        resolve_stickertool_material_display_name=lambda *args,
        **kwargs: _resolve_stickertool_material_display_name(*args, **kwargs),
        sheet_sequence_from_filename=lambda *args, **kwargs: _sheet_sequence_from_filename(*args, **kwargs),
        utc_now_iso=_utc_now_iso,
    )
)
_parse_panels_csv: contracts.ParsePanelsCsvCallback = _JOB_OUTPUT_RUNTIME._parse_panels_csv
_is_subjob = _JOB_OUTPUT_RUNTIME._is_subjob
_filter_panels_csv_by_material: contracts.FilterPanelsCsvByMaterialCallback = (
    _JOB_OUTPUT_RUNTIME._filter_panels_csv_by_material
)
_parts_for_panels_rows = _JOB_OUTPUT_RUNTIME._parts_for_panels_rows
_customer_display_name: contracts.CustomerDisplayNameCallback = _JOB_OUTPUT_RUNTIME._customer_display_name
_customer_name_from_job: contracts.CustomerNameFromJobCallback = _JOB_OUTPUT_RUNTIME._customer_name_from_job
_material_name_and_thickness: contracts.MaterialNameAndThicknessCallback = (
    _JOB_OUTPUT_RUNTIME._material_name_and_thickness
)
_resolve_stickertool_material_display_name: contracts.ResolveStickertoolMaterialDisplayNameCallback = (
    _JOB_OUTPUT_RUNTIME._resolve_stickertool_material_display_name
)
_job_material_context: contracts.JobMaterialContextCallback = _JOB_OUTPUT_RUNTIME._job_material_context
_sheet_sequence_from_filename: contracts.SheetSequenceFromFilenameCallback = (
    _JOB_OUTPUT_RUNTIME._sheet_sequence_from_filename
)
_admin_sheet_download_name: contracts.AdminSheetDownloadNameCallback = (
    _JOB_OUTPUT_RUNTIME._admin_sheet_download_name
)
_generate_stickertool_json: contracts.GenerateStickertoolJsonCallback = (
    _JOB_OUTPUT_RUNTIME._generate_stickertool_json
)
_placements_item_count = _JOB_OUTPUT_RUNTIME._placements_item_count
_generate_labels_json_strict: contracts.GenerateLabelsJsonStrictCallback = (
    _JOB_OUTPUT_RUNTIME._generate_labels_json_strict
)
_input_dxf_source_map: contracts.InputDxfSourceMapCallback = _JOB_OUTPUT_RUNTIME._input_dxf_source_map
_finalize_subjob_outputs: contracts.FinalizeSubjobOutputsCallback = (
    _JOB_OUTPUT_RUNTIME._finalize_subjob_outputs
)
_write_master_job_links: contracts.WriteMasterJobLinksCallback = _JOB_OUTPUT_RUNTIME._write_master_job_links
_finalization_complete: contracts.FinalizationCompleteCallback = _JOB_OUTPUT_RUNTIME._finalization_complete
_sealed_output_artifacts: contracts.SealedOutputArtifactsCallback = (
    _JOB_OUTPUT_RUNTIME._sealed_output_artifacts
)


_DEFAULT_ADMIN_PASSWORDS = {"change-me", "changeme", "admin", "password", "123456", "SET_STRONG_PASSWORD"}
_ADMIN_PBKDF2_ITERATIONS = 600000
_DUMMY_ADMIN_PASSWORD_HASH: str = "pbkdf2_sha256$600000$metod-constant-time-dummy$0aca85bbbb3ab83dc5a9a1acb16a2b30a9051695731317d7bca628f1d8886f0a"
_DUMMY_ADMIN_TOTP_SECRET: str = "JBSWY3DPEHPK3PXP"
_RATE_LIMITS_LOCK: contracts.LockLike = threading.Lock()
_RATE_LIMITS: dict[tuple[str, str], list[float]] = {}
_PUBLIC_JOB_ADMISSION: contracts.PublicJobAdmission = PublicJobAdmission(lock=threading.Lock())
_PUBLIC_JOB_CREATE_LOCK: contracts.LockLike = _PUBLIC_JOB_ADMISSION.lock
_PUBLIC_JOB_CREATE_BY_IP = _PUBLIC_JOB_ADMISSION.by_ip
_PUBLIC_JOB_CREATE_TOTAL: int = _PUBLIC_JOB_ADMISSION.total
_PUBLIC_JOB_RESERVED_TOTAL: int = _PUBLIC_JOB_ADMISSION.reserved_total
_PUBLIC_JOB_RESERVED_BY_IP = _PUBLIC_JOB_ADMISSION.reserved_by_ip
_PUBLIC_JOB_SCHEDULER: contracts.PublicJobScheduler = PublicJobScheduler(
    admission=_PUBLIC_JOB_ADMISSION,
    max_active=lambda: _public_job_queue_limits()[0],
)
_PUBLIC_JOB_QUEUE: contracts.deque[dict[str, Any]] = _PUBLIC_JOB_SCHEDULER.queue
_PUBLIC_JOB_ACTIVE_BY_ID = _PUBLIC_JOB_SCHEDULER.active_by_id
_PUBLIC_JOB_ACTIVE_TOTAL: int = _PUBLIC_JOB_SCHEDULER.active_total
_STATE_CAPACITY_RESERVATIONS: contracts.StateCapacityReservations = StateCapacityReservations(
    lock=threading.RLock()
)
_JOB_STORAGE_RESERVATION_LOCK = _STATE_CAPACITY_RESERVATIONS.lock
_JOB_STORAGE_RESERVATIONS = _STATE_CAPACITY_RESERVATIONS.records
_ADMIN_SESSION_STORE: contracts.AdminSessionStore = AdminSessionStore(
    idle_seconds=_RUNTIME_CONFIG.admin_session_idle_seconds,
    absolute_seconds=_RUNTIME_CONFIG.admin_session_absolute_seconds,
    max_sessions=lambda: _env_int("ADMIN_MAX_SESSIONS", 1024),
    lock=threading.Lock(),
)


def _sync_public_job_admission_legacy_counters() -> None:
    """Keep read-only legacy diagnostics aligned during scheduler migration."""

    global _PUBLIC_JOB_CREATE_TOTAL, _PUBLIC_JOB_RESERVED_TOTAL
    _PUBLIC_JOB_CREATE_TOTAL = _PUBLIC_JOB_ADMISSION.total
    _PUBLIC_JOB_RESERVED_TOTAL = _PUBLIC_JOB_ADMISSION.reserved_total


def _sync_public_job_scheduler_legacy_counter() -> None:
    """Keep the read-only legacy active counter aligned during extraction."""

    global _PUBLIC_JOB_ACTIVE_TOTAL
    _PUBLIC_JOB_ACTIVE_TOTAL = _PUBLIC_JOB_SCHEDULER.active_total


def _sync_public_job_scheduler_legacy_state() -> None:
    """Synchronize all read-only migration diagnostics under scheduler lock."""

    _sync_public_job_admission_legacy_counters()
    _sync_public_job_scheduler_legacy_counter()


# --- DXF startup migration (file-based, deterministic) ---
DXF_CATEGORIES: list[str] = [
    "Deuren METOD",
    "Ladefront METOD",
    "Deuren PAX",
    "Overige panelen",
]


OPTIMIZER_TOOL_B: str = "dxf_nesting_optimizer.py"
JOBS: Path = _APP_PATHS.jobs
DRAFTS: Path = _APP_PATHS.drafts

# Lightweight index/registry folder (used by some endpoints).
INDEX_DIR: Path = _APP_PATHS.index_dir

# Append-only requests index (JSONL). This is used to power Admin inbox views
# without scanning the full requests tree. Must be defined at module load so
# endpoints like /api/submit_config never fail with NameError.
REQUESTS_INDEX = _APP_PATHS.requests_index
_REQUESTS_INDEX_LOCK = threading.RLock()

# --- Requests/Queue (online A-only foundation; file-based, deterministic) ---
REQUESTS: Path = _APP_PATHS.requests
QUEUE_DIR: Path = _APP_PATHS.queue_dir
WORKER_LOCK: Path = QUEUE_DIR / ".worker.lock"
QUEUE_PENDING: Path = _APP_PATHS.queue_pending
QUEUE_PROCESSING: Path = _APP_PATHS.queue_processing
QUEUE_DONE: Path = _APP_PATHS.queue_done
QUEUE_FAILED: Path = _APP_PATHS.queue_failed
SUBMISSION_IDEMPOTENCY_DIR: Path = _APP_PATHS.submission_idempotency_dir
_SUBMISSION_IDEMPOTENCY_LOCK: contracts.LockLike = threading.Lock()
_ARCHIVE_TRANSACTION_LOCK: contracts.LockLike = threading.RLock()

# --- Retention / archive (terminal 90d, open hard max 365d -> archive; archive 90d; orphan jobs 7d) ---
ARCHIVE_ROOT: Path = _APP_PATHS.archive_root
ARCHIVE_JOBS: Path = _APP_PATHS.archive_jobs
ARCHIVE_REQUESTS: Path = _APP_PATHS.archive_requests
ARCHIVE_QUEUE_DONE: Path = _APP_PATHS.archive_queue_done
ARCHIVE_QUEUE_FAILED: Path = _APP_PATHS.archive_queue_failed
ARCHIVE_TRANSACTIONS: Path = _APP_PATHS.archive_transactions
RETENTION_ACTIVE_DAYS: int = _RUNTIME_CONFIG.retention_active_days
RETENTION_OPEN_REQUEST_MAX_DAYS: int = _RUNTIME_CONFIG.retention_open_request_max_days
RETENTION_ARCHIVE_DAYS: int = _RUNTIME_CONFIG.retention_archive_days
ORPHAN_JOB_RETENTION_DAYS: int = _RUNTIME_CONFIG.orphan_job_retention_days
ARCHIVE_META_NAME: str = ".archived_meta.json"
_LAST_RETENTION_RUN_TS = 0.0
_RETENTION_MIN_INTERVAL_SECONDS = 6 * 60 * 60  # max 1x per 6 uur per proces

# Queue / maintenance hardening
STALE_PENDING_QUEUE_DAYS = 7
STALE_PROCESSING_QUEUE_HOURS = 24
_LAST_QUEUE_MAINTENANCE_TS = 0.0
_QUEUE_MAINTENANCE_MIN_INTERVAL_SECONDS = 60 * 60  # max 1x per uur per proces
_SERVER_MAINTENANCE_LOOP_SECONDS: int = 15 * 60

# --- System logs / backups ---
SYSTEM_DIR: Path = _APP_PATHS.system_dir
JOB_CREATE_IDEMPOTENCY_DIR: Path = SYSTEM_DIR / "job_create_idempotency"
_JOB_CREATE_IDEMPOTENCY = JobCreateIdempotencyRepository(
    root=lambda: JOB_CREATE_IDEMPOTENCY_DIR,
    utc_now_iso=lambda: _utc_now_iso(),
    new_owner_nonce=lambda: secrets.token_urlsafe(24),
)
_claim_public_job_idempotency: contracts.ClaimPublicJobIdempotencyCallback = _JOB_CREATE_IDEMPOTENCY.claim
_public_job_idempotency_key_exists: contracts.PublicJobIdempotencyKeyExistsCallback = (
    _JOB_CREATE_IDEMPOTENCY.contains_key
)
_lookup_public_job_idempotency: contracts.LookupPublicJobIdempotencyCallback = _JOB_CREATE_IDEMPOTENCY.lookup
_complete_public_job_idempotency: contracts.CompletePublicJobIdempotencyCallback = (
    _JOB_CREATE_IDEMPOTENCY.complete
)
_recover_public_job_idempotency: contracts.RecoverPublicJobIdempotencyCallback = (
    _JOB_CREATE_IDEMPOTENCY.recover
)
_abandon_public_job_idempotency: contracts.AbandonPublicJobIdempotencyCallback = (
    _JOB_CREATE_IDEMPOTENCY.abandon
)
_cleanup_public_job_idempotency: contracts.CleanupPublicJobIdempotencyCallback = (
    _JOB_CREATE_IDEMPOTENCY.cleanup
)
_reconcile_public_job_idempotency_on_startup: contracts.ReconcilePublicJobIdempotencyOnStartupCallback = (
    _JOB_CREATE_IDEMPOTENCY.reconcile_startup
)
CATALOG_IMPORT_ROOT: Path = _APP_PATHS.catalog_import_root
CATALOG_IMPORT_HISTORY: Path = _APP_PATHS.catalog_import_history
SYSTEM_LOG_FILE: Path = _APP_PATHS.system_log_file
BACKUPS_DIR: Path = _APP_PATHS.backups_dir
AUTO_BACKUP_INTERVAL_DAYS: int = 7
AUTO_BACKUP_KEEP: int = 8
MANUAL_BACKUP_KEEP: int = 12
LAST_AUTO_BACKUP_FILE: Path = _APP_PATHS.last_auto_backup_file
_STATE_SNAPSHOT_LOCK: contracts.LockLike = threading.RLock()
_STATE_MAINTENANCE_LOCK = threading.Lock()
_STATE_MUTATION_CV = threading.Condition(threading.RLock())
_STATE_MUTATION_COUNT = 0
_STATE_SNAPSHOT_ACTIVE = False


# --- Notifications (ntfy) ---
CONFIG_NOTIFY: Path = _APP_PATHS.config_notify
CONFIG_NOTIFY_EXAMPLE = ROOT / "config_notify.example.json"


NTFY_LOG: Path = _APP_PATHS.ntfy_log


def _append_client_log(source, event, message, details):
    """Server-side diagnostics share the bounded, redacted event sink."""
    _append_system_event(
        level="info",
        component=str(source),
        status="resolved",
        message_user="Technische controle",
        message_tech=str(message),
        details={"event": str(event), "data": details},
    )


_REQUEST_PROJECTION = RequestProjection(best_material_name=_best_material_name)
_extract_request_summary: contracts.ExtractRequestSummaryCallback = _REQUEST_PROJECTION.extract_summary


PORT: int = _RUNTIME_CONFIG.port
JOB_OUTPUT_MAX_BYTES: int = _RUNTIME_CONFIG.job_output_max_bytes


CONFIG_DIR: Path = _APP_PATHS.config_dir
PRICING_ACTIVE: Path = _APP_PATHS.pricing_active
PRICING_VERSIONS: Path = _APP_PATHS.pricing_versions
PRICING_AUDIT: Path = _APP_PATHS.pricing_audit

# --- Pricing rules (sell prices) ---
# Legacy factor is read only once for one-time migration of existing material prices.
# New calculations never apply a material factor: each material carries its own direct sell price.
LEGACY_SHEET_PRICE_FACTOR_DEFAULT: float = _RUNTIME_CONFIG.legacy_sheet_price_factor_default
# Edge banding sell price per meter.
EDGE_BAND_PRICE_PER_M: float = _RUNTIME_CONFIG.edge_band_price_per_m
# CNC routing cost per used sheet.
CNC_COST_PER_SHEET: float = _RUNTIME_CONFIG.cnc_cost_per_sheet
# One-time drawing / setup cost per job.
DRAWING_COST_FIXED: float = _RUNTIME_CONFIG.drawing_cost_fixed
# One-time transport cost per job.
TRANSPORT_COST_FIXED: float = _RUNTIME_CONFIG.transport_cost_fixed


HOST: str = _RUNTIME_CONFIG.host
PUBLIC_HOST = _RUNTIME_CONFIG.public_host
PUBLIC_BASE_URL: str = _RUNTIME_CONFIG.public_base_url

# in-memory job status
_job_lock: contracts.LockLike = threading.Lock()
_job_meta: dict[str, dict] = {}
_OPTIMIZER_PROCESS_SUPERVISOR: contracts.OptimizerProcessSupervisor = OptimizerProcessSupervisor(
    lock=threading.RLock(),
    validate_job_id=validate_job_id,
    os_module=os,
    signal_module=signal,
)
# Compatibility aliases for the unchanged maintenance-barrier contract.
_ACTIVE_JOB_PROCESSES_LOCK = _OPTIMIZER_PROCESS_SUPERVISOR.lock
_ACTIVE_JOB_PROCESSES = _OPTIMIZER_PROCESS_SUPERVISOR.processes

_STATE_MAINTENANCE_BARRIER: contracts.StateMaintenanceBarrier = StateMaintenanceBarrier(
    ensure_directories=lambda: _ensure_system_dirs(),
    backups_root=lambda: BACKUPS_DIR,
    maintenance_lock=lambda: _STATE_MAINTENANCE_LOCK,
    file_lock_module=lambda: _fcntl,
    mutation_condition=lambda: _STATE_MUTATION_CV,
    snapshot_active=lambda: _STATE_SNAPSHOT_ACTIVE,
    set_snapshot_active=lambda value: globals().__setitem__("_STATE_SNAPSHOT_ACTIVE", bool(value)),
    mutation_count=lambda: _STATE_MUTATION_COUNT,
    set_mutation_count=lambda value: globals().__setitem__("_STATE_MUTATION_COUNT", max(0, int(value))),
    public_job_create_lock=lambda: _PUBLIC_JOB_CREATE_LOCK,
    public_job_create_total=lambda: _PUBLIC_JOB_CREATE_TOTAL,
    active_job_processes_lock=lambda: _ACTIVE_JOB_PROCESSES_LOCK,
    active_job_processes=lambda: _ACTIVE_JOB_PROCESSES,
    catalog_image_sync_lock=lambda: _CATALOG_IMAGE_SYNC_LOCK,
    catalog_image_sync_active=lambda: _CATALOG_IMAGE_SYNC_ACTIVE,
    queue_processing_root=lambda: QUEUE_PROCESSING,
    monotonic=lambda: time.monotonic(),
    sleep=lambda seconds: time.sleep(seconds),
)
_state_snapshot_is_active: contracts.StateSnapshotIsActiveCallback = (
    _STATE_MAINTENANCE_BARRIER.snapshot_is_active
)
_exclusive_state_maintenance: contracts.ExclusiveStateMaintenanceCallback = (
    _STATE_MAINTENANCE_BARRIER.exclusive
)
_begin_consistent_snapshot: contracts.BeginConsistentSnapshotCallback = (
    _STATE_MAINTENANCE_BARRIER.begin_consistent_snapshot
)
_end_consistent_snapshot: contracts.EndConsistentSnapshotCallback = (
    _STATE_MAINTENANCE_BARRIER.end_consistent_snapshot
)
_PRIVACY_SERVICE: contracts.CustomerPrivacyService = CustomerPrivacyService(
    STATE_ROOT, _STATE_MAINTENANCE_BARRIER
)


class JobCancelledError(RuntimeError):
    pass


_JOB_RESTART_RECONCILER: contracts.JobRestartReconciler = JobRestartReconciler(
    jobs_root=JOBS,
    read_json=lambda path: strict_json_load(path),
    validate_job_id=lambda value: validate_job_id(value),
    save_runtime_state=lambda job_id, state, **extra: _save_job_runtime_state(job_id, state, **extra),
    append_system_event=lambda **event: _append_system_event(**event),
)


# --- Atomic file utilities (avoid 0-byte / race conditions) ---


_REQUEST_REPOSITORY = RequestRepository(
    requests_root=lambda: REQUESTS,
    requests_index=lambda: REQUESTS_INDEX,
    index_lock=lambda: _REQUESTS_INDEX_LOCK,
    ensure_directories=_ensure_request_dirs,
    utc_now_iso=_utc_now_iso,
    jsonl_max_bytes=lambda: _env_int("JSONL_MAX_BYTES", 20 * 1024 * 1024),
    max_active_rows=lambda: _env_int("REQUEST_INDEX_MAX_ACTIVE_ROWS", 250_000),
    file_lock_module=lambda: _fcntl,
)
_load_status: contracts.LoadStatusCallback = _REQUEST_REPOSITORY.load_status
_save_status: contracts.SaveStatusCallback = _REQUEST_REPOSITORY.save_status
_mutate_status: contracts.MutateStatusCallback = _REQUEST_REPOSITORY.mutate_status
_compact_requests_index = _REQUEST_REPOSITORY.compact_index


def run_retention_maintenance(force: bool = False) -> dict:
    global _LAST_RETENTION_RUN_TS
    with _exclusive_state_maintenance():
        now_ts = time.time()
        if (
            (not force)
            and _LAST_RETENTION_RUN_TS
            and (now_ts - _LAST_RETENTION_RUN_TS) < _RETENTION_MIN_INTERVAL_SECONDS
        ):
            return {"ok": True, "skipped": True, "reason": "interval"}

        # An attempted-but-failed run must never suppress the next retry for
        # six hours. Only a fully successful pass below records a timestamp.
        _LAST_RETENTION_RUN_TS = 0.0
        snapshot_started = False
        try:
            _begin_consistent_snapshot(timeout_seconds=max(10, _env_int("RETENTION_DRAIN_TIMEOUT_SEC", 60)))
            snapshot_started = True
            now_dt = datetime.now(timezone.utc).replace(tzinfo=None)
            recovered = _reconcile_archive_transactions()
            archived = _archive_expired_active_data(now_dt)
            purged = _purge_old_archives(now_dt)
            operational = _cleanup_operational_state(now_dt)
            try:
                request_index = _compact_requests_index()
            except Exception as exc:
                report_recovery("metod_app.runtime.application.boundary.1030", exc)
                request_index = {"error": str(exc)}
        finally:
            if snapshot_started:
                _end_consistent_snapshot()

        errors: list[Any] = []
        errors.extend(recovered.get("errors") or [])
        errors.extend(archived.get("errors") or [])
        errors.extend(purged.get("errors") or [])
        errors.extend(operational.get("errors") or [])
        if request_index.get("error"):
            errors.append({"requestIndex": str(request_index["error"])})
        ok = not errors
        if ok:
            _LAST_RETENTION_RUN_TS = time.time()
        return {
            "ok": ok,
            "archived": archived,
            "recoveredArchives": recovered,
            "purged": purged,
            "operational": operational,
            "requestIndex": request_index,
            "errors": errors,
            "ranAt": now_dt.isoformat() + "Z",
        }


def run_queue_maintenance(force: bool = False) -> dict:
    global _LAST_QUEUE_MAINTENANCE_TS
    with _exclusive_state_maintenance():
        if _state_snapshot_is_active():
            return {"ok": True, "skipped": True, "reason": "state-snapshot"}
        now_ts = time.time()
        if (
            (not force)
            and _LAST_QUEUE_MAINTENANCE_TS
            and (now_ts - _LAST_QUEUE_MAINTENANCE_TS) < _QUEUE_MAINTENANCE_MIN_INTERVAL_SECONDS
        ):
            return {"ok": True, "skipped": True, "reason": "interval"}
        # Failed queue maintenance must remain immediately retryable rather than
        # being hidden behind the normal one-hour success interval.
        _LAST_QUEUE_MAINTENANCE_TS = 0.0
        now_dt = datetime.now(timezone.utc).replace(tzinfo=None)
        result: dict[str, Any] = {
            "ok": True,
            "pendingFailed": 0,
            "processingFailed": 0,
            "errors": [],
            "ranAt": now_dt.isoformat() + "Z",
        }

        def _handle_stale(path: Path, *, age_delta: timedelta, bucket: str, code: str, message: str) -> None:
            try:
                mtime = datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc).replace(tzinfo=None)
            except (OSError, ValueError, TypeError, OverflowError) as e:
                result["errors"].append({"file": path.name, "error": str(e)})
                return
            if now_dt - mtime < age_delta:
                return
            request_id = ""
            try:
                payload = strict_json_load(path)
                request_id = _safe_id((payload or {}).get("requestId") or "", 120)
            except Exception as recovery_error:
                report_recovery("metod_app.runtime.application.boundary.1084", recovery_error)
                payload = None
            try:
                if request_id:
                    _mark_request_failed_if_stale(request_id, code=code, message=message)
                _move_queue_file_safe(path, QUEUE_FAILED)
                result[bucket] += 1
                _append_system_event(
                    level="warning",
                    component="jobs",
                    message_user="Een verouderd queue-item is automatisch afgehandeld",
                    message_tech=f"{path.name} marked stale in {path.parent.name}",
                    request_id=request_id,
                    status="open",
                )
            except Exception as e:
                report_recovery("metod_app.runtime.application.boundary.1092", e)
                result["errors"].append({"file": path.name, "error": str(e)})

        for path in sorted(QUEUE_PENDING.glob("*.json")):
            _handle_stale(
                path,
                age_delta=timedelta(days=STALE_PENDING_QUEUE_DAYS),
                bucket="pendingFailed",
                code="STALE_PENDING_QUEUE_ITEM",
                message="Aanvraag te lang in wachtrij gebleven en automatisch als fout gemarkeerd.",
            )
        for path in sorted(QUEUE_PROCESSING.glob("*.json")):
            _handle_stale(
                path,
                age_delta=timedelta(hours=STALE_PROCESSING_QUEUE_HOURS),
                bucket="processingFailed",
                code="STALE_PROCESSING_QUEUE_ITEM",
                message="Aanvraag bleef te lang in verwerking hangen en is automatisch als fout gemarkeerd.",
            )
        result["ok"] = not result["errors"]
        if result["ok"]:
            _LAST_QUEUE_MAINTENANCE_TS = time.time()
        return result


# Submission claims and the authenticated commit transaction are composed below,
# after the strict authoritative pricing reader is defined.


# --- Pricing config (Option B: versioned active pricing) ---


# New jobs have one authoritative, finalization-sealed summary in output/.
# Readers retain the input/ fallback solely for historical jobs; writing an
# identical unsealed mirror cost two extra storage barriers per job/subjob.


from metod_app.runtime.composition import (
    build_core_runtime_services as _build_core_runtime_services,
)


_COMPOSITION_PORTS = RuntimeCompositionPorts(
    get_dxf_library_root=lambda: DXF_LIBRARY_ROOT,
    get_dxf_manifest_path=lambda: DXF_MANIFEST_PATH,
    get_jobs=lambda: JOBS,
    get_job_output_max_bytes=lambda: JOB_OUTPUT_MAX_BYTES,
    JobCancelledError=JobCancelledError,
    get_material_library_path=lambda: MATERIAL_LIBRARY_PATH,
    get_pricing_active=lambda: PRICING_ACTIVE,
    get_queue_pending=lambda: QUEUE_PENDING,
    get_queue_processing=lambda: QUEUE_PROCESSING,
    get_requests=lambda: REQUESTS,
    get_root=lambda: ROOT,
    get_security_build=lambda: SECURITY_BUILD,
    get_state_root=lambda: STATE_ROOT,
    get_submission_idempotency_dir=lambda: SUBMISSION_IDEMPOTENCY_DIR,
    get_system_dir=lambda: SYSTEM_DIR,
    get_system_log_file=lambda: SYSTEM_LOG_FILE,
    get_admin_session_store=lambda: _ADMIN_SESSION_STORE,
    get_dummy_admin_password_hash=lambda: _DUMMY_ADMIN_PASSWORD_HASH,
    get_dummy_admin_totp_secret=lambda: _DUMMY_ADMIN_TOTP_SECRET,
    get_optimizer_process_supervisor=lambda: _OPTIMIZER_PROCESS_SUPERVISOR,
    get_pricing_config_lock=lambda: _PRICING_CONFIG_LOCK,
    get_submission_idempotency_lock=lambda: _SUBMISSION_IDEMPOTENCY_LOCK,
    abandon_public_job_idempotency=_abandon_public_job_idempotency,
    admin_sheet_download_name=_admin_sheet_download_name,
    append_client_log=_append_client_log,
    append_system_event=_append_system_event,
    apply_sell_pricing_to_quote=_apply_sell_pricing_to_quote,
    atomic_write_json=_atomic_write_json,
    best_material_name=_best_material_name,
    build_request_file_manifest=lambda *args, **kwargs: _build_request_file_manifest(*args, **kwargs),
    cached_sha256_file=_cached_sha256_file,
    cancel_queued_public_job=_cancel_queued_public_job,
    capture_public_job_pricing_authority=_capture_public_job_pricing_authority,
    claim_public_job_idempotency=_claim_public_job_idempotency,
    classify_output_kind=lambda *args, **kwargs: _classify_output_kind(*args, **kwargs),
    client_ip=_client_ip,
    collect_job_output_files=lambda *args, **kwargs: _collect_job_output_files(*args, **kwargs),
    commit_public_job_slot=_commit_public_job_slot,
    complete_public_job_idempotency=_complete_public_job_idempotency,
    create_job_from_payload=lambda *args, **kwargs: _create_job_from_payload(*args, **kwargs),
    dedupe_admin_dxf_files=lambda *args, **kwargs: _dedupe_admin_dxf_files(*args, **kwargs),
    dir_size_bytes=lambda *args, **kwargs: _dir_size_bytes(*args, **kwargs),
    dxf_transport_stats=_dxf_transport_stats,
    enforce_job_total_qty_limit=_enforce_job_total_qty_limit,
    ensure_request_dirs=_ensure_request_dirs,
    ensure_system_dirs=_ensure_system_dirs,
    estimate_payload_area_lower_bound=_estimate_payload_area_lower_bound,
    estimate_preflight_job_family_bytes=_estimate_preflight_job_family_bytes,
    extract_request_summary=_extract_request_summary,
    extract_strict_calculation_pricing_summary=lambda *args,
    **kwargs: _extract_strict_calculation_pricing_summary(*args, **kwargs),
    finalization_complete=_finalization_complete,
    find_or_generate_stickertool_file=lambda *args, **kwargs: _find_or_generate_stickertool_file(
        *args, **kwargs
    ),
    finish_public_job_slot=_finish_public_job_slot,
    generate_labels_json_strict=_generate_labels_json_strict,
    generate_stickertool_json=_generate_stickertool_json,
    get_admin_credentials_file_path=_get_admin_credentials_file_path,
    input_dxf_source_map=_input_dxf_source_map,
    is_externally_exposed_security_enabled=_is_externally_exposed_security_enabled,
    is_https_request=_is_https_request,
    is_loopback_client=_is_loopback_client,
    is_production_runtime=_is_production_runtime,
    is_secure_admin_transport=_is_secure_admin_transport,
    job_cancel_requested=_job_cancel_requested,
    get_job_lock=lambda: _job_lock,
    job_material_context=_job_material_context,
    get_job_meta=lambda: _job_meta,
    job_output_limit_message=_job_output_limit_message,
    link_or_copy_file=_link_or_copy_file,
    linked_subjob_ids=_linked_subjob_ids,
    load_job_runtime_state=_load_job_runtime_state,
    load_pricing_config=_load_pricing_config,
    load_status=_load_status,
    master_job_id_for=_master_job_id_for,
    new_public_access_token=_new_public_access_token,
    new_request_id=_new_request_id,
    notify_submitted=_notify_submitted,
    now_iso=_now_iso,
    observability_public_job_snapshot=_observability_public_job_snapshot,
    origin_allowed=_origin_allowed,
    parse_panels_csv=_parse_panels_csv,
    public_job_family_complete=_public_job_family_complete,
    public_job_idempotency_key_exists=_public_job_idempotency_key_exists,
    public_job_queue_limits=_public_job_queue_limits,
    rate_limit_allow=_rate_limit_allow,
    rate_limit_clear=_rate_limit_clear,
    rate_limit_is_blocked=_rate_limit_is_blocked,
    rate_limit_record=_rate_limit_record,
    read_json_body_limited=_read_json_body_limited,
    recover_public_job_idempotency=_recover_public_job_idempotency,
    release_public_job_slot=_release_public_job_slot,
    release_state_capacity_reservation=_release_state_capacity_reservation,
    reserve_state_capacity=_reserve_state_capacity,
    save_job_runtime_state=_save_job_runtime_state,
    save_status=_save_status,
    sealed_output_artifacts=_sealed_output_artifacts,
    terminate_optimizer_process=_terminate_optimizer_process,
    transition_job_runtime_state=_transition_job_runtime_state,
    try_acquire_public_job_slot=_try_acquire_public_job_slot,
    utc_now_iso=_utc_now_iso,
    write_human_calculation_summary=_write_human_calculation_summary,
)

_CORE_RUNTIME_SERVICES = _build_core_runtime_services(_COMPOSITION_PORTS)
_JOB_FINALIZATION_SERVICE: contracts.JobFinalizationService = _CORE_RUNTIME_SERVICES.job_finalization
_OBSERVABILITY: contracts.ObservabilityService = _CORE_RUNTIME_SERVICES.observability
_ADMIN_ACCESS: contracts.AdminAccessController = _CORE_RUNTIME_SERVICES.admin_access
_STATIC_HTTP: contracts.StaticHttpAdapterService = _CORE_RUNTIME_SERVICES.static_http
_JOB_LIFECYCLE: contracts.JobLifecycleFacadeService = _CORE_RUNTIME_SERVICES.job_lifecycle

from metod_app.http.handler import build_handler as _build_http_handler


Handler: type[contracts.WsgiHandler] = _build_http_handler(
    public_catalog=HttpPublicCatalogRuntimePorts(
        get_material_library_path=lambda: MATERIAL_LIBRARY_PATH,
        get_public_material_catalog_cache_build=lambda: PUBLIC_MATERIAL_CATALOG_CACHE_BUILD,
        get_public_material_catalog_cache_meta_path=lambda: PUBLIC_MATERIAL_CATALOG_CACHE_META_PATH,
        get_public_material_catalog_cache_path=lambda: PUBLIC_MATERIAL_CATALOG_CACHE_PATH,
        get_public_material_catalog_cache_schema=lambda: PUBLIC_MATERIAL_CATALOG_CACHE_SCHEMA,
        get_public_materials_response_cache=lambda: _PUBLIC_MATERIALS_RESPONSE_CACHE,
        get_public_materials_response_cache_lock=lambda: _PUBLIC_MATERIALS_RESPONSE_CACHE_LOCK,
        append_system_event=_append_system_event,
        atomic_write_json=_atomic_write_json,
        utc_now_iso=_utc_now_iso,
        catalog=_CATALOG_PUBLICATION_PORTS,
    ),
    catalog_import=HttpCatalogImportRuntimePorts(
        get_catalog_import_history=lambda: CATALOG_IMPORT_HISTORY,
        get_catalog_import_root=lambda: CATALOG_IMPORT_ROOT,
        get_catalog_public_id_registry=lambda: CATALOG_PUBLIC_ID_REGISTRY,
        get_catalog_taxonomy_registry=lambda: CATALOG_TAXONOMY_REGISTRY,
        get_decor_media_root=lambda: DECOR_MEDIA_ROOT,
        get_material_library_path=lambda: MATERIAL_LIBRARY_PATH,
        get_pricing_active=lambda: PRICING_ACTIVE,
        get_catalog_image_storage_bytes_per_worker=lambda: _CATALOG_IMAGE_STORAGE_BYTES_PER_WORKER,
        get_catalog_image_storage_inodes_per_worker=lambda: _CATALOG_IMAGE_STORAGE_INODES_PER_WORKER,
        get_catalog_image_storage_reservation_id=lambda: _CATALOG_IMAGE_STORAGE_RESERVATION_ID,
        get_catalog_image_sync_active=lambda: _CATALOG_IMAGE_SYNC_ACTIVE,
        get_catalog_image_sync_lock=lambda: _CATALOG_IMAGE_SYNC_LOCK,
        get_material_library_lock=lambda: _MATERIAL_LIBRARY_LOCK,
        get_pricing_config_lock=lambda: _PRICING_CONFIG_LOCK,
        get_public_material_id_re=lambda: _PUBLIC_MATERIAL_ID_RE,
        append_system_event=_append_system_event,
        atomic_write_json=_atomic_write_json,
        catalog_review_sha256=_catalog_review_sha256,
        enforce_state_capacity=_enforce_state_capacity,
        read_json_body_limited=_read_json_body_limited,
        release_state_capacity_reservation=_release_state_capacity_reservation,
        reserve_state_capacity=_reserve_state_capacity,
        utc_now_iso=_utc_now_iso,
        catalog=_CATALOG_PUBLICATION_PORTS,
    ),
    transport=HttpTransportRuntimePorts(
        get_admin_access=lambda: _ADMIN_ACCESS,
        get_static_http=lambda: _STATIC_HTTP,
        is_externally_exposed_security_enabled=_is_externally_exposed_security_enabled,
        is_loopback_client=_is_loopback_client,
        is_loopback_value=_is_loopback_value,
        origin_allowed=_origin_allowed,
    ),
    public_api=HttpPublicApiRuntimePorts(
        get_privacy_service=lambda: _PRIVACY_SERVICE,
        get_jobs=lambda: JOBS,
        get_root=lambda: ROOT,
        get_security_build=lambda: SECURITY_BUILD,
        get_state_root=lambda: STATE_ROOT,
        get_job_lifecycle=lambda: _JOB_LIFECYCLE,
        get_state_maintenance_barrier=lambda: _STATE_MAINTENANCE_BARRIER,
        get_static_http=lambda: _STATIC_HTTP,
        get_submission_service=lambda: _SUBMISSION_SERVICE,
        append_system_event=_append_system_event,
        client_ip=_client_ip,
        ensure_request_dirs=_ensure_request_dirs,
        extract_request_token=_extract_request_token,
        finalization_complete=_finalization_complete,
        is_production_runtime=_is_production_runtime,
        job_cancel_requested=_job_cancel_requested,
        load_job_runtime_state=_load_job_runtime_state,
        load_pricing_config=_load_pricing_config,
        lookup_public_job_idempotency=_lookup_public_job_idempotency,
        mutate_status=_mutate_status,
        now_iso=_now_iso,
        prometheus_metrics=lambda *args, **kwargs: _prometheus_metrics(*args, **kwargs),
        public_job_family_complete=_public_job_family_complete,
        rate_limit_allow=_rate_limit_allow,
        read_job_access_token=_read_job_access_token,
        read_json_body_limited=_read_json_body_limited,
        readiness_report=lambda *args, **kwargs: _readiness_report(*args, **kwargs),
        safe_json=_safe_json,
        save_pricing_config=_save_pricing_config,
        utc_now_iso=_utc_now_iso,
        api_admin_control_center=lambda *args, **kwargs: api_admin_control_center(*args, **kwargs),
        api_admin_jobs=lambda *args, **kwargs: api_admin_jobs(*args, **kwargs),
        api_admin_request_download_zip=lambda *args, **kwargs: api_admin_request_download_zip(
            *args, **kwargs
        ),
        api_admin_request_file=lambda *args, **kwargs: api_admin_request_file(*args, **kwargs),
        api_admin_request_files=lambda *args, **kwargs: api_admin_request_files(*args, **kwargs),
        api_admin_requests=lambda *args, **kwargs: api_admin_requests(*args, **kwargs),
        api_admin_requests_update=lambda *args, **kwargs: api_admin_requests_update(*args, **kwargs),
        api_download=lambda *args, **kwargs: api_download(*args, **kwargs),
        api_draft_load=lambda *args, **kwargs: api_draft_load(*args, **kwargs),
        api_draft_save=lambda *args, **kwargs: api_draft_save(*args, **kwargs),
        api_dxf_manifest_meta=lambda *args, **kwargs: api_dxf_manifest_meta(*args, **kwargs),
        api_job_file=lambda *args, **kwargs: api_job_file(*args, **kwargs),
        api_subjob_file=lambda *args, **kwargs: api_subjob_file(*args, **kwargs),
    ),
    admin_operations=HttpAdminOperationsRuntimePorts(
        get_backups_dir=lambda: BACKUPS_DIR,
        append_system_event=_append_system_event,
        create_system_backup=_create_system_backup,
        list_backups=_list_backups,
        read_json_body_limited=_read_json_body_limited,
        read_system_events=_read_system_events,
        get_embedded_dxfs_version=get_embedded_dxfs_version,
        rebuild_embedded_dxfs_manifest=rebuild_embedded_dxfs_manifest,
    ),
    filter_groups=HttpFilterGroupsRuntimePorts(
        append_system_event=_append_system_event,
        invalidate_public_materials_response_cache=_invalidate_public_materials_response_cache,
        read_json_body_limited=_read_json_body_limited,
        catalog=_CATALOG_PUBLICATION_PORTS,
    ),
    material_dxf=HttpMaterialDxfRuntimePorts(get_dxf_library_root=lambda: DXF_LIBRARY_ROOT),
    material_catalog=HttpMaterialCatalogRuntimePorts(
        get_decor_media_root=lambda: DECOR_MEDIA_ROOT,
        get_dxf_library_root=lambda: DXF_LIBRARY_ROOT,
        get_material_library_path=lambda: MATERIAL_LIBRARY_PATH,
        get_material_library_lock=lambda: _MATERIAL_LIBRARY_LOCK,
        get_pricing_config_lock=lambda: _PRICING_CONFIG_LOCK,
        get_public_material_id_re=lambda: _PUBLIC_MATERIAL_ID_RE,
        append_system_event=_append_system_event,
        expand_dxf_payload=_expand_dxf_payload,
        invalidate_material_lookup_cache=_invalidate_material_lookup_cache,
        invalidate_material_name_cache=_invalidate_material_name_cache,
        invalidate_public_materials_response_cache=_invalidate_public_materials_response_cache,
        material_lookup_snapshot=_material_lookup_snapshot,
        utc_now_iso=_utc_now_iso,
        catalog=_CATALOG_PUBLICATION_PORTS,
    ),
    catalog=_CATALOG_PUBLICATION_PORTS,
)


# Thin compatibility adapters keep the established internal call surface while
# endpoint implementation is owned by bounded HTTP modules.
from metod_app.http.endpoints import drafts as _http_drafts
from metod_app.http.endpoints import admin_jobs as _http_admin_jobs
from metod_app.http.endpoints import admin_requests as _http_admin_requests
from metod_app.http.endpoints import downloads as _http_downloads
from metod_app.http.endpoints import control_center as _http_control_center


_HTTP_ENDPOINTS_DRAFTS_PORTS = HttpEndpointsDraftsPorts(
    read_json_body_limited=_read_json_body_limited,
    get_embedded_dxfs_version=get_embedded_dxfs_version,
)


def api_draft_save(self):
    return _http_drafts.api_draft_save(_HTTP_ENDPOINTS_DRAFTS_PORTS, self)


def api_dxf_manifest_meta(handler, parsed):
    return _http_drafts.api_dxf_manifest_meta(_HTTP_ENDPOINTS_DRAFTS_PORTS, handler, parsed)


def api_draft_load(self, parsed):
    return _http_drafts.api_draft_load(_HTTP_ENDPOINTS_DRAFTS_PORTS, self, parsed)


_HTTP_ENDPOINTS_ADMIN_JOBS_PORTS = HttpEndpointsAdminJobsPorts(
    get_jobs=lambda: JOBS,
    get_request_download_projections=lambda: _REQUEST_DOWNLOAD_PROJECTIONS,
    admin_sheet_download_name=_admin_sheet_download_name,
    best_material_name=_best_material_name,
    classify_output_kind=lambda *args, **kwargs: _classify_output_kind(*args, **kwargs),
    customer_name_from_job=_customer_name_from_job,
    edge_meters_by_decor=lambda *args, **kwargs: _edge_meters_by_decor(*args, **kwargs),
    get_job_lock=lambda: _job_lock,
    job_material_context=_job_material_context,
    get_job_meta=lambda: _job_meta,
    job_runtime_state_path=_job_runtime_state_path,
    load_job_runtime_state=_load_job_runtime_state,
    parse_calculation_summary_totals=_parse_calculation_summary_totals,
    parse_panels_csv=_parse_panels_csv,
    sealed_output_artifacts=_sealed_output_artifacts,
)


def _edge_meters_by_decor(job_dir: Path):
    return _http_admin_jobs._edge_meters_by_decor(_HTTP_ENDPOINTS_ADMIN_JOBS_PORTS, job_dir)


def api_admin_jobs(self):
    return _http_admin_jobs.api_admin_jobs(_HTTP_ENDPOINTS_ADMIN_JOBS_PORTS, self)


def _classify_output_kind(name: str):
    return _http_admin_jobs._classify_output_kind(_HTTP_ENDPOINTS_ADMIN_JOBS_PORTS, name)


def _collect_job_output_files(job_id: str):
    return _http_admin_jobs._collect_job_output_files(_HTTP_ENDPOINTS_ADMIN_JOBS_PORTS, job_id)


def _dedupe_admin_dxf_files(files: list[dict]):
    return _http_admin_jobs._dedupe_admin_dxf_files(_HTTP_ENDPOINTS_ADMIN_JOBS_PORTS, files)


def _extract_strict_calculation_pricing_summary(job_ids: list[str]):
    return _http_admin_jobs._extract_strict_calculation_pricing_summary(
        _HTTP_ENDPOINTS_ADMIN_JOBS_PORTS, job_ids
    )


def _find_or_generate_stickertool_file(job_id: str):
    return _http_admin_jobs._find_or_generate_stickertool_file(_HTTP_ENDPOINTS_ADMIN_JOBS_PORTS, job_id)


_HTTP_ENDPOINTS_ADMIN_REQUESTS_PORTS = HttpEndpointsAdminRequestsPorts(
    get_system_dir=lambda: SYSTEM_DIR,
    get_request_download_projections=lambda: _REQUEST_DOWNLOAD_PROJECTIONS,
    append_system_event=_append_system_event,
    build_request_file_manifest=lambda *args, **kwargs: _build_request_file_manifest(*args, **kwargs),
    ensure_request_dirs=_ensure_request_dirs,
    load_status=_load_status,
    mutate_status=_mutate_status,
    read_json_body_limited=_read_json_body_limited,
    api_job_file=lambda *args, **kwargs: api_job_file(*args, **kwargs),
)


def _dir_size_bytes(root: Path):
    return _http_admin_requests._dir_size_bytes(_HTTP_ENDPOINTS_ADMIN_REQUESTS_PORTS, root)


def _build_request_file_manifest(request_id: str):
    return _http_admin_requests._build_request_file_manifest(_HTTP_ENDPOINTS_ADMIN_REQUESTS_PORTS, request_id)


def api_admin_request_files(self):
    return _http_admin_requests.api_admin_request_files(_HTTP_ENDPOINTS_ADMIN_REQUESTS_PORTS, self)


def api_admin_request_file(self):
    return _http_admin_requests.api_admin_request_file(_HTTP_ENDPOINTS_ADMIN_REQUESTS_PORTS, self)


def api_admin_request_download_zip(self):
    return _http_admin_requests.api_admin_request_download_zip(_HTTP_ENDPOINTS_ADMIN_REQUESTS_PORTS, self)


def api_admin_requests(self):
    return _http_admin_requests.api_admin_requests(_HTTP_ENDPOINTS_ADMIN_REQUESTS_PORTS, self)


def api_admin_requests_update(self):
    return _http_admin_requests.api_admin_requests_update(_HTTP_ENDPOINTS_ADMIN_REQUESTS_PORTS, self)


_HTTP_ENDPOINTS_DOWNLOADS_PORTS = HttpEndpointsDownloadsPorts(
    get_jobs=lambda: JOBS,
    admin_sheet_download_name=_admin_sheet_download_name,
    apply_sell_pricing_to_quote=_apply_sell_pricing_to_quote,
    customer_name_from_job=_customer_name_from_job,
    extract_request_token=_extract_request_token,
    finalization_complete=_finalization_complete,
    linked_subjob_ids=_linked_subjob_ids,
    public_job_family_complete=_public_job_family_complete,
    read_job_access_token=_read_job_access_token,
    sealed_output_artifacts=_sealed_output_artifacts,
)


def api_job_file(self, job_id: str, rel: str, parsed=None, *, download_name_override: str | None = None):
    return _http_downloads.api_job_file(
        _HTTP_ENDPOINTS_DOWNLOADS_PORTS,
        self,
        job_id,
        rel,
        parsed,
        download_name_override=download_name_override,
    )


def api_stickertool_v2(self, subjob_id: str):
    return _http_downloads.api_stickertool_v2(_HTTP_ENDPOINTS_DOWNLOADS_PORTS, self, subjob_id)


def api_subjob_file(self, job_id: str, subjob_id: str, rel: str, parsed=None):
    return _http_downloads.api_subjob_file(
        _HTTP_ENDPOINTS_DOWNLOADS_PORTS, self, job_id, subjob_id, rel, parsed
    )


def api_download(self, job_id: str, fname: str, parsed=None):
    return _http_downloads.api_download(_HTTP_ENDPOINTS_DOWNLOADS_PORTS, self, job_id, fname, parsed)


_HTTP_ENDPOINTS_CONTROL_CENTER_PORTS = HttpEndpointsControlCenterPorts(
    get_dxf_manifest_path=lambda: DXF_MANIFEST_PATH,
    get_jobs=lambda: JOBS,
    get_material_library_path=lambda: MATERIAL_LIBRARY_PATH,
    get_optimizer_tool_b=lambda: OPTIMIZER_TOOL_B,
    get_pricing_active=lambda: PRICING_ACTIVE,
    dir_size_bytes=_dir_size_bytes,
    safe_json=_safe_json,
)


def _fmt_bytes(n: int):
    return _http_control_center._fmt_bytes(_HTTP_ENDPOINTS_CONTROL_CENTER_PORTS, n)


def api_admin_control_center(self):
    return _http_control_center.api_admin_control_center(_HTTP_ENDPOINTS_CONTROL_CENTER_PORTS, self)


from metod_app.runtime.composition import build_runtime_services as _build_runtime_services


_RUNTIME_SERVICES = _build_runtime_services(_COMPOSITION_PORTS)
_SUBMISSION_CLAIMS = _RUNTIME_SERVICES.submission_claims
_submission_marker_path: contracts.SubmissionMarkerPathCallback = _SUBMISSION_CLAIMS.marker_path
_read_submission_claim = _SUBMISSION_CLAIMS.read_claim
_reserve_submission_claim = _SUBMISSION_CLAIMS.reserve_claim
_SUBMISSION_SERVICE: contracts.SubmissionService = _RUNTIME_SERVICES.submission_service
_REQUEST_DOWNLOAD_PROJECTIONS: contracts.RequestDownloadProjectionService = (
    _RUNTIME_SERVICES.request_downloads
)

from metod_app.jobs import execution as _job_execution
from metod_app.runtime import worker as _queue_worker


_RUNTIME_WORKER_PORTS = RuntimeWorkerPorts(
    get_jobs=lambda: JOBS,
    get_queue_done=lambda: QUEUE_DONE,
    get_queue_failed=lambda: QUEUE_FAILED,
    get_queue_pending=lambda: QUEUE_PENDING,
    get_queue_processing=lambda: QUEUE_PROCESSING,
    get_worker_lock=lambda: WORKER_LOCK,
    append_system_event=_append_system_event,
    ensure_request_dirs=_ensure_request_dirs,
    get_fcntl=lambda: _fcntl,
    finalization_complete=_finalization_complete,
    guess_customer_name=_guess_customer_name,
    linked_subjob_ids=_linked_subjob_ids,
    load_status=_load_status,
    move_queue_file_safe=_move_queue_file_safe,
    save_status=_save_status,
    state_snapshot_is_active=_state_snapshot_is_active,
    run_backup_maintenance=run_backup_maintenance,
    run_queue_maintenance=run_queue_maintenance,
    run_retention_maintenance=run_retention_maintenance,
)


def _acquire_worker_lock() -> bool:
    return _queue_worker.acquire_worker_lock(_RUNTIME_WORKER_PORTS)


def _release_worker_lock() -> None:
    _queue_worker.release_worker_lock(_RUNTIME_WORKER_PORTS)


def _create_job_from_payload(
    payload: dict, master_job_id: str | None = None, public_access_token: str = ""
) -> dict:
    return _job_execution.create_job_from_payload(
        JobsExecutionPorts(
            get_jobs=lambda: JOBS,
            JobCancelledError=JobCancelledError,
            get_optimizer_tool_b=lambda: OPTIMIZER_TOOL_B,
            get_pricing_seed_path=lambda: PRICING_SEED_PATH,
            get_root=lambda: ROOT,
            get_job_finalization_service=lambda: _JOB_FINALIZATION_SERVICE,
            get_optimizer_process_supervisor=lambda: _OPTIMIZER_PROCESS_SUPERVISOR,
            atomic_write_json=_atomic_write_json,
            cached_sha256_file=_cached_sha256_file,
            enforce_job_output_limit=_enforce_job_output_limit,
            ensure_pricing_materials=_ensure_pricing_materials,
            filter_panels_csv_by_material=_filter_panels_csv_by_material,
            finalize_subjob_outputs=_finalize_subjob_outputs,
            get_python_base_cmd=_get_python_base_cmd,
            job_cancel_requested=_job_cancel_requested,
            get_job_lock=lambda: _job_lock,
            get_job_meta=lambda: _job_meta,
            link_or_copy_file=_link_or_copy_file,
            load_pricing_config=_load_pricing_config,
            now_iso=_now_iso,
            parse_panels_csv=_parse_panels_csv,
            register_job_process=_register_job_process,
            terminate_optimizer_process=_terminate_optimizer_process,
            unregister_job_process=_unregister_job_process,
            utc_now_iso=_utc_now_iso,
            validated_canonical_dxf_transport=_validated_canonical_dxf_transport,
            write_file=_write_file,
            write_master_job_links=_write_master_job_links,
            write_replaceable_json=_write_replaceable_json,
            write_replaceable_text=_write_replaceable_text,
        ),
        payload,
        master_job_id,
        public_access_token,
    )


def process_one_queue_item() -> bool:
    return _queue_worker.process_one_queue_item(_RUNTIME_WORKER_PORTS)


def _recover_processing_queue_items() -> dict:
    return _queue_worker.recover_processing_queue_items(_RUNTIME_WORKER_PORTS)


def worker_loop(poll_seconds: float = 1.0) -> None:
    _queue_worker.worker_loop(_RUNTIME_WORKER_PORTS, poll_seconds)


def _readiness_report() -> tuple[dict[str, Any], int]:
    return _OBSERVABILITY.readiness_report()


def _prometheus_metrics() -> str:
    return _OBSERVABILITY.prometheus_metrics()


from metod_app.runtime import startup as _startup_runtime


_RUNTIME_STARTUP_PORTS = RuntimeStartupPorts(
    replay_customer_erasure=lambda: _PRIVACY_SERVICE.replay(),
    get_host=lambda: HOST,
    Handler=Handler,
    get_jobs=lambda: JOBS,
    get_material_library_path=lambda: MATERIAL_LIBRARY_PATH,
    get_port=lambda: PORT,
    get_pricing_active=lambda: PRICING_ACTIVE,
    get_release_root=lambda: RELEASE_ROOT,
    get_root=lambda: ROOT,
    get_state_root=lambda: STATE_ROOT,
    get_system_dir=lambda: SYSTEM_DIR,
    admin_password_reset_activation_is_enabled=_admin_password_reset_activation_is_enabled,
    ensure_archive_dirs=_ensure_archive_dirs,
    ensure_request_dirs=_ensure_request_dirs,
    ensure_system_dirs=_ensure_system_dirs,
    get_admin_credentials_file_path=_get_admin_credentials_file_path,
    initialize_external_state=_initialize_external_state,
    is_password_hash_value=_is_password_hash_value,
    migrate_legacy_materials_to_direct_sell_prices=_migrate_legacy_materials_to_direct_sell_prices,
    normalized_admin_users=_normalized_admin_users,
    reconcile_archive_transactions=_reconcile_archive_transactions,
    reconcile_interrupted_jobs_on_startup=_reconcile_interrupted_jobs_on_startup,
    reconcile_public_job_idempotency_on_startup=_reconcile_public_job_idempotency_on_startup,
    server_maintenance_loop=_server_maintenance_loop,
    migrate_embedded_dxfs_to_categories=migrate_embedded_dxfs_to_categories,
    rebuild_embedded_dxfs_manifest=rebuild_embedded_dxfs_manifest,
    run_queue_maintenance=run_queue_maintenance,
    run_retention_maintenance=run_retention_maintenance,
    worker_loop=worker_loop,
)


def _validate_production_runtime_or_die() -> None:
    _startup_runtime.validate_production_runtime_or_die(_RUNTIME_STARTUP_PORTS)


def main() -> None:
    _startup_runtime.run_server(_RUNTIME_STARTUP_PORTS)


def run_worker() -> None:
    _startup_runtime.run_worker(_RUNTIME_STARTUP_PORTS)
