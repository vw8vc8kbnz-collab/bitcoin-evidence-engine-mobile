"""Pure validation and arithmetic for immutable job-pricing authority.

The live config/catalog are mutable administrative inputs.  A public job must
therefore carry one validated, content-addressed snapshot from admission through
execution, finalization and every later status projection.
"""

from __future__ import annotations


import copy
import hashlib
import hmac
import json
import math
import re
from datetime import datetime, timedelta, timezone
from typing import Any, Iterable, Mapping


PRICING_AUTHORITY_SCHEMA_VERSION = 2
LEGACY_PRICING_AUTHORITY_SCHEMA_VERSION = 1
from metod_app.pricing.tax import LEGACY_VAT_RATE

PRICING_MODEL = "catalog_sell_price_incl_vat_v2"
CATALOG_SIGNOFF_SCHEMA_VERSION = 2
ACTIVE_PRICING_SCHEMA_VERSION = 1
SELL_PRICING_FIELDS = (
    "edgeBandPricePerM",
    "cncCostPerSheet",
    "drawingCostFixed",
    "transportCostFixed",
)
PUBLIC_QUOTE_TOTAL_FIELDS = (
    "grandTotal",
    "total",
    "totalInclVat",
    "grandTotalInclVat",
    "sheetCount",
)


def _number(
    value: object,
    *,
    field: str,
    minimum: float = 0.0,
    maximum: float = 1_000_000.0,
) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{field} must be a JSON number")
    result = float(value)
    if not math.isfinite(result):
        raise ValueError(f"{field} must be finite")
    if result < minimum or result > maximum:
        raise ValueError(f"{field} is outside the allowed range")
    return result


def _canonical_bytes(value: object) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def validate_active_pricing_config(config: object) -> dict[str, Any]:
    """Return a defensive copy of one complete, strict active config.

    Numeric strings and booleans are deliberately rejected.  Normalization is
    allowed only *after* this check, so malformed Admin values can never turn
    into zero-cost production defaults.
    """

    if not isinstance(config, dict):
        raise ValueError("pricing config must be an object")
    pricing = config.get("pricing")
    sell = config.get("sellPricing")
    if not isinstance(pricing, dict):
        raise ValueError("missing or invalid 'pricing' object")
    if not isinstance(sell, dict):
        raise ValueError("missing or invalid 'sellPricing' object")
    if config.get("pricingModel") != PRICING_MODEL:
        raise ValueError("unsupported pricingModel")

    defaults = pricing.get("defaults")
    if not isinstance(defaults, dict):
        raise ValueError("pricing.defaults must be an object")
    for name in ("sheetMarginMm", "nestingGapMm", "kerfMm"):
        _number(defaults.get(name), field=f"pricing.defaults.{name}", maximum=100.0)
    rounding = defaults.get("rounding")
    if rounding is not None:
        if not isinstance(rounding, dict):
            raise ValueError("pricing.defaults.rounding must be an object")
        for name in ("moneyDecimals", "metersDecimals"):
            if name not in rounding:
                continue
            value = _number(
                rounding.get(name),
                field=f"pricing.defaults.rounding.{name}",
                maximum=6.0,
            )
            if not value.is_integer():
                raise ValueError(f"pricing.defaults.rounding.{name} must be an integer")

    currency = str(pricing.get("currency") or "").strip().upper()
    if not re.fullmatch(r"[A-Z]{3}", currency):
        raise ValueError("pricing.currency must be a three-letter code")
    if str(pricing.get("units") or "").strip().lower() != "mm":
        raise ValueError("pricing.units must be 'mm'")

    edge = pricing.get("edgeBanding")
    if not isinstance(edge, dict):
        raise ValueError("pricing.edgeBanding must be an object")
    _number(
        edge.get("defaultLossPercent"),
        field="pricing.edgeBanding.defaultLossPercent",
        maximum=100.0,
    )
    codes = edge.get("codes")
    if not isinstance(codes, list) or not codes:
        raise ValueError("pricing.edgeBanding.codes must be a non-empty array")
    seen_codes: set[int] = set()
    for index, item in enumerate(codes):
        if not isinstance(item, dict):
            raise ValueError(f"pricing.edgeBanding.codes[{index}] must be an object")
        code = _number(
            item.get("code"),
            field=f"pricing.edgeBanding.codes[{index}].code",
            minimum=1.0,
            maximum=999.0,
        )
        if not code.is_integer() or int(code) in seen_codes:
            raise ValueError("pricing.edgeBanding codes must be unique integers")
        seen_codes.add(int(code))
        _number(
            item.get("purchasePricePerUnit"),
            field=f"pricing.edgeBanding.codes[{index}].purchasePricePerUnit",
            maximum=100_000.0,
        )

    for name in SELL_PRICING_FIELDS:
        value = _number(sell.get(name), field=f"sellPricing.{name}")
        if value <= 0:
            raise ValueError(f"sellPricing.{name} must be greater than zero")

    materials = pricing.get("materials")
    if materials is not None and not isinstance(materials, list):
        raise ValueError("pricing.materials must be an array")
    return copy.deepcopy(config)


def canonical_pricing_sha256(config: object) -> str:
    """Hash the complete logical active-pricing document deterministically.

    The hash is deliberately based on validated canonical JSON rather than file
    bytes. Harmless indentation/key-order changes therefore do not revoke an
    approval, while every logical pricing mutation does.
    """

    validated = validate_active_pricing_config(config)
    return hashlib.sha256(_canonical_bytes(validated)).hexdigest()


def active_pricing_signoff_fields(config: object) -> dict[str, Any]:
    """Return the exact pricing identity that a catalog approval must bind."""

    validated = validate_active_pricing_config(config)
    pricing = validated["pricing"]
    raw_version = pricing.get("pricingVersion")
    if not isinstance(raw_version, str):
        raise ValueError("pricing.pricingVersion must be a string")
    pricing_version = raw_version.strip()
    if (
        not pricing_version
        or pricing_version != raw_version
        or len(pricing_version) > 80
        or any(ord(character) < 0x20 for character in pricing_version)
    ):
        raise ValueError("pricing.pricingVersion is invalid")
    return {
        "pricingCanonicalSha256": hashlib.sha256(_canonical_bytes(validated)).hexdigest(),
        "pricingSchemaVersion": ACTIVE_PRICING_SCHEMA_VERSION,
        "pricingModel": str(validated["pricingModel"]),
        "pricingVersion": pricing_version,
    }


def pricing_signoff_matches(signoff: object, active_config: object) -> bool:
    """Return whether an approved v2 signoff exactly binds active pricing."""

    if not isinstance(signoff, Mapping) or signoff.get("approved") is not True:
        return False
    schema_version = signoff.get("schemaVersion")
    pricing_schema_version = signoff.get("pricingSchemaVersion")
    if (
        isinstance(schema_version, bool)
        or schema_version != CATALOG_SIGNOFF_SCHEMA_VERSION
        or isinstance(pricing_schema_version, bool)
        or pricing_schema_version != ACTIVE_PRICING_SCHEMA_VERSION
    ):
        return False
    try:
        expected = active_pricing_signoff_fields(active_config)
    except (TypeError, ValueError):
        return False
    signed_hash = signoff.get("pricingCanonicalSha256")
    return bool(
        isinstance(signed_hash, str)
        and re.fullmatch(r"[a-f0-9]{64}", signed_hash)
        and hmac.compare_digest(signed_hash, expected["pricingCanonicalSha256"])
        and signoff.get("pricingModel") == expected["pricingModel"]
        and signoff.get("pricingVersion") == expected["pricingVersion"]
    )


def catalog_pricing_signoff_matches(
    signoff: object,
    active_config: object,
    *,
    material_library_sha256: object,
) -> bool:
    """Validate one complete production business approval.

    This is the single runtime/preflight contract for the catalog actor,
    approval timestamp and the exact catalog+pricing identities.  It accepts
    only the canonical UTC ``...Z`` timestamps emitted by the Admin publisher;
    coercing booleans, numbers or containers to display text would turn corrupt
    governance state into a false positive.
    """

    if not isinstance(signoff, Mapping) or signoff.get("approved") is not True:
        return False
    actor = signoff.get("approvedBy")
    approved_at = signoff.get("approvedAt")
    signed_library_hash = signoff.get("materialLibrarySha256")
    active_library_hash = material_library_sha256
    if (
        not isinstance(actor, str)
        or actor != actor.strip()
        or not actor
        or len(actor) > 120
        or any(ord(character) < 0x20 or ord(character) == 0x7F for character in actor)
        or not isinstance(approved_at, str)
        or approved_at != approved_at.strip()
        or not re.fullmatch(
            r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?Z",
            approved_at,
        )
        or not isinstance(signed_library_hash, str)
        or not re.fullmatch(r"[a-f0-9]{64}", signed_library_hash)
        or not isinstance(active_library_hash, str)
        or not re.fullmatch(r"[a-f0-9]{64}", active_library_hash)
    ):
        return False
    try:
        parsed_approval = datetime.fromisoformat(approved_at[:-1] + "+00:00")
    except ValueError:
        return False
    if (
        parsed_approval.tzinfo is None
        or parsed_approval.utcoffset() != timedelta(0)
        or parsed_approval.astimezone(timezone.utc).utcoffset() != timedelta(0)
    ):
        return False
    return bool(
        hmac.compare_digest(signed_library_hash, active_library_hash)
        and pricing_signoff_matches(signoff, active_config)
    )


def build_job_pricing_authority(
    *,
    active_config: Mapping[str, Any],
    authoritative_pricing: Mapping[str, Any],
    captured_at: str,
    vat_rate: float,
) -> dict[str, Any]:
    validated = validate_active_pricing_config(dict(active_config))
    captured_vat_rate = _number(vat_rate, field="vatRate", maximum=1.0)
    core = {
        "schemaVersion": PRICING_AUTHORITY_SCHEMA_VERSION,
        "pricingModel": PRICING_MODEL,
        "capturedAt": str(captured_at),
        "vatRate": captured_vat_rate,
        "pricing": copy.deepcopy(dict(authoritative_pricing)),
        "sellPricing": copy.deepcopy(validated["sellPricing"]),
    }
    # Reuse the full validator for the production defaults/edge contract while
    # accepting the catalog-enriched material array in the job copy.
    validate_active_pricing_config(
        {
            "pricingModel": PRICING_MODEL,
            "pricing": core["pricing"],
            "sellPricing": core["sellPricing"],
        }
    )
    return {
        **core,
        "authoritySha256": hashlib.sha256(_canonical_bytes(core)).hexdigest(),
    }


def validate_job_pricing_authority(
    authority: object,
    *,
    panel_rows: Iterable[Mapping[str, Any]],
) -> tuple[dict[str, Any], dict[str, float]]:
    if not isinstance(authority, dict):
        raise ValueError("job pricing authority is missing")
    schema_version = authority.get("schemaVersion")
    if schema_version not in {
        LEGACY_PRICING_AUTHORITY_SCHEMA_VERSION,
        PRICING_AUTHORITY_SCHEMA_VERSION,
    }:
        raise ValueError("unsupported job pricing authority schema")
    core = {
        "schemaVersion": schema_version,
        "pricingModel": authority.get("pricingModel"),
        "capturedAt": authority.get("capturedAt"),
    }
    if schema_version == PRICING_AUTHORITY_SCHEMA_VERSION:
        core["vatRate"] = authority.get("vatRate")
    core.update(
        {
            "pricing": authority.get("pricing"),
            "sellPricing": authority.get("sellPricing"),
        }
    )
    if str(core["pricingModel"] or "") != PRICING_MODEL:
        raise ValueError("unsupported job pricing model")
    expected = str(authority.get("authoritySha256") or "")
    actual = hashlib.sha256(_canonical_bytes(core)).hexdigest()
    if not re.fullmatch(r"[a-f0-9]{64}", expected) or not hmac.compare_digest(expected, actual):
        raise ValueError("job pricing authority hash mismatch")
    vat_rate = (
        _number(core.get("vatRate"), field="vatRate", maximum=1.0)
        if schema_version == PRICING_AUTHORITY_SCHEMA_VERSION
        else LEGACY_VAT_RATE
    )

    validated = validate_active_pricing_config(
        {
            "pricingModel": PRICING_MODEL,
            "pricing": core["pricing"],
            "sellPricing": core["sellPricing"],
        }
    )
    pricing = validated["pricing"]
    sell = {
        name: _number(
            validated["sellPricing"].get(name),
            field=f"sellPricing.{name}",
        )
        for name in SELL_PRICING_FIELDS
    }

    materials = pricing.get("materials")
    if not isinstance(materials, list) or not materials:
        raise ValueError("job pricing authority has no materials")
    by_code: dict[str, dict[str, Any]] = {}
    for index, material in enumerate(materials):
        if not isinstance(material, dict):
            raise ValueError(f"pricing.materials[{index}] must be an object")
        code = str(material.get("materialCode") or "").strip()
        if not code or code in by_code:
            raise ValueError("job pricing material codes must be non-empty and unique")
        public_id = str(material.get("publicMaterialId") or "").strip().lower()
        if schema_version == PRICING_AUTHORITY_SCHEMA_VERSION:
            if not re.fullmatch(r"decor_[a-f0-9]{20,40}", public_id):
                raise ValueError(f"pricing.materials[{index}].publicMaterialId is invalid")
            display_name = str(material.get("decorName") or "").strip()
            if not display_name or len(display_name) > 240:
                raise ValueError(f"pricing.materials[{index}].decorName is invalid")
        _number(
            material.get("thicknessMm"),
            field=f"pricing.materials[{index}].thicknessMm",
            minimum=0.1,
            maximum=100.0,
        )
        size = material.get("sheetSizeMm")
        if not isinstance(size, dict):
            raise ValueError(f"pricing.materials[{index}].sheetSizeMm must be an object")
        _number(
            size.get("width"),
            field=f"pricing.materials[{index}].sheetSizeMm.width",
            minimum=1.0,
            maximum=100_000.0,
        )
        _number(
            size.get("height"),
            field=f"pricing.materials[{index}].sheetSizeMm.height",
            minimum=1.0,
            maximum=100_000.0,
        )
        _number(
            material.get("sellPriceInclVatPerSheet"),
            field=f"pricing.materials[{index}].sellPriceInclVatPerSheet",
            minimum=0.01,
        )
        _number(
            material.get("sellPriceExVatPerSheet"),
            field=f"pricing.materials[{index}].sellPriceExVatPerSheet",
            minimum=0.01,
        )
        _number(
            material.get("purchasePricePerSheet"),
            field=f"pricing.materials[{index}].purchasePricePerSheet",
            minimum=0.01,
        )
        material_vat_rate = material.get("priceVatRate")
        if material_vat_rate is not None:
            material_vat_rate = _number(
                material_vat_rate,
                field=f"pricing.materials[{index}].priceVatRate",
                maximum=1.0,
            )
            if abs(material_vat_rate - vat_rate) > 1e-12:
                raise ValueError(f"pricing.materials[{index}].priceVatRate mismatch")
        by_code[code] = material

    used_codes: set[str] = set()
    for row in panel_rows:
        code = str((row or {}).get("MaterialCode") or "").strip()
        if not code or code not in by_code:
            raise ValueError(f"job pricing authority misses material {code or '?'}")
        used_codes.add(code)
        row_thickness = _number(
            (row or {}).get("ThicknessMm"),
            field=f"{(row or {}).get('PartId') or code}.ThicknessMm",
            minimum=0.1,
            maximum=100.0,
        )
        material_thickness = float(by_code[code]["thicknessMm"])
        if abs(row_thickness - material_thickness) > 1e-9:
            raise ValueError(f"job pricing authority thickness mismatch for {code}")
    if not used_codes:
        raise ValueError("job pricing authority has no used materials")
    if set(by_code) != used_codes:
        # Admission stores only the material records used by the job.  Rejecting
        # extras makes the snapshot/hash meaning narrow and auditable.
        raise ValueError("job pricing authority contains unused materials")
    pricing_snapshot = copy.deepcopy(pricing)
    pricing_snapshot["vatRate"] = vat_rate
    return pricing_snapshot, sell


def aggregate_sell_priced_quotes(
    quotes: Iterable[Mapping[str, Any]],
    *,
    vat_rate: float,
) -> dict[str, Any]:
    """Aggregate already-priced material quotes and charge fixed costs once."""

    from .amounts import charge, mixed_vat_totals

    rows = [copy.deepcopy(dict(item)) for item in quotes if isinstance(item, Mapping)]
    if not rows:
        return {}
    rate = _number(vat_rate, field="vat_rate", maximum=1.0)
    currency = str(rows[0].get("currency") or "EUR")
    materials: list[dict[str, Any]] = []
    material_ex = material_inc = edge_total = cnc_total = 0.0
    exact_edge_meters = 0.0
    exact_edge_price: float | None = None
    exact_edge_available = True
    sheet_count = 0
    for quote in rows:
        totals = quote.get("totals") if isinstance(quote.get("totals"), dict) else {}
        material_ex += float(totals.get("sheetCostTotalExVat") or totals.get("sheetCostTotal") or 0.0)
        material_inc += float(totals.get("sheetCostTotalInclVat") or 0.0)
        edge_total += float(totals.get("edgeCostTotal") or 0.0)
        cnc_total += float(totals.get("cncCostTotal") or 0.0)
        edge = quote.get("edgeBanding") if isinstance(quote.get("edgeBanding"), Mapping) else {}
        exact_map = (
            edge.get("byCodeMetersWithLossExact")
            if isinstance(edge.get("byCodeMetersWithLossExact"), Mapping)
            else None
        )
        sell = quote.get("sellPricing") if isinstance(quote.get("sellPricing"), Mapping) else {}
        if exact_map is None or sell.get("edgeBandPricePerM") is None:
            exact_edge_available = False
        else:
            price = _number(
                sell.get("edgeBandPricePerM"),
                field="sellPricing.edgeBandPricePerM",
            )
            if exact_edge_price is None:
                exact_edge_price = price
            elif abs(exact_edge_price - price) > 1e-12:
                raise ValueError("subjob edge-band sell prices differ")
            for raw_meters in exact_map.values():
                exact_edge_meters += _number(
                    raw_meters,
                    field="edgeBanding.byCodeMetersWithLossExact",
                    maximum=10_000_000.0,
                )
        for material in quote.get("materials") or []:
            if not isinstance(material, dict):
                continue
            materials.append(copy.deepcopy(material))
            sheet_count += int(material.get("sheetCount") or 0)

    first_totals = rows[0].get("totals") if isinstance(rows[0].get("totals"), dict) else {}
    drawing_total = float(first_totals.get("drawingCostTotal") or 0.0)
    transport_total = float(first_totals.get("transportCostTotal") or 0.0)
    if exact_edge_available and exact_edge_price is not None:
        edge_total = charge(exact_edge_meters, exact_edge_price)
    totals = mixed_vat_totals(
        material_ex=material_ex,
        material_inc=material_inc,
        edge=edge_total,
        cnc=cnc_total,
        drawing=drawing_total,
        transport=transport_total,
        vat_rate=rate,
        sheet_count=sheet_count,
    )
    subtotal_ex = totals["subtotalExVat"]
    total_inc = totals["totalInclVat"]
    return {
        "pricingModel": PRICING_MODEL,
        "currency": currency,
        "materials": materials,
        "totals": totals,
        "grandTotal": subtotal_ex,
        "totalInclVat": total_inc,
        "grandTotalInclVat": total_inc,
        "sheetCount": sheet_count,
    }


def public_subjob_quote_projection(
    subjob_id: object,
    quote: Mapping[str, Any],
    *,
    include_fixed_costs: bool = True,
    vat_rate: float = LEGACY_VAT_RATE,
) -> dict[str, Any]:
    """Return a narrow subjob view with order-fixed costs allocated once.

    Tool B prices each material invocation as if it were a complete order. The
    first deterministic subjob carries drawing/transport; later projections do
    not. This preserves the legacy ``perSubjob`` shape without suggesting those
    fixed costs are charged multiple times.
    """

    from .amounts import mixed_vat_totals

    identifier = str(subjob_id or "").strip()
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}", identifier):
        raise ValueError("invalid subjob id")
    currency = str(quote.get("currency") or "EUR").strip().upper()
    if not re.fullmatch(r"[A-Z]{3}", currency):
        currency = "EUR"
    totals_source = quote.get("totals")
    totals_source = totals_source if isinstance(totals_source, Mapping) else {}
    rate = _number(vat_rate, field="vat_rate", maximum=1.0)

    sheet_count_value = quote.get("sheetCount")
    if sheet_count_value is None:
        sheet_count_value = totals_source.get("sheetCount")
    if sheet_count_value is None:
        derived_sheet_count = 0
        for material in quote.get("materials") or []:
            if not isinstance(material, Mapping):
                continue
            count = _number(
                material.get("sheetCount") or 0,
                field="materials.sheetCount",
                maximum=1_000_000.0,
            )
            if not count.is_integer():
                raise ValueError("materials.sheetCount must be an integer")
            derived_sheet_count += int(count)
        sheet_count_value = derived_sheet_count

    component_fields = {
        "sheetCostTotalExVat",
        "sheetCostTotal",
        "sheetCostTotalInclVat",
        "edgeCostTotal",
        "cncCostTotal",
        "drawingCostTotal",
        "transportCostTotal",
    }
    has_components = any(name in totals_source for name in component_fields)
    if has_components:

        def component(name: str, *fallbacks: str) -> float:
            for candidate in (name, *fallbacks):
                if totals_source.get(candidate) is not None:
                    return _number(
                        totals_source.get(candidate),
                        field=f"totals.{candidate}",
                        maximum=1_000_000_000_000.0,
                    )
            return 0.0

        material_ex = component("sheetCostTotalExVat", "sheetCostTotal")
        material_inc = component("sheetCostTotalInclVat")
        if material_inc <= 0.0 and material_ex > 0.0:
            material_inc = round(material_ex * (1.0 + rate) + 1e-9, 2)
        edge_total = component("edgeCostTotal")
        cnc_total = component("cncCostTotal")
        drawing_total = component("drawingCostTotal") if include_fixed_costs else 0.0
        transport_total = component("transportCostTotal") if include_fixed_costs else 0.0
        amount_totals = mixed_vat_totals(
            material_ex=material_ex,
            material_inc=material_inc,
            edge=edge_total,
            cnc=cnc_total,
            drawing=drawing_total,
            transport=transport_total,
            vat_rate=rate,
        )
        subtotal_ex = amount_totals["subtotalExVat"]
        total_inc = amount_totals["totalInclVat"]
        count = _number(sheet_count_value or 0, field="sheetCount")
        if not count.is_integer():
            raise ValueError("sheetCount must be an integer")
        totals = {
            "grandTotal": subtotal_ex,
            "totalInclVat": total_inc,
            "grandTotalInclVat": total_inc,
            "sheetCount": int(count),
        }
        return {
            "subjobId": identifier,
            "currency": currency,
            "totals": totals,
            "grandTotal": subtotal_ex,
            "sheetCount": int(count),
        }

    totals: dict[str, Any] = {}
    for name in PUBLIC_QUOTE_TOTAL_FIELDS:
        if totals_source.get(name) is None:
            continue
        value = _number(
            totals_source.get(name),
            field=f"totals.{name}",
            maximum=1_000_000.0 if name == "sheetCount" else 1_000_000_000_000.0,
        )
        totals[name] = int(value) if name == "sheetCount" else value
    grand_total = quote.get("grandTotal")
    if grand_total is None:
        grand_total = totals.get("grandTotal")
    sheet_count = sheet_count_value
    projection: dict[str, Any] = {
        "subjobId": identifier,
        "currency": currency,
        "totals": totals,
    }
    if grand_total is not None:
        projection["grandTotal"] = _number(grand_total, field="grandTotal", maximum=1_000_000_000_000.0)
    if sheet_count is not None:
        count = _number(sheet_count, field="sheetCount")
        if not count.is_integer():
            raise ValueError("sheetCount must be an integer")
        projection["sheetCount"] = int(count)
    return projection


def edge_band_sell_total(
    raw_meters: float,
    *,
    loss_percent: float,
    price_per_meter: float,
) -> tuple[float, float]:
    from .amounts import charge

    raw = _number(raw_meters, field="edgeBanding.rawMeters", maximum=10_000_000.0)
    loss = _number(loss_percent, field="edgeBanding.defaultLossPercent", maximum=100.0)
    price = _number(price_per_meter, field="sellPricing.edgeBandPricePerM")
    with_loss = raw * (1.0 + loss / 100.0)
    return with_loss, charge(with_loss, price)


__all__ = (
    "ACTIVE_PRICING_SCHEMA_VERSION",
    "CATALOG_SIGNOFF_SCHEMA_VERSION",
    "LEGACY_PRICING_AUTHORITY_SCHEMA_VERSION",
    "LEGACY_VAT_RATE",
    "PRICING_AUTHORITY_SCHEMA_VERSION",
    "PRICING_MODEL",
    "SELL_PRICING_FIELDS",
    "aggregate_sell_priced_quotes",
    "active_pricing_signoff_fields",
    "build_job_pricing_authority",
    "catalog_pricing_signoff_matches",
    "canonical_pricing_sha256",
    "edge_band_sell_total",
    "public_subjob_quote_projection",
    "pricing_signoff_matches",
    "validate_active_pricing_config",
    "validate_job_pricing_authority",
)
