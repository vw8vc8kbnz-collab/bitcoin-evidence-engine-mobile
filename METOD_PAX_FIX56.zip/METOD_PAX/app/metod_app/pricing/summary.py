"""Read machine-readable calculation authority, with sealed legacy TXT support."""

from __future__ import annotations


import hashlib
import hmac
import math
from safety_contracts import strict_json_load, strict_json_loads


def read_calculation_pricing(job_root, legacy_reader) -> dict:
    try:
        return _read_calculation_pricing(job_root, legacy_reader)
    except (OSError, ValueError, TypeError, AttributeError, KeyError):
        return {}


def _read_calculation_pricing(job_root, legacy_reader) -> dict:
    output = job_root / "output"
    path = output / "calculation_pricing.json"
    final_path = output / "finalization.json"
    finalization = strict_json_load(final_path) if final_path.is_file() else {}
    hashes = finalization.get("artifactsSha256") or {}
    uses_structured = (
        path.exists()
        or "calculation_pricing.json" in hashes
        or int(finalization.get("schemaVersion") or 0) >= 3
    )
    if not uses_structured:
        return legacy_reader(job_root)
    # Never downgrade a new calculation to parsing the TXT when its structured
    # amount is missing, unsealed or corrupt.
    if finalization.get("state") != "COMPLETE":
        return {}
    expected = str(hashes.get("calculation_pricing.json") or "")
    data = path.read_bytes()
    if not expected or not hmac.compare_digest(hashlib.sha256(data).hexdigest(), expected):
        return {}
    value = strict_json_loads(data)
    if value.get("schemaVersion") != 1 or value.get("jobId") != job_root.name:
        return {}
    summary = value.get("summary")
    if not isinstance(summary, dict):
        return {}
    required = (
        "materialsTotal",
        "materialsTotalInclVat",
        "materialsVatIncluded",
        "edgeBandTotal",
        "cncTotal",
        "drawingTotal",
        "transportTotal",
        "otherCostsExVat",
        "otherCostsVat",
        "subtotalExVat",
        "vatAmount",
        "totalInclVat",
    )
    if any(
        isinstance(summary.get(key), bool)
        or not isinstance(summary.get(key), (int, float))
        or not math.isfinite(summary[key])
        or summary[key] < 0
        for key in required
    ):
        return {}
    return dict(summary)
