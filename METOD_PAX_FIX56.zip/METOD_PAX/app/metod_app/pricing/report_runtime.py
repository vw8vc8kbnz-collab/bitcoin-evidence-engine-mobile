"""Create sealed reports from captured input and completed optimizer output only.

Historical sealed reports are read by pricing.summary; this writer never
reconstructs an old order from current Admin settings or customer-supplied prices.
"""

from __future__ import annotations

from pathlib import Path

from safety_contracts import durable_write_json, durable_write_text, strict_json_load, validate_job_id
from metod_app.requests.projections import customer_block_from_sources
from metod_app.runtime.ports import PricingReportRuntimePorts
from .amounts import summary_from_totals
from .quote import price_quote


def _object(path):
    value = strict_json_load(path)
    if not isinstance(value, dict):
        raise ValueError("Calculation source must be a JSON object")
    return value


def _quote_materials(job_root):
    own = job_root / "output/quote.json"
    if "__mat_" in job_root.name:
        return _object(own)["materials"]
    links = _object(job_root / "output/links.json")
    materials = []
    subjobs = links.get("subjobs")
    if not isinstance(subjobs, list) or not subjobs or len(subjobs) > 1000:
        raise ValueError("Master calculation requires bounded material links")
    seen = set()
    for item in subjobs:
        value = item.get("jobId") or item.get("subjobId")
        job_id = validate_job_id(value)
        if not job_id.startswith(job_root.name + "__mat_") or job_id in seen:
            raise ValueError("Invalid or repeated material job link")
        seen.add(job_id)
        subroot = job_root.parent / job_id
        if subroot.is_symlink():
            raise ValueError("Unsafe material job link")
        materials.extend(_object(subroot / "output/quote.json")["materials"])
    return materials


def _panel_metrics(rows):
    meters, quantity = {}, 0
    for row in rows:
        code = str(row["MaterialCode"]).strip()
        count = int(row["Qty"])
        quantity += count
        dimensions = {
            "H1": float(row["LengthMm"]),
            "H2": float(row["LengthMm"]),
            "W1": float(row["WidthMm"]),
            "W2": float(row["WidthMm"]),
        }
        edge = sum(dimension for key, dimension in dimensions.items() if int(row.get(key) or 0) != 0)
        meters[code] = meters.get(code, 0.0) + edge * count / 1000.0
    return quantity, meters


def _priced_report(pricing, materials, meters, *, include_fixed):
    metadata = {str(material["materialCode"]): material for material in pricing["materials"]}
    captured = []
    for material in materials:
        code = str(material["materialCode"])
        if code not in metadata:
            raise ValueError("Optimizer material is missing from the captured price snapshot")
        captured.append({**material, **metadata[code], "sheetCount": int(material["sheetCount"])})
    loss = float((pricing.get("edgeBanding") or {}).get("defaultLossPercent") or 0)
    exact_edge = {code: value * (1 + loss / 100.0) for code, value in meters.items()}
    priced = price_quote(
        {
            "currency": pricing.get("currency") or "EUR",
            "materials": captured,
            "edgeBanding": {"byCodeMetersWithLossExact": exact_edge},
        },
        sell_pricing=pricing["sellPricing"],
        vat_rate=pricing["vatRate"],
        include_fixed_costs=include_fixed,
    )
    return priced, metadata, loss


class PricingReportRuntime:
    def __init__(self, ports: PricingReportRuntimePorts):
        self._ports = ports

    def _material_lines(self, materials, metadata, vat_rate):
        lines = [
            "Materialen / platen",
            "-" * 40,
            f"Materiaalprijs: directe CSV-verkoopprijs per plaat, inclusief {vat_rate * 100:g}% BTW",
            "",
        ]
        for material in materials:
            code = str(material["materialCode"])
            meta = metadata[code]
            name = self._ports.best_material_name(
                code, meta.get("productName"), meta.get("decorName"), meta.get("name")
            )
            size = material.get("sheetSizeMm") or {}
            dimensions = ""
            if size.get("width") and size.get("height"):
                dimensions = f" | Plaatmaat: {int(size['width'])}×{int(size['height'])} mm"
            lines.extend(
                [
                    f"- {name} (artikel: {meta.get('articleNumber') or code})",
                    f"  Dikte: {material.get('thicknessMm', '')} mm | Platen: {material['sheetCount']}{dimensions}",
                    f"  Verkoopprijs plaat incl. btw: {self._ports.format_eur(material['sheetUnitSellPriceInclVat'])} p/st"
                    if "sheetUnitSellPriceInclVat" in material
                    else f"  Verkoopprijs plaat incl. btw: {self._ports.format_eur(meta['sellPriceInclVatPerSheet'])} p/st",
                    f"  Subtotaal plaatmateriaal incl. btw: {self._ports.format_eur(material['sheetCostTotalInclVat'])}",
                    "",
                ]
            )
        return lines

    def _edge_lines(self, meters, metadata, pricing, loss):
        lines = ["Kantenband (m¹) per decor", "-" * 40]
        for code, value in sorted(meters.items()):
            if value:
                name = self._ports.best_material_name(
                    code, metadata[code].get("productName"), metadata[code].get("decorName")
                )
                lines.append(f"- {name} (artikel: {code}): {self._ports.format_m(value)}")
        total = sum(meters.values())
        lines.extend(
            [
                "",
                f"Totaal kantenband: {self._ports.format_m(total)}",
                f"Berekenbare lengte incl. {loss:g}% verlies: {self._ports.format_m(total * (1 + loss / 100.0))}",
                f"Prijs kantenband: {self._ports.format_eur(pricing['sellPricing']['edgeBandPricePerM'])} per meter",
                "",
            ]
        )
        return lines

    def _cost_lines(self, summary, vat_rate):
        lines = ["Kostenopbouw (exclusief BTW)", "-" * 40]
        for key, label in (
            ("materialsTotal", "Plaatmateriaal netto-equivalent"),
            ("edgeBandTotal", "Kantenband excl. btw"),
            ("cncTotal", "CNC excl. btw"),
            ("drawingTotal", "Tekenen excl. btw"),
            ("transportTotal", "Transport excl. btw"),
            ("subtotalExVat", "Subtotaal excl. btw"),
        ):
            lines.append(f"{label}: {self._ports.format_eur(summary[key])}")
        lines.extend(
            [
                "",
                f"BTW ({vat_rate * 100:g}%): {self._ports.format_eur(summary['vatAmount'])}",
                f"Totaal incl. btw: {self._ports.format_eur(summary['totalInclVat'])}",
                "",
                "Fiscale uitsplitsing",
                "-" * 40,
            ]
        )
        for key, label in (
            ("materialsTotalInclVat", "Plaatmateriaal incl. btw"),
            ("materialsVatIncluded", "BTW reeds in plaatprijs"),
            ("otherCostsExVat", "Overige kosten excl. btw"),
            ("otherCostsVat", "BTW over overige kosten"),
        ):
            lines.append(f"{label}: {self._ports.format_eur(summary[key])}")
        return lines

    def _write_human_calculation_summary(self, job_root: Path, request_status: dict | None = None) -> None:
        pricing = _object(job_root / "input/pricing.json")
        customer = _object(job_root / "input/job.json")
        rows = self._ports.parse_panels_csv((job_root / "input/panels.csv").read_text())
        quantity, meters = _panel_metrics(rows)
        suffix = job_root.name.split("__mat_", 1)
        include_fixed = len(suffix) == 1 or suffix[1] == "001"
        priced, metadata, loss = _priced_report(
            pricing, _quote_materials(job_root), meters, include_fixed=include_fixed
        )
        summary = summary_from_totals(priced["totals"], currency=priced["currency"])
        if isinstance(customer.get("rest_material"), dict):
            customer = {**customer, "restCarry": customer["rest_material"].get("carry_out") is True}
        lines = ["METOD One-Click – Berekeningsoverzicht", "=" * 40, f"Job: {job_root.name}", ""]
        lines.extend(customer_block_from_sources({}, customer))
        lines.extend(
            [
                "Configuratie",
                "-" * 40,
                f"Aantal panelen: {quantity}",
                f"Aantal platen: {priced['sheetCount']}",
                "",
            ]
        )
        lines.extend(self._material_lines(priced["materials"], metadata, pricing["vatRate"]))
        lines.extend(self._edge_lines(meters, metadata, pricing, loss))
        lines.extend(self._cost_lines(summary, pricing["vatRate"]))
        output = job_root / "output"
        durable_write_json(
            output / "calculation_pricing.json",
            {
                "schemaVersion": 1,
                "jobId": job_root.name,
                "pricingModel": "catalog_sell_price_incl_vat_v2",
                "roundingPolicy": "DECIMAL_HALF_UP_CENTS",
                "vatRate": pricing["vatRate"],
                "summary": summary,
            },
        )
        durable_write_text(output / "calculation_summary.txt", "\n".join(lines).strip() + "\n")

    EXPORTS = ("_write_human_calculation_summary",)


__all__ = ("PricingReportRuntime",)
