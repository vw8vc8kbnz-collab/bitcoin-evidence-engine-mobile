"""VAT defaults; sealed orders always retain their recorded rate."""

VAT_RATE = 0.21
LEGACY_VAT_RATE = 0.21
