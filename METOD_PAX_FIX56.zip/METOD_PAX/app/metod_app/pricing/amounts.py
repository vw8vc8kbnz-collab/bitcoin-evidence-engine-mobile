"""Canonical EUR arithmetic: decimal half-up to cents at each charge boundary.

CSV material gross cents remain exact. The material net equivalent is rounded
per material line. Admin charges are ex VAT; their summed rounded amount gets
one VAT rounding for the order, including drawing and transport exactly once.
"""

from __future__ import annotations


from decimal import Decimal, ROUND_HALF_UP
from typing import Any

CENT = Decimal("0.01")


def money(value: Any) -> float:
    amount = Decimal(str(value))
    if not amount.is_finite():
        raise ValueError("money must be finite")
    return float(amount.quantize(CENT, rounding=ROUND_HALF_UP))


def charge(amount: float, unit_price: float) -> float:
    return money(Decimal(str(amount)) * Decimal(str(unit_price)))


def material_net(gross: float, vat_rate: float) -> float:
    return money(Decimal(str(gross)) / (Decimal(1) + Decimal(str(vat_rate))))


def mixed_vat_totals(
    *,
    material_ex: float,
    material_inc: float,
    edge: float,
    cnc: float,
    drawing: float,
    transport: float,
    vat_rate: float,
    sheet_count: int = 0,
) -> dict:
    charges = {
        "sheetCostTotalExVat": money(material_ex),
        "sheetCostTotalInclVat": money(material_inc),
        "edgeCostTotal": money(edge),
        "cncCostTotal": money(cnc),
        "drawingCostTotal": money(drawing),
        "transportCostTotal": money(transport),
    }
    net = Decimal(str(charges["sheetCostTotalExVat"]))
    gross = Decimal(str(charges["sheetCostTotalInclVat"]))
    other = sum(
        (
            Decimal(str(charges[key]))
            for key in ("edgeCostTotal", "cncCostTotal", "drawingCostTotal", "transportCostTotal")
        ),
        Decimal(0),
    )
    other_vat = Decimal(str(money(other * Decimal(str(vat_rate)))))
    subtotal = money(net + other)
    total = money(gross + other + other_vat)
    return {
        **charges,
        "sheetCostTotal": float(net),
        "otherCostsExVat": float(other),
        "materialVatIncluded": money(gross - net),
        "otherCostsVat": float(other_vat),
        "subtotalExVat": subtotal,
        "vatAmount": money(Decimal(str(total)) - Decimal(str(subtotal))),
        "grandTotal": subtotal,
        "totalInclVat": total,
        "grandTotalInclVat": total,
        "sheetCount": int(sheet_count),
    }


def summary_from_totals(totals: dict, *, currency: str = "EUR") -> dict:
    mapping = {
        "materialsTotal": "sheetCostTotalExVat",
        "materialsTotalInclVat": "sheetCostTotalInclVat",
        "materialsVatIncluded": "materialVatIncluded",
        "edgeBandTotal": "edgeCostTotal",
        "cncTotal": "cncCostTotal",
        "drawingTotal": "drawingCostTotal",
        "transportTotal": "transportCostTotal",
        "otherCostsExVat": "otherCostsExVat",
        "otherCostsVat": "otherCostsVat",
        "subtotalExVat": "subtotalExVat",
        "vatAmount": "vatAmount",
        "totalInclVat": "totalInclVat",
    }
    return {**{key: totals[value] for key, value in mapping.items()}, "currency": currency}
