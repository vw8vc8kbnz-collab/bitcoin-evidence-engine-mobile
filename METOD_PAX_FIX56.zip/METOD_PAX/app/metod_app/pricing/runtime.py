"""Bounded PricingRuntime implementation with explicit ports injection."""

from __future__ import annotations

from typing import Any

from metod_app.observability.failures import report_recovery

from catalog_importer import ALLOWED_THICKNESSES_MM as CATALOG_ALLOWED_THICKNESSES_MM
from catalog_importer import VAT_RATE as CATALOG_VAT_RATE
from pathlib import Path
from safety_contracts import ContractError as SafetyContractError
from metod_app.config import env_int as _env_int
from metod_app.config import production_hardening_enabled as _is_production_hardening_enabled
from metod_app.pricing.contracts import material_direct_sell_incl_vat as _material_direct_sell_incl_vat
from pricing_helpers import (
    aggregate_materials_from_subjob_quotes as _pricing_aggregate_materials_from_subjob_quotes,
)
from pricing_helpers import parse_calculation_summary_totals as _pricing_parse_calculation_summary_totals
from safety_contracts import append_jsonl_rotating
from datetime import datetime
from safety_contracts import durable_write_json
from safety_contracts import finite_number
import math
import os
import re
import secrets
from safety_contracts import sha256_file
from safety_contracts import strict_json_dumps
from safety_contracts import strict_json_load
from safety_contracts import strict_json_loads
from datetime import timezone
from metod_app.runtime.ports import PricingRuntimePorts

from metod_app.storage.catalog_publication import catalog_guarded


from metod_app.catalog.public_identity import public_material_name
from .quote import price_quote

from .authority import (
    CATALOG_SIGNOFF_SCHEMA_VERSION,
    active_pricing_signoff_fields,
    build_job_pricing_authority,
    catalog_pricing_signoff_matches,
    canonical_pricing_sha256,
    validate_active_pricing_config,
)


class PricingRevisionConflict(ValueError):
    """A concurrent Admin edit changed the document since this editor loaded it."""


class PricingRuntime:
    def __init__(self, ports: PricingRuntimePorts):
        self._ports = ports
        self._catalog_publication = ports.catalog

    def _default_pricing_config(_owner) -> dict:
        ports = _owner._ports
        CNC_COST_PER_SHEET = ports.get_cnc_cost_per_sheet()
        DRAWING_COST_FIXED = ports.get_drawing_cost_fixed()
        EDGE_BAND_PRICE_PER_M = ports.get_edge_band_price_per_m()
        PRICING_SEED_PATH = ports.get_pricing_seed_path()
        TRANSPORT_COST_FIXED = ports.get_transport_cost_fixed()

        base = strict_json_load(PRICING_SEED_PATH)
        return {
            "pricing": base,
            "pricingModel": "catalog_sell_price_incl_vat_v2",
            "sellPricing": {
                "edgeBandPricePerM": EDGE_BAND_PRICE_PER_M,
                "cncCostPerSheet": CNC_COST_PER_SHEET,
                "drawingCostFixed": DRAWING_COST_FIXED,
                "transportCostFixed": TRANSPORT_COST_FIXED,
            },
        }

    def _normalize_pricing_config_schema(_owner, cfg: dict) -> dict:
        """Normalize legacy pricing config without reintroducing a material factor."""
        ports = _owner._ports
        CNC_COST_PER_SHEET = ports.get_cnc_cost_per_sheet()
        DRAWING_COST_FIXED = ports.get_drawing_cost_fixed()
        EDGE_BAND_PRICE_PER_M = ports.get_edge_band_price_per_m()
        TRANSPORT_COST_FIXED = ports.get_transport_cost_fixed()
        _default_pricing_config = _owner._default_pricing_config

        if not isinstance(cfg, dict):
            cfg = _default_pricing_config()
        out = strict_json_loads(strict_json_dumps(cfg))
        if not isinstance(out.get("pricing"), dict):
            out["pricing"] = _default_pricing_config()["pricing"]
        sp = out.get("sellPricing") if isinstance(out.get("sellPricing"), dict) else {}
        # sheetPriceFactor is deliberately removed from the active model. Existing material
        # values are migrated once to fixed per-material sell prices before the server starts.
        sp.pop("sheetPriceFactor", None)
        for key, default in (
            ("edgeBandPricePerM", EDGE_BAND_PRICE_PER_M),
            ("cncCostPerSheet", CNC_COST_PER_SHEET),
            ("drawingCostFixed", DRAWING_COST_FIXED),
            ("transportCostFixed", TRANSPORT_COST_FIXED),
        ):
            try:
                sp[key] = float(sp.get(key, default))
            except (ValueError, TypeError, OverflowError):
                sp[key] = float(default)
        out["sellPricing"] = sp
        out["pricingModel"] = "catalog_sell_price_incl_vat_v2"
        return out

    def _load_pricing_config(_owner) -> dict:
        ports = _owner._ports
        PRICING_ACTIVE = ports.get_pricing_active()
        _default_pricing_config = _owner._default_pricing_config
        _ensure_pricing_config_files = _owner._ensure_pricing_config_files
        _normalize_pricing_config_schema = _owner._normalize_pricing_config_schema

        _ensure_pricing_config_files()
        if not PRICING_ACTIVE.exists():
            raise RuntimeError("Active pricing config is missing")
        raw = strict_json_load(PRICING_ACTIVE)
        validate_active_pricing_config(raw)
        normalized = _normalize_pricing_config_schema(raw)
        validate_active_pricing_config(normalized)
        return normalized

    @catalog_guarded
    def _capture_public_job_pricing_authority(
        _owner,
        panels_csv: str,
    ) -> tuple[dict, dict]:
        """Capture one inseparable pricing+catalog generation for admission.

        Catalog publication uses ``_PRICING_CONFIG_LOCK`` and then the material
        lock in this same order.  Holding both through signoff validation,
        catalog lookup and authority hashing prevents a P0/L1 or P1/L0 job
        snapshot.  Staging keeps its existing unsigned behavior, but it still
        receives the same consistent capture.
        """

        ports = _owner._ports

        MATERIAL_LIBRARY_PATH = ports.get_material_library_path()
        PRICING_SEED_PATH = ports.get_pricing_seed_path()

        SYSTEM_DIR = ports.get_system_dir()

        _MATERIAL_LIBRARY_LOCK = ports.get_material_library_lock()
        _PRICING_CONFIG_LOCK = ports.get_pricing_config_lock()
        _ensure_pricing_materials = _owner._ensure_pricing_materials

        _load_pricing_config = _owner._load_pricing_config
        _utc_now_iso = ports.utc_now_iso

        with _PRICING_CONFIG_LOCK:
            with _MATERIAL_LIBRARY_LOCK:
                live_cfg = _load_pricing_config()
                if _is_production_hardening_enabled():
                    try:
                        signoff_path = Path(
                            os.environ.get("CATALOG_SIGNOFF_FILE") or (SYSTEM_DIR / "catalog_signoff.json")
                        ).expanduser()
                        signoff = strict_json_load(signoff_path)
                        signoff_ok = catalog_pricing_signoff_matches(
                            signoff,
                            live_cfg,
                            material_library_sha256=sha256_file(MATERIAL_LIBRARY_PATH),
                        )
                    except Exception as recovery_error:
                        report_recovery("metod_app.pricing.runtime.boundary.169", recovery_error)
                        signoff_ok = False
                    if not signoff_ok:
                        raise SafetyContractError("JOB_BUSINESS_AUTHORITY_UNAVAILABLE")

                live_pricing = live_cfg.get("pricing") if isinstance(live_cfg, dict) else None
                if not isinstance(live_pricing, dict):
                    live_pricing = strict_json_load(PRICING_SEED_PATH)
                authoritative_pricing = _ensure_pricing_materials(
                    strict_json_loads(strict_json_dumps(live_pricing)),
                    panels_csv,
                )
                authority = build_job_pricing_authority(
                    active_config=live_cfg,
                    authoritative_pricing=authoritative_pricing,
                    captured_at=_utc_now_iso(),
                    vat_rate=CATALOG_VAT_RATE,
                )
                return authority, authoritative_pricing

    def _ensure_pricing_config_files(_owner):
        ports = _owner._ports
        CONFIG_DIR = ports.get_config_dir()
        PRICING_VERSIONS = ports.get_pricing_versions()

        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        PRICING_VERSIONS.mkdir(parents=True, exist_ok=True)

    @catalog_guarded
    def _save_pricing_config(
        _owner, new_cfg: dict, actor: str = "admin", *, expected_revision: str | None = None
    ) -> dict:
        ports = _owner._ports
        PRICING_ACTIVE = ports.get_pricing_active()
        PRICING_AUDIT = ports.get_pricing_audit()
        PRICING_VERSIONS = ports.get_pricing_versions()

        SYSTEM_DIR = ports.get_system_dir()
        _PRICING_CONFIG_LOCK = ports.get_pricing_config_lock()
        _ensure_pricing_config_files = _owner._ensure_pricing_config_files

        _normalize_pricing_config_schema = _owner._normalize_pricing_config_schema
        _utc_now_iso = ports.utc_now_iso

        _ensure_pricing_config_files()
        if not isinstance(new_cfg, dict):
            raise ValueError("pricing config must be an object")
        if "pricing" not in new_cfg or not isinstance(new_cfg["pricing"], dict):
            raise ValueError("missing or invalid 'pricing' object")
        if "sellPricing" not in new_cfg or not isinstance(new_cfg["sellPricing"], dict):
            raise ValueError("missing or invalid 'sellPricing' object")

        # Validate the exact Admin document before any normalizer can replace a
        # malformed value with a production default.
        validate_active_pricing_config(new_cfg)
        cfg = _normalize_pricing_config_schema(new_cfg)
        validate_active_pricing_config(cfg)
        sp = cfg["sellPricing"]
        required = ["edgeBandPricePerM", "cncCostPerSheet", "drawingCostFixed", "transportCostFixed"]
        for k in required:
            try:
                sp[k] = float(sp[k])
            except (ValueError, TypeError, OverflowError):
                raise ValueError(f"sellPricing '{k}' must be a number")
            if sp[k] <= 0:
                raise ValueError(f"sellPricing '{k}' must be greater than zero")

        pricing_signoff = active_pricing_signoff_fields(cfg)
        actor_name = str(actor or "unknown")

        with _PRICING_CONFIG_LOCK:
            if expected_revision is not None:
                current_revision = '"' + canonical_pricing_sha256(_owner._load_pricing_config()) + '"'
                if expected_revision != current_revision:
                    raise PricingRevisionConflict(
                        "Prijsinstellingen zijn intussen gewijzigd. Herlaad de actuele instellingen voordat je opnieuw opslaat."
                    )
            ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S_%f")
            version_path = PRICING_VERSIONS / f"{ts}_{secrets.token_hex(3)}.json"
            changed_at = _utc_now_iso()
            signoff_path = Path(
                os.environ.get("CATALOG_SIGNOFF_FILE") or (SYSTEM_DIR / "catalog_signoff.json")
            ).expanduser()
            rec = {
                "ts": changed_at,
                "actor": actor_name,
                "version": version_path.name,
                "pricingModel": pricing_signoff["pricingModel"],
                "pricingVersion": pricing_signoff["pricingVersion"],
                "pricingCanonicalSha256": pricing_signoff["pricingCanonicalSha256"],
                "catalogSignoffInvalidated": True,
            }
            audit_limit = _env_int("PRICING_AUDIT_MAX_BYTES", 20 * 1024 * 1024)
            durable_write_json(version_path, cfg, mode=0o640)
            # Publish revocation before the new active pricing document. A
            # crash or write failure can leave approval revoked, but can never
            # leave changed pricing trusted by the old catalog signoff.
            durable_write_json(
                signoff_path,
                {
                    "schemaVersion": CATALOG_SIGNOFF_SCHEMA_VERSION,
                    "approved": False,
                    "invalidatedAt": changed_at,
                    "invalidatedBy": actor_name,
                    "invalidationReason": "pricing_changed",
                    **pricing_signoff,
                },
                mode=0o640,
            )
            durable_write_json(PRICING_ACTIVE, cfg, mode=0o640)
            append_jsonl_rotating(PRICING_AUDIT, rec, max_bytes=audit_limit, backups=10)
        return {
            "ok": True,
            "version": version_path.name,
            "pricingModel": pricing_signoff["pricingModel"],
            "pricingVersion": pricing_signoff["pricingVersion"],
            "catalogSignoffInvalidated": True,
            "revision": '"' + canonical_pricing_sha256(cfg) + '"',
        }

    def _migrate_legacy_materials_to_direct_sell_prices(_owner) -> dict:
        """Idempotently freeze legacy factor-based prices into per-material direct prices.

        This protects the live price level during the transition before the first website CSV
        is published. Prefer the historical retailPriceWithoutTax when available; otherwise
        use the previous active factor exactly once. New calculations never use the factor.
        """
        ports = _owner._ports

        CONFIG_DIR = ports.get_config_dir()
        LEGACY_SHEET_PRICE_FACTOR_DEFAULT = ports.get_legacy_sheet_price_factor_default()
        MATERIAL_LIBRARY_PATH = ports.get_material_library_path()
        PRICING_ACTIVE = ports.get_pricing_active()
        SYSTEM_DIR = ports.get_system_dir()
        _atomic_write_json = ports.atomic_write_json
        _default_pricing_config = _owner._default_pricing_config
        _normalize_pricing_config_schema = _owner._normalize_pricing_config_schema
        _utc_now_iso = ports.utc_now_iso

        result: dict[str, Any] = {"ok": True, "updated": 0, "factorUsedForFallback": None}
        try:
            # The installer seeds the initial active document. Once state exists,
            # absence is a business-authority failure, never permission to create
            # silent production defaults or rewrite historical price levels.
            if not PRICING_ACTIVE.is_file():
                raise FileNotFoundError("Active pricing config is missing")
            raw_cfg = strict_json_load(PRICING_ACTIVE)
            if not isinstance(raw_cfg, dict):
                raise ValueError("Active pricing config must be an object")
            raw_sell = raw_cfg.get("sellPricing")
            raw_factor = raw_sell.get("sheetPriceFactor") if isinstance(raw_sell, dict) else None
            if raw_factor is None:
                old_factor = float(LEGACY_SHEET_PRICE_FACTOR_DEFAULT)
            else:
                if isinstance(raw_factor, bool) or not isinstance(raw_factor, (int, float)):
                    raise ValueError("Legacy sellPricing 'sheetPriceFactor' must be a JSON number")
                old_factor = float(raw_factor)
                if not math.isfinite(old_factor) or old_factor <= 0 or old_factor > 1000:
                    raise ValueError("Legacy sellPricing 'sheetPriceFactor' is outside the allowed range")
            result["factorUsedForFallback"] = old_factor

            if str(raw_cfg.get("pricingModel") or "") == "catalog_sell_price_incl_vat_v2":
                validate_active_pricing_config(raw_cfg)
                normalized = _normalize_pricing_config_schema(raw_cfg)
            else:
                if not isinstance(raw_cfg.get("pricing"), dict):
                    raise ValueError("Legacy pricing config misses 'pricing'")
                if not isinstance(raw_cfg.get("sellPricing"), dict):
                    raise ValueError("Legacy pricing config misses 'sellPricing'")
                candidate = strict_json_loads(strict_json_dumps(raw_cfg))
                candidate_sell = candidate["sellPricing"]
                default_sell = _default_pricing_config()["sellPricing"]
                for field in (
                    "edgeBandPricePerM",
                    "cncCostPerSheet",
                    "drawingCostFixed",
                    "transportCostFixed",
                ):
                    if field in candidate_sell:
                        value = candidate_sell[field]
                        if isinstance(value, bool) or not isinstance(value, (int, float)):
                            raise ValueError(f"Legacy sellPricing '{field}' must be a JSON number")
                    else:
                        candidate_sell[field] = default_sell[field]
                candidate_sell.pop("sheetPriceFactor", None)
                candidate["pricingModel"] = "catalog_sell_price_incl_vat_v2"
                normalized = _normalize_pricing_config_schema(candidate)
            validate_active_pricing_config(normalized)

            if MATERIAL_LIBRARY_PATH.exists():
                lib = strict_json_load(MATERIAL_LIBRARY_PATH)
                if isinstance(lib, list):
                    lib = {"source": "legacy", "records": lib}
                recs = lib.get("records") if isinstance(lib, dict) else None
                changed = False
                if isinstance(recs, list):
                    for rec in recs:
                        if not isinstance(rec, dict):
                            continue
                        try:
                            incl = float(rec.get("sellPriceInclVatPerSheet") or 0.0)
                        except (ValueError, TypeError, OverflowError):
                            incl = 0.0
                        try:
                            ex = float(rec.get("sellPriceExVatPerSheet") or 0.0)
                        except (ValueError, TypeError, OverflowError):
                            ex = 0.0
                        if incl > 0 and ex <= 0:
                            rec["sellPriceExVatPerSheet"] = round(incl / (1.0 + CATALOG_VAT_RATE), 6)
                            changed = True
                            result["updated"] += 1
                        elif ex > 0 and incl <= 0:
                            rec["sellPriceInclVatPerSheet"] = round(ex * (1.0 + CATALOG_VAT_RATE), 2)
                            changed = True
                            result["updated"] += 1
                        elif incl <= 0 and ex <= 0:
                            legacy_ex = 0.0
                            try:
                                legacy_ex = float(rec.get("retailPriceWithoutTax") or 0.0)
                            except (ValueError, TypeError, OverflowError):
                                legacy_ex = 0.0
                            source = "LEGACY_RETAIL_PRICE_FROZEN"
                            if legacy_ex <= 0:
                                for key in ("purchasePrice", "inkoopprijs", "purchasePricePerSheet"):
                                    try:
                                        purchase = float(rec.get(key) or 0.0)
                                    except (ValueError, TypeError, OverflowError):
                                        purchase = 0.0
                                    if purchase > 0:
                                        legacy_ex = purchase * old_factor
                                        source = "LEGACY_FACTOR_PRICE_FROZEN"
                                        break
                            if legacy_ex > 0:
                                rec["sellPriceExVatPerSheet"] = round(legacy_ex, 6)
                                rec["sellPriceInclVatPerSheet"] = round(
                                    legacy_ex * (1.0 + CATALOG_VAT_RATE), 2
                                )
                                rec["priceVatRate"] = CATALOG_VAT_RATE
                                rec["priceSource"] = source
                                changed = True
                                result["updated"] += 1
                        if not rec.get("sourceKind"):
                            rec["sourceKind"] = "LEGACY_LIBRARY"
                            changed = True
                    if changed:
                        durable_write_json(MATERIAL_LIBRARY_PATH, lib, mode=0o640)

            CONFIG_DIR.mkdir(parents=True, exist_ok=True)
            if normalized != raw_cfg:
                durable_write_json(PRICING_ACTIVE, normalized, mode=0o640)
            marker = SYSTEM_DIR / "catalog_direct_pricing_migration_v1.json"
            marker.parent.mkdir(parents=True, exist_ok=True)
            _atomic_write_json(marker, {"ranAt": _utc_now_iso(), **result})
        except Exception as e:
            report_recovery("metod_app.pricing.runtime.boundary.411", e)
            result = {"ok": False, "updated": result.get("updated", 0), "error": str(e)}
        return result

    def _ensure_pricing_materials(_owner, pricing: dict, panels_csv: str) -> dict:
        """Build Tool B compatibility material pricing from the internal catalog.

        The CSV gross (incl-VAT) sheet price is authoritative. Tool B still expects a legacy
        field named purchasePricePerSheet, so it receives only the accounting ex-VAT equivalent
        for its internal arithmetic while the exact gross CSV cents travel alongside it. No sheet
        factor is used anywhere. Missing/invalid catalog prices are blocking errors.
        """
        ports = _owner._ports

        _material_lookup_snapshot = ports.material_lookup_snapshot
        _parse_panels_csv = ports.parse_panels_csv

        if not isinstance(pricing, dict):
            raise SafetyContractError("Live pricing config is invalid")
        defaults = pricing.get("defaults")
        if not isinstance(defaults, dict):
            raise SafetyContractError("Live pricing defaults are missing")
        finite_number(
            defaults.get("sheetMarginMm"), field="pricing.defaults.sheetMarginMm", minimum=0.0, maximum=100.0
        )
        finite_number(
            defaults.get("nestingGapMm"), field="pricing.defaults.nestingGapMm", minimum=0.0, maximum=100.0
        )
        finite_number(defaults.get("kerfMm"), field="pricing.defaults.kerfMm", minimum=0.0, maximum=100.0)
        edge_cfg = pricing.get("edgeBanding")
        if not isinstance(edge_cfg, dict):
            raise SafetyContractError("Live edgeBanding config is missing")
        finite_number(
            edge_cfg.get("defaultLossPercent"),
            field="edgeBanding.defaultLossPercent",
            minimum=0.0,
            maximum=100.0,
        )

        rows = _parse_panels_csv(panels_csv)
        codes = []
        seen = set()
        for r in rows:
            c = str(r.get("MaterialCode") or "").strip()
            if c and c not in seen:
                seen.add(c)
                codes.append(c)
        if not codes:
            raise ValueError("Geen materiaal gevonden in de paneellijst.")

        # Reuse the same mutation-sensitive catalog snapshot as public
        # canonicalization/status.  Re-reading and rebuilding 597 rows here for both
        # preflight and the background worker caused lock contention between customers.
        by_code = _material_lookup_snapshot().get("catalogByInternal") or {}

        def from_catalog(code: str) -> dict:
            rec = by_code.get(code)
            if not isinstance(rec, dict):
                raise ValueError(f"Materiaal {code} bestaat niet meer in de actieve Decor Library.")
            if (
                str(rec.get("sourceKind") or "").upper() != "CATALOG_IMPORT"
                or rec.get("catalogMissing") is True
            ):
                raise ValueError(f"Materiaal {code} komt niet uit de actieve gepubliceerde CSV-catalogus.")
            if (
                rec.get("active") is False
                or rec.get("archived") is True
                or rec.get("published") is False
                or rec.get("catalogExcluded") is True
            ):
                raise ValueError(f"Materiaal {code} is niet beschikbaar voor nieuwe aanvragen.")
            try:
                t = float(rec.get("thicknessMm") or 0.0)
            except (ValueError, TypeError, OverflowError):
                t = 0.0
            if not any(abs(t - float(x)) < 1e-9 for x in CATALOG_ALLOWED_THICKNESSES_MM):
                raise ValueError(f"Materiaal {code} heeft geen toegestane plaatdikte.")
            try:
                w = int(float(rec.get("sheetWid") or rec.get("sheetWidthMm") or 0))
            except (ValueError, TypeError, OverflowError):
                w = 0
            try:
                h = int(float(rec.get("sheetLen") or rec.get("sheetHeightMm") or rec.get("height") or 0))
            except (ValueError, TypeError, OverflowError):
                h = 0
            if w <= 0 or h <= 0:
                raise ValueError(f"Materiaal {code} heeft geen geldige plaatmaat.")
            sell_inc = _material_direct_sell_incl_vat(rec)
            if sell_inc <= 0:
                raise ValueError(f"Geen geldige directe verkoopprijs incl. BTW voor materiaal {code}.")
            public_material_id = str(rec.get("publicMaterialId") or "").strip().lower()
            if not re.fullmatch(r"decor_[a-f0-9]{20,40}", public_material_id):
                raise ValueError(f"Materiaal {code} heeft geen geldige publieke catalogus-ID.")
            # Tool B still has an old field name and performs arithmetic on an ex-VAT basis.
            # Feed it the accounting equivalent, but carry the exact CSV gross price alongside
            # it so every authoritative customer/Admin surface can preserve the original cents.
            sell_ex = float(sell_inc) / (1.0 + CATALOG_VAT_RATE)
            public_name = public_material_name(rec, by_code)
            return {
                "materialCode": code,
                "publicMaterialId": public_material_id,
                "publicName": public_name,
                "decorName": public_name,
                "thicknessMm": t,
                "sheetSizeMm": {"width": w, "height": h},
                "purchasePricePerSheet": float(sell_ex),  # Tool B compatibility only
                "sellPriceExVatPerSheet": float(sell_ex),
                "sellPriceInclVatPerSheet": round(float(sell_inc), 2),
                "priceVatRate": CATALOG_VAT_RATE,
                "materialPriceBasis": "CSV_SELL_PRICE_INCL_VAT",
                "pricingSource": str(rec.get("priceSource") or "CSV_SALE_PRICE_INCL_VAT"),
            }

        # Always rebuild only the materials used by this job from the live catalog. This
        # avoids stale request/browser pricing and makes Admin CSV publication authoritative.
        pricing["materials"] = [from_catalog(code) for code in codes]
        by_material = {str(item["materialCode"]): item for item in pricing["materials"]}
        for row in rows:
            code = str(row.get("MaterialCode") or "").strip()
            authoritative = by_material.get(code)
            if not authoritative:
                raise SafetyContractError(f"{row.get('PartId')}: materiaal ontbreekt in serverpricing")
            row_thickness = finite_number(
                row.get("ThicknessMm"), field=f"{row.get('PartId')}.ThicknessMm", minimum=0.1, maximum=100.0
            )
            if abs(row_thickness - float(authoritative["thicknessMm"])) > 1e-9:
                raise SafetyContractError(f"{row.get('PartId')}: dikte wijkt af van servercatalogus")
        pricing["currency"] = "EUR"
        pricing["units"] = "mm"
        pricing["pricingModel"] = "catalog_sell_price_incl_vat_v2"
        return pricing

    def _apply_sell_pricing_to_quote(
        _owner,
        quote: dict,
        *,
        sell_pricing: dict | None = None,
        vat_rate: float | None = None,
        include_fixed_costs: bool = True,
    ) -> dict:
        """Resolve legacy defaults, then delegate all sell arithmetic to one owner."""
        ports = _owner._ports
        if not isinstance(quote, dict):
            return quote
        if sell_pricing is None:
            config = _owner._load_pricing_config()
            sell_pricing = config.get("sellPricing") if isinstance(config, dict) else {}
        if not isinstance(sell_pricing, dict):
            raise ValueError("sell_pricing snapshot must be an object")
        effective_sell = {
            "edgeBandPricePerM": ports.get_edge_band_price_per_m(),
            "cncCostPerSheet": ports.get_cnc_cost_per_sheet(),
            "drawingCostFixed": ports.get_drawing_cost_fixed(),
            "transportCostFixed": ports.get_transport_cost_fixed(),
            **sell_pricing,
        }
        return price_quote(
            quote,
            sell_pricing=effective_sell,
            vat_rate=CATALOG_VAT_RATE if vat_rate is None else vat_rate,
            include_fixed_costs=include_fixed_costs,
        )

    def _format_eur(_owner, x: float) -> str:
        try:
            v = float(x or 0.0)
        except (ValueError, TypeError, OverflowError):
            v = 0.0
        # EU format with comma decimals
        s = f"{v:,.2f}"
        s = s.replace(",", "X").replace(".", ",").replace("X", ".")
        return f"€{s}"

    def _format_m(_owner, x: float) -> str:
        try:
            v = float(x or 0.0)
        except (ValueError, TypeError, OverflowError):
            v = 0.0
        s = f"{v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
        return f"{s} m"

    def _extract_pricing_from_any(_owner, source: dict | None) -> dict:
        out: dict[str, Any] = {
            "materialsTotal": None,
            "materialsTotalInclVat": None,
            "materialsVatIncluded": None,
            "otherCostsExVat": None,
            "otherCostsVat": None,
            "edgeBandTotal": None,
            "cncTotal": None,
            "drawingTotal": None,
            "transportTotal": None,
            "subtotalExVat": None,
            "vatAmount": None,
            "totalInclVat": None,
            "currency": "EUR",
        }
        if not isinstance(source, dict):
            return out

        def _to_float(v):
            try:
                if v is None or v == "":
                    return None
                return float(v)
            except (ValueError, TypeError, OverflowError):
                return None

        def _first_num(*pairs):
            for obj, keys in pairs:
                if not isinstance(obj, dict):
                    continue
                for key in keys:
                    val = _to_float(obj.get(key))
                    if val is not None:
                        return round(val, 2)
            return None

        def _walk(obj, keyset, results):
            if isinstance(obj, dict):
                for k, v in obj.items():
                    lk = str(k).strip().lower()
                    if lk in keyset:
                        val = _to_float(v)
                        if val is not None:
                            results.append(val)
                    _walk(v, keyset, results)
            elif isinstance(obj, list):
                for it in obj:
                    _walk(it, keyset, results)

        totals = source.get("totals") if isinstance(source.get("totals"), dict) else {}
        sell = source.get("sellPricing") if isinstance(source.get("sellPricing"), dict) else {}
        extra = source.get("extraCosts") if isinstance(source.get("extraCosts"), dict) else {}

        out["materialsTotalInclVat"] = _first_num(
            (totals, ("sheetCostTotalInclVat", "materialsTotalInclVat", "materialTotalInclVat")),
            (sell, ("sheetCostTotalInclVat", "materialsTotalInclVat", "materialTotalInclVat")),
            (extra, ("sheetCostTotalInclVat", "materialsTotalInclVat", "materialTotalInclVat")),
            (source, ("sheetCostTotalInclVat", "materialsTotalInclVat", "materialTotalInclVat")),
        )
        out["materialsVatIncluded"] = _first_num(
            (totals, ("materialVatIncluded", "materialsVatIncluded")),
            (sell, ("materialVatIncluded", "materialsVatIncluded")),
            (source, ("materialVatIncluded", "materialsVatIncluded")),
        )
        out["otherCostsExVat"] = _first_num(
            (totals, ("otherCostsExVat",)),
            (sell, ("otherCostsExVat",)),
            (extra, ("otherCostsExVat",)),
            (source, ("otherCostsExVat",)),
        )
        out["otherCostsVat"] = _first_num(
            (totals, ("otherCostsVat",)),
            (sell, ("otherCostsVat",)),
            (extra, ("otherCostsVat",)),
            (source, ("otherCostsVat",)),
        )

        out["subtotalExVat"] = _first_num(
            (totals, ("subtotalExVat", "grandTotal", "total", "subtotal", "totalExVat", "subTotalExVat")),
            (sell, ("grandTotal", "total", "subtotal", "totalExVat", "subTotalExVat")),
            (extra, ("grandTotal", "total", "subtotal", "totalExVat", "subTotalExVat")),
            (source, ("grandTotal", "total", "subtotal", "totalExVat", "subTotalExVat")),
        )
        out["totalInclVat"] = _first_num(
            (totals, ("grandTotalInclVat", "totalInclVat", "inclVatTotal", "totalPriceInclVat")),
            (sell, ("grandTotalInclVat", "totalInclVat", "inclVatTotal", "totalPriceInclVat")),
            (extra, ("grandTotalInclVat", "totalInclVat", "inclVatTotal", "totalPriceInclVat")),
            (source, ("grandTotalInclVat", "totalInclVat", "inclVatTotal", "totalPriceInclVat")),
        )
        out["vatAmount"] = _first_num(
            (totals, ("vatAmount", "btw", "vat", "taxAmount")),
            (sell, ("vatAmount", "btw", "vat", "taxAmount")),
            (extra, ("vatAmount", "btw", "vat", "taxAmount")),
            (source, ("vatAmount", "btw", "vat", "taxAmount")),
        )
        if out["vatAmount"] is None and out["subtotalExVat"] is not None and out["totalInclVat"] is not None:
            out["vatAmount"] = round(out["totalInclVat"] - out["subtotalExVat"], 2)

        out["materialsTotal"] = _first_num(
            (totals, ("sheetCostTotalExVat", "sheetCostTotal", "materialsTotal", "materialTotal")),
            (sell, ("sheetCostTotalExVat", "sheetCostTotal", "materialsTotal", "materialTotal")),
            (source, ("sheetCostTotalExVat", "sheetCostTotal", "materialsTotal", "materialTotal")),
        )

        mats = source.get("materials") if isinstance(source.get("materials"), list) else []
        if mats and out["materialsTotal"] is None:
            total = 0.0
            has = False
            for m in mats:
                if not isinstance(m, dict):
                    continue
                for key in (
                    "sellPrice",
                    "sellPriceTotal",
                    "totalSellPrice",
                    "sheetSellPriceTotal",
                    "sheetCostTotal",
                    "sheetTotal",
                    "materialTotal",
                    "materialsTotal",
                ):
                    val = _to_float(m.get(key))
                    if val is not None:
                        total += val
                        has = True
                        break
            if has:
                out["materialsTotal"] = round(total, 2)
        if out["materialsTotal"] is None:
            out["materialsTotal"] = _first_num(
                (sell, ("materialsTotal", "materialTotal", "sheetTotal", "sheetCostTotal")),
                (extra, ("materialsTotal", "materialTotal", "sheetTotal", "sheetCostTotal")),
                (source, ("materialsTotal", "materialTotal", "sheetTotal", "sheetCostTotal")),
            )

        comp_map = {
            "edgeBandTotal": {
                "edgebandtotal",
                "edgebandselltotal",
                "edgebandcost",
                "edgecosttotal",
                "edgecosttotalraw",
                "kantenband",
                "kantenbandtotaal",
            },
            "cncTotal": {"cnctotal", "cnccosttotal", "routingtotal", "cnc", "routingcost"},
            "drawingTotal": {
                "drawingtotal",
                "drawingcost",
                "drawingcosttotal",
                "setupcost",
                "setuptotal",
                "tekenwerk",
                "tekenkosten",
            },
            "transportTotal": {
                "transporttotal",
                "transportcost",
                "transportcosttotal",
                "shippingtotal",
                "deliverytotal",
                "transport",
                "verzendkosten",
            },
        }
        for target, keys in comp_map.items():
            out[target] = _first_num((sell, tuple(keys)), (extra, tuple(keys)), (source, tuple(keys)))
            if out[target] is None:
                vals: list[float] = []
                _walk(source, keys, vals)
                if vals:
                    out[target] = round(sum(vals), 2)
        return out

    def _aggregate_materials_from_subjob_quotes(_owner, parent_job_id: str) -> list[dict]:
        ports = _owner._ports
        JOBS = ports.get_jobs()

        return _pricing_aggregate_materials_from_subjob_quotes(JOBS, parent_job_id)

    def _parse_calculation_summary_totals(_owner, job_root: Path) -> dict:
        return _pricing_parse_calculation_summary_totals(job_root)

    EXPORTS = (
        "_default_pricing_config",
        "_normalize_pricing_config_schema",
        "_load_pricing_config",
        "_capture_public_job_pricing_authority",
        "_ensure_pricing_config_files",
        "_save_pricing_config",
        "_migrate_legacy_materials_to_direct_sell_prices",
        "_ensure_pricing_materials",
        "_apply_sell_pricing_to_quote",
        "_format_eur",
        "_format_m",
        "_extract_pricing_from_any",
        "_aggregate_materials_from_subjob_quotes",
        "_parse_calculation_summary_totals",
    )


__all__ = ("PricingRuntime",)
