"""Pure sell-price calculation shared by quote views and sealed reports."""

from __future__ import annotations


import copy
import math
from .amounts import charge, material_net, money, mixed_vat_totals


def _number(value, field, *, positive=False):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{field} must be a JSON number")
    result = float(value)
    if not math.isfinite(result) or result < 0 or (positive and result == 0):
        raise ValueError(f"{field} must be finite and {'positive' if positive else 'non-negative'}")
    return result


def price_quote(
    quote: dict, *, sell_pricing: dict, vat_rate: float, include_fixed_costs: bool = True
) -> dict:
    if not isinstance(quote, dict):
        raise ValueError("quote must be an object")
    if not isinstance(sell_pricing, dict):
        raise ValueError("sell_pricing snapshot must be an object")
    q = copy.deepcopy(quote)
    q.setdefault("sellPricing", {})
    sp = dict(sell_pricing)
    effective_vat_rate = vat_rate
    if isinstance(effective_vat_rate, bool) or not isinstance(effective_vat_rate, (int, float)):
        raise ValueError("vat_rate must be a JSON number")
    effective_vat_rate = float(effective_vat_rate)
    if not math.isfinite(effective_vat_rate) or not (0.0 <= effective_vat_rate <= 1.0):
        raise ValueError("vat_rate must be finite and between zero and one")

    def strict_sell(name: str) -> float:
        value = sp.get(name)
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError(f"sellPricing.{name} must be a JSON number")
        result = float(value)
        if not math.isfinite(result) or result < 0:
            raise ValueError(f"sellPricing.{name} must be finite and non-negative")
        return result

    edge_band_price_per_m = strict_sell("edgeBandPricePerM")
    cnc_cost_per_sheet = strict_sell("cncCostPerSheet")
    drawing_cost_fixed = strict_sell("drawingCostFixed")
    transport_cost_fixed = strict_sell("transportCostFixed")
    q["sellPricing"].update(
        {
            "pricingModel": "catalog_sell_price_incl_vat_v2",
            "materialPriceBasis": "CSV_SELL_PRICE_INCL_VAT",
            "materialVatRate": effective_vat_rate,
            "otherCostsPriceBasis": "ADMIN_EX_VAT",
            "edgeBandPricePerM": edge_band_price_per_m,
            "cncCostPerSheet": cnc_cost_per_sheet,
            "drawingCostFixed": drawing_cost_fixed,
            "transportCostFixed": transport_cost_fixed,
        }
    )
    q["sellPricing"].pop("sheetPriceFactor", None)

    if "totalsRaw" not in q and isinstance(q.get("totals"), dict):
        q["totalsRaw"] = dict(q["totals"])

    mats = q.get("materials")
    if not isinstance(mats, list) or not mats:
        raise ValueError("quote requires material rows")
    total_sheets = 0
    sheet_sell_total_ex = 0.0
    sheet_sell_total_inc = 0.0
    for m in mats:
        if not isinstance(m, dict):
            raise ValueError("material row must be an object")
        public_name = str(m.get("publicName") or m.get("decorName") or "").strip()
        if public_name:
            m["publicName"] = public_name
            m["productName"] = public_name
            m["materialDisplayName"] = public_name
        count = _number(m.get("sheetCount"), "sheetCount", positive=True)
        if not count.is_integer():
            raise ValueError("sheetCount must be an integer")
        sc = int(count)
        total_sheets += sc

        raw_unit = m.get("sheetUnitCost")
        gross = m.get("sellPriceInclVatPerSheet")
        if gross is None:
            # Explicit compatibility for historical optimizer quotes without a
            # gross catalog price. Invalid supplied gross values never fall back.
            legacy_net = m.get("sellPriceExVatPerSheet", raw_unit)
            gross = money(_number(legacy_net, "material net price", positive=True) * (1 + effective_vat_rate))
        unit_inc = money(_number(gross, "material gross price", positive=True))
        if unit_inc <= 0:
            raise ValueError("material gross price rounds to zero")
        unit_ex = unit_inc / (1.0 + effective_vat_rate)
        gross_total = charge(sc, unit_inc)
        net_total = material_net(gross_total, effective_vat_rate)

        m["sheetUnitCostRaw"] = raw_unit
        m["sheetUnitCost"] = unit_ex  # legacy ex-VAT compatibility field
        m["sellPriceExVatPerSheet"] = unit_ex
        m["sellPriceInclVatPerSheet"] = unit_inc
        m["materialPriceBasis"] = "CSV_SELL_PRICE_INCL_VAT"
        m["sheetCostTotalRaw"] = m.get("sheetCostTotal")
        m["sheetCostTotal"] = net_total  # legacy/ex-VAT compatibility
        m["sheetCostTotalExVat"] = net_total
        m["sheetCostTotalInclVat"] = gross_total
        sheet_sell_total_ex += net_total
        sheet_sell_total_inc += gross_total

    edge = q.get("edgeBanding") if isinstance(q.get("edgeBanding"), dict) else {}
    # Tool B keeps the display map rounded to millimetres, but sell pricing
    # must use its exact pre-display measurement or the report/status can
    # diverge by a cent near rounding boundaries.
    bwl_exact = edge.get("byCodeMetersWithLossExact")
    bwl = (
        bwl_exact
        if isinstance(bwl_exact, dict)
        else (edge.get("byCodeMetersWithLoss") if isinstance(edge.get("byCodeMetersWithLoss"), dict) else {})
    )
    meters_with_loss = sum(_number(value, "edge meters") for value in bwl.values())
    edge_sell_total = charge(meters_with_loss, edge_band_price_per_m)
    if edge:
        edge.setdefault("sell", {})
        edge["sell"].update(
            {
                "priceBasis": "ADMIN_EX_VAT",
                "pricePerM": edge_band_price_per_m,
                "metersWithLossTotal": meters_with_loss,
                "edgeCostTotalRaw": edge.get("edgeCostTotal"),
            }
        )
        by_code_cost = {}
        for code, mtrs in bwl.items():
            by_code_cost[str(code)] = charge(_number(mtrs, "edge meters"), edge_band_price_per_m)
        edge["byCodeCostRaw"] = edge.get("byCodeCost")
        edge["byCodeCost"] = by_code_cost
        edge["edgeCostTotalRaw"] = edge.get("edgeCostTotal")
        edge["edgeCostTotal"] = edge_sell_total

    cnc_total = charge(total_sheets, cnc_cost_per_sheet)
    drawing_total = money(drawing_cost_fixed) if include_fixed_costs else 0.0
    transport_total = money(transport_cost_fixed) if include_fixed_costs else 0.0
    q["extraCosts"] = {
        "priceBasis": "ADMIN_EX_VAT",
        "sheetCount": total_sheets,
        "cncCostPerSheet": cnc_cost_per_sheet,
        "cncCostTotal": cnc_total,
        "drawingCostFixed": drawing_cost_fixed,
        "drawingCostTotal": drawing_total,
        "transportCostFixed": transport_cost_fixed,
        "transportCostTotal": transport_total,
    }

    totals = mixed_vat_totals(
        material_ex=sheet_sell_total_ex,
        material_inc=sheet_sell_total_inc,
        edge=edge_sell_total,
        cnc=cnc_total,
        drawing=drawing_total,
        transport=transport_total,
        vat_rate=effective_vat_rate,
        sheet_count=total_sheets,
    )
    subtotal_ex = totals["subtotalExVat"]
    total_inc = totals["totalInclVat"]
    q["totals"] = totals
    q["grandTotal"] = subtotal_ex
    q["totalInclVat"] = total_inc
    q["grandTotalInclVat"] = total_inc
    q["sheetCount"] = total_sheets
    return q
