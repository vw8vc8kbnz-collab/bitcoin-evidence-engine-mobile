"""Geometry responsibilities for the production optimizer."""

from __future__ import annotations

from metod_app.observability.failures import report_recovery
import math
import os
import re
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple
from dxf_geometry import (
    ContractError as DxfContractError,
    entities_bbox as strict_entities_bbox,
    entities_section as strict_entities_section,
    entity_bbox as strict_entity_bbox,
    entity_layer as strict_entity_layer,
    entity_type as strict_entity_type,
    geometry_sha256,
    validate_production_entity,
    pairs_to_text as strict_pairs_to_text,
    parse_pairs as strict_parse_pairs,
    set_entity_layer,
    split_entities as strict_split_entities,
    transform_entities as strict_transform_entities,
)
from panel_contract import parse_panels_csv as parse_panels_csv_contract
from safety_contracts import durable_write_text, finite_number, sha256_file, strict_json_load
from .common import fatal
from .models import PanelRow, PartData, Placement


def read_panels_csv(
    path: Path, report: Dict[str, Any], *, allowed_thicknesses: Set[float], allowed_edge_codes: Set[int]
) -> List[PanelRow]:
    if not path.exists():
        fatal(report, f"Missing panels.csv: {path}")
    try:
        canonical = parse_panels_csv_contract(
            path.read_text(encoding="utf-8", errors="strict"),
            allowed_thicknesses=allowed_thicknesses,
            allowed_edge_codes=allowed_edge_codes,
            max_rows=int(os.environ.get("OPTIMIZER_MAX_PANEL_ROWS", "500")),
            max_total_qty=int(os.environ.get("OPTIMIZER_MAX_TOTAL_QTY", "250")),
        )
    except Exception as exc:
        report_recovery("metod_app.optimizer.geometry.boundary.20", exc)
        fatal(report, f"Invalid panels.csv: {exc}")
    return [PanelRow(**row.as_dict()) for row in canonical]


def dxf_pairs(text: str) -> List[Tuple[int, str]]:
    return strict_parse_pairs(text)


def pairs_to_dxf(pairs: List[Tuple[int, str]]) -> str:
    return strict_pairs_to_text(pairs)


def _extract_entities_pairs(all_pairs: List[Tuple[int, str]]) -> List[Tuple[int, str]]:
    return strict_entities_section(all_pairs)


def _float(v: str) -> Optional[float]:
    try:
        return float(v)
    except (ValueError, TypeError, OverflowError):
        return None


def compute_bbox_from_pairs(pairs: List[Any], report: Dict[str, Any]) -> Tuple[float, float, float, float]:
    bbox = strict_entities_bbox(strict_split_entities(pairs))
    return (bbox.min_x, bbox.min_y, bbox.max_x, bbox.max_y)


def shift_pairs_xy(pairs: List[Tuple[int, str]], dx: float, dy: float) -> List[Tuple[int, str]]:
    entities = strict_transform_entities(
        strict_split_entities(pairs),
        rotation_deg=0,
        translate_x=float(dx),
        translate_y=float(dy),
        source_width=0.0,
        source_height=0.0,
    )
    return [pair for entity in entities for pair in entity]


def set_layer_for_pairs(ent: List[Tuple[int, str]], layer: str) -> List[Tuple[int, str]]:
    """Ensure the entity is on a predictable layer.

    Some viewers/CAM setups rely on layers. We use:
    - CUT: outer contour rectangles
    - DRILL: circles/arcs for machining
    """
    entities = [set_entity_layer(entity, layer) for entity in strict_split_entities(ent)]
    return [pair for entity in entities for pair in entity]


def rotate_translate_pairs(
    pairs: List[Tuple[int, str]], rot_deg: int, tx: float, ty: float, w0: float, h0: float
) -> List[Tuple[int, str]]:
    entities = strict_split_entities(pairs)
    transformed = strict_transform_entities(
        entities,
        rotation_deg=int(rot_deg),
        translate_x=float(tx),
        translate_y=float(ty),
        source_width=float(w0),
        source_height=float(h0),
    )
    return [pair for entity in transformed for pair in entity]


def load_part(part_path: Path, report: Dict[str, Any]) -> PartData:
    txt = part_path.read_text(encoding="utf-8", errors="strict")
    allp = dxf_pairs(txt)
    ents = _extract_entities_pairs(allp)
    source_entities = strict_split_entities(ents)
    source_types = {strict_entity_type(entity) for entity in source_entities}
    unsupported_types = sorted(source_types - {"LINE", "CIRCLE", "ARC", "LWPOLYLINE"})
    if unsupported_types:
        fatal(report, f"{part_path.name}: unsupported production DXF entities: {unsupported_types}")
    for entity in source_entities:
        if strict_entity_type(entity) == "LWPOLYLINE" and strict_entity_layer(entity).upper() != "OUTLINE":
            fatal(report, f"{part_path.name}: only an OUTLINE LWPOLYLINE is accepted")
        try:
            validate_production_entity(entity)
        except DxfContractError as exc:
            fatal(report, f"{part_path.name}: {exc}")
    bbox = compute_bbox_from_pairs(ents, report)
    minx, miny, maxx, maxy = bbox
    w = maxx - minx
    h = maxy - miny
    if not all((math.isfinite(value) for value in (minx, miny, maxx, maxy, w, h))) or w <= 0 or h <= 0:
        fatal(report, f"{part_path.name}: DXF has no valid finite panel bbox")
    ents_norm_pairs = shift_pairs_xy(ents, dx=-minx, dy=-miny)
    drill_entities = [
        entity
        for entity in strict_split_entities(ents_norm_pairs)
        if strict_entity_type(entity) in {"CIRCLE", "ARC"}
    ]
    drill_flat = [pair for entity in drill_entities for pair in entity]
    return PartData(
        part_id=part_path.stem,
        bbox=(0.0, 0.0, w, h),
        w=w,
        h=h,
        drill_pairs=drill_flat,
        drill_entity_count=len(drill_entities),
        drill_geometry_sha256=geometry_sha256(drill_entities),
    )


def validate_part_bbox(
    part_id: str, expected_w: float, expected_h: float, pdata: PartData, report: Dict[str, Any]
) -> None:
    tol = float(os.environ.get("DXF_BBOX_TOLERANCE_MM", "0.1"))
    if abs(pdata.w - expected_w) > tol or abs(pdata.h - expected_h) > tol:
        fatal(
            report,
            f"{part_id}: DXF bbox {pdata.w:.3f}x{pdata.h:.3f} differs from CSV {expected_w:.3f}x{expected_h:.3f} (tolerance {tol}mm)",
        )


def compose_sheet_dxf(
    sheet_w: float,
    sheet_h: float,
    sheet_index: int,
    sheet_placements: List[Placement],
    part_cache: Dict[str, PartData],
    out_path: Path,
    report: Dict[str, Any],
) -> None:
    pairs: List[Tuple[int, str]] = []
    pairs += [(0, "SECTION"), (2, "ENTITIES")]

    def add_lwpoly_rect(x0: float, y0: float, w: float, h: float, layer: str) -> None:
        pairs.extend(
            [
                (0, "LWPOLYLINE"),
                (8, layer),
                (90, "4"),
                (70, "1"),
                (10, str(x0)),
                (20, str(y0)),
                (10, str(x0 + w)),
                (20, str(y0)),
                (10, str(x0 + w)),
                (20, str(y0 + h)),
                (10, str(x0)),
                (20, str(y0 + h)),
            ]
        )

    add_lwpoly_rect(-sheet_w, 0, sheet_w, sheet_h, "SHEET")
    expected_drill_entities = 0
    geometry_tolerance = float(os.environ.get("DXF_ENTITY_BOUNDS_TOLERANCE_MM", "0.1"))
    for p in sheet_placements:
        pdata = part_cache.get(p.partId)
        if pdata is None:
            fatal(report, f"Missing part cache for {p.partId} while composing sheet")
        w0 = pdata.w
        h0 = pdata.h
        if int(p.rotationDeg) % 180 == 90:
            ow, oh = (h0, w0)
        else:
            ow, oh = (w0, h0)
        x_place = -(float(p.x) + float(ow))
        y_place = float(p.y)
        add_lwpoly_rect(x_place, y_place, ow, oh, "CUT")
        if pdata.drill_pairs:
            transformed_drill = rotate_translate_pairs(
                pdata.drill_pairs, p.rotationDeg, x_place, y_place, w0=w0, h0=h0
            )
            transformed_drill = set_layer_for_pairs(transformed_drill, "DRILL")
            transformed_entities = strict_split_entities(transformed_drill)
            if len(transformed_entities) != pdata.drill_entity_count:
                fatal(report, f"{p.partId}: machining entity count changed during transform")
            for entity in transformed_entities:
                bbox = strict_entity_bbox(entity)
                if bbox is None:
                    fatal(report, f"{p.partId}: machining entity has no finite bbox")
                if (
                    bbox.min_x < x_place - geometry_tolerance
                    or bbox.max_x > x_place + ow + geometry_tolerance
                    or bbox.min_y < y_place - geometry_tolerance
                    or (bbox.max_y > y_place + oh + geometry_tolerance)
                ):
                    fatal(report, f"{p.partId}: transformed machining escapes its placement bbox")
            expected_drill_entities += len(transformed_entities)
            pairs.extend(transformed_drill)
    pairs += [(0, "ENDSEC"), (0, "EOF")]
    output_text = pairs_to_dxf(pairs)
    output_entities = strict_split_entities(strict_entities_section(strict_parse_pairs(output_text)))
    layer_counts: Dict[str, int] = defaultdict(int)
    for entity in output_entities:
        validate_production_entity(entity)
        layer = strict_entity_layer(entity)
        if layer not in {"SHEET", "CUT", "DRILL"}:
            fatal(report, f"Sheet {sheet_index}: unexpected production layer {layer!r}")
        layer_counts[layer] += 1
        bbox = strict_entity_bbox(entity)
        if bbox is None:
            fatal(report, f"Sheet {sheet_index}: entity on {layer} has no finite bbox")
        if (
            bbox.min_x < -float(sheet_w) - geometry_tolerance
            or bbox.max_x > geometry_tolerance
            or bbox.min_y < -geometry_tolerance
            or (bbox.max_y > float(sheet_h) + geometry_tolerance)
        ):
            fatal(report, f"Sheet {sheet_index}: {layer} entity escapes sheet bounds")
    if layer_counts.get("SHEET", 0) != 1:
        fatal(report, f"Sheet {sheet_index}: expected exactly one SHEET outline")
    if layer_counts.get("CUT", 0) != len(sheet_placements):
        fatal(report, f"Sheet {sheet_index}: CUT count does not match placements")
    if layer_counts.get("DRILL", 0) != expected_drill_entities:
        fatal(report, f"Sheet {sheet_index}: machining count does not match source geometry")
    durable_write_text(out_path, output_text)
    report.setdefault("sheetValidation", []).append(
        {
            "sheetIndex": int(sheet_index),
            "placements": len(sheet_placements),
            "sheetOutlines": layer_counts.get("SHEET", 0),
            "cutEntities": layer_counts.get("CUT", 0),
            "machiningEntities": layer_counts.get("DRILL", 0),
            "geometrySha256": geometry_sha256(output_entities),
        }
    )


def validate_final_placements(
    rows: List[PanelRow],
    placements: List[Placement],
    material_map: Dict[str, Dict[str, Any]],
    report: Dict[str, Any],
    *,
    margin: float,
    gap: float,
) -> Dict[str, Any]:
    """Prove that the packer produced each requested instance exactly once and safely."""
    margin = finite_number(margin, field="sheetMarginMm", minimum=0.0, maximum=100.0)
    gap = finite_number(gap, field="nestingGapMm", minimum=0.0, maximum=100.0)
    expected = {(row.PartId, index) for row in rows for index in range(1, row.Qty + 1)}
    observed = [(placement.partId, int(placement.instanceIndex)) for placement in placements]
    if len(observed) != len(set(observed)):
        fatal(report, "Duplicate placement identity in final output")
    if set(observed) != expected:
        missing = sorted(expected - set(observed))[:10]
        extra = sorted(set(observed) - expected)[:10]
        fatal(report, f"Placement identity mismatch; missing={missing}, extra={extra}")
    by_sheet: Dict[Tuple[str, float, int], List[Tuple[Placement, float, float]]] = defaultdict(list)
    tolerance = 1e-07
    origin_rounding_tolerance = 0.05 + tolerance
    gap_rounding_tolerance = 0.1 + tolerance
    for placement in placements:
        values = (placement.x, placement.y, placement.widthMm, placement.lengthMm, placement.thicknessMm)
        if not all((math.isfinite(float(value)) for value in values)):
            fatal(report, f"{placement.partId}: non-finite placement geometry")
        if int(placement.rotationDeg) not in {0, 90, 180, 270}:
            fatal(report, f"{placement.partId}: unsupported placement rotation")
        actual_w = float(placement.widthMm if int(placement.rotationDeg) % 180 == 0 else placement.lengthMm)
        actual_h = float(placement.lengthMm if int(placement.rotationDeg) % 180 == 0 else placement.widthMm)
        material = material_map.get(placement.materialCode)
        if material is None or abs(float(material["thicknessMm"]) - float(placement.thicknessMm)) > tolerance:
            fatal(report, f"{placement.partId}: placement material/thickness is not authoritative")
        sheet_w = float(material["sheetSizeMm"]["width"])
        sheet_h = float(material["sheetSizeMm"]["height"])
        if (
            placement.x < -tolerance
            or placement.y < -tolerance
            or placement.x + actual_w > sheet_w + tolerance
            or (placement.y + actual_h > sheet_h + tolerance)
        ):
            fatal(report, f"{placement.partId}: placement escapes authoritative sheet bounds")
        if (
            placement.x < margin - origin_rounding_tolerance
            or placement.y < margin - origin_rounding_tolerance
            or placement.x + actual_w > sheet_w - margin + origin_rounding_tolerance
            or (placement.y + actual_h > sheet_h - margin + origin_rounding_tolerance)
        ):
            fatal(report, f"{placement.partId}: placement violates configured sheet margin")
        by_sheet[placement.materialCode, float(placement.thicknessMm), int(placement.sheetIndex)].append(
            (placement, actual_w, actual_h)
        )
    collision_checks = 0
    for _sheet_key, members in by_sheet.items():
        for index, (left, left_w, left_h) in enumerate(members):
            for right, right_w, right_h in members[index + 1 :]:
                collision_checks += 1
                separated = (
                    left.x + left_w <= right.x + tolerance
                    or right.x + right_w <= left.x + tolerance
                    or left.y + left_h <= right.y + tolerance
                    or (right.y + right_h <= left.y + tolerance)
                )
                if not separated:
                    fatal(report, f"Placement collision: {left.partId} and {right.partId}")
                gap_separated = (
                    left.x + left_w + gap <= right.x + gap_rounding_tolerance
                    or right.x + right_w + gap <= left.x + gap_rounding_tolerance
                    or left.y + left_h + gap <= right.y + gap_rounding_tolerance
                    or (right.y + right_h + gap <= left.y + gap_rounding_tolerance)
                )
                if not gap_separated:
                    fatal(report, f"Configured nesting gap violated: {left.partId} and {right.partId}")
    row_by_id = {row.PartId: row for row in rows}
    grain_groups: Dict[str, List[Tuple[int, Placement]]] = defaultdict(list)
    for placement in placements:
        row = row_by_id[placement.partId]
        if row.GrainGroup:
            group_id, position = row.GrainGroup.split(":", 1)
            grain_groups[group_id].append((int(position), placement))
    for group_id, members in grain_groups.items():
        ordered = sorted(members, key=lambda item: item[0])
        sheet_keys = {(item.materialCode, item.thicknessMm, item.sheetIndex) for _, item in ordered}
        if len(sheet_keys) != 1:
            fatal(report, f"GrainGroup {group_id} was split across sheets")
        if any((int(item.rotationDeg) != 0 for _, item in ordered)):
            fatal(report, f"GrainGroup {group_id} contains a rotated panel")
        x_values = {round(float(item.x), 7) for _, item in ordered}
        if len(x_values) != 1:
            fatal(report, f"GrainGroup {group_id} is not vertically aligned")
        y_values = [float(item.y) for _, item in ordered]
        if any((y_values[index] >= y_values[index + 1] for index in range(len(y_values) - 1))):
            fatal(report, f"GrainGroup {group_id}: position 1 must be the lowest physical Y")
    return {
        "expectedInstances": len(expected),
        "observedPlacements": len(observed),
        "sheetPartitions": len(by_sheet),
        "collisionChecks": collision_checks,
        "grainGroups": len(grain_groups),
        "grainPositionOneIsLowestY": True,
        "sheetMarginMm": margin,
        "nestingGapMm": gap,
        "coordinateRoundingMm": 0.1,
    }


def resolve_dxf_part_sources(
    input_dir: Path, rows: List[PanelRow], report: Dict[str, Any]
) -> Tuple[Dict[str, Path], List[Path], str]:
    """Resolve legacy PartId files or compact content-addressed DXF input."""
    expected_ids = {row.PartId for row in rows}
    refs_path = input_dir / "dxf_part_refs.json"
    blobs_dir = input_dir / "dxf_blobs"
    if refs_path.exists():
        try:
            manifest = strict_json_load(refs_path)
        except (OSError, ValueError, TypeError, OverflowError) as exc:
            fatal(report, f"Invalid dxf_part_refs.json: {exc}")
        if not isinstance(manifest, dict) or int(manifest.get("schemaVersion") or 0) != 1:
            fatal(report, "dxf_part_refs.json has an unsupported schema")
        if str(manifest.get("algorithm") or "").lower() != "sha256":
            fatal(report, "dxf_part_refs.json must use sha256 content addresses")
        refs = manifest.get("partRefs")
        if not isinstance(refs, dict) or set(refs) != expected_ids:
            fatal(report, "DXF reference set does not exactly match panels.csv")
        if not blobs_dir.is_dir() or blobs_dir.is_symlink():
            fatal(report, "Missing or unsafe dxf_blobs directory")
        source_by_part: Dict[str, Path] = {}
        source_by_blob: Dict[str, Path] = {}
        referenced_blob_ids: Set[str] = set()
        for part_id in sorted(expected_ids):
            blob_id = str(refs.get(part_id) or "").strip().lower()
            if not re.fullmatch("[0-9a-f]{64}", blob_id):
                fatal(report, f"{part_id}: invalid DXF sha256 reference")
            referenced_blob_ids.add(blob_id)
            path = blobs_dir / f"{blob_id}.dxf"
            if not path.is_file() or path.is_symlink():
                fatal(report, f"{part_id}: referenced DXF body is missing or unsafe")
            if blob_id not in source_by_blob:
                if sha256_file(path) != blob_id:
                    fatal(report, f"{part_id}: referenced DXF body hash mismatch")
                source_by_blob[blob_id] = path
            source_by_part[part_id] = source_by_blob[blob_id]
        actual_blob_ids = {path.stem.lower() for path in blobs_dir.glob("*.dxf") if path.is_file()}
        if actual_blob_ids != referenced_blob_ids:
            fatal(report, "dxf_blobs contains missing or unreferenced bodies")
        evidence = [refs_path] + [source_by_blob[key] for key in sorted(source_by_blob)]
        return (source_by_part, evidence, "content_addressed_refs_v1")
    parts_dir = input_dir / "dxf_parts"
    source_by_part = {row.PartId: parts_dir / f"{row.PartId}.dxf" for row in rows}
    missing = [part_id for part_id, path in source_by_part.items() if not path.is_file()]
    if missing:
        fatal(report, f"Missing DXF files for PartId(s): {missing}")
    return (source_by_part, list(source_by_part.values()), "legacy_part_files")
