"""Production DXF nesting: validated geometry, packing, pricing and CLI."""
