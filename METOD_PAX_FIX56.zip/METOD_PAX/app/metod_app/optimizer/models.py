"""Models responsibilities for the production optimizer."""

from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, List, Tuple


@dataclass
class PanelRow:
    PartId: str
    PanelName: str
    Qty: int
    LengthMm: float
    WidthMm: float
    ThicknessMm: float
    MaterialCode: str
    GrainGroup: str
    RotationAllowed: bool
    H1: int
    H2: int
    W1: int
    W2: int


@dataclass
class PartData:
    part_id: str
    bbox: Tuple[float, float, float, float]
    w: float
    h: float
    drill_pairs: List[Tuple[int, str]]
    drill_entity_count: int
    drill_geometry_sha256: str


@dataclass
class Instance:
    row: PanelRow
    idx: int
    w: float
    h: float
    rot_allowed: bool


@dataclass
class Placement:
    partId: str
    instanceIndex: int
    sheetIndex: int
    x: float
    y: float
    rotationDeg: int
    widthMm: float
    lengthMm: float
    materialCode: str
    thicknessMm: float
    edge: Dict[str, int]


@dataclass
class _FreeRect:
    x: float
    y: float
    w: float
    h: float


@dataclass
class _PlaceChoice:
    sheet_idx: int
    x: float
    y: float
    w: float
    h: float
    rot: int
    score: Tuple[float, ...]
