"""Quote responsibilities for the production optimizer."""

from __future__ import annotations
import re
from typing import Any, Dict, List, Tuple
from safety_contracts import ContractError, finite_number
from .models import PanelRow, Placement


def build_quote(
    job_id: str, rows: List[PanelRow], placements: List[Placement], pricing: Dict[str, Any]
) -> Dict[str, Any]:
    defaults = pricing.get("defaults", {})
    if not isinstance(defaults, dict):
        raise ContractError("pricing.defaults must be an object")
    currency = str(pricing.get("currency") or "").strip().upper()
    if not re.fullmatch("[A-Z]{3}", currency):
        raise ContractError("pricing.currency must be an ISO-style three-letter code")
    sheet_counts: Dict[Tuple[str, float], int] = {}
    for p in placements:
        k = (p.materialCode, float(p.thicknessMm))
        sheet_counts[k] = max(sheet_counts.get(k, 0), p.sheetIndex)
    mats = {(m.get("materialCode"), float(m.get("thicknessMm", 0))): m for m in pricing.get("materials", [])}
    materials_out: List[Dict[str, Any]] = []
    sheet_cost_total = 0.0
    for (code, th), cnt in sorted(sheet_counts.items()):
        mat = mats.get((code, th))
        if mat is None:
            raise ContractError(f"No exact authoritative pricing record for {code}/{th:g}mm")
        unit = finite_number(
            mat.get("purchasePricePerSheet"),
            field=f"{code}.purchasePricePerSheet",
            minimum=0.0,
            maximum=1000000.0,
        )
        cost = unit * cnt
        sheet_cost_total += cost
        sell_ex = None
        if mat.get("sellPriceExVatPerSheet") is not None:
            sell_ex = finite_number(
                mat.get("sellPriceExVatPerSheet"),
                field=f"{code}.sellPriceExVatPerSheet",
                minimum=0.0,
                maximum=1000000.0,
            )
        sell_inc = None
        if mat.get("sellPriceInclVatPerSheet") is not None:
            sell_inc = finite_number(
                mat.get("sellPriceInclVatPerSheet"),
                field=f"{code}.sellPriceInclVatPerSheet",
                minimum=0.0,
                maximum=1000000.0,
            )
        materials_out.append(
            {
                "materialCode": code,
                "publicMaterialId": mat.get("publicMaterialId"),
                "decorName": mat.get("decorName"),
                "publicName": mat.get("publicName") or mat.get("decorName"),
                "thicknessMm": th,
                "sheetSizeMm": mat.get("sheetSizeMm", {}),
                "sheetCount": cnt,
                "sheetUnitCost": unit,
                "sheetCostTotal": round(cost, 2),
                "sellPriceExVatPerSheet": round(sell_ex, 2) if sell_ex is not None else None,
                "sellPriceInclVatPerSheet": round(sell_inc, 2) if sell_inc is not None else None,
                "materialPriceBasis": mat.get("materialPriceBasis") or "CSV_SELL_PRICE_INCL_VAT",
            }
        )
    edge_cfg = pricing.get("edgeBanding", {})
    if not isinstance(edge_cfg, dict):
        raise ContractError("edgeBanding must be an object")
    loss_percent = finite_number(
        edge_cfg.get("defaultLossPercent"), field="edgeBanding.defaultLossPercent", minimum=0.0, maximum=100.0
    )
    edge_price: Dict[int, float] = {}
    for c in edge_cfg.get("codes", []) or []:
        if not isinstance(c, dict):
            raise ContractError("edgeBanding.codes entries must be objects")
        code = int(finite_number(c.get("code"), field="edgeBanding code", minimum=1.0, maximum=999.0))
        if float(code) != finite_number(c.get("code"), field="edgeBanding code", minimum=1.0, maximum=999.0):
            raise ContractError("edgeBanding code must be an integer")
        if code in edge_price:
            raise ContractError(f"duplicate edgeBanding code {code}")
        edge_price[code] = finite_number(
            c.get("purchasePricePerUnit"),
            field=f"edgeBanding code {code} price",
            minimum=0.0,
            maximum=100000.0,
        )
    meters: Dict[int, float] = {}
    for r in rows:
        qty = r.Qty
        for code, m in (
            (r.H1, r.LengthMm / 1000.0 * qty),
            (r.H2, r.LengthMm / 1000.0 * qty),
            (r.W1, r.WidthMm / 1000.0 * qty),
            (r.W2, r.WidthMm / 1000.0 * qty),
        ):
            if code == 0:
                continue
            if code not in edge_price:
                raise ContractError(f"Unknown edgeBanding code {code}")
            meters[code] = meters.get(code, 0.0) + m
    meters_loss = {k: v * (1.0 + loss_percent / 100.0) for k, v in meters.items()}
    by_code_cost: Dict[str, float] = {}
    edge_cost_total = 0.0
    for code, m in meters_loss.items():
        unit = edge_price.get(code, 0.0)
        cost = m * unit
        by_code_cost[str(code)] = round(cost, 2)
        edge_cost_total += cost
    return {
        "jobId": job_id,
        "currency": currency,
        "settings": {
            "units": "mm",
            "sheetMarginMm": finite_number(
                defaults.get("sheetMarginMm"), field="defaults.sheetMarginMm", minimum=0.0, maximum=100.0
            ),
            "nestingGapMm": finite_number(
                defaults.get("nestingGapMm"), field="defaults.nestingGapMm", minimum=0.0, maximum=100.0
            ),
            "kerfMm": finite_number(
                defaults.get("kerfMm"), field="defaults.kerfMm", minimum=0.0, maximum=100.0
            ),
        },
        "materials": materials_out,
        "edgeBanding": {
            "defaultLossPercent": loss_percent,
            "byCodeMeters": {str(k): round(v, 3) for k, v in meters.items()},
            "byCodeMetersWithLoss": {str(k): round(v, 3) for k, v in meters_loss.items()},
            "byCodeMetersExact": {str(k): v for k, v in meters.items()},
            "byCodeMetersWithLossExact": {str(k): v for k, v in meters_loss.items()},
            "byCodeCost": by_code_cost,
            "edgeCostTotal": round(edge_cost_total, 2),
        },
        "totals": {
            "sheetCostTotal": round(sheet_cost_total, 2),
            "edgeCostTotal": round(edge_cost_total, 2),
            "grandTotal": round(sheet_cost_total + edge_cost_total, 2),
        },
        "outputs": {"sheetsDxfFolder": "output/sheets/"},
    }
