"""Cli responsibilities for the production optimizer."""

from __future__ import annotations

from metod_app.version import REVISION
from metod_app.observability.failures import report_recovery
import argparse
import os
import re
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Set, Tuple
from safety_contracts import (
    ContractError,
    durable_copy_file,
    durable_write_json,
    finite_number,
    sha256_file,
    strict_json_load,
)
from .common import ensure_dir, fatal, now_iso
from .geometry import (
    compose_sheet_dxf,
    load_part,
    read_panels_csv,
    resolve_dxf_part_sources,
    validate_final_placements,
    validate_part_bbox,
)
from .models import Instance, PartData, Placement
from .packing import pack_maxrects_optimal
from .profiling import OptimizerProfiler, _profiler, configure_profiler
from .progress import (
    _atomic_progress_write_json,
    _map_material_progress,
    _optimizer_material_work_units,
    _write_progress_snapshot,
    write_progress_report,
)
from .quote import build_quote


def apply_optimizer_memory_limit() -> Dict[str, Any]:
    """Bound only the optimizer CLI process, leaving importing web workers alone."""
    if os.name != "posix":
        return {"applied": False, "reason": "address-space-limit-unavailable"}
    import resource

    if not hasattr(resource, "RLIMIT_AS"):
        return {"applied": False, "reason": "address-space-limit-unavailable"}
    try:
        memory_mb = int(os.environ.get("METOD_OPTIMIZER_MEMORY_MB", "512"))
    except ValueError as exc:
        raise ContractError("METOD_OPTIMIZER_MEMORY_MB must be an integer from 128 to 1024") from exc
    if not 128 <= memory_mb <= 1024:
        raise ContractError("METOD_OPTIMIZER_MEMORY_MB must be an integer from 128 to 1024")
    limit = memory_mb * 1024 * 1024
    current_soft, current_hard = resource.getrlimit(resource.RLIMIT_AS)
    hard = limit if current_hard == resource.RLIM_INFINITY else min(limit, current_hard)
    soft = hard if current_soft == resource.RLIM_INFINITY else min(hard, current_soft)
    resource.setrlimit(resource.RLIMIT_AS, (soft, hard))
    return {"applied": True, "addressSpaceBytes": soft, "configuredLimitMiB": memory_mb}


class OptimizerRun:
    def __init__(self, input_dir, output_dir):
        self.input_dir = Path(input_dir)
        self.output_dir = Path(output_dir)
        self.report: Dict[str, Any] = {
            "version": REVISION,
            "startedAt": now_iso(),
            "inputDir": str(self.input_dir),
            "outputDir": str(self.output_dir),
        }
        self.timing_profile: Dict[str, Any] = {"version": REVISION, "startedAt": now_iso(), "stages": []}
        self.perf_started = time.perf_counter()
        ensure_dir(self.output_dir)
        profiler_enabled = str(os.environ.get("METOD_OPTIMIZER_PROFILER", "")).strip().lower() in {
            "1",
            "true",
            "yes",
            "on",
        }
        configure_profiler(OptimizerProfiler(self.output_dir) if profiler_enabled else None)
        self.prof = _profiler()
        if self.prof:
            self.prof.set_meta(inputDir=str(self.input_dir), outputDir=str(self.output_dir))
            self.prof.event("main.start")
        write_progress_report(self.output_dir, self.report, 1, "start", "Optimalisatie gestart…")
        self._emergency_memory = None

    def read_config(self):
        self.report["resourceLimits"] = apply_optimizer_memory_limit()
        self._emergency_memory = bytearray(1024 * 1024)
        self.job_path = self.input_dir / "job.json"
        if not self.job_path.exists():
            fatal(self.report, f"Missing job.json: {self.job_path}")
        job = strict_json_load(self.job_path)
        if not isinstance(job, dict):
            fatal(self.report, "job.json must be a JSON object")
        if "grainEnabled" not in job:
            fatal(self.report, "job.json missing required key: grainEnabled")
        self.grain_enabled = job.get("grainEnabled")
        if not isinstance(self.grain_enabled, bool):
            fatal(
                self.report, f"job.json grainEnabled must be boolean, got {type(self.grain_enabled).__name__}"
            )
        self.pricing = strict_json_load(self.input_dir / "pricing.json")
        if not isinstance(self.pricing, dict):
            fatal(self.report, "pricing.json must be a JSON object")
        pricing_defaults = (
            self.pricing.get("defaults") if isinstance(self.pricing.get("defaults"), dict) else {}
        )
        try:
            self.gap = finite_number(
                pricing_defaults.get("nestingGapMm"),
                field="pricing.defaults.nestingGapMm",
                minimum=0.0,
                maximum=100.0,
            )
            self.margin = finite_number(
                pricing_defaults.get("sheetMarginMm"),
                field="pricing.defaults.sheetMarginMm",
                minimum=0.0,
                maximum=100.0,
            )
        except (OSError, ValueError, TypeError, OverflowError) as exc:
            fatal(self.report, f"Invalid production layout settings: {exc}")
        self.report["layoutSettings"] = {
            "sheetMarginMm": round(float(self.margin), 3),
            "nestingGapMm": round(float(self.gap), 3),
            "source": "pricing.defaults",
        }
        if not isinstance(self.pricing.get("materials"), list) or not self.pricing.get("materials"):
            fatal(self.report, "pricing.json must contain authoritative materials[]")

    def read_materials(self):
        self.material_map: Dict[str, dict] = {}
        self.allowed_thicknesses: Set[float] = set()
        for index, material in enumerate(self.pricing.get("materials") or []):
            if not isinstance(material, dict):
                fatal(self.report, f"pricing.json materials[{index}] must be an object")
            code = str(material.get("materialCode") or "").strip()
            if not code or code in self.material_map:
                fatal(self.report, f"pricing.json contains missing/duplicate materialCode {code!r}")
            public_material_id = str(material.get("publicMaterialId") or "").strip().lower()
            if not re.fullmatch("decor_[a-f0-9]{20,40}", public_material_id):
                fatal(self.report, f"pricing.json material {code!r} has no valid publicMaterialId")
            decor_name = str(material.get("decorName") or "").strip()
            if not decor_name or len(decor_name) > 240:
                fatal(self.report, f"pricing.json material {code!r} has no valid decorName")
            try:
                thickness = finite_number(
                    material.get("thicknessMm"),
                    field=f"materials[{index}].thicknessMm",
                    minimum=0.1,
                    maximum=100.0,
                )
                sheet_size = (
                    material.get("sheetSizeMm") if isinstance(material.get("sheetSizeMm"), dict) else {}
                )
                sheet_width = finite_number(
                    sheet_size.get("width"),
                    field=f"materials[{index}].sheetSizeMm.width",
                    minimum=1.0,
                    maximum=10000.0,
                )
                sheet_height = finite_number(
                    sheet_size.get("height"),
                    field=f"materials[{index}].sheetSizeMm.height",
                    minimum=1.0,
                    maximum=10000.0,
                )
                purchase_price = finite_number(
                    material.get("purchasePricePerSheet"),
                    field=f"materials[{index}].purchasePricePerSheet",
                    minimum=0.0,
                    maximum=1000000.0,
                )
            except (OSError, ValueError, TypeError, OverflowError) as exc:
                fatal(self.report, f"Invalid authoritative material {code}: {exc}")
            self.material_map[code] = {
                **material,
                "materialCode": code,
                "thicknessMm": thickness,
                "sheetSizeMm": {"width": sheet_width, "height": sheet_height},
                "purchasePricePerSheet": purchase_price,
            }
            self.allowed_thicknesses.add(round(thickness, 3))

    def read_edges(self):
        edge_cfg = self.pricing.get("edgeBanding")
        if not isinstance(edge_cfg, dict):
            fatal(self.report, "pricing.json edgeBanding must be an object")
        try:
            finite_number(
                edge_cfg.get("defaultLossPercent"),
                field="edgeBanding.defaultLossPercent",
                minimum=0.0,
                maximum=100.0,
            )
        except (OSError, ValueError, TypeError, OverflowError) as exc:
            fatal(self.report, f"Invalid authoritative edge loss: {exc}")
        self.allowed_edge_codes: Set[int] = {0}
        for index, item in enumerate(edge_cfg.get("codes") or []):
            if not isinstance(item, dict):
                fatal(self.report, f"edgeBanding.codes[{index}] must be an object")
            try:
                raw_code = finite_number(
                    item.get("code"), field=f"edgeBanding.codes[{index}].code", minimum=1.0, maximum=999.0
                )
                if not raw_code.is_integer():
                    raise ContractError("edge code must be an integer")
                edge_code = int(raw_code)
                if edge_code in self.allowed_edge_codes:
                    raise ContractError(f"duplicate edge code {edge_code}")
                finite_number(
                    item.get("purchasePricePerUnit"),
                    field=f"edgeBanding.codes[{index}].purchasePricePerUnit",
                    minimum=0.0,
                    maximum=100000.0,
                )
            except Exception as exc:
                report_recovery("metod_app.optimizer.cli.boundary.133", exc)
                fatal(self.report, f"Invalid authoritative edge code: {exc}")
            self.allowed_edge_codes.add(edge_code)

    def read_panels(self):
        self.rows = read_panels_csv(
            self.input_dir / "panels.csv",
            self.report,
            allowed_thicknesses=self.allowed_thicknesses,
            allowed_edge_codes=self.allowed_edge_codes,
        )
        if not self.grain_enabled and any((str(row.GrainGroup or "").strip() for row in self.rows)):
            fatal(self.report, "job.json grainEnabled=false conflicts with GrainGroup rows")
        self.timing_profile["stages"].append(
            {"name": "read_input", "seconds": round(max(0.0, time.perf_counter() - self.perf_started), 3)}
        )
        write_progress_report(self.output_dir, self.report, 3, "read_input", "Invoer lezen…")
        for r in self.rows:
            material = self.material_map.get(r.MaterialCode)
            if material is None:
                fatal(self.report, f"Unknown MaterialCode '{r.MaterialCode}' for PartId {r.PartId}")
            if abs(float(material.get("thicknessMm")) - float(r.ThicknessMm)) > 1e-09:
                fatal(
                    self.report,
                    f"{r.PartId}: ThicknessMm does not match authoritative material {r.MaterialCode}",
                )

    def load_geometry(self):
        self.part_cache: Dict[str, PartData] = {}
        source_by_part, self.dxf_input_evidence, dxf_storage_mode = resolve_dxf_part_sources(
            self.input_dir, self.rows, self.report
        )
        geometry_cache: Dict[str, PartData] = {}
        geometry_parse_count = 0
        geometry_reuse_count = 0
        load_total = max(1, len(self.rows))
        last_load_progress = 3
        for load_index, r in enumerate(self.rows, start=1):
            p = source_by_part[r.PartId]
            if dxf_storage_mode == "content_addressed_refs_v1":
                cache_key = p.stem.lower()
            else:
                try:
                    st = p.stat()
                    cache_key = f"inode:{int(st.st_dev)}:{int(st.st_ino)}:{int(st.st_size)}"
                except (OSError, ValueError, TypeError, OverflowError):
                    cache_key = f"path:{p.as_posix()}"
            pdata = geometry_cache.get(cache_key)
            if pdata is None:
                pdata = load_part(p, self.report)
                geometry_parse_count += 1
                geometry_cache[cache_key] = pdata
            else:
                geometry_reuse_count += 1
            self.part_cache[r.PartId] = pdata
            validate_part_bbox(r.PartId, r.WidthMm, r.LengthMm, pdata, self.report)
            load_progress = 3 + int(round(load_index / float(load_total) * 3.0))
            if load_progress > last_load_progress:
                last_load_progress = load_progress
                write_progress_report(
                    self.output_dir,
                    self.report,
                    load_progress,
                    "load_parts",
                    f"Panelengeometrie controleren {load_index}/{load_total}…",
                )
        self.report["dxfInput"] = {
            "storageMode": dxf_storage_mode,
            "logicalParts": len(source_by_part),
            "uniqueBodies": len(geometry_cache),
        }
        if self.prof:
            self.prof.set_meta(
                dxfGeometryParses=int(geometry_parse_count), dxfGeometryReuses=int(geometry_reuse_count)
            )
            self.prof.event(
                "load_parts.deduplicated", parsed=int(geometry_parse_count), reused=int(geometry_reuse_count)
            )
        write_progress_report(
            self.output_dir, self.report, 6, "load_parts", "Panelengeometrie gecontroleerd…"
        )

    def prepare_output(self):
        self.by_mat: Dict[Tuple[str, float], List[Instance]] = {}
        for r in self.rows:
            forced_rot0 = bool(r.GrainGroup.strip())
            rot_allowed = bool(r.RotationAllowed) and (not forced_rot0)
            insts = self.by_mat.setdefault((r.MaterialCode, float(r.ThicknessMm)), [])
            for i in range(1, r.Qty + 1):
                insts.append(
                    Instance(row=r, idx=i, w=float(r.WidthMm), h=float(r.LengthMm), rot_allowed=rot_allowed)
                )
        ensure_dir(self.output_dir)
        self.sheets_dir = self.output_dir / "sheets"
        ensure_dir(self.sheets_dir)
        self.zaag_dir = self.output_dir / "DXF_Zaagplaten"
        ensure_dir(self.zaag_dir)
        if any(self.sheets_dir.iterdir()) or any(self.zaag_dir.iterdir()):
            fatal(self.report, "Production output directories must be empty before optimization")
        write_progress_report(self.output_dir, self.report, 7, "prepare_output", "Platen voorbereiden…")
        self.placements_all: List[Placement] = []
        self.sheet_meta: List[Dict[str, Any]] = []
        self.production_sheet_paths: List[Path] = []
        self.mirrored_sheet_paths: List[Path] = []
        self.optimizer_attempt_audit: Dict[str, Any] = {}
        self.material_groups = sorted(self.by_mat.items())
        self.material_work_units = [
            _optimizer_material_work_units(instances) for _material_key, instances in self.material_groups
        ]
        self.total_material_work_units = max(1, sum(self.material_work_units))
        self.completed_material_work_units = 0

    def pack_materials(self):
        for material_index, ((mat_code, th), insts) in enumerate(self.material_groups):
            current_material_work_units = self.material_work_units[material_index]
            mat = self.material_map[mat_code]
            sheet_w = float(mat["sheetSizeMm"]["width"])
            sheet_h = float(mat["sheetSizeMm"]["height"])
            pack_started = time.perf_counter()
            write_progress_report(
                self.output_dir,
                self.report,
                _map_material_progress(
                    self.completed_material_work_units,
                    current_material_work_units,
                    self.total_material_work_units,
                    0.0,
                ),
                "packing",
                "Nestings berekenen…",
            )
            _pack_progress_state = {"pct": None, "ts": 0.0}

            def _packing_progress(frac: float, msg: str = "") -> None:
                try:
                    frac = max(0.0, min(1.0, float(frac)))
                except (ValueError, TypeError, OverflowError):
                    frac = 0.0
                pct = int(
                    round(
                        _map_material_progress(
                            self.completed_material_work_units,
                            current_material_work_units,
                            self.total_material_work_units,
                            frac * 0.97,
                        )
                    )
                )
                now_ts = time.perf_counter()
                prev_pct = _pack_progress_state.get("pct")
                prev_ts = float(_pack_progress_state.get("ts") or 0.0)
                if prev_pct is not None:
                    pct = max(int(prev_pct), int(pct))
                    if pct == prev_pct and now_ts - prev_ts < 0.15 and (pct < 94):
                        return
                _pack_progress_state["pct"] = pct
                _pack_progress_state["ts"] = now_ts
                write_progress_report(
                    self.output_dir, self.report, pct, "packing", msg or "Nestings berekenen…"
                )

            runtime_margin = float(self.margin)
            runtime_gap = float(self.gap)
            pls, sheets_used = pack_maxrects_optimal(
                insts,
                sheet_w,
                sheet_h,
                runtime_margin,
                runtime_gap,
                self.grain_enabled,
                self.report,
                progress_cb=_packing_progress,
            )
            if sheets_used < 1 or not pls:
                fatal(self.report, f"{mat_code}: packer returned no production placements")
            _attempt_audit = self.report.pop("_lastPackAttemptAudit", None)
            if isinstance(_attempt_audit, dict):
                _attempt_audit["materialCode"] = mat_code
                _attempt_audit["thicknessMm"] = float(th)
                _attempt_audit["instanceCount"] = int(len(insts))
                self.optimizer_attempt_audit[mat_code] = _attempt_audit
            pack_done = time.perf_counter()
            self.timing_profile["stages"].append(
                {
                    "name": f"packing:{mat_code}",
                    "seconds": round(max(0.0, pack_done - pack_started), 3),
                    "sheetsUsed": int(sheets_used),
                }
            )
            self.placements_all.extend(pls)
            write_progress_report(
                self.output_dir,
                self.report,
                _map_material_progress(
                    self.completed_material_work_units,
                    current_material_work_units,
                    self.total_material_work_units,
                    0.97,
                ),
                "dxf_setup",
                f"DXF-platen voorbereiden ({sheets_used} platen)…",
            )
            dxf_started = time.perf_counter()
            if self.prof:
                self.prof.event("stage.dxf_write.start", materialCode=mat_code, sheetsUsed=int(sheets_used))
            for si in range(1, sheets_used + 1):
                sheet_pls = [p for p in pls if p.sheetIndex == si]
                progress_pct = _map_material_progress(
                    self.completed_material_work_units,
                    current_material_work_units,
                    self.total_material_work_units,
                    0.97 + 0.03 * (si / float(max(1, sheets_used))),
                )
                write_progress_report(
                    self.output_dir,
                    self.report,
                    progress_pct,
                    "write_sheets",
                    f"Plaat {si} van {sheets_used} genereren…",
                )
                name = f"Sheet_{si:03d}.dxf" if len(self.by_mat) == 1 else f"{mat_code}_Sheet_{si:03d}.dxf"
                out_dxf = self.sheets_dir / name
                if not sheet_pls:
                    fatal(self.report, f"{mat_code}: sheet {si} has no placements")
                compose_sheet_dxf(sheet_w, sheet_h, si, sheet_pls, self.part_cache, out_dxf, self.report)
                if not out_dxf.is_file() or out_dxf.stat().st_size <= 0:
                    fatal(self.report, f"{mat_code}: sheet {si} was not durably produced")
                self.production_sheet_paths.append(out_dxf)
                mirror_name = (
                    f"S{si:03d}.dxf"
                    if len(self.by_mat) == 1
                    else f"M{len(self.mirrored_sheet_paths) + 1:03d}_S{si:03d}.dxf"
                )
                mirror = self.zaag_dir / mirror_name
                durable_copy_file(out_dxf, mirror)
                if sha256_file(out_dxf) != sha256_file(mirror):
                    fatal(self.report, f"{mat_code}: sheet {si} mirror hash mismatch")
                self.mirrored_sheet_paths.append(mirror)
            material_sheet_files = [
                path for path in self.production_sheet_paths if path.name.startswith(f"{mat_code}_Sheet_")
            ]
            if len(self.by_mat) == 1:
                material_sheet_files = list(self.production_sheet_paths)
            if len(material_sheet_files) != sheets_used:
                fatal(self.report, f"{mat_code}: exact sheet output count mismatch")
            dxf_done = time.perf_counter()
            self.timing_profile["stages"].append(
                {
                    "name": f"dxf_write:{mat_code}",
                    "seconds": round(max(0.0, dxf_done - dxf_started), 3),
                    "sheetsUsed": int(sheets_used),
                }
            )
            if self.prof:
                self.prof.event(
                    "stage.dxf_write.end",
                    materialCode=mat_code,
                    seconds=round(max(0.0, dxf_done - dxf_started), 6),
                    sheetsUsed=int(sheets_used),
                )
            self.completed_material_work_units += current_material_work_units
            self.sheet_meta.append(
                {
                    "materialCode": mat_code,
                    "thicknessMm": th,
                    "sheetSizeMm": {"width": sheet_w, "height": sheet_h},
                    "sheetsUsed": sheets_used,
                }
            )

    def write_placements(self):
        write_progress_report(self.output_dir, self.report, 97, "finalize_placements", "Placeringen opslaan…")
        self.placement_validation = validate_final_placements(
            self.rows, self.placements_all, self.material_map, self.report, margin=self.margin, gap=self.gap
        )
        expected_sheet_count = sum((int(item["sheetsUsed"]) for item in self.sheet_meta))
        if len(self.production_sheet_paths) != expected_sheet_count:
            fatal(self.report, "Final production sheet count does not match packer result")
        if len(self.mirrored_sheet_paths) != expected_sheet_count:
            fatal(self.report, "Final mirrored sheet count does not match packer result")
        if len(self.report.get("sheetValidation") or []) != expected_sheet_count:
            fatal(self.report, "Final sheet geometry validation count mismatch")
        self.report["placementValidation"] = self.placement_validation
        self.placements_json = {
            "jobId": self.input_dir.parent.name if self.input_dir.name == "input" else self.input_dir.name,
            "units": "mm",
            "origin": "bottom-left",
            "y_axis": "up",
            "rotation_deg_cw": False,
            "rotation_origin": "panel_bbox_min_normalized",
            "rounding": {"xyMm": 0.1},
            "sheets": self.sheet_meta,
            "placements": [
                {
                    "partId": p.partId,
                    "instanceIndex": p.instanceIndex,
                    "sheetIndex": p.sheetIndex,
                    "x_mm": p.x,
                    "y_mm": p.y,
                    "rotation_deg": p.rotationDeg,
                    "bbox_mm": {
                        "w_mm": p.widthMm if p.rotationDeg in (0, 180) else p.lengthMm,
                        "h_mm": p.lengthMm if p.rotationDeg in (0, 180) else p.widthMm,
                    },
                    "part_mm": {"width_mm": p.widthMm, "length_mm": p.lengthMm},
                    "materialCode": p.materialCode,
                    "thicknessMm": p.thicknessMm,
                    "edges": {"H1": p.edge["H1"], "H2": p.edge["H2"], "W1": p.edge["W1"], "W2": p.edge["W2"]},
                }
                for p in self.placements_all
            ],
        }
        placements_started = time.perf_counter()
        if self.prof:
            self.prof.event("stage.write_placements.start")
        durable_write_json(self.output_dir / "placements.json", self.placements_json)
        placements_done = time.perf_counter()
        self.timing_profile["stages"].append(
            {"name": "write_placements", "seconds": round(max(0.0, placements_done - placements_started), 3)}
        )
        if self.prof:
            self.prof.event(
                "stage.write_placements.end", seconds=round(max(0.0, placements_done - placements_started), 6)
            )

    def write_quote(self):
        write_progress_report(
            self.output_dir, self.report, 98, "finalize_quote", "Prijs en plaattotalen opbouwen…"
        )
        quote_started = time.perf_counter()
        if self.prof:
            self.prof.event("stage.build_quote.start")
        quote = build_quote(self.placements_json["jobId"], self.rows, self.placements_all, self.pricing)
        durable_write_json(self.output_dir / "quote.json", quote)
        quote_done = time.perf_counter()
        self.timing_profile["stages"].append(
            {"name": "build_quote", "seconds": round(max(0.0, quote_done - quote_started), 3)}
        )
        if self.prof:
            self.prof.event("stage.build_quote.end", seconds=round(max(0.0, quote_done - quote_started), 6))

    def seal_outputs(self):
        write_progress_report(self.output_dir, self.report, 99, "finalize_report", "Resultaten afronden…")
        input_files = [
            self.job_path,
            self.input_dir / "pricing.json",
            self.input_dir / "panels.csv",
        ] + self.dxf_input_evidence
        output_files = (
            self.production_sheet_paths
            + self.mirrored_sheet_paths
            + [self.output_dir / "placements.json", self.output_dir / "quote.json"]
        )
        optimizer_manifest = {
            "schemaVersion": 1,
            "release": REVISION,
            "createdAt": now_iso(),
            "contract": {
                "units": "mm",
                "grainPositionOne": "lowest-physical-y",
                "cncOrigin": "lower-right",
                "unknownDxfEntities": "reject",
                "composeFailure": "reject",
            },
            "counts": {
                "panelRows": len(self.rows),
                "requestedInstances": sum((row.Qty for row in self.rows)),
                "placements": len(self.placements_all),
                "productionSheets": len(self.production_sheet_paths),
                "mirroredSheets": len(self.mirrored_sheet_paths),
                "sheetGeometryValidations": len(self.report.get("sheetValidation") or []),
            },
            "placementValidation": self.placement_validation,
            "inputsSha256": {
                path.relative_to(self.input_dir).as_posix(): sha256_file(path)
                for path in sorted(set(input_files), key=lambda item: item.as_posix())
            },
            "outputsSha256": {
                path.relative_to(self.output_dir).as_posix(): sha256_file(path)
                for path in sorted(set(output_files), key=lambda item: item.as_posix())
            },
            "sheetGeometry": self.report.get("sheetValidation") or [],
        }
        durable_write_json(self.output_dir / "optimizer_manifest.json", optimizer_manifest)
        self.report["optimizerManifestSha256"] = sha256_file(self.output_dir / "optimizer_manifest.json")

    def finish_report(self):
        self.report["finishedAt"] = now_iso()
        self.report["ok"] = True
        self.report["sheets"] = self.sheet_meta
        self.report["progress"] = {
            "percent": 99,
            "phase": "server_followup",
            "message": "Server verwerkt resultaten…",
            "updatedAt": now_iso(),
        }
        _write_progress_snapshot(self.output_dir, self.report["progress"])
        self.report["progress"] = {
            "percent": 100,
            "phase": "done",
            "message": "Optimalisatie afgerond",
            "updatedAt": now_iso(),
        }
        _write_progress_snapshot(self.output_dir, self.report["progress"])
        report_started = time.perf_counter()
        if self.prof:
            self.prof.event("stage.write_report.start")
        durable_write_json(self.output_dir / "report.json", self.report)
        report_done = time.perf_counter()
        report_seconds = round(max(0.0, report_done - report_started), 3)
        self.timing_profile["stages"].append({"name": "write_report", "seconds": report_seconds})
        if self.prof:
            self.prof.event(
                "stage.write_report.end", seconds=round(max(0.0, report_done - report_started), 6)
            )
        self.timing_profile["totalSeconds"] = round(max(0.0, time.perf_counter() - self.perf_started), 3)
        self.timing_profile["finishedAt"] = now_iso()
        _atomic_progress_write_json(self.output_dir / "timing_profile.json", self.timing_profile)
        if self.optimizer_attempt_audit:
            _atomic_progress_write_json(
                self.output_dir / "optimizer_attempt_summary.json",
                {"generatedAt": now_iso(), "materials": self.optimizer_attempt_audit},
            )
        if self.prof:
            self.prof.write_summary()
            self.prof.close()

    def handle_failure(self, e):
        self._emergency_memory = None
        error_message = str(e)
        if isinstance(e, MemoryError):
            self.report["errorCode"] = "OPTIMIZER_MEMORY_LIMIT"
            error_message = "OPTIMIZER_MEMORY_LIMIT: optimizer exceeded its configured memory budget"
        self.prof = _profiler()
        if self.prof and (not isinstance(e, MemoryError)):
            self.prof.event("main.exception", error=error_message)
            self.prof.write_summary()
            self.prof.close()
        self.report["finishedAt"] = now_iso()
        self.report["ok"] = False
        self.report["exception"] = error_message
        try:
            ensure_dir(self.output_dir)
            self.timing_profile["totalSeconds"] = round(max(0.0, time.perf_counter() - self.perf_started), 3)
            self.timing_profile["finishedAt"] = now_iso()
            durable_write_json(self.output_dir / "timing_profile.json", self.timing_profile)
            durable_write_json(self.output_dir / "report.json", self.report)
        except Exception as recovery_error:
            report_recovery("dxf_nesting_optimizer.main.2917", recovery_error)
        sys.stderr.write(error_message + "\n")
        return 1

    def run(self):
        try:
            self.read_config()
            self.read_materials()
            self.read_edges()
            self.read_panels()
            self.load_geometry()
            self.prepare_output()
            self.pack_materials()
            self.write_placements()
            self.write_quote()
            self.seal_outputs()
            self.finish_report()
            return 0
        except Exception as error:
            report_recovery("metod_app.optimizer.cli.boundary.393", error)
            return self.handle_failure(error)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    return OptimizerRun(args.input, args.output).run()
