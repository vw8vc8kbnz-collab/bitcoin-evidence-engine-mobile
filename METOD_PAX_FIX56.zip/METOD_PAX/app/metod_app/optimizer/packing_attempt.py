"""State and deterministic selection for a single MaxRects attempt."""

from __future__ import annotations
from typing import Any, Dict, List, Optional, Set, Tuple
from .models import Instance, Placement, _FreeRect, _PlaceChoice
from .heuristics import _best_choice_for_item, _packing_equivalence_key, _split_free_rect, _prune_free_rects
from .common import fatal, round01
from .profiling import _profiler
from metod_app.observability.failures import report_recovery


class PackingAttempt:
    """One bounded attempt owns its free rectangles, selected placements and progress."""

    def __init__(
        self,
        items: List[Dict[str, Any]],
        sheet_w: float,
        sheet_h: float,
        margin: float,
        gap: float,
        k: int,
        report: Dict[str, Any],
        progress_cb=None,
    ) -> None:
        self.sheet_w = sheet_w
        self.sheet_h = sheet_h
        self.margin = margin
        self.gap = gap
        self.k = k
        self.report = report
        self.progress_cb = progress_cb
        self.usable_w = self.sheet_w - 2 * self.margin
        self.usable_h = self.sheet_h - 2 * self.margin
        if self.usable_w <= 0 or self.usable_h <= 0:
            fatal(self.report, "Sheet usable area is non-positive; check margin/sheet size.")
        self.sheets_free: List[List[_FreeRect]] = [[_FreeRect(0.0, 0.0, self.usable_w, self.usable_h)]]
        self.sheet_existing: List[List[Tuple[float, float, float, float]]] = [[]]
        self.sheet_used_area: List[float] = [0.0]
        self.placements: List[Placement] = []
        self.pending: List[Dict[str, Any]] = list(items)
        self.prof = _profiler()
        if self.prof:
            self.prof.event(
                "pack_k.start", itemCount=len(items), k=int(self.k), sheetW=self.sheet_w, sheetH=self.sheet_h
            )
        self.total_items = max(1, len(self.pending))
        self.report_stride = max(1, self.total_items // 80)
        self.last_report_done = -1
        self.sheet_area = max(1.0, self.usable_w * self.usable_h)

    def _emit_attempt_progress(self, message: str = "Nestings berekenen…", force: bool = False) -> None:
        if not callable(self.progress_cb):
            return
        done = self.total_items - len(self.pending)
        if (
            not force
            and done != self.total_items
            and (done > 0)
            and (done - self.last_report_done < self.report_stride)
        ):
            return
        if done == self.last_report_done and (not force):
            return
        try:
            frac = max(0.0, min(1.0, float(done) / float(self.total_items)))
            self.progress_cb(frac, message)
            self.last_report_done = done
        except Exception as recovery_error:
            report_recovery("dxf_nesting_optimizer._emit_attempt_progress.1203", recovery_error)

    def _density_bucket(self, sheet_idx: int) -> int:
        used_ratio = self.sheet_used_area[sheet_idx] / self.sheet_area
        bucket = 0
        if used_ratio < 0.9:
            bucket += 1
        if used_ratio < 0.75:
            bucket += 1
        if used_ratio < 0.55:
            bucket += 1
        if used_ratio < 0.35:
            bucket += 1
        return bucket

    def _commit(self, item: Dict[str, Any], choice: _PlaceChoice) -> None:
        cut_x1 = max(0.0, choice.x - self.gap)
        cut_y1 = max(0.0, choice.y - self.gap)
        cut_x2 = min(self.usable_w, choice.x + choice.w + self.gap)
        cut_y2 = min(self.usable_h, choice.y + choice.h + self.gap)
        cut_w = max(0.0, cut_x2 - cut_x1)
        cut_h = max(0.0, cut_y2 - cut_y1)
        free = self.sheets_free[choice.sheet_idx - 1]
        new_free: List[_FreeRect] = []
        for fr in free:
            new_free.extend(_split_free_rect(fr, cut_x1, cut_y1, cut_w, cut_h))
        self.sheets_free[choice.sheet_idx - 1] = _prune_free_rects(new_free)
        base_x = round01(self.margin + choice.x)
        base_y = round01(self.margin + choice.y)
        if item["kind"] == "single":
            inst: Instance = item["members"][0]
            self.placements.append(
                Placement(
                    partId=inst.row.PartId,
                    instanceIndex=inst.idx,
                    sheetIndex=choice.sheet_idx,
                    x=base_x,
                    y=base_y,
                    rotationDeg=int(choice.rot),
                    widthMm=float(inst.row.WidthMm),
                    lengthMm=float(inst.row.LengthMm),
                    materialCode=inst.row.MaterialCode,
                    thicknessMm=float(inst.row.ThicknessMm),
                    edge={"H1": inst.row.H1, "H2": inst.row.H2, "W1": inst.row.W1, "W2": inst.row.W2},
                )
            )
            self.sheet_existing[choice.sheet_idx - 1].append((choice.x, choice.y, choice.w, choice.h))
            self.sheet_used_area[choice.sheet_idx - 1] += choice.w * choice.h
        else:
            y_cursor = 0.0
            for mi, inst in enumerate(item["members"]):
                px = base_x
                py = round01(self.margin + choice.y + y_cursor)
                self.placements.append(
                    Placement(
                        partId=inst.row.PartId,
                        instanceIndex=inst.idx,
                        sheetIndex=choice.sheet_idx,
                        x=px,
                        y=py,
                        rotationDeg=0,
                        widthMm=float(inst.row.WidthMm),
                        lengthMm=float(inst.row.LengthMm),
                        materialCode=inst.row.MaterialCode,
                        thicknessMm=float(inst.row.ThicknessMm),
                        edge={"H1": inst.row.H1, "H2": inst.row.H2, "W1": inst.row.W1, "W2": inst.row.W2},
                    )
                )
                if mi == 0:
                    self.sheet_existing[choice.sheet_idx - 1].append((choice.x, choice.y, choice.w, choice.h))
                y_cursor += float(inst.h)
                if mi < len(item["members"]) - 1:
                    y_cursor += self.gap
            self.sheet_used_area[choice.sheet_idx - 1] += choice.w * choice.h

    def _pending_score(self, item: Dict[str, Any], pi: int, pc: _PlaceChoice) -> Tuple[float, ...]:
        si, x, y, placed_w, placed_h = (pc.sheet_idx, pc.x, pc.y, pc.w, pc.h)
        item_area, item_mn, item_mx, micro_flag = (item["area"], item["mn"], item["mx"], item["micro_flag"])
        spill_right_anchor_penalty = 0
        if si > 1 and (max(placed_w, placed_h) >= 900.0 or placed_w * placed_h >= 350000.0):
            right_gap = abs(x + placed_w - self.usable_w)
            touches_right = right_gap <= 1e-06
            touches_bottom = y <= 1e-06
            if not touches_right:
                if right_gap > 220.0:
                    spill_right_anchor_penalty += 3
                elif right_gap > 100.0:
                    spill_right_anchor_penalty += 2
                elif right_gap > 40.0:
                    spill_right_anchor_penalty += 1
            if not touches_bottom and y > 220.0:
                spill_right_anchor_penalty += 1
            if touches_right:
                spill_right_anchor_penalty = max(0, spill_right_anchor_penalty - 2)
            if touches_right and touches_bottom:
                spill_right_anchor_penalty = max(0, spill_right_anchor_penalty - 1)
        last_sheet_cleanup_penalty = 0
        if si > 1 and si == len(self.sheets_free):
            right_gap = abs(x + placed_w - self.usable_w)
            touches_right = right_gap <= 1e-06
            touches_bottom = y <= 1e-06
            long_anchor_flag = item_mx >= 700.0 or item_area >= 260000.0
            if long_anchor_flag:
                if not touches_right:
                    if right_gap > 260.0:
                        last_sheet_cleanup_penalty += 4
                    elif right_gap > 140.0:
                        last_sheet_cleanup_penalty += 3
                    elif right_gap > 60.0:
                        last_sheet_cleanup_penalty += 2
                    elif right_gap > 20.0:
                        last_sheet_cleanup_penalty += 1
                if not touches_bottom and y > 220.0:
                    last_sheet_cleanup_penalty += 1
                if touches_right:
                    last_sheet_cleanup_penalty = max(0, last_sheet_cleanup_penalty - 2)
                if touches_right and touches_bottom:
                    last_sheet_cleanup_penalty = max(0, last_sheet_cleanup_penalty - 1)
            elif micro_flag:
                last_sheet_cleanup_penalty += 2
            elif item_area < 220000.0 and item_mx < 650.0:
                last_sheet_cleanup_penalty += 1
        composite = (
            (
                si - 1,
                self._density_bucket(si - 1),
                spill_right_anchor_penalty,
                last_sheet_cleanup_penalty,
                micro_flag,
                -item_area,
                -item_mx,
                -item_mn,
            )
            + pc.score
            + (float(pi),)
        )
        return composite

    def _pending_choice(self) -> Tuple[Optional[int], Optional[_PlaceChoice]]:
        best_pending_idx: Optional[int] = None
        best_choice: Optional[_PlaceChoice] = None
        best_composite: Optional[Tuple[float, ...]] = None
        evaluated_keys: Set[Tuple[Any, ...]] = set()
        for pi, item in enumerate(self.pending):
            item_key = _packing_equivalence_key(item)
            if item_key in evaluated_keys:
                if self.prof:
                    self.prof.add("pack_k.equivalent_pending_evaluations_skipped", 1)
                continue
            evaluated_keys.add(item_key)
            if self.prof:
                self.prof.add("pack_k.pending_items_scanned", 1)
            iw = item["w"]
            ih = item["h"]
            rot_allowed = item["rot_allowed"]
            for si, free in enumerate(self.sheets_free, start=1):
                if self.prof:
                    self.prof.add("pack_k.sheet_choice_checks", 1)
                choice = _best_choice_for_item(
                    free, iw, ih, rot_allowed, self.sheet_existing[si - 1], self.usable_w, self.usable_h
                )
                if choice is None:
                    continue
                x, y, rot, score = choice
                placed_w = iw if rot == 0 else ih
                placed_h = ih if rot == 0 else iw
                pc = _PlaceChoice(sheet_idx=si, x=x, y=y, w=placed_w, h=placed_h, rot=rot, score=score)
                composite = self._pending_score(item, pi, pc)
                if best_composite is None or composite < best_composite:
                    best_composite = composite
                    best_pending_idx = pi
                    best_choice = pc
        return (best_pending_idx, best_choice)

    def _anchor_choice(self, new_sheet_idx: int) -> Tuple[Optional[int], Optional[_PlaceChoice]]:
        anchor_idx: Optional[int] = None
        anchor_choice: Optional[_PlaceChoice] = None
        anchor_composite: Optional[Tuple[float, ...]] = None
        evaluated_anchor_keys: Set[Tuple[Any, ...]] = set()
        for pi, item in enumerate(self.pending):
            item_key = _packing_equivalence_key(item)
            if item_key in evaluated_anchor_keys:
                if self.prof:
                    self.prof.add("pack_k.equivalent_anchor_evaluations_skipped", 1)
                continue
            evaluated_anchor_keys.add(item_key)
            iw = item["w"]
            ih = item["h"]
            rot_allowed = item["rot_allowed"]
            choice = _best_choice_for_item(
                self.sheets_free[-1],
                iw,
                ih,
                rot_allowed,
                self.sheet_existing[-1],
                self.usable_w,
                self.usable_h,
            )
            if choice is None:
                continue
            x, y, rot, score = choice
            placed_w = iw if rot == 0 else ih
            placed_h = ih if rot == 0 else iw
            area = item["area"]
            item["mn"]
            mx = item["mx"]
            micro_flag = item["micro_flag"]
            anchor_penalty = 0
            right_gap = abs(x + placed_w - self.usable_w)
            touches_right = right_gap <= 1e-06
            touches_bottom = y <= 1e-06
            if not touches_right:
                if right_gap > 220.0:
                    anchor_penalty += 3
                elif right_gap > 100.0:
                    anchor_penalty += 2
                elif right_gap > 40.0:
                    anchor_penalty += 1
            if not touches_bottom and y > 180.0:
                anchor_penalty += 1
            if touches_right:
                anchor_penalty = max(0, anchor_penalty - 2)
            if touches_right and touches_bottom:
                anchor_penalty = max(0, anchor_penalty - 1)
            startup_cleanup_penalty = 0
            if new_sheet_idx > 1:
                if not touches_right:
                    if right_gap > 260.0:
                        startup_cleanup_penalty += 3
                    elif right_gap > 120.0:
                        startup_cleanup_penalty += 2
                    elif right_gap > 40.0:
                        startup_cleanup_penalty += 1
                if not touches_bottom and y > 220.0:
                    startup_cleanup_penalty += 1
                if micro_flag:
                    startup_cleanup_penalty += 2
                if touches_right:
                    startup_cleanup_penalty = max(0, startup_cleanup_penalty - 2)
                if touches_right and touches_bottom:
                    startup_cleanup_penalty = max(0, startup_cleanup_penalty - 1)
            composite = (
                (micro_flag, anchor_penalty, startup_cleanup_penalty, -area, -mx) + score + (float(pi),)
            )
            if anchor_composite is None or composite < anchor_composite:
                anchor_composite = composite
                anchor_idx = pi
                anchor_choice = _PlaceChoice(
                    sheet_idx=new_sheet_idx, x=x, y=y, w=placed_w, h=placed_h, rot=rot, score=composite
                )
        return (anchor_idx, anchor_choice)

    def run(self) -> Optional[List[Placement]]:
        self._emit_attempt_progress("Nestings berekenen…", force=True)
        iteration = 0
        while self.pending:
            iteration += 1
            if self.prof and (iteration <= 5 or iteration % 25 == 0 or len(self.pending) <= 5):
                self.prof.event(
                    "pack_k.iteration",
                    iteration=iteration,
                    pending=len(self.pending),
                    openSheets=len(self.sheets_free),
                    placed=self.total_items - len(self.pending),
                )
            best_pending_idx, best_choice = self._pending_choice()
            if best_pending_idx is not None and best_choice is not None:
                item = self.pending.pop(best_pending_idx)
                self._commit(item, best_choice)
                self._emit_attempt_progress("Nestings berekenen…")
                continue
            if len(self.sheets_free) >= self.k:
                return None
            self.sheets_free.append([_FreeRect(0.0, 0.0, self.usable_w, self.usable_h)])
            self.sheet_existing.append([])
            self.sheet_used_area.append(0.0)
            anchor_idx, anchor_choice = self._anchor_choice(len(self.sheets_free))
            if anchor_idx is None or anchor_choice is None:
                return None
            item = self.pending.pop(anchor_idx)
            self._commit(item, anchor_choice)
            self._emit_attempt_progress("Nestings berekenen…")
        self._emit_attempt_progress("Nestings berekenen…", force=True)
        return self.placements
