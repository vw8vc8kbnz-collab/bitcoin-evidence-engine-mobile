"""Progress responsibilities for the production optimizer."""

from __future__ import annotations
from metod_app.observability.failures import report_recovery
import os
from pathlib import Path
from typing import Any, Dict, List
from safety_contracts import strict_json_dumps
from .common import ensure_dir, now_iso
from .models import Instance


def _atomic_progress_write_json(path: Path, payload: Dict[str, Any]) -> None:
    """Atomically publish transient progress without forcing storage flushes.

    Progress and the in-flight report are replaceable UI snapshots. Fsyncing both
    files on every packer callback caused hundreds of synchronous disk barriers on
    VPS storage. Final report/manifests/production DXFs still use durable_write_json
    or durable_write_text and remain covered by the finalization hashes.
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.progress.{os.getpid()}")
    try:
        tmp.write_text(strict_json_dumps(payload, indent=2) + "\n", encoding="utf-8")
        os.replace(tmp, path)
    finally:
        try:
            tmp.unlink(missing_ok=True)
        except (OSError, ValueError, TypeError, OverflowError) as recovery_error:
            report_recovery("dxf_nesting_optimizer._atomic_progress_write_json.2173", recovery_error)


def _write_progress_snapshot(output_dir: Path, payload: Dict[str, Any]) -> None:
    try:
        _atomic_progress_write_json(output_dir / "progress.json", payload)
    except Exception as recovery_error:
        report_recovery("dxf_nesting_optimizer._write_progress_snapshot.2180", recovery_error)


def _optimizer_material_work_units(instances: List[Instance]) -> int:
    """Return deterministic work units for one material's measured progress slice.

    Pairwise lower-bound analysis is quadratic and dominates larger jobs. Using
    the square of the instance count therefore gives mixed-material jobs stable
    global progress without pretending to predict elapsed wall-clock time.
    """
    count = max(1, len(instances))
    return count * count


def _map_material_progress(
    completed_units: int, material_units: int, total_units: int, local_fraction: float
) -> float:
    """Map completed work in one material to the global optimizer band 8..96."""
    total = max(1, int(total_units))
    completed = max(0, min(total, int(completed_units)))
    current = max(1, int(material_units))
    local = max(0.0, min(1.0, float(local_fraction)))
    return 8.0 + 88.0 * min(1.0, (completed + current * local) / float(total))


def write_progress_report(
    output_dir: Path, report: Dict[str, Any], percent: float, phase: str, message: str = ""
) -> None:
    try:
        ensure_dir(output_dir)
        progress_payload = {
            "percent": max(0, min(100, int(round(float(percent))))),
            "phase": str(phase or "").strip(),
            "message": str(message or phase or "").strip(),
            "updatedAt": now_iso(),
        }
        report["progress"] = progress_payload
        _write_progress_snapshot(output_dir, progress_payload)
        _atomic_progress_write_json(output_dir / "report.json", report)
    except Exception as recovery_error:
        report_recovery("dxf_nesting_optimizer.write_progress_report.2224", recovery_error)
