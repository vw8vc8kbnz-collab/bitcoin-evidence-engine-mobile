"""Common responsibilities for the production optimizer."""

from __future__ import annotations
import re
import time
from pathlib import Path
from typing import Any, Dict


def safe_slug(s: str) -> str:
    """Make a filesystem-safe slug for filenames."""
    s = str(s or "").strip()
    s = re.sub("\\s+", "_", s)
    s = re.sub("[^A-Za-z0-9_\\-.]+", "_", s)
    s = re.sub("_+", "_", s)
    s = s.strip("._-")
    return s or "NA"


def now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")


def ensure_dir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)


def round01(x: float) -> float:
    return round(float(x), 1)


def fatal(report: Dict[str, Any], msg: str) -> None:
    report.setdefault("errors", []).append(msg)
    raise RuntimeError(msg)


def warn(report: Dict[str, Any], msg: str) -> None:
    report.setdefault("warnings", []).append(msg)
