"""Heuristics responsibilities for the production optimizer."""

from __future__ import annotations
from metod_app.observability.failures import report_recovery
import itertools
import math
import time
from typing import Any, Dict, List, Optional, Set, Tuple
from .common import round01
from .models import Instance, Placement, _FreeRect
from .profiling import _profiler


def _sort_key_variant(inst: Instance, variant: str) -> Tuple[float, float, float, str, int]:
    """Deterministic sort keys for multi-pass heuristics."""
    w = float(inst.w)
    h = float(inst.h)
    area = w * h
    mx = max(w, h)
    mn = min(w, h)
    gg = str(inst.row.GrainGroup or "").strip()
    gg_flag = 0 if gg else 1
    if variant == "area_desc":
        return (-area, -mx, -mn, inst.row.PartId, inst.idx)
    if variant == "max_side_desc":
        return (-mx, -mn, -area, inst.row.PartId, inst.idx)
    if variant == "height_desc":
        return (-h, -w, -area, inst.row.PartId, inst.idx)
    if variant == "width_desc":
        return (-w, -h, -area, inst.row.PartId, inst.idx)
    return (gg_flag, -mx, -mn, -area, inst.row.PartId, inst.idx)


def _item_sort_key(it: dict, variant: str) -> tuple:
    """Return a fully comparable deterministic sort key for both single items and GrainGroup stacks.

    IMPORTANT: All returned tuples have identical length and type layout to avoid
    TypeError during sorting (e.g. float vs str comparisons).
    Layout:
      (kind_flag:int, a:float, b:float, c:float, d:float, group:str, partId:str, idx:int)
    kind_flag: 0=single, 1=group
    """
    if it.get("kind") == "single":
        inst = it["members"][0]
        w = float(it.get("w", 0.0))
        h = float(it.get("h", 0.0))
        area = w * h
        mn = min(w, h)
        mx = max(w, h)
        tail_part = str(inst.row.PartId)
        tail_idx = int(inst.idx)
        if variant == "density_first":
            micro_flag = 1 if area <= 120000.0 or mn <= 120.0 or (mx >= 320.0 and mn <= 160.0) else 0
            slender_flag = 1 if mn <= 180.0 and mx >= 2.4 * max(1.0, mn) else 0
            return (0, float(micro_flag), float(slender_flag), -area, -mx, "", tail_part, tail_idx)
        sk = _sort_key_variant(inst, variant)
        nums = []
        for x in sk:
            if isinstance(x, (int, float)):
                nums.append(float(x))
            else:
                break
        while len(nums) < 4:
            nums.append(0.0)
        a, b, c, d = (nums[0], nums[1], nums[2], nums[3])
        return (0, a, b, c, d, "", tail_part, tail_idx)
    else:
        h = float(it.get("h", 0.0))
        w = float(it.get("w", 0.0))
        group = str(it.get("group", ""))
        inst = it["members"][0]
        part = str(inst.row.PartId)
        idx = int(inst.idx)
        if variant == "density_first":
            return (1, 0.0, 0.0, -(w * h), -max(w, h), group, part, idx)
        return (1, -h, -w, 0.0, 0.0, group, part, idx)


def _rect_contains(a: _FreeRect, b: _FreeRect) -> bool:
    return b.x >= a.x and b.y >= a.y and (b.x + b.w <= a.x + a.w) and (b.y + b.h <= a.y + a.h)


def _split_free_rect(f: _FreeRect, px: float, py: float, pw: float, ph: float) -> List[_FreeRect]:
    """Split a free rect by removing the placed rect area; returns up to 4 rects."""
    out: List[_FreeRect] = []
    fx, fy, fw, fh = (f.x, f.y, f.w, f.h)
    if px >= fx + fw or px + pw <= fx or py >= fy + fh or (py + ph <= fy):
        return [f]
    if px > fx:
        out.append(_FreeRect(fx, fy, px - fx, fh))
    if px + pw < fx + fw:
        out.append(_FreeRect(px + pw, fy, fx + fw - (px + pw), fh))
    if py > fy:
        out.append(_FreeRect(fx, fy, fw, py - fy))
    if py + ph < fy + fh:
        out.append(_FreeRect(fx, py + ph, fw, fy + fh - (py + ph)))
    out2 = [r for r in out if r.w > 0.0001 and r.h > 0.0001]
    return out2


def _prune_free_rects(free: List[_FreeRect]) -> List[_FreeRect]:
    """Remove contained rectangles. Deterministic: stable by area desc then x/y."""
    free = sorted(free, key=lambda r: (-(r.w * r.h), r.y, r.x, r.w, r.h))
    kept: List[_FreeRect] = []
    for r in free:
        contained = False
        for k in kept:
            if _rect_contains(k, r):
                contained = True
                break
        if not contained:
            kept.append(r)
    kept = sorted(kept, key=lambda r: (r.y, r.x, r.w, r.h))
    return kept


def _band_clustering_penalty(
    existing: List[Tuple[float, float, float, float]], x: float, y: float, w: float, h: float
) -> int:
    """Mild deterministic penalty for scattering slim / filler-like parts.

    Prefer when skinny parts form compact bands by sharing an edge and having
    broadly similar span. This nudges small fillers into cleaner zones without
    rewriting the packing algorithm.
    """
    if not existing:
        return 1
    eps = 1e-06
    is_slim = min(w, h) <= 180.0 or max(w, h) / max(1.0, min(w, h)) >= 3.0
    if not is_slim:
        return 0
    aligned_contacts = 0
    near_band = 0
    for ex, ey, ew, eh in existing:
        if abs(x + w - ex) <= eps or abs(ex + ew - x) <= eps:
            overlap_h = max(0.0, min(y + h, ey + eh) - max(y, ey))
            if overlap_h >= min(h, eh) * 0.6:
                aligned_contacts += 1
            elif overlap_h >= min(h, eh) * 0.3:
                near_band += 1
        if abs(y + h - ey) <= eps or abs(ey + eh - y) <= eps:
            overlap_w = max(0.0, min(x + w, ex + ew) - max(x, ex))
            if overlap_w >= min(w, ew) * 0.6:
                aligned_contacts += 1
            elif overlap_w >= min(w, ew) * 0.3:
                near_band += 1
    if aligned_contacts >= 1:
        return 0
    if near_band >= 1:
        return 1
    return 2


def _edge_cleanup_penalty(fr: _FreeRect, w: float, h: float, usable_w: float, usable_h: float) -> int:
    """Prefer filler-like parts to clean up bottom/right edges, but avoid
    consuming the floor of a tall narrow column when that strands a large empty
    cavity above.
    """
    eps = 1e-06
    is_filler = w * h <= 180000.0 or min(w, h) <= 180.0 or max(w, h) / max(1.0, min(w, h)) >= 3.0
    if not is_filler:
        return 0
    leftover_w = max(0.0, fr.w - w)
    leftover_h = max(0.0, fr.h - h)
    touches_bottom = fr.y <= eps
    touches_right = abs(fr.x + fr.w - usable_w) <= eps and leftover_w <= eps
    penalty = 1
    if touches_bottom or touches_right:
        penalty = 0
    if leftover_w <= eps and leftover_h > max(220.0, 2.5 * h):
        penalty += 2
        if leftover_h > max(420.0, 4.0 * h):
            penalty += 1
    if not touches_bottom and (not touches_right) and (leftover_h > 120.0) and (leftover_w > 120.0):
        penalty += 1
    return penalty


def _internal_void_compaction_penalty(
    existing: List[Tuple[float, float, float, float]],
    fr: _FreeRect,
    x: float,
    y: float,
    w: float,
    h: float,
    usable_w: float,
    usable_h: float,
) -> int:
    """Prefer placements that tighten the overall mass and reduce interior air.

    This is a small deterministic nudge, not a rewrite of the packer:
    - reward candidates that sit clearly against existing neighbours
    - discourage isolated placements that leave a floating interior cavity
    - keep the effect modest so earlier exact-fit / sliver / edge heuristics stay dominant
    """
    if not existing:
        return 0
    near_gap = 14.5
    strong_contacts = 0
    weak_contacts = 0
    shared_span_max = 0.0
    for ex, ey, ew, eh in existing:
        dx = min(abs(x + w - ex), abs(ex + ew - x))
        overlap_h = max(0.0, min(y + h, ey + eh) - max(y, ey))
        min_h = max(1.0, min(h, eh))
        if dx <= near_gap:
            if overlap_h >= 0.55 * min_h:
                strong_contacts += 1
                shared_span_max = max(shared_span_max, overlap_h)
            elif overlap_h >= 0.25 * min_h:
                weak_contacts += 1
                shared_span_max = max(shared_span_max, overlap_h)
        dy = min(abs(y + h - ey), abs(ey + eh - y))
        overlap_w = max(0.0, min(x + w, ex + ew) - max(x, ex))
        min_w = max(1.0, min(w, ew))
        if dy <= near_gap:
            if overlap_w >= 0.55 * min_w:
                strong_contacts += 1
                shared_span_max = max(shared_span_max, overlap_w)
            elif overlap_w >= 0.25 * min_w:
                weak_contacts += 1
                shared_span_max = max(shared_span_max, overlap_w)
    leftover_w = max(0.0, fr.w - w)
    leftover_h = max(0.0, fr.h - h)
    leaves_2d_cavity = leftover_w > 90.0 and leftover_h > 90.0
    interior_float = x > 80.0 and y > 80.0 and (x + w < usable_w - 80.0) and (y + h < usable_h - 80.0)
    penalty = 0
    if strong_contacts >= 2:
        penalty -= 2
    elif strong_contacts >= 1:
        penalty -= 1
    elif weak_contacts >= 2:
        penalty -= 1
    if strong_contacts == 0 and weak_contacts == 0:
        penalty += 2
    elif strong_contacts == 0 and weak_contacts == 1:
        penalty += 1
    if leaves_2d_cavity and strong_contacts == 0:
        penalty += 1
    if interior_float and strong_contacts == 0 and (weak_contacts == 0):
        penalty += 1
    if shared_span_max >= 260.0:
        penalty -= 1
    return penalty


def _item_orientation_options(it: Dict[str, Any]) -> List[Tuple[float, float]]:
    w = float(it["w"])
    h = float(it["h"])
    if not bool(it.get("rot_allowed")) or abs(w - h) <= 1e-09:
        return [(w, h)]
    return [(w, h), (h, w)]


def _pair_can_share_sheet(
    item_a: Dict[str, Any], item_b: Dict[str, Any], usable_w: float, usable_h: float
) -> bool:
    """Return True when two items can fit together on one sheet in at least one legal orientation pair.

    For two axis-aligned rectangles inside a bounding rectangle, a feasible non-overlapping packing
    exists iff one can be placed left/right of the other or above/below the other. This makes the
    simple side-by-side / stacked checks exact for a pair.
    """
    for aw, ah in _item_orientation_options(item_a):
        for bw, bh in _item_orientation_options(item_b):
            if max(ah, bh) <= usable_h + 1e-09 and aw + bw <= usable_w + 1e-09:
                return True
            if max(aw, bw) <= usable_w + 1e-09 and ah + bh <= usable_h + 1e-09:
                return True
    return False


def _greedy_incompatibility_clique_bound(
    items: List[Dict[str, Any]], usable_w: float, usable_h: float, progress_cb=None
) -> int:
    """Cheap deterministic lower bound from a pairwise incompatibility clique.

    Any set of items that are pairwise unable to share a sheet forms a clique in the
    incompatibility graph and therefore requires at least that many sheets. The greedy
    clique search here is heuristic, but every clique found is a sound lower bound.
    """
    n = len(items)
    if n <= 1:
        return n
    adj: List[Set[int]] = [set() for _ in range(n)]
    degrees = [0] * n
    item_meta = [(float(it["area"]), float(it["mx"]), float(it["mn"])) for it in items]
    total_pairs = max(1, n * (n - 1) // 2)
    completed_pairs = 0
    report_stride = max(1, total_pairs // 80)
    for i in range(n):
        ai = items[i]
        for j in range(i + 1, n):
            if not _pair_can_share_sheet(ai, items[j], usable_w, usable_h):
                adj[i].add(j)
                adj[j].add(i)
                degrees[i] += 1
                degrees[j] += 1
            completed_pairs += 1
            if callable(progress_cb) and (
                completed_pairs == total_pairs or completed_pairs % report_stride == 0
            ):
                try:
                    progress_cb(completed_pairs / float(total_pairs))
                except Exception as recovery_error:
                    report_recovery(
                        "dxf_nesting_optimizer._greedy_incompatibility_clique_bound.762", recovery_error
                    )
    if max(degrees, default=0) == 0:
        return 1

    def _vertex_sort_key(idx: int) -> Tuple[float, float, float, int]:
        area, mx, mn = item_meta[idx]
        return (-degrees[idx], -area, -mx, idx)

    def _candidate_sort_key(idx: int, candidate_pool: Set[int]) -> Tuple[float, float, float, int]:
        area, mx, mn = item_meta[idx]
        local_degree = sum((1 for other in adj[idx] if other in candidate_pool))
        return (-local_degree, -degrees[idx], -area, idx)

    best = 1
    seeds = sorted(range(n), key=_vertex_sort_key)
    for seed in seeds:
        if degrees[seed] + 1 <= best:
            continue
        clique_size = 1
        candidates = set(adj[seed])
        while candidates:
            nxt = min(candidates, key=lambda idx, pool=candidates: _candidate_sort_key(idx, pool))
            clique_size += 1
            if clique_size > best:
                best = clique_size
            candidates &= adj[nxt]
            if clique_size + len(candidates) <= best:
                break
    return max(1, best)


def _best_choice_for_item(
    free: List[_FreeRect],
    iw: float,
    ih: float,
    rot_allowed: bool,
    existing: Optional[List[Tuple[float, float, float, float]]] = None,
    usable_w: Optional[float] = None,
    usable_h: Optional[float] = None,
) -> Optional[
    Tuple[float, float, int, Tuple[float, float, float, float, float, float, float, float, float, float]]
]:
    """Pick best placement in a single sheet's free rect set.

    Heuristic note:
    - still deterministic bottom-left MaxRects
    - gently prefers placements that consume the full width OR full height
      of a free rectangle, because that tends to reduce fragmentation and avoids
      isolated top-right/sliver pockets.
    - also nudges slim filler-like pieces to form compact bands instead of being
      scattered as isolated small islands.
    - for genuinely small filler parts, prefers using a tighter existing gap
      over consuming a very large open zone when both are possible.
    Returns (x,y,rot,score).
    """
    prof = _profiler()
    __t0 = time.perf_counter() if prof else 0.0
    if prof:
        prof.add("best_choice.calls", 1)
    eps = 1e-06
    existing = existing or []
    usable_w_eff_global = usable_w
    usable_h_eff_global = usable_h
    edge_cleanup_fn = _edge_cleanup_penalty
    band_penalty_fn = _band_clustering_penalty
    compaction_penalty_fn = _internal_void_compaction_penalty
    part_area = iw * ih
    min_side_const = iw if iw < ih else ih
    max_side_const = ih if ih > iw else iw
    is_micro_const = part_area <= 90000.0 or min_side_const <= 120.0
    is_tall_anchor_const = max_side_const >= 900.0 or part_area >= 350000.0
    if not rot_allowed or abs(iw - ih) <= eps:
        rot_variants = ((0, iw, ih),)
    else:
        rot_variants = ((0, iw, ih), (90, ih, iw))
    candidates = []
    best_micro_waste = None
    best_micro_rect_area = None
    best_right_anchor = None
    for fr in free:
        fr_x = fr.x
        fr_y = fr.y
        fr_w = fr.w
        fr_h = fr.h
        fr_area = fr_w * fr_h
        usable_w_eff = usable_w_eff_global if usable_w_eff_global is not None else fr_x + fr_w
        usable_h_eff = usable_h_eff_global if usable_h_eff_global is not None else fr_y + fr_h
        for rot, w, h in rot_variants:
            if w > fr_w + eps or h > fr_h + eps:
                continue
            leftover_w = fr_w - w
            if leftover_w < 0.0:
                leftover_w = 0.0
            leftover_h = fr_h - h
            if leftover_h < 0.0:
                leftover_h = 0.0
            short_side = leftover_w if leftover_w < leftover_h else leftover_h
            long_side = leftover_h if leftover_h > leftover_w else leftover_w
            split_penalty = int(leftover_w > eps) + int(leftover_h > eps)
            exact_axis_penalty = 0 if leftover_w <= eps or leftover_h <= eps else 1
            sliver_penalty = 0
            if leftover_w > eps and leftover_h > eps:
                sliver_ratio = short_side / max(1.0, long_side)
                if short_side < 60.0:
                    sliver_penalty += 2
                elif short_side < 120.0:
                    sliver_penalty += 1
                if sliver_ratio < 0.12:
                    sliver_penalty += 2
                elif sliver_ratio < 0.2:
                    sliver_penalty += 1
            edge_cleanup_penalty = edge_cleanup_fn(fr, w, h, usable_w_eff, usable_h_eff)
            band_penalty = band_penalty_fn(existing, fr_x, fr_y, w, h)
            waste_area = fr_area - part_area
            if waste_area < 0.0:
                waste_area = 0.0
            right_gap_eff = usable_w_eff - (fr_x + w)
            if right_gap_eff < 0.0:
                right_gap_eff = 0.0
            top_gap_eff = usable_h_eff - (fr_y + h)
            if top_gap_eff < 0.0:
                top_gap_eff = 0.0
            touches_right_eff = right_gap_eff <= eps
            touches_top_eff = top_gap_eff <= eps
            fill_ratio_eff = part_area / max(1.0, fr_area)
            area_delta_eff = 0.0
            near_exact_hole_eff = False
            if is_micro_const and best_micro_rect_area is not None:
                area_delta_eff = fr_area - best_micro_rect_area
                near_exact_hole_eff = short_side <= 26.0 or exact_axis_penalty == 0
            candidates.append(
                (
                    fr,
                    fr_x,
                    fr_y,
                    rot,
                    w,
                    h,
                    split_penalty,
                    exact_axis_penalty,
                    sliver_penalty,
                    edge_cleanup_penalty,
                    band_penalty,
                    short_side,
                    long_side,
                    waste_area,
                    fr_area,
                    usable_w_eff,
                    usable_h_eff,
                    right_gap_eff,
                    top_gap_eff,
                    touches_right_eff,
                    touches_top_eff,
                    fill_ratio_eff,
                    area_delta_eff,
                    near_exact_hole_eff,
                )
            )
            if is_micro_const:
                if best_micro_waste is None or waste_area < best_micro_waste:
                    best_micro_waste = waste_area
                if best_micro_rect_area is None or fr_area < best_micro_rect_area:
                    best_micro_rect_area = fr_area
            if is_tall_anchor_const:
                right_gap_anchor = usable_w_eff - (fr_x + w)
                if right_gap_anchor < 0.0:
                    right_gap_anchor = -right_gap_anchor
                right_anchor = (right_gap_anchor, fr_y, short_side, long_side)
                if best_right_anchor is None or right_anchor < best_right_anchor:
                    best_right_anchor = right_anchor
    if not candidates:
        return None
    best = None
    usable_w_is_not_none = usable_w is not None
    for (
        fr,
        fr_x,
        fr_y,
        rot,
        w,
        h,
        split_penalty,
        exact_axis_penalty,
        sliver_penalty,
        edge_cleanup_penalty,
        band_penalty,
        short_side,
        long_side,
        waste_area,
        fr_area,
        usable_w_eff,
        usable_h_eff,
        right_gap_eff,
        top_gap_eff,
        touches_right_eff,
        touches_top_eff,
        fill_ratio_eff,
        area_delta_eff,
        near_exact_hole_eff,
    ) in candidates:
        micro_gap_penalty = 0
        if is_micro_const and best_micro_waste is not None:
            fill_ratio = fill_ratio_eff
            waste_delta = waste_area - best_micro_waste
            if waste_delta > 180000.0:
                micro_gap_penalty += 2
            elif waste_delta > 60000.0:
                micro_gap_penalty += 1
            if fill_ratio < 0.45:
                micro_gap_penalty += 1
            if fill_ratio < 0.25:
                micro_gap_penalty += 1
            if best_micro_rect_area is not None:
                area_delta = area_delta_eff
                near_exact_hole = near_exact_hole_eff
                if area_delta > 180000.0:
                    micro_gap_penalty += 4
                elif area_delta > 90000.0:
                    micro_gap_penalty += 3
                elif area_delta > 30000.0:
                    micro_gap_penalty += 2
                elif area_delta > 10000.0:
                    micro_gap_penalty += 1
                if not near_exact_hole and fill_ratio < 0.6:
                    micro_gap_penalty += 1
                if not near_exact_hole and fill_ratio < 0.4:
                    micro_gap_penalty += 1
                if near_exact_hole and area_delta <= 30000.0:
                    micro_gap_penalty = max(0, micro_gap_penalty - 2)
        right_anchor_penalty = 0
        if is_tall_anchor_const and usable_w_is_not_none and (best_right_anchor is not None):
            right_gap = right_gap_eff
            touches_right = touches_right_eff
            touches_bottom = fr_y <= 1e-06
            if not touches_right:
                if right_gap > 220.0:
                    right_anchor_penalty += 2
                elif right_gap > 80.0:
                    right_anchor_penalty += 1
            if not touches_bottom and fr_y > 220.0:
                right_anchor_penalty += 1
            best_gap, best_y, _, _ = best_right_anchor
            if right_gap - best_gap > 120.0:
                right_anchor_penalty += 1
            if fr_y - best_y > 180.0:
                right_anchor_penalty += 1
            if touches_right:
                right_anchor_penalty = max(0, right_anchor_penalty - 2)
            if touches_right and touches_bottom:
                right_anchor_penalty = max(0, right_anchor_penalty - 1)
        topband_penalty = 0
        right_gap = right_gap_eff
        top_gap = top_gap_eff
        touches_right = touches_right_eff
        touches_top = touches_top_eff
        is_horizontal_strip = w >= max(320.0, 1.8 * h) and h <= 220.0 and (part_area <= 260000.0)
        if is_horizontal_strip and top_gap <= max(140.0, 1.35 * h):
            topband_penalty += 1
            if top_gap <= max(60.0, 0.75 * h):
                topband_penalty += 1
            if right_gap > 120.0:
                topband_penalty += 1
            if fr_x < 0.72 * usable_w_eff:
                topband_penalty += 1
            if exact_axis_penalty != 0 and short_side > 18.0:
                topband_penalty += 1
            if touches_right and touches_top:
                topband_penalty = max(0, topband_penalty - 3)
            elif touches_right and right_gap <= 40.0:
                topband_penalty = max(0, topband_penalty - 2)
            elif exact_axis_penalty == 0 and right_gap <= 80.0:
                topband_penalty = max(0, topband_penalty - 1)
        compaction_penalty = compaction_penalty_fn(existing, fr, fr_x, fr_y, w, h, usable_w_eff, usable_h_eff)
        score = (
            split_penalty,
            exact_axis_penalty,
            sliver_penalty,
            edge_cleanup_penalty,
            band_penalty,
            micro_gap_penalty,
            right_anchor_penalty,
            topband_penalty,
            compaction_penalty,
            short_side,
            long_side,
            fr_y,
            fr_x,
        )
        cand = (fr_x, fr_y, rot, score)
        if best is None or cand[3] < best[3]:
            best = cand
    if prof:
        prof.add("best_choice.candidates_considered", len(candidates))
        prof.add("best_choice.seconds_total", max(0.0, time.perf_counter() - __t0))
    return best


def _packing_equivalence_key(item: Dict[str, Any]) -> Tuple[Any, ...]:
    """Return the complete geometry/scoring identity of one pending pack item."""
    return (
        str(item.get("kind") or ""),
        float(item.get("w") or 0.0),
        float(item.get("h") or 0.0),
        bool(item.get("rot_allowed")),
        float(item.get("area") or 0.0),
        float(item.get("mn") or 0.0),
        float(item.get("mx") or 0.0),
        int(item.get("micro_flag") or 0),
    )


def _homogeneous_grid_candidate(
    items: List[Dict[str, Any]], sheet_w: float, sheet_h: float, margin: float, gap: float
) -> Optional[Tuple[List[Placement], int, int, Dict[str, Any]]]:
    """Build a deterministic compact grid for equal single panels.

    MaxRects is still allowed to improve this upper bound. This candidate fixes the
    common 100–250 identical-front case where scoring could create an unnecessary
    spill sheet despite a simple legal regular grid being available.
    """
    if not items or not all((str(it.get("kind") or "") == "single" for it in items)):
        return None
    first_key = _packing_equivalence_key(items[0])
    if not all((_packing_equivalence_key(it) == first_key for it in items)):
        return None
    usable_w = float(sheet_w) - 2.0 * float(margin)
    usable_h = float(sheet_h) - 2.0 * float(margin)
    w0 = float(items[0]["w"])
    h0 = float(items[0]["h"])
    orientations = [(w0, h0, 0)]
    if bool(items[0].get("rot_allowed")) and abs(w0 - h0) > 1e-09:
        orientations.append((h0, w0, 90))
    best_pattern = None
    best_score = None
    candidate_budget_per_axis = 32768
    for axis_tie, extent, cross_extent in ((1, usable_w, usable_h), (0, usable_h, usable_w)):
        band_sizes = [ow if axis_tie else oh for ow, oh, _rot in orientations]
        cross_sizes = [oh if axis_tie else ow for ow, oh, _rot in orientations]
        pitches = [size + gap for size in band_sizes]
        max_counts = [max(0, int(math.floor((extent + gap + 1e-09) / pitch))) for pitch in pitches]
        per_band = [
            max(0, int(math.floor((cross_extent + gap + 1e-09) / (size + gap)))) for size in cross_sizes
        ]
        scan_index = min(range(len(orientations)), key=lambda index: max_counts[index])
        fill_index = 1 - scan_index if len(orientations) == 2 else None
        scan_max = max_counts[scan_index]
        if fill_index is None:
            scan_counts = (scan_max,)
        elif scan_max + 1 <= candidate_budget_per_axis:
            scan_counts = range(scan_max + 1)
        else:
            scan_counts = (
                index * scan_max // (candidate_budget_per_axis - 1)
                for index in range(candidate_budget_per_axis)
            )
        for scan_count in scan_counts:
            counts = [0] * len(orientations)
            counts[scan_index] = scan_count
            if fill_index is not None and per_band[fill_index] > 0:
                remaining = extent + gap - scan_count * pitches[scan_index]
                counts[fill_index] = max(0, int(math.floor((remaining + 1e-09) / pitches[fill_index])))
            band_count = sum(counts)
            used_extent = sum((count * band_sizes[index] for index, count in enumerate(counts))) + gap * (
                band_count - 1
            )
            if used_extent > extent + 1e-09 and fill_index is not None and (counts[fill_index] > 0):
                counts[fill_index] -= 1
                band_count -= 1
                used_extent -= pitches[fill_index]
            if band_count <= 0 or used_extent > extent + 1e-09:
                continue
            capacity = sum((count * per_band[index] for index, count in enumerate(counts)))
            score = (capacity, axis_tie, tuple((-count for count in counts)))
            if capacity > 0 and (best_score is None or score > best_score):
                best_score = score
                best_pattern = (capacity, axis_tie, tuple(counts), tuple(per_band))
    if best_pattern is None:
        return None
    capacity, axis_tie, counts, per_band = best_pattern

    def selected_slots():
        cursor = 0.0
        for index, count in enumerate(counts):
            placed_w, placed_h, rotation = orientations[index]
            pitch = (placed_w if axis_tie else placed_h) + gap
            if per_band[index] == 0:
                cursor += count * pitch
                continue
            for _band in range(count):
                for cross in range(per_band[index]):
                    if axis_tie:
                        yield (cursor, cross * (placed_h + gap), rotation)
                    else:
                        yield (cross * (placed_w + gap), cursor, rotation)
                cursor += pitch

    slots = list(itertools.islice(selected_slots(), min(len(items), capacity)))
    placements: List[Placement] = []
    for index, item in enumerate(items):
        sheet_index = index // capacity + 1
        slot = index % capacity
        slot_x, slot_y, rotation = slots[slot]
        inst: Instance = item["members"][0]
        placements.append(
            Placement(
                partId=inst.row.PartId,
                instanceIndex=inst.idx,
                sheetIndex=sheet_index,
                x=round01(float(margin) + slot_x),
                y=round01(float(margin) + slot_y),
                rotationDeg=int(rotation),
                widthMm=float(inst.row.WidthMm),
                lengthMm=float(inst.row.LengthMm),
                materialCode=inst.row.MaterialCode,
                thicknessMm=float(inst.row.ThicknessMm),
                edge={"H1": inst.row.H1, "H2": inst.row.H2, "W1": inst.row.W1, "W2": inst.row.W2},
            )
        )
    sheets_used = max((p.sheetIndex for p in placements), default=1)
    return (
        placements,
        int(sheets_used),
        int(capacity),
        {
            "axis": "vertical" if axis_tie == 1 else "horizontal",
            "orientationCounts": list(counts),
            "rotationsUsed": sorted(
                {
                    orientations[index][2]
                    for index, count in enumerate(counts)
                    if count > 0 and per_band[index] > 0
                }
            ),
        },
    )
