"""Packing responsibilities for the production optimizer."""

from __future__ import annotations
from metod_app.observability.failures import report_recovery
import math
import os
import time
from typing import Any, Dict, List, Optional, Tuple
from .common import fatal, round01
from .heuristics import (
    _best_choice_for_item,
    _greedy_incompatibility_clique_bound,
    _homogeneous_grid_candidate,
    _item_sort_key,
    _packing_equivalence_key,
    _prune_free_rects,
    _split_free_rect,
)
from .models import Instance, Placement, _FreeRect
from .profiling import _profiler
from .packing_attempt import PackingAttempt


def _maxrects_pack_k(
    items: List[Dict[str, Any]],
    sheet_w: float,
    sheet_h: float,
    margin: float,
    gap: float,
    k: int,
    report: Dict[str, Any],
    progress_cb=None,
) -> Optional[List[Placement]]:
    """Pack into at most k sheets with the established deterministic scoring."""
    return PackingAttempt(items, sheet_w, sheet_h, margin, gap, k, report, progress_cb).run()


def _placement_bbox_usable(p: Placement, margin: float) -> Tuple[float, float, float, float]:
    """Return placement bbox in usable-sheet coordinates (margin removed)."""
    if int(p.rotationDeg) == 90:
        w = float(p.lengthMm)
        h = float(p.widthMm)
    else:
        w = float(p.widthMm)
        h = float(p.lengthMm)
    return (float(p.x) - margin, float(p.y) - margin, w, h)


def _rebuild_free_rects_for_sheet(
    sheet_placements: List[Placement],
    sheet_w: float,
    sheet_h: float,
    margin: float,
    gap: float,
    exclude_local_index: Optional[int] = None,
) -> Tuple[List[_FreeRect], List[Tuple[float, float, float, float]]]:
    usable_w = sheet_w - 2 * margin
    usable_h = sheet_h - 2 * margin
    free: List[_FreeRect] = [_FreeRect(0.0, 0.0, usable_w, usable_h)]
    existing: List[Tuple[float, float, float, float]] = []
    for li, p in enumerate(sheet_placements):
        if exclude_local_index is not None and li == exclude_local_index:
            continue
        x, y, w, h = _placement_bbox_usable(p, margin)
        existing.append((x, y, w, h))
        cut_x1 = max(0.0, x - gap)
        cut_y1 = max(0.0, y - gap)
        cut_x2 = min(usable_w, x + w + gap)
        cut_y2 = min(usable_h, y + h + gap)
        cut_w = max(0.0, cut_x2 - cut_x1)
        cut_h = max(0.0, cut_y2 - cut_y1)
        new_free: List[_FreeRect] = []
        for fr in free:
            new_free.extend(_split_free_rect(fr, cut_x1, cut_y1, cut_w, cut_h))
        free = _prune_free_rects(new_free)
    return (free, existing)


def _postpass_repack_micro_fillers(
    placements: List[Placement], sheet_w: float, sheet_h: float, margin: float, gap: float
) -> None:
    """Local same-sheet tidy-up for genuinely small filler parts.

    After the main greedy packing, very small parts may still sit in larger open
    zones while tiny fitted holes exist elsewhere. This post-pass removes one
    micro part at a time, rebuilds sheet free-rects against the fixed remainder,
    and asks the existing scorer for the best same-orientation spot. Only actual
    moves are applied, so the main algorithm remains intact and deterministic.
    """
    by_sheet: Dict[int, List[int]] = {}
    for gi, p in enumerate(placements):
        by_sheet.setdefault(int(p.sheetIndex), []).append(gi)
    for sheet_idx, global_indices in by_sheet.items():
        if len(global_indices) < 2:
            continue
        local_pls = [placements[gi] for gi in global_indices]

        def _is_micro_candidate(p: Placement) -> bool:
            x, y, w, h = _placement_bbox_usable(p, margin)
            area = w * h
            mn = min(w, h)
            mx = max(w, h)
            return area <= 120000.0 or mn <= 140.0 or (mn <= 180.0 and mx <= 500.0)

        candidate_order = [li for li, p in enumerate(local_pls) if _is_micro_candidate(p)]
        candidate_order.sort(
            key=lambda li: (
                _placement_bbox_usable(local_pls[li], margin)[2]
                * _placement_bbox_usable(local_pls[li], margin)[3],
                local_pls[li].y,
                local_pls[li].x,
            )
        )
        for _pass in range(4):
            moved_any = False
            for li in candidate_order:
                p = local_pls[li]
                x0, y0, w, h = _placement_bbox_usable(p, margin)
                free, existing = _rebuild_free_rects_for_sheet(
                    local_pls, sheet_w, sheet_h, margin, gap, exclude_local_index=li
                )
                choice = _best_choice_for_item(
                    free, w, h, False, existing, sheet_w - 2 * margin, sheet_h - 2 * margin
                )
                if choice is None:
                    continue
                nx, ny, rot, score = choice
                if abs(nx - x0) <= 1e-06 and abs(ny - y0) <= 1e-06:
                    continue
                current_free, _ = _rebuild_free_rects_for_sheet(
                    local_pls, sheet_w, sheet_h, margin, gap, exclude_local_index=li
                )
                current_host_area = None
                for fr in current_free:
                    if (
                        x0 >= fr.x - 1e-06
                        and y0 >= fr.y - 1e-06
                        and (x0 + w <= fr.x + fr.w + 1e-06)
                        and (y0 + h <= fr.y + fr.h + 1e-06)
                    ):
                        a = fr.w * fr.h
                        if current_host_area is None or a < current_host_area:
                            current_host_area = a
                target_host_area = None
                for fr in free:
                    if (
                        nx >= fr.x - 1e-06
                        and ny >= fr.y - 1e-06
                        and (nx + w <= fr.x + fr.w + 1e-06)
                        and (ny + h <= fr.y + fr.h + 1e-06)
                    ):
                        a = fr.w * fr.h
                        if target_host_area is None or a < target_host_area:
                            target_host_area = a
                improves_tightness = (
                    current_host_area is not None
                    and target_host_area is not None
                    and (target_host_area + 5000.0 < current_host_area)
                )
                touches_edge = ny <= 1e-06 or abs(nx + w - (sheet_w - 2 * margin)) <= 1e-06
                current_fill_ratio = None
                target_fill_ratio = None
                part_area = w * h
                if current_host_area and current_host_area > 0:
                    current_fill_ratio = part_area / current_host_area
                if target_host_area and target_host_area > 0:
                    target_fill_ratio = part_area / target_host_area
                improves_fill_ratio = (
                    current_fill_ratio is not None
                    and target_fill_ratio is not None
                    and (target_fill_ratio > current_fill_ratio + 0.12)
                )
                strongly_better_hole = (
                    target_host_area is not None
                    and current_host_area is not None
                    and (target_host_area <= part_area * 2.6)
                    and (current_host_area >= part_area * 4.0)
                )
                if (
                    not improves_tightness
                    and (not improves_fill_ratio)
                    and (not strongly_better_hole)
                    and (not touches_edge)
                ):
                    continue
                p.x = round01(margin + nx)
                p.y = round01(margin + ny)
                moved_any = True
            if not moved_any:
                break


def _build_packing_items(insts, gap, grain_enabled, usable_w, usable_h, report):
    items: List[Dict[str, Any]] = []
    if grain_enabled:
        groups: Dict[str, List[Tuple[Optional[int], int, Instance]]] = {}
        singles: List[Instance] = []
        seq = 0
        for inst in insts:
            seq += 1
            gg_raw = str(inst.row.GrainGroup or "").strip()
            if gg_raw:
                gg_id = gg_raw
                pos_idx: Optional[int] = None
                if ":" in gg_raw:
                    gg_id, tail = gg_raw.split(":", 1)
                    gg_id = gg_id.strip()
                    tail = tail.strip()
                    if tail.isdigit():
                        pos_idx = int(tail)
                groups.setdefault(gg_id, []).append((pos_idx, seq, inst))
            else:
                singles.append(inst)
        for gg in sorted(groups.keys()):
            triples = groups[gg]
            if all((t[0] is not None for t in triples)):
                triples_sorted = sorted(triples, key=lambda t: (t[0], t[1]))
            else:
                triples_sorted = sorted(triples, key=lambda t: t[1])
            members = [t[2] for t in triples_sorted]
            widths = {round(float(m.w), 1) for m in members}
            if len(widths) != 1:
                fatal(report, f"GrainGroup '{gg}' contains mixed WidthMm values: {sorted(widths)}")
            gw = float(members[0].w)
            gh = sum((float(m.h) for m in members)) + gap * max(0, len(members) - 1)
            if gh > usable_h + 1e-06 or gw > usable_w + 1e-06:
                fatal(report, f"GrainGroup '{gg}' does not fit on sheet usable area (w={gw}, h={gh}).")
            items.append(
                {
                    "kind": "group",
                    "group": gg,
                    "members": members,
                    "w": gw,
                    "h": gh,
                    "rot_allowed": False,
                    "area": gw * gh,
                    "mn": min(gw, gh),
                    "mx": max(gw, gh),
                    "micro_flag": 1
                    if gw * gh <= 120000.0
                    or min(gw, gh) <= 120.0
                    or (max(gw, gh) >= 320.0 and min(gw, gh) <= 160.0)
                    else 0,
                }
            )
        for inst in singles:
            items.append(
                {
                    "kind": "single",
                    "members": [inst],
                    "w": float(inst.w),
                    "h": float(inst.h),
                    "rot_allowed": bool(inst.rot_allowed),
                    "area": float(inst.w) * float(inst.h),
                    "mn": min(float(inst.w), float(inst.h)),
                    "mx": max(float(inst.w), float(inst.h)),
                    "micro_flag": 1
                    if float(inst.w) * float(inst.h) <= 120000.0
                    or min(float(inst.w), float(inst.h)) <= 120.0
                    or (
                        max(float(inst.w), float(inst.h)) >= 320.0
                        and min(float(inst.w), float(inst.h)) <= 160.0
                    )
                    else 0,
                }
            )
    else:
        for inst in insts:
            items.append(
                {
                    "kind": "single",
                    "members": [inst],
                    "w": float(inst.w),
                    "h": float(inst.h),
                    "rot_allowed": bool(inst.rot_allowed),
                    "area": float(inst.w) * float(inst.h),
                    "mn": min(float(inst.w), float(inst.h)),
                    "mx": max(float(inst.w), float(inst.h)),
                    "micro_flag": 1
                    if float(inst.w) * float(inst.h) <= 120000.0
                    or min(float(inst.w), float(inst.h)) <= 120.0
                    or (
                        max(float(inst.w), float(inst.h)) >= 320.0
                        and min(float(inst.w), float(inst.h)) <= 160.0
                    )
                    else 0,
                }
            )
    return items


def _packing_bounds(items, usable_w, usable_h, gap, usable_area, total_area, _emit_pack_progress_fraction):
    area_lb = max(1, int(math.ceil(total_area / usable_area - 1e-12)))
    clique_lb = _greedy_incompatibility_clique_bound(
        items,
        usable_w,
        usable_h,
        progress_cb=lambda frac: _emit_pack_progress_fraction(
            0.04 + max(0.0, min(1.0, float(frac))) * 0.1, "Plaatgrenzen analyseren…"
        ),
    )
    fixed_grid_lb = 1
    fixed_grid_capacity = None
    try:
        if items and all((it.get("kind") == "single" and (not bool(it.get("rot_allowed"))) for it in items)):
            w0 = float(items[0]["w"])
            h0 = float(items[0]["h"])
            if all((abs(float(it["w"]) - w0) <= 1e-09 and abs(float(it["h"]) - h0) <= 1e-09 for it in items)):
                cols = int(math.floor((usable_w + gap + 1e-09) / (w0 + gap))) if w0 + gap > 0 else 0
                rows_cap = int(math.floor((usable_h + gap + 1e-09) / (h0 + gap))) if h0 + gap > 0 else 0
                fixed_grid_capacity = max(0, cols * rows_cap)
                if fixed_grid_capacity > 0:
                    fixed_grid_lb = max(1, int(math.ceil(len(items) / float(fixed_grid_capacity))))
    except Exception as recovery_error:
        report_recovery("metod_app.optimizer.packing.boundary.449", recovery_error)
        fixed_grid_lb = 1
        fixed_grid_capacity = None
    return (area_lb, clique_lb, fixed_grid_lb, fixed_grid_capacity)


def _prepare_packing_variants(items, grain_enabled, sort_variants, _emit_pack_progress_fraction):
    items_by_variant: Dict[str, List[Dict[str, Any]]] = {}
    if grain_enabled:
        group_items = [it for it in items if it.get("kind") == "group"]
        single_items = [it for it in items if it.get("kind") != "group"]
        for variant_index, variant in enumerate(sort_variants, start=1):
            items_by_variant[variant] = group_items + sorted(
                single_items, key=lambda it, variant=variant: _item_sort_key(it, variant)
            )
            _emit_pack_progress_fraction(
                0.15 + variant_index / float(len(sort_variants)) * 0.05,
                "Optimalisatiestrategieën voorbereiden…",
            )
    else:
        for variant_index, variant in enumerate(sort_variants, start=1):
            items_by_variant[variant] = sorted(
                items, key=lambda it, variant=variant: _item_sort_key(it, variant)
            )
            _emit_pack_progress_fraction(
                0.15 + variant_index / float(len(sort_variants)) * 0.05,
                "Optimalisatiestrategieën voorbereiden…",
            )
    greedy_variants: List[str] = []
    equivalent_variant_of: Dict[str, str] = {}
    seen_variant_orders: Dict[Tuple[Tuple[Any, ...], ...], str] = {}
    for variant_index, variant in enumerate(sort_variants, start=1):
        order_key = tuple((_packing_equivalence_key(item) for item in items_by_variant[variant]))
        canonical_variant = seen_variant_orders.get(order_key)
        if canonical_variant is not None:
            equivalent_variant_of[variant] = canonical_variant
            continue
        seen_variant_orders[order_key] = variant
        greedy_variants.append(variant)
        _emit_pack_progress_fraction(
            0.2 + variant_index / float(len(sort_variants)) * 0.04, "Optimalisatiestrategieën vergelijken…"
        )
    return (items_by_variant, greedy_variants, equivalent_variant_of)


def pack_maxrects_optimal(
    insts: List[Instance],
    sheet_w: float,
    sheet_h: float,
    margin: float,
    gap: float,
    grain_enabled: bool,
    report: Dict[str, Any],
    progress_cb=None,
) -> Tuple[List[Placement], int]:
    """Deterministic multi-pass MaxRects packing with explicit primary objective: minimize sheet count."""
    usable_w = sheet_w - 2 * margin
    usable_h = sheet_h - 2 * margin
    if usable_w <= 0 or usable_h <= 0:
        fatal(report, "Sheet usable area is non-positive; check margin/sheet size.")
    last_pack_progress = -1.0

    def _emit_pack_progress_fraction(frac: float, message: str = "") -> None:
        nonlocal last_pack_progress
        if not callable(progress_cb):
            return
        try:
            bounded = max(last_pack_progress, max(0.0, min(1.0, float(frac))))
            last_pack_progress = bounded
            progress_cb(bounded, message)
        except Exception as recovery_error:
            report_recovery("dxf_nesting_optimizer._emit_pack_progress_fraction.1630", recovery_error)

    _emit_pack_progress_fraction(0.0, "Panelen voor optimalisatie groeperen…")
    prof = _profiler()
    if prof:
        prof.event(
            "pack_optimal.start",
            instances=len(insts),
            sheetW=sheet_w,
            sheetH=sheet_h,
            grainEnabled=bool(grain_enabled),
        )
    items = _build_packing_items(insts, gap, grain_enabled, usable_w, usable_h, report)
    total_area = sum((float(it["w"]) * float(it["h"]) for it in items))
    _emit_pack_progress_fraction(0.04, "Plaatgrenzen analyseren…")
    if prof:
        prof.set_meta(instanceCount=len(insts), itemCount=len(items), grainEnabled=bool(grain_enabled))
        prof.event("pack_optimal.items_built", itemCount=len(items), lowerBound=None)
    usable_area = usable_w * usable_h
    area_lb, clique_lb, fixed_grid_lb, fixed_grid_capacity = _packing_bounds(
        items, usable_w, usable_h, gap, usable_area, total_area, _emit_pack_progress_fraction
    )
    lb = max(area_lb, clique_lb, fixed_grid_lb)
    _emit_pack_progress_fraction(0.15, "Optimalisatiestrategieën voorbereiden…")
    if prof:
        prof.event(
            "pack_optimal.bounds",
            lowerBound=int(lb),
            areaLowerBound=int(area_lb),
            cliqueLowerBound=int(clique_lb),
            fixedGridLowerBound=int(fixed_grid_lb),
            fixedGridCapacity=fixed_grid_capacity,
            usableArea=usable_area,
            totalArea=total_area,
        )
    sort_variants = ["density_first", "area_desc", "max_side_desc", "height_desc", "width_desc"]
    proof_variant_limit_env = str(os.getenv("METOD_PROOF_VARIANT_LIMIT", "2") or "2").strip()
    try:
        proof_variant_limit = max(1, int(proof_variant_limit_env))
    except (ValueError, TypeError, OverflowError):
        proof_variant_limit = 2
    proof_variant_limit = min(len(sort_variants), proof_variant_limit)
    homogeneous_grid = _homogeneous_grid_candidate(items, sheet_w, sheet_h, margin, gap)
    best: Optional[Tuple[int, float, List[Placement]]] = None
    if homogeneous_grid is not None:
        grid_placements, grid_sheets, _grid_capacity, _grid_rotation = homogeneous_grid
        best = (int(grid_sheets), int(grid_sheets) * usable_area - total_area, grid_placements)
    attempt_audit: Dict[str, Any] = {
        "lowerBound": int(lb),
        "areaLowerBound": int(area_lb),
        "cliqueLowerBound": int(clique_lb),
        "fixedGridLowerBound": int(fixed_grid_lb),
        "fixedGridCapacity": fixed_grid_capacity,
        "sortVariants": list(sort_variants),
        "proofVariantLimit": int(proof_variant_limit),
        "greedy": [],
        "proof": [],
        "proofVariantsConsidered": [],
        "proofVariantsSkipped": [],
        "homogeneousGrid": {
            "sheetsUsed": int(homogeneous_grid[1]),
            "capacityPerSheet": int(homogeneous_grid[2]),
            "pattern": dict(homogeneous_grid[3]),
        }
        if homogeneous_grid is not None
        else None,
    }
    items_by_variant, greedy_variants, equivalent_variant_of = _prepare_packing_variants(
        items, grain_enabled, sort_variants, _emit_pack_progress_fraction
    )
    attempt_audit["greedyVariantsExecuted"] = list(greedy_variants)
    attempt_audit["greedyVariantsSkippedEquivalent"] = dict(equivalent_variant_of)
    ub = int(best[0]) if best is not None else None
    greedy_attempts = len(greedy_variants)
    done_steps = 0
    greedy_results: List[Dict[str, Any]] = []
    _emit_pack_progress_fraction(0.24, "Plaatindelingen berekenen…")
    for variant in greedy_variants:
        __attempt_started = time.perf_counter()
        if prof:
            prof.event("pack_optimal.greedy_attempt_start", variant=variant)
        its = items_by_variant[variant]
        attempt_index = done_steps
        pls = _maxrects_pack_k(
            its,
            sheet_w,
            sheet_h,
            margin,
            gap,
            k=len(items),
            report=report,
            progress_cb=lambda inner_frac,
            msg="",
            attempt_index=attempt_index,
            total_steps=greedy_attempts: _emit_pack_progress_fraction(
                0.24
                + 0.48
                * ((attempt_index + max(0.0, min(1.0, float(inner_frac)))) / float(max(1, total_steps))),
                msg or "Plaatindelingen berekenen…",
            ),
        )
        done_steps += 1
        _emit_pack_progress_fraction(
            0.24 + 0.48 * (done_steps / float(max(1, greedy_attempts))),
            f"Plaatindeling {done_steps}/{greedy_attempts} berekend…",
        )
        __attempt_seconds = round(time.perf_counter() - __attempt_started, 6)
        __attempt_sheets = int(max((p.sheetIndex for p in pls), default=1)) if pls is not None else None
        if prof:
            prof.event(
                "pack_optimal.greedy_attempt_end",
                variant=variant,
                seconds=__attempt_seconds,
                success=pls is not None,
            )
        greedy_entry = {
            "variant": variant,
            "seconds": __attempt_seconds,
            "success": bool(pls is not None),
            "sheetsUsed": __attempt_sheets,
        }
        attempt_audit["greedy"].append(greedy_entry)
        greedy_results.append(dict(greedy_entry))
        if pls is None:
            continue
        sheets_used = max((p.sheetIndex for p in pls), default=1)
        waste = sheets_used * usable_area - total_area
        cand = (sheets_used, waste, pls)
        if best is None or (cand[0], cand[1]) < (best[0], best[1]):
            best = cand
            ub = sheets_used
        if int(sheets_used) == int(lb):
            attempt_audit["upperBoundGreedy"] = int(sheets_used)
            attempt_audit["proofVariantsConsidered"] = []
            attempt_audit["proofVariantsSkipped"] = list(sort_variants)
            attempt_audit["proofRange"] = {"from": int(lb), "toInclusive": int(lb) - 1}
            attempt_audit["greedyAttemptCount"] = len(attempt_audit.get("greedy") or [])
            attempt_audit["proofAttemptCount"] = 0
            attempt_audit["totalAttemptCount"] = int(attempt_audit["greedyAttemptCount"])
            attempt_audit["finalSheetsUsed"] = int(sheets_used)
            attempt_audit["earlyOptimalLowerBound"] = True
            try:
                report["_lastPackAttemptAudit"] = attempt_audit
            except Exception as recovery_error:
                report_recovery("dxf_nesting_optimizer.pack_maxrects_optimal.1856", recovery_error)
            _emit_pack_progress_fraction(1.0, "Optimale plaatindeling bewezen…")
            if prof:
                prof.event(
                    "pack_optimal.early_lower_bound",
                    sheetsUsed=int(sheets_used),
                    lowerBound=int(lb),
                    greedyAttempts=len(attempt_audit.get("greedy") or []),
                )
                prof.event(
                    "pack_optimal.end",
                    sheetsUsed=int(sheets_used),
                    totalSteps=len(attempt_audit.get("greedy") or []),
                )
            return (pls, sheets_used)
    if best is None:
        fatal(report, "Packing failed unexpectedly (no strategy could place items).")
    proof_variants_ranked = [
        row["variant"]
        for row in sorted(
            [row for row in greedy_results if row.get("success")],
            key=lambda row: (
                int(row.get("sheetsUsed") if row.get("sheetsUsed") is not None else 10**9),
                float(row.get("seconds") if row.get("seconds") is not None else 10**9),
                sort_variants.index(row["variant"]) if row.get("variant") in sort_variants else 10**9,
            ),
        )
    ]
    if not proof_variants_ranked:
        proof_variants_ranked = list(sort_variants)
    proof_variants = proof_variants_ranked[:proof_variant_limit]
    skipped_variants = [variant for variant in sort_variants if variant not in proof_variants]
    attempt_audit["proofVariantsConsidered"] = list(proof_variants)
    attempt_audit["proofVariantsSkipped"] = list(skipped_variants)
    attempt_audit["upperBoundGreedy"] = int(ub) if ub is not None else None
    proof_attempts = max(0, int(ub) - int(lb)) * len(proof_variants)
    proof_done = 0
    _emit_pack_progress_fraction(0.72, "Beste plaatindeling verifiëren…")
    for k in range(lb, int(ub)):
        found = None
        for variant in proof_variants:
            __attempt_started = time.perf_counter()
            if prof:
                prof.event("pack_optimal.proof_attempt_start", k=int(k), variant=variant)
            its = items_by_variant[variant]
            attempt_index = proof_done
            pls = _maxrects_pack_k(
                its,
                sheet_w,
                sheet_h,
                margin,
                gap,
                k=k,
                report=report,
                progress_cb=lambda inner_frac,
                msg="",
                attempt_index=attempt_index,
                total_steps=proof_attempts: _emit_pack_progress_fraction(
                    0.72
                    + 0.27
                    * ((attempt_index + max(0.0, min(1.0, float(inner_frac)))) / float(max(1, total_steps))),
                    msg or "Beste plaatindeling verifiëren…",
                ),
            )
            proof_done += 1
            _emit_pack_progress_fraction(
                0.72 + 0.27 * (proof_done / float(max(1, proof_attempts))),
                f"Verificatie {proof_done}/{proof_attempts} afgerond…",
            )
            __attempt_seconds = round(time.perf_counter() - __attempt_started, 6)
            __attempt_sheets = int(max((p.sheetIndex for p in pls), default=1)) if pls is not None else None
            if prof:
                prof.event(
                    "pack_optimal.proof_attempt_end",
                    k=int(k),
                    variant=variant,
                    seconds=__attempt_seconds,
                    success=pls is not None,
                )
            attempt_audit["proof"].append(
                {
                    "k": int(k),
                    "variant": variant,
                    "seconds": __attempt_seconds,
                    "success": bool(pls is not None),
                    "sheetsUsed": __attempt_sheets,
                }
            )
            if pls is not None:
                waste = k * usable_area - total_area
                found = (k, waste, pls)
                break
        if found is not None:
            best = found
            break
    _emit_pack_progress_fraction(1.0, "Nestings berekenen afgerond…")
    sheets_used = best[0]
    attempt_audit["proofRange"] = {"from": int(lb), "toInclusive": int(ub) - 1 if ub is not None else None}
    attempt_audit["greedyAttemptCount"] = len(attempt_audit.get("greedy") or [])
    attempt_audit["proofAttemptCount"] = len(attempt_audit.get("proof") or [])
    attempt_audit["totalAttemptCount"] = int(attempt_audit["greedyAttemptCount"]) + int(
        attempt_audit["proofAttemptCount"]
    )
    attempt_audit["finalSheetsUsed"] = int(sheets_used)
    try:
        report["_lastPackAttemptAudit"] = attempt_audit
    except Exception as recovery_error:
        report_recovery("dxf_nesting_optimizer.pack_maxrects_optimal.1932", recovery_error)
    if prof:
        prof.event(
            "pack_optimal.end", sheetsUsed=int(sheets_used), totalSteps=int(greedy_attempts + proof_attempts)
        )
    return (best[2], sheets_used)
