"""Profiling responsibilities for the production optimizer."""

from __future__ import annotations
from metod_app.observability.failures import report_recovery
import time
from collections import defaultdict
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Dict, List, Optional
from safety_contracts import durable_write_json, strict_json_dumps
from .common import ensure_dir, now_iso

_OPTIMIZER_PROFILER = None


class OptimizerProfiler:
    """Detailed runtime profiler for Tool B performance audits.

    safety repair: keep the audit useful, but make trace writing lightweight
    enough that heavy optimizer runs do not stall on per-event disk flushing.
    """

    _FLUSH_EVERY_EVENTS = 250
    _FLUSH_EVERY_SECONDS = 0.75
    _MAX_TRACE_EVENTS = 12000

    def __init__(self, output_dir: Path):
        self.output_dir = Path(output_dir)
        self.trace_path = self.output_dir / "optimizer_perf_trace.jsonl"
        self.summary_path = self.output_dir / "optimizer_perf_summary.json"
        self.started = time.perf_counter()
        self._trace_fh = None
        self._buffer: List[str] = []
        self._events_written = 0
        self._events_dropped = 0
        self._last_flush_at = self.started
        self.counters = defaultdict(float)
        self.meta = {}
        try:
            ensure_dir(self.output_dir)
            self._trace_fh = open(self.trace_path, "w", encoding="utf-8")
        except Exception as recovery_error:
            report_recovery("metod_app.optimizer.profiling.boundary.38", recovery_error)
            self._trace_fh = None

    def _flush_trace(self, force: bool = False) -> None:
        if not self._trace_fh or not self._buffer:
            return
        now = time.perf_counter()
        if not force:
            if (
                len(self._buffer) < self._FLUSH_EVERY_EVENTS
                and now - self._last_flush_at < self._FLUSH_EVERY_SECONDS
            ):
                return
        try:
            self._trace_fh.write("".join(self._buffer))
            self._trace_fh.flush()
            self._buffer.clear()
            self._last_flush_at = now
        except Exception as recovery_error:
            report_recovery("dxf_nesting_optimizer._flush_trace.124", recovery_error)

    def close(self):
        try:
            self._flush_trace(force=True)
            if self._trace_fh:
                self._trace_fh.close()
        except Exception as recovery_error:
            report_recovery("dxf_nesting_optimizer.close.132", recovery_error)
        self._trace_fh = None

    def _write_event(self, payload: Dict[str, Any]) -> None:
        if not self._trace_fh:
            return
        if self._events_written >= self._MAX_TRACE_EVENTS:
            self._events_dropped += 1
            return
        try:
            self._buffer.append(strict_json_dumps(payload) + "\n")
            self._events_written += 1
            self._flush_trace(force=False)
        except Exception as recovery_error:
            report_recovery("dxf_nesting_optimizer._write_event.146", recovery_error)

    def event(self, name: str, **data: Any) -> None:
        payload = {"t": round(time.perf_counter() - self.started, 6), "event": name}
        if data:
            payload.update(data)
        self._write_event(payload)

    @contextmanager
    def section(self, name: str, **data: Any):
        t0 = time.perf_counter()
        self.event(name + ":start", **data)
        exc = None
        try:
            yield
        except Exception as e:
            exc = e
            raise
        finally:
            dt = time.perf_counter() - t0
            self.counters[f"section_seconds.{name}"] += dt
            self.counters[f"section_calls.{name}"] += 1
            end_payload = dict(data)
            end_payload["seconds"] = round(dt, 6)
            end_payload["ok"] = exc is None
            self.event(name + ":end", **end_payload)

    def add(self, key: str, value: float = 1.0) -> None:
        self.counters[key] += value

    def set_meta(self, **data: Any) -> None:
        self.meta.update(data)

    def write_summary(self) -> None:
        self.counters["trace.events_written"] += float(self._events_written)
        self.counters["trace.events_dropped"] += float(self._events_dropped)
        self._flush_trace(force=True)
        payload = {
            "generatedAt": now_iso(),
            "elapsedSeconds": round(time.perf_counter() - self.started, 6),
            "meta": self.meta,
            "counters": {
                k: round(v, 6) if isinstance(v, float) else v for k, v in sorted(self.counters.items())
            },
        }
        try:
            durable_write_json(self.summary_path, payload)
        except Exception as recovery_error:
            report_recovery("dxf_nesting_optimizer.write_summary.195", recovery_error)


def _profiler() -> Optional[OptimizerProfiler]:
    return _OPTIMIZER_PROFILER


def configure_profiler(profiler):
    global _OPTIMIZER_PROFILER
    _OPTIMIZER_PROFILER = profiler
