"""Pure identifier and download-name normalization.

These functions deliberately preserve the established behavior, including
its different length policies for opaque identifiers and human-facing names.
The module owns no paths, environment, state, locks or I/O.
"""

from __future__ import annotations

from metod_app.observability.failures import report_recovery


import re
from typing import Any


def sanitize_filename(name: Any, max_len: int = 120) -> str:
    try:
        raw = str(name or "")
    except Exception as recovery_error:
        report_recovery("metod_app.identifiers.boundary.18", recovery_error)
        raw = ""
    raw = raw.replace("\\", "_").replace("/", "_")
    raw = re.sub(r"[^A-Za-z0-9.,_ -]+", "_", raw).strip(" ._")
    if not raw:
        return ""
    try:
        limit = max(1, int(max_len or 120))
    except (ValueError, TypeError, OverflowError):
        limit = 120
    return raw[:limit]


def safe_identifier(value: str, max_len: int = 80) -> str:
    raw = str(value or "").strip()
    limit = min(120, max(1, int(max_len or 80)))
    if len(raw) > limit or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]*", raw):
        return ""
    return raw


def sanitize_key(value: str) -> str:
    raw = str(value or "").strip()
    return re.sub(r"[^A-Za-z0-9_\-]+", "_", raw) or "mat"


__all__ = ("safe_identifier", "sanitize_filename", "sanitize_key")
