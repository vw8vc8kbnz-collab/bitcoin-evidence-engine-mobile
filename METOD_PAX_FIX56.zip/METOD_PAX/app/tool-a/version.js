// Generated from VERSION.json by tools/build_assets.cjs.
export const REVISION = "R9RC4_FIX56_RUNTIME_PREFLIGHT";
