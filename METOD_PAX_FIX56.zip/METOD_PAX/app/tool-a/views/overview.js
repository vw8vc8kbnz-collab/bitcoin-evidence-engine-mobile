import { ToolAPanelsViewModels } from "../domain/panels-view-models.js";
import { toolAFoundation } from "../runtime/foundation.js";

export function mount() {
  /*  — single Overview controller.
  Loaded after toolA.html is parsed. It deliberately owns the customer Overview
  render path so legacy overview handlers cannot leave an empty white modal. */
  (function () {
    "use strict";

    let lastOverviewTouchAction = null;

    function byId(id) {
      return document.getElementById(id);
    }
    function esc(v) {
      return String(v == null ? "" : v)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
    }
    function state() {
      return window.state && typeof window.state === "object"
        ? window.state
        : null;
    }
    function arr(v) {
      return Array.isArray(v) ? v : [];
    }
    function text(v) {
      return String(v == null ? "" : v).trim();
    }
    function finite(v, fallback = 0) {
      const n = Number(v);
      return Number.isFinite(n) ? n : fallback;
    }
    // Customer-facing label only. Never fall back to material key/article/code.
    function publicMaterialName(batch) {
      const m =
        batch && batch.mat && typeof batch.mat === "object" ? batch.mat : {};
      const label = text(
        m.publicName ||
          m.displayName ||
          m.productName ||
          m.decorName ||
          batch?.publicName ||
          batch?.displayName,
      );
      return label || "Materiaal";
    }
    function materialNameByKey(key) {
      const st = state();
      const hit = arr(st?.materialBatches).find(
        (b) => String(b?.key ?? "") === String(key ?? ""),
      );
      return publicMaterialName(hit);
    }
    function cartTitle(it) {
      return text(it?.customName || it?.name || it?.label) || "Paneel";
    }
    function extraTitle(p) {
      return text(p?.name || p?.label) || "Overig paneel";
    }
    function edgeText(value) {
      const v = text(value).toLowerCase();
      if (!v || v === "none" || v === "0" || v === "false") return "geen";
      if (v === "all" || v === "1" || v === "true") return "rondom";
      if (v === "lr") return "links + rechts";
      if (v === "tb") return "boven + onder";
      const m = v.match(/^t([01])r([01])b([01])l([01])$/);
      if (m) {
        const names = [];
        if (m[1] === "1") names.push("boven");
        if (m[2] === "1") names.push("rechts");
        if (m[3] === "1") names.push("onder");
        if (m[4] === "1") names.push("links");
        return names.length ? names.join(" + ") : "geen";
      }
      return "ingesteld";
    }
    function cartMeta(it) {
      const w = finite(it?.cmW, NaN),
        h = finite(it?.cmH, NaN);
      const dims =
        Number.isFinite(w) && Number.isFinite(h)
          ? `${w}×${h} cm`
          : "Afmetingen ingesteld";
      const top = finite(it?.extTop, 0),
        bot = finite(it?.extBot, 0);
      const qty = Math.max(1, Math.round(finite(it?.qty, 1)));
      return `${dims} · aantal ${qty} · verlenging +${top} boven / +${bot} onder · kantenband ${edgeText(it?.edge || "all")}`;
    }
    function extraMeta(p) {
      const w = finite(p?.w, NaN),
        h = finite(p?.h, NaN),
        qty = Math.max(1, Math.round(finite(p?.qty, 1)));
      const dims =
        Number.isFinite(w) && Number.isFinite(h)
          ? `${w}×${h} mm`
          : "Afmetingen ingesteld";
      return `${dims} · aantal ${qty} · kantenband ${edgeText(p?.edge || "")}`;
    }
    function buildGroups(st) {
      const shared = ToolAPanelsViewModels;
      if (shared && typeof shared.getPanelMaterialGroups === "function") {
        return shared
          .getPanelMaterialGroups(st, { getMaterialName: materialNameByKey })
          .map((group) => ({
            key: group.materialKey,
            cart: group.cartEntries.map((entry) => entry.panel),
            extra: group.extraEntries.map((entry) => entry.panel),
          }));
      }
      const groups = new Map();
      function get(key) {
        const k = String(key ?? "");
        if (!groups.has(k)) groups.set(k, { key: k, cart: [], extra: [] });
        return groups.get(k);
      }
      arr(st?.cart).forEach((it) => get(it?.materialKey).cart.push(it));
      arr(st?.extraPanels).forEach((p) =>
        get(p?.materialKey || p?.material).extra.push(p),
      );
      return Array.from(groups.values()).sort((a, b) =>
        materialNameByKey(a.key).localeCompare(materialNameByKey(b.key), "nl", {
          sensitivity: "base",
        }),
      );
    }

    function rowHtml(kind, token, title, meta) {
      return `<div class="overviewRow overviewOverviewRow">
      <div class="overviewRowMain">
        <div class="overviewRowTitle">${esc(title)}</div>
        <div class="muted overviewRowMeta">${esc(meta)}</div>
      </div>
      <div class="overviewRowActions">
        <button type="button" class="miniBtn overviewRemoveBtn" data-overview-remove-kind="${esc(kind)}" data-overview-remove-token="${esc(token)}">Verwijder</button>
      </div>
    </div>`;
    }
    function sectionHtml(title, rows) {
      if (!rows) return "";
      return `<section class="overviewSection overviewOverviewSection"><div class="overviewSectionTitle">${esc(title)}</div><div class="overviewList">${rows}</div></section>`;
    }
    function groupHtml(group) {
      const count =
        group.cart.reduce(
          (n, it) => n + Math.max(1, Math.round(finite(it?.qty, 1))),
          0,
        ) +
        group.extra.reduce(
          (n, p) => n + Math.max(1, Math.round(finite(p?.qty, 1))),
          0,
        );
      const cartRows = group.cart
        .map((it, idx) =>
          rowHtml(
            "cart",
            text(it?.id) || `idx:${idx}`,
            cartTitle(it),
            cartMeta(it),
          ),
        )
        .join("");
      const extraRows = group.extra
        .map((p) => {
          const st = state();
          const index = arr(st?.extraPanels).indexOf(p);
          return rowHtml("extra", String(index), extraTitle(p), extraMeta(p));
        })
        .join("");
      return `<div class="overviewGroupCard overviewOverviewGroup">
      <div class="overviewGroupHeader"><div class="overviewGroupTitle">${esc(materialNameByKey(group.key))}</div><div class="overviewOverviewCount">${count} ${count === 1 ? "onderdeel" : "onderdelen"}</div></div>
      ${sectionHtml("METOD deuren & ladefronten", cartRows)}
      ${sectionHtml("Overige panelen", extraRows)}
    </div>`;
    }

    function activeKey(st) {
      const wanted = text(st?.ui?.overviewMaterialKey);
      if (wanted) return wanted;
      const groups = buildGroups(st);
      return groups[0]?.key || "";
    }

    function render() {
      const st = state();
      const content = byId("overviewContent");
      const tabs = byId("overviewTabs");
      const hint = byId("overviewTabHint");
      const empty = byId("overviewEmpty");
      const summary = byId("overviewSummary");
      if (!content || !tabs) {
        window.__TOOLA_OVERVIEW_RENDER_OK = false;
        return false;
      }
      try {
        if (!st) {
          throw new Error("Tool A state ontbreekt");
        }
        st.ui = st.ui && typeof st.ui === "object" ? st.ui : {};
        if (st.ui.overviewTab !== "material") st.ui.overviewTab = "all";
        const groups = buildGroups(st);
        const total =
          arr(st.cart).reduce(
            (n, it) => n + Math.max(1, Math.round(finite(it?.qty, 1))),
            0,
          ) +
          arr(st.extraPanels).reduce(
            (n, p) => n + Math.max(1, Math.round(finite(p?.qty, 1))),
            0,
          );

        const batchByKey = new Map(
          arr(st.materialBatches).map((b) => [String(b?.key ?? ""), b]),
        );
        const groupKeys = new Set(groups.map((g) => g.key));
        const availableBatches = arr(st.materialBatches).filter((b) =>
          groupKeys.has(String(b?.key ?? "")),
        );
        const allActive = st.ui.overviewTab !== "material";
        let tabHtml = `<button type="button" class="chip ${allActive ? "chipActive" : ""}" data-overview-otab="all"><span class="chipTxt">Alle onderdelen</span></button>`;
        for (const b of availableBatches) {
          const k = String(b?.key ?? "");
          const isActive =
            !allActive && String(st.ui.overviewMaterialKey || "") === k;
          tabHtml += `<button type="button" class="chip ${isActive ? "chipActive" : ""}" data-overview-otab="material" data-overview-mkey="${esc(k)}"><span class="chipTxt">${esc(publicMaterialName(batchByKey.get(k)))}</span></button>`;
        }
        tabs.innerHTML = `<div class="chipRow overviewOverviewTabs">${tabHtml}</div>`;

        let visibleGroups = groups;
        if (!allActive) {
          let key = activeKey(st);
          if (!groupKeys.has(key) && groups.length) key = groups[0].key;
          st.ui.overviewMaterialKey = key;
          visibleGroups = groups.filter((g) => g.key === key);
          if (hint)
            hint.textContent = `Je bekijkt alleen: ${materialNameByKey(key)}`;
        } else if (hint) {
          hint.textContent = total
            ? `${total} ${total === 1 ? "onderdeel" : "onderdelen"} · gegroepeerd per materiaal`
            : "Nog geen panelen toegevoegd.";
        }

        if (!groups.length) {
          content.innerHTML =
            '<div class="overviewOverviewEmpty"><strong>Nog geen panelen toegevoegd.</strong><span>Ga terug naar Panelen om onderdelen toe te voegen.</span></div>';
          if (empty) empty.style.display = "none";
        } else {
          content.innerHTML = visibleGroups.map(groupHtml).join("");
          if (empty) empty.style.display = "none";
        }
        if (summary) {
          summary.textContent = "";
          summary.style.display = "none";
        }
        window.__TOOLA_OVERVIEW_RENDER_OK = !!content.innerHTML.trim();
        return true;
      } catch (err) {
        console.error("Overview render failed", err);
        content.innerHTML =
          '<div class="overviewOverviewError"><strong>Overzicht kon niet worden opgebouwd.</strong><span>Ga één stap terug en probeer opnieuw.</span></div>';
        tabs.innerHTML =
          '<div class="chipRow"><button type="button" class="chip chipActive"><span class="chipTxt">Alle onderdelen</span></button></div>';
        if (hint)
          hint.textContent =
            "Er ging iets mis tijdens het tonen van het overzicht.";
        if (empty) empty.style.display = "none";
        window.__TOOLA_OVERVIEW_RENDER_OK = false;
        return false;
      }
    }

    function show() {
      const ov = byId("overviewOverlay");
      if (!ov) return false;
      const st = state();
      if (st) {
        st.ui = st.ui && typeof st.ui === "object" ? st.ui : {};
        st.ui.overviewTab = "all";
        window.__overviewReturnStep = String(
          window.__metod_uiStep || document.body?.dataset?.uiStep || "customer",
        );
      }
      render();
      ov.style.display = "flex";
      ov.style.pointerEvents = "auto";
      ov.setAttribute("aria-hidden", "false");
      document.body.classList.add("overviewOverviewOpen");
      document.body.style.overflow = "hidden";
      // One extra pass after layout/legacy listeners have had a chance to run.
      requestAnimationFrame(() => {
        render();
        requestAnimationFrame(render);
      });
      return true;
    }
    function close() {
      const ov = byId("overviewOverlay");
      if (ov) {
        ov.style.display = "none";
        ov.style.pointerEvents = "none";
        ov.setAttribute("aria-hidden", "true");
      }
      document.body.classList.remove("overviewOverviewOpen");
      document.body.style.overflow = "";
    }
    function goBack() {
      close();
      {
        const raw = String(
          window.__overviewReturnStep ||
            window.__metod_uiStep ||
            document.body?.dataset?.uiStep ||
            "customer",
        );
        const ret =
          raw === "material" ||
          raw === "panels" ||
          raw === "grain" ||
          raw === "customer"
            ? raw
            : "customer";
        if (typeof window.__showWizardStep === "function")
          window.__showWizardStep(ret);
        else if (typeof window.setStep === "function") window.setStep(ret);
        if (typeof window.renderFooterForStep === "function")
          window.renderFooterForStep(ret);
      }
    }
    function calculate() {
      const start = window.__metodStartCalculationFromOverview;
      if (typeof start !== "function") {
        const hint = byId("overviewTabHint");
        if (hint)
          hint.textContent =
            "De berekening is nog niet geladen. Herlaad de pagina één keer en probeer opnieuw.";
        return false;
      }
      try {
        return start.call(window) === true;
      } catch (error) {
        console.error("Overview calculation start failed", error);
        const hint = byId("overviewTabHint");
        if (hint)
          hint.textContent =
            "De berekening kon niet worden gestart. Herlaad de pagina en probeer opnieuw.";
        return false;
      }
    }

    function claim(ev) {
      ev.preventDefault();
      try {
        ev.stopImmediatePropagation();
      } catch (_) {
        ev.stopPropagation();
      }
    }
    function handleOverviewNextEvent(ev) {
      const target =
        ev.target && ev.target.closest
          ? ev.target.closest("#overviewNextBtn")
          : null;
      if (!target) return false;
      const type = String(ev.type || "").toLowerCase();
      const pointerType = String(ev.pointerType || "").toLowerCase();
      if (
        type === "pointerup" &&
        pointerType !== "touch" &&
        pointerType !== "pen"
      )
        return false;
      const now = Date.now();
      const duplicate =
        lastOverviewTouchAction &&
        lastOverviewTouchAction.eventType !== type &&
        now - lastOverviewTouchAction.at < 1000;
      if (duplicate) {
        claim(ev);
        return true;
      }
      claim(ev);
      calculate();
      if (type === "pointerup" || type === "touchend")
        lastOverviewTouchAction = { eventType: type, at: now };
      else lastOverviewTouchAction = null;
      return true;
    }

    function remove(kind, token) {
      const st = state();
      if (!st) return;
      const owner =
        typeof toolAFoundation !== "undefined" ? toolAFoundation : null;
      const hooks = {
        renderCart: window.renderCart,
        renderExtraPanels: window.renderExtraPanels,
        renderOverview: render,
        drawExtraPreview: window.drawExtraPreview,
        scheduleDraftSave: window.scheduleDraftSave,
        updatePriceBar: window.updatePriceBar,
        syncChecksFromSelect: window.syncChecksFromSelect,
      };
      if (kind === "cart") {
        const before = arr(st.cart);
        const target = before.find((it, idx) => {
          const t = text(it?.id) || `idx:${idx}`;
          return t === token;
        });
        const id = text(target?.id);
        if (!id || !owner || typeof owner.removePanel !== "function") return;
        owner.removePanel({ state: st, id, hooks });
      } else if (kind === "extra") {
        const idx = parseInt(token, 10);
        if (
          !(
            Number.isInteger(idx) &&
            idx >= 0 &&
            idx < arr(st.extraPanels).length
          )
        )
          return;
        if (!owner || typeof owner.removeExtraPanel !== "function") return;
        owner.removeExtraPanel({ state: st, index: idx, hooks });
      } else {
        return;
      }
    }

    // Make every legacy overview call converge on this exact renderer.
    window.renderOverviewSafe = render;
    window.openOverviewOverlay = show;
    window.closeOverviewOverlay = close;

    // iPhone Safari can deliver Pointer, Touch and compatibility-click for one
    // tap, or omit the click in a fixed scrolling overlay. This controller owns
    // all three and deduplicates them before invoking the locked calculation.
    document.addEventListener("pointerup", handleOverviewNextEvent, true);
    document.addEventListener("touchend", handleOverviewNextEvent, {
      capture: true,
      passive: false,
    });

    // Capture before target-level legacy handlers. This removes competing overview routes
    // without deleting the old code that other historical flows may still depend on.
    document.addEventListener(
      "click",
      function (ev) {
        const target =
          ev.target && ev.target.closest
            ? ev.target.closest(
                "#overviewBtn,#wizardOverviewBtn,#priceBarBtnOverview,#overviewCloseBtn,#overviewBackBtn,#overviewNextBtn,[data-overview-otab],[data-overview-remove-kind]",
              )
            : null;
        if (!target) return;
        if (
          target.matches("#overviewBtn,#wizardOverviewBtn,#priceBarBtnOverview")
        ) {
          ev.preventDefault();
          ev.stopImmediatePropagation();
          show();
          return;
        }
        if (
          target.id === "overviewCloseBtn" ||
          target.id === "overviewBackBtn"
        ) {
          ev.preventDefault();
          ev.stopImmediatePropagation();
          goBack();
          return;
        }
        if (target.id === "overviewNextBtn") {
          handleOverviewNextEvent(ev);
          return;
        }
        if (target.hasAttribute("data-overview-otab")) {
          ev.preventDefault();
          ev.stopImmediatePropagation();
          const st = state();
          if (!st) return;
          st.ui = st.ui && typeof st.ui === "object" ? st.ui : {};
          st.ui.overviewTab =
            target.getAttribute("data-overview-otab") === "material"
              ? "material"
              : "all";
          const mk = target.getAttribute("data-overview-mkey");
          if (mk) st.ui.overviewMaterialKey = mk;
          render();
          return;
        }
        if (target.hasAttribute("data-overview-remove-kind")) {
          ev.preventDefault();
          ev.stopImmediatePropagation();
          remove(
            target.getAttribute("data-overview-remove-kind"),
            target.getAttribute("data-overview-remove-token") || "",
          );
        }
      },
      true,
    );

    function installObserver() {
      const ov = byId("overviewOverlay");
      if (!ov || ov.__overviewObserved) return;
      ov.__overviewObserved = true;
      let wasVisible = false;
      const check = () => {
        const visible =
          getComputedStyle(ov).display !== "none" &&
          ov.getClientRects().length > 0;
        if (visible && !wasVisible) {
          requestAnimationFrame(() => {
            render();
            requestAnimationFrame(render);
          });
        }
        wasVisible = visible;
      };
      new MutationObserver(check).observe(ov, {
        attributes: true,
        attributeFilter: ["style", "class", "aria-hidden"],
      });
      check();
    }
    if (document.readyState === "loading")
      document.addEventListener("DOMContentLoaded", installObserver, {
        once: true,
      });
    else installObserver();
  })();
}
