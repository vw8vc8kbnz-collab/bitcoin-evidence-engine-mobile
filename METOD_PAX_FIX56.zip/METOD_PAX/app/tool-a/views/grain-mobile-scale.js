import { REVISION } from "../version.js";
import { toolAFoundation } from "../runtime/foundation.js";

let mounted = false,
  drawerOpen = false;

export function mount() {
  (function (root) {
    "use strict";
    const GRAIN_PREVIEW_CTA_BUILD = REVISION;
    if (mounted) return;
    mounted = true;

    const MQ = "(max-width:900px)";
    const q = (id) => document.getElementById(id);
    const isMobile = () => !!(root.matchMedia && root.matchMedia(MQ).matches);
    const bridge = () => root.ToolAGrainBridge || null;
    const state = () => {
      const b = bridge();
      return b && typeof b.state === "function" ? b.state() : root.state || null;
    };
    const entry = (ref) => {
      const b = bridge();
      return b && typeof b.getEntry === "function" ? b.getEntry(ref) : null;
    };
    const esc = (v) =>
      String(v == null ? "" : v).replace(
        /[&<>"']/g,
        (c) =>
          ({
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#39;",
          })[c],
      );
    const n = (v, d = 0) => {
      const x = Number(v);
      return Number.isFinite(x) ? x : d;
    };
    const qmm = (v) => Math.round(n(v) * 1000) / 1000;
    const fmt = (v) => {
      const x = n(v);
      return Math.abs(x - Math.round(x)) < 0.01
        ? String(Math.round(x))
        : x.toFixed(1).replace(".", ",");
    };
    const widthMm = (e) => qmm(e && e.widthMm);
    const heightMm = (e) =>
      Math.max(
        1,
        n(e && e.baseHeightMm) +
          Math.max(0, n(e && e.extTop)) +
          Math.max(0, n(e && e.extBot)),
      );
    const sameWidth = (a, b) => {
      try {
        return root.ToolAGrainStudioMath
          ? root.ToolAGrainStudioMath.sameWidthMm(a, b)
          : Math.abs(n(a) - n(b)) <= 0.001;
      } catch (_) {
        return Math.abs(n(a) - n(b)) <= 0.001;
      }
    };
    const materialKey = () => {
      const b = bridge();
      try {
        return String(
          b && typeof b.selectedMaterialKey === "function" ? b.selectedMaterialKey() : "",
        );
      } catch (_) {
        return "";
      }
    };
    const doorLabel = (raw) => {
      const b = bridge();
      try {
        return b && typeof b.doorDirectionLabel === "function"
          ? b.doorDirectionLabel(raw)
          : "";
      } catch (_) {
        return "";
      }
    };
    const extLabel = (raw) => {
      const b = bridge();
      try {
        return b && typeof b.extensionLabel === "function" ? b.extensionLabel(raw) : "";
      } catch (_) {
        return "";
      }
    };
    const schedulePreview = () => {
      const o = toolAFoundation;
      return o && typeof o.scheduleGrainPreview === "function"
        ? o.scheduleGrainPreview()
        : root.ToolAGrainStudioRenderer && root.ToolAGrainStudioRenderer.schedule();
    };
    const renderPreview = (host) => {
      const o = toolAFoundation;
      if (o && typeof o.renderGrainPreview === "function")
        return o.renderGrainPreview({ container: host, prepare: true });
      const r = root.ToolAGrainStudioRenderer;
      if (!r) return false;
      if (typeof r.prepareHost === "function") r.prepareHost(host);
      return r.render(host);
    };

    function ensureSelectedGroup(preferFilled = false) {
      const s = state();
      if (!s || !s.grain) return null;
      const mk = materialKey();
      const groups = (s.grain.groups || []).filter(
        (g) => !mk || String((g && g.materialKey) || "") === mk,
      );
      if (!groups.length) return null;
      let g =
        groups.find(
          (x) => String((x && x.id) || "") === String(s.grain.selectedGroupId || ""),
        ) || null;
      if ((!g || (preferFilled && !(g.items || []).length)) && preferFilled)
        g = groups.find((x) => ((x && x.items) || []).length) || g;
      if (!g) g = groups[0] || null;
      if (g) s.grain.selectedGroupId = g.id;
      return g;
    }
    function groupWidth(g) {
      let w = qmm(g && g.widthMm);
      if (!w && g && (g.items || []).length) {
        const e = entry(g.items[0]);
        w = widthMm(e);
        if (w) {
          g.widthMm = w;
          g.widthCm = w / 10;
        }
      }
      return w;
    }
    function groupHeight(g) {
      return ((g && g.items) || []).reduce((sum, ref) => {
        const e = entry(ref);
        return sum + (e ? heightMm(e) : 0);
      }, 0);
    }
    function groupSummary(g) {
      const w = groupWidth(g),
        h = groupHeight(g),
        c = ((g && g.items) || []).length;
      return `${w ? fmt(w) + " mm" : "—"} · ${c} ${c === 1 ? "paneel" : "panelen"}${h ? " · " + fmt(h) + " mm hoog" : ""}`;
    }

    function refreshAll() {
      const b = bridge();
      if (!b) return;
      b.syncOrders && b.syncOrders();
      b.rebuildWidthOptions && b.rebuildWidthOptions();
      b.rebuildEligible && b.rebuildEligible();
      b.rebuildGroups && b.rebuildGroups();
      b.renderCart && b.renderCart();
      b.syncPanelDockChrome && b.syncPanelDockChrome();
      b.renderExtraPanels && b.renderExtraPanels();
      b.syncChecksFromSelect && b.syncChecksFromSelect();
      b.drawExtraPreview && b.drawExtraPreview();
      schedulePreview();
      b.setMessage && b.setMessage("");
    }
    function targetGroup() {
      let g = ensureSelectedGroup(false);
      if (g) return g;
      const b = bridge();
      b && b.newGroup && b.newGroup();
      return ensureSelectedGroup(false);
    }
    function addOne(refs) {
      const s = state(),
        b = bridge(),
        g = targetGroup();
      if (!s || !b || !g) return;
      const e = (refs || []).map(entry).find((x) => x && !x.grainGroupId);
      if (!e) return;
      const w = widthMm(e),
        gw = groupWidth(g);
      if (!b.isGrainCapable || !b.isGrainCapable(e.raw)) return;
      if (gw && !sameWidth(gw, w)) {
        b.setMessage &&
          b.setMessage(`Alleen exact ${fmt(gw)} mm brede panelen kunnen in deze nerf-set.`);
        return;
      }
      if (!g.widthMm) {
        g.widthMm = w;
        g.widthCm = w / 10;
      }
      const ref = String(e.ref || "");
      if (!ref || g.items.map(String).includes(ref)) return;
      // Semantic production truth: BOTTOM -> TOP. Append = stack one level higher.
      g.items.push(ref);
      s.grain.selectedGroupId = g.id;
      refreshAll();
    }

    function displayGroups(entries) {
      const b = bridge();
      try {
        return b && b.groupDisplayEntries ? b.groupDisplayEntries(entries) : [];
      } catch (_) {
        return [];
      }
    }

    function renderEligible() {
      if (!isMobile()) return false;
      const b = bridge(),
        host = q("grainEligible"),
        count = q("grainEligibleCount"),
        toggle = q("grainIncludeExtraToggle"),
        widthSel = q("grainWidthSel");
      if (!b || !host || !count) return false;
      host.innerHTML = "";
      const eligible = (b.getEligible && b.getEligible()) || [];
      count.textContent = String(eligible.length);
      if (toggle) toggle.checked = !!(b.extrasEnabled && b.extrasEnabled());
      if (!eligible.length) {
        host.innerHTML =
          '<div class="grainStudioCompactEmpty">Geen panelen beschikbaar voor doorlopende nerf.</div>';
        return true;
      }

      const active = ensureSelectedGroup(false),
        lockedW = active && (active.items || []).length ? groupWidth(active) : 0;
      const byW = new Map();
      eligible.forEach((e) => {
        const w = widthMm(e);
        if (!(w > 0)) return;
        if (!byW.has(w)) byW.set(w, []);
        byW.get(w).push(e);
      });
      let widths = Array.from(byW.keys()).sort((a, c) => a - c);
      const filter = widthSel && widthSel.value !== "all" ? n(widthSel.value) : 0;
      if (lockedW) widths = widths.filter((w) => sameWidth(w, lockedW));
      else if (filter) widths = widths.filter((w) => sameWidth(w, filter));

      widths.forEach((w) => {
        const entries = byW.get(w) || [];
        const band = document.createElement("section");
        band.className = "grainStudioCompactWidth";
        const free = entries.filter((e) => !e.grainGroupId).length;
        band.innerHTML = `<div class="grainStudioCompactWidthHead"><strong>${esc(fmt(w))} mm</strong><span>${free}/${entries.length} beschikbaar</span></div>`;
        const list = document.createElement("div");
        list.className = "grainStudioCompactAvailableList";
        [{ key: "cart" }, { key: "extra" }].forEach((sec) => {
          const secEntries = entries.filter((e) => e.kind === sec.key);
          if (!secEntries.length) return;
          displayGroups(secEntries)
            .sort((a, c) =>
              String(a?.rep?.label || "").localeCompare(String(c?.rep?.label || "")),
            )
            .forEach((group) => {
              const rep = group.rep,
                total = Math.max(1, group.items.length),
                freeItems = group.items.filter((x) => !x.grainGroupId);
              const row = document.createElement("div");
              row.className =
                "grainStudioCompactAvailable" + (!freeItems.length ? " is-disabled" : "");
              const main = document.createElement("div");
              main.className = "grainStudioCompactAvailableMain";
              main.innerHTML = `<strong>${esc(rep.label)}</strong><span>${esc(fmt(widthMm(rep)))} × ${esc(fmt(heightMm(rep)))} mm${esc(doorLabel(rep.raw))}${rep.kind === "extra" ? " · overig" : ""}</span>`;
              const right = document.createElement("div");
              right.className = "grainStudioCompactAvailableRight";
              const av = document.createElement("span");
              av.className = "grainStudioCompactCount";
              av.textContent = `${freeItems.length}/${total}`;
              const plus = document.createElement("button");
              plus.type = "button";
              plus.className = "grainStudioCompactPlus";
              plus.setAttribute("aria-label", `Voeg ${rep.label} bovenop de nerf-set toe`);
              plus.textContent = "+";
              plus.disabled = !freeItems.length;
              plus.addEventListener("click", () => addOne(freeItems.map((x) => x.ref)));
              right.append(av, plus);
              row.append(main, right);
              list.appendChild(row);
            });
        });
        band.appendChild(list);
        host.appendChild(band);
      });
      return true;
    }

    function mini(e) {
      const box = document.createElement("div");
      box.className = "grainStudioPanelMiniBox";
      const shape = document.createElement("div");
      shape.className = "grainStudioPanelMiniShape";
      const w = Math.max(1, widthMm(e)),
        h = Math.max(1, heightMm(e)),
        sc = Math.min(23 / w, 30 / h);
      shape.style.width = Math.max(4, w * sc) + "px";
      shape.style.height = Math.max(3, h * sc) + "px";
      box.appendChild(shape);
      return box;
    }

    function visualGroupItems(body) {
      return body ? Array.from(body.querySelectorAll(".grainStudioGroupItem")) : [];
    }
    function commitVisualGroupOrder(body, g) {
      if (!body || !g) return false;
      const semantic = visualGroupItems(body)
        .map((el) => String((el.dataset && el.dataset.ref) || ""))
        .filter(Boolean)
        .reverse();
      const before = (g.items || []).map(String);
      if (
        semantic.length !== before.length ||
        semantic.some((ref, index) => ref !== before[index])
      ) {
        g.items = semantic;
        return true;
      }
      return false;
    }
    function insertGroupItemAtClientY(item, body, clientY) {
      if (!item || !body || !Number.isFinite(Number(clientY))) return false;
      const before = visualGroupItems(body).indexOf(item);
      const other = visualGroupItems(body).filter((el) => el !== item);
      const next =
        other.find((el) => {
          const r = el.getBoundingClientRect();
          return Number(clientY) < r.top + r.height / 2;
        }) || null;
      if (next) body.insertBefore(item, next);
      else body.appendChild(item);
      return visualGroupItems(body).indexOf(item) !== before;
    }
    function restoreReorderFocus(ref) {
      const run = () => {
        {
          const row = Array.from(
            document.querySelectorAll("#grainGroups .grainStudioGroupItem"),
          ).find((el) => String((el.dataset && el.dataset.ref) || "") === String(ref || ""));
          const control =
            row && row.querySelector && row.querySelector(".grainStudioDragHandle");
          if (control)
            try {
              control.focus({ preventScroll: true });
            } catch (_) {
              control.focus();
            }
        }
      };
      try {
        root.requestAnimationFrame(run);
      } catch (_) {
        setTimeout(run, 0);
      }
    }
    function commitAndRefreshReorder(body, g, focusRef = "") {
      const changed = commitVisualGroupOrder(body, g);
      if (!changed) return false;
      refreshAll();
      if (focusRef) restoreReorderFocus(focusRef);
      return true;
    }
    function keyboardReorder(item, body, g, direction) {
      const items = visualGroupItems(body),
        from = items.indexOf(item);
      if (from < 0) return false;
      const to = Math.max(0, Math.min(items.length - 1, from + (direction < 0 ? -1 : 1)));
      if (to === from) return false;
      const target = items[to];
      if (to < from) body.insertBefore(item, target);
      else body.insertBefore(item, target.nextSibling);
      return commitAndRefreshReorder(
        body,
        g,
        String((item.dataset && item.dataset.ref) || ""),
      );
    }
    function bindTouchReorder(handle, item, body, g) {
      // iPhone Safari may cancel pointer capture while a row is being reparented in
      // a fixed, scrollable modal. Track at window level, calculate the target from
      // row geometry and retain an explicit Touch Events fallback for older WebKit.
      let activeKind = "",
        activeId = null,
        startY = 0,
        moved = false,
        orderChanged = false,
        semanticSnapshot = null;
      const point = (ev, changed = false) => {
        if (!ev) return null;
        if (activeKind === "touch") {
          const list = changed ? ev.changedTouches : ev.touches;
          return (
            Array.from(list || []).find(
              (t) => activeId == null || t.identifier === activeId,
            ) || null
          );
        }
        return Number.isFinite(Number(ev.clientY)) ? ev : null;
      };
      const scrollHost = () => {
        try {
          return (
            body.closest("#grainOverlay .grainGrid3, #grainOverlay .grainGrid") ||
            body.closest("#grainOverlay .modal")
          );
        } catch (_) {
          return null;
        }
      };
      const autoScroll = (clientY) => {
        const host = scrollHost();
        if (!host) return;
        const r = host.getBoundingClientRect();
        const edge = Math.min(64, Math.max(36, r.height * 0.16));
        let dy = 0;
        if (clientY < r.top + edge) dy = -Math.ceil((r.top + edge - clientY) / 5);
        else if (clientY > r.bottom - edge) dy = Math.ceil((clientY - (r.bottom - edge)) / 5);
        if (!dy) return;
        if (typeof host.scrollBy === "function") host.scrollBy(0, dy);
        else host.scrollTop = n(host.scrollTop) + dy;
      };
      const removeTracking = () => {
        root.removeEventListener("pointermove", onPointerMove);
        root.removeEventListener("pointerup", onPointerEnd);
        root.removeEventListener("pointercancel", onPointerCancel);
        root.removeEventListener("touchmove", onTouchMove);
        root.removeEventListener("touchend", onTouchEnd);
        root.removeEventListener("touchcancel", onTouchCancel);
        root.removeEventListener("blur", onWindowBlur);
        root.removeEventListener("pagehide", onWindowBlur);
      };
      const finish = (ev, cancelled = false, forced = false) => {
        if (!activeKind) return;
        const p = point(ev, true);
        if (
          activeKind === "pointer" &&
          ev &&
          ev.pointerId != null &&
          activeId != null &&
          ev.pointerId !== activeId
        )
          return;
        if (activeKind === "touch" && !p && !forced && !cancelled) return;
        activeKind = "";
        activeId = null;
        removeTracking();
        item.classList.remove("is-dragging");
        if (document.body) document.body.classList.remove("grainStudioGrainReordering");
        if (cancelled || forced) {
          g.items = Array.isArray(semanticSnapshot) ? semanticSnapshot.slice() : [];
          refreshAll();
        } else if (orderChanged) {
          commitAndRefreshReorder(body, g);
        }
        moved = false;
        orderChanged = false;
        semanticSnapshot = null;
        void p;
      };
      const move = (ev, p) => {
        if (!p) return;
        if (ev.cancelable !== false) ev.preventDefault();
        if (Math.abs(Number(p.clientY) - startY) > 4) moved = true;
        if (!moved) return;
        autoScroll(Number(p.clientY));
        if (insertGroupItemAtClientY(item, body, Number(p.clientY))) orderChanged = true;
      };
      function onPointerMove(ev) {
        if (activeKind !== "pointer" || (activeId != null && ev.pointerId !== activeId))
          return;
        move(ev, point(ev));
      }
      function onPointerEnd(ev) {
        if (activeKind === "pointer") finish(ev, false);
      }
      function onPointerCancel(ev) {
        if (activeKind === "pointer") finish(ev, true);
      }
      function onTouchMove(ev) {
        if (activeKind !== "touch") return;
        move(ev, point(ev));
      }
      function onTouchEnd(ev) {
        if (activeKind === "touch") finish(ev, false);
      }
      function onTouchCancel(ev) {
        if (activeKind === "touch") finish(ev, true);
      }
      function onWindowBlur() {
        finish(null, true, true);
      }
      const begin = (kind, id, p, ev) => {
        if (activeKind || !p) return;
        activeKind = kind;
        activeId = id;
        startY = Number(p.clientY);
        moved = false;
        orderChanged = false;
        semanticSnapshot = (Array.isArray(g.items) ? g.items : []).slice();
        item.classList.add("is-dragging");
        if (document.body) document.body.classList.add("grainStudioGrainReordering");
        if (ev.cancelable !== false) ev.preventDefault();
        root.addEventListener("blur", onWindowBlur, { passive: true });
        root.addEventListener("pagehide", onWindowBlur, { passive: true });
        if (kind === "pointer") {
          root.addEventListener("pointermove", onPointerMove, {
            passive: false,
          });
          root.addEventListener("pointerup", onPointerEnd, { passive: false });
          root.addEventListener("pointercancel", onPointerCancel, {
            passive: false,
          });
        } else {
          root.addEventListener("touchmove", onTouchMove, { passive: false });
          root.addEventListener("touchend", onTouchEnd, { passive: false });
          root.addEventListener("touchcancel", onTouchCancel, {
            passive: false,
          });
        }
      };
      handle.addEventListener(
        "pointerdown",
        (ev) => {
          const pointerType = String(ev.pointerType || "").toLowerCase();
          if (
            pointerType === "touch" ||
            ev.isPrimary === false ||
            (ev.button != null && ev.button !== 0)
          )
            return;
          begin("pointer", ev.pointerId, ev, ev);
        },
        { passive: false },
      );
      handle.addEventListener(
        "touchstart",
        (ev) => {
          if (activeKind) {
            if (activeKind === "pointer" && ev.cancelable !== false) ev.preventDefault();
            return;
          }
          const t = ev.changedTouches && ev.changedTouches[0];
          if (t) begin("touch", t.identifier, t, ev);
        },
        { passive: false },
      );
      handle.addEventListener("keydown", (ev) => {
        if (ev.key !== "ArrowUp" && ev.key !== "ArrowDown") return;
        ev.preventDefault();
        keyboardReorder(item, body, g, ev.key === "ArrowUp" ? -1 : 1);
      });
    }

    function renderGroups() {
      if (!isMobile()) return false;
      const s = state(),
        b = bridge(),
        host = q("grainGroups");
      if (!s || !b || !host) return false;
      host.innerHTML = "";
      const mk = materialKey();
      const groups = (s.grain.groups || []).filter(
        (g) => !mk || String(g.materialKey || "") === mk,
      );
      ensureSelectedGroup(false);
      if (!groups.length) {
        host.innerHTML =
          '<div class="grainStudioCompactEmpty">Tik op + bij een paneel; G01 wordt automatisch gemaakt.</div>';
        return true;
      }
      groups.forEach((g) => {
        const selected = String(s.grain.selectedGroupId || "") === String(g.id || "");
        const card = document.createElement("section");
        card.className = "grainStudioCompactGroup" + (selected ? " is-selected" : "");
        card.dataset.groupId = String(g.id || "");
        const head = document.createElement("div");
        head.className = "grainStudioCompactGroupHead";
        const choose = document.createElement("button");
        choose.type = "button";
        choose.className = "grainStudioCompactGroupChoose";
        choose.innerHTML = `<strong>${esc(g.id)}</strong><span>${esc(groupSummary(g))}</span>`;
        choose.addEventListener("click", () => {
          s.grain.selectedGroupId = g.id;
          renderGroups();
          schedulePreview();
        });
        const trash = document.createElement("button");
        trash.type = "button";
        trash.className = "grainStudioCompactGroupDelete";
        trash.setAttribute("aria-label", "Verwijder nerf-set");
        trash.textContent = "×";
        trash.addEventListener("click", (ev) => {
          ev.stopPropagation();
          s.grain.groups = s.grain.groups.filter((x) => x.id !== g.id);
          if (s.grain.selectedGroupId === g.id) s.grain.selectedGroupId = null;
          ensureSelectedGroup(false);
          refreshAll();
        });
        head.append(choose, trash);
        card.appendChild(head);
        const hint = document.createElement("div");
        hint.className = "grainStudioCompactStackHint";
        hint.textContent = "↑ hoger in de stapel · 1 = onderaan";
        card.appendChild(hint);
        const body = document.createElement("div");
        body.className = "grainStudioCompactGroupBody";
        if (!(g.items || []).length) {
          body.innerHTML =
            '<div class="grainStudioCompactEmpty">Voeg eerst het onderste paneel toe.</div>';
        } else {
          const visualItems = g.items.slice().reverse();
          visualItems.forEach((ref, visualIndex) => {
            const semanticIndex = g.items.map(String).indexOf(String(ref)),
              pos = semanticIndex + 1,
              e = entry(ref);
            if (!e) return;
            const item = document.createElement("div");
            item.className =
              "grainStudioGroupItem" +
              (String(root.__grainStudioSelectedGrainRef || "") === String(ref)
                ? " is-selected"
                : "");
            item.dataset.ref = String(ref);
            const badge = document.createElement("span");
            badge.className = "grainStudioOrderBadge";
            badge.textContent = String(pos);
            item.append(badge, mini(e));
            const main = document.createElement("button");
            main.type = "button";
            main.className = "grainStudioGroupItemMain";
            main.innerHTML = `<strong>${esc(e.label)}</strong><span>${esc(fmt(widthMm(e)))} × ${esc(fmt(heightMm(e)))} mm${esc(doorLabel(e.raw))}</span>`;
            main.addEventListener("click", () => {
              root.__grainStudioSelectedGrainRef = String(ref);
              s.grain.selectedGroupId = g.id;
              renderGroups();
              schedulePreview();
            });
            item.appendChild(main);
            const moves = document.createElement("span");
            moves.className = "grainStudioMoveControls";
            const moveUp = document.createElement("button");
            moveUp.type = "button";
            moveUp.className = "grainStudioMoveButton";
            moveUp.setAttribute("aria-label", "Verplaats paneel hoger in de stapel");
            moveUp.textContent = "↑";
            moveUp.disabled = visualIndex === 0;
            moveUp.addEventListener("click", (ev) => {
              ev.preventDefault();
              ev.stopPropagation();
              keyboardReorder(item, body, g, -1);
            });
            const moveDown = document.createElement("button");
            moveDown.type = "button";
            moveDown.className = "grainStudioMoveButton";
            moveDown.setAttribute("aria-label", "Verplaats paneel lager in de stapel");
            moveDown.textContent = "↓";
            moveDown.disabled = visualIndex === visualItems.length - 1;
            moveDown.addEventListener("click", (ev) => {
              ev.preventDefault();
              ev.stopPropagation();
              keyboardReorder(item, body, g, 1);
            });
            moves.append(moveUp, moveDown);
            item.appendChild(moves);
            const drag = document.createElement("button");
            drag.type = "button";
            drag.className = "grainStudioDragHandle";
            drag.setAttribute(
              "aria-label",
              "Wijzig stapelvolgorde; sleep of gebruik pijl omhoog en omlaag",
            );
            drag.setAttribute("aria-keyshortcuts", "ArrowUp ArrowDown");
            drag.innerHTML = "<i></i><i></i><i></i><i></i><i></i><i></i>";
            item.appendChild(drag);
            bindTouchReorder(drag, item, body, g);
            const rm = document.createElement("button");
            rm.type = "button";
            rm.className = "grainStudioRemoveBtn";
            rm.setAttribute("aria-label", "Verwijder uit nerf-set");
            rm.textContent = "×";
            rm.addEventListener("click", (ev) => {
              ev.stopPropagation();
              b.removeFromGroup && b.removeFromGroup(g.id, ref);
            });
            item.appendChild(rm);
            body.appendChild(item);
          });
        }
        card.appendChild(body);
        host.appendChild(card);
      });
      return true;
    }

    let drawer = null,
      handle = null,
      handleHome = null,
      handleNextSibling = null,
      actions = null,
      dragging = false,
      startY = 0,
      startOffset = 0,
      pointerDragged = false,
      lastPointerToggleAt = 0;
    const PEEK = 46;
    const travel = () =>
      drawer ? Math.max(0, drawer.getBoundingClientRect().height - PEEK) : 0;
    const expanded = () => !!(drawer && drawer.classList.contains("grainStudioDrawerOpen"));
    function syncDrawerTop() {
      if (!drawer || !isMobile()) return;
      try {
        const header = document.querySelector("#grainOverlay .grainHeader");
        const rect = header && header.getBoundingClientRect();
        const top =
          rect && Number.isFinite(rect.bottom)
            ? Math.max(0, Math.ceil(rect.bottom + 2))
            : 154;
        drawer.style.setProperty("--grainStudio-grain-drawer-top", top + "px");
      } catch (_) {
        drawer.style.setProperty("--grainStudio-grain-drawer-top", "154px");
      }
    }
    function syncViewportHandle() {
      if (
        !handle ||
        !expanded() ||
        !handle.classList.contains("grainCloseViewportGrainClose")
      )
        return;
      {
        const viewport = root.visualViewport;
        const viewLeft =
          viewport && Number.isFinite(viewport.offsetLeft) ? viewport.offsetLeft : 0;
        const viewTop =
          viewport && Number.isFinite(viewport.offsetTop) ? viewport.offsetTop : 0;
        const viewWidth =
          viewport && Number.isFinite(viewport.width) ? viewport.width : root.innerWidth;
        const viewHeight =
          viewport && Number.isFinite(viewport.height) ? viewport.height : root.innerHeight;
        const width = Math.max(118, Math.min(154, Math.floor(viewWidth - 20)));
        const height = 40;
        const header = document.querySelector("#grainOverlay .grainHeader");
        const headerRect = header && header.getBoundingClientRect();
        const preferredTop =
          headerRect && Number.isFinite(headerRect.bottom)
            ? headerRect.bottom - height - 8
            : viewTop + 10;
        const maxTop = Math.max(viewTop + 8, viewTop + viewHeight - height - 8);
        const top = Math.max(viewTop + 8, Math.min(preferredTop, maxTop));
        const left = Math.max(viewLeft + 8, viewLeft + viewWidth - width - 10);
        handle.style.setProperty("--grainClose-grain-close-left", Math.round(left) + "px");
        handle.style.setProperty("--grainClose-grain-close-top", Math.round(top) + "px");
        handle.style.setProperty("--grainClose-grain-close-width", Math.round(width) + "px");
      }
    }
    function mountViewportHandle(open) {
      if (!handle) return;
      if (open) {
        if (!document.body) return;
        if (!handleHome) {
          handleHome = handle.parentNode;
          handleNextSibling = handle.nextSibling;
        }
        if (handle.parentNode !== document.body) document.body.appendChild(handle);
        handle.classList.add("grainCloseViewportGrainClose");
        syncViewportHandle();
        return;
      }
      handle.classList.remove("grainCloseViewportGrainClose");
      handle.style.removeProperty("--grainClose-grain-close-left");
      handle.style.removeProperty("--grainClose-grain-close-top");
      handle.style.removeProperty("--grainClose-grain-close-width");
      if (handleHome && handle.parentNode !== handleHome) {
        const anchor =
          handleNextSibling && handleNextSibling.parentNode === handleHome
            ? handleNextSibling
            : null;
        handleHome.insertBefore(handle, anchor);
      }
    }
    function setTransform(offset) {
      if (drawer)
        drawer.style.setProperty(
          "transform",
          `translateY(${Math.max(0, Math.min(travel(), offset))}px)`,
          "important",
        );
    }
    function renderOpenPreview() {
      if (!expanded()) return;
      ensureSelectedGroup(false);
      const host = q("grainPreview");
      if (!host) return;
      // Two animation frames guarantee that Safari has committed the fixed drawer and
      // explicit host size before we ask Canvas for its backing-store dimensions.
      root.requestAnimationFrame(() =>
        root.requestAnimationFrame(() => {
          if (!expanded()) return;
          try {
            renderPreview(host);
          } catch (err) {
            console.error("[GrainPreview]", err);
          }
        }),
      );
    }
    function setDrawer(open, instant = false) {
      if (!open) {
        dragging = false;
        pointerDragged = false;
        drawerOpen = false;
        if (drawer) drawer.classList.remove("grainStudioDrawerDragging");
      }
      if (!drawer) return;
      syncDrawerTop();
      drawer.classList.toggle("grainStudioDrawerOpen", !!open);
      drawer.classList.toggle("grainStudioDrawerClosed", !open);
      drawer.style.removeProperty("transform");
      drawer.setAttribute("aria-expanded", open ? "true" : "false");
      drawerOpen = !!open;
      if (handle) {
        handle.setAttribute("aria-expanded", open ? "true" : "false");
        handle.setAttribute("aria-label", open ? "Sluit nerf-preview" : "Open nerf-preview");
        const visibleLabel =
          handle.querySelector && handle.querySelector(".grainStudioDrawerHandleText");
        if (visibleLabel)
          visibleLabel.textContent = open ? "Preview sluiten" : "Nerf-preview";
      }
      mountViewportHandle(!!open);
      if (open) {
        renderOpenPreview();
        if (!instant) setTimeout(renderOpenPreview, 340);
      }
    }
    function buildActions() {
      if (actions || !isMobile()) return;
      const modal = document.querySelector("#grainOverlay .modal");
      if (!modal) return;
      actions = document.createElement("div");
      actions.className = "grainStudioMobileActions";
      const c = document.createElement("button");
      c.type = "button";
      c.className = "btn";
      c.textContent = "Annuleren";
      c.onclick = () => q("grainCancelBtn") && q("grainCancelBtn").click();
      const a = document.createElement("button");
      a.type = "button";
      a.className = "btn btnPrimary";
      a.textContent = "Toepassen";
      a.onclick = () => q("grainApplyBtn") && q("grainApplyBtn").click();
      actions.append(c, a);
      modal.appendChild(actions);
    }
    function initDrawer(forceClosed = false) {
      if (!isMobile()) return;
      drawer = document.querySelector("#grainOverlay .grainPreviewCard");
      if (!drawer) return;
      drawer.classList.add("grainStudioPreviewDrawer");
      syncDrawerTop();
      handle =
        q("grainStudioDrawerHandle") || drawer.querySelector(".grainStudioDrawerHandle");
      if (handle && !handleHome) {
        handleHome = handle.parentNode;
        handleNextSibling = handle.nextSibling;
      }
      const old = q("grainPickerPreviewToggle");
      if (old) old.hidden = true;
      if (!drawer.dataset.grainStudior8gTransitionBound) {
        drawer.dataset.grainStudior8gTransitionBound = "1";
        drawer.addEventListener("transitionend", (ev) => {
          if (ev.propertyName === "transform" && expanded()) renderOpenPreview();
        });
      }
      if (handle && !handle.dataset.grainStudior8gBound) {
        handle.dataset.grainStudior8gBound = "1";
        // Keyboard/assistive click fallback. A real pointer tap is handled on pointerup,
        // because iOS Safari may suppress click after preventDefault on pointerdown.
        handle.addEventListener("click", (ev) => {
          if (Date.now() - lastPointerToggleAt < 700) return;
          ev.preventDefault();
          setDrawer(!expanded());
        });
        handle.addEventListener("pointerdown", (ev) => {
          if (ev.button != null && ev.button !== 0) return;
          dragging = true;
          pointerDragged = false;
          startY = ev.clientY;
          startOffset = expanded() ? 0 : travel();
          drawer.classList.add("grainStudioDrawerDragging");
          handle.setPointerCapture(ev.pointerId);
          ev.preventDefault();
        });
        handle.addEventListener("pointermove", (ev) => {
          if (!dragging) return;
          const dy = ev.clientY - startY;
          if (Math.abs(dy) > 5) pointerDragged = true;
          setTransform(startOffset + dy);
        });
        const finish = (ev, cancelled = false) => {
          if (!dragging) return;
          dragging = false;
          drawer.classList.remove("grainStudioDrawerDragging");
          handle.releasePointerCapture(ev.pointerId);
          const dy = Number(ev.clientY) - startY;
          if (cancelled) {
            setDrawer(startOffset === 0, true);
            return;
          }
          if (!pointerDragged && Math.abs(dy) <= 5) {
            lastPointerToggleAt = Date.now();
            setDrawer(!expanded());
            return;
          }
          const current = Math.max(0, Math.min(travel(), startOffset + dy));
          setDrawer(current < travel() * 0.55, true);
        };
        handle.addEventListener("pointerup", (ev) => finish(ev, false));
        handle.addEventListener("pointercancel", (ev) => finish(ev, true));
      }
      buildActions();
      setDrawer(forceClosed ? false : !!drawerOpen, true);
    }
    function teardown() {
      setDrawer(false, true);
      mountViewportHandle(false);
      if (drawer) {
        drawer.classList.remove(
          "grainStudioPreviewDrawer",
          "grainStudioDrawerOpen",
          "grainStudioDrawerClosed",
          "grainStudioDrawerDragging",
        );
        drawer.style.removeProperty("transform");
      }
      const host = q("grainPreview");
      if (host) {
        host.style.removeProperty("height");
        host.style.removeProperty("min-height");
        host.style.removeProperty("flex");
      }
      if (actions) {
        actions.remove();
        actions = null;
      }
      drawer = null;
      handle = null;
      handleHome = null;
      handleNextSibling = null;
    }
    function onOverlayOpen() {
      drawerOpen = false;
      ensureSelectedGroup(false);
      renderEligible();
      renderGroups();
      requestAnimationFrame(() => initDrawer(true));
    }
    function viewportChanged() {
      if (isMobile()) {
        renderEligible();
        renderGroups();
        initDrawer(false);
        syncDrawerTop();
        syncViewportHandle();
        if (expanded()) renderOpenPreview();
      } else teardown();
    }
    function focusRef(ref) {
      root.__grainStudioSelectedGrainRef = String(ref || "");
      renderGroups();
      schedulePreview();
      setTimeout(() => {
        try {
          const el = document.querySelector(
            `#grainGroups .grainStudioGroupItem[data-ref="${CSS.escape(String(ref || ""))}"]`,
          );
          el && el.scrollIntoView({ behavior: "smooth", block: "center" });
        } catch (_) {
          ToolAErrors.recover("toolA.grain.mobile.scale.js.17", _, [
            "NotSupportedError",
            "InvalidStateError",
          ]);
        }
      }, 20);
    }
    function start() {
      if (isMobile()) initDrawer(true);
      {
        const mq = root.matchMedia(MQ);
        mq.addEventListener
          ? mq.addEventListener("change", viewportChanged)
          : mq.addListener(viewportChanged);
      }
      root.addEventListener("resize", viewportChanged, { passive: true });
      root.addEventListener("orientationchange", viewportChanged, {
        passive: true,
      });
      root.visualViewport &&
        root.visualViewport.addEventListener("resize", syncViewportHandle, {
          passive: true,
        });
      root.visualViewport &&
        root.visualViewport.addEventListener("scroll", syncViewportHandle, {
          passive: true,
        });
    }

    root.ToolAGrainStudioMobile = Object.freeze({
      BUILD: GRAIN_PREVIEW_CTA_BUILD,
      isActive: isMobile,
      renderEligible,
      renderGroups,
      onOverlayOpen,
      focusRef,
      openPreview() {
        initDrawer(false);
        setDrawer(true);
      },
      closePreview() {
        setDrawer(false);
      },
      ensureSelectedGroup,
    });
    if (document.readyState === "loading")
      document.addEventListener("DOMContentLoaded", start, { once: true });
    else start();
  })(window);
}
