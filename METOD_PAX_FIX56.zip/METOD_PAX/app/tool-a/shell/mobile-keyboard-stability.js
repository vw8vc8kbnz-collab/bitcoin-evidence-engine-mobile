let mounted = false;

export function mount() {
  (function () {
    "use strict";
    if (mounted) return;
    mounted = true;

    var vv = window.visualViewport || null;
    var baselineHeight = vv ? vv.height : window.innerHeight;
    var raf = 0;
    var blurTimer = 0;
    var focusSettleTimer = 0;
    var orientationTimer = 0;
    var lifecycle = 0;
    var pageLocked = false;
    var prevHtmlOverflow = "";
    var prevBodyOverflow = "";

    var media = window.matchMedia ? window.matchMedia("(max-width:700px)") : null;
    function mobile() {
      return !!(media && media.matches);
    }
    function step() {
      return String(
        (document.body && document.body.dataset && document.body.dataset.uiStep) || "",
      ).toLowerCase();
    }
    function active() {
      return mobile() && step() === "panels";
    }
    function scrollBox(el) {
      return (
        (el &&
          el.closest &&
          el.closest("#extraOverlay .extraBody,#extraOverlay .modalBody,.rightScroll")) ||
        document.getElementById("rightScroll")
      );
    }
    function editable(el) {
      return !!(
        el &&
        el.matches &&
        el.matches(
          '#stepPanels input:not([type="hidden"]):not([disabled]),#stepPanels textarea:not([disabled]),#stepPanels select:not([disabled]),#stepPanels [contenteditable="true"],#extraOverlay input:not([type="hidden"]):not([disabled]),#extraOverlay textarea:not([disabled]),#extraOverlay select:not([disabled]),#extraOverlay [contenteditable="true"]',
        )
      );
    }
    function focusedEditable() {
      var el = document.activeElement;
      return editable(el) ? el : null;
    }
    function viewportHeight() {
      return vv ? Math.max(1, Math.round(vv.height)) : Math.max(1, window.innerHeight);
    }
    function viewportTop() {
      return vv ? Math.max(0, Math.round(vv.offsetTop || 0)) : 0;
    }
    function keyboardLikely() {
      var h = viewportHeight();
      return !!(focusedEditable() && baselineHeight - h > 90);
    }
    function setVars() {
      if (!document.documentElement || !active()) return;
      var h = viewportHeight(),
        top = viewportTop();
      document.body.style.setProperty("--panelKeyboard-vv-height", h + "px");
      document.body.style.setProperty("--panelKeyboard-vv-top", top + "px");
      var open = keyboardLikely();
      document.body.classList.toggle("panelKeyboardKeyboardOpen", open);
      window.__panelKeyboardActive = !!focusedEditable();
    }
    function keepVisible(el) {
      var box = scrollBox(el);
      if (
        !active() ||
        !box ||
        !editable(el) ||
        el !== document.activeElement ||
        !document.contains(el)
      )
        return;

      var br = box.getBoundingClientRect(),
        er = el.getBoundingClientRect();
      var pad = 18,
        delta = 0;
      if (er.top < br.top + pad) delta = er.top - (br.top + pad);
      else if (er.bottom > br.bottom - pad) delta = er.bottom - (br.bottom - pad);
      if (Math.abs(delta) > 0.5) box.scrollTop += delta;
    }
    function scheduleSync(el) {
      if (!active()) return;
      if (raf) cancelAnimationFrame(raf);
      var expectedLifecycle = lifecycle;
      raf = requestAnimationFrame(function () {
        raf = 0;
        if (expectedLifecycle !== lifecycle || !active()) return;
        setVars();
        keepVisible(el || focusedEditable());
      });
    }
    function lockPage() {
      if (pageLocked || !document.documentElement || !document.body) return;
      prevHtmlOverflow = document.documentElement.style.overflow || "";
      prevBodyOverflow = document.body.style.overflow || "";
      document.documentElement.style.overflow = "hidden";
      document.body.style.overflow = "hidden";
      pageLocked = true;
    }
    function unlockPage() {
      if (!pageLocked || !document.documentElement || !document.body) return;
      document.documentElement.style.overflow = prevHtmlOverflow;
      document.body.style.overflow = prevBodyOverflow;
      document.body.style.removeProperty("--panelKeyboard-vv-height");
      document.body.style.removeProperty("--panelKeyboard-vv-top");
      document.body.classList.remove(
        "panelKeyboardKeyboardOpen",
        "panelKeyboardKeyboardFocus",
      );
      window.__panelKeyboardActive = false;
      pageLocked = false;
    }
    function enterStep() {
      if (!active() || pageLocked) return;
      lifecycle++;
      baselineHeight = viewportHeight();
      lockPage();
      setVars();
      if (focusedEditable()) onFocusIn({ target: focusedEditable() });
    }
    function clearFocusSettle() {
      clearTimeout(focusSettleTimer);
      focusSettleTimer = 0;
    }
    function leaveStep() {
      if (!pageLocked) return;
      lifecycle++;
      clearTimeout(blurTimer);
      clearTimeout(orientationTimer);
      clearFocusSettle();
      if (raf) cancelAnimationFrame(raf);
      raf = 0;
      unlockPage();
    }
    function onFocusIn(ev) {
      if (!active() || !editable(ev.target)) return;
      clearTimeout(blurTimer);
      clearFocusSettle();
      lifecycle++;
      baselineHeight = Math.max(baselineHeight, viewportHeight());
      document.body.classList.add("panelKeyboardKeyboardFocus");
      window.__panelKeyboardActive = true;
      scheduleSync(ev.target);
      var expectedLifecycle = lifecycle;
      // VisualViewport resize events own the keyboard animation. One guarded
      // fallback covers older iOS builds without repeatedly fighting Safari's
      // automatic focus scroll.
      focusSettleTimer = setTimeout(function () {
        focusSettleTimer = 0;
        if (expectedLifecycle === lifecycle && active() && focusedEditable())
          scheduleSync(document.activeElement);
      }, 260);
    }
    function finishSession() {
      if (!active() || !pageLocked || focusedEditable()) return;
      lifecycle++;
      clearFocusSettle();
      if (raf) cancelAnimationFrame(raf);
      raf = 0;
      document.body.classList.remove(
        "panelKeyboardKeyboardOpen",
        "panelKeyboardKeyboardFocus",
      );
      window.__panelKeyboardActive = false;
      document.body.style.setProperty(
        "--panelKeyboard-vv-height",
        (vv ? Math.round(vv.height) : window.innerHeight) + "px",
      );
      document.body.style.setProperty(
        "--panelKeyboard-vv-top",
        (vv ? Math.round(vv.offsetTop || 0) : 0) + "px",
      );
      // Keep the user's current position. Safari already moved the active field
      // into view; restoring the first field's old scrollTop here caused the
      // hard jump when switching fields or dismissing the keyboard.
    }
    function onFocusOut() {
      if (!active() || !pageLocked) return;
      clearTimeout(blurTimer);
      blurTimer = setTimeout(finishSession, 220);
    }
    function onViewport() {
      onStep();
      if (!active()) return;
      if (!focusedEditable() && viewportHeight() > baselineHeight - 40)
        baselineHeight = Math.max(baselineHeight, viewportHeight());
      scheduleSync(focusedEditable());
    }
    function onStep() {
      // The same step can cross the CSS breakpoint during rotation or resize.
      // Lock ownership follows both conditions, and never snapshots its own lock.
      if (active()) enterStep();
      else leaveStep();
    }
    function start() {
      onStep();
      document.addEventListener("focusin", onFocusIn, true);
      document.addEventListener("focusout", onFocusOut, true);
      window.addEventListener("resize", onViewport, { passive: true });
      if (media) {
        if (media.addEventListener) media.addEventListener("change", onViewport);
        else if (media.addListener) media.addListener(onViewport);
      }
      if (vv) {
        vv.addEventListener("resize", onViewport, { passive: true });
        vv.addEventListener("scroll", onViewport, { passive: true });
      }
      window.addEventListener(
        "orientationchange",
        function () {
          onStep();
          clearTimeout(orientationTimer);
          orientationTimer = setTimeout(function () {
            baselineHeight = viewportHeight();
            onViewport();
          }, 260);
        },
        { passive: true },
      );
      new MutationObserver(onStep).observe(document.body, {
        attributes: true,
        attributeFilter: ["data-ui-step"],
      });
    }
    if (document.readyState === "loading")
      document.addEventListener("DOMContentLoaded", start, { once: true });
    else start();
  })();
}
