import { REVISION } from "../version.js";
import { toolAFoundation } from "../runtime/foundation.js";

export function mount() {
  /* Register the first document adapter before the checkout view mounts.
     The checkout component owns the resulting action. */
  (function (root) {
    "use strict";
    const BUILD = REVISION;

    root.document.addEventListener(
      "input",
      function (event) {
        toolAFoundation?.handleCheckoutReviewEvent?.(event);
      },
      true,
    );
    root.document.addEventListener(
      "change",
      function (event) {
        toolAFoundation?.handleCheckoutReviewEvent?.(event);
      },
      true,
    );

    root.document.addEventListener(
      "click",
      function (event) {
        if (toolAFoundation?.handleCheckoutReviewEvent?.(event) === true) return;
      },
      true,
    );

    root.__TOOLA_FIRST_EVENT_OWNER_BUILD = BUILD;
  })(window);
}
