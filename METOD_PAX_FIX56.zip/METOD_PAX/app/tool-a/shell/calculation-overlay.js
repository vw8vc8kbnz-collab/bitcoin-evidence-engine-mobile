export function mount() {
  (function () {
    function byId(id) {
      return document.getElementById(id);
    }
    function totalEl() {
      return byId("priceOverlayTotal") || byId("priceTotalValue");
    }
    function sendBtn() {
      return byId("sendConfigBtn") || byId("btnSendConfig");
    }
    function money(v) {
      try {
        return typeof moneyEUR === "function" ? moneyEUR(Number(v)) : String(v);
      } catch (_) {
        return String(v);
      }
    }
    function activeParentJobId() {
      try {
        const raw = String(
          (window.state && state.activeAuthoritativeJobId) ||
            window.__metod_active_parent_job_id ||
            window.__metod_last_parent_job_id ||
            "",
        ).trim();
        if (!raw) return "";
        return raw.includes("__mat_") ? raw.split("__mat_")[0] : raw;
      } catch (_) {
        return "";
      }
    }
    function currentFinal() {
      try {
        const jid = activeParentJobId();
        const finalJid = String((window.state && state.finalAuthoritativeJobId) || "").trim();
        const total = window.state && state.finalAuthoritativePriceInclVat;
        if (!jid || !finalJid || jid !== finalJid) return null;
        if (total == null || !isFinite(Number(total))) return null;
        return Number(total);
      } catch (_) {
        return null;
      }
    }
    function submitLifecycleLocked() {
      if (window.__metod_submit_inflight === true || window.__metod_submit_done === true)
        return true;
      if (window.__metod_submit_commit_uncertain === true) return true;
      if (window.__metodHasUncertainFinalSubmission?.() === true) return true;

      try {
        return Boolean(sessionStorage.getItem("metod_final_submission_uncertain_parent_job_id"));
      } catch (_) {
        return false;
      }
    }
    function blank() {
      {
        const el = totalEl();
        if (el) el.textContent = "—";
      }
      /* Never use the native disabled state for this CTA. On iOS a disabled
      button emits no click at all, so the canonical submit route cannot show
      a validation or recovery message. submitFinalConfiguration performs the
      authoritative checks and owns its short in-flight disable itself. */
      {
        const btn = sendBtn();
        if (btn && !submitLifecycleLocked()) {
          btn.disabled = false;
          btn.setAttribute("aria-disabled", "true");
        }
      }
    }
    function paint(total) {
      {
        const el = totalEl();
        if (el) el.textContent = money(total);
      }
      {
        const btn = sendBtn();
        if (btn && !submitLifecycleLocked()) {
          btn.disabled = false;
          btn.removeAttribute("aria-disabled");
        }
      }
    }
    async function fetchStrict() {
      const jid = activeParentJobId();
      if (!jid) {
        blank();
        return null;
      }
      const already = currentFinal();
      if (already != null) {
        paint(already);
        return already;
      }
      blank();
      try {
        if (typeof window._hydrateAuthoritativePricingSummary !== "function") return null;
        const ps = await window._hydrateAuthoritativePricingSummary(jid, false);
        // A rejected/superseded read must not repaint or clear a newer result.
        if (!ps || activeParentJobId() !== jid) return null;
        const total = currentFinal();
        if (total == null) return null;
        paint(total);
        return total;
      } catch (_) {
        return null;
      }
    }
    // Price hydration is a data adapter only. It no longer wraps or shadows the
    // canonical checkout visibility/render route.
    window.__metodRefreshAuthoritativePriceTotal = async function () {
      const total = currentFinal();
      if (total != null) {
        paint(total);
        return total;
      }
      return fetchStrict();
    };
    const origShow = window.showOptimizingState;
    window.showOptimizingState = function () {
      window.__metodInvalidateAuthoritativePriceHydration();
      state.finalAuthoritativePriceInclVat = null;
      state.finalAuthoritativeJobId = "";
      state.lastPricingSummary = null;
      state.authoritativePricingReady = false;
      state.activeAuthoritativeJobId = "";
      window.__metod_price_validated_key = null;
      window.__metod_active_parent_job_id = "";
      blank();
      if (typeof origShow === "function") return origShow.apply(this, arguments);
    };
    document.addEventListener("DOMContentLoaded", function () {
      const total = currentFinal();
      if (total != null) paint(total);
      else blank();
    });
  })();
}
