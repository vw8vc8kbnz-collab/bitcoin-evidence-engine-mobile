export function mount() {
  (function () {
    function ready(fn) {
      if (document.readyState === "loading")
        document.addEventListener("DOMContentLoaded", fn, { once: true });
      else fn();
    }
    ready(function () {
      var header = document.querySelector(".rightHeader");
      if (header && !document.getElementById("mobileBrandMobileBrand")) {
        var brand = document.createElement("div");
        brand.id = "mobileBrandMobileBrand";
        brand.innerHTML = '<img src="assets/adzaagt_logo.png" alt="AD Zaagt">';
        header.insertBefore(brand, header.firstChild);
      }

      {
        var handle = document.getElementById("mobileSheetHandle");
        if (!handle || handle.__mobileBrandBound) return;
        handle.__mobileBrandBound = true;
        var startY = 0,
          active = false;
        function isMobile() {
          return window.matchMedia && window.matchMedia("(max-width:700px)").matches;
        }
        function currentStep() {
          return (
            (document.body && document.body.dataset && document.body.dataset.uiStep) ||
            window.__metod_uiStep ||
            "material"
          );
        }
        function setSheet(mode) {
          var st = String(currentStep()).toLowerCase();
          if (st === "details") st = "customer";
          if (st !== "material" && st !== "panels") return;
          document.body.dataset.mobileSheet = mode;
        }
        function onStart(y) {
          if (!isMobile()) return;
          active = true;
          startY = y;
        }
        function onEnd(y) {
          if (!active) return;
          active = false;
          var dy = y - startY;
          if (Math.abs(dy) < 18) {
            setSheet(document.body.dataset.mobileSheet === "peek" ? "expanded" : "peek");
          } else if (dy > 0) {
            setSheet("peek");
          } else {
            setSheet("expanded");
          }
        }
        handle.addEventListener(
          "touchstart",
          function (ev) {
            onStart(ev.touches[0].clientY);
          },
          { passive: true },
        );
        handle.addEventListener(
          "touchend",
          function (ev) {
            var t = ev.changedTouches && ev.changedTouches[0];
            onEnd(t ? t.clientY : startY);
          },
          { passive: true },
        );
        handle.addEventListener("pointerdown", function (ev) {
          onStart(ev.clientY);
        });
        handle.addEventListener("pointerup", function (ev) {
          onEnd(ev.clientY);
        });
      }
    });
  })();
}
