import { REVISION } from "../version.js";

export function mount() {
  /* Current release identity and the feature identities used by diagnostics.
   * These values are evidence only; runtime behavior never branches on them. */
  Object.defineProperty(window, "ToolABuild", {
    value: Object.freeze({ revision: REVISION }),
    writable: false,
  });
}
