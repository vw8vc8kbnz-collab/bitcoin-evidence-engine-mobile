import { toolAFoundation } from "../runtime/foundation.js";

let mounted = false;

export function mount() {
  (function () {
    "use strict";
    if (mounted) return;
    mounted = true;

    var drag = null,
      suppressClickUntil = 0,
      lastStep = "";
    function mobile() {
      return !!(window.matchMedia && window.matchMedia("(max-width:700px)").matches);
    }
    function step() {
      return String(
        (document.body && document.body.dataset && document.body.dataset.uiStep) ||
          window.__metod_uiStep ||
          "",
      ).toLowerCase();
    }
    function active() {
      return mobile() && step() === "panels";
    }
    function drawer() {
      return document.querySelector(".right");
    }
    function handle() {
      return document.getElementById("panelDrawerDrawerHandle");
    }
    function state() {
      return document.body.dataset.panelDrawerDrawer === "closed" ? "closed" : "open";
    }
    function width() {
      var d = drawer();
      return d
        ? Math.max(1, d.getBoundingClientRect().width)
        : Math.min(Math.max(1, innerWidth - 56), 430);
    }
    function closedX() {
      return Math.max(0, width() - 8);
    }

    function ensureAnchor() {
      try {
        return !!toolAFoundation?.placeWizardFooter?.("anchor");
      } catch (_e) {
        return false;
      }
    }
    function attachFooter() {
      var d = drawer();
      if (!d) return false;
      try {
        return !!toolAFoundation?.placeWizardFooter?.("attach", d);
      } catch (_e) {
        return false;
      }
    }
    function restoreFooter() {
      try {
        return !!toolAFoundation?.placeWizardFooter?.("restore");
      } catch (_e) {
        return false;
      }
    }

    function ensureHandle() {
      var d = drawer();
      if (!d) return null;
      var h = handle();
      if (!h) {
        h = document.createElement("button");
        h.type = "button";
        h.id = "panelDrawerDrawerHandle";
        h.setAttribute("aria-label", "Paneelformulier openen of inklappen");
        h.innerHTML = '<span aria-hidden="true">›</span>';
        d.appendChild(h);
        bindHandle(h);
      } else if (h.parentNode !== d) {
        d.appendChild(h);
      }
      return h;
    }

    function setState(next, animate) {
      next = next === "closed" ? "closed" : "open";
      document.body.dataset.panelDrawerDrawer = next;
      document.body.classList.toggle("panelDrawerDragging", animate === false);
      if (animate !== false) document.body.classList.remove("panelDrawerDragging");
      document.documentElement.style.removeProperty("--panelDrawer-live-x");
      var h = handle();
      if (h) h.setAttribute("aria-expanded", next === "open" ? "true" : "false");
    }

    function restorePreview() {
      if (!active()) return;
      [".left", ".canvasWrap", "#cv", "#panelDock", ".mobilePreview"].forEach(function (sel) {
        document.querySelectorAll(sel).forEach(function (el) {
          [
            "display",
            "visibility",
            "opacity",
            "position",
            "inset",
            "top",
            "right",
            "bottom",
            "left",
            "width",
            "max-width",
            "min-width",
            "height",
            "min-height",
            "max-height",
            "margin",
            "margin-top",
            "padding",
            "padding-top",
            "pointer-events",
            "transform",
            "overflow",
          ].forEach(function (prop) {
            el.style.removeProperty(prop);
          });
        });
      });
      [0, 80, 240].forEach(function (ms) {
        setTimeout(function () {
          if (typeof window.renderPreview === "function") window.renderPreview();
          if (typeof window.renderScene === "function") window.renderScene();
        }, ms);
      });
    }

    function enter() {
      attachFooter();
      var h = ensureHandle();
      if (h) {
        h.style.removeProperty("display");
        h.style.removeProperty("pointer-events");
      }
      bindDrawerSurface();
      if (!document.body.dataset.panelDrawerDrawer) setState("open", true);
      restorePreview();
    }
    function leave() {
      var h = handle();
      if (h) {
        h.style.setProperty("display", "none", "important");
        h.style.setProperty("pointer-events", "none", "important");
      }
      document.body.classList.remove("panelDrawerDragging");
      document.documentElement.style.removeProperty("--panelDrawer-live-x");
      delete document.body.dataset.panelDrawerDrawer;
      restoreFooter();
    }
    function apply() {
      if (active()) enter();
      else leave();
      lastStep = step();
    }

    function isInteractiveTarget(target) {
      return !!(
        target &&
        target.closest &&
        target.closest(
          'button,a,input,select,textarea,label,[contenteditable="true"],[role="button"],#wizardFooter',
        )
      );
    }

    function beginDrag(ev, source) {
      if (!active() || (ev.button !== undefined && ev.button !== 0)) return;
      if (source !== "handle" && isInteractiveTarget(ev.target)) return;
      var capture = source === "handle" ? handle() : drawer();
      drag = {
        id: ev.pointerId,
        startX: ev.clientX,
        startY: ev.clientY,
        startT: performance.now(),
        base: state() === "closed" ? closedX() : 0,
        moved: false,
        last: state() === "closed" ? closedX() : 0,
        lastX: ev.clientX,
        lastT: performance.now(),
        vx: 0,
        aborted: false,
        capture: capture,
      };
      capture && capture.setPointerCapture(ev.pointerId);
    }

    function moveDrag(ev) {
      if (!drag || ev.pointerId !== drag.id || !active()) return;
      var dx = ev.clientX - drag.startX,
        dy = ev.clientY - drag.startY;
      if (!drag.moved && Math.abs(dx) < 7 && Math.abs(dy) < 7) return;
      if (!drag.moved) {
        if (Math.abs(dy) > Math.abs(dx) * 1.15) {
          drag.aborted = true;
          return;
        }
        drag.moved = true;
        document.body.classList.add("panelDrawerDragging");
      }
      if (drag.aborted) return;
      ev.preventDefault();
      ev.stopPropagation();
      var now = performance.now(),
        dt = Math.max(1, now - drag.lastT);
      drag.vx = (ev.clientX - drag.lastX) / dt;
      drag.lastX = ev.clientX;
      drag.lastT = now;
      var raw = drag.base + dx,
        max = closedX();
      var x = raw < 0 ? raw * 0.18 : raw > max ? max + (raw - max) * 0.18 : raw;
      drag.last = Math.max(0, Math.min(max, x));
      document.documentElement.style.setProperty("--panelDrawer-live-x", drag.last + "px");
    }

    function finishDrag(ev) {
      if (!drag || ev.pointerId !== drag.id) return;
      var d = drag;
      drag = null;
      document.body.classList.remove("panelDrawerDragging");
      document.documentElement.style.removeProperty("--panelDrawer-live-x");
      d.capture && d.capture.releasePointerCapture(ev.pointerId);
      if (d.aborted || !d.moved) return;
      suppressClickUntil = Date.now() + 500;
      var projected = d.last + d.vx * 190;
      var target = projected < closedX() * 0.5 ? "open" : "closed";
      setState(target, true);
    }

    function bindDragSurface(el, source) {
      if (!el || el.__panelDrawerDragBound) return;
      el.__panelDrawerDragBound = true;
      el.addEventListener("pointerdown", function (ev) {
        beginDrag(ev, source);
      });
      el.addEventListener("pointermove", moveDrag, { passive: false });
      el.addEventListener("pointerup", finishDrag);
      el.addEventListener("pointercancel", finishDrag);
    }

    function bindHandle(h) {
      if (h.__panelDrawerBound) return;
      h.__panelDrawerBound = true;
      bindDragSurface(h, "handle");
      h.addEventListener("click", function (ev) {
        if (!active()) return;
        ev.preventDefault();
        ev.stopPropagation();
        if (Date.now() < suppressClickUntil) return;
        setState(state() === "open" ? "closed" : "open", true);
      });
    }

    function bindDrawerSurface() {
      var d = drawer();
      bindDragSurface(d, "drawer");
    }

    function start() {
      ensureAnchor();
      apply();
      document.addEventListener(
        "tool-a-footer-owner-ready",
        function () {
          requestAnimationFrame(apply);
        },
        { once: true },
      );
      new MutationObserver(function () {
        if (step() !== lastStep) requestAnimationFrame(apply);
      }).observe(document.body, {
        attributes: true,
        attributeFilter: ["data-ui-step"],
      });
      window.addEventListener(
        "resize",
        function () {
          if (window.__panelKeyboardActive) return;
          requestAnimationFrame(apply);
        },
        { passive: true },
      );
      window.addEventListener(
        "orientationchange",
        function () {
          setTimeout(apply, 100);
        },
        { passive: true },
      );
      window.addEventListener(
        "pageshow",
        function () {
          requestAnimationFrame(apply);
        },
        { passive: true },
      );
    }
    if (document.readyState === "loading")
      document.addEventListener("DOMContentLoaded", start, { once: true });
    else start();
  })();
}
