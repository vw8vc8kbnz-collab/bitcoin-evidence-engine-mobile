let mounted = false;

export function mount() {
  (function () {
    if (!window.matchMedia || !window.matchMedia("(max-width:700px)").matches) return;
    if (!/\/toolA\.html(?:$|[?#])/i.test(location.pathname + location.search + location.hash))
      return;
    if (mounted) return;
    mounted = true;
    history.replaceState({ toolA: true, historyGuard: true }, "", location.href);
    history.pushState({ toolA: true, historyGuard: true, guard: true }, "", location.href);
    window.addEventListener("popstate", function () {
      history.pushState({ toolA: true, historyGuard: true, guard: true }, "", location.href);
    });
  })();
}
