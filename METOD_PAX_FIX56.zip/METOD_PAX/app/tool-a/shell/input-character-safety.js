import { ToolAValidators } from "../domain/validators.js";

export function mount() {
  (function () {
    const FIELD_RULES =
      ToolAValidators && typeof ToolAValidators.getFieldRules === "function"
        ? ToolAValidators.getFieldRules()
        : {
            customLabelInput: { kind: "panelName", label: "paneelnaam" },
            extraName: { kind: "panelName", label: "omschrijving" },
            custFirstName: { kind: "text", label: "voornaam" },
            custLastName: { kind: "text", label: "achternaam" },
            custCompany: { kind: "text", label: "bedrijfsnaam" },
            custBillingAddress: { kind: "text", label: "straatnaam" },
            custShippingAddress: { kind: "text", label: "bezorgadres" },
            custPostcode: { kind: "postcode", label: "postcode" },
            custHouseNumber: { kind: "houseNumber", label: "huisnummer" },
            custShippingPostcode: {
              kind: "postcode",
              label: "postcode bezorgadres",
            },
            custShippingHouseNumber: {
              kind: "houseNumber",
              label: "huisnummer bezorgadres",
            },
          };
    let lastWarningAt = 0;

    function sanitizeValue(value, kind) {
      if (
        ToolAValidators &&
        typeof ToolAValidators.sanitizeValue === "function"
      ) {
        return ToolAValidators.sanitizeValue(value, kind);
      }

      let s = String(value || "");
      s = s.replace(/[\x00-\x1F\x7F]/g, " ");
      if (kind === "email") {
        s = s.replace(/\s+/g, "");
        s = s.replace(/[^A-Za-z0-9@._+\-]/g, "");
        return s;
      }
      if (kind === "postcode") {
        s = s.replace(/[^A-Za-z0-9 ]+/g, "").toUpperCase();
        s = s.replace(/\s+/g, " ").trimStart();
        return s;
      }
      if (kind === "houseNumber") {
        s = s.replace(/[^0-9A-Za-z \/\-]+/g, "");
        s = s.replace(/\s+/g, " ").trimStart();
        return s;
      }
      s = s.replace(/[\/:*?"<>|@€$£¥~{}\[\]\^+=!]+/g, " ");
      try {
        s = s.replace(/[^\p{L}\p{N} .,_\-'’‘&()]/gu, "");
      } catch (_) {
        s = s.replace(/[^A-Za-z0-9À-ÿ .,_\-'’‘&()]/g, "");
      }
      s = s.replace(/\s+/g, " ").trimStart();
      if (kind === "panelName") s = s.replace(/^[\s-]+/u, "");
      return s;
    }

    function hintText(rule) {
      if (
        ToolAValidators &&
        typeof ToolAValidators.getHintText === "function"
      ) {
        return ToolAValidators.getHintText(rule);
      }

      if (!rule)
        return "Gebruik alleen letters, cijfers, spaties en eenvoudige tekens zoals - , . of _.";
      if (rule.kind === "email")
        return "Gebruik een geldig e-mailadres. Letters, cijfers en tekens zoals @ . - _ en + zijn toegestaan.";
      if (rule.kind === "postcode")
        return "Gebruik alleen letters, cijfers en spaties in de postcode.";
      if (rule.kind === "houseNumber")
        return "Gebruik alleen cijfers, letters, een streepje of een schuine streep in het huisnummer.";
      if (rule.kind === "panelName")
        return "Gebruik letters, cijfers, spaties en eenvoudige leestekens. Begin de paneelnaam met een letter of cijfer; = + - @ mogen niet vooraan staan.";
      return "Gebruik letters, cijfers, spaties en eenvoudige tekens zoals - , . _ ' ’ & ( ). Tekens zoals @ € ? ! / ^ < > $ £ ¥ ~ | \\ { } [ ] * + = zijn niet toegestaan.";
    }

    function ensureHint(input) {
      if (!input) return null;
      let hint =
        input.parentElement &&
        input.parentElement.querySelector(
          '.charSafetyHint[data-for="' + input.id + '"]',
        );
      if (hint) return hint;
      hint = document.createElement("div");
      hint.className = "charSafetyHint";
      hint.dataset.for = input.id || "";
      try {
        input.insertAdjacentElement("afterend", hint);
      } catch (_) {
        input.parentNode && input.parentNode.appendChild(hint);
      }
      return hint;
    }

    function showGlobalWarning(msg) {
      const now = Date.now();
      if (now - lastWarningAt < 2500) return;
      lastWarningAt = now;

      if (typeof window.showToolAlert === "function") {
        window.showToolAlert("Speciale tekens niet toegestaan\n" + msg);
        return;
      }
    }

    function applySafety(input, rule, showModal) {
      if (!input || !rule) return;
      const raw = String(input.value || "");
      const clean = sanitizeValue(raw, rule.kind);
      const changed = raw !== clean;
      if (changed) input.value = clean;
      const hint = ensureHint(input);
      if (hint) {
        hint.textContent = changed ? hintText(rule) : "";
        hint.dataset.show = changed ? "1" : "0";
      }
      if (changed) input.classList.add("charSafetyTouched");
      else input.classList.remove("charSafetyTouched");
      if (changed && showModal) showGlobalWarning(hintText(rule));
    }

    function bindInput(id, rule) {
      const input = document.getElementById(id);
      if (!input || input.dataset.charSafetyBound === "1") return;
      input.dataset.charSafetyBound = "1";
      input.addEventListener("input", () => applySafety(input, rule, true));
      input.addEventListener("blur", () => applySafety(input, rule, false));
      applySafety(input, rule, false);
    }

    function init() {
      Object.keys(FIELD_RULES).forEach((id) => bindInput(id, FIELD_RULES[id]));
    }

    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", init);
    } else {
      init();
    }

    {
      const mo = new MutationObserver(() => {
        init();
      });
      mo.observe(document.documentElement || document.body, {
        childList: true,
        subtree: true,
      });
    }
  })();
}
