let mounted = false;

export function mount() {
  (function () {
    var bind = function () {
      if (mounted) return;
      if (typeof window.showStep !== "function") return;
      var original = window.showStep;
      window.showStep = function (step) {
        var result = original.apply(this, arguments);

        if (window.innerWidth <= 700) {
          var normalized = String(step || "").toLowerCase();
          if (normalized === "details") normalized = "customer";
          if (["material", "panels", "customer"].indexOf(normalized) !== -1) {
            document.body.dataset.mobileSheet =
              normalized === "material" ? "peek" : "expanded";
            var rs = document.getElementById("rightScroll");
            if (rs) {
              setTimeout(function () {
                rs.scrollTop = 0;
              }, 0);
            }
            window.scrollTo && window.scrollTo(0, 0);
          }
        }

        return result;
      };
      mounted = true;
    };
    bind();
    document.addEventListener("DOMContentLoaded", bind);
    setTimeout(bind, 0);
  })();
}
