let mounted = false;

export function mount() {
  (function () {
    "use strict";
    if (mounted) return;
    mounted = true;

    function isQty(el) {
      return !!(el && el.matches && el.matches("#qty,#extraQty"));
    }
    function clearDefaultOne(el) {
      if (!isQty(el) || el.disabled) return;
      if (String(el.value == null ? "" : el.value).trim() === "1") {
        el.dataset.panelQuantityClearedDefaultOne = "1";
        el.value = "";
      }
    }
    function restoreDefaultOne(el) {
      if (!isQty(el)) return;
      if (String(el.value == null ? "" : el.value).trim() === "") {
        el.value = "1";
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
      }
      delete el.dataset.panelQuantityClearedDefaultOne;
    }

    // type=number does not offer reliable text-selection APIs on iOS Safari. Clear the
    // default "1" on an actual pointer/touch into the text field. For desktop mouse
    // users, leave the native spinner zone alone so step-up from 1 still behaves normally.
    document.addEventListener(
      "pointerdown",
      function (ev) {
        const el = ev.target;
        if (
          !isQty(el) ||
          el.disabled ||
          String(el.value == null ? "" : el.value).trim() !== "1"
        )
          return;
        if (ev.pointerType === "mouse") {
          {
            const r = el.getBoundingClientRect();
            if (Number.isFinite(ev.clientX) && ev.clientX >= r.right - 30) return;
          }
        }
        clearDefaultOne(el);
      },
      true,
    );
    document.addEventListener(
      "focusout",
      function (ev) {
        if (isQty(ev.target)) restoreDefaultOne(ev.target);
      },
      true,
    );
  })();
}
