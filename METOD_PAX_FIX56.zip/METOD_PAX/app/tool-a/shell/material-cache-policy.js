export function mount() {
  (function () {
    try {
      if (localStorage.getItem("public_material_cache_migrated") !== "1") {
        localStorage.removeItem("metod_draft_v1");
        localStorage.removeItem("metod_draft");
        sessionStorage.removeItem("metod_draft_v1");
        sessionStorage.removeItem("metod_draft");
        localStorage.setItem("public_material_cache_migrated", "1");
      }
    } catch (_) {
      ToolAErrors.recover(
        "tool.a.shell.script.22.materialCachePolicy.legacy.material.cache.cleanup.js.1",
        _,
        ["SecurityError", "QuotaExceededError", "SyntaxError"],
      );
    }
  })();
}
