const OVERLAY_IDS = Object.freeze(["overlay", "grainOverlay", "extraOverlay", "overviewOverlay"]);

const OVERLAY_ALIASES = Object.freeze({
  start: "overlay",
  grain: "grainOverlay",
  extra: "extraOverlay",
  overview: "overviewOverlay",
});

export function createOverlayRouterComponent({
  documentRef = globalThis.document,
  getComputedStyleImpl = globalThis.getComputedStyle?.bind(globalThis),
  now = () => Date.now(),
  setIntervalImpl = globalThis.setInterval?.bind(globalThis),
  clearIntervalImpl = globalThis.clearInterval?.bind(globalThis),
  htmlElementClass = globalThis.HTMLElement,
  onBeforeHide = () => {},
} = {}) {
  let activeOverlayId = null;
  let ignoreDismissUntil = 0;
  let bound = false;
  const intervalHandles = [];
  let grainFocus = null;

  function visibleControl(element) {
    if (!element || element.disabled || element.hidden || element.closest?.("[inert]"))
      return false;
    const style = getComputedStyleImpl?.(element);
    return (
      style?.display !== "none" &&
      style?.visibility !== "hidden" &&
      (!element.getClientRects || element.getClientRects().length > 0)
    );
  }

  function focusWithoutScroll(element) {
    if (visibleControl(element)) element.focus?.({ preventScroll: true });
  }

  function grainFocusScope() {
    if (!grainFocus) return null;
    const alert = documentRef?.getElementById?.("toolAlertOverlay");
    // A nested confirmation owns focus until it closes.
    if (alert && visibleControl(alert)) return { root: alert, portal: null };
    const root = documentRef?.getElementById?.("grainOverlay");
    const handle = documentRef?.getElementById?.("grainStudioDrawerHandle");
    const portal = handle?.classList?.contains("grainCloseViewportGrainClose") ? handle : null;
    return { root, portal };
  }

  function focusableControls(scope) {
    const selector = "button, a[href], input, select, textarea, [tabindex]";
    const controls = Array.from(scope.root?.querySelectorAll?.(selector) || []);
    if (scope.portal && !controls.includes(scope.portal)) controls.push(scope.portal);
    return controls.filter((el) => el.tabIndex >= 0 && visibleControl(el));
  }

  function handleModalKeydown(event) {
    const scope = grainFocusScope();
    if (!scope || event.defaultPrevented) return;
    if (event.key === "Tab") {
      const controls = focusableControls(scope);
      const current = controls.indexOf(documentRef.activeElement);
      if (
        !controls.length ||
        current < 0 ||
        (event.shiftKey ? current === 0 : current === controls.length - 1)
      ) {
        event.preventDefault();
        focusWithoutScroll(
          event.shiftKey ? controls.at(-1) || scope.root : controls[0] || scope.root,
        );
      }
    } else if (event.key === "Escape" && scope.root?.id === "grainOverlay") {
      event.preventDefault();
      // Reuse the existing close action, including its wizard/preview cleanup.
      (scope.portal || documentRef.getElementById("grainCloseBtn"))?.click();
    }
  }

  function handleModalFocus(event) {
    const scope = grainFocusScope();
    if (!scope || scope.root?.contains?.(event.target) || scope.portal?.contains?.(event.target))
      return;
    focusWithoutScroll(focusableControls(scope)[0] || scope.root);
  }

  function setGrainFocus(visible) {
    if (visible && !grainFocus) {
      const main = documentRef?.getElementById?.("toolAAppShell");
      grainFocus = {
        opener: documentRef?.activeElement,
        main,
        previousInert: Boolean(main?.inert),
      };
      if (main) main.inert = true;
      const scope = grainFocusScope();
      focusWithoutScroll(focusableControls(scope)[0] || scope.root);
    } else if (!visible && grainFocus) {
      const previous = grainFocus;
      grainFocus = null;
      if (previous.main) previous.main.inert = previous.previousInert;
      if (previous.opener?.isConnected !== false) focusWithoutScroll(previous.opener);
    }
  }

  function normalizeId(target) {
    const raw = typeof target === "string" ? target : target?.id;
    const id = OVERLAY_ALIASES[raw] || raw;
    return OVERLAY_IDS.includes(id) ? id : null;
  }

  function setVisible(target, visible) {
    const id = normalizeId(target);
    if (!id) return false;
    const element = documentRef?.getElementById?.(id);
    if (!element) return false;
    // Owned controls may be portaled outside their modal. Tear them down at
    // this common boundary, including hideAll, backdrop and route changes.
    if (!visible) onBeforeHide(id);
    element.style.display = visible ? "flex" : "none";
    element.style.pointerEvents = visible ? "auto" : "none";
    element.setAttribute("aria-hidden", visible ? "false" : "true");
    if (id === "grainOverlay") setGrainFocus(visible);
    if (visible) {
      activeOverlayId = id;
      ignoreDismissUntil = now() + 350;
    } else if (activeOverlayId === id) {
      activeOverlayId = null;
    }
    return true;
  }

  function hideAll() {
    for (const id of OVERLAY_IDS) setVisible(id, false);
    activeOverlayId = null;
  }

  function open(target) {
    const id = normalizeId(target);
    if (!id) return false;
    hideAll();
    setVisible(id, true);
    if (documentRef?.body) documentRef.body.style.overflow = "hidden";
    return true;
  }

  function close(target) {
    const id = normalizeId(target);
    if (!id) return false;
    setVisible(id, false);
    if (documentRef?.body) documentRef.body.style.overflow = "";
    return true;
  }

  function enforceActiveOverlay() {
    if (typeof getComputedStyleImpl !== "function") return;
    for (const id of OVERLAY_IDS) {
      const element = documentRef?.getElementById?.(id);
      if (!element) continue;
      const computed = getComputedStyleImpl(element);
      const shown = computed.display !== "none";
      if (shown && element.getAttribute("aria-hidden") !== "false") {
        element.setAttribute("aria-hidden", "false");
        activeOverlayId = id;
      }
      const active = activeOverlayId === id || element.getAttribute("aria-hidden") === "false";
      if (!active || !shown) {
        setVisible(id, false);
      } else {
        element.style.pointerEvents = "auto";
      }
    }
  }

  function disableHiddenOverlays() {
    if (typeof getComputedStyleImpl !== "function") return;
    for (const id of OVERLAY_IDS) {
      const element = documentRef?.getElementById?.(id);
      if (!element) continue;
      const computed = getComputedStyleImpl(element);
      const hidden =
        computed.display === "none" ||
        computed.visibility === "hidden" ||
        parseFloat(computed.opacity || "1") < 0.05;
      if (hidden) {
        setVisible(id, false);
      } else {
        element.style.pointerEvents = "auto";
      }
    }
  }

  function handlePointerDown(event) {
    if (now() < ignoreDismissUntil) return;
    const target = event?.target;
    if (htmlElementClass && !(target instanceof htmlElementClass)) return;
    if (!htmlElementClass && !target) return;
    const overlay = target.closest?.(".overlay");
    if (overlay && target === overlay) hideAll();
  }

  function bind() {
    if (bound) return;
    bound = true;
    if (typeof setIntervalImpl === "function") {
      intervalHandles.push(setIntervalImpl(enforceActiveOverlay, 500));
    }
    documentRef?.addEventListener?.("pointerdown", handlePointerDown, {
      capture: true,
    });
    documentRef?.addEventListener?.("keydown", handleModalKeydown);
    documentRef?.addEventListener?.("focusin", handleModalFocus);
    setVisible("grainOverlay", false);
    setVisible("extraOverlay", false);
    setVisible("overviewOverlay", false);
    setVisible("overlay", true);
    if (typeof setIntervalImpl === "function") {
      intervalHandles.push(setIntervalImpl(disableHiddenOverlays, 500));
    }
  }

  function destroy() {
    if (!bound) return;
    documentRef?.removeEventListener?.("pointerdown", handlePointerDown, {
      capture: true,
    });
    documentRef?.removeEventListener?.("keydown", handleModalKeydown);
    documentRef?.removeEventListener?.("focusin", handleModalFocus);
    setGrainFocus(false);
    if (typeof clearIntervalImpl === "function") {
      for (const handle of intervalHandles) clearIntervalImpl(handle);
    }
    intervalHandles.length = 0;
    bound = false;
  }

  function getState() {
    return Object.freeze({ activeOverlayId, ignoreDismissUntil, bound });
  }

  return Object.freeze({
    bind,
    destroy,
    setVisible,
    hideAll,
    open,
    close,
    getState,
  });
}
