import { ToolAPanelsEntry } from "../adapters/panels-entrypoints.js";
import { REVISION } from "../version.js";
import { ToolAMaterialSwatchRenderer } from "../domain/material-swatch-renderer.js";

export const MOBILE_MATERIAL_CART_BUILD = REVISION;

function text(value) {
  return String(value == null ? "" : value).trim();
}

function escapeHtml(value) {
  return text(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function titleForMaterial(material, fallback) {
  const source = material || {};
  return text(
    source.publicName ||
      source.displayName ||
      source.productName ||
      source.decorName ||
      fallback ||
      "Materiaal",
  );
}

function metaForMaterial(material) {
  const source = material || {};
  const bits = [];
  const family = text(
    source.primaryVisualFamily || source.visualFamily || source.decorType || "",
  );
  const thickness = Number(source.thicknessMm);
  const width = Number(source.sheetSizeMm && source.sheetSizeMm.width);
  const height = Number(source.sheetSizeMm && source.sheetSizeMm.height);
  if (family) bits.push(family);
  if (Number.isFinite(thickness) && thickness > 0) bits.push(`${thickness} mm`);
  if (Number.isFinite(width) && width > 0 && Number.isFinite(height) && height > 0)
    bits.push(`${width} × ${height} mm`);
  return bits.join(" · ") || "Gekozen materiaal";
}

export function getMobileMaterialCartModels(state) {
  const source = state && typeof state === "object" ? state : {};
  const activeKey = text(source.activeMaterialKey);
  const cart = Array.isArray(source.cart) ? source.cart : [];
  const extraPanels = Array.isArray(source.extraPanels) ? source.extraPanels : [];
  return (Array.isArray(source.materialBatches) ? source.materialBatches : [])
    .filter((batch) => batch && text(batch.key))
    .map((batch) => ({
      key: text(batch.key),
      title: titleForMaterial(batch.mat, batch.key),
      meta: metaForMaterial(batch.mat),
      material: batch.mat || null,
      active: text(batch.key) === activeKey,
      panelCount:
        cart.filter((item) => text(item && item.materialKey) === text(batch.key)).length +
        extraPanels
          .filter((item) => text(item && item.materialKey) === text(batch.key))
          .reduce((sum, item) => sum + Math.max(1, Number(item && item.qty) || 1), 0),
    }));
}

export function createMobileMaterialCartComponent({
  documentRef = globalThis.document,
  rootRef = globalThis,
  getState = () => rootRef.state || {},
  requestAnimationFrameImpl = rootRef.requestAnimationFrame,
  setTimeoutImpl = rootRef.setTimeout,
  matchMediaImpl = rootRef.matchMedia,
  addWindowEventListenerImpl = rootRef.addEventListener,
  applySwatchImpl = null,
  activateMaterialImpl = null,
  removeMaterialImpl = null,
  confirmRemoveImpl = null,
  showPanelsImpl = null,
} = {}) {
  let initialized = false;
  let restoreFocus = null;
  let pendingRemoveKey = "";
  let removalInProgressKey = "";
  let lastOwnedTouchAction = null;

  function state() {
    try {
      const value = typeof getState === "function" ? getState() : {};
      return value && typeof value === "object" ? value : {};
    } catch (_error) {
      return {};
    }
  }

  function nodes() {
    if (!documentRef || typeof documentRef.getElementById !== "function") return {};
    return {
      trigger: documentRef.getElementById("mobileMaterialCartTrigger"),
      triggerSwatch: documentRef.getElementById("mobileMaterialCartTriggerSwatch"),
      triggerTitle: documentRef.getElementById("mobileMaterialCartTriggerTitle"),
      triggerMeta: documentRef.getElementById("mobileMaterialCartTriggerMeta"),
      triggerCount: documentRef.getElementById("mobileMaterialCartTriggerCount"),
      backdrop: documentRef.getElementById("mobileMaterialCartBackdrop"),
      sheet: documentRef.getElementById("mobileMaterialCartSheet"),
      handle: documentRef.getElementById("mobileMaterialCartHandle"),
      close: documentRef.getElementById("mobileMaterialCartClose"),
      subtitle: documentRef.getElementById("mobileMaterialCartSubtitle"),
      list: documentRef.getElementById("mobileMaterialCartList"),
      continueBtn: documentRef.getElementById("mobileMaterialCartContinue"),
    };
  }

  function isMobile() {
    try {
      return Boolean(
        typeof matchMediaImpl === "function" &&
          matchMediaImpl.call(rootRef, "(max-width:700px)").matches,
      );
    } catch (_error) {
      return Number((rootRef && rootRef.innerWidth) || 9999) <= 700;
    }
  }

  function scheduleFrame(callback) {
    if (typeof requestAnimationFrameImpl === "function") {
      requestAnimationFrameImpl.call(rootRef, callback);
      return;
    }

    callback();
  }

  function applySwatch(element, key, material, sourceState) {
    if (!element) return;

    if (typeof applySwatchImpl === "function") {
      applySwatchImpl(element, key, material, sourceState);
      return;
    }
    if (
      ToolAMaterialSwatchRenderer &&
      typeof ToolAMaterialSwatchRenderer.applyDomSwatch === "function"
    ) {
      ToolAMaterialSwatchRenderer.applyDomSwatch(element, {
        materialKey: key,
        material,
        state: sourceState,
        panelGrainAxis: "V",
        preferredImageVariant: "thumb",
      });
      return;
    }

    const url = text(material && (material.imageThumbUrl || material.imagePreviewUrl));
    if (url) element.style.backgroundImage = `url("${url.replace(/"/g, "%22")}")`;
  }

  function close(options) {
    const current = nodes();
    const body = documentRef && documentRef.body;
    const wasOpen = Boolean(
      body && body.classList && body.classList.contains("mobileMaterialCartOpen"),
    );
    body && body.classList.remove("mobileMaterialCartOpen");
    if (current.trigger) current.trigger.setAttribute("aria-expanded", "false");
    if (current.sheet) current.sheet.setAttribute("aria-hidden", "true");
    if (current.backdrop && typeof setTimeoutImpl === "function") {
      setTimeoutImpl.call(
        rootRef,
        () => {
          if (!body.classList.contains("mobileMaterialCartOpen"))
            current.backdrop.hidden = true;
        },
        260,
      );
    }
    if (wasOpen && !(options && options.restoreFocus === false)) {
      const target =
        restoreFocus &&
        documentRef &&
        typeof documentRef.contains === "function" &&
        documentRef.contains(restoreFocus)
          ? restoreFocus
          : current.trigger;
      try {
        if (target) target.focus({ preventScroll: true });
      } catch (_error) {
        try {
          if (target) target.focus();
        } catch (_focusError) {
          ToolAErrors.recover("tool.a.components.mobile.material.cart.js.3", _focusError, [
            "NotSupportedError",
            "InvalidStateError",
          ]);
        }
      }
    }
    restoreFocus = null;
    if (!(options && options.keepPendingRemoval)) pendingRemoveKey = "";
  }

  function open() {
    try {
      const sourceState = state();
      const models = getMobileMaterialCartModels(sourceState);
      const current = nodes();
      if (!isMobile() || !models.length || !current.sheet || !current.backdrop) return false;
      render(sourceState);
      restoreFocus = documentRef.activeElement || current.trigger;
      current.backdrop.hidden = false;
      current.sheet.setAttribute("aria-hidden", "false");
      if (current.trigger) current.trigger.setAttribute("aria-expanded", "true");
      scheduleFrame(() => {
        documentRef.body.classList.add("mobileMaterialCartOpen");
        try {
          if (current.close) current.close.focus({ preventScroll: true });
        } catch (_error) {
          ToolAErrors.recover("tool.a.components.mobile.material.cart.js.6", _error, [
            "NotSupportedError",
            "InvalidStateError",
          ]);
        }
      });
      return true;
    } catch (_error) {
      return false;
    }
  }

  function render(rawState) {
    try {
      const sourceState = rawState && typeof rawState === "object" ? rawState : state();
      const models = getMobileMaterialCartModels(sourceState);
      const current = nodes();
      if (!current.trigger || !current.list) return models;
      const active = models.find((model) => model.active) || models[0] || null;

      documentRef.body.classList.toggle("hasMobileMaterialCart", models.length > 0);

      current.trigger.hidden = models.length === 0;
      if (current.triggerTitle) {
        current.triggerTitle.textContent =
          models.length === 1 ? "Jouw materiaal" : "Jouw materialen";
      }
      if (current.triggerMeta) {
        current.triggerMeta.textContent =
          models.length === 1 ? "1 gekozen · open" : `${models.length} gekozen · open`;
      }
      if (current.triggerCount) current.triggerCount.textContent = String(models.length);
      if (current.subtitle) {
        current.subtitle.textContent =
          models.length === 1 ? "1 materiaal gekozen" : `${models.length} materialen gekozen`;
      }
      if (current.continueBtn) current.continueBtn.disabled = models.length === 0;
      if (pendingRemoveKey && !models.some((model) => model.key === pendingRemoveKey)) {
        pendingRemoveKey = "";
      }
      current.list.innerHTML = models
        .map(
          (model) => `
      <div class="mobileMaterialCartRow ${model.active ? "isActive" : ""}" data-mobile-material-row="${escapeHtml(model.key)}">
        <button class="mobileMaterialCartSelect" type="button" data-mobile-material-select="${escapeHtml(model.key)}" aria-pressed="${model.active ? "true" : "false"}">
          <span class="mobileMaterialCartSwatch" data-mobile-material-swatch="${escapeHtml(model.key)}" aria-hidden="true"></span>
          <span class="mobileMaterialCartRowCopy">
            <span class="mobileMaterialCartRowTitle">${escapeHtml(model.title)}</span>
            <span class="mobileMaterialCartRowMeta">${escapeHtml(model.meta)}</span>
          </span>
          <span class="mobileMaterialCartActiveMark" aria-hidden="true">✓</span>
        </button>
        <button class="mobileMaterialCartRemove" type="button" data-mobile-material-remove="${escapeHtml(model.key)}" aria-label="${escapeHtml(model.title)} verwijderen">🗑️</button>
        ${
          pendingRemoveKey === model.key
            ? `<div class="mobileMaterialCartConfirm" role="group" aria-label="Verwijderen bevestigen">
          <span>${model.panelCount > 0 ? `Verwijder ook ${model.panelCount} gekoppelde pane${model.panelCount === 1 ? "el" : "len"}?` : "Dit materiaal verwijderen?"}</span>
          <span class="mobileMaterialCartConfirmActions">
            <button type="button" data-mobile-material-remove-cancel="${escapeHtml(model.key)}">Behouden</button>
            <button type="button" class="isDanger" data-mobile-material-remove-confirm="${escapeHtml(model.key)}">Verwijderen</button>
          </span>
        </div>`
            : ""
        }
      </div>`,
        )
        .join("");
      if (active && current.triggerSwatch) {
        applySwatch(current.triggerSwatch, active.key, active.material, sourceState);
      }
      models.forEach((model) => {
        const swatch = Array.from(
          current.list.querySelectorAll("[data-mobile-material-swatch]"),
        ).find(
          (element) =>
            text(element.getAttribute("data-mobile-material-swatch")) === model.key,
        );
        applySwatch(swatch, model.key, model.material, sourceState);
      });
      if (!models.length) close({ restoreFocus: false });
      return models;
    } catch (_error) {
      return [];
    }
  }

  function activate(key) {
    const cleanKey = text(key);
    let invoked = false;
    try {
      if (typeof activateMaterialImpl === "function") {
        activateMaterialImpl(cleanKey);
        invoked = true;
      } else if (
        ToolAPanelsEntry &&
        typeof ToolAPanelsEntry.activateMaterial === "function"
      ) {
        ToolAPanelsEntry.activateMaterial(cleanKey);
        invoked = true;
      }
    } catch (_error) {
      invoked = false;
    }
    render(state());
    return invoked;
  }

  function remove(key) {
    const cleanKey = text(key);
    const model = getMobileMaterialCartModels(state()).find((item) => item.key === cleanKey);
    if (!model) return false;
    // The sheet owns its inline confirmation. Calling the legacy remove route
    // here either deleted an unused material immediately or opened a second
    // confirmation dialog behind this modal on iPhone. Defer every mutation
    // until the explicit confirm action below.
    pendingRemoveKey = cleanKey;
    render(state());
    return true;
  }

  function cancelRemove() {
    pendingRemoveKey = "";
    render(state());
    return true;
  }

  function confirmRemove(key) {
    const cleanKey = text(key || pendingRemoveKey);
    // A confirmed mutation is accepted only for the confirmation currently
    // rendered by this component. This makes a pointerup followed by Safari's
    // compatibility click harmless and prevents stale/detached buttons from
    // deleting a newly selected material.
    if (!cleanKey || cleanKey !== pendingRemoveKey || removalInProgressKey) return false;
    const modelStillExists = getMobileMaterialCartModels(state()).some(
      (item) => item.key === cleanKey,
    );
    if (!modelStillExists) {
      pendingRemoveKey = "";
      render(state());
      return false;
    }
    removalInProgressKey = cleanKey;
    pendingRemoveKey = "";
    let invoked = false;
    let injectedOwner = false;
    try {
      if (typeof confirmRemoveImpl === "function") {
        invoked = confirmRemoveImpl(cleanKey) !== false;
        injectedOwner = true;
      } else if (typeof removeMaterialImpl === "function") {
        // Injected owners are already on the trusted, confirmed boundary.
        invoked = removeMaterialImpl(cleanKey) !== false;
        injectedOwner = true;
      } else if (
        rootRef.ToolAMaterialRemovalTransaction &&
        typeof rootRef.ToolAMaterialRemovalTransaction.removeConfirmed === "function"
      ) {
        // The live application publishes this immutable transaction directly
        // beside the canonical mutation. Do not depend on a later wrapper or
        // on global-export timing inside Safari's module/classic-script split.
        invoked = rootRef.ToolAMaterialRemovalTransaction.removeConfirmed(cleanKey) === true;
      } else if (
        ToolAPanelsEntry &&
        typeof ToolAPanelsEntry.removeMaterialConfirmed === "function"
      ) {
        invoked = ToolAPanelsEntry.removeMaterialConfirmed(cleanKey) === true;
      }
    } catch (_error) {
      invoked = false;
    }
    removalInProgressKey = "";
    const removed = !getMobileMaterialCartModels(state()).some(
      (item) => item.key === cleanKey,
    );
    // Test/application injection is an explicitly trusted transaction owner.
    // The live legacy bridge, however, must prove its postcondition. On a
    // swallowed/missing raw hook keep the inline confirmation actionable; do
    // not fall back to removeMaterialBatch(), which would open a second dialog.
    const handled = invoked && (injectedOwner || removed);
    if (
      !handled &&
      getMobileMaterialCartModels(state()).some((item) => item.key === cleanKey)
    ) {
      pendingRemoveKey = cleanKey;
    }
    render(state());
    return handled;
  }

  function showPanels() {
    if (typeof showPanelsImpl === "function") showPanelsImpl();
    else if (typeof rootRef.__showWizardStep === "function")
      rootRef.__showWizardStep("panels");
    else if (typeof rootRef.showStep === "function") rootRef.showStep("panels");
  }

  function closestActionTarget(event, selector) {
    const rawTarget = event && event.target;
    const target =
      rawTarget && rawTarget.nodeType === 3 ? rawTarget.parentElement : rawTarget;
    return target && typeof target.closest === "function" ? target.closest(selector) : null;
  }

  function actionFromEvent(event) {
    const definitions = [
      [
        "confirm",
        "[data-mobile-material-remove-confirm]",
        "data-mobile-material-remove-confirm",
      ],
      [
        "cancel",
        "[data-mobile-material-remove-cancel]",
        "data-mobile-material-remove-cancel",
      ],
      ["remove", "[data-mobile-material-remove]", "data-mobile-material-remove"],
      ["select", "[data-mobile-material-select]", "data-mobile-material-select"],
    ];
    for (const [kind, selector, attribute] of definitions) {
      const target = closestActionTarget(event, selector);
      if (target) return { kind, key: text(target.getAttribute(attribute)) };
    }
    return null;
  }

  function claimOwnedEvent(event) {
    event.preventDefault();
    event.stopPropagation();
  }

  function invokeOwnedAction(action) {
    if (!action) return false;
    if (action.kind === "confirm") return confirmRemove(action.key);
    if (action.kind === "cancel") return cancelRemove();
    if (action.kind === "remove") return remove(action.key);
    if (action.kind === "select") return activate(action.key);
    return false;
  }

  function handleListAction(event) {
    const eventType = text(event && event.type).toLowerCase();
    const pointerType = text(event && event.pointerType).toLowerCase();
    if (eventType === "pointerup" && pointerType !== "touch" && pointerType !== "pen") {
      return;
    }
    const action = actionFromEvent(event);
    if (!action) return;
    const signature = `${action.kind}:${action.key}`;
    const now = Date.now();
    const duplicate =
      lastOwnedTouchAction &&
      lastOwnedTouchAction.signature === signature &&
      lastOwnedTouchAction.eventType !== eventType &&
      now - lastOwnedTouchAction.at < 1000;
    if (duplicate) {
      claimOwnedEvent(event);
      return;
    }
    // Claim while the tapped node is still attached. The action may render a
    // replacement row synchronously, which made a late claim unreliable in
    // WebKit and allowed a compatibility event to reach a retired owner.
    claimOwnedEvent(event);
    if (!invokeOwnedAction(action)) return;
    if (eventType === "pointerup" || eventType === "touchend") {
      lastOwnedTouchAction = { signature, eventType, at: now };
    } else {
      lastOwnedTouchAction = null;
    }
  }

  function init() {
    if (initialized) return true;
    const current = nodes();
    if (!current.trigger || !current.sheet || !current.list) return false;
    initialized = true;
    current.trigger.addEventListener("click", open);
    if (current.backdrop) current.backdrop.addEventListener("click", () => close());
    if (current.close) current.close.addEventListener("click", () => close());
    if (current.handle) current.handle.addEventListener("click", () => close());
    if (current.continueBtn) {
      current.continueBtn.addEventListener("click", () => {
        close({ restoreFocus: false });
        showPanels();
      });
    }
    // This stable list is the sole physical event owner for its dynamic rows.
    // iPhone Safari can omit a compatibility click inside a fixed bottom sheet,
    // while hybrid Pointer/Touch delivery can otherwise execute one tap twice.
    current.list.addEventListener("pointerup", handleListAction, {
      passive: false,
    });
    current.list.addEventListener("touchend", handleListAction, {
      passive: false,
    });
    current.list.addEventListener("click", handleListAction);
    documentRef.addEventListener("keydown", (event) => {
      if (
        event.key === "Escape" &&
        documentRef.body.classList.contains("mobileMaterialCartOpen")
      ) {
        event.preventDefault();
        close();
      }
    });
    documentRef.addEventListener("adzaagt-material-selection-updated", () => render(state()));
    // A fast iPhone can select from the local public catalog before network
    // revalidation has supplied the current thumbnail URLs. Re-render exactly
    // when that authoritative catalog update lands so beige fallbacks are
    // replaced without requiring another selection or reopening the sheet.
    documentRef.addEventListener("adzaagt-material-catalog-updated", () => render(state()));
    if (typeof addWindowEventListenerImpl === "function") {
      addWindowEventListenerImpl.call(
        rootRef,
        "resize",
        () => {
          if (!isMobile()) close({ restoreFocus: false });
        },
        { passive: true },
      );
    }
    render(state());
    return true;
  }

  return Object.freeze({
    BUILD: MOBILE_MATERIAL_CART_BUILD,
    getModels: getMobileMaterialCartModels,
    init,
    render,
    open,
    close,
    remove,
    confirmRemove,
    cancelRemove,
  });
}
