import { REVISION } from "../version.js";
import { ToolACustomerValidation } from "../domain/customer-validation.js";
export const CHECKOUT_REVIEW_COMPONENT_BUILD = REVISION;

function clean(value) {
  return String(value == null ? "" : value).trim();
}

function escapeHtml(value) {
  return String(value == null ? "" : value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function isRecord(value) {
  return Boolean(value && typeof value === "object" && !Array.isArray(value));
}

export function createCheckoutReviewComponent({
  documentRef = globalThis.document,
  rootRef = globalThis,
  getCustomerView = null,
} = {}) {
  let bound = false;
  let readyAnnounced = false;
  let calculationSnapshot = null;

  function byId(id) {
    return documentRef?.getElementById?.(id) || null;
  }

  function field(id) {
    return clean(byId(id)?.value);
  }

  function liveCustomer() {
    const billingAddress = field("custBillingAddress");
    const postcode = field("custPostcode");
    const houseNumber = field("custHouseNumber");
    const shippingSameAsBilling = byId("custShipSame")?.checked !== false;
    const shippingAddress = shippingSameAsBilling ? billingAddress : field("custShippingAddress");
    const shippingPostcode = shippingSameAsBilling ? postcode : field("custShippingPostcode");
    const shippingHouseNumber = shippingSameAsBilling
      ? houseNumber
      : field("custShippingHouseNumber");
    return {
      firstName: field("custFirstName"),
      lastName: field("custLastName"),
      company: field("custCompany"),
      email: field("custEmail"),
      phone: field("custPhone"),
      billingAddress,
      shippingAddress,
      shippingPostcode,
      shippingHouseNumber,
      shippingSameAsBilling,
      postcode,
      houseNumber,
      address1: shippingAddress || billingAddress,
      address2: "",
      city: field("custCity"),
      country: field("custCountry"),
      shippingCity: field(shippingSameAsBilling ? "custCity" : "custShippingCity"),
      shippingCountry: field(shippingSameAsBilling ? "custCountry" : "custShippingCountry"),
    };
  }

  function hasCustomerValue(customer) {
    return [
      "firstName",
      "lastName",
      "company",
      "email",
      "phone",
      "billingAddress",
      "shippingAddress",
      "shippingPostcode",
      "shippingHouseNumber",
      "postcode",
      "houseNumber",
    ].some((key) => clean(customer?.[key]));
  }

  function customerValidationResult(customer) {
    const owner = rootRef?.ToolACustomerValidation || ToolACustomerValidation;
    if (owner && typeof owner.validateCustomer === "function") {
      {
        const result = owner.validateCustomer(customer);
        if (isRecord(result) && typeof result.valid === "boolean") return result;
      }
      return Object.freeze({ valid: false, contractUnavailable: false });
    }
    // Keep pre-owner headless component consumers testable, but never let a browser
    // continue when a stale/missing classic bundle omitted the canonical contract.
    if (typeof globalThis.document === "undefined") {
      return Object.freeze({
        valid: Boolean(clean(customer?.email)),
        contractUnavailable: true,
      });
    }
    return Object.freeze({ valid: false, contractUnavailable: true });
  }

  function captureCustomerSnapshot(options = {}) {
    const force = options.force === true;
    const customer = liveCustomer();
    if (!force && !hasCustomerValue(customer)) {
      return rootRef.__metod_checkout_live_customer || null;
    }
    const snapshot = { ...customer };
    rootRef.__metod_checkout_live_customer = { ...snapshot };
    const state = isRecord(options.state) ? options.state : rootRef.state;
    if (isRecord(state)) {
      state.checkout = isRecord(state.checkout) ? state.checkout : {};
      state.checkout.customer = { ...snapshot };
      state.checkout.customerSnapshot = { ...snapshot };
      state.lastCalculatedCustomer = { ...snapshot };
      const note = field("custNote");
      if (note || force) state.checkout.note = note;
    }
    return { ...snapshot };
  }

  function currentCustomer(state, explicitCustomer) {
    const sealed = calculationSnapshot?.customer || state?.checkout?.reviewSnapshot?.customer;
    if (isRecord(sealed) && hasCustomerValue(sealed)) return sealed;
    if (isRecord(explicitCustomer) && hasCustomerValue(explicitCustomer)) return explicitCustomer;
    {
      const view = typeof getCustomerView === "function" ? getCustomerView() : null;
      if (
        view?.readSucceeded === true &&
        isRecord(view.customerSnapshot) &&
        (view.hasCustomerData === true || hasCustomerValue(view.customerSnapshot))
      ) {
        return view.customerSnapshot;
      }
    }
    const candidates = [
      state?.lastCalculatedCustomer,
      state?.checkout?.customer,
      rootRef.__metod_checkout_live_customer,
      state?.checkout?.customerSnapshot,
      state?.customer,
    ];
    return candidates.find((candidate) => isRecord(candidate) && hasCustomerValue(candidate)) || {};
  }

  function batchMaterialModels(state) {
    const batchByKey = new Map();
    for (const batch of Array.isArray(state?.materialBatches) ? state.materialBatches : []) {
      const key = clean(batch?.key);
      if (!key) continue;
      const material = batch?.mat || batch?.material || {};
      const code = clean(material?.articleNumber || material?.id || material?.code || key) || key;
      const rawName =
        material?.productName ?? material?.name ?? material?.label ?? material?.decorName ?? code;
      const normalizedName = clean(rawName);
      const name =
        normalizedName && !/^[0-9]+(?:\.[0-9]+)?$/.test(normalizedName)
          ? normalizedName
          : clean(material?.productName || material?.name || material?.label || code) || code;
      const model = {
        code,
        name,
        grainEnabled: typeof batch?.grainEnabled === "boolean" ? batch.grainEnabled : true,
      };
      batchByKey.set(key, model);
      batchByKey.set(code, model);
    }

    return batchByKey;
  }

  function stateProductionRows(state) {
    return [
      ...(Array.isArray(state?.cart) ? state.cart : []),
      ...(Array.isArray(state?.extraPanels) ? state.extraPanels : []),
    ];
  }

  function materialModels(state, productionRows = null) {
    const panels = Array.isArray(productionRows) ? productionRows : stateProductionRows(state);
    const batchByKey = batchMaterialModels(state);
    const materials = new Map();
    for (const panel of panels) {
      const rawKey = clean(
        panel?.materialKey ||
          panel?.material_key ||
          panel?.activeMaterialKey ||
          panel?.matKey ||
          panel?.MaterialCode ||
          panel?.ArticleNumber ||
          panel?.articleNumber ||
          panel?.materialCode ||
          panel?.material ||
          state?.activeMaterialKey,
      );
      if (!rawKey) continue;
      const batch = batchByKey.get(rawKey);
      const key = batch?.code || rawKey;
      const grainEnabled =
        panel?.grainEnabled === true ||
        clean(panel?.GrainGroup) ||
        panel?.RotationAllowed === false ||
        panel?.rotationAllowed === false ||
        batch?.grainEnabled === true;
      const rowName = clean(panel?.DecorName || panel?.decorName || panel?.materialName);
      const current = materials.get(key) || {
        key,
        name: batch?.name || rowName || key,
        panels: 0,
        grainEnabled: false,
      };
      current.panels += Number(panel?.Qty ?? panel?.qty) || 1;
      current.grainEnabled = current.grainEnabled || Boolean(grainEnabled);
      materials.set(key, current);
    }
    return Array.from(materials.values()).sort((left, right) =>
      left.key.localeCompare(right.key, "nl", { sensitivity: "base" }),
    );
  }

  function panelCount(state, productionRows = null) {
    const rows = Array.isArray(productionRows) ? productionRows : stateProductionRows(state);
    return rows.reduce((total, panel) => total + (Number(panel?.Qty ?? panel?.qty) || 1), 0);
  }

  function cloneCalculationSnapshot(snapshot) {
    if (!isRecord(snapshot)) return null;
    return {
      schemaVersion: Number(snapshot.schemaVersion) || 2,
      customer: { ...(isRecord(snapshot.customer) ? snapshot.customer : {}) },
      materials: (Array.isArray(snapshot.materials) ? snapshot.materials : [])
        .filter(isRecord)
        .map((model) => ({ ...model })),
      panelCount: Number(snapshot.panelCount) || 0,
      note: clean(snapshot.note),
    };
  }

  function isCompleteCalculationSnapshot(snapshot) {
    if (!isRecord(snapshot)) return false;
    const customer = isRecord(snapshot.customer) ? snapshot.customer : {};
    const materials = Array.isArray(snapshot.materials) ? snapshot.materials.filter(isRecord) : [];
    return Boolean(
      customerValidationResult(customer).valid &&
        materials.length > 0 &&
        Number.isFinite(Number(snapshot.panelCount)) &&
        Number(snapshot.panelCount) > 0,
    );
  }

  function freezeCalculationSnapshot(snapshot) {
    const copy = cloneCalculationSnapshot(snapshot);
    if (!copy) return null;
    Object.freeze(copy.customer);
    copy.materials.forEach(Object.freeze);
    Object.freeze(copy.materials);
    return Object.freeze(copy);
  }

  function captureCalculationSnapshot(options = {}) {
    const state = isRecord(options.state) ? options.state : rootRef.state;
    if (!isRecord(state)) return null;
    const customer =
      isRecord(options.customer) && hasCustomerValue(options.customer)
        ? options.customer
        : currentCustomer(state, options.customer);
    const productionRows = Array.isArray(options.productionRows) ? options.productionRows : null;
    const snapshot = {
      schemaVersion: 2,
      customer: { ...customer },
      materials: materialModels(state, productionRows).map((model) => ({
        ...model,
      })),
      panelCount: panelCount(state, productionRows),
      note: clean(options.note ?? state?.checkout?.note),
    };
    calculationSnapshot = freezeCalculationSnapshot(snapshot);
    state.checkout = isRecord(state.checkout) ? state.checkout : {};
    state.checkout.reviewSnapshot = cloneCalculationSnapshot(snapshot);
    return cloneCalculationSnapshot(snapshot);
  }

  function clearCalculationSnapshot(options = {}) {
    calculationSnapshot = null;
    const state = isRecord(options.state) ? options.state : rootRef.state;
    if (isRecord(state?.checkout)) state.checkout.reviewSnapshot = null;
    return true;
  }

  function getCalculationSnapshot() {
    return cloneCalculationSnapshot(calculationSnapshot);
  }

  function render(options = {}) {
    const state = isRecord(options.state) ? options.state : rootRef.state;
    if (!isRecord(state)) return false;
    // A completed asynchronous job passes its own exact snapshot explicitly.
    // That job-scoped value always wins over mutable wizard/global state.
    const explicitSnapshot = isRecord(options.snapshot)
      ? cloneCalculationSnapshot(options.snapshot)
      : null;
    const reviewSnapshot =
      explicitSnapshot ||
      calculationSnapshot ||
      (isRecord(state?.checkout?.reviewSnapshot) ? state.checkout.reviewSnapshot : null);
    if (explicitSnapshot && !isCompleteCalculationSnapshot(explicitSnapshot)) return false;
    const customer = isCompleteCalculationSnapshot(reviewSnapshot)
      ? reviewSnapshot.customer
      : currentCustomer(state, options.customer);
    try {
      const requiredIds = [
        "priceRO_personal",
        "priceRO_contact",
        "priceRO_address",
        "priceCustomerSummary",
        "priceMaterialSummary",
        "priceGrainLine",
        "pricePanelCountLine",
      ];
      const requiredNodes = Object.fromEntries(requiredIds.map((id) => [id, byId(id)]));
      if (requiredIds.some((id) => !requiredNodes[id])) return false;
      const name = [customer.firstName, customer.lastName].filter(Boolean).join(" ").trim();
      const personal = [name, clean(customer.company)].filter(Boolean);
      const contact = [clean(customer.email), clean(customer.phone)].filter(Boolean);
      const billingAddressLine = [customer.postcode, customer.houseNumber]
        .filter(Boolean)
        .join(" ")
        .trim();
      const shippingUsesBilling = customer.shippingSameAsBilling !== false;
      const shippingPostcode = clean(
        customer.shippingPostcode ||
          customer.shippingPostalCode ||
          (shippingUsesBilling ? customer.postcode : ""),
      );
      const shippingHouseNumber = clean(
        customer.shippingHouseNumber ||
          customer.deliveryHouseNumber ||
          (shippingUsesBilling ? customer.houseNumber : ""),
      );
      const shippingAddressLine = [shippingPostcode, shippingHouseNumber]
        .filter(Boolean)
        .join(" ")
        .trim();
      const addresses = [];
      if (customer.billingAddress) {
        addresses.push(
          `Factuur: ${[clean(customer.billingAddress), billingAddressLine].filter(Boolean).join(" ")}`.trim(),
        );
      }
      if (customer.shippingAddress) {
        addresses.push(
          `Bezorg: ${[clean(customer.shippingAddress), shippingAddressLine].filter(Boolean).join(" ")}`.trim(),
        );
      }
      const compact = [name, clean(customer.email), clean(customer.phone)].filter(Boolean);

      const personalEl = requiredNodes.priceRO_personal;
      const contactEl = requiredNodes.priceRO_contact;
      const addressEl = requiredNodes.priceRO_address;
      const compactEl = requiredNodes.priceCustomerSummary;
      if (personalEl) personalEl.textContent = personal.length ? personal.join("\n") : "—";
      if (contactEl) contactEl.textContent = contact.length ? contact.join("\n") : "—";
      if (addressEl) addressEl.textContent = addresses.length ? addresses.join("\n") : "—";
      if (compactEl) compactEl.textContent = compact.length ? compact.join("\n") : "—";

      const sealedModels = Array.isArray(reviewSnapshot?.materials)
        ? reviewSnapshot.materials.filter(isRecord)
        : [];
      const models = sealedModels.length ? sealedModels : materialModels(state);
      const materialsEl = requiredNodes.priceMaterialSummary;
      const grainEl = requiredNodes.priceGrainLine;
      if (materialsEl) {
        if (!models.length) materialsEl.textContent = "—";
        else
          materialsEl.innerHTML = models
            .map(
              (model) =>
                `${escapeHtml(model.name || model.key)}<span class="help">${escapeHtml(model.panels ? ` · ${model.panels} panelen` : "")}</span>`,
            )
            .join("<br>");
      }
      if (grainEl) {
        if (!models.length) grainEl.textContent = "—";
        else
          grainEl.innerHTML = models
            .map(
              (model) =>
                `${escapeHtml(model.name || model.key)}: ${escapeHtml(model.grainEnabled ? "AAN (geen rotatie)" : "UIT (rotatie toegestaan)")}`,
            )
            .join("<br>");
      }

      const renderedPanelCount =
        Number.isFinite(Number(reviewSnapshot?.panelCount)) && Number(reviewSnapshot.panelCount) > 0
          ? Number(reviewSnapshot.panelCount)
          : panelCount(state);
      const panelCountEl = requiredNodes.pricePanelCountLine;
      if (panelCountEl) panelCountEl.textContent = String(renderedPanelCount || "—");
      return true;
    } catch (_error) {
      return false;
    }
  }

  function open(options = {}) {
    const state = isRecord(options.state) ? options.state : rootRef.state;
    if (!isRecord(state)) return false;
    const explicitSnapshot = isRecord(options.snapshot)
      ? cloneCalculationSnapshot(options.snapshot)
      : null;
    const reviewSnapshot =
      explicitSnapshot ||
      calculationSnapshot ||
      (isRecord(state?.checkout?.reviewSnapshot) ? state.checkout.reviewSnapshot : null);
    // The result modal is transactional: never expose a price-only shell when
    // customer, material or production-row data is incomplete.
    if (!isCompleteCalculationSnapshot(reviewSnapshot)) return false;
    if (!render({ ...options, state, snapshot: reviewSnapshot })) return false;
    const overlay = byId("priceOverlay");
    if (!overlay) return false;
    try {
      overlay.style.display = "flex";
      overlay.setAttribute?.("aria-hidden", "false");
      if (documentRef.body && documentRef.body.dataset.metodCheckoutReviewOpen !== "1") {
        documentRef.body.dataset.metodCheckoutReviewOpen = "1";
        documentRef.body.dataset.metodCheckoutReviewPrevOverflow =
          documentRef.body.style.overflow || "";
        documentRef.body.style.overflow = "hidden";
      }
      return true;
    } catch (_error) {
      return false;
    }
  }

  function close() {
    try {
      const overlay = byId("priceOverlay");
      if (overlay) {
        overlay.style.display = "none";
        overlay.setAttribute?.("aria-hidden", "true");
      }
      if (documentRef.body?.dataset.metodCheckoutReviewOpen === "1") {
        documentRef.body.style.overflow =
          documentRef.body.dataset.metodCheckoutReviewPrevOverflow || "";
        delete documentRef.body.dataset.metodCheckoutReviewPrevOverflow;
        delete documentRef.body.dataset.metodCheckoutReviewOpen;
      }
      return Boolean(overlay);
    } catch (_error) {
      return false;
    }
  }

  function canSubmit(options = {}) {
    const state = isRecord(options.state) ? options.state : rootRef.state;
    if (!isRecord(state)) return false;
    const customer = currentCustomer(state, options.customer);
    const hasPanels =
      (Array.isArray(state.cart) && state.cart.length > 0) ||
      (Array.isArray(state.extraPanels) && state.extraPanels.length > 0) ||
      Number(calculationSnapshot?.panelCount || state?.checkout?.reviewSnapshot?.panelCount) > 0;
    return Boolean(customerValidationResult(customer).valid && hasPanels);
  }

  function reportSubmitError(error) {
    rootRef.statusMsg?.(`Verzenden mislukt: ${error?.message || error}`, true);
  }

  function handleEvent(event) {
    const target = event?.target;
    const closest = (selector) => (target?.closest ? target.closest(selector) : null);
    if (event?.type === "input" || event?.type === "change") {
      if (closest("#stepCustomer")) captureCustomerSnapshot();
      return false;
    }
    if (event?.type !== "click") return false;

    if (closest("#overviewNextBtn, #legacySaveBtn, #saveBtn, #wizardNextBtn, #wizardOverviewBtn")) {
      captureCustomerSnapshot();
    }
    const submit = closest("#sendConfigBtn, #btnSendConfig");
    if (!submit) return false;
    event.preventDefault?.();
    event.stopImmediatePropagation?.();
    captureCustomerSnapshot();
    const submitFinal = rootRef.__metodSubmitFinalConfiguration;
    if (typeof submitFinal !== "function") {
      rootRef.alert?.("De verzendfunctie is niet geladen. Herlaad Tool A en probeer opnieuw.");
      return true;
    }
    try {
      const result = submitFinal(submit);
      if (result && typeof result.catch === "function") result.catch(reportSubmitError);
    } catch (error) {
      reportSubmitError(error);
    }
    return true;
  }

  function bind() {
    if (bound) return false;
    bound = true;
    rootRef.__metodCommitLiveCustomer = (force = false) => captureCustomerSnapshot({ force });
    if (rootRef.__TOOLA_FIRST_EVENT_OWNER_BUILD) return true;
    documentRef?.addEventListener?.("input", handleEvent, true);
    documentRef?.addEventListener?.("change", handleEvent, true);
    documentRef?.addEventListener?.("click", handleEvent, true);
    return true;
  }

  function announceReady() {
    if (readyAnnounced) return false;
    readyAnnounced = true;
    if (documentRef?.dispatchEvent && typeof rootRef.Event === "function") {
      documentRef.dispatchEvent(new rootRef.Event("tool-a-checkout-review-owner-ready"));
    }
    return true;
  }

  return Object.freeze({
    BUILD: CHECKOUT_REVIEW_COMPONENT_BUILD,
    bind,
    handleEvent,
    captureCustomerSnapshot,
    captureCalculationSnapshot,
    getCalculationSnapshot,
    isCompleteCalculationSnapshot,
    clearCalculationSnapshot,
    render,
    open,
    close,
    canSubmit,
    announceReady,
  });
}
