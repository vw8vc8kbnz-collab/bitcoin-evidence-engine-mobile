const DEFAULT_IDS = Object.freeze({
  overlay: "toolAlertOverlay",
  title: "toolAlertTitle",
  body: "toolAlertBody",
  detailsWrap: "toolAlertDetailsWrap",
  details: "toolAlertDetails",
  ok: "toolAlertOkBtn",
  cancel: "toolAlertCancelBtn",
});

export function toolAlertParts(raw, fallbackTitle) {
  try {
    const msg = String(raw == null ? "" : raw)
      .replace(/\r/g, "")
      .trim();
    if (!msg) return { title: fallbackTitle || "Melding", body: "", details: "" };
    const chunks = msg
      .split(/\n\n+/)
      .map((value) => String(value || "").trim())
      .filter(Boolean);
    if (chunks.length >= 2) {
      return {
        title: chunks[0] || fallbackTitle || "Melding",
        body: chunks[1] || "",
        details: chunks.slice(2).join("\n\n"),
      };
    }
    const lines = msg
      .split(/\n+/)
      .map((value) => String(value || "").trim())
      .filter(Boolean);
    if (lines.length >= 3) {
      return {
        title: lines[0] || fallbackTitle || "Melding",
        body: lines[1] || "",
        details: lines.slice(2).join("\n"),
      };
    }
    return { title: fallbackTitle || "Melding", body: msg, details: "" };
  } catch (_error) {
    return {
      title: fallbackTitle || "Melding",
      body: String(raw || ""),
      details: "",
    };
  }
}

export function createDialogComponent({
  documentRef = globalThis.document,
  requestAnimationFrameImpl = globalThis.requestAnimationFrame,
  setTimeoutImpl = globalThis.setTimeout,
  confirmImpl = globalThis.confirm,
  consoleRef = globalThis.console,
  ids = DEFAULT_IDS,
} = {}) {
  function element(name) {
    return documentRef && typeof documentRef.getElementById === "function"
      ? documentRef.getElementById(ids[name])
      : null;
  }

  function scheduleFrame(callback) {
    if (typeof requestAnimationFrameImpl === "function") requestAnimationFrameImpl(callback);
  }

  function closeToolAlert() {
    {
      const overlay = element("overlay");
      if (!overlay) return;
      overlay.classList.remove("isOpen");
      const onClose = overlay.__toolAlertOnClose;
      const onCancel = overlay.__toolAlertOnCancel;
      const closedBy = overlay.__toolAlertClosedBy || "ok";
      overlay.__toolAlertOnClose = null;
      overlay.__toolAlertOnCancel = null;
      overlay.__toolAlertClosedBy = null;
      overlay.__toolAlertConfirmMode = false;
      if (typeof setTimeoutImpl !== "function") return;
      setTimeoutImpl(() => {
        overlay.style.display = "none";

        if (closedBy === "cancel") {
          if (typeof onCancel === "function") onCancel();
        } else if (typeof onClose === "function") {
          onClose();
        }
      }, 120);
    }
  }

  function showToolAlert(raw, fallbackTitle) {
    try {
      const overlay = element("overlay");
      const titleEl = element("title");
      const bodyEl = element("body");
      const detailsWrap = element("detailsWrap");
      const detailsEl = element("details");
      const okBtn = element("ok");
      const cancelBtn = element("cancel");
      if (!overlay || !titleEl || !bodyEl || !detailsWrap || !detailsEl || !okBtn) {
        consoleRef.warn("toolAlertOverlay ontbreekt; fallback naar console");
        consoleRef.warn(raw);
        return false;
      }
      const isObjectRaw = Boolean(raw && typeof raw === "object" && !Array.isArray(raw));
      const onClose = isObjectRaw && typeof raw.onClose === "function" ? raw.onClose : null;
      const onCancel = isObjectRaw && typeof raw.onCancel === "function" ? raw.onCancel : null;
      const parts = isObjectRaw
        ? {
            title: String(raw.title || fallbackTitle || "Melding").trim(),
            body: String(raw.body || raw.message || "").trim(),
            details: String(raw.details || "").trim(),
          }
        : toolAlertParts(raw, fallbackTitle || "Waarschuwing");
      const confirmMode = Boolean(isObjectRaw && raw.confirm === true);
      const okLabel =
        String((isObjectRaw && raw.okText) || (confirmMode ? "Doorgaan" : "Oké")).trim() ||
        (confirmMode ? "Doorgaan" : "Oké");
      const cancelLabel =
        String((isObjectRaw && raw.cancelText) || "Annuleren").trim() || "Annuleren";
      titleEl.textContent = parts.title || fallbackTitle || "Waarschuwing";
      bodyEl.textContent = parts.body || "";
      detailsEl.textContent = parts.details || "";
      detailsWrap.style.display = parts.details ? "block" : "none";
      okBtn.textContent = okLabel;
      if (cancelBtn) {
        cancelBtn.textContent = cancelLabel;
        cancelBtn.style.display = confirmMode ? "" : "none";
      }
      overlay.__toolAlertOnClose = onClose || null;
      overlay.__toolAlertOnCancel = onCancel || null;
      overlay.__toolAlertConfirmMode = confirmMode;
      overlay.style.display = "flex";
      scheduleFrame(() => {
        overlay.classList.add("isOpen");
        try {
          okBtn.focus();
        } catch (_error) {
          ToolAErrors.recover("tool.a.components.dialog.js.1", _error, [
            "NotSupportedError",
            "InvalidStateError",
          ]);
        }
      });
      if (!okBtn.__boundToolAlert) {
        okBtn.__boundToolAlert = true;
        okBtn.addEventListener("click", () => {
          overlay.__toolAlertClosedBy = "ok";
          closeToolAlert();
        });
      }
      if (cancelBtn && !cancelBtn.__boundToolAlert) {
        cancelBtn.__boundToolAlert = true;
        cancelBtn.addEventListener("click", () => {
          overlay.__toolAlertClosedBy = "cancel";
          closeToolAlert();
        });
      }
      if (!overlay.__boundToolAlertBackdrop) {
        overlay.__boundToolAlertBackdrop = true;
        overlay.addEventListener("click", (event) => {
          if (event.target === overlay && !overlay.__toolAlertConfirmMode) {
            overlay.__toolAlertClosedBy = "backdrop";
            closeToolAlert();
          }
        });
      }
      if (!overlay.__boundToolAlertEsc) {
        overlay.__boundToolAlertEsc = true;
        documentRef.addEventListener("keydown", (event) => {
          if (
            event.key === "Escape" &&
            overlay.style.display !== "none" &&
            !overlay.__toolAlertConfirmMode
          ) {
            overlay.__toolAlertClosedBy = "escape";
            closeToolAlert();
          }
        });
      }
      return true;
    } catch (error) {
      consoleRef.warn("showToolAlert failed", error);
      return false;
    }
  }

  function showToolAlertHardFallback(options) {
    try {
      const title = String((options && options.title) || "Melding").trim() || "Melding";
      const body = String((options && options.body) || "").trim();
      const details = String((options && options.details) || "").trim();
      const onClose = options && typeof options.onClose === "function" ? options.onClose : null;
      let overlay = documentRef.getElementById("toolAlertDirectOverlay");
      if (!overlay) {
        overlay = documentRef.createElement("div");
        overlay.id = "toolAlertDirectOverlay";
        overlay.setAttribute("role", "presentation");
        overlay.classList.add("tool-alert-direct-overlay");
        overlay.innerHTML = `
          <div id="toolAlertDirectCard" role="dialog" aria-modal="true" aria-labelledby="toolAlertDirectTitle" class="u-alert-dialog">
            <div class="u-alert-heading-padding">
              <div id="toolAlertDirectTitle" class="u-alert-title">Melding</div>
              <div id="toolAlertDirectBody" class="u-success-message"></div>
            </div>
            <div class="u-alert-body-padding">
              <div id="toolAlertDirectDetailsWrap" class="u-alert-details-hidden">
                <div id="toolAlertDirectDetails" class="u-alert-description"></div>
              </div>
            </div>
            <div class="u-alert-dialog-actions">
              <button id="toolAlertDirectOkBtn" type="button" class="btn btnPrimary u-pointer-active">Oké</button>
            </div>
          </div>`;
        documentRef.body.appendChild(overlay);
      }
      const titleEl = documentRef.getElementById("toolAlertDirectTitle");
      const bodyEl = documentRef.getElementById("toolAlertDirectBody");
      const detailsWrap = documentRef.getElementById("toolAlertDirectDetailsWrap");
      const detailsEl = documentRef.getElementById("toolAlertDirectDetails");
      const okBtn = documentRef.getElementById("toolAlertDirectOkBtn");
      if (!titleEl || !bodyEl || !detailsWrap || !detailsEl || !okBtn) {
        if (typeof onClose === "function") onClose();
        return false;
      }
      overlay.__toolAlertOnClose = onClose || null;
      titleEl.textContent = title;
      bodyEl.textContent = body;
      detailsEl.textContent = details;
      detailsWrap.style.display = details ? "block" : "none";
      overlay.style.display = "flex";
      documentRef.body.appendChild(overlay);
      documentRef.body.style.overflow = "hidden";
      if (!okBtn.__boundDirectToolAlert) {
        okBtn.__boundDirectToolAlert = true;
        okBtn.addEventListener("click", () => {
          overlay.style.display = "none";
          documentRef.body.style.overflow = "";
          const callback = overlay.__toolAlertOnClose;
          overlay.__toolAlertOnClose = null;
          if (typeof callback === "function") callback();
        });
      }
      scheduleFrame(() => {
        try {
          okBtn.focus();
        } catch (_error) {
          ToolAErrors.recover("tool.a.components.dialog.js.2", _error, [
            "NotSupportedError",
            "InvalidStateError",
          ]);
        }
      });
      return true;
    } catch (_error) {
      return false;
    }
  }

  function showToolAlertHardFallbackAsync(options) {
    return new Promise((resolve) => {
      try {
        const merged = Object.assign(
          {},
          options && typeof options === "object" ? options : { body: String(options || "") },
        );
        const previousClose = typeof merged.onClose === "function" ? merged.onClose : null;
        merged.onClose = () => {
          if (typeof previousClose === "function") previousClose();
          resolve(true);
        };
        const shown = showToolAlertHardFallback(merged);
        if (!shown) {
          showToolAlert(merged, merged.title || "Melding");
          resolve(true);
        }
      } catch (_error) {
        showToolAlert(options, (options && options.title) || "Melding");
        resolve(true);
      }
    });
  }

  function showToolConfirm(raw, fallbackTitle) {
    return new Promise((resolve) => {
      let settled = false;
      const settle = (value) => {
        if (settled) return;
        settled = true;
        resolve(value === true);
      };
      const fallback = () => {
        try {
          return (
            typeof confirmImpl === "function" &&
            confirmImpl(
              typeof raw === "string" ? raw : String((raw && raw.body) || "Weet je het zeker?"),
            ) === true
          );
        } catch (_error) {
          return false;
        }
      };
      try {
        const normalized =
          raw && typeof raw === "object" && !Array.isArray(raw)
            ? Object.assign({}, raw)
            : { body: String(raw || "") };
        normalized.confirm = true;
        normalized.title =
          String(normalized.title || fallbackTitle || "Bevestiging").trim() || "Bevestiging";
        normalized.onClose = () => settle(true);
        normalized.onCancel = () => settle(false);
        const shown = showToolAlert(normalized, fallbackTitle || "Bevestiging");
        if (shown !== true) settle(fallback());
      } catch (_error) {
        settle(fallback());
      }
    });
  }

  return Object.freeze({
    toolAlertParts,
    closeToolAlert,
    showToolAlert,
    showToolConfirm,
    showToolAlertHardFallback,
    showToolAlertHardFallbackAsync,
  });
}
