import { REVISION } from "../version.js";

export const PROGRESS_OVERLAY_MARKUP = `
        <div class="metodProgressOverlayCard" role="dialog" aria-modal="true" aria-labelledby="metodProgressOverlayTitle">
          <img class="metodProgressOverlayLogo" src="assets/adzaagt_logo.png" alt="Adzaagt logo" />
          <h2 id="metodProgressOverlayTitle" class="metodProgressOverlayTitle">Optimaliseren</h2>
          <div id="metodProgressOverlayRing" class="metodProgressOverlayRing">
            <div class="metodProgressOverlayRingInner"><span id="metodProgressOverlayPct" class="metodProgressOverlayPct">0%</span></div>
          </div>
          <div class="metodProgressOverlayBar"><div id="metodProgressOverlayFill" class="metodProgressOverlayBarFill"></div></div>
          <div id="metodProgressOverlayLabel" class="metodProgressOverlayLabel">Bezig met optimaliseren…</div>
          <div class="metodProgressOverlayHint"><span class="metodProgressOverlayHintIcon">⌛</span><span>Dit kan even duren, sluit deze pagina niet af.</span></div>
        </div>`;

export const PROGRESS_OVERLAY_BUILD = REVISION;

export function createProgressOverlayComponent({
  documentRef = globalThis.document,
  rootRef = globalThis,
} = {}) {
  let metodProgressBadgeEl = null;
  let metodProgressOverlayEl = null;
  let optimizerBusy = false;
  let lastDisplayedProgressPct = null;
  let authoritativeProgressPct = null;
  let progressAnimationEpoch = 0;
  let progressAnimationFrame = null;
  let progressAnimationTimer = null;
  let lastProgressLabel = "Bezig met optimaliseren…";
  const progressSettleWaiters = new Set();

  function scheduleTimeout(callback, delay) {
    const scheduler =
      typeof rootRef?.setTimeout === "function"
        ? rootRef.setTimeout.bind(rootRef)
        : typeof globalThis.setTimeout === "function"
          ? globalThis.setTimeout.bind(globalThis)
          : null;
    return scheduler ? scheduler(callback, delay) : null;
  }

  function clearScheduledTimeout(handle) {
    if (handle == null) return;
    const clearer =
      typeof rootRef?.clearTimeout === "function"
        ? rootRef.clearTimeout.bind(rootRef)
        : typeof globalThis.clearTimeout === "function"
          ? globalThis.clearTimeout.bind(globalThis)
          : null;
    clearer?.(handle);
  }

  function cancelProgressAnimation() {
    progressAnimationEpoch += 1;
    if (progressAnimationFrame != null && typeof rootRef?.cancelAnimationFrame === "function") {
      rootRef.cancelAnimationFrame(progressAnimationFrame);
    }
    clearScheduledTimeout(progressAnimationTimer);
    progressAnimationFrame = null;
    progressAnimationTimer = null;
  }

  function resolveProgressSettleWaiters() {
    for (const waiter of Array.from(progressSettleWaiters)) {
      if (
        !optimizerBusy ||
        (lastDisplayedProgressPct != null && lastDisplayedProgressPct >= waiter.target)
      ) {
        progressSettleWaiters.delete(waiter);
        clearScheduledTimeout(waiter.timeout);
        waiter.resolve(Boolean(optimizerBusy && lastDisplayedProgressPct >= waiter.target));
      }
    }
  }

  function parseProgressPct(value) {
    if (value == null || typeof value === "boolean") return null;
    if (typeof value === "string" && !value.trim()) return null;
    const numeric = Number(value);
    if (!Number.isFinite(numeric)) return null;
    return Math.max(0, Math.min(100, Math.round(numeric)));
  }

  function ensureMetodProgressBadge() {
    try {
      if (
        metodProgressBadgeEl &&
        documentRef.body &&
        documentRef.body.contains(metodProgressBadgeEl)
      )
        return metodProgressBadgeEl;
      const el = documentRef.createElement("div");
      el.id = "metodProgressBadge";
      el.setAttribute("aria-live", "polite");
      el.style.position = "fixed";
      el.style.top = "16px";
      el.style.right = "16px";
      el.style.zIndex = "10050";
      el.style.padding = "10px 14px";
      el.style.borderRadius = "999px";
      el.style.background = "rgba(255,255,255,0.96)";
      el.style.border = "1px solid rgba(27,173,118,0.28)";
      el.style.boxShadow = "0 10px 30px rgba(0,0,0,0.14)";
      el.style.color = "#1d2b25";
      el.style.fontSize = "13px";
      el.style.fontWeight = "700";
      el.style.display = "none";
      el.style.maxWidth = "min(360px, calc(100vw - 24px))";
      el.style.lineHeight = "1.25";
      documentRef.body.appendChild(el);
      metodProgressBadgeEl = el;
      return el;
    } catch (_error) {
      return null;
    }
  }

  function ensureMetodProgressOverlay() {
    try {
      if (
        metodProgressOverlayEl &&
        documentRef.body &&
        documentRef.body.contains(metodProgressOverlayEl)
      )
        return metodProgressOverlayEl;
      const el = documentRef.createElement("div");
      el.id = "metodProgressOverlay";
      el.setAttribute("aria-hidden", "true");
      el.innerHTML = PROGRESS_OVERLAY_MARKUP;
      documentRef.body.appendChild(el);
      metodProgressOverlayEl = el;
      return el;
    } catch (_error) {
      return null;
    }
  }

  function hideMetodProgressOverlay() {
    optimizerBusy = false;
    cancelProgressAnimation();
    lastDisplayedProgressPct = null;
    authoritativeProgressPct = null;
    resolveProgressSettleWaiters();
    let changed = false;
    {
      const overlay = ensureMetodProgressOverlay();
      const fallback = ensureMetodProgressBadge();
      if (overlay) {
        overlay.setAttribute("aria-hidden", "true");
        overlay.style.display = "none";
        changed = true;
      }
      if (fallback) {
        fallback.style.display = "none";
        fallback.textContent = "";
        changed = true;
      }
      if (documentRef.body && documentRef.body.dataset.metodProgressOverlayOpen === "1") {
        documentRef.body.style.overflow =
          documentRef.body.dataset.metodProgressOverlayPrevOverflow || "";
        delete documentRef.body.dataset.metodProgressOverlayPrevOverflow;
        delete documentRef.body.dataset.metodProgressOverlayOpen;
      }
    }
    return changed;
  }

  function finishOptimizerProgress() {
    // This is the optimizer's single terminal transition. It deliberately owns
    // no price, panel or checkout rendering and is therefore safe to call from
    // success, failure, cancellation and finally paths. Repeated calls are OK.
    try {
      hideMetodProgressOverlay();
    } catch (_error) {
      optimizerBusy = false;
    }
    return !optimizerBusy;
  }

  function initMetodProgressOverlay() {
    try {
      const overlay = ensureMetodProgressOverlay();
      const fallback = ensureMetodProgressBadge();
      if (overlay) {
        overlay.setAttribute("aria-hidden", "true");
        overlay.style.display = "none";
      }
      if (fallback) {
        fallback.style.display = "none";
        fallback.textContent = "";
      }
      optimizerBusy = false;
      return Boolean(overlay || fallback);
    } catch (_error) {
      return false;
    }
  }

  function updateMetodProgressBadge(opts = {}) {
    try {
      const overlay = ensureMetodProgressOverlay();
      const fallback = ensureMetodProgressBadge();
      const hasBusyDirective = Boolean(opts && Object.prototype.hasOwnProperty.call(opts, "busy"));
      if (hasBusyDirective && opts.busy === false) {
        return finishOptimizerProgress();
      }
      if (hasBusyDirective && opts.busy === true) optimizerBusy = true;
      // A generic price/panel render is not allowed to close an optimizer run.
      // Only the owner that started the run may send the explicit busy:false
      // terminal transition.
      if (!optimizerBusy) return true;
      if (!hasBusyDirective) return true;
      const requestedPct = parseProgressPct(opts.progressPct);
      const label = String(opts.progressLabel || "").trim() || lastProgressLabel;
      lastProgressLabel = label;

      function paintProgress(pct) {
        const visiblePct = pct == null ? null : Math.max(0, Math.min(100, Math.round(pct)));
        if (visiblePct != null) lastDisplayedProgressPct = visiblePct;
        const pctValue = visiblePct != null ? visiblePct : 6;
        if (overlay) {
          const pctEl = overlay.querySelector("#metodProgressOverlayPct");
          const fillEl = overlay.querySelector("#metodProgressOverlayFill");
          const labelEl = overlay.querySelector("#metodProgressOverlayLabel");
          const ringEl = overlay.querySelector("#metodProgressOverlayRing");
          if (pctEl) pctEl.textContent = visiblePct != null ? `${visiblePct}%` : "…";
          if (fillEl) fillEl.style.width = `${Math.max(6, pctValue)}%`;
          if (labelEl) labelEl.textContent = lastProgressLabel;
          if (ringEl) {
            const deg = Math.max(8, Math.min(360, pctValue * 3.6));
            ringEl.style.background = `conic-gradient(rgba(102,198,152,.95) 0deg ${deg}deg, rgba(218,236,226,1) ${deg}deg 360deg)`;
            ringEl.setAttribute("role", "progressbar");
            ringEl.setAttribute("aria-valuemin", "0");
            ringEl.setAttribute("aria-valuemax", "100");
            ringEl.setAttribute("aria-valuenow", visiblePct != null ? String(visiblePct) : "0");
            ringEl.setAttribute(
              "aria-valuetext",
              visiblePct != null ? `${visiblePct}%` : "Voortgang wordt bepaald",
            );
          }
          overlay.style.display = "flex";
          overlay.setAttribute("aria-hidden", "false");
          if (documentRef.body && documentRef.body.dataset.metodProgressOverlayOpen !== "1") {
            documentRef.body.dataset.metodProgressOverlayOpen = "1";
            documentRef.body.dataset.metodProgressOverlayPrevOverflow =
              documentRef.body.style.overflow || "";
            documentRef.body.style.overflow = "hidden";
          }
          if (fallback) {
            fallback.style.display = "none";
            fallback.textContent = "";
          }
        } else if (fallback) {
          fallback.textContent =
            visiblePct != null
              ? `Optimaliseren ${visiblePct}%${lastProgressLabel ? ` • ${lastProgressLabel}` : ""}`
              : lastProgressLabel;
          fallback.style.display = "block";
        }
        resolveProgressSettleWaiters();
      }

      function animateToAuthoritativeTarget() {
        cancelProgressAnimation();
        const epoch = progressAnimationEpoch;
        const startPct =
          lastDisplayedProgressPct == null ? authoritativeProgressPct : lastDisplayedProgressPct;
        const targetPct = authoritativeProgressPct;
        if (startPct == null || targetPct == null || targetPct <= startPct) {
          paintProgress(startPct);
          return;
        }
        const distance = targetPct - startPct;
        const totalFrames = Math.max(2, Math.min(24, Math.ceil(distance / 4)));
        let frame = 0;
        const requestFrame =
          typeof rootRef?.requestAnimationFrame === "function"
            ? rootRef.requestAnimationFrame.bind(rootRef)
            : null;

        const scheduleFrame = () => {
          let invoked = false;
          const run = () => {
            if (invoked) return;
            invoked = true;
            clearScheduledTimeout(progressAnimationTimer);
            progressAnimationTimer = null;
            progressAnimationFrame = null;
            if (!optimizerBusy || epoch !== progressAnimationEpoch) return;
            frame += 1;
            const ratio = Math.min(1, frame / totalFrames);
            const nextPct = Math.min(
              targetPct,
              Math.max(startPct, Math.round(startPct + distance * ratio)),
            );
            paintProgress(nextPct);
            if (nextPct < targetPct) scheduleFrame();
          };
          progressAnimationTimer = scheduleTimeout(run, 20);
          if (requestFrame) {
            progressAnimationFrame = requestFrame(run);
          } else if (progressAnimationTimer == null) {
            run();
          }
        };
        scheduleFrame();
      }

      if (requestedPct != null) {
        authoritativeProgressPct = Math.max(authoritativeProgressPct ?? 0, requestedPct);
        if (lastDisplayedProgressPct == null) {
          paintProgress(authoritativeProgressPct);
        } else if (authoritativeProgressPct > lastDisplayedProgressPct) {
          animateToAuthoritativeTarget();
        } else {
          paintProgress(lastDisplayedProgressPct);
        }
      } else {
        // An unknown update may change the human label, but can never reset a
        // previously verified percentage, ring or fill.
        paintProgress(lastDisplayedProgressPct);
      }
      return Boolean(overlay || fallback);
    } catch (_error) {
      // Preserve the legacy no-throw UI boundary.
      return false;
    }
  }

  function hasCompleteOverlayDom(overlay) {
    try {
      if (!overlay || !documentRef.body || !documentRef.body.contains(overlay)) return false;
      return [
        ".metodProgressOverlayCard",
        ".metodProgressOverlayLogo",
        "#metodProgressOverlayRing",
        "#metodProgressOverlayPct",
        "#metodProgressOverlayFill",
        "#metodProgressOverlayLabel",
      ].every((selector) => Boolean(overlay.querySelector(selector)));
    } catch (_error) {
      return false;
    }
  }

  function isMetodProgressOverlayVisible() {
    try {
      const overlay =
        metodProgressOverlayEl || documentRef.getElementById?.("metodProgressOverlay");
      if (!overlay) return false;
      const display = String(overlay.style?.display || "")
        .trim()
        .toLowerCase();
      return Boolean(
        display === "flex" &&
          overlay.getAttribute?.("aria-hidden") === "false" &&
          hasCompleteOverlayDom(overlay),
      );
    } catch (_error) {
      return false;
    }
  }

  function isMetodProgressVisible() {
    return isMetodProgressOverlayVisible() || isMetodProgressFallbackVisible();
  }

  function isOptimizerBusy() {
    return optimizerBusy;
  }

  function startOptimizerProgress(options = {}) {
    cancelProgressAnimation();
    lastDisplayedProgressPct = null;
    authoritativeProgressPct = null;
    lastProgressLabel = "Bezig met optimaliseren…";
    const shown = updateMetodProgressBadge({
      ...(options && typeof options === "object" ? options : {}),
      busy: true,
    });
    // The optimizer route promises the complete branded dialog, not merely the
    // small accessibility fallback used by unrelated legacy progress callers.
    return Boolean(shown && optimizerBusy && isMetodProgressOverlayVisible());
  }

  async function waitForMetodProgressPaint() {
    // WebKit does not expose a compositor-paint acknowledgement. The only hard
    // gate is the synchronous DOM activation contract above. Two frames are a
    // best-effort yield, bounded by a short timer so backgrounding, Low Power
    // Mode or an unbound Safari requestAnimationFrame can never stall a job.
    if (!optimizerBusy || !isMetodProgressOverlayVisible()) return false;
    const requestFrame =
      typeof rootRef?.requestAnimationFrame === "function"
        ? rootRef.requestAnimationFrame.bind(rootRef)
        : null;
    const scheduleTimeout =
      typeof rootRef?.setTimeout === "function"
        ? rootRef.setTimeout.bind(rootRef)
        : typeof globalThis.setTimeout === "function"
          ? globalThis.setTimeout.bind(globalThis)
          : null;
    await new Promise((resolve) => {
      let settled = false;
      const finish = () => {
        if (settled) return;
        settled = true;
        resolve();
      };
      if (scheduleTimeout) scheduleTimeout(finish, 120);
      if (!requestFrame) {
        finish();
        return;
      }
      try {
        requestFrame(() => {
          try {
            requestFrame(finish);
          } catch (_error) {
            finish();
          }
        });
      } catch (_error) {
        finish();
      }
    });
    return Boolean(optimizerBusy && isMetodProgressOverlayVisible());
  }

  async function settleOptimizerProgress(options = {}) {
    if (!optimizerBusy) return false;
    const target = parseProgressPct(options.progressPct ?? 100) ?? 100;
    updateMetodProgressBadge({
      busy: true,
      progressPct: target,
      progressLabel: String(options.progressLabel || "").trim() || "Optimalisatie afgerond",
    });
    let reachedTarget = lastDisplayedProgressPct != null && lastDisplayedProgressPct >= target;
    if (!reachedTarget) {
      reachedTarget = await new Promise((resolve) => {
        const waiter = { target, resolve, timeout: null };
        waiter.timeout = scheduleTimeout(() => {
          progressSettleWaiters.delete(waiter);
          // A throttled/backgrounded WebKit frame may never arrive. The server has
          // already confirmed this target, so paint it once before terminal close.
          if (optimizerBusy && authoritativeProgressPct != null) {
            lastDisplayedProgressPct = Math.max(
              lastDisplayedProgressPct ?? 0,
              authoritativeProgressPct,
            );
            updateMetodProgressBadge({
              busy: true,
              progressPct: authoritativeProgressPct,
              progressLabel: lastProgressLabel,
            });
          }
          resolve(
            Boolean(
              optimizerBusy &&
                lastDisplayedProgressPct != null &&
                lastDisplayedProgressPct >= target,
            ),
          );
        }, 700);
        progressSettleWaiters.add(waiter);
        resolveProgressSettleWaiters();
      });
    }
    if (!reachedTarget || !optimizerBusy) return false;
    // A DOM assignment inside the final animation callback is not a paint
    // acknowledgement: an awaiting caller resumes as a microtask and could hide
    // the overlay before WebKit composites that frame. Keep the terminal target
    // alive through the existing bounded two-frame paint barrier.
    await waitForMetodProgressPaint();
    return Boolean(
      optimizerBusy &&
        lastDisplayedProgressPct != null &&
        lastDisplayedProgressPct >= target &&
        isMetodProgressOverlayVisible(),
    );
  }

  function isMetodProgressFallbackVisible() {
    try {
      const badge = metodProgressBadgeEl || documentRef.getElementById("metodProgressBadge");
      if (!badge) return false;
      const display = String(badge.style.display || "")
        .trim()
        .toLowerCase();
      const text = String(badge.textContent || "").trim();
      return Boolean(display && display !== "none" && text);
    } catch (_error) {
      return false;
    }
  }

  return Object.freeze({
    BUILD: PROGRESS_OVERLAY_BUILD,
    initMetodProgressOverlay,
    hideMetodProgressOverlay,
    finishOptimizerProgress,
    updateMetodProgressBadge,
    startOptimizerProgress,
    isOptimizerBusy,
    isMetodProgressVisible,
    isMetodProgressFallbackVisible,
    waitForMetodProgressPaint,
    settleOptimizerProgress,
  });
}
