function createLifecycleEvent(rootRef, type, detail) {
  const CustomEventConstructor = rootRef?.CustomEvent;
  if (typeof CustomEventConstructor === "function") {
    return new CustomEventConstructor(type, { detail });
  }
  const EventConstructor = rootRef?.Event;
  if (typeof EventConstructor !== "function") return null;
  try {
    const event = new EventConstructor(type);
    Object.defineProperty(event, "detail", { value: detail });
    return event;
  } catch (_fallbackError) {
    return null;
  }
}

export function createFoundationLifecycleComponent(options = {}) {
  const rootRef = options.root || globalThis;
  const documentRef = options.documentRef || rootRef?.document || null;
  let foundationRequestHandler = null;
  let pageShowHandler = null;

  function dispatch(type, detail) {
    if (!documentRef || typeof documentRef.dispatchEvent !== "function") return false;
    const event = createLifecycleEvent(rootRef, type, detail);
    if (!event) return false;
    documentRef.dispatchEvent(event);
    return true;
  }

  function publishJobStartRecovery(snapshot) {
    if (!snapshot || snapshot.state === "none") return false;
    const detail = Object.freeze({
      state: String(snapshot.state || "uncertain"),
      status: Number(snapshot.status || 0),
      expired: snapshot.expired === true,
      running: snapshot.running === true,
      message: String(snapshot.message || ""),
    });
    return dispatch("tool-a:job-start-recovery", detail);
  }

  function bindFoundationAdapter(adapter) {
    if (!adapter || typeof adapter !== "object") return false;
    if (!documentRef || typeof documentRef.addEventListener !== "function") return false;
    if (foundationRequestHandler) return true;
    foundationRequestHandler = () => dispatch("tool-a:foundation-ready", adapter);
    pageShowHandler = foundationRequestHandler;
    documentRef.addEventListener("tool-a:foundation-request", foundationRequestHandler);
    if (typeof rootRef?.addEventListener === "function") {
      rootRef.addEventListener("pageshow", pageShowHandler);
    }
    foundationRequestHandler();
    return true;
  }

  function unbind() {
    if (foundationRequestHandler && typeof documentRef?.removeEventListener === "function") {
      documentRef.removeEventListener("tool-a:foundation-request", foundationRequestHandler);
    }
    if (pageShowHandler && typeof rootRef?.removeEventListener === "function") {
      rootRef.removeEventListener("pageshow", pageShowHandler);
    }
    foundationRequestHandler = null;
    pageShowHandler = null;
  }

  return Object.freeze({
    bindFoundationAdapter,
    publishJobStartRecovery,
    unbind,
  });
}
