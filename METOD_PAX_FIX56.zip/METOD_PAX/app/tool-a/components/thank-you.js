import { REVISION } from "../version.js";
export const THANK_YOU_COMPONENT_BUILD = REVISION;

function clean(value) {
  return String(value == null ? "" : value).trim();
}

function escapeHtml(value) {
  return String(value == null ? "" : value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function firstFiniteNumber(values) {
  for (const value of values) {
    if (value == null || value === "") continue;
    const number = Number(value);
    if (Number.isFinite(number)) return number;
  }
  return null;
}

export function createThankYouComponent({
  documentRef = globalThis.document,
  rootRef = globalThis,
  getState = () => rootRef.state,
  hideProgress = null,
  resetConfiguration = null,
} = {}) {
  let overlay = null;
  let resetBusy = false;
  let readyAnnounced = false;
  let backgroundRestore = [];
  let previousBodyOverflow = null;

  function currentState() {
    try {
      return getState?.() || rootRef.state || {};
    } catch (_error) {
      return rootRef.state || {};
    }
  }

  function customerFrom(data) {
    const state = currentState();
    return data?.customer || state?.checkout?.customer || {};
  }

  function totalFrom(data) {
    const summary = data?.pricingSummary || {};
    return firstFiniteNumber([
      data?.priceInclVat,
      summary?.totalInclVat,
      summary?.total_incl_vat,
      summary?.grandTotalInclVat,
      summary?.grand_total_incl_vat,
    ]);
  }

  function formatTotal(data) {
    const total = totalFrom(data);
    if (total == null) return "Op aanvraag";
    try {
      return new Intl.NumberFormat("nl-NL", {
        style: "currency",
        currency: "EUR",
      }).format(total);
    } catch (_error) {
      return `€ ${total.toFixed(2)}`;
    }
  }

  function restoreBackground() {
    const records = backgroundRestore;
    backgroundRestore = [];
    for (const record of records) {
      const node = record?.node;
      if (!node) continue;

      if (record.hadInert) node.setAttribute?.("inert", record.inertValue);
      else node.removeAttribute?.("inert");

      if (record.hadAriaHidden) node.setAttribute?.("aria-hidden", record.ariaHiddenValue);
      else node.removeAttribute?.("aria-hidden");
    }
    if (previousBodyOverflow !== null) {
      if (documentRef?.body?.style) documentRef.body.style.overflow = previousBodyOverflow;

      previousBodyOverflow = null;
    }
  }

  function lockBackground(active) {
    restoreBackground();
    const body = documentRef?.body;
    if (!body) return;
    try {
      previousBodyOverflow = String(body.style?.overflow || "");
    } catch (_error) {
      previousBodyOverflow = "";
    }
    if (body.style) body.style.overflow = "hidden";
    let siblings = [];
    try {
      siblings = Array.from(body.children || []);
    } catch (_error) {
      siblings = [];
    }
    for (const node of siblings) {
      if (!node || node === active) continue;
      let hadInert = false;
      let inertValue = "";
      let hadAriaHidden = false;
      let ariaHiddenValue = "";

      hadInert = node.hasAttribute?.("inert") === true;
      inertValue = hadInert ? String(node.getAttribute?.("inert") ?? "") : "";

      hadAriaHidden = node.hasAttribute?.("aria-hidden") === true;
      ariaHiddenValue = hadAriaHidden ? String(node.getAttribute?.("aria-hidden") ?? "") : "";

      backgroundRestore.push({
        node,
        hadInert,
        inertValue,
        hadAriaHidden,
        ariaHiddenValue,
      });
      node.setAttribute?.("inert", "");
      node.setAttribute?.("aria-hidden", "true");
    }
  }

  function close() {
    const active = overlay;
    overlay = null;
    resetBusy = false;
    try {
      if (!active) return false;
      active.removeEventListener?.("click", handleEvent);
      active.remove?.();
      return true;
    } finally {
      restoreBackground();
    }
  }

  function disableActions() {
    {
      const closeButton = overlay?.querySelector?.("#submitThanksClose");
      const newButton = overlay?.querySelector?.("#submitThanksNew");
      if (closeButton) closeButton.disabled = true;
      if (newButton) newButton.disabled = true;
    }
  }

  async function resetAndReload() {
    if (resetBusy) return false;
    resetBusy = true;
    disableActions();
    try {
      const reset =
        typeof resetConfiguration === "function"
          ? resetConfiguration
          : rootRef.__metodResetConfigurationHard;
      if (typeof reset === "function") {
        await reset();
        return true;
      }
    } catch (_error) {
      rootRef.console?.warn?.("[Tool A]", "thank-you.reset", "reload-required");
    }
    close();
    rootRef.location?.reload?.();
    return true;
  }

  function handleEvent(event) {
    const target = event?.target;
    if (!overlay || !target) return false;
    if (target === overlay) {
      event.preventDefault?.();
      event.stopImmediatePropagation?.();
      // A committed request must always retain an explicit recovery action.
      // Backdrop taps are common on iPhone and may never reveal a locked wizard
      // with both the price and thank-you dialogs gone.
      return true;
    }
    const action = target.closest?.("#submitThanksClose, #submitThanksNew");
    if (!action) return false;
    event.preventDefault?.();
    event.stopImmediatePropagation?.();
    const result = resetAndReload();
    if (result && typeof result.catch === "function") result;
    return true;
  }

  function bindOverlayClick(active) {
    if (active !== overlay) return;
    active.addEventListener?.("click", handleEvent);
  }

  function show(data = {}) {
    try {
      if (typeof hideProgress === "function") hideProgress();

      close();
      documentRef?.getElementById?.("submitThanksOverlay")?.remove?.();
      const active = documentRef?.createElement?.("div");
      if (!active) throw new Error("Thank-you DOM unavailable");
      overlay = active;
      resetBusy = false;
      active.id = "submitThanksOverlay";
      active.className = "submitThanksOverlay";

      const customer = customerFrom(data);
      const customerName =
        [
          customer?.name,
          customer?.fullName,
          [customer?.firstName, customer?.lastName].filter(Boolean).join(" "),
        ].find((value) => clean(value)) || "je aanvraag";
      const customerEmail = clean(customer?.email || customer?.mail);
      const requestId = clean(data?.requestId) || "Wordt verwerkt";
      const total = formatTotal(data);
      const safeCustomerName = escapeHtml(customerName);
      const safeCustomerEmail = escapeHtml(customerEmail);
      const safeRequestId = escapeHtml(requestId);
      const safeTotal = escapeHtml(total);
      const emailText = customerEmail
        ? ` <a href="mailto:${encodeURIComponent(customerEmail)}" class="u-link-emphasis">${safeCustomerEmail}</a>`
        : " het opgegeven e-mailadres";

      active.innerHTML = `
        <div class="submitThanksCard u-success-dialog" role="dialog" aria-modal="true" aria-labelledby="submitThanksTitle" tabindex="-1">
          <img src="assets/adzaagt_logo.png" alt="Adzaagt logo" class="u-success-logo" />
          <div class="submitThanksEyebrow u-success-status">✓ Aanvraag ontvangen</div>
          <h2 id="submitThanksTitle" class="submitThanksTitle u-success-title">Bedankt voor je aanvraag${customerName !== "je aanvraag" ? `, ${safeCustomerName}` : ""}.</h2>
          <p class="submitThanksText u-success-description">Binnen <strong>2 werkdagen</strong> sturen wij de factuur naar${emailText}.<br>Je ontvangt per e-mail ook de verdere informatie over je aanvraag.</p>
          <div class="submitThanksAgreement u-success-note">Je bent akkoord gegaan met de totaalprijs van <strong>${safeTotal}</strong> incl. btw.</div>
          <div class="submitThanksInfo u-success-details-grid">
            <div class="submitThanksInfoCard u-success-details">
              <div class="submitThanksInfoLabel u-success-label">Totaalprijs incl. btw</div>
              <div class="submitThanksInfoValue submitThanksTotal u-success-total">${safeTotal}</div>
            </div>
            <div class="submitThanksInfoCard u-success-details">
              <div class="submitThanksInfoLabel u-success-label">Referentie</div>
              <div class="submitThanksInfoValue u-success-reference">${safeRequestId}</div>
            </div>
          </div>
          <div class="submitThanksActions u-success-actions">
            <button type="button" class="submitThanksBtn submitThanksBtnSecondary u-success-primary-action" id="submitThanksClose">Sluiten</button>
            <button type="button" class="submitThanksBtn submitThanksBtnPrimary u-success-secondary-action" id="submitThanksNew">Nieuwe configuratie</button>
          </div>
        </div>`;
      documentRef?.body?.appendChild?.(active);
      lockBackground(active);
      bindOverlayClick(active);
      const dialog = active.querySelector?.(".submitThanksCard");
      if (!dialog) throw new Error("Thank-you dialog unavailable");
      try {
        dialog.focus({ preventScroll: true });
      } catch (_error) {
        try {
          dialog.focus();
        } catch (__error) {
          ToolAErrors.recover("tool.a.components.thank.you.js.1", __error, [
            "NotSupportedError",
            "InvalidStateError",
          ]);
        }
      }
      return true;
    } catch (_error) {
      close();
      rootRef.alert?.(
        "Bedankt voor je aanvraag. Binnen 2 werkdagen sturen wij de factuur naar het opgegeven e-mailadres.",
      );
      return false;
    }
  }

  function isOpen() {
    return Boolean(overlay);
  }

  function announceReady() {
    if (readyAnnounced) return false;
    readyAnnounced = true;
    if (documentRef?.dispatchEvent && typeof rootRef.Event === "function") {
      documentRef.dispatchEvent(new rootRef.Event("tool-a-thank-you-owner-ready"));
    }
    return true;
  }

  return Object.freeze({
    BUILD: THANK_YOU_COMPONENT_BUILD,
    show,
    close,
    handleEvent,
    isOpen,
    announceReady,
  });
}
