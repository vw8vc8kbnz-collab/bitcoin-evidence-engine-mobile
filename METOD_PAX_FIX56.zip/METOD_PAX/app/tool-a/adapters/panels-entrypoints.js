import { REVISION } from "../version.js";
import { ToolACoreSelectors } from "../domain/core-selectors.js";

export let ToolAPanelsEntry;

export function mount(actions) {
  (function () {
    const w = window;

    function call(fn, args, fallback) {
      try {
        if (typeof fn === "function") return fn.apply(null, args || []);
      } catch (err) {
        console.warn("ToolAPanelsEntry call failed", err);
      }
      return fallback;
    }

    function totalDockItems() {
      try {
        if (ToolACoreSelectors && typeof ToolACoreSelectors.getCartSnapshot === "function") {
          const snap = ToolACoreSelectors.getCartSnapshot(w.state);
          return Number(snap?.standardCount || 0) + Number(snap?.extraQty || 0);
        }
        const cart = Array.isArray(w.state?.cart) ? w.state.cart.length : 0;
        const extras = Array.isArray(w.state?.extraPanels)
          ? w.state.extraPanels.reduce((a, p) => a + Math.max(1, Number(p?.qty) || 1), 0)
          : 0;
        return cart + extras;
      } catch (_) {
        return 0;
      }
    }

    const api = {
      version: REVISION,
      get raw() {
        return actions;
      },
      bootstrapSelection(force) {
        const raw = actions;
        const out = call(raw.bootstrap, [!!force], false);
        w.__forcePanelBootstrap = false;
        return out;
      },
      resetEntry() {
        const raw = actions;
        return call(raw.resetFields, [], null);
      },
      removeMaterial(key) {
        const raw = actions;
        return call(raw.removeMaterial, [key], null);
      },
      removeMaterialConfirmed(key) {
        const raw = actions;
        return call(raw.removeMaterialConfirmed, [key], null);
      },
      activateMaterial(key) {
        const raw = actions;
        return call(raw.setActiveMaterial, [key], null);
      },
      syncAppleSelects() {
        if (
          typeof w.typeSel !== "undefined" &&
          w.typeSel &&
          typeof w.typeSel.__appleSync === "function"
        )
          w.typeSel.__appleSync();
        if (
          typeof w.sizeSel !== "undefined" &&
          w.sizeSel &&
          typeof w.sizeSel.__appleSync === "function"
        )
          w.sizeSel.__appleSync();
      },
      syncDockOnPanelsEntry(prevStep) {
        {
          if (w.panelDock) {
            w.panelDock.style.display = "flex";
          }
          if (w.panelDockLauncher) {
            w.panelDockLauncher.style.display = "inline-flex";
          }
          const dockTotal = totalDockItems();
          const shouldRestoreDock =
            dockTotal > 0 &&
            (prevStep === "grain" || prevStep === "overview") &&
            !!w.__panelDockWasOpenBeforeRoute;
          const raw = actions;
          if (typeof raw.setDockOpen === "function") {
            if (shouldRestoreDock) raw.setDockOpen(true);
            else if (!dockTotal) raw.setDockOpen(false);
          }
        }
      },
      onEnterPanelsStep(prevStep) {
        if (typeof w.ensureCustomLabelHook === "function") w.ensureCustomLabelHook();
        if (typeof w.syncDefaultPanelTypeSelection === "function")
          w.syncDefaultPanelTypeSelection();
        if (typeof w.enableControlsIfReady === "function") w.enableControlsIfReady();
        {
          const hasMat = !!(w.state && w.state.activeMaterialKey);
          const isPrefillingEdit = !!w.__prefillingPanelEdit;
          const hasEditTarget = !!(
            w.__panelEditTargetId ||
            (typeof w.resolvePanelEditTargetId === "function" && w.resolvePanelEditTargetId())
          );
          const skipBootstrapForEdit = !!w.__skipPanelBootstrapForEdit;
          if (hasMat && !isPrefillingEdit && !hasEditTarget && !skipBootstrapForEdit) {
            const forceBootstrap = !!w.__forcePanelBootstrap;
            api.bootstrapSelection(forceBootstrap);
          }
        }
        w.__skipPanelBootstrapForEdit = false;
        api.syncAppleSelects();
        api.syncDockOnPanelsEntry(prevStep);
      },
    };

    ToolAPanelsEntry = Object.freeze(api);
  })();
}
