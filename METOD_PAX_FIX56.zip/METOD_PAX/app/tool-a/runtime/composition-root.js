import { createCalculation } from "./modules/calculation.js";
import { createCalculationView } from "./modules/calculation-view.js";
import { createPriceBar } from "./modules/price-bar.js";
import { createProgressView } from "./modules/progress-view.js";
import { createJobEstimates } from "./modules/job-estimates.js";
import { createDxfExport } from "./modules/dxf-export.js";
import { createTemplateExport } from "./modules/template-export.js";
import { createJobPayload } from "./modules/job-payload.js";
import { createGrainAssignments } from "./modules/grain-assignments.js";
import { createCheckoutOverlays } from "./modules/checkout-overlays.js";
import { createCustomerForm } from "./modules/customer-form.js";
import { createOverlayControls } from "./modules/overlay-controls.js";
import { createCustomerSnapshot } from "./modules/customer-snapshot.js";
import { createCheckoutFlow } from "./modules/checkout-flow.js";
import { createJobRecovery } from "./modules/job-recovery.js";
import { createJobClient } from "./modules/job-client.js";
import { createAuthoritativePrice } from "./modules/authoritative-price.js";
import { createWizardNavigation } from "./modules/wizard-navigation.js";
import { createTemplateCatalog } from "./modules/template-catalog.js";
import { createConfigurationState } from "./modules/configuration-state.js";
import { createDiagnostics } from "./modules/diagnostics.js";
import { createFeedback } from "./modules/feedback.js";
import { createMaterialMetadata } from "./modules/material-metadata.js";
import { createPanelEditSession } from "./modules/panel-edit-session.js";
import { createPanelElements } from "./modules/panel-elements.js";
import { createMaterialCatalog } from "./modules/material-catalog.js";
import { createMaterialIdentity } from "./modules/material-identity.js";
import { createMaterialBatches } from "./modules/material-batches.js";
import { createPanelPreview } from "./modules/panel-preview.js";
import { createCanvasPrimitives } from "./modules/canvas-primitives.js";
import { createCatalogStartup } from "./modules/catalog-startup.js";
import { createPanelControls } from "./modules/panel-controls.js";
import { createPanelEdges } from "./modules/panel-edges.js";
import { createEdgeValues } from "./modules/edge-values.js";
import { createExtraPreview } from "./modules/extra-preview.js";
import { createExtraEditor } from "./modules/extra-editor.js";
import { createPanelDock } from "./modules/panel-dock.js";
import { createPanelList } from "./modules/panel-list.js";
import { createGrainModel } from "./modules/grain-model.js";
import { createGrainData } from "./modules/grain-data.js";
import { createGrainRendering } from "./modules/grain-rendering.js";
import { createExtraOverlay } from "./modules/extra-overlay.js";
import { createAlertDialog } from "./modules/alert-dialog.js";
import { createOverviewOverlay } from "./modules/overview-overlay.js";
import { createTemplateParser } from "./modules/template-parser.js";
import { createTemplateInventory } from "./modules/template-inventory.js";
import { createFormatting } from "./modules/formatting.js";
import { createStartup } from "./modules/startup.js";
import { createPanelEntryEvents } from "./modules/panel-entry-events.js";
import { createCustomerValidation } from "./modules/customer-validation.js";
import { createSubmission } from "./modules/submission.js";
import { createJobCancellation } from "./modules/job-cancellation.js";
import { createWizardStartup } from "./modules/wizard-startup.js";
import { createSelectionState } from "./modules/selection-state.js";
import { createDomLookup } from "./modules/dom-lookup.js";
import { createCheckoutReviewFlow } from "./modules/checkout-review-flow.js";
import { createMaterialSelectionView } from "./modules/material-selection-view.js";
import { createPanelTypes } from "./modules/panel-types.js";
import { createPanelEditorBinding } from "./modules/panel-editor-binding.js";
import { createGrainStatus } from "./modules/grain-status.js";
import { createTemplateLoadState } from "./modules/template-load-state.js";
import { createMaterialIntents } from "./modules/material-intents.js";
import { createViewRefresh } from "./modules/view-refresh.js";
import { createUiWorkflows } from "./modules/ui-workflows.js";
import { createPanelsProjection } from "./modules/panels-projection.js";
import { createEdgePresentation } from "./modules/edge-presentation.js";
import { createOverviewBridge } from "./modules/overview-bridge.js";
import { createPanelLabels } from "./modules/panel-labels.js";
import { createPanelForm } from "./modules/panel-form.js";
import { createPanelBootstrap } from "./modules/panel-bootstrap.js";
import { createMaterialSearchBinding } from "./modules/material-search-binding.js";
import { createPanelEditController } from "./modules/panel-edit-controller.js";
import { createPanelIntents } from "./modules/panel-intents.js";

/** Explicit dependency wiring and ordered application startup. */

function sealPort(port, owner) {
  Object.defineProperties(port, Object.getOwnPropertyDescriptors(owner));
  Object.freeze(port);
}

function exposeContract(root, name, owner) {
  Object.defineProperty(root, name, {
    configurable: false,
    enumerable: false,
    get() {
      return owner[name];
    },
  });
}

export function startApplicationRuntime({ foundation, root = window } = {}) {
  const calculation = {};
  const calculationView = {};
  const priceBar = {};
  const progressView = {};
  const jobEstimates = {};
  const dxfExport = {};
  const templateExport = {};
  const jobPayload = {};
  const grainAssignments = {};
  const checkoutOverlays = {};
  const customerForm = {};
  const overlayControls = {};
  const customerSnapshot = {};
  const checkoutFlow = {};
  const jobRecovery = {};
  const jobClient = {};
  const authoritativePrice = {};
  const wizardNavigation = {};
  const templateCatalog = {};
  const configurationState = {};
  const diagnostics = {};
  const feedback = {};
  const materialMetadata = {};
  const panelEditSession = {};
  const panelElements = {};
  const materialCatalog = {};
  const materialIdentity = {};
  const materialBatches = {};
  const panelPreview = {};
  const canvasPrimitives = {};
  const catalogStartup = {};
  const panelControls = {};
  const panelEdges = {};
  const edgeValues = {};
  const extraPreview = {};
  const extraEditor = {};
  const panelDock = {};
  const panelList = {};
  const grainModel = {};
  const grainData = {};
  const grainRendering = {};
  const extraOverlay = {};
  const alertDialog = {};
  const overviewOverlay = {};
  const templateParser = {};
  const templateInventory = {};
  const formatting = {};
  const startup = {};
  const panelEntryEvents = {};
  const customerValidation = {};
  const submission = {};
  const jobCancellation = {};
  const wizardStartup = {};
  const selectionState = {};
  const domLookup = {};
  const checkoutReviewFlow = {};
  const materialSelectionView = {};
  const panelTypes = {};
  const panelEditorBinding = {};
  const grainStatus = {};
  const templateLoadState = {};
  const materialIntents = {};
  const viewRefresh = {};
  const uiWorkflows = {};
  const panelsProjection = {};
  const edgePresentation = {};
  const overviewBridge = {};
  const panelLabels = {};
  const panelForm = {};
  const panelBootstrap = {};
  const materialSearchBinding = {};
  const panelEditController = {};
  const panelIntents = {};
  const applicationState = Object.freeze({
    get current() {
      return configurationState.current;
    },
  });
  Object.defineProperty(root, "state", {
    configurable: false,
    enumerable: true,
    get() {
      return configurationState.current;
    },
  });

  sealPort(
    calculation,
    createCalculation({
      alertDialog,
      applicationState,
      authoritativePrice,
      calculationView,
      checkoutFlow,
      checkoutReviewFlow,
      customerForm,
      foundation,
      jobClient,
      jobEstimates,
      jobPayload,
      jobRecovery,
      overviewOverlay,
      priceBar,
      progressView,
      templateExport,
      wizardNavigation,
    }),
  );
  sealPort(calculationView, createCalculationView({}));
  sealPort(
    priceBar,
    createPriceBar({
      applicationState,
      calculationView,
      panelsProjection,
      progressView,
    }),
  );
  sealPort(progressView, createProgressView({ foundation }));
  sealPort(jobEstimates, createJobEstimates({}));
  sealPort(dxfExport, createDxfExport({}));
  sealPort(
    templateExport,
    createTemplateExport({
      applicationState,
      dxfExport,
      priceBar,
      templateCatalog,
    }),
  );
  sealPort(
    jobPayload,
    createJobPayload({
      applicationState,
      customerSnapshot,
      dxfExport,
      foundation,
      grainAssignments,
      jobEstimates,
      priceBar,
      templateExport,
    }),
  );
  sealPort(grainAssignments, createGrainAssignments({}));
  sealPort(checkoutOverlays, createCheckoutOverlays({}));
  sealPort(
    customerForm,
    createCustomerForm({
      applicationState,
      checkoutOverlays,
      customerSnapshot,
      priceBar,
    }),
  );
  sealPort(overlayControls, createOverlayControls({ foundation }));
  sealPort(customerSnapshot, createCustomerSnapshot({ foundation }));
  sealPort(
    checkoutFlow,
    createCheckoutFlow({
      applicationState,
      calculationView,
      customerForm,
      customerSnapshot,
      customerValidation,
      overviewOverlay,
      wizardNavigation,
    }),
  );
  sealPort(
    jobRecovery,
    createJobRecovery({
      applicationState,
      authoritativePrice,
      calculationView,
      checkoutReviewFlow,
      foundation,
      jobClient,
      priceBar,
      progressView,
      wizardNavigation,
    }),
  );
  sealPort(jobClient, createJobClient({ applicationState, foundation }));
  sealPort(
    authoritativePrice,
    createAuthoritativePrice({ applicationState, jobClient, progressView }),
  );
  sealPort(
    wizardNavigation,
    createWizardNavigation({
      applicationState,
      customerForm,
      customerValidation,
      domLookup,
      foundation,
      materialCatalog,
      overlayControls,
      panelBootstrap,
      panelControls,
      panelDock,
      panelElements,
      panelForm,
      panelList,
      panelTypes,
      panelsProjection,
    }),
  );
  sealPort(
    templateCatalog,
    createTemplateCatalog({
      applicationState,
      feedback,
      formatting,
      materialSelectionView,
      panelElements,
      panelPreview,
      panelTypes,
      selectionState,
      templateInventory,
      templateLoadState,
      templateParser,
      wizardNavigation,
    }),
  );
  sealPort(configurationState, createConfigurationState({ selectionState }));
  sealPort(diagnostics, createDiagnostics({ applicationState, jobClient }));
  sealPort(
    feedback,
    createFeedback({
      applicationState,
      calculationView,
      configurationState,
      formatting,
    }),
  );
  sealPort(
    materialMetadata,
    createMaterialMetadata({
      applicationState,
      configurationState,
      foundation,
      materialIdentity,
    }),
  );
  sealPort(panelEditSession, createPanelEditSession({}));
  sealPort(panelElements, createPanelElements({ foundation }));
  sealPort(
    materialCatalog,
    createMaterialCatalog({
      materialIdentity,
      panelElements,
      panelTypes,
      templateCatalog,
    }),
  );
  sealPort(materialIdentity, createMaterialIdentity({}));
  sealPort(
    materialBatches,
    createMaterialBatches({
      applicationState,
      configurationState,
      extraEditor,
      extraPreview,
      feedback,
      formatting,
      grainData,
      grainRendering,
      materialIdentity,
      materialMetadata,
      materialSelectionView,
      overviewOverlay,
      panelBootstrap,
      panelEdges,
      panelEditSession,
      panelElements,
      panelList,
      panelPreview,
      selectionState,
      wizardNavigation,
    }),
  );
  sealPort(
    panelPreview,
    createPanelPreview({
      applicationState,
      canvasPrimitives,
      formatting,
      panelElements,
      templateLoadState,
    }),
  );
  sealPort(canvasPrimitives, createCanvasPrimitives({}));
  sealPort(
    catalogStartup,
    createCatalogStartup({
      applicationState,
      configurationState,
      feedback,
      panelControls,
      panelPreview,
      wizardNavigation,
    }),
  );
  sealPort(
    panelControls,
    createPanelControls({
      applicationState,
      configurationState,
      domLookup,
      extraEditor,
      extraPreview,
      feedback,
      formatting,
      grainData,
      materialSelectionView,
      panelDock,
      panelEdges,
      panelEditSession,
      panelElements,
      panelForm,
      panelList,
      panelPreview,
      panelTypes,
      selectionState,
      templateCatalog,
      templateParser,
    }),
  );
  sealPort(panelEdges, createPanelEdges({ extraPreview, panelElements }));
  sealPort(edgeValues, createEdgeValues({}));
  sealPort(
    extraPreview,
    createExtraPreview({
      applicationState,
      canvasPrimitives,
      edgeValues,
      panelElements,
    }),
  );
  sealPort(
    extraEditor,
    createExtraEditor({
      applicationState,
      configurationState,
      edgePresentation,
      extraPreview,
      feedback,
      formatting,
      foundation,
      grainData,
      materialMetadata,
      panelDock,
      panelEdges,
      panelEditSession,
      panelElements,
      panelList,
      priceBar,
      viewRefresh,
    }),
  );
  sealPort(panelDock, createPanelDock({ applicationState, foundation, panelElements }));
  sealPort(
    panelList,
    createPanelList({
      applicationState,
      edgePresentation,
      extraPreview,
      feedback,
      formatting,
      foundation,
      grainData,
      grainStatus,
      materialIdentity,
      materialMetadata,
      panelDock,
      panelEdges,
      panelEditSession,
      panelElements,
      panelForm,
      panelIntents,
      panelPreview,
      priceBar,
      viewRefresh,
    }),
  );
  sealPort(
    grainModel,
    createGrainModel({
      alertDialog,
      applicationState,
      configurationState,
      extraEditor,
      extraPreview,
      formatting,
      grainData,
      grainRendering,
      grainStatus,
      materialMetadata,
      panelEdges,
      panelEditSession,
      panelElements,
      panelList,
      wizardNavigation,
    }),
  );
  sealPort(grainData, createGrainData({ applicationState, foundation, grainAssignments }));
  sealPort(
    grainRendering,
    createGrainRendering({
      applicationState,
      configurationState,
      extraEditor,
      extraPreview,
      formatting,
      foundation,
      grainAssignments,
      grainData,
      panelEdges,
      panelEditSession,
      panelElements,
      panelList,
      templateCatalog,
      viewRefresh,
    }),
  );
  sealPort(
    extraOverlay,
    createExtraOverlay({
      applicationState,
      configurationState,
      extraEditor,
      extraPreview,
      materialMetadata,
      panelEdges,
      panelEditSession,
      panelElements,
    }),
  );
  sealPort(alertDialog, createAlertDialog({ foundation }));
  sealPort(
    overviewOverlay,
    createOverviewOverlay({
      applicationState,
      configurationState,
      edgePresentation,
      edgeValues,
      extraEditor,
      extraOverlay,
      extraPreview,
      feedback,
      formatting,
      foundation,
      grainData,
      materialIdentity,
      materialMetadata,
      panelElements,
      panelLabels,
      panelList,
      wizardNavigation,
    }),
  );
  sealPort(templateParser, createTemplateParser({}));
  sealPort(
    templateInventory,
    createTemplateInventory({
      applicationState,
      selectionState,
      templateParser,
    }),
  );
  sealPort(formatting, createFormatting({}));
  sealPort(startup, createStartup({ extraEditor, extraPreview, panelPreview }));
  sealPort(panelEntryEvents, createPanelEntryEvents({ panelForm, wizardNavigation }));
  sealPort(
    customerValidation,
    createCustomerValidation({ applicationState, customerForm, domLookup }),
  );
  sealPort(
    submission,
    createSubmission({
      alertDialog,
      applicationState,
      authoritativePrice,
      calculationView,
      customerForm,
      customerSnapshot,
      customerValidation,
      domLookup,
      foundation,
      overlayControls,
      priceBar,
      wizardNavigation,
    }),
  );
  sealPort(
    jobCancellation,
    createJobCancellation({
      alertDialog,
      applicationState,
      calculationView,
      domLookup,
      foundation,
      materialSelectionView,
      overlayControls,
      overviewOverlay,
      panelList,
      submission,
      viewRefresh,
      wizardNavigation,
    }),
  );
  sealPort(
    wizardStartup,
    createWizardStartup({
      panelForm,
      panelList,
      wizardNavigation,
    }),
  );
  sealPort(selectionState, createSelectionState({}));
  sealPort(domLookup, createDomLookup({}));
  sealPort(
    checkoutReviewFlow,
    createCheckoutReviewFlow({
      alertDialog,
      applicationState,
      calculationView,
      foundation,
      wizardNavigation,
    }),
  );
  sealPort(
    materialSelectionView,
    createMaterialSelectionView({
      applicationState,
      configurationState,
      feedback,
      formatting,
      foundation,
      materialIdentity,
      materialIntents,
      panelElements,
    }),
  );
  sealPort(panelTypes, createPanelTypes({ applicationState, panelElements, selectionState }));
  sealPort(
    panelEditorBinding,
    createPanelEditorBinding({
      extraEditor,
      extraPreview,
      foundation,
      panelControls,
      panelDock,
      panelEdges,
      panelElements,
    }),
  );
  sealPort(grainStatus, createGrainStatus({ grainData, panelElements }));
  sealPort(templateLoadState, createTemplateLoadState({}));
  sealPort(materialIntents, createMaterialIntents({}));
  sealPort(viewRefresh, createViewRefresh({}));
  sealPort(
    uiWorkflows,
    createUiWorkflows({
      extraEditor,
      grainModel,
      materialBatches,
      materialIntents,
      overviewOverlay,
      panelEditController,
      panelIntents,
      viewRefresh,
    }),
  );
  sealPort(panelsProjection, createPanelsProjection({ foundation }));
  sealPort(edgePresentation, createEdgePresentation({}));
  sealPort(overviewBridge, createOverviewBridge({ edgePresentation, overviewOverlay }));
  sealPort(panelLabels, createPanelLabels({ applicationState, foundation }));
  sealPort(
    panelForm,
    createPanelForm({
      applicationState,
      domLookup,
      foundation,
      materialSelectionView,
      panelEditSession,
      panelElements,
      panelPreview,
      selectionState,
    }),
  );
  sealPort(
    panelBootstrap,
    createPanelBootstrap({
      applicationState,
      configurationState,
      formatting,
      panelElements,
      panelPreview,
      panelTypes,
      selectionState,
      templateCatalog,
    }),
  );
  sealPort(
    materialSearchBinding,
    createMaterialSearchBinding({
      configurationState,
      materialBatches,
      materialCatalog,
      panelElements,
    }),
  );
  sealPort(
    panelEditController,
    createPanelEditController({
      applicationState,
      domLookup,
      foundation,
      materialIntents,
      materialSelectionView,
      panelDock,
      panelEditSession,
      panelElements,
      panelForm,
      panelList,
      selectionState,
      wizardNavigation,
    }),
  );
  sealPort(panelIntents, createPanelIntents({}));

  exposeContract(root, "statusMsg", calculationView);
  exposeContract(root, "moneyEUR", calculationView);
  exposeContract(root, "updatePriceBar", priceBar);
  exposeContract(root, "_authoritativePriceInclVat", authoritativePrice);
  exposeContract(root, "_hydrateAuthoritativePricingSummary", authoritativePrice);
  exposeContract(root, "setStep", wizardNavigation);
  exposeContract(root, "restoreIdleToolStateAfterStartError", calculation);
  exposeContract(root, "__metodInvalidateAuthoritativePriceHydration", authoritativePrice);

  // State must exist before any view initializer (including the price bar).
  // DOM readiness mounts views only; it must never replace the active state.
  configurationState.mount();
  configurationState.mount2();

  root.addEventListener("DOMContentLoaded", () => {
    templateCatalog.mount();
    diagnostics.mount();
    feedback.mount();
    materialMetadata.mount();
    panelEditSession.mount();
    panelElements.mount();
    materialCatalog.mount();
    panelElements.mount2();
    materialCatalog.mount2();
    materialBatches.mount();
    materialSearchBinding.mount3();
    materialBatches.mount2();
    panelElements.mount3();
    panelPreview.mount();
    catalogStartup.mount();
    panelControls.mount();
    panelEdges.mount();
    panelEditorBinding.mount();
    panelDock.mount();
    grainModel.mount();
    grainRendering.mount();
    extraOverlay.mount();
    alertDialog.mount();
    overviewOverlay.mount();
    grainModel.mount2();
    startup.mount();
  });

  // global startup
  uiWorkflows.initialize();
  calculationView.initialize();
  jobEstimates.initialize();
  templateExport.initialize();
  jobPayload.initialize();
  checkoutOverlays.initialize();
  customerForm.initialize();
  jobRecovery.initialize();
  authoritativePrice.initialize();
  wizardNavigation.initialize();
  calculation.initialize2();
  jobRecovery.initialize2();
  priceBar.initialize();

  // wizard startup
  wizardNavigation.connect();
  panelForm.connect();
  wizardNavigation.connect2();
  submission.connect();
  jobCancellation.connect();
  submission.connect2();
  panelEntryEvents.connect2();
  wizardStartup.connect();

  // fallback startup
  overviewBridge.install();

  return Object.freeze({
    bootstrap: panelBootstrap.bootstrapPanelSelectionForActiveMaterial,
    resetFields: panelForm.resetPanelEntryFields,
    removeMaterial: materialIntents.remove,
    removeMaterialConfirmed: materialBatches._removeMaterialBatchConfirmed,
    setDockOpen: panelDock.setPanelDockOpen,
    setActiveMaterial: materialIntents.activate,
  });
}
