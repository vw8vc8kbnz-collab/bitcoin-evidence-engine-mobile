/** Single foundation binding, connected by the application entrypoint. */
export let toolAFoundation = null;
export function connectFoundation(value) {
  if (!value || toolAFoundation) throw new Error("Foundation must be connected exactly once");
  toolAFoundation = value;
}
