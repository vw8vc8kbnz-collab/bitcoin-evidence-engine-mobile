/** panel-edit-controller: one runtime owner with explicit, immutable dependency ports. */
export function createPanelEditController({
  applicationState,
  domLookup,
  foundation,
  materialIntents,
  materialSelectionView,
  panelDock,
  panelEditSession,
  panelElements,
  panelForm,
  panelList,
  selectionState,
  wizardNavigation,
} = {}) {
  function startEditCartItem(itemId) {
    try {
      const __editSeq =
        typeof window !== "undefined"
          ? (window.__panelEditSeq = Number(window.__panelEditSeq || 0) + 1) || 1
          : 1;
      const idx = (applicationState.current.cart || []).findIndex(
        (x) => String(x?.id || "") === String(itemId || ""),
      );
      if (idx < 0) return;
      const it = applicationState.current.cart[idx];
      // when editing an existing panel, make its material authoritative again.
      // This prevents editing a panel from material A while material B is still active in Step 2.
      {
        const editMk = String(
          it.materialKey || it.material || it.materialCode || it.articleNumber || "",
        ).trim();
        if (editMk && String(applicationState.current.activeMaterialKey || "") !== editMk) {
          if (typeof materialIntents.activate === "function") materialIntents.activate(editMk);
          else {
            const b = (applicationState.current.materialBatches || []).find(
              (x) => String(x?.key || "") === editMk,
            );
            if (b) {
              applicationState.current.activeMaterialKey = b.key;
              applicationState.current.material = b.mat || applicationState.current.material;
            }
          }
        }
        selectionState.update({
          materialKey: String(applicationState.current.activeMaterialKey || editMk || ""),
        });
        if (typeof materialSelectionView.renderMaterialBatches === "function")
          materialSelectionView.renderMaterialBatches();
        if (typeof materialSelectionView.renderMaterialBatchesStep2 === "function")
          materialSelectionView.renderMaterialBatchesStep2();
      }
      const editGroupKey = panelDock._panelDisplayGroupKey(it);
      const editGroupCount = Math.max(
        1,
        (applicationState.current.cart || []).filter(
          (x) => panelDock._panelDisplayGroupKey(x) === editGroupKey,
        ).length || 1,
      );
      panelForm.setPanelEditMode(it.id, editGroupCount, editGroupKey);
      panelList.renderCart();
      if (typeof wizardNavigation.renderFooterForStep === "function")
        wizardNavigation.renderFooterForStep("panels");
      if (typeof window !== "undefined") {
        window.__prefillingPanelEdit = true;
        window.__skipPanelBootstrapForEdit = true;
        window.__panelEditTouchedFields = {
          qty: false,
          hinge: false,
          extTop: false,
          extBot: false,
          customLabel: false,
        };
      }
      wizardNavigation.showStep("panels");
      const __prefill =
        foundation.current && typeof foundation.current.getPanelEditSnapshot === "function"
          ? foundation.current.getPanelEditSnapshot(it, {
              originalCount: editGroupCount,
            })
          : {
              type: String(it.type || ""),
              templateId: String(it.templateId || ""),
              qty: editGroupCount,
              hinge: String(it.hinge || "left"),
              extTop: Number(it.extTop) || 0,
              extBot: Number(it.extBot) || 0,
              customLabel: (function () {
                try {
                  const direct = String(it.customName || it.customLabel || "").trim();
                  if (direct) return direct;
                  const label = String(it.label || "").trim();
                  const base = String(it.baseLabel || it.templateId || "").trim();
                  return label && label !== base ? label : "";
                } catch (_) {
                  return "";
                }
              })(),
              showStep: "panels",
            };
      if (typeof window !== "undefined")
        window.__panelEditSnapshot = {
          ...__prefill,
          customLabel:
            panelForm.ensurePanelEditKnownName(__prefill) ||
            panelForm.resolvePanelEditCustomName(__prefill),
        };
      selectionState.update({
        customLabel:
          panelForm.ensurePanelEditKnownName(__prefill) ||
          panelForm.resolvePanelEditCustomName(__prefill),
      });
      panelForm.syncPanelEditLiveForm();

      const __finish = () => {
        {
          if (
            typeof window !== "undefined" &&
            Number(window.__panelEditSeq || 0) !== Number(__editSeq || 0)
          )
            return;
          const currentEditId =
            typeof panelEditSession.resolvePanelEditTargetId === "function"
              ? panelEditSession.resolvePanelEditTargetId()
              : panelEditSession.panelEditTargetId;
          if (!currentEditId || String(currentEditId) !== String(it.id || "")) return;
          panelForm.applyPanelEditSnapshotToForm(__prefill);
          {
            const custom = domLookup.byId("customLabelInput");
            const resolved =
              panelForm.ensurePanelEditKnownName(__prefill) ||
              panelForm.resolvePanelEditCustomName(__prefill);
            if (custom && resolved) {
              custom.value = resolved;
              custom.setAttribute("value", resolved);
            }
          }
          panelForm.syncPanelEditLiveForm();
          panelDock.pulsePanelDock("Paneel geladen om te bewerken.");
        }
      };

      selectionState.update({ type: String(__prefill.type || "") });
      if (panelElements.typeSel) {
        panelElements.typeSel.value = applicationState.current.selection.type;
        panelElements.typeSel.dispatchEvent(new Event("change", { bubbles: true }));
      }

      setTimeout(() => {
        {
          if (
            typeof window !== "undefined" &&
            Number(window.__panelEditSeq || 0) !== Number(__editSeq || 0)
          )
            return;
          const currentEditId =
            typeof panelEditSession.resolvePanelEditTargetId === "function"
              ? panelEditSession.resolvePanelEditTargetId()
              : panelEditSession.panelEditTargetId;
          if (!currentEditId || String(currentEditId) !== String(it.id || "")) return;
          selectionState.update({
            templateId: String(__prefill.templateId || ""),
          });
          if (panelElements.sizeSel) {
            panelElements.sizeSel.value = applicationState.current.selection.templateId;
            panelElements.sizeSel.dispatchEvent(new Event("change", { bubbles: true }));
          }
        }
        setTimeout(() => {
          if (
            typeof window === "undefined" ||
            Number(window.__panelEditSeq || 0) === Number(__editSeq || 0)
          ) {
            __finish();
            panelForm.applyKnownPanelEditName();
          }
        }, 80);
        setTimeout(() => {
          if (
            typeof window === "undefined" ||
            Number(window.__panelEditSeq || 0) === Number(__editSeq || 0)
          ) {
            __finish();
            panelForm.applyKnownPanelEditName();
          }
        }, 220);
        setTimeout(() => {
          if (
            typeof window === "undefined" ||
            Number(window.__panelEditSeq || 0) === Number(__editSeq || 0)
          ) {
            __finish();
            panelForm.applyKnownPanelEditName();
          }
        }, 420);
        setTimeout(() => {
          try {
            if (
              typeof window === "undefined" ||
              Number(window.__panelEditSeq || 0) === Number(__editSeq || 0)
            ) {
              panelForm.applyKnownPanelEditName(true);
            }
          } finally {
            if (
              typeof window !== "undefined" &&
              Number(window.__panelEditSeq || 0) === Number(__editSeq || 0)
            ) {
              window.__prefillingPanelEdit = false;
              window.__skipPanelBootstrapForEdit = false;
            }
          }
        }, 700);
      }, 30);
    } catch (error) {
      window.__prefillingPanelEdit = false;
      window.__skipPanelBootstrapForEdit = false;
      throw error;
    }
  }

  return Object.freeze({
    startEditCartItem,
  });
}
