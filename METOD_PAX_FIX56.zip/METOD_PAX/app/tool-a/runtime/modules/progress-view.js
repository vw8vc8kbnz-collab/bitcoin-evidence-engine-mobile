/** progress-view: one runtime owner with explicit, immutable dependency ports. */
export function createProgressView({ foundation } = {}) {
  function hideMetodProgressOverlay() {
    {
      window.__metodOptimizerBusy = false;
      const owner = foundation.current;
      if (owner && typeof owner.hideMetodProgressOverlay === "function") {
        return owner.hideMetodProgressOverlay();
      }
    }
  }

  function finishOptimizerProgressLifecycle() {
    // Terminal ownership must never depend on price/panel rendering. Reset the
    // legacy mirrors first, then release the component owner. This function is
    // intentionally idempotent so every terminal path may call it safely.
    window.__metodOptimizerBusy = false;
    window.__metodBusySince = null;
    clearTimeout(window.__metodBusyWatchdog);
    window.__metodBusyWatchdog = null;
    {
      const owner = foundation.current;
      if (owner && typeof owner.finishOptimizerProgress === "function") {
        return owner.finishOptimizerProgress();
      }
      if (owner && typeof owner.hideMetodProgressOverlay === "function") {
        return owner.hideMetodProgressOverlay();
      }
    }
    return false;
  }

  function updateMetodProgressBadge(opts = {}) {
    {
      if (Object.prototype.hasOwnProperty.call(opts || {}, "busy")) {
        window.__metodOptimizerBusy = opts.busy === true;
      }
      const owner = foundation.current;
      if (owner && typeof owner.updateMetodProgressBadge === "function") {
        return owner.updateMetodProgressBadge(opts);
      }
    }
    return false;
  }

  function isMetodProgressVisible() {
    {
      const owner = foundation.current;
      if (owner && typeof owner.isMetodProgressVisible === "function") {
        return !!owner.isMetodProgressVisible();
      }
    }
    return isMetodProgressFallbackVisible();
  }

  async function waitForMetodProgressPaint() {
    {
      const owner = foundation.current;
      if (owner && typeof owner.waitForMetodProgressPaint === "function") {
        return !!(await owner.waitForMetodProgressPaint());
      }
    }

    await new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)));

    return isMetodProgressVisible();
  }

  async function settleOptimizerProgress(options = {}) {
    {
      const owner = foundation.current;
      if (owner && typeof owner.settleOptimizerProgress === "function") {
        return !!(await owner.settleOptimizerProgress(options));
      }
    }
    return waitForMetodProgressPaint();
  }

  function isMetodProgressFallbackVisible() {
    {
      const owner = foundation.current;
      if (owner && typeof owner.isMetodProgressFallbackVisible === "function") {
        return !!owner.isMetodProgressFallbackVisible();
      }
    }
    return false;
  }

  return Object.freeze({
    waitForMetodProgressPaint,
    finishOptimizerProgressLifecycle,
    updateMetodProgressBadge,
    settleOptimizerProgress,
    isMetodProgressVisible,
    hideMetodProgressOverlay,
    isMetodProgressFallbackVisible,
  });
}
