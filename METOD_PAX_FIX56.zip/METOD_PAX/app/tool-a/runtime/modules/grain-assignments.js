/** grain-assignments: one runtime owner with explicit, immutable dependency ports. */
export function createGrainAssignments({} = {}) {
  function ensureExtraAssignments(p) {
    if (!p || typeof p !== "object") return [];
    const qty = Math.max(1, Number(p.qty || 1));
    if (!Array.isArray(p.grainAssignments)) p.grainAssignments = [];
    while (p.grainAssignments.length < qty) {
      p.grainAssignments.push({ grainGroupId: null, grainOrder: null });
    }
    if (p.grainAssignments.length > qty) {
      p.grainAssignments = p.grainAssignments.slice(0, qty);
    }
    return p.grainAssignments;
  }

  return Object.freeze({
    ensureExtraAssignments,
  });
}
