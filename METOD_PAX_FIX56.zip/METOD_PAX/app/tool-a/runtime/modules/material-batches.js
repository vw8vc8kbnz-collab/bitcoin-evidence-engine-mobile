import { ToolAPanelsEntry } from "../../adapters/panels-entrypoints.js";
import { REVISION } from "../../version.js";
import { ToolAMaterialBatchMutations } from "../../domain/material-batch-mutations.js";
import { ToolAMaterialSwatchRenderer } from "../../domain/material-swatch-renderer.js";
import { ToolAPanelBootstrapApply } from "../../domain/panel-bootstrap-apply.js";
import { ToolAPanelBootstrapMutations } from "../../domain/panel-bootstrap-mutations.js";
/** material-batches: one runtime owner with explicit, immutable dependency ports. */
export function createMaterialBatches({
  applicationState,
  configurationState,
  extraEditor,
  extraPreview,
  feedback,
  formatting,
  grainData,
  grainRendering,
  materialIdentity,
  materialMetadata,
  materialSelectionView,
  overviewOverlay,
  panelBootstrap,
  panelEdges,
  panelEditSession,
  panelElements,
  panelList,
  panelPreview,
  selectionState,
  wizardNavigation,
} = {}) {
  let removeHandlerBound = false;

  let __toolAMaterialRemovalTransaction;

  function setActiveMaterial(key) {
    configurationState.ensureStateShape();
    const b = (applicationState.current.materialBatches || []).find((x) => x.key === key);
    applicationState.current.activeMaterialKey = b ? b.key : null;
    applicationState.current.material = b ? b.mat : null;

    // Keep selection in sync (buttons & add-to-cart logic rely on this)

    selectionState.update({
      materialKey: applicationState.current.activeMaterialKey,
    });
    selectionState.update({
      materialName: applicationState.current.material
        ? materialIdentity.materialLabelMat(applicationState.current.material)
        : null,
    });
    {
      const pill = document.getElementById("activeMaterialPill");
      if (pill)
        pill.textContent = applicationState.current.material
          ? materialIdentity.materialLabelMat(applicationState.current.material)
          : "—";
    }

    // Do NOT force wizard page back to step 1 here.
    // Just refresh footer/button states for the current step.
    if (window.__renderWizardFooter)
      window.__renderWizardFooter(window.__metod_uiStep || "material");

    // Per afspraak: nerfrichting default AAN, maar alleen overrulen als de klant dit
    // nog niet heeft aangepast. We bewaren de keuze per materiaal-batch.
    if (applicationState.current.material) {
      if (b && typeof b.grainEnabled === "boolean") {
        applicationState.current.grainEnabled = b.grainEnabled;
      } else if (typeof applicationState.current.grainEnabled !== "boolean") {
        applicationState.current.grainEnabled = true;
        if (b) b.grainEnabled = true;
      }
    }

    panelElements.matSearch.value = "";
    panelElements.matSuggest.style.display = "none";

    if (applicationState.current.material) {
      // Update detail text below chips
      if (panelElements.matChosenTitle)
        panelElements.matChosenTitle.textContent = materialIdentity.materialLabelMat(
          applicationState.current.material,
        );
      const pn = applicationState.current.material.productName
        ? String(applicationState.current.material.productName)
        : "";
      const w = formatting._esc(
        String(
          applicationState.current.material.sheetSizeMm &&
            applicationState.current.material.sheetSizeMm.width != null
            ? applicationState.current.material.sheetSizeMm.width
            : "—",
        ),
      );
      const h = formatting._esc(
        String(
          applicationState.current.material.sheetSizeMm &&
            applicationState.current.material.sheetSizeMm.height != null
            ? applicationState.current.material.sheetSizeMm.height
            : "—",
        ),
      );
      const t = formatting._esc(
        String(
          applicationState.current.material.thicknessMm != null
            ? applicationState.current.material.thicknessMm
            : "—",
        ),
      );
      if (panelElements.matChosenMeta) {
        panelElements.matChosenMeta.innerHTML =
          (pn ? `<div class="u-material-heading">${formatting._esc(pn)}</div>` : "") +
          `<div class="muted u-row-wrap-gap-10">
          <span><b>Plaat</b> ${w}×${h} mm</span>
          <span><b>Dikte</b> ${t} mm</span>
        </div>`;
      }
    } else {
      if (panelElements.matChosenTitle) panelElements.matChosenTitle.textContent = "—";
      if (panelElements.matChosenMeta) panelElements.matChosenMeta.innerHTML = "";
    }

    // Keep selection material key in sync for existing pricing/export code
    if (applicationState.current.material && applicationState.current.material.decorName) {
      // keep the old selection.material string for compatibility (not used for UI)
      selectionState.update({ material: "custom" });
    }

    const __extraThicknessesChanged =
      materialMetadata.syncExtraPanelThicknessesForSelectedMaterials();
    materialSelectionView.renderMaterialBatches();
    materialSelectionView.updateButtons();
    {
      materialMetadata.refreshExtraMaterialOptions();
      const __extraMatSel = document.getElementById("extraMat");
      if (__extraMatSel && panelEditSession.extraEditIndex == null) {
        const __activeMk = String(applicationState.current.activeMaterialKey || "").trim();
        if (__activeMk && __extraMatSel.value !== __activeMk) {
          __extraMatSel.value = __activeMk;
          panelEdges.syncChecksFromSelect();
          extraPreview.drawExtraPreview();
        }
      }
    }
    if (__extraThicknessesChanged && typeof extraEditor.renderExtraPanels === "function")
      extraEditor.renderExtraPanels();
    if (__extraThicknessesChanged && typeof panelList.renderCart === "function")
      panelList.renderCart();
    if (__extraThicknessesChanged && typeof extraPreview.drawExtraPreview === "function")
      extraPreview.drawExtraPreview();
    feedback.updateWizardBanner();
    feedback.scheduleDraftSave();
    materialSelectionView.renderGrainByMaterial();
    // warm the exact selected swatch as soon as the customer switches material,
    // so opening the viewer normally has no visible generic-texture flash.
    ToolAMaterialSwatchRenderer?.preloadMaterial(
      String(applicationState.current.activeMaterialKey || ""),
      applicationState.current,
    );
    // an active-material switch must be visible immediately in every viewer.
    panelPreview.draw();
    if (
      panelElements.grainPreview &&
      panelElements.grainPreview.closest &&
      panelElements.grainPreview.closest("#grainOverlay")?.style.display !== "none"
    )
      grainRendering.drawGrainPreview();
    document.dispatchEvent(
      new CustomEvent("adzaagt-material-selection-updated", {
        detail: {
          publicMaterialId: String(applicationState.current.activeMaterialKey || ""),
        },
      }),
    );
  }

  function addMaterialBatch(mat) {
    configurationState.ensureStateShape();
    const key = materialIdentity.materialKey(mat);
    if (!(applicationState.current.materialBatches || []).some((b) => b.key === key)) {
      applicationState.current.materialBatches.push({
        key,
        mat,
        grainEnabled: true,
      });
    } else {
      // update stored mat reference (fresh data)
      applicationState.current.materialBatches = applicationState.current.materialBatches.map(
        (b) => (b.key === key ? Object.assign({}, b, { key, mat }) : b),
      );
    }
    setActiveMaterial(key);
    materialSelectionView.renderMaterialBatches();
    {
      const shouldBootstrap =
        !!window.__forcePanelBootstrap ||
        !String(applicationState.current?.selection?.type || "").trim() ||
        !String(applicationState.current?.selection?.templateId || "").trim();
      if (shouldBootstrap) {
        panelBootstrap.bootstrapPanelSelectionForActiveMaterial(true);
        window.__refreshCustomLabelVisibility?.();
        window.__forcePanelBootstrap = false;
      }
    }
  }

  function _removeMaterialBatchConfirmed(key) {
    configurationState.ensureStateShape();
    const k = String(key || "");
    if (
      !k ||
      !(applicationState.current.materialBatches || []).some(
        (batch) => String(batch?.key || "") === k,
      )
    )
      return false;
    const __plan =
      ToolAMaterialBatchMutations && typeof ToolAMaterialBatchMutations.getPlan === "function"
        ? ToolAMaterialBatchMutations.getPlan({
            key: k,
            state: applicationState.current,
          })
        : null;
    const __itemMaterialKey =
      ToolAMaterialBatchMutations &&
      typeof ToolAMaterialBatchMutations.getItemMaterialKey === "function"
        ? ToolAMaterialBatchMutations.getItemMaterialKey
        : (item) => String((item && (item.materialKey || item.material)) || "");

    const removesExtraPanels = (applicationState.current.extraPanels || []).some(
      (panel) => __itemMaterialKey(panel) === k,
    );
    const removesIndexedPanels =
      (applicationState.current.cart || []).some((it) => __itemMaterialKey(it) === k) ||
      removesExtraPanels;
    if (removesIndexedPanels) {
      grainData.clearAllGrainAssignments();
    }

    applicationState.current.cart =
      __plan && __plan.nextState
        ? __plan.nextState.cart
        : (applicationState.current.cart || []).filter((it) => __itemMaterialKey(it) !== k);
    applicationState.current.extraPanels =
      __plan && __plan.nextState
        ? __plan.nextState.extraPanels
        : (applicationState.current.extraPanels || []).filter(
            (it) => __itemMaterialKey(it) !== k,
          );
    applicationState.current.materialBatches =
      __plan && __plan.nextState
        ? __plan.nextState.materialBatches
        : (applicationState.current.materialBatches || []).filter((b) => b.key !== k);
    if (removesExtraPanels) {
      try {
        extraEditor.resetExtraForm();
      } catch (_) {
        panelEditSession.extraEditIndex = null;
      }
    }
    const hasAnyMaterialsLeft =
      __plan && typeof __plan.hasAnyMaterialsLeft !== "undefined"
        ? !!__plan.hasAnyMaterialsLeft
        : (applicationState.current.materialBatches || []).length > 0;

    if (
      (__plan && __plan.shouldSetActiveMaterial) ||
      applicationState.current.activeMaterialKey === k
    ) {
      const nextKey =
        __plan && __plan.nextActiveMaterialKey != null
          ? __plan.nextActiveMaterialKey
          : ((applicationState.current.materialBatches || [])[0] || {}).key || null;
      setActiveMaterial(nextKey || null);
      panelList.renderCart();
      extraEditor.renderExtraPanels();
      extraPreview.drawExtraPreview();
      materialSelectionView.updateButtons();
      feedback.updateWizardBanner();
      if (typeof overviewOverlay.renderOverviewSafe === "function")
        overviewOverlay.renderOverviewSafe();
      else if (typeof overviewOverlay.renderOverview === "function")
        overviewOverlay.renderOverview();
      feedback.scheduleDraftSave();
    } else {
      materialSelectionView.renderMaterialBatches();
      panelList.renderCart();
      extraEditor.renderExtraPanels();
      extraPreview.drawExtraPreview();
      materialSelectionView.updateButtons();
      feedback.updateWizardBanner();
      if (typeof overviewOverlay.renderOverviewSafe === "function")
        overviewOverlay.renderOverviewSafe();
      else if (typeof overviewOverlay.renderOverview === "function")
        overviewOverlay.renderOverview();
      feedback.scheduleDraftSave();
    }

    if (!hasAnyMaterialsLeft) {
      applicationState.current.activeMaterialKey = null;
      applicationState.current.material = null;
      selectionState.update({ materialKey: null });
      selectionState.update({ materialName: null });
      window.__forcePanelBootstrap = true;
      const __emptyReset =
        ToolAPanelBootstrapMutations &&
        typeof ToolAPanelBootstrapMutations.getNoMaterialsResetState === "function"
          ? ToolAPanelBootstrapMutations.getNoMaterialsResetState({
              selection: applicationState.current.selection,
              clampInt: formatting.clampInt,
            })
          : null;
      const __renderStep2MaterialSummarySafe =
        typeof materialSelectionView.renderMaterialBatchesStep2 === "function"
          ? materialSelectionView.renderMaterialBatchesStep2
          : null;
      const __renderMaterialBatchesSafe =
        typeof materialSelectionView.renderMaterialBatches === "function"
          ? materialSelectionView.renderMaterialBatches
          : null;
      const __renderCartSafe =
        typeof panelList.renderCart === "function" ? panelList.renderCart : null;
      const __renderExtraPanelsSafe =
        typeof extraEditor.renderExtraPanels === "function"
          ? extraEditor.renderExtraPanels
          : null;
      const __drawPreviewSafe =
        typeof panelPreview.draw === "function" ? panelPreview.draw : null;
      const __drawExtraPreviewSafe =
        typeof extraPreview.drawExtraPreview === "function"
          ? extraPreview.drawExtraPreview
          : null;
      const __showStepSafe =
        typeof wizardNavigation.showStep === "function"
          ? wizardNavigation.showStep
          : window && typeof window.__showWizardStep === "function"
            ? window.__showWizardStep
            : null;
      if (typeof __renderMaterialBatchesSafe === "function") __renderMaterialBatchesSafe();
      if (
        ToolAPanelBootstrapApply &&
        typeof ToolAPanelBootstrapApply.applyNoMaterialsReset === "function"
      ) {
        ToolAPanelBootstrapApply.applyNoMaterialsReset({
          reset: __emptyReset,
          state: applicationState.current,
          selectionCommands: selectionState,
          typeSel: panelElements.typeSel,
          sizeSel: panelElements.sizeSel,
          qty: panelElements.qty,
          extTop: panelElements.extTop,
          extBot: panelElements.extBot,
          addBtn: panelElements.addBtn,
          renderStep2MaterialSummary: __renderStep2MaterialSummarySafe,
          renderMaterialBatches: __renderMaterialBatchesSafe,
          renderMaterialBatchesStep2:
            typeof materialSelectionView.renderMaterialBatchesStep2 === "function"
              ? materialSelectionView.renderMaterialBatchesStep2
              : null,
          renderCart: __renderCartSafe,
          renderExtraPanels: __renderExtraPanelsSafe,
          drawPreview: __drawPreviewSafe,
          drawExtraPreview: __drawExtraPreviewSafe,
          showStep: __showStepSafe,
          setStep:
            typeof wizardNavigation.setStep === "function" ? wizardNavigation.setStep : null,
          renderFooterForStep:
            typeof wizardNavigation.renderFooterForStep === "function"
              ? wizardNavigation.renderFooterForStep
              : null,
          updateButtons:
            typeof materialSelectionView.updateButtons === "function"
              ? materialSelectionView.updateButtons
              : null,
          updateWizardBanner:
            typeof feedback.updateWizardBanner === "function"
              ? feedback.updateWizardBanner
              : null,
        });
      } else {
        {
          const __sel =
            __emptyReset && __emptyReset.selection
              ? __emptyReset.selection
              : {
                  type: null,
                  templateId: null,
                  qty: 1,
                  extTop: 0,
                  extBot: 0,
                  customLabel: "",
                };
          selectionState.update({ type: __sel.type });
          selectionState.update({ templateId: __sel.templateId });
          selectionState.update({ qty: __sel.qty });
          selectionState.update({ extTop: __sel.extTop });
          selectionState.update({ extBot: __sel.extBot });
          selectionState.update({ customLabel: __sel.customLabel });
        }
        if (panelElements.typeSel) {
          panelElements.typeSel.value =
            __emptyReset &&
            __emptyReset.ui &&
            typeof __emptyReset.ui.typeValue !== "undefined"
              ? __emptyReset.ui.typeValue
              : "";
          if (typeof panelElements.typeSel.__appleSync === "function")
            panelElements.typeSel.__appleSync();
        }
        if (panelElements.sizeSel) {
          panelElements.sizeSel.innerHTML =
            __emptyReset && __emptyReset.ui && __emptyReset.ui.sizePlaceholder
              ? __emptyReset.ui.sizePlaceholder
              : '<option value="">— Kies maat —</option>';
          panelElements.sizeSel.value =
            __emptyReset &&
            __emptyReset.ui &&
            typeof __emptyReset.ui.sizeValue !== "undefined"
              ? __emptyReset.ui.sizeValue
              : "";
          if (typeof panelElements.sizeSel.__appleSync === "function")
            panelElements.sizeSel.__appleSync();
        }
        if (panelElements.qty)
          panelElements.qty.value =
            __emptyReset && __emptyReset.ui && typeof __emptyReset.ui.qty !== "undefined"
              ? __emptyReset.ui.qty
              : 1;
        if (panelElements.extTop)
          panelElements.extTop.value =
            __emptyReset && __emptyReset.ui && typeof __emptyReset.ui.extTop !== "undefined"
              ? __emptyReset.ui.extTop
              : 0;
        if (panelElements.extBot)
          panelElements.extBot.value =
            __emptyReset && __emptyReset.ui && typeof __emptyReset.ui.extBot !== "undefined"
              ? __emptyReset.ui.extBot
              : 0;
        if (panelElements.addBtn)
          panelElements.addBtn.disabled = !(__emptyReset && __emptyReset.ui
            ? __emptyReset.ui.addEnabled
            : false);
        if (typeof __renderStep2MaterialSummarySafe === "function")
          __renderStep2MaterialSummarySafe();
        if (typeof __renderMaterialBatchesSafe === "function") __renderMaterialBatchesSafe();
        if (typeof __renderCartSafe === "function") __renderCartSafe();
        if (typeof __renderExtraPanelsSafe === "function") __renderExtraPanelsSafe();
        if (typeof __drawPreviewSafe === "function") __drawPreviewSafe();
        if (typeof __drawExtraPreviewSafe === "function") __drawExtraPreviewSafe();
        if (typeof __showStepSafe === "function") __showStepSafe("material");
      }
    }
    return (
      !(applicationState.current.materialBatches || []).some(
        (batch) => String(batch?.key || "") === k,
      ) &&
      !(applicationState.current.cart || []).some(
        (item) => String(item?.materialKey || "") === k,
      ) &&
      !(applicationState.current.extraPanels || []).some(
        (panel) => String(panel?.materialKey || "") === k,
      )
    );
  }

  function showRemoveMaterialDialog(total, onConfirm) {
    {
      const overlay = document.getElementById("removeMaterialOverlay");
      const confirmBtn = document.getElementById("removeMaterialConfirmBtn");
      const keepBtn = document.getElementById("removeMaterialKeepBtn");
      const bodyEl = document.getElementById("removeMaterialBody");
      if (!overlay || !confirmBtn || !keepBtn || !bodyEl) {
        const ok = confirm(`Dit materiaal heeft ${total} paneel(en). Ook verwijderen?`);
        if (ok && typeof onConfirm === "function") onConfirm();
        return;
      }
      bodyEl.textContent = `Dit materiaal heeft ${total} paneel(en). Als je dit materiaal verwijdert, verwijderen we ook alle gekoppelde panelen uit de lijst.`;
      overlay.__removeMaterialOnConfirm = typeof onConfirm === "function" ? onConfirm : null;
      overlay.style.display = "flex";
      requestAnimationFrame(() => {
        overlay.classList.add("isOpen");
        try {
          confirmBtn.focus();
        } catch (_) {
          ToolAErrors.recover("tool.a.runtime.modules.material.batches.js.1", _, [
            "NotSupportedError",
            "InvalidStateError",
          ]);
        }
      });
      if (!confirmBtn.__bound) {
        confirmBtn.__bound = true;
        confirmBtn.addEventListener("click", () => {
          const cb = overlay.__removeMaterialOnConfirm || null;
          overlay.__removeMaterialOnConfirm = null;
          closeRemoveMaterialDialog();
          if (typeof cb === "function") cb();
        });
      }
      if (!keepBtn.__bound) {
        keepBtn.__bound = true;
        keepBtn.addEventListener("click", () => closeRemoveMaterialDialog());
      }
      if (!overlay.__boundBackdrop) {
        overlay.__boundBackdrop = true;
        overlay.addEventListener("click", (ev) => {
          if (ev.target === overlay) closeRemoveMaterialDialog();
        });
      }
      if (!overlay.__boundEsc) {
        overlay.__boundEsc = true;
        document.addEventListener("keydown", (ev) => {
          if (ev.key === "Escape" && overlay.style.display !== "none")
            closeRemoveMaterialDialog();
        });
      }
    }
  }

  function closeRemoveMaterialDialog() {
    {
      const overlay = document.getElementById("removeMaterialOverlay");
      if (!overlay) return;
      overlay.classList.remove("isOpen");
      setTimeout(() => {
        overlay.style.display = "none";
        overlay.__removeMaterialOnConfirm = null;
      }, 120);
    }
  }

  function handleRemoveMaterialClick(ev, el) {
    if (ev) {
      ev.preventDefault();
      ev.stopPropagation();
    }
    {
      const rm = String((el && el.getAttribute && el.getAttribute("data-mrm")) || "");
      if (!rm) return false;
      try {
        if (ToolAPanelsEntry && typeof ToolAPanelsEntry.removeMaterial === "function") {
          ToolAPanelsEntry.removeMaterial(rm);
        } else {
          removeMaterialBatch(rm);
        }
      } catch (_) {
        removeMaterialBatch(rm);
      }
    }
    return false;
  }

  function directRemoveMaterialClick(el) {
    {
      const rm = String((el && el.getAttribute && el.getAttribute("data-mrm")) || "");
      if (!rm) return false;
      try {
        removeMaterialBatch(rm);
      } catch (err) {
        console.warn("REMOVE_MATERIAL_DIRECT_FAIL", err);
      }
    }
    return false;
  }

  function removeMaterialBatch(key) {
    configurationState.ensureStateShape();
    const k = String(key || "");
    const cartCnt = (applicationState.current.cart || []).filter(
      (it) => String(it.materialKey || "") === k,
    ).length;
    const extraCnt = (applicationState.current.extraPanels || []).filter(
      (it) => String(it.materialKey || "") === k,
    ).length;
    const total = cartCnt + extraCnt;

    if (total > 0) {
      showRemoveMaterialDialog(total, () => _removeMaterialBatchConfirmed(k));
      return;
    }
    _removeMaterialBatchConfirmed(k);
  }

  function clearAllMaterials() {
    configurationState.ensureStateShape();
    applicationState.current.materialBatches = [];
    applicationState.current.activeMaterialKey = null;
    applicationState.current.material = null;
    materialSelectionView.renderMaterialBatches();
    materialSelectionView.updateButtons();
    feedback.updateWizardBanner();
    feedback.scheduleDraftSave();
  }

  function setMaterial(mat) {
    if (!mat) {
      clearAllMaterials();
      document.dispatchEvent(new CustomEvent("adzaagt-material-selection-updated"));
      return;
    }
    addMaterialBatch(mat);
  }

  function mount() {
    __toolAMaterialRemovalTransaction = Object.freeze({
      BUILD: REVISION,
      removeConfirmed(key) {
        return _removeMaterialBatchConfirmed(key) === true;
      },
    });
    try {
      Object.defineProperty(window, "ToolAMaterialRemovalTransaction", {
        value: __toolAMaterialRemovalTransaction,
        writable: false,
        configurable: false,
        enumerable: false,
      });
    } catch (_) {
      if (!window.ToolAMaterialRemovalTransaction)
        window.ToolAMaterialRemovalTransaction = __toolAMaterialRemovalTransaction;
    }
    if (!removeHandlerBound) {
      removeHandlerBound = true;
      document.addEventListener(
        "click",
        function (ev) {
          try {
            const t =
              ev && ev.target && ev.target.closest ? ev.target.closest("[data-mrm]") : null;
            if (!t) return;
            ev.preventDefault();
            ev.stopPropagation();
            const rm = String(t.getAttribute("data-mrm") || "");
            if (!rm) return;
            removeMaterialBatch(rm);
          } catch (err) {
            console.warn("REMOVE_MATERIAL_DELEGATED_FAIL", err);
          }
        },
        true,
      );
    }
    window.removeMaterialBatch = removeMaterialBatch;
    window.setMaterial = setMaterial;
  }

  function mount2() {
    if (panelElements.grainToggle) {
      panelElements.grainToggle.addEventListener("change", () => {
        // Toggle is per materiaalbatch; zonder materiaal is hij disabled, maar defensief:
        if (panelElements.grainToggle.disabled) return;
        const next = !!panelElements.grainToggle.checked;
        if (applicationState.current.grainEnabled && !next) {
          const ok = confirm(
            "Weet je zeker dat je nerfrichting wilt uitzetten?\n\nPanelen kunnen gedraaid worden waardoor houtnerf niet meer overeenkomt; kleur/structuur kan zichtbaar afwijken.",
          );
          if (!ok) {
            panelElements.grainToggle.checked = true;
            return;
          }
        }
        applicationState.current.grainEnabled = next;
        // Persist per active material so the user's choice is not lost when switching steps/materials
        {
          const b = (applicationState.current.materialBatches || []).find(
            (x) => x.key === applicationState.current.activeMaterialKey,
          );
          if (b) b.grainEnabled = next;
        }
        feedback.scheduleDraftSave();
        if (panelElements.grainToggleLabel)
          panelElements.grainToggleLabel.textContent = applicationState.current.grainEnabled
            ? "Aan (panelen worden niet gedraaid)"
            : "Uit (panelen mogen draaien)";
        if (panelElements.grainWarn)
          panelElements.grainWarn.style.display = applicationState.current.grainEnabled
            ? "none"
            : "";
        materialSelectionView.updateButtons();
      });
    }
  }

  return Object.freeze({
    setMaterial,
    setActiveMaterial,
    removeMaterialBatch,
    _removeMaterialBatchConfirmed,
    showRemoveMaterialDialog,
    closeRemoveMaterialDialog,
    mount,
    mount2,
  });
}
