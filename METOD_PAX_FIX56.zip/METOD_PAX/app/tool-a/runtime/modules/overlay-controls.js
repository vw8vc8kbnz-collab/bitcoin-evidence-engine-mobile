/** overlay-controls: one runtime owner with explicit, immutable dependency ports. */
export function createOverlayControls({ foundation } = {}) {
  function openOverlay(el) {
    if (!el) return;
    {
      const owner = foundation.current;
      if (owner && typeof owner.openOverlay === "function" && owner.openOverlay(el)) return;
    }
    el.style.display = "flex";
    document.body.style.overflow = "hidden";
  }

  function closeOverlay(el) {
    if (!el) return;
    {
      const owner = foundation.current;
      if (owner && typeof owner.closeOverlay === "function" && owner.closeOverlay(el)) return;
    }
    el.style.display = "none";
    document.body.style.overflow = "";
  }

  function closePriceOverlay() {
    {
      const owner = foundation.current;
      if (owner && typeof owner.closeCheckoutReview === "function")
        return owner.closeCheckoutReview();
    }
    return false;
  }

  return Object.freeze({
    closeOverlay,
    closePriceOverlay,
    openOverlay,
  });
}
