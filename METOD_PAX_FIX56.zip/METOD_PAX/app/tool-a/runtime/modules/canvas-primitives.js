/** canvas-primitives: one runtime owner with explicit, immutable dependency ports. */
export function createCanvasPrimitives({} = {}) {
  function roundRect(ctx, x, y, w, h, r) {
    const ww = Number.isFinite(w) ? w : 0;
    const hh = Number.isFinite(h) ? h : 0;
    if (ww <= 0 || hh <= 0) {
      ctx.beginPath();
      return;
    }
    const rr = Math.max(0, Math.min(Number(r) || 0, ww / 2, hh / 2));
    ctx.beginPath();
    if (rr <= 0) {
      ctx.rect(x, y, ww, hh);
      return;
    }
    ctx.moveTo(x + rr, y);
    ctx.arcTo(x + ww, y, x + ww, y + hh, rr);
    ctx.arcTo(x + ww, y + hh, x, y + hh, rr);
    ctx.arcTo(x, y + hh, x, y, rr);
    ctx.arcTo(x, y, x + ww, y, rr);
    ctx.closePath();
  }

  return Object.freeze({
    roundRect,
  });
}
