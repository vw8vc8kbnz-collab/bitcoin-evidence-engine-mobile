/** view-refresh: one runtime owner with explicit, immutable dependency ports. */
export function createViewRefresh({} = {}) {
  let handlers;
  let active;

  function bind(views) {
    if (handlers) throw new Error("View notifications are already connected");
    const names = ["extraPanels", "overview", "grainEligible", "grainWidths"];
    if (!names.every((name) => typeof views?.[name] === "function")) {
      throw new TypeError("All view notification handlers are required");
    }
    handlers = Object.freeze({
      extraPanels: views.extraPanels,
      overview: views.overview,
      grainEligible: views.grainEligible,
      grainWidths: views.grainWidths,
    });
    active = new Set();
  }

  function refresh(name) {
    if (!handlers) throw new Error("View notifications are not connected");
    // A renderer may complete the same refresh via a synchronous nested hook.
    // It reads current state, so a second invocation on the same stack is redundant.
    if (active.has(name)) return;
    active.add(name);
    try {
      handlers[name]();
    } finally {
      active.delete(name);
    }
  }

  function extraPanels() {
    refresh("extraPanels");
  }

  function overview() {
    refresh("overview");
  }

  function grainEligible() {
    refresh("grainEligible");
  }

  function grainWidths() {
    refresh("grainWidths");
  }

  return Object.freeze({
    overview,
    extraPanels,
    grainWidths,
    grainEligible,
    bind,
  });
}
