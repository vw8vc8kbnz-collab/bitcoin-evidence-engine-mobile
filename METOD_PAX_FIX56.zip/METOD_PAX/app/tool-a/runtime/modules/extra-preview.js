import { ToolAExtraPanelViewState } from "../../domain/extra-panel-view-state.js";
import { ToolAMaterialSwatchRenderer } from "../../domain/material-swatch-renderer.js";
/** extra-preview: one runtime owner with explicit, immutable dependency ports. */
export function createExtraPreview({
  applicationState,
  canvasPrimitives,
  edgeValues,
  panelElements,
} = {}) {
  function extraPanelMiniSvg(w, h, edgeVal) {
    const m = edgeValues.edgeMaskFromValue(edgeVal);
    const W = 44,
      H = 30,
      pad = 3;
    let rw = W - 2 * pad,
      rh = H - 2 * pad;
    const ratio = w > 0 && h > 0 ? w / h : 1;
    if (ratio >= 1) {
      rh = rw / ratio;
    } else {
      rw = rh * ratio;
    }
    const x = (W - rw) / 2;
    const y = (H - rh) / 2;
    const stroke = "rgba(16,32,24,.35)";
    const edge = "rgba(58,61,64,.95)";
    const sw = 1.2,
      ew = 2.6;
    const line = (x1, y1, x2, y2) =>
      `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${edge}" stroke-width="${ew}"/>`;
    let edgeLines = "";
    if (m.top) edgeLines += line(x, y, x + rw, y);
    if (m.right) edgeLines += line(x + rw, y, x + rw, y + rh);
    if (m.bottom) edgeLines += line(x, y + rh, x + rw, y + rh);
    if (m.left) edgeLines += line(x, y, x, y + rh);
    return (
      `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg">` +
      `<rect x="${x.toFixed(2)}" y="${y.toFixed(2)}" width="${rw.toFixed(2)}" height="${rh.toFixed(2)}" fill="rgba(255,255,255,.0)" stroke="${stroke}" stroke-width="${sw}" rx="2"/>` +
      `${edgeLines}</svg>`
    );
  }

  function _setExtraEdgeLabel(checkboxEl, labelText) {
    if (!checkboxEl) return;
    const label = checkboxEl.closest("label");
    if (!label) return;
    // In the premium overlay we render a <span> for the label.
    // The legacy updater used a trailing text node, which caused duplicated
    // labels like "BovenBoven". Prefer updating the span when present.
    const span = label.querySelector(".edgeLbl");
    if (span) {
      span.textContent = labelText;
      return;
    }

    // Legacy fallback: ensure there's a trailing text node we can set.
    const nodes = Array.from(label.childNodes);
    let tnode = null;
    for (let i = nodes.length - 1; i >= 0; i--) {
      if (nodes[i].nodeType === Node.TEXT_NODE) {
        tnode = nodes[i];
        break;
      }
    }
    if (!tnode) {
      tnode = document.createTextNode("");
      label.appendChild(tnode);
    }
    tnode.nodeValue = " " + labelText;
  }

  function updateExtraEdgeLabels() {
    const w = Number(panelElements.extraW && panelElements.extraW.value);
    const h = Number(panelElements.extraH && panelElements.extraH.value);
    const hasDims = Number.isFinite(w) && Number.isFinite(h) && w > 0 && h > 0;
    const isSquare = hasDims && Math.abs(w - h) < 1;

    if (!hasDims || isSquare) {
      _setExtraEdgeLabel(panelElements.extraEdgeTop, "Boven");
      _setExtraEdgeLabel(panelElements.extraEdgeBottom, "Onder");
      _setExtraEdgeLabel(panelElements.extraEdgeLeft, "Links");
      _setExtraEdgeLabel(panelElements.extraEdgeRight, "Rechts");
      return;
    }

    const longIsLR = h > w; // staand
    const topTxt = longIsLR ? "Korte zijde boven" : "Lange zijde boven";
    const bottomTxt = longIsLR ? "Korte zijde onder" : "Lange zijde onder";
    const leftTxt = longIsLR ? "Lange zijde links" : "Korte zijde links";
    const rightTxt = longIsLR ? "Lange zijde rechts" : "Korte zijde rechts";

    _setExtraEdgeLabel(panelElements.extraEdgeTop, topTxt);
    _setExtraEdgeLabel(panelElements.extraEdgeBottom, bottomTxt);
    _setExtraEdgeLabel(panelElements.extraEdgeLeft, leftTxt);
    _setExtraEdgeLabel(panelElements.extraEdgeRight, rightTxt);
  }

  function drawExtraPreview() {
    if (!panelElements.extraPreviewCanvas) return;
    const ctx = panelElements.extraPreviewCanvas.getContext("2d");

    // responsive + crisp canvas sizing
    const dpr = window.devicePixelRatio || 1;
    const rect = panelElements.extraPreviewCanvas.getBoundingClientRect();
    const cssW = Math.max(240, Math.round(rect.width || 0));
    const cssH = Math.max(180, Math.round(rect.height || 0));
    const pxW = Math.max(1, Math.round(cssW * dpr));
    const pxH = Math.max(1, Math.round(cssH * dpr));
    if (
      panelElements.extraPreviewCanvas.width !== pxW ||
      panelElements.extraPreviewCanvas.height !== pxH
    ) {
      panelElements.extraPreviewCanvas.width = pxW;
      panelElements.extraPreviewCanvas.height = pxH;
    }
    // Draw in CSS pixels
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    updateExtraEdgeLabels();
    const edgeVal = panelElements.extraEdge.value;
    let previewVm = null;
    try {
      if (
        ToolAExtraPanelViewState &&
        typeof ToolAExtraPanelViewState.getPreviewSnapshot === "function"
      ) {
        previewVm = ToolAExtraPanelViewState.getPreviewSnapshot({
          width: panelElements.extraW ? panelElements.extraW.value : "",
          height: panelElements.extraH ? panelElements.extraH.value : "",
          edge: edgeVal,
          emptyHint: "Vul breedte en hoogte in om preview te zien.",
        });
      }
    } catch (_) {
      previewVm = null;
    }
    const w = Number(previewVm && previewVm.width);
    const h = Number(previewVm && previewVm.height);
    ctx.clearRect(0, 0, cssW, cssH);

    // background
    ctx.fillStyle = "rgba(0,0,0,0)";
    ctx.fillRect(0, 0, cssW, cssH);

    // if no dims, show hint
    if (!previewVm || !previewVm.hasDimensions) {
      ctx.fillStyle = "rgba(16,32,24,.55)";
      ctx.font = "14px system-ui, -apple-system, Segoe UI, Roboto, sans-serif";
      ctx.fillText(
        String(
          (previewVm && previewVm.emptyHint) || "Vul breedte en hoogte in om preview te zien.",
        ),
        14,
        28,
      );
      return;
    }

    // fit rectangle
    const pad = 24;
    const maxW = cssW - 2 * pad;
    const maxH = cssH - 2 * pad;
    let rw = maxW,
      rh = maxH;
    const ratio = w / h;
    if (ratio >= 1) {
      rh = rw / ratio;
      if (rh > maxH) {
        rh = maxH;
        rw = rh * ratio;
      }
    } else {
      rw = rh * ratio;
      if (rw > maxW) {
        rw = maxW;
        rh = rw / ratio;
      }
    }
    const x = (cssW - rw) / 2;
    const y = (cssH - rh) / 2;

    // overige-panelenpreview gebruikt exact het gekozen materiaal.
    // The swatch is never tiled and is clipped to this real local panel rectangle.
    const __extraMaterialKey = String(
      (panelElements.extraMat && panelElements.extraMat.value) ||
        applicationState.current.activeMaterialKey ||
        "",
    ).trim();
    try {
      if (ToolAMaterialSwatchRenderer) {
        ToolAMaterialSwatchRenderer.drawCanvasMaterial(
          ctx,
          { x, y, w: rw, h: rh },
          {
            materialKey: __extraMaterialKey,
            panel: { localGrainAxis: "V" },
            radius: 10,
            onReady: drawExtraPreview,
          },
        );
      } else {
        ctx.fillStyle = "rgba(236,236,232,.94)";
        canvasPrimitives.roundRect(ctx, x, y, rw, rh, 10);
        ctx.fill();
      }
    } catch (_e) {
      ctx.fillStyle = "rgba(236,236,232,.94)";
      canvasPrimitives.roundRect(ctx, x, y, rw, rh, 10);
      ctx.fill();
    }
    ctx.strokeStyle = "rgba(16,32,24,.35)";
    ctx.lineWidth = 2;
    canvasPrimitives.roundRect(ctx, x, y, rw, rh, 10);
    ctx.stroke();

    // Keep only the explicit local grain arrow above the real material image.
    // Do not add synthetic/repeating wood lines.
    ctx.save();
    canvasPrimitives.roundRect(ctx, x + 1, y + 1, rw - 2, rh - 2, 9);
    ctx.clip();
    const cx = x + rw / 2;
    const topA = y + Math.max(18, rh * 0.12);
    const botA = y + rh - Math.max(18, rh * 0.12);
    ctx.strokeStyle = "rgba(47,110,72,.88)";
    ctx.fillStyle = "rgba(47,110,72,.88)";
    ctx.lineWidth = 2.6;
    ctx.beginPath();
    ctx.moveTo(cx, botA);
    ctx.lineTo(cx, topA);
    ctx.stroke();
    const ah = 10;
    const aw = 6;
    // arrow head top
    ctx.beginPath();
    ctx.moveTo(cx, topA - ah);
    ctx.lineTo(cx - aw, topA);
    ctx.lineTo(cx + aw, topA);
    ctx.closePath();
    ctx.fill();
    // arrow head bottom
    ctx.beginPath();
    ctx.moveTo(cx, botA + ah);
    ctx.lineTo(cx - aw, botA);
    ctx.lineTo(cx + aw, botA);
    ctx.closePath();
    ctx.fill();
    ctx.restore();

    // label onderin, duidelijk maar rustig
    const grainTag = "Nerfrichting";
    ctx.font = "12px system-ui, -apple-system, Segoe UI, Roboto, sans-serif";
    const grainW = ctx.measureText(grainTag).width + 22;
    const grainX = Math.max(x + 8, x + rw - grainW - 8);
    const grainY = y + rh - 28;
    ctx.fillStyle = "rgba(233,248,238,.96)";
    ctx.strokeStyle = "rgba(58,61,64,.20)";
    ctx.lineWidth = 1;
    canvasPrimitives.roundRect(ctx, grainX, grainY, grainW, 20, 10);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = "rgba(47,110,72,.94)";
    ctx.fillText(grainTag, grainX + 11, grainY + 14);

    // edge banding highlight
    const m =
      previewVm && previewVm.edgeMask ? previewVm.edgeMask : edgeValues.edgeMaskFromValue(edgeVal);
    ctx.strokeStyle = "rgba(58,61,64,.95)";
    ctx.lineWidth = 6;
    ctx.lineCap = "round";
    if (m.top) {
      ctx.beginPath();
      ctx.moveTo(x + 6, y);
      ctx.lineTo(x + rw - 6, y);
      ctx.stroke();
    }
    if (m.right) {
      ctx.beginPath();
      ctx.moveTo(x + rw, y + 6);
      ctx.lineTo(x + rw, y + rh - 6);
      ctx.stroke();
    }
    if (m.bottom) {
      ctx.beginPath();
      ctx.moveTo(x + 6, y + rh);
      ctx.lineTo(x + rw - 6, y + rh);
      ctx.stroke();
    }
    if (m.left) {
      ctx.beginPath();
      ctx.moveTo(x, y + 6);
      ctx.lineTo(x, y + rh - 6);
      ctx.stroke();
    }

    // dimensions text
    ctx.fillStyle = "rgba(16,32,24,.75)";
    ctx.font = "13px system-ui, -apple-system, Segoe UI, Roboto, sans-serif";
    const txt = `${Math.round(w)} × ${Math.round(h)} mm`;
    ctx.fillText(txt, x + 10, y + 22);
  }

  return Object.freeze({
    drawExtraPreview,
    extraPanelMiniSvg,
    updateExtraEdgeLabels,
  });
}
