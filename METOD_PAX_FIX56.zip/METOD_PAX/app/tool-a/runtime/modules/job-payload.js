import { ToolAGrainValidation } from "../../domain/grain-validation.js";
/** job-payload: one runtime owner with explicit, immutable dependency ports. */
export function createJobPayload({
  applicationState,
  customerSnapshot,
  dxfExport,
  foundation,
  grainAssignments,
  jobEstimates,
  priceBar,
  templateExport,
} = {}) {
  function compactDxfPayload(dxfParts) {
    const textToBlobId = new Map();
    const dxfBlobs = {};
    const dxfPartRefs = {};
    let seq = 0;
    for (const [partId, raw] of Object.entries(dxfParts || {})) {
      const txt = String(raw || "");
      let blobId = textToBlobId.get(txt);
      if (!blobId) {
        blobId = "g" + String(++seq).padStart(4, "0");
        textToBlobId.set(txt, blobId);
        dxfBlobs[blobId] = txt;
      }
      dxfPartRefs[String(partId)] = blobId;
    }
    return { dxfBlobs, dxfPartRefs };
  }

  function edgeMaskFromValue(edgeVal) {
    const v = String(edgeVal || "")
      .trim()
      .toLowerCase();
    if (!v || v === "none" || v === "0" || v === "false") {
      return { top: 0, right: 0, bottom: 0, left: 0 };
    }
    if (v === "all" || v === "1" || v === "true") {
      return { top: 1, right: 1, bottom: 1, left: 1 };
    }
    if (v === "lr") {
      return { top: 0, right: 1, bottom: 0, left: 1 };
    }
    if (v === "tb") {
      return { top: 1, right: 0, bottom: 1, left: 0 };
    }
    // Explicit bitmask like: t1r0b1l0
    const m = v.match(/t([01])\s*r([01])\s*b([01])\s*l([01])/);
    if (m) {
      return {
        top: m[1] === "1",
        right: m[2] === "1",
        bottom: m[3] === "1",
        left: m[4] === "1",
      };
    }
    return { top: 0, right: 0, bottom: 0, left: 0 };
  }

  function edgeHWFromEdgeVal(edgeVal) {
    const m = edgeMaskFromValue(edgeVal);
    return {
      H1: m.top ? 1 : 0,
      H2: m.bottom ? 1 : 0,
      W1: m.left ? 1 : 0,
      W2: m.right ? 1 : 0,
    };
  }

  async function buildJobPayload() {
    const rows = [];
    const dxfParts = {};
    const panelIntents = {};

    // Build globally unique production GrainGroup codes from the visual/order
    // state. Server validation deliberately treats a group id as job-global;
    // restarting at G001 for every material would falsely merge two groups.
    // Contract: Tool A is the only source of truth. Tool B must be able to respect group order deterministically.
    // We encode populated groups as G001, G002, ... across the complete job.
    const __grainValidation = ToolAGrainValidation;
    if (
      !__grainValidation ||
      typeof __grainValidation.buildProductionGroupCodeMap !== "function" ||
      typeof __grainValidation.productionGroupCode !== "function"
    ) {
      throw new Error("De nerfgroepvalidatie is niet geladen. Herlaad Tool A.");
    }
    const grainGroupCodeMap = __grainValidation.buildProductionGroupCodeMap(
      Array.isArray(applicationState.current?.grain?.groups)
        ? applicationState.current.grain.groups
        : [],
    );
    function productionGrainCode(materialKey, groupId, grainOrder) {
      if (!groupId) return "";
      const code = __grainValidation.productionGroupCode(grainGroupCodeMap, materialKey, groupId);
      if (!code)
        throw new Error(`Nerfgroep ${String(groupId)} hoort niet bij het geselecteerde materiaal.`);
      return code + (grainOrder ? ":" + String(grainOrder) : "");
    }

    // Per-materiaal nerf-instelling (V2 phase 2)
    const grainEnabledByMaterial = {};

    (applicationState.current.materialBatches || []).forEach((b) => {
      const k = String(b.key || "").trim();
      if (!k) return;
      grainEnabledByMaterial[k] = typeof b.grainEnabled === "boolean" ? b.grainEnabled : true;
    });

    function grainEnabledFor(materialCode) {
      const k = String(materialCode || "").trim();
      const v = grainEnabledByMaterial[k];
      return typeof v === "boolean" ? v : true;
    }

    // METOD cart items (already expanded qty=1 each)
    // IMPORTANT (contract): GrainGroups must export in the exact order as created/dragged in the nerf overlay.
    // We therefore iterate cart items in: group order (state.grain.groups order) -> member order (g.items order) -> remaining items.
    const orderedCartIdx = [];
    const usedCartIdx = new Set();
    {
      const groups = Array.isArray(applicationState.current?.grain?.groups)
        ? applicationState.current.grain.groups
        : [];
      for (const g of groups) {
        if (!g || !Array.isArray(g.items)) continue;
        for (const idx of g.items) {
          const n = Number(idx);
          if (!Number.isFinite(n)) continue;
          if (usedCartIdx.has(n)) continue;
          usedCartIdx.add(n);
          orderedCartIdx.push(n);
        }
      }
    }
    for (let i = 0; i < (applicationState.current.cart || []).length; i++) {
      if (!usedCartIdx.has(i)) orderedCartIdx.push(i);
    }
    const __orderedCartItems = orderedCartIdx
      .map((i) => (applicationState.current.cart || [])[i])
      .filter(Boolean);
    const __extraPanelItems = Array.isArray(applicationState.current.extraPanels)
      ? applicationState.current.extraPanels
      : [];
    const __payloadUnitTotal = Math.max(1, __orderedCartItems.length + __extraPanelItems.length);
    let __payloadUnitsDone = 0,
      __lastPayloadPct = 2;
    async function reportPreparedPayloadUnit(label) {
      __payloadUnitsDone++;
      const pct = Math.min(8, 2 + Math.round((__payloadUnitsDone / __payloadUnitTotal) * 6));
      priceBar.updatePriceBar({
        busy: true,
        progressPct: pct,
        progressLabel: label,
      });
      if (pct > __lastPayloadPct || __payloadUnitsDone === __payloadUnitTotal) {
        __lastPayloadPct = Math.max(__lastPayloadPct, pct);
        await templateExport.yieldPayloadProgressPaint();
      }
    }
    await templateExport.prewarmDxfSourcesForItems(__orderedCartItems);
    for (const cartIdx of orderedCartIdx) {
      const it = (applicationState.current.cart || [])[cartIdx];
      if (!it) continue;
      const partId = String(it.id)
        .replace(/[^A-Za-z0-9_\-]/g, "_")
        .slice(0, 80);
      const t = applicationState.current.templates.get(it.templateId);
      const baseLen = Number(t?.realH || it.realH || 0);
      const baseWid = Number(t?.realW || it.realW || 0);
      const len = baseLen + Number(it.extTop || 0) + Number(it.extBot || 0);
      const wid = baseWid;

      const materialCode = String(it.articleNumber || it.materialCode || "").trim();
      const grainMaterialKey = String(
        it.materialKey || it.materialCode || it.articleNumber || "",
      ).trim();
      const decorName = String(it.decorName || it.material || "").trim();
      const thickness = Number(it.thicknessMm || 18);

      const ge = grainEnabledFor(materialCode);

      rows.push({
        PartId: partId,
        PanelName:
          it.customName && String(it.customName).trim() ? String(it.customName).trim() : it.label,
        Qty: 1,
        LengthMm: Math.round(len * 10) / 10,
        WidthMm: Math.round(wid * 10) / 10,
        ThicknessMm: thickness,
        MaterialCode: materialCode,
        GrainGroup: ge ? productionGrainCode(grainMaterialKey, it.grainGroupId, it.grainOrder) : "",
        RotationAllowed: ge ? !!it.rotationAllowed : true,
        H1: 1,
        H2: 1,
        W1: 1,
        W2: 1,
        ArticleNumber: materialCode,
        DecorName: decorName,
        Note: "",
      });

      const dxf = await templateExport.buildDxfForMetodItem(it);
      if (!dxf || !t?.sourceName)
        throw new Error(
          "Het paneeltemplate ontbreekt. Herlaad de tool en voeg het paneel opnieuw toe.",
        );
      dxfParts[partId] = dxf;
      panelIntents[partId] = {
        kind: "template",
        sourceName: String(t.sourceName),
        hinge: String(it.hinge || "left"),
        extTopMm: Number(it.extTop || 0),
        extBottomMm: Number(it.extBot || 0),
      };
      await reportPreparedPayloadUnit(
        `Panelen voorbereiden ${__payloadUnitsDone + 1}/${__payloadUnitTotal}…`,
      );
    }
    // Overige panelen
    for (const p of __extraPanelItems) {
      const materialCode = String(p.articleNumber || p.materialCode || "").trim();
      const grainMaterialKey = String(
        p.materialKey || p.materialCode || p.articleNumber || "",
      ).trim();
      const decorName = String(p.decorName || p.material || "").trim();
      const thickness = Number(p.thicknessMm || 18);
      const ge = grainEnabledFor(materialCode);
      const assigns =
        typeof grainAssignments.ensureExtraAssignments === "function"
          ? grainAssignments.ensureExtraAssignments(p)
          : (() => {
              const qty = Math.max(1, Number(p.qty || 1));
              if (!Array.isArray(p.grainAssignments)) p.grainAssignments = [];
              while (p.grainAssignments.length < qty)
                p.grainAssignments.push({
                  grainGroupId: null,
                  grainOrder: null,
                });
              if (p.grainAssignments.length > qty)
                p.grainAssignments = p.grainAssignments.slice(0, qty);
              return p.grainAssignments;
            })();
      const grouped = assigns.map((a, rep) => ({ a, rep })).filter((x) => x.a && x.a.grainGroupId);

      for (const { a, rep } of grouped) {
        const grainCode = ge
          ? productionGrainCode(grainMaterialKey, a.grainGroupId, a.grainOrder)
          : "";
        const partId = String((p.id || "EX_" + Date.now() + Math.random()) + "_G" + rep)
          .replace(/[^A-Za-z0-9_\-]/g, "_")
          .slice(0, 80);
        rows.push({
          PartId: partId,
          PanelName: p.name || `Overig paneel ${p.w}x${p.h}`,
          Qty: 1,
          LengthMm: Number(p.h || 0),
          WidthMm: Number(p.w || 0),
          ThicknessMm: thickness,
          MaterialCode: materialCode,
          GrainGroup: grainCode,
          RotationAllowed: false,
          ...edgeHWFromEdgeVal(p.edge || ""),
          ArticleNumber: materialCode,
          DecorName: decorName,
          Note: "",
        });
        dxfParts[partId] = dxfExport.makeRectangleDxf(p.w, p.h);
        panelIntents[partId] = { kind: "free" };
      }

      const remQty = Math.max(0, Number(p.qty || 1) - grouped.length);
      if (remQty > 0) {
        const partId = String((p.id || "EX_" + Date.now() + Math.random()) + "_R")
          .replace(/[^A-Za-z0-9_\-]/g, "_")
          .slice(0, 80);
        rows.push({
          PartId: partId,
          PanelName: p.name || `Overig paneel ${p.w}x${p.h}`,
          Qty: remQty,
          LengthMm: Number(p.h || 0),
          WidthMm: Number(p.w || 0),
          ThicknessMm: thickness,
          MaterialCode: materialCode,
          GrainGroup: "",
          RotationAllowed: ge ? false : true,
          ...edgeHWFromEdgeVal(p.edge || ""),
          ArticleNumber: materialCode,
          DecorName: decorName,
          Note: "",
        });
        dxfParts[partId] = dxfExport.makeRectangleDxf(p.w, p.h);
        panelIntents[partId] = { kind: "free" };
      }
      await reportPreparedPayloadUnit(
        `Panelen voorbereiden ${__payloadUnitsDone + 1}/${__payloadUnitTotal}…`,
      );
    }
    const panelsCsv = jobEstimates.buildPanelsCsv(rows);

    // Pricing: include only used materials
    const mats = new Map();
    function addMat(code, decor, thickness) {
      if (!code) return;
      if (mats.has(code)) return;
      // Try to find material in catalog for sheet size and price
      const found = (window.MATERIAL_CATALOG || []).find(
        (m) => String(m.articleNumber || m.articleNo) === String(code),
      );
      const sheetW =
        found?.sheetSizeMm?.width ??
        found?.sheetWid ??
        found?.sheetW ??
        found?.sheetSizeMm?.w ??
        found?.sheetWid ??
        found?.sheetSizeMm?.width;
      const sheetH =
        found?.sheetSizeMm?.height ??
        found?.sheetLen ??
        found?.sheetH ??
        found?.sheetSizeMm?.h ??
        found?.sheetLen ??
        found?.sheetSizeMm?.height;
      const price =
        found?.purchasePricePerSheet ??
        found?.purchasePrice ??
        found?.purchasePricePerSheet ??
        found?.retailPriceWithoutTax ??
        0;
      mats.set(code, {
        materialCode: String(code),
        decorName: decor || found?.decorName || "",
        thicknessMm: Number(found?.thicknessMm ?? thickness ?? 18),
        sheetSizeMm: {
          width: Number(sheetW || 2800),
          height: Number(sheetH || 2070),
        },
        purchasePricePerSheet: Number(price || 0),
      });
    }
    for (const r of rows) {
      addMat(r.MaterialCode, r.DecorName, r.ThicknessMm);
    }

    const pricing = {
      pricingVersion: "v1",
      currency: "EUR",
      units: "mm",
      defaults: { sheetMarginMm: 7, nestingGapMm: 16, kerfMm: 13 },
      materials: Array.from(mats.values()),
      edgeBanding: {
        defaultLossPercent: 5.0,
        codes: [{ code: 1, name: "Kantenband", unit: "m", purchasePricePerUnit: 1.5 }],
      },
    };
    const preflightEstimate = jobEstimates.estimatePreflightFromRows(rows, mats, pricing);

    const jobJson = {
      createdAt: new Date().toISOString(),
      project: "METOD",
      grainEnabled: true,
      grainEnabledByMaterial: grainEnabledByMaterial,
      grainPolicy: "rotationAllowed=false when grainEnabled",
      sheetMarginMm: 7,
      nestingGapMm: 16,

      // Checkout (for stickers / admin / mobile QR page)
      rest_material: {
        carry_out: applicationState.current.checkout?.restCarry === true,
      },
      customer: customerSnapshot.customerForCurrentCalculation(),
      note: String(applicationState.current.checkout?.note || ""),
    };

    // Seal the review from the exact production rows and customer payload that
    // will be serialized for this optimizer run. This prevents later wizard,
    // autofill or material-library renders from changing the confirmation card.
    const __reviewSnapshot = foundation.current?.captureCheckoutCalculationSnapshot?.({
      state: applicationState.current,
      customer: jobJson.customer,
      productionRows: rows,
    });
    const __productionPanelCount = rows.reduce((sum, row) => sum + (Number(row?.Qty) || 1), 0);
    if (
      !__reviewSnapshot ||
      Number(__reviewSnapshot.panelCount || 0) !== __productionPanelCount ||
      !Array.isArray(__reviewSnapshot.materials) ||
      !__reviewSnapshot.materials.length ||
      !String(__reviewSnapshot.customer?.email || "").trim()
    ) {
      throw new Error(
        "De klant-, materiaal- en paneelcontrole kon niet veilig worden vastgezet. Herlaad de pagina en probeer opnieuw.",
      );
    }

    const __compactDxf = compactDxfPayload(dxfParts);
    return {
      panelsCsv,
      panelIntents,
      pricing,
      dxfBlobs: __compactDxf.dxfBlobs,
      dxfPartRefs: __compactDxf.dxfPartRefs,
      jobJson,
      preflightEstimate,
      payloadSchema: "FIX655_DXF_REF_V1",
    };
  }

  function initialize() {
    window.ensureExtraAssignments = grainAssignments.ensureExtraAssignments;
  }

  return Object.freeze({
    buildJobPayload,
    compactDxfPayload,
    edgeMaskFromValue,
    edgeHWFromEdgeVal,
    initialize,
  });
}
