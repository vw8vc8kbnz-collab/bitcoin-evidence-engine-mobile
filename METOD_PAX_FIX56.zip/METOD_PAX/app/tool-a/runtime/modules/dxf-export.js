import { ToolATemplateViewHelpers } from "../../domain/template-view-helpers.js";
/** dxf-export: one runtime owner with explicit, immutable dependency ports. */
export function createDxfExport({} = {}) {
  function dxfToPairs(text) {
    const lines = text.replace(/\r\n/g, "\n").replace(/\r/g, "\n").split("\n");
    const pairs = [];
    for (let i = 0; i < lines.length - 1; i += 2) {
      const code = lines[i].trim();
      const val = lines[i + 1];
      if (code === "") continue;
      pairs.push([code, val]);
    }
    return pairs;
  }

  function pairsToDxf(pairs) {
    return pairs.map(([c, v]) => String(c) + "\n" + String(v)).join("\n") + "\n";
  }

  function dxfBBox(pairs) {
    if (ToolATemplateViewHelpers && typeof ToolATemplateViewHelpers.dxfBBox === "function") {
      return ToolATemplateViewHelpers.dxfBBox(pairs);
    }

    let minX = Infinity,
      minY = Infinity,
      maxX = -Infinity,
      maxY = -Infinity;
    const xCodes = new Set(["10", "11", "12", "13", "14", "15", "16", "17", "18"]);
    const yCodes = new Set(["20", "21", "22", "23", "24", "25", "26", "27", "28"]);
    for (const [codeRaw, val] of pairs) {
      const code = String(codeRaw).trim();
      const v = parseFloat(val);
      if (Number.isNaN(v)) continue;
      if (xCodes.has(code)) {
        if (v < minX) minX = v;
        if (v > maxX) maxX = v;
      }
      if (yCodes.has(code)) {
        if (v < minY) minY = v;
        if (v > maxY) maxY = v;
      }
    }
    if (!isFinite(minX)) return { minX: 0, minY: 0, maxX: 0, maxY: 0 };
    return { minX, minY, maxX, maxY };
  }

  function setEntityLayer(pairs, startIdx, layerName) {
    // Entity starts at startIdx where pairs[startIdx] = ['0', <TYPE>]
    // Find next '8' before next '0'. If found, replace. Else insert after type line.
    let i = startIdx + 1;
    while (i < pairs.length) {
      const code = String(pairs[i][0]).trim();
      if (code === "0") break;
      if (code === "8") {
        pairs[i][1] = layerName;
        return;
      }
      i++;
    }
    pairs.splice(startIdx + 1, 0, ["8", layerName]);
  }

  function classifyAndRelayer(pairs) {
    for (let i = 0; i < pairs.length; i++) {
      if (String(pairs[i][0]).trim() !== "0") continue;
      const typ = String(pairs[i][1]).trim().toUpperCase();
      if (!typ) continue;
      if (["CIRCLE", "ARC"].includes(typ)) setEntityLayer(pairs, i, "DRILL");
      else if (
        [
          "LINE",
          "LWPOLYLINE",
          "POLYLINE",
          "VERTEX",
          "SEQEND",
          "INSERT",
          "BLOCK",
          "ENDBLK",
        ].includes(typ)
      ) {
        // We'll set LINE/LWPOLYLINE/POLYLINE to OUTLINE; leave block structures as-is
        if (["LINE", "LWPOLYLINE", "POLYLINE"].includes(typ)) setEntityLayer(pairs, i, "OUTLINE");
      }
    }
  }

  function mirrorX(pairs) {
    const helper = ToolATemplateViewHelpers;
    if (!helper || typeof helper.mirrorX !== "function") {
      throw new Error("DXF-spiegeling is niet beschikbaar. Herlaad de tool.");
    }
    return helper.mirrorX(pairs, dxfBBox);
  }

  function extendOutlineY(pairs, extTop, extBot) {
    extTop = Number(extTop || 0);
    extBot = Number(extBot || 0);
    if (!extTop && !extBot) return;

    const yCodes = new Set(["20", "21", "22", "23", "24", "25", "26", "27", "28"]);

    // v2 fix (extBot): Only operate inside the ENTITIES section.
    // Some DXF templates contain BLOCK definitions with far-away OUTLINE points
    // (e.g. construction geometry). If we include those points when computing
    // minY/maxY, bottom-extension may target the wrong "minY" and appear to do
    // nothing. Restricting to ENTITIES keeps extTop/extBot deterministic.
    function isEntitiesSectionStart(i) {
      return (
        String(pairs[i]?.[0] || "").trim() === "0" &&
        String(pairs[i]?.[1] || "")
          .trim()
          .toUpperCase() === "SECTION" &&
        String(pairs[i + 1]?.[0] || "").trim() === "2" &&
        String(pairs[i + 1]?.[1] || "")
          .trim()
          .toUpperCase() === "ENTITIES"
      );
    }

    function getEntityLayer(i) {
      for (let j = i + 1; j < pairs.length; j++) {
        const c = String(pairs[j][0]).trim();
        if (c === "0") break;
        if (c === "8") return String(pairs[j][1]).trim();
      }
      return "";
    }

    // First pass: find min/max Y of OUTLINE (VERTEX inherits POLYLINE layer)
    let minY = Infinity,
      maxY = -Infinity,
      hasOutline = false;
    const outlineYs = [];
    let polyLayer = "";
    let inEntities = false;
    for (let i = 0; i < pairs.length; i++) {
      if (isEntitiesSectionStart(i)) {
        inEntities = true;
        continue;
      }
      if (
        inEntities &&
        String(pairs[i][0]).trim() === "0" &&
        String(pairs[i][1]).trim().toUpperCase() === "ENDSEC"
      ) {
        inEntities = false;
        polyLayer = "";
        continue;
      }
      if (!inEntities) continue;
      if (String(pairs[i][0]).trim() !== "0") continue;
      const typ = String(pairs[i][1]).trim().toUpperCase();
      if (typ === "POLYLINE") polyLayer = getEntityLayer(i) || polyLayer;
      if (typ === "SEQEND") {
        polyLayer = "";
        continue;
      }
      if (!["LINE", "LWPOLYLINE", "VERTEX"].includes(typ)) continue;
      let layer = getEntityLayer(i);
      if (!layer && typ === "VERTEX") layer = polyLayer;
      if (layer !== "OUTLINE") continue;
      hasOutline = true;
      for (let j = i + 1; j < pairs.length && String(pairs[j][0]).trim() !== "0"; j++) {
        const c = String(pairs[j][0]).trim();
        if (!yCodes.has(c)) continue;
        const v = parseFloat(pairs[j][1]);
        if (Number.isNaN(v)) continue;
        outlineYs.push(v);
        if (v < minY) minY = v;
        if (v > maxY) maxY = v;
      }
    }
    // Robust extremes: pick dominant Y-level near min/max (avoids stray helper lines)
    if (hasOutline && outlineYs.length) {
      const counts = Object.create(null);
      for (const y of outlineYs) {
        const k = (Math.round(y * 100) / 100).toFixed(2); // 0.01mm buckets
        counts[k] = (counts[k] || 0) + 1;
      }
      const ysUnique = Object.keys(counts)
        .map((k) => ({ y: parseFloat(k), c: counts[k] }))
        .sort((a, b) => a.y - b.y);
      const windowMm = 2.0; // consider candidates within 2mm from extreme
      const minY0 = ysUnique[0].y;
      const bottomCands = ysUnique.filter((o) => o.y <= minY0 + windowMm);
      // Pick the most common Y-level near the bottom.
      // If tied:
      //  - when bottom extension is active, prefer the MOST extreme (lower Y) so the real bottom edge gets extended
      //  - otherwise, prefer the LESS extreme (higher Y) to avoid stray helper lines
      bottomCands.sort((a, b) => {
        const dc = b.c - a.c;
        if (dc) return dc;
        return extBot > 0 ? a.y - b.y : b.y - a.y;
      });
      minY = bottomCands[0].y;

      const maxY0 = ysUnique[ysUnique.length - 1].y;
      const topCands = ysUnique.filter((o) => o.y >= maxY0 - windowMm);
      // Pick the most common Y-level near the top.
      // If tied:
      //  - when top extension is active, prefer the MOST extreme (higher Y)
      //  - otherwise, prefer the LESS extreme (lower Y)
      topCands.sort((a, b) => {
        const dc = b.c - a.c;
        if (dc) return dc;
        return extTop > 0 ? b.y - a.y : a.y - b.y;
      });
      maxY = topCands[0].y;
    }
    if (!hasOutline) {
      const bb = dxfBBox(pairs);
      minY = bb.minY;
      maxY = bb.maxY;
    }
    if (!isFinite(minY) || !isFinite(maxY)) return;

    // Second pass: extend any OUTLINE coords close to the extremes.
    const eps = 0.75;
    polyLayer = "";
    inEntities = false;
    for (let i = 0; i < pairs.length; i++) {
      if (isEntitiesSectionStart(i)) {
        inEntities = true;
        continue;
      }
      if (
        inEntities &&
        String(pairs[i][0]).trim() === "0" &&
        String(pairs[i][1]).trim().toUpperCase() === "ENDSEC"
      ) {
        inEntities = false;
        polyLayer = "";
        continue;
      }
      if (!inEntities) continue;
      if (String(pairs[i][0]).trim() !== "0") continue;
      const typ = String(pairs[i][1]).trim().toUpperCase();
      if (typ === "POLYLINE") polyLayer = getEntityLayer(i) || polyLayer;
      if (typ === "SEQEND") {
        polyLayer = "";
        continue;
      }
      if (!["LINE", "LWPOLYLINE", "VERTEX"].includes(typ)) continue;
      let layer = getEntityLayer(i);
      if (!layer && typ === "VERTEX") layer = polyLayer;
      if (layer !== "OUTLINE") continue;

      for (let j = i + 1; j < pairs.length && String(pairs[j][0]).trim() !== "0"; j++) {
        const c = String(pairs[j][0]).trim();
        if (!yCodes.has(c)) continue;
        const v = parseFloat(pairs[j][1]);
        if (Number.isNaN(v)) continue;
        if (v >= maxY - eps) pairs[j][1] = String(v + extTop);
        else if (v <= minY + eps) pairs[j][1] = String(v - extBot);
      }
    }
  }

  function shiftEntitiesY(pairs, deltaY) {
    deltaY = Number(deltaY || 0);
    if (!deltaY) return;
    const yCodes = new Set(["20", "21", "22", "23", "24", "25", "26", "27", "28"]);
    let inEntities = false;
    for (let i = 0; i < pairs.length; i++) {
      const code = String(pairs[i][0]).trim();
      const val = String(pairs[i][1]).trim();
      if (code === "0" && val.toUpperCase() === "SECTION") {
        const c2 = String(pairs[i + 1]?.[0] || "").trim();
        const v2 = String(pairs[i + 1]?.[1] || "")
          .trim()
          .toUpperCase();
        inEntities = c2 === "2" && v2 === "ENTITIES";
      }
      if (!inEntities) continue;
      if (!yCodes.has(code)) continue;
      const v = parseFloat(pairs[i][1]);
      if (Number.isNaN(v)) continue;
      pairs[i][1] = String(v + deltaY);
    }
  }

  function makeRectangleDxf(widthMm, lengthMm) {
    const w = Number(widthMm),
      h = Number(lengthMm);
    return (
      [
        "0",
        "SECTION",
        "2",
        "ENTITIES",
        "0",
        "LWPOLYLINE",
        "8",
        "OUTLINE",
        "90",
        "4",
        "70",
        "1",
        "10",
        "0",
        "20",
        "0",
        "10",
        String(w),
        "20",
        "0",
        "10",
        String(w),
        "20",
        String(h),
        "10",
        "0",
        "20",
        String(h),
        "0",
        "ENDSEC",
        "0",
        "EOF",
      ].join("\n") + "\n"
    );
  }

  return Object.freeze({
    dxfToPairs,
    pairsToDxf,
    classifyAndRelayer,
    mirrorX,
    extendOutlineY,
    makeRectangleDxf,
    dxfBBox,
    setEntityLayer,
    shiftEntitiesY,
  });
}
