/** checkout-review-flow: one runtime owner with explicit, immutable dependency ports. */
export function createCheckoutReviewFlow({
  alertDialog,
  applicationState,
  calculationView,
  foundation,
  wizardNavigation,
} = {}) {
  let openPriceOverlay;
  let returnToOverviewAfterCheckoutReviewFailure;
  let openCompletedCheckoutReview;

  function initialize() {
    openPriceOverlay = (jobReviewSnapshot = null) => {
      try {
        if (window.__metod_submit_done || window.__metod_submit_inflight) return false;
        const owner = foundation.current;
        if (!owner || typeof owner.openCheckoutReview !== "function") return false;
        const opened = owner.openCheckoutReview({
          state: applicationState.current,
          snapshot: jobReviewSnapshot,
        });
        if (opened && typeof window.__metodRefreshAuthoritativePriceTotal === "function") {
          void window.__metodRefreshAuthoritativePriceTotal();
        }
        return opened === true;
      } catch (_) {
        return false;
      }
    };
    window.openPriceOverlay = openPriceOverlay;

    returnToOverviewAfterCheckoutReviewFailure = () => {
      if (typeof window.__showWizardStep === "function") {
        window.__showWizardStep("overview");
        return true;
      }

      try {
        wizardNavigation.setStep("overview");
        return true;
      } catch (_) {
        return false;
      }
    };
    openCompletedCheckoutReview = async (jobReviewSnapshot = null) => {
      if (openPriceOverlay(jobReviewSnapshot) === true) return true;
      window.__metod_price_locked = false;
      const message =
        "De berekening is afgerond, maar de klant-, materiaal- en paneelcontrole kon niet volledig worden getoond.";
      calculationView.statusMsg(`${message} Je aanvraag is niet verzonden.`, true);
      try {
        await alertDialog.showToolAlertHardFallbackAsync({
          title: "Resultaat kon niet veilig worden geopend",
          body: message,
          details:
            "Je configuratie is behouden en er is niets verzonden. Controleer de gegevens in het overzicht en start de berekening daarna opnieuw.",
          onClose: returnToOverviewAfterCheckoutReviewFailure,
        });
      } catch (_) {
        returnToOverviewAfterCheckoutReviewFailure();
      }
      return false;
    };
  }

  return Object.freeze({
    get openCompletedCheckoutReview() {
      return openCompletedCheckoutReview;
    },
    initialize,
    get openPriceOverlay() {
      return openPriceOverlay;
    },
    get returnToOverviewAfterCheckoutReviewFailure() {
      return returnToOverviewAfterCheckoutReviewFailure;
    },
  });
}
