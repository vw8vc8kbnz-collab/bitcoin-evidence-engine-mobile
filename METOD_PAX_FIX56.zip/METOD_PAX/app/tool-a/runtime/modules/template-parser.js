import { ToolATemplateHelpers } from "../../domain/template-helpers.js";
/** template-parser: one runtime owner with explicit, immutable dependency ports. */
export function createTemplateParser({} = {}) {
  function parseMetaFromFilename(name) {
    if (ToolATemplateHelpers && typeof ToolATemplateHelpers.parseMetaFromFilename === "function") {
      return ToolATemplateHelpers.parseMetaFromFilename(name);
    }

    return {
      type: "special",
      cmW: null,
      cmH: null,
      kind: "Special",
      folderLabel: "",
    };
  }

  function parseDXFMinimal(text) {
    if (ToolATemplateHelpers && typeof ToolATemplateHelpers.parseDXFMinimal === "function") {
      return ToolATemplateHelpers.parseDXFMinimal(text);
    }

    return { circles: [], lwpolys: [], polys: [], lines: [] };
  }

  function buildTemplate(filename, meta, geom) {
    if (ToolATemplateHelpers && typeof ToolATemplateHelpers.buildTemplate === "function") {
      return ToolATemplateHelpers.buildTemplate(filename, meta, geom);
    }

    const sourceName = String(filename || "").trim();
    const label = sourceName.replace(/\.dxf$/i, "").trim() || sourceName;
    const safeMeta = meta || {};
    const safeGeom = geom || { circles: [], lwpolys: [], polys: [], lines: [] };
    const circles = Array.isArray(safeGeom.circles) ? safeGeom.circles : [];
    const outlinePts = [];
    function pushPt(x, y) {
      if (Number.isFinite(x) && Number.isFinite(y)) outlinePts.push({ x, y });
    }
    for (const lp of Array.isArray(safeGeom.lwpolys) ? safeGeom.lwpolys : []) {
      for (const p of Array.isArray(lp.points) ? lp.points : []) pushPt(Number(p.x), Number(p.y));
    }
    for (const pl of Array.isArray(safeGeom.polys) ? safeGeom.polys : []) {
      for (const p of Array.isArray(pl.points) ? pl.points : []) pushPt(Number(p.x), Number(p.y));
    }
    for (const ln of Array.isArray(safeGeom.lines) ? safeGeom.lines : []) {
      pushPt(Number(ln.x1), Number(ln.y1));
      pushPt(Number(ln.x2), Number(ln.y2));
    }
    let minX = 0,
      minY = 0,
      maxX = 0,
      maxY = 0;
    if (outlinePts.length) {
      minX = Math.min(...outlinePts.map((p) => p.x));
      maxX = Math.max(...outlinePts.map((p) => p.x));
      minY = Math.min(...outlinePts.map((p) => p.y));
      maxY = Math.max(...outlinePts.map((p) => p.y));
    } else {
      const w = Math.max(0, Number(safeMeta.cmW || 0) * 10);
      const h = Math.max(0, Number(safeMeta.cmH || 0) * 10);
      minX = 0;
      minY = 0;
      maxX = w;
      maxY = h;
    }
    const realW =
      Math.max(0, Math.round(maxX - minX)) || Math.max(0, Number(safeMeta.cmW || 0) * 10);
    const realH =
      Math.max(0, Math.round(maxY - minY)) || Math.max(0, Number(safeMeta.cmH || 0) * 10);
    const normMinX = Number.isFinite(minX) ? minX : 0;
    const normMinY = Number.isFinite(minY) ? minY : 0;
    return {
      id: makeTemplateId(sourceName),
      label,
      sourceName,
      fileName: sourceName,
      type: safeMeta.type || "special",
      kind: safeMeta.kind || "Special",
      cmW: safeMeta.cmW != null ? Number(safeMeta.cmW) : Math.round(realW / 10),
      cmH: safeMeta.cmH != null ? Number(safeMeta.cmH) : Math.round(realH / 10),
      realW,
      realH,
      outline: { minX: 0, maxX: realW, minY: 0, maxY: realH },
      holes: circles.map((c) => ({
        x: (Number(c.x) || 0) - normMinX,
        y: (Number(c.y) || 0) - normMinY,
        r: Number(c.r) || 0,
      })),
    };
  }

  function makeTemplateId(filename) {
    if (ToolATemplateHelpers && typeof ToolATemplateHelpers.makeTemplateId === "function") {
      return ToolATemplateHelpers.makeTemplateId(filename);
    }

    return String(filename || "")
      .toLowerCase()
      .replace(/\.dxf$/, "")
      .replace(/[^a-z0-9]+/g, "_")
      .replace(/^_+|_+$/g, "");
  }

  return Object.freeze({
    makeTemplateId,
    parseMetaFromFilename,
    parseDXFMinimal,
    buildTemplate,
  });
}
