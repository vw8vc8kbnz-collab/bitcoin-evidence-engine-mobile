/** material-catalog: one runtime owner with explicit, immutable dependency ports. */
export function createMaterialCatalog({
  materialIdentity,
  panelElements,
  panelTypes,
  templateCatalog,
} = {}) {
  let MATERIAL_CATALOG;
  let sugActive;
  let sugList;
  let __materialCatalogLiveVersion;
  let __materialCatalogRefreshBusy;
  let __materialCatalogLastSyncAt;

  function renderSuggest(items, activeIdx) {
    // the right-column search now filters the visual tile library directly.
    // The legacy text suggestion list is deliberately disabled.
    panelElements.matSuggest.style.display = "none";
    panelElements.matSuggest.innerHTML = "";
  }

  function computeSuggest(q) {
    const qq = materialIdentity.norm(q);
    let hits;
    if (!qq) {
      // Help discoverability: toon top 10 bij focus/lege input
      hits = window.MATERIAL_CATALOG.slice(0, 10);
    } else {
      hits = window.MATERIAL_CATALOG.filter((m) => {
        const hay =
          `${m.brand || ""} ${m.publicName || m.displayName || m.productName || m.decorName || ""} ${m.decorType || m.categoryName || ""} ${m.colorGroup || ""}`.toLowerCase();
        return hay.includes(qq);
      }).slice(0, 10);
    }
    sugList = hits;
    sugActive = hits.length ? 0 : -1;
    renderSuggest(hits, sugActive);
  }

  function _normalizeLiveMaterialForToolA(rec) {
    if (!rec || typeof rec !== "object") return null;
    const publicId = String(
      rec.publicMaterialId || rec.articleNumber || rec.articleNo || rec.materialCode || "",
    ).trim();
    const publicName = String(
      rec.publicName || rec.displayName || rec.productName || rec.decorName || "Decor",
    ).trim();
    const w = Number(rec?.sheetSizeMm?.width ?? rec.sheetWid ?? rec.sheetWidth ?? 0);
    const h = Number(
      rec?.sheetSizeMm?.height ?? rec.sheetLen ?? rec.sheetHeight ?? rec.height ?? 0,
    );
    const t = Number(rec.thicknessMm ?? rec.thickness ?? 0);
    if (!/^decor_[a-f0-9]{20,40}$/.test(publicId) || !(w > 0) || !(h > 0) || !(t > 0)) return null;
    return {
      publicMaterialId: publicId,
      articleNumber: publicId,
      articleNo: publicId,
      materialCode: publicId,
      publicName,
      displayName: publicName,
      decorName: publicName,
      productName: publicName,
      filters:
        rec.filters && typeof rec.filters === "object"
          ? JSON.parse(JSON.stringify(rec.filters))
          : {},
      brand: String(rec.brand || "Overig").trim() || "Overig",
      decorType:
        String(rec.primaryVisualFamily || rec.decorType || rec.visualFamily || "Onbekend").trim() ||
        "Onbekend",
      primaryVisualFamily:
        String(rec.primaryVisualFamily || rec.visualFamily || rec.decorType || "Onbekend").trim() ||
        "Onbekend",
      visualFamily:
        String(rec.primaryVisualFamily || rec.visualFamily || rec.decorType || "Onbekend").trim() ||
        "Onbekend",
      visualTags: Array.isArray(rec.visualTags)
        ? rec.visualTags
            .map((x) => String(x || "").trim())
            .filter(Boolean)
            .slice(0, 12)
        : [],
      substrateType:
        String(rec.substrateType || "ONBEKEND")
          .trim()
          .toUpperCase() || "ONBEKEND",
      substrateLabel: String(rec.substrateLabel || "Onbekend").trim() || "Onbekend",
      collection: String(rec.collection || "").trim(),
      colorGroup: String(rec.colorGroup || "Overig").trim() || "Overig",
      searchTags: Array.isArray(rec.searchTags)
        ? rec.searchTags
            .map((x) => String(x || "").trim())
            .filter(Boolean)
            .slice(0, 48)
        : [],
      thicknessMm: t,
      sheetSizeMm: { width: w, height: h },
      hasGrain: rec.hasGrain == null ? true : !!rec.hasGrain,
      grainDefaultOn: rec.grainDefaultOn == null ? true : !!rec.grainDefaultOn,
      categoryName: String(rec.decorType || rec.categoryName || "Overig").trim() || "Overig",
      active: rec.active !== false,
      published: rec.published !== false,
      isPopular: !!rec.isPopular,
      isNew: !!rec.isNew,
      imageAvailable: !!rec.imageAvailable,
      imageThumbUrl: String(rec.imageThumbUrl || ""),
      imagePreviewUrl: String(rec.imagePreviewUrl || ""),
    };
  }

  async function refreshMaterialCatalogLive(opts) {
    opts = opts || {};
    const now = Date.now();
    if (__materialCatalogRefreshBusy) return false;
    if (!opts.force && __materialCatalogLastSyncAt && now - __materialCatalogLastSyncAt < 4000)
      return false;
    __materialCatalogRefreshBusy = true;
    try {
      let j;
      try {
        if (!__materialCatalogLastSyncAt && window.__TOOLA_PUBLIC_CATALOG_BOOTSTRAP_PROMISE) {
          j = await window.__TOOLA_PUBLIC_CATALOG_BOOTSTRAP_PROMISE;
        } else {
          const response = await fetch("/api/materials/library", {
            cache: "no-cache",
            credentials: "same-origin",
          });
          if (!response.ok) {
            ToolAErrors.recover("catalog.material.http", new Error(), ["Error"]);
            return false;
          }
          j = await response.json();
        }
      } catch (error) {
        ToolAErrors.recover("catalog.material.transport", error, [
          "TypeError",
          "SyntaxError",
          "AbortError",
          "NetworkError",
          "TimeoutError",
        ]);
        return false;
      }
      if (!j || j.ok === false) {
        ToolAErrors.recover("catalog.material.response", new Error(), ["Error"]);
        return false;
      }
      const recs = Array.isArray(j.records)
        ? j.records.map(_normalizeLiveMaterialForToolA).filter(Boolean)
        : [];
      if (recs.length) {
        window.MATERIAL_CATALOG = recs;
        __materialCatalogLiveVersion = String(j.version || now);
        __materialCatalogLastSyncAt = now;
        if (panelElements.matSearch === document.activeElement || opts.refreshSuggest) {
          computeSuggest(panelElements.matSearch ? panelElements.matSearch.value || "" : "");
        }

        document.dispatchEvent(
          new CustomEvent("adzaagt-material-catalog-updated", {
            detail: {
              count: recs.length,
              version: __materialCatalogLiveVersion,
            },
          }),
        );
        return true;
      }
    } finally {
      __materialCatalogRefreshBusy = false;
    }
    return false;
  }

  function mount() {
    // Public visitors do not hold a permanent server connection. Templates are
    // loaded at startup; a returning tab checks its revision once, at most once
    // per minute. Never rebuild options while the customer uses a native select.
    let lastCheck = Date.now();
    let checking = false;
    async function checkTemplates() {
      if (document.hidden || checking || Date.now() - lastCheck < 60000) return;
      const active = document.activeElement;
      if (active?.id === "typeSel" || active?.id === "sizeSel") return;
      checking = true;
      lastCheck = Date.now();
      try {
        const response = await fetch("/api/dxf_manifest_meta", {
          cache: "no-store",
        });
        if (!response.ok) throw new Error("Template revision unavailable");
        const metadata = await response.json();
        if (
          metadata.version !== templateCatalog.EMBED_DXF_VERSION &&
          (await templateCatalog.refreshEmbeddedDxfCatalogNow())
        ) {
          templateCatalog.EMBED_DXF_VERSION = metadata.version;
          panelTypes.updateTypeOptions();
          templateCatalog.populateSizeDropdown();
        }
      } catch (error) {
        ToolAErrors.recover("catalog.templates.refresh", error, [
          "Error",
          "TypeError",
          "SyntaxError",
        ]);
      } finally {
        checking = false;
      }
    }
    window.addEventListener("focus", checkTemplates);
    document.addEventListener("visibilitychange", checkTemplates);
  }

  function mount2() {
    MATERIAL_CATALOG = window.MATERIAL_CATALOG = Array.isArray(window.MATERIAL_CATALOG)
      ? window.MATERIAL_CATALOG
      : [];
  }

  return Object.freeze({
    refreshMaterialCatalogLive,
    get sugActive() {
      return sugActive;
    },
    set sugActive(value) {
      sugActive = value;
    },
    get sugList() {
      return sugList;
    },
    set sugList(value) {
      sugList = value;
    },
    get __materialCatalogLiveVersion() {
      return __materialCatalogLiveVersion;
    },
    set __materialCatalogLiveVersion(value) {
      __materialCatalogLiveVersion = value;
    },
    get __materialCatalogRefreshBusy() {
      return __materialCatalogRefreshBusy;
    },
    set __materialCatalogRefreshBusy(value) {
      __materialCatalogRefreshBusy = value;
    },
    get __materialCatalogLastSyncAt() {
      return __materialCatalogLastSyncAt;
    },
    set __materialCatalogLastSyncAt(value) {
      __materialCatalogLastSyncAt = value;
    },
    renderSuggest,
    computeSuggest,
    mount,
    mount2,
  });
}
