/** customer-form: one runtime owner with explicit, immutable dependency ports. */
export function createCustomerForm({
  applicationState,
  checkoutOverlays,
  customerSnapshot,
  priceBar,
} = {}) {
  let custLastName;
  let custCompany;
  let custEmail;
  let custPhone;
  let custBillingAddress;
  let custPostcode;
  let custHouseNumber;
  let custShipSame;
  let custShippingAddress;
  let custShippingPostcode;
  let custShippingHouseNumber;
  let custNote;
  let custRestYes;
  let custRestNo;

  function applyRestCarryToggleUI() {
    {
      const yes = document.getElementById("custRestYes");
      const no = document.getElementById("custRestNo");
      if (!yes || !no) return;
      const carry = applicationState.current.checkout?.restCarry !== false; // default JA
      const setBtn = (btn, active) => {
        btn.classList.toggle("active", !!active);
        btn.setAttribute("aria-pressed", active ? "true" : "false");
        btn.style.background = active
          ? "linear-gradient(180deg, rgba(120,151,188,.18), rgba(88,119,159,.10))"
          : "#ffffff";
        btn.style.borderColor = active ? "rgba(88,119,159,.92)" : "rgba(34,34,34,.12)";
        btn.style.color = active ? "#23425f" : "#2f3235";
        btn.style.opacity = "1";
        btn.style.filter = "none";
        btn.style.boxShadow = active
          ? "0 0 0 1px rgba(47,191,106,.12) inset, 0 10px 24px rgba(47,191,106,.12)"
          : "none";
        const muted = btn.querySelectorAll(".muted");
        muted.forEach((el) => {
          el.style.color = active ? "#4b6787" : "#6b7280";
          el.style.opacity = "1";
        });
      };
      setBtn(yes, carry === true);
      setBtn(no, carry === false);
    }
  }

  function setRestCarryValue(v) {
    applicationState.current.checkout = applicationState.current.checkout || {};
    applicationState.current.checkout.restCarry = !!v;
    applicationState.current.checkout.rest_material = { carry_out: !!v };
    applyRestCarryToggleUI();
    priceBar.updatePriceBar();
  }

  function ensureRestCarryDefault() {
    applicationState.current.checkout = applicationState.current.checkout || {};
    if (typeof applicationState.current.checkout.restCarry !== "boolean")
      applicationState.current.checkout.restCarry = true;
    applicationState.current.checkout.rest_material = {
      carry_out: applicationState.current.checkout.restCarry !== false,
    };
    if (checkoutOverlays.restYes && checkoutOverlays.restNo) {
      const carry = applicationState.current.checkout.restCarry !== false;
      checkoutOverlays.restYes.checked = carry === true;
      checkoutOverlays.restNo.checked = carry === false;
    }
    applyRestCarryToggleUI();
  }

  function applyCustShipSameUI() {
    const separateLocation = document.getElementById("custShippingLocation");
    if (separateLocation)
      separateLocation.hidden = document.getElementById("custShipSame")?.checked !== false;

    {
      const cb = document.getElementById("custShipSame");
      if (!cb) return;
      const same = cb.checked !== false;
      [
        ["custShippingAddress", "custBillingAddress"],
        ["custShippingCity", "custCity"],
        ["custShippingCountry", "custCountry"],
        ["custShippingPostcode", "custPostcode"],
        ["custShippingHouseNumber", "custHouseNumber"],
      ].forEach(([shippingId, billingId]) => {
        const ship = document.getElementById(shippingId);
        if (!ship) return;
        if (same) {
          const bill = document.getElementById(billingId);
          ship.value = String(bill?.value || "").trim();
          ship.disabled = true;
          ship.style.opacity = "0.7";
        } else {
          ship.disabled = false;
          ship.style.opacity = "";
        }
      });
    }
  }

  function syncCheckoutUIFromState() {
    // Only push state -> UI when state actually has a value.
    // This prevents wiping user-entered fields when state.checkout.customer is still empty.
    const setIf = (id, val) => {
      const el = document.getElementById(id);
      if (!el) return;
      const v = val === undefined || val === null ? "" : String(val);
      if (v.trim() !== "") {
        el.value = v;
      } else {
        // Do NOT overwrite a non-empty input with empty state (leave as-is).
      }
    };
    // Restmateriaal (stap 4 toggle + legacy radios voor backwards compatibility)
    ensureRestCarryDefault();
    {
      const carry = applicationState.current.checkout?.restCarry !== false; // default JA
      applicationState.current.checkout.restCarry = carry;
      applicationState.current.checkout.rest_material = { carry_out: carry };
      if (checkoutOverlays.restYes && checkoutOverlays.restNo) {
        checkoutOverlays.restYes.checked = carry === true;
        checkoutOverlays.restNo.checked = carry === false;
      }
      applyRestCarryToggleUI();
    }
    // Customer (Gegevens)
    const c =
      applicationState.current.checkout && applicationState.current.checkout.customer
        ? applicationState.current.checkout.customer
        : {};
    setIf("custFirstName", c.firstName);
    setIf("custLastName", c.lastName);
    setIf("custCompany", c.company || c.companyName);
    setIf("custEmail", c.email);
    setIf("custPhone", c.phone);
    setIf("custBillingAddress", c.billingAddress || c.invoiceAddress || c.address1);
    setIf("custCity", c.city);
    setIf("custCountry", c.country || "Nederland");
    setIf("custShippingCity", c.shippingCity);
    setIf("custShippingCountry", c.shippingCountry || "Nederland");
    setIf("custPostcode", c.postcode || c.postalCode);
    setIf("custHouseNumber", c.houseNumber || c.housenumber);
    // shipping
    {
      const cb = document.getElementById("custShipSame");
      if (cb) {
        if (typeof c.shippingSameAsBilling === "boolean") cb.checked = c.shippingSameAsBilling;
        else if (cb.checked !== true) cb.checked = true; // default AAN
      }
    }
    setIf(
      "custShippingAddress",
      c.shippingAddress ||
        c.deliveryAddress ||
        (c.shippingSameAsBilling === false ? "" : c.address1),
    );
    setIf(
      "custShippingPostcode",
      c.shippingPostcode || c.shippingPostalCode || c.deliveryPostcode || c.deliveryPostalCode,
    );
    setIf("custShippingHouseNumber", c.shippingHouseNumber || c.deliveryHouseNumber);
    setIf(
      "custNote",
      applicationState.current.checkout ? applicationState.current.checkout.note : "",
    );
    // Apply checkbox UI state after filling
    applyCustShipSameUI();
  }

  function readCustomerFromUI() {
    // Read live DOM values (avoid stale cached refs)
    const v = (id) => String(document.getElementById(id)?.value || "").trim();
    const shipSame = document.getElementById("custShipSame")?.checked !== false;
    const billingAddress = v("custBillingAddress");
    const postcode = v("custPostcode");
    const houseNumber = v("custHouseNumber");
    let shippingAddress = v("custShippingAddress");
    let shippingPostcode = v("custShippingPostcode");
    let shippingHouseNumber = v("custShippingHouseNumber");
    if (shipSame) {
      shippingAddress = billingAddress;
      shippingPostcode = postcode;
      shippingHouseNumber = houseNumber;
    }

    applicationState.current.checkout.customer = {
      firstName: v("custFirstName"),
      lastName: v("custLastName"),
      company: v("custCompany") || "",
      email: v("custEmail"),
      phone: v("custPhone"),
      billingAddress,
      shippingAddress,
      shippingPostcode,
      shippingHouseNumber,
      shippingSameAsBilling: shipSame,
      postcode,
      houseNumber,
      // Backwards-compatible keys (do not rely on these for UI)
      address1: shippingAddress ? shippingAddress : billingAddress,
      address2: "",
      city: v("custCity"),
      country: v("custCountry"),
      shippingCity: v(shipSame ? "custCity" : "custShippingCity"),
      shippingCountry: v(shipSame ? "custCountry" : "custShippingCountry"),
    };
    applicationState.current.checkout.note = v("custNote");
    const carry = applicationState.current.checkout?.restCarry !== false;
    applicationState.current.checkout.restCarry = carry;
    applicationState.current.checkout.rest_material = { carry_out: carry };
    // Apply UI lock if needed (in case of programmatic changes)
    applyCustShipSameUI();
    return applicationState.current.checkout.customer;
  }

  function customerFormHasValues() {
    const ids = [
      "custFirstName",
      "custLastName",
      "custCompany",
      "custEmail",
      "custPhone",
      "custBillingAddress",
      "custPostcode",
      "custHouseNumber",
      "custCity",
      "custCountry",
      "custShippingAddress",
      "custShippingPostcode",
      "custShippingHouseNumber",
      "custShippingCity",
      "custShippingCountry",
    ];
    return ids.some((id) => String(document.getElementById(id)?.value || "").trim());
  }

  function commitCustomerCalculationSnapshot() {
    const live = readCustomerFromUI();
    const snapshot = customerSnapshot.copyCustomerSnapshot(live);
    applicationState.current.checkout = applicationState.current.checkout || {};
    applicationState.current.checkout.customer = customerSnapshot.copyCustomerSnapshot(snapshot);
    applicationState.current.checkout.customerSnapshot =
      customerSnapshot.copyCustomerSnapshot(snapshot);
    applicationState.current.lastCalculatedCustomer =
      customerSnapshot.copyCustomerSnapshot(snapshot);
    return customerSnapshot.copyCustomerSnapshot(snapshot);
  }

  function initialize() {
    custLastName = document.getElementById("custLastName");
    custCompany = document.getElementById("custCompany");
    custEmail = document.getElementById("custEmail");
    custPhone = document.getElementById("custPhone");
    custBillingAddress = document.getElementById("custBillingAddress");
    custPostcode = document.getElementById("custPostcode");
    custHouseNumber = document.getElementById("custHouseNumber");
    custShipSame = document.getElementById("custShipSame");
    custShippingAddress = document.getElementById("custShippingAddress");
    custShippingPostcode = document.getElementById("custShippingPostcode");
    custShippingHouseNumber = document.getElementById("custShippingHouseNumber");
    custNote = document.getElementById("custNote");
    custRestYes = document.getElementById("custRestYes");
    custRestNo = document.getElementById("custRestNo");
    {
      const cb = document.getElementById("custShipSame");
      if (cb && !cb.__bound) {
        cb.addEventListener(
          "change",
          () => {
            applyCustShipSameUI();
            readCustomerFromUI();
          },
          true,
        );
        cb.__bound = true;
      }
      ["custBillingAddress", "custPostcode", "custHouseNumber", "custCity", "custCountry"].forEach(
        (id) => {
          const billingField = document.getElementById(id);
          if (billingField && !billingField.__bound) {
            billingField.addEventListener(
              "input",
              () => {
                if (document.getElementById("custShipSame")?.checked !== false)
                  applyCustShipSameUI();
                readCustomerFromUI();
              },
              true,
            );
            billingField.__bound = true;
          }
        },
      );
      const ids = [
        "custFirstName",
        "custLastName",
        "custCompany",
        "custEmail",
        "custPhone",
        "custBillingAddress",
        "custPostcode",
        "custHouseNumber",
        "custCity",
        "custCountry",
        "custShippingAddress",
        "custShippingPostcode",
        "custShippingHouseNumber",
        "custShippingCity",
        "custShippingCountry",
        "custNote",
      ];

      if (custRestYes && !custRestYes.__bound) {
        custRestYes.addEventListener(
          "click",
          () => {
            setRestCarryValue(true);
            readCustomerFromUI();
          },
          true,
        );
        custRestYes.__bound = true;
      }
      if (custRestNo && !custRestNo.__bound) {
        custRestNo.addEventListener(
          "click",
          () => {
            setRestCarryValue(false);
            readCustomerFromUI();
          },
          true,
        );
        custRestNo.__bound = true;
      }

      ids.forEach((id) => {
        const el = document.getElementById(id);
        if (el && !el.__bound) {
          el.addEventListener(
            "input",
            () => {
              readCustomerFromUI();
            },
            true,
          );
          el.__bound = true;
        }
      });
    }
  }

  return Object.freeze({
    commitCustomerCalculationSnapshot,
    syncCheckoutUIFromState,
    readCustomerFromUI,
    get custLastName() {
      return custLastName;
    },
    get custCompany() {
      return custCompany;
    },
    get custEmail() {
      return custEmail;
    },
    get custPhone() {
      return custPhone;
    },
    get custBillingAddress() {
      return custBillingAddress;
    },
    get custPostcode() {
      return custPostcode;
    },
    get custHouseNumber() {
      return custHouseNumber;
    },
    get custShipSame() {
      return custShipSame;
    },
    get custShippingAddress() {
      return custShippingAddress;
    },
    get custShippingPostcode() {
      return custShippingPostcode;
    },
    get custShippingHouseNumber() {
      return custShippingHouseNumber;
    },
    get custNote() {
      return custNote;
    },
    get custRestYes() {
      return custRestYes;
    },
    get custRestNo() {
      return custRestNo;
    },
    applyRestCarryToggleUI,
    setRestCarryValue,
    ensureRestCarryDefault,
    applyCustShipSameUI,
    customerFormHasValues,
    initialize,
  });
}
