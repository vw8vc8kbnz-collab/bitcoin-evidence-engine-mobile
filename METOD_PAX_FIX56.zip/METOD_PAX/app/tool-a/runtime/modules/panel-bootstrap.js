import { ToolAPanelBootstrapApply } from "../../domain/panel-bootstrap-apply.js";
import { ToolAPanelBootstrapMutations } from "../../domain/panel-bootstrap-mutations.js";
/** panel-bootstrap: one runtime owner with explicit, immutable dependency ports. */
export function createPanelBootstrap({
  applicationState,
  configurationState,
  formatting,
  panelElements,
  panelPreview,
  panelTypes,
  selectionState,
  templateCatalog,
} = {}) {
  function bootstrapPanelSelectionForActiveMaterial(force) {
    try {
      configurationState.ensureStateShape();
      if (
        !(
          applicationState.current &&
          applicationState.current.activeMaterialKey &&
          applicationState.current.material
        )
      )
        return false;

      const __plan =
        ToolAPanelBootstrapMutations &&
        typeof ToolAPanelBootstrapMutations.getBootstrapPlan === "function"
          ? ToolAPanelBootstrapMutations.getBootstrapPlan({
              state: applicationState.current,
              selectionCommands: selectionState,
              force,
              clampInt: formatting.clampInt,
            })
          : null;
      const __selection = __plan && __plan.selection ? __plan.selection : null;
      const __ui = __plan && __plan.ui ? __plan.ui : null;
      const __needsReset = !!(__plan && __plan.needsReset);

      if (
        ToolAPanelBootstrapApply &&
        typeof ToolAPanelBootstrapApply.applyBootstrap === "function"
      ) {
        ToolAPanelBootstrapApply.applyBootstrap({
          state: applicationState.current,
          selectionCommands: selectionState,
          selection: __selection,
          ui: __ui,
          needsReset: __needsReset,
          typeSel: panelElements.typeSel,
          sizeSel: panelElements.sizeSel,
          qty: panelElements.qty,
          extTop: panelElements.extTop,
          extBot: panelElements.extBot,
          addBtn: panelElements.addBtn,
          syncDefaultPanelTypeSelection: panelTypes.syncDefaultPanelTypeSelection,
          populateSizeDropdown: templateCatalog.populateSizeDropdown,
          refreshCustomLabelVisibility: window.__refreshCustomLabelVisibility,
          ensureTemplateLoadedById: templateCatalog.loadSelectedPanelTemplate,
          draw: panelPreview.draw,
        });
      } else {
        if (__selection) {
          selectionState.update({ type: __selection.type });
          selectionState.update({ templateId: __selection.templateId });
          selectionState.update({
            qty: formatting.clampInt(__selection.qty || 1, 1, 999),
          });
          selectionState.update({ extTop: Number(__selection.extTop) || 0 });
          selectionState.update({ extBot: Number(__selection.extBot) || 0 });
        }

        if (__needsReset) {
          if (panelElements.typeSel) {
            panelElements.typeSel.value =
              __ui && typeof __ui.typeValue !== "undefined" ? __ui.typeValue : "";
            if (typeof panelElements.typeSel.__appleSync === "function")
              panelElements.typeSel.__appleSync();
          }
          if (panelElements.sizeSel) {
            panelElements.sizeSel.innerHTML =
              __ui && __ui.sizePlaceholder
                ? __ui.sizePlaceholder
                : '<option value="">— Kies maat —</option>';
            panelElements.sizeSel.value =
              __ui && typeof __ui.sizeValue !== "undefined" ? __ui.sizeValue : "";
            if (typeof panelElements.sizeSel.__appleSync === "function")
              panelElements.sizeSel.__appleSync();
          }
          if (panelElements.extTop)
            panelElements.extTop.value =
              __ui && typeof __ui.extTop !== "undefined" ? __ui.extTop : 0;
          if (panelElements.extBot)
            panelElements.extBot.value =
              __ui && typeof __ui.extBot !== "undefined" ? __ui.extBot : 0;
          panelTypes.syncDefaultPanelTypeSelection();
          templateCatalog.populateSizeDropdown();
        } else {
          if (panelElements.typeSel) {
            panelElements.typeSel.value =
              __ui && typeof __ui.typeValue !== "undefined"
                ? __ui.typeValue
                : String(applicationState.current.selection.type || "");
            if (typeof panelElements.typeSel.__appleSync === "function")
              panelElements.typeSel.__appleSync();
          }
          if (panelElements.sizeSel) {
            panelElements.sizeSel.value =
              __ui && typeof __ui.sizeValue !== "undefined"
                ? __ui.sizeValue
                : String(applicationState.current.selection.templateId || "");
            if (typeof panelElements.sizeSel.__appleSync === "function")
              panelElements.sizeSel.__appleSync();
          }
        }

        if (panelElements.addBtn)
          panelElements.addBtn.disabled = !(__ui && typeof __ui.addEnabled !== "undefined"
            ? __ui.addEnabled
            : applicationState.current.selection.type &&
              applicationState.current.selection.templateId &&
              applicationState.current.activeMaterialKey);
        window.__refreshCustomLabelVisibility?.();
        if (panelElements.typeSel)
          panelElements.typeSel.dispatchEvent(new Event("change", { bubbles: true }));
        templateCatalog.loadSelectedPanelTemplate();
      }
      return true;
    } catch (_) {
      return false;
    }
  }

  return Object.freeze({
    bootstrapPanelSelectionForActiveMaterial,
  });
}
