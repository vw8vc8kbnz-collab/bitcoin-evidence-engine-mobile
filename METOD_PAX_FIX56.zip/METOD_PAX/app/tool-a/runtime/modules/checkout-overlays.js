/** checkout-overlays: one runtime owner with explicit, immutable dependency ports. */
export function createCheckoutOverlays({} = {}) {
  let restOverlay;
  let restCloseBtn;
  let restNextBtn;
  let restYes;
  let restNo;
  let custFirstName;

  function initialize() {
    restOverlay = document.getElementById("restOverlay");
    restCloseBtn = document.getElementById("restCloseBtn");
    restNextBtn = document.getElementById("restNextBtn");
    restYes = document.getElementById("restYes");
    restNo = document.getElementById("restNo");
    custFirstName = document.getElementById("custFirstName");
  }

  return Object.freeze({
    get restYes() {
      return restYes;
    },
    get restNo() {
      return restNo;
    },
    get restOverlay() {
      return restOverlay;
    },
    get restCloseBtn() {
      return restCloseBtn;
    },
    get restNextBtn() {
      return restNextBtn;
    },
    get custFirstName() {
      return custFirstName;
    },
    initialize,
  });
}
