import { ToolAPanelEditContext } from "../../domain/panel-edit-context.js";
import { ToolAStateHelpers } from "../../domain/safe-helper-layer.js";
/** panel-edit-session: one runtime owner with explicit, immutable dependency ports. */
export function createPanelEditSession({} = {}) {
  let extraEditIndex;
  let panelEditTargetId;
  let panelEditGroupKey;
  let panelEditOriginalCount;
  let currentDrag;

  function getPanelEditTargetId() {
    if (ToolAPanelEditContext && typeof ToolAPanelEditContext.getTargetId === "function") {
      return ToolAPanelEditContext.getTargetId(panelEditTargetId);
    }
    if (ToolAStateHelpers && typeof ToolAStateHelpers.getPanelEditTargetId === "function") {
      return ToolAStateHelpers.getPanelEditTargetId(panelEditTargetId);
    }

    try {
      return typeof panelEditTargetId !== "undefined"
        ? panelEditTargetId
        : window.__panelEditTargetId || null;
    } catch (_) {
      return window.__panelEditTargetId || null;
    }
  }

  function getPanelEditGroupKey() {
    if (ToolAPanelEditContext && typeof ToolAPanelEditContext.getGroupKey === "function") {
      return ToolAPanelEditContext.getGroupKey(panelEditGroupKey);
    }
    if (ToolAStateHelpers && typeof ToolAStateHelpers.getPanelEditGroupKey === "function") {
      return ToolAStateHelpers.getPanelEditGroupKey(panelEditGroupKey);
    }

    try {
      return typeof panelEditGroupKey !== "undefined"
        ? panelEditGroupKey
        : window.__panelEditGroupKey || null;
    } catch (_) {
      return window.__panelEditGroupKey || null;
    }
  }

  function getPanelEditOriginalCount() {
    if (ToolAPanelEditContext && typeof ToolAPanelEditContext.getOriginalCount === "function") {
      return ToolAPanelEditContext.getOriginalCount(panelEditOriginalCount);
    }
    if (ToolAStateHelpers && typeof ToolAStateHelpers.getPanelEditOriginalCount === "function") {
      return ToolAStateHelpers.getPanelEditOriginalCount(panelEditOriginalCount);
    }

    try {
      return typeof panelEditOriginalCount !== "undefined"
        ? panelEditOriginalCount
        : Number(window.__panelEditOriginalCount || 0);
    } catch (_) {
      return Number(window.__panelEditOriginalCount || 0);
    }
  }

  function resolvePanelEditTargetId() {
    if (typeof getPanelEditTargetId === "function") return getPanelEditTargetId();
    if (typeof panelEditTargetId !== "undefined") return panelEditTargetId;
    try {
      return window.__panelEditTargetId || null;
    } catch (_) {
      return null;
    }
  }

  function resolvePanelEditGroupKey() {
    if (typeof getPanelEditGroupKey === "function") return getPanelEditGroupKey();
    if (typeof panelEditGroupKey !== "undefined") return panelEditGroupKey;
    try {
      return window.__panelEditGroupKey || null;
    } catch (_) {
      return null;
    }
  }

  function resolvePanelEditOriginalCount() {
    if (typeof getPanelEditOriginalCount === "function") return getPanelEditOriginalCount();
    if (typeof panelEditOriginalCount !== "undefined") return Number(panelEditOriginalCount || 0);
    try {
      return Number(window.__panelEditOriginalCount || 0);
    } catch (_) {
      return 0;
    }
  }

  function mount() {
    extraEditIndex = null;
    panelEditTargetId = null;
    panelEditGroupKey = null;
    panelEditOriginalCount = 0;

    if (typeof window !== "undefined") {
      window.getPanelEditTargetId =
        window.getPanelEditTargetId ||
        function () {
          try {
            return window.__panelEditTargetId || null;
          } catch (_) {
            return null;
          }
        };
      window.getPanelEditGroupKey =
        window.getPanelEditGroupKey ||
        function () {
          try {
            return window.__panelEditGroupKey || null;
          } catch (_) {
            return null;
          }
        };
      window.getPanelEditOriginalCount =
        window.getPanelEditOriginalCount ||
        function () {
          try {
            return Number(window.__panelEditOriginalCount || 0);
          } catch (_) {
            return 0;
          }
        };
    }
    window.__panelEditTargetId = panelEditTargetId;
    window.__panelEditGroupKey = panelEditGroupKey;
    window.__panelEditOriginalCount = panelEditOriginalCount;

    currentDrag = null;
  }

  return Object.freeze({
    get extraEditIndex() {
      return extraEditIndex;
    },
    set extraEditIndex(value) {
      extraEditIndex = value;
    },
    get panelEditTargetId() {
      return panelEditTargetId;
    },
    set panelEditTargetId(value) {
      panelEditTargetId = value;
    },
    get panelEditGroupKey() {
      return panelEditGroupKey;
    },
    set panelEditGroupKey(value) {
      panelEditGroupKey = value;
    },
    get panelEditOriginalCount() {
      return panelEditOriginalCount;
    },
    set panelEditOriginalCount(value) {
      panelEditOriginalCount = value;
    },
    resolvePanelEditTargetId,
    resolvePanelEditGroupKey,
    resolvePanelEditOriginalCount,
    get currentDrag() {
      return currentDrag;
    },
    set currentDrag(value) {
      currentDrag = value;
    },
    mount,
  });
}
