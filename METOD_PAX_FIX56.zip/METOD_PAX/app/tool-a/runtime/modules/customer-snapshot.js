/** customer-snapshot: one runtime owner with explicit, immutable dependency ports. */
export function createCustomerSnapshot({ foundation } = {}) {
  function copyCustomerSnapshot(raw) {
    const owner = foundation.current;
    if (!owner || typeof owner.normalizeCustomerSnapshot !== "function") {
      throw new Error("R9 customer snapshot reader is niet geladen. Herlaad Tool A.");
    }
    return owner.normalizeCustomerSnapshot(raw);
  }

  function customerForCurrentCalculation() {
    const owner = foundation.current;
    if (!owner || typeof owner.getCustomerSnapshot !== "function") {
      throw new Error("R9 customer snapshot store is niet geladen. Herlaad Tool A.");
    }
    return owner.getCustomerSnapshot();
  }

  return Object.freeze({
    customerForCurrentCalculation,
    copyCustomerSnapshot,
  });
}
