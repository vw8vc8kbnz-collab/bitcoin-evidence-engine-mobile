import { ToolACustomerValidation } from "../../domain/customer-validation.js";
/** checkout-flow: one runtime owner with explicit, immutable dependency ports. */
export function createCheckoutFlow({
  applicationState,
  calculationView,
  customerForm,
  customerSnapshot,
  customerValidation,
  overviewOverlay,
  wizardNavigation,
} = {}) {
  async function runCheckoutOverlays() {
    // Restmateriaal + klantgegevens worden nu direct in stap 4 beheerd.
    try {
      applicationState.current.checkout = applicationState.current.checkout || {};
    } catch (_) {
      applicationState.current.checkout = {};
    }
    if (typeof applicationState.current.checkout.restCarry !== "boolean")
      applicationState.current.checkout.restCarry = true;
    applicationState.current.checkout.rest_material = {
      carry_out: applicationState.current.checkout.restCarry !== false,
    };
    if (!applicationState.current.checkout.customer)
      applicationState.current.checkout.customer = {};
    customerForm.ensureRestCarryDefault();
    // The customer footer commits this snapshot while Step 4 is still visible.
    // Prefer that validated boundary on Overview: hidden/disabled form controls
    // and Safari autofill lifecycle must not be re-read after navigation.
    const committedCustomer = applicationState.current.checkout.customerSnapshot;
    let committedValidation = null;
    try {
      if (committedCustomer && ToolACustomerValidation?.validateCustomer) {
        committedValidation = ToolACustomerValidation.validateCustomer(committedCustomer);
      }
    } catch (_) {
      committedValidation = null;
    }
    if (committedValidation?.valid === true) {
      const snapshot = customerSnapshot.copyCustomerSnapshot(committedValidation.customer);
      applicationState.current.checkout.customer = customerSnapshot.copyCustomerSnapshot(snapshot);
      applicationState.current.checkout.customerSnapshot =
        customerSnapshot.copyCustomerSnapshot(snapshot);
      applicationState.current.lastCalculatedCustomer =
        customerSnapshot.copyCustomerSnapshot(snapshot);
      return true;
    }
    // Never paint an older/empty state over the live form before reading it.
    // Safari autofill and password managers do not consistently emit input events.
    // Only hydrate from state when the form is genuinely empty (draft restore).
    if (
      !customerForm.customerFormHasValues() &&
      Object.values(applicationState.current.checkout.customer || {}).some((v) =>
        String(v == null ? "" : v).trim(),
      )
    ) {
      customerForm.syncCheckoutUIFromState();
    }
    customerForm.readCustomerFromUI();
    let customerValid = false;
    try {
      customerValid =
        typeof customerValidation.validateCustomerStepRequired === "function"
          ? customerValidation.validateCustomerStepRequired()
          : false;
    } catch (_) {
      customerValid = false;
    }
    if (!customerValid) {
      calculationView.statusMsg(
        "Vul de gemarkeerde klantgegevens correct en volledig in om verder te gaan.",
        true,
      );
      if (typeof overviewOverlay.closeOverview === "function") overviewOverlay.closeOverview();
      if (typeof window.__showWizardStep === "function") window.__showWizardStep("customer");
      else if (typeof wizardNavigation.setStep === "function") wizardNavigation.setStep("customer");
      return false;
    }
    customerForm.commitCustomerCalculationSnapshot();
    return true;
  }

  return Object.freeze({
    runCheckoutOverlays,
  });
}
