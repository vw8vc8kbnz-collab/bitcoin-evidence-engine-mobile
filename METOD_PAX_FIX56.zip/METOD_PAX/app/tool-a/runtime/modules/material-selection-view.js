import { ToolAPanelsEntry } from "../../adapters/panels-entrypoints.js";
import { ToolAPanelControlsApply } from "../../domain/panel-controls-apply.js";
import { ToolAPanelUiState } from "../../domain/panel-ui-state.js";
import { ToolAPanelsViewModels } from "../../domain/panels-view-models.js";
/** material-selection-view: one runtime owner with explicit, immutable dependency ports. */
export function createMaterialSelectionView({
  applicationState,
  configurationState,
  feedback,
  formatting,
  foundation,
  materialIdentity,
  materialIntents,
  panelElements,
} = {}) {
  function renderMaterialBatches() {
    configurationState.ensureStateShape();
    // Show chips in chosen area
    if (!panelElements.matChosen) return;
    const chips =
      ToolAPanelsViewModels &&
      typeof ToolAPanelsViewModels.getMaterialChipModels === "function"
        ? ToolAPanelsViewModels.getMaterialChipModels(applicationState.current, {
            titleForBatch: (b) =>
              String(
                (b?.mat && (b.mat.productName || b.mat.articleNumber || b.mat.decorName)) ||
                  b?.key ||
                  "",
              ),
          })
        : (applicationState.current.materialBatches || []).map((b) => ({
            key: b.key,
            title: String(
              (b?.mat && (b.mat.productName || b.mat.articleNumber || b.mat.decorName)) ||
                b?.key ||
                "",
            ),
            active: b.key === applicationState.current.activeMaterialKey,
            removeKey: b.key,
          }));
    if (chips.length === 0) {
      panelElements.matChosen.style.display = "none";
      if (panelElements.matChosenTitle) panelElements.matChosenTitle.textContent = "—";
      if (panelElements.matChosenMeta) panelElements.matChosenMeta.innerHTML = "";
      foundation.current?.renderMobileMaterialCart?.(applicationState.current);
      return;
    }
    panelElements.matChosen.style.display = "";
    const chipsHtml = chips
      .map((chip) => {
        const title = formatting._esc(String(chip.title || chip.key || ""));
        return `<div class="chipItem">
      <button type="button" class="chip ${chip.active ? "chipActive" : ""}" data-mkey="${formatting._esc(chip.key)}" title="${title}">
        <span class="chipDot"></span>
        <span class="chipTxt">${title}</span>
      </button>
      <button type="button" class="chipX chipXStandalone" data-mrm="${formatting._esc(chip.removeKey || chip.key)}" title="Verwijder" aria-label="Verwijder materiaal">🗑️</button>
    </div>`;
      })
      .join("");
    panelElements.matChosen.innerHTML = `<div class="chipRow">${chipsHtml}</div>`;
    panelElements.matChosen.querySelectorAll("[data-mkey]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const k = btn.getAttribute("data-mkey");
        if (k) materialIntents.activate(k);
      });
    });
    panelElements.matChosen.querySelectorAll("[data-mrm]").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        const rm = btn.getAttribute("data-mrm") || "";
        if (!rm) return;
        try {
          if (ToolAPanelsEntry) ToolAPanelsEntry.removeMaterial(rm);
          else materialIntents.remove(rm);
        } catch (_) {
          materialIntents.remove(rm);
        }
      });
    });
    renderGrainByMaterial();
    renderMaterialBatchesStep2();
    foundation.current?.renderMobileMaterialCart?.(applicationState.current);
  }

  function renderMaterialBatchesStep2() {
    configurationState.ensureStateShape();
    const elWrap = document.getElementById("matChosenStep2");
    const el = document.getElementById("matChosenStep2Chips");
    if (!elWrap || !el) return;

    const chips =
      ToolAPanelsViewModels &&
      typeof ToolAPanelsViewModels.getMaterialChipModels === "function"
        ? ToolAPanelsViewModels.getMaterialChipModels(applicationState.current, {
            titleForBatch: (b) =>
              String(
                (b?.mat && (b.mat.productName || b.mat.articleNumber || b.mat.decorName)) ||
                  b?.key ||
                  "",
              ),
          })
        : (applicationState.current.materialBatches || []).map((b) => ({
            key: b.key,
            title: String(
              (b?.mat && (b.mat.productName || b.mat.articleNumber || b.mat.decorName)) ||
                b?.key ||
                "",
            ),
            active: b.key === applicationState.current.activeMaterialKey,
            removeKey: b.key,
          }));
    if (chips.length === 0) {
      elWrap.style.display = "none";
      el.innerHTML = "";
      return;
    }
    elWrap.style.display = "";
    const chipsHtml = chips
      .map((chip) => {
        const title = formatting._esc(String(chip.title || chip.key || ""));
        return `<div class="chipItem">
      <button type="button" class="chip ${chip.active ? "chipActive" : ""}" data-mkey="${formatting._esc(chip.key)}" title="${title}">
        <span class="chipDot"></span>
        <span class="chipTxt">${title}</span>
      </button>
      <button type="button" class="chipX chipXStandalone" data-mrm="${formatting._esc(chip.removeKey || chip.key)}" title="Verwijder" aria-label="Verwijder materiaal">🗑️</button>
    </div>`;
      })
      .join("");
    const rowClass = "chipRow chipRowStep2";
    el.innerHTML = `<div class="${rowClass}">${chipsHtml}</div>`;

    el.querySelectorAll("[data-mkey]").forEach((btn) => {
      btn.addEventListener("click", () => {
        const k = btn.getAttribute("data-mkey");
        if (k) materialIntents.activate(k);
      });
    });
    el.querySelectorAll("[data-mrm]").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        const rm = btn.getAttribute("data-mrm") || "";
        if (!rm) return;
        try {
          if (ToolAPanelsEntry) ToolAPanelsEntry.removeMaterial(rm);
          else materialIntents.remove(rm);
        } catch (_) {
          materialIntents.remove(rm);
        }
      });
    });
    renderGrainByMaterial();
  }

  function clearPanelGrainAssignmentsForMaterial(materialKeyValue) {
    const key = String(materialKeyValue || "");
    (applicationState.current.cart || []).forEach((it) => {
      const mk = String(
        it?.materialKey || it?.articleNumber || it?.materialCode || "",
      ).trim();
      if (mk !== key || !it || typeof it !== "object") return;
      it.grainGroupId = null;
      it.grainOrder = null;
    });
    (applicationState.current.extraPanels || []).forEach((panel) => {
      const mk = String(
        panel?.materialKey || panel?.articleNumber || panel?.materialCode || "",
      ).trim();
      if (mk !== key || !Array.isArray(panel?.grainAssignments)) return;
      panel.grainAssignments.forEach((assignment) => {
        if (!assignment || typeof assignment !== "object") return;
        assignment.grainGroupId = null;
        assignment.grainOrder = null;
      });
    });
  }

  function renderGrainByMaterial() {
    try {
      configurationState.ensureStateShape();
      const wrap = document.getElementById("grainByMaterialList");
      if (!wrap) return;

      const batches = applicationState.current.materialBatches || [];
      if (batches.length === 0) {
        wrap.innerHTML = "";
        return;
      }

      const rows = batches.map((b) => {
        const k = String(b.key || "");
        const name = b.mat ? materialIdentity.materialLabelMat(b.mat) : k;
        const checked = typeof b.grainEnabled === "boolean" ? b.grainEnabled : true;
        const isActive = k === applicationState.current.activeMaterialKey;
        return `
        <div class="grainRow tool-runtime-grain-row ${isActive ? "is-active" : ""}" data-mkey="${formatting._esc(k)}">
          <div class="u-row-spread-center">
            <div class="u-weight-700">${formatting._esc(name)}</div>
            <button class="miniMatPick u-button-compact" data-mpick="${formatting._esc(k)}">Actief</button>
          </div>
          <div class="u-review-heading-row">
            <div class="u-material-summary-column">
              <div class="u-weight-700">Nerfrichting</div>
              <div class="u-help-muted">${checked ? "Doorlopende nerf actief. Panelen mogen niet roteren." : "Vrij roteren actief. Panelen mogen 90° draaien voor optimalisatie."}</div>
            </div>
            <div class="grainChoice u-review-details-grid" data-gkey="${formatting._esc(k)}" role="group" aria-label="Nerfrichting voor ${formatting._esc(name)}">
              <button type="button" class="grainChoiceBtn tool-runtime-grain-choice ${checked ? "is-active" : ""}" data-gval="on" aria-pressed="${checked ? "true" : "false"}">
                <span class="u-weight-800">Ja, toepassen</span>
                <span class="u-caption-dimmed">Niet roteren</span>
              </button>
              <button type="button" class="grainChoiceBtn tool-runtime-grain-choice ${checked ? "" : "is-active"}" data-gval="off" aria-pressed="${checked ? "false" : "true"}">
                <span class="u-weight-800">Nee, vrij roteren</span>
                <span class="u-caption-dimmed">90° draaien toegestaan</span>
              </button>
            </div>
          </div>
        </div>
      `;
      });

      wrap.innerHTML = rows.join("");

      // Activate material button
      wrap.querySelectorAll(".miniMatPick").forEach((btn) => {
        btn.addEventListener("click", () => {
          const key = btn.getAttribute("data-mpick") || "";
          if (key) materialIntents.activate(key);
        });
      });

      // Per-material grain toggle
      wrap.querySelectorAll(".grainChoice").forEach((group) => {
        group.querySelectorAll(".grainChoiceBtn").forEach((btn) => {
          btn.addEventListener("click", () => {
            const key = group.getAttribute("data-gkey") || "";
            const next = (btn.getAttribute("data-gval") || "on") === "on";

            // Update batch setting
            const b = (applicationState.current.materialBatches || []).find(
              (x) => String(x.key || "") === String(key),
            );
            if (b) b.grainEnabled = next;

            // If turned OFF: clear any existing grain assignments/groups bound to this material
            if (next === false) {
              clearPanelGrainAssignmentsForMaterial(key);
              if (
                applicationState.current.grain &&
                Array.isArray(applicationState.current.grain.groups)
              ) {
                applicationState.current.grain.groups =
                  applicationState.current.grain.groups.filter(
                    (g) => String(g.materialKey || "") !== String(key),
                  );
                if (applicationState.current.grain.selectedGroupId) {
                  const ok = applicationState.current.grain.groups.some(
                    (g) =>
                      String(g.id || "") ===
                      String(applicationState.current.grain.selectedGroupId),
                  );
                  if (!ok)
                    applicationState.current.grain.selectedGroupId =
                      applicationState.current.grain.groups[0]?.id || null;
                }
              }
            }

            // Keep legacy shortcut in sync for currently active material
            if (String(key) === String(applicationState.current.activeMaterialKey)) {
              applicationState.current.grainEnabled = next;
            }

            feedback.scheduleDraftSave();
            updateButtons();
            renderGrainByMaterial();
          });
        });
      });
    } catch (e) {
      console.warn("renderGrainByMaterial failed", e);
    }
  }

  function updateButtons() {
    let __ui = null;
    try {
      if (ToolAPanelUiState?.getControlsState)
        __ui = ToolAPanelUiState.getControlsState(applicationState.current);
    } catch (_) {
      __ui = null;
    }
    const ready = __ui ? !!__ui.ready : applicationState.current.route === "metod";
    const hasMaterial = __ui
      ? !!__ui.hasMaterial
      : !!(
          applicationState.current.material &&
          (applicationState.current.activeMaterialKey ||
            applicationState.current.material.materialCode ||
            applicationState.current.material.articleNumber ||
            applicationState.current.material.decorName)
        );
    const fallbackState = __ui || {
      ready,
      hasMaterial,
      enablePanels: !!(ready && hasMaterial),
      addEnabled: !!(
        ready &&
        hasMaterial &&
        applicationState.current.selection.type &&
        applicationState.current.selection.templateId
      ),
      grainEnabled: !!(ready && hasMaterial),
      grainNextEnabled: !!(
        ready &&
        hasMaterial &&
        (applicationState.current.cart.length > 0 ||
          applicationState.current.extraPanels.length > 0)
      ),
      extraOverlayEnabled: !!(ready && hasMaterial),
      overviewEnabled: !!(
        ready &&
        (applicationState.current.cart.length > 0 ||
          applicationState.current.extraPanels.length > 0)
      ),
    };

    if (ToolAPanelControlsApply?.apply) {
      ToolAPanelControlsApply.apply({
        state: fallbackState,
        refs: {
          panelControls: [
            panelElements.typeSel,
            panelElements.sizeSel,
            panelElements.qty,
            panelElements.hingeSel,
            panelElements.extTop,
            panelElements.extBot,
            panelElements.edgeSel,
          ],
          matSearch: panelElements.matSearch,
          grainToggle: panelElements.grainToggle,
          addBtn: panelElements.addBtn,
          grainBtn: panelElements.grainBtn,
          extraOverlayBtn: panelElements.extraOverlayBtn,
          overviewBtn: panelElements.overviewBtn,
        },
      });
      return;
    }

    const enablePanels = !!fallbackState.enablePanels;
    [
      panelElements.typeSel,
      panelElements.sizeSel,
      panelElements.qty,
      panelElements.hingeSel,
      panelElements.extTop,
      panelElements.extBot,
      panelElements.edgeSel,
    ].forEach((el) => {
      if (el) el.disabled = !enablePanels;
    });
    if (panelElements.matSearch) panelElements.matSearch.disabled = !ready;
    if (panelElements.grainToggle)
      panelElements.grainToggle.disabled = !fallbackState.grainEnabled;
    if (panelElements.addBtn) panelElements.addBtn.disabled = !fallbackState.addEnabled;
    if (panelElements.grainBtn)
      panelElements.grainBtn.disabled = !fallbackState.grainNextEnabled;
    if (panelElements.extraOverlayBtn)
      panelElements.extraOverlayBtn.disabled = !fallbackState.extraOverlayEnabled;
    if (panelElements.overviewBtn)
      panelElements.overviewBtn.disabled = !fallbackState.overviewEnabled;
  }

  return Object.freeze({
    updateButtons,
    renderMaterialBatches,
    renderGrainByMaterial,
    renderMaterialBatchesStep2,
  });
}
