import { ToolAAlertHelpers } from "../../domain/safe-helper-layer.js";
/** alert-dialog: one runtime owner with explicit, immutable dependency ports. */
export function createAlertDialog({ foundation } = {}) {
  function priceOverlayTotalElement() {
    return (
      document.getElementById("priceOverlayTotal") ||
      document.getElementById("priceTotalValue")
    );
  }

  function showToolAlert(raw, fallbackTitle) {
    try {
      if (
        ToolAAlertHelpers &&
        typeof ToolAAlertHelpers.showToolAlert === "function"
      ) {
        return ToolAAlertHelpers.showToolAlert(raw, fallbackTitle);
      }
    } catch (err) {
      console.warn("showToolAlert failed", err);
    }
  }

  function showToolAlertHardFallback(opts) {
    try {
      const owner = foundation.current;
      if (owner && typeof owner.showToolAlertHardFallback === "function") {
        return owner.showToolAlertHardFallback(opts);
      }
    } catch (_) {
      return false;
    }
    return false;
  }

  function showToolAlertHardFallbackAsync(opts) {
    {
      const owner = foundation.current;
      if (owner && typeof owner.showToolAlertHardFallbackAsync === "function") {
        return owner.showToolAlertHardFallbackAsync(opts);
      }
    }
    return Promise.resolve(false);
  }

  function mount() {
    window.showToolAlert = showToolAlert;
    window.alert = function (message) {
      showToolAlert(message, "Waarschuwing");
    };
    window.showToolAlertHardFallback = showToolAlertHardFallback;
    window.showToolAlertHardFallbackAsync = showToolAlertHardFallbackAsync;
  }

  return Object.freeze({
    showToolAlertHardFallbackAsync,
    showToolAlert,
    showToolAlertHardFallback,
    mount,
  });
}
