/** dom-lookup: one runtime owner with explicit, immutable dependency ports. */
export function createDomLookup({} = {}) {
  function byId(id) {
    return document.getElementById(id);
  }

  return Object.freeze({
    byId,
  });
}
