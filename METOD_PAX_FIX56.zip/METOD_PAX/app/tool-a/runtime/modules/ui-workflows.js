/** ui-workflows: one runtime owner with explicit, immutable dependency ports. */
export function createUiWorkflows({
  extraEditor,
  grainModel,
  materialBatches,
  materialIntents,
  overviewOverlay,
  panelEditController,
  panelIntents,
  viewRefresh,
} = {}) {
  function initialize() {
    panelIntents.bind(panelEditController.startEditCartItem);
    materialIntents.bind({
      activate: materialBatches.setActiveMaterial,
      remove: materialBatches.removeMaterialBatch,
    });
    viewRefresh.bind({
      extraPanels: extraEditor.renderExtraPanels,
      overview: overviewOverlay.renderOverviewSafe,
      grainEligible: grainModel.rebuildGrainEligible,
      grainWidths: grainModel.rebuildGrainWidthOptions,
    });
  }

  return Object.freeze({
    initialize,
  });
}
