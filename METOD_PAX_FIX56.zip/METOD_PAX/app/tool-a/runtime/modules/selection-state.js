/** selection-state: one runtime owner with explicit, immutable dependency ports. */
export function createSelectionState({} = {}) {
  let current;
  let attached;

  function update(patch) {
    if (!attached) throw new Error("Panel selection has not been attached");
    if (!patch || typeof patch !== "object" || Array.isArray(patch)) {
      throw new TypeError("Panel selection update must be a record");
    }
    const allowed = [
      "type",
      "templateId",
      "qty",
      "hinge",
      "extTop",
      "extBot",
      "material",
      "edge",
      "materialKey",
      "materialName",
      "customLabel",
    ];
    const next = { ...current };
    for (const key of Object.keys(patch)) {
      if (!allowed.includes(key)) throw new TypeError("Unknown panel selection field: " + key);
      const value = patch[key];
      if (
        value !== null &&
        value !== undefined &&
        typeof value !== "string" &&
        !(typeof value === "number" && Number.isFinite(value))
      ) {
        throw new TypeError("Invalid panel selection value: " + key);
      }
      next[key] = value;
    }
    current = Object.freeze(next);
    return current;
  }

  function attach(state) {
    if (!state || typeof state !== "object") throw new TypeError("Configuration state is required");
    if (attached) {
      if (attached !== state)
        throw new Error("Panel selection already belongs to another configuration");
      return current;
    }
    const initial = state.selection || {};
    // Validate before installing an irreversible property descriptor.
    attached = state;
    try {
      update(initial);
    } catch (error) {
      attached = undefined;
      throw error;
    }
    Object.defineProperty(state, "selection", {
      enumerable: true,
      configurable: false,
      get() {
        return current;
      },
      set() {
        throw new TypeError("Use panel selection commands");
      },
    });
    return current;
  }

  return Object.freeze({
    update,
    attach,
  });
}
