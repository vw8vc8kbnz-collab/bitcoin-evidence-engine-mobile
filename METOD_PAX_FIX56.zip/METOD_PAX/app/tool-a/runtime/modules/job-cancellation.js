import {
  isJobCancellationConfirmed,
  isRequestCancellationConfirmed,
} from "../../api/cancellation-response.js";

const FAILURE_MESSAGES = Object.freeze({
  unconfirmed: "Annuleren kon niet worden bevestigd.",
  timeout: "De server reageerde niet op tijd om de annulering te bevestigen.",
  missingToken:
    "De beveiligde annuleercode ontbreekt. De aanvraag is niet gewist.",
  unavailable: "De annuleerfunctie voor de berekening is niet geladen.",
});

class CancellationFailure extends Error {
  constructor(code = "unconfirmed") {
    super(FAILURE_MESSAGES[code] || FAILURE_MESSAGES.unconfirmed);
  }
}

function failureCode(error) {
  return error?.metodTimeout === true ||
    (error?.metodRequestTimeout === true && error?.operation === "job_cancel")
    ? "timeout"
    : "unconfirmed";
}

/** job-cancellation: one runtime owner with explicit, immutable dependency ports. */
export function createJobCancellation({
  alertDialog,
  applicationState,
  calculationView,
  domLookup,
  foundation,
  materialSelectionView,
  overlayControls,
  overviewOverlay,
  panelList,
  submission,
  viewRefresh,
  wizardNavigation,
} = {}) {
  let cancelHandlerBound = false;

  async function _postJsonWithDeadline(
    url,
    payload,
    timeoutMs = submission.CLIENT_MUTATION_DEADLINE_MS,
  ) {
    const deadlineMs = Math.max(
      250,
      Number(timeoutMs) || submission.CLIENT_MUTATION_DEADLINE_MS,
    );
    const controller =
      typeof AbortController === "function" ? new AbortController() : null;
    let timer = null;
    let timedOut = false;
    const deadline = new Promise((_, reject) => {
      timer = setTimeout(() => {
        timedOut = true;
        try {
          controller?.abort();
        } catch (_) {
          ToolAErrors.recover(
            "tool.a.runtime.modules.job.cancellation.js.4",
            _,
            ["AbortError", "InvalidStateError"],
          );
        }
        const error = new Error(
          "De server reageerde niet op tijd. Controleer je verbinding en probeer opnieuw.",
        );
        error.isUserFacing = true;
        error.metodTimeout = true;
        reject(error);
      }, deadlineMs);
    });
    try {
      const response = await Promise.race([
        fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload || {}),
          ...(controller ? { signal: controller.signal } : {}),
        }),
        deadline,
      ]);
      const raw =
        response && typeof response.text === "function"
          ? await Promise.race([response.text(), deadline])
          : "";
      let data = null;
      try {
        data = raw ? JSON.parse(raw) : null;
      } catch (_) {
        data = null;
      }
      return { response, data };
    } catch (error) {
      if (timedOut || error?.name === "AbortError") {
        const timeoutError = new Error(
          "De server reageerde niet op tijd. Controleer je verbinding en probeer opnieuw.",
        );
        timeoutError.isUserFacing = true;
        timeoutError.metodTimeout = true;
        throw timeoutError;
      }
      throw error;
    } finally {
      if (timer != null) clearTimeout(timer);
    }
  }

  async function _readJobConfirmation(response) {
    if (!response || typeof response.json !== "function") return null;
    let timer = null;
    try {
      return await Promise.race([
        response.json(),
        new Promise((resolve) => {
          timer = setTimeout(() => resolve(null), 2000);
        }),
      ]);
    } catch (_) {
      return null;
    } finally {
      if (timer != null) clearTimeout(timer);
    }
  }

  async function _markJobCancelled(jobId) {
    try {
      if (!jobId) return { ok: true, skipped: true };
      const token =
        applicationState.current.lastJobAccessToken ||
        window.__metod_last_job_access_token ||
        null;
      const owner = foundation.current;
      if (!owner || typeof owner.cancelJob !== "function") {
        return { ok: false, code: "unavailable" };
      }
      const response = await owner.cancelJob({
        jobId,
        accessToken: token,
        reason: "customer_cancelled",
      });
      const data = await _readJobConfirmation(response);
      return { ok: isJobCancellationConfirmed(response, data, jobId) };
    } catch (error) {
      return { ok: false, code: failureCode(error) };
    }
  }

  async function _markRequestCancelled(requestId, cancelToken) {
    try {
      if (!requestId) return { ok: true, skipped: true };
      if (!cancelToken) return { ok: false, code: "missingToken" };
      const { response, data } = await _postJsonWithDeadline("/api/cancel", {
        requestId,
        cancelToken,
      });
      return { ok: isRequestCancellationConfirmed(response, data, requestId) };
    } catch (error) {
      return { ok: false, code: failureCode(error) };
    }
  }

  async function _resetConfigurationHard() {
    try {
      sessionStorage.setItem("metod_fresh_configuration_v1", "1");
    } catch (_) {
      ToolAErrors.recover("tool.a.runtime.modules.job.cancellation.js.30", _, [
        "SecurityError",
        "QuotaExceededError",
        "SyntaxError",
      ]);
    }
    window.__metodInvalidateAuthoritativePriceHydration?.();
    window.__metod_price_locked = false;
    window.__metod_active_parent_job_id = null;
    window.__metod_last_parent_job_id = null;
    window.__metod_last_job_id = null;
    window.__metod_last_job_access_token = null;
    window.__metod_last_request_id = null;
    window.__metod_last_request_cancel_token = null;
    window.__metod_price_validated_key = null;
    window.__metod_submit_inflight = false;
    window.__metod_submit_done = false;
    window.__metod_submitted_parent_job_id = null;
    submission._setFinalSubmissionUncertain("", false);
    if (foundation.current && typeof foundation.current.resetFinalSubmission === "function")
      foundation.current.resetFinalSubmission();
    if (foundation.current && typeof foundation.current.resetJobRecovery === "function")
      foundation.current.resetJobRecovery();

    try {
      localStorage.removeItem("metod_draft_v1");
    } catch (_) {
      ToolAErrors.recover("tool.a.runtime.modules.job.cancellation.js.17", _, [
        "SecurityError",
        "QuotaExceededError",
        "SyntaxError",
      ]);
    }
    try {
      localStorage.removeItem("metod_draft");
    } catch (_) {
      ToolAErrors.recover("tool.a.runtime.modules.job.cancellation.js.13", _, [
        "SecurityError",
        "QuotaExceededError",
        "SyntaxError",
      ]);
    }
    try {
      localStorage.removeItem("metod_last_request_id");
    } catch (_) {
      ToolAErrors.recover("tool.a.runtime.modules.job.cancellation.js.25", _, [
        "SecurityError",
        "QuotaExceededError",
        "SyntaxError",
      ]);
    }
    try {
      localStorage.removeItem("metod_last_request_cancel_token");
    } catch (_) {
      ToolAErrors.recover("tool.a.runtime.modules.job.cancellation.js.31", _, [
        "SecurityError",
        "QuotaExceededError",
        "SyntaxError",
      ]);
    }
    try {
      localStorage.removeItem("metod_last_parent_job_id");
    } catch (_) {
      ToolAErrors.recover("tool.a.runtime.modules.job.cancellation.js.27", _, [
        "SecurityError",
        "QuotaExceededError",
        "SyntaxError",
      ]);
    }
    try {
      sessionStorage.removeItem("metod_last_request_id");
      sessionStorage.removeItem("metod_last_request_cancel_token");
      sessionStorage.removeItem("metod_last_parent_job_id");
      sessionStorage.removeItem("metod_last_job_access_token");
      sessionStorage.removeItem("metod_pending_job_start_v1");
      sessionStorage.removeItem("metod_running_job_v1");
      sessionStorage.removeItem(submission.FINAL_SUBMISSION_UNCERTAIN_KEY);
      localStorage.removeItem("metod_last_job_access_token");
    } catch (_) {
      ToolAErrors.recover("tool.a.runtime.modules.job.cancellation.js.64", _, [
        "SecurityError",
        "QuotaExceededError",
        "SyntaxError",
      ]);
    }

    if (window.state) {
      if (Array.isArray(applicationState.current.cart))
        applicationState.current.cart.length = 0;
      if (Array.isArray(applicationState.current.extraPanels))
        applicationState.current.extraPanels.length = 0;
      if (Array.isArray(applicationState.current.materials))
        applicationState.current.materials.length = 0;
      if (Array.isArray(applicationState.current.materialBatches))
        applicationState.current.materialBatches.length = 0;
      else applicationState.current.materialBatches = [];
      if (applicationState.current.grain) {
        if (Array.isArray(applicationState.current.grain.groups))
          applicationState.current.grain.groups.length = 0;
        applicationState.current.grain.selectedGroupId = null;
        applicationState.current.grain.materialKey = null;
        applicationState.current.grain.includeExtraPanels = false;
      }
      // Calculation snapshots may be frozen. Drop the references after confirmed
      // cancellation instead of mutating the snapshot shared with the review.
      applicationState.current.customer = {};
      if (applicationState.current.checkout) applicationState.current.checkout.customer = {};
      if (
        applicationState.current.checkout &&
        applicationState.current.checkout.customerSnapshot
      )
        applicationState.current.checkout.customerSnapshot = null;
      if (
        applicationState.current.checkout &&
        applicationState.current.checkout.reviewSnapshot
      )
        applicationState.current.checkout.reviewSnapshot = null;
      foundation.current?.clearCheckoutCalculationSnapshot?.({
        state: applicationState.current,
      });
      if (applicationState.current.checkout) applicationState.current.checkout.note = "";
      applicationState.current.lastCalculatedCustomer = null;
      applicationState.current.activeMaterialKey = null;
      applicationState.current.material = null;
      applicationState.current.activeMaterial = null;
      applicationState.current.lastQuote = null;
      applicationState.current.finalAuthoritativePriceInclVat = null;
      applicationState.current.finalAuthoritativeJobId = null;
      applicationState.current.quote = null;
      applicationState.current.quoteRaw = null;
      applicationState.current.lastJobResult = null;
      applicationState.current.lastPricingSummary = null;
      applicationState.current.lastGrainPreviewAttestation = null;
      applicationState.current.activeAuthoritativeJobId = null;
      applicationState.current.authoritativePricingReady = false;
      applicationState.current.lastParentJobId = null;
      applicationState.current.lastSubjobs = [];
      applicationState.current.lastJobId = null;
      applicationState.current.jobId = null;
    }

    window.__metod_checkout_live_customer = null;
    if (typeof window.__metodClearCustomerConfiguration === "function")
      window.__metodClearCustomerConfiguration();

    closeCancelRequestDialog();
    try {
      overlayControls.closePriceOverlay();
    } catch (_) {
      {
        const po = domLookup.byId("priceOverlay");
        if (po) po.style.display = "none";
      }
    }

    if (typeof materialSelectionView.renderMaterialBatches === "function")
      materialSelectionView.renderMaterialBatches();
    if (typeof materialSelectionView.renderMaterialBatchesStep2 === "function")
      materialSelectionView.renderMaterialBatchesStep2();
    if (typeof materialSelectionView.renderGrainByMaterial === "function")
      materialSelectionView.renderGrainByMaterial();
    if (typeof panelList.renderCart === "function") panelList.renderCart();
    if (typeof viewRefresh.extraPanels === "function") viewRefresh.extraPanels();
    if (typeof overviewOverlay.renderOverviewSafe === "function")
      overviewOverlay.renderOverviewSafe();
    else if (typeof overviewOverlay.renderOverview === "function")
      overviewOverlay.renderOverview();
    if (typeof wizardNavigation.setStep === "function") wizardNavigation.setStep("material");
    try {
      window.scrollTo({ top: 0, behavior: "instant" });
    } catch (_) {
      try {
        window.scrollTo(0, 0);
      } catch (__) {
        ToolAErrors.recover("tool.a.runtime.modules.job.cancellation.js.5", __, [
          "NotSupportedError",
          "InvalidStateError",
        ]);
      }
    }

    try {
      const freshUrl = new URL(location.href);
      freshUrl.searchParams.set("_freshConfig", String(Date.now()));
      setTimeout(() => {
        try {
          location.replace(freshUrl.toString());
        } catch (_) {
          location.reload();
        }
      }, 40);
    } catch (_) {
      location.reload();
    }
  }

  function closeCancelRequestDialog() {
    {
      const overlay = domLookup.byId("cancelRequestOverlay");
      const confirmBtn = domLookup.byId("cancelRequestConfirmBtn");
      if (confirmBtn) confirmBtn.disabled = false;
      if (!overlay) return;
      overlay.classList.remove("isOpen");
      setTimeout(() => {
        overlay.style.display = "none";
      }, 120);
    }
  }

  async function confirmCancelRequest() {
    if (submission._isFinalSubmissionInFlight()) {
      calculationView.statusMsg(
        "Wacht tot de server het verzenden heeft bevestigd. Annuleren is daarna weer beschikbaar als het verzenden mislukt.",
        true,
      );
      submission._setCancelConfigAvailable(false);
      return false;
    }
    if (submission._hasUncertainFinalSubmission()) {
      calculationView.statusMsg(
        "De verzendstatus is nog niet bevestigd. Bevestig exact dezelfde aanvraag opnieuw voordat je wist of annuleert.",
        true,
      );
      submission._setCancelConfigAvailable(false);
      return false;
    }
    {
      const confirmBtn = domLookup.byId("cancelRequestConfirmBtn");
      if (confirmBtn) confirmBtn.disabled = true;
    }
    submission.cancelBtn && (submission.cancelBtn.disabled = true);
    const jobIdRaw = String(
      window.__metod_last_parent_job_id ||
        window.__metod_last_job_id ||
        (applicationState.current &&
          (applicationState.current.lastParentJobId ||
            applicationState.current.lastJobId ||
            applicationState.current.jobId)) ||
        "",
    );
    const jobId = jobIdRaw ? jobIdRaw.split("__mat_")[0] : "";
    const requestId = String(window.__metod_last_request_id || "");
    const cancelToken = String(window.__metod_last_request_cancel_token || "");
    let confirmationReceived = false;
    try {
      // Once a final request exists, its authenticated cancellation is the hard
      // gate. Never erase the only local reference after an offline/403/500 path.
      if (requestId) {
        const requestOutcome = await _markRequestCancelled(
          requestId,
          cancelToken,
        );
        if (!requestOutcome?.ok)
          throw new CancellationFailure(requestOutcome?.code);
        // The request is now durably cancelled; stopping the completed/source job
        // remains best effort and may not undo that successful request transition.
        await _markJobCancelled(jobId);
      } else if (jobId) {
        const jobOutcome = await _markJobCancelled(jobId);
        if (!jobOutcome?.ok) throw new CancellationFailure(jobOutcome?.code);
      }
      confirmationReceived = true;
      await _resetConfigurationHard();
      return true;
    } catch (error) {
      const message = confirmationReceived
        ? "De annulering is bevestigd, maar opnieuw starten lukte niet."
        : error instanceof CancellationFailure
          ? error.message
          : FAILURE_MESSAGES.unconfirmed;
      const details = confirmationReceived
        ? "Herlaad de pagina om een nieuwe configuratie te starten."
        : "Je gegevens zijn behouden. Probeer het opnieuw.";
      calculationView.statusMsg(`${message} ${details}`, true);
      {
        const confirmBtn = domLookup.byId("cancelRequestConfirmBtn");
        if (confirmBtn) confirmBtn.disabled = false;
      }
      submission._setCancelConfigAvailable(true);

      alertDialog.showToolAlertHardFallback({
        title: confirmationReceived
          ? "Opnieuw starten"
          : "Annuleren niet bevestigd",
        body: message,
        details,
      });

      return false;
    }
  }

  function openCancelRequestDialog() {
    if (submission._isFinalSubmissionInFlight()) {
      submission._setCancelConfigAvailable(false);
      calculationView.statusMsg(
        "Wacht tot de server het verzenden heeft bevestigd. Annuleren is nu tijdelijk uitgeschakeld.",
        true,
      );
      return false;
    }
    if (submission._hasUncertainFinalSubmission()) {
      submission._setCancelConfigAvailable(false);
      calculationView.statusMsg(
        "De verzendstatus is nog niet bevestigd. Bevestig exact dezelfde aanvraag opnieuw voordat je wist of annuleert.",
        true,
      );
      return false;
    }
    const overlay = domLookup.byId("cancelRequestOverlay");
    const confirmBtn = domLookup.byId("cancelRequestConfirmBtn");
    const keepBtn = domLookup.byId("cancelRequestKeepBtn");
    if (!overlay || !confirmBtn || !keepBtn) {
      const ok = confirm(
        "Wil je de aanvraag echt stoppen?\n\nAlles wat je hebt ingevuld wordt verwijderd en je gaat terug naar stap 1.\n\nDit kan niet ongedaan worden gemaakt.",
      );
      if (ok) confirmCancelRequest();
      return true;
    }
    overlay.style.display = "flex";
    requestAnimationFrame(() => {
      overlay.classList.add("isOpen");
      try {
        confirmBtn.focus();
      } catch (_) {
        ToolAErrors.recover("tool.a.runtime.modules.job.cancellation.js.3", _, [
          "NotSupportedError",
          "InvalidStateError",
        ]);
      }
    });
    confirmBtn.onclick = function (ev) {
      ev.preventDefault();
      ev.stopPropagation();
      if (confirmBtn.disabled) return false;
      confirmCancelRequest();
      return false;
    };
    keepBtn.onclick = function (ev) {
      ev.preventDefault();
      ev.stopPropagation();
      closeCancelRequestDialog();
      return false;
    };
    if (!overlay.__boundBackdrop) {
      overlay.__boundBackdrop = true;
      overlay.addEventListener("click", (ev) => {
        if (ev.target === overlay) closeCancelRequestDialog();
      });
    }
    if (!overlay.__boundEsc) {
      overlay.__boundEsc = true;
      document.addEventListener("keydown", (ev) => {
        if (ev.key === "Escape" && overlay.style.display !== "none")
          closeCancelRequestDialog();
      });
    }
    return true;
  }

  function bindCancelConfigButtonHard(btn) {
    if (!btn) return;
    const available =
      !submission._isFinalSubmissionInFlight() && !submission._hasUncertainFinalSubmission();
    btn.disabled = !available;
    btn.setAttribute("aria-disabled", available ? "false" : "true");
    btn.style.setProperty("pointer-events", available ? "auto" : "none", "important");
    btn.onclick = function (ev) {
      ev.preventDefault();
      ev.stopPropagation();
      ev.stopImmediatePropagation && ev.stopImmediatePropagation();
      if (
        submission._isFinalSubmissionInFlight() ||
        submission._hasUncertainFinalSubmission()
      ) {
        submission._setCancelConfigAvailable(false);
        calculationView.statusMsg("Wacht tot het verzenden is bevestigd.", true);
        return false;
      }
      openCancelRequestDialog();
      return false;
    };
    btn.__cancelFlowBound = true;
  }

  function connect() {
    window.__metodSetCancelConfigAvailable = submission._setCancelConfigAvailable;
    window.__metodResetConfigurationHard = _resetConfigurationHard;
    if (submission.cancelBtn) {
      bindCancelConfigButtonHard(submission.cancelBtn);
    }
    if (!cancelHandlerBound) {
      cancelHandlerBound = true;
      document.addEventListener(
        "click",
        function (ev) {
          const btn =
            ev && ev.target && ev.target.closest
              ? ev.target.closest("#cancelConfigBtn, #btnCancelConfig")
              : null;
          if (!btn) return;
          ev.preventDefault();
          ev.stopPropagation();
          ev.stopImmediatePropagation && ev.stopImmediatePropagation();
          if (
            submission._isFinalSubmissionInFlight() ||
            submission._hasUncertainFinalSubmission()
          ) {
            submission._setCancelConfigAvailable(false);
            calculationView.statusMsg("Wacht tot het verzenden is bevestigd.", true);
            return false;
          }
          bindCancelConfigButtonHard(btn);
          openCancelRequestDialog();
          return false;
        },
        true,
      );
    }
    window.bindCancelConfigButtonHard = bindCancelConfigButtonHard;
  }

  return Object.freeze({
    connect,
  });
}
