import { ToolACustomerValidation } from "../../domain/customer-validation.js";
/** customer-validation: one runtime owner with explicit, immutable dependency ports. */
export function createCustomerValidation({ applicationState, customerForm, domLookup } = {}) {
  function _ensureFieldErrorEl(inp) {
    if (!inp) return null;
    const nxt = inp.nextElementSibling;
    if (nxt && nxt.classList && nxt.classList.contains("fieldErrorMsg")) return nxt;
    const d = document.createElement("div");
    d.className = "fieldErrorMsg";
    d.style.display = "none";
    inp.insertAdjacentElement("afterend", d);
    return d;
  }

  function _setFieldInvalid(inp, msg) {
    if (!inp) return;
    inp.classList.add("inpInvalid");
    inp.setAttribute("aria-invalid", "true");
    const el = _ensureFieldErrorEl(inp);
    if (el) {
      el.textContent = msg || "Dit veld is verplicht";
      el.style.display = "";
    }
  }

  function _clearFieldInvalid(inp) {
    if (!inp) return;
    inp.classList.remove("inpInvalid");
    inp.removeAttribute("aria-invalid");
    const nxt = inp.nextElementSibling;
    if (nxt && nxt.classList && nxt.classList.contains("fieldErrorMsg")) {
      nxt.style.display = "none";
      nxt.textContent = "";
    }
  }

  function _wireClearOnInput(inp) {
    if (!inp || inp.__reqBound) return;
    inp.addEventListener("input", () => {
      const value = String(inp.value || "").trim();
      const valid =
        inp.id === "custEmail" && ToolACustomerValidation?.isValidEmail
          ? ToolACustomerValidation.isValidEmail(value)
          : value.length > 0;
      if (valid) {
        _clearFieldInvalid(inp);
      }
    });
    inp.__reqBound = true;
  }

  function validateCustomerStepRequired() {
    customerForm.readCustomerFromUI();
    let __plan = null;
    try {
      if (
        ToolACustomerValidation &&
        typeof ToolACustomerValidation.getRequiredPlan === "function"
      ) {
        __plan = ToolACustomerValidation.getRequiredPlan({
          shipSameChecked: !!(
            domLookup.byId("custShipSame") && domLookup.byId("custShipSame").checked
          ),
        });
      }
    } catch (_) {
      __plan = null;
    }

    const ids =
      __plan && Array.isArray(__plan.baseIds) && __plan.baseIds.length
        ? __plan.baseIds.slice()
        : [
            "custFirstName",
            "custLastName",
            "custEmail",
            "custPhone",
            "custBillingAddress",
            "custPostcode",
            "custHouseNumber",
          ];
    const inps = ids.map((id) => domLookup.byId(id)).filter(Boolean);
    // shipping required only if "same as billing" is unchecked
    const shipSame = domLookup.byId("custShipSame");
    if (shipSame && !shipSame.__reqBound) {
      shipSame.addEventListener("change", () => {
        // If the user sets "same as billing", the complete shipping trio is copied
        // and no longer independently required.
        if (shipSame.checked) {
          ["custShippingAddress", "custShippingPostcode", "custShippingHouseNumber"].forEach(
            (id) => {
              const field = domLookup.byId(id);
              if (field) _clearFieldInvalid(field);
            },
          );
        }
      });
      shipSame.__reqBound = true;
    }
    const needShip = !!(__plan ? __plan.needShip : !(shipSame && shipSame.checked));
    if (needShip) {
      ["custShippingAddress", "custShippingPostcode", "custShippingHouseNumber"].forEach((id) => {
        const field = domLookup.byId(id);
        if (field) inps.push(field);
      });
    }

    // bind clear-on-input
    inps.forEach(_wireClearOnInput);

    // reset
    inps.forEach(_clearFieldInvalid);

    let firstBad = null;

    function req(inp, label) {
      const v = String(inp.value || "").trim();
      if (!v) {
        _setFieldInvalid(inp, (label || "Dit veld") + " is verplicht");
        if (!firstBad) firstBad = inp;
        return false;
      }
      return true;
    }

    const labels = (__plan && __plan.labels) || {
      custFirstName: "Voornaam",
      custLastName: "Achternaam",
      custEmail: "E-mail",
      custPhone: "Telefoonnummer",
      custBillingAddress: "Factuuradres",
      custPostcode: "Postcode",
      custHouseNumber: "Huisnummer",
      custShippingAddress: "Bezorgadres",
      custShippingPostcode: "Postcode bezorgadres",
      custShippingHouseNumber: "Huisnummer bezorgadres",
    };
    const requiredOrder =
      __plan && Array.isArray(__plan.requiredIds) && __plan.requiredIds.length
        ? __plan.requiredIds.slice()
        : [
            "custFirstName",
            "custLastName",
            "custEmail",
            "custPhone",
            "custBillingAddress",
            "custPostcode",
            "custHouseNumber",
          ].concat(
            needShip
              ? ["custShippingAddress", "custShippingPostcode", "custShippingHouseNumber"]
              : [],
          );

    let ok = true;
    let canonicalResult = null;
    try {
      if (ToolACustomerValidation?.validateCustomer) {
        canonicalResult = ToolACustomerValidation.validateCustomer(
          applicationState.current?.checkout?.customer || {},
          { shipSameChecked: !needShip },
        );
      }
    } catch (_) {
      canonicalResult = null;
    }
    if (canonicalResult && Array.isArray(canonicalResult.errors)) {
      ok = canonicalResult.valid === true;
      canonicalResult.errors.forEach((error) => {
        const inp = domLookup.byId(error?.fieldId);
        if (inp) {
          _setFieldInvalid(inp, error?.message || labels[error?.fieldId]);
          if (!firstBad) firstBad = inp;
        }
      });
    } else {
      requiredOrder.forEach((id) => {
        const inp = domLookup.byId(id);
        if (inp) {
          ok = req(inp, labels[id]) && ok;
        }
      });
    }

    if (!ok && firstBad) {
      try {
        firstBad.scrollIntoView({ behavior: "smooth", block: "center" });
      } catch (_) {
        ToolAErrors.recover("tool.a.runtime.modules.customer.validation.js.4", _, [
          "NotSupportedError",
          "InvalidStateError",
        ]);
      }
      try {
        firstBad.focus({ preventScroll: true });
      } catch (_) {
        ToolAErrors.recover("tool.a.runtime.modules.customer.validation.js.3", _, [
          "NotSupportedError",
          "InvalidStateError",
        ]);
      }
    }
    if (ok) {
      customerForm.readCustomerFromUI();
    }
    return ok;
  }

  return Object.freeze({
    validateCustomerStepRequired,
  });
}
