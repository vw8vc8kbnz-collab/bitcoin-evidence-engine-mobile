/** feedback: one runtime owner with explicit, immutable dependency ports. */
export function createFeedback({
  applicationState,
  calculationView,
  configurationState,
  formatting,
} = {}) {
  let __draftSaveT;

  function scheduleDraftSave() {
    if (__draftSaveT) clearTimeout(__draftSaveT);
    calculationView.showSavingToast();
    __draftSaveT = setTimeout(() => {
      {
        configurationState.ensureStateShape();
        // customer data and capability tokens are never persisted in
        // browser durable storage. The authoritative calculation state remains
        // in memory for this tab and on the server once a job is accepted.
        try {
          localStorage.removeItem("metod_draft_v1");
          localStorage.removeItem("metod_draft");
        } catch (_) {
          ToolAErrors.recover("tool.a.runtime.modules.feedback.js.4", _, [
            "SecurityError",
            "QuotaExceededError",
            "SyntaxError",
          ]);
        }
        const el = document.getElementById("saveStatus");
        if (el) {
          el.classList.remove("isSaving", "hasText");
          el.textContent = "Concept opgeslagen";
          void el.offsetWidth;
          el.classList.add("hasText");
          setTimeout(() => {
            el.textContent = "";
            el.classList.remove("hasText");
          }, 1450);
        }
      }
    }, 250);
  }

  function updateWizardBanner() {
    {
      const step = window.__metod_uiStep || "material";
      if (step === "material" || step === "panels" || step === "customer") {
        const el0 = document.getElementById("wizardBanner");
        if (el0) el0.style.display = "none";
        return;
      }
    }

    {
      const el = document.getElementById("wizardBanner");
      if (!el) return;
      configurationState.ensureStateShape();
      const hasRoute = !!applicationState.current.route;
      const hasMat = !!(
        applicationState.current.material &&
        (applicationState.current.activeMaterialKey ||
          applicationState.current.material.materialCode ||
          applicationState.current.material.articleNumber ||
          applicationState.current.material.decorName)
      );
      const hasPanels =
        (applicationState.current.cart && applicationState.current.cart.length > 0) ||
        (applicationState.current.extraPanels && applicationState.current.extraPanels.length > 0);
      let msg = "";
      if (!hasRoute) {
        msg = "<b>Kies een systeem</b> om te starten.";
      } else if (!hasMat) {
        msg = "<b>Stap 1:</b> kies eerst een <b>materiaal</b>. Daarna kun je panelen toevoegen.";
      } else if (!hasPanels) {
        msg =
          "<b>Stap 2:</b> kies <b>type + maat</b> en klik <b>Toevoegen</b>. Panelen komen in het <b>actieve materiaal</b>.";
      } else {
        msg =
          "<b>Panelen klaar</b> — je kunt verder met <b>Doorlopende nerf</b> of <b>Volgende stap</b>.";
      }
      el.innerHTML = msg;
      el.style.display = "block";
    }
  }

  function flashWarn(msg) {
    {
      const step = window.__metod_uiStep || "material";
      if (step === "material" || step === "panels" || step === "customer") {
        return;
      }
    }

    {
      const el = document.getElementById("wizardBanner");
      if (!el) return;
      el.innerHTML = `<b class="u-color-warning">Let op:</b> ${formatting._esc(String(msg || ""))}`;
      el.style.display = "block";
      el.style.borderColor = "rgba(181,138,0,.35)";
      el.style.background = "rgba(181,138,0,.10)";
      clearTimeout(flashWarn._t);
      flashWarn._t = setTimeout(() => {
        updateWizardBanner();
      }, 3500);
    }
  }

  function mount() {
    __draftSaveT = null;
    window.scheduleDraftSave = scheduleDraftSave;
    window.updateWizardBanner = updateWizardBanner;
    window.flashWarn = flashWarn;
  }

  return Object.freeze({
    updateWizardBanner,
    scheduleDraftSave,
    flashWarn,
    mount,
  });
}
