import { REVISION } from "../../version.js";
import { ToolAGrainValidation } from "../../domain/grain-validation.js";
import { ToolAMaterialSwatchRenderer } from "../../domain/material-swatch-renderer.js";
/** grain-rendering: one runtime owner with explicit, immutable dependency ports. */
export function createGrainRendering({
  applicationState,
  configurationState,
  extraEditor,
  extraPreview,
  formatting,
  foundation,
  grainAssignments,
  grainData,
  panelEdges,
  panelEditSession,
  panelElements,
  panelList,
  templateCatalog,
  viewRefresh,
} = {}) {
  function getDragAfterElement(container, y) {
    const els = [...container.querySelectorAll(".groupItem:not(.dragging)")];
    let closest = { offset: Number.NEGATIVE_INFINITY, element: null };
    for (const child of els) {
      const box = child.getBoundingClientRect();
      const offset = y - (box.top + box.height / 2);
      if (offset < 0 && offset > closest.offset) {
        closest = { offset, element: child };
      }
    }
    return closest.element;
  }

  function ensureDropIndicator(container) {
    let ind = container.querySelector(".dropIndicator");
    if (!ind) {
      ind = document.createElement("div");
      ind.className = "dropIndicator";
      container.appendChild(ind);
    }
    return ind;
  }

  function removeDropIndicator(container) {
    const ind = container.querySelector(".dropIndicator");
    if (ind) ind.remove();
  }

  function syncSelectedGrainGroupForMaterial() {
    {
      configurationState.ensureStateShape();
      const selMk = grainData.grainOverlaySelectedMaterialKey();
      const list = (applicationState.current.grain.groups || []).filter(
        (g) => !selMk || String(g.materialKey || "") === String(selMk),
      );
      const selId = String(applicationState.current?.grain?.selectedGroupId || "");
      const ok = !!(selId && list.some((g) => String(g?.id || "") === selId));
      if (!ok) applicationState.current.grain.selectedGroupId = list[0]?.id || null;
    }
  }

  function newGroup() {
    // always allocate a unique stable group id, even after an earlier group was deleted.
    const usedIds = new Set(
      (applicationState.current.grain.groups || []).map((g) => String((g && g.id) || "")),
    );
    let nextNr = 1;
    while (usedIds.has(`G${String(nextNr).padStart(2, "0")}`)) nextNr++;
    const id = `G${String(nextNr).padStart(2, "0")}`;
    // A new set is intentionally width-neutral. It becomes locked only when its first
    // panel is added; otherwise a previous filter/group width hides every other width.
    if (panelElements.grainWidthSel) panelElements.grainWidthSel.value = "all";
    applicationState.current.grain.groups.push({
      id,
      widthMm: null,
      widthCm: null,
      items: [],
      materialKey: grainData.grainOverlaySelectedMaterialKey(),
    });
    applicationState.current.grain.selectedGroupId = id;
    viewRefresh.grainWidths();
    viewRefresh.grainEligible();
    rebuildGrainGroups();
    drawGrainPreview();
  }

  function rebuildGrainGroups() {
    if (
      window.ToolAGrainStudioMobile &&
      typeof window.ToolAGrainStudioMobile.isActive === "function" &&
      window.ToolAGrainStudioMobile.isActive() &&
      typeof window.ToolAGrainStudioMobile.renderGroups === "function"
    ) {
      return window.ToolAGrainStudioMobile.renderGroups();
    }

    if (!panelElements.grainGroups) return;
    panelElements.grainGroups.innerHTML = "";
    const selMk = grainData.grainOverlaySelectedMaterialKey();
    const list = (applicationState.current.grain.groups || []).filter(
      (g) => !selMk || String(g.materialKey || "") === String(selMk),
    );
    syncSelectedGrainGroupForMaterial();
    if (!list.length) {
      const div = document.createElement("div");
      div.className = "help";
      div.textContent =
        "Nog geen nerf-sets. Er staat alvast een set klaar — sleep panelen met dezelfde breedte hierin of maak er nog één bij.";
      panelElements.grainGroups.appendChild(div);
      drawGrainPreview();
      return;
    }

    for (const g of list) {
      const box = document.createElement("div");
      box.className =
        "dropzone" + (applicationState.current.grain.selectedGroupId === g.id ? " selGroup" : "");
      box.dataset.groupId = g.id;

      const __gw =
        Number(g.widthMm || 0) ||
        ((g.items || []).length
          ? Number(grainData.getGrainEntryByRef(g.items[0])?.widthMm || 0)
          : 0);
      if (__gw && !g.widthMm) {
        g.widthMm = __gw;
        g.widthCm = __gw / 10;
      }
      const wLabel = __gw ? `Werkelijke breedte ${Math.round(__gw * 10) / 10} mm` : "Breedte: —";
      box.innerHTML = `
        <div class="groupHdr">
          <div class="groupTitle">
            <button type="button" class="grainGroupSelect u-weight-700" data-act="select" aria-pressed="${applicationState.current.grain.selectedGroupId === g.id}">Nerfgroep ${formatting._esc(g.id)}</button>
            <small>${wLabel} · volgorde: positie 1 onderaan → hogere posities erboven</small>
          </div>
          <div class="u-row-center-gap-8">
            <button class="miniBtn" data-act="del" aria-label="Verwijder nerfgroep ${formatting._esc(g.id)}" title="Verwijder groep">🗑</button>
          </div>
        </div>
        <div class="help u-margin-bottom-8">Sleep hier panelen met dezelfde breedte naartoe om deze nerf-set te maken.</div>
        <div class="groupBody"></div>
      `;

      // Select group on click
      box.addEventListener("click", (ev) => {
        const restoreFocus =
          document.activeElement === ev.target && ev.target?.dataset?.act === "select";
        configurationState.ensureStateShape();
        // State is normalized once at this event boundary.
        applicationState.current.grain.selectedGroupId = g.id;
        rebuildGrainGroups();
        drawGrainPreview();
        if (restoreFocus) focusGrainGroupControl(g.id, null, "select");
      });

      // Delete group
      box.querySelector('[data-act="del"]').addEventListener("click", (ev) => {
        const restoreFocus = document.activeElement === ev.currentTarget;
        ev.stopPropagation();
        applicationState.current.grain.groups = applicationState.current.grain.groups.filter(
          (x) => x.id !== g.id,
        );
        if (applicationState.current.grain.selectedGroupId === g.id)
          applicationState.current.grain.selectedGroupId =
            applicationState.current.grain.groups[0]?.id || null;
        syncGroupOrders();
        viewRefresh.grainEligible();
        rebuildGrainGroups();
        panelList.renderCart();
        extraEditor.renderExtraPanels();
        panelEdges.syncChecksFromSelect();
        extraPreview.drawExtraPreview();
        drawGrainPreview();
        if (restoreFocus) {
          const next =
            panelElements.grainGroups.querySelector('[data-act="select"]') ||
            panelElements.grainNewGroupBtn;
          next?.focus({ preventScroll: true });
        }
      });

      const body = box.querySelector(".groupBody");

      // Drop handling (tussen items plaatsen)
      // Belangrijk: drop moet werken op de HELE groepskaart (niet alleen in een klein vak).
      // Daarom luisteren we op zowel de box als de body.
      body.style.minHeight = "84px";

      const dragOverHandler = (ev) => {
        ev.preventDefault();
        ev.stopPropagation();
        box.classList.add("dragover");
        ev.dataTransfer.dropEffect = "move";
        const ind = ensureDropIndicator(body);
        const afterEl = getDragAfterElement(body, ev.clientY);
        if (afterEl == null) body.appendChild(ind);
        else body.insertBefore(ind, afterEl);
      };

      const dragLeaveHandler = (ev) => {
        // dragleave vuurt ook als je over child elements beweegt.
        // Alleen echt 'verlaten' als de nieuwe target buiten de box valt.
        if (ev.relatedTarget && box.contains(ev.relatedTarget)) return;
        box.classList.remove("dragover");
        removeDropIndicator(body);
      };

      const dropHandler = (ev) => {
        ev.preventDefault();
        ev.stopPropagation();
        box.classList.remove("dragover");

        let entryRef = null;
        let fromGroupId = null;
        const json = ev.dataTransfer.getData("application/json");
        if (json) {
          try {
            const obj = JSON.parse(json);
            entryRef = String(obj.entryRef || "").trim();
            fromGroupId = obj.fromGroupId || null;
          } catch (e) {
            ToolAErrors.recover("tool.a.runtime.modules.grain.rendering.js.5", e, ["SyntaxError"]);
          }
        }
        if (!entryRef) {
          const t = String(ev.dataTransfer.getData("text/plain") || "").trim();
          if (t) entryRef = t;
        }
        if (!entryRef) {
          if (panelEditSession.currentDrag && panelEditSession.currentDrag.entryRef) {
            entryRef = String(panelEditSession.currentDrag.entryRef || "");
            fromGroupId = panelEditSession.currentDrag.fromGroupId || null;
          }
        }
        if (!entryRef) {
          removeDropIndicator(body);
          return;
        }

        const ind = body.querySelector(".dropIndicator");
        let visualInsertIndex = 0;
        if (ind) {
          const kids = [...body.children];
          const before = kids.indexOf(ind);
          visualInsertIndex = kids
            .slice(0, before)
            .filter((el) => el.classList.contains("groupItem")).length;
        } else {
          visualInsertIndex = [...body.querySelectorAll(".groupItem")].length;
        }
        removeDropIndicator(body);
        // The DOM is TOP -> BOTTOM, while g.items is authoritative BOTTOM -> TOP.
        // Build the desired visual order first, then translate it back to the semantic insertion index.
        const visualRefs = (g.items || [])
          .slice()
          .reverse()
          .map(String)
          .filter((ref) => ref !== String(entryRef));
        visualInsertIndex = Math.max(0, Math.min(visualInsertIndex, visualRefs.length));
        visualRefs.splice(visualInsertIndex, 0, String(entryRef));
        const targetSemantic = visualRefs.slice().reverse();
        const insertIndex = targetSemantic.indexOf(String(entryRef));
        addItemToGroup(entryRef, g.id, insertIndex, fromGroupId);
        panelEditSession.currentDrag = null;
      };

      // Attach to both container and inner body
      // NB: sommige browsers vereisen dragenter + dragover om drop te activeren.
      box.addEventListener("dragenter", dragOverHandler);
      body.addEventListener("dragenter", dragOverHandler);
      box.addEventListener("dragover", dragOverHandler);
      body.addEventListener("dragover", dragOverHandler);
      box.addEventListener("dragleave", dragLeaveHandler);
      body.addEventListener("dragleave", dragLeaveHandler);
      box.addEventListener("drop", dropHandler);
      body.addEventListener("drop", dropHandler);

      if (!g.items.length) {
        const empty = document.createElement("div");
        empty.className = "help";
        empty.textContent = "Nog geen panelen in deze groep.";
        body.appendChild(empty);
      } else {
        g.items
          .slice()
          .reverse()
          .forEach((idx, visualOrder) => {
            const semanticIndex = g.items.map(String).indexOf(String(idx));
            const position = semanticIndex + 1;
            const e = grainData.getGrainEntryByRef(idx);
            if (!e) return;
            const gi = document.createElement("div");
            gi.className = "groupItem";
            gi.draggable = true;
            gi.dataset.entryRef = String(idx);
            gi.addEventListener("dragstart", (ev) => {
              gi.classList.add("dragging");
              panelEditSession.currentDrag = {
                entryRef: idx,
                fromGroupId: g.id,
              };

              ev.dataTransfer.setData(
                "application/json",
                JSON.stringify(panelEditSession.currentDrag),
              );

              ev.dataTransfer.setData("text/plain", String(idx));
              ev.dataTransfer.effectAllowed = "move";
            });
            gi.addEventListener("dragend", () => {
              gi.classList.remove("dragging");
              panelEditSession.currentDrag = null;
              removeDropIndicator(body);
            });
            gi.innerHTML = `
            <div>
              <div class="u-weight-650">${formatting._esc(e.label)}</div>
              <small>${Math.round(Number(e.widthMm || 0))}×${Math.round(Number((e.baseHeightMm || 0) + (e.extTop || 0) + (e.extBot || 0)))} mm${grainData.grainDoorDirectionLabel(e.raw)}${grainData.grainExtLabel(e.raw)}${e.kind === "extra" ? " · overig" : ""} · positie ${position}/${g.items.length}</small>
            </div>
            <div class="actions">
              <button class="miniBtn" data-act="up" aria-label="Hoger in de stapel: ${formatting._esc(e.label)}" title="Hoger in de stapel">↑</button>
              <button class="miniBtn" data-act="down" aria-label="Lager in de stapel: ${formatting._esc(e.label)}" title="Lager in de stapel">↓</button>
              <button class="miniBtn" data-act="rm" aria-label="Verwijder uit groep: ${formatting._esc(e.label)}" title="Verwijder uit groep">✕</button>
            </div>
          `;
            gi.querySelector('[data-act="up"]').addEventListener("click", (ev) => {
              ev.stopPropagation();
              moveInGroup(g.id, semanticIndex, +1);
              focusGrainGroupControl(g.id, idx, "up");
            });
            gi.querySelector('[data-act="down"]').addEventListener("click", (ev) => {
              ev.stopPropagation();
              moveInGroup(g.id, semanticIndex, -1);
              focusGrainGroupControl(g.id, idx, "down");
            });
            gi.querySelector('[data-act="rm"]').addEventListener("click", (ev) => {
              ev.stopPropagation();
              removeFromGroup(g.id, idx);
              focusGrainGroupControl(g.id, null, "select");
            });
            body.appendChild(gi);
          });
      }

      panelElements.grainGroups.appendChild(box);
    }
  }

  function focusGrainGroupControl(groupId, entryRef, action) {
    const group = Array.from(panelElements.grainGroups.querySelectorAll("[data-group-id]")).find(
      (el) => el.dataset.groupId === String(groupId),
    );
    const row =
      entryRef == null
        ? group
        : Array.from(group?.querySelectorAll("[data-entry-ref]") || []).find(
            (el) => el.dataset.entryRef === String(entryRef),
          );
    row?.querySelector(`[data-act="${action}"]`)?.focus({ preventScroll: true });
  }

  function addItemToGroup(entryRef, groupId, insertIndex = null, fromGroupId = null) {
    const e = grainData.getGrainEntryByRef(entryRef);
    if (!e) return;

    const g = applicationState.current.grain.groups.find((x) => x.id === groupId);
    if (!g) return;

    const wMm = Math.round(Number(e.widthMm || 0) * 1000) / 1000;
    let groupWidthMm = Math.round(Number(g.widthMm || 0) * 1000) / 1000;
    if (!groupWidthMm && (g.items || []).length) {
      const firstExisting = grainData.getGrainEntryByRef(g.items[0]);
      groupWidthMm = Math.round(Number(firstExisting?.widthMm || 0) * 1000) / 1000;
      if (groupWidthMm) {
        g.widthMm = groupWidthMm;
        g.widthCm = groupWidthMm / 10;
      }
    }
    {
      const dropCheck =
        ToolAGrainValidation && typeof ToolAGrainValidation.getDropValidation === "function"
          ? ToolAGrainValidation.getDropValidation({
              isGrainCapable: grainData.isGrainCapable(e.raw),
              groupWidthMm,
              itemWidthMm: wMm,
            })
          : null;
      if (dropCheck && !dropCheck.ok) {
        panelElements.setGrainMsg(dropCheck.message || "Kan niet toevoegen aan deze nerf-set.");
        return;
      }
    }
    if (!grainData.isGrainCapable(e.raw)) {
      panelElements.setGrainMsg("Dit paneel heeft geen doorlopende houtnerf.");
      return;
    }
    if (groupWidthMm && Math.abs(groupWidthMm - wMm) > 0.001) {
      panelElements.setGrainMsg(
        `Kan niet: alleen panelen met exact dezelfde werkelijke breedte kunnen in één nerf-set. Deze set is ${groupWidthMm} mm breed en dit paneel is ${wMm} mm breed.`,
      );
      return;
    }

    if (e.grainGroupId && e.grainGroupId !== g.id) {
      const old = applicationState.current.grain.groups.find((x) => x.id === e.grainGroupId);
      if (old) old.items = old.items.filter((i) => String(i) !== String(entryRef));
    }

    if (!g.widthMm) {
      g.widthMm = wMm;
      g.widthCm = wMm / 10;
    }

    const alreadyInThis = g.items.map(String).includes(String(entryRef));
    if (alreadyInThis) {
      g.items = g.items.filter((i) => String(i) !== String(entryRef));
    }

    if (insertIndex === null || typeof insertIndex !== "number" || Number.isNaN(insertIndex)) {
      g.items.push(String(entryRef));
    } else {
      const ix = Math.max(0, Math.min(insertIndex, g.items.length));
      g.items.splice(ix, 0, String(entryRef));
    }

    applicationState.current.grain.selectedGroupId = g.id;
    syncGroupOrders();
    viewRefresh.grainEligible();
    rebuildGrainGroups();
    panelList.renderCart();
    panelList.syncPanelDockChrome();
    extraEditor.renderExtraPanels();
    panelEdges.syncChecksFromSelect();
    extraPreview.drawExtraPreview();
    drawGrainPreview();
    panelElements.setGrainMsg("");
  }

  function removeFromGroup(groupId, entryRef) {
    const g = applicationState.current.grain.groups.find((x) => x.id === groupId);
    if (!g) return;
    g.items = g.items.filter((i) => String(i) !== String(entryRef));
    if (!g.items.length) {
      g.widthMm = null;
      g.widthCm = null;
    }
    syncGroupOrders();
    viewRefresh.grainEligible();
    rebuildGrainGroups();
    panelList.renderCart();
    extraEditor.renderExtraPanels();
    panelEdges.syncChecksFromSelect();
    extraPreview.drawExtraPreview();
    drawGrainPreview();
  }

  function moveInGroup(groupId, indexInGroup, delta) {
    const g = applicationState.current.grain.groups.find((x) => x.id === groupId);
    if (!g) return;
    const ni = indexInGroup + delta;
    if (ni < 0 || ni >= g.items.length) return;
    const a = g.items[indexInGroup];
    g.items[indexInGroup] = g.items[ni];
    g.items[ni] = a;
    syncGroupOrders();
    rebuildGrainGroups();
    panelList.renderCart();
    extraEditor.renderExtraPanels();
    panelEdges.syncChecksFromSelect();
    extraPreview.drawExtraPreview();
    drawGrainPreview();
  }

  function syncGroupOrders() {
    (applicationState.current.cart || []).forEach((it) => {
      if (it) {
        it.grainGroupId = null;
        it.grainOrder = null;
      }
    });
    (applicationState.current.extraPanels || []).forEach((p) => {
      grainAssignments.ensureExtraAssignments(p).forEach((a) => {
        a.grainGroupId = null;
        a.grainOrder = null;
      });
    });
    const groups = applicationState.current.grain?.groups || [];
    for (const g of groups) {
      (g.items || []).forEach((ref, i) => {
        const pr = grainData.parseGrainRef(ref);
        if (!pr) return;
        if (pr.kind === "cart") {
          const it = applicationState.current.cart[pr.idx];
          if (it) {
            it.grainGroupId = g.id;
            it.grainOrder = i + 1;
          }
        } else if (pr.kind === "extra") {
          const p = applicationState.current.extraPanels[pr.idx];
          const arr = grainAssignments.ensureExtraAssignments(p);
          if (arr[pr.rep]) {
            arr[pr.rep].grainGroupId = g.id;
            arr[pr.rep].grainOrder = i + 1;
          }
        }
      });
    }
  }

  function animateGrainPreviewFlip(prevRects, stage) {
    if (!stage || !prevRects) return;
    const nextRows = [...stage.querySelectorAll(".grainPreviewPanel[data-preview-key]")];
    let hadMovement = false;
    for (const row of nextRows) {
      const key = row.dataset.previewKey || "";
      const prev = prevRects.get(key);
      if (!prev) continue;
      const next = row.getBoundingClientRect();
      const dy = prev.top - next.top;
      if (Math.abs(dy) > 1) {
        hadMovement = true;
        row.classList.add("animating", "is-moving");
        row.animate(
          [
            { transform: `translateY(${dy}px)`, offset: 0 },
            { transform: "translateY(0px)", offset: 1 },
          ],
          { duration: 240, easing: "cubic-bezier(.22,.61,.36,1)" },
        );
        setTimeout(() => {
          row.classList.remove("animating", "is-moving");
        }, 260);
      }
    }
    if (hadMovement) {
      stage.animate(
        [
          { transform: "scale(0.995)", filter: "brightness(1.01)" },
          { transform: "scale(1)", filter: "brightness(1)" },
        ],
        { duration: 240, easing: "cubic-bezier(.22,.61,.36,1)" },
      );
    }
  }

  function drawGrainPreview() {
    if (foundation.current && typeof foundation.current.renderGrainPreview === "function") {
      if (!panelElements.grainPreview)
        panelElements.grainPreview = document.getElementById("grainPreview");
      return foundation.current.renderGrainPreview({
        container: panelElements.grainPreview,
      });
    }
    if (
      window.ToolAGrainStudioRenderer &&
      typeof window.ToolAGrainStudioRenderer.render === "function"
    ) {
      if (!panelElements.grainPreview)
        panelElements.grainPreview = document.getElementById("grainPreview");
      return window.ToolAGrainStudioRenderer.render(panelElements.grainPreview);
    }

    if (!panelElements.grainPreview) return;
    const prevRects = new Map();

    panelElements.grainPreview
      .querySelectorAll(".grainPreviewPanel[data-preview-key]")
      .forEach((el) => {
        prevRects.set(el.dataset.previewKey || "", el.getBoundingClientRect());
      });

    panelElements.grainPreview.innerHTML = "";
    const gid = applicationState.current.grain.selectedGroupId;
    const g = applicationState.current.grain.groups.find((x) => x.id === gid);
    if (!g || !g.items.length) {
      const div = document.createElement("div");
      div.className = "grainPreviewEmpty";
      div.textContent = "Selecteer een set met minstens 2 panelen om de nerf-preview te zien.";
      panelElements.grainPreview.appendChild(div);
      return;
    }

    const dims = g.items
      .map((ref) => {
        const e = grainData.getGrainEntryByRef(ref);
        if (!e) return null;
        const it = e.raw;
        const w = Number(e.widthMm || 0);
        const baseH = Number(e.baseHeightMm || 0);
        const extTop = Math.max(0, Number(e.extTop || 0));
        const extBot = Math.max(0, Number(e.extBot || 0));
        const totalH = Math.max(1, baseH + extTop + extBot);
        return { ref, entry: e, it, w, baseH, extTop, extBot, totalH };
      })
      .filter(Boolean);

    if (!dims.length) {
      const div = document.createElement("div");
      div.className = "grainPreviewEmpty";
      div.textContent = "Geen panelen beschikbaar voor preview.";
      panelElements.grainPreview.appendChild(div);
      return;
    }

    const stage = document.createElement("div");
    stage.className = "grainPreviewStage";

    const totalStack = dims.reduce((sum, d) => sum + Math.max(d.totalH, 160), 0);
    dims.forEach((d, order) => {
      const row = document.createElement("div");
      row.className = "grainPreviewPanel";
      row.dataset.previewKey = String(
        (d.it && d.it.id) || `${gid}_${String(d.ref).replace(/[^A-Za-z0-9_\-:]/g, "_")}`,
      );
      row.style.flex = `${Math.max(d.totalH, 160)} 1 0`;

      const badge = document.createElement("div");
      badge.className = "grainOrderBadge";
      badge.textContent = String(order + 1);
      row.appendChild(badge);

      const dirRail = document.createElement("div");
      dirRail.className = "grainDirRail";
      const dirArrowTop = document.createElement("div");
      dirArrowTop.className = "grainDirArrow top";
      dirArrowTop.textContent = "↑";
      dirRail.appendChild(dirArrowTop);
      const dirArrowBottom = document.createElement("div");
      dirArrowBottom.className = "grainDirArrow bottom";
      dirArrowBottom.textContent = "↑";
      dirRail.appendChild(dirArrowBottom);
      row.appendChild(dirRail);

      const shell = document.createElement("div");
      shell.className = "grainPanelShell";
      // each panel uses exactly one source swatch, center-cover + local grain axis.
      // We deliberately do NOT fake physical texture continuity between separate panels: the
      // library image is a visual swatch without a known millimetre scale. Group order/arrows
      // still communicate the continuous-grain production intent without inventing scale.

      if (ToolAMaterialSwatchRenderer) {
        ToolAMaterialSwatchRenderer.applyDomSwatch(shell, {
          materialKey: String(
            d.entry?.materialKey ||
              g.materialKey ||
              applicationState.current.grain?.materialKey ||
              "",
          ),
          panel: d.it || { localGrainAxis: "V" },
        });
      }

      const total = d.totalH || 1;
      let topPct = d.extTop > 0 ? Math.max(10, (d.extTop / total) * 100) : 0;
      let botPct = d.extBot > 0 ? Math.max(10, (d.extBot / total) * 100) : 0;
      let corePct = Math.max(34, 100 - topPct - botPct);
      if (topPct + botPct + corePct > 100) {
        const diff = topPct + botPct + corePct - 100;
        corePct = Math.max(28, corePct - diff);
      }
      const usedPct = topPct + botPct + corePct;
      if (usedPct < 100) {
        corePct += 100 - usedPct;
      }

      if (d.extTop > 0) {
        const top = document.createElement("div");
        top.className = "grainPanelSection ext";
        top.style.height = `${topPct}%`;
        const badgeTop = document.createElement("div");
        badgeTop.className = "grainExtBadge";
        badgeTop.textContent = `+${Math.round(d.extTop)}`;
        top.appendChild(badgeTop);
        shell.appendChild(top);
      }

      const core = document.createElement("div");
      core.className = "grainPanelSection";
      core.style.height = `${corePct}%`;
      const label = document.createElement("div");
      label.className = "grainPanelLabel";
      label.textContent = String(
        d.entry?.label || d.it.label || d.it.baseLabel || d.it.templateId || "Paneel",
      );
      core.appendChild(label);
      const innerArrow = document.createElement("div");
      innerArrow.className = "grainPanelInnerArrow";
      innerArrow.textContent = "↑";
      core.appendChild(innerArrow);
      const size = document.createElement("div");
      size.className = "grainPanelSize";
      size.textContent = `${d.entry?.widthCm || Math.round((d.w || 0) / 10) / 10}×${d.entry?.heightCm || Math.round((d.baseH || 0) / 10) / 10} cm`;
      core.appendChild(size);
      shell.appendChild(core);

      if (d.extBot > 0) {
        const bot = document.createElement("div");
        bot.className = "grainPanelSection ext";
        bot.style.height = `${botPct}%`;
        const badgeBot = document.createElement("div");
        badgeBot.className = "grainExtBadge";
        badgeBot.textContent = `+${Math.round(d.extBot)}`;
        bot.appendChild(badgeBot);
        shell.appendChild(bot);
      }

      row.appendChild(shell);
      stage.appendChild(row);

      if (order < dims.length - 1) {
        const join = document.createElement("div");
        join.className = "grainJoinLine";
        stage.appendChild(join);
      }
    });

    panelElements.grainPreview.appendChild(stage);
    requestAnimationFrame(() => animateGrainPreviewFlip(prevRects, stage));
  }

  function mount() {
    window.ToolAGrainBridge = Object.freeze({
      BUILD: REVISION,
      state: () => applicationState.current,
      ensureStateShape: () => configurationState.ensureStateShape(),
      selectedMaterialKey: () => grainData.grainOverlaySelectedMaterialKey(),
      getEntry: (ref) => grainData.getGrainEntryByRef(ref),
      getEligible: () => grainData.getGrainEligibleEntries(),
      extrasEnabled: () => grainData.grainExtrasEnabled(),
      isGrainCapable: (raw) => grainData.isGrainCapable(raw),
      groupDisplayEntries: (entries) => grainData._groupGrainDisplayEntries(entries),
      doorDirectionLabel: (raw) => grainData.grainDoorDirectionLabel(raw),
      extensionLabel: (raw) => grainData.grainExtLabel(raw),
      syncOrders: () => syncGroupOrders(),
      rebuildWidthOptions: () => viewRefresh.grainWidths(),
      rebuildEligible: () => viewRefresh.grainEligible(),
      rebuildGroups: () => rebuildGrainGroups(),
      renderCart: () => panelList.renderCart(),
      syncPanelDockChrome: () => {
        panelList.syncPanelDockChrome();
      },
      renderExtraPanels: () => extraEditor.renderExtraPanels(),
      syncChecksFromSelect: () => panelEdges.syncChecksFromSelect(),
      drawExtraPreview: () => extraPreview.drawExtraPreview(),
      setMessage: (msg) => panelElements.setGrainMsg(msg),
      newGroup: () => newGroup(),
      removeFromGroup: (groupId, ref) => removeFromGroup(groupId, ref),
      addToGroup: (ref, groupId, insertIndex, fromGroupId) =>
        addItemToGroup(ref, groupId, insertIndex, fromGroupId),
      getTemplate: (templateId) => {
        try {
          return applicationState.current.templates && applicationState.current.templates.get
            ? applicationState.current.templates.get(String(templateId || "")) || null
            : null;
        } catch (_e) {
          return null;
        }
      },
      ensureTemplate: (templateId) => {
        try {
          return templateCatalog.ensureTemplateLoadedById(String(templateId || ""));
        } catch (_e) {
          return Promise.resolve(null);
        }
      },
      drawPreviewLegacy: () => {
        try {
          return drawGrainPreview();
        } catch (_e) {
          return null;
        }
      },
    });
  }

  return Object.freeze({
    drawGrainPreview,
    newGroup,
    syncSelectedGrainGroupForMaterial,
    rebuildGrainGroups,
    addItemToGroup,
    mount,
  });
}
