/** extra-overlay: one runtime owner with explicit, immutable dependency ports. */
export function createExtraOverlay({
  applicationState,
  configurationState,
  extraEditor,
  extraPreview,
  materialMetadata,
  panelEdges,
  panelEditSession,
  panelElements,
} = {}) {
  function openExtraOverlay() {
    if (typeof panelElements.ensureOverlayEls === "function") panelElements.ensureOverlayEls();
    if (!panelElements.extraOverlay) return;
    {
      materialMetadata.refreshExtraMaterialOptions();
      const __extraMatSel = document.getElementById("extraMat");
      const __activeMk = String(applicationState.current?.activeMaterialKey || "").trim();
      if (panelEditSession.extraEditIndex == null && __extraMatSel && __activeMk) {
        __extraMatSel.value = __activeMk;
      }
    }
    panelElements.setOverlayVisible("extraOverlay", true);
    extraEditor.renderExtraPanels();
    panelEdges.syncChecksFromSelect();
    extraPreview.drawExtraPreview();
  }

  function closeExtraOverlay() {
    if (typeof panelElements.ensureOverlayEls === "function") panelElements.ensureOverlayEls();
    try {
      extraEditor.resetExtraForm();
    } catch (_e) {
      panelEditSession.extraEditIndex = null;
    }
    if (!panelElements.extraOverlay) return;
    panelElements.setOverlayVisible("extraOverlay", false);
  }

  function mount() {
    if (panelElements.extraOverlayBtn)
      panelElements.extraOverlayBtn.addEventListener("click", () => {
        configurationState.ensureStateShape();
        // State is normalized once at this event boundary.
        if (panelElements.extraOverlayBtn.disabled) return;
        openExtraOverlay();
      });
  }

  return Object.freeze({
    closeExtraOverlay,
    mount,
  });
}
