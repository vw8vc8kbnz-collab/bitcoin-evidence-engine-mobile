/** panel-edges: one runtime owner with explicit, immutable dependency ports. */
export function createPanelEdges({ extraPreview, panelElements } = {}) {
  function encodeEdgeFromChecks() {
    const t = panelElements.extraEdgeTop && panelElements.extraEdgeTop.checked ? 1 : 0;
    const r = panelElements.extraEdgeRight && panelElements.extraEdgeRight.checked ? 1 : 0;
    const b = panelElements.extraEdgeBottom && panelElements.extraEdgeBottom.checked ? 1 : 0;
    const l = panelElements.extraEdgeLeft && panelElements.extraEdgeLeft.checked ? 1 : 0;
    return `t${t}r${r}b${b}l${l}`;
  }

  function ensureEdgeOption(val) {
    if (!panelElements.extraEdge) return;
    const opt = panelElements.extraEdge.querySelector(`option[value="${val}"]`);
    if (!opt) {
      const o = document.createElement("option");
      o.value = val;
      o.textContent = val;
      panelElements.extraEdge.appendChild(o);
    }
    panelElements.extraEdge.value = val;
  }

  function edgeValueFromChecks() {
    const t = panelElements.extraEdgeTop && panelElements.extraEdgeTop.checked ? 1 : 0;
    const r = panelElements.extraEdgeRight && panelElements.extraEdgeRight.checked ? 1 : 0;
    const b = panelElements.extraEdgeBottom && panelElements.extraEdgeBottom.checked ? 1 : 0;
    const l = panelElements.extraEdgeLeft && panelElements.extraEdgeLeft.checked ? 1 : 0;
    return `t${t}r${r}b${b}l${l}`;
  }

  function ensureExtraEdgeValue(v) {
    if (!panelElements.extraEdge) return;
    if (!panelElements.extraEdge.querySelector(`option[value="${v}"]`)) {
      const o = document.createElement("option");
      o.value = v;
      o.textContent = v;
      panelElements.extraEdge.appendChild(o);
    }
    panelElements.extraEdge.value = v;
  }

  function syncSelectFromChecks() {
    ensureExtraEdgeValue(edgeValueFromChecks());
  }

  function syncChecksFromSelect() {
    if (!panelElements.extraEdgeTop || !panelElements.extraEdge) return;
    const v = String(panelElements.extraEdge.value || "none");
    if (v === "all") {
      panelElements.extraEdgeTop.checked = true;
      panelElements.extraEdgeBottom.checked = true;
      panelElements.extraEdgeLeft.checked = true;
      panelElements.extraEdgeRight.checked = true;
      return;
    }
    if (v === "lr") {
      panelElements.extraEdgeTop.checked = false;
      panelElements.extraEdgeBottom.checked = false;
      panelElements.extraEdgeLeft.checked = true;
      panelElements.extraEdgeRight.checked = true;
      return;
    }
    if (v === "tb") {
      panelElements.extraEdgeTop.checked = true;
      panelElements.extraEdgeBottom.checked = true;
      panelElements.extraEdgeLeft.checked = false;
      panelElements.extraEdgeRight.checked = false;
      return;
    }
    if (v === "none") {
      panelElements.extraEdgeTop.checked = false;
      panelElements.extraEdgeBottom.checked = false;
      panelElements.extraEdgeLeft.checked = false;
      panelElements.extraEdgeRight.checked = false;
      return;
    }
    const m = v.match(/^t([01])r([01])b([01])l([01])$/);
    if (m) {
      panelElements.extraEdgeTop.checked = m[1] === "1";
      panelElements.extraEdgeRight.checked = m[2] === "1";
      panelElements.extraEdgeBottom.checked = m[3] === "1";
      panelElements.extraEdgeLeft.checked = m[4] === "1";
    }
  }

  function mount() {
    [
      panelElements.extraEdgeTop,
      panelElements.extraEdgeBottom,
      panelElements.extraEdgeLeft,
      panelElements.extraEdgeRight,
    ].forEach((el) => {
      if (!el) return;
      el.addEventListener("change", () => {
        syncSelectFromChecks();
        extraPreview.drawExtraPreview();
      });
    });
  }

  return Object.freeze({
    syncChecksFromSelect,
    ensureEdgeOption,
    syncSelectFromChecks,
    mount,
  });
}
