import { ToolAMaterialSwatchRenderer } from "../../domain/material-swatch-renderer.js";
import { ToolARenderHelpers } from "../../domain/render-helpers.js";
import { ToolAViewMathHelpers } from "../../domain/view-math-helpers.js";
/** panel-preview: one runtime owner with explicit, immutable dependency ports. */
export function createPanelPreview({
  applicationState,
  canvasPrimitives,
  formatting,
  panelElements,
  templateLoadState,
} = {}) {
  let ctx;

  function resizeCanvas() {
    const dpr = Math.max(1, window.devicePixelRatio || 1);
    const r = panelElements.cv.getBoundingClientRect();
    const nextWidth = Math.floor(r.width * dpr);
    const nextHeight = Math.floor(r.height * dpr);
    if (panelElements.cv.width !== nextWidth) panelElements.cv.width = nextWidth;
    if (panelElements.cv.height !== nextHeight) panelElements.cv.height = nextHeight;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    draw();
  }

  function draw() {
    // Dark work-surface background
    {
      const c = document.getElementById("canvas");
      if (c) {
        const ctx = c.getContext("2d");
        ctx.save();
        ctx.setTransform(1, 0, 0, 1, 0, 0);
        ctx.fillStyle = "#1f2526";
        ctx.fillRect(0, 0, c.width, c.height);
        ctx.restore();
      }
    }

    // clear
    const w = panelElements.cv.clientWidth;
    const h = panelElements.cv.clientHeight;
    ctx.clearRect(0, 0, w, h);

    // background subtle
    ctx.fillStyle = "#1f2526";
    ctx.fillRect(0, 0, w, h);

    // instruction if missing
    const t = applicationState.current.templates.get(applicationState.current.selection.templateId);
    if (!t) {
      drawEmpty(w, h);
      return;
    }

    // compute transformed geometry
    const extTopVal = Number(applicationState.current.selection.extTop) || 0;
    const extBotVal = Number(applicationState.current.selection.extBot) || 0;
    const baseW = t.realW;
    const baseH = t.realH;

    // Panel world coordinates with extensions: yMin becomes -extBot, yMax becomes baseH + extTop.
    // Keep this as the *real* panel extent for wood fill, outline and dimensions.
    const world = {
      minX: 0,
      maxX: baseW,
      minY: -extBotVal,
      maxY: baseH + extTopVal,
    };

    // Preview world may be slightly larger than the panel itself.
    // Important: the DXF remains the only source of truth. We may extend the preview bounds
    // so circles that fall half over the edge remain visible, but we never invent extra cups.
    const isDoor = !!(
      applicationState.current.selection.type === "deur" ||
      applicationState.current.selection.type === "pax_deur" ||
      t.supportsHinge ||
      t.kind === "Hoekkast"
    );
    const mirror = isDoor && applicationState.current.selection.hinge === "right";
    const outlineMinX = Number.isFinite(Number(t?.outline?.minX)) ? Number(t.outline.minX) : 0;
    const outlineMinY = Number.isFinite(Number(t?.outline?.minY)) ? Number(t.outline.minY) : 0;
    const previewHoles = Array.isArray(t?.holes) ? t.holes.slice() : [];
    const previewArcs = Array.isArray(t?.holeArcs) ? t.holeArcs.slice() : [];
    let previewMinX = world.minX;
    let previewMaxX = world.maxX;
    let previewMinY = world.minY;
    let previewMaxY = world.maxY;
    for (const h0 of previewHoles) {
      const localHx = (Number(h0?.x) || 0) - outlineMinX;
      const localHy = (Number(h0?.y) || 0) - outlineMinY;
      const hx = mirror ? baseW - localHx : localHx;
      const hy = localHy;
      const r = Math.max(0, Number(h0?.r) || 0);
      previewMinX = Math.min(previewMinX, hx - r);
      previewMaxX = Math.max(previewMaxX, hx + r);
      previewMinY = Math.min(previewMinY, hy - r);
      previewMaxY = Math.max(previewMaxY, hy + r);
    }
    function __degToRad(d) {
      return ((Number(d) || 0) * Math.PI) / 180;
    }
    function __normRad(a) {
      const two = Math.PI * 2;
      let v = a % two;
      if (v < 0) v += two;
      return v;
    }
    function __arcContains(a0, a1, t) {
      const s = __normRad(a0),
        e = __normRad(a1),
        x = __normRad(t);
      if (s <= e) return x >= s && x <= e;
      return x >= s || x <= e;
    }
    for (const a0 of previewArcs) {
      const localAx = (Number(a0?.x) || 0) - outlineMinX;
      const localAy = (Number(a0?.y) || 0) - outlineMinY;
      const ax = mirror ? baseW - localAx : localAx;
      const ay = localAy;
      const r = Math.max(0, Number(a0?.r) || 0);
      if (!(r > 0)) continue;
      let s = __degToRad(Number(a0?.startDeg) || 0);
      let e = __degToRad(Number(a0?.endDeg) || 0);
      if (mirror) {
        const ms = Math.PI - s;
        const me = Math.PI - e;
        s = me;
        e = ms;
      }
      const angles = [s, e, 0, Math.PI / 2, Math.PI, Math.PI * 1.5].filter((t) =>
        __arcContains(s, e, t),
      );
      for (const ang of angles) {
        const px = ax + Math.cos(ang) * r;
        const py = ay + Math.sin(ang) * r;
        previewMinX = Math.min(previewMinX, px);
        previewMaxX = Math.max(previewMaxX, px);
        previewMinY = Math.min(previewMinY, py);
        previewMaxY = Math.max(previewMaxY, py);
      }
    }

    // fit the real panel + DXF-extents inside a mobile-safe content box that
    // explicitly reserves room for dimension lines/text. Desktop uses the exact established
    // geometry; this only changes the narrow-screen fit.
    const __mobileCanvas = !!(window.matchMedia && window.matchMedia("(max-width:700px)").matches);
    const worldW = world.maxX - world.minX;
    const worldH = world.maxY - world.minY;
    const previewW = Math.max(1, previewMaxX - previewMinX);
    const previewH = Math.max(1, previewMaxY - previewMinY);
    let __viewerFit = null;
    try {
      if (
        ToolAViewMathHelpers &&
        typeof ToolAViewMathHelpers.computePanelPreviewFit === "function"
      ) {
        __viewerFit = ToolAViewMathHelpers.computePanelPreviewFit({
          canvasWidth: w,
          canvasHeight: h,
          previewMinX,
          previewMaxX,
          previewMinY,
          previewMaxY,
          mobile: __mobileCanvas,
        });
      }
    } catch (_e) {
      __viewerFit = null;
    }
    if (!__viewerFit) {
      const pad = __mobileCanvas ? 18 : 34;
      const headerReserve = __mobileCanvas ? 88 : 0;
      const footerReserve = __mobileCanvas ? 88 : 0;
      const availW = Math.max(80, w - pad * 2);
      const availH = Math.max(80, h - pad * 2 - headerReserve - footerReserve);
      const fallbackScale =
        Math.min(availW / previewW, availH / previewH) * (__mobileCanvas ? 0.94 : 0.9);
      __viewerFit = {
        scale: fallbackScale,
        ox: (w - previewW * fallbackScale) / 2 - previewMinX * fallbackScale,
        oy:
          pad +
          headerReserve +
          (availH - previewH * fallbackScale) / 2 +
          previewMaxY * fallbackScale,
      };
    }
    const scale = __viewerFit.scale;
    const ox = __viewerFit.ox;
    const oy = __viewerFit.oy; // y flips

    function X(x) {
      return ox + x * scale;
    }
    function Y(y) {
      return oy - y * scale;
    }

    // render the ACTUAL selected material swatch. One image per panel,
    // aspect-preserving center-cover, clipped to the local panel surface, never repeated.
    const rect = {
      x: X(0),
      y: Y(world.maxY),
      w: worldW * scale,
      h: worldH * scale,
    };
    try {
      if (ToolAMaterialSwatchRenderer) {
        ToolAMaterialSwatchRenderer.drawCanvasMaterial(ctx, rect, {
          materialKey: String(
            applicationState.current.activeMaterialKey ||
              applicationState.current.selection.materialKey ||
              "",
          ),
          material: applicationState.current.material || null,
          panel: { localGrainAxis: "V" },
          onReady: draw,
        });
      } else {
        drawWood(rect, applicationState.current.selection.material);
      }
    } catch (_e) {
      drawWood(rect, applicationState.current.selection.material);
    }

    // draw growth zones highlight
    ctx.save();
    ctx.globalAlpha = 0.22;
    ctx.fillStyle = "rgba(45,181,111,1)";
    if (extTopVal > 0) {
      const y0 = Y(baseH + extTopVal);
      const y1 = Y(baseH);
      ctx.fillRect(X(0), y0, worldW * scale, y1 - y0);
    }
    if (extBotVal > 0) {
      const y0 = Y(0);
      const y1 = Y(-extBotVal);
      ctx.fillRect(X(0), y0, worldW * scale, y1 - y0);
    }
    ctx.restore();

    // outline
    ctx.save();
    ctx.strokeStyle = "rgba(30,40,35,.55)";
    ctx.lineWidth = 1.6;
    ctx.strokeRect(X(0), Y(world.maxY), worldW * scale, worldH * scale);
    ctx.restore();

    // holes (ghosted) — mirror if hinge right for doors.
    // Clip to the real panel rectangle so half-over-edge cups render like the DXF: visible inside,
    // but not floating outside the panel.
    ctx.save();
    ctx.beginPath();
    ctx.rect(X(0), Y(world.maxY), worldW * scale, worldH * scale);
    ctx.clip();
    // keep the exact 1px CNC line weight, but choose a local high-contrast
    // stroke from the rendered material underneath each boring. Light swatches get an
    // anthracite detail line; dark swatches get a near-white line. No halo / no thicker line.
    const __cncContrastStroke = (px, py) => {
      if (
        ToolAMaterialSwatchRenderer &&
        typeof ToolAMaterialSwatchRenderer.contrastStrokeAt === "function"
      ) {
        return ToolAMaterialSwatchRenderer.contrastStrokeAt(ctx, px, py, {
          dark: "rgba(18,28,25,.90)",
          light: "rgba(247,250,248,.94)",
          fallback: "rgba(64,177,113,.95)",
          sampleRadius: 2,
        });
      }

      return "rgba(64,177,113,.95)";
    };
    ctx.setLineDash([4, 4]);
    ctx.lineWidth = 1;
    for (const h0 of previewHoles) {
      const localHx = (Number(h0?.x) || 0) - outlineMinX;
      const localHy = (Number(h0?.y) || 0) - outlineMinY;
      const hx = mirror ? baseW - localHx : localHx;
      const hy = localHy;
      const r = Number(h0?.r) || 0;
      if (!(r > 0)) continue;
      ctx.strokeStyle = __cncContrastStroke(X(hx), Y(hy));
      ctx.beginPath();
      ctx.arc(X(hx), Y(hy), r * scale, 0, Math.PI * 2);
      ctx.stroke();
    }
    for (const a0 of previewArcs) {
      const localAx = (Number(a0?.x) || 0) - outlineMinX;
      const localAy = (Number(a0?.y) || 0) - outlineMinY;
      const ax = mirror ? baseW - localAx : localAx;
      const ay = localAy;
      const r = Number(a0?.r) || 0;
      if (!(r > 0)) continue;
      let s = ((Number(a0?.startDeg) || 0) * Math.PI) / 180;
      let e = ((Number(a0?.endDeg) || 0) * Math.PI) / 180;
      let ccw = false;
      if (mirror) {
        const ms = Math.PI - s;
        const me = Math.PI - e;
        s = me;
        e = ms;
      }
      ctx.strokeStyle = __cncContrastStroke(X(ax), Y(ay));
      ctx.beginPath();
      ctx.arc(X(ax), Y(ay), r * scale, s, e, ccw);
      ctx.stroke();
    }
    ctx.restore();

    // label corner/header (: on mobile it gets a safe header lane, never over the panel)
    ctx.save();
    const __mobileCanvasFit = !!(
      window.matchMedia && window.matchMedia("(max-width:700px)").matches
    );
    if (__mobileCanvasFit) {
      ctx.fillStyle = "rgba(234,243,238,.95)";
      ctx.font = "700 12px ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto";
      ctx.textAlign = "left";
      ctx.textBaseline = "top";
      // Keep the template name compact, but NEVER truncate the actual dimensions.
      const maxTitleW = Math.max(90, w - 36);
      let mobileTitle = String(t.label || "Paneel");
      while (mobileTitle.length > 4 && ctx.measureText(mobileTitle).width > maxTitleW) {
        mobileTitle = mobileTitle.slice(0, -2);
      }
      if (mobileTitle !== String(t.label || "Paneel"))
        mobileTitle = mobileTitle.replace(/\s+$/, "") + "…";
      ctx.fillText(mobileTitle, 18, 10);
      ctx.font = "700 11.5px ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto";
      ctx.fillStyle = "rgba(234,243,238,.93)";
      ctx.fillText(
        `${formatting.formatMm(baseW)} × ${formatting.formatMm(baseH + extTopVal + extBotVal)} mm`,
        18,
        29,
      );
      ctx.font = "10.5px ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto";
      ctx.fillStyle = "rgba(200,215,208,.86)";
      ctx.fillText("Vooraanzicht · boringen achterzijde", 18, 46);
    } else {
      ctx.fillStyle = "rgba(234,243,238,.92)";
      ctx.font = "600 13px ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto";
      ctx.fillText(
        `${t.label}  ·  ${formatting.formatMm(baseW)} × ${formatting.formatMm(baseH)} mm`,
        16,
        24,
      );
      ctx.font = "12px ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto";
      ctx.fillStyle = "rgba(200,215,208,.90)";
      ctx.fillText("Vooraanzicht (boringen achterzijde)", 16, 44);
    }
    ctx.restore();

    // dimensions (outer only)
    drawDimensions({ X, Y, scale }, world, baseW, baseH, extTopVal, extBotVal);

    // mini side view icon (hinge + handle)
    drawMiniSideView({ X, Y }, baseW, world, mirror);

    // update header info
    const realShownW = baseW;
    const realShownH = baseH + extTopVal + extBotVal;
  }

  function drawEmpty(w, h) {
    if (ToolARenderHelpers && typeof ToolARenderHelpers.drawEmpty === "function") {
      return ToolARenderHelpers.drawEmpty(
        ctx,
        w,
        h,
        applicationState.current.selection.templateId
          ? templateLoadState.selectedTemplateLoad?.status || "loading"
          : "idle",
      );
    }

    // nice empty state
    ctx.save();
    ctx.fillStyle = "rgba(234,243,238,.9)";
    ctx.font = "800 16px ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto";
    ctx.textAlign = "center";
    ctx.fillText("Kies rechts een type + maat om te starten", w / 2, h / 2 - 12);
    ctx.fillStyle = "rgba(200,215,208,.90)";
    ctx.font = "13px ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto";
    ctx.fillText(
      "Je ziet hier direct het front met boringen, maatvoering, verlengen en spiegeling.",
      w / 2,
      h / 2 + 12,
    );
    ctx.restore();
  }

  function drawWood(rect, material) {
    // Draw a warm wood-like pattern using gradients + subtle lines.
    ctx.save();
    // Defensive normalize: during mobile sheet transitions the canvas can briefly report
    // zero/negative fit dimensions. Skip that frame instead of throwing canvas errors.
    try {
      if (!rect) {
        ctx.restore();
        return;
      }
      let rx = Number(rect.x),
        ry = Number(rect.y),
        rw = Number(rect.w),
        rh = Number(rect.h);
      if (
        !Number.isFinite(rx) ||
        !Number.isFinite(ry) ||
        !Number.isFinite(rw) ||
        !Number.isFinite(rh)
      ) {
        ctx.restore();
        return;
      }
      if (rw < 0) {
        rx += rw;
        rw = Math.abs(rw);
      }
      if (rh < 0) {
        ry += rh;
        rh = Math.abs(rh);
      }
      if (rw < 1 || rh < 1) {
        ctx.restore();
        return;
      }
      rect = { x: rx, y: ry, w: rw, h: rh };
    } catch (_e) {
      ctx.restore();
      return;
    }
    // base gradient
    let g = ctx.createLinearGradient(rect.x, rect.y, rect.x + rect.w, rect.y + rect.h);
    if (material === "oak") {
      g.addColorStop(0, "rgba(188,150,92,.55)");
      g.addColorStop(0.45, "rgba(164,123,70,.52)");
      g.addColorStop(1, "rgba(201,162,103,.55)");
    } else if (material === "walnut") {
      g.addColorStop(0, "rgba(122,86,52,.55)");
      g.addColorStop(0.55, "rgba(96,66,40,.52)");
      g.addColorStop(1, "rgba(137,97,60,.55)");
    } else {
      // default/fallback: keep wood tone (never gray) so preview stays consistent
      g.addColorStop(0, "rgba(188,150,92,.55)");
      g.addColorStop(0.45, "rgba(164,123,70,.52)");
      g.addColorStop(1, "rgba(201,162,103,.55)");
    }
    ctx.fillStyle = g;
    ctx.fillRect(rect.x, rect.y, rect.w, rect.h);

    // grain lines (default vertical grain running along the height)
    // i.e. lines run top-to-bottom, and vary slightly across the width.
    const lineCount = Math.max(10, Math.floor(rect.w / 24));
    ctx.globalAlpha = 0.28;
    ctx.strokeStyle = "rgba(40,26,16,1)";
    if (material === "paint") ctx.strokeStyle = "rgba(20,20,20,1)";

    ctx.lineWidth = 1;
    for (let i = 0; i < lineCount; i++) {
      const x = rect.x + ((i + 0.5) * rect.w) / lineCount;
      ctx.beginPath();
      const wobble = Math.sin(i * 1.2) * 3;
      ctx.moveTo(x + wobble, rect.y);
      ctx.bezierCurveTo(
        x + wobble + Math.cos(i * 0.8) * 5,
        rect.y + rect.h * 0.25,
        x + wobble + Math.sin(i * 0.6) * 5,
        rect.y + rect.h * 0.75,
        x + wobble,
        rect.y + rect.h,
      );
      ctx.stroke();
    }

    // subtle vignette
    const __rMin = Math.max(0.01, Math.min(rect.w, rect.h) * 0.2);
    const __rMax = Math.max(__rMin + 0.01, Math.max(rect.w, rect.h) * 0.75);
    const v = ctx.createRadialGradient(
      rect.x + rect.w * 0.5,
      rect.y + rect.h * 0.5,
      __rMin,
      rect.x + rect.w * 0.5,
      rect.y + rect.h * 0.5,
      __rMax,
    );
    v.addColorStop(0, "rgba(0,0,0,0)");
    v.addColorStop(1, "rgba(0,0,0,.28)");
    ctx.globalAlpha = 1;
    ctx.fillStyle = v;
    ctx.fillRect(rect.x, rect.y, rect.w, rect.h);

    ctx.restore();
  }

  function drawDimensions(tf, world, baseW, baseH, extTop, extBot) {
    const { X, Y, scale } = tf;
    const totalH = baseH + extTop + extBot;

    const left = X(world.minX);
    const right = X(world.maxX);
    const top = Y(world.maxY);
    const bottom = Y(world.minY);

    ctx.save();
    ctx.strokeStyle = "rgba(234,243,238,.55)";
    ctx.fillStyle = "rgba(234,243,238,.75)";
    ctx.lineWidth = 1;
    ctx.setLineDash([]);

    // width dimension above
    const dimY = top - 18;
    drawDimLine(left, dimY, right, dimY, formatting.formatMm(baseW) + " mm");

    // height dimension left
    const dimX = left - 18;
    drawDimLineVertical(dimX, bottom, dimX, top, formatting.formatMm(totalH) + " mm");

    // extension labels
    ctx.font = "12px ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto";
    ctx.fillStyle = "rgba(45,181,111,.98)";
    if (extTop > 0) ctx.fillText(`+${extTop} boven`, right - 110, top + 16);
    if (extBot > 0) ctx.fillText(`+${extBot} onder`, right - 110, bottom - 6);

    ctx.restore();

    function drawDimLine(x1, y1, x2, y2, text) {
      // end ticks
      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
      ctx.stroke();
      tick(x1, y1, 0);
      tick(x2, y2, 0);
      // arrows
      arrow(x1, y1, x1 + 10, y1);
      arrow(x2, y2, x2 - 10, y2);
      // text
      ctx.textAlign = "center";
      ctx.textBaseline = "bottom";
      ctx.fillText(text, (x1 + x2) / 2, y1 - 4);
    }

    function drawDimLineVertical(x1, y1, x2, y2, text) {
      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
      ctx.stroke();
      tick(x1, y1, 1);
      tick(x2, y2, 1);
      arrow(x1, y1, x1, y1 - 10);
      arrow(x2, y2, x2, y2 + 10);
      ctx.save();
      ctx.translate(x1 - 6, (y1 + y2) / 2);
      ctx.rotate(-Math.PI / 2);
      ctx.textAlign = "center";
      ctx.textBaseline = "bottom";
      ctx.fillText(text, 0, 0);
      ctx.restore();
    }

    function tick(x, y, vertical) {
      const s = 6;
      ctx.beginPath();
      if (vertical) {
        ctx.moveTo(x - s, y);
        ctx.lineTo(x + s, y);
      } else {
        ctx.moveTo(x, y - s);
        ctx.lineTo(x, y + s);
      }
      ctx.stroke();
    }

    function arrow(x1, y1, x2, y2) {
      const ang = Math.atan2(y2 - y1, x2 - x1);
      const len = 8;
      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(x1 + Math.cos(ang + 0.6) * len, y1 + Math.sin(ang + 0.6) * len);
      ctx.moveTo(x1, y1);
      ctx.lineTo(x1 + Math.cos(ang - 0.6) * len, y1 + Math.sin(ang - 0.6) * len);
      ctx.stroke();
    }
  }

  function drawMiniSideView(tf, baseW, world, mirror) {
    // — clean hinge-direction badge. It stays technical and readable instead
    // of looking like a thumbnail/image. Mobile is intentionally bottom-left so the
    // drawer handle and panel drawing keep their own visual space.
    const w = panelElements.cv.clientWidth,
      h = panelElements.cv.clientHeight;
    const isMobile = !!(window.matchMedia && window.matchMedia("(max-width:700px)").matches);
    const hingeOnLeft = !mirror;
    const hingeLabel = hingeOnLeft ? "Scharnier links" : "Scharnier rechts";
    const boxW = isMobile ? 154 : 174;
    const boxH = isMobile ? 64 : 70;
    const x0 = isMobile ? 12 : w - boxW - 16;
    const y0 = isMobile ? Math.max(12, h - boxH - 18) : 14;

    ctx.save();

    // Glass-like information card, not a miniature product picture.
    ctx.shadowColor = "rgba(4,14,10,.18)";
    ctx.shadowBlur = isMobile ? 14 : 16;
    ctx.shadowOffsetY = 6;
    ctx.fillStyle = "rgba(250,252,251,.965)";
    ctx.strokeStyle = "rgba(73,96,85,.20)";
    ctx.lineWidth = 1;
    canvasPrimitives.roundRect(ctx, x0, y0, boxW, boxH, 16);
    ctx.fill();
    ctx.shadowColor = "transparent";
    ctx.stroke();

    // Compact door icon.
    const iconX = x0 + 13;
    const iconY = y0 + 11;
    const iconW = 34;
    const iconH = boxH - 22;
    ctx.fillStyle = "rgba(235,241,238,.96)";
    ctx.strokeStyle = "rgba(41,61,52,.24)";
    canvasPrimitives.roundRect(ctx, iconX, iconY, iconW, iconH, 9);
    ctx.fill();
    ctx.stroke();

    const doorX = iconX + 8;
    const doorY = iconY + 6;
    const doorW = iconW - 16;
    const doorH = iconH - 12;
    ctx.strokeStyle = "rgba(43,61,53,.62)";
    ctx.lineWidth = 1.25;
    ctx.strokeRect(doorX, doorY, doorW, doorH);

    const hingeX = hingeOnLeft ? doorX : doorX + doorW;
    const handleX = hingeOnLeft ? doorX + doorW - 4 : doorX + 4;
    ctx.fillStyle = "rgba(45,181,111,.98)";
    [doorY + 6, doorY + doorH - 6].forEach((py) => {
      ctx.beginPath();
      ctx.arc(hingeX, py, 2.15, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.strokeStyle = "rgba(45,181,111,.98)";
    ctx.lineWidth = 2.4;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(handleX, doorY + doorH / 2 - 4.5);
    ctx.lineTo(handleX, doorY + doorH / 2 + 4.5);
    ctx.stroke();

    // Small swing cue: an arc from the hinge toward the opening side.
    ctx.strokeStyle = "rgba(85,112,99,.38)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    if (hingeOnLeft) {
      ctx.arc(hingeX, doorY + doorH / 2, Math.max(7, doorW * 0.55), -Math.PI / 2, Math.PI / 2);
    } else {
      ctx.arc(hingeX, doorY + doorH / 2, Math.max(7, doorW * 0.55), Math.PI / 2, Math.PI * 1.5);
    }
    ctx.stroke();

    const textX = iconX + iconW + 11;
    ctx.textAlign = "left";
    ctx.textBaseline = "alphabetic";
    ctx.fillStyle = "rgba(79,96,88,.72)";
    ctx.font = `800 ${isMobile ? 9.5 : 10}px ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto`;
    ctx.fillText("DRAAIRICHTING", textX, y0 + 22);
    ctx.fillStyle = "rgba(22,40,31,.96)";
    ctx.font = `750 ${isMobile ? 12.5 : 13}px ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto`;
    ctx.fillText(hingeLabel, textX, y0 + 43);

    ctx.restore();
  }

  function mount() {
    ctx = panelElements.cv.getContext("2d");
    window.addEventListener("resize", function () {
      if (window.__panelKeyboardActive) return;
      resizeCanvas();
    });
    {
      const __cvWrap = document.getElementById("canvasWrap") || panelElements.cv.parentElement;
      if (__cvWrap && "ResizeObserver" in window) {
        let __cvResizeRaf = 0;
        let __cvObservedWidth = -1;
        let __cvObservedHeight = -1;
        const __cvRO = new ResizeObserver((entries) => {
          const __entry = Array.isArray(entries)
            ? entries.find((item) => item && item.target === __cvWrap) || entries[0]
            : null;
          const __rect = __entry && __entry.contentRect ? __entry.contentRect : null;
          const __width = Math.round(Number((__rect && __rect.width) || 0) * 100) / 100;
          const __height = Math.round(Number((__rect && __rect.height) || 0) * 100) / 100;
          if (
            !(__width > 0 && __height > 0) ||
            (__width === __cvObservedWidth && __height === __cvObservedHeight)
          )
            return;
          __cvObservedWidth = __width;
          __cvObservedHeight = __height;
          if (__cvResizeRaf) return;
          __cvResizeRaf = requestAnimationFrame(() => {
            __cvResizeRaf = 0;
            if (__cvWrap.isConnected) resizeCanvas();
          });
        });
        __cvRO.observe(__cvWrap);
      }
    }
  }

  return Object.freeze({
    draw,
    resizeCanvas,
    mount,
  });
}
