/** material-search-binding: one runtime owner with explicit, immutable dependency ports. */
export function createMaterialSearchBinding({
  configurationState,
  materialBatches,
  materialCatalog,
  panelElements,
} = {}) {
  function mount3() {
    materialCatalog.sugActive = -1;
    materialCatalog.sugList = [];
    materialCatalog.__materialCatalogLiveVersion = null;
    materialCatalog.__materialCatalogRefreshBusy = false;
    materialCatalog.__materialCatalogLastSyncAt = 0;
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible") {
        materialCatalog.refreshMaterialCatalogLive({
          reRenderStep1: true,
          refreshSuggest: true,
        });
      }
    });
    window.addEventListener("focus", () => {
      materialCatalog.refreshMaterialCatalogLive({
        reRenderStep1: true,
        refreshSuggest: true,
      });
    });
    setTimeout(() => {
      materialCatalog.refreshMaterialCatalogLive({
        force: true,
        reRenderStep1: true,
      });
    }, 0);
    if (panelElements.matSearch && panelElements.matSuggest) {
      panelElements.matSearch.addEventListener("input", () => {
        materialCatalog.computeSuggest(panelElements.matSearch.value);
      });
      panelElements.matSearch.addEventListener("focus", () => {
        materialCatalog.computeSuggest(panelElements.matSearch.value);
      });
      panelElements.matSearch.addEventListener("keydown", (e) => {
        if (panelElements.matSuggest.style.display === "none") return;
        if (e.key === "ArrowDown") {
          e.preventDefault();
          materialCatalog.sugActive = Math.min(
            materialCatalog.sugActive + 1,
            materialCatalog.sugList.length - 1,
          );
          materialCatalog.renderSuggest(materialCatalog.sugList, materialCatalog.sugActive);
        }
        if (e.key === "ArrowUp") {
          e.preventDefault();
          materialCatalog.sugActive = Math.max(materialCatalog.sugActive - 1, 0);
          materialCatalog.renderSuggest(materialCatalog.sugList, materialCatalog.sugActive);
        }
        if (e.key === "Enter") {
          if (
            materialCatalog.sugActive >= 0 &&
            materialCatalog.sugList[materialCatalog.sugActive]
          ) {
            e.preventDefault();
            materialBatches.setMaterial(materialCatalog.sugList[materialCatalog.sugActive]);
          }
        }
        if (e.key === "Escape") {
          panelElements.matSuggest.style.display = "none";
        }
      });

      panelElements.matSuggest.addEventListener("mousedown", (e) => {
        const el = e.target.closest(".sugItem");
        if (!el) return;
        const idx = parseInt(el.getAttribute("data-idx") || "-1", 10);
        if (idx >= 0 && materialCatalog.sugList[idx])
          materialBatches.setMaterial(materialCatalog.sugList[idx]);
      });
    }
    document.addEventListener("click", (e) => {
      configurationState.ensureStateShape();
      // Alleen sluiten als suggest/keuze elementen bestaan
      const inSearch = panelElements.matSearch && e.target === panelElements.matSearch;
      const inSuggest =
        panelElements.matSuggest &&
        panelElements.matSuggest.contains &&
        panelElements.matSuggest.contains(e.target);
      const inChosen =
        panelElements.matChosen &&
        panelElements.matChosen.contains &&
        panelElements.matChosen.contains(e.target);
      if (inSearch || inSuggest || inChosen) return;
      if (panelElements.matSuggest) panelElements.matSuggest.style.display = "none";
    });
    if (panelElements.matClearBtn) {
      panelElements.matClearBtn.addEventListener("click", () => {
        configurationState.ensureStateShape();
        materialBatches.setMaterial(null);
      });
    }
  }

  return Object.freeze({
    mount3,
  });
}
