/** edge-presentation: one runtime owner with explicit, immutable dependency ports. */
export function createEdgePresentation({} = {}) {
  function _edgeMaskFromValue(edge) {
    // Returns {t:boolean,r:boolean,b:boolean,l:boolean}
    const s = String(edge || "")
      .trim()
      .toLowerCase();
    if (!s || s === "none" || s === "0") return { t: false, r: false, b: false, l: false };
    if (s === "all" || s === "1") return { t: true, r: true, b: true, l: true };
    // Support legacy bit-string like "t0r1b0l1"
    const m = s.match(/t([01]).*r([01]).*b([01]).*l([01])/);
    if (m)
      return {
        t: m[1] === "1",
        r: m[2] === "1",
        b: m[3] === "1",
        l: m[4] === "1",
      };
    // Support comma list like "top,right" (just in case)
    const parts = s.split(/[\s,;|]+/).filter(Boolean);
    const out = { t: false, r: false, b: false, l: false };
    for (const p of parts) {
      if (p === "t" || p === "top" || p === "boven") out.t = true;
      if (p === "r" || p === "right" || p === "rechts") out.r = true;
      if (p === "b" || p === "bottom" || p === "onder") out.b = true;
      if (p === "l" || p === "left" || p === "links") out.l = true;
    }
    return out;
  }

  function edgeCustomerText(edge, wMm, hMm) {
    const m = _edgeMaskFromValue(edge);
    const any = m.t || m.r || m.b || m.l;
    if (!any) return "Geen";
    if (m.t && m.r && m.b && m.l) return "Rondom";

    const w = Number(wMm);
    const h = Number(hMm);
    const hasDims = Number.isFinite(w) && Number.isFinite(h) && w > 0 && h > 0;
    const isSquare = hasDims && Math.abs(w - h) < 1; // 1mm tolerance

    // Determine long/short edges based on dimensions
    const longIsLR = hasDims && !isSquare && h > w; // staand paneel => lange zijden links/rechts
    const longIsTB = hasDims && !isSquare && w > h; // liggend paneel => lange zijden boven/onder

    const longMask = longIsLR
      ? { t: false, r: true, b: false, l: true }
      : longIsTB
        ? { t: true, r: false, b: true, l: false }
        : null;
    const shortMask = longIsLR
      ? { t: true, r: false, b: true, l: false }
      : longIsTB
        ? { t: false, r: true, b: false, l: true }
        : null;

    const isExactly = (maskA, maskB) =>
      maskA &&
      maskA.t === maskB.t &&
      maskA.r === maskB.r &&
      maskA.b === maskB.b &&
      maskA.l === maskB.l;

    if (hasDims && !isSquare) {
      if (isExactly(m, longMask)) return "Beide lange zijden";
      if (isExactly(m, shortMask)) return "Beide korte zijden";
    }

    const parts = [];
    const push = (label) => parts.push(label);

    const nameEdge = (edgeKey) => {
      if (isSquare || !hasDims) {
        if (edgeKey === "t") return "Boven";
        if (edgeKey === "r") return "Rechts";
        if (edgeKey === "b") return "Onder";
        if (edgeKey === "l") return "Links";
      }
      // Non-square: prefix with Lange/Korte zijde depending on orientation
      const isLong = longIsLR
        ? edgeKey === "l" || edgeKey === "r"
        : longIsTB
          ? edgeKey === "t" || edgeKey === "b"
          : false;
      const side =
        edgeKey === "t"
          ? "boven"
          : edgeKey === "r"
            ? "rechts"
            : edgeKey === "b"
              ? "onder"
              : "links";
      return `${isLong ? "Lange" : "Korte"} zijde ${side}`;
    };

    if (m.t) push(nameEdge("t"));
    if (m.r) push(nameEdge("r"));
    if (m.b) push(nameEdge("b"));
    if (m.l) push(nameEdge("l"));

    return parts.join(", ");
  }

  return Object.freeze({
    edgeCustomerText,
    _edgeMaskFromValue,
  });
}
