/** startup: one runtime owner with explicit, immutable dependency ports. */
export function createStartup({ extraEditor, extraPreview, panelPreview } = {}) {
  function mount() {
    panelPreview.resizeCanvas();
    extraEditor.renderExtraPanels();
    extraPreview.drawExtraPreview();
  }

  return Object.freeze({
    mount,
  });
}
