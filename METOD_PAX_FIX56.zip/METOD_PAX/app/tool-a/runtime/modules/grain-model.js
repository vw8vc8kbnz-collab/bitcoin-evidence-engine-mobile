import { ToolAGrainValidation } from "../../domain/grain-validation.js";
/** grain-model: one runtime owner with explicit, immutable dependency ports. */
export function createGrainModel({
  alertDialog,
  applicationState,
  configurationState,
  extraEditor,
  extraPreview,
  formatting,
  grainData,
  grainRendering,
  grainStatus,
  materialMetadata,
  panelEdges,
  panelEditSession,
  panelElements,
  panelList,
  wizardNavigation,
} = {}) {
  let handlersBound = false;

  function bindGrainHandlers() {
    panelElements.ensureGrainEls();
    if (handlersBound) return;
    // Only bind once when elements exist
    if (panelElements.grainNewGroupBtn)
      panelElements.grainNewGroupBtn.addEventListener("click", () => {
        configurationState.ensureStateShape();
        grainRendering.newGroup();
      });
    if (panelElements.grainWidthSel)
      panelElements.grainWidthSel.addEventListener("change", () => {
        panelElements.setGrainMsg("");
        rebuildGrainEligible();
      });
    if (panelElements.grainMatSel)
      panelElements.grainMatSel.addEventListener("change", () => {
        configurationState.ensureStateShape();
        applicationState.current.grain.materialKey = String(
          panelElements.grainMatSel.value || "",
        );
        grainRendering.syncSelectedGrainGroupForMaterial();
        panelElements.setGrainMsg("");
        rebuildGrainWidthOptions();
        rebuildGrainEligible();
        grainRendering.rebuildGrainGroups();
        grainRendering.drawGrainPreview();
        grainStatus.updateGrainBtnState();
      });
    if (panelElements.grainIncludeExtraToggle)
      panelElements.grainIncludeExtraToggle.addEventListener("change", () => {
        configurationState.ensureStateShape();
        applicationState.current.grain.includeExtraPanels =
          !!panelElements.grainIncludeExtraToggle.checked;
        panelElements.setGrainMsg("");
        rebuildGrainMaterialOptions();
        rebuildGrainWidthOptions();
        rebuildGrainEligible();
        grainRendering.rebuildGrainGroups();
        grainRendering.drawGrainPreview();
        grainStatus.updateGrainBtnState();
      });
    if (panelElements.grainCloseBtn)
      panelElements.grainCloseBtn.addEventListener("click", () => {
        try {
          wizardNavigation.showStep("panels");
        } catch (e) {
          closeGrainOverlay();
          wizardNavigation.renderFooterForStep &&
            wizardNavigation.renderFooterForStep("panels");
        }
      });
    if (panelElements.grainCancelBtn)
      panelElements.grainCancelBtn.addEventListener("click", () => {
        wizardNavigation.showStep("panels");
      });
    if (panelElements.grainApplyBtn)
      panelElements.grainApplyBtn.addEventListener("click", () => {
        applyGrainAndContinue();
      });
    if (panelElements.grainAlertOkBtn)
      panelElements.grainAlertOkBtn.addEventListener("click", () => {
        panelElements.setGrainMsg("");
      });
    if (panelElements.grainAlertOverlay)
      panelElements.grainAlertOverlay.addEventListener("click", (e) => {
        if (e && e.target === panelElements.grainAlertOverlay) panelElements.setGrainMsg("");
      });
    handlersBound = true;
  }

  function applyGrainAndContinue() {
    configurationState.ensureStateShape();
    // Validate grain groups against usable sheet size per materiaal.
    // Rules:
    // - No panel may exceed the usable sheet size (sheet - 2× margin)
    // - A grain group stack total height cannot exceed usable sheet height
    //   totalHeight = sum(panelHeights) + (n-1)*nestingGapMm
    // - Group width (max member width) cannot exceed usable sheet width
    {
      const margin = Number(
        applicationState.current?.sheetMarginMm ??
          applicationState.current?.defaults?.sheetMarginMm ??
          7,
      );
      const gap = Number(
        applicationState.current?.nestingGapMm ??
          applicationState.current?.defaults?.nestingGapMm ??
          16,
      );
      const groups = applicationState.current.grain.groups || [];
      for (const g of groups) {
        if (!g || !g.items || !g.items.length) continue;
        const mk = String(
          g.materialKey || grainData.grainOverlaySelectedMaterialKey() || "",
        ).trim();
        const batch = (applicationState.current.materialBatches || []).find(
          (b) => String(b.key || "") === mk,
        );
        const matObj = batch?.mat || applicationState.current.material;
        const sheetH = matObj?.sheetSizeMm?.height;
        const sheetW = matObj?.sheetSizeMm?.width;
        if (!sheetH || !sheetW) continue;
        const usableH = Number(sheetH) - 2 * margin;
        const usableW = Number(sheetW) - 2 * margin;
        let sumLen = 0;
        let maxW = 0;
        let n = 0;
        const widthCheck = [];
        for (const ref of g.items) {
          const e = grainData.getGrainEntryByRef(ref);
          if (!e) continue;
          const d = {
            w: Number(e.widthMm || 0),
            h: Number((e.baseHeightMm || 0) + (e.extTop || 0) + (e.extBot || 0) || 0),
          };
          if (!d) continue;
          widthCheck.push(Math.round(Number(e.widthMm || 0) * 1000) / 1000);
          const it = e.raw;
          if (!it) continue;
          n++;
          sumLen += d.h;
          maxW = Math.max(maxW, d.w);
          // Individual member must also fit the usable sheet (no rotation allowed in grain groups)
          {
            const fitCheck =
              ToolAGrainValidation &&
              typeof ToolAGrainValidation.getGroupValidation === "function"
                ? ToolAGrainValidation.getGroupValidation({
                    label: it.label || it.baseLabel || it.templateId || "paneel",
                    panelWidthMm: d.w,
                    panelHeightMm: d.h,
                    usableWidthMm: usableW,
                    usableHeightMm: usableH,
                    marginMm: margin,
                  })
                : null;
            if (fitCheck && !fitCheck.ok) {
              alert(fitCheck.message || "Paneel past niet op de plaat.");
              return;
            }
          }
          if (d.w > usableW + 0.01 || d.h > usableH + 0.01) {
            alert(
              `Paneel '${it.label || it.baseLabel || it.templateId || "paneel"}' past niet op de plaat (${Math.round(d.w)}×${Math.round(d.h)}mm > ${Math.round(usableW)}×${Math.round(usableH)}mm bruikbaar, marge ${margin}mm).`,
            );
            return;
          }
        }
        const uniqueWidths =
          window.ToolAGrainStudioMath &&
          typeof window.ToolAGrainStudioMath.distinctWidthsMm === "function"
            ? window.ToolAGrainStudioMath.distinctWidthsMm(widthCheck)
            : Array.from(new Set(widthCheck));
        const total = sumLen + Math.max(0, n - 1) * gap;
        {
          const groupCheck =
            ToolAGrainValidation &&
            typeof ToolAGrainValidation.getGroupValidation === "function"
              ? ToolAGrainValidation.getGroupValidation({
                  groupId: g.id,
                  uniqueWidths,
                  totalHeightMm: total,
                  maxWidthMm: maxW,
                  usableWidthMm: usableW,
                  usableHeightMm: usableH,
                  marginMm: margin,
                })
              : null;
          if (groupCheck && !groupCheck.ok) {
            alert(groupCheck.message || "Doorlopende nerf groep is ongeldig.");
            return;
          }
        }
        if (uniqueWidths.length > 1) {
          alert(
            `Doorlopende nerf groep ${g.id} bevat panelen met verschillende breedtes. Alleen panelen met dezelfde breedte kunnen een nerf-set vormen.`,
          );
          return;
        }
        if (total > usableH + 0.01) {
          alert(
            `Doorlopende nerf groep ${g.id} is te lang voor de plaathoogte (${Math.round(total)}mm > ${Math.round(usableH)}mm bruikbaar, marge ${margin}mm).`,
          );
          return;
        }
        if (maxW > usableW + 0.01) {
          alert(
            `Doorlopende nerf groep ${g.id} is te breed voor de plaatbreedte (${Math.round(maxW)}mm > ${Math.round(usableW)}mm bruikbaar, marge ${margin}mm).`,
          );
          return;
        }
      }
    }

    // groups with 1 item have no effect
    {
      const bad = (applicationState.current.grain?.groups || []).filter(
        (g) => g.items.length === 1,
      );
      if (bad.length) {
        panelElements.setGrainMsg("");
        try {
          alertDialog.showToolAlert(
            {
              title: "Nerf-set nog niet compleet",
              body: "Sleep minimaal 2 panelen in een nerf-set.",
              details: "Sleep nog een paneel met dezelfde breedte naar deze set.",
            },
            "Waarschuwing",
          );
        } catch (_) {
          alert(
            "Nerf-set nog niet compleet\n\nSleep minimaal 2 panelen in een nerf-set.\nSleep nog een paneel met dezelfde breedte naar deze set.",
          );
        }
        return;
      }
    }

    closeGrainOverlay();
    panelList.renderCart();
    extraEditor.renderExtraPanels();
    panelEdges.syncChecksFromSelect();
    extraPreview.drawExtraPreview();
    // Proceed to customer data step
    if (typeof wizardNavigation.showStep === "function")
      wizardNavigation.showStep("customer");
  }

  function openGrainOverlay() {
    panelElements.ensureGrainEls();
    bindGrainHandlers();
    panelElements.setGrainMsg("");
    rebuildGrainMaterialOptions();
    if (panelElements.grainIncludeExtraToggle)
      panelElements.grainIncludeExtraToggle.checked = !!grainData.grainExtrasEnabled();
    rebuildGrainWidthOptions();
    rebuildGrainEligible();
    // Always start with at least one open/selected nerfgroep so users can immediately drop panels
    {
      configurationState.ensureStateShape();
      const selMk = grainData.grainOverlaySelectedMaterialKey();
      const list = (applicationState.current.grain.groups || []).filter(
        (g) => !selMk || String(g.materialKey || "") === String(selMk),
      );
      if (!list.length) {
        grainRendering.newGroup();
      } else {
        // Ensure selected group belongs to selected material
        const selId = String(applicationState.current.grain.selectedGroupId || "");
        const ok = list.some((g) => String(g.id || "") === selId);
        if (!ok) {
          applicationState.current.grain.selectedGroupId = list[0]?.id || null;
        }
      }
    }
    grainRendering.rebuildGrainGroups();
    panelElements.setOverlayVisible("grainOverlay", true);
    wizardNavigation.setStep("grain");

    requestAnimationFrame(() => {
      if (
        window.ToolAGrainStudioMobile &&
        typeof window.ToolAGrainStudioMobile.onOverlayOpen === "function"
      )
        window.ToolAGrainStudioMobile.onOverlayOpen();
    });
  }

  function closeGrainOverlay() {
    panelElements.ensureGrainEls();
    panelElements.setOverlayVisible("grainOverlay", false);
  }

  function rebuildGrainMaterialOptions() {
    configurationState.ensureStateShape();
    if (!panelElements.grainMatSel) return;
    // Only materials that have grain enabled AND have at least 1 panel in cart
    const mats = new Map(); // key -> label

    for (const it of applicationState.current.cart || []) {
      const mk = String(it.materialKey || it.articleNumber || it.materialCode || "").trim();
      if (!mk) continue;
      if (!grainData.grainEnabledForKey(mk)) continue;
      const lbl = materialMetadata.materialLabelKey(mk) || mk;
      mats.set(mk, lbl);
    }
    if (grainData.grainExtrasEnabled()) {
      for (const p of applicationState.current.extraPanels || []) {
        const mk = String(p.materialKey || p.articleNumber || p.materialCode || "").trim();
        if (!mk) continue;
        if (!grainData.grainEnabledForKey(mk)) continue;
        const lbl = materialMetadata.materialLabelKey(mk) || mk;
        mats.set(mk, lbl);
      }
    }

    const keys = Array.from(mats.keys());
    // If no grain-enabled materials, show a disabled placeholder
    if (!keys.length) {
      panelElements.grainMatSel.innerHTML =
        '<option value="">Geen materialen met nerf</option>';
      panelElements.grainMatSel.disabled = true;
      applicationState.current.grain.materialKey = "";
      return;
    }
    panelElements.grainMatSel.disabled = false;
    const cur = grainData.grainOverlaySelectedMaterialKey();
    panelElements.grainMatSel.innerHTML = keys
      .map(
        (k) =>
          `<option value="${formatting._esc(k)}">${formatting._esc(mats.get(k) || k)}</option>`,
      )
      .join("");
    // Select current if possible else first
    if (cur && keys.includes(cur)) {
      panelElements.grainMatSel.value = cur;
      applicationState.current.grain.materialKey = cur;
    } else {
      panelElements.grainMatSel.value = keys[0];
      applicationState.current.grain.materialKey = keys[0];
    }
  }

  function rebuildGrainWidthOptions() {
    if (!panelElements.grainWidthSel) return;
    const eligible = grainData.getGrainEligibleEntries();
    const widths = Array.from(
      new Set(eligible.map((e) => Math.round(Number(e.widthMm || 0) * 1000) / 1000)),
    )
      .filter((w) => w > 0)
      .sort((a, b) => a - b);
    const cur = panelElements.grainWidthSel.value || "all";
    panelElements.grainWidthSel.innerHTML =
      '<option value="all">Alle breedtes</option>' +
      widths
        .map(
          (w) => `<option value="${w}">${Number.isInteger(w) ? w : w.toFixed(1)} mm</option>`,
        )
        .join("");
    // keep selection if possible
    if (widths.map(String).includes(String(cur)))
      panelElements.grainWidthSel.value = String(cur);
    else panelElements.grainWidthSel.value = "all";
  }

  function rebuildGrainEligible() {
    if (
      window.ToolAGrainStudioMobile &&
      typeof window.ToolAGrainStudioMobile.isActive === "function" &&
      window.ToolAGrainStudioMobile.isActive() &&
      typeof window.ToolAGrainStudioMobile.renderEligible === "function"
    ) {
      return window.ToolAGrainStudioMobile.renderEligible();
    }

    if (!panelElements.grainEligible || !panelElements.grainEligibleCount) return;
    panelElements.grainEligible.innerHTML = "";
    const eligible = grainData.getGrainEligibleEntries();

    panelElements.grainEligibleCount.textContent = String(eligible.length);

    if (panelElements.grainIncludeExtraToggle)
      panelElements.grainIncludeExtraToggle.checked = !!grainData.grainExtrasEnabled();

    if (!eligible.length) {
      const div = document.createElement("div");
      div.className = "help";
      div.textContent =
        "Geen panelen beschikbaar voor doorlopende houtnerf bij dit materiaal. Zet in stap 1 nerfrichting aan en voeg minimaal 2 panelen met dezelfde breedte toe.";
      panelElements.grainEligible.appendChild(div);
      return;
    }

    // available-panel buckets use the real production width in millimetres.
    // Nominal labels such as “60 cm” are intentionally not allowed to merge 597 mm and 595 mm.
    const groups = new Map();
    for (const e of eligible) {
      const w = Math.round(Number(e.widthMm || 0) * 1000) / 1000;
      if (!(w > 0)) continue;
      if (!groups.has(w)) groups.set(w, []);
      groups.get(w).push(e);
    }

    let widths = Array.from(groups.keys()).sort((a, b) => a - b);
    const fw = panelElements.grainWidthSel ? panelElements.grainWidthSel.value : "all";
    if (fw && fw !== "all")
      widths = widths.filter((w) => Math.abs(Number(w) - Number(fw)) <= 0.001);

    for (const w of widths) {
      const entries = groups.get(w) || [];

      const hEl = document.createElement("div");
      hEl.style.margin = "10px 0 6px";
      hEl.innerHTML = `<strong>Werkelijke breedte ${Number.isInteger(w) ? w : w.toFixed(1)} mm</strong> <span class="pill u-margin-left-8">${entries.length}</span>`;
      panelElements.grainEligible.appendChild(hEl);

      const sections = [
        { key: "cart", title: "METOD panelen" },
        { key: "extra", title: "Overige panelen" },
      ];

      for (const sec of sections) {
        const secEntries = entries.filter((e) => e.kind === sec.key);
        if (!secEntries.length) continue;
        const sh = document.createElement("div");
        sh.style.margin = "6px 0 6px";
        sh.innerHTML = `<small class="u-overline-muted">${sec.title}</small>`;
        panelElements.grainEligible.appendChild(sh);

        const displayGroups = grainData
          ._groupGrainDisplayEntries(secEntries)
          .sort((a, b) =>
            String(a?.rep?.label || "").localeCompare(String(b?.rep?.label || "")),
          );

        for (const group of displayGroups) {
          const rep = group.rep;
          const total = Math.max(1, group.items.length);
          const availableItems = group.items.filter((x) => !x.grainGroupId);
          const avail = availableItems.length;
          const chip = document.createElement("button");
          chip.type = "button";
          chip.disabled = avail <= 0;
          chip.dataset.grainChoice = String(rep.label || "");
          chip.className = "grainChip" + (avail > 0 ? "" : " disabled");
          chip.draggable = avail > 0;
          chip.setAttribute(
            "aria-label",
            `${rep.label}, ${avail} beschikbaar, toevoegen aan geselecteerde nerfgroep`,
          );
          chip.title = avail > 0 ? "" : "Dit paneel is al gebruikt in een nerfgroep.";

          let usedTxt = "Toevoegen →";
          if (avail <= 0) {
            const usedGroups = Array.from(
              new Set(group.items.map((x) => String(x.grainGroupId || "")).filter(Boolean)),
            );
            usedTxt = usedGroups.length
              ? "In groep " + usedGroups.join(", ")
              : "Niet beschikbaar";
          }

          chip.innerHTML = `
          <span class="u-min-width-zero">
            <span class="u-text-ellipsis">${formatting._esc(rep.label)}</span>
            <small>${total}× · ${Math.round(Number(rep.widthMm || 0))}×${Math.round(Number((rep.baseHeightMm || 0) + (rep.extTop || 0) + (rep.extBot || 0)))} mm${grainData.grainDoorDirectionLabel(rep.raw)}${grainData.grainExtLabel(rep.raw)}${rep.kind === "extra" ? " · overig" : ""}</small>
          </span>
          <span class="u-stack-align-end">
            <span class="pill">${avail}/${total} beschikbaar</span>
            <small>${formatting._esc(usedTxt)}</small>
          </span>
        `;

          chip.addEventListener("dragstart", (ev) => {
            if (avail <= 0) {
              ev.preventDefault();
              return;
            }
            const dragEntry = availableItems[0] || group.items[0];
            panelEditSession.currentDrag = {
              entryRef: dragEntry.ref,
              fromGroupId: null,
            };
            ev.dataTransfer.setData(
              "application/json",
              JSON.stringify(panelEditSession.currentDrag),
            );
            ev.dataTransfer.setData("text/plain", String(dragEntry.ref));
            ev.dataTransfer.effectAllowed = "move";
          });
          chip.addEventListener("click", () => {
            const restoreFocus = document.activeElement === chip;
            if (avail <= 0) return;
            {
              configurationState.ensureStateShape();
              let targetGroupId = String(
                applicationState.current?.grain?.selectedGroupId || "",
              );
              let targetGroup = (applicationState.current?.grain?.groups || []).find(
                (x) => String(x?.id || "") === targetGroupId,
              );
              const selectedMaterialKey = grainData.grainOverlaySelectedMaterialKey();
              if (
                !targetGroup ||
                String(targetGroup.materialKey || "") !== String(selectedMaterialKey || "")
              ) {
                targetGroup =
                  (applicationState.current?.grain?.groups || []).find(
                    (x) => String(x?.materialKey || "") === String(selectedMaterialKey || ""),
                  ) || null;
              }
              if (!targetGroup) {
                grainRendering.newGroup();
                targetGroupId = String(
                  applicationState.current?.grain?.selectedGroupId || "",
                );
                targetGroup =
                  (applicationState.current?.grain?.groups || []).find(
                    (x) => String(x?.id || "") === targetGroupId,
                  ) || null;
              }
              if (!targetGroup) return;
              const dragEntry = availableItems[0] || group.items[0];
              grainRendering.addItemToGroup(
                String(dragEntry.ref || ""),
                String(targetGroup.id || ""),
                null,
                null,
              );
              if (restoreFocus) {
                const choices = Array.from(
                  panelElements.grainEligible.querySelectorAll("button:not(:disabled)"),
                );
                const next =
                  choices.find((el) => el.dataset.grainChoice === String(rep.label || "")) ||
                  choices[0] ||
                  panelElements.grainGroups.querySelector("[data-act=select]");
                next?.focus({ preventScroll: true });
              }
            }
          });

          panelElements.grainEligible.appendChild(chip);
        }
      }
    }
  }

  function mount() {
    window.openGrainOverlay = window.openGrainOverlay || openGrainOverlay;
    window.closeGrainOverlay = window.closeGrainOverlay || closeGrainOverlay;
  }

  function mount2() {
    if (panelElements.grainBtn)
      panelElements.grainBtn.addEventListener("click", () => {
        configurationState.ensureStateShape();
        // State is normalized once at this event boundary.
        if (panelElements.grainBtn.disabled) return;
        if (
          !(
            applicationState.current.cart.length ||
            applicationState.current.extraPanels.length
          )
        ) {
          panelElements.setGrainMsg("Voeg eerst panelen toe voordat je een nerf-set maakt.");
          return;
        }
        openGrainOverlay();
        // If no groups, create one for convenience
        const selMk = grainData.grainOverlaySelectedMaterialKey();
        const list = (applicationState.current.grain.groups || []).filter(
          (g) => !selMk || String(g.materialKey || "") === String(selMk),
        );
        if (!list.length) {
          grainRendering.newGroup();
        } else {
          grainRendering.drawGrainPreview();
        }
      });
  }

  return Object.freeze({
    rebuildGrainWidthOptions,
    rebuildGrainEligible,
    mount,
    mount2,
  });
}
