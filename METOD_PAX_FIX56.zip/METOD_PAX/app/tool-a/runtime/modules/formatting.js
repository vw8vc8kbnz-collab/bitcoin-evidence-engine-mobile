import { ToolAMiscHelpers } from "../../domain/safe-helper-layer.js";
import { ToolAValidators } from "../../domain/validators.js";
/** formatting: one runtime owner with explicit, immutable dependency ports. */
export function createFormatting({} = {}) {
  function clampInt(v, min, max) {
    if (ToolAValidators && typeof ToolAValidators.clampInt === "function") {
      return ToolAValidators.clampInt(v, min, max);
    }

    const n = parseInt(String(v || "0"), 10);
    if (!Number.isFinite(n)) return min;
    return Math.max(min, Math.min(max, n));
  }

  function formatMm(n) {
    // show without decimals if near int
    const r = Math.round(n);
    if (Math.abs(n - r) < 0.05) return String(r);
    return String(n.toFixed(1));
  }

  function groupBy(arr, fn) {
    if (ToolAMiscHelpers && typeof ToolAMiscHelpers.groupBy === "function") {
      return ToolAMiscHelpers.groupBy(arr, fn);
    }
    const m = {};
    for (const x of arr) {
      const k = String(fn(x));
      (m[k] ||= []).push(x);
    }
    return m;
  }

  function _esc(s) {
    if (ToolAMiscHelpers && typeof ToolAMiscHelpers.escapeHtml === "function") {
      return ToolAMiscHelpers.escapeHtml(s);
    }
    return String(s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  return Object.freeze({
    groupBy,
    _esc,
    clampInt,
    formatMm,
  });
}
