/** Initialize the catalog wizard before asynchronous template loading. */
export function createCatalogStartup({
  applicationState,
  configurationState,
  feedback,
  panelControls,
  panelPreview,
  wizardNavigation,
} = {}) {
  function mount() {
    configurationState.ensureStateShape();
    applicationState.current.route = "metod";
    (async () => {
      try {
        // Initialiseer vóór het asynchrone templatewerk. Als de gebruiker daarna
        // al naar Stap 2 navigeert, mag een late template-respons die keuze niet
        // meer overschrijven met Stap 1.
        const startupStep = String(window.__metod_uiStep || "material");
        wizardNavigation.setStep(startupStep);
        if (typeof wizardNavigation.renderFooterForStep === "function")
          wizardNavigation.renderFooterForStep(startupStep);
        // Laad templates (ingebouwd) async, zodat UI niet bevriest
        if (applicationState.current.templates.size === 0) {
          try {
            await panelControls.loadEmbeddedTemplates();
          } catch (e) {
            console.warn("loadEmbeddedTemplates failed", e);
          }
        }
        const currentStepAfterTemplates = String(
          window.__metod_uiStep || startupStep || "material",
        );
        if (typeof wizardNavigation.renderFooterForStep === "function")
          wizardNavigation.renderFooterForStep(currentStepAfterTemplates);
        feedback.updateWizardBanner();
        panelControls.enableControlsIfReady();
        panelPreview.draw();
      } catch (e) {
        console.warn("Auto-start failed", e);
      }
    })();
  }

  return Object.freeze({
    mount,
  });
}
