import { ToolAPanelMutations } from "../../domain/panel-mutations.js";
import { ToolAPanelSubmitApply } from "../../domain/panel-submit-apply.js";
import { ToolAPanelSubmitFlow } from "../../domain/panel-submit-flow.js";
/** panel-controls: one runtime owner with explicit, immutable dependency ports. */
export function createPanelControls({
  applicationState,
  configurationState,
  domLookup,
  extraEditor,
  extraPreview,
  feedback,
  formatting,
  grainData,
  materialSelectionView,
  panelDock,
  panelEdges,
  panelEditSession,
  panelElements,
  panelForm,
  panelList,
  panelPreview,
  panelTypes,
  selectionState,
  templateCatalog,
  templateParser,
} = {}) {
  async function loadEmbeddedTemplates() {
    // Load embedded DXFs progressively to keep UI responsive.
    await templateCatalog._loadEmbedManifest();
    let ok = 0,
      bad = 0;
    for (const name of templateCatalog.EMBED_DXF_FILES || []) {
      try {
        await templateCatalog.ensureTemplateLoadedById(
          templateParser.makeTemplateId(name),
        );
        ok++;
      } catch (err) {
        console.warn("Embedded template failed", name, err);
        bad++;
      }
      // Yield to UI every few files
      if ((ok + bad) % 3 === 0) {
        await new Promise((r) => setTimeout(r, 0));
      }
    }
  }

  function enableControlsIfReady() {
    const ready =
      applicationState.current.route === "metod" &&
      (applicationState.current.templates.size > 0 ||
        (Array.isArray(templateCatalog.EMBED_DXF_FILES) &&
          templateCatalog.EMBED_DXF_FILES.length > 0));
    // Sommige controls zitten pas in de DOM nadat stap 2 actief wordt.
    // Zorg dat ontbrekende elementen de app niet laten crashen.
    const setDis = (el, v) => {
      if (el) el.disabled = v;
    };
    setDis(panelElements.typeSel, !ready);
    setDis(panelElements.qty, !ready);
    setDis(panelElements.hingeSel, !ready);
    setDis(panelElements.extTop, !ready);
    setDis(panelElements.extBot, !ready);
    setDis(panelElements.matSearch, !ready);
    setDis(panelElements.edgeSel, !ready);
    materialSelectionView.updateButtons();
    setDis(panelElements.sizeSel, !ready);
    if (panelElements.extraOverlayBtn)
      setDis(panelElements.extraOverlayBtn, !ready);

    if (ready) {
      panelTypes.syncDefaultPanelTypeSelection();
      window.__refreshCustomLabelVisibility?.();
      templateCatalog.populateSizeDropdown();
      setDis(
        panelElements.addBtn,
        !applicationState.current.selection.templateId,
      );
    } else {
      if (panelElements.sizeSel)
        panelElements.sizeSel.innerHTML =
          '<option value="">— Kies een maat —</option>';
      setDis(panelElements.addBtn, true);
    }
  }

  function standardPanelInputSignature() {
    return JSON.stringify({
      selection: applicationState.current.selection,
      materialKey: applicationState.current.activeMaterialKey,
      qty: panelElements.qty?.value,
      name: document.getElementById("customLabelInput")?.value,
      edit: [
        panelEditSession.panelEditTargetId,
        panelEditSession.panelEditGroupKey,
        panelEditSession.panelEditOriginalCount,
      ],
      step: window.__metod_uiStep,
      cart: applicationState.current.cart,
      extraPanels: applicationState.current.extraPanels,
    });
  }

  async function prepareStandardPanelSubmitInput() {
    const signature = standardPanelInputSignature();
    const template = await templateCatalog.loadSelectedPanelTemplate();
    if (!template) return null;
    if (signature !== standardPanelInputSignature()) {
      feedback.flashWarn(
        "Je invoer is gewijzigd. Controleer het paneel en klik opnieuw op Toevoegen.",
      );
      return null;
    }
    return getStandardPanelSubmitInput();
  }

  function getStandardPanelSubmitInput() {
    configurationState.ensureStateShape();
    const t = applicationState.current.templates.get(
      applicationState.current.selection.templateId,
    );
    return {
      submitOwner:
        ToolAPanelSubmitApply &&
        typeof ToolAPanelSubmitApply.execute === "function"
          ? ToolAPanelSubmitApply
          : null,
      state: applicationState.current,
      selectionCommands: selectionState,
      template: t,
      addBtn: panelElements.addBtn,
      qtyElement: panelElements.qty,
      customLabelInput: document.getElementById("customLabelInput"),
      liveForm:
        typeof window !== "undefined" && window.__panelEditLiveForm
          ? window.__panelEditLiveForm
          : null,
      panelSubmitFlow:
        ToolAPanelSubmitFlow &&
        typeof ToolAPanelSubmitFlow.getSubmitPlan === "function"
          ? ToolAPanelSubmitFlow
          : null,
      panelMutationAdapter:
        ToolAPanelMutations &&
        typeof ToolAPanelMutations.applyUpsert === "function"
          ? ToolAPanelMutations
          : null,
      editStateFallback: {
        targetId:
          (typeof panelEditSession.resolvePanelEditTargetId === "function"
            ? panelEditSession.resolvePanelEditTargetId()
            : panelEditSession.panelEditTargetId) ||
          panelEditSession.panelEditTargetId ||
          "",
        groupKey:
          (typeof panelEditSession.resolvePanelEditGroupKey === "function"
            ? panelEditSession.resolvePanelEditGroupKey()
            : panelEditSession.panelEditGroupKey) ||
          panelEditSession.panelEditGroupKey ||
          "",
        originalCount: Number(
          (typeof panelEditSession.resolvePanelEditOriginalCount === "function"
            ? panelEditSession.resolvePanelEditOriginalCount()
            : panelEditSession.panelEditOriginalCount) ||
            panelEditSession.panelEditOriginalCount ||
            0,
        ),
      },
      flashWarn: feedback.flashWarn,
      matSearch: panelElements.matSearch,
      validatePanelFits: panelDock.validatePanelFitsSheetMm,
      setPanelEditMode: panelForm.setPanelEditMode,
      clearAllGrainAssignments: grainData.clearAllGrainAssignments,
      scheduleDraftSave: feedback.scheduleDraftSave,
      pulsePanelDock: panelDock.pulsePanelDock,
      renderCart: panelList.renderCart,
      renderExtraPanels: extraEditor.renderExtraPanels,
      syncChecksFromSelect: panelEdges.syncChecksFromSelect,
      drawExtraPreview: extraPreview.drawExtraPreview,
    };
  }

  function mount() {
    if (panelElements.typeSel) {
      panelElements.typeSel.addEventListener("change", () => {
        selectionState.update({ type: panelElements.typeSel.value });
        selectionState.update({ templateId: "" });
        const __preserveEditValues = !!(
          typeof window !== "undefined" && window.__prefillingPanelEdit
        );
        // Nieuwe keuze = terug naar standaard verlenging
        if (!__preserveEditValues) {
          selectionState.update({ extTop: 0 });
          selectionState.update({ extBot: 0 });
          if (panelElements.extTop) panelElements.extTop.value = 0;
          if (panelElements.extBot) panelElements.extBot.value = 0;
        }
        templateCatalog.populateSizeDropdown();
        panelPreview.draw();
      });
    }
    if (panelElements.sizeSel) {
      // Do NOT intercept pointerdown on native <select> (causes "2x click").
      // Catalog is refreshed via SSE in the background.

      panelElements.sizeSel.addEventListener("change", async () => {
        selectionState.update({ templateId: panelElements.sizeSel.value });
        const __preserveEditValues = !!(
          typeof window !== "undefined" && window.__prefillingPanelEdit
        );
        // Bij wisselen van maat: standaard verlenging terugzetten
        if (!__preserveEditValues) {
          selectionState.update({ extTop: 0 });
          selectionState.update({ extBot: 0 });
          if (panelElements.extTop) panelElements.extTop.value = 0;
          if (panelElements.extBot) panelElements.extBot.value = 0;
        }
        if (panelElements.addBtn)
          panelElements.addBtn.disabled =
            !applicationState.current.selection.templateId;
        await templateCatalog.loadSelectedPanelTemplate();
      });
    }
    document
      .getElementById("templateLoadRetry")
      ?.addEventListener("click", () =>
        templateCatalog.loadSelectedPanelTemplate(),
      );
    if (panelElements.qty) {
      panelElements.qty.addEventListener("input", () => {
        const raw = String(panelElements.qty.value ?? "").trim();
        if (raw === "") {
          return;
        }
        const num = Number(raw);
        if (Number.isFinite(num))
          selectionState.update({ qty: formatting.clampInt(num, 1, 999) });
      });
      panelElements.qty.addEventListener("blur", () => {
        const raw = String(panelElements.qty.value ?? "").trim();
        selectionState.update({
          qty: formatting.clampInt(
            raw === "" ? applicationState.current.selection.qty || 1 : raw,
            1,
            999,
          ),
        });
        panelElements.qty.value = applicationState.current.selection.qty;
      });
      panelElements.qty.addEventListener("input", () => {
        window.__panelEditTouchedFields = Object.assign(
          {},
          window.__panelEditTouchedFields || {},
          {
            qty: true,
          },
        );
      });
    }
    {
      if (
        panelElements.hingeSel &&
        !panelElements.hingeSel.__panelEditTouchBound
      ) {
        panelElements.hingeSel.addEventListener("change", () => {
          window.__panelEditTouchedFields = Object.assign(
            {},
            window.__panelEditTouchedFields || {},
            { hinge: true },
          );
        });
        panelElements.hingeSel.__panelEditTouchBound = true;
      }
      if (panelElements.extTop && !panelElements.extTop.__panelEditTouchBound) {
        panelElements.extTop.addEventListener("input", () => {
          window.__panelEditTouchedFields = Object.assign(
            {},
            window.__panelEditTouchedFields || {},
            { extTop: true },
          );
        });
        panelElements.extTop.__panelEditTouchBound = true;
      }
      if (panelElements.extBot && !panelElements.extBot.__panelEditTouchBound) {
        panelElements.extBot.addEventListener("input", () => {
          window.__panelEditTouchedFields = Object.assign(
            {},
            window.__panelEditTouchedFields || {},
            { extBot: true },
          );
        });
        panelElements.extBot.__panelEditTouchBound = true;
      }
      const __cli = domLookup.byId("customLabelInput");
      if (__cli && !__cli.__panelEditTouchBound) {
        __cli.addEventListener("input", () => {
          window.__panelEditTouchedFields = Object.assign(
            {},
            window.__panelEditTouchedFields || {},
            { customLabel: true },
          );
        });
        __cli.__panelEditTouchBound = true;
      }
    }
    if (panelElements.hingeSel) {
      panelElements.hingeSel.addEventListener("change", () => {
        selectionState.update({ hinge: panelElements.hingeSel.value });
        panelPreview.draw();
      });
    }
    if (panelElements.extTop) {
      panelElements.extTop.addEventListener("input", () => {
        selectionState.update({
          extTop: formatting.clampInt(panelElements.extTop.value, 0, 999),
        });
        panelElements.extTop.value = applicationState.current.selection.extTop;
        panelPreview.draw();
      });
    }
    if (panelElements.extBot) {
      panelElements.extBot.addEventListener("input", () => {
        selectionState.update({
          extBot: formatting.clampInt(panelElements.extBot.value, 0, 999),
        });
        panelElements.extBot.value = applicationState.current.selection.extBot;
        panelPreview.draw();
      });
    }
    {
      const __customInput = domLookup.byId("customLabelInput");
      if (__customInput && !__customInput.__customStateBound) {
        __customInput.addEventListener("input", () => {
          selectionState.update({
            customLabel: String(__customInput.value || "").trim(),
          });
          panelForm.syncPanelEditLiveForm();
        });
        __customInput.__customStateBound = true;
      }
      if (panelElements.qty && !panelElements.qty.__panelLiveSyncBound) {
        panelElements.qty.addEventListener("input", () => {
          panelForm.syncPanelEditLiveForm();
        });
        panelElements.qty.__panelLiveSyncBound = true;
      }
      if (
        panelElements.hingeSel &&
        !panelElements.hingeSel.__panelLiveSyncBound
      ) {
        panelElements.hingeSel.addEventListener("change", () => {
          panelForm.syncPanelEditLiveForm();
        });
        panelElements.hingeSel.__panelLiveSyncBound = true;
      }
      if (panelElements.extTop && !panelElements.extTop.__panelLiveSyncBound) {
        panelElements.extTop.addEventListener("input", () => {
          panelForm.syncPanelEditLiveForm();
        });
        panelElements.extTop.__panelLiveSyncBound = true;
      }
      if (panelElements.extBot && !panelElements.extBot.__panelLiveSyncBound) {
        panelElements.extBot.addEventListener("input", () => {
          panelForm.syncPanelEditLiveForm();
        });
        panelElements.extBot.__panelLiveSyncBound = true;
      }
    }
    if (panelElements.edgeSel) {
      panelElements.edgeSel.addEventListener("change", () => {
        selectionState.update({ edge: panelElements.edgeSel.value });
        panelPreview.draw();
      });
    }
  }

  return Object.freeze({
    enableControlsIfReady,
    loadEmbeddedTemplates,
    prepareStandardPanelSubmitInput,
    getStandardPanelSubmitInput,
    mount,
  });
}
