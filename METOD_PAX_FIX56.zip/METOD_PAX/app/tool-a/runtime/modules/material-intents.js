/** material-intents: one runtime owner with explicit, immutable dependency ports. */
export function createMaterialIntents({} = {}) {
  let handlers;

  function bind(actions) {
    if (handlers) throw new Error("Material actions are already connected");
    if (typeof actions?.activate !== "function" || typeof actions?.remove !== "function") {
      throw new TypeError("Both material action handlers are required");
    }
    handlers = Object.freeze({
      activate: actions.activate,
      remove: actions.remove,
    });
  }

  function activate(key) {
    if (!handlers) throw new Error("Material actions are not connected");
    if (key !== null && typeof key !== "string") throw new TypeError("Invalid material key");
    handlers.activate(key);
  }

  function remove(key) {
    if (!handlers) throw new Error("Material actions are not connected");
    if (typeof key !== "string" || !key.trim()) throw new TypeError("Invalid material key");
    handlers.remove(key);
  }

  return Object.freeze({
    activate,
    remove,
    bind,
  });
}
