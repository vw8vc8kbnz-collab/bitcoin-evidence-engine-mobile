/** job-client: one runtime owner with explicit, immutable dependency ports. */
export function createJobClient({ applicationState, foundation } = {}) {
  function buildJobTokenHeaders(accessToken) {
    const tok = String(
      accessToken ||
        applicationState.current?.lastJobAccessToken ||
        window.__metod_last_job_access_token ||
        "",
    ).trim();
    if (!tok) return {};
    // one canonical secret transport only. Never place job tokens in URL/body.
    return { Authorization: `Bearer ${tok}` };
  }

  function r9JobsOwner() {
    const owner = foundation.current;
    if (
      !owner ||
      typeof owner.startJob !== "function" ||
      typeof owner.pollJob !== "function" ||
      typeof owner.fetchJobPricingSummary !== "function" ||
      typeof owner.authoritativeTotalInclVat !== "function"
    ) {
      throw new Error("De jobmodule is niet geladen. Herlaad Tool A en probeer opnieuw.");
    }
    return owner;
  }

  return Object.freeze({
    r9JobsOwner,
    buildJobTokenHeaders,
  });
}
