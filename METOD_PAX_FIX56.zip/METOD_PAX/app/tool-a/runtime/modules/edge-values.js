/** edge-values: one runtime owner with explicit, immutable dependency ports. */
export function createEdgeValues({} = {}) {
  function edgeHWFromEdgeVal(edgeVal) {
    const m = edgeMaskFromValue(edgeVal);
    return {
      H1: m.top ? 1 : 0,
      H2: m.bottom ? 1 : 0,
      W1: m.left ? 1 : 0,
      W2: m.right ? 1 : 0,
    };
  }

  function edgeHWText(edgeVal) {
    const e = edgeHWFromEdgeVal(edgeVal);
    return `H1=${e.H1} · H2=${e.H2} · W1=${e.W1} · W2=${e.W2}`;
  }

  function edgeMaskFromValue(v) {
    if (v === "all") return { top: 1, right: 1, bottom: 1, left: 1 };
    if (v === "lr") return { top: 0, right: 1, bottom: 0, left: 1 };
    if (v === "tb") return { top: 1, right: 0, bottom: 1, left: 0 };
    if (v === "none") return { top: 0, right: 0, bottom: 0, left: 0 };
    const m = String(v).match(/^t([01])r([01])b([01])l([01])$/);
    if (m) {
      return {
        top: Number(m[1]),
        right: Number(m[2]),
        bottom: Number(m[3]),
        left: Number(m[4]),
      };
    }
    return { top: 0, right: 0, bottom: 0, left: 0 };
  }

  return Object.freeze({
    edgeMaskFromValue,
    edgeHWText,
  });
}
