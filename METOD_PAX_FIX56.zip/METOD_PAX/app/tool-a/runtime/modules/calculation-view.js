import { ToolAMiscHelpers } from "../../domain/safe-helper-layer.js";
/** calculation-view: one runtime owner with explicit, immutable dependency ports. */
export function createCalculationView({} = {}) {
  let saveQuoteBtn;
  let saveStatus;
  let wizardBannerEl;
  let priceBarTotalEl;
  let priceBarSubEl;
  let priceBarMetaEl;
  let priceBarBtnOverview;
  let priceBarBtnCalc;

  function showSavingToast() {
    if (ToolAMiscHelpers && typeof ToolAMiscHelpers.showSavingToast === "function") {
      return ToolAMiscHelpers.showSavingToast(saveStatus);
    }
    if (!saveStatus) return;
    saveStatus.textContent = "Opslaan…";
    saveStatus.classList.remove("hasText");
    saveStatus.classList.add("isSaving");
  }

  function statusMsg(msg, isErr = false) {
    if (ToolAMiscHelpers && typeof ToolAMiscHelpers.statusMsg === "function") {
      return ToolAMiscHelpers.statusMsg(saveStatus, msg, isErr);
    }
    if (!saveStatus) return;
    const has = !!(msg && String(msg).trim());
    saveStatus.textContent = has ? String(msg) : "";
    saveStatus.classList.remove("isSaving");
    saveStatus.classList.toggle("hasText", has);
    saveStatus.style.color = isErr ? "#ff6b6b" : "#2fbf6a";
    saveStatus.style.borderColor = isErr ? "rgba(255,107,107,.28)" : "rgba(58,61,64,.20)";
    saveStatus.style.background = isErr ? "rgba(255,107,107,.10)" : "rgba(58,61,64,.08)";
  }

  function moneyEUR(n) {
    if (ToolAMiscHelpers && typeof ToolAMiscHelpers.moneyEUR === "function") {
      return ToolAMiscHelpers.moneyEUR(n);
    }
    const v = Number(n);
    if (!Number.isFinite(v)) return "€0,00";
    return "€" + v.toFixed(2).replace(".", ",");
  }

  function setCalculationEntryPointsDisabled(disabled) {
    const shouldDisable = disabled === true;
    if (saveQuoteBtn) saveQuoteBtn.disabled = shouldDisable;
    if (priceBarBtnCalc) priceBarBtnCalc.disabled = shouldDisable;
    {
      const overviewCalculate = document.getElementById("overviewNextBtn");
      if (overviewCalculate) overviewCalculate.disabled = shouldDisable;
    }
  }

  function initialize() {
    saveQuoteBtn = document.getElementById("saveQuoteBtn");
    saveStatus = document.getElementById("saveStatus");
    wizardBannerEl = document.getElementById("wizardBanner");
    priceBarTotalEl = document.getElementById("priceBarTotal");
    priceBarSubEl = document.getElementById("priceBarSub");
    priceBarMetaEl = document.getElementById("priceBarMeta");
    priceBarBtnOverview = document.getElementById("priceBarBtnOverview");
    priceBarBtnCalc = document.getElementById("priceBarBtnCalc");
  }

  return Object.freeze({
    statusMsg,
    setCalculationEntryPointsDisabled,
    moneyEUR,
    get saveQuoteBtn() {
      return saveQuoteBtn;
    },
    get priceBarBtnCalc() {
      return priceBarBtnCalc;
    },
    get priceBarBtnOverview() {
      return priceBarBtnOverview;
    },
    get priceBarTotalEl() {
      return priceBarTotalEl;
    },
    get priceBarSubEl() {
      return priceBarSubEl;
    },
    get priceBarMetaEl() {
      return priceBarMetaEl;
    },
    showSavingToast,
    get saveStatus() {
      return saveStatus;
    },
    get wizardBannerEl() {
      return wizardBannerEl;
    },
    initialize,
  });
}
