/** grain-status: one runtime owner with explicit, immutable dependency ports. */
export function createGrainStatus({ grainData, panelElements } = {}) {
  function updateGrainBtnState() {
    const eligible = grainData.getGrainEligibleEntries();
    const byW = new Map();
    for (const e of eligible) {
      const w = Math.round(Number(e.widthMm || 0) * 1000) / 1000;
      byW.set(w, (byW.get(w) || 0) + 1);
    }
    const ok = Array.from(byW.values()).some((v) => v >= 2);
    if (!panelElements.grainBtn) return;
    panelElements.grainBtn.disabled = !ok;
    panelElements.grainBtn.title = ok
      ? "Nerf laten doorlopen instellen"
      : "Voeg minimaal 2 panelen met dezelfde breedte (en nerf-materiaal) toe.";
  }

  return Object.freeze({
    updateGrainBtnState,
  });
}
