/** job-estimates: one runtime owner with explicit, immutable dependency ports. */
export function createJobEstimates({} = {}) {
  let PUBLIC_JOB_PANEL_LIMIT;
  let PUBLIC_JOB_AREA_WARN_LB;
  let PUBLIC_JOB_AREA_HARD_LB;
  let PUBLIC_JOB_PAYLOAD_MAX_BYTES;

  function csvEscape(v) {
    const s = String(v ?? "");
    if (s.includes(";") || s.includes("\n") || s.includes('"'))
      return '"' + s.replace(/"/g, '""') + '"';
    return s;
  }

  function buildPanelsCsv(rows) {
    const header = [
      "PartId",
      "PanelName",
      "Qty",
      "LengthMm",
      "WidthMm",
      "ThicknessMm",
      "MaterialCode",
      "GrainGroup",
      "RotationAllowed",
      "H1",
      "H2",
      "W1",
      "W2",
      "ProjectName",
      "OrderNumber",
      "ArticleNumber",
      "DecorName",
      "Note",
    ].join(";");
    const lines = [header];
    for (const r of rows) {
      lines.push(
        [
          r.PartId,
          r.PanelName,
          r.Qty,
          r.LengthMm,
          r.WidthMm,
          r.ThicknessMm,
          r.MaterialCode,
          r.GrainGroup || "",
          r.RotationAllowed ? "true" : "false",
          r.H1,
          r.H2,
          r.W1,
          r.W2,
          r.ProjectName || "",
          r.OrderNumber || "",
          r.ArticleNumber || "",
          r.DecorName || "",
          r.Note || "",
        ]
          .map(csvEscape)
          .join(";"),
      );
    }
    return lines.join("\n");
  }

  function estimatePreflightFromRows(rows, mats, pricing) {
    const out = { totalQty: 0, maxAreaLowerBound: 0, byMaterial: [] };
    {
      const defaults = pricing && pricing.defaults ? pricing.defaults : {};
      const sheetMarginMm = Number(defaults.sheetMarginMm ?? 7) || 7;
      const materialMap = new Map();
      Array.from(mats && mats.values ? mats.values() : []).forEach((m) => {
        materialMap.set(String(m.materialCode || "").trim(), m);
      });
      const areaByMaterial = new Map();
      for (const r of rows || []) {
        const qty = Math.max(1, Number(r?.Qty || 1) || 1);
        const w = Math.max(0, Number(r?.WidthMm || 0) || 0);
        const h = Math.max(0, Number(r?.LengthMm || 0) || 0);
        const code = String(r?.MaterialCode || "").trim();
        if (!code || w <= 0 || h <= 0) continue;
        out.totalQty += qty;
        areaByMaterial.set(code, (areaByMaterial.get(code) || 0) + w * h * qty);
      }
      for (const [code, totalArea] of areaByMaterial.entries()) {
        const mat = materialMap.get(code) || {};
        const sheetW = Math.max(0, Number(mat?.sheetSizeMm?.width || 0) || 0);
        const sheetH = Math.max(0, Number(mat?.sheetSizeMm?.height || 0) || 0);
        const usableW = Math.max(0, sheetW - 2 * sheetMarginMm);
        const usableH = Math.max(0, sheetH - 2 * sheetMarginMm);
        const usableArea = usableW * usableH;
        const areaLowerBound =
          usableArea > 0 ? Math.max(1, Math.ceil(totalArea / usableArea - 1e-12)) : 0;
        out.byMaterial.push({
          materialCode: code,
          areaLowerBound,
          totalAreaMm2: totalArea,
          usableAreaMm2: usableArea,
        });
        if (areaLowerBound > out.maxAreaLowerBound) out.maxAreaLowerBound = areaLowerBound;
      }
    }
    return out;
  }

  function initialize() {
    PUBLIC_JOB_PANEL_LIMIT = 250;
    PUBLIC_JOB_AREA_WARN_LB = 80;
    PUBLIC_JOB_AREA_HARD_LB = 250;
    PUBLIC_JOB_PAYLOAD_MAX_BYTES = 134217728;
  }

  return Object.freeze({
    get PUBLIC_JOB_PANEL_LIMIT() {
      return PUBLIC_JOB_PANEL_LIMIT;
    },
    get PUBLIC_JOB_AREA_HARD_LB() {
      return PUBLIC_JOB_AREA_HARD_LB;
    },
    get PUBLIC_JOB_PAYLOAD_MAX_BYTES() {
      return PUBLIC_JOB_PAYLOAD_MAX_BYTES;
    },
    get PUBLIC_JOB_AREA_WARN_LB() {
      return PUBLIC_JOB_AREA_WARN_LB;
    },
    buildPanelsCsv,
    estimatePreflightFromRows,
    csvEscape,
    initialize,
  });
}
