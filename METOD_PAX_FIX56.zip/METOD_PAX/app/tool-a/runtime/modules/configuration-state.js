/** configuration-state: one runtime owner with explicit, immutable dependency ports. */
export function createConfigurationState({ selectionState } = {}) {
  let currentState;

  function ensureStateShape() {
    if (typeof currentState !== "object" || currentState === null) return;

    // Top-level arrays
    if (!Array.isArray(currentState.cart)) currentState.cart = [];
    if (!Array.isArray(currentState.extraPanels)) currentState.extraPanels = [];
    // route is a string ('metod'|'pax') or null
    if (typeof currentState.route !== "string") currentState.route = null;
    if (!Array.isArray(currentState.materialBatches)) currentState.materialBatches = [];

    // UI state
    if (typeof currentState.ui !== "object" || currentState.ui === null) currentState.ui = {};
    if (!currentState.ui.step) currentState.ui.step = "config";

    // Grain state (prevents 'undefined.length' crashes on g.items / groups)
    if (typeof currentState.grain !== "object" || currentState.grain === null)
      currentState.grain = {
        groups: [],
        selectedGroupId: null,
        includeExtraPanels: false,
      };
    if (!Array.isArray(currentState.grain.groups)) currentState.grain.groups = [];
    if (typeof currentState.grain.includeExtraPanels !== "boolean")
      currentState.grain.includeExtraPanels = false;
    currentState.grain.groups.forEach((g) => {
      if (!g || typeof g !== "object") return;
      if (!Array.isArray(g.items)) g.items = [];
    });
  }

  function mount() {
    currentState = {
      material: null,
      grainEnabled: true,
      route: null,
      grain: { groups: [], selectedGroupId: null, includeExtraPanels: false }, // grain overlay state
      templates: new Map(), // id -> {id,label,type,cmW,cmH, realW, realH, outline:{minX,maxX,minY,maxY}, holes:[{x,y,r}], sourceName}
      catalog: { deur: [], lade: [], pax_deur: [], special: [] },
      embedIndex: {}, // templateId -> filename for embedded DXFs
      selection: {
        type: "deur",
        templateId: "",
        qty: 1,
        hinge: "left",
        extTop: 0,
        extBot: 0,
        material: "oak",
        edge: "all",
      },
      cart: [],
      extraPanels: [],
      checkout: {
        restCarry: true, // true/false (default: ja)
        customer: {
          firstName: "",
          lastName: "",
          company: "",
          email: "",
          phone: "",
          billingAddress: "",
          shippingAddress: "",
          shippingPostcode: "",
          shippingHouseNumber: "",
          shippingSameAsBilling: true,
          postcode: "",
          houseNumber: "",
          address1: "",
          address2: "",
          city: "",
        },
        note: "",
      },
    };
    selectionState.attach(currentState);
  }

  function mount2() {
    ensureStateShape();
  }

  return Object.freeze({
    get current() {
      return currentState;
    },
    ensureStateShape,
    mount,
    mount2,
  });
}
