/** panel-elements: one runtime owner with explicit, immutable dependency ports. */
export function createPanelElements({ foundation } = {}) {
  let grainIncludeExtraToggle, grainMatSel, grainGroupsWrap, grainEligibleWrap;

  let overlay;
  let overlayRouterOwner;
  let builtinCount;
  let typeSel;
  let sizeSel;
  let qty;
  let hingeSel;
  let extTop;
  let extBot;
  let matSearch;
  let matSuggest;
  let matChosen;
  let matChosenTitle;
  let matChosenMeta;
  let matClearBtn;
  let grainToggle;
  let grainToggleLabel;
  let grainWarn;
  let edgeSel;
  let addBtn;
  let grainBtn;
  let extraOverlayBtn;
  let overviewBtn;
  let overviewOverlay;
  let overviewCloseBtn;
  let overviewBackBtn;
  let overviewNextBtn;
  let overviewTabs;
  let overviewTabHint;
  let overviewContent;
  let overviewEmpty;
  let overviewSummary;
  let overviewPriceEl;
  let extraOverlay;
  let extraCloseBtn;
  let extraDoneBtn;
  let extraCountPill;
  let grainOverlay;
  let grainCloseBtn;
  let grainCancelBtn;
  let grainApplyBtn;
  let grainNewGroupBtn;
  let grainEligible;
  let grainEligibleCount;
  let grainWidthSel;
  let grainGroups;
  let grainPreview;
  let grainMsg;
  let grainAlertOverlay;
  let grainAlertBody;
  let grainAlertOkBtn;
  let cartEl;
  let cartHelp;
  let panelDock;
  let panelDockLauncher;
  let panelDockCount;
  let panelDockDrawer;
  let panelDockList;
  let panelDockEmpty;
  let panelDockClose;
  let panelDockSub;
  let panelDockTabs;
  let panelDockHint;
  let extraName;
  let extraW;
  let extraH;
  let extraQty;
  let extraMat;
  let extraEdge;
  let extraEdgeTop;
  let extraEdgeBottom;
  let extraEdgeLeft;
  let extraEdgeRight;
  let extraPreviewCanvas;
  let addExtraBtn;
  let extraList;
  let extraHelp;
  let extraEditHint;
  let cv;

  function setOverlayVisible(id, visible) {
    const owner = foundation.current;
    if (!owner || typeof owner.setOverlayVisible !== "function")
      throw new Error("Overlay router owner unavailable");
    return owner.setOverlayVisible(id, visible);
  }

  function setGrainMsg(msg = "") {
    {
      ensureGrainEls();
      const txt = String(msg || "").trim();
      if (typeof grainMsg === "undefined" || !grainMsg)
        grainMsg = document.getElementById("grainMsg");
      if (grainMsg) {
        grainMsg.textContent = txt;
        grainMsg.classList.toggle("hasText", !!txt);
      }
      if (!grainAlertOverlay) grainAlertOverlay = document.getElementById("grainAlertOverlay");
      if (!grainAlertBody) grainAlertBody = document.getElementById("grainAlertBody");
      if (txt) {
        if (grainAlertBody) grainAlertBody.textContent = txt;
        if (grainAlertOverlay) grainAlertOverlay.style.display = "flex";
        try {
          grainAlertOkBtn && grainAlertOkBtn.focus({ preventScroll: true });
        } catch (_) {
          ToolAErrors.recover("tool.a.runtime.modules.panel.elements.js.2", _, [
            "NotSupportedError",
            "InvalidStateError",
          ]);
        }
      } else {
        if (grainAlertOverlay) grainAlertOverlay.style.display = "none";
        if (grainAlertBody) grainAlertBody.textContent = "";
      }
    }
  }

  function ensureOverlayEls() {
    // Extra overlay
    if (!extraOverlay) extraOverlay = document.getElementById("extraOverlay");
    if (!extraCloseBtn) extraCloseBtn = document.getElementById("extraCloseBtn");
    if (!extraDoneBtn) extraDoneBtn = document.getElementById("extraDoneBtn");
    if (!extraCountPill) extraCountPill = document.getElementById("extraCountPill");

    // Grain overlay
    if (!grainOverlay) grainOverlay = document.getElementById("grainOverlay");
    if (!grainCloseBtn) grainCloseBtn = document.getElementById("grainCloseBtn");
    if (!grainCancelBtn) grainCancelBtn = document.getElementById("grainCancelBtn");
    if (!grainApplyBtn) grainApplyBtn = document.getElementById("grainApplyBtn");
    if (!grainNewGroupBtn) grainNewGroupBtn = document.getElementById("grainNewGroupBtn");
    if (!grainEligible) grainEligible = document.getElementById("grainEligible");
    if (!grainEligibleCount) grainEligibleCount = document.getElementById("grainEligibleCount");
    if (!grainWidthSel) grainWidthSel = document.getElementById("grainWidthSel");
    if (!grainGroups) grainGroups = document.getElementById("grainGroups");
    if (!grainPreview) grainPreview = document.getElementById("grainPreview");
    if (!grainAlertOverlay) grainAlertOverlay = document.getElementById("grainAlertOverlay");
    if (!grainAlertBody) grainAlertBody = document.getElementById("grainAlertBody");
    if (!grainAlertOkBtn) grainAlertOkBtn = document.getElementById("grainAlertOkBtn");
    if (typeof grainIncludeExtraToggle === "undefined" || !grainIncludeExtraToggle)
      grainIncludeExtraToggle = document.getElementById("grainIncludeExtraToggle");
    if (!grainMsg) grainMsg = document.getElementById("grainMsg");
  }

  function mount() {
    overlay = document.getElementById("overlay");
    overlayRouterOwner = foundation.current;
    if (!overlayRouterOwner || typeof overlayRouterOwner.bindOverlayRouter !== "function")
      throw new Error("Overlay router owner unavailable");
    overlayRouterOwner.bindOverlayRouter();
    builtinCount = document.getElementById("builtinCount");
    typeSel = document.getElementById("typeSel");
    sizeSel = document.getElementById("sizeSel");
  }

  function mount2() {
    qty = document.getElementById("qty");
    hingeSel = document.getElementById("hingeSel");
    extTop = document.getElementById("extTop");
    extBot = document.getElementById("extBot");
    matSearch = document.getElementById("matSearch");
    matSuggest = document.getElementById("matSuggest");
    matChosen = document.getElementById("matChosen");
    matChosenTitle = document.getElementById("matChosenTitle");
    matChosenMeta = document.getElementById("matChosenMeta");
    matClearBtn = document.getElementById("matClearBtn");
    grainToggle = document.getElementById("grainToggle");
    grainToggleLabel = document.getElementById("grainToggleLabel");
    grainWarn = document.getElementById("grainWarn");
    edgeSel = document.getElementById("edgeSel");
    addBtn = document.getElementById("addBtn");
    grainBtn = document.getElementById("grainBtn");
    extraOverlayBtn = document.getElementById("extraOverlayBtn");
    overviewBtn = document.getElementById("overviewBtn");
  }

  function mount3() {
    overviewOverlay = null;
    overviewCloseBtn = null;
    overviewBackBtn = null;
    overviewNextBtn = null;
    overviewTabs = null;
    overviewTabHint = null;
    overviewContent = null;
    overviewEmpty = null;
    overviewSummary = null;
    overviewPriceEl = null;
    extraOverlay = null;
    extraCloseBtn = null;
    extraDoneBtn = null;
    extraCountPill = null;
    grainOverlay = null;
    grainCloseBtn = null;
    grainCancelBtn = null;
    grainApplyBtn = null;
    grainNewGroupBtn = null;
    grainEligible = null;
    grainEligibleCount = null;
    grainWidthSel = null;
    grainGroups = null;
    grainPreview = null;
    grainMsg = null;
    grainAlertOverlay = null;
    grainAlertBody = null;
    grainAlertOkBtn = null;
    cartEl = document.getElementById("cart");
    cartHelp = document.getElementById("cartHelp");
    panelDock = document.getElementById("panelDock");
    panelDockLauncher = document.getElementById("panelDockLauncher");
    panelDockCount = document.getElementById("panelDockCount");
    panelDockDrawer = document.getElementById("panelDockDrawer");
    panelDockList = document.getElementById("panelDockList");
    panelDockEmpty = document.getElementById("panelDockEmpty");
    panelDockClose = document.getElementById("panelDockClose");
    panelDockSub = document.getElementById("panelDockSub");
    panelDockTabs = document.getElementById("panelDockTabs");
    panelDockHint = document.getElementById("panelDockHint");
    extraName = document.getElementById("extraName");
    extraW = document.getElementById("extraW");
    extraH = document.getElementById("extraH");
    extraQty = document.getElementById("extraQty");
    extraMat = document.getElementById("extraMat");
    extraEdge = document.getElementById("extraEdge");
    extraEdgeTop = document.getElementById("extraEdgeTop");
    extraEdgeBottom = document.getElementById("extraEdgeBottom");
    extraEdgeLeft = document.getElementById("extraEdgeLeft");
    extraEdgeRight = document.getElementById("extraEdgeRight");
    extraPreviewCanvas = document.getElementById("extraPreviewCanvas");
    addExtraBtn = document.getElementById("addExtraBtn");
    extraList = document.getElementById("extraList");
    extraHelp = document.getElementById("extraHelp");
    extraEditHint = document.getElementById("extraEditHint");
    cv = document.getElementById("cv");
  }

  function ensureGrainEls() {
    // Overlay elements are defined after main script in HTML; fetch lazily to avoid null refs.
    if (typeof ensureOverlayEls === "function") ensureOverlayEls();
    if (typeof grainMsg === "undefined" || !grainMsg)
      grainMsg = document.getElementById("grainMsg");
    if (typeof grainWidthSel === "undefined" || !grainWidthSel)
      grainWidthSel = document.getElementById("grainWidthSel");
    if (typeof grainMatSel === "undefined" || !grainMatSel)
      grainMatSel = document.getElementById("grainMatSel");
    if (typeof grainGroupsWrap === "undefined" || !grainGroupsWrap)
      grainGroupsWrap = document.getElementById("grainGroupsWrap");
    if (typeof grainEligibleWrap === "undefined" || !grainEligibleWrap)
      grainEligibleWrap = document.getElementById("grainEligibleWrap");
    if (typeof grainOverlay === "undefined" || !grainOverlay)
      grainOverlay = document.getElementById("grainOverlay");
    // Also ensure the core grain overlay nodes are available (these were previously const-null)
    if (!grainEligible) grainEligible = document.getElementById("grainEligible");
    if (!grainEligibleCount) grainEligibleCount = document.getElementById("grainEligibleCount");
    if (!grainGroups) grainGroups = document.getElementById("grainGroups");
    if (!grainPreview) grainPreview = document.getElementById("grainPreview");
    if (typeof grainIncludeExtraToggle === "undefined" || !grainIncludeExtraToggle)
      grainIncludeExtraToggle = document.getElementById("grainIncludeExtraToggle");
  }

  return Object.freeze({
    get panelDockDrawer() {
      return panelDockDrawer;
    },
    get panelDock() {
      return panelDock;
    },
    get panelDockLauncher() {
      return panelDockLauncher;
    },
    get typeSel() {
      return typeSel;
    },
    get sizeSel() {
      return sizeSel;
    },
    get hingeSel() {
      return hingeSel;
    },
    get addBtn() {
      return addBtn;
    },
    setOverlayVisible,
    get qty() {
      return qty;
    },
    get extTop() {
      return extTop;
    },
    get extBot() {
      return extBot;
    },
    get matSearch() {
      return matSearch;
    },
    get matSuggest() {
      return matSuggest;
    },
    get matChosen() {
      return matChosen;
    },
    get matChosenTitle() {
      return matChosenTitle;
    },
    get matChosenMeta() {
      return matChosenMeta;
    },
    get matClearBtn() {
      return matClearBtn;
    },
    get grainToggle() {
      return grainToggle;
    },
    get grainToggleLabel() {
      return grainToggleLabel;
    },
    get grainWarn() {
      return grainWarn;
    },
    get edgeSel() {
      return edgeSel;
    },
    get grainBtn() {
      return grainBtn;
    },
    get extraOverlayBtn() {
      return extraOverlayBtn;
    },
    get overviewBtn() {
      return overviewBtn;
    },
    get overviewOverlay() {
      return overviewOverlay;
    },
    set overviewOverlay(value) {
      overviewOverlay = value;
    },
    get overviewCloseBtn() {
      return overviewCloseBtn;
    },
    set overviewCloseBtn(value) {
      overviewCloseBtn = value;
    },
    get overviewBackBtn() {
      return overviewBackBtn;
    },
    set overviewBackBtn(value) {
      overviewBackBtn = value;
    },
    get overviewNextBtn() {
      return overviewNextBtn;
    },
    set overviewNextBtn(value) {
      overviewNextBtn = value;
    },
    get overviewTabs() {
      return overviewTabs;
    },
    set overviewTabs(value) {
      overviewTabs = value;
    },
    get overviewTabHint() {
      return overviewTabHint;
    },
    set overviewTabHint(value) {
      overviewTabHint = value;
    },
    get overviewContent() {
      return overviewContent;
    },
    set overviewContent(value) {
      overviewContent = value;
    },
    get overviewEmpty() {
      return overviewEmpty;
    },
    set overviewEmpty(value) {
      overviewEmpty = value;
    },
    get overviewSummary() {
      return overviewSummary;
    },
    set overviewSummary(value) {
      overviewSummary = value;
    },
    get extraOverlay() {
      return extraOverlay;
    },
    get extraCloseBtn() {
      return extraCloseBtn;
    },
    get extraDoneBtn() {
      return extraDoneBtn;
    },
    get extraCountPill() {
      return extraCountPill;
    },
    get grainOverlay() {
      return grainOverlay;
    },
    set grainOverlay(value) {
      grainOverlay = value;
    },
    get grainCloseBtn() {
      return grainCloseBtn;
    },
    get grainCancelBtn() {
      return grainCancelBtn;
    },
    get grainApplyBtn() {
      return grainApplyBtn;
    },
    get grainNewGroupBtn() {
      return grainNewGroupBtn;
    },
    get grainEligible() {
      return grainEligible;
    },
    set grainEligible(value) {
      grainEligible = value;
    },
    get grainEligibleCount() {
      return grainEligibleCount;
    },
    set grainEligibleCount(value) {
      grainEligibleCount = value;
    },
    get grainWidthSel() {
      return grainWidthSel;
    },
    set grainWidthSel(value) {
      grainWidthSel = value;
    },
    get grainGroups() {
      return grainGroups;
    },
    set grainGroups(value) {
      grainGroups = value;
    },
    get grainPreview() {
      return grainPreview;
    },
    set grainPreview(value) {
      grainPreview = value;
    },
    get grainMsg() {
      return grainMsg;
    },
    set grainMsg(value) {
      grainMsg = value;
    },
    get grainAlertOverlay() {
      return grainAlertOverlay;
    },
    get grainAlertOkBtn() {
      return grainAlertOkBtn;
    },
    setGrainMsg,
    ensureOverlayEls,
    get cartEl() {
      return cartEl;
    },
    get cartHelp() {
      return cartHelp;
    },
    get panelDockCount() {
      return panelDockCount;
    },
    get panelDockList() {
      return panelDockList;
    },
    get panelDockEmpty() {
      return panelDockEmpty;
    },
    get panelDockClose() {
      return panelDockClose;
    },
    get panelDockSub() {
      return panelDockSub;
    },
    get panelDockTabs() {
      return panelDockTabs;
    },
    get panelDockHint() {
      return panelDockHint;
    },
    get extraName() {
      return extraName;
    },
    get extraW() {
      return extraW;
    },
    get extraH() {
      return extraH;
    },
    get extraQty() {
      return extraQty;
    },
    get extraMat() {
      return extraMat;
    },
    get extraEdge() {
      return extraEdge;
    },
    get extraEdgeTop() {
      return extraEdgeTop;
    },
    get extraEdgeBottom() {
      return extraEdgeBottom;
    },
    get extraEdgeLeft() {
      return extraEdgeLeft;
    },
    get extraEdgeRight() {
      return extraEdgeRight;
    },
    get extraPreviewCanvas() {
      return extraPreviewCanvas;
    },
    get addExtraBtn() {
      return addExtraBtn;
    },
    get extraList() {
      return extraList;
    },
    get extraHelp() {
      return extraHelp;
    },
    get extraEditHint() {
      return extraEditHint;
    },
    get cv() {
      return cv;
    },
    ensureGrainEls,
    get grainIncludeExtraToggle() {
      return grainIncludeExtraToggle;
    },
    set grainIncludeExtraToggle(value) {
      grainIncludeExtraToggle = value;
    },
    get grainMatSel() {
      return grainMatSel;
    },
    set grainMatSel(value) {
      grainMatSel = value;
    },
    get grainGroupsWrap() {
      return grainGroupsWrap;
    },
    set grainGroupsWrap(value) {
      grainGroupsWrap = value;
    },
    get grainEligibleWrap() {
      return grainEligibleWrap;
    },
    set grainEligibleWrap(value) {
      grainEligibleWrap = value;
    },
    mount,
    mount2,
    mount3,
  });
}
