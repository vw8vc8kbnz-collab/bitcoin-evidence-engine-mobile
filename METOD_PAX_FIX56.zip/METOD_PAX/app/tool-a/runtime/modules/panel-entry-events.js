/** panel-entry-events: one runtime owner with explicit, immutable dependency ports. */
export function createPanelEntryEvents({ panelForm, wizardNavigation } = {}) {
  function connect2() {
    if (panelForm.addInline && !panelForm.addInline.__bound) {
      panelForm.addInline.addEventListener("click", () => {
        wizardNavigation.lockRightScroll(panelForm.addInline);
        panelForm.legacyAddBtn?.click();
      });
      document.addEventListener("tool-a:standard-panel-busy", (event) => {
        const busy = event.detail?.busy === true;
        panelForm.addInline.setAttribute("aria-busy", String(busy));
        if (busy) panelForm.addInline.disabled = true;
        else wizardNavigation.renderFooterForStep(window.__metod_uiStep || "panels");
      });
      document.addEventListener("tool-a:standard-panel-submitted", (event) => {
        if (event.detail?.ok !== true) return;
        panelForm.resetPanelEntryFields();
        wizardNavigation.renderFooterForStep(window.__metod_uiStep || "panels");
        try {
          panelForm.addInline.blur({ preventScroll: true });
        } catch (_) {
          ToolAErrors.recover("tool.a.runtime.modules.panel.entry.events.js.1", _, [
            "NotSupportedError",
            "InvalidStateError",
          ]);
        }
        wizardNavigation.stabilizeRightScroll(14, panelForm.addInline);
      });
      panelForm.addInline.__bound = true;
    }
    panelForm.ensureCustomLabelHook();
  }

  return Object.freeze({
    connect2,
  });
}
