/** grain-data: one runtime owner with explicit, immutable dependency ports. */
export function createGrainData({ applicationState, foundation, grainAssignments } = {}) {
  function grainEnabledForKey(mk) {
    const owner = foundation.current;
    if (!owner || typeof owner.isGrainEnabledForMaterial !== "function") {
      throw new Error("R9 grain material reader is niet geladen. Herlaad Tool A.");
    }
    return owner.isGrainEnabledForMaterial(mk);
  }

  function grainOverlaySelectedMaterialKey() {
    const owner = foundation.current;
    if (!owner || typeof owner.getGrainMaterialKey !== "function") {
      throw new Error("R9 grain selection reader is niet geladen. Herlaad Tool A.");
    }
    return owner.getGrainMaterialKey();
  }

  function isGrainCapable(it) {
    const owner = foundation.current;
    if (!owner || typeof owner.isGrainCapableItem !== "function") {
      throw new Error("R9 grain capability reader is niet geladen. Herlaad Tool A.");
    }
    return owner.isGrainCapableItem(it);
  }

  function grainExtrasEnabled() {
    return !!applicationState.current?.grain?.includeExtraPanels;
    return false;
  }

  function makeGrainRef(kind, idx, rep) {
    return kind === "extra" ? `extra:${idx}:${rep}` : `cart:${idx}`;
  }

  function parseGrainRef(ref) {
    const owner = foundation.current;
    if (!owner || typeof owner.parseGrainReference !== "function") {
      throw new Error("R9 grain reference reader is niet geladen. Herlaad Tool A.");
    }
    return owner.parseGrainReference(ref);
  }

  function getGrainEntryByRef(ref) {
    const pr = parseGrainRef(ref);
    if (!pr) return null;
    if (pr.kind === "cart") {
      const it = (applicationState.current.cart || [])[pr.idx];
      if (!it) return null;
      return {
        ref: makeGrainRef("cart", pr.idx, null),
        kind: "cart",
        idx: pr.idx,
        rep: null,
        raw: it,
        label: String(it.label || it.baseLabel || it.templateId || "Paneel"),
        widthCm: Number(it.cmW ?? Math.round(Number(it.realW || 0))),
        heightCm: Number(it.cmH ?? Math.round(Number(it.realH || 0))),
        widthMm: Number(it.realW ?? it.widthMm ?? it.w ?? 0),
        baseHeightMm: Number(it.realH ?? it.lengthMm ?? it.h ?? 0),
        extTop: Math.max(0, Number(it.extTop || 0)),
        extBot: Math.max(0, Number(it.extBot || 0)),
        materialKey: String(it.materialKey || it.materialCode || it.articleNumber || "").trim(),
        grainGroupId: it.grainGroupId || null,
        grainOrder: it.grainOrder || null,
      };
    }
    const p = (applicationState.current.extraPanels || [])[pr.idx];
    if (!p) return null;
    const assigns =
      typeof grainAssignments.ensureExtraAssignments === "function"
        ? grainAssignments.ensureExtraAssignments(p)
        : (() => {
            const qty = Math.max(1, Number(p.qty || 1));
            if (!Array.isArray(p.grainAssignments)) p.grainAssignments = [];
            while (p.grainAssignments.length < qty)
              p.grainAssignments.push({ grainGroupId: null, grainOrder: null });
            if (p.grainAssignments.length > qty)
              p.grainAssignments = p.grainAssignments.slice(0, qty);
            return p.grainAssignments;
          })();
    const ass = assigns[pr.rep] || { grainGroupId: null, grainOrder: null };
    return {
      ref: makeGrainRef("extra", pr.idx, pr.rep),
      kind: "extra",
      idx: pr.idx,
      rep: pr.rep,
      raw: p,
      label: String(p.name && String(p.name).trim() ? p.name : `Overig paneel ${p.w}×${p.h}`),
      widthCm: Math.round(Number(p.w || 0) / 10),
      heightCm: Math.round(Number(p.h || 0) / 10),
      widthMm: Number(p.w || 0),
      baseHeightMm: Number(p.h || 0),
      extTop: 0,
      extBot: 0,
      materialKey: String(p.materialKey || p.materialCode || p.articleNumber || "").trim(),
      grainGroupId: ass.grainGroupId || null,
      grainOrder: ass.grainOrder || null,
    };
  }

  function getGrainEligibleEntries() {
    const out = [];

    (applicationState.current.cart || []).forEach((it, idx) => {
      const e = getGrainEntryByRef(makeGrainRef("cart", idx, null));
      if (e && isGrainCapable(e.raw)) out.push(e);
    });
    if (grainExtrasEnabled()) {
      (applicationState.current.extraPanels || []).forEach((p, idx) => {
        const assigns =
          typeof grainAssignments.ensureExtraAssignments === "function"
            ? grainAssignments.ensureExtraAssignments(p)
            : (() => {
                const qty = Math.max(1, Number(p.qty || 1));
                if (!Array.isArray(p.grainAssignments)) p.grainAssignments = [];
                while (p.grainAssignments.length < qty)
                  p.grainAssignments.push({
                    grainGroupId: null,
                    grainOrder: null,
                  });
                if (p.grainAssignments.length > qty)
                  p.grainAssignments = p.grainAssignments.slice(0, qty);
                return p.grainAssignments;
              })();
        for (let rep = 0; rep < assigns.length; rep++) {
          const e = getGrainEntryByRef(makeGrainRef("extra", idx, rep));
          if (e && isGrainCapable(e.raw)) out.push(e);
        }
      });
    }

    return out;
  }

  function clearAllGrainAssignments() {
    (applicationState.current.cart || []).forEach((it) => {
      if (it) {
        it.grainGroupId = null;
        it.grainOrder = null;
      }
    });
    (applicationState.current.extraPanels || []).forEach((p) => {
      grainAssignments.ensureExtraAssignments(p).forEach((a) => {
        a.grainGroupId = null;
        a.grainOrder = null;
      });
    });
    if (applicationState.current.grain) {
      applicationState.current.grain.groups = [];
      applicationState.current.grain.selectedGroupId = null;
    }
  }

  function grainDoorDirectionLabel(it) {
    {
      if (!it || typeof it !== "object") return "";
      const kind = String(it.kind || it.panelType || it.type || "").toLowerCase();
      const label = String(it.label || it.baseLabel || "").toLowerCase();
      const hinge = String(
        it.hinge || it.hingeSide || it.swing || it.draairichting || "",
      ).toLowerCase();
      const isDoor =
        kind.includes("door") ||
        kind.includes("deur") ||
        label.includes("deur") ||
        label.includes("door");
      if (!isDoor) return "";
      if (hinge.includes("left") || hinge.includes("links")) return " · Draairichting: L";
      if (hinge.includes("right") || hinge.includes("rechts")) return " · Draairichting: R";
      return "";
    }
    return "";
  }

  function grainExtLabel(it) {
    const top = Number(it.extTop || 0);
    const bot = Number(it.extBot || 0);
    if (top <= 0 && bot <= 0) return "";
    return ` · verlenging: +${top} boven / +${bot} onder`;
  }

  function _grainDisplayGroupKey(e) {
    try {
      const raw = e?.raw || {};
      const customName = String(raw?.customName || raw?.customLabel || raw?.name || "").trim();
      const effectiveName = customName || String(e?.label || "");
      return [
        String(e?.kind || ""),
        String(e?.materialKey || ""),
        effectiveName,
        String(e?.label || ""),
        String(Math.round(Number(e?.widthMm || 0) * 1000) / 1000),
        String(
          Math.round(Number((e?.baseHeightMm || 0) + (e?.extTop || 0) + (e?.extBot || 0)) * 1000) /
            1000,
        ),
        String(Number(e?.extTop || 0) || 0),
        String(Number(e?.extBot || 0) || 0),
        String(raw?.type || ""),
        String(raw?.hinge || ""),
        String(customName),
      ].join("||");
    } catch (_e) {
      return String(e?.ref || Math.random());
    }
  }

  function _groupGrainDisplayEntries(entries) {
    const map = new Map();
    const order = [];
    (entries || []).forEach((e) => {
      const key = _grainDisplayGroupKey(e);
      let g = map.get(key);
      if (!g) {
        g = { key, rep: e, items: [] };
        map.set(key, g);
        order.push(g);
      }
      g.items.push(e);
    });
    return order;
  }

  return Object.freeze({
    clearAllGrainAssignments,
    grainOverlaySelectedMaterialKey,
    getGrainEntryByRef,
    grainExtrasEnabled,
    grainEnabledForKey,
    getGrainEligibleEntries,
    _groupGrainDisplayEntries,
    grainDoorDirectionLabel,
    grainExtLabel,
    isGrainCapable,
    parseGrainRef,
  });
}
