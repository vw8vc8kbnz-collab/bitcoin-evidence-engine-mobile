/** panel-dock: one runtime owner with explicit, immutable dependency ports. */
export function createPanelDock({ applicationState, foundation, panelElements } = {}) {
  let hintTimer = null;

  function validatePanelFitsSheetMm(panelW, panelH, materialKey, rotationAllowed) {
    const w = Number(panelW);
    const h = Number(panelH);
    const owner = foundation.current;
    if (!owner || typeof owner.getUsableMaterialSheetDimensions !== "function") {
      throw new Error("PANEL_FIT_READER_UNAVAILABLE");
    }
    const {
      usableW,
      usableH,
      margin,
      width: sheetW,
      height: sheetH,
      mat,
    } = owner.getUsableMaterialSheetDimensions(materialKey, window.MATERIAL_CATALOG);
    // An unavailable check is distinct from a panel that fits. The submit
    // adapters report this failure before changing any panel or entry field.
    if (
      ![w, h, usableW, usableH, sheetW, sheetH].every(
        (value) => Number.isFinite(value) && value > 0,
      ) ||
      !Number.isFinite(margin) ||
      margin < 0 ||
      Math.abs(usableW - (sheetW - 2 * margin)) > 1e-6 ||
      Math.abs(usableH - (sheetH - 2 * margin)) > 1e-6
    ) {
      throw new Error("PANEL_FIT_DIMENSIONS_UNAVAILABLE");
    }

    const fitsNormal = w <= usableW + 1e-6 && h <= usableH + 1e-6;
    const fitsRot = rotationAllowed ? h <= usableW + 1e-6 && w <= usableH + 1e-6 : false;
    if (fitsNormal || fitsRot) return true;

    const matName = String(
      mat?.productName || mat?.decorName || mat?.name || materialKey || "",
    ).trim();
    alert(
      `Dit paneel past niet op de plaat.\n\n` +
        `Paneel: ${Math.round(w)}×${Math.round(h)} mm\n` +
        `Plaat: ${Math.round(sheetW)}×${Math.round(sheetH)} mm\n` +
        `Marge: ${margin} mm rondom → bruikbaar: ${Math.round(usableW)}×${Math.round(usableH)} mm\n` +
        `${matName ? `Materiaal: ${matName}\n` : ""}` +
        (rotationAllowed
          ? `\nTip: rotatie is toegestaan, maar ook gedraaid past dit paneel niet binnen de bruikbare plaatmaat.`
          : `\nNerf staat AAN, rotatie is niet toegestaan.`),
    );
    return false;
  }

  function _panelDisplayGroupKey(it) {
    try {
      const hinge =
        it &&
        (it.type === "deur" ||
          it.type === "pax_deur" ||
          it.supportsHinge ||
          it.kind === "Hoekkast")
          ? String(it.hinge || "")
          : "";
      const customName = String(it?.customName || it?.customLabel || "").trim();
      const effectiveName =
        customName || String(it?.label || it?.baseLabel || it?.templateId || "");
      return [
        String(it?.type || ""),
        String(it?.materialKey || it?.materialCode || it?.articleNumber || ""),
        String(it?.baseLabel || it?.label || it?.templateId || ""),
        effectiveName,
        String(Number(it?.cmW ?? Math.round(Number(it?.realW || 0))) || 0),
        String(Number(it?.cmH ?? Math.round(Number(it?.realH || 0))) || 0),
        String(Number(it?.extTop || 0) || 0),
        String(Number(it?.extBot || 0) || 0),
        hinge,
      ].join("||");
    } catch (_e) {
      return String(it?.id || Math.random());
    }
  }

  function _groupCartDisplayItems(items) {
    const map = new Map();
    const order = [];
    (items || []).forEach((it) => {
      const key = _panelDisplayGroupKey(it);
      let g = map.get(key);
      if (!g) {
        g = { key, rep: it, items: [] };
        map.set(key, g);
        order.push(g);
      }
      g.items.push(it);
    });
    return order;
  }

  function pulsePanelDock(message) {
    if (panelElements.panelDockLauncher) {
      panelElements.panelDockLauncher.classList.remove("is-pulse");
      void panelElements.panelDockLauncher.offsetWidth;
      panelElements.panelDockLauncher.classList.add("is-pulse");
      setTimeout(() => {
        panelElements.panelDockLauncher.classList.remove("is-pulse");
      }, 720);
    }
    if (panelElements.panelDockCount) {
      panelElements.panelDockCount.classList.remove("is-bump");
      void panelElements.panelDockCount.offsetWidth;
      panelElements.panelDockCount.classList.add("is-bump");
      setTimeout(() => {
        panelElements.panelDockCount.classList.remove("is-bump");
      }, 520);
    }
    if (panelElements.panelDockHint) {
      panelElements.panelDockHint.textContent = message || "Toegevoegd aan Mijn panelen.";
      panelElements.panelDockHint.style.display = "block";
      clearTimeout(hintTimer);
      hintTimer = setTimeout(() => {
        panelElements.panelDockHint.style.display = "none";
      }, 1800);
    }
  }

  function mount() {
    window.isPanelDockOpen = function isPanelDockOpen() {
      try {
        if (!panelElements.panelDockDrawer) return false;
        if (panelElements.panelDockDrawer.hidden) return false;
        if (panelElements.panelDockDrawer.getAttribute("hidden") != null) return false;
        const display =
          (panelElements.panelDockDrawer.style &&
            panelElements.panelDockDrawer.style.display) ||
          "";
        if (display && display.toLowerCase() === "none") return false;
        return true;
      } catch (_) {
        return false;
      }
    };
    window.setPanelDockOpen = setPanelDockOpen;

    if (
      panelElements.panelDockLauncher &&
      !panelElements.panelDockLauncher.__panelDockFix589
    ) {
      panelElements.panelDockLauncher.__panelDockFix589 = true;
      panelElements.panelDockLauncher.style.pointerEvents = "auto";
      const __toggleDock = function (ev) {
        if (ev) {
          ev.preventDefault();
          ev.stopPropagation();
        }
        {
          const isOpen = !!(window.isPanelDockOpen && window.isPanelDockOpen());
          window.setPanelDockOpen && window.setPanelDockOpen(!isOpen);
        }
      };
      panelElements.panelDockLauncher.addEventListener("click", __toggleDock, true);
      panelElements.panelDockLauncher.addEventListener(
        "keydown",
        function (ev) {
          {
            const k = ev && (ev.key || ev.code || "");
            if (k === "Enter" || k === " " || k === "Space" || k === "Spacebar") {
              __toggleDock(ev);
            }
          }
        },
        true,
      );
    }
    if (panelElements.panelDockClose && !panelElements.panelDockClose.__panelDockFix586) {
      panelElements.panelDockClose.__panelDockFix586 = true;
      panelElements.panelDockClose.style.pointerEvents = "auto";
      const __closeDock = function (ev) {
        if (ev) {
          ev.preventDefault();
          ev.stopPropagation();
        }
        window.setPanelDockOpen && window.setPanelDockOpen(false);
      };
      panelElements.panelDockClose.addEventListener("click", __closeDock, true);
      panelElements.panelDockClose.addEventListener(
        "keydown",
        function (ev) {
          {
            const k = ev && (ev.key || ev.code || "");
            if (k === "Enter" || k === " " || k === "Space" || k === "Spacebar") {
              __closeDock(ev);
            }
          }
        },
        true,
      );
    }

    {
      const __initialDockTotal =
        (Array.isArray(applicationState.current?.cart)
          ? applicationState.current.cart.length
          : 0) +
        (Array.isArray(applicationState.current?.extraPanels)
          ? applicationState.current.extraPanels.reduce(
              (a, p) => a + Math.max(1, Number(p?.qty) || 1),
              0,
            )
          : 0);
      if (!__initialDockTotal) {
        if (panelElements.panelDockDrawer) {
          panelElements.panelDockDrawer.hidden = true;
          panelElements.panelDockDrawer.setAttribute("hidden", "hidden");
        }
        if (panelElements.panelDockLauncher) {
          panelElements.panelDockLauncher.setAttribute("aria-expanded", "false");
        }
        if (panelElements.panelDock) {
          panelElements.panelDock.classList.remove("is-open");
        }
        window.__panelDockWasOpenBeforeRoute = false;
      }
    }
  }

  function setPanelDockOpen(open) {
    {
      if (!panelElements.panelDockDrawer || !panelElements.panelDockLauncher) return;
      const shouldOpen = !!open;
      if (shouldOpen) {
        panelElements.panelDockDrawer.hidden = false;
        panelElements.panelDockDrawer.removeAttribute("hidden");
        panelElements.panelDockDrawer.style.display = "flex";
      } else {
        panelElements.panelDockDrawer.hidden = true;
        panelElements.panelDockDrawer.setAttribute("hidden", "hidden");
        panelElements.panelDockDrawer.style.removeProperty("display");
      }
      panelElements.panelDockLauncher.setAttribute("aria-expanded", String(shouldOpen));
      if (panelElements.panelDock)
        panelElements.panelDock.classList.toggle("is-open", shouldOpen);
    }
  }

  return Object.freeze({
    setPanelDockOpen,
    validatePanelFitsSheetMm,
    pulsePanelDock,
    _panelDisplayGroupKey,
    _groupCartDisplayItems,
    mount,
  });
}
