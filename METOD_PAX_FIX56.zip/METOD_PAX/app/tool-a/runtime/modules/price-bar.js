/** price-bar: one runtime owner with explicit, immutable dependency ports. */
export function createPriceBar({
  applicationState,
  calculationView,
  panelsProjection,
  progressView,
} = {}) {
  function updatePriceBar(opts = {}) {
    const hasBusyDirective = Object.prototype.hasOwnProperty.call(opts || {}, "busy");
    // Release the overlay before consulting any derived view or touching price
    // DOM. A renderer failure can no longer strand the optimizer lifecycle.
    if (hasBusyDirective && opts.busy === false) {
      progressView.finishOptimizerProgressLifecycle();
    }
    const panelsView = panelsProjection.r9PanelsView();
    const panelCount =
      panelsView && Number.isSafeInteger(panelsView.totalPanelLineCount)
        ? panelsView.totalPanelLineCount
        : (applicationState.current?.cart?.length || 0) +
          (applicationState.current?.extraPanels?.length || 0);
    if (calculationView.priceBarMetaEl) {
      const rest =
        applicationState.current?.checkout?.restCarry === true
          ? "JA"
          : applicationState.current?.checkout?.restCarry === false
            ? "NEE"
            : "—";
      calculationView.priceBarMetaEl.textContent = `${panelCount} panelen • Restmateriaal: ${rest}`;
    }

    const hasPanels =
      panelsView && typeof panelsView.hasPanels === "boolean"
        ? panelsView.hasPanels
        : panelCount > 0;
    // Busy is an explicit optimizer lifecycle transition. Ordinary panel/material
    // renders call updatePriceBar() without options and must never hide or unlock
    // the branded progress layer while a job is still running.
    const wasBusy = !!window.__metodOptimizerBusy;
    const isBusy = hasBusyDirective ? opts.busy === true : wasBusy;
    if (hasBusyDirective && isBusy) {
      window.__metodOptimizerBusy = true;
      window.__metodBusySince = Date.now();
      clearTimeout(window.__metodBusyWatchdog);
      window.__metodBusyWatchdog = null;
    } else if (hasBusyDirective) {
      progressView.finishOptimizerProgressLifecycle();
    }
    if (calculationView.priceBarBtnCalc)
      calculationView.priceBarBtnCalc.disabled = !hasPanels || isBusy;
    if (calculationView.priceBarBtnOverview)
      calculationView.priceBarBtnOverview.disabled = !hasPanels;

    if (isBusy) {
      if (hasBusyDirective) {
        const rawPct = opts.progressPct;
        const pct =
          rawPct != null &&
          typeof rawPct !== "boolean" &&
          !(typeof rawPct === "string" && !rawPct.trim()) &&
          Number.isFinite(Number(rawPct))
            ? Math.max(0, Math.min(100, Math.round(Number(rawPct))))
            : null;
        const label = String(opts.progressLabel || "").trim();
        if (calculationView.priceBarTotalEl)
          calculationView.priceBarTotalEl.textContent =
            pct != null ? `Optimaliseren… ${pct}%` : "Bezig met optimaliseren…";
        if (calculationView.priceBarSubEl)
          calculationView.priceBarSubEl.textContent =
            label || "Totaalprijs incl. btw (wordt berekend)";
        progressView.updateMetodProgressBadge({
          busy: true,
          progressPct: pct,
          progressLabel: label,
        });
      }
      return;
    }
    if (opts.total != null) {
      const t = Number(opts.total);
      if (Number.isFinite(t)) applicationState.current.lastTotalInclBtw = t;
      if (calculationView.priceBarTotalEl)
        calculationView.priceBarTotalEl.textContent = calculationView.moneyEUR(opts.total);
      if (calculationView.priceBarSubEl)
        calculationView.priceBarSubEl.textContent = "Totaalprijs incl. btw";

      return;
    }

    // If we have a stored total from a previous run, keep showing it
    const stored = Number(applicationState.current.lastTotalInclBtw);
    const hasStored = Number.isFinite(stored) && stored > 0;
    if (hasStored) {
      if (calculationView.priceBarTotalEl)
        calculationView.priceBarTotalEl.textContent = calculationView.moneyEUR(stored);
      if (calculationView.priceBarSubEl)
        calculationView.priceBarSubEl.textContent = "Totaalprijs incl. btw";

      return;
    }
    if (calculationView.priceBarTotalEl)
      calculationView.priceBarTotalEl.textContent = hasPanels
        ? "Nog niet berekend"
        : "Voeg panelen toe";
    if (calculationView.priceBarSubEl)
      calculationView.priceBarSubEl.textContent = "Totaalprijs incl. btw";
  }

  function initialize() {
    if (calculationView.priceBarBtnCalc) {
      calculationView.priceBarBtnCalc.addEventListener("click", () => {
        // trigger same flow
        calculationView.saveQuoteBtn?.click();
      });
    }
    if (calculationView.priceBarBtnOverview) {
      calculationView.priceBarBtnOverview.addEventListener("click", () => {
        document.getElementById("overviewBtn")?.click();
      });
    }
    updatePriceBar();
  }

  return Object.freeze({
    updatePriceBar,
    initialize,
  });
}
