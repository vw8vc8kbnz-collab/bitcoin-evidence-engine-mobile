/** template-inventory: one runtime owner with explicit, immutable dependency ports. */
export function createTemplateInventory({ applicationState, selectionState, templateParser } = {}) {
  function rebuildCatalogFromTemplates(files) {
    // Build catalog as a UNION of:
    // 1) filenames from embedded manifest (so newly uploaded DXFs appear immediately)
    // 2) parsed templates in state.templates (these override filename-derived metadata)
    const buckets = { deur: [], lade: [], pax_deur: [], special: [] };

    /** @type {Record<string, any>} */
    const byId = {};

    // 1) Seed with manifest filenames (always).
    // Also build a set of "allowed" templateIds from the current manifest.
    const manifestIds = new Set();
    if (Array.isArray(files) && files.length > 0) {
      for (let i = 0; i < files.length; i++) {
        const rawName = String(files[i] || "");
        if (!rawName) continue;
        const templateId = templateParser.makeTemplateId(rawName);
        manifestIds.add(templateId);
        try {
          const meta = templateParser.parseMetaFromFilename(rawName);
          const baseName = rawName.replace(/\.dxf$/i, "").trim();
          const item = {
            templateId,
            cmW: meta && meta.cmW != null ? meta.cmW : 0,
            cmH: meta && meta.cmH != null ? meta.cmH : 0,
            label: baseName || rawName,
            kind:
              meta && meta.type === "lade"
                ? "Lade"
                : meta && (meta.type === "deur" || meta.type === "pax_deur")
                  ? "Deur"
                  : "Speciaal",
            sourceName: baseName,
            fileName: rawName,
            type: meta && meta.type ? meta.type : "special",
            folderLabel: meta && meta.folderLabel ? meta.folderLabel : "",
          };
          byId[templateId] = item;

          if (!applicationState.current.embedIndex) applicationState.current.embedIndex = {};
          applicationState.current.embedIndex[templateId] = rawName;
        } catch (e) {
          // If parsing fails, still list the file as special so it is selectable.
          byId[templateId] = {
            templateId,
            cmW: 0,
            cmH: 0,
            label: rawName.replace(/\.dxf$/i, "").trim() || rawName,
            kind: "Speciaal",
            sourceName: rawName.replace(/\.dxf$/i, "").trim(),
            fileName: rawName,
            type: "special",
            folderLabel: "",
          };
          if (!applicationState.current.embedIndex) applicationState.current.embedIndex = {};
          applicationState.current.embedIndex[templateId] = rawName;
        }
      }
    }

    // If a DXF was removed from the embedded folder/manifest, it must disappear from Tool A immediately.
    // Previously parsed templates can linger in state.templates; prune anything that's no longer in the manifest.
    if (manifestIds.size > 0) {
      for (const [tid] of applicationState.current.templates.entries()) {
        if (!manifestIds.has(tid)) {
          applicationState.current.templates.delete(tid);
          if (applicationState.current.embedIndex) delete applicationState.current.embedIndex[tid];
          // If the user currently has this deleted template selected, clear selection.
          if (
            applicationState.current.selection &&
            applicationState.current.selection.templateId === tid
          ) {
            selectionState.update({ templateId: "" });
          }
        }
      }
    }

    // 2) Overlay with parsed templates (more accurate metadata + kind).
    // Only overlay templates that still exist in the current manifest.

    for (const t of applicationState.current.templates.values()) {
      const rawName = (t.sourceName || t.fileName || t.label || "").trim();
      const baseName = rawName.replace(/\.dxf$/i, "").trim();
      const templateId = t.id;
      if (manifestIds.size > 0 && !manifestIds.has(templateId)) continue;

      // Ensure embedIndex has the original filename if available

      if (rawName) {
        if (!applicationState.current.embedIndex) applicationState.current.embedIndex = {};
        applicationState.current.embedIndex[templateId] = rawName;
      }

      const item = {
        templateId,
        cmW: t.cmW ?? 0,
        cmH: t.cmH ?? 0,
        label: baseName || rawName || (byId[templateId]?.label ?? templateId),
        kind:
          t.type === "lade"
            ? "Ladefront"
            : t.type === "pax_deur"
              ? "Deur PAX"
              : t.type === "deur"
                ? "Deur"
                : t.kind || "Special",
        sourceName: baseName || (byId[templateId]?.sourceName ?? ""),
        fileName: rawName || (byId[templateId]?.fileName ?? ""),
        type: t.type || byId[templateId]?.type || "special",
        folderLabel: t.folderLabel || byId[templateId]?.folderLabel || "",
      };
      byId[templateId] = { ...(byId[templateId] || {}), ...item };
    }

    // 3) Bucketize
    for (const id in byId) {
      const it = byId[id];
      const t = it.type;
      if (!Array.isArray(buckets[t])) buckets[t] = [];
      buckets[t].push(it);
    }

    // 4) Deterministic sort
    const sortWH = function (a, b) {
      return a.cmW - b.cmW || a.cmH - b.cmH || String(a.label).localeCompare(String(b.label));
    };
    Object.keys(buckets).forEach((key) => {
      buckets[key].sort(sortWH);
    });

    applicationState.current.catalog = buckets;
  }

  return Object.freeze({
    rebuildCatalogFromTemplates,
  });
}
