/** job-recovery: one runtime owner with explicit, immutable dependency ports. */
export function createJobRecovery({
  applicationState,
  authoritativePrice,
  calculationView,
  checkoutReviewFlow,
  foundation,
  jobClient,
  priceBar,
  progressView,
  wizardNavigation,
} = {}) {
  let __runningJobRecoveryBusy;

  async function pollJob(jobId, accessToken) {
    return jobClient.r9JobsOwner().pollJob({
      jobId,
      accessToken,
      onProgress: ({ progressPct, progressLabel }) => {
        calculationView.statusMsg(`Bezig met optimaliseren… ${progressPct}% • ${progressLabel}`);
        priceBar.updatePriceBar({ busy: true, progressPct, progressLabel });
      },
    });
  }

  async function resumeAcceptedJobAfterReload() {
    if (__runningJobRecoveryBusy || window.__metod_calculation_inflight === true) return false;
    const owner = foundation.current;
    if (!owner || typeof owner.resumeRecoveredJob !== "function") return false;
    __runningJobRecoveryBusy = true;
    window.__metod_calculation_inflight = true;
    calculationView.setCalculationEntryPointsDisabled(true);
    let progressOwned = false;
    try {
      progressOwned = !!owner.startOptimizerProgress?.({
        progressPct: 1,
        progressLabel: "Bestaande berekening hervatten…",
      });

      calculationView.statusMsg("Bestaande berekening veilig teruggevonden. Status wordt hervat…");
      const resumed = await owner.resumeRecoveredJob({
        onProgress: ({ progressPct, progressLabel }) => {
          calculationView.statusMsg(`Bezig met optimaliseren… ${progressPct}% • ${progressLabel}`);
          priceBar.updatePriceBar({ busy: true, progressPct, progressLabel });
        },
      });
      if (!resumed?.resumed) return false;
      const jobId = String(resumed.jobId || "").trim();
      const accessToken = String(resumed.accessToken || "").trim();
      const result = resumed.result || null;
      if (!jobId || !result)
        throw new Error("De hervatte jobstatus was niet volledig. Er is geen nieuwe job gestart.");

      // Capability recovery remains memory-only. It is needed for the later
      // authenticated final submission and is never copied into web storage.
      applicationState.current.lastJobAccessToken = accessToken || null;
      window.__metod_last_job_access_token = accessToken || null;
      applicationState.current.lastJobId = jobId;
      applicationState.current.lastParentJobId = jobId;
      applicationState.current.activeAuthoritativeJobId = jobId;
      window.__metod_last_job_id = jobId;
      window.__metod_last_parent_job_id = jobId;
      window.__metod_active_parent_job_id = jobId;
      applicationState.current.lastJobResult = result;
      applicationState.current.lastPricingSummary = result?.pricingSummary || null;
      authoritativePrice._setFinalAuthoritativePrice(jobId, result?.pricingSummary || null);

      let reviewSnapshot = null;
      try {
        reviewSnapshot = owner.getCheckoutCalculationSnapshot?.() || null;
        if (!owner.isCheckoutCalculationSnapshotComplete?.(reviewSnapshot)) {
          owner.captureCheckoutCalculationSnapshot?.({
            state: applicationState.current,
            customer:
              applicationState.current?.lastCalculatedCustomer ||
              applicationState.current?.checkout?.customer ||
              null,
          });
          reviewSnapshot = owner.getCheckoutCalculationSnapshot?.() || null;
        }
      } catch (_) {
        reviewSnapshot = null;
      }
      wizardNavigation.setStep("overview");
      await owner.settleOptimizerProgress?.({
        progressPct: 100,
        progressLabel: "Optimalisatie afgerond",
      });
      progressView.finishOptimizerProgressLifecycle();
      progressOwned = false;
      priceBar.updatePriceBar({ busy: false });

      let inclVat = owner.authoritativeTotalInclVat(result);
      if (inclVat == null || !Number.isFinite(Number(inclVat))) {
        await authoritativePrice._hydrateAuthoritativePricingSummary(jobId, true);
        inclVat = authoritativePrice._strictAuthoritativePriceInclVat({
          pricingSummary:
            applicationState.current?.lastPricingSummary ||
            applicationState.current?.lastJobResult?.pricingSummary ||
            null,
        });
      }
      const q = result?.quote || null;
      if (inclVat != null && Number.isFinite(Number(inclVat))) {
        const total = Number(inclVat);
        calculationView.statusMsg(
          `Klaar: totaal ${calculationView.moneyEUR(total)} incl. btw (job ${jobId})`,
        );
        priceBar.updatePriceBar({ total });
        applicationState.current.lastQuote = Object.assign(
          {},
          q || applicationState.current.lastQuote || {},
          {
            total_incl_vat: total,
            totalInclVat: total,
            grandTotalInclVat: total,
          },
        );
        applicationState.current.quote = Object.assign(
          {},
          applicationState.current.quote || q || {},
          {
            total_incl_vat: total,
            totalInclVat: total,
            grandTotalInclVat: total,
          },
        );
      } else {
        calculationView.statusMsg(`Klaar (job ${jobId}). Prijs wordt opgehaald…`);
        if (q) applicationState.current.lastQuote = q;
        applicationState.current.quote = Object.assign(
          {},
          applicationState.current.quote || q || {},
          { total_incl_vat: null, totalInclVat: null, grandTotalInclVat: null },
        );
      }
      window.__metod_price_locked = true;
      return await checkoutReviewFlow.openCompletedCheckoutReview(reviewSnapshot);
    } catch (error) {
      const message = String(
        error?.message || error || "De bestaande berekening kon nog niet worden hervat.",
      ).trim();
      calculationView.statusMsg(`${message} Er is geen nieuwe berekening gestart.`, true);
      return false;
    } finally {
      if (progressOwned) {
        progressView.finishOptimizerProgressLifecycle();
      }
      __runningJobRecoveryBusy = false;
      window.__metod_calculation_inflight = false;
      const recoveryState = owner.getPendingJobStartRecoveryState?.() || null;
      const remainsBlocked =
        recoveryState &&
        !["none", "absent"].includes(String(recoveryState.state || "").toLowerCase());
      calculationView.setCalculationEntryPointsDisabled(!!remainsBlocked);
      priceBar.updatePriceBar();
    }
  }

  function initialize() {
    // Capability tokens and job identifiers are memory-only. Remove values left
    // by older builds; lost-start recovery now uses a key-only server lookup.
    try {
      localStorage.removeItem("metod_last_job_access_token");
    } catch (_) {
      ToolAErrors.recover("tool.a.runtime.modules.job.recovery.js.13", _, [
        "SecurityError",
        "QuotaExceededError",
        "SyntaxError",
      ]);
    }
    try {
      sessionStorage.removeItem("metod_last_job_access_token");
    } catch (_) {
      ToolAErrors.recover("tool.a.runtime.modules.job.recovery.js.14", _, [
        "SecurityError",
        "QuotaExceededError",
        "SyntaxError",
      ]);
    }
    try {
      sessionStorage.removeItem("metod_last_parent_job_id");
    } catch (_) {
      ToolAErrors.recover("tool.a.runtime.modules.job.recovery.js.12", _, [
        "SecurityError",
        "QuotaExceededError",
        "SyntaxError",
      ]);
    }
    try {
      sessionStorage.removeItem("metod_last_job_id");
    } catch (_) {
      ToolAErrors.recover("tool.a.runtime.modules.job.recovery.js.9", _, [
        "SecurityError",
        "QuotaExceededError",
        "SyntaxError",
      ]);
    }
  }

  function initialize2() {
    __runningJobRecoveryBusy = false;
    document.addEventListener("tool-a:job-start-recovery", (event) => {
      const detail = event?.detail || null;
      if (detail?.state !== "ready" || detail?.running !== true) return;
      Promise.resolve().then(() => resumeAcceptedJobAfterReload());
    });
  }

  return Object.freeze({
    pollJob,
    get __runningJobRecoveryBusy() {
      return __runningJobRecoveryBusy;
    },
    resumeAcceptedJobAfterReload,
    initialize,
    initialize2,
  });
}
