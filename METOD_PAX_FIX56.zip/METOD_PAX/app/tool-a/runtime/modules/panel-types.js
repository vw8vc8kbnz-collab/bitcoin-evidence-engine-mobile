import { ToolATypeSizeDecisions } from "../../domain/type-size-decisions.js";
/** panel-types: one runtime owner with explicit, immutable dependency ports. */
export function createPanelTypes({ applicationState, panelElements, selectionState } = {}) {
  function getTypeLabelFromKey(typeKey) {
    const key = String(typeKey || "").trim();
    if (!key) return "";
    if (key === "deur") return "Deuren METOD";
    if (key === "lade") return "Ladefront METOD";
    if (key === "pax_deur") return "Deuren PAX";
    if (key === "special") return "Overige panelen";
    {
      const list = Array.isArray(applicationState.current?.catalog?.[key])
        ? applicationState.current.catalog[key]
        : [];
      const fromItem = String(list[0]?.folderLabel || list[0]?.kind || "").trim();
      if (fromItem) return fromItem;
    }
    return key.replace(/^cat_/, "").replace(/_/g, " ").trim() || key;
  }

  function getOrderedTypeKeys() {
    const available =
      ToolATypeSizeDecisions && typeof ToolATypeSizeDecisions.getAvailableTypes === "function"
        ? ToolATypeSizeDecisions.getAvailableTypes(applicationState.current)
        : Object.keys(applicationState.current?.catalog || {}).filter(
            (k) =>
              Array.isArray(applicationState.current.catalog[k]) &&
              applicationState.current.catalog[k].length > 0,
          );
    const preferred = ["deur", "lade", "pax_deur"];
    const custom = available
      .filter((k) => !preferred.includes(k) && k !== "special")
      .sort((a, b) => getTypeLabelFromKey(a).localeCompare(getTypeLabelFromKey(b), "nl"));
    const ordered = preferred.filter((k) => available.includes(k)).concat(custom);
    if (available.includes("special")) ordered.push("special");
    return ordered;
  }

  function updateTypeOptions() {
    if (!panelElements.typeSel) return;
    const current = String(
      panelElements.typeSel.value || applicationState.current?.selection?.type || "",
    ).trim();
    const ordered = getOrderedTypeKeys();
    panelElements.typeSel.innerHTML = "";
    const placeholder = document.createElement("option");
    placeholder.value = "";
    placeholder.textContent = "— Kies type —";
    panelElements.typeSel.appendChild(placeholder);
    ordered.forEach((key) => {
      const opt = document.createElement("option");
      opt.value = key;
      opt.textContent = getTypeLabelFromKey(key);
      panelElements.typeSel.appendChild(opt);
    });
    const next = ordered.includes(current) ? current : ordered[0] || "";
    if (next) {
      panelElements.typeSel.value = next;
      selectionState.update({ type: next });
    } else {
      panelElements.typeSel.value = "";
    }
    if (typeof panelElements.typeSel.__appleSync === "function")
      panelElements.typeSel.__appleSync();
    window.__refreshCustomLabelVisibility?.();
  }

  function syncDefaultPanelTypeSelection() {
    {
      if (!panelElements.typeSel) return;
      let nextType = "";

      if (
        ToolATypeSizeDecisions &&
        typeof ToolATypeSizeDecisions.getPreferredPanelType === "function"
      ) {
        nextType = String(
          ToolATypeSizeDecisions.getPreferredPanelType(applicationState.current) || "",
        ).trim();
      }

      if (!nextType) {
        nextType = String(applicationState.current?.selection?.type || "").trim();
      }
      if (nextType) {
        selectionState.update({ type: nextType });
        panelElements.typeSel.value = nextType;
        if (typeof panelElements.typeSel.__appleSync === "function")
          panelElements.typeSel.__appleSync();
      }
      if (
        !String(panelElements.typeSel.value || "").trim() &&
        String(applicationState.current?.selection?.templateId || "").trim()
      ) {
        const curTpl2 = applicationState.current?.selection?.templateId
          ? applicationState.current.templates.get(applicationState.current.selection.templateId) ||
            null
          : null;
        const tplType = String(curTpl2?.type || "").trim();
        if (tplType) {
          selectionState.update({ type: tplType });
          panelElements.typeSel.value = tplType;
          if (typeof panelElements.typeSel.__appleSync === "function")
            panelElements.typeSel.__appleSync();
        }
      }
      if (!String(panelElements.typeSel.value || "").trim()) {
        const fallback =
          String(applicationState.current?.selection?.type || nextType || "deur").trim() || "deur";
        panelElements.typeSel.value = fallback;
        if (typeof panelElements.typeSel.__appleSync === "function")
          panelElements.typeSel.__appleSync();
      }
      window.__refreshCustomLabelVisibility?.();
    }
  }

  return Object.freeze({
    syncDefaultPanelTypeSelection,
    updateTypeOptions,
  });
}
