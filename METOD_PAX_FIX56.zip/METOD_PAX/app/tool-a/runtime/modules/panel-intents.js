/** A row requests an edit; the edit controller owns navigation and form prefill. */
export function createPanelIntents({} = {}) {
  let editHandler;

  function bind(handler) {
    if (editHandler) throw new Error("Panel edit handler is already connected");
    if (typeof handler !== "function") throw new TypeError("Panel edit handler is required");
    editHandler = handler;
  }

  function edit(id) {
    if (!editHandler) throw new Error("Panel edit handler is not connected");
    if (typeof id !== "string" || !id.trim()) throw new TypeError("Invalid panel id");
    editHandler(id);
  }

  return Object.freeze({ bind, edit });
}
