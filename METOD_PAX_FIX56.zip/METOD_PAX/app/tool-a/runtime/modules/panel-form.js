import { ToolAPanelEditContext } from "../../domain/panel-edit-context.js";
import { ToolAPanelUiState } from "../../domain/panel-ui-state.js";
/** panel-form: one runtime owner with explicit, immutable dependency ports. */
export function createPanelForm({
  applicationState,
  domLookup,
  foundation,
  materialSelectionView,
  panelEditSession,
  panelElements,
  panelPreview,
  selectionState,
} = {}) {
  function setPanelEditMode(itemId, count, groupKey) {
    panelEditSession.panelEditTargetId = itemId ? String(itemId) : null;
    panelEditSession.panelEditGroupKey = groupKey ? String(groupKey) : null;
    panelEditSession.panelEditOriginalCount = Math.max(0, Number(count) || 0);
    window.__panelEditTargetId = panelEditSession.panelEditTargetId;
    window.__panelEditGroupKey = panelEditSession.panelEditGroupKey;
    window.__panelEditOriginalCount = panelEditSession.panelEditOriginalCount;
    if (!panelEditSession.panelEditTargetId) {
      window.__panelEditSnapshot = null;
      window.__panelEditLiveForm = null;
      window.__panelEditKnownName = "";
      window.__panelEditTouchedFields = {
        qty: false,
        hinge: false,
        extTop: false,
        extBot: false,
        customLabel: false,
      };
      selectionState.update({ customLabel: "" });
      {
        const __nameInp = domLookup.byId("customLabelInput");
        if (__nameInp) {
          __nameInp.value = "";
          __nameInp.setAttribute("value", "");
        }
      }
    }
    {
      const __editContext =
        ToolAPanelEditContext && typeof ToolAPanelEditContext.getContext === "function"
          ? ToolAPanelEditContext.getContext({
              localTargetId: panelEditSession.panelEditTargetId,
              localGroupKey: panelEditSession.panelEditGroupKey,
              localOriginalCount: panelEditSession.panelEditOriginalCount,
              state: applicationState.current,
            })
          : {
              targetId: panelEditSession.resolvePanelEditTargetId(),
              groupKey: panelEditSession.resolvePanelEditGroupKey(),
              originalCount: panelEditSession.resolvePanelEditOriginalCount(),
              isEditing: !!panelEditSession.resolvePanelEditTargetId(),
            };
      const __addState =
        ToolAPanelEditContext && typeof ToolAPanelEditContext.getAddButtonState === "function"
          ? ToolAPanelEditContext.getAddButtonState(__editContext)
          : {
              isEditing: !!__editContext?.isEditing,
              inlineLabel: __editContext?.isEditing
                ? "✓ Wijzigingen opslaan"
                : "+ Toevoegen aan lijst",
              buttonLabel: __editContext?.isEditing ? "Wijzigingen opslaan" : "Toevoegen",
              ariaLabel: __editContext?.isEditing ? "Wijzigingen opslaan" : "Toevoegen aan lijst",
              hintText: __editContext?.isEditing
                ? (__editContext?.originalCount || 0) > 1
                  ? `Je bewerkt 1 paneel uit een groep van ${__editContext.originalCount}.`
                  : "Je bewerkt nu een bestaand paneel."
                : "",
            };
      if (addInline) {
        addInline.textContent = __addState.inlineLabel;
        addInline.classList.toggle("is-editing", !!__addState.isEditing);
        addInline.setAttribute("aria-label", __addState.ariaLabel);
      }
      if (panelElements.addBtn) {
        panelElements.addBtn.textContent = __addState.buttonLabel;
      }
      if (panelElements.panelDockHint) {
        if (__addState.isEditing) {
          panelElements.panelDockHint.textContent =
            __addState.hintText || "Je bewerkt nu een bestaand paneel.";
          panelElements.panelDockHint.style.display = "block";
        } else if (
          panelElements.panelDockHint.textContent &&
          /bewerk/i.test(panelElements.panelDockHint.textContent)
        ) {
          panelElements.panelDockHint.style.display = "none";
        }
      }
    }
  }

  function resolvePanelEditCustomName(snapshot) {
    {
      const snap =
        snapshot ||
        (typeof window !== "undefined" && window.__panelEditSnapshot
          ? window.__panelEditSnapshot
          : null) ||
        {};
      let resolvedName = String(snap.customLabel || snap.customName || snap.label || "").trim();
      if (resolvedName) return resolvedName;
      const editId =
        typeof panelEditSession.resolvePanelEditTargetId === "function"
          ? panelEditSession.resolvePanelEditTargetId()
          : panelEditSession.panelEditTargetId;
      const it =
        (applicationState.current.cart || []).find(
          (x) => String(x?.id || "") === String(editId || ""),
        ) || null;
      if (it) {
        const direct = String(it.customName || it.customLabel || "").trim();
        const label = String(it.label || "").trim();
        const base = String(it.baseLabel || it.templateId || "").trim();
        return direct || (label && label !== base ? label : "");
      }
      return "";
    }
  }

  function ensurePanelEditKnownName(snapshot) {
    {
      const resolved = String(resolvePanelEditCustomName(snapshot) || "").trim();
      if (typeof window !== "undefined") window.__panelEditKnownName = resolved;
      return resolved;
    }
  }

  function applyKnownPanelEditName(force) {
    {
      const known = String(
        (typeof window !== "undefined" && window.__panelEditKnownName) ||
          applicationState.current?.selection?.customLabel ||
          "",
      ).trim();
      if (!known) return false;
      const inp = domLookup.byId("customLabelInput");
      if (!inp) return false;
      if (force || !String(inp.value || "").trim()) {
        inp.value = known;
        inp.setAttribute("value", known);
      }
      selectionState.update({ customLabel: known });
      inp.dispatchEvent(new Event("input", { bubbles: true }));
      return true;
    }
  }

  function syncPanelEditLiveForm() {
    if (typeof window === "undefined") return;
    window.__panelEditLiveForm = {
      qty: Math.max(
        1,
        parseInt(
          (panelElements.qty && panelElements.qty.value) ||
            applicationState.current?.selection?.qty ||
            1,
          10,
        ) || 1,
      ),
      hinge: String(
        (panelElements.hingeSel && panelElements.hingeSel.value) ||
          applicationState.current?.selection?.hinge ||
          "left",
      ),
      extTop:
        Number(
          (panelElements.extTop && panelElements.extTop.value) ||
            applicationState.current?.selection?.extTop ||
            0,
        ) || 0,
      extBot:
        Number(
          (panelElements.extBot && panelElements.extBot.value) ||
            applicationState.current?.selection?.extBot ||
            0,
        ) || 0,
      customLabel: String(
        (domLookup.byId("customLabelInput") && domLookup.byId("customLabelInput").value) ||
          applicationState.current?.selection?.customLabel ||
          "",
      ).trim(),
    };
  }

  function applyPanelEditSnapshotToForm(snapshot) {
    {
      const snap =
        snapshot ||
        (typeof window !== "undefined" && window.__panelEditSnapshot
          ? window.__panelEditSnapshot
          : null);
      if (!snap) return false;
      const touched =
        typeof window !== "undefined" && window.__panelEditTouchedFields
          ? window.__panelEditTouchedFields
          : {};
      const resolvedName = ensurePanelEditKnownName(snap) || resolvePanelEditCustomName(snap);
      if (!touched.qty) {
        selectionState.update({ qty: Math.max(1, Number(snap.qty || 1) || 1) });
        if (panelElements.qty)
          panelElements.qty.value = String(applicationState.current.selection.qty);
      }
      if (!touched.hinge) {
        selectionState.update({ hinge: String(snap.hinge || "left") });
        if (panelElements.hingeSel)
          panelElements.hingeSel.value = applicationState.current.selection.hinge;
      }
      if (!touched.extTop) {
        selectionState.update({ extTop: Number(snap.extTop) || 0 });
        if (panelElements.extTop)
          panelElements.extTop.value = String(applicationState.current.selection.extTop);
      }
      if (!touched.extBot) {
        selectionState.update({ extBot: Number(snap.extBot) || 0 });
        if (panelElements.extBot)
          panelElements.extBot.value = String(applicationState.current.selection.extBot);
      }
      window.__refreshCustomLabelVisibility?.();
      if (!touched.customLabel) {
        selectionState.update({ customLabel: resolvedName });
        {
          const custom = domLookup.byId("customLabelInput");
          if (custom) {
            custom.value = resolvedName;
            custom.setAttribute("value", resolvedName);
          }
        }
      }
      if (panelElements.qty) panelElements.qty.dispatchEvent(new Event("input", { bubbles: true }));
      if (panelElements.hingeSel)
        panelElements.hingeSel.dispatchEvent(new Event("change", { bubbles: true }));
      if (panelElements.extTop)
        panelElements.extTop.dispatchEvent(new Event("input", { bubbles: true }));
      if (panelElements.extBot)
        panelElements.extBot.dispatchEvent(new Event("input", { bubbles: true }));
      {
        const custom = domLookup.byId("customLabelInput");
        if (custom) custom.dispatchEvent(new Event("input", { bubbles: true }));
      }
      syncPanelEditLiveForm();
      if (typeof materialSelectionView.updateButtons === "function")
        materialSelectionView.updateButtons();
      panelPreview.draw();
      return true;
    }
  }

  let legacyAddBtn;
  let legacySaveBtn;
  let addInline;
  let overviewBtnInline;
  let extraBtn;

  function resetPanelEntryFields() {
    const __reset = {
      qty: 1,
      extTop: 0,
      extBot: 0,
      hinge: domLookup.byId("hingeSel")?.value || "left",
      customLabel: "",
      clearEdit: true,
    };

    const __setEditMode =
      typeof setPanelEditMode === "function"
        ? setPanelEditMode
        : typeof window !== "undefined" && typeof window.__setPanelEditMode === "function"
          ? window.__setPanelEditMode
          : null;

    const __applied =
      foundation.current && typeof foundation.current.resetPanelEditor === "function"
        ? foundation.current.resetPanelEditor({
            state: applicationState.current,
            selectionCommands: selectionState,
            options: { currentHingeValue: __reset.hinge },
            elements: {
              qty: domLookup.byId("qty"),
              extTop: domLookup.byId("extTop"),
              extBot: domLookup.byId("extBot"),
              hingeSel: domLookup.byId("hingeSel"),
              customLabelInput: domLookup.byId("customLabelInput"),
            },
            setPanelEditMode: __setEditMode,
            refreshCustomLabelVisibility: window.__refreshCustomLabelVisibility,
          })
        : false;
    if (__applied) return;

    // Reset visible inputs
    {
      const q = domLookup.byId("qty");
      if (q) q.value = String(__reset.qty);
    }
    {
      const t = domLookup.byId("extTop");
      if (t) t.value = String(__reset.extTop);
    }
    {
      const b = domLookup.byId("extBot");
      if (b) b.value = String(__reset.extBot);
    }
    {
      const h = domLookup.byId("hingeSel");
      if (h) {
        h.value = String(__reset.hinge || "left");
      }
    }
    {
      const n = domLookup.byId("customLabelInput");
      if (n) n.value = String(__reset.customLabel || "");
    }
    if (__reset.clearEdit && typeof __setEditMode === "function") __setEditMode(null, 0);

    // Reset underlying state so UI re-renders don't "restore" old values

    if (
      typeof applicationState.current !== "undefined" &&
      applicationState.current &&
      applicationState.current.selection
    ) {
      selectionState.update({ qty: Number(__reset.qty || 1) || 1 });
      selectionState.update({ extTop: Number(__reset.extTop) || 0 });
      selectionState.update({ extBot: Number(__reset.extBot) || 0 });
      // Keep template/type/size and material as-is (those are typically re-used),
      // but ensure hinge is set to the default option.
      selectionState.update({ hinge: String(__reset.hinge || "left") });
    }

    // Ensure dependent validation/UI enables/disables update after reset
    {
      // Trigger a lightweight input event so any listeners update derived state
      const q = domLookup.byId("qty");
      if (q) q.dispatchEvent(new Event("input", { bubbles: true }));
      const t = domLookup.byId("extTop");
      if (t) t.dispatchEvent(new Event("input", { bubbles: true }));
      const b = domLookup.byId("extBot");
      if (b) b.dispatchEvent(new Event("input", { bubbles: true }));
      const h = domLookup.byId("hingeSel");
      if (h) h.dispatchEvent(new Event("change", { bubbles: true }));
      const n = domLookup.byId("customLabelInput");
      if (n) n.dispatchEvent(new Event("input", { bubbles: true }));
      window.__refreshCustomLabelVisibility?.();
    }
  }

  function ensureCustomLabelHook() {
    const typeSel = domLookup.byId("typeSel");
    const labelWrap = domLookup.byId("customLabelWrap");
    const labelInp = domLookup.byId("customLabelInput");
    const updateLabelVis = () => {
      let __labelState = null;

      if (ToolAPanelUiState?.getCustomLabelState) {
        __labelState = ToolAPanelUiState.getCustomLabelState({
          rawValue: String(typeSel?.value || ""),
          selectedText: String(
            typeSel?.selectedOptions?.[0]?.textContent ||
              typeSel?.options?.[typeSel?.selectedIndex]?.textContent ||
              "",
          ),
          stateType: String(
            (typeof applicationState.current !== "undefined"
              ? applicationState.current?.selection?.type
              : window.state?.selection?.type) || "",
          ),
        });
      }

      const showIt = __labelState ? !!__labelState.show : false;
      if (labelWrap) labelWrap.style.display = showIt ? "block" : "none";
      if ((__labelState ? !!__labelState.clearValueOnHide : !showIt) && labelInp)
        labelInp.value = "";
      if (showIt && labelInp) {
        {
          const isEditing = !!(
            (typeof window !== "undefined" && window.__panelEditTargetId) ||
            panelEditSession.panelEditTargetId
          );
          if (isEditing) {
            const touched =
              typeof window !== "undefined" && window.__panelEditTouchedFields
                ? window.__panelEditTouchedFields
                : {};
            const snap =
              typeof window !== "undefined" && window.__panelEditSnapshot
                ? window.__panelEditSnapshot
                : null;
            const resolved = String(
              (!touched.customLabel && typeof ensurePanelEditKnownName === "function"
                ? ensurePanelEditKnownName(snap)
                : "") ||
                (!touched.customLabel && typeof resolvePanelEditCustomName === "function"
                  ? resolvePanelEditCustomName(snap)
                  : "") ||
                (typeof window !== "undefined" ? window.__panelEditKnownName : "") ||
                applicationState.current?.selection?.customLabel ||
                "",
            ).trim();
            if (resolved && !String(labelInp.value || "").trim()) {
              labelInp.value = resolved;
              labelInp.setAttribute("value", resolved);
            }
          }
        }
      }
    };
    if (typeSel && !typeSel.__customLabelBound) {
      typeSel.addEventListener("change", updateLabelVis);
      typeSel.addEventListener("input", updateLabelVis);
      typeSel.__customLabelBound = true;
    }
    window.__refreshCustomLabelVisibility = updateLabelVis;
    updateLabelVis();
  }

  function connect() {
    legacyAddBtn = domLookup.byId("addBtn");
    legacySaveBtn = domLookup.byId("saveQuoteBtn");
    addInline = domLookup.byId("addBtnInline");
    overviewBtnInline = null;
    extraBtn = domLookup.byId("extraOverlayBtn");
  }

  return Object.freeze({
    get addInline() {
      return addInline;
    },
    ensureCustomLabelHook,
    setPanelEditMode,
    syncPanelEditLiveForm,
    resolvePanelEditCustomName,
    ensurePanelEditKnownName,
    applyKnownPanelEditName,
    applyPanelEditSnapshotToForm,
    resetPanelEntryFields,
    get legacyAddBtn() {
      return legacyAddBtn;
    },
    connect,
  });
}
