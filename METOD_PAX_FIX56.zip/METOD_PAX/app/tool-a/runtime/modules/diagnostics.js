/** diagnostics: one runtime owner with explicit, immutable dependency ports. */
export function createDiagnostics({ applicationState, jobClient } = {}) {
  function mount() {
    (function () {
      const LOG_ENDPOINT = "/api/client_log";
      const buf = [];
      const recent = new Map();
      let flushing = false;
      let flushTimer = null;
      let mutedUntil = 0;
      function getJobIdSafe() {
        try {
          return (
            window.__metod_last_job_id ||
            applicationState.current?.lastJobId ||
            applicationState.current?.jobId ||
            ""
          ).toString();
        } catch (_) {
          return "";
        }
      }
      function sanitizeClientLogData(data) {
        if (data == null) return null;
        if (typeof data === "string") return data.slice(0, 200);
        if (Array.isArray(data))
          return data.slice(0, 10).map((v) => (typeof v === "string" ? v.slice(0, 120) : typeof v));
        if (typeof data === "object") {
          const out = {};
          Object.keys(data)
            .slice(0, 10)
            .forEach((k) => {
              const low = String(k || "").toLowerCase();
              if (
                [
                  "password",
                  "token",
                  "secret",
                  "email",
                  "mail",
                  "phone",
                  "tel",
                  "telephone",
                  "address",
                  "billingaddress",
                  "shippingaddress",
                  "postcode",
                  "postalcode",
                  "args",
                  "stack",
                ].includes(low)
              ) {
                out[k] = "[redacted]";
              } else {
                const v = data[k];
                out[k] = typeof v === "string" ? v.slice(0, 120) : typeof v;
              }
            });
          return out;
        }

        return null;
      }
      function shouldEnqueue(rec) {
        try {
          if (Date.now() < mutedUntil) return false;
          const lvl = String(rec?.level || "info").toLowerCase();
          const evt = String(rec?.event || "");
          const msg = String(rec?.message || "");
          if (lvl === "info" && !/^job\./.test(evt)) return false;
          const sig = [lvl, evt, msg].join("|").slice(0, 500);
          const now = Date.now();
          const prev = recent.get(sig) || 0;
          if (now - prev < 5000) return false;
          recent.set(sig, now);
          if (recent.size > 300) {
            for (const [k, v] of recent) {
              if (now - v > 30000) recent.delete(k);
            }
          }
          return true;
        } catch (_) {
          return true;
        }
      }
      function enqueue(level, event, message, data) {
        const lvl = String(level || "info").toLowerCase();
        // Tool A should never spam normal UI/info transitions to the server.
        // Keep server-side client logging strictly for warnings/errors.
        if (lvl !== "warn" && lvl !== "error") return;
        const rec = {
          jobId: getJobIdSafe(),
          level: lvl,
          event: event || "",
          message: String(message || "").slice(0, 300),
          data: sanitizeClientLogData(data),
          ts: new Date().toISOString(),
          url: location.pathname,
          ua: "",
        };
        if (!shouldEnqueue(rec)) return;
        buf.push(rec);
        if (buf.length > 120) buf.splice(0, buf.length - 120);
        flushSoon();
      }
      function failureClass(value) {
        {
          const raw = String(value?.name || value || "").toLowerCase();
          if (raw.includes("network") || raw.includes("fetch")) return "NetworkError";
          if (raw.includes("timeout")) return "TimeoutError";
          if (raw.includes("syntax")) return "SyntaxError";
          if (raw.includes("type")) return "TypeError";
        }
        return "ClientError";
      }
      function sourceClass(value) {
        try {
          const path = String(value || "").split(/[?#]/, 1)[0];
          const name = path.split("/").pop() || "";
          return /^[A-Za-z0-9._-]{1,100}$/.test(name) ? name : "application";
        } catch (_) {
          return "application";
        }
      }
      function flushSoon() {
        if (flushing || flushTimer) return;
        flushTimer = setTimeout(async () => {
          flushTimer = null;
          if (flushing || !buf.length) return;
          flushing = true;
          try {
            while (buf.length) {
              const rec = buf.shift();
              try {
                const jobHeaders =
                  typeof jobClient.buildJobTokenHeaders === "function"
                    ? jobClient.buildJobTokenHeaders()
                    : {};
                const resp = await fetch(LOG_ENDPOINT, {
                  method: "POST",
                  headers: Object.assign({ "Content-Type": "application/json" }, jobHeaders),
                  body: JSON.stringify(rec),
                });
                if (resp && (resp.status === 401 || resp.status === 403 || resp.status === 429)) {
                  mutedUntil = Date.now() + 30000;
                  buf.length = 0;
                  break;
                }
              } catch (_) {
                mutedUntil = Date.now() + 10000;
                break;
              }
            }
          } finally {
            flushing = false;
            if (buf.length && Date.now() >= mutedUntil) flushSoon();
          }
        }, 400);
      }

      window.addEventListener("error", (e) => {
        {
          const location =
            sourceClass(e?.filename) + ":" + Number(e?.lineno || 0) + ":" + Number(e?.colno || 0);
          enqueue(
            "error",
            "window.error",
            failureClass(e?.error || e?.message) + " @" + location,
            null,
          );
        }
      });

      window.addEventListener("unhandledrejection", (e) => {
        {
          const r = e?.reason;
          enqueue("error", "unhandledrejection", failureClass(r), null);
        }
      });

      window.__metod_log = enqueue;
    })();
  }

  return Object.freeze({
    mount,
  });
}
