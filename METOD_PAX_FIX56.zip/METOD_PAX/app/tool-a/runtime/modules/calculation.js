/** calculation: one runtime owner with explicit, immutable dependency ports. */
export function createCalculation({
  alertDialog,
  applicationState,
  authoritativePrice,
  calculationView,
  checkoutFlow,
  checkoutReviewFlow,
  customerForm,
  foundation,
  jobClient,
  jobEstimates,
  jobPayload,
  jobRecovery,
  overviewOverlay,
  priceBar,
  progressView,
  templateExport,
  wizardNavigation,
} = {}) {
  let __calculationRunSequence;
  let __activeCalculationRunId;

  async function runCalculationOnce() {
    ToolAErrors.assertHealthy();
    // A lost final-submit response may already represent a committed customer
    // request. Starting a new calculation would overwrite the only local job
    // reference needed for idempotent reconciliation.

    if (window.__metodHasUncertainFinalSubmission?.() === true) {
      calculationView.statusMsg(
        "Bevestig eerst opnieuw de aanvraag waarvan de verzendstatus nog onzeker is.",
        true,
      );
      return;
    }

    // Acquire the run before the first await; all physical/programmatic owners share this lock.
    if (
      __activeCalculationRunId ||
      window.__metod_calculation_inflight === true
    )
      return;
    const __calculationRunId = ++__calculationRunSequence;
    __activeCalculationRunId = __calculationRunId;
    window.__metod_calculation_inflight = true;
    window.__metodInvalidateAuthoritativePriceHydration?.();
    calculationView.setCalculationEntryPointsDisabled(true);
    let __startedJobId = null;
    let __optimizerProgressOwned = false;
    let __calculationReviewSnapshot = null;
    try {
      if (
        !applicationState.current.cart.length &&
        !applicationState.current.extraPanels.length
      ) {
        calculationView.statusMsg("Geen panelen om te verwerken.", true);
        return;
      }
      if (!foundation.current) {
        document.dispatchEvent(new Event("tool-a:foundation-request"));
      }
      const __requiredCalculationOwners = [
        "captureCheckoutCalculationSnapshot",
        "getCheckoutCalculationSnapshot",
        "isCheckoutCalculationSnapshotComplete",
        "openCheckoutReview",
        "updateMetodProgressBadge",
        "startOptimizerProgress",
        "finishOptimizerProgress",
        "isOptimizerBusy",
        "waitForMetodProgressPaint",
      ];
      if (
        !foundation.current ||
        __requiredCalculationOwners.some(
          (name) => typeof foundation.current[name] !== "function",
        )
      ) {
        await alertDialog.showToolAlertHardFallbackAsync({
          title: "Tool A is nog niet volledig geladen",
          body: "De beveiligde berekeningsweergave kon niet worden gestart.",
          details:
            "Herlaad deze pagina één keer en probeer daarna opnieuw. Er is nog geen aanvraag verstuurd.",
        });
        return;
      }
      // Checkout (restmateriaal + klantgegevens)
      calculationView.statusMsg("Opslaan: gegevens verzamelen…");
      const checkout = await checkoutFlow.runCheckoutOverlays();
      if (!checkout) {
        // runCheckoutOverlays already showed the correct reason (e.g. missing e-mail)
        return;
      }

      // This calculation owns a fresh customer snapshot and submission state.
      // A successful/failed request from an earlier job in the same Safari tab
      // must not disable the new result CTA.
      customerForm.commitCustomerCalculationSnapshot();

      if (
        foundation.current &&
        typeof foundation.current.captureCheckoutCalculationSnapshot ===
          "function"
      ) {
        foundation.current.captureCheckoutCalculationSnapshot({
          state: applicationState.current,
          customer: applicationState.current.lastCalculatedCustomer,
        });
      }

      // Validate authoritative grain-group data before starting the optimizer.
      // Canvas visibility is deliberately not a gate: iOS may collapse or
      // detach the preview drawer while the same production data remains valid.
      const __grainReadiness =
        foundation.current &&
        typeof foundation.current.getGrainPreviewReadiness === "function"
          ? foundation.current.getGrainPreviewReadiness()
          : {
              ok: false,
              token: "",
              missing: [],
              message:
                "De nerf-previewcontrole is niet geladen. Herlaad de pagina.",
            };
      if (!__grainReadiness.ok) {
        window.__metod_price_locked = false;
        const __grainMessage =
          __grainReadiness.message ||
          "Controleer de samenstelling van de doorlopende nerfgroep.";
        try {
          await alertDialog.showToolAlertHardFallbackAsync({
            title: "Controleer de doorlopende nerf",
            body: __grainMessage,
            details:
              "De optimalisatie is nog niet gestart. Corrigeer de genoemde nerfgroep en probeer daarna opnieuw.",
            onClose: () => {
              wizardNavigation.showStep("grain");
            },
          });
        } catch (_) {
          wizardNavigation.showStep("grain");
          calculationView.statusMsg(__grainMessage, true);
        }
        return;
      }

      applicationState.current.lastGrainPreviewAttestation = {
        token: String(__grainReadiness.token || ""),
        jobId: "",
      };

      window.__metod_submit_inflight = false;
      window.__metod_submit_done = false;
      window.__metod_submitted_parent_job_id = null;
      if (
        foundation.current &&
        typeof foundation.current.resetFinalSubmission === "function"
      )
        foundation.current.resetFinalSubmission();

      // All mobile preconditions are now proven. Replace Overview with the
      // progress owner in this same synchronous transaction so Safari never
      // exposes the hidden customer step between the tap and the overlay.
      overviewOverlay.closeOverview();
      calculationView.statusMsg("Aanvraag voorbereiden… 0%");
      const __progressOptions = {
        progressPct: 0,
        progressLabel: "Panelen voorbereiden…",
      };
      let __progressOpened = false;
      __progressOpened =
        !!foundation.current.startOptimizerProgress(__progressOptions);
      priceBar.updatePriceBar(Object.assign({ busy: true }, __progressOptions));
      // The synchronous component-owned activation contract is the hard gate.
      // WebKit compositor paint itself cannot be proven from JavaScript; the
      // bounded two-frame yield below is deliberately best effort.
      if (!__progressOpened) {
        foundation.current.initMetodProgressOverlay?.();
        __progressOpened =
          !!foundation.current.startOptimizerProgress(__progressOptions);
        priceBar.updatePriceBar(
          Object.assign({ busy: true }, __progressOptions),
        );
      }
      if (!__progressOpened || !foundation.current.isOptimizerBusy()) {
        throw new Error(
          "De voortgangsweergave kon niet veilig worden opgebouwd. Herlaad de pagina en probeer opnieuw.",
        );
      }
      __optimizerProgressOwned = true;
      let __progressPainted = false;
      __progressPainted = !!(await progressView.waitForMetodProgressPaint());
      if (!__progressPainted) {
        // Reassert the already validated overlay after Safari lifecycle or
        // compositor throttling. A second paint acknowledgement is not a gate.
        foundation.current.startOptimizerProgress(__progressOptions);
        priceBar.updatePriceBar(
          Object.assign({ busy: true }, __progressOptions),
        );
      }
      // Start of a new compute run: invalidate every previous displayed price.
      applicationState.current.lastPricingSummary = null;
      applicationState.current.finalAuthoritativePriceInclVat = null;
      applicationState.current.finalAuthoritativeJobId = null;
      applicationState.current.lastJobResult = Object.assign(
        {},
        applicationState.current.lastJobResult || {},
        { pricingSummary: null },
      );
      applicationState.current.quote = Object.assign(
        {},
        applicationState.current.quote || {},
        {
          total_incl_vat: null,
          totalInclVat: null,
          grandTotalInclVat: null,
        },
      );
      applicationState.current.lastQuote = Object.assign(
        {},
        applicationState.current.lastQuote || {},
        { total_incl_vat: null, totalInclVat: null, grandTotalInclVat: null },
      );
      window.__metod_price_validated_key = null;

      const payload = await jobPayload.buildJobPayload();
      // Keep the exact payload-bound review snapshot in this job's async scope.
      // Global wizard state may change while the server is optimizing.
      __calculationReviewSnapshot =
        foundation.current.getCheckoutCalculationSnapshot();
      if (
        !foundation.current.isCheckoutCalculationSnapshotComplete(
          __calculationReviewSnapshot,
        )
      ) {
        throw new Error(
          "De berekeningsgegevens zijn na het opbouwen niet volledig beschikbaar. De aanvraag is niet verstuurd.",
        );
      }
      priceBar.updatePriceBar({
        busy: true,
        progressPct: 8,
        progressLabel: "Aanvraag veilig serialiseren…",
      });
      await templateExport.yieldPayloadProgressPaint();
      const __payloadJson = JSON.stringify(payload);
      priceBar.updatePriceBar({
        busy: true,
        progressPct: 9,
        progressLabel: "Aanvraag naar optimizer sturen…",
      });
      await templateExport.yieldPayloadProgressPaint();
      const __payloadBytes = new Blob([__payloadJson]).size;
      const __preflight =
        payload && payload.preflightEstimate ? payload.preflightEstimate : null;
      const __panelCount = Math.max(0, Number(__preflight?.totalQty || 0) || 0);
      const __maxAreaLowerBound = Math.max(
        0,
        Number(__preflight?.maxAreaLowerBound || 0) || 0,
      );
      if (__panelCount > jobEstimates.PUBLIC_JOB_PANEL_LIMIT) {
        await alertDialog.showToolAlertHardFallbackAsync({
          title: "Te veel panelen",
          body: `Deze configuratie bevat ${__panelCount} panelen. Maximum is ${jobEstimates.PUBLIC_JOB_PANEL_LIMIT} panelen per aanvraag.`,
          details: "Splits de bestelling op in meerdere aanvragen.",
        });
        restoreIdleToolStateAfterStartError();
        return;
      }
      if (__maxAreaLowerBound > jobEstimates.PUBLIC_JOB_AREA_HARD_LB) {
        await alertDialog.showToolAlertHardFallbackAsync({
          title: "Aanvraag te groot",
          body: `Deze configuratie is uitzonderlijk groot voor één aanvraag. De geschatte minimale plaatbehoefte is minstens ${__maxAreaLowerBound} platen.`,
          details: "Splits de bestelling op in meerdere aanvragen.",
        });
        restoreIdleToolStateAfterStartError();
        return;
      }
      if (__payloadBytes > jobEstimates.PUBLIC_JOB_PAYLOAD_MAX_BYTES) {
        await alertDialog.showToolAlertHardFallbackAsync({
          title: "Aanvraag te groot",
          body: "Deze configuratie is uitzonderlijk groot voor één aanvraag.",
          details: "Splits de bestelling op in meerdere aanvragen.",
        });
        restoreIdleToolStateAfterStartError();
        return;
      }
      if (__maxAreaLowerBound > jobEstimates.PUBLIC_JOB_AREA_WARN_LB) {
        // An interactive confirm must never sit below the modal optimizer
        // owner. Release it temporarily, then reacquire it only after consent.
        progressView.finishOptimizerProgressLifecycle();
        __optimizerProgressOwned = false;
        const okLarge =
          typeof window.showToolConfirm === "function"
            ? await window.showToolConfirm(
                {
                  title: "Aanvraag is groot",
                  body: `De geschatte minimale plaatbehoefte is minstens ${__maxAreaLowerBound} platen en de verwerking kan langer duren.`,
                  details:
                    "Klik op Doorgaan om verder te gaan of op Annuleren om de bestelling eerst te splitsen.",
                  okText: "Doorgaan",
                  cancelText: "Annuleren",
                },
                "Aanvraag is groot",
              )
            : window.confirm(`Deze aanvraag is groot. De geschatte minimale plaatbehoefte is minstens ${__maxAreaLowerBound} platen en de verwerking kan langer duren.

Klik op OK om door te gaan of op Annuleren om de bestelling eerst te splitsen.`);
        if (!okLarge) {
          calculationView.statusMsg("Aanvraag geannuleerd.", false);
          restoreIdleToolStateAfterStartError();
          return;
        }
        let __progressReopened = false;
        __progressReopened = !!foundation.current.startOptimizerProgress({
          progressPct: 4,
          progressLabel: "Aanvraag voorbereiden…",
        });
        priceBar.updatePriceBar({
          busy: true,
          progressPct: 4,
          progressLabel: "Aanvraag voorbereiden…",
        });
        if (!__progressReopened || !foundation.current.isOptimizerBusy()) {
          throw new Error(
            "De voortgangsweergave kon na de bevestiging niet veilig worden hervat. Probeer opnieuw.",
          );
        }
        __optimizerProgressOwned = true;
        await foundation.current.waitForMetodProgressPaint();
      }
      priceBar.updatePriceBar({
        busy: true,
        progressPct: 4,
        progressLabel: "Aanvraag voorbereiden…",
      });
      let resp;
      try {
        resp = await jobClient.r9JobsOwner().startJob(__payloadJson);
      } catch (fetchErr) {
        const __rawFetchText = String(
          fetchErr?.message || fetchErr || "",
        ).trim();
        const isBusyNetworkStartFailure =
          !__startedJobId &&
          /failed to fetch|networkerror|load failed|connection reset|connection timed out|err_connection_reset|err_connection_timed_out/i.test(
            __rawFetchText,
          );
        if (isBusyNetworkStartFailure) {
          await alertDialog.showToolAlertHardFallbackAsync({
            title: "Server is momenteel druk",
            body: "Server is momenteel druk met andere aanvragen. Probeer het over enkele minuten opnieuw.",
            details: "",
            onClose: () => {
              restoreIdleToolStateAfterStartError();
              progressView.updateMetodProgressBadge({ busy: false });
            },
          });
          restoreIdleToolStateAfterStartError();
          return;
        }
        throw fetchErr;
      }
      if (!resp.ok) {
        let serverMessage = "";
        let rawText = "";

        rawText = await resp.text();
        try {
          const j = JSON.parse(rawText);
          serverMessage = String(j?.error || j?.message || "").trim();
        } catch (_) {
          serverMessage = String(rawText || "").trim();
        }

        if (resp.status === 429 || resp.status === 503) {
          await alertDialog.showToolAlertHardFallbackAsync({
            title: "Server is momenteel druk",
            body:
              serverMessage ||
              "Server is momenteel druk met andere aanvragen. Probeer het over enkele minuten opnieuw.",
            details: "",
            onClose: () => {
              restoreIdleToolStateAfterStartError();
              progressView.updateMetodProgressBadge({ busy: false });
            },
          });
          restoreIdleToolStateAfterStartError();
          return;
        }
        const err = new Error(serverMessage || `Serverfout (${resp.status})`);
        err.isUserFacing = true;
        err.httpStatus = resp.status;
        throw err;
      }
      const respData = await resp.json();
      const subjobs = Array.isArray(respData?.subjobs) ? respData.subjobs : [];
      let jobId =
        respData?.jobId ||
        respData?.parentJobId ||
        respData?.parentJobID ||
        null;
      if (!jobId && subjobs.length && subjobs[0]?.subjobId)
        jobId = subjobs[0].subjobId;
      if (!jobId)
        throw new Error("Server error: missing jobId in /api/jobs response");
      __startedJobId = jobId;
      const accessToken =
        respData &&
        (respData.accessToken || respData.jobAccessToken || respData.token)
          ? String(
              respData.accessToken || respData.jobAccessToken || respData.token,
            )
          : "";
      applicationState.current.lastJobAccessToken = accessToken || null;
      window.__metod_last_job_access_token = accessToken || null;
      window.__metod_last_parent_job_id = respData?.parentJobId || null;

      window.__metod_last_job_id = jobId;
      applicationState.current.lastJobId = jobId;
      applicationState.current.lastParentJobId =
        respData && respData.parentJobId ? respData.parentJobId : jobId;
      applicationState.current.activeAuthoritativeJobId =
        respData && respData.parentJobId ? respData.parentJobId : jobId;
      window.__metod_last_parent_job_id =
        respData && respData.parentJobId ? respData.parentJobId : jobId;
      {
        const __att = applicationState.current.lastGrainPreviewAttestation;
        if (__att && typeof __att === "object")
          __att.jobId = String(window.__metod_last_parent_job_id || "");
      }
      window.__metod_active_parent_job_id = window.__metod_last_parent_job_id;

      window.__metod_log &&
        window.__metod_log("info", "job.created", jobId, null);
      calculationView.statusMsg(`Job gestart (${jobId}). Optimaliseren…`);
      priceBar.updatePriceBar({
        busy: true,
        progressPct: 9,
        progressLabel: "Aanvraag gestart",
      });

      const result = await jobRecovery.pollJob(
        jobId,
        applicationState.current.lastJobAccessToken || null,
      );
      applicationState.current.lastJobResult = result || null;
      applicationState.current.lastPricingSummary =
        result?.pricingSummary || null;
      authoritativePrice._setFinalAuthoritativePrice(
        jobId,
        result?.pricingSummary || null,
      );
      wizardNavigation.setStep("overview");

      // The DONE status response already passed the server's complete family
      // integrity gate and contains the authoritative quote + pricing summary.
      // Do not block the customer on a second file/status fetch at 100%.
      let q = result?.quote || null;
      // FINAL PRICE RULE: the pre-submit price overlay must come from exactly one source:
      // the authoritative server-side pricingSummary for the current finished job.
      // Never derive the visible final total from quote.json or any client-side fallback.
      const directDoneTotal = jobClient
        .r9JobsOwner()
        .authoritativeTotalInclVat(result);
      let inclVat = directDoneTotal;
      // pollJob has just projected the authoritative DONE=100% event. Let the
      // component visibly catch up to that already verified target before the
      // terminal close transition (bounded for backgrounded WebKit).
      await progressView.settleOptimizerProgress({
        progressPct: 100,
        progressLabel: "Optimalisatie afgerond",
      });
      // DONE is terminal. Release the optimizer owner before any price, panel or
      // checkout renderer runs; none of those layers may keep this modal alive.
      progressView.finishOptimizerProgressLifecycle();
      __optimizerProgressOwned = false;
      // Also render the idle price bar, but terminal closure no longer depends on it.
      priceBar.updatePriceBar({ busy: false });
      if (inclVat == null || !Number.isFinite(Number(inclVat))) {
        await authoritativePrice._hydrateAuthoritativePricingSummary(
          jobId,
          true,
        );
        inclVat = authoritativePrice._strictAuthoritativePriceInclVat({
          pricingSummary:
            applicationState.current?.lastPricingSummary ||
            applicationState.current?.lastJobResult?.pricingSummary ||
            null,
        });
      }

      if (inclVat != null && Number.isFinite(Number(inclVat))) {
        calculationView.statusMsg(
          `Klaar: totaal ${calculationView.moneyEUR(inclVat)} incl. btw (job ${jobId})`,
        );
        priceBar.updatePriceBar({ total: inclVat });
        // Normalize quote holders only *after* the authoritative server total exists for this job.
        // This keeps all later UI reads in sync with the single source of truth.
        applicationState.current.lastQuote = Object.assign(
          {},
          q || applicationState.current.lastQuote || {},
          {
            total_incl_vat: Number(inclVat),
            totalInclVat: Number(inclVat),
            grandTotalInclVat: Number(inclVat),
          },
        );
        applicationState.current.quote = Object.assign(
          {},
          applicationState.current.quote || q || {},
          {
            total_incl_vat: Number(inclVat),
            totalInclVat: Number(inclVat),
            grandTotalInclVat: Number(inclVat),
          },
        );
        window.__metod_price_locked = true;
        if (
          !(await checkoutReviewFlow.openCompletedCheckoutReview(
            __calculationReviewSnapshot,
          ))
        )
          return;
      } else {
        calculationView.statusMsg(
          `Klaar (job ${jobId}). Prijs wordt opgehaald…`,
        );
        priceBar.updatePriceBar({});
        // Keep quote data for diagnostics/downloads, but do not let it act as visible final pricing.
        if (q) {
          applicationState.current.lastQuote = q;
        }
        applicationState.current.quote = Object.assign(
          {},
          applicationState.current.quote || q || {},
          { total_incl_vat: null, totalInclVat: null, grandTotalInclVat: null },
        );
        window.__metod_price_locked = true;
        if (
          !(await checkoutReviewFlow.openCompletedCheckoutReview(
            __calculationReviewSnapshot,
          ))
        )
          return;
      }
      // Never place response payloads or capability tokens in browser logs.
    } catch (err) {
      console.error(
        "Job processing failed",
        String(err?.name || "Error"),
        Number(err?.httpStatus || 0),
      );
      // Never leave the optimizing layer above a validation/network message. This
      // also makes early submit failures recover to a coherent idle screen.
      progressView.finishOptimizerProgressLifecycle();
      __optimizerProgressOwned = false;
      window.__metodBusySince = null;
      clearTimeout(window.__metodBusyWatchdog);
      let userMsg = String(err?.message || err || "").trim();
      const restoreUiAfterAlert = () => {
        restoreIdleToolStateAfterStartError();
        progressView.updateMetodProgressBadge({ busy: false });
      };
      let modalShown = false;
      {
        const __rawBusyText = String(userMsg || err?.stack || err || "").trim();
        const isBusyStartFailure =
          !__startedJobId &&
          (err?.httpStatus === 429 ||
            err?.httpStatus === 503 ||
            /failed to fetch|networkerror|load failed|connection reset|connection timed out|err_connection_reset|err_connection_timed_out/i.test(
              __rawBusyText,
            ));
        if (isBusyStartFailure) {
          userMsg =
            "Server is momenteel druk met andere aanvragen. Probeer het over enkele minuten opnieuw.";
        }
        if (userMsg) {
          let title = "Aanvraag kon niet worden gestart";
          if (isBusyStartFailure || err?.httpStatus === 429)
            title = "Server is momenteel druk";
          else if (
            err?.httpStatus === 413 ||
            /te veel panelen|te groot|maximum is/i.test(userMsg)
          )
            title = "Aanvraag te groot";
          await alertDialog.showToolAlertHardFallbackAsync({
            title,
            body:
              userMsg ||
              "Er ging iets mis bij het starten van de aanvraag. Probeer het opnieuw.",
            details: "",
            onClose: restoreUiAfterAlert,
          });
          modalShown = true;
        }
      }
      if (!modalShown) {
        calculationView.statusMsg(
          userMsg || "Er ging iets mis bij het starten van de aanvraag.",
          true,
        );
      }
      try {
        restoreIdleToolStateAfterStartError();
      } catch (_) {
        priceBar.updatePriceBar({});
      }
    } finally {
      // Absolute terminal guarantee for success, validation return, cancellation,
      // network error and any downstream renderer exception.
      if (
        __optimizerProgressOwned ||
        (foundation.current && foundation.current.isOptimizerBusy?.())
      ) {
        progressView.finishOptimizerProgressLifecycle();
      }
      __optimizerProgressOwned = false;
      if (__activeCalculationRunId === __calculationRunId) {
        __activeCalculationRunId = 0;
        window.__metod_calculation_inflight = false;
        calculationView.setCalculationEntryPointsDisabled(false);
        priceBar.updatePriceBar();
      }
    }
  }

  function startCalculationFromOverview() {
    if (
      __activeCalculationRunId ||
      window.__metod_calculation_inflight === true
    )
      return false;
    try {
      void runCalculationOnce();
      return true;
    } catch (_) {
      calculationView.statusMsg(
        "De berekening kon niet worden gestart. Herlaad Tool A en probeer opnieuw.",
        true,
      );
      return false;
    }
  }

  function restoreIdleToolStateAfterStartError() {
    window.__metod_price_locked = false;
    window.__metodBusySince = null;
    clearTimeout(window.__metodBusyWatchdog);
    priceBar.updatePriceBar({ busy: false });
    if (calculationView.saveQuoteBtn)
      calculationView.saveQuoteBtn.disabled = false;
    if (calculationView.priceBarBtnCalc)
      calculationView.priceBarBtnCalc.disabled = false;
    if (
      calculationView.priceBarBtnOverview &&
      (applicationState.current?.cart?.length || 0) +
        (applicationState.current?.extraPanels?.length || 0) >
        0
    )
      calculationView.priceBarBtnOverview.disabled = false;
    if (typeof calculationView.statusMsg === "function")
      calculationView.statusMsg("Concept opgeslagen", false);
  }

  function initialize2() {
    __calculationRunSequence = 0;
    __activeCalculationRunId = 0;

    checkoutReviewFlow.initialize();
    if (calculationView.saveQuoteBtn)
      calculationView.saveQuoteBtn.addEventListener(
        "click",
        runCalculationOnce,
      );
    try {
      Object.defineProperty(window, "__metodStartCalculationFromOverview", {
        value: startCalculationFromOverview,
        writable: false,
        configurable: false,
        enumerable: false,
      });
    } catch (_) {
      window.__metodStartCalculationFromOverview = startCalculationFromOverview;
    }
  }

  return Object.freeze({
    get __calculationRunSequence() {
      return __calculationRunSequence;
    },
    get __activeCalculationRunId() {
      return __activeCalculationRunId;
    },
    runCalculationOnce,
    startCalculationFromOverview,
    restoreIdleToolStateAfterStartError,
    initialize2,
  });
}
