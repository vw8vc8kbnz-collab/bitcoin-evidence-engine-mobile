/** material-identity: one runtime owner with explicit, immutable dependency ports. */
export function createMaterialIdentity({} = {}) {
  function norm(s) {
    return (s || "").toString().toLowerCase().trim();
  }

  function materialLabelMat(m) {
    if (!m) return "Materiaal";
    const publicName = String(
      m.publicName || m.displayName || m.productName || m.decorName || "",
    ).trim();
    return publicName || "Materiaal";
  }

  function materialKey(mat) {
    // Prefer stable identifiers
    const k = (mat && (mat.articleNumber || mat.id || mat.decorName || mat.productName)) || "";
    return String(k).trim() || "mat_" + Math.random().toString(36).slice(2, 8);
  }

  return Object.freeze({
    materialLabelMat,
    norm,
    materialKey,
  });
}
