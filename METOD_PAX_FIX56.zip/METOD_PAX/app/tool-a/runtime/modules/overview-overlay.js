/** overview-overlay: one runtime owner with explicit, immutable dependency ports. */
export function createOverviewOverlay({
  applicationState,
  configurationState,
  edgePresentation,
  edgeValues,
  extraEditor,
  extraOverlay,
  extraPreview,
  feedback,
  formatting,
  foundation,
  grainData,
  materialIdentity,
  materialMetadata,
  panelElements,
  panelLabels,
  panelList,
  wizardNavigation,
} = {}) {
  let overviewBound = false,
    footerCaptureBound = false,
    extraCloseCaptureBound = false;

  function ensureOverviewEls() {
    if (
      typeof panelElements.overviewOverlay === "undefined" ||
      !panelElements.overviewOverlay
    )
      panelElements.overviewOverlay = document.getElementById("overviewOverlay");
    if (
      typeof panelElements.overviewCloseBtn === "undefined" ||
      !panelElements.overviewCloseBtn
    )
      panelElements.overviewCloseBtn = document.getElementById("overviewCloseBtn");
    if (
      typeof panelElements.overviewBackBtn === "undefined" ||
      !panelElements.overviewBackBtn
    )
      panelElements.overviewBackBtn = document.getElementById("overviewBackBtn");
    if (
      typeof panelElements.overviewNextBtn === "undefined" ||
      !panelElements.overviewNextBtn
    )
      panelElements.overviewNextBtn = document.getElementById("overviewNextBtn");
    if (typeof panelElements.overviewTabs === "undefined" || !panelElements.overviewTabs)
      panelElements.overviewTabs = document.getElementById("overviewTabs");
    if (
      typeof panelElements.overviewContent === "undefined" ||
      !panelElements.overviewContent
    )
      panelElements.overviewContent = document.getElementById("overviewContent");
    if (typeof panelElements.overviewEmpty === "undefined" || !panelElements.overviewEmpty)
      panelElements.overviewEmpty = document.getElementById("overviewEmpty");
    if (
      typeof panelElements.overviewTabHint === "undefined" ||
      !panelElements.overviewTabHint
    )
      panelElements.overviewTabHint = document.getElementById("overviewTabHint");
    if (
      typeof panelElements.overviewSummary === "undefined" ||
      !panelElements.overviewSummary
    )
      panelElements.overviewSummary = document.getElementById("overviewSummary");

    // Bind once (elements are created later in DOM, so we bind lazily here)
    if (!overviewBound && panelElements.overviewCloseBtn && panelElements.overviewBackBtn) {
      overviewBound = true;
      panelElements.overviewCloseBtn.addEventListener("click", () => {
        closeOverview();
      });
      panelElements.overviewBackBtn.addEventListener(
        "click",
        (ev) => {
          ev.preventDefault();
          ev.stopPropagation();
          navigateOverviewBack();
        },
        true,
      );
    }
  }

  function openOverview() {
    {
      // Force overview footer buttons to be clickable even if other layers mess with pointer-events
      ensureOverviewEls && ensureOverviewEls();
      const foot = document.querySelector("#overviewOverlay .modalFoot");
      if (foot) {
        foot.style.pointerEvents = "auto";
        foot.style.zIndex = "10050";
        foot.style.position = "relative";
      }
      const b1 = document.getElementById("overviewBackBtn");
      const b2 = document.getElementById("overviewNextBtn");
      [b1, b2].forEach((b) => {
        if (b) {
          b.style.pointerEvents = "auto";
          b.style.zIndex = "10060";
          b.style.position = "relative";
        }
      });
    }

    ensureOverviewEls();
    {
      const raw = String(
        window.__metod_uiStep || document.body?.dataset?.uiStep || "customer",
      );
      window.__overviewReturnStep =
        raw === "material" || raw === "panels" || raw === "grain" || raw === "customer"
          ? raw
          : "customer";
    }
    if (!panelElements.overviewOverlay) return;
    renderOverviewSafe();
    panelElements.setOverlayVisible("overviewOverlay", true);
  }

  function closeOverview() {
    ensureOverviewEls();
    if (!panelElements.overviewOverlay) return;
    panelElements.setOverlayVisible("overviewOverlay", false);
  }

  function navigateOverviewBack() {
    closeOverview();
    {
      const raw = String(
        window.__overviewReturnStep ||
          window.__metod_uiStep ||
          document.body?.dataset?.uiStep ||
          "customer",
      );
      const ret =
        raw === "material" || raw === "panels" || raw === "grain" || raw === "customer"
          ? raw
          : "customer";
      if (typeof window.__showWizardStep === "function") window.__showWizardStep(ret);
      else if (typeof wizardNavigation.setStep === "function") wizardNavigation.setStep(ret);
      if (typeof window.renderFooterForStep === "function") window.renderFooterForStep(ret);
    }
  }

  function renderOverview() {
    configurationState.ensureStateShape();
    if (!panelElements.overviewTabs || !panelElements.overviewContent) return;

    // Default tab state when opening
    if (!applicationState.current.ui) applicationState.current.ui = {};
    if (!applicationState.current.ui.overviewTab) {
      applicationState.current.ui.overviewTab = "all"; // material | all | fronts
    }
    if (
      applicationState.current.ui.overviewTab === "material" &&
      !applicationState.current.ui.overviewMaterialKey
    ) {
      applicationState.current.ui.overviewMaterialKey =
        applicationState.current.activeMaterialKey ||
        ((applicationState.current.materialBatches || [])[0]
          ? (applicationState.current.materialBatches || [])[0].key
          : null);
    }

    // ----- Tabs -----
    const batches = applicationState.current.materialBatches || [];
    const chips = [];

    function chipHtml(label, active, attrs) {
      const at = Object.entries(attrs || {})
        .map(([k, v]) => ` ${k}="${formatting._esc(String(v))}"`)
        .join("");
      return `<button type="button" class="chip ${active ? "chipActive" : ""}"${at}>
        <span class="chipDot ${active ? "" : "tool-runtime-muted"}"></span>
        <span class="chipTxt">${formatting._esc(label)}</span>
      </button>`;
    }

    // "Alle onderdelen" (alles)
    chips.push(
      chipHtml("Alle onderdelen", applicationState.current.ui.overviewTab === "all", {
        "data-otab": "all",
      }),
    );

    // Material chips
    for (const b of batches) {
      const title =
        b && b.mat
          ? materialIdentity.materialLabelMat(b.mat)
          : materialMetadata.materialLabel(b.key);
      const active =
        applicationState.current.ui.overviewTab === "material" &&
        applicationState.current.ui.overviewMaterialKey === b.key;
      chips.push(
        chipHtml(title, active, {
          "data-otab": "material",
          "data-mkey": b.key,
        }),
      );
    }

    panelElements.overviewTabs.innerHTML = `<div class="chipRow">${chips.join("")}</div>`;

    panelElements.overviewTabs.querySelectorAll("[data-otab]").forEach((b) => {
      b.addEventListener("click", () => {
        const tab = b.getAttribute("data-otab");
        const mk = b.getAttribute("data-mkey");
        applicationState.current.ui.overviewTab = tab;
        if (tab === "material" && mk) {
          applicationState.current.ui.overviewMaterialKey = mk;
        }
        renderOverviewSafe();
      });
    });

    // ----- Content builders -----
    function rowHtml(title, meta, delCb) {
      const id = "del_" + Math.random().toString(36).slice(2, 10);
      // We'll bind events after insertion
      return {
        html: `
        <div class="cardItem overviewRow">
          <div class="overviewRowMain">
            <div class="overviewRowTitle">${formatting._esc(title)}</div>
            <div class="muted overviewRowMeta">${meta}</div>
          </div>
          <div class="overviewRowActions">
            <button class="miniBtn overviewRemoveBtn u-border-warning" data-delid="${id}">Verwijder</button>
          </div>
        </div>`,
        id,
        delCb,
      };
    }

    const bindings = [];

    function addCartItem(it, idx) {
      const meta = `${it.cmW}×${it.cmH} cm · aantal ${parseInt(it.qty, 10) || 1} · verlenging: +${it.extTop} boven / +${it.extBot} onder · kantenband: ${edgeValues.edgeHWText(it.edge || "all")}`;
      const r = rowHtml(
        panelLabels.overviewTitleWithMeta(
          it,
          it.customName?.trim()
            ? it.customName.trim()
            : it.name || it.label || it.dxf || "Paneel",
        ),
        meta,
        () => {
          foundation.current?.removePanel?.({
            state: applicationState.current,
            id: it.id,
            hooks: {
              renderCart: panelList.renderCart,
              renderExtraPanels: extraEditor.renderExtraPanels,
              drawExtraPreview: extraPreview.drawExtraPreview,
              scheduleDraftSave: feedback.scheduleDraftSave,
              renderOverview: renderOverviewSafe,
            },
          });
        },
      );
      bindings.push(r);
      return r.html;
    }

    function addExtraPanel(p, idx) {
      const title =
        p.name && String(p.name).trim()
          ? String(p.name).trim()
          : `Overig paneel ${p.w}×${p.h}`;
      const edgeTxt = edgePresentation.edgeCustomerText(p.edge, Number(p.w), Number(p.h));
      const meta = `${p.w}×${p.h} mm · aantal ${parseInt(p.qty, 10) || 1}${p.edge ? ` · kantenband: ${edgeTxt}` : ""}`;
      const r = rowHtml(panelLabels.overviewExtraTitleWithMeta(p, title), meta, () => {
        foundation.current?.removeExtraPanel?.({
          state: applicationState.current,
          index: idx,
          hooks: {
            clearAllGrainAssignments: grainData.clearAllGrainAssignments,
            renderExtraPanels: extraEditor.renderExtraPanels,
            drawExtraPreview: extraPreview.drawExtraPreview,
            scheduleDraftSave: feedback.scheduleDraftSave,
            renderOverview: renderOverviewSafe,
          },
        });
      });
      bindings.push(r);
      return r.html;
    }

    function renderSection(header, innerHtml) {
      return `<div class="overviewSection">
        <div class="overviewSectionTitle">${formatting._esc(header)}</div>
        <div class="list overviewList">${innerHtml}</div>
      </div>`;
    }

    // ----- Render content based on active tab -----
    const tab = applicationState.current.ui.overviewTab;
    let out = "";
    let shown = 0;

    if (tab === "material") {
      const mk = applicationState.current.ui.overviewMaterialKey;
      const b = (applicationState.current.materialBatches || []).find((x) => x.key === mk);
      const title =
        b && b.mat ? materialIdentity.materialLabelMat(b.mat) : String(mk || "Materiaal");
      if (panelElements.overviewTabHint)
        panelElements.overviewTabHint.textContent = `Je bekijkt alleen panelen voor: ${title}`;

      const cartItems = (applicationState.current.cart || []).filter(
        (it) => String(it.materialKey || "") === String(mk || ""),
      );
      const extraItems = (applicationState.current.extraPanels || []).filter(
        (p) => String(p.materialKey || "") === String(mk || ""),
      );

      const cartHtml = cartItems
        .map((it, i) =>
          addCartItem(
            it,
            (applicationState.current.cart || []).findIndex((x) => x.id === it.id),
          ),
        )
        .join("");
      const extraHtml = extraItems
        .map((p, i) =>
          addExtraPanel(
            p,
            (applicationState.current.extraPanels || []).findIndex((x) => x === p),
          ),
        )
        .join("");

      let inner = "";
      if (cartItems.length) {
        inner += renderSection("METOD deuren & ladefronten", cartHtml);
        shown += cartItems.length;
      }
      if (extraItems.length) {
        inner += renderSection("Overige panelen", extraHtml);
        shown += extraItems.length;
      }
      if (inner) {
        out += `<div class="overviewGroupCard">
          <div class="overviewGroupHeader"><div class="overviewGroupTitle">${formatting._esc(title)}</div></div>
          ${inner}
        </div>`;
      }
    } else if (tab === "all") {
      if (panelElements.overviewTabHint)
        panelElements.overviewTabHint.textContent =
          "Je bekijkt alle materialen in één overzicht.";
      // Group by materialKey
      const groups = new Map();
      function grp(k) {
        const kk = String(k || "");
        if (!groups.has(kk)) groups.set(kk, { cart: [], extra: [] });
        return groups.get(kk);
      }
      (applicationState.current.cart || []).forEach((it) =>
        grp(it.materialKey).cart.push(it),
      );
      (applicationState.current.extraPanels || []).forEach((p) =>
        grp(p.materialKey).extra.push(p),
      );

      // Sort group keys by displayed name
      const keys = Array.from(groups.keys()).sort((a, b) => {
        const an =
          batches.find((x) => x.key === a)?.mat?.productName ||
          batches.find((x) => x.key === a)?.mat?.articleNumber ||
          a;
        const bn =
          batches.find((x) => x.key === b)?.mat?.productName ||
          batches.find((x) => x.key === b)?.mat?.articleNumber ||
          b;
        return String(an).localeCompare(String(bn));
      });

      for (const k of keys) {
        const b = batches.find((x) => x.key === k);
        const gname =
          b && b.mat ? materialIdentity.materialLabelMat(b.mat) : String(k || "Materiaal");
        const g = groups.get(k);
        let inner = "";
        if (g.cart.length) {
          inner += renderSection(
            "METOD deuren & ladefronten",
            g.cart
              .map((it) =>
                addCartItem(
                  it,
                  (applicationState.current.cart || []).findIndex((x) => x.id === it.id),
                ),
              )
              .join(""),
          );
          shown += g.cart.length;
        }
        if (g.extra.length) {
          inner += renderSection(
            "Overige panelen",
            g.extra
              .map((p) =>
                addExtraPanel(
                  p,
                  (applicationState.current.extraPanels || []).findIndex((x) => x === p),
                ),
              )
              .join(""),
          );
          shown += g.extra.length;
        }
        out += `<div class="overviewGroupCard">
          <div class="overviewGroupHeader"><div class="overviewGroupTitle">${formatting._esc(gname)}</div></div>
          ${inner}
        </div>`;
      }
    } else if (tab === "fronts") {
      if (panelElements.overviewTabHint)
        panelElements.overviewTabHint.textContent =
          "Alleen fronten (deuren & ladefronten). Grepen volgen zodra de greeplibrary is aangeleverd.";
      const items = applicationState.current.cart || [];
      if (items.length) {
        out += renderSection(
          "Fronten",
          items
            .map((it) =>
              addCartItem(
                it,
                (applicationState.current.cart || []).findIndex((x) => x.id === it.id),
              ),
            )
            .join(""),
        );
        shown += items.length;
        out += `<div class="help u-margin-top-10">Tip: straks kun je hier per front een greep kiezen + positie (boven/onder) + scharnierkant.</div>`;
      }
    }

    panelElements.overviewContent.innerHTML = out || "";
    if (panelElements.overviewEmpty)
      panelElements.overviewEmpty.style.display = shown ? "none" : "block";

    // Bind delete buttons
    for (const b of bindings) {
      const btn = panelElements.overviewContent.querySelector(`[data-delid="${b.id}"]`);
      if (btn) {
        btn.addEventListener("click", b.delCb);
      }
    }

    if (panelElements.overviewSummary) {
      panelElements.overviewSummary.textContent = "";
      panelElements.overviewSummary.style.display = "none";
    }
  }

  function renderOverviewSafe() {
    try {
      configurationState.ensureStateShape();
      renderOverview();
      window.__TOOLA_OVERVIEW_RENDER_OK = true;
      return true;
    } catch (error) {
      window.__TOOLA_OVERVIEW_RENDER_OK = false;
      const content = document.getElementById("overviewContent");
      if (content)
        content.textContent = "Het overzicht kon niet worden opgebouwd. Herlaad de pagina.";
      ToolAErrors.stop("overview.render", error);
      return false;
    }
  }

  function mount() {
    window.openOverviewOverlay =
      window.openOverviewOverlay ||
      function () {
        const btn = document.getElementById("overviewBtn");
        if (btn) {
          btn.click();
          return;
        }
        const ov = document.getElementById("overviewOverlay");
        if (ov) {
          try {
            panelElements.setOverlayVisible("overviewOverlay", true);
          } catch (_) {
            ov.style.display = "flex";
          }
        }
        wizardNavigation.setStep("overview");
      };

    window.closeOverviewOverlay = window.closeOverviewOverlay || closeOverview;

    document.addEventListener("keydown", (e) => {
      if (e.key !== "Escape") return;
      const ids = ["overviewOverlay", "grainOverlay", "extraOverlay", "restOverlay"];
      for (const id of ids) {
        const ov = document.getElementById(id);
        if (ov && ov.style && ov.style.display !== "none" && ov.style.display !== "") {
          if (id === "overviewOverlay" && window.closeOverviewOverlay)
            window.closeOverviewOverlay();
          ov.style.display = "none";
        }
      }
    });

    {
      const oov = document.getElementById("overviewOverlay");
      if (oov && !oov.__backdropBound) {
        oov.addEventListener("click", (ev) => {
          if (ev.target === oov) {
            try {
              if (window.closeOverviewOverlay) window.closeOverviewOverlay();
            } catch (_) {
              oov.style.display = "none";
            }
          }
        });
        oov.__backdropBound = true;
      }
    }
    window.renderOverviewSafe = renderOverviewSafe;
    if (panelElements.overviewBtn)
      panelElements.overviewBtn.addEventListener("click", () => {
        try {
          configurationState.ensureStateShape();
          if (panelElements.overviewBtn.disabled) return;
          window.__overviewReturnStep = String(
            window.__metod_uiStep || document.body?.dataset?.uiStep || "panels",
          );
          openOverview();
        } catch (err) {
          console.error(err);
          feedback.flashWarn(err && err.message ? err.message : "Kon overzicht niet openen");
        }
      });
    if (!footerCaptureBound) {
      footerCaptureBound = true;
      document.addEventListener(
        "click",
        function (ev) {
          const t =
            ev.target && ev.target.closest ? ev.target.closest("#overviewBackBtn") : null;
          if (!t) return;
          ev.preventDefault();
          ev.stopPropagation();

          if (t.id === "overviewBackBtn") {
            navigateOverviewBack();
          }
        },
        true,
      );
    }
    if (!extraCloseCaptureBound) {
      extraCloseCaptureBound = true;
      document.addEventListener(
        "click",
        function (ev) {
          const t =
            ev.target && ev.target.closest
              ? ev.target.closest("#extraCloseBtn, #extraDoneBtn")
              : null;
          if (!t) return;
          ev.preventDefault();
          ev.stopPropagation();
          extraOverlay.closeExtraOverlay();
        },
        true,
      );
    }
    document.addEventListener("DOMContentLoaded", () => {
      try {
        // Extra panels overlay
        panelElements.ensureOverlayEls();
        if (panelElements.extraCloseBtn && !panelElements.extraCloseBtn.__bound) {
          panelElements.extraCloseBtn.addEventListener(
            "click",
            extraOverlay.closeExtraOverlay,
          );
          panelElements.extraCloseBtn.__bound = true;
        }
        if (panelElements.extraDoneBtn && !panelElements.extraDoneBtn.__bound) {
          panelElements.extraDoneBtn.addEventListener(
            "click",
            extraOverlay.closeExtraOverlay,
          );
          panelElements.extraDoneBtn.__bound = true;
        }

        // Overview/quote overlay
        ensureOverviewEls();
        if (panelElements.overviewCloseBtn && !panelElements.overviewCloseBtn.__bound) {
          panelElements.overviewCloseBtn.addEventListener("click", closeOverview);
          panelElements.overviewCloseBtn.__bound = true;
        }
        if (panelElements.overviewBackBtn && !panelElements.overviewBackBtn.__bound) {
          panelElements.overviewBackBtn.addEventListener("click", () => {
            navigateOverviewBack();
          });
          panelElements.overviewBackBtn.__bound = true;
        }
        if (panelElements.overviewOverlay && !panelElements.overviewOverlay.__bound) {
          panelElements.overviewOverlay.addEventListener("click", (e) => {
            configurationState.ensureStateShape();
            if (e.target === panelElements.overviewOverlay) closeOverview();
          });
          panelElements.overviewOverlay.__bound = true;
        }
      } catch (err) {
        console.warn("DOMContentLoaded overlay bind failed", err);
      }
    });
  }

  return Object.freeze({
    closeOverview,
    renderOverviewSafe,
    renderOverview,
    ensureOverviewEls,
    navigateOverviewBack,
    openOverview,
    mount,
  });
}
