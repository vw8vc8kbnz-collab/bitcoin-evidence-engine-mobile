/** template-export: one runtime owner with explicit, immutable dependency ports. */
export function createTemplateExport({
  applicationState,
  dxfExport,
  priceBar,
  templateCatalog,
} = {}) {
  let _DXF_TEXT_CACHE;
  let _DXF_TEXT_PROMISE_CACHE;
  let _DXF_CLASSIFIED_PAIR_CACHE;
  let _DXF_TRANSFORMED_TEXT_CACHE;

  function cloneDxfPairs(pairs) {
    return Array.isArray(pairs) ? pairs.map((p) => [p[0], p[1]]) : [];
  }

  async function getDxfTextByName(srcName) {
    if (!srcName) throw new Error("DXF sourceName missing");
    if (Object.prototype.hasOwnProperty.call(_DXF_TEXT_CACHE, srcName))
      return _DXF_TEXT_CACHE[srcName];
    if (_DXF_TEXT_PROMISE_CACHE[srcName]) return _DXF_TEXT_PROMISE_CACHE[srcName];
    return await templateCatalog._fetchEmbedDXF(srcName);
  }

  async function ensureClassifiedDxfSource(srcName) {
    if (_DXF_CLASSIFIED_PAIR_CACHE.has(srcName)) return _DXF_CLASSIFIED_PAIR_CACHE.get(srcName);
    const base = await getDxfTextByName(srcName);
    if (!base) return [];
    const pairs = dxfExport.dxfToPairs(base);
    dxfExport.classifyAndRelayer(pairs);
    _DXF_CLASSIFIED_PAIR_CACHE.set(srcName, pairs);
    return pairs;
  }

  async function getClassifiedDxfPairs(srcName) {
    // Callers transform their copy; the immutable cached source is never mutated.
    return cloneDxfPairs(await ensureClassifiedDxfSource(srcName));
  }

  async function yieldPayloadProgressPaint() {
    // Yield measured work to Safari; the timer covers throttled animation frames.
    await new Promise((resolve) => {
      const fallback = setTimeout(resolve, 48);
      requestAnimationFrame(() =>
        setTimeout(() => {
          clearTimeout(fallback);
          resolve();
        }, 0),
      );
    });
  }

  async function prewarmDxfSourcesForItems(items) {
    const names = [];
    const seen = new Set();
    for (const it of items || []) {
      const t = applicationState.current.templates.get(it?.templateId);
      const n = String(t?.sourceName || "").trim();
      if (n && !seen.has(n)) {
        seen.add(n);
        names.push(n);
      }
    }
    if (!names.length) return;
    let next = 0,
      done = 0,
      lastPaintedPct = -1;
    const total = names.length;
    async function worker() {
      while (true) {
        const i = next++;
        if (i >= total) return;
        // Prewarm only parses/classifies. Do not allocate and immediately discard a
        // deep clone; the real build obtains exactly one private transform copy.
        await ensureClassifiedDxfSource(names[i]);
        done++;
        {
          const pct = Math.min(2, Math.max(0, Math.round((done / total) * 2)));
          priceBar.updatePriceBar({
            busy: true,
            progressPct: pct,
            progressLabel: `DXF-bronnen voorbereiden ${done}/${total}…`,
          });
          if (pct > lastPaintedPct) {
            lastPaintedPct = pct;
            await yieldPayloadProgressPaint();
          }
        }
      }
    }
    await Promise.all(Array.from({ length: Math.min(4, total) }, () => worker()));
  }

  async function buildDxfForMetodItem(it) {
    const t = applicationState.current.templates.get(it.templateId);
    if (!t) return null;
    const srcName = String(t.sourceName || "");
    const hinge = String(it.hinge || "left");
    const extTop = Number(it.extTop || 0);
    const extBot = Number(it.extBot || 0);
    const cacheKey = JSON.stringify([srcName, hinge, extTop, extBot]);
    if (_DXF_TRANSFORMED_TEXT_CACHE.has(cacheKey)) return _DXF_TRANSFORMED_TEXT_CACHE.get(cacheKey);
    const pairs = await getClassifiedDxfPairs(srcName);
    if (!pairs.length) return null;

    // 1) Apply hinge (customer view) if needed
    if (hinge === "right") dxfExport.mirrorX(pairs);
    // 2) Apply extension to OUTLINE only (holes stay)
    dxfExport.extendOutlineY(pairs, extTop, extBot);
    // 3) Export mirror for B-side machining (always)
    dxfExport.mirrorX(pairs);

    const out = dxfExport.pairsToDxf(pairs);
    _DXF_TRANSFORMED_TEXT_CACHE.set(cacheKey, out);
    return out;
  }

  function initialize() {
    _DXF_TEXT_CACHE =
      window.__TOOLA_DXF_TEXT_CACHE || (window.__TOOLA_DXF_TEXT_CACHE = Object.create(null));
    _DXF_TEXT_PROMISE_CACHE =
      window.__TOOLA_DXF_TEXT_PROMISE_CACHE ||
      (window.__TOOLA_DXF_TEXT_PROMISE_CACHE = Object.create(null));
    _DXF_CLASSIFIED_PAIR_CACHE =
      window.__TOOLA_DXF_CLASSIFIED_PAIR_CACHE ||
      (window.__TOOLA_DXF_CLASSIFIED_PAIR_CACHE = new Map());
    _DXF_TRANSFORMED_TEXT_CACHE =
      window.__TOOLA_DXF_TRANSFORMED_TEXT_CACHE ||
      (window.__TOOLA_DXF_TRANSFORMED_TEXT_CACHE = new Map());
  }

  return Object.freeze({
    yieldPayloadProgressPaint,
    prewarmDxfSourcesForItems,
    buildDxfForMetodItem,
    get _DXF_TEXT_CACHE() {
      return _DXF_TEXT_CACHE;
    },
    get _DXF_TEXT_PROMISE_CACHE() {
      return _DXF_TEXT_PROMISE_CACHE;
    },
    get _DXF_CLASSIFIED_PAIR_CACHE() {
      return _DXF_CLASSIFIED_PAIR_CACHE;
    },
    get _DXF_TRANSFORMED_TEXT_CACHE() {
      return _DXF_TRANSFORMED_TEXT_CACHE;
    },
    cloneDxfPairs,
    getDxfTextByName,
    ensureClassifiedDxfSource,
    getClassifiedDxfPairs,
    initialize,
  });
}
