/** authoritative-price: one runtime owner with explicit, immutable dependency ports. */
export function createAuthoritativePrice({ applicationState, jobClient, progressView } = {}) {
  let VAT_RATE;
  let priceGeneration;
  let priceReadSequence;

  function canonicalPriceJobId(value) {
    return String(value || "")
      .trim()
      .split("__mat_")[0];
  }

  function __metodInvalidateAuthoritativePriceHydration() {
    priceGeneration = (priceGeneration || 0) + 1;
    return priceGeneration;
  }

  function validatedPriceTotal(summary) {
    const value = summary?.totalInclVat;
    if (typeof value !== "number" && typeof value !== "string") return null;
    if (typeof value === "string" && !value.trim()) return null;
    const total = Number(value);
    return Number.isFinite(total) && total >= 0 ? total : null;
  }

  function _authoritativePriceInclVat(source) {
    {
      const direct =
        source?.pricingSummary?.totalInclVat ??
        source?.priceInclVat ??
        applicationState.current?.lastPricingSummary?.totalInclVat ??
        applicationState.current?.quote?.total_incl_vat ??
        applicationState.current?.quote?.totalInclVat ??
        applicationState.current?.lastQuote?.grandTotalInclVat ??
        applicationState.current?.lastQuote?.totalInclVat ??
        null;
      if (direct != null && Number.isFinite(Number(direct))) return Number(direct);
    }
    {
      const q =
        source?.quote ||
        applicationState.current?.lastQuote ||
        applicationState.current?.quote ||
        null;
      const inclDirect =
        q?.grandTotalInclVat ??
        q?.totalInclVat ??
        q?.inclVatTotal ??
        q?.totals?.grandTotalInclVat ??
        q?.totals?.totalInclVat ??
        null;
      if (inclDirect != null && Number.isFinite(Number(inclDirect))) return Number(inclDirect);
      const base = q?.totals?.grandTotal ?? q?.totals?.total ?? q?.total ?? q?.grandTotal ?? null;
      if (base != null && Number.isFinite(Number(base))) return Number(base) * (1 + VAT_RATE);
    }
    return null;
  }

  function _isAuthoritativePricingPending() {
    if (window.__metod_submit_done || window.__metod_submit_inflight) return false;
    if (window.__metodBusySince) return true;
    if (progressView.isMetodProgressVisible()) return true;

    return false;
  }

  function _strictAuthoritativePriceInclVat(source) {
    {
      const finalCurrent = _getFinalAuthoritativePriceForCurrentJob();
      if (finalCurrent != null && Number.isFinite(Number(finalCurrent)))
        return Number(finalCurrent);
      if (_isAuthoritativePricingPending()) return null;
      const currentJobId = String(_currentAuthoritativeJobId() || "").trim();
      const validatedKey = String(window.__metod_price_validated_key || "").trim();
      const requiresValidation = !!currentJobId;
      const isValidatedForCurrentJob =
        requiresValidation && validatedKey === `authoritative:${currentJobId}`;
      if (requiresValidation && !isValidatedForCurrentJob) return null;
      const direct =
        source?.pricingSummary?.totalInclVat ??
        source?.lastPricingSummary?.totalInclVat ??
        applicationState.current?.lastPricingSummary?.totalInclVat ??
        applicationState.current?.lastJobResult?.pricingSummary?.totalInclVat ??
        null;
      if (direct != null && Number.isFinite(Number(direct))) return Number(direct);
    }
    return null;
  }

  function _currentAuthoritativeJobId() {
    try {
      const raw = String(
        (applicationState.current && applicationState.current.activeAuthoritativeJobId) ||
          window.__metod_active_parent_job_id ||
          window.__metod_last_parent_job_id ||
          window.__metod_last_job_id ||
          applicationState.current?.lastParentJobId ||
          applicationState.current?.lastJobId ||
          applicationState.current?.jobId ||
          "",
      ).trim();
      if (!raw) return "";
      return raw.includes("__mat_") ? raw.split("__mat_")[0] : raw;
    } catch (_) {
      return "";
    }
  }

  function _setFinalAuthoritativePrice(jobId, pricingSummary) {
    const jid = canonicalPriceJobId(jobId || _currentAuthoritativeJobId());
    const total = validatedPriceTotal(pricingSummary);
    if (!jid || jid !== _currentAuthoritativeJobId() || total == null) return false;
    const state = applicationState.current;
    const result = Object.assign({}, state.lastJobResult || {}, {
      pricingSummary,
    });
    // Every successful commit supersedes older reads, including reads of the
    // same job. Shell and runtime use this one commit boundary.
    __metodInvalidateAuthoritativePriceHydration();
    state.finalAuthoritativeJobId = jid;
    state.finalAuthoritativePriceInclVat = total;
    state.lastPricingSummary = pricingSummary;
    state.lastJobResult = result;
    state.authoritativePricingReady = true;
    window.__metod_price_validated_key = `authoritative:${jid}`;
    return true;
  }

  function _getFinalAuthoritativePriceForCurrentJob() {
    try {
      if (_isAuthoritativePricingPending()) return null;
      const currentJobId = String(_currentAuthoritativeJobId() || "").trim();
      const finalJobId = String(applicationState.current?.finalAuthoritativeJobId || "").trim();
      const total = applicationState.current?.finalAuthoritativePriceInclVat;
      if (!currentJobId || !finalJobId || currentJobId !== finalJobId) return null;
      if (total == null || !Number.isFinite(Number(total))) return null;
      return Number(total);
    } catch (_) {
      return null;
    }
  }

  async function _hydrateAuthoritativePricingSummary(jobId, force) {
    try {
      const jid = canonicalPriceJobId(jobId || _currentAuthoritativeJobId());
      if (!jid || jid !== _currentAuthoritativeJobId()) return null;
      const validatedKey = `authoritative:${jid}`;
      const current = _strictAuthoritativePriceInclVat({
        pricingSummary: applicationState.current?.lastPricingSummary || null,
      });
      const alreadyValidated = String(window.__metod_price_validated_key || "") === validatedKey;
      if (!force && alreadyValidated && current != null && Number.isFinite(Number(current)))
        return applicationState.current?.lastPricingSummary || null;
      const state = applicationState.current;
      const generation = priceGeneration || 0;
      const sequence = (priceReadSequence = (priceReadSequence || 0) + 1);
      const token =
        applicationState.current?.lastJobAccessToken || window.__metod_last_job_access_token || "";
      const ps = await jobClient
        .r9JobsOwner()
        .fetchJobPricingSummary({ jobId: jid, accessToken: token });
      if (
        state !== applicationState.current ||
        generation !== (priceGeneration || 0) ||
        sequence !== priceReadSequence ||
        jid !== _currentAuthoritativeJobId()
      )
        return null;
      return _setFinalAuthoritativePrice(jid, ps) ? ps : null;
    } catch (_) {
      return null;
    }
  }

  function initialize() {
    VAT_RATE = 0.21;
  }

  return Object.freeze({
    _setFinalAuthoritativePrice,
    _hydrateAuthoritativePricingSummary,
    _strictAuthoritativePriceInclVat,
    _getFinalAuthoritativePriceForCurrentJob,
    get VAT_RATE() {
      return VAT_RATE;
    },
    _authoritativePriceInclVat,
    _isAuthoritativePricingPending,
    _currentAuthoritativeJobId,
    __metodInvalidateAuthoritativePriceHydration,
    initialize,
  });
}
