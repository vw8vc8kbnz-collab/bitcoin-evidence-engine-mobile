import { ToolATypeSizeDecisions } from "../../domain/type-size-decisions.js";
/** template-catalog: one runtime owner with explicit, immutable dependency ports. */
export function createTemplateCatalog({
  applicationState,
  feedback,
  formatting,
  materialSelectionView,
  panelElements,
  panelPreview,
  panelTypes,
  selectionState,
  templateInventory,
  templateLoadState,
  templateParser,
  wizardNavigation,
} = {}) {
  let EMBED_DXF_FILES;
  let EMBED_DXF_COUNT;
  let EMBED_DXF_VERSION;
  let embeddedManifestPromise;
  let _EMBED_DXF_META_VERSION;
  let _EMBED_DXF_REFRESHING;
  let TOOLA_DXF_FETCH_TIMEOUT_MS;

  function templateLoadError(message) {
    const error = new Error(message);
    error.userFacing = true;
    return error;
  }

  async function readTemplateResource(url, format, timeoutMs = TOOLA_DXF_FETCH_TIMEOUT_MS) {
    const controller = typeof AbortController === "function" ? new AbortController() : null;
    let timer;
    const deadline = new Promise((_, reject) => {
      timer = setTimeout(() => {
        try {
          controller?.abort();
        } catch (_) {
          ToolAErrors.recover("tool.a.runtime.modules.template.catalog.js.1", _, [
            "AbortError",
            "InvalidStateError",
          ]);
        }
        reject(
          templateLoadError(
            "Laden duurt te lang. Controleer je verbinding en probeer opnieuw.",
          ),
        );
      }, timeoutMs);
    });
    try {
      // DXFs are mutable Admin data. A retry must reach the server rather than
      // reusing a cached error page, redirect or an earlier file revision.
      const response = await Promise.race([
        fetch(url, {
          cache: "no-store",
          credentials: "same-origin",
          ...(controller ? { signal: controller.signal } : {}),
        }),
        deadline,
      ]);
      if (!response.ok) {
        throw templateLoadError(
          response.status === 404
            ? "Paneelbestand niet gevonden. Herlaad de pagina om de actuele lijst op te halen."
            : `Server tijdelijk niet bereikbaar (HTTP ${response.status || "onbekend"}). Probeer opnieuw.`,
        );
      }
      if (
        format === "text" &&
        /(?:text\/html|application\/(?:json|problem\+json))/i.test(
          response.headers?.get("Content-Type") || "",
        )
      ) {
        throw templateLoadError("De server stuurde geen DXF-bestand. Probeer opnieuw.");
      }
      return await Promise.race([
        format === "json" ? response.json() : response.text(),
        deadline,
      ]);
    } catch (error) {
      if (error?.userFacing) throw error;
      throw templateLoadError(
        "Paneelgegevens konden niet worden opgehaald. Controleer je verbinding en probeer opnieuw.",
      );
    } finally {
      clearTimeout(timer);
    }
  }

  async function _loadEmbedManifest() {
    if (embeddedManifestPromise) return embeddedManifestPromise;
    if (EMBED_DXF_FILES) return EMBED_DXF_FILES;
    embeddedManifestPromise = (async () => {
      const man = await readTemplateResource("/embedded_dxfs_manifest.json", "json");
      if (
        !Array.isArray(man?.files) ||
        !man.files.every(
          (name) => typeof name === "string" && name.toLowerCase().endsWith(".dxf"),
        )
      )
        throw new Error("Ongeldige paneelcatalogus.");
      EMBED_DXF_FILES = man.files;
      EMBED_DXF_COUNT = EMBED_DXF_FILES.length;
      {
        const mj = await readTemplateResource(
          `/api/dxf_manifest_meta?ts=${Date.now()}`,
          "json",
          4000,
        );
        EMBED_DXF_VERSION = mj && mj.version !== undefined ? mj.version : EMBED_DXF_VERSION;
      }
      if (!applicationState.current.embedIndex) applicationState.current.embedIndex = {};
      for (const nm of EMBED_DXF_FILES) {
        const tid = templateParser.makeTemplateId(String(nm));
        if (!applicationState.current.embedIndex[tid])
          applicationState.current.embedIndex[tid] = String(nm);
      }
      {
        const bc = document.getElementById("builtinCount");
        if (bc) bc.textContent = String(EMBED_DXF_COUNT);
      }
      templateInventory.rebuildCatalogFromTemplates(EMBED_DXF_FILES);
      panelTypes.updateTypeOptions();
      return EMBED_DXF_FILES;
    })();
    try {
      return await embeddedManifestPromise;
    } finally {
      embeddedManifestPromise = null;
    }
  }

  async function refreshEmbeddedDxfCatalogNow() {
    if (_EMBED_DXF_REFRESHING) return;
    _EMBED_DXF_REFRESHING = true;
    const previousFiles = EMBED_DXF_FILES;
    const previousVersion = EMBED_DXF_VERSION;
    try {
      // Force manifest reload + rebuild catalog
      EMBED_DXF_FILES = null;
      await _loadEmbedManifest();
      return true;
    } catch (error) {
      EMBED_DXF_FILES = previousFiles;
      EMBED_DXF_VERSION = previousVersion;
      if (!error?.userFacing) throw error;
      ToolAErrors.recover("catalog.dxf.refresh", error, ["Error"]);
      return false;
    } finally {
      _EMBED_DXF_REFRESHING = false;
    }
  }

  async function _fetchEmbedDXF(name) {
    const textCache = window.__TOOLA_DXF_TEXT_CACHE;
    const promiseCache = window.__TOOLA_DXF_TEXT_PROMISE_CACHE;
    if (Object.prototype.hasOwnProperty.call(textCache, name)) return textCache[name];
    if (promiseCache[name]) return promiseCache[name];
    promiseCache[name] = (async () => {
      const url =
        "/embedded_dxfs/" + String(name).split("/").map(encodeURIComponent).join("/");
      const text = await readTemplateResource(url, "text");
      textCache[name] = text;
      return text;
    })();
    try {
      return await promiseCache[name];
    } finally {
      delete promiseCache[name];
    }
  }

  async function ensureTemplateLoadedById(templateId) {
    if (!templateId) return null;
    if (
      applicationState.current &&
      applicationState.current.templates &&
      applicationState.current.templates.has(templateId)
    )
      return applicationState.current.templates.get(templateId);

    let filename = null;

    if (
      applicationState.current &&
      applicationState.current.embedIndex &&
      applicationState.current.embedIndex[templateId]
    )
      filename = applicationState.current.embedIndex[templateId];

    if (!filename) {
      await _loadEmbedManifest();
      filename = applicationState.current.embedIndex?.[templateId] || null;
    }
    if (!filename) {
      // fallback search in catalog
      {
        const all = [].concat(
          Object.values(applicationState.current.catalog || {}).flatMap((list) =>
            Array.isArray(list) ? list : [],
          ),
        );
        const hit = all.find((x) => String(x.templateId) === String(templateId));
        if (hit) filename = hit.fileName || hit.sourceName || null;
      }
    }
    if (!filename) throw new Error("Paneelbestand ontbreekt in de catalogus.");

    // Fetch + parse
    const txt = await _fetchEmbedDXF(filename);
    let t;
    try {
      const meta = templateParser.parseMetaFromFilename(filename);
      const geom = templateParser.parseDXFMinimal(txt);
      if (
        ![geom.lwpolys, geom.polys, geom.lines].some(
          (items) => Array.isArray(items) && items.length,
        )
      ) {
        throw templateLoadError(
          "Paneelbestand bevat geen leesbare contour. Laat dit bestand in Admin controleren.",
        );
      }
      t = templateParser.buildTemplate(filename, meta, geom);
      if (
        t?.id !== templateId ||
        ![t.realW, t.realH].every((value) => Number.isFinite(value) && value > 0)
      ) {
        throw templateLoadError(
          "Paneelbestand bevat ongeldige afmetingen. Laat dit bestand in Admin controleren.",
        );
      }
    } catch (error) {
      delete window.__TOOLA_DXF_TEXT_CACHE[filename];
      throw error;
    }
    applicationState.current.templates.set(t.id, t);
    return t;
  }

  function setTemplateLoadStatus(status, error = null) {
    const box = document.getElementById("templateLoadStatus");
    const message = document.getElementById("templateLoadMessage");
    const retry = document.getElementById("templateLoadRetry");
    if (box) {
      box.hidden = status !== "loading" && status !== "error";
      box.dataset.status = status;
    }
    if (message)
      message.textContent =
        status === "loading"
          ? "Paneel laden…"
          : error?.userFacing
            ? error.message
            : "Paneel kon niet worden geladen. Probeer opnieuw.";
    if (retry) retry.hidden = status !== "error";
    panelPreview.draw();
    materialSelectionView.updateButtons();
    wizardNavigation.renderFooterForStep(document.body.dataset.uiStep || "material");
  }

  function loadSelectedPanelTemplate() {
    const id = String(applicationState.current.selection.templateId || "");
    if (!id) {
      templateLoadState.selectedTemplateLoad = null;
      setTemplateLoadStatus("idle");
      return Promise.resolve(null);
    }
    if (
      templateLoadState.selectedTemplateLoad?.id === id &&
      templateLoadState.selectedTemplateLoad.status === "loading"
    )
      return templateLoadState.selectedTemplateLoad.promise;
    if (applicationState.current.templates.has(id)) {
      templateLoadState.selectedTemplateLoad = {
        id,
        status: "ready",
        promise: null,
      };
      setTemplateLoadStatus("ready");
      return Promise.resolve(applicationState.current.templates.get(id));
    }
    const request = { id, status: "loading", promise: null };
    templateLoadState.selectedTemplateLoad = request;
    setTemplateLoadStatus("loading");
    request.promise = (async () => {
      try {
        // A previous background request may have failed. Retry once on an explicit selection.
        let template;
        try {
          template = await ensureTemplateLoadedById(id);
        } catch (firstError) {
          if (
            templateLoadState.selectedTemplateLoad !== request ||
            applicationState.current.selection.templateId !== id
          )
            return null;
          template = await ensureTemplateLoadedById(id);
        }
        if (
          templateLoadState.selectedTemplateLoad !== request ||
          applicationState.current.selection.templateId !== id
        )
          return null;
        if (!template) throw new Error("Paneelbestand ontbreekt.");
        request.status = "ready";
        setTemplateLoadStatus("ready");
        window.__refreshCustomLabelVisibility?.();
        return template;
      } catch (error) {
        if (
          templateLoadState.selectedTemplateLoad === request &&
          applicationState.current.selection.templateId === id
        ) {
          request.status = "error";
          setTemplateLoadStatus("error", error);
          console.warn("Panel template load failed", id, error);
        }
        return null;
      }
    })();
    return request.promise;
  }

  function templateDropdownDisplayName(item) {
    try {
      const raw = String(item?.sourceName || item?.fileName || item?.label || "").trim();
      const base = raw.split(/[\\/]/).pop() || raw;
      return base.replace(/\.dxf$/i, "").trim() || base || raw;
    } catch (_) {
      return "";
    }
  }

  function populateSizeDropdown() {
    panelTypes.syncDefaultPanelTypeSelection();
    const type = applicationState.current.selection.type;
    if (panelElements.typeSel && panelElements.typeSel.value !== type)
      panelElements.typeSel.value = type || "";
    panelElements.sizeSel.innerHTML = '<option value="">— Kies maat —</option>';

    let groups = [];
    try {
      if (
        ToolATypeSizeDecisions &&
        typeof ToolATypeSizeDecisions.getSizeOptionGroups === "function"
      ) {
        groups =
          ToolATypeSizeDecisions.getSizeOptionGroups(applicationState.current, type) || [];
      }
    } catch (_) {
      groups = [];
    }
    if (!Array.isArray(groups) || !groups.length) {
      const list = applicationState.current.catalog[type] || [];
      if (type === "special") {
        const kinds = formatting.groupBy(list, (x) => x.kind);
        groups = Object.keys(kinds)
          .sort()
          .map((kind) => ({
            label: kind,
            items: (kinds[kind] || []).map((item) => ({
              templateId: item.templateId,
              label: templateDropdownDisplayName(item),
              raw: item,
            })),
          }));
      } else {
        const widthGroups = formatting.groupBy(list, (x) => x.cmW);
        groups = Object.keys(widthGroups)
          .map(Number)
          .sort((a, b) => a - b)
          .map((cmW) => ({
            label: `Breedte ${cmW} cm`,
            items: (widthGroups[String(cmW)] || [])
              .slice()
              .sort((a, b) => a.cmH - b.cmH)
              .map((item) => ({
                templateId: item.templateId,
                label: templateDropdownDisplayName(item),
                raw: item,
              })),
          }));
      }
    }

    for (const group of groups) {
      const og = document.createElement("optgroup");
      og.label = String(group?.label || "").trim() || "Maten";
      for (const item of Array.isArray(group?.items) ? group.items : []) {
        const opt = document.createElement("option");
        opt.value = String(item?.templateId || "").trim();
        opt.textContent =
          templateDropdownDisplayName(item) || String(item?.label || "").trim();
        og.appendChild(opt);
      }
      panelElements.sizeSel.appendChild(og);
    }

    let preferredTemplateId = "";
    try {
      if (
        ToolATypeSizeDecisions &&
        typeof ToolATypeSizeDecisions.getPreferredTemplateId === "function"
      ) {
        preferredTemplateId = String(
          ToolATypeSizeDecisions.getPreferredTemplateId(
            applicationState.current,
            type,
            applicationState.current.selection.templateId,
          ) || "",
        ).trim();
      }
    } catch (_) {
      preferredTemplateId = "";
    }

    if (preferredTemplateId) {
      selectionState.update({ templateId: preferredTemplateId });
      panelElements.sizeSel.value = preferredTemplateId;
    } else if (!applicationState.current.selection.templateId) {
      const first = panelElements.sizeSel.querySelector('option[value]:not([value=""])');
      if (first) {
        first.selected = true;
        selectionState.update({ templateId: first.value });
      }
    } else {
      panelElements.sizeSel.value = applicationState.current.selection.templateId;
    }

    loadSelectedPanelTemplate();

    let uiState = null;
    try {
      if (
        ToolATypeSizeDecisions &&
        typeof ToolATypeSizeDecisions.getTypeSizeUiState === "function"
      ) {
        uiState = ToolATypeSizeDecisions.getTypeSizeUiState(
          applicationState.current,
          type,
          applicationState.current.selection.templateId,
        );
      }
    } catch (_) {
      uiState = null;
    }
    panelElements.hingeSel.disabled = uiState
      ? !uiState.hingeEnabled
      : type !== "deur" && type !== "pax_deur";
    panelElements.addBtn.disabled = uiState
      ? !uiState.hasTemplate
      : !applicationState.current.selection.templateId;
  }

  function mount() {
    setTimeout(() => {
      _loadEmbedManifest().catch((error) => console.warn("DXF catalog load failed", error));
    }, 50);
    setTimeout(() => {
      feedback.updateWizardBanner();
    }, 200);
    EMBED_DXF_FILES = null;
    EMBED_DXF_COUNT = 0;
    EMBED_DXF_VERSION = null;
    embeddedManifestPromise = null;
    _EMBED_DXF_META_VERSION = null;
    _EMBED_DXF_REFRESHING = false;
    window.__TOOLA_DXF_TEXT_CACHE = window.__TOOLA_DXF_TEXT_CACHE || Object.create(null);
    window.__TOOLA_DXF_TEXT_PROMISE_CACHE =
      window.__TOOLA_DXF_TEXT_PROMISE_CACHE || Object.create(null);
    window.__TOOLA_DXF_CLASSIFIED_PAIR_CACHE =
      window.__TOOLA_DXF_CLASSIFIED_PAIR_CACHE || new Map();
    window.__TOOLA_DXF_TRANSFORMED_TEXT_CACHE =
      window.__TOOLA_DXF_TRANSFORMED_TEXT_CACHE || new Map();

    TOOLA_DXF_FETCH_TIMEOUT_MS = 20000;
    templateLoadState.selectedTemplateLoad = null;
  }

  return Object.freeze({
    _fetchEmbedDXF,
    get EMBED_DXF_FILES() {
      return EMBED_DXF_FILES;
    },
    get EMBED_DXF_VERSION() {
      return EMBED_DXF_VERSION;
    },
    set EMBED_DXF_VERSION(value) {
      EMBED_DXF_VERSION = value;
    },
    _loadEmbedManifest,
    refreshEmbeddedDxfCatalogNow,
    ensureTemplateLoadedById,
    loadSelectedPanelTemplate,
    populateSizeDropdown,
    mount,
  });
}
