import { ToolAPanelsEntry } from "../../adapters/panels-entrypoints.js";
import { ToolACoreSelectors } from "../../domain/core-selectors.js";
import { ToolARouteState } from "../../domain/route-state.js";
import { ToolAShowStepApply } from "../../domain/showstep-apply.js";
/** wizard-navigation: one runtime owner with explicit, immutable dependency ports. */
export function createWizardNavigation({
  applicationState,
  customerForm,
  customerValidation,
  domLookup,
  foundation,
  materialCatalog,
  overlayControls,
  panelBootstrap,
  panelControls,
  panelDock,
  panelElements,
  panelForm,
  panelList,
  panelTypes,
  panelsProjection,
} = {}) {
  let stepOrder;
  let stepLabelMap;
  let footerInner;
  let rightScroll;
  let __rightScrollLockTop;
  let __rightAnchorEl;
  let __rightAnchorTop;
  let btnPrev;
  let btnNext;
  let btnOverview;
  let stepbar;
  let ovClose;
  let ovBack;
  let ovCalc;

  function updateMobileStepMeta(step) {
    {
      const idx = stepOrder.indexOf(step);
      const indexEl = document.getElementById("mobileStepIndex");
      const nameEl = document.getElementById("mobileStepName");
      if (indexEl)
        indexEl.textContent = `Stap ${idx > -1 ? idx + 1 : 1} / ${stepOrder.length}`;
      if (nameEl) nameEl.textContent = stepLabelMap[step] || "Materiaal";
    }
  }

  function setStep(step) {
    {
      const bar = document.getElementById("stepbar");
      if (!bar) return;
      const idx = stepOrder.indexOf(step);
      bar.querySelectorAll(".step").forEach((el) => {
        const s = el.getAttribute("data-step");
        const i = stepOrder.indexOf(s);
        el.classList.remove("active", "done");
        if (i === idx) el.classList.add("active");
        else if (i > -1 && idx > -1 && i < idx) el.classList.add("done");
      });
    }

    // Step pages (right column)
    // Some steps are full-screen overlays (grain/overview). Those do not have a
    // matching .stepPage. If we blindly toggle all pages off, the right column
    // becomes empty. Only switch pages when a matching stepPage exists.
    {
      const target = document.querySelector(`.stepPage[data-step="${step}"]`);
      if (target) {
        document.querySelectorAll(".stepPage").forEach((p) => {
          const s = p.getAttribute("data-step");
          p.classList.toggle("active", s === step);
        });
      }
    }

    // Persist current UI step for overlays/overview return
    window.__metod_uiStep = step;
    document.body.dataset.uiStep = step;
    updateMobileStepMeta(step);
    document.body.dataset.mobileSheet =
      step === "material" ? "peek" : step === "panels" ? "expanded" : "expanded";
  }

  function lockRightScroll(anchorEl = null) {
    if (rightScroll) __rightScrollLockTop = rightScroll.scrollTop;
    __rightAnchorEl = anchorEl || document.activeElement || null;
    __rightAnchorTop =
      __rightAnchorEl && __rightAnchorEl.getBoundingClientRect
        ? __rightAnchorEl.getBoundingClientRect().top
        : null;
  }

  function restoreRightScroll() {
    if (rightScroll && __rightScrollLockTop != null) {
      rightScroll.scrollTop = __rightScrollLockTop;
    }
    if (
      rightScroll &&
      __rightAnchorEl &&
      __rightAnchorTop != null &&
      document.contains(__rightAnchorEl)
    ) {
      const nowTop = __rightAnchorEl.getBoundingClientRect().top;
      const delta = nowTop - __rightAnchorTop;
      if (Number.isFinite(delta) && Math.abs(delta) > 0.5) {
        rightScroll.scrollTop += delta;
      }
    }
  }

  function stabilizeRightScroll(frames = 8, anchorEl = null) {
    lockRightScroll(anchorEl);
    let n = Math.max(1, Number(frames) || 1);
    const tick = () => {
      restoreRightScroll();
      n -= 1;
      if (n > 0) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }

  function hasMaterialSelected() {
    try {
      const st =
        typeof applicationState.current !== "undefined"
          ? applicationState.current
          : window.state || {};
      const mat = st.material || {};
      return !!(
        st.activeMaterialKey ||
        mat.materialCode ||
        mat.articleNumber ||
        mat.decorName ||
        mat.productName
      );
    } catch (_) {
      return false;
    }
  }

  function hasPanels() {
    try {
      const view = panelsProjection.r9PanelsView();
      if (view && typeof view.hasPanels === "boolean") return view.hasPanels;
      const st =
        typeof applicationState.current !== "undefined"
          ? applicationState.current
          : window.state || {};
      return !!(
        st &&
        ((st.cart && st.cart.length) || (st.extraPanels && st.extraPanels.length))
      );
    } catch (_) {
      return false;
    }
  }

  function closeOverview() {
    if (window.closeOverviewOverlay) window.closeOverviewOverlay();
    else overlayControls.closeOverlay("overview");
  }

  function openOverview() {
    if (window.openOverviewOverlay) window.openOverviewOverlay();
    else overlayControls.openOverlay("overview");
  }

  function closeGrain() {
    if (window.closeGrainOverlay) window.closeGrainOverlay();
    else overlayControls.closeOverlay("grain");
  }

  function openGrain() {
    if (window.openGrainOverlay) window.openGrainOverlay();
    else overlayControls.openOverlay("grain");
  }

  function renderFooterForStep(step) {
    try {
      const owner = foundation.current;
      if (!owner || typeof owner.renderWizardFooter !== "function") return null;
      const snapshot =
        ToolACoreSelectors && typeof ToolACoreSelectors.getWizardSnapshot === "function"
          ? ToolACoreSelectors.getWizardSnapshot()
          : null;
      const result = owner.renderWizardFooter({
        step,
        snapshot,
        footerInner,
        existing: { prev: btnPrev, next: btnNext, overview: btnOverview },
        addInline: panelForm.addInline,
        showStep: showStep,
        getCurrentStep: () => window.__metod_uiStep || "material",
        getOverviewReturnStep: () => window.__overviewReturnStep || "customer",
        hasMaterialSelected: hasMaterialSelected,
        hasPanels: hasPanels,
        validateCustomerStepRequired: customerValidation.validateCustomerStepRequired,
        commitCustomerCalculationSnapshot: customerForm.commitCustomerCalculationSnapshot,
      });
      btnPrev = result?.prev || btnPrev;
      btnNext = result?.next || btnNext;
      btnOverview = result?.overview || btnOverview;
      return result || null;
    } catch (_) {
      return null;
    }
  }

  function showStep(step) {
    let __routePlan = null;
    try {
      if (ToolARouteState && typeof ToolARouteState.getShowStepPlan === "function") {
        __routePlan = ToolARouteState.getShowStepPlan({
          requestedStep: step,
          prevStep: (() => {
            try {
              return window.__metod_uiStep || null;
            } catch (_) {
              return null;
            }
          })(),
          priceLocked: !!window.__metod_price_locked,
        });
      }
    } catch (_) {
      __routePlan = null;
    }
    step =
      __routePlan?.requestedStep ||
      (ToolARouteState && typeof ToolARouteState.normalizeStep === "function"
        ? ToolARouteState.normalizeStep(step)
        : ["material", "panels", "grain", "customer", "overview"].includes(step)
          ? step
          : "material");
    if (
      step === "material" &&
      typeof materialCatalog.refreshMaterialCatalogLive === "function"
    ) {
      materialCatalog.refreshMaterialCatalogLive({
        reRenderStep1: true,
        refreshSuggest: true,
      });
    }
    // If a price has been calculated, the flow is locked: customers can only
    // send the configuration or cancel (reset). No navigation back into the wizard.
    try {
      if ((__routePlan && __routePlan.blockedByPriceLock) || window.__metod_price_locked) {
        return;
      }
    } catch (_) {
      if (window.__metod_price_locked) {
        return;
      }
    }
    const prevStep =
      (__routePlan && __routePlan.prevStep) ||
      (() => {
        try {
          return window.__metod_uiStep || null;
        } catch (_) {
          return null;
        }
      })();
    const sameStep = !!((__routePlan && __routePlan.sameStep) || prevStep === step);
    // Commit before routing. This catches Safari autofill/change cases even when
    // no input event fired and prevents a later render from restoring stale data.
    if (prevStep === "customer" && step !== "customer") {
      customerForm.readCustomerFromUI();
    }
    let prevRightScrollTop = 0;
    if (rightScroll) prevRightScrollTop = rightScroll.scrollTop || 0;

    // Remember the dock state before leaving the panels step, so returning from
    // Nerf via Annuleren/X restores the same "Mijn panelen" state instead of
    // visually dropping the whole panel list.
    {
      const __rememberDock =
        (__routePlan && __routePlan.shouldRememberDockBeforeLeave) ||
        (prevStep === "panels" && step !== "panels");
      if (__rememberDock) {
        window.__panelDockWasOpenBeforeRoute = !!(
          panelElements.panelDockDrawer && !panelElements.panelDockDrawer.hidden
        );
      }
    }

    // Remember where we came from when opening the Overzicht overlay.
    // This makes the overlay return to the step it was opened from.
    if (step === "overview") {
      try {
        window.__overviewReturnStep =
          (__routePlan && __routePlan.overviewReturnStep) || "customer";
      } catch (_) {
        window.__overviewReturnStep = "customer";
      }
    }

    // close result overlay (unless locked)
    try {
      if (!window.__metod_price_locked) overlayControls.closePriceOverlay();
    } catch (_) {
      overlayControls.closePriceOverlay();
    }

    if (ToolAShowStepApply && typeof ToolAShowStepApply.execute === "function") {
      const __handled = ToolAShowStepApply.execute({
        step,
        prevStep,
        sameStep,
        prevRightScrollTop,
        routePlan: __routePlan || null,
        rightScroll: typeof rightScroll !== "undefined" ? rightScroll : null,
        state:
          typeof applicationState.current !== "undefined" ? applicationState.current : null,
        panelDock:
          typeof panelElements.panelDock !== "undefined" ? panelElements.panelDock : null,
        panelDockLauncher:
          typeof panelElements.panelDockLauncher !== "undefined"
            ? panelElements.panelDockLauncher
            : null,
        typeSel: typeof panelElements.typeSel !== "undefined" ? panelElements.typeSel : null,
        sizeSel: typeof panelElements.sizeSel !== "undefined" ? panelElements.sizeSel : null,
        closeGrain: typeof closeGrain === "function" ? closeGrain : null,
        closeOverview: typeof closeOverview === "function" ? closeOverview : null,
        setStep: typeof setStep === "function" ? setStep : null,
        renderFooterForStep:
          typeof renderFooterForStep === "function" ? renderFooterForStep : null,
        syncPanelDockChrome:
          typeof panelList.syncPanelDockChrome === "function"
            ? panelList.syncPanelDockChrome
            : null,
        ensureCustomLabelHook:
          typeof panelForm.ensureCustomLabelHook === "function"
            ? panelForm.ensureCustomLabelHook
            : null,
        refreshCustomLabelVisibility:
          typeof window.__refreshCustomLabelVisibility === "function"
            ? window.__refreshCustomLabelVisibility
            : null,
        syncDefaultPanelTypeSelection:
          typeof panelTypes.syncDefaultPanelTypeSelection === "function"
            ? panelTypes.syncDefaultPanelTypeSelection
            : null,
        enableControlsIfReady:
          typeof panelControls.enableControlsIfReady === "function"
            ? panelControls.enableControlsIfReady
            : null,
        bootstrapPanelSelectionForActiveMaterial:
          typeof panelBootstrap.bootstrapPanelSelectionForActiveMaterial === "function"
            ? panelBootstrap.bootstrapPanelSelectionForActiveMaterial
            : null,
        setPanelDockOpen:
          typeof panelDock.setPanelDockOpen === "function"
            ? panelDock.setPanelDockOpen
            : null,
        stabilizeRightScroll:
          typeof stabilizeRightScroll === "function" ? stabilizeRightScroll : null,
        openGrain: typeof openGrain === "function" ? openGrain : null,
        openOverview: typeof openOverview === "function" ? openOverview : null,
      });
      if (__handled && __handled.didOpenStepOverlay) {
        return;
      }
    } else {
      // close overlays not relevant
      if (step !== "grain") closeGrain();
      if (step !== "overview") closeOverview();

      // base UI step & pages
      setStep(step);
      renderFooterForStep(step);
      panelList.syncPanelDockChrome();
      if (step === "panels") {
        if (ToolAPanelsEntry && typeof ToolAPanelsEntry.onEnterPanelsStep === "function") {
          ToolAPanelsEntry.onEnterPanelsStep(prevStep);
        }
      }

      if (rightScroll) {
        if (sameStep) {
          rightScroll.scrollTop = prevRightScrollTop;
          stabilizeRightScroll(14);
        } else if (
          (__routePlan && __routePlan.shouldResetRightScroll) ||
          step === "material" ||
          step === "panels" ||
          step === "customer"
        ) {
          rightScroll.scrollTop = 0;
        }
      }

      if (step === "grain") {
        openGrain();
        return;
      }
      if (step === "overview") {
        openOverview();
        return;
      }
    }
  }

  function bindFooterOwner() {
    try {
      const owner = foundation.current;
      if (
        !owner ||
        typeof owner.renderWizardFooter !== "function" ||
        typeof owner.bindOverviewFooter !== "function"
      )
        return false;
      renderFooterForStep(window.__metod_uiStep || "material");
      owner.bindOverviewFooter({
        closeBtn: ovClose,
        backBtn: ovBack,
        closeOverview: closeOverview,
        showStep: showStep,
        getOverviewReturnStep: () => window.__overviewReturnStep || "customer",
      });
      return true;
    } catch (_) {
      return false;
    }
  }

  function initialize() {
    stepOrder = ["material", "panels", "grain", "customer", "overview"];
    stepLabelMap = {
      material: "Materiaal kiezen",
      panels: "Panelen toevoegen",
      grain: "Nerf",
      customer: "Gegevens",
      overview: "Overzicht",
    };
    document.addEventListener("DOMContentLoaded", () => {
      {
        const cur = window.__metod_uiStep || "material";
        document.body.dataset.mobileSheet =
          cur === "material" ? "peek" : cur === "panels" ? "expanded" : "expanded";
      }
      updateMobileStepMeta(window.__metod_uiStep || "material");
      const handle = document.getElementById("mobileSheetHandle");
      if (handle && !handle.__bound) {
        handle.addEventListener("click", () => {
          {
            if (window.innerWidth > 700) return;
            const curStep = document.body.dataset.uiStep || "material";
            if (curStep !== "material" && curStep !== "panels") return;
            document.body.dataset.mobileSheet =
              document.body.dataset.mobileSheet === "peek" ? "expanded" : "peek";
          }
        });
        handle.__bound = true;
      }
    });
  }

  function connect() {
    footerInner = domLookup.byId("wizardFooterInner");
    rightScroll = domLookup.byId("rightScroll");

    window.addEventListener(
      "resize",
      function () {
        if (window.__panelKeyboardActive) return;
        if (typeof panelList.updatePanelDockSizing === "function")
          panelList.updatePanelDockSizing();
      },
      { passive: true },
    );
    window.addEventListener(
      "orientationchange",
      function () {
        if (typeof panelList.updatePanelDockSizing === "function")
          panelList.updatePanelDockSizing();
      },
      { passive: true },
    );
    setTimeout(function () {
      if (typeof panelList.updatePanelDockSizing === "function")
        panelList.updatePanelDockSizing();
    }, 0);

    __rightScrollLockTop = null;
    __rightAnchorEl = null;
    __rightAnchorTop = null;

    if (rightScroll && !rightScroll.__stabilityBound) {
      rightScroll.addEventListener(
        "mousedown",
        (e) => {
          // Only lock for normal content clicks, not scrollbar drags.
          try {
            const r = rightScroll.getBoundingClientRect();
            if (e.clientX < r.right - 24)
              lockRightScroll(
                e.target?.closest?.(
                  'button,.btn,.choice,.chip,.matChosen,.cardItem,.item,.apple-select,.apple-select-btn,[role="button"]',
                ) || e.target,
              );
          } catch (_) {
            lockRightScroll(e.target);
          }
        },
        true,
      );
      rightScroll.addEventListener(
        "click",
        (e) => {
          {
            const anchor = e.target?.closest?.(
              'button,.btn,.choice,.chip,.matChosen,.cardItem,.item,.apple-select,.apple-select-btn,[role="button"]',
            );
            if (anchor) stabilizeRightScroll(10, anchor);
          }
        },
        true,
      );
      rightScroll.addEventListener(
        "focusin",
        (e) => {
          if (window.__panelKeyboardActive) return;
          stabilizeRightScroll(4, e.target);
        },
        true,
      );
      rightScroll.__stabilityBound = true;
    }
  }

  function connect2() {
    window.renderFooterForStep = renderFooterForStep;
    stepbar = domLookup.byId("stepbar");
    if (stepbar && !stepbar.__bound) {
      stepbar.addEventListener("click", (e) => {
        const el = e.target.closest(".step");
        if (!el) return;
        const s = el.getAttribute("data-step");
        let target = null;
        try {
          if (ToolARouteState && typeof ToolARouteState.getStepbarTarget === "function") {
            target = ToolARouteState.getStepbarTarget(s, {
              hasMaterial: hasMaterialSelected(),
              hasPanels: hasPanels(),
            });
          }
        } catch (_) {
          target = null;
        }
        if (target) return showStep(target);
      });
      stepbar.__bound = true;
    }
    ovClose = domLookup.byId("overviewCloseBtn");
    ovBack = domLookup.byId("overviewBackBtn");
    ovCalc = domLookup.byId("overviewNextBtn");
    if (!bindFooterOwner()) {
      document.addEventListener("tool-a-footer-owner-ready", bindFooterOwner, {
        once: true,
      });
    }
  }

  return Object.freeze({
    showStep,
    setStep,
    get byId() {
      return domLookup.byId;
    },
    lockRightScroll,
    stabilizeRightScroll,
    renderFooterForStep,
    get stepOrder() {
      return stepOrder;
    },
    get stepLabelMap() {
      return stepLabelMap;
    },
    updateMobileStepMeta,
    initialize,
    connect,
    connect2,
  });
}
