/** template-load-state: one runtime owner with explicit, immutable dependency ports. */
export function createTemplateLoadState({} = {}) {
  let selectedTemplateLoad;

  return Object.freeze({
    get selectedTemplateLoad() {
      return selectedTemplateLoad;
    },
    set selectedTemplateLoad(value) {
      selectedTemplateLoad = value;
    },
  });
}
