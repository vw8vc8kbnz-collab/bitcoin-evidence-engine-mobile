/** panel-editor-binding: one runtime owner with explicit, immutable dependency ports. */
export function createPanelEditorBinding({
  extraEditor,
  extraPreview,
  foundation,
  panelControls,
  panelDock,
  panelEdges,
  panelElements,
} = {}) {
  function bindNativePanelEditor() {
    const owner = foundation.current;
    if (!owner || typeof owner.bindPanelEditor !== "function") return false;
    return owner.bindPanelEditor({
      standardAddButton: panelElements.addBtn,
      extraAddButton: panelElements.addExtraBtn,
      getStandardSubmitInput: panelControls.getStandardPanelSubmitInput,
      prepareStandardSubmit: panelControls.prepareStandardPanelSubmitInput,
      onStandardSubmit: (result) => {
        // Complete the form/navigation update before optional visual feedback.
        document.dispatchEvent(
          new CustomEvent("tool-a:standard-panel-submitted", {
            detail: { ok: result?.ok === true, mode: result?.mode || "" },
          }),
        );
        if (result?.ok === true && result.mode !== "edit")
          panelDock.pulsePanelDock("Paneel toegevoegd aan Mijn panelen.");
      },
      onStandardSubmitBusy: (busy) =>
        document.dispatchEvent(new CustomEvent("tool-a:standard-panel-busy", { detail: { busy } })),
      getExtraSubmitInput: extraEditor.getExtraPanelSubmitInput,
      extraPreviewInputs: [
        panelElements.extraW,
        panelElements.extraH,
        panelElements.extraMat,
        panelElements.extraEdgeTop,
        panelElements.extraEdgeBottom,
        panelElements.extraEdgeLeft,
        panelElements.extraEdgeRight,
      ],
      extraNameInput: panelElements.extraName,
      extraEdgeInputs: [
        panelElements.extraEdgeTop,
        panelElements.extraEdgeBottom,
        panelElements.extraEdgeLeft,
        panelElements.extraEdgeRight,
      ],
      drawExtraPreview: extraPreview.drawExtraPreview,
      syncExtraEdges: panelEdges.syncSelectFromChecks,
    });
  }

  function mount() {
    document.addEventListener("tool-a-panel-editor-owner-ready", bindNativePanelEditor, {
      once: true,
    });
    bindNativePanelEditor();
  }

  return Object.freeze({
    mount,
  });
}
