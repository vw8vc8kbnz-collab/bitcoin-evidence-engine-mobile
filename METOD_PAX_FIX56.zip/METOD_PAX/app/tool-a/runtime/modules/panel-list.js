import { ToolAPanelDockState } from "../../domain/panel-dock-state.js";
import { ToolAPanelEditContext } from "../../domain/panel-edit-context.js";
import { ToolAPanelRowViewModels } from "../../domain/panel-row-view-models.js";
import { ToolAPanelsViewModels } from "../../domain/panels-view-models.js";
/** panel-list: one runtime owner with explicit, immutable dependency ports. */
export function createPanelList({
  applicationState,
  edgePresentation,
  extraPreview,
  feedback,
  formatting,
  foundation,
  grainData,
  grainStatus,
  materialIdentity,
  materialMetadata,
  panelDock,
  panelEdges,
  panelEditSession,
  panelElements,
  panelForm,
  panelIntents,
  panelPreview,
  priceBar,
  viewRefresh,
} = {}) {
  function updatePanelDockSizing() {
    {
      if (!panelElements.panelDockDrawer || !panelElements.panelDock) return;
      const leftPane = document.querySelector(".left");
      const leftRect = leftPane?.getBoundingClientRect?.();
      const dockRect = panelElements.panelDock?.getBoundingClientRect?.();
      const viewportW = Math.max(
        document.documentElement.clientWidth || 0,
        window.innerWidth || 0,
      );
      const viewportH = Math.max(
        document.documentElement.clientHeight || 0,
        window.innerHeight || 0,
      );
      const leftWidth = Math.max(0, Math.floor(leftRect?.width || 0));
      const leftHeight = Math.max(0, Math.floor(leftRect?.height || 0));
      const dockLeftInset = Math.max(
        14,
        Math.floor((dockRect?.left || 0) - (leftRect?.left || 0)),
      );
      const rightSafety = 18;
      const availableWidth = Math.max(
        420,
        Math.min(leftWidth - dockLeftInset - rightSafety, viewportW - 56),
      );
      const baseWidth = Math.max(
        460,
        Math.min(availableWidth, Math.round(availableWidth * 0.62)),
      );
      const largeWidth = Math.max(
        baseWidth,
        Math.min(availableWidth, Math.round(availableWidth * 0.76)),
      );
      const xlWidth = Math.max(
        largeWidth,
        Math.min(availableWidth, Math.round(availableWidth * 0.88)),
      );
      const xxlWidth = Math.max(
        xlWidth,
        Math.min(availableWidth, Math.round(availableWidth * 0.98)),
      );

      const bottomInset = 18;
      const topInset = 16;
      const availableHeight = Math.max(
        380,
        Math.min(leftHeight - bottomInset - topInset, viewportH - 48),
      );
      const baseHeight = Math.max(
        460,
        Math.min(availableHeight, Math.round(availableHeight * 0.76)),
      );
      const largeHeight = Math.max(
        baseHeight,
        Math.min(availableHeight, Math.round(availableHeight * 0.86)),
      );
      const xlHeight = Math.max(
        largeHeight,
        Math.min(availableHeight, Math.round(availableHeight * 0.93)),
      );
      const xxlHeight = Math.max(
        xlHeight,
        Math.min(availableHeight, Math.round(availableHeight * 0.985)),
      );

      panelElements.panelDockDrawer.style.setProperty(
        "--panelDockMaxWidth",
        `${Math.round(availableWidth)}px`,
      );
      panelElements.panelDockDrawer.style.setProperty(
        "--panelDockWidth",
        `${Math.round(baseWidth)}px`,
      );
      panelElements.panelDockDrawer.style.setProperty(
        "--panelDockWidthLarge",
        `${Math.round(largeWidth)}px`,
      );
      panelElements.panelDockDrawer.style.setProperty(
        "--panelDockWidthXl",
        `${Math.round(xlWidth)}px`,
      );
      panelElements.panelDockDrawer.style.setProperty(
        "--panelDockWidthXxl",
        `${Math.round(xxlWidth)}px`,
      );
      panelElements.panelDockDrawer.style.setProperty(
        "--panelDockMaxHeight",
        `${Math.round(baseHeight)}px`,
      );
      panelElements.panelDockDrawer.style.setProperty(
        "--panelDockMaxHeightLarge",
        `${Math.round(largeHeight)}px`,
      );
      panelElements.panelDockDrawer.style.setProperty(
        "--panelDockMaxHeightXl",
        `${Math.round(xlHeight)}px`,
      );
      panelElements.panelDockDrawer.style.setProperty(
        "--panelDockMaxHeightXxl",
        `${Math.round(xxlHeight)}px`,
      );
    }
  }

  function syncPanelDockChrome() {
    {
      const cartCount = Array.isArray(applicationState.current?.cart)
        ? applicationState.current.cart.length
        : 0;
      const extraCount = Array.isArray(applicationState.current?.extraPanels)
        ? applicationState.current.extraPanels.reduce(
            (a, p) => a + Math.max(1, Number(p?.qty) || 1),
            0,
          )
        : 0;
      const total = cartCount + extraCount;
      if (panelElements.panelDockCount)
        panelElements.panelDockCount.textContent = String(total);
      if (!total) {
        window.__panelDockWasOpenBeforeRoute = false;
        window.setPanelDockOpen && window.setPanelDockOpen(false);
        if (panelElements.panelDockDrawer) {
          panelElements.panelDockDrawer.hidden = true;
          panelElements.panelDockDrawer.setAttribute("hidden", "hidden");
        }
        if (panelElements.panelDockLauncher)
          panelElements.panelDockLauncher.setAttribute("aria-expanded", "false");
        if (panelElements.panelDock) panelElements.panelDock.classList.remove("is-open");
      }
      if (panelElements.panelDockSub) {
        const cartQty = cartCount;
        const extraQty = extraCount;
        panelElements.panelDockSub.textContent = total
          ? `${total} paneel${total === 1 ? "" : "en"} toegevoegd · ${cartQty} standaard · ${extraQty} overig`
          : "Nog niets toegevoegd.";
      }
      if (panelElements.panelDockEmpty)
        panelElements.panelDockEmpty.style.display = total ? "none" : "block";
      if (panelElements.panelDockList)
        panelElements.panelDockList.style.display = total ? "" : "none";
      if (panelElements.panelDockLauncher) {
        panelElements.panelDockLauncher.style.opacity = total ? "1" : ".96";
      }
      if (panelElements.panelDockDrawer) {
        const visualRows =
          (Array.isArray(applicationState.current?.cart)
            ? panelDock._groupCartDisplayItems(applicationState.current.cart).length
            : 0) +
          (Array.isArray(applicationState.current?.extraPanels)
            ? applicationState.current.extraPanels.length
            : 0);
        panelElements.panelDockDrawer.classList.toggle("is-large", visualRows > 3);
        panelElements.panelDockDrawer.classList.toggle("is-xl", visualRows > 6);
        panelElements.panelDockDrawer.classList.toggle("is-xxl", visualRows > 9);
      }
      updatePanelDockSizing();
      if (panelElements.panelDock && typeof window.__metod_uiStep !== "undefined") {
        panelElements.panelDock.style.display =
          window.__metod_uiStep === "panels" ? "flex" : "none";
      }
      if (panelElements.panelDockTabs) {
        const keys = Array.from(
          new Set(
            [
              ...(applicationState.current?.cart || []).map((it) =>
                String(it?.materialKey || ""),
              ),
              ...(applicationState.current?.extraPanels || []).map((it) =>
                String(it?.materialKey || it?.material || ""),
              ),
            ].filter(Boolean),
          ),
        );
        panelElements.panelDockTabs.style.display = keys.length > 1 ? "block" : "none";
      }
    }
  }

  function panelDockMaterialNameByKey(k) {
    const key = String(k || "").trim();
    const b = (applicationState.current?.materialBatches || []).find(
      (x) => String(x?.key || "") === key,
    );
    if (b && b.mat) return materialIdentity.materialLabelMat(b.mat);
    // Customer-facing mobile/desktop panel context must never expose a raw
    // material key or article identifier when an orphaned legacy row remains.
    return "Materiaal";
  }

  function buildExtraDockRow(p, idx) {
    const model =
      ToolAPanelRowViewModels &&
      typeof ToolAPanelRowViewModels.getExtraRowModel === "function"
        ? ToolAPanelRowViewModels.getExtraRowModel(p, idx, {
            getMaterialLabel: materialMetadata.materialLabelKey,
            getEdgeText: edgePresentation.edgeCustomerText,
          })
        : null;
    const row = document.createElement("div");
    row.className = "panelDockRow panelDockRow--extra";
    row.setAttribute("data-panel-kind", "extra");
    const title = model
      ? model.title
      : String((p?.name || "").trim() || `Overig paneel ${p?.w || 0}×${p?.h || 0}`);
    const line2 = model
      ? model.metaText
      : `${Math.max(1, Number(p?.qty) || 1)}× · ${formatting._esc(`${p?.w || 0}×${p?.h || 0} mm`)} · ${formatting._esc(materialMetadata.materialLabelKey(p?.materialKey || p?.material || ""))} · kantenband: ${formatting._esc(edgePresentation.edgeCustomerText(p?.edge || "none", Number(p?.w || 0), Number(p?.h || 0)))}`;
    const safeLine2 = model ? formatting._esc(String(line2 || "")) : line2;
    row.innerHTML = `
      <div class="panelDockRowMain">
        <div class="panelDockRowTitle">${formatting._esc(title)}</div>
        <div class="panelDockRowMeta">${safeLine2}</div>
      </div>
      <div class="panelDockRowActions">
        <button class="panelDockMini" type="button" data-act="del" title="Verwijder" aria-label="Verwijder ${formatting._esc(title)}">✕</button>
      </div>
    `;
    row.querySelector('[data-act="del"]').addEventListener("click", () => {
      foundation.current?.removeExtraPanel?.({
        state: applicationState.current,
        index: idx,
        editIndex: panelEditSession.extraEditIndex,
        hooks: {
          clearAllGrainAssignments: grainData.clearAllGrainAssignments,
          setEditIndex(v) {
            panelEditSession.extraEditIndex = v;
          },
          renderExtraPanels: viewRefresh.extraPanels,
          renderCart,
          updatePriceBar: priceBar.updatePriceBar,
          syncChecksFromSelect: panelEdges.syncChecksFromSelect,
          drawExtraPreview: extraPreview.drawExtraPreview,
        },
      });
    });
    return row;
  }

  function appendPanelDockSection(title, countText, rows, parent) {
    const mount = parent || panelElements.panelDockList;
    if (!mount || !rows || !rows.length) return;
    const sec = document.createElement("div");
    sec.className = "panelDockSection";
    sec.setAttribute("role", "group");
    sec.setAttribute("aria-label", title);
    const head = document.createElement("div");
    head.className = "panelDockSectionHead";
    head.innerHTML = `<div class="panelDockSectionTitle">${formatting._esc(title)}</div><div class="panelDockSectionCount">${formatting._esc(countText)}</div>`;
    sec.appendChild(head);
    rows.forEach((r) => sec.appendChild(r));
    mount.appendChild(sec);
  }

  function buildCartGroupRow(group) {
    const __editContext =
      ToolAPanelEditContext && typeof ToolAPanelEditContext.getContext === "function"
        ? ToolAPanelEditContext.getContext({
            localTargetId: panelEditSession.panelEditTargetId,
            localGroupKey: panelEditSession.panelEditGroupKey,
            localOriginalCount: panelEditSession.panelEditOriginalCount,
            state: applicationState.current,
          })
        : {
            targetId: panelEditSession.resolvePanelEditTargetId(),
            groupKey: panelEditSession.resolvePanelEditGroupKey(),
            originalCount: panelEditSession.resolvePanelEditOriginalCount(),
            isEditing: !!panelEditSession.resolvePanelEditTargetId(),
          };
    const model =
      ToolAPanelRowViewModels &&
      typeof ToolAPanelRowViewModels.getCartGroupRowModel === "function"
        ? ToolAPanelRowViewModels.getCartGroupRowModel(group, {
            editContext: __editContext,
            grainGroups: applicationState.current?.grain?.groups,
            isEditingGroup: (g, ctx) =>
              ToolAPanelEditContext &&
              typeof ToolAPanelEditContext.isEditingGroup === "function"
                ? ToolAPanelEditContext.isEditingGroup(g, ctx)
                : !!(
                    (ctx.targetId &&
                      g.items.some((x) => String(x?.id || "") === String(ctx.targetId))) ||
                    (ctx.groupKey && String(g.key) === String(ctx.groupKey))
                  ),
          })
        : null;
    const it = group.rep;
    const isEditing = model
      ? !!model.isEditing
      : ToolAPanelEditContext && typeof ToolAPanelEditContext.isEditingGroup === "function"
        ? ToolAPanelEditContext.isEditingGroup(group, __editContext)
        : !!(
            (__editContext.targetId &&
              group.items.some(
                (x) => String(x?.id || "") === String(__editContext.targetId),
              )) ||
            (__editContext.groupKey && String(group.key) === String(__editContext.groupKey))
          );
    const row = document.createElement("div");
    row.className = `panelDockRow panelDockRow--standard${isEditing ? " is-editing" : ""}`;
    row.setAttribute("data-panel-kind", "standard");
    const title = model ? model.title : String(it?.label || "");
    const metaText = model
      ? model.metaText
      : `${Math.max(1, group.items.length)}× · ${formatting._esc(`${it.cmW}×${it.cmH} cm`)}${it.type === "deur" || it.type === "pax_deur" || it.supportsHinge || it.kind === "Hoekkast" ? ` · ${it.hinge === "left" ? "scharnier links" : "scharnier rechts"}` : ""} · verlengen +${it.extTop} / +${it.extBot}`;
    const safeMetaText = model ? formatting._esc(String(metaText || "")) : metaText;
    row.innerHTML = `
      <div class="panelDockRowMain">
        <div class="panelDockRowTitle">${formatting._esc(title)}</div>
        <div class="panelDockRowMeta">${safeMetaText}</div>
        ${isEditing ? '<div class="panelDockRowEditTag">Je bewerkt dit paneel</div>' : ""}
      </div>
      <div class="panelDockRowActions">
        <button class="panelDockMini" type="button" data-act="edit" title="Bewerk 1" aria-label="Bewerk ${formatting._esc(title)}">✎</button>
        <button class="panelDockMini" type="button" data-act="del" title="Verwijder 1" aria-label="Verwijder ${formatting._esc(title)}">✕</button>
      </div>
    `;
    row.querySelector('[data-act="del"]').addEventListener("click", () => {
      const removeId = group.items[0]?.id;
      const __editContext =
        ToolAPanelEditContext && typeof ToolAPanelEditContext.getContext === "function"
          ? ToolAPanelEditContext.getContext({
              localTargetId: panelEditSession.panelEditTargetId,
              localGroupKey: panelEditSession.panelEditGroupKey,
              localOriginalCount: panelEditSession.panelEditOriginalCount,
              state: applicationState.current,
            })
          : {
              targetId: panelEditSession.resolvePanelEditTargetId(),
              groupKey: panelEditSession.resolvePanelEditGroupKey(),
              originalCount: panelEditSession.resolvePanelEditOriginalCount(),
              isEditing: !!panelEditSession.resolvePanelEditTargetId(),
            };
      const isRemovingEdited =
        ToolAPanelEditContext && typeof ToolAPanelEditContext.isRemovingEdited === "function"
          ? ToolAPanelEditContext.isRemovingEdited(removeId, __editContext)
          : !!(
              __editContext.targetId &&
              String(removeId || "") === String(__editContext.targetId)
            );
      foundation.current?.removePanel?.({
        state: applicationState.current,
        id: removeId,
        isRemovingEdited,
        hooks: {
          resetPanelEntryFields: panelForm.resetPanelEntryFields,
          draw: panelPreview.draw,
          renderCart,
          renderExtraPanels: viewRefresh.extraPanels,
          syncChecksFromSelect: panelEdges.syncChecksFromSelect,
          drawExtraPreview: extraPreview.drawExtraPreview,
          scheduleDraftSave: feedback.scheduleDraftSave,
        },
      });
    });
    row
      .querySelector('[data-act="edit"]')
      .addEventListener("click", () => panelIntents.edit(group.items[0]?.id));
    return row;
  }

  function appendInlineMaterialGroup(group) {
    if (!panelElements.cartEl || !group) return;
    const cartEntries = Array.isArray(group.cartEntries) ? group.cartEntries : [];
    const extraEntries = Array.isArray(group.extraEntries) ? group.extraEntries : [];
    const groupedCart = panelDock._groupCartDisplayItems(
      cartEntries.map((entry) => entry?.panel).filter(Boolean),
    );
    const cartRows = groupedCart.map((panelGroup) => buildCartGroupRow(panelGroup));
    const extraRows = extraEntries
      .filter((entry) => entry?.panel && Number.isInteger(entry?.index))
      .map((entry) => buildExtraDockRow(entry.panel, entry.index));
    if (!(cartRows.length || extraRows.length)) return;

    const materialGroup = document.createElement("div");
    materialGroup.className = "panelDockMaterialGroup";
    materialGroup.setAttribute("role", "group");
    materialGroup.setAttribute("aria-label", String(group.materialLabel || "Materiaal"));
    const materialHead = document.createElement("div");
    materialHead.className = "panelDockMaterialHead";
    const materialName = document.createElement("div");
    materialName.className = "panelDockMaterialName";
    materialName.textContent = String(group.materialLabel || "Materiaal");
    const totalQty = Math.max(0, Number(group.totalQtyCount) || 0);
    const materialCount = document.createElement("div");
    materialCount.className = "panelDockMaterialCount";
    materialCount.textContent = `${totalQty} ${totalQty === 1 ? "paneel" : "panelen"}`;
    materialHead.appendChild(materialName);
    materialHead.appendChild(materialCount);
    materialGroup.appendChild(materialHead);

    if (cartRows.length) {
      appendPanelDockSection(
        "Standaard panelen",
        `${Math.max(0, Number(group.standardQtyCount) || 0)} stuks`,
        cartRows,
        materialGroup,
      );
    }
    if (extraRows.length) {
      appendPanelDockSection(
        "Overige panelen",
        `${Math.max(0, Number(group.extraQtyCount) || 0)} stuks`,
        extraRows,
        materialGroup,
      );
    }
    panelElements.cartEl.appendChild(materialGroup);
  }

  function renderInlinePanelList() {
    if (!panelElements.cartEl) return;
    panelElements.cartEl.innerHTML = "";
    const cart = Array.isArray(applicationState.current?.cart)
      ? applicationState.current.cart
      : [];
    const extraPanels = Array.isArray(applicationState.current?.extraPanels)
      ? applicationState.current.extraPanels
      : [];
    const groups =
      ToolAPanelsViewModels &&
      typeof ToolAPanelsViewModels.getPanelMaterialGroups === "function"
        ? ToolAPanelsViewModels.getPanelMaterialGroups(applicationState.current, {
            getMaterialName: panelDockMaterialNameByKey,
          })
        : [
            {
              materialKey: "",
              materialLabel: "Materiaal",
              cartEntries: cart.map((panel, index) => ({ panel, index })),
              extraEntries: extraPanels.map((panel, index) => ({
                panel,
                index,
              })),
              standardQtyCount: cart.reduce(
                (total, panel) => total + Math.max(1, Number(panel?.qty) || 1),
                0,
              ),
              extraQtyCount: extraPanels.reduce(
                (total, panel) => total + Math.max(1, Number(panel?.qty) || 1),
                0,
              ),
              totalQtyCount:
                cart.reduce(
                  (total, panel) => total + Math.max(1, Number(panel?.qty) || 1),
                  0,
                ) +
                extraPanels.reduce(
                  (total, panel) => total + Math.max(1, Number(panel?.qty) || 1),
                  0,
                ),
            },
          ];
    groups.forEach(appendInlineMaterialGroup);
  }

  function renderCart() {
    if (panelElements.panelDockList) panelElements.panelDockList.innerHTML = "";
    const totalCart = Array.isArray(applicationState.current?.cart)
      ? applicationState.current.cart.length
      : 0;
    const totalExtraQty = Array.isArray(applicationState.current?.extraPanels)
      ? applicationState.current.extraPanels.reduce(
          (a, p) => a + Math.max(1, Number(p?.qty) || 1),
          0,
        )
      : 0;
    renderInlinePanelList();
    if (!(totalCart || totalExtraQty)) {
      if (panelElements.cartHelp) {
        panelElements.cartHelp.textContent = "Nog niets toegevoegd.";
        panelElements.cartHelp.style.display = "";
      }
      if (panelElements.overviewBtn)
        panelElements.overviewBtn.disabled = !(
          applicationState.current.cart.length || applicationState.current.extraPanels.length
        );
      if (panelElements.panelDockTabs) panelElements.panelDockTabs.innerHTML = "";
      window.setPanelDockOpen && window.setPanelDockOpen(false);
      syncPanelDockChrome();
      grainStatus.updateGrainBtnState();
      priceBar.updatePriceBar();
      return;
    }
    if (panelElements.cartHelp) {
      panelElements.cartHelp.textContent = "";
      panelElements.cartHelp.style.display = "none";
    }

    // Panel dock filters by material (like overview)
    if (!applicationState.current.ui) applicationState.current.ui = {};
    const __panelDockTabState =
      ToolAPanelDockState && typeof ToolAPanelDockState.getTabState === "function"
        ? ToolAPanelDockState.getTabState(applicationState.current)
        : {
            matKeys: Array.from(
              new Set(
                [
                  ...(applicationState.current.cart || []).map((it) =>
                    String(it?.materialKey || ""),
                  ),
                  ...(applicationState.current.extraPanels || []).map((it) =>
                    String(it?.materialKey || it?.material || ""),
                  ),
                ].filter(Boolean),
              ),
            ),
            panelDockTab: applicationState.current.ui.panelDockTab || "all",
            panelDockMaterialKey: applicationState.current.ui.panelDockMaterialKey || null,
          };
    const matKeys = Array.isArray(__panelDockTabState.matKeys)
      ? __panelDockTabState.matKeys
      : [];
    applicationState.current.ui.panelDockTab = __panelDockTabState.panelDockTab || "all";
    applicationState.current.ui.panelDockMaterialKey =
      __panelDockTabState.panelDockMaterialKey || null;

    if (panelElements.panelDockTabs) {
      const tabModel =
        ToolAPanelsViewModels &&
        typeof ToolAPanelsViewModels.getPanelDockTabModel === "function"
          ? ToolAPanelsViewModels.getPanelDockTabModel(applicationState.current, {
              getMaterialName: panelDockMaterialNameByKey,
            })
          : null;
      const chips = [];
      const chip = (label, active, attrs) => {
        const at = Object.entries(attrs || {})
          .map(([k, v]) => ` ${k}="${formatting._esc(v)}"`)
          .join("");
        return `<button type="button" class="chip ${active ? "chipActive" : ""}"${at}><span class="chipDot ${active ? "" : "tool-runtime-muted"}"></span><span class="chipTxt">${formatting._esc(label)}</span></button>`;
      };
      const chipModels = tabModel
        ? tabModel.chips
        : [
            {
              type: "all",
              label: "Alle onderdelen",
              active: applicationState.current.ui.panelDockTab === "all",
            },
            ...matKeys.map((mk) => ({
              type: "material",
              key: mk,
              label: panelDockMaterialNameByKey(mk),
              active:
                applicationState.current.ui.panelDockTab === "material" &&
                String(applicationState.current.ui.panelDockMaterialKey) === String(mk),
            })),
          ];
      chipModels.forEach((model) => {
        const attrs = { "data-pdock": model.type };
        if (model.key) attrs["data-mkey"] = String(model.key);
        chips.push(chip(model.label, !!model.active, attrs));
      });
      const visible = tabModel ? !!tabModel.visible : matKeys.length > 1;
      panelElements.panelDockTabs.innerHTML = visible
        ? `<div class="chipRow">${chips.join("")}</div>`
        : "";
      panelElements.panelDockTabs.style.display = visible ? "block" : "none";
      panelElements.panelDockTabs.querySelectorAll("[data-pdock]").forEach((btn) => {
        btn.onclick = () => {
          applicationState.current.ui.panelDockTab = btn.getAttribute("data-pdock");
          const mk = btn.getAttribute("data-mkey");
          if (applicationState.current.ui.panelDockTab === "material" && mk)
            applicationState.current.ui.panelDockMaterialKey = mk;
          renderCart();
        };
      });
    }

    if (panelElements.panelDockList) {
      panelElements.panelDockList.innerHTML = "";
      panelElements.panelDockList.classList.remove("is-split");
      if (panelElements.panelDockDrawer)
        panelElements.panelDockDrawer.classList.remove("is-split");
      const __panelDockFiltered =
        ToolAPanelDockState &&
        typeof ToolAPanelDockState.getFilteredCollections === "function"
          ? ToolAPanelDockState.getFilteredCollections(applicationState.current)
          : {
              filteredCart: applicationState.current.cart || [],
              filteredExtraPanels: applicationState.current.extraPanels || [],
            };
      const groupedFiltered = panelDock._groupCartDisplayItems(
        __panelDockFiltered.filteredCart || [],
      );
      const extraFiltered = Array.isArray(__panelDockFiltered.filteredExtraPanels)
        ? __panelDockFiltered.filteredExtraPanels
        : [];
      const __panelDockSectionState =
        ToolAPanelDockState && typeof ToolAPanelDockState.getSectionState === "function"
          ? ToolAPanelDockState.getSectionState(applicationState.current)
          : {
              useSplit: !!(groupedFiltered.length && extraFiltered.length),
              showMaterialHint:
                applicationState.current.ui.panelDockTab === "material" &&
                applicationState.current.ui.panelDockMaterialKey,
            };
      if (
        __panelDockSectionState.showMaterialHint &&
        applicationState.current.ui.panelDockMaterialKey
      ) {
        const matHint = document.createElement("div");
        matHint.className = "panelDockSectionHint";
        matHint.textContent = panelDockMaterialNameByKey(
          applicationState.current.ui.panelDockMaterialKey,
        );
        panelElements.panelDockList.appendChild(matHint);
      }
      const cartRows = groupedFiltered.map((group) => buildCartGroupRow(group));
      const extraRows = extraFiltered.map((p) =>
        buildExtraDockRow(
          p,
          (applicationState.current.extraPanels || []).findIndex((x) => x === p),
        ),
      );
      const useSplit = !!__panelDockSectionState.useSplit;
      let splitLeft = null;
      let splitRight = null;
      if (useSplit) {
        panelElements.panelDockList.classList.add("is-split");
        if (panelElements.panelDockDrawer)
          panelElements.panelDockDrawer.classList.add("is-split");
        splitLeft = document.createElement("div");
        splitLeft.className = "panelDockColumn";
        splitRight = document.createElement("div");
        splitRight.className = "panelDockColumn";
        panelElements.panelDockList.appendChild(splitLeft);
        panelElements.panelDockList.appendChild(splitRight);
      }
      if (cartRows.length)
        appendPanelDockSection(
          "Standaard panelen",
          `${Array.isArray(__panelDockFiltered.filteredCart) ? __panelDockFiltered.filteredCart.length : 0} stuks`,
          cartRows,
          splitLeft || panelElements.panelDockList,
        );
      if (extraRows.length)
        appendPanelDockSection(
          "Overige panelen",
          `${extraFiltered.reduce((a, p) => a + Math.max(1, Number(p?.qty) || 1), 0)} stuks`,
          extraRows,
          splitRight || panelElements.panelDockList,
        );
    }
    syncPanelDockChrome();
    panelForm.setPanelEditMode(
      panelEditSession.panelEditTargetId,
      panelEditSession.panelEditOriginalCount,
      panelEditSession.panelEditGroupKey,
    );
    grainStatus.updateGrainBtnState();
    priceBar.updatePriceBar();
  }

  return Object.freeze({
    syncPanelDockChrome,
    updatePanelDockSizing,
    renderCart,
  });
}
