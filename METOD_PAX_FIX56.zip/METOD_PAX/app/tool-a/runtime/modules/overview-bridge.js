/** overview-bridge: one runtime owner with explicit, immutable dependency ports. */
export function createOverviewBridge({ edgePresentation, overviewOverlay } = {}) {
  function install() {
    window.edgeCustomerText = edgePresentation.edgeCustomerText;
    window._edgeMaskFromValue = edgePresentation._edgeMaskFromValue;
    window.openOverviewOverlay = overviewOverlay.openOverview;
    window.closeOverviewOverlay = overviewOverlay.closeOverview;
  }

  return Object.freeze({
    install,
  });
}
