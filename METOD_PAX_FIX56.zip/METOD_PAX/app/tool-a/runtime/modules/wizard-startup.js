/** wizard-startup: one runtime owner with explicit, immutable dependency ports. */
export function createWizardStartup({ panelForm, panelList, wizardNavigation } = {}) {
  function connect() {
    // Wait for all page owners to mount before opening the first wizard step.
    window.addEventListener(
      "DOMContentLoaded",
      () => {
        setTimeout(() => wizardNavigation.showStep("material"), 0);
      },
      { once: true },
    );
    window.showStep = wizardNavigation.showStep;
    window.__showWizardStep = wizardNavigation.showStep;
    window.__renderWizardFooter = wizardNavigation.renderFooterForStep;
    window.renderFooterForStep = wizardNavigation.renderFooterForStep;
    window.renderCart = panelList.renderCart;
    window.__setPanelEditMode = panelForm.setPanelEditMode;
  }

  return Object.freeze({
    connect,
  });
}
