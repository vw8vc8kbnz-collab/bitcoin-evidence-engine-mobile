/** submission: one runtime owner with explicit, immutable dependency ports. */
export function createSubmission({
  alertDialog,
  applicationState,
  authoritativePrice,
  calculationView,
  customerForm,
  customerSnapshot,
  customerValidation,
  domLookup,
  foundation,
  overlayControls,
  priceBar,
  wizardNavigation,
} = {}) {
  let sendBtn;
  let cancelBtn;
  let CLIENT_MUTATION_DEADLINE_MS;
  let FINAL_SUBMISSION_UNCERTAIN_KEY;

  function _isFinalSubmissionInFlight() {
    try {
      if (window.__metod_submit_inflight === true) return true;
      const nativeState = foundation.current?.getFinalSubmissionState?.();
      return String(nativeState?.status || "").toLowerCase() === "submitting";
    } catch (_) {
      return window.__metod_submit_inflight === true;
    }
  }

  function _uncertainFinalSubmissionParentJobId() {
    {
      const volatileId = String(window.__metod_submit_uncertain_parent_job_id || "").trim();
      if (volatileId) return volatileId;
    }
    try {
      return String(sessionStorage.getItem(FINAL_SUBMISSION_UNCERTAIN_KEY) || "").trim();
    } catch (_) {
      return "";
    }
  }

  function _hasUncertainFinalSubmission() {
    try {
      return (
        window.__metod_submit_commit_uncertain === true ||
        Boolean(_uncertainFinalSubmissionParentJobId())
      );
    } catch (_) {
      return Boolean(_uncertainFinalSubmissionParentJobId());
    }
  }

  function _setFinalSubmissionUncertain(parentJobId, uncertain) {
    const active = uncertain === true;
    const safeParentJobId = String(
      parentJobId || _uncertainFinalSubmissionParentJobId() || "unknown",
    ).trim();

    window.__metod_submit_commit_uncertain = active;
    window.__metod_submit_uncertain_parent_job_id = active ? safeParentJobId : null;

    try {
      if (active) sessionStorage.setItem(FINAL_SUBMISSION_UNCERTAIN_KEY, safeParentJobId);
      else sessionStorage.removeItem(FINAL_SUBMISSION_UNCERTAIN_KEY);
    } catch (_) {
      ToolAErrors.recover("tool.a.runtime.modules.submission.js.33", _, [
        "SecurityError",
        "QuotaExceededError",
        "SyntaxError",
      ]);
    }
    if (active) {
      _setCancelConfigAvailable(false);
    }
    return active;
  }

  function _setCancelConfigAvailable(available) {
    const enabled =
      available === true && !_isFinalSubmissionInFlight() && !_hasUncertainFinalSubmission();

    if (cancelBtn) {
      cancelBtn.disabled = !enabled;
      cancelBtn.setAttribute("aria-disabled", enabled ? "false" : "true");
      cancelBtn.style.setProperty("pointer-events", enabled ? "auto" : "none", "important");
    }

    return enabled;
  }

  function checkoutCalculationReviewSnapshot() {
    {
      const owned = foundation.current?.getCheckoutCalculationSnapshot?.();
      if (owned && typeof owned === "object") return owned;
    }
    return applicationState.current?.checkout?.reviewSnapshot || null;
  }

  function sealedCustomerForCurrentCalculation() {
    const customer = checkoutCalculationReviewSnapshot()?.customer;
    return customer && typeof customer === "object" && String(customer.email || "").trim()
      ? customer
      : customerSnapshot.customerForCurrentCalculation();
  }

  function canSendConfig() {
    {
      const owner = foundation.current;
      if (owner && typeof owner.canSubmitCheckoutReview === "function") {
        return owner.canSubmitCheckoutReview({
          state: applicationState.current,
        });
      }
    }
    try {
      const email = String(sealedCustomerForCurrentCalculation()?.email || "").trim();
      const hasPanels =
        (Array.isArray(applicationState.current?.cart) && applicationState.current.cart.length) ||
        (Array.isArray(applicationState.current?.extraPanels) &&
          applicationState.current.extraPanels.length);
      // Prefer having a computed quote, but allow submit even if quote missing (server can still store request)
      return Boolean(email && hasPanels);
    } catch (_) {
      return false;
    }
  }

  async function submitFinalConfiguration() {
    ToolAErrors.assertHealthy();
    let submitBtnLive = null;
    let finalSubmitAttemptStarted = false;
    let submitParentJobId = "";
    let hadUncertaintyAtStart = false;
    try {
      submitBtnLive = domLookup.byId("sendConfigBtn") || domLookup.byId("btnSendConfig");
      const jobIdRaw = String(
        window.__metod_last_parent_job_id ||
          window.__metod_last_job_id ||
          (applicationState.current &&
            (applicationState.current.lastParentJobId ||
              applicationState.current.lastJobId ||
              applicationState.current.jobId)) ||
          "",
      );
      const parentJobId = jobIdRaw ? jobIdRaw.split("__mat_")[0] : "";
      submitParentJobId = parentJobId;
      hadUncertaintyAtStart = window.__metodHasUncertainFinalSubmission?.() === true;
      let uncertainParentJobId = "";
      try {
        uncertainParentJobId = String(
          window.__metod_submit_uncertain_parent_job_id ||
            sessionStorage.getItem("metod_final_submission_uncertain_parent_job_id") ||
            "",
        ).trim();
      } catch (_) {
        ToolAErrors.recover("tool.a.runtime.modules.submission.js.36", _, [
          "SecurityError",
          "QuotaExceededError",
          "SyntaxError",
        ]);
      }
      if (hadUncertaintyAtStart && uncertainParentJobId && uncertainParentJobId !== parentJobId) {
        calculationView.statusMsg(
          "De verzendstatus van de vorige berekening is nog niet bevestigd. Rond die aanvraag eerst af.",
          true,
        );
        return;
      }
      // A previous request in the same tab must never poison a newly calculated
      // job. Keep idempotency for the same job, but reset stale client flags.
      if (
        window.__metod_submit_done &&
        String(window.__metod_submitted_parent_job_id || "") !== parentJobId
      ) {
        window.__metod_submit_done = false;
      }
      if (window.__metod_submit_inflight) return;
      if (window.__metod_submit_done) {
        calculationView.statusMsg("Deze aanvraag is al verzonden.", false);
        return;
      }
      if (!submitBtnLive)
        throw new Error(
          "De verzendknop kon niet worden geladen. Herlaad de pagina en probeer opnieuw.",
        );
      if (!canSendConfig()) {
        // A disabled button cannot explain what is missing. Keep the result CTA
        // interactive and return the customer to the exact correction step.
        // The authoritative quote remains stored and no optimizer state is
        // changed.
        window.__metod_price_locked = false;
        overlayControls.closePriceOverlay();
        customerForm.syncCheckoutUIFromState();
        if (typeof window.__showWizardStep === "function") window.__showWizardStep("customer");
        else if (typeof wizardNavigation.setStep === "function")
          wizardNavigation.setStep("customer");
        customerValidation.validateCustomerStepRequired();
        calculationView.statusMsg(
          "Vul de ontbrekende klantgegevens in; daarna kun je de aanvraag verzenden.",
          true,
        );
        return;
      }
      const previewReadiness =
        foundation.current && typeof foundation.current.getGrainPreviewReadiness === "function"
          ? foundation.current.getGrainPreviewReadiness()
          : {
              ok: false,
              token: "",
              message: "De nerf-previewcontrole is niet geladen. Herlaad de pagina.",
            };
      if (!previewReadiness.ok) {
        const previewMessage =
          previewReadiness.message || "Controleer de samenstelling van de doorlopende nerfgroep.";
        window.__metod_price_locked = false;
        overlayControls.closePriceOverlay();
        try {
          await alertDialog.showToolAlertHardFallbackAsync({
            title: "Aanvraag nog niet verzonden",
            body: previewMessage,
            details:
              "Er is niets naar Admin verstuurd. Corrigeer de genoemde nerfgroep en verstuur daarna opnieuw.",
            onClose: () => {
              if (typeof window.__showWizardStep === "function") window.__showWizardStep("grain");
              else if (typeof wizardNavigation.showStep === "function")
                wizardNavigation.showStep("grain");
            },
          });
        } catch (_) {
          if (typeof window.__showWizardStep === "function") window.__showWizardStep("grain");
          else if (typeof wizardNavigation.showStep === "function")
            wizardNavigation.showStep("grain");
          calculationView.statusMsg(previewMessage, true);
        }
        submitBtnLive.disabled = false;
        return;
      }
      window.__metod_submit_inflight = true;
      window.__metodSetCancelConfigAvailable?.(false);
      submitBtnLive.disabled = true;
      submitBtnLive.setAttribute("aria-busy", "true");
      submitBtnLive.textContent = "Aanvraag wordt verzonden…";
      const subjobId =
        jobIdRaw && jobIdRaw.includes("__mat_")
          ? jobIdRaw
          : (applicationState.current &&
              applicationState.current.lastQuote &&
              (applicationState.current.lastQuote.jobId ||
                (applicationState.current.lastQuote.perSubjob &&
                  applicationState.current.lastQuote.perSubjob[0] &&
                  (applicationState.current.lastQuote.perSubjob[0].jobId ||
                    applicationState.current.lastQuote.perSubjob[0].subjobId)))) ||
            "";
      const payload = {
        jobId: parentJobId,
        parentJobId: parentJobId,
        subjobId: subjobId || null,
        ts: new Date().toISOString(),
        material:
          applicationState.current?.activeMaterial ||
          applicationState.current?.selectedMaterial ||
          applicationState.current?.material ||
          null,
        customer: sealedCustomerForCurrentCalculation(),
        note: applicationState.current?.checkout?.note || "",
        grainEnabled: applicationState.current?.grainEnabled !== false,
        quote: applicationState.current?.lastQuote || null,
        cart: applicationState.current?.cart || [],
        extraPanels: applicationState.current?.extraPanels || [],
      };
      // Build a compact summary for server-side notifications/mailbox
      let priceInclVat = null;
      let platesTotal = null;
      let materialsSummary = [];
      {
        const q = payload.quote || null;
        priceInclVat =
          authoritativePrice._getFinalAuthoritativePriceForCurrentJob() ??
          authoritativePrice._strictAuthoritativePriceInclVat({
            pricingSummary: applicationState.current?.lastPricingSummary || null,
          });
        const cartNameMap = new Map();
        const addName = (p) => {
          const code = String(p?.articleNumber || p?.materialKey || p?.materialCode || "").trim();
          const name = String(
            p?.materialDisplayName || p?.productName || p?.decorName || p?.name || "",
          ).trim();
          const key = code || name;
          if (!key) return;
          if (name && !cartNameMap.has(key)) cartNameMap.set(key, name);
        };
        (payload.cart || []).forEach(addName);
        (payload.extraPanels || []).forEach(addName);
        (payload.panels || []).forEach(addName);
        // Materials: derive from quote.materials if available, else from cart
        if (Array.isArray(q?.materials)) {
          materialsSummary = q.materials
            .map((mm) => {
              const code = String(mm.materialCode || mm.code || mm.articleNumber || "").trim();
              const fromCart = cartNameMap.get(code) || "";
              const name = String(
                fromCart ||
                  mm.materialDisplayName ||
                  mm.materialName ||
                  mm.name ||
                  mm.productName ||
                  mm.decorName ||
                  "",
              ).trim();
              const plates =
                mm.plates ??
                mm.sheets ??
                mm.sheetsUsed ??
                mm.boards ??
                mm.boardsUsed ??
                mm.sheetCount ??
                null;
              return {
                code,
                name,
                plates: plates != null ? Number(plates) : null,
              };
            })
            .filter((x) => x.code || x.name);
          try {
            platesTotal = materialsSummary.reduce(
              (a, x) => a + (Number.isFinite(x.plates) ? x.plates : 0),
              0,
            );
            if (!Number.isFinite(platesTotal) || platesTotal <= 0) platesTotal = null;
          } catch (_) {
            platesTotal = null;
          }
        } else {
          const map = new Map();
          const add = (p) => {
            const code = String(p?.articleNumber || p?.materialKey || p?.materialCode || "").trim();
            const name = String(
              p?.materialDisplayName || p?.productName || p?.decorName || p?.name || "",
            ).trim();
            const key = code || name;
            if (!key) return;
            if (!map.has(key)) map.set(key, { code, name, plates: null });
          };
          (payload.cart || []).forEach(add);
          (payload.extraPanels || []).forEach(add);
          materialsSummary = Array.from(map.values());
        }
      }
      payload.priceInclVat = priceInclVat;
      payload.platesTotal = platesTotal;
      payload.materialsSummary = materialsSummary;
      // Final submit is a lightweight link operation. Optimization inputs,
      // quote and pricing are already sealed server-side and must not travel a
      // second time through this route.
      const submitWirePayload = {
        jobId: parentJobId,
        parentJobId,
        customer: sealedCustomerForCurrentCalculation(),
        note: String(
          checkoutCalculationReviewSnapshot()?.note ??
            applicationState.current?.checkout?.note ??
            "",
        ),
      };
      const finalSubmitOwner = foundation.current;
      if (!finalSubmitOwner || typeof finalSubmitOwner.submitFinalConfiguration !== "function") {
        throw new Error(
          "De definitieve verzendfunctie is nog niet gereed. Herlaad de pagina en probeer opnieuw.",
        );
      }
      const finalJobId = String(applicationState.current?.finalAuthoritativeJobId || "").trim();
      const finalTotal = authoritativePrice._getFinalAuthoritativePriceForCurrentJob();
      finalSubmitAttemptStarted = true;
      window.__metodSetFinalSubmissionUncertain?.(parentJobId, true);
      const submitResult = await finalSubmitOwner.submitFinalConfiguration({
        parentJobId,
        accessToken:
          applicationState.current?.lastJobAccessToken ||
          window.__metod_last_job_access_token ||
          "",
        customer: submitWirePayload.customer,
        note: submitWirePayload.note,
        jobComplete: Boolean(
          finalJobId === parentJobId && finalTotal != null && Number.isFinite(Number(finalTotal)),
        ),
      });
      if (!submitResult?.ok) {
        if (submitResult?.ignored) {
          calculationView.statusMsg("Deze aanvraag wordt al verwerkt of is al verzonden.", false);
          return;
        }
        throw submitResult?.error || new Error("De aanvraag kon niet worden verzonden.");
      }
      const out = submitResult.committed?.response || {};
      const committedRequestId = String(out?.requestId || "").trim();
      if (!committedRequestId) {
        throw new Error(
          "De server bevestigde geen aanvraagreferentie. De aanvraag is niet als verzonden gemarkeerd.",
        );
      }
      let finalPriceInclVat = priceInclVat;

      if (out?.pricingSummary) {
        applicationState.current.lastPricingSummary = out.pricingSummary;
      }

      {
        authoritativePrice._setFinalAuthoritativePrice(
          applicationState.current?.lastParentJobId || window.__metod_last_parent_job_id || null,
          out?.pricingSummary || null,
        );
        const authoritative =
          authoritativePrice._getFinalAuthoritativePriceForCurrentJob() ??
          authoritativePrice._strictAuthoritativePriceInclVat({
            pricingSummary: out?.pricingSummary || null,
          });
        if (authoritative != null && Number.isFinite(Number(authoritative))) {
          finalPriceInclVat = Number(authoritative);
          applicationState.current.lastQuote = Object.assign(
            {},
            applicationState.current.lastQuote || payload?.quote || {},
            {
              total_incl_vat: finalPriceInclVat,
              totalInclVat: finalPriceInclVat,
              grandTotalInclVat: finalPriceInclVat,
            },
          );
          applicationState.current.quote = Object.assign(
            {},
            applicationState.current.quote || payload?.quote || {},
            {
              total_incl_vat: finalPriceInclVat,
              totalInclVat: finalPriceInclVat,
              grandTotalInclVat: finalPriceInclVat,
            },
          );
          priceBar.updatePriceBar({ total: finalPriceInclVat });
        }
      }
      // Keep cancellation capabilities in memory only. They must never survive
      // a tab reload or become a browser-storage authorization source.

      window.__metod_last_request_id = committedRequestId;
      if (out?.cancelToken) {
        window.__metod_last_request_cancel_token = out.cancelToken;
      }

      window.__metodSetFinalSubmissionUncertain?.(parentJobId, false);
      calculationView.statusMsg("Configuratie verzonden.", false);
      window.__metod_submit_done = true;
      window.__metod_submitted_parent_job_id = parentJobId;
      overlayControls.closePriceOverlay();
      const thankYouOwner = foundation.current;
      if (!thankYouOwner || typeof thankYouOwner.showSubmissionThankYou !== "function") {
        calculationView.statusMsg(`Aanvraag ontvangen. Referentie: ${committedRequestId}`, false);
        alert(`Bedankt, je aanvraag is ontvangen. Referentie: ${committedRequestId}`);
        return;
      }
      const thankYouShown = thankYouOwner.showSubmissionThankYou({
        requestId: committedRequestId,
        priceInclVat: finalPriceInclVat,
        pricingSummary: out?.pricingSummary || null,
        customer: payload?.customer || {},
      });
      if (thankYouShown !== true) {
        calculationView.statusMsg(`Aanvraag ontvangen. Referentie: ${committedRequestId}`, false);
      }
    } catch (err) {
      window.__metod_submit_done = false;
      const commitUncertain = Boolean(
        err?.metodCommitUncertain || err?.metodRequestTimeout || err?.metodTimeout,
      );

      if (commitUncertain || (hadUncertaintyAtStart && !finalSubmitAttemptStarted)) {
        window.__metodSetFinalSubmissionUncertain?.(submitParentJobId, true);
      } else if (finalSubmitAttemptStarted) {
        window.__metodSetFinalSubmissionUncertain?.(submitParentJobId, false);
      }

      const failureMessage = commitUncertain
        ? `De serverbevestiging is nog niet ontvangen: ${err?.message || err}. Probeer dezelfde aanvraag opnieuw te bevestigen; er wordt geen tweede aanvraag aangemaakt.`
        : `Verzenden mislukt: ${err?.message || err}`;
      calculationView.statusMsg(failureMessage, true);
      if (typeof alertDialog.showToolAlert === "function")
        alertDialog.showToolAlert(
          failureMessage,
          commitUncertain ? "Verzendstatus niet bevestigd" : "Aanvraag niet verzonden",
        );
    } finally {
      window.__metod_submit_inflight = false;
      if (!window.__metod_submit_done) {
        submitBtnLive.disabled = false;
        submitBtnLive.removeAttribute("aria-busy");
        submitBtnLive.textContent = "Akkoord en aanvraag verzenden";
        window.__metodSetCancelConfigAvailable?.(true);
      } else {
        window.__metodSetCancelConfigAvailable?.(false);
      }
    }
  }

  function connect() {
    sendBtn = domLookup.byId("sendConfigBtn");
    cancelBtn = domLookup.byId("cancelConfigBtn");
    CLIENT_MUTATION_DEADLINE_MS = 12000;
    FINAL_SUBMISSION_UNCERTAIN_KEY = "metod_final_submission_uncertain_parent_job_id";

    window.__metodHasUncertainFinalSubmission = _hasUncertainFinalSubmission;
    window.__metodSetFinalSubmissionUncertain = _setFinalSubmissionUncertain;
  }

  function connect2() {
    window.__metodSubmitFinalConfiguration = submitFinalConfiguration;
    if (sendBtn) sendBtn.__bound = true;
  }

  return Object.freeze({
    get cancelBtn() {
      return cancelBtn;
    },
    get CLIENT_MUTATION_DEADLINE_MS() {
      return CLIENT_MUTATION_DEADLINE_MS;
    },
    get FINAL_SUBMISSION_UNCERTAIN_KEY() {
      return FINAL_SUBMISSION_UNCERTAIN_KEY;
    },
    _isFinalSubmissionInFlight,
    _hasUncertainFinalSubmission,
    _setFinalSubmissionUncertain,
    _setCancelConfigAvailable,
    connect,
    connect2,
  });
}
