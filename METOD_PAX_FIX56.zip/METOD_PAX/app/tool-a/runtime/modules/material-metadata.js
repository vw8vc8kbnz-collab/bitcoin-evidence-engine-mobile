import { ToolAExtraPanelViewState } from "../../domain/extra-panel-view-state.js";
import { ToolAStateHelpers } from "../../domain/safe-helper-layer.js";
/** material-metadata: one runtime owner with explicit, immutable dependency ports. */
export function createMaterialMetadata({
  applicationState,
  configurationState,
  foundation,
  materialIdentity,
} = {}) {
  let DEFAULT_THICKNESS_MM;
  let MATERIAL_META;

  function materialLabel(key) {
    if (ToolAStateHelpers && typeof ToolAStateHelpers.materialLabel === "function") {
      return ToolAStateHelpers.materialLabel(
        key,
        applicationState.current,
        MATERIAL_META,
        materialIdentity.materialLabelMat,
      );
    }

    return String(key || "");
  }

  function getMaterialBatchByKey(k) {
    if (ToolAStateHelpers && typeof ToolAStateHelpers.getMaterialBatchByKey === "function") {
      return ToolAStateHelpers.getMaterialBatchByKey(applicationState.current, k);
    }

    configurationState.ensureStateShape();
    return (applicationState.current.materialBatches || []).find(
      (b) => String(b.key) === String(k),
    );
  }

  function materialLabelKey(k) {
    if (ToolAStateHelpers && typeof ToolAStateHelpers.materialLabelKey === "function") {
      return ToolAStateHelpers.materialLabelKey(
        k,
        applicationState.current,
        MATERIAL_META,
        materialIdentity.materialLabelMat,
      );
    }

    const b = getMaterialBatchByKey(k);
    if (b && b.mat) return materialIdentity.materialLabelMat(b.mat);
    return materialLabel(k);
  }

  function materialArticleNumberKey(k) {
    if (ToolAStateHelpers && typeof ToolAStateHelpers.materialArticleNumberKey === "function") {
      return ToolAStateHelpers.materialArticleNumberKey(k, applicationState.current);
    }

    const b = getMaterialBatchByKey(k);
    const art = b && b.mat && b.mat.articleNumber ? String(b.mat.articleNumber) : "";
    return art;
  }

  function materialThicknessKey(k) {
    configurationState.ensureStateShape();
    const owner = foundation.current;
    if (!owner || typeof owner.getMaterialThickness !== "function") {
      throw new Error("R9 material thickness reader is niet geladen. Herlaad Tool A.");
    }
    return owner.getMaterialThickness(k, window.MATERIAL_CATALOG, DEFAULT_THICKNESS_MM);
  }

  function syncExtraPanelThicknessesForSelectedMaterials() {
    configurationState.ensureStateShape();
    if (
      !Array.isArray(applicationState.current?.extraPanels) ||
      !applicationState.current.extraPanels.length
    )
      return false;
    let changed = false;
    applicationState.current.extraPanels = applicationState.current.extraPanels.map(
      function (panel) {
        const mk = String(panel?.materialKey || panel?.material || "").trim();
        const nextThickness = Number(materialThicknessKey(mk));
        if (!Number.isFinite(nextThickness) || nextThickness <= 0) return panel;
        const currentThickness = Number(panel?.thicknessMm);
        if (Number.isFinite(currentThickness) && Math.abs(currentThickness - nextThickness) < 0.001)
          return panel;
        changed = true;
        return Object.assign({}, panel || {}, { thicknessMm: nextThickness });
      },
    );
    return changed;
  }

  function refreshExtraMaterialOptions() {
    configurationState.ensureStateShape();
    const sel = document.getElementById("extraMat");
    if (!sel) return;
    let vm = null;
    try {
      if (
        ToolAExtraPanelViewState &&
        typeof ToolAExtraPanelViewState.getMaterialOptionsState === "function"
      ) {
        vm = ToolAExtraPanelViewState.getMaterialOptionsState(applicationState.current, {
          currentValue: String(sel.value || ""),
          materialLabelMat: materialIdentity.materialLabelMat,
        });
      }
    } catch (_) {
      vm = null;
    }
    if (!vm) {
      const batches = applicationState.current.materialBatches || [];
      const current = String(sel.value || "");
      vm = {
        disabled: !batches.length,
        options: batches.map((b) => ({
          value: String(b.key),
          label: materialIdentity.materialLabelMat(b.mat || { decorName: b.key }),
        })),
        selectedValue:
          current && batches.some((b) => String(b.key) === current)
            ? current
            : String(applicationState.current.activeMaterialKey || "") &&
                batches.some(
                  (b) => String(b.key) === String(applicationState.current.activeMaterialKey || ""),
                )
              ? String(applicationState.current.activeMaterialKey || "")
              : batches[0]
                ? String(batches[0].key)
                : "",
        emptyLabel: "— kies eerst een materiaal —",
      };
    }
    sel.innerHTML = "";
    if (vm.disabled) {
      const opt = document.createElement("option");
      opt.value = "";
      opt.textContent = String(vm.emptyLabel || "— kies eerst een materiaal —");
      sel.appendChild(opt);
      sel.value = "";
      sel.disabled = true;
      return;
    }
    sel.disabled = false;
    (vm.options || []).forEach((model) => {
      const opt = document.createElement("option");
      opt.value = String(model?.value || "").trim();
      opt.textContent = String(model?.label || model?.value || "").trim();
      sel.appendChild(opt);
    });
    sel.value = String(vm.selectedValue || "");
  }

  function materialArticleNumber(key) {
    if (ToolAStateHelpers && typeof ToolAStateHelpers.materialArticleNumber === "function") {
      return ToolAStateHelpers.materialArticleNumber(key, MATERIAL_META);
    }

    return MATERIAL_META[key] && MATERIAL_META[key].articleNumber
      ? MATERIAL_META[key].articleNumber
      : "";
  }

  function mount() {
    DEFAULT_THICKNESS_MM = 18;
    MATERIAL_META = {
      oak: { name: "Eiken (warm)", articleNumber: "DEFAULT_18_OAK" },
      walnut: {
        name: "Noten (warm donker)",
        articleNumber: "DEFAULT_18_WALNUT",
      },
      paint: { name: "Uni kleur (rustig)", articleNumber: "DEFAULT_18_UNI" },
    };
  }

  return Object.freeze({
    get DEFAULT_THICKNESS_MM() {
      return DEFAULT_THICKNESS_MM;
    },
    materialLabel,
    materialLabelKey,
    materialArticleNumberKey,
    materialThicknessKey,
    syncExtraPanelThicknessesForSelectedMaterials,
    refreshExtraMaterialOptions,
    materialArticleNumber,
    mount,
  });
}
