import { ToolAExtraPanelMutations } from "../../domain/extra-panel-mutations.js";
import { ToolAExtraPanelSubmitApply } from "../../domain/extra-panel-submit-apply.js";
import { ToolAExtraPanelSubmitFlow } from "../../domain/extra-panel-submit-flow.js";
import { ToolAPanelsViewModels } from "../../domain/panels-view-models.js";
/** extra-editor: one runtime owner with explicit, immutable dependency ports. */
export function createExtraEditor({
  applicationState,
  configurationState,
  edgePresentation,
  extraPreview,
  feedback,
  formatting,
  foundation,
  grainData,
  materialMetadata,
  panelDock,
  panelEdges,
  panelEditSession,
  panelElements,
  panelList,
  priceBar,
  viewRefresh,
} = {}) {
  function renderExtraPanels() {
    if (!panelElements.extraList || !panelElements.extraHelp) return;
    panelElements.extraList.innerHTML = "";
    const extraSummary =
      ToolAPanelsViewModels && typeof ToolAPanelsViewModels.getExtraPanelsSummary === "function"
        ? ToolAPanelsViewModels.getExtraPanelsSummary(applicationState.current)
        : {
            lineCount: Array.isArray(applicationState.current.extraPanels)
              ? applicationState.current.extraPanels.length
              : 0,
            qtyCount: Array.isArray(applicationState.current.extraPanels)
              ? applicationState.current.extraPanels.reduce(
                  (a, p) => a + Math.max(1, Number(p?.qty) || 1),
                  0,
                )
              : 0,
            hasItems: !!(
              applicationState.current.extraPanels && applicationState.current.extraPanels.length
            ),
          };
    if (panelElements.extraCountPill)
      panelElements.extraCountPill.textContent = String(extraSummary.lineCount || 0);
    if (panelElements.extraOverlayBtn)
      panelElements.extraOverlayBtn.textContent = extraSummary.lineCount
        ? `Overige panelen (${extraSummary.lineCount})`
        : "Overige panelen";
    if (panelElements.overviewBtn)
      panelElements.overviewBtn.disabled = !(
        applicationState.current.cart.length || applicationState.current.extraPanels.length
      );
    const items = applicationState.current.extraPanels;
    if (!items.length) {
      panelElements.extraHelp.style.display = "block";
      try {
        panelList.renderCart();
      } catch (_) {
        panelList.syncPanelDockChrome();
      }
      priceBar.updatePriceBar();
      return;
    }
    panelElements.extraHelp.style.display = "none";

    const cardModels =
      ToolAPanelsViewModels && typeof ToolAPanelsViewModels.getExtraPanelCardModels === "function"
        ? ToolAPanelsViewModels.getExtraPanelCardModels(applicationState.current, {
            materialLabelForKey: materialMetadata.materialLabelKey,
            edgeTextFor: edgePresentation.edgeCustomerText,
          })
        : items.map((p, i) => ({
            index: i,
            width: Number(p.w) || 0,
            height: Number(p.h) || 0,
            title: p.name?.trim() ? p.name.trim() : `Overig paneel ${p.w}×${p.h}`,
            line2: `${p.qty}× · ${p.w}×${p.h} mm · ${materialMetadata.materialLabelKey(p.materialKey || p.material)} · Kantenband: ${edgePresentation.edgeCustomerText(p.edge, Number(p.w), Number(p.h))}`,
            panel: p,
          }));
    for (const model of cardModels) {
      const p = model.panel || items[model.index];
      const i = Number(model.index);
      const card = document.createElement("div");
      card.className = "cardItem extraPanelListItem";
      const svg = extraPreview.extraPanelMiniSvg(model.width, model.height, p?.edge);
      card.innerHTML = `
        <div class="extraPanelListMain u-row-center">
          <div class="u-panel-thumbnail">${svg}</div>
          <div class="extraPanelListCopy">
            <div class="extraPanelListTitle u-weight-800">${formatting._esc(model.title)}</div>
            <div class="extraPanelListMeta muted u-text-12">${formatting._esc(model.line2)}</div>
          </div>
        </div>
        <div class="extraPanelListActions u-row-gap-8">
          <button class="miniBtn" type="button" data-act="edit" data-i="${i}" aria-label="Bewerk ${formatting._esc(model.title)}" title="Bewerk">✎</button>
          <button class="miniBtn u-border-warning" type="button" data-act="del" data-i="${i}" aria-label="Verwijder ${formatting._esc(model.title)}" title="Verwijder">✕</button>
        </div>`;

      panelElements.extraList.appendChild(card);
    }

    if (typeof panelList.renderCart === "function") panelList.renderCart();

    panelElements.extraList.querySelectorAll("button").forEach((btn) => {
      btn.addEventListener("click", () => {
        configurationState.ensureStateShape();
        // State is normalized once at this event boundary.
        const act = btn.getAttribute("data-act");
        const idx = Number(btn.getAttribute("data-i"));
        if (!(idx >= 0)) return;
        if (act === "del") {
          foundation.current?.removeExtraPanel?.({
            state: applicationState.current,
            index: idx,
            editIndex: panelEditSession.extraEditIndex,
            hooks: {
              clearAllGrainAssignments: grainData.clearAllGrainAssignments,
              setEditIndex(v) {
                panelEditSession.extraEditIndex = v;
              },
              renderExtraPanels,
              renderCart: panelList.renderCart,
              renderOverview() {
                if (typeof viewRefresh.overview === "function") viewRefresh.overview();
                else if (typeof viewRefresh.overview === "function") viewRefresh.overview();
              },
              scheduleDraftSave: feedback.scheduleDraftSave,
              updatePriceBar: priceBar.updatePriceBar,
              syncChecksFromSelect: panelEdges.syncChecksFromSelect,
              drawExtraPreview: extraPreview.drawExtraPreview,
            },
          });
          return;
        }
        if (act === "edit") {
          const p = applicationState.current.extraPanels[idx];
          const panelEditorOwner = foundation.current;
          const snap =
            panelEditorOwner && typeof panelEditorOwner.getExtraPanelEditSnapshot === "function"
              ? panelEditorOwner.getExtraPanelEditSnapshot(p, { index: idx })
              : null;
          const __applied =
            panelEditorOwner && typeof panelEditorOwner.applyExtraPanelEditSnapshot === "function"
              ? panelEditorOwner.applyExtraPanelEditSnapshot({
                  snapshot: snap || {
                    editIndex: idx,
                    showEditHint: true,
                    buttonLabel: "✓ Wijzigingen opslaan",
                    name: p.name || "",
                    w: p.w,
                    h: p.h,
                    qty: p.qty,
                    materialKey: String(p.materialKey || p.material || ""),
                    edge: p.edge || "none",
                  },
                  elements: {
                    addExtraBtn: panelElements.addExtraBtn,
                    extraEditHint: panelElements.extraEditHint,
                    extraName: panelElements.extraName,
                    extraW: panelElements.extraW,
                    extraH: panelElements.extraH,
                    extraQty: panelElements.extraQty,
                    extraMat: panelElements.extraMat,
                  },
                  hooks: {
                    setEditIndex(v) {
                      panelEditSession.extraEditIndex = v;
                    },
                    refreshExtraMaterialOptions: materialMetadata.refreshExtraMaterialOptions,
                    ensureEdgeOption: panelEdges.ensureEdgeOption,
                    syncChecksFromSelect: panelEdges.syncChecksFromSelect,
                  },
                })
              : false;
          if (!__applied) {
            panelEditSession.extraEditIndex = snap ? snap.editIndex : idx;
            panelElements.extraEditHint.style.display = (snap ? snap.showEditHint : true)
              ? "block"
              : "none";
            if (panelElements.addExtraBtn)
              panelElements.addExtraBtn.textContent = snap?.buttonLabel || "✓ Wijzigingen opslaan";
            panelElements.extraName.value = snap ? snap.name : p.name || "";
            panelElements.extraW.value = snap ? snap.w : p.w;
            panelElements.extraH.value = snap ? snap.h : p.h;
            panelElements.extraQty.value = snap ? snap.qty : p.qty;
            materialMetadata.refreshExtraMaterialOptions();
            panelElements.extraMat.value = snap
              ? String(snap.materialKey || "")
              : String(p.materialKey || p.material || "");
            panelEdges.ensureEdgeOption(snap ? snap.edge || "none" : p.edge || "none");
            panelEdges.syncChecksFromSelect();
            // scroll to section
            panelElements.extraName.scrollIntoView({
              behavior: "auto",
              block: "nearest",
            });
          }
        }
      });
    });

    priceBar.updatePriceBar();
  }

  function resetExtraForm() {
    // Reset the volatile edit identity first so a partial DOM reset can never
    // leave a stale array index armed for a later submit.
    panelEditSession.extraEditIndex = null;
    const panelEditorOwner = foundation.current;
    const snap = {
      editIndex: null,
      showEditHint: false,
      buttonLabel: "+ Toevoegen",
      name: "",
      w: "",
      h: "",
      qty: "1",
      edge: "none",
    };
    const __applied =
      panelEditorOwner && typeof panelEditorOwner.resetExtraPanelEditor === "function"
        ? panelEditorOwner.resetExtraPanelEditor({
            options: { buttonLabel: "+ Toevoegen", defaultEdge: "none" },
            elements: {
              addExtraBtn: panelElements.addExtraBtn,
              extraEditHint: panelElements.extraEditHint,
              extraName: panelElements.extraName,
              extraW: panelElements.extraW,
              extraH: panelElements.extraH,
              extraQty: panelElements.extraQty,
              extraEdgeTop: panelElements.extraEdgeTop,
              extraEdgeBottom: panelElements.extraEdgeBottom,
              extraEdgeLeft: panelElements.extraEdgeLeft,
              extraEdgeRight: panelElements.extraEdgeRight,
            },
            hooks: {
              setEditIndex(v) {
                panelEditSession.extraEditIndex = v;
              },
              refreshExtraMaterialOptions: materialMetadata.refreshExtraMaterialOptions,
              ensureEdgeOption: panelEdges.ensureEdgeOption,
              syncSelectFromChecks: panelEdges.syncSelectFromChecks,
            },
          })
        : false;
    if (__applied) return;
    panelEditSession.extraEditIndex = snap ? snap.editIndex : null;
    panelElements.extraEditHint.style.display = (snap ? snap.showEditHint : false)
      ? "block"
      : "none";
    if (panelElements.addExtraBtn)
      panelElements.addExtraBtn.textContent = snap?.buttonLabel || "+ Toevoegen";
    panelElements.extraName.value = snap ? snap.name : "";
    panelElements.extraW.value = snap ? snap.w : "";
    panelElements.extraH.value = snap ? snap.h : "";
    panelElements.extraQty.value = snap ? snap.qty : "1";
    materialMetadata.refreshExtraMaterialOptions();
    panelEdges.ensureEdgeOption(snap ? snap.edge || "none" : "none");
    if (panelElements.extraEdgeTop) panelElements.extraEdgeTop.checked = false;
    if (panelElements.extraEdgeBottom) panelElements.extraEdgeBottom.checked = false;
    if (panelElements.extraEdgeLeft) panelElements.extraEdgeLeft.checked = false;
    if (panelElements.extraEdgeRight) panelElements.extraEdgeRight.checked = false;
    panelEdges.syncSelectFromChecks();
  }

  function getExtraPanelSubmitInput() {
    return {
      submitOwner:
        ToolAExtraPanelSubmitApply && typeof ToolAExtraPanelSubmitApply.execute === "function"
          ? ToolAExtraPanelSubmitApply
          : null,
      state: applicationState.current,
      elements: {
        extraW: panelElements.extraW,
        extraH: panelElements.extraH,
        extraQty: panelElements.extraQty,
        extraMat: panelElements.extraMat,
        extraName: panelElements.extraName,
        extraEdge: panelElements.extraEdge,
        addExtraBtn: panelElements.addExtraBtn,
        extraEditHint: panelElements.extraEditHint,
        extraEdgeTop: panelElements.extraEdgeTop,
        extraEdgeBottom: panelElements.extraEdgeBottom,
        extraEdgeLeft: panelElements.extraEdgeLeft,
        extraEdgeRight: panelElements.extraEdgeRight,
      },
      editIndex: panelEditSession.extraEditIndex,
      submitFlow:
        ToolAExtraPanelSubmitFlow && typeof ToolAExtraPanelSubmitFlow.getSubmitPlan === "function"
          ? ToolAExtraPanelSubmitFlow
          : null,
      mutationAdapter:
        ToolAExtraPanelMutations && typeof ToolAExtraPanelMutations.applyUpsert === "function"
          ? ToolAExtraPanelMutations
          : null,
      hooks: {
        updateExtraEdgeLabels: extraPreview.updateExtraEdgeLabels,
        validatePanelFits: panelDock.validatePanelFitsSheetMm,
        materialArticleNumberKey: materialMetadata.materialArticleNumberKey,
        materialArticleNumber: materialMetadata.materialArticleNumber,
        materialThicknessKey: materialMetadata.materialThicknessKey,
        clearAllGrainAssignments: grainData.clearAllGrainAssignments,
        renderExtraPanels,
        renderCart: panelList.renderCart,
        syncChecksFromSelect: panelEdges.syncChecksFromSelect,
        drawExtraPreview: extraPreview.drawExtraPreview,
        resetExtraForm,
        setEditIndex(v) {
          panelEditSession.extraEditIndex = v;
        },
      },
      constants: {
        defaultThicknessMm: materialMetadata.DEFAULT_THICKNESS_MM,
        idPrefix: "EX_",
        minWidthMm: 40,
      },
    };
  }

  return Object.freeze({
    renderExtraPanels,
    resetExtraForm,
    getExtraPanelSubmitInput,
  });
}
