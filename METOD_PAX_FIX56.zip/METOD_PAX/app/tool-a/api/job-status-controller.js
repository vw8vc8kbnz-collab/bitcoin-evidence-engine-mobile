import {
  authoritativeTotalInclVat,
  cancelledJobError,
  cleanText,
  normalizeJobId,
  safeProgressCallback,
} from "./job-api-shared.js";
import { isJobCancellationConfirmed } from "./cancellation-response.js";

export function createJobStatusController(options = {}) {
  const now = options.now;
  const sleep = options.sleep;
  const maxTotalMs = options.maxTotalMs;
  const maxStatusOutageMs = options.maxStatusOutageMs;
  const statusRequestTimeoutMs = options.statusRequestTimeoutMs;
  const pricingRequestTimeoutMs = options.pricingRequestTimeoutMs;
  const readStatus = options.readStatus;
  const cancelRequest = options.cancelRequest;
  const clearTerminal = options.clearTerminal;

  async function cancelJob({
    jobId,
    accessToken,
    reason = "customer_cancelled",
  } = {}) {
    if (!jobId) return null;
    const response = await cancelRequest({ jobId, accessToken, reason });
    let data = null;
    try {
      data = await response.json();
    } catch (_error) {
      // An unreadable response cannot confirm cancellation or clear recovery.
    }
    if (isJobCancellationConfirmed(response, data, jobId)) clearTerminal(jobId);
    return response;
  }

  async function fetchPricingSummary({ jobId, accessToken } = {}) {
    try {
      const { response, data } = await readStatus(jobId, accessToken, pricingRequestTimeoutMs);
      if (!response.ok) return null;
      const status = cleanText(data?.meta?.status).toLowerCase();
      if (!["done", "ready", "ok"].includes(status)) return null;
      const pricingSummary = data?.pricingSummary || null;
      return authoritativeTotalInclVat({ pricingSummary }) == null ? null : pricingSummary;
    } catch (_error) {
      return null;
    }
  }

  async function pollJob({ jobId, accessToken, onProgress } = {}) {
    const canonicalJobId = normalizeJobId(jobId);
    let shownPct = 3;
    let lastMessage = "Invoer veilig gecontroleerd";
    let lastProgressAt = now();
    let lastServerPct = 0;
    let lastStatus = "";
    const startedAt = now();
    let outageStartedAt = 0;
    let transientFailures = 0;
    safeProgressCallback(onProgress, shownPct, lastMessage);

    while (true) {
      if (now() - startedAt > maxTotalMs) {
        throw new Error(
          "De optimalisatie duurt onverwacht lang. De aanvraag is niet verloren; controleer Admin of probeer de status opnieuw te laden.",
        );
      }
      let response;
      let data;
      try {
        let rawStatusBody = "";
        ({ response, data, rawStatusBody } = await readStatus(
          canonicalJobId,
          accessToken,
          statusRequestTimeoutMs,
          true,
        ));
        if (!response.ok) {
          const terminalClientError =
            response.status >= 400 &&
            response.status < 500 &&
            ![408, 425, 429].includes(response.status);
          if (terminalClientError) {
            let serverMessage = "";
            try {
              const statusJson = JSON.parse(rawStatusBody);
              serverMessage = cleanText(
                statusJson?.error ||
                  statusJson?.message ||
                  statusJson?.meta?.error ||
                  statusJson?.meta?.progressMessage,
              );
            } catch (_error) {
              serverMessage = cleanText(rawStatusBody);
            }
            const terminalError = new Error(
              serverMessage || `De jobstatus is definitief geweigerd (HTTP ${response.status}).`,
            );
            terminalError.httpStatus = response.status;
            terminalError.isUserFacing = true;
            terminalError.metodTerminalStatus = true;
            if (response.status === 404) clearTerminal(canonicalJobId);
            throw terminalError;
          }
          throw new Error(`Status HTTP ${response.status}`);
        }
        transientFailures = 0;
        outageStartedAt = 0;
      } catch (statusError) {
        if (statusError?.metodTerminalStatus) throw statusError;
        transientFailures += 1;
        if (!outageStartedAt) outageStartedAt = now();
        if (now() - outageStartedAt > maxStatusOutageMs) {
          throw new Error(
            "De serverstatus kon langere tijd niet worden opgehaald. De job kan nog op de server draaien; controleer Admin voordat je opnieuw indient.",
          );
        }
        safeProgressCallback(
          onProgress,
          Math.max(1, shownPct),
          lastMessage || "Server verwerkt de optimalisatie…",
        );
        await sleep(Math.min(5000, 500 + transientFailures * 350));
        continue;
      }

      const status = cleanText(data?.meta?.status || "unknown").toLowerCase();
      if (["cancelled", "canceled"].includes(status)) {
        clearTerminal(canonicalJobId);
        throw cancelledJobError(data, status);
      }
      if (status === "error") {
        clearTerminal(canonicalJobId);
        const terminalError = new Error(
          cleanText(data?.meta?.error || data?.meta?.progressMessage) ||
            "De output kon niet volledig worden opgebouwd. Controleer de aanvraag in Admin.",
        );
        terminalError.name = "MetodJobFailedError";
        terminalError.code = "METOD_JOB_FAILED";
        terminalError.isUserFacing = true;
        terminalError.metodTerminalStatus = true;
        terminalError.metodJobFailed = true;
        terminalError.jobStatus = status;
        throw terminalError;
      }
      const message = cleanText(data?.meta?.progressMessage);
      if (message) lastMessage = message;
      const rawServerPct = data?.meta?.progressPct;
      let serverPct = Number.isFinite(Number(rawServerPct))
        ? Math.max(0, Math.min(100, Math.round(Number(rawServerPct))))
        : shownPct;
      if (serverPct > lastServerPct || status !== lastStatus) {
        lastProgressAt = now();
        lastServerPct = serverPct;
        lastStatus = status;
      }
      if (["done", "ready", "ok"].includes(status)) {
        shownPct = 100;
        safeProgressCallback(onProgress, 100, message || lastMessage || "Optimalisatie afgerond");
        clearTerminal(canonicalJobId);
        return data;
      }
      if (now() - lastProgressAt > 90 * 1000) {
        lastMessage = "Deze optimalisatie duurt langer dan normaal; de server werkt verder…";
      }
      serverPct = Math.min(99, Math.max(shownPct, serverPct, 1));
      shownPct = serverPct;
      safeProgressCallback(
        onProgress,
        shownPct,
        message || lastMessage || "Bezig met optimaliseren…",
      );
      await sleep(350);
    }
  }

  return Object.freeze({ cancelJob, fetchPricingSummary, pollJob });
}
