export const SHA256_HEX_PATTERN = /^[a-f0-9]{64}$/;
export const PUBLIC_JOB_ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9_.:-]{0,199}$/;

export function cleanText(value) {
  return String(value == null ? "" : value).trim();
}

export function normalizeJobId(value) {
  const jobId = cleanText(value);
  if (!jobId) throw new TypeError("A job id is required");
  return jobId;
}

export function validateStoredStartKey(value) {
  const key = cleanText(value);
  return key.length >= 16 && key.length <= 128 && /^[A-Za-z0-9._:-]+$/.test(key) ? key : "";
}

export function validateStoredJobId(value) {
  const jobId = cleanText(value);
  return PUBLIC_JOB_ID_PATTERN.test(jobId) ? jobId : "";
}

export function safeProgressCallback(callback, progressPct, progressLabel) {
  if (typeof callback !== "function") return;

  callback(Object.freeze({ progressPct, progressLabel }));
}

export function positiveTimeout(value, fallback) {
  return Number.isFinite(Number(value)) ? Math.max(1, Number(value)) : fallback;
}

export function positiveInteger(value, fallback, maximum) {
  return Number.isFinite(Number(value))
    ? Math.min(maximum, Math.max(1, Math.floor(Number(value))))
    : fallback;
}

export function requestTimeoutError(message, operation, timeoutMs) {
  const error = new Error(message);
  error.name = "MetodRequestTimeoutError";
  error.code = "METOD_REQUEST_TIMEOUT";
  error.isUserFacing = true;
  error.metodRequestTimeout = true;
  error.operation = operation;
  error.timeoutMs = timeoutMs;
  return error;
}

export function uncertainStartResponseError(message) {
  const error = new Error(message);
  error.name = "MetodJobStartUncertainError";
  error.code = "METOD_JOB_START_UNCERTAIN";
  error.isUserFacing = true;
  error.metodCommitUncertain = true;
  return error;
}

export function startStorageError(message) {
  const error = new Error(message);
  error.name = "MetodJobStartStorageError";
  error.code = "METOD_JOB_START_STORAGE_UNAVAILABLE";
  error.isUserFacing = true;
  error.metodCommitUncertain = true;
  return error;
}

export function markUncertainStartError(error) {
  const target =
    error && (typeof error === "object" || typeof error === "function")
      ? error
      : uncertainStartResponseError(cleanText(error) || "De jobstart is nog onzeker.");
  try {
    target.metodCommitUncertain = true;
    target.isUserFacing = true;
  } catch (_error) {
    return uncertainStartResponseError(cleanText(target?.message) || "De jobstart is nog onzeker.");
  }
  return target;
}

export function cancelledJobError(data, status) {
  const message =
    cleanText(data?.meta?.error || data?.meta?.progressMessage) || "De berekening is geannuleerd.";
  const error = new Error(message);
  error.name = "MetodJobCancelledError";
  error.code = "METOD_JOB_CANCELLED";
  error.isUserFacing = true;
  error.metodTerminalStatus = true;
  error.metodCancelled = true;
  error.metodJobCancelled = true;
  error.jobStatus = status;
  return error;
}

export function buildJobTokenHeaders(accessToken) {
  const token = cleanText(accessToken);
  return token ? Object.freeze({ Authorization: `Bearer ${token}` }) : Object.freeze({});
}

export function authoritativeTotalInclVat(source) {
  const total = source?.pricingSummary?.totalInclVat;
  return total != null && Number.isFinite(Number(total)) ? Number(total) : null;
}

export function bufferedStartResponse(response, rawBody, parsedBody) {
  const status = Number(response?.status || 0);
  const ok = typeof response?.ok === "boolean" ? response.ok : status >= 200 && status < 300;
  const body = String(rawBody == null ? "" : rawBody);
  return Object.freeze({
    ok,
    status,
    statusText: cleanText(response?.statusText),
    headers: response?.headers || null,
    url: cleanText(response?.url),
    text: async () => body,
    json: async () => (parsedBody === undefined ? JSON.parse(body) : parsedBody),
  });
}

export function acceptedJobFields(data) {
  const jobId = validateStoredJobId(data?.parentJobId || data?.jobId);
  const accessToken = cleanText(data?.accessToken || data?.jobAccessToken || data?.token);
  if (!jobId || !accessToken) {
    throw uncertainStartResponseError(
      "De serverbevestiging miste de veilige jobreferentie. Dezelfde start blijft geblokkeerd voor controle.",
    );
  }
  return Object.freeze({ jobId, accessToken });
}

export async function readAndBufferStartResponse(response) {
  let buffered;
  if (response && typeof response.text === "function") {
    const rawBody = await response.text();
    buffered = bufferedStartResponse(response, rawBody);
  } else if (response && typeof response.json === "function") {
    const parsedBody = await response.json();
    buffered = bufferedStartResponse(response, JSON.stringify(parsedBody), parsedBody);
  } else {
    buffered = response;
  }
  const status = Number(response?.status || 0);
  if (status >= 200 && status < 300) {
    if (!buffered || typeof buffered.json !== "function") {
      throw uncertainStartResponseError(
        "De serverbevestiging voor de berekening bevatte geen leesbare inhoud.",
      );
    }
    acceptedJobFields(await buffered.json());
  }
  return buffered;
}
