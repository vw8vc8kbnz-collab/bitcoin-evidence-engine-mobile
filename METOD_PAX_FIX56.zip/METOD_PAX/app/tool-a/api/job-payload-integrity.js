import { SHA256_HEX_PATTERN, cleanText, startStorageError } from "./job-api-shared.js";

function stableJson(value) {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map((item) => stableJson(item)).join(",")}]`;
  return `{${Object.keys(value)
    .sort()
    .map((key) => `${JSON.stringify(key)}:${stableJson(value[key])}`)
    .join(",")}}`;
}

function canonicalStartPayload(serializedPayload) {
  const payload = JSON.parse(serializedPayload);
  if (!payload || typeof payload !== "object" || Array.isArray(payload)) {
    throw new TypeError("A serialized job payload object is required");
  }
  if (payload.jobJson && typeof payload.jobJson === "object" && !Array.isArray(payload.jobJson)) {
    delete payload.jobJson.createdAt;
  }
  return stableJson(payload);
}

export function createJobPayloadIntegrity(options = {}) {
  const cryptoImpl = options.cryptoImpl || globalThis.crypto;
  const digestFactory = typeof options.digestFactory === "function" ? options.digestFactory : null;
  const TextEncoderImpl =
    typeof options.TextEncoderImpl === "function"
      ? options.TextEncoderImpl
      : globalThis.TextEncoder;

  async function digest(serializedPayload) {
    let canonicalPayload;
    try {
      canonicalPayload = canonicalStartPayload(serializedPayload);
    } catch (_error) {
      throw startStorageError(
        "De jobinvoer kon niet veilig worden gecontroleerd. Er is geen job gestart.",
      );
    }
    let result = "";
    if (digestFactory) {
      result = cleanText(await digestFactory(canonicalPayload)).toLowerCase();
    } else if (
      typeof cryptoImpl?.subtle?.digest === "function" &&
      typeof TextEncoderImpl === "function"
    ) {
      const bytes = new TextEncoderImpl().encode(canonicalPayload);
      const hash = await cryptoImpl.subtle.digest("SHA-256", bytes);
      result = Array.from(new Uint8Array(hash), (byte) => byte.toString(16).padStart(2, "0")).join(
        "",
      );
    }
    if (!SHA256_HEX_PATTERN.test(result)) {
      throw startStorageError(
        "Deze browser kan geen veilige herstelvingerafdruk maken. Er is geen job gestart.",
      );
    }
    return result;
  }

  function same(previousPayload, nextPayload) {
    if (previousPayload === nextPayload) return true;
    try {
      return canonicalStartPayload(previousPayload) === canonicalStartPayload(nextPayload);
    } catch (_error) {
      return false;
    }
  }

  return Object.freeze({ digest, same });
}
