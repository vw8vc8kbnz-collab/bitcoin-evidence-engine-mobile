import {
  acceptedJobFields,
  bufferedStartResponse,
  cleanText,
  markUncertainStartError,
  startStorageError,
  uncertainStartResponseError,
  validateStoredJobId,
} from "./job-api-shared.js";

export function createJobStartController(options = {}) {
  const now = options.now;
  const sleep = options.sleep;
  const startMaxAttempts = options.startMaxAttempts;
  const startRetryDelayMs = options.startRetryDelayMs;
  const reconcileMaxAttempts = options.reconcileMaxAttempts;
  const startAttemptTtlMs = options.startAttemptTtlMs;
  const idempotencyKeyFactory = options.idempotencyKeyFactory;
  const cryptoImpl = options.cryptoImpl;
  const persistEnabled = options.persistEnabled === true;
  const payloadIntegrity = options.payloadIntegrity;
  const storage = options.storage;
  const requestStart = options.requestStart;
  const requestReconcile = options.requestReconcile;
  const pollJob = options.pollJob;
  let unresolvedStartAttempt = null;
  let reconcilePromise = null;
  let resumePromise = null;
  let recoveredStart = null;
  let recoveredJobCapability = null;
  let reconciliationState = Object.freeze({
    state: "none",
    status: 0,
    expired: false,
    running: false,
  });

  function createStartIdempotencyKey() {
    let key = "";
    if (idempotencyKeyFactory) key = cleanText(idempotencyKeyFactory());
    else if (typeof cryptoImpl?.randomUUID === "function")
      key = `tool-a-${cryptoImpl.randomUUID()}`;
    else if (typeof cryptoImpl?.getRandomValues === "function") {
      const bytes = new Uint8Array(16);
      cryptoImpl.getRandomValues(bytes);
      key = `tool-a-${Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("")}`;
    }
    if (key.length < 16 || key.length > 128 || !/^[A-Za-z0-9._:-]+$/.test(key)) {
      throw new Error(
        "Een veilige startsleutel kon niet worden aangemaakt. Herlaad Tool A en probeer opnieuw.",
      );
    }
    return key;
  }

  function setState(state, status = 0, expired = false, running = false) {
    const messages = {
      checking: "Een eerdere berekening wordt veilig gecontroleerd.",
      ready: "Een eerdere berekening is veilig teruggevonden en kan worden hervat.",
      pending:
        "Het herstel van een eerdere berekening is nog bezig. Er is geen nieuwe berekening gestart.",
      uncertain:
        "Het herstel van een eerdere berekening is nog onzeker. Er is geen nieuwe berekening gestart.",
      absent: "De server bevestigde dat de eerdere jobstart niet bestaat.",
      none: "",
    };
    reconciliationState = Object.freeze({
      state,
      status: Number(status || 0),
      expired: expired === true,
      running: running === true,
      message: messages[state] || messages.uncertain,
    });
  }

  function getState() {
    return reconciliationState;
  }

  function uncertainStatus(status) {
    const value = Number(status || 0);
    return [408, 425, 429].includes(value) || value >= 500;
  }

  function retryDelay(response) {
    let requestedMs = 0;
    try {
      const raw = cleanText(response?.headers?.get?.("Retry-After"));
      if (raw && Number.isFinite(Number(raw))) requestedMs = Number(raw) * 1000;
      else if (raw) requestedMs = Date.parse(raw) - Date.now();
    } catch (_error) {
      requestedMs = 0;
    }
    return Math.min(5000, Math.max(100, requestedMs || startRetryDelayMs));
  }

  function rememberCapability(fields) {
    recoveredJobCapability = Object.freeze({
      jobId: fields.jobId,
      accessToken: fields.accessToken,
    });
  }

  function clearRecovery(key) {
    storage.clearRecovery(key);
    recoveredStart = null;
    recoveredJobCapability = null;
  }

  async function transitionAccepted(record, response) {
    const data = await response.json();
    const fields = acceptedJobFields(data);
    const running = storage.persistRunning(record) || Object.freeze({ ...record, kind: "running" });
    // Running is verified before pending is removed, so eviction always leaves
    // at least one durable GET-only authority.
    storage.clearPending(record.key);
    rememberCapability(fields);
    return Object.freeze({ running, fields });
  }

  async function performStart(attempt) {
    let lastError = null;
    for (let requestNumber = 1; requestNumber <= startMaxAttempts; requestNumber += 1) {
      let receivedStatus = 0;
      try {
        const response = await requestStart(attempt);
        receivedStatus = Number(response?.status || 0);
        if (receivedStatus >= 200 && receivedStatus < 300) {
          await transitionAccepted(
            {
              kind: "pending",
              key: attempt.idempotencyKey,
              timestamp: attempt.timestamp,
              payloadDigest: attempt.payloadDigest,
              expired: now() - attempt.timestamp > startAttemptTtlMs,
            },
            response,
          );
          if (unresolvedStartAttempt === attempt) unresolvedStartAttempt = null;
          return response;
        }
        if (uncertainStatus(receivedStatus)) {
          attempt.requiresReconcile = true;
          if (receivedStatus !== 425 || requestNumber === startMaxAttempts) return response;
          await sleep(retryDelay(response));
          continue;
        }
        storage.clearPending(attempt.idempotencyKey);
        if (unresolvedStartAttempt === attempt) unresolvedStartAttempt = null;
        return response;
      } catch (error) {
        lastError = error;
        receivedStatus ||= Number(error?.metodReceivedStatus || 0);
        if (receivedStatus && !(receivedStatus >= 200 && receivedStatus < 300)) {
          if (uncertainStatus(receivedStatus)) {
            attempt.requiresReconcile = true;
            if (receivedStatus === 425 && requestNumber < startMaxAttempts) {
              await sleep(retryDelay(null));
              continue;
            }
            throw markUncertainStartError(error);
          }
          storage.clearPending(attempt.idempotencyKey);
          if (unresolvedStartAttempt === attempt) unresolvedStartAttempt = null;
          throw error;
        }
        attempt.requiresReconcile = true;
        if (requestNumber === startMaxAttempts) throw markUncertainStartError(error);
        await sleep(retryDelay(null));
      }
    }
    throw lastError || new Error("De berekening kon niet veilig worden gestart.");
  }

  async function performReconciliation(record) {
    let lastError = null;
    for (let requestNumber = 1; requestNumber <= reconcileMaxAttempts; requestNumber += 1) {
      let receivedStatus = 0;
      try {
        const response = await requestReconcile(record);
        receivedStatus = Number(response?.status || 0);
        if (receivedStatus === 202) {
          const accepted = await transitionAccepted(record, response);
          recoveredStart = Object.freeze({
            response,
            record: accepted.running,
          });
          setState("ready", 202, record.expired, true);
          return response;
        }
        if (receivedStatus === 404) {
          clearRecovery(record.key);
          if (unresolvedStartAttempt?.idempotencyKey === record.key) unresolvedStartAttempt = null;
          setState("absent", 404, record.expired, false);
          return response;
        }
        if (receivedStatus === 425 && requestNumber < reconcileMaxAttempts) {
          setState("pending", 425, record.expired, record.kind === "running");
          await sleep(retryDelay(response));
          continue;
        }
        setState(
          receivedStatus === 425 ? "pending" : "uncertain",
          receivedStatus,
          record.expired,
          record.kind === "running",
        );
        return response;
      } catch (error) {
        lastError = error;
        receivedStatus ||= Number(error?.metodReceivedStatus || 0);
        if (receivedStatus === 404 && error?.metodRawResponse) {
          clearRecovery(record.key);
          if (unresolvedStartAttempt?.idempotencyKey === record.key) unresolvedStartAttempt = null;
          setState("absent", 404, record.expired, false);
          return bufferedStartResponse(error.metodRawResponse, "");
        }
        if (receivedStatus === 425 && requestNumber < reconcileMaxAttempts) {
          setState("pending", 425, record.expired, record.kind === "running");
          await sleep(retryDelay(null));
          continue;
        }
        setState("uncertain", receivedStatus, record.expired, record.kind === "running");
        throw markUncertainStartError(error);
      }
    }
    throw (
      lastError ||
      uncertainStartResponseError("De eerdere jobstart kon nog niet veilig worden gecontroleerd.")
    );
  }

  async function reconcilePendingStart() {
    if (reconcilePromise) return reconcilePromise;
    let record;
    try {
      record = storage.recovery();
    } catch (error) {
      setState("uncertain");
      throw error;
    }
    if (!record) {
      setState("none");
      return null;
    }
    setState("checking", 0, record.expired, record.kind === "running");
    reconcilePromise = performReconciliation(record);
    try {
      return await reconcilePromise;
    } finally {
      reconcilePromise = null;
    }
  }

  async function takeRecovered(serializedPayload) {
    const recovery = recoveredStart;
    if (!recovery) return null;
    const persisted = storage.recovery();
    if (!persisted || persisted.key !== recovery.record.key) {
      recoveredStart = null;
      return null;
    }
    if ((await payloadIntegrity.digest(serializedPayload)) !== recovery.record.payloadDigest) {
      setState("uncertain", 202, recovery.record.expired, true);
      throw uncertainStartResponseError(
        "De teruggevonden berekening hoort niet exact bij de huidige invoer. Er is geen nieuwe berekening gestart. Start bewust een nieuwe configuratie of herstel de oorspronkelijke invoer.",
      );
    }
    if (unresolvedStartAttempt?.idempotencyKey === recovery.record.key)
      unresolvedStartAttempt = null;
    setState("ready", 202, recovery.record.expired, true);
    return recovery.response;
  }

  async function startJob(serializedPayload) {
    if (typeof serializedPayload !== "string" || !serializedPayload) {
      throw new TypeError("A serialized job payload is required");
    }
    const cachedRecovery = await takeRecovered(serializedPayload);
    if (cachedRecovery) return cachedRecovery;
    if (reconcilePromise) {
      const response = await reconcilePromise;
      if (Number(response?.status || 0) === 202)
        return (await takeRecovered(serializedPayload)) || response;
      if (Number(response?.status || 0) !== 404) return response;
    }
    let attempt = unresolvedStartAttempt;
    const persisted = storage.recovery();
    if (attempt?.requiresReconcile || (!attempt && persisted)) {
      const response = await reconcilePendingStart();
      const status = Number(response?.status || 0);
      if (status === 202) return (await takeRecovered(serializedPayload)) || response;
      if (status && status !== 404) return response;
      attempt = unresolvedStartAttempt;
    }
    if (attempt && !payloadIntegrity.same(attempt.serializedPayload, serializedPayload)) {
      throw uncertainStartResponseError(
        "De bevestiging van de vorige berekening is nog onzeker. Probeer eerst exact dezelfde berekening opnieuw.",
      );
    }
    if (!attempt) {
      attempt = {
        serializedPayload,
        idempotencyKey: createStartIdempotencyKey(),
        timestamp: now(),
        payloadDigest: "",
        persisted: false,
        networkStarted: false,
        requiresReconcile: false,
        promise: null,
      };
      unresolvedStartAttempt = attempt;
    }
    if (attempt.promise) return attempt.promise;
    attempt.promise = (async () => {
      if (!attempt.persisted && persistEnabled) {
        if (!attempt.payloadDigest)
          attempt.payloadDigest = await payloadIntegrity.digest(attempt.serializedPayload);
        storage.persistPending(attempt);
        attempt.persisted = true;
      }
      return performStart(attempt);
    })();
    try {
      return await attempt.promise;
    } catch (error) {
      if (!attempt.networkStarted && unresolvedStartAttempt === attempt)
        unresolvedStartAttempt = null;
      throw error;
    } finally {
      attempt.promise = null;
    }
  }

  function clearTerminal(jobId) {
    const canonicalJobId = validateStoredJobId(jobId);
    const running = storage.running();
    if (!canonicalJobId || !running || recoveredJobCapability?.jobId !== canonicalJobId) return;
    clearRecovery(running.key);
    setState("none");
  }

  async function resumeRecoveredJob({ onProgress } = {}) {
    if (resumePromise) return resumePromise;
    resumePromise = (async () => {
      const response = recoveredStart?.response || (await reconcilePendingStart());
      if (Number(response?.status || 0) !== 202) return Object.freeze({ resumed: false, response });
      const fields = acceptedJobFields(await response.json());
      rememberCapability(fields);
      const result = await pollJob({
        jobId: fields.jobId,
        accessToken: fields.accessToken,
        onProgress,
      });
      return Object.freeze({
        resumed: true,
        jobId: fields.jobId,
        accessToken: fields.accessToken,
        result,
      });
    })();
    try {
      return await resumePromise;
    } finally {
      resumePromise = null;
    }
  }

  function resetJobRecovery() {
    storage.reset();
    unresolvedStartAttempt = null;
    recoveredStart = null;
    recoveredJobCapability = null;
    setState("none");
    return true;
  }

  return Object.freeze({
    startJob,
    reconcilePendingStart,
    resumeRecoveredJob,
    getStartReconciliationState: getState,
    resetJobRecovery,
    clearTerminal,
  });
}
