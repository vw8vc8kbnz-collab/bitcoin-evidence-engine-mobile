export function readBrowserSessionStorage(rootRef = globalThis) {
  try {
    const storage = rootRef?.sessionStorage || null;
    return storage &&
      typeof storage.getItem === "function" &&
      typeof storage.setItem === "function" &&
      typeof storage.removeItem === "function"
      ? storage
      : null;
  } catch (_error) {
    return null;
  }
}
