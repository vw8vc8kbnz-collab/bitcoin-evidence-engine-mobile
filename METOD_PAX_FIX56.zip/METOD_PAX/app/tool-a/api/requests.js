const SUBMIT_STATES = Object.freeze({
  IDLE: "idle",
  SUBMITTING: "submitting",
  COMMITTED: "committed",
  FAILED: "failed",
});
const DEFAULT_SUBMIT_REQUEST_TIMEOUT_MS = 60 * 1000;

function cleanText(value) {
  return String(value == null ? "" : value).trim();
}

function submissionError(message, details = {}) {
  const error = new Error(message);
  Object.assign(error, details, { isUserFacing: true });
  return error;
}

function positiveTimeout(value, fallback) {
  return Number.isFinite(Number(value)) ? Math.max(1, Number(value)) : fallback;
}

function markCommitUncertain(error, message) {
  const value =
    error instanceof Error
      ? error
      : submissionError(message || "De verzendstatus kon niet worden bevestigd.");
  try {
    value.metodCommitUncertain = true;
    value.isUserFacing = true;
    return value;
  } catch (_error) {
    return submissionError(message || value.message, {
      metodCommitUncertain: true,
      cause: value,
    });
  }
}

function jobTokenHeaders(accessToken) {
  const token = cleanText(accessToken);
  return token ? { Authorization: `Bearer ${token}` } : {};
}

function submissionWirePayload(context) {
  const parentJobId = cleanText(context?.parentJobId || context?.jobId);
  if (!parentJobId) {
    throw submissionError(
      "Geen afgeronde optimalisatie gevonden. Bereken de configuratie opnieuw.",
    );
  }
  const customer = context?.customer;
  if (!customer || typeof customer !== "object" || Array.isArray(customer)) {
    throw submissionError("De klantgegevens konden niet veilig worden klaargezet.");
  }
  return {
    jobId: parentJobId,
    parentJobId,
    customer,
    note: String(context?.note == null ? "" : context.note),
  };
}

async function responseJson(response) {
  try {
    return await response.json();
  } catch (error) {
    const status = Number(response?.status || 0);
    const possiblyCommitted =
      !status ||
      status === 408 ||
      status === 409 ||
      status === 425 ||
      status >= 500 ||
      (status >= 200 && status < 300);
    throw submissionError(
      "De serverbevestiging kon niet worden gelezen. Bevestig exact dezelfde aanvraag opnieuw.",
      {
        httpStatus: status || undefined,
        metodCommitUncertain: possiblyCommitted,
        cause: error,
      },
    );
  }
}

export function createRequestsApi(options = {}) {
  const assertCanMutate =
    typeof options.assertCanMutate === "function" ? options.assertCanMutate : () => true;
  const fetchWasInjected = typeof options.fetchImpl === "function";
  const fetchImpl = fetchWasInjected ? options.fetchImpl : (...args) => globalThis.fetch(...args);
  const submitRequestTimeoutMs = positiveTimeout(
    options.submitRequestTimeoutMs,
    DEFAULT_SUBMIT_REQUEST_TIMEOUT_MS,
  );
  const setTimeoutImpl =
    typeof options.setTimeoutImpl === "function"
      ? options.setTimeoutImpl
      : (...args) => globalThis.setTimeout(...args);
  const clearTimeoutImpl =
    typeof options.clearTimeoutImpl === "function"
      ? options.clearTimeoutImpl
      : (timerId) => globalThis.clearTimeout(timerId);
  const AbortControllerImpl =
    typeof options.AbortControllerImpl === "function"
      ? options.AbortControllerImpl
      : globalThis.AbortController;
  const useAbortSignal =
    options.useAbortSignal === true || (!fetchWasInjected && options.useAbortSignal !== false);
  const cryptoImpl = options.cryptoImpl || globalThis.crypto;
  const idempotencyKeyFactory =
    typeof options.idempotencyKeyFactory === "function" ? options.idempotencyKeyFactory : null;
  let unresolvedSubmitAttempt = null;

  function requestOptionsWithSignal(requestOptions, signal) {
    return signal ? { ...requestOptions, signal } : requestOptions;
  }

  function createSubmitIdempotencyKey() {
    let key = "";
    if (idempotencyKeyFactory) {
      key = cleanText(idempotencyKeyFactory());
    } else if (typeof cryptoImpl?.randomUUID === "function") {
      key = `tool-a-submit-${cryptoImpl.randomUUID()}`;
    } else if (typeof cryptoImpl?.getRandomValues === "function") {
      const bytes = new Uint8Array(16);
      cryptoImpl.getRandomValues(bytes);
      key = `tool-a-submit-${Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("")}`;
    }
    if (key.length < 16 || key.length > 128 || !/^[A-Za-z0-9._:-]+$/.test(key)) {
      throw submissionError(
        "Een veilige verzendsleutel kon niet worden aangemaakt. Herlaad Tool A en probeer opnieuw.",
      );
    }
    return key;
  }

  async function withSubmitDeadline(operation, getReceivedStatus = () => 0) {
    const controller =
      useAbortSignal && typeof AbortControllerImpl === "function"
        ? new AbortControllerImpl()
        : null;
    let timerId;
    const timeoutPromise = new Promise((_resolve, reject) => {
      timerId = setTimeoutImpl(() => {
        const receivedStatus = Number(getReceivedStatus() || 0);
        const possiblyCommitted =
          !receivedStatus ||
          receivedStatus === 408 ||
          receivedStatus === 409 ||
          receivedStatus === 425 ||
          receivedStatus >= 500 ||
          (receivedStatus >= 200 && receivedStatus < 300);
        reject(
          submissionError(
            "De serverbevestiging duurde te lang. De aanvraag kan al ontvangen zijn; controleer Admin voordat je opnieuw verzendt.",
            {
              name: "MetodRequestTimeoutError",
              code: "METOD_REQUEST_TIMEOUT",
              metodRequestTimeout: true,
              metodCommitUncertain: possiblyCommitted,
              httpStatus: receivedStatus || undefined,
              operation: "final_submit",
              timeoutMs: submitRequestTimeoutMs,
            },
          ),
        );
        controller?.abort();
      }, submitRequestTimeoutMs);
    });
    let operationPromise;
    try {
      operationPromise = Promise.resolve(operation(controller?.signal));
    } catch (error) {
      operationPromise = Promise.reject(error);
    }
    try {
      return await Promise.race([operationPromise, timeoutPromise]);
    } finally {
      clearTimeoutImpl(timerId);
    }
  }

  function prepareSubmitAttempt(context) {
    const payload = submissionWirePayload(context);
    const serializedPayload = JSON.stringify(payload);
    if (unresolvedSubmitAttempt) {
      if (unresolvedSubmitAttempt.serializedPayload !== serializedPayload) {
        throw submissionError(
          "De status van de vorige aanvraag is nog onzeker. Bevestig eerst exact dezelfde aanvraag opnieuw.",
          {
            code: "METOD_SUBMISSION_UNCERTAIN",
            metodCommitUncertain: true,
          },
        );
      }
      return unresolvedSubmitAttempt;
    }
    const attempt = {
      payload,
      serializedPayload,
      idempotencyKey: createSubmitIdempotencyKey(),
      promise: null,
    };
    unresolvedSubmitAttempt = attempt;
    return attempt;
  }

  async function performSubmitConfiguration(attempt, accessToken) {
    let receivedStatus = 0;
    try {
      const committed = await withSubmitDeadline(
        async (signal) => {
          let response;
          try {
            response = await fetchImpl(
              "/api/submit_config",
              requestOptionsWithSignal(
                {
                  method: "POST",
                  headers: {
                    "Content-Type": "application/json",
                    "Idempotency-Key": attempt.idempotencyKey,
                    ...jobTokenHeaders(accessToken),
                  },
                  body: attempt.serializedPayload,
                },
                signal,
              ),
            );
          } catch (error) {
            throw markCommitUncertain(
              error,
              "De verbinding viel weg tijdens het verzenden. Bevestig exact dezelfde aanvraag opnieuw.",
            );
          }
          receivedStatus = Number(response?.status || 0);
          const data = await responseJson(response);
          if (!response.ok || data?.ok === false) {
            const message =
              cleanText(data?.error || data?.message) ||
              `Verzenden is geweigerd (HTTP ${response.status}).`;
            const inProgress =
              receivedStatus === 409 && /wordt al verwerkt|bestaande aanvraag/i.test(message);
            throw submissionError(message, {
              httpStatus: response.status,
              metodCommitUncertain:
                inProgress ||
                receivedStatus === 408 ||
                receivedStatus === 425 ||
                receivedStatus >= 500,
            });
          }
          const requestId = cleanText(data?.requestId);
          const cancelToken = cleanText(data?.cancelToken);
          if (!requestId || !cancelToken) {
            throw submissionError(
              !requestId
                ? "De server bevestigde geen aanvraagreferentie. Bevestig exact dezelfde aanvraag opnieuw."
                : "De server bevestigde geen beveiligde annuleercode. Bevestig exact dezelfde aanvraag opnieuw.",
              { metodCommitUncertain: true },
            );
          }
          return Object.freeze({
            requestId,
            cancelToken,
            pricingSummary: data?.pricingSummary || null,
            response: data,
            parentJobId: attempt.payload.parentJobId,
            customer: attempt.payload.customer,
            note: attempt.payload.note,
          });
        },
        () => receivedStatus,
      );
      if (unresolvedSubmitAttempt === attempt) unresolvedSubmitAttempt = null;
      return committed;
    } catch (error) {
      if (!error?.metodCommitUncertain && unresolvedSubmitAttempt === attempt) {
        unresolvedSubmitAttempt = null;
      }
      throw error;
    }
  }

  async function submitConfiguration(context = {}) {
    assertCanMutate();
    const attempt = prepareSubmitAttempt(context);
    if (attempt.promise) return attempt.promise;
    attempt.promise = performSubmitConfiguration(attempt, context.accessToken);
    try {
      return await attempt.promise;
    } finally {
      attempt.promise = null;
    }
  }

  return Object.freeze({ submitConfiguration });
}

async function safeCallback(callback, value) {
  if (typeof callback !== "function") return null;
  try {
    await callback(value);
    return null;
  } catch (error) {
    return error;
  }
}

export function createFinalSubmitAction(options = {}) {
  const requestsApi = options.requestsApi || createRequestsApi(options);
  let status = SUBMIT_STATES.IDLE;
  let committedRequestId = "";
  let committedParentJobId = "";

  function getState() {
    return Object.freeze({ status, committedRequestId, committedParentJobId });
  }

  function reset() {
    status = SUBMIT_STATES.IDLE;
    committedRequestId = "";
    committedParentJobId = "";
    return getState();
  }

  async function submit(context = {}, callbacks = {}) {
    if (status === SUBMIT_STATES.SUBMITTING || status === SUBMIT_STATES.COMMITTED) {
      return Object.freeze({ ok: false, ignored: true, state: getState() });
    }

    const parentJobId = cleanText(context?.parentJobId || context?.jobId);
    if (!parentJobId) {
      const error = submissionError(
        "Geen afgeronde optimalisatie gevonden. Bereken de configuratie opnieuw.",
      );
      status = SUBMIT_STATES.FAILED;
      await safeCallback(callbacks.onFailed, Object.freeze({ error, state: getState() }));
      return Object.freeze({ ok: false, error, state: getState() });
    }
    if (context?.jobComplete !== true) {
      const error = submissionError(
        "De optimalisatie is nog niet volledig afgerond. Wacht op de definitieve prijs.",
      );
      status = SUBMIT_STATES.FAILED;
      await safeCallback(callbacks.onFailed, Object.freeze({ error, state: getState() }));
      return Object.freeze({ ok: false, error, state: getState() });
    }

    status = SUBMIT_STATES.SUBMITTING;
    await safeCallback(callbacks.onSubmitting, Object.freeze({ parentJobId, state: getState() }));
    try {
      const committed = await requestsApi.submitConfiguration({
        ...context,
        parentJobId,
      });
      committedRequestId = committed.requestId;
      committedParentJobId = parentJobId;
      status = SUBMIT_STATES.COMMITTED;
      const uiError = await safeCallback(
        callbacks.onCommitted,
        Object.freeze({ committed, state: getState() }),
      );
      return Object.freeze({ ok: true, committed, uiError, state: getState() });
    } catch (error) {
      status = SUBMIT_STATES.FAILED;
      await safeCallback(callbacks.onFailed, Object.freeze({ error, state: getState() }));
      return Object.freeze({ ok: false, error, state: getState() });
    } finally {
      await safeCallback(callbacks.onSettled, getState());
    }
  }

  return Object.freeze({ submit, reset, getState });
}

export { SUBMIT_STATES };
