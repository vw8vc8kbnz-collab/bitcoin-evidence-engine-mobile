import {
  SHA256_HEX_PATTERN,
  cleanText,
  startStorageError,
  validateStoredStartKey,
} from "./job-api-shared.js";

export const START_ATTEMPT_STORAGE_KEY = "metod_pending_job_start_v1";
export const RUNNING_JOB_STORAGE_KEY = "metod_running_job_v1";
const STORAGE_VERSION = 1;
const RECORD_MAX_CHARS = 512;

export function createJobRecoveryStorage(options = {}) {
  const storage = options.storage || null;
  const requirePersistent = options.requirePersistent === true;
  const now = typeof options.now === "function" ? options.now : () => Date.now();
  const ttlMs = Number(options.ttlMs);

  function persistentStorageOrNull() {
    if (storage) return storage;
    if (requirePersistent) {
      throw startStorageError(
        "De veilige herstelstatus kan niet in dit browsertabblad worden bewaard. Sta sessieopslag toe en herlaad Tool A voordat je de berekening start.",
      );
    }
    return null;
  }

  function readRaw(storageKey, label) {
    const target = persistentStorageOrNull();
    if (!target) return "";
    let raw = "";
    try {
      raw = String(target.getItem(storageKey) || "");
    } catch (_error) {
      throw startStorageError(
        `${label} kon niet uit dit browsertabblad worden gelezen. Er is geen nieuwe job gestart.`,
      );
    }
    if (raw.length > RECORD_MAX_CHARS) {
      throw startStorageError(
        `${label} is ongeldig. Start bewust een nieuwe configuratie om deze status veilig te wissen.`,
      );
    }
    return raw;
  }

  function parseRecord(raw, kind, label) {
    if (!raw) return null;
    let record;
    try {
      record = JSON.parse(raw);
    } catch (_error) {
      throw startStorageError(
        `${label} is onleesbaar. Start bewust een nieuwe configuratie om deze status veilig te wissen.`,
      );
    }
    const keys =
      record && typeof record === "object" && !Array.isArray(record)
        ? Object.keys(record).sort()
        : [];
    const key = validateStoredStartKey(record?.key);
    const payloadDigest = cleanText(record?.payloadDigest).toLowerCase();
    const timestamp = Number(record?.timestamp);
    if (
      keys.join(",") !== "key,payloadDigest,timestamp,version" ||
      record?.version !== STORAGE_VERSION ||
      !key ||
      !SHA256_HEX_PATTERN.test(payloadDigest) ||
      !Number.isFinite(timestamp) ||
      timestamp < 0 ||
      timestamp > now() + 5 * 60 * 1000
    ) {
      throw startStorageError(
        `${label} is ongeldig. Start bewust een nieuwe configuratie om deze status veilig te wissen.`,
      );
    }
    return Object.freeze({
      kind,
      version: STORAGE_VERSION,
      key,
      timestamp,
      payloadDigest,
      expired: now() - timestamp > ttlMs,
    });
  }

  function pending() {
    return parseRecord(
      readRaw(START_ATTEMPT_STORAGE_KEY, "De bewaarde herstelstatus"),
      "pending",
      "De bewaarde herstelstatus",
    );
  }

  function running() {
    return parseRecord(
      readRaw(RUNNING_JOB_STORAGE_KEY, "De bewaarde actieve jobreferentie"),
      "running",
      "De bewaarde actieve jobreferentie",
    );
  }

  function recovery() {
    const pendingRecord = pending();
    const runningRecord = running();
    if (
      pendingRecord &&
      runningRecord &&
      (pendingRecord.key !== runningRecord.key ||
        pendingRecord.payloadDigest !== runningRecord.payloadDigest ||
        pendingRecord.timestamp !== runningRecord.timestamp)
    ) {
      throw startStorageError(
        "De bewaarde jobherstelstatus spreekt zichzelf tegen. Er is geen nieuwe job gestart.",
      );
    }
    return runningRecord || pendingRecord;
  }

  function serialize(record) {
    const raw = JSON.stringify({
      version: STORAGE_VERSION,
      key: record.key,
      timestamp: record.timestamp,
      payloadDigest: record.payloadDigest,
    });
    if (raw.length > RECORD_MAX_CHARS) {
      throw startStorageError(
        "De veilige herstelstatus is onverwacht te groot. Er is geen job gestart.",
      );
    }
    return raw;
  }

  function verifiedWrite(storageKey, raw, message) {
    const target = persistentStorageOrNull();
    if (!target) return;
    try {
      target.setItem(storageKey, raw);
      if (target.getItem(storageKey) !== raw) throw new Error("storage verification failed");
    } catch (_error) {
      throw startStorageError(message);
    }
  }

  function persistPending(attempt) {
    const target = persistentStorageOrNull();
    if (!target) return null;
    const existing = recovery();
    if (existing && existing.key !== attempt.idempotencyKey) {
      throw startStorageError(
        "Een eerdere jobstart moet eerst veilig worden gecontroleerd. Er is geen nieuwe job gestart.",
      );
    }
    if (existing?.kind === "running") {
      throw startStorageError(
        "Een actieve berekening moet eerst worden hervat of bewust worden gewist. Er is geen nieuwe job gestart.",
      );
    }
    verifiedWrite(
      START_ATTEMPT_STORAGE_KEY,
      serialize({
        key: attempt.idempotencyKey,
        timestamp: attempt.timestamp,
        payloadDigest: attempt.payloadDigest,
      }),
      "De veilige herstelstatus kon niet worden bewaard. Maak opslagruimte vrij of sta sessieopslag toe; er is geen job gestart.",
    );
    return pending();
  }

  function persistRunning(record) {
    const target = persistentStorageOrNull();
    if (!target) return null;
    const existing = running();
    if (
      existing &&
      (existing.key !== record.key ||
        existing.payloadDigest !== record.payloadDigest ||
        existing.timestamp !== record.timestamp)
    ) {
      throw startStorageError(
        "Een andere actieve berekening is al bewaard. De huidige serverbevestiging blijft onzeker.",
      );
    }
    verifiedWrite(
      RUNNING_JOB_STORAGE_KEY,
      serialize(record),
      "De geaccepteerde job kon niet veilig voor herstel worden bewaard. Herlaad Tool A; dezelfde start blijft geblokkeerd voor controle.",
    );
    return running();
  }

  function verifiedRemove(storageKey, message, expectedKey = "", readRecord = null) {
    const target = persistentStorageOrNull();
    if (!target) return;
    const existing = readRecord?.();
    if (readRecord && (!existing || (expectedKey && existing.key !== expectedKey))) return;
    try {
      target.removeItem(storageKey);
      if (target.getItem(storageKey)) throw new Error("storage removal verification failed");
    } catch (_error) {
      throw startStorageError(message);
    }
  }

  function clearPending(expectedKey) {
    verifiedRemove(
      START_ATTEMPT_STORAGE_KEY,
      "De afgehandelde herstelstatus kon niet veilig worden gewist. Herlaad Tool A en probeer dezelfde handeling opnieuw.",
      expectedKey,
      pending,
    );
  }

  function clearRunning(expectedKey) {
    verifiedRemove(
      RUNNING_JOB_STORAGE_KEY,
      "De afgehandelde actieve jobreferentie kon niet veilig worden gewist. Herlaad Tool A voordat je opnieuw rekent.",
      expectedKey,
      running,
    );
  }

  function clearRecovery(expectedKey) {
    clearRunning(expectedKey);
    clearPending(expectedKey);
  }

  function reset() {
    const target = persistentStorageOrNull();
    if (!target) return true;
    try {
      target.removeItem(START_ATTEMPT_STORAGE_KEY);
      target.removeItem(RUNNING_JOB_STORAGE_KEY);
      if (target.getItem(START_ATTEMPT_STORAGE_KEY) || target.getItem(RUNNING_JOB_STORAGE_KEY)) {
        throw new Error("storage removal verification failed");
      }
    } catch (_error) {
      throw startStorageError(
        "De jobherstelstatus kon niet volledig worden gewist. Herlaad Tool A voordat je opnieuw rekent.",
      );
    }
    return true;
  }

  return Object.freeze({
    pending,
    running,
    recovery,
    persistPending,
    persistRunning,
    clearPending,
    clearRecovery,
    reset,
  });
}

export const JOB_RECOVERY_STORAGE_DEFAULTS = Object.freeze({
  startAttemptStorageKey: START_ATTEMPT_STORAGE_KEY,
  runningJobStorageKey: RUNNING_JOB_STORAGE_KEY,
  recordMaxChars: RECORD_MAX_CHARS,
});
