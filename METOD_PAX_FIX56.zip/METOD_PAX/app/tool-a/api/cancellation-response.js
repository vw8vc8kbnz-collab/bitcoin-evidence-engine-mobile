/** Confirm only the cancellation contract returned for this exact operation. */
function isRecord(data) {
  return data !== null && typeof data === "object" && !Array.isArray(data);
}

function jobState(data) {
  return String(
    data?.state ||
      data?.status ||
      data?.publicStatus ||
      data?.meta?.state ||
      data?.meta?.status ||
      "",
  )
    .trim()
    .toLowerCase();
}

export function isJobCancellationConfirmed(response, data, jobId) {
  if (!jobId || !isRecord(data) || data.jobId !== jobId) return false;
  const state = jobState(data);
  if (response?.status === 409 && data.ok === false) {
    // A completed job may be left locally; its sealed history stays on the server.
    return ["done", "ready", "ok", "cancelled", "canceled"].includes(state);
  }
  return (
    response?.status === 200 &&
    response.ok === true &&
    data.ok === true &&
    ["cancelled", "canceled"].includes(state)
  );
}

export function isRequestCancellationConfirmed(response, data, requestId) {
  return Boolean(
    requestId &&
      response?.status === 200 &&
      response.ok === true &&
      isRecord(data) &&
      data.ok === true &&
      data.requestId === requestId &&
      data.cancelled === true,
  );
}
