import { createJobPayloadIntegrity } from "./job-payload-integrity.js";
import { createJobStartController } from "./job-start-controller.js";
import { createJobStatusController } from "./job-status-controller.js";

import {
  authoritativeTotalInclVat,
  buildJobTokenHeaders,
  bufferedStartResponse,
  normalizeJobId,
  positiveInteger,
  positiveTimeout,
  readAndBufferStartResponse,
  requestTimeoutError,
} from "./job-api-shared.js";

import { createJobRecoveryStorage, JOB_RECOVERY_STORAGE_DEFAULTS } from "./job-recovery-storage.js";

const DEFAULT_MAX_TOTAL_MS = 30 * 60 * 1000;
const DEFAULT_MAX_STATUS_OUTAGE_MS = 2 * 60 * 1000;
const DEFAULT_START_REQUEST_TIMEOUT_MS = 60 * 1000;
const DEFAULT_START_MAX_ATTEMPTS = 3;
const DEFAULT_START_RETRY_DELAY_MS = 750;
const DEFAULT_RECONCILE_REQUEST_TIMEOUT_MS = 20 * 1000;
const DEFAULT_RECONCILE_MAX_ATTEMPTS = 3;
const DEFAULT_START_ATTEMPT_TTL_MS = 24 * 60 * 60 * 1000;
const DEFAULT_STATUS_REQUEST_TIMEOUT_MS = 20 * 1000;
const DEFAULT_PRICING_REQUEST_TIMEOUT_MS = 20 * 1000;
const DEFAULT_CANCEL_REQUEST_TIMEOUT_MS = 20 * 1000;

export { authoritativeTotalInclVat, buildJobTokenHeaders };

export function createJobsApi(options = {}) {
  const assertCanMutate =
    typeof options.assertCanMutate === "function" ? options.assertCanMutate : () => true;
  const fetchWasInjected = typeof options.fetchImpl === "function";
  const fetchImpl = fetchWasInjected ? options.fetchImpl : (...args) => globalThis.fetch(...args);
  const now = typeof options.now === "function" ? options.now : () => Date.now();
  const sleep =
    typeof options.sleep === "function"
      ? options.sleep
      : (milliseconds) => new Promise((resolve) => globalThis.setTimeout(resolve, milliseconds));
  const maxTotalMs = positiveTimeout(options.maxTotalMs, DEFAULT_MAX_TOTAL_MS);
  const maxStatusOutageMs = positiveTimeout(
    options.maxStatusOutageMs,
    DEFAULT_MAX_STATUS_OUTAGE_MS,
  );
  const startRequestTimeoutMs = positiveTimeout(
    options.startRequestTimeoutMs,
    DEFAULT_START_REQUEST_TIMEOUT_MS,
  );
  const startMaxAttempts = positiveInteger(options.startMaxAttempts, DEFAULT_START_MAX_ATTEMPTS, 5);
  const startRetryDelayMs = positiveTimeout(
    options.startRetryDelayMs,
    DEFAULT_START_RETRY_DELAY_MS,
  );
  const reconcileRequestTimeoutMs = positiveTimeout(
    options.reconcileRequestTimeoutMs,
    DEFAULT_RECONCILE_REQUEST_TIMEOUT_MS,
  );
  const reconcileMaxAttempts = positiveInteger(
    options.reconcileMaxAttempts,
    DEFAULT_RECONCILE_MAX_ATTEMPTS,
    5,
  );
  const startAttemptTtlMs = Math.min(
    30 * 24 * 60 * 60 * 1000,
    positiveTimeout(options.startAttemptTtlMs, DEFAULT_START_ATTEMPT_TTL_MS),
  );
  const statusRequestTimeoutMs = positiveTimeout(
    options.statusRequestTimeoutMs,
    DEFAULT_STATUS_REQUEST_TIMEOUT_MS,
  );
  const pricingRequestTimeoutMs = positiveTimeout(
    options.pricingRequestTimeoutMs,
    DEFAULT_PRICING_REQUEST_TIMEOUT_MS,
  );
  const cancelRequestTimeoutMs = positiveTimeout(
    options.cancelRequestTimeoutMs,
    DEFAULT_CANCEL_REQUEST_TIMEOUT_MS,
  );
  const setTimeoutImpl =
    typeof options.setTimeoutImpl === "function"
      ? options.setTimeoutImpl
      : (...args) => globalThis.setTimeout(...args);
  const clearTimeoutImpl =
    typeof options.clearTimeoutImpl === "function"
      ? options.clearTimeoutImpl
      : (timerId) => globalThis.clearTimeout(timerId);
  const AbortControllerImpl =
    typeof options.AbortControllerImpl === "function"
      ? options.AbortControllerImpl
      : globalThis.AbortController;
  const useAbortSignal =
    options.useAbortSignal === true || (!fetchWasInjected && options.useAbortSignal !== false);
  const cryptoImpl = options.cryptoImpl || globalThis.crypto;
  const attemptStorage =
    options.attemptStorage &&
    typeof options.attemptStorage.getItem === "function" &&
    typeof options.attemptStorage.setItem === "function" &&
    typeof options.attemptStorage.removeItem === "function"
      ? options.attemptStorage
      : null;
  const requirePersistent = options.requirePersistentStartAttempt === true;

  function requestOptionsWithSignal(requestOptions, signal) {
    return signal ? { ...requestOptions, signal } : requestOptions;
  }

  async function withRequestDeadline(operation, timeoutMs, timeoutFactory) {
    const controller =
      useAbortSignal && typeof AbortControllerImpl === "function"
        ? new AbortControllerImpl()
        : null;
    let timerId;
    const timeoutPromise = new Promise((_resolve, reject) => {
      timerId = setTimeoutImpl(() => {
        reject(timeoutFactory());
        controller?.abort();
      }, timeoutMs);
    });
    let operationPromise;
    try {
      operationPromise = Promise.resolve(operation(controller?.signal));
    } catch (error) {
      operationPromise = Promise.reject(error);
    }
    try {
      return await Promise.race([operationPromise, timeoutPromise]);
    } finally {
      clearTimeoutImpl(timerId);
    }
  }

  async function requestStart(attempt) {
    assertCanMutate();
    let receivedStatus = 0;
    let rawResponse = null;
    try {
      return await withRequestDeadline(
        async (signal) => {
          attempt.networkStarted = true;
          rawResponse = await fetchImpl(
            "/api/jobs",
            requestOptionsWithSignal(
              {
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                  "Idempotency-Key": attempt.idempotencyKey,
                },
                body: attempt.serializedPayload,
              },
              signal,
            ),
          );
          receivedStatus = Number(rawResponse?.status || 0);
          return readAndBufferStartResponse(rawResponse);
        },
        startRequestTimeoutMs,
        () =>
          requestTimeoutError(
            "De serverbevestiging voor de berekening duurde te lang. Dezelfde veilige start wordt opnieuw gecontroleerd.",
            "job_start",
            startRequestTimeoutMs,
          ),
      );
    } catch (error) {
      error.metodReceivedStatus = receivedStatus;
      error.metodRawResponse = rawResponse;

      throw error;
    }
  }

  async function requestReconcile(record) {
    let receivedStatus = 0;
    let rawResponse = null;
    try {
      return await withRequestDeadline(
        async (signal) => {
          rawResponse = await fetchImpl(
            "/api/jobs/reconcile",
            requestOptionsWithSignal(
              {
                method: "GET",
                cache: "no-store",
                headers: { "Idempotency-Key": record.key },
              },
              signal,
            ),
          );
          receivedStatus = Number(rawResponse?.status || 0);
          return readAndBufferStartResponse(rawResponse);
        },
        reconcileRequestTimeoutMs,
        () =>
          requestTimeoutError(
            "De eerdere jobstart kon niet op tijd worden gecontroleerd. Er is geen nieuwe job gestart.",
            "job_start_reconcile",
            reconcileRequestTimeoutMs,
          ),
      );
    } catch (error) {
      error.metodReceivedStatus = receivedStatus;
      error.metodRawResponse = rawResponse;

      throw error;
    }
  }

  async function readStatus(jobId, accessToken, timeoutMs, readTerminalErrorBody = false) {
    return withRequestDeadline(
      async (signal) => {
        const response = await fetchImpl(
          `/api/jobs/${encodeURIComponent(normalizeJobId(jobId))}/status`,
          requestOptionsWithSignal(
            {
              cache: "no-store",
              headers: buildJobTokenHeaders(accessToken),
            },
            signal,
          ),
        );
        if (response.ok) return { response, data: await response.json(), rawStatusBody: "" };
        const terminalClientError =
          response.status >= 400 &&
          response.status < 500 &&
          ![408, 425, 429].includes(response.status);
        const rawStatusBody =
          readTerminalErrorBody && terminalClientError ? await response.text() : "";
        return { response, data: null, rawStatusBody };
      },
      timeoutMs,
      () =>
        requestTimeoutError(
          "De serverstatus reageerde niet op tijd. De job kan nog op de server draaien.",
          "job_status",
          timeoutMs,
        ),
    );
  }

  async function cancelRequest({ jobId, accessToken, reason }) {
    return withRequestDeadline(
      async (signal) => {
        const response = await fetchImpl(
          "/api/jobs/cancel",
          requestOptionsWithSignal(
            {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
                ...buildJobTokenHeaders(accessToken),
              },
              body: JSON.stringify({ jobId, reason }),
            },
            signal,
          ),
        );
        // Reading the confirmation body shares the transport deadline. Keep a
        // buffered copy for both the recovery owner and the cancellation UI.
        return bufferedStartResponse(response, await response.text());
      },
      cancelRequestTimeoutMs,
      () =>
        requestTimeoutError(
          "Annuleren duurde te lang. Controleer de jobstatus voordat je het opnieuw probeert.",
          "job_cancel",
          cancelRequestTimeoutMs,
        ),
    );
  }

  const recoveryStorage = createJobRecoveryStorage({
    storage: attemptStorage,
    requirePersistent,
    now,
    ttlMs: startAttemptTtlMs,
  });
  const payloadIntegrity = createJobPayloadIntegrity({
    cryptoImpl,
    digestFactory:
      typeof options.payloadDigestFactory === "function" ? options.payloadDigestFactory : null,
    TextEncoderImpl: options.TextEncoderImpl,
  });
  let startController = null;
  const statusController = createJobStatusController({
    now,
    sleep,
    maxTotalMs,
    maxStatusOutageMs,
    statusRequestTimeoutMs,
    pricingRequestTimeoutMs,
    readStatus,
    cancelRequest,
    clearTerminal: (jobId) => startController?.clearTerminal(jobId),
  });
  startController = createJobStartController({
    now,
    sleep,
    startMaxAttempts,
    startRetryDelayMs,
    reconcileMaxAttempts,
    startAttemptTtlMs,
    idempotencyKeyFactory:
      typeof options.idempotencyKeyFactory === "function" ? options.idempotencyKeyFactory : null,
    cryptoImpl,
    persistEnabled: Boolean(attemptStorage || requirePersistent),
    payloadIntegrity,
    storage: recoveryStorage,
    requestStart,
    requestReconcile,
    pollJob: (pollOptions) => statusController.pollJob(pollOptions),
  });

  return Object.freeze({
    startJob: startController.startJob,
    reconcilePendingStart: startController.reconcilePendingStart,
    resumeRecoveredJob: startController.resumeRecoveredJob,
    getStartReconciliationState: startController.getStartReconciliationState,
    resetJobRecovery: startController.resetJobRecovery,
    cancelJob: statusController.cancelJob,
    pollJob: statusController.pollJob,
    fetchPricingSummary: statusController.fetchPricingSummary,
    authoritativeTotalInclVat,
  });
}

export const JOB_API_DEFAULTS = Object.freeze({
  maxTotalMs: DEFAULT_MAX_TOTAL_MS,
  maxStatusOutageMs: DEFAULT_MAX_STATUS_OUTAGE_MS,
  startRequestTimeoutMs: DEFAULT_START_REQUEST_TIMEOUT_MS,
  startMaxAttempts: DEFAULT_START_MAX_ATTEMPTS,
  startRetryDelayMs: DEFAULT_START_RETRY_DELAY_MS,
  reconcileRequestTimeoutMs: DEFAULT_RECONCILE_REQUEST_TIMEOUT_MS,
  reconcileMaxAttempts: DEFAULT_RECONCILE_MAX_ATTEMPTS,
  startAttemptTtlMs: DEFAULT_START_ATTEMPT_TTL_MS,
  startAttemptStorageKey: JOB_RECOVERY_STORAGE_DEFAULTS.startAttemptStorageKey,
  runningJobStorageKey: JOB_RECOVERY_STORAGE_DEFAULTS.runningJobStorageKey,
  statusRequestTimeoutMs: DEFAULT_STATUS_REQUEST_TIMEOUT_MS,
  pricingRequestTimeoutMs: DEFAULT_PRICING_REQUEST_TIMEOUT_MS,
  cancelRequestTimeoutMs: DEFAULT_CANCEL_REQUEST_TIMEOUT_MS,
});
