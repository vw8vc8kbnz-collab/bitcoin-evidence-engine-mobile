/* Shared browser error boundary. Only fixed operation codes and error classes
 * enter this bounded in-memory record; messages, payloads and tokens never do. */
(function installErrorBoundary(root) {
  "use strict";
  if (root.ToolAErrors) return;
  const records = new Map();
  const knownNames = new Set([
    "Error",
    "TypeError",
    "ReferenceError",
    "SyntaxError",
    "RangeError",
    "AbortError",
    "SecurityError",
    "QuotaExceededError",
    "InvalidStateError",
    "NotSupportedError",
    "NetworkError",
    "TimeoutError",
  ]);
  let failed = false;
  let bannerPending = false;

  function record(code, error, severity) {
    if (!/^[A-Za-z0-9_.:-]{1,160}$/.test(code)) throw new TypeError("Invalid operation code");
    const name = knownNames.has(error?.name) ? error.name : "Error";
    const key = code + ":" + name + ":" + severity;
    const previous = records.get(key);
    if (previous) {
      previous.count++;
      return;
    }
    if (records.size >= 64) records.delete(records.keys().next().value);
    records.set(key, { code, name, severity, count: 1 });
    root.console?.warn?.("[Tool A]", code, name, severity);
  }

  function showFailure() {
    const document = root.document;
    if (!document?.body) {
      if (document && !bannerPending) {
        bannerPending = true;
        document.addEventListener?.("DOMContentLoaded", showFailure, {
          once: true,
        });
      }
      return;
    }
    if (document.getElementById("applicationFailure")) return;
    const banner = document.createElement("div");
    banner.id = "applicationFailure";
    banner.className = "applicationFailure";
    banner.setAttribute("role", "alert");
    banner.textContent =
      "Deze handeling is niet goed afgerond. Herlaad de pagina voordat je verdergaat.";
    document.body.prepend(banner);
    document.body.dataset.applicationFailed = "true";
  }

  function stop(code, error) {
    failed = true;
    record(code, error, "blocking");
    showFailure();
  }

  function recover(code, error, expectedNames) {
    if (!Array.isArray(expectedNames) || !expectedNames.includes(error?.name)) {
      stop(code, error);
      throw error;
    }
    record(code, error, "recovered");
  }

  function assertHealthy() {
    if (failed) throw new Error("Herlaad de pagina: een eerdere handeling is niet goed afgerond.");
  }

  const api = Object.freeze({
    recover,
    stop,
    assertHealthy,
    hasFailed: () => failed,
    snapshot: () => Object.freeze(Array.from(records.values(), (row) => Object.freeze({ ...row }))),
  });
  Object.defineProperty(root, "ToolAErrors", {
    value: api,
    writable: false,
    configurable: false,
  });
  root.addEventListener?.("error", (event) => {
    // Resource load errors have no Error object; the owning loader provides its retry UI.
    if (event.error) stop("window.error", event.error);
  });
  root.addEventListener?.("unhandledrejection", (event) => stop("promise.unhandled", event.reason));
  root.document?.addEventListener?.(
    "click",
    (event) => {
      if (failed && event.target?.closest?.('button, input[type="submit"], [role="button"]')) {
        event.preventDefault();
        event.stopImmediatePropagation();
        showFailure();
      }
    },
    true,
  );
  root.document?.addEventListener?.(
    "submit",
    (event) => {
      if (failed) {
        event.preventDefault();
        event.stopImmediatePropagation();
        showFailure();
      }
    },
    true,
  );
})(globalThis);
