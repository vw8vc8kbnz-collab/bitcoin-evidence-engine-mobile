import { REVISION } from "../version.js";

export var ToolACustomerValidation;

export function mount() {
  (function (root) {
    "use strict";

    const BUILD = REVISION;
    // Byte-for-behaviour equivalent to metod_app.contracts.submission.EMAIL_RE.
    const EMAIL_PATTERN_SOURCE = "^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$";
    const EMAIL_RE = new RegExp(EMAIL_PATTERN_SOURCE);
    const BASE_REQUIRED_IDS = Object.freeze([
      "custFirstName",
      "custLastName",
      "custEmail",
      "custPhone",
      "custBillingAddress",
      "custPostcode",
      "custHouseNumber",
      "custCity",
      "custCountry",
    ]);
    const FIELD_KEYS = Object.freeze({
      custFirstName: "firstName",
      custLastName: "lastName",
      custEmail: "email",
      custPhone: "phone",
      custBillingAddress: "billingAddress",
      custPostcode: "postcode",
      custHouseNumber: "houseNumber",
      custCity: "city",
      custCountry: "country",
      custShippingCity: "shippingCity",
      custShippingCountry: "shippingCountry",
      custShippingAddress: "shippingAddress",
      custShippingPostcode: "shippingPostcode",
      custShippingHouseNumber: "shippingHouseNumber",
    });
    const LABELS = Object.freeze({
      custFirstName: "Voornaam",
      custLastName: "Achternaam",
      custEmail: "E-mail",
      custPhone: "Telefoonnummer",
      custBillingAddress: "Factuuradres",
      custPostcode: "Postcode",
      custHouseNumber: "Huisnummer",
      custCity: "Woonplaats",
      custCountry: "Land",
      custShippingCity: "Woonplaats bezorgadres",
      custShippingCountry: "Land bezorgadres",
      custShippingAddress: "Bezorgadres",
      custShippingPostcode: "Postcode bezorgadres",
      custShippingHouseNumber: "Huisnummer bezorgadres",
    });

    function clean(value) {
      return String(value == null ? "" : value).trim();
    }

    function value(source, keys) {
      for (const key of keys) {
        const candidate = clean(source && source[key]);
        if (candidate) return candidate;
      }
      return "";
    }

    function shippingSameFrom(source, opts) {
      if (opts && typeof opts.shipSameChecked === "boolean") return opts.shipSameChecked;
      if (opts && typeof opts.shippingSameAsBilling === "boolean")
        return opts.shippingSameAsBilling;
      if (source && typeof source.shippingSameAsBilling === "boolean")
        return source.shippingSameAsBilling;
      return true;
    }

    function normalizeCustomer(raw, opts) {
      const source = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : {};
      const shippingSameAsBilling = shippingSameFrom(source, opts || {});
      const billingAddress = value(source, ["billingAddress", "invoiceAddress", "address"]);
      const postcode = value(source, ["postcode", "postalCode"]);
      const houseNumber = value(source, ["houseNumber", "housenumber"]);
      // address1 is an ambiguous legacy alias and may contain the billing street.
      // It must never satisfy an explicitly distinct shipping contract.
      const suppliedShippingAddress = value(source, ["shippingAddress", "deliveryAddress"]);
      const suppliedShippingPostcode = value(source, [
        "shippingPostcode",
        "shippingPostalCode",
        "deliveryPostcode",
        "deliveryPostalCode",
      ]);
      const suppliedShippingHouseNumber = value(source, [
        "shippingHouseNumber",
        "deliveryHouseNumber",
      ]);
      const shippingAddress = shippingSameAsBilling ? billingAddress : suppliedShippingAddress;
      const shippingPostcode = shippingSameAsBilling ? postcode : suppliedShippingPostcode;
      const shippingHouseNumber = shippingSameAsBilling ? houseNumber : suppliedShippingHouseNumber;
      return Object.freeze({
        firstName: value(source, ["firstName"]),
        lastName: value(source, ["lastName"]),
        company: value(source, ["company", "companyName"]),
        email: value(source, ["email", "mail"]),
        phone: value(source, ["phone", "telephone", "tel"]),
        billingAddress,
        shippingAddress,
        shippingPostcode,
        shippingHouseNumber,
        shippingSameAsBilling,
        postcode,
        houseNumber,
        address1: shippingAddress || billingAddress,
        address2: value(source, ["address2"]),
        city: value(source, ["city", "plaats"]),
        country: value(source, ["country"]),
        shippingCity: shippingSameAsBilling
          ? value(source, ["city", "plaats"])
          : value(source, ["shippingCity"]),
        shippingCountry: shippingSameAsBilling
          ? value(source, ["country"])
          : value(source, ["shippingCountry"]),
      });
    }

    function getRequiredPlan(opts) {
      const shipSameChecked = shippingSameFrom(null, opts || {});
      const needShip = !shipSameChecked;
      const requiredIds = BASE_REQUIRED_IDS.slice();
      if (needShip) {
        requiredIds.push(
          "custShippingAddress",
          "custShippingPostcode",
          "custShippingHouseNumber",
          "custShippingCity",
          "custShippingCountry",
        );
      }
      return Object.freeze({
        baseIds: Object.freeze(BASE_REQUIRED_IDS.slice()),
        needShip,
        requiredIds: Object.freeze(requiredIds),
        labels: Object.freeze(Object.assign({}, LABELS)),
        fieldKeys: Object.freeze(Object.assign({}, FIELD_KEYS)),
      });
    }

    function getInvalidMessage(fieldId, code) {
      if (fieldId === "custEmail" && code === "invalid_email")
        return "Vul een geldig e-mailadres in";
      const label = LABELS[fieldId] || "Dit veld";
      return label + " is verplicht";
    }

    function isValidEmail(valueToCheck) {
      return EMAIL_RE.test(clean(valueToCheck));
    }

    function validateCustomer(raw, opts) {
      const customer = normalizeCustomer(raw, opts);
      const plan = getRequiredPlan({
        shipSameChecked: customer.shippingSameAsBilling,
      });
      const errors = [];
      const errorsById = {};

      for (const fieldId of plan.requiredIds) {
        const field = FIELD_KEYS[fieldId];
        const present = clean(customer[field]);
        if (present && (fieldId !== "custEmail" || isValidEmail(present))) continue;
        const code = present ? "invalid_email" : "required";
        const error = Object.freeze({
          fieldId,
          field,
          code,
          message: getInvalidMessage(fieldId, code),
        });
        errors.push(error);
        errorsById[fieldId] = error.message;
      }

      return Object.freeze({
        valid: errors.length === 0,
        customer,
        shippingSameAsBilling: customer.shippingSameAsBilling,
        needShippingAddress: plan.needShip,
        requiredIds: plan.requiredIds,
        errors: Object.freeze(errors),
        errorsById: Object.freeze(errorsById),
        firstInvalidId: errors.length ? errors[0].fieldId : null,
      });
    }

    function isCustomerValid(raw, opts) {
      return validateCustomer(raw, opts).valid;
    }

    ToolACustomerValidation = Object.freeze({
      BUILD,
      EMAIL_PATTERN_SOURCE,
      BASE_REQUIRED_IDS,
      FIELD_KEYS,
      LABELS,
      getRequiredPlan,
      getInvalidMessage,
      normalizeCustomer,
      isValidEmail,
      validateCustomer,
      isCustomerValid,
    });
  })(typeof window !== "undefined" ? window : globalThis);
}
