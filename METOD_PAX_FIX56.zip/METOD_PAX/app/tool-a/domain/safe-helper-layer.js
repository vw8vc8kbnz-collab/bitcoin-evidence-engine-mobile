import { toolAFoundation } from "../runtime/foundation.js";
export var ToolAAlertHelpers, ToolADomHelpers, ToolAMiscHelpers, ToolAStateHelpers;

export function mount() {
  /* State, dialog and DOM adapters for the classic shell. Template parsing has
   * one owner: toolA_template_helpers.js, loaded before this file. */

  /* --- toolA_state_helpers.js --- */
  (function () {
    function ensureStateShapeLocal(state) {
      if (!state || typeof state !== "object") return state;
      if (!Array.isArray(state.cart)) state.cart = [];
      if (!Array.isArray(state.extraPanels)) state.extraPanels = [];
      if (!Array.isArray(state.materialBatches)) state.materialBatches = [];
      if (typeof state.ui !== "object" || state.ui === null) state.ui = {};
      if (typeof state.checkout !== "object" || state.checkout === null) state.checkout = {};
      if (typeof state.grain !== "object" || state.grain === null)
        state.grain = {
          groups: [],
          selectedGroupId: null,
          includeExtraPanels: false,
        };
      if (!Array.isArray(state.grain.groups)) state.grain.groups = [];
      if (typeof state.grain.includeExtraPanels !== "boolean")
        state.grain.includeExtraPanels = false;
      state.grain.groups.forEach(function (g) {
        if (!g || typeof g !== "object") return;
        if (!Array.isArray(g.items)) g.items = [];
      });
      return state;
    }

    function getMaterialBatchByKey(state, key) {
      ensureStateShapeLocal(state);
      return (
        ((state && state.materialBatches) || []).find(function (b) {
          return String(b && b.key) === String(key);
        }) || null
      );
    }

    function materialLabel(key, state, materialMeta, materialLabelMat) {
      if (materialMeta && materialMeta[key] && materialMeta[key].name)
        return materialMeta[key].name;

      var b = getMaterialBatchByKey(state, key);
      if (b && b.mat && typeof materialLabelMat === "function") return materialLabelMat(b.mat);

      return String(key || "");
    }

    function materialLabelKey(key, state, materialMeta, materialLabelMat) {
      var b = getMaterialBatchByKey(state, key);
      if (b && b.mat && typeof materialLabelMat === "function") return materialLabelMat(b.mat);
      return materialLabel(key, state, materialMeta, materialLabelMat);
    }

    function materialArticleNumberKey(key, state) {
      var b = getMaterialBatchByKey(state, key);
      return b && b.mat && b.mat.articleNumber ? String(b.mat.articleNumber) : "";
    }

    function materialArticleNumber(key, materialMeta) {
      return materialMeta && materialMeta[key] && materialMeta[key].articleNumber
        ? materialMeta[key].articleNumber
        : "";
    }

    function refreshExtraMaterialOptions(state, materialLabelMat) {
      ensureStateShapeLocal(state);
      var sel = document.getElementById("extraMat");
      if (!sel) return;
      var batches = (state && state.materialBatches) || [];
      var current = String(sel.value || "");
      sel.innerHTML = "";
      if (!batches.length) {
        var opt0 = document.createElement("option");
        opt0.value = "";
        opt0.textContent = "— kies eerst een materiaal —";
        sel.appendChild(opt0);
        sel.value = "";
        sel.disabled = true;
        return;
      }
      sel.disabled = false;
      batches.forEach(function (b) {
        var opt = document.createElement("option");
        opt.value = String(b.key);
        opt.textContent =
          typeof materialLabelMat === "function"
            ? materialLabelMat(b.mat || { decorName: b.key })
            : String(b.key);
        sel.appendChild(opt);
      });
      var active = String((state && state.activeMaterialKey) || "");
      if (
        current &&
        batches.some(function (b) {
          return String(b.key) === current;
        })
      )
        sel.value = current;
      else if (
        active &&
        batches.some(function (b) {
          return String(b.key) === active;
        })
      )
        sel.value = active;
      else sel.value = String(batches[0].key);
    }

    function getPanelEditTargetId(localValue) {
      try {
        return typeof localValue !== "undefined" ? localValue : window.__panelEditTargetId || null;
      } catch (_e) {
        return window.__panelEditTargetId || null;
      }
    }
    function getPanelEditGroupKey(localValue) {
      try {
        return typeof localValue !== "undefined" ? localValue : window.__panelEditGroupKey || null;
      } catch (_e) {
        return window.__panelEditGroupKey || null;
      }
    }
    function getPanelEditOriginalCount(localValue) {
      try {
        return typeof localValue !== "undefined"
          ? localValue
          : Number(window.__panelEditOriginalCount || 0);
      } catch (_e) {
        return Number(window.__panelEditOriginalCount || 0);
      }
    }

    ToolAStateHelpers = {
      ensureStateShape: ensureStateShapeLocal,
      getMaterialBatchByKey: getMaterialBatchByKey,
      materialLabel: materialLabel,
      materialLabelKey: materialLabelKey,
      materialArticleNumberKey: materialArticleNumberKey,
      materialArticleNumber: materialArticleNumber,
      refreshExtraMaterialOptions: refreshExtraMaterialOptions,
      getPanelEditTargetId: getPanelEditTargetId,
      getPanelEditGroupKey: getPanelEditGroupKey,
      getPanelEditOriginalCount: getPanelEditOriginalCount,
    };
  })();

  /* --- toolA_alert_helpers.js --- */
  (function () {
    function dialogOwner() {
      {
        const owner = toolAFoundation;
        if (owner && typeof owner.showToolAlert === "function") return owner;
      }
      return null;
    }

    const alertHelpers = {
      toolAlertParts(raw, fallbackTitle) {
        const owner = dialogOwner();
        if (owner && typeof owner.toolAlertParts === "function")
          return owner.toolAlertParts(raw, fallbackTitle);
        return undefined;
      },
      closeToolAlert() {
        const owner = dialogOwner();
        if (owner && typeof owner.closeToolAlert === "function") return owner.closeToolAlert();
      },
      showToolAlert(raw, fallbackTitle) {
        const owner = dialogOwner();
        if (owner && typeof owner.showToolAlert === "function")
          return owner.showToolAlert(raw, fallbackTitle);
        console.warn("Tool A dialogcomponent is nog niet gereed");
      },
      showToolConfirm(raw, fallbackTitle) {
        const owner = dialogOwner();
        if (owner && typeof owner.showToolConfirm === "function")
          return owner.showToolConfirm(raw, fallbackTitle);
        return Promise.resolve(false);
      },
    };

    ToolAAlertHelpers = alertHelpers;
    window.showToolConfirm = ToolAAlertHelpers.showToolConfirm.bind(ToolAAlertHelpers);
  })();

  /* --- toolA_dom_helpers.js --- */
  (function () {
    function setGrainMsg(msg, getCurrentEl, setCurrentEl) {
      {
        let el = typeof getCurrentEl === "function" ? getCurrentEl() : null;
        if (!el) el = document.getElementById("grainMsg");
        if (typeof setCurrentEl === "function" && el) setCurrentEl(el);
        if (!el) return;
        const txt = String(msg || "").trim();
        el.textContent = txt;
        el.classList.toggle("hasText", !!txt);
      }
    }

    ToolADomHelpers = {
      setGrainMsg,
    };
  })();

  /* --- toolA_misc_helpers.js --- */
  (function () {
    function round1(n) {
      return Math.round(Number(n || 0) * 10) / 10;
    }
    function capitalize(s) {
      const v = String(s || "");
      if (!v) return v;
      return v.charAt(0).toUpperCase() + v.slice(1);
    }
    function groupBy(arr, fn) {
      const out = {};
      for (const x of Array.isArray(arr) ? arr : []) {
        const k = String(fn(x));
        (out[k] ||= []).push(x);
      }
      return out;
    }
    function escapeHtml(s) {
      return String(s)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
    }
    function showSavingToast(el) {
      if (!el) return;
      el.textContent = "Opslaan…";
      el.classList.remove("hasText");
      el.classList.add("isSaving");
    }
    function statusMsg(el, msg, isErr) {
      if (!el) return;
      const has = !!(msg && String(msg).trim());
      el.textContent = has ? String(msg) : "";
      el.classList.remove("isSaving");
      el.classList.toggle("hasText", has);
      el.style.color = isErr ? "#ff6b6b" : "#2fbf6a";
      el.style.borderColor = isErr ? "rgba(255,107,107,.28)" : "rgba(47,191,106,.28)";
      el.style.background = isErr ? "rgba(255,107,107,.10)" : "rgba(47,191,106,.10)";
    }
    function moneyEUR(n) {
      const v = Number(n);
      if (!Number.isFinite(v)) return "€0,00";
      return "€" + v.toFixed(2).replace(".", ",");
    }
    ToolAMiscHelpers = {
      round1,
      capitalize,
      groupBy,
      escapeHtml,
      showSavingToast,
      statusMsg,
      moneyEUR,
    };
  })();
}
