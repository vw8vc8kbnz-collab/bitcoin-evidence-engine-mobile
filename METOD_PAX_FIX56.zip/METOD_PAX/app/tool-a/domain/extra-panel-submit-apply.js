export var ToolAExtraPanelSubmitApply;

export function mount() {
  (function () {
    function toStr(v, fb) {
      return String(v == null ? (fb == null ? "" : fb) : v);
    }
    function toNum(v, fb) {
      const n = Number(v);
      return Number.isFinite(n) ? n : Number(fb == null ? 0 : fb);
    }
    function clampQty(v) {
      const n = Math.round(Number(v || 1));
      return Number.isFinite(n) && n > 0 ? n : 1;
    }
    function buildSubmitPlan(input) {
      const submitFlow = input?.submitFlow || null;
      const els = input?.elements || {};
      if (submitFlow && typeof submitFlow.getSubmitPlan === "function") {
        return submitFlow.getSubmitPlan({
          width: els.extraW?.value,
          height: els.extraH?.value,
          qty: els.extraQty?.value,
          editIndex: input?.editIndex,
          materialKey: els.extraMat?.value,
          idPrefix: toStr(input?.constants?.idPrefix || "EX_") || "EX_",
          minWidthMm: Math.max(1, toNum(input?.constants?.minWidthMm, 40)),
          rerenderExtraPanels: true,
          syncChecks: true,
          redrawExtraPreviewBeforeReset: true,
          resetForm: true,
          redrawExtraPreviewAfterReset: true,
          clearEditIndex: true,
        });
      }
      return null;
    }
    function fallbackValidation(input) {
      const els = input?.elements || {};
      const widthRaw = Number(els.extraW?.value);
      const heightRaw = Number(els.extraH?.value);
      const minWidth = Math.max(1, toNum(input?.constants?.minWidthMm, 40));
      return {
        ok:
          Number.isFinite(widthRaw) &&
          Number.isFinite(heightRaw) &&
          widthRaw > 0 &&
          heightRaw > 0 &&
          widthRaw >= minWidth,
        width: Math.round(widthRaw || 0),
        height: Math.round(heightRaw || 0),
        qty: clampQty(els.extraQty?.value),
        alertMessage:
          widthRaw < minWidth
            ? `Overige panelen moeten minimaal ${minWidth} mm breed zijn. Vul een breedte van ${minWidth} mm of groter in.`
            : "Vul een geldige breedte en hoogte in (mm).",
      };
    }
    function buildRawItem(input, validation) {
      const els = input?.elements || {};
      const hooks = input?.hooks || {};
      const mk = toStr(els.extraMat?.value || "").trim();
      const materialArticleNumberKey = hooks?.materialArticleNumberKey;
      const materialArticleNumber = hooks?.materialArticleNumber;
      const materialThicknessKey = hooks?.materialThicknessKey;
      const resolvedThickness =
        typeof materialThicknessKey === "function"
          ? materialThicknessKey(mk)
          : input?.constants?.defaultThicknessMm;
      return {
        name: toStr(els.extraName?.value || ""),
        w: validation.width,
        h: validation.height,
        qty: validation.qty,
        materialKey: mk,
        material: mk,
        articleNumber:
          (typeof materialArticleNumberKey === "function" ? materialArticleNumberKey(mk) : "") ||
          (typeof materialArticleNumber === "function" ? materialArticleNumber(mk) : ""),
        thicknessMm: toNum(resolvedThickness, input?.constants?.defaultThicknessMm ?? 18),
        edge: toStr(els.extraEdge?.value || "none") || "none",
      };
    }
    function resolveEditIndex(v) {
      if (v === null || v === undefined || v === "") return null;
      const n = Number(v);
      return Number.isInteger(n) && n >= 0 ? n : null;
    }
    function normalizeMutationPlan(plan, editIndex, idPrefix, mutationAdapter) {
      const base = plan && typeof plan === "object" ? Object.assign({}, plan) : {};
      const resolvedIndex =
        base.index != null ? resolveEditIndex(base.index) : resolveEditIndex(base.editIndex);
      const modeWasProvided =
        Object.prototype.hasOwnProperty.call(base, "mode") &&
        base.mode !== null &&
        base.mode !== undefined &&
        toStr(base.mode).trim() !== "";
      if (!modeWasProvided) {
        base.mode = resolvedIndex == null ? "append" : "replace";
      }
      base.index = resolvedIndex;
      base.editIndex = resolvedIndex;
      base.idPrefix = toStr(base.idPrefix || idPrefix || "EX_") || "EX_";
      if (
        base.mode === "replace" &&
        resolvedIndex == null &&
        mutationAdapter &&
        typeof mutationAdapter.getUpsertPlan === "function"
      ) {
        const adapterPlan =
          mutationAdapter.getUpsertPlan({
            editIndex,
            idPrefix: base.idPrefix,
          }) || {};
        const adapterIndex =
          adapterPlan.index != null
            ? resolveEditIndex(adapterPlan.index)
            : resolveEditIndex(adapterPlan.editIndex);
        base.index = adapterIndex;
        base.editIndex = adapterIndex;
        base.mode = adapterIndex == null ? "append" : "replace";
      }
      return base;
    }
    function applyMutation(input, item, submitPlan) {
      const state = input?.state || {};
      const mutationAdapter = input?.mutationAdapter || null;
      const idPrefix = toStr(input?.constants?.idPrefix || "EX_") || "EX_";
      const editIndex = resolveEditIndex(input?.editIndex);
      const mutationPlan = normalizeMutationPlan(
        (submitPlan && submitPlan.mutation) ||
          (mutationAdapter && typeof mutationAdapter.getUpsertPlan === "function"
            ? mutationAdapter.getUpsertPlan({ editIndex, idPrefix })
            : {
                mode: editIndex === null ? "append" : "replace",
                index: editIndex,
                idPrefix,
              }),
        editIndex,
        idPrefix,
        mutationAdapter,
      );
      const applied =
        mutationAdapter && typeof mutationAdapter.applyUpsert === "function"
          ? mutationAdapter.applyUpsert(state.extraPanels, item, mutationPlan)
          : null;
      if (applied && applied.ok === false) {
        return {
          applied: false,
          failed: true,
          reason: toStr(applied.reason || "extra-panel-mutation-rejected"),
          mutationPlan,
          result: applied,
        };
      }
      if (applied && Array.isArray(applied.items)) {
        state.extraPanels = applied.items;
        return { applied: true, mutationPlan, result: applied };
      }
      state.extraPanels = Array.isArray(state.extraPanels) ? state.extraPanels : [];
      if (mutationPlan.mode === "append") {
        item.id = item.id || idPrefix + Date.now() + Math.random();
        state.extraPanels.push(item);
        return {
          applied: true,
          mutationPlan,
          result: {
            ok: true,
            items: state.extraPanels,
            item,
            replaced: false,
            index: state.extraPanels.length - 1,
          },
        };
      }
      const replaceIndex = Number(mutationPlan.index);
      if (
        mutationPlan.mode !== "replace" ||
        !Number.isInteger(replaceIndex) ||
        replaceIndex < 0 ||
        replaceIndex >= state.extraPanels.length
      ) {
        return {
          applied: false,
          failed: true,
          reason: mutationPlan.mode === "replace" ? "stale-edit-index" : "invalid-upsert-mode",
          mutationPlan,
          result: null,
        };
      }
      item.id =
        state.extraPanels[replaceIndex]?.id || item.id || idPrefix + Date.now() + Math.random();
      state.extraPanels[replaceIndex] = item;
      return {
        applied: true,
        mutationPlan,
        result: {
          ok: true,
          items: state.extraPanels,
          item,
          replaced: true,
          index: replaceIndex,
        },
      };
    }
    function applyPostSubmit(input, submitPlan) {
      const hooks = input?.hooks || {};
      const postSubmit = (submitPlan && submitPlan.postSubmit) || {
        rerenderExtraPanels: true,
        syncChecks: true,
        redrawExtraPreviewBeforeReset: true,
        resetForm: true,
        redrawExtraPreviewAfterReset: true,
        clearEditIndex: true,
      };
      if (postSubmit.rerenderExtraPanels && typeof hooks.renderExtraPanels === "function")
        hooks.renderExtraPanels();
      if (postSubmit.rerenderExtraPanels && typeof hooks.renderCart === "function")
        hooks.renderCart();
      if (postSubmit.syncChecks && typeof hooks.syncChecksFromSelect === "function")
        hooks.syncChecksFromSelect();
      if (postSubmit.redrawExtraPreviewBeforeReset && typeof hooks.drawExtraPreview === "function")
        hooks.drawExtraPreview();
      if (postSubmit.clearEditIndex) {
        if (typeof hooks.setEditIndex === "function") hooks.setEditIndex(null);
      }
      if (postSubmit.resetForm && typeof hooks.resetExtraForm === "function")
        hooks.resetExtraForm();
      if (postSubmit.redrawExtraPreviewAfterReset && typeof hooks.drawExtraPreview === "function")
        hooks.drawExtraPreview();
      return postSubmit;
    }
    function execute(input) {
      const hooks = input?.hooks || {};
      const state = input?.state || null;
      if (!state) return { ok: false, reason: "missing-state" };
      const submitPlan = buildSubmitPlan(input);
      const validation =
        submitPlan && submitPlan.validation ? submitPlan.validation : fallbackValidation(input);
      if (typeof hooks.updateExtraEdgeLabels === "function") hooks.updateExtraEdgeLabels();
      if (!validation.ok) {
        alert(validation.alertMessage || "Vul een geldige breedte en hoogte in (mm).");
        return {
          ok: false,
          reason: "invalid-dimensions",
          validation,
          submitPlan,
        };
      }
      try {
        if (typeof hooks.validatePanelFits !== "function")
          throw new Error("PANEL_FIT_READER_UNAVAILABLE");
        const mkTmp = toStr(input?.elements?.extraMat?.value || "").trim();
        const selectedBatch = (
          Array.isArray(state?.materialBatches) ? state.materialBatches : []
        ).find((batch) => toStr(batch?.key || "").trim() === mkTmp);
        // Grain defaults to enabled. Rotation is safe only when the selected
        // extra-panel material explicitly opts out of continuous grain.
        const rotationAllowed = !!(selectedBatch && selectedBatch.grainEnabled === false);
        const fits = hooks.validatePanelFits(
          validation.width,
          validation.height,
          mkTmp,
          rotationAllowed,
        );
        if (fits === false) {
          return {
            ok: false,
            reason: "sheet-fit-invalid",
            validation,
            submitPlan,
          };
        }
        if (fits !== true) throw new Error("PANEL_FIT_RESULT_INVALID");
      } catch (_) {
        alert(
          "De plaatmaat kon niet betrouwbaar worden gecontroleerd. Je invoer is bewaard. Selecteer het materiaal opnieuw en probeer nogmaals.",
        );
        console.warn("ToolA panel validation unavailable", "PANEL_FIT_UNAVAILABLE");
        return {
          ok: false,
          reason: "sheet-fit-unavailable",
          validation,
          submitPlan,
        };
      }
      const rawItem = buildRawItem(input, validation);
      const item =
        input?.mutationAdapter && typeof input.mutationAdapter.buildItem === "function"
          ? input.mutationAdapter.buildItem(rawItem)
          : rawItem;
      const mutation = applyMutation(input, item, submitPlan);
      if (!mutation.applied) {
        if (mutation.reason === "stale-edit-index") {
          alert(
            "Dit paneel is intussen gewijzigd. Open het paneel opnieuw om je wijziging veilig op te slaan.",
          );
        }
        return {
          ok: false,
          reason: mutation.reason || "extra-panel-mutation-rejected",
          submitPlan,
          validation,
          item,
          mutation,
        };
      }
      if (typeof hooks.clearAllGrainAssignments === "function") hooks.clearAllGrainAssignments();
      const postSubmit = applyPostSubmit(input, submitPlan);
      return { ok: true, submitPlan, validation, item, mutation, postSubmit };
    }

    ToolAExtraPanelSubmitApply = {
      buildSubmitPlan,
      fallbackValidation,
      buildRawItem,
      applyMutation,
      applyPostSubmit,
      execute,
    };
  })();
}
