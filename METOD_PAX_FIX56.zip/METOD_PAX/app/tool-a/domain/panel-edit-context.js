import { ToolACoreSelectors } from "./core-selectors.js";
import { ToolAStateHelpers } from "./safe-helper-layer.js";
export var ToolAPanelEditContext;

export function mount() {
  (function () {
    function toStr(v) {
      return v == null ? "" : String(v);
    }
    function toNum(v, fallback) {
      const n = Number(v);
      return Number.isFinite(n) ? n : fallback == null ? 0 : fallback;
    }

    function getTargetId(localValue) {
      if (ToolAStateHelpers && typeof ToolAStateHelpers.getPanelEditTargetId === "function") {
        return ToolAStateHelpers.getPanelEditTargetId(localValue);
      }

      try {
        return typeof localValue !== "undefined" ? localValue : window.__panelEditTargetId || null;
      } catch (_) {
        return window.__panelEditTargetId || null;
      }
    }

    function getGroupKey(localValue) {
      if (ToolAStateHelpers && typeof ToolAStateHelpers.getPanelEditGroupKey === "function") {
        return ToolAStateHelpers.getPanelEditGroupKey(localValue);
      }

      try {
        return typeof localValue !== "undefined" ? localValue : window.__panelEditGroupKey || null;
      } catch (_) {
        return window.__panelEditGroupKey || null;
      }
    }

    function getOriginalCount(localValue) {
      if (ToolAStateHelpers && typeof ToolAStateHelpers.getPanelEditOriginalCount === "function") {
        return ToolAStateHelpers.getPanelEditOriginalCount(localValue);
      }

      try {
        return typeof localValue !== "undefined"
          ? Number(localValue || 0)
          : Number(window.__panelEditOriginalCount || 0);
      } catch (_) {
        return Number(window.__panelEditOriginalCount || 0);
      }
    }

    function getContext(opts) {
      const o = opts || {};
      const targetId = getTargetId(o.localTargetId);
      const groupKey = getGroupKey(o.localGroupKey);
      const originalCount = Math.max(0, toNum(getOriginalCount(o.localOriginalCount), 0));
      const currentStep = (() => {
        if (ToolACoreSelectors && typeof ToolACoreSelectors.getCurrentStep === "function") {
          return String(ToolACoreSelectors.getCurrentStep() || "material");
        }

        try {
          return String(window.__metod_uiStep || document.body?.dataset?.uiStep || "material");
        } catch (_) {
          return "material";
        }
      })();
      const activeMaterialKey = (() => {
        if (ToolACoreSelectors && typeof ToolACoreSelectors.getActiveMaterialKey === "function") {
          return String(ToolACoreSelectors.getActiveMaterialKey(window.state) || "");
        }

        try {
          return String(
            window.state?.activeMaterialKey || window.state?.selection?.materialKey || "",
          );
        } catch (_) {
          return "";
        }
      })();
      return {
        targetId: targetId ? String(targetId) : null,
        groupKey: groupKey ? String(groupKey) : null,
        originalCount,
        isEditing: !!(targetId || groupKey),
        currentStep,
        activeMaterialKey,
      };
    }

    function isEditingGroup(group, context) {
      const ctx = context || getContext();
      if (!ctx || !ctx.isEditing || !group) return false;
      {
        const items = Array.isArray(group.items) ? group.items : [];
        if (ctx.targetId && items.some((x) => String(x?.id || "") === String(ctx.targetId)))
          return true;
        if (ctx.groupKey && String(group.key || "") === String(ctx.groupKey)) return true;
      }
      return false;
    }

    function isRemovingEdited(removeId, context) {
      const ctx = context || getContext();
      if (!ctx || !ctx.targetId) return false;
      return String(removeId || "") === String(ctx.targetId || "");
    }

    function getAddButtonState(context) {
      const ctx = context || getContext();
      const isEditing = !!ctx?.isEditing;
      return {
        isEditing,
        inlineLabel: isEditing ? "✓ Wijzigingen opslaan" : "+ Toevoegen aan lijst",
        buttonLabel: isEditing ? "Wijzigingen opslaan" : "Toevoegen",
        ariaLabel: isEditing ? "Wijzigingen opslaan" : "Toevoegen aan lijst",
        hintText: isEditing
          ? Number(ctx?.originalCount || 0) > 1
            ? `Je bewerkt 1 paneel uit een groep van ${Number(ctx.originalCount || 0)}.`
            : "Je bewerkt nu een bestaand paneel."
          : "",
      };
    }

    ToolAPanelEditContext = {
      getTargetId,
      getGroupKey,
      getOriginalCount,
      getContext,
      isEditingGroup,
      isRemovingEdited,
      getAddButtonState,
    };
  })();
}
