export var ToolATemplateViewHelpers;

export function mount() {
  (function () {
    function dxfBBox(pairs) {
      let minX = Infinity,
        minY = Infinity,
        maxX = -Infinity,
        maxY = -Infinity;
      const xCodes = new Set(["10", "11", "12", "13", "14", "15", "16", "17", "18"]);
      const yCodes = new Set(["20", "21", "22", "23", "24", "25", "26", "27", "28"]);
      pairs = Array.isArray(pairs) ? pairs : [];
      for (const pair of pairs) {
        const codeRaw = Array.isArray(pair) ? pair[0] : "";
        const val = Array.isArray(pair) ? pair[1] : "";
        const code = String(codeRaw).trim();
        const v = parseFloat(val);
        if (Number.isNaN(v)) continue;
        if (xCodes.has(code)) {
          if (v < minX) minX = v;
          if (v > maxX) maxX = v;
        }
        if (yCodes.has(code)) {
          if (v < minY) minY = v;
          if (v > maxY) maxY = v;
        }
      }
      if (!isFinite(minX)) return { minX: 0, minY: 0, maxX: 0, maxY: 0 };
      return { minX, minY, maxX, maxY };
    }

    function mirrorX(pairs, dxfBBoxFn) {
      const bboxFn = typeof dxfBBoxFn === "function" ? dxfBBoxFn : dxfBBox;
      const bb = bboxFn(pairs);
      const axis = bb.minX + bb.maxX;
      const xCodes = new Set(["10", "11", "12", "13", "14", "15", "16", "17", "18"]);
      pairs = Array.isArray(pairs) ? pairs : [];
      let entityType = "";
      let arcStart = null;
      let arcEnd = null;
      function mirrorArcAngles() {
        if (entityType !== "ARC" || !arcStart || !arcEnd) return;
        const start = Number(arcStart[1]);
        const end = Number(arcEnd[1]);
        if (!Number.isFinite(start) || !Number.isFinite(end)) return;
        // A reflection reverses winding. DXF arcs run counterclockwise, so their
        // reflected endpoint becomes the start and vice versa.
        arcStart[1] = String((((180 - end) % 360) + 360) % 360);
        arcEnd[1] = String((((180 - start) % 360) + 360) % 360);
      }
      for (let i = 0; i < pairs.length; i++) {
        const row = pairs[i];
        if (!Array.isArray(row)) continue;
        const code = String(row[0]).trim();
        if (code === "0") {
          mirrorArcAngles();
          entityType = String(row[1]).trim().toUpperCase();
          arcStart = null;
          arcEnd = null;
        } else if (entityType === "ARC") {
          if (code === "50") arcStart = row;
          if (code === "51") arcEnd = row;
        }
        if (!xCodes.has(code)) continue;
        const v = parseFloat(row[1]);
        if (Number.isNaN(v)) continue;
        const nv = axis - v;
        row[1] = String(nv);
      }
      mirrorArcAngles();
      return pairs;
    }

    ToolATemplateViewHelpers = {
      dxfBBox: dxfBBox,
      mirrorX: mirrorX,
    };
  })();
}
