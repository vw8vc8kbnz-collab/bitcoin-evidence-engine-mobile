export var ToolARenderHelpers;

export function mount() {
  (function () {
    function drawEmpty(ctx, w, h, status) {
      if (!ctx) return;
      ctx.save();
      ctx.fillStyle = "rgba(234,243,238,.9)";
      ctx.font = "800 16px ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto";
      ctx.textAlign = "center";
      const title =
        status === "error"
          ? "Paneel nog niet geladen"
          : status === "loading"
            ? "Paneel laden…"
            : "Kies rechts een type + maat om te starten";
      ctx.fillText(title, w / 2, h / 2 - 12);
      ctx.fillStyle = "rgba(200,215,208,.90)";
      ctx.font = "13px ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto";
      const detail =
        status === "error"
          ? "Klik rechts op Opnieuw proberen."
          : status === "loading"
            ? "De preview verschijnt zodra het paneel klaar is."
            : "Je ziet hier direct het front met boringen, maatvoering, verlengen en spiegeling.";
      ctx.fillText(detail, w / 2, h / 2 + 12);
      ctx.restore();
    }

    ToolARenderHelpers = {
      drawEmpty: drawEmpty,
    };
  })();
}
