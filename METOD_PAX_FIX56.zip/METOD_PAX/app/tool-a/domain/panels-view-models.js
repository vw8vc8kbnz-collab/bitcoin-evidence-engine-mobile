export var ToolAPanelsViewModels;

export function mount() {
  (function () {
    function toStr(v) {
      return v == null ? "" : String(v);
    }
    function toNum(v, fallback) {
      const n = Number(v);
      return Number.isFinite(n) ? n : fallback == null ? 0 : fallback;
    }
    function clone(value) {
      if (typeof structuredClone === "function") return structuredClone(value);

      try {
        return JSON.parse(JSON.stringify(value));
      } catch (_) {
        return value;
      }
    }
    function uniq(values) {
      return Array.from(new Set((values || []).filter(Boolean)));
    }

    function getMaterialChipModels(state, options) {
      const s = state || window.state || {};
      const opts = options || {};
      const batches = Array.isArray(s.materialBatches) ? s.materialBatches : [];
      const activeKey = toStr(s.activeMaterialKey || "").trim();
      const titleForBatch =
        typeof opts.titleForBatch === "function"
          ? opts.titleForBatch
          : (batch) =>
              toStr(
                batch?.mat?.productName ||
                  batch?.mat?.articleNumber ||
                  batch?.mat?.decorName ||
                  batch?.key ||
                  "",
              ).trim();
      return batches.map((batch) => {
        const key = toStr(batch?.key || "").trim();
        const title = titleForBatch(batch);
        return {
          key,
          title,
          active: !!(key && key === activeKey),
          removeKey: key,
          batch: clone(batch),
        };
      });
    }

    function getExtraPanelsSummary(state) {
      const s = state || window.state || {};
      const items = Array.isArray(s.extraPanels) ? s.extraPanels : [];
      return {
        lineCount: items.length,
        qtyCount: items.reduce((acc, item) => acc + Math.max(1, toNum(item?.qty, 1)), 0),
        hasItems: items.length > 0,
        items: clone(items),
      };
    }

    function getExtraPanelCardModels(state, options) {
      const s = state || window.state || {};
      const opts = options || {};
      const materialLabelForKey =
        typeof opts.materialLabelForKey === "function" ? opts.materialLabelForKey : (k) => toStr(k);
      const edgeTextFor = typeof opts.edgeTextFor === "function" ? opts.edgeTextFor : () => "";
      const items = Array.isArray(s.extraPanels) ? s.extraPanels : [];
      return items.map((panel, index) => {
        const width = Math.round(toNum(panel?.w, 0));
        const height = Math.round(toNum(panel?.h, 0));
        const qty = Math.max(1, toNum(panel?.qty, 1));
        const title = toStr(panel?.name || "").trim() || `Overig paneel ${width}×${height}`;
        const materialKey = toStr(panel?.materialKey || panel?.material || "").trim();
        const materialLabel = materialLabelForKey(materialKey);
        const edgeText = edgeTextFor(panel?.edge || "none", width, height);
        return {
          index,
          id: panel?.id || null,
          qty,
          width,
          height,
          title,
          materialKey,
          materialLabel,
          articleNumber: toStr(panel?.articleNumber || "").trim(),
          edgeText,
          line2: `${qty}× · ${width}×${height} mm · ${materialLabel} · Artikel: ${toStr(panel?.articleNumber || "").trim()} · Kantenband: ${edgeText}`,
          panel: clone(panel),
        };
      });
    }

    function getPanelDockTabModel(state, options) {
      const s = state || window.state || {};
      const opts = options || {};
      const getMaterialName =
        typeof opts.getMaterialName === "function" ? opts.getMaterialName : (k) => toStr(k);
      const cart = Array.isArray(s.cart) ? s.cart : [];
      const extraPanels = Array.isArray(s.extraPanels) ? s.extraPanels : [];
      const matKeys = uniq([
        ...cart.map((it) => toStr(it?.materialKey || "").trim()),
        ...extraPanels.map((it) => toStr(it?.materialKey || it?.material || "").trim()),
      ]);
      const ui = s.ui || {};
      const preferredTab =
        ui.panelDockTab === "material" && ui.panelDockMaterialKey ? "material" : "all";
      const resolvedKey = matKeys.includes(toStr(ui.panelDockMaterialKey || "").trim())
        ? toStr(ui.panelDockMaterialKey || "").trim()
        : matKeys[0] || null;
      const chips = [
        {
          type: "all",
          label: "Alle onderdelen",
          active: preferredTab === "all",
        },
      ];
      matKeys.forEach((key) => {
        chips.push({
          type: "material",
          key,
          label: getMaterialName(key),
          active: preferredTab === "material" && key === resolvedKey,
        });
      });
      return {
        visible: matKeys.length > 1,
        materialKeys: matKeys,
        selectedTab: preferredTab,
        selectedMaterialKey: resolvedKey,
        chips,
      };
    }

    // Shared, read-only material partition for the desktop overview and the
    // compact mobile panel list. Entries retain their original collection index
    // so a filtered/material-grouped row can still target the canonical state.
    function getPanelMaterialGroups(state, options) {
      const s = state || {};
      const opts = options || {};
      const getMaterialName =
        typeof opts.getMaterialName === "function" ? opts.getMaterialName : () => "Materiaal";
      const cart = Array.isArray(s.cart) ? s.cart : [];
      const extraPanels = Array.isArray(s.extraPanels) ? s.extraPanels : [];
      const groups = new Map();

      function ensureGroup(materialKey) {
        const key = toStr(materialKey).trim();
        if (!groups.has(key)) {
          let resolvedLabel = "";
          try {
            resolvedLabel = toStr(getMaterialName(key)).trim();
          } catch (error) {
            ToolAErrors.recover("panel.material-label", error, ["Error", "TypeError"]);
          }
          groups.set(key, {
            materialKey: key,
            materialLabel: resolvedLabel || "Materiaal",
            cartEntries: [],
            extraEntries: [],
          });
        }
        return groups.get(key);
      }

      cart.forEach((panel, index) => {
        ensureGroup(panel?.materialKey).cartEntries.push({ panel, index });
      });
      extraPanels.forEach((panel, index) => {
        ensureGroup(panel?.materialKey || panel?.material).extraEntries.push({
          panel,
          index,
        });
      });

      return Array.from(groups.values())
        .map((group) => {
          const standardQtyCount = group.cartEntries.reduce(
            (total, entry) => total + Math.max(1, Math.round(toNum(entry?.panel?.qty, 1))),
            0,
          );
          const extraQtyCount = group.extraEntries.reduce(
            (total, entry) => total + Math.max(1, Math.round(toNum(entry?.panel?.qty, 1))),
            0,
          );
          return {
            ...group,
            standardQtyCount,
            extraQtyCount,
            totalQtyCount: standardQtyCount + extraQtyCount,
          };
        })
        .sort((a, b) => {
          const byLabel = a.materialLabel.localeCompare(b.materialLabel, "nl", {
            sensitivity: "base",
          });
          return (
            byLabel ||
            a.materialKey.localeCompare(b.materialKey, "nl", {
              sensitivity: "base",
            })
          );
        });
    }

    ToolAPanelsViewModels = {
      getMaterialChipModels,
      getExtraPanelsSummary,
      getExtraPanelCardModels,
      getPanelDockTabModel,
      getPanelMaterialGroups,
    };
  })();
}
