export var ToolAExtraPanelFormApply;

export function mount() {
  (function () {
    function toStr(v, fb) {
      return String(v == null ? (fb == null ? "" : fb) : v);
    }
    function toNum(v, fb) {
      if (v === "" && fb === "") return "";
      const n = Number(v);
      return Number.isFinite(n) ? n : fb == null ? 0 : fb;
    }
    function scrollIntoViewSafe(el) {
      try {
        if (el && typeof el.scrollIntoView === "function")
          el.scrollIntoView({ behavior: "auto", block: "nearest" });
      } catch (_) {
        ToolAErrors.recover("toolA.extra.panel.form.apply.js.8", _, [
          "NotSupportedError",
          "InvalidStateError",
        ]);
      }
    }

    function applyPrefill(input) {
      const snapshot = (input && input.snapshot) || {};
      const elements = (input && input.elements) || {};
      const hooks = (input && input.hooks) || {};

      if (typeof hooks.setEditIndex === "function")
        hooks.setEditIndex(snapshot.editIndex == null ? null : Number(snapshot.editIndex));
      if (elements.extraEditHint)
        elements.extraEditHint.style.display = snapshot.showEditHint ? "block" : "none";
      if (elements.addExtraBtn)
        elements.addExtraBtn.textContent = snapshot.buttonLabel || "✓ Wijzigingen opslaan";
      if (elements.extraName) elements.extraName.value = toStr(snapshot.name, "");
      if (elements.extraW) elements.extraW.value = toStr(snapshot.w, "");
      if (elements.extraH) elements.extraH.value = toStr(snapshot.h, "");
      if (elements.extraQty) elements.extraQty.value = toStr(snapshot.qty, "1");
      if (typeof hooks.refreshExtraMaterialOptions === "function")
        hooks.refreshExtraMaterialOptions();
      if (elements.extraMat) elements.extraMat.value = toStr(snapshot.materialKey, "");
      if (typeof hooks.ensureEdgeOption === "function")
        hooks.ensureEdgeOption(snapshot.edge || "none");
      if (typeof hooks.syncChecksFromSelect === "function") hooks.syncChecksFromSelect();
      scrollIntoViewSafe(elements.extraName);
      return true;
    }

    function applyReset(input) {
      const snapshot = (input && input.snapshot) || {};
      const elements = (input && input.elements) || {};
      const hooks = (input && input.hooks) || {};

      if (typeof hooks.setEditIndex === "function")
        hooks.setEditIndex(snapshot.editIndex == null ? null : Number(snapshot.editIndex));
      if (elements.extraEditHint)
        elements.extraEditHint.style.display = snapshot.showEditHint ? "block" : "none";
      if (elements.addExtraBtn)
        elements.addExtraBtn.textContent = snapshot.buttonLabel || "+ Toevoegen";
      if (elements.extraName) elements.extraName.value = toStr(snapshot.name, "");
      if (elements.extraW) elements.extraW.value = toStr(snapshot.w, "");
      if (elements.extraH) elements.extraH.value = toStr(snapshot.h, "");
      if (elements.extraQty) elements.extraQty.value = toStr(snapshot.qty, "1");
      if (typeof hooks.refreshExtraMaterialOptions === "function")
        hooks.refreshExtraMaterialOptions();
      if (typeof hooks.ensureEdgeOption === "function")
        hooks.ensureEdgeOption(snapshot.edge || "none");
      if (elements.extraEdgeTop) elements.extraEdgeTop.checked = false;
      if (elements.extraEdgeBottom) elements.extraEdgeBottom.checked = false;
      if (elements.extraEdgeLeft) elements.extraEdgeLeft.checked = false;
      if (elements.extraEdgeRight) elements.extraEdgeRight.checked = false;
      if (typeof hooks.syncSelectFromChecks === "function") hooks.syncSelectFromChecks();
      return true;
    }

    ToolAExtraPanelFormApply = { applyPrefill, applyReset };
  })();
}
