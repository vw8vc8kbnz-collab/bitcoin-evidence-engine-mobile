import { ToolAPanelsEntry } from "../adapters/panels-entrypoints.js";
export var ToolAShowStepApply;

export function mount() {
  (function () {
    function fallbackEnterPanelsStep(ctx) {
      ctx.ensureCustomLabelHook && ctx.ensureCustomLabelHook();
      ctx.refreshCustomLabelVisibility && ctx.refreshCustomLabelVisibility();
      ctx.syncDefaultPanelTypeSelection && ctx.syncDefaultPanelTypeSelection();
      ctx.enableControlsIfReady && ctx.enableControlsIfReady();
      {
        const hasMat = !!(ctx.state && ctx.state.activeMaterialKey);
        if (hasMat && ctx.bootstrapPanelSelectionForActiveMaterial) {
          const forceBootstrap = !!window.__forcePanelBootstrap;
          ctx.bootstrapPanelSelectionForActiveMaterial(forceBootstrap);
          window.__forcePanelBootstrap = false;
        }
      }
      if (ctx.typeSel && typeof ctx.typeSel.__appleSync === "function")
        ctx.typeSel.__appleSync();
      if (ctx.sizeSel && typeof ctx.sizeSel.__appleSync === "function")
        ctx.sizeSel.__appleSync();
      {
        if (ctx.panelDock) {
          ctx.panelDock.style.display = "flex";
        }
        if (ctx.panelDockLauncher) {
          ctx.panelDockLauncher.style.display = "inline-flex";
        }
        const cartCount = Array.isArray(ctx.state?.cart) ? ctx.state.cart.length : 0;
        const extraCount = Array.isArray(ctx.state?.extraPanels)
          ? ctx.state.extraPanels.reduce((a, p) => a + Math.max(1, Number(p?.qty) || 1), 0)
          : 0;
        const dockTotal = cartCount + extraCount;
        const shouldRestoreDock =
          dockTotal > 0 &&
          (ctx.prevStep === "grain" || ctx.prevStep === "overview") &&
          !!window.__panelDockWasOpenBeforeRoute;
        if (typeof ctx.setPanelDockOpen === "function") {
          if (shouldRestoreDock) ctx.setPanelDockOpen(true);
          else if (!dockTotal) ctx.setPanelDockOpen(false);
        }
      }
    }

    function handlePanelsEnter(ctx) {
      if (ctx.step !== "panels") return;

      if (ToolAPanelsEntry && typeof ToolAPanelsEntry.onEnterPanelsStep === "function") {
        ToolAPanelsEntry.onEnterPanelsStep(ctx.prevStep);
        return;
      }

      fallbackEnterPanelsStep(ctx);
    }

    function applyRightScroll(ctx) {
      if (!ctx.rightScroll) return;
      if (ctx.sameStep) {
        ctx.rightScroll.scrollTop = ctx.prevRightScrollTop || 0;
        if (typeof ctx.stabilizeRightScroll === "function") ctx.stabilizeRightScroll(14);
      } else if (
        (ctx.routePlan && ctx.routePlan.shouldResetRightScroll) ||
        ctx.step === "material" ||
        ctx.step === "panels" ||
        ctx.step === "customer"
      ) {
        ctx.rightScroll.scrollTop = 0;
      }
    }

    function execute(ctx) {
      if (ctx.step !== "grain" && typeof ctx.closeGrain === "function") ctx.closeGrain();
      if (ctx.step !== "overview" && typeof ctx.closeOverview === "function")
        ctx.closeOverview();
      if (typeof ctx.setStep === "function") ctx.setStep(ctx.step);
      if (typeof ctx.renderFooterForStep === "function") ctx.renderFooterForStep(ctx.step);
      if (typeof ctx.syncPanelDockChrome === "function") ctx.syncPanelDockChrome();
      handlePanelsEnter(ctx);
      applyRightScroll(ctx);

      if (ctx.step === "grain" && typeof ctx.openGrain === "function") {
        ctx.openGrain();
        return { didOpenStepOverlay: true };
      }
      if (ctx.step === "overview" && typeof ctx.openOverview === "function") {
        ctx.openOverview();
        return { didOpenStepOverlay: true };
      }

      return { didOpenStepOverlay: false };
    }

    ToolAShowStepApply = {
      execute,
      handlePanelsEnter,
      applyRightScroll,
    };
  })();
}
