export var ToolAPanelBootstrapApply;

export function mount() {
  (function () {
    function setSelectValue(el, value) {
      if (!el) return;
      el.value = value == null ? "" : String(value);
      if (typeof el.__appleSync === "function") el.__appleSync();
    }
    function setInputValue(el, value) {
      if (el) el.value = value;
    }
    function dispatchChange(el) {
      if (el) el.dispatchEvent(new Event("change", { bubbles: true }));
    }
    function applyBootstrap(input) {
      const selection = input?.selection || null;
      const ui = input?.ui || null;
      const needsReset = !!input?.needsReset;
      const state = input?.state || null;
      const typeSel = input?.typeSel || null;
      const sizeSel = input?.sizeSel || null;
      const qty = input?.qty || null;
      const extTop = input?.extTop || null;
      const extBot = input?.extBot || null;
      const addBtn = input?.addBtn || null;
      const syncDefaultPanelTypeSelection = input?.syncDefaultPanelTypeSelection;
      const populateSizeDropdown = input?.populateSizeDropdown;
      const refreshCustomLabelVisibility = input?.refreshCustomLabelVisibility;
      const ensureTemplateLoadedById = input?.ensureTemplateLoadedById;
      const draw = input?.draw;

      if (selection && state) {
        input.selectionCommands.update({ type: selection.type });
        input.selectionCommands.update({ templateId: selection.templateId });
        input.selectionCommands.update({ qty: selection.qty });
        input.selectionCommands.update({ extTop: selection.extTop });
        input.selectionCommands.update({ extBot: selection.extBot });
      }

      if (needsReset) {
        setSelectValue(typeSel, ui && "typeValue" in ui ? ui.typeValue : "");

        if (sizeSel) {
          sizeSel.innerHTML =
            ui && ui.sizePlaceholder
              ? ui.sizePlaceholder
              : '<option value="">— Kies maat —</option>';
        }

        setSelectValue(sizeSel, ui && "sizeValue" in ui ? ui.sizeValue : "");
        setInputValue(extTop, ui && "extTop" in ui ? ui.extTop : 0);
        setInputValue(extBot, ui && "extBot" in ui ? ui.extBot : 0);
        if (typeof syncDefaultPanelTypeSelection === "function") syncDefaultPanelTypeSelection();
        if (typeof populateSizeDropdown === "function") populateSizeDropdown();
      } else {
        setSelectValue(
          typeSel,
          ui && "typeValue" in ui
            ? ui.typeValue
            : state && state.selection
              ? state.selection.type
              : "",
        );
        setSelectValue(
          sizeSel,
          ui && "sizeValue" in ui
            ? ui.sizeValue
            : state && state.selection
              ? state.selection.templateId
              : "",
        );
      }

      if (addBtn)
        addBtn.disabled = !(ui && "addEnabled" in ui
          ? ui.addEnabled
          : !!(
              state &&
              state.selection &&
              state.activeMaterialKey &&
              state.selection.type &&
              state.selection.templateId
            ));
      if (typeof refreshCustomLabelVisibility === "function") refreshCustomLabelVisibility();
      dispatchChange(typeSel);

      if (
        typeof ensureTemplateLoadedById === "function" &&
        state &&
        state.selection &&
        state.selection.templateId
      ) {
        ensureTemplateLoadedById(state.selection.templateId).then(function () {
          if (typeof draw === "function") draw();
          if (typeof refreshCustomLabelVisibility === "function") refreshCustomLabelVisibility();
        });
      } else {
        if (typeof draw === "function") draw();
        if (typeof refreshCustomLabelVisibility === "function") refreshCustomLabelVisibility();
      }
    }

    function applyNoMaterialsReset(input) {
      const reset = input?.reset || null;
      const state = input?.state || null;
      const typeSel = input?.typeSel || null;
      const sizeSel = input?.sizeSel || null;
      const qty = input?.qty || null;
      const extTop = input?.extTop || null;
      const extBot = input?.extBot || null;
      const addBtn = input?.addBtn || null;
      const renderStep2MaterialSummary = input?.renderStep2MaterialSummary;
      const renderMaterialBatches = input?.renderMaterialBatches;
      const renderMaterialBatchesStep2 = input?.renderMaterialBatchesStep2;
      const renderCart = input?.renderCart;
      const renderExtraPanels = input?.renderExtraPanels;
      const drawPreview = input?.drawPreview;
      const drawExtraPreview = input?.drawExtraPreview;
      const showStep = input?.showStep;
      const setStep = input?.setStep;
      const renderFooterForStep = input?.renderFooterForStep;
      const updateButtons = input?.updateButtons;
      const updateWizardBanner = input?.updateWizardBanner;

      {
        if (state) {
          state.materialBatches = [];
          state.activeMaterialKey = null;
          state.material = null;
        }
        const sel =
          reset && reset.selection
            ? reset.selection
            : {
                type: null,
                templateId: null,
                qty: 1,
                extTop: 0,
                extBot: 0,
                customLabel: "",
                materialKey: null,
                materialName: null,
              };
        input.selectionCommands.update({ type: sel.type });
        input.selectionCommands.update({ templateId: sel.templateId });
        input.selectionCommands.update({ qty: sel.qty });
        input.selectionCommands.update({ extTop: sel.extTop });
        input.selectionCommands.update({ extBot: sel.extBot });
        input.selectionCommands.update({ customLabel: sel.customLabel });
        input.selectionCommands.update({ materialKey: null });
        input.selectionCommands.update({ materialName: null });
      }
      setSelectValue(
        typeSel,
        reset && reset.ui && "typeValue" in reset.ui ? reset.ui.typeValue : "",
      );
      if (sizeSel) {
        sizeSel.innerHTML =
          reset && reset.ui && reset.ui.sizePlaceholder
            ? reset.ui.sizePlaceholder
            : '<option value="">— Kies maat —</option>';
      }
      setSelectValue(
        sizeSel,
        reset && reset.ui && "sizeValue" in reset.ui ? reset.ui.sizeValue : "",
      );
      setInputValue(qty, reset && reset.ui && "qty" in reset.ui ? reset.ui.qty : 1);
      setInputValue(extTop, reset && reset.ui && "extTop" in reset.ui ? reset.ui.extTop : 0);
      setInputValue(extBot, reset && reset.ui && "extBot" in reset.ui ? reset.ui.extBot : 0);
      if (addBtn) addBtn.disabled = true;
      if (typeof renderStep2MaterialSummary === "function") renderStep2MaterialSummary();
      if (typeof renderMaterialBatches === "function") renderMaterialBatches();
      if (typeof renderMaterialBatchesStep2 === "function") renderMaterialBatchesStep2();
      {
        const wrap = document.getElementById("matChosenStep2");
        const chips = document.getElementById("matChosenStep2Chips");
        if (wrap) wrap.style.display = "none";
        if (chips) chips.innerHTML = "";
        const chosen = document.getElementById("matChosen");
        if (chosen) chosen.style.display = "none";
      }
      if (typeof renderCart === "function") renderCart();
      if (typeof renderExtraPanels === "function") renderExtraPanels();
      if (typeof updateButtons === "function") updateButtons();
      if (typeof updateWizardBanner === "function") updateWizardBanner();
      if (typeof drawPreview === "function") drawPreview();
      if (typeof drawExtraPreview === "function") drawExtraPreview();
      if (typeof setStep === "function") setStep("material");
      if (typeof renderFooterForStep === "function") renderFooterForStep("material");
      if (typeof showStep === "function")
        setTimeout(function () {
          showStep("material");
        }, 0);
    }

    ToolAPanelBootstrapApply = {
      applyBootstrap,
      applyNoMaterialsReset,
    };
  })();
}
