export var ToolAPanelFormApply;

export function mount() {
  (function () {
    function toStr(v, fb) {
      return String(v == null ? (fb == null ? "" : fb) : v);
    }
    function toNum(v, fb) {
      const n = Number(v);
      return Number.isFinite(n) ? n : Number(fb || 0);
    }
    function dispatch(el, type) {
      if (el && type) el.dispatchEvent(new Event(type, { bubbles: true }));
    }

    function applyPrefill(input) {
      const state = input && input.state;
      const snapshot = (input && input.snapshot) || {};
      const plan = (input && input.plan) || {};
      const elements = (input && input.elements) || {};
      if (!state || !state.selection) return false;

      input.selectionCommands.update({ type: toStr(snapshot.type, "") });
      if (elements.typeSel) {
        elements.typeSel.value = state.selection.type;
        if (plan.dispatchTypeChange) dispatch(elements.typeSel, "change");
      }

      input.selectionCommands.update({
        templateId: toStr(snapshot.templateId, ""),
      });
      if (elements.sizeSel) {
        elements.sizeSel.value = state.selection.templateId;
        if (plan.dispatchSizeChange) dispatch(elements.sizeSel, "change");
      }

      input.selectionCommands.update({
        qty: Math.max(1, toNum(snapshot.qty, 1) || 1),
      });
      if (elements.qty) {
        elements.qty.value = String(state.selection.qty);
        if (plan.dispatchQtyInput) dispatch(elements.qty, "input");
      }

      input.selectionCommands.update({
        hinge: toStr(snapshot.hinge, "left") || "left",
      });
      if (elements.hingeSel) {
        elements.hingeSel.value = state.selection.hinge;
        if (plan.dispatchHingeChange) dispatch(elements.hingeSel, "change");
      }

      input.selectionCommands.update({
        extTop: toNum(snapshot.extTop, 0) || 0,
      });
      input.selectionCommands.update({
        extBot: toNum(snapshot.extBot, 0) || 0,
      });
      if (elements.extTop) {
        elements.extTop.value = String(state.selection.extTop);
        if (plan.dispatchExtTopInput) dispatch(elements.extTop, "input");
      }
      if (elements.extBot) {
        elements.extBot.value = String(state.selection.extBot);
        if (plan.dispatchExtBotInput) dispatch(elements.extBot, "input");
      }

      if (elements.customLabelInput) {
        elements.customLabelInput.value = toStr(snapshot.customLabel, "");
        if (plan.dispatchCustomLabelInput) dispatch(elements.customLabelInput, "input");
      }
      return true;
    }

    function applyReset(input) {
      const state = input && input.state;
      const snapshot = (input && input.snapshot) || {};
      const elements = (input && input.elements) || {};
      const setPanelEditMode =
        (input && input.setPanelEditMode) ||
        (typeof window !== "undefined" && typeof window.__setPanelEditMode === "function"
          ? window.__setPanelEditMode
          : null);
      const refreshCustomLabelVisibility = input && input.refreshCustomLabelVisibility;
      if (!state || !state.selection) return false;

      if (elements.qty) elements.qty.value = String(Math.max(1, toNum(snapshot.qty, 1) || 1));
      if (elements.extTop) elements.extTop.value = String(toNum(snapshot.extTop, 0) || 0);
      if (elements.extBot) elements.extBot.value = String(toNum(snapshot.extBot, 0) || 0);
      if (elements.hingeSel) elements.hingeSel.value = toStr(snapshot.hinge, "left") || "left";
      if (elements.customLabelInput)
        elements.customLabelInput.value = toStr(snapshot.customLabel, "");
      if (snapshot.clearEdit && typeof setPanelEditMode === "function") {
        setPanelEditMode(null, 0);
      }
      if (snapshot.clearEdit && typeof window !== "undefined") {
        window.__panelEditSnapshot = null;
        window.__panelEditLiveForm = null;
        window.__panelEditKnownName = "";
        window.__panelEditTouchedFields = {
          qty: false,
          hinge: false,
          extTop: false,
          extBot: false,
          customLabel: false,
        };
      }

      input.selectionCommands.update({
        qty: Math.max(1, toNum(snapshot.qty, 1) || 1),
      });
      input.selectionCommands.update({
        extTop: toNum(snapshot.extTop, 0) || 0,
      });
      input.selectionCommands.update({
        extBot: toNum(snapshot.extBot, 0) || 0,
      });
      input.selectionCommands.update({
        hinge: toStr(snapshot.hinge, "left") || "left",
      });

      dispatch(elements.qty, "input");
      dispatch(elements.extTop, "input");
      dispatch(elements.extBot, "input");
      dispatch(elements.hingeSel, "change");
      dispatch(elements.customLabelInput, "input");
      if (typeof refreshCustomLabelVisibility === "function") refreshCustomLabelVisibility();
      return true;
    }

    ToolAPanelFormApply = { applyPrefill, applyReset };
  })();
}
