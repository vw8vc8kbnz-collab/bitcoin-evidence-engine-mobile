export var ToolAPanelUiState;

export function mount() {
  (function () {
    "use strict";

    function getControlsState(state) {
      const route = String(state?.route || "");
      const ready = route === "metod";
      const material = state?.material || null;
      const hasMaterial = !!(
        material &&
        (state?.activeMaterialKey ||
          material?.materialCode ||
          material?.articleNumber ||
          material?.decorName)
      );
      const hasCart = Array.isArray(state?.cart) && state.cart.length > 0;
      const hasExtraPanels =
        Array.isArray(state?.extraPanels) && state.extraPanels.length > 0;
      const hasPanels = hasCart || hasExtraPanels;
      const type = state?.selection?.type || "";
      const templateId = state?.selection?.templateId || "";
      const templateReady = !!state?.templates?.has?.(templateId);
      return {
        ready,
        hasMaterial,
        enablePanels: !!(ready && hasMaterial),
        addEnabled: !!(ready && hasMaterial && type && templateId && templateReady),
        grainEnabled: !!(ready && hasMaterial),
        grainNextEnabled: !!(ready && hasMaterial && hasPanels),
        extraOverlayEnabled: !!(ready && hasMaterial),
        overviewEnabled: !!(ready && hasPanels),
      };
    }

    function resolveTypeKind(input) {
      const rawValue = String(input?.rawValue || "")
        .trim()
        .toLowerCase();
      if (rawValue) return rawValue;
      const selectedText = String(input?.selectedText || "")
        .trim()
        .toLowerCase();
      if (selectedText.includes("pax")) return "pax_deur";
      if (selectedText.includes("lade")) return "lade";
      if (selectedText.includes("deur") || selectedText.includes("door")) return "deur";
      if (selectedText.includes("overige")) return "special";
      return String(input?.stateType || "")
        .trim()
        .toLowerCase();
    }

    function getCustomLabelState(input) {
      const typeKind = resolveTypeKind(input);
      const show =
        typeKind === "deur" ||
        typeKind === "pax_deur" ||
        typeKind === "lade" ||
        typeKind === "special";
      return {
        typeKind,
        show,
        clearValueOnHide: !show,
      };
    }

    const api = { getControlsState, resolveTypeKind, getCustomLabelState };
    ToolAPanelUiState = api;
  })();
}
