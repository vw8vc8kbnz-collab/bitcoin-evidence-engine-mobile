#!/usr/bin/env python3
"""Executable entry point; services and operational APIs live in metod_app."""

import sys
import logging
from metod_app.runtime.application import main, run_worker

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
    run_worker() if "--worker" in sys.argv else main()
