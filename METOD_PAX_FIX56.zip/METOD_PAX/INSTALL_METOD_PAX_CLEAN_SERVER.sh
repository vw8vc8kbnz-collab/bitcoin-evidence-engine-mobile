#!/usr/bin/env bash
set -Eeuo pipefail
export PATH=/usr/sbin:/usr/bin:/sbin:/bin
export PYTHONDONTWRITEBYTECODE=1
export PYTHONSAFEPATH=1 PYTHONNOUSERSITE=1
unset PYTHONPATH PYTHONHOME

STAGE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUNDLE="${1:-}"
STATE_DIR="${METOD_STATE_ROOT:-/var/lib/metod-pax}"
ENV_DIR="${METOD_ENV_DIR:-/etc/adzaagt/metod-pax}"
CREDS_FILE="${ADMIN_CREDENTIALS_FILE:-$ENV_DIR/admin_credentials.live.json}"
CURRENT_LINK="${METOD_CURRENT_LINK:-/opt/adzaagt/metod-pax-current}"
INSTALL_PACKAGES="${METOD_INSTALL_PACKAGES:-1}"
TEMP_ROOT=""
STATE_STAGE=""
DISTRO_DEFAULT_REMOVED=0
NGINX_DEFAULT_LINK="/etc/nginx/sites-enabled/default"
NGINX_DEFAULT_TARGET="/etc/nginx/sites-available/default"
CREATED_CODE_ROOT=0
CREATED_STATE_ROOT=0
CREATED_PRIVACY_ROOT=0
CREATED_ENV_ROOT=0
INSTALL_COMMITTED=0

fail(){ echo "[METOD-PAX-CLEAN-INSTALL] FOUT: $*" >&2; exit 1; }
validate_os_release(){
  # Debian/Ubuntu normally use /etc/os-release -> ../usr/lib/os-release.
  # Accept only that vendor target (or a regular /etc file), never an arbitrary
  # symlink or shell code from an environment-supplied identity file.
  local os_file="$1" vendor_file="$2" target="$1" parent line distro=""
  for parent in "$(dirname "$os_file")" "$(dirname "$vendor_file")" "$(dirname "$(dirname "$vendor_file")")"; do
    [[ -d "$parent" && ! -L "$parent" ]] || fail "OS-identiteit heeft een onveilige bovenliggende map"
    [[ "$(stat -c '%u:%g:%a' "$parent")" =~ ^0:0:(555|755)$ ]] \
      || fail "OS-identiteit vereist root-owned, niet-schrijfbare bovenliggende mappen"
  done
  if [[ -L "$os_file" ]]; then
    [[ "$(stat -c '%u:%g' "$os_file")" == "0:0" ]] || fail "OS-identiteitssymlink is niet root-owned"
    target="$(readlink -f "$os_file")" || fail "OS-identiteitssymlink kon niet worden opgelost"
    [[ "$target" == "$vendor_file" ]] || fail "OS-identiteitssymlink wijst niet naar de canonieke vendor-identiteit"
  fi
  [[ -f "$target" && ! -L "$target" && -r "$target" ]] || fail "Reguliere Debian/Ubuntu-identiteit ontbreekt"
  [[ "$(stat -c '%u:%g:%a:%h' "$target")" =~ ^0:0:(444|644):1$ ]] \
    || fail "OS-identiteit moet root:root-owned, enkelvoudig gelinkt en mode 0444/0644 zijn"
  while IFS= read -r line || [[ -n "$line" ]]; do
    case "$line" in
      ID=ubuntu|ID=\"ubuntu\"|ID=\'ubuntu\') [[ -z "$distro" ]] || fail "Dubbele OS-identiteit"; distro=ubuntu ;;
      ID=debian|ID=\"debian\"|ID=\'debian\') [[ -z "$distro" ]] || fail "Dubbele OS-identiteit"; distro=debian ;;
      ID=*) fail "Clean installer ondersteunt uitsluitend Debian/Ubuntu" ;;
    esac
  done < "$target"
  [[ -n "$distro" ]] || fail "Debian/Ubuntu ID ontbreekt in OS-identiteit"
}

cleanup(){
  local rc=$? cleanup_load_state="" live_or_partial=0
  set +e
  unset MIGRATION_PASSPHRASE
  if [[ -n "$TEMP_ROOT" && -d "$TEMP_ROOT" ]]; then
    [[ "$TEMP_ROOT" == /var/tmp/metod-pax-clean-install.* ]] || { echo "Onverwacht tijdelijk pad; niet verwijderd: $TEMP_ROOT" >&2; return "$rc"; }
    rm -rf -- "$TEMP_ROOT" || { echo "Tijdelijke decryptiemap kon niet volledig worden verwijderd: $TEMP_ROOT" >&2; rc=1; }
  fi
  if [[ -n "$STATE_STAGE" && -d "$STATE_STAGE" ]]; then
    [[ "$STATE_STAGE" == "${STATE_DIR}.bootstrap."* ]] || { echo "Onverwachte state-stage; niet verwijderd: $STATE_STAGE" >&2; return "$rc"; }
    rm -rf -- "$STATE_STAGE" || { echo "Tijdelijke state-stage kon niet volledig worden verwijderd: $STATE_STAGE" >&2; rc=1; }
  fi
  # Zodra de geneste installer de live edge heeft gecommit, mag een late
  # uitvoer-/housekeepingfout nooit meer als pre-commit cleanup worden behandeld.
  if [[ "$rc" -ne 0 && "$INSTALL_COMMITTED" -eq 0 && "$CREATED_CODE_ROOT" -eq 1 ]]; then
    # Sluit ook het SIGTERM/connection-loss-venster tussen de innerlijke edge-
    # commit en diens shellreturn. Elk pointer- of werkelijk servicebewijs maakt
    # automatische verwijdering onveilig, ook als de service later inactief is.
    if [[ -e "$CURRENT_LINK" || -L "$CURRENT_LINK" ]]; then
      live_or_partial=1
    fi
    cleanup_load_state="$(systemctl show metod-pax.service --property=LoadState --value 2>/dev/null)" \
      || cleanup_load_state="unknown"
    [[ "$cleanup_load_state" == "not-found" ]] || live_or_partial=1
    systemctl is-active --quiet metod-pax.service && live_or_partial=1
    if [[ "$live_or_partial" -eq 1 ]]; then
      echo "KRITIEK: current-pointer of systemd-status bewijst een partiële/live installatie; code, state en configuratie worden niet automatisch verwijderd" >&2
      rc=1
    else
      [[ -d /opt/adzaagt && ! -L /opt/adzaagt ]] && rm -rf -- /opt/adzaagt
      [[ "$CREATED_PRIVACY_ROOT" -eq 1 && -d "${STATE_DIR}-privacy" && ! -L "${STATE_DIR}-privacy" ]] && rm -rf -- "${STATE_DIR}-privacy"
      [[ "$CREATED_STATE_ROOT" -eq 1 && -d "$STATE_DIR" && ! -L "$STATE_DIR" ]] && rm -rf -- "$STATE_DIR"
      [[ "$CREATED_ENV_ROOT" -eq 1 && -d "$ENV_DIR" && ! -L "$ENV_DIR" ]] && rm -rf -- "$ENV_DIR"
    fi
  fi
  if [[ "$rc" -ne 0 && "$INSTALL_COMMITTED" -eq 0 && "$live_or_partial" -eq 0 && "$DISTRO_DEFAULT_REMOVED" -eq 1 && ! -e "$NGINX_DEFAULT_LINK" && ! -L "$NGINX_DEFAULT_LINK" ]]; then
    if ln -s "$NGINX_DEFAULT_TARGET" "$NGINX_DEFAULT_LINK"; then
      if ! nginx -t; then
        echo "Herstelde distro-default Nginx-site faalt configuratievalidatie" >&2
        rc=1
      elif systemctl is-active --quiet nginx && ! systemctl reload nginx; then
        echo "Herstelde distro-default Nginx-site kon niet live worden herladen" >&2
        rc=1
      fi
    else
      echo "Distro-default Nginx-site kon niet worden hersteld" >&2
      rc=1
    fi
  fi
  return "$rc"
}
trap cleanup EXIT

source "$STAGE/ops/deploy_lock.sh"


[[ -n "$BUNDLE" && "$BUNDLE" == /* && "$BUNDLE" =~ ^/[A-Za-z0-9._/-]+\.gpg$ ]] || fail "Geef één veilig absoluut pad naar de .gpg-migratiebundle"
[[ -f "$BUNDLE" && ! -L "$BUNDLE" ]] || fail "Migratiebundle ontbreekt of is een symlink"
if [[ "$EUID" -ne 0 ]]; then
  FORWARD=(PYTHONDONTWRITEBYTECODE=1 METOD_STATE_ROOT="$STATE_DIR" METOD_ENV_DIR="$ENV_DIR" ADMIN_CREDENTIALS_FILE="$CREDS_FILE" METOD_CURRENT_LINK="$CURRENT_LINK" METOD_INSTALL_PACKAGES="$INSTALL_PACKAGES")
  for name in METOD_DEPLOY_MODE PUBLIC_ORIGIN METOD_DOMAIN TLS_CERT_FILE TLS_KEY_FILE OFFSITE_BACKUP_VERIFIED OFFSITE_BACKUP_PROVIDER PRODUCTION_MIN_CATALOG_RECORDS ADMIN_ALLOWED_NETWORKS STAGING_PUBLIC_PORT STAGING_BIND_ADDRESS STAGING_ALLOWED_CIDR STAGING_EXTERNAL_ORIGIN; do
    [[ -v "$name" ]] && FORWARD+=("$name=${!name}")
  done
  exec sudo env "${FORWARD[@]}" bash "$0" "$BUNDLE"
fi

[[ "$INSTALL_PACKAGES" =~ ^[01]$ ]] || fail "METOD_INSTALL_PACKAGES moet 0 of 1 zijn"
for command in flock stat readlink systemctl; do
  command -v "$command" >/dev/null || fail "Ontbrekend commando: $command"
done
acquire_or_inherit_deploy_lock

# Dit is de beslissende clean-statecontrole en draait onder dezelfde lock die de
# geneste installer en DEPLOY erven.
[[ ! -e /opt/adzaagt && ! -L /opt/adzaagt && ! -e "$STATE_DIR" && ! -L "$STATE_DIR" && ! -e "$ENV_DIR" && ! -L "$ENV_DIR" && ! -e "${STATE_DIR}-privacy" && ! -L "${STATE_DIR}-privacy" ]] \
  || fail "Clean installer weigert bestaande METOD/PAX code, state of configuratie"
CLEAN_SERVICE_LOAD_STATE="$(systemctl show metod-pax.service --property=LoadState --value)" \
  || fail "Werkelijke systemd load-state kon niet worden bepaald"
[[ "$CLEAN_SERVICE_LOAD_STATE" == "not-found" ]] \
  || fail "Clean installer weigert een bestaande METOD/PAX-unit uit iedere systemd load path: $CLEAN_SERVICE_LOAD_STATE"
if [[ "$INSTALL_PACKAGES" == "1" ]]; then
  validate_os_release /etc/os-release /usr/lib/os-release
  command -v apt-get >/dev/null || fail "apt-get ontbreekt"
  DEBIAN_FRONTEND=noninteractive apt-get update
  DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends python3 nodejs nginx rsync curl ca-certificates gnupg tar logrotate
fi
for command in python3 node nginx rsync curl gpg tar sha256sum mktemp; do
  command -v "$command" >/dev/null || fail "Ontbrekend commando: $command"
done
[[ -x /usr/bin/python3 ]] || fail "Vertrouwde interpreter /usr/bin/python3 ontbreekt"
/usr/bin/python3 -I -S -B - /opt/adzaagt "$STATE_DIR" "$ENV_DIR" "$CREDS_FILE" "$NGINX_DEFAULT_LINK" "$NGINX_DEFAULT_TARGET" <<'PY'
import os,sys
from pathlib import Path
code,state,env,creds,default_link,default_target=map(Path,sys.argv[1:])
for path in (code,state,env,creds,default_link,default_target):
    if not path.is_absolute() or str(path).startswith('//') or Path(os.path.normpath(path)) != path:
        raise SystemExit(f'clean-installpad is niet canoniek absoluut: {path}')
    if any(part in ('','.','..') for part in path.parts[1:]):
        raise SystemExit(f'clean-installpad bevat verboden segment: {path}')
def reject_symlink_components(path,include_leaf=True):
    cursor=Path('/')
    parts=path.parts[1:] if include_leaf else path.parts[1:-1]
    for part in parts:
        cursor /= part
        if cursor.is_symlink():
            raise SystemExit(f'symlinkcomponent is verboden in clean-installpad: {cursor}')
def below(path,root):
    try: path.relative_to(root); return path != root
    except ValueError: return False
if not (below(state,Path('/var/lib')) or below(state,Path('/srv'))):
    raise SystemExit('clean statepad moet onder /var/lib of /srv liggen')
if not below(env,Path('/etc/adzaagt')) or creds.parent != env:
    raise SystemExit('clean env/credentialpaden moeten onder dezelfde /etc/adzaagt-map liggen')
for path in (code,state,env,creds):
    reject_symlink_components(path)
for path in (default_link,default_target):
    reject_symlink_components(path,include_leaf=False)
PY
# Pakketten en padvalidatie kunnen systemd zichtbaar hebben veranderd; bewijs
# de clean preconditie daarom nogmaals onmiddellijk vóór de eerste hostmutatie.
[[ ! -e /opt/adzaagt && ! -L /opt/adzaagt && ! -e "$STATE_DIR" && ! -L "$STATE_DIR" && ! -e "$ENV_DIR" && ! -L "$ENV_DIR" && ! -e "${STATE_DIR}-privacy" && ! -L "${STATE_DIR}-privacy" ]] \
  || fail "Clean-state veranderde tijdens voorbereiding"
CLEAN_SERVICE_LOAD_STATE="$(systemctl show metod-pax.service --property=LoadState --value)" \
  || fail "Werkelijke systemd load-state kon niet opnieuw worden bepaald"
[[ "$CLEAN_SERVICE_LOAD_STATE" == "not-found" ]] \
  || fail "Tijdens voorbereiding verscheen een METOD/PAX-unit: $CLEAN_SERVICE_LOAD_STATE"

# Veranker bundle en sidecar vanuit één werkelijk geopend uploaddirectory-FD
# in root-private bestanden. Alle verificatie/decryptie hieronder gebruikt
# uitsluitend deze snapshots, nooit opnieuw het caller-beheerste pad.
TEMP_ROOT="$(mktemp -d /var/tmp/metod-pax-clean-install.XXXXXX)"
chmod 0700 "$TEMP_ROOT"
BUNDLE_SNAPSHOT="$TEMP_ROOT/migration.gpg"
SIDECAR_SNAPSHOT="$TEMP_ROOT/migration.gpg.sha256"
/usr/bin/python3 -I -S -B - "$BUNDLE" "$BUNDLE.sha256" "$BUNDLE_SNAPSHOT" "$SIDECAR_SNAPSHOT" <<'PY'
import os,stat,sys
from pathlib import Path

raw_source=sys.argv[1]
if raw_source.startswith('//') or raw_source!=os.path.normpath(raw_source):
    raise SystemExit('bundlepad moet lexicaal canoniek absoluut zijn')
source,sidecar,destination,sidecar_destination=map(Path,sys.argv[1:])
if source.parent != sidecar.parent:
    raise SystemExit('bundle en sidecar moeten dezelfde uploaddirectory delen')
resolved_parent=source.parent.resolve(strict=True)
if resolved_parent != source.parent:
    raise SystemExit('symlinkcomponent in bundle-uploadpad is verboden')

def open_directory_chain(path):
    descriptor=os.open('/',os.O_RDONLY|getattr(os,'O_DIRECTORY',0)|getattr(os,'O_CLOEXEC',0))
    try:
        for part in path.parts[1:]:
            child=os.open(part,os.O_RDONLY|getattr(os,'O_DIRECTORY',0)|getattr(os,'O_NOFOLLOW',0)|getattr(os,'O_CLOEXEC',0),dir_fd=descriptor)
            os.close(descriptor)
            descriptor=child
        return descriptor
    except Exception:
        os.close(descriptor)
        raise

if destination.parent.resolve(strict=True)!=destination.parent:
    raise SystemExit('root-private snapshotdirectory wijzigde onverwacht')
parent_fd=open_directory_chain(resolved_parent)
destination_fd=open_directory_chain(destination.parent)

def stable(metadata):
    return (metadata.st_dev,metadata.st_ino,metadata.st_mode,metadata.st_nlink,metadata.st_size,metadata.st_mtime_ns,metadata.st_ctime_ns)

def snapshot(name,destination_name,limit):
    flags=os.O_RDONLY|getattr(os,'O_NOFOLLOW',0)|getattr(os,'O_NONBLOCK',0)|getattr(os,'O_CLOEXEC',0)
    descriptor=os.open(name,flags,dir_fd=parent_fd)
    try:
        before=os.fstat(descriptor)
        linked=os.stat(name,dir_fd=parent_fd,follow_symlinks=False)
        if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1 or (linked.st_dev,linked.st_ino)!=(before.st_dev,before.st_ino):
            raise SystemExit(f'onveilig uploadbestand: {name}')
        if before.st_size < 1 or before.st_size > limit:
            raise SystemExit(f'uploadbestand buiten bytegrens: {name}')
        output=os.open(destination_name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|getattr(os,'O_CLOEXEC',0),0o600,dir_fd=destination_fd)
        copied=0
        try:
            while True:
                chunk=os.read(descriptor,1024*1024)
                if not chunk:
                    break
                copied += len(chunk)
                if copied > limit:
                    raise SystemExit(f'uploadbestand groeide buiten bytegrens: {name}')
                view=memoryview(chunk)
                while view:
                    written=os.write(output,view)
                    view=view[written:]
            os.fsync(output)
        finally:
            os.close(output)
        after=os.fstat(descriptor)
        linked_after=os.stat(name,dir_fd=parent_fd,follow_symlinks=False)
        if stable(before)!=stable(after) or (linked_after.st_dev,linked_after.st_ino)!=(after.st_dev,after.st_ino) or copied!=before.st_size:
            raise SystemExit(f'uploadbestand wijzigde tijdens snapshot: {name}')
    finally:
        os.close(descriptor)

try:
    snapshot(source.name,destination.name,64*1024*1024*1024)
    snapshot(sidecar.name,sidecar_destination.name,4096)
    os.fsync(destination_fd)
finally:
    os.close(destination_fd)
    os.close(parent_fd)
PY
if [[ "${METOD_DEPLOY_MODE:-staging}" == "production" && ( -e "$NGINX_DEFAULT_LINK" || -L "$NGINX_DEFAULT_LINK" ) ]]; then
  [[ -L "$NGINX_DEFAULT_LINK" ]] \
    || fail "Nginx default-site is geen canonieke distro-symlink"
  [[ "$(readlink -f "$NGINX_DEFAULT_LINK")" == "$NGINX_DEFAULT_TARGET" ]] \
    || fail "Nginx default-site wijst niet naar de canonieke distro-default"
  [[ -f "$NGINX_DEFAULT_TARGET" && ! -L "$NGINX_DEFAULT_TARGET" ]] \
    || fail "Canonieke distro-default Nginx-config ontbreekt"
  [[ "$(stat -c '%u:%g:%a:%h' "$NGINX_DEFAULT_TARGET")" =~ ^0:0:(600|640|644):1$ ]] \
    || fail "Distro-default Nginx-config heeft onveilige metadata"
  rm -- "$NGINX_DEFAULT_LINK"
  DISTRO_DEFAULT_REMOVED=1
fi
[[ -f "$STAGE/SHA256SUMS.txt" ]] || fail "Releasechecksummanifest ontbreekt"
(cd "$STAGE" && sha256sum -c SHA256SUMS.txt)
if [[ "${METOD_DEPLOY_MODE:-staging}" == "production" ]]; then
  /usr/bin/python3 -I -S -B "$STAGE/tools/deployment_safety.py" production --release "$STAGE" \
    || fail "Clean production-install vereist onafhankelijke goedkeuring van deze exacte release"
fi
[[ -f "$SIDECAR_SNAPSHOT" && ! -L "$SIDECAR_SNAPSHOT" ]] || fail "Verplichte migratiebundle-sidecar ontbreekt"
SIDECAR_LINE="$(cat "$SIDECAR_SNAPSHOT")"
[[ "$SIDECAR_LINE" =~ ^([a-f0-9]{64})[[:space:]][[:space:]]([^/[:space:]]+)$ ]] || fail "Migratiebundle-sidecar heeft ongeldig formaat"
[[ "${BASH_REMATCH[2]}" == "$(basename "$BUNDLE")" ]] || fail "Migratiebundle-sidecar noemt niet exact de bundle"
[[ "$(sha256sum "$BUNDLE_SNAPSHOT" | awk '{print $1}')" == "${BASH_REMATCH[1]}" ]] || fail "Migratiebundle-SHA256 wijkt af"

printf 'Wachtwoord van de versleutelde migratiebundle: ' >/dev/tty
IFS= read -rs MIGRATION_PASSPHRASE </dev/tty
printf '\n' >/dev/tty
[[ -n "$MIGRATION_PASSPHRASE" ]] || fail "Leeg migratiewachtwoord geweigerd"
DECRYPTED="$TEMP_ROOT/migration.tar"
exec {PASSPHRASE_FD}<<<"$MIGRATION_PASSPHRASE"
gpg --batch --yes --pinentry-mode loopback --passphrase-fd "$PASSPHRASE_FD" --no-symkey-cache --decrypt --output "$DECRYPTED" "$BUNDLE_SNAPSHOT"
exec {PASSPHRASE_FD}<&-
unset MIGRATION_PASSPHRASE
chmod 0600 "$DECRYPTED"
PYTHONDONTWRITEBYTECODE=1 /usr/bin/python3 -I -S -B "$STAGE/tools/migration_bundle_tool.py" extract \
  --archive "$DECRYPTED" --destination "$TEMP_ROOT/extracted"
PAYLOAD="$TEMP_ROOT/extracted/metod-pax-migration"
STATE_GATE_ARGS=()
if [[ "${METOD_DEPLOY_MODE:-staging}" == "production" ]]; then
  STATE_GATE_ARGS+=(--production)
fi
PYTHONDONTWRITEBYTECODE=1 /usr/bin/python3 -I -S -B "$STAGE/tools/install_state_gate.py" \
  --state-root "$PAYLOAD/state" --credentials "$PAYLOAD/config/admin_credentials.live.json" \
  "${STATE_GATE_ARGS[@]}"

id -u metod-pax >/dev/null 2>&1 || useradd --system --home-dir "$STATE_DIR" --shell /usr/sbin/nologin metod-pax
install -d -o root -g root -m 0755 /opt/adzaagt
CREATED_CODE_ROOT=1
STATE_STAGE="$(mktemp -d "${STATE_DIR}.bootstrap.XXXXXXXX")" \
  || fail "Unieke tijdelijke state-import kon niet worden gereserveerd"
chown metod-pax:metod-pax "$STATE_STAGE"
chmod 0750 "$STATE_STAGE"
rsync -a --delete "$PAYLOAD/state/" "$STATE_STAGE/"
chown -R metod-pax:metod-pax "$STATE_STAGE"
chmod -R o-rwx "$STATE_STAGE"
chmod 0750 "$STATE_STAGE"
install -d -o root -g metod-pax -m 0750 "$ENV_DIR"
CREATED_ENV_ROOT=1
install -o root -g root -m 0600 "$PAYLOAD/config/admin_credentials.live.json" "$CREDS_FILE"
mv "$STATE_STAGE" "$STATE_DIR"
STATE_STAGE=""
CREATED_STATE_ROOT=1
install -d -o metod-pax -g metod-pax -m 0700 "${STATE_DIR}-privacy"
CREATED_PRIVACY_ROOT=1
rsync -a --delete "$PAYLOAD/privacy/" "${STATE_DIR}-privacy/"
chown -R metod-pax:metod-pax "${STATE_DIR}-privacy"
find "${STATE_DIR}-privacy" -type d -exec chmod 0700 {} +
find "${STATE_DIR}-privacy" -type f -exec chmod 0600 {} +
if [[ -f "$PAYLOAD/config/backup-budget.env" ]]; then
  install -o root -g root -m 0600 "$PAYLOAD/config/backup-budget.env" "$ENV_DIR/backup-budget.env"
fi

METOD_DEPLOY_LOCK_CONTRACT="$METOD_DEPLOY_LOCK_CONTRACT" METOD_DEPLOY_LOCK_FD="$METOD_DEPLOY_LOCK_FD" \
  METOD_INSTALL_MODE=bootstrap METOD_RECOVERY_ACK=CLEAN_SERVER_STATE_IMPORT_CONFIRMED \
  bash "$STAGE/INSTALL_FROM_STAGE.sh"
INSTALL_COMMITTED=1
set +e
echo "[METOD-PAX-CLEAN-INSTALL] PASS: code, externe state, credentials, service en Nginx zijn geïnstalleerd." || true
exit 0
