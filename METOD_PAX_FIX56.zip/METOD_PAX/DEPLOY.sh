#!/usr/bin/env bash
set -Eeuo pipefail
export PATH=/usr/sbin:/usr/bin:/sbin:/bin
export PYTHONDONTWRITEBYTECODE=1
export PYTHONSAFEPATH=1 PYTHONNOUSERSITE=1
unset PYTHONPATH PYTHONHOME

VERSION="R9RC4_FIX56_RUNTIME_PREFLIGHT"
CURRENT_LINK="${METOD_CURRENT_LINK:-/opt/adzaagt/metod-pax-current}"
STATE_DIR="${METOD_STATE_ROOT:-/var/lib/metod-pax}"
ENV_DIR="${METOD_ENV_DIR:-/etc/adzaagt/metod-pax}"
ENV_FILE="$ENV_DIR/metod-pax.env"
CREDS_FILE="${ADMIN_CREDENTIALS_FILE:-$ENV_DIR/admin_credentials.live.json}"
SERVICE_FILE="/etc/systemd/system/metod-pax.service"
NGINX_SITE="/etc/nginx/sites-available/metod-pax"
NGINX_LINK="/etc/nginx/sites-enabled/metod-pax"
NGINX_LIMITS="/etc/nginx/conf.d/metod-pax-limits.conf"
NGINX_LOGROTATE="/etc/logrotate.d/metod-pax-nginx"
MODE="${METOD_DEPLOY_MODE:-staging}"
PUBLIC_ORIGIN="${PUBLIC_ORIGIN:-http://127.0.0.1:8790}"
STAGING_EXTERNAL_ORIGIN="${STAGING_EXTERNAL_ORIGIN:-}"
DOMAIN="${METOD_DOMAIN:-}"

fail(){ echo "[$VERSION] FOUT: $*" >&2; exit 1; }
info(){ echo "[$VERSION] $*"; }
safe_abs_path(){ [[ "$1" =~ ^/[A-Za-z0-9._/-]+$ ]] || fail "Onveilig absoluut pad: $1"; }
safe_uint(){ [[ "$2" =~ ^[0-9]{1,12}$ ]] || fail "$1 moet een begrensd positief geheel getal zijn"; }
no_controls(){ [[ "$2" != *$'\n'* && "$2" != *$'\r'* ]] || fail "$1 bevat verboden regeleinden"; }

source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/ops/deploy_lock.sh"

[[ "$EUID" -eq 0 ]] || fail "DEPLOY.sh vereist root."
umask 027
for cmd in python3 nginx systemctl curl runuser grep nproc mktemp logrotate flock stat readlink; do command -v "$cmd" >/dev/null || fail "Ontbrekend commando: $cmd"; done
[[ -x /usr/bin/python3 ]] || fail "Vertrouwde interpreter /usr/bin/python3 ontbreekt"
require_inherited_deploy_lock
for value in "$CURRENT_LINK" "$STATE_DIR" "$ENV_DIR" "$ENV_FILE" "$CREDS_FILE"; do safe_abs_path "$value"; done
/usr/bin/python3 -I -S -B - "$CURRENT_LINK" "$STATE_DIR" "$ENV_DIR" "$CREDS_FILE" <<'PY'
import itertools,os,sys
from pathlib import Path
raw=sys.argv[1:]
for value in raw:
    if not value.startswith('/') or value.startswith('//') or value != os.path.normpath(value):
        raise SystemExit(f'deploypad moet een canoniek absoluut pad zijn: {value}')
    if any(part in ('','.','..') for part in value.split('/')[1:]):
        raise SystemExit(f'deploypad bevat een verboden segment: {value}')
current,state,env,creds=map(Path,raw)
def below(path, root):
    try: path.relative_to(root); return path != root
    except ValueError: return False
def reject_symlink_components(path, *, include_leaf=True):
    parts=path.parts[1:] if include_leaf else path.parts[1:-1]
    cursor=Path('/')
    for part in parts:
        cursor /= part
        if cursor.is_symlink():
            raise SystemExit(f'symlinkcomponent is verboden in deploypad: {cursor}')
if not below(current,Path('/opt/adzaagt')):
    raise SystemExit('METOD_CURRENT_LINK moet onder /opt/adzaagt liggen')
if not (below(state,Path('/var/lib')) or below(state,Path('/srv'))):
    raise SystemExit('METOD_STATE_ROOT moet onder /var/lib of /srv liggen')
if not below(env,Path('/etc/adzaagt')) or creds.parent != env:
    raise SystemExit('env/credentials moeten onder dezelfde /etc/adzaagt-map liggen')
for left,right in itertools.combinations((current,state,env),2):
    if left == right or left in right.parents or right in left.parents:
        raise SystemExit(f'deploybomen mogen niet overlappen: {left} / {right}')
for path in (state,env,creds):
    reject_symlink_components(path)
reject_symlink_components(current,include_leaf=False)
PY
no_controls PUBLIC_ORIGIN "$PUBLIC_ORIGIN"
no_controls STAGING_EXTERNAL_ORIGIN "$STAGING_EXTERNAL_ORIGIN"
no_controls OFFSITE_BACKUP_PROVIDER "${OFFSITE_BACKUP_PROVIDER:-}"
no_controls NTFY_ALLOWED_HOSTS "${NTFY_ALLOWED_HOSTS:-ntfy.sh}"
[[ "${OFFSITE_BACKUP_VERIFIED:-0}" =~ ^[01]$ ]] || fail "OFFSITE_BACKUP_VERIFIED moet 0 of 1 zijn"
/usr/bin/python3 -I -S -B - "${NTFY_ALLOWED_HOSTS:-ntfy.sh}" "${OFFSITE_BACKUP_PROVIDER:-}" <<'PY'
import re,sys
hosts=[item.strip().lower() for item in sys.argv[1].split(',') if item.strip()]
if not hosts or any(not re.fullmatch(r'(?=.{1,253}\Z)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)*[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?', host) for host in hosts):
    raise SystemExit('NTFY_ALLOWED_HOSTS bevat een ongeldige hostnaam')
provider=sys.argv[2]
if provider and not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._:/@+\-]{0,199}', provider):
    raise SystemExit('OFFSITE_BACKUP_PROVIDER heeft een onveilig formaat')
PY
[[ -L "$CURRENT_LINK" && -d "$CURRENT_LINK/app" ]] || fail "Actieve release-symlink ontbreekt: $CURRENT_LINK"
[[ -d "$STATE_DIR" ]] || fail "Externe state ontbreekt: $STATE_DIR"
[[ -f "$CREDS_FILE" && ! -L "$CREDS_FILE" ]] || fail "Admin credentials ontbreken of zijn geen regulier bestand: $CREDS_FILE"
[[ "$(stat -c '%u:%g:%a:%h' "$CREDS_FILE")" == "0:0:600:1" ]] \
  || fail "Admin credentials moeten enkelvoudig gelinkt, root:root-owned en mode 0600 zijn"

if [[ "$MODE" == "production" ]]; then
  /usr/bin/python3 -I -S -B "$CURRENT_LINK/tools/deployment_safety.py" production --release "$CURRENT_LINK" \
    || fail "Production-deploy vereist onafhankelijke goedkeuring van deze exacte release"
fi

id -u metod-pax >/dev/null 2>&1 || useradd --system --home-dir "$STATE_DIR" --shell /usr/sbin/nologin metod-pax
install -d -o metod-pax -g metod-pax -m 0750 "$STATE_DIR"
install -d -o root -g metod-pax -m 0750 "$ENV_DIR"

case "$MODE" in
  staging)
    SITE_PORT="${STAGING_PUBLIC_PORT:-8790}"
    STAGING_BIND="${STAGING_BIND_ADDRESS:-127.0.0.1}"
    STAGING_CIDR="${STAGING_ALLOWED_CIDR:-}"
    safe_uint STAGING_PUBLIC_PORT "$SITE_PORT"
    (( 10#$SITE_PORT >= 1024 && 10#$SITE_PORT <= 65535 )) || fail "STAGING_PUBLIC_PORT moet 1024..65535 zijn"
    /usr/bin/python3 -I -S -B - "$PUBLIC_ORIGIN" "$SITE_PORT" "$STAGING_BIND" "$STAGING_CIDR" "$STAGING_EXTERNAL_ORIGIN" <<'PY'
import ipaddress,re,sys
from urllib.parse import urlparse
u=urlparse(sys.argv[1])
if u.scheme!='http' or not u.hostname or u.username or u.password or u.query or u.fragment or u.path not in ('','/'):
    raise SystemExit('staging PUBLIC_ORIGIN must be one exact http://host[:port] origin')
if (u.port or 80) != int(sys.argv[2]):
    raise SystemExit('staging PUBLIC_ORIGIN port must equal STAGING_PUBLIC_PORT')
bind=ipaddress.ip_address(sys.argv[3])
if bind.version != 4: raise SystemExit('STAGING_BIND_ADDRESS must be an IPv4 address')
cidr=sys.argv[4]
if not bind.is_loopback:
    if not cidr: raise SystemExit('remote staging bind requires STAGING_ALLOWED_CIDR')
    ipaddress.ip_network(cidr,strict=False)
elif cidr:
    ipaddress.ip_network(cidr,strict=False)
external=sys.argv[5]
if external:
    e=urlparse(external)
    if e.scheme!='https' or not e.hostname or e.username or e.password or e.query or e.fragment or e.path not in ('','/'):
        raise SystemExit('STAGING_EXTERNAL_ORIGIN must be one exact https://host[:port] origin')
    if not re.fullmatch(r'(?=.{4,253}\Z)(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.)+[A-Za-z]{2,63}',e.hostname):
        raise SystemExit('STAGING_EXTERNAL_ORIGIN hostname is not safe public DNS')
    try: external_port=e.port
    except ValueError as exc: raise SystemExit('STAGING_EXTERNAL_ORIGIN port is invalid') from exc
    if external_port is not None and not 1 <= external_port <= 65535:
        raise SystemExit('STAGING_EXTERNAL_ORIGIN port is outside 1..65535')
    if not bind.is_loopback:
        raise SystemExit('STAGING_EXTERNAL_ORIGIN requires a loopback-only STAGING_BIND_ADDRESS')
PY
    APP_PUBLIC_ORIGIN="${STAGING_EXTERNAL_ORIGIN:-$PUBLIC_ORIGIN}"
    if [[ -n "$STAGING_EXTERNAL_ORIGIN" ]]; then
      STAGING_EXTERNAL_HTTPS_PREVIEW=1
    else
      STAGING_EXTERNAL_HTTPS_PREVIEW=0
    fi
    APP_ENV="staging"
    PROD="0"
    CATALOG_MIN="${PRODUCTION_MIN_CATALOG_RECORDS:-1}"
    ;;
  production)
    [[ -z "$STAGING_EXTERNAL_ORIGIN" ]] || fail "STAGING_EXTERNAL_ORIGIN is uitsluitend toegestaan voor staging"
    STAGING_EXTERNAL_HTTPS_PREVIEW=0
    [[ -n "$DOMAIN" ]] || fail "METOD_DOMAIN is verplicht voor production"
    /usr/bin/python3 -I -S -B - "$DOMAIN" <<'PY'
import re,sys
d=sys.argv[1]
if not re.fullmatch(r'(?=.{4,253}\Z)(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.)+[A-Za-z]{2,63}',d):
    raise SystemExit('METOD_DOMAIN is not a safe public DNS name')
PY
    [[ "$PUBLIC_ORIGIN" == "https://$DOMAIN" ]] || fail "PUBLIC_ORIGIN moet exact https://$DOMAIN zijn"
    APP_PUBLIC_ORIGIN="$PUBLIC_ORIGIN"
    TLS_CERT="${TLS_CERT_FILE:-/etc/letsencrypt/live/$DOMAIN/fullchain.pem}"
    TLS_KEY="${TLS_KEY_FILE:-/etc/letsencrypt/live/$DOMAIN/privkey.pem}"
    safe_abs_path "$TLS_CERT"
    safe_abs_path "$TLS_KEY"
    [[ -r "$TLS_CERT" && -r "$TLS_KEY" ]] || fail "Geldig TLS-certificaat/key ontbreekt voor $DOMAIN"
    /usr/bin/python3 -I -S -B - "$TLS_CERT" "$TLS_KEY" <<'PY'
import os,stat,sys
for label,path in (('certificaat',sys.argv[1]),('private key',sys.argv[2])):
    mode=os.stat(path).st_mode
    if not stat.S_ISREG(mode): raise SystemExit(f'{label} is geen regulier bestand')
if os.stat(sys.argv[2]).st_mode & 0o077:
    raise SystemExit('TLS private key mag niet leesbaar/schrijfbaar zijn voor group/other')
PY
    command -v openssl >/dev/null || fail "Ontbrekend commando voor production: openssl"
    openssl x509 -in "$TLS_CERT" -noout -checkend 604800 >/dev/null || fail "TLS-certificaat verloopt binnen 7 dagen"
    openssl x509 -in "$TLS_CERT" -noout -checkhost "$DOMAIN" >/dev/null || fail "TLS-certificaat dekt $DOMAIN niet"
    CERT_KEY_HASH="$(openssl x509 -in "$TLS_CERT" -pubkey -noout | openssl pkey -pubin -outform DER 2>/dev/null | sha256sum | awk '{print $1}')"
    PRIVATE_KEY_HASH="$(openssl pkey -in "$TLS_KEY" -pubout -outform DER 2>/dev/null | sha256sum | awk '{print $1}')"
    [[ -n "$CERT_KEY_HASH" && "$CERT_KEY_HASH" == "$PRIVATE_KEY_HASH" ]] || fail "TLS-certificaat en private key horen niet bij elkaar"
    APP_ENV="production"
    PROD="1"
    CATALOG_MIN="${PRODUCTION_MIN_CATALOG_RECORDS:-597}"
    ;;
  *) fail "METOD_DEPLOY_MODE moet staging of production zijn" ;;
esac
safe_uint PRODUCTION_MIN_CATALOG_RECORDS "$CATALOG_MIN"
(( 10#$CATALOG_MIN >= 1 )) || fail "PRODUCTION_MIN_CATALOG_RECORDS moet minimaal 1 zijn"

MEMORY_MAX="${METOD_MEMORY_MAX:-2G}"
TASKS_MAX="${METOD_TASKS_MAX:-128}"
NOFILE_MAX="${METOD_NOFILE_MAX:-8192}"
[[ "$MEMORY_MAX" =~ ^[1-9][0-9]*[KMGT]?$ ]] || fail "METOD_MEMORY_MAX heeft een onveilig formaat"
safe_uint METOD_TASKS_MAX "$TASKS_MAX"
safe_uint METOD_NOFILE_MAX "$NOFILE_MAX"
(( 10#$TASKS_MAX >= 16 && 10#$TASKS_MAX <= 4096 )) || fail "METOD_TASKS_MAX buiten veilige grens"
(( 10#$NOFILE_MAX >= 1024 && 10#$NOFILE_MAX <= 1048576 )) || fail "METOD_NOFILE_MAX buiten veilige grens"

/usr/bin/python3 -I -S -B - "$CREDS_FILE" "$PROD" <<'PY'
import base64,json,re,sys
p=sys.argv[1]; prod=sys.argv[2]=='1'; obj=json.load(open(p,encoding='utf-8'))
users=obj.get('users') if isinstance(obj,dict) else None
if not isinstance(users,list) or not users: raise SystemExit('individual users[] are required')
active=0
for user in users:
    if user.get('active') is False: continue
    active += 1
    name=str(user.get('username') or '')
    h=str(user.get('password_hash') or '')
    if not re.fullmatch(r'[A-Za-z0-9_.@-]{3,80}',name): raise SystemExit('invalid individual admin username')
    if not re.fullmatch(r'pbkdf2_sha256\$600000\$[A-Za-z0-9._-]{16,128}\$[a-f0-9]{64}',h) or user.get('password'):
        raise SystemExit('admin password hash must use the exact 600000-iteration contract')
    if prod:
        secret=re.sub(r'\s+','',str(user.get('totp_secret') or '')).upper()
        if not re.fullmatch(r'[A-Z2-7]{16,128}',secret): raise SystemExit('invalid TOTP secret contract')
        if len(base64.b32decode(secret + '='*((8-len(secret)%8)%8),casefold=True)) < 10: raise SystemExit('TOTP secret too short')
        if 'admin' not in set(user.get('roles') or []): raise SystemExit('admin role missing')
if active < 1: raise SystemExit('at least one active individual admin is required')
print('Admin credential contract OK')
PY

EFFECTIVE_CPU_COUNT="$(nproc)"
safe_uint EFFECTIVE_CPU_COUNT "$EFFECTIVE_CPU_COUNT"
if (( 10#$EFFECTIVE_CPU_COUNT <= 1 )); then
  PROVEN_OPTIMIZER_CAP=1
elif (( 10#$EFFECTIVE_CPU_COUNT <= 3 )); then
  PROVEN_OPTIMIZER_CAP=2
else
  PROVEN_OPTIMIZER_CAP=$((10#$EFFECTIVE_CPU_COUNT / 2))
  (( PROVEN_OPTIMIZER_CAP <= 8 )) || PROVEN_OPTIMIZER_CAP=8
fi
DEFAULT_OPTIMIZER_WORKERS=2
(( PROVEN_OPTIMIZER_CAP >= 2 )) || DEFAULT_OPTIMIZER_WORKERS=1
PUBLIC_JOB_MAX_CONCURRENT_VALUE="${PUBLIC_JOB_MAX_CONCURRENT:-$DEFAULT_OPTIMIZER_WORKERS}"
PUBLIC_JOB_MAX_QUEUED_VALUE="${PUBLIC_JOB_MAX_QUEUED:-8}"
PUBLIC_JOB_MAX_CONCURRENT_PER_IP_VALUE="${PUBLIC_JOB_MAX_CONCURRENT_PER_IP:-6}"
OPTIMIZER_TIMEOUT_SECONDS_VALUE="${OPTIMIZER_TIMEOUT_SECONDS:-300}"
OPTIMIZER_JOB_TIMEOUT_SECONDS_VALUE="${OPTIMIZER_JOB_TIMEOUT_SECONDS:-900}"
HTTP_MAX_CONNECTIONS_VALUE="${HTTP_MAX_CONNECTIONS:-128}"
HTTP_WORKERS_VALUE="${HTTP_WORKERS:-16}"
MIN_FREE_STATE_BYTES_VALUE="${MIN_FREE_STATE_BYTES:-1073741824}"
MIN_FREE_STATE_INODES_VALUE="${MIN_FREE_STATE_INODES:-10000}"
for pair in \
  "PUBLIC_JOB_MAX_CONCURRENT:$PUBLIC_JOB_MAX_CONCURRENT_VALUE" \
  "PUBLIC_JOB_MAX_QUEUED:$PUBLIC_JOB_MAX_QUEUED_VALUE" \
  "PUBLIC_JOB_MAX_CONCURRENT_PER_IP:$PUBLIC_JOB_MAX_CONCURRENT_PER_IP_VALUE" \
  "OPTIMIZER_TIMEOUT_SECONDS:$OPTIMIZER_TIMEOUT_SECONDS_VALUE" \
  "OPTIMIZER_JOB_TIMEOUT_SECONDS:$OPTIMIZER_JOB_TIMEOUT_SECONDS_VALUE" \
  "HTTP_MAX_CONNECTIONS:$HTTP_MAX_CONNECTIONS_VALUE" \
  "HTTP_WORKERS:$HTTP_WORKERS_VALUE" \
  "MIN_FREE_STATE_BYTES:$MIN_FREE_STATE_BYTES_VALUE" \
  "MIN_FREE_STATE_INODES:$MIN_FREE_STATE_INODES_VALUE"; do
  safe_uint "${pair%%:*}" "${pair#*:}"
done
(( 10#$PUBLIC_JOB_MAX_CONCURRENT_VALUE >= 1 && 10#$PUBLIC_JOB_MAX_CONCURRENT_VALUE <= 8 )) || fail "PUBLIC_JOB_MAX_CONCURRENT moet 1..8 zijn"
(( 10#$PUBLIC_JOB_MAX_CONCURRENT_VALUE <= PROVEN_OPTIMIZER_CAP )) || fail "PUBLIC_JOB_MAX_CONCURRENT=$PUBLIC_JOB_MAX_CONCURRENT_VALUE overschrijdt de CPU-capaciteit $PROVEN_OPTIMIZER_CAP voor $EFFECTIVE_CPU_COUNT effectieve CPU('s)"
[[ "$PUBLIC_JOB_MAX_QUEUED_VALUE" == "8" ]] || fail "PUBLIC_JOB_MAX_QUEUED moet 8 zijn"
(( 10#$PUBLIC_JOB_MAX_CONCURRENT_PER_IP_VALUE >= 1 && 10#$PUBLIC_JOB_MAX_CONCURRENT_PER_IP_VALUE <= 8 )) || fail "PUBLIC_JOB_MAX_CONCURRENT_PER_IP moet 1..8 zijn"
(( 10#$OPTIMIZER_TIMEOUT_SECONDS_VALUE >= 30 && 10#$OPTIMIZER_TIMEOUT_SECONDS_VALUE <= 3600 )) || fail "OPTIMIZER_TIMEOUT_SECONDS moet 30..3600 zijn"
(( 10#$OPTIMIZER_JOB_TIMEOUT_SECONDS_VALUE >= 10#$OPTIMIZER_TIMEOUT_SECONDS_VALUE && 10#$OPTIMIZER_JOB_TIMEOUT_SECONDS_VALUE <= 86400 )) || fail "OPTIMIZER_JOB_TIMEOUT_SECONDS moet minimaal de subjobtimeout en maximaal 86400 zijn"
(( 10#$HTTP_MAX_CONNECTIONS_VALUE >= 1 && 10#$HTTP_MAX_CONNECTIONS_VALUE <= 256 )) || fail "HTTP_MAX_CONNECTIONS moet 1..256 zijn"
(( 10#$HTTP_WORKERS_VALUE >= 4 && 10#$HTTP_WORKERS_VALUE <= 64 )) || fail "HTTP_WORKERS moet 4..64 zijn"
(( 10#$MIN_FREE_STATE_BYTES_VALUE >= 67108864 )) || fail "MIN_FREE_STATE_BYTES moet minimaal 67108864 zijn"
(( 10#$MIN_FREE_STATE_INODES_VALUE >= 100 )) || fail "MIN_FREE_STATE_INODES moet minimaal 100 zijn"

ADMIN_ALLOWED_NETWORKS_VALUE="${ADMIN_ALLOWED_NETWORKS:-}"
if [[ ! -v ADMIN_ALLOWED_NETWORKS && -f "$ENV_FILE" && ! -L "$ENV_FILE" ]]; then
  ADMIN_ALLOWED_NETWORKS_VALUE="$(/usr/bin/python3 -I -S -B - "$ENV_FILE" <<'PYNETWORK'
import sys
from pathlib import Path
rows = [line.split('=', 1)[1].strip() for line in Path(sys.argv[1]).read_text().splitlines() if line.startswith('ADMIN_ALLOWED_NETWORKS=')]
if len(rows) > 1:
    raise SystemExit('Duplicate Admin network setting')
print(rows[0] if rows else '')
PYNETWORK
)"
fi
if [[ "$MODE" == "production" && -z "$ADMIN_ALLOWED_NETWORKS_VALUE" ]]; then
  fail "Productie vereist ADMIN_ALLOWED_NETWORKS: de IP-adressen of VPN-netwerken van beheerders"
fi
python3 - "$ADMIN_ALLOWED_NETWORKS_VALUE" <<'PYIP'
import ipaddress, sys
raw=sys.argv[1]
if raw:
    if any(character in raw for character in '\r\n'):
        raise SystemExit('Invalid Admin network configuration')
    for value in raw.split(','):
        ipaddress.ip_network(value.strip(), strict=False)
PYIP

cat > "$ENV_FILE.tmp" <<EOF
METOD_PORT=8792
METOD_STATE_ROOT=$STATE_DIR
METOD_PUBLIC_BASE_URL=$APP_PUBLIC_ORIGIN
APP_ENV=$APP_ENV
STAGING_EXTERNAL_HTTPS_PREVIEW=$STAGING_EXTERNAL_HTTPS_PREVIEW
PRODUCTION_HARDENING=$PROD
ADMIN_HASH_ONLY=$PROD
ADMIN_STAGING_OPEN=0
TRUSTED_PROXY_IPS=127.0.0.1,::1
ALLOWED_ORIGINS=$APP_PUBLIC_ORIGIN
ALLOWED_ADMIN_ORIGINS=$APP_PUBLIC_ORIGIN
ADMIN_ALLOWED_NETWORKS=$ADMIN_ALLOWED_NETWORKS_VALUE
PUBLIC_JOB_MAX_CONCURRENT=$PUBLIC_JOB_MAX_CONCURRENT_VALUE
PUBLIC_JOB_MAX_QUEUED=$PUBLIC_JOB_MAX_QUEUED_VALUE
PUBLIC_JOB_MAX_CONCURRENT_PER_IP=$PUBLIC_JOB_MAX_CONCURRENT_PER_IP_VALUE
OPTIMIZER_TIMEOUT_SECONDS=$OPTIMIZER_TIMEOUT_SECONDS_VALUE
OPTIMIZER_JOB_TIMEOUT_SECONDS=$OPTIMIZER_JOB_TIMEOUT_SECONDS_VALUE
HTTP_MAX_CONNECTIONS=$HTTP_MAX_CONNECTIONS_VALUE
HTTP_WORKERS=$HTTP_WORKERS_VALUE
PUBLIC_JSON_MAX_BYTES=16777216
SUBMIT_MAX_BYTES=8388608
PUBLIC_DXF_BLOB_MAX_BYTES=2097152
PUBLIC_DXF_TOTAL_MAX_BYTES=33554432
PUBLIC_DXF_MAX_COUNT=500
PUBLIC_JOB_TOTAL_QTY_LIMIT=250
JOB_OUTPUT_MAX_BYTES=536870912
MIN_FREE_STATE_BYTES=$MIN_FREE_STATE_BYTES_VALUE
MIN_FREE_STATE_INODES=$MIN_FREE_STATE_INODES_VALUE
PRODUCTION_MIN_CATALOG_RECORDS=$CATALOG_MIN
CATALOG_SIGNOFF_FILE=$STATE_DIR/system/catalog_signoff.json
ADMIN_SESSION_IDLE_SEC=1800
ADMIN_SESSION_ABSOLUTE_SEC=28800
NTFY_ALLOWED_HOSTS=${NTFY_ALLOWED_HOSTS:-ntfy.sh}
OFFSITE_BACKUP_VERIFIED=${OFFSITE_BACKUP_VERIFIED:-0}
OFFSITE_BACKUP_PROVIDER=${OFFSITE_BACKUP_PROVIDER:-}
RESTORE_TEST_PROOF_FILE=$STATE_DIR/system/restore_test_proof.json
RESTORE_TEST_MAX_AGE_DAYS=90
RETENTION_ACTIVE_DAYS=90
RETENTION_OPEN_REQUEST_MAX_DAYS=365
RETENTION_ARCHIVE_DAYS=90
ORPHAN_JOB_RETENTION_DAYS=7
CATALOG_STAGE_RETENTION_DAYS=7
CATALOG_HISTORY_KEEP=12
CATALOG_HISTORY_RETENTION_DAYS=180
ORPHAN_DECOR_MEDIA_RETENTION_DAYS=30
ORPHAN_QUEUE_RETENTION_DAYS=30
ORPHAN_SUBMISSION_CLAIM_RETENTION_DAYS=1
ORPHAN_DRAFT_RETENTION_DAYS=30
ROTATED_LOG_RETENTION_DAYS=30
REQUEST_INDEX_MAX_ACTIVE_ROWS=250000
AUTO_BACKUP_KEEP=8
MANUAL_BACKUP_KEEP=12
AUTO_BACKUP_MAX_AGE_DAYS=70
MANUAL_BACKUP_MAX_AGE_DAYS=120
BACKUP_TEMP_RETENTION_HOURS=24
BACKUP_TOTAL_MAX_BYTES=21474836480
BACKUP_MAX_SOURCE_BYTES=17179869184
BACKUP_MAX_FILES=200000
BACKUP_MIN_FREE_BYTES=$MIN_FREE_STATE_BYTES_VALUE
BACKUP_MIN_FREE_INODES=$MIN_FREE_STATE_INODES_VALUE
BACKUP_DRAIN_TIMEOUT_SEC=60
RETENTION_DRAIN_TIMEOUT_SEC=60
EOF
chmod 0640 "$ENV_FILE.tmp"
chown root:metod-pax "$ENV_FILE.tmp"
mv -f "$ENV_FILE.tmp" "$ENV_FILE"

install -d -m 0700 -o metod-pax -g metod-pax "${STATE_DIR}-privacy"

cat > "$SERVICE_FILE.tmp" <<EOF
[Unit]
Description=METOD/PAX configurator ($VERSION)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=metod-pax
Group=metod-pax
WorkingDirectory=$CURRENT_LINK/app
EnvironmentFile=$ENV_FILE
EnvironmentFile=-$ENV_DIR/backup-budget.env
LoadCredential=admin_credentials.live.json:$CREDS_FILE
Environment=PYTHONDONTWRITEBYTECODE=1
Environment=PYTHONNOUSERSITE=1
UnsetEnvironment=PYTHONPATH PYTHONHOME PYTHONSTARTUP PYTHONINSPECT PYTHONUSERBASE
ExecStart=/usr/bin/python3 -B $CURRENT_LINK/app/server_py.py
Restart=on-failure
RestartSec=3
TimeoutStartSec=90
TimeoutStopSec=30
KillMode=control-group
UMask=0027
NoNewPrivileges=yes
PrivateTmp=yes
PrivateDevices=yes
ProtectSystem=strict
ProtectHome=yes
ProtectKernelTunables=yes
ProtectKernelModules=yes
ProtectKernelLogs=yes
ProtectControlGroups=yes
ProtectProc=invisible
ProcSubset=pid
ProtectClock=yes
ProtectHostname=yes
RestrictNamespaces=yes
RestrictSUIDSGID=yes
RestrictRealtime=yes
LockPersonality=yes
SystemCallArchitectures=native
RemoveIPC=yes
CapabilityBoundingSet=
AmbientCapabilities=
RestrictAddressFamilies=AF_UNIX AF_INET AF_INET6
ReadWritePaths=$STATE_DIR ${STATE_DIR}-privacy
MemoryMax=$MEMORY_MAX
TasksMax=$TASKS_MAX
LimitNOFILE=$NOFILE_MAX

[Install]
WantedBy=multi-user.target
EOF
chown root:root "$SERVICE_FILE.tmp"
chmod 0644 "$SERVICE_FILE.tmp"
mv -f "$SERVICE_FILE.tmp" "$SERVICE_FILE"

cat > "$NGINX_LIMITS.tmp" <<'EOF'
limit_req_zone $binary_remote_addr zone=metod_general:10m rate=10r/s;
limit_req_zone $binary_remote_addr zone=metod_jobs:10m rate=12r/m;
limit_req_zone $binary_remote_addr zone=metod_auth:10m rate=5r/m;
limit_conn_zone $binary_remote_addr zone=metod_conn:10m;
EOF
chown root:root "$NGINX_LIMITS.tmp"
chmod 0644 "$NGINX_LIMITS.tmp"
mv -f "$NGINX_LIMITS.tmp" "$NGINX_LIMITS"

nginx_server_hardening(){
cat <<'EOF'
    server_tokens off;
    gzip off;
    # HTML and private JSON are intentionally excluded from response compression.
EOF
}

proxy_locations(){
cat <<'EOF'
    proxy_headers_hash_max_size 1024;
    proxy_headers_hash_bucket_size 128;
    access_log /var/log/nginx/metod-pax/access.log combined;
    error_log /var/log/nginx/metod-pax/error.log warn;
    client_max_body_size 20m;
    client_header_timeout 10s;
    client_body_timeout 30s;
    proxy_request_buffering on;
    limit_conn metod_conn 20;
    limit_req zone=metod_general burst=40 nodelay;
    limit_req_status 429;
    limit_conn_status 429;

    location ~ "^/assets/tool-a\.[a-f0-9]{16}\.(js|css)$" {
        gzip on;
        gzip_vary on;
        gzip_min_length 1024;
        gzip_comp_level 5;
        gzip_types text/css application/javascript text/javascript;
        proxy_pass http://127.0.0.1:8792;
        proxy_hide_header Strict-Transport-Security;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $remote_addr;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header X-Forwarded-Host $host;
    }
    location = /api/jobs {
        limit_req zone=metod_jobs burst=5 nodelay;
        proxy_pass http://127.0.0.1:8792;
        proxy_hide_header Strict-Transport-Security;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $remote_addr;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header X-Forwarded-Host $host;
        proxy_read_timeout 60s;
    }
    location = /api/admin/login {
        limit_req zone=metod_auth burst=2 nodelay;
        proxy_pass http://127.0.0.1:8792;
        proxy_hide_header Strict-Transport-Security;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $remote_addr;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header X-Forwarded-Host $host;
    }

    location / {
        proxy_pass http://127.0.0.1:8792;
        proxy_hide_header Strict-Transport-Security;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $remote_addr;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header X-Forwarded-Host $host;
        proxy_connect_timeout 10s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
EOF
}

if [[ "$MODE" == "staging" ]]; then
  {
    echo 'server {'
    echo "    listen $STAGING_BIND:$SITE_PORT;"
    echo '    server_name _;'
    nginx_server_hardening
    if [[ -n "$STAGING_EXTERNAL_ORIGIN" ]]; then
      # The externally exposed staging listener is loopback-only and is reached
      # solely through the local cloudflared hop. Let Nginx validate the single
      # Cloudflare client-IP header, then overwrite both upstream IP headers with
      # that normalized address. This also restores per-client Nginx rate limits.
      echo '    set_real_ip_from 127.0.0.1;'
      echo '    real_ip_header CF-Connecting-IP;'
      echo '    real_ip_recursive off;'
    fi
    if [[ -n "$STAGING_CIDR" ]]; then
      echo "    allow $STAGING_CIDR;"
      echo '    deny all;'
    fi
    echo '    add_header X-METOD-Environment staging always;'
    proxy_locations
    echo '}'
  } > "$NGINX_SITE.tmp"
else
  # Production must own the default vhosts. Failing closed is safer than
  # silently serving a distro default or an unrelated site on the same host.
  for enabled_site in /etc/nginx/sites-enabled/*; do
    [[ -e "$enabled_site" || -L "$enabled_site" ]] || continue
    case "$(basename "$enabled_site")" in
      metod-pax|metod-pax-8790) ;;
      *) fail "Onverwachte enabled Nginx-site in production: $enabled_site (schakel deze bewust uit)" ;;
    esac
  done
  {
    echo 'server {'
    echo '    listen 80 default_server;'
    echo '    listen [::]:80 default_server;'
    echo '    server_name _;'
    nginx_server_hardening
    echo '    return 444;'
    echo '}'
    echo 'server {'
    echo '    listen 80;'
    echo '    listen [::]:80;'
    echo "    server_name $DOMAIN;"
    nginx_server_hardening
    echo "    return 308 https://$DOMAIN\$request_uri;"
    echo '}'
    echo 'server {'
    echo '    listen 443 ssl http2 default_server;'
    echo '    listen [::]:443 ssl http2 default_server;'
    echo '    server_name _;'
    nginx_server_hardening
    echo "    ssl_certificate $TLS_CERT;"
    echo "    ssl_certificate_key $TLS_KEY;"
    echo '    ssl_protocols TLSv1.2 TLSv1.3;'
    echo '    return 444;'
    echo '}'
    echo 'server {'
    echo '    listen 443 ssl http2;'
    echo '    listen [::]:443 ssl http2;'
    echo "    server_name $DOMAIN;"
    nginx_server_hardening
    echo "    ssl_certificate $TLS_CERT;"
    echo "    ssl_certificate_key $TLS_KEY;"
    echo '    ssl_protocols TLSv1.2 TLSv1.3;'
    echo '    ssl_session_timeout 1d;'
    echo '    ssl_session_cache shared:METODSSL:10m;'
    # includeSubDomains is deliberately omitted until every subdomain is
    # inventoried and HTTPS-covered; enabling it prematurely can break them.
    echo '    add_header Strict-Transport-Security "max-age=31536000" always;'
    proxy_locations
    echo '}'
  } > "$NGINX_SITE.tmp"
fi
if [[ "$MODE" == "staging" && -n "$STAGING_EXTERNAL_ORIGIN" ]]; then
  sed -i 's/proxy_set_header X-Forwarded-Proto $scheme;/proxy_set_header X-Forwarded-Proto https;/g' "$NGINX_SITE.tmp"
  [[ "$(grep -Fc 'proxy_set_header X-Forwarded-Proto https;' "$NGINX_SITE.tmp")" == "4" ]] \
    || fail "Externe stagingproxy mist de vier verplichte HTTPS-forwardingheaders"
  ! grep -Fq 'proxy_set_header X-Forwarded-Proto $scheme;' "$NGINX_SITE.tmp" \
    || fail "Externe stagingproxy bevat nog een HTTP-schema-afleiding"
fi
chown root:root "$NGINX_SITE.tmp"
chmod 0644 "$NGINX_SITE.tmp"
mv -f "$NGINX_SITE.tmp" "$NGINX_SITE"
rm -f /etc/nginx/sites-enabled/metod-pax-8790
ln -sfn "$NGINX_SITE" "$NGINX_LINK"

# A private child namespace avoids overlapping the stock /var/log/nginx/*.log
# rule. Existing historical top-level logs remain covered by the distro rule.
[[ ! -L /var/log/nginx/metod-pax ]] || fail "Nginx-logmap mag geen symlink zijn"
install -d -o root -g adm -m 0750 /var/log/nginx/metod-pax
cat > "$NGINX_LOGROTATE.tmp" <<'EOF'
/var/log/nginx/metod-pax/access.log /var/log/nginx/metod-pax/error.log {
    daily
    rotate 30
    maxage 30
    missingok
    notifempty
    compress
    delaycompress
    create 0640 www-data adm
    sharedscripts
    postrotate
        [ ! -s /run/nginx.pid ] || kill -USR1 "$(cat /run/nginx.pid)"
    endscript
}
EOF
chown root:root "$NGINX_LOGROTATE.tmp"
chmod 0644 "$NGINX_LOGROTATE.tmp"
mv -f "$NGINX_LOGROTATE.tmp" "$NGINX_LOGROTATE"
[[ -f /etc/logrotate.conf && ! -L /etc/logrotate.conf ]] || fail "Canonieke host-logrotateconfig ontbreekt"
logrotate --debug /etc/logrotate.conf >/dev/null

# Prove actual state write access as the service identity; the full runtime
# preflight then validates catalog/pricing/security/restore evidence. The full
# outcome matrix already ran before maintenance and is not repeated during
# downtime.
runuser -u metod-pax -- env PYTHONDONTWRITEBYTECODE=1 PYTHONSAFEPATH=1 PYTHONNOUSERSITE=1 METOD_STATE_ROOT="$STATE_DIR" /usr/bin/python3 -I -S -B - "$STATE_DIR" <<'PY'
import os,secrets,sys
from pathlib import Path
root=Path(sys.argv[1]); probe=root/f'.deploy-write-{os.getpid()}-{secrets.token_hex(4)}'
try:
    with probe.open('x',encoding='utf-8') as f:
        f.write('ok\n'); f.flush(); os.fsync(f.fileno())
finally:
    probe.unlink(missing_ok=True)
PY
PYTHONDONTWRITEBYTECODE=1 ADMIN_CREDENTIALS_FILE="$CREDS_FILE" \
  /usr/bin/python3 -I -S -B "$CURRENT_LINK/tools/final_preflight.py" \
  --release "$CURRENT_LINK" --verify-checksums --runtime-only \
  --env-file "$ENV_FILE" --state-root "$STATE_DIR"
nginx -t
systemctl daemon-reload
systemctl enable metod-pax.service >/dev/null
systemctl restart metod-pax.service

RUNTIME_PROBE_DIR="$(mktemp -d /tmp/metod-pax-runtime-identity.XXXXXX)"
chmod 0700 "$RUNTIME_PROBE_DIR"
cleanup_runtime_probes(){ rm -rf -- "$RUNTIME_PROBE_DIR"; }
trap cleanup_runtime_probes EXIT
LIVE_MARKER_PROBE="$RUNTIME_PROBE_DIR/health-live.json"
TOOL_A_MARKER_PROBE="$RUNTIME_PROBE_DIR/toolA.html"
LIVE_OK=0
for _ in $(seq 1 30); do
  if curl -fsS --connect-timeout 1 --max-time 2 \
      http://127.0.0.1:8792/health/live -o "$LIVE_MARKER_PROBE" 2>/dev/null \
      && /usr/bin/python3 -I -S -B "$CURRENT_LINK/tools/deploy_runtime_identity_probe.py" \
        --release "$CURRENT_LINK" --liveness "$LIVE_MARKER_PROBE" >/dev/null; then
    LIVE_OK=1
    break
  fi
  if ! systemctl is-active --quiet metod-pax.service; then
    break
  fi
  sleep 1
done
systemctl is-active --quiet metod-pax.service || { journalctl -u metod-pax.service -n 120 --no-pager >&2; fail "service startte niet"; }
if [[ "$LIVE_OK" != "1" ]]; then
  journalctl -u metod-pax.service -n 120 --no-pager >&2 || true
  fail "livenesscontrole faalt"
fi
if ! curl -fsS --connect-timeout 2 --max-time 10 http://127.0.0.1:8792/health/ready >/dev/null; then
  curl -sS --connect-timeout 2 --max-time 10 http://127.0.0.1:8792/health/ready >&2 || true
  journalctl -u metod-pax.service -n 120 --no-pager >&2 || true
  fail "readiness faalt (catalogus/pricing/state/disk/DXF)"
fi
if ! curl -fsS --connect-timeout 2 --max-time 10 \
    http://127.0.0.1:8792/toolA.html -o "$TOOL_A_MARKER_PROBE"; then
  fail "Tool A runtime kon vóór edge-open niet worden opgehaald"
fi
/usr/bin/python3 -I -S -B "$CURRENT_LINK/tools/deploy_runtime_identity_probe.py" \
  --release "$CURRENT_LINK" --tool-a "$TOOL_A_MARKER_PROBE" \
  || fail "Tool A runtime-identiteit wijkt af van de immutable actuele release"
systemctl reload nginx
cleanup_runtime_probes
trap - EXIT

if [[ "$MODE" == "staging" ]]; then
  info "Staging actief: $PUBLIC_ORIGIN/ (niet geschikt als publieke livegang)"
  if [[ -n "$STAGING_EXTERNAL_ORIGIN" ]]; then
    info "Tijdelijke HTTPS-preview actief als applicatie-origin: $STAGING_EXTERNAL_ORIGIN/"
  fi
else
  info "Production HTTPS actief: https://$DOMAIN/"
fi
info "Non-root service, bounded HTTP/SSE, externe state en Nginx-limits zijn actief."
