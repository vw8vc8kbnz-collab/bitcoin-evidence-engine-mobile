# Componenten en gebruiksrechten

De applicatiebron wordt als project-eigen bron behandeld; dit pakket verleent geen zelfstandige open-sourcelicentie. Gebruik en overdracht volgen de afspraken met de eigenaar.

De verplichte HTTP-server is Waitress 3.0.2. De exacte wheel staat in `dependencies/` en heeft een SHA-256 in de pakketmanifesten; de bijbehorende ZPL-2.1-licentie staat ernaast. De overige verplichte backendcode gebruikt de Python-standard library. Python, nginx, restic en het besturingssysteem worden door de beheerder geïnstalleerd en zijn geen onderdeel van deze zip.

Pillow is optioneel voor runtime-beeldverwerking en verplicht voor de synthetische testfixtures. De ontwikkelafhankelijkheden staan exact vast in `package-lock.json` en `requirements-dev.txt`. npm-pakketten, browsers en node_modules worden niet in de distributie meegenomen. De publieke browserbundel bevat de projectmodules; esbuild zelf wordt niet in de browser uitgevoerd.

`SBOM.cdx.json` benoemt de runtime- en directe ontwikkelcomponenten. Het npm-lockbestand beschrijft de transitieve npm-resoluties en integriteit. Dit is geen claim dat de complete afhankelijkheden van het besturingssysteem of de live server zijn geïnventariseerd.

Logo's, decorafbeeldingen en DXF-bestanden zijn aangeleverde productiemiddelen. De eigenaar beheert hun gebruiksrechten. De broncodecontrole bewijst die rechten niet. De PAX-bestandsnamen volgen kasthoogtes; de werkelijke geometrie is 1945/2294 mm. Het compacte PAX-sjabloon is geometrisch gecontroleerd en hoeft niet kunstmatig groter te worden gemaakt.
