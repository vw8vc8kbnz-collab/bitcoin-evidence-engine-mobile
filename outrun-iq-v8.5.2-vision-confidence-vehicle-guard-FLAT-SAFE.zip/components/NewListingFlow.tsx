"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { eur } from "@/lib/types";
import type { PriceAdvice } from "@/lib/ai";

type Cat = "witgoed" | "meubels" | "keukens" | "tuin" | "overig";
type PhotoRole = { index: number; role: string; buyerFacing: boolean; reason?: string };
type VisionDetails = { conditionReason?: string; defects?: string[]; accessories?: string[]; energyLabel?: string; sellingPoints?: string[]; photosAnalyzed?: number; source?: string; model?: string; modelCandidates?: string[]; articleNumber?: string; serialMasked?: string; ocrText?: string; confidence?: number; uncertainty?: boolean; needsExtraPhotos?: string[]; photoRoles?: PhotoRole[]; };
const CATS: { v: Cat; label: string }[] = [
  { v: "witgoed", label: "Witgoed" }, { v: "meubels", label: "Meubels" },
  { v: "keukens", label: "Keukens" }, { v: "tuin", label: "Tuin" }, { v: "overig", label: "Overig" },
];

const inputStyle: React.CSSProperties = {
  border: 0, background: "none", font: "inherit", width: "100%", outline: "none", color: "#fff",
};

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="dli" style={{ cursor: "default" }}>
      <b style={{ flex: "none", width: 108, fontSize: 11 }}>{label}</b>
      <span style={{ flex: 1 }}>{children}</span>
    </div>
  );
}

export function NewListingFlow() {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  // stap 1
  const [photos, setPhotos] = useState<string[]>([]);
  const [vision, setVision] = useState<"idle" | "busy" | "done" | "failed">("idle");
  const [visionNote, setVisionNote] = useState("");
  const [visionDetails, setVisionDetails] = useState<VisionDetails | null>(null);
  // stap 2
  const [f, setF] = useState({
    title: "", brand: "", partnerRef: "", category: "witgoed" as Cat, condition: "", conditionScore: 8,
    defect: "", newPrice: "", stock: "1", delivery: "Bezorging in overleg", deliveryPrice: "0",
  });
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
    setF({ ...f, [k]: e.target.value });
  // stap 3
  const [advice, setAdvice] = useState<PriceAdvice | null>(null);
  const [choice, setChoice] = useState<"fast" | "outlet" | "premium">("outlet");
  const [ownPrice, setOwnPrice] = useState("");

  async function upload(files: FileList | null) {
    if (!files?.length) return;
    setBusy(true); setErr("");
    const fd = new FormData();
    Array.from(files).slice(0, Math.max(0, 5 - photos.length)).forEach(x => fd.append("photos", x));
    const r = await fetch("/api/partner/upload", { method: "POST", body: fd });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (r.ok) {
      const next = [...photos, ...j.urls].slice(0, 5);
      setPhotos(next);
      if (vision === "idle" && next[0]) recognize(next);
    } else setErr(j.error || "Upload mislukt");
  }

  /** AI vult velden vooraf in — nooit over eigen invoer heen. */
  async function recognize(photoUrls: string[]) {
    const batch = photoUrls.slice(0, 5);
    if (!batch.length) return;
    setVision("busy"); setVisionNote(""); setVisionDetails(null);
    const r = await fetch("/api/partner/vision", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ photoUrls: batch }),
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) { setVision("failed"); setVisionNote(j.error || "AI-herkenning mislukt — vul de velden zelf in."); return; }
    const detailDefects = Array.isArray(j.defects) ? j.defects.filter(Boolean).slice(0, 5) : [];
    const conditionParts = [j.condition, j.conditionReason].filter(Boolean).join(" · ");
    setF(prev => ({
      ...prev,
      title: prev.title || j.title || "",
      brand: prev.brand || j.brand || "",
      category: (prev.title || prev.brand) ? prev.category : (j.category ?? prev.category),
      condition: prev.condition || conditionParts || "",
      conditionScore: prev.condition ? prev.conditionScore : (j.conditionScore ?? prev.conditionScore),
      defect: prev.defect || j.defect || detailDefects[0] || "",
      newPrice: prev.newPrice || (j.newPriceEstimate > 0 ? String(j.newPriceEstimate) : ""),
    }));
    setVisionDetails({
      conditionReason: j.conditionReason,
      defects: detailDefects,
      accessories: Array.isArray(j.accessories) ? j.accessories.filter(Boolean).slice(0, 5) : [],
      energyLabel: j.energyLabel || "",
      sellingPoints: Array.isArray(j.sellingPoints) ? j.sellingPoints.filter(Boolean).slice(0, 3) : [],
      photosAnalyzed: j.photosAnalyzed,
      source: j.source,
      model: j.model || "",
      modelCandidates: Array.isArray(j.modelCandidates) ? j.modelCandidates.filter(Boolean).slice(0, 4) : [],
      articleNumber: j.articleNumber || "",
      serialMasked: j.serialMasked || "",
      ocrText: j.ocrText || "",
      confidence: Number(j.confidence) || 0,
      uncertainty: Boolean(j.uncertainty),
      needsExtraPhotos: Array.isArray(j.needsExtraPhotos) ? j.needsExtraPhotos.filter(Boolean).slice(0, 4) : [],
      photoRoles: Array.isArray(j.photoRoles) ? j.photoRoles.slice(0, 5) : [],
    });
    setVision("done");
    setVisionNote(`AI heeft ${j.photosAnalyzed || batch.length} foto${(j.photosAnalyzed || batch.length) === 1 ? "" : "'s"} beoordeeld en stap 2 ingevuld${j.newPriceEstimate > 0 ? " (nieuwprijs is een schatting)" : ""}. Controleer alles.`);
  }

  const step2ok = f.title && f.newPrice && Number(f.newPrice) > 0;

  async function runAi() {
    setBusy(true); setErr(""); setAdvice(null); setStep(3);
    const r = await fetch("/api/partner/pricing", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        title: f.title, brand: f.brand, category: f.category, condition: f.condition,
        conditionScore: Number(f.conditionScore), newPrice: Number(f.newPrice),
        stock: Number(f.stock), photosCount: photos.length, defect: f.defect || undefined,
        visionSummary: visionDetails ? [visionDetails.conditionReason, ...(visionDetails.defects || []), ...(visionDetails.sellingPoints || [])].filter(Boolean).join(" · ") : undefined,
        conditionReason: visionDetails?.conditionReason,
        defects: visionDetails?.defects, accessories: visionDetails?.accessories, energyLabel: visionDetails?.energyLabel,
      }),
    });
    const j = await r.json().catch(() => null);
    setBusy(false);
    if (r.ok && j?.outlet) setAdvice(j);
    else { setErr(j?.error || "Prijsadvies mislukt"); setStep(2); }
  }

  async function publish() {
    if (!advice) return;
    const price = ownPrice ? Math.round(Number(ownPrice)) : advice[choice];
    setBusy(true); setErr("");
    const r = await fetch("/api/partner/listings", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...f, conditionScore: Number(f.conditionScore), newPrice: Number(f.newPrice),
        stock: Number(f.stock), deliveryPrice: Number(f.deliveryPrice),
        perUnit: Number(f.stock) > 1, photos: safePublicPhotos, internalPhotos,
        visionMetadata: visionDetails ? {
          model: visionDetails.model,
          modelCandidates: visionDetails.modelCandidates,
          articleNumber: visionDetails.articleNumber,
          serialMasked: visionDetails.serialMasked,
          ocrText: visionDetails.ocrText,
          confidence: visionDetails.confidence,
          uncertainty: visionDetails.uncertainty,
          needsExtraPhotos: visionDetails.needsExtraPhotos,
          photoRoles: visionDetails.photoRoles,
        } : undefined,
        price, fast: advice.fast, premium: advice.premium,
        expectedDays: choice === "fast" ? advice.expectedDaysFast : choice === "premium" ? advice.expectedDaysPremium : advice.expectedDaysOutlet,
        confidence: advice.confidence, comps: advice.comps, aiSource: advice.source,
      }),
    });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (r.ok && j.id) { router.push("/partner/voorraad"); router.refresh(); }
    else setErr(j.error || "Publiceren mislukt");
  }

  const chosen = advice ? (ownPrice ? Math.round(Number(ownPrice)) : advice[choice]) : 0;
  const buyerPhotoIndexes = new Set((visionDetails?.photoRoles || []).filter(r => r.buyerFacing !== false).map(r => r.index - 1));
  const hasRoleAdvice = (visionDetails?.photoRoles || []).length > 0;
  const publicPhotos = hasRoleAdvice ? photos.filter((_, i) => buyerPhotoIndexes.has(i)).slice(0, 5) : photos.slice(0, 5);
  const safePublicPhotos = publicPhotos.length ? publicPhotos : photos.slice(0, Math.min(1, photos.length));
  const internalPhotos = photos.filter(u => !safePublicPhotos.includes(u));

  return (
    <>
      <div className="dots">{[1, 2, 3, 4].map(i => <i key={i} className={step >= i ? "on" : ""} />)}</div>

      {step === 1 && (
        <>
          <div className="upl">
            <div className="thumbs">
              {photos.map(u => (
                <span key={u} className="imw dk">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={u} alt="" />
                </span>
              ))}
              {photos.length < 5 && (
                <label className="add" style={{ cursor: "pointer" }}>+
                  <input type="file" accept="image/*" multiple hidden onChange={e => upload(e.target.files)} />
                </label>
              )}
            </div>
            <p>{photos.length === 0 ? "Max 5 foto's: voorkant · zijkant · detail/schade · accessoires · label/artikelnummer" : `${photos.length}/5 foto's — AI kiest zelf wat openbaar wordt en wat intern blijft`}</p>
          </div>
          {vision === "busy" && (
            <div className="scan"><div className="r">AI herkent je product <span>analyseren…</span></div></div>
          )}
          {vision === "done" && (
            <div className="scan"><div className="r">AI-herkenning <span className="done">{visionDetails?.photosAnalyzed || photos.length} foto's geanalyseerd</span></div></div>
          )}
          {vision === "failed" && visionNote && (
            <p className="note" style={{ color: "var(--amber)" }}>{visionNote}{" "}
              {photos[0] && <button className="alink" style={{ color: "var(--petrol-glow)" }} onClick={() => recognize(photos)}>Herken opnieuw →</button>}
            </p>
          )}
          <p className="note">Foto's mogen ook later; zonder foto toont de app een nette illustratie.</p>
          <div className="foot"><button className="btn pri" style={{ width: "100%" }} onClick={() => setStep(2)} disabled={busy}>
            {busy ? "Uploaden…" : vision === "busy" ? "AI herkent je product…" : "Verder — productgegevens"}</button></div>
        </>
      )}

      {step === 2 && (
        <>
          {vision === "done" && visionNote && (
            <p className="note" style={{ margin: "0 4px 10px", color: "var(--petrol-glow)" }}>✦ {visionNote}</p>
          )}
          {visionDetails && (visionDetails.conditionReason || visionDetails.defects?.length || visionDetails.energyLabel) && (
            <div className="scan" style={{ marginBottom: 12 }}>
              {visionDetails.conditionReason && <div className="r">Conditie-motivatie <span className="done">{visionDetails.conditionReason}</span></div>}
              {visionDetails.defects?.length ? <div className="r">Zichtbare details <span className="done">{visionDetails.defects.join(" · ")}</span></div> : null}
              {visionDetails.energyLabel && <div className="r">Energielabel <span className="done">{visionDetails.energyLabel}</span></div>}
              {visionDetails.confidence ? <div className="r">AI-zekerheid <span className={visionDetails.uncertainty ? "" : "done"}>{visionDetails.confidence}/100{visionDetails.uncertainty ? " · bevestigen aanbevolen" : ""}</span></div> : null}
              {visionDetails.modelCandidates?.length ? <div className="r">Modelkandidaten <span className="done">{visionDetails.modelCandidates.join(" · ")}</span></div> : null}
              {visionDetails.articleNumber && <div className="r">Artikelnummer <span className="done">{visionDetails.articleNumber}</span></div>}
              {visionDetails.needsExtraPhotos?.length ? <div className="r">AI vraagt extra zekerheid <span className="done">{visionDetails.needsExtraPhotos.join(" · ")}</span></div> : null}
            </div>
          )}
          <div className="dgroup">
            <Field label="Titel"><input style={inputStyle} value={f.title} onChange={set("title")} placeholder="Bosch Serie 6 wasmachine 9kg" /></Field>
            <Field label="Merk"><input style={inputStyle} value={f.brand} onChange={set("brand")} placeholder="Bosch" /></Field>
            <Field label="Ref / SKU"><input style={inputStyle} value={f.partnerRef} onChange={set("partnerRef")} placeholder="optioneel — bv. MAG-A12-0433" /></Field>
            <Field label="Categorie">
              <select style={{ ...inputStyle, appearance: "none" }} value={f.category} onChange={set("category")}>
                {CATS.map(c => <option key={c.v} value={c.v} style={{ color: "#000" }}>{c.label}</option>)}
              </select>
            </Field>
            <Field label="Conditie"><input style={inputStyle} value={f.condition} onChange={set("condition")} placeholder="Retour, ongebruikt · doos beschadigd" /></Field>
            <Field label="Score /10"><input style={inputStyle} type="number" min={1} max={10} value={f.conditionScore} onChange={set("conditionScore")} /></Field>
            <Field label="Gebrek"><input style={inputStyle} value={f.defect} onChange={set("defect")} placeholder="optioneel — bv. kras zijkant, foto 3" /></Field>
            <Field label="Nieuwprijs €"><input style={inputStyle} type="number" min={1} value={f.newPrice} onChange={set("newPrice")} placeholder="899" /></Field>
            <Field label="Voorraad"><input style={inputStyle} type="number" min={1} value={f.stock} onChange={set("stock")} /></Field>
            <Field label="Levering"><input style={inputStyle} value={f.delivery} onChange={set("delivery")} /></Field>
            <Field label="Bezorgkosten €"><input style={inputStyle} type="number" min={0} value={f.deliveryPrice} onChange={set("deliveryPrice")} /></Field>
          </div>
          {err && <p className="note" style={{ color: "var(--amber)" }}>{err}</p>}
          <div className="foot"><button className="btn pri" style={{ width: "100%" }} onClick={runAi} disabled={!step2ok || busy}>
            Start AI-prijsanalyse</button></div>
        </>
      )}

      {step === 3 && (
        <>
          <div className="scan">
            <div className="r">Productherkenning <span className={advice ? "done" : ""}>{advice ? (f.brand || f.title.split(" ")[0]) : "analyseren…"}</span></div>
            <div className="r">Conditieweging <span className={advice ? "done" : ""}>{advice ? `${f.conditionScore}/10` : "…"}</span></div>
            <div className="r">Prijsanalyse <span className={advice ? "done" : ""}>{advice ? (advice.comps > 0 ? `${advice.comps} AI-prijssignalen` : "modelkennis") : "…"}</span></div>
            <div className="r">Confidence <span className={advice ? "done" : ""}>{advice ? `${advice.confidence}/100` : "…"}</span></div>
          </div>
          {advice && (
            <>
              <p className="note">{advice.reasoning} <span className="mono" style={{ color: advice.source === "deepseek" ? "var(--petrol-glow)" : "var(--amber)" }}>[{advice.source.toUpperCase()}]</span></p>
              <div className="dsec"><h2>Kies je strategie</h2></div>
              <div className="pk3">
                {(["fast", "outlet", "premium"] as const).map(k => (
                  <button key={k} className={`pk${choice === k && !ownPrice ? " on" : ""}`} onClick={() => { setChoice(k); setOwnPrice(""); }}>
                    <label>{k.toUpperCase()}</label><b>{eur(advice[k])}</b>
                    <span>± {k === "fast" ? advice.expectedDaysFast : k === "premium" ? advice.expectedDaysPremium : advice.expectedDaysOutlet} dagen</span>
                  </button>
                ))}
              </div>
              <div className="slabel" style={{ color: "#5F6873" }}>OF ZELF</div>
              <div className="dgroup"><Field label="Eigen prijs €"><input style={inputStyle} type="number" min={1} value={ownPrice} onChange={e => setOwnPrice(e.target.value)} placeholder={String(advice.outlet)} /></Field></div>
              <div className="foot"><button className="btn pri" style={{ width: "100%" }} onClick={() => setStep(4)} disabled={!chosen || chosen <= 0 || chosen >= Number(f.newPrice)}>
                Verder — controleren</button></div>
            </>
          )}
          {!advice && !err && <p className="note">De AI analyseert je product…</p>}
          {err && <p className="note" style={{ color: "var(--amber)" }}>{err}</p>}
        </>
      )}

      {step === 4 && advice && (
        <>
          <div className="scan">
            <div className="r">{f.title} <span className="done">{eur(chosen)}{Number(f.stock) > 1 ? "/st" : ""}</span></div>
            <div className="r">Nieuwprijs <span className="done">{eur(Number(f.newPrice))}</span></div>
            <div className="r">Voorraad <span className="done">{f.stock} stuks</span></div>
            <div className="r">Levering <span className="done">{f.delivery} · {eur(Number(f.deliveryPrice))}</span></div>
            <div className="r">Openbare foto's <span className="done">{safePublicPhotos.length}/5</span></div>
            {internalPhotos.length ? <div className="r">Interne AI/OCR-foto's <span className="done">{internalPhotos.length} niet in galerij</span></div> : null}
          </div>
          <p className="note">Kopers zien het prijsbewijs (fast → outlet → nieuwprijs) bij je listing. Eerlijkheid verkoopt.</p>
          {err && <p className="note" style={{ color: "var(--amber)" }}>{err}</p>}
          <div className="foot"><button className="btn pri" style={{ width: "100%" }} onClick={publish} disabled={busy}>
            {busy ? "Publiceren…" : `Publiceer listing — ${eur(chosen)}`}</button></div>
        </>
      )}
    </>
  );
}
