import Link from "next/link";
import { eur, type Listing } from "@/lib/data";
import { EvidenceStrip } from "./EvidenceStrip";
import { BidBox } from "./BidBox";
import { SaveButton } from "./SaveButton";
import { Stars } from "./Reviews";

export function ListingBody({ l, sellerName, sellerOrders, sellerLogo, myBid, savedOn, rating, aiInsight }:{
  l: Listing; sellerName: string; sellerOrders: number; sellerLogo?: string;
  myBid?: { id: string; amount: number; counterAmount?: number; status: string } | null;
  savedOn?: boolean;
  rating?: { avg: number; count: number } | null;
  aiInsight?: { finalScore: number; dealScore: number; trustScore: number; priceScore: number; urgencyScore: number; label: string; reason: string; priceText: string; trustText: string; urgencyText: string; alternativesHint: string } | null;
}) {
  const disc = Math.round((1 - l.price / l.newPrice) * 100);
  const stockLabel = l.stock > 1 ? `${l.stock} beschikbaar` : "Laatste stuk";
  return (
    <div className="lsheet">
      <div className="grab" />
      <div className="lhero">
        <div className="lhmeta">
          <span>GEVERIFIEERDE OUTLETDEAL</span>
          <span>{stockLabel}</span>
        </div>
        <div style={{ display: "flex", alignItems: "flex-start", gap: 10 }}>
          <h1 style={{ flex: 1, margin: 0 }}>{l.title}</h1>
          <SaveButton id={l.id} initialOn={savedOn} />
        </div>
        <div className="lchips">
          <span>−{disc}% t.o.v. nieuw</span>
          <span>Conditie {l.conditionScore}/10</span>
          <span>{l.pickupCity}</span>
        </div>
      </div>

      <div className="selrow premium">
        <span className="av">{sellerLogo
          ? /* eslint-disable-next-line @next/next/no-img-element */
            <img src={sellerLogo} alt="" style={{ width: "100%", height: "100%", objectFit: "cover", borderRadius: "inherit" }} />
          : sellerName.slice(0, 2).toUpperCase()}</span>
        <span>
          <b>{sellerName} ✓{rating ? <> · <Stars n={rating.avg} size={11} /> <small style={{ fontWeight: 600 }}>{rating.avg}</small></> : null}</b>
          <span>{sellerOrders > 0 ? `${sellerOrders} succesvolle orders` : "nieuwe partner"} · KvK-geverifieerd · escrow actief</span>
        </span>
        <Link href={`/store/${l.sellerSlug}`} className="go">STORE →</Link>
      </div>

      <div className="pricecard premium">
        <h4>✦ AI-PRIJSINSCHATTING · {l.comps > 0 ? `${l.comps} AI-PRIJSSIGNALEN` : "MODELKENNIS"} · CONFIDENCE {l.confidence}{l.aiSource === "heuristiek" ? " · HEURISTIEK" : ""}</h4>
        <div className="l1"><b>{eur(l.price)}{l.perUnit && "/st"}</b><s>nieuw {eur(l.newPrice)}</s><span className="d">−{disc}%</span></div>
        <EvidenceStrip l={l} labels={false} />
        <div className="lg"><span>SNEL {eur(l.fast)}</span><span>OUTLET-PRIJS</span><span>NIEUW {eur(l.newPrice)}</span></div>
        <p className="src">{l.condition || "Conditie niet opgegeven"} · {stockLabel}</p>
      </div>

      {aiInsight && <div className="listingAiBrainCard">
        <span className="aiBrainBadge">AI-DEALCHECK</span>
        <div className="listingAiTop"><b>{aiInsight.label}</b><em>{aiInsight.finalScore}/100</em></div>
        <p>Outrun beoordeelt of prijs, partnertrust en voorraad samen een sterke koop vormen. De score is advies, geen advertentiepositie.</p>
        <div className="listingAiMeters">
          <span><b>{aiInsight.dealScore}</b><small>Deal</small></span>
          <span><b>{aiInsight.priceScore}</b><small>Prijs</small></span>
          <span><b>{aiInsight.trustScore}</b><small>Trust</small></span>
          <span><b>{aiInsight.urgencyScore}</b><small>Urgentie</small></span>
        </div>
        <ul>
          <li>{aiInsight.priceText}</li>
          <li>{aiInsight.trustText}</li>
          <li>{aiInsight.urgencyText}</li>
          <li>{aiInsight.alternativesHint}</li>
          <li>Tip: open de foto volledig en vergelijk conditie/details vóór aankoop.</li>
        </ul>
      </div>}

      <div className="trustgrid">
        <span><b>Escrow</b><small>partner krijgt pas betaald na levering</small></span>
        <span><b>Geverifieerd</b><small>zakelijke partner met KvK-check</small></span>
        <span><b>Support</b><small>hulp bij vragen of problemen</small></span>
      </div>

      <div className="cta2 stickybuy">
        <Link href={`/checkout/${l.id}`} className="btn pri">Koop veilig — {eur(l.price)}</Link>
        <Link href={`/store/${l.sellerSlug}`} className="btn sec">Partner bekijken</Link>
      </div>
      <BidBox listingId={l.id} price={l.price} fast={l.fast} myBid={myBid ?? null} />
      <p className="note" style={{ margin: "12px 4px 0" }}>Testmodus: kopen maakt een testorder aan, er wordt niets afgeschreven. De checkout toont alvast de echte escrow-flow.</p>
    </div>
  );
}
