/**
 * AI Model Abstraction Layer (Masterplan V1.1 Amendment 3).
 * Provider = vervangbaar component. Routing per taaktype; nu: reasoning (pricing).
 * ENV: AI_PROVIDER=deepseek|heuristiek (default: deepseek als key aanwezig), DEEPSEEK_API_KEY.
 */
import { deepseekPricing } from "./deepseek";
import { heuristicPricing } from "./heuristic";

export type PricingInput = {
  title: string; brand?: string; category: string;
  condition: string; conditionScore: number;   // 1–10
  newPrice: number;                            // adviesprijs/nieuwprijs (anker)
  stock: number; photosCount: number; defect?: string;
  visionSummary?: string; conditionReason?: string; defects?: string[]; accessories?: string[]; energyLabel?: string;
};

export type PriceAdvice = {
  fast: number; outlet: number; premium: number;
  expectedDaysFast: number; expectedDaysOutlet: number; expectedDaysPremium: number;
  confidence: number;          // 0–100
  comps: number;               // 0 = geen echte marktscan gedaan
  reasoning: string;           // 1 zin NL, tonen aan seller
  source: "deepseek" | "heuristiek";
};

export async function getPriceAdvice(input: PricingInput): Promise<PriceAdvice> {
  const provider = process.env.AI_PROVIDER
    ?? (process.env.DEEPSEEK_API_KEY ? "deepseek" : "heuristiek");
  if (provider === "deepseek" && process.env.DEEPSEEK_API_KEY) {
    try { return await deepseekPricing(input); }
    catch (e) { console.error("[ai] deepseek faalde, val terug op heuristiek:", e); }
  }
  return heuristicPricing(input);
}
