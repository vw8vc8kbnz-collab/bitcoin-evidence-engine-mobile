# Outrun IQ v8.5.2 — Vision Confidence & Vehicle Recognition Guard

Flat-safe deploy build voor Outrun IQ. Gebouwd bovenop v8.5.1.

Belangrijk: vision vereist nog steeds `VISION_API_KEY` en `VISION_MODEL` met een echt multimodaal model. Zonder die configuratie blijft AI-fotoherkenning bewust uit.
