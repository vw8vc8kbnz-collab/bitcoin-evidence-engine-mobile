# Outrun IQ v8.5.2 — Vision Confidence & Vehicle Recognition Guard

## Hoofddoel
Deze versie verdiept de product-visionlaag na de Harley-test: Outrun mag niet meer te snel een specifiek motor-/voertuigmodel verzinnen, en moet bij duidelijke Harley-Davidson/cruiser-signalen betere merk/model-suggesties geven met confidence en extra-foto-vragen.

## Wijzigingen
- Visionprompt aangescherpt voor motoren/voertuigen: tankbadge, emblemen, V-twin, zijkoffers, floorboards, whitewalls en touring/cruiser-lijnen worden expliciet meegenomen.
- Hallucinatieguard toegevoegd voor klassieke cruiser-modellen zoals Yamaha XV 535 Virago wanneer er geen OCR/badge-bewijs is en de confidence te laag is.
- Harley-Davidson waarschijnlijke herkenning toegevoegd: bij Harley/touring/cruiser-signalen wordt Harley-Davidson als waarschijnlijke brand gebruikt en het model als bevestigingskandidaat getoond.
- Model wordt bij onzekerheid niet meer als harde waarheid behandeld; de UI toont nu AI-zekerheid en “bevestigen aanbevolen”.
- Modelkandidaten en extra-foto-verzoeken worden prominenter in de zakelijke productflow getoond.
- Max 5 foto’s per product blijft vast: hoofdbeeld, tweede hoek, detail/schade, accessoires/verpakking, label/artikelnummer.

## Test
- `npm install` uitgevoerd.
- `npx tsc --noEmit` OK.
