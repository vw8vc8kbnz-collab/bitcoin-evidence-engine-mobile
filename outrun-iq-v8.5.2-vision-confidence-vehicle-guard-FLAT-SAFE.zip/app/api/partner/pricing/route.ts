import { NextResponse, type NextRequest } from "next/server";
import { getUser, isApprovedPartner, rateLimit } from "@/lib/auth";
import { getPriceAdvice } from "@/lib/ai";
export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  const __u = await getUser();
  if (!isApprovedPartner(__u)) return NextResponse.json({ error: "Alleen voor goedgekeurde partners" }, { status: 403 });
  if (!rateLimit(`ai-pricing:${__u?.id ?? "anon"}`, 60, 60 * 60_000)) {
    return NextResponse.json({ error: "AI-limiet bereikt. Probeer het straks opnieuw." }, { status: 429 });
  }
  const b = await req.json().catch(() => null);
  if (!b?.title || !b?.newPrice || !b?.category) {
    return NextResponse.json({ error: "title, category en newPrice zijn verplicht" }, { status: 400 });
  }
  const advice = await getPriceAdvice({
    title: String(b.title), brand: b.brand ? String(b.brand) : undefined,
    category: String(b.category), condition: String(b.condition ?? ""),
    conditionScore: Number(b.conditionScore) || 7,
    newPrice: Number(b.newPrice), stock: Number(b.stock) || 1,
    photosCount: Number(b.photosCount) || 0,
    defect: b.defect ? String(b.defect) : undefined,
    visionSummary: b.visionSummary ? String(b.visionSummary).slice(0, 500) : undefined,
    conditionReason: b.conditionReason ? String(b.conditionReason).slice(0, 220) : undefined,
    defects: Array.isArray(b.defects) ? b.defects.map((x: unknown) => String(x).slice(0, 120)).slice(0, 5) : undefined,
    accessories: Array.isArray(b.accessories) ? b.accessories.map((x: unknown) => String(x).slice(0, 80)).slice(0, 5) : undefined,
    energyLabel: b.energyLabel ? String(b.energyLabel).slice(0, 30) : undefined,
  });
  return NextResponse.json(advice);
}
