# Stock Evidence Engine V1

Backtest-first research lab voor stock buy-signal hypotheses.

## Waarom deze V1?
Deze versie bouwt bewust nog geen blind live buy-bot. Eerst worden hypotheses meetbaar gemaakt: entry, exit, holdtijd, kosten/slippage, winrate, expectancy en drawdown.

## Start lokaal/VPS

```bash
cp .env.example .env
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
python -m stock_evidence_engine.cli backtest --tickers BB,PLTR,IONQ,SOUN,NVDA --period 2y
python -m stock_evidence_engine.cli dashboard --host 0.0.0.0 --port 8791
```

Dashboard: http://SERVER-IP:8791

## Belangrijk
Yahoo/yfinance is prima voor prototype research, maar niet point-in-time institutional data. Deze V1 logt resultaten eerlijk en is bedoeld om setups te falsifiëren.
