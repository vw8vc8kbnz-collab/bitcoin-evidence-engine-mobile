from __future__ import annotations

import json
import numpy as np
import pandas as pd
from stock_evidence_engine.engines.features import add_features
from stock_evidence_engine.engines.setups import detect_signals


def _simulate_trade(df: pd.DataFrame, signal_idx: int, hold_days: int, fee_bps: float, slippage_bps: float) -> dict | None:
    entry_idx = signal_idx + 1
    exit_idx = min(entry_idx + hold_days, len(df) - 1)
    if entry_idx >= len(df) or exit_idx <= entry_idx:
        return None
    entry = float(df.iloc[entry_idx].open) * (1 + slippage_bps / 10000)
    exitp = float(df.iloc[exit_idx].close) * (1 - slippage_bps / 10000)
    fee = 2 * fee_bps / 10000
    ret = (exitp / entry - 1 - fee) * 100
    window = df.iloc[entry_idx:exit_idx + 1]
    max_dd = (window.low.min() / entry - 1) * 100
    max_ru = (window.high.max() / entry - 1) * 100
    return {
        "entry_date": str(df.iloc[entry_idx].date),
        "exit_date": str(df.iloc[exit_idx].date),
        "entry_price": entry,
        "exit_price": exitp,
        "return_pct": ret,
        "max_drawdown_pct": max_dd,
        "max_runup_pct": max_ru,
        "hold_days": int(exit_idx - entry_idx),
    }


def run_backtest(price_data: dict[str, pd.DataFrame], hold_days_list: list[int] | None = None, fee_bps: float = 5, slippage_bps: float = 10) -> tuple[pd.DataFrame, pd.DataFrame]:
    hold_days_list = hold_days_list or [1, 3, 5, 10, 20]
    trades = []
    for ticker, raw in price_data.items():
        df = add_features(raw)
        if df.empty:
            continue
        signals = detect_signals(df)
        date_to_idx = {str(r.date): i for i, r in df.iterrows()}
        for sig in signals:
            idx = date_to_idx.get(str(sig["date"]))
            if idx is None:
                continue
            for hd in hold_days_list:
                tr = _simulate_trade(df, idx, hd, fee_bps, slippage_bps)
                if not tr:
                    continue
                trades.append({
                    "ticker": ticker,
                    "setup": f"{sig['setup']}_hold{hd}d",
                    **tr,
                    "evidence_json": json.dumps(sig["evidence"], sort_keys=True),
                })
    trade_df = pd.DataFrame(trades)
    if trade_df.empty:
        return trade_df, pd.DataFrame()
    rows = []
    for setup, g in trade_df.groupby("setup"):
        rows.append({
            "setup": setup,
            "trades": int(len(g)),
            "winrate": float((g.return_pct > 0).mean() * 100),
            "avg_return_pct": float(g.return_pct.mean()),
            "median_return_pct": float(g.return_pct.median()),
            "expectancy_pct": float(g.return_pct.mean()),
            "best_return_pct": float(g.return_pct.max()),
            "worst_return_pct": float(g.return_pct.min()),
            "avg_max_drawdown_pct": float(g.max_drawdown_pct.mean()),
        })
    summary = pd.DataFrame(rows).sort_values(["expectancy_pct", "trades"], ascending=[False, False])
    return trade_df, summary
