from __future__ import annotations

import numpy as np
import pandas as pd


def add_features(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df
    x = df.copy().sort_values("date").reset_index(drop=True)
    x["ret_1d"] = x["close"].pct_change()
    x["gap_pct"] = (x["open"] / x["close"].shift(1) - 1.0) * 100.0
    x["dollar_volume"] = x["close"] * x["volume"]
    x["avg_volume_20"] = x["volume"].rolling(20).mean()
    x["rel_volume"] = x["volume"] / x["avg_volume_20"]
    x["ma20"] = x["close"].rolling(20).mean()
    x["ma50"] = x["close"].rolling(50).mean()
    x["ma200"] = x["close"].rolling(200).mean()
    x["high_20"] = x["high"].rolling(20).max().shift(1)
    x["low_20"] = x["low"].rolling(20).min().shift(1)
    delta = x["close"].diff()
    gain = delta.clip(lower=0).rolling(14).mean()
    loss = (-delta.clip(upper=0)).rolling(14).mean()
    rs = gain / loss.replace(0, np.nan)
    x["rsi14"] = 100 - (100 / (1 + rs))
    tr = pd.concat([
        x["high"] - x["low"],
        (x["high"] - x["close"].shift(1)).abs(),
        (x["low"] - x["close"].shift(1)).abs(),
    ], axis=1).max(axis=1)
    x["atr14"] = tr.rolling(14).mean()
    return x
