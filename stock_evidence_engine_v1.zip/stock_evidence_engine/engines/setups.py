from __future__ import annotations

import pandas as pd


def detect_signals(df: pd.DataFrame) -> list[dict]:
    """Deterministic hypotheses. These are not assumed profitable; V1 tests them."""
    signals: list[dict] = []
    if df.empty:
        return signals
    for i, row in df.iterrows():
        if i < 220:
            continue
        evidence_base = {
            "close": float(row.close),
            "rel_volume": float(row.rel_volume) if pd.notna(row.rel_volume) else None,
            "rsi14": float(row.rsi14) if pd.notna(row.rsi14) else None,
            "gap_pct": float(row.gap_pct) if pd.notna(row.gap_pct) else None,
        }
        if row.close > row.high_20 and row.rel_volume >= 2.5 and row.close > row.ma50:
            signals.append({"date": row.date, "setup": "volume_breakout_20d", "score": 75, "evidence": evidence_base | {"rule": "close > prior 20d high + rel_volume >= 2.5 + close > MA50"}})
        prev = df.iloc[i-1]
        if prev.close < prev.ma200 and row.close > row.ma200 and row.rel_volume >= 1.5:
            signals.append({"date": row.date, "setup": "ma200_reclaim", "score": 70, "evidence": evidence_base | {"rule": "close reclaims MA200 with rel_volume >= 1.5"}})
        if prev.rsi14 < 30 and row.rsi14 > 35 and row.close > row.open and row.rel_volume >= 1.3:
            signals.append({"date": row.date, "setup": "oversold_recovery", "score": 65, "evidence": evidence_base | {"rule": "RSI recovers from oversold + green candle + rel_volume >= 1.3"}})
        if row.gap_pct >= 5 and row.close > row.open and row.rel_volume >= 2.0:
            signals.append({"date": row.date, "setup": "gap_strength", "score": 72, "evidence": evidence_base | {"rule": "gap >= 5% + closes green + rel_volume >= 2"}})
    return signals
