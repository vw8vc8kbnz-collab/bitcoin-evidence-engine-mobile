from __future__ import annotations

from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from stock_evidence_engine.storage.db import connect

app = FastAPI(title="Stock Evidence Engine")

HTML = """
<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>
<title>Stock Evidence Engine</title><style>
body{font-family:-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;background:#f6f7fb;color:#111;margin:0;padding:24px}.card{background:white;border-radius:22px;padding:18px;margin:12px 0;box-shadow:0 10px 35px rgba(0,0,0,.06)}table{width:100%;border-collapse:collapse}td,th{padding:9px;border-bottom:1px solid #eee;text-align:left}.pill{border-radius:99px;background:#111;color:white;padding:4px 9px;font-size:12px}</style></head>
<body><h1>Stock Evidence Engine</h1><div class='card'><b>Status:</b> Research Lab V1 — backtest-first, no blind live buys.</div>{content}</body></html>
"""

@app.get("/", response_class=HTMLResponse)
def home():
    con = connect()
    runs = con.execute("SELECT * FROM backtest_runs ORDER BY id DESC LIMIT 5").fetchall()
    content = "<div class='card'><h2>Laatste backtest runs</h2>"
    if not runs:
        content += "Nog geen runs. Start met: <code>python -m stock_evidence_engine.cli backtest --tickers BB,PLTR,IONQ,SOUN --period 2y</code>"
    else:
        content += "<table><tr><th>ID</th><th>Tijd</th><th>Universe</th><th>Period</th></tr>"
        for r in runs:
            content += f"<tr><td><a href='/run/{r['id']}'>#{r['id']}</a></td><td>{r['created_at']}</td><td>{r['universe']}</td><td>{r['period']}</td></tr>"
        content += "</table>"
    content += "</div>"
    return HTML.format(content=content)

@app.get("/run/{run_id}", response_class=HTMLResponse)
def run_detail(run_id: int):
    con = connect()
    rows = con.execute("SELECT * FROM setup_summary WHERE run_id=? ORDER BY expectancy_pct DESC", (run_id,)).fetchall()
    content = f"<div class='card'><h2>Run #{run_id}</h2>"
    if not rows:
        content += "Geen summary gevonden."
    else:
        content += "<table><tr><th>Setup</th><th>Trades</th><th>Winrate</th><th>Avg return</th><th>Worst</th><th>Avg DD</th></tr>"
        for r in rows:
            content += f"<tr><td>{r['setup']}</td><td>{r['trades']}</td><td>{r['winrate']:.1f}%</td><td>{r['avg_return_pct']:.2f}%</td><td>{r['worst_return_pct']:.2f}%</td><td>{r['avg_max_drawdown_pct']:.2f}%</td></tr>"
        content += "</table>"
    content += "</div>"
    return HTML.format(content=content)
