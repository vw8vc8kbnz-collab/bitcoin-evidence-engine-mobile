from __future__ import annotations

import argparse
import json
import uvicorn
from stock_evidence_engine import __version__
from stock_evidence_engine.config.settings import settings
from stock_evidence_engine.data.yahoo_client import fetch_batch, fetch_recent_news
from stock_evidence_engine.engines.backtester import run_backtest
from stock_evidence_engine.storage.db import connect, insert_run


def cmd_backtest(args):
    tickers = [t.strip().upper() for t in (args.tickers or ",".join(settings.tickers)).split(",") if t.strip()]
    print(f"Stock Evidence Engine v{__version__}")
    print(f"Fetching {len(tickers)} tickers from Yahoo/yfinance: {tickers}")
    data = fetch_batch(tickers, period=args.period, interval=args.interval)
    trade_df, summary = run_backtest(data, hold_days_list=[int(x) for x in args.holds.split(",")], fee_bps=args.fee_bps, slippage_bps=args.slippage_bps)
    con = connect()
    run_id = insert_run(con, tickers, args.period, {"interval": args.interval, "holds": args.holds, "fee_bps": args.fee_bps, "slippage_bps": args.slippage_bps})
    for _, r in trade_df.iterrows():
        con.execute("""INSERT INTO trades (run_id,ticker,setup,entry_date,exit_date,entry_price,exit_price,return_pct,max_drawdown_pct,max_runup_pct,hold_days,evidence_json)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""", (run_id, r.ticker, r.setup, r.entry_date, r.exit_date, r.entry_price, r.exit_price, r.return_pct, r.max_drawdown_pct, r.max_runup_pct, int(r.hold_days), r.evidence_json))
    for _, r in summary.iterrows():
        con.execute("""INSERT INTO setup_summary (run_id,setup,trades,winrate,avg_return_pct,median_return_pct,expectancy_pct,best_return_pct,worst_return_pct,avg_max_drawdown_pct)
        VALUES (?,?,?,?,?,?,?,?,?,?)""", (run_id, r.setup, int(r.trades), r.winrate, r.avg_return_pct, r.median_return_pct, r.expectancy_pct, r.best_return_pct, r.worst_return_pct, r.avg_max_drawdown_pct))
    con.commit()
    print(f"\nRun #{run_id} opgeslagen in {settings.db_file}")
    if summary.empty:
        print("Geen trades gevonden.")
    else:
        print(summary.head(20).to_string(index=False))


def cmd_news(args):
    for t in [x.strip().upper() for x in args.tickers.split(",") if x.strip()]:
        print(f"\n== {t} news ==")
        for n in fetch_recent_news(t)[:10]:
            print(json.dumps(n, ensure_ascii=False))


def cmd_dashboard(args):
    uvicorn.run("stock_evidence_engine.dashboard.app:app", host=args.host, port=args.port, reload=False)


def main():
    p = argparse.ArgumentParser(description="Stock Evidence Engine V1")
    sub = p.add_subparsers(required=True)
    b = sub.add_parser("backtest")
    b.add_argument("--tickers", default=",".join(settings.tickers))
    b.add_argument("--period", default="2y")
    b.add_argument("--interval", default="1d")
    b.add_argument("--holds", default="1,3,5,10,20")
    b.add_argument("--fee-bps", type=float, default=5)
    b.add_argument("--slippage-bps", type=float, default=10)
    b.set_defaults(func=cmd_backtest)
    n = sub.add_parser("news")
    n.add_argument("--tickers", default="BB,PLTR,IONQ,SOUN")
    n.set_defaults(func=cmd_news)
    d = sub.add_parser("dashboard")
    d.add_argument("--host", default="0.0.0.0")
    d.add_argument("--port", type=int, default=8791)
    d.set_defaults(func=cmd_dashboard)
    args = p.parse_args()
    args.func(args)

if __name__ == "__main__":
    main()
