from __future__ import annotations

import requests
from stock_evidence_engine.config.settings import settings


def send_ntfy(title: str, body: str, priority: str = "default", tags: str = "rocket") -> bool:
    if not settings.ntfy_topic:
        print("[NTFY disabled]", title, body[:160])
        return False
    url = f"{settings.ntfy_server.rstrip('/')}/{settings.ntfy_topic}"
    r = requests.post(url, data=body.encode("utf-8"), headers={"Title": title, "Priority": priority, "Tags": tags}, timeout=15)
    r.raise_for_status()
    return True
