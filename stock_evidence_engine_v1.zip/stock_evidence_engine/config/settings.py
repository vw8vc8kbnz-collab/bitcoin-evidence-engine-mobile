from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()


@dataclass(frozen=True)
class Settings:
    ntfy_topic: str = os.getenv("SEE_NTFY_TOPIC", "")
    ntfy_server: str = os.getenv("SEE_NTFY_SERVER", "https://ntfy.sh")
    alert_min_class: str = os.getenv("SEE_ALERT_MIN_CLASS", "ELITE")
    universe: str = os.getenv("SEE_UNIVERSE", "AAPL,MSFT,NVDA,BB,PLTR,IONQ,SOUN")
    db_path: str = os.getenv("SEE_DB_PATH", "./stock_evidence_engine/storage/see.db")

    @property
    def tickers(self) -> list[str]:
        return [t.strip().upper() for t in self.universe.split(",") if t.strip()]

    @property
    def db_file(self) -> Path:
        p = Path(self.db_path)
        p.parent.mkdir(parents=True, exist_ok=True)
        return p


settings = Settings()
