from __future__ import annotations

import time
import pandas as pd
import yfinance as yf


def fetch_history(ticker: str, period: str = "2y", interval: str = "1d") -> pd.DataFrame:
    """Fetch OHLCV from Yahoo via yfinance. Returns clean dataframe with columns open/high/low/close/volume."""
    raw = yf.download(ticker, period=period, interval=interval, auto_adjust=True, progress=False, threads=False)
    if raw is None or raw.empty:
        return pd.DataFrame()
    if isinstance(raw.columns, pd.MultiIndex):
        raw.columns = [c[0] for c in raw.columns]
    df = raw.rename(columns=str.lower).reset_index()
    date_col = "Date" if "Date" in df.columns else "Datetime"
    df = df.rename(columns={date_col: "date"})
    keep = [c for c in ["date", "open", "high", "low", "close", "volume"] if c in df.columns]
    df = df[keep].dropna()
    df["ticker"] = ticker.upper()
    return df


def fetch_batch(tickers: list[str], period: str = "2y", interval: str = "1d", sleep_s: float = 0.25) -> dict[str, pd.DataFrame]:
    out: dict[str, pd.DataFrame] = {}
    for t in tickers:
        try:
            out[t.upper()] = fetch_history(t, period=period, interval=interval)
        except Exception as exc:
            print(f"[WARN] {t}: {exc}")
            out[t.upper()] = pd.DataFrame()
        time.sleep(sleep_s)
    return out


def fetch_recent_news(ticker: str) -> list[dict]:
    """Best-effort current news from Yahoo. Historical news is not reliable; this is for live research later."""
    try:
        items = yf.Ticker(ticker).news or []
    except Exception:
        return []
    normalized = []
    for item in items:
        normalized.append({
            "ticker": ticker.upper(),
            "title": item.get("title") or "",
            "publisher": item.get("publisher") or "",
            "link": item.get("link") or "",
            "provider_publish_time": item.get("providerPublishTime"),
            "type": item.get("type") or "",
        })
    return normalized
