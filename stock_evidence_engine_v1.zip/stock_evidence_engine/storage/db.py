from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any
from stock_evidence_engine.config.settings import settings

SCHEMA = """
CREATE TABLE IF NOT EXISTS backtest_runs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  universe TEXT,
  period TEXT,
  params_json TEXT
);

CREATE TABLE IF NOT EXISTS trades (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  run_id INTEGER,
  ticker TEXT,
  setup TEXT,
  entry_date TEXT,
  exit_date TEXT,
  entry_price REAL,
  exit_price REAL,
  return_pct REAL,
  max_drawdown_pct REAL,
  max_runup_pct REAL,
  hold_days INTEGER,
  evidence_json TEXT
);

CREATE TABLE IF NOT EXISTS setup_summary (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  run_id INTEGER,
  setup TEXT,
  trades INTEGER,
  winrate REAL,
  avg_return_pct REAL,
  median_return_pct REAL,
  expectancy_pct REAL,
  best_return_pct REAL,
  worst_return_pct REAL,
  avg_max_drawdown_pct REAL
);

CREATE TABLE IF NOT EXISTS live_signals (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  ticker TEXT,
  signal_class TEXT,
  score REAL,
  title TEXT,
  body TEXT,
  evidence_json TEXT
);
"""


def connect(path: Path | None = None) -> sqlite3.Connection:
    db_path = path or settings.db_file
    db_path.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(db_path)
    con.row_factory = sqlite3.Row
    con.executescript(SCHEMA)
    con.commit()
    return con


def insert_run(con: sqlite3.Connection, universe: list[str], period: str, params: dict[str, Any]) -> int:
    cur = con.execute(
        "INSERT INTO backtest_runs (universe, period, params_json) VALUES (?, ?, ?)",
        (",".join(universe), period, json.dumps(params, sort_keys=True)),
    )
    con.commit()
    return int(cur.lastrowid)
