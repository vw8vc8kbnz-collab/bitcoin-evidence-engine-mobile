#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
. .venv/bin/activate
python -m stock_evidence_engine.cli backtest --tickers "${1:-BB,PLTR,IONQ,SOUN,NVDA,AMD,TSLA}" --period "${2:-2y}"
