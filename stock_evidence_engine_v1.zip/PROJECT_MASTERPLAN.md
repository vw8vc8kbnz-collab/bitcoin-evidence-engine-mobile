# Stock Evidence Engine — Technisch Masterplan

## Doel
Een evidence-based stock signal systeem bouwen dat uiteindelijk live buy-signals via ntfy verstuurt, maar alleen nadat setups historisch zijn gevalideerd.

## Belangrijkste ontwerpkeuze
Backtest-first. Niet eerst zes brains live bouwen en daarna hopen dat de signalen werken. Eerst hypotheses falsifiëren met entry, exit, holdtijd, fees en slippage.

## V1 in deze ZIP
- Yahoo/yfinance data loader
- Feature engineering: returns, gap, relative volume, MA20/50/200, RSI14, ATR14
- Eerste hypotheses:
  - volume_breakout_20d
  - ma200_reclaim
  - oversold_recovery
  - gap_strength
- Backtester met hold 1/3/5/10/20 dagen
- Kosten/slippage parameters
- SQLite opslag
- FastAPI dashboard
- ntfy-client placeholder voor later live signals

## Wat bewust nog niet in V1 zit
- Geen live buy-bot
- Geen blind AI-narrative score
- Geen ChatGPT API
- Geen Ollama/FinBERT integratie voordat bewezen is welke tekstsignalen waarde hebben
- Geen grote universe scanner voordat de hypotheses goed zijn

## V2 Research
- Meer tickers/universe
- Historical news/catalyst dataset ontwerpen
- Per setup out-of-sample splits
- Regime analyse
- Sector/thema momentum kwantificeren

## V3 Live Signal Engine
Pas na bewezen alpha:
- live market scanner
- live news reader
- local AI/FinBERT/Ollama voor news classification
- ntfy alerts alleen STRONG/ELITE

## Kritieke researchvragen
1. Is er na detectie nog alpha?
2. Welke holdtijd werkt?
3. Welke setups blijven overeind na kosten/slippage?
4. Werkt het alleen in bull regimes of ook breed?
5. Hoeveel signalen per week zijn realistisch?
