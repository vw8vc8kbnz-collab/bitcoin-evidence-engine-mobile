#!/usr/bin/env bash
set -euo pipefail
APP_DIR="${APP_DIR:-/home/ubuntu/stock_evidence_engine}"
PORT="${PORT:-8791}"

sudo apt-get update -y
sudo apt-get install -y python3 python3-venv python3-pip unzip curl
mkdir -p "$APP_DIR"
cp -R . "$APP_DIR/"
cd "$APP_DIR"
python3 -m venv .venv
. .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
if [ ! -f .env ]; then cp .env.example .env; fi

sudo tee /etc/systemd/system/stock-evidence-dashboard.service >/dev/null <<SERVICE
[Unit]
Description=Stock Evidence Engine Dashboard
After=network.target

[Service]
Type=simple
WorkingDirectory=$APP_DIR
Environment=PYTHONUNBUFFERED=1
ExecStart=$APP_DIR/.venv/bin/python -m stock_evidence_engine.cli dashboard --host 0.0.0.0 --port $PORT
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
SERVICE

sudo systemctl daemon-reload
sudo systemctl enable stock-evidence-dashboard.service
sudo systemctl restart stock-evidence-dashboard.service

echo "Installed Stock Evidence Engine at $APP_DIR"
echo "Dashboard: http://SERVER-IP:$PORT"
