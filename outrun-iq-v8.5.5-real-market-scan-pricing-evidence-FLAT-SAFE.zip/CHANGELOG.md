# Changelog

## v8.5.5 — Real Market Scan & Pricing Evidence
- Nieuwe marktprijslaag met interne marktankers en optionele `MARKET_SCAN_ENDPOINT` webhook voor externe/live prijsbronnen.
- Pricing gebruikt nu tweedehands marktwaarde als anker wanneer nieuwprijs ontbreekt of onrealistisch laag is.
- Harley/motor-flow gebruikt modelkandidaten en brede verkooprange in plaats van €899-achtige ankers.
- Prijsadvies toont nu AI prijsbewijs: marktrange, adviesprijs, confidence, basis en waarschuwing bij zwakke data.
- UI blijft simpel: één compacte prijsbewijskaart vóór strategiekeuze.
