# Outrun IQ v8.5.5

Real Market Scan & Pricing Evidence.

Deployment: flat Next.js app. Bewaar `.env`, `data`, `runtime_uploads` en uploads bij updates.

Optioneel voor echte externe marktscan:
- `MARKET_SCAN_ENDPOINT` = POST endpoint dat prijssignalen teruggeeft.
- `MARKET_SCAN_KEY` = bearer key.
Zonder endpoint gebruikt Outrun veilige interne marktankers + DeepSeek/modelkennis.
