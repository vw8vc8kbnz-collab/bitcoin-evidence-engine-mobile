const CACHE_NAME = 'bee-mobile-10_16_55_instant_startup_shell';
const APP_SHELL = [
  '/mobile',
  '/manifest.webmanifest?v=10_16_55_instant_startup_shell',
  '/static/css/mobile_app.css?v=10_16_55_instant_startup_shell',
  '/static/js/mobile_app.js?v=10_16_55_instant_startup_shell',
  '/static/icons/icon-180.png',
  '/static/icons/icon-192.png',
  '/static/icons/icon-512.png'
];

async function warmCache(){
  const cache = await caches.open(CACHE_NAME);
  await Promise.all(APP_SHELL.map(async (url)=>{
    try {
      const res = await fetch(url, {cache:'reload'});
      if(res && res.ok) await cache.put(url, res.clone());
    } catch(e) {}
  }));
}

self.addEventListener('install', event => {
  self.skipWaiting();
  event.waitUntil(warmCache());
});

self.addEventListener('activate', event => {
  event.waitUntil((async()=>{
    const keys = await caches.keys();
    await Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)));
    if(self.registration.navigationPreload){ try{ await self.registration.navigationPreload.enable(); }catch(e){} }
    await self.clients.claim();
  })());
});

function timeout(ms){ return new Promise((_,rej)=>setTimeout(()=>rej(new Error('sw-timeout')),ms)); }
async function networkUpdate(request, cacheKey){
  try{
    const fresh = await fetch(request, {cache:'reload'});
    if(fresh && fresh.ok){ const cache=await caches.open(CACHE_NAME); cache.put(cacheKey || request, fresh.clone()).catch(()=>{}); }
    return fresh;
  }catch(e){ return null; }
}

self.addEventListener('fetch', event => {
  const req = event.request;
  const url = new URL(req.url);
  if(req.method !== 'GET') return;
  if(url.pathname.startsWith('/api/')) return; // API must remain live.

  // CRITICAL: installed iPhone PWA must never wait 30-50s on network for the app shell.
  // Serve cached /mobile instantly and update in the background.
  if(req.mode === 'navigate' || url.pathname === '/mobile' || url.pathname === '/'){
    event.respondWith((async()=>{
      const cache = await caches.open(CACHE_NAME);
      const cached = await cache.match('/mobile') || await cache.match(req);
      const netPromise = (event.preloadResponse || networkUpdate(req, '/mobile')).catch(()=>null);
      if(cached){ event.waitUntil(netPromise); return cached; }
      try{
        const fresh = await Promise.race([netPromise, timeout(1800)]);
        if(fresh) return fresh;
      }catch(e){}
      return new Response('<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><style>html,body{margin:0;background:#061327;color:#eef5ff;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;height:100%;display:grid;place-items:center}.c{text-align:center;padding:26px}.l{width:58px;height:58px;border-radius:18px;background:#ffbe3d;color:#061327;display:grid;place-items:center;font-weight:950;font-size:34px;margin:0 auto 14px}.b{height:7px;background:rgba(255,255,255,.10);border-radius:99px;overflow:hidden;margin-top:18px}.b i{display:block;height:100%;width:50%;background:linear-gradient(90deg,#348bff,#1fd5ff,#48e6ad);border-radius:99px;animation:a 1s infinite alternate}@keyframes a{to{transform:translateX(100%)}}</style></head><body><div class="c"><div class="l">₿</div><h2>Bitcoin Evidence</h2><p>App-shell wordt geladen…</p><div class="b"><i></i></div></div><script>setTimeout(()=>location.reload(),1600)</script></body></html>', {headers:{'Content-Type':'text/html; charset=utf-8'}});
    })());
    return;
  }

  // Static assets: cache first, background refresh. This prevents white screens when network is slow.
  if(url.pathname.startsWith('/static/') || url.pathname.endsWith('.webmanifest') || url.pathname.endsWith('.js') || url.pathname.endsWith('.css')){
    event.respondWith((async()=>{
      const cache = await caches.open(CACHE_NAME);
      const cached = await cache.match(req) || await cache.match(url.pathname);
      const net = networkUpdate(req).catch(()=>null);
      if(cached){ event.waitUntil(net); return cached; }
      const fresh = await net;
      return fresh || new Response('', {status:504});
    })());
  }
});
