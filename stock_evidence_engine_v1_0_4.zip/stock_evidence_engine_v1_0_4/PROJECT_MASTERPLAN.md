# Stock Evidence Engine v1.0.4 Masterplan

This build keeps the proven v1.0.3 VPS deployment model fixed: one stdlib server, one service, one port 8798.

Focus of v1.0.4:
- Improve research quality before live signals.
- Penalize tiny sample setups so 1-3 trade false alpha does not rank as top evidence.
- Add drill-down pages for tickers and setups.
- Add CSV exports for audit and external review.

Next after v1.0.4:
- Narrative/catalyst research layer.
- BB-style catalyst case tagging.
- News ingestion after the backtest framework is reliable.
- NTFY only after validated setup rules exist.
