# Stock Evidence Engine v1.0.4

Clean VPS build based on the working v1.0.3 baseline.

New in v1.0.4:
- Stronger fake-alpha filtering and sample-size penalty.
- Ticker detail pages: `/ticker/BB`.
- Setup detail pages: `/setup/momentum_continuation`.
- CSV exports: `/exports/summary.csv` and `/exports/trades.csv`.
- Health/API: `/health` and `/api/results`.

Runtime stays simple: `server.py` on port 8798 via Python stdlib HTTP server. No uvicorn/FastAPI/module path issues.
