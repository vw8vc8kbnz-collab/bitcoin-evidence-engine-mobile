# AlgoRoute v1.8.6 Desktop Layout + Service Time Polish

```bash
cd /home/ubuntu

rm -rf algoroute_latest
rm -f algoroute_v1_8_8_ADAPTIVE_PREMIUM_MAP.zip

wget -O /home/ubuntu/algoroute_v1_8_8_ADAPTIVE_PREMIUM_MAP.zip \
"https://raw.githubusercontent.com/vw8vc8kbnz-collab/bitcoin-evidence-engine-mobile/main/algoroute_v1_8_8_ADAPTIVE_PREMIUM_MAP.zip"

mkdir -p /home/ubuntu/algoroute_latest
unzip -o /home/ubuntu/algoroute_v1_8_8_ADAPTIVE_PREMIUM_MAP.zip -d /home/ubuntu/algoroute_latest

cd /home/ubuntu/algoroute_latest/algoroute_v1_8_8_ADAPTIVE_PREMIUM_MAP

chmod +x scripts/install.sh scripts/setup_osrm_nl.sh
sudo ./scripts/install.sh

sudo docker compose down --remove-orphans || true
sudo docker rm -f algoroute-api algoroute-web algoroute-nginx 2>/dev/null || true
sudo docker compose up -d --build --force-recreate

curl http://localhost:8787/api/health
curl http://localhost:8787/api/routing/status
curl http://localhost:8787/api/optimizer/status
```


## v1.8.9 LAYOUT REFINEMENT
- Fixed map overlay collisions on Dashboard and Live Kaart.
- Reserved map control layers, legend spacing and route summary spacing.
- Routes overview spacing, metric wrapping and stop timeline polish.
- Laptop scale refinements for 1260-1500px screens.
