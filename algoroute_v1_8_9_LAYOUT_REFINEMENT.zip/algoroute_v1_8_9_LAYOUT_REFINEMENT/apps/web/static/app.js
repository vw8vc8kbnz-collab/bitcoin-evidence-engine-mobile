function bootIntro(){
  const overlay=document.getElementById('startupIntro');
  const video=document.getElementById('startupVideo');
  const app=document.getElementById('app');
  const skip=document.getElementById('skipIntro');
  if(!overlay||!app) return;
  let closed=false;
  function closeIntro(){
    if(closed) return; closed=true;
    app.classList.remove('introPending'); app.classList.add('introReady');
    overlay.classList.add('hidden');
    try{ if(video) video.pause(); }catch(e){}
    setTimeout(()=>{ try{overlay.remove()}catch(e){} },900);
  }
  if(skip) skip.addEventListener('click', closeIntro);
  if(video){
    video.muted=true; video.playsInline=true;
    const playPromise=video.play();
    if(playPromise && playPromise.catch){playPromise.catch(()=>setTimeout(closeIntro,1100));}
    video.addEventListener('ended', closeIntro);
    video.addEventListener('error', ()=>setTimeout(closeIntro,700));
  }
  setTimeout(closeIntro, 9500);
}

const API = location.origin;
const state = {
  page:'dashboard', planningStep:1, map:null, mapState:null, routingStatus:null, selectedRouteId:'all', expandedRouteId:null,
  fields:[], fieldCategories:[], detections:[], csvHeaders:[], csvRows:[], mapping:{}, templates:[], selectedTemplate:null,
  queue:null, optimizeResult:null, geocodeResult:null, optimizerStatus:null, error:null
};
const navGroups = [
  ['OPERATIONS',[['dashboard','Dashboard','⌂'],['planning','Planning','☷'],['routes','Routes','⌘'],['load','Load Optimization','▣'],['live','Live Kaart','◎']]],
  ['RESOURCES',[['vehicles','Wagenpark','▤'],['drivers','Chauffeurs','♙'],['orders','Orders','▦']]],
  ['MANAGEMENT',[['tracking','Klanttracking','⌾'],['reports','Rapportages','▥'],['settings','Instellingen','⚙']]]
];
function api(path, opts){return fetch(API+path, opts).then(async r=>{let j={};try{j=await r.json()}catch(e){}; if(!r.ok) throw {status:r.status,...j}; return j;});}
async function init(){
  try{state.mapState=await api('/api/map/state')}catch(e){}
  try{state.routingStatus=await api('/api/routing/status')}catch(e){}
  try{state.optimizerStatus=await api('/api/optimizer/status')}catch(e){}
  try{const f=await api('/api/import/fields'); state.fields=f.fields||[]; state.fieldCategories=f.categories||[]}catch(e){}
  try{state.templates=(await api('/api/import/templates')).templates||[]}catch(e){}
  try{state.queue=await api('/api/planning/queue')}catch(e){}
  try{state.vehicles=await api('/api/vehicles')}catch(e){state.vehicles=[]}
  try{state.drivers=await api('/api/drivers')}catch(e){state.drivers=[]}
  render();
}
function setPage(p){state.page=p; render();}
function setStep(n){state.planningStep=n; render();}
function escapeHtml(s){return String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));}
function shell(content){
  return `<div class="shell"><aside class="sidebar"><div class="brand brandOfficial"><img class="brandFullLogo" src="/assets/algoroute-logo-sidebar-white-lime.png" alt="AlgoRoute"/></div>${navGroups.map(([g,items])=>`<div class="sectionLabel">${g}</div>${items.map(([id,label,icon])=>`<div onclick="setPage('${id}')" class="navItem ${state.page===id?'active':''}"><span class="navIcon">${icon}</span><span>${label}</span></div>`).join('')}`).join('')}<div class="sideFooter"><div>◐ Donker sidebar</div><br><b>Stijn</b><div class="muted">Admin</div></div></aside><main class="main page-${state.page}"><div class="topbar"><div class="menuBtn">☰</div><div class="search">⌕ Zoek order, route, bus, mapping of klant...</div><div class="topRight"><span class="sync">● Live sync actief</span><span>🔔</span><span>?</span><span class="avatar">S</span></div></div>${content}</main></div>`;
}
function kpis(){
  const q=state.queue?.summary||{};
  const routes=(state.mapState?.routes||[]).length;
  return `<div class="kpis"><div class="card kpi"><div class="kpiIcon">⌘</div><div><small>Actieve routes</small><br><b>${routes}</b><br><small>${routes?'live beschikbaar':'vult na optimizer'}</small></div></div><div class="card kpi"><div class="kpiIcon">☷</div><div><small>Orders in queue</small><br><b>${q.count||0}</b><br><small>${q.ready||0} ready</small></div></div><div class="card kpi"><div class="kpiIcon">↗</div><div><small>OSRM routing</small><br><b>${state.routingStatus?.available?'online':'—'}</b><br><small>${state.routingStatus?.available?'echte routes':'setup nodig'}</small></div></div><div class="card kpi"><div class="kpiIcon">▧</div><div><small>Load utilization</small><br><b>—</b><br><small>na load optimization</small></div></div></div>`;
}
function dashboard(){return shell(`<h1 class="pageTitle">Dashboard</h1><p class="subtitle">Operationele cockpit. Widgets vullen automatisch vanuit import, voertuigen, OSRM en optimizer.</p>${kpis()}<section class="layout dashboardLayout"><div>${mapCard('Dashboard preview met echte kaartdata')}<div class="bottom"><div class="card panel"><h3>Routes vandaag</h3><div class="row"><span class="muted">${(state.mapState?.routes||[]).length||'Nog geen routes gegenereerd'}</span><span class="badge">routes</span></div></div><div class="card panel"><h3>Planning queue</h3><div class="row"><span class="muted">${state.queue?.summary?.count||0} orders</span><span class="badge green">ready</span></div></div><div class="card panel"><h3>Fleet status</h3><div class="row"><span class="muted">${(state.vehicles||[]).length} voertuigen</span><span class="badge">fleet</span></div></div></div></div><div>${osrmPanel()}${rightInfo()}</div></section>`)}
function routeFocusControls(){const routes=state.mapState?.routes||[]; if(!routes.length) return ''; const active=state.selectedRouteId||'all'; return `<div class="routeFocusPanel"><div class="routeFocusTitle">Route focus</div><button onclick="selectRoute('all')" class="routeChip ${active==='all'?'active':''}">Alle routes</button>${routes.map((r,i)=>`<button onclick="selectRoute('${escapeHtml(r.id||('route_'+(i+1)))}')" class="routeChip ${active===(r.id||('route_'+(i+1)))?'active':''}">${escapeHtml(r.name||('Route '+(i+1)))} · ${escapeHtml(r.vehicle_name||'voertuig')}</button>`).join('')}</div>`}

function serviceMinutes(r){return (r?.stops||[]).reduce((a,s)=>a+Number(s.service_time_minutes||15),0)}
function fmtMin(min){min=Math.round(Number(min||0)); const h=Math.floor(min/60), m=min%60; return h?`${h}u ${m}m`:`${m}m`;}
function routeTimeParts(r){const drive=Math.round((r?.duration_s||0)/60); const service=serviceMinutes(r); return {drive,service,total:drive+service};}
function mapRouteOverlay(){
  const routes=state.mapState?.routes||[]; if(!routes.length) return '';
  const selected=state.selectedRouteId||'all';
  const active=selected==='all' ? routes[0] : routes.find((r,i)=>(r.id||('route_'+(i+1)))===selected) || routes[0];
  const rid=active?.id||'route_1';
  const stops=(active?.stops||[]).length;
  const km=Math.round((active?.distance_m||0)/1000);
  const tp=routeTimeParts(active);
  const load=active?.load||{};
  const routeCards=routes.slice(0,4).map((r,i)=>{
    const id=r.id||('route_'+(i+1)); const on=selected===id || (selected==='all'&&i===0);
    const rkm=Math.round((r.distance_m||0)/1000); const s=(r.stops||[]).length;
    return `<button onclick="selectRoute('${escapeHtml(id)}')" class="miniRouteCard ${on?'active':''}"><span><b>${escapeHtml(r.name||('Route '+(i+1)))}</b><small>${escapeHtml(r.vehicle_name||'Voertuig')}</small></span><em>${s} stops · ${rkm} km</em></button>`;
  }).join('');
  return `<div class="premiumRouteOverlay"><div class="miniRouteList"><div class="miniRouteHeader">Routes <span>${routes.length}</span></div>${routeCards}</div><div class="routeSummaryCard"><div><span class="routeDotBlue"></span><b>${escapeHtml(active?.name||rid)}</b><small>${escapeHtml(active?.vehicle_name||'Voertuig')}</small></div><div class="routeStats"><span>⌘ <b>${stops}</b><small>Stops</small></span><span>↗ <b>${km}</b><small>km</small></span><span>◷ <b>${fmtMin(tp.drive)}</b><small>Rijtijd</small></span><span>⏱ <b>${fmtMin(tp.service)}</b><small>Service</small></span><span>Σ <b>${fmtMin(tp.total)}</b><small>Totaal</small></span><span>▣ <b>${load.europallets||0}</b><small>Pallets</small></span><span>▥ <b>${load.roll_containers||0}</b><small>Rols</small></span><span>⚖ <b>${Math.round(load.weight_kg||0)}</b><small>kg</small></span></div></div></div>`;
}
function mapCard(sub='Echte Nederland-kaart', full=false){return `<div class="card mapCard ${full?'mapCanvasFull':''}"><div class="mapHeader"><button class="pill">Traffic</button><button class="pill active">Routes</button><button class="pill">Stops</button></div>${routeFocusControls()}${mapRouteOverlay()}<div id="map" class="map"></div>${full?`<div class="roadLegend"><b>Route status</b><span class="legendLine"><i class="normal"></i>Premium blauw</span><span class="legendLine"><i class="delay"></i>Vertraging</span><span class="legendLine"><i class="jam"></i>File</span><span class="legendLine"><i class="ev"></i>EV route</span></div>`:''}${(!state.mapState || ((state.mapState.routes||[]).length===0 && (state.mapState.vehicles||[]).length===0))?`<div class="emptyMap"><b>Kaart is klaar voor echte data</b><br><span class="muted">Routes verschijnen na echte orders + optimalisatie.</span></div>`:''}</div>`}
function selectRoute(id){state.selectedRouteId=id||'all'; render();}
function osrmPanel(){const s=state.routingStatus||{};return `<div class="card panel" style="margin-bottom:18px"><h3>OSRM status</h3><div class="row"><span><i class="statusDot ${s.available?'ok':'bad'}"></i> Routing engine</span><span class="badge ${s.available?'green':'orange'}">${s.available?'online':'niet actief'}</span></div><p class="muted">${escapeHtml(s.message||'OSRM status wordt geladen.')}</p><button class="btn accent" onclick="setPage('settings')">OSRM setup bekijken</button></div>`}
function rightInfo(){return `<div class="card panel"><h3>Product flow</h3><div class="row"><b>1. Import</b><span class="badge green">CSV/ERP</span></div><div class="row"><b>2. Mapping</b><span class="badge green">smart</span></div><div class="row"><b>3. Queue</b><span class="badge">ready</span></div><div class="row"><b>4. Optimize</b><span class="badge orange">OSRM</span></div><div class="row"><b>5. Publish</b><span class="badge">later</span></div></div>`}
function initMap(){
  if(!window.maplibregl) return; const el=document.getElementById('map'); if(!el) return; el.innerHTML='';
  const style={version:8,sources:{carto:{type:'raster',tiles:['https://a.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}@2x.png','https://b.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}@2x.png','https://c.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}@2x.png','https://d.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}@2x.png'],tileSize:256,attribution:'© OpenStreetMap © CARTO'}},layers:[{id:'carto',type:'raster',source:'carto',paint:{'raster-opacity':.98,'raster-saturation':-.10,'raster-contrast':.18,'raster-brightness-min':.00,'raster-brightness-max':.88}}]};
  const map=new maplibregl.Map({container:el,style,center:[5.2913,52.1326],zoom: state.page==='live'?7.75:7.18,pixelRatio:Math.min(window.devicePixelRatio||1,2),attributionControl:true,preserveDrawingBuffer:false});
  state.map=map;
  map.addControl(new maplibregl.NavigationControl({showCompass:false}),'bottom-right');
  map.on('load',()=>{drawData(map); setTimeout(()=>map.resize(),60); setTimeout(()=>map.resize(),260);});
  setTimeout(()=>map.resize(),120);
  setTimeout(()=>map.resize(),520);
}
function drawData(map){
  const ms=state.mapState||{routes:[],vehicles:[]};
  const selected=state.selectedRouteId||'all';
  const routes=(ms.routes||[]).filter((r,i)=>selected==='all' || selected===(r.id||('route_'+(i+1))));
  const bounds=new maplibregl.LngLatBounds(); let hasBounds=false;
  routes.forEach((r,i)=>{
    const coords=r.geometry||r.coordinates||[]; if(!coords.length) return;
    const rid=r.id||('route_'+(i+1));
    const routeColor='#147CFF';
    coords.forEach(c=>{if(Array.isArray(c)&&c.length>=2){bounds.extend(c);hasBounds=true;}});
    map.addSource('route-'+i,{type:'geojson',data:{type:'Feature',properties:{id:rid,name:r.name||rid,vehicle:r.vehicle_name||''},geometry:{type:'LineString',coordinates:coords}}});
    map.addLayer({id:'route-shadow-'+i,type:'line',source:'route-'+i,layout:{'line-cap':'round','line-join':'round'},paint:{'line-color':'#061A3D','line-width':selected==='all'?13:18,'line-opacity':selected==='all'?.18:.26,'line-blur':6}});
    map.addLayer({id:'route-glow-'+i,type:'line',source:'route-'+i,layout:{'line-cap':'round','line-join':'round'},paint:{'line-color':'#2294FF','line-width':selected==='all'?9:13,'line-opacity':selected==='all'?.34:.50,'line-blur':4}});
    map.addLayer({id:'route-casing-'+i,type:'line',source:'route-'+i,layout:{'line-cap':'round','line-join':'round'},paint:{'line-color':'#EAF4FF','line-width':selected==='all'?6.2:8.8,'line-opacity':.98}});
    map.addLayer({id:'route-'+i,type:'line',source:'route-'+i,layout:{'line-cap':'round','line-join':'round'},paint:{'line-color':routeColor,'line-width':selected==='all'?4.2:6.2,'line-opacity':.98}});
    map.addLayer({id:'route-shine-'+i,type:'line',source:'route-'+i,layout:{'line-cap':'round','line-join':'round'},paint:{'line-color':'#7DD3FC','line-width':selected==='all'?1.4:2.0,'line-opacity':selected==='all'?.72:.88}});
    addRouteStartMarker(map, r, coords, rid);
    addStopMarkers(map, r, selected==='all');
    map.on('click','route-'+i,()=>selectRoute(rid));
    map.on('mouseenter','route-'+i,()=>{map.getCanvas().style.cursor='pointer'});
    map.on('mouseleave','route-'+i,()=>{map.getCanvas().style.cursor=''});
  });
  if(hasBounds){try{map.fitBounds(bounds,{padding:selected==='all'?70:90,maxZoom:selected==='all'?8.55:10.8,duration:550});}catch(e){}}
  (ms.vehicles||[]).forEach(v=>{if(!v.longitude||!v.latitude)return; const el=document.createElement('div');el.className='vehicleMarker';el.textContent='🚚';new maplibregl.Marker({element:el}).setLngLat([v.longitude,v.latitude]).addTo(map);});
}

function addRouteStartMarker(map,r,coords,rid){
  const start=coords[0]; if(!Array.isArray(start)||start.length<2) return;
  const el=document.createElement('div'); el.className='routeStartMarker';
  el.innerHTML=`<div class="startBus">🚐</div><div class="startLabel"><b>Start</b><span>${escapeHtml(r.vehicle_name||r.name||rid)}</span></div>`;
  new maplibregl.Marker({element:el,anchor:'bottom'}).setLngLat(start).addTo(map);
}
function addStopMarkers(map,r,compact=false){
  const stops=(r.stops||[]).filter(s=>s.longitude!==undefined&&s.latitude!==undefined).slice(0,40);
  stops.forEach((s,idx)=>{ if(!s.longitude||!s.latitude) return; const el=document.createElement('div'); el.className=compact?'stopMarker compact':'stopMarker'; el.textContent=String(s.sequence||idx+1); new maplibregl.Marker({element:el}).setLngLat([Number(s.longitude),Number(s.latitude)]).addTo(map); });
}

function live(){return shell(`<section class="liveMapPage"><h1 class="pageTitle">Live Kaart</h1><p class="subtitle">Full-canvas execution map met OSRM-routes, traffic-segmenten, voertuigen en laadstatus.</p><div class="liveMapShell">${mapCard('Echte Nederland-kaart', true)}</div></section>`)}
function planning(){return shell(`<h1 class="pageTitle">Planning Queue</h1><p class="subtitle">Controleer leverdatum, tijdvensters, service/kostijd en capaciteit voordat AlgoRoute de optimizer start.</p><div class="tabs">${[1,2,3,4,5].map((n,i)=>`<button onclick="setStep(${n})" class="tab ${state.planningStep===n?'active':''}">${n} ${['Import','Mapping','Queue','Optimize','Publish'][i]}</button>`).join('')}</div>${planningStep()}`)}
function planningStep(){
  if(state.planningStep===1) return importStep();
  if(state.planningStep===2) return mappingStep();
  if(state.planningStep===3) return queueStep();
  if(state.planningStep===4) return optimizeStep();
  return publishStep();
}
function importStep(){return `<div class="workflowCard card"><h2>1. Import</h2><p class="muted">Upload CSV. Mapping gebeurt bewust pas in stap 2.</p><div class="uploadBox"><input id="csvFile" class="input" type="file" accept=".csv,.txt" onchange="handleCsvUpload(event)"><div class="muted">CSV wordt lokaal geparsed en daarna naar Smart Mapping gestuurd.</div></div><div class="moduleGrid"><div class="card panel"><h3>Recent bestand</h3>${state.csvHeaders.length?`<div class="notice greenNotice"><b>${state.csvRows.length}</b> regels gelezen · <b>${state.csvHeaders.length}</b> kolommen gevonden</div><button class="btn accent" onclick="setStep(2)">Door naar Mapping →</button>`:`<p class="muted">Nog geen bestand geüpload.</p>`}</div><div class="card panel"><h3>Integraties later</h3><p class="muted">Odoo, Exact, AFAS, WooCommerce, SFTP en Custom API komen via dezelfde normalisatielaag binnen.</p></div></div></div>`;}
function mappingStep(){return `<div class="workflowCard card"><h2>2. Mapping</h2><p class="muted">Mega slimme CSV-detectie: fuzzy matching, synoniemen, spelfouten, NL/EN en waardeherkenning.</p>${state.csvHeaders.length?mappingContent():`<div class="notice">Upload eerst een CSV in stap 1 Import.</div>`}</div>`;}
function requiredFields(){return (state.fields||[]).filter(f=>f.required).map(f=>f.id)}
function mappingStats(){const vals=Object.values(state.mapping).filter(Boolean); const req=requiredFields(); const missing=req.filter(f=>!vals.includes(f)); const unmapped=(state.csvHeaders||[]).filter(h=>!state.mapping[h]); return {mapped:vals.length, total:(state.csvHeaders||[]).length, missing, unmapped};}
function mappingStep(){const stats=mappingStats(); return `<div class="workflowCard card"><div class="sectionHero"><div><h2>2. Mapping Studio</h2><p class="muted">Koppel CSV-kolommen visueel aan AlgoRoute velden. Alles wat rood/oranje is vraagt aandacht.</p></div>${state.csvHeaders.length?`<div class="mappingScore ${stats.missing.length?'warn':'ok'}"><b>${stats.total-stats.unmapped.length}/${stats.total}</b><span>kolommen gekoppeld</span></div>`:''}</div>${state.csvHeaders.length?mappingContent():`<div class="notice">Upload eerst een CSV in stap 1 Import.</div>`}</div>`;}
function mappingContent(){
  const stats=mappingStats();
  return `<div class="mappingStudio"><div class="mappingActionBar"><button class="btn accent" onclick="runSmartDetect()">Smart detect opnieuw</button><button class="btn" onclick="commitImport()">Importeer naar Queue</button><input id="templateName" class="input templateInput" placeholder="Template naam opslaan"><span class="badge ${stats.missing.length?'orange':'green'}">${stats.missing.length?stats.missing.length+' verplichte velden missen':'mapping compleet'}</span><span class="badge ${stats.unmapped.length?'orange':'green'}">${stats.unmapped.length} ongemapt</span></div>${stats.missing.length?`<div class="missingStrip"><b>Actie nodig:</b>${stats.missing.map(f=>`<button onclick="highlightField('${f}')">${escapeHtml(labelForField(f))}</button>`).join('')}</div>`:`<div class="missingStrip ok"><b>Goed:</b><span>Alle verplichte velden zijn gekoppeld. Je kunt importeren.</span></div>`}<div class="mappingCanvas"><div class="mappingColumns">${state.csvHeaders.map(h=>mappingCard(h)).join('')}</div><div class="card panel fieldPicker premiumPicker"><h3>Veldbibliotheek</h3><p class="muted">Zoek en selecteer handmatig het juiste doelveld wanneer Smart Detect twijfelt.</p><input id="fieldSearch" class="input" placeholder="Zoek veld: postcode, pallets, leverdatum..." oninput="renderFieldCatalog(this.value)"><div id="fieldCatalog" class="fieldCatalog">${fieldCatalogHtml('')}</div></div></div></div>`;
}
function mappingCard(h){const det=(state.detections||[]).find(d=>d.column===h); const best=det?.best; const current=state.mapping[h] || (best&&best.score>=82?best.field_id:''); if(current && !state.mapping[h]) state.mapping[h]=current; const samples=(det?.samples||[]).slice(0,3); const confidence=best?.score||0; const status=current?'mapped':(best?'review':'missing'); return `<div class="mappingCard ${status} ${confidence&&confidence<75?'lowConf':''}" data-field="${escapeHtml(current||'')}"><div class="mapCardTop"><div><b>${escapeHtml(h)}</b><small>${current?escapeHtml(labelForField(current)):'Geen veld gekoppeld'}</small></div><span class="mapStatus ${status}">${current?'gekoppeld':best?'check':'geen match'}</span></div><div class="sampleLine">${samples.length?samples.map(x=>`<em>${escapeHtml(x)}</em>`).join(''):'<em>Geen voorbeeldwaarden</em>'}</div><div class="mapSelectRow"><select onchange="state.mapping['${escapeHtml(h)}']=this.value; render()"><option value="">— Kies veld —</option>${state.fields.map(f=>`<option value="${f.id}" ${current===f.id?'selected':''}>${f.label} · ${f.category}</option>`).join('')}</select><div class="confidenceRing ${confidence<75?'warn':''}">${confidence?confidence+'%':'—'}</div></div>${!current?`<div class="mapHint">Geen match? Kies rechts of in deze dropdown het juiste veld.</div>`:''}</div>`;}
function highlightField(fid){const el=[...document.querySelectorAll('.mappingCard')].find(x=>x.dataset.field===fid); if(el){el.scrollIntoView({behavior:'smooth',block:'center'}); el.classList.add('pulse'); setTimeout(()=>el.classList.remove('pulse'),1500)}}
function fieldCatalogHtml(query){const q=(query||'').toLowerCase(); const fields=state.fields.filter(f=>!q || (f.label+' '+f.id+' '+f.category+' '+(f.aliases||[]).join(' ')).toLowerCase().includes(q)); const grouped={}; fields.forEach(f=>{(grouped[f.category]||(grouped[f.category]=[])).push(f)}); return Object.entries(grouped).map(([cat,fs])=>`<div class="fieldCat"><h4>${cat}</h4>${fs.map(f=>`<button class="fieldItem" onclick="copyFieldHint('${f.id}')"><b>${f.label}</b><span class="badge">${f.type||'text'}</span><small>${f.required?'verplicht':'optioneel'}</small></button>`).join('')}</div>`).join('');}
function copyFieldHint(fid){alert('Kies dit veld in de dropdown bij de juiste CSV-kolom: '+labelForField(fid));}
function renderFieldCatalog(q){const el=document.getElementById('fieldCatalog'); if(el) el.innerHTML=fieldCatalogHtml(q);}
function labelForField(id){const f=state.fields.find(x=>x.id===id); return f?f.label:id;}
function queueStep(){
  const orders=state.queue?.orders||[]; const geo=state.geocodeResult; const geocoded=orders.filter(o=>o.latitude&&o.longitude).length;
  return `<div class="workflowCard card"><h2>3. Queue</h2><p class="muted">Controleer adressen, status en service/lostijd per order voordat je optimaliseert.</p><div class="mappingToolbar"><button class="btn accent" onclick="geocodeQueue()">Adressen valideren via PDOK/BAG</button><button class="btn" onclick="setStep(4)">Door naar Optimize →</button><button class="btn dangerSoft" onclick="clearQueue()">Queue leegmaken</button><span class="badge ${geocoded?'green':'orange'}">${geocoded}/${orders.length||0} met GPS</span></div>${geo?`<div class="notice ${geo.unresolved?'':'greenNotice'}"><b>PDOK resultaat</b><br>${geo.updated} adressen gekoppeld · ${geo.unresolved} onopgelost · ${geo.total_checked} gecontroleerd</div>`:''}${orders.length?`<div class="queueCards">${orders.map(o=>`<div class="queueCard"><div><b>${escapeHtml(o.order_number)}</b><span>${escapeHtml(o.customer_name)}</span></div><div class="queueAddress">${escapeHtml((o.delivery_address||'')+' '+(o.postal_code||'')+' '+(o.city||''))}</div><div class="chips"><span class="badge ${o.latitude&&o.longitude?'green':'orange'}">${o.latitude&&o.longitude?'PDOK':'GPS nodig'}</span><span class="badge ${o.status==='ready'?'green':'orange'}">${escapeHtml(o.status||'—')}</span><span class="badge serviceBadge">${o.service_time_minutes||15} min service</span><span class="badge">${o.europallets||0} EP</span><span class="badge">${o.roll_containers||0} RC</span></div></div>`).join('')}</div>`:`<div class="notice">Planning Queue is leeg. Importeer orders of koppel een ERP.</div>`}</div>`;}
function optimizeStep(){const core=state.optimizerStatus; const res=state.optimizeResult; return `<div class="workflowCard card"><h2>4. Optimize</h2><p class="muted">C++ Optimizer Core: routeoptimalisatie + load-capaciteit voor kg, m³, pallets en rolcontainers. Geen 3D loading in deze fase.</p><div class="notice ${core?.available?'greenNotice':''}"><b>Optimizer core</b><br>${core?`${core.core_mode} · ${core.available?'binary beschikbaar':'binary ontbreekt'} · ${core.scope}`:'status laden...'}</div>${osrmPanel()}<div class="serviceConfig card"><div><b>Service time schaalbaar</b><span>Per order via CSV-mapping of Order-detail. Fallback voor orders zonder waarde: 15 minuten.</span></div><div class="servicePills"><span>CSV: service_time_minutes</span><span>Queue zichtbaar</span><span>Route totaal = rijtijd + service</span></div></div><button class="btn accent" onclick="runOptimize()">Optimaliseer routes met C++ core</button>${res?optimizeResultPanel(res):''}</div>`;}
function optimizeResultPanel(res){if(!res.ok)return `<div class="resultPanel warn"><b>Optimalisatie niet gestart</b><span>${escapeHtml(res.reason||'Controleer queue en wagenpark.')}</span></div>`; return `<div class="resultPanel ok"><div><b>${res.routes_created||0} routes gemaakt</b><span>${res.unplanned_orders||0} orders niet gepland</span></div><div class="resultStats"><span>C++ core</span><span>${escapeHtml(res.core_version||'v1')}</span><button class="btn" onclick="setPage('routes')">Bekijk routes</button><button class="btn" onclick="setPage('live')">Open live kaart</button></div></div>`;}
function publishStep(){return `<div class="workflowCard card"><h2>5. Publish</h2><p class="muted">Routes publiceren naar chauffeur-app, klanttracking en live kaart.</p><div class="notice">Publish wordt actief zodra routes gegenereerd zijn.</div></div>`;}
function routeQuality(r){const stops=(r.stops||[]).length; const km=Math.round((r.distance_m||0)/1000); const tp=routeTimeParts(r); const load=r.load||{}; return {stops,km,drive:tp.drive,service:tp.service,total:tp.total,load};}
function routes(){const list=state.mapState?.routes||[]; return shell(`<h1 class="pageTitle">Routes</h1><p class="subtitle">Premium overzicht van routes, rijtijd, service time, totaalduur, stops en belading.</p>${list.length?`<div class="routeOverview">${list.map((r,i)=>routePanel(r,i)).join('')}</div>`:`<div class="workflowCard card"><h2>Nog geen routes</h2><p class="muted">Optimaliseer eerst de Planning Queue.</p><button class="btn accent" onclick="setPage('planning');state.planningStep=4;render()">Naar optimaliseren</button></div>`}`)}
function routePanel(r,i){const q=routeQuality(r); const id=r.id||('route_'+(i+1)); const open=state.expandedRouteId===id; return `<div class="card routePanel"><div class="routePanelHead"><div><span class="routeDotBlue"></span><b>${escapeHtml(r.name||('Route '+(i+1)))}</b><small>${escapeHtml(r.vehicle_name||'Voertuig')}</small></div><div class="routePanelStats"><span><b>${q.stops}</b><small>Stops</small></span><span><b>${q.km}</b><small>km</small></span><span><b>${fmtMin(q.drive)}</b><small>Rijtijd</small></span><span><b>${fmtMin(q.service)}</b><small>Service</small></span><span><b>${fmtMin(q.total)}</b><small>Totaal</small></span><span><b>${q.load.europallets||0}</b><small>Pallets</small></span><span><b>${q.load.roll_containers||0}</b><small>Rols</small></span><span><b>${Math.round(q.load.weight_kg||0)}</b><small>kg</small></span></div><button class="btn" onclick="toggleRoute('${escapeHtml(id)}')">${open?'Inklappen':'Stops bekijken'}</button></div>${open?`<div class="stopTimeline">${(r.stops||[]).map((s,j)=>stopRow(s,j)).join('')}</div>`:''}</div>`;}
function stopRow(s,j){return `<div class="stopRow"><div class="stopSeq">${j+1}</div><div><b>${escapeHtml(s.order_number||s.id||'Stop')}</b><span>${escapeHtml(s.customer_name||'')}</span></div><div class="muted">${escapeHtml((s.delivery_address||'')+' '+(s.postal_code||'')+' '+(s.city||''))}</div><div class="chips"><span class="badge">${s.service_time_minutes||15} min</span><span class="badge">${s.europallets||0} EP</span><span class="badge">${s.roll_containers||0} RC</span><span class="badge">${Math.round(s.weight_kg||0)} kg</span></div></div>`;}
function toggleRoute(id){state.expandedRouteId=state.expandedRouteId===id?null:id; render();}
function simple(title,txt){return shell(`<h1 class="pageTitle">${title}</h1><p class="subtitle">${txt}</p><div class="workflowCard card"><h2>Module foundation</h2><p class="muted">Deze pagina is klaar voor echte data en forms. Geen dummydata.</p></div>`)}

function vehicles(){
  const list=state.vehicles||[];
  const available=list.filter(v=>['available','beschikbaar','active','actief'].includes(String(v.status||'available'))).length;
  const ev=list.filter(v=>String(v.fuel_type||'').toLowerCase()==='electric').length;
  return shell(`<h1 class="pageTitle">Wagenpark</h1><p class="subtitle">Voertuigen, capaciteit, onderhoud, RDW-kentekenlookup en EV-profielen. EV-laadstops zijn roadmap; nu tonen we bereik en marge.</p><div class="setupActions"><button class="btn accent" onclick="seedFleet()">Test-vloot laden</button><button class="btn" onclick="refreshFleet()">Vernieuwen</button><span class="badge green">${available} beschikbaar</span><span class="badge ${ev?'green':''}">${ev} elektrisch</span></div><div class="fleetGrid premiumFleet"><div class="workflowCard card"><h2>Voertuig toevoegen</h2><form class="entityForm vehicleForm" onsubmit="saveVehicle(event)"><input name="name" placeholder="Naam voertuig, bijv. Bus 01" required><div class="plateLookup"><div class="nlPlate"><span>NL</span><input name="license_plate" id="licensePlateInput" placeholder="V-123-AB" oninput="formatPlateInput(this)" required></div><button type="button" class="btn" onclick="lookupRdw()">RDW lookup</button></div><div id="rdwPreview" class="rdwPreview">Kenteken invullen voor RDW merk/model voorstel.</div><div class="two"><input name="brand" id="vehicleBrand" placeholder="Merk"><input name="model" id="vehicleModel" placeholder="Model"></div><div class="two"><select name="status"><option value="available">Beschikbaar</option><option value="maintenance">Onderhoud</option><option value="unavailable">Niet beschikbaar</option></select><select name="fuel_type" onchange="toggleEvFields(this)"><option value="diesel">Diesel</option><option value="petrol">Benzine</option><option value="hybrid">Hybride</option><option value="electric">Elektrisch</option></select></div><div class="capacityGrid"><label>Europallets<input name="europallet_capacity" type="number" min="0" placeholder="8"></label><label>Rolcontainers<input name="roll_container_capacity" type="number" min="0" placeholder="10"></label><label>Max kg<input name="max_weight_kg" type="number" min="0" placeholder="1250"></label><label>Max m³<input name="max_volume_m3" type="number" min="0" step="0.1" placeholder="15"></label></div><div id="evFields" class="evFields hidden"><h3>EV-profiel</h3><p class="muted">Nog geen laadstop-calculatie in deze fase; deze waarden worden alvast opgeslagen voor EV Intelligence.</p><div class="three"><input name="battery_capacity_kwh" type="number" placeholder="kWh accu"><input name="range_empty_km" type="number" placeholder="Bereik leeg km"><input name="range_loaded_km" type="number" placeholder="Bereik beladen km"></div><div class="two"><input name="current_soc_percent" type="number" placeholder="Batterij nu %"><input name="min_soc_percent" type="number" placeholder="Min. marge %"></div></div><button class="btn accent" type="submit">Voertuig opslaan</button></form></div><div class="workflowCard card"><h2>Voertuigen</h2>${list.length?`<div class="entityList">${list.map(v=>vehicleCard(v)).join('')}</div>`:`<div class="notice">Nog geen voertuigen. Voeg handmatig toe of laad de test-vloot.</div>`}</div></div>`);
}
function vehicleCard(v){const ev=String(v.fuel_type||'').toLowerCase()==='electric'; return `<div class="entityCard vehicleEntity"><div><b>${escapeHtml(v.name||v.license_plate||'Voertuig')}</b><div class="muted"><span class="plateSmall">${escapeHtml(v.license_plate||'—')}</span> · ${escapeHtml(v.brand||'')} ${escapeHtml(v.model||'')}</div><div class="chips"><span class="badge ${v.status==='available'?'green':'orange'}">${escapeHtml(v.status||'available')}</span><span class="badge">${v.europallet_capacity||0} EP</span><span class="badge">${v.roll_container_capacity||0} RC</span><span class="badge">${v.max_weight_kg||0} kg</span><span class="badge">${v.max_volume_m3||0} m³</span>${ev?`<span class="badge ev">EV ${v.current_soc_percent||0}% · ${v.range_loaded_km||0} km beladen</span><span class="badge orange">laadstops roadmap</span>`:''}</div></div><button class="miniDanger" onclick="deleteVehicle('${escapeHtml(v.id)}')">Verwijder</button></div>`}
function formatPlateInput(el){let v=el.value.toUpperCase().replace(/[^A-Z0-9]/g,''); if(v.length>2&&v.length<=5)v=v.slice(0,1)+'-'+v.slice(1,4)+'-'+v.slice(4); else if(v.length>5)v=v.slice(0,1)+'-'+v.slice(1,4)+'-'+v.slice(4,6); el.value=v;}
async function lookupRdw(){const input=document.getElementById('licensePlateInput'); const box=document.getElementById('rdwPreview'); if(!input||!input.value)return; box.textContent='RDW wordt opgezocht...'; try{const res=await api('/api/rdw/lookup?kenteken='+encodeURIComponent(input.value)); if(!res.found){box.textContent='Geen RDW match gevonden.'; return;} document.getElementById('vehicleBrand').value=res.brand||''; document.getElementById('vehicleModel').value=res.model||''; box.innerHTML=`<b>RDW match</b> · ${escapeHtml(res.brand||'')} ${escapeHtml(res.model||'')} · ${escapeHtml(res.vehicle_type||'')}`;}catch(e){box.textContent='RDW lookup niet beschikbaar of tijdelijk geen verbinding.';}}
function drivers(){
  const list=state.drivers||[];
  return shell(`<h1 class="pageTitle">Chauffeurs</h1><p class="subtitle">Chauffeurs, beschikbaarheid en app-toegang. Klaar voor route-toewijzing.</p><div class="setupActions"><button class="btn accent" onclick="seedFleet()">Test-chauffeurs laden</button><button class="btn" onclick="refreshFleet()">Vernieuwen</button><span class="badge green">${list.filter(d=>d.status==='available').length} beschikbaar</span></div><div class="fleetGrid"><div class="workflowCard card"><h2>Chauffeur toevoegen</h2><form class="entityForm" onsubmit="saveDriver(event)"><input name="name" placeholder="Naam chauffeur" required><div class="two"><input name="phone" placeholder="Telefoon"><input name="email" placeholder="E-mail"></div><div class="two"><select name="status"><option value="available">Beschikbaar</option><option value="unavailable">Niet beschikbaar</option><option value="sick">Ziek</option><option value="holiday">Vakantie</option></select><select name="license_type"><option value="B">Rijbewijs B</option><option value="BE">BE</option><option value="C1">C1</option><option value="C">C</option></select></div><select name="assigned_vehicle_id"><option value="">Geen vast voertuig</option>${(state.vehicles||[]).map(v=>`<option value="${escapeHtml(v.id)}">${escapeHtml(v.name||v.license_plate)}</option>`).join('')}</select><button class="btn accent" type="submit">Chauffeur opslaan</button></form></div><div class="workflowCard card"><h2>Chauffeurs</h2>${list.length?`<div class="entityList">${list.map(d=>driverCard(d)).join('')}</div>`:`<div class="notice">Nog geen chauffeurs. Voeg handmatig toe of laad de testset.</div>`}</div></div>`);
}
function driverCard(d){const v=(state.vehicles||[]).find(x=>x.id===d.assigned_vehicle_id); return `<div class="entityCard"><div><b>${escapeHtml(d.name)}</b><div class="muted">${escapeHtml(d.phone||'—')} · ${escapeHtml(d.email||'')}</div><div class="chips"><span class="badge ${d.status==='available'?'green':'orange'}">${escapeHtml(d.status||'available')}</span><span class="badge">${escapeHtml(d.license_type||'B')}</span><span class="badge">${v?escapeHtml(v.name||v.license_plate):'geen voertuig'}</span><span class="badge">app ${escapeHtml(d.app_access||'pending')}</span></div></div><button class="miniDanger" onclick="deleteDriver('${escapeHtml(d.id)}')">Verwijder</button></div>`}
async function refreshFleet(){state.vehicles=await api('/api/vehicles'); state.drivers=await api('/api/drivers'); state.mapState=await api('/api/map/state'); render();}
async function seedFleet(){await api('/api/testdata/fleet',{method:'POST'}); await refreshFleet();}
async function saveVehicle(e){e.preventDefault(); const data=Object.fromEntries(new FormData(e.target).entries()); ['europallet_capacity','roll_container_capacity','max_weight_kg','max_volume_m3','battery_capacity_kwh','range_empty_km','range_loaded_km','current_soc_percent','min_soc_percent'].forEach(k=>{if(data[k]!==''&&data[k]!=null)data[k]=Number(data[k]);}); await api('/api/vehicles',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)}); e.target.reset(); await refreshFleet();}
async function saveDriver(e){e.preventDefault(); const data=Object.fromEntries(new FormData(e.target).entries()); await api('/api/drivers',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)}); e.target.reset(); await refreshFleet();}
async function deleteVehicle(id){if(!confirm('Voertuig verwijderen?'))return; await api('/api/vehicles/'+id,{method:'DELETE'}); await refreshFleet();}
async function deleteDriver(id){if(!confirm('Chauffeur verwijderen?'))return; await api('/api/drivers/'+id,{method:'DELETE'}); await refreshFleet();}
function toggleEvFields(sel){const box=document.getElementById('evFields'); if(box) box.classList.toggle('hidden', sel.value!=='electric');}

function settings(){return shell(`<h1 class="pageTitle">Instellingen</h1><p class="subtitle">OSRM, integraties, depots, transport-units en API keys.</p><div class="moduleGrid"><div class="card panel"><h3>OSRM Nederland setup</h3><pre>cd /home/ubuntu/algoroute_latest/algoroute_v1_7_TEST_READY
sudo ./scripts/setup_osrm_nl.sh</pre></div><div>${osrmPanel()}</div></div>`)}
function render(){const pages={dashboard,live,planning,routes,vehicles,drivers,orders:()=>simple('Orders','Alle geïmporteerde en handmatige orders.'),load:()=>simple('Load Optimization','Pallets, rolcontainers, LIFO en later 2D/3D belading.'),tracking:()=>simple('Klanttracking','Trackinglinks en klantmeldingen.'),reports:()=>simple('Rapportages','Punctualiteit, routekwaliteit, load en EV.'),settings}; document.getElementById('app').innerHTML=(pages[state.page]||dashboard)(); setTimeout(initMap,50);}
function detectDelimiter(text){const first=text.split(/\r?\n/).slice(0,5).join('\n'); const candidates=[',',';','\t','|']; return candidates.map(d=>[d,(first.match(new RegExp('\\'+d,'g'))||[]).length]).sort((a,b)=>b[1]-a[1])[0][0];}
function parseCsv(text){const d=detectDelimiter(text); const rows=[]; let row=[], cell='', q=false; for(let i=0;i<text.length;i++){const c=text[i], n=text[i+1]; if(c==='"'&&q&&n==='"'){cell+='"';i++;} else if(c==='"'){q=!q;} else if(c===d&&!q){row.push(cell);cell='';} else if((c==='\n'||c==='\r')&&!q){ if(c==='\r'&&n==='\n') i++; row.push(cell); if(row.some(x=>String(x).trim()!=='')) rows.push(row); row=[]; cell=''; } else cell+=c; } if(cell||row.length){row.push(cell); rows.push(row);} const headers=(rows.shift()||[]).map(h=>h.trim()); return {headers, rows:rows.map(r=>Object.fromEntries(headers.map((h,i)=>[h,r[i]||''])))};}
async function handleCsvUpload(e){const file=e.target.files[0]; if(!file) return; const text=await file.text(); const parsed=parseCsv(text); state.csvHeaders=parsed.headers; state.csvRows=parsed.rows; state.mapping={}; await runSmartDetect(false); state.planningStep=2; render();}
async function runSmartDetect(doRender=true){if(!state.csvHeaders.length)return; const res=await api('/api/import/detect',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({headers:state.csvHeaders,rows:state.csvRows.slice(0,50)})}); state.detections=res.detections||[]; state.detections.forEach(d=>{if(d.best&&d.best.score>=82&&!state.mapping[d.column]) state.mapping[d.column]=d.best.field_id}); if(doRender) render();}
async function commitImport(){if(!state.csvRows.length)return alert('Geen CSV geladen'); const templateName=document.getElementById('templateName')?.value||''; const res=await api('/api/import/commit',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({rows:state.csvRows,mapping:state.mapping,template_name:templateName})}); state.queue=await api('/api/planning/queue'); alert(`${res.orders_created} orders geïmporteerd (${res.ready} ready, ${res.incomplete} incomplete)`); state.planningStep=3; render();}


async function clearQueue(){if(!confirm('Planning Queue en routes leegmaken?'))return; await api('/api/planning/queue',{method:'DELETE'}); state.queue=await api('/api/planning/queue'); state.mapState=await api('/api/map/state'); render();}

async function geocodeQueue(){
  state.geocodeResult=await api('/api/geocode/queue',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({limit:500, overwrite:false})});
  state.queue=await api('/api/planning/queue');
  render();
}

async function runOptimize(){state.optimizeResult=await api('/api/planning/optimize',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({})}); state.mapState=await api('/api/map/state'); state.selectedRouteId='all'; render();}
window.setPage=setPage; window.setStep=setStep; window.state=state; window.handleCsvUpload=handleCsvUpload; window.runSmartDetect=runSmartDetect; window.commitImport=commitImport; window.runOptimize=runOptimize; window.geocodeQueue=geocodeQueue; window.clearQueue=clearQueue; window.renderFieldCatalog=renderFieldCatalog; window.seedFleet=seedFleet; window.refreshFleet=refreshFleet; window.saveVehicle=saveVehicle; window.saveDriver=saveDriver; window.deleteVehicle=deleteVehicle; window.deleteDriver=deleteDriver; window.toggleEvFields=toggleEvFields;
init(); bootIntro();
