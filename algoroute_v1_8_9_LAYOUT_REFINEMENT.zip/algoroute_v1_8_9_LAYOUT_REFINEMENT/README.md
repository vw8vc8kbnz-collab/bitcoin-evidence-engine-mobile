# AlgoRoute v1.8.5 Route Quality Upgrade

C++ core v1.1 met farthest-seed + cheapest insertion + 2-opt/or-opt local search. Routevolgorde wordt daardoor minder zig-zag en dichter bij industrie-standaard heuristiek.


## v1.8.9 LAYOUT REFINEMENT
- Fixed map overlay collisions on Dashboard and Live Kaart.
- Reserved map control layers, legend spacing and route summary spacing.
- Routes overview spacing, metric wrapping and stop timeline polish.
- Laptop scale refinements for 1260-1500px screens.
