const app=document.getElementById('app');
let state={view:'dashboard',map:null,selected:'veh-01',mapInstances:{}};

function logo(){return `<svg viewBox="0 0 80 80" fill="none"><circle cx="40" cy="40" r="25" stroke="#2f8cff" stroke-width="6"/><circle cx="22" cy="27" r="7" fill="#00d6ff"/><circle cx="58" cy="27" r="7" fill="#2f8cff"/><circle cx="40" cy="60" r="7" fill="#41f0a8"/><path d="M27 30 40 54 53 30" stroke="#86c7ff" stroke-width="5" stroke-linecap="round"/></svg>`}
async function load(){const r=await fetch('/api/map/state');state.map=await r.json();render()}
function shell(content){return `<div class="app"><aside class="rail"><div class="mark">${logo()}</div><nav class="nav">${[['dashboard','⌘'],['map','🗺'],['planning','↗'],['routes','◎'],['vehicles','🚚'],['import','⇪'],['tracking','◉'],['reports','▣'],['settings','⚙']].map(([id,ic])=>`<button class="${state.view===id?'active':''}" title="${id}" onclick="go('${id}')">${ic}</button>`).join('')}</nav></aside><main class="main"><header class="topbar"><div class="brand">${logo()}<div><h1>Algo<span>Route</span></h1><div class="subtitle">Route & Load Intelligence for Complex Deliveries</div></div></div><div class="tabs"><button class="tab ${state.view==='dashboard'?'active':''}" onclick="go('dashboard')">Dashboard</button><button class="tab ${state.view==='map'?'active':''}" onclick="go('map')">Live Kaart</button><button class="tab ${state.view==='vehicles'?'active':''}" onclick="go('vehicles')">Wagenpark</button></div><div class="search">Zoek route, bus, klant of order…</div><div class="pill">Live sync actief</div></header>${content}</main></div>`}
function kpis(){return `<section class="kpis"><div class="card kpi"><label>Actieve routes</label><div class="value">${state.map.routes.length}</div><small>+2 sinds 08:00</small></div><div class="card kpi"><label>On-time performance</label><div class="value">94%</div><small>Customer Promise Guard</small></div><div class="card kpi"><label>Stops voltooid</label><div class="value">35/70</div><small>50% dagprogressie</small></div><div class="card kpi"><label>Load utilization</label><div class="value">82%</div><small>Pallet/rolcontainer check</small></div></section>`}
function mapBlock(full=false){const id=full?'map-full':'map-preview';setTimeout(()=>initRealMap(id,full),50);return `<section class="card mapCard"><div class="mapHead"><div class="mapTitle"><b>${full?'Live Kaart Nederland':'Operations Map'}</b><span>${full?'Echte MapLibre basemap + AlgoRoute overlays':'Dashboard preview met echte kaartdata'}</span></div><div class="mapTools"><button class="mapTool">Traffic</button><button class="mapTool">Routes</button><button class="mapTool">Stops</button></div></div><div id="${id}" class="realMap"><div class="mapFallback"><div class="mapFallbackInner"><b>Kaart laden…</b><p>MapLibre wordt gestart met NL basemap. Als externe tiles niet laden, blijft deze fallback zichtbaar.</p></div></div></div></section>`}
function initRealMap(id,full=false){
  if(!state.map || state.mapInstances[id] || !document.getElementById(id)) return;
  if(!window.maplibregl){return;}
  const center=state.map.center || [5.2913,52.1326];
  const map=new maplibregl.Map({
    container:id,
    center:center,
    zoom: full ? 7.15 : 6.65,
    pitch:0,
    bearing:0,
    attributionControl:true,
    style:{
      version:8,
      sources:{
        carto:{type:'raster',tiles:['https://a.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png','https://b.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png','https://c.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png','https://d.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png'],tileSize:256,attribution:'© OpenStreetMap © CARTO'}
      },
      layers:[{id:'carto',type:'raster',source:'carto',paint:{'raster-opacity':0.72,'raster-contrast':0.1,'raster-saturation':-0.25}}]
    }
  });
  state.mapInstances[id]=map;
  map.on('load',()=>{
    map.resize();
    addAlgoLayers(map);
    fitToRoutes(map);
  });
}
function addAlgoLayers(map){
  const routeFeatures=state.map.routes.map(r=>({type:'Feature',properties:{id:r.id,name:r.name,color:r.color,risk:r.risk,vehicle_id:r.vehicle_id},geometry:{type:'LineString',coordinates:r.coordinates}}));
  map.addSource('algoroute-routes',{type:'geojson',data:{type:'FeatureCollection',features:routeFeatures}});
  map.addLayer({id:'route-glow-wide',type:'line',source:'algoroute-routes',paint:{'line-color':['get','color'],'line-width':16,'line-opacity':0.16,'line-blur':6}});
  map.addLayer({id:'route-glow-mid',type:'line',source:'algoroute-routes',paint:{'line-color':['get','color'],'line-width':8,'line-opacity':0.34,'line-blur':3}});
  map.addLayer({id:'route-main',type:'line',source:'algoroute-routes',paint:{'line-color':['get','color'],'line-width':3.5,'line-opacity':0.96}});
  map.on('click','route-main',(e)=>{const vid=e.features?.[0]?.properties?.vehicle_id;if(vid) selectVehicle(vid)});
  map.on('mouseenter','route-main',()=>map.getCanvas().style.cursor='pointer');
  map.on('mouseleave','route-main',()=>map.getCanvas().style.cursor='');

  state.map.routes.forEach(route=>{
    const mid=route.coordinates[Math.floor(route.coordinates.length/2)];
    const el=document.createElement('div');el.className='routeLabel';el.innerHTML=`${route.name}<br><span style="color:#7f93ad">${route.km} km · ${route.risk}</span>`;
    new maplibregl.Marker({element:el,anchor:'bottom'}).setLngLat(mid).addTo(map);
    route.stops.forEach(stop=>{
      const s=document.createElement('div');s.className=`stopMarker ${stop.status}`;s.textContent=stop.seq;
      s.title=`${stop.city} · ETA ${stop.eta}`;
      new maplibregl.Marker({element:s}).setLngLat([stop.lng,stop.lat]).addTo(map);
    });
  });
  state.map.vehicles.forEach(v=>{
    const el=document.createElement('div');el.className=`truckMarker ${v.status==='delay'?'delay':v.status==='critical'?'critical':''}`;el.style.transform=`rotate(${v.heading||0}deg)`;
    el.title=`${v.name} · ${v.driver}`;el.onclick=()=>selectVehicle(v.id);
    new maplibregl.Marker({element:el}).setLngLat([v.lng,v.lat]).addTo(map);
  });
  map.addControl(new maplibregl.NavigationControl({showCompass:false}),'bottom-right');
}
function fitToRoutes(map){
  const coords=state.map.routes.flatMap(r=>r.coordinates).concat(state.map.vehicles.map(v=>[v.lng,v.lat]));
  const bounds=coords.reduce((b,c)=>b.extend(c),new maplibregl.LngLatBounds(coords[0],coords[0]));
  map.fitBounds(bounds,{padding:{top:92,bottom:70,left:60,right:60},duration:0,maxZoom:8.4});
}
function selectedPanel(){let veh=state.map.vehicles.find(v=>v.id===state.selected)||state.map.vehicles[0];let route=state.map.routes.find(r=>r.vehicle_id===veh.id)||state.map.routes[0];return `<section class="card panel"><h3>${veh.name} — ${veh.driver}</h3><div class="muted">${veh.plate} · ${veh.status} · ${veh.speed} km/u</div><div class="progress"><i style="width:${veh.progress}%"></i></div><div class="routeItem active"><div><b>Volgende ETA</b><div class="muted">${veh.eta} · ${veh.stops_done}/${veh.stops_total} stops</div></div><span class="badge ${veh.status==='critical'?'red':'green'}">${veh.load}</span></div><h3>Stopvolgorde</h3>${route.stops.map(s=>`<div class="stopRow"><div><b>${s.seq}. ${s.city}</b><div class="muted">ETA ${s.eta}</div></div><span class="badge ${s.status==='done'?'green':s.status==='current'?'':'red'}">${s.status}</span></div>`).join('')}</section>`}
function routePanel(){return `<section class="card panel"><h3>Routes vandaag</h3>${state.map.routes.map(r=>`<div class="routeItem ${state.map.vehicles.find(v=>v.id===state.selected)?.id===r.vehicle_id?'active':''}" onclick="selectVehicle('${r.vehicle_id}')"><div><b>${r.name}</b><div class="muted">${r.km} km · ${r.duration}</div></div><span class="badge ${r.risk==='high'?'red':r.risk==='low'?'green':''}">${r.risk}</span></div>`).join('')}</section>`}
function eventPanel(){return `<section class="card panel"><h3>Live alerts</h3>${state.map.events.map(e=>`<div class="event"><div><b>${e.title}</b><div class="muted">${e.route}</div></div><span class="badge ${e.severity==='critical'?'red':e.severity==='ok'?'green':''}">${e.type}</span></div>`).join('')}</section>`}
function dashboard(){return shell(`${kpis()}<section class="layout">${mapBlock()}<div class="side">${selectedPanel()}${eventPanel()}</div></section><section class="bottom">${routePanel()}<section class="card panel"><h3>Planning queue</h3><div class="routeItem"><b>18 orders klaar</b><span class="badge">CSV import</span></div><div class="routeItem"><b>4 capaciteit waarschuwingen</b><span class="badge red">load</span></div></section><section class="card panel"><h3>Fleet status</h3><div class="routeItem"><b>3 beschikbaar</b><span class="badge green">ready</span></div><div class="routeItem"><b>1 EV kritisch</b><span class="badge red">range</span></div></section></section>`)}
function liveMap(){return shell(`<section class="layout" style="grid-template-columns:1fr 410px;min-height:820px">${mapBlock(true)}<div class="side">${selectedPanel()}${routePanel()}${eventPanel()}</div></section>`)}
function placeholder(name){return shell(`${kpis()}<section class="card panel" style="min-height:640px"><h3>${name}</h3><p class="muted">Deze module staat klaar als schaalbare pagina. Volgende builds koppelen hier echte CRUD, import mapping en optimizer jobs aan.</p><div class="bottom"><div class="card panel"><h3>API-ready</h3><p class="muted">Data loopt via /api endpoints.</p></div><div class="card panel"><h3>Frontend module</h3><p class="muted">Eigen view en componentstructuur.</p></div><div class="card panel"><h3>Next build</h3><p class="muted">Functionele workflow toevoegen.</p></div></div></section>`)}
function render(){state.mapInstances={}; if(!state.map)return;app.innerHTML= state.view==='dashboard'?dashboard():state.view==='map'?liveMap():placeholder({planning:'Planning',routes:'Routes',vehicles:'Wagenpark',import:'Import Studio',tracking:'Klanttracking',reports:'Rapportages',settings:'Instellingen'}[state.view]||'Module')}
function go(v){state.view=v;render()}function selectVehicle(id){state.selected=id;render()}load();
