# AlgoRoute v0.9 — Real NL Map Foundation

Deze build vervangt de placeholder-kaart door een echte MapLibre GL kaartlaag met Nederland als basis.

## Nieuw
- MapLibre GL JS geïntegreerd in de frontend.
- Echte Nederland basemap via raster tiles in dark style.
- Route-layers als echte GeoJSON-polylines.
- Stopmarkers met status: done/current/planned.
- Voertuigmarkers met statuskleur: on-time/delay/critical.
- Klik op route of voertuig werkt door naar de rechter overlay.
- Dashboard preview en Live Kaart gebruiken dezelfde herbruikbare map-component.
- API levert routes, stops, voertuigen en coördinaten via `/api/map/state`.

## Nog placeholder / later
- Nog geen OSRM routeberekening.
- Nog geen live GPS vanuit chauffeur-app.
- Nog geen Google/TomTom/HERE traffic layer.
- Nog geen echte adressen/geocoding.

## Test
- Open Dashboard en Live Kaart.
- Klik op voertuigen/routes.
- Controleer dat de echte kaart zichtbaar is.
- Controleer `/api/health` en `/api/map/state`.
