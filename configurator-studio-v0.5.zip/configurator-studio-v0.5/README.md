# Configurator Studio v0.5

AI-first 3D configurator prototype.

## Wat is nieuw in v0.5

- Eén centrale **AI Product Studio** in plaats van losse prompt-, foto- en 3D-importblokken.
- Prompt, productfoto’s en GLB/GLTF-upload kunnen samen in één slimme composer.
- Eigen 3D-model import heeft nu ook prompt-context: de gebruiker kan uitleggen wat het product is en welke zones kleuren/texturen moeten krijgen.
- Zichtbare legacy demo-tafelprojecten zijn uit de hoofdervaring verwijderd; seed data start nu met een AI-created lounge-stoel voorbeeld.
- Professionelere SaaS-stijl: systeem/Inter-achtige sans typography, minder serif/magazine-look, compactere mobile header, clean cards en betere spacing.
- Reviewflow is belangrijker gemaakt: AI-output moet door asset review, desktop/mobile preview en publish-check.

## Belangrijk

Dit is nog een statische proof-of-concept. De AI-provider is een mock/procedural adapter. Productie vereist server-side AI jobs met providers zoals Meshy/Tripo/Rodin, opslag in Supabase/S3/CDN, normalizer, configurator-ready checker en Shopify-koppeling.

## Deploy

Gebruik `deploy/deploy-9999.sh` op de VPS om nginx op poort 9999 te configureren.
