// ============================================================================
// Builder — the merchant-facing tool. Dashboard + project shell + all steps.
// Desktop and mobile. Persists to the store on every edit.
// ============================================================================

import { store } from './store.js';
import { ConfiguratorEngine } from './engine.js';
import { renderRuntime } from './runtime.js';
import { renderProjectAiStudio, createSmartAiProduct } from './ai.js';
import { el, mount, clear, euro, uid, clamp, toast, debounce } from './util.js';
import { THREE } from './three.js';
import { newProject, publishChecks, TEMPLATES, ENVIRONMENTS, BACKGROUNDS, buildRuntimeConfig } from './schema.js';
import { navigate } from './router.js';

const STEPS = [
  { key: 'product', label: 'Product' },
  { key: 'model', label: 'Model' },
  { key: 'surfaces', label: 'Vlakken' },
  { key: 'finishes', label: 'Afwerkingen' },
  { key: 'pricing', label: 'Prijs' },
  { key: 'template', label: 'Template' },
  { key: 'scene', label: 'Weergave' },
  { key: 'ai', label: 'AI Studio' },
  { key: 'preview', label: 'Voorbeeld' },
  { key: 'publish', label: 'Publiceren' },
];

// ---- shared helpers ---------------------------------------------------------
function shade(hex, amt) { const c = new THREE.Color(hex), f = amt / 100; c.r = clamp(c.r + f, 0, 1); c.g = clamp(c.g + f, 0, 1); c.b = clamp(c.b + f, 0, 1); return '#' + c.getHexString(); }
function finishSwatch(fin) {
  if (!fin) return 'background:#ccc;';
  const hex = fin.colorHex;
  if (fin.kind === 'metal') return `background:linear-gradient(135deg,${shade(hex, 24)},${hex} 45%,${shade(hex, -20)});`;
  if (fin.kind === 'marble') return `background:radial-gradient(120% 120% at 30% 20%,#f4f1ea,${hex} 70%);`;
  if (fin.kind === 'wood') return `background:linear-gradient(150deg,${shade(hex, 16)},${hex} 45%,${shade(hex, -14)});`;
  return `background:${hex};`;
}
function statusPill(status) {
  const map = { draft: ['Concept', 'pill-draft'], test: ['Test', 'pill-test'], live: ['Live', 'pill-live'] };
  const [t, c] = map[status] || map.draft; return el('span', { class: 'pill ' + c, text: t });
}

// ============================================================================
// DASHBOARD
// ============================================================================
export function renderDashboard(container) {
  const projects = store.listProjects().filter((p) => p.model?.source !== 'demo');
  const configs = store.listConfigurations();
  const now = new Date();
  const thisMonth = configs.filter((c) => { const d = new Date(c.createdAt); return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear(); }).length;
  const liveCount = projects.filter((p) => p.status === 'live').length;

  const grid = el('div', { class: 'dash-grid' });
  if (!projects.length) {
    grid.appendChild(el('div', { class: 'empty-project-card' }, [
      el('b', { text: 'Nog geen AI-productbasis' }),
      el('span', { text: 'Begin hierboven met een prompt, productfoto’s, een 3D-model of een combinatie daarvan.' }),
    ]));
  }
  projects.forEach((p) => {
    const cfgCount = p.surfaces.filter((s) => s.configurable).length;
    const sourceLabel = p.model?.source === 'glb' ? '3D import + AI prompt' : p.model?.source === 'ai_images' ? 'Foto’s + prompt' : 'Prompt naar 3D';
    const card = el('div', { class: 'proj-card', role: 'button', tabindex: '0',
      onclick: () => navigate(`#/p/${p.id}/ai`),
      onkeydown: (e) => { if (e.key === 'Enter') navigate(`#/p/${p.id}/ai`); } }, [
      el('div', { class: 'proj-card-top' }, [statusPill(p.status), el('span', { class: 'proj-card-price', text: euro(p.basePrice, p.currency) })]),
      el('div', { class: 'proj-card-name', text: p.name }),
      el('div', { class: 'proj-card-meta', text: `${sourceLabel} · ${cfgCount} configureerbare zones` }),
      el('div', { class: 'proj-card-actions' }, [
        el('button', { class: 'card-act', title: 'Open review', onclick: (e) => { e.stopPropagation(); navigate(`#/p/${p.id}/ai`); }, text: 'Review' }),
        el('button', { class: 'card-act', title: 'Preview', onclick: (e) => { e.stopPropagation(); navigate(`#/preview/${p.id}`); }, text: 'Preview' }),
        el('button', { class: 'card-act danger', title: 'Verwijderen', onclick: async (e) => { e.stopPropagation(); if (confirm(`“${p.name}” verwijderen?`)) { await store.deleteProject(p.id); toast('Verwijderd'); renderDashboard(container); } }, text: 'Verwijder' }),
      ]),
    ]);
    grid.appendChild(card);
  });

  const stat = (n, l) => el('div', { class: 'stat' }, [el('div', { class: 'stat-n mono', text: String(n) }), el('div', { class: 'stat-l', text: l })]);
  const smartPrompt = el('textarea', { class: 'smart-textarea', placeholder: 'Beschrijf je product en wat klanten straks moeten kunnen aanpassen...\n\nVoorbeeld: Dit is een lounge stoel. De zitting en rugleuning moeten stofkleuren krijgen. Het frame moet metaalafwerkingen krijgen.' });
  const photoInput = el('input', { class: 'smart-file-input', type: 'file', accept: 'image/*', multiple: true });
  const modelInput = el('input', { class: 'smart-file-input', type: 'file', accept: '.glb,.gltf,model/gltf-binary,model/gltf+json' });
  const category = el('select', { class: 'inp smart-select' }, [
    el('option', { value: 'auto', text: 'AI bepaalt producttype' }),
    el('option', { value: 'chair', text: 'Stoel/fauteuil' }),
    el('option', { value: 'cabinet', text: 'Kast/meubel' }),
    el('option', { value: 'lamp', text: 'Lamp' }),
    el('option', { value: 'table', text: 'Tafel/bureau' }),
    el('option', { value: 'product', text: 'Algemeen product' }),
  ]);
  const attachmentState = el('div', { class: 'smart-attachments-empty', text: 'Nog geen bijlagen toegevoegd. Je kunt prompt, foto’s en 3D-model combineren.' });
  function refreshAttachments() {
    const photos = Array.from(photoInput.files || []);
    const model = modelInput.files?.[0];
    clear(attachmentState);
    if (!photos.length && !model) { attachmentState.className = 'smart-attachments-empty'; attachmentState.textContent = 'Nog geen bijlagen toegevoegd. Je kunt prompt, foto’s en 3D-model combineren.'; return; }
    attachmentState.className = 'smart-attachments-list';
    photos.slice(0,4).forEach((f) => attachmentState.appendChild(el('span', { class: 'file-chip', text: 'Foto · ' + f.name })));
    if (model) attachmentState.appendChild(el('span', { class: 'file-chip file-chip-model', text: '3D · ' + model.name }));
  }
  photoInput.addEventListener('change', refreshAttachments);
  modelInput.addEventListener('change', refreshAttachments);

  async function startSmartAi() {
    try {
      const created = await createSmartAiProduct({
        prompt: smartPrompt.value,
        images: Array.from(photoInput.files || []),
        modelFile: modelInput.files?.[0] || null,
        category: category.value,
      });
      toast('AI-productbasis gemaakt — review onderdelen en mobile preview');
      navigate(`#/p/${created.id}/ai`);
    } catch (e) { toast(e.message || 'AI Product Studio kon niet starten'); }
  }

  const root = el('div', { class: 'dashboard v05-dashboard' }, [
    el('header', { class: 'dash-header v05-header' }, [
      el('div', { class: 'brandmark' }, [el('span', { class: 'diamond' }), el('span', { class: 'brandtext', text: 'Configurator Studio' })]),
      el('div', { class: 'dash-tabs' }, [
        el('button', { class: 'tab active', onclick: () => navigate('#/'), text: 'AI Studio' }),
        el('button', { class: 'tab', onclick: () => navigate('#/configs'), text: 'Configuraties' }),
        el('button', { class: 'tab', onclick: () => navigate('#/library'), text: 'Afwerkingen' }),
      ]),
    ]),
    el('main', { class: 'dash-body v05-body' }, [
      el('section', { class: 'v05-hero' }, [
        el('div', { class: 'hero-kicker', text: 'AI Product Studio' }),
        el('h1', { class: 'dash-title', text: 'Maak een 3D-productconfigurator met AI' }),
        el('p', { class: 'dash-sub', text: 'Eén slimme ingang voor prompt, productfoto’s en eigen 3D-modellen. AI maakt een productbasis met onderdelen, materiaalzones en een reviewflow voor desktop en mobiel.' }),
      ]),
      el('section', { class: 'smart-card' }, [
        el('div', { class: 'smart-card-head' }, [
          el('span', { class: 'smart-badge', text: 'Nieuwe hoofdflow' }),
          el('h2', { text: 'Geef je product aan AI' }),
          el('p', { text: 'Beschrijf het product, voeg foto’s toe of upload een bestaand GLB/GLTF-model. De prompt stuurt ook de 3D-import: wat is het product en welke zones moeten configureerbaar worden?' }),
        ]),
        smartPrompt,
        el('div', { class: 'smart-upload-row' }, [
          el('label', { class: 'smart-upload' }, [el('span', { text: '+ Productfoto’s' }), el('small', { text: '1–4 beelden' }), photoInput]),
          el('label', { class: 'smart-upload' }, [el('span', { text: '+ 3D-model' }), el('small', { text: 'GLB / GLTF' }), modelInput]),
        ]),
        attachmentState,
        el('div', { class: 'smart-actions' }, [category, el('button', { class: 'btn dark smart-cta', onclick: startSmartAi, text: 'Genereer productbasis' })]),
        el('div', { class: 'smart-pipeline' }, [
          el('span', { text: 'Product begrijpen' }), el('span', { text: '3D maken/analyseren' }), el('span', { text: 'Zones voorstellen' }), el('span', { text: 'Preview & review' }),
        ]),
      ]),
      el('div', { class: 'stats compact' }, [stat(projects.length, 'AI-projecten'), stat(liveCount, 'Live'), stat(thisMonth, 'Deze maand'), stat(configs.length, 'Configuraties')]),
      el('div', { class: 'section-head' }, [el('h2', { text: 'Recente productbases' }), el('span', { text: 'Alle zichtbare projecten zijn AI-created of geïmporteerd via de slimme workflow' })]),
      grid,
    ]),
  ]);
  mount(container, root);
}

// ============================================================================
// PROJECT SHELL + step host
// ============================================================================
let session = { engine: null, cleanup: [] };
function disposeSession() {
  session.cleanup.forEach((fn) => { try { fn(); } catch (e) {} });
  session.cleanup = [];
  if (session.engine) { try { session.engine.dispose(); } catch (e) {} session.engine = null; }
}
const saveNow = (project, saveEl) => { if (saveEl) saveEl.textContent = 'Opslaan…'; store.saveProject(project).then(() => { if (saveEl) setTimeout(() => saveEl.textContent = 'Opgeslagen', 400); }); };

export function renderBuilder(container, projectId, stepKey) {
  disposeSession();
  const project = store.getProject(projectId);
  if (!project) { navigate('#/'); return; }
  const step = STEPS.find((s) => s.key === stepKey) ? stepKey : 'product';

  const saveEl = el('span', { class: 'save', text: 'Opgeslagen' });
  const contentHost = el('div', { class: 'builder-content' });

  // steps nav (desktop sidebar + mobile scroller share markup, CSS differs)
  const nav = el('nav', { class: 'steps' }, STEPS.map((s, i) =>
    el('button', { class: 'step' + (s.key === step ? ' active' : ''), onclick: () => navigate(`#/p/${project.id}/${s.key}`) }, [
      el('span', { class: 'step-n', text: String(i + 1) }), el('span', { class: 'step-lbl', text: s.label }),
    ])));

  const topbar = el('header', { class: 'topbar' }, [
    el('div', { class: 'tb-left' }, [
      el('button', { class: 'tb-back', title: 'Terug', onclick: () => navigate('#/'), text: '‹' }),
      el('span', { class: 'diamond' }),
      el('div', { class: 'proj-title' }, [el('b', { text: project.name }), el('small', { text: project.model.source === 'glb' ? (project.model.name || 'GLB') : project.model.source === 'ai_prompt' ? 'AI-prompt model' : project.model.source === 'ai_images' ? 'AI-foto model' : 'AI/import model' })]),
      statusPill(project.status),
    ]),
    el('div', { class: 'tb-right' }, [
      saveEl,
      el('button', { class: 'btn', onclick: () => navigate(`#/preview/${project.id}`), text: 'Voorbeeld' }),
      el('button', { class: 'btn dark', onclick: () => openPublish(project, saveEl), text: 'Publiceren' }),
    ]),
  ]);

  const root = el('div', { class: 'builder' }, [topbar, el('div', { class: 'builder-main' }, [nav, contentHost])]);
  mount(container, root);

  const ctx = { project, saveEl, save: () => saveNow(project, saveEl) };
  const renderers = { product: stepProduct, model: stepModel, surfaces: stepSurfaces, finishes: stepFinishes, pricing: stepPricing, template: stepTemplate, scene: stepScene, ai: stepAi, preview: stepPreview, publish: stepPublish };
  (renderers[step] || stepProduct)(contentHost, ctx);
}

// ---- publish popover --------------------------------------------------------
function openPublish(project, saveEl) {
  const { checks, passed } = publishChecks(project);
  const overlay = el('div', { class: 'overlay', onclick: (e) => { if (e.target.classList.contains('overlay')) overlay.remove(); } });
  const pop = el('div', { class: 'pop' }, [
    el('h5', { text: 'Publiceren' }),
    el('p', { text: 'Controle vóór livegang. Publiceren kan pas als alles groen is.' }),
    ...checks.map((c) => el('div', { class: 'chk ' + (c.ok ? 'pass' : 'fail') }, [
      el('span', { class: 'chk-ic', text: c.ok ? '✓' : '!' }),
      el('span', { class: 'chk-msg' }, [el('b', { text: c.label }), c.sub ? el('small', { text: c.sub }) : null]),
    ])),
    el('button', { class: 'btn dark full', style: passed ? '' : 'opacity:.5', onclick: async () => {
      if (!passed) { toast('Nog niet publiceerbaar'); return; }
      project.status = 'live'; await store.saveProject(project); overlay.remove(); toast('Configurator gepubliceerd'); navigate(`#/p/${project.id}/publish`);
    }, text: passed ? 'Publiceer configurator' : 'Nog niet publiceerbaar' }),
  ]);
  overlay.appendChild(pop); document.body.appendChild(overlay);
}

// ============================================================================
// STEP: PRODUCT
// ============================================================================
function stepProduct(host, ctx) {
  const p = ctx.project;
  const save = debounce(ctx.save, 400);
  const form = el('div', { class: 'form' }, [
    field('Projectnaam', input(p.name, (v) => { p.name = v; save(); })),
    row([
      field('Basisprijs', input(String(p.basePrice), (v) => { p.basePrice = parseFloat(v) || 0; save(); }, 'number')),
      field('Valuta', select(['EUR', 'USD', 'GBP'], p.currency, (v) => { p.currency = v; save(); })),
    ]),
    field('Taal', select(['nl', 'en', 'de'], p.language, (v) => { p.language = v; save(); })),
    field('Shopify product-ID (optioneel)', input(p.shopify.productId || '', (v) => { p.shopify.productId = v.trim() || undefined; save(); }, 'text', 'gid://shopify/Product/…')),
  ]);
  mount(host, stepScaffold('Product', 'Basisgegevens van je configurator.', form));
}

// ============================================================================
// STEP: MODEL  (AI-first; GLB upload remains the advanced/fallback route)
// ============================================================================
function stepModel(host, ctx) {
  const p = ctx.project;
  const stage = el('div', { class: 'mini-stage' });
  const slotList = el('div', { class: 'slot-list' });
  const drop = el('label', { class: 'dropzone' }, [
    el('input', { type: 'file', accept: '.glb,.gltf', style: 'display:none', onchange: (e) => handleFile(e.target.files[0]) }),
    el('div', { class: 'dz-inner', html: '<b>Technische GLB/GLTF-import</b><span>Hoofdroute: AI Product Studio met prompt + foto’s + 3D-upload samen</span>' }),
  ]);
  const panel = el('div', { class: 'model-panel' }, [
    el('h3', { class: 'panel-h', text: 'Model' }),
    drop,
    el('div', { class: 'flabel', text: 'Configureerbare slots in dit model' }),
    el('p', { class: 'hint', text: 'Elk slot kan een aanpasbaar vlak worden. Bij AI-output stelt de provider slots voor; bij eigen GLB moeten onafhankelijke onderdelen aparte materialen/slots hebben.' }),
    slotList,
  ]);

  mount(host, el('div', { class: 'builder-3col' }, [el('div', { class: 'col-stage' }, [stage]), panel]));

  let engine = null;
  function mountEngine() {
    if (engine) { try { engine.dispose(); } catch (e) {} }
    engine = new ConfiguratorEngine(); session.engine = engine;
    const cfg = { project: { basePrice: p.basePrice, currency: p.currency, name: p.name }, model: p.model, template: p.template, branding: { showBranding: false }, surfaces: [] };
    engine.mount(stage, cfg, { mode: 'live' }).then(() => renderSlots(engine.detectSlots())).catch((e) => { console.error(e); toast('Kon model niet laden'); });
  }
  function renderSlots(slots) {
    clear(slotList);
    if (!slots.length) { slotList.appendChild(el('div', { class: 'hint', text: 'Geen slots gevonden.' })); return; }
    slots.forEach((s) => {
      const existing = p.surfaces.find((x) => x.slot === s.slot);
      slotList.appendChild(el('div', { class: 'slot-row' }, [
        el('span', { class: 'slot-name' }, [el('b', { text: existing ? existing.name : s.slot }), el('span', { class: 'mono', text: `${s.slot} · ${s.count} mesh` })]),
        existing ? el('span', { class: 'pill pill-live', text: 'in gebruik' })
          : el('button', { class: 'btn tiny', onclick: () => { addSurface(s.slot); }, text: 'Als vlak toevoegen' }),
      ]));
    });
  }
  function addSurface(slot) {
    const s = { id: uid('srf'), slot, name: slot.replace(/material[_-]?/i, '') || 'Vlak', configurable: true, options: [], defaultOptionId: '' };
    p.surfaces.push(s); ctx.save(); toast('Vlak toegevoegd — stel afwerkingen in bij “Vlakken”'); mountEngine();
  }
  async function handleFile(file) {
    if (!file) return;
    const url = URL.createObjectURL(file);
    p.model = { source: 'glb', url, name: file.name }; ctx.save();
    toast('Model geladen. Let op: bij publicatie moet het bestand op je CDN staan.');
    mountEngine();
  }
  mountEngine();
  session.cleanup.push(() => { if (engine) engine.dispose(); });
}

// ============================================================================
// STEP: SURFACES  (the visual 3D screen — click a surface, drag finishes on)
// ============================================================================
function stepSurfaces(host, ctx) {
  const p = ctx.project;
  const library = store.getLibrary();
  let selectedId = p.surfaces[0]?.id || null;

  const stage = el('div', { class: 'edit-stage' });
  const surfLabel = el('div', { class: 'surflabel' });
  const dropglow = el('div', { class: 'dropglow' });
  stage.appendChild(surfLabel); stage.appendChild(dropglow);

  const inspector = el('aside', { class: 'inspector' });
  const palRow = el('div', { class: 'pal-row' });
  const palette = el('div', { class: 'palette' }, [
    el('div', { class: 'pal-head' }, [el('span', { class: 'pal-t', text: 'Afwerkingenbibliotheek' }), el('span', { class: 'pal-h', text: 'Sleep een blok op een vlak' })]),
    palRow,
  ]);

  const layout = el('div', { class: 'builder-3col edit' }, [
    el('div', { class: 'col-stage' }, [stage, palette]),
    inspector,
  ]);
  mount(host, layout);

  // palette chips
  library.forEach((fin) => {
    const chip = el('div', { class: 'fchip', dataset: { finish: fin.id } }, [
      el('span', { class: 'fchip-sw', style: finishSwatch(fin) }),
      el('span', { class: 'fchip-nm', text: fin.name }),
      el('span', { class: 'fchip-dl', text: fin.defaultDelta ? '+' + euro(fin.defaultDelta, p.currency) : 'inbegrepen' }),
    ]);
    chip.addEventListener('pointerdown', (e) => startDrag(e, fin.id));
    palRow.appendChild(chip);
  });

  // engine
  const engine = new ConfiguratorEngine(); session.engine = engine;
  const cfg = () => buildBuilderConfig(p, library);
  engine.mount(stage, cfg(), { mode: 'builder' }).then(() => {
    if (selectedId) { engine.setHighlightSurface(selectedId); }
    engine.on('select', (sid) => selectSurface(sid));
    engine.on('hover', ({ surfaceId, point }) => showLabel(surfaceId, point));
    engine.on('hoverend', () => surfLabel.classList.remove('show'));
    renderInspector();
  }).catch((e) => { console.error(e); toast('Kon model niet laden'); });

  function showLabel(sid, point) {
    const s = p.surfaces.find((x) => x.id === sid); if (!s) return;
    const v = point.clone().project(engine.camera); const r = stage.getBoundingClientRect();
    surfLabel.style.left = (((v.x + 1) / 2) * r.width) + 'px';
    surfLabel.style.top = (((-v.y + 1) / 2) * r.height) + 'px';
    surfLabel.textContent = s.name; surfLabel.classList.add('show');
  }

  function selectSurface(sid) { selectedId = sid; engine.setHighlightSurface(sid); renderInspector(); }

  function renderInspector() {
    const layers = el('div', { class: 'layers' }, p.surfaces.map((s) => {
      const cur = s.options.find((o) => o.id === (engine.selection[s.id] || s.defaultOptionId));
      const fin = cur && store.getFinish(cur.finishId);
      return el('button', { class: 'layer' + (selectedId === s.id ? ' sel' : ''), onclick: () => { selectSurface(s.id); engine.focusSurface(s.id); } }, [
        el('span', { class: 'layer-dot', style: finishSwatch(fin) }),
        el('span', { class: 'layer-info' }, [el('b', { text: s.name }), el('span', { class: 'mono', text: s.slot })]),
        el('span', { class: 'badge ' + (s.configurable ? 'cfg' : 'lock'), text: s.configurable ? 'aanpasbaar' : 'vast' }),
      ]);
    }));

    const detail = el('div', { class: 'surf-detail' });
    const s = p.surfaces.find((x) => x.id === selectedId);
    if (!s) {
      detail.appendChild(el('div', { class: 'detail-hint', text: 'Klik een vlak op het model of in de lijst. Sleep daarna een afwerking uit de bibliotheek op dat vlak.' }));
    } else {
      detail.appendChild(el('div', { class: 'insp-eyebrow', text: 'Vlak' }));
      detail.appendChild(el('div', { class: 'insp-title', html: `${s.name}<small>${s.slot}</small>` }));
      detail.appendChild(el('div', { class: 'srow' }, [
        el('div', {}, [el('div', { class: 'srow-k', text: 'Klanten mogen dit aanpassen' }), el('div', { class: 'srow-sub', text: s.configurable ? 'Zichtbaar als keuze' : 'Vast — altijd standaard' })]),
        el('button', { class: 'switch' + (s.configurable ? ' on' : ''), onclick: () => { s.configurable = !s.configurable; ctx.save(); renderInspector(); } }),
      ]));
      detail.appendChild(el('div', { class: 'flabel', text: 'Afwerkingen op dit vlak' }));
      s.options.forEach((o) => {
        const fin = store.getFinish(o.finishId);
        detail.appendChild(el('div', { class: 'finish' + ((engine.selection[s.id] || s.defaultOptionId) === o.id ? ' cur' : ''), onclick: () => applyOpt(s, o) }, [
          el('span', { class: 'finish-sw', style: finishSwatch(fin) }),
          el('span', { class: 'finish-meta' }, [el('b', { text: fin ? fin.name : '—' }), el('span', { class: 'mono', text: o.sku || (fin && fin.sku) || '' })]),
          el('span', { class: 'finish-delta', text: o.delta ? '+' + euro(o.delta, p.currency) : '—' }),
          el('button', { class: 'star' + (s.defaultOptionId === o.id ? ' on' : ''), title: 'Standaard', onclick: (e) => { e.stopPropagation(); s.defaultOptionId = o.id; ctx.save(); renderInspector(); }, text: '★' }),
        ]));
      });
      detail.appendChild(el('div', { class: 'assign-hint', text: 'Sleep een blok uit de bibliotheek hierop om een afwerking toe te voegen.' }));
    }

    mount(inspector, el('div', {}, [
      el('div', { class: 'insp-eyebrow', text: 'Vlakken' }),
      el('div', { class: 'insp-title', html: 'Model opgedeeld<small>' + p.surfaces.length + ' materiaalslots</small>' }),
      layers, el('div', { class: 'divider' }), detail,
    ]));
  }

  function applyOpt(s, o) { engine.applyOption(s.id, o.id, true); renderInspector(); }

  function addFinishToSurface(surfaceId, finishId) {
    const s = p.surfaces.find((x) => x.id === surfaceId); const fin = store.getFinish(finishId); if (!s || !fin) return false;
    let o = s.options.find((x) => x.finishId === finishId);
    const isNew = !o;
    if (isNew) { o = { id: uid('opt'), finishId, delta: fin.defaultDelta, sku: fin.sku }; s.options.push(o); }
    if (!s.defaultOptionId) s.defaultOptionId = o.id;
    // engine needs fresh config to know this new option's material
    engine.config = buildBuilderConfig(p, library);
    engine.applyOption(s.id, o.id, true);
    ctx.save(); selectSurface(surfaceId); renderInspector();
    return isNew;
  }

  // drag-assign
  let dragFinish = null;
  const ghost = el('div', { class: 'ghost' }); document.body.appendChild(ghost);
  session.cleanup.push(() => ghost.remove());
  function startDrag(e, finishId) {
    e.preventDefault(); dragFinish = finishId;
    const fin = store.getFinish(finishId);
    ghost.setAttribute('style', `left:${e.clientX}px;top:${e.clientY}px;` + finishSwatch(fin)); ghost.classList.add('on');
    const move = (ev) => {
      ghost.style.left = ev.clientX + 'px'; ghost.style.top = ev.clientY + 'px';
      const r = stage.getBoundingClientRect();
      const over = ev.clientX >= r.left && ev.clientX <= r.right && ev.clientY >= r.top && ev.clientY <= r.bottom;
      if (over) { const p2 = engine.pickSurfaceAt(ev.clientX, ev.clientY); if (p2?.surfaceId) { engine.setHighlightSurface(p2.surfaceId); dropglow.classList.add('on'); } else dropglow.classList.remove('on'); }
      else dropglow.classList.remove('on');
    };
    const up = (ev) => {
      window.removeEventListener('pointermove', move); ghost.classList.remove('on'); dropglow.classList.remove('on');
      const r = stage.getBoundingClientRect();
      const over = ev.clientX >= r.left && ev.clientX <= r.right && ev.clientY >= r.top && ev.clientY <= r.bottom;
      if (over) { const p2 = engine.pickSurfaceAt(ev.clientX, ev.clientY);
        if (p2?.surfaceId) { const isNew = addFinishToSurface(p2.surfaceId, dragFinish); const s = p.surfaces.find((x) => x.id === p2.surfaceId); const fin = store.getFinish(dragFinish);
          toast(isNew ? `“${fin.name}” toegevoegd aan ${s.name}` : `${s.name} → ${fin.name}`); } }
      dragFinish = null;
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up, { once: true });
  }

  session.cleanup.push(() => { if (engine) engine.dispose(); });
}

// ============================================================================
// STEP: FINISHES  (per-surface options table: delta, SKU, default, remove)
// ============================================================================
function stepFinishes(host, ctx) {
  const p = ctx.project; const library = store.getLibrary();
  const save = debounce(ctx.save, 400);
  const wrap = el('div', { class: 'finishes-step' });

  p.surfaces.forEach((s) => {
    const table = el('div', { class: 'opt-table' });
    function renderRows() {
      clear(table);
      s.options.forEach((o) => {
        const fin = store.getFinish(o.finishId);
        table.appendChild(el('div', { class: 'opt-row' }, [
          el('span', { class: 'opt-sw', style: finishSwatch(fin) }),
          el('span', { class: 'opt-name', text: fin ? fin.name : '—' }),
          labeledInput('Meerprijs', String(o.delta), (v) => { o.delta = parseFloat(v) || 0; save(); }, 'number', 'delta-in'),
          labeledInput('SKU', o.sku || '', (v) => { o.sku = v.trim(); save(); }, 'text', 'sku-in'),
          labeledInput('Shopify variant', o.shopifyVariantId || '', (v) => { o.shopifyVariantId = v.trim() || undefined; save(); }, 'text', 'var-in'),
          el('button', { class: 'star' + (s.defaultOptionId === o.id ? ' on' : ''), title: 'Standaard', onclick: () => { s.defaultOptionId = o.id; save(); renderRows(); }, text: '★' }),
          el('button', { class: 'row-del', title: 'Verwijder', onclick: () => { s.options = s.options.filter((x) => x.id !== o.id); if (s.defaultOptionId === o.id) s.defaultOptionId = s.options[0]?.id || ''; save(); renderRows(); }, text: '×' }),
        ]));
      });
      // add finish from library
      const addSel = el('select', { class: 'add-finish', onchange: (e) => {
        const fid = e.target.value; if (!fid) return; const fin = store.getFinish(fid);
        s.options.push({ id: uid('opt'), finishId: fid, delta: fin.defaultDelta, sku: fin.sku });
        if (!s.defaultOptionId) s.defaultOptionId = s.options[s.options.length - 1].id;
        save(); renderRows(); e.target.value = '';
      } }, [el('option', { value: '', text: '+ Afwerking uit bibliotheek…' }), ...library.map((f) => el('option', { value: f.id, text: f.name }))]);
      table.appendChild(el('div', { class: 'opt-add' }, [addSel]));
    }
    renderRows();
    wrap.appendChild(el('div', { class: 'finish-block' }, [
      el('div', { class: 'fb-head' }, [
        el('div', {}, [el('b', { text: s.name }), el('span', { class: 'mono', text: s.slot })]),
        el('span', { class: 'badge ' + (s.configurable ? 'cfg' : 'lock'), text: s.configurable ? 'aanpasbaar' : 'vast' }),
      ]),
      table,
    ]));
  });

  wrap.appendChild(el('div', { class: 'lib-note', html: 'Afwerkingen komen uit je <b>accountbibliotheek</b> en zijn herbruikbaar over al je producten. Elke SKU mapt straks naar een Shopify-variant zodat de prijs klopt in checkout.' }));
  mount(host, stepScaffold('Afwerkingen', 'Stel per vlak de opties, meerprijs en SKU in.', wrap));
}

// ============================================================================
// STEP: PRICING
// ============================================================================
function stepPricing(host, ctx) {
  const p = ctx.project; const save = debounce(ctx.save, 400);
  const summary = el('div', { class: 'price-summary' });
  function renderSummary() {
    clear(summary);
    summary.appendChild(el('div', { class: 'ps-row ps-base' }, [el('span', { text: 'Basisprijs' }), el('span', { class: 'mono', text: euro(p.basePrice, p.currency) })]));
    p.surfaces.filter((s) => s.configurable).forEach((s) => {
      summary.appendChild(el('div', { class: 'ps-group', text: s.name }));
      s.options.forEach((o) => { const fin = store.getFinish(o.finishId);
        summary.appendChild(el('div', { class: 'ps-row' }, [el('span', { text: (fin ? fin.name : '—') + (s.defaultOptionId === o.id ? ' (standaard)' : '') }), el('span', { class: 'mono', text: o.delta ? '+' + euro(o.delta, p.currency) : '—' })])); });
    });
    const min = p.basePrice + p.surfaces.filter((s) => s.configurable).reduce((a, s) => a + Math.min(0, ...s.options.map((o) => o.delta), 0), 0);
    const example = p.basePrice + p.surfaces.filter((s) => s.configurable).reduce((a, s) => { const d = s.options.find((o) => o.id === s.defaultOptionId); return a + (d ? d.delta : 0); }, 0);
    summary.appendChild(el('div', { class: 'ps-total' }, [el('span', { text: 'Voorbeeld (standaardkeuzes)' }), el('span', { class: 'mono', text: euro(example, p.currency) })]));
  }
  renderSummary();
  const form = el('div', { class: 'form' }, [
    field('Basisprijs', input(String(p.basePrice), (v) => { p.basePrice = parseFloat(v) || 0; save(); renderSummary(); }, 'number')),
    el('div', { class: 'pricing-note', html: 'De prijs in de configurator is voor de UX. De <b>definitieve</b> prijs wordt server-side gevalideerd en via de Shopify-variant/-SKU afgerekend (addendum A). Vermijd prijsvertrouwen vanuit de client.' }),
    summary,
  ]);
  mount(host, stepScaffold('Prijs', 'Basisprijs plus meerprijs per afwerking.', form));
}

// ============================================================================
// STEP: TEMPLATE
// ============================================================================
function stepTemplate(host, ctx) {
  const p = ctx.project; const save = debounce(ctx.save, 300);
  const cards = el('div', { class: 'tpl-cards' }, TEMPLATES.map((t) =>
    el('button', { class: 'tpl-card' + (p.template.templateId === t.id ? ' sel' : ''), onclick: () => { p.template.templateId = t.id; save(); host._rerender(); } }, [
      el('div', { class: 'tpl-preview tpl-' + t.id }),
      el('b', { text: t.name }), el('span', { class: 'tpl-hint', text: t.hint }),
    ])));
  const opts = el('div', { class: 'form' }, [
    field('Knoptekst', input(p.template.buttonLabel, (v) => { p.template.buttonLabel = v; save(); })),
    field('Accentkleur', input(p.template.accentColor, (v) => { p.template.accentColor = v; save(); }, 'color')),
    field('Logo/branding tonen (groeiloop, Starter)', toggle(p.branding.showBranding, (v) => { p.branding.showBranding = v; save(); })),
    field('Sticky CTA op mobiel', toggle(p.template.mobileStickyCta, (v) => { p.template.mobileStickyCta = v; save(); })),
  ]);
  const node = stepScaffold('Template', 'Kies de layout. Preview en live gebruiken dezelfde engine.', el('div', {}, [cards, opts]));
  host._rerender = () => stepTemplate(host, ctx);
  mount(host, node);
}

// ============================================================================
// STEP: SCENE / WEERGAVE  (environment, lighting, auto-rotate — contract v2)
// ============================================================================
function stepScene(host, ctx) {
  const p = ctx.project; const library = store.getLibrary();
  if (!p.scene) p.scene = { environment: 'studio', exposure: 1.02, environmentIntensity: 1, background: 'studio', autoRotate: false };
  const stage = el('div', { class: 'edit-stage' });
  const panel = el('aside', { class: 'inspector' });
  mount(host, el('div', { class: 'builder-3col edit' }, [el('div', { class: 'col-stage' }, [stage]), panel]));

  const engine = new ConfiguratorEngine(); session.engine = engine;
  engine.mount(stage, buildBuilderConfig(p, library), { mode: 'live' }).catch((e) => { console.error(e); toast('Kon model niet laden'); });
  const save = debounce(ctx.save, 350);

  const envBtns = el('div', { class: 'seg' }, ENVIRONMENTS.map((e) =>
    el('button', { class: 'seg-btn' + (p.scene.environment === e.id ? ' on' : ''), onclick: (ev) => {
      p.scene.environment = e.id; engine.setEnvironmentPreset(e.id); save();
      [...envBtns.children].forEach((b) => b.classList.remove('on')); ev.currentTarget.classList.add('on');
    }, title: e.hint, text: e.name })));

  panel.appendChild(el('div', {}, [
    el('div', { class: 'insp-eyebrow', text: 'Weergave' }),
    el('div', { class: 'insp-title', html: 'Sfeer & belichting<small>zelfde engine als live</small>' }),
    el('div', { class: 'flabel', text: 'Omgeving' }), envBtns,
    el('div', { class: 'flabel', text: 'Achtergrond' }),
    select(BACKGROUNDS.map((b) => b.id), p.scene.background, (v) => { p.scene.background = v; engine.setBackground(v); save(); }),
    sceneSlider('Belichting', p.scene.exposure, 0.6, 1.6, (v) => { p.scene.exposure = v; engine.setExposure(v); save(); }),
    sceneSlider('Reflectie', p.scene.environmentIntensity, 0, 2, (v) => { p.scene.environmentIntensity = v; engine.setEnvIntensity(v); save(); }),
    el('div', { class: 'srow', style: 'margin-top:18px' }, [
      el('div', {}, [el('div', { class: 'srow-k', text: 'Automatisch draaien' }), el('div', { class: 'srow-sub', text: 'Langzame showroom-rotatie' })]),
      (() => { const b = el('button', { class: 'switch' + (p.scene.autoRotate ? ' on' : '') }); b.addEventListener('click', () => { p.scene.autoRotate = !p.scene.autoRotate; b.classList.toggle('on', p.scene.autoRotate); engine.setAutoRotate(p.scene.autoRotate); save(); }); return b; })(),
    ]),
  ]));
  session.cleanup.push(() => { if (engine) engine.dispose(); });
}
function sceneSlider(label, value, min, max, onInput) {
  const out = el('span', { class: 'slider-val mono', text: Number(value).toFixed(2) });
  const input = el('input', { type: 'range', class: 'slider', min: String(min), max: String(max), step: '0.01', value: String(value), oninput: (e) => { const v = parseFloat(e.target.value); out.textContent = v.toFixed(2); onInput(v); } });
  return el('label', { class: 'field', style: 'margin-top:14px' }, [el('span', { class: 'field-label slider-label' }, [document.createTextNode(label), out]), input]);
}


// ============================================================================
// STEP: AI STUDIO  (mock/skeleton provider layer; never publishes directly)
// ============================================================================
function stepAi(host, ctx) {
  renderProjectAiStudio(host, ctx.project.id, { embedded: true });
}

// ============================================================================
// STEP: PREVIEW  (device toggle, live runtime, same engine)
// ============================================================================
function stepPreview(host, ctx) {
  const p = ctx.project; const library = store.getLibrary();
  let device = 'desktop';
  const cfg = buildBuilderConfig(p, library);

  const frame = el('div', { class: 'preview-frame' });
  let controller = null;
  function renderDevice() {
    if (controller) controller.dispose();
    frame.className = 'preview-frame ' + (device === 'mobile' ? 'is-mobile' : 'is-desktop');
    const inner = el('div', { class: 'preview-inner' });
    mount(frame, device === 'mobile' ? el('div', { class: 'phone' }, [el('div', { class: 'phone-screen' }, [inner])]) : inner);
    controller = renderRuntime(inner, cfg, { layout: device, onAddToCart: (sel, total) => toast('Toegevoegd · ' + euro(total, p.currency)) });
    session.engine = controller.engine;
  }
  const toggle = el('div', { class: 'devtoggle' }, [
    el('button', { class: 'active', onclick: (e) => { device = 'desktop'; setActive(e); renderDevice(); }, text: 'Desktop' }),
    el('button', { onclick: (e) => { device = 'mobile'; setActive(e); renderDevice(); }, text: 'Mobiel' }),
  ]);
  function setActive(e) { [...toggle.children].forEach((b) => b.classList.remove('active')); e.target.classList.add('active'); }

  mount(host, el('div', { class: 'preview-step' }, [
    el('div', { class: 'preview-bar' }, [el('div', { class: 'preview-note', text: 'Dit is exact wat je klant ziet — dezelfde engine als live.' }), toggle]),
    frame,
  ]));
  renderDevice();
  session.cleanup.push(() => { if (controller) controller.dispose(); });
}

// ============================================================================
// STEP: PUBLISH
// ============================================================================
function stepPublish(host, ctx) {
  const p = ctx.project; const { checks, passed } = publishChecks(p);
  const list = el('div', { class: 'publish-list' }, checks.map((c) => el('div', { class: 'chk ' + (c.ok ? 'pass' : 'fail') }, [
    el('span', { class: 'chk-ic', text: c.ok ? '✓' : '!' }),
    el('span', { class: 'chk-msg' }, [el('b', { text: c.label }), c.sub ? el('small', { text: c.sub }) : null]),
  ])));
  const cta = el('button', { class: 'btn dark full', style: passed ? '' : 'opacity:.5', onclick: async () => {
    if (!passed) { toast('Los eerst de rode punten op'); return; }
    p.status = 'live'; await store.saveProject(p); toast('Gepubliceerd'); renderBuilder(document.getElementById('app'), p.id, 'publish');
  }, text: passed ? 'Publiceer configurator' : 'Nog niet publiceerbaar' });
  const embed = el('div', { class: 'embed-box' }, [
    el('div', { class: 'flabel', text: 'Embed (iframe)' }),
    el('pre', { class: 'code', text: `<iframe src="https://app.jouwdomein.nl/embed/${p.id}" style="width:100%;border:0;min-height:720px" loading="lazy"></iframe>` }),
  ]);
  const rc = buildRuntimeConfig(p, store.getLibrary());
  const jsonPre = el('pre', { class: 'code json-code', text: JSON.stringify(rc, null, 2) });
  const jsonBox = el('details', { class: 'json-box' }, [
    el('summary', { text: 'RuntimeConfig (API-vorm — dit levert je backend later terug)' }),
    el('button', { class: 'btn tiny', style: 'margin:10px 0', onclick: () => { navigator.clipboard?.writeText(JSON.stringify(rc, null, 2)); toast('JSON gekopieerd'); }, text: 'Kopieer JSON' }),
    jsonPre,
  ]);
  mount(host, stepScaffold('Publiceren', 'Controle vóór livegang.', el('div', {}, [list, cta, embed, jsonBox])));
}

// ============================================================================
// shared UI atoms
// ============================================================================
function stepScaffold(title, sub, body) {
  return el('div', { class: 'step-scaffold' }, [
    el('div', { class: 'step-head' }, [el('h2', { class: 'step-title', text: title }), el('p', { class: 'step-sub', text: sub })]),
    body,
  ]);
}
function field(label, control) { return el('label', { class: 'field' }, [el('span', { class: 'field-label', text: label }), control]); }
function row(children) { return el('div', { class: 'field-row' }, children); }
function input(value, onInput, type = 'text', placeholder = '') {
  return el('input', { class: 'inp', type, value, placeholder, oninput: (e) => onInput(e.target.value) });
}
function labeledInput(label, value, onInput, type, cls) {
  return el('label', { class: 'mini-field ' + (cls || '') }, [el('span', { text: label }), input(value, onInput, type)]);
}
function select(options, value, onChange) {
  return el('select', { class: 'inp', onchange: (e) => onChange(e.target.value) }, options.map((o) => el('option', { value: o, text: o, selected: o === value })));
}
function toggle(value, onChange) {
  const b = el('button', { class: 'switch' + (value ? ' on' : ''), type: 'button' });
  b.addEventListener('click', () => { value = !value; b.classList.toggle('on', value); onChange(value); });
  return b;
}

// Build a RuntimeConfig from a project for the builder engine (inline, no store dep on schema import cycle).
function buildBuilderConfig(project, library) {
  const libById = new Map(library.map((f) => [f.id, f]));
  return {
    project: { id: project.id, name: project.name, basePrice: project.basePrice, currency: project.currency, language: project.language },
    model: project.model, template: project.template, branding: project.branding,
    scene: project.scene || { environment: 'studio', exposure: 1.02, environmentIntensity: 1, background: 'studio', autoRotate: false },
    surfaces: project.surfaces.map((s) => ({
      id: s.id, slot: s.slot, name: s.name, configurable: s.configurable, defaultOptionId: s.defaultOptionId,
      options: s.options.map((o) => { const f = libById.get(o.finishId) || {}; return { id: o.id, name: f.name || 'Afwerking', delta: o.delta || 0, sku: o.sku, shopifyVariantId: o.shopifyVariantId,
        material: { kind: f.kind, colorHex: f.colorHex, roughness: f.roughness, metalness: f.metalness, envIntensity: f.envIntensity, grainHex: f.grainHex, textureUrl: f.textureUrl } }; }),
    })),
  };
}
