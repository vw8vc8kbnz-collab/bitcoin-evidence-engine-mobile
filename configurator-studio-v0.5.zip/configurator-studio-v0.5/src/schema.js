// ============================================================================
// DATA MODEL  —  the scalable contract layer.
//
// Two persisted entities:
//   - Finish (account-level library, reusable across projects)
//   - Project (a configurator being built)
//
// One derived, read-only entity:
//   - RuntimeConfig  (what the 3D engine + live runtime consume)
//
// The engine and live runtime NEVER read Project directly — only RuntimeConfig.
// That seam is what lets the live/embed endpoint later be served by an API that
// strips secrets, exactly like the spec's "clean runtime" rule.
// ============================================================================

import { uid } from './util.js';

/**
 * @typedef {Object} Finish        Account-level material definition (reusable).
 * @property {string} id
 * @property {string} name
 * @property {'solid'|'wood'|'marble'|'metal'} kind
 * @property {string} colorHex
 * @property {number} roughness
 * @property {number} metalness
 * @property {number} envIntensity
 * @property {string} grainHex      // for procedural wood/marble hint
 * @property {string} [textureUrl]  // optional real texture (KTX2/jpg) — overrides procedural
 * @property {string} sku
 * @property {number} defaultDelta  // suggested surcharge; overridable per project
 */

/**
 * @typedef {Object} SurfaceOption  A finish assigned to a surface, with project pricing.
 * @property {string} id
 * @property {string} finishId      // -> Finish.id
 * @property {number} delta
 * @property {string} sku
 * @property {string} [shopifyVariantId]  // Route A mapping (addendum A)
 */

/**
 * @typedef {Object} Surface        A configurable material slot of the model.
 * @property {string} id
 * @property {string} slot          // material/mesh slot name in the GLB (or demo slot)
 * @property {string} name          // human name shown to merchant + customer
 * @property {boolean} configurable
 * @property {SurfaceOption[]} options
 * @property {string} defaultOptionId
 */

/**
 * @typedef {Object} Project
 * @property {string} id
 * @property {string} name
 * @property {'draft'|'test'|'live'} status
 * @property {number} basePrice
 * @property {string} currency
 * @property {string} language
 * @property {{source:'demo'|'glb'|'ai_prompt', url?:string, name?:string, prompt?:string, category?:string, provider?:string}} model
 * @property {Surface[]} surfaces
 * @property {{templateId:string, accentColor:string, buttonLabel:string, mobileStickyCta:boolean}} template
 * @property {{showBranding:boolean, label:string, link:string}} branding
 * @property {{productId?:string, shopDomain?:string}} shopify
 * @property {number} updatedAt
 */

export const TEMPLATES = [
  { id: 'product_split', name: 'Product Split', hint: 'Viewer links, opties rechts. De veilige standaard.' },
  { id: 'fullscreen',    name: 'Fullscreen',    hint: 'Grote viewer, opties in een drawer/bottom-sheet.' },
  { id: 'compact',       name: 'Compact',       hint: 'Klein blok voor in een productpagina.' },
];

export function newFinish(partial = {}) {
  return {
    id: uid('fin'), name: 'Nieuwe afwerking', kind: 'solid',
    colorHex: '#cfccc6', roughness: 0.4, metalness: 0, envIntensity: 0.8,
    grainHex: '#8a6234', textureUrl: undefined, sku: '', defaultDelta: 0, ...partial,
  };
}

export function newProject(partial = {}) {
  return {
    id: uid('prj'), name: 'Nieuwe configurator', status: 'draft',
    basePrice: 0, currency: 'EUR', language: 'nl',
    model: { source: 'ai_prompt', prompt: '', category: 'product', provider: 'mock_adapter', reviewed: false },
    surfaces: [],
    template: { templateId: 'product_split', accentColor: '#1b1a17', buttonLabel: 'Voeg toe aan winkelmand', mobileStickyCta: true },
    branding: { showBranding: true, label: 'jouw merk', link: '' },
    scene: { environment: 'studio', exposure: 1.02, environmentIntensity: 1, background: 'studio', autoRotate: false },
    shopify: {},
    updatedAt: Date.now(), ...partial,
  };
}

export const ENVIRONMENTS = [
  { id: 'studio', name: 'Studio', hint: 'Neutraal, warm/koel gesplitst' },
  { id: 'warm', name: 'Warm', hint: 'Gouden showroomlicht' },
  { id: 'cool', name: 'Koel', hint: 'Helder daglicht' },
  { id: 'soft', name: 'Zacht', hint: 'Egaal, weinig contrast' },
];
export const BACKGROUNDS = [
  { id: 'studio', name: 'Studio-verloop' },
  { id: 'light', name: 'Licht' },
  { id: 'dark', name: 'Donker' },
];

let _cfgCounter = Math.floor(Math.random() * 900 + 100);
export function newConfiguration(partial = {}) {
  return {
    id: uid('cfg'), publicCode: 'CFG-' + (++_cfgCounter),
    projectId: '', projectName: '', selection: {}, summary: [],
    total: 0, currency: 'EUR', device: 'desktop', status: 'created',
    shopifyOrderId: undefined, createdAt: Date.now(), ...partial,
  };
}

// Build a human summary + total from a runtime config + selection.
export function summarize(config, selection) {
  const summary = []; let total = config.project.basePrice || 0;
  for (const s of config.surfaces) {
    if (!s.configurable) continue;
    const o = s.options.find((x) => x.id === (selection[s.id] || s.defaultOptionId));
    if (!o) continue;
    total += o.delta || 0;
    summary.push({ surface: s.name, option: o.name, delta: o.delta || 0, sku: o.sku || '', variantId: o.shopifyVariantId || '' });
  }
  return { summary, total };
}

// --- pricing -----------------------------------------------------------------
// NB: client-side price is for UX only. The real total MUST be revalidated
// server-side / mapped to a Shopify variant before checkout (addendum A §1.5).
export function priceFor(project, selection /* {surfaceId: optionId} */) {
  let total = project.basePrice || 0;
  for (const s of project.surfaces) {
    if (!s.configurable) continue;
    const optId = selection?.[s.id] || s.defaultOptionId;
    const opt = s.options.find((o) => o.id === optId);
    if (opt) total += opt.delta || 0;
  }
  return total;
}

export function defaultSelection(project) {
  const sel = {};
  for (const s of project.surfaces) sel[s.id] = s.defaultOptionId || s.options[0]?.id;
  return sel;
}

// --- runtime config (derived) ------------------------------------------------
// Resolve library finishes into concrete material specs. This is the object the
// engine renders from and the live/embed API would return.
export function buildRuntimeConfig(project, library) {
  const libById = new Map(library.map((f) => [f.id, f]));
  const materialSpec = (fin) => ({
    kind: fin.kind, colorHex: fin.colorHex, roughness: fin.roughness,
    metalness: fin.metalness, envIntensity: fin.envIntensity,
    grainHex: fin.grainHex, textureUrl: fin.textureUrl,
  });
  return {
    project: {
      id: project.id, name: project.name, basePrice: project.basePrice,
      currency: project.currency, language: project.language,
    },
    model: project.model,
    template: project.template,
    branding: project.branding,
    scene: project.scene || { environment: 'studio', exposure: 1.02, environmentIntensity: 1, background: 'studio', autoRotate: false },
    surfaces: project.surfaces.map((s) => ({
      id: s.id, slot: s.slot, name: s.name, configurable: s.configurable,
      defaultOptionId: s.defaultOptionId,
      options: s.options.map((o) => {
        const fin = libById.get(o.finishId) || {};
        return { id: o.id, name: fin.name || 'Afwerking', delta: o.delta || 0, sku: o.sku, shopifyVariantId: o.shopifyVariantId, material: materialSpec(fin) };
      }),
    })),
  };
}

// --- publish checks ----------------------------------------------------------
export function publishChecks(project) {
  const cfgSurfaces = project.surfaces.filter((s) => s.configurable);
  const checks = [
    { key: 'name', label: 'Projectnaam ingesteld', ok: !!project.name?.trim() },
    { key: 'model', label: '3D-model geladen', ok: !!project.model && !!project.surfaces.length,
      sub: project.model?.source === 'glb' ? (project.model.name || 'GLB') : project.model?.source === 'ai_prompt' ? 'AI-prompt model' : project.model?.source === 'ai_images' ? 'AI-foto model' : 'AI/import model' },
    { key: 'cfg', label: 'Minstens één aanpasbaar vlak', ok: cfgSurfaces.length > 0 },
    { key: 'opts', label: 'Elk aanpasbaar vlak heeft opties',
      ok: cfgSurfaces.every((s) => s.options.length > 0) },
    { key: 'defaults', label: 'Standaardafwerking per vlak',
      ok: cfgSurfaces.every((s) => s.defaultOptionId && s.options.some((o) => o.id === s.defaultOptionId)) },
    { key: 'price', label: 'Basisprijs ingesteld', ok: (project.basePrice || 0) > 0 },
    { key: 'asset_review', label: 'AI/foto-output gereviewd', ok: !['ai_prompt','ai_images'].includes(project.model?.source) || !!project.model?.reviewed,
      sub: ['ai_prompt','ai_images'].includes(project.model?.source) ? 'AI-output moet handmatig worden goedgekeurd vóór livegang' : '' },
    { key: 'shopify', label: 'Shopify-product gekoppeld', ok: !!project.shopify?.productId,
      sub: project.shopify?.productId ? project.shopify.productId : 'Koppel om SKU’s naar varianten te mappen' },
  ];
  return { checks, passed: checks.every((c) => c.ok) };
}
