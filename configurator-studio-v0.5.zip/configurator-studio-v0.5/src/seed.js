// Seed data so the app is useful the first time it opens.
import { newFinish, newProject } from './schema.js';
import { uid } from './util.js';

export function seedLibrary() {
  return [
    newFinish({ id: 'fin_hpl_white',  name: 'HPL Wit',           kind: 'solid',  colorHex: '#f2f0ec', roughness: 0.34, metalness: 0, envIntensity: 0.8, sku: 'HPL-100', defaultDelta: 0 }),
    newFinish({ id: 'fin_hpl_grey',   name: 'HPL Lichtgrijs',    kind: 'solid',  colorHex: '#cfccc6', roughness: 0.34, metalness: 0, envIntensity: 0.8, sku: 'HPL-120', defaultDelta: 0 }),
    newFinish({ id: 'fin_hpl_anthra', name: 'HPL Antraciet',     kind: 'solid',  colorHex: '#33322f', roughness: 0.32, metalness: 0, envIntensity: 0.85, sku: 'HPL-220', defaultDelta: 15 }),
    newFinish({ id: 'fin_hpl_black',  name: 'HPL Zwart',         kind: 'solid',  colorHex: '#1a1917', roughness: 0.30, metalness: 0, envIntensity: 0.9, sku: 'HPL-240', defaultDelta: 15 }),
    newFinish({ id: 'fin_hpl_oak',    name: 'HPL Eiken-decor',   kind: 'wood',   colorHex: '#b98f57', roughness: 0.40, metalness: 0, envIntensity: 0.6, grainHex: '#7a5a30', sku: 'HPL-310', defaultDelta: 25 }),
    newFinish({ id: 'fin_hpl_marble', name: 'HPL Marmer-decor',  kind: 'marble', colorHex: '#edeae3', roughness: 0.22, metalness: 0, envIntensity: 1.1, grainHex: '#9a958c', sku: 'HPL-330', defaultDelta: 35 }),
    newFinish({ id: 'fin_birch_nat',  name: 'Berken naturel',    kind: 'wood',   colorHex: '#d9c39a', roughness: 0.60, metalness: 0, envIntensity: 0.5, grainHex: '#b59b6a', sku: 'BRK-001', defaultDelta: 0 }),
    newFinish({ id: 'fin_birch_white',name: 'Berken wit geolied',kind: 'wood',   colorHex: '#e8e0d0', roughness: 0.62, metalness: 0, envIntensity: 0.45, grainHex: '#cdbfa0', sku: 'BRK-010', defaultDelta: 10 }),
    newFinish({ id: 'fin_oak_nat',    name: 'Naturel eiken',     kind: 'wood',   colorHex: '#c69b63', roughness: 0.62, metalness: 0, envIntensity: 0.5, grainHex: '#8a6234', sku: 'OAK-001', defaultDelta: 0 }),
    newFinish({ id: 'fin_walnut',     name: 'Donker walnoot',    kind: 'wood',   colorHex: '#5a3a22', roughness: 0.55, metalness: 0, envIntensity: 0.55, grainHex: '#2f1c0f', sku: 'WAL-001', defaultDelta: 80 }),
    newFinish({ id: 'fin_steel_black',name: 'Staal mat zwart',   kind: 'metal',  colorHex: '#1d1d1d', roughness: 0.5, metalness: 0.55, envIntensity: 0.9, sku: 'ST-BLK', defaultDelta: 0 }),
    newFinish({ id: 'fin_steel_white',name: 'Staal wit',         kind: 'metal',  colorHex: '#eceae5', roughness: 0.38, metalness: 0.15, envIntensity: 0.85, sku: 'ST-WHT', defaultDelta: 20 }),
    newFinish({ id: 'fin_steel_champ',name: 'Staal champagne',   kind: 'metal',  colorHex: '#c6a671', roughness: 0.3, metalness: 0.9, envIntensity: 1.1, sku: 'ST-CHM', defaultDelta: 60 }),
  ];
}

function opt(finishId, delta, sku) { return { id: uid('opt'), finishId, delta, sku }; }

export function seedProjects(/* library */) {
  // v0.5: no visible legacy demo-table projects. Seed only AI-created examples so
  // the product starts from the intended AI Product Studio flow.
  const seat = { id: 'srf_ai_seat', slot: 'ai_seat', name: 'Zitting', configurable: true,
    options: [opt('fin_hpl_white', 0, 'AI-FAB-01'), opt('fin_hpl_grey', 35, 'AI-FAB-02'), opt('fin_hpl_anthra', 55, 'AI-FAB-03')], defaultOptionId: '' };
  seat.defaultOptionId = seat.options[0].id;
  const back = { id: 'srf_ai_back', slot: 'ai_back', name: 'Rugleuning', configurable: true,
    options: [opt('fin_oak_nat', 0, 'AI-WOOD-01'), opt('fin_walnut', 80, 'AI-WOOD-02'), opt('fin_hpl_black', 45, 'AI-WOOD-03')], defaultOptionId: '' };
  back.defaultOptionId = back.options[0].id;
  const frame = { id: 'srf_ai_frame', slot: 'ai_frame', name: 'Frame', configurable: true,
    options: [opt('fin_steel_black', 0, 'AI-MET-01'), opt('fin_steel_white', 20, 'AI-MET-02'), opt('fin_steel_champ', 60, 'AI-MET-03')], defaultOptionId: '' };
  frame.defaultOptionId = frame.options[0].id;

  const p1 = newProject({
    id: 'prj_ai_lounge_chair',
    name: 'AI Studio · Lounge stoel',
    status: 'draft',
    basePrice: 429,
    model: {
      source: 'ai_prompt',
      prompt: 'Premium lounge stoel met houten rug, zachte beige zitting en mat zwart metalen frame',
      category: 'chair',
      provider: 'mock_adapter',
      generatedAt: new Date().toISOString(),
      reviewed: false,
      inputMode: 'prompt_only',
      note: 'AI-prompt voorbeeld: review onderdelen, materiaalzones en mobile preview vóór publicatie.'
    },
    surfaces: [seat, back, frame],
    scene: { environment: 'studio', exposure: 1.05, environmentIntensity: 1.05, background: 'studio', autoRotate: true },
  });

  return [p1];
}
