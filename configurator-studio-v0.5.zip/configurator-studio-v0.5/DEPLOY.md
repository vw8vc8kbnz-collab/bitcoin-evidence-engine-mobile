# Deploy — Configurator Studio v0.5

Upload `configurator-studio-v0.5.zip` naar de GitHub repo en draai daarna in Termius:

```bash
cd ~/apps/bitcoin-evidence-engine-mobile && git pull && \
rm -rf configurator-studio-v0.5 && unzip -o configurator-studio-v0.5.zip && \
cd configurator-studio-v0.5 && bash deploy/deploy-9999.sh && \
curl -I http://127.0.0.1:9999/ && \
curl -I http://127.0.0.1:9999/src/app.js?v=0.5 && \
echo "KLAAR — http://51.195.102.180:9999/"
```

Als nginx niet start omdat poort 9999 bezet is:

```bash
sudo systemctl stop configurator 2>/dev/null || true
sudo systemctl disable configurator 2>/dev/null || true
sudo fuser -k 9999/tcp 2>/dev/null || true
sudo nginx -t && sudo systemctl restart nginx
```
