# Handover — Configurator Studio v0.5

## Productrichting

De app is nu volledig omgezet naar een AI-first create/import flow. De gebruiker start niet meer vanuit een demo-tafel, maar vanuit één slimme AI Product Studio.

De gebruiker kan in één composer combineren:

1. Prompt: beschrijf het product en wat configureerbaar moet worden.
2. Productfoto’s: 1–4 beelden als basis voor image-to-3D/multi-image-to-3D.
3. Bestaand 3D-model: GLB/GLTF import, met prompt-context voor productbegrip en material-zone mapping.

De AI-output wordt nooit direct live gezet. De vaste flow is:

`prompt + foto’s + 3D import → AI provider → normalizer → configurator-ready checker → desktop/mobile preview → publish-check → live`

## UX wijzigingen

- Serif/magazine typography is visueel vervangen door een moderne sans-serif SaaS-stijl.
- Dashboard hero is strakker en compacter.
- Losse prompt/foto routes zijn vervangen door één smart composer.
- 3D-import staat op dezelfde plek als prompt en foto’s.
- Projecten tonen alleen AI/import projecten in de hoofdflow.
- Reviewkaart toont producttype, zones, configureerbare onderdelen en mobile score.
- Mobile header gebruikt tabs in plaats van rommelige grote knoppen.

## Technische staat

Nog steeds statisch vanilla JS + Three.js via CDN. Geen Next.js/Supabase/Shopify productie-SaaS. De code is bedoeld als UX/product prototype.

Belangrijkste bestanden:

- `src/builder.js` — dashboard met v0.5 smart composer.
- `src/ai.js` — mock AI provider layer, nieuwe `createSmartAiProduct` flow.
- `src/seed.js` — geen legacy demo-tafel als visible seed; alleen AI-created voorbeeld.
- `styles/app.css` — v0.5 design overrides.
- `deploy/deploy-9999.sh` — nginx deploy op poort 9999.

## Volgende stap

Maak hierna een echte Next.js/Supabase basis met server-side AI job queue. Daarna pas echte providers koppelen:

- text + image(s) → 3D model
- GLB/GLTF → part detection/material zones
- material generation
- web optimization
- publish-check
