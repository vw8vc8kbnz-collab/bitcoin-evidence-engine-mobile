# Outrun OS v1.3.5 — Debug Center + Health Check

## Doel van deze build
Deze build lost het probleem op dat je op de iPhone niet goed ziet of een taak echt draait, stil faalt of klaar is. De tool krijgt nu een harde diagnostics-laag.

## Nieuw
- `/health` endpoint toegevoegd voor Termius/curl checks.
- `/api/debug` endpoint toegevoegd met service, database, jobs, laatste bedrijven en configuratie.
- Developer Dashboard knop in de UI.
- Actieve jobs, laatste jobs, databasegrootte en tabellen zichtbaar op iPhone.
- Beter zichtbaar of `master vullen 10k`, `basic analyse` of `deep search` echt gestart is.
- Version bump naar `1.3.5-debug-center`.

## Belangrijk
- Worker blijft standaard uit.
- AI wordt niet automatisch 24/7 gebruikt.
- Master vullen en basic analyse blijven lokale taken zonder AI-kosten.
- Database en `data/` moeten bij updates behouden blijven.

## Checks
Gebruik:
```bash
curl -s http://127.0.0.1:8700/health
curl -s http://127.0.0.1:8700/api/debug
curl -s http://127.0.0.1:8700/api/jobs
```

## UI
Open op iPhone:
```text
http://51.195.102.180:8700/
```
Klik bovenin op **Debug**.
