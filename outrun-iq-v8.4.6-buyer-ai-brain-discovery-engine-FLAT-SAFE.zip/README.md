# Outrun IQ v8.4.6

Flat safe deployment build. Deze versie introduceert de kopergerichte Outrun AI Brain voor Home, AI Vinder, zoeken/discovery en productdetail.
