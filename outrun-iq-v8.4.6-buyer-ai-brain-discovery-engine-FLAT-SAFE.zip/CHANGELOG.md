# v8.4.6 — Buyer AI Brain & Discovery Engine

- Centrale buyer AI scoring toegevoegd voor deal-score, trust, prijs, urgentie, personalisatie en Promote-blending.
- Home uitgebreid met Outrun AI Brain hero en AI-gedreven sectielogica.
- Zoeken vervangen door AI Discovery-ranking met sorteringen AI beste, waarde, prijs, korting en nieuw.
- AI Vinder 2.0 koppelt nu aan dezelfde centrale buyer ranking-engine.
- Productdetail toont AI Brain uitleg, score-meters en koopadvies.
- Promote blijft subtiel: betaalde zichtbaarheid is begrensd en kan relevantie niet overschrijven.
