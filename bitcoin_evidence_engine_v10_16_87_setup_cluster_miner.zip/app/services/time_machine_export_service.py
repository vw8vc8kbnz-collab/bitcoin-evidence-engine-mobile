from __future__ import annotations

import csv
import json
import zipfile
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from app.core.config import settings
from app.core.debug import append_jsonl
from app.db.database import db
from app.services.adaptive_learning_service import AdaptiveLearningService
from app.services.session_log_service import SessionLogService


def _safe_json(obj: Any) -> Any:
    try:
        import math
        if obj is None or isinstance(obj, (str, bool, int)):
            return obj
        if isinstance(obj, float):
            return obj if math.isfinite(obj) else None
        if isinstance(obj, dict):
            return {str(k): _safe_json(v) for k, v in obj.items()}
        if isinstance(obj, (list, tuple)):
            return [_safe_json(v) for v in obj]
        if hasattr(obj, 'item'):
            return _safe_json(obj.item())
        if hasattr(obj, 'isoformat'):
            return obj.isoformat()
    except Exception:
        pass
    return str(obj)


class TimeMachineExportService:
    """Persistent Time Machine evidence exports.

    Random100/Random1000 should be analyzable later exactly like the local debug
    folders. This service stores the raw native items, summary, and relevant DB
    rows under the shared data directory, so exports survive new ZIP versions.
    """

    ROOT = settings.data_dir / "time_machine_exports"

    def __init__(self) -> None:
        self.root = self.ROOT
        self.root.mkdir(parents=True, exist_ok=True)

    def _safe_unlink_tree(self, path: Path) -> int:
        """Delete a file/folder and return an approximate deleted count."""
        try:
            if not path.exists():
                return 0
            if path.is_dir():
                shutil.rmtree(path, ignore_errors=True)
                return 1
            path.unlink(missing_ok=True)
            return 1
        except Exception as exc:
            append_jsonl("time_machine_cleanup_audit.jsonl", {"event":"cleanup_delete_failed_v101674", "path":str(path), "error":str(exc)[:500]})
            return 0

    def disk_status(self) -> dict:
        """Small VPS disk-space snapshot for the mobile UI and audits."""
        try:
            usage = shutil.disk_usage(settings.data_dir)
            free_gb = round(usage.free / (1024**3), 2)
            total_gb = round(usage.total / (1024**3), 2)
            used_gb = round(usage.used / (1024**3), 2)
            used_pct = round((usage.used / usage.total) * 100, 1) if usage.total else None
            return {"ok": True, "data_dir": str(settings.data_dir), "total_gb": total_gb, "used_gb": used_gb, "free_gb": free_gb, "used_pct": used_pct, "warning": bool(free_gb < 10 or (used_pct is not None and used_pct > 85))}
        except Exception as exc:
            return {"ok": False, "error": str(exc)[:500], "data_dir": str(settings.data_dir)}

    def cleanup_archive(self, *, keep_latest: int = 1, prune_logs_days: int = 7, prune_tmp_hours: int = 24, reason: str = "manual") -> dict:
        """Keep the VPS clean without touching raw candles/warehouse/adaptive learning.

        v10.16.74: Time Machine exports are large. Keep only the newest N ZIPs
        and their matching batch folders. Remove orphan batch folders, tmp ZIPs,
        stale status files and old debug/session exports. Persistent market data
        in settings.data_dir/bitcoin_evidence_engine.duckdb is never removed.
        """
        import time
        now = time.time()
        deleted = {"zips":0, "batch_dirs":0, "tmp":0, "logs":0, "debug_exports":0, "releases_hint":0}
        before = self.disk_status()
        keep_latest = max(0, int(keep_latest))
        try:
            self.root.mkdir(parents=True, exist_ok=True)
            zips = sorted(self.root.glob("*.zip"), key=lambda q: q.stat().st_mtime if q.exists() else 0, reverse=True)
            keep_ids = {z.stem for z in zips[:keep_latest]}
            for z in zips[keep_latest:]:
                deleted["zips"] += self._safe_unlink_tree(z)
            for d in list(self.root.iterdir()):
                if d.name == "latest_random_export.json":
                    continue
                if d.is_dir() and d.name not in keep_ids:
                    deleted["batch_dirs"] += self._safe_unlink_tree(d)
                elif d.is_file() and (d.suffix in (".tmp", ".part") or d.name.endswith(".zip.tmp")):
                    deleted["tmp"] += self._safe_unlink_tree(d)
            # If no latest is kept, clear pointer. If pointer references a removed batch, repair to newest kept ZIP.
            latest_ptr = self.root / "latest_random_export.json"
            if keep_latest == 0 or not zips[:keep_latest]:
                latest_ptr.unlink(missing_ok=True)
            elif keep_ids:
                try:
                    info = json.loads(latest_ptr.read_text(encoding="utf-8")) if latest_ptr.exists() else {}
                    if str(info.get("batch_id") or "") not in keep_ids:
                        z = zips[0]
                        latest_ptr.write_text(json.dumps({"exists": True, "batch_id": z.stem, "path": str(z), "download_url": f"/api/time-machine/export/download?batch_id={z.stem}", "repaired_by":"v10.16.74_cleanup"}, ensure_ascii=False, indent=2), encoding="utf-8")
                except Exception:
                    pass
            # Prune generated debug/session export zips/txt logs outside the core DB.
            cutoff_logs = now - max(1, prune_logs_days) * 86400
            for folder in [settings.data_dir / "debug_exports", settings.data_dir / "session_logs"]:
                try:
                    if folder.exists():
                        for f in folder.rglob("*"):
                            if f.is_file() and f.stat().st_mtime < cutoff_logs:
                                key = "debug_exports" if "debug" in folder.name else "logs"
                                deleted[key] += self._safe_unlink_tree(f)
                except Exception as exc:
                    append_jsonl("time_machine_cleanup_audit.jsonl", {"event":"cleanup_logs_failed_v101674", "folder":str(folder), "error":str(exc)[:500]})
            # Prune temp files in the TM export root older than N hours.
            cutoff_tmp = now - max(1, prune_tmp_hours) * 3600
            try:
                for f in self.root.rglob("*"):
                    if f.is_file() and (f.suffix in (".tmp", ".part") or f.name.endswith(".zip.tmp")) and f.stat().st_mtime < cutoff_tmp:
                        deleted["tmp"] += self._safe_unlink_tree(f)
            except Exception:
                pass
        except Exception as exc:
            append_jsonl("time_machine_cleanup_audit.jsonl", {"event":"cleanup_archive_failed_v101674", "reason":reason, "error":str(exc)[:1000]})
            return {"ok": False, "reason": reason, "error": str(exc)[:1000], "before": before, "after": self.disk_status(), "deleted": deleted}
        after = self.disk_status()
        payload = {"ok": True, "reason": reason, "keep_latest": keep_latest, "deleted": deleted, "before": before, "after": after, "root": str(self.root)}
        append_jsonl("time_machine_cleanup_audit.jsonl", {"event":"cleanup_archive_complete_v101674", **payload})
        return _safe_json(payload)

    def _evidence_data_status(self) -> dict:
        """Snapshot of what evidence data is truly present in the DB.

        Included in every Time Machine ZIP so audits can distinguish real
        external history from proxy/model placeholders.
        """
        metrics = [
            ("Binance Spot candles", "raw_candles", "binance", "BTCUSDT 1h OHLCV", "core_price"),
            ("Binance Futures funding", "raw_metric_points", "binance_futures", "funding_rate", "futures"),
            ("Binance Futures open interest", "raw_metric_points", "binance_futures", "open_interest_value", "futures"),
            ("Long/Short ratio", "raw_metric_points", "binance_futures", "long_short_ratio", "futures"),
            ("Top position L/S", "raw_metric_points", "binance_futures", "top_position_long_short_ratio", "futures"),
            ("Top account L/S", "raw_metric_points", "binance_futures", "top_account_long_short_ratio", "futures"),
            ("Taker buy/sell ratio", "raw_metric_points", "binance_futures", "taker_buy_sell_ratio", "orderflow"),
            ("Taker delta", "raw_metric_points", "binance_futures", "taker_delta_ratio", "orderflow"),
            ("Futures basis/premium", "raw_metric_points", "binance_futures", "futures_basis_premium_pct", "futures"),
            ("Composite orderbook", "raw_metric_points", "composite_orderbook", "orderbook_imbalance", "orderbook"),
            ("Fear & Greed", "raw_metric_points", "alternative_me", "fear_greed", "sentiment"),
            ("Coinbase premium", "raw_metric_points", "spot_composite", "spot_premium_coinbase_pct", "cross_exchange"),
            ("Kraken premium", "raw_metric_points", "spot_composite", "spot_premium_kraken_pct", "cross_exchange"),
            ("Coinbase hourly close", "raw_metric_points", "coinbase_history", "btc_close", "cross_exchange"),
            ("Kraken hourly close", "raw_metric_points", "kraken_history", "btc_close", "cross_exchange"),
            ("CoinMetrics MVRV", "raw_metric_points", "coinmetrics_community", "CapMVRVCur", "onchain"),
        ]
        rows=[]
        for label, table, source, metric, group in metrics:
            try:
                if table == "raw_candles":
                    r = db.fetchone("SELECT COUNT(*), MIN(open_time), MAX(open_time) FROM raw_candles WHERE source='binance' AND symbol=? AND interval='1h'", [settings.symbol])
                else:
                    r = db.fetchone("SELECT COUNT(*), MIN(timestamp_ms), MAX(timestamp_ms) FROM raw_metric_points WHERE source=? AND metric=?", [source, metric])
                count = int(r[0] or 0) if r else 0
                min_ms = int(r[1]) if r and r[1] is not None else None
                max_ms = int(r[2]) if r and r[2] is not None else None
            except Exception:
                count, min_ms, max_ms = 0, None, None
            status = "active" if count >= 1000 else ("partial" if count > 0 else "missing")
            rows.append({"label":label,"source":source,"metric":metric,"group":group,"rows":count,"min_ms":min_ms,"max_ms":max_ms,"status":status})
        return {"rows": rows, "summary": {"active": sum(1 for r in rows if r['status']=='active'), "partial": sum(1 for r in rows if r['status']=='partial'), "missing": sum(1 for r in rows if r['status']=='missing'), "total": len(rows)}}

    def _write_evidence_status_files(self, d: Path) -> None:
        status = self._evidence_data_status()
        (d / "evidence_data_status.json").write_text(json.dumps(_safe_json(status), ensure_ascii=False, indent=2), encoding="utf-8")
        with (d / "evidence_data_status.csv").open("w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=["label","source","metric","group","rows","min_ms","max_ms","status"])
            w.writeheader(); w.writerows(status.get("rows", []))
        (d / "EVIDENCE_DATA_README.txt").write_text(
            "Deze export bevat per datasource hoeveel echte historische rijen beschikbaar zijn.\n"
            "Status active = 1000+ rijen, partial = enkele rijen, missing = geen historische data.\n"
            "Modellen met ontbrekende datasource mogen alleen proxy/laag gewicht gebruiken.\n"
            "Forecast en Time Machine horen dezelfde state-vector/data te gebruiken.\n",
            encoding="utf-8"
        )

    def _batch_dir(self, batch_id: str) -> Path:
        safe = ''.join(ch for ch in str(batch_id) if ch.isalnum() or ch in ('-', '_'))[:80] or 'batch'
        d = self.root / safe
        d.mkdir(parents=True, exist_ok=True)
        return d


    def _write_entry_trade_analytics(self, d: Path, batch_id: str) -> None:
        """Write trader-facing entry/target/invalidation analytics for a Time Machine batch.

        v10.16.77: Stijn asked not just whether the model was directionally right,
        but what the historical entry price was, what the win/target price was,
        what invalidation was used and whether the setup would actually have had
        positive expectancy. These files make that auditable per horizon.
        """
        try:
            import math
            import pandas as pd
            frame = db.df("""
                SELECT
                    test_item_id, batch_id, cutoff_iso, cutoff_ms, horizon,
                    start_price AS entry_price,
                    expected_price AS target_price,
                    invalidation_price,
                    actual_price, actual_high, actual_low,
                    bullish_probability, bearish_probability,
                    expected_move_pct, confidence,
                    actual_move_pct, direction_correct,
                    target_touched, target_reached, partial_reached,
                    invalidated, outcome_tier, total_score,
                    CASE WHEN expected_price >= start_price THEN 'LONG' ELSE 'SHORT' END AS side,
                    ABS(expected_price - start_price) AS target_distance_usd,
                    CASE WHEN start_price IS NOT NULL AND start_price != 0 THEN ABS((expected_price - start_price) / start_price) * 100 ELSE NULL END AS target_distance_pct,
                    ABS(invalidation_price - start_price) AS invalidation_distance_usd,
                    CASE WHEN start_price IS NOT NULL AND start_price != 0 THEN ABS((invalidation_price - start_price) / start_price) * 100 ELSE NULL END AS invalidation_distance_pct,
                    CASE WHEN expected_price >= start_price THEN actual_high ELSE actual_low END AS best_price_seen,
                    CASE WHEN expected_price >= start_price THEN actual_low ELSE actual_high END AS worst_price_seen
                FROM time_machine_tests
                WHERE batch_id=?
                ORDER BY horizon, cutoff_ms
            """, [batch_id])
            if frame is None or frame.empty:
                (d / "entry_trade_analytics.error.txt").write_text("No time_machine_tests rows found for batch_id=" + str(batch_id), encoding="utf-8")
                return

            # Normalize booleans that may come back as strings/ints depending on DB driver.
            def as_bool(x):
                if isinstance(x, bool): return x
                if x is None: return False
                if isinstance(x, (int, float)): return bool(x)
                return str(x).strip().lower() in ("1", "true", "yes", "y", "win", "partial")
            for col in ["direction_correct", "target_touched", "target_reached", "partial_reached", "invalidated"]:
                if col in frame.columns:
                    frame[col] = frame[col].map(as_bool)

            # Trader-facing outcome math. The Time Machine is not yet a full bar-by-bar
            # execution simulator, but these fields show entry, target/win price,
            # invalidation and realized horizon exit in a consistent way.
            def _signed_pct(row, price_col):
                entry = row.get("entry_price")
                px = row.get(price_col)
                side = row.get("side")
                try:
                    if entry is None or float(entry) == 0 or px is None:
                        return None
                    raw = (float(px) - float(entry)) / float(entry) * 100.0
                    return raw if side == "LONG" else -raw
                except Exception:
                    return None
            frame["target_gain_pct_if_hit"] = frame.apply(lambda r: _signed_pct(r, "target_price"), axis=1)
            frame["invalidation_loss_pct_if_hit"] = frame.apply(lambda r: _signed_pct(r, "invalidation_price"), axis=1)
            frame["horizon_exit_pct"] = frame.apply(lambda r: _signed_pct(r, "actual_price"), axis=1)
            frame["best_excursion_pct"] = frame.apply(lambda r: _signed_pct(r, "best_price_seen"), axis=1)
            frame["worst_excursion_pct"] = frame.apply(lambda r: _signed_pct(r, "worst_price_seen"), axis=1)

            def _rr(row):
                try:
                    risk = abs(float(row.get("invalidation_loss_pct_if_hit") or 0))
                    reward = abs(float(row.get("target_gain_pct_if_hit") or 0))
                    return reward / risk if risk > 0 else None
                except Exception:
                    return None
            frame["planned_rr"] = frame.apply(_rr, axis=1)

            def _trade_return(row):
                try:
                    if as_bool(row.get("target_reached")):
                        return float(row.get("target_gain_pct_if_hit") or 0)
                    if as_bool(row.get("invalidated")):
                        return -abs(float(row.get("invalidation_loss_pct_if_hit") or 0))
                    # If neither level was touched, mark-to-horizon. This lets us see
                    # whether entries were early/late even without target hit.
                    return float(row.get("horizon_exit_pct") or 0)
                except Exception:
                    return None
            frame["simulated_trade_return_pct"] = frame.apply(_trade_return, axis=1)
            frame["win_price"] = frame["target_price"]
            frame["loss_price"] = frame["invalidation_price"]
            frame["entry_to_win_usd"] = (frame["target_price"] - frame["entry_price"]).abs()
            frame["entry_to_loss_usd"] = (frame["invalidation_price"] - frame["entry_price"]).abs()

            # Full compact rows for all tests, optimized for spreadsheet/audit use.
            detail_cols = [
                "cutoff_iso", "horizon", "side", "entry_price", "win_price", "loss_price",
                "target_gain_pct_if_hit", "invalidation_loss_pct_if_hit", "planned_rr",
                "actual_price", "actual_high", "actual_low", "horizon_exit_pct",
                "best_excursion_pct", "worst_excursion_pct", "simulated_trade_return_pct",
                "direction_correct", "target_reached", "partial_reached", "invalidated",
                "outcome_tier", "confidence", "total_score", "bullish_probability", "bearish_probability",
                "expected_move_pct", "test_item_id"
            ]
            existing_cols = [c for c in detail_cols if c in frame.columns]
            frame[existing_cols].to_csv(d / "entry_trade_details_batch.csv", index=False)

            rows = []
            for horizon, g in frame.groupby("horizon", dropna=False):
                n = int(len(g))
                returns = g["simulated_trade_return_pct"].dropna()
                wins = returns[returns > 0]
                losses = returns[returns < 0]
                gross_win = float(wins.sum()) if len(wins) else 0.0
                gross_loss = float(abs(losses.sum())) if len(losses) else 0.0
                # Simple equity curve from sequential historical samples. It is not
                # position sizing advice; it is an expectancy diagnostic.
                equity = 100.0
                peak = 100.0
                max_dd = 0.0
                for r in returns.fillna(0).clip(lower=-50, upper=50):
                    equity *= (1.0 + float(r) / 100.0)
                    peak = max(peak, equity)
                    if peak > 0:
                        max_dd = min(max_dd, (equity - peak) / peak * 100.0)
                rows.append({
                    "horizon": horizon,
                    "trades": n,
                    "long_trades": int((g["side"] == "LONG").sum()),
                    "short_trades": int((g["side"] == "SHORT").sum()),
                    "direction_hitrate_pct": round(float(g["direction_correct"].mean() * 100.0), 3) if n else None,
                    "target_hitrate_pct": round(float(g["target_reached"].mean() * 100.0), 3) if n else None,
                    "partial_or_target_pct": round(float((g["target_reached"] | g["partial_reached"]).mean() * 100.0), 3) if n else None,
                    "avg_planned_rr": round(float(g["planned_rr"].dropna().mean()), 4) if len(g["planned_rr"].dropna()) else None,
                    "avg_win_pct": round(float(wins.mean()), 4) if len(wins) else None,
                    "avg_loss_pct": round(float(losses.mean()), 4) if len(losses) else None,
                    "gross_win_pct": round(gross_win, 4),
                    "gross_loss_pct": round(gross_loss, 4),
                    "profit_factor": round(gross_win / gross_loss, 4) if gross_loss > 0 else None,
                    "expectancy_pct_per_trade": round(float(returns.mean()), 5) if len(returns) else None,
                    "median_trade_return_pct": round(float(returns.median()), 5) if len(returns) else None,
                    "sim_equity_start": 100.0,
                    "sim_equity_end": round(float(equity), 4),
                    "sim_return_pct": round(float(equity - 100.0), 4),
                    "sim_max_drawdown_pct": round(float(max_dd), 4),
                    "avg_entry_to_target_pct": round(float(g["target_distance_pct"].dropna().mean()), 4) if "target_distance_pct" in g else None,
                    "avg_entry_to_invalidation_pct": round(float(g["invalidation_distance_pct"].dropna().mean()), 4) if "invalidation_distance_pct" in g else None,
                    "avg_best_excursion_pct": round(float(g["best_excursion_pct"].dropna().mean()), 4) if len(g["best_excursion_pct"].dropna()) else None,
                    "avg_worst_excursion_pct": round(float(g["worst_excursion_pct"].dropna().mean()), 4) if len(g["worst_excursion_pct"].dropna()) else None,
                })
            by_h = pd.DataFrame(rows)
            # Keep the expected horizon order where possible.
            order = {h: i for i, h in enumerate(settings.horizons)}
            by_h["_order"] = by_h["horizon"].map(lambda h: order.get(str(h), 999))
            by_h = by_h.sort_values(["_order", "horizon"]).drop(columns=["_order"])
            by_h.to_csv(d / "entry_trade_analytics_by_horizon.csv", index=False)

            # Useful examples: best/worst 1h entries and all high-confidence 1h rows.
            one_h = frame[frame["horizon"].astype(str) == "1h"].copy()
            if not one_h.empty:
                one_h.sort_values("simulated_trade_return_pct", ascending=False)[existing_cols].head(75).to_csv(d / "entry_examples_1h_best_wins.csv", index=False)
                one_h.sort_values("simulated_trade_return_pct", ascending=True)[existing_cols].head(75).to_csv(d / "entry_examples_1h_worst_losses.csv", index=False)
                one_h.sort_values(["confidence", "total_score"], ascending=False)[existing_cols].head(100).to_csv(d / "entry_examples_1h_high_confidence.csv", index=False)

            analytics = {
                "ok": True,
                "version": "v10.16.77_entry_trade_analytics",
                "batch_id": batch_id,
                "generated_at": datetime.now(timezone.utc).isoformat(),
                "meaning": {
                    "entry_price": "historical start_price at forecast cutoff",
                    "win_price": "target_price / expected_price used by Time Machine",
                    "loss_price": "invalidation_price used by Time Machine",
                    "simulated_trade_return_pct": "target gain if target hit, invalidation loss if invalidated, otherwise mark-to-horizon actual exit",
                    "profit_factor": "gross simulated winning pct divided by absolute gross simulated losing pct",
                    "sim_equity_end": "diagnostic compounding from 100 using simulated_trade_return_pct; not trading advice"
                },
                "by_horizon": by_h.to_dict(orient="records"),
                "files": [
                    "entry_trade_analytics_by_horizon.csv",
                    "entry_trade_details_batch.csv",
                    "entry_examples_1h_best_wins.csv",
                    "entry_examples_1h_worst_losses.csv",
                    "entry_examples_1h_high_confidence.csv"
                ]
            }
            (d / "entry_trade_analytics.json").write_text(json.dumps(_safe_json(analytics), ensure_ascii=False, indent=2), encoding="utf-8")
            append_jsonl("time_machine_entry_analytics_audit.jsonl", {"event": "entry_trade_analytics_written_v101677", "batch_id": batch_id, "rows": int(len(frame))})
        except Exception as exc:
            append_jsonl("time_machine_entry_analytics_audit.jsonl", {"event": "entry_trade_analytics_failed_v101677", "batch_id": batch_id, "error": str(exc)[:1000]})
            try:
                (d / "entry_trade_analytics.error.txt").write_text(str(exc), encoding="utf-8")
            except Exception:
                pass


    def _write_trade_setup_selector_analytics(self, d: Path, batch_id: str, items: list[dict]) -> None:
        """v10.16.79: strict LONG/SHORT/NO_TRADE analytics from the unified selector.

        NO TRADE is first-class.  The export records whether no-trade was
        correct because no valid RR/target/edge occurred, or wrong because a
        valid target-before-stop setup existed.  These files are the main audit
        for the new Trade Setup Selector.
        """
        try:
            import pandas as pd
            if not items:
                return
            rows=[]
            for it in items:
                _ctx_json = it.get('setup_context_json') or {}
                _ctx = (_ctx_json.get('context') if isinstance(_ctx_json, dict) else {}) or {}
                _tags = it.get('setup_specialist_tags') or []
                try:
                    _tag_text = ';'.join(str(x) for x in _tags)
                except Exception:
                    _tag_text = str(_tags)
                rows.append({
                    'cutoff_iso': it.get('cutoff_iso'), 'cutoff_ms': it.get('cutoff_ms'), 'horizon': it.get('horizon'),
                    'action': it.get('setup_action') or it.get('trade_action'), 'candidate_side': it.get('setup_side_candidate'),
                    'entry_price': it.get('start_price'), 'target_price': it.get('setup_target_price'),
                    'invalidation_price': it.get('setup_invalidation_price'), 'rr': it.get('setup_rr'),
                    'market_potential_usd': it.get('market_potential_usd'), 'market_potential_pct': it.get('market_potential_pct'),
                    'target_distance_usd': it.get('setup_target_distance_usd'), 'stop_distance_usd': it.get('setup_invalidation_distance_usd'),
                    'expected_value_pct': it.get('setup_expected_value_pct'), 'setup_quality': it.get('setup_quality'),
                    'direction_edge': it.get('setup_direction_edge'), 'magnitude_edge': it.get('setup_magnitude_edge'),
                    'trade_quality': it.get('setup_trade_quality'), 'strictness_bucket': it.get('setup_strictness_bucket'),
                    'master_regime': it.get('setup_master_regime'),
                    'confidence': it.get('confidence'), 'actual_price': it.get('actual_price'), 'actual_high': it.get('actual_high'), 'actual_low': it.get('actual_low'),
                    'setup_target_hit': it.get('setup_target_hit'), 'setup_stop_hit': it.get('setup_stop_hit'),
                    'setup_return_pct': it.get('setup_return_pct'), 'setup_outcome': it.get('setup_outcome'),
                    'setup_return_pct_v2': it.get('setup_return_pct_v2'), 'setup_outcome_v2': it.get('setup_outcome_v2'), 'setup_eval_method_v2': it.get('setup_eval_method_v2'),
                    'setup_valid_trade_existed_v2': it.get('setup_valid_trade_existed_v2'), 'no_trade_correct_v2': it.get('no_trade_correct_v2'),
                    'no_trade': it.get('no_trade'), 'no_trade_correct': it.get('no_trade_correct'),
                    'valid_trade_existed': it.get('setup_valid_trade_existed'), 'mfe_usd': it.get('setup_mfe_usd'), 'mae_usd': it.get('setup_mae_usd'),
                    'reason': it.get('setup_reason'), 'regime_bucket': it.get('setup_regime_bucket'),
                    'rr_target_dynamic': it.get('setup_rr_target_dynamic'), 'effective_confidence': it.get('setup_effective_confidence'),
                    'confidence_bucket': it.get('setup_confidence_bucket'), 'confidence_filter_pass_52': it.get('setup_confidence_filter_pass_52'), 'confidence_filter_pass_55': it.get('setup_confidence_filter_pass_55'),
                    'alert_candidate': it.get('alert_candidate'), 'alert_level': it.get('alert_level'), 'alert_quality_score': it.get('alert_quality_score'),
                    'alert_reason': it.get('alert_reason'), 'alert_failed_gates': it.get('alert_failed_gates'),
                    'specialist_tags': _tag_text,
                    'fear_greed': _ctx.get('fear_greed'), 'rsi_14': _ctx.get('rsi_14'),
                    'return_1': _ctx.get('return_1'), 'return_4': _ctx.get('return_4'), 'return_24': _ctx.get('return_24'),
                    'range_pct': _ctx.get('range_pct'), 'volatility_24': _ctx.get('volatility_24'),
                    'volume_zscore': _ctx.get('volume_zscore'), 'volume_ratio_24': _ctx.get('volume_ratio_24'),
                    'drawdown_from_ath': _ctx.get('drawdown_from_ath'), 'funding_rate': _ctx.get('funding_rate'),
                    'spot_premium_coinbase_pct': _ctx.get('spot_premium_coinbase_pct'),
                    'coinbase_premium_change_4h': _ctx.get('coinbase_premium_change_4h')
                })
            df=pd.DataFrame(rows)
            df.to_csv(d / 'trade_setup_selector_details.csv', index=False)
            out=[]
            for h,g in df.groupby('horizon', dropna=False):
                n=len(g)
                trade_g=g[g['action'].isin(['LONG','SHORT'])]
                nt_g=g[g['action'].astype(str)=='NO_TRADE']
                returns=pd.to_numeric(trade_g.get('setup_return_pct'), errors='coerce').dropna() if len(trade_g) else pd.Series(dtype=float)
                returns_v2=pd.to_numeric(trade_g.get('setup_return_pct_v2'), errors='coerce').dropna() if len(trade_g) and 'setup_return_pct_v2' in trade_g.columns else pd.Series(dtype=float)
                wins=returns[returns>0]; losses=returns[returns<0]
                gross_win=float(wins.sum()) if len(wins) else 0.0
                gross_loss=float(abs(losses.sum())) if len(losses) else 0.0
                wins_v2=returns_v2[returns_v2>0]; losses_v2=returns_v2[returns_v2<0]
                gross_win_v2=float(wins_v2.sum()) if len(wins_v2) else 0.0
                gross_loss_v2=float(abs(losses_v2.sum())) if len(losses_v2) else 0.0
                out.append({
                    'horizon': h, 'rows': int(n), 'trade_setups': int(len(trade_g)), 'no_trade_setups': int(len(nt_g)),
                    'no_trade_pct': round(float(len(nt_g)/n*100.0),3) if n else None,
                    'no_trade_correct_pct': round(float(pd.to_numeric(nt_g.get('no_trade_correct'), errors='coerce').mean()*100.0),3) if len(nt_g) else None,
                    'long_setups': int((trade_g['action']=='LONG').sum()) if len(trade_g) else 0,
                    'short_setups': int((trade_g['action']=='SHORT').sum()) if len(trade_g) else 0,
                    'target_hit_pct': round(float(pd.to_numeric(trade_g.get('setup_target_hit'), errors='coerce').mean()*100.0),3) if len(trade_g) else None,
                    'stop_hit_pct': round(float(pd.to_numeric(trade_g.get('setup_stop_hit'), errors='coerce').mean()*100.0),3) if len(trade_g) else None,
                    'avg_rr': round(float(pd.to_numeric(trade_g.get('rr'), errors='coerce').mean()),4) if len(trade_g) else None,
                    'avg_direction_edge': round(float(pd.to_numeric(g.get('direction_edge'), errors='coerce').mean()),3) if 'direction_edge' in g.columns else None,
                    'avg_magnitude_edge': round(float(pd.to_numeric(g.get('magnitude_edge'), errors='coerce').mean()),3) if 'magnitude_edge' in g.columns else None,
                    'avg_trade_quality': round(float(pd.to_numeric(g.get('trade_quality'), errors='coerce').mean()),3) if 'trade_quality' in g.columns else None,
                    'strictness_mix': '; '.join(g.get('strictness_bucket').astype(str).value_counts().head(5).index.tolist()) if 'strictness_bucket' in g.columns else None,
                    'avg_market_potential_usd': round(float(pd.to_numeric(g.get('market_potential_usd'), errors='coerce').mean()),2) if n else None,
                    'avg_target_distance_usd': round(float(pd.to_numeric(trade_g.get('target_distance_usd'), errors='coerce').mean()),2) if len(trade_g) else None,
                    'avg_stop_distance_usd': round(float(pd.to_numeric(trade_g.get('stop_distance_usd'), errors='coerce').mean()),2) if len(trade_g) else None,
                    'profit_factor': round(gross_win/gross_loss,4) if gross_loss>0 else None,
                    'expectancy_pct_per_trade': round(float(returns.mean()),5) if len(returns) else None,
                    'profit_factor_v2': round(gross_win_v2/gross_loss_v2,4) if gross_loss_v2>0 else None,
                    'expectancy_pct_per_trade_v2': round(float(returns_v2.mean()),5) if len(returns_v2) else None,
                    'v2_winrate_pct': round(float((returns_v2>0).mean()*100.0),3) if len(returns_v2) else None,
                    'ambiguous_legacy_both_hit_pct': round(float(pd.to_numeric(trade_g.get('setup_both_hit_ambiguous'), errors='coerce').mean()*100.0),3) if len(trade_g) else None,
                    'v2_eval_method_mix': '; '.join(trade_g.get('setup_eval_method_v2').astype(str).value_counts().head(4).index.tolist()) if len(trade_g) and 'setup_eval_method_v2' in trade_g.columns else None,
                    'alert_candidates': int(pd.to_numeric(trade_g.get('alert_candidate'), errors='coerce').fillna(0).astype(bool).sum()) if len(trade_g) and 'alert_candidate' in trade_g.columns else 0,
                    'alert_candidate_pct_of_trades': round(float(pd.to_numeric(trade_g.get('alert_candidate'), errors='coerce').fillna(0).astype(bool).mean()*100.0),3) if len(trade_g) and 'alert_candidate' in trade_g.columns else None,
                    'alert_winrate_v2_pct': round(float((pd.to_numeric(trade_g[pd.to_numeric(trade_g.get('alert_candidate'), errors='coerce').fillna(0).astype(bool)].get('setup_return_pct_v2'), errors='coerce').dropna()>0).mean()*100.0),3) if len(trade_g) and 'alert_candidate' in trade_g.columns and len(trade_g[pd.to_numeric(trade_g.get('alert_candidate'), errors='coerce').fillna(0).astype(bool)]) else None,
                    'alert_expectancy_v2_pct': round(float(pd.to_numeric(trade_g[pd.to_numeric(trade_g.get('alert_candidate'), errors='coerce').fillna(0).astype(bool)].get('setup_return_pct_v2'), errors='coerce').dropna().mean()),5) if len(trade_g) and 'alert_candidate' in trade_g.columns and len(trade_g[pd.to_numeric(trade_g.get('alert_candidate'), errors='coerce').fillna(0).astype(bool)]) else None,
                    'alert_level_mix': '; '.join(trade_g.get('alert_level').astype(str).value_counts().head(5).index.tolist()) if len(trade_g) and 'alert_level' in trade_g.columns else None,
                    'estimated_trades_per_week': round(float(len(trade_g) / max(1, n) * (24*7 / {'1h':1,'4h':4,'8h':8,'24h':24,'7d':168,'30d':720,'90d':2160}.get(str(h),24))),3) if n else None,
                    'estimated_trades_per_month': round(float(len(trade_g) / max(1, n) * (24*30 / {'1h':1,'4h':4,'8h':8,'24h':24,'7d':168,'30d':720,'90d':2160}.get(str(h),24))),3) if n else None,
                    'avg_mfe_usd': round(float(pd.to_numeric(trade_g.get('mfe_usd'), errors='coerce').mean()),2) if len(trade_g) else None,
                    'avg_mae_usd': round(float(pd.to_numeric(trade_g.get('mae_usd'), errors='coerce').mean()),2) if len(trade_g) else None,
                    'top_no_trade_reasons': '; '.join(nt_g.get('reason').astype(str).value_counts().head(4).index.tolist()) if len(nt_g) else None,
                    'regime_mix': '; '.join(g.get('regime_bucket').astype(str).value_counts().head(4).index.tolist()) if 'regime_bucket' in g.columns else None,
                })
            summary=pd.DataFrame(out)
            order={h:i for i,h in enumerate(settings.horizons)}
            if not summary.empty:
                summary['_o']=summary['horizon'].map(lambda x: order.get(str(x),999)); summary=summary.sort_values(['_o','horizon']).drop(columns=['_o'])
            summary.to_csv(d / 'trade_setup_selector_by_horizon.csv', index=False)
            # Plain text audit for DeepSeek/text-only review.  Keep it compact
            # but complete enough to audit selector quality without opening CSV/JSON.
            lines=[]
            lines.append('BITCOIN EVIDENCE ENGINE - TIME MACHINE DEEPSEEK AUDIT')
            lines.append('engine_version=v10.16.87_setup_cluster_miner')
            lines.append(f'batch_id={batch_id}')
            lines.append(f'generated_at={datetime.now(timezone.utc).isoformat()}')
            lines.append('')
            lines.append('GOAL')
            lines.append('Use one unified Time Machine + Forecast Trade Setup Selector. v10.16.82 uses a Regime Master Switch and Triple Gate selection: Direction Edge, Magnitude/Market Potential Edge, and Trade Quality/EV Edge. Each horizon can output LONG, SHORT or NO TRADE. NO TRADE is a first-class prediction and is evaluated.')
            lines.append('RR is dynamic around a healthy target instead of rigid 1.5. Trades now require all three gates to pass. The selector intentionally avoids sparse historical premium fields as core input, uses regime-specialist logic, extreme crash reversal clusters, Fear&Greed U-shape context, and stricter transition/noise filtering. NO_TRADE reasons are specific so wrong filtering can be audited.')
            lines.append('')
            lines.append('SUMMARY BY HORIZON')
            if not summary.empty:
                for r in summary.to_dict(orient='records'):
                    lines.append(f"- {r.get('horizon')}: rows={r.get('rows')} trades={r.get('trade_setups')} no_trade={r.get('no_trade_setups')} no_trade_pct={r.get('no_trade_pct')} target_hit_pct={r.get('target_hit_pct')} stop_hit_pct={r.get('stop_hit_pct')} PF={r.get('profit_factor')} EV%={r.get('expectancy_pct_per_trade')} PFv2={r.get('profit_factor_v2')} EVv2%={r.get('expectancy_pct_per_trade_v2')} WRv2={r.get('v2_winrate_pct')} RR={r.get('avg_rr')} dir_edge={r.get('avg_direction_edge')} mag_edge={r.get('avg_magnitude_edge')} quality={r.get('avg_trade_quality')} strictness={r.get('strictness_mix')} est_trades_week={r.get('estimated_trades_per_week')} est_trades_month={r.get('estimated_trades_per_month')}")
            lines.append('')
            lines.append('ALERT QUALITY ENGINE')
            lines.append('v10.16.86 separates forecast from push notifications: forecast still predicts every horizon, but alert_candidate=true only for strict A/A+ setups that would be sent to iPhone/ntfy later. Audit alert_quality_*.csv for historical notification count, winrate, expectancy and regimes.')
            try:
                _alert_count = int(pd.to_numeric(df.get('alert_candidate'), errors='coerce').fillna(0).astype(bool).sum()) if 'alert_candidate' in df.columns else 0
                lines.append(f'notification_alert_candidates={_alert_count}')
            except Exception:
                pass
            lines.append('')
            lines.append('TOP TRADE EXAMPLES')
            sample_df = df[df['action'].isin(['LONG','SHORT'])].copy()
            if not sample_df.empty:
                sample_df['_ret'] = pd.to_numeric(sample_df.get('setup_return_pct_v2') if 'setup_return_pct_v2' in sample_df.columns else sample_df.get('setup_return_pct'), errors='coerce')
                sample_df = sample_df.sort_values('_ret', ascending=False).head(40)
                for _, r in sample_df.iterrows():
                    lines.append(f"{r.get('horizon')} {r.get('action')} entry={r.get('entry_price')} target={r.get('target_price')} stop={r.get('invalidation_price')} RR={r.get('rr')} EV%={r.get('expected_value_pct')} result={r.get('setup_outcome')} return%={r.get('setup_return_pct')} result_v2={r.get('setup_outcome_v2')} return_v2%={r.get('setup_return_pct_v2')} MFE$={r.get('mfe_usd')} MAE$={r.get('mae_usd')}")
            lines.append('')
            lines.append('NO TRADE AUDIT EXAMPLES')
            nt_sample = df[df['action'].astype(str)=='NO_TRADE'].head(60)
            for _, r in nt_sample.iterrows():
                lines.append(f"{r.get('horizon')} NO_TRADE candidate={r.get('candidate_side')} correct={r.get('no_trade_correct')} valid_trade_existed={r.get('valid_trade_existed')} quality={r.get('setup_quality')} confidence={r.get('confidence')} reason={r.get('reason')}")
            lines.append('')
            lines.append('KEY QUESTIONS FOR REVIEW')
            lines.append('1. Are LONG/SHORT winrates high enough after NO TRADE filtering?')
            lines.append('2. Are trade frequencies still practical: multiple setups per week/month when edge exists?')
            lines.append('3. Is profit factor above 1.0 and preferably above 1.3 per active horizon?')
            lines.append('4. Are no-trades mostly correct, or is the selector missing too many valid trades? Which reason codes are wrong most often?')
            lines.append('5. Do target and stop distances look realistic for BTC volatility and horizon?')
            (d / 'time_machine_deepseek_audit.txt').write_text('\n'.join(lines), encoding='utf-8')

            # v10.16.84: confidence bucket audit using fair v2 returns.
            try:
                bucket_rows=[]
                trades=df[df['action'].isin(['LONG','SHORT'])].copy()
                if not trades.empty:
                    trades['_conf']=pd.to_numeric(trades.get('effective_confidence'), errors='coerce')
                    trades['_ret_v2']=pd.to_numeric(trades.get('setup_return_pct_v2'), errors='coerce')
                    buckets=[('under_50', -1e9, 50), ('50_52', 50, 52), ('52_55', 52, 55), ('55_plus', 55, 1e9)]
                    for name,lo,hi in buckets:
                        bg=trades[(trades['_conf']>=lo) & (trades['_conf']<hi)]
                        rets=bg['_ret_v2'].dropna()
                        bucket_rows.append({
                            'confidence_bucket': name, 'trades': int(len(bg)),
                            'avg_effective_confidence': round(float(bg['_conf'].mean()),3) if len(bg) else None,
                            'winrate_v2_pct': round(float((rets>0).mean()*100.0),3) if len(rets) else None,
                            'expectancy_v2_pct': round(float(rets.mean()),5) if len(rets) else None,
                            'total_return_v2_pct': round(float(rets.sum()),5) if len(rets) else None,
                        })
                pd.DataFrame(bucket_rows).to_csv(d / 'trade_setup_confidence_buckets_v2.csv', index=False)
            except Exception as _exc:
                append_jsonl('time_machine_trade_setup_audit.jsonl', {'event':'confidence_bucket_v2_failed_v101684','batch_id':batch_id,'error':str(_exc)[:500]})



            # v10.16.86: Alert Quality Engine audit.  Forecast continues to
            # predict every horizon, but iPhone/ntfy alerts should only fire
            # for the strict A/A+ subset.  These files answer: how many
            # historical notifications would have been sent, and how good were
            # those trades?
            try:
                trades = df[df['action'].isin(['LONG','SHORT'])].copy()
                if not trades.empty and 'alert_candidate' in trades.columns:
                    trades['_alert'] = pd.to_numeric(trades.get('alert_candidate'), errors='coerce').fillna(0).astype(bool)
                    trades['_ret_v2'] = pd.to_numeric(trades.get('setup_return_pct_v2'), errors='coerce')
                    trades['_conf'] = pd.to_numeric(trades.get('effective_confidence'), errors='coerce')
                    alerts = trades[trades['_alert']].copy()
                    alerts.to_csv(d / 'alert_quality_details.csv', index=False)

                    def _agg(group, name_key=None, name_val=None):
                        rets = group['_ret_v2'].dropna() if len(group) else pd.Series(dtype=float)
                        wins = rets[rets > 0]; losses = rets[rets < 0]
                        gross_win = float(wins.sum()) if len(wins) else 0.0
                        gross_loss = float(abs(losses.sum())) if len(losses) else 0.0
                        row = {
                            'rows': int(len(group)),
                            'alerts': int(group['_alert'].sum()) if '_alert' in group.columns else int(len(group)),
                            'winrate_v2_pct': round(float((rets > 0).mean()*100.0), 3) if len(rets) else None,
                            'expectancy_v2_pct': round(float(rets.mean()), 5) if len(rets) else None,
                            'total_return_v2_pct': round(float(rets.sum()), 5) if len(rets) else None,
                            'profit_factor_v2': round(gross_win/gross_loss, 4) if gross_loss > 0 else None,
                            'avg_effective_confidence': round(float(group['_conf'].mean()), 3) if len(group) else None,
                            'avg_alert_quality_score': round(float(pd.to_numeric(group.get('alert_quality_score'), errors='coerce').mean()), 3) if len(group) and 'alert_quality_score' in group.columns else None,
                            'level_mix': '; '.join(group.get('alert_level').astype(str).value_counts().head(5).index.tolist()) if len(group) and 'alert_level' in group.columns else None,
                        }
                        if name_key is not None:
                            row[name_key] = name_val
                        return row

                    overall = [_agg(alerts, 'group', 'notification_alerts')]
                    overall.append(_agg(trades, 'group', 'all_trade_setups'))
                    pd.DataFrame(overall).to_csv(d / 'alert_quality_summary.csv', index=False)

                    by_h=[]
                    for h, g2 in alerts.groupby('horizon', dropna=False):
                        by_h.append(_agg(g2, 'horizon', h))
                    pd.DataFrame(by_h).to_csv(d / 'alert_quality_by_horizon.csv', index=False)

                    by_reg=[]
                    for rg, g2 in alerts.groupby('master_regime', dropna=False):
                        by_reg.append(_agg(g2, 'master_regime', rg))
                    pd.DataFrame(by_reg).to_csv(d / 'alert_quality_by_regime.csv', index=False)

                    by_conf=[]
                    buckets=[('under_52', -1e9, 52), ('52_55', 52, 55), ('55_58', 55, 58), ('58_plus', 58, 1e9)]
                    for name,lo,hi in buckets:
                        g2=trades[(trades['_conf']>=lo) & (trades['_conf']<hi)]
                        row=_agg(g2, 'confidence_bucket', name)
                        row['notification_alerts'] = int(g2['_alert'].sum()) if len(g2) else 0
                        row['notification_alert_pct'] = round(float(g2['_alert'].mean()*100.0),3) if len(g2) else None
                        by_conf.append(row)
                    pd.DataFrame(by_conf).to_csv(d / 'alert_quality_by_confidence_bucket.csv', index=False)

                    alert_payload = {
                        'ok': True,
                        'version': 'v10.16.87_setup_cluster_miner',
                        'batch_id': batch_id,
                        'meaning': {
                            'forecast_layer': 'every horizon still predicts LONG/SHORT/NO_TRADE for research/app visibility',
                            'alert_quality_layer': 'only strict A/A+ setups become notification candidates for future ntfy/iPhone push',
                            'alert_candidate': 'historical notification-worthy setup according to confidence, EV, RR, regime and edge gates',
                        },
                        'overall': overall,
                        'by_horizon': by_h,
                        'by_regime': by_reg,
                        'by_confidence_bucket': by_conf,
                    }
                    (d / 'alert_quality_analytics.json').write_text(json.dumps(_safe_json(alert_payload), ensure_ascii=False, indent=2), encoding='utf-8')
                else:
                    pd.DataFrame([]).to_csv(d / 'alert_quality_summary.csv', index=False)
            except Exception as _exc:
                append_jsonl('time_machine_trade_setup_audit.jsonl', {'event':'alert_quality_export_failed_v101686','batch_id':batch_id,'error':str(_exc)[:500]})
                try: (d / 'alert_quality_analytics.error.txt').write_text(str(_exc), encoding='utf-8')
                except Exception: pass

            # v10.16.87: Setup Cluster Miner.
            # Instead of guessing alert thresholds by hand, mine historical setup
            # families from the actual 7000 Random rows.  These exports show which
            # combinations of horizon/regime/flow/confidence/twin quality have
            # positive EV and are candidates for future notification rules.
            try:
                import pandas as pd
                import math as _math
                cm = df.copy()
                cm['is_trade'] = cm['action'].isin(['LONG','SHORT'])
                trades_all = cm[cm['is_trade']].copy()
                # Dedicated, easy-to-find CSV with the actual trade rows including
                # entry/target/stop.  This is what the user can upload directly for
                # trade-level audit.
                trade_cols = [c for c in [
                    'cutoff_iso','cutoff_ms','horizon','action','entry_price','target_price','invalidation_price',
                    'target_distance_usd','stop_distance_usd','rr','effective_confidence','expected_value_pct',
                    'direction_edge','magnitude_edge','trade_quality','alert_candidate','alert_level','alert_quality_score',
                    'setup_return_pct_v2','setup_outcome_v2','setup_eval_method_v2','master_regime','regime_bucket',
                    'specialist_tags','fear_greed','rsi_14','return_1','return_4','return_24','volatility_24','range_pct',
                    'funding_rate','spot_premium_coinbase_pct','coinbase_premium_change_4h','reason'
                ] if c in trades_all.columns]
                trades_all.to_csv(d / 'all_trade_setups_details.csv', index=False, columns=trade_cols if trade_cols else None)

                def _num(series, default=0.0):
                    return pd.to_numeric(series, errors='coerce').fillna(default)

                def _bucket_conf(v):
                    try: v=float(v)
                    except Exception: return 'conf_unknown'
                    if v < 50: return 'conf_lt50'
                    if v < 52: return 'conf_50_52'
                    if v < 55: return 'conf_52_55'
                    if v < 58: return 'conf_55_58'
                    if v < 62: return 'conf_58_62'
                    return 'conf_62_plus'
                def _bucket_coinbase(v):
                    try: v=float(v)
                    except Exception: return 'cb_unknown'
                    if v <= -0.06: return 'coinbase_deep_discount'
                    if v < -0.02: return 'coinbase_discount'
                    if v <= 0.02: return 'coinbase_neutral'
                    if v < 0.06: return 'coinbase_premium'
                    return 'coinbase_strong_premium'
                def _bucket_funding(v):
                    try: v=float(v)
                    except Exception: return 'funding_unknown'
                    if v < -0.0005: return 'funding_negative_extreme'
                    if v < -0.0001: return 'funding_negative'
                    if v <= 0.0003: return 'funding_neutral'
                    if v <= 0.0008: return 'funding_positive'
                    return 'funding_overheated'
                def _bucket_fear(v):
                    try: v=float(v)
                    except Exception: return 'fear_unknown'
                    if v <= 20: return 'extreme_fear'
                    if v < 40: return 'fear_20_40'
                    if v < 60: return 'neutral_40_60'
                    if v < 80: return 'greed_60_80'
                    return 'extreme_greed'
                def _bucket_vol(v):
                    try: v=float(v)
                    except Exception: return 'vol_unknown'
                    if v < 0.35: return 'vol_low'
                    if v < 0.75: return 'vol_normal'
                    if v < 1.35: return 'vol_high'
                    return 'vol_extreme'
                def _bucket_r24(v):
                    try: v=float(v)
                    except Exception: return 'r24_unknown'
                    if v <= -9.2: return 'crash_top1pct'
                    if v < -3.0: return 'dump_large'
                    if v < -0.6: return 'down_moderate'
                    if v <= 0.6: return 'flat'
                    if v < 3.0: return 'up_moderate'
                    if v < 9.5: return 'pump_large'
                    return 'pump_top1pct'

                if not trades_all.empty:
                    trades_all['_ret_v2'] = _num(trades_all.get('setup_return_pct_v2'), default=float('nan'))
                    trades_all['_win_v2'] = trades_all['_ret_v2'] > 0
                    trades_all['_conf_num'] = _num(trades_all.get('effective_confidence'), 50.0)
                    trades_all['_cluster_confidence_bucket'] = trades_all['_conf_num'].map(_bucket_conf)
                    trades_all['_cluster_coinbase_bucket'] = _num(trades_all.get('spot_premium_coinbase_pct'), 0.0).map(_bucket_coinbase)
                    trades_all['_cluster_funding_bucket'] = _num(trades_all.get('funding_rate'), 0.0).map(_bucket_funding)
                    trades_all['_cluster_fear_bucket'] = _num(trades_all.get('fear_greed'), 50.0).map(_bucket_fear)
                    trades_all['_cluster_vol_bucket'] = _num(trades_all.get('volatility_24'), 0.0).map(_bucket_vol)
                    trades_all['_cluster_return24_bucket'] = _num(trades_all.get('return_24'), 0.0).map(_bucket_r24)

                    def _agg_cluster(g, keys):
                        rets = pd.to_numeric(g['_ret_v2'], errors='coerce').dropna()
                        wins = rets[rets > 0]; losses = rets[rets < 0]
                        gross_win = float(wins.sum()) if len(wins) else 0.0
                        gross_loss = float(abs(losses.sum())) if len(losses) else 0.0
                        row = {k: g[k].iloc[0] for k in keys}
                        row.update({
                            'trades': int(len(g)),
                            'wins': int((rets > 0).sum()) if len(rets) else 0,
                            'losses': int((rets < 0).sum()) if len(rets) else 0,
                            'winrate_v2_pct': round(float((rets > 0).mean()*100.0), 3) if len(rets) else None,
                            'expectancy_v2_pct': round(float(rets.mean()), 5) if len(rets) else None,
                            'total_return_v2_pct': round(float(rets.sum()), 5) if len(rets) else None,
                            'profit_factor_v2': round(gross_win/gross_loss, 4) if gross_loss > 0 else (999.0 if gross_win > 0 else None),
                            'avg_confidence': round(float(g['_conf_num'].mean()), 3) if len(g) else None,
                            'avg_alert_quality_score': round(float(pd.to_numeric(g.get('alert_quality_score'), errors='coerce').mean()), 3) if 'alert_quality_score' in g.columns else None,
                            'alerts': int(pd.to_numeric(g.get('alert_candidate'), errors='coerce').fillna(0).astype(bool).sum()) if 'alert_candidate' in g.columns else 0,
                            'avg_rr': round(float(pd.to_numeric(g.get('rr'), errors='coerce').mean()), 4) if 'rr' in g.columns else None,
                            'avg_target_usd': round(float(pd.to_numeric(g.get('target_distance_usd'), errors='coerce').mean()), 2) if 'target_distance_usd' in g.columns else None,
                            'avg_stop_usd': round(float(pd.to_numeric(g.get('stop_distance_usd'), errors='coerce').mean()), 2) if 'stop_distance_usd' in g.columns else None,
                        })
                        # Candidate label for future notification tiers.  This is research output,
                        # not a live trading recommendation.
                        pf = row.get('profit_factor_v2') or 0.0; ev = row.get('expectancy_v2_pct') or 0.0; wr = row.get('winrate_v2_pct') or 0.0; n = row.get('trades') or 0
                        if n >= 25 and pf >= 1.8 and ev > 0.25 and wr >= 58:
                            label = 'push_candidate'
                        elif n >= 12 and pf >= 1.5 and ev > 0.15 and wr >= 55:
                            label = 'watch_candidate'
                        elif n >= 6 and pf >= 2.0 and ev > 0.30 and wr >= 60:
                            label = 'thin_elite_candidate_needs_more_samples'
                        else:
                            label = 'reject_or_needs_more_evidence'
                        row['alert_rule_candidate'] = label
                        return row

                    cluster_sets = [
                        ['horizon','action','master_regime'],
                        ['horizon','action','master_regime','_cluster_confidence_bucket'],
                        ['horizon','action','master_regime','_cluster_coinbase_bucket'],
                        ['horizon','action','master_regime','_cluster_funding_bucket'],
                        ['horizon','action','master_regime','_cluster_fear_bucket'],
                        ['horizon','action','master_regime','_cluster_return24_bucket'],
                        ['horizon','action','master_regime','_cluster_coinbase_bucket','_cluster_funding_bucket'],
                        ['horizon','action','master_regime','_cluster_coinbase_bucket','_cluster_fear_bucket'],
                        ['horizon','action','master_regime','_cluster_confidence_bucket','_cluster_coinbase_bucket'],
                        ['horizon','action','master_regime','_cluster_confidence_bucket','_cluster_fear_bucket'],
                    ]
                    cluster_rows=[]
                    for keys in cluster_sets:
                        use_keys=[k for k in keys if k in trades_all.columns]
                        if len(use_keys) != len(keys):
                            continue
                        for _, g3 in trades_all.groupby(use_keys, dropna=False):
                            if len(g3) >= 3:
                                row=_agg_cluster(g3, use_keys)
                                row['cluster_definition'] = '+'.join(use_keys)
                                cluster_rows.append(row)
                    clusters = pd.DataFrame(cluster_rows)
                    if not clusters.empty:
                        clusters = clusters.sort_values(['alert_rule_candidate','profit_factor_v2','expectancy_v2_pct','trades'], ascending=[True,False,False,False])
                        clusters.to_csv(d / 'setup_cluster_summary.csv', index=False)
                        candidates = clusters[clusters['alert_rule_candidate'].astype(str) != 'reject_or_needs_more_evidence'].copy()
                        candidates.to_csv(d / 'setup_cluster_candidates.csv', index=False)
                        # More readable candidate rules for the future Alert Engine / ntfy scanner.
                        rule_rows=[]
                        for _, r in candidates.iterrows():
                            cond=[]
                            for k in ['horizon','action','master_regime','_cluster_confidence_bucket','_cluster_coinbase_bucket','_cluster_funding_bucket','_cluster_fear_bucket','_cluster_return24_bucket']:
                                if k in r and pd.notna(r[k]): cond.append(f"{k}={r[k]}")
                            rule_rows.append({
                                'candidate_level': r.get('alert_rule_candidate'),
                                'rule': ' AND '.join(cond),
                                'trades': r.get('trades'), 'winrate_v2_pct': r.get('winrate_v2_pct'),
                                'profit_factor_v2': r.get('profit_factor_v2'), 'expectancy_v2_pct': r.get('expectancy_v2_pct'),
                                'avg_confidence': r.get('avg_confidence'), 'avg_alert_quality_score': r.get('avg_alert_quality_score'),
                                'note': 'Research candidate only; require repeated Random runs / more samples before ntfy push rule.'
                            })
                        pd.DataFrame(rule_rows).to_csv(d / 'alert_rule_candidates.csv', index=False)

                        # Trade-level examples for each candidate cluster: best/worst/most confident.
                        ex=[]
                        for _, r in candidates.head(50).iterrows():
                            keys = str(r.get('cluster_definition') or '').split('+')
                            g = trades_all.copy()
                            for k in keys:
                                if k and k in r and k in g.columns:
                                    g = g[g[k].astype(str) == str(r[k])]
                            if g.empty: continue
                            sample = pd.concat([
                                g.sort_values('_ret_v2', ascending=False).head(3),
                                g.sort_values('_ret_v2', ascending=True).head(3),
                                g.sort_values('_conf_num', ascending=False).head(3),
                            ]).drop_duplicates(subset=[c for c in ['cutoff_ms','horizon','action'] if c in g.columns])
                            for _, tr in sample.iterrows():
                                rec={c: tr.get(c) for c in trade_cols if c in tr.index}
                                rec['cluster_rule'] = ' AND '.join([f"{k}={r[k]}" for k in keys if k and k in r and pd.notna(r[k])])
                                rec['cluster_winrate_v2_pct'] = r.get('winrate_v2_pct')
                                rec['cluster_profit_factor_v2'] = r.get('profit_factor_v2')
                                rec['cluster_expectancy_v2_pct'] = r.get('expectancy_v2_pct')
                                ex.append(rec)
                        pd.DataFrame(ex).to_csv(d / 'setup_cluster_trade_examples.csv', index=False)

                        cluster_payload = {
                            'ok': True,
                            'version': 'v10.16.87_setup_cluster_miner',
                            'batch_id': batch_id,
                            'random_seed': (native.get('random_seed') if 'native' in locals() and isinstance(native, dict) else None),
                            'meaning': {
                                'setup_cluster_summary.csv': 'All mined setup families with winrate, PF, expectancy and sample size.',
                                'setup_cluster_candidates.csv': 'Only clusters that passed basic evidence thresholds; still research, not live rules.',
                                'alert_rule_candidates.csv': 'Human-readable candidate rules for future alert/ntfy engine.',
                                'setup_cluster_trade_examples.csv': 'Actual underlying trades for candidate clusters with entry/target/stop/outcome.',
                                'all_trade_setups_details.csv': 'All LONG/SHORT rows in one easy CSV for direct upload/audit.'
                            },
                            'candidate_count': int(len(candidates)),
                            'top_candidates': candidates.head(25).to_dict(orient='records') if not candidates.empty else [],
                        }
                        (d / 'setup_cluster_analytics.json').write_text(json.dumps(_safe_json(cluster_payload), ensure_ascii=False, indent=2), encoding='utf-8')
                    else:
                        pd.DataFrame([]).to_csv(d / 'setup_cluster_summary.csv', index=False)
                        pd.DataFrame([]).to_csv(d / 'setup_cluster_candidates.csv', index=False)
                        pd.DataFrame([]).to_csv(d / 'alert_rule_candidates.csv', index=False)
                        pd.DataFrame([]).to_csv(d / 'setup_cluster_trade_examples.csv', index=False)
                else:
                    pd.DataFrame([]).to_csv(d / 'all_trade_setups_details.csv', index=False)
            except Exception as _exc:
                append_jsonl('time_machine_trade_setup_audit.jsonl', {'event':'setup_cluster_miner_failed_v101687','batch_id':batch_id,'error':str(_exc)[:1000]})
                try: (d / 'setup_cluster_analytics.error.txt').write_text(str(_exc), encoding='utf-8')
                except Exception: pass

            payload={'ok':True,'version':'v10.16.87_setup_cluster_miner','batch_id':batch_id,'generated_at':datetime.now(timezone.utc).isoformat(),'meaning':{'NO_TRADE':'first-class prediction; correct if no valid RR/target setup existed before invalidation/noise','RR':'planned target distance divided by planned stop/invalidation distance, target around 1.3-1.7 depending on horizon/regime','market_potential_usd':'dynamic per-horizon BTC move potential estimated from live/DB range context + model confidence','estimated_trades_per_week':'rough frequency estimate if historical sample density repeats'},'by_horizon':summary.to_dict(orient='records')}
            (d / 'trade_setup_selector_analytics.json').write_text(json.dumps(_safe_json(payload), ensure_ascii=False, indent=2), encoding='utf-8')
            append_jsonl('time_machine_trade_setup_audit.jsonl', {'event':'trade_setup_selector_export_written_v101681','batch_id':batch_id,'rows':len(df)})
        except Exception as exc:
            append_jsonl('time_machine_trade_setup_audit.jsonl', {'event':'trade_setup_selector_export_failed_v101678','batch_id':batch_id,'error':str(exc)[:1000]})
            try: (d / 'trade_setup_selector_analytics.error.txt').write_text(str(exc), encoding='utf-8')
            except Exception: pass

    def write_random_batch(self, *, batch_id: str, count: int, native: dict, items: list[dict], summary: dict, source: str) -> dict:
        import time as _time
        _export_started_ms = int(_time.time()*1000)
        SessionLogService().append('tm_export_write_start', {'batch_id': batch_id, 'count': count, 'items': len(items), 'source': source})
        # v10.16.74: keep VPS storage under control before writing another heavy Random1000 export.
        try:
            self.cleanup_archive(keep_latest=1, prune_logs_days=3, prune_tmp_hours=1, reason="before_new_time_machine_export_v101676_lite")
        except Exception:
            pass
        d = self._batch_dir(batch_id)
        now = datetime.now(timezone.utc).isoformat()
        meta = {
            "ok": True,
            "kind": "time_machine_random_batch",
            "batch_id": batch_id,
            "source": source,
            "requested_count": int(count),
            "item_count": len(items),
            "created_at": now,
            "engine_version": settings.engine_version,
            "data_dir": str(settings.data_dir),
            "db_path": str(settings.db_path),
            "native_elapsed_ms": native.get("elapsed_ms"),
            "native_bridge_elapsed_ms": native.get("native_bridge_elapsed_ms"),
        }
        (d / "manifest.json").write_text(json.dumps(_safe_json(meta), ensure_ascii=False, indent=2), encoding="utf-8")
        (d / "summary.json").write_text(json.dumps(_safe_json(summary), ensure_ascii=False, indent=2), encoding="utf-8")
        (d / "native_result_without_items.json").write_text(json.dumps(_safe_json({k:v for k,v in native.items() if k != 'items'}), ensure_ascii=False, indent=2), encoding="utf-8")
        self._write_evidence_status_files(d)
        # V10.16.76: Random1000 exports used to include full random_items.json and
        # random_items.csv. Together these could exceed 350 MB uncompressed and kept
        # Uvicorn busy even after the Time Machine itself was complete. The database
        # batch CSVs below are the authoritative 7000-row audit. Keep a compact full
        # item CSV plus a small rich JSON sample for debugging, not the huge raw blobs.
        compact_keys = [
            "horizon", "cutoff_ms", "cutoff_iso", "due_at_ms", "start_price",
            "bullish_probability", "bearish_probability", "expected_move_pct", "expected_price",
            "confidence", "evidence_count", "actual_price", "actual_high", "actual_low",
            "actual_move_pct", "direction_correct", "target_touched", "target_reached",
            "partial_reached", "outcome_tier", "invalidated", "target_gap_pct",
            "price_error_pct", "total_score",
            "setup_action", "trade_action", "no_trade", "no_trade_correct",
            "setup_quality", "market_potential_usd", "market_potential_pct",
            "setup_target_price", "setup_target_distance_usd", "setup_invalidation_price",
            "setup_invalidation_distance_usd", "setup_rr", "setup_expected_value_pct",
            "setup_outcome", "setup_target_hit", "setup_stop_hit", "setup_return_pct",
            "setup_outcome_v2", "setup_return_pct_v2", "setup_eval_method_v2", "setup_valid_trade_existed_v2", "no_trade_correct_v2",
            "setup_confidence_bucket", "setup_confidence_filter_pass_52", "setup_confidence_filter_pass_55",
            "alert_candidate", "alert_level", "alert_quality_score", "alert_reason", "alert_failed_gates",
            "setup_mfe_usd", "setup_mae_usd", "setup_valid_trade_existed", "setup_reason",
            "setup_master_regime", "setup_regime_bucket", "setup_effective_confidence", "setup_direction_edge",
            "setup_magnitude_edge", "setup_trade_quality", "setup_specialist_tags"
        ]
        with (d / "random_items_compact.csv").open("w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=compact_keys)
            w.writeheader()
            for item in items:
                w.writerow({k: _safe_json(item.get(k)) for k in compact_keys})
        # Random reproducibility audit: every run should have a fresh seed and a fresh
        # random set of historical cutoffs.  This CSV makes that directly visible.
        try:
            sample_rows = []
            seen = set()
            for item in items:
                key = item.get('cutoff_ms')
                if key in seen:
                    continue
                seen.add(key)
                sample_rows.append({
                    'cutoff_ms': item.get('cutoff_ms'),
                    'cutoff_iso': item.get('cutoff_iso'),
                    'start_price': item.get('start_price'),
                })
            import pandas as _pd
            _pd.DataFrame(sample_rows).sort_values('cutoff_ms').to_csv(d / 'random_sample_cutoffs.csv', index=False)
            (d / 'random_sample_metadata.json').write_text(json.dumps(_safe_json({
                'random_seed': native.get('random_seed') if isinstance(native, dict) else None,
                'random_seed_source': native.get('random_seed_source') if isinstance(native, dict) else None,
                'unique_cutoffs': len(sample_rows),
                'item_rows': len(items),
                'expected_horizons_per_cutoff': 7,
                'note': 'If this seed and the cutoff list change between exports, Random1000 is using fresh random points.'
            }), ensure_ascii=False, indent=2), encoding='utf-8')
        except Exception as exc:
            append_jsonl('time_machine_export_audit.jsonl', {'event':'random_sample_metadata_failed_v101687','batch_id':batch_id,'error':str(exc)[:500]})
        sample_n = min(250, len(items))
        (d / "random_items_sample.json").write_text(json.dumps(_safe_json(items[:sample_n]), ensure_ascii=False, indent=2), encoding="utf-8")
        (d / "EXPORT_SIZE_POLICY.txt").write_text(
            "v10.16.87 setup cluster miner + fair trade evaluation v2 + alert quality engine:\n"
            "- Full raw random_items.json/csv is intentionally not written by default.\n"
            "- Authoritative full audit rows are in time_machine_tests_batch.csv and time_machine_feature_snapshots_batch.csv.\n"
            "- random_items_compact.csv contains all Random1000 rows with the core fields.\n"
            "- random_items_sample.json contains a rich sample for debugging/model inspection.\n"
            "This keeps the VPS responsive and prevents export ZIPs from growing endlessly.\n",
            encoding="utf-8"
        )
        # Snapshot current learning/stat tables where available. V10.16.16:
        # batch-scoped files first, so the ZIP can be analyzed without mixing
        # older Random100/1000 runs. Aggregate files are still included for
        # context, but are explicitly named *_all.csv.
        batch_sql = {
            "time_machine_tests_batch.csv": ("""SELECT *,
                   start_price AS entry_price,
                   expected_price AS target_price,
                   (expected_price - start_price) AS target_distance_usd,
                   CASE WHEN start_price IS NOT NULL AND start_price != 0 THEN ((expected_price - start_price) / start_price) * 100 ELSE NULL END AS target_distance_pct,
                   (invalidation_price - start_price) AS invalidation_distance_usd,
                   CASE WHEN start_price IS NOT NULL AND start_price != 0 THEN ((invalidation_price - start_price) / start_price) * 100 ELSE NULL END AS invalidation_distance_pct_signed,
                   (actual_price - start_price) AS actual_move_usd
                FROM time_machine_tests WHERE batch_id=? ORDER BY cutoff_ms, horizon""", [batch_id]),
            "time_machine_feature_snapshots_batch.csv": ("SELECT * FROM time_machine_feature_snapshots WHERE batch_id=? ORDER BY cutoff_ms, horizon", [batch_id]),
            "evidence_attribution_events_batch.csv": ("SELECT * FROM evidence_attribution_events WHERE batch_id=? ORDER BY cutoff_ms, horizon", [batch_id]),
        }
        try:
            AdaptiveLearningService().rebuild(source_batch_id=batch_id, min_total=20)
        except Exception as exc:
            append_jsonl("adaptive_learning_audit.jsonl", {"event":"export_rebuild_failed_v101636", "batch_id":batch_id, "error":str(exc)})
        aggregate_sql = {
            "time_machine_tests_all_recent.csv": ("""SELECT *,
                   start_price AS entry_price,
                   expected_price AS target_price,
                   (expected_price - start_price) AS target_distance_usd,
                   CASE WHEN start_price IS NOT NULL AND start_price != 0 THEN ((expected_price - start_price) / start_price) * 100 ELSE NULL END AS target_distance_pct,
                   (invalidation_price - start_price) AS invalidation_distance_usd,
                   CASE WHEN start_price IS NOT NULL AND start_price != 0 THEN ((invalidation_price - start_price) / start_price) * 100 ELSE NULL END AS invalidation_distance_pct_signed,
                   (actual_price - start_price) AS actual_move_usd
                FROM time_machine_tests ORDER BY created_at DESC LIMIT 50000""", []),
            "time_machine_feature_snapshots_all_recent.csv": ("SELECT * FROM time_machine_feature_snapshots ORDER BY created_at DESC LIMIT 50000", []),
            "time_machine_signal_scores_all.csv": ("SELECT * FROM time_machine_signal_scores ORDER BY total DESC, hitrate_with_partial DESC LIMIT 50000", []),
            "model_scores.csv": ("SELECT * FROM model_scores ORDER BY horizon, total DESC", []),
            "adaptive_feature_weights.csv": ("SELECT * FROM adaptive_feature_weights ORDER BY sample DESC, quality DESC", []),
            "adaptive_model_weights.csv": ("SELECT * FROM adaptive_model_weights ORDER BY horizon, quality DESC, sample DESC", []),
            "adaptive_regime_weights.csv": ("SELECT * FROM adaptive_regime_weights ORDER BY horizon, quality DESC, sample DESC", []),
            "adaptive_feature_pair_weights.csv": ("SELECT * FROM adaptive_feature_pair_weights ORDER BY quality DESC, edge DESC, sample DESC", []),
            "adaptive_learning_runs.csv": ("SELECT * FROM adaptive_learning_runs ORDER BY created_at DESC LIMIT 50", []),
            "data_health.csv": ("SELECT * FROM data_health ORDER BY source", []),
            "raw_metric_points_recent.csv": ("SELECT * FROM raw_metric_points ORDER BY timestamp_ms DESC LIMIT 20000", []),
            "features_recent_snapshot.csv": ("SELECT * FROM features ORDER BY timestamp_ms DESC LIMIT 10000", []),
        }
        for name, (sql, params) in {**batch_sql, **aggregate_sql}.items():
            try:
                frame = db.df(sql, params) if params else db.df(sql)
                # V10.16.46: if the batch-scoped DB rows are not visible yet for
                # any reason, do not export an empty primary batch file. Fall back
                # to the native random items that were just used for this batch.
                if name == 'time_machine_tests_batch.csv' and getattr(frame, 'empty', False) and items:
                    fallback_keys = sorted({str(k) for item in items for k in item.keys()})
                    with (d / name).open('w', newline='', encoding='utf-8') as fh:
                        w = csv.DictWriter(fh, fieldnames=fallback_keys)
                        w.writeheader()
                        for item in items:
                            row = {}
                            for k in fallback_keys:
                                v = item.get(k)
                                row[k] = json.dumps(_safe_json(v), ensure_ascii=False) if isinstance(v, (dict, list, tuple)) else _safe_json(v)
                            w.writerow(row)
                    continue
                frame.to_csv(d / name, index=False)
            except Exception as exc:
                (d / (name + ".error.txt")).write_text(str(exc), encoding="utf-8")
        # V10.16.79: unified LONG/SHORT/NO_TRADE selector analytics + text audit.
        self._write_trade_setup_selector_analytics(d, batch_id, items)
        # V10.16.77: trader-facing entry / target / invalidation analytics.
        self._write_entry_trade_analytics(d, batch_id)

        # V10.16.46: include full session timing log as TXT so frontend reloads,
        # API polling, native runtime, export and adaptive rebuild can be audited.
        try:
            duration_ms = int(_time.time()*1000) - _export_started_ms
            SessionLogService().append('tm_export_write_complete', {'batch_id': batch_id, 'duration_ms': duration_ms})
            (d / 'session_export_log.txt').write_text(SessionLogService().text(tail_lines=None), encoding='utf-8')
        except Exception as exc:
            (d / 'session_export_log.error.txt').write_text(str(exc), encoding='utf-8')
        zip_path = self._zip_dir(d)
        latest = {**meta, "path": str(zip_path), "download_url": f"/api/time-machine/export/download?batch_id={batch_id}"}
        (self.root / "latest_random_export.json").write_text(json.dumps(_safe_json(latest), ensure_ascii=False, indent=2), encoding="utf-8")
        append_jsonl("time_machine_export_audit.jsonl", {"event":"tm_random_export_written_v101615", **latest})
        try:
            latest["cleanup"] = self.cleanup_archive(keep_latest=1, prune_logs_days=3, prune_tmp_hours=1, reason="after_successful_time_machine_export_keep_latest_only_v101676_lite")
        except Exception as exc:
            latest["cleanup_error"] = str(exc)[:500]
        return latest

    def _zip_dir(self, d: Path) -> Path:
        # V10.16.71: atomic ZIP build + integrity check. The UI previously saw a
        # partly corrupt export once; do not publish/serve the file before the
        # central directory has been written and testzip passes.
        out = d.with_suffix(".zip")
        tmp = out.with_suffix(".zip.tmp")
        if tmp.exists():
            try: tmp.unlink()
            except Exception: pass
        with zipfile.ZipFile(tmp, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
            for p in sorted(d.rglob("*")):
                if p.is_file():
                    zf.write(p, p.relative_to(d.parent))
        with zipfile.ZipFile(tmp, "r") as zf:
            bad = zf.testzip()
            if bad:
                raise RuntimeError(f"Time Machine ZIP integrity check failed at {bad}")
        tmp.replace(out)
        try:
            append_jsonl("time_machine_export_audit.jsonl", {"event":"tm_zip_integrity_ok_v101671", "path":str(out), "size_bytes":out.stat().st_size})
        except Exception:
            pass
        return out

    def latest_info(self) -> dict:
        p = self.root / "latest_random_export.json"
        if p.exists():
            try:
                return json.loads(p.read_text(encoding="utf-8"))
            except Exception:
                pass
        zips = sorted(self.root.glob("*.zip"), key=lambda q: q.stat().st_mtime if q.exists() else 0, reverse=True)
        if not zips:
            return {"exists": False, "root": str(self.root)}
        batch_id = zips[0].stem
        return {"exists": True, "batch_id": batch_id, "path": str(zips[0]), "download_url": f"/api/time-machine/export/download?batch_id={batch_id}"}


    def list_exports(self, limit: int = 25) -> dict:
        """Return recent persistent Time Machine export batches."""
        rows = []
        for z in sorted(self.root.glob("*.zip"), key=lambda q: q.stat().st_mtime if q.exists() else 0, reverse=True)[:max(1, min(int(limit), 100))]:
            batch_id = z.stem
            meta_path = self.root / batch_id / "manifest.json"
            meta = {"batch_id": batch_id, "path": str(z), "download_url": f"/api/time-machine/export/download?batch_id={batch_id}", "size_bytes": z.stat().st_size}
            try:
                if meta_path.exists():
                    meta.update(json.loads(meta_path.read_text(encoding="utf-8")))
            except Exception:
                pass
            rows.append(_safe_json(meta))
        return {"ok": True, "count": len(rows), "rows": rows, "root": str(self.root)}

    def reset_warehouse(self, *, delete_exports: bool = False, reset_learning: bool = False) -> dict:
        """Clear Time Machine learning/test warehouse without touching candles.

        This is intentionally scoped: raw_candles, features, forecasts and sync
        state remain intact. Use it before a clean Random100/Random1000 audit so
        old runs do not mix with the new batch.
        """
        # V10.16.43: default reset means "clear the current Time Machine run state".
        # It must NOT delete persistent market data, forecasts or adaptive learning
        # unless reset_learning=True is explicitly requested.
        tables = [
            "time_machine_tests",
            "time_machine_feature_snapshots",
            "time_machine_signal_scores",
            "evidence_attribution_events",
            "evidence_attribution_stats",
            "time_machine_jobs",
        ]
        if reset_learning:
            tables += [
                "adaptive_feature_weights",
                "adaptive_model_weights",
                "adaptive_regime_weights",
                "adaptive_feature_pair_weights",
                "adaptive_learning_runs",
                "model_scores",
            ]
        before = {}
        after = {}
        for t in tables:
            try:
                before[t] = int(db.fetchone(f"SELECT COUNT(*) FROM {t}")[0] or 0)
                db.execute(f"DELETE FROM {t}")
                after[t] = int(db.fetchone(f"SELECT COUNT(*) FROM {t}")[0] or 0)
            except Exception as exc:
                before[t] = f"error: {exc}"
                after[t] = None
        exports_deleted = 0
        # Always clear the latest pointer on Reset TM. If old ZIPs stay on disk,
        # they remain in the archive list, but Download ZIP will no longer serve
        # a stale previous Random1000 after a reset.
        try:
            (self.root / "latest_random_export.json").unlink(missing_ok=True)
        except Exception:
            pass

        # Clear stale mobile progress markers so a reset cannot keep the UI stuck at
        # an old 35/72/100% job after the warehouse was emptied.
        try:
            db.execute("DELETE FROM sync_state WHERE key IN ('time_machine_current_job','time_machine_last_batch','time_machine_export_ready')")
        except Exception:
            pass
        cleanup_result = None
        # v10.16.74: Reset TM also cleans the heavy archive, but keeps the latest
        # successful ZIP downloadable. Use hard_delete_all_exports only for manual
        # disaster cleanup; normal mobile reset should keep_latest=1.
        try:
            if delete_exports:
                keep_latest = 0 if bool(getattr(self, '_hard_delete_all_exports', False)) else 1
                cleanup_result = self.cleanup_archive(keep_latest=keep_latest, prune_logs_days=7, prune_tmp_hours=1, reason="reset_tm_keep_latest_export")
                exports_deleted = int(sum((cleanup_result.get('deleted') or {}).values())) if isinstance(cleanup_result, dict) else 0
            else:
                cleanup_result = self.cleanup_archive(keep_latest=1, prune_logs_days=7, prune_tmp_hours=1, reason="reset_tm_light_archive_prune")
        except Exception as exc:
            append_jsonl("time_machine_export_audit.jsonl", {"event":"reset_exports_failed_v101674", "error":str(exc)})
        payload = {"ok": True, "reset": "time_machine_warehouse_and_archive_cleanup", "delete_exports": bool(delete_exports), "reset_learning": bool(reset_learning), "exports_deleted": exports_deleted, "cleanup": cleanup_result, "before": before, "after": after, "data_dir": str(settings.data_dir), "db_path": str(settings.db_path)}
        append_jsonl("time_machine_export_audit.jsonl", {"event":"reset_time_machine_warehouse_v101616", **payload})
        return payload


    def _df_to_csv_file(self, path: Path, sql: str, params: list | None = None) -> None:
        try:
            frame = db.df(sql, params or []) if params else db.df(sql)
            frame.to_csv(path, index=False)
        except Exception as exc:
            path.with_suffix(path.suffix + ".error.txt").write_text(str(exc), encoding="utf-8")

    def heal_existing_export(self, batch_id: str | None = None) -> dict:
        """Regenerate learning CSVs for an existing Time Machine export.

        v10.16.37 fixes an important practical issue: users may download the
        latest Random1000 ZIP that was originally written by an older build. The
        DB can already contain time_machine_signal_scores/model_scores, but the
        ZIP's adaptive_feature_weights.csv can still be empty. Before serving an
        export we now rebuild adaptive learning from the current DuckDB warehouse
        and rewrite the learning CSVs into the batch folder, then rezip it.
        """
        info = self.latest_info() if not batch_id else {"batch_id": batch_id}
        bid = str(batch_id or info.get("batch_id") or "").strip()
        if not bid:
            return {"ok": False, "reason": "no_batch_id"}
        d = self._batch_dir(bid)
        if not d.exists():
            return {"ok": False, "reason": "batch_dir_missing", "batch_id": bid}
        try:
            adaptive = AdaptiveLearningService().rebuild(source_batch_id=bid, min_total=20)
        except Exception as exc:
            adaptive = {"ok": False, "error": str(exc)}
            append_jsonl("adaptive_learning_audit.jsonl", {"event":"export_heal_rebuild_failed_v101637", "batch_id":bid, "error":str(exc)})
        # Always rewrite the DB-derived files, even if rebuild failed, so the ZIP
        # reflects current truth instead of stale older CSVs.
        db_files = {
            "time_machine_tests_batch.csv": ("SELECT * FROM time_machine_tests WHERE batch_id=? ORDER BY cutoff_ms, horizon", [bid]),
            "time_machine_feature_snapshots_batch.csv": ("SELECT * FROM time_machine_feature_snapshots WHERE batch_id=? ORDER BY cutoff_ms, horizon", [bid]),
            "evidence_attribution_events_batch.csv": ("SELECT * FROM evidence_attribution_events WHERE batch_id=? ORDER BY cutoff_ms, horizon", [bid]),
            "time_machine_tests_all_recent.csv": ("""SELECT *,
                   start_price AS entry_price,
                   expected_price AS target_price,
                   (expected_price - start_price) AS target_distance_usd,
                   CASE WHEN start_price IS NOT NULL AND start_price != 0 THEN ((expected_price - start_price) / start_price) * 100 ELSE NULL END AS target_distance_pct,
                   (invalidation_price - start_price) AS invalidation_distance_usd,
                   CASE WHEN start_price IS NOT NULL AND start_price != 0 THEN ((invalidation_price - start_price) / start_price) * 100 ELSE NULL END AS invalidation_distance_pct_signed,
                   (actual_price - start_price) AS actual_move_usd
                FROM time_machine_tests ORDER BY created_at DESC LIMIT 50000""", []),
            "time_machine_feature_snapshots_all_recent.csv": ("SELECT * FROM time_machine_feature_snapshots ORDER BY created_at DESC LIMIT 50000", []),
            "time_machine_signal_scores_all.csv": ("SELECT * FROM time_machine_signal_scores ORDER BY total DESC, hitrate_with_partial DESC LIMIT 50000", []),
            "model_scores.csv": ("SELECT * FROM model_scores ORDER BY horizon, total DESC", []),
            "adaptive_feature_weights.csv": ("SELECT * FROM adaptive_feature_weights ORDER BY sample DESC, quality DESC", []),
            "adaptive_model_weights.csv": ("SELECT * FROM adaptive_model_weights ORDER BY horizon, quality DESC, sample DESC", []),
            "adaptive_regime_weights.csv": ("SELECT * FROM adaptive_regime_weights ORDER BY horizon, quality DESC, sample DESC", []),
            "adaptive_feature_pair_weights.csv": ("SELECT * FROM adaptive_feature_pair_weights ORDER BY quality DESC, edge DESC, sample DESC", []),
            "adaptive_learning_runs.csv": ("SELECT * FROM adaptive_learning_runs ORDER BY created_at DESC LIMIT 50", []),
            "data_health.csv": ("SELECT * FROM data_health ORDER BY source", []),
            "raw_metric_points_recent.csv": ("SELECT * FROM raw_metric_points ORDER BY timestamp_ms DESC LIMIT 20000", []),
            "features_recent_snapshot.csv": ("SELECT * FROM features ORDER BY timestamp_ms DESC LIMIT 10000", []),
        }
        for name, (sql, params) in db_files.items():
            self._df_to_csv_file(d / name, sql, params)
        try:
            manifest_path = d / "manifest.json"
            meta = {}
            if manifest_path.exists():
                meta = json.loads(manifest_path.read_text(encoding="utf-8"))
            meta["export_healed_by_version"] = settings.engine_version
            meta["export_healed_at"] = datetime.now(timezone.utc).isoformat()
            meta["adaptive_rebuild"] = _safe_json(adaptive)
            # Keep original_engine_version visible if this folder came from an older run.
            if "original_engine_version" not in meta:
                meta["original_engine_version"] = meta.get("engine_version")
            meta["engine_version"] = settings.engine_version
            manifest_path.write_text(json.dumps(_safe_json(meta), ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as exc:
            append_jsonl("time_machine_export_audit.jsonl", {"event":"export_heal_manifest_failed_v101637", "batch_id":bid, "error":str(exc)})
        zip_path = self._zip_dir(d)
        latest = {"exists": True, "batch_id": bid, "path": str(zip_path), "download_url": f"/api/time-machine/export/download?batch_id={bid}", "healed": True, "adaptive": _safe_json(adaptive)}
        try:
            (self.root / "latest_random_export.json").write_text(json.dumps(_safe_json(latest), ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass
        append_jsonl("time_machine_export_audit.jsonl", {"event":"export_healed_v101637", **latest})
        return latest

    def export_path(self, batch_id: str | None = None, *, heal: bool = False) -> Path | None:
        if heal:
            try:
                self.heal_existing_export(batch_id)
            except Exception as exc:
                append_jsonl("time_machine_export_audit.jsonl", {"event":"export_path_heal_failed_v101637", "batch_id":batch_id, "error":str(exc)})
        if batch_id:
            p = self.root / f"{batch_id}.zip"
            return p if p.exists() else None
        info = self.latest_info()
        p = Path(info.get("path", "")) if info.get("path") else None
        return p if p and p.exists() else None
