# AlgoRoute v1.6.1 update

```bash
cd /home/ubuntu

rm -rf algoroute_latest
rm -f algoroute_v1_6_1_4K_FULLSCREEN_INTRO.zip

wget -O /home/ubuntu/algoroute_v1_6_1_4K_FULLSCREEN_INTRO.zip \
"https://raw.githubusercontent.com/vw8vc8kbnz-collab/bitcoin-evidence-engine-mobile/main/algoroute_v1_6_1_4K_FULLSCREEN_INTRO.zip"

mkdir -p /home/ubuntu/algoroute_latest
unzip -o /home/ubuntu/algoroute_v1_6_1_4K_FULLSCREEN_INTRO.zip -d /home/ubuntu/algoroute_latest

cd /home/ubuntu/algoroute_latest/algoroute_v1_6_1_4k_fullscreen_intro

chmod +x scripts/install.sh scripts/setup_osrm_nl.sh
sudo ./scripts/install.sh

sudo ufw allow 8787/tcp || true
sudo ufw allow 5000/tcp || true
sudo docker compose down --remove-orphans || true
sudo docker rm -f algoroute-api algoroute-web algoroute-nginx 2>/dev/null || true
sudo docker compose up -d --build --force-recreate

sudo docker compose ps
curl -I http://localhost:8787/
curl http://localhost:8787/api/health
curl http://localhost:8787/api/geocode/status
curl http://localhost:8787/api/routing/status
```
