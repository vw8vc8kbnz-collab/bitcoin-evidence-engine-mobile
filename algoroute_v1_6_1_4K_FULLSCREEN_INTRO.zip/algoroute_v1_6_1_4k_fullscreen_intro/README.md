# AlgoRoute v1.6.1 — 4K Fullscreen Intro Replacement

## Nieuw / gefixt
- Introvideo vervangen door aangeleverde `AlgoRoute intro 4K fullscreen.mp4`.
- Intro wordt fullscreen edge-to-edge getoond met `object-fit: cover`.
- Geen randen/letterboxing vanuit de app-layout.
- PDOK/BAG geocoding en OSRM foundation uit v1.6 blijven behouden.
- Logo/header fixes blijven behouden.

## Testpunten
- Open de app op `/` en controleer dat de intro fullscreen start.
- Er mag geen witte/zwarte rand rondom de video zitten vanuit de UI.
- Na de intro moet de app smooth zichtbaar worden.
