# Outrun IQ v8.5.9

AI Product Resolver & Model Choice.

Deze versie voorkomt dat herkenbare producten te generiek worden ingevuld. Bij vergelijkbare modellen toont Outrun korte bevestigingsopties, zodat de partner met één tik het juiste model kiest en de rest van de listing automatisch kan worden verbeterd.

Belangrijkste focus:
- minder generieke AI-titels;
- modelkandidaten bij onzekerheid;
- betere Sony WH-1000X-serie herkenning;
- eenvoudige one-tap bevestiging;
- betere input voor pricing, SEO en listing writer.
