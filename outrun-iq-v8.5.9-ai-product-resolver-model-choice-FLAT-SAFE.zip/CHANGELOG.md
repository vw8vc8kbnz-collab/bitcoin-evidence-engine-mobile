# Outrun IQ v8.5.9 — AI Product Resolver & Model Choice

- Productherkenning is aangescherpt voor consumentenelektronica waar modellen sterk op elkaar lijken.
- Sony over-ear koptelefoons worden niet meer generiek als “Sony koptelefoon” vastgezet als WH-model onzeker is.
- Bij twijfel toont Outrun één-tik opties zoals Sony WH-1000XM5 / WH-1000XM4 / WH-1000XM3.
- Vision prompt uitgebreid: merk + serie + modelkandidaten boven generieke titels.
- Confirm-flow blijft eenvoudig: gebruiker kiest één optie, daarna worden titel/model/prijs/SEO-flow verder gevoed.
- Extra foto-advies toegevoegd bij onzeker model: typecode, doos/modelsticker of close-up van arm/knoppen.

Build note: gebaseerd op v8.5.8.
