# Outrun IQ v8.5.4 — Product Intake Clarity & Market Pricing Anchor

## Kern
- Nieuwe product-aanmaakpagina rustiger gemaakt: AI-herkenning is nu een compacte bevestigingskaart in plaats van een druk technisch blok.
- Bij twijfel toont Outrun simpele merk/model-keuzes, zonder dat de partner een ingewikkelde AI-flow hoeft te begrijpen.
- Prijsanker is niet meer verplicht als harde nieuwprijs; de prijsengine kan nu een tweedehands marktanker gebruiken.
- Pricing prompt is aangescherpt: bij motoren/voertuigen en gebruikte producten moet AI eerst gemiddelde tweedehands marktwaarde inschatten, niet blind korting op nieuwprijs toepassen.
- Heuristische fallback voorkomt extreem foute €899-achtige prijzen voor Harley/motorachtige producten.

## Technisch
- PricingInput uitgebreid met model, artikelnummer, identityConfirmed en marketScanRequested.
- PriceAdvice uitgebreid met marketAverage, marketLow, marketHigh, referenceNewPrice en marketConfidence.
- DeepSeek pricing prompt aangepast richting marktprijsanalyse.
- Partner pricing API accepteert nu een leeg prijsanker en laat AI/fallback een referentie bepalen.
- TypeScript check OK (`npx tsc --noEmit`).
