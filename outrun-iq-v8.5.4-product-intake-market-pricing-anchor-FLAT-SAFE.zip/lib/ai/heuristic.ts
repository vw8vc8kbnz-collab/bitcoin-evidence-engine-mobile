import type { PriceAdvice, PricingInput } from "./index";

/** Deterministische fallback zonder externe AI.
 * v8.5.4: als nieuwprijs ontbreekt of onlogisch laag is, gebruik een veilige
 * tweedehands-marktanker voor herkenbare voertuig/productfamilies i.p.v. €899-achtige onzin.
 */
function round5(v: number) { return Math.max(1, Math.round(v / 5) * 5); }
function round50(v: number) { return Math.max(50, Math.round(v / 50) * 50); }
function isHarley(i: PricingInput) {
  const s = `${i.title} ${i.brand ?? ""} ${i.model ?? ""}`.toLowerCase();
  return s.includes("harley") || s.includes("road king") || s.includes("softail");
}
function isMotor(i: PricingInput) {
  const s = `${i.title} ${i.brand ?? ""} ${i.model ?? ""} ${i.category}`.toLowerCase();
  return isHarley(i) || s.includes("motor") || s.includes("cruiser") || s.includes("touring");
}

export function heuristicPricing(i: PricingInput): PriceAdvice {
  const cond = Math.min(10, Math.max(1, i.conditionScore));

  if (isHarley(i) || (isMotor(i) && (!i.newPrice || i.newPrice < 2500))) {
    const avg = isHarley(i) ? 14500 : 5500;
    const condFactor = 0.86 + cond * 0.025;
    const outlet = round50(avg * condFactor);
    return {
      fast: round50(outlet * 0.9), outlet, premium: round50(outlet * 1.1),
      expectedDaysFast: 10, expectedDaysOutlet: 28, expectedDaysPremium: 55,
      confidence: isHarley(i) ? 62 : 48, comps: 0,
      reasoning: isHarley(i)
        ? "Geen live marktscan: veilige Harley-cruiser tweedehandsanker gebruikt; controleer bouwjaar/km/model."
        : "Geen live marktscan: voertuigprijs voorzichtig geschat; controleer model, bouwjaar en kilometerstand.",
      source: "heuristiek",
      marketAverage: avg, marketLow: round50(avg * .75), marketHigh: round50(avg * 1.25),
      referenceNewPrice: i.newPrice > avg ? i.newPrice : 0, marketConfidence: isHarley(i) ? 58 : 42,
    };
  }

  const anchor = i.newPrice > 0 ? i.newPrice : 899;
  const base = anchor * (0.55 + (cond - 5) * 0.046);
  const outlet = round5(base);
  return {
    fast: round5(outlet * 0.87),
    outlet,
    premium: round5(outlet * 1.09),
    expectedDaysFast: 3, expectedDaysOutlet: 7, expectedDaysPremium: 16,
    confidence: 35 + cond * 2,
    comps: 0,
    reasoning: "Heuristische schatting op basis van prijsanker en conditie — geen live marktscan (AI offline of geen API-key).",
    source: "heuristiek",
    referenceNewPrice: i.newPrice || undefined,
  };
}
