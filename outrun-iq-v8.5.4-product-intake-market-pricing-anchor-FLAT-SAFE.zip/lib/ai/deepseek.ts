import type { PriceAdvice, PricingInput } from "./index";
import { heuristicPricing } from "./heuristic";

const API = process.env.DEEPSEEK_BASE_URL || "https://api.deepseek.com/chat/completions";
const MODEL = process.env.DEEPSEEK_MODEL || "deepseek-chat";

/** Robuuste getal-parser: accepteert 575, "575", "€575", "1.249,50". */
function num(x: unknown): number {
  if (typeof x === "number" && isFinite(x)) return Math.round(x);
  if (typeof x === "string") {
    const v = parseFloat(x.replace(/[^\d,.-]/g, "").replace(/\.(?=\d{3}\b)/g, "").replace(",", "."));
    if (isFinite(v)) return Math.round(v);
  }
  return NaN;
}

export async function deepseekPricing(i: PricingInput): Promise<PriceAdvice> {
  const key = process.env.DEEPSEEK_API_KEY;
  if (!key) throw new Error("DEEPSEEK_API_KEY ontbreekt");

  const sys = `Je bent de pricing- en marktprijs-engine van een Nederlandse outlet-marketplace (overstock, showroommodellen, retouren en zakelijke sellers). Je krijgt productgegevens, vision-observaties en mogelijk een onzekere nieuwprijs. Denk verder dan alleen korting op nieuwprijs: bepaal bij auto's/motoren, vintage, outlet en gebruikte producten eerst een realistische tweedehands marktwaarde voor specifiek merk/model/type. Gebruik je modelkennis conservatief; als er later een web/search-provider aan DEEPSEEK_BASE_URL hangt, mag die marktinformatie expliciet meewegen. Antwoord UITSLUITEND met geldige JSON, exact deze sleutels, alle prijzen als kale integers zonder valutateken:
{"fast":0,"outlet":0,"premium":0,"expectedDaysFast":0,"expectedDaysOutlet":0,"expectedDaysPremium":0,"confidence":0,"comps":0,"reasoning":"","marketAverage":0,"marketLow":0,"marketHigh":0,"referenceNewPrice":0,"marketConfidence":0}
BELANGRIJK: "fast" = de LAAGSTE prijs (snelle verkoop), "outlet" = de middelste (aanbevolen), "premium" = de HOOGSTE (geduld). Dus altijd: fast < outlet < premium. Voor normale retailartikelen moet premium meestal < nieuwprijs blijven. Voor tweedehands voertuigen of producten waar nieuwprijs ontbreekt/onrealistisch laag is: gebruik marketAverage als anker en negeer een onlogisch lage nieuwprijs zoals 899 voor een Harley/motor. Rond retail op €5, voertuigen op €50/€100. "comps" = aantal prijssignalen uit modelkennis/marktinschatting; 0 bij weinig zekerheid. "reasoning" = één Nederlandse zin, max 160 tekens. Gebruik vision_observaties, merk/model-confidence, bouwjaar/km/onzekerheid en zichtbare staat zwaarder dan generieke aannames.`;

  const user = JSON.stringify({
    titel: i.title, merk: i.brand ?? null, categorie: i.category,
    conditie_tekst: i.condition, conditie_score_op_10: i.conditionScore,
    nieuwprijs_of_prijsanker_eur: i.newPrice || null, voorraad: i.stock,
    aantal_fotos: i.photosCount, gebrek: i.defect ?? null,
    vision_observatie: i.visionSummary ?? null,
    conditie_motivatie: i.conditionReason ?? null,
    zichtbare_gebreken: i.defects ?? [],
    zichtbare_accessoires: i.accessories ?? [],
    energielabel: i.energyLabel ?? null,
    model: i.model ?? null, artikelnummer: i.articleNumber ?? null,
    identiteit_bevestigd_door_partner: i.identityConfirmed ?? false,
    markt_scan_nodig: i.marketScanRequested ?? (!i.newPrice || i.newPrice < 1),
  });

  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), 25_000);
  try {
    const res = await fetch(API, {
      method: "POST",
      signal: ctl.signal,
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
      body: JSON.stringify({
        model: MODEL,
        temperature: 0.2,
        response_format: { type: "json_object" },
        messages: [{ role: "system", content: sys }, { role: "user", content: user }],
      }),
    });
    if (!res.ok) throw new Error(`DeepSeek ${res.status}: ${await res.text().catch(() => "")}`);
    const data = await res.json();
    const raw = data?.choices?.[0]?.message?.content ?? "";
    let p: Record<string, unknown> = {};
    try { p = JSON.parse(raw.replace(/```json|```/g, "").trim()); }
    catch { console.error("[ai] deepseek: geen parsebare JSON:", raw); return heuristicPricing(i); }

    const out: PriceAdvice = {
      fast: num(p.fast), outlet: num(p.outlet), premium: num(p.premium),
      expectedDaysFast: num(p.expectedDaysFast) || 3,
      expectedDaysOutlet: num(p.expectedDaysOutlet) || 7,
      expectedDaysPremium: num(p.expectedDaysPremium) || 16,
      confidence: Math.min(100, Math.max(0, num(p.confidence) || 0)),
      comps: Math.max(0, num(p.comps) || 0),
      reasoning: String(p.reasoning ?? "").slice(0, 180) || "Prijsadvies o.b.v. modelkennis.",
      source: "deepseek",
      marketAverage: num(p.marketAverage) || undefined,
      marketLow: num(p.marketLow) || undefined,
      marketHigh: num(p.marketHigh) || undefined,
      referenceNewPrice: num(p.referenceNewPrice) || (i.newPrice || undefined),
      marketConfidence: Math.min(100, Math.max(0, num(p.marketConfidence) || 0)) || undefined,
    };

    // Auto-reparatie: modellen halen fast/outlet/premium soms door elkaar -> sorteren i.p.v. afkeuren.
    let trio = [out.fast, out.outlet, out.premium].filter(v => isFinite(v) && v > 0);
    if (trio.length === 3) {
      const normalRetailCap = i.newPrice > 0 && i.newPrice > Math.max(...trio) * 0.8;
      trio = trio.map(v => normalRetailCap ? Math.min(v, Math.round((i.newPrice * 0.95) / 5) * 5) : v).sort((a, b) => a - b);
      const step = Math.max(5, Math.round(trio[1] / 100));
      if (trio[1] <= trio[0]) trio[1] = trio[0] + step;
      if (trio[2] <= trio[1]) trio[2] = trio[1] + step;
      [out.fast, out.outlet, out.premium] = trio;
    }
    const sane = out.fast > 0 && out.fast < out.outlet && out.outlet < out.premium;
    if (!sane) {
      console.error("[ai] deepseek onherstelbaar. Ruw antwoord:", raw);
      return { ...heuristicPricing(i), reasoning: "Modeloutput onbruikbaar \u2192 heuristiek." };
    }
    return out;
  } finally { clearTimeout(t); }
}
