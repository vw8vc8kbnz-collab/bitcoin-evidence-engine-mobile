# Outrun IQ v8.5.4

Flat safe deployment build.

Deze versie bouwt door op v8.5.3 en verbetert vooral de zakelijke product-intake:

- rustiger AI-herkenningsblok;
- eenvoudige merk/model-bevestiging;
- prijsanker optioneel;
- marktprijsanalyse voor tweedehands/voertuigen;
- veiligere fallback voor Harley/motor-prijzen.

Deployment blijft hetzelfde als eerdere Outrun IQ flat safe builds.
