#!/usr/bin/env bash
set -euo pipefail
APP_DIR="/var/www/configurator-studio"
SITE_AVAIL="/etc/nginx/sites-available/configurator-studio-9999"
SITE_ENAB="/etc/nginx/sites-enabled/configurator-studio-9999"

sudo mkdir -p "$APP_DIR"
sudo rsync -a --delete --exclude .git --exclude deploy ./ "$APP_DIR/"

sudo tee "$SITE_AVAIL" >/dev/null <<'EOF'
server {
    listen 9999;
    listen [::]:9999;
    server_name _;

    root /var/www/configurator-studio;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    location ~ /\.(?!well-known) {
        deny all;
    }
}
EOF

sudo ln -sf "$SITE_AVAIL" "$SITE_ENAB"
sudo systemctl stop configurator 2>/dev/null || true
sudo systemctl disable configurator 2>/dev/null || true
sudo fuser -k 9999/tcp 2>/dev/null || true
sudo nginx -t
sudo systemctl enable nginx
sudo systemctl restart nginx
