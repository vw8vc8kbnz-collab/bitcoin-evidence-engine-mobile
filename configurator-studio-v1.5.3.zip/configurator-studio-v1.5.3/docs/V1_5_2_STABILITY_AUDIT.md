# v1.5.2 Stability Audit

- Mobiele vastloper/onzichtbare GLB geaudit.
- Topbar Model / Builder / Sluit toegevoegd.
- Viewer-canvas stabiele hoogte.
- Alleen echte GLB-laag.
- Selectieknoppen + reset camera toegevoegd.
- ResizeObserver en expliciete resize hooks toegevoegd.
