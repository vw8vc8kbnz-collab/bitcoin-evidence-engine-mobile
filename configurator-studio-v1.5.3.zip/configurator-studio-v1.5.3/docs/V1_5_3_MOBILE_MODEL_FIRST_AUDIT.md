# v1.5.3 Mobile Model-First Audit

## Issue
On mobile the demo opened directly in the lower Builder/Inspector area. The GLB was textually loaded but the 3D model was not the dominant visible surface, and the close button felt non-functional.

## Fix
- Injected a force-close function independent of the original builder code.
- Added capture-phase handlers for Close, Model and Builder buttons.
- Mobile builder now defaults to `mobile-view-model`.
- In Model view only the GLB viewer panel is visible.
- In Builder view the builder/inspector panels are visible.
- The 3D canvas has a dominant mobile height and explicit resize calls.
