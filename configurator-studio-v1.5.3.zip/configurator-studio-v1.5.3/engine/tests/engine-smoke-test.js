const assert = require('assert');
const { deriveFactStatus, pricingAllowed } = require('../core/deriveFactStatus');
const { gateFor } = require('../core/gateFor');
const { analyzeSegmentation } = require('../core/analyzeSegmentation');
const { validateRuleActions, evaluateRules } = require('../core/evaluateRules');
const { calculatePrice } = require('../core/calculatePrice');
const { reserveCredits, captureCredits, refundCredits } = require('../job-core/ledger');
const { settlementFor } = require('../job-core/settleJob');

// 1. AI candidate never confirms
const aiFact = {
  key:'dimensions.length',
  value:null,
  value_type:'measurement',
  candidates:[{candidate_id:'c1', value:2200, provenance:'ai_inferred', confidence:.99}],
  verified:{by:null, method:'none', verified_at:null}
};
assert.strictEqual(deriveFactStatus(aiFact), 'inferred');
assert.strictEqual(pricingAllowed(aiFact), false);

// 2. Confirmed measurement is pricing-allowed
const confirmedFact = {
  key:'dimensions.length',
  value:2200,
  value_type:'measurement',
  candidates:[],
  verified:{by:'user_1', method:'user_confirmed', verified_at:new Date().toISOString()}
};
assert.strictEqual(deriveFactStatus(confirmedFact), 'confirmed');
assert.strictEqual(pricingAllowed(confirmedFact), true);

// 3. Boolean gate, no pseudo-score
const gate = gateFor({ facts:[confirmedFact], criticalFields:['dimensions.length','dimensions.width'], pricingFields:['dimensions.length'] });
assert.strictEqual(gate.allowed, false);
assert.strictEqual(gate.blocking_fields[0].key, 'dimensions.width');

// 4. Merged mesh blocks configurability
const seg = analyzeSegmentation({
  mesh_inventory:[{mesh_id:'mesh_0',name:'mesh_0',material_slots:['mat_0'],triangle_count:5000,visible:true,assigned_part_id:null}],
  intended_configurable_parts:[{part_id:'part_top',label:'Top',required_isolation:'material'}]
});
assert.strictEqual(seg.overall_status, 'blocked');

// 5. Rules cannot add price directly
const actionErrors = validateRuleActions([{rule_id:'r1',then:[{action:'add_price',amount:10}]}]);
assert.strictEqual(actionErrors.length, 1);

// 6. Conflicting required/hidden invalid
const ruleState = evaluateRules({ rules:[
  {rule_id:'hide',enabled:true,then:[{action:'hide_option',option_id:'opt_x'}]},
  {rule_id:'req',enabled:true,then:[{action:'require_option',option_id:'opt_x'}]}
]});
assert.strictEqual(ruleState.invalid, true);

// 7. Pricing area requires authoritative dimensions
const widthFact = { key:'dimensions.width', value:1000, value_type:'measurement', pricing_allowed:true, verified:{by:'user',method:'user_confirmed'} };
const lengthFact = { ...confirmedFact, pricing_allowed:true };
const price = calculatePrice({
  base_price:{label:'Base',amount:799},
  selected_option_ids:['opt_area'],
  facts:[lengthFact,widthFact],
  rules:[{rule_id:'area',label:'Area price',type:'area_based',trigger_option_id:'opt_area',length_field:'dimensions.length',width_field:'dimensions.width',rate_per_m2:100,requires_authoritative_inputs:['dimensions.length','dimensions.width']}]
});
assert(price.total > 799);

// 8. Ledger entries balance
assert.doesNotThrow(()=>reserveCredits({workspace_id:'ws',job_id:'job',amount:5,idempotency_key:'k1'}));
assert.doesNotThrow(()=>captureCredits({workspace_id:'ws',job_id:'job',amount:5,idempotency_key:'k2'}));
assert.doesNotThrow(()=>refundCredits({workspace_id:'ws',job_id:'job',amount:5,idempotency_key:'k3'}));

// 9. Settlement matrix
assert.strictEqual(settlementFor({technical_status:'failed',failure_type:'provider_error'}),'full_refund');
assert.strictEqual(settlementFor({technical_status:'succeeded',quality_status:'not_configurable',failure_type:'none'}),'partial_capture_discounted_retry');


// 10. Builder draft from mesh inventory
const { createBuilderDraft } = require('../core/createBuilderDraft');
const draft = createBuilderDraft({
  workspace_id:'ws',
  project_id:'proj',
  mesh_inventory:[
    {mesh_id:'mesh_a',visible:true,material_slots:['mat_a'],suggested_label:'Hoofdvlak'},
    {mesh_id:'mesh_b',visible:false,material_slots:[]}
  ]
});
assert.strictEqual(draft.parts.length, 1);
assert.strictEqual(draft.parts[0].label, 'Hoofdvlak');


// 11. Customer-friendly builder pricing setup validation
const { customerLabelSuggestion, validatePricingSetup } = require('../core/customerBuilder');
assert.strictEqual(customerLabelSuggestion({ type:'frame' }), 'Frame / basis');
const setupCheck = validatePricingSetup([{ id:'pr_base', type:'base', amount:null, needs_setup:true }]);
assert.strictEqual(setupCheck.valid, false);
assert.strictEqual(setupCheck.issues[0].code, 'base_price_missing');
const validSetup = validatePricingSetup([{ id:'pr_base', type:'base', amount:799 }]);
assert.strictEqual(validSetup.valid, true);


// 12. Capability-aware selection actions
const { actionAllowed, allowedActionsForScope } = require('../core/selectionCapabilities');
assert.strictEqual(actionAllowed('material_zone', 'product_dimension'), false);
assert.strictEqual(actionAllowed('material_zone', 'material'), true);
assert.strictEqual(actionAllowed('product', 'product_dimension'), true);
assert.strictEqual(actionAllowed('product', 'product_material'), true);
assert.strictEqual(actionAllowed('part', 'variant'), true);
assert.strictEqual(actionAllowed('single_mesh', 'segmentation_plan'), true);
assert.deepStrictEqual(allowedActionsForScope('material_zone', ['material','texture','variant','product_dimension']), ['material','texture']);


// 13. Test table manifest maps GLB meshes to logical parts
const { TEST_TABLE_MANIFEST, partForMesh: testPartForMesh } = require('../core/testTableManifest');
assert.strictEqual(TEST_TABLE_MANIFEST.parts.length, 3);
assert.strictEqual(testPartForMesh('tabletop_main').label, 'Tafelblad');
assert.strictEqual(testPartForMesh('leg_front_left').label, 'Metalen frame en poten');
assert.strictEqual(testPartForMesh('tabletop_inlay').scope, 'material_zone');

console.log('Engine Foundation smoke tests passed.');
