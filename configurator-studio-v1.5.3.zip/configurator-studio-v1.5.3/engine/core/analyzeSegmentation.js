function analyzeSegmentation({ mesh_inventory = [], intended_configurable_parts = [] }) {
  const issues = [];
  const visibleMeshes = mesh_inventory.filter(m => m.visible);
  const mergedMeshLikely = visibleMeshes.length <= 1 && intended_configurable_parts.some(p => p.required_isolation !== 'data_only');

  if (mergedMeshLikely) {
    issues.push({
      type: 'merged_mesh',
      severity: 'blocking',
      message: 'The model appears to be one merged mesh; intended configurable parts cannot be isolated.',
      target_ids: visibleMeshes.map(m => m.mesh_id)
    });
  }

  for (const part of intended_configurable_parts) {
    if (part.required_isolation === 'data_only') continue;
    const hasAssigned = visibleMeshes.some(m => m.assigned_part_id === part.part_id);
    if (!hasAssigned) {
      issues.push({
        type: 'intended_part_not_isolable',
        severity: 'blocking',
        message: `Intended part "${part.label}" is not mapped to an isolable mesh/material slot.`,
        target_ids: [part.part_id]
      });
    }
  }

  const unmapped = visibleMeshes.filter(m => !m.assigned_part_id);
  if (unmapped.length && !mergedMeshLikely) {
    issues.push({
      type: 'unmapped_visible_mesh',
      severity: 'warning',
      message: `${unmapped.length} visible mesh(es) are not mapped to logical parts.`,
      target_ids: unmapped.map(m => m.mesh_id)
    });
  }

  const blocking = issues.some(i => i.severity === 'blocking');
  return {
    overall_status: blocking ? 'blocked' : (issues.length ? 'needs_mapping' : 'ready'),
    issues,
    recommended_actions: blocking
      ? ['upload_segmented_model','run_segmentation','manual_part_painting','admin_review']
      : (issues.length ? ['admin_review'] : [])
  };
}

module.exports = { analyzeSegmentation };
