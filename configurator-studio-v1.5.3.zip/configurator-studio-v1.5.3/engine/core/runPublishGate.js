function runPublishGate({ criticalGate, configurability, pricingValid, rulesValid, runtimeCompiled, brandingVisible }) {
  const checks = [
    { id:'critical_facts_confirmed', label:'Essentiële productdetails bevestigd', status: criticalGate.allowed ? 'passed' : 'blocked', message: criticalGate.allowed ? '' : `${criticalGate.blocking_fields.length} blocking field(s)` },
    { id:'model_configurable', label:'Model configureerbaar', status: configurability.overall_status === 'ready' ? 'passed' : 'blocked', message: configurability.overall_status },
    { id:'pricing_valid', label:'Prijsregels geldig', status: pricingValid ? 'passed' : 'blocked' },
    { id:'rules_valid', label:'Regels geldig', status: rulesValid ? 'passed' : 'blocked' },
    { id:'runtime_compiled', label:'Runtime snapshot klaar', status: runtimeCompiled ? 'passed' : 'blocked' },
    { id:'branding_visible', label:'Branding zichtbaar', status: brandingVisible ? 'passed' : 'blocked' }
  ];
  return { publish_allowed: checks.every(c => c.status === 'passed'), checks };
}

module.exports = { runPublishGate };
