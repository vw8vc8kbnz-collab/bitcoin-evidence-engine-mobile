function assertAuthoritativeInputs(rule, factsByKey) {
  for (const key of rule.requires_authoritative_inputs || []) {
    const fact = factsByKey.get(key);
    if (!fact || !fact.pricing_allowed) {
      throw new Error(`Pricing rule "${rule.rule_id}" blocked: input ${key} is not authoritative.`);
    }
  }
}

function calculatePrice({ base_price, rules = [], selected_option_ids = [], facts = [] }) {
  const factsByKey = new Map(facts.map(f => [f.key, f]));
  const breakdown = [{ label: base_price.label || 'Base price', amount: base_price.amount || 0 }];
  let total = base_price.amount || 0;

  for (const rule of rules) {
    if (rule.enabled === false) continue;
    if (rule.trigger_option_id && !selected_option_ids.includes(rule.trigger_option_id)) continue;
    assertAuthoritativeInputs(rule, factsByKey);

    let amount = 0;
    if (rule.type === 'fixed_delta') amount = rule.amount || 0;
    if (rule.type === 'percentage_delta') amount = total * ((rule.percent || 0) / 100);
    if (rule.type === 'area_based') {
      const l = factsByKey.get(rule.length_field).value;
      const w = factsByKey.get(rule.width_field).value;
      amount = (l / 1000) * (w / 1000) * rule.rate_per_m2;
    }
    if (rule.type === 'perimeter_based') {
      const l = factsByKey.get(rule.length_field).value;
      const w = factsByKey.get(rule.width_field).value;
      amount = ((l + w) * 2 / 1000) * rule.rate_per_meter;
    }
    breakdown.push({ label: rule.label, amount: Math.round(amount * 100) / 100 });
    total += amount;
  }

  return { total: Math.round(total * 100) / 100, breakdown };
}

module.exports = { calculatePrice };
