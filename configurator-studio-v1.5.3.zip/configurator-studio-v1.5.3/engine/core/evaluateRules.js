/**
 * Rule engine does not calculate price directly.
 * It may enable/disable pricing rules, require options, show warnings, hide/disable options.
 */
const RULE_ACTIONS_ALLOWED = new Set([
  'show_option','hide_option','disable_option','require_option','set_default',
  'add_lead_time','show_warning','switch_mesh','switch_material','limit_dimension',
  'set_order_field','enable_pricing_rule','disable_pricing_rule'
]);

function validateRuleActions(rules) {
  const errors = [];
  for (const rule of rules) {
    for (const effect of rule.then || []) {
      if (!RULE_ACTIONS_ALLOWED.has(effect.action)) {
        errors.push({ rule_id: rule.rule_id, error: `Action ${effect.action} is not allowed. Pricing must stay in Pricing Engine.` });
      }
    }
  }
  return errors;
}

function evaluateRules({ rules = [], configuration = {} }) {
  const state = {
    hidden_options: new Set(),
    disabled_options: new Set(),
    required_options: new Set(),
    warnings: [],
    enabled_pricing_rules: new Set(),
    disabled_pricing_rules: new Set(),
    invalid: false,
    conflicts: []
  };

  for (const rule of rules.filter(r => r.enabled !== false)) {
    // Mock condition evaluator: true when rule.mock_condition_true is true or no conditions supplied.
    const conditionMet = rule.mock_condition_true === true || !(rule.if || []).length;
    if (!conditionMet) continue;
    for (const effect of rule.then || []) {
      if (effect.action === 'hide_option') state.hidden_options.add(effect.option_id);
      if (effect.action === 'disable_option') state.disabled_options.add(effect.option_id);
      if (effect.action === 'require_option') state.required_options.add(effect.option_id);
      if (effect.action === 'show_warning') state.warnings.push(effect.message);
      if (effect.action === 'enable_pricing_rule') state.enabled_pricing_rules.add(effect.pricing_rule_id);
      if (effect.action === 'disable_pricing_rule') state.disabled_pricing_rules.add(effect.pricing_rule_id);
    }
  }

  for (const opt of state.required_options) {
    if (state.hidden_options.has(opt) || state.disabled_options.has(opt)) {
      state.invalid = true;
      state.conflicts.push({ option_id: opt, reason: 'required_option_is_hidden_or_disabled' });
    }
  }

  return {
    ...state,
    hidden_options: [...state.hidden_options],
    disabled_options: [...state.disabled_options],
    required_options: [...state.required_options],
    enabled_pricing_rules: [...state.enabled_pricing_rules],
    disabled_pricing_rules: [...state.disabled_pricing_rules]
  };
}

module.exports = { validateRuleActions, evaluateRules };
