const CAPABILITY_MATRIX = {
  product: {
    color: true, material: true, texture: true, finish: true,
    dimension: true, geometry_variant: false, visibility: false,
    pricing: true, rules: true, order_output: true, segmentation: false
  },
  part: {
    color: true, material: true, texture: true, finish: true,
    dimension: false, geometry_variant: true, visibility: true,
    pricing: true, rules: true, order_output: true, segmentation: false
  },
  material_zone: {
    color: true, material: true, texture: true, finish: true,
    dimension: false, geometry_variant: false, visibility: false,
    pricing: true, rules: false, order_output: false, segmentation: false
  },
  single_mesh: {
    color: true, material: true, texture: true, finish: true,
    dimension: true, geometry_variant: false, visibility: false,
    pricing: true, rules: true, order_output: true, segmentation: true
  }
};

const ACTION_CAPABILITY_REQUIREMENTS = {
  product_material: ['material'],
  product_texture: ['texture'],
  product_dimension: ['dimension'],
  product_choice: ['order_output'],
  material: ['material'],
  texture: ['texture'],
  finish: ['finish'],
  variant: ['geometry_variant'],
  visibility: ['visibility'],
  pricing: ['pricing'],
  pricing_choice: ['pricing'],
  rule: ['rules'],
  order: ['order_output'],
  use_single_product: ['material'],
  whole_material: ['material'],
  segmentation_plan: ['segmentation']
};

function capabilitiesForSelection(scope) {
  return CAPABILITY_MATRIX[scope] || CAPABILITY_MATRIX.product;
}

function actionAllowed(scope, action) {
  const caps = capabilitiesForSelection(scope);
  const reqs = ACTION_CAPABILITY_REQUIREMENTS[action] || [];
  return reqs.every(r => caps[r] === true);
}

function allowedActionsForScope(scope, actions) {
  return actions.filter(action => actionAllowed(scope, action));
}

module.exports = { CAPABILITY_MATRIX, ACTION_CAPABILITY_REQUIREMENTS, capabilitiesForSelection, actionAllowed, allowedActionsForScope };
