const { deriveFactStatus, pricingAllowed } = require('./deriveFactStatus');

function gateFor({ facts, criticalFields = [], pricingFields = [] }) {
  const byKey = new Map(facts.map(f => [f.key, f]));
  const blocking_fields = [];

  for (const key of criticalFields) {
    const fact = byKey.get(key);
    if (!fact || deriveFactStatus(fact) !== 'confirmed') {
      blocking_fields.push({ key, reason: 'critical_field_not_confirmed' });
    }
  }

  for (const key of pricingFields) {
    const fact = byKey.get(key);
    if (!fact || !pricingAllowed(fact)) {
      blocking_fields.push({ key, reason: 'pricing_input_not_authoritative' });
    }
  }

  return {
    allowed: blocking_fields.length === 0,
    blocking_fields,
    completed_required_fields: criticalFields.filter(k => byKey.get(k) && deriveFactStatus(byKey.get(k)) === 'confirmed').length,
    total_required_fields: criticalFields.length
  };
}

module.exports = { gateFor };
