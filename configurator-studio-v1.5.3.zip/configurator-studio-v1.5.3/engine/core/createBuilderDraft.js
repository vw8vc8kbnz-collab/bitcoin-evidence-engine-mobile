function createBuilderDraft({ workspace_id, project_id, mesh_inventory = [] }) {
  const parts = mesh_inventory
    .filter(m => m.visible)
    .map((m, index) => ({
      part_id: m.assigned_part_id || `part_${m.mesh_id}`,
      label: m.suggested_label || `Onderdeel ${index + 1}`,
      type: m.suggested_type || 'surface',
      mesh_targets: [m.mesh_id],
      material_slots: m.material_slots || [],
      configurable: true
    }));

  return {
    schema_version: '1.2.0',
    workspace_id,
    project_id,
    parts,
    option_groups: [],
    pricing: {
      currency: 'EUR',
      base_price: { amount: 0, label: 'Basisprijs' },
      rules: []
    },
    rules: [],
    publish_checks: [
      { id: 'parts_mapped', label: 'Onderdelen gekoppeld', status: parts.length ? 'passed' : 'blocked' },
      { id: 'pricing_valid', label: 'Prijsregels geldig', status: 'blocked', message: 'Basisprijs ontbreekt nog.' }
    ]
  };
}

module.exports = { createBuilderDraft };
