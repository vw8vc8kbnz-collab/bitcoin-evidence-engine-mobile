const TEST_TABLE_MANIFEST = {
  asset_id: 'asset_test_table_configurator',
  file: 'assets/test_table_configurator.glb',
  product_label: 'Testtafel',
  parts: [
    { part_id:'part_tabletop', label:'Tafelblad', scope:'part', mesh_targets:['tabletop_main'] },
    { part_id:'part_inlay', label:'Accentstrip', scope:'material_zone', mesh_targets:['tabletop_inlay'] },
    { part_id:'part_frame', label:'Metalen frame en poten', scope:'part', mesh_targets:['apron_left','apron_right','apron_front','apron_back','leg_front_left','leg_front_right','leg_back_left','leg_back_right'] }
  ]
};

function partForMesh(meshName, manifest = TEST_TABLE_MANIFEST) {
  return manifest.parts.find(p => (p.mesh_targets || []).includes(meshName)) || null;
}

module.exports = { TEST_TABLE_MANIFEST, partForMesh };
