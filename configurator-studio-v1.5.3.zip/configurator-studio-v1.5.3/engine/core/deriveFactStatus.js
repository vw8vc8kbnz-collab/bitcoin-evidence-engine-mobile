/**
 * Truth Graph v2 invariant:
 * AI candidates are never confirmed facts. Confirmation requires user/admin/measured/import verification.
 */
function deriveFactStatus(fact) {
  if (fact.conflict && fact.conflict.status === 'open') return 'conflicting';
  if (fact.verified && fact.verified.by && fact.verified.method !== 'none') return 'confirmed';
  if (Array.isArray(fact.candidates) && fact.candidates.length > 0) return 'inferred';
  return 'missing';
}

function pricingAllowed(fact) {
  const status = deriveFactStatus(fact);
  if (status !== 'confirmed') return false;
  if (fact.value_type === 'measurement') {
    const method = fact.verified && fact.verified.method;
    return ['user_confirmed','admin_confirmed','measured','imported_verified'].includes(method);
  }
  return true;
}

module.exports = { deriveFactStatus, pricingAllowed };
