function compileRuntimeSnapshot({ workspace_id, project_id, blueprint, runtime_version = '1.1.0' }) {
  return Object.freeze({
    schema_version: '1.1.0',
    workspace_id,
    project_id,
    runtime_config_id: `runtime_${project_id}_${Date.now()}`,
    blueprint_version: blueprint.schema_version || '1.1.0',
    runtime_version,
    immutable: true,
    published_at: null,
    snapshot: {
      project_id,
      parts: blueprint.parts || [],
      controls: (blueprint.option_groups || []).map(g => ({
        id: g.option_group_id,
        label: g.label,
        control_type: g.control_type,
        effect_type: g.effect_type,
        options: g.options || []
      })),
      pricing: blueprint.pricing || {},
      rules: blueprint.rules || [],
      branding: { powered_by_visible: true }
    }
  });
}

module.exports = { compileRuntimeSnapshot };
