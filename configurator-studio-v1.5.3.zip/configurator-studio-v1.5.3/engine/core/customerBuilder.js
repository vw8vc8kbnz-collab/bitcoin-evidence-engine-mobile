function hasRealAmount(value) {
  return value !== null && value !== undefined && value !== '' && Number.isFinite(Number(value));
}

function customerLabelSuggestion(part) {
  const byType = {
    surface: 'Zichtbaar vlak',
    frame: 'Frame / basis',
    soft_surface: 'Stof / bekleding',
    edge: 'Randafwerking',
    hardware: 'Detail / hardware',
    glass: 'Glasvlak',
    fabric_zone: 'Stofzone'
  };
  return byType[part.type] || 'Onderdeel';
}

function validatePricingSetup(pricingRules = []) {
  const issues = [];
  const base = pricingRules.find(r => r.type === 'base');
  if (!base || !hasRealAmount(base.amount)) {
    issues.push({ severity: 'blocking', code: 'base_price_missing', message: 'Basisprijs is nog niet ingesteld.' });
  }
  for (const rule of pricingRules) {
    if (rule.type !== 'base' && rule.needs_setup) {
      issues.push({ severity: 'warning', code: 'pricing_rule_needs_setup', rule_id: rule.id || rule.rule_id });
    }
    if (hasRealAmount(rule.amount) && Number(rule.amount) < 0) {
      issues.push({ severity: 'blocking', code: 'negative_price_not_allowed', rule_id: rule.id || rule.rule_id });
    }
  }
  return { valid: !issues.some(i => i.severity === 'blocking'), issues };
}

module.exports = { customerLabelSuggestion, validatePricingSetup, hasRealAmount };
