function detectConflicts(facts) {
  const conflicts = [];
  for (const fact of facts) {
    const values = new Map();
    for (const c of fact.candidates || []) {
      const key = JSON.stringify(c.value);
      if (!values.has(key)) values.set(key, []);
      values.get(key).push(c);
    }
    if (values.size > 1 && !(fact.verified && fact.verified.by)) {
      conflicts.push({
        conflict_id: `conf_${fact.key.replace(/[^a-z0-9_]/gi, '_')}`,
        field: fact.key,
        status: 'open',
        candidates: [...values.values()].flat(),
        resolution_required: true
      });
    }
  }
  return conflicts;
}

function resolveConflict(conflict, { value, resolved_by }) {
  return { ...conflict, status: 'resolved', resolved_value: value, resolved_by, resolved_at: new Date().toISOString() };
}

module.exports = { detectConflicts, resolveConflict };
