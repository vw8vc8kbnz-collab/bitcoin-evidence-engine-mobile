/**
 * Mock adapters only.
 * v1.1 does not perform real generation. This prevents normalizing the assumption
 * that generated models are exact/configurable.
 */
async function mockSegmentationAdapter(asset) {
  return {
    adapter: 'mock_segmentation',
    technical_status: 'succeeded',
    quality_status: asset.mesh_count <= 1 ? 'not_configurable' : 'accepted',
    mesh_inventory: asset.mesh_inventory || []
  };
}

async function mockModelAdapter() {
  throw new Error('Real model generation is intentionally out of scope for Reliable Configurator Core v1.1');
}

async function mockTextureAdapter(input) {
  return {
    adapter: 'mock_texture',
    technical_status: 'succeeded',
    quality_status: 'pending_review',
    preview_texture_id: `mock_texture_${Date.now()}`,
    input
  };
}

module.exports = { mockSegmentationAdapter, mockModelAdapter, mockTextureAdapter };
