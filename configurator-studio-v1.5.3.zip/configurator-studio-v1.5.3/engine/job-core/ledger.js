function assertBalanced(entry) {
  const sum = (entry.lines || []).reduce((acc, l) => acc + l.amount, 0);
  if (Math.abs(sum) > 0.00001) throw new Error(`Ledger entry ${entry.entry_id} is not balanced: ${sum}`);
  return true;
}

function reserveCredits({ workspace_id, job_id, amount, idempotency_key }) {
  const entry = {
    entry_id: `ledger_reserve_${job_id}`,
    workspace_id, job_id, idempotency_key,
    lines: [
      { account:'available', amount:-amount },
      { account:'reserved', amount:amount }
    ]
  };
  assertBalanced(entry);
  return entry;
}

function captureCredits({ workspace_id, job_id, amount, idempotency_key }) {
  const entry = {
    entry_id: `ledger_capture_${job_id}`,
    workspace_id, job_id, idempotency_key,
    lines: [
      { account:'reserved', amount:-amount },
      { account:'captured', amount:amount }
    ]
  };
  assertBalanced(entry);
  return entry;
}

function refundCredits({ workspace_id, job_id, amount, idempotency_key }) {
  const entry = {
    entry_id: `ledger_refund_${job_id}`,
    workspace_id, job_id, idempotency_key,
    lines: [
      { account:'reserved', amount:-amount },
      { account:'refunded', amount:amount }
    ]
  };
  assertBalanced(entry);
  return entry;
}

module.exports = { assertBalanced, reserveCredits, captureCredits, refundCredits };
