const SETTLEMENT = {
  provider_error: 'full_refund',
  timeout: 'full_refund_or_retry',
  input_error: 'full_refund_requires_input_fix',
  not_segmentable: 'partial_capture_discounted_retry',
  quality_rejected_by_user: 'capture_discounted_retry',
  customer_cancelled_pre_run: 'release_reservation',
  system_error: 'full_refund'
};

function settlementFor(job) {
  if (job.technical_status === 'succeeded' && job.quality_status === 'accepted') return 'full_capture';
  if (job.failure_type && job.failure_type !== 'none') return SETTLEMENT[job.failure_type] || 'admin_review';
  if (job.quality_status === 'not_configurable') return SETTLEMENT.not_segmentable;
  return 'admin_review';
}

module.exports = { settlementFor, SETTLEMENT };
