function applyBuilderAction(blueprint, action) {
  const next = JSON.parse(JSON.stringify(blueprint));
  if (action.type === 'create_part') {
    next.parts.push({
      part_id: action.part_id,
      label: action.label,
      type: action.part_type || 'surface',
      mesh_targets: action.mesh_ids || [],
      material_slots: action.material_slots || [],
      configurable: true
    });
  }
  if (action.type === 'create_option_group') {
    next.option_groups.push({
      option_group_id: action.option_group_id,
      label: action.label,
      applies_to_parts: action.applies_to_parts,
      control_type: action.control_type,
      effect_type: action.effect_type,
      options: []
    });
  }
  if (action.type === 'create_pricing_rule') {
    next.pricing.rules.push(action.pricing_rule);
  }
  return next;
}

module.exports = { applyBuilderAction };
