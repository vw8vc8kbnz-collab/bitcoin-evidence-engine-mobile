const ACTIONS = [
  { id:'link_part', label:'Koppel aan onderdeel', requires_isolation:false },
  { id:'material', label:'Materiaal / textuur', requires_isolation:true },
  { id:'dimension', label:'Maatoptie', requires_isolation:false },
  { id:'variant', label:'Variant / zichtbaarheid', requires_isolation:true },
  { id:'pricing', label:'Prijsregel', requires_isolation:false },
  { id:'rule', label:'Regel / waarschuwing', requires_isolation:false },
  { id:'order', label:'Orderdata', requires_isolation:false }
];

function actionsForSelection(selection, configurability) {
  const blocked = configurability.overall_status === 'blocked';
  return ACTIONS.map(action => ({
    ...action,
    enabled: !(blocked && action.requires_isolation),
    disabled_reason: blocked && action.requires_isolation ? 'selection_not_isolable' : null
  }));
}

module.exports = { ACTIONS, actionsForSelection };
