function validatePartMappings({ parts = [], mesh_inventory = [], intended_configurable_parts = [] }) {
  const issues = [];
  const meshIds = new Set(mesh_inventory.map(m => m.mesh_id));

  for (const part of parts) {
    if (part.configurable && (!part.mesh_targets || !part.mesh_targets.length)) {
      issues.push({ severity:'blocking', type:'part_without_mesh_target', part_id:part.part_id });
    }
    for (const mesh of part.mesh_targets || []) {
      if (!meshIds.has(mesh)) issues.push({ severity:'blocking', type:'mesh_target_missing', part_id:part.part_id, mesh_id:mesh });
    }
  }

  const assigned = new Map();
  for (const part of parts) {
    for (const mesh of part.mesh_targets || []) {
      if (!assigned.has(mesh)) assigned.set(mesh, []);
      assigned.get(mesh).push(part.part_id);
    }
  }
  for (const [mesh, partIds] of assigned.entries()) {
    if (partIds.length > 1) issues.push({ severity:'warning', type:'mesh_assigned_to_multiple_parts', mesh_id:mesh, part_ids:partIds });
  }

  return { valid: !issues.some(i => i.severity === 'blocking'), issues };
}

module.exports = { validatePartMappings };
