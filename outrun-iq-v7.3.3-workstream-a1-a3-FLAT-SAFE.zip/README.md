# Outrun IQ — v6.0 · Twee Werelden (accounts + Partner)

Next.js 15 / React 19. **Geen demo-data, geen nepfoto's.** De app start leeg en wordt gevuld
via de Seller Hub. Volledige testloop zonder echt geld:

**seller plaatst listing (foto's → AI-prijsadvies → strategie → publiceer) → koper ziet hem
overal → koper plaatst testorder → escrow-stepper → seller bevestigt & plant levering →
koper bevestigt ontvangst → uitbetaling zichtbaar onder Geld.**

## Wat zit erin
- **AI Model Abstraction Layer** (`lib/ai/`) — Masterplan V1.1 Amendment 3. Provider is een
  vervangbaar component. Nu: **DeepSeek** (`deepseek-chat`, JSON-mode, 25s timeout, sanity-checks)
  met **heuristische fallback** zonder key of bij storing. De bron staat eerlijk in de UI
  (`DEEPSEEK` of `HEURISTIEK`, incl. lagere confidence bij heuristiek).
- **Datastore**: dependency-vrije JSON-store (`data/db.json`, atomisch weggeschreven,
  geserialiseerde writes). Bewust gekozen: nul native-module-buildrisico op de VPS.
  Swap naar Postgres = alleen `lib/store.ts`/`lib/data.ts` vervangen (zelfde exports).
- **Foto-uploads** naar `public/uploads/` (max 8 per listing, 8MB, jpeg/png/webp/heic).
  Zonder foto toont de app een nette illustratie — nooit nepbeeld.
- **Seller Hub-gate**: PIN via `SELLER_PIN` (cookie, 30 dagen). Geen PIN gezet = open (alleen lokaal doen).
- **Orders**: statusmachine `paid → confirmed → delivery_planned → delivered_buyer_confirmed → paid_out`,
  commissie 10%, escrow-taal overal, alles gemarkeerd als testmodus.

## Environment (`.env`)
```
DEEPSEEK_API_KEY=sk-...   # plakken, herstarten, klaar
AI_PROVIDER=              # leeg = automatisch
REQUIRE_AUTH=hard         # hard = account verplicht (pilot) | soft = gastmodus
ADMIN_PIN=kies-iets       # voor /beheer?pin=... (partners goedkeuren)
```

## Lokaal
```bash
npm install && npm run dev   # http://localhost:3000
```

## Workflow: zip → GitHub → VPS → Termius
1. **Eenmalig lokaal:** `git init -b main && git add -A && git commit -m "v5.1" && git remote add origin git@github.com:JOUW-GEBRUIKER/outrun-iq.git && git push -u origin main`
2. **Eenmalig VPS:** `REPO=` aanpassen in `deploy.sh` → `bash deploy.sh` → daarna
   `nano /var/www/outrun-iq/.env` → key + PIN plakken → `pm2 restart outrun-iq --update-env`
3. **Elke update (Termius):**
```bash
cd /var/www/outrun-iq && git pull && npm install --no-audit --no-fund && npm run build && pm2 restart outrun-iq --update-env
```
   **API-key wisselen zonder update:** `nano .env` → plakken → `pm2 restart outrun-iq --update-env`

## Eerlijke status
- Ongetest gebouwd (geen npm in de bouwomgeving); kleine buildfixes mogelijk.
- Betalingen zijn **gesimuleerd** (geen Stripe) — dat is bewust module M4.
- AI is nu tekst-reasoning (titel/merk/conditie/nieuwprijs als anker); échte foto-vision
  en marktscan komen via dezelfde abstraction layer.
- `data/db.json` + `public/uploads/` staan in `.gitignore`: testdata overleeft `git pull`.
- Desktop (≥1024px) volledig ondersteund: topnav + grids (koper), sidebar (seller). Mobiel ongewijzigd.
- Voor publieke tests: domein + TLS (nginx/Caddy) vóór poort 8795.
