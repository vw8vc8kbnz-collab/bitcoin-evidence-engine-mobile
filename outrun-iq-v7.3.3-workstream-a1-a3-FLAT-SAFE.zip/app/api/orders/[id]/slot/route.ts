import { NextResponse, type NextRequest } from "next/server";
import { getUser } from "@/lib/auth";
import { chooseSlot } from "@/lib/data";
export const runtime = "nodejs";

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const u = await getUser();
  if (!u) return NextResponse.json({ error: "Log in" }, { status: 401 });
  const { id } = await ctx.params;
  const b = await req.json().catch(() => ({}));
  const out = await chooseSlot(u.id, id, String(b.at));
  return "error" in out ? NextResponse.json(out, { status: 400 }) : NextResponse.json(out);
}
