import { NextResponse, type NextRequest } from "next/server";
import { getUser } from "@/lib/auth";
import { mutate } from "@/lib/store";
export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  const u = await getUser();
  if (!u) return NextResponse.json({ error: "Log eerst in" }, { status: 401 });
  if (!u.partnerProfile) {
    return NextResponse.json({
      error: "Partneraanvragen verlopen via een apart zakelijk account. Een persoonlijk kopersaccount kan niet worden omgezet."
    }, { status: 409 });
  }
  if (u.partnerProfile.status === "approved") {
    return NextResponse.json({ error: "Dit partneraccount is al goedgekeurd" }, { status: 409 });
  }
  if (u.partnerProfile.status === "pending") {
    return NextResponse.json({ error: "Je aanvraag is al in behandeling" }, { status: 409 });
  }
  const b = await req.json().catch(() => ({}));
  const companyName = String(b.companyName ?? "").trim().slice(0, 80);
  const kvk = String(b.kvk ?? "").replace(/\D/g, "");
  const city = String(b.city ?? "").trim().slice(0, 40);
  if (b.termsAccepted !== true) {
    return NextResponse.json({ error: "Akkoord met de Partnervoorwaarden is verplicht" }, { status: 400 });
  }
  if (companyName.length < 2 || kvk.length !== 8 || city.length < 2) {
    return NextResponse.json({ error: "Bedrijfsnaam, geldig KvK-nummer (8 cijfers) en plaats zijn verplicht" }, { status: 400 });
  }
  await mutate(db => {
    const me = db.users.find(x => x.id === u.id)!;
    me.partnerProfile = { companyName, kvk, city, status: "pending", termsAcceptedAt: new Date().toISOString(), appliedAt: new Date().toISOString() };
  });
  return NextResponse.json({ ok: true });
}
