import { NextResponse, type NextRequest } from "next/server";
import { read, mutate } from "@/lib/store";
import { verifyPassword, createSession, SESSION_COOKIE, rateLimit, isApprovedPartner } from "@/lib/auth";
export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  const b = await req.json().catch(() => ({}));
  const e = String(b.email ?? "").trim().toLowerCase();
  const pass = String(b.password ?? "");
  if (!rateLimit(`login:${e}`, 8, 10 * 60_000)) {
    return NextResponse.json({ error: "Te veel pogingen. Wacht 10 minuten." }, { status: 429 });
  }
  const db = await read();
  const u = db.users.find(x => x.email === e);
  if (!u || !verifyPassword(pass, u.salt, u.passHash)) {
    return NextResponse.json({ error: "E-mail of wachtwoord onjuist" }, { status: 401 });
  }
  const { token, expires } = await createSession(u.id);
  const adminMail = (process.env.ADMIN_EMAIL ?? "").trim().toLowerCase();
  if (adminMail && u.email === adminMail && u.role !== "admin") {
    await mutate(db => { const me = db.users.find(x => x.id === u.id); if (me) me.role = "admin"; });
    u.role = "admin";
  }
  const res = NextResponse.json({ ok: true, role: u.role, partner: isApprovedPartner(u), partnerPending: u.partnerProfile?.status === "pending", name: u.name });
  res.cookies.set(SESSION_COOKIE, token, { httpOnly: true, sameSite: "lax", path: "/", expires });
  return res;
}
