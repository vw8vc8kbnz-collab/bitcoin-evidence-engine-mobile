import { NextResponse, type NextRequest } from "next/server";
import { mutate } from "@/lib/store";
export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  const b = await req.json().catch(() => ({}));
  if (!process.env.ADMIN_PIN || b.pin !== process.env.ADMIN_PIN) {
    return NextResponse.json({ error: "Geen toegang" }, { status: 401 });
  }
  const out = await mutate(db => {
    const s = db.sellers.find(x => x.slug === String(b.slug));
    if (!s) return { error: "Partner niet gevonden" };
    s.trusted = b.trusted === true;
    return { ok: true, trusted: s.trusted };
  });
  return "error" in out ? NextResponse.json(out, { status: 404 }) : NextResponse.json(out);
}
