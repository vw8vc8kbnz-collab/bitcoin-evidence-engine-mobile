import { NextResponse, type NextRequest } from "next/server";
import { mutate } from "@/lib/store";
export const runtime = "nodejs";

/** Beheer: geëscaleerde retour afsluiten (na contact buitenom). */
export async function POST(req: NextRequest) {
  const b = await req.json().catch(() => ({}));
  if (!process.env.ADMIN_PIN || b.pin !== process.env.ADMIN_PIN) {
    return NextResponse.json({ error: "Geen toegang" }, { status: 401 });
  }
  const out = await mutate(db => {
    const o = db.orders.find(x => x.id === String(b.orderId));
    if (!o?.returnRequest || o.returnRequest.status !== "escalated") return { error: "Geen geëscaleerde retour" };
    o.returnRequest.status = "completed";
    o.returnRequest.completedAt = new Date().toISOString();
    o.returnRequest.instructions = (o.returnRequest.instructions ?? "") + " [Afgehandeld door Outrun IQ]";
    db.notifications.push({
      id: Math.random().toString(36).slice(2, 10), userId: o.buyerId, type: "order",
      title: "Retour afgehandeld door Outrun IQ", body: `${o.id} is afgesloten.`,
      href: `/order/${o.id}`, read: false, at: new Date().toISOString(),
    });
    return { ok: true };
  });
  return "error" in out ? NextResponse.json(out, { status: 404 }) : NextResponse.json(out);
}
