import Link from "next/link";
import { read } from "@/lib/store";
import { getUser } from "@/lib/auth";
import { sweepOrders } from "@/lib/data";
import { eur } from "@/lib/types";
import { Mark } from "@/components/icons";
import { Empty } from "@/components/Empty";

export const dynamic = "force-dynamic";

const fmt = (iso: string) => new Date(iso).toLocaleDateString("nl-NL", { day: "numeric", month: "short" });

export default async function Geld() {
  await sweepOrders();
  const db = await read();
  const user = await getUser();
  const orders = db.orders.filter(o => o.sellerSlug === user?.partnerSlug).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  const escrow = orders.filter(o => !["paid_out", "cancelled"].includes(o.status));
  const paid = orders.filter(o => o.status === "paid_out");
  const d30 = Date.now() - 30 * 864e5;
  return (
    <main className="page">
      <header className="hd">
        <Link href="/partner" className="lock" style={{ color: "#fff" }}><Mark glow />Geld</Link>
        <span className="sp" />
      </header>
      <div className="big"><label>IN ESCROW · ONDERWEG NAAR JE REKENING</label>
        <b>{eur(escrow.reduce((s, o) => s + o.sellerNet, 0))}</b></div>
      <div className="dkchips">
        <span className="dkc"><label>UITBETAALD 30D</label><b>{eur(paid.filter(o => +new Date(o.createdAt) > d30).reduce((s, o) => s + o.sellerNet, 0))}</b></span>
        <span className="dkc"><label>COMMISSIE 30D</label><b>{eur(paid.filter(o => +new Date(o.createdAt) > d30).reduce((s, o) => s + o.commission, 0))}</b></span>
      </div>
      {orders.length === 0 && <Empty title="Nog geen geldstromen" text="Uitbetalingen en escrow-bedragen verschijnen hier per order, netto na 10% commissie." />}
      {orders.length > 0 && <div className="dsec"><h2>Per order</h2><span>NA 10% COMMISSIE</span></div>}
      {orders.map(o => (
        <div key={o.id} className="pay">
          <b>{o.itemTitle} · {o.id}{o.partnerRef ? ` · ${o.partnerRef}` : ""}<small>{fmt(o.createdAt)} · {o.status.replaceAll("_", " ").toUpperCase()}</small></b>
          <span className={`flag ${o.status === "paid_out" ? "ok3" : "hot"}`}>{o.status === "paid_out" ? "BETAALD" : "IN ESCROW"}</span>
          <span className="amt2">{eur(o.sellerNet)}</span>
        </div>
      ))}
      <p className="note">Uitbetaling volgt automatisch zodra de koper de levering bevestigt (testmodus: direct).</p>
    </main>
  );
}
