import Link from "next/link";
import { read } from "@/lib/store";
import { getUser } from "@/lib/auth";
import { eur } from "@/lib/types";
import { Mark } from "@/components/icons";
import { Img } from "@/components/Img";
import { Empty } from "@/components/Empty";
import { ListingActions } from "@/components/ListingActions";

export const dynamic = "force-dynamic";

export default async function Voorraad() {
  const db = await read();
  const user = await getUser();
  const listings = db.listings.filter(l => l.sellerSlug === user?.partnerSlug).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  const live = listings.filter(l => l.status === "active");
  return (
    <main className="page">
      <header className="hd">
        <Link href="/partner" className="lock" style={{ color: "#fff" }}><Mark glow />Voorraad</Link>
        <span className="sp" /><span className="mini" style={{ color: "#8B96A0" }}>{live.length} LIVE</span>
      </header>
      <div className="dkchips" style={{ marginTop: 2 }}>
        <span className="dkc"><label>LIVE</label><b>{live.length}</b></span>
        <span className="dkc"><label>VERKOCHT</label><b>{listings.filter(l => l.status === "sold").length}</b></span>
        <span className="dkc"><label>AI-GEPRIJSD</label><b>{listings.filter(l => l.aiSource === "deepseek").length}</b></span>
      </div>
      {listings.length === 0 && (
        <>
          <Empty title="Nog geen listings" text="Plaats je eerste product — foto's erbij, AI-prijsadvies, publiceren. Klaar in twee minuten." />
          <div className="foot"><Link href="/partner/nieuw" className="btn pri">+ Nieuw product</Link></div>
        </>
      )}
      {listings.length > 0 && <div className="dsec"><h2>Listings</h2><span>NIEUWSTE EERST</span></div>}
      {listings.map(l => (
        <div key={l.id} style={{ marginBottom: 4 }}>
        <div className="orow">
          <Img src={l.photos[0]} fallback={l.fallback} dark />
          <span>
            <b>{l.title}</b>
            <span>{l.views} VIEWS · CONF. {l.confidence} · {l.aiSource.toUpperCase()}</span>
          </span>
          <span className="amt">{eur(l.price)}{l.perUnit ? "/st" : ""}<i>
            <span className={`flag ${l.status === "active" ? "ok3" : "hot"}`}>
              {l.status === "active" ? `LIVE · ${l.stock} ST` : l.status.toUpperCase()}
            </span></i>
          </span>
        </div>
        <ListingActions id={l.id} status={l.status} price={l.price} newPrice={l.newPrice} />
        </div>
      ))}
    </main>
  );
}
