import { BuyerDock, TopNav } from "@/components/Dock";
import { SplashIntro } from "@/components/SplashIntro";

export default function BuyerLayout({
  children, modal,
}: { children: React.ReactNode; modal: React.ReactNode }) {
  return (
    <div className="app">
      <SplashIntro />
      <TopNav />
      {children}
      {modal}
      <BuyerDock />
    </div>
  );
}
