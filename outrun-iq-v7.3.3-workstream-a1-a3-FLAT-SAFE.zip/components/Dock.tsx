"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Mark } from "./icons";

const I = {
  home: <path d="M4 11l8-7 8 7v9h-6v-6h-4v6H4z" />,
  search: <><circle cx="11" cy="11" r="6.5" /><path d="M20 20l-4.2-4.2" /></>,
  saved: <path d="M6 3h12v18l-6-4-6 4z" />,
  user: <><circle cx="12" cy="8.5" r="3.5" /><path d="M5 19c1.2-3 4-4.5 7-4.5s5.8 1.5 7 4.5" /></>,
  grid: <><rect x="4" y="4" width="7" height="7" rx="1.5" /><rect x="13" y="4" width="7" height="7" rx="1.5" /><rect x="4" y="13" width="7" height="7" rx="1.5" /><rect x="13" y="13" width="7" height="7" rx="1.5" /></>,
  list: <path d="M4 6h16M4 12h16M4 18h10" />,
  orders: <path d="M5 4h14v16l-3-2-2 2-2-2-2 2-2-2-3 2z" />,
  money: <><path d="M4 17l5-5 4 3 7-8" /><path d="M15 7h5v5" /></>,
  store: <><rect x="4" y="4" width="16" height="16" rx="3" /><path d="M4 10h16M10 10v10" /></>,
};

function useActive(href: string, exact: boolean) {
  const path = usePathname();
  return exact ? path === href : path.startsWith(href);
}

function Tab({ href, icon, label, exact = false }:{
  href: string; icon: keyof typeof I; label: string; exact?: boolean;
}) {
  const on = useActive(href, exact);
  return (
    <Link href={href} className={`t${on ? " on" : ""}`}>
      <svg viewBox="0 0 24 24">{I[icon]}</svg>{label}
    </Link>
  );
}

/* ===== Mobiel: docks ===== */
export function BuyerDock() {
  return (
    <nav className="dock" aria-label="Navigatie">
      <Tab href="/" icon="home" label="ONTDEK" exact />
      <Tab href="/zoeken" icon="search" label="ZOEKEN" />
      <Link href="/vinder" className="plus" aria-label="AI Vinder">
        <svg viewBox="0 0 24 24"><path d="M12 3l1.8 5.3L19 10l-5.2 1.7L12 17l-1.8-5.3L5 10l5.2-1.7z" /><path d="M18.5 15.5l.9 2.6 2.6.9-2.6.9-.9 2.6-.9-2.6-2.6-.9 2.6-.9z" /></svg>
      </Link>
      <Tab href="/bewaard" icon="saved" label="BEWAARD" />
      <Tab href="/account" icon="user" label="ACCOUNT" />
    </nav>
  );
}

export function SellerDock() {
  return (
    <nav className="dock dk" aria-label="Partner-navigatie">
      <Tab href="/partner" icon="grid" label="DASH" exact />
      <Tab href="/partner/voorraad" icon="list" label="VOORRAAD" />
      <Link href="/partner/nieuw" className="plus" aria-label="Nieuw product">
        <svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14" /></svg>
      </Link>
      <Tab href="/partner/orders" icon="orders" label="ORDERS" />
      <Tab href="/partner/geld" icon="money" label="GELD" />
    </nav>
  );
}

/* ===== Desktop: topnav (koper) ===== */
function NavLink({ href, label, exact = false }:{ href: string; label: string; exact?: boolean }) {
  const on = useActive(href, exact);
  return <Link href={href} className={`nl${on ? " on" : ""}`}>{label}</Link>;
}

export function TopNav() {
  return (
    <header className="topnav" aria-label="Hoofdnavigatie">
      <Link href="/" className="lock"><Mark size={28} />OUTRUN <b>IQ</b></Link>
      <nav className="links">
        <NavLink href="/" label="Ontdek" exact />
        <NavLink href="/zoeken" label="Zoeken" />
        <NavLink href="/bewaard" label="Bewaard" />
        <NavLink href="/account" label="Account" />
      </nav>
      <span className="sp" />
      <form action="/zoeken" className="srchbar tsrch">
        <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="6.5" /><path d="M20 20l-4.2-4.2" /></svg>
        <input name="q" placeholder="Zoek producten, merken of stores" autoComplete="off" />
      </form>
      <Link href="/vinder" className="sellcta">✦ AI Vinder</Link>
    </header>
  );
}

/* ===== Desktop: sidebar (seller) ===== */
function SideLink({ href, icon, label, exact = false }:{
  href: string; icon: keyof typeof I; label: string; exact?: boolean;
}) {
  const on = useActive(href, exact);
  return (
    <Link href={href} className={`sl${on ? " on" : ""}`}>
      <svg viewBox="0 0 24 24">{I[icon]}</svg>{label}
    </Link>
  );
}

export function SellerSide() {
  return (
    <aside className="sidenav" aria-label="Partner-navigatie">
      <Link href="/partner" className="lock" style={{ color: "#fff" }}><Mark size={26} glow />PARTNER <b style={{ color: "var(--petrol-glow)" }}>HUB</b></Link>
      <nav>
        <SideLink href="/partner" icon="grid" label="Dashboard" exact />
        <SideLink href="/partner/voorraad" icon="list" label="Voorraad" />
        <SideLink href="/partner/orders" icon="orders" label="Orders" />
        <SideLink href="/partner/geld" icon="money" label="Geld" />
        <SideLink href="/partner/storefront" icon="store" label="Storefront" />
      </nav>
      <Link href="/partner/nieuw" className="sellcta side">+ Nieuw product</Link>
      <Link href="/" className="sl back2buy">← Naar de shop</Link>
    </aside>
  );
}
