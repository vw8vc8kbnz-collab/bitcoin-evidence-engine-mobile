"use client";
import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";

/** Overlay-sheet. v6.3: animeert HOOGTE i.p.v. translateY, zodat .sbody exact het
 *  zichtbare deel vult en de onderkant van de content ALTIJD bereikbaar is. */
const SNAPS = [0.55, 0.92];

export function BottomSheet({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const [h, setH] = useState(0);            // fractie van viewporthoogte
  const [drag, setDrag] = useState(false);
  const start = useRef({ y: 0, h: SNAPS[0] });

  useEffect(() => {
    const t = requestAnimationFrame(() => setH(SNAPS[0]));  // intrede-animatie
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const esc = (e: KeyboardEvent) => e.key === "Escape" && router.back();
    window.addEventListener("keydown", esc);
    return () => {
      cancelAnimationFrame(t);
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", esc);
    };
  }, [router]);

  function down(e: React.PointerEvent) {
    setDrag(true);
    start.current = { y: e.clientY, h };
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  }
  function move(e: React.PointerEvent) {
    if (!drag) return;
    const next = start.current.h + (start.current.y - e.clientY) / window.innerHeight;
    setH(Math.min(0.96, Math.max(0.1, next)));
  }
  function up() {
    if (!drag) return;
    setDrag(false);
    if (h < 0.3) { router.back(); return; }
    setH(SNAPS.reduce((a, b) => (Math.abs(b - h) < Math.abs(a - h) ? b : a)));
  }

  return (
    <>
      <div className="scrim" onClick={() => router.back()} />
      <div
        className="sheet"
        style={{ height: `${h * 100}dvh`, transition: drag ? "none" : "height .32s cubic-bezier(.32,.72,.28,1)" }}
        role="dialog" aria-modal="true"
      >
        <div className="sgrab" onPointerDown={down} onPointerMove={move} onPointerUp={up} onPointerCancel={up}>
          <i />
        </div>
        <div className="sbody">{children}</div>
      </div>
    </>
  );
}
