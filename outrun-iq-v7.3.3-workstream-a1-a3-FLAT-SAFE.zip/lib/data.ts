import { read, mutate } from "./store";
import { COMMISSION, slugify } from "./types";
import type { DB, Listing, Order, OrderStatus, Seller, User, Notification, SavedItem, Address, Bid } from "./types";
import { sendWebPush } from "./push";
export { eur } from "./types";
export type { Listing, Order, Seller, OrderStatus, User };

function pushNote(db: DB, userId: string, type: Notification["type"], title: string, body: string, href: string) {
  db.notifications.push({
    id: Math.random().toString(36).slice(2, 10), userId, type, title, body, href,
    read: false, at: new Date().toISOString(),
  });
  // Web Push naar alle apparaten van deze user (fire-and-forget; faalt stil zonder keys)
  sendWebPush(db.pushSubs.filter(x => x.userId === userId), { title, body, href });
}

export async function getNotifications(userId: string) {
  const db = await read();
  return db.notifications.filter(n => n.userId === userId)
    .sort((a, b) => b.at.localeCompare(a.at)).slice(0, 60);
}

export async function unreadCount(userId: string) {
  const db = await read();
  return db.notifications.filter(n => n.userId === userId && !n.read).length;
}

export async function markNotificationsRead(userId: string) {
  return mutate(db => { db.notifications.forEach(n => { if (n.userId === userId) n.read = true; }); });
}

export async function getSaved(userId: string): Promise<{ item: SavedItem; listing: Listing }[]> {
  const db = await read();
  return db.saved.filter(s => s.userId === userId)
    .map(item => ({ item, listing: db.listings.find(l => l.id === item.listingId)! }))
    .filter(x => x.listing);
}

export async function toggleSaved(userId: string, listingId: string): Promise<boolean> {
  return mutate(db => {
    const i = db.saved.findIndex(s => s.userId === userId && s.listingId === listingId);
    if (i >= 0) { db.saved.splice(i, 1); return false; }
    const l = db.listings.find(x => x.id === listingId);
    db.saved.push({ userId, listingId, savedAtPrice: l?.price ?? 0, at: new Date().toISOString() });
    return true;
  });
}

export async function getActiveListings(): Promise<Listing[]> {
  const db = await read();
  return db.listings
    .filter(l => l.status === "active" && l.stock > 0)
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export async function searchListings(q: string): Promise<Listing[]> {
  const all = await getActiveListings();
  if (!q) return all;
  const n = q.toLowerCase();
  return all.filter(l =>
    [l.title, l.brand, l.condition, l.category, l.sellerSlug].join(" ").toLowerCase().includes(n));
}

export async function getListing(id: string): Promise<Listing | undefined> {
  const db = await read();
  return db.listings.find(l => l.id === id);
}

export async function getSeller(slug: string): Promise<Seller | undefined> {
  const db = await read();
  return db.sellers.find(s => s.slug === slug);
}

export async function getSellerStats(slug: string) {
  const db = await read();
  const listings = db.listings.filter(l => l.sellerSlug === slug);
  const orders = db.orders.filter(o => o.sellerSlug === slug);
  const paidOut = orders.filter(o => o.status === "paid_out");
  const inEscrow = orders.filter(o => !["paid_out", "cancelled"].includes(o.status));
  const d30 = Date.now() - 30 * 864e5;
  const rev30 = paidOut.filter(o => +new Date(o.createdAt) > d30)
    .reduce((s, o) => s + o.sellerNet, 0);
  const daily = Array.from({ length: 30 }, (_, i) => {
    const day = new Date(Date.now() - (29 - i) * 864e5).toISOString().slice(0, 10);
    return paidOut.filter(o => o.createdAt.slice(0, 10) === day)
      .reduce((s, o) => s + o.sellerNet, 0);
  });
  const sold = db.listings.filter(l => l.sellerSlug === slug && l.status === "sold").length;
  return {
    listings, orders,
    activeCount: listings.filter(l => l.status === "active").length,
    rev30,
    inEscrowSum: inEscrow.reduce((s, o) => s + o.sellerNet, 0),
    paidOut30: rev30,
    commission30: paidOut.filter(o => +new Date(o.createdAt) > d30).reduce((s, o) => s + o.commission, 0),
    sellThrough: listings.length ? Math.round((sold / listings.length) * 1000) / 10 : 0,
    daily,
  };
}

/** Eén test-seller-profiel voor de gate-fase; wordt aangemaakt/bijgewerkt in de nieuw-flow. */
export async function upsertSeller(input: { name: string; city: string; kvk?: string }): Promise<Seller> {
  return mutate(db => {
    const slug = slugify(input.name);
    let s = db.sellers.find(x => x.slug === slug);
    if (!s) {
      s = { slug, name: input.name, city: input.city, kvk: input.kvk, createdAt: new Date().toISOString() };
      db.sellers.push(s);
    } else { s.city = input.city; if (input.kvk) s.kvk = input.kvk; }
    return s;
  });
}

export async function createListing(l: Omit<Listing, "id" | "createdAt" | "views" | "status">): Promise<Listing> {
  return mutate(db => {
    let id = slugify(l.title) || "listing";
    while (db.listings.some(x => x.id === id)) id += "-" + Math.random().toString(36).slice(2, 5);
    const rec: Listing = { ...l, id, status: "active", views: 0, createdAt: new Date().toISOString() };
    db.listings.push(rec);
    return rec;
  });
}

export async function setListingStatus(id: string, status: Listing["status"]) {
  return mutate(db => {
    const l = db.listings.find(x => x.id === id);
    if (l) l.status = status;
    return l;
  });
}

export async function bumpViews(id: string) {
  // fire-and-forget; fouten negeren
  mutate(db => { const l = db.listings.find(x => x.id === id); if (l) l.views++; }).catch(() => {});
}

export async function createOrder(buyerId: string, listingId: string, deliveryChoice: "bezorgen" | "ophalen", address?: Address, bidId?: string): Promise<Order | { error: string }> {
  return mutate(db => {
    const l = db.listings.find(x => x.id === listingId);
    if (!l || l.status !== "active" || l.stock < 1) return { error: "Listing niet beschikbaar" };
    const self = db.users.find(x => x.id === buyerId);
    if (!self || self.role !== "consument" || self.partnerProfile) {
      return { error: "Kopen kan alleen met een persoonlijk kopersaccount" };
    }
    if (self.partnerSlug === l.sellerSlug) return { error: "Je kunt je eigen listing niet kopen" };
    let itemPrice = l.price;
    if (bidId) {
      const bid = db.bids.find(b => b.id === bidId);
      if (!bid || bid.buyerId !== buyerId || bid.listingId !== l.id || bid.status !== "accepted") {
        return { error: "Dit bod is niet (meer) geldig" };
      }
      itemPrice = bid.amount;
      bid.status = "used";
    }
    const deliveryPrice = deliveryChoice === "bezorgen" ? l.deliveryPrice : 0;
    const commission = Math.round(itemPrice * COMMISSION);
    db.counters.order++;
    const id = `OIQ-${new Date().getFullYear()}-${String(db.counters.order).padStart(4, "0")}`;
    const now = new Date().toISOString();
    const o: Order = {
      id, buyerId, listingId, sellerSlug: l.sellerSlug, itemTitle: l.title,
      partnerRef: l.partnerRef,
      deliveryAddress: deliveryChoice === "bezorgen" ? address : undefined,
      pickupCode: deliveryChoice === "ophalen"
        ? Array.from({ length: 6 }, () => "ACDEFHJKLMNPRTVWXY23456789"[Math.floor(Math.random() * 26)]).join("")
        : undefined,
      itemPrice, deliveryChoice, deliveryPrice, bidId,
      totalPaid: itemPrice + deliveryPrice, commission, sellerNet: itemPrice - commission,
      status: "paid",
      events: [{ status: "paid", at: now, note: "Testmodus — geen echte betaling. Geld zou nu in escrow staan." }],
      createdAt: now,
    };
    db.orders.push(o);
    l.stock--; if (l.stock === 0) l.status = "sold";
    const partner = db.users.find(u => u.partnerSlug === l.sellerSlug);
    if (partner) pushNote(db, partner.id, "order", "Nieuwe order", `${l.title} · ${id}`, "/partner/orders");
    return o;
  });
}

export async function getOrder(id: string): Promise<Order | undefined> {
  const db = await read();
  return db.orders.find(o => o.id === id);
}

export async function disputeOrder(id: string, buyerId: string, category: string, text: string) {
  return mutate(db => {
    const o = db.orders.find(x => x.id === id);
    if (!o || o.buyerId !== buyerId) return { error: "Niet jouw order" };
    if (["paid_out", "cancelled", "disputed"].includes(o.status)) return { error: "Deze order kan niet (meer) betwist worden" };
    o.dispute = { category, text, at: new Date().toISOString() };
    o.status = "disputed";
    o.events.push({ status: "disputed", at: new Date().toISOString(), note: `${category}: ${text.slice(0, 80)}` });
    const partner = db.users.find(u => u.partnerSlug === o.sellerSlug);
    if (partner) pushNote(db, partner.id, "order", "Probleem gemeld op order", `${o.itemTitle} · ${o.id} · ${category}`, "/partner/orders");
    pushNote(db, o.buyerId, "order", "Je melding is ontvangen", `${o.id} is bevroren; uitbetaling geblokkeerd tot afhandeling.`, `/order/${o.id}`);
    return { ok: true };
  });
}

/** Beheer: dispute afhandelen. release = alsnog uitbetalen; cancel = annuleren + voorraad terug. */
export async function resolveDispute(id: string, action: "release" | "cancel") {
  return mutate(db => {
    const o = db.orders.find(x => x.id === id);
    if (!o || o.status !== "disputed") return { error: "Geen openstaande dispute" };
    const now = new Date().toISOString();
    if (action === "cancel") {
      o.status = "cancelled";
      o.events.push({ status: "cancelled", at: now, note: "Geannuleerd na dispute (beheer)." });
      const l = db.listings.find(x => x.id === o.listingId);
      if (l) { l.stock++; if (l.status === "sold") l.status = "active"; }
      pushNote(db, o.buyerId, "order", "Order geannuleerd", `${o.id} — je melding is afgehandeld.`, `/order/${o.id}`);
    } else {
      o.status = "paid_out";
      o.events.push({ status: "paid_out", at: now, note: "Dispute afgewezen — uitbetaling vrijgegeven (beheer)." });
      pushNote(db, o.buyerId, "order", "Melding afgehandeld", `${o.id} — de uitbetaling is vrijgegeven.`, `/order/${o.id}`);
    }
    const partner = db.users.find(u => u.partnerSlug === o.sellerSlug);
    if (partner) pushNote(db, partner.id, action === "cancel" ? "order" : "payout",
      action === "cancel" ? "Order geannuleerd na dispute" : "Uitbetaling vrijgegeven na dispute",
      `${o.itemTitle} · ${o.id}`, "/partner/orders");
    return { ok: true };
  });
}

export function paidOutAt(o: Order): string | undefined {
  return o.events.find(e => e.status === "paid_out")?.at;
}

export async function requestReturn(orderId: string, buyerId: string, reason: string) {
  return mutate(db => {
    const o = db.orders.find(x => x.id === orderId);
    if (!o || o.buyerId !== buyerId) return { error: "Niet jouw order" };
    if (!["delivered", "paid_out"].includes(o.status)) {
      return { error: "Retour kan vanaf het moment van levering" };
    }
    if (o.returnRequest) return { error: "Er loopt al een retouraanvraag" };
    if (o.status === "paid_out") {
      const paidAt = paidOutAt(o);
      if (!paidAt || Date.now() - +new Date(paidAt) > RETURN_WINDOW_DAYS * 864e5) {
        return { error: `De retourtermijn van ${RETURN_WINDOW_DAYS} dagen is verstreken` };
      }
    }
    const now = new Date();
    o.returnRequest = {
      reason, at: now.toISOString(),
      deadlineAt: new Date(+now + RETURN_RESPONSE_DAYS * 864e5).toISOString(),
      status: "requested",
    };
    const partner = db.users.find(u => u.partnerSlug === o.sellerSlug);
    if (partner) pushNote(db, partner.id, "order", "Retouraanvraag ontvangen",
      `${o.itemTitle} · ${o.id} — reageer binnen ${RETURN_RESPONSE_DAYS} dagen met instructies.`, "/partner/orders");
    pushNote(db, buyerId, "order", "Retouraanvraag verstuurd",
      `${o.id} — de partner reageert binnen ${RETURN_RESPONSE_DAYS} dagen met instructies.${o.status !== "paid_out" ? " De uitbetaling is gepauzeerd zolang je aanvraag loopt." : ""}`, `/order/${o.id}`);
    return { ok: true };
  });
}

export async function respondReturn(orderId: string, partnerSlug: string, instructions: string) {
  return mutate(db => {
    const o = db.orders.find(x => x.id === orderId);
    if (!o || o.sellerSlug !== partnerSlug) return { error: "Niet jouw order" };
    if (!o.returnRequest || !["requested", "escalated"].includes(o.returnRequest.status)) {
      return { error: "Geen openstaande retouraanvraag" };
    }
    o.returnRequest.status = "responded";
    o.returnRequest.instructions = instructions;
    o.returnRequest.respondedAt = new Date().toISOString();
    pushNote(db, o.buyerId, "order", "Retourinstructies ontvangen", `${o.id} — bekijk hoe je kunt retourneren.`, `/order/${o.id}`);
    return { ok: true };
  });
}

export async function completeReturn(orderId: string, partnerSlug: string) {
  return mutate(db => {
    const o = db.orders.find(x => x.id === orderId);
    if (!o || o.sellerSlug !== partnerSlug) return { error: "Niet jouw order" };
    if (o.returnRequest?.status !== "responded") return { error: "Retour is nog niet in behandeling" };
    o.returnRequest.status = "completed";
    o.returnRequest.completedAt = new Date().toISOString();
    if (o.status !== "paid_out") {
      // geld stond nog vast: terugstorten uit escrow, order annuleren, voorraad terug
      o.status = "cancelled";
      o.events.push({ status: "cancelled", at: new Date().toISOString(), note: "Retour afgerond vóór uitbetaling — bedrag (testmodus) uit escrow terugbetaald aan koper." });
      const l = db.listings.find(x => x.id === o.listingId);
      if (l) { l.stock++; if (l.status === "sold") l.status = "active"; }
      pushNote(db, o.buyerId, "order", "Retour afgerond — geld terug",
        `${o.id} — het bedrag is (testmodus) uit escrow aan je terugbetaald.`, `/order/${o.id}`);
    } else {
      pushNote(db, o.buyerId, "order", "Retour afgerond",
        `${o.id} — de partner bevestigde ontvangst; terugbetaling volgt conform de Retourvoorwaarden (testmodus: gesimuleerd).`, `/order/${o.id}`);
    }
    return { ok: true };
  });
}

/** Klant escaleert naar Outrun IQ — kan pas ná de reactietermijn zonder partnerreactie. */
export async function escalateReturn(orderId: string, buyerId: string) {
  return mutate(db => {
    const o = db.orders.find(x => x.id === orderId);
    if (!o || o.buyerId !== buyerId) return { error: "Niet jouw order" };
    const r = o.returnRequest;
    if (!r || r.status !== "requested") return { error: "Escaleren kan alleen bij een onbeantwoorde aanvraag" };
    if (Date.now() < +new Date(r.deadlineAt)) return { error: "De partner heeft nog tijd om te reageren" };
    r.status = "escalated";
    pushNote(db, buyerId, "order", "Geëscaleerd naar Outrun IQ", `${o.id} — wij nemen het over en spreken de partner aan.`, `/order/${o.id}`);
    const partner = db.users.find(u => u.partnerSlug === o.sellerSlug);
    if (partner) pushNote(db, partner.id, "systeem", "Retour geëscaleerd — actie vereist",
      `${o.id}: geen reactie binnen de termijn. Dit telt mee voor je partnerstatus.`, "/partner/orders");
    return { ok: true };
  });
}

/** Waterdichte autorelease: 'delivered' + RELEASE_DAYS zonder bevestiging/dispute -> paid_out.
 *  Lazy sweep (geen cron): aanroepen op order-lezende pagina's; schrijft alleen bij echte releases. */
export async function sweepOrders() {
  const db = await read();
  const due = db.orders.filter(o => {
    if (o.status !== "delivered") return false;
    if (o.returnRequest && o.returnRequest.status !== "completed") return false;  // open retour = escrow bevroren
    const trusted = db.sellers.find(x => x.slug === o.sellerSlug)?.trusted;
    const cutoff = Date.now() - releaseDaysFor(trusted) * 864e5;
    return +new Date(o.events.find(e => e.status === "delivered")?.at ?? o.createdAt) < cutoff;
  });
  if (due.length === 0) return 0;
  return mutate(d => {
    let n = 0;
    for (const ref of due) {
      const o = d.orders.find(x => x.id === ref.id);
      if (!o || o.status !== "delivered" || (o.returnRequest && o.returnRequest.status !== "completed")) continue;
      o.status = "paid_out";
      const now = new Date().toISOString();
      o.events.push({ status: "delivered_buyer_confirmed", at: now, note: `Automatisch: ${releaseDaysFor(d.sellers.find(x => x.slug === o.sellerSlug)?.trusted)} dagen zonder melding.` });
      o.events.push({ status: "paid_out", at: now, note: "Automatische uitbetaling na bevestigingstermijn." });
      pushNote(d, o.buyerId, "order", "Order automatisch afgerond", `${o.id} — geen melding binnen ${releaseDaysFor(d.sellers.find(x => x.slug === o.sellerSlug)?.trusted)} dagen.`, `/order/${o.id}`);
      const partner = d.users.find(u => u.partnerSlug === o.sellerSlug);
      if (partner) pushNote(d, partner.id, "payout", "Uitbetaling vrijgegeven", `${o.itemTitle} · netto €${o.sellerNet}`, "/partner/geld");
      n++;
    }
    return n;
  });
}

const FLOW: OrderStatus[] = ["paid", "confirmed", "delivery_planned", "delivered", "delivered_buyer_confirmed", "paid_out"];
export const RELEASE_DAYS = Math.max(1, Number(process.env.ESCROW_RELEASE_DAYS) || 7);          // bewezen partners
export const RELEASE_DAYS_NEW = Math.max(RELEASE_DAYS, Number(process.env.ESCROW_RELEASE_DAYS_NEW) || 14); // nieuwe partners
export const releaseDaysFor = (trusted?: boolean) => (trusted ? RELEASE_DAYS : RELEASE_DAYS_NEW);
export const RETURN_WINDOW_DAYS = Math.max(1, Number(process.env.RETURN_WINDOW_DAYS) || 14);
export const RETURN_RESPONSE_DAYS = Math.max(1, Number(process.env.RETURN_RESPONSE_DAYS) || 3);

export async function advanceOrder(id: string, to: OrderStatus, note?: string) {
  return mutate(db => {
    const o = db.orders.find(x => x.id === id);
    if (!o) return { error: "Order niet gevonden" };
    if (o.status === "disputed") return { error: "Order is bevroren wegens een gemeld probleem" };
    const from = FLOW.indexOf(o.status), toI = FLOW.indexOf(to);
    if (toI !== from + 1) return { error: `Ongeldige overgang ${o.status} → ${to}` };
    o.status = to;
    o.events.push({ status: to, at: new Date().toISOString(), note });
    const labels: Record<string, string> = {
      confirmed: "Partner heeft je bestelling bevestigd",
      delivery_planned: "Levering wordt gepland",
      delivered: "Gemarkeerd als geleverd — bevestig ontvangst of meld een probleem binnen de bevestigingstermijn",
    };
    if (labels[to]) pushNote(db, o.buyerId, "order", labels[to], `${o.itemTitle} · ${o.id}`, `/order/${o.id}`);
    if (to === "delivered_buyer_confirmed") {
      o.status = "paid_out";
      o.events.push({ status: "paid_out", at: new Date().toISOString(), note: "Automatische uitbetaling (testmodus)." });
      const partner = db.users.find(u => u.partnerSlug === o.sellerSlug);
      if (partner) pushNote(db, partner.id, "payout", "Uitbetaling vrijgegeven", `${o.itemTitle} · netto €${o.sellerNet}`, "/partner/geld");
    }
    return o;
  });
}

/* ============ BIEDEN (v6.7) ============ */
const MASK_PATTERNS = [
  /[\w.+-]+@[\w-]+\.[\w.]+/gi,
  /(?:\+31|0031|0)\s?6[\s-]?\d{2}[\s-]?\d{2}[\s-]?\d{2}[\s-]?\d{2}/g,
  /\b\d{10,}\b/g,
  /https?:\/\/\S+|www\.\S+/gi,
  /\b(whatsapp|whats app|telegram|signal)\b/gi,
];
/** Anti-omzeiling: contactgegevens in vrije tekst afschermen. */
export function maskContact(t: string) {
  let out = t;
  for (const rx of MASK_PATTERNS) out = out.replace(rx, "[afgeschermd]");
  return out;
}

export async function placeBid(buyerId: string, listingId: string, amount: number, message?: string) {
  return mutate(db => {
    const l = db.listings.find(x => x.id === listingId);
    if (!l || l.status !== "active" || l.stock < 1) return { error: "Listing niet beschikbaar" };
    const me = db.users.find(x => x.id === buyerId);
    if (!me || me.role !== "consument" || me.partnerProfile) {
      return { error: "Bieden kan alleen met een persoonlijk kopersaccount" };
    }
    if (me.partnerSlug === l.sellerSlug) return { error: "Je kunt niet op je eigen listing bieden" };
    if (!(amount > 0 && amount < l.price)) return { error: "Een bod ligt boven \u20ac0 en onder de vraagprijs" };
    if (db.bids.some(b => b.buyerId === buyerId && b.listingId === listingId && ["open", "countered", "accepted"].includes(b.status))) {
      return { error: "Je hebt al een lopend bod op deze listing" };
    }
    const bid: Bid = {
      id: Math.random().toString(36).slice(2, 10),
      listingId, buyerId, sellerSlug: l.sellerSlug,
      amount: Math.round(amount),
      message: message ? maskContact(message).slice(0, 200) : undefined,
      status: "open", at: new Date().toISOString(),
    };
    db.bids.push(bid);
    const partner = db.users.find(u => u.partnerSlug === l.sellerSlug);
    if (partner) pushNote(db, partner.id, "order", "Nieuw bod ontvangen",
      `\u20ac${bid.amount} op ${l.title} (vraagprijs \u20ac${l.price})`, "/partner/orders");
    return { ok: true };
  });
}

export async function respondBid(partnerSlug: string, bidId: string, action: "accept" | "reject" | "counter", counterAmount?: number) {
  return mutate(db => {
    const b = db.bids.find(x => x.id === bidId);
    if (!b || b.sellerSlug !== partnerSlug) return { error: "Niet jouw bod" };
    if (!["open", "countered"].includes(b.status)) return { error: "Dit bod is al afgehandeld" };
    const l = db.listings.find(x => x.id === b.listingId);
    b.respondedAt = new Date().toISOString();
    if (action === "accept") {
      b.status = "accepted";
      pushNote(db, b.buyerId, "order", "Je bod is geaccepteerd",
        `\u20ac${b.amount} voor ${l?.title ?? "het product"} \u2014 rond je aankoop af via de listing.`, `/listing/${b.listingId}`);
    } else if (action === "reject") {
      b.status = "rejected";
      pushNote(db, b.buyerId, "order", "Je bod is afgewezen", `\u20ac${b.amount} op ${l?.title ?? "het product"}`, `/listing/${b.listingId}`);
    } else {
      if (!(counterAmount && counterAmount > b.amount && l && counterAmount < l.price)) {
        return { error: "Tegenbod moet tussen het bod en de vraagprijs liggen" };
      }
      b.status = "countered";
      b.counterAmount = Math.round(counterAmount);
      pushNote(db, b.buyerId, "order", "Tegenbod ontvangen",
        `Partner stelt \u20ac${b.counterAmount} voor op ${l?.title ?? "het product"}.`, `/listing/${b.listingId}`);
    }
    return { ok: true };
  });
}

export async function buyerBidAction(buyerId: string, bidId: string, action: "accept-counter" | "withdraw") {
  return mutate(db => {
    const b = db.bids.find(x => x.id === bidId);
    if (!b || b.buyerId !== buyerId) return { error: "Niet jouw bod" };
    if (action === "withdraw") {
      if (!["open", "countered", "accepted"].includes(b.status)) return { error: "Bod is al afgehandeld" };
      b.status = "withdrawn";
      return { ok: true };
    }
    if (b.status !== "countered" || !b.counterAmount) return { error: "Er ligt geen tegenbod" };
    b.amount = b.counterAmount;
    b.status = "accepted";
    const partner = db.users.find(u => u.partnerSlug === b.sellerSlug);
    if (partner) pushNote(db, partner.id, "order", "Tegenbod geaccepteerd",
      `Koper gaat akkoord met \u20ac${b.amount}.`, "/partner/orders");
    pushNote(db, buyerId, "order", "Deal! Rond je aankoop af",
      `\u20ac${b.amount} \u2014 reken af via de listing.`, `/listing/${b.listingId}`);
    return { ok: true };
  });
}

export async function getMyBid(listingId: string, buyerId: string) {
  const db = await read();
  return db.bids.find(b => b.listingId === listingId && b.buyerId === buyerId
    && ["open", "countered", "accepted"].includes(b.status)) ?? null;
}

/* ============ BEZORGMOMENT (v6.7) ============ */
export async function proposeSlots(partnerSlug: string, orderId: string, slots: string[]) {
  return mutate(db => {
    const o = db.orders.find(x => x.id === orderId);
    if (!o || o.sellerSlug !== partnerSlug) return { error: "Niet jouw order" };
    if (o.status !== "confirmed") return { error: "Momenten voorstellen kan na je bevestiging" };
    const valid = slots.map(x => new Date(x)).filter(d => !isNaN(+d) && +d > Date.now()).slice(0, 3);
    if (valid.length === 0) return { error: "Geef minimaal \u00e9\u00e9n moment in de toekomst" };
    o.deliverySlots = valid.map(d => ({ at: d.toISOString() }));
    o.status = "delivery_planned";
    o.events.push({ status: "delivery_planned", at: new Date().toISOString(), note: `${valid.length} moment(en) voorgesteld` });
    pushNote(db, o.buyerId, "order", "Kies je bezorgmoment",
      `De partner stelt ${valid.length} moment(en) voor \u2014 kies wat jou uitkomt.`, `/order/${o.id}`);
    return { ok: true };
  });
}

export async function chooseSlot(buyerId: string, orderId: string, at: string) {
  return mutate(db => {
    const o = db.orders.find(x => x.id === orderId);
    if (!o || o.buyerId !== buyerId) return { error: "Niet jouw order" };
    if (!o.deliverySlots?.some(x => x.at === at)) return { error: "Ongeldig moment" };
    o.chosenSlotAt = at;
    const label = new Date(at).toLocaleString("nl-NL", { weekday: "short", day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
    o.events.push({ status: o.status, at: new Date().toISOString(), note: `Bezorgmoment gekozen: ${label}` });
    const partner = db.users.find(u => u.partnerSlug === o.sellerSlug);
    if (partner) pushNote(db, partner.id, "order", "Bezorgmoment gekozen", `${o.id} \u00b7 ${label}`, `/partner/orders/${o.id}`);
    return { ok: true };
  });
}

/* ============ ORDER-CHAT (v6.7) ============ */
export async function addOrderMessage(userId: string, orderId: string, text: string) {
  return mutate(db => {
    const o = db.orders.find(x => x.id === orderId);
    if (!o) return { error: "Order niet gevonden" };
    const me = db.users.find(u => u.id === userId);
    const isBuyer = o.buyerId === userId;
    const isPartner = !!me?.partnerSlug && me.partnerSlug === o.sellerSlug;
    if (!isBuyer && !isPartner) return { error: "Geen toegang tot deze order" };
    if (o.status === "cancelled") return { error: "Deze order is gesloten" };
    (o.messages ??= []).push({ from: isBuyer ? "buyer" : "partner", text: text.slice(0, 500), at: new Date().toISOString() });
    if (o.messages.length > 200) o.messages = o.messages.slice(-200);
    if (isBuyer) {
      const partner = db.users.find(u => u.partnerSlug === o.sellerSlug);
      if (partner) pushNote(db, partner.id, "order", "Nieuw bericht van koper", `${o.id}: "${text.slice(0, 60)}"`, `/partner/orders/${o.id}`);
    } else {
      pushNote(db, o.buyerId, "order", "Nieuw bericht van de partner", `${o.id}: "${text.slice(0, 60)}"`, `/order/${o.id}`);
    }
    return { ok: true };
  });
}

/** Orders van één koper (v7.0 — voor personalisatie en account). */
export async function getMyOrders(userId: string) {
  const db = await read();
  return db.orders.filter(o => o.buyerId === userId);
}

/* ============ REVIEWS (v7.1) — alleen geverifieerde aankopen ============ */
export async function addReview(orderId: string, buyerId: string, rating: number, text?: string) {
  return mutate(db => {
    const o = db.orders.find(x => x.id === orderId);
    if (!o || o.buyerId !== buyerId) return { error: "Niet jouw order" };
    if (o.status !== "paid_out") return { error: "Review kan na afronding van de order" };
    if (o.returnRequest && o.returnRequest.status !== "completed") {
      return { error: "Rond eerst je retouraanvraag af" };
    }
    if (db.reviews.some(r => r.orderId === orderId)) return { error: "Je hebt deze aankoop al beoordeeld" };
    const r = Math.round(rating);
    if (!(r >= 1 && r <= 5)) return { error: "Beoordeling: 1 t/m 5 sterren" };
    const buyer = db.users.find(u => u.id === buyerId);
    db.reviews.push({
      id: Math.random().toString(36).slice(2, 10),
      orderId, listingId: o.listingId, sellerSlug: o.sellerSlug, buyerId,
      buyerName: (buyer?.name ?? "Koper").split(" ")[0],
      rating: r as 1 | 2 | 3 | 4 | 5,
      text: text?.trim().slice(0, 600) || undefined,
      at: new Date().toISOString(),
    });
    const partner = db.users.find(u => u.partnerSlug === o.sellerSlug);
    if (partner) pushNote(db, partner.id, "order", `Nieuwe review: ${"★".repeat(r)}`,
      `${o.itemTitle}${text ? ` — "${text.trim().slice(0, 60)}"` : ""}`, "/partner/storefront");
    return { ok: true };
  });
}

export async function replyReview(reviewId: string, partnerSlug: string, text: string) {
  return mutate(db => {
    const r = db.reviews.find(x => x.id === reviewId);
    if (!r || r.sellerSlug !== partnerSlug) return { error: "Niet jouw review" };
    if (r.reply) return { error: "Je hebt al gereageerd" };
    r.reply = { text: text.trim().slice(0, 400), at: new Date().toISOString() };
    pushNote(db, r.buyerId, "order", "De partner reageerde op je review", `"${r.reply.text.slice(0, 60)}"`, `/store/${partnerSlug}`);
    return { ok: true };
  });
}

export async function getSellerReviews(slug: string) {
  const db = await read();
  return db.reviews.filter(r => r.sellerSlug === slug).sort((a, b) => b.at.localeCompare(a.at));
}

export function ratingOf(reviews: { rating: number }[]) {
  if (reviews.length === 0) return null;
  return { avg: Math.round((reviews.reduce((s, r) => s + r.rating, 0) / reviews.length) * 10) / 10, count: reviews.length };
}
