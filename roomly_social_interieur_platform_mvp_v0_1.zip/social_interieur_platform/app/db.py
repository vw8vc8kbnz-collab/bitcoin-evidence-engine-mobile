import os, sqlite3, uuid, time
from pathlib import Path
from contextlib import contextmanager

ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ROOT / 'data' / 'roomly.db'
DB_PATH.parent.mkdir(parents=True, exist_ok=True)

def now(): return int(time.time())
def uid(): return str(uuid.uuid4())

@contextmanager
def connect():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute('PRAGMA foreign_keys=ON')
    try:
        yield con
        con.commit()
    finally:
        con.close()

def init_db():
    with connect() as con:
        con.executescript('''
        CREATE TABLE IF NOT EXISTS users (
          id TEXT PRIMARY KEY,
          email TEXT UNIQUE NOT NULL,
          password_hash TEXT NOT NULL,
          display_name TEXT NOT NULL,
          username TEXT UNIQUE NOT NULL,
          avatar_url TEXT,
          created_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS homes (
          id TEXT PRIMARY KEY,
          owner_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          title TEXT NOT NULL,
          slug TEXT UNIQUE NOT NULL,
          description TEXT,
          home_type TEXT,
          cover_url TEXT,
          privacy TEXT NOT NULL DEFAULT 'public',
          created_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS rooms (
          id TEXT PRIMARY KEY,
          home_id TEXT NOT NULL REFERENCES homes(id) ON DELETE CASCADE,
          name TEXT NOT NULL,
          room_type TEXT,
          cover_url TEXT,
          sort_order INTEGER NOT NULL DEFAULT 0,
          created_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS media (
          id TEXT PRIMARY KEY,
          owner_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          url TEXT NOT NULL,
          thumb_url TEXT,
          mime_type TEXT NOT NULL,
          width INTEGER,
          height INTEGER,
          blurhash TEXT,
          status TEXT NOT NULL DEFAULT 'ready',
          created_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS room_updates (
          id TEXT PRIMARY KEY,
          room_id TEXT NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
          user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          media_id TEXT REFERENCES media(id) ON DELETE SET NULL,
          caption TEXT,
          phase_label TEXT,
          update_type TEXT NOT NULL DEFAULT 'standard',
          before_url TEXT,
          after_url TEXT,
          created_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS follows_home (
          user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          home_id TEXT NOT NULL REFERENCES homes(id) ON DELETE CASCADE,
          created_at INTEGER NOT NULL,
          PRIMARY KEY(user_id, home_id)
        );
        CREATE TABLE IF NOT EXISTS follows_room (
          user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          room_id TEXT NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
          created_at INTEGER NOT NULL,
          PRIMARY KEY(user_id, room_id)
        );
        CREATE TABLE IF NOT EXISTS saves (
          user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          room_update_id TEXT NOT NULL REFERENCES room_updates(id) ON DELETE CASCADE,
          created_at INTEGER NOT NULL,
          PRIMARY KEY(user_id, room_update_id)
        );
        CREATE TABLE IF NOT EXISTS product_hotspots (
          id TEXT PRIMARY KEY,
          room_update_id TEXT NOT NULL REFERENCES room_updates(id) ON DELETE CASCADE,
          label TEXT NOT NULL,
          x_percent REAL NOT NULL,
          y_percent REAL NOT NULL,
          url TEXT,
          created_at INTEGER NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_updates_room_created ON room_updates(room_id, created_at DESC);
        CREATE INDEX IF NOT EXISTS idx_rooms_home ON rooms(home_id);
        ''')
