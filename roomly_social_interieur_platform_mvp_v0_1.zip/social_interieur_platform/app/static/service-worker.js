const CACHE='roomly-v1';
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(['/','/static/styles.css','/static/app.js','/manifest.webmanifest']))));
self.addEventListener('fetch',e=>{ if(e.request.method==='GET') e.respondWith(fetch(e.request).catch(()=>caches.match(e.request))) });
