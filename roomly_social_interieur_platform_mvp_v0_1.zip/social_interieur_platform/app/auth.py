import os, time, hmac, hashlib, base64, secrets
from fastapi import Request, HTTPException

SECRET = os.getenv('SECRET_KEY','dev-secret-change').encode()

def _b64(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).decode().rstrip('=')
def _unb64(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + '=' * (-len(s) % 4))

def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 220_000)
    return 'pbkdf2_sha256$220000$%s$%s' % (_b64(salt), _b64(dk))

def verify_password(password: str, stored: str) -> bool:
    try:
        algo, rounds, salt_b64, dk_b64 = stored.split('$', 3)
        salt = _unb64(salt_b64); expected = _unb64(dk_b64)
        got = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, int(rounds))
        return hmac.compare_digest(got, expected)
    except Exception:
        return False

def make_token(user_id: str) -> str:
    payload = f'{user_id}.{int(time.time())}'
    sig = hmac.new(SECRET, payload.encode(), hashlib.sha256).digest()
    return _b64(payload.encode()) + '.' + _b64(sig)

def read_token(token: str):
    try:
        p, s = token.split('.', 1)
        payload = _unb64(p).decode()
        sig = _unb64(s)
        good = hmac.new(SECRET, payload.encode(), hashlib.sha256).digest()
        if not hmac.compare_digest(sig, good): return None
        return payload.split('.', 1)[0]
    except Exception:
        return None

def current_user_id(request: Request):
    auth = request.headers.get('authorization','')
    token = auth[7:] if auth.lower().startswith('bearer ') else request.cookies.get('roomly_token')
    user_id = read_token(token) if token else None
    if not user_id: raise HTTPException(401, 'Niet ingelogd')
    return user_id
