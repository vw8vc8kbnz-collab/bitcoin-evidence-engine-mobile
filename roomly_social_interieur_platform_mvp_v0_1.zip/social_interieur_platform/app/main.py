import os, re, shutil
from pathlib import Path
from fastapi import FastAPI, Request, HTTPException, UploadFile, File, Form
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv
from PIL import Image
from .db import connect, init_db, uid, now, ROOT
from .auth import hash_password, verify_password, make_token, current_user_id

load_dotenv(ROOT/'.env')
APP_NAME=os.getenv('APP_NAME','Roomly')
MEDIA_DIR=ROOT/os.getenv('MEDIA_LOCAL_DIR','storage')
MEDIA_DIR.mkdir(parents=True, exist_ok=True)

app=FastAPI(title=APP_NAME)
app.add_middleware(CORSMiddleware, allow_origins=['*'], allow_methods=['*'], allow_headers=['*'])
app.mount('/static', StaticFiles(directory=ROOT/'app'/'static'), name='static')
app.mount('/media', StaticFiles(directory=MEDIA_DIR), name='media')

@app.on_event('startup')
def startup():
    init_db(); seed_demo()

@app.get('/', response_class=HTMLResponse)
def index():
    return (ROOT/'app'/'static'/'index.html').read_text(encoding='utf-8')

@app.get('/manifest.webmanifest')
def manifest(): return FileResponse(ROOT/'app'/'static'/'manifest.webmanifest')
@app.get('/service-worker.js')
def sw(): return FileResponse(ROOT/'app'/'static'/'service-worker.js')

def slugify(s):
    s=re.sub(r'[^a-z0-9]+','-',s.lower()).strip('-')
    return s or 'home'

def rowdict(r): return dict(r) if r else None

def get_user(user_id):
    with connect() as con: return rowdict(con.execute('SELECT id,email,display_name,username,avatar_url FROM users WHERE id=?',(user_id,)).fetchone())

@app.post('/api/auth/register')
def register(payload: dict):
    email=(payload.get('email') or '').lower().strip(); password=payload.get('password') or ''
    display=payload.get('display_name') or payload.get('username') or 'Maker'
    username=slugify(payload.get('username') or display)
    if not email or len(password)<6: raise HTTPException(400,'Email en wachtwoord van minimaal 6 tekens nodig')
    user_id=uid()
    try:
        with connect() as con:
            con.execute('INSERT INTO users VALUES (?,?,?,?,?,?,?)',(user_id,email,hash_password(password),display,username,None,now()))
    except Exception as e: raise HTTPException(400,'Email of gebruikersnaam bestaat al')
    token=make_token(user_id)
    res=JSONResponse({'token':token,'user':get_user(user_id)})
    res.set_cookie('roomly_token',token,httponly=False,samesite='lax',max_age=60*60*24*365)
    return res

@app.post('/api/auth/login')
def login(payload: dict):
    email=(payload.get('email') or '').lower().strip(); password=payload.get('password') or ''
    with connect() as con:
        u=con.execute('SELECT * FROM users WHERE email=?',(email,)).fetchone()
    if not u or not verify_password(password,u['password_hash']): raise HTTPException(401,'Login mislukt')
    token=make_token(u['id'])
    res=JSONResponse({'token':token,'user':get_user(u['id'])})
    res.set_cookie('roomly_token',token,httponly=False,samesite='lax',max_age=60*60*24*365)
    return res

@app.get('/api/me')
def me(request: Request): return get_user(current_user_id(request))

@app.post('/api/homes')
def create_home(request: Request, payload: dict):
    user_id=current_user_id(request); title=payload.get('title') or 'Mijn huis'; htype=payload.get('home_type') or ''
    slug=slugify(title)+'-'+uid()[:6]; home_id=uid()
    with connect() as con:
        con.execute('INSERT INTO homes VALUES (?,?,?,?,?,?,?,?,?)',(home_id,user_id,title,slug,payload.get('description'),htype,payload.get('cover_url'), 'public', now()))
        con.execute('INSERT OR IGNORE INTO follows_home VALUES (?,?,?)',(user_id,home_id,now()))
    return {'id':home_id,'slug':slug}

@app.get('/api/homes')
def homes(request: Request):
    user_id=None
    try: user_id=current_user_id(request)
    except Exception: pass
    with connect() as con:
        rows=con.execute('''SELECT h.*, u.display_name, u.username,
          EXISTS(SELECT 1 FROM follows_home f WHERE f.home_id=h.id AND f.user_id=?) as is_following,
          (SELECT COUNT(*) FROM follows_home f WHERE f.home_id=h.id) as followers
          FROM homes h JOIN users u ON u.id=h.owner_user_id ORDER BY h.created_at DESC''',(user_id or '',)).fetchall()
    return [rowdict(r) for r in rows]

@app.get('/api/homes/{home_id}')
def home_detail(request: Request, home_id: str):
    user_id=''
    try: user_id=current_user_id(request)
    except Exception: pass
    with connect() as con:
        h=con.execute('''SELECT h.*, u.display_name, u.username,
          EXISTS(SELECT 1 FROM follows_home f WHERE f.home_id=h.id AND f.user_id=?) as is_following,
          (SELECT COUNT(*) FROM follows_home f WHERE f.home_id=h.id) as followers
          FROM homes h JOIN users u ON u.id=h.owner_user_id WHERE h.id=?''',(user_id,home_id)).fetchone()
        rooms=con.execute('''SELECT r.*, EXISTS(SELECT 1 FROM follows_room f WHERE f.room_id=r.id AND f.user_id=?) as is_following,
          (SELECT COUNT(*) FROM follows_room f WHERE f.room_id=r.id) as followers,
          (SELECT COUNT(*) FROM room_updates ru WHERE ru.room_id=r.id) as update_count
          FROM rooms r WHERE r.home_id=? ORDER BY sort_order, created_at''',(user_id,home_id)).fetchall()
    if not h: raise HTTPException(404,'Home niet gevonden')
    return {'home':rowdict(h),'rooms':[rowdict(r) for r in rooms]}

@app.post('/api/homes/{home_id}/rooms')
def create_room(request: Request, home_id: str, payload: dict):
    user_id=current_user_id(request)
    with connect() as con:
        h=con.execute('SELECT * FROM homes WHERE id=?',(home_id,)).fetchone()
        if not h or h['owner_user_id']!=user_id: raise HTTPException(403,'Geen toegang')
        room_id=uid(); name=payload.get('name') or 'Nieuwe kamer'
        con.execute('INSERT INTO rooms VALUES (?,?,?,?,?,?,?)',(room_id,home_id,name,payload.get('room_type'),payload.get('cover_url'),0,now()))
        con.execute('INSERT OR IGNORE INTO follows_room VALUES (?,?,?)',(user_id,room_id,now()))
    return {'id':room_id}

@app.post('/api/follow/home/{home_id}')
def follow_home(request: Request, home_id: str):
    user_id=current_user_id(request)
    with connect() as con:
        exists=con.execute('SELECT 1 FROM follows_home WHERE user_id=? AND home_id=?',(user_id,home_id)).fetchone()
        if exists: con.execute('DELETE FROM follows_home WHERE user_id=? AND home_id=?',(user_id,home_id)); state=False
        else: con.execute('INSERT INTO follows_home VALUES (?,?,?)',(user_id,home_id,now())); state=True
    return {'following':state}

@app.post('/api/follow/room/{room_id}')
def follow_room(request: Request, room_id: str):
    user_id=current_user_id(request)
    with connect() as con:
        exists=con.execute('SELECT 1 FROM follows_room WHERE user_id=? AND room_id=?',(user_id,room_id)).fetchone()
        if exists: con.execute('DELETE FROM follows_room WHERE user_id=? AND room_id=?',(user_id,room_id)); state=False
        else: con.execute('INSERT INTO follows_room VALUES (?,?,?)',(user_id,room_id,now())); state=True
    return {'following':state}

@app.post('/api/media')
def upload_media(request: Request, file: UploadFile=File(...)):
    user_id=current_user_id(request)
    ext=Path(file.filename or 'upload.jpg').suffix.lower() or '.jpg'
    mid=uid(); name=f'{mid}{ext}'; target=MEDIA_DIR/name
    with target.open('wb') as f: shutil.copyfileobj(file.file, f)
    width=height=None; thumb_url=None
    try:
        im=Image.open(target); width,height=im.size; im.thumbnail((720,720)); thumb=f'{mid}_thumb.webp'; im.save(MEDIA_DIR/thumb,'WEBP',quality=82); thumb_url=f'/media/{thumb}'
    except Exception: pass
    url=f'/media/{name}'
    with connect() as con:
        con.execute('INSERT INTO media VALUES (?,?,?,?,?,?,?,?,?)',(mid,user_id,url,thumb_url,file.content_type or 'application/octet-stream',width,height,None,'ready',now()))
    return {'id':mid,'url':url,'thumb_url':thumb_url}

@app.post('/api/rooms/{room_id}/updates')
def create_update(request: Request, room_id: str, payload: dict):
    user_id=current_user_id(request); upd=uid()
    with connect() as con:
        r=con.execute('''SELECT r.*, h.owner_user_id FROM rooms r JOIN homes h ON h.id=r.home_id WHERE r.id=?''',(room_id,)).fetchone()
        if not r or r['owner_user_id']!=user_id: raise HTTPException(403,'Geen toegang')
        con.execute('INSERT INTO room_updates VALUES (?,?,?,?,?,?,?,?,?,?)',(upd,room_id,user_id,payload.get('media_id'),payload.get('caption'),payload.get('phase_label'),payload.get('update_type','standard'),payload.get('before_url'),payload.get('after_url'),now()))
        if payload.get('hotspots'):
            for hs in payload['hotspots']:
                con.execute('INSERT INTO product_hotspots VALUES (?,?,?,?,?,?,?)',(uid(),upd,hs.get('label','Product'),float(hs.get('x',50)),float(hs.get('y',50)),hs.get('url'),now()))
    return {'id':upd}

@app.get('/api/feed')
def feed(request: Request):
    user_id=current_user_id(request)
    with connect() as con:
        rows=con.execute('''SELECT ru.*, r.name room_name, r.room_type, h.id home_id, h.title home_title, h.cover_url home_cover, u.display_name, u.username,
          m.url media_url, m.thumb_url,
          EXISTS(SELECT 1 FROM saves s WHERE s.room_update_id=ru.id AND s.user_id=?) as is_saved
          FROM room_updates ru
          JOIN rooms r ON r.id=ru.room_id JOIN homes h ON h.id=r.home_id JOIN users u ON u.id=ru.user_id
          LEFT JOIN media m ON m.id=ru.media_id
          WHERE r.id IN (SELECT room_id FROM follows_room WHERE user_id=?) OR h.id IN (SELECT home_id FROM follows_home WHERE user_id=?)
          ORDER BY ru.created_at DESC LIMIT 80''',(user_id,user_id,user_id)).fetchall()
        result=[]
        for r in rows:
            d=rowdict(r)
            hs=con.execute('SELECT * FROM product_hotspots WHERE room_update_id=?',(d['id'],)).fetchall()
            d['hotspots']=[rowdict(x) for x in hs]; result.append(d)
    return result

@app.get('/api/rooms/{room_id}/timeline')
def timeline(request: Request, room_id: str):
    user_id=''
    try: user_id=current_user_id(request)
    except Exception: pass
    with connect() as con:
        room=con.execute('''SELECT r.*, h.title home_title, h.id home_id, EXISTS(SELECT 1 FROM follows_room f WHERE f.room_id=r.id AND f.user_id=?) is_following FROM rooms r JOIN homes h ON h.id=r.home_id WHERE r.id=?''',(user_id,room_id)).fetchone()
        rows=con.execute('''SELECT ru.*, m.url media_url, m.thumb_url FROM room_updates ru LEFT JOIN media m ON m.id=ru.media_id WHERE ru.room_id=? ORDER BY ru.created_at ASC''',(room_id,)).fetchall()
    if not room: raise HTTPException(404,'Kamer niet gevonden')
    return {'room':rowdict(room),'updates':[rowdict(r) for r in rows]}

@app.post('/api/save/{update_id}')
def save_update(request: Request, update_id: str):
    user_id=current_user_id(request)
    with connect() as con:
        exists=con.execute('SELECT 1 FROM saves WHERE user_id=? AND room_update_id=?',(user_id,update_id)).fetchone()
        if exists: con.execute('DELETE FROM saves WHERE user_id=? AND room_update_id=?',(user_id,update_id)); state=False
        else: con.execute('INSERT INTO saves VALUES (?,?,?)',(user_id,update_id,now())); state=True
    return {'saved':state}

def seed_demo():
    with connect() as con:
        if con.execute('SELECT COUNT(*) c FROM users').fetchone()['c']>0: return
        u=uid(); con.execute('INSERT INTO users VALUES (?,?,?,?,?,?,?)',(u,'demo@roomly.local',hash_password('demo123'),'Mila Studio','mila-studio',None,now()))
        h=uid(); con.execute('INSERT INTO homes VALUES (?,?,?,?,?,?,?,?,?)',(h,u,'Japandi stadswoning','japandi-stadswoning','Zachte materialen, rustige kleuren en een verbouwing die per kamer groeit.','Japandi',None,'public',now()))
        con.execute('INSERT INTO follows_home VALUES (?,?,?)',(u,h,now()))
        rooms=[('Woonkamer','living'),('Keuken','kitchen'),('Slaapkamer','bedroom')]
        colors=['linear-gradient(135deg,#d9c8b7,#f7f0e8)','linear-gradient(135deg,#c8d3c4,#f4f7ef)','linear-gradient(135deg,#c9ced8,#f7f3ee)']
        for i,(name,typ) in enumerate(rooms):
            r=uid(); con.execute('INSERT INTO rooms VALUES (?,?,?,?,?,?,?)',(r,h,name,typ,None,i,now()+i))
            con.execute('INSERT INTO follows_room VALUES (?,?,?)',(u,r,now()))
            for j,phase in enumerate(['Start','Materialen gekozen','Styling laag toegevoegd']):
                con.execute('INSERT INTO room_updates VALUES (?,?,?,?,?,?,?,?,?,?)',(uid(),r,u,None,f'{name}: {phase.lower()} met rustige materialen en een warme basis.',phase,'standard',None,None,now()+i*100+j))
