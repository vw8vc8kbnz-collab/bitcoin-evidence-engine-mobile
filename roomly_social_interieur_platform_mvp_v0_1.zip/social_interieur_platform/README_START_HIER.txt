ROOMLY / SOCIAL INTERIEUR PLATFORM — MVP v0.1

Wat zit erin:
- Mobile-first PWA die als app aanvoelt.
- FastAPI backend.
- SQLite startdatabase, later makkelijk naar PostgreSQL.
- Account/login/register.
- Home Profiles.
- Rooms.
- Room-follow direct in MVP.
- Home-follow.
- Feed van gevolgde homes/rooms.
- Room Timeline met horizontale swipe.
- Before/After signature slider.
- Product hotspot demo.
- Uploadflow lokaal werkend; Cloudflare R2 configuratie voorbereid.
- PWA manifest + service worker + app icon.

Eerste lokale test:
1. Pak ZIP uit.
2. Open terminal in deze map.
3. Maak venv:
   python3 -m venv .venv
4. Activeer venv:
   source .venv/bin/activate
5. Installeer packages:
   pip install -r requirements.txt
6. Kopieer .env.example naar .env:
   cp .env.example .env
7. Start:
   ./run.sh
8. Open:
   http://localhost:8899

Demo-login:
- demo@roomly.local
- demo123

VPS install naast bestaande Bitcoin tool:
1. Zet deze map los naast je Bitcoin tool, bijvoorbeeld:
   /home/ubuntu/roomly/current
2. Gebruik een eigen poort, standaard 8899.
3. Maak eigen systemd service, niet dezelfde als de Bitcoin tool.
4. Zet later Nginx/Cloudflare reverse proxy naar app.jouwdomein.nl.
5. Media in productie niet op VPS laten groeien; koppel Cloudflare R2 voordat echte beta-gebruikers uploaden.

Belangrijk voor volgende bouwstap:
- Vervang SQLite door PostgreSQL als we naar echte beta gaan.
- R2 upload via signed URLs toevoegen.
- Admin paneel toevoegen.
- Echte creator onboarding flow toevoegen.
- Room ID uit post-flow vervangen door kamerkeuze UI.
- Premium animaties verder verdiepen met shared-element transitions.
