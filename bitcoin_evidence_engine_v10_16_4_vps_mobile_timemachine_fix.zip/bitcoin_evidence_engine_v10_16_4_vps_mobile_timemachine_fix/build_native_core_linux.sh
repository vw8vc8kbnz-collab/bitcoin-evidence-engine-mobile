#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p native_core/bin logs
if command -v go >/dev/null 2>&1; then
  echo "Building Linux native core from Go state-vector source..."
  go build -o native_core/bin/bee_native_core ./native_core/go_src/bee_native_core.go
  chmod +x native_core/bin/bee_native_core
  echo "OK: native_core/bin/bee_native_core"
elif command -v g++ >/dev/null 2>&1; then
  echo "Go not found; building emergency C++ compatibility core with g++..."
  g++ -std=c++17 -O3 -DNDEBUG native_core/src/bee_native_core.cpp -o native_core/bin/bee_native_core
  chmod +x native_core/bin/bee_native_core
  echo "OK: native_core/bin/bee_native_core"
else
  echo "ERROR: neither Go nor g++ found. Install Go or build-essential." >&2
  exit 1
fi
