Bitcoin Evidence Engine V10.16.4 Oracle Cloud Mobile

Deze complete ZIP is bedoeld voor Oracle Cloud Always Free / VPS + iPhone PWA.
Startpunt: lees ORACLE_CLOUD_IPHONE_GUIDE.txt.

Belangrijkste bestanden:
- start_oracle.sh
- oracle_bootstrap_ubuntu.sh
- install_oracle_systemd.sh
- .env.oracle.example
- oracle_nginx_site.conf
- app/web/mobile.html

Windows desktop/start.bat zit er nog in, maar deze build is primair server/mobile gericht.
