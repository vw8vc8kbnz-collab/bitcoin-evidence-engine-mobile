#!/usr/bin/env bash
set -euo pipefail
cd /home/ubuntu/bitcoin-engine-deploy/current
chmod +x update.sh restart_vps.sh stop_vps.sh start_vps.sh 2>/dev/null || true
# Deze versie gebruikt géén harde python3.12 apt dependency meer.
bash update.sh
