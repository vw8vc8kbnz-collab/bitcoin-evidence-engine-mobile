#!/usr/bin/env bash
set -euo pipefail
BASE="$HOME/bitcoin-engine-deploy"
REPO_URL="${REPO_URL:-https://github.com/vw8vc8kbnz-collab/bitcoin-evidence-engine-mobile.git}"
echo "[BEE bootstrap] Oude v10.16.58 updater wordt omzeild."
mkdir -p "$BASE/releases" "$BASE/logs" "$HOME/bitcoin_evidence_data"
cd "$BASE"
sudo apt-get update
sudo apt-get install -y git unzip curl rsync procps build-essential golang-go python3 python3-venv python3-dev
rm -rf "$BASE/github_latest_bootstrap"
git clone "$REPO_URL" "$BASE/github_latest_bootstrap"
ZIP="$(find "$BASE/github_latest_bootstrap" -maxdepth 4 -type f \( -iname 'bitcoin_evidence_engine*.zip' -o -iname 'engine*.zip' \) | sort -V | tail -1)"
if [ -z "$ZIP" ]; then
  echo "Geen ZIP gevonden in GitHub repo." >&2
  exit 1
fi
echo "[BEE bootstrap] Gebruik ZIP: $ZIP"
TMP="$BASE/.bootstrap_extract_$(date +%Y%m%d_%H%M%S)"
DEST="$BASE/releases/$(date +%Y%m%d_%H%M%S)_$(basename "$ZIP" .zip)"
rm -rf "$TMP" "$DEST"
mkdir -p "$TMP"
unzip -q "$ZIP" -d "$TMP"
APP_DIR=""
while IFS= read -r mainfile; do
  candidate="$(dirname "$(dirname "$mainfile")")"
  if [ -f "$candidate/requirements.txt" ] && [ -f "$candidate/app/main.py" ]; then
    APP_DIR="$candidate"
    break
  fi
done < <(find "$TMP" -type f -path '*/app/main.py' | sort)
if [ -z "$APP_DIR" ]; then
  echo "Geen geldige app-root in ZIP gevonden." >&2
  find "$TMP" -maxdepth 4 -type f | head -120
  exit 1
fi
mv "$APP_DIR" "$DEST"
rm -rf "$TMP"
ln -sfn "$DEST" "$BASE/current"
cd "$BASE/current"
chmod +x update.sh restart_vps.sh stop_vps.sh start_vps.sh 2>/dev/null || true
echo "[BEE bootstrap] Nieuwe updater staat klaar. Start nu normale update..."
bash update.sh
