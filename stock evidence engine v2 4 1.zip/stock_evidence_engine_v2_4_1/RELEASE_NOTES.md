# RELEASE NOTES — v2.0.0 (breaking, honesty release)

Resultaten zullen LAGER zijn dan v1.9.x. Dat is de bedoeling: de optimistische biases zijn verwijderd.

## Gefixt (kritiek)
1. **ntfy-alerts kwamen nooit aan**: emoji in de HTTP `Title`-header gaf een UnicodeEncodeError die door `except: pass` werd ingeslikt — élke alert crashte vóór verzending. Headers zijn nu ASCII-safe, fouten worden gelogd, `NTFY_ENABLED` staat standaard aan, en er is `python engine.py --ntfy-test`.
2. **Snapshot-leakage**: technical_score/theme-bonus van vandaag zat in historische evidence. Snapshot-velden zijn nu alleen live-context en tellen nergens mee in validatie.
3. **Fake drift-baseline**: excess werd gemeten t.o.v. andere signaal-geconditioneerde trades (≈ zichzelf). Nu: echte unconditional drift van de ticker over hetzelfde window, zelfde executie + kosten.
4. **Entry-bias**: entry was de Close van de signaalbar zelf. Nu: Open van de volgende dag, met 0.20% round-trip kosten (SEE_TRADE_COST_PCT).
5. **Opgeblazen n**: elite/usable-gates draaien nu volledig op n_eff (non-overlapping), niet op de ~10x opgeblazen ruwe n.
6. **Schaalcorruptie**: ×10-heuristiek verminkte legitieme lage scores (7/100 → 70). Nu row-level detectie: alleen ×10 als ALLE scorevelden ≤10.
7. **News-matching**: word-boundary regex ('ai' matcht niet meer 'said'/'raise') + recency-weging (≤1d vol gewicht, ≥7d nul).
8. **CI vs nul → CI vs drift**: validated_edge vereist excess_ci90_low > 0, excess > 0.5, n_eff ≥ 10. Monitor-CSV rapporteert aantal geteste cellen (multiple-testing-context).
9. **Stock Lab**: cache wordt nu ook gelézen (2h), ticker-validatie, per-IP rate limit — DeepSeek-budget beschermd. Optionele dashboard-token via SEE_DASH_TOKEN.
10. **Dashboard leeg na versiebump**: server valt terug op nieuwste v*-CSV. Price cache max 3 dagen oud in live mode.

## Nieuw
- **Statistische controles in selftest**: positieve controle (synthetische conditionele edge → moet gedetecteerd) + negatieve controle (random walk → nul validated). Beide slagen.
- Extra ntfy-tier `LIVE_HIGH_UNVALIDATED` (live_attention ≥ 75 + AI high) met cross-run dedup (12h), zodat het topic niet maandenlang stil is terwijl validated edges schaars zijn.
- Dark quant-terminal dashboard met dubbele live/validated scorebalk, warning-chips en Nederlandse labels.
- DeepSeek prompt: freshness-discipline (age_days-weging; nieuws >7d ≠ catalyst).

# v2.0.1
- "Run scan nu"-knop in het dashboard: start run_backtest.sh op de achtergrond met lockfile (geen dubbele runs), live status via /api/run_status, pagina ververst automatisch als de scan klaar is. De automatische systemd-timer (4x/dag) blijft gewoon actief.
- Scans loggen naar output/scan.log zodat mislukte Yahoo-downloads zichtbaar zijn.

# v2.1.0 — Forward Tracking
- Elk actief signaal (setup-conditie waar op de laatste bar + validated edge of live alert-tier) wordt gelogd in een PERSISTENT forward log in de data-cache (overleeft versie-bumps).
- Elke scan vult automatisch de gerealiseerde rendementen in na 1/3/5/10 handelsdagen: next-open entry, incl. kosten, plus excess vs QQQ over exact hetzelfde window. Dit is de enige hindsight-vrije validatie van live signalen én van de DeepSeek-laag.
- Dashboard: Forward Tracking-sectie met per-tier performance (gem., winrate, vs QQQ) en de recentste signalen.
- Auto-blacklist van tickers vervalt nu na 24 uur (omgevingsfouten zijn niet langer permanent).
- Voortgangsregel [DL] per verse download; verse runs ogen nooit meer stil.
- Selftest uitgebreid met exacte forward-tracking controle (log, dedupe, invulwaarden, QQQ-excess).

# v2.1.1 — Actiegerichte alerts
- ntfy-berichten beginnen nu met een expliciet oordeel per tier: TRADE-KANDIDAAT (hybrid/extreme) of GEEN TRADE-BEWIJS (unvalidated live tiers).
- Trade-kandidaten krijgen een mechanisch handelsplan: entry rond volgende open, historisch gemiddelde + winrate + 90% CI van de cel (expliciet gelabeld als gemeten historie, geen voorspelling), take profit op het historische gemiddelde, stop loss op 2x ATR14, en de resulterende R:R.
- Unvalidated alerts krijgen bewust GEEN TP/SL-plan — alleen "op de radar".

# v2.2.0 — Meer signalen, zelfde eerlijkheid
- Universum uitgebreid van 82 naar 252 liquide US-aandelen (alle sectoren; thema-namen behouden). DeepSeek-shortlist blijft top-30, dus AI-kosten veranderen niet.
- Nieuwe HYPOTHESE-engine oversold_snapback (5d < -10%, onder ma20, capitulatie-volume): mean-reversion zodat er ook in dalende markten getest wordt. Telt alleen mee als validatie + FDR hem goedkeuren.
- Benjamini-Hochberg FDR-correctie (q=0.10) over alle toetsbare cellen: met ~6000+ cellen worden CI-toevalstreffers nu automatisch afgekeurd (edge_grade=FDR_REJECTED, p_boot per cel in de export). Zonder deze laag zou het grotere universum schijn-edges produceren.
- NTFY_LIVE_MIN_ATTENTION default 75 -> 68: meer "op de radar"-alerts (blijven expliciet GEEN TRADE-BEWIJS gelabeld).
- Eerste run na deploy downloadt ~170 nieuwe tickers en duurt 15-30 min; daarna weer cache-snelheid.

# v2.3.0 — FDR als badge + signal-stijl alerts
- KALIBRATIE OP ECHTE DATA (7000 cellen, 2554 toetsbaar): whole-universe BH bleek wiskundig onhaalbaar (min p 0.002 vs vereist 0.00004) — de v2.2.0 FDR-veto maakte de validated-gate permanent leeg en degradeerde o.a. TER/RGTI onterecht tot ruis-status. Hersteld: validated_edge = KANDIDAAT (CI-criteria), fdr_confirmed = aparte goud-badge, forward tracking = scheidsrechter.
- ntfy-alerts in signal-stijl: emoji-layout met Entry/TP/SL/R:R-blok, historie + CI, warnings en event; per-tier ntfy-tags (🎯 hybrid, 🚨 extreme, 👀 radar). Trade-kandidaten expliciet "size klein"; radar-alerts expliciet zonder plan.

# v2.3.1 — Plan-simulatie in forward tracking
- Naast de kale setup-meting (ret_1/3/5/10d, blind vasthouden) simuleert de forward log nu ook het ALERT-PLAN op dag-OHLC: TP/SL uit de alert worden bij het loggen vastgelegd; gap door SL vult op de Open, TP en SL in dezelfde bar = SL (worst case), anders tijd-exit op de horizon. Kolommen plan_exit/plan_ret/plan_days.
- Dashboard toont Plan win % en TP/SL/tijd-verdeling. De setup-winrate en de plan-winrate zijn nu twee gescheiden, beide eerlijke metingen.
- ntfy re-alert blijft max 1x per 12h per ticker+tier (NTFY_REALERT_HOURS).

# v2.4.0 — Cross-ticker intelligentie
- THEME PASS: één extra DeepSeek-call per run die alle 30 per-ticker analyses samen ziet. Output: max 5 clusters met naam, driver, tickers, crowding_risk (0-100), tweede-orde-begunstigden (alleen binnen het eigen universum) en toelichting. Dashboard toont ze als kaarten; crowding >=70 kleurt rood. Kosten: ~1 goedkope call extra (gelogd als _THEME_PASS in cost monitor).
- SHORTLIST-FIX: 6 gereserveerde slots (DEEPSEEK_SNAPBACK_SLOTS) voor de hardste 5d-dalers met volume >1.1x, zodat de oversold_snapback-engine ook AI-context krijgt. De rest blijft momentum-gerangschikt; totaal blijft 30.
- metrics: ret5 toegevoegd.

# v2.4.1 — Resultaat-alerts
- Zodra een gevolgd signaal zijn plan afrondt (TP geraakt, SL geraakt, of tijd-exit) stuurt ntfy het resultaat: WIN/LOSS, rendement, aantal dagen, exit-type. Eenmalig per signaal. Uitzetten kan met NTFY_RESULTS=0.
- Forward-tabel in het dashboard heeft een plan-kolom: WIN/LOSS + exit-type + rendement per signaal.
