#!/usr/bin/env bash
set -e
sudo apt update
sudo apt install -y docker.io docker-compose-plugin unzip curl
