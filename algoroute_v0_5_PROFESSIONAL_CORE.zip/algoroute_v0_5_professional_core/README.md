# AlgoRoute v0.5 Professional Core

Real UI build, not a mockup. Focus:
- clean SVG logo without background block
- Live Kaart as separate nav page
- dark premium AlgoRoute styling
- more complete route/load SaaS module structure
- backend health + sample APIs
