from datetime import datetime, timezone
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
app=FastAPI(title="AlgoRoute API")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
@app.get("/api/health")
def health(): return {"ok": True, "app":"AlgoRoute", "version":"0.5.0", "time": datetime.now(timezone.utc).isoformat()}
@app.get("/api/fleet")
def fleet(): return [{"id":"V-01","status":"active","capacity":85},{"id":"V-02","status":"active","capacity":72},{"id":"V-03","status":"maintenance","capacity":30}]
@app.get("/api/routes")
def routes(): return [{"id":"R001","driver":"Jan de Vries","stops":12,"status":"active"},{"id":"R002","driver":"Pieter Smit","stops":10,"status":"active"}]
