#!/usr/bin/env bash
set -euo pipefail
BASE_DIR="${BASE_DIR:-$HOME/bitcoin-engine-deploy}"
cd "$BASE_DIR/current"
chmod +x update.sh restart_vps.sh stop_vps.sh start_vps.sh 2>/dev/null || true
bash update.sh
