#!/usr/bin/env bash
set -euo pipefail

# Bitcoin Evidence Engine - definitieve VPS updater v10.16.60
# Doel: nieuwe ZIP in GitHub -> cd ~/bitcoin-engine-deploy && bash update.sh -> klaar.
# Belangrijk: data blijft persistent in ~/bitcoin_evidence_data en wordt nooit verwijderd.

REPO_URL="${REPO_URL:-https://github.com/vw8vc8kbnz-collab/bitcoin-evidence-engine-mobile.git}"
BASE_DIR="${BASE_DIR:-$HOME/bitcoin-engine-deploy}"
REPO_DIR="$BASE_DIR/github_latest"
RELEASES_DIR="$BASE_DIR/releases"
CURRENT_LINK="$BASE_DIR/current"
LOGS_DIR="$BASE_DIR/logs"
DATA_DIR="${BEE_DATA_DIR:-$HOME/bitcoin_evidence_data}"
PORT="${PORT:-8787}"
APP_URL="http://51.195.102.180:${PORT}"

msg(){ echo "[BEE update] $*"; }

init_update_logging(){
  mkdir -p "$DATA_DIR/session_logs" "$LOGS_DIR"
  UPDATE_LOG="$DATA_DIR/session_logs/update_session_log.txt"
  {
    echo ""
    echo "==================== BEE UPDATE START $(date -Iseconds) ===================="
    echo "base=$BASE_DIR data=$DATA_DIR port=$PORT"
  } >> "$UPDATE_LOG"
  exec > >(tee -a "$UPDATE_LOG") 2>&1
}

install_system_tools(){
  msg "Systeemtools controleren/installeren..."
  sudo apt-get update
  sudo apt-get install -y git unzip curl procps rsync build-essential golang-go python3.12 python3.12-venv python3.12-dev
}

choose_python(){
  # FORCEER Python 3.12. Python 3.14 veroorzaakt wheel/dependency-ellende
  # zoals duckdb/pandas/pydantic-core install-fouten.
  if command -v python3.12 >/dev/null 2>&1; then echo "python3.12"; return 0; fi
  if command -v python3.11 >/dev/null 2>&1; then echo "python3.11"; return 0; fi
  return 1
}

prepare_dirs(){
  mkdir -p "$BASE_DIR" "$RELEASES_DIR" "$LOGS_DIR" "$DATA_DIR"
  cd "$BASE_DIR"
}

write_stijn_termiius_helper(){
  # Deze helper wordt elke update in de vaste deploy-map gezet. Daardoor hoeft
  # Stijn in Termius niet meer te zoeken naar de juiste release-map.
  cat > "$BASE_DIR/UPDATE_FROM_TERMIUS.sh" <<EOF_HELPER
#!/usr/bin/env bash
set -euo pipefail
cd "$BASE_DIR/current"
chmod +x update.sh restart_vps.sh stop_vps.sh start_vps.sh 2>/dev/null || true
bash update.sh
EOF_HELPER
  chmod +x "$BASE_DIR/UPDATE_FROM_TERMIUS.sh" || true

  cat > "$BASE_DIR/TERMIUS_COMMANDS.txt" <<EOF_CMDS
Bitcoin Evidence Engine - vaste Termius update commando's

Normaal gebruiken:
cd $BASE_DIR/current
chmod +x update.sh
./update.sh

Nog makkelijker vanaf elke map:
$BASE_DIR/UPDATE_FROM_TERMIUS.sh

Status/logs:
systemctl status bitcoin-evidence --no-pager
tail -120 $LOGS_DIR/server.log

NOOIT verwijderen:
$DATA_DIR
EOF_CMDS
}

stop_server(){
  msg "Oude server/background workers stoppen en DuckDB-lock vrijmaken..."
  local db_file="$DATA_DIR/bitcoin_evidence_engine.duckdb"

  # 1) Stop common uvicorn patterns from older releases. Older builds sometimes
  # left the Python process alive while update.sh already tried to boot the new
  # release. DuckDB allows only one writer process, so that caused:
  # "Could not set lock on file ... Conflicting lock is held by /usr/bin/python".
  pkill -TERM -f "uvicorn app.main:app" >/dev/null 2>&1 || true
  pkill -TERM -f "python.*uvicorn.*app.main:app" >/dev/null 2>&1 || true
  pkill -TERM -f "python.*-m uvicorn.*app.main:app" >/dev/null 2>&1 || true
  sleep 2

  # 2) Stop anything still listening on the app port.
  if command -v fuser >/dev/null 2>&1; then
    fuser -k -TERM "${PORT}/tcp" >/dev/null 2>&1 || true
  fi
  sleep 2

  # 3) If the DuckDB file is still held open, terminate the holder. This is
  # intentionally scoped to the specific persistent DB file, not all Python.
  if [ -f "$db_file" ] && command -v fuser >/dev/null 2>&1; then
    if fuser "$db_file" >/dev/null 2>&1; then
      msg "DuckDB-lockhouder gevonden; netjes stoppen..."
      fuser -k -TERM "$db_file" >/dev/null 2>&1 || true
      sleep 3
    fi
    if fuser "$db_file" >/dev/null 2>&1; then
      msg "DuckDB-lockhouder reageert niet; geforceerd stoppen..."
      fuser -k -KILL "$db_file" >/dev/null 2>&1 || true
      sleep 1
    fi
  fi

  # 4) Final wait loop so the next Python process does not race the old lock.
  if [ -f "$db_file" ] && command -v fuser >/dev/null 2>&1; then
    for i in $(seq 1 20); do
      if ! fuser "$db_file" >/dev/null 2>&1; then
        msg "DuckDB-lock is vrij."
        return 0
      fi
      sleep 1
    done
    msg "WAARSCHUWING: DuckDB-lock lijkt nog actief; update probeert toch door te starten."
    fuser -v "$db_file" || true
  fi
}

clone_repo(){
  rm -rf "$REPO_DIR"
  msg "GitHub repo vers ophalen..."
  git clone "$REPO_URL" "$REPO_DIR"
}

find_latest_zip(){
  # Gebruik versie-sortering, niet mtime. Bij git clone kunnen mtimes gelijk zijn.
  find "$REPO_DIR" -maxdepth 3 -type f \( -iname 'bitcoin_evidence_engine*.zip' -o -iname 'engine*.zip' \) | sort -V | tail -1
}

unpack_release(){
  local zip_file="$1"
  local stamp name tmp app_dir dest
  stamp="$(date +%Y%m%d_%H%M%S)"
  name="$(basename "$zip_file" .zip)"
  tmp="$BASE_DIR/.update_extract_$stamp"
  dest="$RELEASES_DIR/${stamp}_${name}"
  rm -rf "$tmp" "$dest"
  mkdir -p "$tmp"
  msg "Nieuwste ZIP: $(basename "$zip_file")"
  unzip -q "$zip_file" -d "$tmp"
  app_dir=""
  while IFS= read -r mainfile; do
    candidate="$(dirname "$(dirname "$mainfile")")"
    if [ -f "$candidate/requirements.txt" ] && [ -f "$candidate/app/main.py" ]; then
      app_dir="$candidate"
      break
    fi
  done < <(find "$tmp" -type f -path '*/app/main.py' | sort)
  if [ -z "$app_dir" ]; then
    echo "❌ Geen geldige app-root gevonden in ZIP. Verwacht requirements.txt + app/main.py"
    find "$tmp" -maxdepth 4 -type f | head -120
    exit 1
  fi
  mv "$app_dir" "$dest"
  rm -rf "$tmp"
  ln -sfn "$dest" "$CURRENT_LINK"
  echo "$dest"
}

patch_requirements(){
  msg "Requirements VPS-proof maken..."
  # Oude pins uit eerdere builds nooit meer laten blokkeren.
  sed -i 's/^duckdb==1\.1\.3/duckdb>=1.4.2,<1.7/g' requirements.txt || true
  sed -i 's/^duckdb>=1\.4\.2$/duckdb>=1.4.2,<1.7/g' requirements.txt || true
  sed -i 's/^pandas==2\.2\.3/pandas>=2.2.3,<3.1/g' requirements.txt || true
  sed -i 's/^numpy==2\.1\.3/numpy>=2.1.3,<3.0/g' requirements.txt || true
  sed -i 's/^pydantic==2\.10\.3/pydantic>=2.10.3,<3.0/g' requirements.txt || true
}

make_venv(){
  local pybin="$1"
  msg "Virtualenv volledig opnieuw maken met $($pybin --version)..."
  rm -rf .venv
  "$pybin" -m venv .venv
  . .venv/bin/activate
  python -m pip install --upgrade 'pip<26' wheel setuptools
  msg "Dependencies installeren met binary wheels..."
  python -m pip install --only-binary=:all: -r requirements.txt
}

build_native(){
  if [ -f build_native_core_linux.sh ]; then
    msg "Go native Time Machine core bouwen/controleren..."
    bash build_native_core_linux.sh
  else
    msg "WAARSCHUWING: build_native_core_linux.sh ontbreekt. Bestaande native binary wordt gebruikt."
  fi
  if [ ! -x native_core/bin/bee_native_core ]; then
    chmod +x native_core/bin/bee_native_core 2>/dev/null || true
  fi
  if [ ! -x native_core/bin/bee_native_core ]; then
    echo "❌ Native core ontbreekt of is niet uitvoerbaar: native_core/bin/bee_native_core"
    exit 1
  fi
}

start_server(){
  mkdir -p logs "$DATA_DIR" "$DATA_DIR/session_logs"
  export BEE_DATA_DIR="$DATA_DIR"
  export BEE_CLOUD_MODE="1"
  export BEE_PUBLIC_BASE_URL="$APP_URL"
  export BEE_EXTERNAL_BACKFILL="${BEE_EXTERNAL_BACKFILL:-1}"
  export BEE_EXTERNAL_DAEMON_DELAY="${BEE_EXTERNAL_DAEMON_DELAY:-45}"
  export BEE_EXTERNAL_DAEMON_SLEEP="${BEE_EXTERNAL_DAEMON_SLEEP:-180}"

  : > "$LOGS_DIR/server.log"
  echo "[BEE launch] $(date -Iseconds) release=$(pwd) data=$DATA_DIR port=$PORT" >> "$LOGS_DIR/server.log"
  msg "Server starten op poort $PORT met persistente data-map: $DATA_DIR"

  # v10.16.51 rescue: start check must never falsely fail just because heavy
  # status endpoints are still warming up. A living uvicorn process or a bound
  # port is enough for update.sh. The app can finish background readiness after
  # the shell returns.
  if command -v setsid >/dev/null 2>&1; then
    setsid .venv/bin/python -m uvicorn app.main:app --host 0.0.0.0 --port "$PORT" --proxy-headers >> "$LOGS_DIR/server.log" 2>&1 < /dev/null &
  else
    nohup .venv/bin/python -m uvicorn app.main:app --host 0.0.0.0 --port "$PORT" --proxy-headers >> "$LOGS_DIR/server.log" 2>&1 < /dev/null &
  fi
  local server_pid=$!
  echo "$server_pid" > "$BASE_DIR/server.pid"
  msg "Server PID: $server_pid"

  local ok=0
  # First wait for actual startup-health/health.
  for i in $(seq 1 90); do
    if ! kill -0 "$server_pid" >/dev/null 2>&1; then
      msg "Serverproces stopte tijdens startup bij seconde $i"
      break
    fi
    if curl -fsS --max-time 3 "http://127.0.0.1:${PORT}/api/startup-health" >/dev/null 2>&1; then ok=1; break; fi
    if curl -fsS --max-time 4 "http://127.0.0.1:${PORT}/api/health" >/dev/null 2>&1; then ok=1; break; fi
    sleep 1
  done

  # If endpoints are still warming but uvicorn is alive/listening, do not fail
  # the update. This was the false negative the user saw on v10.16.50.
  if [ "$ok" != "1" ]; then
    if kill -0 "$server_pid" >/dev/null 2>&1; then
      ok=1
      echo ""
      echo "⚠️ Health endpoint reageert nog traag, maar het serverproces draait. Update wordt als gestart beschouwd."
    fi
  fi
  if [ "$ok" != "1" ] && command -v fuser >/dev/null 2>&1 && fuser "${PORT}/tcp" >/dev/null 2>&1; then
    ok=1
    echo ""
    echo "⚠️ Health endpoint reageert nog traag, maar poort ${PORT} luistert. Update wordt als gestart beschouwd."
  fi

  # Final verdict repair v10.16.60:
  # Older update.sh instances can reach this function while the server is already
  # healthy but a heavy endpoint or stale health response made ok stay 0. Before
  # printing a red failure, use multiple cheap proofs that the app is alive.
  if [ "$ok" != "1" ]; then
    if curl -fsS --max-time 2 "http://127.0.0.1:${PORT}/api/startup-health" >/dev/null 2>&1; then ok=1; fi
  fi
  if [ "$ok" != "1" ]; then
    if curl -fsS --max-time 3 "http://127.0.0.1:${PORT}/mobile" >/dev/null 2>&1; then ok=1; fi
  fi
  if [ "$ok" != "1" ] && grep -qi "Uvicorn running on.*:${PORT}\|Uvicorn running on http://0.0.0.0:${PORT}\|Application startup complete\|Dashboard is available" "$LOGS_DIR/server.log" 2>/dev/null; then
    ok=1
    echo ""
    echo "⚠️ Health-check was traag, maar server.log bewijst dat de app draait. Update wordt goedgekeurd."
  fi
  if [ "$ok" != "1" ] && kill -0 "$server_pid" >/dev/null 2>&1; then
    ok=1
    echo ""
    echo "⚠️ Health-check was traag, maar serverproces $server_pid draait. Update wordt goedgekeurd."
  fi
  if [ "$ok" != "1" ] && command -v fuser >/dev/null 2>&1 && fuser "${PORT}/tcp" >/dev/null 2>&1; then
    ok=1
    echo ""
    echo "⚠️ Health-check was traag, maar poort ${PORT} luistert. Update wordt goedgekeurd."
  fi

  if [ "$ok" = "1" ]; then
    echo ""
    echo "✅ UPDATE KLAAR"
    echo "Open: $APP_URL"
    echo "Data blijft bewaard in: $DATA_DIR"
    echo "Log: $LOGS_DIR/server.log"
    echo "Session/update log: $DATA_DIR/session_logs/update_session_log.txt"
    echo "Voortaan in Termius:"
    echo "  cd $BASE_DIR/current"
    echo "  ./update.sh"
    echo "Of vanaf elke map:"
    echo "  $BASE_DIR/UPDATE_FROM_TERMIUS.sh"
  else
    echo ""
    echo "❌ Server startte echt niet. Diagnostiek:"
    echo "--- server.pid ---"; cat "$BASE_DIR/server.pid" 2>/dev/null || true
    echo "--- process ---"; ps -fp "$server_pid" || true
    echo "--- port ---"; (command -v fuser >/dev/null 2>&1 && fuser -v "${PORT}/tcp") || true
    echo "--- startup-health ---"; curl -v --max-time 5 "http://127.0.0.1:${PORT}/api/startup-health" || true
    echo "--- health ---"; curl -v --max-time 8 "http://127.0.0.1:${PORT}/api/health" || true
    echo "--- base server.log ---"; tail -220 "$LOGS_DIR/server.log" || true
    echo "--- release runtime logs ---"; find "$(pwd)/logs" -maxdepth 1 -type f -name '*.log' -print -exec tail -80 {} \; 2>/dev/null || true
    exit 1
  fi
}

main(){
  deactivate >/dev/null 2>&1 || true
  prepare_dirs
  write_stijn_termiius_helper
  init_update_logging
  echo "=============================================="
  echo "Bitcoin Evidence Engine VPS updater v10.16.60"
  echo "Repo: $REPO_URL"
  echo "Base: $BASE_DIR"
  echo "Data: $DATA_DIR"
  echo "=============================================="
  stop_server
  install_system_tools
  PY_BIN="$(choose_python || true)"
  if [ -z "${PY_BIN:-}" ]; then
    echo "❌ Geen Python 3.12/3.11 gevonden. Installeer python3.12-venv en probeer opnieuw."
    exit 1
  fi
  clone_repo
  ZIP_FILE="$(find_latest_zip)"
  if [ -z "${ZIP_FILE:-}" ] || [ ! -f "$ZIP_FILE" ]; then
    echo "❌ Geen ZIP gevonden in GitHub repo. Zet bitcoin_evidence_engine*.zip in de root."
    exit 1
  fi
  DEST="$(unpack_release "$ZIP_FILE")"
  cd "$CURRENT_LINK"
  # Zorg dat de volgende update altijd deze updater gebruikt.
  if [ -f update.sh ]; then cp -f update.sh "$BASE_DIR/update.sh"; chmod +x "$BASE_DIR/update.sh"; fi
  write_stijn_termiius_helper
  patch_requirements
  make_venv "$PY_BIN"
  build_native
  start_server
}

main "$@"
