from __future__ import annotations
import json
from app.db.database import db
from app.core.config import settings
from app.core.time_utils import utc_now, to_ms, horizon_delta
from app.engine.feature_engine import FeatureEngine
from app.engine.model_arena import ModelArena
from app.engine.meta_judge import MetaJudge
from app.engine.risk_rules import invalidation_price as calc_invalidation_price



def _clamp(v, lo, hi, default=0.0):
    try:
        import math
        x = float(v)
        if not math.isfinite(x):
            return default
        return max(lo, min(hi, x))
    except Exception:
        return default

def _normalise_forecast_item(combined: dict, current_price: float, horizon: str) -> dict:
    """V10.16.46: keep live forecast output human-scale and safe.

    Internal models use percent points for expected_move_pct and 0-100 for
    confidence. Older UI bugs multiplied those values by 100. This function also
    prevents absurd live targets or fake 90% confidence when evidence is weak.
    """
    out = dict(combined or {})
    bull = _clamp(out.get('bullish_probability', 0.5), 0.01, 0.99, 0.5)
    if bull > 1.0:  # tolerate accidental 0-100 probability payloads
        bull = _clamp(bull / 100.0, 0.01, 0.99, 0.5)
    out['bullish_probability'] = bull
    out['bearish_probability'] = _clamp(1.0 - bull, 0.01, 0.99, 0.5)
    conf = _clamp(out.get('confidence', 0.0), 0.0, 100.0, 0.0)
    evidence = int(out.get('evidence_count') or 0)
    edge = abs(bull - 0.5) * 2.0
    # Confidence needs both model edge and historical evidence. A neutral stack
    # must not display as a strong signal just because many weak models voted.
    evidence_cap = 38.0 + min(32.0, evidence / 35.0)
    edge_cap = 35.0 + edge * 75.0
    out['confidence'] = round(min(conf, evidence_cap, edge_cap, 88.0), 2)
    move = _clamp(out.get('expected_move_pct', 0.0), -80.0, 80.0, 0.0)
    horizon_caps = {'1h': 3.5, '4h': 6.0, '8h': 8.5, '24h': 13.0, '7d': 24.0, '30d': 45.0, '90d': 75.0}
    cap = horizon_caps.get(str(horizon), 20.0)
    move = _clamp(move, -cap, cap, 0.0)
    out['expected_move_pct'] = round(move, 6)
    if current_price and current_price > 0:
        out['expected_price'] = float(current_price) * (1 + move / 100.0)
    return out


def _bucket_live_feature(name, value):
    try:
        if value is None: return None
        if isinstance(value, str): return value.lower()[:32] if value else None
        x=float(value)
        if x!=x or x in (float('inf'), float('-inf')): return None
    except Exception:
        return None
    n=str(name).lower()
    if 'funding' in n:
        if x>=0.00030: return 'funding_high_positive'
        if x>=0.00008: return 'funding_positive'
        if x<=-0.00012: return 'funding_negative'
        return 'funding_neutral'
    if 'premium' in n or 'spread' in n:
        if x>=0.12: return 'premium_strong_positive'
        if x>=0.025: return 'premium_positive'
        if x<=-0.08: return 'premium_negative'
        return 'premium_neutral'
    if 'rsi' in n:
        if x>=72: return 'rsi_overheated'
        if x>=58: return 'rsi_bullish'
        if x<=30: return 'rsi_oversold'
        if x<=44: return 'rsi_weak'
        return 'rsi_neutral'
    if 'fear' in n:
        if x>=75: return 'greed_extreme'
        if x>=58: return 'greed'
        if x<=25: return 'fear_extreme'
        if x<=42: return 'fear'
        return 'sentiment_neutral'
    if 'volatility' in n:
        if x>=0.075: return 'vol_high'
        if x>=0.04: return 'vol_mid'
        return 'vol_low'
    if 'long_short' in n:
        if x>=1.35: return 'crowded_longs'
        if x<=0.78: return 'crowded_shorts'
        return 'crowding_neutral'
    if 'open_interest' in n:
        if x>=4: return 'oi_rising_fast'
        if x<=-4: return 'oi_falling_fast'
        return 'oi_neutral'
    if 'return' in n or n=='trend':
        if x>=3: return 'trend_up_strong'
        if x>=0.5: return 'trend_up'
        if x<=-3: return 'trend_down_strong'
        if x<=-0.5: return 'trend_down'
        return 'trend_flat'
    if 'drawdown' in n:
        if x<=-35: return 'deep_drawdown'
        if x<=-15: return 'drawdown'
        return 'near_highs'
    return 'positive' if x>0 else ('negative' if x<0 else 'neutral')

def _current_pair_context():
    row = db.df("""
        SELECT funding_rate, spot_premium_coinbase_pct, spot_premium_kraken_pct, cross_exchange_spread_pct,
               rsi_14, fear_greed, volatility_24, long_short_ratio, top_account_long_short_ratio,
               open_interest_change_24h, return_24, return_4, drawdown_from_ath, regime
        FROM features WHERE interval='1h' ORDER BY timestamp_ms DESC LIMIT 1
    """).to_dict('records')
    if not row: return {}, 'unknown'
    r=row[0]; reg=str(r.get('regime') or 'unknown').lower()[:32]
    ctx={}
    ctx['funding']=_bucket_live_feature('funding', r.get('funding_rate'))
    prem = r.get('spot_premium_coinbase_pct') if r.get('spot_premium_coinbase_pct') is not None else (r.get('spot_premium_kraken_pct') if r.get('spot_premium_kraken_pct') is not None else r.get('cross_exchange_spread_pct'))
    ctx['premium']=_bucket_live_feature('premium', prem)
    ctx['rsi']=_bucket_live_feature('rsi', r.get('rsi_14'))
    ctx['fear_greed']=_bucket_live_feature('fear', r.get('fear_greed'))
    ctx['volatility']=_bucket_live_feature('volatility', r.get('volatility_24'))
    ctx['long_short']=_bucket_live_feature('long_short', r.get('long_short_ratio') if r.get('long_short_ratio') is not None else r.get('top_account_long_short_ratio'))
    ctx['open_interest']=_bucket_live_feature('open_interest', r.get('open_interest_change_24h'))
    ctx['trend']=_bucket_live_feature('return_24', r.get('return_24') if r.get('return_24') is not None else r.get('return_4'))
    ctx['drawdown']=_bucket_live_feature('drawdown', r.get('drawdown_from_ath'))
    ctx['regime']=reg
    return {k:v for k,v in ctx.items() if v}, reg

def _apply_adaptive_pair_calibration(out: dict, horizon: str) -> dict:
    try:
        ctx, reg = _current_pair_context()
        if len(ctx) < 2: return out
        dims=list(ctx.keys())
        hits=[]
        for i in range(len(dims)):
            for j in range(i+1, len(dims)):
                a,b=dims[i],dims[j]
                rows=db.df("""
                    SELECT pair_key, feature_a, bucket_a, feature_b, bucket_b, sample, edge, weight, quality, hitrate_with_partial
                    FROM adaptive_feature_pair_weights
                    WHERE horizon=? AND regime=? AND ((feature_a=? AND bucket_a=? AND feature_b=? AND bucket_b=?) OR (feature_a=? AND bucket_a=? AND feature_b=? AND bucket_b=?))
                    ORDER BY quality DESC, sample DESC LIMIT 2
                """, [horizon, reg, a, ctx[a], b, ctx[b], b, ctx[b], a, ctx[a]]).to_dict('records')
                hits.extend(rows)
        if not hits: return out
        # Conservative: combinations may calibrate confidence and strength, but not flip direction.
        sample=sum(max(0,int(h.get('sample') or 0)) for h in hits)
        edge=sum(float(h.get('edge') or 0)*max(1,int(h.get('sample') or 1)) for h in hits)/max(1,sample)
        avg_weight=sum(float(h.get('weight') or 1)*max(1,int(h.get('sample') or 1)) for h in hits)/max(1,sample)
        conf=float(out.get('confidence') or 0)
        move=float(out.get('expected_move_pct') or 0)
        conf += max(-8.0, min(8.0, edge*55.0 + (avg_weight-1.0)*7.0))
        if edge < -0.03:
            move *= max(0.72, 1.0 + edge*1.8)
        elif edge > 0.03:
            move *= min(1.18, 1.0 + edge*0.85)
        out['confidence']=round(max(0.0,min(88.0,conf)),2)
        out['expected_move_pct']=round(max(-80.0,min(80.0,move)),6)
        out['expected_price']=float(out.get('expected_price') or 0) # overwritten below by normalise if needed
        out['adaptive_pair_edge']=round(edge,6)
        out['adaptive_pair_weight']=round(avg_weight,6)
        out['adaptive_pair_matches']=len(hits)
        try:
            contrib=list(out.get('contributions') or [])
            contrib.append({'model_id':'ADAPTIVE_PAIRS','name':'Adaptive Combinations','horizon':horizon,'weight':round(avg_weight,3),'confidence':round(conf,2),'evidence_count':sample,'note':f'{len(hits)} live feature-combinations matched learned Time Machine pairs'})
            out['contributions']=contrib
        except Exception: pass
    except Exception:
        pass
    return out

class ForecastService:
    def __init__(self):
        self.features = FeatureEngine()
        self.arena = ModelArena()
        self.judge = MetaJudge()

    def maybe_create_run(self, force: bool = False) -> dict:
        now=utc_now()
        latest = db.fetchone("SELECT created_at_ms FROM forecast_runs ORDER BY created_at_ms DESC LIMIT 1")
        if latest and not force:
            age_min = (to_ms(now) - int(latest[0])) / 60000
            if age_min < settings.min_forecast_gap_minutes:
                return {"created": False, "reason": f"Laatste forecast is {age_min:.1f} minuten oud"}
        return self.create_run()

    def create_run(self) -> dict:
        rebuilt = self.features.rebuild()
        price_row = db.fetchone("SELECT close, open_time FROM raw_candles WHERE source='binance' AND symbol=? AND interval='1h' ORDER BY open_time DESC LIMIT 1", [settings.symbol])
        if not price_row:
            return {"created": False, "reason": "Geen candledata beschikbaar"}
        current_price = float(price_row[0])
        now=utc_now(); now_ms=to_ms(now)
        run_id = db.fetchone("SELECT nextval('seq_forecast_runs')")[0]
        data_points = db.fetchone("SELECT COUNT(*) FROM raw_candles WHERE source='binance' AND symbol=? AND interval='1h'", [settings.symbol])[0]
        db.execute("INSERT INTO forecast_runs VALUES (?, ?, ?, ?, ?, 'open', ?, ?)", [run_id, now, now_ms, current_price, data_points, settings.engine_version, f"features_rebuilt={rebuilt}"])
        items=[]
        for horizon in settings.horizons:
            models = self.arena.run_models(horizon, current_price)
            combined = self.judge.combine(models, current_price)
            combined = _apply_adaptive_pair_calibration(combined, horizon)
            combined = _normalise_forecast_item(combined, current_price, horizon)
            due = now + horizon_delta(horizon)
            item_id = f"{run_id}_{horizon}"
            entry_price = float(current_price)
            target_price = float(combined['expected_price'])
            target_distance_usd = target_price - entry_price
            target_distance_pct = (target_distance_usd / entry_price * 100.0) if entry_price else float(combined['expected_move_pct'])
            inv_price_value, invalidation_distance_pct = calc_invalidation_price(current_price, float(combined['expected_move_pct']), horizon, abs(target_distance_pct))
            invalidation_distance_usd = float(inv_price_value) - entry_price if inv_price_value is not None else None
            # V10.16.46: store entry/target/invalidation distance explicitly.
            # Hitrate alone is not enough; Stijn wants to see how many dollars
            # away the target and invalidation are from the actual entry price.
            db.execute("""
                INSERT INTO forecast_items (
                    item_id, run_id, horizon, due_at, due_at_ms, start_price,
                    bullish_probability, bearish_probability, expected_move_pct, expected_price,
                    entry_price, target_price, target_distance_usd, target_distance_pct,
                    invalidation_price, invalidation_distance_usd, invalidation_distance_pct,
                    bullish_range_low, bullish_range_high, bearish_risk_low, bearish_risk_high,
                    confidence, evidence_count, contributions_json, status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'open')
            """, [item_id, run_id, horizon, due, to_ms(due), current_price, combined['bullish_probability'], combined['bearish_probability'], combined['expected_move_pct'], combined['expected_price'], entry_price, target_price, target_distance_usd, target_distance_pct, inv_price_value, invalidation_distance_usd, invalidation_distance_pct, combined['bullish_range_low'], combined['bullish_range_high'], combined['bearish_risk_low'], combined['bearish_risk_high'], combined['confidence'], combined['evidence_count'], json.dumps(combined['contributions'])])
            items.append({"horizon": horizon, **combined, "entry_price": entry_price, "target_price": target_price, "target_distance_usd": target_distance_usd, "target_distance_pct": target_distance_pct, "invalidation_price": inv_price_value, "invalidation_distance_usd": invalidation_distance_usd, "invalidation_distance_pct": invalidation_distance_pct})
        return {"created": True, "run_id": run_id, "items": items}
