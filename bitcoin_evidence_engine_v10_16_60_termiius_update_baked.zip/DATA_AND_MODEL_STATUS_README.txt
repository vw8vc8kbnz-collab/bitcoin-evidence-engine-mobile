Bitcoin Evidence Engine v10.16.26 — Historical External Warehouse

Doel van deze versie
--------------------
Deze build maakt de externe marktdata net als de 70.000 candles persistent. De tool probeert de externe bronnen niet meer alleen kort live op te halen, maar vult ze stap voor stap historisch in en bewaart alles in:

/home/ubuntu/bitcoin_evidence_data/bitcoin_evidence_engine.duckdb

Belangrijk:
- Nieuwe ZIP-versies mogen deze data-map niet verwijderen.
- Forecast en Time Machine lezen allebei uit dezelfde features/state-vector.
- Externe data die nog niet echt historisch aanwezig is, wordt in Data/Model Cockpit als partial/missing/proxy getoond.
- CoinMetrics/MVRV blijft API-key-afhankelijk en wordt niet gefaket als echte on-chain data.

Nieuwe/verbeterde historische lagen
-----------------------------------
1. Binance Futures Funding Rate
2. Binance Futures Open Interest
3. Binance Futures Global Long/Short Ratio
4. Binance Futures Taker Buy/Sell Ratio
5. Binance Futures Top Trader Position Ratio
6. Binance Futures Top Trader Account Ratio
7. Alternative.me Fear & Greed history
8. Coinbase BTC-USD hourly candle history + premium versus Binance
9. Kraken XBT/USD hourly candle history + premium versus Binance
10. Composite cross-exchange spread where Coinbase and Kraken overlap

Hoe het vult
------------
De achtergrond-daemon vult in pagina's/chunks. Dat is bewust: APIs hebben limieten en mogen de mobiele UI/Forecast nooit blokkeren. Elke daemon-pass gaat verder vanaf de laatst opgeslagen timestamp.

Progress is zichtbaar via:
- Data-tab / evidence status
- /api/evidence/data-sources
- /api/health
- sync_state keys zoals external_progress_funding_rate, external_progress_coinbase_history, external_progress_kraken_history

Wat nog API-key nodig kan hebben
--------------------------------
- CoinMetrics MVRV / realized cap / market cap kan 403 geven zonder API-key.
- In dat geval blijft MVRV missing en krijgt het model geen echte on-chain status.

Test na update
--------------
1. Home openen: prijs + candles moeten snel laden.
2. Data-tab: check welke bronnen active/partial/missing zijn.
3. Wacht de background daemon enkele minuten af.
4. Run Reset TM.
5. Run Random1000.
6. Download Time Machine ZIP.
7. Audit de export: evidence_data_status.csv/json moet laten zien welke externe data echt actief was.
