const CACHE_NAME = 'bee-vps-mobile-v10-16-21-stable-ui';
const ASSETS = [
  '/', '/mobile', '/manifest.webmanifest',
  '/static/css/mobile_app.css?v=10_16_21_stable',
  '/static/js/mobile_app.js?v=10_16_21_stable',
  '/static/icons/icon-192.svg',
  '/static/icons/icon-512.svg'
];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(ASSETS)).catch(()=>null));
  self.skipWaiting();
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))));
  self.clients.claim();
});
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  if (url.pathname.startsWith('/api/')) return;
  event.respondWith(fetch(event.request).catch(() => caches.match(event.request).then(r => r || caches.match('/mobile'))));
});
