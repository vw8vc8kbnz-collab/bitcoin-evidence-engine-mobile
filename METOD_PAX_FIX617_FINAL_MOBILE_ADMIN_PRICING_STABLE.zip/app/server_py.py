#!/usr/bin/env python3
# METOD Tool A + Tool B local server (py-only)
# Serves Tool A UI, Admin UI, and runs Tool B optimizer jobs.

from __future__ import annotations

# Build stamp (debug)
__STICKERTOOL_V2_BUILD = 'FIX600_STABLE_ROLLBACK_ADMIN_JOBS'

import json
import math
import os
import re
import shutil
import subprocess
import sys
import threading
import traceback
import time
import uuid
import base64
import io
import hmac
import hashlib
import secrets
import queue
import zipfile
import ssl
import ipaddress
from datetime import datetime, timedelta, timezone
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs, unquote, quote
from urllib.request import Request, urlopen
from urllib.error import URLError
from typing import Optional, List, Dict, Any, Union

from server_helpers import (
    atomic_write_json as _helpers_atomic_write_json,
    atomic_write_text as _helpers_atomic_write_text,
    extract_request_token as _helpers_extract_request_token,
    read_json_body as _helpers_read_json_body,
    read_json_body_limited as _helpers_read_json_body_limited,
    require_same_origin_admin_write as _helpers_require_same_origin_admin_write,
    safe_job_file as _helpers_safe_job_file,
)
from pricing_helpers import (
    aggregate_materials_from_subjob_quotes as _pricing_aggregate_materials_from_subjob_quotes,
    parse_calculation_summary_totals as _pricing_parse_calculation_summary_totals,
)

ROOT = Path(__file__).resolve().parent
BASE_DIR = str(ROOT)

_DEFAULT_ADMIN_PASSWORDS = {"change-me", "changeme", "admin", "password", "123456", "SET_STRONG_PASSWORD"}
_RATE_LIMITS_LOCK = threading.Lock()
_RATE_LIMITS: dict[tuple[str, str], list[float]] = {}
_PUBLIC_JOB_CREATE_LOCK = threading.Lock()
_PUBLIC_JOB_CREATE_BY_IP: dict[str, int] = {}
_PUBLIC_JOB_CREATE_TOTAL = 0

def _sanitize_filename(name: Any, max_len: int = 120) -> str:
    try:
        raw = str(name or '')
    except Exception:
        raw = ''
    raw = raw.replace('\\', '_').replace('/', '_')
    raw = re.sub(r'[^A-Za-z0-9.,_ -]+', '_', raw).strip(' ._')
    if not raw:
        return ''
    try:
        limit = max(1, int(max_len or 120))
    except Exception:
        limit = 120
    return raw[:limit]

def _direct_peer_ip(handler) -> str:
    try:
        return str((handler.client_address or ["?"])[0] or "?").strip()
    except Exception:
        return "?"

def _split_env_csv(name: str, default: str = "") -> list[str]:
    raw = str(os.environ.get(name, default) or "")
    return [x.strip() for x in raw.split(",") if x.strip()]

def _ip_matches(value: str, pattern: str) -> bool:
    try:
        ip = ipaddress.ip_address(str(value).strip())
        pat = str(pattern).strip()
        if "/" in pat:
            return ip in ipaddress.ip_network(pat, strict=False)
        return ip == ipaddress.ip_address(pat)
    except Exception:
        return str(value or "").strip() == str(pattern or "").strip()

def _is_trusted_proxy_peer(handler) -> bool:
    peer = _direct_peer_ip(handler)
    proxies = _split_env_csv("TRUSTED_PROXY_IPS", "127.0.0.1,::1")
    return any(_ip_matches(peer, p) for p in proxies)

def _extract_forwarded_client_ip(raw: str) -> str:
    # X-Forwarded-For is a comma-separated chain: client, proxy1, proxy2.
    # When the direct peer is trusted, the left-most syntactically valid IP is the client.
    for part in str(raw or "").split(","):
        cand = part.strip()
        if not cand:
            continue
        if cand.startswith("[") and "]" in cand:
            cand = cand[1:cand.index("]")]
        if ":" in cand and cand.count(":") == 1 and not re.search(r"[A-Fa-f]", cand):
            cand = cand.split(":", 1)[0]
        try:
            ipaddress.ip_address(cand)
            return cand
        except Exception:
            continue
    return ""

def _client_ip(handler) -> str:
    try:
        # Only trust forwarded headers from a configured reverse proxy.
        if _is_trusted_proxy_peer(handler):
            xff = str(handler.headers.get("X-Forwarded-For") or "").strip()
            real = _extract_forwarded_client_ip(xff)
            if real:
                return real
            xri = str(handler.headers.get("X-Real-IP") or "").strip()
            try:
                ipaddress.ip_address(xri)
                if xri:
                    return xri
            except Exception:
                pass
        return _direct_peer_ip(handler)
    except Exception:
        return _direct_peer_ip(handler) or "?"

def _is_loopback_value(value: str) -> bool:
    v = str(value or '').strip().lower()
    return v in {'127.0.0.1', '::1', 'localhost'}

def _is_loopback_client(handler) -> bool:
    return _is_loopback_value(_client_ip(handler))

def _credentials_are_default(user: Optional[str], pw: Optional[str]) -> bool:
    try:
        return str(user or '').strip().lower() == 'admin' and str(pw or '').strip() in _DEFAULT_ADMIN_PASSWORDS
    except Exception:
        return False

def _rate_limit_allow(bucket: str, key: str, max_hits: int, window_sec: int) -> bool:
    now = time.time()
    kk = (str(bucket), str(key))
    with _RATE_LIMITS_LOCK:
        arr = [ts for ts in _RATE_LIMITS.get(kk, []) if now - ts < float(window_sec)]
        if len(arr) >= int(max_hits):
            _RATE_LIMITS[kk] = arr
            return False
        arr.append(now)
        _RATE_LIMITS[kk] = arr
        return True


def _rate_limit_is_blocked(bucket: str, key: str, max_hits: int, window_sec: int) -> bool:
    now = time.time()
    kk = (str(bucket), str(key))
    with _RATE_LIMITS_LOCK:
        arr = [ts for ts in _RATE_LIMITS.get(kk, []) if now - ts < float(window_sec)]
        _RATE_LIMITS[kk] = arr
        return len(arr) >= int(max_hits)


def _rate_limit_record(bucket: str, key: str) -> None:
    now = time.time()
    kk = (str(bucket), str(key))
    with _RATE_LIMITS_LOCK:
        arr = _RATE_LIMITS.get(kk, [])
        arr.append(now)
        _RATE_LIMITS[kk] = arr


def _rate_limit_clear(bucket: str, key: str) -> None:
    kk = (str(bucket), str(key))
    with _RATE_LIMITS_LOCK:
        _RATE_LIMITS.pop(kk, None)

def _env_int(name: str, default: int) -> int:
    try:
        raw = str(os.environ.get(name, '')).strip()
        return int(raw) if raw else int(default)
    except Exception:
        return int(default)


def _try_acquire_public_job_slot(ip: str) -> tuple[bool, str]:
    global _PUBLIC_JOB_CREATE_TOTAL
    ip = str(ip or '?')
    max_total = _env_int('PUBLIC_JOB_MAX_CONCURRENT', 4 if _is_production_runtime() else 8)
    max_per_ip = _env_int('PUBLIC_JOB_MAX_CONCURRENT_PER_IP', 2 if _is_production_runtime() else 4)
    with _PUBLIC_JOB_CREATE_LOCK:
        current_ip = int(_PUBLIC_JOB_CREATE_BY_IP.get(ip, 0) or 0)
        if _PUBLIC_JOB_CREATE_TOTAL >= max_total:
            return False, 'total'
        if current_ip >= max_per_ip:
            return False, 'ip'
        _PUBLIC_JOB_CREATE_TOTAL += 1
        _PUBLIC_JOB_CREATE_BY_IP[ip] = current_ip + 1
        return True, 'ok'


def _release_public_job_slot(ip: str) -> None:
    global _PUBLIC_JOB_CREATE_TOTAL
    ip = str(ip or '?')
    with _PUBLIC_JOB_CREATE_LOCK:
        current_ip = int(_PUBLIC_JOB_CREATE_BY_IP.get(ip, 0) or 0)
        if current_ip <= 1:
            _PUBLIC_JOB_CREATE_BY_IP.pop(ip, None)
        else:
            _PUBLIC_JOB_CREATE_BY_IP[ip] = current_ip - 1
        if _PUBLIC_JOB_CREATE_TOTAL > 0:
            _PUBLIC_JOB_CREATE_TOTAL -= 1

_EMAIL_RE = re.compile(r'^[^@\s]+@[^@\s]+\.[^@\s]+$')
_ALLOWED_SUBMIT_ROOT_KEYS = {
    'jobId','parentJobId','subjobId','ts','material','customer','note','grainEnabled',
    'quote','cart','extraPanels','priceInclVat','platesTotal','materialsSummary','checkout'
}

_PUBLIC_STATIC_ROOT_FILES = {
    "toolA.html",
    "embedded_dxfs_manifest.json",
    "toolA_template_helpers.js",
    "toolA_safe_helper_layer.js",
    "toolA_view_math_helpers.js",
    "toolA_render_helpers.js",
    "toolA_template_view_helpers.js",
    "toolA_module_registry.js",
    "toolA_runtime_guard.js",
    "toolA_load_contract.js",
    "toolA_validators.js",
    "toolA_core_selectors.js",
    "toolA_panel_edit_context.js",
    "toolA_panel_form_state.js",
    "toolA_panel_form_apply.js",
    "toolA_extra_panel_form_apply.js",
    "toolA_type_size_decisions.js",
    "toolA_footer_decisions.js",
    "toolA_footer_view_state.js",
    "toolA_footer_apply.js",
    "toolA_footer_bindings.js",
    "toolA_extra_panel_view_state.js",
    "toolA_extra_panel_mutations.js",
    "toolA_extra_panel_submit_flow.js",
    "toolA_extra_panel_submit_apply.js",
    "toolA_panel_mutations.js",
    "toolA_panel_submit_flow.js",
    "toolA_panel_submit_apply.js",
    "toolA_panel_bootstrap_mutations.js",
    "toolA_panel_bootstrap_apply.js",
    "toolA_material_batch_mutations.js",
    "toolA_customer_validation.js",
    "toolA_grain_validation.js",
    "toolA_panel_ui_state.js",
    "toolA_panel_controls_apply.js",
    "toolA_panels_view_models.js",
    "toolA_panel_dock_state.js",
    "toolA_panel_row_view_models.js",
    "toolA_core_read_helpers.js",
    "toolA_core_split_readiness.js",
    "toolA_entrypoints.js",
    "toolA_route_state.js",
    "toolA_route_footer_helpers.js",
    "toolA_showstep_apply.js",
    "toolA_panels_entrypoints.js",
}

_PUBLIC_STATIC_DIR_PREFIXES = (
    "assets/",
    "embedded_dxfs/",
)

_BLOCKED_STATIC_TOP_LEVEL = {
    "config",
    "jobs",
    "requests",
    "archive",
    "backups",
    "system",
    "docs",
    "__pycache__",
}


def _is_public_static_relpath(rel: str) -> bool:
    rel = str(rel or '').strip().lstrip('/')
    if not rel:
        rel = 'toolA.html'
    rel = rel.replace('\\', '/')
    if rel in _PUBLIC_STATIC_ROOT_FILES:
        return True
    if any(rel.startswith(prefix) for prefix in _PUBLIC_STATIC_DIR_PREFIXES):
        return True
    return False


def _is_blocked_static_relpath(rel: str) -> bool:
    rel = str(rel or '').strip().lstrip('/').replace('\\', '/')
    if not rel:
        return False
    parts = [p for p in rel.split('/') if p not in ('', '.')]
    if not parts:
        return False
    first = parts[0]
    if first in _BLOCKED_STATIC_TOP_LEVEL:
        return True
    if any(part.startswith('.') for part in parts):
        return True
    low = rel.lower()
    if low.endswith(('.log', '.jsonl', '.py', '.pyc', '.bat', '.ps1', '.sh')):
        return True
    return False


def _pbkdf2_hash_password(password: str, *, iterations: int = 260000, salt: Optional[str] = None) -> str:
    salt = salt or secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac('sha256', str(password).encode('utf-8'), str(salt).encode('utf-8'), int(iterations))
    return f"pbkdf2_sha256${int(iterations)}${salt}${dk.hex()}"

def _verify_password_against_stored(password: str, stored: str) -> bool:
    try:
        raw = str(stored or '')
        if not raw:
            return False
        if raw.startswith('pbkdf2_sha256$'):
            parts = raw.split('$', 3)
            if len(parts) != 4:
                return False
            _, iter_s, salt, expected = parts
            calc = _pbkdf2_hash_password(password, iterations=int(iter_s), salt=salt)
            return hmac.compare_digest(calc, raw)
        return hmac.compare_digest(str(password or ''), raw)
    except Exception:
        return False


def _is_password_hash_value(v: Any) -> bool:
    try:
        raw = str(v or '')
        return raw.startswith('pbkdf2_sha256$')
    except Exception:
        return False

def _env_flag(name: str, default: bool = False) -> bool:
    raw = str(os.environ.get(name, '')).strip().lower()
    if not raw:
        return bool(default)
    return raw in ('1', 'true', 'yes', 'on', 'prod', 'production')

def _is_production_hardening_enabled() -> bool:
    if _env_flag('PRODUCTION_HARDENING', False) or _env_flag('ADMIN_HASH_ONLY', False):
        return True
    app_env = str(os.environ.get('APP_ENV', '')).strip().lower()
    return app_env in ('prod', 'production')

def _is_https_request(handler) -> bool:
    try:
        if _is_trusted_proxy_peer(handler):
            xf = str(handler.headers.get('X-Forwarded-Proto') or '').strip().lower()
            if xf:
                return xf == 'https'
    except Exception:
        pass
    try:
        return bool(getattr(handler.server, 'server_port', None) == 443)
    except Exception:
        return False

def _is_secure_admin_transport(handler) -> bool:
    try:
        if _is_loopback_client(handler):
            return True
    except Exception:
        pass
    return _is_https_request(handler)

def _is_production_runtime() -> bool:
    return _is_production_hardening_enabled()

def _get_admin_credentials_file_path() -> Path:
    raw = str(os.environ.get('ADMIN_CREDENTIALS_FILE') or os.environ.get('ADMIN_CREDENTIALS_PATH') or '').strip()
    if raw:
        try:
            return Path(raw).expanduser()
        except Exception:
            pass
    return ROOT / 'config' / 'admin_credentials.json'

def _get_admin_password_reset_activation_file_path() -> Path:
    raw = str(os.environ.get('ADMIN_PASSWORD_RESET_ACTIVATION_FILE') or os.environ.get('ADMIN_PASSWORD_RESET_ACTIVATION_PATH') or '').strip()
    if raw:
        try:
            return Path(raw).expanduser()
        except Exception:
            pass
    return ROOT / 'config' / 'admin_password_reset_activation.json'

def _load_admin_password_reset_activation() -> dict | None:
    path = _get_admin_password_reset_activation_file_path()
    try:
        with open(path, 'r', encoding='utf-8') as f:
            obj = json.load(f)
        if isinstance(obj, dict):
            obj['_path'] = str(path)
            return obj
    except Exception:
        return None
    return None

def _admin_password_reset_activation_is_enabled() -> bool:
    try:
        obj = _load_admin_password_reset_activation() or {}
        return bool(obj.get('enabled'))
    except Exception:
        return False

def _split_env_origins(name: str) -> list[str]:
    vals = []
    for raw in str(os.environ.get(name, '')).split(','):
        item = str(raw or '').strip()
        if item:
            vals.append(item)
    return vals

def _origin_allowed(origin: str, *, admin: bool = False) -> bool:
    origin = str(origin or '').strip()
    if not origin:
        return False
    extra = _split_env_origins('ALLOWED_ADMIN_ORIGINS' if admin else 'ALLOWED_ORIGINS')
    if origin in extra:
        return True
    try:
        parsed = urlparse(origin)
        host = str(parsed.hostname or '').strip().lower()
    except Exception:
        return False
    if not host:
        return False
    if _is_production_runtime():
        return False
    return _is_loopback_value(host)

def _public_error_message(code: int, fallback: str = 'Er ging iets mis.') -> str:
    code = int(code or 500)
    if code == 400:
        return 'Ongeldige aanvraag.'
    if code == 403:
        return 'Actie niet toegestaan.'
    if code == 404:
        return 'Niet gevonden.'
    if code == 413:
        return 'Aanvraag te groot.'
    if code == 429:
        return 'Te veel verzoeken. Probeer het later opnieuw.'
    return fallback

def _is_str(v: Any) -> bool:
    return isinstance(v, str)

def _clean_text(v: Any, max_len: int = 5000) -> str:
    s = str(v or '')
    if len(s) > int(max_len):
        s = s[:int(max_len)]
    return s


_FORBIDDEN_FILE_CHARS = set('/\\:*?"<>|')
_ALLOWED_USER_TEXT_EXTRA = set(" .,_-")
_ALLOWED_NOTE_EXTRA = set(" .,_-")

def _sanitize_user_text(v: Any, max_len: int = 240, *, allow_note_chars: bool = False) -> str:
    raw = _clean_text(v, max_len * 4 if max_len else 4000)
    extras = _ALLOWED_NOTE_EXTRA if allow_note_chars else _ALLOWED_USER_TEXT_EXTRA
    out = []
    last_space = False
    for ch in raw:
        if ch in ('\r', '\n', '\t'):
            ch = ' '
        allowed = ch.isalnum() or ch in extras
        if not allowed and ch in _FORBIDDEN_FILE_CHARS:
            ch = ' '
            allowed = True
        if not allowed:
            continue
        if ch.isspace():
            if last_space:
                continue
            out.append(' ')
            last_space = True
        else:
            out.append(ch)
            last_space = False
    s = ''.join(out).strip()
    if max_len and len(s) > int(max_len):
        s = s[:int(max_len)].rstrip()
    return s

def _sanitize_phone_text(v: Any, max_len: int = 60) -> str:
    raw = _clean_text(v, max_len * 2)
    out = []
    for ch in raw:
        if ch.isdigit() or ch in ' +()-':
            out.append(ch)
    s = re.sub(r'\s+', ' ', ''.join(out)).strip()
    return s[:max_len]

def _sanitize_postcode_text(v: Any, max_len: int = 16) -> str:
    raw = _clean_text(v, max_len * 2)
    out = []
    for ch in raw:
        if ch.isalnum() or ch == ' ':
            out.append(ch.upper())
    s = re.sub(r'\s+', ' ', ''.join(out)).strip()
    return s[:max_len]

def _validate_submit_payload(payload: Any) -> tuple[bool, list[str], dict]:
    errs: list[str] = []
    clean: dict = {}
    if not isinstance(payload, dict):
        return False, ['Payload must be a JSON object.'], {}

    # Be tolerant with extra frontend fields so submit flows keep working across
    # slightly different Tool A builds. We validate and sanitize the fields we know,
    # but we do not hard-fail on additional root keys.
    unknown = [k for k in payload.keys() if k not in _ALLOWED_SUBMIT_ROOT_KEYS]

    def _safe_id_field(name: str, max_len: int = 200):
        val = payload.get(name)
        if val in (None, ''):
            return
        sval = str(val).strip()
        if not re.fullmatch(r'[A-Za-z0-9_.:\-]{1,%d}' % int(max_len), sval):
            errs.append(f'Ongeldige waarde voor {name}.')
        else:
            clean[name] = sval

    _safe_id_field('jobId')
    _safe_id_field('parentJobId')
    _safe_id_field('subjobId')

    if payload.get('ts') not in (None, ''):
        ts = str(payload.get('ts')).strip()
        if len(ts) > 80:
            errs.append('Tijdstempel is te lang.')
        else:
            clean['ts'] = ts

    if payload.get('material') is not None:
        if not isinstance(payload.get('material'), (str, dict, list, type(None))):
            errs.append('Materiaalveld heeft een ongeldig type.')
        else:
            clean['material'] = payload.get('material')

    if payload.get('grainEnabled') is not None and not isinstance(payload.get('grainEnabled'), bool):
        errs.append('grainEnabled moet true of false zijn.')
    else:
        clean['grainEnabled'] = bool(payload.get('grainEnabled')) if payload.get('grainEnabled') is not None else None

    note = payload.get('note')
    if note not in (None, ''):
        if not _is_str(note):
            errs.append('Opmerking moet tekst zijn.')
        else:
            clean['note'] = _sanitize_user_text(note, 4000, allow_note_chars=True)

    cust = payload.get('customer')
    if cust is None:
        cust = {}
    if not isinstance(cust, dict):
        errs.append('Klantgegevens moeten een object zijn.')
        cust = {}
    cc = {}
    allowed_customer_keys = {'name','fullName','firstName','lastName','email','mail','phone','tel','telephone','billingAddress','invoiceAddress','address','addressLine1','street','shippingAddress','deliveryAddress','address1','postalCode','postcode','city','plaats','country','note'}
    for k, v in list(cust.items())[:100]:
        if k not in allowed_customer_keys:
            continue
        if v in (None, ''):
            continue
        if not _is_str(v):
            errs.append(f'Klantveld {k} moet tekst zijn.')
            continue
        max_len = 320 if k in {'email','mail'} else 500
        if k in {'email','mail'}:
            cc[k] = _clean_text(v, max_len).strip()
        elif k in {'phone','tel','telephone'}:
            cc[k] = _sanitize_phone_text(v, min(max_len, 60))
        elif k in {'postalCode','postcode'}:
            cc[k] = _sanitize_postcode_text(v, 16)
        elif k in {'note'}:
            cc[k] = _sanitize_user_text(v, max_len, allow_note_chars=True)
        else:
            cc[k] = _sanitize_user_text(v, max_len)
    email = str(cc.get('email') or cc.get('mail') or '').strip()
    if not email:
        errs.append('E-mailadres ontbreekt.')
    elif not _EMAIL_RE.match(email):
        errs.append('E-mailadres is ongeldig.')
    clean['customer'] = cc

    quote = payload.get('quote')
    if quote is not None and not isinstance(quote, dict):
        errs.append('Quote moet een object zijn.')
    elif isinstance(quote, dict):
        try:
            if len(json.dumps(quote)) > 400000:
                errs.append('Quote is te groot.')
            else:
                clean['quote'] = quote
        except Exception:
            errs.append('Quote kon niet worden verwerkt.')

    mats = payload.get('materialsSummary')
    if mats is not None:
        if not isinstance(mats, list):
            errs.append('materialsSummary moet een lijst zijn.')
        elif len(mats) > 100:
            errs.append('materialsSummary bevat te veel regels.')
        else:
            out = []
            for idx, it in enumerate(mats):
                if not isinstance(it, dict):
                    errs.append(f'materialsSummary regel {idx+1} is ongeldig.')
                    continue
                row = {}
                for k in ('code','name'):
                    if it.get(k) not in (None, ''):
                        if not _is_str(it.get(k)):
                            errs.append(f'materialsSummary.{k} op regel {idx+1} moet tekst zijn.')
                        else:
                            row[k] = _clean_text(it.get(k), 200)
                if it.get('plates') not in (None, ''):
                    try:
                        plates = float(it.get('plates'))
                        if plates < 0 or plates > 10000:
                            raise ValueError()
                        row['plates'] = plates
                    except Exception:
                        errs.append(f'materialsSummary.plates op regel {idx+1} is ongeldig.')
                out.append(row)
            clean['materialsSummary'] = out

    for num_name in ('priceInclVat','platesTotal'):
        if payload.get(num_name) not in (None, ''):
            try:
                val = float(payload.get(num_name))
                if not (0 <= val <= 100000000):
                    raise ValueError()
                clean[num_name] = val
            except Exception:
                errs.append(f'{num_name} is ongeldig.')

    def _validate_panel_list(name: str):
        arr = payload.get(name)
        if arr is None:
            clean[name] = []
            return
        if not isinstance(arr, list):
            errs.append(f'{name} moet een lijst zijn.')
            return
        if len(arr) > 1000:
            errs.append(f'{name} bevat te veel regels.')
            return
        out = []
        allowed_keys = {'id','type','size','qty','quantity','width','height','length','name','panelName','description','materialCode','materialKey','articleNumber','materialDisplayName','productName','decorName','grainGroupId','grainOrder','rotation','topExt','bottomExt','extensions','edgeBanding','material','hingeSide','swingDirection'}
        for idx, it in enumerate(arr):
            if not isinstance(it, dict):
                errs.append(f'{name} regel {idx+1} is ongeldig.')
                continue
            row = {}
            for k,v in list(it.items())[:80]:
                if k not in allowed_keys:
                    continue
                if isinstance(v, (str, int, float, bool)) or v is None:
                    if isinstance(v, str):
                        if k in {'name','panelName','description','productName','articleNumber'}:
                            row[k] = _sanitize_user_text(v, 240)
                        else:
                            row[k] = _clean_text(v, 500)
                    else:
                        row[k] = v
                elif isinstance(v, dict):
                    if k == 'edgeBanding':
                        eb = {}
                        for ek,ev in list(v.items())[:10]:
                            if ek in {'top','bottom','left','right'}:
                                eb[ek] = bool(ev)
                        row[k] = eb
                    elif k == 'extensions':
                        ex = {}
                        for ek,ev in list(v.items())[:10]:
                            if ek in {'top','bottom'}:
                                try:
                                    ex[ek] = float(ev)
                                except Exception:
                                    pass
                        row[k] = ex
                # other nested values ignored
            qty = row.get('qty', row.get('quantity', 1))
            try:
                qtyn = int(qty)
                if qtyn < 1 or qtyn > 10000:
                    raise ValueError()
                row['qty'] = qtyn
                row.pop('quantity', None)
            except Exception:
                errs.append(f'{name} regel {idx+1} heeft een ongeldig aantal.')
            for nk in ('width','height','length','topExt','bottomExt'):
                if nk in row and row[nk] not in (None, ''):
                    try:
                        fv = float(row[nk])
                        if fv < 0 or fv > 100000:
                            raise ValueError()
                        row[nk] = fv
                    except Exception:
                        errs.append(f'{name} regel {idx+1} heeft een ongeldig veld {nk}.')
            out.append(row)
        clean[name] = out

    _validate_panel_list('cart')
    _validate_panel_list('extraPanels')

    checkout = payload.get('checkout')
    if checkout is not None:
        if not isinstance(checkout, dict):
            errs.append('checkout moet een object zijn.')
        else:
            clean['checkout'] = checkout

    panel_count = len(clean.get('cart') or []) + len(clean.get('extraPanels') or [])
    if panel_count <= 0:
        errs.append('Geen panelen gevonden in de aanvraag.')

    return len(errs) == 0, errs, clean


def _extract_request_token(handler, parsed=None, body: Optional[dict]=None) -> str:
    return _helpers_extract_request_token(handler, parsed=parsed, body=body)

def _new_public_access_token() -> str:
    return uuid.uuid4().hex + uuid.uuid4().hex

def _write_job_access_token(job_id: str, token: str) -> None:
    try:
        job_root = JOBS / str(job_id)
        if not job_root.exists():
            return
        _atomic_write_json(job_root / '.public_access.json', {'token': str(token), 'jobId': str(job_id), 'updatedAt': _utc_now_iso()})
    except Exception:
        pass

def _read_job_access_token(job_id: str) -> str:
    try:
        job_root = JOBS / str(job_id)
        path = job_root / '.public_access.json'
        if not path.exists():
            return ''
        data = json.loads(path.read_text(encoding='utf-8') or '{}')
        return str(data.get('token') or '').strip()
    except Exception:
        return ''

# Prefer the Windows Python launcher (py -3) to avoid binding to a specific installed python.exe
# and to keep compatibility with environments where sys.executable may be a newer Python (e.g. 3.14).
def _get_python_base_cmd():
    # Use the same Python interpreter as the server for maximum compatibility and speed.
    # (Avoid calling the Windows py launcher for Tool B, which can be slow and may select a different Python version.)
    return [sys.executable]

# --- Server-Sent Events (SSE) for live updates (ToolA reload without page refresh) ---
_SSE_CLIENTS_LOCK = threading.Lock()
_SSE_CLIENTS: list[queue.Queue] = []


def _sse_broadcast(event: Optional[str] = None, data: Optional[dict] = None) -> None:
    """Broadcast an SSE event to all connected clients (best-effort)."""
    payload = {
        "event": event,
        "data": data or {},
        "ts": datetime.utcnow().isoformat() + "Z",
    }
    with _SSE_CLIENTS_LOCK:
        dead: list[queue.Queue] = []
        for q in _SSE_CLIENTS:
            try:
                q.put_nowait(payload)
            except Exception:
                dead.append(q)
        if dead:
            _SSE_CLIENTS[:] = [q for q in _SSE_CLIENTS if q not in dead]


def _sse_handler(handler) -> None:
    """Handle /api/events SSE stream."""
    handler.send_response(200)
    handler.send_header('Content-Type', 'text/event-stream; charset=utf-8')
    handler.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
    handler.send_header('Pragma', 'no-cache')
    handler.send_header('Connection', 'keep-alive')
    handler.end_headers()

    q = queue.Queue(maxsize=200)
    with _SSE_CLIENTS_LOCK:
        _SSE_CLIENTS.append(q)

    # Initial hello + current DXF version
    try:
        init = {
            "event": "hello",
            "data": {"dxfVersion": get_embedded_dxfs_version()},
            "ts": datetime.utcnow().isoformat() + "Z",
        }
        handler.wfile.write(f"event: {init['event']}\n".encode('utf-8'))
        handler.wfile.write(f"data: {json.dumps(init)}\n\n".encode('utf-8'))
        handler.wfile.flush()
    except Exception:
        with _SSE_CLIENTS_LOCK:
            try:
                _SSE_CLIENTS.remove(q)
            except ValueError:
                pass
        return

    last_ping = time.time()
    try:
        while True:
            try:
                msg = q.get(timeout=5.0)
                handler.wfile.write(f"event: {msg['event']}\n".encode('utf-8'))
                handler.wfile.write(f"data: {json.dumps(msg)}\n\n".encode('utf-8'))
                handler.wfile.flush()
            except queue.Empty:
                pass

            now = time.time()
            if now - last_ping >= 15.0:
                last_ping = now
                handler.wfile.write(b": ping\n\n")
                handler.wfile.flush()
    except Exception:
        pass
    finally:
        with _SSE_CLIENTS_LOCK:
            try:
                _SSE_CLIENTS.remove(q)
            except ValueError:
                pass

# --- DXF startup migration (file-based, deterministic) ---
DXF_CATEGORIES = [
    "Deuren METOD",
    "Ladefront METOD",
    "Deuren PAX",
    "Overige panelen",
]

def _classify_dxf_filename(name: str) -> str:
    n = name.lower()
    # PAX first
    if n.startswith("pax"):
        return "Deuren PAX"
    # METOD ladefront
    if n.startswith("metod") and ("lade" in n or "ladefront" in n):
        return "Ladefront METOD"
    # METOD deuren
    if n.startswith("metod") and ("deur" in n or "deuren" in n):
        return "Deuren METOD"
    return "Overige panelen"

def migrate_embedded_dxfs_on_startup():
    # Moves DXF files from embedded_dxfs root into category folders.
    # One-time safe: only removes the original file after successful move.
    # Deterministic: classification uses filename only.
    dxf_root = ROOT / "embedded_dxfs"
    dxf_root.mkdir(parents=True, exist_ok=True)

    # Ensure category folders exist
    for cat in DXF_CATEGORIES:
        (dxf_root / cat).mkdir(parents=True, exist_ok=True)

    moved = 0
    for fp in sorted(dxf_root.iterdir()):
        if not fp.is_file():
            continue
        if fp.suffix.lower() != ".dxf":
            continue
        target_cat = _classify_dxf_filename(fp.name)
        dest = dxf_root / target_cat / fp.name
        if dest.exists():
            # Keep category version; leave root file untouched
            continue
        try:
            shutil.move(str(fp), str(dest))
            moved += 1
        except Exception:
            continue
    return moved

OPTIMIZER_TOOL_B = 'dxf_nesting_optimizer.py'  # rollback: set to 'dxf_nesting_optimizer_v1_2.py'
JOBS = ROOT / "jobs"
DRAFTS = ROOT / "drafts"

# Lightweight index/registry folder (used by some endpoints).
INDEX_DIR = ROOT / "index"

# Append-only requests index (JSONL). This is used to power Admin inbox views
# without scanning the full requests tree. Must be defined at module load so
# endpoints like /api/submit_config never fail with NameError.
REQUESTS_INDEX = INDEX_DIR / "requests_index.jsonl"

# --- Requests/Queue (online A-only foundation; file-based, deterministic) ---
REQUESTS = ROOT / "requests"
QUEUE_DIR = ROOT / "queue"
QUEUE_PENDING = QUEUE_DIR / "pending"
QUEUE_PROCESSING = QUEUE_DIR / "processing"
QUEUE_DONE = QUEUE_DIR / "done"
QUEUE_FAILED = QUEUE_DIR / "failed"

# --- Retention / archive (submitted/request-linked: 90 dagen actief -> archive, 90 dagen archive -> delete; orphan jobs: direct delete na 7 dagen) ---
ARCHIVE_ROOT = ROOT / "archive"
ARCHIVE_JOBS = ARCHIVE_ROOT / "jobs"
ARCHIVE_REQUESTS = ARCHIVE_ROOT / "requests"
ARCHIVE_QUEUE_DONE = ARCHIVE_ROOT / "queue_done"
ARCHIVE_QUEUE_FAILED = ARCHIVE_ROOT / "queue_failed"
RETENTION_ACTIVE_DAYS = 90
RETENTION_ARCHIVE_DAYS = 90
ORPHAN_JOB_RETENTION_DAYS = 7
ARCHIVE_META_NAME = ".archived_meta.json"
_LAST_RETENTION_RUN_TS = 0.0
_RETENTION_MIN_INTERVAL_SECONDS = 6 * 60 * 60  # max 1x per 6 uur per proces

# Queue / maintenance hardening
STALE_PENDING_QUEUE_DAYS = 7
STALE_PROCESSING_QUEUE_HOURS = 24
_LAST_QUEUE_MAINTENANCE_TS = 0.0
_QUEUE_MAINTENANCE_MIN_INTERVAL_SECONDS = 60 * 60  # max 1x per uur per proces
_SERVER_MAINTENANCE_LOOP_SECONDS = 15 * 60

# --- System logs / backups ---
SYSTEM_DIR = ROOT / "system"
SYSTEM_LOG_FILE = SYSTEM_DIR / "system_events.jsonl"
BACKUPS_DIR = ROOT / "backups"
AUTO_BACKUP_INTERVAL_DAYS = 7
AUTO_BACKUP_KEEP = 8
MANUAL_BACKUP_KEEP = 12
LAST_AUTO_BACKUP_FILE = SYSTEM_DIR / "last_auto_backup.json"



def _ensure_system_dirs() -> None:
    for d in (SYSTEM_DIR, BACKUPS_DIR):
        d.mkdir(parents=True, exist_ok=True)


def _safe_text(v, max_len: int = 240) -> str:
    try:
        s = str(v or "").strip()
    except Exception:
        s = ""
    if len(s) > max_len:
        s = s[: max_len - 1] + "…"
    return s


_REDACT_EMAIL_RE = re.compile(r'([A-Za-z0-9._%+-])[A-Za-z0-9._%+-]*@([A-Za-z0-9.-]+\.[A-Za-z]{2,})')
_REDACT_PHONE_RE = re.compile(r'(?<!\w)(?:\+?\d[\d()\-\s]{6,}\d)(?!\w)')
_REDACT_POSTCODE_RE = re.compile(r'\b\d{4}\s?[A-Za-z]{2}\b')
_REDACT_TOKEN_RE = re.compile(r'(?i)\b(?:token|password|passwd|secret|authorization|cookie|set-cookie)\b\s*[:=]\s*[^,;\s]+')
_REDACT_URL_QUERY_RE = re.compile(r'([?&](?:email|mail|phone|tel|telephone|address|postcode|postalcode|token|password|secret)=[^&#]*)', re.I)


def _redact_sensitive_text(v, max_len: int = 240) -> str:
    s = _safe_text(v, max_len=max_len * 2 if max_len and max_len > 0 else 480)
    if not s:
        return ""
    try:
        s = _REDACT_EMAIL_RE.sub(lambda m: f"{m.group(1)}***@{m.group(2)}", s)
        s = _REDACT_PHONE_RE.sub('[redacted-phone]', s)
        s = _REDACT_POSTCODE_RE.sub('[redacted-postcode]', s)
        s = _REDACT_TOKEN_RE.sub('[redacted-secret]', s)
        s = _REDACT_URL_QUERY_RE.sub('[redacted-query]', s)
    except Exception:
        pass
    if max_len and len(s) > max_len:
        s = s[: max_len - 1] + "…"
    return s


def _sanitize_log_value(value, *, max_depth: int = 2, max_items: int = 20):
    if max_depth < 0:
        return '[truncated]'
    if value is None or isinstance(value, (bool, int, float)):
        return value
    if isinstance(value, str):
        return _redact_sensitive_text(value, 300)
    if isinstance(value, dict):
        out = {}
        for i, (k, v) in enumerate(value.items()):
            if i >= max_items:
                out['__truncated__'] = True
                break
            ks = str(k)[:80]
            low = ks.lower()
            if low in {'password', 'passwd', 'secret', 'token', 'authorization', 'cookie', 'set-cookie', 'email', 'mail', 'phone', 'tel', 'telephone', 'address', 'billingaddress', 'shippingaddress', 'postcode', 'postalcode'}:
                out[ks] = '[redacted]'
            else:
                out[ks] = _sanitize_log_value(v, max_depth=max_depth - 1, max_items=max_items)
        return out
    if isinstance(value, (list, tuple)):
        out = []
        for i, item in enumerate(value):
            if i >= max_items:
                out.append('[truncated]')
                break
            out.append(_sanitize_log_value(item, max_depth=max_depth - 1, max_items=max_items))
        return out
    return _redact_sensitive_text(value, 200)


def _guess_customer_name_from_payload(payload: dict | None) -> str:
    if not isinstance(payload, dict):
        return ""
    for key in ("customer", "client", "contact"):
        obj = payload.get(key)
        if isinstance(obj, dict):
            for nk in ("name", "fullName", "company", "companyName"):
                val = _safe_text(obj.get(nk), 120)
                if val:
                    return val
    for nk in ("customerName", "name", "companyName", "company"):
        val = _safe_text(payload.get(nk), 120)
        if val:
            return val
    return ""


def _guess_customer_name(request_id: str = "", payload: dict | None = None, status: dict | None = None) -> str:
    name = _guess_customer_name_from_payload(payload)
    if name:
        return name
    if isinstance(status, dict):
        for key in ("customerName", "customer", "clientName", "name"):
            val = status.get(key)
            if isinstance(val, dict):
                val = val.get("name") or val.get("company")
            val = _safe_text(val, 120)
            if val:
                return val
    rid = _safe_id(request_id or "", 120)
    if rid:
        try:
            fp = REQUESTS / rid / "input" / "submit_payload.json"
            if fp.exists():
                pl = json.loads(fp.read_text(encoding="utf-8"))
                return _guess_customer_name_from_payload(pl)
        except Exception:
            pass
    return ""


def _append_system_event(*, level: str = "error", component: str = "system", message_user: str, message_tech: str = "", request_id: str = "", job_id: str = "", customer_name: str = "", status: str = "open", details: dict | None = None) -> None:
    try:
        _ensure_system_dirs()
        rec = {
            "ts": _now_iso(),
            "level": _safe_text(level, 32) or "error",
            "component": _safe_text(component, 64) or "system",
            "messageUser": _safe_text(message_user, 400),
            "messageTech": _redact_sensitive_text(message_tech, 1200),
            "requestId": _safe_text(request_id, 120),
            "jobId": _safe_text(job_id, 120),
            "customerName": "",
            "status": _safe_text(status, 32) or "open",
            "details": _sanitize_log_value(details or {}, max_depth=2, max_items=20),
        }
        with open(SYSTEM_LOG_FILE, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    except Exception:
        pass


def _read_system_events(limit: int = 200) -> list[dict]:
    try:
        if not SYSTEM_LOG_FILE.exists():
            return []
        lines = SYSTEM_LOG_FILE.read_text(encoding="utf-8", errors="ignore").splitlines()
        out = []
        for line in reversed(lines[-max(1, int(limit)*3):]):
            try:
                rec = json.loads(line)
                if isinstance(rec, dict):
                    out.append(rec)
                    if len(out) >= limit:
                        break
            except Exception:
                continue
        return out
    except Exception:
        return []


def _cleanup_old_backups() -> None:
    try:
        _ensure_system_dirs()
        auto_files = []
        manual_files = []
        for fp in BACKUPS_DIR.glob("*.zip"):
            nm = fp.name.lower()
            if nm.startswith("system_backup_auto_"):
                auto_files.append(fp)
            elif nm.startswith("system_backup_manual_"):
                manual_files.append(fp)
            elif nm.startswith("system_backup_"):
                manual_files.append(fp)
        auto_files = sorted(auto_files, key=lambda p: p.stat().st_mtime, reverse=True)
        manual_files = sorted(manual_files, key=lambda p: p.stat().st_mtime, reverse=True)
        for fp in auto_files[AUTO_BACKUP_KEEP:]:
            try:
                fp.unlink()
            except Exception:
                pass
        for fp in manual_files[MANUAL_BACKUP_KEEP:]:
            try:
                fp.unlink()
            except Exception:
                pass
    except Exception:
        pass


def _write_last_auto_backup(dt: datetime, file_name: str) -> None:
    try:
        _ensure_system_dirs()
        LAST_AUTO_BACKUP_FILE.write_text(json.dumps({
            "ts": dt.isoformat(),
            "file": file_name,
        }, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass


def _read_last_auto_backup_dt() -> datetime | None:
    try:
        if LAST_AUTO_BACKUP_FILE.exists():
            data = json.loads(LAST_AUTO_BACKUP_FILE.read_text(encoding="utf-8"))
            ts = str((data or {}).get("ts") or "").strip()
            if ts:
                return datetime.fromisoformat(ts)
    except Exception:
        pass
    try:
        auto_files = sorted(BACKUPS_DIR.glob("system_backup_auto_*.zip"), key=lambda p: p.stat().st_mtime, reverse=True)
        if auto_files:
            return datetime.fromtimestamp(auto_files[0].stat().st_mtime)
    except Exception:
        pass
    return None


def run_backup_maintenance(force: bool = False) -> dict:
    try:
        _ensure_system_dirs()
        _cleanup_old_backups()
        last_dt = _read_last_auto_backup_dt()
        now = datetime.now()
        if (not force) and last_dt and (now - last_dt) < timedelta(days=AUTO_BACKUP_INTERVAL_DAYS):
            return {
                "ok": True,
                "created": False,
                "reason": "recent_auto_backup_exists",
                "last": last_dt.isoformat(),
            }
        res = _create_system_backup(actor="system", backup_kind="auto")
        _write_last_auto_backup(now, str(res.get("file") or ""))
        return {"ok": True, "created": True, "backup": res}
    except Exception as e:
        _append_system_event(level="error", component="backup", message_user="Automatische backup is mislukt", message_tech=str(e), status="open")
        return {"ok": False, "error": str(e)}


def _create_system_backup(actor: str = "admin", backup_kind: str = "manual") -> dict:
    _ensure_system_dirs()
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    prefix = "system_backup_auto" if str(backup_kind).lower() == "auto" else "system_backup_manual"
    out = BACKUPS_DIR / f"{prefix}_{ts}.zip"
    include = [
        ROOT / "server_py.py",
        ROOT / "toolA.html",
        ROOT / "material_library.json",
        ROOT / "pricing_v13mm.json",
        ROOT / "embedded_dxfs_manifest.json",
        ROOT / "config",
        ROOT / "embedded_dxfs",
        ROOT / "jobs",
        ROOT / "requests",
        ROOT / "archive",
        ROOT / "system",
    ]
    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for src in include:
            if not src.exists():
                continue
            if src.is_file():
                zf.write(src, src.relative_to(ROOT).as_posix())
                continue
            for child in src.rglob('*'):
                if not child.exists() or not child.is_file():
                    continue
                try:
                    zf.write(child, child.relative_to(ROOT).as_posix())
                except Exception:
                    pass
    _cleanup_old_backups()
    msg = "Automatische backup voltooid" if str(backup_kind).lower() == "auto" else "Handmatige backup voltooid"
    _append_system_event(level="info", component="backup", message_user=msg, message_tech=f"Created {out.name}", status="resolved", details={"actor": actor, "file": out.name, "kind": backup_kind})
    st = out.stat()
    return {"ok": True, "file": out.name, "path": str(out), "size": st.st_size, "modified": datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M:%S"), "kind": backup_kind}


def _list_backups(limit: int = 50) -> list[dict]:
    try:
        _ensure_system_dirs()
        items = []
        for fp in sorted(BACKUPS_DIR.glob("*.zip"), key=lambda p: p.stat().st_mtime, reverse=True)[:limit]:
            st = fp.stat()
            nm = fp.name.lower()
            kind = "auto" if nm.startswith("system_backup_auto_") else "manual"
            items.append({
                "name": fp.name,
                "size": st.st_size,
                "modified": datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M:%S"),
                "kind": kind,
            })
        return items
    except Exception:
        return []


# --- Notifications (ntfy) ---
CONFIG_NOTIFY = ROOT / "config_notify.json"
CONFIG_NOTIFY_EXAMPLE = ROOT / "config_notify.example.json"

def _get_notify_config_file_path() -> Path:
    raw = str(os.environ.get('NOTIFY_CONFIG_FILE') or os.environ.get('CONFIG_NOTIFY_FILE') or '').strip()
    if raw:
        try:
            return Path(raw).expanduser()
        except Exception:
            pass
    return CONFIG_NOTIFY

NTFY_LOG = ROOT / "_client_logs" / "ntfy.log"

def _ntfy_log(line: str) -> None:
    try:
        (ROOT / "_client_logs").mkdir(parents=True, exist_ok=True)
        ts = datetime.utcnow().isoformat() + "Z"
        with open(NTFY_LOG, "a", encoding="utf-8") as f:
            f.write(f"{ts} {line}\n")
    except Exception:
        pass


def _load_notify_config() -> dict:
    """
    Notification config is OPTIONAL.
    - If app/config_notify.json exists, it overrides defaults.
    - If missing, we use safe defaults so it works out-of-the-box.
    """
    defaults = {
        "ntfy": {
            "enabled": False,
            "topic_url": "",
            "title": "AD Zaagt Configurator",
            "include_customer_details": False,
            "include_price_breakdown": False,
            "minimal_order_notice": True,
        }
    }
    try:
        notify_cfg_path = _get_notify_config_file_path()
        if notify_cfg_path.exists():
            cfg = json.loads(notify_cfg_path.read_text(encoding="utf-8"))
            if isinstance(cfg, dict):
                # shallow-merge defaults
                out = defaults.copy()
                nt = defaults.get("ntfy", {}).copy()
                if isinstance(cfg.get("ntfy"), dict):
                    nt.update(cfg.get("ntfy"))
                out["ntfy"] = nt
                return out
    except Exception:
        pass
    return defaults



_MATERIAL_NAME_BY_CODE = None

def _load_material_name_by_code() -> dict:
    global _MATERIAL_NAME_BY_CODE
    if isinstance(_MATERIAL_NAME_BY_CODE, dict):
        return _MATERIAL_NAME_BY_CODE
    out = {}
    try:
        ml_path = ROOT / "material_library.json"
        if ml_path.exists():
            raw = json.loads(ml_path.read_text(encoding="utf-8"))
            recs = raw.get("records") if isinstance(raw, dict) else raw
            if isinstance(recs, list):
                for r in recs:
                    if not isinstance(r, dict):
                        continue
                    code = str(r.get("articleNo") or r.get("articleNumber") or r.get("materialCode") or "").strip()
                    name = str(r.get("productName") or r.get("materialDisplayName") or r.get("materialName") or "").strip()
                    if code and name and code not in out:
                        out[code] = name
    except Exception:
        pass
    _MATERIAL_NAME_BY_CODE = out
    return out

def _looks_numeric_material_name(v: str) -> bool:
    vv = str(v or "").strip().replace(",", ".")
    if not vv:
        return False
    try:
        float(vv)
        return True
    except Exception:
        return False

def _best_material_name(code: str, *candidates) -> str:
    for c in candidates:
        name = str(c or "").strip()
        if name and not _looks_numeric_material_name(name):
            return name
    code = str(code or "").strip()
    if code:
        lib = _load_material_name_by_code()
        if code in lib:
            return lib[code]
    for c in candidates:
        name = str(c or "").strip()
        if name:
            return name
    return ""


def _material_label_for_filename(material_code: str, thickness_mm) -> str:
    """Build a human-readable material label for exported filenames.
    Prefer the real material/decor name from loaded material metadata; fall back to code.
    Thickness is intentionally omitted from the visible filename label for cleaner DXF names.
    """
    code = str(material_code or '').strip()
    name = _best_material_name(code, '') if code else ''
    return str(name or code or '').strip()

def _ntfy_send(
    title: Optional[str] = None,
    message: str = "",
    click_url: Optional[str] = None,
    priority: Optional[int] = None,
    tags: Optional[list[str]] = None,
) -> tuple[bool, str]:
    """Send ntfy notification. Never raises. Returns (ok, error)."""
    cfg = _load_notify_config()
    nt = cfg.get("ntfy") if isinstance(cfg, dict) else None
    if not isinstance(nt, dict):
        return (False, "ntfy config missing")
    if nt.get("enabled") is False:
        return (False, "ntfy disabled")
    topic_url = str(nt.get("topic_url") or "").strip()
    if not topic_url:
        return (False, "ntfy topic_url empty")

    hdr_title = str(nt.get("title") or title or "").strip() or "Notification"
    auth = str(nt.get("authorization") or nt.get("auth") or nt.get("token") or "").strip()
    insecure = False

    body = (message or "").encode("utf-8")
    headers = {
        "Title": hdr_title,
        "Content-Type": "text/plain; charset=utf-8",
        "User-Agent": "METOD-PAX-LocalServer/1.0",
    }
    if click_url:
        headers["Click"] = str(click_url)
    if priority is not None:
        headers["Priority"] = str(int(priority))
    if tags:
        headers["Tags"] = ",".join([str(t) for t in tags if t])
    if auth:
        # Allow both raw token and full 'Bearer ...'
        if auth.lower().startswith("bearer "):
            headers["Authorization"] = auth
        else:
            headers["Authorization"] = "Bearer " + auth

    req = Request(topic_url, data=body, headers=headers, method="POST")
    try:
        ctx = None
        if insecure:
            ctx = ssl._create_unverified_context()
        with urlopen(req, timeout=8, context=ctx) as resp:
            resp.read(1)
        _ntfy_log(f"OK POST {topic_url} title={hdr_title!r} insecure={insecure}")
        return (True, "")
    except ssl.SSLCertVerificationError as e:
        _ntfy_log(f"FAIL POST {topic_url} ssl_verify_failed insecure={insecure}: {e}")
        return (False, f"ssl_verify_failed: {e}")
    except Exception as e:
        _ntfy_log(f"FAIL POST {topic_url} err={e}")
        return (False, str(e))


def _format_money_eur(x) -> str:
    try:
        v = float(x)
        if not (v == v):
            return ""
        s = f"{v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
        return f"€{s}"
    except Exception:
        return ""

def _extract_request_summary(payload: dict) -> dict:
    """Best-effort summary for notifications: customer, panels/plates, materials, price."""
    out = {
        "customerName": "",
        "customerEmail": "",
        "customerPhone": "",
        "customerAddress": "",
        "panelsTotal": None,
        "platesTotal": None,
        "materials": [],  # list of {code, name, plates}
        "priceInclVat": None,
        "materialsPrice": None,
    }
    try:
        cust = payload.get("customer") if isinstance(payload.get("customer"), dict) else {}
        if isinstance(cust, dict):
            first = str(cust.get("firstName") or "").strip()
            last = str(cust.get("lastName") or "").strip()
            full = " ".join([x for x in [first, last] if x]).strip()
            out["customerName"] = str(cust.get("name") or cust.get("fullName") or full or "").strip()
            out["customerEmail"] = str(cust.get("email") or cust.get("mail") or "").strip()
            out["customerPhone"] = str(cust.get("phone") or cust.get("tel") or cust.get("telephone") or "").strip()
            postcode = str(cust.get("postcode") or "").strip()
            house = str(cust.get("houseNumber") or "").strip()
            city = str(cust.get("city") or "").strip()
            addr_line = " ".join([x for x in [postcode, house] if x]).strip()
            bill = str(cust.get("billingAddress") or cust.get("invoiceAddress") or cust.get("address") or "").strip()
            ship = str(cust.get("shippingAddress") or cust.get("deliveryAddress") or cust.get("address1") or bill or "").strip()
            addr_parts = []
            if bill:
                addr_parts.append(("Factuur: " + " ".join([x for x in [bill, addr_line] if x]).strip()).strip())
            if ship and ship != bill:
                addr_parts.append(("Bezorg: " + " ".join([x for x in [ship, addr_line] if x]).strip()).strip())
            if city:
                addr_parts.append(city)
            out["customerAddress"] = " | ".join([x for x in addr_parts if x]).strip()
    except Exception:
        pass

    # Price incl VAT: prefer explicit field
    for k in ["priceInclVat", "totalPriceInclVat", "totalInclVat"]:
        try:
            if payload.get(k) is not None:
                out["priceInclVat"] = float(payload.get(k))
                break
        except Exception:
            pass

    quote = payload.get("quote") if isinstance(payload.get("quote"), dict) else None
    if out["priceInclVat"] is None and isinstance(quote, dict):
        for k in ["grandTotalInclVat", "totalInclVat", "inclVatTotal", "totalPriceInclVat"]:
            if quote.get(k) is not None:
                try:
                    out["priceInclVat"] = float(quote.get(k))
                    break
                except Exception:
                    pass
        if out["priceInclVat"] is None:
            try:
                t = quote.get("totals") if isinstance(quote.get("totals"), dict) else {}
                for k in ["grandTotalInclVat", "totalInclVat", "inclVatTotal", "totalPriceInclVat"]:
                    if t.get(k) is not None:
                        out["priceInclVat"] = float(t.get(k))
                        break
            except Exception:
                pass
        if out["priceInclVat"] is None:
            try:
                t = quote.get("totals") if isinstance(quote.get("totals"), dict) else {}
                base = None
                for k in ["grandTotal", "total", "subtotal"]:
                    if t.get(k) is not None:
                        base = float(t.get(k))
                        break
                if base is None:
                    for k in ["grandTotal", "total", "subtotal"]:
                        if quote.get(k) is not None:
                            base = float(quote.get(k))
                            break
                if base is not None:
                    out["priceInclVat"] = round(base * 1.21, 2)
            except Exception:
                pass

    # Materials: prefer explicit summary if ToolA provided it
    mats = payload.get("materialsSummary")
    if isinstance(mats, list):
        for m in mats:
            if not isinstance(m, dict):
                continue
            code = str(m.get("code") or m.get("articleNumber") or m.get("materialCode") or "").strip()
            name = _best_material_name(code, m.get("materialDisplayName"), m.get("materialName"), m.get("name"), m.get("productName"), m.get("decorName"))
            plates = m.get("plates")
            try:
                plates = int(plates) if plates is not None else None
            except Exception:
                plates = None
            if code or name:
                out["materials"].append({"code": code, "name": name, "plates": plates})
    else:
        # derive from cart + extraPanels
        codes = {}
        def _add(code, name=""):
            if not code and not name:
                return
            key = code or name
            if key not in codes:
                codes[key] = {"code": code, "name": name, "plates": None}
        for arr_key in ["cart", "extraPanels", "panels"]:
            arr = payload.get(arr_key)
            if not isinstance(arr, list):
                continue
            for p in arr:
                if not isinstance(p, dict):
                    continue
                code = str(p.get("articleNumber") or p.get("materialKey") or p.get("materialCode") or "").strip()
                name = _best_material_name(code, p.get("materialDisplayName"), p.get("productName"), p.get("decorName"), p.get("name"))
                _add(code, name)
        out["materials"] = list(codes.values())

    # Plates: from explicit fields, else from quote heuristics
    try:
        if payload.get("platesTotal") is not None:
            out["platesTotal"] = int(payload.get("platesTotal"))
    except Exception:
        pass
    if out["platesTotal"] is None and isinstance(quote, dict):
        # heuristics
        candidates = []
        def walk(o):
            if isinstance(o, dict):
                for k,v in o.items():
                    lk=str(k).lower()
                    if lk in ("plates", "platencount", "sheetcount", "sheetsused", "boardsused", "boardscount"):
                        if isinstance(v, (int,float)) and v>=0:
                            candidates.append(int(v))
                    walk(v)
            elif isinstance(o, list):
                for v in o: walk(v)
        walk(quote)
        if candidates:
            out["platesTotal"] = max(candidates)  # best-effort (often totals)
    # Also map per-material plates if possible
    if isinstance(quote, dict):
        mats2 = []
        try:
            qm = quote.get("materials") if isinstance(quote.get("materials"), list) else None
            if qm:
                for m in qm:
                    if not isinstance(m, dict):
                        continue
                    code = str(m.get("materialCode") or m.get("code") or m.get("articleNumber") or "").strip()
                    name = _best_material_name(code, m.get("materialDisplayName"), m.get("materialName"), m.get("name"), m.get("productName"), m.get("decorName"))
                    plates = None
                    for kk in ["plates", "sheets", "sheetsUsed", "boards", "boardsUsed", "sheetCount"]:
                        if m.get(kk) is not None:
                            try:
                                plates = int(m.get(kk))
                                break
                            except Exception:
                                pass
                    mats2.append({"code": code, "name": name, "plates": plates})
        except Exception:
            pass
        if mats2:
            # merge into existing list by code
            by = { (x.get("code") or x.get("name")): x for x in out["materials"] }
            for m in mats2:
                key = m.get("code") or m.get("name")
                if not key:
                    continue
                if key in by and m.get("plates") is not None:
                    by[key]["plates"] = m.get("plates")
                elif key not in by:
                    out["materials"].append(m)

    # Materials total if present in payload/quote
    for k in ["materialsPrice", "materialsTotal", "materialTotal", "materialsAmount"]:
        try:
            if payload.get(k) is not None:
                out["materialsPrice"] = float(payload.get(k))
                break
        except Exception:
            pass
    if out["materialsPrice"] is None and isinstance(quote, dict):
        try:
            mats_total = None
            for k in ["materialsTotal", "materialTotal", "subtotalMaterials", "materialsSubtotal"]:
                if quote.get(k) is not None:
                    mats_total = quote.get(k)
                    break
            if mats_total is None:
                totals = quote.get("totals") if isinstance(quote.get("totals"), dict) else {}
                for k in ["materialsTotal", "materialTotal", "subtotalMaterials", "materialsSubtotal"]:
                    if totals.get(k) is not None:
                        mats_total = totals.get(k)
                        break
            if mats_total is None and isinstance(quote.get("materials"), list):
                vals = []
                for m in quote.get("materials") or []:
                    if not isinstance(m, dict):
                        continue
                    for k in ["priceInclVat", "totalInclVat", "grandTotal", "total", "subtotal", "price"]:
                        if m.get(k) is not None:
                            try:
                                vals.append(float(m.get(k)))
                                break
                            except Exception:
                                pass
                if vals:
                    mats_total = sum(vals)
            if mats_total is not None:
                out["materialsPrice"] = float(mats_total)
        except Exception:
            pass

    # Panels total from payload cart/extraPanels/panels (sum qty, fallback item count)
    try:
        panels_total = 0
        found_any = False
        for arr_key in ["cart", "extraPanels", "panels"]:
            arr = payload.get(arr_key)
            if not isinstance(arr, list):
                continue
            for p in arr:
                if not isinstance(p, dict):
                    continue
                found_any = True
                qty = None
                for k in ["qty", "quantity", "count", "aantal"]:
                    if p.get(k) is not None:
                        try:
                            qty = int(float(p.get(k)))
                            break
                        except Exception:
                            pass
                panels_total += qty if (qty is not None and qty > 0) else 1
        if found_any and panels_total > 0:
            out["panelsTotal"] = panels_total
    except Exception:
        pass

    return out

def _calculation_summary_text_for_ntfy(job_ids: list[str] | None) -> tuple[str, str]:
    """Return the first final calculation_summary.txt for the submitted order.

    ntfy must match the real backend/admin calculation, not the earlier frontend
    payload. Prefer the same human-readable calculation summary that Admin exposes.
    """
    for jid in (job_ids or []):
        jid = _safe_id(str(jid or '').strip(), 200)
        if not jid:
            continue
        for rel in ('output/calculation_summary.txt', 'input/calculation_summary.txt', 'calculation_summary.txt'):
            try:
                fp = JOBS / jid / rel
                if fp.exists() and fp.is_file():
                    txt = fp.read_text(encoding='utf-8', errors='ignore')
                    if txt.strip():
                        return txt, jid
            except Exception:
                pass
    return '', ''


def _parse_calculation_summary_for_ntfy(text: str) -> dict:
    """Small, safe parser for notification-only fields from calculation_summary.txt."""
    out = {
        'panelsTotal': None,
        'platesTotal': None,
        'materials': [],
        'edgeMeters': [],
        'pricing': {},
    }
    s = str(text or '')
    if not s.strip():
        return out

    def _eur_to_float(raw):
        try:
            return round(float(str(raw).replace('.', '').replace(',', '.')), 2)
        except Exception:
            return None

    def _m_to_float(raw):
        try:
            return round(float(str(raw).replace('.', '').replace(',', '.')), 2)
        except Exception:
            return None

    try:
        m = re.search(r'Aantal panelen:\s*([0-9]+)', s, re.I)
        if m:
            out['panelsTotal'] = int(m.group(1))
        m = re.search(r'Aantal platen:\s*([0-9]+)', s, re.I)
        if m:
            out['platesTotal'] = int(m.group(1))
    except Exception:
        pass

    pats = {
        'materialsTotal': r'Plaatmateriaal:\s*€\s*([0-9\.,]+)',
        'edgeBandTotal': r'Kantenband:\s*€\s*([0-9\.,]+)',
        'cncTotal': r'CNC:\s*€\s*([0-9\.,]+)',
        'drawingTotal': r'Tekenen:\s*€\s*([0-9\.,]+)',
        'transportTotal': r'Transport:\s*€\s*([0-9\.,]+)',
        'subtotalExVat': r'Subtotaal excl\. btw:\s*€\s*([0-9\.,]+)',
        'vatAmount': r'BTW\s*\(21%\):\s*€\s*([0-9\.,]+)',
        'totalInclVat': r'Totaal incl\. btw:\s*€\s*([0-9\.,]+)',
    }
    for key, pat in pats.items():
        try:
            m = re.search(pat, s, re.I)
            if m:
                out['pricing'][key] = _eur_to_float(m.group(1))
        except Exception:
            pass

    # Material block: keep the visible material line + next details line.
    try:
        mat_block = ''
        m = re.search(r'Materialen / platen\s*-+\s*(.*?)(?:\nKantenband \(m¹\) per decor|\nKostenopbouw \(excl\. btw\)|\Z)', s, re.I | re.S)
        if m:
            mat_block = m.group(1)
        cur = None
        for raw in mat_block.splitlines():
            line = raw.strip()
            if not line or line.startswith('Opslagfactor') or line.startswith('Plaatprijs') or line.startswith('Subtotaal'):
                continue
            if line.startswith('- '):
                if cur:
                    out['materials'].append(cur)
                cur = {'label': line[2:].strip(), 'detail': ''}
            elif cur and ('Platen:' in line or 'Dikte:' in line or 'Plaatmaat:' in line):
                cur['detail'] = line.strip()
        if cur:
            out['materials'].append(cur)
    except Exception:
        pass

    try:
        edge_block = ''
        m = re.search(r'Kantenband \(m¹\) per decor\s*-+\s*(.*?)(?:\nKostenopbouw \(excl\. btw\)|\Z)', s, re.I | re.S)
        if m:
            edge_block = m.group(1)
        for raw in edge_block.splitlines():
            line = raw.strip()
            if not line.startswith('- '):
                continue
            mm = re.search(r'^-\s*(.+?):\s*([0-9\.,]+)\s*m', line, re.I)
            if mm:
                out['edgeMeters'].append({'label': mm.group(1).strip(), 'meters': _m_to_float(mm.group(2))})
    except Exception:
        pass
    return out


def _merge_ntfy_pricing(summary: dict, calculation_info: dict, authoritative_pricing: dict | None) -> dict:
    pricing = {}
    try:
        if isinstance(summary, dict):
            if summary.get('materialsPrice') is not None:
                pricing['materialsTotal'] = float(summary.get('materialsPrice'))
            if summary.get('priceInclVat') is not None:
                pricing['totalInclVat'] = float(summary.get('priceInclVat'))
    except Exception:
        pass
    try:
        if isinstance(authoritative_pricing, dict):
            for k in ('materialsTotal','edgeBandTotal','cncTotal','drawingTotal','transportTotal','subtotalExVat','vatAmount','totalInclVat'):
                if authoritative_pricing.get(k) is not None:
                    pricing[k] = authoritative_pricing.get(k)
    except Exception:
        pass
    try:
        calc_pr = (calculation_info or {}).get('pricing') if isinstance(calculation_info, dict) else {}
        if isinstance(calc_pr, dict):
            for k, v in calc_pr.items():
                if v is not None:
                    pricing[k] = v
    except Exception:
        pass
    return pricing


def _notify_privacy_options() -> dict:
    cfg = _load_notify_config()
    nt = cfg.get('ntfy') if isinstance(cfg, dict) else {}
    if not isinstance(nt, dict):
        nt = {}
    return {
        'include_customer_details': bool(nt.get('include_customer_details') is True),
        'include_price_breakdown': bool(nt.get('include_price_breakdown', True) is not False),
        'minimal_order_notice': bool(nt.get('minimal_order_notice', True) is not False),
    }

def _ntfy_public_safe_customer_lines(status: dict | None, payload: dict) -> list[str]:
    # Privacy-first default: never push name, email, phone or address unless explicitly enabled.
    opts = _notify_privacy_options()
    if not opts.get('include_customer_details'):
        return []
    cust_lines = _customer_block_from_sources(status if isinstance(status, dict) else None, payload if isinstance(payload, dict) else {})
    compact = []
    keep = False
    for line in cust_lines:
        line = str(line or '').strip()
        if line in ('Klant', 'Adres', 'Restmateriaal', 'Opmerking klant'):
            keep = line
            continue
        if not line or set(line) == {'-'} or line.startswith('Aanvraag') or line.startswith('Request ID') or line.startswith('Datum'):
            continue
        if keep == 'Klant' and (line.startswith('Naam:') or line.startswith('Email:') or line.startswith('Telefoon:')):
            compact.append(line)
        elif keep == 'Adres' and (line.startswith('Factuur:') or line.startswith('Bezorg:') or line.startswith('Plaats:') or line.startswith('Land:')):
            compact.append(line)
        elif keep == 'Restmateriaal' and line.startswith('Meeleveren:'):
            compact.append('Restmateriaal ' + line)
        elif keep == 'Opmerking klant' and line:
            compact.append('Opmerking: ' + line[:220])
    return compact[:10]

def _notify_submitted(request_id: str, payload: dict, status: dict | None = None, job_ids: list[str] | None = None, authoritative_pricing: dict | None = None) -> tuple[bool, str]:
    summ = _extract_request_summary(payload or {})
    calc_text, calc_job_id = _calculation_summary_text_for_ntfy(job_ids or [])
    calc_info = _parse_calculation_summary_for_ntfy(calc_text)
    pricing = _merge_ntfy_pricing(summ, calc_info, authoritative_pricing)
    notify_opts = _notify_privacy_options()

    parts = []
    parts.append("Nieuwe order ontvangen")

    total = pricing.get('totalInclVat')
    if total is not None:
        parts.append("Totaal: " + _format_money_eur(total))

    parts.append("Request: " + str(request_id))
    parts.append("Open admin voor details.")

    # VPS/live default: ntfy is only a lightweight signal. It must not receive
    # customer data, panel rows, material lines, address data, notes or job links.
    if notify_opts.get('minimal_order_notice', True):
        msg = "\n".join(parts)
        ok, err = _ntfy_send("AD Zaagt Configurator", msg, tags=["new"])
        if not ok:
            _ntfy_log(f"SUBMIT notify failed: {err}")
        return (ok, err)

    # Legacy verbose mode below is opt-in only through the private server-only
    # notify config. Keep it disabled for staging/live unless there is a strong
    # reason and an explicit privacy decision.
    parts = []
    parts.append("Nieuwe configuratie")

    # Customer/order info is privacy-first. By default, ntfy never receives customer PII
    # such as name, email, phone, address or free-text notes. Enable explicitly with
    # ntfy.include_customer_details=true in the private server-only config if required.
    try:
        compact = _ntfy_public_safe_customer_lines(status if isinstance(status, dict) else None, payload if isinstance(payload, dict) else {})
        if compact:
            parts.append("")
            parts.append("👤 Klant/order")
            parts.extend(compact[:10])
    except Exception:
        pass

    cfg_lines = []
    panel_count = calc_info.get('panelsTotal') if isinstance(calc_info, dict) else None
    if panel_count is None:
        panel_count = summ.get('panelsTotal')
    if panel_count is not None:
        cfg_lines.append(f"Panelen: {panel_count}")
    plate_count = calc_info.get('platesTotal') if isinstance(calc_info, dict) else None
    if plate_count is None:
        plate_count = summ.get('platesTotal')
    if plate_count is not None:
        cfg_lines.append(f"Platen: {plate_count}")

    calc_mats = (calc_info or {}).get('materials') if isinstance(calc_info, dict) else []
    if calc_mats:
        for m in calc_mats[:6]:
            label = str((m or {}).get('label') or '').strip()
            detail = str((m or {}).get('detail') or '').strip()
            if label:
                cfg_lines.append('• ' + label)
                if detail:
                    cfg_lines.append('  ' + detail)
    else:
        mats = summ.get("materials") or []
        for m in mats[:6]:
            name = str(m.get("name") or "").strip()
            code = str(m.get("code") or "").strip()
            if name and code and code.lower() not in name.lower():
                label = f"{name} ({code})"
            else:
                label = name or code
            if not label:
                continue
            if m.get("plates") is not None:
                cfg_lines.append(f"• {label} - {m['plates']} plaat/platen")
            else:
                cfg_lines.append(f"• {label}")
    if cfg_lines:
        parts.append("")
        parts.append("Configuratie")
        parts.extend(cfg_lines[:18])

    edge_lines = []
    for e in ((calc_info or {}).get('edgeMeters') if isinstance(calc_info, dict) else [])[:6]:
        label = str((e or {}).get('label') or '').strip()
        meters = (e or {}).get('meters')
        if label and meters is not None:
            edge_lines.append(f"• {label}: {_format_m(meters)}")
    if edge_lines:
        parts.append("")
        parts.append("Kantenband")
        parts.extend(edge_lines)

    price_lines = []
    labels = (
        ('materialsTotal', 'Plaatmateriaal'),
        ('edgeBandTotal', 'Kantenband'),
        ('cncTotal', 'CNC'),
        ('drawingTotal', 'Tekenen'),
        ('transportTotal', 'Transport'),
        ('subtotalExVat', 'Subtotaal excl. btw'),
        ('vatAmount', 'BTW'),
        ('totalInclVat', 'Totaal incl. btw'),
    )
    for key, label in labels:
        if pricing.get(key) is not None:
            price_lines.append(f"{label}: {_format_money_eur(pricing.get(key))}")
    if price_lines and notify_opts.get('include_price_breakdown'):
        parts.append("")
        parts.append("Berekening" + (" (exact uit calculation_summary)" if calc_text else ""))
        parts.extend(price_lines)
    elif pricing.get('totalInclVat') is not None:
        parts.append("")
        parts.append("Totaal incl. btw: " + _format_money_eur(pricing.get('totalInclVat')))

    parts.append("")
    parts.append("Request")
    parts.append(request_id)
    if calc_job_id:
        parts.append(f"Job: {calc_job_id}")

    msg = "\n".join(parts)
    ok, err = _ntfy_send("AD Zaagt Configurator", msg, tags=["new"])
    if not ok:
        _ntfy_log(f"SUBMIT notify failed: {err}")
    return (ok, err)

def _notify_failed(request_id: str, err: str) -> tuple[bool, str]:
    err1 = str(err or "").strip().splitlines()[0][:180]
    msg = "\n".join([
        "🔴 Optimizer fout",
        f"Request: {request_id}",
        err1 or "Onbekende fout",
        "Check Admin",
    ])
    # No auto-link to admin (user request)
    ok, err = _ntfy_send("AD Zaagt Configurator", msg, tags=["warning"])
    if not ok:
        _ntfy_log(f"FAIL notify failed: {err}")
    return (ok, err)

PORT = int(os.environ.get("METOD_PORT", "8787"))
JOB_OUTPUT_MAX_BYTES = int(os.environ.get("JOB_OUTPUT_MAX_BYTES", str(150 * 1024 * 1024)))


def _job_output_limit_message(size_bytes: int, limit_bytes: int) -> str:
    try:
        size_mb = float(size_bytes) / (1024.0 * 1024.0)
    except Exception:
        size_mb = 0.0
    try:
        limit_mb = float(limit_bytes) / (1024.0 * 1024.0)
    except Exception:
        limit_mb = 0.0
    return f"Job te groot tijdens verwerking ({size_mb:.1f} MB). Het maximum is {limit_mb:.0f} MB. Splits de job op in meerdere delen."


def _job_family_size_bytes(master_root: Path, subjob_roots: list[Path] | None = None) -> int:
    total = 0
    roots = [master_root]
    if isinstance(subjob_roots, list):
        roots.extend([r for r in subjob_roots if isinstance(r, Path)])
    for r in roots:
        try:
            total += _dir_size_bytes(r)
        except Exception:
            pass
    return int(total)


def _enforce_job_output_limit(master_root: Path, subjob_roots: list[Path] | None = None, limit_bytes: int | None = None) -> int:
    limit = int(limit_bytes or JOB_OUTPUT_MAX_BYTES)
    total = _job_family_size_bytes(master_root, subjob_roots)
    if total > limit:
        raise RuntimeError(_job_output_limit_message(total, limit))
    return total


def _estimate_preflight_job_family_bytes(payload: dict) -> dict:
    try:
        panels_csv = str((payload or {}).get('panelsCsv') or '')
    except Exception:
        panels_csv = ''
    try:
        pricing_obj = (payload or {}).get('pricing')
        pricing_bytes = len(json.dumps(pricing_obj if pricing_obj is not None else {}, ensure_ascii=False).encode('utf-8'))
    except Exception:
        pricing_bytes = 0
    try:
        job_json_obj = (payload or {}).get('jobJson')
        job_json_bytes = len(json.dumps(job_json_obj if job_json_obj is not None else {}, ensure_ascii=False).encode('utf-8'))
    except Exception:
        job_json_bytes = 0
    try:
        panels_csv_bytes = len(panels_csv.encode('utf-8'))
    except Exception:
        panels_csv_bytes = 0
    try:
        rows = _parse_panels_csv(panels_csv)
    except Exception:
        rows = []
    seen_codes: set[str] = set()
    for r in rows or []:
        try:
            code = str((r or {}).get('MaterialCode') or '').strip()
        except Exception:
            code = ''
        if code:
            seen_codes.add(code)
    material_count = max(1, len(seen_codes))
    try:
        dxf_parts = (payload or {}).get('dxfParts') or {}
    except Exception:
        dxf_parts = {}
    dxf_count = len(dxf_parts) if isinstance(dxf_parts, dict) else 0
    dxf_total_bytes = 0
    if isinstance(dxf_parts, dict):
        for _pid, dxf_text in dxf_parts.items():
            try:
                dxf_total_bytes += len(str(dxf_text).encode('utf-8'))
            except Exception:
                pass
    panel_rows = len(rows or [])
    total_qty = 0
    for r in rows or []:
        try:
            qty_raw = r.get('Qty') or r.get('qty') or r.get('quantity') or 1
            qty = int(float(qty_raw) or 0)
        except Exception:
            qty = 0
        if qty <= 0:
            qty = 1
        total_qty += qty
    total_qty = max(total_qty, panel_rows)
    # Lower-bound family input size before optimizer output: master input + all subjob inputs.
    # DXFs are copied to the master job and again to each material subjob, so this dominates
    # disk growth for extreme jobs. In practice, however, very large jobs scale mainly with the
    # effective number of produced panels (Qty totals), because each placed panel fans out into
    # more placement/report/export/zip output even when the DXF templates themselves are reused.
    # We therefore keep the DXF/input estimate but also add a conservative per-panel output floor
    # so absurd jobs (for example hundreds of repeated small parts) are stopped early.
    shared_json_bytes = pricing_bytes + job_json_bytes
    estimated_subjob_csv_total = int(panels_csv_bytes * 1.10)
    family_input_lower_bound = (dxf_total_bytes * (1 + material_count)) + (shared_json_bytes * (1 + material_count)) + panels_csv_bytes + estimated_subjob_csv_total
    per_panel_output_floor = total_qty * 262144  # 256 KB per effective panel as conservative early-stop floor
    projected_total_bytes = int(max((family_input_lower_bound * 1.22) + (dxf_count * 2048) + (panel_rows * 256), family_input_lower_bound + per_panel_output_floor + (material_count * 131072)))
    return {
        'panelRows': int(panel_rows),
        'totalQty': int(total_qty),
        'dxfCount': int(dxf_count),
        'materialCount': int(material_count),
        'panelsCsvBytes': int(panels_csv_bytes),
        'pricingBytes': int(pricing_bytes),
        'jobJsonBytes': int(job_json_bytes),
        'dxfTotalBytes': int(dxf_total_bytes),
        'familyInputLowerBoundBytes': int(family_input_lower_bound),
        'perPanelOutputFloorBytes': int(per_panel_output_floor),
        'projectedTotalBytes': int(projected_total_bytes),
    }


def _preflight_job_family_limit_message(projected_bytes: int, limit_bytes: int) -> str:
    try:
        projected_mb = float(projected_bytes) / (1024.0 * 1024.0)
    except Exception:
        projected_mb = 0.0
    try:
        limit_mb = float(limit_bytes) / (1024.0 * 1024.0)
    except Exception:
        limit_mb = 0.0
    return f"Deze job is te groot om veilig te verwerken. De geschatte jobgrootte is ongeveer {projected_mb:.1f} MB en dat overschrijdt het maximum van {limit_mb:.0f} MB. Splits de job op in meerdere delen."


def _get_payload_total_qty(payload: dict) -> int:
    try:
        panels_csv = str((payload or {}).get('panelsCsv') or '')
    except Exception:
        panels_csv = ''
    try:
        rows = _parse_panels_csv(panels_csv)
    except Exception:
        rows = []
    total_qty = 0
    for r in rows or []:
        try:
            qty_raw = r.get('Qty') or r.get('qty') or r.get('quantity') or 1
            qty = int(float(qty_raw) or 0)
        except Exception:
            qty = 0
        if qty <= 0:
            qty = 1
        total_qty += qty
    return int(max(total_qty, len(rows or [])))


def _enforce_job_total_qty_limit(payload: dict, limit_qty: int = 250) -> int:
    total_qty = _get_payload_total_qty(payload)
    if total_qty > int(limit_qty):
        raise RuntimeError('JOB_TOTAL_QTY_TOO_LARGE::%d::%d' % (total_qty, int(limit_qty)))
    return int(total_qty)


def _estimate_payload_area_lower_bound(payload: dict) -> dict:
    try:
        panels_csv = str((payload or {}).get('panelsCsv') or '')
    except Exception:
        panels_csv = ''
    try:
        pricing = (payload or {}).get('pricing') or {}
    except Exception:
        pricing = {}
    try:
        defaults = pricing.get('defaults') or {}
    except Exception:
        defaults = {}
    try:
        margin = float(defaults.get('sheetMarginMm') or 7.0)
    except Exception:
        margin = 7.0
    try:
        rows = _parse_panels_csv(panels_csv)
    except Exception:
        rows = []
    try:
        materials = pricing.get('materials') or []
    except Exception:
        materials = []
    mat_map = {}
    for m in materials if isinstance(materials, list) else []:
        try:
            code = str((m or {}).get('materialCode') or (m or {}).get('articleNumber') or '').strip()
            if code:
                mat_map[code] = m or {}
        except Exception:
            continue
    area_by_code = {}
    for r in rows or []:
        try:
            code = str(r.get('MaterialCode') or r.get('materialCode') or '').strip()
        except Exception:
            code = ''
        if not code:
            continue
        try:
            qty = int(float(r.get('Qty') or r.get('qty') or 1) or 1)
        except Exception:
            qty = 1
        if qty <= 0:
            qty = 1
        try:
            w = float(r.get('WidthMm') or r.get('widthMm') or 0.0)
            h = float(r.get('LengthMm') or r.get('lengthMm') or 0.0)
        except Exception:
            w = 0.0
            h = 0.0
        if w <= 0.0 or h <= 0.0:
            continue
        area_by_code[code] = area_by_code.get(code, 0.0) + (w * h * qty)
    by_material = []
    max_lb = 0
    for code, total_area in area_by_code.items():
        m = mat_map.get(code) or {}
        try:
            sheet = m.get('sheetSizeMm') or {}
            sheet_w = float(sheet.get('width') or m.get('sheetWid') or m.get('sheetW') or 0.0)
            sheet_h = float(sheet.get('height') or m.get('sheetLen') or m.get('sheetH') or 0.0)
        except Exception:
            sheet_w = 0.0
            sheet_h = 0.0
        usable_w = max(0.0, sheet_w - 2.0 * margin)
        usable_h = max(0.0, sheet_h - 2.0 * margin)
        usable_area = usable_w * usable_h
        area_lb = max(1, int(math.ceil((total_area / usable_area) - 1e-12))) if usable_area > 0.0 else 0
        by_material.append({'materialCode': code, 'areaLowerBound': int(area_lb), 'totalAreaMm2': float(total_area), 'usableAreaMm2': float(usable_area)})
        max_lb = max(max_lb, int(area_lb))
    return {'maxAreaLowerBound': int(max_lb), 'byMaterial': by_material}


DXF_CATEGORIES = [
    "Deuren METOD",
    "Ladefront METOD",
    "Deuren PAX",
    "Overige panelen",
]

def classify_dxf_category(filename: str) -> str:
    lower = str(filename or "").lower().strip()
    # Mirror Tool A parseMetaFromFilename() type logic
    if lower.startswith("pax"):
        return "Deuren PAX"
    if "lade" in lower and "apothekerslade" not in lower:
        return "Ladefront METOD"
    if "deur" in lower:
        return "Deuren METOD"
    return "Overige panelen"

def migrate_embedded_dxfs_to_categories():
    """One-time migration: move root-level DXFs in app/embedded_dxfs into category subfolders.
    This keeps Tool A behavior (manifest relative paths) and makes Admin categories match Tool A labels."""
    dxf_root = ROOT / "embedded_dxfs"
    dxf_root.mkdir(parents=True, exist_ok=True)

    # Ensure default categories exist
    for cat in DXF_CATEGORIES:
        (dxf_root / cat).mkdir(parents=True, exist_ok=True)

    # Move any DXF files in the root of embedded_dxfs into a category folder
    for p in sorted(dxf_root.iterdir()):
        if not p.is_file():
            continue
        if not p.name.lower().endswith(".dxf"):
            continue
        # Skip temp
        if p.name.lower().endswith(".tmp"):
            continue
        target_dir = dxf_root / classify_dxf_category(p.name)
        target = target_dir / p.name
        # If target exists, keep existing and avoid overwrite by renaming
        if target.exists():
            stem = target.stem
            suffix = target.suffix
            i = 2
            while True:
                cand = target_dir / f"{stem} ({i}){suffix}"
                if not cand.exists():
                    target = cand
                    break
                i += 1
        try:
            os.replace(p, target)
        except Exception:
            # Best effort; if move fails, keep file in root
            pass

def get_embedded_dxfs_version():
    """Return a monotonic-ish version for embedded_dxfs tree (ms since epoch based on latest mtime).
    Used by Tool A to auto-refresh without server restart."""
    dxf_root = ROOT / "embedded_dxfs"
    latest = 0.0
    try:
        if dxf_root.exists():
            for p in dxf_root.rglob("*"):
                try:
                    st = p.stat()
                    if st.st_mtime > latest:
                        latest = st.st_mtime
                except Exception:
                    continue
    except Exception:
        pass
    try:
        man = ROOT / "embedded_dxfs_manifest.json"
        if man.exists():
            mt = man.stat().st_mtime
            if mt > latest:
                latest = mt
    except Exception:
        pass
    return int(latest * 1000)


def rebuild_embedded_dxfs_manifest():
    """Rebuild app/embedded_dxfs_manifest.json from files inside app/embedded_dxfs.
    Includes files in root and subfolders (relative paths)."""
    dxf_root = ROOT / "embedded_dxfs"
    dxf_root.mkdir(parents=True, exist_ok=True)

    files = []
    for p in sorted(dxf_root.rglob("*")):
        if not p.is_file():
            continue
        name = p.name.lower()
        if name.endswith(".tmp"):
            continue
        if p.name == "embedded_dxfs_manifest.json":
            continue
        if not name.endswith(".dxf"):
            continue
        rel = p.relative_to(dxf_root).as_posix()
        files.append(rel)

    manifest = {"files": files, "count": len(files)}
    target = ROOT / "embedded_dxfs_manifest.json"
    tmp = ROOT / "embedded_dxfs_manifest.json.tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, target)


CONFIG_DIR = ROOT / "config"
PRICING_ACTIVE = CONFIG_DIR / "pricing_active.json"
PRICING_VERSIONS = CONFIG_DIR / "pricing_versions"
PRICING_AUDIT = CONFIG_DIR / "pricing_audit.jsonl"

# --- Pricing rules (sell prices) ---
# Sheet material sell factor (e.g. 1.4 means +40% on purchase price).
SHEET_PRICE_FACTOR = float(os.environ.get("METOD_SHEET_PRICE_FACTOR", "1.4"))
# Edge banding sell price per meter.
EDGE_BAND_PRICE_PER_M = float(os.environ.get("METOD_EDGE_BAND_PRICE_PER_M", "4.5"))
# CNC routing cost per used sheet.
CNC_COST_PER_SHEET = float(os.environ.get("METOD_CNC_COST_PER_SHEET", "85"))
# One-time drawing / setup cost per job.
DRAWING_COST_FIXED = float(os.environ.get("METOD_DRAWING_COST_FIXED", "125"))
# One-time transport cost per job.
TRANSPORT_COST_FIXED = float(os.environ.get("METOD_TRANSPORT_COST_FIXED", "54.95"))


HOST = "127.0.0.1"
PUBLIC_HOST = os.environ.get("METOD_PUBLIC_HOST", "werkplaats")
PUBLIC_BASE_URL = os.environ.get("METOD_PUBLIC_BASE_URL", f"http://{PUBLIC_HOST}:{PORT}")

JOBS.mkdir(parents=True, exist_ok=True)
DRAFTS.mkdir(parents=True, exist_ok=True)

# in-memory job status
_job_lock = threading.Lock()
_job_meta: dict[str, dict] = {}


def _find_existing_file(base_dir: Path, candidates):
    """Return first existing path among candidates (relative to base_dir)."""
    for rel in candidates:
        p = base_dir / rel
        if p.exists():
            return p
    return None

def _find_placements_any(output_dir: Path):
    # common variants (windows may hide extension; toolb may output without)
    candidates = [Path('placements.json'), Path('placements'), Path('Placements.json'), Path('Placements')]
    p = _find_existing_file(output_dir, candidates)
    if p:
        return p
    for f in output_dir.iterdir():
        if f.is_file() and f.name.lower().startswith('placements'):
            return f
    return None

def _find_labels_any(output_dir: Path):
    candidates = [Path('labels.json'), Path('labels'), Path('Labels.json'), Path('Labels')]
    p = _find_existing_file(output_dir, candidates)
    if p:
        return p
    for f in output_dir.iterdir():
        if f.is_file() and f.name.lower().startswith('labels'):
            return f
    return None

def _now_iso() -> str:
    return time.strftime('%Y-%m-%dT%H:%M:%S', time.localtime())


def _safe_json(data, code=200):
    body = json.dumps(data).encode('utf-8')
    return body, code


def _read_json_body(handler: SimpleHTTPRequestHandler, max_bytes: Optional[int] = None) -> dict:
    return _helpers_read_json_body(handler, max_bytes=max_bytes)


def _read_json_body_limited(handler: SimpleHTTPRequestHandler, env_name: str, default_bytes: int) -> dict:
    return _helpers_read_json_body_limited(handler, env_name, default_bytes)


def _safe_job_file(job_root: Path, rel: str) -> Optional[Path]:
    return _helpers_safe_job_file(job_root, rel)


def _write_file(path: Path, text: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding='utf-8')


def _write_bytes(path: Path, b: bytes):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(b)

# --- Atomic file utilities (avoid 0-byte / race conditions) ---
def _atomic_write_text(path: Path, text: str) -> None:
    _helpers_atomic_write_text(path, text)


def _atomic_write_json(path: Path, obj: dict) -> None:
    _helpers_atomic_write_json(path, obj)


def _utc_now_iso() -> str:
    return datetime.utcnow().isoformat() + "Z"


def _safe_id(s: str, max_len: int = 80) -> str:
    s = re.sub(r"[^A-Za-z0-9_\-\.]", "_", str(s or ""))
    return s[:max_len] if len(s) > max_len else s


def _ensure_request_dirs() -> None:
    for d in [REQUESTS, QUEUE_DIR, QUEUE_PENDING, QUEUE_PROCESSING, QUEUE_DONE, QUEUE_FAILED, INDEX_DIR, SYSTEM_DIR, BACKUPS_DIR]:
        d.mkdir(parents=True, exist_ok=True)


def _ensure_archive_dirs() -> None:
    for d in [ARCHIVE_ROOT, ARCHIVE_JOBS, ARCHIVE_REQUESTS, ARCHIVE_QUEUE_DONE, ARCHIVE_QUEUE_FAILED]:
        d.mkdir(parents=True, exist_ok=True)


def _parse_iso_dt(value) -> Optional[datetime]:
    try:
        s = str(value or '').strip()
        if not s:
            return None
        if s.endswith('Z'):
            s = s[:-1] + '+00:00'
        dt = datetime.fromisoformat(s)
        if dt.tzinfo is not None:
            dt = dt.astimezone(timezone.utc).replace(tzinfo=None)
        return dt
    except Exception:
        return None


def _path_dt(path: Path) -> Optional[datetime]:
    try:
        return datetime.utcfromtimestamp(path.stat().st_mtime)
    except Exception:
        return None


def _request_status_path(request_id: str) -> Path:
    rid = _safe_id(str(request_id or '').strip(), 120)
    return REQUESTS / rid / 'status.json'


def _request_created_dt_from_status(st: dict | None, request_root: Path | None = None) -> Optional[datetime]:
    if isinstance(st, dict):
        for k in ('createdAt', 'submittedAt', 'updatedAt'):
            dt = _parse_iso_dt(st.get(k))
            if dt is not None:
                return dt
    if request_root is not None:
        sp = Path(request_root) / 'status.json'
        if sp.exists():
            dt = _path_dt(sp)
            if dt is not None:
                return dt
        dt = _path_dt(Path(request_root))
        if dt is not None:
            return dt
    return None


def _request_archive_meta_dt(req_dir: Path) -> Optional[datetime]:
    meta_path = Path(req_dir) / ARCHIVE_META_NAME
    if meta_path.exists():
        try:
            meta = json.loads(meta_path.read_text(encoding='utf-8') or '{}')
            dt = _parse_iso_dt(meta.get('archivedAt'))
            if dt is not None:
                return dt
        except Exception:
            pass
    return _path_dt(req_dir)


def _job_created_dt(job_dir: Path) -> Optional[datetime]:
    try:
        meta = _job_meta.get(job_dir.name, {}) if isinstance(_job_meta, dict) else {}
        if isinstance(meta, dict):
            for k in ('createdAt', 'startedAt', 'updatedAt'):
                dt = _parse_iso_dt(meta.get(k))
                if dt is not None:
                    return dt
    except Exception:
        pass
    status_candidates = [job_dir / 'output' / 'meta_status.json', job_dir / 'output' / 'links.json', job_dir / 'input' / 'job.json']
    for fp in status_candidates:
        if fp.exists():
            dt = _path_dt(fp)
            if dt is not None:
                return dt
    return _path_dt(job_dir)


def _write_archive_meta(dest_dir: Path, *, kind: str, item_id: str, archived_at: datetime, active_created_at: Optional[datetime] = None) -> None:
    try:
        payload = {
            'kind': kind,
            'id': item_id,
            'archivedAt': archived_at.isoformat() + 'Z',
        }
        if active_created_at is not None:
            payload['activeCreatedAt'] = active_created_at.isoformat() + 'Z'
        _atomic_write_json(dest_dir / ARCHIVE_META_NAME, payload)
    except Exception:
        pass


def _unique_archive_dest(base_dir: Path, name: str) -> Path:
    dest = base_dir / name
    if not dest.exists():
        return dest
    stamp = time.strftime('%Y%m%d_%H%M%S')
    return base_dir / f"{name}__archived_{stamp}"


def _linked_job_ids_from_status(st: dict | None) -> list[str]:
    out = []
    if not isinstance(st, dict):
        return out
    job = st.get('job') if isinstance(st.get('job'), dict) else {}
    parent = _safe_id(str(job.get('parentJobId') or '').strip(), 200)
    if parent:
        out.append(parent)
    for sj in (job.get('subjobs') or []):
        sj_id = ''
        if isinstance(sj, dict):
            sj_id = str(sj.get('subjobId') or sj.get('jobId') or sj.get('id') or '').strip()
        else:
            sj_id = str(sj or '').strip()
        sj_id = _safe_id(sj_id, 200) if sj_id else ''
        if sj_id and sj_id not in out:
            out.append(sj_id)
    return out


def _archive_request_and_linked_jobs(request_id: str) -> dict:
    rid = _safe_id(str(request_id or '').strip(), 120)
    if not rid:
        return {'ok': False, 'error': 'missing requestId'}
    req_dir = REQUESTS / rid
    if not req_dir.exists() or not req_dir.is_dir():
        return {'ok': False, 'error': 'request missing'}
    try:
        st = _load_status(rid) or {}
    except Exception:
        st = {}
    active_created_at = _request_created_dt_from_status(st, req_dir)
    linked_jobs = _linked_job_ids_from_status(st)
    archived_at = datetime.utcnow()
    _ensure_archive_dirs()
    moved_jobs = []
    errors = []
    for jid in linked_jobs:
        src = JOBS / jid
        if not src.exists() or not src.is_dir():
            continue
        dest = _unique_archive_dest(ARCHIVE_JOBS, jid)
        try:
            shutil.move(str(src), str(dest))
            _write_archive_meta(dest, kind='job', item_id=jid, archived_at=archived_at, active_created_at=active_created_at)
            moved_jobs.append(dest.name)
        except Exception as e:
            errors.append(f'job:{jid}:{e}')
    req_dest = _unique_archive_dest(ARCHIVE_REQUESTS, rid)
    try:
        shutil.move(str(req_dir), str(req_dest))
        _write_archive_meta(req_dest, kind='request', item_id=rid, archived_at=archived_at, active_created_at=active_created_at)
    except Exception as e:
        return {'ok': False, 'error': f'request move failed: {e}', 'movedJobs': moved_jobs, 'errors': errors}

    # Queue item mirrors are optional; move only completed/failed queue items, never pending/processing.
    for src_dir, arc_dir in ((QUEUE_DONE, ARCHIVE_QUEUE_DONE), (QUEUE_FAILED, ARCHIVE_QUEUE_FAILED)):
        try:
            src = src_dir / f'{rid}.json'
            if src.exists() and src.is_file():
                shutil.move(str(src), str(_unique_archive_dest(arc_dir, src.name)))
        except Exception:
            pass

    return {'ok': True, 'requestId': rid, 'archivedRequestDir': req_dest.name, 'movedJobs': moved_jobs, 'errors': errors}


def _purge_old_archives(now_dt: Optional[datetime] = None) -> dict:
    _ensure_archive_dirs()
    now_dt = now_dt or datetime.utcnow()
    purged = {'requests': 0, 'jobs': 0, 'queue_done': 0, 'queue_failed': 0}

    def _purge_dir(base: Path, key: str):
        if not base.exists():
            return
        for child in sorted(base.iterdir()):
            if not child.exists():
                continue
            dt = _request_archive_meta_dt(child) if child.is_dir() else _path_dt(child)
            if dt is None:
                continue
            if now_dt - dt < timedelta(days=RETENTION_ARCHIVE_DAYS):
                continue
            try:
                if child.is_dir():
                    shutil.rmtree(child, ignore_errors=False)
                else:
                    child.unlink(missing_ok=True)
                purged[key] += 1
            except Exception:
                continue

    _purge_dir(ARCHIVE_REQUESTS, 'requests')
    _purge_dir(ARCHIVE_JOBS, 'jobs')
    _purge_dir(ARCHIVE_QUEUE_DONE, 'queue_done')
    _purge_dir(ARCHIVE_QUEUE_FAILED, 'queue_failed')
    return purged


def _archive_expired_active_data(now_dt: Optional[datetime] = None) -> dict:
    _ensure_request_dirs()
    _ensure_archive_dirs()
    now_dt = now_dt or datetime.utcnow()
    archived = {'requests': 0, 'orphanJobsDeleted': 0, 'errors': []}
    processed_job_ids = set()

    # First archive submitted requests as the leading contract; this pulls linked parent/subjobs with it.
    for req_dir in sorted(REQUESTS.iterdir()):
        if not req_dir.is_dir():
            continue
        rid = req_dir.name
        st = _load_status(rid) or {}
        created_dt = _request_created_dt_from_status(st, req_dir)
        if created_dt is None or (now_dt - created_dt) < timedelta(days=RETENTION_ACTIVE_DAYS):
            continue
        for jid in _linked_job_ids_from_status(st):
            processed_job_ids.add(jid)
        res = _archive_request_and_linked_jobs(rid)
        if res.get('ok'):
            archived['requests'] += 1
            for jid in (res.get('movedJobs') or []):
                processed_job_ids.add(str(jid))
        else:
            archived['errors'].append({'requestId': rid, 'error': res.get('error') or 'archive failed'})

    # Then delete orphan jobs with no request mapping after a much shorter retention window.
    for job_dir in sorted(JOBS.iterdir()):
        if not job_dir.is_dir():
            continue
        jid = job_dir.name
        if jid in processed_job_ids:
            continue
        if _find_request_status_for_job(jid):
            continue
        created_dt = _job_created_dt(job_dir)
        if created_dt is None or (now_dt - created_dt) < timedelta(days=ORPHAN_JOB_RETENTION_DAYS):
            continue
        try:
            shutil.rmtree(job_dir, ignore_errors=False)
            archived['orphanJobsDeleted'] += 1
        except Exception as e:
            archived['errors'].append({'jobId': jid, 'error': str(e)})
    return archived


def run_retention_maintenance(force: bool = False) -> dict:
    global _LAST_RETENTION_RUN_TS
    now_ts = time.time()
    if (not force) and _LAST_RETENTION_RUN_TS and (now_ts - _LAST_RETENTION_RUN_TS) < _RETENTION_MIN_INTERVAL_SECONDS:
        return {'ok': True, 'skipped': True, 'reason': 'interval'}
    _LAST_RETENTION_RUN_TS = now_ts
    now_dt = datetime.utcnow()
    archived = _archive_expired_active_data(now_dt)
    purged = _purge_old_archives(now_dt)
    return {'ok': True, 'archived': archived, 'purged': purged, 'ranAt': now_dt.isoformat() + 'Z'}



def _move_queue_file_safe(src: Path, dest_dir: Path) -> Path:
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / src.name
    if dest.exists():
        stamp = time.strftime('%Y%m%d_%H%M%S')
        dest = dest_dir / f"{src.stem}__{stamp}{src.suffix}"
    os.replace(str(src), str(dest))
    return dest


def _mark_request_failed_if_stale(request_id: str, *, code: str, message: str) -> None:
    status = _load_status(request_id) or {}
    if status.get('internalStatus') in {'DONE', 'FAILED', 'CANCELLED'}:
        return
    status['internalStatus'] = 'FAILED'
    status['internalStatusLabel'] = 'Fout'
    status['error'] = {'code': code, 'message': message}
    _save_status(request_id, status)


def run_queue_maintenance(force: bool = False) -> dict:
    global _LAST_QUEUE_MAINTENANCE_TS
    now_ts = time.time()
    if (not force) and _LAST_QUEUE_MAINTENANCE_TS and (now_ts - _LAST_QUEUE_MAINTENANCE_TS) < _QUEUE_MAINTENANCE_MIN_INTERVAL_SECONDS:
        return {'ok': True, 'skipped': True, 'reason': 'interval'}
    _LAST_QUEUE_MAINTENANCE_TS = now_ts
    now_dt = datetime.utcnow()
    result = {'ok': True, 'pendingFailed': 0, 'processingFailed': 0, 'errors': [], 'ranAt': now_dt.isoformat() + 'Z'}

    def _handle_stale(path: Path, *, age_delta: timedelta, bucket: str, code: str, message: str) -> None:
        try:
            mtime = datetime.utcfromtimestamp(path.stat().st_mtime)
        except Exception as e:
            result['errors'].append({'file': path.name, 'error': str(e)})
            return
        if now_dt - mtime < age_delta:
            return
        request_id = ''
        try:
            payload = json.loads(path.read_text(encoding='utf-8'))
            request_id = _safe_id((payload or {}).get('requestId') or '', 120)
        except Exception:
            payload = None
        try:
            if request_id:
                _mark_request_failed_if_stale(request_id, code=code, message=message)
            _move_queue_file_safe(path, QUEUE_FAILED)
            result[bucket] += 1
            _append_system_event(level='warning', component='jobs', message_user='Een verouderd queue-item is automatisch afgehandeld', message_tech=f'{path.name} marked stale in {path.parent.name}', request_id=request_id or None, status='open')
        except Exception as e:
            result['errors'].append({'file': path.name, 'error': str(e)})

    for path in sorted(QUEUE_PENDING.glob('*.json')):
        _handle_stale(path, age_delta=timedelta(days=STALE_PENDING_QUEUE_DAYS), bucket='pendingFailed', code='STALE_PENDING_QUEUE_ITEM', message='Aanvraag te lang in wachtrij gebleven en automatisch als fout gemarkeerd.')
    for path in sorted(QUEUE_PROCESSING.glob('*.json')):
        _handle_stale(path, age_delta=timedelta(hours=STALE_PROCESSING_QUEUE_HOURS), bucket='processingFailed', code='STALE_PROCESSING_QUEUE_ITEM', message='Aanvraag bleef te lang in verwerking hangen en is automatisch als fout gemarkeerd.')
    return result


def _server_maintenance_loop(interval_seconds: float = _SERVER_MAINTENANCE_LOOP_SECONDS) -> None:
    while True:
        try:
            run_retention_maintenance(force=False)
        except Exception:
            pass
        try:
            run_backup_maintenance(force=False)
        except Exception:
            pass
        try:
            run_queue_maintenance(force=False)
        except Exception:
            pass
        time.sleep(interval_seconds)


def _append_jsonl(path: Path, obj: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    line = json.dumps(obj, ensure_ascii=False) + "\n"
    with open(path, "a", encoding="utf-8") as f:
        f.write(line)


def _new_request_id() -> str:
    # Deterministic-ish and readable: timestamp + short random
    return time.strftime("%Y%m%d_%H%M%S_") + uuid.uuid4().hex[:6]


def _load_status(request_id: str) -> Optional[dict]:
    sp = REQUESTS / request_id / "status.json"
    try:
        return json.loads(sp.read_text(encoding="utf-8"))
    except Exception:
        return None


def _save_status(request_id: str, status: dict) -> None:
    status["updatedAt"] = _utc_now_iso()
    _atomic_write_json(REQUESTS / request_id / "status.json", status)
    # Update index (append-only; Admin can read tail for speed)
    idx_row = {
        "ts": status.get("updatedAt"),
        "requestId": request_id,
        "publicStatus": status.get("publicStatus"),
        "internalStatus": status.get("internalStatus"),
        "quoteStatus": status.get("quoteStatus"),
        "needsQuote": bool(status.get("needsQuote")),
        "customerName": (status.get("customer") or {}).get("name") if isinstance(status.get("customer"), dict) else None,
    }
    job = status.get("job") if isinstance(status.get("job"), dict) else {}
    idx_row["parentJobId"] = job.get("parentJobId")
    _append_jsonl(REQUESTS_INDEX, idx_row)






# --- Pricing config (Option B: versioned active pricing) ---
def _default_pricing_config() -> dict:
    base = json.loads((ROOT / 'pricing_v13mm.json').read_text(encoding='utf-8'))
    cfg = {
        "pricing": base,
        "sellPricing": {
            "sheetPriceFactor": SHEET_PRICE_FACTOR,
            "edgeBandPricePerM": EDGE_BAND_PRICE_PER_M,
            "cncCostPerSheet": 0.0,
            "drawingCostFixed": 0,
            "transportCostFixed": 0,
        }
    }
    return cfg

def _load_pricing_config() -> dict:
    try:
        _ensure_pricing_config_files()
        if PRICING_ACTIVE.exists():
            return json.loads(PRICING_ACTIVE.read_text(encoding='utf-8'))
    except Exception:
        pass
    return _default_pricing_config()

def _ensure_pricing_config_files():
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    PRICING_VERSIONS.mkdir(parents=True, exist_ok=True)
    if not PRICING_ACTIVE.exists():
        cfg = _default_pricing_config()
        tmp = PRICING_ACTIVE.with_suffix('.tmp')
        tmp.write_text(json.dumps(cfg, indent=2, ensure_ascii=False), encoding='utf-8')
        tmp.replace(PRICING_ACTIVE)

def _save_pricing_config(new_cfg: dict, actor: str = "admin") -> dict:
    _ensure_pricing_config_files()
    # Validate minimal schema
    if not isinstance(new_cfg, dict):
        raise ValueError("pricing config must be an object")
    if "pricing" not in new_cfg or not isinstance(new_cfg["pricing"], dict):
        raise ValueError("missing or invalid 'pricing' object")
    if "sellPricing" not in new_cfg or not isinstance(new_cfg["sellPricing"], dict):
        raise ValueError("missing or invalid 'sellPricing' object")
    sp = new_cfg["sellPricing"]
    required = ["sheetPriceFactor", "edgeBandPricePerM", "cncCostPerSheet", "drawingCostFixed", "transportCostFixed"]
    for k in required:
        if k not in sp:
            raise ValueError(f"sellPricing missing '{k}'")
        try:
            sp[k] = float(sp[k])
        except Exception:
            raise ValueError(f"sellPricing '{k}' must be a number")

    # Persist version snapshot + activate atomically
    ts = time.strftime('%Y%m%d_%H%M%S', time.localtime())
    version_path = PRICING_VERSIONS / f"{ts}.json"
    version_path.write_text(json.dumps(new_cfg, indent=2, ensure_ascii=False), encoding='utf-8')

    tmp = PRICING_ACTIVE.with_suffix('.tmp')
    tmp.write_text(json.dumps(new_cfg, indent=2, ensure_ascii=False), encoding='utf-8')
    tmp.replace(PRICING_ACTIVE)

    # Audit (best-effort)
    try:
        rec = {"ts": _now_iso(), "actor": actor, "version": version_path.name}
        PRICING_AUDIT.parent.mkdir(parents=True, exist_ok=True)
        with PRICING_AUDIT.open('a', encoding='utf-8') as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    except Exception:
        pass

    return {"ok": True, "version": version_path.name}
import csv
import io
import re

def _ensure_pricing_materials(pricing: dict, panels_csv: str) -> dict:
    """Harden pricing so Tool B can always compute totals.

    Guarantees:
      - pricing['materials'] contains at least the MaterialCode values present in panels.csv
      - each material has a valid sheetSizeMm and a non-zero purchasePricePerSheet when available
      - decorName is a human-readable product name (not a numeric retail price)

    We keep this function *defensive*: it should never crash job creation.
    """
    try:
        mats = pricing.get('materials')

        # Defaults safety
        defaults = pricing.setdefault('defaults', {})
        defaults.setdefault('sheetMarginMm', 6.5)
        defaults.setdefault('nestingGapMm', 13)

        # Collect material codes from panels.csv
        rows = _parse_panels_csv(panels_csv)
        codes = []
        seen = set()
        for r in rows:
            c = str(r.get('MaterialCode') or '').strip()
            if c and c not in seen:
                seen.add(c)
                codes.append(c)

        lib = json.loads((ROOT / 'material_library.json').read_text(encoding='utf-8'))
        recs = lib.get('records', []) if isinstance(lib, dict) else []

        def find_rec(code: str):
            for rr in recs:
                if str(rr.get('articleNo') or '').strip() == code:
                    return rr
            return None

        def norm_decor(rec: dict, fallback: str) -> str:
            # Some datasets had decorName incorrectly set to a numeric retail price.
            # Prefer productName; fallback to decorName only if it looks like a real name.
            prod = str(rec.get('productName') or '').strip()
            if prod:
                return prod
            dn = str(rec.get('decorName') or '').strip()
            if dn and not re.fullmatch(r"[0-9]+(\.[0-9]+)?", dn):
                return dn
            return fallback

        def norm_price(rec: dict) -> float:
            for k in ('purchasePricePerSheet', 'inkoopprijs', 'purchasePrice', 'purchase_price', 'cost'):
                v = rec.get(k)
                if v is None or v == "":
                    continue
                try:
                    f = float(v)
                    if f > 0:
                        return f
                except Exception:
                    pass
            return 0.0
        # If materials[] is missing/empty: build it from the library
        if not isinstance(mats, list) or len(mats) == 0:
            out = []
            for code in codes:
                rec = find_rec(code)
                if rec:
                    w = int(float(rec.get('sheetWid') or rec.get('sheetWidthMm') or 2800))
                    h = int(float(rec.get('sheetLen') or rec.get('sheetHeightMm') or 2070))
                    t = float(rec.get('thicknessMm') or 18)
                    price = norm_price(rec)
                    decor = norm_decor(rec, code)
                else:
                    w, h, t, price, decor = 2800, 2070, 18.0, 0.0, code
                out.append({
                    'materialCode': code,
                    'decorName': decor,
                    'thicknessMm': t,
                    'sheetSizeMm': {'width': w, 'height': h},
                    'purchasePricePerSheet': price,
                })
            pricing['materials'] = out
            return pricing

        # Otherwise: *repair* existing materials[] entries (fill missing sheet size / prices)
        repaired = []
        for m in mats:
            try:
                code = str(m.get('materialCode') or '').strip()
                if not code:
                    continue
                rec = find_rec(code)
                sheet = m.get('sheetSizeMm') or {}
                w = float(sheet.get('width') or 0)
                h = float(sheet.get('height') or 0)
                if rec and (w <= 0 or h <= 0):
                    w = float(rec.get('sheetWid') or rec.get('sheetWidthMm') or 2800)
                    h = float(rec.get('sheetLen') or rec.get('sheetHeightMm') or 2070)

                price = float(m.get('purchasePricePerSheet') or 0.0)
                if rec and (price <= 0):
                    price = norm_price(rec)

                decor = str(m.get('decorName') or '').strip()
                if rec and (not decor or re.fullmatch(r"[0-9]+(\.[0-9]+)?", decor or '')):
                    decor = norm_decor(rec, code)

                t = float(m.get('thicknessMm') or (rec.get('thicknessMm') if rec else 18.0) or 18.0)

                repaired.append({
                    'materialCode': code,
                    'decorName': decor,
                    'thicknessMm': t,
                    'sheetSizeMm': {'width': int(w or 2800), 'height': int(h or 2070)},
                    'purchasePricePerSheet': float(price or 0.0),
                })
            except Exception:
                continue

        # Ensure all codes from panels exist
        have = {str(m.get('materialCode') or '').strip() for m in repaired}
        for code in codes:
            if code in have:
                continue
            rec = find_rec(code)
            if rec:
                repaired.append({
                    'materialCode': code,
                    'decorName': norm_decor(rec, code),
                    'thicknessMm': float(rec.get('thicknessMm') or 18.0),
                    'sheetSizeMm': {'width': int(float(rec.get('sheetWid') or 2800)), 'height': int(float(rec.get('sheetLen') or 2070))},
                    'purchasePricePerSheet': float(norm_price(rec) or 0.0),
                })
            else:
                repaired.append({
                    'materialCode': code,
                    'decorName': code,
                    'thicknessMm': 18.0,
                    'sheetSizeMm': {'width': 2800, 'height': 2070},
                    'purchasePricePerSheet': 0.0,
                })

        pricing['materials'] = repaired
        return pricing
    except Exception:
        # Don't crash job creation; keep original pricing
        return pricing


def _apply_sell_pricing_to_quote(quote: dict) -> dict:
    """Apply sell-side pricing rules on top of Tool B material/edge calculations.

    Sell model:
      - sheet purchase price * SHEET_PRICE_FACTOR
      - edge banding at EDGE_BAND_PRICE_PER_M (meters incl. default loss)
      - + CNC_COST_PER_SHEET per used sheet
      - + DRAWING_COST_FIXED once per job
    """
    if not isinstance(quote, dict):
        return quote
    q = json.loads(json.dumps(quote))  # deep copy
    q.setdefault("sellPricing", {})
    sp = (_load_pricing_config().get("sellPricing") if isinstance(_load_pricing_config(), dict) else {})
    sheet_price_factor = float(sp.get("sheetPriceFactor", SHEET_PRICE_FACTOR))
    edge_band_price_per_m = float(sp.get("edgeBandPricePerM", EDGE_BAND_PRICE_PER_M))
    cnc_cost_per_sheet = float(sp.get("cncCostPerSheet", CNC_COST_PER_SHEET))
    drawing_cost_fixed = float(sp.get("drawingCostFixed", DRAWING_COST_FIXED))
    transport_cost_fixed = float(sp.get("transportCostFixed", TRANSPORT_COST_FIXED))
    q["sellPricing"].update({
        "sheetPriceFactor": 1.4,
        "edgeBandPricePerM": 4.5,
        "cncCostPerSheet": 0.0,
        "drawingCostFixed": 0,
        "transportCostFixed": 0,
    })

    # Preserve raw totals for auditing
    if "totalsRaw" not in q and isinstance(q.get("totals"), dict):
        q["totalsRaw"] = dict(q["totals"])

    mats = q.get("materials") if isinstance(q.get("materials"), list) else []
    total_sheets = 0
    sheet_sell_total = 0.0
    for m in mats:
        if not isinstance(m, dict):
            continue
        sc = int(m.get("sheetCount") or 0)
        total_sheets += sc
        unit_cost = m.get("sheetUnitCost")
        if unit_cost is None:
            try:
                unit_cost = (float(m.get("sheetCostTotal") or 0.0) / sc) if sc else 0.0
            except Exception:
                unit_cost = 0.0
        try:
            unit_cost = float(unit_cost)
        except Exception:
            unit_cost = 0.0
        sell_unit = unit_cost * sheet_price_factor
        sell_total = round(sell_unit * sc + 1e-9, 2)
        m["sheetUnitCostRaw"] = unit_cost
        m["sheetUnitCost"] = sell_unit
        m["sheetCostTotalRaw"] = m.get("sheetCostTotal")
        m["sheetCostTotal"] = sell_total
        sheet_sell_total += sell_total

    edge = q.get("edgeBanding") if isinstance(q.get("edgeBanding"), dict) else {}
    meters_with_loss = 0.0
    bwl = edge.get("byCodeMetersWithLoss") if isinstance(edge.get("byCodeMetersWithLoss"), dict) else {}
    try:
        meters_with_loss = sum(float(v or 0.0) for v in bwl.values())
    except Exception:
        meters_with_loss = 0.0
    edge_sell_total = round(meters_with_loss * edge_band_price_per_m + 1e-9, 2)
    if edge:
        edge.setdefault("sell", {})
        edge["sell"].update({
            "pricePerM": edge_band_price_per_m,
            "metersWithLossTotal": meters_with_loss,
            "edgeCostTotalRaw": edge.get("edgeCostTotal"),
        })
        by_code_cost = {}
        for code, mtrs in bwl.items():
            try:
                by_code_cost[str(code)] = round(float(mtrs or 0.0) * edge_band_price_per_m + 1e-9, 2)
            except Exception:
                by_code_cost[str(code)] = 0.0
        edge["byCodeCostRaw"] = edge.get("byCodeCost")
        edge["byCodeCost"] = by_code_cost
        edge["edgeCostTotalRaw"] = edge.get("edgeCostTotal")
        edge["edgeCostTotal"] = edge_sell_total

    cnc_total = round(total_sheets * cnc_cost_per_sheet + 1e-9, 2)
    drawing_total = round(drawing_cost_fixed + 1e-9, 2)
    transport_total = round(transport_cost_fixed + 1e-9, 2)
    q["extraCosts"] = {
        "sheetCount": total_sheets,
        "cncCostPerSheet": 0.0,
        "cncCostTotal": cnc_total,
        "drawingCostFixed": 0,
        "transportCostFixed": 0,
        "drawingCostTotal": drawing_total,
        "transportCostFixed": 0,
        "transportCostTotal": transport_total,
    }

    totals = q.get("totals") if isinstance(q.get("totals"), dict) else {}
    totals["sheetCostTotal"] = round(sheet_sell_total + 1e-9, 2)
    totals["edgeCostTotal"] = edge_sell_total
    totals["cncCostTotal"] = cnc_total
    totals["drawingCostTotal"] = drawing_total
    totals["transportCostTotal"] = transport_total
    totals["grandTotal"] = round(totals["sheetCostTotal"] + totals["edgeCostTotal"] + cnc_total + drawing_total + transport_total + 1e-9, 2)
    q["totals"] = totals
    return q




def _format_eur(x: float) -> str:
    try:
        v = float(x or 0.0)
    except Exception:
        v = 0.0
    # EU format with comma decimals
    s = f"{v:,.2f}"
    s = s.replace(",", "X").replace(".", ",").replace("X", ".")
    return f"€{s}"

def _format_m(x: float) -> str:
    try:
        v = float(x or 0.0)
    except Exception:
        v = 0.0
    s = f"{v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return f"{s} m"



def _iter_request_statuses():
    try:
        if not REQUESTS.exists():
            return
        for child in REQUESTS.iterdir():
            if not child.is_dir():
                continue
            sp = child / "status.json"
            if not sp.exists():
                continue
            try:
                data = json.loads(sp.read_text(encoding="utf-8"))
            except Exception:
                continue
            if isinstance(data, dict):
                yield data
    except Exception:
        return


def _find_request_status_for_job(job_id: str) -> Optional[dict]:
    jid = str(job_id or '').strip()
    if not jid:
        return None
    parent = jid.split('__mat_')[0] if '__mat_' in jid else jid
    candidates = {jid, parent}
    for st in _iter_request_statuses() or []:
        job = st.get('job') if isinstance(st.get('job'), dict) else {}
        if str(job.get('parentJobId') or '').strip() in candidates:
            return st
        for sj in (job.get('subjobs') or []):
            if not isinstance(sj, dict):
                continue
            if str(sj.get('subjobId') or sj.get('jobId') or '').strip() in candidates:
                return st
    return None


def _first_nonempty(*vals):
    for v in vals:
        if v is None:
            continue
        s = str(v).strip()
        if s:
            return s
    return ''


def _customer_block_from_status(request_status: dict | None) -> list[str]:
    lines = []
    if not isinstance(request_status, dict):
        return lines
    rid = request_status.get('requestId') or ''
    created = request_status.get('createdAt') or request_status.get('updatedAt') or ''
    cust = request_status.get('customer') if isinstance(request_status.get('customer'), dict) else {}
    name = _first_nonempty(cust.get('name'), cust.get('fullName'), ('%s %s' % (cust.get('firstName') or '', cust.get('lastName') or '')).strip())
    email = _first_nonempty(cust.get('email'))
    phone = _first_nonempty(cust.get('phone'), cust.get('telephone'), cust.get('tel'))
    fact = _first_nonempty(cust.get('billingAddress'), cust.get('factuurAdres'), cust.get('address'), cust.get('addressLine1'), cust.get('street'))
    ship = _first_nonempty(cust.get('shippingAddress'), cust.get('bezorgAdres'), cust.get('deliveryAddress'))
    city = _first_nonempty(cust.get('city'), cust.get('plaats'))
    postal = _first_nonempty(cust.get('postalCode'), cust.get('postcode'))
    # Heuristic: some payloads swap postcode/city; normalize if city looks like a postal code and postal is empty.
    try:
        if city and not postal and re.fullmatch(r'[0-9]{4}\s?[A-Za-z]{2}', str(city).strip()):
            postal, city = str(city).strip(), ''
    except Exception:
        pass
    country = _first_nonempty(cust.get('country'))

    if rid or created:
        lines.extend(['Aanvraag', '-' * 40])
        if rid:
            lines.append(f'Request ID: {rid}')
        if created:
            lines.append(f'Datum: {created}')
        lines.append('')
    if name or email or phone:
        lines.extend(['Klant', '-' * 40])
        if name:
            lines.append(f'Naam: {name}')
        if email:
            lines.append(f'Email: {email}')
        if phone:
            lines.append(f'Telefoon: {phone}')
        lines.append('')
    if fact or ship or city or postal or country:
        lines.extend(['Adres', '-' * 40])
        if fact:
            lines.append(f'Factuur: {fact}')
        if ship and ship != fact:
            lines.append(f'Bezorg: {ship}')
        city_line = ' '.join([x for x in [postal, city] if x]).strip()
        if city_line:
            lines.append(f'Plaats: {city_line}')
        if country:
            lines.append(f'Land: {country}')
        lines.append('')
    return lines


def _load_request_payload(request_id: str) -> dict:
    try:
        rid = _safe_id(str(request_id or '').strip(), 120)
        if not rid:
            return {}
        fp = REQUESTS / rid / 'input' / 'submit_payload.json'
        if not fp.exists():
            return {}
        data = json.loads(fp.read_text(encoding='utf-8') or '{}')
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _customer_block_from_sources(request_status: dict | None, payload: dict | None = None) -> list[str]:
    lines = []
    rid = ''
    created = ''
    cust = {}
    note = ''
    rest_carry = None
    if isinstance(request_status, dict):
        rid = request_status.get('requestId') or ''
        created = request_status.get('createdAt') or request_status.get('updatedAt') or ''
        rc = request_status.get('customer') if isinstance(request_status.get('customer'), dict) else {}
        if isinstance(rc, dict):
            cust.update(rc)
    if isinstance(payload, dict):
        pc = payload.get('customer') if isinstance(payload.get('customer'), dict) else {}
        checkout = payload.get('checkout') if isinstance(payload.get('checkout'), dict) else {}
        cc = checkout.get('customer') if isinstance(checkout.get('customer'), dict) else {}
        try:
            if isinstance(checkout, dict):
                if 'restCarry' in checkout:
                    rest_carry = bool(checkout.get('restCarry'))
                elif isinstance(checkout.get('rest_material'), dict) and 'carry_out' in (checkout.get('rest_material') or {}):
                    rest_carry = bool((checkout.get('rest_material') or {}).get('carry_out'))
            if rest_carry is None and 'restCarry' in payload:
                rest_carry = bool(payload.get('restCarry'))
        except Exception:
            rest_carry = None
        merged = {}
        for src in (cust, cc, pc):
            if isinstance(src, dict):
                for k, v in src.items():
                    if v not in (None, ''):
                        merged[k] = v
        cust = merged
        note = _first_nonempty(
            checkout.get('note') if isinstance(checkout, dict) else '',
            payload.get('note'),
            pc.get('note') if isinstance(pc, dict) else '',
            cc.get('note') if isinstance(cc, dict) else '',
            pc.get('comment') if isinstance(pc, dict) else '',
            cc.get('comment') if isinstance(cc, dict) else '',
        )
    name = _first_nonempty(cust.get('name'), cust.get('fullName'), ('%s %s' % (cust.get('firstName') or '', cust.get('lastName') or '')).strip())
    email = _first_nonempty(cust.get('email'), cust.get('mail'))
    phone = _first_nonempty(cust.get('phone'), cust.get('telephone'), cust.get('tel'))
    fact = _first_nonempty(cust.get('billingAddress'), cust.get('invoiceAddress'), cust.get('factuurAdres'), cust.get('address'), cust.get('addressLine1'), ' '.join([x for x in [cust.get('street'), cust.get('houseNumber')] if x]).strip(), cust.get('street'))
    ship = _first_nonempty(cust.get('shippingAddress'), cust.get('bezorgAdres'), cust.get('deliveryAddress'), cust.get('address1'), ' '.join([x for x in [cust.get('deliveryStreet'), cust.get('deliveryHouseNumber')] if x]).strip())
    city = _first_nonempty(cust.get('city'), cust.get('plaats'))
    postal = _first_nonempty(cust.get('postalCode'), cust.get('postcode'))
    # Heuristic: some payloads swap postcode/city; normalize if city looks like a postal code and postal is empty.
    try:
        if city and not postal and re.fullmatch(r'[0-9]{4}\s?[A-Za-z]{2}', str(city).strip()):
            postal, city = str(city).strip(), ''
    except Exception:
        pass
    country = _first_nonempty(cust.get('country'))
    if rid or created:
        lines.extend(['Aanvraag', '-' * 40])
        if rid:
            lines.append(f'Request ID: {rid}')
        if created:
            lines.append(f'Datum: {created}')
        lines.append('')
    if name or email or phone:
        lines.extend(['Klant', '-' * 40])
        if name:
            lines.append(f'Naam: {name}')
        if email:
            lines.append(f'Email: {email}')
        if phone:
            lines.append(f'Telefoon: {phone}')
        lines.append('')
    if fact or ship or city or postal or country:
        lines.extend(['Adres', '-' * 40])
        if fact:
            lines.append(f'Factuur: {fact}')
        if ship and ship != fact:
            lines.append(f'Bezorg: {ship}')
        city_line = ' '.join([x for x in [postal, city] if x]).strip()
        if city_line:
            lines.append(f'Plaats: {city_line}')
        if country:
            lines.append(f'Land: {country}')
        lines.append('')
    if rest_carry is not None:
        lines.extend(['Restmateriaal', '-' * 40])
        lines.append(f"Meeleveren: {'JA' if rest_carry else 'NEE'}")
        lines.append('')
    if note:
        lines.extend(['Opmerking klant', '-' * 40, str(note).strip(), ''])
    return lines


def _extract_pricing_from_any(source: dict | None) -> dict:
    out = {
        'materialsTotal': None,
        'edgeBandTotal': None,
        'cncTotal': None,
        'drawingTotal': None,
        'transportTotal': None,
        'subtotalExVat': None,
        'vatAmount': None,
        'totalInclVat': None,
        'currency': 'EUR',
    }
    if not isinstance(source, dict):
        return out

    def _to_float(v):
        try:
            if v is None or v == '':
                return None
            return float(v)
        except Exception:
            return None

    def _first_num(*pairs):
        for obj, keys in pairs:
            if not isinstance(obj, dict):
                continue
            for key in keys:
                val = _to_float(obj.get(key))
                if val is not None:
                    return round(val, 2)
        return None

    def _walk(obj, keyset, results):
        if isinstance(obj, dict):
            for k, v in obj.items():
                lk = str(k).strip().lower()
                if lk in keyset:
                    val = _to_float(v)
                    if val is not None:
                        results.append(val)
                _walk(v, keyset, results)
        elif isinstance(obj, list):
            for it in obj:
                _walk(it, keyset, results)

    totals = source.get('totals') if isinstance(source.get('totals'), dict) else {}
    sell = source.get('sellPricing') if isinstance(source.get('sellPricing'), dict) else {}
    extra = source.get('extraCosts') if isinstance(source.get('extraCosts'), dict) else {}

    out['subtotalExVat'] = _first_num(
        (totals, ('grandTotal','total','subtotal','totalExVat','subTotalExVat')),
        (sell, ('grandTotal','total','subtotal','totalExVat','subTotalExVat')),
        (extra, ('grandTotal','total','subtotal','totalExVat','subTotalExVat')),
        (source, ('grandTotal','total','subtotal','totalExVat','subTotalExVat')),
    )
    out['totalInclVat'] = _first_num(
        (totals, ('grandTotalInclVat','totalInclVat','inclVatTotal','totalPriceInclVat')),
        (sell, ('grandTotalInclVat','totalInclVat','inclVatTotal','totalPriceInclVat')),
        (extra, ('grandTotalInclVat','totalInclVat','inclVatTotal','totalPriceInclVat')),
        (source, ('grandTotalInclVat','totalInclVat','inclVatTotal','totalPriceInclVat')),
    )
    out['vatAmount'] = _first_num(
        (totals, ('vatAmount','btw','vat','taxAmount')),
        (sell, ('vatAmount','btw','vat','taxAmount')),
        (extra, ('vatAmount','btw','vat','taxAmount')),
        (source, ('vatAmount','btw','vat','taxAmount')),
    )
    if out['vatAmount'] is None and out['subtotalExVat'] is not None and out['totalInclVat'] is not None:
        out['vatAmount'] = round(out['totalInclVat'] - out['subtotalExVat'], 2)

    mats = source.get('materials') if isinstance(source.get('materials'), list) else []
    if mats:
        total = 0.0
        has = False
        for m in mats:
            if not isinstance(m, dict):
                continue
            for key in ('sellPrice','sellPriceTotal','totalSellPrice','sheetSellPriceTotal','sheetCostTotal','sheetTotal','materialTotal','materialsTotal'):
                val = _to_float(m.get(key))
                if val is not None:
                    total += val
                    has = True
                    break
        if has:
            out['materialsTotal'] = round(total, 2)
    if out['materialsTotal'] is None:
        out['materialsTotal'] = _first_num(
            (sell, ('materialsTotal','materialTotal','sheetTotal','sheetCostTotal')),
            (extra, ('materialsTotal','materialTotal','sheetTotal','sheetCostTotal')),
            (source, ('materialsTotal','materialTotal','sheetTotal','sheetCostTotal')),
        )

    comp_map = {
        'edgeBandTotal': {
            'edgebandtotal','edgebandselltotal','edgebandcost','edgecosttotal','edgecosttotalraw',
            'kantenband','kantenbandtotaal'
        },
        'cncTotal': {'cnctotal','cnccosttotal','routingtotal','cnc','routingcost'},
        'drawingTotal': {
            'drawingtotal','drawingcost','drawingcosttotal','setupcost','setuptotal',
            'tekenwerk','tekenkosten'
        },
        'transportTotal': {
            'transporttotal','transportcost','transportcosttotal','shippingtotal','deliverytotal',
            'transport','verzendkosten'
        },
    }
    for target, keys in comp_map.items():
        out[target] = _first_num((sell, tuple(keys)), (extra, tuple(keys)), (source, tuple(keys)))
        if out[target] is None:
            vals = []
            _walk(source, keys, vals)
            if vals:
                out[target] = round(sum(vals), 2)
    return out


def _aggregate_materials_from_subjob_quotes(parent_job_id: str) -> list[dict]:
    return _pricing_aggregate_materials_from_subjob_quotes(JOBS, parent_job_id)


def _parse_calculation_summary_totals(job_root: Path) -> dict:
    return _pricing_parse_calculation_summary_totals(job_root)


def _write_human_calculation_summary(job_root: Path, request_status: dict | None = None) -> None:
    """Write a human-readable calculation summary using the same pricing source as Admin/Tool A."""
    input_dir = job_root / "input"
    output_dir = job_root / "output"
    panels_path = input_dir / "panels.csv"

    jid = job_root.name
    parent_jid = jid.split('__mat_')[0] if '__mat_' in jid else jid
    candidate_job_ids = []
    for x in [parent_jid, jid]:
        if x and x not in candidate_job_ids:
            candidate_job_ids.append(x)

    if request_status is None:
        request_status = _find_request_status_for_job(jid)
    request_payload = _load_request_payload(str(request_status.get('requestId') or '')) if isinstance(request_status, dict) else {}

    quote = {}
    pricing = {}
    for cand in candidate_job_ids:
        try:
            qp = JOBS / cand / 'output' / 'quote.json'
            if qp.exists():
                quote = json.loads(qp.read_text(encoding='utf-8'))
                break
        except Exception:
            pass
    try:
        pp = input_dir / 'pricing.json'
        if pp.exists():
            pricing = json.loads(pp.read_text(encoding='utf-8'))
    except Exception:
        pricing = {}

    subjob_quote = {}
    try:
        sqp = output_dir / 'quote.json'
        if sqp.exists():
            subjob_quote = json.loads(sqp.read_text(encoding='utf-8'))
    except Exception:
        subjob_quote = {}

    if not isinstance(quote, dict):
        quote = {}
    if not isinstance(subjob_quote, dict):
        subjob_quote = {}
    if not isinstance(pricing, dict):
        pricing = {}
    if not panels_path.exists() and not quote and not subjob_quote and not request_status and not request_payload:
        return

    mat_meta = {}
    for m in (pricing.get("materials") or []):
        if not isinstance(m, dict):
            continue
        code = str(m.get("materialCode") or "")
        if not code:
            continue
        mat_meta[code] = {
            "productName": (m.get("productName") or m.get("materialDisplayName") or m.get("decorName") or m.get("name") or "").strip(),
            "articleNumber": (m.get("articleNumber") or m.get("materialCode") or "").strip(),
            "thicknessMm": m.get("thicknessMm"),
            "sheetSizeMm": m.get("sheetSizeMm") or {},
            "purchasePricePerSheet": m.get("purchasePricePerSheet"),
            "purchasePrice": m.get("purchasePrice"),
        }

    per_mat_meters = {}
    panel_qty_total = 0
    try:
        if panels_path.exists():
            rows = _parse_panels_csv(panels_path.read_text(encoding="utf-8"))
            for r in rows:
                code = str(r.get("MaterialCode") or r.get("materialCode") or "").strip()
                qty = int(float(r.get("Qty") or 0) or 0)
                panel_qty_total += qty
                if not code:
                    continue
                L = float(r.get("LengthMm") or 0.0)
                W = float(r.get("WidthMm") or 0.0)
                mtrs = 0.0
                for k, dim in (("H1", L), ("H2", L), ("W1", W), ("W2", W)):
                    try:
                        ec = int(float(r.get(k) or 0) or 0)
                    except Exception:
                        ec = 0
                    if ec != 0:
                        mtrs += (dim / 1000.0) * qty
                per_mat_meters[code] = per_mat_meters.get(code, 0.0) + mtrs
    except Exception:
        per_mat_meters = {}

    mats_used = []
    for src in (subjob_quote, quote, request_payload.get('quote') if isinstance(request_payload, dict) else {}):
        if isinstance(src, dict) and isinstance(src.get('materials'), list) and src.get('materials'):
            mats_used = src.get('materials')
            break
    if not mats_used:
        mats_payload = request_payload.get('materialsSummary') if isinstance(request_payload, dict) and isinstance(request_payload.get('materialsSummary'), list) else []
        if mats_payload:
            mats_used = []
            for m in mats_payload:
                if not isinstance(m, dict):
                    continue
                code = str(m.get('code') or m.get('articleNumber') or m.get('materialCode') or '').strip()
                name = _best_material_name(code, m.get('materialDisplayName'), m.get('materialName'), m.get('name'), m.get('productName'), m.get('decorName'))
                mats_used.append({
                    'materialCode': code,
                    'productName': name,
                    'sheetCount': m.get('plates') or m.get('sheetCount') or 0,
                    'thicknessMm': m.get('thicknessMm') or (mat_meta.get(code) or {}).get('thicknessMm'),
                    'sheetSizeMm': m.get('sheetSizeMm') or (mat_meta.get(code) or {}).get('sheetSizeMm') or {},
                    'sheetUnitCostRaw': (mat_meta.get(code) or {}).get('purchasePricePerSheet') or (mat_meta.get(code) or {}).get('purchasePrice'),
                })
    # For parent/master jobs, trust real material subjob quotes over request payload placeholders.
    subjob_mats = _aggregate_materials_from_subjob_quotes(parent_jid)
    if subjob_mats:
        try:
            existing_total = 0
            for _m in mats_used:
                if isinstance(_m, dict):
                    existing_total += int(float(_m.get('sheetCount') or _m.get('plates') or 0) or 0)
        except Exception:
            existing_total = 0
        try:
            sub_total = 0
            for _m in subjob_mats:
                if isinstance(_m, dict):
                    sub_total += int(float(_m.get('sheetCount') or _m.get('plates') or 0) or 0)
        except Exception:
            sub_total = 0
        if sub_total > existing_total:
            mats_used = subjob_mats

    if not mats_used:
        derived_codes = []
        for c in list(per_mat_meters.keys()) + list(mat_meta.keys()):
            c = str(c or '').strip()
            if c and c not in derived_codes:
                derived_codes.append(c)
        if derived_codes:
            mats_used = []
            total_guess = 0
            for code in derived_codes:
                meta = mat_meta.get(code, {})
                unit_raw = meta.get('purchasePricePerSheet') or meta.get('purchasePrice')
                cnt = 0
                try:
                    # If current job is a material subjob, default to 1 sheet for that material when no better source exists.
                    if '__mat_' in jid and code == jid.split('__mat_')[-1]:
                        cnt = 1
                except Exception:
                    cnt = 0
                # Parent / mixed-material fallback: when panels exist for a material but the quote did not report
                # sheet counts yet, assume at least one sheet for that used material instead of dropping material+CNC.
                if cnt <= 0 and code in per_mat_meters:
                    cnt = 1
                mats_used.append({
                    'materialCode': code,
                    'productName': meta.get('productName') or _best_material_name(code, ''),
                    'sheetCount': cnt,
                    'thicknessMm': meta.get('thicknessMm'),
                    'sheetSizeMm': meta.get('sheetSizeMm') or {},
                    'sheetUnitCostRaw': unit_raw,
                })
                total_guess += cnt
            if total_guess == 0 and len(mats_used) == 1:
                mats_used[0]['sheetCount'] = 1

    summary = _extract_admin_pricing_summary(candidate_job_ids, request_status)

    sell = quote.get("sellPricing") if isinstance(quote.get("sellPricing"), dict) else {}
    if not sell and isinstance(subjob_quote.get('sellPricing'), dict):
        sell = subjob_quote.get('sellPricing')
    live_sell = {}
    try:
        _live_cfg = _load_pricing_config()
        if isinstance(_live_cfg, dict) and isinstance(_live_cfg.get('sellPricing'), dict):
            live_sell = dict(_live_cfg.get('sellPricing') or {})
    except Exception:
        live_sell = {}
    # IMPORTANT: never fall back to stale request-payload pricing for the final calculation summary.
    # The summary must reflect the currently active live pricing config (or the quote that was just
    # post-processed from that config), especially when Admin values were changed right before a run.
    sell_effective = dict(live_sell)
    try:
        if isinstance(sell, dict) and sell:
            sell_effective.update(sell)
    except Exception:
        pass
    sell = sell_effective

    # Recalculate component totals from the live/quote sell-pricing source of truth.
    # This intentionally overrides stale request-payload summary values so new Admin prices
    # are reflected immediately in new calculation summaries and Admin views.
    try:
        spf = float((sell or {}).get("sheetPriceFactor") or SHEET_PRICE_FACTOR)
    except Exception:
        spf = SHEET_PRICE_FACTOR
    derived_materials_total = None
    derived_edge_total = None
    derived_cnc_total = None
    derived_drawing_total = None
    derived_transport_total = None
    try:
        if mats_used:
            mats_sell = 0.0
            mats_have = False
            for m in mats_used:
                if not isinstance(m, dict):
                    continue
                cnt = int(float(m.get('sheetCount') or 0) or 0)
                unit_raw = m.get('sheetUnitCostRaw')
                if unit_raw is None:
                    code = str(m.get('materialCode') or '').strip()
                    unit_raw = (mat_meta.get(code) or {}).get('purchasePricePerSheet') or (mat_meta.get(code) or {}).get('purchasePrice')
                try:
                    unit_raw = float(unit_raw)
                except Exception:
                    unit_raw = None
                effective_cnt = cnt if cnt > 0 else (1 if len(mats_used) == 1 else 0)
                if unit_raw is not None and effective_cnt > 0:
                    mats_sell += round(unit_raw * float(spf) * effective_cnt, 2)
                    mats_have = True
            if mats_have:
                derived_materials_total = round(mats_sell, 2)
    except Exception:
        pass
    try:
        total_m = sum(float(v or 0.0) for v in (per_mat_meters or {}).values())
        if total_m > 0:
            derived_edge_total = round(total_m * float((sell or {}).get('edgeBandPricePerM') or EDGE_BAND_PRICE_PER_M), 2)
    except Exception:
        pass
    try:
        total_sheets_guess = 0
        for m in mats_used:
            if isinstance(m, dict):
                total_sheets_guess += int(float(m.get('sheetCount') or 0) or 0)
        if total_sheets_guess <= 0 and len(mats_used) == 1:
            total_sheets_guess = 1
        if total_sheets_guess > 0:
            derived_cnc_total = round(total_sheets_guess * float((sell or {}).get('cncCostPerSheet') or CNC_COST_PER_SHEET), 2)
    except Exception:
        pass
    try:
        derived_drawing_total = round(float((sell or {}).get('drawingCostFixed') or DRAWING_COST_FIXED), 2)
    except Exception:
        pass
    try:
        derived_transport_total = round(float((sell or {}).get('transportCostFixed') or TRANSPORT_COST_FIXED), 2)
    except Exception:
        pass

    # Always let the live/quote-derived component values win for the final human summary.
    # This prevents stale request payload summaries from leaking old transport/factor values.
    if derived_materials_total is not None:
        summary['materialsTotal'] = derived_materials_total
    if derived_edge_total is not None:
        summary['edgeBandTotal'] = derived_edge_total
    if derived_cnc_total is not None:
        summary['cncTotal'] = derived_cnc_total
    if derived_drawing_total is not None:
        summary['drawingTotal'] = derived_drawing_total
    if derived_transport_total is not None:
        summary['transportTotal'] = derived_transport_total

    subtotal_ex = 0.0
    for key in ('materialsTotal','edgeBandTotal','cncTotal','drawingTotal','transportTotal'):
        try:
            subtotal_ex += float(summary.get(key) or 0.0)
        except Exception:
            pass
    subtotal_ex = round(subtotal_ex, 2) if subtotal_ex > 0 else 0.0
    if subtotal_ex:
        summary['subtotalExVat'] = subtotal_ex
    total_inc = round(subtotal_ex * 1.21, 2) if subtotal_ex else 0.0
    if total_inc:
        summary['totalInclVat'] = total_inc
    vat_amt = round(total_inc - subtotal_ex, 2) if total_inc and subtotal_ex else 0.0
    if vat_amt:
        summary['vatAmount'] = vat_amt

    lines = []
    lines.append("METOD One-Click – Berekeningsoverzicht")
    lines.append("=" * 40)
    lines.append(f"Job: {jid}")
    lines.append("")
    lines.extend(_customer_block_from_sources(request_status, request_payload))

    lines.append("Configuratie")
    lines.append("-" * 40)
    if not panel_qty_total and isinstance(request_payload, dict):
        try:
            panel_qty_total = len(request_payload.get('cart') or []) + len(request_payload.get('extraPanels') or [])
        except Exception:
            panel_qty_total = 0
    if panel_qty_total:
        lines.append(f"Aantal panelen: {panel_qty_total}")
    total_sheets = 0
    if mats_used:
        for m in mats_used:
            if isinstance(m, dict):
                try:
                    total_sheets += int(m.get('sheetCount') or m.get('plates') or 0)
                except Exception:
                    pass
    if total_sheets:
        lines.append(f"Aantal platen: {total_sheets}")
    lines.append("")

    lines.append("Materialen / platen")
    lines.append("-" * 40)
    lines.append(f"Opslagfactor plaatmateriaal: x{spf:.2f} (alleen materiaal, niet kantenband/overig)")
    lines.append("")
    if mats_used:
        for m in mats_used:
            if not isinstance(m, dict):
                continue
            code = str(m.get("materialCode") or m.get('code') or "")
            meta = mat_meta.get(code, {})
            name = meta.get("productName") or m.get('productName') or m.get('materialDisplayName') or m.get('decorName') or m.get('name') or ''
            art = meta.get("articleNumber") or code
            th = m.get("thicknessMm") or meta.get("thicknessMm") or ""
            cnt = int(m.get("sheetCount") or m.get('plates') or 0)
            ss = m.get("sheetSizeMm") or meta.get("sheetSizeMm") or {}
            sw = ss.get("width") or ss.get("Width") or ""
            sh = ss.get("height") or ss.get("Height") or ""
            size_str = f"{int(sw)}×{int(sh)} mm" if sw and sh else ""
            lines.append(f"- {name} (artikel: {art})")
            detail = f"  Dikte: {th} mm | Platen: {cnt}"
            if size_str:
                detail += f" | Plaatmaat: {size_str}"
            lines.append(detail)
            unit_raw = m.get("sheetUnitCostRaw")
            cost_raw = m.get("sheetCostTotalRaw")
            if unit_raw is None:
                unit_raw = meta.get("purchasePricePerSheet") or meta.get("purchasePrice")
            if unit_raw is None:
                try:
                    _fallback_total = float(m.get("sheetCostTotal") or 0.0)
                    unit_raw = (_fallback_total / cnt) if cnt else None
                except Exception:
                    unit_raw = None
            try:
                unit_raw = float(unit_raw) if unit_raw is not None else None
            except Exception:
                unit_raw = None
            if cost_raw is None and unit_raw is not None and cnt:
                try:
                    cost_raw = round(float(unit_raw) * float(cnt), 2)
                except Exception:
                    cost_raw = None
            # IMPORTANT: the human-readable summary must always show verkoop values derived from
            # the active sell pricing factor, not blindly echo a possibly raw sheetUnitCost coming
            # from Tool B/raw quote payloads. This keeps the per-sheet verkoop rows aligned with the
            # final component total shown under Kostenopbouw > Plaatmateriaal.
            unit_sell = None
            cost_sell = None
            if unit_raw is not None:
                try:
                    unit_sell = round(float(unit_raw) * float(spf) + 1e-9, 2)
                except Exception:
                    unit_sell = None
            if unit_sell is not None and cnt:
                try:
                    cost_sell = round(float(unit_sell) * float(cnt) + 1e-9, 2)
                except Exception:
                    cost_sell = None
            if unit_raw is not None:
                if unit_sell is not None:
                    lines.append(f"  Plaatprijs inkoop: {_format_eur(unit_raw)} p/st | verkoop: {_format_eur(unit_sell)} p/st")
                else:
                    lines.append(f"  Plaatprijs inkoop: {_format_eur(unit_raw)} p/st")
            if cost_raw is not None:
                if cost_sell is not None:
                    lines.append(f"  Subtotaal inkoop: {_format_eur(cost_raw)} | verkoop: {_format_eur(cost_sell)}")
                else:
                    lines.append(f"  Subtotaal inkoop: {_format_eur(cost_raw)}")
            lines.append("")
    else:
        mats_payload = request_payload.get('materialsSummary') if isinstance(request_payload, dict) and isinstance(request_payload.get('materialsSummary'), list) else []
        if mats_payload:
            for m in mats_payload:
                if not isinstance(m, dict):
                    continue
                code = str(m.get('code') or m.get('articleNumber') or m.get('materialCode') or '').strip()
                name = _best_material_name(code, m.get('materialDisplayName'), m.get('materialName'), m.get('name'), m.get('productName'), m.get('decorName'))
                cnt = m.get('plates') or ''
                lines.append(f"- {name or code} (artikel: {code})")
                if cnt:
                    lines.append(f"  Platen: {cnt}")
                lines.append("")
        else:
            lines.append("(geen materialen gevonden in quote.json)")
            lines.append("")

    lines.append("Kantenband (m¹) per decor")
    lines.append("-" * 40)
    if per_mat_meters:
        for code, mtrs in sorted(per_mat_meters.items(), key=lambda kv: kv[0]):
            meta = mat_meta.get(code, {})
            name = meta.get("productName") or _best_material_name(code, '')
            art = meta.get("articleNumber") or code
            label = f"{name} (artikel: {art})" if name else f"Artikel: {art}"
            lines.append(f"- {label}: {_format_m(mtrs)}")
        lines.append("")
        total_m = sum(per_mat_meters.values())
        try:
            edge_price_live = float((sell or {}).get('edgeBandPricePerM') or EDGE_BAND_PRICE_PER_M)
        except Exception:
            edge_price_live = EDGE_BAND_PRICE_PER_M
        lines.append(f"Totaal kantenband: {_format_m(total_m)}")
        lines.append(f"Prijs kantenband: {_format_eur(edge_price_live)} per meter")
        lines.append("")
    else:
        lines.append("(geen kantenband gevonden)")
        lines.append("")

    lines.append("Kostenopbouw (excl. btw)")
    lines.append("-" * 40)
    known_costs = 0.0
    if summary.get('materialsTotal') is not None:
        lines.append(f"Plaatmateriaal: {_format_eur(summary['materialsTotal'])}")
        known_costs += float(summary['materialsTotal'] or 0.0)
    if summary.get('edgeBandTotal') is not None:
        lines.append(f"Kantenband:     {_format_eur(summary['edgeBandTotal'])}")
        known_costs += float(summary['edgeBandTotal'] or 0.0)
    if summary.get('cncTotal') is not None:
        lines.append(f"CNC:            {_format_eur(summary['cncTotal'])}")
        known_costs += float(summary['cncTotal'] or 0.0)
    if summary.get('drawingTotal') is not None:
        lines.append(f"Tekenen:        {_format_eur(summary['drawingTotal'])}")
        known_costs += float(summary['drawingTotal'] or 0.0)
    if summary.get('transportTotal') is not None:
        lines.append(f"Transport:      {_format_eur(summary['transportTotal'])}")
        known_costs += float(summary['transportTotal'] or 0.0)
    residual = None
    try:
        residual = round(float(subtotal_ex) - known_costs, 2)
    except Exception:
        residual = None
    if residual is not None and abs(residual) >= 0.01:
        lines.append(f"Overig/niet gespecificeerd: {_format_eur(residual)}")
    lines.append("")
    lines.append(f"Subtotaal excl. btw: {_format_eur(subtotal_ex)}")
    lines.append(f"BTW (21%):          {_format_eur(vat_amt)}")
    lines.append(f"Totaal incl. btw:    {_format_eur(total_inc)}")
    lines.append("")

    out_txt = "\n".join(lines).strip() + "\n"
    try:
        output_dir.mkdir(parents=True, exist_ok=True)
        (output_dir / "calculation_summary.txt").write_text(out_txt, encoding="utf-8")
    except Exception:
        pass
    try:
        input_dir.mkdir(parents=True, exist_ok=True)
        (input_dir / "calculation_summary.txt").write_text(out_txt, encoding="utf-8")
    except Exception:
        pass

def _parse_panels_csv(text: str) -> list[dict]:
    '''
    Parse Tool A panels.csv (semicolon-delimited) into list of dict rows.
    '''
    text = (text or "").strip()
    if not text:
        return []
    f = io.StringIO(text)
    reader = csv.DictReader(f, delimiter=';')
    return [r for r in reader]



def _is_subjob(job_id: str) -> bool:
    return "__mat_" in (job_id or "")

def _sanitize_key(s: str) -> str:
    s = str(s or "").strip()
    # keep alnum, dash, underscore; replace others with underscore
    return re.sub(r'[^A-Za-z0-9_\-]+', '_', s) or "mat"

def _filter_panels_csv_by_material(panels_csv: str, material_code: str) -> str:
    """Return panels.csv containing only rows whose MaterialCode matches material_code."""
    panels_csv = panels_csv or ""
    lines = [ln for ln in panels_csv.splitlines() if ln.strip()]
    if not lines:
        return panels_csv
    header = lines[0]
    rows = _parse_panels_csv(panels_csv)
    filt = [r for r in rows if str(r.get("MaterialCode") or "").strip() == str(material_code).strip()]
    out = io.StringIO()
    out.write(header.strip() + "\n")
    if filt:
        writer = csv.DictWriter(out, fieldnames=header.split(';'), delimiter=';', lineterminator='\n')
        for r in filt:
            # DictWriter writes header only if writeheader() called; we already wrote it
            writer.writerow({k: r.get(k, "") for k in header.split(';')})
    return out.getvalue()

def _parts_for_panels_rows(rows: list[dict]) -> set[str]:
    part_ids = set()
    for r in rows:
        pid = str(r.get("PartId") or r.get("PartID") or r.get("partId") or "").strip()
        if pid:
            part_ids.add(pid)
    return part_ids

def _merge_raw_quotes(quotes: list[dict], master_job_id: str) -> dict:
    """Merge Tool B raw quote.json objects into one raw quote (purchase-cost model)."""
    out = {
        "jobId": master_job_id,
        "currency": "EUR",
        "settings": {},
        "materials": [],
        "edgeBanding": {
            "defaultLossPercent": 0.0,
            "byCodeMeters": {},
            "byCodeMetersWithLoss": {},
            "byCodeCost": {},
            "edgeCostTotal": 0.0,
        },
        "totals": {"sheetCostTotal": 0.0, "edgeCostTotal": 0.0, "grandTotal": 0.0},
        "outputs": {},
    }
    mats_acc = {}
    loss = 0.0
    by_m = {}
    by_m_loss = {}
    for q in quotes:
        if not isinstance(q, dict):
            continue
        out["currency"] = q.get("currency") or out["currency"]
        if isinstance(q.get("settings"), dict) and not out["settings"]:
            out["settings"] = dict(q["settings"])
        edge = q.get("edgeBanding") if isinstance(q.get("edgeBanding"), dict) else {}
        try:
            loss = float(edge.get("defaultLossPercent") or loss or 0.0)
        except Exception:
            pass
        # materials
        for m in q.get("materials") or []:
            if not isinstance(m, dict):
                continue
            key = (str(m.get("materialCode") or ""), float(m.get("thicknessMm") or 0.0))
            prev = mats_acc.get(key)
            if prev is None:
                mats_acc[key] = json.loads(json.dumps(m))
            else:
                prev["sheetCount"] = int(prev.get("sheetCount") or 0) + int(m.get("sheetCount") or 0)
                # recompute totals
                unit = float(prev.get("sheetUnitCost") or 0.0)
                prev["sheetCostTotal"] = round(unit * int(prev["sheetCount"]), 2)
        # edge meters
        bcm = edge.get("byCodeMeters") if isinstance(edge.get("byCodeMeters"), dict) else {}
        for k,v in bcm.items():
            try:
                by_m[str(k)] = by_m.get(str(k), 0.0) + float(v)
            except Exception:
                pass
        bcm2 = edge.get("byCodeMetersWithLoss") if isinstance(edge.get("byCodeMetersWithLoss"), dict) else {}
        for k,v in bcm2.items():
            try:
                by_m_loss[str(k)] = by_m_loss.get(str(k), 0.0) + float(v)
            except Exception:
                pass
        # totals
        tot = q.get("totals") if isinstance(q.get("totals"), dict) else {}
        for tk in ["sheetCostTotal","edgeCostTotal","grandTotal"]:
            try:
                out["totals"][tk] = round(float(out["totals"].get(tk) or 0.0) + float(tot.get(tk) or 0.0), 2)
            except Exception:
                pass

    out["materials"] = list(mats_acc.values())
    out["edgeBanding"]["defaultLossPercent"] = loss
    out["edgeBanding"]["byCodeMeters"] = {k: round(v,3) for k,v in by_m.items()}
    out["edgeBanding"]["byCodeMetersWithLoss"] = {k: round(v,3) for k,v in by_m_loss.items()}
    # costs by code (purchase) - sum if present
    for q in quotes:
        edge = q.get("edgeBanding") if isinstance(q, dict) and isinstance(q.get("edgeBanding"), dict) else {}
        bcc = edge.get("byCodeCost") if isinstance(edge.get("byCodeCost"), dict) else {}
        for k,v in bcc.items():
            try:
                out["edgeBanding"]["byCodeCost"][str(k)] = round(float(out["edgeBanding"]["byCodeCost"].get(str(k)) or 0.0) + float(v), 2)
            except Exception:
                pass
    out["edgeBanding"]["edgeCostTotal"] = out["totals"]["edgeCostTotal"]
    out["outputs"] = {"subjobs": True}
    return out

def _edge_name_from_code(pricing: dict, code_val) -> str:
    try:
        if code_val is None:
            return ""
        s = str(code_val).strip()
        if s == "" or s.lower() in ("0", "none", "null", "undefined"):
            return ""
        code = int(float(s))
        if code <= 0:
            return ""
        codes = (((pricing or {}).get("edgeBanding") or {}).get("codes") or [])
        for c in codes:
            try:
                if int(c.get("code")) == code:
                    return str(c.get("name") or "").strip()
            except Exception:
                continue
        return ""
    except Exception:
        return ""


def _guess_sheet_dxf_file(sheets_dir: Path, sheet_index: int) -> Optional[str]:
    '''Return filename like Sheet_001.dxf or <mat>_Sheet_001.dxf if found.'''
    if not sheets_dir.exists():
        return None
    token = f"Sheet_{sheet_index:03d}".lower()
    matches = [p.name for p in sheets_dir.glob("*.dxf") if token in p.name.lower()]
    return sorted(matches)[0] if matches else None


def _generate_labels_json(job_root: Path) -> None:
    '''
    Create output/labels.json by merging:
      - input/panels.csv
      - input/pricing.json (edgeBanding code->name)
      - output/placements.json
    '''
    input_dir = job_root / "input"
    output_dir = job_root / "output"
    panels_path = input_dir / "panels.csv"
    pricing_path = input_dir / "pricing.json"
    placements_path = _find_placements_any(output_dir) or (output_dir / "placements.json")
    if not (panels_path.exists() and pricing_path.exists() and placements_path and placements_path.exists()):
        return

    panels_rows = _parse_panels_csv(panels_path.read_text(encoding="utf-8"))
    pricing = json.loads(pricing_path.read_text(encoding="utf-8"))
    placements = json.loads(placements_path.read_text(encoding="utf-8"))

    job_json = {}
    job_json_path = input_dir / "job.json"
    if job_json_path.exists():
        try:
            job_json = json.loads(job_json_path.read_text(encoding="utf-8"))
        except Exception:
            job_json = {}

    by_part: dict[str, dict] = {}
    for r in panels_rows:
        pid = str(r.get("PartId") or "").strip()
        if pid:
            by_part[pid] = r

    sheets_out = []
    labels_out = []

    sheets_dir = output_dir / "sheets"
    job_id = placements.get("jobId", job_root.name)

    for sh in (placements.get("sheets") or []):
        si = int(sh.get("sheetIndex", 0))
        sheet_id = f"sheet_{si:03d}"
        sheet_size = sh.get("sheetSizeMm") or {}
        dxf_name = _guess_sheet_dxf_file(sheets_dir, si)

        sheets_out.append({
            "sheet_id": sheet_id,
            "dxf_file": (f"sheets/{dxf_name}" if dxf_name else ""),
            "width_mm": float(sheet_size.get("width") or sheet_size.get("w") or 0),
            "height_mm": float(sheet_size.get("height") or sheet_size.get("h") or 0),
            "margin_mm": float(sh.get("marginMm") or 0),
            "gap_mm": float(sh.get("gapMm") or 0),
            "material_code": str(sh.get("materialCode") or ""),
            "thickness_mm": float(sh.get("thicknessMm") or 0),
        })

        for pl in (sh.get("placements") or []):
            part_id = str(pl.get("partId") or "").strip()
            inst = int(pl.get("instanceIndex") or 1)
            x = float(pl.get("x") or 0)
            y = float(pl.get("y") or 0)
            rot = int(pl.get("rotDeg") or 0)

            pr = by_part.get(part_id, {})
            panel_name = str(pr.get("PanelName") or pl.get("panelName") or "")
            material_name = str(pr.get("DecorName") or "")
            material_code = str(pr.get("MaterialCode") or sh.get("materialCode") or "")
            order_number = str(pr.get("OrderNumber") or "")
            customer_name = ""

            length_mm = float(pr.get("LengthMm") or 0)
            width_mm = float(pr.get("WidthMm") or 0)
            thickness_mm = float(pr.get("ThicknessMm") or sh.get("thicknessMm") or 0)

            w_eff = width_mm
            h_eff = length_mm
            if rot % 180 != 0:
                w_eff, h_eff = h_eff, w_eff
            bbox = [x, y, x + w_eff, y + h_eff]

            edge_h1 = _edge_name_from_code(pricing, pr.get("H1"))
            edge_h2 = _edge_name_from_code(pricing, pr.get("H2"))
            edge_w1 = _edge_name_from_code(pricing, pr.get("W1"))
            edge_w2 = _edge_name_from_code(pricing, pr.get("W2"))

            label_id = f"{part_id}-{inst}"
            barcode_value = f"http://{PUBLIC_HOST}:{PORT}/m/{job_id}/{label_id}"

            labels_out.append({
                "label_id": label_id,
                "panel_id": part_id,
                "instance": inst,
                "qty_total": int(float(pr.get("Qty") or 1)) if str(pr.get("Qty") or "").strip() else 1,

                "order_number": order_number,
                "customer_name": customer_name,

                "panel_name": panel_name,
                "material_code": material_code,
                "material_name": material_name,

                "length_mm": length_mm,
                "width_mm": width_mm,
                "thickness_mm": thickness_mm,

                "edge_H1": edge_h1,
                "edge_H2": edge_h2,
                "edge_W1": edge_w1,
                "edge_W2": edge_w2,

                "barcode_type": "QR",
                "barcode_value": barcode_value,

                "placement": {
                    "sheet_id": sheet_id,
                    "origin": "bottom-left",
                    "y_axis": "up",
                    "x_mm": x,
                    "y_mm": y,
                    "bbox_mm": bbox,
                    "rotation_deg": rot,
                    "rotation_deg_cw": True,
                    "rotation_origin": "panel_center",
                }
            })

    labels_json = {
        "schema_version": 1,
        "units": "mm",
        "job_id": job_id,
        "order": {
            "order_number": (labels_out[0].get("order_number") if labels_out else ""),
            "customer_name": (labels_out[0].get("customer_name") if labels_out else ""),
        },
        "customer": (job_json.get("customer") or {}),
        "note": (job_json.get("note") or ""),
        "rest_material": {
            "carry_out": bool((job_json.get("rest_material") or {}).get("carry_out")) if (job_json.get("rest_material") is not None) else False,
            "label_text": ("Restmateriaal: JA" if bool((job_json.get("rest_material") or {}).get("carry_out")) else "Restmateriaal: NEE")
        },
        "sheets": sheets_out,
        "labels": labels_out,
    }

    (output_dir / "labels.json").write_text(json.dumps(labels_json, indent=2), encoding="utf-8")


def _customer_name_from_job(job_json: dict) -> str:
    """Return a display-friendly customer name. Must always return a non-empty string."""
    try:
        cust = (job_json or {}).get("customer") or {}
        if isinstance(cust, dict):
            # Support both camelCase and snake_case keys.
            first = str(cust.get("firstName") or cust.get("first_name") or "").strip()
            last = str(cust.get("lastName") or cust.get("last_name") or "").strip()
            company = str(cust.get("company") or "").strip()
            name = (f"{first} {last}".strip())
            if name:
                return name
            if company:
                return company
    except Exception:
        pass
    return "Onbekend"


def _material_name_and_thickness(pricing: dict, material_code: str) -> tuple[str, float]:
    """Lookup the human material/decor name + thickness for a material code.

    IMPORTANT for StickerTool/admin exports:
    - materialCode must remain the article number/code.
    - materialDisplayName must be the human decor/product label, never the code just
      because a pricing row duplicated materialCode into decorName.
    """
    code = str(material_code or "").strip()
    try:
        mats = (pricing or {}).get("materials") or []
        for m in mats:
            if str(m.get("materialCode") or m.get("code") or m.get("articleNumber") or "").strip() == code:
                name = _best_material_name(
                    code,
                    m.get("materialDisplayName"),
                    m.get("materialName"),
                    m.get("name"),
                    m.get("productName"),
                    m.get("decorName"),
                )
                t = float(m.get("thicknessMm") or 0.0)
                return (name or code or "Onbekend"), t
    except Exception:
        pass
    return (_best_material_name(code, "") or code or "Onbekend"), 0.0


def _resolve_stickertool_material_display_name(material_code: str, job_json: dict, panels_rows: list[dict], pricing_obj: dict) -> str:
    """Resolve the StickerTool materialDisplayName from the richest available order data.

    This intentionally prefers order/catalog human labels over the subjob/material code.
    The bug fixed in FIX591 was that StickerTool could output:
      materialCode: "100817-1", materialDisplayName: "100817-1"
    while the expected display name is the decor/product name, e.g. "DecoLegno LS14 ...".
    """
    code = str(material_code or "").strip()

    def _code_of(rec: dict) -> str:
        return str(
            rec.get("materialCode") or rec.get("MaterialCode") or
            rec.get("code") or rec.get("articleNumber") or rec.get("articleNo") or
            rec.get("materialKey") or rec.get("ArticleNumber") or ""
        ).strip()

    def _name_of(rec: dict) -> str:
        return _best_material_name(
            code,
            rec.get("materialDisplayName"), rec.get("MaterialDisplayName"),
            rec.get("materialName"), rec.get("MaterialName"),
            rec.get("name"), rec.get("Name"),
            rec.get("productName"), rec.get("ProductName"),
            rec.get("decorName"), rec.get("DecorName"),
        )

    def _consider(rec: dict) -> str:
        if not isinstance(rec, dict):
            return ""
        rc = _code_of(rec)
        if code and rc and rc != code:
            return ""
        nm = _name_of(rec)
        # Do not accept the article number itself as display name when richer fallbacks may exist.
        if nm and (not code or nm != code):
            return nm
        return ""

    # 1) User/order payload sources are most accurate for custom/selected decor labels.
    try:
        if isinstance(job_json, dict):
            for key in ("materialsSummary", "materials", "materialBatches", "cart", "panels", "extraPanels"):
                arr = job_json.get(key)
                if isinstance(arr, list):
                    for rec in arr:
                        nm = _consider(rec)
                        if nm:
                            return nm
            quote = job_json.get("quote") if isinstance(job_json.get("quote"), dict) else {}
            q_mats = quote.get("materials") if isinstance(quote.get("materials"), list) else []
            for rec in q_mats:
                nm = _consider(rec)
                if nm:
                    return nm
    except Exception:
        pass

    # 2) panels.csv can carry DecorName/ProductName from Tool A.
    try:
        for rec in panels_rows or []:
            nm = _consider(rec)
            if nm:
                return nm
    except Exception:
        pass

    # 3) pricing.json generated by Tool B/admin.
    try:
        mats = (pricing_obj or {}).get("materials") or []
        if isinstance(mats, list):
            for rec in mats:
                nm = _consider(rec)
                if nm:
                    return nm
    except Exception:
        pass

    # 4) Embedded material library fallback.
    try:
        lib = json.loads((ROOT / "material_library.json").read_text(encoding="utf-8"))
        recs = lib.get("records") if isinstance(lib, dict) else lib
        if isinstance(recs, list):
            for rec in recs:
                nm = _consider(rec)
                if nm:
                    return nm
    except Exception:
        pass

    return _best_material_name(code, "") or code or "Onbekend"


def _generate_stickertool_json(job_root: Path) -> Path:
    """Generate StickerTool v2.x contract JSON.

    HARD CONTRACT (per user spec):
      jobs/<jobId>/subjobs/<subjobId>/output/stickers.json

    In practice the platform's Admin and local browsing workflow operate on the *subjob folder*:
      jobs/<subjobId>/output/

    Therefore we write:
      - Canonical contract: jobs/<jobId>/subjobs/<subjobId>/output/stickers.json
      - Mirror:            jobs/<subjobId>/output/stickers.json
      - Admin alias:       jobs/<subjobId>/output/stickertool.json

    All writes are atomic to prevent 0-byte downloads if a user clicks while we are writing.
    """

    def _atomic_write_text(path: Path, text: str):
        """Write text atomically to avoid partial/empty reads during downloads."""
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_name(path.name + '.tmp')
        tmp.write_text(text, encoding='utf-8')
        try:
            with tmp.open('rb') as f:
                os.fsync(f.fileno())
        except Exception:
            pass
        tmp.replace(path)

    output_dir = job_root / "output"
    input_dir = job_root / "input"
    output_dir.mkdir(parents=True, exist_ok=True)

    # --- resolve jobId/subjobId/materialCode ---
    subjob_id = job_root.name
    base_job_id = subjob_id
    material_code = ""
    m = re.match(r"^(?P<base>.+)__mat_(?P<mat>.+)$", subjob_id)
    if m:
        base_job_id = m.group('base')
        material_code = m.group('mat')

    # --- load job.json for customer/order info ---
    job_json = {}
    job_json_path = input_dir / "job.json"
    if job_json_path.exists():
        try:
            job_json = json.loads(job_json_path.read_text(encoding='utf-8') or "{}")
        except Exception:
            job_json = {}

    customer_name = _customer_name_from_job(job_json)
    order_number = str((job_json.get('order') or {}).get('orderNumber') or (job_json.get('order') or {}).get('order_number') or "").strip()

    # --- load placements.json ---
    placements_path = output_dir / "placements.json"
    placements_obj = {}
    if placements_path.exists():
        try:
            placements_obj = json.loads(placements_path.read_text(encoding='utf-8') or "{}")
        except Exception:
            placements_obj = {}

    placements_list = []
    if isinstance(placements_obj, dict):
        placements_list = placements_obj.get('placements') or []
    elif isinstance(placements_obj, list):
        placements_list = placements_obj
    else:
        placements_list = []

    # infer material_code if missing
    if not material_code:
        try:
            mats = sorted({str(p.get('materialCode') or '').strip() for p in placements_list if isinstance(p, dict) and str(p.get('materialCode') or '').strip()})
            if len(mats) == 1:
                material_code = mats[0]
        except Exception:
            pass

    # --- load panels.csv (output or input) ---
    panels_rows: list[dict] = []
    for cand in [output_dir / 'panels.csv', input_dir / 'panels.csv']:
        if cand.exists():
            try:
                panels_rows = _parse_panels_csv(cand.read_text(encoding='utf-8'))
                if panels_rows:
                    break
            except Exception:
                continue

    panels_by_part: dict[str, dict] = {}
    for r in panels_rows:
        if not isinstance(r, dict):
            continue
        pid = str(r.get('PartId') or r.get('PartID') or r.get('partId') or r.get('ID') or '').strip()
        if pid and pid not in panels_by_part:
            panels_by_part[pid] = r

    # --- material display name + thickness ---
    # FIX591: materialCode remains the article number/code; materialDisplayName must be
    # the human decor/product label from the order/catalog/pricing, not the code again.
    material_display_name = material_code or "Onbekend"
    thickness_mm = None
    pricing_obj = {}
    try:
        pricing_path = output_dir / 'pricing.json'
        if pricing_path.exists():
            pricing_obj = json.loads(pricing_path.read_text(encoding='utf-8') or "{}")
        if material_code:
            nm, th = _material_name_and_thickness(pricing_obj, material_code)
            if nm:
                material_display_name = nm
            if th:
                thickness_mm = th
    except Exception:
        pass
    try:
        resolved_name = _resolve_stickertool_material_display_name(material_code, job_json, panels_rows, pricing_obj)
        if resolved_name:
            material_display_name = resolved_name
    except Exception:
        pass

    def _as_int(v, default=None):
        try:
            if v is None or v == '':
                return default
            return int(round(float(str(v).replace(',', '.'))))
        except Exception:
            return default

    def _rotation_0_90(rot_deg) -> int:
        r = _as_int(rot_deg, 0) or 0
        r = r % 360
        if r in (0, 180):
            return 0
        if r in (90, 270):
            return 90
        raise ValueError(f"Invalid rotation_deg (must be 0/90/180/270): {rot_deg}")

    # --- sheet size (placements meta first) ---
    sheet_w = None
    sheet_h = None
    try:
        meta_sheets = (placements_obj.get('sheets') or []) if isinstance(placements_obj, dict) else []
        pick = None
        for s in meta_sheets:
            if not isinstance(s, dict):
                continue
            if material_code and str(s.get('materialCode') or '').strip() != material_code:
                continue
            pick = s
            break
        if pick is None and meta_sheets:
            pick = meta_sheets[0]
        if isinstance(pick, dict):
            ss = pick.get('sheetSizeMm') or {}
            sheet_w = _as_int((ss or {}).get('width'))
            sheet_h = _as_int((ss or {}).get('height'))
            if thickness_mm is None:
                thickness_mm = _as_int(pick.get('thicknessMm'))
    except Exception:
        pass

    # last resort: material_library.json
    if (not sheet_w) or (not sheet_h):
        try:
            lib = json.loads((ROOT / 'material_library.json').read_text(encoding='utf-8'))
            mats = lib.get('materials') if isinstance(lib, dict) else None
            if isinstance(mats, list) and material_code:
                hit = next((m for m in mats if str(m.get('articleNumber') or '').strip() == material_code), None)
                if isinstance(hit, dict):
                    ss = hit.get('sheetSizeMm') or hit.get('sheetSize') or {}
                    sheet_w = sheet_w or _as_int(ss.get('width') or ss.get('w'))
                    sheet_h = sheet_h or _as_int(ss.get('height') or ss.get('h'))
                    if thickness_mm is None:
                        thickness_mm = _as_int(hit.get('thicknessMm') or hit.get('thickness'))
                    if material_display_name == (material_code or "Onbekend"):
                        material_display_name = str(hit.get('productName') or hit.get('decorName') or material_display_name)
        except Exception:
            pass

    if not sheet_w:
        sheet_w = 2070
    if not sheet_h:
        sheet_h = 2800

    max_sheet_index = 1
    try:
        if placements_list:
            max_sheet_index = max(int(p.get('sheetIndex') or 1) for p in placements_list if isinstance(p, dict))
    except Exception:
        max_sheet_index = 1

    sheets_out = [
        {"sheetId": f"S{si:02d}", "width": int(sheet_w), "height": int(sheet_h)}
        for si in range(1, max_sheet_index + 1)
    ]

    # --- items ---
    items_out: list[dict] = []
    seen_part_ids: set[str] = set()

    for p in placements_list:
        if not isinstance(p, dict):
            continue
        pid_base = str(p.get('partId') or p.get('PartId') or '').strip()
        if not pid_base:
            continue
        inst = str(p.get('instanceIndex') if p.get('instanceIndex') is not None else '').strip()
        part_id = f"{pid_base}__{inst}" if inst else pid_base
        if part_id in seen_part_ids:
            k = 2
            while f"{part_id}__{k}" in seen_part_ids:
                k += 1
            part_id = f"{part_id}__{k}"
        seen_part_ids.add(part_id)

        row = panels_by_part.get(pid_base) or {}
        display_name = str(
            row.get('PanelName') or row.get('panelName') or
            row.get('Label') or row.get('label') or
            row.get('Name') or row.get('name') or
            pid_base
        ).strip() or pid_base
        display_name = (
            display_name
            .replace('Ã—', '×')
            .replace('â€“', '–')
            .replace('â€”', '—')
            .replace('Ã©', 'é')
            .replace('Ã‰', 'É')
            .replace('Ã¶', 'ö')
            .replace('Ã–', 'Ö')
        )

        part_mm = p.get('part_mm') or {}
        w = _as_int(part_mm.get('width_mm') or row.get('WidthMM') or row.get('Width') or row.get('width'))
        h = _as_int(part_mm.get('length_mm') or row.get('LengthMM') or row.get('HeightMM') or row.get('Height') or row.get('height'))
        t = _as_int(p.get('thicknessMm') or row.get('ThicknessMM') or row.get('Thickness') or row.get('thickness') or thickness_mm)
        if not w or not h or not t:
            continue

        rot = _rotation_0_90(p.get('rotation_deg') or p.get('rotationDeg') or p.get('rot') or 0)
        bbox_mm = p.get('bbox_mm') or {}
        bw = _as_int(bbox_mm.get('w_mm') or bbox_mm.get('w') or w)
        bh = _as_int(bbox_mm.get('h_mm') or bbox_mm.get('h') or h)
        if not bw or not bh:
            continue

        x = float(p.get('x_mm') or p.get('x') or 0.0)
        y = float(p.get('y_mm') or p.get('y') or 0.0)

        # placements.json uses origin bottom-left, y up.
        # Stickertool expects origin top-left, y down.
        x1 = x
        y1 = float(sheet_h) - (y + float(bh))
        x2 = x1 + float(bw)
        y2 = y1 + float(bh)
        if x1 < 0 or y1 < 0 or x2 <= x1 or y2 <= y1:
            continue

        sheet_index = int(p.get('sheetIndex') or 1)
        sheet_id = f"S{sheet_index:02d}"

        grain = str(row.get('Grain') or row.get('grain') or row.get('Nerf') or '').strip().lower()
        if grain not in ('vertical', 'horizontal'):
            grain = 'vertical'

        edges = p.get('edges') or {}
        edge_banding = {
            "top": bool(edges.get('H1')),
            "right": bool(edges.get('W2')),
            "bottom": bool(edges.get('H2')),
            "left": bool(edges.get('W1')),
        }

        items_out.append({
            "partId": part_id,
            "displayName": display_name,
            "qty": 1,
            "width": int(w),
            "height": int(h),
            "thickness": int(t),
            "grain": grain,
            "placement": {
                "sheetId": sheet_id,
                "bbox": [int(round(x1)), int(round(y1)), int(round(x2)), int(round(y2))],
                "rotation": int(rot),
            },
            "edgeBanding": {k: bool(v) for k, v in edge_banding.items() if bool(v)},
        })

    items_out.sort(key=lambda it: (str(it.get('displayName') or ''), str(it.get('partId') or '')))

    carry_out = bool((job_json.get("rest_material") or {}).get("carry_out")) if isinstance(job_json, dict) else False
    payload = {
        "schemaVersion": "2.0",
        "jobId": base_job_id,
        "subjobId": subjob_id,
        "customerName": customer_name,
        "materialCode": material_code or "",
        "materialDisplayName": material_display_name,
        "generatedAt": datetime.utcnow().isoformat() + "Z",
        "optimizerVersionId": f"{OPTIMIZER_TOOL_B}::{__STICKERTOOL_V2_BUILD}",
        "restMaterial": {
            "carryOut": carry_out,
            "labelText": ("Restmateriaal: JA" if carry_out else "Restmateriaal: NEE")
        },
        "sheets": sheets_out,
        "items": items_out,
    }
    if order_number:
        payload["orderNumber"] = order_number

    # --- write to contract path (canonical) ---
    contract_out = JOBS / base_job_id / "subjobs" / subjob_id / "output"
    contract_path = contract_out / "stickers.json"
    data_text = json.dumps(payload, ensure_ascii=False, indent=2)
    _atomic_write_text(contract_path, data_text)

    # --- convenience mirror ---
    # Existing local workflows frequently browse the subjob folder itself:
    #   jobs/<subjobId>/output/
    # To avoid confusion while keeping Admin on the canonical contract path, we mirror the SAME
    # stickers.json into the subjob output folder as well.
    # This does NOT create duplicate Admin buttons because Admin only links to the canonical route.
    try:
        mirror_path = (JOBS / subjob_id / 'output' / 'stickers.json')
        _atomic_write_text(mirror_path, data_text)
        # Admin alias (single download button)
        alias_path = (JOBS / subjob_id / 'output' / 'stickertool.json')
        _atomic_write_text(alias_path, data_text)

    except Exception:
        pass

    # NOTE: Admin downloads v2 from the contract path via /api/jobs/<jobId>/subjobs/<subjobId>/file/...
    return contract_path

def _rename_sheet_dxfs(job_root: Path):
    """Rename output sheet DXFs to include jobId, customer name and material.
    Format: <jobId>__<customer>__<material>__S<nn>.dxf
    """
    input_dir = job_root / "input"
    output_dir = job_root / "output"
    placements_path = output_dir / "placements.json"
    if not placements_path.exists():
        return
    try:
        placements = json.loads(placements_path.read_text(encoding="utf-8"))
    except Exception:
        with _SSE_CLIENTS_LOCK:
            try:
                _SSE_CLIENTS.remove(q)
            except ValueError:
                pass
        return

    job_json = {}
    job_json_path = input_dir / "job.json"
    if job_json_path.exists():
        try:
            job_json = json.loads(job_json_path.read_text(encoding="utf-8"))
        except Exception:
            job_json = {}

    job_id = str(placements.get("jobId") or job_root.name)
    customer_name = ""
    cust = (job_json.get("customer") or {})
    if isinstance(cust, dict):
        # Support both snake_case and camelCase keys
        fn = str(cust.get("first_name") or cust.get("firstName") or "").strip()
        ln = str(cust.get("last_name")  or cust.get("lastName")  or "").strip()
        customer_name = " ".join([fn, ln]).strip()
    if not customer_name:
        # fallback to older key names
        customer_name = str((job_json.get("order") or {}).get("customer_name") or "").strip()

    safe_job = _sanitize_filename(job_id, 40)
    safe_cust = _sanitize_filename(customer_name, 50)

    sheets_dir = output_dir / "sheets"
    if not sheets_dir.exists():
        return

    # If this job is a per-material subjob (panels.csv contains exactly 1 MaterialCode),
    # we can rename all sheet DXFs deterministically without relying on placements sheet metadata.
    # IMPORTANT: subjobs are contractually allowed to have ONLY job.json + panels.csv in /input.
    # So pricing.json may be absent. In that case we still include the material identity via
    # material_library.json (decor lookup) and/or the raw MaterialCode.
    single_mat_label = None
    try:
        panels_path = input_dir / "panels.csv"
        pricing_path = input_dir / "pricing.json"  # optional
        if panels_path.exists():
            _rows = _parse_panels_csv(panels_path.read_text(encoding="utf-8"))
            _codes = sorted({str(r.get("MaterialCode") or r.get("materialCode") or "").strip() for r in _rows
                             if str(r.get("MaterialCode") or r.get("materialCode") or "").strip()})
            if len(_codes) == 1:
                _code = _codes[0]
                _thick = ""
                _label_code = _code

                # If pricing.json is present (non-contract, but can exist in some builds),
                # use it to enrich thickness + decor label.
                if pricing_path.exists():
                    try:
                        _pricing = json.loads(pricing_path.read_text(encoding="utf-8"))
                        for _m in (_pricing.get("materials") or []):
                            if str(_m.get("materialCode") or "").strip() == _code:
                                _thick = _m.get("thicknessMm") or _m.get("thickness_mm") or _m.get("thickness") or ""
                                _label_code = _m.get("materialCode") or _code
                                # Prefer a human label if present; otherwise the code.
                                _human = _m.get("decorName") or _m.get("productName") or _m.get("name")
                                if _human:
                                    # _material_label_for_filename expects a code for library lookup; we pass the
                                    # material code and let the library resolve the decor when possible.
                                    _label_code = _code
                                break
                    except Exception:
                        pass

                # Always build a filename label from the (single) material code; decor is resolved via library lookup.
                single_mat_label = _material_label_for_filename(_code, _thick)
    except Exception:
        single_mat_label = None

    if single_mat_label:
        safe_mat = _sanitize_filename(single_mat_label, 80)
        files = list(sheets_dir.glob("*.dxf"))

        def _sheet_no(p: Path) -> int:
            try:
                mm = re.search(r"sheet[_\-\s]*0*([0-9]+)", p.name, flags=re.IGNORECASE)
                return int(mm.group(1)) if mm else 10**9
            except Exception:
                return 10**9

        for idx, f in enumerate(sorted(files, key=lambda p: (_sheet_no(p), p.name.lower())), start=1):
            new_name = f"{safe_cust}__{safe_mat}__S{idx:02d}.dxf"
            target = sheets_dir / new_name
            if f.name != target.name:
                if target.exists():
                    k = 2
                    while True:
                        target2 = sheets_dir / f"{safe_cust}__{safe_mat}__S{idx:02d}__{k}.dxf"
                        if not target2.exists():
                            target = target2
                            break
                        k += 1
                try:
                    f.rename(target)
                except Exception:
                    pass
        return


    # Build mapping from placements sheet entries to existing filenames
    sheets = placements.get("sheets") or []
    if not isinstance(sheets, list) or not sheets:
        # fallback: rename whatever exists without material
        for idx, f in enumerate(sorted(sheets_dir.glob("*.dxf")), start=1):
            new_name = f"{safe_cust}__S{idx:02d}.dxf"
            target = sheets_dir / new_name
            if f.name != target.name and not target.exists():
                f.rename(target)
        return

    for sh in sheets:
        try:
            sheet_idx = int(sh.get("index") or sh.get("sheetIndex") or sh.get("sheet") or 1)
        except Exception:
            sheet_idx = 1
        mat_code = sh.get("materialCode") or sh.get("material_code") or sh.get("material") or sh.get("materialName") or "Materiaal"
        thick = sh.get("thicknessMm") or sh.get("thickness_mm") or sh.get("thickness") or ""
        mat_str = _material_label_for_filename(mat_code, thick)
        safe_mat = _sanitize_filename(mat_str, 80)

        # locate source file
        src_name = sh.get("dxf") or sh.get("dxfFile") or sh.get("file") or sh.get("path")
        src_path = sheets_dir / str(src_name) if src_name else None
        if src_path and src_path.exists():
            src = src_path
        else:
            # fallback by index ordering
            candidates = sorted(sheets_dir.glob("*.dxf"))
            src = candidates[sheet_idx-1] if 0 <= sheet_idx-1 < len(candidates) else None
        if not src:
            continue

        new_name = f"{safe_cust}__{safe_mat}__S{sheet_idx:02d}.dxf"
        target = sheets_dir / new_name
        if src.name != target.name:
            # If a file with target name already exists, add suffix
            if target.exists():
                k = 2
                while True:
                    target2 = sheets_dir / f"{safe_cust}__{safe_mat}__S{sheet_idx:02d}__{k}.dxf"
                    if not target2.exists():
                        target = target2
                        break
                    k += 1
            try:
                src.rename(target)
            except Exception:
                pass

def _build_admin_dxf_exports(job_root: Path):
    """Create customer-friendly DXF export folders for Admin.

    output/DXF_Zaagplaten  -> renamed sheet DXFs (customer + decor + code + thickness + Sxx)
    output/DXF_Onderdelen  -> part DXFs (customer + partname)
    """
    input_dir = job_root / "input"
    output_dir = job_root / "output"
    sheets_src = output_dir / "sheets"
    if not output_dir.exists():
        return

    job_json = {}
    job_json_path = input_dir / "job.json"
    if job_json_path.exists():
        try:
            job_json = json.loads(job_json_path.read_text(encoding="utf-8"))
        except Exception:
            job_json = {}

    cust = (job_json.get("customer") or {})
    fn = ln = ""
    if isinstance(cust, dict):
        fn = str(cust.get("first_name") or cust.get("firstName") or "").strip()
        ln = str(cust.get("last_name")  or cust.get("lastName")  or "").strip()
    customer_name = " ".join([fn, ln]).strip()
    safe_cust = _sanitize_filename(customer_name, 50)

    # --- Zaagplaten ---
    out_sheets = output_dir / "DXF_Zaagplaten"
    out_sheets.mkdir(parents=True, exist_ok=True)

    # Tool B historically wrote sheets to output/sheets/*.dxf, but some versions or edge-cases may
    # output directly into output/ (e.g. sheet_1.dxf). Admin must be robust: show zaagplaten whenever
    # any sheet DXFs exist.
    sheet_sources = []

    # 1) canonical folder (RECURSIVE): output/sheets can contain nested folders in some Tool B versions.
    if sheets_src.exists():
        sheet_sources.extend(sorted(sheets_src.rglob("*.dxf")))
        sheet_sources.extend(sorted(sheets_src.rglob("*.DXF")))
        # Some environments/exporters may write DXF files without an extension (e.g. 'Sheet_001').
        # Include those as potential sheet sources as well.
        for f in sorted(sheets_src.rglob("*")):
            if f.is_file() and f.suffix == "" and f.name.lower().startswith("sheet"):
                sheet_sources.append(f)

    # 2) fallback: output root (non-recursive)
    sheet_sources.extend(sorted(output_dir.glob("sheet_*.dxf")))
    sheet_sources.extend(sorted(output_dir.glob("sheet_*.DXF")))
    sheet_sources.extend(sorted(output_dir.glob("Sheet_*.dxf")))
    sheet_sources.extend(sorted(output_dir.glob("Sheet_*.DXF")))

    # 3) last resort: recursive search under output/ for anything that looks like a sheet,
    # excluding the export folders themselves to avoid loops/dupes.
    for f in sorted(output_dir.rglob("*.dxf")) + sorted(output_dir.rglob("*.DXF")):
        try:
            rel = f.relative_to(output_dir).as_posix().lower()
        except Exception:
            rel = str(f).lower()
        if rel.startswith("dxf_zaagplaten/") or rel.startswith("dxf_onderdelen/"):
            continue
        n = f.name.lower()
        if (
            n.startswith("sheet_") or n.startswith("sheet") or
            n.startswith("plaat") or n.startswith("zaag") or
            "__s" in n
        ):
            sheet_sources.append(f)


    # 4) extra fallback: suffix-less sheet files anywhere under output/
    for f in sorted(output_dir.rglob("*")):
        try:
            rel = f.relative_to(output_dir).as_posix().lower()
        except Exception:
            rel = str(f).lower()
        if rel.startswith("dxf_zaagplaten/") or rel.startswith("dxf_onderdelen/"):
            continue
        if f.is_file() and f.suffix == "" and f.name.lower().startswith("sheet"):
            sheet_sources.append(f)

    # Deduplicate while preserving deterministic order.
    # Several glob patterns above can match the same file.
    _seen = set()
    _uniq = []
    for f in sheet_sources:
        try:
            key = str(f.resolve())
        except Exception:
            key = str(f)
        if key in _seen:
            continue
        _seen.add(key)
        _uniq.append(f)
    # Sort by filename for determinism across platforms/filesystems.
    sheet_sources = sorted(_uniq, key=lambda p: p.name.lower())

    # Copy/rename into export folder.
    # IMPORTANT: always include material identity in the exported sheet names.
    # Some Tool B versions write sheets to output/sheets/, others directly into output/.
    # We derive the material label from panels.csv (preferred) or placements.json sheets metadata.
    mat_label = None
    try:
        # 1) panels.csv -> single MaterialCode
        panels_path = input_dir / "panels.csv"
        if panels_path.exists():
            _rows = _parse_panels_csv(panels_path.read_text(encoding="utf-8"))
            _codes = sorted({str(r.get("MaterialCode") or r.get("materialCode") or "").strip() for r in _rows
                             if str(r.get("MaterialCode") or r.get("materialCode") or "").strip()})
            if len(_codes) == 1:
                mat_label = _material_label_for_filename(_codes[0], "")
    except Exception:
        mat_label = None

    if not mat_label:
        try:
            # 2) placements.json -> sheets metadata
            placements_path = _find_placements_any(output_dir) or (output_dir / "placements.json")
            if placements_path and placements_path.exists():
                _pl = json.loads(placements_path.read_text(encoding="utf-8"))
                _sh = (_pl.get("sheets") or [])
                if isinstance(_sh, list) and _sh:
                    _code = str((_sh[0].get("materialCode") or "")).strip()
                    _th = _sh[0].get("thicknessMm") or ""
                    if _code:
                        mat_label = _material_label_for_filename(_code, _th)
        except Exception:
            mat_label = None

    safe_mat = _sanitize_filename(mat_label or "materiaal_onbekend", 80)

    # Determine sheet indices deterministically by sorted discovery order.
    # We always export as <customer>__<material>__Sxx.dxf
    for i, f in enumerate(sheet_sources, start=1):
        name = f"{safe_cust}__{safe_mat}__S{i:02d}.dxf" if safe_cust else f"{safe_mat}__S{i:02d}.dxf"
        target = out_sheets / name
        if not target.exists():
            try:
                shutil.copy2(f, target)
            except Exception:
                pass

    # --- Onderdelen ---
    parts_src = None
    for cand in ["dxf_parts", "parts", "input_parts"]:
        p = input_dir / cand
        if p.exists():
            parts_src = p
            break
    out_parts = output_dir / "DXF_Onderdelen"
    out_parts.mkdir(parents=True, exist_ok=True)
    if parts_src and parts_src.exists():
        for f in sorted(parts_src.glob("*.dxf")):
            base = _sanitize_filename(f.stem, 90)
            target = out_parts / f"{safe_cust}__{base}.dxf"
            if not target.exists():
                try:
                    shutil.copy2(f, target)
                except Exception:
                    pass

def _start_optimizer(job_id: str, input_dir: Path, output_dir: Path):
    """Run Tool B in background and update job meta."""
    try:
        cmd = _get_python_base_cmd() + ["-u", str(ROOT / OPTIMIZER_TOOL_B), '--input', str(input_dir), '--output', str(output_dir)]
        optimizer_timeout = _env_int('OPTIMIZER_TIMEOUT_SECONDS', 300)
        try:
            p = subprocess.run(cmd, cwd=str(ROOT), capture_output=True, text=True, timeout=optimizer_timeout)
        except subprocess.TimeoutExpired as e:
            (output_dir).mkdir(parents=True, exist_ok=True)
            (output_dir / 'toolb_stdout.txt').write_text((e.stdout or '') if isinstance(e.stdout, str) else '', encoding='utf-8')
            (output_dir / 'toolb_stderr.txt').write_text(f'Optimizer timeout after {optimizer_timeout} seconds.\n{(e.stderr or "") if isinstance(e.stderr, str) else ""}', encoding='utf-8')
            raise RuntimeError(f'Optimizer timeout after {optimizer_timeout} seconds')
        # Persist tool output
        (output_dir).mkdir(parents=True, exist_ok=True)
        (output_dir / 'toolb_stdout.txt').write_text(p.stdout or '', encoding='utf-8')
        (output_dir / 'toolb_stderr.txt').write_text(p.stderr or '', encoding='utf-8')

        # Resolve job root folder once (app/jobs/<jobId>)
        job_root = output_dir.parent

        report_path = output_dir / 'report.json'
        quote_path = output_dir / 'quote.json'
        placements_path = _find_placements_any(output_dir)

        # Postprocess quote.json into SELL price model (material factor + edge €/m + CNC + drawing)
        try:
            if quote_path.exists() and (not _is_subjob(job_id)):
                raw_quote = json.loads(quote_path.read_text(encoding='utf-8'))
                sell_quote = _apply_sell_pricing_to_quote(raw_quote)
                quote_path.write_text(json.dumps(sell_quote, indent=2), encoding='utf-8')
                _write_human_calculation_summary(input_dir.parent)
        except Exception:
            # Never fail job on pricing postprocess
            pass

        with _job_lock:
            meta = _job_meta.get(job_id, {})
            if p.returncode == 0:
                meta['status'] = 'done'
                meta['finishedAt'] = _now_iso()
                if placements_path is None:
                    meta['warning'] = 'placements missing; sticker export may be limited'
            else:
                meta['status'] = 'error'
                meta['finishedAt'] = _now_iso()
                meta['error'] = (p.stderr.strip() or f'Tool B failed (code {p.returncode})')
            _job_meta[job_id] = meta
        # Post-processing: labels + stickertool + admin exports
        # Never fail the job on post-processing.
        if (p.returncode == 0):
            # labels.json requires placements
            try:
                if (placements_path is not None) and placements_path.exists():
                    _generate_labels_json(job_root)
            except Exception:
                pass

            # Stickertool v2 contract MUST ALWAYS be written (even if placements/panels missing)
            try:
                _generate_stickertool_json(job_root)
            except Exception as e:
                # absolute last-resort: ensure a visible error log exists
                try:
                    (output_dir / 'stickers_error.txt').write_text(str(e), encoding='utf-8')
                except Exception:
                    pass

            # Exports depend on placements/sheets
            if (placements_path is not None) and placements_path.exists():
                try:
                    _rename_sheet_dxfs(job_root)
                    _build_admin_dxf_exports(job_root)
                except Exception:
                    pass

    # no return
    except Exception as e:
        with _job_lock:
            meta = _job_meta.get(job_id, {})
            meta['status'] = 'error'
            meta['finishedAt'] = _now_iso()
            meta['error'] = str(e)
            _job_meta[job_id] = meta


ADMIN_HTML = """<!doctype html>
<html lang=\"nl\"><head>
<meta charset=\"utf-8\" />
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />
<title>METOD Admin</title>
<style>
  body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial; background:#0f1314; color:#e8f3ee; margin:0;}
  header{padding:16px 18px; border-bottom:1px solid rgba(255,255,255,.08); display:flex; gap:12px; align-items:center;}
  h1{font-size:16px; margin:0; letter-spacing:.2px;}
  main{padding:18px;}
  .card{background:#141a1c; border:1px solid rgba(255,255,255,.08); border-radius:14px; padding:14px; margin-bottom:12px;}
  .row{display:flex; gap:12px; flex-wrap:wrap; align-items:center; justify-content:space-between;}
  .muted{color:rgba(232,243,238,.7); font-size:12px;}
  button,a.btn{background:#2fbf6a; border:0; color:#08110b; padding:10px 12px; border-radius:10px; font-weight:700; cursor:pointer; text-decoration:none; display:inline-block;}
  button.secondary{background:rgba(255,255,255,.08); color:#e8f3ee; font-weight:600;}
  table{width:100%; border-collapse:collapse; font-size:13px;}
  th,td{padding:8px 10px; border-bottom:1px solid rgba(255,255,255,.08); text-align:left;}
  td.outputsTd{vertical-align:top;}
  .outputsCell{display:flex; justify-content:flex-end; align-items:flex-start;}
  .outputsCell > *{max-width:100%;}
  code{background:rgba(255,255,255,.08); padding:2px 6px; border-radius:8px;}
  details{margin-top:6px;}
  summary{cursor:pointer; user-select:none;}
  summary::-webkit-details-marker{display:none;}
  summary::marker{content:'';}

  details.jobOut{display:inline-block;}
  details.jobOut > summary{
    list-style:none;
    display:inline-flex;
    align-items:center;
    gap:8px;
    padding:8px 10px;
    border-radius:10px;
    background:rgba(255,255,255,.06);
    border:1px solid rgba(255,255,255,.10);
    color:#e8f3ee;
    font-weight:800;
    width:fit-content;
  }
  details.jobOut[open] > summary{background:rgba(47,191,106,.18); border-color:rgba(47,191,106,.35);}
  .jobOutBody{margin-top:8px;}

  .groupToggle{background:rgba(255,255,255,.08); border:1px solid rgba(255,255,255,.12); color:#e8f3ee; font-weight:900; border-radius:10px; padding:6px 8px; cursor:pointer;}
  .groupToggle:hover{background:rgba(255,255,255,.12);}
  tr.childRow{display:none;}
  tr.childRow td{opacity:0.98;}
  tr.childRow td:first-child .arrow{color:rgba(232,243,238,.65); margin-right:6px;}
  tr.childRow td:first-child .jobIndent{display:inline-flex; align-items:center; gap:6px; padding-left:18px;}
  details.jobOut.zaagHi > summary{background:rgba(47,191,106,.22); border-color:rgba(47,191,106,.45);}
  tr.childRow.zaagRow td:first-child{box-shadow: inset 3px 0 0 rgba(47,191,106,.9);}


  /* Mailbox (requests) */
  .tabs{display:flex; gap:6px; flex-wrap:wrap;}
  .tabBtn{border:1px solid rgba(0,0,0,.12); background:#fff; padding:6px 10px; border-radius:999px; cursor:pointer; font-weight:700;}
  .tabBtn.active{box-shadow: inset 0 0 0 2px rgba(47,191,106,.35); border-color:rgba(47,191,106,.45);}
  .dot{width:10px; height:10px; border-radius:50%; display:inline-block;}
  .dot.green{background:rgba(47,191,106,.95);}
  .dot.red{background:rgba(214,69,69,.95);}
  .dot.blue{background:rgba(64,120,240,.95);}
  .dot.yellow{background:rgba(245,178,37,.95);}
  .dot.gray{background:rgba(140,140,140,.95);}
  tr.mbRow{cursor:pointer;}
  tr.mbRow:hover{background:rgba(255,255,255,.03);}
  .mbDetailsCard{margin-top:14px; border:1px solid rgba(255,255,255,.08); border-radius:16px; background:linear-gradient(180deg, rgba(255,255,255,.025), rgba(255,255,255,.012)); overflow:hidden;}
  .mbDetailsHead{padding:12px 14px; border-bottom:1px solid rgba(255,255,255,.06); display:flex; align-items:center; justify-content:space-between; gap:12px;}
  .mbDetailsBody{padding:14px;}
  .mbInfoGrid{display:grid; grid-template-columns:repeat(auto-fit, minmax(220px,1fr)); gap:12px;}
  .mbInfoCard{border:1px solid rgba(255,255,255,.08); background:rgba(255,255,255,.025); border-radius:14px; padding:12px;}
  .mbLabel{font-size:11px; letter-spacing:.04em; text-transform:uppercase; color:rgba(232,243,238,.62); font-weight:800; margin-bottom:6px;}
  .mbValue{font-size:14px; font-weight:700; color:#e8f3ee;}
  .mbValue.mono{font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace; font-size:12px;}
  .mbBadgeRow{display:flex; gap:8px; flex-wrap:wrap; margin-top:2px;}
  .mbBadge{display:inline-flex; align-items:center; gap:6px; border-radius:999px; padding:4px 10px; font-size:12px; font-weight:800; border:1px solid rgba(255,255,255,.12); background:rgba(255,255,255,.05);}
  .mbBadge.green{background:rgba(47,191,106,.12); border-color:rgba(47,191,106,.28); color:#d9f7e4;}
  .mbBadge.blue{background:rgba(64,120,240,.12); border-color:rgba(64,120,240,.28); color:#dce7ff;}
  .mbBadge.yellow{background:rgba(245,178,37,.14); border-color:rgba(245,178,37,.28); color:#fff0c8;}
  .mbBadge.red{background:rgba(214,69,69,.14); border-color:rgba(214,69,69,.28); color:#ffd8d8;}
  .mbBadge.gray{background:rgba(255,255,255,.06); border-color:rgba(255,255,255,.12); color:#d8dee1;}
  .mbSectionTitle{font-weight:900; margin-top:14px; margin-bottom:8px;}
  .mbFileGrid{display:flex; gap:8px; flex-wrap:wrap; margin-top:10px;}
  .mbPill, .mbFileGrid a.pill, .mbFileLine a.pill, .mbActionBtn{display:inline-flex; align-items:center; justify-content:center; min-height:28px; padding:0 11px; border-radius:9px; border:1px solid rgba(255,255,255,.14); background:rgba(255,255,255,.055); color:#e8f3ee; font-size:12px; font-weight:800; text-decoration:none; white-space:nowrap; transition:all .15s ease;}
  .mbPill:hover, .mbFileGrid a.pill:hover, .mbFileLine a.pill:hover, .mbActionBtn:hover{background:rgba(47,191,106,.12); border-color:rgba(47,191,106,.32); transform:translateY(-1px);}
  .mbActionBtn{background:rgba(47,191,106,.14); border-color:rgba(47,191,106,.28); color:#ddf8e6; cursor:pointer;}
  .mbActionBtn[disabled]{opacity:.55; pointer-events:none; transform:none;}
  .mbFileGroup{margin-top:10px; border:1px solid rgba(255,255,255,.06); border-radius:14px; overflow:hidden;}
  .mbFileGroupHead{padding:10px 12px; background:rgba(255,255,255,.03); font-weight:800;}
  .mbFileLine{display:flex; justify-content:space-between; gap:12px; align-items:center; padding:10px 12px; border-top:1px dashed rgba(255,255,255,.08);}
  .mbFileMeta{font-size:12px; opacity:.8;}
  .mbPriceCard{margin-top:10px; border:1px solid rgba(255,255,255,.08); background:rgba(255,255,255,.03); border-radius:14px; padding:12px;}
  .mbPriceRow{display:flex; align-items:center; justify-content:space-between; gap:12px; padding:7px 0; border-top:1px dashed rgba(255,255,255,.08);}
  .mbPriceRow:first-child{border-top:none; padding-top:0;}
  .mbPriceRow:last-child{padding-bottom:0;}
  .mbPriceRow span{color:rgba(232,243,238,.82); font-size:13px;}
  .mbPriceRow strong{color:#f6fbf8; font-size:13px;}
  .mbPriceRow.emph span,.mbPriceRow.emph strong{font-weight:900; font-size:14px; color:#fff;}

  .adminShell{display:grid; grid-template-columns:76px minmax(0,1fr); gap:18px; align-items:start;}
  .adminRail{position:sticky; top:18px; display:flex; flex-direction:column; gap:10px; padding:10px 8px; border:1px solid rgba(255,255,255,.08); border-radius:18px; background:linear-gradient(180deg, rgba(255,255,255,.03), rgba(255,255,255,.015));}
  .adminNavBtn{display:flex; flex-direction:column; align-items:center; justify-content:center; gap:6px; min-height:66px; border-radius:16px; border:1px solid rgba(255,255,255,.10); background:rgba(255,255,255,.03); color:#dfeae4; cursor:pointer; transition:all .18s ease; padding:8px 6px;}
  .adminNavBtn:hover{transform:translateY(-1px); border-color:rgba(47,191,106,.24); background:rgba(47,191,106,.08);}
  .adminNavBtn.active{background:rgba(47,191,106,.14); border-color:rgba(47,191,106,.34); box-shadow:inset 3px 0 0 rgba(47,191,106,.9);}
  .adminNavIcon{font-size:18px; line-height:1;}
  .adminNavLabel{font-size:11px; font-weight:800; letter-spacing:.01em; text-align:center;}
  .adminPages{min-width:0; display:grid; gap:16px;}
  .adminSection{display:none;}
  .adminSection.active{display:block;}
  .adminSectionTitle{font-size:18px; font-weight:900; margin-bottom:6px;}
  .adminSectionIntro{color:rgba(232,243,238,.7); margin-bottom:12px;}
  .pricingShell{display:grid; gap:14px;}
  .pricingHero{display:flex; justify-content:space-between; align-items:flex-start; gap:16px; flex-wrap:wrap;}
  .pricingHeroMeta{display:flex; gap:8px; flex-wrap:wrap; align-items:center;}
  .pricingTag{display:inline-flex; align-items:center; gap:6px; border-radius:999px; padding:6px 10px; font-size:12px; font-weight:800; border:1px solid rgba(47,191,106,.24); background:rgba(47,191,106,.10); color:#dff7e7;}
  .pricingGrid{display:grid; grid-template-columns:repeat(auto-fit, minmax(260px,1fr)); gap:14px;}
  .pricingCard{border:1px solid rgba(255,255,255,.08); border-radius:18px; background:linear-gradient(180deg, rgba(255,255,255,.03), rgba(255,255,255,.015)); padding:16px;}
  .pricingCard h3{margin:0 0 6px 0; font-size:16px; font-weight:900;}
  .pricingCard p{margin:0 0 14px 0; color:rgba(232,243,238,.72); font-size:13px;}
  .pricingFields{display:grid; gap:12px;}
  .pricingField label{display:block; font-size:12px; font-weight:800; color:rgba(232,243,238,.78); margin-bottom:6px;}
  .pricingField input,.pricingField select,.pricingField textarea{width:100%; box-sizing:border-box; padding:11px 12px; border-radius:12px; border:1px solid rgba(255,255,255,.12); background:#0f1518; color:#e8f3ee; font-size:14px;}
  .pricingField .help{margin-top:5px; font-size:11px; color:rgba(232,243,238,.55);}
  .pricingActions{display:flex; gap:10px; flex-wrap:wrap; align-items:center;}
  .pricingStatusLine{font-size:12px; color:rgba(232,243,238,.72); min-height:18px;}
  .materialsGrid{display:grid; grid-template-columns:minmax(320px, 420px) minmax(480px, 1fr); gap:18px; align-items:start;}
  .materialsListCard,.materialsDetailCard{border:1px solid rgba(255,255,255,.08); border-radius:20px; background:linear-gradient(180deg, rgba(255,255,255,.03), rgba(255,255,255,.015)); padding:16px;}
  .materialsList{display:grid; gap:10px; max-height:70vh; overflow:auto; padding-right:4px;}
  .materialsRow{border:1px solid rgba(255,255,255,.08); border-radius:14px; background:#0f1518; padding:12px 13px; cursor:pointer; transition:.15s ease; color:#e8f3ee; text-align:left; appearance:none; -webkit-appearance:none;}
  .materialsRow:hover{border-color:rgba(62,201,120,.45); transform:translateY(-1px);}
  .materialsRow.active{border-color:#3ec978; box-shadow:0 0 0 1px rgba(62,201,120,.25) inset;}
  .materialsRowTitle{font-weight:900; font-size:14px; margin-bottom:3px; color:#f3fbf7;}
  .materialsRowMeta{font-size:12px; color:rgba(232,243,238,.65); display:flex; gap:8px; flex-wrap:wrap;}
  .materialsForm{display:grid; grid-template-columns:repeat(2, minmax(220px, 1fr)); gap:14px;}
  .materialsWide{grid-column:1 / -1;}
  @media (max-width: 1180px){ .materialsGrid{grid-template-columns:1fr;} .materialsForm{grid-template-columns:1fr;} }
  .jobsSummary{display:flex; align-items:center; justify-content:space-between; gap:12px; cursor:pointer; font-weight:900; list-style:none;}
  .jobsSummary::-webkit-details-marker{display:none;}
  .jobsSummary::after{content:'▾'; opacity:.72; transition:transform .15s ease;}
  #jobsDetails:not([open]) .jobsSummary::after{transform:rotate(-90deg);}
  .jobsCollapsedHint{color:rgba(232,243,238,.6); font-size:12px; margin-top:8px;}

</style></head>
<body>
<header>
  <h1>METOD Admin</h1>
  <div class=\"muted\">Jobs + outputs (DXF sheets download)</div>
  <div style=\"margin-left:auto\"></div>
  <a class=\"btn\" href=\"/\">Tool A</a>
</header>
<main>
  <div class="adminShell">
    <aside class="adminRail" aria-label="Admin navigatie">
      <button class="adminNavBtn active" type="button" data-section="inbox" title="Inbox">
        <span class="adminNavIcon">📥</span>
        <span class="adminNavLabel">Inbox</span>
      </button>
      <button class="adminNavBtn" type="button" data-section="beheer" title="Beheer">
        <span class="adminNavIcon">🛠</span>
        <span class="adminNavLabel">Beheer</span>
      </button>
      <button class="adminNavBtn" type="button" data-section="materials" title="Materialen">
        <span class="adminNavIcon">🪵</span>
        <span class="adminNavLabel">Materialen</span>
      </button>
      <button class="adminNavBtn" type="button" data-section="pricing" title="Prijsinstellingen">
        <span class="adminNavIcon">💶</span>
        <span class="adminNavLabel">Prijzen</span>
      </button>
      <button class="adminNavBtn" type="button" data-section="system" title="Systeem">
        <span class="adminNavIcon">🖥️</span>
        <span class="adminNavLabel">Systeem</span>
      </button>
      <button class="adminNavBtn" type="button" data-section="jobs" title="Jobs">
        <span class="adminNavIcon">🧰</span>
        <span class="adminNavLabel">Jobs</span>
      </button>
    </aside>

    <div class="adminPages">
      <section class="adminSection active" id="adminSection-inbox" data-section="inbox">
        <div class="card" id="mbCard">
          <div style="display:flex; align-items:center; gap:12px; flex-wrap:wrap;">
            <div style="font-weight:900; font-size:16px;">📥 Inbox</div>
            <div class="tabs" id="mbTabs">
              <button class="tabBtn active" data-tab="inbox" type="button">Inbox</button>
              <button class="tabBtn" data-tab="processing" type="button">Processing</button>
              <button class="tabBtn" data-tab="errors" type="button">Errors</button>
              <button class="tabBtn" data-tab="afgehandeld" type="button">Afgehandeld</button>
              <button class="tabBtn" data-tab="alles" type="button">Alles</button>
            </div>
            <div style="margin-left:auto; display:flex; gap:8px; align-items:center;">
              <input id="mbSearch" placeholder="Zoeken (klant / requestId)" style="min-width:220px; padding:8px 10px; border-radius:10px; border:1px solid rgba(0,0,0,.12);" />
              <button class="btn" id="mbRefreshBtn" type="button">Refresh</button>
            </div>
          </div>
          <div class="muted" style="margin-top:8px;">Nieuwe aanvragen komen binnen in Inbox. Na 'Aanvraag afhandelen' schuiven ze door naar Afgehandeld. Alles blijft file-based & deterministisch.</div>

          <div style="margin-top:12px; overflow:auto;">
            <table id="mbTable" style="width:100%;">
              <thead>
                <tr>
                  <th style="width:34px;"></th>
                  <th>Request</th>
                  <th>Klant</th>
                  <th>Public</th>
                  <th>Intern</th>
                  <th>Created</th>
                  <th style="width:200px;">Acties</th>
                </tr>
              </thead>
              <tbody id="mbTbody">
                <tr><td colspan="7" class="muted">laden…</td></tr>
              </tbody>
            </table>
          </div>

          <details id="mbDetails" style="margin-top:10px; display:none;">
            <summary style="cursor:pointer; font-weight:900;">Details</summary>
            <div id="mbDetailsBody" class="muted" style="margin-top:8px;">—</div>
          </details>
        </div>
      </section>

      <section class="adminSection" id="adminSection-beheer" data-section="beheer">
        <div class="card">
          <div style="display:flex; align-items:flex-start; justify-content:space-between; gap:16px; flex-wrap:wrap;">
            <div>
              <div style="font-weight:900; font-size:16px;">📐 DXF Beheer</div>
              <div class="muted" style="margin-top:6px; max-width:900px;">Beheer hier alle DXF templates per categorie. <code>(root)</code> is de hoofdmap voor bestaande templates. Materialen en prijsinstellingen hebben nu hun eigen pagina links in de adminbalk.</div>
            </div>
          </div>

          <div style="margin-top:16px; padding-top:10px; border-top:1px solid rgba(255,255,255,0.08);">
            <div style="display:flex; gap:8px; flex-wrap:wrap; align-items:center;">
              <label class="muted" style="font-size:12px;">Categorie</label>
              <select id="dxfCatSel" style="min-width:200px;"></select>
              <button class="btn" id="dxfRefreshBtn" type="button">Ververs</button>
            </div>

            <div style="margin-top:10px; display:flex; gap:8px; flex-wrap:wrap; align-items:center;">
              <input id="dxfNewCat" placeholder="Nieuwe categorie (bv. metod)" style="min-width:220px;" />
              <button class="btn" id="dxfCreateCatBtn" type="button">Maak categorie</button>
            </div>

            <div style="margin-top:12px; display:flex; gap:8px; flex-wrap:wrap; align-items:center;">
              <input type="file" id="dxfFileInput" accept=".dxf" />
              <button class="btn" id="dxfUploadBtn" type="button">Upload DXF</button>
            </div>

            <div class="muted" id="dxfStatus" style="margin-top:6px; font-size:12px;">—</div>

            <div style="margin-top:12px;">
              <div style="font-weight:800; margin-bottom:6px;">Bestanden</div>
              <div id="dxfFiles" class="muted" style="font-size:12px;">—</div>
            </div>
          </div>

              <script>
              async function _postJson(url, body){
                const r = await fetch(url, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body)});
                let j = {};
                try{ j = await r.json(); }catch(e){}
                return {ok:r.ok, json:j};
              }
              async function _getJson(url){
                const r = await fetch(url, {cache:'no-store'});
                let j = {};
                try{ j = await r.json(); }catch(e){}
                return {ok:r.ok, json:j};
              }

              function esc(s){ return String(s).replace(/[&<>"']/g, c=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c])); }

              async function dxf_load_categories(){
                const sel = document.getElementById('dxfCatSel');
                if(!sel) return;
                const prev = sel.value || '';
                const {ok, json} = await _getJson('/api/admin/dxf/categories');
                sel.innerHTML = '';
                (json.categories || []).forEach(c=>{
                  const o = document.createElement('option');
                  o.value = c;
                  o.textContent = (c === '(root)') ? '(root)' : c;
                  sel.appendChild(o);
                });
                if(prev){
                  const opt = Array.from(sel.options).find(o=>o.value===prev);
                  if(opt) sel.value = prev;
                }
              }

              async function dxf_load_files(){
                const sel = document.getElementById('dxfCatSel');
                const box = document.getElementById('dxfFiles');
                const st = document.getElementById('dxfStatus');
                let cat = sel ? sel.value : '';
                const catText = (sel && sel.options && sel.selectedIndex>=0) ? (sel.options[sel.selectedIndex].textContent||'') : '';
                if(cat === '(root)' && catText && catText !== '(root)') cat = catText;
                if(!cat){ if(box) box.textContent='Geen categorie geselecteerd.'; return; }
                const {ok, json} = await _getJson('/api/admin/dxf/list?category=' + encodeURIComponent(cat));
                if(!ok || !json.ok){ if(st) st.textContent='Fout: ' + (json.error||''); return; }
                const files = json.files || [];
                if(!files.length){ if(box) box.textContent='Geen DXF bestanden in deze categorie.'; return; }
                box.innerHTML = files.map(fn=>(
                  `<div style="display:flex; justify-content:space-between; gap:12px; align-items:center; padding:6px 0; border-bottom:1px dashed rgba(255,255,255,0.08);">
                    <div style="font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace;">${esc(fn)}</div>
                    <button class="btn danger" type="button" data-act="delete-dxf" data-cat="${encodeURIComponent(cat)}" data-file="${encodeURIComponent(fn)}">Verwijder</button>
                  </div>`
                )).join('');
                box.querySelectorAll('[data-act="delete-dxf"]').forEach(btn=>{
                  btn.addEventListener('click', ()=>{
                    const catVal = decodeURIComponent(btn.getAttribute('data-cat') || '');
                    const fileVal = decodeURIComponent(btn.getAttribute('data-file') || '');
                    dxf_delete_file(catVal, fileVal);
                  });
                });
              }

              async function dxf_create_category(){
                const inp = document.getElementById('dxfNewCat');
                const st = document.getElementById('dxfStatus');
                const name = inp ? inp.value.trim() : '';
                if(!name){ if(st) st.textContent='Vul een categorie naam in.'; return; }
                const {ok, json} = await _postJson('/api/admin/dxf/create_category', {category:name});
                if(!ok || !json.ok){ if(st) st.textContent='Fout: ' + (json.error||''); return; }
                if(st) st.textContent='Categorie aangemaakt: ' + name;
                if(inp) inp.value='';
                await dxf_load_categories();
                const sel = document.getElementById('dxfCatSel');
                if(sel) sel.value = name;
                await dxf_load_files();
              }

              async function dxf_upload_file(){
                const sel = document.getElementById('dxfCatSel');
                let cat = sel ? sel.value : '';
                const catText = (sel && sel.options && sel.selectedIndex>=0) ? (sel.options[sel.selectedIndex].textContent||'') : '';
                if(cat === '(root)' && catText && catText !== '(root)') cat = catText;
                const inp = document.getElementById('dxfFileInput');
                const st = document.getElementById('dxfStatus');
                if(!cat){ if(st) st.textContent='Selecteer eerst een categorie.'; return; }
                if(!inp || !inp.files || !inp.files.length){ if(st) st.textContent='Kies eerst een DXF bestand.'; return; }
                const file = inp.files[0];
                const buf = await file.arrayBuffer();
                let bin = '';
                const bytes = new Uint8Array(buf);
                const chunk = 0x8000;
                for(let i=0;i<bytes.length;i+=chunk){
                  bin += String.fromCharCode.apply(null, bytes.subarray(i,i+chunk));
                }
                const b64 = btoa(bin);
                const {ok, json} = await _postJson('/api/admin/dxf/upload', {category:cat, filename:file.name, dataBase64:b64});
                if(!ok || !json.ok){ if(st) st.textContent='Fout: ' + (json.error||''); return; }
                if(st) st.textContent='Upload OK: ' + file.name;
                inp.value='';
                await dxf_load_files();
              }

              async function dxf_delete_file(cat, fn){
                if(!confirm('Verwijderen: ' + fn + ' ?')) return;
                const st = document.getElementById('dxfStatus');
                const {ok, json} = await _postJson('/api/admin/dxf/delete', {category:cat, filename:fn});
                if(!ok || !json.ok){ if(st) st.textContent='Fout: ' + (json.error||''); return; }
                if(st) st.textContent='Verwijderd: ' + fn;
                await dxf_load_files();
              }

              document.addEventListener('DOMContentLoaded', ()=>{
                const r = document.getElementById('dxfRefreshBtn');
                const c = document.getElementById('dxfCreateCatBtn');
                const u = document.getElementById('dxfUploadBtn');
                if(r) r.addEventListener('click', async()=>{ await dxf_load_categories(); await dxf_load_files(); });
                if(c) c.addEventListener('click', dxf_create_category);
                if(u) u.addEventListener('click', dxf_upload_file);
                (async()=>{ await dxf_load_categories(); await dxf_load_files(); })();
              });
              </script>
        </div>
      </section>

      <section class="adminSection" id="adminSection-materials" data-section="materials">
        <div class="card">
          <div style="display:flex; justify-content:space-between; gap:12px; align-items:flex-start; flex-wrap:wrap;">
            <div>
              <div class="adminSectionTitle">Materialen</div>
            </div>
            <div class="pricingActions">
              <button class="btn" type="button" onclick="materialsNew()">Nieuw materiaal</button>
              <button class="btn" type="button" onclick="materialsReload()">Herladen</button>
            </div>
          </div>

          <div class="materialsGrid" style="margin-top:16px;">
            <div class="materialsListCard">
              <div class="pricingField">
                <label for="materialsSearch">Zoeken</label>
                <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
                  <input id="materialsSearch" placeholder="Zoek op artikelnummer, decornaam of code..." style="flex:1 1 320px;" />
                  <button class="btn secondary" id="materialsFiltersToggle" type="button">Filters</button>
                </div>
                <div class="help">Live filter op bestaande materialen. Extra filters staan standaard ingeklapt.</div>
              </div>
              <div id="materialsFiltersPanel" class="card" style="display:none; margin-top:12px; padding:12px; background:rgba(255,255,255,0.02); border:1px solid rgba(255,255,255,0.08);">
                <div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:12px;">
                  <div class="pricingField" style="margin:0;"><label for="materialsFilterThickness">Dikte</label><select id="materialsFilterThickness"><option value="">Alle diktes</option></select></div>
                  <div class="pricingField" style="margin:0;"><label for="materialsFilterDimension">Afmeting plaat</label><select id="materialsFilterDimension"><option value="">Alle afmetingen</option></select></div>
                  <div class="pricingField" style="margin:0;"><label for="materialsFilterCategory">Plaatsoort / categorie</label><select id="materialsFilterCategory"><option value="">Alle plaatsoorten</option></select></div>
                  <div class="pricingField" style="margin:0;"><label for="materialsFilterBrandText">Merk / producttekst</label><input id="materialsFilterBrandText" placeholder="Bijv. Unilin, DecoLegno, Shinnoki..." /></div>
                  <div class="pricingField" style="margin:0;"><label for="materialsFilterAvailability">Beschikbaar in Tool A</label><select id="materialsFilterAvailability"><option value="">Alles</option><option value="yes">Alleen beschikbaar</option><option value="no">Alleen niet beschikbaar</option></select></div>
                </div>
                <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap; margin-top:12px;">
                  <button class="btn secondary" id="materialsResetFiltersBtn" type="button">Reset filters</button>
                  <div class="muted" style="font-size:12px;">Filtert slim op dikte, plaatmaat, plaatsoort en merk-/producttekst. Actieve filters tellen mee op de knop.</div>
                </div>
              </div>
              <div style="margin-top:12px; display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
                <input type="file" id="matJsonInput" accept=".json,application/json" />
                <button class="btn" id="matJsonUploadBtn" type="button">Upload hele JSON</button>
              </div>
              <div id="matJsonStatus" class="pricingStatusLine" style="margin-top:8px;">—</div>
              <div id="materialsMeta" class="muted" style="margin-top:12px; font-size:12px;">Laden…</div>
              <div id="materialsList" class="materialsList" style="margin-top:12px;"></div>
            </div>

            <div class="materialsDetailCard">
              <div style="display:flex; justify-content:space-between; gap:12px; align-items:flex-start; flex-wrap:wrap;">
                <div>
                  <div class="adminSectionTitle" style="font-size:22px; margin-bottom:4px;">Materiaalgegevens</div>
                  <div class="adminSectionIntro" style="margin-bottom:0;">Pas een bestaand materiaal aan of voeg een nieuw materiaal toe. Alles schrijft direct terug naar <code>material_library.json</code>.</div>
                </div>
                <div id="materialsDetailState" class="pricingStatusLine">Geen materiaal geselecteerd.</div>
              </div>

              <div class="materialsForm" style="margin-top:16px;">
                <div class="pricingField"><label for="matArticleNo">Artikelnummer</label><input id="matArticleNo" /></div>
                <div class="pricingField"><label for="matDecorName">Decornaam</label><input id="matDecorName" /></div>
                <div class="pricingField"><label for="matProductName">Productnaam</label><input id="matProductName" /></div>
                <div class="pricingField"><label for="matCategoryName">Categorie</label><select id="matCategoryName"><option value="">Kies categorie</option><option>Gemelamineerd spaanplaat</option><option>Gefineerd MDF</option><option>Gemelamineerd MDF</option><option>MDF</option><option>MDF met HPL</option></select></div>
                <div class="pricingField"><label for="matSheetWid">Breedte plaat (mm)</label><input id="matSheetWid" inputmode="decimal" /></div>
                <div class="pricingField"><label for="matSheetLen">Lengte plaat (mm)</label><input id="matSheetLen" inputmode="decimal" /></div>
                <div class="pricingField"><label for="matThickness">Dikte (mm)</label><input id="matThickness" inputmode="decimal" /></div>
                <div class="pricingField"><label for="matPurchasePrice">Inkoopprijs per plaat (€)</label><input id="matPurchasePrice" inputmode="decimal" /></div>
                <div class="pricingField materialsWide"><label for="matShortDescription">Omschrijving</label><input id="matShortDescription" /></div>
                <div class="pricingField materialsWide"><label style="display:flex; align-items:center; gap:10px;"><input id="matActive" type="checkbox" style="width:auto;" checked /> Beschikbaar in Tool A</label><div class="help">Zet dit uit als een materiaal tijdelijk niet op voorraad of niet bestelbaar is. Het blijft dan wel in de library staan, maar verdwijnt uit Tool A.</div></div>
              </div>

              <div class="pricingActions" style="margin-top:18px;">
                <button class="btn" type="button" onclick="materialsSave()">Opslaan</button>
                <button class="btn" type="button" onclick="materialsDelete()">Verwijderen</button>
                <button class="btn secondary" type="button" onclick="materialsNew()">Leeg formulier</button>
                <span id="materialsStatus" class="pricingStatusLine"></span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section class="adminSection" id="adminSection-pricing" data-section="pricing">
        <div class="card">
          <div class="pricingShell">
            <div class="pricingHero">
              <div>
                <div class="adminSectionTitle">Prijsinstellingen</div>
              </div>
              <div class="pricingHeroMeta">
                <span class="pricingTag">Live voor nieuwe berekeningen</span>
                <span class="pricingTag">Versies worden automatisch opgeslagen</span>
              </div>
            </div>

            <div class="pricingGrid">
              <div class="pricingCard">
                <h3>Algemene instellingen</h3>
                <p>Technische defaults voor de actieve pricing-configuratie.</p>
                <div class="pricingFields">
                  <div class="pricingField"><label for="priceSheetMargin">Plaatmarge (mm)</label><input id="priceSheetMargin" type="number" step="0.1" min="0" /><div class="help">Vrije marge langs de plaatranden.</div></div>
                  <div class="pricingField"><label for="priceNestingGap">Nesting gap (mm)</label><input id="priceNestingGap" type="number" step="0.1" min="0" /><div class="help">Afstand tussen onderdelen op de plaat.</div></div>
                  <div class="pricingField"><label for="priceKerf">Kerf / zaagverlies (mm)</label><input id="priceKerf" type="number" step="0.1" min="0" /><div class="help">Technische kerf-waarde in de pricing-config.</div></div>
                  <div class="pricingField"><label for="priceMoneyDecimals">Bedragen afronden</label><input id="priceMoneyDecimals" type="number" step="1" min="0" max="4" /><div class="help">Aantal decimalen voor geldbedragen.</div></div>
                  <div class="pricingField"><label for="priceMetersDecimals">Meters afronden</label><input id="priceMetersDecimals" type="number" step="1" min="0" max="4" /><div class="help">Aantal decimalen voor meters/kantenband.</div></div>
                </div>
              </div>

              <div class="pricingCard">
                <h3>Kosten & toeslagen</h3>
                <p>Deze waarden worden gebruikt voor nieuwe offertes en berekeningen.</p>
                <div class="pricingFields">
                  <div class="pricingField"><label for="priceSheetFactor">Plaatfactor</label><input id="priceSheetFactor" type="number" step="0.01" min="0" /><div class="help">Verkoopfactor op aankoopprijs per plaat.</div></div>
                  <div class="pricingField"><label for="priceEdgeBand">Kantenband per meter (€)</label><input id="priceEdgeBand" type="number" step="0.01" min="0" /><div class="help">Verkoopprijs per meter kantenband.</div></div>
                  <div class="pricingField"><label for="priceCnc">CNC per plaat (€)</label><input id="priceCnc" type="number" step="0.01" min="0" /><div class="help">CNC-kosten per gebruikte plaat.</div></div>
                  <div class="pricingField"><label for="priceDrawing">Tekenwerk vast (€)</label><input id="priceDrawing" type="number" step="0.01" min="0" /><div class="help">Vaste teken-/voorbereidingskosten per aanvraag.</div></div>
                  <div class="pricingField"><label for="priceTransport">Transport vast (€)</label><input id="priceTransport" type="number" step="0.01" min="0" /><div class="help">Vaste transportkosten per aanvraag.</div></div>
                </div>
              </div>
            </div>

            <div class="pricingCard">
              <div style="display:flex; justify-content:space-between; gap:12px; align-items:flex-start; flex-wrap:wrap;">
                <div>
                  <h3 style="margin-bottom:4px;">Status</h3>
                </div>
                <div id="pricingMeta" class="pricingStatusLine">Nog niet geladen.</div>
              </div>
              <div class="pricingActions" style="margin-top:14px;">
                <button class="btn" type="button" onclick="savePricing()">Opslaan</button>
                <button class="btn" type="button" onclick="reloadPricing()">Herladen</button>
                <span id="pricingStatus" class="pricingStatusLine"></span>
              </div>
            </div>
          </div>
        </div>
      </section>


      <section class="adminSection" id="adminSection-system" data-section="system">
        <div class="card" style="padding:18px; display:grid; gap:16px;">
          <div>
            <div class="adminSectionTitle">Systeem</div>
            <div class="adminSectionIntro">Duidelijke systeemmeldingen en backups op één plek. Per melding zie je mensentaal, technische details en – als beschikbaar – jobId en klantnaam.</div>
          </div>
          <div class="grid2" style="gap:14px; align-items:start;">
            <details class="card" style="padding:14px; display:grid; gap:10px;" id="systemBackupsDetails">
              <summary style="list-style:none; cursor:pointer; display:flex; justify-content:space-between; align-items:center; gap:10px; font-weight:900; font-size:15px;">
                <span>Backups</span>
                <span class="pill" id="systemBackupsCount">0</span>
              </summary>
              <div class="muted" style="margin-top:8px;">Maak handmatig een backup van code, config en data. Daarnaast maakt het systeem automatisch 1 backup per week en bewaart het de lijsten compact.</div>
              <div style="display:flex; gap:10px; flex-wrap:wrap; margin-top:4px;">
                <button class="btn secondary" type="button" onclick="refreshSystemPage()">Verversen</button>
                <button class="btn" type="button" onclick="createSystemBackup()">Nu backup maken</button>
              </div>
              <div id="systemBackupStatus" class="muted">Nog geen data geladen…</div><div class="muted" style="margin-top:6px;">Automatisch: 1 backup per 7 dagen · bewaren: 8 automatische + 12 handmatige backups</div>
              <div id="systemBackupsList" style="display:grid; gap:8px;"></div>
            </details>
            <details class="card" style="padding:14px; display:grid; gap:10px;" id="systemOpenIssuesDetails">
              <summary style="list-style:none; cursor:pointer; display:flex; justify-content:space-between; align-items:center; gap:10px; font-weight:900; font-size:15px;">
                <span>Open fouten & meldingen</span>
                <span class="pill" id="systemOpenIssuesCount">0</span>
              </summary>
              <div class="muted" style="margin-top:8px;">Alleen meldingen die aandacht nodig hebben. Standaard ingeklapt voor rust.</div>
              <div id="systemLogsStatus" class="muted">Nog geen data geladen…</div>
              <div id="systemOpenIssuesList" style="display:grid; gap:10px;"></div>
            </details>
          </div>
          <details class="card" style="padding:14px; display:grid; gap:10px; margin-top:14px;" id="systemRecentActionsDetails">
            <summary style="list-style:none; cursor:pointer; display:flex; justify-content:space-between; align-items:center; gap:10px; font-weight:900; font-size:15px;">
              <span>Recente systeemacties</span>
              <span class="pill" id="systemRecentActionsCount">0</span>
            </summary>
            <div class="muted" style="margin-top:8px;">Compact overzicht van de laatste belangrijke successen. Standaard ingeklapt.</div>
            <div id="systemRecentActionsList" style="display:grid; gap:8px;"></div>
          </details>
          <details class="card" style="padding:14px; display:grid; gap:10px; margin-top:14px;" id="systemHistoryDetails">
            <summary style="list-style:none; cursor:pointer; display:flex; justify-content:space-between; align-items:center; gap:10px; font-weight:900; font-size:15px;">
              <span>Volledige geschiedenis</span>
              <span class="pill" id="systemHistoryCount">0</span>
            </summary>
            <div class="muted" style="margin-top:8px;">Alles blijft beschikbaar, maar standaard netjes ingeklapt.</div>
            <div id="systemHistoryList" style="display:grid; gap:10px;"></div>
          </details>
        </div>
      </section>

      <section class="adminSection" id="adminSection-jobs" data-section="jobs">
        <div class="card">
          <details id="jobsDetails">
            <summary class="jobsSummary">
              <span>Jobs</span>
              <span class="muted" style="font-weight:600; font-size:12px;">Technische joblijst — standaard ingeklapt</span>
            </summary>
            <div class="jobsCollapsedHint">Open alleen wanneer je technische jobs of orphan runs wilt controleren.</div>
            <div class="row" style="margin-top:12px;">
              <div>
                <div style="font-weight:800">Technische jobs</div>
                <div class="muted">Inbox blijft de hoofdflow. Deze lijst is puur voor controle/debug.</div>
              </div>
              <button class="secondary" onclick="load()">Ververs</button>
            </div>
            <div id="out" style="margin-top:10px"></div>
          </details>
        </div>
      </section>
    </div>
  </div>
</main>
<script>
// ADMIN guard: prevent double-execution (hot reload / injected twice)
if (window.__ADMIN_JS_LOADED__) { console.warn('Admin JS already loaded'); } else {
  window.__ADMIN_JS_LOADED__ = true;

	function _zaagFile(z){ return (typeof z === 'string') ? z : (z && z.file ? z.file : ''); }
	function _zaagLabel(z){ return (typeof z === 'string') ? z : (z && (z.label || z.file) ? (z.label || z.file) : ''); }
	function _h(s){
	  return String(s==null?'':s).replace(/[&<>"']/g, c=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
	}
	function _jobLabel(j){
	  const cn = String((j && j.customerName) ? j.customerName : '').trim();
	  const id = String((j && j.jobId) ? j.jobId : '');
	  return cn ? (_h(cn) + ' · ' + _h(id)) : _h(id);
	}
window.reloadPricing = async function reloadPricing(){
  const st = document.getElementById('pricingStatus');
  const meta = document.getElementById('pricingMeta');
  if(st) st.textContent = 'laden...';
  try{
    const r = await fetch('/api/admin/pricing', {cache:'no-store'});
    const j = await r.json();
    window.__pricingCfg = j;
    const pricing = j.pricing || {};
    const defaults = pricing.defaults || {};
    const rounding = defaults.rounding || {};
    const sell = j.sellPricing || {};
    const setVal = (id, val) => { const el = document.getElementById(id); if(el) el.value = (val !== undefined && val !== null) ? String(val) : ''; };
    setVal('priceSheetMargin', defaults.sheetMarginMm);
    setVal('priceNestingGap', defaults.nestingGapMm);
    setVal('priceKerf', defaults.kerfMm);
    setVal('priceMoneyDecimals', rounding.moneyDecimals);
    setVal('priceMetersDecimals', rounding.metersDecimals);
    setVal('priceSheetFactor', sell.sheetPriceFactor);
    setVal('priceEdgeBand', sell.edgeBandPricePerM);
    setVal('priceCnc', sell.cncCostPerSheet);
    setVal('priceDrawing', sell.drawingCostFixed);
    setVal('priceTransport', sell.transportCostFixed);
    if(st) st.textContent = 'geladen';
    if(meta) meta.textContent = 'Live configuratie geladen';
  }catch(e){
    if(st) st.textContent = 'fout bij laden: ' + (e && e.message ? e.message : e);
    if(meta) meta.textContent = 'Kon pricing-config niet laden';
  }
}

function pricingReadNumber(id, label, integerOnly=false){
  const el = document.getElementById(id);
  const raw = String(el && el.value!=null ? el.value : '').trim().replace(',', '.');
  if(!raw) throw new Error(label + ' is leeg');
  const n = integerOnly ? parseInt(raw, 10) : parseFloat(raw);
  if(!Number.isFinite(n)) throw new Error(label + ' is ongeldig');
  if(n < 0) throw new Error(label + ' mag niet negatief zijn');
  return integerOnly ? Math.round(n) : n;
}

window.savePricing = async function savePricing(){
  const st = document.getElementById('pricingStatus');
  const meta = document.getElementById('pricingMeta');
  if(st) st.textContent = 'opslaan...';
  try{
    const base = window.__pricingCfg ? JSON.parse(JSON.stringify(window.__pricingCfg)) : null;
    const cfg = base || await (async()=>{ const r = await fetch('/api/admin/pricing', {cache:'no-store'}); return await r.json(); })();
    cfg.pricing = cfg.pricing || {};
    cfg.pricing.defaults = cfg.pricing.defaults || {};
    cfg.pricing.defaults.rounding = cfg.pricing.defaults.rounding || {};
    cfg.sellPricing = cfg.sellPricing || {};
    cfg.pricing.defaults.sheetMarginMm = pricingReadNumber('priceSheetMargin', 'Plaatmarge');
    cfg.pricing.defaults.nestingGapMm = pricingReadNumber('priceNestingGap', 'Nesting gap');
    cfg.pricing.defaults.kerfMm = pricingReadNumber('priceKerf', 'Kerf');
    cfg.pricing.defaults.rounding.moneyDecimals = pricingReadNumber('priceMoneyDecimals', 'Bedragen afronden', true);
    cfg.pricing.defaults.rounding.metersDecimals = pricingReadNumber('priceMetersDecimals', 'Meters afronden', true);
    cfg.sellPricing.sheetPriceFactor = pricingReadNumber('priceSheetFactor', 'Plaatfactor');
    cfg.sellPricing.edgeBandPricePerM = pricingReadNumber('priceEdgeBand', 'Kantenband per meter');
    cfg.sellPricing.cncCostPerSheet = pricingReadNumber('priceCnc', 'CNC per plaat');
    cfg.sellPricing.drawingCostFixed = pricingReadNumber('priceDrawing', 'Tekenwerk vast');
    cfg.sellPricing.transportCostFixed = pricingReadNumber('priceTransport', 'Transport vast');

    const r = await fetch('/api/admin/pricing', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(cfg)});
    const j = await r.json();
    if(!r.ok){ if(st) st.textContent = 'fout: ' + (j.error || r.status); return; }
    if(st) st.textContent = 'opgeslagen (' + (j.version || 'ok') + ')';
    if(meta) meta.textContent = 'Laatste save: ' + (j.version || 'ok');
    window.__pricingCfg = cfg;
  }catch(e){
    if(st) st.textContent = 'fout bij opslaan: ' + (e && e.message ? e.message : e);
  }
}

function _escapeHtml(s){ return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function _fmtBytes(n){ n = Number(n||0); if(n < 1024) return n + ' B'; if(n < 1024*1024) return (n/1024).toFixed(1) + ' KB'; if(n < 1024*1024*1024) return (n/1024/1024).toFixed(1) + ' MB'; return (n/1024/1024/1024).toFixed(1) + ' GB'; }
function _systemTone(it){
  return (it.level === 'error') ? 'rgba(255,107,107,.14)' : (it.level === 'warning' ? 'rgba(255,196,87,.12)' : 'rgba(47,191,106,.08)');
}
function _systemRefs(it){
  return [it.requestId ? ('Request: ' + it.requestId) : '', it.jobId ? ('Job: ' + it.jobId) : '', it.customerName ? ('Klant: ' + it.customerName) : ''].filter(Boolean).join(' · ');
}
function _renderSystemDetailCard(it){
  const user = _escapeHtml(it.messageUser || 'Onbekende melding');
  const tech = _escapeHtml(it.messageTech || '—');
  const meta = [it.component || 'systeem', it.level || 'info', it.ts || ''].filter(Boolean).join(' · ');
  const refs = _systemRefs(it);
  return `<details class="card systemLogItem" style="padding:0; border-color:rgba(255,255,255,.08); background:${_systemTone(it)}; overflow:hidden;">
    <summary style="list-style:none; cursor:pointer; padding:14px; display:grid; gap:8px;">
      <div style="display:flex; justify-content:space-between; gap:10px; align-items:start;">
        <div style="font-weight:900;">${user}</div>
        <div class="pill">${_escapeHtml(it.status || 'open')}</div>
      </div>
      <div class="muted">${_escapeHtml(meta)}</div>
      ${refs ? `<div style="font-size:12px; color:#e6f2ec;">${_escapeHtml(refs)}</div>` : ''}
    </summary>
    <div style="padding:0 14px 14px 14px;">
      <div style="border:1px solid rgba(255,255,255,.08); border-radius:12px; padding:10px 12px; background:rgba(10,14,12,.26);">
        <div style="font-size:12px; font-weight:800; color:#b9c9c0; margin-bottom:4px;">Technische details</div>
        <code style="white-space:pre-wrap; word-break:break-word; font-size:12px; color:#f4f7f5;">${tech}</code>
      </div>
    </div>
  </details>`;
}
function _renderSystemCompactRow(it){
  const refs = _systemRefs(it);
  const meta = [it.component || 'systeem', it.ts || ''].filter(Boolean).join(' · ');
  return `<div class="card" style="padding:12px 14px; background:${_systemTone(it)}; display:grid; gap:5px;">
    <div style="display:flex; justify-content:space-between; gap:10px; align-items:start;">
      <div style="font-weight:800;">${_escapeHtml(it.messageUser || 'Onbekende melding')}</div>
      <div class="pill">${_escapeHtml(it.status || 'resolved')}</div>
    </div>
    <div class="muted">${_escapeHtml(meta)}</div>
    ${refs ? `<div style="font-size:12px; color:#dfeae4;">${_escapeHtml(refs)}</div>` : ''}
  </div>`;
}
async function refreshSystemPage(){
  const logsStatus = document.getElementById('systemLogsStatus');
  const openIssuesList = document.getElementById('systemOpenIssuesList');
  const recentActionsList = document.getElementById('systemRecentActionsList');
  const historyList = document.getElementById('systemHistoryList');
  const backupStatus = document.getElementById('systemBackupStatus');
  const backupsList = document.getElementById('systemBackupsList');
  const openIssuesCount = document.getElementById('systemOpenIssuesCount');
  const recentActionsCount = document.getElementById('systemRecentActionsCount');
  const historyCount = document.getElementById('systemHistoryCount');
  const backupsCount = document.getElementById('systemBackupsCount');
  if(logsStatus) logsStatus.textContent = 'Systeemmeldingen laden…';
  if(backupStatus) backupStatus.textContent = 'Backups laden…';
  try{
    const [lr, br] = await Promise.all([
      fetch('/api/admin/system/logs', {cache:'no-store', credentials:'same-origin'}),
      fetch('/api/admin/system/backups', {cache:'no-store', credentials:'same-origin'})
    ]);
    const lj = await lr.json().catch(()=>({ok:false,error:'Ongeldige log-response'}));
    const bj = await br.json().catch(()=>({ok:false,error:'Ongeldige backup-response'}));
    const logItems = (lr.ok && lj.ok) ? (lj.items||[]) : [];
    const backupItems = (br.ok && bj.ok) ? (bj.items||[]) : [];
    const openItems = logItems.filter(it => {
      const status = String(it && it.status || '').toLowerCase();
      const level = String(it && it.level || '').toLowerCase();
      return status !== 'resolved' || level === 'error' || level === 'warning';
    });
    const recentItems = logItems.filter(it => !openItems.includes(it)).slice(0, 5);
    if(logsStatus) logsStatus.textContent = (lr.ok && lj.ok) ? `${logItems.length||0} meldingen geladen` : ('Fout: ' + (lj.error || ('HTTP ' + lr.status)));
    if(backupStatus) backupStatus.textContent = (br.ok && bj.ok) ? `${backupItems.length||0} backups gevonden` : ('Fout: ' + (bj.error || ('HTTP ' + br.status)));
    if(openIssuesCount) openIssuesCount.textContent = String(openItems.length || 0);
    if(recentActionsCount) recentActionsCount.textContent = String(recentItems.length || 0);
    if(historyCount) historyCount.textContent = String(logItems.length || 0);
    if(backupsCount) backupsCount.textContent = String(backupItems.length || 0);
    if(openIssuesList){
      openIssuesList.innerHTML = openItems.length ? openItems.map(_renderSystemDetailCard).join('') : `<div class="card" style="padding:12px 14px;">Geen open fouten of waarschuwingen.</div>`;
    }
    if(recentActionsList){
      recentActionsList.innerHTML = recentItems.length ? recentItems.map(_renderSystemCompactRow).join('') : `<div class="card" style="padding:12px 14px;">Nog geen recente systeemacties.</div>`;
    }
    if(historyList){
      historyList.innerHTML = logItems.length ? logItems.map(_renderSystemDetailCard).join('') : `<div class="card" style="padding:14px;">Geen systeemmeldingen gevonden.</div>`;
    }
    if(backupsList){
      backupsList.innerHTML = backupItems.length ? backupItems.map(it => `<div class="card" style="padding:12px 14px; display:flex; justify-content:space-between; gap:10px; align-items:center;"><div><div style="font-weight:800; display:flex; align-items:center; gap:10px; flex-wrap:wrap;"><span>${_escapeHtml(it.name || '')}</span><span class="pill">${(it.kind||'manual')==='auto'?'Automatisch':'Handmatig'}</span></div><div class="muted">${_escapeHtml(it.modified || '')}</div></div><div style="display:flex; align-items:center; gap:10px;"><div class="pill">${_fmtBytes(it.size || 0)}</div><a class="btn secondary" href="/api/admin/system/backup_download?name=${encodeURIComponent(it.name || '')}">Download</a></div></div>`).join('') : `<div class="card" style="padding:12px 14px;">Nog geen backups gevonden.</div>`;
    }
  }catch(err){
    if(logsStatus) logsStatus.textContent = 'Fout: ' + (err && err.message || err);
    if(backupStatus) backupStatus.textContent = 'Fout: ' + (err && err.message || err);
  }
}
async function createSystemBackup(){
  const st = document.getElementById('systemBackupStatus');
  if(st) st.textContent = 'Backup wordt gemaakt…';
  try{
    const r = await fetch('/api/admin/system/backup_now', {method:'POST', headers:{'Content-Type':'application/json'}, body:'{}'});
    const j = await r.json().catch(()=>({ok:false,error:'Ongeldige serverresponse'}));
    if(!r.ok || !j.ok){ if(st) st.textContent = 'Fout: ' + (j.error || ('HTTP ' + r.status)); return; }
    if(st) st.textContent = `Backup gemaakt: ${j.file || ''}`;
    refreshSystemPage();
  }catch(err){ if(st) st.textContent = 'Fout: ' + (err && err.message || err); }
}
window.refreshSystemPage = refreshSystemPage;
window.createSystemBackup = createSystemBackup;

function switchAdminSection(section){
  document.querySelectorAll('.adminNavBtn').forEach(btn=>{
    btn.classList.toggle('active', btn.getAttribute('data-section') === section);
  });
  document.querySelectorAll('.adminSection').forEach(sec=>{
    sec.classList.toggle('active', sec.getAttribute('data-section') === section);
  });
  if(section === 'system'){ try{ refreshSystemPage(); }catch(_e){} }
}

function initAdminShell(){
  if(window.__adminShellInit) return;
  window.__adminShellInit = true;
  document.querySelectorAll('.adminNavBtn').forEach(btn=>{
    btn.addEventListener('click', ()=> switchAdminSection(btn.getAttribute('data-section') || 'inbox'));
  });
  switchAdminSection('inbox');
}

let materialsCache = [];
let materialsSelectedKey = '';
function matNum(v){
  const raw = String(v == null ? '' : v).trim().replace(',', '.');
  if(!raw) return null;
  const n = parseFloat(raw);
  return Number.isFinite(n) ? n : null;
}
function materialKeyOf(r){ return String((r && (r.articleNo || r.articleNumber || r.materialCode)) || '').trim(); }
function materialDecorOf(r){ return String((r && (r.decorName || r.productName || r.materialDisplayName || '')) || '').trim(); }
function materialCodeOf(r){ return String((r && (r.materialCode || r.articleNo || '')) || '').trim(); }
function materialsDimensionOf(r){
  const w = materialsFormatDim(r?.sheetWid || r?.sheetWidth || '');
  const l = materialsFormatDim(r?.sheetLen || r?.sheetHeight || r?.height || '');
  return w && l ? (w + '×' + l + ' mm') : '';
}
function materialsThicknessOf(r){
  return materialsFormatDim(r?.thicknessMm || r?.thickness || '');
}
function materialsGetFilterState(){
  return {
    search: String(document.getElementById('materialsSearch')?.value || '').trim().toLowerCase(),
    thickness: String(document.getElementById('materialsFilterThickness')?.value || '').trim(),
    dimension: String(document.getElementById('materialsFilterDimension')?.value || '').trim(),
    category: String(document.getElementById('materialsFilterCategory')?.value || '').trim().toLowerCase(),
    brandText: String(document.getElementById('materialsFilterBrandText')?.value || '').trim().toLowerCase(),
    availability: String(document.getElementById('materialsFilterAvailability')?.value || '').trim(),
  };
}
function materialsActiveFilterCount(){
  const f = materialsGetFilterState();
  return [f.thickness, f.dimension, f.category, f.brandText, f.availability].filter(Boolean).length;
}
function materialsUpdateFiltersToggleLabel(){
  const btn = document.getElementById('materialsFiltersToggle');
  if(!btn) return;
  const n = materialsActiveFilterCount();
  btn.textContent = n ? ('Filters (' + n + ')') : 'Filters';
}
function materialsToggleFilters(forceOpen){
  const panel = document.getElementById('materialsFiltersPanel');
  if(!panel) return;
  const open = forceOpen === true ? true : !(panel.style.display === 'block');
  panel.style.display = open ? 'block' : 'none';
}
function materialsPopulateFilterOptions(){
  const thicknessEl = document.getElementById('materialsFilterThickness');
  const dimEl = document.getElementById('materialsFilterDimension');
  const catEl = document.getElementById('materialsFilterCategory');
  const current = materialsGetFilterState();
  const uniqueSorted = (vals, numeric=false) => Array.from(new Set(vals.filter(Boolean))).sort((a,b)=>{
    if(numeric){ return parseFloat(a) - parseFloat(b); }
    return String(a).localeCompare(String(b), 'nl', {numeric:true, sensitivity:'base'});
  });
  const thicknesses = uniqueSorted(materialsCache.map(r=>materialsThicknessOf(r)), true);
  const dims = uniqueSorted(materialsCache.map(r=>materialsDimensionOf(r)));
  const cats = uniqueSorted(materialsCache.map(r=>String(r.categoryName || '').trim()));
  if(thicknessEl) thicknessEl.innerHTML = '<option value="">Alle diktes</option>' + thicknesses.map(v=>`<option value="${esc(v)}">${esc(v)} mm</option>`).join('');
  if(dimEl) dimEl.innerHTML = '<option value="">Alle afmetingen</option>' + dims.map(v=>`<option value="${esc(v)}">${esc(v)}</option>`).join('');
  if(catEl) catEl.innerHTML = '<option value="">Alle plaatsoorten</option>' + cats.map(v=>`<option value="${esc(v)}">${esc(v)}</option>`).join('');
  if(thicknessEl) thicknessEl.value = current.thickness;
  if(dimEl) dimEl.value = current.dimension;
  if(catEl) catEl.value = current.category ? (cats.find(v=>String(v).toLowerCase()===current.category) || '') : '';
  materialsUpdateFiltersToggleLabel();
}
function materialsFilterRows(){
  const f = materialsGetFilterState();
  return materialsCache.filter(r=>{
    const hay = [r.articleNo, r.articleNumber, r.materialCode, r.decorName, r.productName, r.categoryName, r.shortDescription].map(v=>String(v||'').toLowerCase());
    if(f.search && !hay.some(v=>v.includes(f.search))) return false;
    const thickness = materialsThicknessOf(r);
    if(f.thickness && thickness !== f.thickness) return false;
    const dimension = materialsDimensionOf(r);
    if(f.dimension && dimension !== f.dimension) return false;
    const category = String(r.categoryName || '').trim().toLowerCase();
    if(f.category && category !== f.category) return false;
    if(f.brandText){
      const brandHay = [r.productName, r.decorName, r.shortDescription, r.categoryName, r.articleNo].map(v=>String(v||'').toLowerCase()).join(' | ');
      if(!brandHay.includes(f.brandText)) return false;
    }
    if(f.availability === 'yes' && r.active === false) return false;
    if(f.availability === 'no' && r.active !== false) return false;
    return true;
  });
}
function materialsSetCategoryValue(val){
  const el = document.getElementById('matCategoryName');
  if(!el) return;
  const v = String(val || '').trim();
  if(v && !Array.from(el.options).some(o=>o.value===v)){
    const opt = document.createElement('option');
    opt.value = v;
    opt.textContent = v;
    opt.dataset.dynamic = '1';
    el.appendChild(opt);
  }
  el.value = v;
}
function materialsFormatDim(n){
  const num = Number(n);
  if(!Number.isFinite(num)) return '';
  return Number.isInteger(num) ? String(Math.trunc(num)) : String(num).replace(/\.0+$/,'').replace(/(\.\d*?)0+$/,'$1');
}
function materialsUpdateDerivedFields(){
  if(materialsSelectedKey) return;
  const descEl = document.getElementById('matShortDescription');
  const w = matNum(document.getElementById('matSheetWid')?.value);
  const l = matNum(document.getElementById('matSheetLen')?.value);
  const t = matNum(document.getElementById('matThickness')?.value);
  if(!descEl) return;
  const prevAuto = descEl.dataset.auto === '1';
  const canAuto = prevAuto || !String(descEl.value || '').trim();
  if(!canAuto) return;
  if(w>0 && l>0 && t>0){
    descEl.value = `${materialsFormatDim(l)}x${materialsFormatDim(w)}x${materialsFormatDim(t)}mm`;
    descEl.dataset.auto = '1';
  }else if(prevAuto){
    descEl.value = '';
    descEl.dataset.auto = '0';
  }
}
function materialsSetForm(rec){
  const set=(id,val)=>{ const el=document.getElementById(id); if(el) el.value = (val===undefined||val===null)?'':String(val); };
  set('matArticleNo', rec?.articleNo || rec?.articleNumber || '');
  set('matDecorName', rec?.decorName || '');
  set('matProductName', rec?.productName || '');
  set('matSheetWid', rec?.sheetWid || rec?.sheetWidth || '');
  set('matSheetLen', rec?.sheetLen || rec?.sheetHeight || rec?.height || '');
  set('matThickness', rec?.thicknessMm || rec?.thickness || '');
  set('matPurchasePrice', rec?.purchasePrice ?? rec?.inkoopprijs ?? '');
  materialsSetCategoryValue(rec?.categoryName || '');
  set('matShortDescription', rec?.shortDescription || '');
  const desc = document.getElementById('matShortDescription');
  if(desc) desc.dataset.auto = '0';
  const active = document.getElementById('matActive');
  if(active) active.checked = rec?.active !== false;
  const state = document.getElementById('materialsDetailState');
  if(state) state.textContent = rec ? ('Geselecteerd: ' + (rec.productName || rec.decorName || rec.articleNo || 'materiaal')) : 'Nieuw materiaal';
}
function materialsReadForm(){
  const req=(id,label)=>{ const el=document.getElementById(id); const v=String(el&&el.value!=null?el.value:'').trim(); if(!v) throw new Error(label + ' is leeg'); return v; };
  const articleNo = req('matArticleNo','Artikelnummer');
  const rec = {
    articleNo,
    decorName: req('matDecorName','Decornaam'),
    materialCode: articleNo,
    productName: req('matProductName','Productnaam'),
    sheetWid: matNum(document.getElementById('matSheetWid')?.value),
    sheetLen: matNum(document.getElementById('matSheetLen')?.value),
    thicknessMm: matNum(document.getElementById('matThickness')?.value),
    purchasePrice: matNum(document.getElementById('matPurchasePrice')?.value),
    categoryName: String(document.getElementById('matCategoryName')?.value || '').trim(),
    shortDescription: String(document.getElementById('matShortDescription')?.value || '').trim(),
    active: !!document.getElementById('matActive')?.checked,
  };
  if(!(rec.sheetWid>0)) throw new Error('Breedte plaat moet groter zijn dan 0');
  if(!(rec.sheetLen>0)) throw new Error('Lengte plaat moet groter zijn dan 0');
  if(!(rec.thicknessMm>0)) throw new Error('Dikte moet groter zijn dan 0');
  if(!(rec.purchasePrice>0)) throw new Error('Inkoopprijs moet groter zijn dan 0');
  if(!rec.categoryName) throw new Error('Kies een categorie');
  rec.inkoopprijs = rec.purchasePrice;
  return rec;
}
function materialsRenderList(){
  const list = document.getElementById('materialsList');
  const meta = document.getElementById('materialsMeta');
  if(!list) return;
  const rows = materialsFilterRows();
  const activeCount = materialsActiveFilterCount();
  if(meta) meta.textContent = rows.length + ' van ' + materialsCache.length + ' materialen zichtbaar' + (activeCount ? (' · ' + activeCount + ' filter' + (activeCount===1?'':'s') + ' actief') : '');
  materialsUpdateFiltersToggleLabel();
  if(!rows.length){ list.innerHTML = '<div class="muted">Geen materialen gevonden.</div>'; return; }
  list.innerHTML = rows.map(r=>{
    const key = materialKeyOf(r);
    const title = esc(r.productName || r.decorName || r.articleNo || 'Materiaal');
    const meta = [r.articleNo, r.materialCode, materialsDimensionOf(r), materialsThicknessOf(r) ? (materialsThicknessOf(r) + ' mm') : '', r.categoryName || ''].filter(Boolean).map(esc).join('<span>·</span>');
    return `<button class="materialsRow${materialsSelectedKey===key?' active':''}" type="button" data-key="${esc(key)}"><div class="materialsRowTitle">${title}</div><div class="materialsRowMeta">${meta}</div></button>`;
  }).join('');
  list.querySelectorAll('.materialsRow').forEach(btn=>btn.addEventListener('click', ()=>{
    const key = btn.getAttribute('data-key') || '';
    const rec = materialsCache.find(x=>materialKeyOf(x)===key) || null;
    materialsSelectedKey = key;
    materialsSetForm(rec);
    materialsRenderList();
  }));
}
window.materialsNew = function materialsNew(){ materialsSelectedKey=''; materialsSetForm(null); materialsRenderList(); const st=document.getElementById('materialsStatus'); if(st) st.textContent='Nieuw materiaal'; };
window.materialsReload = async function materialsReload(){
  const st = document.getElementById('materialsStatus');
  if(st) st.textContent='laden...';
  try{
    const r = await fetch('/api/admin/materials/library', {cache:'no-store'});
    const j = await r.json();
    if(!r.ok || !j.ok) throw new Error(j.error || ('HTTP ' + r.status));
    materialsCache = Array.isArray(j.records) ? j.records : [];
    materialsPopulateFilterOptions();
    const chosen = materialsSelectedKey ? materialsCache.find(x=>materialKeyOf(x)===materialsSelectedKey) : null;
    materialsSetForm(chosen || null);
    materialsRenderList();
    if(st) st.textContent='geladen';
  }catch(e){ if(st) st.textContent='fout bij laden: ' + (e && e.message ? e.message : e); }
};
window.materialsSave = async function materialsSave(){
  const st = document.getElementById('materialsStatus');
  if(st) st.textContent='opslaan...';
  try{
    const rec = materialsReadForm();
    const prevArticleNo = materialsSelectedKey || null;
    const r = await fetch('/api/admin/materials/save_item', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({prevArticleNo, record: rec})});
    const j = await r.json();
    if(!r.ok || !j.ok) throw new Error(j.error || ('HTTP ' + r.status));
    materialsSelectedKey = rec.articleNo;
    await materialsReload();
    if(st) st.textContent='opgeslagen';
  }catch(e){ if(st) st.textContent='fout: ' + (e && e.message ? e.message : e); }
};
window.materialsDelete = async function materialsDelete(){
  const st = document.getElementById('materialsStatus');
  const articleNo = materialsSelectedKey || String(document.getElementById('matArticleNo')?.value || '').trim();
  if(!articleNo){ if(st) st.textContent='Kies eerst een materiaal.'; return; }
  if(!confirm('Weet je zeker dat je dit materiaal wilt verwijderen?')) return;
  if(st) st.textContent='verwijderen...';
  try{
    const r = await fetch('/api/admin/materials/delete_item', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({articleNo})});
    const j = await r.json();
    if(!r.ok || !j.ok) throw new Error(j.error || ('HTTP ' + r.status));
    materialsSelectedKey='';
    materialsSetForm(null);
    await materialsReload();
    if(st) st.textContent='verwijderd';
  }catch(e){ if(st) st.textContent='fout: ' + (e && e.message ? e.message : e); }
};
async function materialsUploadJson(){
  const inp = document.getElementById('matJsonInput');
  const st = document.getElementById('matJsonStatus');
  if(!inp || !inp.files || !inp.files.length){ if(st) st.textContent='Kies eerst een JSON bestand.'; return; }
  const text = await inp.files[0].text();
  try{ JSON.parse(text); }catch(e){ if(st) st.textContent='Ongeldige JSON.'; return; }
  const r = await fetch('/api/admin/materials/upload', {method:'POST', headers:{'Content-Type':'application/json'}, body:text});
  const j = await r.json().catch(()=>({}));
  if(st) st.textContent = (r.ok && j.ok) ? 'Upload OK. Material Library vervangen.' : ('Fout: ' + (j.error || ('HTTP ' + r.status)));
  inp.value='';
  if(r.ok && j.ok) await materialsReload();
}
function materialsResetFilters(){
  const ids = ['materialsFilterThickness','materialsFilterDimension','materialsFilterCategory','materialsFilterBrandText','materialsFilterAvailability'];
  ids.forEach(id=>{ const el=document.getElementById(id); if(el) el.value=''; });
  materialsRenderList();
}
function initMaterialsManager(){
  if(window.__materialsManagerInit) return;
  window.__materialsManagerInit = true;
  const s = document.getElementById('materialsSearch');
  if(s) s.addEventListener('input', ()=>materialsRenderList());
  const toggle = document.getElementById('materialsFiltersToggle');
  if(toggle) toggle.addEventListener('click', ()=>materialsToggleFilters());
  const reset = document.getElementById('materialsResetFiltersBtn');
  if(reset) reset.addEventListener('click', materialsResetFilters);
  ['materialsFilterThickness','materialsFilterDimension','materialsFilterCategory','materialsFilterBrandText','materialsFilterAvailability'].forEach(id=>{
    const el = document.getElementById(id);
    if(el) el.addEventListener(id==='materialsFilterBrandText' ? 'input' : 'change', ()=>materialsRenderList());
  });
  const up = document.getElementById('matJsonUploadBtn');
  if(up) up.addEventListener('click', materialsUploadJson);
  ['matArticleNo','matSheetWid','matSheetLen','matThickness'].forEach(id=>{
    const el = document.getElementById(id);
    if(el) el.addEventListener('input', materialsUpdateDerivedFields);
  });
  const desc = document.getElementById('matShortDescription');
  if(desc) desc.addEventListener('input', ()=>{ desc.dataset.auto = '0'; });
  materialsUpdateFiltersToggleLabel();
}

async function loadControlCenter(){
  const el = document.getElementById('ccOut');
  if(!el) return;
  try{
    const r = await fetch('/api/admin/control_center', {cache:'no-store'});
    const j = await r.json();
    const v = j.versions || {};
    const s = j.storage || {};
    const f = j.failures || [];
    const pricing = v.pricing || {};
    const materials = v.materials || {};
    const dxf = v.dxfLibrary || {};
    const opt = v.optimizer || {};
    function fmtBytes(n){
      n = Number(n||0);
      const u=['B','KB','MB','GB','TB']; let i=0;
      while(n>=1024 && i<u.length-1){ n/=1024; i++; }
      return (i===0? String(Math.round(n)) : n.toFixed(1)) + ' ' + u[i];
    }
    let html = '';
    html += `<div style="display:grid; gap:8px;">`;
    html += `<div><b>Actief nu</b></div>`;
    html += `<div>💶 Prijzen: <code>${pricing.exists? 'pricing_active.json' : '—'}</code> <span class="muted">${pricing.modified?('(' + pricing.modified + ')'):''}</span></div>`;
    html += `<div>🪵 Materialen: <code>${materials.file||'material_library.json'}</code> <span class="muted">${materials.modified?('(' + materials.modified + ')'):''}</span></div>`;
    html += `<div>📐 DXF lijst: <code>${dxf.file||'embedded_dxfs_manifest.json'}</code> <span class="muted">${dxf.modified?('(' + dxf.modified + ')'):''}</span></div>`;
    html += `<div>🧠 Optimizer: <code>${opt.active||'—'}</code></div>`;
    html += `<hr style="border:0; border-top:1px solid rgba(255,255,255,.08); margin:6px 0;">`;
    html += `<div><b>Opslag</b></div>`;
    html += `<div>Jobs: <code>${s.jobsCount??'—'}</code> · Grootte jobs-map: <code>${fmtBytes(s.jobsBytes||0)}</code></div>`;
    if(s.largestJob && s.largestJob.jobId){
      html += `<div>Grootste job: <code>${_h(s.largestJob.jobId)}</code> · <code>${fmtBytes(s.largestJob.bytes||0)}</code></div>`;
    }
    if(f && f.length){
      html += `<hr style="border:0; border-top:1px solid rgba(255,255,255,.08); margin:6px 0;">`;
      html += `<div><b>Laatste fouten</b> <span class="muted">(laatste 5)</span></div>`;
      for(const x of f){
        html += `<div style="padding:8px 10px; border:1px solid rgba(255,255,255,.08); border-radius:10px; background:#0e1416;">`
             + `<div><code>${_h(x.jobId||'')}</code> <span class="muted">${_h(x.modified||'')}</span></div>`
             + `<div class="muted" style="white-space:pre-wrap; margin-top:4px;">${_h(x.excerpt||'')}</div>`
             + `</div>`;
      }
    }else{
      html += `<div class="muted">Geen recente fouten gevonden.</div>`;
    }
    html += `</div>`;
    el.className = '';
    el.innerHTML = html;
  }catch(e){
    el.className = 'muted';
    el.textContent = 'Kon beheer-info niet laden: ' + (e && e.message ? e.message : e);
  }
}

// --- Mailbox (Requests) ---
let mb_tab = 'inbox';
let mb_cache = [];
let mb_openRid = null;
function mb_dotClass(st){
  const pub = String(st.publicStatus||'').toUpperCase();
  const intr = String(st.internalStatus||'').toUpperCase();
  if(pub === 'CANCELLED') return 'gray';
  if(intr === 'FAILED' || pub === 'FAILED' || pub === 'ERROR') return 'red';
  if(pub === 'DONE' || pub === 'AFGEHANDELD') return 'yellow';
  if(pub === 'OFFER_SENT' || pub === 'IN_PRODUCTION' || intr === 'PROCESSING') return 'blue';
  if(pub === 'SUBMITTED') return 'green';
  return 'gray';
}
function mb_statusBadge(label, cls){
  return `<span class="mbBadge ${cls}">${esc(label||'—')}</span>`;
}
function mb_matchesTab(st){
  const pub = String(st.publicStatus||'').toUpperCase();
  const intr = String(st.internalStatus||'').toUpperCase();
  if(mb_tab === 'inbox') return pub === 'SUBMITTED';
  if(mb_tab === 'processing') return (pub === 'OFFER_SENT' || pub === 'IN_PRODUCTION' || intr === 'PROCESSING');
  if(mb_tab === 'errors') return intr === 'FAILED' || pub === 'FAILED' || pub === 'ERROR';
  if(mb_tab === 'afgehandeld') return pub === 'DONE' || pub === 'AFGEHANDELD';
  if(mb_tab === 'alles') return true;
  return true;
}
function mb_matchesSearch(st, q){
  q = String(q||'').trim().toLowerCase();
  if(!q) return true;
  const rid = String(st.requestId||'').toLowerCase();
  const cn = String(st.customer?.name||'').toLowerCase();
  return rid.includes(q) || cn.includes(q);
}
function mb_money(v){ const n = Number(v); return Number.isFinite(n) ? new Intl.NumberFormat('nl-NL',{style:'currency',currency:'EUR'}).format(n) : '—'; }
function mb_formatBytes(v){
  const n = Number(v||0);
  if(!Number.isFinite(n) || n <= 0) return '0 B';
  const units = ['B','KB','MB','GB','TB'];
  let i = 0; let val = n;
  while(val >= 1024 && i < units.length-1){ val /= 1024; i++; }
  const digits = (i === 0 ? 0 : (val >= 100 ? 0 : val >= 10 ? 1 : 2));
  return `${val.toFixed(digits)} ${units[i]}`;
}
function mb_renderStorageSummary(ss){
  if(!ss || typeof ss !== 'object') return '';
  const total = Number(ss.totalBytes||0);
  if(!Number.isFinite(total) || total <= 0) return '';
  const jobs = Number(ss.jobsBytes||0);
  const req = Number(ss.requestBytes||0);
  const bits = [];
  if(jobs > 0) bits.push(`Jobs ${mb_formatBytes(jobs)}`);
  if(req > 0) bits.push(`Request ${mb_formatBytes(req)}`);
  return `<div class="mbSectionTitle">Opslag</div><div class="mbPriceCard"><div class="mbPriceRow emph"><span>Totale jobgrootte</span><strong>${esc(mb_formatBytes(total))}</strong></div><div class="mbFileMeta" style="margin-top:8px;">${esc(bits.join(' · '))}</div></div>`;
}
function mb_renderPricingSummary(ps){
  if(!ps || typeof ps !== 'object') return '';
  const rows = [];
  const push = (label, val, emph=false) => { if(val===null || val===undefined || val==='') return; rows.push(`<div class="mbPriceRow${emph?' emph':''}"><span>${esc(label)}</span><strong>${esc(mb_money(val))}</strong></div>`); };
  const totalEx = (ps.subtotalExVat!==null && ps.subtotalExVat!==undefined) ? ps.subtotalExVat : null;
  const totalIncl = (ps.totalInclVat!==null && ps.totalInclVat!==undefined) ? ps.totalInclVat : null;
  if(totalEx===null && totalIncl===null) return '';
  push('Totaal ex. btw', totalEx, false);
  push('Totaal incl. btw', totalIncl, true);
  return `<div class="mbSectionTitle">Prijs</div><div class="mbPriceCard">${rows.join('')}</div>`;
}
function mb_renderFileActions(manifest){
  const parts = [];
  const zip = manifest?.zip || {};
  const pricingSummary = manifest?.pricingSummary || {};
  const storageSummary = manifest?.storageSummary || {};
  const summaryFiles = Array.isArray(manifest?.summaryFiles) ? manifest.summaryFiles : [];
  const groups = Array.isArray(manifest?.dxfGroups) ? manifest.dxfGroups : [];
  const summaryKinds = ['quote','report','placements','stickertool','stickers','summary','pricing'];
  const labels = {quote:'Quote', report:'Report', placements:'Placements', stickers:'Stickers', stickertool:'Stickertool', summary:'Berekening', pricing:'Pricing'};
  parts.push(`<div class="mbSectionTitle">Downloads</div>`);
  parts.push(`<div class="mbFileGrid">`);
  if(zip.allOutputsUrl) parts.push(`<a class="pill premiumPill" download onclick="event.stopPropagation();" href="${esc(zip.allOutputsUrl)}">Alles ZIP</a>`);
  if(zip.allDxfUrl) parts.push(`<a class="pill premiumPill" download onclick="event.stopPropagation();" href="${esc(zip.allDxfUrl)}">Alle DXF's ZIP</a>`);
  for(const kind of summaryKinds){
    const f = summaryFiles.find(x => String(x.kind||'')===kind);
    if(f) parts.push(`<a class="pill premiumPill" download onclick="event.stopPropagation();" href="${esc(f.url||'#')}">${esc(labels[kind]||f.name||kind)}</a>`);
  }
  parts.push(`</div>`);
  parts.push(mb_renderStorageSummary(storageSummary));
  parts.push(mb_renderPricingSummary(pricingSummary));
  parts.push(`<div class="mbSectionTitle">DXF bestanden</div>`);
  if(!groups.length){
    parts.push(`<div class="muted">Geen DXF bestanden gevonden voor deze order.</div>`);
  } else {
    for(const g of groups){
      const glabel = esc(g.label || g.materialName || g.materialCode || g.jobId || 'DXF');
      parts.push(`<div class="mbFileGroup"><div class="mbFileGroupHead">${glabel}</div>`);
      for(const f of (g.files || [])){
        const meta = [];
        if(f.size) meta.push(Math.max(1, Math.round(Number(f.size||0)/1024)) + ' KB');
        if(f.mtime) meta.push(String(f.mtime).replace('T',' ').replace('Z',''));
        parts.push(`<div class="mbFileLine"><div><div style="font-family:ui-monospace,Menlo,monospace; font-size:12px;">${esc(f.name||'')}</div><div class="mbFileMeta">${esc(meta.join(' · '))}</div></div><a class="pill" onclick="event.stopPropagation();" href="${esc(f.url||'#')}">Download</a></div>`);
      }
      parts.push(`</div>`);
    }
  }
  return parts.join('');
}

async function mb_loadRequestFiles(rid){
  const box = document.getElementById('mbFilesBox');
  if(!box) return;
  box.innerHTML = `<div class="muted">Bestanden laden…</div>`;
  try{
    const r = await fetch('/api/admin/request_files?requestId=' + encodeURIComponent(rid), {cache:'no-store'});
    const j = await r.json().catch(()=>({}));
    if(!r.ok || !j.ok){
      box.innerHTML = `<div class="muted">Kon bestanden niet laden.</div>`;
      return;
    }
    box.innerHTML = mb_renderFileActions(j.files || {});
  }catch(e){
    box.innerHTML = `<div class="muted">Kon bestanden niet laden.</div>`;
  }
}

function mb_setDetails(st){
  const det = document.getElementById('mbDetails');
  const body = document.getElementById('mbDetailsBody');
  if(!det || !body) return;
  document.querySelectorAll('#mbTbody tr.mbRow').forEach(row=>row.classList.toggle('active', !!st && String(row.getAttribute('data-rid')||'')===String(st.requestId||'')));
  if(!st){
    mb_openRid = null;
    det.open = false;
    det.style.display='none';
    try{ if(location.hash && location.hash.startsWith('#request=')) history.replaceState(null,'',location.pathname + location.search); }catch(e){}
    return;
  }
  mb_openRid = String(st.requestId||'');
  det.style.display='block';
  const err = st.error ? JSON.stringify(st.error, null, 2) : '';
  const job = st.job || {};
  const sj = Array.isArray(job.subjobs) ? job.subjobs : [];
  const customerName = st.customer?.name || '—';
  const dot = mb_dotClass(st);
  const pub = String(st.publicStatusLabel || st.publicStatus || '—');
  const intr = String(st.internalStatusLabel || st.internalStatus || '—');
  const parts = [];
  parts.push(`<div class="mbDetailsCard">`);
  parts.push(`<div class="mbDetailsHead"><div style="font-weight:900; font-size:15px;">Orderdetails</div><div class="mbBadgeRow">${mb_statusBadge(pub, dot)}${mb_statusBadge(intr, dot==='green'?'gray':dot)}</div></div>`);
  parts.push(`<div class="mbDetailsBody">`);
  parts.push(`<div class="mbInfoGrid">`);
  parts.push(`<div class="mbInfoCard"><div class="mbLabel">Request</div><div class="mbValue mono">${esc(st.requestId||'')}</div></div>`);
  parts.push(`<div class="mbInfoCard"><div class="mbLabel">Klant</div><div class="mbValue">${esc(customerName)}</div>${st.customer?.email ? `<div class="mbFileMeta">${esc(st.customer.email)}</div>` : ``}${st.customer?.phone ? `<div class="mbFileMeta">${esc(st.customer.phone)}</div>` : ``}</div>`);
  parts.push(`<div class="mbInfoCard"><div class="mbLabel">Job</div><div class="mbValue mono">${esc(job.parentJobId||'—')}</div><div class="mbFileMeta">Subjobs: ${esc(String(sj.length||0))}</div></div>`);
  parts.push(`<div class="mbInfoCard"><div class="mbLabel">Aangemaakt</div><div class="mbValue mono">${esc(st.createdAt||'—')}</div></div>`);
  parts.push(`</div>`);
  parts.push(`<div id="mbFilesBox" style="margin-top:12px;"></div>`);
  if(err){
    parts.push(`<div style="margin-top:12px;"><div class="mbLabel">Error</div><pre style="white-space:pre-wrap; background:rgba(255,255,255,.03); border:1px solid rgba(255,255,255,.08); padding:12px; border-radius:12px;">${esc(err)}</pre></div>`);
  }
  parts.push(`</div></div>`);
  body.innerHTML = parts.join('');
  try{ det.open = true; }catch(e){}
  mb_loadRequestFiles(st.requestId||'');
}

async function mb_load(){
  const tb = document.getElementById('mbTbody');
  if(tb) tb.innerHTML = `<tr><td colspan="7" class="muted">laden…</td></tr>`;
  const r = await fetch('/api/admin/requests?limit=500', {cache:'no-store', credentials:'same-origin'});
  const j = await r.json().catch(()=>({}));
  mb_cache = (j.requests || []);
  mb_render();
}
function mb_render(){
  const tb = document.getElementById('mbTbody');
  if(!tb) return;
  const q = document.getElementById('mbSearch')?.value || '';
  const rows = mb_cache.filter(st=>mb_matchesTab(st) && mb_matchesSearch(st, q));
  if(!rows.length){
    tb.innerHTML = `<tr><td colspan="7" class="muted">Geen items</td></tr>`;
    mb_setDetails(null);
    return;
  }
  let html = '';
  for(const st of rows){
    const dot = mb_dotClass(st);
    const rid = esc(st.requestId||'');
    const cn = esc(st.customer?.name||'—');
    const pub = esc(st.publicStatus||'');
    const intr = esc(st.internalStatus||'');
    const created = esc(st.createdAt||'');
    const canMark = (String(st.publicStatus||'').toUpperCase()==='SUBMITTED' && String(st.quoteStatus||'').toUpperCase()==='TODO');
    html += `<tr class="mbRow" data-rid="${rid}">
      <td><span class="dot ${dot}"></span></td>
      <td style="font-family:ui-monospace,Menlo,monospace; font-size:12px;">${rid}</td>
      <td>${cn}</td>
      <td>${mb_statusBadge(pub, dot)}</td>
      <td>${mb_statusBadge(intr, dot==='green'?'gray':dot)}</td>
      <td style="font-size:12px;">${created}</td>
      <td>
        ${canMark ? `<button class="mbActionBtn" data-act="sent" data-rid="${rid}" type="button">Aanvraag afhandelen</button>` : ``}
        ${(!canMark && (['AFGEHANDELD','DONE'].includes(String(st.publicStatus||'').toUpperCase()))) ? `<button class="mbActionBtn" data-act="reopen" data-rid="${rid}" type="button">Heropen</button>` : ``}
      </td>
    </tr>`;
  }
  tb.innerHTML = html;
  tb.querySelectorAll('tr.mbRow').forEach(tr=>{
    tr.addEventListener('click', (ev)=>{
      const rid = String(tr.getAttribute('data-rid')||'');
      const isSameOpen = (mb_openRid === rid) && !!document.getElementById('mbDetails') && document.getElementById('mbDetails').style.display !== 'none';
      if(isSameOpen){
        mb_setDetails(null);
        return;
      }
      const st = mb_cache.find(x=>String(x.requestId||'')===rid);
      mb_setDetails(st||null);
      try{ location.hash = 'request=' + rid; }catch(e){}
    });
  });
  tb.querySelectorAll('button[data-act]').forEach(btn=>{
    btn.addEventListener('click', async (ev)=>{
      ev.stopPropagation();
      const rid = btn.getAttribute('data-rid');
      const act = btn.getAttribute('data-act');
      btn.disabled = true;
      const rr = await fetch('/api/admin/requests/update', {method:'POST', credentials:'same-origin', headers:{'Content-Type':'application/json'}, body: JSON.stringify({requestId: rid, action: act==='sent'?'mark_quote_sent':'reopen'})});
      await rr.json().catch(()=>({}));
      await mb_load();
    });
  });
}
function mb_init(){
  const tabs = document.getElementById('mbTabs');
  const search = document.getElementById('mbSearch');
  const ref = document.getElementById('mbRefreshBtn');
  if(tabs && !tabs.__bound){
    tabs.querySelectorAll('button.tabBtn').forEach(b=>{
      b.addEventListener('click', ()=>{
        tabs.querySelectorAll('button.tabBtn').forEach(x=>x.classList.remove('active'));
        b.classList.add('active');
        mb_tab = b.getAttribute('data-tab')||'alles';
        mb_render();
      });
    });
    tabs.__bound=true;
  }
  if(search && !search.__bound){
    search.addEventListener('input', ()=>mb_render());
    search.__bound=true;
  }
  if(ref && !ref.__bound){
    ref.addEventListener('click', ()=>mb_load());
    ref.__bound=true;
  }
  // hash jump
  try{
    if(location.hash && location.hash.startsWith('#request=')){
      const rid = decodeURIComponent(location.hash.replace('#request=',''));
      const st = mb_cache.find(x=>String(x.requestId||'')===rid);
      if(st) mb_setDetails(st);
    }
  }catch(e){}
}

async function load(){
  initAdminShell();
  reloadPricing();
  loadControlCenter();
  initMaterialsManager();
  materialsReload();
  try{ mb_init(); }catch(e){}
  try{ await mb_load(); }catch(e){}
  const r = await fetch('/api/admin/jobs', {cache:'no-store', credentials:'same-origin'});
  const data = await r.json();
  const el = document.getElementById('out');
  if(!data.jobs.length){ el.innerHTML = '<div class="muted">Nog geen jobs.</div>'; return; }
  let html = '<table><thead><tr><th>JobId</th><th>Status</th><th>Created</th><th>Outputs</th></tr></thead><tbody>';
  const childrenMap = {};
  const masters = [];
  const masterSet = new Set();
  for(const jj of data.jobs){
    const id = String(jj.jobId||'');
    if(id.includes('__mat_')){
      const master = id.split('__mat_')[0];
      (childrenMap[master] = childrenMap[master] || []).push(jj);
    }else{
      masters.push(jj);
      masterSet.add(id);
    }
  }

  function safeKey(s){
    return String(s||'').replace(/[^a-zA-Z0-9_\-]/g,'_');
  }

  for(const j of masters){
    const jid = String(j.jobId||'');
    const gkey = safeKey(jid);
    const kids0 = (childrenMap[j.jobId]||[]);
    const kids = kids0.sort((a,b)=>String(a.jobId||'').localeCompare(String(b.jobId||'')));
    const kidCount = kids.length;

	    const dlZaag = j.zaagplaten && j.zaagplaten.length
	      ? j.zaagplaten.map(z=>{
	          const f=_zaagFile(z), t=_zaagLabel(z);
	          return `<a class=\"btn\" style=\"padding:6px 10px; border-radius:9px; font-size:12px; margin-right:6px\" href=\"/api/jobs/${encodeURIComponent(j.jobId)}/file/${encodeURIComponent('output/DXF_Zaagplaten/' + f)}\">${t}</a>`;
	        }).join('')
	      : '';
    const dlParts = j.onderdelen && j.onderdelen.length
      ? j.onderdelen.map(s=>`<a class=\"btn\" style=\"padding:6px 10px; border-radius:9px; font-size:12px; margin-right:6px\" href=\"/api/jobs/${encodeURIComponent(j.jobId)}/file/${encodeURIComponent('output/DXF_Onderdelen/' + s)}\">${esc(s)}</a>`).join('')
      : '';
    const dlSheetsFallback = j.sheets && j.sheets.length
      ? j.sheets.map(s=>`<a class=\"btn\" style=\"padding:6px 10px; border-radius:9px; font-size:12px; margin-right:6px\" href=\"/api/jobs/${encodeURIComponent(j.jobId)}/download/${encodeURIComponent(s)}\">${esc(s)}</a>`).join('')
      : '';
    const dlSheets = (dlZaag || dlParts)
      ? (`<div style=\"margin-bottom:6px\"><span class=\"muted\">Zaagplaten:</span> ${dlZaag || '<span class=\\"muted\\">—</span>'}</div>`
         + `<div><span class=\"muted\">Onderdelen:</span> ${dlParts || '<span class=\\"muted\\">—</span>'}</div>`)
      : (dlSheetsFallback || '<span class=\"muted\">—</span>');

    const dlMeta = [
  ['labels.json','output/labels.json'],
  ['placements.json','output/placements.json'],
  ['report.json','output/report.json'],
  ['quote.json','output/quote.json'],
  ['calculation_summary.txt','output/calculation_summary.txt'],
  ['toolb_stderr.txt','output/toolb_stderr.txt'],
  ['toolb_stdout.txt','output/toolb_stdout.txt'],
  ['panels.csv','input/panels.csv'],
  ['pricing.json','input/pricing.json']
].map(([t,p])=>{
  const url = `/api/jobs/${encodeURIComponent(j.jobId)}/file/${encodeURIComponent(p)}`;
  if(t==='calculation_summary.txt'){
    return `<a class="btn" style="padding:6px 10px; border-radius:9px; font-size:12px; margin-right:6px; background:rgba(47,191,106,.18); border:1px solid rgba(47,191,106,.35); color:#e8f3ee; font-weight:800" href="${url}" download>Berekening</a>`
         + `<button class="btn secondary" style="padding:6px 10px; border-radius:9px; font-size:12px; margin-right:6px;" type="button" data-open-text-url="${esc(url)}" data-open-text-title="Berekening">Bekijk</button>`;
  }
  return `<a class="btn secondary" style="padding:6px 10px; border-radius:9px; font-size:12px; margin-right:6px;" href="${url}" download>${t}</a>`;
}).join('');

    
    const edgeDecor = j.edgeBandByDecorMeters || {};
    let edgeHtml = '';
    try{
      const keys = Object.keys(edgeDecor||{});
      if(keys.length){
        edgeHtml = '<div style="margin-top:8px"><div class="muted" style="margin-bottom:4px">Kantenband per decor (m):</div>'
          + keys.map(k=>`<div style="display:flex; gap:10px"><div style="min-width:220px; font-weight:800">${esc(k)}</div><div>${Number(edgeDecor[k]||0).toFixed(2)}</div></div>`).join('')
          + `<div style="display:flex; gap:10px; margin-top:6px; padding-top:6px; border-top:1px solid rgba(255,255,255,.12)"><div style="min-width:220px; font-weight:900">Totaal</div><div>${keys.reduce((a,k)=>a+Number(edgeDecor[k]||0),0).toFixed(2)}</div></div>`
          + '</div>';
      }
    }catch(e){}

    const _cntZaag = (j.zaagplaten&&j.zaagplaten.length)?j.zaagplaten.length:0;
    const _cntOnd = (j.onderdelen&&j.onderdelen.length)?j.onderdelen.length:0;
    const _cntMeta = 9; // labels/stickertool/placements/report/quote/berekening/toolb logs/panels/pricing
    const _sum = `DXF: ${_cntZaag+_cntOnd} · Overig: ${_cntMeta}`;
    const _body = `<div class=\"jobOutBody\" style=\"display:flex; flex-wrap:wrap; gap:6px;\">${dlSheets}${dlMeta}</div>` + edgeHtml;
    const dl = `<details class=\"jobOut\"><summary>${_sum}</summary>${_body}</details>`;
    const toggleBtn = kidCount
      ? `<button class="groupToggle" type="button" data-group="${gkey}" aria-expanded="false">▸</button>`
      : `<span style="display:inline-block; width:34px"></span>`;
    const kidBadge = kidCount ? `<span class="muted" style="margin-left:8px">(${kidCount} materiaal)</span>` : '';
    html += `<tr class="masterRow" data-group="${gkey}"><td><div style="display:flex; align-items:center; gap:10px">${toggleBtn}<code>${_jobLabel(j)}</code>${kidBadge}</div></td><td>${esc(j.status||'')}</td><td class="muted">${esc(j.createdAt||'')}</td><td class="outputsTd"><div class="outputsCell">${dl}</div></td></tr>`;
    for(const c of kids){
      // reuse dl generation by temporarily mapping j->c
      const j = c;
      const masterJobId = jid;

	  const hasZaag = !!(j.zaagplaten && j.zaagplaten.length);
	      const dlZaag = j.zaagplaten && j.zaagplaten.length
	        ? j.zaagplaten.map(z=>{
	            const f=_zaagFile(z), t=_zaagLabel(z);
	            return `<a class=\"btn\" style=\"padding:6px 10px; border-radius:9px; font-size:12px; margin-right:6px\" href=\"/api/jobs/${encodeURIComponent(j.jobId)}/file/${encodeURIComponent('output/DXF_Zaagplaten/' + f)}\">${t}</a>`;
	          }).join('')
	        : '';
      const dlParts = j.onderdelen && j.onderdelen.length
        ? j.onderdelen.map(s=>`<a class=\"btn\" style=\"padding:6px 10px; border-radius:9px; font-size:12px; margin-right:6px\" href=\"/api/jobs/${encodeURIComponent(j.jobId)}/file/${encodeURIComponent('output/DXF_Onderdelen/' + s)}\">${esc(s)}</a>`).join('')
        : '';
      const dlSheetsFallback = j.sheets && j.sheets.length
        ? j.sheets.map(s=>`<a class=\"btn\" style=\"padding:6px 10px; border-radius:9px; font-size:12px; margin-right:6px\" href=\"/api/jobs/${encodeURIComponent(j.jobId)}/download/${encodeURIComponent(s)}\">${esc(s)}</a>`).join('')
        : '';
      const partsCount = (j.onderdelen && j.onderdelen.length) ? j.onderdelen.length : 0;
      const partsBlock = partsCount
        ? (`<details>`
            + `<summary class=\"muted\">Onderdelen (${partsCount})</summary>`
            + `<div style=\"margin-top:6px; display:flex; flex-wrap:wrap; gap:6px\">${dlParts}</div>`
          + `</details>`)
        : (`<div><span class=\"muted\">Onderdelen:</span> <span class=\"muted\">—</span></div>`);

      const dlSheets = (dlZaag || dlParts)
        ? (`<div style=\"margin-bottom:6px\"><span class=\"muted\">Zaagplaten:</span> <div style=\"margin-top:6px; display:flex; flex-wrap:wrap; gap:6px\">${dlZaag || '<span class=\\\"muted\\\">—</span>'}</div></div>`
           + partsBlock)
        : (dlSheetsFallback || '<span class=\"muted\">—</span>');
      const dlMeta = [
  ['stickertool.json (v2)','output/stickertool.json'],
  ['labels.json','output/labels.json'],
  ['placements.json','output/placements.json'],
  ['report.json','output/report.json'],
  ['quote.json','output/quote.json'],
  ['calculation_summary.txt','output/calculation_summary.txt'],
  ['toolb_stderr.txt','output/toolb_stderr.txt'],
  ['toolb_stdout.txt','output/toolb_stdout.txt'],
  ['panels.csv','input/panels.csv'],
  ['pricing.json','input/pricing.json']
].map(([t,p])=>{
  const url = (`/api/jobs/${encodeURIComponent(j.jobId)}/file/${encodeURIComponent(p)}`);
  if(t==='calculation_summary.txt'){
    return `<a class=\"btn\" style=\"padding:6px 10px; border-radius:9px; font-size:12px; margin-right:6px; background:rgba(47,191,106,.18); border:1px solid rgba(47,191,106,.35); color:#e8f3ee; font-weight:800\" href=\"${url}\" download>Berekening</a>`
         + `<button class=\"btn secondary\" style=\"padding:6px 10px; border-radius:9px; font-size:12px; margin-right:6px;\" type=\"button\" data-open-text-url=\"${esc(url)}\" data-open-text-title=\"Berekening\">Bekijk</button>`;
  }
  // Make v2 stickers more prominent
  if(t==='stickertool.json (v2)'){
    return `<a class=\"btn\" style=\"padding:6px 10px; border-radius:9px; font-size:12px; margin-right:6px; background:rgba(47,191,106,.18); border:1px solid rgba(47,191,106,.35); color:#e8f3ee; font-weight:900\" href=\"${url}\" download>${t}</a>`;
  }
  return `<a class=\"btn secondary\" style=\"padding:6px 10px; border-radius:9px; font-size:12px; margin-right:6px;\" href=\"${url}\" download>${t}</a>`;
}).join('');
      const _cntZaag = (j.zaagplaten&&j.zaagplaten.length)?j.zaagplaten.length:0;
      const _cntOnd = (j.onderdelen&&j.onderdelen.length)?j.onderdelen.length:0;
      const _cntMeta = 9;
      const _sum = `DXF: ${_cntZaag+_cntOnd} · Overig: ${_cntMeta}`;
      const _body = `<div class=\"jobOutBody\" style=\"display:flex; flex-wrap:wrap; gap:6px;\">${dlSheets}${dlMeta}</div>`;
      const dl = `<details class=\"jobOut ${hasZaag?'zaagHi':''}\"><summary>${_sum}</summary>${_body}</details>`;
      html += `<tr class=\"childRow ${hasZaag?'zaagRow':''}\" data-parent=\"${gkey}\" style=\"background:rgba(255,255,255,.02)\"><td><span class=\"jobIndent\"><span class=\"arrow\">↳</span><code>${_jobLabel(j)}</code></span></td><td>${esc(j.status||'')}</td><td class=\"muted\">${esc(j.createdAt||'')}</td><td class=\"outputsTd\"><div class=\"outputsCell\">${dl}</div></td></tr>`;
    }

  }
  html += '</tbody></table>';
  el.innerHTML = html;

  el.querySelectorAll('[data-open-text-url]').forEach(btn=>{
    btn.addEventListener('click', (e)=>{
      e.preventDefault();
      e.stopPropagation();
      openTextModal(btn.getAttribute('data-open-text-url') || '', btn.getAttribute('data-open-text-title') || 'Bestand');
    });
  });

  // toggle groups
  function setGroupVisible(groupKey, visible){
    const rows = el.querySelectorAll(`tr.childRow[data-parent="${groupKey}"]`);
    rows.forEach(r=>{ r.style.display = visible ? 'table-row' : 'none'; });
    const btn = el.querySelector(`button.groupToggle[data-group="${groupKey}"]`);
    if(btn){
      btn.textContent = visible ? '▾' : '▸';
      btn.setAttribute('aria-expanded', visible ? 'true' : 'false');
    }
  }
  el.querySelectorAll('button.groupToggle').forEach(btn=>{
    btn.addEventListener('click', (e)=>{
      e.preventDefault();
      e.stopPropagation();
      const k = btn.getAttribute('data-group');
      const expanded = btn.getAttribute('aria-expanded')==='true';
      setGroupVisible(k, !expanded);
    });
  });
}
load();
  loadControlCenter();

function openTextModal(url, title){
  const m = document.getElementById('textModal');
  const t = document.getElementById('textModalTitle');
  const b = document.getElementById('textModalBody');
  const dl = document.getElementById('textModalDownload');
  if(!m||!t||!b||!dl) return;
  t.textContent = title || 'Bestand';
  b.textContent = 'Laden…';
  dl.href = url;
  m.style.display = 'flex';
  fetch(url).then(r=>r.text()).then(txt=>{ b.textContent = txt; }).catch(()=>{ b.textContent='Kon bestand niet laden.'; });
}
function closeTextModal(){
  const m = document.getElementById('textModal');
  if(m) m.style.display='none';
}
document.addEventListener('keydown', (e)=>{ if(e.key==='Escape') closeTextModal(); });

  try { window.load = load; } catch(e) {}
}
</script>
</body></html>"""


class Handler(SimpleHTTPRequestHandler):
    # Serve files from ROOT directory
    def translate_path(self, path: str) -> str:
        # Serve static files from an explicit public allowlist only.
        parsed = urlparse(path)
        rel = unquote(parsed.path.lstrip('/'))
        if rel == '':
            rel = 'toolA.html'
        if rel == 'admin':
            # pseudo path
            return str(ROOT / '__admin__.html')
        root_resolved = ROOT.resolve()
        if _is_blocked_static_relpath(rel) or not _is_public_static_relpath(rel):
            return str(ROOT / '__forbidden_static__.404')
        target = (ROOT / rel).resolve()
        if target != root_resolved and root_resolved not in target.parents:
            return str(ROOT / '__forbidden_static__.404')
        if target.is_dir():
            return str(ROOT / '__forbidden_static__.404')
        return str(target)

    def end_headers(self):
        origin = str(self.headers.get('Origin') or '').strip()
        if origin:
            try:
                if _origin_allowed(origin, admin=False) or _origin_allowed(origin, admin=True):
                    self.send_header('Access-Control-Allow-Origin', origin)
                    self.send_header('Vary', 'Origin')
            except Exception:
                pass
        self.send_header('Access-Control-Allow-Methods', 'GET,POST,OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, X-Job-Token, Authorization')
        # Prevent stale HTML/JS being cached between zip updates.
        # Users often unzip over the existing folder; without this, old toolA.html
        # can remain cached and cause "random" JS errors that were already fixed.
        self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0')
        self.send_header('Pragma', 'no-cache')
        self.send_header('Expires', '0')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('X-Frame-Options', 'DENY')
        self.send_header('Referrer-Policy', 'strict-origin-when-cross-origin')
        self.send_header('Permissions-Policy', 'accelerometer=(), autoplay=(), camera=(), geolocation=(), gyroscope=(), magnetometer=(), microphone=(), payment=(), usb=()')
        self.send_header('Cross-Origin-Opener-Policy', 'same-origin')
        self.send_header('Cross-Origin-Resource-Policy', 'same-origin')
        if _is_production_hardening_enabled():
            # Production-only CSP: keep Tool A compatible with inline bootstrap scripts,
            # but remove unsafe-eval and narrow the default policy to self.
            csp = "; ".join([
                "default-src 'self'",
                "base-uri 'self'",
                "object-src 'none'",
                "frame-ancestors 'none'",
                "frame-src 'none'",
                "img-src 'self' data: blob:",
                "font-src 'self' data:",
                "style-src 'self' 'unsafe-inline'",
                "script-src 'self' 'unsafe-inline'",
                "connect-src 'self' ws: wss:",
                "worker-src 'self' blob:",
                "manifest-src 'self'",
                "media-src 'self' data: blob:",
                "form-action 'self'"
            ])
            self.send_header('Content-Security-Policy', csp)
            if _is_https_request(self):
                self.send_header('Strict-Transport-Security', 'max-age=31536000; includeSubDomains')
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(204)
        self.end_headers()


    def _load_admin_credentials(self):
        # Priority 1: direct env vars (production / container)
        u = os.environ.get("ADMIN_USER")
        p = os.environ.get("ADMIN_PASS")
        ph = os.environ.get("ADMIN_PASS_HASH")
        if u and (p or ph):
            return {"username": u, "password": p, "password_hash": ph, "source": "env"}

        # Priority 2: external credentials file via env var (recommended production setup)
        creds_path = _get_admin_credentials_file_path()
        try:
            with open(creds_path, "r", encoding="utf-8") as f:
                obj = json.load(f)
            u = obj.get("username")
            p = obj.get("password")
            ph = obj.get("password_hash") or obj.get("passwordHash")
            if isinstance(u, str) and u and ((isinstance(p, str) and p) or (isinstance(ph, str) and ph)):
                source = "external_config" if creds_path != (ROOT / "config" / "admin_credentials.json") else "config"
                return {
                    "username": u,
                    "password": p if isinstance(p, str) else None,
                    "password_hash": ph if isinstance(ph, str) else None,
                    "source": source,
                    "path": str(creds_path),
                }
        except FileNotFoundError:
            pass
        except Exception:
            pass
        return None


    def _warn_if_local_admin_credentials_in_production(self, creds: dict | None) -> None:
        try:
            if not _is_production_hardening_enabled():
                return
            creds = creds or {}
            source = str(creds.get("source") or "")
            if source != "config":
                return
            msg = (
                "Production hardening is active, but admin credentials are still loaded from "
                "app/config/admin_credentials.json. Move credentials to an external path and set "
                "ADMIN_CREDENTIALS_FILE or ADMIN_CREDENTIALS_PATH for live deployment."
            )
            try:
                if not getattr(self.server, "_local_admin_credentials_warned", False):
                    print("[SECURITY WARNING] " + msg)
                    setattr(self.server, "_local_admin_credentials_warned", True)
            except Exception:
                print("[SECURITY WARNING] " + msg)
        except Exception:
            pass


    def _require_admin_write_origin(self) -> bool:
        ok, error = _helpers_require_same_origin_admin_write(
            self,
            is_loopback_value=_is_loopback_value,
            is_loopback_client=_is_loopback_client,
        )
        if ok:
            return True
        return self._send_json({'ok': False, 'error': error or 'Admin write origin blocked'}, 403)

    def _require_same_origin_public_write(self) -> bool:
        try:
            origin = str(self.headers.get('Origin') or '').strip()
            referer = str(self.headers.get('Referer') or '').strip()
            host_header = str(self.headers.get('Host') or '').strip()
            host_name = host_header.split(':', 1)[0].strip().lower() if host_header else ''

            def _matches_host(candidate_host: str) -> bool:
                candidate_host = str(candidate_host or '').strip().lower()
                if not candidate_host:
                    return False
                if host_name and candidate_host == host_name:
                    return True
                if not _is_production_runtime() and host_name and _is_loopback_value(candidate_host) and _is_loopback_value(host_name):
                    return True
                return False

            if origin:
                if _origin_allowed(origin, admin=False):
                    return True
                try:
                    o = urlparse(origin)
                    if _matches_host(o.hostname or ''):
                        return True
                except Exception:
                    pass
                return self._send_json({'ok': False, 'error': _public_error_message(403)}, 403)

            if referer:
                try:
                    r = urlparse(referer)
                    ref_origin = f"{r.scheme}://{r.netloc}" if r.scheme and r.netloc else ''
                    if ref_origin and _origin_allowed(ref_origin, admin=False):
                        return True
                    if _matches_host(r.hostname or ''):
                        return True
                except Exception:
                    pass
                return self._send_json({'ok': False, 'error': _public_error_message(403)}, 403)

            if not _is_production_runtime() and _is_loopback_client(self):
                return True
            return self._send_json({'ok': False, 'error': _public_error_message(403)}, 403)
        except Exception:
            return self._send_json({'ok': False, 'error': _public_error_message(403)}, 403)

    def _check_admin_auth_silent(self) -> bool:
        creds = self._load_admin_credentials() or {}
        self._warn_if_local_admin_credentials_in_production(creds)
        user = creds.get('username')
        pw = creds.get('password')
        pw_hash = creds.get('password_hash')
        if not user or not (pw or pw_hash):
            return False
        if _is_production_hardening_enabled() and not _is_password_hash_value(pw_hash):
            return False
        auth = self.headers.get("Authorization") or ""
        if not auth.startswith("Basic "):
            return False
        try:
            decoded = base64.b64decode(auth.split(" ", 1)[1].strip()).decode("utf-8")
            supplied_user, supplied_pw = decoded.split(":", 1)
        except Exception:
            return False
        return hmac.compare_digest(str(supplied_user), str(user)) and _verify_password_against_stored(str(supplied_pw), str(pw_hash or pw or ''))

    def _require_admin_auth(self) -> bool:
        # FIX594: staging-only bypass for VPS tests where admin UI and API must be verified over HTTP.
        # Keep disabled for real live unless a proper HTTPS/session login is configured.
        if os.environ.get('ADMIN_STAGING_OPEN') == '1':
            return True
        creds = self._load_admin_credentials() or {}
        self._warn_if_local_admin_credentials_in_production(creds)
        user = creds.get('username')
        pw = creds.get('password')
        pw_hash = creds.get('password_hash')
        if not user or not (pw or pw_hash):
            _append_system_event(level="error", component="auth", message_user="Admin-login is niet geconfigureerd", message_tech=f"Missing username/password in {creds.get('path') or _get_admin_credentials_file_path()}", status="open")
            self.send_response(403)
            self.end_headers()
            self.wfile.write(b"Admin authentication not configured.")
            return False
        if _is_production_hardening_enabled() and not _is_password_hash_value(pw_hash):
            _append_system_event(level="error", component="auth", message_user="Admin-login geblokkeerd", message_tech=f"Production hardening requires password_hash credentials in {creds.get('path') or _get_admin_credentials_file_path()}", status="open")
            self.send_response(403)
            self.end_headers()
            self.wfile.write(b"Admin hash-based authentication required in production hardening mode.")
            return False

        if _credentials_are_default(user, pw or '') and not _is_loopback_client(self):
            _append_system_event(level="error", component="auth", message_user="Admin-login geblokkeerd", message_tech="Default admin credentials are not allowed for non-loopback clients", status="open")
            self.send_response(403)
            self.end_headers()
            self.wfile.write(b"Default admin credentials blocked for non-local access.")
            return False

        if _is_production_hardening_enabled() and not _is_secure_admin_transport(self):
            _append_system_event(level="error", component="auth", message_user="Admin-login geblokkeerd", message_tech="Admin authentication requires HTTPS or loopback in production hardening mode", status="open")
            self.send_response(403)
            self.end_headers()
            self.wfile.write(b"Admin authentication requires HTTPS in production hardening mode.")
            return False

        ip = _client_ip(self)
        auth = self.headers.get("Authorization") or ""
        if not auth.startswith("Basic "):
            self.send_response(401)
            self.send_header("WWW-Authenticate", 'Basic realm="Admin"')
            self.end_headers()
            return False

        b64 = auth.split(" ", 1)[1].strip()
        try:
            decoded = base64.b64decode(b64).decode("utf-8")
        except Exception:
            if _rate_limit_is_blocked('admin_auth_fail', ip, 10, 300):
                self.send_response(429)
                self.end_headers()
                self.wfile.write(b"Too many login attempts.")
                return False
            _rate_limit_record('admin_auth_fail', ip)
            _append_system_event(level="warning", component="auth", message_user="Admin login mislukt", message_tech="Invalid Basic auth encoding", status="open")
            self.send_response(401)
            self.send_header("WWW-Authenticate", 'Basic realm="Admin"')
            self.end_headers()
            return False

        u_in, _, p_in = decoded.partition(":")
        if hmac.compare_digest(str(u_in), str(user)) and _verify_password_against_stored(str(p_in), str(pw_hash or pw or '')):
            _rate_limit_clear('admin_auth_fail', ip)
            return True

        if _rate_limit_is_blocked('admin_auth_fail', ip, 10, 300):
            self.send_response(429)
            self.end_headers()
            self.wfile.write(b"Too many login attempts.")
            return False
        _rate_limit_record('admin_auth_fail', ip)
        _append_system_event(level="warning", component="auth", message_user="Admin login mislukt", message_tech=f"Invalid credentials for user={u_in}", status="open")
        self.send_response(401)
        self.send_header("WWW-Authenticate", 'Basic realm="Admin"')
        self.end_headers()
        return False


    def _dxf_root(self) -> Path:
        return ROOT / "embedded_dxfs"

    def _sanitize_category(self, cat: str):
        if not isinstance(cat, str):
            return None
        cat = cat.strip()
        if not cat:
            return None
        # Keep legacy behavior: allow "(root)" to point to the base folder.
        if cat == "(root)":
            return cat
        # Prevent path traversal / separators
        if "/" in cat or "\\" in cat or ".." in cat:
            return None
        # Allow categories with spaces (labels must match Tool A)
        if len(cat) > 60:
            return None
        if not re.fullmatch(r"[\w \-]{1,60}", cat, flags=re.UNICODE):
            return None
        return cat

    def _sanitize_filename(self, name: str):
        if not isinstance(name, str):
            return None
        name = name.strip()
        if not name:
            return None
        if "/" in name or "\\" in name or ".." in name:
            return None
        if not name.lower().endswith(".dxf"):
            return None
        if not re.fullmatch(r"[A-Za-z0-9 _,.-]{1,80}\.dxf", name, flags=re.IGNORECASE):
            return None
        return name

    def _dxf_category_folder(self, cat: str) -> Path:
        root = self._dxf_root()
        root.mkdir(parents=True, exist_ok=True)
        if cat == "(root)":
            return root
        return root / cat

    def _list_dxf_categories(self):
        root = self._dxf_root()
        root.mkdir(parents=True, exist_ok=True)
        cats = ["(root)"]
        for p in sorted(root.iterdir()):
            if p.is_dir():
                cats.append(p.name)
        return cats

    def _list_dxf_files_in_category(self, cat: str):
        folder = self._dxf_category_folder(cat)
        if not folder.exists() or not folder.is_dir():
            return None
        files = []
        for p in sorted(folder.iterdir()):
            if not p.is_file():
                continue
            name = p.name
            if name.startswith('.'):
                continue
            # Accept normal .dxf and (optionally) extensionless DXF files
            if name.lower().endswith(".dxf") or p.suffix == "":
                files.append(name)
        return files

    def _load_material_library_bundle(self):
        target = ROOT / "material_library.json"
        if target.exists():
            raw = json.loads(target.read_text(encoding="utf-8"))
        else:
            raw = {"source": "admin", "records": []}
        if isinstance(raw, list):
            raw = {"source": "admin", "records": raw}
        if not isinstance(raw, dict):
            raise ValueError("Material library must be a JSON object or list")
        recs = raw.get("records")
        if recs is None:
            recs = []
            raw["records"] = recs
        if not isinstance(recs, list):
            raise ValueError("material_library.json must contain a records list")
        return raw, recs

    def _save_material_library_bundle(self, raw):
        global _MATERIAL_NAME_BY_CODE
        target = ROOT / "material_library.json"
        tmp = ROOT / "material_library.json.tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(raw, f, ensure_ascii=False, indent=2)
            f.flush(); os.fsync(f.fileno())
        os.replace(tmp, target)
        _MATERIAL_NAME_BY_CODE = None

    def _normalize_material_record_for_admin(self, rec):
        if not isinstance(rec, dict):
            rec = {}
        out = dict(rec)
        art = str(out.get("articleNo") or out.get("articleNumber") or out.get("materialCode") or "").strip()
        out["articleNo"] = art
        out["materialCode"] = str(out.get("materialCode") or art).strip()
        if out.get("sheetWid") is None and out.get("sheetWidth") is not None:
            out["sheetWid"] = out.get("sheetWidth")
        if out.get("sheetLen") is None:
            for k in ("sheetHeight", "height"):
                if out.get(k) is not None:
                    out["sheetLen"] = out.get(k)
                    break
        if out.get("purchasePrice") is None:
            for k in ("inkoopprijs", "purchase_price", "cost"):
                if out.get(k) is not None:
                    out["purchasePrice"] = out.get(k)
                    break
        if out.get("thicknessMm") is None and out.get("thickness") is not None:
            out["thicknessMm"] = out.get("thickness")
        return out

    def _material_record_to_toola_catalog(self, rec):
        rr = self._normalize_material_record_for_admin(rec)
        art = str(rr.get("articleNo") or rr.get("articleNumber") or rr.get("materialCode") or "").strip()
        decor = str(rr.get("decorName") or rr.get("decor") or rr.get("productName") or art).strip()
        prod = str(rr.get("productName") or rr.get("decorName") or decor or art).strip()
        try:
            w = float(rr.get("sheetWid") or rr.get("sheetWidth") or 0)
        except Exception:
            w = 0.0
        try:
            h = float(rr.get("sheetLen") or rr.get("sheetHeight") or rr.get("height") or 0)
        except Exception:
            h = 0.0
        try:
            t = float(rr.get("thicknessMm") or rr.get("thickness") or 0)
        except Exception:
            t = 0.0
        try:
            price = float(rr.get("purchasePricePerSheet") or rr.get("purchasePrice") or rr.get("purchase_price") or rr.get("inkoopprijs") or 0)
        except Exception:
            price = 0.0
        cat = str(rr.get("categoryName") or rr.get("category") or "").strip()
        active_raw = rr.get("active")
        active = True if active_raw is None else bool(active_raw)
        return {
            "articleNumber": art,
            "articleNo": art,
            "materialCode": str(rr.get("materialCode") or art).strip(),
            "decorName": decor,
            "productName": prod,
            "thicknessMm": t,
            "sheetSizeMm": {"width": w, "height": h},
            "sheetWid": w,
            "sheetLen": h,
            "purchasePricePerSheet": price,
            "purchasePrice": price,
            "categoryName": cat,
            "hasGrain": True if rr.get("hasGrain") is None else bool(rr.get("hasGrain")),
            "grainDefaultOn": True if rr.get("grainDefaultOn") is None else bool(rr.get("grainDefaultOn")),
            "active": active,
        }

    def _api_public_materials_library(self):
        try:
            raw, recs = self._load_material_library_bundle()
            norm = [self._material_record_to_toola_catalog(r) for r in recs if isinstance(r, dict) and (self._normalize_material_record_for_admin(r).get('active') is not False)]
            try:
                st = (ROOT / "material_library.json").stat()
                version = str(int(st.st_mtime_ns))
            except Exception:
                version = str(int(time.time() * 1000))
            return self._send_json({"ok": True, "records": norm, "version": version, "count": len(norm)})
        except Exception as e:
            _append_system_event(level="error", component="materials", message_user="Materiaalbibliotheek laden is mislukt", message_tech=str(e), status="open")
            return self._send_json({"ok": False, "error": "Materiaalbibliotheek kon niet worden geladen"}, 500)

    def _api_admin_materials_library(self):
        try:
            raw, recs = self._load_material_library_bundle()
            norm = [self._normalize_material_record_for_admin(r) for r in recs if isinstance(r, dict)]
            return self._send_json({"ok": True, "records": norm, "meta": {"source": raw.get("source"), "count": len(norm)}})
        except Exception as e:
            _append_system_event(level="error", component="materials", message_user="Materiaalbeheer laden is mislukt", message_tech=str(e), status="open")
            return self._send_json({"ok": False, "error": "Materiaalbeheer kon niet worden geladen"}, 500)

    def _api_admin_materials_save_item(self):
        try:
            data = _read_json_body_limited(self, 'ADMIN_JSON_MAX_BYTES', 262144) or {}
            prev_article = str(data.get("prevArticleNo") or "").strip()
            rec = data.get("record") or {}
            if not isinstance(rec, dict):
                return self._send_json({"ok": False, "error": "Invalid record"}, 400)
            norm = self._normalize_material_record_for_admin(rec)
            article = str(norm.get("articleNo") or "").strip()
            if not article:
                return self._send_json({"ok": False, "error": "Artikelnummer ontbreekt"}, 400)
            for nk in ("sheetWid", "sheetLen", "thicknessMm", "purchasePrice"):
                try:
                    if float(norm.get(nk) or 0) <= 0:
                        return self._send_json({"ok": False, "error": f"{nk} moet groter zijn dan 0"}, 400)
                except Exception:
                    return self._send_json({"ok": False, "error": f"{nk} is ongeldig"}, 400)
            raw, recs = self._load_material_library_bundle()
            # duplicate guard
            for existing in recs:
                if not isinstance(existing, dict):
                    continue
                ex_art = str(existing.get("articleNo") or existing.get("articleNumber") or existing.get("materialCode") or "").strip()
                if ex_art == article and ex_art != prev_article:
                    return self._send_json({"ok": False, "error": "Artikelnummer bestaat al"}, 400)
            updated = False
            for i, existing in enumerate(recs):
                if not isinstance(existing, dict):
                    continue
                ex_art = str(existing.get("articleNo") or existing.get("articleNumber") or existing.get("materialCode") or "").strip()
                if ex_art == prev_article or (not prev_article and ex_art == article):
                    recs[i] = norm
                    updated = True
                    break
            if not updated:
                recs.append(norm)
            raw["records"] = recs
            raw["recordCountOriginal"] = len(recs)
            raw["recordCountFiltered"] = len(recs)
            self._save_material_library_bundle(raw)
            _append_system_event(level="info", component="materials", message_user="Materiaal opgeslagen", message_tech=f"Saved articleNo={article}", customer_name=article, status="resolved")
            return self._send_json({"ok": True, "articleNo": article, "count": len(recs)})
        except Exception as e:
            _append_system_event(level="error", component="materials", message_user="Materiaal kon niet worden opgeslagen", message_tech=str(e), customer_name=_safe_text((data or {}).get('record',{}).get('decorName') if isinstance((data or {}).get('record'), dict) else "", 160), status="open")
            return self._send_json({"ok": False, "error": "Materiaal opslaan is mislukt"}, 400)

    def _api_admin_materials_delete_item(self):
        try:
            data = _read_json_body_limited(self, 'ADMIN_JSON_MAX_BYTES', 262144) or {}
            article = str(data.get("articleNo") or "").strip()
            if not article:
                return self._send_json({"ok": False, "error": "Artikelnummer ontbreekt"}, 400)
            raw, recs = self._load_material_library_bundle()
            kept = []
            removed = 0
            for r in recs:
                if not isinstance(r, dict):
                    kept.append(r)
                    continue
                ex_art = str(r.get("articleNo") or r.get("articleNumber") or r.get("materialCode") or "").strip()
                if ex_art == article:
                    removed += 1
                else:
                    kept.append(r)
            if not removed:
                return self._send_json({"ok": False, "error": "Materiaal niet gevonden"}, 404)
            raw["records"] = kept
            raw["recordCountOriginal"] = len(kept)
            raw["recordCountFiltered"] = len(kept)
            self._save_material_library_bundle(raw)
            _append_system_event(level="info", component="materials", message_user="Materiaal verwijderd", message_tech=f"Removed articleNo={article}", customer_name=article, status="resolved")
            return self._send_json({"ok": True, "removed": removed, "count": len(kept)})
        except Exception as e:
            _append_system_event(level="error", component="materials", message_user="Materiaal verwijderen is mislukt", message_tech=str(e), customer_name=_safe_text((data or {}).get('articleNo'), 120), status="open")
            return self._send_json({"ok": False, "error": "Materiaal verwijderen is mislukt"}, 400)

    def _api_admin_materials_upload(self):
        data = _read_json_body_limited(self, 'ADMIN_MATERIALS_UPLOAD_MAX_BYTES', 2097152)
        if isinstance(data, list):
            data = {"source": "admin upload", "records": data}
        if not isinstance(data, dict) or not data:
            return self._send_json({"ok": False, "error": "Material library must be a non-empty JSON object"}, 400)
        recs = data.get("records") if isinstance(data, dict) else None
        if not isinstance(recs, list) or not recs:
            return self._send_json({"ok": False, "error": "Material library must contain a non-empty records list"}, 400)
        norm = []
        for r in recs:
            if not isinstance(r, dict):
                return self._send_json({"ok": False, "error": "Every record must be an object"}, 400)
            rr = self._normalize_material_record_for_admin(r)
            art = str(rr.get("articleNo") or "").strip()
            if not art:
                return self._send_json({"ok": False, "error": "Elke record moet een artikelnummer hebben"}, 400)
            if float(rr.get("sheetWid") or 0) <= 0 or float(rr.get("sheetLen") or 0) <= 0:
                return self._send_json({"ok": False, "error": f"Breedte/lengte ongeldig in {art}"}, 400)
            norm.append(rr)
        data["records"] = norm
        data["recordCountOriginal"] = len(norm)
        data["recordCountFiltered"] = len(norm)
        self._save_material_library_bundle(data)
        _append_system_event(level="info", component="materials", message_user="Material Library vervangen via upload", message_tech=f"Uploaded {len(norm)} records", status="resolved")
        return self._send_json({"ok": True, "count": len(norm)})


    def _api_admin_system_logs(self):
        try:
            items = _read_system_events(limit=200)
            return self._send_json({"ok": True, "items": items, "count": len(items)})
        except Exception as e:
            _append_system_event(level="error", component="system", message_user="Systeemlog laden is mislukt", message_tech=str(e), status="open")
            return self._send_json({"ok": False, "error": "Systeemlog kon niet worden geladen"}, 500)

    def _api_admin_system_backups(self):
        try:
            items = _list_backups(limit=50)
            return self._send_json({"ok": True, "items": items, "count": len(items)})
        except Exception as e:
            _append_system_event(level="error", component="backup", message_user="Backuplijst laden is mislukt", message_tech=str(e), status="open")
            return self._send_json({"ok": False, "error": "Backuplijst kon niet worden geladen"}, 500)

    def _api_admin_system_backup_download(self, parsed):
        try:
            qs = parse_qs(parsed.query)
            name = str((qs.get('name') or [''])[0]).strip()
            if not name or '/' in name or '\\' in name or '..' in name:
                return self._send_text('Not found', 404)
            fpath = BACKUPS_DIR / name
            if not fpath.exists() or not fpath.is_file() or fpath.suffix.lower() != '.zip':
                return self._send_text('Not found', 404)
            data = fpath.read_bytes()
            self.send_response(200)
            self.send_header('Content-Type', 'application/zip')
            self.send_header('Content-Disposition', f'attachment; filename="{fpath.name}"')
            self.send_header('Content-Length', str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return
        except Exception as e:
            _append_system_event(level="error", component="backup", message_user="Backup downloaden is mislukt", message_tech=str(e), status="open")
            return self._send_json({"ok": False, "error": "Backup downloaden is mislukt"}, 500)

    def _api_admin_system_backup_now(self):
        try:
            actor = self.headers.get('X-Admin-Actor', 'admin')
            res = _create_system_backup(actor=actor)
            return self._send_json(res, 200)
        except Exception as e:
            _append_system_event(level="error", component="backup", message_user="Backup maken is mislukt", message_tech=str(e), status="open")
            return self._send_json({"ok": False, "error": "Backup maken is mislukt"}, 500)

    def _api_admin_dxf_categories(self):
        return self._send_json({"ok": True, "categories": self._list_dxf_categories()})

    def _api_admin_dxf_list(self, parsed):
        qs = parse_qs(parsed.query)
        cat = self._sanitize_category((qs.get("category") or [""])[0])
        if not cat:
            return self._send_json({"ok": False, "error": "Invalid category"}, 400)
        folder = self._dxf_category_folder(cat)
        files = self._list_dxf_files_in_category(cat)
        if files is None:
            return self._send_json({"ok": False, "error": "Category not found"}, 404)
        return self._send_json({
            "ok": True,
            "category": cat,
            "files": files,
            "count": len(files),
        })

    def _api_admin_dxf_create_category(self):
        data = _read_json_body_limited(self, 'ADMIN_JSON_MAX_BYTES', 262144) or {}
        cat = self._sanitize_category(data.get("category", ""))
        if not cat or cat == "(root)":
            return self._send_json({"ok": False, "error": "Invalid category"}, 400)
        folder = self._dxf_category_folder(cat)
        folder.mkdir(parents=True, exist_ok=True)
        rebuild_embedded_dxfs_manifest()
        _sse_broadcast('dxf_changed', {"dxfVersion": get_embedded_dxfs_version()})
        return self._send_json({"ok": True, "category": cat})

    def _api_admin_dxf_upload(self):
        data = _read_json_body_limited(self, 'ADMIN_DXF_UPLOAD_MAX_BYTES', 15728640) or {}
        cat = self._sanitize_category(data.get("category", ""))
        filename = self._sanitize_filename(data.get("filename", ""))
        b64data = data.get("dataBase64", "")
        if not cat or not filename or not isinstance(b64data, str) or not b64data:
            return self._send_json({"ok": False, "error": "Invalid payload"}, 400)

        folder = self._dxf_category_folder(cat)
        if not folder.exists() or not folder.is_dir():
            return self._send_json({"ok": False, "error": "Category not found"}, 404)

        try:
            raw = base64.b64decode(b64data, validate=True)
        except Exception:
            return self._send_json({"ok": False, "error": "Invalid base64"}, 400)

        if len(raw) > 10 * 1024 * 1024:
            return self._send_json({"ok": False, "error": "File too large"}, 400)

        target = folder / filename
        tmp = folder / (filename + ".tmp")
        with open(tmp, "wb") as f:
            f.write(raw)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, target)

        rebuild_embedded_dxfs_manifest()
        _sse_broadcast('dxf_changed', {"dxfVersion": get_embedded_dxfs_version(), "category": cat, "filename": filename})
        return self._send_json({"ok": True})

    def _api_admin_dxf_delete(self):
        data = _read_json_body_limited(self, 'ADMIN_JSON_MAX_BYTES', 262144) or {}
        cat = self._sanitize_category(data.get("category", ""))
        filename = self._sanitize_filename(data.get("filename", ""))
        if not cat or not filename:
            return self._send_json({"ok": False, "error": "Invalid payload"}, 400)
        folder = self._dxf_category_folder(cat)
        target = folder / filename
        if not target.exists() or not target.is_file():
            return self._send_json({"ok": False, "error": "File not found"}, 404)
        try:
            os.remove(target)
        except Exception:
            return self._send_json({"ok": False, "error": "Delete failed"}, 500)
        rebuild_embedded_dxfs_manifest()
        _sse_broadcast('dxf_changed', {"dxfVersion": get_embedded_dxfs_version(), "category": cat, "filename": filename})
        return self._send_json({"ok": True})

    def _require_job_access(self, job_id: str, parsed=None, body: Optional[dict]=None, deny_as_json: bool = False) -> bool:
        try:
            if self._check_admin_auth_silent():
                return True
        except Exception:
            pass
        expected = _read_job_access_token(job_id)
        supplied = _extract_request_token(self, parsed=parsed, body=body)
        if expected and supplied and hmac.compare_digest(str(supplied), str(expected)):
            return True
        if deny_as_json:
            return self._send_json({'ok': False, 'error': 'Forbidden'}, 403)
        return self._send_text('Forbidden', 403)

    def do_GET(self):
        parsed = urlparse(self.path)

        # Public SSE stream used by Tool A to refresh embedded DXF catalog live.
        if parsed.path == '/api/events':
            return _sse_handler(self)

        if parsed.path in ('/admin', '/admin/') or parsed.path.startswith('/api/admin/'):
            if not self._require_admin_auth():
                return

        if parsed.path == '/favicon.ico':
            # Avoid noisy 404s in the browser console.
            self.send_response(204)
            self.end_headers()
            return

        if parsed.path == '/.well-known/appspecific/com.chrome.devtools.json':
            # Chrome DevTools sometimes probes this path; respond without crashing.
            self.send_response(204)
            self.end_headers()
            return

        if parsed.path == '/api/draft/load':
            return api_draft_load(self, parsed)

        if parsed.path == '/api/dxf_manifest_meta':
            return api_dxf_manifest_meta(self, parsed)


        if parsed.path == '/api/admin/jobs':
            return api_admin_jobs(self)

        if parsed.path == '/api/admin/requests':
            return api_admin_requests(self)
        if parsed.path == '/api/admin/request_files':
            return api_admin_request_files(self)
        if parsed.path == '/api/admin/request_file':
            return api_admin_request_file(self)
        if parsed.path == '/api/admin/request_download_zip':
            return api_admin_request_download_zip(self)
        if parsed.path == '/api/admin/requests/update':
            return api_admin_requests_update(self)

        if parsed.path == '/api/admin/control_center':
            return api_admin_control_center(self)

        if parsed.path == '/api/admin/dxf/categories':
            return self._api_admin_dxf_categories()

        if parsed.path == '/api/admin/dxf/list':
            return self._api_admin_dxf_list(parsed)

        if parsed.path == '/api/admin/materials/library':
            return self._api_admin_materials_library()

        if parsed.path == '/api/materials/library':
            return self._api_public_materials_library()

        if parsed.path == '/api/admin/system/logs':
            return self._api_admin_system_logs()

        if parsed.path == '/api/admin/system/backups':
            return self._api_admin_system_backups()
        if parsed.path == '/api/admin/system/backup_download':
            return self._api_admin_system_backup_download(parsed)

        if parsed.path == '/api/admin/pricing':
            cfg = _load_pricing_config()
            body, code = _safe_json(cfg, 200)
            self.send_response(code)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return


        # Deprecated: Stickertool v2 direct route.
        # We now serve v2 via the generic, proven file route:
        #   /api/jobs/<subjobId>/file/output/stickers.json
        if parsed.path.startswith('/api/stickertool_v2/'):
            return self._send_text('Deprecated. Use /api/jobs/<subjobId>/file/output/stickers.json', 410)

        if parsed.path.startswith('/api/jobs/') and '/download/' in parsed.path:
            # /api/jobs/<jobId>/download/<filename>
            parts = parsed.path.split('/')
            try:
                job_id = parts[3]
                fname = parts[5]
            except Exception:
                return self._send_text('Bad request', 400)
            return api_download(self, job_id, fname, parsed)

        # Subjob file serving (Stickertool v2 contract)
        # /api/jobs/<jobId>/subjobs/<subjobId>/file/<relpath>
        if parsed.path.startswith('/api/jobs/') and '/subjobs/' in parsed.path and '/file/' in parsed.path:
            parts = parsed.path.split('/')
            # ['', 'api', 'jobs', <jobId>, 'subjobs', <subjobId>, 'file', <relpath...>]
            if len(parts) >= 8 and parts[4] == 'subjobs' and parts[6] == 'file':
                job_id = unquote(parts[3])
                subjob_id = unquote(parts[5])
                rel = '/'.join(parts[7:])
                rel = unquote(rel)
                return api_subjob_file(self, job_id, subjob_id, rel, parsed)

        if parsed.path.startswith('/api/jobs/') and '/file/' in parsed.path:
            # /api/jobs/<jobId>/file/<relpath>
            parts = parsed.path.split('/')
            if len(parts) >= 6:
                job_id = unquote(parts[3])
                rel = '/'.join(parts[5:])
                rel = unquote(rel)
                return api_job_file(self, job_id, rel, parsed)


        if parsed.path.startswith('/api/jobs/') and parsed.path.endswith('/status'):
            # /api/jobs/<jobId>/status
            job_id = parsed.path.split('/')[3]
            return self._api_status(job_id, parsed)

        if parsed.path in ('/admin', '/admin/'):
            # serve admin html
            body = ADMIN_HTML.encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        return super().do_GET()

    def do_POST(self):
        parsed = urlparse(self.path)
        if parsed.path in ('/admin', '/admin/') or parsed.path.startswith('/api/admin/'):
            if not self._require_admin_auth():
                return
            if parsed.path.startswith('/api/admin/') and not self._require_admin_write_origin():
                return

        if parsed.path == '/api/admin/materials/upload':
            return self._api_admin_materials_upload()

        if parsed.path == '/api/admin/materials/save_item':
            return self._api_admin_materials_save_item()

        if parsed.path == '/api/admin/materials/delete_item':
            return self._api_admin_materials_delete_item()

        if parsed.path == '/api/admin/system/backup_now':
            return self._api_admin_system_backup_now()

        if parsed.path == '/api/admin/dxf/create_category':
            return self._api_admin_dxf_create_category()

        if parsed.path == '/api/admin/dxf/upload':
            return self._api_admin_dxf_upload()

        if parsed.path == '/api/admin/dxf/delete':
            return self._api_admin_dxf_delete()

        if parsed.path == '/api/admin/requests/update':
            return api_admin_requests_update(self)

        if parsed.path == '/api/submit_config':
            try:
                return self._api_submit_config()
            except Exception as e:
                _append_system_event(level="error", component="toola", message_user="Aanvraag verwerken is mislukt", message_tech=str(e), status="open")
                return self._send_json({"ok": False, "error": _public_error_message(500)}, 500)
        if parsed.path == '/api/cancel':
            return self._api_cancel_request()

        if parsed.path == '/api/client_log':
            return self._api_client_log(parsed=parsed)
        if parsed.path == '/api/send_to_odoo':
            if not self._require_admin_auth():
                return
            if not self._require_admin_write_origin():
                return
            return self._api_send_to_odoo()
        if parsed.path == '/api/jobs/cancel':
            return self._api_cancel_job(parsed=parsed)
        if parsed.path == '/api/jobs':
            return self._api_create_job()

        if parsed.path == '/api/draft/save':
            return api_draft_save(self)

        if parsed.path == '/api/admin/pricing':
            try:
                data = _read_json_body_limited(self, 'ADMIN_JSON_MAX_BYTES', 262144)
                actor = self.headers.get('X-Admin-Actor', 'admin')
                res = _save_pricing_config(data, actor=actor)
                _append_system_event(level="info", component="pricing", message_user="Prijsinstellingen opgeslagen", message_tech=f"Saved pricing config by {actor}", status="resolved")
                body, code = _safe_json(res, 200)
            except Exception as e:
                _append_system_event(level="error", component="pricing", message_user="Prijsinstellingen konden niet worden opgeslagen", message_tech=str(e), status="open")
                body, code = _safe_json({'ok': False, 'error': str(e)}, 400)
            self.send_response(code)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        return self._send_text('Not found', 404)

    def _api_send_to_odoo(self):
        """Store a payload for later Odoo integration.

        This route is admin-only and should never be exposed as a public write
        surface. It persists a bounded JSON payload inside the target job.
        """
        try:
            payload = _read_json_body_limited(self, 'ADMIN_JSON_MAX_BYTES', 262144)
        except Exception:
            return self._send_json({'ok': False, 'error': 'Invalid JSON'}, 400)

        job_id = str(payload.get('jobId') or '').strip()
        if not job_id:
            return self._send_json({'ok': False, 'error': 'Missing jobId'}, 400)
        job_id = re.sub(r"[^A-Za-z0-9_\-\.]", "_", job_id)[:120]

        try:
            jobs_dir = os.path.join(BASE_DIR, 'jobs')
            job_dir = os.path.join(jobs_dir, job_id)
            os.makedirs(job_dir, exist_ok=True)
            out_path = os.path.join(job_dir, 'odoo_payload.json')
            with open(out_path, 'w', encoding='utf-8') as f:
                json.dump(payload, f, ensure_ascii=False, indent=2)
        except Exception:
            return self._send_json({'ok': False, 'error': 'Failed to store payload'}, 500)

        return self._send_json({'ok': True, 'stored': True, 'jobId': job_id})


    
    def _api_submit_config(self):
        """Public endpoint: accept a configuration/job payload and enqueue it for processing.

        IMPORTANT: This endpoint must not expose any job outputs. It only stores input
        and status + queue files (file-based, deterministic).
        """
        _ensure_request_dirs()
        ip = _client_ip(self)
        if not _rate_limit_allow('submit_config', ip, 30, 300):
            return self._send_json({"ok": False, "error": "Te veel verzoeken. Probeer het later opnieuw."}, 429)
        try:
            # Size limit (basic anti-abuse). Default 1 MB.
            payload = _read_json_body_limited(self, 'SUBMIT_MAX_BYTES', 8388608 if _is_production_runtime() else 16777216)
            if not isinstance(payload, dict) or not payload:
                return self._send_json({"ok": False, "error": "Lege aanvraagpayload."}, 400)
        except Exception as e:
            return self._send_json({"ok": False, "error": _public_error_message(400)}, 400)

        ok_payload, payload_errors, cleaned_payload = _validate_submit_payload(payload)
        if not ok_payload:
            return self._send_json({"ok": False, "error": "Validatie mislukt"}, 400)
        # Preserve unknown/non-critical frontend fields so older/newer Tool A builds
        # do not break submit. Known fields remain sanitized via cleaned_payload.
        raw_payload = dict(payload) if isinstance(payload, dict) else {}
        raw_payload.update(cleaned_payload)
        payload = raw_payload

        # Minimal customer info (optional but useful for Admin index)
        customer = payload.get("customer") if isinstance(payload.get("customer"), dict) else {}
        checkout = payload.get("checkout") if isinstance(payload.get("checkout"), dict) else {}
        checkout_customer = checkout.get("customer") if isinstance(checkout.get("customer"), dict) else {}
        merged_customer = {}
        for src in (customer if isinstance(customer, dict) else {}, checkout_customer if isinstance(checkout_customer, dict) else {}):
            if isinstance(src, dict):
                for k, v in src.items():
                    if v not in (None, ''):
                        merged_customer[k] = v
        customer = merged_customer
        customer_name = ""
        if isinstance(customer, dict):
            first = str(customer.get("firstName") or "").strip()
            last = str(customer.get("lastName") or "").strip()
            full = " ".join([x for x in [first, last] if x]).strip()
            customer_name = str(customer.get("name") or customer.get("fullName") or full or "").strip()

        request_id = _new_request_id()
        cancel_token = secrets.token_urlsafe(32)
        req_root = REQUESTS / request_id
        inp = req_root / "input"
        inp.mkdir(parents=True, exist_ok=True)

        # Store raw payload (so we can process later without ToolA changes)
        _atomic_write_json(inp / "submit_payload.json", payload)

        created = _utc_now_iso()
        status = {
            "schemaVersion": "1.0",
            "requestId": request_id,
            "createdAt": created,
            "updatedAt": created,
            "customer": {
                "name": customer_name,
                "fullName": customer_name,
                "firstName": str(customer.get("firstName") or "").strip() if isinstance(customer, dict) else "",
                "lastName": str(customer.get("lastName") or "").strip() if isinstance(customer, dict) else "",
                "email": str(customer.get("email") or customer.get("mail") or "").strip() if isinstance(customer, dict) else "",
                "phone": str(customer.get("phone") or customer.get("tel") or customer.get("telephone") or "").strip() if isinstance(customer, dict) else "",
                "billingAddress": str(customer.get("billingAddress") or customer.get("invoiceAddress") or customer.get("address") or customer.get("addressLine1") or customer.get("street") or "").strip() if isinstance(customer, dict) else "",
                "shippingAddress": str(customer.get("shippingAddress") or customer.get("deliveryAddress") or customer.get("address1") or "").strip() if isinstance(customer, dict) else "",
                "postalCode": str(customer.get("postalCode") or customer.get("postcode") or "").strip() if isinstance(customer, dict) else "",
                "city": str(customer.get("city") or customer.get("plaats") or "").strip() if isinstance(customer, dict) else "",
                "country": str(customer.get("country") or "").strip() if isinstance(customer, dict) else "",
                "note": str(checkout.get("note") or payload.get("note") or customer.get("note") or "").strip(),
            },
            # Mailbox semantics:
            "publicStatus": "SUBMITTED",
            "publicStatusLabel": "Aanvraag verzonden",
            "needsQuote": True,
            "quoteStatus": "TODO",
            # Worker/engine:
            "internalStatus": "QUEUED",
            "internalStatusLabel": "In wachtrij",
            "job": {
                "parentJobId": None,
                "subjobs": []
            },
            "error": None,
            "cancel": None,
            "cancelControl": {
                "cancelToken": cancel_token,
                "issuedAt": created,
            },
        }
        try:
            if isinstance(payload.get('quote'), dict):
                status['quote'] = payload.get('quote')
        except Exception:
            pass
        try:
            status['summary'] = _extract_request_summary(payload)
        except Exception:
            pass

        # Optional linkage to an existing ToolB job (parent + subjobs)
        try:
            parent_job_id = str(payload.get("parentJobId") or payload.get("jobId") or "").strip()
            parent_job_id = _safe_id(parent_job_id, 200) if parent_job_id else None
            quote = payload.get("quote") if isinstance(payload.get("quote"), dict) else {}
            subjobs = []
            if isinstance(quote, dict):
                # Accept multiple quote formats
                pj = quote.get("parentJobId") or quote.get("jobId")
                if not parent_job_id and pj:
                    parent_job_id = _safe_id(str(pj), 200)
                per = quote.get("perSubjob") if isinstance(quote.get("perSubjob"), list) else []
                for it in per:
                    if not isinstance(it, dict):
                        continue
                    sj = it.get("jobId") or it.get("subjobId") or it.get("id")
                    if sj:
                        subjobs.append(_safe_id(str(sj), 200))
            # Fallback: subjobId field
            sj_payload = str(payload.get("subjobId") or "").strip()
            if sj_payload:
                subjobs.append(_safe_id(sj_payload, 200))
            # Normalize parentJobId from subjob if needed
            if not parent_job_id and subjobs:
                parent_job_id = _safe_id(str(subjobs[0]).split("__mat_")[0], 200)
            if parent_job_id:
                status["job"]["parentJobId"] = parent_job_id
            # Deduplicate
            if subjobs:
                dedup = []
                for sj in subjobs:
                    if sj and sj not in dedup:
                        dedup.append(sj)
                status["job"]["subjobs"] = dedup
        except Exception:
            pass

        _save_status(request_id, status)

        # Enqueue (atomic create)
        q_item = {
            "requestId": request_id,
            "createdAt": created,
        }
        _atomic_write_json(QUEUE_PENDING / f"{request_id}.json", q_item)

        authoritative_pricing = {}
        candidate_job_ids = []
        try:
            parent_id = str((status.get('job') or {}).get('parentJobId') or '').strip()
            if parent_id:
                candidate_job_ids.append(parent_id)
            for sj in ((status.get('job') or {}).get('subjobs') or []):
                sj = str(sj or '').strip()
                if sj and sj not in candidate_job_ids:
                    candidate_job_ids.append(sj)
            # STRICT: never invent/surface a final price from request payload or quote
            # fallback at submit time. Only expose pricing when a final calculation
            # summary already exists on disk for one of the jobs.
            if candidate_job_ids:
                authoritative_pricing = _extract_strict_calculation_pricing_summary(candidate_job_ids) or {}
        except Exception:
            authoritative_pricing = {}

        # Push notification (best-effort; never breaks flow).
        # IMPORTANT FIX590: send it after reading the authoritative calculation summary,
        # so ntfy matches Admin/berekening instead of stale frontend payload totals.
        notify_ok = False
        notify_err = ""
        try:
            notify_ok, notify_err = _notify_submitted(request_id, payload, status=status, job_ids=candidate_job_ids, authoritative_pricing=authoritative_pricing)
        except Exception as e:
            notify_ok, notify_err = (False, str(e))

        _sse_broadcast("request_submitted", {"requestId": request_id})
        return self._send_json({"ok": True, "requestId": request_id, "cancelToken": cancel_token, "notifyOk": notify_ok, "notifyError": notify_err, "createdAt": created, "pricingSummary": authoritative_pricing})

    def _api_cancel_request(self):
        """Public endpoint: mark a request as cancelled by the customer."""
        _ensure_request_dirs()
        try:
            payload = _read_json_body_limited(self, 'CLIENT_LOG_MAX_BYTES', 65536)
        except Exception:
            return self._send_json({"ok": False, "error": _public_error_message(400)}, 400)

        ip = _client_ip(self)
        if not _rate_limit_allow('public_cancel_request', ip, 10, 60):
            return self._send_json({"ok": False, "error": "Too many requests"}, 429)

        request_id = str(payload.get("requestId") or "").strip()
        if not request_id:
            return self._send_json({"ok": False, "error": "Missing requestId"}, 400)
        request_id = _safe_id(request_id, 120)

        supplied_cancel_token = str(payload.get("cancelToken") or payload.get("token") or '').strip()
        if not supplied_cancel_token:
            return self._send_json({"ok": False, "error": "Forbidden"}, 403)

        status = _load_status(request_id)
        if not isinstance(status, dict):
            return self._send_json({"ok": False, "error": "Unknown requestId"}, 404)

        expected_cancel_token = ''
        try:
            cc = status.get('cancelControl') if isinstance(status.get('cancelControl'), dict) else {}
            expected_cancel_token = str(cc.get('cancelToken') or '').strip()
        except Exception:
            expected_cancel_token = ''
        if not expected_cancel_token or not hmac.compare_digest(supplied_cancel_token, expected_cancel_token):
            return self._send_json({"ok": False, "error": "Forbidden"}, 403)

        # Update status
        status["publicStatus"] = "CANCELLED"
        status["publicStatusLabel"] = "Geannuleerd door klant"
        status["needsQuote"] = False
        status["quoteStatus"] = "CANCELLED"
        # If it hasn't started processing, cancel internal as well
        if status.get("internalStatus") in ("QUEUED", "RECEIVED", None, ""):
            status["internalStatus"] = "CANCELLED"
            status["internalStatusLabel"] = "Geannuleerd"
        status["cancel"] = {
            "cancelledAt": _utc_now_iso(),
            "cancelReason": str(payload.get("reason") or "USER_CANCELLED"),
            "context": str(payload.get("context") or "PRICE_OVERLAY"),
        }
        try:
            if isinstance(status.get('cancelControl'), dict):
                status['cancelControl']['cancelledAt'] = status['cancel'].get('cancelledAt')
                status['cancelControl'].pop('cancelToken', None)
        except Exception:
            pass
        _save_status(request_id, status)

        _sse_broadcast("request_cancelled", {"requestId": request_id})
        return self._send_json({"ok": True, "requestId": request_id, "cancelled": True})

    def _api_cancel_job(self, parsed=None):
            """Mark a job as cancelled (UI-only action).

            Access policy:
            - admin is always allowed
            - non-admin callers must present the correct job access token
            """
            ip = _client_ip(self)
            if not _rate_limit_allow('cancel_job', ip, 20, 300):
                return self._send_json({'ok': False, 'error': 'Te veel verzoeken. Probeer het later opnieuw.'}, 429)
            try:
                payload = _read_json_body_limited(self, 'PUBLIC_JSON_MAX_BYTES', 262144)
            except Exception:
                return self._send_json({'ok': False, 'error': 'Invalid JSON'}, 400)

            job_id = str(payload.get('jobId') or payload.get('parentJobId') or '').strip()
            if not job_id:
                return self._send_json({'ok': False, 'error': 'Missing jobId'}, 400)

            safe_job_id = re.sub(r"[^A-Za-z0-9_\-\.]", "_", job_id)[:120]
            if not self._require_job_access(safe_job_id, parsed=parsed, body=payload, deny_as_json=True):
                return
            try:
                jobs_dir = Path(BASE_DIR) / 'jobs'
                job_dir = jobs_dir / safe_job_id
                job_dir.mkdir(parents=True, exist_ok=True)
                status_path = job_dir / 'status.json'

                status = {}
                if status_path.exists():
                    try:
                        status = json.loads(status_path.read_text(encoding='utf-8') or '{}')
                    except Exception:
                        status = {}

                status.update({
                    'jobId': safe_job_id,
                    'state': 'cancelled',
                    'cancelledAt': _now_iso(),
                    'reason': str(payload.get('reason') or '').strip() or None,
                })
                status_path.write_text(json.dumps(status, ensure_ascii=False, indent=2), encoding='utf-8')
            except Exception:
                return self._send_json({'ok': False, 'error': 'Failed to mark cancelled'}, 500)

            return self._send_json({'ok': True, 'jobId': safe_job_id, 'state': 'cancelled'})


    def _send_text(self, text: str, code: int = 200, ctype: str = 'text/plain; charset=utf-8'):
        b = text.encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def _send_json(self, obj, code: int = 200):
        b = json.dumps(obj).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(b)))
        self.end_headers()
        self.wfile.write(b)


    def _api_client_log(self, parsed=None):
        """Receive bounded client-side debug logs.

        Security policy:
        - same-origin / loopback only
        - small payloads only
        - rate-limited per client IP
        - best-effort logging with generic failures
        """
        if not self._require_same_origin_public_write():
            return
        ip = _client_ip(self)
        if not _rate_limit_allow('client_log', ip, 120, 300):
            return self._send_json({"ok": False, "error": "Te veel verzoeken. Probeer het later opnieuw."}, 429)
        try:
            payload = _read_json_body_limited(self, 'CLIENT_LOG_MAX_BYTES', 16384)
        except Exception:
            return self._send_json({"ok": False, "error": "Invalid JSON"}, 400)

        try:
            job_id = str(payload.get("jobId") or "").strip()
            if job_id:
                job_id = re.sub(r"[^A-Za-z0-9_\-\.]", "_", job_id)[:120]
            ts = payload.get("ts") or _now_iso()
            rec = {
                "ts": ts,
                "level": str(payload.get("level") or "info")[:24],
                "event": str(payload.get("event") or "")[:120],
                "message": _redact_sensitive_text(payload.get("message") or "", 400),
                "url": _redact_sensitive_text(str(payload.get("url") or "").split("#",1)[0].split("?",1)[0], 300),
                "ua": "",
                "data": _sanitize_log_value(payload.get("data"), max_depth=1, max_items=10),
            }
            if job_id:
                path = JOBS / job_id / "client_log.jsonl"
            else:
                path = JOBS / "_client_logs" / "general_client_log.jsonl"
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open("a", encoding="utf-8") as f:
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
            return self._send_json({"ok": True})
        except Exception:
            return self._send_json({"ok": False, "error": "Log write failed"}, 500)


    def _estimate_job_complexity(self, payload: dict) -> dict:
        try:
            panels_csv = str((payload or {}).get('panelsCsv') or '')
        except Exception:
            panels_csv = ''
        try:
            dxf_parts = (payload or {}).get('dxfParts') or {}
            dxf_count = len(dxf_parts) if isinstance(dxf_parts, dict) else 0
        except Exception:
            dxf_count = 0
        try:
            panel_rows = max(0, len([ln for ln in panels_csv.splitlines() if ln.strip()]) - 1)
        except Exception:
            panel_rows = 0
        try:
            approx_bytes = len(json.dumps(payload or {}, ensure_ascii=False).encode('utf-8'))
        except Exception:
            approx_bytes = 0
        try:
            area_info = _estimate_payload_area_lower_bound(payload)
        except Exception:
            area_info = {'maxAreaLowerBound': 0}
        return {
            'panelRows': panel_rows,
            'dxfCount': dxf_count,
            'approxBytes': approx_bytes,
            'maxAreaLowerBound': int((area_info or {}).get('maxAreaLowerBound') or 0),
        }

    def _start_async_job_create(self, payload: dict, master_job_id: str, public_access_token: str = '', acquired_ip: str = '') -> None:
        def _runner():
            try:
                _create_job_from_payload(payload, master_job_id=master_job_id, public_access_token=public_access_token)
                with _job_lock:
                    meta = _job_meta.get(master_job_id, {}) or {}
                    meta['status'] = 'done'
                    meta['progressPct'] = 100
                    meta['progressMessage'] = 'Optimalisatie afgerond'
                    meta['phase'] = 'done'
                    meta['finishedAt'] = _now_iso()
                    _job_meta[master_job_id] = meta
                try:
                    st = _load_status(master_job_id) or {}
                    if st:
                        st.update({'publicStatus':'DONE','publicStatusLabel':'Klaar','internalStatus':'DONE','internalStatusLabel':'Klaar','quoteStatus':'DONE','needsQuote':False})
                        _save_status(master_job_id, st)
                except Exception:
                    pass
            except Exception as e:
                try:
                    jr = JOBS / master_job_id
                    (jr / 'output').mkdir(parents=True, exist_ok=True)
                    (jr / 'output' / 'create_job_error.txt').write_text(str(e), encoding='utf-8')
                except Exception:
                    pass
                with _job_lock:
                    meta = _job_meta.get(master_job_id, {}) or {}
                    meta['status'] = 'error'
                    meta['finishedAt'] = _now_iso()
                    meta['error'] = str(e)
                    _job_meta[master_job_id] = meta
                try:
                    st = _load_status(master_job_id) or {}
                    if st:
                        st.update({'publicStatus':'ERROR','publicStatusLabel':'Fout bij optimaliseren','internalStatus':'ERROR','internalStatusLabel':'Fout','quoteStatus':'ERROR','needsQuote':True,'error':str(e)[:500]})
                        _save_status(master_job_id, st)
                except Exception:
                    pass
            finally:
                if acquired_ip:
                    try:
                        _release_public_job_slot(acquired_ip)
                    except Exception:
                        pass
        t = threading.Thread(target=_runner, daemon=True, name=f'job-create-{master_job_id}')
        t.start()


    def _write_api_jobs_crashlog(self, label: str, payload: dict | None = None, err: Exception | None = None, extra: dict | None = None) -> None:
        try:
            log_dir = JOBS / '_crash_logs'
            log_dir.mkdir(parents=True, exist_ok=True)
            ts = time.strftime('%Y%m%d_%H%M%S_') + uuid.uuid4().hex[:6]
            rec = {
                'ts': _now_iso(),
                'label': label,
                'error': _redact_sensitive_text(str(err), 600) if err else '',
                'traceback': _redact_sensitive_text(traceback.format_exc(), 4000) if err else '',
                'extra': extra or {},
            }
            if isinstance(payload, dict):
                try:
                    rec['complexity'] = self._estimate_job_complexity(payload)
                except Exception:
                    pass
                try:
                    rec['payload_keys'] = sorted(list(payload.keys()))
                except Exception:
                    pass
            _atomic_write_json(log_dir / f'api_jobs_{ts}.json', rec)
        except Exception:
            pass

    def _api_create_job(self):
        """Create a Tool B job using the proven synchronous path.

        Public route, but security-hardened with payload limits and basic abuse
        throttling because job creation is disk- and CPU-expensive.
        """
        ip = _client_ip(self)
        if not _rate_limit_allow('api_jobs', ip, 12 if _is_production_runtime() else 20, 300):
            try:
                _append_system_event(level="warning", component="jobs", message_user="Publieke jobroute rate-limited", message_tech=f"api_jobs rate limit for {ip}", status="open")
            except Exception:
                pass
            return self._send_json({"ok": False, "error": _public_error_message(429)}, 429)

        acquired = False
        slot_handed_off = False
        try:
            acquired, slot_reason = _try_acquire_public_job_slot(ip)
            if not acquired:
                try:
                    _append_system_event(level="warning", component="jobs", message_user="Publieke jobroute is te druk", message_tech=f"api_jobs concurrency block ({slot_reason}) for {ip}", status="open")
                except Exception:
                    pass
                return self._send_json({"ok": False, "error": "Server is momenteel druk met andere aanvragen. Probeer het zo opnieuw."}, 429)

            max_bytes = _env_int('PUBLIC_JSON_MAX_BYTES', 4194304 if _is_production_runtime() else 8388608)
            try:
                content_length = int(self.headers.get('Content-Length', '0') or '0')
            except Exception:
                content_length = 0
            if content_length and content_length > max_bytes:
                actual_mb = float(content_length) / 1024.0 / 1024.0
                limit_mb = float(max_bytes) / 1024.0 / 1024.0
                try:
                    _append_client_log('server', 'api_jobs_payload_block', 'Public job payload too large', {'contentLengthMb': round(actual_mb, 1), 'limitMb': round(limit_mb, 1)})
                except Exception:
                    pass
                return self._send_json({"ok": False, "error": "Deze configuratie bevat uitzonderlijk veel gegevens voor één aanvraag. Splits de bestelling op in meerdere aanvragen."}, 413)

            try:
                payload = _read_json_body_limited(self, 'PUBLIC_JSON_MAX_BYTES', max_bytes)
            except Exception as e:
                err_text = str(e)
                if err_text.startswith('JOB_PAYLOAD_TOO_LARGE::'):
                    return self._send_json({"ok": False, "error": "Deze configuratie is uitzonderlijk groot voor één aanvraag. Splits de bestelling op in meerdere aanvragen."}, 413)
                raise
            if not isinstance(payload, dict) or not payload:
                return self._send_json({"ok": False, "error": "Lege jobpayload."}, 400)

            try:
                top_level_keys = set(payload.keys())
                if top_level_keys and len(top_level_keys) > 64:
                    return self._send_json({"ok": False, "error": "Ongeldige aanvraag."}, 400)
            except Exception:
                pass
            qty_limit = _env_int('PUBLIC_JOB_TOTAL_QTY_LIMIT', 250)
            area_lb_limit = _env_int('PUBLIC_JOB_MAX_AREA_LB', 30)
            total_qty = _enforce_job_total_qty_limit(payload, qty_limit)
            area_info = _estimate_payload_area_lower_bound(payload)
            max_area_lb = int((area_info or {}).get('maxAreaLowerBound') or 0)
            try:
                _append_client_log('server', 'api_jobs_preflight', 'Public job guards passed', {'totalQty': int(total_qty), 'limitQty': int(qty_limit), 'maxAreaLowerBound': int(max_area_lb), 'maxAreaLowerBoundLimit': int(area_lb_limit)})
            except Exception:
                pass
            if max_area_lb > int(area_lb_limit):
                return self._send_json({"ok": False, "error": f"Deze configuratie is te groot voor één aanvraag. De geschatte minimale plaatbehoefte is minstens {max_area_lb} platen. Splits de bestelling op in meerdere aanvragen."}, 413)

            created_at = _now_iso()
            master_job_id = time.strftime('%Y%m%d_%H%M%S_') + uuid.uuid4().hex[:6]
            job_root = JOBS / master_job_id
            (job_root / 'input').mkdir(parents=True, exist_ok=True)
            (job_root / 'output').mkdir(parents=True, exist_ok=True)
            access_token = _new_public_access_token()
            _atomic_write_json(job_root / '.public_access.json', {
                'token': access_token,
                'jobId': master_job_id,
                'updatedAt': _utc_now_iso(),
            })
            complexity = self._estimate_job_complexity(payload)
            with _job_lock:
                _job_meta[master_job_id] = {
                    'status': 'processing',
                    'createdAt': created_at,
                    'acceptedAt': created_at,
                    'progressPct': 1,
                    'progressMessage': 'Aanvraag gestart',
                    'phase': 'accepted',
                    'complexity': complexity,
                }
            # FIX616: mirror every Tool A optimization job into the Admin request mailbox immediately.
            # This makes Tool A -> Admin visible even before the async optimizer finishes, and survives
            # service restarts because it writes a normal REQUESTS/<jobId>/status.json row.
            try:
                _ensure_request_dirs()
                req_inp = REQUESTS / master_job_id / 'input'
                req_inp.mkdir(parents=True, exist_ok=True)
                try:
                    _atomic_write_json(req_inp / 'submit_payload.json', payload)
                except Exception:
                    pass
                cust = payload.get('customer') if isinstance(payload.get('customer'), dict) else {}
                checkout = payload.get('checkout') if isinstance(payload.get('checkout'), dict) else {}
                if not cust and isinstance(checkout.get('customer'), dict):
                    cust = checkout.get('customer')
                fn = str((cust or {}).get('firstName') or (cust or {}).get('first_name') or '').strip()
                ln = str((cust or {}).get('lastName') or (cust or {}).get('last_name') or '').strip()
                nm = str((cust or {}).get('name') or (cust or {}).get('fullName') or (' '.join([x for x in [fn, ln] if x]).strip()) or '').strip()
                _save_status(master_job_id, {
                    'schemaVersion':'1.0',
                    'requestId': master_job_id,
                    'createdAt': created_at,
                    'updatedAt': created_at,
                    'customer': {
                        'name': nm, 'fullName': nm, 'firstName': fn, 'lastName': ln,
                        'email': str((cust or {}).get('email') or (cust or {}).get('mail') or '').strip(),
                        'phone': str((cust or {}).get('phone') or (cust or {}).get('tel') or '').strip(),
                    },
                    'publicStatus':'SUBMITTED',
                    'publicStatusLabel':'Aanvraag gestart',
                    'internalStatus':'PROCESSING',
                    'internalStatusLabel':'Optimaliseren',
                    'quoteStatus':'PROCESSING',
                    'needsQuote': True,
                    'job': {'parentJobId': master_job_id, 'subjobs': []},
                    'source':'api-jobs-live',
                })
            except Exception as _mirror_e:
                try:
                    _append_system_event(level='warning', component='admin', message_user='Admin mailbox kon startende job niet spiegelen', message_tech=str(_mirror_e), status='open')
                except Exception:
                    pass

            self._start_async_job_create(payload, master_job_id, access_token, ip)
            slot_handed_off = True
            return self._send_json({
                'ok': True,
                'jobId': master_job_id,
                'parentJobId': master_job_id,
                'subjobs': [],
                'accessToken': access_token,
                'meta': {
                    'status': 'processing',
                    'progressPct': 1,
                    'progressMessage': 'Aanvraag gestart',
                }
            }, 202)
        except Exception as e:
            err_text = str(e)
            if err_text.startswith('JOB_PAYLOAD_TOO_LARGE::'):
                try:
                    _, actual_s, limit_s = err_text.split('::', 2)
                    actual_mb = float(actual_s) / 1024.0 / 1024.0
                    limit_mb = float(limit_s) / 1024.0 / 1024.0
                    return self._send_json({
                        "ok": False,
                        "error": f"Deze aanvraag is te groot om veilig te verwerken ({actual_mb:.1f} MB). Het maximum is {limit_mb:.0f} MB. Splits de job op in meerdere delen en probeer het opnieuw."
                    }, 413)
                except Exception:
                    return self._send_json({
                        "ok": False,
                        "error": "Deze aanvraag is te groot om veilig te verwerken. Splits de job op in meerdere delen en probeer het opnieuw."
                    }, 413)
            if err_text.startswith('JOB_TOTAL_QTY_TOO_LARGE::'):
                try:
                    _, actual_s, limit_s = err_text.split('::', 2)
                    return self._send_json({
                        "ok": False,
                        "error": f"Deze aanvraag bevat te veel panelen om veilig te verwerken ({int(actual_s)}). Het maximum is {int(limit_s)} panelen. Splits de job op in meerdere delen."
                    }, 413)
                except Exception:
                    return self._send_json({
                        "ok": False,
                        "error": "Deze aanvraag bevat te veel panelen om veilig te verwerken. Splits de job op in meerdere delen."
                    }, 413)
            try:
                self._write_api_jobs_crashlog('api_create_job_exception', payload if 'payload' in locals() and isinstance(payload, dict) else None, e, {
                    'path': '/api/jobs',
                    'contentLength': str(self.headers.get('Content-Length') or ''),
                })
            except Exception:
                pass
            safe_msg = str(e).strip()
            if safe_msg and not safe_msg.startswith(('JOB_PAYLOAD_TOO_LARGE::', 'JOB_TOTAL_QTY_TOO_LARGE::')) and len(safe_msg) <= 240 and not any(ch in safe_msg for ch in ['Traceback', 'File "', '\n']):
                return self._send_json({"ok": False, "error": safe_msg}, 400)
            return self._send_json({"ok": False, "error": "Jobaanmaak mislukt"}, 400)
        finally:
            if acquired and not slot_handed_off:
                _release_public_job_slot(ip)


    def _api_status(self, job_id: str, parsed=None):
        """Return lightweight job status + quote for Tool A polling.

        Old builds relied on in-memory _job_meta, but that breaks after restarts and
        for parent/subjob fan-out runs. We infer status from the file-based outputs,
        keeping the system deterministic and resilient.
        """
        job_root = JOBS / job_id
        if not self._require_job_access(job_id, parsed=parsed, deny_as_json=True):
            return
        if not job_root.exists():
            return self._send_json({'meta': {'status': 'unknown'}, 'quote': None})

        def _load_quote(path: Path):
            if not path.exists():
                return None
            try:
                q = json.loads(path.read_text(encoding='utf-8'))
            except Exception:
                return None
            # ensure sell pricing shape compatibility where possible
            try:
                if isinstance(q, dict) and (q.get('sellPricing') is None):
                    q = _apply_sell_pricing_to_quote(q)
            except Exception:
                pass
            return q

        def _quote_grand_total(q: dict) -> float:
            """Best-effort extract of grand total from various quote formats."""
            if not isinstance(q, dict):
                return 0.0
            # Most authoritative: quote.json format uses totals.grandTotal
            cand = None
            try:
                cand = (q.get('totals') or {}).get('grandTotal')
            except Exception:
                cand = None
            if cand is None:
                # legacy / status-summary formats
                for k in ('grandTotal', 'total_incl_vat', 'totalInclVat', 'total'):
                    if q.get(k) is not None:
                        cand = q.get(k)
                        break
            try:
                return float(cand or 0.0)
            except Exception:
                return 0.0

        def _quote_sheet_count(q: dict) -> int:
            """Best-effort extract of sheet count."""
            if not isinstance(q, dict):
                return 0
            # Prefer explicit if present
            for k in ('sheetCount', 'sheetsCount'):
                if q.get(k) is not None:
                    try:
                        return int(q.get(k) or 0)
                    except Exception:
                        pass
            # quote.json format: sum materials[*].sheetCount if available
            try:
                mats = q.get('materials')
                if isinstance(mats, list):
                    s = 0
                    for m in mats:
                        if isinstance(m, dict) and m.get('sheetCount') is not None:
                            try:
                                s += int(m.get('sheetCount') or 0)
                            except Exception:
                                pass
                    if s:
                        return s
            except Exception:
                pass
            # fallback: totals.sheetCount
            try:
                return int((q.get('totals') or {}).get('sheetCount') or 0)
            except Exception:
                return 0


        inferred_status = 'unknown'
        quote = None

        # Parent job? (fan-out into __mat_ subjobs)
        subjob_dirs = [p for p in sorted(JOBS.glob(f"{job_id}__mat_*")) if p.is_dir()]
        if subjob_dirs:
            # Infer DONE only when every subjob has its core outputs *and* a final calculation summary.
            # This keeps Tool A from showing a quote-derived total before the authoritative summary exists.
            all_done = True
            sub_quotes = []
            for sp in subjob_dirs:
                out = sp / 'output'
                if not (out / 'placements.json').exists():
                    all_done = False
                if not (out / 'report.json').exists():
                    all_done = False
                if not ((sp / 'calculation_summary.txt').exists() or (out / 'calculation_summary.txt').exists()):
                    all_done = False
                q = _load_quote(out / 'quote.json')
                if isinstance(q, dict):
                    sub_quotes.append((sp.name, q))
            inferred_status = 'done' if all_done else 'processing'

            # Aggregate quote (best-effort) if parent quote is missing
            parent_quote = _load_quote((job_root / 'output' / 'quote.json'))
            if isinstance(parent_quote, dict):
                quote = parent_quote
            elif sub_quotes:
                total = 0.0
                sheet_count = 0
                currency = None
                for sid, q in sub_quotes:
                    if currency is None:
                        currency = q.get('currency')
                    try:
                        total += _quote_grand_total(q)
                    except Exception:
                        pass
                    try:
                        sheet_count += _quote_sheet_count(q)
                    except Exception:
                        pass
                # Provide BOTH the modern quote.json-like shape (totals.grandTotal) and
                # legacy summary fields (grandTotal/sheetCount) so Tool A can accept all formats.
                quote = {
                    'currency': currency or 'EUR',
                    'totals': {
                        'grandTotal': round(total, 2),
                        'sheetCount': sheet_count,
                    },
                    'grandTotal': round(total, 2),
                    'sheetCount': sheet_count,
                    'perSubjob': [
                        {
                            'subjobId': sid,
                            'currency': (q.get('currency') if isinstance(q, dict) else None) or (currency or 'EUR'),
                            'totals': {
                                'grandTotal': _quote_grand_total(q),
                                'sheetCount': _quote_sheet_count(q),
                            },
                            'grandTotal': _quote_grand_total(q),
                            'sheetCount': _quote_sheet_count(q),
                        }
                        for sid, q in sub_quotes
                    ],
                }
        else:
            out = job_root / 'output'
            quote = _load_quote(out / 'quote.json')
            has_calc = (job_root / 'calculation_summary.txt').exists() or (out / 'calculation_summary.txt').exists()
            if (((out / 'report.json').exists() or (out / 'placements.json').exists() or isinstance(quote, dict)) and has_calc):
                inferred_status = 'done'
            elif out.exists() or isinstance(quote, dict):
                inferred_status = 'processing'

        def _read_progress(root: Path):
            try:
                pp = root / 'output' / 'progress.json'
                if pp.exists():
                    pdata = json.loads(pp.read_text(encoding='utf-8') or '{}')
                    pct = pdata.get('percent')
                    msg = str(pdata.get('message') or pdata.get('phase') or '').strip()
                    if pct is not None:
                        try:
                            pct = max(0, min(100, int(round(float(pct)))))
                            return {'pct': pct, 'message': msg}
                        except Exception:
                            pass
                rp = root / 'output' / 'report.json'
                if not rp.exists():
                    return None
                data = json.loads(rp.read_text(encoding='utf-8') or '{}')
                prog = data.get('progress') if isinstance(data.get('progress'), dict) else {}
                pct = prog.get('percent') if isinstance(prog, dict) else None
                msg = str(prog.get('message') or prog.get('phase') or '').strip() if isinstance(prog, dict) else ''
                if pct is None and data.get('ok') is True:
                    pct = 100
                if pct is None:
                    return None
                try:
                    pct = max(0, min(100, int(round(float(pct)))))
                except Exception:
                    return None
                return {'pct': pct, 'message': msg}
            except Exception:
                return None

        with _job_lock:
            meta = _job_meta.get(job_id, {}) or {}
        meta2 = dict(meta)
        if inferred_status != 'unknown':
            meta2['status'] = inferred_status
        else:
            meta2.setdefault('status', 'unknown')

        progress_info = None
        meta_pct = int(meta2.get('progressPct') or 0)
        meta_msg = str(meta2.get('progressMessage') or '').strip()

        # Prefer live subjob progress while a job is still processing. The coarse master/meta
        # progress is only a floor/fallback; otherwise the UI can jump early to a stale 84/86/98.
        if subjob_dirs and meta2.get('status') not in ('done', 'ready', 'ok'):
            total = len(subjob_dirs)
            done_count = 0
            current_fraction = 0.0
            current_message = ''
            for sj in subjob_dirs:
                sj_out = sj / 'output'
                sj_quote = _load_quote(sj_out / 'quote.json')
                has_calc_summary = ((sj / 'calculation_summary.txt').exists()) or ((sj_out / 'calculation_summary.txt').exists())
                sj_done = (((sj_out / 'report.json').exists() or (sj_out / 'placements.json').exists() or isinstance(sj_quote, dict)) and has_calc_summary)
                if sj_done:
                    done_count += 1
                    continue
                prog = _read_progress(sj)
                if prog and prog.get('pct', 0) > 0:
                    frac = max(0.0, min(0.99, prog['pct'] / 100.0))
                    if frac >= current_fraction:
                        current_fraction = frac
                        current_message = prog.get('message') or current_message
            if total > 0:
                if done_count >= total:
                    # all subjobs finished; keep the master meta progress as the source for the true final server phase
                    if meta_pct > 0:
                        progress_info = {'pct': meta_pct, 'message': meta_msg}
                    else:
                        progress_info = {'pct': 99, 'message': meta_msg or 'Resultaten verwerken…'}
                else:
                    pct = int(round(((done_count + current_fraction) / float(total)) * 96.0))
                    pct = max(pct, min(96, meta_pct))
                    if pct > 0:
                        progress_info = {'pct': pct, 'message': current_message or meta_msg}
        elif meta_pct > 0:
            progress_info = {'pct': meta_pct, 'message': meta_msg}
        else:
            prog = _read_progress(job_root)
            if prog:
                progress_info = prog

        if progress_info:
            pct_val = int(progress_info.get('pct') or 0)
            if meta2.get('status') not in ('done', 'ready', 'ok'):
                pct_val = min(99, pct_val)
            meta2['progressPct'] = pct_val
            if progress_info.get('message'):
                meta2['progressMessage'] = progress_info.get('message')
            elif pct_val >= 95 and meta2.get('status') not in ('done', 'ready', 'ok'):
                meta2['progressMessage'] = 'Resultaten verwerken…'
        elif meta2.get('status') in ('done', 'ready', 'ok'):
            meta2['progressPct'] = 100
            meta2['progressMessage'] = meta2.get('progressMessage') or 'Optimalisatie afgerond'

        pricing_summary = {}
        try:
            candidate_job_ids = []
            for jid in [job_id] + [p.name for p in subjob_dirs]:
                if jid and jid not in candidate_job_ids:
                    candidate_job_ids.append(jid)
            # STRICT for Tool A status: only return a visible price once a finished
            # calculation summary exists. Never generate one on the fly from quote or
            # request payload fallbacks.
            pricing_summary = _extract_strict_calculation_pricing_summary(candidate_job_ids) if candidate_job_ids else {}
        except Exception:
            pricing_summary = {}

        return self._send_json({'meta': meta2, 'quote': quote, 'pricingSummary': pricing_summary})


    def _api_admin_jobs(self):
        jobs = []
        for p in sorted(JOBS.glob('*')):
            if not p.is_dir():
                continue
            job_id = p.name
            with _job_lock:
                meta = _job_meta.get(job_id, {})
            output_dir = p / 'output'
            sheets_dir = output_dir / 'sheets'
            sheets = []
        if sheets_dir.exists():
            sheets = [f.name for f in sorted(sheets_dir.glob('*.dxf'))] + [f.name for f in sorted(sheets_dir.glob('*.DXF'))]
            seen=set(); sheets=[x for x in sheets if (x.lower() not in seen and not seen.add(x.lower()))]

            jobs.append({
                'jobId': job_id,
                'status': meta.get('status', 'unknown'),
                'createdAt': meta.get('createdAt', ''),
                'sheets': sheets,
            })
        return self._send_json({'jobs': jobs})

    
    def _api_job_file(self, job_id: str, rel: str):
        job_root = JOBS / job_id
        if not job_root.exists():
            return self._send_text('Not found', 404)

        fpath = _safe_job_file(job_root, rel)
        if fpath is None or (not fpath.exists()) or (not fpath.is_file()):
            return self._send_text('Not found', 404)

        data = fpath.read_bytes()
        # basic content-type
        ctype = 'application/octet-stream'
        name = fpath.name.lower()
        if name.endswith('.json'):
            ctype = 'application/json'
        elif name.endswith('.csv'):
            ctype = 'text/csv'
        elif name.endswith('.txt'):
            ctype = 'text/plain'
        elif name.endswith('.dxf'):
            ctype = 'application/dxf'
        elif name.endswith('.html'):
            ctype = 'text/html'

        self.send_response(200)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Disposition', f'attachment; filename="{fpath.name}"')
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)

# ------------------------------
# API helpers (module-level)
# ------------------------------

def _start_master_split(master_job_id: str, master_input_dir: Path, master_output_dir: Path, subjobs: list[dict]):
    """Phase 1: Run Tool B per material subjob, then merge into a master order output.

    - Tool B is run only for subjobs.
    - Master output gets a merged quote.json (sell pricing applied once).
    - Master meta status is done only when all subjobs are done.
    """
    master_root = master_input_dir.parent
    try:
        master_output_dir.mkdir(parents=True, exist_ok=True)

        # Persist links index for Admin
        links = {
            "masterJobId": master_job_id,
            "createdAt": _now_iso(),
            "subjobs": [
                {
                    "jobId": sj["jobId"],
                    "materialCode": sj["materialCode"],
                    "materialKey": sj.get("materialKey"),
                    "materialName": sj.get("materialName"),
                    "grainEnabled": bool(sj.get("grainEnabled")),
                }
                for sj in subjobs
            ],
        }
        (master_output_dir / "links.json").write_text(json.dumps(links, indent=2), encoding="utf-8")

        any_error = False
        for sj in subjobs:
            job_id = sj["jobId"]
            with _job_lock:
                meta = _job_meta.get(job_id, {})
                meta["status"] = "running"
                meta["startedAt"] = _now_iso()
                _job_meta[job_id] = meta

            # Run Tool B (blocking) for this subjob
            _start_optimizer(job_id, sj["inputDir"], sj["outputDir"])

            with _job_lock:
                meta = _job_meta.get(job_id, {})
                if meta.get("status") != "done":
                    any_error = True

        # Merge raw quotes from subjobs (purchase model) and apply sell pricing once for the whole order
        raw_quotes = []
        for sj in subjobs:
            qpath = Path(sj["outputDir"]) / "quote.json"
            if qpath.exists():
                try:
                    raw_quotes.append(json.loads(qpath.read_text(encoding="utf-8")))
                except Exception:
                    pass

        merged_raw = _merge_raw_quotes(raw_quotes, master_job_id)
        merged_sell = _apply_sell_pricing_to_quote(merged_raw)
        (master_output_dir / "quote.json").write_text(json.dumps(merged_sell, indent=2), encoding="utf-8")

        # Build a master report with pointers
        master_report = {
            "ok": (not any_error),
            "jobId": master_job_id,
            "createdAt": _now_iso(),
            "subjobs": [
                {
                    "jobId": sj["jobId"],
                    "materialCode": sj["materialCode"],
                    "materialName": sj.get("materialName"),
                    "status": (_job_meta.get(sj["jobId"], {}).get("status") if True else "unknown"),
                }
                for sj in subjobs
            ],
        }
        (master_output_dir / "master_report.json").write_text(json.dumps(master_report, indent=2), encoding="utf-8")

        # Human-readable calculation summary for the MASTER order
        try:
            _write_human_calculation_summary(master_root)
        except Exception:
            pass

        with _job_lock:
            meta = _job_meta.get(master_job_id, {})
            meta["finishedAt"] = _now_iso()
            if any_error:
                meta["status"] = "error"
                meta["error"] = "One or more subjobs failed"
            else:
                meta["status"] = "done"
            _job_meta[master_job_id] = meta

    except Exception as e:
        with _job_lock:
            meta = _job_meta.get(master_job_id, {})
            meta["status"] = "error"
            meta["finishedAt"] = _now_iso()
            meta["error"] = str(e)
            _job_meta[master_job_id] = meta


def api_draft_save(self):
    try:
        length = int(self.headers.get('Content-Length', '0') or '0')
        raw = self.rfile.read(length) if length > 0 else b'{}'
        data = json.loads(raw.decode('utf-8') or '{}')
        draft_id = str(data.get('draft_id') or 'default')
        draft = data.get('draft') or {}

        safe = "".join(ch for ch in draft_id if ch.isalnum() or ch in ('-','_')).strip() or 'default'
        path = DRAFTS / f"{safe}.json"
        path.write_text(json.dumps(draft, ensure_ascii=False, indent=2), encoding='utf-8')
        return self._send_json({'ok': True, 'path': str(path.name)})
    except Exception:
        return self._send_json({'ok': False, 'error': 'Opslaan van concept is mislukt'}, code=500)


def api_dxf_manifest_meta(handler, parsed):
    """Return current embedded DXF catalog version.

    IMPORTANT: must not be cached by browsers/proxies, because Tool A relies on this
    to detect live updates when SSE is flaky or blocked.
    """
    try:
        version = get_embedded_dxfs_version()
        body = json.dumps({"version": version}).encode("utf-8")
        handler.send_response(200)
        handler.send_header("Content-Type", "application/json; charset=utf-8")
        handler.send_header("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate")
        handler.send_header("Pragma", "no-cache")
        handler.send_header("Expires", "0")
        handler.send_header("Content-Length", str(len(body)))
        handler.end_headers()
        handler.wfile.write(body)
    except Exception:
        handler._send_json({"version": None, "error": "Manifest ophalen is mislukt"}, code=500)


def api_draft_load(self, parsed):
    try:
        qs = parse_qs(parsed.query or '')
        draft_id = (qs.get('draft_id') or ['default'])[0]
        safe = "".join(ch for ch in str(draft_id) if ch.isalnum() or ch in ('-','_')).strip() or 'default'
        path = DRAFTS / f"{safe}.json"
        if not path.exists():
            return self._send_json({'ok': True, 'draft': None})
        draft = json.loads(path.read_text(encoding='utf-8') or '{}')
        return self._send_json({'ok': True, 'draft': draft})
    except Exception:
        return self._send_json({'ok': False, 'error': 'Laden van concept is mislukt', 'draft': None}, code=500)




def _edge_meters_by_decor(job_dir: Path):
    """Read input/panels.csv and sum required edge band meters per DecorName.

    Reporting-only helper for /admin. Never affects pricing or nesting.
    """
    try:
        import csv
        panels_path = job_dir / 'input' / 'panels.csv'
        if not panels_path.exists():
            return {}
        out = {}
        with panels_path.open('r', encoding='utf-8-sig', newline='') as f:
            reader = csv.DictReader(f)
            for r in reader:
                try:
                    qty = int(float((r.get('Qty') or '1').strip() or '1'))
                except Exception:
                    qty = 1
                try:
                    L = float((r.get('LengthMm') or '0').strip() or '0')
                    W = float((r.get('WidthMm') or '0').strip() or '0')
                except Exception:
                    L = 0.0; W = 0.0

                decor = (r.get('DecorName') or r.get('MaterialCode') or '').strip() or '—'

                def _code(name: str) -> int:
                    try:
                        return int(float((r.get(name) or '0').strip() or '0'))
                    except Exception:
                        return 0

                # Same meter model as Tool B quote: H* uses LengthMm, W* uses WidthMm
                meters = 0.0
                if _code('H1') != 0: meters += (L/1000.0) * qty
                if _code('H2') != 0: meters += (L/1000.0) * qty
                if _code('W1') != 0: meters += (W/1000.0) * qty
                if _code('W2') != 0: meters += (W/1000.0) * qty

                if meters <= 0:
                    continue
                out[decor] = out.get(decor, 0.0) + meters
        # round for display
        return {k: round(v, 3) for k, v in sorted(out.items(), key=lambda kv: kv[0].lower())}
    except Exception:
        return {}
def api_admin_jobs(self):
    jobs = []
    for p in sorted(JOBS.glob('*')):
        if not p.is_dir():
            continue
        job_id = p.name
        with _job_lock:
            meta = _job_meta.get(job_id, {})
        output_dir = p / 'output'
        # Ensure export folders are built even if a previous run skipped post-processing.
        try:
            _build_admin_dxf_exports(p)
        except Exception:
            pass
        sheets_dir = output_dir / 'sheets'
        sheets = []
        if sheets_dir.exists():
            # Tool B may output sheet files with .dxf/.DXF or (on some systems) without an extension (e.g. 'Sheet_001').
            # Also allow nested folders under sheets/.
            sheet_files = []
            sheet_files += [f for f in sorted(sheets_dir.rglob('*.dxf'))]
            sheet_files += [f for f in sorted(sheets_dir.rglob('*.DXF'))]
            sheet_files += [f for f in sorted(sheets_dir.rglob('*')) if f.is_file() and f.suffix == '' and f.name.lower().startswith('sheet')]
            # Return relative names (under output/sheets) so download endpoint works.
            rels = []
            for f in sheet_files:
                try:
                    rels.append(str(f.relative_to(sheets_dir)).replace('\\','/'))
                except Exception:
                    rels.append(f.name)
            seen=set(); sheets=[x for x in rels if (x.lower() not in seen and not seen.add(x.lower()))]


        # --- Zaagplaten ---
        # Return both the real filename (for download) and a human-friendly label for display.
        # Some runs use short filenames (e.g. "105574_S01.dxf") as a fallback for Windows path limits.
        # The workshop still needs to SEE customer + material in Admin.
        zaag_dir = output_dir / 'DXF_Zaagplaten'
        zaag_files = []
        if zaag_dir.exists():
            zaag_files = [f.name for f in sorted(zaag_dir.glob('*.dxf'))] + [f.name for f in sorted(zaag_dir.glob('*.DXF'))]
            seen=set(); zaag_files=[x for x in zaag_files if (x.lower() not in seen and not seen.add(x.lower()))]
            # De-duplicate per sheet index (S01, S02, ...) in case both a short and a long filename exist.
            # Preference: short physical filename like "105574_S01.dxf", otherwise the shortest name.
            try:
                import re as _re
                def _sheet_key(fn: str):
                    mm = _re.search(r'(S\d{2})', fn or '')
                    return mm.group(1).upper() if mm else (fn or '').lower()

                def _score(fn: str):
                    low = (fn or '').lower()
                    if _re.match(r'^\d+_s\d{2}\.dxf$', low):
                        return (0, len(fn))
                    return (1, len(fn))

                chosen = {}
                for fn in zaag_files:
                    k = _sheet_key(fn)
                    if k not in chosen or _score(fn) < _score(chosen[k]):
                        chosen[k] = fn
                zaag_files = [chosen[k] for k in sorted(chosen.keys())]
            except Exception:
                pass


        # Build label context from input.
        customer_name = ""
        try:
            job_json_path = (p / 'input' / 'job.json')
            if job_json_path.exists():
                jj = json.loads(job_json_path.read_text(encoding='utf-8'))
                cust = (jj.get('customer') or {})
                if isinstance(cust, dict):
                    fn = str(cust.get('first_name') or cust.get('firstName') or '').strip()
                    ln = str(cust.get('last_name')  or cust.get('lastName')  or '').strip()
                    customer_name = " ".join([fn, ln]).strip()
        except Exception:
            customer_name = ""

        decor_name = ""
        mat_code = ""
        try:
            panels_path = (p / 'input' / 'panels.csv')
            if panels_path.exists():
                rows = _parse_panels_csv(panels_path.read_text(encoding='utf-8'))
                if rows:
                    r0 = rows[0]
                    decor_name = (r0.get('DecorName') or r0.get('decorName') or '').strip()
                    mat_code = (r0.get('MaterialCode') or r0.get('materialCode') or '').strip()
        except Exception:
            decor_name = ""; mat_code = ""

        def _label_for_file(fname: str) -> str:
            # If already contains customer/material, keep as-is.
            low = (fname or '').lower()
            if '__' in low or (customer_name and customer_name.lower().replace(' ','_') in low):
                return fname
            # Build friendly label for short fallback names like 105574_S01.dxf / S01.dxf
            base = fname
            try:
                import re
                m = re.search(r'(S\d{2})', fname)
                sfx = m.group(1) if m else ''
                parts = []
                if customer_name:
                    parts.append(_sanitize_filename(customer_name, 30))
                if decor_name:
                    parts.append(_sanitize_filename(decor_name, 40))
                if mat_code:
                    parts.append(_sanitize_filename(mat_code, 20))
                if sfx:
                    parts.append(sfx)
                if parts:
                    base = "_".join(parts) + '.dxf'
            except Exception:
                base = fname
            return base

        zaag = [{'file': f, 'label': _label_for_file(f)} for f in zaag_files]


        parts_dir = output_dir / 'DXF_Onderdelen'
        parts = []
        if parts_dir.exists():
            parts = [f.name for f in sorted(parts_dir.glob('*.dxf'))] + [f.name for f in sorted(parts_dir.glob('*.DXF'))]
            seen=set(); parts=[x for x in parts if (x.lower() not in seen and not seen.add(x.lower()))]


        jobs.append({
            'jobId': job_id,
            'status': meta.get('status', 'unknown'),
            'createdAt': meta.get('createdAt', ''),
            'sheets': sheets,
            'zaagplaten': zaag,
            'onderdelen': parts,
            'edgeBandByDecorMeters': _edge_meters_by_decor(p),
            'customerName': customer_name,
        })
    return self._send_json({'jobs': jobs})



def _classify_output_kind(name: str) -> str:
    n = str(name or '').lower()
    if n.endswith('.dxf'):
        return 'dxf'
    if n == 'quote.json':
        return 'quote'
    if n == 'report.json':
        return 'report'
    if n == 'placements.json':
        return 'placements'
    if n == 'stickers.json':
        return 'stickers'
    if n == 'stickertool.json':
        return 'stickertool'
    if n == 'calculation_summary.txt':
        return 'summary'
    if n == 'pricing.json':
        return 'pricing'
    return 'other'


def _collect_job_output_files(job_id: str) -> list[dict]:
    job_id = _safe_id(str(job_id or '').strip(), 200)
    if not job_id:
        return []
    out_root = JOBS / job_id / 'output'
    if not out_root.exists():
        return []
    code = ''
    if '__mat_' in job_id:
        code = job_id.split('__mat_', 1)[1].strip()
    material_name = _best_material_name(code, '') if code else ''
    rows = []
    for fp in sorted(out_root.rglob('*')):
        if not fp.is_file():
            continue
        rel = fp.relative_to(JOBS / job_id).as_posix()
        kind = _classify_output_kind(fp.name)
        rows.append({
            'jobId': job_id,
            'materialCode': code,
            'materialName': material_name,
            'name': fp.name,
            'rel': rel,
            'kind': kind,
            'size': fp.stat().st_size if fp.exists() else 0,
            'mtime': datetime.utcfromtimestamp(fp.stat().st_mtime).isoformat() + 'Z' if fp.exists() else '',
        })
    return rows




def _dedupe_admin_dxf_files(files: list[dict]) -> list[dict]:
    """Hide duplicate generic Sheet_001.dxf-style files in Admin when a renamed
    workshop-friendly S01 export exists for the same sheet. Keep generic Sheet files
    only as a fallback when no nicer counterpart is available.
    """
    try:
        import re as _re
        rows = list(files or [])

        def _sheet_key(name: str) -> str:
            n = str(name or '').strip()
            m = _re.search(r'(?:^|[^a-z0-9])s(\d{2})(?:\.dxf)?$', n, _re.I)
            if m:
                return f"S{int(m.group(1)):02d}"
            m = _re.fullmatch(r'sheet[_\- ]?(\d+)(?:\.dxf)?', n, _re.I)
            if m:
                return f"S{int(m.group(1)):02d}"
            return n.lower()

        def _is_generic_sheet(name: str) -> bool:
            return bool(_re.fullmatch(r'sheet[_\- ]?\d+(?:\.dxf)?', str(name or '').strip(), _re.I))

        chosen = {}
        for f in rows:
            name = str((f or {}).get('name') or '')
            key = _sheet_key(name)
            cur = chosen.get(key)
            if cur is None:
                chosen[key] = f
                continue
            cur_generic = _is_generic_sheet(str(cur.get('name') or ''))
            new_generic = _is_generic_sheet(name)
            if cur_generic and not new_generic:
                chosen[key] = f
                continue
            if cur_generic == new_generic:
                # Keep shorter rel/name as a deterministic fallback.
                cur_score = (len(str(cur.get('rel') or cur.get('name') or '')), len(str(cur.get('name') or '')))
                new_score = (len(str(f.get('rel') or f.get('name') or '')), len(name))
                if new_score < cur_score:
                    chosen[key] = f

        # Preserve stable ordering from original rows.
        keep_ids = {id(v) for v in chosen.values()}
        return [f for f in rows if id(f) in keep_ids]
    except Exception:
        return list(files or [])

def _extract_strict_calculation_pricing_summary(job_ids: list[str]) -> dict:
    """Strict authoritative pricing for Tool A status/submit flows.

    Only return pricing when a final human calculation summary exists for one of the
    candidate jobs. Never fall back to request payloads, legacy quote totals, or
    interim frontend values. This prevents stale/partial prices from surfacing in
    the first price overlay before the true server calculation is finished.
    """
    out = {
        'materialsTotal': None,
        'edgeBandTotal': None,
        'cncTotal': None,
        'drawingTotal': None,
        'transportTotal': None,
        'subtotalExVat': None,
        'vatAmount': None,
        'totalInclVat': None,
        'currency': 'EUR',
        'source': '',
    }
    for jid in (job_ids or []):
        if not jid:
            continue
        try:
            jr = JOBS / jid
            calc = _parse_calculation_summary_totals(jr)
            if isinstance(calc, dict) and (calc.get('subtotalExVat') is not None or calc.get('totalInclVat') is not None):
                for k in ('materialsTotal','edgeBandTotal','cncTotal','drawingTotal','transportTotal','subtotalExVat','vatAmount','totalInclVat'):
                    out[k] = calc.get(k)
                out['source'] = 'calculation-summary'
                return out
        except Exception:
            pass
    return out

def _extract_admin_pricing_summary(job_ids: list[str], request_status: dict | None = None) -> dict:
    """Best-effort compact price breakdown for Admin orderdetails.

    STRICT: prefer totals from calculation_summary.txt when available,
    so the Admin card matches the downloadable berekening exactly.
    """
    out = {
        'materialsTotal': None,
        'edgeBandTotal': None,
        'cncTotal': None,
        'drawingTotal': None,
        'transportTotal': None,
        'subtotalExVat': None,
        'vatAmount': None,
        'totalInclVat': None,
        'currency': 'EUR',
        'source': '',
    }

    # STRICT source of truth: the human calculation summary.
    for jid in job_ids:
        if not jid:
            continue
        try:
            calc = _parse_calculation_summary_totals(JOBS / jid)
            if isinstance(calc, dict) and (calc.get('subtotalExVat') is not None or calc.get('totalInclVat') is not None):
                out['subtotalExVat'] = calc.get('subtotalExVat')
                out['vatAmount'] = calc.get('vatAmount')
                out['totalInclVat'] = calc.get('totalInclVat')
                out['source'] = 'calculation-summary'
                return out
        except Exception:
            pass


    def _merge(candidate: dict, label: str) -> bool:
        changed = False
        for k in ('materialsTotal','edgeBandTotal','cncTotal','drawingTotal','transportTotal','subtotalExVat','vatAmount','totalInclVat'):
            v = candidate.get(k)
            if v is not None and out.get(k) is None:
                out[k] = v
                changed = True
        if changed and not out.get('source'):
            out['source'] = label
        return (out.get('totalInclVat') is not None) or (out.get('subtotalExVat') is not None and any(out.get(x) is not None for x in ('materialsTotal','edgeBandTotal','cncTotal','drawingTotal','transportTotal')))

    for jid in job_ids:
        if not jid:
            continue
        for fp, label in (
            (JOBS / jid / 'output' / 'quote.json', 'job-output-quote'),
            (JOBS / jid / 'output' / 'pricing.json', 'job-output-pricing'),
            (JOBS / jid / 'input' / 'pricing.json', 'job-input-pricing'),
        ):
            try:
                if fp.exists():
                    data = json.loads(fp.read_text(encoding='utf-8') or '{}')
                    if _merge(_extract_pricing_from_any(data), label):
                        return out
            except Exception:
                pass

    payload = _load_request_payload(str(request_status.get('requestId') or '')) if isinstance(request_status, dict) else {}
    if isinstance(payload, dict) and payload:
        for src_name in ('quote','pricing','summary'):
            src = payload.get(src_name)
            if isinstance(src, dict):
                if _merge(_extract_pricing_from_any(src), f'request-payload-{src_name}'):
                    return out
        try:
            summ = _extract_request_summary(payload)
            if out['totalInclVat'] is None and summ.get('priceInclVat') is not None:
                out['totalInclVat'] = round(float(summ['priceInclVat']), 2)
            if out['materialsTotal'] is None and summ.get('materialsPrice') is not None:
                out['materialsTotal'] = round(float(summ['materialsPrice']), 2)
            if out['vatAmount'] is None and out['subtotalExVat'] is not None and out['totalInclVat'] is not None:
                out['vatAmount'] = round(out['totalInclVat'] - out['subtotalExVat'], 2)
            if (out['totalInclVat'] is not None or out['materialsTotal'] is not None) and not out.get('source'):
                out['source'] = 'request-payload-summary'
        except Exception:
            pass

    if isinstance(request_status, dict):
        for src_name in ('quote','summary','pricing'):
            src = request_status.get(src_name)
            if isinstance(src, dict):
                if _merge(_extract_pricing_from_any(src), f'request-status-{src_name}'):
                    return out

    if out['subtotalExVat'] is None and out['totalInclVat'] is not None:
        try:
            out['subtotalExVat'] = round(float(out['totalInclVat']) / 1.21, 2)
        except Exception:
            pass
    if out['vatAmount'] is None and out['subtotalExVat'] is not None and out['totalInclVat'] is not None:
        out['vatAmount'] = round(out['totalInclVat'] - out['subtotalExVat'], 2)
    return out

def _find_or_generate_stickertool_file(job_id: str):
    """Return best admin-visible sticker file info for a *material subjob* only.

    Important: parent jobs must NEVER surface a fallback stickertool file, because that
    creates empty/unknown exports (materialCode empty, items []). Stickertool is only
    valid per material-subjob.
    """
    try:
        jid = str(job_id or '').strip()
        if not jid or '__mat_' not in jid:
            return None
        job_root = JOBS / jid
        out = job_root / 'output'
        cand = [out / 'stickertool.json', out / 'stickers.json']
        for fp in cand:
            if fp.exists() and fp.is_file():
                try:
                    data = json.loads(fp.read_text(encoding='utf-8') or '{}')
                    if str(data.get('materialCode') or '').strip() and isinstance(data.get('items'), list) and len(data.get('items') or []) > 0:
                        return fp
                except Exception:
                    continue
        try:
            _generate_stickertool_json(job_root)
        except Exception:
            pass
        for fp in cand:
            if fp.exists() and fp.is_file():
                try:
                    data = json.loads(fp.read_text(encoding='utf-8') or '{}')
                    if str(data.get('materialCode') or '').strip() and isinstance(data.get('items'), list) and len(data.get('items') or []) > 0:
                        return fp
                except Exception:
                    continue
    except Exception:
        pass
    return None




def _dir_size_bytes(root: Path) -> int:
    try:
        total = 0
        if not root.exists() or not root.is_dir():
            return 0
        for fp in root.rglob('*'):
            try:
                if fp.is_file():
                    total += fp.stat().st_size
            except Exception:
                pass
        return int(total)
    except Exception:
        return 0

def _build_request_file_manifest(request_id: str) -> dict:
    st = _load_status(request_id) or {}
    job = st.get('job') if isinstance(st.get('job'), dict) else {}
    parent = _safe_id(str(job.get('parentJobId') or '').strip(), 200)
    subjobs = []
    for sj in (job.get('subjobs') or []):
        sj_id = ''
        if isinstance(sj, dict):
            sj_id = str(sj.get('subjobId') or sj.get('jobId') or sj.get('id') or '').strip()
        else:
            sj_id = str(sj or '').strip()
        sj_id = _safe_id(sj_id, 200) if sj_id else ''
        if sj_id and sj_id not in subjobs:
            subjobs.append(sj_id)
    job_ids = []
    for jid in ([parent] if parent else []) + subjobs:
        if jid and jid not in job_ids:
            job_ids.append(jid)

    groups = []
    summary_files = []
    all_files = []
    seen_summary = set()
    for jid in job_ids:
        try:
            _write_human_calculation_summary(JOBS / jid, st)
        except Exception:
            pass
        files = _collect_job_output_files(jid)
        # Ensure stickertool alias is surfaced if worker generated it or can generate it lazily
        st_fp = _find_or_generate_stickertool_file(jid)
        if st_fp is not None:
            rel = st_fp.relative_to(JOBS / jid).as_posix()
            if not any(str(f.get('rel') or '') == rel for f in files):
                code2 = jid.split('__mat_', 1)[1].strip() if '__mat_' in jid else ''
                files.append({
                    'jobId': jid,
                    'materialCode': code2,
                    'materialName': _best_material_name(code2, '') if code2 else '',
                    'name': st_fp.name,
                    'rel': rel,
                    'kind': _classify_output_kind(st_fp.name),
                    'size': st_fp.stat().st_size if st_fp.exists() else 0,
                    'mtime': datetime.utcfromtimestamp(st_fp.stat().st_mtime).isoformat() + 'Z' if st_fp.exists() else '',
                })
        if not files:
            continue
        all_files.extend(files)
        code = ''
        if '__mat_' in jid:
            code = jid.split('__mat_', 1)[1].strip()
        material_name = _best_material_name(code, '') if code else ''
        label = material_name or code or jid
        # Admin request detail should show only full sheet-layout DXFs here.
        # Part DXFs live in output/DXF_Onderdelen and must stay hidden in this block.
        sheet_dxf_files = _dedupe_admin_dxf_files([
            f for f in files
            if str(f.get('kind') or '') == 'dxf'
            and str(f.get('rel') or '').startswith('output/DXF_Zaagplaten/')
        ])
        if sheet_dxf_files:
            groups.append({
                'jobId': jid,
                'materialCode': code,
                'materialName': material_name,
                'label': label,
                'files': sheet_dxf_files,
            })
        for f in files:
            fkind = str(f.get('kind') or '')
            if fkind in ('quote','report','placements','stickers','stickertool','summary','pricing'):
                # Stickertool/Stickers are only valid per material subjob. Never surface
                # parent-level fallback files in Admin, because they produce empty items
                # and unknown material info.
                if fkind in ('stickers','stickertool') and '__mat_' not in str(jid or ''):
                    continue
                key = (fkind, jid)
                if key not in seen_summary:
                    seen_summary.add(key)
                    summary_files.append(f)

    for f in all_files:
        jid = quote(str(f.get('jobId') or ''), safe='')
        relq = quote(str(f.get('rel') or ''), safe='/')
        f['url'] = f"/api/admin/request_file?requestId={quote(request_id)}&jobId={jid}&rel={relq}"

    pricing_summary = _extract_admin_pricing_summary(job_ids, st)

    request_dir = REQUESTS / request_id
    request_bytes = _dir_size_bytes(request_dir)
    jobs_bytes = 0
    for jid in job_ids:
        try:
            jobs_bytes += _dir_size_bytes(JOBS / jid)
        except Exception:
            pass
    total_bytes = int(request_bytes + jobs_bytes)

    return {
        'requestId': request_id,
        'parentJobId': parent,
        'subjobs': subjobs,
        'summaryFiles': summary_files,
        'dxfGroups': groups,
        'allFiles': all_files,
        'pricingSummary': pricing_summary,
        'storageSummary': {
            'requestBytes': int(request_bytes),
            'jobsBytes': int(jobs_bytes),
            'totalBytes': total_bytes,
            'jobCount': len(job_ids),
            'subjobCount': len(subjobs),
        },
        'zip': {
            'allOutputsUrl': f"/api/admin/request_download_zip?requestId={quote(request_id)}&scope=all",
            'allDxfUrl': f"/api/admin/request_download_zip?requestId={quote(request_id)}&scope=dxf",
        }
    }


def api_admin_request_files(self):
    parsed = urlparse(self.path)
    qs = parse_qs(parsed.query or '')
    rid = _safe_id(str((qs.get('requestId') or [''])[0]).strip(), 120)
    if not rid:
        return self._send_json({'ok': False, 'error': 'Missing requestId'}, 400)
    st = _load_status(rid)
    if not isinstance(st, dict):
        return self._send_json({'ok': False, 'error': 'Unknown requestId'}, 404)
    manifest = _build_request_file_manifest(rid)
    return self._send_json({'ok': True, 'requestId': rid, 'files': manifest})


def api_admin_request_file(self):
    parsed = urlparse(self.path)
    qs = parse_qs(parsed.query or '')
    rid = _safe_id(str((qs.get('requestId') or [''])[0]).strip(), 120)
    job_id = _safe_id(str((qs.get('jobId') or [''])[0]).strip(), 200)
    rel = str((qs.get('rel') or [''])[0]).strip()
    if not rid or not job_id or not rel:
        return self._send_text('Missing requestId/jobId/rel', 400)
    st = _load_status(rid)
    if not isinstance(st, dict):
        return self._send_text('Unknown requestId', 404)
    manifest = _build_request_file_manifest(rid)
    allowed = False
    for f in (manifest.get('allFiles') or []):
        if str(f.get('jobId') or '') == job_id and str(f.get('rel') or '') == rel:
            allowed = True
            break
    if not allowed:
        return self._send_text('File not linked to this request', 404)
    return api_job_file(self, job_id, rel)


def api_admin_request_download_zip(self):
    parsed = urlparse(self.path)
    qs = parse_qs(parsed.query or '')
    rid = _safe_id(str((qs.get('requestId') or [''])[0]).strip(), 120)
    scope = str((qs.get('scope') or ['all'])[0]).strip().lower()
    if not rid:
        return self._send_text('Missing requestId', 400)
    st = _load_status(rid)
    if not isinstance(st, dict):
        return self._send_text('Unknown requestId', 404)
    manifest = _build_request_file_manifest(rid)
    files = manifest.get('allFiles') or []
    if scope == 'dxf':
        files = [f for f in files if f.get('kind') == 'dxf']
    if not files:
        return self._send_text('No files for this request', 404)
    bio = io.BytesIO()
    with zipfile.ZipFile(bio, 'w', zipfile.ZIP_DEFLATED) as zf:
        for f in files:
            job_id = _safe_id(str(f.get('jobId') or ''), 200)
            rel = str(f.get('rel') or '')
            safe = _safe_job_file(JOBS / job_id, rel)
            if safe is None or (not safe.exists()) or (not safe.is_file()):
                continue
            code = str(f.get('materialCode') or '').strip()
            prefix = job_id
            if scope == 'dxf' and code:
                prefix = code
            arcname = f"{prefix}/{Path(rel).name}"
            try:
                zf.writestr(arcname, safe.read_bytes())
            except Exception:
                pass
    data = bio.getvalue()
    fname = f"{rid}_{'dxf' if scope == 'dxf' else 'outputs'}.zip"
    self.send_response(200)
    self.send_header('Content-Type', 'application/zip')
    self.send_header('Content-Length', str(len(data)))
    safe_name = _sanitize_filename(fname, 120) or 'download.zip'
    self.send_header('Content-Disposition', f'attachment; filename="{safe_name}"')
    self.end_headers()
    self.wfile.write(data)


def api_admin_requests(self):
    """Admin endpoint: list requests (mailbox)."""
    _ensure_request_dirs()
    # optional limit
    parsed = urlparse(self.path)
    qs = parse_qs(parsed.query or "")
    try:
        limit = int((qs.get("limit") or ["200"])[0])
    except Exception:
        limit = 200
    limit = max(1, min(2000, limit))

    rows = []
    for p in sorted(REQUESTS.glob("*")):
        if not p.is_dir():
            continue
        rid = p.name
        st_path = p / "status.json"
        if not st_path.exists():
            continue
        try:
            st = json.loads(st_path.read_text(encoding="utf-8"))
        except Exception:
            continue
        st["requestId"] = rid
        rows.append(st)

    # FIX594: direct Tool A optimization jobs may exist without a REQUESTS mailbox row.
    # Mirror those master jobs into the admin request list so Tool A -> Admin is live.
    try:
        existing_ids = {str(r.get("requestId") or "") for r in rows}
        for jp in sorted(JOBS.glob("*"), key=lambda x: x.stat().st_mtime if x.exists() else 0, reverse=True):
            if not jp.is_dir():
                continue
            job_id = jp.name
            # Material subjobs are children of a master order; show the master only in the mailbox.
            if "__mat_" in job_id:
                continue
            if job_id in existing_ids:
                continue
            job_json = {}
            try:
                jpath = jp / "input" / "job.json"
                if jpath.exists():
                    job_json = json.loads(jpath.read_text(encoding="utf-8") or "{}")
            except Exception:
                job_json = {}
            cust = job_json.get("customer") if isinstance(job_json.get("customer"), dict) else {}
            if not cust:
                order = job_json.get("order") if isinstance(job_json.get("order"), dict) else {}
                cust = {
                    "name": order.get("customer_name") or order.get("customerName") or "—",
                    "email": order.get("email") or "",
                    "phone": order.get("phone") or "",
                }
            created = ""
            try:
                created = datetime.datetime.fromtimestamp(jp.stat().st_mtime).isoformat(timespec="seconds")
            except Exception:
                created = ""
            status = "DONE" if (jp / "output" / "calculation_summary.txt").exists() else "PROCESSING"
            subjobs = []
            try:
                for child in sorted(JOBS.glob(job_id + "__mat_*")):
                    if child.is_dir():
                        subjobs.append({"subjobId": child.name, "jobId": child.name, "status": "DONE" if (child / "output").exists() else "PROCESSING"})
            except Exception:
                subjobs = []
            rows.append({
                "requestId": job_id,
                "createdAt": created,
                "updatedAt": created,
                "customer": cust or {"name": "—"},
                "publicStatus": "DONE" if status == "DONE" else "SUBMITTED",
                "publicStatusLabel": "Klaar" if status == "DONE" else "Aanvraag verzonden",
                "internalStatus": status,
                "internalStatusLabel": "Klaar" if status == "DONE" else "Bezig",
                "quoteStatus": "DONE" if status == "DONE" else "TODO",
                "needsQuote": False if status == "DONE" else True,
                "job": {"parentJobId": job_id, "subjobs": subjobs},
                "source": "jobs-fallback",
            })
            existing_ids.add(job_id)
    except Exception as e:
        try:
            _append_system_event(level="warning", component="admin", message_user="Admin kon job fallback niet volledig opbouwen", message_tech=str(e), status="open")
        except Exception:
            pass

    # newest first
    def _key(x):
        return str(x.get("createdAt") or x.get("updatedAt") or "")
    rows.sort(key=_key, reverse=True)
    rows = rows[:limit]
    return self._send_json({"ok": True, "requests": rows})

def api_admin_requests_update(self):
    """Admin endpoint: update request mailbox status (e.g., mark quote sent)."""
    _ensure_request_dirs()
    try:
        body = _read_json_body_limited(self, 'ADMIN_JSON_MAX_BYTES', 262144)
    except Exception as e:
        return self._send_json({"ok": False, "error": _public_error_message(400)}, 400)

    rid = _safe_id(str(body.get("requestId") or "").strip(), 120)
    if not rid:
        return self._send_json({"ok": False, "error": "Missing requestId"}, 400)

    st = _load_status(rid)
    if not isinstance(st, dict):
        return self._send_json({"ok": False, "error": "Unknown requestId"}, 404)

    action = str(body.get("action") or "").strip().lower()
    if action == "mark_quote_sent":
        st["quoteStatus"] = "DONE"
        st["needsQuote"] = False
        st["publicStatus"] = "DONE"
        st["publicStatusLabel"] = "Afgehandeld"
        st["internalStatus"] = "DONE"
        st["internalStatusLabel"] = "Afgehandeld"
    elif action == "reopen":
        st["quoteStatus"] = "TODO"
        st["needsQuote"] = True
        st["publicStatus"] = "SUBMITTED"
        st["publicStatusLabel"] = "Aanvraag verzonden"
        if str(st.get("internalStatus") or "").upper() in ("PROCESSING", "OFFER_SENT", ""):
            st["internalStatus"] = "QUEUED"
            st["internalStatusLabel"] = "In wachtrij"
    else:
        return self._send_json({"ok": False, "error": "Unknown action"}, 400)

    _save_status(rid, st)
    return self._send_json({"ok": True})


def api_job_file(self, job_id: str, rel: str, parsed=None):
    """Serve a file inside jobs/<jobId> safely.

    This endpoint is used by Admin downloads. It must never fail silently
    (ERR_EMPTY_RESPONSE). If something goes wrong, return an error body.
    """
    try:
        if not self._require_job_access(job_id, parsed=parsed):
            return
        job_root = JOBS / job_id
        if not job_root.exists():
            return self._send_text('Not found', 404)

        fpath = _safe_job_file(job_root, rel)
        if fpath is None:
            return self._send_text('Not found', 404)

        # Robust path for calculation summary: some runs write it to both input/ and output/.
        rel_l = (rel or '').replace('\\', '/').lstrip('/').lower()
        if (not fpath.exists()) and rel_l in ('output/calculation_summary.txt', 'input/calculation_summary.txt'):
            alt_rel = 'input/calculation_summary.txt' if 'output/' in rel_l else 'output/calculation_summary.txt'
            alt = _safe_job_file(job_root, alt_rel)
            if alt is not None and alt.exists() and alt.is_file():
                fpath = alt

        if (not fpath.exists()) or (not fpath.is_file()):
            return self._send_text('Not found', 404)

        data = fpath.read_bytes()

        ctype = 'application/octet-stream'
        name = fpath.name.lower()
        if name.endswith('.json'):
            ctype = 'application/json'
        elif name.endswith('.csv'):
            ctype = 'text/csv'
        elif name.endswith('.txt'):
            ctype = 'text/plain'
        elif name.endswith('.dxf'):
            ctype = 'application/dxf'
        elif name.endswith('.html'):
            ctype = 'text/html'

        # Friendly download name for Stickertool v2
        download_name = fpath.name
        try:
            rel_norm = (rel or '').replace('\\', '/').lstrip('/')
            if rel_norm == 'output/stickertool.json':
                job_json_path = job_root / 'input' / 'job.json'
                job_json = {}
                if job_json_path.exists():
                    try:
                        job_json = json.loads(job_json_path.read_text(encoding='utf-8'))
                    except Exception:
                        job_json = {}
                cust_name = _customer_name_from_job(job_json)
                safe_cust = _sanitize_filename(cust_name or 'Onbekend', 50)
                safe_job = _sanitize_filename(job_id, 60)
                download_name = f"{safe_cust}__{safe_job}__stickertool.json"
        except Exception:
            download_name = fpath.name

        self.send_response(200)
        self.send_header('Cache-Control', 'no-store')
        if ctype == 'application/json':
            self.send_header('Content-Type', 'application/json; charset=utf-8')
        else:
            self.send_header('Content-Type', ctype)
        self.send_header('Content-Disposition', f'attachment; filename="{download_name}"')
        self.send_header('Content-Length', str(len(data)))
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.end_headers()
        self.wfile.write(data)
        return
    except Exception as e:
        return self._send_text('Error serving file', 500)



def api_stickertool_v2(self, subjob_id: str):
    """Serve Stickertool v2 contract JSON for a subjob without needing master job id.
    Preferred disk path: jobs/<subjobId>/output/stickers.json
    Fallbacks: jobs/<subjobId>/output/stickertool.json and canonical nested path if present.
    """
    base = JOBS / subjob_id

    # Try canonical nested contract path as well (jobs/<baseJobId>/subjobs/<subjobId>/output/stickers.json)
    base_job_id = subjob_id.split('__mat_')[0] if '__mat_' in subjob_id else ''
    if base_job_id:
        canonical_base = JOBS / base_job_id / 'subjobs' / subjob_id
        if canonical_base.exists():
            f_can = _safe_job_file(canonical_base, 'output/stickers.json')
            if f_can and f_can.exists() and f_can.is_file():
                data = f_can.read_bytes()
                self.send_response(200)
                self.send_header('Content-Type', 'application/json; charset=utf-8')
                self.send_header('Cache-Control', 'no-store')
                self.send_header('Content-Disposition', 'attachment; filename="stickertool.json"')
                self.send_header('Content-Length', str(len(data)))
                self.end_headers()
                self.wfile.write(data)
                return

    if not base.exists():
        return self._send_text('Not found', 404)

    for rel in ('output/stickers.json', 'output/stickertool.json'):
        f = _safe_job_file(base, rel)
        if f and f.exists() and f.is_file():
            data = f.read_bytes()
            self.send_response(200)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Cache-Control', 'no-store')
            self.send_header('Content-Disposition', 'attachment; filename="stickertool.json"')
            self.send_header('Content-Length', str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

    return self._send_text('Not found', 404)


def api_subjob_file(self, job_id: str, subjob_id: str, rel: str, parsed=None):
    """Serve a file from jobs/<jobId>/subjobs/<subjobId>/<rel>.
    Used for Stickertool v2 contract exports (stickers.json)."""
    if not (self._require_job_access(job_id, parsed=parsed) or self._require_job_access(subjob_id, parsed=parsed)):
        return
    base = JOBS / job_id / 'subjobs' / subjob_id
    # Some legacy runs may not have the nested subjobs structure on disk; in that case we
    # fall back to serving directly from jobs/<subjobId>/ (mirror path).
    fallback_base = JOBS / subjob_id
    if not base.exists() and not fallback_base.exists():
        return self._send_text('Not found', 404)

    fpath = _safe_job_file(base if base.exists() else fallback_base, rel)
    if fpath is None or (not fpath.exists()) or (not fpath.is_file()):
        # If nested path exists but the file doesn't, try mirror location too.
        if fallback_base.exists():
            f2 = _safe_job_file(fallback_base, rel)
            if f2 is not None and f2.exists() and f2.is_file():
                fpath = f2
            else:
                return self._send_text('Not found', 404)
        else:
            return self._send_text('Not found', 404)

    data = fpath.read_bytes()
    ctype = 'application/octet-stream'
    name = fpath.name.lower()
    if name.endswith('.json'):
        ctype = 'application/json'
    elif name.endswith('.csv'):
        ctype = 'text/csv'
    elif name.endswith('.txt'):
        ctype = 'text/plain'

    # Friendly filename for stickers.json
    download_name = fpath.name
    try:
        rel_norm = (rel or '').replace('\\', '/').lstrip('/').lower()
        if rel_norm == 'output/stickers.json':
            # Try to derive customer from the subjob's job.json if present
            job_json_path = base / 'input' / 'job.json'
            job_json = {}
            if job_json_path.exists():
                try:
                    job_json = json.loads(job_json_path.read_text(encoding='utf-8'))
                except Exception:
                    job_json = {}
            cust_name = _customer_name_from_job(job_json)
            safe_cust = _sanitize_filename(cust_name or 'Onbekend', 50)
            safe_sub = _sanitize_filename(subjob_id, 80)
            download_name = f"{safe_cust}__{safe_sub}__stickers.json"
    except Exception:
        download_name = fpath.name

    self.send_response(200)
    self.send_header('Content-Type', ctype)
    self.send_header('Cache-Control', 'no-store')
    self.send_header('Content-Disposition', f'attachment; filename="{download_name}"')
    self.send_header('Content-Length', str(len(data)))
    self.end_headers()
    self.wfile.write(data)

def _fmt_bytes(n: int) -> str:
    try:
        n = int(n)
    except Exception:
        return "0 B"
    units = ["B","KB","MB","GB","TB"]
    i = 0
    f = float(n)
    while f >= 1024 and i < len(units)-1:
        f /= 1024.0
        i += 1
    if i == 0:
        return f"{int(f)} {units[i]}"
    return f"{f:.1f} {units[i]}"

def _dir_size_bytes(p: Path) -> int:
    total = 0
    try:
        for f in p.rglob('*'):
            try:
                if f.is_file():
                    total += f.stat().st_size
            except Exception:
                pass
    except Exception:
        pass
    return total

def api_admin_control_center(self):
    """Read-only info for the Admin Control Center (Phase 1)."""
    # Active versions (Phase 1 = simple file timestamps; no editing here)
    def _file_ver(path: Path) -> dict:
        if not path.exists():
            return {"exists": False}
        st = path.stat()
        return {
            "exists": True,
            "file": path.name,
            "modified": time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(st.st_mtime)),
            "bytes": int(st.st_size),
        }

    pricing = _file_ver(PRICING_ACTIVE)
    materials = _file_ver(ROOT / 'material_library.json')
    dxf_library = _file_ver(ROOT / 'embedded_dxfs_manifest.json')
    optimizer = {"active": OPTIMIZER_TOOL_B}

    # Storage
    jobs_count = 0
    largest = {"jobId": None, "bytes": 0}
    try:
        for p in JOBS.glob('*'):
            if not p.is_dir(): 
                continue
            jobs_count += 1
            sz = _dir_size_bytes(p)
            if sz > largest["bytes"]:
                largest = {"jobId": p.name, "bytes": sz}
    except Exception:
        pass

    # Recent failures (best-effort): jobs with non-empty toolb_stderr.txt
    failures = []
    try:
        job_dirs = [p for p in JOBS.glob('*') if p.is_dir()]
        job_dirs.sort(key=lambda p: p.stat().st_mtime, reverse=True)
        for p in job_dirs[:200]:
            err = p / 'output' / 'toolb_stderr.txt'
            if err.exists():
                try:
                    txt = err.read_text(encoding='utf-8', errors='ignore').strip()
                except Exception:
                    txt = ''
                if txt:
                    # short excerpt
                    excerpt = '\n'.join(txt.splitlines()[:5]).strip()
                    failures.append({
                        "jobId": p.name,
                        "modified": time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(p.stat().st_mtime)),
                        "excerpt": excerpt[:600],
                    })
            if len(failures) >= 5:
                break
    except Exception:
        pass

    # Disk usage (jobs folder only)
    jobs_bytes = _dir_size_bytes(JOBS)

    payload = {
        "versions": {
            "pricing": pricing,
            "materials": materials,
            "dxfLibrary": dxf_library,
            "optimizer": optimizer,
        },
        "storage": {
            "jobsCount": jobs_count,
            "jobsBytes": jobs_bytes,
            "largestJob": largest,
        },
        "failures": failures,
    }
    body, code = _safe_json(payload, 200)
    self.send_response(code)
    self.send_header('Content-Type', 'application/json; charset=utf-8')
    self.send_header('Content-Length', str(len(body)))
    self.end_headers()
    self.wfile.write(body)


def api_download(self, job_id: str, fname: str, parsed=None):
    if not self._require_job_access(job_id, parsed=parsed):
        return
    job_root = JOBS / job_id
    fpath = _safe_job_file(job_root, 'output/sheets/' + str(fname))
    if fpath is None:
        return self._send_text('Not found', 404)
    if not fpath.exists():
        return self._send_text('Not found', 404)
    data = fpath.read_bytes()
    self.send_response(200)
    self.send_header('Content-Type', 'application/dxf')
    self.send_header('Content-Disposition', f'attachment; filename="{fname}"')
    self.send_header('Content-Length', str(len(data)))
    self.end_headers()
    self.wfile.write(data)



# --- Queue worker (Release 1 foundation) ---
def _acquire_worker_lock() -> bool:
    try:
        WORKER_LOCK.parent.mkdir(parents=True, exist_ok=True)
        # Create lock file if not exists
        if WORKER_LOCK.exists():
            return False
        WORKER_LOCK.write_text(str(os.getpid()), encoding="utf-8")
        return True
    except Exception:
        return False


def _release_worker_lock() -> None:
    try:
        if WORKER_LOCK.exists():
            WORKER_LOCK.unlink()
    except Exception:
        pass


def _create_job_from_payload(payload: dict, master_job_id: str | None = None, public_access_token: str = '') -> dict:
    """Internal helper used by both /api/jobs and the queue worker.

    NOTE: payload format is the same as /api/jobs expects today:
      {panelsCsv: str, dxfParts: dict, pricing?: dict, jobJson?: dict}
    """
    panels_csv = payload.get('panelsCsv', '')
    pricing = payload.get('pricing', None)
    dxf_parts = payload.get('dxfParts', {}) or {}
    job_json = payload.get('jobJson', {}) or {}

    if not panels_csv or not isinstance(dxf_parts, dict) or not dxf_parts:
        raise ValueError('Missing panelsCsv or dxfParts')

    # Always start from the live pricing config on disk so Admin changes apply immediately
    # to new jobs, even when Tool A still sends an older client-side pricing skeleton.
    cfg = _load_pricing_config()
    live_cfg = cfg if isinstance(cfg, dict) else {}
    live_pricing = live_cfg.get('pricing') if isinstance(live_cfg.get('pricing'), dict) else None
    if not isinstance(live_pricing, dict):
        live_pricing = json.loads((ROOT / 'pricing_v13mm.json').read_text(encoding='utf-8'))

    # Deep-copy the live pricing block and merge in only the client-side dynamic parts that
    # Tool A must provide (mainly the used materials list / edge codes for the current order).
    pricing_base = json.loads(json.dumps(live_pricing))
    if isinstance(pricing, dict):
        try:
            if isinstance(pricing.get('materials'), list):
                pricing_base['materials'] = pricing.get('materials')
        except Exception:
            pass
        try:
            if isinstance(pricing.get('edgeBanding'), dict):
                pricing_base['edgeBanding'] = pricing.get('edgeBanding')
        except Exception:
            pass
        try:
            if pricing.get('currency') is not None:
                pricing_base['currency'] = pricing.get('currency')
            if pricing.get('units') is not None:
                pricing_base['units'] = pricing.get('units')
            if pricing.get('pricingVersion') is not None:
                pricing_base['pricingVersion'] = pricing.get('pricingVersion')
        except Exception:
            pass
    pricing = _ensure_pricing_materials(pricing_base, panels_csv)

    # Keep production layout settings authoritative from the live pricing config so
    # Admin changes (plaatmarge / nesting gap / kerf) apply immediately to new jobs,
    # even when Tool A still sends older client-side defaults.
    try:
        live_defaults = pricing.get('defaults') if isinstance(pricing.get('defaults'), dict) else {}
        job_json = dict(job_json or {})
        if isinstance(live_defaults, dict):
            if live_defaults.get('sheetMarginMm') is not None:
                job_json['sheetMarginMm'] = float(live_defaults.get('sheetMarginMm'))
            if live_defaults.get('nestingGapMm') is not None:
                job_json['nestingGapMm'] = float(live_defaults.get('nestingGapMm'))
            if live_defaults.get('kerfMm') is not None:
                job_json['kerfMm'] = float(live_defaults.get('kerfMm'))
    except Exception:
        pass

    master_job_id = str(master_job_id or (time.strftime('%Y%m%d_%H%M%S_') + uuid.uuid4().hex[:6]))
    master_root = JOBS / master_job_id
    master_input = master_root / 'input'
    master_output = master_root / 'output'
    master_input.mkdir(parents=True, exist_ok=True)
    master_output.mkdir(parents=True, exist_ok=True)
    if public_access_token:
        try:
            _atomic_write_json(master_root / '.public_access.json', {
                'token': str(public_access_token),
                'jobId': str(master_job_id),
                'updatedAt': _utc_now_iso(),
            })
        except Exception:
            pass
    if master_job_id:
        try:
            with _job_lock:
                meta = _job_meta.get(master_job_id, {}) or {}
                meta.update({
                    'status': 'processing',
                    'createdAt': meta.get('createdAt') or _now_iso(),
                    'progressPct': max(int(meta.get('progressPct') or 0), 3),
                    'progressMessage': 'Voorbereiden van de job…',
                    'phase': 'prepare',
                })
                _job_meta[master_job_id] = meta
        except Exception:
            pass

    # Master input (record of the full order)
    _write_file(master_input / 'panels.csv', panels_csv)
    _write_file(master_input / 'pricing.json', json.dumps(pricing, indent=2))
    _write_file(master_input / 'job.json', json.dumps(job_json, indent=2))

    parts_dir = master_input / 'dxf_parts'
    parts_dir.mkdir(parents=True, exist_ok=True)
    for part_id, dxf_text in dxf_parts.items():
        name = str(part_id)
        if not name.lower().endswith('.dxf'):
            name = name + '.dxf'
        _write_file(parts_dir / name, str(dxf_text))

    # Split into subjobs per MaterialCode (deterministic)
    rows = _parse_panels_csv(panels_csv)
    material_codes: list[str] = []
    seen: set[str] = set()
    for r in rows:
        c = str(r.get('MaterialCode') or '').strip()
        if c and c not in seen:
            seen.add(c)
            material_codes.append(c)

    # Resolve human names from pricing material library
    mats = pricing.get('materials', []) if isinstance(pricing, dict) else []

    def mat_name_for(code: str) -> str:
        for m in mats:
            if str(m.get('materialCode') or '').strip() == str(code).strip():
                return str(m.get('decorName') or m.get('materialName') or m.get('materialCode') or code)
        return str(code)

    subjobs = []
    subjob_roots: list[Path] = []
    timing_profile: dict[str, Any] = {
        'version': 'FIX441',
        'startedAt': _utc_now_iso(),
        'masterJobId': master_job_id,
        'subjobs': [],
    }
    total_started_perf = time.perf_counter()

    # Guard against runaway disk growth before optimizer work starts
    _enforce_job_output_limit(master_root, subjob_roots)

    # Run optimizer per material code (deterministic ordering)
    total_subjobs = max(1, len(material_codes))
    for subjob_index, code in enumerate(material_codes, start=1):
        try:
            with _job_lock:
                meta = _job_meta.get(master_job_id, {}) or {}
                base_pct = 5 + int(round(((subjob_index - 1) / float(total_subjobs)) * 90.0))
                meta.update({
                    'status': 'processing',
                    'progressPct': max(int(meta.get('progressPct') or 0), base_pct),
                    'progressMessage': f'Materiaal {subjob_index}/{total_subjobs} voorbereiden…',
                    'phase': 'subjob_prepare',
                    'currentSubjobIndex': subjob_index,
                    'subjobsTotal': total_subjobs,
                })
                _job_meta[master_job_id] = meta
        except Exception:
            pass
        sub_id = f"{master_job_id}__mat_{_safe_id(code, 60)}"
        sub_root = JOBS / sub_id
        subjob_roots.append(sub_root)
        sub_inp = sub_root / 'input'
        sub_out = sub_root / 'output'
        if public_access_token:
            try:
                sub_root.mkdir(parents=True, exist_ok=True)
                _atomic_write_json(sub_root / '.public_access.json', {
                    'token': str(public_access_token),
                    'jobId': str(sub_id),
                    'updatedAt': _utc_now_iso(),
                })
            except Exception:
                pass
        # Filter panels.csv for this material (preserve header/order)
        sub_csv = _filter_panels_csv_by_material(panels_csv, code)
        _write_file(sub_inp / 'panels.csv', sub_csv)
        _write_file(sub_inp / 'pricing.json', json.dumps(pricing, indent=2))
        _write_file(sub_inp / 'job.json', json.dumps(job_json, indent=2))
        # copy dxf parts (small enough; deterministic)
        (sub_inp / 'dxf_parts').mkdir(parents=True, exist_ok=True)
        for part_id, dxf_text in dxf_parts.items():
            name = str(part_id)
            if not name.lower().endswith('.dxf'):
                name = name + '.dxf'
            _write_file(sub_inp / 'dxf_parts' / name, str(dxf_text))

        # Guard after writing subjob inputs, before expensive optimizer work
        _enforce_job_output_limit(master_root, subjob_roots)

        # Run optimizer script
        cmd = _get_python_base_cmd() + ["-u", str(ROOT / OPTIMIZER_TOOL_B), '--input', str(sub_inp), '--output', str(sub_out)]
        try:
            _write_file(sub_out / 'toolb_cmd.txt', ' '.join(cmd))
        except Exception:
            pass
        # Capture logs
        sub_out.mkdir(parents=True, exist_ok=True)
        stdout_path = sub_out / 'toolb_stdout.txt'
        stderr_path = sub_out / 'toolb_stderr.txt'
        progress_path = sub_out / 'progress.json'

        def _read_subjob_progress_snapshot() -> tuple[int|None, str]:
            try:
                if not progress_path.exists():
                    return (None, '')
                pdata = json.loads(progress_path.read_text(encoding='utf-8') or '{}')
                pct_raw = pdata.get('percent')
                if pct_raw is None:
                    return (None, '')
                pct_val = max(0, min(100, int(round(float(pct_raw)))))
                msg_val = str(pdata.get('message') or pdata.get('phase') or '').strip()
                return (pct_val, msg_val)
            except Exception:
                return (None, '')

        def _publish_master_progress_from_subjob() -> None:
            if not master_job_id:
                return
            pct_val, msg_val = _read_subjob_progress_snapshot()
            if pct_val is None:
                return
            try:
                base_pct = 5 + int(round(((subjob_index - 1) / float(total_subjobs)) * 93.0))
                done_pct = 5 + int(round((subjob_index / float(total_subjobs)) * 93.0))
                mapped_pct = base_pct + int(round((max(0, min(99, pct_val)) / 100.0) * max(0, done_pct - base_pct - 1)))
                mapped_pct = max(base_pct, min(done_pct - 1, mapped_pct))
                if pct_val >= 100:
                    mapped_pct = min(done_pct - 1, max(mapped_pct, done_pct - 1))
                with _job_lock:
                    meta = _job_meta.get(master_job_id, {}) or {}
                    current_pct = int(meta.get('progressPct') or 0)
                    if mapped_pct > current_pct:
                        meta.update({
                            'status': 'processing',
                            'progressPct': mapped_pct,
                            'progressMessage': msg_val or f'Materiaal {subjob_index}/{total_subjobs} optimaliseren…',
                            'phase': 'subjob_progress',
                            'currentSubjobIndex': subjob_index,
                            'subjobsTotal': total_subjobs,
                            'updatedAt': _utc_now_iso(),
                        })
                        _job_meta[master_job_id] = meta
            except Exception:
                pass

        subjob_started_perf = time.perf_counter()
        with open(stdout_path, 'w', encoding='utf-8') as f_out, open(stderr_path, 'w', encoding='utf-8') as f_err:
            p = subprocess.Popen(cmd, cwd=str(ROOT), stdout=f_out, stderr=f_err)
            deadline = time.time() + float(_env_int('OPTIMIZER_TIMEOUT_SECONDS', 300))
            timed_out = False
            while True:
                rc = p.poll()
                _publish_master_progress_from_subjob()
                if rc is not None:
                    break
                if time.time() > deadline:
                    timed_out = True
                    try:
                        p.terminate()
                        p.wait(timeout=5)
                    except Exception:
                        try:
                            p.kill()
                        except Exception:
                            pass
                    rc = -9
                    break
                time.sleep(0.25)
            _publish_master_progress_from_subjob()
            if timed_out:
                raise RuntimeError(f"Optimizer timeout for {sub_id}")
        optimizer_done_perf = time.perf_counter()

        if rc != 0:
            raise RuntimeError(f"Optimizer failed for {sub_id} (rc={rc}). See {stderr_path.name}")

        # Guard again after optimizer output landed on disk
        _enforce_job_output_limit(master_root, subjob_roots)
        try:
            with _job_lock:
                meta = _job_meta.get(master_job_id, {}) or {}
                summary_pct = 94 + int(round((((subjob_index - 1) + 0.25) / float(total_subjobs)) * 2.0))
                meta.update({
                    'status': 'processing',
                    'progressPct': max(int(meta.get('progressPct') or 0), summary_pct),
                    'progressMessage': f'Materiaal {subjob_index}/{total_subjobs} berekening opbouwen…',
                    'phase': 'subjob_summary',
                })
                _job_meta[master_job_id] = meta
        except Exception:
            pass

        summary_started_perf = time.perf_counter()
        try:
            _write_human_calculation_summary(sub_root)
        except Exception:
            pass
        summary_done_perf = time.perf_counter()
        try:
            _atomic_write_json(sub_out / 'timing_profile_server.json', {
                'version': 'FIX441',
                'jobId': sub_id,
                'startedAt': _utc_now_iso(),
                'optimizerSeconds': round(max(0.0, optimizer_done_perf - subjob_started_perf), 3),
                'summarySeconds': round(max(0.0, summary_done_perf - summary_started_perf), 3),
                'totalSeconds': round(max(0.0, summary_done_perf - subjob_started_perf), 3),
                'updatedAt': _utc_now_iso(),
            })
        except Exception:
            pass
        timing_profile['subjobs'].append({
            'subjobId': sub_id,
            'optimizerSeconds': round(max(0.0, optimizer_done_perf - subjob_started_perf), 3),
            'summarySeconds': round(max(0.0, summary_done_perf - summary_started_perf), 3),
            'totalSeconds': round(max(0.0, summary_done_perf - subjob_started_perf), 3),
        })

        try:
            with _job_lock:
                meta = _job_meta.get(master_job_id, {}) or {}
                done_pct = 97 + int(round((subjob_index / float(total_subjobs)) * 1.0))
                meta.update({
                    'status': 'processing',
                    'progressPct': max(int(meta.get('progressPct') or 0), done_pct),
                    'progressMessage': f'Materiaal {subjob_index}/{total_subjobs} afgerond',
                    'phase': 'subjob_done',
                })
                _job_meta[master_job_id] = meta
        except Exception:
            pass

        subjobs.append({
            "subjobId": sub_id,
            "materialCode": code,
            "materialDisplayName": mat_name_for(code),
            "status": "DONE",
            "outputsReady": True,
        })

    # Final guard on the full job family before reporting success
    _enforce_job_output_limit(master_root, subjob_roots)
    if master_job_id:
        try:
            with _job_lock:
                meta = _job_meta.get(master_job_id, {}) or {}
                meta.update({
                    'status': 'processing',
                    'progressPct': max(int(meta.get('progressPct') or 0), 95),
                    'progressMessage': 'Subjobs samenvoegen…',
                    'phase': 'finalize_merge',
                })
                _job_meta[master_job_id] = meta
        except Exception:
            pass
    master_summary_started_perf = time.perf_counter()
    try:
        _write_human_calculation_summary(master_root)
    except Exception:
        pass
    master_summary_done_perf = time.perf_counter()
    if master_job_id:
        try:
            with _job_lock:
                meta = _job_meta.get(master_job_id, {}) or {}
                meta.update({
                    'status': 'processing',
                    'progressPct': max(int(meta.get('progressPct') or 0), 97),
                    'progressMessage': 'Resultaten verwerken…',
                    'phase': 'finalize',
                })
                _job_meta[master_job_id] = meta
        except Exception:
            pass
        try:
            with _job_lock:
                meta = _job_meta.get(master_job_id, {}) or {}
                meta.update({
                    'status': 'processing',
                    'progressPct': max(int(meta.get('progressPct') or 0), 99),
                    'progressMessage': 'Afronden…',
                    'phase': 'finalize_done',
                })
                _job_meta[master_job_id] = meta
        except Exception:
            pass
    try:
        timing_profile['masterSummarySeconds'] = round(max(0.0, master_summary_done_perf - master_summary_started_perf), 3)
        timing_profile['totalSeconds'] = round(max(0.0, time.perf_counter() - total_started_perf), 3)
        timing_profile['finishedAt'] = _utc_now_iso()
        _atomic_write_json(master_root / 'output' / 'timing_profile.json', timing_profile)
    except Exception:
        pass

    return {
        "jobId": master_job_id,
        "parentJobId": master_job_id,
        "subjobs": subjobs,
    }


def process_one_queue_item() -> bool:
    """Process one pending queue item. Returns True if something was processed."""
    _ensure_request_dirs()
    items = sorted(QUEUE_PENDING.glob("*.json"))
    if not items:
        return False

    item_path = items[0]
    try:
        q_item = json.loads(item_path.read_text(encoding="utf-8"))
    except Exception as e:
        _append_system_event(level="error", component="jobs", message_user="Een queue-item kon niet worden gelezen", message_tech=str(e), job_id=_safe_text(item_path.stem, 120), status="open")
        # bad queue item -> move to failed
        try:
            os.replace(str(item_path), str(QUEUE_FAILED / item_path.name))
        except Exception:
            pass
        return True

    request_id = _safe_id(q_item.get("requestId") or "", 120)
    if not request_id:
        _append_system_event(level="error", component="jobs", message_user="Een queue-item mist requestId", message_tech=f"Queue item {item_path.name} has no requestId", status="open")
        try:
            os.replace(str(item_path), str(QUEUE_FAILED / item_path.name))
        except Exception:
            pass
        return True

    # Move to processing (atomic)
    processing_path = QUEUE_PROCESSING / item_path.name
    try:
        os.replace(str(item_path), str(processing_path))
    except Exception:
        return True

    status = _load_status(request_id) or {}
    # If cancelled, skip
    if status.get("publicStatus") == "CANCELLED" or status.get("internalStatus") == "CANCELLED":
        status["internalStatus"] = "CANCELLED"
        status["internalStatusLabel"] = "Geannuleerd"
        _save_status(request_id, status)
        try:
            os.replace(str(processing_path), str(QUEUE_DONE / processing_path.name))
        except Exception:
            pass
        return True

    # Update status: processing
    status["internalStatus"] = "PROCESSING"
    status["internalStatusLabel"] = "Bezig"
    _save_status(request_id, status)
    _sse_broadcast("request_processing", {"requestId": request_id})

    try:
        payload_path = REQUESTS / request_id / "input" / "submit_payload.json"
        payload = json.loads(payload_path.read_text(encoding="utf-8"))
        res = _create_job_from_payload(payload)
        status["internalStatus"] = "DONE"
        status["internalStatusLabel"] = "Klaar"
        status["job"] = {
            "parentJobId": res.get("parentJobId"),
            "subjobs": res.get("subjobs") or [],
        }
        status["error"] = None
        _save_status(request_id, status)
        _sse_broadcast("request_done", {"requestId": request_id})
        os.replace(str(processing_path), str(QUEUE_DONE / processing_path.name))
    except Exception as e:
        # Mark failed
        status["internalStatus"] = "FAILED"
        status["internalStatusLabel"] = "Fout"
        status["error"] = {
            "code": "WORKER_FAILED",
            "message": str(e),
        }
        _save_status(request_id, status)
        _append_system_event(level="error", component="jobs", message_user="Een job is mislukt tijdens verwerken", message_tech=str(e), request_id=request_id, job_id=_safe_text((status.get('job') or {}).get('parentJobId'), 120), customer_name=_guess_customer_name(request_id=request_id, status=status), status="open")
        # Push notification (best-effort)
        try:
            _notify_failed(request_id, str(e))
        except Exception:
            pass
        _sse_broadcast("request_failed", {"requestId": request_id, "error": str(e)})
        try:
            os.replace(str(processing_path), str(QUEUE_FAILED / processing_path.name))
        except Exception:
            pass

    return True


def worker_loop(poll_seconds: float = 1.0) -> None:
    if not _acquire_worker_lock():
        print("Worker already running (lock exists).")
        return
    print("Worker started.")
    try:
        while True:
            did = False
            try:
                did = process_one_queue_item()
            except Exception as e:
                print("Worker error:", e)
            if not did:
                try:
                    run_retention_maintenance(force=False)
                except Exception:
                    pass
                try:
                    run_backup_maintenance(force=False)
                except Exception:
                    pass
                try:
                    run_queue_maintenance(force=False)
                except Exception:
                    pass
                time.sleep(poll_seconds)
    except KeyboardInterrupt:
        pass
    finally:
        _release_worker_lock()
        print("Worker stopped.")

def main():
    os.chdir(str(ROOT))
    _ensure_request_dirs()
    _ensure_archive_dirs()
    try:
        run_retention_maintenance(force=True)
    except Exception:
        pass
    try:
        run_backup_maintenance(force=False)
    except Exception:
        pass
    try:
        run_queue_maintenance(force=True)
    except Exception:
        pass
    # Align embedded DXFs with Tool A categories and rebuild manifest
    migrate_embedded_dxfs_to_categories()
    rebuild_embedded_dxfs_manifest()
    httpd = ThreadingHTTPServer((HOST, PORT), Handler)
    maintenance_thread = threading.Thread(target=_server_maintenance_loop, name='server-maintenance', daemon=True)
    maintenance_thread.start()
    print(f"Server listening on http://{HOST}:{PORT}")
    print(f"Admin: http://{HOST}:{PORT}/admin")
    creds_path = _get_admin_credentials_file_path()
    print(f"Admin credentials source: {creds_path}")
    if _is_production_hardening_enabled():
        required_public_origins = _split_env_origins('ALLOWED_ORIGINS')
        required_admin_origins = _split_env_origins('ALLOWED_ADMIN_ORIGINS')
        if creds_path == (ROOT / 'config' / 'admin_credentials.json'):
            print('[SECURITY ERROR] Production hardening requires external hash-only admin credentials.')
            print('[SECURITY ERROR] Set ADMIN_CREDENTIALS_FILE to a path outside the app map before going live.')
            raise SystemExit(2)
        if not required_public_origins:
            print('[SECURITY ERROR] Production hardening requires ALLOWED_ORIGINS to be set.')
            raise SystemExit(2)
        if not required_admin_origins:
            print('[SECURITY ERROR] Production hardening requires ALLOWED_ADMIN_ORIGINS to be set.')
            raise SystemExit(2)
        if _admin_password_reset_activation_is_enabled():
            print('[SECURITY ERROR] Admin password reset activation is currently enabled.')
            print('[SECURITY ERROR] Disable or remove the activation file before live use unless you are intentionally rotating the admin password right now.')
            raise SystemExit(2)
    httpd.serve_forever()





if __name__ == '__main__':
    # Mode switch:
    #   python server_py.py          -> run server
    #   python server_py.py --worker -> run queue worker
    if '--worker' in sys.argv:
        os.chdir(str(ROOT))
        _ensure_request_dirs()
        _ensure_archive_dirs()
        try:
            run_retention_maintenance(force=True)
        except Exception:
            pass
        try:
            run_backup_maintenance(force=False)
        except Exception:
            pass
        try:
            run_queue_maintenance(force=True)
        except Exception:
            pass
        worker_loop()
    else:
        # One-time DXF migration (root -> categories)
        migrate_embedded_dxfs_on_startup()
        main()
