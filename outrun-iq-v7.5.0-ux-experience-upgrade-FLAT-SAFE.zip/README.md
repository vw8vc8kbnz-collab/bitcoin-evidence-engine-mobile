# Outrun IQ v7.5.0 UX Experience Upgrade

Flat root ZIP. Gebouwd op v7.4.0/v7.3.11.

Belangrijkste punten:
- Ontdekpagina meer marketplace-first: zoeken, trending, live deals, trust lager.
- Product-detail overlay opgeschoond: geen dubbele content/overflow, stabiel fullscreen sheet.
- Partner portal vriendelijker/professioneler: inventory/order/money cards en betere alignment.
- Service worker cache v7.5.0.
