# v7.5.0 — UX Experience Upgrade

- Ontdekpagina minder informatiepagina, meer deal discovery.
- Compactere hero en betere marketplace hiërarchie.
- Fullscreen listing sheet: dubbele title/overflow gefixt.
- Partner voorraad/orders/geld: professionelere kaarten en tekstuitlijning.
- Versie naar 7.5.0.
