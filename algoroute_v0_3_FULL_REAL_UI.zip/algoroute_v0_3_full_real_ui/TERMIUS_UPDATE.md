# AlgoRoute v0.3 FULL REAL UI - Termius update

Upload `algoroute_v0_3_FULL_REAL_UI.zip` naar GitHub en gebruik daarna:

```bash
cd /home/ubuntu
rm -rf algoroute_latest
rm -f algoroute_v0_3_FULL_REAL_UI.zip

wget -O /home/ubuntu/algoroute_v0_3_FULL_REAL_UI.zip \
"https://raw.githubusercontent.com/vw8vc8kbnz-collab/bitcoin-evidence-engine-mobile/main/algoroute_v0_3_FULL_REAL_UI.zip"

mkdir -p /home/ubuntu/algoroute_latest
unzip -o /home/ubuntu/algoroute_v0_3_FULL_REAL_UI.zip -d /home/ubuntu/algoroute_latest

cd /home/ubuntu/algoroute_latest/algoroute_v0_3_full_real_ui
chmod +x scripts/install.sh
sudo ./scripts/install.sh
sudo ufw allow 8787/tcp || true
docker compose up -d --build
docker compose ps
curl http://localhost:8787/api/health
```

Open:
`http://51.195.102.180:8787`
