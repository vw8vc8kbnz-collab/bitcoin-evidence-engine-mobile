# AlgoRoute v0.3 Full Real UI

Echte softwarebuild, geen mockup-image als UI.

## Inhoud
- FastAPI backend
- Echte HTML/CSS/JS dashboard cockpit
- SVG logo componenten
- Live map visual component met animated bus
- Planning, Import Studio, Wagenpark, Live Tracking, Klanttracking secties
- Docker Compose
- VPS/Termius update flow

## Start lokaal/VPS
```bash
chmod +x scripts/install.sh
sudo ./scripts/install.sh
docker compose up -d --build
```

Open: `http://<VPS-IP>:8787`
