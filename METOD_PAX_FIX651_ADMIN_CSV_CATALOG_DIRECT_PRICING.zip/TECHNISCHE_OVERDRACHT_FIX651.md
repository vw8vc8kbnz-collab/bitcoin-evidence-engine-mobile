# METOD/PAX Tool A — technische overdracht FIX651

## Release-identiteit

- Release: **FIX651 — Admin CSV Catalog + Direct Pricing + Public Article Privacy**
- Basis: FIX650.
- Kernmarker backend: `FIX651_CSV_CATALOG_DIRECT_PRICING`.
- FIX650/FIX649/FIX648/FIX645/FIX644 mobiele UX blijft intact.
- De aangeleverde website-CSV is **geen releasebestand en geen default catalogus**.

## Functionele bedoeling

FIX651 verandert de Decor Library van hoofdzakelijk handmatig beheer naar een gecontroleerde catalogus-importworkflow. Admin blijft de publicatie- en correctielaag. Een CSV-upload verandert de live catalogus nooit meteen: eerst wordt geparsed, genormaliseerd, gevalideerd en gediffed; pas een aparte Publish-call schrijft de live library.

Tegelijk vervalt de algemene materiaal-/plaatfactor uit het actieve prijsmodel. Een materiaalrecord bezit voortaan een directe verkoopprijs per plaat. Voor CSV-records komt `sellPriceInclVatPerSheet` rechtstreeks uit `Prijs per plaat inclusief BTW`. De backend rekent voor de bestaande netto kostenopbouw een `sellPriceExVatPerSheet` uit door door 1,21 te delen. De bestaande overige Admin-kosten worden daarna toegevoegd en de eindberekening past 21% BTW toe.

## Bestanden

### Nieuw

`app/catalog_importer.py`

Verantwoordelijk voor:
- beide CSV-vormen herkennen (normale CSV en outer-quoted/één-kolom export);
- exact headerschema valideren;
- numerieke normalisatie;
- dikte-whitelist;
- image-URL parsing;
- plaatmaatfallback;
- warnings/errors/excluded records;
- catalogusdiff;
- remote-image URL-beveiliging en metadata-strippende cachehelpers.

### Gewijzigd

`app/server_py.py`

Belangrijkste wijzigingen:
- FIX651 buildmarker;
- Admin catalog preview/publish/status/retry endpoints;
- Admin CSV-importkaart;
- direct per-material sell price in materiaalbeheer;
- material-factor verwijderd uit pricing UI/config/actieve berekening;
- idempotente legacy prijs-migratie bij serverstart;
- nieuwe jobs bouwen hun materiaalprijzen uit de live Material Library;
- publieke material library is expliciete allowlist-projectie;
- publieke job/status/error output wordt op interne materiaalcodes gesanitized;
- catalogMissing/catalogExcluded lifecycle;
- veilige lokale catalogus-imagecache.

`app/config/pricing_active.json`

Fresh-install default gebruikt `pricingModel: catalog_sell_price_v1` en heeft alleen de bestaande overige sell-costs. Op een bestaande VPS wordt het live bestand door de installer bewaard; bij serverstart migreert de backend het schema en haalt `sheetPriceFactor` weg.

## CSV-contract

Exact zeven velden:

1. `Product Reference Code` — intern artikelnummer/SKU.
2. `Product Image Urls` — één of meerdere afbeelding-URL's.
3. `Product Name` — bron/product/decornaam.
4. `Feature Max. dikte (mm)` — autoritatieve dikte.
5. `Feature Max. lengte (mm)` — autoritatieve lengte indien ingevuld.
6. `Feature Max. breedte (mm)` — autoritatieve breedte indien ingevuld.
7. `Prijs per plaat inclusief BTW` — autoritatieve directe verkoopprijs per plaat incl. 21% BTW.

Headerwijzigingen zijn bewust blocking. Daarmee kan een upstream export niet stilletjes verkeerd worden geïnterpreteerd.

## Diktebeleid

`ALLOWED_THICKNESSES_MM = (18.0, 19.0, 20.0)`.

De CSV-dikte is autoritatief. Niet-toegestane diktes komen in `excluded`, niet in `records`. Public API voert daarnaast opnieuw een 18/19/20-whitelist uit als defense in depth.

Cruciale update-case: als een artikel dat eerder 18 mm was in een nieuwe CSV 10 mm wordt, is alleen het weglaten uit staged records onvoldoende. `_merge_catalog_stage()` vergelijkt daarom ook `stage.excluded`. Een bestaand source-owned record krijgt dan:

- `catalogExcluded = true`
- `catalogExcludedThicknessMm = <nieuwe uitgesloten dikte>`
- `catalogExcludedReason`
- `catalogMissing = false`

Het record blijft intern bestaan voor historie, maar `_api_public_materials_library()` sluit `catalogExcluded` expliciet uit. Wordt dezelfde SKU later weer geldig, dan wist de eligible merge de exclusionvelden en behoudt de bestaande opaque public ID.

`MANUAL` records worden nooit door deze CSV-exclusionlogica gemuteerd.

## Plaatmaatfallback

Volgorde:

1. geldige lengte/breedte uit CSV;
2. ontbrekende component(en) aanvullen uit de eerste bruikbare image URL;
3. URL-dikte alleen vergelijken met CSV-dikte; mismatch = warning, CSV wint;
4. alleen voor DecoLegno + CSV-dikte 18 mm + nog steeds ontbrekende maat: 2800 × 2070 fallback + warning;
5. anders blocking `DIMENSIONS_MISSING`.

De URL-parser ondersteunt gangbare varianten rond `2800-2070-18`, `2800x2070x18mm`, `2800-x-2070-x-18mm`, `3050-1300-19`, enz.

## Catalogus lifecycle

### Preview

`POST /api/admin/materials/catalog_preview`

Admin-auth vereist. Body bevat `csvText`. Max standaard 4 MiB. Server schrijft een stagebestand onder `app/system/catalog_imports/` met random `cat_<24 hex>` ID. Preview bevat summary, warnings, errors, exclusions, eerste records en diff. Stage is geen live catalogus.

### Publish

`POST /api/admin/materials/catalog_publish`

Admin-auth vereist. Accepteert alleen geldige, ongepubliceerde stage jonger dan 24 uur zonder blocking errors en met minstens één eligible record. Voor merge wordt een snapshot gemaakt in `system/catalog_imports/history/` van library en pricing-config.

### Match / public ID

Interne match-key = artikelnummer. `publicMaterialId` is random `decor_<20 hex>` en blijft bij bestaande SKU stabiel. Nieuw artikel krijgt nieuw random public ID. Public ID is nooit afgeleid van artikelnummer.

### Source ownership

- `CATALOG_IMPORT`: eigendom catalogusimport; wordt bijgewerkt door CSV.
- `LEGACY_LIBRARY`: eerste import mag bestaande SKU matchen/upgraden; ontbrekende legacy SKU wordt alleen `catalogMissing`, niet verwijderd.
- `MANUAL`: Admin-owned; CSV mag deze niet stil overschrijven/verwijderen/missing-markeren wanneer niet gematcht.

Een matched existing record wordt `CATALOG_IMPORT`, behalve de expliciete Admin-curationwaarden (publicName wanneer gecureerd, brand/type/color/grain/popular/new en active/published/archive) die waar mogelijk behouden blijven.

## Missing-from-source

Source-owned `CATALOG_IMPORT` en `LEGACY_LIBRARY` records die niet in staged eligible **en niet in staged excluded** voorkomen krijgen `catalogMissing=true`. Ze worden niet automatisch verwijderd of gedeactiveerd. Dit is bewust zodat verdwijnen uit een website-export niet meteen historische/live data vernietigt. Admin kan later archiveren.

Een expliciet wegens dikte uitgesloten artikel is geen `missing`; het is `catalogExcluded`.

## Afbeeldingsarchitectuur

Bron-URL's worden alleen intern opgeslagen. Public Tool A krijgt uitsluitend lokale URLs op basis van `publicMaterialId`.

Beveiliging:
- alleen `https`;
- default allow-hosts: `adzaagt.nl,www.adzaagt.nl`;
- geen URL credentials;
- alleen poort 443;
- hostname/DNS-resultaten mogen niet naar loopback/private/link-local/reserved/multicast/unspecified IP wijzen;
- redirects begrensd en iedere destination opnieuw gevalideerd;
- connect/read timeout;
- max 12 MiB;
- signaturevalidatie JPG/PNG/WebP;
- JPEG APP1..APP15/COM, PNG tekst/EXIF/time en WebP EXIF/XMP metadata worden gestript.

Catalog images worden asynchroon na publish opgehaald. Een downloadfout maakt de catalogus niet transactioneel half-af: catalogusdata is al atomair gepubliceerd, image status wordt apart bijgehouden en kan via Admin retry worden gedaan.

## Pricingmodel

### Autoritatieve bron

Nieuwe catalogusrecords:

- `sellPriceInclVatPerSheet` = CSV exact afgerond op centen;
- `sellPriceExVatPerSheet` = incl / 1.21;
- `priceSource = CSV_SALE_PRICE_INCL_VAT`.

### Geen factor

`sheetPriceFactor` wordt door `_normalize_pricing_config_schema()` verwijderd en is geen invoer van `_apply_sell_pricing_to_quote()`.

### Compatibiliteit Tool B

Tool B verwacht historisch een veld `purchasePricePerSheet`. Om Tool B niet risicovol te herschrijven, bouwt `_ensure_pricing_materials()` per gebruikte SKU een verse compatibiliteitsrecord. In FIX651 betekent dat veld semantisch **directe verkoopprijs excl. BTW**, niet aankoopprijs. Daarnaast worden expliciet `sellPriceExVatPerSheet` en `sellPriceInclVatPerSheet` gezet.

De bron is altijd de live `material_library.json`; client/browser pricing is niet autoritatief. Een ontbrekende SKU, onbeschikbaar/excluded materiaal, verkeerde dikte, ongeldige plaatmaat of ontbrekende directe verkoopprijs is een blocking jobfout. Er is geen factor- of stale-clientfallback.

### Overige kosten

Ongewijzigd Admin-instelbaar:

- `edgeBandPricePerM`
- `cncCostPerSheet`
- `drawingCostFixed`
- `transportCostFixed`

Daarnaast blijven technische pricing defaults zoals sheet margin, nesting gap, kerf en rounding bestaan.

Netto kostenopbouw:

`materialen + kantenband + CNC + tekenwerk + transport`

Daarna 21% BTW voor `totalInclVat` in de bestaande berekeningsoverzichten.

### Migratie bestaande live installatie

`_migrate_legacy_materials_to_direct_sell_prices()` draait bij server/worker start en is idempotent op reeds gemigreerde records. Doel: vóór de eerste echte CSV-publicatie geen prijsschok veroorzaken.

Prioriteit bij legacy record zonder direct sell price:

1. `retailPriceWithoutTax` vastzetten als directe sell ex BTW;
2. anders historische purchase field × de oude factor éénmalig bevriezen;
3. directe incl/excl waarden opslaan op materiaalrecord;
4. pricing config normaliseren en factor verwijderen.

Deze factor is dus alleen migratie-informatie; hij bestaat niet meer in het actieve rekenpad.

## Publieke privacycontract

`GET /api/materials/library` projecteert via een expliciete allowlist. Publiek toegestaan:

- publicMaterialId
- publicName
- brand
- decorType
- colorGroup
- thicknessMm
- sheetSizeMm
- hasGrain / grainDefaultOn
- active/published
- isPopular/isNew
- lokale image availability/URLs

Niet publiek:

- articleNo / articleNumber / materialCode / SKU
- purchase/inkoopvelden
- supplier/leverancier
- imageSourceUrl(s)
- catalogusbron/auditmetadata
- CSV prijsvelden

Tool A gebruikt `publicMaterialId`; server vertaalt dit pas na ontvangst naar intern artikelnummer voor productie/optimizer. Publieke quote/status/error responses lopen door materiaal-sanitization. Raw internal JSON/config/staging is niet statisch serveerbaar.

## Admin UI

Decor Library heeft bovenaan **Websitecatalogus importeren**:

- file input `.csv`;
- `CSV controleren`;
- `Publiceren` disabled tot geldige preview;
- summary cards: gelezen, eligible, excluded, new, changed, unchanged, missing, warnings;
- detailsecties voor blocking errors/warnings/exclusions;
- image-sync status/retry.

Legacy volledige JSON upload staat onder `Geavanceerd · oude JSON-import` en is niet de primaire workflow.

Handmatig materiaalbeheer heeft een directe `Verkoopprijs per plaat incl. BTW (€)`; publicatie van een handmatig record met andere dikte dan 18/19/20 wordt geweigerd.

Pricing UI heeft geen plaatfactor meer en toont de vier bestaande commerciële kostenposten plus de technische defaults.

## Deployment

Termius installer moet runtime/live data bewaren:

- app/jobs/
- app/requests/
- app/queue/
- app/archive/
- app/backups/
- app/drafts/
- app/system/ (inclusief catalog import history/stages)
- app/decor_media/
- app/material_library.json
- app/config/pricing_active.json
- app/config/pricing_versions/
- app/config/pricing_audit.jsonl
- app/embedded_dxfs/
- app/embedded_dxfs_manifest.json

De releasecode wordt eromheen ge-rsynct. Nieuwe `catalog_importer.py` en `server_py.py` worden dus geplaatst, maar live bedrijfsdata wordt niet vervangen door packaged defaults.

## Acceptatie na live deploy

1. Tool A opent nog steeds FIX650/FIX649 grain UX.
2. Admin > Decor Library toont CSV-importkaart.
3. Pricing Admin heeft geen materiaal/plaatfactor.
4. Bestaande overige kosten staan nog op hun live waarden.
5. Upload de CSV, klik alleen **CSV controleren** en controleer aantallen/waarschuwingen.
6. Bevestig vóór publish dat 18/19/20-filter en plaatmaatfallbacks logisch zijn.
7. Publiceer.
8. Laat image sync afronden of gebruik Retry bij fouten.
9. Open Tool A in nieuwe/private browser en controleer decorcards/images.
10. Network-inspectie `/api/materials/library`: geen intern artikelnummer/prijs/source URL.
11. Maak een kleine testorder en controleer berekening: website verkoopprijs per gebruikte plaat + overige Admin-kosten, zonder factor.

## Bewuste niet-wijzigingen / vervolg

- Productie-hardening/TLS staat nog los van deze functionele release volgens eerdere afspraak.
- CSV wordt niet automatisch periodiek vanaf een URL opgehaald; Admin-upload + expliciet Publish is nu de veilige waarheid.
- Ontbrekende source-records worden niet automatisch gearchiveerd.
- Afbeelding-download is bewust asynchroon zodat externe websiteproblemen de cataloguspublicatie niet corrupt maken.
