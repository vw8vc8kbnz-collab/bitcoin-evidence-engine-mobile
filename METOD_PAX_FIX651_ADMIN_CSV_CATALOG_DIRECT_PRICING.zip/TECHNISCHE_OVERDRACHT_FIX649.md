# METOD/PAX Tool A — Technische overdracht FIX649

## Basis
FIX649 bouwt rechtstreeks voort op FIX648. De verticale mobiele Doorlopende-nerf-flow blijft behouden. Alleen de mobiele presentatie en bediening binnen Stap 3 zijn schaalbaarder gemaakt.

## Nieuwe geïsoleerde assets
- `app/toolA_grain_mobile_scale.css`
- `app/toolA_grain_mobile_scale.js`

Beide bestanden staan in de expliciete publieke static allowlist van `server_py.py`.

## Mobiele rendering
De bestaande functies `rebuildGrainEligible`, `rebuildGrainGroups` en `drawGrainPreview` worden alleen bij `max-width: 700px` door een presentatielaag omwikkeld. Desktop roept ongewijzigd de originele functies aan.

### Beschikbare panelen
- gegroepeerd per breedte;
- per breedte een accordion;
- bestaande `_groupGrainDisplayEntries()` blijft de bron voor het samenvoegen van identieke panelen;
- acties `+1`, `+5` en `Alles` voegen in één batch toe;
- de bestaande autoritatieve refs en `syncGroupOrders()` blijven gebruikt.

### Nerf-sets
- één geselecteerde groep tegelijk geopend;
- pijlen en verwijderen gebruiken de bestaande `moveInGroup()` en `removeFromGroup()`;
- bij meer dan 12 panelen blijft de groep compact totdat de gebruiker `Toon alle … panelen` kiest.

### Preview
- blijft gebaseerd op de bestaande `drawGrainPreview()`;
- gebruikt `state.grain.selectedGroupId`;
- mobiel handmatig in/uitklapbaar;
- desktop altijd zichtbaar zoals voorheen.

## Veiligheidsgrenzen
Niet aangepast: backendcontracten, artikelnummermapping, pricing, optimizer, jobs, requests, Admin en productie-export.

## Buildmarker
`window.__TOOLA_GRAIN_MOBILE_BUILD = 'FIX649_MOBILE_GRAIN_SCALE'`

## Praktische acceptatie
Test op iPhone:
1. switch overige panelen;
2. breedteaccordions;
3. +1, +5 en Alles;
4. meerdere nerf-sets;
5. set van meer dan 12 panelen uitklappen;
6. volgorde wijzigen;
7. actieve preview tonen;
8. Toepassen en doorgaan.
