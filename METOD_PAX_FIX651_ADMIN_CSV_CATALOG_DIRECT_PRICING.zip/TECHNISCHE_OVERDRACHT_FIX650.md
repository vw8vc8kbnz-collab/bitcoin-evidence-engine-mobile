# METOD/PAX Tool A — technische overdracht FIX650

## Doel
FIX650 corrigeert uitsluitend de mobiele knop **Toon preview** binnen Doorlopende nerf. In FIX649 kon de knopstatus veranderen zonder dat de preview op iPhone/Safari betrouwbaar zichtbaar of in beeld kwam.

## Implementatie
`toolA_grain_mobile_scale.js` bevat nu één autoritatieve `setPreviewOpen(open, options)`-functie. Deze functie:

- beheert de openklasse en `aria-expanded`;
- maakt `#grainPreview` expliciet zichtbaar;
- voert de bestaande `drawGrainPreview()` uit;
- herhaalt de draw na layout;
- scrollt de daadwerkelijke preview of lege status gecontroleerd in beeld;
- verwijdert inline overrides bij sluiten.

De bestaande preview-engine blijft autoritatief. Er is geen nieuwe nerf- of previewberekening gebouwd.

## Behouden
FIX645 keyboard/footer, FIX648 verticale nerfflow en FIX649 schaalbare mobiele lijsten blijven aanwezig. Desktop, pricing, optimizer, Admin en publieke decorbeveiliging zijn niet gewijzigd.
