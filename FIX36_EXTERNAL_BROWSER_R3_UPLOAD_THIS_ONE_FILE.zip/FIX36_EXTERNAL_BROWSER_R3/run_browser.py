#!/usr/bin/env python3
"""Run the FIX36 R3 18-fixture oracle on exact immutable candidate/golden ZIPs."""
import contextlib
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import traceback

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from common import CANDIDATE_SHA, CANDIDATE_MANIFEST_SHA, GOLDEN_SHA, REGISTRY_SHA, atomic_json, digest, verify_package
sys.path.insert(0, str(ROOT / 'support'))
from final_preflight import Preflight, validate_checksum_manifest
from verify_standalone_artifact import safe_extract, snapshot_and_verify_artifact
from r9n_external_evidence_gate import validate_browser_ledger
sys.path.insert(0, str(ROOT / 'oracle/tools'))
import r9a_browser_oracle as oracle


def verified_release(archive, expected, destination):
    destination.mkdir(mode=0o700)
    snapshot, _, _ = snapshot_and_verify_artifact(archive, destination / 'input.zip', expected_sha256=expected)
    release, _ = safe_extract(snapshot, destination / 'release')
    if not validate_checksum_manifest(Preflight(), release, verify=True):
        raise ValueError('Invalid release payload manifest')
    return release


def validate_current_pass(report, registry, candidate, golden, started, code):
    if code != 0 or report.get('status') != 'PASS' or report.get('schemaVersion') != 2:
        raise ValueError('Browser status/exit/schema mismatch')
    observed = datetime.fromisoformat(report['finishedAtUtc'].replace('Z', '+00:00'))
    began = datetime.fromisoformat(report['startedAtUtc'].replace('Z', '+00:00'))
    if began < started or observed < began or observed > datetime.now(timezone.utc):
        raise ValueError('Observation is not from this invocation')
    for label, release in [('candidate', candidate), ('golden', golden)]:
        if report[label + 'Release']['manifestSha256'] != digest(release / 'SHA256SUMS.txt'):
            raise ValueError('Browser release binding mismatch')
    if report.get('registry', {}).get('sha256') != REGISTRY_SHA:
        raise ValueError('Browser ran a different fixture registry')
    for label, relative in [('runner', 'tools/r9a_browser_oracle.py'), ('driver', 'tools/r9a_browser_driver.js')]:
        if report[label]['sha256'] != digest(ROOT / 'oracle' / relative):
            raise ValueError('Browser runner binding mismatch')
    if report.get('fixtureCount') != 18 or report.get('passedFixtureCount') != 18 or report.get('assertionsTotal') != 144:
        raise ValueError('Incomplete 18-fixture / 144-assertion run')
    if any(report.get(key) != 0 for key in ['failedFixtureCount', 'skippedFixtureCount', 'blockedFixtureCount']):
        raise ValueError('Unresolved browser outcomes')
    if sorted(report.get('enginesPassed', [])) != ['chromium', 'webkit']:
        raise ValueError('Missing engine evidence')
    validate_browser_ledger(report, registry)
    for relative in registry['oracleDependencies']:
        if report.get('bindings', {}).get('dependencySha256', {}).get(relative) != digest(ROOT / 'oracle' / relative):
            raise ValueError('Oracle dependency binding mismatch: ' + relative)
    for fixture in report['fixtures']:
        spec = next(item for item in registry['fixtures'] if item['id'] == fixture['id'])
        profiles = fixture['evidence'].get('profiles', {})
        if set(profiles) != set(spec['profiles']):
            raise ValueError('Raw browser profile set mismatch')
        for profile in profiles.values():
            sides = ['candidate'] if spec['requiredEvidenceClass'] == 'candidate-conformance' else ['golden', 'candidate']
            for side in sides:
                raw = profile.get(side, {})
                checks = raw.get('assertions', [])
                ids = [item.get('id') for item in checks]
                if not checks or len(ids) != len(set(ids)) or any(item.get('ok') is not True for item in checks):
                    raise ValueError('Raw profile contains a failed, missing or duplicate assertion')
                if raw.get('exception') is not None or raw.get('pageErrorCount') != 0 or raw.get('pageErrors') != []:
                    raise ValueError('Raw profile contains an unhandled browser error')
    probe = report.get('runtimeProbe', {})
    if probe.get('status') != 'PASS' or probe.get('playwrightPackageVersion') != '1.62.0' or not probe.get('nodeVersion', '').startswith('v24.'):
        raise ValueError('Unreviewed browser toolchain')
    for engine in ['chromium', 'webkit']:
        value = probe.get('engines', {}).get(engine, {})
        if value.get('launchable') is not True or not value.get('executableSha256'):
            raise ValueError('Real engine launch is not proven')


def main():
    os.umask(0o077)
    evidence = Path('/evidence')
    summary = {'schemaVersion': 1, 'reportType': 'fix36-r3-browser-oracle', 'status': 'FAIL',
               'subjectArtifactSha256': CANDIDATE_SHA, 'candidateManifestSha256': CANDIDATE_MANIFEST_SHA,
               'goldenArtifactSha256': GOLDEN_SHA, 'fixtureRegistrySha256': REGISTRY_SHA,
               'productionGo': False, 'releaseEligible': False,
               'aggregateCompatibility': 'Separate FIX36 R3 evidence; not a converted FIX33 15-fixture report'}
    native = evidence / 'BROWSER_ORACLE_NATIVE.json'
    code = 1
    try:
        verify_package(ROOT)
        if native.exists():
            raise ValueError('Evidence path already exists; rerun in a new directory')
        registry = json.loads((ROOT / 'oracle/contracts/R9A_BROWSER_FIXTURES.json').read_text())
        oracle.validate_registry(registry)
        toolchain = json.loads(subprocess.check_output([
            'node', '-e', "const p=require('/toolchain/node_modules/playwright'); console.log(JSON.stringify({node:process.version,version:require('/toolchain/node_modules/playwright/package.json').version,chromium:p.chromium.executablePath(),webkit:p.webkit.executablePath()}));"
        ], timeout=20))
        if not toolchain['node'].startswith('v24.') or toolchain['version'] != '1.62.0':
            raise ValueError('Node 24 and Playwright 1.62.0 are required')
        with tempfile.TemporaryDirectory(prefix='fix36-browser-inputs-') as temporary:
            work = Path(temporary)
            candidate = verified_release(ROOT / 'candidate.zip', CANDIDATE_SHA, work / 'candidate')
            golden = verified_release(Path('/inputs/golden.zip'), GOLDEN_SHA, work / 'golden')
            if digest(candidate / 'SHA256SUMS.txt') != CANDIDATE_MANIFEST_SHA:
                raise ValueError('Candidate manifest is not FIX36')
            started = datetime.now(timezone.utc)
            code = oracle.main([
                '--registry', str(ROOT / 'oracle/contracts/R9A_BROWSER_FIXTURES.json'),
                '--golden-release', str(golden), '--candidate', str(candidate),
                '--engines', 'webkit', 'chromium', '--no-partial-engine-evidence',
                '--playwright-module', '/toolchain/node_modules/playwright',
                '--chromium-executable', toolchain['chromium'], '--webkit-executable', toolchain['webkit'],
                '--json-output', str(native), '--suite-timeout', '600',
            ])
            report = json.loads(native.read_text())
            status = report.get('status')
            if status not in {'PASS', 'FAIL', 'NO_GO'} or code != {'PASS': 0, 'FAIL': 1, 'NO_GO': 3}[status]:
                raise ValueError('Invalid browser exit/status pair')
            if status == 'PASS':
                validate_current_pass(report, registry, candidate, golden, started, code)
            summary.update(status=status, fixtureCount=report.get('fixtureCount'),
                           passedFixtureCount=report.get('passedFixtureCount'), assertionsTotal=report.get('assertionsTotal'),
                           enginesPassed=report.get('enginesPassed'), observedAtUtc=report.get('finishedAtUtc'),
                           rawReportPath=native.name, rawReportSha256=digest(native))
        verify_package(ROOT)
    except Exception as exc:
        code = 1
        summary.update(status='FAIL', error=str(exc), observedAtUtc=datetime.now(timezone.utc).isoformat())
        traceback.print_exc()
    atomic_json(evidence / 'BROWSER_RESULT.json', summary)
    print('FIX36_BROWSER_RESULT=' + summary['status'], flush=True)
    return code


if __name__ == '__main__':
    raise SystemExit(main())
