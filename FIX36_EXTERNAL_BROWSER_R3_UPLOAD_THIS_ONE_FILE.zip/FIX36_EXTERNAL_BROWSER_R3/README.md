# FIX36 externe browsertest R3

Dit pakket test de complete, eerder geleverde FIX36-applicatie. `candidate.zip`
is byte voor byte dezelfde applicatie. De launcher installeert niets, herstart
geen service en heeft geen toegang tot de actieve applicatie of klantgegevens.

## Starten

Upload `FIX36_EXTERNAL_BROWSER_R3_UPLOAD_THIS_ONE_FILE.zip` naar de hoofdmap van
de bestaande GitHub-repository, op `main`. Gebruik daarna de afzonderlijk
geleverde `TERMIUS_FIX36_BROWSER_R3_START.txt`. De opdracht gebruikt de bewaarde
golden-ZIP uit de eerdere R2-run van 11 september en controleert opnieuw de SHA256.
De oude run en de eerder ontvangen FAIL blijven behouden.

De test loopt los van de SSH-sessie door. De startopdracht geeft daarom snel
weer een shellprompt. Gebruik `TERMIUS_FIX36_BROWSER_R3_STATUS.txt` voor de
actuele fase en de laatste logregels. Start niet tegelijkertijd een tweede run.

Na afloop staat de oorspronkelijke bewijs-ZIP in de runmap. De launcher maakt
ook een identieke kopie in `/home/ubuntu`, met naam
`FIX36_BROWSER_R3_EVIDENCE_<datum>_<run-id>.zip`. Ververs de SFTP-bestandenlijst,
download deze ZIP en stuur die terug. Het statusveld `evidenceDownloadCopy`
vermeldt de kopie; `evidenceZip` vermeldt altijd het oorspronkelijke bestand.
Een probleem met de kopie wordt apart vermeld en verwijdert het origineel niet.

## Wat R3 corrigeert

- De reset-test gebruikt dezelfde complete testcontext als alle andere checkout-aanroepen.
- Paneel-ID’s worden exact gekoppeld tussen interface, verzonden DXF-payload en export.
  Alleen die bewezen identiteiten worden onder vaste namen vergeleken. De ruwe
  bestandsnamen en ID’s blijven in het rapport staan. Er worden geen tijdstempels
  met een algemeen zoekpatroon weggefilterd.

De correcties uit R2 blijven behouden:

- Exacte FIX36-componentlabels voor panelen en nerf-preview, gecontroleerd tegen
  de vastgepinde applicatiebron.
- De ververs-test wacht tot alle manifesttemplates daadwerkelijk zijn geparseerd,
  en daarna tot de DXF-verzoeken zijn afgerond. Een rustige netwerkperiode alleen
  was onvoldoende bij de progressieve laadlus. Geannuleerde verzoeken en
  browserfouten blijven fouten; er wordt geen poging automatisch overgedaan.
- De volledige bestandsinventaris wordt per hoofdjob en materiaaljob bewaard.
  Alle gedeelde bestanden worden vergeleken op rol, pad en soort. Dubbele
  bestanden, ongeldige paden, lege bestanden of verkeerde jobkoppelingen falen.
- Alleen de twee concrete FIX36-toevoegingen `output/calculation_pricing.json`
  worden apart beoordeeld. Beide moeten via de echte Admin-route downloadbaar
  zijn, de manifestgrootte hebben en geldige schema-, job- en bedraggegevens
  bevatten. Het hoofdbedrag moet met de autoritatieve Admin-prijs overeenkomen.
  Het ruwe aantal 15 blijft in het bewijs staan; de 13 gedeelde bestanden worden
  afzonderlijk vergeleken. Andere verschillen worden niet weggefilterd.
- De downloadlimiet blijft exact: één bestandsdownload voor de referentie,
  drie voor FIX36 (één DXF plus twee prijsdocumenten). Bij de reset-test
  zijn het precies vier: de bestaande controle na reset downloadt nog één DXF.
- Een PASS wordt opnieuw gecontroleerd op alle rapporten, profielen, afzonderlijke
  controles, actuele tijdstippen, bronhashes en daadwerkelijk gestarte engines.

Alle 18 scenario's, profielen en 138 verplichte controles uit R2 blijven aanwezig.
R3 voegt zes verplichte controles toe: totaal **144**.
De oude `fix30-...` scenario-ID's blijven staan voor traceerbaarheid; hun
componentverwachtingen zijn nu expliciet voor FIX36.

## Uitvoering en bewijs

De bestaande vastgepinde Playwright-image, Node 24 en Playwright 1.62.0 blijven
gelijk. Alleen de installatie van de vastgepinde npm-afhankelijkheden heeft
netwerktoegang. De browsercontainer heeft `--network none`, geen hostpoorten,
alleen tijdelijke testgegevens en een alleen-lezen applicatiepakket.
Limieten: 1,25 CPU, 1536 MiB RAM, 512 processen, 90 minuten totaal en 10 minuten
per scenario. Chromium en WebKit zijn beide verplicht.

`LOCAL_VALIDATION.json` beschrijft uitsluitend lokale controles van de testcode,
rapportvalidatie en hergebruik van de serverfixture uit R2 voor de ongewijzigde
applicatie. Er is geen nieuwe lokale serverjob of browserrun uitgevoerd.
De testfixtures met synthetische rapporten zijn alleen validator-unit-tests.

Herkomst en wijzigingen staan in `FIX36_R3_CHANGES.md`, de patchbestanden
en `oracle/FIX36_R4_PROVENANCE.json`. De originele R1- en R2-foutuitvoer blijven als
ongewijzigde ZIPs bijgevoegd onder `prior-evidence/`.

## Resterende vrijgave

Dit is een apart FIX36 R3-browsercontract met 18 scenario's en 144 controles.
Het wordt niet omgezet naar het oudere FIX33-contract met 15 scenario's.
Die aansluiting moet bij de uiteindelijke externe vrijgave expliciet worden
vastgelegd. `productionGo` en `releaseEligible` blijven `false`.

De browsertest vervangt geen fysieke iPhone-toetsenbordcontrole, controle van
alle Admin-onderdelen en Inbox-acties, schone-serverinstallatie, herstelproef,
domein/HTTPS, onafhankelijke beveiligingsaudit of praktische DXF/CAM-acceptatie.
