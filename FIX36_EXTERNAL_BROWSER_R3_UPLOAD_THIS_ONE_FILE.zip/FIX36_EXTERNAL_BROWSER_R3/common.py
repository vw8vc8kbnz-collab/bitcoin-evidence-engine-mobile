"""Release and external test package identities; no production state access."""
from pathlib import Path
import hashlib
import json
import stat

CANDIDATE_SHA = '99470896de783030bf08afa83020bfc82b7a9d5cff51041b8428edf5b21422b2'
CANDIDATE_MANIFEST_SHA = '67dc33e9e86f47214e8fb01d4033a5f27c84e137754d6339bfa9df24eefc7b4a'
GOLDEN_SHA = 'd3e8656d8d7d5a581a8186ef8fe2c91c19b2137a8654b2f2874497dd85255e62'
REGISTRY_SHA = '76dee630dbae5c68c236fadda70b74151b7a89241b450c0c8b0b7f164a2dbb30'
IMAGE = 'mcr.microsoft.com/playwright@sha256:baed2032d533817f3dbe6425de795788430ba345e819a1201337009ba17c9d07'


def digest(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()


def atomic_json(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=True, allow_nan=False) + '\n')
    temporary.replace(path)


def verify_package(root):
    root = Path(root)
    expected = json.loads((root / 'PACKAGE_SHA256SUMS.json').read_text())
    actual = set()
    for path in root.rglob('*'):
        mode = path.lstat().st_mode
        if stat.S_ISDIR(mode):
            continue
        if not stat.S_ISREG(mode):
            raise ValueError('Non-regular entry in test package')
        name = path.relative_to(root).as_posix()
        if name == 'PACKAGE_SHA256SUMS.json':
            continue
        actual.add(name)
        if name not in expected or digest(path) != expected[name]:
            raise ValueError('Test package hash mismatch: ' + name)
    if actual != set(expected):
        raise ValueError('Incomplete test package')
    if digest(root / 'candidate.zip') != CANDIDATE_SHA:
        raise ValueError('Candidate ZIP is not the published FIX36')
    if digest(root / 'oracle/contracts/R9A_BROWSER_FIXTURES.json') != REGISTRY_SHA:
        raise ValueError('FIX36 R3 fixture registry changed')
