# FIX36 browser R3 — reparatie van de R2-testcode

De oorspronkelijke R2-run blijft FAIL. De ZIP wordt ongewijzigd bewaard onder
prior-evidence/FIX36_BROWSER_R2_FAILURE.zip. Er wordt geen historisch rapport
herschreven of als nieuwe browser-PASS gepresenteerd.

## Vastgestelde R2-uitkomst

- 14 van 18 scenario's PASS; 123 van 138 verplichte controles PASS.
- Verversen in Chromium en WebKit slaagt nu, inclusief alle templates.
- De mobiele component-, materiaal-, paneel-, nerf- en checkoutcontroles slagen.
- De nieuwe prijsdocumentcontroles slagen op desktop en iPhone in beide engines.
- Drie scenario's falen uitsluitend doordat de bestandsvergelijking de
  tijdstempel in paneel-ID's als verschil behandelt. In elk van de zes
  profielvergelijkingen is sealedFiles de enige afwijkende hoofdsleutel.
- De reset-test stopt in de testdriver vóór de privacycontroles. De aanroep van
  fullUiPath gaf nog losse argumenten door en miste diagnostics/releaseSide.
  Dit rapport bewijst daarom geen geslaagde of mislukte product-privacyreset.

Native R2-rapport SHA256:
`b3deeb67fcbd9264debede46d804b795ea6829313593866aef2f12b937f05b5d`.

## Reparaties

fullUiPath ontvangt voortaan één volledig scenario-object. Zowel de gewone
checkout als Admin-projectie en privacyreset geven exact dat object door.
De privacyreset behoudt zijn eigen klant-sentinel en alle bestaande controles.
De vier bestandsdownloads tijdens die test worden exact begrensd: één DXF en
twee prijsdocumenten vóór reset, één DXF bij de bestaande backendcontrole erna.

De applicatie maakt paneel-ID's met een tijdstempel en volgnummer. R3 leest de
werkelijk gekozen cart-ID's en de daadwerkelijke POST-payload van /api/jobs.
De geselecteerde ID's moeten uniek zijn en exact overeenkomen met de verzonden
DXF-sleutels. Elk geëxporteerd onderdeel moet vervolgens exact bij één van die
ID's horen en bij de juiste materiaaljob. Pas daarna krijgt het in de vergelijking
een alias panel-1 of panel-2. Template en materiaal blijven vergelijkingswaarden.
Ruwe paneel-ID's, filenames en koppelingen blijven in het bewijs staan.

Er is geen algemene timestamp-regex of tolerant bestandsaantal toegevoegd.
Onverwachte, ontbrekende of dubbel gekoppelde onderdelen blijven fouten.

## Gerichte regressietests

Dertien nieuwe Node-testgevallen controleren:

- De zes werkelijk afwijkende R2-profielvergelijkingen met behoud van hun overige
  waarden. Alleen de expliciet gekoppelde paneelnamen verschillen.
- Verkeerde geselecteerde/verzonden/export-ID's, ontbrekende onderdelen,
  duplicaten, verkeerde template/materialen/jobs en ongemoeid gelaten andere
  tijdstempelachtige namen.
- Alle echte aanroepfuncties van de gedeelde checkout, inclusief privacyreset
  en zijn klant-sentinel. De test voert deze functies daadwerkelijk uit met een
  geïnstrumenteerde checkoutgrens; dit zou de R2-argumentfout hebben afgekeurd.
- De volledige gedeelde checkoutbesturing met nagebootste browserinteracties
  voor golden en candidate, inclusief bestaande lokale serverfixturegegevens.

Deze lokale tests zijn geen browserbewijs. De R2-gegevens worden alleen gebruikt
als regressie-input; een lokaal gelijke vergelijking verandert hun
historische status niet. Een nieuwe volledige VPS-run blijft noodzakelijk.

Alle 18 scenario's en 138 R2-controle-ID's blijven aanwezig. R3 voegt zes
verplichte controles toe: totaal 144. De oorspronkelijke 22 runner-tests,
26 R2-contracttests en rapportvalidatietests blijven behouden.

## Applicatie en aflevering

candidate.zip blijft de complete ongewijzigde FIX36-applicatie met SHA256
`99470896de783030bf08afa83020bfc82b7a9d5cff51041b8428edf5b21422b2`.
De launcher installeert of herstart geen actieve applicatie en bewaart alle
oude runs. De nieuwe startregel gebruikt de gecontroleerde golden-ZIP uit de
bewaarde R2-run van 11 september. Na afloop wordt de bewijs-ZIP ook in de
thuismap van ubuntu neergezet.

De patches en bronherkomst zijn bijgevoegd. LOCAL_VALIDATION.json benoemt de
lokale controles en hun grenzen. Het oudere FIX33-contract met 15 scenario's
wordt niet automatisch als voldaan beschouwd. productionGo en releaseEligible
blijven false; productieacceptatie blijft een aparte stap.
