'use strict';

// All browser interactions in the orchestration tests are mocks, explicitly.
// The original VPS FAIL is retained; these tests never produce browser evidence.
const assert = require('node:assert/strict');
const test = require('node:test');
const vm = require('node:vm');
const fs = require('node:fs');
const path = require('node:path');
const { createRequire } = require('node:module');
const contract = require('../oracle/tools/fix36_browser_contract');
const probe = require('./fixtures/candidate_inventory_probe.json');
const cases = require('./fixtures/r2_comparison_cases.json').cases;
const driverPath = path.resolve(__dirname, '../oracle/tools/r9a_browser_driver.js');
const source = fs.readFileSync(driverPath, 'utf8');
const templateId = 'deuren_metod_metod_deur_60x40';
const materialKey = 'decor_0123456789abcdefabcd';
const cart = ['PANEL_A', 'PANEL_B'].map(id => ({ id, templateId, materialKey }));
const payload = { dxfPartRefs: { PANEL_A: 'blob1', PANEL_B: 'blob1' } };

function driverContext() {
  const sandbox = { require: createRequire(driverPath), module: { exports: {} }, process,
    Buffer, URL, setTimeout, clearTimeout, console };
  const context = vm.createContext(sandbox);
  vm.runInContext(source + '\nglobalThis.testApi = { fullUiPath, SCENARIOS, assertionCollector };', context);
  return context;
}

for (const item of cases) test(`R2 actual comparison ${item.fixture}/${item.profile} differs only in bound panel IDs`, () => {
  const values = ['golden', 'candidate'].map(side => {
    const observation = structuredClone(item[side]);
    // Synthetic UI context built for replay only; R2 did not record UI IDs.
    const ids = observation.sealedFiles.filter(file => file.rel.startsWith('output/DXF_Onderdelen/'))
      .map(file => file.rel.slice('output/DXF_Onderdelen/'.length, -4));
    const selected = ids.map(id => ({ id, templateId, materialKey }));
    const bindings = contract.checkoutPartIdentities(selected, { dxfPartRefs: Object.fromEntries(ids.map(id => [id, 'blob'])) });
    observation.sealedFiles = contract.bindPartFiles(observation.sealedFiles, bindings);
    return observation;
  });
  assert.deepEqual(values[0], values[1]);
  assert.notDeepEqual(item.golden.sealedFiles, item.candidate.sealedFiles);
});

test('selected IDs must match submitted IDs exactly, including runtime stamp', () => {
  const changed = structuredClone(payload); changed.dxfPartRefs.PANEL_NEW = changed.dxfPartRefs.PANEL_A; delete changed.dxfPartRefs.PANEL_A;
  assert.throws(() => contract.checkoutPartIdentities(cart, changed));
  assert.throws(() => contract.checkoutPartIdentities([cart[0], cart[0]], payload));
  assert.throws(() => contract.checkoutPartIdentities([{ ...cart[0], templateId: 'wrong-template' }, cart[1]], payload));
  assert.throws(() => contract.checkoutPartIdentities([{ ...cart[0], materialKey: 'wrong-material' }, cart[1]], payload));
});

test('exports cannot substitute, omit, duplicate or reassign a selected part', () => {
  const bindings = contract.checkoutPartIdentities(cart, payload);
  const files = contract.inventoryEvidence(probe.files, probe.parentJobId, 'candidate').comparable;
  const index = files.findIndex(file => file.rel.endsWith('/PANEL_A.dxf'));
  for (const change of ['rename', 'omit', 'duplicate', 'wrong-job']) {
    const broken = structuredClone(files);
    if (change === 'rename') broken[index].rel = 'output/DXF_Onderdelen/PANEL_9999999999999.dxf';
    if (change === 'omit') broken.splice(index, 1);
    if (change === 'duplicate') broken.push({ ...broken[index] });
    if (change === 'wrong-job') broken[index].role = 'master';
    assert.throws(() => contract.bindPartFiles(broken, bindings));
  }
});

test('unrelated timestamp-like filenames stay literal', () => {
  const bindings = contract.checkoutPartIdentities(cart, payload);
  const files = contract.inventoryEvidence(probe.files, probe.parentJobId, 'candidate').comparable;
  files.push({ role: 'master', rel: 'output/report_1789102618740.json', kind: 'other' });
  assert.ok(contract.bindPartFiles(files, bindings).some(file => file.rel === 'output/report_1789102618740.json'));
});

test('all actual checkout callers pass the complete same scenario context, including reset overrides', async () => {
  const context = driverContext();
  vm.runInContext(`fullUiPath = async (env, options = {}) => { globalThis.observedCheckout = { env, options }; throw new Error('STOP_AFTER_CONTEXT_CAPTURE'); };`, context);
  for (const name of ['fullUiCheckout', 'adminProjectionDownload', 'newConfigurationReset']) {
    const env = { page: {}, profile: {}, assert: {}, releaseSide: 'candidate', diagnostics: {},
      sentinelRef: { value: '' }, consoleMessages: [], network: { requests: [] } };
    await assert.rejects(context.testApi.SCENARIOS[name](env), /STOP_AFTER_CONTEXT_CAPTURE/);
    assert.equal(context.observedCheckout.env, env);
    assert.equal(context.observedCheckout.env.diagnostics, env.diagnostics);
    if (name === 'newConfigurationReset') {
      assert.match(context.observedCheckout.options.customerOverrides.custFirstName, /^R9A-PII-/);
      assert.equal(context.observedCheckout.options.customerOverrides.custFirstName, env.sentinelRef.value);
    }
  }
});

for (const side of ['golden', 'candidate']) test(`entire shared checkout orchestration with mocked browser completes for ${side}`, async () => {
  const context = driverContext();
  const checks = context.testApi.assertionCollector();
  const requestId = 'REQUEST_FIXTURE';
  const files = probe.files.filter(file => side === 'candidate' || file.rel !== contract.PRICING_REL);
  const admin = {
    loginStatus: 200, loginOk: true, requestsStatus: 200, filesStatus: 200,
    row: { customer: { email: 'test@example.invalid' } },
    files: { allFiles: files, pricingSummary: { totalInclVat: probe.authoritativeTotal } },
    pricingDownloads: side === 'candidate' ? probe.downloads : [], adminStorageKeys: [],
    individualDownload: { status: 200, bytes: 10, firstBytes: [48, 10], contentDisposition: 'a.dxf', expectedDownloadName: 'a.dxf' },
    zipDownload: { status: 200, bytes: 10, firstBytes: [80, 75], contentDisposition: 'a.zip' }
  };
  context.adminFixture = admin;
  context.expectedPricing = side === 'candidate';
  vm.runInContext(`
    selectMaterialCards = choosePanelThroughUi = buildGrainGroupThroughUi = activate = async () => {};
    fillCustomerThroughUi = async () => ({ custEmail: 'test@example.invalid' });
    adminProjection = async (page, id, includePricing) => {
      if (includePricing !== expectedPricing) throw new Error('Wrong pricing download side');
      return adminFixture;
    };
  `, context);
  const evaluations = [cart, { requestId: '', thankYou: false, total: '€465,37' },
    { requestId, title: 'Bedankt', overlayText: 'Bedankt ' + requestId }];
  const responses = [
    { status: () => 202, json: async () => ({ jobId: probe.parentJobId }), request: () => ({ postDataJSON: () => payload }) },
    { status: () => 200, json: async () => ({ ok: true, parentJobId: probe.parentJobId, requestId }) }
  ];
  const page = { locator: () => ({ waitFor: async () => {} }), waitForFunction: async () => {},
    waitForResponse: async () => responses.shift(), evaluate: async () => evaluations.shift(),
    context: () => ({ cookies: async () => [{ name: 'adzaagt_admin_session', httpOnly: true }] }) };
  const env = { page, profile: { formFactor: 'desktop' }, assert: checks, releaseSide: side, diagnostics: {} };
  const result = await context.testApi.fullUiPath(env);
  assert.equal(result.requestId, requestId);
  assert.equal(result.partIdentities.length, 2);
  assert.ok(checks.assertions.every(check => check.ok));
  assert.ok(checks.assertions.some(check => check.id === 'checkout-part-identities-bound'));
  assert.equal(env.diagnostics.sealedFileInventory.length, side === 'candidate' ? 15 : 13);
  assert.equal(evaluations.length, 0);
  assert.equal(responses.length, 0);
});

test('reset file download budget includes its preserved-request download after reset', () => {
  const registry = require('../oracle/contracts/R9A_BROWSER_FIXTURES.json');
  const reset = registry.fixtures.find(fixture => fixture.scenario === 'newConfigurationReset');
  assert.deepEqual(reset.networkExpectations['GET /api/admin/request_file'], { minimum: 4, maximum: 4 });
});
