# Configurator Studio v0.4

AI-first statische proof-of-concept voor een no-code 3D configurator builder.

## Wat werkt nu echt

- Vanilla JS SPA met hash-router.
- Three.js/R3F-achtige eigen engine zonder framework.
- Eén gedeelde `ConfiguratorEngine` voor builder, preview en embed.
- **Nieuwe hoofdroute in v0.4:** prompt → AI-modelconcept → review → desktop/mobile preview → publish-check.
- **Nieuwe hoofdroute in v0.4:** productfoto’s uploaden → image-to-3D concept → review → desktop/mobile preview → publish-check.
- Klanten kunnen nog steeds een eigen GLB/GLTF uploaden als advanced/fallback route.
- Lokale/procedural AI mock-provider voor prompt/photo flows met configureerbare slots per productcategorie.
- Dashboard met twee AI-startkaarten: prompt-to-3D en photo-to-3D.
- Configurator AI Studio met provider-ready adapterlaag:
  - 3D-model genereren uit prompt
  - 3D-model maken uit 1–4 productfoto’s
  - AI-materiaalprompt → nieuw bibliotheekmateriaal
  - part-detection/naming voorstel
  - mobile optimizer/check
  - asset review gate
  - AI jobs/audit trail
- Desktop- en mobile-preview met dezelfde runtime.
- Configuraties opslaan in localStorage met `CFG-*` code en Shopify line-item-properties preview.
- Publish-check blokkeert AI-output totdat deze handmatig is gereviewd.

## Wat nog niet productie-klaar is

- Geen Next.js/Supabase backend.
- Geen echte Shopify OAuth/app block/cart bridge.
- Geen server-side prijsvalidatie.
- Geen echte AI API-integratie; v0.4 gebruikt een mock/procedural provider.
- Productfoto’s worden lokaal geregistreerd; productie vereist upload naar storage/CDN en provider task polling.
- GLB upload gebruikt nog tijdelijke blob-URL; productie vereist CDN/storage.

## Lokaal draaien

```bash
cd configurator-studio-v0.4
python3 -m http.server 8000
# open http://localhost:8000
```

## Belangrijk principe

AI output publiceert nooit direct. Flow moet blijven:

```text
AI output → normalizer → configurator-ready checker → desktop preview → mobile preview → publish-check → live
```

## Productieroute later

De mock-provider moet vervangen worden door een server-side provider adapter layer:

```text
Prompt/images upload
→ backend AI job
→ provider adapter (Meshy/Tripo/Rodin/etc.)
→ async polling/webhook
→ GLB + textures naar storage/CDN
→ normalizer/checker
→ review + preview
→ publish
```
