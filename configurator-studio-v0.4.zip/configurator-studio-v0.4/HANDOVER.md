# HANDOVER — Configurator Studio v0.4

## Context

De productrichting is aangepast van “demo-tafelmodel + optioneel AI” naar **AI-first 3D model creation**. De reden: een handmatig demo-tafelmodel voelt te zwak en is niet de kernwaarde van het SaaS-product. De hoofdwaarde moet worden dat een webshop-eigenaar in de tool zelf een 3D-model kan laten maken vanuit een prompt of productfoto’s. Als de klant al een 3D-model heeft, blijft GLB/GLTF upload beschikbaar als advanced/fallback route.

## v0.4 kernwijziging

Nieuwe hoofdflow:

```text
Prompt of productfoto’s
→ AI-modelconcept
→ configureerbare slots/parts
→ handmatige review
→ desktop preview
→ mobile preview
→ publish-check
→ live embed / Shopify bridge later
```

AI output mag nooit direct live.

## Wat is gebouwd in v0.4

### 1. Dashboard AI-first

Bestand: `src/builder.js`

Het dashboard heet nu “AI-first 3D configurators” en toont twee hoofdkaarten:

1. Prompt-to-3D
2. Productfoto’s-to-3D

De oude flow “nieuwe configurator met demo-model” bestaat nog als projectkaart, maar is niet langer de hoofdpropositie.

### 2. Prompt-to-3D project creation

Bestand: `src/ai.js`

Functie:

```js
createAiPromptProject(prompt, category)
```

Maakt een nieuw project met:

- `model.source = 'ai_prompt'`
- prompt metadata
- categorie: table/chair/cabinet/lamp/product
- configureerbare slots per categorie
- default opties/materialen
- AI job audit item `text_to_3d_model`
- `reviewed: false`

### 3. Productfoto’s-to-3D project creation

Bestand: `src/ai.js`

Functie:

```js
createAiImageProject(files, prompt, category)
```

Maakt een nieuw project met:

- `model.source = 'ai_images'`
- 1–4 image inputs
- veilige file summary metadata
- tijdelijke browser preview URL’s
- categorie + optionele prompt/context
- configureerbare slots per categorie
- AI job audit item `image_to_3d_model`
- `reviewed: false`

Let op: dit is nog geen echte AI model generation. De statische MVP registreert de juiste productflow en maakt lokale/procedural mock-output. Productie moet dit vervangen door een backend job + provider.

### 4. Engine ondersteunt AI prompt én AI images

Bestand: `src/engine.js`

De engine bouwt nu procedural stand-ins voor:

- `ai_prompt`
- `ai_images`

Dit gebeurt via dezelfde slot-contracten die een echte provider later moet teruggeven.

Belangrijk: dit is bewust geen definitieve 3D-kwaliteit. Het is een stand-in om de SaaS workflow, review, preview, slots, opties en pricing te testen.

### 5. Publish check blokkeert ongereviewde AI-output

Bestand: `src/schema.js`

AI-output met source `ai_prompt` of `ai_images` moet eerst worden gemarkeerd als gereviewd in de AI Studio. Anders blijft publiceren geblokkeerd.

### 6. AI Studio uitgebreid

Bestand: `src/ai.js`

Cards:

- 3D-model genereren uit prompt
- 3D-model maken uit productfoto’s
- Asset review
- Onderdelen herkennen
- Materiaal maken
- Optimaliseren voor mobiel
- Conceptmodel maken legacy
- AI jobs/audit trail

### 7. CSS toegevoegd

Bestand: `styles/app.css`

Nieuwe dashboard-styling voor de AI-first startkaarten en foto-upload inputs.

## Productie-realiteit

Echte AI 3D is mogelijk, maar moet via server-side async jobs gebeuren. De frontend mag nooit rechtstreeks provider API keys bevatten.

Gewenste productie-architectuur:

```text
Frontend upload/prompt
→ /api/ai/jobs
→ provider adapter
→ provider task_id
→ polling/webhook
→ output GLB/textures downloaden
→ upload naar Supabase/S3/CDN
→ normalizer
→ configurator-ready checker
→ project draft update
→ review gate
```

## Aanbevolen providers later

- Meshy: text-to-3D, image-to-3D, multi-image-to-3D, retexture.
- Tripo: text/image-to-model en editing/segmentation richting parts.
- Rodin/Hyper3D: premium/fotorealistische GLB/PBR output.
- Open-source/self-hosted later pas, vanwege GPU/ops complexity.

## Belangrijkste regels

1. AI-first is hoofdroute.
2. GLB upload blijft optioneel voor klanten die al een model hebben.
3. AI output publiceert nooit direct.
4. Prompt/photo output vereist handmatige review.
5. Preview en live gebruiken dezelfde engine.
6. Desktop en mobile preview blijven verplicht.
7. De providerkeuze moet later task-based verborgen blijven voor de klant.
8. Echte prijsvalidatie moet server-side gebeuren in de Next.js/Supabase versie.

## Wat nog moet in de volgende grote stap

Deze statische versie moet worden omgezet naar een echte SaaS stack:

- Next.js App Router
- Supabase Auth/Postgres/Storage
- server-side AI jobs
- echte provider adapter(s)
- GLB/texture storage
- configurator-ready checker
- Shopify app/theme extension
- server-side price validation
- Stripe billing later

