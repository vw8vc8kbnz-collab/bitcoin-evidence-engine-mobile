// App entry point.
import { store } from './store.js';
import { startRouter, parseRoute, navigate } from './router.js';
import { renderDashboard, renderBuilder } from './builder.js';
import { renderLibrary } from './library.js';
import { renderAiStudio } from './ai.js';
import { renderConfigurations, renderConfigDetail } from './configs.js';
import { renderRuntime } from './runtime.js';
import { buildRuntimeConfig, summarize, newConfiguration } from './schema.js';
import { el, mount, clear, euro, toast } from './util.js';

const app = document.getElementById('app');
let liveController = null;

function disposeLive() { if (liveController) { try { liveController.dispose(); } catch (e) {} liveController = null; } }

function renderLive(id, bare) {
  disposeLive();
  const project = store.getProject(id);
  if (!project) { navigate('#/'); return; }
  const config = buildRuntimeConfig(project, store.getLibrary());
  const container = el('div', { class: bare ? 'embed-host' : 'live-host' });
  if (!bare) {
    container.appendChild(el('button', { class: 'live-back', onclick: () => navigate(`#/p/${id}/preview`), text: '‹ Terug naar builder' }));
  }
  const rtHost = el('div', { class: 'live-runtime' });
  container.appendChild(rtHost);
  mount(app, container);
  liveController = renderRuntime(rtHost, config, {
    onAddToCart: async (sel) => {
      // In production: POST /api/configurations -> validate server-side -> map to Shopify variant/SKU -> add to cart.
      const { summary, total } = summarize(config, sel);
      const cfg = newConfiguration({ projectId: project.id, projectName: project.name, selection: sel, summary, total, currency: project.currency, device: bare ? 'embed' : 'desktop' });
      await store.saveConfiguration(cfg);
      toast('Toegevoegd · ' + cfg.publicCode + ' · ' + euro(total, project.currency));
    },
  });
}

function route(r) {
  if (r.name !== 'preview' && r.name !== 'embed') disposeLive();
  if (r.name === 'dashboard') renderDashboard(app);
  else if (r.name === 'builder') renderBuilder(app, r.id, r.step);
  else if (r.name === 'preview') renderLive(r.id, false);
  else if (r.name === 'embed') renderLive(r.id, true);
  else if (r.name === 'library') renderLibrary(app);
  else if (r.name === 'ai') renderAiStudio(app);
  else if (r.name === 'configs') renderConfigurations(app);
  else if (r.name === 'config') renderConfigDetail(app, r.id);
  else renderDashboard(app);
}

(async function boot() {
  mount(app, el('div', { class: 'boot', text: 'Laden…' }));
  await store.init();
  startRouter(route);
})();
