# DEPLOY — Configurator Studio v0.4

Dit is een statische proof-of-concept. Je kunt hem lokaal of via simpele static hosting draaien.

## Lokaal

```bash
cd configurator-studio-v0.4
python3 -m http.server 8000
```

Open:

```text
http://localhost:8000
```

## VPS/static nginx

Plaats de mapinhoud in een webroot en serveer `index.html`.

Voor hash routing is geen extra rewrite nodig.

## Belangrijk

v0.4 bevat geen echte backend. API keys voor Meshy/Tripo/Rodin mogen nooit in deze statische frontend worden gezet. Echte AI-integratie moet via een server-side endpoint.

## Versie

- v0.4: AI-first hoofdroute met prompt-to-3D en photo-to-3D mock/provider-ready flows.
