#!/usr/bin/env bash
set -Eeuo pipefail
export PATH=/usr/sbin:/usr/bin:/sbin:/bin
export PYTHONDONTWRITEBYTECODE=1 PYTHONSAFEPATH=1 PYTHONNOUSERSITE=1
unset PYTHONPATH PYTHONHOME PYTHONSTARTUP PYTHONINSPECT PYTHONUSERBASE

PACKAGE_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
HELPER="$PACKAGE_ROOT/fix30_acceptance_probe.py"
CONTRACT="$PACKAGE_ROOT/FIX30_ACCEPTANCE_RECOVERY_CONTRACT.json"
FROZEN_OUTER="$PACKAGE_ROOT/METOD_PAX_R9RC4_FIX30_MOBILE_MATERIAL_CHECKOUT_GRAIN_DISCOVERY_UPLOAD_THIS_ONE_FILE.zip"
EXPECTED_OUTER_SHA="643467ac8e9a20a3f500aaaa180336213c7db33b2d10de3cd3f7f731dfd7cc0f"
EXPECTED_INNER_SHA="cccdcb1bcd40f112ac59722361b43718fed77d7a7c334225a64a2f586c113bf3"
OUTPUT_DIR="${FIX30_OUTPUT_DIR:-/home/ubuntu}"

fail(){ echo "FIX30 ACCEPTANCE FOUT: $*" >&2; exit 1; }
info(){ echo "[FIX30_ACCEPTANCE_RECOVERY] $*"; }
safe_output_dir(){ [[ "$1" =~ ^/[A-Za-z0-9._/-]+$ ]] || fail "Onveilig outputpad"; }

safe_output_dir "$OUTPUT_DIR"
if [[ "$EUID" -ne 0 ]]; then
  exec sudo env \
    PATH=/usr/sbin:/usr/bin:/sbin:/bin \
    PYTHONDONTWRITEBYTECODE=1 PYTHONSAFEPATH=1 PYTHONNOUSERSITE=1 \
    FIX30_OUTPUT_DIR="$OUTPUT_DIR" \
    bash "$0"
fi

for command in /usr/bin/python3 sha256sum unzip bash tee stat readlink; do
  command -v "$command" >/dev/null || fail "Ontbrekend commando: $command"
done
[[ -d "$OUTPUT_DIR" && ! -L "$OUTPUT_DIR" ]] || fail "Outputmap ontbreekt of is een symlink"
[[ -f "$PACKAGE_ROOT/ACCEPTANCE_SHA256SUMS.txt" && ! -L "$PACKAGE_ROOT/ACCEPTANCE_SHA256SUMS.txt" ]] \
  || fail "Pakketmanifest ontbreekt of is onveilig"

info "Fase 1/8: acceptatiepakket en bevroren FIX30-bytes controleren"
(cd "$PACKAGE_ROOT" && sha256sum -c ACCEPTANCE_SHA256SUMS.txt)
printf '%s  %s\n' "$EXPECTED_OUTER_SHA" "$FROZEN_OUTER" | sha256sum -c -

WORK="$(mktemp -d /var/tmp/metod-fix30-acceptance.XXXXXXXX)"
chmod 0700 "$WORK"
EVIDENCE="$WORK/evidence"
mkdir -m 0700 "$EVIDENCE"
RESTORE_HOLDER=""
cleanup(){
  if [[ -n "$RESTORE_HOLDER" && -d "$RESTORE_HOLDER" && ! -L "$RESTORE_HOLDER" ]]; then
    /usr/bin/python3 -I -S -B "$HELPER" remove-restore "$RESTORE_HOLDER" >/dev/null 2>&1 || true
  fi
  [[ "$WORK" == /var/tmp/metod-fix30-acceptance.* && -d "$WORK" && ! -L "$WORK" ]] && rm -rf -- "$WORK"
}
trap cleanup EXIT

mkdir -m 0700 "$WORK/outer" "$WORK/inner"
unzip -q "$FROZEN_OUTER" -d "$WORK/outer"
INNER="$WORK/outer/R9RC4_FIX30_DELIVERY/METOD_PAX_R9RC4_TOOL_A_RUNTIME_HARDENING_CANDIDATE.zip"
[[ -f "$INNER" && ! -L "$INNER" ]] || fail "Bevroren inner artifact ontbreekt"
printf '%s  %s\n' "$EXPECTED_INNER_SHA" "$INNER" | sha256sum -c -
unzip -q "$INNER" -d "$WORK/inner"
RELEASE_ROOT="$WORK/inner/METOD_PAX_R9RC4_TOOL_A_RUNTIME_HARDENING_CANDIDATE"
[[ -d "$RELEASE_ROOT" && ! -L "$RELEASE_ROOT" ]] || fail "FIX30 releaseroot ontbreekt"

info "Fase 2/8: volledige standalone artifactpreflight uitvoeren"
/usr/bin/python3 -I -S -B "$RELEASE_ROOT/tools/verify_standalone_artifact.py" \
  --artifact "$INNER" --expected-sha256 "$EXPECTED_INNER_SHA" \
  | tee "$EVIDENCE/standalone.json"

info "Fase 3/8: live FIX30- en statecontract vóór herdeploy vastleggen"
/usr/bin/python3 -I -S -B "$HELPER" snapshot \
  --phase pre --release-root "$RELEASE_ROOT" --output "$EVIDENCE/pre-snapshot.json" >/dev/null

info "Fase 4/8: exact dezelfde FIX30-release éénmaal atomisch herdeployen"
bash "$RELEASE_ROOT/INSTALL_STAGING_PREVIEW_UPDATE.sh" 2>&1 | tee "$EVIDENCE/deploy.log"

info "Fase 5/8: release, state, health en publieke bytes na herdeploy vergelijken"
/usr/bin/python3 -I -S -B "$HELPER" snapshot \
  --phase post --release-root "$RELEASE_ROOT" --output "$EVIDENCE/post-snapshot.json" >/dev/null
/usr/bin/python3 -I -S -B "$HELPER" compare \
  --before "$EVIDENCE/pre-snapshot.json" --after "$EVIDENCE/post-snapshot.json" \
  --output "$EVIDENCE/deploy-comparison.json" >/dev/null

info "Fase 6/8: nieuwste echte systeembackup geïsoleerd herstellen en byteverifiëren"
BACKUP_PATH="$(/usr/bin/python3 -I -S -B "$HELPER" select-backup --max-age-days 7)"
printf 'SELECTED_BACKUP=%s\n' "${BACKUP_PATH##*/}" > "$EVIDENCE/backup-selection.txt"
RESTORE_HOLDER="$(mktemp -d /var/tmp/metod-fix30-acceptance-restore.XXXXXXXX)"
chmod 0700 "$RESTORE_HOLDER"
RESTORE_TARGET="$RESTORE_HOLDER/restored-state"
/usr/bin/python3 -I -S -B "$RELEASE_ROOT/tools/restore_system_backup.py" "$BACKUP_PATH" \
  --target "$RESTORE_TARGET" --proof "$EVIDENCE/restore-proof.json" \
  > "$EVIDENCE/restore-output.json"

info "Fase 7/8: bewijzen dat de geïsoleerde restore live service/state niet wijzigde"
/usr/bin/python3 -I -S -B "$HELPER" snapshot \
  --phase recovery --release-root "$RELEASE_ROOT" --output "$EVIDENCE/recovery-snapshot.json" >/dev/null
/usr/bin/python3 -I -S -B "$HELPER" compare \
  --before "$EVIDENCE/post-snapshot.json" --after "$EVIDENCE/recovery-snapshot.json" \
  --output "$EVIDENCE/recovery-comparison.json" >/dev/null
/usr/bin/python3 -I -S -B "$HELPER" remove-restore "$RESTORE_HOLDER" >/dev/null
RESTORE_HOLDER=""

info "Fase 8/8: privacy-veilige evidence verzegelen"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
EVIDENCE_ZIP="$OUTPUT_DIR/METOD_FIX30_ACCEPTANCE_RECOVERY_EVIDENCE_${STAMP}.zip"
FINAL_JSON="$EVIDENCE/finalize.json"
/usr/bin/python3 -I -S -B "$HELPER" finalize \
  --evidence-dir "$EVIDENCE" --output-zip "$EVIDENCE_ZIP" \
  --contract "$CONTRACT" --json-output "$FINAL_JSON" >/dev/null
REPORT_OUT="$OUTPUT_DIR/METOD_FIX30_ACCEPTANCE_RECOVERY_REPORT_${STAMP}.json"
install -o root -g root -m 0644 "$EVIDENCE/FIX30_ACCEPTANCE_RECOVERY_REPORT.json" "$REPORT_OUT"
SHA_OUT="$EVIDENCE_ZIP.sha256"
sha256sum "$EVIDENCE_ZIP" > "$SHA_OUT"
if id ubuntu >/dev/null 2>&1; then
  chown ubuntu:ubuntu "$EVIDENCE_ZIP" "$SHA_OUT" "$REPORT_OUT"
fi
PREVIEW_ORIGIN="$(/usr/bin/python3 -I -S -B - "$EVIDENCE/recovery-snapshot.json" <<'PY'
import json,sys
print(json.load(open(sys.argv[1],encoding='utf-8'))['previewOrigin'])
PY
)"

echo
echo "FIX30_ACCEPTANCE_RECOVERY_PASS"
echo "REPORT=$REPORT_OUT"
echo "EVIDENCE=$EVIDENCE_ZIP"
echo "EVIDENCE_SHA256=$(sha256sum "$EVIDENCE_ZIP" | awk '{print $1}')"
echo "OPEN=$PREVIEW_ORIGIN/?fix30=1"
echo "PRODUCTIE_GO=NEE_NOG_EXTERNE_GATES"

