#!/usr/bin/env python3
from __future__ import annotations

"""Fail-closed VPS acceptance and isolated-recovery evidence helper for FIX30.

The helper never restores over live state and never serializes customer records,
private filenames, credentials, request bodies or backup contents into evidence.
"""

import argparse
import hashlib
import json
import math
import os
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any


EXPECTED_REVISION = "R9RC4_FIX30_MOBILE_MATERIAL_CHECKOUT_GRAIN_DISCOVERY"
EXPECTED_BUILD = "FIX660R8_PRELIVE_HARDENED"
EXPECTED_OUTER_SHA256 = "643467ac8e9a20a3f500aaaa180336213c7db33b2d10de3cd3f7f731dfd7cc0f"
EXPECTED_INNER_SHA256 = "cccdcb1bcd40f112ac59722361b43718fed77d7a7c334225a64a2f586c113bf3"
MAX_HTTP_BYTES = 32 * 1024 * 1024
BACKUP_NAME = re.compile(r"system_backup_(?:auto|manual)_[-0-9T_Z]+\.zip\Z")
ORIGIN_HOST = re.compile(
    r"(?=.{4,253}\Z)(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.)+[A-Za-z]{2,63}\Z"
)
ASSET_PATHS = (
    "/tool-a/bootstrap.js?fix30=1",
    "/tool-a/components/mobile-material-cart.js?fix30=1",
    "/tool-a/components/footer.js?fix30=1",
    "/tool-a/components/checkout-review.js?fix30=1",
    "/tool-a/components/progress-overlay.js?fix30=1",
    "/tool-a/runtime/classic-runtime.bundle.js?fix30=1",
    "/tool-a/styles/tool-a.bundle.css?fix30=1",
)
REQUIRED_MARKERS = {
    "/tool-a/components/mobile-material-cart.js?fix30=1": (
        "R9RC4_FIX30_MOBILE_MATERIAL_CHECKOUT_GRAIN_DISCOVERY",
    ),
    "/tool-a/components/checkout-review.js?fix30=1": (
        "R9RC4_FIX30_CANONICAL_CHECKOUT_REVIEW",
    ),
    "/tool-a/components/progress-overlay.js?fix30=1": (
        "R9RC4_FIX30_VERIFIED_PROGRESS",
    ),
    "/tool-a/runtime/classic-runtime.bundle.js?fix30=1": (
        "R9RC4_FIX30_MATERIAL_GROUPED_PANEL_LIST",
        "R9RC4_FIX30_SHARED_CHECKOUT_SCOPE",
        "R9RC4_FIX30_GRAIN_PREVIEW_CTA",
        "await settleOptimizerProgress({progressPct:100,progressLabel:'Optimalisatie afgerond'});",
        "const opened=owner.openCheckoutReview({state,snapshot:jobReviewSnapshot});",
    ),
    "/tool-a/styles/tool-a.bundle.css?fix30=1": (
        "#grainOverlay .fix660DrawerHandle{position:absolute!important;left:50%!important;top:7px!important;transform:translateX(-50%)!important;z-index:8!important;width:154px!important;min-width:154px!important;height:34px!important;min-height:34px!important;",
        "#grainOverlay .fix660DrawerHandleText{",
    ),
}
CRITICAL_STATE_FILES = (
    ".fix660r8_external_state_v1.json",
    "material_library.json",
    "config/pricing_active.json",
    "embedded_dxfs_manifest.json",
)


class AcceptanceError(RuntimeError):
    pass


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def strict_json_bytes(raw: bytes, label: str) -> Any:
    def unique_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        value: dict[str, Any] = {}
        for key, item in pairs:
            if key in value:
                raise AcceptanceError(f"{label}: dubbele JSON-sleutel: {key}")
            value[key] = item
        return value

    def reject_constant(value: str) -> None:
        raise AcceptanceError(f"{label}: niet-eindige JSON-waarde: {value}")

    try:
        return json.loads(
            raw.decode("utf-8", errors="strict"),
            object_pairs_hook=unique_object,
            parse_constant=reject_constant,
        )
    except AcceptanceError:
        raise
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise AcceptanceError(f"{label}: geen strikte UTF-8/JSON") from exc


def read_object(path: Path) -> dict[str, Any]:
    value = strict_json_bytes(path.read_bytes(), str(path))
    if not isinstance(value, dict):
        raise AcceptanceError(f"{path}: JSON-root moet een object zijn")
    return value


def atomic_json(path: Path, value: dict[str, Any], mode: int = 0o600) -> None:
    path = path.absolute()
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=path.parent, delete=False) as handle:
        os.fchmod(handle.fileno(), mode)
        json.dump(value, handle, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
        temporary = Path(handle.name)
    os.replace(temporary, path)
    os.chmod(path, mode)


def validate_origin(raw: str) -> str:
    text = str(raw or "").strip()
    if not text or any(char in text for char in "\r\n\t"):
        raise AcceptanceError("preview-origin is leeg of bevat controltekens")
    parsed = urllib.parse.urlparse(text)
    if (
        parsed.scheme != "https"
        or not parsed.hostname
        or parsed.username
        or parsed.password
        or parsed.query
        or parsed.fragment
        or parsed.path not in {"", "/"}
        or not ORIGIN_HOST.fullmatch(parsed.hostname)
    ):
        raise AcceptanceError("preview-origin moet exact canoniek https://host[:port] zijn")
    try:
        port = parsed.port
    except ValueError as exc:
        raise AcceptanceError("preview-origin bevat een ongeldige poort") from exc
    if port is not None and not 1 <= port <= 65535:
        raise AcceptanceError("preview-originpoort valt buiten 1..65535")
    netloc = parsed.hostname.lower() + (f":{port}" if port is not None else "")
    if parsed.netloc != netloc:
        raise AcceptanceError("preview-origin is niet canoniek lowercase")
    return f"https://{netloc}"


def run_checked(arguments: list[str], *, timeout: int = 120) -> str:
    completed = subprocess.run(
        arguments,
        check=False,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=timeout,
        env={"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "PYTHONDONTWRITEBYTECODE": "1"},
    )
    if completed.returncode != 0:
        tail = "\n".join(completed.stdout.splitlines()[-20:])
        raise AcceptanceError(f"commando faalde ({completed.returncode}): {arguments[0]}\n{tail}")
    return completed.stdout.strip()


def bounded_get(url: str) -> tuple[bytes, dict[str, str]]:
    request = urllib.request.Request(url, headers={"User-Agent": "METOD-FIX30-Acceptance/1"})
    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            if int(response.status) != 200:
                raise AcceptanceError(f"HTTP {response.status}: {url}")
            declared = response.headers.get("Content-Length")
            if declared and int(declared) > MAX_HTTP_BYTES:
                raise AcceptanceError(f"HTTP-response te groot: {url}")
            data = response.read(MAX_HTTP_BYTES + 1)
            if len(data) > MAX_HTTP_BYTES:
                raise AcceptanceError(f"HTTP-response overschrijdt limiet: {url}")
            headers = {str(key).lower(): str(value) for key, value in response.headers.items()}
            return data, headers
    except AcceptanceError:
        raise
    except (urllib.error.URLError, TimeoutError, OSError, ValueError) as exc:
        raise AcceptanceError(f"HTTP-probe mislukt: {url}: {exc}") from exc


def safe_release_target(current_link: Path, releases_root: Path) -> Path:
    if not current_link.is_symlink():
        raise AcceptanceError("actieve releasepointer ontbreekt of is geen symlink")
    target = current_link.resolve(strict=True)
    releases = releases_root.resolve(strict=True)
    if target.is_symlink() or not target.is_dir() or target.parent != releases:
        raise AcceptanceError("actieve releasetarget valt buiten de directe releaseroot")
    metadata = target.stat()
    if (
        metadata.st_uid != 0
        or metadata.st_gid != 0
        or stat.S_IMODE(metadata.st_mode) != 0o555
        or metadata.st_nlink < 2
    ):
        raise AcceptanceError("actieve releasetarget is niet root:root/0555 verzegeld")
    installer = target / "INSTALL_FIX660R8_FROM_STAGE.sh"
    source = installer.read_text(encoding="utf-8", errors="strict")
    marker = f'INSTALLER_REVISION="{EXPECTED_REVISION}"'
    if source.count(marker) != 1:
        raise AcceptanceError("actieve installer bevat niet exact de FIX30-revisie")
    return target


def state_gate(release_root: Path, state_root: Path, credentials: Path) -> dict[str, int]:
    script = release_root / "tools/install_state_gate.py"
    output = run_checked([
        "/usr/bin/python3", "-I", "-S", "-B", str(script),
        "--state-root", str(state_root), "--credentials", str(credentials),
    ], timeout=180)
    lines = [line for line in output.splitlines() if line.strip()]
    if len(lines) < 2 or lines[-2] != "INSTALL STATE GATE: PASS":
        raise AcceptanceError("state gate gaf geen canonieke PASS-uitvoer")
    value = strict_json_bytes(lines[-1].encode("utf-8"), "state-gate")
    if not isinstance(value, dict) or any(type(item) is not int for item in value.values()):
        raise AcceptanceError("state gate gaf geen veilig count-object")
    return value


def health_probe(origin: str) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for endpoint in ("/health/live", "/health/ready"):
        data, _headers = bounded_get(origin + endpoint + ("?fix30=1" if origin.startswith("https://") else ""))
        value = strict_json_bytes(data, origin + endpoint)
        if not isinstance(value, dict) or value.get("ok") is not True or value.get("build") != EXPECTED_BUILD:
            raise AcceptanceError(f"ongeldige health-identiteit: {origin}{endpoint}")
        result[endpoint.rsplit("/", 1)[-1]] = {"ok": True, "build": value["build"]}
    return result


def asset_probe(preview_origin: str) -> dict[str, Any]:
    origins = {
        "backend": "http://127.0.0.1:8792",
        "localEdge": "http://127.0.0.1:8790",
        "externalPreview": preview_origin,
    }
    result: dict[str, Any] = {}
    for path in ASSET_PATHS:
        hashes: dict[str, str] = {}
        sizes: dict[str, int] = {}
        canonical_data: bytes | None = None
        for label, origin in origins.items():
            data, _headers = bounded_get(origin + path)
            hashes[label] = sha256_bytes(data)
            sizes[label] = len(data)
            if canonical_data is None:
                canonical_data = data
            elif data != canonical_data:
                raise AcceptanceError(f"assetbytes verschillen tussen backend/edge/preview: {path}")
        assert canonical_data is not None
        text = canonical_data.decode("utf-8", errors="strict")
        for marker in REQUIRED_MARKERS.get(path, ()):
            if text.count(marker) != 1:
                raise AcceptanceError(f"FIX30-marker komt niet exact eenmaal voor in {path}: {marker}")
        result[path] = {"sha256": hashes["backend"], "bytes": sizes["backend"], "originsEqual": True}
    return result


def snapshot(
    *,
    phase: str,
    release_root: Path,
    current_link: Path,
    releases_root: Path,
    state_root: Path,
    credentials: Path,
    preview_file: Path,
) -> dict[str, Any]:
    if phase not in {"pre", "post", "recovery"}:
        raise AcceptanceError("ongeldige snapshotfase")
    target = safe_release_target(current_link, releases_root)
    run_checked(["/usr/bin/systemctl", "is-active", "--quiet", "metod-pax.service"])
    run_checked(["/usr/bin/systemctl", "is-active", "--quiet", "nginx"])
    run_checked(["/usr/sbin/nginx", "-t"])
    if preview_file.is_symlink() or not preview_file.is_file():
        raise AcceptanceError("preview-URL-bestand ontbreekt of is onveilig")
    preview_metadata = preview_file.stat()
    if preview_metadata.st_uid != 0 or preview_metadata.st_nlink != 1:
        raise AcceptanceError("preview-URL-bestand is niet enkelvoudig root-owned")
    preview_origin = validate_origin(preview_file.read_text(encoding="utf-8", errors="strict"))
    counts = state_gate(release_root, state_root, credentials)
    critical_hashes: dict[str, str] = {}
    for relative in CRITICAL_STATE_FILES:
        path = state_root / relative
        if path.is_symlink() or not path.is_file():
            raise AcceptanceError(f"kritiek statebestand ontbreekt of is onveilig: {relative}")
        critical_hashes[relative] = sha256_file(path)
    release_manifest = target / "SHA256SUMS.txt"
    if release_manifest.is_symlink() or not release_manifest.is_file():
        raise AcceptanceError("actief releasechecksummanifest ontbreekt")
    health = {
        "backend": health_probe("http://127.0.0.1:8792"),
        "localEdge": health_probe("http://127.0.0.1:8790"),
        "externalPreview": health_probe(preview_origin),
    }
    assets = asset_probe(preview_origin)
    return {
        "schemaVersion": 1,
        "reportType": "fix30-vps-snapshot",
        "phase": phase,
        "observedAtUtc": utc_now().isoformat().replace("+00:00", "Z"),
        "releaseRevision": EXPECTED_REVISION,
        "releaseManifestSha256": sha256_file(release_manifest),
        "currentTargetName": target.name,
        "currentTargetMetadata": {"uid": 0, "gid": 0, "mode": "0555"},
        "previewOrigin": preview_origin,
        "services": {"metod-pax.service": "active", "nginx": "active", "nginxConfig": "valid"},
        "stateCounts": counts,
        "criticalStateHashes": critical_hashes,
        "health": health,
        "assetProof": assets,
    }


def compare_snapshots(before: dict[str, Any], after: dict[str, Any]) -> dict[str, Any]:
    if before.get("schemaVersion") != 1 or after.get("schemaVersion") != 1:
        raise AcceptanceError("snapshotversie ongeldig")
    if before.get("releaseRevision") != EXPECTED_REVISION or after.get("releaseRevision") != EXPECTED_REVISION:
        raise AcceptanceError("snapshot is niet aan FIX30 gebonden")
    if before.get("releaseManifestSha256") != after.get("releaseManifestSha256"):
        raise AcceptanceError("actief releasemanifest wijzigde tijdens acceptatieronde")
    if before.get("previewOrigin") != after.get("previewOrigin"):
        raise AcceptanceError("preview-origin wijzigde tijdens acceptatieronde")
    if before.get("criticalStateHashes") != after.get("criticalStateHashes"):
        raise AcceptanceError("kritieke externe state wijzigde tijdens acceptatieronde")
    before_counts = before.get("stateCounts")
    after_counts = after.get("stateCounts")
    if not isinstance(before_counts, dict) or not isinstance(after_counts, dict):
        raise AcceptanceError("statecountbewijs ontbreekt")
    for key in ("catalogRecords", "activeCatalogRecords", "activeAdmins"):
        if before_counts.get(key) != after_counts.get(key):
            raise AcceptanceError(f"statecontract wijzigde voor {key}")
    expected_services = {"metod-pax.service": "active", "nginx": "active", "nginxConfig": "valid"}
    if after.get("services") != expected_services:
        raise AcceptanceError("services zijn na de proef niet volledig actief")
    if before.get("assetProof") != after.get("assetProof"):
        raise AcceptanceError("publieke FIX30-assetbytes wijzigden tijdens de proef")
    for scope in ("backend", "localEdge", "externalPreview"):
        scope_health = (after.get("health") or {}).get(scope) or {}
        for endpoint in ("live", "ready"):
            item = scope_health.get(endpoint) or {}
            if item.get("ok") is not True or item.get("build") != EXPECTED_BUILD:
                raise AcceptanceError(f"healthbewijs ontbreekt na proef: {scope}/{endpoint}")
    return {
        "schemaVersion": 1,
        "reportType": "fix30-snapshot-comparison",
        "status": "PASS",
        "beforePhase": before.get("phase"),
        "afterPhase": after.get("phase"),
        "releaseManifestSha256": after["releaseManifestSha256"],
        "criticalStatePreserved": True,
        "catalogAndAdminContractPreserved": True,
        "publicAssetBytesPreserved": True,
        "servicesHealthy": True,
    }


def select_latest_backup(root: Path, max_age_days: int) -> Path:
    root = root.absolute()
    if root.is_symlink() or not root.is_dir():
        raise AcceptanceError("backuproot ontbreekt of is een symlink")
    candidates: list[Path] = []
    for item in root.iterdir():
        if not BACKUP_NAME.fullmatch(item.name):
            continue
        metadata = item.lstat()
        if item.is_symlink() or not stat.S_ISREG(metadata.st_mode) or metadata.st_nlink != 1 or metadata.st_size <= 0:
            continue
        candidates.append(item)
    if not candidates:
        raise AcceptanceError("geen veilig systeembackupbestand gevonden")
    latest = max(candidates, key=lambda path: path.stat().st_mtime_ns)
    age = utc_now() - datetime.fromtimestamp(latest.stat().st_mtime, tz=timezone.utc)
    if age < timedelta(minutes=-5) or age > timedelta(days=max(1, int(max_age_days))):
        raise AcceptanceError(f"nieuwste systeembackup is ouder dan {max_age_days} dag(en)")
    return latest


def safe_remove_restore(path: Path) -> None:
    candidate = path.absolute()
    if candidate.parent != Path("/var/tmp") or not candidate.name.startswith("metod-fix30-acceptance-restore."):
        raise AcceptanceError("restore-opruimpad valt buiten de vaste /var/tmp-scope")
    if candidate.is_symlink() or not candidate.is_dir():
        raise AcceptanceError("restore-opruimpad is geen echte directory")
    for item in candidate.rglob("*"):
        if item.is_symlink():
            raise AcceptanceError("symlink in geïsoleerde restore; opruimen geweigerd")
    shutil.rmtree(candidate)


def validate_restore(proof: dict[str, Any], output: dict[str, Any]) -> dict[str, Any]:
    required = ("backupSha256", "manifestSha256", "stateFileCount", "totalBytes")
    if proof.get("ok") is not True or output.get("ok") is not True:
        raise AcceptanceError("restore gaf geen PASS-bewijs")
    if any(proof.get(key) != output.get(key) for key in required):
        raise AcceptanceError("restore-output en duurzaam proof verschillen")
    if not re.fullmatch(r"[a-f0-9]{64}", str(proof.get("backupSha256") or "")):
        raise AcceptanceError("restorebackuphash ongeldig")
    if not re.fullmatch(r"[a-f0-9]{64}", str(proof.get("manifestSha256") or "")):
        raise AcceptanceError("restoremanifesthash ongeldig")
    if int(proof.get("stateFileCount") or 0) < 1 or int(proof.get("totalBytes") or 0) < 1:
        raise AcceptanceError("restorebewijs bevat geen echte state")
    return {
        "backupSha256": proof["backupSha256"],
        "manifestSha256": proof["manifestSha256"],
        "stateFileCount": int(proof["stateFileCount"]),
        "totalBytes": int(proof["totalBytes"]),
        "isolatedRestore": True,
        "liveStateOverwritten": False,
    }


def evidence_attachment(path: Path, root: Path) -> dict[str, Any]:
    resolved = path.resolve(strict=True)
    if path.is_symlink() or not path.is_file() or not resolved.is_relative_to(root.resolve(strict=True)):
        raise AcceptanceError(f"onveilige evidencebijlage: {path}")
    return {"path": str(resolved.relative_to(root.resolve())), "sha256": sha256_file(resolved), "bytes": resolved.stat().st_size}


def finalize(evidence_dir: Path, output_zip: Path, contract_path: Path) -> dict[str, Any]:
    evidence_dir = evidence_dir.resolve(strict=True)
    contract = read_object(contract_path)
    if contract.get("contractId") != "R9RC4_FIX30_FORMAL_ACCEPTANCE_RECOVERY":
        raise AcceptanceError("acceptatiecontractidentiteit ongeldig")
    standalone = read_object(evidence_dir / "standalone.json")
    if standalone.get("status") != "PASS" or standalone.get("artifactSha256") != EXPECTED_INNER_SHA256:
        raise AcceptanceError("standalone artifactbewijs is niet PASS/FIX30")
    pre = read_object(evidence_dir / "pre-snapshot.json")
    post = read_object(evidence_dir / "post-snapshot.json")
    recovery = read_object(evidence_dir / "recovery-snapshot.json")
    deployment = read_object(evidence_dir / "deploy-comparison.json")
    recovery_comparison = read_object(evidence_dir / "recovery-comparison.json")
    if deployment.get("status") != "PASS" or recovery_comparison.get("status") != "PASS":
        raise AcceptanceError("snapshotvergelijking is niet PASS")
    restore = validate_restore(
        read_object(evidence_dir / "restore-proof.json"),
        read_object(evidence_dir / "restore-output.json"),
    )
    attachments = [
        evidence_attachment(path, evidence_dir)
        for path in sorted(evidence_dir.iterdir(), key=lambda item: item.name)
        if path.is_file() and path.name != "FIX30_ACCEPTANCE_RECOVERY_REPORT.json"
    ]
    report = {
        "schemaVersion": 1,
        "reportType": "candidate-vps-acceptance-recovery",
        "status": "PASS",
        "contractId": contract["contractId"],
        "subjectRelease": EXPECTED_REVISION,
        "subjectOuterSha256": EXPECTED_OUTER_SHA256,
        "subjectInnerSha256": EXPECTED_INNER_SHA256,
        "observedAtUtc": utc_now().isoformat().replace("+00:00", "Z"),
        "checks": [
            {"id": check_id, "status": "PASS"}
            for check_id in contract.get("requiredChecks", [])
        ],
        "stateSummary": {
            "before": pre.get("stateCounts"),
            "after": post.get("stateCounts"),
            "afterRecoveryTest": recovery.get("stateCounts"),
            "criticalStateBytePreserved": True,
        },
        "restoreSummary": restore,
        "previewOrigin": recovery.get("previewOrigin"),
        "attachments": attachments,
        "productionGo": False,
        "releaseEligible": False,
        "remainingExternalGates": contract.get("remainingExternalGates", []),
        "scopeLimit": "PASS bewijst exact FIX30 op deze staging-VPS en een echte geïsoleerde backuprestore; dit is geen productie-GO.",
    }
    report_path = evidence_dir / "FIX30_ACCEPTANCE_RECOVERY_REPORT.json"
    atomic_json(report_path, report, mode=0o600)
    attachments.append(evidence_attachment(report_path, evidence_dir))
    output_zip = output_zip.absolute()
    output_zip.parent.mkdir(parents=True, exist_ok=True)
    temporary = output_zip.with_name(f".{output_zip.name}.{os.getpid()}.tmp")
    with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in sorted(evidence_dir.iterdir(), key=lambda item: item.name):
            if path.is_symlink() or not path.is_file():
                raise AcceptanceError(f"onveilige evidence tijdens verpakking: {path.name}")
            archive.write(path, arcname=f"FIX30_ACCEPTANCE_RECOVERY_EVIDENCE/{path.name}")
    os.replace(temporary, output_zip)
    os.chmod(output_zip, 0o644)
    return {"report": report, "reportPath": str(report_path), "evidenceZip": str(output_zip), "evidenceZipSha256": sha256_file(output_zip)}


def main() -> int:
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="command", required=True)

    snapshot_parser = subparsers.add_parser("snapshot")
    snapshot_parser.add_argument("--phase", choices=("pre", "post", "recovery"), required=True)
    snapshot_parser.add_argument("--release-root", type=Path, required=True)
    snapshot_parser.add_argument("--current-link", type=Path, default=Path("/opt/adzaagt/metod-pax-current"))
    snapshot_parser.add_argument("--releases-root", type=Path, default=Path("/opt/adzaagt/metod-pax-releases"))
    snapshot_parser.add_argument("--state-root", type=Path, default=Path("/var/lib/metod-pax"))
    snapshot_parser.add_argument("--credentials", type=Path, default=Path("/etc/adzaagt/metod-pax/admin_credentials.live.json"))
    snapshot_parser.add_argument("--preview-file", type=Path, default=Path("/etc/adzaagt/metod-pax/preview-url"))
    snapshot_parser.add_argument("--output", type=Path, required=True)

    compare_parser = subparsers.add_parser("compare")
    compare_parser.add_argument("--before", type=Path, required=True)
    compare_parser.add_argument("--after", type=Path, required=True)
    compare_parser.add_argument("--output", type=Path, required=True)

    backup_parser = subparsers.add_parser("select-backup")
    backup_parser.add_argument("--root", type=Path, default=Path("/var/lib/metod-pax/backups"))
    backup_parser.add_argument("--max-age-days", type=int, default=7)

    remove_parser = subparsers.add_parser("remove-restore")
    remove_parser.add_argument("path", type=Path)

    finalize_parser = subparsers.add_parser("finalize")
    finalize_parser.add_argument("--evidence-dir", type=Path, required=True)
    finalize_parser.add_argument("--output-zip", type=Path, required=True)
    finalize_parser.add_argument("--contract", type=Path, required=True)
    finalize_parser.add_argument("--json-output", type=Path, required=True)

    args = parser.parse_args()
    if args.command == "snapshot":
        value = snapshot(
            phase=args.phase,
            release_root=args.release_root,
            current_link=args.current_link,
            releases_root=args.releases_root,
            state_root=args.state_root,
            credentials=args.credentials,
            preview_file=args.preview_file,
        )
        atomic_json(args.output, value)
        print(json.dumps(value, ensure_ascii=False, sort_keys=True))
    elif args.command == "compare":
        value = compare_snapshots(read_object(args.before), read_object(args.after))
        atomic_json(args.output, value)
        print(json.dumps(value, ensure_ascii=False, sort_keys=True))
    elif args.command == "select-backup":
        print(select_latest_backup(args.root, args.max_age_days))
    elif args.command == "remove-restore":
        safe_remove_restore(args.path)
        print("ISOLATED_RESTORE_REMOVED")
    elif args.command == "finalize":
        value = finalize(args.evidence_dir, args.output_zip, args.contract)
        atomic_json(args.json_output, value)
        print(json.dumps(value, ensure_ascii=False, sort_keys=True))
    else:
        raise AcceptanceError("onbekend commando")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (AcceptanceError, OSError, subprocess.SubprocessError, zipfile.BadZipFile) as exc:
        print(f"FIX30 ACCEPTANCE FAILED: {exc}", file=sys.stderr)
        raise SystemExit(1)
