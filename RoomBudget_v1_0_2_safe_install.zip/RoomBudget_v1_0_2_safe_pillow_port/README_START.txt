RoomBudget v1.0.1 auto install

This build installs as a separate VPS service:
- service: roombudget.service
- folder: /opt/roombudget
- port: 8899 by default

It does not stop or modify other tools/services.
AI provider is mock by default, so no AI API costs are made.

One-command install after uploading the ZIP to /home/ubuntu:

cd /home/ubuntu && rm -rf /tmp/roombudget_auto_install && mkdir -p /tmp/roombudget_auto_install && unzip -q -o RoomBudget_v1_0_1_auto_install.zip -d /tmp/roombudget_auto_install && cd "$(find /tmp/roombudget_auto_install -maxdepth 3 -type f -name install.sh -printf '%h\n' | head -1)" && chmod +x install.sh && ROOMBUDGET_PORT=8899 ./install.sh

Check:
sudo systemctl status roombudget.service --no-pager -l
curl http://127.0.0.1:8899/health
