import React, { useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { Compass, Flame, Home, Search, Sparkles, TrendingUp } from 'lucide-react';
import { EmptyState, TopBar } from './Layout';

const STYLES = ['Alles', 'Japandi', 'Hotel chique', 'Mediterraan', 'Industrieel', 'Budget', 'Klein wonen'];

function matchesStyle(item, style) {
  if (style === 'Alles') return true;
  return `${item.title || ''} ${item.name || ''} ${item.style_text || ''} ${item.room_type || ''}`.toLowerCase().includes(style.toLowerCase().split(' ')[0]);
}

export function Discover({ auth, openHome, openRoom }) {
  const [data, setData] = useState({ homes: [], rooms: [], updates: [] });
  const [query, setQuery] = useState('');
  const [style, setStyle] = useState('Alles');

  async function load() {
    try {
      await fetch('/api/seed-demo', { method: 'POST', cache: 'no-store' });
      const result = await auth.req('/api/discover');
      setData(result || { homes: [], rooms: [], updates: [] });
    } catch {
      try {
        const homes = await auth.req('/api/homes');
        setData({ homes, rooms: [], updates: [] });
      } catch { setData({ homes: [], rooms: [], updates: [] }); }
    }
  }

  useEffect(() => { load(); }, []);

  const q = query.trim().toLowerCase();
  const homes = useMemo(() => data.homes.filter((home) => matchesStyle(home, style) && `${home.title} ${home.description} ${home.style_text}`.toLowerCase().includes(q)), [data.homes, q, style]);
  const rooms = useMemo(() => data.rooms.filter((room) => matchesStyle(room, style) && `${room.name} ${room.home_title} ${room.style_text} ${room.latest_phase}`.toLowerCase().includes(q)), [data.rooms, q, style]);
  const updates = useMemo(() => data.updates.filter((update) => matchesStyle(update.home || {}, style) && `${update.caption} ${update.phase_label} ${update.room?.name} ${update.home?.title}`.toLowerCase().includes(q)), [data.updates, q, style]);

  return (
    <main className="screen discover-v9">
      <TopBar title="Ontdekken" subtitle="Vind kamers, huizen en stijlen" />

      <section className="discover-hero-v9">
        <div><Compass size={20} /><span>Roomarc Discovery</span></div>
        <h1>Ontdek kamers die echt groeien.</h1>
        <p>Zoek op stijl, open een huisprofiel of spring direct naar een kamer-tijdlijn.</p>
      </section>

      <section className="search-card search-card--v9">
        <Search size={18} />
        <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Zoek Japandi, keuken, loft..." />
      </section>

      <div className="style-filter-v9">
        {STYLES.map((item) => <button key={item} onClick={() => setStyle(item)} className={style === item ? 'active' : ''}>{item}</button>)}
      </div>

      <section className="metric-row-v9">
        <div><strong>{data.homes.length}</strong><span>Huizen</span></div>
        <div><strong>{data.rooms.length}</strong><span>Kamers</span></div>
        <div><strong>{data.updates.length}</strong><span>Updates</span></div>
      </section>

      <div className="section-title"><span>Populair deze week</span><small>{homes.length} homes</small></div>
      <div className="home-grid home-grid--v9">
        {homes.slice(0, 6).map((home) => (
          <motion.button className="home-tile home-tile--v9" whileTap={{ scale: 0.98 }} onClick={() => openHome(home.slug)} key={home.id}>
            <img src={home.cover_url} alt={home.title} />
            <em><TrendingUp size={13} /> {home.followers || 0} volgers</em>
            <strong>{home.title}</strong>
            <span>{home.rooms} kamers · {home.updates} updates</span>
          </motion.button>
        ))}
      </div>

      <div className="section-title"><span>Kamer-tijdlijnen</span><small>Open direct</small></div>
      <div className="room-discover-list-v9">
        {rooms.slice(0, 8).map((room) => (
          <motion.button whileTap={{ scale: 0.985 }} className="room-discover-card-v9" key={room.id} onClick={() => openRoom?.(room.id)}>
            <img src={room.cover_url} alt={room.name} />
            <div>
              <small>{room.home_title}</small>
              <strong>{room.name}</strong>
              <span>{room.updates} fases · laatste: {room.latest_phase || 'Nieuwe update'}</span>
            </div>
          </motion.button>
        ))}
      </div>

      <div className="section-title"><span>Nieuwe updates</span><small>Net geplaatst</small></div>
      <div className="mini-update-grid-v9">
        {updates.slice(0, 6).map((update) => (
          <button key={update.id} onClick={() => openRoom?.(update.room.id)}>
            <img src={update.media_url} alt={update.phase_label} />
            <span>{update.phase_label}</span>
          </button>
        ))}
      </div>

      {!homes.length && !rooms.length ? <EmptyState title="Nog niets gevonden" text="Probeer een andere stijl of maak je eerste huisprofiel in Studio." /> : null}
    </main>
  );
}
