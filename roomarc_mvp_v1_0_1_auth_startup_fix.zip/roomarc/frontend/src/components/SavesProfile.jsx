import React, { useEffect, useState } from 'react';
import { EmptyState, TopBar } from './Layout';

export function Saves({ auth, openRoom }) {
  const [items, setItems] = useState([]);
  useEffect(() => { auth.req('/api/me/saves').then(setItems).catch(() => setItems([])); }, []);

  return (
    <main className="screen">
      <TopBar title="Bewaard" subtitle="Je inspiratie" />
      <div className="save-grid">{items.map((item) => <button key={item.id} onClick={() => openRoom(item.room.id)}><img src={item.media_url} alt={item.phase_label} /></button>)}</div>
      {!items.length ? <EmptyState title="Nog niets bewaard" text="Bewaar kamerupdates uit de feed om ze hier terug te vinden." /> : null}
    </main>
  );
}

export function Profile({ auth }) {
  return (
    <main className="screen">
      <TopBar title="Profiel" subtitle="Jouw Roomarc-account" />
      <section className="profile-card">
        <div className="profile-avatar">R</div>
        <h2>{auth.me?.display_name}</h2>
        <p>@{auth.me?.username}</p>
        <div className="version-card"><strong>ROOMARC v1.0.1</strong><span>Signature Experience: Timeline 3.0, Voor/Na, Room Journey en stabiele auth-start zonder 401-feedcall.</span></div>
        <button className="primary-button" onClick={auth.logout}>Uitloggen</button>
      </section>
    </main>
  );
}
