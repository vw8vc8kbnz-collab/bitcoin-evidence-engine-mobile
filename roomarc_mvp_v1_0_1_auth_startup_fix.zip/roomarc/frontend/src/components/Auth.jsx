import React from 'react';
import { Bookmark, House, Layers } from 'lucide-react';
import { motion } from 'framer-motion';

export function Splash() {
  return (
    <motion.div className="splash" initial={{ opacity: 1 }} animate={{ opacity: 0 }} transition={{ delay: 1.05, duration: 0.55 }}>
      <motion.div initial={{ opacity: 0, scale: 0.96, y: 10 }} animate={{ opacity: 1, scale: 1, y: 0 }} transition={{ duration: 0.75 }}>
        <div className="brandmark">⌂</div>
        <h1>ROOMARC</h1>
        <p>Waar interieurs groeien.</p>
      </motion.div>
    </motion.div>
  );
}

export function Login({ auth }) {
  return (
    <main className="login-screen">
      <div className="login-screen__bg" />
      <section className="login-card">
        <div className="brandmark brandmark--dark">⌂</div>
        <h1>ROOMARC</h1>
        <p>Maak een profiel van je huis. Volg echte kamers en zie interieurs stap voor stap veranderen.</p>
      </section>
      <section className="login-bullets">
        <motion.div className="onboarding-card" initial={{ x: 20, opacity: 0 }} animate={{ x: 0, opacity: 1 }}>
          <House size={18} /> Bouw een huisprofiel met kamers.
        </motion.div>
        <motion.div className="onboarding-card" initial={{ x: 20, opacity: 0 }} animate={{ x: 0, opacity: 1 }} transition={{ delay: 0.08 }}>
          <Layers size={18} /> Volg kamers, niet alleen mensen.
        </motion.div>
        <motion.div className="onboarding-card" initial={{ x: 20, opacity: 0 }} animate={{ x: 0, opacity: 1 }} transition={{ delay: 0.16 }}>
          <Bookmark size={18} /> Bewaar inspiratie uit echte huizen.
        </motion.div>
      </section>
      <button className="primary-button" onClick={() => auth.login()}>Open demo-app</button>
      <small className="demo-hint">Demo-login: demo@roomarc.local / demo123</small>
    </main>
  );
}
