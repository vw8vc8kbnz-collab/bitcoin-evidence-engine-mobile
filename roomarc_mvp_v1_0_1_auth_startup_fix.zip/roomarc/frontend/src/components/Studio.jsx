import React, { useEffect, useState } from 'react';
import { Camera, Check, House, ImagePlus, Layers, Sparkles, SplitSquareHorizontal } from 'lucide-react';
import { DEFAULT_COVER, DEFAULT_ROOM } from '../data/fallback';
import { TopBar } from './Layout';

const PHASES = ['Startpunt', 'Vloer gelegd', 'Muren afgerond', 'Meubels geplaatst', 'Gestyled', 'Voor/na'];

function StudioHome({ setMode }) {
  const cards = [
    ['update', Camera, 'Plaats kamerupdate', 'Voeg een nieuwe fase toe aan een kamer-tijdlijn.'],
    ['room', Layers, 'Maak nieuwe kamer', 'Start een ruimte die mensen apart kunnen volgen.'],
    ['before', SplitSquareHorizontal, 'Start before/after', 'Leg een transformatie vast.'],
    ['home', House, 'Maak huisprofiel', 'Bouw je eigen interieurpagina.'],
  ];
  return (
    <main className="screen studio-screen">
      <TopBar title="Roomarc Studio" subtitle="Maak je huis, kamer of update" />
      <section className="studio-hero">
        <span>Studio</span>
        <h1>Wat wil je maken?</h1>
        <p>Begin simpel. Kies één actie en Roomarc bouwt de juiste flow eromheen.</p>
      </section>
      <section className="studio-grid">
        {cards.map(([mode, Icon, title, text]) => (
          <button className="studio-card" key={mode} onClick={() => setMode(mode)}>
            <Icon size={24} />
            <strong>{title}</strong>
            <span>{text}</span>
          </button>
        ))}
      </section>
    </main>
  );
}

function UpdateComposer({ auth, onBack, onPosted }) {
  const [homes, setHomes] = useState([]);
  const [rooms, setRooms] = useState([]);
  const [homeId, setHomeId] = useState('');
  const [roomId, setRoomId] = useState('');
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState('');
  const [phase, setPhase] = useState('');
  const [caption, setCaption] = useState('');
  const [status, setStatus] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    auth.req('/api/homes').then((data) => {
      setHomes(data);
      if (data[0]) setHomeId(data[0].id);
    }).catch(() => setHomes([]));
  }, []);

  useEffect(() => {
    const selected = homes.find((home) => home.id === homeId);
    if (!selected) return;
    auth.req(`/api/homes/${selected.slug}`).then((detail) => {
      setRooms(detail.rooms || []);
      if (detail.rooms?.[0]) setRoomId(detail.rooms[0].id);
    }).catch(() => setRooms([]));
  }, [homeId, homes.length]);

  function pickFile(event) {
    const selected = event.target.files?.[0];
    if (!selected) return;
    setFile(selected);
    setPreview(URL.createObjectURL(selected));
  }

  async function submit() {
    if (!file || !roomId || !phase || !caption.trim()) {
      setStatus('Kies een foto, kamer, fase en korte update.');
      return;
    }
    setBusy(true);
    try {
      setStatus('Foto uploaden...');
      const form = new FormData();
      form.append('file', file);
      const uploaded = await auth.req('/api/media/upload', { method: 'POST', body: form });
      setStatus('Update publiceren...');
      await auth.req(`/api/rooms/${roomId}/updates`, { method: 'POST', body: JSON.stringify({ media_url: uploaded.url, caption, phase_label: phase }) });
      setStatus('Geplaatst. Je update staat nu in de feed en tijdlijn.');
      onPosted?.();
    } catch (error) {
      setStatus(`Upload mislukt: ${error.message}`);
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="screen studio-screen composer-screen">
      <button className="mini-back" onClick={onBack}>← Studio</button>
      <section className="composer-head">
        <span>Kamerupdate</span>
        <h1>Nieuwe fase</h1>
        <p>Foto eerst. Daarna kies je kamer, fase en verhaal.</p>
      </section>
      <label className="media-picker">
        <input type="file" accept="image/*" onChange={pickFile} />
        {preview ? <img src={preview} alt="Preview" /> : <div><ImagePlus size={36} /><strong>Kies je beste kamerfoto</strong><span>Tik om een foto vanaf je iPhone toe te voegen.</span></div>}
      </label>
      <section className="composer-card">
        <div className="guide-box"><Sparkles size={17} /><p>Deze update verschijnt op de tijdlijn van de gekozen kamer. Volgers zien de nieuwe fase in hun feed.</p></div>
        <label>Huis<select value={homeId} onChange={(event) => setHomeId(event.target.value)}>{homes.map((home) => <option value={home.id} key={home.id}>{home.title}</option>)}</select></label>
        <label>Kamer<select value={roomId} onChange={(event) => setRoomId(event.target.value)}>{rooms.map((room) => <option value={room.id} key={room.id}>{room.name}</option>)}</select></label>
        <div className="field-block"><span>Kies fase</span><div className="phase-chips">{PHASES.map((item) => <button className={phase === item ? 'active' : ''} key={item} onClick={() => setPhase(item)} type="button">{item}</button>)}</div></div>
        <label>Wat is er veranderd?<textarea value={caption} onChange={(event) => setCaption(event.target.value)} placeholder="Bijv. De vloer ligt erin en de kamer voelt direct warmer." /></label>
        <section className="feed-preview">
          <small>Preview in feed</small>
          <strong>{phase || 'Nieuwe fase'}</strong>
          <p>{caption || 'Schrijf kort wat er veranderd is.'}</p>
        </section>
        {status ? <p className="status-message">{status}</p> : null}
        <button className="primary-button full" disabled={busy} onClick={submit}>{busy ? 'Publiceren...' : 'Publiceer naar tijdlijn'}</button>
      </section>
    </main>
  );
}

function RoomComposer({ auth, onBack }) {
  const [homes, setHomes] = useState([]);
  const [homeId, setHomeId] = useState('');
  const [name, setName] = useState('');
  const [type, setType] = useState('');
  const [cover, setCover] = useState('');
  const [status, setStatus] = useState('');

  useEffect(() => {
    auth.req('/api/homes').then((data) => { setHomes(data); if (data[0]) setHomeId(data[0].id); });
  }, []);

  async function submit() {
    try {
      await auth.req(`/api/homes/${homeId}/rooms`, { method: 'POST', body: JSON.stringify({ name, room_type: type, cover_url: cover || DEFAULT_ROOM }) });
      setStatus('Kamer aangemaakt. Plaats nu de eerste update om de tijdlijn te starten.');
      setName(''); setType(''); setCover('');
    } catch (error) { setStatus(`Mislukt: ${error.message}`); }
  }

  return (
    <main className="screen studio-screen composer-screen">
      <button className="mini-back" onClick={onBack}>← Studio</button>
      <section className="composer-card standalone">
        <h1>Nieuwe kamer</h1>
        <p>Start een ruimte die bezoekers los kunnen volgen.</p>
        <label>Kamernaam<input value={name} onChange={(event) => setName(event.target.value)} placeholder="Bijv. Woonkamer" /></label>
        <label>Kamertype<input value={type} onChange={(event) => setType(event.target.value)} placeholder="Keuken, slaapkamer, badkamer..." /></label>
        <label>Huis<select value={homeId} onChange={(event) => setHomeId(event.target.value)}>{homes.map((home) => <option value={home.id} key={home.id}>{home.title}</option>)}</select></label>
        <label>Cover URL optioneel<input value={cover} onChange={(event) => setCover(event.target.value)} placeholder="Mag leeg blijven" /></label>
        <button className="primary-button full" onClick={submit}>Maak kamer</button>
        {status ? <p className="status-message">{status}</p> : null}
      </section>
    </main>
  );
}

function HomeComposer({ auth, onBack }) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [style, setStyle] = useState('');
  const [cover, setCover] = useState('');
  const [status, setStatus] = useState('');

  async function submit() {
    try {
      await auth.req('/api/homes', { method: 'POST', body: JSON.stringify({ title: title || 'Mijn Roomarc huis', description, style_text: style, cover_url: cover || DEFAULT_COVER }) });
      setStatus('Huisprofiel aangemaakt. Voeg nu kamers toe vanuit Studio.');
    } catch (error) { setStatus(`Mislukt: ${error.message}`); }
  }

  return (
    <main className="screen studio-screen composer-screen">
      <button className="mini-back" onClick={onBack}>← Studio</button>
      <section className="composer-card standalone">
        <h1>Maak huisprofiel</h1>
        <p>Denk aan dit scherm als je Instagram-profiel, maar dan voor je huis.</p>
        <div className="profile-preview"><img src={cover || DEFAULT_COVER} /><div><strong>{title || 'Jouw huisnaam'}</strong><span>{style || 'Stijlrichting'} · @roomarc</span><p>{description || 'Korte bio over je interieur, verbouwing of stijl.'}</p></div></div>
        <label>Naam<input value={title} onChange={(event) => setTitle(event.target.value)} placeholder="Bijv. Villa Rutte" /></label>
        <label>Bio<textarea value={description} onChange={(event) => setDescription(event.target.value)} placeholder="Vertel kort over je huis/interieur." /></label>
        <label>Stijl<input value={style} onChange={(event) => setStyle(event.target.value)} placeholder="Japandi, hotel chique, minimal..." /></label>
        <label>Cover URL optioneel<input value={cover} onChange={(event) => setCover(event.target.value)} placeholder="Mag leeg blijven" /></label>
        <div className="guide-box"><Check size={17} /><p>Later maken we dit inline: direct op je profiel cover wijzigen, bio tikken en kamers slepen.</p></div>
        <button className="primary-button full" onClick={submit}>Bewaar huisprofiel</button>
        {status ? <p className="status-message">{status}</p> : null}
      </section>
    </main>
  );
}

function BeforeAfter({ onBack }) {
  return (
    <main className="screen studio-screen composer-screen">
      <button className="mini-back" onClick={onBack}>← Studio</button>
      <section className="composer-card standalone center-card">
        <SplitSquareHorizontal size={42} />
        <h1>Before/after</h1>
        <p>De volgende stap wordt een echte slider: links voor, rechts na, met fases en producttags. Voor nu kun je via kamerupdate alvast ‘Voor/na’ kiezen.</p>
        <div className="fake-slider"><span>Voor</span><i /><span>Na</span></div>
        <button className="primary-button full" onClick={onBack}>Terug naar Studio</button>
      </section>
    </main>
  );
}

export function Studio({ auth, onPosted }) {
  const [mode, setMode] = useState('home');
  if (mode === 'update') return <UpdateComposer auth={auth} onBack={() => setMode('home')} onPosted={onPosted} />;
  if (mode === 'room') return <RoomComposer auth={auth} onBack={() => setMode('home')} />;
  if (mode === 'homeProfile') return <HomeComposer auth={auth} onBack={() => setMode('home')} />;
  if (mode === 'before') return <BeforeAfter onBack={() => setMode('home')} />;
  return <StudioHome setMode={(next) => setMode(next === 'home' ? 'homeProfile' : next)} />;
}
