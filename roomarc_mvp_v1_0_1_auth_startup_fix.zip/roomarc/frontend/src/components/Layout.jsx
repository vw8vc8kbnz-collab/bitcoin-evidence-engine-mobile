import React from 'react';
import { Bookmark, Compass, Home, Plus, Search, User } from 'lucide-react';

export function TopBar({ title = 'ROOMARC', subtitle = '', children }) {
  return (
    <header className="topbar">
      <div>
        <strong>{title}</strong>
        {subtitle ? <small>{subtitle}</small> : null}
      </div>
      <div className="topbar__actions">
        {children || <Search size={22} />}
        <span className="accent-dot" />
      </div>
    </header>
  );
}

export function BottomNav({ active, setActive }) {
  const items = [
    ['feed', Home, 'Volgend'],
    ['discover', Compass, 'Ontdekken'],
    ['create', Plus, 'Studio'],
    ['saves', Bookmark, 'Bewaard'],
    ['profile', User, 'Profiel'],
  ];

  return (
    <nav className="bottom-nav" aria-label="Hoofdnavigatie">
      {items.map(([key, Icon, label]) => (
        <button
          key={key}
          type="button"
          className={active === key ? 'active' : ''}
          onClick={() => setActive(key)}
        >
          <Icon size={22} strokeWidth={active === key ? 2.6 : 2.2} />
          <span>{label}</span>
        </button>
      ))}
    </nav>
  );
}

export function EmptyState({ title, text, action }) {
  return (
    <section className="empty-state">
      <span className="empty-state__spark">✦</span>
      <strong>{title}</strong>
      <p>{text}</p>
      {action}
    </section>
  );
}
