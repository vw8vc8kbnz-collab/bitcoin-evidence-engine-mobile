ROOMARC MVP v1.0.0 — Social discovery polish

Installeren/updaten op VPS:

cd ~ && rm -rf roomarc-src roomarc-unpack roomarc && git clone https://github.com/vw8vc8kbnz-collab/bitcoin-evidence-engine-mobile.git roomarc-src && mkdir -p roomarc-unpack && unzip -oq roomarc-src/roomarc_mvp_v0_9_0_social_discovery.zip -d roomarc-unpack && bash roomarc-unpack/install_roomarc.sh

Open:
http://SERVER-IP:8899

Demo-login:
demo@roomarc.local
demo123

Nieuw in v1.0.0:
- Ontdekken 2.0 met stijlfilters en betere social discovery.
- Populaire huizen, kamer-tijdlijnen en nieuwe updates.
- Publieke home profiles met sterkere social proof.
- Bewaard-tab meer als inspiratiecollectie.
- Extra voorbeeldkamers/huizen blijven via demo seed beschikbaar.


ROOMARC v1.0.0 SIGNATURE EXPERIENCE
- Timeline 3.0 with milestone rail and signature scrub.
- Before/after compare slider built from first and latest room update.
- Room Journey tab with updates, days and transformation score.
- Premium dark immersive motion layer for room pages.
