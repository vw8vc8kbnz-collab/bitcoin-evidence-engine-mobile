#!/usr/bin/env bash
set -euo pipefail
SRC_DIR="$(cd "$(dirname "$0")" && pwd)"
TARGET="${ROOMARC_TARGET:-$HOME/roomarc}"
echo "============================================================"
echo "ROOMARC v1.0.1 auto deployer"
echo "============================================================"
echo "Source: $SRC_DIR"
echo "Target: $TARGET"
if [ ! -d "$SRC_DIR/roomarc" ]; then
  echo "ERROR: expected $SRC_DIR/roomarc inside extracted ZIP." >&2
  exit 1
fi
rm -rf "$TARGET"
mkdir -p "$TARGET"
cp -a "$SRC_DIR/roomarc" "$TARGET/roomarc"
cd "$TARGET/roomarc"
# Preserve database and uploaded media across redeploys.
DATA_DIR="${ROOMARC_DATA_DIR:-$HOME/roomarc_data}"
mkdir -p "$DATA_DIR/media"
cp .env.example .env
if command -v python3 >/dev/null 2>&1; then
  SECRET="$(python3 - <<'PY'
import secrets
print(secrets.token_urlsafe(32))
PY
)"
else
  SECRET="roomarc-dev-secret"
fi
cat > .env <<EOF
ROOMARC_ENV=development
ROOMARC_HOST=0.0.0.0
ROOMARC_PORT=8899
DATABASE_URL=sqlite:///$DATA_DIR/roomarc.db
JWT_SECRET=$SECRET
MEDIA_BACKEND=local
MEDIA_DIR=$DATA_DIR/media
FRONTEND_DIST=frontend/dist
EOF
chmod +x scripts/*.sh
./scripts/install.sh
echo "============================================================"
echo "Install complete. Starting Roomarc..."
echo "URL: http://SERVER-IP:8899"
echo "Demo: demo@roomarc.local / demo123
Persistent data: ${ROOMARC_DATA_DIR:-$HOME/roomarc_data}"
echo "Press CTRL+C to stop."
echo "============================================================"
exec ./scripts/run_dev.sh
