#!/usr/bin/env bash
set -euo pipefail
APP_ROOT="/home/ubuntu/bitcoin-engine-deploy/current"
LAB="$APP_ROOT/alphalab"
SERVICE_SRC="$LAB/scripts/alpha-lab.service"
SERVICE_DST="/etc/systemd/system/alpha-lab.service"
PORT="${ALPHA_LAB_PORT:-8000}"

echo "=== Installing BEE Alpha Lab webserver ==="

# 1. Vraag/zet de toegangssleutel
read -p "Kies een toegangssleutel (wachtwoord voor de webapp): " KEY
if [ -z "$KEY" ]; then echo "ERROR: lege sleutel niet toegestaan"; exit 1; fi

echo "[1/7] Check bestanden..."
[ -f "$LAB/bee_alpha_lab_server.py" ] || { echo "ERROR: server niet gevonden"; exit 1; }
[ -f "$LAB/bee_alpha_lab.html" ] || { echo "ERROR: frontend niet gevonden"; exit 1; }

echo "[2/7] Check pandas/numpy beschikbaar..."
python3 -c "import pandas, numpy" || { echo "ERROR: pip install pandas numpy --break-system-packages"; exit 1; }

echo "[3/7] Service-file klaarzetten met jouw sleutel..."
sudo cp "$SERVICE_SRC" "$SERVICE_DST"
sudo sed -i "s/CHANGE_THIS_KEY/$KEY/" "$SERVICE_DST"
sudo chmod 644 "$SERVICE_DST"

echo "[4/7] Firewall: poort $PORT openzetten..."
if command -v ufw >/dev/null 2>&1; then
  sudo ufw allow ${PORT}/tcp || true
  echo "  ufw: poort $PORT toegestaan."
else
  echo "  Geen ufw gevonden. LET OP: check of je VPS-provider poort $PORT openzet in hun control panel (security groups / firewall)."
fi

echo "[5/7] Systemd reload + enable..."
sudo systemctl daemon-reload
sudo systemctl enable alpha-lab.service

echo "[6/7] Start service..."
sudo systemctl restart alpha-lab.service
sleep 3

echo "[7/7] Verify..."
if ! sudo systemctl is-active --quiet alpha-lab.service; then
  echo "ERROR: service niet actief."
  sudo journalctl -u alpha-lab.service -n 40 --no-pager || true
  exit 1
fi

IP=$(curl -s ifconfig.me 2>/dev/null || echo "<vps-ip>")
echo ""
echo "Alpha Lab draait. Open in je browser:"
echo "  http://$IP:$PORT/?key=$KEY"
echo ""
echo "Als de pagina niet laadt: poort $PORT staat waarschijnlijk dicht bij je"
echo "VPS-provider. Open hem in hun firewall/security-groups paneel."
echo ""
echo "Status:  sudo systemctl status alpha-lab"
echo "Log:     tail -f $LAB/alpha-lab.log"
