# BEE Alpha Lab — installatie

De visuele hypothese-validator die ECHT op 8 jaar data rekent (walk-forward,
overlap-correctie, fees). Draait als webserver op de VPS, naast je daemon.

## Installeren (na uitpakken via je normale GitHub/Termius update)

```
cd /home/ubuntu/bitcoin-engine-deploy/current
chmod +x alphalab/scripts/install_alpha_lab.sh
./alphalab/scripts/install_alpha_lab.sh
```

Het script vraagt om een toegangssleutel (een wachtwoord dat je zelf kiest),
zet de service op, opent de poort, en print de URL.

## Openen

In je telefoon-browser:
```
http://<vps-ip>:8000/?key=<jouw-sleutel>
```
Het script print de exacte URL aan het eind.

## Als de pagina niet laadt

Bijna altijd de firewall. Volgorde van checken:
1. Draait de service?  `sudo systemctl status alpha-lab`  -> moet "active (running)"
2. Lokaal op de server: `curl -s "http://localhost:8000/?key=<sleutel>" -o /dev/null -w "%{http_code}"` -> moet 200
   - Werkt lokaal wel maar extern niet = poort dicht bij je VPS-provider.
3. Open poort 8000 in het control panel van je VPS-provider (security groups / firewall).

## Belangrijk

- Dit raakt je daemon/baseline NIET aan. Aparte service, eigen map.
- De cijfers zijn ECHT (walk-forward op de candle-CSV), geen schatting.
- De multiple-testing-teller bovenaan bewaakt dat je niet jezelf voor de gek houdt
  door honderd combinaties te proberen tot er een mooi lijkt.
- Een "ECHTE EDGE" verdict = waard om paper-only live te zetten, daarna is de
  live track record de uiteindelijke rechter.
