#!/usr/bin/env bash
set -euo pipefail
for f in server.py engine.py install.sh run_backtest.sh requirements.txt deepseek_prompt.md VERSION; do
  test -f "$f" || { echo "missing $f"; exit 1; }
done
python3 -m py_compile server.py engine.py
python3 - <<'PYSELF'
import re, pathlib
expected=pathlib.Path('VERSION').read_text().strip()
for file in ['server.py','engine.py']:
    txt=pathlib.Path(file).read_text()
    m=re.search(r"VERSION=['\"]([^'\"]+)['\"]", txt)
    if not m or m.group(1)!=expected:
        raise SystemExit(f"VERSION mismatch in {file}: {m.group(1) if m else 'missing'} != {expected}")
print('[SEE selftest] version markers OK')
PYSELF
echo '[SEE selftest] OK'
