# Stock Evidence Engine v1.8.5

Careful rebuild after bad v1.8.4 package.

Fixes:
- All runtime version markers now v1.8.5.
- Selftest fails on server.py / engine.py / VERSION mismatch.
- Bad ticker loader remains enabled: retry, skip, ticker health logs.
- LAZR removed from default universe.
- AI_ELITE and QUANT_ELITE remain separated.
- DeepSeek remains linked to market data, price reaction, news, theme and regime.
