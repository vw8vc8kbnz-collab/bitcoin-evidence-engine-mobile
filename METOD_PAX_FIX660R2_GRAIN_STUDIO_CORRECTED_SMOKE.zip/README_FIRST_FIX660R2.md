# METOD/PAX FIX660R2 — Grain Studio corrected smoke installer

FIX660R2 contains the same FIX660_GRAIN_STUDIO application as FIX660R1.
The correction is in the deployment contract only.

## Root cause fixed
FIX660R1 successfully started FIX660 live, but its post-restart smoke test incorrectly expected `decor_library.js?v=660`. The application deliberately keeps the byte-identical FIX659R1 library bundle and therefore correctly loads `decor_library.js?v=659r1`. That false assertion returned exit code 1 and triggered an unnecessary rollback.

FIX660R2:
- expects the actual retained `decor_library.js?v=659r1` bundle;
- explicitly probes the three Grain Studio public assets after restart;
- gives named failure messages for backend/proxy/CORS smoke checks;
- retains exact FIX659R1/FIX659R2 baseline hash verification, state-preserving backup and automatic rollback;
- does not alter pricing, VAT, catalog, optimizer, submit, security, URL or ports.

Live target remains `http://51.195.102.180:8790/`.
