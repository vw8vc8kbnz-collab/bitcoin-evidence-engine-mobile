# METOD/PAX FIX660R1 — veilige baseline bridge naar Grain Studio

Deze package bevat exact de FIX660 Grain Studio applicatie, maar met een gecorrigeerde installer voor de werkelijk live aangetroffen baseline.

## Waarom R1?
De eerste FIX660-installer was bewust fail-closed en accepteerde alleen FIX659R2. De live VPS bleek nog exact FIX659R1_ADAPTIVE_CNC_MOBILE_FIT te draaien. FIX660R1 accepteert daarom uitsluitend:
- de exact gehashte FIX659R1 golden baseline; of
- de exact gehashte FIX659R2 golden baseline.

Vanaf FIX659R1 neemt deze release de volledige FIX659R2 mobile polish automatisch mee en installeert daarna FIX660 Grain Studio in één state-preserving backup/switch/rollbackcyclus.

De build die live komt blijft: `FIX660_GRAIN_STUDIO`.
De URL blijft: `http://51.195.102.180:8790/`.
