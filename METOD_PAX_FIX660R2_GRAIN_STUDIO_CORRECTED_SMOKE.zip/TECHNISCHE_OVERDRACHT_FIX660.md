# Technische overdracht — METOD/PAX FIX660_GRAIN_STUDIO

## 1. Baseline en scope
FIX660 is een chirurgische Doorlopende Nerf release bovenop FIX659R2. Alle businesscontracten buiten grain UI/rendering zijn behouden.

## 2. Nieuwe modules
### `app/toolA_grain_studio_math.js`
Autoritatieve view-math voor Grain Studio:
- `sameWidthMm`
- `distinctWidthsMm`
- `summarizePanels`
- `computeVerticalGroupFit`

`computeVerticalGroupFit` gebruikt één uniforme schaalfactor voor de volledige verticale groep. Paneelhoogtes worden uitsluitend `realHeightMm * scale`; er is geen visuele minimumhoogte.

### `app/toolA_grain_studio_renderer.js`
Canvaspreview voor desktop + mobile:
- echte panel widthMm/heightMm
- FIX659 materiaal-swatch per paneel
- DXF holes + holeArcs
- dezelfde deur/scharnier-mirrorsemantiek als Stap 2
- adaptieve contrastkleur; CNC lineWidth blijft 1 px
- orderrail + nerfpijl
- collision-safe maatlabelrail buiten de paneelvorm
- click-hit testing naar invoertegel

### `app/toolA_grain_studio.css`
Mobile bottom drawer + tile UX. Preview staat los van de invoer en kan vanaf onder worden geopend. Vaste Apply/Cancel actiebalk blijft bereikbaar.

## 3. Bestaande modules aangepast
### `app/toolA_grain_mobile_scale.js`
- mobile beschikbare panelen gegroepeerd op echte `widthMm`
- true-aspect miniaturen
- positionele tiles
- pointer/touch drag reorder
- bottom drawer controller
- preview/input focuskoppeling

### `app/toolA_grain_validation.js`
Drop-validatie gebruikt `groupWidthMm` en `itemWidthMm`; afwijking > 0.001 mm wordt geweigerd. Legacy cm-parameters blijven alleen als compatibility fallback bestaan.

### `app/toolA.html`
- width selector en desktop buckets gebruiken echte mm
- group data krijgt `widthMm`
- final Apply controleert unieke echte breedtes
- nieuwe groups krijgen unieke Gxx IDs
- FIX660 scripts/CSS geladen
- globale Tool A buildmarker = FIX660_GRAIN_STUDIO

### `app/server_py.py`
Alleen:
- buildmarker FIX660
- drie nieuwe static assets aan expliciete publieke allowlist toegevoegd

## 4. Harde breedte-invariant
`widthMm` is autoritatief. Nominale productnamen/cm-maten zijn niet voldoende.
Voorbeeld:
- 597.000 mm + 597.000 mm => toegestaan
- 597.000 mm + 596.000 mm => geweigerd

Deze invariant wordt afgedwongen bij:
1. beschikbare-panelen buckets;
2. toevoegen/drop;
3. mobile addMany;
4. group preview;
5. final Apply-validatie.

## 5. Renderingcontract
- hele groep gebruikt één mm->px schaal
- panelen blijven onderling exact proportioneel
- elk paneel gebruikt één toegewezen materiaal-swatch, aspectvast center-cover, clip, nooit repeat
- lokale grain axis blijft autoritatief
- boring/arc overlay volgt dezelfde lokale geometrie als Stap 2
- zeer kleine fronten worden niet opgeblazen; labels worden buiten de geometrie opgelost

## 6. Deployment
Installer: `INSTALL_FIX660R1_FROM_STAGE.sh`
Live deploy: `DEPLOY_FIX660.sh`

De installer:
- controleert bestaande service + :8790 + :8792
- eist exact FIX659R2 als bestaande baseline
- valideert release hashes
- draait regressies + production preflight vóór live switch
- maakt app- en externe-configbackup
- behoudt jobs/requests/queue/archive/backups/system/decor_media/material_library/pricing/embedded DXFs
- voert final smoke via tijdelijke responsebestanden uit
- rolt automatisch terug bij fout

## 7. Niet wijzigen in vervolgfix zonder aparte scope
- prijs/BTW-contract
- CSV-only catalogus/taxonomy
- optimizer
- finalization/submit-idempotency
- auth/token/SSE hardening
- URL/poortarchitectuur
- FIX659 material-rendering contract

## 8. Acceptatie na live deploy
Controleer minimaal:
1. lange deur + laag ladefront in één groep: echte hoogteverhouding zichtbaar;
2. boringen zichtbaar in beide panelen;
3. licht/donker materiaal: CNC contrast leesbaar en 1px;
4. drawer dicht/open op iPhone;
5. reorder tile -> preview verandert direct;
6. 597 mm + afwijkende breedte wordt geweigerd;
7. Apply/Cancel blijven bereikbaar;
8. Tool A blijft op `http://51.195.102.180:8790/`.


## FIX660R2 deployment correction
FIX660R1 was observed to start the FIX660 service successfully and return HTTP 200 for `/toolA.html?v=660` and `/api/materials/library`, after which the deployment smoke incorrectly asserted `decor_library.js?v=660`. FIX660 intentionally retains the unchanged FIX659R1 decor library asset reference `decor_library.js?v=659r1`, so that assertion was invalid and caused rollback. FIX660R2 corrects only this deployment smoke contract and adds explicit live probes for the Grain Studio JS/CSS assets. Application build marker remains `FIX660_GRAIN_STUDIO`.
