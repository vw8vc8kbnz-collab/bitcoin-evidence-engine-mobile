from pathlib import Path
from PIL import Image, ImageEnhance, ImageDraw, ImageFont
from app.core.config import UPLOAD_DIR, MOCK_RENDER_COST_EUR
import uuid

STYLE_TINTS = {
    "japandi": (224, 211, 190, 48),
    "modern_warm": (214, 185, 150, 45),
    "hotel_chic": (92, 78, 63, 52),
    "scandinavisch": (236, 237, 232, 40),
    "industrieel": (65, 68, 70, 48),
    "luxe_minimal": (190, 168, 132, 58),
    "landelijk_modern": (176, 158, 132, 45),
}

def mock_generate(input_path: str, style: str, budget_class: str, user_prompt: str = ""):
    src = Path(input_path)
    out_name = f"render_{uuid.uuid4().hex}.jpg"
    out_path = UPLOAD_DIR / out_name
    img = Image.open(src).convert("RGB")
    img.thumbnail((1400, 1400))
    img = ImageEnhance.Contrast(img).enhance(1.08)
    img = ImageEnhance.Color(img).enhance(0.86)
    overlay = Image.new("RGBA", img.size, STYLE_TINTS.get(style, (210,190,165,45)))
    base = Image.alpha_composite(img.convert("RGBA"), overlay)
    draw = ImageDraw.Draw(base)
    w,h = base.size
    # architectural overlay bars to signal mock concept without pretending real AI
    draw.rectangle((0, h-120, w, h), fill=(15,15,14,165))
    draw.text((32, h-92), "ROOMBUDGET CONCEPT PREVIEW", fill=(248,246,242,255))
    draw.text((32, h-56), f"Stijl: {style.replace('_',' ')} · Niveau: {budget_class}", fill=(220,214,204,255))
    if user_prompt:
        short = user_prompt[:90] + ("..." if len(user_prompt) > 90 else "")
        draw.text((32, h-28), short, fill=(220,214,204,235))
    base.convert("RGB").save(out_path, quality=90, optimize=True)
    return str(out_path), MOCK_RENDER_COST_EUR
