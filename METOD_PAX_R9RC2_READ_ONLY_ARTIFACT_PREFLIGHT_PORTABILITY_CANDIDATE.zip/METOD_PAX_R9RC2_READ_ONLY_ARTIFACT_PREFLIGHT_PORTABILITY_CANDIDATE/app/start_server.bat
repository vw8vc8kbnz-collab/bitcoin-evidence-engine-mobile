@echo off
set "PYTHONDONTWRITEBYTECODE=1"
REM Shared/plaintext environment credentials are deliberately unsupported.
if not exist "config\admin_credentials.json" (
  echo ERROR: config\admin_credentials.json ontbreekt.
  echo Maak eerst een 600000-iteratiehash met: python ..\tools\make_admin_hash.py
  exit /b 1
)

REM === Start server (use Python launcher if available) ===
start "" http://127.0.0.1:8787/
start "" http://127.0.0.1:8787/admin

REM Prefer py -3 on Windows, fallback to python
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 server_py.py
) else (
  python server_py.py
)

pause
