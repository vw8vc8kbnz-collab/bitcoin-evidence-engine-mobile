import { createJobsApi } from "./api/jobs.js";
import { createFinalSubmitAction, createRequestsApi } from "./api/requests.js";
import { createCheckoutReviewComponent } from "./components/checkout-review.js";
import { createDialogComponent } from "./components/dialog.js";
import { createFooterComponent } from "./components/footer.js";
import { createGrainPreviewComponent } from "./components/grain-preview.js";
import { createMaterialCardComponent } from "./components/material-card.js";
import { createMobileMaterialCartComponent } from "./components/mobile-material-cart.js";
import { createOverlayRouterComponent } from "./components/overlay-router.js";
import { createPanelEditorComponent } from "./components/panel-editor.js";
import { createProgressOverlayComponent } from "./components/progress-overlay.js";
import { createThankYouComponent } from "./components/thank-you.js";
import { createToolAStore } from "./state/store.js";
import { createMaterialsViewConsumer } from "./steps/materials.js";
import { createPanelsViewConsumer } from "./steps/panels.js";
import { createGrainViewConsumer } from "./steps/grain.js";
import { createCustomerViewConsumer } from "./steps/customer.js";

export const TOOL_A_R9_FOUNDATION_REVISION = "R9RC1_PROFESSIONAL_ARCHITECTURE_COMPLETION";

function readLegacySource() {
  return {
    state: globalThis.state,
    runtime: {
      uiStep: globalThis.__metod_uiStep,
      liveCustomer: globalThis.__metod_checkout_live_customer,
    },
  };
}

export const toolAStore = createToolAStore(readLegacySource);
export const materialsViewConsumer = createMaterialsViewConsumer(toolAStore);
export const panelsViewConsumer = createPanelsViewConsumer(toolAStore);
export const grainViewConsumer = createGrainViewConsumer(toolAStore);
export const customerViewConsumer = createCustomerViewConsumer(toolAStore);
export const jobsApi = createJobsApi();
export const requestsApi = createRequestsApi();
export const finalSubmitAction = createFinalSubmitAction({ requestsApi });
export const checkoutReviewComponent = createCheckoutReviewComponent({
  getCustomerView: () => customerViewConsumer.getView(),
});
export const dialogComponent = createDialogComponent();
export const footerComponent = createFooterComponent();
export const grainPreviewComponent = createGrainPreviewComponent();
export const materialCardComponent = createMaterialCardComponent();
export const mobileMaterialCartComponent = createMobileMaterialCartComponent();
export const overlayRouterComponent = createOverlayRouterComponent();
export const panelEditorComponent = createPanelEditorComponent();
export const progressOverlayComponent = createProgressOverlayComponent();
export const thankYouComponent = createThankYouComponent({
  getState: () => readLegacySource().state,
  hideProgress: () => progressOverlayComponent.hideMetodProgressOverlay(),
});

const passiveAdapter = Object.freeze({
  revision: TOOL_A_R9_FOUNDATION_REVISION,
  mode: "legacy-read-cleanup-adapter",
  getSnapshot: () => toolAStore.getSnapshot(),
  getMaterialsView: () => materialsViewConsumer.getView(),
  getPanelsView: () => panelsViewConsumer.getView(),
  getGrainView: () => grainViewConsumer.getView(),
  getCustomerView: () => customerViewConsumer.getView(),
  getCustomerSnapshot: () => toolAStore.getCustomerSnapshot(),
  normalizeCustomerSnapshot: (source) => toolAStore.normalizeCustomerSnapshot(source),
  getGrainMaterialKey: () => toolAStore.getGrainMaterialKey(),
  isGrainEnabledForMaterial: (materialKey) => toolAStore.isGrainEnabledForMaterial(materialKey),
  isGrainCapableItem: (item) => toolAStore.isGrainCapableItem(item),
  parseGrainReference: (reference) => toolAStore.parseGrainReference(reference),
  getMaterialThickness: (materialKey, materialCatalog, defaultThicknessMm) => toolAStore.getMaterialThickness(materialKey, materialCatalog, defaultThicknessMm),
  getUsableMaterialSheetDimensions: (materialKey, materialCatalog) => toolAStore.getUsableMaterialSheetDimensions(materialKey, materialCatalog),
  startJob: (serializedPayload) => jobsApi.startJob(serializedPayload),
  cancelJob: (options) => jobsApi.cancelJob(options),
  pollJob: (options) => jobsApi.pollJob(options),
  fetchJobPricingSummary: (options) => jobsApi.fetchPricingSummary(options),
  authoritativeTotalInclVat: (source) => jobsApi.authoritativeTotalInclVat(source),
  submitFinalConfiguration: (context, callbacks) => finalSubmitAction.submit(context, callbacks),
  resetFinalSubmission: () => finalSubmitAction.reset(),
  getFinalSubmissionState: () => finalSubmitAction.getState(),
  showSubmissionThankYou: (data) => thankYouComponent.show(data),
  closeSubmissionThankYou: () => thankYouComponent.close(),
  handleSubmissionThankYouEvent: (event) => thankYouComponent.handleEvent(event),
  isSubmissionThankYouOpen: () => thankYouComponent.isOpen(),
  bindCheckoutReview: () => checkoutReviewComponent.bind(),
  handleCheckoutReviewEvent: (event) => checkoutReviewComponent.handleEvent(event),
  captureCheckoutCustomer: (options) => checkoutReviewComponent.captureCustomerSnapshot(options),
  renderCheckoutReview: (options) => checkoutReviewComponent.render(options),
  canSubmitCheckoutReview: (options) => checkoutReviewComponent.canSubmit(options),
  toolAlertParts: (raw, fallbackTitle) => dialogComponent.toolAlertParts(raw, fallbackTitle),
  closeToolAlert: () => dialogComponent.closeToolAlert(),
  showToolAlert: (raw, fallbackTitle) => dialogComponent.showToolAlert(raw, fallbackTitle),
  showToolConfirm: (raw, fallbackTitle) => dialogComponent.showToolConfirm(raw, fallbackTitle),
  showToolAlertHardFallback: (options) => dialogComponent.showToolAlertHardFallback(options),
  showToolAlertHardFallbackAsync: (options) => dialogComponent.showToolAlertHardFallbackAsync(options),
  getFooterDecision: (step, snapshot, overrides) => footerComponent.getDecision(step, snapshot, overrides),
  renderWizardFooter: (options) => footerComponent.render(options),
  bindOverviewFooter: (options) => footerComponent.bindOverview(options),
  placeWizardFooter: (mode, container) => footerComponent.place(mode, container),
  bindGrainPreview: (options) => grainPreviewComponent.bind(options),
  renderGrainPreview: (options) => grainPreviewComponent.render(options),
  scheduleGrainPreview: (options) => grainPreviewComponent.schedule(options),
  getGrainPreviewReadiness: () => grainPreviewComponent.productionReadiness(),
  getGrainGroupDimensions: (group) => grainPreviewComponent.groupDimensions(group),
  renderMaterialCard: (material, options) => materialCardComponent.render(material, options),
  bindMaterialCardGrid: (options) => materialCardComponent.bind(options),
  bindPanelEditor: (options) => panelEditorComponent.bind(options),
  submitPanel: (options) => panelEditorComponent.submitStandard(options),
  submitExtraPanel: (options) => panelEditorComponent.submitExtra(options),
  removePanel: (options) => panelEditorComponent.removeStandard(options),
  removeExtraPanel: (options) => panelEditorComponent.removeExtra(options),
  getPanelEditSnapshot: (item, options) => panelEditorComponent.getStandardEditSnapshot(item, options),
  applyPanelEditSnapshot: (options) => panelEditorComponent.applyStandardPrefill(options),
  resetPanelEditor: (options) => panelEditorComponent.resetStandard(options),
  getExtraPanelEditSnapshot: (item, options) => panelEditorComponent.getExtraEditSnapshot(item, options),
  applyExtraPanelEditSnapshot: (options) => panelEditorComponent.applyExtraPrefill(options),
  resetExtraPanelEditor: (options) => panelEditorComponent.resetExtra(options),
  hideMetodProgressOverlay: () => progressOverlayComponent.hideMetodProgressOverlay(),
  updateMetodProgressBadge: (options) => progressOverlayComponent.updateMetodProgressBadge(options),
  isMetodProgressFallbackVisible: () => progressOverlayComponent.isMetodProgressFallbackVisible(),
  getMobileMaterialCartModels: (state) => mobileMaterialCartComponent.getModels(state),
  initMobileMaterialCart: () => mobileMaterialCartComponent.init(),
  renderMobileMaterialCart: (state) => mobileMaterialCartComponent.render(state),
  openMobileMaterialCart: () => mobileMaterialCartComponent.open(),
  closeMobileMaterialCart: (options) => mobileMaterialCartComponent.close(options),
  removeMobileMaterial: (key) => mobileMaterialCartComponent.remove(key),
  confirmMobileMaterialRemoval: (key) => mobileMaterialCartComponent.confirmRemove(key),
  cancelMobileMaterialRemoval: () => mobileMaterialCartComponent.cancelRemove(),
  bindOverlayRouter: () => overlayRouterComponent.bind(),
  setOverlayVisible: (target, visible) => overlayRouterComponent.setVisible(target, visible),
  hideAllOverlays: () => overlayRouterComponent.hideAll(),
  openOverlay: (target) => overlayRouterComponent.open(target),
  closeOverlay: (target) => overlayRouterComponent.close(target),
});

export const foundationAdapter = passiveAdapter;

document.dispatchEvent(new CustomEvent("tool-a:foundation-ready", {
  detail: foundationAdapter,
}));
checkoutReviewComponent.bind();
mobileMaterialCartComponent.init();
footerComponent.announceReady();
materialCardComponent.announceReady();
panelEditorComponent.announceReady();
grainPreviewComponent.bind();
grainPreviewComponent.announceReady();
checkoutReviewComponent.announceReady();
thankYouComponent.announceReady();
