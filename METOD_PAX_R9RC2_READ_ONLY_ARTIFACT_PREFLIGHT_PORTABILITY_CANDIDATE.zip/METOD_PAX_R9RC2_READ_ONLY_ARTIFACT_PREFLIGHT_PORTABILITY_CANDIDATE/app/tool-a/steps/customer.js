const EMPTY_CUSTOMER_SNAPSHOT = Object.freeze({
  firstName: "",
  lastName: "",
  company: "",
  email: "",
  phone: "",
  billingAddress: "",
  shippingAddress: "",
  shippingSameAsBilling: true,
  postcode: "",
  houseNumber: "",
  address1: "",
  address2: "",
  city: "",
  country: "",
});

const EMPTY_CUSTOMER_VIEW = Object.freeze({
  customerSnapshot: EMPTY_CUSTOMER_SNAPSHOT,
  hasCustomerData: false,
  hasRequiredEmail: false,
  isCustomerStep: false,
  readSucceeded: false,
});

const TEXT_FIELDS = Object.freeze([
  "firstName", "lastName", "company", "email", "phone", "billingAddress",
  "shippingAddress", "postcode", "houseNumber", "address1", "address2",
  "city", "country",
]);

export function selectCustomerView(readModelSnapshot, customerSnapshot) {
  if (
    readModelSnapshot === null
    || typeof readModelSnapshot !== "object"
    || Array.isArray(readModelSnapshot)
    || customerSnapshot === null
    || typeof customerSnapshot !== "object"
    || Array.isArray(customerSnapshot)
  ) {
    return EMPTY_CUSTOMER_VIEW;
  }

  const customer = {};
  for (const key of TEXT_FIELDS) {
    customer[key] = String(customerSnapshot[key] == null ? "" : customerSnapshot[key]).trim();
  }
  customer.shippingSameAsBilling = typeof customerSnapshot.shippingSameAsBilling === "boolean"
    ? customerSnapshot.shippingSameAsBilling
    : true;
  const frozenCustomer = Object.freeze(customer);
  const hasCustomerData = TEXT_FIELDS.some((key) => Boolean(frozenCustomer[key]));

  return Object.freeze({
    customerSnapshot: frozenCustomer,
    hasCustomerData,
    hasRequiredEmail: Boolean(frozenCustomer.email),
    isCustomerStep: readModelSnapshot.currentStep === "customer",
    readSucceeded: true,
  });
}

export function createCustomerViewConsumer(store) {
  if (
    store === null
    || typeof store !== "object"
    || typeof store.getSnapshot !== "function"
    || typeof store.getCustomerSnapshot !== "function"
  ) {
    throw new TypeError("R9G customer view requires one read-only Tool A store");
  }

  return Object.freeze({
    getView() {
      try {
        return selectCustomerView(store.getSnapshot(), store.getCustomerSnapshot());
      } catch (_error) {
        return EMPTY_CUSTOMER_VIEW;
      }
    },
  });
}

export { EMPTY_CUSTOMER_SNAPSHOT, EMPTY_CUSTOMER_VIEW };
