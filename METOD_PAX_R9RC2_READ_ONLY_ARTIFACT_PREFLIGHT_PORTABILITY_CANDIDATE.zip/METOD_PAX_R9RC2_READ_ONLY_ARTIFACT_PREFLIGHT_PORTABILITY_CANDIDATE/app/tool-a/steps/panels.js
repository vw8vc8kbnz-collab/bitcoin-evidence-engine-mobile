const EMPTY_PANELS_VIEW = Object.freeze({
  standardPanelLineCount: 0,
  extraPanelLineCount: 0,
  totalPanelLineCount: 0,
  hasPanels: false,
  isPanelsStep: false,
});

function safeCount(value) {
  const count = Number(value);
  return Number.isSafeInteger(count) && count >= 0 ? count : 0;
}

export function selectPanelsView(snapshot) {
  if (snapshot === null || typeof snapshot !== "object" || Array.isArray(snapshot)) {
    return EMPTY_PANELS_VIEW;
  }

  const standardPanelLineCount = safeCount(snapshot.standardPanelLineCount);
  const extraPanelLineCount = safeCount(snapshot.extraPanelLineCount);
  const totalPanelLineCount = standardPanelLineCount + extraPanelLineCount;

  return Object.freeze({
    standardPanelLineCount,
    extraPanelLineCount,
    totalPanelLineCount,
    hasPanels: totalPanelLineCount > 0 || Boolean(snapshot.hasPanels),
    isPanelsStep: snapshot.currentStep === "panels",
  });
}

export function createPanelsViewConsumer(store) {
  if (store === null || typeof store !== "object" || typeof store.getSnapshot !== "function") {
    throw new TypeError("R9G panels view requires one read-only Tool A store");
  }

  return Object.freeze({
    getView() {
      try {
        return selectPanelsView(store.getSnapshot());
      } catch (_error) {
        return EMPTY_PANELS_VIEW;
      }
    },
  });
}

export { EMPTY_PANELS_VIEW };
