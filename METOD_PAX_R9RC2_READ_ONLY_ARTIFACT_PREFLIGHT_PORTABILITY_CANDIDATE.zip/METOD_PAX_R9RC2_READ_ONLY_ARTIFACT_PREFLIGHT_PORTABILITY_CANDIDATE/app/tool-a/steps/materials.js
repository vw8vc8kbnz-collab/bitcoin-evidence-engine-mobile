const EMPTY_MATERIALS_VIEW = Object.freeze({
  activeMaterialKey: "",
  selectedMaterialCount: 0,
  hasSelection: false,
  isMaterialStep: true,
});

function safeCount(value) {
  const count = Number(value);
  return Number.isSafeInteger(count) && count >= 0 ? count : 0;
}

export function selectMaterialsView(snapshot) {
  if (snapshot === null || typeof snapshot !== "object" || Array.isArray(snapshot)) {
    return EMPTY_MATERIALS_VIEW;
  }

  const activeMaterialKey = String(snapshot.activeMaterialKey || "").trim();
  const selectedMaterialCount = safeCount(snapshot.materialBatchCount);

  return Object.freeze({
    activeMaterialKey,
    selectedMaterialCount,
    hasSelection: selectedMaterialCount > 0 || Boolean(snapshot.hasActiveMaterial),
    isMaterialStep: snapshot.currentStep === "material",
  });
}

export function createMaterialsViewConsumer(store) {
  if (store === null || typeof store !== "object" || typeof store.getSnapshot !== "function") {
    throw new TypeError("R9G materials view requires one read-only Tool A store");
  }

  return Object.freeze({
    getView() {
      try {
        return selectMaterialsView(store.getSnapshot());
      } catch (_error) {
        return EMPTY_MATERIALS_VIEW;
      }
    },
  });
}

export { EMPTY_MATERIALS_VIEW };
