const EMPTY_GRAIN_VIEW = Object.freeze({
  grainGroupCount: 0,
  hasGrainGroups: false,
  isGrainStep: false,
});

function safeCount(value) {
  const count = Number(value);
  return Number.isSafeInteger(count) && count >= 0 ? count : 0;
}

export function selectGrainView(snapshot) {
  if (snapshot === null || typeof snapshot !== "object" || Array.isArray(snapshot)) {
    return EMPTY_GRAIN_VIEW;
  }

  const grainGroupCount = safeCount(snapshot.grainGroupCount);
  return Object.freeze({
    grainGroupCount,
    hasGrainGroups: grainGroupCount > 0,
    isGrainStep: snapshot.currentStep === "grain",
  });
}

export function createGrainViewConsumer(store) {
  if (store === null || typeof store !== "object" || typeof store.getSnapshot !== "function") {
    throw new TypeError("R9G grain view requires one read-only Tool A store");
  }

  return Object.freeze({
    getView() {
      try {
        return selectGrainView(store.getSnapshot());
      } catch (_error) {
        return EMPTY_GRAIN_VIEW;
      }
    },
  });
}

export { EMPTY_GRAIN_VIEW };
