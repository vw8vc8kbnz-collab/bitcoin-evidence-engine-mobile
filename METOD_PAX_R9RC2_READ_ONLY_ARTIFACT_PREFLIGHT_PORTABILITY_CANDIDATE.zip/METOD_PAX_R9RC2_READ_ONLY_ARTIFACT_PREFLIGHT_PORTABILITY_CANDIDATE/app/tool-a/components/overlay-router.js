const OVERLAY_IDS = Object.freeze([
  "overlay",
  "grainOverlay",
  "extraOverlay",
  "overviewOverlay",
]);

const OVERLAY_ALIASES = Object.freeze({
  start: "overlay",
  grain: "grainOverlay",
  extra: "extraOverlay",
  overview: "overviewOverlay",
});

export function createOverlayRouterComponent({
  documentRef = globalThis.document,
  getComputedStyleImpl = globalThis.getComputedStyle?.bind(globalThis),
  now = () => Date.now(),
  setIntervalImpl = globalThis.setInterval?.bind(globalThis),
  clearIntervalImpl = globalThis.clearInterval?.bind(globalThis),
  htmlElementClass = globalThis.HTMLElement,
} = {}) {
  let activeOverlayId = null;
  let ignoreDismissUntil = 0;
  let bound = false;
  const intervalHandles = [];

  function normalizeId(target) {
    const raw = typeof target === "string" ? target : target?.id;
    const id = OVERLAY_ALIASES[raw] || raw;
    return OVERLAY_IDS.includes(id) ? id : null;
  }

  function setVisible(target, visible) {
    const id = normalizeId(target);
    if (!id) return false;
    const element = documentRef?.getElementById?.(id);
    if (!element) return false;
    element.style.display = visible ? "flex" : "none";
    element.style.pointerEvents = visible ? "auto" : "none";
    element.setAttribute("aria-hidden", visible ? "false" : "true");
    if (visible) {
      activeOverlayId = id;
      ignoreDismissUntil = now() + 350;
    } else if (activeOverlayId === id) {
      activeOverlayId = null;
    }
    return true;
  }

  function hideAll() {
    for (const id of OVERLAY_IDS) setVisible(id, false);
    activeOverlayId = null;
  }

  function open(target) {
    const id = normalizeId(target);
    if (!id) return false;
    hideAll();
    setVisible(id, true);
    if (documentRef?.body) documentRef.body.style.overflow = "hidden";
    return true;
  }

  function close(target) {
    const id = normalizeId(target);
    if (!id) return false;
    setVisible(id, false);
    if (documentRef?.body) documentRef.body.style.overflow = "";
    return true;
  }

  function enforceActiveOverlay() {
    if (typeof getComputedStyleImpl !== "function") return;
    for (const id of OVERLAY_IDS) {
      const element = documentRef?.getElementById?.(id);
      if (!element) continue;
      const computed = getComputedStyleImpl(element);
      const shown = computed.display !== "none";
      if (shown && element.getAttribute("aria-hidden") !== "false") {
        element.setAttribute("aria-hidden", "false");
        activeOverlayId = id;
      }
      const active = activeOverlayId === id || element.getAttribute("aria-hidden") === "false";
      if (!active || !shown) {
        element.style.display = "none";
        element.style.pointerEvents = "none";
      } else {
        element.style.pointerEvents = "auto";
      }
    }
  }

  function disableHiddenOverlays() {
    if (typeof getComputedStyleImpl !== "function") return;
    for (const id of OVERLAY_IDS) {
      const element = documentRef?.getElementById?.(id);
      if (!element) continue;
      const computed = getComputedStyleImpl(element);
      const hidden = computed.display === "none"
        || computed.visibility === "hidden"
        || parseFloat(computed.opacity || "1") < 0.05;
      if (hidden) {
        element.style.pointerEvents = "none";
        if (computed.display !== "none") element.style.display = "none";
        if (activeOverlayId === id) activeOverlayId = null;
      } else {
        element.style.pointerEvents = "auto";
      }
    }
  }

  function handlePointerDown(event) {
    if (now() < ignoreDismissUntil) return;
    const target = event?.target;
    if (htmlElementClass && !(target instanceof htmlElementClass)) return;
    if (!htmlElementClass && !target) return;
    const overlay = target.closest?.(".overlay");
    if (overlay && target === overlay) hideAll();
  }

  function bind() {
    if (bound) return;
    bound = true;
    if (typeof setIntervalImpl === "function") {
      intervalHandles.push(setIntervalImpl(enforceActiveOverlay, 500));
    }
    documentRef?.addEventListener?.("pointerdown", handlePointerDown, { capture: true });
    setVisible("grainOverlay", false);
    setVisible("extraOverlay", false);
    setVisible("overviewOverlay", false);
    setVisible("overlay", true);
    if (typeof setIntervalImpl === "function") {
      intervalHandles.push(setIntervalImpl(disableHiddenOverlays, 500));
    }
  }

  function destroy() {
    if (!bound) return;
    documentRef?.removeEventListener?.("pointerdown", handlePointerDown, { capture: true });
    if (typeof clearIntervalImpl === "function") {
      for (const handle of intervalHandles) clearIntervalImpl(handle);
    }
    intervalHandles.length = 0;
    bound = false;
  }

  function getState() {
    return Object.freeze({ activeOverlayId, ignoreDismissUntil, bound });
  }

  return Object.freeze({ bind, destroy, setVisible, hideAll, open, close, getState });
}
