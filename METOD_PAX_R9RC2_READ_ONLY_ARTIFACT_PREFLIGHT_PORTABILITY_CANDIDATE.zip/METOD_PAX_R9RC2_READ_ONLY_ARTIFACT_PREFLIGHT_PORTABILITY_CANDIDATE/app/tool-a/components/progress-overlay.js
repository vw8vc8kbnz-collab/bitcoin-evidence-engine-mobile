export const PROGRESS_OVERLAY_MARKUP = `
        <div class="metodProgressOverlayCard" role="dialog" aria-modal="true" aria-labelledby="metodProgressOverlayTitle">
          <img class="metodProgressOverlayLogo" src="assets/adzaagt_logo.png" alt="Adzaagt logo" />
          <h2 id="metodProgressOverlayTitle" class="metodProgressOverlayTitle">Optimaliseren</h2>
          <div id="metodProgressOverlayRing" class="metodProgressOverlayRing" aria-hidden="true">
            <div class="metodProgressOverlayRingInner"><span id="metodProgressOverlayPct" class="metodProgressOverlayPct">0%</span></div>
          </div>
          <div class="metodProgressOverlayBar"><div id="metodProgressOverlayFill" class="metodProgressOverlayBarFill"></div></div>
          <div id="metodProgressOverlayLabel" class="metodProgressOverlayLabel">Bezig met optimaliseren…</div>
          <div class="metodProgressOverlayHint"><span class="metodProgressOverlayHintIcon">⌛</span><span>Dit kan even duren, sluit deze pagina niet af.</span></div>
        </div>`;

export function createProgressOverlayComponent({ documentRef = globalThis.document } = {}) {
  let metodProgressBadgeEl = null;
  let metodProgressOverlayEl = null;

  function ensureMetodProgressBadge() {
    try {
      if (
        metodProgressBadgeEl
        && documentRef.body
        && documentRef.body.contains(metodProgressBadgeEl)
      ) return metodProgressBadgeEl;
      const el = documentRef.createElement("div");
      el.id = "metodProgressBadge";
      el.setAttribute("aria-live", "polite");
      el.style.position = "fixed";
      el.style.top = "16px";
      el.style.right = "16px";
      el.style.zIndex = "10050";
      el.style.padding = "10px 14px";
      el.style.borderRadius = "999px";
      el.style.background = "rgba(255,255,255,0.96)";
      el.style.border = "1px solid rgba(27,173,118,0.28)";
      el.style.boxShadow = "0 10px 30px rgba(0,0,0,0.14)";
      el.style.color = "#1d2b25";
      el.style.fontSize = "13px";
      el.style.fontWeight = "700";
      el.style.display = "none";
      el.style.maxWidth = "min(360px, calc(100vw - 24px))";
      el.style.lineHeight = "1.25";
      documentRef.body.appendChild(el);
      metodProgressBadgeEl = el;
      return el;
    } catch (_error) {
      return null;
    }
  }


  function ensureMetodProgressOverlay() {
    try {
      if (
        metodProgressOverlayEl
        && documentRef.body
        && documentRef.body.contains(metodProgressOverlayEl)
      ) return metodProgressOverlayEl;
      const el = documentRef.createElement("div");
      el.id = "metodProgressOverlay";
      el.setAttribute("aria-hidden", "true");
      el.innerHTML = PROGRESS_OVERLAY_MARKUP;
      documentRef.body.appendChild(el);
      metodProgressOverlayEl = el;
      return el;
    } catch (_error) {
      return null;
    }
  }

  function hideMetodProgressOverlay() {
    try {
      const overlay = ensureMetodProgressOverlay();
      if (overlay) {
        overlay.setAttribute("aria-hidden", "true");
        overlay.style.display = "none";
      }
      if (documentRef.body && documentRef.body.dataset.metodProgressOverlayOpen === "1") {
        documentRef.body.style.overflow = documentRef.body.dataset.metodProgressOverlayPrevOverflow || "";
        delete documentRef.body.dataset.metodProgressOverlayPrevOverflow;
        delete documentRef.body.dataset.metodProgressOverlayOpen;
      }
    } catch (_error) {
      // Preserve the legacy no-throw UI boundary.
    }
  }

  function updateMetodProgressBadge(opts = {}) {
    try {
      const overlay = ensureMetodProgressOverlay();
      const fallback = ensureMetodProgressBadge();
      if (!opts || !opts.busy) {
        hideMetodProgressOverlay();
        if (fallback) {
          fallback.style.display = "none";
          fallback.textContent = "";
        }
        return;
      }
      const pct = Number.isFinite(Number(opts.progressPct))
        ? Math.max(0, Math.min(100, Math.round(Number(opts.progressPct))))
        : null;
      const label = String(opts.progressLabel || "").trim() || "Bezig met optimaliseren…";
      if (overlay) {
        const pctValue = pct != null ? pct : 6;
        const pctEl = overlay.querySelector("#metodProgressOverlayPct");
        const fillEl = overlay.querySelector("#metodProgressOverlayFill");
        const labelEl = overlay.querySelector("#metodProgressOverlayLabel");
        const ringEl = overlay.querySelector("#metodProgressOverlayRing");
        if (pctEl) pctEl.textContent = pct != null ? `${pct}%` : "…";
        if (fillEl) fillEl.style.width = `${Math.max(6, pctValue)}%`;
        if (labelEl) labelEl.textContent = label;
        if (ringEl) {
          const deg = Math.max(8, Math.min(360, pctValue * 3.6));
          ringEl.style.background = `conic-gradient(rgba(102,198,152,.95) 0deg ${deg}deg, rgba(218,236,226,1) ${deg}deg 360deg)`;
        }
        overlay.style.display = "flex";
        overlay.setAttribute("aria-hidden", "false");
        if (documentRef.body && documentRef.body.dataset.metodProgressOverlayOpen !== "1") {
          documentRef.body.dataset.metodProgressOverlayOpen = "1";
          documentRef.body.dataset.metodProgressOverlayPrevOverflow = documentRef.body.style.overflow || "";
          documentRef.body.style.overflow = "hidden";
        }
        if (fallback) {
          fallback.style.display = "none";
          fallback.textContent = "";
        }
        return;
      }
      if (!fallback) return;
      fallback.textContent = pct != null
        ? `Optimaliseren ${pct}%${label ? ` • ${label}` : ""}`
        : label;
      fallback.style.display = "block";
    } catch (_error) {
      // Preserve the legacy no-throw UI boundary.
    }
  }

  function isMetodProgressFallbackVisible() {
    try {
      const badge = metodProgressBadgeEl || documentRef.getElementById("metodProgressBadge");
      if (!badge) return false;
      const display = String(badge.style.display || "").trim().toLowerCase();
      const text = String(badge.textContent || "").trim();
      return Boolean(display && display !== "none" && text);
    } catch (_error) {
      return false;
    }
  }

  return Object.freeze({
    hideMetodProgressOverlay,
    updateMetodProgressBadge,
    isMetodProgressFallbackVisible,
  });
}
