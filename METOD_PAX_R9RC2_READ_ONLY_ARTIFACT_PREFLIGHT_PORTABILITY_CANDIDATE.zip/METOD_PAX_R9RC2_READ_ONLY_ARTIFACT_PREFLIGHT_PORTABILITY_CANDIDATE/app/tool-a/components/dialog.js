const DEFAULT_IDS = Object.freeze({
  overlay: "toolAlertOverlay",
  title: "toolAlertTitle",
  body: "toolAlertBody",
  detailsWrap: "toolAlertDetailsWrap",
  details: "toolAlertDetails",
  ok: "toolAlertOkBtn",
  cancel: "toolAlertCancelBtn",
});

export function toolAlertParts(raw, fallbackTitle) {
  try {
    const msg = String(raw == null ? "" : raw).replace(/\r/g, "").trim();
    if (!msg) return { title: fallbackTitle || "Melding", body: "", details: "" };
    const chunks = msg.split(/\n\n+/).map((value) => String(value || "").trim()).filter(Boolean);
    if (chunks.length >= 2) {
      return {
        title: chunks[0] || (fallbackTitle || "Melding"),
        body: chunks[1] || "",
        details: chunks.slice(2).join("\n\n"),
      };
    }
    const lines = msg.split(/\n+/).map((value) => String(value || "").trim()).filter(Boolean);
    if (lines.length >= 3) {
      return {
        title: lines[0] || (fallbackTitle || "Melding"),
        body: lines[1] || "",
        details: lines.slice(2).join("\n"),
      };
    }
    return { title: fallbackTitle || "Melding", body: msg, details: "" };
  } catch (_error) {
    return { title: fallbackTitle || "Melding", body: String(raw || ""), details: "" };
  }
}

export function createDialogComponent({
  documentRef = globalThis.document,
  requestAnimationFrameImpl = globalThis.requestAnimationFrame,
  setTimeoutImpl = globalThis.setTimeout,
  confirmImpl = globalThis.confirm,
  consoleRef = globalThis.console,
  ids = DEFAULT_IDS,
} = {}) {
  function element(name) {
    return documentRef && typeof documentRef.getElementById === "function"
      ? documentRef.getElementById(ids[name])
      : null;
  }

  function scheduleFrame(callback) {
    if (typeof requestAnimationFrameImpl === "function") requestAnimationFrameImpl(callback);
  }

  function closeToolAlert() {
    try {
      const overlay = element("overlay");
      if (!overlay) return;
      overlay.classList.remove("isOpen");
      const onClose = overlay.__toolAlertOnClose;
      const onCancel = overlay.__toolAlertOnCancel;
      const closedBy = overlay.__toolAlertClosedBy || "ok";
      overlay.__toolAlertOnClose = null;
      overlay.__toolAlertOnCancel = null;
      overlay.__toolAlertClosedBy = null;
      overlay.__toolAlertConfirmMode = false;
      if (typeof setTimeoutImpl !== "function") return;
      setTimeoutImpl(() => {
        try { overlay.style.display = "none"; } catch (_error) { /* compatibility no-op */ }
        try {
          if (closedBy === "cancel") {
            if (typeof onCancel === "function") onCancel();
          } else if (typeof onClose === "function") {
            onClose();
          }
        } catch (_error) { /* compatibility no-op */ }
      }, 120);
    } catch (_error) { /* compatibility no-op */ }
  }

  function showToolAlert(raw, fallbackTitle) {
    try {
      const overlay = element("overlay");
      const titleEl = element("title");
      const bodyEl = element("body");
      const detailsWrap = element("detailsWrap");
      const detailsEl = element("details");
      const okBtn = element("ok");
      const cancelBtn = element("cancel");
      if (!overlay || !titleEl || !bodyEl || !detailsWrap || !detailsEl || !okBtn) {
        try { consoleRef.warn("toolAlertOverlay ontbreekt; fallback naar console"); } catch (_error) { /* no-op */ }
        try { consoleRef.warn(raw); } catch (_error) { /* no-op */ }
        return;
      }
      const isObjectRaw = Boolean(raw && typeof raw === "object" && !Array.isArray(raw));
      const onClose = isObjectRaw && typeof raw.onClose === "function" ? raw.onClose : null;
      const onCancel = isObjectRaw && typeof raw.onCancel === "function" ? raw.onCancel : null;
      const parts = isObjectRaw
        ? {
            title: String(raw.title || fallbackTitle || "Melding").trim(),
            body: String(raw.body || raw.message || "").trim(),
            details: String(raw.details || "").trim(),
          }
        : toolAlertParts(raw, fallbackTitle || "Waarschuwing");
      const confirmMode = Boolean(isObjectRaw && raw.confirm === true);
      const okLabel = String((isObjectRaw && raw.okText) || (confirmMode ? "Doorgaan" : "Oké")).trim()
        || (confirmMode ? "Doorgaan" : "Oké");
      const cancelLabel = String((isObjectRaw && raw.cancelText) || "Annuleren").trim() || "Annuleren";
      titleEl.textContent = parts.title || (fallbackTitle || "Waarschuwing");
      bodyEl.textContent = parts.body || "";
      detailsEl.textContent = parts.details || "";
      detailsWrap.style.display = parts.details ? "block" : "none";
      okBtn.textContent = okLabel;
      if (cancelBtn) {
        cancelBtn.textContent = cancelLabel;
        cancelBtn.style.display = confirmMode ? "" : "none";
      }
      overlay.__toolAlertOnClose = onClose || null;
      overlay.__toolAlertOnCancel = onCancel || null;
      overlay.__toolAlertConfirmMode = confirmMode;
      overlay.style.display = "flex";
      scheduleFrame(() => {
        try { overlay.classList.add("isOpen"); } catch (_error) { /* no-op */ }
        try { okBtn.focus(); } catch (_error) { /* no-op */ }
      });
      if (!okBtn.__boundToolAlert) {
        okBtn.__boundToolAlert = true;
        okBtn.addEventListener("click", () => {
          try { overlay.__toolAlertClosedBy = "ok"; } catch (_error) { /* no-op */ }
          closeToolAlert();
        });
      }
      if (cancelBtn && !cancelBtn.__boundToolAlert) {
        cancelBtn.__boundToolAlert = true;
        cancelBtn.addEventListener("click", () => {
          try { overlay.__toolAlertClosedBy = "cancel"; } catch (_error) { /* no-op */ }
          closeToolAlert();
        });
      }
      if (!overlay.__boundToolAlertBackdrop) {
        overlay.__boundToolAlertBackdrop = true;
        overlay.addEventListener("click", (event) => {
          if (event.target === overlay && !overlay.__toolAlertConfirmMode) {
            try { overlay.__toolAlertClosedBy = "backdrop"; } catch (_error) { /* no-op */ }
            closeToolAlert();
          }
        });
      }
      if (!overlay.__boundToolAlertEsc) {
        overlay.__boundToolAlertEsc = true;
        documentRef.addEventListener("keydown", (event) => {
          if (event.key === "Escape" && overlay.style.display !== "none" && !overlay.__toolAlertConfirmMode) {
            try { overlay.__toolAlertClosedBy = "escape"; } catch (_error) { /* no-op */ }
            closeToolAlert();
          }
        });
      }
    } catch (error) {
      try { consoleRef.warn("showToolAlert failed", error); } catch (_error) { /* no-op */ }
    }
  }

  function showToolAlertHardFallback(options) {
    try {
      const title = String((options && options.title) || "Melding").trim() || "Melding";
      const body = String((options && options.body) || "").trim();
      const details = String((options && options.details) || "").trim();
      const onClose = options && typeof options.onClose === "function" ? options.onClose : null;
      let overlay = documentRef.getElementById("toolAlertDirectOverlay");
      if (!overlay) {
        overlay = documentRef.createElement("div");
        overlay.id = "toolAlertDirectOverlay";
        overlay.setAttribute("role", "presentation");
        overlay.classList.add("tool-alert-direct-overlay");
        overlay.innerHTML = `
          <div id="toolAlertDirectCard" role="dialog" aria-modal="true" aria-labelledby="toolAlertDirectTitle" class="tool-component-u-a011aee3fa67">
            <div class="tool-component-u-f686ecc94f47">
              <div id="toolAlertDirectTitle" class="tool-component-u-ce0fa34ac5fa">Melding</div>
              <div id="toolAlertDirectBody" class="tool-component-u-414269c1e77b"></div>
            </div>
            <div class="tool-component-u-66069ff2131d">
              <div id="toolAlertDirectDetailsWrap" class="tool-component-u-ace193008826">
                <div id="toolAlertDirectDetails" class="tool-component-u-fada6feff051"></div>
              </div>
            </div>
            <div class="tool-component-u-b4a81ff1819d">
              <button id="toolAlertDirectOkBtn" type="button" class="btn btnPrimary tool-component-u-6f977998f8cd">Oké</button>
            </div>
          </div>`;
        documentRef.body.appendChild(overlay);
      }
      const titleEl = documentRef.getElementById("toolAlertDirectTitle");
      const bodyEl = documentRef.getElementById("toolAlertDirectBody");
      const detailsWrap = documentRef.getElementById("toolAlertDirectDetailsWrap");
      const detailsEl = documentRef.getElementById("toolAlertDirectDetails");
      const okBtn = documentRef.getElementById("toolAlertDirectOkBtn");
      if (!titleEl || !bodyEl || !detailsWrap || !detailsEl || !okBtn) {
        try { if (typeof onClose === "function") onClose(); } catch (_error) { /* no-op */ }
        return false;
      }
      overlay.__toolAlertOnClose = onClose || null;
      titleEl.textContent = title;
      bodyEl.textContent = body;
      detailsEl.textContent = details;
      detailsWrap.style.display = details ? "block" : "none";
      overlay.style.display = "flex";
      try { documentRef.body.appendChild(overlay); } catch (_error) { /* no-op */ }
      try { documentRef.body.style.overflow = "hidden"; } catch (_error) { /* no-op */ }
      if (!okBtn.__boundDirectToolAlert) {
        okBtn.__boundDirectToolAlert = true;
        okBtn.addEventListener("click", () => {
          try { overlay.style.display = "none"; } catch (_error) { /* no-op */ }
          try { documentRef.body.style.overflow = ""; } catch (_error) { /* no-op */ }
          const callback = overlay.__toolAlertOnClose;
          overlay.__toolAlertOnClose = null;
          try { if (typeof callback === "function") callback(); } catch (_error) { /* no-op */ }
        });
      }
      scheduleFrame(() => { try { okBtn.focus(); } catch (_error) { /* no-op */ } });
      return true;
    } catch (_error) {
      return false;
    }
  }

  function showToolAlertHardFallbackAsync(options) {
    return new Promise((resolve) => {
      try {
        const merged = Object.assign({}, options && typeof options === "object" ? options : { body: String(options || "") });
        const previousClose = typeof merged.onClose === "function" ? merged.onClose : null;
        merged.onClose = () => {
          try { if (typeof previousClose === "function") previousClose(); } catch (_error) { /* no-op */ }
          resolve(true);
        };
        const shown = showToolAlertHardFallback(merged);
        if (!shown) {
          try { showToolAlert(merged, merged.title || "Melding"); } catch (_error) { /* no-op */ }
          resolve(true);
        }
      } catch (_error) {
        try { showToolAlert(options, (options && options.title) || "Melding"); } catch (_showError) { /* no-op */ }
        resolve(true);
      }
    });
  }

  function showToolConfirm(raw, fallbackTitle) {
    return new Promise((resolve) => {
      try {
        const normalized = raw && typeof raw === "object" && !Array.isArray(raw)
          ? Object.assign({}, raw)
          : { body: String(raw || "") };
        normalized.confirm = true;
        normalized.title = String(normalized.title || fallbackTitle || "Bevestiging").trim() || "Bevestiging";
        normalized.onClose = () => resolve(true);
        normalized.onCancel = () => resolve(false);
        showToolAlert(normalized, fallbackTitle || "Bevestiging");
      } catch (_error) {
        try {
          resolve(confirmImpl(typeof raw === "string" ? raw : String((raw && raw.body) || "Weet je het zeker?")));
        } catch (_confirmError) {
          resolve(false);
        }
      }
    });
  }

  return Object.freeze({
    toolAlertParts,
    closeToolAlert,
    showToolAlert,
    showToolConfirm,
    showToolAlertHardFallback,
    showToolAlertHardFallbackAsync,
  });
}
