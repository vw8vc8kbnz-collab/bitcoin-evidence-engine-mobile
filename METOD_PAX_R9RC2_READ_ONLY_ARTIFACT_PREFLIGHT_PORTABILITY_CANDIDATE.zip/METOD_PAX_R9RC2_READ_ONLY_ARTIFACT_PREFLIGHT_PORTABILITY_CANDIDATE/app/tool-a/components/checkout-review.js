export const CHECKOUT_REVIEW_COMPONENT_BUILD = "R9H_CHECKOUT_REVIEW_COMPONENT_8";

function clean(value) {
  return String(value == null ? "" : value).trim();
}

function escapeHtml(value) {
  return String(value == null ? "" : value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function isRecord(value) {
  return Boolean(value && typeof value === "object" && !Array.isArray(value));
}

export function createCheckoutReviewComponent({
  documentRef = globalThis.document,
  rootRef = globalThis,
  getCustomerView = null,
} = {}) {
  let bound = false;
  let readyAnnounced = false;

  function byId(id) {
    return documentRef?.getElementById?.(id) || null;
  }

  function field(id) {
    return clean(byId(id)?.value);
  }

  function liveCustomer() {
    const billingAddress = field("custBillingAddress");
    const shippingSameAsBilling = byId("custShipSame")?.checked !== false;
    const shippingAddress = shippingSameAsBilling ? billingAddress : field("custShippingAddress");
    return {
      firstName: field("custFirstName"),
      lastName: field("custLastName"),
      company: field("custCompany"),
      email: field("custEmail"),
      phone: field("custPhone"),
      billingAddress,
      shippingAddress,
      shippingSameAsBilling,
      postcode: field("custPostcode"),
      houseNumber: field("custHouseNumber"),
      address1: shippingAddress || billingAddress,
      address2: "",
      city: "",
      country: "",
    };
  }

  function hasCustomerValue(customer) {
    return [
      "firstName", "lastName", "company", "email", "phone", "billingAddress",
      "shippingAddress", "postcode", "houseNumber",
    ].some((key) => clean(customer?.[key]));
  }

  function captureCustomerSnapshot(options = {}) {
    const force = options.force === true;
    const customer = liveCustomer();
    if (!force && !hasCustomerValue(customer)) {
      return rootRef.__metod_checkout_live_customer || null;
    }
    const snapshot = { ...customer };
    rootRef.__metod_checkout_live_customer = { ...snapshot };
    const state = isRecord(options.state) ? options.state : rootRef.state;
    if (isRecord(state)) {
      state.checkout = isRecord(state.checkout) ? state.checkout : {};
      state.checkout.customer = { ...snapshot };
      state.checkout.customerSnapshot = { ...snapshot };
      state.lastCalculatedCustomer = { ...snapshot };
      const note = field("custNote");
      if (note || force) state.checkout.note = note;
    }
    return { ...snapshot };
  }

  function currentCustomer(state, explicitCustomer) {
    if (isRecord(explicitCustomer)) return explicitCustomer;
    try {
      const view = typeof getCustomerView === "function" ? getCustomerView() : null;
      if (view?.readSucceeded === true && isRecord(view.customerSnapshot)) {
        return view.customerSnapshot;
      }
    } catch (_error) { /* protected compatibility fallback below */ }
    const candidates = [
      state?.lastCalculatedCustomer,
      state?.checkout?.customer,
      rootRef.__metod_checkout_live_customer,
      state?.checkout?.customerSnapshot,
      state?.customer,
    ];
    return candidates.find(isRecord) || {};
  }

  function materialModels(state) {
    const panels = [
      ...(Array.isArray(state?.cart) ? state.cart : []),
      ...(Array.isArray(state?.extraPanels) ? state.extraPanels : []),
    ];
    const batchByKey = new Map();
    for (const batch of Array.isArray(state?.materialBatches) ? state.materialBatches : []) {
      const key = clean(batch?.key);
      if (!key) continue;
      const material = batch?.mat || batch?.material || {};
      const code = clean(material?.articleNumber || material?.id || material?.code || key) || key;
      const rawName = material?.productName ?? material?.name ?? material?.label ?? material?.decorName ?? code;
      const normalizedName = clean(rawName);
      const name = normalizedName && !/^[0-9]+(?:\.[0-9]+)?$/.test(normalizedName)
        ? normalizedName
        : clean(material?.productName || material?.name || material?.label || code) || code;
      batchByKey.set(key, {
        code,
        name,
        grainEnabled: typeof batch?.grainEnabled === "boolean" ? batch.grainEnabled : true,
      });
    }

    const materials = new Map();
    for (const panel of panels) {
      const rawKey = clean(
        panel?.materialKey || panel?.material_key || panel?.activeMaterialKey || panel?.matKey
        || panel?.articleNumber || panel?.materialCode || panel?.material || state?.activeMaterialKey,
      );
      if (!rawKey) continue;
      const batch = batchByKey.get(rawKey);
      const key = batch?.code || rawKey;
      const grainEnabled = panel?.grainEnabled === true
        || panel?.rotationAllowed === false
        || batch?.grainEnabled === true;
      const current = materials.get(key) || {
        key,
        name: batch?.name || key,
        panels: 0,
        grainEnabled: false,
      };
      current.panels += Number(panel?.qty) || 1;
      current.grainEnabled = current.grainEnabled || grainEnabled;
      materials.set(key, current);
    }
    return Array.from(materials.values()).sort((left, right) => (
      left.key.localeCompare(right.key, "nl", { sensitivity: "base" })
    ));
  }

  function render(options = {}) {
    const state = isRecord(options.state) ? options.state : rootRef.state;
    if (!isRecord(state)) return false;
    const customer = currentCustomer(state, options.customer);
    try {
      const name = [customer.firstName, customer.lastName].filter(Boolean).join(" ").trim();
      const personal = [name, clean(customer.company)].filter(Boolean);
      const contact = [clean(customer.email), clean(customer.phone)].filter(Boolean);
      const addressLine = [customer.postcode, customer.houseNumber].filter(Boolean).join(" ").trim();
      const addresses = [];
      if (customer.billingAddress) {
        addresses.push(`Factuur: ${[clean(customer.billingAddress), addressLine].filter(Boolean).join(" ")}`.trim());
      }
      if (customer.shippingAddress) {
        addresses.push(`Bezorg: ${[clean(customer.shippingAddress), addressLine].filter(Boolean).join(" ")}`.trim());
      }
      const compact = [name, clean(customer.email), clean(customer.phone)].filter(Boolean);

      const personalEl = byId("priceRO_personal");
      const contactEl = byId("priceRO_contact");
      const addressEl = byId("priceRO_address");
      const compactEl = byId("priceCustomerSummary");
      if (personalEl) personalEl.textContent = personal.length ? personal.join("\n") : "—";
      if (contactEl) contactEl.textContent = contact.length ? contact.join("\n") : "—";
      if (addressEl) addressEl.textContent = addresses.length ? addresses.join("\n") : "—";
      if (compactEl) compactEl.textContent = compact.length ? compact.join("\n") : "—";

      const models = materialModels(state);
      const materialsEl = byId("priceMaterialSummary");
      const grainEl = byId("priceGrainLine");
      if (materialsEl) {
        if (!models.length) materialsEl.textContent = "—";
        else materialsEl.innerHTML = models.map((model) => (
          `${escapeHtml(model.name || model.key)}<span class="help">${escapeHtml(model.panels ? ` · ${model.panels} panelen` : "")}</span>`
        )).join("<br>");
      }
      if (grainEl) {
        if (!models.length) grainEl.textContent = "—";
        else grainEl.innerHTML = models.map((model) => (
          `${escapeHtml(model.name || model.key)}: ${escapeHtml(model.grainEnabled ? "AAN (geen rotatie)" : "UIT (rotatie toegestaan)")}`
        )).join("<br>");
      }

      const panelCount = [...(state.cart || []), ...(state.extraPanels || [])]
        .reduce((total, panel) => total + (Number(panel?.qty) || 1), 0);
      const panelCountEl = byId("pricePanelCountLine");
      if (panelCountEl) panelCountEl.textContent = String(panelCount || "—");
      return true;
    } catch (_error) {
      return false;
    }
  }

  function canSubmit(options = {}) {
    const state = isRecord(options.state) ? options.state : rootRef.state;
    if (!isRecord(state)) return false;
    const customer = currentCustomer(state, options.customer);
    const hasPanels = (Array.isArray(state.cart) && state.cart.length > 0)
      || (Array.isArray(state.extraPanels) && state.extraPanels.length > 0);
    return Boolean(clean(customer?.email) && hasPanels);
  }

  function reportSubmitError(error) {
    try {
      rootRef.statusMsg?.(`Verzenden mislukt: ${error?.message || error}`, true);
    } catch (_reportError) { /* no-op */ }
  }

  function handleEvent(event) {
    const target = event?.target;
    const closest = (selector) => (target?.closest ? target.closest(selector) : null);
    if (event?.type === "input" || event?.type === "change") {
      if (closest("#stepCustomer")) captureCustomerSnapshot();
      return false;
    }
    if (event?.type !== "click") return false;

    if (closest("#overviewNextBtn, #legacySaveBtn, #saveBtn, #wizardNextBtn, #wizardOverviewBtn")) {
      captureCustomerSnapshot();
    }
    const submit = closest("#sendConfigBtn, #btnSendConfig");
    if (!submit) return false;
    event.preventDefault?.();
    event.stopImmediatePropagation?.();
    captureCustomerSnapshot();
    const submitFinal = rootRef.__metodSubmitFinalConfiguration;
    if (typeof submitFinal !== "function") {
      try { rootRef.alert?.("De verzendfunctie is niet geladen. Herlaad Tool A en probeer opnieuw."); } catch (_error) { /* no-op */ }
      return true;
    }
    try {
      const result = submitFinal(submit);
      if (result && typeof result.catch === "function") result.catch(reportSubmitError);
    } catch (error) {
      reportSubmitError(error);
    }
    return true;
  }

  function bind() {
    if (bound) return false;
    bound = true;
    rootRef.__metodCommitLiveCustomer = (force = false) => captureCustomerSnapshot({ force });
    if (rootRef.__TOOLA_FIRST_EVENT_OWNER_BUILD) return true;
    documentRef?.addEventListener?.("input", handleEvent, true);
    documentRef?.addEventListener?.("change", handleEvent, true);
    documentRef?.addEventListener?.("click", handleEvent, true);
    return true;
  }

  function announceReady() {
    if (readyAnnounced) return false;
    readyAnnounced = true;
    if (documentRef?.dispatchEvent && typeof rootRef.Event === "function") {
      documentRef.dispatchEvent(new rootRef.Event("tool-a-checkout-review-owner-ready"));
    }
    return true;
  }

  return Object.freeze({
    BUILD: CHECKOUT_REVIEW_COMPONENT_BUILD,
    bind,
    handleEvent,
    captureCustomerSnapshot,
    render,
    canSubmit,
    announceReady,
  });
}
