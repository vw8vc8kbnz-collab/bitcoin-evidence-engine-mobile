export const FOOTER_COMPONENT_BUILD = "R9H_FOOTER_COMPONENT_4";

const ALLOWED_STEPS = Object.freeze([
  "material", "panels", "grain", "customer", "overview",
]);

function text(value) {
  return String(value == null ? "" : value).trim();
}

function safeStep(step, fallback) {
  const requested = text(step);
  if (ALLOWED_STEPS.includes(requested)) return requested;
  const current = text(fallback);
  return ALLOWED_STEPS.includes(current) ? current : "material";
}

export function getFooterDecision(step, snapshot, overrides) {
  const source = snapshot && typeof snapshot === "object" ? snapshot : {};
  const targetStep = safeStep(step, source.currentStep);
  const materialReady = Boolean(source.material && source.material.hasActiveMaterial);
  const hasPanels = Boolean(source.cart && source.cart.hasPanels);
  const customerReady = Boolean(source.customer && source.customer.requiredReady);
  const isEditing = Boolean(source.edit && source.edit.isEditing);

  const decision = {
    step: targetStep,
    showPrev: false,
    prevLabel: "Vorige stap",
    prevDisabled: false,
    showNext: false,
    nextLabel: "Volgende stap",
    nextDisabled: false,
    showOverview: false,
    overviewLabel: "Overzicht",
    overviewDisabled: false,
    addInlineDisabled: targetStep !== "panels",
    addInlineLabel: isEditing ? "✓ Wijzigingen opslaan" : "+ Toevoegen aan lijst",
    addInlineEditing: isEditing,
    guards: {
      materialReady,
      hasPanels,
      customerReady,
      isEditing,
    },
  };

  if (targetStep === "material") {
    decision.showNext = true;
    decision.nextDisabled = !materialReady;
  } else if (targetStep === "panels") {
    decision.showPrev = true;
    decision.showNext = true;
    decision.nextDisabled = !hasPanels;
    decision.addInlineDisabled = !materialReady;
  } else if (targetStep === "grain") {
    decision.showPrev = true;
  } else if (targetStep === "customer") {
    decision.showPrev = true;
    decision.showNext = true;
    decision.nextDisabled = false;
  } else if (targetStep === "overview") {
    decision.showPrev = true;
    decision.prevLabel = "Terug";
  }

  return overrides && typeof overrides === "object"
    ? Object.assign({}, decision, overrides)
    : decision;
}

function buttonState(input, fallbackLabel) {
  const source = input && typeof input === "object" ? input : {};
  return {
    display: source.show ? "inline-flex" : "none",
    disabled: Boolean(source.disabled),
    text: source.label || fallbackLabel,
  };
}

export function getFooterViewState(decision) {
  const source = decision && typeof decision === "object" ? decision : {};
  return {
    step: text(source.step) || "material",
    prev: buttonState({
      show: source.showPrev,
      disabled: source.prevDisabled,
      label: source.prevLabel,
    }, "Vorige stap"),
    next: buttonState({
      show: source.showNext,
      disabled: source.nextDisabled,
      label: source.nextLabel,
    }, "Volgende stap"),
    overview: buttonState({
      show: source.showOverview,
      disabled: source.overviewDisabled,
      label: source.overviewLabel,
    }, "Overzicht"),
    addInline: {
      disabled: Boolean(source.addInlineDisabled),
      text: source.addInlineLabel || "+ Toevoegen aan lijst",
      editing: Boolean(source.addInlineEditing),
      classes: { isEditing: Boolean(source.addInlineEditing) },
    },
  };
}

export function createFooterComponent({
  documentRef = globalThis.document,
  rootRef = globalThis,
} = {}) {
  let placementAnchor = null;
  let readyAnnounced = false;

  function element(id) {
    try {
      return documentRef && typeof documentRef.getElementById === "function"
        ? documentRef.getElementById(id)
        : null;
    } catch (_error) {
      return null;
    }
  }

  function readSnapshot() {
    try {
      const selectors = rootRef && rootRef.ToolACoreSelectors;
      if (selectors && typeof selectors.getWizardSnapshot === "function") {
        const snapshot = selectors.getWizardSnapshot();
        if (snapshot && typeof snapshot === "object") return snapshot;
      }
    } catch (_error) { /* compatibility fallback below */ }
    let materialReady = false;
    let hasPanels = false;
    let customerReady = false;
    try {
      materialReady = Boolean(
        rootRef && typeof rootRef.hasMaterialSelected === "function"
        && rootRef.hasMaterialSelected(),
      );
    } catch (_error) { /* no-op */ }
    try {
      hasPanels = Boolean(
        rootRef && typeof rootRef.hasPanels === "function" && rootRef.hasPanels(),
      );
    } catch (_error) { /* no-op */ }
    try {
      customerReady = Boolean(
        rootRef && typeof rootRef.validateCustomerStepRequired === "function"
        && rootRef.validateCustomerStepRequired(),
      );
    } catch (_error) { /* no-op */ }
    return {
      currentStep: text(rootRef && rootRef.__metod_uiStep) || "material",
      material: { hasActiveMaterial: materialReady },
      cart: { hasPanels },
      customer: { requiredReady: customerReady },
      edit: { isEditing: Boolean(rootRef && rootRef.__panelEditTargetId) },
    };
  }

  function makeButton(id, label, primary) {
    if (!documentRef || typeof documentRef.createElement !== "function") return null;
    const button = documentRef.createElement("button");
    button.id = id;
    button.type = "button";
    button.className = primary ? "btn btnPrimary" : "btn";
    button.textContent = label;
    return button;
  }

  function ensureButtons(input) {
    const options = input && typeof input === "object" ? input : {};
    const footerInner = options.footerInner || element("wizardFooterInner");
    const existing = options.existing && typeof options.existing === "object"
      ? options.existing
      : {};
    let prev = existing.prev || element("wizardPrevBtn");
    let overview = existing.overview || element("wizardOverviewBtn");
    let next = existing.next || element("wizardNextBtn");
    if (!footerInner || typeof footerInner.appendChild !== "function") {
      return { prev: prev || null, next: next || null, overview: overview || null };
    }
    if (!prev) {
      prev = makeButton("wizardPrevBtn", "Vorige stap", false);
      if (prev) footerInner.appendChild(prev);
    }
    if (!overview) {
      overview = makeButton("wizardOverviewBtn", "Overzicht", false);
      if (overview) footerInner.appendChild(overview);
    }
    if (!next) {
      next = makeButton("wizardNextBtn", "Volgende stap", true);
      if (next) footerInner.appendChild(next);
    }
    return { prev: prev || null, next: next || null, overview: overview || null };
  }

  function applyButton(button, state, fallbackText) {
    if (!button) return;
    const source = state && typeof state === "object" ? state : {};
    button.style.display = source.display || "none";
    button.disabled = Boolean(source.disabled);
    button.textContent = source.text || fallbackText;
  }

  function applyViewState(buttons, addInline, viewState) {
    const handles = buttons && typeof buttons === "object" ? buttons : {};
    const source = viewState && typeof viewState === "object" ? viewState : {};
    applyButton(handles.prev, source.prev, "Vorige stap");
    applyButton(handles.next, source.next, "Volgende stap");
    applyButton(handles.overview, source.overview, "Overzicht");
    if (addInline) {
      const addState = source.addInline && typeof source.addInline === "object"
        ? source.addInline
        : {};
      addInline.disabled = Boolean(addState.disabled);
      addInline.textContent = addState.text || "+ Toevoegen aan lijst";
      try {
        addInline.classList.toggle(
          "is-editing",
          Boolean(addState.classes && addState.classes.isEditing),
        );
      } catch (_error) { /* no-op */ }
    }
  }

  function currentStep(buttons, options) {
    try {
      const direct = [buttons.next, buttons.prev, buttons.overview]
        .map((button) => button && button.dataset && button.dataset.currentStep)
        .find(Boolean)
        || (options.footerInner && options.footerInner.dataset
          && options.footerInner.dataset.currentStep)
        || "";
      if (direct) return safeStep(direct, "material");
    } catch (_error) { /* callback fallback below */ }
    try {
      if (typeof options.getCurrentStep === "function") {
        return safeStep(options.getCurrentStep(), "material");
      }
    } catch (_error) { /* root fallback below */ }
    return safeStep(rootRef && rootRef.__metod_uiStep, "material");
  }

  function prevTarget(step, overviewReturnStep, options) {
    try {
      if (typeof options.getPrevTarget === "function") {
        return options.getPrevTarget(step, overviewReturnStep);
      }
      const routes = rootRef && rootRef.ToolARouteState;
      if (routes && typeof routes.getPrevStep === "function") {
        return routes.getPrevStep(step, overviewReturnStep);
      }
    } catch (_error) { /* no-op */ }
    return null;
  }

  function nextTarget(step, context, options) {
    try {
      if (typeof options.getNextTarget === "function") {
        return options.getNextTarget(step, context);
      }
      const routes = rootRef && rootRef.ToolARouteState;
      if (routes && typeof routes.getNextStep === "function") {
        return routes.getNextStep(step, context);
      }
    } catch (_error) { /* no-op */ }
    return null;
  }

  function bindWizardFooter(input) {
    const options = input && typeof input === "object" ? input : {};
    const buttons = {
      prev: options.prevBtn || null,
      next: options.nextBtn || null,
      overview: options.overviewBtn || null,
    };
    const showStep = typeof options.showStep === "function"
      ? options.showStep
      : (target) => {
          try {
            if (rootRef && typeof rootRef.__showWizardStep === "function") {
              rootRef.__showWizardStep(target);
            }
          } catch (_error) { /* no-op */ }
        };
    const getOverviewReturnStep = typeof options.getOverviewReturnStep === "function"
      ? options.getOverviewReturnStep
      : () => text(rootRef && rootRef.__overviewReturnStep) || "customer";
    const hasMaterialSelected = typeof options.hasMaterialSelected === "function"
      ? options.hasMaterialSelected
      : () => Boolean(readSnapshot().material && readSnapshot().material.hasActiveMaterial);
    const hasPanels = typeof options.hasPanels === "function"
      ? options.hasPanels
      : () => Boolean(readSnapshot().cart && readSnapshot().cart.hasPanels);
    const validateCustomer = typeof options.validateCustomerStepRequired === "function"
      ? options.validateCustomerStepRequired
      : () => true;

    if (buttons.prev && !buttons.prev.__bound) {
      buttons.prev.addEventListener("click", () => {
        const step = currentStep(buttons, options);
        const target = prevTarget(step, getOverviewReturnStep(), options) || "material";
        try { showStep(target); } catch (_error) { /* no-op */ }
      });
      buttons.prev.__bound = true;
    }
    if (buttons.next && !buttons.next.__bound) {
      buttons.next.addEventListener("click", () => {
        const step = currentStep(buttons, options);
        if (step === "customer" && !validateCustomer()) return;
        const target = nextTarget(step, {
          hasMaterial: Boolean(hasMaterialSelected()),
          hasPanels: Boolean(hasPanels()),
          customerValid: step === "customer",
        }, options);
        if (target) {
          try { showStep(target); } catch (_error) { /* no-op */ }
        }
      });
      buttons.next.__bound = true;
    }
    if (buttons.overview && !buttons.overview.__bound) {
      buttons.overview.addEventListener("click", () => {
        if (!hasPanels()) return;
        try { showStep("overview"); } catch (_error) { /* no-op */ }
      });
      buttons.overview.__bound = true;
    }
    return buttons;
  }

  function render(input) {
    try {
      const options = input && typeof input === "object" ? input : {};
      const footerInner = options.footerInner || element("wizardFooterInner");
      const buttons = ensureButtons({ footerInner, existing: options.existing });
      if (!footerInner) return Object.assign({ decision: null, viewState: null }, buttons);
      const snapshot = options.snapshot && typeof options.snapshot === "object"
        ? options.snapshot
        : readSnapshot();
      const decision = getFooterDecision(options.step, snapshot, options.overrides);
      const viewState = getFooterViewState(decision);
      applyViewState(buttons, options.addInline || null, viewState);
      const step = decision.step;
      try { footerInner.dataset.currentStep = step; } catch (_error) { /* no-op */ }
      [buttons.prev, buttons.next, buttons.overview].forEach((button) => {
        try { if (button) button.dataset.currentStep = step; } catch (_error) { /* no-op */ }
      });
      bindWizardFooter(Object.assign({}, options, {
        footerInner,
        prevBtn: buttons.prev,
        nextBtn: buttons.next,
        overviewBtn: buttons.overview,
      }));
      return Object.assign({ decision, viewState, addInline: options.addInline || null }, buttons);
    } catch (_error) {
      return { prev: null, next: null, overview: null, addInline: null, decision: null, viewState: null };
    }
  }

  function bindOverview(input) {
    const options = input && typeof input === "object" ? input : {};
    const closeBtn = options.closeBtn || null;
    const backBtn = options.backBtn || null;
    const closeOverview = typeof options.closeOverview === "function"
      ? options.closeOverview
      : () => {};
    const showStep = typeof options.showStep === "function"
      ? options.showStep
      : (target) => {
          try {
            if (rootRef && typeof rootRef.__showWizardStep === "function") {
              rootRef.__showWizardStep(target);
            }
          } catch (_error) { /* no-op */ }
        };
    const getOverviewReturnStep = typeof options.getOverviewReturnStep === "function"
      ? options.getOverviewReturnStep
      : () => text(rootRef && rootRef.__overviewReturnStep) || "customer";
    function backFromOverview() {
      try { closeOverview(); } catch (_error) { /* no-op */ }
      let target = getOverviewReturnStep() || "customer";
      target = prevTarget("overview", target, options) || target || "customer";
      try { showStep(target); } catch (_error) {
        try { showStep("customer"); } catch (_fallbackError) { /* no-op */ }
      }
    }
    if (closeBtn && !closeBtn.__bound) {
      closeBtn.addEventListener("click", backFromOverview);
      closeBtn.__bound = true;
    }
    if (backBtn && !backBtn.__bound) {
      backBtn.addEventListener("click", backFromOverview);
      backBtn.__bound = true;
    }
    return { close: closeBtn || null, back: backBtn || null };
  }

  function ensurePlacementAnchor() {
    try {
      const footer = element("wizardFooter");
      if (!footer) return false;
      if (placementAnchor) return true;
      if (!documentRef || typeof documentRef.createComment !== "function") return false;
      placementAnchor = documentRef.createComment("R9H wizard footer original position");
      if (!footer.parentNode || typeof footer.parentNode.insertBefore !== "function") {
        placementAnchor = null;
        return false;
      }
      footer.parentNode.insertBefore(placementAnchor, footer);
      return true;
    } catch (_error) {
      placementAnchor = null;
      return false;
    }
  }

  function place(mode, container) {
    try {
      const action = text(mode).toLowerCase();
      const footer = element("wizardFooter");
      if (!footer) return false;
      if (action === "anchor") return ensurePlacementAnchor();
      if (action === "attach") {
        if (!container || typeof container.appendChild !== "function") return false;
        if (!ensurePlacementAnchor()) return false;
        if (footer.parentNode !== container) container.appendChild(footer);
        return true;
      }
      if (action === "restore") {
        if (
          placementAnchor
          && placementAnchor.parentNode
          && footer.parentNode !== placementAnchor.parentNode
          && typeof placementAnchor.parentNode.insertBefore === "function"
        ) placementAnchor.parentNode.insertBefore(footer, placementAnchor.nextSibling);
        return Boolean(placementAnchor && placementAnchor.parentNode);
      }
    } catch (_error) { /* no-op */ }
    return false;
  }

  function announceReady() {
    if (readyAnnounced) return false;
    try {
      if (!documentRef || typeof documentRef.dispatchEvent !== "function") return false;
      const EventConstructor = rootRef && (rootRef.CustomEvent || rootRef.Event);
      if (typeof EventConstructor !== "function") return false;
      readyAnnounced = true;
      documentRef.dispatchEvent(new EventConstructor("tool-a-footer-owner-ready"));
      return true;
    } catch (_error) {
      readyAnnounced = false;
      return false;
    }
  }

  return Object.freeze({
    BUILD: FOOTER_COMPONENT_BUILD,
    getDecision: getFooterDecision,
    getViewState: getFooterViewState,
    render,
    bindOverview,
    place,
    announceReady,
  });
}
