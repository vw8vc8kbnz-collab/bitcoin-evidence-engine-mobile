export const MOBILE_MATERIAL_CART_BUILD = "R9H_MOBILE_CART_COMPONENT_3";

function text(value) {
  return String(value == null ? "" : value).trim();
}

function escapeHtml(value) {
  return text(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function titleForMaterial(material, fallback) {
  const source = material || {};
  return text(
    source.publicName
    || source.displayName
    || source.productName
    || source.decorName
    || fallback
    || "Materiaal",
  );
}

function metaForMaterial(material) {
  const source = material || {};
  const bits = [];
  const family = text(
    source.primaryVisualFamily || source.visualFamily || source.decorType || "",
  );
  const thickness = Number(source.thicknessMm);
  const width = Number(source.sheetSizeMm && source.sheetSizeMm.width);
  const height = Number(source.sheetSizeMm && source.sheetSizeMm.height);
  if (family) bits.push(family);
  if (Number.isFinite(thickness) && thickness > 0) bits.push(`${thickness} mm`);
  if (
    Number.isFinite(width) && width > 0
    && Number.isFinite(height) && height > 0
  ) bits.push(`${width} × ${height} mm`);
  return bits.join(" · ") || "Gekozen materiaal";
}

export function getMobileMaterialCartModels(state) {
  const source = state && typeof state === "object" ? state : {};
  const activeKey = text(source.activeMaterialKey);
  const cart = Array.isArray(source.cart) ? source.cart : [];
  const extraPanels = Array.isArray(source.extraPanels) ? source.extraPanels : [];
  return (Array.isArray(source.materialBatches) ? source.materialBatches : [])
    .filter((batch) => batch && text(batch.key))
    .map((batch) => ({
      key: text(batch.key),
      title: titleForMaterial(batch.mat, batch.key),
      meta: metaForMaterial(batch.mat),
      material: batch.mat || null,
      active: text(batch.key) === activeKey,
      panelCount: cart.filter(
        (item) => text(item && item.materialKey) === text(batch.key),
      ).length + extraPanels.filter(
        (item) => text(item && item.materialKey) === text(batch.key),
      ).reduce((sum, item) => sum + Math.max(1, Number(item && item.qty) || 1), 0),
    }));
}

export function createMobileMaterialCartComponent({
  documentRef = globalThis.document,
  rootRef = globalThis,
  getState = () => rootRef.state || {},
  requestAnimationFrameImpl = rootRef.requestAnimationFrame,
  setTimeoutImpl = rootRef.setTimeout,
  matchMediaImpl = rootRef.matchMedia,
  addWindowEventListenerImpl = rootRef.addEventListener,
  applySwatchImpl = null,
  activateMaterialImpl = null,
  removeMaterialImpl = null,
  confirmRemoveImpl = null,
  showPanelsImpl = null,
} = {}) {
  let initialized = false;
  let restoreFocus = null;
  let pendingRemoveKey = "";

  function state() {
    try {
      const value = typeof getState === "function" ? getState() : {};
      return value && typeof value === "object" ? value : {};
    } catch (_error) {
      return {};
    }
  }

  function nodes() {
    if (!documentRef || typeof documentRef.getElementById !== "function") return {};
    return {
      trigger: documentRef.getElementById("mobileMaterialCartTrigger"),
      triggerSwatch: documentRef.getElementById("mobileMaterialCartTriggerSwatch"),
      triggerTitle: documentRef.getElementById("mobileMaterialCartTriggerTitle"),
      triggerMeta: documentRef.getElementById("mobileMaterialCartTriggerMeta"),
      triggerCount: documentRef.getElementById("mobileMaterialCartTriggerCount"),
      backdrop: documentRef.getElementById("mobileMaterialCartBackdrop"),
      sheet: documentRef.getElementById("mobileMaterialCartSheet"),
      handle: documentRef.getElementById("mobileMaterialCartHandle"),
      close: documentRef.getElementById("mobileMaterialCartClose"),
      subtitle: documentRef.getElementById("mobileMaterialCartSubtitle"),
      list: documentRef.getElementById("mobileMaterialCartList"),
      continueBtn: documentRef.getElementById("mobileMaterialCartContinue"),
    };
  }

  function isMobile() {
    try {
      return Boolean(
        typeof matchMediaImpl === "function"
        && matchMediaImpl.call(rootRef, "(max-width:700px)").matches,
      );
    } catch (_error) {
      return Number(rootRef && rootRef.innerWidth || 9999) <= 700;
    }
  }

  function scheduleFrame(callback) {
    try {
      if (typeof requestAnimationFrameImpl === "function") {
        requestAnimationFrameImpl.call(rootRef, callback);
        return;
      }
    } catch (_error) { /* fall through */ }
    callback();
  }

  function applySwatch(element, key, material, sourceState) {
    if (!element) return;
    try {
      if (typeof applySwatchImpl === "function") {
        applySwatchImpl(element, key, material, sourceState);
        return;
      }
      if (
        rootRef.ToolAMaterialSwatchRenderer
        && typeof rootRef.ToolAMaterialSwatchRenderer.applyDomSwatch === "function"
      ) {
        rootRef.ToolAMaterialSwatchRenderer.applyDomSwatch(element, {
          materialKey: key,
          material,
          state: sourceState,
          panelGrainAxis: "V",
        });
        return;
      }
    } catch (_error) { /* preserve image fallback */ }
    const url = text(material && (material.imageThumbUrl || material.imagePreviewUrl));
    if (url) element.style.backgroundImage = `url("${url.replace(/"/g, "%22")}")`;
  }

  function close(options) {
    const current = nodes();
    const body = documentRef && documentRef.body;
    const wasOpen = Boolean(
      body && body.classList && body.classList.contains("mobileMaterialCartOpen"),
    );
    try { body && body.classList.remove("mobileMaterialCartOpen"); } catch (_error) { /* no-op */ }
    if (current.trigger) current.trigger.setAttribute("aria-expanded", "false");
    if (current.sheet) current.sheet.setAttribute("aria-hidden", "true");
    if (current.backdrop && typeof setTimeoutImpl === "function") {
      setTimeoutImpl.call(rootRef, () => {
        try {
          if (!body.classList.contains("mobileMaterialCartOpen")) current.backdrop.hidden = true;
        } catch (_error) { /* no-op */ }
      }, 260);
    }
    if (wasOpen && !(options && options.restoreFocus === false)) {
      const target = restoreFocus
        && documentRef
        && typeof documentRef.contains === "function"
        && documentRef.contains(restoreFocus)
        ? restoreFocus
        : current.trigger;
      try {
        if (target) target.focus({ preventScroll: true });
      } catch (_error) {
        try { if (target) target.focus(); } catch (_focusError) { /* no-op */ }
      }
    }
    restoreFocus = null;
    if (!(options && options.keepPendingRemoval)) pendingRemoveKey = "";
  }

  function open() {
    try {
      const sourceState = state();
      const models = getMobileMaterialCartModels(sourceState);
      const current = nodes();
      if (!isMobile() || !models.length || !current.sheet || !current.backdrop) return false;
      render(sourceState);
      restoreFocus = documentRef.activeElement || current.trigger;
      current.backdrop.hidden = false;
      current.sheet.setAttribute("aria-hidden", "false");
      if (current.trigger) current.trigger.setAttribute("aria-expanded", "true");
      scheduleFrame(() => {
        try { documentRef.body.classList.add("mobileMaterialCartOpen"); } catch (_error) { /* no-op */ }
        try { if (current.close) current.close.focus({ preventScroll: true }); } catch (_error) { /* no-op */ }
      });
      return true;
    } catch (_error) {
      return false;
    }
  }

  function render(rawState) {
    try {
      const sourceState = rawState && typeof rawState === "object" ? rawState : state();
      const models = getMobileMaterialCartModels(sourceState);
      const current = nodes();
      if (!current.trigger || !current.list) return models;
      const active = models.find((model) => model.active) || models[0] || null;
      try {
        documentRef.body.classList.toggle("hasMobileMaterialCart", models.length > 0);
      } catch (_error) { /* no-op */ }
      current.trigger.hidden = models.length === 0;
      if (current.triggerTitle) {
        current.triggerTitle.textContent = models.length === 1 ? "Jouw materiaal" : "Jouw materialen";
      }
      if (current.triggerMeta) {
        current.triggerMeta.textContent = models.length === 1
          ? "1 gekozen · open"
          : `${models.length} gekozen · open`;
      }
      if (current.triggerCount) current.triggerCount.textContent = String(models.length);
      if (current.subtitle) {
        current.subtitle.textContent = models.length === 1
          ? "1 materiaal gekozen"
          : `${models.length} materialen gekozen`;
      }
      if (current.continueBtn) current.continueBtn.disabled = models.length === 0;
      if (pendingRemoveKey && !models.some((model) => model.key === pendingRemoveKey)) {
        pendingRemoveKey = "";
      }
      current.list.innerHTML = models.map((model) => `
      <div class="mobileMaterialCartRow ${model.active ? "isActive" : ""}" data-mobile-material-row="${escapeHtml(model.key)}">
        <button class="mobileMaterialCartSelect" type="button" data-mobile-material-select="${escapeHtml(model.key)}" aria-pressed="${model.active ? "true" : "false"}">
          <span class="mobileMaterialCartSwatch" data-mobile-material-swatch="${escapeHtml(model.key)}" aria-hidden="true"></span>
          <span class="mobileMaterialCartRowCopy">
            <span class="mobileMaterialCartRowTitle">${escapeHtml(model.title)}</span>
            <span class="mobileMaterialCartRowMeta">${escapeHtml(model.meta)}</span>
          </span>
          <span class="mobileMaterialCartActiveMark" aria-hidden="true">✓</span>
        </button>
        <button class="mobileMaterialCartRemove" type="button" data-mobile-material-remove="${escapeHtml(model.key)}" aria-label="${escapeHtml(model.title)} verwijderen">🗑️</button>
        ${pendingRemoveKey === model.key ? `<div class="mobileMaterialCartConfirm" role="group" aria-label="Verwijderen bevestigen">
          <span>${model.panelCount > 0 ? `Verwijder ook ${model.panelCount} gekoppelde pane${model.panelCount === 1 ? "el" : "len"}?` : "Dit materiaal verwijderen?"}</span>
          <span class="mobileMaterialCartConfirmActions">
            <button type="button" data-mobile-material-remove-cancel="${escapeHtml(model.key)}">Behouden</button>
            <button type="button" class="isDanger" data-mobile-material-remove-confirm="${escapeHtml(model.key)}">Verwijderen</button>
          </span>
        </div>` : ""}
      </div>`).join("");
      if (active && current.triggerSwatch) {
        applySwatch(current.triggerSwatch, active.key, active.material, sourceState);
      }
      models.forEach((model) => {
        const swatch = Array.from(
          current.list.querySelectorAll("[data-mobile-material-swatch]"),
        ).find(
          (element) => text(element.getAttribute("data-mobile-material-swatch")) === model.key,
        );
        applySwatch(swatch, model.key, model.material, sourceState);
      });
      if (!models.length) close({ restoreFocus: false });
      return models;
    } catch (_error) {
      return [];
    }
  }

  function activate(key) {
    const cleanKey = text(key);
    try {
      if (typeof activateMaterialImpl === "function") activateMaterialImpl(cleanKey);
      else if (
        rootRef.ToolAPanelsEntry
        && typeof rootRef.ToolAPanelsEntry.activateMaterial === "function"
      ) rootRef.ToolAPanelsEntry.activateMaterial(cleanKey);
      else if (typeof rootRef.__setActiveMaterial === "function") rootRef.__setActiveMaterial(cleanKey);
    } catch (_error) { /* no-op */ }
    render(state());
  }

  function remove(key) {
    const cleanKey = text(key);
    const model = getMobileMaterialCartModels(state()).find((item) => item.key === cleanKey);
    if (!model) return false;
    try {
      if (typeof removeMaterialImpl === "function") {
        removeMaterialImpl(cleanKey);
        return true;
      }
      if (typeof rootRef.removeMaterialBatch === "function") {
        rootRef.removeMaterialBatch(cleanKey);
        return true;
      }
      if (typeof rootRef.__removeMaterialBatch === "function") {
        rootRef.__removeMaterialBatch(cleanKey);
        return true;
      }
      if (
        rootRef.ToolAPanelsEntry
        && typeof rootRef.ToolAPanelsEntry.removeMaterial === "function"
        && typeof rootRef.ToolAPanelsEntry.raw?.removeMaterial === "function"
      ) {
        rootRef.ToolAPanelsEntry.removeMaterial(cleanKey);
        return true;
      }
    } catch (_error) { /* preserve no-throw mutation boundary */ }
    return false;
  }

  function cancelRemove() {
    pendingRemoveKey = "";
    render(state());
    return true;
  }

  function confirmRemove(key) {
    const cleanKey = text(key || pendingRemoveKey);
    if (!cleanKey) return false;
    pendingRemoveKey = "";
    let handled = false;
    try {
      if (typeof confirmRemoveImpl === "function") {
        confirmRemoveImpl(cleanKey);
        handled = true;
      } else if (
        rootRef.ToolAPanelsEntry
        && typeof rootRef.ToolAPanelsEntry.removeMaterialConfirmed === "function"
      ) {
        rootRef.ToolAPanelsEntry.removeMaterialConfirmed(cleanKey);
        handled = true;
      } else if (typeof rootRef.__removeMaterialBatchConfirmed === "function") {
        rootRef.__removeMaterialBatchConfirmed(cleanKey);
        handled = true;
      } else if (typeof rootRef.removeMaterialBatch === "function") {
        rootRef.removeMaterialBatch(cleanKey);
        handled = true;
      } else if (typeof rootRef.__removeMaterialBatch === "function") {
        rootRef.__removeMaterialBatch(cleanKey);
        handled = true;
      }
    } catch (_error) {
      handled = false;
    }
    render(state());
    return handled;
  }

  function showPanels() {
    try {
      if (typeof showPanelsImpl === "function") showPanelsImpl();
      else if (typeof rootRef.__showWizardStep === "function") rootRef.__showWizardStep("panels");
      else if (typeof rootRef.showStep === "function") rootRef.showStep("panels");
    } catch (_error) { /* no-op */ }
  }

  function init() {
    if (initialized) return true;
    const current = nodes();
    if (!current.trigger || !current.sheet || !current.list) return false;
    initialized = true;
    current.trigger.addEventListener("click", open);
    if (current.backdrop) current.backdrop.addEventListener("click", () => close());
    if (current.close) current.close.addEventListener("click", () => close());
    if (current.handle) current.handle.addEventListener("click", () => close());
    if (current.continueBtn) {
      current.continueBtn.addEventListener("click", () => {
        close({ restoreFocus: false });
        showPanels();
      });
    }
    current.list.addEventListener("click", (event) => {
      const target = event.target;
      const confirmButton = target && target.closest
        ? target.closest("[data-mobile-material-remove-confirm]") : null;
      if (confirmButton) {
        event.preventDefault();
        event.stopPropagation();
        confirmRemove(text(confirmButton.getAttribute("data-mobile-material-remove-confirm")));
        return;
      }
      const keepButton = target && target.closest
        ? target.closest("[data-mobile-material-remove-cancel]") : null;
      if (keepButton) {
        event.preventDefault();
        event.stopPropagation();
        cancelRemove();
        return;
      }
      const removeButton = target && target.closest
        ? target.closest("[data-mobile-material-remove]") : null;
      if (removeButton) {
        event.preventDefault();
        event.stopPropagation();
        remove(text(removeButton.getAttribute("data-mobile-material-remove")));
        return;
      }
      const selectButton = target && target.closest
        ? target.closest("[data-mobile-material-select]") : null;
      if (selectButton) {
        event.preventDefault();
        activate(text(selectButton.getAttribute("data-mobile-material-select")));
      }
    });
    documentRef.addEventListener("keydown", (event) => {
      if (
        event.key === "Escape"
        && documentRef.body.classList.contains("mobileMaterialCartOpen")
      ) {
        event.preventDefault();
        close();
      }
    });
    documentRef.addEventListener("adzaagt-material-selection-updated", () => render(state()));
    if (typeof addWindowEventListenerImpl === "function") {
      addWindowEventListenerImpl.call(rootRef, "resize", () => {
        if (!isMobile()) close({ restoreFocus: false });
      }, { passive: true });
    }
    render(state());
    return true;
  }

  return Object.freeze({
    BUILD: MOBILE_MATERIAL_CART_BUILD,
    getModels: getMobileMaterialCartModels,
    init,
    render,
    open,
    close,
    remove,
    confirmRemove,
    cancelRemove,
  });
}
