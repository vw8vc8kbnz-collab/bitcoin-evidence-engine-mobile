export const MATERIAL_CARD_COMPONENT_BUILD = "R9H_MATERIAL_CARD_COMPONENT_5";

const EAGER_IMAGE_COUNT = 4;

function text(value) {
  return String(value == null ? "" : value).trim();
}

function escapeHtml(value) {
  return String(value == null ? "" : value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function keyOf(material) {
  return text(material?.publicMaterialId || material?.articleNumber || material?.materialCode);
}

function nameOf(material) {
  return text(
    material?.publicName || material?.displayName || material?.productName
    || material?.decorName || "Decor",
  );
}

function brandOf(material) {
  return text(material?.brand || "Overig") || "Overig";
}

function familyOf(material) {
  return text(
    material?.primaryVisualFamily || material?.visualFamily
    || material?.decorType || "Onbekend",
  ) || "Onbekend";
}

function typeBucket(material) {
  const family = familyOf(material).toLowerCase();
  if (family === "hout") return "wood";
  if (family === "uni") return "uni";
  if (family === "steen & beton" || family === "steen" || family === "beton") return "stone";
  if (family === "metaal") return "metal";
  if (family === "textiel & leer" || family === "textiel") return "textile";
  if (family === "grafisch") return "graphic";
  if (family === "fantasie") return "fantasy";
  return "other";
}

function displayBrandOf(material) {
  const brand = brandOf(material);
  return typeBucket(material) === "wood" && brand.toLowerCase() === "overig"
    ? "Fineer"
    : brand;
}

function typeLabel(material) {
  return ({
    wood: "Hout",
    uni: "Uni",
    stone: "Steen & beton",
    metal: "Metaal",
    textile: "Textiel & leer",
    graphic: "Grafisch",
    fantasy: "Fantasie",
    other: "Decor",
  })[typeBucket(material)] || "Decor";
}

function substrateLabel(material) {
  const explicit = text(material?.substrateLabel);
  if (explicit) return explicit;
  return ({
    MDF: "MDF",
    SPAANPLAAT: "Spaanplaat",
    MULTIPLEX: "Multiplex",
    OVERIG: "Overig",
    ONBEKEND: "Onbekend",
  })[text(material?.substrateType).toUpperCase()] || "Onbekend";
}

function sheetSizeLabel(material) {
  const width = Number(material?.sheetSizeMm?.width);
  const height = Number(material?.sheetSizeMm?.height);
  if (!(width > 0) || !(height > 0)) return "";
  const format = (value) => (
    Number.isInteger(value)
      ? String(value)
      : String(Math.round(value * 10) / 10).replace(".", ",")
  );
  return `${format(height)} × ${format(width)} mm`;
}

function thicknessLabel(material) {
  const thickness = Number(material?.thicknessMm);
  return Number.isFinite(thickness) ? `${String(thickness).replace(".0", "")} mm` : "";
}

function placeholderSymbol(bucket) {
  if (bucket === "wood") return "▥";
  if (bucket === "stone") return "◫";
  if (bucket === "metal") return "▦";
  return "○";
}

export function getMaterialCardModel(material, options = {}) {
  const source = material && typeof material === "object" ? material : {};
  const key = keyOf(source);
  const bucket = typeBucket(source);
  const name = nameOf(source);
  const position = Number(options?.position);
  const imageSrc = text(source.imageThumbUrl);
  return Object.freeze({
    key,
    selected: Boolean(key && key === text(options?.activeMaterialKey)),
    name,
    brand: displayBrandOf(source),
    type: typeLabel(source),
    substrate: substrateLabel(source),
    thickness: thicknessLabel(source),
    sheetSize: sheetSizeLabel(source),
    bucket,
    imageSrc,
    imageAlt: name,
    imageEager: Number.isFinite(position) && position >= 0 && position < EAGER_IMAGE_COUNT,
    placeholderSymbol: placeholderSymbol(bucket),
  });
}

function thumbnailHtml(model) {
  if (model.imageSrc) {
    return `<img src="${escapeHtml(model.imageSrc)}" alt="${escapeHtml(model.imageAlt)}" data-decor-image-type="${escapeHtml(model.bucket)}" loading="${model.imageEager ? "eager" : "lazy"}" decoding="async"${model.imageEager ? ' fetchpriority="high"' : ""}>`;
  }
  return `<div class="decorPlaceholder " data-type="${escapeHtml(model.bucket)}" aria-hidden="true">${model.placeholderSymbol}</div>`;
}

export function renderMaterialCard(material, options = {}) {
  const model = getMaterialCardModel(material, options);
  return `<button class="decorCard${model.selected ? " is-selected" : ""}" type="button" data-decor-id="${escapeHtml(model.key)}" aria-pressed="${model.selected ? "true" : "false"}">
      <div class="decorCardMedia">${thumbnailHtml(model)}<span class="decorSelectedCheck">✓</span></div>
      <div class="decorCardBody"><div class="decorBrand">${escapeHtml(model.brand)}</div><div class="decorName">${escapeHtml(model.name)}</div><div class="decorTags"><span class="decorTag">${escapeHtml(model.type)}</span><span class="decorTag">${escapeHtml(model.substrate)}</span>${model.thickness ? `<span class="decorTag">${escapeHtml(model.thickness)}</span>` : ""}${model.sheetSize ? `<span class="decorTag">${escapeHtml(model.sheetSize)}</span>` : ""}</div></div>
    </button>`;
}

export function createMaterialCardComponent({
  documentRef = globalThis.document,
  rootRef = globalThis,
} = {}) {
  const boundGrids = new WeakSet();
  const boundFallbackRoots = new WeakSet();
  let readyAnnounced = false;

  function bindImageFallback(root) {
    if (!root || typeof root.addEventListener !== "function" || boundFallbackRoots.has(root)) {
      return false;
    }
    root.addEventListener("error", (event) => {
      try {
        const image = event?.target;
        if (
          !image
          || text(image.tagName).toUpperCase() !== "IMG"
          || typeof image.hasAttribute !== "function"
          || !image.hasAttribute("data-decor-image-type")
        ) return;
        if (!documentRef || typeof documentRef.createElement !== "function") return;
        const fallback = documentRef.createElement("div");
        const bucket = text(image.getAttribute("data-decor-image-type")) || "other";
        fallback.className = "decorPlaceholder";
        fallback.dataset.type = bucket;
        fallback.setAttribute("aria-hidden", "true");
        fallback.textContent = placeholderSymbol(bucket);
        if (typeof image.replaceWith === "function") image.replaceWith(fallback);
        else if (typeof image.remove === "function") image.remove();
      } catch (_error) { /* no-throw UI fallback */ }
    }, true);
    boundFallbackRoots.add(root);
    return true;
  }

  function bind(input = {}) {
    try {
      const options = input && typeof input === "object" ? input : {};
      const grid = options.grid || null;
      const fallbackRoot = options.fallbackRoot || grid;
      bindImageFallback(fallbackRoot);
      if (!grid || typeof grid.addEventListener !== "function") return false;
      if (boundGrids.has(grid)) return true;
      grid.addEventListener("click", (event) => {
        try {
          const button = event?.target?.closest?.("[data-decor-id]");
          if (!button || (typeof grid.contains === "function" && !grid.contains(button))) return;
          const id = text(button.getAttribute?.("data-decor-id"));
          const catalog = typeof options.getCatalog === "function"
            ? options.getCatalog()
            : options.catalog;
          const rows = Array.isArray(catalog) ? catalog : [];
          const material = rows.find((item) => keyOf(item) === id);
          if (!material || typeof options.onSelect !== "function") return;
          const selectedKey = typeof options.getSelectedKey === "function"
            ? text(options.getSelectedKey())
            : text(options.activeMaterialKey);
          options.onSelect(material, Object.freeze({
            id,
            wasSelected: Boolean(id && id === selectedKey),
          }));
        } catch (_error) { /* no-throw event boundary */ }
      });
      boundGrids.add(grid);
      return true;
    } catch (_error) {
      return false;
    }
  }

  function announceReady() {
    if (readyAnnounced) return false;
    try {
      if (!documentRef || typeof documentRef.dispatchEvent !== "function") return false;
      const EventConstructor = rootRef && (rootRef.CustomEvent || rootRef.Event);
      if (typeof EventConstructor !== "function") return false;
      readyAnnounced = true;
      documentRef.dispatchEvent(new EventConstructor("tool-a-material-card-owner-ready"));
      return true;
    } catch (_error) {
      readyAnnounced = false;
      return false;
    }
  }

  return Object.freeze({
    BUILD: MATERIAL_CARD_COMPONENT_BUILD,
    getModel: getMaterialCardModel,
    render: renderMaterialCard,
    bind,
    announceReady,
  });
}
