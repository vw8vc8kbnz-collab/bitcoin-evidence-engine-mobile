export const PANEL_EDITOR_COMPONENT_BUILD = "R9H_PANEL_EDITOR_COMPONENT_6";

function text(value) {
  return String(value == null ? "" : value);
}

function integer(value, fallback = 0) {
  const number = Number(value);
  return Number.isFinite(number) ? Math.round(number) : fallback;
}

function resolveOwner(explicitOwner, rootRef, globalName, method) {
  const owner = explicitOwner || rootRef?.[globalName] || null;
  return owner && typeof owner[method] === "function" ? owner : null;
}

function callSafely(callback, ...args) {
  try {
    return typeof callback === "function" ? callback(...args) : undefined;
  } catch (_error) {
    return undefined;
  }
}

function clearGrainState(state, hooks = {}) {
  if (typeof hooks.clearAllGrainAssignments === "function") {
    callSafely(hooks.clearAllGrainAssignments);
    return;
  }
  if (!state || typeof state !== "object") return;
  if (!state.grain || typeof state.grain !== "object") state.grain = {};
  state.grain.groups = [];
  state.grain.selectedGroupId = null;
  if (Array.isArray(state.cart)) {
    state.cart.forEach((item) => {
      if (!item || typeof item !== "object") return;
      item.grainGroupId = null;
      item.grainOrder = null;
    });
  }
}

export function createPanelEditorComponent({
  documentRef = globalThis.document,
  rootRef = globalThis,
} = {}) {
  const boundElements = new WeakMap();
  let readyAnnounced = false;

  function bindOnce(element, type, key, callback) {
    if (!element || typeof element.addEventListener !== "function") return false;
    let keys = boundElements.get(element);
    if (!keys) {
      keys = new Set();
      boundElements.set(element, keys);
    }
    const bindingKey = `${type}:${key}`;
    if (keys.has(bindingKey)) return true;
    element.addEventListener(type, callback);
    keys.add(bindingKey);
    return true;
  }

  function submitStandard(input = {}) {
    const owner = resolveOwner(input.submitOwner, rootRef, "ToolAPanelSubmitApply", "execute");
    if (!owner) return Object.freeze({ ok: false, reason: "missing-standard-submit-owner" });
    try {
      return owner.execute(input) || Object.freeze({ ok: false, reason: "empty-standard-submit-result" });
    } catch (_error) {
      return Object.freeze({ ok: false, reason: "standard-submit-failed" });
    }
  }

  function submitExtra(input = {}) {
    const owner = resolveOwner(input.submitOwner, rootRef, "ToolAExtraPanelSubmitApply", "execute");
    if (!owner) return Object.freeze({ ok: false, reason: "missing-extra-submit-owner" });
    try {
      return owner.execute(input) || Object.freeze({ ok: false, reason: "empty-extra-submit-result" });
    } catch (_error) {
      return Object.freeze({ ok: false, reason: "extra-submit-failed" });
    }
  }

  function removeStandard(input = {}) {
    const state = input.state;
    const id = text(input.id).trim();
    if (!state || !Array.isArray(state.cart) || !id) {
      return Object.freeze({ ok: false, reason: "missing-standard-panel" });
    }
    const previousCount = state.cart.length;
    state.cart = state.cart.filter((item) => text(item?.id) !== id);
    if (state.cart.length === previousCount) {
      return Object.freeze({ ok: false, reason: "standard-panel-not-found" });
    }
    clearGrainState(state, input.hooks);
    if (input.isRemovingEdited) {
      callSafely(input.hooks?.resetPanelEntryFields);
      callSafely(input.hooks?.draw);
    }
    callSafely(input.hooks?.renderCart);
    callSafely(input.hooks?.renderExtraPanels);
    callSafely(input.hooks?.renderOverview);
    callSafely(input.hooks?.syncChecksFromSelect);
    callSafely(input.hooks?.drawExtraPreview);
    callSafely(input.hooks?.scheduleDraftSave);
    return Object.freeze({ ok: true, removedId: id, remaining: state.cart.length });
  }

  function removeExtra(input = {}) {
    const state = input.state;
    const index = integer(input.index, -1);
    if (!state || !Array.isArray(state.extraPanels) || index < 0 || index >= state.extraPanels.length) {
      return Object.freeze({ ok: false, reason: "extra-panel-not-found" });
    }
    clearGrainState(state, input.hooks);
    const [removed] = state.extraPanels.splice(index, 1);
    if (integer(input.editIndex, -1) === index) callSafely(input.hooks?.setEditIndex, null);
    callSafely(input.hooks?.renderExtraPanels);
    callSafely(input.hooks?.renderCart);
    callSafely(input.hooks?.renderOverview);
    callSafely(input.hooks?.scheduleDraftSave);
    callSafely(input.hooks?.updatePriceBar);
    callSafely(input.hooks?.syncChecksFromSelect);
    callSafely(input.hooks?.drawExtraPreview);
    return Object.freeze({ ok: true, removedId: text(removed?.id), remaining: state.extraPanels.length });
  }

  function getStandardEditSnapshot(item, options = {}) {
    const owner = resolveOwner(options.formStateOwner, rootRef, "ToolAPanelFormState", "getEditPrefillSnapshot");
    if (owner) return owner.getEditPrefillSnapshot(item, options);
    const source = item || {};
    const custom = text(source.customName || source.customLabel).trim();
    const label = text(source.label).trim();
    const base = text(source.baseLabel || source.templateId).trim();
    return Object.freeze({
      type: text(source.type).trim(),
      templateId: text(source.templateId).trim(),
      qty: Math.max(1, integer(options.originalCount, 1)),
      hinge: text(source.hinge || "left").trim() || "left",
      extTop: Number(source.extTop) || 0,
      extBot: Number(source.extBot) || 0,
      customLabel: custom || (label && label !== base ? label : ""),
      showStep: "panels",
    });
  }

  function applyStandardPrefill(input = {}) {
    const owner = resolveOwner(input.formApplyOwner, rootRef, "ToolAPanelFormApply", "applyPrefill");
    return owner ? Boolean(owner.applyPrefill(input)) : false;
  }

  function resetStandard(input = {}) {
    const stateOwner = resolveOwner(input.formStateOwner, rootRef, "ToolAPanelFormState", "getResetSnapshot");
    const applyOwner = resolveOwner(input.formApplyOwner, rootRef, "ToolAPanelFormApply", "applyReset");
    if (!applyOwner) return false;
    const snapshot = input.snapshot || (stateOwner ? stateOwner.getResetSnapshot(input.options || {}) : null);
    if (!snapshot) return false;
    return Boolean(applyOwner.applyReset({ ...input, snapshot }));
  }

  function getExtraEditSnapshot(item, options = {}) {
    const owner = resolveOwner(options.mutationOwner, rootRef, "ToolAExtraPanelMutations", "getEditPrefillSnapshot");
    return owner ? owner.getEditPrefillSnapshot(item, options) : null;
  }

  function applyExtraPrefill(input = {}) {
    const owner = resolveOwner(input.formApplyOwner, rootRef, "ToolAExtraPanelFormApply", "applyPrefill");
    return owner ? Boolean(owner.applyPrefill(input)) : false;
  }

  function resetExtra(input = {}) {
    const mutationOwner = resolveOwner(input.mutationOwner, rootRef, "ToolAExtraPanelMutations", "getResetFormState");
    const applyOwner = resolveOwner(input.formApplyOwner, rootRef, "ToolAExtraPanelFormApply", "applyReset");
    if (!mutationOwner || !applyOwner) return false;
    const snapshot = input.snapshot || mutationOwner.getResetFormState(input.options || {});
    return Boolean(applyOwner.applyReset({ ...input, snapshot }));
  }

  function bind(input = {}) {
    try {
      const standardButton = input.standardAddButton || null;
      const extraButton = input.extraAddButton || null;
      let bound = false;
      bound = bindOnce(standardButton, "click", "standard-submit", () => {
        const context = callSafely(input.getStandardSubmitInput);
        submitStandard(context && typeof context === "object" ? context : {});
      }) || bound;
      bound = bindOnce(extraButton, "click", "extra-submit", () => {
        const context = callSafely(input.getExtraSubmitInput);
        submitExtra(context && typeof context === "object" ? context : {});
      }) || bound;
      const previewInputs = Array.isArray(input.extraPreviewInputs) ? input.extraPreviewInputs : [];
      previewInputs.forEach((element) => {
        bound = bindOnce(element, "input", "extra-preview", () => callSafely(input.drawExtraPreview)) || bound;
        bound = bindOnce(element, "change", "extra-preview", () => callSafely(input.drawExtraPreview)) || bound;
      });
      if (input.extraNameInput) {
        bound = bindOnce(input.extraNameInput, "input", "extra-name-preview", () => callSafely(input.drawExtraPreview)) || bound;
      }
      const edgeInputs = Array.isArray(input.extraEdgeInputs) ? input.extraEdgeInputs : [];
      edgeInputs.forEach((element) => {
        bound = bindOnce(element, "change", "extra-edge-sync", () => callSafely(input.syncExtraEdges)) || bound;
      });
      return bound;
    } catch (_error) {
      return false;
    }
  }

  function announceReady() {
    if (readyAnnounced) return false;
    try {
      if (!documentRef || typeof documentRef.dispatchEvent !== "function") return false;
      const EventConstructor = rootRef && (rootRef.CustomEvent || rootRef.Event);
      if (typeof EventConstructor !== "function") return false;
      readyAnnounced = true;
      documentRef.dispatchEvent(new EventConstructor("tool-a-panel-editor-owner-ready"));
      return true;
    } catch (_error) {
      readyAnnounced = false;
      return false;
    }
  }

  return Object.freeze({
    BUILD: PANEL_EDITOR_COMPONENT_BUILD,
    bind,
    submitStandard,
    submitExtra,
    removeStandard,
    removeExtra,
    getStandardEditSnapshot,
    applyStandardPrefill,
    resetStandard,
    getExtraEditSnapshot,
    applyExtraPrefill,
    resetExtra,
    announceReady,
  });
}
