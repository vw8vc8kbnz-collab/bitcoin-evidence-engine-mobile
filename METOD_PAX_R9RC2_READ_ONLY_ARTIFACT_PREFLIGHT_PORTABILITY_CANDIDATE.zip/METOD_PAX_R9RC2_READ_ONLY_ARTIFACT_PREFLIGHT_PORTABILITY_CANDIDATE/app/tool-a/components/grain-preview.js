export const GRAIN_PREVIEW_COMPONENT_BUILD = "R9H_GRAIN_PREVIEW_COMPONENT_7";

export function createGrainPreviewComponent({
  documentRef = globalThis.document,
  rootRef = globalThis,
} = {}) {
  const boundHosts = new WeakSet();
  const observers = new WeakMap();
  let scheduledFrame = 0;
  let scheduledHost = null;
  let readyAnnounced = false;

  function measuredBox(host) {
    if (!host || host.isConnected === false || typeof host.getBoundingClientRect !== "function") return null;
    const rect = host.getBoundingClientRect();
    const width = Math.round(Number(rect?.width || 0) * 100) / 100;
    const height = Math.round(Number(rect?.height || 0) * 100) / 100;
    return width > 0 && height > 0 ? { width, height } : null;
  }

  function getHost(explicitHost) {
    return explicitHost || documentRef?.getElementById?.("grainPreview") || null;
  }

  function getRenderer() {
    const renderer = rootRef?.ToolAGrainStudioRenderer;
    return renderer && typeof renderer.render === "function" ? renderer : null;
  }

  function render(options = {}) {
    const host = getHost(options.container);
    const renderer = options.renderer || getRenderer();
    if (!host || !renderer || typeof renderer.render !== "function") return false;
    if (options.prepare === true && typeof renderer.prepareHost === "function") {
      renderer.prepareHost(host);
    }
    renderer.render(host);
    return true;
  }

  function schedule(options = {}) {
    scheduledHost = getHost(options.container) || scheduledHost;
    if (!scheduledHost || !getRenderer()) return false;
    // A hidden overlay has a zero-sized preview host. Rendering into it can
    // create a self-sustaining ResizeObserver/layout feedback cycle in WebKit.
    // The observer will schedule once the host obtains a real visible box.
    if (options.requireVisible !== false && !measuredBox(scheduledHost)) {
      scheduledHost = null;
      return false;
    }
    const cancelFrame = rootRef?.cancelAnimationFrame?.bind(rootRef);
    const requestFrame = rootRef?.requestAnimationFrame?.bind(rootRef);
    if (scheduledFrame && cancelFrame) cancelFrame(scheduledFrame);
    const run = () => {
      scheduledFrame = 0;
      const host = scheduledHost;
      scheduledHost = null;
      render({ container: host });
    };
    if (requestFrame) scheduledFrame = requestFrame(run);
    else run();
    return true;
  }

  function bind(options = {}) {
    const host = getHost(options.container);
    if (!host) return false;
    if (!boundHosts.has(host)) {
      boundHosts.add(host);
      const Observer = options.ResizeObserver || rootRef?.ResizeObserver;
      if (typeof Observer === "function") {
        let lastWidth = -1;
        let lastHeight = -1;
        const observer = new Observer((entries = []) => {
          if (host.isConnected === false) return;
          const entry = entries.find?.(item => item?.target === host) || entries[0];
          const box = entry?.contentRect
            ? {
                width: Math.round(Number(entry.contentRect.width || 0) * 100) / 100,
                height: Math.round(Number(entry.contentRect.height || 0) * 100) / 100,
              }
            : measuredBox(host);
          if (!box || box.width <= 0 || box.height <= 0) return;
          if (box.width === lastWidth && box.height === lastHeight) return;
          lastWidth = box.width;
          lastHeight = box.height;
          schedule({ container: host });
        });
        observer.observe(host);
        observers.set(host, observer);
      }
    }
    schedule({ container: host });
    return true;
  }

  function productionReadiness() {
    const renderer = getRenderer();
    if (!renderer || typeof renderer.productionReadiness !== "function") {
      return {
        ok: false,
        required: 0,
        missing: [],
        invalid: [],
        problems: [{ code: "missing-preview-renderer", message: "De nerfpreview-renderer ontbreekt." }],
        token: "grain-data:v2:",
        message: "De nerfpreview-renderer ontbreekt.",
      };
    }
    return renderer.productionReadiness();
  }

  function groupDimensions(group) {
    const renderer = getRenderer();
    return renderer && typeof renderer.groupDims === "function" ? renderer.groupDims(group) : null;
  }

  function announceReady() {
    if (readyAnnounced || !documentRef?.dispatchEvent || !rootRef?.Event) return false;
    readyAnnounced = true;
    documentRef.dispatchEvent(new rootRef.Event("tool-a-grain-preview-owner-ready"));
    return true;
  }

  return Object.freeze({
    BUILD: GRAIN_PREVIEW_COMPONENT_BUILD,
    bind,
    render,
    schedule,
    productionReadiness,
    groupDimensions,
    announceReady,
  });
}
