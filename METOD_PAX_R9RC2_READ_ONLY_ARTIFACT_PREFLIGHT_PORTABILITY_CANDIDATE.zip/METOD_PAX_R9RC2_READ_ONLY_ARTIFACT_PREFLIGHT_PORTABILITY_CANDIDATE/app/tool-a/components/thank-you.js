export const THANK_YOU_COMPONENT_BUILD = "R9H_THANK_YOU_COMPONENT_9";

function clean(value) {
  return String(value == null ? "" : value).trim();
}

function escapeHtml(value) {
  return String(value == null ? "" : value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function firstFiniteNumber(values) {
  for (const value of values) {
    if (value == null || value === "") continue;
    const number = Number(value);
    if (Number.isFinite(number)) return number;
  }
  return null;
}

export function createThankYouComponent({
  documentRef = globalThis.document,
  rootRef = globalThis,
  getState = () => rootRef.state,
  hideProgress = null,
  resetConfiguration = null,
} = {}) {
  let overlay = null;
  let resetBusy = false;
  let readyAnnounced = false;

  function currentState() {
    try { return getState?.() || rootRef.state || {}; } catch (_error) { return rootRef.state || {}; }
  }

  function customerFrom(data) {
    const state = currentState();
    return data?.customer || state?.checkout?.customer || {};
  }

  function totalFrom(data) {
    const summary = data?.pricingSummary || {};
    return firstFiniteNumber([
      data?.priceInclVat,
      summary?.totalInclVat,
      summary?.total_incl_vat,
      summary?.grandTotalInclVat,
      summary?.grand_total_incl_vat,
    ]);
  }

  function formatTotal(data) {
    const total = totalFrom(data);
    if (total == null) return "Op aanvraag";
    try {
      return new Intl.NumberFormat("nl-NL", { style: "currency", currency: "EUR" }).format(total);
    } catch (_error) {
      return `€ ${total.toFixed(2)}`;
    }
  }

  function close() {
    const active = overlay;
    overlay = null;
    resetBusy = false;
    if (!active) return false;
    try { active.removeEventListener?.("click", handleEvent); } catch (_error) { /* no-op */ }
    try { active.remove?.(); } catch (_error) { /* no-op */ }
    return true;
  }

  function disableActions() {
    try {
      const closeButton = overlay?.querySelector?.("#submitThanksClose");
      const newButton = overlay?.querySelector?.("#submitThanksNew");
      if (closeButton) closeButton.disabled = true;
      if (newButton) newButton.disabled = true;
    } catch (_error) { /* no-op */ }
  }

  async function resetAndReload() {
    if (resetBusy) return false;
    resetBusy = true;
    disableActions();
    try {
      const reset = typeof resetConfiguration === "function"
        ? resetConfiguration
        : rootRef.__metodResetConfigurationHard;
      if (typeof reset === "function") {
        await reset();
        return true;
      }
    } catch (_error) { /* compatibility fallback below */ }
    close();
    try { rootRef.location?.reload?.(); } catch (_error) { /* no-op */ }
    return true;
  }

  function handleEvent(event) {
    const target = event?.target;
    if (!overlay || !target) return false;
    if (target === overlay) {
      event.preventDefault?.();
      close();
      return true;
    }
    const action = target.closest?.("#submitThanksClose, #submitThanksNew");
    if (!action) return false;
    event.preventDefault?.();
    event.stopImmediatePropagation?.();
    const result = resetAndReload();
    if (result && typeof result.catch === "function") result.catch(() => {});
    return true;
  }

  function bindOverlayClick(active) {
    if (active !== overlay) return;
    try { active.addEventListener?.("click", handleEvent); } catch (_error) { /* no-op */ }
  }

  function show(data = {}) {
    try {
      try {
        if (typeof hideProgress === "function") hideProgress();
      } catch (_error) { /* no-op */ }
      close();
      documentRef?.getElementById?.("submitThanksOverlay")?.remove?.();
      const active = documentRef?.createElement?.("div");
      if (!active) throw new Error("Thank-you DOM unavailable");
      overlay = active;
      resetBusy = false;
      active.id = "submitThanksOverlay";
      active.className = "submitThanksOverlay";

      const customer = customerFrom(data);
      const customerName = [
        customer?.name,
        customer?.fullName,
        [customer?.firstName, customer?.lastName].filter(Boolean).join(" "),
      ].find((value) => clean(value)) || "je aanvraag";
      const customerEmail = clean(customer?.email || customer?.mail);
      const requestId = clean(data?.requestId) || "Wordt verwerkt";
      const total = formatTotal(data);
      const safeCustomerName = escapeHtml(customerName);
      const safeCustomerEmail = escapeHtml(customerEmail);
      const safeRequestId = escapeHtml(requestId);
      const safeTotal = escapeHtml(total);
      const emailText = customerEmail
        ? ` <a href="mailto:${encodeURIComponent(customerEmail)}" class="tool-component-u-77dc4176bb0e">${safeCustomerEmail}</a>`
        : " het opgegeven e-mailadres";

      active.innerHTML = `
        <div class="submitThanksCard tool-component-u-a6f6d5170448" role="dialog" aria-modal="true" aria-labelledby="submitThanksTitle">
          <img src="assets/adzaagt_logo.png" alt="Adzaagt logo" class="tool-component-u-4299305cb0c7" />
          <div class="submitThanksEyebrow tool-component-u-c884c80384f9">✓ Aanvraag ontvangen</div>
          <h2 id="submitThanksTitle" class="submitThanksTitle tool-component-u-21eebdcd90d0">Bedankt voor je aanvraag${customerName !== "je aanvraag" ? `, ${safeCustomerName}` : ""}.</h2>
          <p class="submitThanksText tool-component-u-f7798fbdf3cc">Binnen <strong>2 werkdagen</strong> sturen wij de factuur naar${emailText}.<br>Je ontvangt per e-mail ook de verdere informatie over je aanvraag.</p>
          <div class="submitThanksAgreement tool-component-u-4cc165d131e2">Je bent akkoord gegaan met de totaalprijs van <strong>${safeTotal}</strong> incl. btw.</div>
          <div class="submitThanksInfo tool-component-u-9468221e1027">
            <div class="submitThanksInfoCard tool-component-u-4468e2f58b35">
              <div class="submitThanksInfoLabel tool-component-u-b913b3b31806">Totaalprijs incl. btw</div>
              <div class="submitThanksInfoValue tool-component-u-55e06a743308">${safeTotal}</div>
            </div>
            <div class="submitThanksInfoCard tool-component-u-4468e2f58b35">
              <div class="submitThanksInfoLabel tool-component-u-b913b3b31806">Referentie</div>
              <div class="submitThanksInfoValue tool-component-u-55e06a743308">${safeRequestId}</div>
            </div>
          </div>
          <div class="submitThanksActions tool-component-u-c36ec52ad7c4">
            <button type="button" class="submitThanksBtn submitThanksBtnSecondary tool-component-u-ffdb8980a5f8" id="submitThanksClose">Sluiten</button>
            <button type="button" class="submitThanksBtn submitThanksBtnPrimary tool-component-u-2ea108b708a6" id="submitThanksNew">Nieuwe configuratie</button>
          </div>
        </div>`;
      documentRef?.body?.appendChild?.(active);
      const defer = typeof rootRef.setTimeout === "function" ? rootRef.setTimeout.bind(rootRef) : null;
      if (defer) defer(() => bindOverlayClick(active), 50);
      else bindOverlayClick(active);
      return true;
    } catch (_error) {
      close();
      try { rootRef.alert?.("Bedankt voor je aanvraag. Binnen 2 werkdagen sturen wij de factuur naar het opgegeven e-mailadres."); } catch (__error) { /* no-op */ }
      return false;
    }
  }

  function isOpen() {
    return Boolean(overlay);
  }

  function announceReady() {
    if (readyAnnounced) return false;
    readyAnnounced = true;
    if (documentRef?.dispatchEvent && typeof rootRef.Event === "function") {
      documentRef.dispatchEvent(new rootRef.Event("tool-a-thank-you-owner-ready"));
    }
    return true;
  }

  return Object.freeze({
    BUILD: THANK_YOU_COMPONENT_BUILD,
    show,
    close,
    handleEvent,
    isOpen,
    announceReady,
  });
}
