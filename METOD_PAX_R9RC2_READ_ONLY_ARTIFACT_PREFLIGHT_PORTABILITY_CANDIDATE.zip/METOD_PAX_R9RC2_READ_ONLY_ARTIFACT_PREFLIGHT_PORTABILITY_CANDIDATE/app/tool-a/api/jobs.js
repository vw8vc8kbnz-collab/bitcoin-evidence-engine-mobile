const DEFAULT_MAX_TOTAL_MS = 30 * 60 * 1000;
const DEFAULT_MAX_STATUS_OUTAGE_MS = 2 * 60 * 1000;

function cleanText(value) {
  return String(value == null ? "" : value).trim();
}

function normalizeJobId(value) {
  const jobId = cleanText(value);
  if (!jobId) throw new TypeError("A job id is required");
  return jobId;
}

function safeProgressCallback(callback, progressPct, progressLabel) {
  if (typeof callback !== "function") return;
  try {
    callback(Object.freeze({
      progressPct,
      progressLabel,
    }));
  } catch (_error) {
    // Rendering may never break the authoritative polling lifecycle.
  }
}

export function buildJobTokenHeaders(accessToken) {
  const token = cleanText(accessToken);
  return token ? Object.freeze({ Authorization: `Bearer ${token}` }) : Object.freeze({});
}

export function authoritativeTotalInclVat(source) {
  const total = source?.pricingSummary?.totalInclVat;
  return total != null && Number.isFinite(Number(total)) ? Number(total) : null;
}

export function createJobsApi(options = {}) {
  const fetchImpl = typeof options.fetchImpl === "function"
    ? options.fetchImpl
    : (...args) => globalThis.fetch(...args);
  const now = typeof options.now === "function" ? options.now : () => Date.now();
  const sleep = typeof options.sleep === "function"
    ? options.sleep
    : (milliseconds) => new Promise((resolve) => globalThis.setTimeout(resolve, milliseconds));
  const maxTotalMs = Number.isFinite(Number(options.maxTotalMs))
    ? Math.max(1, Number(options.maxTotalMs))
    : DEFAULT_MAX_TOTAL_MS;
  const maxStatusOutageMs = Number.isFinite(Number(options.maxStatusOutageMs))
    ? Math.max(1, Number(options.maxStatusOutageMs))
    : DEFAULT_MAX_STATUS_OUTAGE_MS;

  function statusUrl(jobId) {
    return `/api/jobs/${encodeURIComponent(normalizeJobId(jobId))}/status`;
  }

  async function fetchStatus(jobId, accessToken) {
    return fetchImpl(statusUrl(jobId), {
      cache: "no-store",
      headers: buildJobTokenHeaders(accessToken),
    });
  }

  async function startJob(serializedPayload) {
    if (typeof serializedPayload !== "string" || !serializedPayload) {
      throw new TypeError("A serialized job payload is required");
    }
    return fetchImpl("/api/jobs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: serializedPayload,
    });
  }

  async function cancelJob({ jobId, accessToken, reason = "customer_cancelled" } = {}) {
    if (!jobId) return null;
    return fetchImpl("/api/jobs/cancel", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...buildJobTokenHeaders(accessToken),
      },
      body: JSON.stringify({ jobId, reason }),
    });
  }

  async function fetchPricingSummary({ jobId, accessToken } = {}) {
    try {
      const response = await fetchStatus(jobId, accessToken);
      if (!response.ok) return null;
      const data = await response.json().catch(() => null);
      const status = cleanText(data?.meta?.status).toLowerCase();
      if (!["done", "ready", "ok"].includes(status)) return null;
      const pricingSummary = data?.pricingSummary || null;
      return authoritativeTotalInclVat({ pricingSummary }) == null ? null : pricingSummary;
    } catch (_error) {
      return null;
    }
  }

  async function pollJob({ jobId, accessToken, onProgress } = {}) {
    const canonicalJobId = normalizeJobId(jobId);
    let shownPct = 3;
    let lastMessage = "Invoer veilig gecontroleerd";
    let lastProgressAt = now();
    let lastServerPct = 0;
    let lastStatus = "";
    const startedAt = now();
    let outageStartedAt = 0;
    let transientFailures = 0;

    safeProgressCallback(onProgress, shownPct, lastMessage);

    while (true) {
      if (now() - startedAt > maxTotalMs) {
        throw new Error("De optimalisatie duurt onverwacht lang. De aanvraag is niet verloren; controleer Admin of probeer de status opnieuw te laden.");
      }

      let response;
      let data;
      try {
        response = await fetchStatus(canonicalJobId, accessToken);
        if (!response.ok) {
          const terminalClientError = response.status >= 400
            && response.status < 500
            && ![408, 425, 429].includes(response.status);
          if (terminalClientError) {
            let serverMessage = "";
            try {
              const rawStatusBody = await response.text();
              try {
                const statusJson = JSON.parse(rawStatusBody);
                serverMessage = cleanText(
                  statusJson?.error
                  || statusJson?.message
                  || statusJson?.meta?.error
                  || statusJson?.meta?.progressMessage,
                );
              } catch (_error) {
                serverMessage = cleanText(rawStatusBody);
              }
            } catch (_error) {
              serverMessage = "";
            }
            const terminalError = new Error(
              serverMessage || `De jobstatus is definitief geweigerd (HTTP ${response.status}).`,
            );
            terminalError.httpStatus = response.status;
            terminalError.isUserFacing = true;
            terminalError.metodTerminalStatus = true;
            throw terminalError;
          }
          throw new Error(`Status HTTP ${response.status}`);
        }
        data = await response.json();
        transientFailures = 0;
        outageStartedAt = 0;
      } catch (statusError) {
        if (statusError?.metodTerminalStatus) throw statusError;
        transientFailures += 1;
        if (!outageStartedAt) outageStartedAt = now();
        if (now() - outageStartedAt > maxStatusOutageMs) {
          throw new Error("De serverstatus kon langere tijd niet worden opgehaald. De job kan nog op de server draaien; controleer Admin voordat je opnieuw indient.");
        }
        safeProgressCallback(
          onProgress,
          Math.max(1, shownPct),
          lastMessage || "Server verwerkt de optimalisatie…",
        );
        await sleep(Math.min(5000, 500 + transientFailures * 350));
        continue;
      }

      const status = cleanText(data?.meta?.status || "unknown").toLowerCase();
      if (status === "error") {
        throw new Error(data?.meta?.error || "De output kon niet volledig worden opgebouwd. Controleer de aanvraag in Admin.");
      }
      const message = cleanText(data?.meta?.progressMessage);
      if (message) lastMessage = message;
      const rawServerPct = data?.meta?.progressPct;
      let serverPct = Number.isFinite(Number(rawServerPct))
        ? Math.max(0, Math.min(100, Math.round(Number(rawServerPct))))
        : shownPct;
      if (serverPct > lastServerPct || status !== lastStatus) {
        lastProgressAt = now();
        lastServerPct = serverPct;
        lastStatus = status;
      }
      if (["done", "ready", "ok"].includes(status)) {
        shownPct = 100;
        safeProgressCallback(onProgress, 100, message || lastMessage || "Optimalisatie afgerond");
        return data;
      }
      if (now() - lastProgressAt > 90 * 1000) {
        lastMessage = "Deze optimalisatie duurt langer dan normaal; de server werkt verder…";
      }
      serverPct = Math.min(99, Math.max(shownPct, serverPct, 1));
      shownPct = serverPct;
      safeProgressCallback(onProgress, shownPct, message || lastMessage || "Bezig met optimaliseren…");
      await sleep(350);
    }
  }

  return Object.freeze({
    startJob,
    cancelJob,
    pollJob,
    fetchPricingSummary,
    authoritativeTotalInclVat,
  });
}

export const JOB_API_DEFAULTS = Object.freeze({
  maxTotalMs: DEFAULT_MAX_TOTAL_MS,
  maxStatusOutageMs: DEFAULT_MAX_STATUS_OUTAGE_MS,
});
