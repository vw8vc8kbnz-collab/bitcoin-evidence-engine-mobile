const SUBMIT_STATES = Object.freeze({
  IDLE: "idle",
  SUBMITTING: "submitting",
  COMMITTED: "committed",
  FAILED: "failed",
});

function cleanText(value) {
  return String(value == null ? "" : value).trim();
}

function submissionError(message, details = {}) {
  const error = new Error(message);
  Object.assign(error, details, { isUserFacing: true });
  return error;
}

function jobTokenHeaders(accessToken) {
  const token = cleanText(accessToken);
  return token ? { Authorization: `Bearer ${token}` } : {};
}

function submissionWirePayload(context) {
  const parentJobId = cleanText(context?.parentJobId || context?.jobId);
  if (!parentJobId) {
    throw submissionError("Geen afgeronde optimalisatie gevonden. Bereken de configuratie opnieuw.");
  }
  const customer = context?.customer;
  if (!customer || typeof customer !== "object" || Array.isArray(customer)) {
    throw submissionError("De klantgegevens konden niet veilig worden klaargezet.");
  }
  return {
    jobId: parentJobId,
    parentJobId,
    customer,
    note: String(context?.note == null ? "" : context.note),
  };
}

async function responseJson(response) {
  try {
    return await response.json();
  } catch (_error) {
    throw submissionError("De serverbevestiging kon niet worden gelezen. Probeer het opnieuw.");
  }
}

export function createRequestsApi(options = {}) {
  const fetchImpl = typeof options.fetchImpl === "function"
    ? options.fetchImpl
    : (...args) => globalThis.fetch(...args);

  async function submitConfiguration(context = {}) {
    const payload = submissionWirePayload(context);
    const response = await fetchImpl("/api/submit_config", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...jobTokenHeaders(context.accessToken),
      },
      body: JSON.stringify(payload),
    });
    const data = await responseJson(response);
    if (!response.ok || data?.ok === false) {
      throw submissionError(
        cleanText(data?.error || data?.message) || `Verzenden is geweigerd (HTTP ${response.status}).`,
        { httpStatus: response.status },
      );
    }
    const requestId = cleanText(data?.requestId);
    if (!requestId) {
      throw submissionError("De server bevestigde geen aanvraagreferentie. De aanvraag is niet als verzonden gemarkeerd.");
    }
    return Object.freeze({
      requestId,
      cancelToken: cleanText(data?.cancelToken),
      pricingSummary: data?.pricingSummary || null,
      response: data,
      parentJobId: payload.parentJobId,
      customer: payload.customer,
      note: payload.note,
    });
  }

  return Object.freeze({ submitConfiguration });
}

async function safeCallback(callback, value) {
  if (typeof callback !== "function") return null;
  try {
    await callback(value);
    return null;
  } catch (error) {
    return error;
  }
}

export function createFinalSubmitAction(options = {}) {
  const requestsApi = options.requestsApi || createRequestsApi(options);
  let status = SUBMIT_STATES.IDLE;
  let committedRequestId = "";
  let committedParentJobId = "";

  function getState() {
    return Object.freeze({ status, committedRequestId, committedParentJobId });
  }

  function reset() {
    status = SUBMIT_STATES.IDLE;
    committedRequestId = "";
    committedParentJobId = "";
    return getState();
  }

  async function submit(context = {}, callbacks = {}) {
    if (status === SUBMIT_STATES.SUBMITTING || status === SUBMIT_STATES.COMMITTED) {
      return Object.freeze({ ok: false, ignored: true, state: getState() });
    }

    const parentJobId = cleanText(context?.parentJobId || context?.jobId);
    if (!parentJobId) {
      const error = submissionError("Geen afgeronde optimalisatie gevonden. Bereken de configuratie opnieuw.");
      status = SUBMIT_STATES.FAILED;
      await safeCallback(callbacks.onFailed, Object.freeze({ error, state: getState() }));
      return Object.freeze({ ok: false, error, state: getState() });
    }
    if (context?.jobComplete !== true) {
      const error = submissionError("De optimalisatie is nog niet volledig afgerond. Wacht op de definitieve prijs.");
      status = SUBMIT_STATES.FAILED;
      await safeCallback(callbacks.onFailed, Object.freeze({ error, state: getState() }));
      return Object.freeze({ ok: false, error, state: getState() });
    }

    status = SUBMIT_STATES.SUBMITTING;
    await safeCallback(callbacks.onSubmitting, Object.freeze({ parentJobId, state: getState() }));
    try {
      const committed = await requestsApi.submitConfiguration({ ...context, parentJobId });
      committedRequestId = committed.requestId;
      committedParentJobId = parentJobId;
      status = SUBMIT_STATES.COMMITTED;
      const uiError = await safeCallback(
        callbacks.onCommitted,
        Object.freeze({ committed, state: getState() }),
      );
      return Object.freeze({ ok: true, committed, uiError, state: getState() });
    } catch (error) {
      status = SUBMIT_STATES.FAILED;
      await safeCallback(callbacks.onFailed, Object.freeze({ error, state: getState() }));
      return Object.freeze({ ok: false, error, state: getState() });
    } finally {
      await safeCallback(callbacks.onSettled, getState());
    }
  }

  return Object.freeze({ submit, reset, getState });
}

export { SUBMIT_STATES };
