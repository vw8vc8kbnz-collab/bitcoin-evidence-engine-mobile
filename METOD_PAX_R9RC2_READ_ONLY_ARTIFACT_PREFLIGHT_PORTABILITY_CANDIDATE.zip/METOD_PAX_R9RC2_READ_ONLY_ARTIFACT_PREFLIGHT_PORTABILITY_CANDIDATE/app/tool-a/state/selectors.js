const TOOL_A_STEPS = Object.freeze([
  "material",
  "panels",
  "grain",
  "customer",
  "overview",
]);

const EMPTY_CUSTOMER_SNAPSHOT = Object.freeze({
  firstName: "",
  lastName: "",
  company: "",
  email: "",
  phone: "",
  billingAddress: "",
  shippingAddress: "",
  shippingSameAsBilling: true,
  postcode: "",
  houseNumber: "",
  address1: "",
  address2: "",
  city: "",
  country: "",
});

function isRecord(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function list(value) {
  return Array.isArray(value) ? value : [];
}

function text(value) {
  return value === null || value === undefined ? "" : String(value).trim();
}

export function selectCurrentStep(state, runtime = {}) {
  const safeState = isRecord(state) ? state : {};
  const safeRuntime = isRecord(runtime) ? runtime : {};
  const requested = text(safeRuntime.uiStep || safeState.ui?.step || "material");
  return TOOL_A_STEPS.includes(requested) ? requested : "material";
}

export function selectActiveMaterialKey(state) {
  const safeState = isRecord(state) ? state : {};
  return text(safeState.activeMaterialKey || safeState.selection?.materialKey);
}

export function selectGrainMaterialKey(state) {
  const safeState = isRecord(state) ? state : {};
  const grainMaterialKey = text(safeState.grain?.materialKey);
  return grainMaterialKey || text(safeState.activeMaterialKey);
}

export function selectGrainEnabledForMaterial(state, materialKey) {
  const safeState = isRecord(state) ? state : {};
  const key = text(materialKey);
  if (!key) return true;
  const batch = list(safeState.materialBatches).find(
    (candidate) => String(candidate?.key || "") === key,
  );
  return typeof batch?.grainEnabled === "boolean" ? batch.grainEnabled : true;
}

export function selectIsGrainCapableItem(state, item) {
  const safeItem = isRecord(item) ? item : {};
  const materialKey = safeItem.materialKey || safeItem.materialCode || safeItem.articleNumber || "";
  if (!selectGrainEnabledForMaterial(state, materialKey)) return false;
  const selectedMaterialKey = selectGrainMaterialKey(state);
  return !selectedMaterialKey || String(materialKey) === selectedMaterialKey;
}

export function selectMaterialThickness(
  state,
  materialKey,
  materialCatalog = [],
  defaultThicknessMm = 18,
) {
  const safeState = isRecord(state) ? state : {};
  const key = String(materialKey || "").trim();
  const activeKey = String(safeState.activeMaterialKey || "").trim();
  const batch = key
    ? list(safeState.materialBatches).find(
      (candidate) => String(candidate && candidate.key) === String(key),
    )
    : null;
  const material = (batch && batch.mat)
    ? batch.mat
    : ((key && activeKey && key === activeKey) ? safeState.material : null)
      || safeState.material
      || null;
  const thickness = Number(material?.thicknessMm);
  if (Number.isFinite(thickness) && thickness > 0) return thickness;

  const catalogMaterial = list(materialCatalog).find(
    (candidate) => String(candidate?.articleNumber || "") === key
      || String(candidate?.materialCode || "") === key,
  );
  const catalogThickness = Number(catalogMaterial?.thicknessMm);
  if (Number.isFinite(catalogThickness) && catalogThickness > 0) {
    return catalogThickness;
  }
  return Number(safeState.material?.thicknessMm || defaultThicknessMm || 18);
}

export function selectMaterialSheetDimensions(state, materialKey, materialCatalog = []) {
  const safeState = isRecord(state) ? state : {};
  const key = String(materialKey || "").trim();
  const batch = list(safeState.materialBatches).find(
    (candidate) => String(candidate?.key || "") === key,
  );
  const material = batch?.mat
    || ((String(safeState.activeMaterialKey || "") === key) ? safeState.material : null)
    || safeState.material
    || null;
  const width = Number(material?.sheetSizeMm?.width || 0);
  const height = Number(material?.sheetSizeMm?.height || 0);
  if (Number.isFinite(width) && width > 0 && Number.isFinite(height) && height > 0) {
    return { width, height, mat: material };
  }

  const catalogMaterial = list(materialCatalog).find(
    (candidate) => String(candidate?.articleNumber || "") === key
      || String(candidate?.materialCode || "") === key,
  );
  const catalogWidth = Number(catalogMaterial?.sheetSizeMm?.width || 0);
  const catalogHeight = Number(catalogMaterial?.sheetSizeMm?.height || 0);
  if (
    Number.isFinite(catalogWidth)
    && catalogWidth > 0
    && Number.isFinite(catalogHeight)
    && catalogHeight > 0
  ) {
    return { width: catalogWidth, height: catalogHeight, mat: catalogMaterial };
  }
  return { width: 0, height: 0, mat: null };
}

export function selectUsableMaterialSheetDimensions(state, materialKey, materialCatalog = []) {
  const safeState = isRecord(state) ? state : {};
  const dimensions = selectMaterialSheetDimensions(safeState, materialKey, materialCatalog);
  const margin = Number(safeState.defaults?.sheetMarginMm ?? safeState.sheetMarginMm ?? 7);
  return {
    ...dimensions,
    margin,
    usableW: Math.max(0, dimensions.width - 2 * margin),
    usableH: Math.max(0, dimensions.height - 2 * margin),
  };
}

export function parseGrainReference(reference) {
  if (typeof reference === "number") {
    return { kind: "cart", idx: Number(reference), rep: null };
  }
  const value = text(reference);
  if (!value) return null;
  if (/^\d+$/.test(value)) {
    return { kind: "cart", idx: Number(value), rep: null };
  }
  const parts = value.split(":");
  if (parts[0] === "extra") {
    return { kind: "extra", idx: Number(parts[1]), rep: Number(parts[2] || 0) };
  }
  if (parts[0] === "cart") {
    return { kind: "cart", idx: Number(parts[1]), rep: null };
  }
  return null;
}

export function normalizeCustomerSnapshot(raw) {
  const customer = isRecord(raw) ? raw : {};
  const value = (key) => text(customer[key]);
  const billingAddress = value("billingAddress") || value("invoiceAddress") || value("address");
  const shippingSameAsBilling = typeof customer.shippingSameAsBilling === "boolean"
    ? customer.shippingSameAsBilling
    : true;
  const shippingAddress = shippingSameAsBilling
    ? billingAddress
    : (value("shippingAddress") || value("deliveryAddress") || value("address1"));

  return {
    firstName: value("firstName"),
    lastName: value("lastName"),
    company: value("company") || value("companyName"),
    email: value("email") || value("mail"),
    phone: value("phone") || value("telephone") || value("tel"),
    billingAddress,
    shippingAddress,
    shippingSameAsBilling,
    postcode: value("postcode") || value("postalCode"),
    houseNumber: value("houseNumber") || value("housenumber"),
    address1: shippingAddress || billingAddress,
    address2: value("address2"),
    city: value("city") || value("plaats"),
    country: value("country"),
  };
}

export function selectCustomerSnapshot(state, runtime = {}) {
  const safeState = isRecord(state) ? state : {};
  const safeRuntime = isRecord(runtime) ? runtime : {};
  const checkout = isRecord(safeState.checkout) ? safeState.checkout : {};
  const merged = {};
  const sources = [
    checkout.customer,
    safeRuntime.liveCustomer,
    checkout.customerSnapshot,
    safeState.lastCalculatedCustomer,
  ];

  for (const candidate of sources) {
    const normalized = normalizeCustomerSnapshot(candidate);
    for (const [key, value] of Object.entries(normalized)) {
      if (key === "shippingSameAsBilling") {
        if (isRecord(candidate) && typeof candidate.shippingSameAsBilling === "boolean") {
          merged[key] = candidate.shippingSameAsBilling;
        }
      } else if (text(value)) {
        merged[key] = value;
      }
    }
  }

  return Object.freeze(normalizeCustomerSnapshot(merged));
}

export function selectSafeToolAReadModel(state, runtime = {}) {
  const safeState = isRecord(state) ? state : {};
  const materialBatches = list(safeState.materialBatches);
  const standardPanels = list(safeState.cart);
  const extraPanels = list(safeState.extraPanels);
  const grainGroups = list(safeState.grain?.groups);
  const activeMaterialKey = selectActiveMaterialKey(safeState);
  const material = isRecord(safeState.material) ? safeState.material : {};
  const hasActiveMaterial = Boolean(
    activeMaterialKey
    || text(material.materialCode)
    || text(material.articleNumber)
    || text(material.decorName)
    || text(material.productName)
  );

  return Object.freeze({
    currentStep: selectCurrentStep(safeState, runtime),
    activeMaterialKey,
    materialBatchCount: materialBatches.length,
    standardPanelLineCount: standardPanels.length,
    extraPanelLineCount: extraPanels.length,
    grainGroupCount: grainGroups.length,
    hasActiveMaterial,
    hasPanels: standardPanels.length + extraPanels.length > 0,
  });
}

export { EMPTY_CUSTOMER_SNAPSHOT, TOOL_A_STEPS };
