import { EMPTY_CUSTOMER_SNAPSHOT, parseGrainReference, selectCustomerSnapshot, selectGrainEnabledForMaterial, selectGrainMaterialKey, selectIsGrainCapableItem, selectMaterialThickness, selectSafeToolAReadModel, selectUsableMaterialSheetDimensions } from "./selectors.js";

const EMPTY_LEGACY_SOURCE = Object.freeze({
  state: Object.freeze({}),
  runtime: Object.freeze({}),
});
const EMPTY_TOOL_A_STATE = selectSafeToolAReadModel(
  EMPTY_LEGACY_SOURCE.state,
  EMPTY_LEGACY_SOURCE.runtime,
);

export function createToolAStore(readSource = () => EMPTY_LEGACY_SOURCE) {
  if (typeof readSource !== "function") {
    throw new TypeError("R9G read-only Tool A store requires one source reader");
  }

  return Object.freeze({
    getSnapshot() {
      try {
        const source = readSource();
        if (source === null || typeof source !== "object" || Array.isArray(source)) {
          return EMPTY_TOOL_A_STATE;
        }
        return selectSafeToolAReadModel(source.state, source.runtime);
      } catch (_error) {
        return EMPTY_TOOL_A_STATE;
      }
    },
    getCustomerSnapshot() {
      try {
        const source = readSource();
        if (source === null || typeof source !== "object" || Array.isArray(source)) {
          return EMPTY_CUSTOMER_SNAPSHOT;
        }
        return selectCustomerSnapshot(source.state, source.runtime);
      } catch (_error) {
        return EMPTY_CUSTOMER_SNAPSHOT;
      }
    },
    normalizeCustomerSnapshot(source) {
      return selectCustomerSnapshot({ checkout: { customer: source } });
    },
    getGrainMaterialKey() {
      try {
        return selectGrainMaterialKey(readSource().state);
      } catch (_error) {
        return "";
      }
    },
    isGrainEnabledForMaterial(materialKey) {
      try {
        return selectGrainEnabledForMaterial(readSource().state, materialKey);
      } catch (_error) {
        return true;
      }
    },
    isGrainCapableItem(item) {
      try {
        return selectIsGrainCapableItem(readSource().state, item);
      } catch (_error) {
        return false;
      }
    },
    parseGrainReference(reference) {
      return parseGrainReference(reference);
    },
    getMaterialThickness(materialKey, materialCatalog, defaultThicknessMm) {
      try {
        return selectMaterialThickness(
          readSource().state,
          materialKey,
          materialCatalog,
          defaultThicknessMm,
        );
      } catch (_error) {
        return Number(defaultThicknessMm || 18);
      }
    },
    getUsableMaterialSheetDimensions(materialKey, materialCatalog) {
      try {
        return selectUsableMaterialSheetDimensions(
          readSource().state,
          materialKey,
          materialCatalog,
        );
      } catch (_error) {
        return { width: 0, height: 0, mat: null, margin: 7, usableW: 0, usableH: 0 };
      }
    },
  });
}

export { EMPTY_LEGACY_SOURCE, EMPTY_TOOL_A_STATE };
