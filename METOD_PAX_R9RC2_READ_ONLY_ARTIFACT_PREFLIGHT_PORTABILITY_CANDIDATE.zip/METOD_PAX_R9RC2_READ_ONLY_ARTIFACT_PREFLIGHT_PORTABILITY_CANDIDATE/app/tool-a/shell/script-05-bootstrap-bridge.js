
window.__RIGHTCOL_SCALE_BUILD = 'FIX409_FRONTEND_SINK_AUDIT';
window.__PRICE_OVERLAY_BUILD = 'FIX409_FRONTEND_SINK_AUDIT';
window.__TOOLA_UI_BUILD = 'FIX409_FRONTEND_SINK_AUDIT';
(function(){
  // Global-ish state holder (function-scoped var to avoid block-scope ReferenceError)
  var state;

  const banner = () => document.getElementById('metodDebugBanner');
  function _escapeHtml(v){
    return String(v == null ? '' : v)
      .replace(/&/g,'&amp;')
      .replace(/</g,'&lt;')
      .replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;')
      .replace(/'/g,'&#39;');
  }
  function show(msg){
    try{
      const el = banner();
      if(!el) return;
      el.style.display='block';
      el.innerHTML = "<b>METOD ToolA error</b><br>" + _escapeHtml(msg).replace(/\n/g,'<br>');
    }catch(e){}
  }
  window.addEventListener('error', (e)=>{
    const msg = (e && (e.message || e.error && e.error.message)) || String(e);
    const stack = (e && e.error && e.error.stack) ? "\n\n" + e.error.stack : "";
    show(msg + stack);
  });
  window.addEventListener('unhandledrejection', (e)=>{
    const reason = e && e.reason ? e.reason : e;
    const msg = (reason && reason.message) ? reason.message : String(reason);
    // Chrome extensions (including devtools / security add-ons) sometimes emit this noisy rejection.
    // It is unrelated to ToolA and should not confuse the user or spam the banner.
    if(msg.includes('A listener indicated an asynchronous response') && msg.includes('message channel closed')){
      return;
    }
    const stack = (reason && reason.stack) ? "\n\n" + reason.stack : "";
    show("Unhandled promise rejection: " + msg + stack);
  });
})();
