
/* FIX660R8W — an explicit new configuration owns a completely fresh customer.
   Safari may restore form controls during navigation, so clear once before the
   app reads them and once again after pageshow/layout restoration. */
(function(root){
  'use strict';
  const RESET_KEY='metod_fresh_configuration_v1';
  const FIELD_IDS=['custFirstName','custLastName','custCompany','custEmail','custPhone','custBillingAddress','custPostcode','custHouseNumber','custShippingAddress','custNote'];
  const CAPABILITY_KEYS=[
    'metod_last_job_access_token','metod_last_job_id','metod_last_parent_job_id',
    'metod_last_request_id','metod_last_request_cancel_token','metod_active_parent_job_id',
    'metod_price_validated_key','metod_submitted_parent_job_id'
  ];
  const MEMORY_CAPABILITY_KEYS=[
    '__metod_active_parent_job_id','__metod_last_job_access_token','__metod_last_job_id',
    '__metod_last_parent_job_id','__metod_last_request_cancel_token','__metod_last_request_id',
    '__metod_price_auto_opened_job_id','__metod_price_validated_key','__metod_submitted_parent_job_id'
  ];
  function clearCapabilities(){
    for(const key of MEMORY_CAPABILITY_KEYS){ try{ root[key]=null; }catch(_){ } }
    try{ root.__metod_price_locked=false; root.__metod_submit_done=false; root.__metod_submit_inflight=false; }catch(_){ }
    try{
      root.localStorage.removeItem('metod_draft_v1');
      root.localStorage.removeItem('metod_draft');
      for(const key of CAPABILITY_KEYS) root.localStorage.removeItem(key);
    }catch(_){ }
    try{ for(const key of CAPABILITY_KEYS) root.sessionStorage.removeItem(key); }catch(_){ }
    try{
      const st=root.state;
      if(st&&typeof st==='object'){
        st.activeAuthoritativeJobId=null;
        st.lastJobAccessToken=null;
        st.lastParentJobId=null;
        st.lastJobId=null;
        st.jobId=null;
      }
    }catch(_){ }
  }
  function clearCustomer(){
    try{ root.__metod_checkout_live_customer=null; }catch(_){ }
    for(const id of FIELD_IDS){
      try{ const field=root.document.getElementById(id); if(field) field.value=''; }catch(_){ }
    }
    try{ const same=root.document.getElementById('custShipSame'); if(same) same.checked=true; }catch(_){ }
    try{
      const st=root.state;
      if(st&&typeof st==='object'){
        st.customer={};
        st.checkout=st.checkout||{};
        st.checkout.customer={};
        st.checkout.customerSnapshot=null;
        st.checkout.note='';
        st.lastCalculatedCustomer=null;
      }
    }catch(_){ }
  }
  root.__metodClearCustomerConfiguration=clearCustomer;
  let requested=false;
  try{ requested=root.sessionStorage.getItem(RESET_KEY)==='1'; }catch(_){ }
  if(!requested) return;
  root.__metod_force_fresh_configuration=true;
  clearCapabilities();
  clearCustomer();
  root.document.addEventListener('DOMContentLoaded',()=>{ clearCapabilities(); clearCustomer(); },{capture:true,once:true});
  root.addEventListener('pageshow',()=>{
    clearCapabilities();
    clearCustomer();
    const finish=()=>{
      clearCapabilities();
      clearCustomer();
      try{ root.sessionStorage.removeItem(RESET_KEY); }catch(_){ }
      root.__metod_force_fresh_configuration=false;
      try{
        const url=new URL(root.location.href);
        if(url.searchParams.has('_freshConfig')){
          url.searchParams.delete('_freshConfig');
          root.history.replaceState(null,'',url.toString());
        }
      }catch(_){ }
    };
    try{ root.requestAnimationFrame(()=>root.requestAnimationFrame(finish)); }catch(_){ setTimeout(finish,0); }
  },{once:true});
})(window);
