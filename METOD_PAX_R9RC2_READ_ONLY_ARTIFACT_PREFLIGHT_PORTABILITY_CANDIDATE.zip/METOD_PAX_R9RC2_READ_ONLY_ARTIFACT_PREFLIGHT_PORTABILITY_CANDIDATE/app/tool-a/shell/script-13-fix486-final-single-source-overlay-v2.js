
(function(){
  function byId(id){ return document.getElementById(id); }
  function totalEl(){ return byId('priceOverlayTotal') || byId('priceTotalValue'); }
  function sendBtn(){ return byId('sendConfigBtn') || byId('btnSendConfig'); }
  function money(v){ try{ return (typeof moneyEUR==='function') ? moneyEUR(Number(v)) : String(v); }catch(_){ return String(v); } }
  function activeParentJobId(){
    try{
      const raw = String((window.state && state.activeAuthoritativeJobId) || window.__metod_active_parent_job_id || window.__metod_last_parent_job_id || '').trim();
      if(!raw) return '';
      return raw.includes('__mat_') ? raw.split('__mat_')[0] : raw;
    }catch(_){ return ''; }
  }
  function currentFinal(){
    try{
      const jid = activeParentJobId();
      const finalJid = String((window.state && state.finalAuthoritativeJobId) || '').trim();
      const total = window.state && state.finalAuthoritativePriceInclVat;
      if(!jid || !finalJid || jid !== finalJid) return null;
      if(total == null || !isFinite(Number(total))) return null;
      return Number(total);
    }catch(_){ return null; }
  }
  function blank(){
    try{ const el=totalEl(); if(el) el.textContent='—'; }catch(_){ }
    /* Never use the native disabled state for this CTA. On iOS a disabled
       button emits no click at all, so the canonical submit route cannot show
       a validation or recovery message. submitFinalConfiguration performs the
       authoritative checks and owns its short in-flight disable itself. */
    try{ const btn=sendBtn(); if(btn){ btn.disabled=false; btn.setAttribute('aria-disabled','true'); } }catch(_){ }
  }
  function paint(total){
    try{ const el=totalEl(); if(el) el.textContent = money(total); }catch(_){ }
    try{ const btn=sendBtn(); if(btn){ btn.disabled=false; btn.removeAttribute('aria-disabled'); } }catch(_){ }
  }
  async function fetchStrict(){
    const jid = activeParentJobId();
    if(!jid) { blank(); return null; }
    const already = currentFinal();
    if(already != null){ paint(already); return already; }
    const seq = (window.__fix486_overlay_seq = (window.__fix486_overlay_seq||0)+1);
    blank();
    try{
      const token = (window.state && state.lastJobAccessToken) || window.__metod_last_job_access_token || '';
      const owner = toolAFoundation;
      if(!owner || typeof owner.fetchJobPricingSummary !== 'function' || typeof owner.authoritativeTotalInclVat !== 'function'){ blank(); return null; }
      const ps = await owner.fetchJobPricingSummary({jobId:jid, accessToken:token});
      if(seq !== window.__fix486_overlay_seq) return null;
      const total = owner.authoritativeTotalInclVat({pricingSummary:ps});
      if(total == null || !isFinite(Number(total))){ blank(); return null; }
      try{ if(typeof _setFinalAuthoritativePrice === 'function') _setFinalAuthoritativePrice(jid, ps); }catch(_){ }
      try{ window.__metod_price_validated_key = `authoritative:${jid}`; }catch(_){ }
      try{ state.authoritativePricingReady = true; state.activeAuthoritativeJobId = jid; }catch(_){ }
      paint(Number(total));
      return Number(total);
    }catch(_){
      if(seq === window.__fix486_overlay_seq) blank();
      return null;
    }
  }
  window._authoritativePriceInclVat = function(){ return null; };
  const origOpen = window.openPriceOverlay;
  window.openPriceOverlay = async function(){
    const have = currentFinal();
    if(have != null){ paint(have); }
    else { blank(); }
    let ret;
    try{ if(typeof origOpen === 'function') ret = await origOpen.apply(this, arguments); }catch(_){ }
    if(have == null) await fetchStrict();
    return ret;
  };
  const origRefresh = window.refreshPriceOverlay;
  window.refreshPriceOverlay = function(){
    const total = currentFinal();
    try{ if(typeof origRefresh === 'function') origRefresh(); }catch(_){ }
    if(total != null) paint(total); else blank();
  };
  const origShow = window.showOptimizingState;
  window.showOptimizingState = function(){
    try{ state.finalAuthoritativePriceInclVat = null; state.finalAuthoritativeJobId=''; state.lastPricingSummary=null; state.authoritativePricingReady=false; state.activeAuthoritativeJobId=''; }catch(_){ }
    try{ window.__metod_price_validated_key = null; window.__metod_active_parent_job_id=''; }catch(_){ }
    blank();
    if(typeof origShow === 'function') return origShow.apply(this, arguments);
  };
  document.addEventListener('DOMContentLoaded', function(){
    const total = currentFinal();
    if(total != null) paint(total); else blank();
  });
})();
