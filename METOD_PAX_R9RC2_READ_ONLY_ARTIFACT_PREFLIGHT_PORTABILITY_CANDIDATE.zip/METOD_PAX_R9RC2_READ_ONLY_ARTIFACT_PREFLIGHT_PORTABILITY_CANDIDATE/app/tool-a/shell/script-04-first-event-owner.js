
/* FIX660R8U — first document adapter for checkout and mobile basket actions.
   This listener is deliberately registered before the legacy application
   scripts. Checkout behavior delegates to the native R9H-8 component owner;
   registration stays early so no older handler can swallow the Safari tap. */
(function(root){
  'use strict';
  const BUILD='R9G8_SINGLE_FINAL_SUBMIT_CLICK_ADAPTER';

  function clean(value){ return String(value == null ? '' : value).trim(); }

  root.document.addEventListener('input', function(event){
    try{ toolAFoundation?.handleCheckoutReviewEvent?.(event); }catch(_){ }
  }, true);
  root.document.addEventListener('change', function(event){
    try{ toolAFoundation?.handleCheckoutReviewEvent?.(event); }catch(_){ }
  }, true);

  root.document.addEventListener('click', function(event){
    const target=event.target;
    const closest=(selector)=>target && target.closest ? target.closest(selector) : null;
    try{ if(toolAFoundation?.handleCheckoutReviewEvent?.(event)===true) return; }catch(_){ }

    const confirmRemove=closest('[data-mobile-material-remove-confirm]');
    const cancelRemove=closest('[data-mobile-material-remove-cancel]');
    const remove=closest('[data-mobile-material-remove]');
    if(confirmRemove || cancelRemove || remove){
      event.preventDefault();
      event.stopImmediatePropagation();
      const api=toolAFoundation;
      if(!api) return;
      if(confirmRemove) api.confirmMobileMaterialRemoval(clean(confirmRemove.getAttribute('data-mobile-material-remove-confirm')));
      else if(cancelRemove) api.cancelMobileMaterialRemoval();
      else api.removeMobileMaterial(clean(remove.getAttribute('data-mobile-material-remove')));
    }
  }, true);

  root.__TOOLA_FIRST_EVENT_OWNER_BUILD=BUILD;
})(window);
