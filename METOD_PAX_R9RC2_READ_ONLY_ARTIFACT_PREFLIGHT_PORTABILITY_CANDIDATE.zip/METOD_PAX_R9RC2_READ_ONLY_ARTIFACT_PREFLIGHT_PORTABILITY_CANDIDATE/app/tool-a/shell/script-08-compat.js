
/* FIX115T: force single authoritative price overlay behavior (remove duplicate openPriceOverlay issues) */
(function(){
  function byId(id){ return document.getElementById(id); }

  function ensureEls(){
    // reuse existing ensurePriceOverlayEls if present
    try{ if(typeof ensurePriceOverlayEls === 'function'){ ensurePriceOverlayEls(); } }catch(_){}
    // hard fallback mapping
    window.__priceOverlayEls = window.__priceOverlayEls || {};
    window.__priceOverlayEls.priceOverlay = byId('priceOverlay');
    window.__priceOverlayEls.totalEl = byId('priceOverlayTotal') || byId('priceTotalValue');
    window.__priceOverlayEls.cancelBtn = byId('cancelConfigBtn') || byId('btnCancelConfig');

    // Bind buttons once (capture)
    const cancel = window.__priceOverlayEls.cancelBtn;
    if(cancel){
      try{ if(typeof window.bindCancelConfigButtonHard === 'function'){ window.bindCancelConfigButtonHard(cancel); } }catch(_){ }
      cancel.__priceOverlayCancelBound = true;
      try{ cancel.disabled = false; }catch(_){ }
      try{ cancel.style.pointerEvents = 'auto'; }catch(_){ }
    }
    // R9G-7: no submit fallback is installed here. The single document-capture
    // owner delegates to the native final-submit state machine.
  }

  // Authoritative open
  window.openPriceOverlay = function(){
    if(window.__metod_submit_done || window.__metod_submit_inflight) return;
    ensureEls();
    try{ if(typeof window.bindCancelConfigButtonHard === 'function'){ window.bindCancelConfigButtonHard(window.__priceOverlayEls && window.__priceOverlayEls.cancelBtn); } }catch(_){ }
    const po = window.__priceOverlayEls.priceOverlay || byId('priceOverlay');
    if(!po) return;

    // Make it a centered modal
    po.style.display = 'flex';
    po.style.alignItems = 'center';
    po.style.justifyContent = 'center';
    document.body.style.overflow = 'hidden';

    // Refresh summary + totals
    try{ if(typeof refreshPriceOverlay === 'function'){ refreshPriceOverlay(); } }catch(_){}
    try{ if(typeof renderPriceSummary === 'function'){ renderPriceSummary(); } }catch(_){}

    // Safety fallback: only fill when the overlay is still blank and always prefer the
    // same authoritative server total as refreshPriceOverlay(). Never overwrite a real server
    // amount with a stale quote-derived number.
    try{
      const el = window.__priceOverlayEls.totalEl || byId('priceOverlayTotal') || byId('priceTotalValue');
      const raw = el ? String(el.textContent || '').trim() : '';
      const isBlank = !raw || raw === '—' || /^op aanvraag$/i.test(raw);
      if(el && isBlank && !(typeof _isAuthoritativePricingPending === 'function' && _isAuthoritativePricingPending())){
        let total = null;
        try{ if(typeof _getFinalAuthoritativePriceForCurrentJob === 'function'){ total = _getFinalAuthoritativePriceForCurrentJob(); } }catch(_){ total = null; }
        try{
          if((total == null || !isFinite(Number(total))) && typeof _strictAuthoritativePriceInclVat === 'function'){
            total = _strictAuthoritativePriceInclVat({ pricingSummary: (window.state && (state.lastPricingSummary || state.lastJobResult?.pricingSummary)) || null });
          }
        }catch(_){ total = null; }
        if(total!=null && isFinite(Number(total))){
          el.textContent = (typeof moneyEUR==='function' ? moneyEUR(Number(total)) : String(total));
        }
      }
    }catch(_){}
  };

  // Ensure close works
  window.closePriceOverlay = window.closePriceOverlay || function(){
    const po = byId('priceOverlay');
    if(po) po.style.display='none';
    document.body.style.overflow = '';
  };

  // Cleanup: quote/job state is now written directly in the compute flow above; no console patching needed.
})();
