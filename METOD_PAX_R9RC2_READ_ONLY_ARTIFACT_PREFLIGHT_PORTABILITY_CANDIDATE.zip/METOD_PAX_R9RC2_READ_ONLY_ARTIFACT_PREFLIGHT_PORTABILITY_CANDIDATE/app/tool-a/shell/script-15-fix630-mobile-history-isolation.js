
(function(){
  try{
    if(!window.matchMedia || !window.matchMedia('(max-width:700px)').matches) return;
    if(!/\/toolA\.html(?:$|[?#])/i.test(location.pathname + location.search + location.hash)) return;
    if(window.__FIX630_HISTORY_ISOLATION__) return;
    window.__FIX630_HISTORY_ISOLATION__=true;
    history.replaceState({toolA:true,fix630:true},'',location.href);
    history.pushState({toolA:true,fix630:true,guard:true},'',location.href);
    window.addEventListener('popstate',function(){
      try{ history.pushState({toolA:true,fix630:true,guard:true},'',location.href); }catch(_e){}
    });
  }catch(_e){}
})();
