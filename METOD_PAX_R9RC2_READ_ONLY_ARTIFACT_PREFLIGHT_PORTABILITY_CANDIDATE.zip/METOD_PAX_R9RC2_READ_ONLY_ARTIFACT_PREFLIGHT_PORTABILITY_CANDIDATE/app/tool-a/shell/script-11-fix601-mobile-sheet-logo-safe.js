
(function(){
  function ready(fn){
    if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', fn, {once:true});
    else fn();
  }
  ready(function(){
    try{
      var header=document.querySelector('.rightHeader');
      if(header && !document.getElementById('fix601MobileBrand')){
        var brand=document.createElement('div');
        brand.id='fix601MobileBrand';
        brand.innerHTML='<img src="assets/adzaagt_logo.png" alt="AD Zaagt">';
        header.insertBefore(brand, header.firstChild);
      }
    }catch(e){}
    try{
      var handle=document.getElementById('mobileSheetHandle');
      if(!handle || handle.__fix601Bound) return;
      handle.__fix601Bound=true;
      var startY=0, active=false;
      function isMobile(){ return window.matchMedia && window.matchMedia('(max-width:700px)').matches; }
      function currentStep(){ return (document.body && document.body.dataset && document.body.dataset.uiStep) || (window.__metod_uiStep || 'material'); }
      function setSheet(mode){
        try{
          var st=String(currentStep()).toLowerCase();
          if(st==='details') st='customer';
          if(st!=='material' && st!=='panels') return;
          document.body.dataset.mobileSheet=mode;
        }catch(e){}
      }
      function onStart(y){ if(!isMobile()) return; active=true; startY=y; }
      function onEnd(y){
        if(!active) return;
        active=false;
        var dy=y-startY;
        if(Math.abs(dy)<18){
          setSheet((document.body.dataset.mobileSheet==='peek')?'expanded':'peek');
        }else if(dy>0){
          setSheet('peek');
        }else{
          setSheet('expanded');
        }
      }
      handle.addEventListener('touchstart',function(ev){ try{ onStart(ev.touches[0].clientY); }catch(e){} },{passive:true});
      handle.addEventListener('touchend',function(ev){ try{ var t=(ev.changedTouches&&ev.changedTouches[0]); onEnd(t?t.clientY:startY); }catch(e){} },{passive:true});
      handle.addEventListener('pointerdown',function(ev){ try{ onStart(ev.clientY); }catch(e){} });
      handle.addEventListener('pointerup',function(ev){ try{ onEnd(ev.clientY); }catch(e){} });
    }catch(e){}
  });
})();
