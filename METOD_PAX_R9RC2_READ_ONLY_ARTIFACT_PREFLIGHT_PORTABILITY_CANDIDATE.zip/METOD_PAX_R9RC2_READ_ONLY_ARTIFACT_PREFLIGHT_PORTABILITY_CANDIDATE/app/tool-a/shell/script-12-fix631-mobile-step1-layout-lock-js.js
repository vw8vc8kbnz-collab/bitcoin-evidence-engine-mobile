
(function(){
  'use strict';
  if(window.__FIX631_STEP1_LAYOUT_LOCK__) return;
  window.__FIX631_STEP1_LAYOUT_LOCK__=true;

  var touched=[];
  function mobile(){
    return !!(window.matchMedia && window.matchMedia('(max-width:700px)').matches);
  }
  function step(){
    return String((document.body && document.body.dataset && document.body.dataset.uiStep) || window.__metod_uiStep || '').toLowerCase();
  }
  function isStep1(){
    var s=step();
    return mobile() && (s==='material' || s==='materials');
  }
  function setImp(el,name,value){
    if(!el) return;
    try{el.style.setProperty(name,value,'important');}catch(_e){}
    if(touched.indexOf(el)<0) touched.push(el);
  }
  function clearLocks(){
    var props=['display','visibility','opacity','position','width','max-width','min-width','padding-top','margin-top','min-height','max-height','height','align-items','align-content','justify-content','top','right','bottom','left','transform','align-self','justify-self','pointer-events','overflow'];
    touched.forEach(function(el){
      props.forEach(function(prop){try{el.style.removeProperty(prop);}catch(_e){}});
    });
    touched=[];
    try{document.body.classList.remove('fix631Step1Locked');}catch(_e){}
  }
  function apply(){
    if(!document.body) return;
    if(!isStep1()){
      if(document.body.classList.contains('fix631Step1Locked')) clearLocks();
      return;
    }
    document.body.classList.add('fix631Step1Locked');
    var app=document.querySelector('.app');
    var right=document.querySelector('.right');
    var header=document.querySelector('.rightHeader');
    var scroll=document.querySelector('.rightScroll');
    var left=document.querySelector('.left');
    var canvas=document.querySelector('.canvasWrap');
    var dock=document.getElementById('panelDock');
    var preview=document.querySelector('.mobilePreview');

    setImp(document.body,'padding-top','0px');
    setImp(document.body,'margin-top','0px');
    setImp(app,'min-height','auto');
    setImp(app,'height','auto');
    setImp(app,'padding-top','0px');
    setImp(app,'margin-top','0px');
    setImp(app,'align-items','flex-start');
    setImp(app,'align-content','flex-start');
    setImp(app,'justify-content','flex-start');
    setImp(right,'top','0px');
    setImp(right,'margin-top','0px');
    setImp(right,'transform','none');
    setImp(right,'align-self','flex-start');
    setImp(right,'justify-self','start');
    setImp(header,'margin-top','0px');
    setImp(header,'padding-top','8px');
    setImp(scroll,'margin-top','0px');
    setImp(scroll,'padding-top','4px');
    [left,canvas,dock,preview].forEach(function(el){
      if(!el) return;
      setImp(el,'display','none');
      setImp(el,'height','0px');
      setImp(el,'min-height','0px');
      setImp(el,'margin-top','0px');
      setImp(el,'padding-top','0px');
    });
  }

  var scheduled=false;
  function schedule(){
    if(scheduled) return;
    scheduled=true;
    requestAnimationFrame(function(){scheduled=false;apply();});
  }

  function start(){
    apply();
    [0,50,150,350,750,1500,3000].forEach(function(ms){setTimeout(apply,ms);});
    try{
      new MutationObserver(schedule).observe(document.documentElement,{subtree:true,attributes:true,attributeFilter:['style','class','data-ui-step','data-mobile-sheet']});
    }catch(_e){}
    window.addEventListener('resize',schedule,{passive:true});
    window.addEventListener('orientationchange',schedule,{passive:true});
    window.addEventListener('pageshow',schedule,{passive:true});
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',start,{once:true});
  else start();
})();
