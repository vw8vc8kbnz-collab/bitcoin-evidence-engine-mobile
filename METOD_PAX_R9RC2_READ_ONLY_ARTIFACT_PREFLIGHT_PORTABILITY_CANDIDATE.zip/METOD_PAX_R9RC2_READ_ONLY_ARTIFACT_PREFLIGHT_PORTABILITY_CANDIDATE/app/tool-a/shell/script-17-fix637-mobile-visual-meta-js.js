
(function(){
  'use strict';
  window.__TOOLA_MOBILE_VISUAL_BUILD='FIX637_MOBILE_VISUAL_CONSOLIDATION';
  var names={material:'Materiaal',panels:'Panelen',grain:'Nerf',customer:'Gegevens',overview:'Overzicht'};
  var order=['material','panels','grain','customer','overview'];
  function sync(){
    var s=String((document.body&&document.body.dataset&&document.body.dataset.uiStep)||'material').toLowerCase();
    var i=Math.max(0,order.indexOf(s));
    var a=document.getElementById('mobileStepIndex'),b=document.getElementById('mobileStepName');
    if(a)a.textContent='Stap '+(i+1)+' van 5';
    if(b)b.textContent=names[s]||'Aanvraag';
  }
  function start(){sync();try{new MutationObserver(sync).observe(document.body,{attributes:true,attributeFilter:['data-ui-step']});}catch(_e){}}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();
