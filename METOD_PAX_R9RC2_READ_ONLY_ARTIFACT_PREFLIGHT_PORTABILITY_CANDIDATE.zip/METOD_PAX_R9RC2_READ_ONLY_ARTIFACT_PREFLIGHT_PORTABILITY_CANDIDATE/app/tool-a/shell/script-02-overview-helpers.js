

function overviewDoorDirection(it){
  try{
    const hinge = String(it?.hinge || it?.hingeSide || it?.draairichting || '').toLowerCase();
    const label = String(it?.label || it?.name || '').toLowerCase();
    if(!label.includes('deur') && !label.includes('door')) return '';
    if(hinge.includes('links') || hinge.includes('left')) return 'Draairichting L';
    if(hinge.includes('rechts') || hinge.includes('right')) return 'Draairichting R';
  }catch(e){}
  return '';
}

function r9GrainView(){
  try{
    const view = toolAFoundation?.getGrainView?.();
    return view && typeof view === 'object' ? view : null;
  }catch(_){ return null; }
}

function overviewGrainCodeFromGroupId(materialKey, grainGroupId){
  try{
    const gid = String(grainGroupId || '').trim();
    if(!gid) return '';
    const grainView = r9GrainView();
    if(grainView && grainView.hasGrainGroups === false) return '';
    const groups = Array.isArray(state?.grain?.groups) ? state.grain.groups : [];
    const sameMat = groups.filter(g => String(g?.materialKey || '') === String(materialKey || ''));
    for(let i=0;i<sameMat.length;i++){
      if(String(sameMat[i]?.id || '') === gid){
        return 'Nerf G' + String(i+1).padStart(2,'0');
      }
    }
  }catch(e){}
  return '';
}

function overviewGrainCode(it){
  return overviewGrainCodeFromGroupId(it?.materialKey, it?.grainGroupId);
}

function overviewExtraGrainCode(p){
  try{
    const assigns = Array.isArray(p?.grainAssignments) ? p.grainAssignments : [];
    const labels = [];
    const seen = new Set();
    for(const a of assigns){
      const label = overviewGrainCodeFromGroupId(p?.materialKey, a?.grainGroupId);
      if(label && !seen.has(label)){
        seen.add(label);
        labels.push(label);
      }
    }
    if(!labels.length) return '';
    return labels.join(', ');
  }catch(e){}
  return '';
}

function overviewTitleWithMeta(it, baseTitle){
  const bits = [];
  const dir = overviewDoorDirection(it);
  const grain = overviewGrainCode(it);
  const title = String(baseTitle || it?.customName || it?.name || it?.label || 'Paneel');
  if(dir) bits.push(dir);
  if(grain) bits.push(grain);
  return bits.length ? `${title} · ${bits.join(' · ')}` : title;
}

function overviewExtraTitleWithMeta(p, baseTitle){
  const bits = [];
  const grain = overviewExtraGrainCode(p);
  const title = String(baseTitle || p?.name || 'Overig paneel');
  if(grain) bits.push(grain);
  return bits.length ? `${title} · ${bits.join(' · ')}` : title;
}


    // Global $ helper (id lookup). Some flows rely on this; ensure it exists early and cannot be shadowed.
    window.$ = window.$ || function(id){ try{ return document.getElementById(id); }catch(_){ return null; } };
  