
  (function(){
    'use strict';
    window.__TOOLA_PERFORMANCE_BUILD='FIX660_GRAIN_STUDIO';
    const CACHE_KEY='toolA_public_catalog_v658';
    function normalize(rec){
      try{
        rec=rec||{};
        const publicId=String(rec.publicMaterialId||rec.articleNumber||rec.articleNo||rec.materialCode||'').trim();
        const publicName=String(rec.publicName||rec.displayName||rec.productName||rec.decorName||'Decor').trim();
        const w=Number(rec?.sheetSizeMm?.width ?? rec.sheetWid ?? rec.sheetWidth ?? 0);
        const h=Number(rec?.sheetSizeMm?.height ?? rec.sheetLen ?? rec.sheetHeight ?? rec.height ?? 0);
        const t=Number(rec.thicknessMm ?? rec.thickness ?? 0);
        if(!/^decor_[a-f0-9]{20,40}$/.test(publicId)||!(w>0)||!(h>0)||!(t>0)) return null;
        return {
          publicMaterialId:publicId, articleNumber:publicId, articleNo:publicId, materialCode:publicId,
          publicName,displayName:publicName,decorName:publicName,productName:publicName,
          brand:String(rec.brand||'Overig').trim()||'Overig',
          decorType:String(rec.primaryVisualFamily||rec.decorType||rec.visualFamily||'Onbekend').trim()||'Onbekend',
          primaryVisualFamily:String(rec.primaryVisualFamily||rec.visualFamily||rec.decorType||'Onbekend').trim()||'Onbekend',
          visualFamily:String(rec.primaryVisualFamily||rec.visualFamily||rec.decorType||'Onbekend').trim()||'Onbekend',
          visualTags:Array.isArray(rec.visualTags)?rec.visualTags.map(x=>String(x||'').trim()).filter(Boolean).slice(0,12):[],
          substrateType:String(rec.substrateType||'ONBEKEND').trim().toUpperCase()||'ONBEKEND',
          substrateLabel:String(rec.substrateLabel||'Onbekend').trim()||'Onbekend',
          collection:String(rec.collection||'').trim(),
          colorGroup:String(rec.colorGroup||'Overig').trim()||'Overig',
          searchTags:Array.isArray(rec.searchTags)?rec.searchTags.map(x=>String(x||'').trim()).filter(Boolean).slice(0,48):[],
          thicknessMm:t,sheetSizeMm:{width:w,height:h},
          hasGrain:rec.hasGrain==null?true:!!rec.hasGrain, grainDefaultOn:rec.grainDefaultOn==null?true:!!rec.grainDefaultOn,
          categoryName:String(rec.decorType||rec.categoryName||'Overig').trim()||'Overig',
          active:rec.active!==false,published:rec.published!==false,isPopular:!!rec.isPopular,isNew:!!rec.isNew,
          imageAvailable:!!rec.imageAvailable,imageThumbUrl:String(rec.imageThumbUrl||''),imagePreviewUrl:String(rec.imagePreviewUrl||'')
        };
      }catch(_){ return null; }
    }
    window.__TOOLA_NORMALIZE_PUBLIC_CATALOG_RECORD=normalize;
    function apply(j,source){
      if(!j||!Array.isArray(j.records)) return null;
      const recs=j.records.map(normalize).filter(Boolean);
      window.MATERIAL_CATALOG=recs;
      window.__TOOLA_PUBLIC_CATALOG_VERSION=String(j.version||'');
      window.__TOOLA_PUBLIC_CATALOG_SOURCE=source||'network';
      try{document.dispatchEvent(new CustomEvent('adzaagt-material-catalog-updated',{detail:{count:recs.length,version:window.__TOOLA_PUBLIC_CATALOG_VERSION,source}}));}catch(_){ }
      return recs;
    }
    // Repeat visits: render public-only cached tiles immediately. Network revalidation starts
    // at the top of <head>, in parallel with parsing the large configurator document.
    try{
      const cached=JSON.parse(localStorage.getItem(CACHE_KEY)||'null');
      if(cached&&Array.isArray(cached.records)&&cached.records.length){ apply(cached,'browser-cache'); }
    }catch(_){ }
    window.__TOOLA_PUBLIC_CATALOG_BOOTSTRAP_PROMISE=fetch('/api/materials/library',{cache:'no-cache',credentials:'same-origin'})
      .then(r=>{if(!r.ok) throw new Error('HTTP '+r.status);return r.json();})
      .then(j=>{
        if(!j||j.ok===false||!Array.isArray(j.records)) throw new Error((j&&j.error)||'Ongeldige catalogus');
        try{localStorage.setItem(CACHE_KEY,JSON.stringify({records:j.records,version:j.version||'',count:j.count||j.records.length,savedAt:Date.now()}));}catch(_){ }
        apply(j,'network');
        return j;
      })
      .catch(err=>{try{console.warn('FIX656 early catalog bootstrap:',err&&err.message?err.message:err);}catch(_){ }return null;});
  })();
  