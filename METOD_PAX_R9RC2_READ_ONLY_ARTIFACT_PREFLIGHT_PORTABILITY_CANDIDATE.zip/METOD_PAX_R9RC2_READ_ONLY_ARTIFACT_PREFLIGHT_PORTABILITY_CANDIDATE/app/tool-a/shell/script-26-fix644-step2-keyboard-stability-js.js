
(function(){
  'use strict';
  if(window.__FIX644_STEP2_KEYBOARD_STABILITY__) return;
  window.__FIX644_STEP2_KEYBOARD_STABILITY__='FIX644_STEP2_KEYBOARD_STABILITY_ALL_FIELDS';

  var vv=window.visualViewport||null;
  var baselineHeight=vv?vv.height:window.innerHeight;
  var session=null;
  var raf=0;
  var blurTimer=0;
  var lastStep='';
  var lockedWindowY=0;
  var prevHtmlOverflow='';
  var prevBodyOverflow='';

  function mobile(){return !!(window.matchMedia&&window.matchMedia('(max-width:700px)').matches);}
  function step(){return String((document.body&&document.body.dataset&&document.body.dataset.uiStep)||'').toLowerCase();}
  function active(){return mobile()&&step()==='panels';}
  function scrollBox(el){return (el&&el.closest&&el.closest('#extraOverlay .extraBody,#extraOverlay .modalBody,.rightScroll'))||document.getElementById('rightScroll');}
  function editable(el){
    return !!(el&&el.matches&&el.matches('#stepPanels input:not([type="hidden"]):not([disabled]),#stepPanels textarea:not([disabled]),#stepPanels select:not([disabled]),#stepPanels [contenteditable="true"],#extraOverlay input:not([type="hidden"]):not([disabled]),#extraOverlay textarea:not([disabled]),#extraOverlay select:not([disabled]),#extraOverlay [contenteditable="true"]'));
  }
  function focusedEditable(){var el=document.activeElement;return editable(el)?el:null;}
  function viewportHeight(){return vv?Math.max(1,Math.round(vv.height)):Math.max(1,window.innerHeight);}
  function viewportTop(){return vv?Math.max(0,Math.round(vv.offsetTop||0)):0;}
  function keyboardLikely(){
    var h=viewportHeight();
    return !!(focusedEditable() && baselineHeight-h>90);
  }
  function setVars(){
    if(!document.documentElement||!active())return;
    var h=viewportHeight(),top=viewportTop();
    document.body.style.setProperty('--fix644-vv-height',h+'px');
    document.body.style.setProperty('--fix644-vv-top',top+'px');
    var open=keyboardLikely();
    document.body.classList.toggle('fix644KeyboardOpen',open);
    window.__FIX644_STEP2_KEYBOARD_ACTIVE__=!!focusedEditable();
  }
  function resetWindowScroll(){
    if(!active()||!window.__FIX644_STEP2_KEYBOARD_ACTIVE__)return;
    try{window.scrollTo(0,lockedWindowY);}catch(_e){}
  }
  function keepVisible(el){
    var box=scrollBox(el);
    if(!box||!editable(el)||!document.contains(el))return;
    try{
      var br=box.getBoundingClientRect(),er=el.getBoundingClientRect();
      var pad=18,delta=0;
      if(er.top<br.top+pad)delta=er.top-(br.top+pad);
      else if(er.bottom>br.bottom-pad)delta=er.bottom-(br.bottom-pad);
      if(Math.abs(delta)>.5)box.scrollTop+=delta;
    }catch(_e){}
  }
  function scheduleSync(el){
    if(raf)cancelAnimationFrame(raf);
    raf=requestAnimationFrame(function(){
      raf=0;setVars();resetWindowScroll();keepVisible(el||focusedEditable());
      requestAnimationFrame(function(){setVars();resetWindowScroll();keepVisible(el||focusedEditable());});
    });
  }
  function lockPage(){
    if(!document.documentElement||!document.body)return;
    lockedWindowY=window.scrollY||window.pageYOffset||0;
    prevHtmlOverflow=document.documentElement.style.overflow||'';
    prevBodyOverflow=document.body.style.overflow||'';
    document.documentElement.style.overflow='hidden';
    document.body.style.overflow='hidden';
  }
  function unlockPage(){
    if(!document.documentElement||!document.body)return;
    document.documentElement.style.overflow=prevHtmlOverflow;
    document.body.style.overflow=prevBodyOverflow;
    document.body.style.removeProperty('--fix644-vv-height');
    document.body.style.removeProperty('--fix644-vv-top');
    document.body.classList.remove('fix644KeyboardOpen','fix644KeyboardFocus');
    window.__FIX644_STEP2_KEYBOARD_ACTIVE__=false;
  }
  function enterStep(){
    if(!active())return;
    baselineHeight=Math.max(baselineHeight,viewportHeight());
    lockPage();setVars();
  }
  function leaveStep(){
    clearTimeout(blurTimer);
    session=null;unlockPage();
  }
  function onFocusIn(ev){
    if(!active()||!editable(ev.target))return;
    clearTimeout(blurTimer);
    var box=scrollBox(ev.target);
    if(!session){
      session={box:box,scrollTop:box?box.scrollTop:0,windowY:window.scrollY||0};
      baselineHeight=Math.max(baselineHeight,viewportHeight());
    }
    lockedWindowY=session.windowY;
    document.body.classList.add('fix644KeyboardFocus');
    window.__FIX644_STEP2_KEYBOARD_ACTIVE__=true;
    scheduleSync(ev.target);
    [30,90,180,320].forEach(function(ms){setTimeout(function(){if(active()&&editable(document.activeElement))scheduleSync(document.activeElement);},ms);});
  }
  function finishSession(){
    if(focusedEditable())return;
    var box=(session&&session.box)||scrollBox(),restore=session&&Number.isFinite(session.scrollTop)?session.scrollTop:null;
    session=null;
    document.body.classList.remove('fix644KeyboardOpen','fix644KeyboardFocus');
    window.__FIX644_STEP2_KEYBOARD_ACTIVE__=false;
    document.body.style.setProperty('--fix644-vv-height',(vv?Math.round(vv.height):window.innerHeight)+'px');
    document.body.style.setProperty('--fix644-vv-top',(vv?Math.round(vv.offsetTop||0):0)+'px');
    if(box&&restore!==null){
      requestAnimationFrame(function(){box.scrollTop=restore;requestAnimationFrame(function(){box.scrollTop=restore;});});
    }
    resetWindowScroll();
  }
  function onFocusOut(){
    clearTimeout(blurTimer);
    blurTimer=setTimeout(finishSession,220);
  }
  function onViewport(){
    if(!active())return;
    if(!focusedEditable()&&viewportHeight()>baselineHeight-40)baselineHeight=Math.max(baselineHeight,viewportHeight());
    scheduleSync(focusedEditable());
  }
  function onStep(){
    var s=step();
    if(s===lastStep)return;
    if(lastStep==='panels')leaveStep();
    lastStep=s;
    if(active())requestAnimationFrame(enterStep);
  }
  function start(){
    lastStep=step();
    if(active())enterStep();
    document.addEventListener('focusin',onFocusIn,true);
    document.addEventListener('focusout',onFocusOut,true);
    window.addEventListener('scroll',resetWindowScroll,{passive:true});
    if(vv){vv.addEventListener('resize',onViewport,{passive:true});vv.addEventListener('scroll',onViewport,{passive:true});}
    window.addEventListener('orientationchange',function(){setTimeout(function(){baselineHeight=viewportHeight();onViewport();},260);},{passive:true});
    try{new MutationObserver(onStep).observe(document.body,{attributes:true,attributeFilter:['data-ui-step']});}catch(_e){}
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();
