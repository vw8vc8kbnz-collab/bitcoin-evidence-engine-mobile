
(function(){
  try{
    var bind = function(){
      if(window.__fix576MobileShowStepTopReset) return;
      if(typeof window.showStep !== 'function') return;
      var original = window.showStep;
      window.showStep = function(step){
        var result = original.apply(this, arguments);
        try{
          if(window.innerWidth <= 700){
            var normalized = String(step || '').toLowerCase();
            if(normalized === 'details') normalized = 'customer';
            if(['material','panels','customer'].indexOf(normalized) !== -1){
              document.body.dataset.mobileSheet = (normalized === 'material') ? 'peek' : 'expanded';
              var rs = document.getElementById('rightScroll');
              if(rs){ setTimeout(function(){ try{ rs.scrollTop = 0; }catch(e){} }, 0); }
              window.scrollTo && window.scrollTo(0,0);
            }
          }
        }catch(e){}
        return result;
      };
      window.__fix576MobileShowStepTopReset = true;
    };
    bind();
    document.addEventListener('DOMContentLoaded', bind);
    setTimeout(bind, 0);
  }catch(e){}
})();
