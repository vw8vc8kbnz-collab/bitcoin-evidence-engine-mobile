
// FIX101 Apple-like dropdowns (progressive enhancement over native <select>)
(function(){
  function el(tag, cls){ const e=document.createElement(tag); if(cls) e.className=cls; return e; }

  function closeAll(exceptWrap){
    document.querySelectorAll('.apple-select-wrap[data-open="1"]').forEach(w=>{ if(w!==exceptWrap){ w.dataset.open='0'; } });
  }

  function buildForSelect(sel){
    if(!sel || sel.dataset.appleEnhanced==='1') return;
    try{
      if(sel.dataset && (sel.dataset.noApple==='1' || sel.dataset.noApple==='true')) return;
      if(sel.hasAttribute('data-no-apple')) return;
      if(sel.style && String(sel.style.display||'').toLowerCase()==='none') return;
    }catch(e){}

    const wrap=el('div','apple-select-wrap');
    const btn=el('button','apple-select-btn');
    btn.type='button';
    btn.setAttribute('aria-haspopup','listbox');

    const label=el('div','apple-select-label');
    const chev=el('svg','apple-select-chev');
    chev.setAttribute('viewBox','0 0 20 20');
    chev.innerHTML='<path d="M5 7l5 6 5-6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>';

    btn.appendChild(label);
    btn.appendChild(chev);

    const menu=el('div','apple-select-menu');
    menu.setAttribute('role','listbox');

    function setBtnDisabled(){
      const disabled=!!sel.disabled;
      btn.setAttribute('aria-disabled', disabled? 'true':'false');
      if(disabled) btn.setAttribute('tabindex','-1'); else btn.removeAttribute('tabindex');
    }

    function currentText(){
      const opt=sel.options[sel.selectedIndex];
      return (opt && opt.textContent) ? opt.textContent.trim() : '';
    }

    function renderOptions(){
      menu.innerHTML='';
      const selectedVal=sel.value;
      for(const opt of sel.options){
        const oBtn=el('button','apple-select-opt');
        oBtn.type='button';
        oBtn.setAttribute('role','option');
        oBtn.dataset.value=opt.value;
        const t=document.createElement('div');
        t.style.minWidth='0';
        t.style.whiteSpace='nowrap';
        t.style.overflow='hidden';
        t.style.textOverflow='ellipsis';
        t.textContent=(opt.textContent||'').trim();
        oBtn.appendChild(t);

        const isSel=(opt.value===selectedVal);
        oBtn.setAttribute('aria-selected', isSel? 'true':'false');
        if(isSel){
          const check=el('div','apple-select-check');
          check.textContent='✓';
          oBtn.appendChild(check);
        }

        oBtn.addEventListener('click', ()=>{
          if(sel.disabled) return;
          sel.value=opt.value;
          // Fire existing listeners
          sel.dispatchEvent(new Event('change',{bubbles:true}));
          // Sync UI
          syncFromSelect();
          wrap.dataset.open='0';
          btn.focus();
        });

        menu.appendChild(oBtn);
      }
    }

    function syncFromSelect(){
      label.textContent = currentText() || '—';
      setBtnDisabled();
      // Update selected marker without rebuilding if possible
      const selectedVal=sel.value;
      const opts=menu.querySelectorAll('.apple-select-opt');
      if(opts.length===sel.options.length){
        opts.forEach(b=>{
          const isSel=b.dataset.value===selectedVal;
          b.setAttribute('aria-selected', isSel? 'true':'false');
          const existing=b.querySelector('.apple-select-check');
          if(isSel && !existing){ const c=el('div','apple-select-check'); c.textContent='✓'; b.appendChild(c); }
          if(!isSel && existing){ existing.remove(); }
        });
      } else {
        renderOptions();
      }
    }

    btn.addEventListener('click', ()=>{
      if(sel.disabled) return;
      const isOpen = wrap.dataset.open==='1';
      if(isOpen){ wrap.dataset.open='0'; return; }
      closeAll(wrap);
      wrap.dataset.open='1';
      // Ensure up-to-date options (in case select was repopulated)
      renderOptions();
      syncFromSelect();
      // Scroll selected into view
      const selEl=menu.querySelector('.apple-select-opt[aria-selected="true"]');
      if(selEl) selEl.scrollIntoView({block:'nearest'});
    });

    // Keyboard support
    btn.addEventListener('keydown', (e)=>{
      if(sel.disabled) return;
      if(e.key==='Enter' || e.key===' '){ e.preventDefault(); btn.click(); }
      if(e.key==='ArrowDown' || e.key==='ArrowUp'){
        e.preventDefault();
        closeAll(wrap);
        wrap.dataset.open='1';
        renderOptions();
        syncFromSelect();
        const list=Array.from(menu.querySelectorAll('.apple-select-opt'));
        if(!list.length) return;
        const idx=Math.max(0, list.findIndex(x=>x.dataset.value===sel.value));
        const next = e.key==='ArrowDown' ? Math.min(list.length-1, idx+1) : Math.max(0, idx-1);
        list[next].focus();
      }
    });

    menu.addEventListener('keydown', (e)=>{
      const list=Array.from(menu.querySelectorAll('.apple-select-opt'));
      const i=list.indexOf(document.activeElement);
      if(e.key==='Escape'){ e.preventDefault(); wrap.dataset.open='0'; btn.focus(); }
      if(e.key==='ArrowDown'){ e.preventDefault(); if(i>=0 && i<list.length-1) list[i+1].focus(); }
      if(e.key==='ArrowUp'){ e.preventDefault(); if(i>0) list[i-1].focus(); }
      if(e.key==='Tab'){ wrap.dataset.open='0'; }
    });

    // Close on outside click
    document.addEventListener('pointerdown', (e)=>{
      if(!wrap.contains(e.target)) wrap.dataset.open='0';
    }, true);

    // Observe option changes (dynamic repopulation)
    const mo=new MutationObserver(()=>{ renderOptions(); syncFromSelect(); });
    mo.observe(sel, {childList:true, subtree:true});

    // Insert structure: wrap replaces select in layout, select hidden
    sel.classList.add('apple-native-hidden');
    sel.dataset.appleEnhanced='1';

    sel.parentNode.insertBefore(wrap, sel);
    wrap.appendChild(btn);
    wrap.appendChild(menu);
    wrap.appendChild(sel);

    // Keep UI synced
    sel.addEventListener('change', syncFromSelect);
    sel.__appleSync = syncFromSelect;
    setBtnDisabled();
    renderOptions();
    syncFromSelect();
  }

  function init(){
    try{
      document.querySelectorAll('select').forEach(buildForSelect);
    } catch(err){
      console.warn('[FIX101] AppleSelect init failed', err);
    }
  }

  if(document.readyState==='loading'){
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
