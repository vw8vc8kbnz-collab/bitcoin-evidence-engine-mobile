/* R9RC1 source descriptor only.
 * The reviewed legacy closure is byte-exactly assembled from bounded files in
 * tool-a/runtime/legacy-source/parts.json by r9rc1_build_toola_assets.py.
 * Aggregate SHA-256 before splitting: 4836de1632d301ed5d0b614bff0923606205cc84fd6241e1122febb4c1defe21
 */
