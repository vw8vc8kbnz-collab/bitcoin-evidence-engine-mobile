
(function(){
  try{
    if(localStorage.getItem('fix640_public_material_cache_migrated') !== '1'){
      localStorage.removeItem('metod_draft_v1');
      localStorage.removeItem('metod_draft');
      sessionStorage.removeItem('metod_draft_v1');
      sessionStorage.removeItem('metod_draft');
      localStorage.setItem('fix640_public_material_cache_migrated','1');
    }
  }catch(_){ }
})();
