from __future__ import annotations

"""Bounded StorageIoRuntime implementation with explicit runtime injection."""

class StorageIoRuntime:
    def __init__(self, runtime):
        self._runtime = runtime

    def _now_iso(_owner) -> str:
        runtime = _owner._runtime
        time = runtime.time

        return time.strftime('%Y-%m-%dT%H:%M:%S', time.localtime())


    def _safe_json(_owner, data, code=200):
        runtime = _owner._runtime
        strict_json_dumps = runtime.strict_json_dumps

        body = strict_json_dumps(data).encode('utf-8')
        return body, code


    def _read_json_body(_owner, handler: SimpleHTTPRequestHandler, max_bytes: Optional[int] = None) -> dict:
        runtime = _owner._runtime
        Optional = runtime.Optional
        SimpleHTTPRequestHandler = runtime.SimpleHTTPRequestHandler
        _helpers_read_json_body = runtime._helpers_read_json_body

        return _helpers_read_json_body(handler, max_bytes=max_bytes)


    def _read_json_body_limited(_owner, handler: SimpleHTTPRequestHandler, env_name: str, default_bytes: int) -> dict:
        runtime = _owner._runtime
        SimpleHTTPRequestHandler = runtime.SimpleHTTPRequestHandler
        _helpers_read_json_body_limited = runtime._helpers_read_json_body_limited

        return _helpers_read_json_body_limited(handler, env_name, default_bytes)


    def _safe_job_file(_owner, job_root: Path, rel: str) -> Optional[Path]:
        runtime = _owner._runtime
        Optional = runtime.Optional
        Path = runtime.Path
        _helpers_safe_job_file = runtime._helpers_safe_job_file

        return _helpers_safe_job_file(job_root, rel)


    def _write_file(_owner, path: Path, text: str):
        runtime = _owner._runtime
        Path = runtime.Path
        durable_write_text = runtime.durable_write_text

        durable_write_text(path, text)


    def _write_bytes(_owner, path: Path, b: bytes):
        runtime = _owner._runtime
        Path = runtime.Path
        durable_write_bytes = runtime.durable_write_bytes

        durable_write_bytes(path, b)


    def _write_replaceable_bytes(_owner, path: Path, data: bytes) -> None:
        """Atomically publish diagnostic/progress data without a durability barrier."""
        runtime = _owner._runtime
        Path = runtime.Path
        os = runtime.os
        secrets = runtime.secrets

    
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        tmp = target.parent / f'.{target.name}.snapshot.{os.getpid()}.{secrets.token_hex(4)}'
        try:
            tmp.write_bytes(data)
            os.replace(tmp, target)
        finally:
            try:
                tmp.unlink(missing_ok=True)
            except Exception:
                pass


    def _write_replaceable_text(_owner, path: Path, text: str) -> None:
        runtime = _owner._runtime
        Path = runtime.Path
        _write_replaceable_bytes = runtime._write_replaceable_bytes

        _write_replaceable_bytes(path, str(text).encode('utf-8'))


    def _write_replaceable_json(_owner, path: Path, value: Any) -> None:
        runtime = _owner._runtime
        Any = runtime.Any
        Path = runtime.Path
        _write_replaceable_text = runtime._write_replaceable_text
        strict_json_dumps = runtime.strict_json_dumps

        _write_replaceable_text(path, strict_json_dumps(value, indent=2) + '\n')


    def _link_or_copy_file(_owner, src: Path, dst: Path) -> str:
        """Create dst without duplicating file bytes when the filesystem supports hardlinks."""
        runtime = _owner._runtime
        Path = runtime.Path
        durable_copy_file = runtime.durable_copy_file
        os = runtime.os

        src = Path(src); dst = Path(dst)
        dst.parent.mkdir(parents=True, exist_ok=True)
        try:
            if dst.exists() or dst.is_symlink():
                dst.unlink()
            os.link(src, dst)
            return 'hardlink'
        except Exception:
            durable_copy_file(src, dst)
            return 'copy'


    def _atomic_write_text(_owner, path: Path, text: str) -> None:
        runtime = _owner._runtime
        Path = runtime.Path
        _helpers_atomic_write_text = runtime._helpers_atomic_write_text

        _helpers_atomic_write_text(path, text)


    def _atomic_write_json(_owner, path: Path, obj: dict, *, mode: int | None = 0o600) -> None:
        runtime = _owner._runtime
        Path = runtime.Path
        _helpers_atomic_write_json = runtime._helpers_atomic_write_json

        _helpers_atomic_write_json(path, obj, mode=mode)


    def _utc_now_iso(_owner) -> str:
        runtime = _owner._runtime
        datetime = runtime.datetime
        timezone = runtime.timezone

        return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


    def _ensure_request_dirs(_owner) -> None:
        runtime = _owner._runtime
        BACKUPS_DIR = runtime.BACKUPS_DIR
        INDEX_DIR = runtime.INDEX_DIR
        QUEUE_DIR = runtime.QUEUE_DIR
        QUEUE_DONE = runtime.QUEUE_DONE
        QUEUE_FAILED = runtime.QUEUE_FAILED
        QUEUE_PENDING = runtime.QUEUE_PENDING
        QUEUE_PROCESSING = runtime.QUEUE_PROCESSING
        REQUESTS = runtime.REQUESTS
        SUBMISSION_IDEMPOTENCY_DIR = runtime.SUBMISSION_IDEMPOTENCY_DIR
        SYSTEM_DIR = runtime.SYSTEM_DIR

        for d in [REQUESTS, QUEUE_DIR, QUEUE_PENDING, QUEUE_PROCESSING, QUEUE_DONE, QUEUE_FAILED, INDEX_DIR, SUBMISSION_IDEMPOTENCY_DIR, SYSTEM_DIR, BACKUPS_DIR]:
            d.mkdir(parents=True, exist_ok=True)


    def _ensure_archive_dirs(_owner) -> None:
        runtime = _owner._runtime
        ARCHIVE_JOBS = runtime.ARCHIVE_JOBS
        ARCHIVE_QUEUE_DONE = runtime.ARCHIVE_QUEUE_DONE
        ARCHIVE_QUEUE_FAILED = runtime.ARCHIVE_QUEUE_FAILED
        ARCHIVE_REQUESTS = runtime.ARCHIVE_REQUESTS
        ARCHIVE_ROOT = runtime.ARCHIVE_ROOT
        ARCHIVE_TRANSACTIONS = runtime.ARCHIVE_TRANSACTIONS
        Path = runtime.Path
        fsync_directory = runtime.fsync_directory

        directories = [ARCHIVE_ROOT, ARCHIVE_JOBS, ARCHIVE_REQUESTS, ARCHIVE_QUEUE_DONE, ARCHIVE_QUEUE_FAILED, ARCHIVE_TRANSACTIONS]
        created_parents: set[Path] = set()
        for d in directories:
            if not d.exists():
                created_parents.add(d.parent)
            d.mkdir(parents=True, exist_ok=True)
        for parent in sorted(created_parents, key=lambda path: len(path.parts), reverse=True):
            if parent.exists():
                fsync_directory(parent)

    EXPORTS = ('_now_iso', '_safe_json', '_read_json_body', '_read_json_body_limited', '_safe_job_file', '_write_file', '_write_bytes', '_write_replaceable_bytes', '_write_replaceable_text', '_write_replaceable_json', '_link_or_copy_file', '_atomic_write_text', '_atomic_write_json', '_utc_now_iso', '_ensure_request_dirs', '_ensure_archive_dirs')

__all__ = ("StorageIoRuntime",)
