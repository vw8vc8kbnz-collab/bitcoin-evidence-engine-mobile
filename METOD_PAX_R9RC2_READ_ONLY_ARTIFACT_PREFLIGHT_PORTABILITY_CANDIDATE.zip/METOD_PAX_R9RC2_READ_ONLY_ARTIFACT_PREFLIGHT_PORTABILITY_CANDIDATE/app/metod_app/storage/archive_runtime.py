from __future__ import annotations

"""Bounded ArchiveRuntime implementation with explicit runtime injection."""

class ArchiveRuntime:
    def __init__(self, runtime):
        self._runtime = runtime

    def _parse_iso_dt(_owner, value) -> Optional[datetime]:
        runtime = _owner._runtime
        Optional = runtime.Optional
        datetime = runtime.datetime
        timezone = runtime.timezone

        try:
            s = str(value or '').strip()
            if not s:
                return None
            if s.endswith('Z'):
                s = s[:-1] + '+00:00'
            dt = datetime.fromisoformat(s)
            if dt.tzinfo is not None:
                dt = dt.astimezone(timezone.utc).replace(tzinfo=None)
            return dt
        except Exception:
            return None

    def _path_dt(_owner, path: Path) -> Optional[datetime]:
        runtime = _owner._runtime
        Optional = runtime.Optional
        Path = runtime.Path
        datetime = runtime.datetime
        timezone = runtime.timezone

        try:
            return datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc).replace(tzinfo=None)
        except Exception:
            return None

    def _request_status_path(_owner, request_id: str) -> Path:
        runtime = _owner._runtime
        Path = runtime.Path
        REQUESTS = runtime.REQUESTS
        _safe_id = runtime._safe_id

        rid = _safe_id(str(request_id or '').strip(), 120)
        return REQUESTS / rid / 'status.json'

    def _request_created_dt_from_status(_owner, st: dict | None, request_root: Path | None = None) -> Optional[datetime]:
        runtime = _owner._runtime
        Optional = runtime.Optional
        Path = runtime.Path
        _parse_iso_dt = runtime._parse_iso_dt
        _path_dt = runtime._path_dt
        datetime = runtime.datetime

        if isinstance(st, dict):
            for k in ('createdAt', 'submittedAt', 'updatedAt'):
                dt = _parse_iso_dt(st.get(k))
                if dt is not None:
                    return dt
        if request_root is not None:
            sp = Path(request_root) / 'status.json'
            if sp.exists():
                dt = _path_dt(sp)
                if dt is not None:
                    return dt
            dt = _path_dt(Path(request_root))
            if dt is not None:
                return dt
        return None

    def _request_archive_meta_dt(_owner, req_dir: Path) -> Optional[datetime]:
        runtime = _owner._runtime
        ARCHIVE_META_NAME = runtime.ARCHIVE_META_NAME
        Optional = runtime.Optional
        Path = runtime.Path
        _parse_iso_dt = runtime._parse_iso_dt
        _path_dt = runtime._path_dt
        datetime = runtime.datetime
        strict_json_load = runtime.strict_json_load

        meta_path = Path(req_dir) / ARCHIVE_META_NAME
        if meta_path.exists():
            try:
                meta = strict_json_load(meta_path)
                dt = _parse_iso_dt(meta.get('archivedAt'))
                if dt is not None:
                    return dt
            except Exception:
                pass
        return _path_dt(req_dir)

    def _job_created_dt(_owner, job_dir: Path) -> Optional[datetime]:
        runtime = _owner._runtime
        Optional = runtime.Optional
        Path = runtime.Path
        _job_meta = runtime._job_meta
        _parse_iso_dt = runtime._parse_iso_dt
        _path_dt = runtime._path_dt
        datetime = runtime.datetime

        try:
            meta = _job_meta.get(job_dir.name, {}) if isinstance(_job_meta, dict) else {}
            if isinstance(meta, dict):
                for k in ('createdAt', 'startedAt', 'updatedAt'):
                    dt = _parse_iso_dt(meta.get(k))
                    if dt is not None:
                        return dt
        except Exception:
            pass
        status_candidates = [job_dir / 'output' / 'meta_status.json', job_dir / 'output' / 'links.json', job_dir / 'input' / 'job.json']
        for fp in status_candidates:
            if fp.exists():
                dt = _path_dt(fp)
                if dt is not None:
                    return dt
        return _path_dt(job_dir)

    def _write_archive_meta(_owner, 
        dest_dir: Path,
        *,
        kind: str,
        item_id: str,
        archived_at: datetime,
        active_created_at: Optional[datetime] = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        runtime = _owner._runtime
        ARCHIVE_META_NAME = runtime.ARCHIVE_META_NAME
        Any = runtime.Any
        Optional = runtime.Optional
        Path = runtime.Path
        _atomic_write_json = runtime._atomic_write_json
        datetime = runtime.datetime

        payload = {
            'kind': kind,
            'id': item_id,
            'archivedAt': archived_at.isoformat() + 'Z',
        }
        if active_created_at is not None:
            payload['activeCreatedAt'] = active_created_at.isoformat() + 'Z'
        if isinstance(details, dict):
            payload.update(details)
        # Metadata is part of the archive transaction: a write failure must roll
        # every required move back instead of leaving an unretained archive tree.
        _atomic_write_json(dest_dir / ARCHIVE_META_NAME, payload)

    def _unique_archive_dest(_owner, base_dir: Path, name: str) -> Path:
        runtime = _owner._runtime
        Path = runtime.Path
        secrets = runtime.secrets
        time = runtime.time

        dest = base_dir / name
        if not dest.exists():
            return dest
        for _ in range(128):
            dest = base_dir / f"{name}__archived_{time.strftime('%Y%m%d_%H%M%S')}_{secrets.token_hex(5)}"
            if not dest.exists():
                return dest
        raise RuntimeError(f'cannot allocate collision-free archive destination for {name}')

    def _archive_journal_path(_owner, transaction_id: str) -> Path:
        runtime = _owner._runtime
        ARCHIVE_TRANSACTIONS = runtime.ARCHIVE_TRANSACTIONS
        Path = runtime.Path
        _safe_id = runtime._safe_id

        txid = _safe_id(str(transaction_id or '').strip(), 120)
        if not txid or not txid.startswith('archive_'):
            raise ValueError('invalid archive transaction id')
        return ARCHIVE_TRANSACTIONS / f'{txid}.json'

    def _archive_journal_write(_owner, path: Path, journal: dict[str, Any]) -> None:
        runtime = _owner._runtime
        Any = runtime.Any
        Path = runtime.Path
        _utc_now_iso = runtime._utc_now_iso
        durable_write_json = runtime.durable_write_json

        journal['updatedAt'] = _utc_now_iso()
        durable_write_json(path, journal, mode=0o640)

    def _archive_journal_entries(_owner, 
        journal: dict[str, Any],
        *,
        journal_path: Path | None = None,
    ) -> list[dict[str, str]]:
        runtime = _owner._runtime
        ARCHIVE_JOBS = runtime.ARCHIVE_JOBS
        ARCHIVE_REQUESTS = runtime.ARCHIVE_REQUESTS
        Any = runtime.Any
        JOBS = runtime.JOBS
        Path = runtime.Path
        REQUESTS = runtime.REQUESTS
        SUBMISSION_IDEMPOTENCY_DIR = runtime.SUBMISSION_IDEMPOTENCY_DIR
        _archive_journal_path = runtime._archive_journal_path
        _parse_iso_dt = runtime._parse_iso_dt
        _safe_id = runtime._safe_id
        _safe_text = runtime._safe_text
        _submission_marker_path = runtime._submission_marker_path
        re = runtime.re

        if journal.get('schemaVersion') != 1:
            raise RuntimeError('archive journal schemaVersion is invalid')
        transaction_id = str(journal.get('transactionId') or '')
        if not re.fullmatch(r'archive_[a-f0-9]{32}', transaction_id):
            raise RuntimeError('archive journal transactionId is invalid')
        if journal_path is not None and Path(journal_path) != _archive_journal_path(transaction_id):
            raise RuntimeError('archive journal filename does not match transactionId')
        if str(journal.get('state') or '') not in {'PREPARED', 'COMMITTED'}:
            raise RuntimeError('archive journal state is invalid')
        request_id = str(journal.get('requestId') or '')
        if not request_id or request_id != _safe_id(request_id, 120):
            raise RuntimeError('archive journal requestId is invalid')
        if _parse_iso_dt(journal.get('archivedAt')) is None:
            raise RuntimeError('archive journal archivedAt is invalid')
        if _parse_iso_dt(journal.get('createdAt')) is None or _parse_iso_dt(journal.get('updatedAt')) is None:
            raise RuntimeError('archive journal timestamps are invalid')
        active_created_at = journal.get('activeCreatedAt')
        if active_created_at not in {None, ''} and _parse_iso_dt(active_created_at) is None:
            raise RuntimeError('archive journal activeCreatedAt is invalid')
        missing_jobs_raw = journal.get('missingJobs') or []
        if not isinstance(missing_jobs_raw, list) or len(missing_jobs_raw) > 10000:
            raise RuntimeError('archive journal missingJobs is invalid')
        missing_jobs: list[str] = []
        for raw_missing_job in missing_jobs_raw:
            missing_job = str(raw_missing_job or '')
            if not missing_job or missing_job != _safe_id(missing_job, 200) or missing_job in missing_jobs:
                raise RuntimeError('archive journal missingJobs contains an invalid identity')
            missing_jobs.append(missing_job)
        retention_reason = str(journal.get('retentionReason') or '')
        if not retention_reason or retention_reason != _safe_text(retention_reason, 80):
            raise RuntimeError('archive journal retentionReason is invalid')
    
        moves = journal.get('moves')
        if not isinstance(moves, list) or not moves or len(moves) > 10002:
            raise RuntimeError('archive journal moves is invalid')
        out: list[dict[str, str]] = []
        sources: set[str] = set()
        destinations: set[str] = set()
        job_ids: set[str] = set()
        request_entries: list[dict[str, str]] = []
        claim_entries: list[dict[str, str]] = []
        for entry in moves:
            if not isinstance(entry, dict):
                raise RuntimeError('archive journal has an invalid move entry')
            kind = str(entry.get('kind') or '')
            raw_item_id = str(entry.get('id') or '')
            item_id = _safe_id(raw_item_id, 200)
            source = Path(str(entry.get('source') or ''))
            destination = Path(str(entry.get('destination') or ''))
            if kind not in {'job', 'request', 'claim'} or not item_id or item_id != raw_item_id:
                raise RuntimeError('archive journal has an invalid move identity')
            if not source.is_absolute() or not destination.is_absolute():
                raise RuntimeError('archive journal paths must be absolute')
            allowed_source_root = JOBS if kind == 'job' else (REQUESTS if kind == 'request' else SUBMISSION_IDEMPOTENCY_DIR)
            allowed_destination_root = ARCHIVE_JOBS if kind == 'job' else ARCHIVE_REQUESTS
            try:
                source.relative_to(allowed_source_root)
                destination.relative_to(allowed_destination_root)
            except ValueError as exc:
                raise RuntimeError('archive journal path escaped its managed root') from exc
            if kind == 'claim' and destination.name != '.submission_idempotency.json':
                raise RuntimeError('archive journal claim destination is invalid')
            if kind == 'claim' and (source.parent != SUBMISSION_IDEMPOTENCY_DIR or destination.parent.parent != ARCHIVE_REQUESTS):
                raise RuntimeError('archive journal claim is not attached to a direct request archive')
            if kind != 'claim' and (source.parent != allowed_source_root or destination.parent != allowed_destination_root):
                raise RuntimeError('archive journal move is not a direct managed child')
            source_text = str(source)
            destination_text = str(destination)
            if source_text in sources or destination_text in destinations:
                raise RuntimeError('archive journal contains a duplicate source or destination')
            sources.add(source_text)
            destinations.add(destination_text)
            normalized = {
                'kind': kind,
                'id': item_id,
                'source': source_text,
                'destination': destination_text,
            }
            if kind == 'job':
                if item_id in job_ids or source.name != item_id or not (
                    destination.name == item_id
                    or re.fullmatch(
                        rf'{re.escape(item_id)}__archived_[0-9]{{8}}_[0-9]{{6}}_[a-f0-9]{{10}}',
                        destination.name,
                    )
                ):
                    raise RuntimeError('archive journal job identity does not match its paths')
                job_ids.add(item_id)
            elif kind == 'request':
                if item_id != request_id or source != REQUESTS / request_id or not (
                    destination.name == request_id
                    or re.fullmatch(
                        rf'{re.escape(request_id)}__archived_[0-9]{{8}}_[0-9]{{6}}_[a-f0-9]{{10}}',
                        destination.name,
                    )
                ):
                    raise RuntimeError('archive journal request identity does not match its paths')
                request_entries.append(normalized)
            else:
                if source != _submission_marker_path(item_id):
                    raise RuntimeError('archive journal claim identity does not match its source')
                claim_entries.append(normalized)
            out.append(normalized)
        if len(request_entries) != 1:
            raise RuntimeError('archive journal must contain exactly one request move')
        request_destination = request_entries[0]['destination']
        if len(claim_entries) > 1 or any(
            entry['destination'] != str(Path(request_destination) / '.submission_idempotency.json')
            for entry in claim_entries
        ):
            raise RuntimeError('archive journal claim does not belong to its request move')
        request_index = out.index(request_entries[0])
        if any(entry['kind'] == 'job' for entry in out[request_index + 1:]) or any(
            out.index(entry) < request_index for entry in claim_entries
        ):
            raise RuntimeError('archive journal move order is invalid')
        if job_ids.intersection(missing_jobs):
            raise RuntimeError('archive journal job cannot be both present and missing')
        return out

    def _complete_archive_journal(_owner, journal_path: Path, journal: dict[str, Any]) -> dict[str, Any]:
        """Idempotently roll a durable archive transaction forward to completion."""
        runtime = _owner._runtime
        Any = runtime.Any
        Path = runtime.Path
        _archive_journal_entries = runtime._archive_journal_entries
        _archive_journal_write = runtime._archive_journal_write
        _parse_iso_dt = runtime._parse_iso_dt
        _safe_id = runtime._safe_id
        _safe_text = runtime._safe_text
        _write_archive_meta = runtime._write_archive_meta
        fsync_directory = runtime.fsync_directory
        os = runtime.os

    
        entries = _archive_journal_entries(journal, journal_path=journal_path)
        archived_at = _parse_iso_dt(journal.get('archivedAt'))
        if archived_at is None:  # Defensive for type narrowing; validation above is authoritative.
            raise RuntimeError('archive journal archivedAt is invalid')
        active_created_at = _parse_iso_dt(journal.get('activeCreatedAt'))
        missing_jobs = [
            value for value in (_safe_id(str(item or ''), 200) for item in (journal.get('missingJobs') or []))
            if value
        ]
        retention_reason = _safe_text(journal.get('retentionReason') or 'terminal-age', 80)
        for entry in entries:
            source = Path(entry['source'])
            destination = Path(entry['destination'])
            if destination.exists():
                if destination.is_symlink() or (
                    entry['kind'] in {'job', 'request'} and not destination.is_dir()
                ) or (entry['kind'] == 'claim' and not destination.is_file()):
                    raise RuntimeError(f'archive recovery destination has an invalid type: {entry["id"]}')
                if source.exists():
                    raise RuntimeError(f'archive recovery found both source and destination: {entry["id"]}')
                continue
            if not source.exists():
                raise RuntimeError(f'archive recovery lost both source and destination: {entry["id"]}')
            if source.is_symlink() or (
                entry['kind'] in {'job', 'request'} and not source.is_dir()
            ) or (entry['kind'] == 'claim' and not source.is_file()):
                raise RuntimeError(f'archive recovery source has an invalid type: {entry["id"]}')
            if destination.parent.exists() and (
                destination.parent.is_symlink() or not destination.parent.is_dir()
            ):
                raise RuntimeError(f'archive recovery destination parent has an invalid type: {entry["id"]}')
            destination.parent.mkdir(parents=True, exist_ok=True)
            os.replace(source, destination)
            fsync_directory(source.parent)
            fsync_directory(destination.parent)
    
        for entry in entries:
            if entry['kind'] not in {'job', 'request'}:
                continue
            destination = Path(entry['destination'])
            details: dict[str, Any] = {'retentionReason': retention_reason}
            if entry['kind'] == 'request':
                details['missingJobs'] = missing_jobs
                details['degradedArchive'] = bool(missing_jobs)
            _write_archive_meta(
                destination,
                kind=entry['kind'],
                item_id=entry['id'],
                archived_at=archived_at,
                active_created_at=active_created_at,
                details=details,
            )
    
        journal['state'] = 'COMMITTED'
        _archive_journal_write(journal_path, journal)
        journal_path.unlink(missing_ok=True)
        fsync_directory(journal_path.parent)
        return {'ok': True, 'missingJobs': missing_jobs}

    def _reconcile_archive_transactions(_owner) -> dict[str, Any]:
        """Finish archive transactions whose process died after the durable intent."""
        runtime = _owner._runtime
        ARCHIVE_ROOT = runtime.ARCHIVE_ROOT
        ARCHIVE_TRANSACTIONS = runtime.ARCHIVE_TRANSACTIONS
        Any = runtime.Any
        _ARCHIVE_TRANSACTION_LOCK = runtime._ARCHIVE_TRANSACTION_LOCK
        _append_system_event = runtime._append_system_event
        _complete_archive_journal = runtime._complete_archive_journal
        _ensure_archive_dirs = runtime._ensure_archive_dirs
        _fcntl = runtime._fcntl
        strict_json_load = runtime.strict_json_load

    
        _ensure_archive_dirs()
        result: dict[str, Any] = {'recovered': 0, 'errors': []}
        with _ARCHIVE_TRANSACTION_LOCK:
            lock_path = ARCHIVE_ROOT / '.archive_transaction.lock'
            with open(lock_path, 'a+b', buffering=0) as lock_handle:
                if _fcntl is not None:
                    _fcntl.flock(lock_handle.fileno(), _fcntl.LOCK_EX)
                try:
                    for journal_path in sorted(ARCHIVE_TRANSACTIONS.glob('archive_*.json')):
                        try:
                            journal = strict_json_load(journal_path)
                            if not isinstance(journal, dict):
                                raise RuntimeError('archive journal root is invalid')
                            _complete_archive_journal(journal_path, journal)
                            result['recovered'] += 1
                        except Exception as exc:
                            result['errors'].append({'journal': journal_path.name, 'error': str(exc)})
                            _append_system_event(
                                level='error',
                                component='retention',
                                message_user='Een onderbroken archivering vereist controle',
                                message_tech=f'{journal_path.name}: {exc}',
                                status='open',
                            )
                finally:
                    if _fcntl is not None:
                        _fcntl.flock(lock_handle.fileno(), _fcntl.LOCK_UN)
        return result

    def _linked_job_ids_from_status(_owner, st: dict | None) -> list[str]:
        runtime = _owner._runtime
        _safe_id = runtime._safe_id

        out = []
        if not isinstance(st, dict):
            return out
        job = st.get('job') if isinstance(st.get('job'), dict) else {}
        parent = _safe_id(str(job.get('parentJobId') or '').strip(), 200)
        if parent:
            out.append(parent)
        for sj in (job.get('subjobs') or []):
            sj_id = ''
            if isinstance(sj, dict):
                sj_id = str(sj.get('subjobId') or sj.get('jobId') or sj.get('id') or '').strip()
            else:
                sj_id = str(sj or '').strip()
            sj_id = _safe_id(sj_id, 200) if sj_id else ''
            if sj_id and sj_id not in out:
                out.append(sj_id)
        return out

    def _archive_request_and_linked_jobs(_owner, request_id: str, *, retention_reason: str = 'terminal-age') -> dict:
        runtime = _owner._runtime
        ARCHIVE_JOBS = runtime.ARCHIVE_JOBS
        ARCHIVE_META_NAME = runtime.ARCHIVE_META_NAME
        ARCHIVE_QUEUE_DONE = runtime.ARCHIVE_QUEUE_DONE
        ARCHIVE_QUEUE_FAILED = runtime.ARCHIVE_QUEUE_FAILED
        ARCHIVE_REQUESTS = runtime.ARCHIVE_REQUESTS
        ARCHIVE_ROOT = runtime.ARCHIVE_ROOT
        Any = runtime.Any
        JOBS = runtime.JOBS
        Path = runtime.Path
        QUEUE_DONE = runtime.QUEUE_DONE
        QUEUE_FAILED = runtime.QUEUE_FAILED
        REQUESTS = runtime.REQUESTS
        _ARCHIVE_TRANSACTION_LOCK = runtime._ARCHIVE_TRANSACTION_LOCK
        _archive_journal_path = runtime._archive_journal_path
        _archive_journal_write = runtime._archive_journal_write
        _ensure_archive_dirs = runtime._ensure_archive_dirs
        _linked_job_ids_from_status = runtime._linked_job_ids_from_status
        _load_status = runtime._load_status
        _request_created_dt_from_status = runtime._request_created_dt_from_status
        _safe_id = runtime._safe_id
        _safe_text = runtime._safe_text
        _submission_marker_path = runtime._submission_marker_path
        _unique_archive_dest = runtime._unique_archive_dest
        _utc_now_iso = runtime._utc_now_iso
        _write_archive_meta = runtime._write_archive_meta
        _fcntl = runtime._fcntl
        datetime = runtime.datetime
        fsync_directory = runtime.fsync_directory
        os = runtime.os
        secrets = runtime.secrets
        strict_json_load = runtime.strict_json_load
        timezone = runtime.timezone

        rid = _safe_id(str(request_id or '').strip(), 120)
        if not rid:
            return {'ok': False, 'error': 'missing requestId'}
        req_dir = REQUESTS / rid
        archived_at = datetime.now(timezone.utc).replace(tzinfo=None)
        _ensure_archive_dirs()
        moved_jobs: list[str] = []
        queue_errors: list[str] = []
        commit_warnings: list[str] = []
        req_dest: Path | None = None
        missing_jobs: list[str] = []
    
        # RLock serializes in-process maintenance/admin calls. The advisory lock
        # extends the exact same transaction boundary to the optional queue-worker
        # process which also runs retention maintenance.
        with _ARCHIVE_TRANSACTION_LOCK:
            lock_path = ARCHIVE_ROOT / '.archive_transaction.lock'
            with open(lock_path, 'a+b', buffering=0) as lock_handle:
                if _fcntl is not None:
                    _fcntl.flock(lock_handle.fileno(), _fcntl.LOCK_EX)
                moved: list[tuple[Path, Path]] = []
                metadata_paths: list[Path] = []
                journal_path: Path | None = None
                journal: dict[str, Any] | None = None
                try:
                    if not req_dir.exists() or not req_dir.is_dir():
                        return {'ok': False, 'error': 'request missing'}
                    st = _load_status(rid) or {}
                    active_created_at = _request_created_dt_from_status(st, req_dir)
                    linked_jobs = _linked_job_ids_from_status(st)
                    active_references: set[str] = set()
                    for other in REQUESTS.iterdir() if REQUESTS.exists() else []:
                        if not other.is_dir() or other.name == rid:
                            continue
                        active_references.update(_linked_job_ids_from_status(_load_status(other.name)))
    
                    required_jobs: list[tuple[str, Path, Path]] = []
                    for jid in linked_jobs:
                        if jid in active_references:
                            continue
                        source = JOBS / jid
                        if not source.exists() or not source.is_dir():
                            missing_jobs.append(jid)
                            continue
                        required_jobs.append((jid, source, _unique_archive_dest(ARCHIVE_JOBS, jid)))
                    req_dest = _unique_archive_dest(ARCHIVE_REQUESTS, rid)
    
                    marker_source: Path | None = None
                    parent_job_id = ''
                    job = st.get('job') if isinstance(st.get('job'), dict) else {}
                    parent_job_id = _safe_id(str(job.get('parentJobId') or ''), 200)
                    if parent_job_id:
                        candidate = _submission_marker_path(parent_job_id)
                        if candidate.is_file():
                            marker_obj = strict_json_load(candidate)
                            if _safe_id(str(marker_obj.get('requestId') or ''), 120) == rid:
                                marker_source = candidate
    
                    transaction_id = f'archive_{secrets.token_hex(16)}'
                    journal_path = _archive_journal_path(transaction_id)
                    moves = [
                        {'kind': 'job', 'id': jid, 'source': str(source), 'destination': str(destination)}
                        for jid, source, destination in required_jobs
                    ]
                    moves.append({'kind': 'request', 'id': rid, 'source': str(req_dir), 'destination': str(req_dest)})
                    if marker_source is not None:
                        moves.append({
                            'kind': 'claim',
                            'id': parent_job_id,
                            'source': str(marker_source),
                            'destination': str(req_dest / '.submission_idempotency.json'),
                        })
                    journal = {
                        'schemaVersion': 1,
                        'transactionId': transaction_id,
                        'state': 'PREPARED',
                        'requestId': rid,
                        'archivedAt': archived_at.isoformat() + 'Z',
                        'activeCreatedAt': active_created_at.isoformat() + 'Z' if active_created_at else None,
                        'retentionReason': _safe_text(retention_reason or 'terminal-age', 80),
                        'missingJobs': missing_jobs,
                        'moves': moves,
                        'createdAt': _utc_now_iso(),
                    }
                    _archive_journal_write(journal_path, journal)
    
                    for jid, source, destination in required_jobs:
                        os.replace(source, destination)
                        moved.append((source, destination))
                        fsync_directory(source.parent)
                        fsync_directory(destination.parent)
                        moved_jobs.append(destination.name)
                    os.replace(req_dir, req_dest)
                    moved.append((req_dir, req_dest))
                    fsync_directory(req_dir.parent)
                    fsync_directory(req_dest.parent)
    
                    for jid, _source, destination in required_jobs:
                        meta_path = destination / ARCHIVE_META_NAME
                        metadata_paths.append(meta_path)
                        _write_archive_meta(
                            destination,
                            kind='job',
                            item_id=jid,
                            archived_at=archived_at,
                            active_created_at=active_created_at,
                            details={'retentionReason': journal['retentionReason']},
                        )
                    req_meta_path = req_dest / ARCHIVE_META_NAME
                    metadata_paths.append(req_meta_path)
                    _write_archive_meta(
                        req_dest,
                        kind='request',
                        item_id=rid,
                        archived_at=archived_at,
                        active_created_at=active_created_at,
                        details={
                            'retentionReason': journal['retentionReason'],
                            'missingJobs': missing_jobs,
                            'degradedArchive': bool(missing_jobs),
                        },
                    )
    
                    # The active idempotency claim is moved into the request archive,
                    # not unlinked. This makes removal reversible until commit and keeps
                    # the forensic relationship available until archive expiry.
                    if marker_source is not None:
                        marker_destination = req_dest / '.submission_idempotency.json'
                        if marker_destination.exists():
                            raise RuntimeError('archive request already contains an idempotency marker')
                        os.replace(marker_source, marker_destination)
                        moved.append((marker_source, marker_destination))
                        fsync_directory(marker_source.parent)
                        fsync_directory(marker_destination.parent)
                    journal['state'] = 'COMMITTED'
                    _archive_journal_write(journal_path, journal)
                    # Once COMMITTED is durable every required move and metadata
                    # write is complete. Journal cleanup may be retried by startup;
                    # a cleanup failure must never roll an already committed family
                    # back without a durable intent record.
                    try:
                        journal_path.unlink(missing_ok=True)
                        fsync_directory(journal_path.parent)
                    except Exception as cleanup_error:
                        commit_warnings.append(f'journal-cleanup:{cleanup_error}')
                except Exception as exc:
                    rollback_errors: list[str] = []
                    for meta_path in reversed(metadata_paths):
                        try:
                            meta_path.unlink(missing_ok=True)
                            fsync_directory(meta_path.parent)
                        except Exception as rollback_error:
                            rollback_errors.append(f'metadata:{meta_path.name}:{rollback_error}')
                    for source, destination in reversed(moved):
                        try:
                            if destination.exists():
                                source.parent.mkdir(parents=True, exist_ok=True)
                                os.replace(destination, source)
                                fsync_directory(destination.parent)
                                fsync_directory(source.parent)
                        except Exception as rollback_error:
                            rollback_errors.append(f'move:{destination.name}:{rollback_error}')
                    if journal_path is not None and not rollback_errors:
                        try:
                            journal_path.unlink(missing_ok=True)
                            fsync_directory(journal_path.parent)
                        except Exception as rollback_error:
                            rollback_errors.append(f'journal:{journal_path.name}:{rollback_error}')
                    return {
                        'ok': False,
                        'error': f'archive transaction rolled back: {exc}',
                        'rollbackErrors': rollback_errors,
                        'movedJobs': [],
                    }
                finally:
                    if _fcntl is not None:
                        _fcntl.flock(lock_handle.fileno(), _fcntl.LOCK_UN)
    
        # Queue files are mirrors of authoritative request status. They are explicitly
        # best-effort: a mirror failure cannot undo the committed request/job archive.
        for src_dir, arc_dir in ((QUEUE_DONE, ARCHIVE_QUEUE_DONE), (QUEUE_FAILED, ARCHIVE_QUEUE_FAILED)):
            try:
                src = src_dir / f'{rid}.json'
                if src.exists() and src.is_file():
                    destination = _unique_archive_dest(arc_dir, src.name)
                    os.replace(src, destination)
                    fsync_directory(destination.parent)
                    fsync_directory(src.parent)
            except Exception as exc:
                queue_errors.append(f'{src_dir.name}:{exc}')
    
        return {
            'ok': True,
            'requestId': rid,
            'archivedRequestDir': req_dest.name if req_dest is not None else '',
            'movedJobs': moved_jobs,
            'queueMirrorsBestEffort': True,
            'queueMirrorErrors': queue_errors,
            'commitWarnings': commit_warnings,
            'missingJobs': missing_jobs,
            'degradedArchive': bool(missing_jobs),
        }

    EXPORTS = ('_parse_iso_dt', '_path_dt', '_request_status_path', '_request_created_dt_from_status', '_request_archive_meta_dt', '_job_created_dt', '_write_archive_meta', '_unique_archive_dest', '_archive_journal_path', '_archive_journal_write', '_archive_journal_entries', '_complete_archive_journal', '_reconcile_archive_transactions', '_linked_job_ids_from_status', '_archive_request_and_linked_jobs')

__all__ = ("ArchiveRuntime",)
