"""Storage coordination primitives for the R9 composition root."""

