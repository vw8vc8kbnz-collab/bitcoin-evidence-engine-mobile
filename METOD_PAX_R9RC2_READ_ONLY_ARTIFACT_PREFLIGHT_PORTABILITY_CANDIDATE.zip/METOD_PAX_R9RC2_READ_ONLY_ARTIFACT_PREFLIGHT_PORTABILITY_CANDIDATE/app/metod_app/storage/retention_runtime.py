from __future__ import annotations

"""Bounded RetentionRuntime implementation with explicit runtime injection."""

class RetentionRuntime:
    def __init__(self, runtime):
        self._runtime = runtime

    def _purge_old_archives(_owner, now_dt: Optional[datetime] = None) -> dict:
        runtime = _owner._runtime
        ARCHIVE_JOBS = runtime.ARCHIVE_JOBS
        ARCHIVE_QUEUE_DONE = runtime.ARCHIVE_QUEUE_DONE
        ARCHIVE_QUEUE_FAILED = runtime.ARCHIVE_QUEUE_FAILED
        ARCHIVE_REQUESTS = runtime.ARCHIVE_REQUESTS
        Optional = runtime.Optional
        Path = runtime.Path
        RETENTION_ARCHIVE_DAYS = runtime.RETENTION_ARCHIVE_DAYS
        _ensure_archive_dirs = runtime._ensure_archive_dirs
        _path_dt = runtime._path_dt
        _request_archive_meta_dt = runtime._request_archive_meta_dt
        datetime = runtime.datetime
        fsync_directory = runtime.fsync_directory
        shutil = runtime.shutil
        timedelta = runtime.timedelta
        timezone = runtime.timezone

        _ensure_archive_dirs()
        now_dt = now_dt or datetime.now(timezone.utc).replace(tzinfo=None)
        purged = {'requests': 0, 'jobs': 0, 'queue_done': 0, 'queue_failed': 0, 'errors': []}
    
        def _purge_dir(base: Path, key: str):
            if not base.exists():
                return
            for child in sorted(base.iterdir()):
                if not child.exists():
                    continue
                dt = _request_archive_meta_dt(child) if child.is_dir() else _path_dt(child)
                if dt is None:
                    continue
                if now_dt - dt < timedelta(days=RETENTION_ARCHIVE_DAYS):
                    continue
                try:
                    if child.is_dir():
                        shutil.rmtree(child, ignore_errors=False)
                    else:
                        child.unlink(missing_ok=True)
                    fsync_directory(base)
                    purged[key] += 1
                except Exception as exc:
                    purged['errors'].append({'path': str(child), 'error': str(exc)})
    
        _purge_dir(ARCHIVE_REQUESTS, 'requests')
        _purge_dir(ARCHIVE_JOBS, 'jobs')
        _purge_dir(ARCHIVE_QUEUE_DONE, 'queue_done')
        _purge_dir(ARCHIVE_QUEUE_FAILED, 'queue_failed')
        return purged

    def _request_is_terminal_for_retention(_owner, status: dict | None) -> bool:
        runtime = _owner._runtime

        if not isinstance(status, dict):
            return False
        public_status = str(status.get('publicStatus') or '').strip().upper()
        internal_status = str(status.get('internalStatus') or '').strip().upper()
        quote_status = str(status.get('quoteStatus') or '').strip().upper()
        return bool(
            public_status in {'DONE', 'AFGEHANDELD', 'CANCELLED'}
            or internal_status in {'FAILED', 'CANCELLED'}
            or (internal_status == 'DONE' and quote_status in {'DONE', 'CANCELLED'})
        )

    def _archive_expired_active_data(_owner, now_dt: Optional[datetime] = None) -> dict:
        runtime = _owner._runtime
        JOBS = runtime.JOBS
        ORPHAN_JOB_RETENTION_DAYS = runtime.ORPHAN_JOB_RETENTION_DAYS
        Optional = runtime.Optional
        REQUESTS = runtime.REQUESTS
        RETENTION_ACTIVE_DAYS = runtime.RETENTION_ACTIVE_DAYS
        RETENTION_OPEN_REQUEST_MAX_DAYS = runtime.RETENTION_OPEN_REQUEST_MAX_DAYS
        _append_system_event = runtime._append_system_event
        _archive_request_and_linked_jobs = runtime._archive_request_and_linked_jobs
        _ensure_archive_dirs = runtime._ensure_archive_dirs
        _ensure_request_dirs = runtime._ensure_request_dirs
        _find_request_status_for_job = runtime._find_request_status_for_job
        _job_created_dt = runtime._job_created_dt
        _linked_job_ids_from_status = runtime._linked_job_ids_from_status
        _load_status = runtime._load_status
        _request_created_dt_from_status = runtime._request_created_dt_from_status
        _request_is_terminal_for_retention = runtime._request_is_terminal_for_retention
        datetime = runtime.datetime
        fsync_directory = runtime.fsync_directory
        shutil = runtime.shutil
        timedelta = runtime.timedelta
        timezone = runtime.timezone

        _ensure_request_dirs()
        _ensure_archive_dirs()
        now_dt = now_dt or datetime.now(timezone.utc).replace(tzinfo=None)
        archived = {'requests': 0, 'orphanJobsDeleted': 0, 'errors': []}
        processed_job_ids = set()
    
        # First archive submitted requests as the leading contract; this pulls linked parent/subjobs with it.
        for req_dir in sorted(REQUESTS.iterdir()):
            if not req_dir.is_dir():
                continue
            rid = req_dir.name
            st = _load_status(rid) or {}
            created_dt = _request_created_dt_from_status(st, req_dir)
            if created_dt is None:
                continue
            age = now_dt - created_dt
            terminal = _request_is_terminal_for_retention(st)
            retention_reason = 'terminal-age' if terminal else 'open-hard-limit'
            retention_days = RETENTION_ACTIVE_DAYS if terminal else RETENTION_OPEN_REQUEST_MAX_DAYS
            if age < timedelta(days=retention_days):
                continue
            for jid in _linked_job_ids_from_status(st):
                processed_job_ids.add(jid)
            res = _archive_request_and_linked_jobs(rid, retention_reason=retention_reason)
            if res.get('ok'):
                archived['requests'] += 1
                for jid in (res.get('movedJobs') or []):
                    processed_job_ids.add(str(jid))
                for queue_error in (res.get('queueMirrorErrors') or []):
                    archived['errors'].append({'requestId': rid, 'error': str(queue_error)})
                for commit_warning in (res.get('commitWarnings') or []):
                    archived['errors'].append({'requestId': rid, 'error': str(commit_warning)})
                if retention_reason == 'open-hard-limit' or res.get('degradedArchive'):
                    _append_system_event(
                        level='warning',
                        component='retention',
                        message_user='Een aanvraag is met bewaarschuwing gearchiveerd',
                        message_tech=(
                            f'request={rid}; reason={retention_reason}; '
                            f'missingJobs={res.get("missingJobs") or []}'
                        ),
                        request_id=rid,
                        status='open',
                    )
            else:
                archived['errors'].append({'requestId': rid, 'error': res.get('error') or 'archive failed'})
    
        # Then delete orphan jobs with no request mapping after a much shorter retention window.
        for job_dir in sorted(JOBS.iterdir()):
            if not job_dir.is_dir():
                continue
            jid = job_dir.name
            if jid in processed_job_ids:
                continue
            if _find_request_status_for_job(jid):
                continue
            created_dt = _job_created_dt(job_dir)
            if created_dt is None or (now_dt - created_dt) < timedelta(days=ORPHAN_JOB_RETENTION_DAYS):
                continue
            try:
                shutil.rmtree(job_dir, ignore_errors=False)
                fsync_directory(JOBS)
                archived['orphanJobsDeleted'] += 1
            except Exception as e:
                archived['errors'].append({'jobId': jid, 'error': str(e)})
        return archived

    def _cleanup_operational_state(_owner, now_dt: Optional[datetime] = None) -> dict:
        """Bound reconstructable operational state without touching live records.
    
        Catalog stage files and image-preparation directories are private, disposable
        review artifacts.  The current published import and any in-flight image sync
        are always excluded.  Likewise, live decor media and queue mirrors belonging
        to an active request are never candidates.
        """
        runtime = _owner._runtime
        CATALOG_IMPORT_HISTORY = runtime.CATALOG_IMPORT_HISTORY
        CATALOG_IMPORT_ROOT = runtime.CATALOG_IMPORT_ROOT
        DECOR_MEDIA_ROOT = runtime.DECOR_MEDIA_ROOT
        DRAFTS = runtime.DRAFTS
        JOBS = runtime.JOBS
        MATERIAL_LIBRARY_PATH = runtime.MATERIAL_LIBRARY_PATH
        Optional = runtime.Optional
        Path = runtime.Path
        QUEUE_DONE = runtime.QUEUE_DONE
        QUEUE_FAILED = runtime.QUEUE_FAILED
        REQUESTS = runtime.REQUESTS
        STATE_ROOT = runtime.STATE_ROOT
        SUBMISSION_IDEMPOTENCY_DIR = runtime.SUBMISSION_IDEMPOTENCY_DIR
        SYSTEM_DIR = runtime.SYSTEM_DIR
        SYSTEM_LOG_FILE = runtime.SYSTEM_LOG_FILE
        _CATALOG_IMAGE_SYNC_ACTIVE = runtime._CATALOG_IMAGE_SYNC_ACTIVE
        _CATALOG_IMAGE_SYNC_LOCK = runtime._CATALOG_IMAGE_SYNC_LOCK
        _PUBLIC_MATERIAL_ID_RE = runtime._PUBLIC_MATERIAL_ID_RE
        _ensure_request_dirs = runtime._ensure_request_dirs
        _ensure_system_dirs = runtime._ensure_system_dirs
        _env_int = runtime._env_int
        _path_dt = runtime._path_dt
        _safe_id = runtime._safe_id
        datetime = runtime.datetime
        delete_rotating_log_if_older_than = runtime.delete_rotating_log_if_older_than
        fsync_directory = runtime.fsync_directory
        re = runtime.re
        shutil = runtime.shutil
        strict_json_load = runtime.strict_json_load
        timedelta = runtime.timedelta
        timezone = runtime.timezone

    
        _ensure_request_dirs()
        _ensure_system_dirs()
        now_dt = now_dt or datetime.now(timezone.utc).replace(tzinfo=None)
        result = {
            'catalogStages': 0,
            'catalogHistory': 0,
            'orphanDecorMedia': 0,
            'orphanQueueDone': 0,
            'orphanQueueFailed': 0,
            'orphanSubmissionClaims': 0,
            'orphanDrafts': 0,
            'rotatedLogs': 0,
            'errors': [],
        }
    
        def is_old(path: Path, days: int) -> bool:
            dt = _path_dt(path)
            return bool(dt is not None and now_dt - dt >= timedelta(days=max(1, days)))
    
        active_import_id = ''
        active_public_ids: set[str] = set()
        catalog_authority_ok = True
        try:
            library = strict_json_load(MATERIAL_LIBRARY_PATH)
            if isinstance(library, dict):
                last_import = library.get('lastCatalogImport') if isinstance(library.get('lastCatalogImport'), dict) else {}
                candidate = str(last_import.get('importId') or '').strip().lower()
                if re.fullmatch(r'cat_[a-f0-9]{24}', candidate):
                    active_import_id = candidate
                for record in library.get('records') or []:
                    if not isinstance(record, dict):
                        continue
                    if record.get('active') is False or record.get('published') is False or record.get('archived') is True:
                        continue
                    public_id = str(record.get('publicMaterialId') or '').strip().lower()
                    if _PUBLIC_MATERIAL_ID_RE.fullmatch(public_id):
                        active_public_ids.add(public_id)
        except Exception as exc:
            # Without an authoritative library no media/catalog-stage deletion is safe.
            result['errors'].append(f'active catalog unreadable: {exc}')
            catalog_authority_ok = False
    
        with _CATALOG_IMAGE_SYNC_LOCK:
            syncing_imports = set(_CATALOG_IMAGE_SYNC_ACTIVE)
        stage_days = max(1, _env_int('CATALOG_STAGE_RETENTION_DAYS', 7))
        stage_patterns = (
            re.compile(r'^(cat_[a-f0-9]{24})\.json$'),
            re.compile(r'^(cat_[a-f0-9]{24})_images\.json$'),
            re.compile(r'^(cat_[a-f0-9]{24})_media$'),
        )
        for path in sorted(CATALOG_IMPORT_ROOT.iterdir() if CATALOG_IMPORT_ROOT.exists() else []):
            if not catalog_authority_ok:
                break
            if path.name == 'history':
                continue
            import_id = ''
            for pattern in stage_patterns:
                match = pattern.fullmatch(path.name)
                if match:
                    import_id = match.group(1)
                    break
            if not import_id or import_id == active_import_id or import_id in syncing_imports or not is_old(path, stage_days):
                continue
            try:
                if path.is_dir():
                    shutil.rmtree(path, ignore_errors=False)
                elif path.is_file():
                    path.unlink(missing_ok=True)
                else:
                    continue
                fsync_directory(CATALOG_IMPORT_ROOT)
                result['catalogStages'] += 1
            except Exception as exc:
                result['errors'].append(f'catalog stage {path.name}: {exc}')
    
        history_keep = max(1, min(1000, _env_int('CATALOG_HISTORY_KEEP', 12)))
        history_days = max(1, _env_int('CATALOG_HISTORY_RETENTION_DAYS', 180))
        history_items = sorted(
            [path for path in CATALOG_IMPORT_HISTORY.iterdir() if path.is_dir()],
            key=lambda path: path.stat().st_mtime,
            reverse=True,
        ) if CATALOG_IMPORT_HISTORY.exists() else []
        for index, path in enumerate(history_items):
            if index < history_keep and not is_old(path, history_days):
                continue
            try:
                shutil.rmtree(path, ignore_errors=False)
                fsync_directory(CATALOG_IMPORT_HISTORY)
                result['catalogHistory'] += 1
            except Exception as exc:
                result['errors'].append(f'catalog history {path.name}: {exc}')
    
        media_days = max(1, _env_int('ORPHAN_DECOR_MEDIA_RETENTION_DAYS', 30))
        for path in sorted(DECOR_MEDIA_ROOT.iterdir() if DECOR_MEDIA_ROOT.exists() else []):
            if not catalog_authority_ok:
                break
            if not path.is_dir() or not _PUBLIC_MATERIAL_ID_RE.fullmatch(path.name):
                continue
            if path.name in active_public_ids or not is_old(path, media_days):
                continue
            try:
                shutil.rmtree(path, ignore_errors=False)
                fsync_directory(DECOR_MEDIA_ROOT)
                result['orphanDecorMedia'] += 1
            except Exception as exc:
                result['errors'].append(f'decor media {path.name}: {exc}')
    
        queue_days = max(1, _env_int('ORPHAN_QUEUE_RETENTION_DAYS', 30))
        for queue_dir, key in ((QUEUE_DONE, 'orphanQueueDone'), (QUEUE_FAILED, 'orphanQueueFailed')):
            for path in sorted(queue_dir.glob('*.json')):
                if not is_old(path, queue_days):
                    continue
                request_id = ''
                try:
                    payload = strict_json_load(path)
                    request_id = _safe_id(str((payload or {}).get('requestId') or ''), 120)
                except Exception:
                    pass
                if request_id and (REQUESTS / request_id).is_dir():
                    continue
                try:
                    path.unlink(missing_ok=True)
                    fsync_directory(queue_dir)
                    result[key] += 1
                except Exception as exc:
                    result['errors'].append(f'queue mirror {path.name}: {exc}')
    
        claim_days = max(1, _env_int('ORPHAN_SUBMISSION_CLAIM_RETENTION_DAYS', 1))
        for marker in sorted(SUBMISSION_IDEMPOTENCY_DIR.glob('*.json')):
            if not is_old(marker, claim_days):
                continue
            request_id = ''
            try:
                claim = strict_json_load(marker)
                request_id = _safe_id(str((claim or {}).get('requestId') or ''), 120)
            except Exception:
                pass
            if request_id and (REQUESTS / request_id / 'status.json').is_file():
                continue
            try:
                marker.unlink(missing_ok=True)
                fsync_directory(SUBMISSION_IDEMPOTENCY_DIR)
                result['orphanSubmissionClaims'] += 1
            except Exception as exc:
                result['errors'].append(f'submission claim {marker.name}: {exc}')
    
        draft_days = max(1, _env_int('ORPHAN_DRAFT_RETENTION_DAYS', 30))
        for draft in sorted(DRAFTS.iterdir() if DRAFTS.exists() else []):
            if not (draft.is_file() or draft.is_dir()) or not is_old(draft, draft_days):
                continue
            try:
                if draft.is_dir():
                    shutil.rmtree(draft, ignore_errors=False)
                else:
                    draft.unlink(missing_ok=True)
                fsync_directory(DRAFTS)
                result['orphanDrafts'] += 1
            except Exception as exc:
                result['errors'].append(f'draft {draft.name}: {exc}')
    
        # Active writers already impose byte/count caps. Enforce the same hard age
        # bound on active files so low-volume logs cannot retain personal or
        # operational data indefinitely.
        log_days = max(1, _env_int('ROTATED_LOG_RETENTION_DAYS', 30))
        log_roots = [SYSTEM_DIR, STATE_ROOT / 'client_logs', JOBS / '_crash_logs']
        cutoff_ts = (now_dt - timedelta(days=log_days)).timestamp()
        active_logs = (
            SYSTEM_LOG_FILE,
            STATE_ROOT / 'client_logs' / 'general_client_log.jsonl',
            STATE_ROOT / 'client_logs' / 'ntfy.log',
        )
        for path in active_logs:
            try:
                if delete_rotating_log_if_older_than(path, cutoff_timestamp=cutoff_ts):
                    result['rotatedLogs'] += 1
            except Exception as exc:
                result['errors'].append(f'active log {path.name}: {exc}')
        for root in log_roots:
            if not root.exists():
                continue
            for path in sorted(root.rglob('*')):
                if not path.is_file() or not is_old(path, log_days):
                    continue
                name = path.name.lower()
                rotated = bool(
                    re.search(r'\.(?:jsonl|log)\.\d+$', name)
                    or (root == JOBS / '_crash_logs' and name.startswith('api_jobs_') and name.endswith('.json'))
                )
                if not rotated:
                    continue
                try:
                    path.unlink(missing_ok=True)
                    fsync_directory(path.parent)
                    result['rotatedLogs'] += 1
                except Exception as exc:
                    result['errors'].append(f'rotated log {path.name}: {exc}')
        return result

    def _move_queue_file_safe(_owner, src: Path, dest_dir: Path) -> Path:
        runtime = _owner._runtime
        Path = runtime.Path
        fsync_directory = runtime.fsync_directory
        os = runtime.os
        time = runtime.time

        source_parent = Path(src).parent
        dest_dir.mkdir(parents=True, exist_ok=True)
        dest = dest_dir / src.name
        if dest.exists():
            stamp = time.strftime('%Y%m%d_%H%M%S')
            dest = dest_dir / f"{src.stem}__{stamp}{src.suffix}"
        os.replace(str(src), str(dest))
        fsync_directory(dest_dir)
        if source_parent.resolve() != dest_dir.resolve():
            fsync_directory(source_parent)
        return dest

    def _mark_request_failed_if_stale(_owner, request_id: str, *, code: str, message: str) -> None:
        runtime = _owner._runtime
        _load_status = runtime._load_status
        _save_status = runtime._save_status

        status = _load_status(request_id) or {}
        if status.get('internalStatus') in {'DONE', 'FAILED', 'CANCELLED'}:
            return
        status['internalStatus'] = 'FAILED'
        status['internalStatusLabel'] = 'Fout'
        status['error'] = {'code': code, 'message': message}
        _save_status(request_id, status)

    def _record_maintenance_failure(_owner, component: str, user_message: str, failure: object) -> None:
        runtime = _owner._runtime
        _append_system_event = runtime._append_system_event
        _redact_sensitive_text = runtime._redact_sensitive_text

        if isinstance(failure, BaseException):
            detail = f'{type(failure).__name__}: {failure}'
        elif isinstance(failure, dict):
            detail = str(failure.get('errors') or failure.get('error') or failure)
        else:
            detail = str(failure)
        _append_system_event(
            level='error',
            component=component,
            message_user=user_message,
            message_tech=_redact_sensitive_text(detail, 1200),
            status='open',
        )

    def _server_maintenance_loop(_owner, interval_seconds: float = 15 * 60) -> None:
        runtime = _owner._runtime
        _SERVER_MAINTENANCE_LOOP_SECONDS = runtime._SERVER_MAINTENANCE_LOOP_SECONDS
        _record_maintenance_failure = runtime._record_maintenance_failure
        run_backup_maintenance = runtime.run_backup_maintenance
        run_queue_maintenance = runtime.run_queue_maintenance
        run_retention_maintenance = runtime.run_retention_maintenance
        time = runtime.time

        while True:
            try:
                retention = run_retention_maintenance(force=False)
                if not retention.get('ok', False):
                    _record_maintenance_failure('retention', 'Automatisch retentieonderhoud is niet volledig uitgevoerd', retention)
            except Exception as exc:
                _record_maintenance_failure('retention', 'Automatisch retentieonderhoud is gecrasht', exc)
            try:
                run_backup_maintenance(force=False)
            except Exception as exc:
                _record_maintenance_failure('backup', 'Automatisch backuponderhoud is gecrasht', exc)
            try:
                queue_result = run_queue_maintenance(force=False)
                if not queue_result.get('ok', False):
                    _record_maintenance_failure('jobs', 'Automatisch queue-onderhoud is niet volledig uitgevoerd', queue_result)
            except Exception as exc:
                _record_maintenance_failure('jobs', 'Automatisch queue-onderhoud is gecrasht', exc)
            time.sleep(interval_seconds)

    EXPORTS = ('_purge_old_archives', '_request_is_terminal_for_retention', '_archive_expired_active_data', '_cleanup_operational_state', '_move_queue_file_safe', '_mark_request_failed_if_stale', '_record_maintenance_failure', '_server_maintenance_loop')

__all__ = ("RetentionRuntime",)
