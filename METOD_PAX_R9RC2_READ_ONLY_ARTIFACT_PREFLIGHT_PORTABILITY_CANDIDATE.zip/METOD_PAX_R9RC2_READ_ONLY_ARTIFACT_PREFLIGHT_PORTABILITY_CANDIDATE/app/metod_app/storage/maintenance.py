from __future__ import annotations

"""One owner for the existing state-mutation and maintenance barrier policy."""

from contextlib import contextmanager
from pathlib import Path
from typing import Any, Callable, Iterator


Provider = Callable[[], Any]
Setter = Callable[[Any], None]


class StateMaintenanceBarrier:
    """Coordinate live mutations, destructive maintenance and consistent snapshots.

    All locks, counters, paths, clocks and live-work probes are injected by the
    composition root. This keeps the established lock order and state layout
    intact while giving the policy exactly one owner.
    """

    def __init__(
        self,
        *,
        ensure_directories: Callable[[], None],
        backups_root: Provider,
        maintenance_lock: Provider,
        file_lock_module: Provider,
        mutation_condition: Provider,
        snapshot_active: Provider,
        set_snapshot_active: Setter,
        mutation_count: Provider,
        set_mutation_count: Setter,
        public_job_create_lock: Provider,
        public_job_create_total: Provider,
        active_job_processes_lock: Provider,
        active_job_processes: Provider,
        catalog_image_sync_lock: Provider,
        catalog_image_sync_active: Provider,
        queue_processing_root: Provider,
        monotonic: Callable[[], float],
        sleep: Callable[[float], None],
    ) -> None:
        self._ensure_directories = ensure_directories
        self._backups_root = backups_root
        self._maintenance_lock = maintenance_lock
        self._file_lock_module = file_lock_module
        self._mutation_condition = mutation_condition
        self._snapshot_active = snapshot_active
        self._set_snapshot_active = set_snapshot_active
        self._mutation_count = mutation_count
        self._set_mutation_count = set_mutation_count
        self._public_job_create_lock = public_job_create_lock
        self._public_job_create_total = public_job_create_total
        self._active_job_processes_lock = active_job_processes_lock
        self._active_job_processes = active_job_processes
        self._catalog_image_sync_lock = catalog_image_sync_lock
        self._catalog_image_sync_active = catalog_image_sync_active
        self._queue_processing_root = queue_processing_root
        self._monotonic = monotonic
        self._sleep = sleep

    def snapshot_is_active(self) -> bool:
        with self._mutation_condition():
            return bool(self._snapshot_active())

    def begin_mutation(self) -> bool:
        """Enter one live state mutation or fail closed during a snapshot."""

        with self._mutation_condition():
            if self._snapshot_active():
                return False
            self._set_mutation_count(int(self._mutation_count()) + 1)
            return True

    def end_mutation(self) -> None:
        condition = self._mutation_condition()
        with condition:
            self._set_mutation_count(max(0, int(self._mutation_count()) - 1))
            condition.notify_all()

    @contextmanager
    def exclusive(self) -> Iterator[None]:
        """Acquire thread lock, then the established process-wide flock."""

        self._ensure_directories()
        lock_path = Path(self._backups_root()) / ".state_maintenance.lock"
        with self._maintenance_lock():
            with open(lock_path, "a+b", buffering=0) as lock_handle:
                file_lock = self._file_lock_module()
                if file_lock is not None:
                    file_lock.flock(lock_handle.fileno(), file_lock.LOCK_EX)
                try:
                    yield
                finally:
                    if file_lock is not None:
                        file_lock.flock(lock_handle.fileno(), file_lock.LOCK_UN)

    def begin_consistent_snapshot(self, timeout_seconds: float = 60.0) -> None:
        deadline = self._monotonic() + max(5.0, float(timeout_seconds))
        condition = self._mutation_condition()
        with condition:
            if self._snapshot_active():
                raise RuntimeError("Another state snapshot is already active")
            self._set_snapshot_active(True)
            while int(self._mutation_count()) > 0:
                remaining = deadline - self._monotonic()
                if remaining <= 0:
                    self._set_snapshot_active(False)
                    condition.notify_all()
                    raise RuntimeError("Timed out draining state mutations for backup")
                condition.wait(timeout=min(0.5, remaining))

        while True:
            with self._public_job_create_lock():
                active_creates = int(self._public_job_create_total())
            with self._active_job_processes_lock():
                active_processes = sum(
                    len(items) for items in self._active_job_processes().values()
                )
            with self._catalog_image_sync_lock():
                active_catalog_sync = len(self._catalog_image_sync_active())
            queue_busy = any(Path(self._queue_processing_root()).glob("*.json"))
            if (
                active_creates == 0
                and active_processes == 0
                and active_catalog_sync == 0
                and not queue_busy
            ):
                return
            if self._monotonic() >= deadline:
                self.end_consistent_snapshot()
                raise RuntimeError("Timed out draining active jobs for backup")
            self._sleep(0.25)

    def end_consistent_snapshot(self) -> None:
        condition = self._mutation_condition()
        with condition:
            self._set_snapshot_active(False)
            condition.notify_all()


__all__ = ("StateMaintenanceBarrier",)
