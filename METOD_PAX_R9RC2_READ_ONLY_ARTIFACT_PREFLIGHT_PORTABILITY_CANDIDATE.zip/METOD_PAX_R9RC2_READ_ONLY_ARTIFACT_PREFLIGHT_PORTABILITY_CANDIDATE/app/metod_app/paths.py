"""Immutable filesystem layout for one METOD/PAX server process."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping


@dataclass(frozen=True, slots=True)
class AppPaths:
    app_root: Path
    release_root: Path
    state_root: Path
    dxf_library_root: Path
    dxf_manifest_path: Path
    pricing_seed_path: Path
    material_library_seed_path: Path
    material_library_path: Path
    catalog_public_id_registry: Path
    catalog_taxonomy_registry: Path
    decor_media_root: Path
    public_material_catalog_cache_path: Path
    public_material_catalog_cache_meta_path: Path
    jobs: Path
    drafts: Path
    index_dir: Path
    requests_index: Path
    requests: Path
    queue_dir: Path
    queue_pending: Path
    queue_processing: Path
    queue_done: Path
    queue_failed: Path
    submission_idempotency_dir: Path
    archive_root: Path
    archive_jobs: Path
    archive_requests: Path
    archive_queue_done: Path
    archive_queue_failed: Path
    archive_transactions: Path
    system_dir: Path
    catalog_import_root: Path
    catalog_import_history: Path
    system_log_file: Path
    backups_dir: Path
    last_auto_backup_file: Path
    config_notify: Path
    ntfy_log: Path
    config_dir: Path
    pricing_active: Path
    pricing_versions: Path
    pricing_audit: Path

    @classmethod
    def from_environment(
        cls,
        *,
        app_root: str | os.PathLike[str],
        environment: Mapping[str, str] | None = None,
    ) -> "AppPaths":
        source = os.environ if environment is None else environment
        resolved_app_root = Path(app_root).expanduser().resolve()
        release_root = resolved_app_root.parent
        default_state_root = resolved_app_root.parents[1] / "metod-pax-state"
        state_root = Path(
            source.get("METOD_STATE_ROOT") or default_state_root
        ).expanduser().resolve()
        system_dir = state_root / "system"
        index_dir = state_root / "index"
        queue_dir = state_root / "queue"
        archive_root = state_root / "archive"
        catalog_import_root = system_dir / "catalog_imports"
        config_dir = state_root / "config"
        return cls(
            app_root=resolved_app_root,
            release_root=release_root,
            state_root=state_root,
            dxf_library_root=state_root / "embedded_dxfs",
            dxf_manifest_path=state_root / "embedded_dxfs_manifest.json",
            pricing_seed_path=resolved_app_root / "pricing_v13mm.json",
            material_library_seed_path=resolved_app_root / "material_library.json",
            material_library_path=state_root / "material_library.json",
            catalog_public_id_registry=system_dir / "catalog_public_ids.json",
            catalog_taxonomy_registry=system_dir / "catalog_taxonomy_registry.json",
            decor_media_root=state_root / "decor_media",
            public_material_catalog_cache_path=system_dir / "public_material_catalog_v1.json",
            public_material_catalog_cache_meta_path=system_dir / "public_material_catalog_v1.meta.json",
            jobs=state_root / "jobs",
            drafts=state_root / "drafts",
            index_dir=index_dir,
            requests_index=index_dir / "requests_index.jsonl",
            requests=state_root / "requests",
            queue_dir=queue_dir,
            queue_pending=queue_dir / "pending",
            queue_processing=queue_dir / "processing",
            queue_done=queue_dir / "done",
            queue_failed=queue_dir / "failed",
            submission_idempotency_dir=index_dir / "submission_idempotency",
            archive_root=archive_root,
            archive_jobs=archive_root / "jobs",
            archive_requests=archive_root / "requests",
            archive_queue_done=archive_root / "queue_done",
            archive_queue_failed=archive_root / "queue_failed",
            archive_transactions=archive_root / ".transactions",
            system_dir=system_dir,
            catalog_import_root=catalog_import_root,
            catalog_import_history=catalog_import_root / "history",
            system_log_file=system_dir / "system_events.jsonl",
            backups_dir=state_root / "backups",
            last_auto_backup_file=system_dir / "last_auto_backup.json",
            config_notify=state_root / "config_notify.json",
            ntfy_log=state_root / "client_logs" / "ntfy.log",
            config_dir=config_dir,
            pricing_active=config_dir / "pricing_active.json",
            pricing_versions=config_dir / "pricing_versions",
            pricing_audit=config_dir / "pricing_audit.jsonl",
        )


__all__ = ("AppPaths",)
