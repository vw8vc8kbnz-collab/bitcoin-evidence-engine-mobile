"""Side-effect-free projections for outbound order notifications.

This module deliberately owns no configuration, filesystem, network or logging
concerns.  The server composition root supplies already-loaded inputs and
decides whether customer details may be included.
"""

from __future__ import annotations

import re
from typing import Any, Iterable, Mapping


_PRICING_KEYS = (
    'materialsTotal',
    'materialsTotalInclVat',
    'materialsVatIncluded',
    'otherCostsExVat',
    'otherCostsVat',
    'edgeBandTotal',
    'cncTotal',
    'drawingTotal',
    'transportTotal',
    'subtotalExVat',
    'vatAmount',
    'totalInclVat',
)


def _localized_decimal(raw: Any) -> float | None:
    try:
        return round(float(str(raw).replace('.', '').replace(',', '.')), 2)
    except (TypeError, ValueError):
        return None


def parse_calculation_summary(text: str) -> dict[str, Any]:
    """Project notification fields from a Dutch calculation summary."""
    out: dict[str, Any] = {
        'panelsTotal': None,
        'platesTotal': None,
        'materials': [],
        'edgeMeters': [],
        'pricing': {},
    }
    summary_text = str(text or '')
    if not summary_text.strip():
        return out

    panels_match = re.search(r'Aantal panelen:\s*([0-9]+)', summary_text, re.I)
    if panels_match:
        out['panelsTotal'] = int(panels_match.group(1))
    plates_match = re.search(r'Aantal platen:\s*([0-9]+)', summary_text, re.I)
    if plates_match:
        out['platesTotal'] = int(plates_match.group(1))

    pricing_patterns = {
        'materialsTotalInclVat': r'Plaatmateriaal incl\. btw:\s*€\s*([0-9\.,]+)',
        'materialsTotal': r'Plaatmateriaal netto-equivalent:\s*€\s*([0-9\.,]+)',
        'materialsVatIncluded': r'BTW reeds in plaatprijs:\s*€\s*([0-9\.,]+)',
        'otherCostsExVat': r'Overige kosten excl\. btw:\s*€\s*([0-9\.,]+)',
        'otherCostsVat': r'BTW over overige kosten:\s*€\s*([0-9\.,]+)',
        'edgeBandTotal': r'Kantenband excl\. btw:\s*€\s*([0-9\.,]+)',
        'cncTotal': r'CNC excl\. btw:\s*€\s*([0-9\.,]+)',
        'drawingTotal': r'Tekenen excl\. btw:\s*€\s*([0-9\.,]+)',
        'transportTotal': r'Transport excl\. btw:\s*€\s*([0-9\.,]+)',
        'subtotalExVat': r'Subtotaal excl\. btw:\s*€\s*([0-9\.,]+)',
        'vatAmount': r'BTW\s*\(21%\):\s*€\s*([0-9\.,]+)',
        'totalInclVat': r'Totaal incl\. btw:\s*€\s*([0-9\.,]+)',
    }
    for key, pattern in pricing_patterns.items():
        match = re.search(pattern, summary_text, re.I)
        if match:
            out['pricing'][key] = _localized_decimal(match.group(1))

    material_match = re.search(
        r'Materialen / platen\s*-+\s*(.*?)(?:\nKantenband \(m¹\) per decor|\nKostenopbouw|\Z)',
        summary_text,
        re.I | re.S,
    )
    material_block = material_match.group(1) if material_match else ''
    current_material: dict[str, str] | None = None
    for raw_line in material_block.splitlines():
        line = raw_line.strip()
        if not line or line.startswith(('Opslagfactor', 'Plaatprijs', 'Subtotaal')):
            continue
        if line.startswith('- '):
            if current_material:
                out['materials'].append(current_material)
            current_material = {'label': line[2:].strip(), 'detail': ''}
        elif current_material and any(marker in line for marker in ('Platen:', 'Dikte:', 'Plaatmaat:')):
            current_material['detail'] = line
    if current_material:
        out['materials'].append(current_material)

    edge_match = re.search(
        r'Kantenband \(m¹\) per decor\s*-+\s*(.*?)(?:\nKostenopbouw|\Z)',
        summary_text,
        re.I | re.S,
    )
    edge_block = edge_match.group(1) if edge_match else ''
    for raw_line in edge_block.splitlines():
        line = raw_line.strip()
        if not line.startswith('- '):
            continue
        edge_line_match = re.search(r'^-\s*(.+?):\s*([0-9\.,]+)\s*m', line, re.I)
        if edge_line_match:
            out['edgeMeters'].append(
                {
                    'label': edge_line_match.group(1).strip(),
                    'meters': _localized_decimal(edge_line_match.group(2)),
                }
            )
    return out


def merge_notification_pricing(
    summary: Mapping[str, Any] | None,
    calculation_info: Mapping[str, Any] | None,
    authoritative_pricing: Mapping[str, Any] | None,
) -> dict[str, Any]:
    """Merge pricing with calculation output taking highest precedence."""
    pricing: dict[str, Any] = {}
    if isinstance(summary, Mapping):
        try:
            if summary.get('materialsPrice') is not None:
                pricing['materialsTotal'] = float(summary.get('materialsPrice'))
            if summary.get('priceInclVat') is not None:
                pricing['totalInclVat'] = float(summary.get('priceInclVat'))
        except (TypeError, ValueError):
            pass

    if isinstance(authoritative_pricing, Mapping):
        for key in _PRICING_KEYS:
            if authoritative_pricing.get(key) is not None:
                pricing[key] = authoritative_pricing.get(key)

    calculation_pricing = (
        calculation_info.get('pricing')
        if isinstance(calculation_info, Mapping)
        else None
    )
    if isinstance(calculation_pricing, Mapping):
        for key, value in calculation_pricing.items():
            if value is not None:
                pricing[key] = value
    return pricing


def privacy_safe_customer_lines(
    customer_lines: Iterable[Any],
    *,
    include_customer_details: bool,
) -> list[str]:
    """Return the explicitly allowed subset of a projected customer block."""
    if not include_customer_details:
        return []

    compact: list[str] = []
    section: str | bool = False
    for raw_line in customer_lines:
        line = str(raw_line or '').strip()
        if line in ('Klant', 'Adres', 'Restmateriaal', 'Opmerking klant'):
            section = line
            continue
        if (
            not line
            or set(line) == {'-'}
            or line.startswith(('Aanvraag', 'Request ID', 'Datum'))
        ):
            continue
        if section == 'Klant' and line.startswith(('Naam:', 'Email:', 'Telefoon:')):
            compact.append(line)
        elif section == 'Adres' and line.startswith(('Factuur:', 'Bezorg:', 'Plaats:', 'Land:')):
            compact.append(line)
        elif section == 'Restmateriaal' and line.startswith('Meeleveren:'):
            compact.append('Restmateriaal ' + line)
        elif section == 'Opmerking klant':
            compact.append('Opmerking: ' + line[:220])
    return compact[:10]


__all__ = [
    'merge_notification_pricing',
    'parse_calculation_summary',
    'privacy_safe_customer_lines',
]
