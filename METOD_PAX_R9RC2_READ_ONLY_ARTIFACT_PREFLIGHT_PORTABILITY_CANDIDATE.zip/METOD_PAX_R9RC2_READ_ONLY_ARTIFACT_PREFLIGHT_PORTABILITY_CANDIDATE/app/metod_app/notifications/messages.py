"""Side-effect-free message construction for outbound notifications."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Sequence


@dataclass(frozen=True, slots=True)
class NotificationMessage:
    """Transport-neutral notification value object."""

    title: str
    message: str
    tags: tuple[str, ...]


def _format_money_eur(value: Any) -> str:
    try:
        numeric = float(value)
        if not (numeric == numeric):
            return ''
        formatted = f'{numeric:,.2f}'.replace(',', 'X').replace('.', ',').replace('X', '.')
        return f'€{formatted}'
    except (TypeError, ValueError, OverflowError):
        return ''


def _format_meters(value: Any) -> str:
    try:
        numeric = float(value or 0.0)
    except (TypeError, ValueError, OverflowError):
        numeric = 0.0
    formatted = f'{numeric:,.2f}'.replace(',', 'X').replace('.', ',').replace('X', '.')
    return f'{formatted} m'


def build_submitted_notification(
    request_id: str,
    summary: Mapping[str, Any],
    calculation_info: Mapping[str, Any],
    pricing: Mapping[str, Any],
    customer_lines: Sequence[str] = (),
    *,
    minimal_order_notice: bool = True,
    include_price_breakdown: bool = False,
    calculation_summary_present: bool = False,
    calculation_job_id: str = '',
) -> NotificationMessage:
    """Build the minimal or explicitly enabled verbose order notification."""
    if minimal_order_notice:
        parts = ['Nieuwe order ontvangen']
        total = pricing.get('totalInclVat')
        if total is not None:
            parts.append('Totaal: ' + _format_money_eur(total))
        parts.append('Request: ' + str(request_id))
        parts.append('Open admin voor details.')
        return NotificationMessage(
            title='AD Zaagt Configurator',
            message='\n'.join(parts),
            tags=('new',),
        )

    parts = ['Nieuwe configuratie']
    if customer_lines:
        parts.extend(('', '👤 Klant/order'))
        parts.extend(customer_lines[:10])

    configuration_lines: list[str] = []
    panel_count = calculation_info.get('panelsTotal')
    if panel_count is None:
        panel_count = summary.get('panelsTotal')
    if panel_count is not None:
        configuration_lines.append(f'Panelen: {panel_count}')

    plate_count = calculation_info.get('platesTotal')
    if plate_count is None:
        plate_count = summary.get('platesTotal')
    if plate_count is not None:
        configuration_lines.append(f'Platen: {plate_count}')

    calculation_materials = calculation_info.get('materials') or []
    if calculation_materials:
        for material in calculation_materials[:6]:
            label = str((material or {}).get('label') or '').strip()
            detail = str((material or {}).get('detail') or '').strip()
            if label:
                configuration_lines.append('• ' + label)
                if detail:
                    configuration_lines.append('  ' + detail)
    else:
        for material in (summary.get('materials') or [])[:6]:
            name = str(material.get('name') or '').strip()
            code = str(material.get('code') or '').strip()
            if name and code and code.lower() not in name.lower():
                label = f'{name} ({code})'
            else:
                label = name or code
            if not label:
                continue
            if material.get('plates') is not None:
                configuration_lines.append(f"• {label} - {material['plates']} plaat/platen")
            else:
                configuration_lines.append(f'• {label}')
    if configuration_lines:
        parts.extend(('', 'Configuratie'))
        parts.extend(configuration_lines[:18])

    edge_lines: list[str] = []
    for edge in (calculation_info.get('edgeMeters') or [])[:6]:
        label = str((edge or {}).get('label') or '').strip()
        meters = (edge or {}).get('meters')
        if label and meters is not None:
            edge_lines.append(f'• {label}: {_format_meters(meters)}')
    if edge_lines:
        parts.extend(('', 'Kantenband'))
        parts.extend(edge_lines)

    price_lines: list[str] = []
    price_labels = (
        ('materialsTotalInclVat', 'Plaatmateriaal incl. btw'),
        ('edgeBandTotal', 'Kantenband excl. btw'),
        ('cncTotal', 'CNC'),
        ('drawingTotal', 'Tekenen'),
        ('transportTotal', 'Transport'),
        ('subtotalExVat', 'Subtotaal excl. btw'),
        ('vatAmount', 'BTW'),
        ('totalInclVat', 'Totaal incl. btw'),
    )
    for key, label in price_labels:
        if pricing.get(key) is not None:
            price_lines.append(f'{label}: {_format_money_eur(pricing.get(key))}')
    if price_lines and include_price_breakdown:
        heading = 'Berekening' + (
            ' (exact uit calculation_summary)' if calculation_summary_present else ''
        )
        parts.extend(('', heading))
        parts.extend(price_lines)
    elif pricing.get('totalInclVat') is not None:
        parts.extend(('', 'Totaal incl. btw: ' + _format_money_eur(pricing.get('totalInclVat'))))

    parts.extend(('', 'Request', str(request_id)))
    if calculation_job_id:
        parts.append(f'Job: {calculation_job_id}')

    return NotificationMessage(
        title='AD Zaagt Configurator',
        message='\n'.join(parts),
        tags=('new',),
    )


def build_failed_notification(request_id: str, error: str) -> NotificationMessage:
    """Build a bounded optimizer failure notification without an admin link."""
    error_lines = str(error or '').strip().splitlines()
    first_line = error_lines[0][:180] if error_lines else ''
    return NotificationMessage(
        title='AD Zaagt Configurator',
        message='\n'.join(
            (
                '🔴 Optimizer fout',
                f'Request: {request_id}',
                first_line or 'Onbekende fout',
                'Check Admin',
            )
        ),
        tags=('warning',),
    )


__all__ = [
    'NotificationMessage',
    'build_failed_notification',
    'build_submitted_notification',
]
