"""Request persistence boundaries for METOD/PAX."""

