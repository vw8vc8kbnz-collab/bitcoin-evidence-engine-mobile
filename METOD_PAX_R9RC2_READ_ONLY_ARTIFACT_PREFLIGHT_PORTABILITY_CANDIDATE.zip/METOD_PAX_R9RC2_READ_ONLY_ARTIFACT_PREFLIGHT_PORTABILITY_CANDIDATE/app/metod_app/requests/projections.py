from __future__ import annotations

"""Pure request projections shared by submit, notifications and Admin output.

This module owns no files, locks, HTTP responses, routes or mutable global state.
Material-name resolution is injected so the existing catalog-backed behavior stays
at the composition root.
"""

import re
from typing import Any, Callable


MaterialNameResolver = Callable[..., str]


def _first_nonempty(*values: Any) -> str:
    for value in values:
        if value is None:
            continue
        text = str(value).strip()
        if text:
            return text
    return ""


def customer_block_from_status(request_status: dict | None) -> list[str]:
    lines: list[str] = []
    if not isinstance(request_status, dict):
        return lines
    request_id = request_status.get("requestId") or ""
    created = request_status.get("createdAt") or request_status.get("updatedAt") or ""
    customer = (
        request_status.get("customer")
        if isinstance(request_status.get("customer"), dict)
        else {}
    )
    name = _first_nonempty(
        customer.get("name"),
        customer.get("fullName"),
        ("%s %s" % (customer.get("firstName") or "", customer.get("lastName") or "")).strip(),
    )
    email = _first_nonempty(customer.get("email"))
    phone = _first_nonempty(customer.get("phone"), customer.get("telephone"), customer.get("tel"))
    billing = _first_nonempty(
        customer.get("billingAddress"), customer.get("factuurAdres"),
        customer.get("address"), customer.get("addressLine1"), customer.get("street"),
    )
    shipping = _first_nonempty(
        customer.get("shippingAddress"), customer.get("bezorgAdres"), customer.get("deliveryAddress")
    )
    house = _first_nonempty(customer.get("houseNumber"))
    if billing and house and not re.search(rf"(^|\s){re.escape(house)}($|\s)", billing):
        billing = f"{billing} {house}".strip()
    if shipping and house and not re.search(rf"(^|\s){re.escape(house)}($|\s)", shipping):
        shipping = f"{shipping} {house}".strip()
    city = _first_nonempty(customer.get("city"), customer.get("plaats"))
    postal = _first_nonempty(customer.get("postalCode"), customer.get("postcode"))
    try:
        if city and not postal and re.fullmatch(r"[0-9]{4}\s?[A-Za-z]{2}", str(city).strip()):
            postal, city = str(city).strip(), ""
    except Exception:
        pass
    country = _first_nonempty(customer.get("country"))

    if request_id or created:
        lines.extend(["Aanvraag", "-" * 40])
        if request_id:
            lines.append(f"Request ID: {request_id}")
        if created:
            lines.append(f"Datum: {created}")
        lines.append("")
    if name or email or phone:
        lines.extend(["Klant", "-" * 40])
        if name:
            lines.append(f"Naam: {name}")
        if email:
            lines.append(f"Email: {email}")
        if phone:
            lines.append(f"Telefoon: {phone}")
        lines.append("")
    if billing or shipping or city or postal or country:
        lines.extend(["Adres", "-" * 40])
        if billing:
            lines.append(f"Factuur: {billing}")
        if shipping and shipping != billing:
            lines.append(f"Bezorg: {shipping}")
        city_line = " ".join([item for item in [postal, city] if item]).strip()
        if city_line:
            lines.append(f"Plaats: {city_line}")
        if country:
            lines.append(f"Land: {country}")
        lines.append("")
    return lines


def customer_block_from_sources(
    request_status: dict | None,
    payload: dict | None = None,
) -> list[str]:
    lines: list[str] = []
    request_id = ""
    created = ""
    customer: dict[str, Any] = {}
    note = ""
    rest_carry = None
    if isinstance(request_status, dict):
        request_id = request_status.get("requestId") or ""
        created = request_status.get("createdAt") or request_status.get("updatedAt") or ""
        stored = request_status.get("customer") if isinstance(request_status.get("customer"), dict) else {}
        if isinstance(stored, dict):
            customer.update(stored)
    if isinstance(payload, dict):
        payload_customer = payload.get("customer") if isinstance(payload.get("customer"), dict) else {}
        checkout = payload.get("checkout") if isinstance(payload.get("checkout"), dict) else {}
        checkout_customer = checkout.get("customer") if isinstance(checkout.get("customer"), dict) else {}
        try:
            if isinstance(checkout, dict):
                if "restCarry" in checkout:
                    rest_carry = bool(checkout.get("restCarry"))
                elif (
                    isinstance(checkout.get("rest_material"), dict)
                    and "carry_out" in (checkout.get("rest_material") or {})
                ):
                    rest_carry = bool((checkout.get("rest_material") or {}).get("carry_out"))
            if rest_carry is None and "restCarry" in payload:
                rest_carry = bool(payload.get("restCarry"))
        except Exception:
            rest_carry = None
        merged: dict[str, Any] = {}
        for source in (customer, checkout_customer, payload_customer):
            if isinstance(source, dict):
                for key, value in source.items():
                    if value not in (None, ""):
                        merged[key] = value
        customer = merged
        note = _first_nonempty(
            checkout.get("note") if isinstance(checkout, dict) else "",
            payload.get("note"),
            payload_customer.get("note") if isinstance(payload_customer, dict) else "",
            checkout_customer.get("note") if isinstance(checkout_customer, dict) else "",
            payload_customer.get("comment") if isinstance(payload_customer, dict) else "",
            checkout_customer.get("comment") if isinstance(checkout_customer, dict) else "",
        )
    name = _first_nonempty(
        customer.get("name"),
        customer.get("fullName"),
        ("%s %s" % (customer.get("firstName") or "", customer.get("lastName") or "")).strip(),
    )
    email = _first_nonempty(customer.get("email"), customer.get("mail"))
    phone = _first_nonempty(customer.get("phone"), customer.get("telephone"), customer.get("tel"))
    billing = _first_nonempty(
        customer.get("billingAddress"), customer.get("invoiceAddress"), customer.get("factuurAdres"),
        customer.get("address"), customer.get("addressLine1"),
        " ".join([item for item in [customer.get("street"), customer.get("houseNumber")] if item]).strip(),
        customer.get("street"),
    )
    shipping = _first_nonempty(
        customer.get("shippingAddress"), customer.get("bezorgAdres"), customer.get("deliveryAddress"),
        customer.get("address1"),
        " ".join([
            item for item in [customer.get("deliveryStreet"), customer.get("deliveryHouseNumber")] if item
        ]).strip(),
    )
    house = _first_nonempty(customer.get("houseNumber"))
    if billing and house and not re.search(rf"(^|\s){re.escape(house)}($|\s)", billing):
        billing = f"{billing} {house}".strip()
    if shipping and house and not re.search(rf"(^|\s){re.escape(house)}($|\s)", shipping):
        shipping = f"{shipping} {house}".strip()
    city = _first_nonempty(customer.get("city"), customer.get("plaats"))
    postal = _first_nonempty(customer.get("postalCode"), customer.get("postcode"))
    try:
        if city and not postal and re.fullmatch(r"[0-9]{4}\s?[A-Za-z]{2}", str(city).strip()):
            postal, city = str(city).strip(), ""
    except Exception:
        pass
    country = _first_nonempty(customer.get("country"))
    if request_id or created:
        lines.extend(["Aanvraag", "-" * 40])
        if request_id:
            lines.append(f"Request ID: {request_id}")
        if created:
            lines.append(f"Datum: {created}")
        lines.append("")
    if name or email or phone:
        lines.extend(["Klant", "-" * 40])
        if name:
            lines.append(f"Naam: {name}")
        if email:
            lines.append(f"Email: {email}")
        if phone:
            lines.append(f"Telefoon: {phone}")
        lines.append("")
    if billing or shipping or city or postal or country:
        lines.extend(["Adres", "-" * 40])
        if billing:
            lines.append(f"Factuur: {billing}")
        if shipping and shipping != billing:
            lines.append(f"Bezorg: {shipping}")
        city_line = " ".join([item for item in [postal, city] if item]).strip()
        if city_line:
            lines.append(f"Plaats: {city_line}")
        if country:
            lines.append(f"Land: {country}")
        lines.append("")
    if rest_carry is not None:
        lines.extend(["Restmateriaal", "-" * 40])
        lines.append(f"Meeleveren: {'JA' if rest_carry else 'NEE'}")
        lines.append("")
    if note:
        lines.extend(["Opmerking klant", "-" * 40, str(note).strip(), ""])
    return lines


class RequestProjection:
    """Project request payloads without owning their catalog/name source."""

    def __init__(self, *, best_material_name: MaterialNameResolver) -> None:
        self._best_material_name = best_material_name

    def extract_summary(self, payload: dict) -> dict:
        """Return the established best-effort customer/order summary."""

        out = {
            "customerName": "",
            "customerEmail": "",
            "customerPhone": "",
            "customerAddress": "",
            "panelsTotal": None,
            "platesTotal": None,
            "materials": [],
            "priceInclVat": None,
            "materialsPrice": None,
        }
        try:
            customer = payload.get("customer") if isinstance(payload.get("customer"), dict) else {}
            if isinstance(customer, dict):
                first = str(customer.get("firstName") or "").strip()
                last = str(customer.get("lastName") or "").strip()
                full = " ".join([item for item in [first, last] if item]).strip()
                out["customerName"] = str(customer.get("name") or customer.get("fullName") or full or "").strip()
                out["customerEmail"] = str(customer.get("email") or customer.get("mail") or "").strip()
                out["customerPhone"] = str(customer.get("phone") or customer.get("tel") or customer.get("telephone") or "").strip()
                postcode = str(customer.get("postcode") or "").strip()
                house = str(customer.get("houseNumber") or "").strip()
                city = str(customer.get("city") or "").strip()
                address_line = " ".join([item for item in [postcode, house] if item]).strip()
                billing = str(customer.get("billingAddress") or customer.get("invoiceAddress") or customer.get("address") or "").strip()
                shipping = str(customer.get("shippingAddress") or customer.get("deliveryAddress") or customer.get("address1") or billing or "").strip()
                address_parts = []
                if billing:
                    address_parts.append(("Factuur: " + " ".join([item for item in [billing, address_line] if item]).strip()).strip())
                if shipping and shipping != billing:
                    address_parts.append(("Bezorg: " + " ".join([item for item in [shipping, address_line] if item]).strip()).strip())
                if city:
                    address_parts.append(city)
                out["customerAddress"] = " | ".join([item for item in address_parts if item]).strip()
        except Exception:
            pass

        for key in ["priceInclVat", "totalPriceInclVat", "totalInclVat"]:
            try:
                if payload.get(key) is not None:
                    out["priceInclVat"] = float(payload.get(key))
                    break
            except Exception:
                pass

        quote = payload.get("quote") if isinstance(payload.get("quote"), dict) else None
        if out["priceInclVat"] is None and isinstance(quote, dict):
            for key in ["grandTotalInclVat", "totalInclVat", "inclVatTotal", "totalPriceInclVat"]:
                if quote.get(key) is not None:
                    try:
                        out["priceInclVat"] = float(quote.get(key))
                        break
                    except Exception:
                        pass
            if out["priceInclVat"] is None:
                try:
                    totals = quote.get("totals") if isinstance(quote.get("totals"), dict) else {}
                    for key in ["grandTotalInclVat", "totalInclVat", "inclVatTotal", "totalPriceInclVat"]:
                        if totals.get(key) is not None:
                            out["priceInclVat"] = float(totals.get(key))
                            break
                except Exception:
                    pass
            if out["priceInclVat"] is None:
                try:
                    totals = quote.get("totals") if isinstance(quote.get("totals"), dict) else {}
                    base = None
                    for key in ["grandTotal", "total", "subtotal"]:
                        if totals.get(key) is not None:
                            base = float(totals.get(key))
                            break
                    if base is None:
                        for key in ["grandTotal", "total", "subtotal"]:
                            if quote.get(key) is not None:
                                base = float(quote.get(key))
                                break
                    if base is not None:
                        out["priceInclVat"] = round(base * 1.21, 2)
                except Exception:
                    pass

        materials = payload.get("materialsSummary")
        if isinstance(materials, list):
            for material in materials:
                if not isinstance(material, dict):
                    continue
                code = str(material.get("code") or material.get("articleNumber") or material.get("materialCode") or "").strip()
                name = self._best_material_name(
                    code, material.get("materialDisplayName"), material.get("materialName"),
                    material.get("name"), material.get("productName"), material.get("decorName"),
                )
                plates = material.get("plates")
                try:
                    plates = int(plates) if plates is not None else None
                except Exception:
                    plates = None
                if code or name:
                    out["materials"].append({"code": code, "name": name, "plates": plates})
        else:
            codes: dict[str, dict[str, Any]] = {}

            def add_material(code: str, name: str = "") -> None:
                if not code and not name:
                    return
                key = code or name
                if key not in codes:
                    codes[key] = {"code": code, "name": name, "plates": None}

            for array_key in ["cart", "extraPanels", "panels"]:
                items = payload.get(array_key)
                if not isinstance(items, list):
                    continue
                for panel in items:
                    if not isinstance(panel, dict):
                        continue
                    code = str(panel.get("articleNumber") or panel.get("materialKey") or panel.get("materialCode") or "").strip()
                    name = self._best_material_name(
                        code, panel.get("materialDisplayName"), panel.get("productName"),
                        panel.get("decorName"), panel.get("name"),
                    )
                    add_material(code, name)
            out["materials"] = list(codes.values())

        try:
            if payload.get("platesTotal") is not None:
                out["platesTotal"] = int(payload.get("platesTotal"))
        except Exception:
            pass
        if out["platesTotal"] is None and isinstance(quote, dict):
            candidates: list[int] = []

            def walk(value: Any) -> None:
                if isinstance(value, dict):
                    for key, child in value.items():
                        if str(key).lower() in (
                            "plates", "platencount", "sheetcount", "sheetsused", "boardsused", "boardscount",
                        ) and isinstance(child, (int, float)) and child >= 0:
                            candidates.append(int(child))
                        walk(child)
                elif isinstance(value, list):
                    for child in value:
                        walk(child)

            walk(quote)
            if candidates:
                out["platesTotal"] = max(candidates)
        if isinstance(quote, dict):
            quote_materials = []
            try:
                raw_materials = quote.get("materials") if isinstance(quote.get("materials"), list) else None
                if raw_materials:
                    for material in raw_materials:
                        if not isinstance(material, dict):
                            continue
                        code = str(material.get("materialCode") or material.get("code") or material.get("articleNumber") or "").strip()
                        name = self._best_material_name(
                            code, material.get("materialDisplayName"), material.get("materialName"),
                            material.get("name"), material.get("productName"), material.get("decorName"),
                        )
                        plates = None
                        for key in ["plates", "sheets", "sheetsUsed", "boards", "boardsUsed", "sheetCount"]:
                            if material.get(key) is not None:
                                try:
                                    plates = int(material.get(key))
                                    break
                                except Exception:
                                    pass
                        quote_materials.append({"code": code, "name": name, "plates": plates})
            except Exception:
                pass
            if quote_materials:
                existing = {(item.get("code") or item.get("name")): item for item in out["materials"]}
                for material in quote_materials:
                    key = material.get("code") or material.get("name")
                    if not key:
                        continue
                    if key in existing and material.get("plates") is not None:
                        existing[key]["plates"] = material.get("plates")
                    elif key not in existing:
                        out["materials"].append(material)

        for key in ["materialsPrice", "materialsTotal", "materialTotal", "materialsAmount"]:
            try:
                if payload.get(key) is not None:
                    out["materialsPrice"] = float(payload.get(key))
                    break
            except Exception:
                pass
        if out["materialsPrice"] is None and isinstance(quote, dict):
            try:
                materials_total = None
                for key in ["materialsTotal", "materialTotal", "subtotalMaterials", "materialsSubtotal"]:
                    if quote.get(key) is not None:
                        materials_total = quote.get(key)
                        break
                if materials_total is None:
                    totals = quote.get("totals") if isinstance(quote.get("totals"), dict) else {}
                    for key in ["materialsTotal", "materialTotal", "subtotalMaterials", "materialsSubtotal"]:
                        if totals.get(key) is not None:
                            materials_total = totals.get(key)
                            break
                if materials_total is None and isinstance(quote.get("materials"), list):
                    values = []
                    for material in quote.get("materials") or []:
                        if not isinstance(material, dict):
                            continue
                        for key in ["priceInclVat", "totalInclVat", "grandTotal", "total", "subtotal", "price"]:
                            if material.get(key) is not None:
                                try:
                                    values.append(float(material.get(key)))
                                    break
                                except Exception:
                                    pass
                    if values:
                        materials_total = sum(values)
                if materials_total is not None:
                    out["materialsPrice"] = float(materials_total)
            except Exception:
                pass

        try:
            panels_total = 0
            found_any = False
            for array_key in ["cart", "extraPanels", "panels"]:
                items = payload.get(array_key)
                if not isinstance(items, list):
                    continue
                for panel in items:
                    if not isinstance(panel, dict):
                        continue
                    found_any = True
                    quantity = None
                    for key in ["qty", "quantity", "count", "aantal"]:
                        if panel.get(key) is not None:
                            try:
                                quantity = int(float(panel.get(key)))
                                break
                            except Exception:
                                pass
                    panels_total += quantity if (quantity is not None and quantity > 0) else 1
            if found_any and panels_total > 0:
                out["panelsTotal"] = panels_total
        except Exception:
            pass
        return out


__all__ = (
    "RequestProjection",
    "customer_block_from_sources",
    "customer_block_from_status",
)
