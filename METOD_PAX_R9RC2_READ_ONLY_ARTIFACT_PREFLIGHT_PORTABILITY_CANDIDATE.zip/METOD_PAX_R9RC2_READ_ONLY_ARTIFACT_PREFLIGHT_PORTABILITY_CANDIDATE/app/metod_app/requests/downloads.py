from __future__ import annotations

"""Read-only request and download projections with injected runtime ownership.

The service owns mailbox ordering, request-linked file manifests and sealed ZIP
selection. It deliberately owns no HTTP parsing/response writing, ZIP creation,
authentication, locks or mutable state. All filesystem and naming behavior is
provided by the server composition root so historical contracts remain patchable.
"""

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Callable
from urllib.parse import quote


Provider = Callable[[], Any]


@dataclass(frozen=True)
class RequestDownloadDependencies:
    requests_root: Provider
    jobs_root: Provider
    ensure_request_directories: Callable[[], None]
    load_status: Callable[[str], dict | None]
    strict_json_load: Callable[[Any], Any]
    safe_identifier: Callable[[str, int], str]
    validate_job_id: Callable[[str], str]
    resolve_job_root: Callable[[str], Any]
    collect_job_output_files: Callable[[str], list[dict]]
    find_stickertool_file: Callable[[str], Any | None]
    sealed_output_artifacts: Callable[[Any], dict[str, Any]]
    job_material_context: Callable[[Any], dict]
    best_material_name: Callable[..., str]
    classify_output_kind: Callable[[str], str]
    dedupe_admin_dxf_files: Callable[[list[dict]], list[dict]]
    admin_sheet_download_name: Callable[..., str]
    strict_pricing_summary: Callable[[list[str]], dict]
    finalization_complete: Callable[[Any], bool]
    directory_size_bytes: Callable[[Any], int]
    sanitize_filename: Callable[[str, int], str]
    relative_parts: Callable[[str], tuple[str, ...]]
    relative_basename: Callable[[str], str]
    build_manifest: Callable[[str], dict]


@dataclass(frozen=True)
class RequestExportPlan:
    ok: bool
    status: int
    message: str
    request_id: str
    scope: str
    selected: tuple[tuple[Any, str], ...]
    download_name: str

    @classmethod
    def failure(cls, status: int, message: str, request_id: str, scope: str) -> "RequestExportPlan":
        return cls(False, status, message, request_id, scope, (), "")


class RequestDownloadProjectionService:
    """Single read-only owner for Admin request/download projections."""

    def __init__(self, dependencies: RequestDownloadDependencies) -> None:
        self._d = dependencies

    def find_finalized_stickertool_file(self, job_id: str):
        """Return the already-sealed material-subjob sticker artifact, if valid."""

        try:
            job_id = self._d.validate_job_id(job_id)
            if "__mat_" not in job_id:
                return None
            job_root = self._d.resolve_job_root(job_id)
            file_path = self._d.sealed_output_artifacts(job_root).get("output/stickertool.json")
            if file_path is not None:
                data = self._d.strict_json_load(file_path)
                if (
                    str(data.get("materialCode") or "").strip()
                    and isinstance(data.get("items"), list)
                    and len(data.get("items") or []) > 0
                ):
                    return file_path
        except Exception:
            pass
        return None

    def list_requests(self, limit: int) -> list[dict]:
        """Return bounded request mailbox rows, newest first, without mutation."""

        self._d.ensure_request_directories()
        limit = max(1, min(2000, int(limit)))
        rows: list[dict] = []
        for request_root in sorted(self._d.requests_root().glob("*")):
            if not request_root.is_dir():
                continue
            status_path = request_root / "status.json"
            if not status_path.exists():
                continue
            try:
                status = self._d.strict_json_load(status_path)
            except Exception:
                continue
            status["requestId"] = request_root.name
            rows.append(status)
        rows.sort(
            key=lambda item: str(item.get("createdAt") or item.get("updatedAt") or ""),
            reverse=True,
        )
        return rows[:limit]

    def build_manifest(self, request_id: str) -> dict:
        """Project one request onto its sealed job artifacts without side effects."""

        status = self._d.load_status(request_id) or {}
        job = status.get("job") if isinstance(status.get("job"), dict) else {}
        parent = self._d.safe_identifier(str(job.get("parentJobId") or "").strip(), 200)
        subjobs: list[str] = []
        for subjob in job.get("subjobs") or []:
            if isinstance(subjob, dict):
                subjob_id = str(
                    subjob.get("subjobId") or subjob.get("jobId") or subjob.get("id") or ""
                ).strip()
            else:
                subjob_id = str(subjob or "").strip()
            subjob_id = self._d.safe_identifier(subjob_id, 200) if subjob_id else ""
            if subjob_id and subjob_id not in subjobs:
                subjobs.append(subjob_id)

        if parent and not subjobs:
            try:
                links_path = self._d.jobs_root() / parent / "output" / "links.json"
                if links_path.exists():
                    links = self._d.strict_json_load(links_path)
                    for subjob in links.get("subjobs") or []:
                        subjob_id = str(
                            (subjob or {}).get("subjobId") if isinstance(subjob, dict) else subjob or ""
                        ).strip()
                        subjob_id = self._d.safe_identifier(subjob_id, 200) if subjob_id else ""
                        if subjob_id and subjob_id not in subjobs:
                            subjobs.append(subjob_id)
            except Exception:
                pass
            if not subjobs:
                try:
                    for subjob_root in sorted(self._d.jobs_root().glob(f"{parent}__mat_*")):
                        if subjob_root.is_dir():
                            subjob_id = self._d.safe_identifier(subjob_root.name, 200)
                            if subjob_id and subjob_id not in subjobs:
                                subjobs.append(subjob_id)
                except Exception:
                    pass

        job_ids: list[str] = []
        for job_id in ([parent] if parent else []) + subjobs:
            if job_id and job_id not in job_ids:
                job_ids.append(job_id)

        groups: list[dict] = []
        summary_files: list[dict] = []
        all_files: list[dict] = []
        seen_summary: set[tuple[str, str]] = set()
        for job_id in job_ids:
            files = self._d.collect_job_output_files(job_id)
            sticker_path = self._d.find_stickertool_file(job_id)
            if sticker_path is not None:
                relative = sticker_path.relative_to(self._d.jobs_root() / job_id).as_posix()
                if not any(str(item.get("rel") or "") == relative for item in files):
                    context = self._d.job_material_context(self._d.jobs_root() / job_id)
                    code = str(context.get("materialCode") or "").strip()
                    stat_result = sticker_path.stat() if sticker_path.exists() else None
                    files.append({
                        "jobId": job_id,
                        "materialCode": code,
                        "materialName": str(
                            context.get("materialName")
                            or (self._d.best_material_name(code, "") if code else "")
                        ).strip(),
                        "name": sticker_path.name,
                        "rel": relative,
                        "kind": self._d.classify_output_kind(sticker_path.name),
                        "size": stat_result.st_size if stat_result is not None else 0,
                        "mtime": (
                            datetime.fromtimestamp(stat_result.st_mtime, tz=timezone.utc)
                            .isoformat().replace("+00:00", "Z")
                            if stat_result is not None else ""
                        ),
                    })
            if not files:
                continue
            all_files.extend(files)
            context = self._d.job_material_context(self._d.jobs_root() / job_id)
            code = str(context.get("materialCode") or "").strip()
            material_name = str(
                context.get("materialName")
                or (self._d.best_material_name(code, "") if code else "")
            ).strip()
            label = material_name or code or job_id
            sheet_dxf_files = self._d.dedupe_admin_dxf_files([
                item for item in files
                if str(item.get("kind") or "") == "dxf"
                and str(item.get("rel") or "").startswith("output/DXF_Zaagplaten/")
            ])
            if sheet_dxf_files:
                groups.append({
                    "jobId": job_id,
                    "materialCode": code,
                    "materialName": material_name,
                    "label": label,
                    "files": sheet_dxf_files,
                })
            for item in files:
                kind = str(item.get("kind") or "")
                if kind in ("quote", "report", "placements", "stickers", "stickertool", "summary", "pricing"):
                    if kind in ("stickers", "stickertool") and "__mat_" not in str(job_id or ""):
                        continue
                    key = (kind, job_id)
                    if key not in seen_summary:
                        seen_summary.add(key)
                        summary_files.append(item)

        request_customer = status.get("customer") if isinstance(status, dict) else None
        for item in all_files:
            relative = str(item.get("rel") or "")
            if (
                str(item.get("kind") or "") == "dxf"
                and (
                    relative.startswith("output/DXF_Zaagplaten/")
                    or relative.startswith("output/sheets/")
                )
            ):
                try:
                    item["downloadName"] = self._d.admin_sheet_download_name(
                        self._d.jobs_root() / str(item.get("jobId") or ""),
                        str(item.get("name") or self._d.relative_basename(relative)),
                        customer=request_customer,
                    )
                except Exception:
                    item["downloadName"] = str(
                        item.get("name") or self._d.relative_basename(relative)
                    )
            job_id_quoted = quote(str(item.get("jobId") or ""), safe="")
            relative_quoted = quote(relative, safe="/")
            item["url"] = (
                f"/api/admin/request_file?requestId={quote(request_id)}"
                f"&jobId={job_id_quoted}&rel={relative_quoted}"
            )

        pricing_summary = (
            self._d.strict_pricing_summary(job_ids)
            if job_ids and all(
                self._d.finalization_complete(self._d.resolve_job_root(job_id))
                for job_id in job_ids
            )
            else {}
        )

        request_bytes = self._d.directory_size_bytes(self._d.requests_root() / request_id)
        jobs_bytes = 0
        for job_id in job_ids:
            try:
                jobs_bytes += self._d.directory_size_bytes(self._d.jobs_root() / job_id)
            except Exception:
                pass
        total_bytes = int(request_bytes + jobs_bytes)
        return {
            "requestId": request_id,
            "parentJobId": parent,
            "subjobs": subjobs,
            "summaryFiles": summary_files,
            "dxfGroups": groups,
            "allFiles": all_files,
            "pricingSummary": pricing_summary,
            "storageSummary": {
                "requestBytes": int(request_bytes),
                "jobsBytes": int(jobs_bytes),
                "totalBytes": total_bytes,
                "jobCount": len(job_ids),
                "subjobCount": len(subjobs),
            },
            "zip": {
                "allOutputsUrl": (
                    f"/api/admin/request_download_zip?requestId={quote(request_id)}&scope=all"
                ),
                "allDxfUrl": (
                    f"/api/admin/request_download_zip?requestId={quote(request_id)}&scope=dxf"
                ),
            },
        }

    def resolve_linked_file(self, request_id: str, job_id: str, relative: str) -> dict | None:
        manifest = self._d.build_manifest(request_id)
        for item in manifest.get("allFiles") or []:
            if (
                str(item.get("jobId") or "") == job_id
                and str(item.get("rel") or "") == relative
            ):
                return item
        return None

    def build_export_plan(self, request_id: str, scope: str, export_limit: int) -> RequestExportPlan:
        manifest = self._d.build_manifest(request_id)
        files = manifest.get("allFiles") or []
        if scope == "dxf":
            files = [item for item in files if item.get("kind") == "dxf"]
        if not files:
            return RequestExportPlan.failure(404, "No files for this request", request_id, scope)

        selected: list[tuple[Any, str]] = []
        sealed_by_job: dict[str, dict[str, Any]] = {}
        total_input = 0
        for item in files[:10_000]:
            try:
                job_id = self._d.validate_job_id(str(item.get("jobId") or ""))
                job_root = self._d.resolve_job_root(job_id)
                if not self._d.finalization_complete(job_root):
                    raise ValueError("job is not finalized")
                relative = str(item.get("rel") or "")
                if job_id not in sealed_by_job:
                    sealed_by_job[job_id] = self._d.sealed_output_artifacts(job_root)
                safe_path = sealed_by_job[job_id].get(relative)
                if safe_path is None:
                    raise ValueError("file is not sealed")
                if not safe_path.is_file():
                    raise ValueError("file missing")
                total_input += safe_path.stat().st_size
                if total_input > export_limit:
                    return RequestExportPlan.failure(
                        413, "Export exceeds the configured limit", request_id, scope
                    )
                code = self._d.sanitize_filename(str(item.get("materialCode") or ""), 80)
                prefix = code if scope == "dxf" and code else job_id
                relative_parts = [
                    self._d.sanitize_filename(part, 120)
                    for part in self._d.relative_parts(relative)
                    if part not in {"", ".", "output"}
                ]
                if not relative_parts or any(not part for part in relative_parts):
                    raise ValueError("invalid export path")
                if (
                    str(item.get("kind") or "") == "dxf"
                    and (
                        relative.startswith("output/DXF_Zaagplaten/")
                        or relative.startswith("output/sheets/")
                    )
                ):
                    friendly = self._d.sanitize_filename(
                        str(item.get("downloadName") or ""), 160
                    )
                    if friendly:
                        relative_parts[-1] = friendly
                selected.append((safe_path, "/".join([prefix, *relative_parts])))
            except Exception:
                return RequestExportPlan.failure(
                    409, "Export manifest is no longer valid", request_id, scope
                )
        if not selected:
            return RequestExportPlan.failure(
                404, "No valid files for this request", request_id, scope
            )
        return RequestExportPlan(
            True,
            200,
            "",
            request_id,
            scope,
            tuple(selected),
            f"{request_id}_{'dxf' if scope == 'dxf' else 'outputs'}.zip",
        )


__all__ = (
    "RequestDownloadDependencies",
    "RequestDownloadProjectionService",
    "RequestExportPlan",
)
