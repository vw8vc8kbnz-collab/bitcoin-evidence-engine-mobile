from __future__ import annotations

"""Single owner for durable request status and its reconstructable index.

The repository deliberately does not own submission, customer validation,
idempotency, Admin projection, archive transactions or retention. Paths and the
existing process lock are injected by the composition root so there is no second
state or lock owner.
"""

from typing import Any, Callable

from safety_contracts import (
    append_jsonl_rotating,
    durable_write_json,
    durable_write_text,
    fsync_directory,
    resolve_identifier_child,
    strict_json_dumps,
    strict_json_load,
    validate_request_id,
)


PathProvider = Callable[[], Any]
LockProvider = Callable[[], Any]
IntProvider = Callable[[], int]


def request_index_row(request_id: str, status: dict) -> dict:
    """Return the established non-PII current-state request-index row."""

    job = status.get("job") if isinstance(status.get("job"), dict) else {}
    return {
        "ts": status.get("updatedAt") or status.get("createdAt"),
        "requestId": request_id,
        "publicStatus": status.get("publicStatus"),
        "internalStatus": status.get("internalStatus"),
        "quoteStatus": status.get("quoteStatus"),
        "needsQuote": bool(status.get("needsQuote")),
        "parentJobId": job.get("parentJobId"),
    }


class RequestRepository:
    """Durable request-status repository using one injected lock instance."""

    def __init__(
        self,
        *,
        requests_root: PathProvider,
        requests_index: PathProvider,
        index_lock: LockProvider,
        ensure_directories: Callable[[], None],
        utc_now_iso: Callable[[], str],
        jsonl_max_bytes: IntProvider,
        max_active_rows: IntProvider,
        file_lock_module: Callable[[], Any],
    ) -> None:
        self._requests_root = requests_root
        self._requests_index = requests_index
        self._index_lock = index_lock
        self._ensure_directories = ensure_directories
        self._utc_now_iso = utc_now_iso
        self._jsonl_max_bytes = jsonl_max_bytes
        self._max_active_rows = max_active_rows
        self._file_lock_module = file_lock_module

    def load_status(self, request_id: str) -> dict | None:
        try:
            request_id = validate_request_id(request_id)
            status_path = resolve_identifier_child(
                self._requests_root(), request_id, kind="request"
            ) / "status.json"
            data = strict_json_load(status_path)
            return data if isinstance(data, dict) else None
        except Exception:
            return None

    def save_status(self, request_id: str, status: dict) -> None:
        request_id = validate_request_id(request_id)
        request_root = resolve_identifier_child(
            self._requests_root(), request_id, kind="request"
        )
        status["updatedAt"] = self._utc_now_iso()
        # Request status contains customer contact data and a cancellation secret.
        durable_write_json(request_root / "status.json", status, mode=0o600)
        row = request_index_row(request_id, status)
        with self._index_lock():
            append_jsonl_rotating(
                self._requests_index(),
                row,
                max_bytes=self._jsonl_max_bytes(),
                backups=5,
            )

    def compact_index(self) -> dict:
        """Write one PII-free row per active request to the bounded index."""

        self._ensure_directories()
        max_rows = max(1000, min(1_000_000, self._max_active_rows()))
        requests_root = self._requests_root()
        request_dirs = [
            path for path in sorted(requests_root.iterdir(), reverse=True)
            if path.is_dir()
        ]
        truncated = len(request_dirs) > max_rows
        request_dirs = request_dirs[:max_rows]
        rows: list[str] = []
        for request_dir in request_dirs:
            status = self.load_status(request_dir.name)
            if isinstance(status, dict):
                rows.append(strict_json_dumps(request_index_row(request_dir.name, status)))
        payload = "\n".join(reversed(rows)) + ("\n" if rows else "")
        requests_index = self._requests_index()
        lock_path = requests_index.parent / f".{requests_index.name}.rotate.lock"
        removed_rotations = 0
        with self._index_lock():
            lock_path.parent.mkdir(parents=True, exist_ok=True)
            with open(lock_path, "a+b", buffering=0) as lock_handle:
                file_lock = self._file_lock_module()
                if file_lock is not None:
                    file_lock.flock(lock_handle.fileno(), file_lock.LOCK_EX)
                try:
                    durable_write_text(requests_index, payload, mode=0o640)
                    for rotated in requests_index.parent.glob(f"{requests_index.name}.*"):
                        suffix = rotated.name[len(requests_index.name) + 1:]
                        if rotated.is_file() and suffix.isdigit():
                            rotated.unlink(missing_ok=True)
                            removed_rotations += 1
                    fsync_directory(requests_index.parent)
                finally:
                    if file_lock is not None:
                        file_lock.flock(lock_handle.fileno(), file_lock.LOCK_UN)
        return {
            "rows": len(rows),
            "truncated": truncated,
            "removedRotations": removed_rotations,
        }


__all__ = ("RequestRepository", "request_index_row")
