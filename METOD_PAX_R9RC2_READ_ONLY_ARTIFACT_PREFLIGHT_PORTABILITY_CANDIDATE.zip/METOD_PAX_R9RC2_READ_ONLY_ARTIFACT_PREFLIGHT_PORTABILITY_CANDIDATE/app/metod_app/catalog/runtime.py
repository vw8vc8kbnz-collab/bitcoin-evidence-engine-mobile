from __future__ import annotations

"""Bounded CatalogRuntime implementation with explicit runtime injection."""

class CatalogRuntime:
    def __init__(self, runtime):
        self._runtime = runtime

    def _invalidate_public_materials_response_cache(_owner) -> None:
        runtime = _owner._runtime
        _PUBLIC_MATERIALS_RESPONSE_CACHE = runtime._PUBLIC_MATERIALS_RESPONSE_CACHE
        _PUBLIC_MATERIALS_RESPONSE_CACHE_LOCK = runtime._PUBLIC_MATERIALS_RESPONSE_CACHE_LOCK

        with _PUBLIC_MATERIALS_RESPONSE_CACHE_LOCK:
            _PUBLIC_MATERIALS_RESPONSE_CACHE['mtimeNs'] = None
            _PUBLIC_MATERIALS_RESPONSE_CACHE['body'] = None
            _PUBLIC_MATERIALS_RESPONSE_CACHE['etag'] = None


    def _path_content_signature(_owner, path: Path) -> tuple[int, int, int, int, int] | None:
        """Return a mutation-sensitive, process-local file signature."""
        runtime = _owner._runtime
        Path = runtime.Path

    
        try:
            stat_result = Path(path).stat()
            return (
                int(stat_result.st_dev),
                int(stat_result.st_ino),
                int(stat_result.st_size),
                int(stat_result.st_mtime_ns),
                int(stat_result.st_ctime_ns),
            )
        except Exception:
            return None


    def _invalidate_material_lookup_cache(_owner) -> None:
        runtime = _owner._runtime
        _MATERIAL_LIBRARY_LOCK = runtime._MATERIAL_LIBRARY_LOCK
        _MATERIAL_LOOKUP_CACHE = runtime._MATERIAL_LOOKUP_CACHE

        with _MATERIAL_LIBRARY_LOCK:
            _MATERIAL_LOOKUP_CACHE.update({
                'signature': None,
                'publicToInternal': {},
                'internalToPublic': {},
                'catalogByInternal': {},
                'replacements': (),
            })


    def _material_lookup_snapshot(_owner) -> dict[str, Any]:
        """Return immutable-by-convention catalog lookup maps cached by file identity.
    
        Public job/status traffic used to parse and normalize all 597 catalog rows two
        or three times per request while holding one global lock.  The active catalog is
        atomically replaced, so device/inode/size/mtime/ctime form a safe invalidation
        key.  Admin writes explicitly invalidate this cache as well.
        """
        runtime = _owner._runtime
        Any = runtime.Any
        MATERIAL_LIBRARY_PATH = runtime.MATERIAL_LIBRARY_PATH
        SafetyContractError = runtime.SafetyContractError
        _MATERIAL_LIBRARY_LOCK = runtime._MATERIAL_LIBRARY_LOCK
        _MATERIAL_LOOKUP_CACHE = runtime._MATERIAL_LOOKUP_CACHE
        _PUBLIC_MATERIAL_ID_RE = runtime._PUBLIC_MATERIAL_ID_RE
        _path_content_signature = runtime._path_content_signature
        strict_json_load = runtime.strict_json_load

    
        with _MATERIAL_LIBRARY_LOCK:
            signature = _path_content_signature(MATERIAL_LIBRARY_PATH)
            if signature is not None and _MATERIAL_LOOKUP_CACHE.get('signature') == signature:
                return _MATERIAL_LOOKUP_CACHE
    
            raw = strict_json_load(MATERIAL_LIBRARY_PATH) if MATERIAL_LIBRARY_PATH.exists() else {'records': []}
            records = raw.get('records') if isinstance(raw, dict) else raw
            if not isinstance(records, list):
                raise SafetyContractError('material_library.json must contain a records list')
            public_to_internal: dict[str, str] = {}
            internal_to_public: dict[str, str] = {}
            catalog_by_internal: dict[str, dict] = {}
            for record in records:
                if not isinstance(record, dict):
                    continue
                internal = str(record.get('articleNo') or record.get('articleNumber') or record.get('materialCode') or '').strip()
                public_id = str(record.get('publicMaterialId') or '').strip().lower()
                if internal:
                    catalog_by_internal[internal] = record
                if internal and _PUBLIC_MATERIAL_ID_RE.fullmatch(public_id):
                    public_to_internal[public_id] = internal
                    internal_to_public[internal] = public_id
            replacements = tuple(sorted(
                ((internal, public_id) for internal, public_id in internal_to_public.items()),
                key=lambda item: len(item[0]),
                reverse=True,
            ))
            _MATERIAL_LOOKUP_CACHE.update({
                'signature': signature,
                'publicToInternal': public_to_internal,
                'internalToPublic': internal_to_public,
                'catalogByInternal': catalog_by_internal,
                'replacements': replacements,
            })
            return _MATERIAL_LOOKUP_CACHE


    def _cached_sha256_file(_owner, path: Path) -> str:
        """Hash an immutable artifact once per exact filesystem content signature.
    
        ``ctime_ns`` deliberately participates in the key.  A same-size modification
        followed by restoring the old mtime therefore cannot reuse a positive cache hit.
        A before/after signature check also prevents caching a hash across a concurrent
        replacement.  The bounded cache is only an acceleration; all security decisions
        still compare the expected digest with the actual artifact digest.
        """
        runtime = _owner._runtime
        Path = runtime.Path
        SafetyContractError = runtime.SafetyContractError
        _ARTIFACT_HASH_CACHE = runtime._ARTIFACT_HASH_CACHE
        _ARTIFACT_HASH_CACHE_LOCK = runtime._ARTIFACT_HASH_CACHE_LOCK
        _env_int = runtime._env_int
        _path_content_signature = runtime._path_content_signature
        sha256_file = runtime.sha256_file

    
        target = Path(path)
        for _attempt in range(2):
            before = _path_content_signature(target)
            if before is None:
                raise FileNotFoundError(str(target))
            with _ARTIFACT_HASH_CACHE_LOCK:
                cached = _ARTIFACT_HASH_CACHE.get(before)
                if cached is not None:
                    _ARTIFACT_HASH_CACHE.move_to_end(before)
                    return cached
            digest = sha256_file(target)
            after = _path_content_signature(target)
            if before != after:
                continue
            with _ARTIFACT_HASH_CACHE_LOCK:
                _ARTIFACT_HASH_CACHE[before] = digest
                _ARTIFACT_HASH_CACHE.move_to_end(before)
                limit = max(1024, min(131072, _env_int('ARTIFACT_HASH_CACHE_ENTRIES', 32768)))
                while len(_ARTIFACT_HASH_CACHE) > limit:
                    _ARTIFACT_HASH_CACHE.popitem(last=False)
            return digest
        raise SafetyContractError(f'Artifact changed while hashing: {target.name}')


    def _classify_dxf_filename(_owner, name: str) -> str:
        runtime = _owner._runtime

        n = name.lower()
        # PAX first
        if n.startswith("pax"):
            return "Deuren PAX"
        # METOD ladefront
        if n.startswith("metod") and ("lade" in n or "ladefront" in n):
            return "Ladefront METOD"
        # METOD deuren
        if n.startswith("metod") and ("deur" in n or "deuren" in n):
            return "Deuren METOD"
        return "Overige panelen"


    def migrate_embedded_dxfs_on_startup(_owner):
        runtime = _owner._runtime
        DXF_CATEGORIES = runtime.DXF_CATEGORIES
        DXF_LIBRARY_ROOT = runtime.DXF_LIBRARY_ROOT
        _classify_dxf_filename = runtime._classify_dxf_filename
        fsync_directory = runtime.fsync_directory
        os = runtime.os

        # Moves DXF files from embedded_dxfs root into category folders.
        # One-time safe: only removes the original file after successful move.
        # Deterministic: classification uses filename only.
        dxf_root = DXF_LIBRARY_ROOT
        dxf_root.mkdir(parents=True, exist_ok=True)
    
        # Ensure category folders exist
        for cat in DXF_CATEGORIES:
            (dxf_root / cat).mkdir(parents=True, exist_ok=True)
    
        moved = 0
        for fp in sorted(dxf_root.iterdir()):
            if not fp.is_file():
                continue
            if fp.suffix.lower() != ".dxf":
                continue
            target_cat = _classify_dxf_filename(fp.name)
            dest = dxf_root / target_cat / fp.name
            if dest.exists():
                # Keep category version; leave root file untouched
                continue
            try:
                os.replace(fp, dest)
                fsync_directory(dest.parent)
                fsync_directory(dxf_root)
                moved += 1
            except Exception:
                continue
        return moved


    def classify_dxf_category(_owner, filename: str) -> str:
        runtime = _owner._runtime

        lower = str(filename or "").lower().strip()
        # Mirror Tool A parseMetaFromFilename() type logic
        if lower.startswith("pax"):
            return "Deuren PAX"
        if "lade" in lower and "apothekerslade" not in lower:
            return "Ladefront METOD"
        if "deur" in lower:
            return "Deuren METOD"
        return "Overige panelen"


    def migrate_embedded_dxfs_to_categories(_owner):
        """One-time migration: move root-level DXFs in app/embedded_dxfs into category subfolders.
        This keeps Tool A behavior (manifest relative paths) and makes Admin categories match Tool A labels."""
        runtime = _owner._runtime
        DXF_CATEGORIES = runtime.DXF_CATEGORIES
        DXF_LIBRARY_ROOT = runtime.DXF_LIBRARY_ROOT
        classify_dxf_category = runtime.classify_dxf_category
        fsync_directory = runtime.fsync_directory
        os = runtime.os

        dxf_root = DXF_LIBRARY_ROOT
        dxf_root.mkdir(parents=True, exist_ok=True)
    
        # Ensure default categories exist
        for cat in DXF_CATEGORIES:
            (dxf_root / cat).mkdir(parents=True, exist_ok=True)
    
        # Move any DXF files in the root of embedded_dxfs into a category folder
        for p in sorted(dxf_root.iterdir()):
            if not p.is_file():
                continue
            if not p.name.lower().endswith(".dxf"):
                continue
            # Skip temp
            if p.name.lower().endswith(".tmp"):
                continue
            target_dir = dxf_root / classify_dxf_category(p.name)
            target = target_dir / p.name
            # If target exists, keep existing and avoid overwrite by renaming
            if target.exists():
                stem = target.stem
                suffix = target.suffix
                i = 2
                while True:
                    cand = target_dir / f"{stem} ({i}){suffix}"
                    if not cand.exists():
                        target = cand
                        break
                    i += 1
            try:
                os.replace(p, target)
                fsync_directory(target_dir)
                fsync_directory(dxf_root)
            except Exception:
                # Best effort; if move fails, keep file in root
                pass


    def get_embedded_dxfs_version(_owner):
        """Return a monotonic-ish version for embedded_dxfs tree (ms since epoch based on latest mtime).
        Used by Tool A to auto-refresh without server restart."""
        runtime = _owner._runtime
        DXF_LIBRARY_ROOT = runtime.DXF_LIBRARY_ROOT
        DXF_MANIFEST_PATH = runtime.DXF_MANIFEST_PATH

        dxf_root = DXF_LIBRARY_ROOT
        latest = 0.0
        try:
            if dxf_root.exists():
                for p in dxf_root.rglob("*"):
                    try:
                        st = p.stat()
                        if st.st_mtime > latest:
                            latest = st.st_mtime
                    except Exception:
                        continue
        except Exception:
            pass
        try:
            man = DXF_MANIFEST_PATH
            if man.exists():
                mt = man.stat().st_mtime
                if mt > latest:
                    latest = mt
        except Exception:
            pass
        return int(latest * 1000)


    def rebuild_embedded_dxfs_manifest(_owner):
        """Rebuild app/embedded_dxfs_manifest.json from files inside app/embedded_dxfs.
        Includes files in root and subfolders (relative paths)."""
        runtime = _owner._runtime
        DXF_LIBRARY_ROOT = runtime.DXF_LIBRARY_ROOT
        DXF_MANIFEST_PATH = runtime.DXF_MANIFEST_PATH
        durable_write_json = runtime.durable_write_json

        dxf_root = DXF_LIBRARY_ROOT
        dxf_root.mkdir(parents=True, exist_ok=True)
    
        files = []
        for p in sorted(dxf_root.rglob("*")):
            if not p.is_file():
                continue
            name = p.name.lower()
            if name.endswith(".tmp"):
                continue
            if p.name == "embedded_dxfs_manifest.json":
                continue
            if not name.endswith(".dxf"):
                continue
            rel = p.relative_to(dxf_root).as_posix()
            files.append(rel)
    
        manifest = {"files": files, "count": len(files)}
        durable_write_json(DXF_MANIFEST_PATH, manifest)


    def _looks_numeric_material_name(_owner, v: str) -> bool:
        runtime = _owner._runtime

        vv = str(v or "").strip().replace(",", ".")
        if not vv:
            return False
        try:
            float(vv)
            return True
        except Exception:
            return False


    def _best_material_name(_owner, code: str, *candidates) -> str:
        runtime = _owner._runtime
        _load_material_name_by_code = runtime._load_material_name_by_code
        _looks_numeric_material_name = runtime._looks_numeric_material_name

        for c in candidates:
            name = str(c or "").strip()
            if name and not _looks_numeric_material_name(name):
                return name
        code = str(code or "").strip()
        if code:
            lib = _load_material_name_by_code()
            if code in lib:
                return lib[code]
        for c in candidates:
            name = str(c or "").strip()
            if name:
                return name
        return ""


    def _material_label_for_filename(_owner, material_code: str, thickness_mm) -> str:
        """Build a human-readable material label for exported filenames.
        Prefer the real material/decor name from loaded material metadata; fall back to code.
        Thickness is intentionally omitted from the visible filename label for cleaner DXF names.
        """
        runtime = _owner._runtime
        _best_material_name = runtime._best_material_name

        code = str(material_code or '').strip()
        name = _best_material_name(code, '') if code else ''
        return str(name or code or '').strip()

    EXPORTS = ('_invalidate_public_materials_response_cache', '_path_content_signature', '_invalidate_material_lookup_cache', '_material_lookup_snapshot', '_cached_sha256_file', '_classify_dxf_filename', 'migrate_embedded_dxfs_on_startup', 'classify_dxf_category', 'migrate_embedded_dxfs_to_categories', 'get_embedded_dxfs_version', 'rebuild_embedded_dxfs_manifest', '_looks_numeric_material_name', '_best_material_name', '_material_label_for_filename')

__all__ = ("CatalogRuntime",)
