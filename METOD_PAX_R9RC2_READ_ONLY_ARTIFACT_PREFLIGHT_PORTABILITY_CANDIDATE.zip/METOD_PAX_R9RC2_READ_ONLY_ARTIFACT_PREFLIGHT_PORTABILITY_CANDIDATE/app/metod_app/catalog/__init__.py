"""Catalog runtime domain."""
