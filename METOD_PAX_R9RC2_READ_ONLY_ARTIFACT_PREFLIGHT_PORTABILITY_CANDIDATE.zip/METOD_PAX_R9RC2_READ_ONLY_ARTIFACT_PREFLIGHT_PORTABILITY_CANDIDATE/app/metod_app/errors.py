"""Typed, transport-neutral error primitives and public HTTP messages."""


class MetodError(Exception):
    """Base class for future typed METOD/PAX application errors."""


class ContractViolation(MetodError, ValueError):
    """Raised when a domain input violates an explicit R9 contract."""


def public_error_message(code: int, fallback: str = "Er ging iets mis.") -> str:
    """Return the existing non-sensitive Dutch message for an HTTP status."""

    status = int(code or 500)
    if status == 400:
        return "Ongeldige aanvraag."
    if status == 403:
        return "Actie niet toegestaan."
    if status == 404:
        return "Niet gevonden."
    if status == 413:
        return "Aanvraag te groot."
    if status == 429:
        return "Te veel verzoeken. Probeer het later opnieuw."
    return fallback


__all__ = ("ContractViolation", "MetodError", "public_error_message")
