"""Pure composition root for immutable METOD/PAX process context.

This module deliberately owns no startup, shutdown, threads, sockets or I/O.
It only composes the already extracted runtime configuration and path layout.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Mapping

from .config import RuntimeConfig
from .paths import AppPaths


@dataclass(frozen=True, slots=True)
class AppContext:
    """Immutable process-level dependencies available during composition."""

    config: RuntimeConfig
    paths: AppPaths


def build_app_context(
    *,
    app_root: str | os.PathLike[str],
    environment: Mapping[str, str] | None = None,
) -> AppContext:
    """Build one side-effect-free context from a shared environment view."""

    return AppContext(
        config=RuntimeConfig.from_environment(environment),
        paths=AppPaths.from_environment(
            app_root=app_root,
            environment=environment,
        ),
    )


__all__ = ("AppContext", "build_app_context")
