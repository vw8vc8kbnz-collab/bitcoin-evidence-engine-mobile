from __future__ import annotations

"""Single active owner for Admin presentation, authentication and sessions.

The HTTP server deliberately keeps only narrow adapters around this boundary.
R9M keeps this module focused on authentication and sessions. Presentation
templates and same-origin assets are owned by ``admin.presentation`` without
changing cookie, CSRF or development-only Basic-authentication contracts.
"""

import base64
import json
import secrets
import time
from dataclasses import dataclass
from typing import Any, Callable, Mapping

from .presentation import ADMIN_HTML, ADMIN_LOGIN_HTML





def normalized_admin_users(credentials: dict | None) -> list[dict[str, Any]]:
    creds = credentials if isinstance(credentials, dict) else {}
    raw_users = creds.get("users")
    users: list[dict[str, Any]] = []
    if isinstance(raw_users, list):
        for raw in raw_users:
            if not isinstance(raw, dict) or raw.get("active") is False:
                continue
            username = str(raw.get("username") or "").strip()
            password_hash = str(raw.get("password_hash") or raw.get("passwordHash") or "").strip()
            roles = raw.get("roles") if isinstance(raw.get("roles"), list) else ["admin"]
            roles = sorted({str(role).strip().lower() for role in roles if str(role).strip()})
            if username and password_hash:
                users.append(
                    {
                        "username": username,
                        "password_hash": password_hash,
                        "totp_secret": str(raw.get("totp_secret") or raw.get("totpSecret") or "").strip(),
                        "roles": roles or ["admin"],
                    }
                )
        return users
    username = str(creds.get("username") or "").strip()
    password_hash = str(creds.get("password_hash") or creds.get("passwordHash") or "").strip()
    if username and password_hash:
        users.append(
            {
                "username": username,
                "password_hash": password_hash,
                "totp_secret": str(creds.get("totp_secret") or creds.get("totpSecret") or "").strip(),
                "roles": ["admin"],
            }
        )
    return users


def find_admin_user(credentials: dict | None, username: str) -> dict[str, Any] | None:
    import hmac

    supplied = str(username or "").strip()
    for user in normalized_admin_users(credentials):
        if hmac.compare_digest(str(user.get("username") or ""), supplied):
            return user
    return None


class AdminSessionStore:
    """Bounded in-memory Admin session owner with idle and absolute expiry."""

    def __init__(
        self,
        *,
        idle_seconds: int,
        absolute_seconds: int,
        max_sessions: Callable[[], int],
        lock: Any,
        clock: Callable[[], float] = time.time,
        token_factory: Callable[[], str] | None = None,
    ) -> None:
        self._idle_seconds = idle_seconds
        self._absolute_seconds = absolute_seconds
        self._max_sessions = max_sessions
        self._clock = clock
        self._token_factory = token_factory or (lambda: secrets.token_urlsafe(32))
        self._lock = lock
        self._sessions: dict[str, dict[str, Any]] = {}

    @property
    def idle_seconds(self) -> int:
        return max(300, min(3600, int(self._idle_seconds or 1800)))

    @property
    def absolute_seconds(self) -> int:
        return max(self.idle_seconds, self.cookie_max_age)

    @property
    def cookie_max_age(self) -> int:
        # Preserve the historical wire contract even when an invalid custom
        # configuration makes absolute expiry shorter than idle expiry.
        return max(300, min(24 * 60 * 60, int(self._absolute_seconds or 28800)))

    def create(self, actor: str, roles: list[str] | None = None) -> tuple[str, float]:
        token = self._token_factory()
        now = self._clock()
        idle = self.idle_seconds
        exp = now + self.absolute_seconds
        with self._lock:
            for key, value in list(self._sessions.items()):
                if float(value.get("absoluteExpiresAt") or 0) <= now or float(
                    value.get("idleExpiresAt") or 0
                ) <= now:
                    self._sessions.pop(key, None)
            max_sessions = max(8, min(4096, int(self._max_sessions())))
            while len(self._sessions) >= max_sessions:
                oldest = min(
                    self._sessions,
                    key=lambda key: float(self._sessions[key].get("lastSeenAt") or 0),
                )
                self._sessions.pop(oldest, None)
            self._sessions[token] = {
                "actor": str(actor or "").strip(),
                "roles": sorted(
                    {str(role).strip().lower() for role in (roles or ["admin"]) if str(role).strip()}
                ),
                "createdAt": now,
                "lastSeenAt": now,
                "idleExpiresAt": now + idle,
                "absoluteExpiresAt": exp,
            }
        return token, exp

    def valid(self, token: str) -> bool:
        raw = str(token or "").strip()
        if not raw:
            return False
        with self._lock:
            session = self._sessions.get(raw)
            if not session:
                return False
            now = self._clock()
            if float(session.get("absoluteExpiresAt") or 0) <= now or float(
                session.get("idleExpiresAt") or 0
            ) <= now:
                self._sessions.pop(raw, None)
                return False
            session["lastSeenAt"] = now
            session["idleExpiresAt"] = min(
                now + self.idle_seconds,
                float(session.get("absoluteExpiresAt") or now),
            )
            return True

    def revoke(self, token: str) -> None:
        raw = str(token or "").strip()
        if raw:
            with self._lock:
                self._sessions.pop(raw, None)

    def actor(self, token: str) -> str:
        raw = str(token or "").strip()
        if not raw:
            return ""
        with self._lock:
            session = self._sessions.get(raw) or {}
            return str(session.get("actor") or "").strip()

    def roles(self, token: str) -> frozenset[str]:
        raw = str(token or "").strip()
        if not raw:
            return frozenset()
        with self._lock:
            session = self._sessions.get(raw) or {}
            roles = session.get("roles") if isinstance(session.get("roles"), list) else []
            return frozenset(str(role).strip().lower() for role in roles if str(role).strip())


@dataclass(frozen=True)
class AdminAccessDependencies:
    root: Any
    environment: Mapping[str, str]
    credentials_file_path: Callable[[], Any]
    strict_json_load: Callable[[Any], Any]
    strict_json_dumps: Callable[[Any], str]
    read_json_body_limited: Callable[[Any, str, int], dict]
    production_runtime: Callable[[], bool]
    production_hardening_enabled: Callable[[], bool]
    secure_admin_transport: Callable[[Any], bool]
    https_request: Callable[[Any], bool]
    client_ip: Callable[[Any], str]
    loopback_client: Callable[[Any], bool]
    rate_limit_is_blocked: Callable[[str, str, int, int], bool]
    rate_limit_record: Callable[[str, str], None]
    rate_limit_clear: Callable[[str, str], None]
    verify_password: Callable[[str, str], bool]
    verify_totp: Callable[[str, str], bool]
    append_system_event: Callable[..., None]
    extract_bearer_token: Callable[[str], str]
    extract_session_cookie: Callable[[str], str]
    dummy_password_hash: str
    dummy_totp_secret: str


class AdminAccessController:
    """Active Admin credential, login, cookie, challenge and session owner."""

    def __init__(self, dependencies: AdminAccessDependencies, sessions: AdminSessionStore) -> None:
        self.dependencies = dependencies
        self.sessions = sessions

    def load_credentials(self) -> dict | None:
        deps = self.dependencies
        # One credential authority only. Environment-supplied shared accounts
        # previously took precedence over the validated credentials file and
        # could make production validation disagree with runtime behavior.
        credentials_path = deps.credentials_file_path()
        try:
            obj = deps.strict_json_load(credentials_path)
            if isinstance(obj, dict) and normalized_admin_users(obj):
                result = dict(obj)
                result["source"] = (
                    "external_config"
                    if credentials_path != (deps.root / "config" / "admin_credentials.json")
                    else "config"
                )
                result["path"] = str(credentials_path)
                return result
        except FileNotFoundError:
            pass
        except Exception:
            pass
        return None

    def warn_if_local_credentials_in_production(self, handler: Any, credentials: dict | None) -> None:
        try:
            if not self.dependencies.production_hardening_enabled():
                return
            source = str((credentials or {}).get("source") or "")
            if source != "config":
                return
            message = (
                "Production hardening is active, but admin credentials are still loaded from "
                "app/config/admin_credentials.json. Move credentials to an external path and set "
                "ADMIN_CREDENTIALS_FILE or ADMIN_CREDENTIALS_PATH for live deployment."
            )
            try:
                if not getattr(handler.server, "_local_admin_credentials_warned", False):
                    print("[SECURITY WARNING] " + message)
                    setattr(handler.server, "_local_admin_credentials_warned", True)
            except Exception:
                print("[SECURITY WARNING] " + message)
        except Exception:
            pass

    def _credentials(self, handler: Any) -> dict:
        credentials = self.load_credentials() or {}
        self.warn_if_local_credentials_in_production(handler, credentials)
        return credentials

    def _has_admin_session(self, token: str) -> bool:
        return bool(token and self.sessions.valid(token) and "admin" in self.sessions.roles(token))

    def login(self, handler: Any) -> None:
        deps = self.dependencies
        try:
            data = deps.read_json_body_limited(handler, "ADMIN_JSON_MAX_BYTES", 262144)
        except Exception:
            return handler._send_json(
                {"ok": False, "authRequired": True, "error": "Invalid login payload"}, 400
            )
        credentials = self._credentials(handler)
        users = normalized_admin_users(credentials)
        if not users:
            return handler._send_json(
                {"ok": False, "authRequired": True, "error": "Admin authentication not configured"},
                403,
            )
        if deps.production_hardening_enabled() and not deps.secure_admin_transport(handler):
            return handler._send_json(
                {"ok": False, "authRequired": True, "error": "Admin authentication requires HTTPS"},
                403,
            )
        username = str(data.get("username") or "").strip()
        ip = deps.client_ip(handler)
        account_key = username.casefold() or "[empty]"
        if (
            deps.rate_limit_is_blocked("admin_auth_fail", ip, 10, 300)
            or deps.rate_limit_is_blocked("admin_auth_fail_account", account_key, 10, 300)
        ):
            return handler._send_json(
                {"ok": False, "authRequired": True, "error": "Too many login attempts"}, 429
            )
        password = str(data.get("password") or "")
        otp = str(data.get("otp") or "")
        user = find_admin_user(credentials, username)
        stored_hash = str(user.get("password_hash") or "") if user else deps.dummy_password_hash
        stored_totp = str(user.get("totp_secret") or "") if user else deps.dummy_totp_secret
        password_ok = deps.verify_password(password, stored_hash)
        mfa_ok = deps.verify_totp(stored_totp or deps.dummy_totp_secret, otp)
        if user and password_ok and (mfa_ok or (not deps.production_runtime() and not stored_totp)):
            deps.rate_limit_clear("admin_auth_fail", ip)
            deps.rate_limit_clear("admin_auth_fail_account", account_key)
            token, expires_at = self.sessions.create(username, list(user.get("roles") or ["admin"]))
            body = deps.strict_json_dumps(
                {"ok": True, "expiresAt": int(expires_at), "actor": username}
            ).encode("utf-8")
            handler.send_response(200)
            handler.send_header("Content-Type", "application/json; charset=utf-8")
            handler.send_header("Content-Length", str(len(body)))
            secure = "; Secure" if (deps.production_runtime() or deps.https_request(handler)) else ""
            handler.send_header(
                "Set-Cookie",
                f"adzaagt_admin_session={token}; Path=/; SameSite=Strict; HttpOnly{secure}; "
                f"Max-Age={self.sessions.cookie_max_age}",
            )
            handler.end_headers()
            handler.wfile.write(body)
            return None
        deps.rate_limit_record("admin_auth_fail", ip)
        deps.rate_limit_record("admin_auth_fail_account", account_key)
        deps.append_system_event(
            level="warning",
            component="auth",
            message_user="Admin login mislukt",
            message_tech="Invalid overlay login",
            status="open",
        )
        return handler._send_json(
            {"ok": False, "authRequired": True, "error": "Invalid admin credentials"}, 401
        )

    def check_silent(self, handler: Any) -> bool:
        deps = self.dependencies
        credentials = self._credentials(handler)
        if not normalized_admin_users(credentials):
            return False
        authorization = handler.headers.get("Authorization") or ""
        bearer = deps.extract_bearer_token(authorization)
        if self._has_admin_session(bearer):
            return True
        cookie_token = deps.extract_session_cookie(handler.headers.get("Cookie") or "")
        if self._has_admin_session(cookie_token):
            return True
        if deps.production_runtime():
            return False
        if not authorization.startswith("Basic "):
            return False
        try:
            decoded = base64.b64decode(authorization.split(" ", 1)[1].strip()).decode("utf-8")
            supplied_user, supplied_password = decoded.split(":", 1)
        except Exception:
            return False
        user = find_admin_user(credentials, supplied_user)
        return bool(
            user
            and deps.verify_password(supplied_password, str(user.get("password_hash") or ""))
        )

    def current_session_token(self, handler: Any) -> str:
        deps = self.dependencies
        bearer = deps.extract_bearer_token(handler.headers.get("Authorization") or "")
        if self._has_admin_session(bearer):
            return bearer
        cookie = deps.extract_session_cookie(handler.headers.get("Cookie") or "")
        if self._has_admin_session(cookie):
            return cookie
        return ""

    def current_actor(self, handler: Any) -> str:
        token = self.current_session_token(handler)
        if token:
            return self.sessions.actor(token)
        return "local-development" if not self.dependencies.production_runtime() else ""

    def logout(self, handler: Any) -> None:
        deps = self.dependencies
        token = self.current_session_token(handler)
        actor = self.sessions.actor(token)
        self.sessions.revoke(token)
        body = b'{"ok":true}'
        handler.send_response(200)
        handler.send_header("Content-Type", "application/json; charset=utf-8")
        handler.send_header("Content-Length", str(len(body)))
        secure = "; Secure" if (deps.production_runtime() or deps.https_request(handler)) else ""
        handler.send_header(
            "Set-Cookie",
            f"adzaagt_admin_session=; Path=/; SameSite=Strict; HttpOnly{secure}; Max-Age=0",
        )
        handler.end_headers()
        handler.wfile.write(body)
        if actor:
            deps.append_system_event(
                level="info",
                component="auth",
                message_user="Admin uitgelogd",
                message_tech="Session revoked",
                status="resolved",
                details={"actor": actor},
            )

    @staticmethod
    def wants_native_basic_prompt(handler: Any) -> bool:
        try:
            requested_with = (handler.headers.get("X-Requested-With") or "").lower()
            if requested_with:
                return False
            accept = (handler.headers.get("Accept") or "").lower()
            destination = (handler.headers.get("Sec-Fetch-Dest") or "").lower()
            mode = (handler.headers.get("Sec-Fetch-Mode") or "").lower()
            if destination == "empty" or mode in ("cors", "same-origin"):
                return False
            return ("text/html" in accept) or destination in ("document", "")
        except Exception:
            return False

    def send_challenge(
        self,
        handler: Any,
        code: int = 401,
        message: str = "Admin authentication required",
    ) -> bool:
        try:
            if not self.wants_native_basic_prompt(handler):
                handler.send_response(code)
                handler.send_header("Content-Type", "application/json; charset=utf-8")
                handler.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
                handler.send_header("X-Admin-Auth-Required", "1")
                handler.send_header("X-Content-Type-Options", "nosniff")
                handler.end_headers()
                body = json.dumps(
                    {"ok": False, "authRequired": True, "error": message}, ensure_ascii=False
                ).encode("utf-8")
                handler.wfile.write(body)
                return False
        except Exception:
            pass
        handler.send_response(code)
        if code == 401 and not self.dependencies.production_runtime():
            handler.send_header("WWW-Authenticate", 'Basic realm="Admin"')
        handler.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        handler.end_headers()
        try:
            handler.wfile.write(str(message).encode("utf-8"))
        except Exception:
            pass
        return False

    def require_auth(self, handler: Any) -> bool:
        deps = self.dependencies
        if deps.environment.get("ADMIN_STAGING_OPEN") == "1":
            if (not deps.production_runtime()) and deps.loopback_client(handler):
                return True
            try:
                deps.append_system_event(
                    level="error",
                    component="auth",
                    message_user="Admin staging bypass geblokkeerd",
                    message_tech=(
                        "ADMIN_STAGING_OPEN was set but public admin bypass is disabled in FIX618"
                    ),
                    status="open",
                )
            except Exception:
                pass
        credentials = self._credentials(handler)
        if not normalized_admin_users(credentials):
            deps.append_system_event(
                level="error",
                component="auth",
                message_user="Admin-login is niet geconfigureerd",
                message_tech=(
                    f"Missing username/password in "
                    f"{credentials.get('path') or deps.credentials_file_path()}"
                ),
                status="open",
            )
            return self.send_challenge(handler, 403, "Admin authentication not configured.")

        if deps.production_hardening_enabled() and not deps.secure_admin_transport(handler):
            deps.append_system_event(
                level="error",
                component="auth",
                message_user="Admin-login geblokkeerd",
                message_tech=(
                    "Admin authentication requires HTTPS or loopback in production hardening mode"
                ),
                status="open",
            )
            return self.send_challenge(handler, 403, "Admin authentication requires HTTPS.")

        ip = deps.client_ip(handler)
        authorization = handler.headers.get("Authorization") or ""
        bearer = deps.extract_bearer_token(authorization)
        if self._has_admin_session(bearer):
            deps.rate_limit_clear("admin_auth_fail", ip)
            return True
        cookie_token = deps.extract_session_cookie(handler.headers.get("Cookie") or "")
        if self._has_admin_session(cookie_token):
            deps.rate_limit_clear("admin_auth_fail", ip)
            return True
        if deps.production_runtime():
            return self.send_challenge(handler, 401, "Admin authentication required")
        if not authorization.startswith("Basic "):
            return self.send_challenge(handler, 401, "Admin authentication required")

        encoded = authorization.split(" ", 1)[1].strip()
        try:
            decoded = base64.b64decode(encoded).decode("utf-8")
        except Exception:
            if deps.rate_limit_is_blocked("admin_auth_fail", ip, 10, 300):
                handler.send_response(429)
                handler.end_headers()
                handler.wfile.write(b"Too many login attempts.")
                return False
            deps.rate_limit_record("admin_auth_fail", ip)
            deps.append_system_event(
                level="warning",
                component="auth",
                message_user="Admin login mislukt",
                message_tech="Invalid Basic auth encoding",
                status="open",
            )
            return self.send_challenge(handler, 401, "Admin authentication required")

        username, _, password = decoded.partition(":")
        user = find_admin_user(credentials, username)
        if user and deps.verify_password(password, str(user.get("password_hash") or "")):
            deps.rate_limit_clear("admin_auth_fail", ip)
            return True

        if deps.rate_limit_is_blocked("admin_auth_fail", ip, 10, 300):
            handler.send_response(429)
            handler.end_headers()
            handler.wfile.write(b"Too many login attempts.")
            return False
        deps.rate_limit_record("admin_auth_fail", ip)
        deps.append_system_event(
            level="warning",
            component="auth",
            message_user="Admin login mislukt",
            message_tech="Invalid credentials",
            status="open",
        )
        return self.send_challenge(handler, 401, "Invalid admin credentials")
