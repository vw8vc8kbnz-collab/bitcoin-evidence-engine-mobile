from __future__ import annotations

"""Fail-closed owner for the Admin templates and same-origin static assets."""

import re
from dataclasses import dataclass
from importlib.resources import files
from types import MappingProxyType
from typing import Mapping


@dataclass(frozen=True, slots=True)
class AdminAsset:
    body: str
    content_type: str
    requires_session: bool


def _read_resource(folder: str, name: str) -> str:
    return files(__package__).joinpath(folder, name).read_text(encoding="utf-8", errors="strict")


def _validate_template(name: str, html: str, expected_assets: tuple[str, ...]) -> None:
    if re.search(r"<style\b", html, re.IGNORECASE):
        raise RuntimeError(f"{name}: embedded style element is forbidden")
    if re.search(r"\sstyle\s*=", html, re.IGNORECASE):
        raise RuntimeError(f"{name}: inline style attribute is forbidden")
    if re.search(r"\son[a-z]+\s*=", html, re.IGNORECASE):
        raise RuntimeError(f"{name}: inline event attribute is forbidden")
    scripts = re.findall(r"<script\b([^>]*)>(.*?)</script>", html, re.IGNORECASE | re.DOTALL)
    if any(body.strip() or not re.search(r'\bsrc="/[^"]+"', attributes) for attributes, body in scripts):
        raise RuntimeError(f"{name}: inline or non-root-relative script is forbidden")
    references = tuple(re.findall(r'(?:href|src)="(/admin/assets/[^"]+)"', html, re.IGNORECASE))
    if references != expected_assets:
        raise RuntimeError(f"{name}: Admin asset references drifted")
    if re.search(r'(?:href|src)="(?:https?:)?//', html, re.IGNORECASE):
        raise RuntimeError(f"{name}: remote presentation dependency is forbidden")


ADMIN_HTML = _read_resource("templates", "admin.html")
ADMIN_LOGIN_HTML = _read_resource("templates", "login.html")

_validate_template(
    "admin.html",
    ADMIN_HTML,
    (
        "/admin/assets/admin.css",
        "/admin/assets/dxf.js",
        "/admin/assets/admin.js",
    ),
)
_validate_template(
    "login.html",
    ADMIN_LOGIN_HTML,
    (
        "/admin/assets/login.css",
        "/admin/assets/login.js",
    ),
)

ADMIN_ASSETS: Mapping[str, AdminAsset] = MappingProxyType(
    {
        "/admin/assets/admin.css": AdminAsset(
            _read_resource("assets", "admin.css"), "text/css; charset=utf-8", True
        ),
        "/admin/assets/admin.js": AdminAsset(
            _read_resource("assets", "admin.js"), "text/javascript; charset=utf-8", True
        ),
        "/admin/assets/dxf.js": AdminAsset(
            _read_resource("assets", "dxf.js"), "text/javascript; charset=utf-8", True
        ),
        "/admin/assets/login.css": AdminAsset(
            _read_resource("assets", "login.css"), "text/css; charset=utf-8", False
        ),
        "/admin/assets/login.js": AdminAsset(
            _read_resource("assets", "login.js"), "text/javascript; charset=utf-8", False
        ),
    }
)


def admin_asset_for_path(path: str) -> AdminAsset | None:
    """Return only an explicitly allowlisted Admin asset."""

    return ADMIN_ASSETS.get(path)


__all__ = (
    "ADMIN_ASSETS",
    "ADMIN_HTML",
    "ADMIN_LOGIN_HTML",
    "AdminAsset",
    "admin_asset_for_path",
)
