
              async function _postJson(url, body){
                const r = await fetch(url, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body)});
                let j = {};
                try{ j = await r.json(); }catch(e){}
                return {ok:r.ok, json:j};
              }
              async function _getJson(url){
                const r = await fetch(url, {cache:'no-store'});
                let j = {};
                try{ j = await r.json(); }catch(e){}
                return {ok:r.ok, json:j};
              }

              function esc(s){ return String(s).replace(/[&<>"']/g, c=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c])); }

              async function dxf_load_categories(){
                const sel = document.getElementById('dxfCatSel');
                if(!sel) return;
                const prev = sel.value || '';
                const {ok, json} = await _getJson('/api/admin/dxf/categories');
                sel.innerHTML = '';
                (json.categories || []).forEach(c=>{
                  const o = document.createElement('option');
                  o.value = c;
                  o.textContent = (c === '(root)') ? '(root)' : c;
                  sel.appendChild(o);
                });
                if(prev){
                  const opt = Array.from(sel.options).find(o=>o.value===prev);
                  if(opt) sel.value = prev;
                }
              }

              async function dxf_load_files(){
                const sel = document.getElementById('dxfCatSel');
                const box = document.getElementById('dxfFiles');
                const st = document.getElementById('dxfStatus');
                let cat = sel ? sel.value : '';
                const catText = (sel && sel.options && sel.selectedIndex>=0) ? (sel.options[sel.selectedIndex].textContent||'') : '';
                if(cat === '(root)' && catText && catText !== '(root)') cat = catText;
                if(!cat){ if(box) box.textContent='Geen categorie geselecteerd.'; return; }
                const {ok, json} = await _getJson('/api/admin/dxf/list?category=' + encodeURIComponent(cat));
                if(!ok || !json.ok){ if(st) st.textContent='Fout: ' + (json.error||''); return; }
                const files = json.files || [];
                if(!files.length){ if(box) box.textContent='Geen DXF bestanden in deze categorie.'; return; }
                box.innerHTML = files.map(fn=>(
                  `<div class="admin-u-025">
                    <div class="admin-u-026">${esc(fn)}</div>
                    <button class="btn danger" type="button" data-act="delete-dxf" data-cat="${encodeURIComponent(cat)}" data-file="${encodeURIComponent(fn)}">Verwijder</button>
                  </div>`
                )).join('');
                box.querySelectorAll('[data-act="delete-dxf"]').forEach(btn=>{
                  btn.addEventListener('click', ()=>{
                    const catVal = decodeURIComponent(btn.getAttribute('data-cat') || '');
                    const fileVal = decodeURIComponent(btn.getAttribute('data-file') || '');
                    dxf_delete_file(catVal, fileVal);
                  });
                });
              }

              async function dxf_create_category(){
                const inp = document.getElementById('dxfNewCat');
                const st = document.getElementById('dxfStatus');
                const name = inp ? inp.value.trim() : '';
                if(!name){ if(st) st.textContent='Vul een categorie naam in.'; return; }
                const {ok, json} = await _postJson('/api/admin/dxf/create_category', {category:name});
                if(!ok || !json.ok){ if(st) st.textContent='Fout: ' + (json.error||''); return; }
                if(st) st.textContent='Categorie aangemaakt: ' + name;
                if(inp) inp.value='';
                await dxf_load_categories();
                const sel = document.getElementById('dxfCatSel');
                if(sel) sel.value = name;
                await dxf_load_files();
              }

              async function dxf_upload_file(){
                const sel = document.getElementById('dxfCatSel');
                let cat = sel ? sel.value : '';
                const catText = (sel && sel.options && sel.selectedIndex>=0) ? (sel.options[sel.selectedIndex].textContent||'') : '';
                if(cat === '(root)' && catText && catText !== '(root)') cat = catText;
                const inp = document.getElementById('dxfFileInput');
                const st = document.getElementById('dxfStatus');
                if(!cat){ if(st) st.textContent='Selecteer eerst een categorie.'; return; }
                if(!inp || !inp.files || !inp.files.length){ if(st) st.textContent='Kies eerst een DXF bestand.'; return; }
                const file = inp.files[0];
                const buf = await file.arrayBuffer();
                let bin = '';
                const bytes = new Uint8Array(buf);
                const chunk = 0x8000;
                for(let i=0;i<bytes.length;i+=chunk){
                  bin += String.fromCharCode.apply(null, bytes.subarray(i,i+chunk));
                }
                const b64 = btoa(bin);
                const {ok, json} = await _postJson('/api/admin/dxf/upload', {category:cat, filename:file.name, dataBase64:b64});
                if(!ok || !json.ok){ if(st) st.textContent='Fout: ' + (json.error||''); return; }
                if(st) st.textContent='Upload OK: ' + file.name;
                inp.value='';
                await dxf_load_files();
              }

              async function dxf_delete_file(cat, fn){
                if(!confirm('Verwijderen: ' + fn + ' ?')) return;
                const st = document.getElementById('dxfStatus');
                const {ok, json} = await _postJson('/api/admin/dxf/delete', {category:cat, filename:fn});
                if(!ok || !json.ok){ if(st) st.textContent='Fout: ' + (json.error||''); return; }
                if(st) st.textContent='Verwijderd: ' + fn;
                await dxf_load_files();
              }

              document.addEventListener('DOMContentLoaded', ()=>{
                const r = document.getElementById('dxfRefreshBtn');
                const c = document.getElementById('dxfCreateCatBtn');
                const u = document.getElementById('dxfUploadBtn');
                if(r) r.addEventListener('click', async()=>{ await dxf_load_categories(); await dxf_load_files(); });
                if(c) c.addEventListener('click', dxf_create_category);
                if(u) u.addEventListener('click', dxf_upload_file);
                (async()=>{ await dxf_load_categories(); await dxf_load_files(); })();
              });
              