
// ADMIN guard: prevent double-execution (hot reload / injected twice)
if (window.__ADMIN_JS_LOADED__) { console.warn('Admin JS already loaded'); } else {
  window.__ADMIN_JS_LOADED__ = true;

	function _zaagFile(z){ return (typeof z === 'string') ? z : (z && z.file ? z.file : ''); }
	function _zaagLabel(z){ return (typeof z === 'string') ? z : (z && (z.label || z.file) ? (z.label || z.file) : ''); }
	function _h(s){
	  return String(s==null?'':s).replace(/[&<>"']/g, c=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
	}
	// Admin owns its escaping primitive. Do not depend on dxf.js load order.
	const esc = _h;
	function _jobLabel(j){
	  const cn = String((j && j.customerName) ? j.customerName : '').trim();
	  const id = String((j && j.jobId) ? j.jobId : '');
	  return cn ? (_h(cn) + ' · ' + _h(id)) : _h(id);
	}
window.reloadPricing = async function reloadPricing(){
  const st = document.getElementById('pricingStatus');
  const meta = document.getElementById('pricingMeta');
  if(st) st.textContent = 'laden...';
  try{
    const r = await fetch('/api/admin/pricing', {cache:'no-store'});
    const j = await r.json();
    window.__pricingCfg = j;
    const pricing = j.pricing || {};
    const defaults = pricing.defaults || {};
    const rounding = defaults.rounding || {};
    const sell = j.sellPricing || {};
    const setVal = (id, val) => { const el = document.getElementById(id); if(el) el.value = (val !== undefined && val !== null) ? String(val) : ''; };
    setVal('priceSheetMargin', defaults.sheetMarginMm);
    setVal('priceNestingGap', defaults.nestingGapMm);
    setVal('priceKerf', defaults.kerfMm);
    setVal('priceMoneyDecimals', rounding.moneyDecimals);
    setVal('priceMetersDecimals', rounding.metersDecimals);
    setVal('priceEdgeBand', sell.edgeBandPricePerM);
    setVal('priceCnc', sell.cncCostPerSheet);
    setVal('priceDrawing', sell.drawingCostFixed);
    setVal('priceTransport', sell.transportCostFixed);
    if(st) st.textContent = 'geladen';
    if(meta) meta.textContent = 'Live configuratie geladen';
  }catch(e){
    if(st) st.textContent = 'fout bij laden: ' + (e && e.message ? e.message : e);
    if(meta) meta.textContent = 'Kon pricing-config niet laden';
  }
}

function pricingReadNumber(id, label, integerOnly=false){
  const el = document.getElementById(id);
  const raw = String(el && el.value!=null ? el.value : '').trim().replace(',', '.');
  if(!raw) throw new Error(label + ' is leeg');
  const n = integerOnly ? parseInt(raw, 10) : parseFloat(raw);
  if(!Number.isFinite(n)) throw new Error(label + ' is ongeldig');
  if(n < 0) throw new Error(label + ' mag niet negatief zijn');
  return integerOnly ? Math.round(n) : n;
}

window.savePricing = async function savePricing(){
  const st = document.getElementById('pricingStatus');
  const meta = document.getElementById('pricingMeta');
  if(st) st.textContent = 'opslaan...';
  try{
    const base = window.__pricingCfg ? JSON.parse(JSON.stringify(window.__pricingCfg)) : null;
    const cfg = base || await (async()=>{ const r = await fetch('/api/admin/pricing', {cache:'no-store'}); return await r.json(); })();
    cfg.pricing = cfg.pricing || {};
    cfg.pricing.defaults = cfg.pricing.defaults || {};
    cfg.pricing.defaults.rounding = cfg.pricing.defaults.rounding || {};
    cfg.sellPricing = cfg.sellPricing || {};
    cfg.pricing.defaults.sheetMarginMm = pricingReadNumber('priceSheetMargin', 'Plaatmarge');
    cfg.pricing.defaults.nestingGapMm = pricingReadNumber('priceNestingGap', 'Nesting gap');
    cfg.pricing.defaults.kerfMm = pricingReadNumber('priceKerf', 'Kerf');
    cfg.pricing.defaults.rounding.moneyDecimals = pricingReadNumber('priceMoneyDecimals', 'Bedragen afronden', true);
    cfg.pricing.defaults.rounding.metersDecimals = pricingReadNumber('priceMetersDecimals', 'Meters afronden', true);
    cfg.sellPricing.edgeBandPricePerM = pricingReadNumber('priceEdgeBand', 'Kantenband per meter');
    cfg.sellPricing.cncCostPerSheet = pricingReadNumber('priceCnc', 'CNC per plaat');
    cfg.sellPricing.drawingCostFixed = pricingReadNumber('priceDrawing', 'Tekenwerk vast');
    cfg.sellPricing.transportCostFixed = pricingReadNumber('priceTransport', 'Transport vast');

    const r = await fetch('/api/admin/pricing', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(cfg)});
    const j = await r.json();
    if(!r.ok){ if(st) st.textContent = 'fout: ' + (j.error || r.status); return; }
    if(st) st.textContent = 'opgeslagen (' + (j.version || 'ok') + ')';
    if(meta) meta.textContent = 'Laatste save: ' + (j.version || 'ok');
    window.__pricingCfg = cfg;
  }catch(e){
    if(st) st.textContent = 'fout bij opslaan: ' + (e && e.message ? e.message : e);
  }
}

function _escapeHtml(s){ return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
function _fmtBytes(n){ n = Number(n||0); if(n < 1024) return n + ' B'; if(n < 1024*1024) return (n/1024).toFixed(1) + ' KB'; if(n < 1024*1024*1024) return (n/1024/1024).toFixed(1) + ' MB'; return (n/1024/1024/1024).toFixed(1) + ' GB'; }
function _systemToneClass(it){
  return (it.level === 'error') ? 'systemToneError' : (it.level === 'warning' ? 'systemToneWarning' : 'systemToneInfo');
}
function _systemRefs(it){
  return [it.requestId ? ('Request: ' + it.requestId) : '', it.jobId ? ('Job: ' + it.jobId) : '', it.customerName ? ('Klant: ' + it.customerName) : ''].filter(Boolean).join(' · ');
}
function _renderSystemDetailCard(it){
  const user = _escapeHtml(it.messageUser || 'Onbekende melding');
  const tech = _escapeHtml(it.messageTech || '—');
  const meta = [it.component || 'systeem', it.level || 'info', it.ts || ''].filter(Boolean).join(' · ');
  const refs = _systemRefs(it);
  return `<details class="card systemLogItem ${_systemToneClass(it)} admin-u-091">
    <summary class="admin-u-092">
      <div class="admin-u-093">
        <div class="admin-u-094">${user}</div>
        <div class="pill">${_escapeHtml(it.status || 'open')}</div>
      </div>
      <div class="muted">${_escapeHtml(meta)}</div>
      ${refs ? `<div class="admin-u-095">${_escapeHtml(refs)}</div>` : ''}
    </summary>
    <div class="admin-u-096">
      <div class="admin-u-097">
        <div class="admin-u-098">Technische details</div>
        <code class="admin-u-099">${tech}</code>
      </div>
    </div>
  </details>`;
}
function _renderSystemCompactRow(it){
  const refs = _systemRefs(it);
  const meta = [it.component || 'systeem', it.ts || ''].filter(Boolean).join(' · ');
  return `<div class="card ${_systemToneClass(it)} admin-u-100">
    <div class="admin-u-093">
      <div class="admin-u-101">${_escapeHtml(it.messageUser || 'Onbekende melding')}</div>
      <div class="pill">${_escapeHtml(it.status || 'resolved')}</div>
    </div>
    <div class="muted">${_escapeHtml(meta)}</div>
    ${refs ? `<div class="admin-u-102">${_escapeHtml(refs)}</div>` : ''}
  </div>`;
}
async function refreshSystemPage(){
  const logsStatus = document.getElementById('systemLogsStatus');
  const openIssuesList = document.getElementById('systemOpenIssuesList');
  const recentActionsList = document.getElementById('systemRecentActionsList');
  const historyList = document.getElementById('systemHistoryList');
  const backupStatus = document.getElementById('systemBackupStatus');
  const backupsList = document.getElementById('systemBackupsList');
  const openIssuesCount = document.getElementById('systemOpenIssuesCount');
  const recentActionsCount = document.getElementById('systemRecentActionsCount');
  const historyCount = document.getElementById('systemHistoryCount');
  const backupsCount = document.getElementById('systemBackupsCount');
  if(logsStatus) logsStatus.textContent = 'Systeemmeldingen laden…';
  if(backupStatus) backupStatus.textContent = 'Backups laden…';
  try{
    const [lr, br] = await Promise.all([
      fetch('/api/admin/system/logs', {cache:'no-store', credentials:'same-origin'}),
      fetch('/api/admin/system/backups', {cache:'no-store', credentials:'same-origin'})
    ]);
    const lj = await lr.json().catch(()=>({ok:false,error:'Ongeldige log-response'}));
    const bj = await br.json().catch(()=>({ok:false,error:'Ongeldige backup-response'}));
    const logItems = (lr.ok && lj.ok) ? (lj.items||[]) : [];
    const backupItems = (br.ok && bj.ok) ? (bj.items||[]) : [];
    const openItems = logItems.filter(it => {
      const status = String(it && it.status || '').toLowerCase();
      const level = String(it && it.level || '').toLowerCase();
      return status !== 'resolved' || level === 'error' || level === 'warning';
    });
    const recentItems = logItems.filter(it => !openItems.includes(it)).slice(0, 5);
    if(logsStatus) logsStatus.textContent = (lr.ok && lj.ok) ? `${logItems.length||0} meldingen geladen` : ('Fout: ' + (lj.error || ('HTTP ' + lr.status)));
    if(backupStatus) backupStatus.textContent = (br.ok && bj.ok) ? `${backupItems.length||0} backups gevonden` : ('Fout: ' + (bj.error || ('HTTP ' + br.status)));
    if(openIssuesCount) openIssuesCount.textContent = String(openItems.length || 0);
    if(recentActionsCount) recentActionsCount.textContent = String(recentItems.length || 0);
    if(historyCount) historyCount.textContent = String(logItems.length || 0);
    if(backupsCount) backupsCount.textContent = String(backupItems.length || 0);
    if(openIssuesList){
      openIssuesList.innerHTML = openItems.length ? openItems.map(_renderSystemDetailCard).join('') : `<div class="card admin-u-103">Geen open fouten of waarschuwingen.</div>`;
    }
    if(recentActionsList){
      recentActionsList.innerHTML = recentItems.length ? recentItems.map(_renderSystemCompactRow).join('') : `<div class="card admin-u-103">Nog geen recente systeemacties.</div>`;
    }
    if(historyList){
      historyList.innerHTML = logItems.length ? logItems.map(_renderSystemDetailCard).join('') : `<div class="card admin-u-104">Geen systeemmeldingen gevonden.</div>`;
    }
    if(backupsList){
      backupsList.innerHTML = backupItems.length ? backupItems.map(it => `<div class="card admin-u-105"><div><div class="admin-u-106"><span>${_escapeHtml(it.name || '')}</span><span class="pill">${(it.kind||'manual')==='auto'?'Automatisch':'Handmatig'}</span></div><div class="muted">${_escapeHtml(it.modified || '')}</div></div><div class="admin-u-107"><div class="pill">${_fmtBytes(it.size || 0)}</div><a class="btn secondary" href="/api/admin/system/backup_download?name=${encodeURIComponent(it.name || '')}">Download</a></div></div>`).join('') : `<div class="card admin-u-103">Nog geen backups gevonden.</div>`;
    }
  }catch(err){
    if(logsStatus) logsStatus.textContent = 'Fout: ' + (err && err.message || err);
    if(backupStatus) backupStatus.textContent = 'Fout: ' + (err && err.message || err);
  }
}
async function createSystemBackup(){
  const st = document.getElementById('systemBackupStatus');
  if(st) st.textContent = 'Backup wordt gemaakt…';
  try{
    const r = await fetch('/api/admin/system/backup_now', {method:'POST', headers:{'Content-Type':'application/json'}, body:'{}'});
    const j = await r.json().catch(()=>({ok:false,error:'Ongeldige serverresponse'}));
    if(!r.ok || !j.ok){ if(st) st.textContent = 'Fout: ' + (j.error || ('HTTP ' + r.status)); return; }
    if(st) st.textContent = `Backup gemaakt: ${j.file || ''}`;
    refreshSystemPage();
  }catch(err){ if(st) st.textContent = 'Fout: ' + (err && err.message || err); }
}
window.refreshSystemPage = refreshSystemPage;
window.createSystemBackup = createSystemBackup;

function switchAdminSection(section){
  document.querySelectorAll('.adminNavBtn').forEach(btn=>{
    btn.classList.toggle('active', btn.getAttribute('data-section') === section);
  });
  document.querySelectorAll('.adminSection').forEach(sec=>{
    sec.classList.toggle('active', sec.getAttribute('data-section') === section);
  });
  if(section === 'system'){ try{ refreshSystemPage(); }catch(_e){} }
}

function initAdminShell(){
  if(window.__adminShellInit) return;
  window.__adminShellInit = true;
  document.querySelectorAll('.adminNavBtn').forEach(btn=>{
    btn.addEventListener('click', ()=> switchAdminSection(btn.getAttribute('data-section') || 'inbox'));
  });
  switchAdminSection('inbox');
}

let materialsCache = [];
let materialsSelectedKey = '';
function matNum(v){
  const raw = String(v == null ? '' : v).trim().replace(',', '.');
  if(!raw) return null;
  const n = parseFloat(raw);
  return Number.isFinite(n) ? n : null;
}
function materialKeyOf(r){ return String((r && (r.articleNo || r.articleNumber || r.materialCode)) || '').trim(); }
function materialDecorOf(r){ return String((r && (r.decorName || r.productName || r.materialDisplayName || '')) || '').trim(); }
function materialCodeOf(r){ return String((r && (r.materialCode || r.articleNo || '')) || '').trim(); }
function materialsDimensionOf(r){
  const w = materialsFormatDim(r?.sheetWid || r?.sheetWidth || '');
  const l = materialsFormatDim(r?.sheetLen || r?.sheetHeight || r?.height || '');
  return w && l ? (w + '×' + l + ' mm') : '';
}
function materialsThicknessOf(r){
  return materialsFormatDim(r?.thicknessMm || r?.thickness || '');
}
function materialsGetFilterState(){
  return {
    search: String(document.getElementById('materialsSearch')?.value || '').trim().toLowerCase(),
    thickness: String(document.getElementById('materialsFilterThickness')?.value || '').trim(),
    dimension: String(document.getElementById('materialsFilterDimension')?.value || '').trim(),
    category: String(document.getElementById('materialsFilterCategory')?.value || '').trim().toLowerCase(),
    brandText: String(document.getElementById('materialsFilterBrandText')?.value || '').trim().toLowerCase(),
    availability: String(document.getElementById('materialsFilterAvailability')?.value || '').trim(),
  };
}
function materialsActiveFilterCount(){
  const f = materialsGetFilterState();
  return [f.thickness, f.dimension, f.category, f.brandText, f.availability].filter(Boolean).length;
}
function materialsUpdateFiltersToggleLabel(){
  const btn = document.getElementById('materialsFiltersToggle');
  if(!btn) return;
  const n = materialsActiveFilterCount();
  btn.textContent = n ? ('Filters (' + n + ')') : 'Filters';
}
const ADMIN_RUNTIME_DISPLAY_CLASSES = Object.freeze(['adminRuntimeHidden','adminRuntimeBlock','adminRuntimeGrid','adminRuntimeFlex','adminRuntimeTableRow']);
const setAdminRuntimeDisplay = (element, display) => {
  if(!element) return;
  element.classList.remove(...ADMIN_RUNTIME_DISPLAY_CLASSES);
  const className = {
    none:'adminRuntimeHidden', block:'adminRuntimeBlock', grid:'adminRuntimeGrid',
    flex:'adminRuntimeFlex', 'table-row':'adminRuntimeTableRow'
  }[display];
  if(className) element.classList.add(className);
};
function materialsToggleFilters(forceOpen){
  const panel = document.getElementById('materialsFiltersPanel');
  if(!panel) return;
  const open = forceOpen === true ? true : !panel.classList.contains('adminRuntimeBlock');
  setAdminRuntimeDisplay(panel, open ? 'block' : 'none');
}
function materialsPopulateFilterOptions(){
  const thicknessEl = document.getElementById('materialsFilterThickness');
  const dimEl = document.getElementById('materialsFilterDimension');
  const catEl = document.getElementById('materialsFilterCategory');
  const current = materialsGetFilterState();
  const uniqueSorted = (vals, numeric=false) => Array.from(new Set(vals.filter(Boolean))).sort((a,b)=>{
    if(numeric){ return parseFloat(a) - parseFloat(b); }
    return String(a).localeCompare(String(b), 'nl', {numeric:true, sensitivity:'base'});
  });
  const thicknesses = uniqueSorted(materialsCache.map(r=>materialsThicknessOf(r)), true);
  const dims = uniqueSorted(materialsCache.map(r=>materialsDimensionOf(r)));
  const cats = uniqueSorted(materialsCache.map(r=>String(r.categoryName || '').trim()));
  if(thicknessEl) thicknessEl.innerHTML = '<option value="">Alle diktes</option>' + thicknesses.map(v=>`<option value="${esc(v)}">${esc(v)} mm</option>`).join('');
  if(dimEl) dimEl.innerHTML = '<option value="">Alle afmetingen</option>' + dims.map(v=>`<option value="${esc(v)}">${esc(v)}</option>`).join('');
  if(catEl) catEl.innerHTML = '<option value="">Alle plaatsoorten</option>' + cats.map(v=>`<option value="${esc(v)}">${esc(v)}</option>`).join('');
  if(thicknessEl) thicknessEl.value = current.thickness;
  if(dimEl) dimEl.value = current.dimension;
  if(catEl) catEl.value = current.category ? (cats.find(v=>String(v).toLowerCase()===current.category) || '') : '';
  materialsUpdateFiltersToggleLabel();
}
function materialsFilterRows(){
  const f = materialsGetFilterState();
  return materialsCache.filter(r=>{
    const hay = [r.articleNo, r.articleNumber, r.materialCode, r.decorName, r.productName, r.categoryName, r.shortDescription].map(v=>String(v||'').toLowerCase());
    if(f.search && !hay.some(v=>v.includes(f.search))) return false;
    const thickness = materialsThicknessOf(r);
    if(f.thickness && thickness !== f.thickness) return false;
    const dimension = materialsDimensionOf(r);
    if(f.dimension && dimension !== f.dimension) return false;
    const category = String(r.categoryName || '').trim().toLowerCase();
    if(f.category && category !== f.category) return false;
    if(f.brandText){
      const brandHay = [r.productName, r.decorName, r.shortDescription, r.categoryName, r.articleNo].map(v=>String(v||'').toLowerCase()).join(' | ');
      if(!brandHay.includes(f.brandText)) return false;
    }
    if(f.availability === 'yes' && r.active === false) return false;
    if(f.availability === 'no' && r.active !== false) return false;
    return true;
  });
}
function materialsSetCategoryValue(val){
  const el = document.getElementById('matCategoryName');
  if(!el) return;
  const v = String(val || '').trim();
  if(v && !Array.from(el.options).some(o=>o.value===v)){
    const opt = document.createElement('option');
    opt.value = v;
    opt.textContent = v;
    opt.dataset.dynamic = '1';
    el.appendChild(opt);
  }
  el.value = v;
}
function materialsFormatDim(n){
  const num = Number(n);
  if(!Number.isFinite(num)) return '';
  return Number.isInteger(num) ? String(Math.trunc(num)) : String(num).replace(/\.0+$/,'').replace(/(\.\d*?)0+$/,'$1');
}
function materialsUpdateDerivedFields(){
  if(materialsSelectedKey) return;
  const descEl = document.getElementById('matShortDescription');
  const w = matNum(document.getElementById('matSheetWid')?.value);
  const l = matNum(document.getElementById('matSheetLen')?.value);
  const t = matNum(document.getElementById('matThickness')?.value);
  if(!descEl) return;
  const prevAuto = descEl.dataset.auto === '1';
  const canAuto = prevAuto || !String(descEl.value || '').trim();
  if(!canAuto) return;
  if(w>0 && l>0 && t>0){
    descEl.value = `${materialsFormatDim(l)}x${materialsFormatDim(w)}x${materialsFormatDim(t)}mm`;
    descEl.dataset.auto = '1';
  }else if(prevAuto){
    descEl.value = '';
    descEl.dataset.auto = '0';
  }
}
function materialsRenderPublicPreview(){
  const target=document.getElementById('matToolAPreview'); if(!target) return;
  const publicName=String(document.getElementById('matPublicName')?.value||'Publieke decornaam').trim()||'Publieke decornaam';
  const brand=String(document.getElementById('matBrand')?.value||'Merk').trim()||'Merk';
  const type=String(document.getElementById('matDecorType')?.value||'Overig').trim()||'Overig';
  const thickness=materialsFormatDim(document.getElementById('matThickness')?.value)||'—';
  const grain=!!document.getElementById('matHasGrain')?.checked;
  const source=document.querySelector('#matImagePreview img')?.getAttribute('src')||'';
  const media=source?`<img src="${esc(source)}" alt="">`:'▧';
  target.innerHTML=`<div class="decorAdminToolACardMedia">${media}</div><div class="decorAdminToolACardBody"><div class="decorAdminToolACardBrand">${esc(brand)}</div><div class="decorAdminToolACardName">${esc(publicName)}</div><div class="decorAdminToolACardTags"><span class="decorAdminToolACardTag">${grain?'Nerf':'Uni'}</span><span class="decorAdminToolACardTag">${esc(thickness)} mm</span><span class="decorAdminToolACardTag">${esc(type)}</span></div></div>`;
}
function materialsSetForm(rec){
  const state=document.getElementById('materialsDetailState');
  const empty=document.getElementById('matCsvOnlyDetailEmpty');
  const detail=document.getElementById('matCsvOnlyDetail');
  if(!rec){
    if(state) state.textContent='Geen product geselecteerd.';
    setAdminRuntimeDisplay(empty, 'block');
    setAdminRuntimeDisplay(detail, 'none');
    return;
  }
  if(state) state.textContent='CSV-product geselecteerd';
  setAdminRuntimeDisplay(empty, 'none');
  setAdminRuntimeDisplay(detail, 'block');
  const txt=(id,val)=>{const el=document.getElementById(id);if(el)el.textContent=String(val??'');};
  txt('matCsvOnlyBrand',rec.brand||'Overig');
  txt('matCsvOnlyName',rec.publicName||rec.productName||rec.decorName||'Decor');
  txt('matCsvOnlyThickness',(materialsFormatDim(rec.thicknessMm||rec.thickness)||'—')+' mm');
  txt('matCsvOnlySize',materialsDimensionOf(rec)||'—');
  const price=Number(rec.sellPriceInclVatPerSheet||0);
  txt('matCsvOnlyPrice',price>0?new Intl.NumberFormat('nl-NL',{style:'currency',currency:'EUR'}).format(price):'—');
  txt('matCsvOnlyImageState',rec.imageAvailable?'Lokaal beschikbaar':'Wordt opgehaald / ontbreekt');
  txt('matCsvOnlyArticle',rec.articleNo||rec.articleNumber||rec.materialCode||'—');
  txt('matCsvOnlyPublicId',rec.publicMaterialId||'—');
  const ds=String(rec.dimensionSource||'csv');
  txt('matCsvOnlyDimensionSource',ds==='csv'?'CSV':(ds==='image_url'?'Afbeeldings-URL':(ds==='decolegno_18_fallback'?'DecoLegno 18 mm fallback':ds)));
  const familySelect=document.getElementById('matCsvOnlyFamilyOverride');
  const manualFamily=String(rec.taxonomyManualFamilyOverride||'').trim();
  if(familySelect){
    familySelect.value=manualFamily||'AUTO';
    familySelect.disabled=false;
  }
  txt('matCsvOnlyFamilyOverrideState',manualFamily ? ('Handmatig vastgezet op '+manualFamily) : ('Automatisch · '+String(rec.primaryVisualFamily||rec.decorType||'Onbekend')));
  const image=document.getElementById('matCsvOnlyImage');
  if(image){
    const url=String(rec.imagePreviewUrl||rec.imageThumbUrl||'').trim();
    image.innerHTML=url?`<img src="${esc(url)}" alt="Decorafbeelding" class="admin-u-108">`:'Geen afbeelding';
  }
}
async function materialsSaveFamilyOverride(){
  const select=document.getElementById('matCsvOnlyFamilyOverride');
  const state=document.getElementById('matCsvOnlyFamilyOverrideState');
  if(!select||!materialsSelectedKey) return;
  const rec=materialsCache.find(x=>materialKeyOf(x)===materialsSelectedKey)||null;
  const pid=String(rec?.publicMaterialId||'').trim();
  if(!pid){ if(state) state.textContent='Opslaan niet mogelijk: publieke decor-ID ontbreekt.'; return; }
  const requested=String(select.value||'AUTO');
  try{
    select.disabled=true;
    if(state) state.textContent='Opslaan…';
    const r=await fetch('/api/admin/materials/live_taxonomy_family',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({publicMaterialId:pid,primaryVisualFamily:requested})});
    const j=await r.json().catch(()=>({}));
    if(!r.ok||!j.ok) throw new Error(j.error||('HTTP '+r.status));
    const idx=materialsCache.findIndex(x=>materialKeyOf(x)===materialsSelectedKey);
    if(idx>=0&&j.record) materialsCache[idx]=j.record;
    const updated=idx>=0?materialsCache[idx]:j.record;
    materialsSetForm(updated||null);
    materialsPopulateFilterOptions();
    materialsRenderList();
    if(state) state.textContent=j.manualOverride ? ('Handmatig vastgezet op '+j.primaryVisualFamily) : ('Automatisch · '+j.primaryVisualFamily);
  }catch(e){
    select.disabled=false;
    select.value=String(rec?.taxonomyManualFamilyOverride||'').trim()||'AUTO';
    if(state) state.textContent='Opslaan mislukt: '+(e?.message||e);
  }
}

function materialsRenderList(){
  const list = document.getElementById('materialsList');
  const meta = document.getElementById('materialsMeta');
  if(!list) return;
  const rows = materialsFilterRows();
  const activeCount = materialsActiveFilterCount();
  if(meta) meta.textContent = rows.length + ' van ' + materialsCache.length + ' materialen zichtbaar' + (activeCount ? (' · ' + activeCount + ' filter' + (activeCount===1?'':'s') + ' actief') : '');
  materialsUpdateFiltersToggleLabel();
  if(!rows.length){ list.innerHTML = '<div class="muted">Geen materialen gevonden.</div>'; return; }
  list.innerHTML = rows.map(r=>{
    const key = materialKeyOf(r);
    const title = esc(r.publicName || r.productName || r.decorName || r.articleNo || 'Materiaal');
    const status = 'CSV actief';
    const metaText = [r.articleNo, r.brand || '', r.primaryVisualFamily || r.decorType || '', r.substrateLabel || '', materialsDimensionOf(r), materialsThicknessOf(r) ? (materialsThicknessOf(r) + ' mm') : '', status].filter(Boolean).map(esc).join('<span>·</span>');
    const thumb = r.imageThumbUrl ? `<img src="${esc(r.imageThumbUrl)}" alt="">` : '▧';
    return `<button class="materialsRow${materialsSelectedKey===key?' active':''}" type="button" data-key="${esc(key)}"><div class="materialsRowWithImage"><div class="materialsRowThumb">${thumb}</div><div><div class="materialsRowTitle">${title}</div><div class="materialsRowMeta">${metaText}</div></div></div></button>`;
  }).join('');
  list.querySelectorAll('.materialsRow').forEach(btn=>btn.addEventListener('click', ()=>{
    const key = btn.getAttribute('data-key') || '';
    const rec = materialsCache.find(x=>materialKeyOf(x)===key) || null;
    materialsSelectedKey = key;
    materialsSetForm(rec);
    materialsRenderList();
  }));
}
window.materialsNew = function materialsNew(){
  const st=document.getElementById('materialsStatus');
  if(st) st.textContent='Nieuwe materialen worden uitsluitend via de catalogus-CSV toegevoegd.';
};
window.materialsReload = async function materialsReload(){
  const st=document.getElementById('materialsStatus');
  if(st) st.textContent='Catalogus laden…';
  try{
    const r=await fetch('/api/admin/materials/library',{cache:'no-store'});
    const j=await r.json();
    if(!r.ok||!j.ok) throw new Error(j.error||('HTTP '+r.status));
    materialsCache=Array.isArray(j.records)?j.records:[];
    materialsPopulateFilterOptions();
    const chosen=materialsSelectedKey?materialsCache.find(x=>materialKeyOf(x)===materialsSelectedKey):null;
    if(materialsSelectedKey&&!chosen) materialsSelectedKey='';
    materialsSetForm(chosen||null);
    materialsRenderList();
    const state=document.getElementById('materialsCatalogStateText');
    if(state){
      const li=j?.meta?.lastCatalogImport||null;
      if(materialsCache.length){
        const when=li?.publishedAt?(' · gepubliceerd '+String(li.publishedAt).replace('T',' ').replace('Z',' UTC')):'';
        state.textContent=`${materialsCache.length} CSV-producten actief${when}`;
      }else{
        state.textContent='Nog geen actieve CSV-catalogus. Upload en publiceer hierboven eerst een catalogus.';
      }
    }
    if(st) st.textContent='CSV-only beheer actief.';
  }catch(e){if(st)st.textContent='Fout bij laden: '+(e?.message||e);}
};
window.materialsSave = async function materialsSave(){ throw new Error('Handmatig materiaalbeheer is uitgeschakeld. Publiceer een nieuwe CSV.'); };
window.materialsDelete = async function materialsDelete(){ throw new Error('Handmatig materiaalbeheer is uitgeschakeld. Publiceer een nieuwe CSV.'); };

document.getElementById('matCsvOnlyFamilyOverride')?.addEventListener('change', materialsSaveFamilyOverride);

let materialsCatalogImportId = '';
let materialsCatalogPollTimer = null;
let materialsCatalogCanPublishAfterImages = false;
let materialsCatalogLastPreview = null;
function catalogSummaryBox(value,label,detail){
  return `<div class="admin-u-109"><div class="admin-u-110">${esc(value)}</div><div class="admin-u-111">${esc(label)}</div>${detail?`<div class="muted admin-u-112">${esc(detail)}</div>`:''}</div>`;
}
function materialsCatalogRenderPreview(j){
  materialsCatalogLastPreview=j||materialsCatalogLastPreview;
  const summary=document.getElementById('matCsvSummary');
  const notices=document.getElementById('matCsvNotices');
  const publish=document.getElementById('matCsvPublishBtn');
  const s=j?.summary||{};
  if(summary){
    setAdminRuntimeDisplay(summary, 'grid');
    summary.innerHTML=[
      catalogSummaryBox(s.rowsRead||0,'CSV-regels','gelezen'),
      catalogSummaryBox(s.eligible||0,'Toegelaten','18 / 19 / 20 mm'),
      catalogSummaryBox(s.excludedThickness||0,'Uitgesloten','andere dikte'),
      catalogSummaryBox(s.new||0,'Nieuw','artikel'),
      catalogSummaryBox(s.changed||0,'Gewijzigd','prijs / maat / beeld'),
      catalogSummaryBox(s.unchanged||0,'Ongewijzigd','zelfde brondata'),
      catalogSummaryBox(s.missingFromSource||0,'Niet meer in nieuwe CSV','verdwijnt uit actief'),
      catalogSummaryBox(s.taxonomyVerified||0,'Geclassificeerd','filter + drager'),
      catalogSummaryBox(s.taxonomyReviewRequired||0,'Controle nodig','publicatie geblokkeerd'),
      catalogSummaryBox(s.warnings||0,'Waarschuwingen','controleren')
    ].join('');
  }
  const warnings=Array.isArray(j?.warnings)?j.warnings:[];
  const errors=Array.isArray(j?.errors)?j.errors:[];
  const excluded=Array.isArray(j?.excluded)?j.excluded:[];
  const taxonomyReview=Array.isArray(j?.taxonomyReview)?j.taxonomyReview:[];
  if(notices){
    setAdminRuntimeDisplay(notices, (warnings.length||errors.length||excluded.length||taxonomyReview.length)?'block':'none');
    const section=(title,arr,kind)=>!arr.length?'':`<details class="admin-u-113"${kind==='error'?' open':''}><summary class="admin-u-114">${esc(title)} · ${arr.length}</summary><div class="admin-u-115">${arr.map(x=>`<div class="admin-u-116"><strong>${esc(x.articleNo||('regel '+(x.row||'')))}</strong> · ${esc(x.message||x.reason||'')}</div>`).join('')}</div></details>`;
    const families=Array.isArray(j?.taxonomyFamilies)?j.taxonomyFamilies:['Hout','Uni','Steen & beton','Metaal','Textiel & leer','Grafisch','Fantasie'];
    const substrates=Array.isArray(j?.taxonomySubstrates)?j.taxonomySubstrates:[{value:'MDF',label:'MDF'},{value:'SPAANPLAAT',label:'Spaanplaat'},{value:'MULTIPLEX',label:'Multiplex'},{value:'OVERIG',label:'Overig'}];
    const reviewHtml=!taxonomyReview.length?'':`<details class="admin-u-113" open><summary class="admin-u-117">Classificatie controleren · ${taxonomyReview.length}</summary><div class="muted admin-u-118">Alleen twijfelgevallen verschijnen hier. Publiceren blijft geblokkeerd totdat ieder product één primaire decorfamilie en drager heeft.</div><div class="admin-u-119">${taxonomyReview.map(x=>`<div data-tax-row="${esc(x.articleNo)}" class="admin-u-120"><div class="admin-u-121">${esc(x.productName||x.articleNo)}</div><div class="muted admin-u-112">${esc([x.brand,x.manufacturerCode,x.collection].filter(Boolean).join(' · '))} · ${esc(x.reason||'controle nodig')}</div><div class="admin-u-122"><select data-tax-family>${families.map(v=>`<option value="${esc(v)}"${v===x.suggestedFamily?' selected':''}>${esc(v)}</option>`).join('')}</select><select data-tax-substrate>${substrates.map(v=>`<option value="${esc(v.value)}"${v.value===x.suggestedSubstrate?' selected':''}>${esc(v.label)}</option>`).join('')}</select><button class="btn secondary" type="button" data-tax-save="${esc(x.articleNo)}">Opslaan</button></div></div>`).join('')}</div></details>`;
    notices.innerHTML=section('Blokkerende fouten',errors,'error')+reviewHtml+section('Waarschuwingen',warnings,'warning')+section('Door diktefilter uitgesloten',excluded,'excluded');
    notices.querySelectorAll('[data-tax-save]').forEach(btn=>btn.addEventListener('click',()=>materialsCatalogApplyTaxonomy(btn.getAttribute('data-tax-save'),btn)));
  }
  materialsCatalogCanPublishAfterImages = !!j?.canPublishAfterImages || !!j?.canPublish;
  if(publish) publish.disabled=!j?.canPublish;
}
async function materialsCatalogApplyTaxonomy(articleNo,btn){
  if(!materialsCatalogImportId||!articleNo) return;
  const row=btn?.closest?.('[data-tax-row]');
  const family=row?.querySelector?.('[data-tax-family]')?.value||'';
  const substrate=row?.querySelector?.('[data-tax-substrate]')?.value||'';
  const status=document.getElementById('matCsvStatus');
  try{
    if(btn) btn.disabled=true;
    const r=await fetch('/api/admin/materials/catalog_taxonomy_override',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({importId:materialsCatalogImportId,articleNo,primaryVisualFamily:family,substrateType:substrate})});
    const j=await r.json().catch(()=>({}));
    if(!r.ok||!j.ok) throw new Error(j.error||('HTTP '+r.status));
    const base=materialsCatalogLastPreview||{};
    base.reviewSha256=String(j.reviewSha256||'');
    base.taxonomySummary=j.taxonomySummary||{};
    base.taxonomyReview=j.taxonomyReview||[];
    base.canPublishAfterImages=!!j.canPublishAfterImages;
    base.canPublish=!!j.canPublish;
    base.summary=Object.assign({},base.summary||{}, {
      taxonomyVerified:Number(j.taxonomySummary?.verified||0),
      taxonomyReused:Number(j.taxonomySummary?.reused||0),
      taxonomyAutoVerified:Number(j.taxonomySummary?.autoVerified||0),
      taxonomyAdminVerified:Number(j.taxonomySummary?.adminVerified||0),
      taxonomyReviewRequired:Number(j.taxonomySummary?.reviewRequired||0)
    });
    materialsCatalogCanPublishAfterImages=!!j.canPublishAfterImages;
    materialsCatalogRenderPreview(base);
    if(status) status.textContent=(j.taxonomySummary?.reviewRequired||0)>0
      ? `${j.taxonomySummary.reviewRequired} product(en) moeten nog worden gecontroleerd.`
      : 'Classificatie compleet. Wacht zo nodig nog op de afbeeldingen; daarna kun je publiceren.';
  }catch(e){
    if(status) status.textContent='Classificatie opslaan mislukt: '+(e?.message||e);
    if(btn) btn.disabled=false;
  }
}

async function materialsCatalogPreview(){
  const input=document.getElementById('matCsvInput');
  const status=document.getElementById('matCsvStatus');
  const btn=document.getElementById('matCsvPreviewBtn');
  const pub=document.getElementById('matCsvPublishBtn');
  materialsCatalogImportId='';
  materialsCatalogCanPublishAfterImages=false;
  if(materialsCatalogPollTimer){clearInterval(materialsCatalogPollTimer);materialsCatalogPollTimer=null;}
  if(pub) pub.disabled=true;
  if(!input?.files?.length){ if(status) status.textContent='Kies eerst een CSV-bestand.'; return; }
  const file=input.files[0];
  if(file.size>4*1024*1024){ if(status) status.textContent='CSV is groter dan 4 MB.'; return; }
  if(status) status.textContent='CSV controleren…';
  try{
    if(btn) btn.disabled=true;
    const text=await file.text();
    const r=await fetch('/api/admin/materials/catalog_preview',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({csvText:text})});
    const j=await r.json().catch(()=>({}));
    if(!r.ok||!j.ok) throw new Error(j.error||('HTTP '+r.status));
    materialsCatalogImportId=String(j.importId||'');
    materialsCatalogRenderPreview(j);
    const imageTotal=Number(j.imageSyncTotal||0);
    if(j.canPublish){
      if(status) status.textContent='Controle klaar. Alle benodigde beelden zijn al lokaal beschikbaar; je kunt publiceren.';
      materialsCatalogRenderSync({ok:true,state:'DONE',total:0,processed:0,success:0,failed:0});
    }else if(j.canPublishAfterImages && imageTotal>0){
      if(status) status.textContent=`CSV-data is geldig. ${imageTotal} afbeeldingen worden nu lokaal voorbereid vóór publicatie…`;
      materialsCatalogStartPolling();
    }else{
      const review=Number(j?.taxonomySummary?.reviewRequired||0);
      if(status) status.textContent=review>0
        ? `CSV-data is geldig, maar ${review} product(en) vereisen classificatiecontrole vóór publicatie.`
        : 'Controle klaar, maar er zijn blokkerende fouten.';
    }
  }catch(e){
    if(status) status.textContent='Fout: '+(e?.message||e);
  }finally{ if(btn) btn.disabled=false; }
}
function materialsCatalogRenderSync(st){
  const el=document.getElementById('matCsvImageSync'); if(!el) return;
  setAdminRuntimeDisplay(el, 'block');
  const total=Number(st?.total||0), processed=Number(st?.processed||0), ok=Number(st?.success||0), failed=Number(st?.failed||0);
  const pct=total?Math.min(100,Math.round((processed/total)*100)):100;
  const done=['DONE','DONE_WITH_ERRORS','FAILED'].includes(String(st?.state||''));
  const fullyPrepared=String(st?.state||'')==='DONE' && failed===0 && processed>=total;
  const readyToPublish=!!materialsCatalogCanPublishAfterImages && fullyPrepared && !st?.published;
  const publicationGate=st?.published
    ? `<div class="admin-u-123">Actief gepubliceerd. Tool A gebruikt nu deze catalogus en afbeeldingen.</div>`
    : readyToPublish
      ? `<div class="admin-u-124"><div class="admin-u-125">100% voorbereid, maar nog niet actief in Tool A</div><div class="muted admin-u-126">De beelden staan veilig in staging. Publiceer de catalogus nog expliciet om records en afbeeldingen samen live te zetten.</div><button class="btn admin-u-127" type="button" id="matCsvPublishReadyBtn">Nu catalogus publiceren</button></div>`
      : '';
  el.innerHTML=`<div class="admin-u-128"><strong>Afbeeldingen voorbereiden vóór publicatie</strong><span>${pct}%</span></div><div class="admin-u-129"><div class="catalogProgressValue" data-progress-pct="${pct}"></div></div><div class="muted admin-u-130">${processed} / ${total} verwerkt · ${ok} gelukt · ${failed} mislukt${done?' · klaar':''}</div>${publicationGate}${failed&&done?`<button class="btn secondary admin-u-131" type="button" id="matCsvRetryImagesBtn">Afbeeldingen opnieuw proberen</button>`:''}`;
  const progressValue=el.querySelector('.catalogProgressValue');
  if(progressValue) progressValue.style.width=`${pct}%`;
  const retry=document.getElementById('matCsvRetryImagesBtn'); if(retry) retry.addEventListener('click',materialsCatalogRetryImages);
  const publishReady=document.getElementById('matCsvPublishReadyBtn'); if(publishReady) publishReady.addEventListener('click',materialsCatalogPublish);
}
async function materialsCatalogPollImages(){
  if(!materialsCatalogImportId) return;
  try{
    const r=await fetch('/api/admin/materials/catalog_status?importId='+encodeURIComponent(materialsCatalogImportId),{cache:'no-store'});
    const st=await r.json().catch(()=>({}));
    if(r.ok&&st.ok!==false){
      materialsCatalogRenderSync(st);
      if(['DONE','DONE_WITH_ERRORS','FAILED'].includes(String(st.state||''))){
        if(materialsCatalogPollTimer){clearInterval(materialsCatalogPollTimer);materialsCatalogPollTimer=null;}
        const pub=document.getElementById('matCsvPublishBtn');
        const status=document.getElementById('matCsvStatus');
        const fullyPrepared=String(st.state||'')==='DONE' && Number(st.failed||0)===0 && Number(st.processed||0)>=Number(st.total||0);
        if(pub) pub.disabled=!(materialsCatalogCanPublishAfterImages && fullyPrepared);
        if(status && materialsCatalogCanPublishAfterImages){
          status.textContent=fullyPrepared
            ? '100% voorbereid, maar nog niet actief in Tool A. Klik nu op Catalogus publiceren.'
            : 'Niet alle afbeeldingen konden worden voorbereid. Probeer de mislukte afbeeldingen opnieuw; publiceren blijft geblokkeerd.';
        }
      }
    }
  }catch(_){ }
}
function materialsCatalogStartPolling(){
  if(materialsCatalogPollTimer) clearInterval(materialsCatalogPollTimer);
  materialsCatalogPollTimer=setInterval(materialsCatalogPollImages,2000);
  materialsCatalogPollImages();
}
async function materialsCatalogPublish(){
  const status=document.getElementById('matCsvStatus'); const btn=document.getElementById('matCsvPublishBtn');
  if(!materialsCatalogImportId){ if(status) status.textContent='Controleer eerst de CSV.'; return; }
  const reviewSha256=String(materialsCatalogLastPreview?.reviewSha256||'');
  if(!/^[a-f0-9]{64}$/.test(reviewSha256)){ if(status) status.textContent='Controlebewijs ontbreekt. Controleer de CSV opnieuw.'; return; }
  const warningCount=Number(materialsCatalogLastPreview?.warnings?.length||0);
  const excludedCount=Number(materialsCatalogLastPreview?.excluded?.length||0);
  if(!confirm(`Nieuwe catalogus publiceren en expliciet aftekenen? Je bevestigt ${warningCount} waarschuwing(en) en ${excludedCount} uitgesloten regel(s). De actieve Decor Library wordt exact vervangen door de toegestane 18/19/20-mm producten uit deze CSV. Producten die niet meer in de CSV staan verdwijnen uit Tool A. Er wordt vooraf automatisch een volledige snapshot gemaakt.`)) return;
  try{
    if(btn) btn.disabled=true; if(status) status.textContent='Catalogus veilig publiceren…';
    const r=await fetch('/api/admin/materials/catalog_publish',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({importId:materialsCatalogImportId,reviewSha256})});
    const j=await r.json().catch(()=>({})); if(!r.ok||!j.ok) throw new Error(j.error||('HTTP '+r.status));
    if(status) status.textContent=`Actief in Tool A: ${j.published||0} CSV-producten en ${j.preparedImages||0} voorbereide afbeeldingen gepubliceerd · ${j.excludedThickness||0} door diktefilter uitgesloten · ${j.removedFromActive||0} niet meer in bron verwijderd · snapshot ${j.snapshot||'gemaakt'}.`;
    await materialsReload(); await reloadPricing();
    materialsCatalogCanPublishAfterImages=false;
    materialsCatalogRenderSync({ok:true,state:'DONE',published:true,total:Number(j.preparedImages||0),processed:Number(j.preparedImages||0),success:Number(j.preparedImages||0),failed:0});
  }catch(e){ if(status) status.textContent='Fout: '+(e?.message||e); if(btn) btn.disabled=false; }
}
async function materialsCatalogRetryImages(){
  if(!materialsCatalogImportId) return;
  const status=document.getElementById('matCsvStatus');
  try{
    const r=await fetch('/api/admin/materials/catalog_retry_images',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({importId:materialsCatalogImportId})});
    const j=await r.json().catch(()=>({})); if(!r.ok||!j.ok) throw new Error(j.error||('HTTP '+r.status));
    if(status) status.textContent='Afbeeldingen opnieuw voorbereiden gestart. Publiceren wordt vrijgegeven zodra alles gelukt is.';
    materialsCatalogStartPolling();
  }catch(e){ if(status) status.textContent='Afbeeldingen opnieuw proberen mislukt: '+(e?.message||e); }
}

function materialsResetFilters(){
  const ids = ['materialsFilterThickness','materialsFilterDimension','materialsFilterCategory','materialsFilterBrandText','materialsFilterAvailability'];
  ids.forEach(id=>{ const el=document.getElementById(id); if(el) el.value=''; });
  materialsRenderList();
}
function initMaterialsManager(){
  if(window.__materialsManagerInit) return;
  window.__materialsManagerInit = true;
  const s = document.getElementById('materialsSearch');
  if(s) s.addEventListener('input', ()=>materialsRenderList());
  const toggle = document.getElementById('materialsFiltersToggle');
  if(toggle) toggle.addEventListener('click', ()=>materialsToggleFilters());
  const reset = document.getElementById('materialsResetFiltersBtn');
  if(reset) reset.addEventListener('click', materialsResetFilters);
  ['materialsFilterThickness','materialsFilterDimension','materialsFilterCategory','materialsFilterBrandText','materialsFilterAvailability'].forEach(id=>{
    const el = document.getElementById(id);
    if(el) el.addEventListener(id==='materialsFilterBrandText' ? 'input' : 'change', ()=>materialsRenderList());
  });
  const csvPreview = document.getElementById('matCsvPreviewBtn');
  if(csvPreview) csvPreview.addEventListener('click', materialsCatalogPreview);
  const csvPublish = document.getElementById('matCsvPublishBtn');
  if(csvPublish) csvPublish.addEventListener('click', materialsCatalogPublish);
  const csvInput = document.getElementById('matCsvInput');
  if(csvInput) csvInput.addEventListener('change', ()=>{
    materialsCatalogImportId='';
    materialsCatalogCanPublishAfterImages=false;
    if(materialsCatalogPollTimer){clearInterval(materialsCatalogPollTimer);materialsCatalogPollTimer=null;}
    const pub=document.getElementById('matCsvPublishBtn'); if(pub) pub.disabled=true;
    const status=document.getElementById('matCsvStatus'); if(status) status.textContent=csvInput.files?.length?'CSV gekozen. Klik op “CSV controleren”.':'Nog geen CSV gekozen.';
    const summary=document.getElementById('matCsvSummary'); if(summary){setAdminRuntimeDisplay(summary, 'none');summary.innerHTML='';}
    const notices=document.getElementById('matCsvNotices'); if(notices){setAdminRuntimeDisplay(notices, 'none');notices.innerHTML='';}
  });
  materialsUpdateFiltersToggleLabel();
}

async function loadControlCenter(){
  const el = document.getElementById('ccOut');
  if(!el) return;
  try{
    const r = await fetch('/api/admin/control_center', {cache:'no-store'});
    const j = await r.json();
    const v = j.versions || {};
    const s = j.storage || {};
    const f = j.failures || [];
    const pricing = v.pricing || {};
    const materials = v.materials || {};
    const dxf = v.dxfLibrary || {};
    const opt = v.optimizer || {};
    function fmtBytes(n){
      n = Number(n||0);
      const u=['B','KB','MB','GB','TB']; let i=0;
      while(n>=1024 && i<u.length-1){ n/=1024; i++; }
      return (i===0? String(Math.round(n)) : n.toFixed(1)) + ' ' + u[i];
    }
    let html = '';
    html += `<div class="admin-u-085">`;
    html += `<div><b>Actief nu</b></div>`;
    html += `<div>💶 Prijzen: <code>${pricing.exists? 'pricing_active.json' : '—'}</code> <span class="muted">${pricing.modified?('(' + pricing.modified + ')'):''}</span></div>`;
    html += `<div>🪵 Materialen: <code>${materials.file||'material_library.json'}</code> <span class="muted">${materials.modified?('(' + materials.modified + ')'):''}</span></div>`;
    html += `<div>📐 DXF lijst: <code>${dxf.file||'embedded_dxfs_manifest.json'}</code> <span class="muted">${dxf.modified?('(' + dxf.modified + ')'):''}</span></div>`;
    html += `<div>🧠 Optimizer: <code>${opt.active||'—'}</code></div>`;
    html += `<hr class="admin-u-132">`;
    html += `<div><b>Opslag</b></div>`;
    html += `<div>Jobs: <code>${s.jobsCount??'—'}</code> · Grootte jobs-map: <code>${fmtBytes(s.jobsBytes||0)}</code></div>`;
    if(s.largestJob && s.largestJob.jobId){
      html += `<div>Grootste job: <code>${_h(s.largestJob.jobId)}</code> · <code>${fmtBytes(s.largestJob.bytes||0)}</code></div>`;
    }
    if(f && f.length){
      html += `<hr class="admin-u-132">`;
      html += `<div><b>Laatste fouten</b> <span class="muted">(laatste 5)</span></div>`;
      for(const x of f){
        html += `<div class="admin-u-133">`
             + `<div><code>${_h(x.jobId||'')}</code> <span class="muted">${_h(x.modified||'')}</span></div>`
             + `<div class="muted admin-u-134">${_h(x.excerpt||'')}</div>`
             + `</div>`;
      }
    }else{
      html += `<div class="muted">Geen recente fouten gevonden.</div>`;
    }
    html += `</div>`;
    el.className = '';
    el.innerHTML = html;
  }catch(e){
    el.className = 'muted';
    el.textContent = 'Kon beheer-info niet laden: ' + (e && e.message ? e.message : e);
  }
}

// --- Mailbox (Requests) ---
let mb_tab = 'inbox';
let mb_cache = [];
let mb_openRid = null;
function mb_dotClass(st){
  const pub = String(st.publicStatus||'').toUpperCase();
  const intr = String(st.internalStatus||'').toUpperCase();
  if(pub === 'CANCELLED') return 'gray';
  if(intr === 'FAILED' || pub === 'FAILED' || pub === 'ERROR') return 'red';
  if(pub === 'DONE' || pub === 'AFGEHANDELD') return 'yellow';
  if(pub === 'OFFER_SENT' || pub === 'IN_PRODUCTION' || intr === 'PROCESSING') return 'blue';
  if(pub === 'SUBMITTED') return 'green';
  return 'gray';
}
function mb_statusBadge(label, cls){
  return `<span class="mbBadge ${cls}">${esc(label||'—')}</span>`;
}
function mb_matchesTab(st){
  const pub = String(st.publicStatus||'').toUpperCase();
  const intr = String(st.internalStatus||'').toUpperCase();
  if(mb_tab === 'inbox') return pub === 'SUBMITTED';
  if(mb_tab === 'processing') return (pub === 'OFFER_SENT' || pub === 'IN_PRODUCTION' || intr === 'PROCESSING');
  if(mb_tab === 'errors') return intr === 'FAILED' || pub === 'FAILED' || pub === 'ERROR';
  if(mb_tab === 'afgehandeld') return pub === 'DONE' || pub === 'AFGEHANDELD';
  if(mb_tab === 'alles') return true;
  return true;
}
function mb_matchesSearch(st, q){
  q = String(q||'').trim().toLowerCase();
  if(!q) return true;
  const rid = String(st.requestId||'').toLowerCase();
  const cn = String(st.customer?.name||'').toLowerCase();
  return rid.includes(q) || cn.includes(q);
}
function mb_money(v){ const n = Number(v); return Number.isFinite(n) ? new Intl.NumberFormat('nl-NL',{style:'currency',currency:'EUR'}).format(n) : '—'; }
function mb_formatBytes(v){
  const n = Number(v||0);
  if(!Number.isFinite(n) || n <= 0) return '0 B';
  const units = ['B','KB','MB','GB','TB'];
  let i = 0; let val = n;
  while(val >= 1024 && i < units.length-1){ val /= 1024; i++; }
  const digits = (i === 0 ? 0 : (val >= 100 ? 0 : val >= 10 ? 1 : 2));
  return `${val.toFixed(digits)} ${units[i]}`;
}
function mb_renderStorageSummary(ss){
  if(!ss || typeof ss !== 'object') return '';
  const total = Number(ss.totalBytes||0);
  if(!Number.isFinite(total) || total <= 0) return '';
  const jobs = Number(ss.jobsBytes||0);
  const req = Number(ss.requestBytes||0);
  const bits = [];
  if(jobs > 0) bits.push(`Jobs ${mb_formatBytes(jobs)}`);
  if(req > 0) bits.push(`Request ${mb_formatBytes(req)}`);
  return `<div class="mbSectionTitle">Opslag</div><div class="mbPriceCard"><div class="mbPriceRow emph"><span>Totale jobgrootte</span><strong>${esc(mb_formatBytes(total))}</strong></div><div class="mbFileMeta admin-u-006">${esc(bits.join(' · '))}</div></div>`;
}
function mb_renderPricingSummary(ps){
  if(!ps || typeof ps !== 'object') return '';
  const rows = [];
  const push = (label, val, emph=false) => { if(val===null || val===undefined || val==='') return; rows.push(`<div class="mbPriceRow${emph?' emph':''}"><span>${esc(label)}</span><strong>${esc(mb_money(val))}</strong></div>`); };
  const totalEx = (ps.subtotalExVat!==null && ps.subtotalExVat!==undefined) ? ps.subtotalExVat : null;
  const totalIncl = (ps.totalInclVat!==null && ps.totalInclVat!==undefined) ? ps.totalInclVat : null;
  if(totalEx===null && totalIncl===null) return '';
  push('Plaatmateriaal (CSV, incl. btw)', ps.materialsTotalInclVat, false);
  push('Kantenband (excl. btw)', ps.edgeBandTotal, false);
  push('CNC (excl. btw)', ps.cncTotal, false);
  push('Tekenen (excl. btw)', ps.drawingTotal, false);
  push('Transport (excl. btw)', ps.transportTotal, false);
  push('Fiscaal subtotaal excl. btw', totalEx, false);
  push('Totaal incl. btw', totalIncl, true);
  return `<div class="mbSectionTitle">Prijs</div><div class="mbPriceCard">${rows.join('')}</div>`;
}
function mb_renderFileActions(manifest){
  const parts = [];
  const zip = manifest?.zip || {};
  const pricingSummary = manifest?.pricingSummary || {};
  const storageSummary = manifest?.storageSummary || {};
  const summaryFiles = Array.isArray(manifest?.summaryFiles) ? manifest.summaryFiles : [];
  const groups = Array.isArray(manifest?.dxfGroups) ? manifest.dxfGroups : [];
  const summaryKinds = ['quote','report','placements','stickertool','stickers','summary','pricing'];
  const labels = {quote:'Quote', report:'Report', placements:'Placements', stickers:'Stickers', stickertool:'Stickertool', summary:'Berekening', pricing:'Pricing'};
  parts.push(`<div class="mbSectionTitle">Downloads</div>`);
  parts.push(`<div class="mbFileGrid">`);
  if(zip.allOutputsUrl) parts.push(`<a class="pill premiumPill" download data-stop-propagation="1" href="${esc(zip.allOutputsUrl)}">Alles ZIP</a>`);
  if(zip.allDxfUrl) parts.push(`<a class="pill premiumPill" download data-stop-propagation="1" href="${esc(zip.allDxfUrl)}">Alle DXF's ZIP</a>`);
  for(const kind of summaryKinds){
    const f = summaryFiles.find(x => String(x.kind||'')===kind);
    if(f) parts.push(`<a class="pill premiumPill" download data-stop-propagation="1" href="${esc(f.url||'#')}">${esc(labels[kind]||f.name||kind)}</a>`);
  }
  parts.push(`</div>`);
  parts.push(mb_renderStorageSummary(storageSummary));
  parts.push(mb_renderPricingSummary(pricingSummary));
  parts.push(`<div class="mbSectionTitle">DXF bestanden</div>`);
  if(!groups.length){
    parts.push(`<div class="muted">Geen DXF bestanden gevonden voor deze order.</div>`);
  } else {
    for(const g of groups){
      const glabel = esc(g.label || g.materialName || g.materialCode || g.jobId || 'DXF');
      parts.push(`<div class="mbFileGroup"><div class="mbFileGroupHead">${glabel}</div>`);
      for(const f of (g.files || [])){
        const meta = [];
        if(f.size) meta.push(Math.max(1, Math.round(Number(f.size||0)/1024)) + ' KB');
        if(f.mtime) meta.push(String(f.mtime).replace('T',' ').replace('Z',''));
        parts.push(`<div class="mbFileLine"><div><div class="admin-u-135">${esc(f.downloadName||f.name||'')}</div><div class="mbFileMeta">${esc(meta.join(' · '))}</div></div><a class="pill" download data-stop-propagation="1" href="${esc(f.url||'#')}">Download</a></div>`);
      }
      parts.push(`</div>`);
    }
  }
  return parts.join('');
}

async function mb_loadRequestFiles(rid){
  const box = document.getElementById('mbFilesBox');
  if(!box) return;
  box.innerHTML = `<div class="muted">Bestanden laden…</div>`;
  try{
    const r = await fetch('/api/admin/request_files?requestId=' + encodeURIComponent(rid), {cache:'no-store'});
    const j = await r.json().catch(()=>({}));
    if(!r.ok || !j.ok){
      box.innerHTML = `<div class="muted">Kon bestanden niet laden.</div>`;
      return;
    }
    box.innerHTML = mb_renderFileActions(j.files || {});
  }catch(e){
    box.innerHTML = `<div class="muted">Kon bestanden niet laden.</div>`;
  }
}

function mb_setDetails(st){
  const det = document.getElementById('mbDetails');
  const body = document.getElementById('mbDetailsBody');
  if(!det || !body) return;
  document.querySelectorAll('#mbTbody tr.mbRow').forEach(row=>row.classList.toggle('active', !!st && String(row.getAttribute('data-rid')||'')===String(st.requestId||'')));
  if(!st){
    mb_openRid = null;
    det.open = false;
    setAdminRuntimeDisplay(det, 'none');
    try{ if(location.hash && location.hash.startsWith('#request=')) history.replaceState(null,'',location.pathname + location.search); }catch(e){}
    return;
  }
  mb_openRid = String(st.requestId||'');
  setAdminRuntimeDisplay(det, 'block');
  const err = st.error ? JSON.stringify(st.error, null, 2) : '';
  const job = st.job || {};
  const sj = Array.isArray(job.subjobs) ? job.subjobs : [];
  const customerName = st.customer?.name || '—';
  const dot = mb_dotClass(st);
  const pub = String(st.publicStatusLabel || st.publicStatus || '—');
  const intr = String(st.internalStatusLabel || st.internalStatus || '—');
  const parts = [];
  parts.push(`<div class="mbDetailsCard">`);
  parts.push(`<div class="mbDetailsHead"><div class="admin-u-136">Orderdetails</div><div class="mbBadgeRow">${mb_statusBadge(pub, dot)}${mb_statusBadge(intr, dot==='green'?'gray':dot)}</div></div>`);
  parts.push(`<div class="mbDetailsBody">`);
  parts.push(`<div class="mbInfoGrid">`);
  parts.push(`<div class="mbInfoCard"><div class="mbLabel">Request</div><div class="mbValue mono">${esc(st.requestId||'')}</div></div>`);
  parts.push(`<div class="mbInfoCard"><div class="mbLabel">Klant</div><div class="mbValue">${esc(customerName)}</div>${st.customer?.email ? `<div class="mbFileMeta">${esc(st.customer.email)}</div>` : ``}${st.customer?.phone ? `<div class="mbFileMeta">${esc(st.customer.phone)}</div>` : ``}</div>`);
  parts.push(`<div class="mbInfoCard"><div class="mbLabel">Job</div><div class="mbValue mono">${esc(job.parentJobId||'—')}</div><div class="mbFileMeta">Subjobs: ${esc(String(sj.length||0))}</div></div>`);
  parts.push(`<div class="mbInfoCard"><div class="mbLabel">Aangemaakt</div><div class="mbValue mono">${esc(st.createdAt||'—')}</div></div>`);
  parts.push(`</div>`);
  parts.push(`<div id="mbFilesBox" class="admin-u-023"></div>`);
  if(err){
    parts.push(`<div class="admin-u-023"><div class="mbLabel">Error</div><pre class="admin-u-137">${esc(err)}</pre></div>`);
  }
  parts.push(`</div></div>`);
  body.innerHTML = parts.join('');
  try{ det.open = true; }catch(e){}
  mb_loadRequestFiles(st.requestId||'');
}

async function mb_load(){
  const tb = document.getElementById('mbTbody');
  if(tb) tb.innerHTML = `<tr><td colspan="7" class="muted">laden…</td></tr>`;
  const r = await fetch('/api/admin/requests?limit=500', {cache:'no-store', credentials:'same-origin'});
  const j = await r.json().catch(()=>({}));
  mb_cache = (j.requests || []);
  mb_render();
}
function mb_render(){
  const tb = document.getElementById('mbTbody');
  if(!tb) return;
  const q = document.getElementById('mbSearch')?.value || '';
  const rows = mb_cache.filter(st=>mb_matchesTab(st) && mb_matchesSearch(st, q));
  if(!rows.length){
    tb.innerHTML = `<tr><td colspan="7" class="muted">Geen items</td></tr>`;
    mb_setDetails(null);
    return;
  }
  let html = '';
  for(const st of rows){
    const dot = mb_dotClass(st);
    const rid = esc(st.requestId||'');
    const cn = esc(st.customer?.name||'—');
    const pub = esc(st.publicStatus||'');
    const intr = esc(st.internalStatus||'');
    const created = esc(st.createdAt||'');
    const canMark = (String(st.publicStatus||'').toUpperCase()==='SUBMITTED' && String(st.quoteStatus||'').toUpperCase()==='TODO');
    html += `<tr class="mbRow" data-rid="${rid}">
      <td><span class="dot ${dot}"></span></td>
      <td class="admin-u-135">${rid}</td>
      <td>${cn}</td>
      <td>${mb_statusBadge(pub, dot)}</td>
      <td>${mb_statusBadge(intr, dot==='green'?'gray':dot)}</td>
      <td class="admin-u-017">${created}</td>
      <td>
        ${canMark ? `<button class="mbActionBtn" data-act="sent" data-rid="${rid}" type="button">Aanvraag afhandelen</button>` : ``}
        ${(!canMark && (['AFGEHANDELD','DONE'].includes(String(st.publicStatus||'').toUpperCase()))) ? `<button class="mbActionBtn" data-act="reopen" data-rid="${rid}" type="button">Heropen</button>` : ``}
      </td>
    </tr>`;
  }
  tb.innerHTML = html;
  tb.querySelectorAll('tr.mbRow').forEach(tr=>{
    tr.addEventListener('click', (ev)=>{
      const rid = String(tr.getAttribute('data-rid')||'');
      const details = document.getElementById('mbDetails');
      const isSameOpen = (mb_openRid === rid) && !!details && details.classList.contains('adminRuntimeBlock');
      if(isSameOpen){
        mb_setDetails(null);
        return;
      }
      const st = mb_cache.find(x=>String(x.requestId||'')===rid);
      mb_setDetails(st||null);
      try{ location.hash = 'request=' + rid; }catch(e){}
    });
  });
  tb.querySelectorAll('button[data-act]').forEach(btn=>{
    btn.addEventListener('click', async (ev)=>{
      ev.stopPropagation();
      const rid = btn.getAttribute('data-rid');
      const act = btn.getAttribute('data-act');
      btn.disabled = true;
      const rr = await fetch('/api/admin/requests/update', {method:'POST', credentials:'same-origin', headers:{'Content-Type':'application/json'}, body: JSON.stringify({requestId: rid, action: act==='sent'?'mark_quote_sent':'reopen'})});
      await rr.json().catch(()=>({}));
      await mb_load();
    });
  });
}
function mb_init(){
  const tabs = document.getElementById('mbTabs');
  const search = document.getElementById('mbSearch');
  const ref = document.getElementById('mbRefreshBtn');
  if(tabs && !tabs.__bound){
    tabs.querySelectorAll('button.tabBtn').forEach(b=>{
      b.addEventListener('click', ()=>{
        tabs.querySelectorAll('button.tabBtn').forEach(x=>x.classList.remove('active'));
        b.classList.add('active');
        mb_tab = b.getAttribute('data-tab')||'alles';
        mb_render();
      });
    });
    tabs.__bound=true;
  }
  if(search && !search.__bound){
    search.addEventListener('input', ()=>mb_render());
    search.__bound=true;
  }
  if(ref && !ref.__bound){
    ref.addEventListener('click', ()=>mb_load());
    ref.__bound=true;
  }
  // hash jump
  try{
    if(location.hash && location.hash.startsWith('#request=')){
      const rid = decodeURIComponent(location.hash.replace('#request=',''));
      const st = mb_cache.find(x=>String(x.requestId||'')===rid);
      if(st) mb_setDetails(st);
    }
  }catch(e){}
}

async function load(){
  initAdminShell();
  reloadPricing();
  loadControlCenter();
  initMaterialsManager();
  materialsReload();
  try{ mb_init(); }catch(e){}
  try{ await mb_load(); }catch(e){}
  const r = await fetch('/api/admin/jobs', {cache:'no-store', credentials:'same-origin'});
  const data = await r.json();
  const el = document.getElementById('out');
  if(!data.jobs.length){ el.innerHTML = '<div class="muted">Nog geen jobs.</div>'; return; }
  let html = '<table><thead><tr><th>JobId</th><th>Status</th><th>Created</th><th>Outputs</th></tr></thead><tbody>';
  const childrenMap = {};
  const masters = [];
  const masterSet = new Set();
  for(const jj of data.jobs){
    const id = String(jj.jobId||'');
    if(id.includes('__mat_')){
      const master = id.split('__mat_')[0];
      (childrenMap[master] = childrenMap[master] || []).push(jj);
    }else{
      masters.push(jj);
      masterSet.add(id);
    }
  }

  function safeKey(s){
    return String(s||'').replace(/[^a-zA-Z0-9_-]/g,'_');
  }

  function sealedMetaLinks(j){
    const files=(j.sealedFiles||[]).filter(f=>String(f.kind||'')!=='dxf');
    return files.map(f=>{
      const rel=String(f.rel||'');
      const name=String(f.name||rel||'bestand');
      const url=`/api/jobs/${encodeURIComponent(j.jobId)}/file/${encodeURIComponent(rel)}`;
      if(name==='calculation_summary.txt'){
        return `<a class="btn admin-u-138" href="${url}" download>Berekening</a>`
             + `<button class="btn secondary admin-u-139" type="button" data-open-text-url="${esc(url)}" data-open-text-title="Berekening">Bekijk</button>`;
      }
      if(name==='stickertool.json'){
        return `<a class="btn admin-u-140" href="${url}" download>stickertool.json (v2)</a>`;
      }
      return `<a class="btn secondary admin-u-139" href="${url}" download>${esc(name)}</a>`;
    }).join('');
  }

  for(const j of masters){
    const jid = String(j.jobId||'');
    const gkey = safeKey(jid);
    const kids0 = (childrenMap[j.jobId]||[]);
    const kids = kids0.sort((a,b)=>String(a.jobId||'').localeCompare(String(b.jobId||'')));
    const kidCount = kids.length;

	    const dlZaag = j.zaagplaten && j.zaagplaten.length
	      ? j.zaagplaten.map(z=>{
	          const f=_zaagFile(z), t=_zaagLabel(z);
	          return `<a class="btn admin-u-141" href="/api/jobs/${encodeURIComponent(j.jobId)}/file/${encodeURIComponent('output/DXF_Zaagplaten/' + f)}">${t}</a>`;
	        }).join('')
	      : '';
    const dlParts = j.onderdelen && j.onderdelen.length
      ? j.onderdelen.map(s=>`<a class="btn admin-u-141" href="/api/jobs/${encodeURIComponent(j.jobId)}/file/${encodeURIComponent('output/DXF_Onderdelen/' + s)}">${esc(s)}</a>`).join('')
      : '';
    const dlSheetsFallback = j.sheets && j.sheets.length
      ? j.sheets.map(s=>`<a class="btn admin-u-141" href="/api/jobs/${encodeURIComponent(j.jobId)}/download/${encodeURIComponent(s)}">${esc(s)}</a>`).join('')
      : '';
    const dlSheets = (dlZaag || dlParts)
      ? (`<div class="admin-u-142"><span class="muted">Zaagplaten:</span> ${dlZaag || '<span class=\"muted\">—</span>'}</div>`
         + `<div><span class="muted">Onderdelen:</span> ${dlParts || '<span class=\"muted\">—</span>'}</div>`)
      : (dlSheetsFallback || '<span class="muted">—</span>');

    const dlMeta = sealedMetaLinks(j);

    
    const edgeDecor = j.edgeBandByDecorMeters || {};
    let edgeHtml = '';
    try{
      const keys = Object.keys(edgeDecor||{});
      if(keys.length){
        edgeHtml = '<div class="admin-u-143"><div class="muted admin-u-144">Kantenband per decor (m):</div>'
          + keys.map(k=>`<div class="admin-u-145"><div class="admin-u-146">${esc(k)}</div><div>${Number(edgeDecor[k]||0).toFixed(2)}</div></div>`).join('')
          + `<div class="admin-u-147"><div class="admin-u-148">Totaal</div><div>${keys.reduce((a,k)=>a+Number(edgeDecor[k]||0),0).toFixed(2)}</div></div>`
          + '</div>';
      }
    }catch(e){}

    const _cntZaag = (j.zaagplaten&&j.zaagplaten.length)?j.zaagplaten.length:0;
    const _cntOnd = (j.onderdelen&&j.onderdelen.length)?j.onderdelen.length:0;
    const _cntMeta = (j.sealedFiles||[]).filter(f=>String(f.kind||'')!=='dxf').length;
    const _sum = `DXF: ${_cntZaag+_cntOnd} · Overig: ${_cntMeta}`;
    const _body = `<div class="jobOutBody admin-u-149">${dlSheets}${dlMeta}</div>` + edgeHtml;
    const dl = `<details class="jobOut"><summary>${_sum}</summary>${_body}</details>`;
    const toggleBtn = kidCount
      ? `<button class="groupToggle" type="button" data-group="${gkey}" aria-expanded="false">▸</button>`
      : `<span class="admin-u-150"></span>`;
    const kidBadge = kidCount ? `<span class="muted admin-u-151">(${kidCount} materiaal)</span>` : '';
    html += `<tr class="masterRow" data-group="${gkey}"><td><div class="admin-u-152">${toggleBtn}<code>${_jobLabel(j)}</code>${kidBadge}</div></td><td>${esc(j.status||'')}</td><td class="muted">${esc(j.createdAt||'')}</td><td class="outputsTd"><div class="outputsCell">${dl}</div></td></tr>`;
    for(const c of kids){
      // reuse dl generation by temporarily mapping j->c
      const j = c;
      const masterJobId = jid;

	  const hasZaag = !!(j.zaagplaten && j.zaagplaten.length);
	      const dlZaag = j.zaagplaten && j.zaagplaten.length
	        ? j.zaagplaten.map(z=>{
	            const f=_zaagFile(z), t=_zaagLabel(z);
	            return `<a class="btn admin-u-141" href="/api/jobs/${encodeURIComponent(j.jobId)}/file/${encodeURIComponent('output/DXF_Zaagplaten/' + f)}">${t}</a>`;
	          }).join('')
	        : '';
      const dlParts = j.onderdelen && j.onderdelen.length
        ? j.onderdelen.map(s=>`<a class="btn admin-u-141" href="/api/jobs/${encodeURIComponent(j.jobId)}/file/${encodeURIComponent('output/DXF_Onderdelen/' + s)}">${esc(s)}</a>`).join('')
        : '';
      const dlSheetsFallback = j.sheets && j.sheets.length
        ? j.sheets.map(s=>`<a class="btn admin-u-141" href="/api/jobs/${encodeURIComponent(j.jobId)}/download/${encodeURIComponent(s)}">${esc(s)}</a>`).join('')
        : '';
      const partsCount = (j.onderdelen && j.onderdelen.length) ? j.onderdelen.length : 0;
      const partsBlock = partsCount
        ? (`<details>`
            + `<summary class="muted">Onderdelen (${partsCount})</summary>`
            + `<div class="admin-u-153">${dlParts}</div>`
          + `</details>`)
        : (`<div><span class="muted">Onderdelen:</span> <span class="muted">—</span></div>`);

      const dlSheets = (dlZaag || dlParts)
        ? (`<div class="admin-u-142"><span class="muted">Zaagplaten:</span> <div class="admin-u-153">${dlZaag || '<span class=\"muted\">—</span>'}</div></div>`
           + partsBlock)
        : (dlSheetsFallback || '<span class="muted">—</span>');
      const dlMeta = sealedMetaLinks(j);
      const _cntZaag = (j.zaagplaten&&j.zaagplaten.length)?j.zaagplaten.length:0;
      const _cntOnd = (j.onderdelen&&j.onderdelen.length)?j.onderdelen.length:0;
      const _cntMeta = (j.sealedFiles||[]).filter(f=>String(f.kind||'')!=='dxf').length;
      const _sum = `DXF: ${_cntZaag+_cntOnd} · Overig: ${_cntMeta}`;
      const _body = `<div class="jobOutBody admin-u-149">${dlSheets}${dlMeta}</div>`;
      const dl = `<details class="jobOut ${hasZaag?'zaagHi':''}"><summary>${_sum}</summary>${_body}</details>`;
      html += `<tr class="childRow ${hasZaag?'zaagRow':''} admin-u-154" data-parent="${gkey}"><td><span class="jobIndent"><span class="arrow">↳</span><code>${_jobLabel(j)}</code></span></td><td>${esc(j.status||'')}</td><td class="muted">${esc(j.createdAt||'')}</td><td class="outputsTd"><div class="outputsCell">${dl}</div></td></tr>`;
    }

  }
  html += '</tbody></table>';
  el.innerHTML = html;

  el.querySelectorAll('[data-open-text-url]').forEach(btn=>{
    btn.addEventListener('click', (e)=>{
      e.preventDefault();
      e.stopPropagation();
      openTextModal(btn.getAttribute('data-open-text-url') || '', btn.getAttribute('data-open-text-title') || 'Bestand');
    });
  });

  // toggle groups
  function setGroupVisible(groupKey, visible){
    const rows = el.querySelectorAll(`tr.childRow[data-parent="${groupKey}"]`);
    rows.forEach(r=>setAdminRuntimeDisplay(r, visible ? 'table-row' : 'none'));
    const btn = el.querySelector(`button.groupToggle[data-group="${groupKey}"]`);
    if(btn){
      btn.textContent = visible ? '▾' : '▸';
      btn.setAttribute('aria-expanded', visible ? 'true' : 'false');
    }
  }
  el.querySelectorAll('button.groupToggle').forEach(btn=>{
    btn.addEventListener('click', (e)=>{
      e.preventDefault();
      e.stopPropagation();
      const k = btn.getAttribute('data-group');
      const expanded = btn.getAttribute('aria-expanded')==='true';
      setGroupVisible(k, !expanded);
    });
  });
}
load();
  loadControlCenter();

function openTextModal(url, title){
  const m = document.getElementById('textModal');
  const t = document.getElementById('textModalTitle');
  const b = document.getElementById('textModalBody');
  const dl = document.getElementById('textModalDownload');
  if(!m||!t||!b||!dl) return;
  t.textContent = title || 'Bestand';
  b.textContent = 'Laden…';
  dl.href = url;
  setAdminRuntimeDisplay(m, 'flex');
  fetch(url).then(r=>r.text()).then(txt=>{ b.textContent = txt; }).catch(()=>{ b.textContent='Kon bestand niet laden.'; });
}
function closeTextModal(){
  const m = document.getElementById('textModal');
  setAdminRuntimeDisplay(m, 'none');
}
document.addEventListener('keydown', (e)=>{ if(e.key==='Escape') closeTextModal(); });
document.addEventListener('click', (e)=>{
  const stop=e.target.closest('[data-stop-propagation="1"]');
  if(stop) e.stopPropagation();
  const trigger=e.target.closest('[data-admin-action]');
  if(!trigger) return;
  const action=trigger.getAttribute('data-admin-action');
  const allowed=new Set(['materialsReload','savePricing','reloadPricing','refreshSystemPage','createSystemBackup','load']);
  if(allowed.has(action) && typeof window[action]==='function') window[action]();
});
document.getElementById('adminLogoutBtn')?.addEventListener('click', async ()=>{
  try {
    await fetch('/api/admin/logout', {method:'POST', credentials:'same-origin', headers:{'X-Requested-With':'fetch'}});
  } finally {
    window.location.replace('/admin/');
  }
});

  try { window.load = load; } catch(e) {}
}
