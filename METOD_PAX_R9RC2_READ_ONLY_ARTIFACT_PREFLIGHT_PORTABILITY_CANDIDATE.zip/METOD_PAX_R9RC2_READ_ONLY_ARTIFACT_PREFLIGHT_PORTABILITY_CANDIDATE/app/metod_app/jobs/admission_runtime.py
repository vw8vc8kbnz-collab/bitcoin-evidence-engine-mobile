from __future__ import annotations

"""Bounded JobAdmissionRuntime implementation with explicit runtime injection."""

class JobAdmissionRuntime:
    def __init__(self, runtime):
        self._runtime = runtime

    def _public_job_queue_limits(_owner) -> tuple[int, int, int]:
        """Return bounded optimizer worker, waiting-room and per-IP limits."""
        runtime = _owner._runtime
        _bounded_public_job_queue_limits = runtime._bounded_public_job_queue_limits
        _env_int = runtime._env_int

    
        return _bounded_public_job_queue_limits(_env_int)


    def _decrement_public_job_ip_locked(_owner, ip: str) -> None:
        runtime = _owner._runtime
        _PUBLIC_JOB_ADMISSION = runtime._PUBLIC_JOB_ADMISSION
        _sync_public_job_admission_legacy_counters = runtime._sync_public_job_admission_legacy_counters

        _PUBLIC_JOB_ADMISSION.decrement_ip_locked(ip)
        _sync_public_job_admission_legacy_counters()


    def _refresh_public_job_queue_meta_locked(_owner, 
        starting: list[dict[str, Any]],
        queued: list[dict[str, Any]],
    ) -> None:
        """Synchronize volatile UI phases while the scheduler lock is held.
    
        Durable queued jobs deliberately remain ACCEPTED.  A restart therefore uses
        the existing interrupted-job reconciliation and cannot silently lose work.
        """
        runtime = _owner._runtime
        Any = runtime.Any
        _job_lock = runtime._job_lock
        _job_meta = runtime._job_meta
        _now_iso = runtime._now_iso

    
        with _job_lock:
            for item in starting:
                job_id = str(item.get('jobId') or '')
                meta = _job_meta.get(job_id, {}) or {}
                meta.update({
                    'status': 'processing',
                    'phase': 'worker_start',
                    'progressPct': max(1, int(meta.get('progressPct') or 0)),
                    'progressMessage': 'Optimalisatie wordt gestart…',
                    'queuePosition': 0,
                    'workerStartedAt': _now_iso(),
                })
                _job_meta[job_id] = meta
            for position, item in enumerate(queued, start=1):
                job_id = str(item.get('jobId') or '')
                meta = _job_meta.get(job_id, {}) or {}
                meta.update({
                    'status': 'queued',
                    'phase': 'queued',
                    'progressPct': max(1, int(meta.get('progressPct') or 0)),
                    'progressMessage': f'Wachtrij: positie {position}',
                    'queuePosition': position,
                })
                _job_meta[job_id] = meta


    def _launch_public_job_item(_owner, item: dict[str, Any]) -> None:
        runtime = _owner._runtime
        Any = runtime.Any
        _finish_public_job_slot = runtime._finish_public_job_slot
        _job_lock = runtime._job_lock
        _job_meta = runtime._job_meta
        _now_iso = runtime._now_iso
        _save_job_runtime_state = runtime._save_job_runtime_state
        threading = runtime.threading

        job_id = str(item.get('jobId') or '')
        runner = item.get('runner')
    
        def _scheduled_runner() -> None:
            try:
                if not callable(runner):
                    raise RuntimeError('Optimizer queue item has no runner')
                runner()
            except Exception as exc:
                # Normal API runners already persist their own failure.  This fallback
                # covers scheduler/runner contract failures without stranding a slot.
                try:
                    _save_job_runtime_state(job_id, 'FAILED', reason=str(exc)[:500], retryable=True)
                except Exception:
                    pass
                try:
                    with _job_lock:
                        meta = _job_meta.get(job_id, {}) or {}
                        meta.update({'status': 'error', 'phase': 'failed', 'error': str(exc), 'finishedAt': _now_iso()})
                        _job_meta[job_id] = meta
                except Exception:
                    pass
            finally:
                _finish_public_job_slot(job_id)
    
        try:
            threading.Thread(
                target=_scheduled_runner,
                daemon=True,
                name=f'job-create-{job_id}',
            ).start()
        except Exception as exc:
            try:
                _save_job_runtime_state(job_id, 'FAILED', reason=f'worker-start-failed: {exc}'[:500], retryable=True)
            except Exception:
                pass
            with _job_lock:
                meta = _job_meta.get(job_id, {}) or {}
                meta.update({'status': 'error', 'phase': 'failed', 'error': 'Optimizerworker kon niet starten', 'finishedAt': _now_iso()})
                _job_meta[job_id] = meta
            _finish_public_job_slot(job_id)


    def _try_acquire_public_job_slot(_owner, ip: str) -> tuple[bool, str]:
        """Reserve admission for one validated-or-being-validated public request.
    
        The reservation is included in both the global and per-IP cap, preventing
        concurrent HTTP handlers from overfilling the bounded queue before their
        durable ACCEPTED record has been written.
        """
        runtime = _owner._runtime
        _PUBLIC_JOB_ADMISSION = runtime._PUBLIC_JOB_ADMISSION
        _env_int = runtime._env_int
        _sync_public_job_admission_legacy_counters = runtime._sync_public_job_admission_legacy_counters

    
        result = _PUBLIC_JOB_ADMISSION.try_acquire(ip, env_int=_env_int)
        _sync_public_job_admission_legacy_counters()
        return result


    def _release_public_job_slot(_owner, ip: str) -> None:
        """Release an admission reservation that never reached the FIFO queue."""
        runtime = _owner._runtime
        _PUBLIC_JOB_ADMISSION = runtime._PUBLIC_JOB_ADMISSION
        _sync_public_job_admission_legacy_counters = runtime._sync_public_job_admission_legacy_counters

    
        _PUBLIC_JOB_ADMISSION.release_reservation(ip)
        _sync_public_job_admission_legacy_counters()


    def _commit_public_job_slot(_owner, ip: str, job_id: str, runner) -> dict[str, Any]:
        """Commit a reservation and start or FIFO-queue its optimizer runner."""
        runtime = _owner._runtime
        Any = runtime.Any
        _PUBLIC_JOB_SCHEDULER = runtime._PUBLIC_JOB_SCHEDULER
        _launch_public_job_item = runtime._launch_public_job_item
        _refresh_public_job_queue_meta_locked = runtime._refresh_public_job_queue_meta_locked
        _sync_public_job_scheduler_legacy_state = runtime._sync_public_job_scheduler_legacy_state
        validate_job_id = runtime.validate_job_id

    
        ip = str(ip or '?')
        result, starting = _PUBLIC_JOB_SCHEDULER.commit(
            ip=ip,
            job_id=validate_job_id(job_id),
            runner=runner,
            refresh_meta=_refresh_public_job_queue_meta_locked,
            state_changed=_sync_public_job_scheduler_legacy_state,
        )
        for start_item in starting:
            _launch_public_job_item(start_item)
        return result


    def _finish_public_job_slot(_owner, job_id: str) -> bool:
        """Release one job-owned worker slot exactly once and promote FIFO work.
    
        Cancellation runs in an HTTP thread while the scheduled runner unwinds in a
        different thread.  A bare counter decrement lets both paths release the same
        slot, or leaves the slot occupied until slow cleanup completes.  The active
        job map is the ownership record: only the path that removes that job may
        decrement admission counters and promote queued work.
        """
        runtime = _owner._runtime
        _PUBLIC_JOB_SCHEDULER = runtime._PUBLIC_JOB_SCHEDULER
        _launch_public_job_item = runtime._launch_public_job_item
        _refresh_public_job_queue_meta_locked = runtime._refresh_public_job_queue_meta_locked
        _release_state_capacity_reservation = runtime._release_state_capacity_reservation
        _sync_public_job_scheduler_legacy_state = runtime._sync_public_job_scheduler_legacy_state
        validate_job_id = runtime.validate_job_id

    
        try:
            job_id = validate_job_id(job_id)
        except Exception:
            return False
        released, starting = _PUBLIC_JOB_SCHEDULER.finish(
            job_id=job_id,
            refresh_meta=_refresh_public_job_queue_meta_locked,
            state_changed=_sync_public_job_scheduler_legacy_state,
        )
        if not released:
            return False
        _release_state_capacity_reservation(job_id)
        for start_item in starting:
            _launch_public_job_item(start_item)
        return True


    def _cancel_queued_public_job(_owner, job_id: str) -> bool:
        """Remove a not-yet-started job and free its admission atomically."""
        runtime = _owner._runtime
        _PUBLIC_JOB_SCHEDULER = runtime._PUBLIC_JOB_SCHEDULER
        _refresh_public_job_queue_meta_locked = runtime._refresh_public_job_queue_meta_locked
        _release_state_capacity_reservation = runtime._release_state_capacity_reservation
        _sync_public_job_scheduler_legacy_state = runtime._sync_public_job_scheduler_legacy_state
        validate_job_id = runtime.validate_job_id

    
        job_id = validate_job_id(job_id)
        cancelled = _PUBLIC_JOB_SCHEDULER.cancel_queued(
            job_id=job_id,
            refresh_meta=_refresh_public_job_queue_meta_locked,
            state_changed=_sync_public_job_scheduler_legacy_state,
        )
        if cancelled:
            _release_state_capacity_reservation(job_id)
        return cancelled


    def _catalog_review_sha256(_owner, stage: dict) -> str:
        """Bind an Admin approval to the exact CSV, warnings and normalized records."""
        runtime = _owner._runtime
        SafetyContractError = runtime.SafetyContractError
        hashlib = runtime.hashlib
        strict_json_dumps = runtime.strict_json_dumps

    
        if not isinstance(stage, dict):
            raise SafetyContractError('Invalid catalog review')
        records = stage.get('records') if isinstance(stage.get('records'), list) else []
        review = {
            'schemaVersion': 1,
            'csvSha256': str(stage.get('csvSha256') or ''),
            'warnings': stage.get('warnings') if isinstance(stage.get('warnings'), list) else [],
            'excluded': stage.get('excluded') if isinstance(stage.get('excluded'), list) else [],
            'errors': stage.get('errors') if isinstance(stage.get('errors'), list) else [],
            'summary': stage.get('summary') if isinstance(stage.get('summary'), dict) else {},
            'taxonomySummary': stage.get('taxonomySummary') if isinstance(stage.get('taxonomySummary'), dict) else {},
            'recordsSha256': hashlib.sha256(strict_json_dumps(records).encode('utf-8')).hexdigest(),
        }
        return hashlib.sha256(strict_json_dumps(review).encode('utf-8')).hexdigest()

    EXPORTS = ('_public_job_queue_limits', '_decrement_public_job_ip_locked', '_refresh_public_job_queue_meta_locked', '_launch_public_job_item', '_try_acquire_public_job_slot', '_release_public_job_slot', '_commit_public_job_slot', '_finish_public_job_slot', '_cancel_queued_public_job', '_catalog_review_sha256')

__all__ = ("JobAdmissionRuntime",)
