from __future__ import annotations

"""Finalization, artifact sealing and public family-readiness ownership.

All filesystem primitives and product-specific artifact generators are injected
by the composition root.  The optimizer and pricing calculations remain outside
this module; this owner only verifies their evidence and controls publication.
"""

import hmac
from typing import Any, Callable


class JobFinalizationService:
    def __init__(
        self,
        *,
        jobs_root: Any,
        safety_error: type[Exception],
        validate_job_id: Callable[[Any], str],
        resolve_identifier_child: Callable[..., Any],
        resolve_relative_file: Callable[[Any, str], Any],
        read_json: Callable[[Any], Any],
        cached_sha256_file: Callable[[Any], str],
        parse_panels_csv: Callable[[str], list[dict[str, Any]]],
        input_dxf_source_map: Callable[[Any, set[str]], dict[str, Any]],
        link_or_copy_file: Callable[[Any, Any], str],
        fsync_directory: Callable[[Any], None],
        generate_labels: Callable[[Any], Any],
        generate_stickertool: Callable[[Any], Any],
        write_calculation_summary: Callable[..., Any],
        durable_write_json: Callable[[Any, Any], None],
        atomic_write_json: Callable[[Any, Any], None],
        load_runtime_state: Callable[[str], dict[str, Any]],
        utc_now_iso: Callable[[], str],
    ) -> None:
        self.jobs_root = jobs_root
        self.safety_error = safety_error
        self.validate_job_id = validate_job_id
        self.resolve_identifier_child = resolve_identifier_child
        self.resolve_relative_file = resolve_relative_file
        self.read_json = read_json
        self.cached_sha256_file = cached_sha256_file
        self.parse_panels_csv = parse_panels_csv
        self.input_dxf_source_map = input_dxf_source_map
        self.link_or_copy_file = link_or_copy_file
        self.fsync_directory = fsync_directory
        self.generate_labels = generate_labels
        self.generate_stickertool = generate_stickertool
        self.write_calculation_summary = write_calculation_summary
        self.durable_write_json = durable_write_json
        self.atomic_write_json = atomic_write_json
        self.load_runtime_state = load_runtime_state
        self.utc_now_iso = utc_now_iso

    def _verify_hashes(self, root: Any, mapping: Any, label: str) -> dict[str, str]:
        if not isinstance(mapping, dict) or not mapping:
            raise self.safety_error(f"{label} hash map is empty")
        verified: dict[str, str] = {}
        for relative, expected in sorted(mapping.items()):
            path = self.resolve_relative_file(root, str(relative))
            if not path.is_file():
                raise self.safety_error(f"{label} file missing: {relative}")
            actual = self.cached_sha256_file(path)
            if not hmac.compare_digest(actual, str(expected)):
                raise self.safety_error(f"{label} hash mismatch: {relative}")
            verified[str(relative)] = actual
        return verified

    def finalize_subjob(self, job_root: Any) -> dict[str, Any]:
        """Verify optimizer evidence and atomically publish a subjob manifest."""

        self.validate_job_id(job_root.name)
        if job_root.resolve().parent != self.jobs_root.resolve():
            raise self.safety_error("Subjob root is outside the fixed jobs root")
        input_dir = job_root / "input"
        output_dir = job_root / "output"
        final_path = output_dir / "finalization.json"
        result: dict[str, Any] = {
            "schemaVersion": 2,
            "build": "FIX660R8_PRELIVE_HARDENED",
            "jobId": job_root.name,
            "state": "FINALIZING",
            "startedAt": self.utc_now_iso(),
            "errors": [],
        }
        try:
            report_path = output_dir / "report.json"
            optimizer_manifest_path = output_dir / "optimizer_manifest.json"
            placements_path = output_dir / "placements.json"
            quote_path = output_dir / "quote.json"
            for path in (report_path, optimizer_manifest_path, placements_path, quote_path):
                if not path.is_file() or path.stat().st_size <= 0:
                    raise self.safety_error(f"Required optimizer artifact missing: {path.name}")

            report = self.read_json(report_path)
            optimizer_manifest = self.read_json(optimizer_manifest_path)
            placements_obj = self.read_json(placements_path)
            self.read_json(quote_path)
            if not isinstance(report, dict) or report.get("ok") is not True:
                raise self.safety_error("Optimizer report is not an explicit success")
            if report.get("optimizerManifestSha256") != self.cached_sha256_file(optimizer_manifest_path):
                raise self.safety_error("Optimizer manifest hash does not match report")
            if not isinstance(optimizer_manifest, dict) or optimizer_manifest.get("release") != "FIX660R8":
                raise self.safety_error("Unexpected optimizer manifest release")

            verified_inputs = self._verify_hashes(
                input_dir, optimizer_manifest.get("inputsSha256"), "input"
            )
            verified_outputs = self._verify_hashes(
                output_dir, optimizer_manifest.get("outputsSha256"), "output"
            )
            rows = self.parse_panels_csv(
                (input_dir / "panels.csv").read_text(encoding="utf-8", errors="strict")
            )
            placements = placements_obj.get("placements") if isinstance(placements_obj, dict) else None
            if not isinstance(placements, list):
                raise self.safety_error("placements.json has no placements list")
            expected_identities = {
                (str(row["PartId"]), index)
                for row in rows
                for index in range(1, int(row["Qty"]) + 1)
            }
            actual_identities = {
                (str(item.get("partId") or ""), int(item.get("instanceIndex") or 0))
                for item in placements
                if isinstance(item, dict)
            }
            if len(actual_identities) != len(placements) or actual_identities != expected_identities:
                raise self.safety_error("Final placements do not exactly match requested instances")

            manifest_counts = (
                optimizer_manifest.get("counts")
                if isinstance(optimizer_manifest.get("counts"), dict)
                else {}
            )
            expected_sheets = int(manifest_counts.get("productionSheets") or 0)
            if expected_sheets <= 0:
                raise self.safety_error("Optimizer manifest reports no production sheets")
            sheet_files = sorted((output_dir / "sheets").glob("*.dxf"))
            mirrored_sheets = sorted((output_dir / "DXF_Zaagplaten").glob("*.dxf"))
            if len(sheet_files) != expected_sheets or len(mirrored_sheets) != expected_sheets:
                raise self.safety_error("Exact sheet DXF count mismatch")
            if len(report.get("sheetValidation") or []) != expected_sheets:
                raise self.safety_error("Sheet geometry validation evidence count mismatch")

            parts_export = output_dir / "DXF_Onderdelen"
            parts_export.mkdir(parents=True, exist_ok=True)
            expected_part_names = {f"{row['PartId']}.dxf" for row in rows}
            part_sources = self.input_dxf_source_map(
                input_dir, {str(row["PartId"]) for row in rows}
            )
            existing_part_names = {path.name for path in parts_export.glob("*.dxf")}
            if existing_part_names - expected_part_names:
                raise self.safety_error("Unexpected file in DXF_Onderdelen")
            linked_part_directory_dirty = False
            for row in rows:
                part_name = f"{row['PartId']}.dxf"
                source = part_sources[str(row["PartId"])]
                destination = parts_export / part_name
                link_mode = self.link_or_copy_file(source, destination)
                if link_mode == "hardlink":
                    source_stat = source.stat()
                    destination_stat = destination.stat()
                    if (source_stat.st_dev, source_stat.st_ino) != (
                        destination_stat.st_dev,
                        destination_stat.st_ino,
                    ):
                        raise self.safety_error(
                            f"{part_name}: DXF_Onderdelen hardlink identity mismatch"
                        )
                    linked_part_directory_dirty = True
                elif self.cached_sha256_file(source) != self.cached_sha256_file(destination):
                    raise self.safety_error(f"{part_name}: DXF_Onderdelen hash mismatch")
            if linked_part_directory_dirty:
                self.fsync_directory(parts_export)

            labels_path = self.generate_labels(job_root)
            self.generate_stickertool(job_root)
            stickertool_path = output_dir / "stickertool.json"
            labels_obj = self.read_json(labels_path)
            sticker_obj = self.read_json(stickertool_path)
            label_count = len(labels_obj.get("labels") or []) if isinstance(labels_obj, dict) else 0
            sticker_items = sticker_obj.get("items") if isinstance(sticker_obj, dict) else None
            sticker_count = len(sticker_items) if isinstance(sticker_items, list) else 0
            if label_count != len(expected_identities) or sticker_count != len(expected_identities):
                raise self.safety_error("Label/StickerTool count does not match requested instances")
            expected_sticker_ids = {
                f"{part_id}__{instance}" for part_id, instance in expected_identities
            }
            actual_sticker_ids = {
                str(item.get("partId") or "")
                for item in sticker_items
                if isinstance(item, dict)
            }
            if len(actual_sticker_ids) != sticker_count or actual_sticker_ids != expected_sticker_ids:
                raise self.safety_error("StickerTool identities do not exactly match requested instances")
            material_codes = {
                str(row.get("MaterialCode") or "").strip()
                for row in rows
                if str(row.get("MaterialCode") or "").strip()
            }
            if len(material_codes) != 1 or str(sticker_obj.get("materialCode") or "").strip() not in material_codes:
                raise self.safety_error("StickerTool material does not match the subjob input")

            self.write_calculation_summary(job_root, request_status={})
            summary_path = output_dir / "calculation_summary.txt"
            if not summary_path.is_file() or summary_path.stat().st_size <= 0:
                raise self.safety_error("Authoritative calculation summary is missing")
            production_paths = (
                [
                    report_path,
                    optimizer_manifest_path,
                    placements_path,
                    quote_path,
                    labels_path,
                    stickertool_path,
                    summary_path,
                ]
                + sheet_files
                + mirrored_sheets
                + sorted(parts_export.glob("*.dxf"))
            )
            artifact_hashes = {
                path.relative_to(output_dir).as_posix(): self.cached_sha256_file(path)
                for path in sorted(set(production_paths), key=lambda item: item.as_posix())
            }
            result.update({
                "state": "COMPLETE",
                "finishedAt": self.utc_now_iso(),
                "counts": {
                    "panelRows": len(rows),
                    "instances": len(expected_identities),
                    "placements": len(placements),
                    "sheetDxfs": len(sheet_files),
                    "mirroredSheetDxfs": len(mirrored_sheets),
                    "partDxfs": len(expected_part_names),
                    "labels": label_count,
                    "stickerItems": sticker_count,
                },
                "optimizerManifestSha256": self.cached_sha256_file(optimizer_manifest_path),
                "verifiedInputHashes": verified_inputs,
                "verifiedOptimizerOutputHashes": verified_outputs,
                "artifactsSha256": artifact_hashes,
            })
            self.durable_write_json(final_path, result)
            return result
        except Exception as exc:
            result.update({
                "state": "ERROR",
                "finishedAt": self.utc_now_iso(),
                "errors": [str(exc)[:1000]],
            })
            self.durable_write_json(final_path, result)
            raise

    def seal_master(
        self,
        *,
        master_root: Any,
        subjobs: list[dict[str, Any]],
        finalized_subjob_hashes: dict[str, str],
    ) -> dict[str, Any]:
        output_root = master_root / "output"
        try:
            self.write_calculation_summary(master_root, request_status={})
            if not (
                (output_root / "calculation_summary.txt").exists()
                or (master_root / "input" / "calculation_summary.txt").exists()
                or (master_root / "calculation_summary.txt").exists()
            ):
                raise RuntimeError("Definitief master-berekeningsoverzicht ontbreekt.")
            artifacts = [
                output_root / "links.json",
                output_root / "calculation_summary.txt",
            ]
            for path in artifacts:
                if not path.is_file() or path.stat().st_size <= 0:
                    raise RuntimeError(f"Masterartifact ontbreekt: {path.name}")
            subjob_finalizations: dict[str, str] = {}
            for subjob in subjobs:
                subjob_id = self.validate_job_id(subjob.get("subjobId"))
                self.resolve_identifier_child(self.jobs_root, subjob_id)
                expected_hash = finalized_subjob_hashes.get(subjob_id)
                if not expected_hash:
                    raise RuntimeError(f"Subjobfinalisatie ontbreekt: {subjob_id}")
                subjob_finalizations[subjob_id] = expected_hash
            result = {
                "schemaVersion": 2,
                "build": "FIX660R8_PRELIVE_HARDENED",
                "kind": "master",
                "jobId": master_root.name,
                "state": "COMPLETE",
                "subjobCount": len(subjobs),
                "subjobFinalizationsSha256": subjob_finalizations,
                "artifactsSha256": {
                    path.relative_to(output_root).as_posix(): self.cached_sha256_file(path)
                    for path in artifacts
                },
                "finishedAt": self.utc_now_iso(),
            }
            self.durable_write_json(output_root / "finalization.json", result)
            return result
        except Exception as exc:
            try:
                self.atomic_write_json(output_root / "finalization.json", {
                    "schemaVersion": 1,
                    "build": "FIX654_OUTPUT_PIPELINE_AUDIT",
                    "jobId": master_root.name,
                    "state": "ERROR",
                    "error": str(exc)[:500],
                    "finishedAt": self.utc_now_iso(),
                })
            except Exception:
                pass
            raise RuntimeError(f"Masteroutput finaliseren mislukt: {exc}") from exc

    def finalization_complete(
        self,
        job_root: Any,
        *,
        memo: dict[str, bool] | None = None,
    ) -> bool:
        try:
            root = job_root.resolve()
            memo_key = str(root)
            if memo is not None and memo_key in memo:
                return bool(memo[memo_key])
            if root.parent != self.jobs_root.resolve():
                return False
            self.validate_job_id(root.name)
            master_job_id = root.name.split("__mat_", 1)[0]
            master_state = str(self.load_runtime_state(master_job_id).get("state") or "").upper()
            if master_state in {"CANCEL_REQUESTED", "CANCELLED"}:
                return False
            output_root = root / "output"
            final_path = output_root / "finalization.json"
            if not final_path.exists():
                return False
            finalization = self.read_json(final_path)
            if not isinstance(finalization, dict) or str(finalization.get("state") or "").upper() != "COMPLETE":
                return False
            if finalization.get("kind") == "master":
                linked = finalization.get("subjobFinalizationsSha256")
                if not isinstance(linked, dict) or not linked:
                    return False
                for subjob_id, expected_hash in linked.items():
                    subjob_root = self.resolve_identifier_child(self.jobs_root, str(subjob_id))
                    subjob_final = subjob_root / "output" / "finalization.json"
                    if not self.finalization_complete(subjob_root, memo=memo):
                        return False
                    if not hmac.compare_digest(
                        self.cached_sha256_file(subjob_final), str(expected_hash)
                    ):
                        return False
            else:
                manifest_path = output_root / "optimizer_manifest.json"
                if finalization.get("optimizerManifestSha256") != self.cached_sha256_file(manifest_path):
                    return False
            artifacts = finalization.get("artifactsSha256")
            if not isinstance(artifacts, dict) or not artifacts:
                return False
            for relative, expected_hash in artifacts.items():
                artifact = self.resolve_relative_file(output_root, str(relative))
                if not artifact.is_file() or not hmac.compare_digest(
                    self.cached_sha256_file(artifact), str(expected_hash)
                ):
                    return False
            if memo is not None:
                memo[memo_key] = True
            return True
        except Exception:
            try:
                if memo is not None:
                    memo[str(job_root.resolve())] = False
            except Exception:
                pass
            return False

    def sealed_output_artifacts(self, job_root: Any) -> dict[str, Any]:
        try:
            root = job_root.resolve()
            if not self.finalization_complete(root):
                return {}
            output_root = root / "output"
            finalization = self.read_json(output_root / "finalization.json")
            artifacts = finalization.get("artifactsSha256") if isinstance(finalization, dict) else None
            if not isinstance(artifacts, dict) or not artifacts:
                return {}
            sealed: dict[str, Any] = {}
            for relative, expected_hash in artifacts.items():
                path = self.resolve_relative_file(output_root, str(relative))
                if not path.is_file() or not hmac.compare_digest(
                    self.cached_sha256_file(path), str(expected_hash)
                ):
                    return {}
                sealed[f"output/{relative}"] = path
            return sealed
        except Exception:
            return {}

    def public_family_complete(
        self,
        job_id: str,
        *,
        memo: dict[str, bool] | None = None,
    ) -> bool:
        try:
            validated = self.validate_job_id(job_id)
            master_id = self.validate_job_id(
                validated.split("__mat_", 1)[0] if "__mat_" in validated else validated
            )
            master_root = self.resolve_identifier_child(self.jobs_root, master_id)
            if not master_root.is_dir():
                return False
            runtime_state = str(self.load_runtime_state(master_id).get("state") or "").upper()
            has_master_finalization = (master_root / "output" / "finalization.json").is_file()
            if runtime_state == "DONE":
                return self.finalization_complete(master_root, memo=memo)
            if not runtime_state and has_master_finalization:
                return self.finalization_complete(master_root, memo=memo)
            return False
        except Exception:
            return False
