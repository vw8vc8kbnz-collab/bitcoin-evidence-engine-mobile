from __future__ import annotations

"""Single owner for canonical job-family execution and finalization."""

def create_job_from_payload(runtime, payload: dict, master_job_id: str | None = None, public_access_token: str = '') -> dict:
    """Internal helper used by both /api/jobs and the queue worker.

    NOTE: payload format is the same as /api/jobs expects today:
      {panelsCsv: str, dxfParts: dict, pricing?: dict, jobJson?: dict}
    """
    JOBS = runtime.JOBS
    JobCancelledError = runtime.JobCancelledError
    OPTIMIZER_TOOL_B = runtime.OPTIMIZER_TOOL_B
    OptimizerDeadline = runtime.OptimizerDeadline
    PRICING_SEED_PATH = runtime.PRICING_SEED_PATH
    Path = runtime.Path
    ROOT = runtime.ROOT
    SafetyContractError = runtime.SafetyContractError
    _JOB_FINALIZATION_SERVICE = runtime._JOB_FINALIZATION_SERVICE
    _OPTIMIZER_PROCESS_SUPERVISOR = runtime._OPTIMIZER_PROCESS_SUPERVISOR
    _atomic_write_json = runtime._atomic_write_json
    _cached_sha256_file = runtime._cached_sha256_file
    _enforce_job_output_limit = runtime._enforce_job_output_limit
    _ensure_pricing_materials = runtime._ensure_pricing_materials
    _env_int = runtime._env_int
    _filter_panels_csv_by_material = runtime._filter_panels_csv_by_material
    _finalize_subjob_outputs = runtime._finalize_subjob_outputs
    _get_python_base_cmd = runtime._get_python_base_cmd
    _job_cancel_requested = runtime._job_cancel_requested
    _job_lock = runtime._job_lock
    _job_meta = runtime._job_meta
    _link_or_copy_file = runtime._link_or_copy_file
    _load_pricing_config = runtime._load_pricing_config
    _now_iso = runtime._now_iso
    _parse_panels_csv = runtime._parse_panels_csv
    _register_job_process = runtime._register_job_process
    _terminate_optimizer_process = runtime._terminate_optimizer_process
    _unregister_job_process = runtime._unregister_job_process
    _utc_now_iso = runtime._utc_now_iso
    _validated_canonical_dxf_transport = runtime._validated_canonical_dxf_transport
    _write_file = runtime._write_file
    _write_master_job_links = runtime._write_master_job_links
    _write_replaceable_json = runtime._write_replaceable_json
    _write_replaceable_text = runtime._write_replaceable_text
    durable_write_many_bytes = runtime.durable_write_many_bytes
    fsync_directory = runtime.fsync_directory
    json = runtime.json
    resolve_identifier_child = runtime.resolve_identifier_child
    strict_json_dumps = runtime.strict_json_dumps
    strict_json_load = runtime.strict_json_load
    strict_json_loads = runtime.strict_json_loads
    subprocess = runtime.subprocess
    time = runtime.time
    uuid = runtime.uuid
    validate_job_id = runtime.validate_job_id

    function_started_perf = time.perf_counter()
    family_timeout_seconds = max(1, min(86_400, _env_int('OPTIMIZER_JOB_TIMEOUT_SECONDS', 900)))
    optimizer_deadline = OptimizerDeadline.start(
        monotonic=time.monotonic,
        timeout_seconds=family_timeout_seconds,
    )

    def _check_family_deadline(phase: str) -> None:
        optimizer_deadline.check_family(phase)
    if not isinstance(payload, dict) or payload.get('payloadSchema') != 'FIX660R8_SERVER_CANONICAL_V1':
        raise SafetyContractError('Internal job payload is not server-canonical')
    panels_csv = payload.get('panelsCsv', '')
    # Keep the already validated content-addressed representation compact all the
    # way to Tool B.  The previous expand -> re-encode/hash -> compact cycle repeated
    # identical 100 KB bodies up to 250 times before optimizer start.
    dxf_blobs, dxf_part_refs = _validated_canonical_dxf_transport(payload)
    logical_part_ids = set(dxf_part_refs)
    job_json = payload.get('jobJson', {}) or {}

    if not panels_csv or not logical_part_ids:
        raise ValueError('Missing panelsCsv or DXF geometry')

    # Always start from the live pricing config on disk so Admin changes apply immediately
    # to new jobs, even when Tool A still sends an older client-side pricing skeleton.
    cfg = _load_pricing_config()
    live_cfg = cfg if isinstance(cfg, dict) else {}
    live_pricing = live_cfg.get('pricing') if isinstance(live_cfg.get('pricing'), dict) else None
    if not isinstance(live_pricing, dict):
        live_pricing = strict_json_load(PRICING_SEED_PATH)

    # Browser pricing, currency, edge loss and dimensions are never merged here.
    pricing_base = strict_json_loads(strict_json_dumps(live_pricing))
    pricing = _ensure_pricing_materials(pricing_base, panels_csv)

    # Keep production layout settings authoritative from the live pricing config so
    # Admin changes (plaatmarge / nesting gap / kerf) apply immediately to new jobs,
    # even when Tool A still sends older client-side defaults.
    try:
        live_defaults = pricing.get('defaults') if isinstance(pricing.get('defaults'), dict) else {}
        job_json = dict(job_json or {})
        if isinstance(live_defaults, dict):
            if live_defaults.get('sheetMarginMm') is not None:
                job_json['sheetMarginMm'] = float(live_defaults.get('sheetMarginMm'))
            if live_defaults.get('nestingGapMm') is not None:
                job_json['nestingGapMm'] = float(live_defaults.get('nestingGapMm'))
            if live_defaults.get('kerfMm') is not None:
                job_json['kerfMm'] = float(live_defaults.get('kerfMm'))
    except Exception:
        pass

    master_job_id = validate_job_id(str(master_job_id or (time.strftime('%Y%m%d_%H%M%S_') + uuid.uuid4().hex[:6])))
    master_root = resolve_identifier_child(JOBS, master_job_id)
    master_input = master_root / 'input'
    master_output = master_root / 'output'
    master_input.mkdir(parents=True, exist_ok=True)
    master_output.mkdir(parents=True, exist_ok=True)
    # ACCEPTED was durably committed before 202. Intermediate phases live in
    # _job_meta: startup recovery marks ACCEPTED and every former intermediate state
    # FAILED alike, so repeatedly fsyncing the same job_state adds no recovery value.
    if public_access_token:
        try:
            public_access_path = master_root / '.public_access.json'
            # /api/jobs durably creates this before returning 202. Direct/internal callers
            # still get the same contract, without a duplicate fsync in the normal path.
            if not public_access_path.exists():
                _atomic_write_json(public_access_path, {
                    'token': str(public_access_token),
                    'jobId': str(master_job_id),
                    'updatedAt': _utc_now_iso(),
                })
        except Exception:
            pass
    if master_job_id:
        try:
            with _job_lock:
                meta = _job_meta.get(master_job_id, {}) or {}
                meta.update({
                    'status': 'processing',
                    'createdAt': meta.get('createdAt') or _now_iso(),
                    'progressPct': max(int(meta.get('progressPct') or 0), 3),
                    'progressMessage': 'Voorbereiden van de job…',
                    'phase': 'prepare',
                })
                _job_meta[master_job_id] = meta
        except Exception:
            pass

    # Master input (record of the full order). Every file itself remains fsynced;
    # related directory entries are flushed once per directory as one transaction.
    master_blobs_dir = master_input / 'dxf_blobs'
    master_blobs_dir.mkdir(parents=True, exist_ok=True)
    master_blob_paths: dict[str, Path] = {}
    master_refs_obj = {
        'schemaVersion': 1,
        'algorithm': 'sha256',
        'partRefs': {part_id: dxf_part_refs[part_id] for part_id in sorted(dxf_part_refs)},
    }
    master_input_entries: list[tuple[Path, bytes, int | None]] = [
        (master_input / 'panels.csv', str(panels_csv).encode('utf-8'), 0o640),
        (master_input / 'pricing.json', json.dumps(pricing, indent=2).encode('utf-8'), 0o640),
        # job.json can contain the in-memory customer checkout snapshot.
        (master_input / 'job.json', json.dumps(job_json, indent=2).encode('utf-8'), 0o600),
        (master_input / 'dxf_part_refs.json', (strict_json_dumps(master_refs_obj, indent=2) + '\n').encode('utf-8'), 0o640),
    ]
    for blob_id, dxf_text in sorted(dxf_blobs.items()):
        target = master_blobs_dir / f'{blob_id}.dxf'
        master_input_entries.append((target, str(dxf_text).encode('utf-8'), 0o640))
        master_blob_paths[blob_id] = target
    durable_write_many_bytes(master_input_entries)

    # Split into subjobs per MaterialCode (deterministic)
    rows = _parse_panels_csv(panels_csv)
    required_part_ids = {str((r or {}).get('PartId') or '').strip() for r in rows if str((r or {}).get('PartId') or '').strip()}
    missing_dxf_ids = sorted(pid for pid in required_part_ids if pid not in logical_part_ids)
    if missing_dxf_ids:
        raise ValueError(f'DXF-geometrie ontbreekt voor {len(missing_dxf_ids)} paneelregel(s).')
    material_codes: list[str] = []
    seen: set[str] = set()
    for r in rows:
        c = str(r.get('MaterialCode') or '').strip()
        if c and c not in seen:
            seen.add(c)
            material_codes.append(c)

    # Resolve human names from pricing material library
    mats = pricing.get('materials', []) if isinstance(pricing, dict) else []

    def mat_name_for(code: str) -> str:
        for m in mats:
            if str(m.get('materialCode') or '').strip() == str(code).strip():
                return str(m.get('decorName') or m.get('materialName') or m.get('materialCode') or code)
        return str(code)

    subjobs = []
    subjob_roots: list[Path] = []
    timing_profile: dict[str, Any] = {
        'version': 'FIX660R8M',
        'startedAt': _utc_now_iso(),
        'masterJobId': master_job_id,
        'subjobs': [],
    }
    total_started_perf = time.perf_counter()
    timing_profile['acceptedToPreparedSeconds'] = round(max(0.0, total_started_perf - function_started_perf), 3)
    timing_profile['masterDxfFiles'] = len(logical_part_ids)
    timing_profile['masterDxfUniqueBodies'] = len(dxf_blobs)
    timing_profile['masterDxfHardlinks'] = 0
    timing_profile['masterDxfStorageMode'] = 'content_addressed_refs_v1'

    # Guard against runaway disk growth before optimizer work starts
    _enforce_job_output_limit(master_root, subjob_roots)

    # Run optimizer per material code (deterministic ordering)
    total_subjobs = max(1, len(material_codes))
    finalized_subjob_hashes: dict[str, str] = {}
    for subjob_index, code in enumerate(material_codes, start=1):
        _check_family_deadline('subjob preparation')
        if _job_cancel_requested(master_job_id):
            raise JobCancelledError('Job cancelled before optimizer start')
        try:
            with _job_lock:
                meta = _job_meta.get(master_job_id, {}) or {}
                base_pct = 5 + int(round(((subjob_index - 1) / float(total_subjobs)) * 90.0))
                meta.update({
                    'status': 'processing',
                    'progressPct': max(int(meta.get('progressPct') or 0), base_pct),
                    'progressMessage': f'Materiaal {subjob_index}/{total_subjobs} voorbereiden…',
                    'phase': 'subjob_prepare',
                    'currentSubjobIndex': subjob_index,
                    'subjobsTotal': total_subjobs,
                })
                _job_meta[master_job_id] = meta
        except Exception:
            pass
        # Subjob IDs are deliberately opaque; internal article numbers must never appear in public job identifiers.
        sub_id = f"{master_job_id}__mat_{subjob_index:03d}"
        sub_root = JOBS / sub_id
        subjob_roots.append(sub_root)
        sub_inp = sub_root / 'input'
        sub_out = sub_root / 'output'
        sub_inp.mkdir(parents=True, exist_ok=True)
        sub_out.mkdir(parents=True, exist_ok=True)
        # Persist the new subjob entry in JOBS once, before any optimizer process
        # can consume it or the master can later seal it. Never flush per panel.
        fsync_directory(JOBS)
        hardlink_input_directories: set[Path] = set()
        if public_access_token:
            try:
                sub_root.mkdir(parents=True, exist_ok=True)
                # Master and subjob deliberately share the bearer value, but keep
                # independent token records. A later atomic rotation/revocation of
                # either job must never strand the old bearer in a broken hardlink.
                _atomic_write_json(sub_root / '.public_access.json', {
                    'token': str(public_access_token),
                    'jobId': str(sub_id),
                    'updatedAt': _utc_now_iso(),
                })
            except Exception:
                pass
        # Filter panels.csv for this material (preserve header/order)
        sub_csv = _filter_panels_csv_by_material(panels_csv, code)
        # With one material the subjob contains the complete order, even if the CSV
        # helper normalized line endings/quoting. Reuse the already durable canonical
        # master input instead of writing the same logical table a second time.
        if len(material_codes) == 1 or sub_csv == panels_csv:
            sub_csv = panels_csv
            panels_destination = sub_inp / 'panels.csv'
            if _link_or_copy_file(master_input / 'panels.csv', panels_destination) == 'hardlink':
                hardlink_input_directories.add(panels_destination.parent)
        else:
            _write_file(sub_inp / 'panels.csv', sub_csv)
        pricing_destination = sub_inp / 'pricing.json'
        if _link_or_copy_file(master_input / 'pricing.json', pricing_destination) == 'hardlink':
            hardlink_input_directories.add(pricing_destination.parent)
        job_destination = sub_inp / 'job.json'
        if _link_or_copy_file(master_input / 'job.json', job_destination) == 'hardlink':
            hardlink_input_directories.add(job_destination.parent)
        # A material subjob receives only its logical PartId refs and unique bodies.
        # Distinct panel identities remain in panels.csv/placements; geometry is stored once.
        sub_rows = _parse_panels_csv(sub_csv)
        relevant_part_ids = []
        relevant_seen = set()
        for _r in sub_rows:
            _pid = str((_r or {}).get('PartId') or '').strip()
            if _pid and _pid not in relevant_seen:
                relevant_seen.add(_pid)
                relevant_part_ids.append(_pid)
        sub_refs: dict[str, str] = {}
        for part_id in relevant_part_ids:
            if part_id not in logical_part_ids:
                raise ValueError(f'DXF-geometrie ontbreekt voor paneel {part_id}.')
            sub_refs[part_id] = dxf_part_refs[part_id]
        sub_blob_ids = sorted(set(sub_refs.values()))
        sub_blobs_dir = sub_inp / 'dxf_blobs'
        sub_blobs_dir.mkdir(parents=True, exist_ok=True)
        for blob_id in sub_blob_ids:
            src_path = master_blob_paths[blob_id]
            dst_path = sub_blobs_dir / f'{blob_id}.dxf'
            try:
                if _link_or_copy_file(src_path, dst_path) == 'hardlink':
                    hardlink_input_directories.add(dst_path.parent)
            except Exception:
                _write_file(dst_path, str(dxf_blobs[blob_id]))
        sub_refs_obj = {
            'schemaVersion': 1,
            'algorithm': 'sha256',
            'partRefs': {part_id: sub_refs[part_id] for part_id in sorted(sub_refs)},
        }
        if sub_refs_obj == master_refs_obj:
            refs_destination = sub_inp / 'dxf_part_refs.json'
            if _link_or_copy_file(master_input / 'dxf_part_refs.json', refs_destination) == 'hardlink':
                hardlink_input_directories.add(refs_destination.parent)
        else:
            _atomic_write_json(sub_inp / 'dxf_part_refs.json', sub_refs_obj)

        # _link_or_copy_file intentionally does not fsync per hardlink.  Publish the
        # complete input tree with one barrier per affected directory before the
        # optimizer can consume it.  This preserves crash durability without the
        # former per-file sync amplification.
        for linked_directory in sorted(hardlink_input_directories, key=lambda value: value.as_posix()):
            fsync_directory(linked_directory)

        try:
            with _job_lock:
                meta = _job_meta.get(master_job_id, {}) or {}
                ids = [str(value) for value in (meta.get('subjobIds') or []) if str(value)]
                if sub_id not in ids:
                    ids.append(sub_id)
                meta['subjobIds'] = ids
                _job_meta[master_job_id] = meta
        except Exception:
            pass

        # Guard after writing subjob inputs, before expensive optimizer work
        _enforce_job_output_limit(master_root, subjob_roots)

        # Run optimizer script
        cmd = _get_python_base_cmd() + ["-u", str(ROOT / OPTIMIZER_TOOL_B), '--input', str(sub_inp), '--output', str(sub_out)]
        try:
            _write_replaceable_text(sub_out / 'toolb_cmd.txt', ' '.join(cmd))
        except Exception:
            pass
        # Capture logs
        stdout_path = sub_out / 'toolb_stdout.txt'
        stderr_path = sub_out / 'toolb_stderr.txt'
        progress_path = sub_out / 'progress.json'

        def _read_subjob_progress_snapshot() -> tuple[int|None, str]:
            try:
                if not progress_path.exists():
                    return (None, '')
                pdata = strict_json_load(progress_path)
                pct_raw = pdata.get('percent')
                if pct_raw is None:
                    return (None, '')
                pct_val = max(0, min(100, int(round(float(pct_raw)))))
                msg_val = str(pdata.get('message') or pdata.get('phase') or '').strip()
                return (pct_val, msg_val)
            except Exception:
                return (None, '')

        def _publish_master_progress_from_subjob() -> None:
            if not master_job_id:
                return
            pct_val, msg_val = _read_subjob_progress_snapshot()
            if pct_val is None:
                return
            try:
                base_pct = 5 + int(round(((subjob_index - 1) / float(total_subjobs)) * 93.0))
                done_pct = 5 + int(round((subjob_index / float(total_subjobs)) * 93.0))
                mapped_pct = base_pct + int(round((max(0, min(99, pct_val)) / 100.0) * max(0, done_pct - base_pct - 1)))
                mapped_pct = max(base_pct, min(done_pct - 1, mapped_pct))
                if pct_val >= 100:
                    mapped_pct = min(done_pct - 1, max(mapped_pct, done_pct - 1))
                with _job_lock:
                    meta = _job_meta.get(master_job_id, {}) or {}
                    current_pct = int(meta.get('progressPct') or 0)
                    if mapped_pct > current_pct:
                        meta.update({
                            'status': 'processing',
                            'progressPct': mapped_pct,
                            'progressMessage': msg_val or f'Materiaal {subjob_index}/{total_subjobs} optimaliseren…',
                            'phase': 'subjob_progress',
                            'currentSubjobIndex': subjob_index,
                            'subjobsTotal': total_subjobs,
                            'updatedAt': _utc_now_iso(),
                        })
                        _job_meta[master_job_id] = meta
            except Exception:
                pass

        _check_family_deadline('optimizer start')
        subjob_started_perf = time.perf_counter()
        with open(stdout_path, 'w', encoding='utf-8') as f_out, open(stderr_path, 'w', encoding='utf-8') as f_err:
            p = _OPTIMIZER_PROCESS_SUPERVISOR.spawn(
                popen=subprocess.Popen,
                command=cmd,
                cwd=str(ROOT),
                stdout=f_out,
                stderr=f_err,
            )
            if timing_profile.get('firstOptimizerSpawnSeconds') is None:
                timing_profile['firstOptimizerSpawnSeconds'] = round(max(0.0, time.perf_counter() - function_started_perf), 3)
            _register_job_process(master_job_id, p)
            subjob_timeout_seconds = max(1, min(3_600, _env_int('OPTIMIZER_TIMEOUT_SECONDS', 300)))
            subjob_deadline = optimizer_deadline.start_subjob(subjob_timeout_seconds)
            timeout_kind = ''
            try:
                while True:
                    rc = p.poll()
                    _publish_master_progress_from_subjob()
                    if rc is not None:
                        break
                    if _job_cancel_requested(master_job_id):
                        _terminate_optimizer_process(p)
                        raise JobCancelledError(f'Job cancelled during {sub_id}')
                    timeout_kind = optimizer_deadline.timeout_kind(subjob_deadline)
                    if timeout_kind:
                        terminated_rc = _terminate_optimizer_process(p)
                        rc = int(terminated_rc) if terminated_rc is not None else -9
                        break
                    # Fast jobs used to pay four or more fixed 80 ms parent sleeps
                    # even when Tool B had already finished. Poll responsively during
                    # the first two seconds, then back off for genuinely long runs.
                    elapsed = time.perf_counter() - subjob_started_perf
                    time.sleep(0.02 if elapsed < 2.0 else 0.08)
            finally:
                _terminate_optimizer_process(p, terminate_timeout=0.2, kill_timeout=1.0)
                _unregister_job_process(master_job_id, p)
            _publish_master_progress_from_subjob()
            if timeout_kind:
                raise RuntimeError(f"Optimizer {timeout_kind} timeout for {sub_id}")
        optimizer_done_perf = time.perf_counter()

        if rc != 0:
            raise RuntimeError(f"Optimizer failed for {sub_id} (rc={rc}). See {stderr_path.name}")
        _check_family_deadline('optimizer completion')

        # Guard again after optimizer output landed on disk
        _enforce_job_output_limit(master_root, subjob_roots)
        try:
            with _job_lock:
                meta = _job_meta.get(master_job_id, {}) or {}
                summary_pct = 94 + int(round((((subjob_index - 1) + 0.25) / float(total_subjobs)) * 2.0))
                meta.update({
                    'status': 'processing',
                    'progressPct': max(int(meta.get('progressPct') or 0), summary_pct),
                    'progressMessage': f'Materiaal {subjob_index}/{total_subjobs} berekening opbouwen…',
                    'phase': 'subjob_summary',
                })
                _job_meta[master_job_id] = meta
        except Exception:
            pass

        summary_started_perf = time.perf_counter()
        _check_family_deadline('subjob finalization')
        if _job_cancel_requested(master_job_id):
            raise JobCancelledError('Job cancelled before output finalization')
        try:
            _finalize_subjob_outputs(sub_root)
            finalized_subjob_hashes[sub_id] = _cached_sha256_file(sub_out / 'finalization.json')
        except Exception as e:
            raise RuntimeError(f'Outputfinalisatie mislukt voor {sub_id}: {e}') from e
        summary_done_perf = time.perf_counter()
        try:
            _write_replaceable_json(sub_out / 'timing_profile_server.json', {
                'version': 'FIX660R8M',
                'jobId': sub_id,
                'startedAt': _utc_now_iso(),
                'optimizerSeconds': round(max(0.0, optimizer_done_perf - subjob_started_perf), 3),
                'summarySeconds': round(max(0.0, summary_done_perf - summary_started_perf), 3),
                'totalSeconds': round(max(0.0, summary_done_perf - subjob_started_perf), 3),
                'updatedAt': _utc_now_iso(),
            })
        except Exception:
            pass
        timing_profile['subjobs'].append({
            'subjobId': sub_id,
            'optimizerSeconds': round(max(0.0, optimizer_done_perf - subjob_started_perf), 3),
            'summarySeconds': round(max(0.0, summary_done_perf - summary_started_perf), 3),
            'totalSeconds': round(max(0.0, summary_done_perf - subjob_started_perf), 3),
        })

        try:
            with _job_lock:
                meta = _job_meta.get(master_job_id, {}) or {}
                done_pct = 97 + int(round((subjob_index / float(total_subjobs)) * 1.0))
                meta.update({
                    'status': 'processing',
                    'progressPct': max(int(meta.get('progressPct') or 0), done_pct),
                    'progressMessage': f'Materiaal {subjob_index}/{total_subjobs} afgerond',
                    'phase': 'subjob_done',
                })
                _job_meta[master_job_id] = meta
        except Exception:
            pass

        subjobs.append({
            "subjobId": sub_id,
            "materialCode": code,
            "materialDisplayName": mat_name_for(code),
            "status": "DONE",
            "outputsReady": True,
        })
        _write_master_job_links(master_job_id, subjobs)

    # Final guard on the full job family before reporting success
    _check_family_deadline('master finalization')
    if _job_cancel_requested(master_job_id):
        raise JobCancelledError('Job cancelled before master finalization')
    _enforce_job_output_limit(master_root, subjob_roots)
    if master_job_id:
        try:
            with _job_lock:
                meta = _job_meta.get(master_job_id, {}) or {}
                meta.update({
                    'status': 'processing',
                    'progressPct': max(int(meta.get('progressPct') or 0), 95),
                    'progressMessage': 'Subjobs samenvoegen…',
                    'phase': 'finalize_merge',
                })
                _job_meta[master_job_id] = meta
        except Exception:
            pass
    master_summary_started_perf = time.perf_counter()
    _JOB_FINALIZATION_SERVICE.seal_master(
        master_root=master_root,
        subjobs=subjobs,
        finalized_subjob_hashes=finalized_subjob_hashes,
    )
    master_summary_done_perf = time.perf_counter()
    if master_job_id:
        try:
            with _job_lock:
                meta = _job_meta.get(master_job_id, {}) or {}
                meta.update({
                    'status': 'processing',
                    'progressPct': max(int(meta.get('progressPct') or 0), 97),
                    'progressMessage': 'Resultaten verwerken…',
                    'phase': 'finalize',
                })
                _job_meta[master_job_id] = meta
        except Exception:
            pass
        try:
            with _job_lock:
                meta = _job_meta.get(master_job_id, {}) or {}
                meta.update({
                    'status': 'processing',
                    'progressPct': max(int(meta.get('progressPct') or 0), 99),
                    'progressMessage': 'Afronden…',
                    'phase': 'finalize_done',
                })
                _job_meta[master_job_id] = meta
        except Exception:
            pass
    try:
        timing_profile['masterSummarySeconds'] = round(max(0.0, master_summary_done_perf - master_summary_started_perf), 3)
        timing_profile['totalSeconds'] = round(max(0.0, time.perf_counter() - total_started_perf), 3)
        timing_profile['finishedAt'] = _utc_now_iso()
        _write_replaceable_json(master_root / 'output' / 'timing_profile.json', timing_profile)
    except Exception:
        pass

    return {
        "jobId": master_job_id,
        "parentJobId": master_job_id,
        "subjobs": subjobs,
    }
