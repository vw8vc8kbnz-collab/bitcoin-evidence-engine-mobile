from __future__ import annotations

"""In-memory FIFO ownership for admitted public optimizer jobs.

The composition root still owns durable job metadata, runner/thread launch,
process supervision and capacity-reservation I/O.  This owner only performs
the atomic FIFO, active-slot and promotion transitions under the admission
lock that already serialized those transitions in R8Z.
"""

from collections import deque
from typing import Any, Callable

from .admission import PublicJobAdmission


QueueMetaRefresh = Callable[[list[dict[str, Any]], list[dict[str, Any]]], None]
MaxActive = Callable[[], int]
StateChanged = Callable[[], None]


class PublicJobScheduler:
    """Own FIFO order, queue positions and active-worker promotion."""

    def __init__(
        self,
        *,
        admission: PublicJobAdmission,
        max_active: MaxActive,
    ) -> None:
        self.admission = admission
        self.lock = admission.lock
        self.max_active = max_active
        self.queue: deque[dict[str, Any]] = deque()
        self.active_by_id: dict[str, dict[str, Any]] = {}
        self.active_total = 0

    def _promote_locked(self) -> list[dict[str, Any]]:
        starting: list[dict[str, Any]] = []
        maximum = max(1, int(self.max_active()))
        while self.queue and self.active_total < maximum:
            item = self.queue.popleft()
            self.active_total += 1
            self.active_by_id[str(item.get("jobId") or "")] = item
            starting.append(item)
        return starting

    def commit(
        self,
        *,
        ip: str,
        job_id: str,
        runner: Any,
        refresh_meta: QueueMetaRefresh,
        state_changed: StateChanged,
    ) -> tuple[dict[str, Any], list[dict[str, Any]]]:
        """Consume admission and atomically start or enqueue one job."""

        item = {"ip": str(ip or "?"), "jobId": job_id, "runner": runner}
        with self.lock:
            self.admission.consume_reservation_locked(item["ip"])
            self.queue.append(item)
            starting = self._promote_locked()
            state_changed()
            refresh_meta(starting, list(self.queue))
            if item in starting:
                result = {"status": "processing", "queuePosition": 0}
            else:
                position = next(
                    index
                    for index, queued in enumerate(self.queue, start=1)
                    if queued is item
                )
                result = {"status": "queued", "queuePosition": position}
        return result, starting

    def finish(
        self,
        *,
        job_id: str,
        refresh_meta: QueueMetaRefresh,
        state_changed: StateChanged,
    ) -> tuple[bool, list[dict[str, Any]]]:
        """Release an active job exactly once and promote FIFO work."""

        with self.lock:
            item = self.active_by_id.pop(job_id, None)
            if item is None:
                return False, []
            self.active_total = max(0, self.active_total - 1)
            self.admission.finish_locked(str(item.get("ip") or "?"))
            starting = self._promote_locked()
            state_changed()
            refresh_meta(starting, list(self.queue))
        return True, starting

    def cancel_queued(
        self,
        *,
        job_id: str,
        refresh_meta: QueueMetaRefresh,
        state_changed: StateChanged,
    ) -> bool:
        """Remove one waiting job and compact all remaining queue positions."""

        with self.lock:
            item = next(
                (queued for queued in self.queue if queued.get("jobId") == job_id),
                None,
            )
            if item is None:
                return False
            self.queue.remove(item)
            self.admission.cancel_queued_locked(str(item.get("ip") or "?"))
            state_changed()
            refresh_meta([], list(self.queue))
        return True
