"""Job contracts, lifecycle primitives and public facade ownership."""
