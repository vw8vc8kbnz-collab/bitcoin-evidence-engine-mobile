from __future__ import annotations

"""Public job lifecycle facades extracted from the HTTP composition root.

The service owns lifecycle orchestration and response projection.  Every state,
filesystem, queue, process, pricing and serialization collaborator is injected;
optimizer algorithms and artifact finalization remain their existing owners.
"""

import json
import time
import traceback
import uuid
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class JobLifecycleDependencies:
    JOBS: Any
    _OPTIMIZER_PROCESS_SUPERVISOR: Any
    _cancel_queued_public_job: Any
    _client_ip: Any
    _finish_public_job_slot: Any
    _job_lock: Any
    _job_meta: Any
    _now_iso: Any
    _rate_limit_allow: Any
    _read_json_body_limited: Any
    _save_job_runtime_state: Any
    _terminate_optimizer_process: Any
    resolve_identifier_child: Any
    validate_job_id: Any
    _dxf_transport_stats: Any
    _estimate_payload_area_lower_bound: Any
    JobCancelledError: Any
    SafetyContractError: Any
    _commit_public_job_slot: Any
    _create_job_from_payload: Any
    _finalization_complete: Any
    _job_cancel_requested: Any
    durable_write_text: Any
    _atomic_write_json: Any
    _redact_sensitive_text: Any
    JOB_OUTPUT_MAX_BYTES: Any
    PRICING_SEED_PATH: Any
    _append_client_log: Any
    _append_system_event: Any
    _enforce_job_total_qty_limit: Any
    _ensure_pricing_materials: Any
    _env_int: Any
    _estimate_preflight_job_family_bytes: Any
    _is_production_runtime: Any
    _job_output_limit_message: Any
    _load_pricing_config: Any
    _new_public_access_token: Any
    _public_error_message: Any
    _public_job_queue_limits: Any
    _release_public_job_slot: Any
    _release_state_capacity_reservation: Any
    _reserve_state_capacity: Any
    _try_acquire_public_job_slot: Any
    _utc_now_iso: Any
    fsync_directory: Any
    strict_json_dumps: Any
    strict_json_load: Any
    strict_json_loads: Any
    _apply_sell_pricing_to_quote: Any
    _extract_strict_calculation_pricing_summary: Any
    _linked_subjob_ids: Any
    _load_job_runtime_state: Any
    _master_job_id_for: Any
    _public_job_family_complete: Any


class JobLifecycleFacadeService:
    def __init__(self, dependencies: JobLifecycleDependencies) -> None:
        self.dependencies = dependencies

    def api_cancel_job(self, handler, parsed=None):
        """Durably cancel a job and terminate its active optimizer process."""
        d = self.dependencies
        JOBS = d.JOBS()
        _OPTIMIZER_PROCESS_SUPERVISOR = d._OPTIMIZER_PROCESS_SUPERVISOR()
        _cancel_queued_public_job = d._cancel_queued_public_job
        _client_ip = d._client_ip
        _finish_public_job_slot = d._finish_public_job_slot
        _job_lock = d._job_lock()
        _job_meta = d._job_meta()
        _now_iso = d._now_iso
        _rate_limit_allow = d._rate_limit_allow
        _read_json_body_limited = d._read_json_body_limited
        _save_job_runtime_state = d._save_job_runtime_state
        _terminate_optimizer_process = d._terminate_optimizer_process
        resolve_identifier_child = d.resolve_identifier_child
        validate_job_id = d.validate_job_id

        ip = _client_ip(handler)
        if not _rate_limit_allow('cancel_job', ip, 20, 300):
            return handler._send_json({'ok': False, 'error': 'Te veel verzoeken. Probeer het later opnieuw.'}, 429)
        try:
            payload = _read_json_body_limited(handler, 'PUBLIC_JSON_MAX_BYTES', 262144)
            job_id = validate_job_id(payload.get('jobId') or payload.get('parentJobId'))
            job_root = resolve_identifier_child(JOBS, job_id)
        except Exception:
            return handler._send_json({'ok': False, 'error': 'Ongeldige job.'}, 400)
        if not job_root.is_dir():
            return handler._send_json({'ok': False, 'error': 'Job niet gevonden.'}, 404)
        if not handler._require_job_access(job_id, parsed=parsed, body=payload, deny_as_json=True):
            return

        _save_job_runtime_state(job_id, 'CANCEL_REQUESTED', reason='user-cancelled')
        _cancel_queued_public_job(job_id)
        processes = _OPTIMIZER_PROCESS_SUPERVISOR.active(job_id)
        for process in processes:
            if process.poll() is not None:
                continue
            _terminate_optimizer_process(process)
        _save_job_runtime_state(job_id, 'CANCELLED', reason='user-cancelled')
        with _job_lock:
            meta = _job_meta.get(job_id, {}) or {}
            meta.update({'status': 'cancelled', 'phase': 'cancelled', 'finishedAt': _now_iso()})
            _job_meta[job_id] = meta
        # Do not make the next customer wait for the cancelled runner's remaining
        # Python cleanup.  Slot ownership is job-id based and idempotent, so the
        # runner's finally block cannot decrement or promote a second time.
        _finish_public_job_slot(job_id)
        return handler._send_json({'ok': True, 'jobId': job_id, 'state': 'cancelled'})

    def estimate_job_complexity(self, handler, payload: dict) -> dict:
        d = self.dependencies
        _dxf_transport_stats = d._dxf_transport_stats
        _estimate_payload_area_lower_bound = d._estimate_payload_area_lower_bound
        try:
            panels_csv = str((payload or {}).get('panelsCsv') or '')
        except Exception:
            panels_csv = ''
        try:
            dxf_stats = _dxf_transport_stats(payload or {})
            dxf_count = int(dxf_stats.get('logicalCount') or 0)
            dxf_unique_count = int(dxf_stats.get('uniqueCount') or 0)
            dxf_unique_bytes = int(dxf_stats.get('uniqueBytes') or 0)
        except Exception:
            dxf_count = 0
            dxf_unique_count = 0
            dxf_unique_bytes = 0
        try:
            panel_rows = max(0, len([ln for ln in panels_csv.splitlines() if ln.strip()]) - 1)
        except Exception:
            panel_rows = 0
        # Do not stringify an expanded logical PartId->DXF map here. This method runs
        # before the API sends 202 Accepted, and identical 200–250 panel jobs previously
        # became a temporary 25–35 MB JSON serialization despite a single unique body.
        try:
            approx_bytes = (
                len(panels_csv.encode('utf-8'))
                + dxf_unique_bytes
                + len(json.dumps((payload or {}).get('jobJson') or {}, ensure_ascii=False).encode('utf-8'))
            )
        except Exception:
            approx_bytes = dxf_unique_bytes
        try:
            area_info = _estimate_payload_area_lower_bound(payload)
        except Exception:
            area_info = {'maxAreaLowerBound': 0}
        return {
            'panelRows': panel_rows,
            'dxfCount': dxf_count,
            'dxfUniqueBodies': dxf_unique_count,
            'approxBytes': approx_bytes,
            'maxAreaLowerBound': int((area_info or {}).get('maxAreaLowerBound') or 0),
            }

    def start_async_job_create(self, handler, payload: dict, master_job_id: str, public_access_token: str = '', acquired_ip: str = '') -> dict[str, Any]:
        d = self.dependencies
        JOBS = d.JOBS()
        JobCancelledError = d.JobCancelledError
        SafetyContractError = d.SafetyContractError
        _commit_public_job_slot = d._commit_public_job_slot
        _create_job_from_payload = d._create_job_from_payload
        _finalization_complete = d._finalization_complete
        _job_cancel_requested = d._job_cancel_requested
        _job_lock = d._job_lock()
        _job_meta = d._job_meta()
        _now_iso = d._now_iso
        _save_job_runtime_state = d._save_job_runtime_state
        durable_write_text = d.durable_write_text
        resolve_identifier_child = d.resolve_identifier_child
        def _runner():
            try:
                if _job_cancel_requested(master_job_id):
                    raise JobCancelledError('Job was cancelled before optimizer start')
                create_result = _create_job_from_payload(payload, master_job_id=master_job_id, public_access_token=public_access_token)
                if _job_cancel_requested(master_job_id):
                    raise JobCancelledError('Job was cancelled before publication')
                # One complete family proof is the durable transition gate to DONE.
                # Status polling reuses the per-artifact hash cache and never races the
                # finalizer by repeatedly doing this proof while output is still growing.
                if not _finalization_complete(resolve_identifier_child(JOBS, master_job_id), _memo={}):
                    raise SafetyContractError('Final job family integrity verification failed')
                _save_job_runtime_state(master_job_id, 'DONE')
                with _job_lock:
                    meta = _job_meta.get(master_job_id, {}) or {}
                    meta['status'] = 'done'
                    meta['progressPct'] = 100
                    meta['progressMessage'] = 'Optimalisatie afgerond'
                    meta['phase'] = 'done'
                    meta['finishedAt'] = _now_iso()
                    _job_meta[master_job_id] = meta
            except Exception as e:
                cancelled = isinstance(e, JobCancelledError) or _job_cancel_requested(master_job_id)
                try:
                    jr = resolve_identifier_child(JOBS, master_job_id)
                    (jr / 'output').mkdir(parents=True, exist_ok=True)
                    durable_write_text(jr / 'output' / 'create_job_error.txt', str(e))
                except Exception:
                    pass
                _save_job_runtime_state(
                    master_job_id,
                    'CANCELLED' if cancelled else 'FAILED',
                    reason='user-cancelled' if cancelled else str(e)[:500],
                    retryable=not cancelled,
                )
                with _job_lock:
                    meta = _job_meta.get(master_job_id, {}) or {}
                    meta['status'] = 'cancelled' if cancelled else 'error'
                    meta['phase'] = 'cancelled' if cancelled else 'failed'
                    meta['finishedAt'] = _now_iso()
                    if not cancelled:
                        meta['error'] = str(e)
                    _job_meta[master_job_id] = meta
        return _commit_public_job_slot(acquired_ip, master_job_id, _runner)

    def write_api_jobs_crashlog(self, handler, label: str, payload: dict | None = None, err: Exception | None = None, extra: dict | None = None) -> None:
        d = self.dependencies
        JOBS = d.JOBS()
        _atomic_write_json = d._atomic_write_json
        _now_iso = d._now_iso
        _redact_sensitive_text = d._redact_sensitive_text
        try:
            log_dir = JOBS / '_crash_logs'
            log_dir.mkdir(parents=True, exist_ok=True)
            ts = time.strftime('%Y%m%d_%H%M%S_') + uuid.uuid4().hex[:6]
            rec = {
                'ts': _now_iso(),
                'label': label,
                'error': _redact_sensitive_text(str(err), 600) if err else '',
                'traceback': _redact_sensitive_text(traceback.format_exc(), 4000) if err else '',
                'extra': extra or {},
            }
            if isinstance(payload, dict):
                try:
                    rec['complexity'] = handler._estimate_job_complexity(payload)
                except Exception:
                    pass
                try:
                    rec['payload_keys'] = sorted(list(payload.keys()))
                except Exception:
                    pass
            _atomic_write_json(log_dir / f'api_jobs_{ts}.json', rec)
        except Exception:
            pass

    def api_create_job(self, handler):
        """Create a Tool B job using the proven synchronous path.

        Public route, but security-hardened with payload limits and basic abuse
        throttling because job creation is disk- and CPU-expensive.
        """
        d = self.dependencies
        JOBS = d.JOBS()
        JOB_OUTPUT_MAX_BYTES = d.JOB_OUTPUT_MAX_BYTES()
        PRICING_SEED_PATH = d.PRICING_SEED_PATH()
        _append_client_log = d._append_client_log
        _append_system_event = d._append_system_event
        _atomic_write_json = d._atomic_write_json
        _client_ip = d._client_ip
        _enforce_job_total_qty_limit = d._enforce_job_total_qty_limit
        _ensure_pricing_materials = d._ensure_pricing_materials
        _env_int = d._env_int
        _estimate_payload_area_lower_bound = d._estimate_payload_area_lower_bound
        _estimate_preflight_job_family_bytes = d._estimate_preflight_job_family_bytes
        _is_production_runtime = d._is_production_runtime
        _job_lock = d._job_lock()
        _job_meta = d._job_meta()
        _job_output_limit_message = d._job_output_limit_message
        _load_pricing_config = d._load_pricing_config
        _new_public_access_token = d._new_public_access_token
        _now_iso = d._now_iso
        _public_error_message = d._public_error_message
        _public_job_queue_limits = d._public_job_queue_limits
        _rate_limit_allow = d._rate_limit_allow
        _read_json_body_limited = d._read_json_body_limited
        _release_public_job_slot = d._release_public_job_slot
        _release_state_capacity_reservation = d._release_state_capacity_reservation
        _reserve_state_capacity = d._reserve_state_capacity
        _save_job_runtime_state = d._save_job_runtime_state
        _try_acquire_public_job_slot = d._try_acquire_public_job_slot
        _utc_now_iso = d._utc_now_iso
        fsync_directory = d.fsync_directory
        strict_json_dumps = d.strict_json_dumps
        strict_json_load = d.strict_json_load
        strict_json_loads = d.strict_json_loads
        validate_job_id = d.validate_job_id
        ip = _client_ip(handler)
        if not _rate_limit_allow('api_jobs', ip, 12 if _is_production_runtime() else 20, 300):
            try:
                _append_system_event(level="warning", component="jobs", message_user="Publieke jobroute rate-limited", message_tech="api_jobs rate limit", status="open")
            except Exception:
                pass
            return handler._send_json({"ok": False, "error": _public_error_message(429)}, 429)

        acquired = False
        slot_handed_off = False
        storage_reserved = False
        master_job_id = ''
        try:
            acquired, slot_reason = _try_acquire_public_job_slot(ip)
            if not acquired:
                try:
                    _append_system_event(level="warning", component="jobs", message_user="Publieke optimalisatiecapaciteit bereikt", message_tech=f"api_jobs admission block ({slot_reason})", status="open")
                except Exception:
                    pass
                max_active, max_queued, max_per_ip = _public_job_queue_limits()
                if slot_reason == 'ip':
                    error = "Er staan al aanvragen vanaf dit netwerkadres in verwerking of in de wachtrij. Wacht tot er één klaar is en probeer het opnieuw."
                else:
                    error = "De optimalisatiewachtrij is vol. Wacht even en probeer het daarna opnieuw."
                return handler._send_json({
                    "ok": False,
                    "error": error,
                    "busy": True,
                    "queueFull": slot_reason == 'queue_full',
                    "maxConcurrentOptimizations": max_active,
                    "maxQueuedOptimizations": max_queued,
                    "maxOptimizationsPerIp": max_per_ip,
                }, 429)

            max_bytes = _env_int('PUBLIC_JSON_MAX_BYTES', 16777216 if _is_production_runtime() else 134217728)
            try:
                content_length = int(handler.headers.get('Content-Length', '0') or '0')
            except Exception:
                content_length = 0
            if content_length and content_length > max_bytes:
                actual_mb = float(content_length) / 1024.0 / 1024.0
                limit_mb = float(max_bytes) / 1024.0 / 1024.0
                try:
                    _append_client_log('server', 'api_jobs_payload_block', 'Public job payload too large', {'contentLengthMb': round(actual_mb, 1), 'limitMb': round(limit_mb, 1)})
                except Exception:
                    pass
                return handler._send_json({"ok": False, "error": "De aanvraag kon niet volledig worden ontvangen. Herlaad de pagina en probeer opnieuw."}, 413)

            try:
                payload = _read_json_body_limited(handler, 'PUBLIC_JSON_MAX_BYTES', max_bytes)
            except Exception as e:
                err_text = str(e)
                if err_text.startswith('JOB_PAYLOAD_TOO_LARGE::'):
                    return handler._send_json({"ok": False, "error": "De aanvraag kon niet volledig worden ontvangen. Herlaad de pagina en probeer opnieuw."}, 413)
                raise
            if not isinstance(payload, dict) or not payload:
                return handler._send_json({"ok": False, "error": "Lege jobpayload."}, 400)

            # Convert browser intent into a strict, server-owned production DTO before
            # any persistent job/request path is created.
            payload = handler._canonicalize_public_job_payload(payload)

            try:
                top_level_keys = set(payload.keys())
                if top_level_keys and len(top_level_keys) > 64:
                    return handler._send_json({"ok": False, "error": "Ongeldige aanvraag."}, 400)
            except Exception:
                pass
            qty_limit = _env_int('PUBLIC_JOB_TOTAL_QTY_LIMIT', 250)
            area_lb_limit = _env_int('PUBLIC_JOB_MAX_AREA_LB', 250)
            total_qty = _enforce_job_total_qty_limit(payload, qty_limit)
            live_cfg = _load_pricing_config()
            live_pricing = (live_cfg or {}).get('pricing') if isinstance(live_cfg, dict) else None
            if not isinstance(live_pricing, dict):
                live_pricing = strict_json_load(PRICING_SEED_PATH)
            authoritative_pricing = _ensure_pricing_materials(
                strict_json_loads(strict_json_dumps(live_pricing)),
                payload['panelsCsv'],
            )
            area_info = _estimate_payload_area_lower_bound({
                'panelsCsv': payload['panelsCsv'],
                'pricing': authoritative_pricing,
            })
            max_area_lb = int((area_info or {}).get('maxAreaLowerBound') or 0)
            try:
                _append_client_log('server', 'api_jobs_preflight', 'Public job guards passed', {'totalQty': int(total_qty), 'limitQty': int(qty_limit), 'maxAreaLowerBound': int(max_area_lb), 'maxAreaLowerBoundLimit': int(area_lb_limit)})
            except Exception:
                pass
            if max_area_lb > int(area_lb_limit):
                return handler._send_json({"ok": False, "error": f"Deze configuratie is te groot voor één aanvraag. De geschatte minimale plaatbehoefte is minstens {max_area_lb} platen. Splits de bestelling op in meerdere aanvragen."}, 413)
            family_estimate = _estimate_preflight_job_family_bytes(payload)
            if int(family_estimate.get('projectedTotalBytes') or 0) > int(JOB_OUTPUT_MAX_BYTES):
                return handler._send_json({
                    'ok': False,
                    'error': _job_output_limit_message(
                        int(family_estimate.get('projectedTotalBytes') or 0),
                        int(JOB_OUTPUT_MAX_BYTES),
                    ),
                }, 413)
            master_job_id = validate_job_id(time.strftime('%Y%m%d_%H%M%S_') + uuid.uuid4().hex[:6])
            _reserve_state_capacity(
                master_job_id,
                int(family_estimate.get('projectedTotalBytes') or 0),
                projected_inodes=max(
                    256,
                    int(family_estimate.get('totalQty') or 0) * 8
                    + int(family_estimate.get('dxfCount') or 0) * 4,
                ),
            )
            storage_reserved = True

            created_at = _now_iso()
            job_root = JOBS / master_job_id
            (job_root / 'input').mkdir(parents=True, exist_ok=True)
            (job_root / 'output').mkdir(parents=True, exist_ok=True)
            # The files below are individually durable, but POSIX also requires the
            # newly created job-directory entry itself to be flushed in its parent.
            # Do this once per admitted job before ACCEPTED can be returned as 202.
            fsync_directory(JOBS)
            access_token = _new_public_access_token()
            _atomic_write_json(job_root / '.public_access.json', {
                'token': access_token,
                'jobId': master_job_id,
                'updatedAt': _utc_now_iso(),
            })
            _save_job_runtime_state(master_job_id, 'ACCEPTED')
            complexity = handler._estimate_job_complexity(payload)
            with _job_lock:
                _job_meta[master_job_id] = {
                    'status': 'processing',
                    'createdAt': created_at,
                    'acceptedAt': created_at,
                    'progressPct': 1,
                    'progressMessage': 'Aanvraag gestart',
                    'phase': 'accepted',
                    'complexity': complexity,
                }
            scheduling = handler._start_async_job_create(payload, master_job_id, access_token, ip)
            slot_handed_off = True
            scheduling_status = str(scheduling.get('status') or 'queued')
            queue_position = max(0, int(scheduling.get('queuePosition') or 0))
            if scheduling_status == 'queued':
                progress_message = f'Wachtrij: positie {queue_position}'
            else:
                progress_message = 'Optimalisatie wordt gestart…'
            return handler._send_json({
                'ok': True,
                'jobId': master_job_id,
                'parentJobId': master_job_id,
                'subjobs': [],
                'accessToken': access_token,
                'meta': {
                    'status': scheduling_status,
                    'progressPct': 1,
                    'progressMessage': progress_message,
                    'queuePosition': queue_position,
                }
            }, 202)
        except Exception as e:
            err_text = str(e)
            if err_text.startswith('JOB_PAYLOAD_TOO_LARGE::'):
                try:
                    _, actual_s, limit_s = err_text.split('::', 2)
                    actual_mb = float(actual_s) / 1024.0 / 1024.0
                    limit_mb = float(limit_s) / 1024.0 / 1024.0
                    return handler._send_json({
                        "ok": False,
                        "error": f"Deze aanvraag is te groot om veilig te verwerken ({actual_mb:.1f} MB). Het maximum is {limit_mb:.0f} MB. Splits de job op in meerdere delen en probeer het opnieuw."
                    }, 413)
                except Exception:
                    return handler._send_json({
                        "ok": False,
                        "error": "Deze aanvraag is te groot om veilig te verwerken. Splits de job op in meerdere delen en probeer het opnieuw."
                    }, 413)
            if err_text.startswith('JOB_TOTAL_QTY_TOO_LARGE::'):
                try:
                    _, actual_s, limit_s = err_text.split('::', 2)
                    return handler._send_json({
                        "ok": False,
                        "error": f"Deze aanvraag bevat te veel panelen om veilig te verwerken ({int(actual_s)}). Het maximum is {int(limit_s)} panelen. Splits de job op in meerdere delen."
                    }, 413)
                except Exception:
                    return handler._send_json({
                        "ok": False,
                        "error": "Deze aanvraag bevat te veel panelen om veilig te verwerken. Splits de job op in meerdere delen."
                    }, 413)
            try:
                handler._write_api_jobs_crashlog('api_create_job_exception', payload if 'payload' in locals() and isinstance(payload, dict) else None, e, {
                    'path': '/api/jobs',
                    'contentLength': str(handler.headers.get('Content-Length') or ''),
                })
            except Exception:
                pass
            safe_msg = str(e).strip()
            if safe_msg and not safe_msg.startswith(('JOB_PAYLOAD_TOO_LARGE::', 'JOB_TOTAL_QTY_TOO_LARGE::')) and len(safe_msg) <= 240 and not any(ch in safe_msg for ch in ['Traceback', 'File "', '\n']):
                safe_obj = handler._sanitize_public_material_response({"ok": False, "error": safe_msg})
                return handler._send_json(safe_obj, 400)
            return handler._send_json({"ok": False, "error": "Jobaanmaak mislukt"}, 400)
        finally:
            if storage_reserved and not slot_handed_off:
                _release_state_capacity_reservation(master_job_id)
            if acquired and not slot_handed_off:
                _release_public_job_slot(ip)

    def api_status(self, handler, job_id: str, parsed=None):
        """Return lightweight job status + quote for Tool A polling.

        Old builds relied on in-memory _job_meta, but that breaks after restarts and
        for parent/subjob fan-out runs. We infer status from the file-based outputs,
        keeping the system deterministic and resilient.
        """
        d = self.dependencies
        JOBS = d.JOBS()
        SafetyContractError = d.SafetyContractError
        _apply_sell_pricing_to_quote = d._apply_sell_pricing_to_quote
        _extract_strict_calculation_pricing_summary = d._extract_strict_calculation_pricing_summary
        _finalization_complete = d._finalization_complete
        _job_lock = d._job_lock()
        _job_meta = d._job_meta()
        _linked_subjob_ids = d._linked_subjob_ids
        _load_job_runtime_state = d._load_job_runtime_state
        _master_job_id_for = d._master_job_id_for
        _public_job_family_complete = d._public_job_family_complete
        resolve_identifier_child = d.resolve_identifier_child
        strict_json_load = d.strict_json_load
        validate_job_id = d.validate_job_id
        try:
            job_id = validate_job_id(job_id)
            job_root = resolve_identifier_child(JOBS, job_id)
        except SafetyContractError:
            return handler._send_json({'meta': {'status': 'unknown'}, 'quote': None}, 404)
        if not handler._require_job_access(job_id, parsed=parsed, deny_as_json=True):
            return
        if not job_root.exists():
            return handler._send_json({'meta': {'status': 'unknown'}, 'quote': None})
        if '__mat_' in job_id:
            # A finished material subjob is only a partial result until its master
            # family has reached a verified durable DONE state.  Keep public clients
            # on the master status route and never expose intermediate pricing.
            if not _public_job_family_complete(job_id, memo={}):
                master_id = _master_job_id_for(job_id)
                master_state = str(_load_job_runtime_state(master_id).get('state') or '').lower()
                if master_state in {'done', 'failed', 'cancel_requested', 'cancelled'}:
                    message = (
                        'Integriteitscontrole van de volledige berekening is mislukt'
                        if master_state == 'done'
                        else 'De volledige berekening is niet afgerond'
                    )
                    return handler._send_json({
                        'meta': {'status': 'error', 'progressPct': 0, 'progressMessage': message},
                        'quote': None,
                        'pricingSummary': {},
                    }, 409)
                return handler._send_json({
                    'meta': {'status': 'processing', 'progressPct': 0, 'progressMessage': 'De volledige berekening wordt nog verwerkt'},
                    'quote': None,
                    'pricingSummary': {},
                })
        runtime_state = str(_load_job_runtime_state(job_id).get('state') or '').lower()
        with _job_lock:
            meta = dict(_job_meta.get(job_id, {}) or {})
        finalization_memo: dict[str, bool] = {}
        def _is_final(root: Any) -> bool:
            return _finalization_complete(root, _memo=finalization_memo)
        # During ACCEPTED/processing phases no production result is exposed.  Rehashing
        # a growing output tree on every 350 ms poll only competes with the finalizer.
        # DONE is written durably only after one complete family verification.
        # Historical/preserved completed jobs can predate job_state.json; in that
        # narrow case the immutable master finalization marker authorizes one full
        # proof. Never hash a growing ACCEPTED/PROCESSING family.
        has_master_finalization = (job_root / 'output' / 'finalization.json').is_file()
        family_finalized = _is_final(job_root) if (
            runtime_state == 'done' or (not runtime_state and has_master_finalization)
        ) else False
        if runtime_state in {'cancel_requested', 'cancelled'}:
            return handler._send_json({
                'meta': {'status': 'cancelled', 'progressPct': 0, 'progressMessage': 'Berekening geannuleerd'},
                'quote': None,
                'pricingSummary': {},
            })
        if runtime_state == 'failed':
            return handler._send_json({
                'meta': {'status': 'error', 'progressPct': 0, 'progressMessage': 'Berekening mislukt'},
                'quote': None,
                'pricingSummary': {},
            })
        if runtime_state == 'done' and not family_finalized:
            return handler._send_json({
                'meta': {'status': 'error', 'progressPct': 0, 'progressMessage': 'Integriteitscontrole van productie-output is mislukt'},
                'quote': None,
                'pricingSummary': {},
            }, 409)

        def _load_quote(path: Any):
            if not path.exists():
                return None
            try:
                q = strict_json_load(path)
            except Exception:
                return None
            # ensure sell pricing shape compatibility where possible
            try:
                if isinstance(q, dict) and (q.get('sellPricing') is None):
                    q = _apply_sell_pricing_to_quote(q)
            except Exception:
                pass
            return q

        def _quote_grand_total(q: dict) -> float:
            """Best-effort extract of grand total from various quote formats."""
            if not isinstance(q, dict):
                return 0.0
            # Most authoritative: quote.json format uses totals.grandTotal
            cand = None
            try:
                cand = (q.get('totals') or {}).get('grandTotal')
            except Exception:
                cand = None
            if cand is None:
                # legacy / status-summary formats
                for k in ('grandTotal', 'total_incl_vat', 'totalInclVat', 'total'):
                    if q.get(k) is not None:
                        cand = q.get(k)
                        break
            try:
                return float(cand or 0.0)
            except Exception:
                return 0.0

        def _quote_sheet_count(q: dict) -> int:
            """Best-effort extract of sheet count."""
            if not isinstance(q, dict):
                return 0
            # Prefer explicit if present
            for k in ('sheetCount', 'sheetsCount'):
                if q.get(k) is not None:
                    try:
                        return int(q.get(k) or 0)
                    except Exception:
                        pass
            # quote.json format: sum materials[*].sheetCount if available
            try:
                mats = q.get('materials')
                if isinstance(mats, list):
                    s = 0
                    for m in mats:
                        if isinstance(m, dict) and m.get('sheetCount') is not None:
                            try:
                                s += int(m.get('sheetCount') or 0)
                            except Exception:
                                pass
                    if s:
                        return s
            except Exception:
                pass
            # fallback: totals.sheetCount
            try:
                return int((q.get('totals') or {}).get('sheetCount') or 0)
            except Exception:
                return 0


        inferred_status = 'unknown'
        quote = None

        # Parent job? Prefer explicit persisted links, then the current process metadata.
        # A global JOBS glob on every poll degrades with retained order history.
        linked_ids = _linked_subjob_ids(job_id)
        if not linked_ids:
            linked_ids = [
                str(value) for value in (meta.get('subjobIds') or [])
                if isinstance(value, str)
            ]
        # Legacy completed jobs predate links.json; retain one compatibility fallback.
        if not linked_ids and runtime_state in {'done', 'failed', 'cancelled'}:
            linked_ids = [p.name for p in sorted(JOBS.glob(f"{job_id}__mat_*")) if p.is_dir()]
        subjob_dirs = []
        for subjob_id in linked_ids:
            try:
                subjob_root = resolve_identifier_child(JOBS, validate_job_id(subjob_id))
                if subjob_root.is_dir() and subjob_root not in subjob_dirs:
                    subjob_dirs.append(subjob_root)
            except Exception:
                continue
        if subjob_dirs:
            # FIX654: new jobs use an explicit finalization contract. Legacy jobs retain
            # the old core-output fallback, but a missing best-effort summary can no longer
            # silently make a new job spin forever.
            all_done = True
            any_finalization = False
            finalization_error = ''
            sub_quotes = []
            for sp in subjob_dirs:
                out = sp / 'output'
                fin = out / 'finalization.json'
                if fin.exists():
                    any_finalization = True
                    try:
                        fd = strict_json_load(fin)
                        fstate = str(fd.get('state') or '').upper()
                        if fstate == 'ERROR':
                            finalization_error = str((fd.get('errors') or [fd.get('error') or 'Outputfinalisatie mislukt'])[0])
                            all_done = False
                        elif fstate != 'COMPLETE':
                            all_done = False
                    except Exception:
                        all_done = False
                else:
                    if not (out / 'placements.json').exists() or not (out / 'report.json').exists():
                        all_done = False
                    if not ((sp / 'calculation_summary.txt').exists() or (out / 'calculation_summary.txt').exists() or (sp / 'input' / 'calculation_summary.txt').exists()):
                        all_done = False
                # The master family proof already recursively verified every linked
                # subjob.  Never perform the same complete proof again in one response.
                q = _load_quote(out / 'quote.json') if family_finalized else None
                if isinstance(q, dict):
                    sub_quotes.append((sp.name, q))
            if finalization_error:
                inferred_status = 'error'
            else:
                inferred_status = 'done' if all_done else 'processing'

            # Aggregate quote (best-effort) if parent quote is missing
            # A master quote is authoritative only when the master finalization
            # explicitly seals it. Current multi-material masters seal links + the
            # calculation summary and derive their public quote from already verified
            # subjob quotes; an unrelated file named quote.json must never override it.
            parent_quote = None
            if family_finalized:
                try:
                    master_finalization = strict_json_load(job_root / 'output' / 'finalization.json')
                    master_artifacts = (master_finalization or {}).get('artifactsSha256') or {}
                    if isinstance(master_artifacts, dict) and 'quote.json' in master_artifacts:
                        parent_quote = _load_quote(job_root / 'output' / 'quote.json')
                except Exception:
                    parent_quote = None
            if isinstance(parent_quote, dict):
                quote = parent_quote
            elif sub_quotes:
                total = 0.0
                sheet_count = 0
                currency = None
                for sid, q in sub_quotes:
                    if currency is None:
                        currency = q.get('currency')
                    try:
                        total += _quote_grand_total(q)
                    except Exception:
                        pass
                    try:
                        sheet_count += _quote_sheet_count(q)
                    except Exception:
                        pass
                # Provide BOTH the modern quote.json-like shape (totals.grandTotal) and
                # legacy summary fields (grandTotal/sheetCount) so Tool A can accept all formats.
                quote = {
                    'currency': currency or 'EUR',
                    'totals': {
                        'grandTotal': round(total, 2),
                        'sheetCount': sheet_count,
                    },
                    'grandTotal': round(total, 2),
                    'sheetCount': sheet_count,
                    'perSubjob': [
                        {
                            'subjobId': sid,
                            'currency': (q.get('currency') if isinstance(q, dict) else None) or (currency or 'EUR'),
                            'totals': {
                                'grandTotal': _quote_grand_total(q),
                                'sheetCount': _quote_sheet_count(q),
                            },
                            'grandTotal': _quote_grand_total(q),
                            'sheetCount': _quote_sheet_count(q),
                        }
                        for sid, q in sub_quotes
                    ],
                }
        else:
            out = job_root / 'output'
            quote = _load_quote(out / 'quote.json')
            has_calc = (job_root / 'calculation_summary.txt').exists() or (out / 'calculation_summary.txt').exists()
            if runtime_state == 'accepted' and str(meta.get('status') or '').lower() == 'queued':
                inferred_status = 'queued'
            elif (((out / 'report.json').exists() or (out / 'placements.json').exists() or isinstance(quote, dict)) and has_calc):
                inferred_status = 'done'
            elif out.exists() or isinstance(quote, dict):
                inferred_status = 'processing'

        def _read_progress(root: Any):
            try:
                pp = root / 'output' / 'progress.json'
                if pp.exists():
                    pdata = strict_json_load(pp)
                    pct = pdata.get('percent')
                    msg = str(pdata.get('message') or pdata.get('phase') or '').strip()
                    if pct is not None:
                        try:
                            pct = max(0, min(100, int(round(float(pct)))))
                            return {'pct': pct, 'message': msg}
                        except Exception:
                            pass
                rp = root / 'output' / 'report.json'
                if not rp.exists():
                    return None
                data = strict_json_load(rp)
                prog = data.get('progress') if isinstance(data.get('progress'), dict) else {}
                pct = prog.get('percent') if isinstance(prog, dict) else None
                msg = str(prog.get('message') or prog.get('phase') or '').strip() if isinstance(prog, dict) else ''
                if pct is None and data.get('ok') is True:
                    pct = 100
                if pct is None:
                    return None
                try:
                    pct = max(0, min(100, int(round(float(pct)))))
                except Exception:
                    return None
                return {'pct': pct, 'message': msg}
            except Exception:
                return None

        meta2 = dict(meta)
        queued_in_memory = runtime_state == 'accepted' and str(meta2.get('phase') or '') == 'queued'
        if queued_in_memory:
            # The empty output directory exists from durable admission and must not
            # make a waiting job look as though its optimizer worker has started.
            meta2['status'] = 'queued'
        elif inferred_status != 'unknown':
            meta2['status'] = inferred_status
        else:
            meta2.setdefault('status', 'unknown')

        progress_info = None
        meta_pct = int(meta2.get('progressPct') or 0)
        meta_msg = str(meta2.get('progressMessage') or '').strip()

        # Prefer live subjob progress while a job is still processing. The coarse master/meta
        # progress is only a floor/fallback; otherwise the UI can jump early to a stale 84/86/98.
        if subjob_dirs and meta2.get('status') not in ('done', 'ready', 'ok'):
            total = len(subjob_dirs)
            done_count = 0
            current_fraction = 0.0
            current_message = ''
            for sj in subjob_dirs:
                sj_out = sj / 'output'
                sj_quote = _load_quote(sj_out / 'quote.json')
                has_calc_summary = ((sj / 'calculation_summary.txt').exists()) or ((sj_out / 'calculation_summary.txt').exists()) or ((sj / 'input' / 'calculation_summary.txt').exists())
                fin_path = sj_out / 'finalization.json'
                if fin_path.exists():
                    # This is progress only, not an authorization boundary.  Production
                    # data remains hidden until the verified master family reaches DONE.
                    try:
                        fin_obj = strict_json_load(fin_path)
                        sj_done = str((fin_obj or {}).get('state') or '').upper() == 'COMPLETE'
                    except Exception:
                        sj_done = False
                else:
                    # Legacy jobs created before FIX654 have no finalization marker.
                    sj_done = (((sj_out / 'report.json').exists() or (sj_out / 'placements.json').exists() or isinstance(sj_quote, dict)) and has_calc_summary)
                if sj_done:
                    done_count += 1
                    continue
                prog = _read_progress(sj)
                if prog and prog.get('pct', 0) > 0:
                    frac = max(0.0, min(0.99, prog['pct'] / 100.0))
                    if frac >= current_fraction:
                        current_fraction = frac
                        current_message = prog.get('message') or current_message
            if total > 0:
                if done_count >= total:
                    # all subjobs finished; keep the master meta progress as the source for the true final server phase
                    if meta_pct > 0:
                        progress_info = {'pct': meta_pct, 'message': meta_msg}
                    else:
                        progress_info = {'pct': 99, 'message': meta_msg or 'Resultaten verwerken…'}
                else:
                    pct = int(round(((done_count + current_fraction) / float(total)) * 96.0))
                    pct = max(pct, min(96, meta_pct))
                    if pct > 0:
                        progress_info = {'pct': pct, 'message': current_message or meta_msg}
        elif meta_pct > 0:
            progress_info = {'pct': meta_pct, 'message': meta_msg}
        else:
            prog = _read_progress(job_root)
            if prog:
                progress_info = prog

        if progress_info:
            pct_val = int(progress_info.get('pct') or 0)
            if meta2.get('status') not in ('done', 'ready', 'ok'):
                pct_val = min(99, pct_val)
            meta2['progressPct'] = pct_val
            if progress_info.get('message'):
                meta2['progressMessage'] = progress_info.get('message')
            elif pct_val >= 95 and meta2.get('status') not in ('done', 'ready', 'ok'):
                meta2['progressMessage'] = 'Resultaten verwerken…'
        elif meta2.get('status') in ('done', 'ready', 'ok'):
            meta2['progressPct'] = 100
            meta2['progressMessage'] = meta2.get('progressMessage') or 'Optimalisatie afgerond'

        pricing_summary = {}
        try:
            candidate_job_ids = []
            for jid in [job_id] + [p.name for p in subjob_dirs]:
                if jid and jid not in candidate_job_ids:
                    candidate_job_ids.append(jid)
            # STRICT for Tool A status: only return a visible price once a finished
            # calculation summary exists. Never generate one on the fly from quote or
            # request payload fallbacks.
            pricing_summary = _extract_strict_calculation_pricing_summary(candidate_job_ids) if candidate_job_ids and family_finalized else {}
        except Exception:
            pricing_summary = {}

        if inferred_status == 'done' and not family_finalized:
            if runtime_state in {'accepted', 'preparing', 'processing', 'finalizing'}:
                meta2['status'] = 'processing'
                meta2['progressPct'] = min(99, max(1, int(meta2.get('progressPct') or 99)))
                meta2['progressMessage'] = str(meta2.get('progressMessage') or 'Resultaten verzegelen…')
            else:
                public_meta = {'status': 'error', 'progressPct': 0, 'progressMessage': 'Integriteitscontrole van productie-output is mislukt'}
                return handler._send_json({'meta': public_meta, 'quote': None, 'pricingSummary': {}}, 409)
        public_quote = handler._public_quote_view(quote) if quote is not None and family_finalized else None
        public_pricing_summary = handler._sanitize_public_material_response(pricing_summary or {})
        public_meta = handler._sanitize_public_material_response(meta2 or {})
        return handler._send_json({'meta': public_meta, 'quote': public_quote, 'pricingSummary': public_pricing_summary})


__all__ = (
    "JobLifecycleDependencies",
    "JobLifecycleFacadeService",
)
