from __future__ import annotations

"""Bounded job admission and shared state-capacity reservations.

The composition root injects its existing locks and operating-system probes.
This module owns the accounting rules; FIFO scheduling, worker promotion and
durable job I/O deliberately remain in ``server_py.py`` until later R9E steps.
"""

from typing import Any, Callable


EnvInt = Callable[[str, int], int]


def public_job_queue_limits(env_int: EnvInt) -> tuple[int, int, int]:
    """Return the established bounded worker, waiting-room and per-IP limits."""

    max_active = max(1, min(8, env_int("PUBLIC_JOB_MAX_CONCURRENT", 2)))
    max_queued = max(0, min(64, env_int("PUBLIC_JOB_MAX_QUEUED", 8)))
    max_per_ip = max(
        1,
        min(
            max_active + max_queued,
            env_int("PUBLIC_JOB_MAX_CONCURRENT_PER_IP", 2),
        ),
    )
    return max_active, max_queued, max_per_ip


class PublicJobAdmission:
    """Own admission counters while the composition root retains FIFO state."""

    def __init__(self, *, lock: Any) -> None:
        self.lock = lock
        self.by_ip: dict[str, int] = {}
        self.reserved_by_ip: dict[str, int] = {}
        self.total = 0
        self.reserved_total = 0

    @staticmethod
    def normalize_ip(ip: object) -> str:
        return str(ip or "?")

    def decrement_ip_locked(self, ip: str) -> None:
        current_ip = int(self.by_ip.get(ip, 0) or 0)
        if current_ip <= 1:
            self.by_ip.pop(ip, None)
        else:
            self.by_ip[ip] = current_ip - 1

    def try_acquire(self, ip: object, *, env_int: EnvInt) -> tuple[bool, str]:
        normalized = self.normalize_ip(ip)
        max_active, max_queued, max_per_ip = public_job_queue_limits(env_int)
        with self.lock:
            current_ip = int(self.by_ip.get(normalized, 0) or 0)
            if current_ip >= max_per_ip:
                return False, "ip"
            if self.total >= max_active + max_queued:
                return False, "queue_full"
            self.total += 1
            self.reserved_total += 1
            self.by_ip[normalized] = current_ip + 1
            self.reserved_by_ip[normalized] = (
                int(self.reserved_by_ip.get(normalized, 0) or 0) + 1
            )
            return True, "ok"

    def release_reservation(self, ip: object) -> bool:
        normalized = self.normalize_ip(ip)
        with self.lock:
            reserved_ip = int(self.reserved_by_ip.get(normalized, 0) or 0)
            if reserved_ip <= 0:
                return False
            if reserved_ip == 1:
                self.reserved_by_ip.pop(normalized, None)
            else:
                self.reserved_by_ip[normalized] = reserved_ip - 1
            self.reserved_total = max(0, self.reserved_total - 1)
            self.total = max(0, self.total - 1)
            self.decrement_ip_locked(normalized)
            return True

    def consume_reservation_locked(self, ip: object) -> None:
        """Commit one reservation; caller already owns ``lock``."""

        normalized = self.normalize_ip(ip)
        reserved_ip = int(self.reserved_by_ip.get(normalized, 0) or 0)
        if reserved_ip <= 0 or self.reserved_total <= 0:
            raise RuntimeError("Public optimizer admission reservation is missing")
        if reserved_ip == 1:
            self.reserved_by_ip.pop(normalized, None)
        else:
            self.reserved_by_ip[normalized] = reserved_ip - 1
        self.reserved_total -= 1

    def finish_locked(self, ip: object) -> None:
        """Release one active job; caller already owns ``lock``."""

        normalized = self.normalize_ip(ip)
        self.total = max(0, self.total - 1)
        self.decrement_ip_locked(normalized)

    def cancel_queued_locked(self, ip: object) -> None:
        """Release one queued job; caller already owns ``lock``."""

        self.finish_locked(ip)


class StateCapacityReservations:
    """Own atomic byte/inode admission reservations over injected OS probes."""

    VALID_KINDS = frozenset({"job", "catalog-image-sync"})

    def __init__(self, *, lock: Any) -> None:
        self.lock = lock
        self.records: dict[str, dict[str, Any]] = {}

    @staticmethod
    def _reserved(records: dict[str, dict[str, Any]]) -> tuple[int, int]:
        return (
            sum(max(0, int(item.get("bytes") or 0)) for item in records.values()),
            sum(max(0, int(item.get("inodes") or 0)) for item in records.values()),
        )

    @staticmethod
    def _check(
        *,
        projected: int,
        inode_need: int,
        reserved_bytes: int,
        reserved_inodes: int,
        state_root: Any,
        env_int: EnvInt,
        disk_usage: Callable[[Any], Any],
        statvfs: Callable[[Any], Any] | None,
        capacity_error: Callable[[str], BaseException],
    ) -> dict[str, int]:
        usage = disk_usage(state_root)
        reserve_bytes = max(
            64 * 1024 * 1024,
            env_int("MIN_FREE_STATE_BYTES", 1024 * 1024 * 1024),
        )
        required_free = reserve_bytes + reserved_bytes + projected
        if int(usage.free) < required_free:
            raise capacity_error("Onvoldoende veilige opslagruimte voor deze aanvraag.")
        result = {
            "freeBytes": int(usage.free),
            "requiredFreeBytes": int(required_free),
            "reservedBytes": int(reserved_bytes),
        }
        if statvfs is not None:
            fs = statvfs(state_root)
            free_inodes = int(fs.f_favail)
            reserve_inodes = max(100, env_int("MIN_FREE_STATE_INODES", 10_000))
            required_inodes = reserve_inodes + reserved_inodes + inode_need
            if free_inodes < required_inodes:
                raise capacity_error(
                    "Onvoldoende vrije bestandsposities voor deze aanvraag."
                )
            result.update({
                "freeInodes": free_inodes,
                "requiredFreeInodes": int(required_inodes),
                "reservedInodes": int(reserved_inodes),
            })
        return result

    def enforce(
        self,
        projected_bytes: int,
        projected_inodes: int,
        **dependencies: Any,
    ) -> dict[str, int]:
        projected = max(0, int(projected_bytes))
        inode_need = max(1, int(projected_inodes))
        with self.lock:
            reserved_bytes, reserved_inodes = self._reserved(self.records)
            return self._check(
                projected=projected,
                inode_need=inode_need,
                reserved_bytes=reserved_bytes,
                reserved_inodes=reserved_inodes,
                **dependencies,
            )

    def reserve(
        self,
        reservation_id: str,
        projected_bytes: int,
        projected_inodes: int,
        *,
        reservation_kind: str,
        **dependencies: Any,
    ) -> dict[str, int]:
        kind = str(reservation_kind or "job").strip().lower()
        if kind not in self.VALID_KINDS:
            raise ValueError("Invalid state capacity reservation kind")
        projected = max(0, int(projected_bytes))
        inode_need = max(1, int(projected_inodes))
        with self.lock:
            previous = self.records.get(reservation_id) or {}
            others = {
                key: value for key, value in self.records.items()
                if key != reservation_id
            }
            reserved_bytes, reserved_inodes = self._reserved(others)
            checked = self._check(
                projected=projected,
                inode_need=inode_need,
                reserved_bytes=reserved_bytes,
                reserved_inodes=reserved_inodes,
                **dependencies,
            )
            result = {
                "freeBytes": checked["freeBytes"],
                "requiredFreeBytes": checked["requiredFreeBytes"],
                "reservedBytesBefore": checked["reservedBytes"],
                "reservationBytes": int(projected),
            }
            if "reservedInodes" in checked:
                result.update({
                    "freeInodes": checked["freeInodes"],
                    "requiredFreeInodes": checked["requiredFreeInodes"],
                    "reservedInodesBefore": checked["reservedInodes"],
                    "reservationInodes": int(inode_need),
                })
            self.records[reservation_id] = {
                "bytes": int(projected),
                "inodes": int(inode_need),
                "kind": kind,
            }
            result["replacedReservationBytes"] = max(
                0, int(previous.get("bytes") or 0)
            )
            result["replacedReservationInodes"] = max(
                0, int(previous.get("inodes") or 0)
            )
            return result

    def release(self, reservation_id: str) -> bool:
        with self.lock:
            return self.records.pop(reservation_id, None) is not None

    def totals(self) -> dict[str, int]:
        with self.lock:
            reserved_bytes, reserved_inodes = self._reserved(self.records)
            return {
                "jobs": sum(
                    1 for item in self.records.values()
                    if str(item.get("kind") or "job") == "job"
                ),
                "bytes": reserved_bytes,
                "inodes": reserved_inodes,
            }


__all__ = (
    "PublicJobAdmission",
    "StateCapacityReservations",
    "public_job_queue_limits",
)
