from __future__ import annotations

"""Bounded JobStateRuntime implementation with explicit runtime injection."""

class JobStateRuntime:
    def __init__(self, runtime):
        self._runtime = runtime

    def _get_python_base_cmd(_owner):
        runtime = _owner._runtime
        sys = runtime.sys

        # Use the same Python interpreter as the server for maximum compatibility and speed.
        # (Avoid calling the Windows py launcher for Tool B, which can be slow and may select a different Python version.)
        return [sys.executable]


    def _job_runtime_state_path(_owner, job_id: str) -> Path:
        runtime = _owner._runtime
        JOBS = runtime.JOBS
        Path = runtime.Path
        resolve_identifier_child = runtime.resolve_identifier_child
        validate_job_id = runtime.validate_job_id

        root = resolve_identifier_child(JOBS, validate_job_id(job_id))
        return root / 'job_state.json'


    def _load_job_runtime_state(_owner, job_id: str) -> dict:
        runtime = _owner._runtime
        _job_runtime_state_path = runtime._job_runtime_state_path
        strict_json_load = runtime.strict_json_load

        try:
            value = strict_json_load(_job_runtime_state_path(job_id))
            return value if isinstance(value, dict) else {}
        except Exception:
            return {}


    def _save_job_runtime_state(_owner, job_id: str, state: str, **extra: Any) -> dict:
        runtime = _owner._runtime
        Any = runtime.Any
        _build_job_runtime_state = runtime._build_job_runtime_state
        _job_runtime_state_path = runtime._job_runtime_state_path
        _load_job_runtime_state = runtime._load_job_runtime_state
        _utc_now_iso = runtime._utc_now_iso
        durable_write_json = runtime.durable_write_json
        validate_job_id = runtime.validate_job_id

        job_id = validate_job_id(job_id)
        previous = _load_job_runtime_state(job_id)
        value = _build_job_runtime_state(
            job_id=job_id,
            state=state,
            previous=previous,
            now_iso=_utc_now_iso,
            extra=extra,
        )
        durable_write_json(_job_runtime_state_path(job_id), value)
        return value


    def _job_cancel_requested(_owner, job_id: str) -> bool:
        runtime = _owner._runtime
        _load_job_runtime_state = runtime._load_job_runtime_state
        _runtime_job_cancel_requested = runtime._runtime_job_cancel_requested

        return _runtime_job_cancel_requested(_load_job_runtime_state(job_id))


    def _register_job_process(_owner, master_job_id: str, process: subprocess.Popen) -> None:
        runtime = _owner._runtime
        _OPTIMIZER_PROCESS_SUPERVISOR = runtime._OPTIMIZER_PROCESS_SUPERVISOR
        subprocess = runtime.subprocess

        _OPTIMIZER_PROCESS_SUPERVISOR.register(master_job_id, process)


    def _unregister_job_process(_owner, master_job_id: str, process: subprocess.Popen) -> None:
        runtime = _owner._runtime
        _OPTIMIZER_PROCESS_SUPERVISOR = runtime._OPTIMIZER_PROCESS_SUPERVISOR
        subprocess = runtime.subprocess

        _OPTIMIZER_PROCESS_SUPERVISOR.unregister(master_job_id, process)


    def _terminate_optimizer_process(_owner, 
        process: subprocess.Popen,
        *,
        terminate_timeout: float = 5.0,
        kill_timeout: float = 2.0,
    ) -> int | None:
        runtime = _owner._runtime
        _OPTIMIZER_PROCESS_SUPERVISOR = runtime._OPTIMIZER_PROCESS_SUPERVISOR
        subprocess = runtime.subprocess

        return _OPTIMIZER_PROCESS_SUPERVISOR.terminate(
            process,
            terminate_timeout=terminate_timeout,
            kill_timeout=kill_timeout,
        )


    def _reconcile_interrupted_jobs_on_startup(_owner) -> int:
        runtime = _owner._runtime
        _JOB_RESTART_RECONCILER = runtime._JOB_RESTART_RECONCILER
        _startup_recovery_decision = runtime._startup_recovery_decision

        return _JOB_RESTART_RECONCILER.reconcile(
            recovery_decision=_startup_recovery_decision
        )


    def _find_existing_file(_owner, base_dir: Path, candidates):
        """Return first existing path among candidates (relative to base_dir)."""
        runtime = _owner._runtime
        Path = runtime.Path

        for rel in candidates:
            p = base_dir / rel
            if p.exists():
                return p
        return None


    def _find_placements_any(_owner, output_dir: Path):
        runtime = _owner._runtime
        Path = runtime.Path
        _find_existing_file = runtime._find_existing_file

        # common variants (windows may hide extension; toolb may output without)
        candidates = [Path('placements.json'), Path('placements'), Path('Placements.json'), Path('Placements')]
        p = _find_existing_file(output_dir, candidates)
        if p:
            return p
        for f in output_dir.iterdir():
            if f.is_file() and f.name.lower().startswith('placements'):
                return f
        return None


    def _find_labels_any(_owner, output_dir: Path):
        runtime = _owner._runtime
        Path = runtime.Path
        _find_existing_file = runtime._find_existing_file

        candidates = [Path('labels.json'), Path('labels'), Path('Labels.json'), Path('Labels')]
        p = _find_existing_file(output_dir, candidates)
        if p:
            return p
        for f in output_dir.iterdir():
            if f.is_file() and f.name.lower().startswith('labels'):
                return f
        return None

    EXPORTS = ('_get_python_base_cmd', '_job_runtime_state_path', '_load_job_runtime_state', '_save_job_runtime_state', '_job_cancel_requested', '_register_job_process', '_unregister_job_process', '_terminate_optimizer_process', '_reconcile_interrupted_jobs_on_startup', '_find_existing_file', '_find_placements_any', '_find_labels_any')

__all__ = ("JobStateRuntime",)
