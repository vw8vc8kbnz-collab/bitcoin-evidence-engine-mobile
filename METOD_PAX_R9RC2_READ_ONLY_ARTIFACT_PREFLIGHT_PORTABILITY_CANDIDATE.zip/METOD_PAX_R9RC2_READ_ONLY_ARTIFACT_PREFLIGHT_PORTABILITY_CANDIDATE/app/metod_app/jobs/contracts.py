from __future__ import annotations

"""Pure constants and normalization for the existing durable job states."""

JOB_STATE_SCHEMA_VERSION = 1

ACTIVE_JOB_STATES = frozenset({
    "ACCEPTED",
    "PREPARING",
    "PROCESSING",
    "FINALIZING",
})
CANCELLATION_JOB_STATES = frozenset({"CANCEL_REQUESTED", "CANCELLED"})
TERMINAL_JOB_STATES = frozenset({"DONE", "FAILED", "CANCELLED"})


def canonical_job_state(value: object) -> str:
    """Preserve the server's established ``str(value).upper()`` contract."""

    return str(value).upper()


def state_from_record(record: object) -> str:
    """Read a runtime state exactly as existing lifecycle checks do."""

    if not isinstance(record, dict):
        return ""
    return str(record.get("state") or "").upper()


__all__ = (
    "ACTIVE_JOB_STATES",
    "CANCELLATION_JOB_STATES",
    "JOB_STATE_SCHEMA_VERSION",
    "TERMINAL_JOB_STATES",
    "canonical_job_state",
    "state_from_record",
)

