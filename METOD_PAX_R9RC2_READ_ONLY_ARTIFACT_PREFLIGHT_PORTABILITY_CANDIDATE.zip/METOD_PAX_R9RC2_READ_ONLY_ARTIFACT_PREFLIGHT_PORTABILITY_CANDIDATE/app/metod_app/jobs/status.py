from __future__ import annotations

"""Pure construction and classification of the existing job-state document."""

from typing import Any, Callable, Mapping

from .contracts import (
    ACTIVE_JOB_STATES,
    CANCELLATION_JOB_STATES,
    JOB_STATE_SCHEMA_VERSION,
    canonical_job_state,
    state_from_record,
)


NowIso = Callable[[], str]


def build_job_runtime_state(
    *,
    job_id: str,
    state: object,
    previous: Mapping[str, Any],
    now_iso: NowIso,
    extra: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Build the exact schema-v1 document without owning validation or I/O.

    ``now_iso`` remains injected and is called with the same short-circuit and
    ordering semantics as the former inline owner. Extra values intentionally
    remain last, preserving the established keyword-override behavior.
    """

    value: dict[str, Any] = {
        "schemaVersion": JOB_STATE_SCHEMA_VERSION,
        "jobId": job_id,
        "state": canonical_job_state(state),
        "createdAt": previous.get("createdAt") or now_iso(),
        "updatedAt": now_iso(),
        **dict(extra or {}),
    }
    return value


def job_cancel_requested(record: object) -> bool:
    return state_from_record(record) in CANCELLATION_JOB_STATES


def startup_recovery_decision(record: object) -> tuple[str, dict[str, Any]] | None:
    """Return the existing post-restart durable transition, if required."""

    current = state_from_record(record)
    if current == "CANCEL_REQUESTED":
        return "CANCELLED", {"reason": "startup-reconciliation"}
    if current in ACTIVE_JOB_STATES:
        return "FAILED", {
            "reason": "service-restarted-during-processing",
            "retryable": True,
        }
    return None


__all__ = (
    "build_job_runtime_state",
    "job_cancel_requested",
    "startup_recovery_decision",
)

