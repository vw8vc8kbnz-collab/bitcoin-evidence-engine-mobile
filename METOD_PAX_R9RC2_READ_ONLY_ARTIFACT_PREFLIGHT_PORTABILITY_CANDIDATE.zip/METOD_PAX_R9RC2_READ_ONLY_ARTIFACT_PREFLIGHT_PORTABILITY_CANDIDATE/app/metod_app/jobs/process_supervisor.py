from __future__ import annotations

"""Optimizer process-family ownership without optimizer business logic.

The composition root injects the platform, signals, lock and clock.  This
module owns only registration, dedicated process-group spawning, bounded
termination/reaping and deadline decisions; command construction, polling,
progress and finalization deliberately remain outside this boundary.
"""

from typing import Any, Callable


class OptimizerDeadline:
    """One monotonic family deadline with independently bounded subjobs."""

    def __init__(self, *, monotonic: Callable[[], float], family_deadline: float) -> None:
        self._monotonic = monotonic
        self.family_deadline = float(family_deadline)

    @classmethod
    def start(
        cls,
        *,
        monotonic: Callable[[], float],
        timeout_seconds: float,
    ) -> "OptimizerDeadline":
        return cls(
            monotonic=monotonic,
            family_deadline=float(monotonic()) + float(timeout_seconds),
        )

    def check_family(self, phase: str) -> None:
        if float(self._monotonic()) >= self.family_deadline:
            raise RuntimeError(f"Optimizer job family timeout during {phase}")

    def start_subjob(self, timeout_seconds: float) -> float:
        return float(self._monotonic()) + float(timeout_seconds)

    def timeout_kind(self, subjob_deadline: float) -> str:
        now = float(self._monotonic())
        if now >= self.family_deadline:
            return "job family"
        if now >= float(subjob_deadline):
            return "subjob"
        return ""


class OptimizerProcessSupervisor:
    """Own registered optimizer parents and their dedicated process groups."""

    def __init__(
        self,
        *,
        lock: Any,
        validate_job_id: Callable[[str], str],
        os_module: Any,
        signal_module: Any,
    ) -> None:
        self.lock = lock
        self.processes: dict[str, set[Any]] = {}
        self._validate_job_id = validate_job_id
        self._os = os_module
        self._signal = signal_module

    def register(self, master_job_id: str, process: Any) -> None:
        with self.lock:
            job_id = self._validate_job_id(master_job_id)
            self.processes.setdefault(job_id, set()).add(process)

    def unregister(self, master_job_id: str, process: Any) -> None:
        with self.lock:
            processes = self.processes.get(master_job_id)
            if processes is not None:
                processes.discard(process)
                if not processes:
                    self.processes.pop(master_job_id, None)

    def active(self, master_job_id: str) -> list[Any]:
        with self.lock:
            return list(self.processes.get(self._validate_job_id(master_job_id)) or ())

    def spawn(self, *, popen: Callable[..., Any], command: list[str], **kwargs: Any) -> Any:
        process = popen(
            command,
            start_new_session=(self._os.name == "posix"),
            **kwargs,
        )
        if self._os.name == "posix":
            try:
                setattr(process, "_metod_process_group_id", int(process.pid))
            except Exception:
                pass
        return process

    def terminate(
        self,
        process: Any,
        *,
        terminate_timeout: float = 5.0,
        kill_timeout: float = 2.0,
    ) -> int | None:
        """Terminate one optimizer family and reap the direct child."""

        pgid: int | None = None
        if self._os.name == "posix":
            try:
                candidate = int(
                    getattr(process, "_metod_process_group_id", 0)
                    or self._os.getpgid(int(process.pid))
                )
                if candidate > 1 and candidate != int(self._os.getpgrp()):
                    pgid = candidate
            except Exception:
                pgid = None

        try:
            parent_returncode = process.poll()
        except Exception:
            parent_returncode = None
        if parent_returncode is not None and pgid is None:
            return parent_returncode
        if parent_returncode is not None and pgid is not None:
            try:
                self._os.killpg(pgid, 0)
            except ProcessLookupError:
                return parent_returncode
            except Exception:
                pass

        def send(sig: int, *, force: bool = False) -> None:
            if pgid is not None:
                try:
                    self._os.killpg(pgid, sig)
                    return
                except ProcessLookupError:
                    pass
                except Exception:
                    pass
            try:
                process.kill() if force else process.terminate()
            except Exception:
                pass

        send(self._signal.SIGTERM)
        try:
            process.wait(timeout=max(0.1, float(terminate_timeout)))
        except Exception:
            pass

        group_alive = False
        if pgid is not None:
            try:
                self._os.killpg(pgid, 0)
                group_alive = True
            except ProcessLookupError:
                group_alive = False
            except Exception:
                group_alive = True
        try:
            parent_alive = process.poll() is None
        except Exception:
            parent_alive = True
        if group_alive or parent_alive:
            send(getattr(self._signal, "SIGKILL", self._signal.SIGTERM), force=True)
        try:
            return process.wait(timeout=max(0.1, float(kill_timeout)))
        except Exception:
            try:
                return process.poll()
            except Exception:
                return None
