from __future__ import annotations

"""Bounded JobPayloadRuntime implementation with explicit runtime injection."""

class JobPayloadRuntime:
    def __init__(self, runtime):
        self._runtime = runtime

    def _job_output_limit_message(_owner, size_bytes: int, limit_bytes: int) -> str:
        runtime = _owner._runtime

        try:
            size_mb = float(size_bytes) / (1024.0 * 1024.0)
        except Exception:
            size_mb = 0.0
        try:
            limit_mb = float(limit_bytes) / (1024.0 * 1024.0)
        except Exception:
            limit_mb = 0.0
        return f"Job te groot tijdens verwerking ({size_mb:.1f} MB). Het maximum is {limit_mb:.0f} MB. Splits de job op in meerdere delen."


    def _job_family_size_bytes(_owner, master_root: Path, subjob_roots: list[Path] | None = None) -> int:
        runtime = _owner._runtime
        Path = runtime.Path
        _dir_size_bytes = runtime._dir_size_bytes

        total = 0
        roots = [master_root]
        if isinstance(subjob_roots, list):
            roots.extend([r for r in subjob_roots if isinstance(r, Path)])
        for r in roots:
            try:
                total += _dir_size_bytes(r)
            except Exception:
                pass
        return int(total)


    def _enforce_job_output_limit(_owner, master_root: Path, subjob_roots: list[Path] | None = None, limit_bytes: int | None = None) -> int:
        runtime = _owner._runtime
        JOB_OUTPUT_MAX_BYTES = runtime.JOB_OUTPUT_MAX_BYTES
        Path = runtime.Path
        _job_family_size_bytes = runtime._job_family_size_bytes
        _job_output_limit_message = runtime._job_output_limit_message

        limit = int(limit_bytes or JOB_OUTPUT_MAX_BYTES)
        total = _job_family_size_bytes(master_root, subjob_roots)
        if total > limit:
            raise RuntimeError(_job_output_limit_message(total, limit))
        return total


    def _enforce_state_capacity(_owner, projected_bytes: int, projected_inodes: int = 256) -> dict[str, int]:
        """Check one write against headroom plus every admitted reservation."""
        runtime = _owner._runtime
        STATE_ROOT = runtime.STATE_ROOT
        SafetyContractError = runtime.SafetyContractError
        _STATE_CAPACITY_RESERVATIONS = runtime._STATE_CAPACITY_RESERVATIONS
        _env_int = runtime._env_int
        os = runtime.os
        shutil = runtime.shutil

    
        return _STATE_CAPACITY_RESERVATIONS.enforce(
            projected_bytes,
            projected_inodes,
            state_root=STATE_ROOT,
            env_int=_env_int,
            disk_usage=shutil.disk_usage,
            statvfs=(os.statvfs if hasattr(os, 'statvfs') else None),
            capacity_error=SafetyContractError,
        )


    def _reserve_state_capacity(_owner, 
        job_id: str,
        projected_bytes: int,
        projected_inodes: int = 256,
        *,
        reservation_kind: str = 'job',
    ) -> dict[str, int]:
        """Atomically reserve storage for one admitted state-writing operation.
    
        Disk usage alone is not an admission reservation: concurrent HTTP handlers can
        all observe the same free bytes and independently pass.  The in-process map is
        therefore held under one lock for the full check-and-record operation.  Calling
        this function again for the same job replaces (rather than adds) its reservation,
        and release is idempotent.
        """
        runtime = _owner._runtime
        STATE_ROOT = runtime.STATE_ROOT
        SafetyContractError = runtime.SafetyContractError
        _STATE_CAPACITY_RESERVATIONS = runtime._STATE_CAPACITY_RESERVATIONS
        _env_int = runtime._env_int
        os = runtime.os
        shutil = runtime.shutil
        validate_job_id = runtime.validate_job_id

    
        jid = validate_job_id(job_id)
        return _STATE_CAPACITY_RESERVATIONS.reserve(
            jid,
            projected_bytes,
            projected_inodes,
            reservation_kind=reservation_kind,
            state_root=STATE_ROOT,
            env_int=_env_int,
            disk_usage=shutil.disk_usage,
            statvfs=(os.statvfs if hasattr(os, 'statvfs') else None),
            capacity_error=SafetyContractError,
        )


    def _release_state_capacity_reservation(_owner, job_id: str) -> bool:
        """Release an active/queued job reservation exactly once."""
        runtime = _owner._runtime
        _STATE_CAPACITY_RESERVATIONS = runtime._STATE_CAPACITY_RESERVATIONS
        validate_job_id = runtime.validate_job_id

    
        try:
            jid = validate_job_id(job_id)
        except Exception:
            return False
        return _STATE_CAPACITY_RESERVATIONS.release(jid)


    def _state_capacity_reservation_totals(_owner) -> dict[str, int]:
        """Return a bounded operational snapshot without exposing job identifiers."""
        runtime = _owner._runtime
        _STATE_CAPACITY_RESERVATIONS = runtime._STATE_CAPACITY_RESERVATIONS

    
        return _STATE_CAPACITY_RESERVATIONS.totals()


    def _expand_dxf_payload(_owner, payload: dict) -> dict[str, str]:
        """Return logical PartId -> DXF text from legacy or FIX655 compact transport.
    
        FIX655 sends each identical transformed DXF once (`dxfBlobs`) and maps PartIds
        through `dxfPartRefs`. This reduces customer-side preparation/JSON upload without
        changing the optimizer's proven per-PartId input contract.
        """
        runtime = _owner._runtime
        _env_int = runtime._env_int
        re = runtime.re

        if not isinstance(payload, dict):
            return {}
    
        def _valid_part_id(value: object) -> str:
            raw = str(value or '').strip()
            if not raw or len(raw) > 80 or not re.fullmatch(r'[A-Za-z0-9_-]+', raw):
                raise ValueError('Ongeldige DXF PartId in aanvraag.')
            return raw
    
        legacy = payload.get('dxfParts')
        if isinstance(legacy, dict) and legacy:
            if payload.get('dxfBlobs') or payload.get('dxfPartRefs'):
                raise ValueError('Ambigue DXF-transportvorm in aanvraag.')
            max_entries = _env_int('PUBLIC_DXF_MAX_COUNT', 500)
            if len(legacy) > max_entries:
                raise ValueError('Te veel DXF-bestanden in aanvraag.')
            max_blob_bytes = _env_int('PUBLIC_DXF_BLOB_MAX_BYTES', 2 * 1024 * 1024)
            max_total_bytes = _env_int('PUBLIC_DXF_TOTAL_MAX_BYTES', 12 * 1024 * 1024)
            total_bytes = 0
            out: dict[str, str] = {}
            for part_id, raw_text in legacy.items():
                pid = _valid_part_id(part_id)
                if not isinstance(raw_text, str) or not raw_text.strip():
                    raise ValueError('Lege of ongeldige DXF in aanvraag.')
                blob_bytes = len(raw_text.encode('utf-8', errors='strict'))
                if blob_bytes > max_blob_bytes:
                    raise ValueError('Een DXF-bestand is te groot voor deze aanvraag.')
                total_bytes += blob_bytes
                if total_bytes > max_total_bytes:
                    raise ValueError('Totale DXF-invoer is te groot voor deze aanvraag.')
                out[pid] = raw_text
            return out
    
        blobs = payload.get('dxfBlobs')
        refs = payload.get('dxfPartRefs')
        if not isinstance(blobs, dict) or not isinstance(refs, dict) or not blobs or not refs:
            return {}
        if len(refs) > _env_int('PUBLIC_DXF_MAX_COUNT', 500):
            raise ValueError('Te veel DXF-referenties in aanvraag.')
        if len(blobs) > len(refs):
            raise ValueError('Ongeldige DXF-bibliotheek in aanvraag.')
    
        max_blob_bytes = _env_int('PUBLIC_DXF_BLOB_MAX_BYTES', 2 * 1024 * 1024)
        max_total_bytes = _env_int('PUBLIC_DXF_TOTAL_MAX_BYTES', 12 * 1024 * 1024)
        total_blob_bytes = 0
        safe_blobs: dict[str, str] = {}
        for blob_id, raw_text in blobs.items():
            bid = str(blob_id or '').strip()
            if not bid or len(bid) > 80 or not re.fullmatch(r'[A-Za-z0-9_-]+', bid):
                raise ValueError('Ongeldige DXF-referentie in aanvraag.')
            if not isinstance(raw_text, str) or not raw_text.strip():
                raise ValueError('Lege of ongeldige DXF in aanvraag.')
            blob_bytes = len(raw_text.encode('utf-8', errors='strict'))
            if blob_bytes > max_blob_bytes:
                raise ValueError('Een DXF-bestand is te groot voor deze aanvraag.')
            total_blob_bytes += blob_bytes
            if total_blob_bytes > max_total_bytes:
                raise ValueError('Totale DXF-invoer is te groot voor deze aanvraag.')
            safe_blobs[bid] = raw_text
    
        out: dict[str, str] = {}
        for part_id, blob_id in refs.items():
            pid = _valid_part_id(part_id)
            bid = str(blob_id or '').strip()
            if bid not in safe_blobs:
                raise ValueError('DXF-referentie verwijst naar ontbrekende geometrie.')
            out[pid] = safe_blobs[bid]
        return out


    def _compact_dxf_transport(_owner, dxf_parts: dict[str, str]) -> tuple[dict[str, str], dict[str, str]]:
        """Normalize logical PartId geometry to one content-addressed body per unique DXF.
    
        The public browser transport is already compact, but the earlier server boundary
        expanded it again. Keeping the validated canonical DTO compact prevents 200–250
        equal panels from becoming hundreds of repeated in-memory encodes and filesystem
        entries before the optimizer can publish useful progress.
        """
        runtime = _owner._runtime
        SafetyContractError = runtime.SafetyContractError
        hashlib = runtime.hashlib

        blobs: dict[str, str] = {}
        refs: dict[str, str] = {}
        for part_id, raw_text in (dxf_parts or {}).items():
            text = str(raw_text)
            blob_id = hashlib.sha256(text.encode('utf-8', errors='strict')).hexdigest()
            previous = blobs.get(blob_id)
            if previous is not None and previous != text:
                raise SafetyContractError('DXF content-address collision')
            blobs.setdefault(blob_id, text)
            refs[str(part_id)] = blob_id
        return blobs, refs


    def _validated_canonical_dxf_transport(_owner, payload: dict) -> tuple[dict[str, str], dict[str, str]]:
        """Validate the internal SHA-addressed DTO without expanding it per PartId."""
        runtime = _owner._runtime
        SafetyContractError = runtime.SafetyContractError
        hashlib = runtime.hashlib
        hmac = runtime.hmac
        re = runtime.re

    
        raw_blobs = payload.get('dxfBlobs') if isinstance(payload, dict) else None
        raw_refs = payload.get('dxfPartRefs') if isinstance(payload, dict) else None
        if not isinstance(raw_blobs, dict) or not raw_blobs or not isinstance(raw_refs, dict) or not raw_refs:
            raise SafetyContractError('Canonical compact DXF transport is missing')
        blobs: dict[str, str] = {}
        for raw_digest, raw_text in raw_blobs.items():
            digest = str(raw_digest or '').strip().lower()
            if not re.fullmatch(r'[0-9a-f]{64}', digest) or not isinstance(raw_text, str) or not raw_text:
                raise SafetyContractError('Canonical DXF body is invalid')
            actual = hashlib.sha256(raw_text.encode('utf-8', errors='strict')).hexdigest()
            if not hmac.compare_digest(actual, digest):
                raise SafetyContractError('Canonical DXF body hash mismatch')
            blobs[digest] = raw_text
        refs: dict[str, str] = {}
        for raw_part_id, raw_digest in raw_refs.items():
            part_id = str(raw_part_id or '').strip()
            digest = str(raw_digest or '').strip().lower()
            if not part_id or len(part_id) > 80 or not re.fullmatch(r'[A-Za-z0-9_-]+', part_id):
                raise SafetyContractError('Canonical DXF PartId is invalid')
            if digest not in blobs:
                raise SafetyContractError('Canonical DXF reference has no body')
            refs[part_id] = digest
        return blobs, refs


    def _dxf_transport_stats(_owner, payload: dict) -> dict[str, int]:
        """Return logical/unique DXF counts without re-encoding referenced bodies."""
        runtime = _owner._runtime
        _compact_dxf_transport = runtime._compact_dxf_transport
        _expand_dxf_payload = runtime._expand_dxf_payload

        blobs = (payload or {}).get('dxfBlobs')
        refs = (payload or {}).get('dxfPartRefs')
        if isinstance(blobs, dict) and isinstance(refs, dict) and blobs and refs:
            unique_bytes = sum(len(str(text).encode('utf-8', errors='strict')) for text in blobs.values())
            return {
                'logicalCount': len(refs),
                'uniqueCount': len(blobs),
                'uniqueBytes': int(unique_bytes),
            }
        parts = _expand_dxf_payload(payload or {})
        compact_blobs, compact_refs = _compact_dxf_transport(parts)
        unique_bytes = sum(len(text.encode('utf-8', errors='strict')) for text in compact_blobs.values())
        return {
            'logicalCount': len(compact_refs),
            'uniqueCount': len(compact_blobs),
            'uniqueBytes': int(unique_bytes),
        }


    def _estimate_preflight_job_family_bytes(_owner, payload: dict) -> dict:
        runtime = _owner._runtime
        _dxf_transport_stats = runtime._dxf_transport_stats
        _parse_panels_csv = runtime._parse_panels_csv
        json = runtime.json

        try:
            panels_csv = str((payload or {}).get('panelsCsv') or '')
        except Exception:
            panels_csv = ''
        try:
            pricing_obj = (payload or {}).get('pricing')
            pricing_bytes = len(json.dumps(pricing_obj if pricing_obj is not None else {}, ensure_ascii=False).encode('utf-8'))
        except Exception:
            pricing_bytes = 0
        try:
            job_json_obj = (payload or {}).get('jobJson')
            job_json_bytes = len(json.dumps(job_json_obj if job_json_obj is not None else {}, ensure_ascii=False).encode('utf-8'))
        except Exception:
            job_json_bytes = 0
        try:
            panels_csv_bytes = len(panels_csv.encode('utf-8'))
        except Exception:
            panels_csv_bytes = 0
        try:
            rows = _parse_panels_csv(panels_csv)
        except Exception:
            rows = []
        seen_codes: set[str] = set()
        for r in rows or []:
            try:
                code = str((r or {}).get('MaterialCode') or '').strip()
            except Exception:
                code = ''
            if code:
                seen_codes.add(code)
        material_count = max(1, len(seen_codes))
        try:
            dxf_stats = _dxf_transport_stats(payload or {})
        except Exception:
            dxf_stats = {'logicalCount': 0, 'uniqueCount': 0, 'uniqueBytes': 0}
        dxf_count = int(dxf_stats.get('logicalCount') or 0)
        dxf_unique_count = int(dxf_stats.get('uniqueCount') or 0)
        dxf_total_bytes = int(dxf_stats.get('uniqueBytes') or 0)
        panel_rows = len(rows or [])
        total_qty = 0
        for r in rows or []:
            try:
                qty_raw = r.get('Qty') or r.get('qty') or r.get('quantity') or 1
                qty = int(float(qty_raw) or 0)
            except Exception:
                qty = 0
            if qty <= 0:
                qty = 1
            total_qty += qty
        total_qty = max(total_qty, panel_rows)
        # Lower-bound family input size before optimizer output: master input + all subjob inputs.
        # DXFs are copied to the master job and again to each material subjob, so this dominates
        # disk growth for extreme jobs. In practice, however, very large jobs scale mainly with the
        # effective number of produced panels (Qty totals), because each placed panel fans out into
        # more placement/report/export/zip output even when the DXF templates themselves are reused.
        # We therefore keep the DXF/input estimate but also add a conservative per-panel output floor
        # so absurd jobs (for example hundreds of repeated small parts) are stopped early.
        shared_json_bytes = pricing_bytes + job_json_bytes
        estimated_subjob_csv_total = int(panels_csv_bytes * 1.10)
        family_input_lower_bound = (dxf_total_bytes * (1 + material_count)) + (shared_json_bytes * (1 + material_count)) + panels_csv_bytes + estimated_subjob_csv_total
        per_panel_output_floor = total_qty * 262144  # 256 KB per effective panel as conservative early-stop floor
        projected_total_bytes = int(max((family_input_lower_bound * 1.22) + (dxf_count * 2048) + (panel_rows * 256), family_input_lower_bound + per_panel_output_floor + (material_count * 131072)))
        return {
            'panelRows': int(panel_rows),
            'totalQty': int(total_qty),
            'dxfCount': int(dxf_count),
            'dxfUniqueBodies': int(dxf_unique_count),
            'materialCount': int(material_count),
            'panelsCsvBytes': int(panels_csv_bytes),
            'pricingBytes': int(pricing_bytes),
            'jobJsonBytes': int(job_json_bytes),
            'dxfTotalBytes': int(dxf_total_bytes),
            'familyInputLowerBoundBytes': int(family_input_lower_bound),
            'perPanelOutputFloorBytes': int(per_panel_output_floor),
            'projectedTotalBytes': int(projected_total_bytes),
        }


    def _preflight_job_family_limit_message(_owner, projected_bytes: int, limit_bytes: int) -> str:
        runtime = _owner._runtime

        try:
            projected_mb = float(projected_bytes) / (1024.0 * 1024.0)
        except Exception:
            projected_mb = 0.0
        try:
            limit_mb = float(limit_bytes) / (1024.0 * 1024.0)
        except Exception:
            limit_mb = 0.0
        return f"Deze job is te groot om veilig te verwerken. De geschatte jobgrootte is ongeveer {projected_mb:.1f} MB en dat overschrijdt het maximum van {limit_mb:.0f} MB. Splits de job op in meerdere delen."


    def _get_payload_total_qty(_owner, payload: dict) -> int:
        runtime = _owner._runtime
        _parse_panels_csv = runtime._parse_panels_csv

        try:
            panels_csv = str((payload or {}).get('panelsCsv') or '')
        except Exception:
            panels_csv = ''
        try:
            rows = _parse_panels_csv(panels_csv)
        except Exception:
            rows = []
        total_qty = 0
        for r in rows or []:
            try:
                qty_raw = r.get('Qty') or r.get('qty') or r.get('quantity') or 1
                qty = int(float(qty_raw) or 0)
            except Exception:
                qty = 0
            if qty <= 0:
                qty = 1
            total_qty += qty
        return int(max(total_qty, len(rows or [])))


    def _enforce_job_total_qty_limit(_owner, payload: dict, limit_qty: int = 250) -> int:
        runtime = _owner._runtime
        _get_payload_total_qty = runtime._get_payload_total_qty

        total_qty = _get_payload_total_qty(payload)
        if total_qty > int(limit_qty):
            raise RuntimeError('JOB_TOTAL_QTY_TOO_LARGE::%d::%d' % (total_qty, int(limit_qty)))
        return int(total_qty)


    def _estimate_payload_area_lower_bound(_owner, payload: dict) -> dict:
        runtime = _owner._runtime
        _parse_panels_csv = runtime._parse_panels_csv
        math = runtime.math

        try:
            panels_csv = str((payload or {}).get('panelsCsv') or '')
        except Exception:
            panels_csv = ''
        try:
            pricing = (payload or {}).get('pricing') or {}
        except Exception:
            pricing = {}
        try:
            defaults = pricing.get('defaults') or {}
        except Exception:
            defaults = {}
        try:
            margin = float(defaults.get('sheetMarginMm') or 7.0)
        except Exception:
            margin = 7.0
        try:
            rows = _parse_panels_csv(panels_csv)
        except Exception:
            rows = []
        try:
            materials = pricing.get('materials') or []
        except Exception:
            materials = []
        mat_map = {}
        for m in materials if isinstance(materials, list) else []:
            try:
                code = str((m or {}).get('materialCode') or (m or {}).get('articleNumber') or '').strip()
                if code:
                    mat_map[code] = m or {}
            except Exception:
                continue
        area_by_code = {}
        for r in rows or []:
            try:
                code = str(r.get('MaterialCode') or r.get('materialCode') or '').strip()
            except Exception:
                code = ''
            if not code:
                continue
            try:
                qty = int(float(r.get('Qty') or r.get('qty') or 1) or 1)
            except Exception:
                qty = 1
            if qty <= 0:
                qty = 1
            try:
                w = float(r.get('WidthMm') or r.get('widthMm') or 0.0)
                h = float(r.get('LengthMm') or r.get('lengthMm') or 0.0)
            except Exception:
                w = 0.0
                h = 0.0
            if w <= 0.0 or h <= 0.0:
                continue
            area_by_code[code] = area_by_code.get(code, 0.0) + (w * h * qty)
        by_material = []
        max_lb = 0
        for code, total_area in area_by_code.items():
            m = mat_map.get(code) or {}
            try:
                sheet = m.get('sheetSizeMm') or {}
                sheet_w = float(sheet.get('width') or m.get('sheetWid') or m.get('sheetW') or 0.0)
                sheet_h = float(sheet.get('height') or m.get('sheetLen') or m.get('sheetH') or 0.0)
            except Exception:
                sheet_w = 0.0
                sheet_h = 0.0
            usable_w = max(0.0, sheet_w - 2.0 * margin)
            usable_h = max(0.0, sheet_h - 2.0 * margin)
            usable_area = usable_w * usable_h
            area_lb = max(1, int(math.ceil((total_area / usable_area) - 1e-12))) if usable_area > 0.0 else 0
            by_material.append({'materialCode': code, 'areaLowerBound': int(area_lb), 'totalAreaMm2': float(total_area), 'usableAreaMm2': float(usable_area)})
            max_lb = max(max_lb, int(area_lb))
        return {'maxAreaLowerBound': int(max_lb), 'byMaterial': by_material}

    EXPORTS = ('_job_output_limit_message', '_job_family_size_bytes', '_enforce_job_output_limit', '_enforce_state_capacity', '_reserve_state_capacity', '_release_state_capacity_reservation', '_state_capacity_reservation_totals', '_expand_dxf_payload', '_compact_dxf_transport', '_validated_canonical_dxf_transport', '_dxf_transport_stats', '_estimate_preflight_job_family_bytes', '_preflight_job_family_limit_message', '_get_payload_total_qty', '_enforce_job_total_qty_limit', '_estimate_payload_area_lower_bound')

__all__ = ("JobPayloadRuntime",)
