from __future__ import annotations

"""Bounded ObservabilityRuntime implementation with explicit runtime injection."""

class ObservabilityRuntime:
    def __init__(self, runtime):
        self._runtime = runtime

    def _sse_broadcast(_owner, event: Optional[str] = None, data: Optional[dict] = None) -> None:
        """Broadcast only the tiny public DXF freshness event surface.
    
        FIX657 deliberately drops request/order lifecycle broadcasts. /api/events is public
        and therefore may never disclose request IDs, customer workflow state or errors.
        """
        runtime = _owner._runtime
        Optional = runtime.Optional
        _PUBLIC_SSE_EVENT_ALLOWLIST = runtime._PUBLIC_SSE_EVENT_ALLOWLIST
        _SSE_CLIENTS = runtime._SSE_CLIENTS
        _SSE_CLIENTS_LOCK = runtime._SSE_CLIENTS_LOCK
        datetime = runtime.datetime
        queue = runtime.queue
        timezone = runtime.timezone

        if str(event or '') not in _PUBLIC_SSE_EVENT_ALLOWLIST:
            return
        safe_data = {}
        if str(event or '') == 'dxf_changed':
            # Keep only fields needed by Tool A. Category/filename are harmless but unnecessary
            # for the public client and are intentionally omitted to minimize metadata.
            safe_data = {'dxfVersion': str((data or {}).get('dxfVersion') or '')}
        payload = {
            "event": event,
            "data": safe_data,
            "ts": datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'),
        }
        with _SSE_CLIENTS_LOCK:
            dead: list[queue.Queue] = []
            for q in _SSE_CLIENTS:
                try:
                    q.put_nowait(payload)
                except Exception:
                    dead.append(q)
            if dead:
                _SSE_CLIENTS[:] = [q for q in _SSE_CLIENTS if q not in dead]


    def _sse_handler(_owner, handler) -> None:
        """Handle /api/events SSE stream."""
        runtime = _owner._runtime
        _MAX_SSE_CLIENTS = runtime._MAX_SSE_CLIENTS
        _SSE_CLIENTS = runtime._SSE_CLIENTS
        _SSE_CLIENTS_LOCK = runtime._SSE_CLIENTS_LOCK
        datetime = runtime.datetime
        get_embedded_dxfs_version = runtime.get_embedded_dxfs_version
        json = runtime.json
        queue = runtime.queue
        time = runtime.time
        timezone = runtime.timezone

        q = queue.Queue(maxsize=64)
        with _SSE_CLIENTS_LOCK:
            if len(_SSE_CLIENTS) >= _MAX_SSE_CLIENTS:
                return handler._send_json({'ok': False, 'error': 'Event stream capacity reached'}, 503)
            _SSE_CLIENTS.append(q)
    
        handler.send_response(200)
        handler.send_header('Content-Type', 'text/event-stream; charset=utf-8')
        handler.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
        handler.send_header('Pragma', 'no-cache')
        handler.send_header('Connection', 'keep-alive')
        handler.end_headers()
    
        # Initial hello + current DXF version
        try:
            init = {
                "event": "hello",
                "data": {"dxfVersion": get_embedded_dxfs_version()},
                "ts": datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'),
            }
            handler.wfile.write(f"event: {init['event']}\n".encode('utf-8'))
            handler.wfile.write(f"data: {json.dumps(init)}\n\n".encode('utf-8'))
            handler.wfile.flush()
        except Exception:
            with _SSE_CLIENTS_LOCK:
                try:
                    _SSE_CLIENTS.remove(q)
                except ValueError:
                    pass
            return
    
        last_ping = time.time()
        try:
            while True:
                try:
                    msg = q.get(timeout=5.0)
                    handler.wfile.write(f"event: {msg['event']}\n".encode('utf-8'))
                    handler.wfile.write(f"data: {json.dumps(msg)}\n\n".encode('utf-8'))
                    handler.wfile.flush()
                except queue.Empty:
                    pass
    
                now = time.time()
                if now - last_ping >= 15.0:
                    last_ping = now
                    handler.wfile.write(b": ping\n\n")
                    handler.wfile.flush()
        except Exception:
            pass
        finally:
            with _SSE_CLIENTS_LOCK:
                try:
                    _SSE_CLIENTS.remove(q)
                except ValueError:
                    pass


    def _guess_customer_name_from_payload(_owner, payload: dict | None) -> str:
        runtime = _owner._runtime
        _safe_text = runtime._safe_text

        if not isinstance(payload, dict):
            return ""
        for key in ("customer", "client", "contact"):
            obj = payload.get(key)
            if isinstance(obj, dict):
                for nk in ("name", "fullName", "company", "companyName"):
                    val = _safe_text(obj.get(nk), 120)
                    if val:
                        return val
        for nk in ("customerName", "name", "companyName", "company"):
            val = _safe_text(payload.get(nk), 120)
            if val:
                return val
        return ""


    def _guess_customer_name(_owner, request_id: str = "", payload: dict | None = None, status: dict | None = None) -> str:
        runtime = _owner._runtime
        REQUESTS = runtime.REQUESTS
        _guess_customer_name_from_payload = runtime._guess_customer_name_from_payload
        _safe_id = runtime._safe_id
        _safe_text = runtime._safe_text
        strict_json_load = runtime.strict_json_load

        name = _guess_customer_name_from_payload(payload)
        if name:
            return name
        if isinstance(status, dict):
            for key in ("customerName", "customer", "clientName", "name"):
                val = status.get(key)
                if isinstance(val, dict):
                    val = val.get("name") or val.get("company")
                val = _safe_text(val, 120)
                if val:
                    return val
        rid = _safe_id(request_id or "", 120)
        if rid:
            try:
                fp = REQUESTS / rid / "input" / "submit_payload.json"
                if fp.exists():
                    pl = strict_json_load(fp)
                    return _guess_customer_name_from_payload(pl)
            except Exception:
                pass
        return ""


    def _append_system_event(_owner, *, level: str = "error", component: str = "system", message_user: str, message_tech: str = "", request_id: str = "", job_id: str = "", customer_name: str = "", status: str = "open", details: dict | None = None) -> None:
        runtime = _owner._runtime
        _OBSERVABILITY = runtime._OBSERVABILITY

        return _OBSERVABILITY.append_system_event(
            level=level, component=component, message_user=message_user,
            message_tech=message_tech, request_id=request_id, job_id=job_id,
            customer_name=customer_name, status=status, details=details,
        )


    def _read_system_events(_owner, limit: int = 200) -> list[dict]:
        runtime = _owner._runtime
        _OBSERVABILITY = runtime._OBSERVABILITY

        return _OBSERVABILITY.read_system_events(limit)


    def _observability_sse_client_count(_owner) -> int:
        runtime = _owner._runtime
        _SSE_CLIENTS = runtime._SSE_CLIENTS
        _SSE_CLIENTS_LOCK = runtime._SSE_CLIENTS_LOCK

        with _SSE_CLIENTS_LOCK:
            return len(_SSE_CLIENTS)


    def _observability_public_job_snapshot(_owner) -> dict[str, int]:
        runtime = _owner._runtime
        _PUBLIC_JOB_ACTIVE_TOTAL = runtime._PUBLIC_JOB_ACTIVE_TOTAL
        _PUBLIC_JOB_CREATE_LOCK = runtime._PUBLIC_JOB_CREATE_LOCK
        _PUBLIC_JOB_CREATE_TOTAL = runtime._PUBLIC_JOB_CREATE_TOTAL
        _PUBLIC_JOB_QUEUE = runtime._PUBLIC_JOB_QUEUE
        _PUBLIC_JOB_RESERVED_TOTAL = runtime._PUBLIC_JOB_RESERVED_TOTAL

        with _PUBLIC_JOB_CREATE_LOCK:
            return {
                'admitted': _PUBLIC_JOB_CREATE_TOTAL,
                'active': _PUBLIC_JOB_ACTIVE_TOTAL,
                'waiting': len(_PUBLIC_JOB_QUEUE),
                'reserved': _PUBLIC_JOB_RESERVED_TOTAL,
            }

    EXPORTS = ('_sse_broadcast', '_sse_handler', '_guess_customer_name_from_payload', '_guess_customer_name', '_append_system_event', '_read_system_events', '_observability_sse_client_count', '_observability_public_job_snapshot')

__all__ = ("ObservabilityRuntime",)
