from __future__ import annotations

"""Operational event, readiness and Prometheus ownership.

The composition root injects filesystem durability, redaction, configuration
and live counter snapshots. This module owns the behavior and wire values but
does not import the HTTP server, locks or process/runtime owners.
"""

import hmac
import re
from dataclasses import dataclass
from typing import Any, Callable, Mapping, MutableMapping


@dataclass(frozen=True)
class ObservabilityPaths:
    system_log_file: Callable[[], Any]
    system_dir: Callable[[], Any]
    state_root: Callable[[], Any]
    material_library_path: Callable[[], Any]
    dxf_library_root: Callable[[], Any]
    jobs_root: Callable[[], Any]
    requests_root: Callable[[], Any]
    queue_pending_root: Callable[[], Any]
    queue_processing_root: Callable[[], Any]


@dataclass(frozen=True)
class ObservabilityDependencies:
    paths: ObservabilityPaths
    build: str
    environment: MutableMapping[str, str]
    path_factory: Callable[[Any], Any]
    env_int: Callable[[str, int], int]
    production_hardening_enabled: Callable[[], bool]
    ensure_system_dirs: Callable[[], None]
    now_iso: Callable[[], str]
    safe_text: Callable[[object, int], str]
    redact_sensitive_text: Callable[[object, int], str]
    sanitize_log_value: Callable[..., Any]
    append_jsonl_rotating: Callable[..., None]
    tail_text_lines: Callable[..., list[str]]
    strict_json_load: Callable[[Any], Any]
    strict_json_loads: Callable[[str], Any]
    sha256_file: Callable[[Any], str]
    load_pricing_config: Callable[[], dict[str, Any]]
    ensure_finite_json: Callable[[Any], None]
    durable_write_text: Callable[..., None]
    disk_usage: Callable[[Any], Any]
    statvfs: Callable[[Any], Any] | None
    process_id: Callable[[], int]
    token_hex: Callable[[int], str]
    sse_client_count: Callable[[], int]
    public_job_snapshot: Callable[[], Mapping[str, int]]


class ObservabilityService:
    """Single owner for private events, readiness and metric rendering."""

    def __init__(self, dependencies: ObservabilityDependencies) -> None:
        self.dependencies = dependencies

    def append_system_event(
        self,
        *,
        level: str = "error",
        component: str = "system",
        message_user: str,
        message_tech: str = "",
        request_id: str = "",
        job_id: str = "",
        customer_name: str = "",
        status: str = "open",
        details: dict | None = None,
    ) -> None:
        del customer_name
        deps = self.dependencies
        try:
            deps.ensure_system_dirs()
            record = {
                "ts": deps.now_iso(),
                "level": deps.safe_text(level, 32) or "error",
                "component": deps.safe_text(component, 64) or "system",
                "messageUser": deps.safe_text(message_user, 400),
                "messageTech": deps.redact_sensitive_text(message_tech, 1200),
                "requestId": deps.safe_text(request_id, 120),
                "jobId": deps.safe_text(job_id, 120),
                "customerName": "",
                "status": deps.safe_text(status, 32) or "open",
                "details": deps.sanitize_log_value(
                    details or {}, max_depth=2, max_items=20
                ),
            }
            deps.append_jsonl_rotating(
                deps.paths.system_log_file(),
                record,
                max_bytes=deps.env_int("SYSTEM_LOG_MAX_BYTES", 20 * 1024 * 1024),
                backups=10,
            )
        except Exception:
            pass

    def read_system_events(self, limit: int = 200) -> list[dict]:
        deps = self.dependencies
        path = deps.paths.system_log_file()
        try:
            if not path.exists():
                return []
            lines = deps.tail_text_lines(
                path,
                max(1, int(limit) * 3),
                max_scan_bytes=deps.env_int(
                    "SYSTEM_LOG_MAX_SCAN_BYTES", 2 * 1024 * 1024
                ),
            )
            output = []
            for line in reversed(lines[-max(1, int(limit) * 3):]):
                try:
                    record = deps.strict_json_loads(line)
                    if isinstance(record, dict):
                        output.append(record)
                        if len(output) >= limit:
                            break
                except Exception:
                    continue
            return output
        except Exception:
            return []

    def readiness_report(self) -> tuple[dict[str, Any], int]:
        deps = self.dependencies
        paths = deps.paths
        material_library_path = paths.material_library_path()
        system_dir = paths.system_dir()
        state_root = paths.state_root()
        dxf_library_root = paths.dxf_library_root()
        checks: dict[str, bool] = {}
        details: dict[str, Any] = {}
        try:
            library = deps.strict_json_load(material_library_path)
            records = library.get("records") if isinstance(library, dict) else []
            count = sum(
                1
                for record in records
                if isinstance(record, dict)
                and str(record.get("sourceKind") or "").upper() == "CATALOG_IMPORT"
                and record.get("active") is not False
                and record.get("archived") is not True
                and record.get("published") is True
                and record.get("catalogMissing") is not True
                and record.get("catalogExcluded") is not True
            )
            checks["catalog"] = count >= max(
                1, deps.env_int("PRODUCTION_MIN_CATALOG_RECORDS", 1)
            )
            details["catalogRecords"] = count
        except Exception:
            checks["catalog"] = False

        if deps.production_hardening_enabled():
            try:
                signoff_path = deps.path_factory(
                    deps.environment.get("CATALOG_SIGNOFF_FILE")
                    or (system_dir / "catalog_signoff.json")
                ).expanduser()
                signoff = deps.strict_json_load(signoff_path)
                signed_hash = (
                    str(signoff.get("materialLibrarySha256") or "")
                    if isinstance(signoff, dict)
                    else ""
                )
                checks["catalogSignoff"] = bool(
                    isinstance(signoff, dict)
                    and signoff.get("approved") is True
                    and str(signoff.get("approvedBy") or "").strip()
                    and str(signoff.get("approvedAt") or "").strip()
                    and re.fullmatch(r"[a-f0-9]{64}", signed_hash)
                    and hmac.compare_digest(
                        signed_hash, deps.sha256_file(material_library_path)
                    )
                )
                details["catalogSignoffActor"] = (
                    str(signoff.get("approvedBy") or "")
                    if isinstance(signoff, dict)
                    else ""
                )
            except Exception:
                checks["catalogSignoff"] = False

        try:
            pricing = deps.load_pricing_config()
            deps.ensure_finite_json(pricing)
            checks["pricing"] = (
                isinstance(pricing, dict)
                and str(pricing.get("currency") or "EUR").upper() == "EUR"
            )
        except Exception:
            checks["pricing"] = False

        probe = state_root / (
            f".readiness.{deps.process_id()}.{deps.token_hex(4)}"
        )
        try:
            deps.durable_write_text(probe, "ok\n", mode=0o600)
            checks["stateWritable"] = probe.read_text(encoding="utf-8") == "ok\n"
        except Exception:
            checks["stateWritable"] = False
        finally:
            probe.unlink(missing_ok=True)

        try:
            usage = deps.disk_usage(state_root)
            minimum_free = max(
                64 * 1024 * 1024,
                deps.env_int("MIN_FREE_STATE_BYTES", 1024 * 1024 * 1024),
            )
            checks["freeBytes"] = usage.free >= minimum_free
            details["freeBytes"] = int(usage.free)
            if deps.statvfs is not None:
                filesystem = deps.statvfs(state_root)
                free_inodes = int(filesystem.f_favail)
                checks["freeInodes"] = free_inodes >= max(
                    100, deps.env_int("MIN_FREE_STATE_INODES", 10_000)
                )
                details["freeInodes"] = free_inodes
        except Exception:
            checks["freeBytes"] = False
            checks["freeInodes"] = False

        try:
            checks["dxfLibrary"] = dxf_library_root.is_dir() and any(
                dxf_library_root.rglob("*.dxf")
            )
        except Exception:
            checks["dxfLibrary"] = False
        ok = bool(checks) and all(checks.values())
        return (
            {"ok": ok, "build": deps.build, "checks": checks, "details": details},
            200 if ok else 503,
        )

    def prometheus_metrics(self) -> str:
        deps = self.dependencies
        paths = deps.paths
        material_library_path = paths.material_library_path()
        jobs_root = paths.jobs_root()
        requests_root = paths.requests_root()
        queue_pending_root = paths.queue_pending_root()
        queue_processing_root = paths.queue_processing_root()
        state_root = paths.state_root()
        sse_clients = deps.sse_client_count()
        job_snapshot = deps.public_job_snapshot()
        try:
            catalog = deps.strict_json_load(material_library_path)
            catalog_records = (
                len(catalog.get("records") or []) if isinstance(catalog, dict) else 0
            )
        except Exception:
            catalog_records = 0
        values = {
            "metod_sse_clients": sse_clients,
            "metod_job_creates_active": job_snapshot["active"],
            "metod_job_creates_admitted": job_snapshot["admitted"],
            "metod_job_queue_waiting": job_snapshot["waiting"],
            "metod_job_admissions_reserved": job_snapshot["reserved"],
            "metod_jobs_total": (
                sum(1 for path in jobs_root.iterdir() if path.is_dir())
                if jobs_root.exists()
                else 0
            ),
            "metod_requests_total": (
                sum(1 for path in requests_root.iterdir() if path.is_dir())
                if requests_root.exists()
                else 0
            ),
            "metod_queue_pending": len(list(queue_pending_root.glob("*.json"))),
            "metod_queue_processing": len(
                list(queue_processing_root.glob("*.json"))
            ),
            "metod_catalog_records": catalog_records,
            "metod_state_free_bytes": deps.disk_usage(state_root).free,
        }
        return "".join(
            f"# TYPE {name} gauge\n{name} {int(value)}\n"
            for name, value in values.items()
        )
