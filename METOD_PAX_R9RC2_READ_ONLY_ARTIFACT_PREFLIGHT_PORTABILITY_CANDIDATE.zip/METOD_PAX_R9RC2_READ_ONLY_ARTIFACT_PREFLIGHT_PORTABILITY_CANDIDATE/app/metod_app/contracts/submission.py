"""Pure validation and normalization for the final-submit payload.

This module owns no files, locks, processes, HTTP handlers or mutable global
state.  The behavior is intentionally extracted byte-for-behavior from the
R8Z/R9A server owner and is protected by the paired server oracle.
"""

from __future__ import annotations

import re
from typing import Any

from safety_contracts import ensure_finite_json, finite_number, strict_json_dumps


EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
ALLOWED_SUBMIT_ROOT_KEYS = frozenset(
    {
        "jobId",
        "parentJobId",
        "subjobId",
        "ts",
        "material",
        "customer",
        "note",
        "grainEnabled",
        "quote",
        "cart",
        "extraPanels",
        "priceInclVat",
        "platesTotal",
        "materialsSummary",
        "checkout",
    }
)
FORBIDDEN_FILE_CHARS = frozenset('/\\:*?"<>|')
ALLOWED_USER_TEXT_EXTRA = frozenset(" .,_-")
ALLOWED_NOTE_EXTRA = frozenset(" .,_-")


def clean_text(value: Any, max_len: int = 5000) -> str:
    text = str(value or "")
    if len(text) > int(max_len):
        text = text[: int(max_len)]
    return text


def sanitize_user_text(
    value: Any,
    max_len: int = 240,
    *,
    allow_note_chars: bool = False,
) -> str:
    raw = clean_text(value, max_len * 4 if max_len else 4000)
    extras = ALLOWED_NOTE_EXTRA if allow_note_chars else ALLOWED_USER_TEXT_EXTRA
    out: list[str] = []
    last_space = False
    for character in raw:
        if character in ("\r", "\n", "\t"):
            character = " "
        allowed = character.isalnum() or character in extras
        if not allowed and character in FORBIDDEN_FILE_CHARS:
            character = " "
            allowed = True
        if not allowed:
            continue
        if character.isspace():
            if last_space:
                continue
            out.append(" ")
            last_space = True
        else:
            out.append(character)
            last_space = False
    text = "".join(out).strip()
    if max_len and len(text) > int(max_len):
        text = text[: int(max_len)].rstrip()
    return text


def sanitize_phone_text(value: Any, max_len: int = 60) -> str:
    raw = clean_text(value, max_len * 2)
    out = [character for character in raw if character.isdigit() or character in " +()-"]
    return re.sub(r"\s+", " ", "".join(out)).strip()[:max_len]


def sanitize_postcode_text(value: Any, max_len: int = 16) -> str:
    raw = clean_text(value, max_len * 2)
    out = [character.upper() for character in raw if character.isalnum() or character == " "]
    return re.sub(r"\s+", " ", "".join(out)).strip()[:max_len]


def validate_submit_payload(payload: Any) -> tuple[bool, list[str], dict]:
    errors: list[str] = []
    clean: dict = {}
    if not isinstance(payload, dict):
        return False, ["Payload must be a JSON object."], {}

    if any(key not in ALLOWED_SUBMIT_ROOT_KEYS for key in payload):
        errors.append("Onbekende velden in aanvraagpayload.")

    def safe_id_field(name: str, max_len: int = 200) -> None:
        value = payload.get(name)
        if value in (None, ""):
            return
        normalized = str(value).strip()
        if len(normalized) > min(120, int(max_len)) or not re.fullmatch(
            r"[A-Za-z0-9][A-Za-z0-9_-]*", normalized
        ):
            errors.append(f"Ongeldige waarde voor {name}.")
        else:
            clean[name] = normalized

    safe_id_field("jobId")
    safe_id_field("parentJobId")
    safe_id_field("subjobId")

    if payload.get("ts") not in (None, ""):
        timestamp = str(payload.get("ts")).strip()
        if len(timestamp) > 80:
            errors.append("Tijdstempel is te lang.")
        else:
            clean["ts"] = timestamp

    material = payload.get("material")
    if material is not None:
        if not isinstance(material, (str, dict, list, type(None))):
            errors.append("Materiaalveld heeft een ongeldig type.")
        else:
            clean["material"] = material

    grain_enabled = payload.get("grainEnabled")
    if grain_enabled is not None and not isinstance(grain_enabled, bool):
        errors.append("grainEnabled moet true of false zijn.")
    else:
        clean["grainEnabled"] = bool(grain_enabled) if grain_enabled is not None else None

    note = payload.get("note")
    if note not in (None, ""):
        if not isinstance(note, str):
            errors.append("Opmerking moet tekst zijn.")
        else:
            clean["note"] = sanitize_user_text(note, 4000, allow_note_chars=True)

    customer = payload.get("customer")
    if customer is None:
        customer = {}
    if not isinstance(customer, dict):
        errors.append("Klantgegevens moeten een object zijn.")
        customer = {}
    clean_customer: dict[str, Any] = {}
    allowed_customer_keys = {
        "name",
        "fullName",
        "firstName",
        "lastName",
        "company",
        "companyName",
        "email",
        "mail",
        "phone",
        "tel",
        "telephone",
        "billingAddress",
        "invoiceAddress",
        "address",
        "addressLine1",
        "street",
        "shippingAddress",
        "deliveryAddress",
        "address1",
        "shippingSameAsBilling",
        "houseNumber",
        "postalCode",
        "postcode",
        "city",
        "plaats",
        "country",
        "note",
    }
    for key, value in list(customer.items())[:100]:
        if key not in allowed_customer_keys or value in (None, ""):
            continue
        if key == "shippingSameAsBilling":
            if not isinstance(value, bool):
                errors.append("Klantveld shippingSameAsBilling moet true of false zijn.")
            else:
                clean_customer[key] = bool(value)
            continue
        if not isinstance(value, str):
            errors.append(f"Klantveld {key} moet tekst zijn.")
            continue
        max_len = 320 if key in {"email", "mail"} else 500
        if key in {"email", "mail"}:
            clean_customer[key] = clean_text(value, max_len).strip()
        elif key in {"phone", "tel", "telephone"}:
            clean_customer[key] = sanitize_phone_text(value, min(max_len, 60))
        elif key in {"postalCode", "postcode"}:
            clean_customer[key] = sanitize_postcode_text(value, 16)
        elif key == "note":
            clean_customer[key] = sanitize_user_text(value, max_len, allow_note_chars=True)
        else:
            clean_customer[key] = sanitize_user_text(value, max_len)
    email = str(clean_customer.get("email") or clean_customer.get("mail") or "").strip()
    if email and not EMAIL_RE.match(email):
        errors.append("E-mailadres is ongeldig.")
    clean["customer"] = clean_customer

    quote = payload.get("quote")
    if quote is not None and not isinstance(quote, dict):
        errors.append("Quote moet een object zijn.")
    elif isinstance(quote, dict):
        try:
            ensure_finite_json(quote)
            if len(strict_json_dumps(quote)) > 400000:
                errors.append("Quote is te groot.")
            else:
                clean["quote"] = quote
        except Exception:
            errors.append("Quote kon niet worden verwerkt.")

    materials = payload.get("materialsSummary")
    if materials is not None:
        if not isinstance(materials, list):
            errors.append("materialsSummary moet een lijst zijn.")
        elif len(materials) > 100:
            errors.append("materialsSummary bevat te veel regels.")
        else:
            clean_materials: list[dict[str, Any]] = []
            for index, item in enumerate(materials):
                if not isinstance(item, dict):
                    errors.append(f"materialsSummary regel {index + 1} is ongeldig.")
                    continue
                row: dict[str, Any] = {}
                for key in ("code", "name"):
                    if item.get(key) not in (None, ""):
                        if not isinstance(item.get(key), str):
                            errors.append(
                                f"materialsSummary.{key} op regel {index + 1} moet tekst zijn."
                            )
                        else:
                            row[key] = clean_text(item.get(key), 200)
                if item.get("plates") not in (None, ""):
                    try:
                        row["plates"] = finite_number(
                            item.get("plates"),
                            field="materialsSummary.plates",
                            minimum=0,
                            maximum=10000,
                        )
                    except Exception:
                        errors.append(
                            f"materialsSummary.plates op regel {index + 1} is ongeldig."
                        )
                clean_materials.append(row)
            clean["materialsSummary"] = clean_materials

    for number_name in ("priceInclVat", "platesTotal"):
        if payload.get(number_name) not in (None, ""):
            try:
                clean[number_name] = finite_number(
                    payload.get(number_name),
                    field=number_name,
                    minimum=0,
                    maximum=100000000,
                )
            except Exception:
                errors.append(f"{number_name} is ongeldig.")

    def validate_panel_list(name: str) -> None:
        items = payload.get(name)
        if items is None:
            clean[name] = []
            return
        if not isinstance(items, list):
            errors.append(f"{name} moet een lijst zijn.")
            return
        if len(items) > 1000:
            errors.append(f"{name} bevat te veel regels.")
            return
        clean_items: list[dict[str, Any]] = []
        allowed_keys = {
            "id",
            "type",
            "size",
            "qty",
            "quantity",
            "width",
            "height",
            "length",
            "name",
            "panelName",
            "description",
            "materialCode",
            "materialKey",
            "articleNumber",
            "materialDisplayName",
            "productName",
            "decorName",
            "grainGroupId",
            "grainOrder",
            "rotation",
            "topExt",
            "bottomExt",
            "extensions",
            "edgeBanding",
            "material",
            "hingeSide",
            "swingDirection",
        }
        for index, item in enumerate(items):
            if not isinstance(item, dict):
                errors.append(f"{name} regel {index + 1} is ongeldig.")
                continue
            row: dict[str, Any] = {}
            for key, value in list(item.items())[:80]:
                if key not in allowed_keys:
                    continue
                if isinstance(value, (str, int, float, bool)) or value is None:
                    if isinstance(value, str):
                        if key in {
                            "name",
                            "panelName",
                            "description",
                            "productName",
                            "articleNumber",
                        }:
                            row[key] = sanitize_user_text(value, 240)
                        else:
                            row[key] = clean_text(value, 500)
                    else:
                        row[key] = value
                elif isinstance(value, dict):
                    if key == "edgeBanding":
                        edge_banding = {}
                        for edge_key, edge_value in list(value.items())[:10]:
                            if edge_key in {"top", "bottom", "left", "right"}:
                                edge_banding[edge_key] = bool(edge_value)
                        row[key] = edge_banding
                    elif key == "extensions":
                        extensions = {}
                        for extension_key, extension_value in list(value.items())[:10]:
                            if extension_key in {"top", "bottom"}:
                                try:
                                    extensions[extension_key] = finite_number(
                                        extension_value,
                                        field=f"{name}.{extension_key}",
                                        minimum=0,
                                        maximum=100000,
                                    )
                                except Exception:
                                    pass
                        row[key] = extensions
            quantity = row.get("qty", row.get("quantity", 1))
            try:
                normalized_quantity = int(quantity)
                if normalized_quantity < 1 or normalized_quantity > 10000:
                    raise ValueError
                row["qty"] = normalized_quantity
                row.pop("quantity", None)
            except Exception:
                errors.append(f"{name} regel {index + 1} heeft een ongeldig aantal.")
            for number_key in ("width", "height", "length", "topExt", "bottomExt"):
                if number_key in row and row[number_key] not in (None, ""):
                    try:
                        row[number_key] = finite_number(
                            row[number_key],
                            field=f"{name}.{number_key}",
                            minimum=0,
                            maximum=100000,
                        )
                    except Exception:
                        errors.append(
                            f"{name} regel {index + 1} heeft een ongeldig veld {number_key}."
                        )
            clean_items.append(row)
        clean[name] = clean_items

    validate_panel_list("cart")
    validate_panel_list("extraPanels")

    checkout = payload.get("checkout")
    if checkout is not None:
        if not isinstance(checkout, dict):
            errors.append("checkout moet een object zijn.")
        else:
            clean["checkout"] = checkout

    return len(errors) == 0, errors, clean


__all__ = (
    "ALLOWED_SUBMIT_ROOT_KEYS",
    "EMAIL_RE",
    "clean_text",
    "sanitize_phone_text",
    "sanitize_postcode_text",
    "sanitize_user_text",
    "validate_submit_payload",
)
