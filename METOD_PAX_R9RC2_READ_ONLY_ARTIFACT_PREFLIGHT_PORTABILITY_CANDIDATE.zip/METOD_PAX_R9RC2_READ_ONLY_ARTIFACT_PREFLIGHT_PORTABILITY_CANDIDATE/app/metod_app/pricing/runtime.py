from __future__ import annotations

"""Bounded PricingRuntime implementation with explicit runtime injection."""

class PricingRuntime:
    def __init__(self, runtime):
        self._runtime = runtime

    def _default_pricing_config(_owner) -> dict:
        runtime = _owner._runtime
        EDGE_BAND_PRICE_PER_M = runtime.EDGE_BAND_PRICE_PER_M
        PRICING_SEED_PATH = runtime.PRICING_SEED_PATH
        strict_json_load = runtime.strict_json_load

        base = strict_json_load(PRICING_SEED_PATH)
        return {
            "pricing": base,
            "pricingModel": "catalog_sell_price_incl_vat_v2",
            "sellPricing": {
                "edgeBandPricePerM": EDGE_BAND_PRICE_PER_M,
                "cncCostPerSheet": 0.0,
                "drawingCostFixed": 0.0,
                "transportCostFixed": 0.0,
            },
        }


    def _normalize_pricing_config_schema(_owner, cfg: dict) -> dict:
        """Normalize legacy pricing config without reintroducing a material factor."""
        runtime = _owner._runtime
        EDGE_BAND_PRICE_PER_M = runtime.EDGE_BAND_PRICE_PER_M
        _default_pricing_config = runtime._default_pricing_config
        strict_json_dumps = runtime.strict_json_dumps
        strict_json_loads = runtime.strict_json_loads

        if not isinstance(cfg, dict):
            cfg = _default_pricing_config()
        out = strict_json_loads(strict_json_dumps(cfg))
        if not isinstance(out.get('pricing'), dict):
            out['pricing'] = _default_pricing_config()['pricing']
        sp = out.get('sellPricing') if isinstance(out.get('sellPricing'), dict) else {}
        # sheetPriceFactor is deliberately removed from the active model. Existing material
        # values are migrated once to fixed per-material sell prices before the server starts.
        sp.pop('sheetPriceFactor', None)
        for key, default in (
            ('edgeBandPricePerM', EDGE_BAND_PRICE_PER_M),
            ('cncCostPerSheet', 0.0),
            ('drawingCostFixed', 0.0),
            ('transportCostFixed', 0.0),
        ):
            try:
                sp[key] = float(sp.get(key, default))
            except Exception:
                sp[key] = float(default)
        out['sellPricing'] = sp
        out['pricingModel'] = 'catalog_sell_price_incl_vat_v2'
        return out


    def _load_pricing_config(_owner) -> dict:
        runtime = _owner._runtime
        PRICING_ACTIVE = runtime.PRICING_ACTIVE
        _default_pricing_config = runtime._default_pricing_config
        _ensure_pricing_config_files = runtime._ensure_pricing_config_files
        _normalize_pricing_config_schema = runtime._normalize_pricing_config_schema
        strict_json_load = runtime.strict_json_load

        try:
            _ensure_pricing_config_files()
            if PRICING_ACTIVE.exists():
                return _normalize_pricing_config_schema(strict_json_load(PRICING_ACTIVE))
        except Exception:
            pass
        return _default_pricing_config()


    def _ensure_pricing_config_files(_owner):
        runtime = _owner._runtime
        CONFIG_DIR = runtime.CONFIG_DIR
        PRICING_ACTIVE = runtime.PRICING_ACTIVE
        PRICING_VERSIONS = runtime.PRICING_VERSIONS
        _default_pricing_config = runtime._default_pricing_config
        durable_write_json = runtime.durable_write_json

        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        PRICING_VERSIONS.mkdir(parents=True, exist_ok=True)
        if not PRICING_ACTIVE.exists():
            durable_write_json(PRICING_ACTIVE, _default_pricing_config(), mode=0o640)


    def _save_pricing_config(_owner, new_cfg: dict, actor: str = "admin") -> dict:
        runtime = _owner._runtime
        PRICING_ACTIVE = runtime.PRICING_ACTIVE
        PRICING_AUDIT = runtime.PRICING_AUDIT
        PRICING_VERSIONS = runtime.PRICING_VERSIONS
        _PRICING_CONFIG_LOCK = runtime._PRICING_CONFIG_LOCK
        _ensure_pricing_config_files = runtime._ensure_pricing_config_files
        _env_int = runtime._env_int
        _normalize_pricing_config_schema = runtime._normalize_pricing_config_schema
        _utc_now_iso = runtime._utc_now_iso
        append_jsonl_rotating = runtime.append_jsonl_rotating
        datetime = runtime.datetime
        durable_write_json = runtime.durable_write_json
        secrets = runtime.secrets
        timezone = runtime.timezone

        _ensure_pricing_config_files()
        if not isinstance(new_cfg, dict):
            raise ValueError("pricing config must be an object")
        if "pricing" not in new_cfg or not isinstance(new_cfg["pricing"], dict):
            raise ValueError("missing or invalid 'pricing' object")
        if "sellPricing" not in new_cfg or not isinstance(new_cfg["sellPricing"], dict):
            raise ValueError("missing or invalid 'sellPricing' object")
    
        cfg = _normalize_pricing_config_schema(new_cfg)
        sp = cfg['sellPricing']
        required = ["edgeBandPricePerM", "cncCostPerSheet", "drawingCostFixed", "transportCostFixed"]
        for k in required:
            try:
                sp[k] = float(sp[k])
            except Exception:
                raise ValueError(f"sellPricing '{k}' must be a number")
            if sp[k] < 0:
                raise ValueError(f"sellPricing '{k}' cannot be negative")
    
        with _PRICING_CONFIG_LOCK:
            ts = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f')
            version_path = PRICING_VERSIONS / f"{ts}_{secrets.token_hex(3)}.json"
            rec = {"ts": _utc_now_iso(), "actor": str(actor or 'unknown'), "version": version_path.name, "pricingModel": "catalog_sell_price_incl_vat_v2"}
            audit_limit = _env_int('PRICING_AUDIT_MAX_BYTES', 20 * 1024 * 1024)
            durable_write_json(version_path, cfg, mode=0o640)
            durable_write_json(PRICING_ACTIVE, cfg, mode=0o640)
            append_jsonl_rotating(PRICING_AUDIT, rec, max_bytes=audit_limit, backups=10)
        return {"ok": True, "version": version_path.name, "pricingModel": "catalog_sell_price_incl_vat_v2"}


    def _migrate_legacy_materials_to_direct_sell_prices(_owner) -> dict:
        """Idempotently freeze legacy factor-based prices into per-material direct prices.
    
        This protects the live price level during the transition before the first website CSV
        is published. Prefer the historical retailPriceWithoutTax when available; otherwise
        use the previous active factor exactly once. New calculations never use the factor.
        """
        runtime = _owner._runtime
        CATALOG_VAT_RATE = runtime.CATALOG_VAT_RATE
        CONFIG_DIR = runtime.CONFIG_DIR
        LEGACY_SHEET_PRICE_FACTOR_DEFAULT = runtime.LEGACY_SHEET_PRICE_FACTOR_DEFAULT
        MATERIAL_LIBRARY_PATH = runtime.MATERIAL_LIBRARY_PATH
        PRICING_ACTIVE = runtime.PRICING_ACTIVE
        SYSTEM_DIR = runtime.SYSTEM_DIR
        _atomic_write_json = runtime._atomic_write_json
        _default_pricing_config = runtime._default_pricing_config
        _normalize_pricing_config_schema = runtime._normalize_pricing_config_schema
        _utc_now_iso = runtime._utc_now_iso
        durable_write_json = runtime.durable_write_json
        strict_json_load = runtime.strict_json_load

        result = {'ok': True, 'updated': 0, 'factorUsedForFallback': None}
        try:
            raw_cfg = {}
            if PRICING_ACTIVE.exists():
                try:
                    raw_cfg = strict_json_load(PRICING_ACTIVE)
                except Exception:
                    raw_cfg = {}
            try:
                old_factor = float(((raw_cfg.get('sellPricing') or {}).get('sheetPriceFactor')) or LEGACY_SHEET_PRICE_FACTOR_DEFAULT)
            except Exception:
                old_factor = LEGACY_SHEET_PRICE_FACTOR_DEFAULT
            if old_factor <= 0:
                old_factor = LEGACY_SHEET_PRICE_FACTOR_DEFAULT
            result['factorUsedForFallback'] = old_factor
    
            if MATERIAL_LIBRARY_PATH.exists():
                lib = strict_json_load(MATERIAL_LIBRARY_PATH)
                if isinstance(lib, list):
                    lib = {'source': 'legacy', 'records': lib}
                recs = lib.get('records') if isinstance(lib, dict) else None
                changed = False
                if isinstance(recs, list):
                    for rec in recs:
                        if not isinstance(rec, dict):
                            continue
                        try: incl = float(rec.get('sellPriceInclVatPerSheet') or 0.0)
                        except Exception: incl = 0.0
                        try: ex = float(rec.get('sellPriceExVatPerSheet') or 0.0)
                        except Exception: ex = 0.0
                        if incl > 0 and ex <= 0:
                            rec['sellPriceExVatPerSheet'] = round(incl / (1.0 + CATALOG_VAT_RATE), 6)
                            changed = True; result['updated'] += 1
                        elif ex > 0 and incl <= 0:
                            rec['sellPriceInclVatPerSheet'] = round(ex * (1.0 + CATALOG_VAT_RATE), 2)
                            changed = True; result['updated'] += 1
                        elif incl <= 0 and ex <= 0:
                            legacy_ex = 0.0
                            try:
                                legacy_ex = float(rec.get('retailPriceWithoutTax') or 0.0)
                            except Exception:
                                legacy_ex = 0.0
                            source = 'LEGACY_RETAIL_PRICE_FROZEN'
                            if legacy_ex <= 0:
                                for key in ('purchasePrice', 'inkoopprijs', 'purchasePricePerSheet'):
                                    try: purchase = float(rec.get(key) or 0.0)
                                    except Exception: purchase = 0.0
                                    if purchase > 0:
                                        legacy_ex = purchase * old_factor
                                        source = 'LEGACY_FACTOR_PRICE_FROZEN'
                                        break
                            if legacy_ex > 0:
                                rec['sellPriceExVatPerSheet'] = round(legacy_ex, 6)
                                rec['sellPriceInclVatPerSheet'] = round(legacy_ex * (1.0 + CATALOG_VAT_RATE), 2)
                                rec['priceVatRate'] = CATALOG_VAT_RATE
                                rec['priceSource'] = source
                                changed = True; result['updated'] += 1
                        if not rec.get('sourceKind'):
                            rec['sourceKind'] = 'LEGACY_LIBRARY'
                            changed = True
                    if changed:
                        durable_write_json(MATERIAL_LIBRARY_PATH, lib, mode=0o640)
    
            normalized = _normalize_pricing_config_schema(raw_cfg if isinstance(raw_cfg, dict) and raw_cfg else _default_pricing_config())
            CONFIG_DIR.mkdir(parents=True, exist_ok=True)
            durable_write_json(PRICING_ACTIVE, normalized, mode=0o640)
            marker = SYSTEM_DIR / 'catalog_direct_pricing_migration_v1.json'
            marker.parent.mkdir(parents=True, exist_ok=True)
            _atomic_write_json(marker, {'ranAt': _utc_now_iso(), **result})
        except Exception as e:
            result = {'ok': False, 'updated': result.get('updated', 0), 'error': str(e)}
        return result


    def _ensure_pricing_materials(_owner, pricing: dict, panels_csv: str) -> dict:
        """Build Tool B compatibility material pricing from the internal catalog.
    
        The CSV gross (incl-VAT) sheet price is authoritative. Tool B still expects a legacy
        field named purchasePricePerSheet, so it receives only the accounting ex-VAT equivalent
        for its internal arithmetic while the exact gross CSV cents travel alongside it. No sheet
        factor is used anywhere. Missing/invalid catalog prices are blocking errors.
        """
        runtime = _owner._runtime
        CATALOG_ALLOWED_THICKNESSES_MM = runtime.CATALOG_ALLOWED_THICKNESSES_MM
        CATALOG_VAT_RATE = runtime.CATALOG_VAT_RATE
        SafetyContractError = runtime.SafetyContractError
        _material_direct_sell_incl_vat = runtime._material_direct_sell_incl_vat
        _material_lookup_snapshot = runtime._material_lookup_snapshot
        _parse_panels_csv = runtime._parse_panels_csv
        finite_number = runtime.finite_number
        re = runtime.re

        if not isinstance(pricing, dict):
            raise SafetyContractError('Live pricing config is invalid')
        defaults = pricing.get('defaults')
        if not isinstance(defaults, dict):
            raise SafetyContractError('Live pricing defaults are missing')
        finite_number(defaults.get('sheetMarginMm'), field='pricing.defaults.sheetMarginMm', minimum=0.0, maximum=100.0)
        finite_number(defaults.get('nestingGapMm'), field='pricing.defaults.nestingGapMm', minimum=0.0, maximum=100.0)
        finite_number(defaults.get('kerfMm'), field='pricing.defaults.kerfMm', minimum=0.0, maximum=100.0)
        edge_cfg = pricing.get('edgeBanding')
        if not isinstance(edge_cfg, dict):
            raise SafetyContractError('Live edgeBanding config is missing')
        finite_number(edge_cfg.get('defaultLossPercent'), field='edgeBanding.defaultLossPercent', minimum=0.0, maximum=100.0)
    
        rows = _parse_panels_csv(panels_csv)
        codes = []
        seen = set()
        for r in rows:
            c = str(r.get('MaterialCode') or '').strip()
            if c and c not in seen:
                seen.add(c); codes.append(c)
        if not codes:
            raise ValueError('Geen materiaal gevonden in de paneellijst.')
    
        # Reuse the same mutation-sensitive catalog snapshot as public
        # canonicalization/status.  Re-reading and rebuilding 597 rows here for both
        # preflight and the background worker caused lock contention between customers.
        by_code = _material_lookup_snapshot().get('catalogByInternal') or {}
    
        def norm_decor(rec: dict, fallback: str) -> str:
            prod = str(rec.get('productName') or rec.get('publicName') or '').strip()
            if prod:
                return prod
            dn = str(rec.get('decorName') or '').strip()
            if dn and not re.fullmatch(r"[0-9]+(\.[0-9]+)?", dn):
                return dn
            return fallback
    
        def from_catalog(code: str) -> dict:
            rec = by_code.get(code)
            if not isinstance(rec, dict):
                raise ValueError(f'Materiaal {code} bestaat niet meer in de actieve Decor Library.')
            if str(rec.get('sourceKind') or '').upper() != 'CATALOG_IMPORT' or rec.get('catalogMissing') is True:
                raise ValueError(f'Materiaal {code} komt niet uit de actieve gepubliceerde CSV-catalogus.')
            if rec.get('active') is False or rec.get('archived') is True or rec.get('published') is False or rec.get('catalogExcluded') is True:
                raise ValueError(f'Materiaal {code} is niet beschikbaar voor nieuwe aanvragen.')
            try: t = float(rec.get('thicknessMm') or 0.0)
            except Exception: t = 0.0
            if not any(abs(t - float(x)) < 1e-9 for x in CATALOG_ALLOWED_THICKNESSES_MM):
                raise ValueError(f'Materiaal {code} heeft geen toegestane plaatdikte.')
            try: w = int(float(rec.get('sheetWid') or rec.get('sheetWidthMm') or 0))
            except Exception: w = 0
            try: h = int(float(rec.get('sheetLen') or rec.get('sheetHeightMm') or rec.get('height') or 0))
            except Exception: h = 0
            if w <= 0 or h <= 0:
                raise ValueError(f'Materiaal {code} heeft geen geldige plaatmaat.')
            sell_inc = _material_direct_sell_incl_vat(rec)
            if sell_inc <= 0:
                raise ValueError(f'Geen geldige directe verkoopprijs incl. BTW voor materiaal {code}.')
            # Tool B still has an old field name and performs arithmetic on an ex-VAT basis.
            # Feed it the accounting equivalent, but carry the exact CSV gross price alongside
            # it so every authoritative customer/Admin surface can preserve the original cents.
            sell_ex = float(sell_inc) / (1.0 + CATALOG_VAT_RATE)
            return {
                'materialCode': code,
                'decorName': norm_decor(rec, code),
                'thicknessMm': t,
                'sheetSizeMm': {'width': w, 'height': h},
                'purchasePricePerSheet': float(sell_ex),  # Tool B compatibility only
                'sellPriceExVatPerSheet': float(sell_ex),
                'sellPriceInclVatPerSheet': round(float(sell_inc), 2),
                'priceVatRate': CATALOG_VAT_RATE,
                'materialPriceBasis': 'CSV_SELL_PRICE_INCL_VAT',
                'pricingSource': str(rec.get('priceSource') or 'CSV_SALE_PRICE_INCL_VAT'),
            }
    
        # Always rebuild only the materials used by this job from the live catalog. This
        # avoids stale request/browser pricing and makes Admin CSV publication authoritative.
        pricing['materials'] = [from_catalog(code) for code in codes]
        by_material = {str(item['materialCode']): item for item in pricing['materials']}
        for row in rows:
            code = str(row.get('MaterialCode') or '').strip()
            authoritative = by_material.get(code)
            if not authoritative:
                raise SafetyContractError(f'{row.get("PartId")}: materiaal ontbreekt in serverpricing')
            row_thickness = finite_number(row.get('ThicknessMm'), field=f'{row.get("PartId")}.ThicknessMm', minimum=0.1, maximum=100.0)
            if abs(row_thickness - float(authoritative['thicknessMm'])) > 1e-9:
                raise SafetyContractError(f'{row.get("PartId")}: dikte wijkt af van servercatalogus')
        pricing['currency'] = 'EUR'
        pricing['units'] = 'mm'
        pricing['pricingModel'] = 'catalog_sell_price_incl_vat_v2'
        return pricing


    def _apply_sell_pricing_to_quote(_owner, quote: dict) -> dict:
        """Apply the mixed VAT contract without changing the business price.
    
        - Sheet material: the CSV amount is already a SELL price INCLUDING 21% VAT and its
          exact cents are authoritative.
        - Edge banding, CNC, drawing and transport: Admin values remain EXCLUDING VAT.
        - No general material factor exists.
    
        Tool B still calculates with an ex-VAT compatibility field, but this postprocessor
        makes the gross material truth explicit and publishes an authoritative incl-VAT total.
        """
        runtime = _owner._runtime
        CATALOG_VAT_RATE = runtime.CATALOG_VAT_RATE
        CNC_COST_PER_SHEET = runtime.CNC_COST_PER_SHEET
        DRAWING_COST_FIXED = runtime.DRAWING_COST_FIXED
        EDGE_BAND_PRICE_PER_M = runtime.EDGE_BAND_PRICE_PER_M
        TRANSPORT_COST_FIXED = runtime.TRANSPORT_COST_FIXED
        _load_pricing_config = runtime._load_pricing_config
        json = runtime.json

        if not isinstance(quote, dict):
            return quote
        q = json.loads(json.dumps(quote))
        q.setdefault('sellPricing', {})
        cfg = _load_pricing_config()
        sp = cfg.get('sellPricing') if isinstance(cfg, dict) and isinstance(cfg.get('sellPricing'), dict) else {}
        edge_band_price_per_m = float(sp.get('edgeBandPricePerM', EDGE_BAND_PRICE_PER_M))
        cnc_cost_per_sheet = float(sp.get('cncCostPerSheet', CNC_COST_PER_SHEET))
        drawing_cost_fixed = float(sp.get('drawingCostFixed', DRAWING_COST_FIXED))
        transport_cost_fixed = float(sp.get('transportCostFixed', TRANSPORT_COST_FIXED))
        q['sellPricing'].update({
            'pricingModel': 'catalog_sell_price_incl_vat_v2',
            'materialPriceBasis': 'CSV_SELL_PRICE_INCL_VAT',
            'materialVatRate': CATALOG_VAT_RATE,
            'otherCostsPriceBasis': 'ADMIN_EX_VAT',
            'edgeBandPricePerM': edge_band_price_per_m,
            'cncCostPerSheet': cnc_cost_per_sheet,
            'drawingCostFixed': drawing_cost_fixed,
            'transportCostFixed': transport_cost_fixed,
        })
        q['sellPricing'].pop('sheetPriceFactor', None)
    
        if 'totalsRaw' not in q and isinstance(q.get('totals'), dict):
            q['totalsRaw'] = dict(q['totals'])
    
        mats = q.get('materials') if isinstance(q.get('materials'), list) else []
        total_sheets = 0
        sheet_sell_total_ex = 0.0
        sheet_sell_total_inc = 0.0
        for m in mats:
            if not isinstance(m, dict):
                continue
            sc = int(m.get('sheetCount') or 0)
            total_sheets += sc
    
            unit_inc = m.get('sellPriceInclVatPerSheet')
            unit_ex = m.get('sellPriceExVatPerSheet')
            raw_unit = m.get('sheetUnitCost')
            if unit_ex is None:
                unit_ex = raw_unit
            try:
                unit_inc = float(unit_inc) if unit_inc is not None else 0.0
            except Exception:
                unit_inc = 0.0
            try:
                unit_ex = float(unit_ex) if unit_ex is not None else 0.0
            except Exception:
                unit_ex = 0.0
            if unit_inc <= 0 and unit_ex > 0:
                unit_inc = round(unit_ex * (1.0 + CATALOG_VAT_RATE), 2)
            if unit_ex <= 0 and unit_inc > 0:
                unit_ex = unit_inc / (1.0 + CATALOG_VAT_RATE)
    
            # Preserve website cents exactly. The accounting net equivalent is derived from
            # the full gross material subtotal so VAT rounding cannot alter the CSV amount.
            unit_inc = round(unit_inc, 2) if unit_inc > 0 else 0.0
            gross_total = round(unit_inc * sc + 1e-9, 2)
            net_total = round(gross_total / (1.0 + CATALOG_VAT_RATE) + 1e-9, 2) if gross_total > 0 else 0.0
    
            m['sheetUnitCostRaw'] = raw_unit
            m['sheetUnitCost'] = unit_ex  # legacy ex-VAT compatibility field
            m['sellPriceExVatPerSheet'] = unit_ex
            m['sellPriceInclVatPerSheet'] = unit_inc
            m['materialPriceBasis'] = 'CSV_SELL_PRICE_INCL_VAT'
            m['sheetCostTotalRaw'] = m.get('sheetCostTotal')
            m['sheetCostTotal'] = net_total  # legacy/ex-VAT compatibility
            m['sheetCostTotalExVat'] = net_total
            m['sheetCostTotalInclVat'] = gross_total
            sheet_sell_total_ex += net_total
            sheet_sell_total_inc += gross_total
    
        edge = q.get('edgeBanding') if isinstance(q.get('edgeBanding'), dict) else {}
        bwl = edge.get('byCodeMetersWithLoss') if isinstance(edge.get('byCodeMetersWithLoss'), dict) else {}
        try:
            meters_with_loss = sum(float(v or 0.0) for v in bwl.values())
        except Exception:
            meters_with_loss = 0.0
        edge_sell_total = round(meters_with_loss * edge_band_price_per_m + 1e-9, 2)
        if edge:
            edge.setdefault('sell', {})
            edge['sell'].update({
                'priceBasis': 'ADMIN_EX_VAT',
                'pricePerM': edge_band_price_per_m,
                'metersWithLossTotal': meters_with_loss,
                'edgeCostTotalRaw': edge.get('edgeCostTotal'),
            })
            by_code_cost = {}
            for code, mtrs in bwl.items():
                try:
                    by_code_cost[str(code)] = round(float(mtrs or 0.0) * edge_band_price_per_m + 1e-9, 2)
                except Exception:
                    by_code_cost[str(code)] = 0.0
            edge['byCodeCostRaw'] = edge.get('byCodeCost')
            edge['byCodeCost'] = by_code_cost
            edge['edgeCostTotalRaw'] = edge.get('edgeCostTotal')
            edge['edgeCostTotal'] = edge_sell_total
    
        cnc_total = round(total_sheets * cnc_cost_per_sheet + 1e-9, 2)
        drawing_total = round(drawing_cost_fixed + 1e-9, 2)
        transport_total = round(transport_cost_fixed + 1e-9, 2)
        q['extraCosts'] = {
            'priceBasis': 'ADMIN_EX_VAT',
            'sheetCount': total_sheets,
            'cncCostPerSheet': cnc_cost_per_sheet,
            'cncCostTotal': cnc_total,
            'drawingCostFixed': drawing_cost_fixed,
            'drawingCostTotal': drawing_total,
            'transportCostFixed': transport_cost_fixed,
            'transportCostTotal': transport_total,
        }
    
        other_ex = round(edge_sell_total + cnc_total + drawing_total + transport_total + 1e-9, 2)
        material_ex = round(sheet_sell_total_ex + 1e-9, 2)
        material_inc = round(sheet_sell_total_inc + 1e-9, 2)
        subtotal_ex = round(material_ex + other_ex + 1e-9, 2)
        other_vat = round(other_ex * CATALOG_VAT_RATE + 1e-9, 2)
        total_inc = round(material_inc + other_ex + other_vat + 1e-9, 2)
        vat_total = round(total_inc - subtotal_ex + 1e-9, 2)
        material_vat = round(material_inc - material_ex + 1e-9, 2)
    
        totals = q.get('totals') if isinstance(q.get('totals'), dict) else {}
        totals['sheetCostTotal'] = material_ex  # legacy ex-VAT compatibility
        totals['sheetCostTotalExVat'] = material_ex
        totals['sheetCostTotalInclVat'] = material_inc
        totals['edgeCostTotal'] = edge_sell_total
        totals['cncCostTotal'] = cnc_total
        totals['drawingCostTotal'] = drawing_total
        totals['transportCostTotal'] = transport_total
        totals['otherCostsExVat'] = other_ex
        totals['materialVatIncluded'] = material_vat
        totals['otherCostsVat'] = other_vat
        totals['subtotalExVat'] = subtotal_ex
        totals['vatAmount'] = vat_total
        totals['grandTotal'] = subtotal_ex  # legacy name retained as ex-VAT total
        totals['totalInclVat'] = total_inc
        totals['grandTotalInclVat'] = total_inc
        q['totals'] = totals
        q['totalInclVat'] = total_inc
        q['grandTotalInclVat'] = total_inc
        return q


    def _format_eur(_owner, x: float) -> str:
        runtime = _owner._runtime

        try:
            v = float(x or 0.0)
        except Exception:
            v = 0.0
        # EU format with comma decimals
        s = f"{v:,.2f}"
        s = s.replace(",", "X").replace(".", ",").replace("X", ".")
        return f"€{s}"


    def _format_m(_owner, x: float) -> str:
        runtime = _owner._runtime

        try:
            v = float(x or 0.0)
        except Exception:
            v = 0.0
        s = f"{v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
        return f"{s} m"


    def _extract_pricing_from_any(_owner, source: dict | None) -> dict:
        runtime = _owner._runtime

        out = {
            'materialsTotal': None,
            'materialsTotalInclVat': None,
            'materialsVatIncluded': None,
            'otherCostsExVat': None,
            'otherCostsVat': None,
            'edgeBandTotal': None,
            'cncTotal': None,
            'drawingTotal': None,
            'transportTotal': None,
            'subtotalExVat': None,
            'vatAmount': None,
            'totalInclVat': None,
            'currency': 'EUR',
        }
        if not isinstance(source, dict):
            return out
    
        def _to_float(v):
            try:
                if v is None or v == '':
                    return None
                return float(v)
            except Exception:
                return None
    
        def _first_num(*pairs):
            for obj, keys in pairs:
                if not isinstance(obj, dict):
                    continue
                for key in keys:
                    val = _to_float(obj.get(key))
                    if val is not None:
                        return round(val, 2)
            return None
    
        def _walk(obj, keyset, results):
            if isinstance(obj, dict):
                for k, v in obj.items():
                    lk = str(k).strip().lower()
                    if lk in keyset:
                        val = _to_float(v)
                        if val is not None:
                            results.append(val)
                    _walk(v, keyset, results)
            elif isinstance(obj, list):
                for it in obj:
                    _walk(it, keyset, results)
    
        totals = source.get('totals') if isinstance(source.get('totals'), dict) else {}
        sell = source.get('sellPricing') if isinstance(source.get('sellPricing'), dict) else {}
        extra = source.get('extraCosts') if isinstance(source.get('extraCosts'), dict) else {}
    
        out['materialsTotalInclVat'] = _first_num(
            (totals, ('sheetCostTotalInclVat','materialsTotalInclVat','materialTotalInclVat')),
            (sell, ('sheetCostTotalInclVat','materialsTotalInclVat','materialTotalInclVat')),
            (extra, ('sheetCostTotalInclVat','materialsTotalInclVat','materialTotalInclVat')),
            (source, ('sheetCostTotalInclVat','materialsTotalInclVat','materialTotalInclVat')),
        )
        out['materialsVatIncluded'] = _first_num(
            (totals, ('materialVatIncluded','materialsVatIncluded')),
            (sell, ('materialVatIncluded','materialsVatIncluded')),
            (source, ('materialVatIncluded','materialsVatIncluded')),
        )
        out['otherCostsExVat'] = _first_num(
            (totals, ('otherCostsExVat',)), (sell, ('otherCostsExVat',)),
            (extra, ('otherCostsExVat',)), (source, ('otherCostsExVat',)),
        )
        out['otherCostsVat'] = _first_num(
            (totals, ('otherCostsVat',)), (sell, ('otherCostsVat',)),
            (extra, ('otherCostsVat',)), (source, ('otherCostsVat',)),
        )
    
        out['subtotalExVat'] = _first_num(
            (totals, ('subtotalExVat','grandTotal','total','subtotal','totalExVat','subTotalExVat')),
            (sell, ('grandTotal','total','subtotal','totalExVat','subTotalExVat')),
            (extra, ('grandTotal','total','subtotal','totalExVat','subTotalExVat')),
            (source, ('grandTotal','total','subtotal','totalExVat','subTotalExVat')),
        )
        out['totalInclVat'] = _first_num(
            (totals, ('grandTotalInclVat','totalInclVat','inclVatTotal','totalPriceInclVat')),
            (sell, ('grandTotalInclVat','totalInclVat','inclVatTotal','totalPriceInclVat')),
            (extra, ('grandTotalInclVat','totalInclVat','inclVatTotal','totalPriceInclVat')),
            (source, ('grandTotalInclVat','totalInclVat','inclVatTotal','totalPriceInclVat')),
        )
        out['vatAmount'] = _first_num(
            (totals, ('vatAmount','btw','vat','taxAmount')),
            (sell, ('vatAmount','btw','vat','taxAmount')),
            (extra, ('vatAmount','btw','vat','taxAmount')),
            (source, ('vatAmount','btw','vat','taxAmount')),
        )
        if out['vatAmount'] is None and out['subtotalExVat'] is not None and out['totalInclVat'] is not None:
            out['vatAmount'] = round(out['totalInclVat'] - out['subtotalExVat'], 2)
    
        out['materialsTotal'] = _first_num(
            (totals, ('sheetCostTotalExVat','sheetCostTotal','materialsTotal','materialTotal')),
            (sell, ('sheetCostTotalExVat','sheetCostTotal','materialsTotal','materialTotal')),
            (source, ('sheetCostTotalExVat','sheetCostTotal','materialsTotal','materialTotal')),
        )
    
        mats = source.get('materials') if isinstance(source.get('materials'), list) else []
        if mats and out['materialsTotal'] is None:
            total = 0.0
            has = False
            for m in mats:
                if not isinstance(m, dict):
                    continue
                for key in ('sellPrice','sellPriceTotal','totalSellPrice','sheetSellPriceTotal','sheetCostTotal','sheetTotal','materialTotal','materialsTotal'):
                    val = _to_float(m.get(key))
                    if val is not None:
                        total += val
                        has = True
                        break
            if has:
                out['materialsTotal'] = round(total, 2)
        if out['materialsTotal'] is None:
            out['materialsTotal'] = _first_num(
                (sell, ('materialsTotal','materialTotal','sheetTotal','sheetCostTotal')),
                (extra, ('materialsTotal','materialTotal','sheetTotal','sheetCostTotal')),
                (source, ('materialsTotal','materialTotal','sheetTotal','sheetCostTotal')),
            )
    
        comp_map = {
            'edgeBandTotal': {
                'edgebandtotal','edgebandselltotal','edgebandcost','edgecosttotal','edgecosttotalraw',
                'kantenband','kantenbandtotaal'
            },
            'cncTotal': {'cnctotal','cnccosttotal','routingtotal','cnc','routingcost'},
            'drawingTotal': {
                'drawingtotal','drawingcost','drawingcosttotal','setupcost','setuptotal',
                'tekenwerk','tekenkosten'
            },
            'transportTotal': {
                'transporttotal','transportcost','transportcosttotal','shippingtotal','deliverytotal',
                'transport','verzendkosten'
            },
        }
        for target, keys in comp_map.items():
            out[target] = _first_num((sell, tuple(keys)), (extra, tuple(keys)), (source, tuple(keys)))
            if out[target] is None:
                vals = []
                _walk(source, keys, vals)
                if vals:
                    out[target] = round(sum(vals), 2)
        return out


    def _aggregate_materials_from_subjob_quotes(_owner, parent_job_id: str) -> list[dict]:
        runtime = _owner._runtime
        JOBS = runtime.JOBS
        _pricing_aggregate_materials_from_subjob_quotes = runtime._pricing_aggregate_materials_from_subjob_quotes

        return _pricing_aggregate_materials_from_subjob_quotes(JOBS, parent_job_id)


    def _parse_calculation_summary_totals(_owner, job_root: Path) -> dict:
        runtime = _owner._runtime
        Path = runtime.Path
        _pricing_parse_calculation_summary_totals = runtime._pricing_parse_calculation_summary_totals

        return _pricing_parse_calculation_summary_totals(job_root)

    EXPORTS = ('_default_pricing_config', '_normalize_pricing_config_schema', '_load_pricing_config', '_ensure_pricing_config_files', '_save_pricing_config', '_migrate_legacy_materials_to_direct_sell_prices', '_ensure_pricing_materials', '_apply_sell_pricing_to_quote', '_format_eur', '_format_m', '_extract_pricing_from_any', '_aggregate_materials_from_subjob_quotes', '_parse_calculation_summary_totals')

__all__ = ("PricingRuntime",)
