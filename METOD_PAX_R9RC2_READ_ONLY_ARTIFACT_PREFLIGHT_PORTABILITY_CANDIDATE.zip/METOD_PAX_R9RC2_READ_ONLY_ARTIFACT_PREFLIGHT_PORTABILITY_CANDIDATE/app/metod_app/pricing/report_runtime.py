from __future__ import annotations

"""Bounded PricingReportRuntime implementation with explicit runtime injection."""

class PricingReportRuntime:
    def __init__(self, runtime):
        self._runtime = runtime

    def _write_human_calculation_summary(_owner, job_root: Path, request_status: dict | None = None) -> None:
        """Write a human-readable calculation summary using the same pricing source as Admin/Tool A."""
        runtime = _owner._runtime
        CATALOG_VAT_RATE = runtime.CATALOG_VAT_RATE
        CNC_COST_PER_SHEET = runtime.CNC_COST_PER_SHEET
        DRAWING_COST_FIXED = runtime.DRAWING_COST_FIXED
        EDGE_BAND_PRICE_PER_M = runtime.EDGE_BAND_PRICE_PER_M
        JOBS = runtime.JOBS
        Path = runtime.Path
        TRANSPORT_COST_FIXED = runtime.TRANSPORT_COST_FIXED
        _aggregate_materials_from_subjob_quotes = runtime._aggregate_materials_from_subjob_quotes
        _best_material_name = runtime._best_material_name
        _customer_block_from_sources = runtime._customer_block_from_sources
        _extract_admin_pricing_summary = runtime._extract_admin_pricing_summary
        _find_request_status_for_job = runtime._find_request_status_for_job
        _format_eur = runtime._format_eur
        _format_m = runtime._format_m
        _job_material_context = runtime._job_material_context
        _load_pricing_config = runtime._load_pricing_config
        _load_request_payload = runtime._load_request_payload
        _parse_panels_csv = runtime._parse_panels_csv
        durable_write_text = runtime.durable_write_text
        strict_json_load = runtime.strict_json_load

        input_dir = job_root / "input"
        output_dir = job_root / "output"
        panels_path = input_dir / "panels.csv"
    
        jid = job_root.name
        parent_jid = jid.split('__mat_')[0] if '__mat_' in jid else jid
        candidate_job_ids = []
        for x in [parent_jid, jid]:
            if x and x not in candidate_job_ids:
                candidate_job_ids.append(x)
    
        if request_status is None:
            request_status = _find_request_status_for_job(jid)
        request_payload = _load_request_payload(str(request_status.get('requestId') or '')) if isinstance(request_status, dict) else {}
    
        quote = {}
        pricing = {}
        for cand in candidate_job_ids:
            try:
                qp = JOBS / cand / 'output' / 'quote.json'
                if qp.exists():
                    quote = strict_json_load(qp)
                    break
            except Exception:
                pass
        try:
            pp = input_dir / 'pricing.json'
            if pp.exists():
                pricing = strict_json_load(pp)
        except Exception:
            pricing = {}
    
        subjob_quote = {}
        try:
            sqp = output_dir / 'quote.json'
            if sqp.exists():
                subjob_quote = strict_json_load(sqp)
        except Exception:
            subjob_quote = {}
    
        if not isinstance(quote, dict):
            quote = {}
        if not isinstance(subjob_quote, dict):
            subjob_quote = {}
        if not isinstance(pricing, dict):
            pricing = {}
        if not panels_path.exists() and not quote and not subjob_quote and not request_status and not request_payload:
            return
    
        mat_meta = {}
        for m in (pricing.get("materials") or []):
            if not isinstance(m, dict):
                continue
            code = str(m.get("materialCode") or "")
            if not code:
                continue
            mat_meta[code] = {
                "productName": (m.get("productName") or m.get("materialDisplayName") or m.get("decorName") or m.get("name") or "").strip(),
                "articleNumber": (m.get("articleNumber") or m.get("materialCode") or "").strip(),
                "thicknessMm": m.get("thicknessMm"),
                "sheetSizeMm": m.get("sheetSizeMm") or {},
                "purchasePricePerSheet": m.get("purchasePricePerSheet"),
                "purchasePrice": m.get("purchasePrice"),
                "sellPriceExVatPerSheet": m.get("sellPriceExVatPerSheet"),
                "sellPriceInclVatPerSheet": m.get("sellPriceInclVatPerSheet"),
            }
    
        per_mat_meters = {}
        panel_qty_total = 0
        try:
            if panels_path.exists():
                rows = _parse_panels_csv(panels_path.read_text(encoding="utf-8"))
                for r in rows:
                    code = str(r.get("MaterialCode") or r.get("materialCode") or "").strip()
                    qty = int(float(r.get("Qty") or 0) or 0)
                    panel_qty_total += qty
                    if not code:
                        continue
                    L = float(r.get("LengthMm") or 0.0)
                    W = float(r.get("WidthMm") or 0.0)
                    mtrs = 0.0
                    for k, dim in (("H1", L), ("H2", L), ("W1", W), ("W2", W)):
                        try:
                            ec = int(float(r.get(k) or 0) or 0)
                        except Exception:
                            ec = 0
                        if ec != 0:
                            mtrs += (dim / 1000.0) * qty
                    per_mat_meters[code] = per_mat_meters.get(code, 0.0) + mtrs
        except Exception:
            per_mat_meters = {}
    
        mats_used = []
        for src in (subjob_quote, quote, request_payload.get('quote') if isinstance(request_payload, dict) else {}):
            if isinstance(src, dict) and isinstance(src.get('materials'), list) and src.get('materials'):
                mats_used = src.get('materials')
                break
        if not mats_used:
            mats_payload = request_payload.get('materialsSummary') if isinstance(request_payload, dict) and isinstance(request_payload.get('materialsSummary'), list) else []
            if mats_payload:
                mats_used = []
                for m in mats_payload:
                    if not isinstance(m, dict):
                        continue
                    code = str(m.get('code') or m.get('articleNumber') or m.get('materialCode') or '').strip()
                    name = _best_material_name(code, m.get('materialDisplayName'), m.get('materialName'), m.get('name'), m.get('productName'), m.get('decorName'))
                    mats_used.append({
                        'materialCode': code,
                        'productName': name,
                        'sheetCount': m.get('plates') or m.get('sheetCount') or 0,
                        'thicknessMm': m.get('thicknessMm') or (mat_meta.get(code) or {}).get('thicknessMm'),
                        'sheetSizeMm': m.get('sheetSizeMm') or (mat_meta.get(code) or {}).get('sheetSizeMm') or {},
                        'sheetUnitCostRaw': (mat_meta.get(code) or {}).get('purchasePricePerSheet') or (mat_meta.get(code) or {}).get('purchasePrice'),
                    })
        # For parent/master jobs, trust real material subjob quotes over request payload placeholders.
        subjob_mats = _aggregate_materials_from_subjob_quotes(parent_jid)
        if subjob_mats:
            try:
                existing_total = 0
                for _m in mats_used:
                    if isinstance(_m, dict):
                        existing_total += int(float(_m.get('sheetCount') or _m.get('plates') or 0) or 0)
            except Exception:
                existing_total = 0
            try:
                sub_total = 0
                for _m in subjob_mats:
                    if isinstance(_m, dict):
                        sub_total += int(float(_m.get('sheetCount') or _m.get('plates') or 0) or 0)
            except Exception:
                sub_total = 0
            if sub_total > existing_total:
                mats_used = subjob_mats
    
        if not mats_used:
            derived_codes = []
            for c in list(per_mat_meters.keys()) + list(mat_meta.keys()):
                c = str(c or '').strip()
                if c and c not in derived_codes:
                    derived_codes.append(c)
            if derived_codes:
                mats_used = []
                total_guess = 0
                for code in derived_codes:
                    meta = mat_meta.get(code, {})
                    unit_raw = meta.get('purchasePricePerSheet') or meta.get('purchasePrice')
                    cnt = 0
                    try:
                        # FIX654: opaque __mat_### suffix is not a material code. Resolve it from panels.csv.
                        if '__mat_' in jid:
                            _ctx_code = str((_job_material_context(job_root) or {}).get('materialCode') or '').strip()
                            if code == _ctx_code:
                                cnt = 1
                    except Exception:
                        cnt = 0
                    # Parent / mixed-material fallback: when panels exist for a material but the quote did not report
                    # sheet counts yet, assume at least one sheet for that used material instead of dropping material+CNC.
                    if cnt <= 0 and code in per_mat_meters:
                        cnt = 1
                    mats_used.append({
                        'materialCode': code,
                        'productName': meta.get('productName') or _best_material_name(code, ''),
                        'sheetCount': cnt,
                        'thicknessMm': meta.get('thicknessMm'),
                        'sheetSizeMm': meta.get('sheetSizeMm') or {},
                        'sheetUnitCostRaw': unit_raw,
                    })
                    total_guess += cnt
                if total_guess == 0 and len(mats_used) == 1:
                    mats_used[0]['sheetCount'] = 1
    
        summary = _extract_admin_pricing_summary(candidate_job_ids, request_status)
    
        sell = quote.get("sellPricing") if isinstance(quote.get("sellPricing"), dict) else {}
        if not sell and isinstance(subjob_quote.get('sellPricing'), dict):
            sell = subjob_quote.get('sellPricing')
        live_sell = {}
        try:
            _live_cfg = _load_pricing_config()
            if isinstance(_live_cfg, dict) and isinstance(_live_cfg.get('sellPricing'), dict):
                live_sell = dict(_live_cfg.get('sellPricing') or {})
        except Exception:
            live_sell = {}
        # IMPORTANT: never fall back to stale request-payload pricing for the final calculation summary.
        # The summary must reflect the currently active live pricing config (or the quote that was just
        # post-processed from that config), especially when Admin values were changed right before a run.
        sell_effective = dict(live_sell)
        try:
            if isinstance(sell, dict) and sell:
                sell_effective.update(sell)
        except Exception:
            pass
        sell = sell_effective
    
        # Recalculate component totals from the live/quote source of truth. The exact CSV
        # material amount INCLUDING VAT is authoritative; a net equivalent is maintained only
        # for fiscal subtotal/VAT reporting. No general material factor exists.
        derived_materials_total = None
        derived_materials_total_inc = None
        derived_edge_total = None
        derived_cnc_total = None
        derived_drawing_total = None
        derived_transport_total = None
        try:
            if mats_used:
                mats_sell = 0.0
                mats_sell_inc = 0.0
                mats_have = False
                mats_inc_have = False
                for m in mats_used:
                    if not isinstance(m, dict):
                        continue
                    cnt = int(float(m.get('sheetCount') or 0) or 0)
                    code = str(m.get('materialCode') or '').strip()
                    meta_for_code = mat_meta.get(code) or {}
                    unit_raw = m.get('sellPriceExVatPerSheet')
                    if unit_raw is None:
                        unit_raw = m.get('sheetUnitCostRaw')
                    if unit_raw is None:
                        unit_raw = meta_for_code.get('sellPriceExVatPerSheet')
                    if unit_raw is None:
                        unit_raw = meta_for_code.get('purchasePricePerSheet') or meta_for_code.get('purchasePrice')
                    unit_inc = m.get('sellPriceInclVatPerSheet')
                    if unit_inc is None:
                        unit_inc = meta_for_code.get('sellPriceInclVatPerSheet')
                    try:
                        unit_raw = float(unit_raw)
                    except Exception:
                        unit_raw = None
                    try:
                        unit_inc = float(unit_inc)
                    except Exception:
                        unit_inc = None
                    effective_cnt = cnt if cnt > 0 else (1 if len(mats_used) == 1 else 0)
                    if unit_raw is not None and effective_cnt > 0:
                        mats_sell += round(unit_raw * effective_cnt, 2)
                        mats_have = True
                    if unit_inc is not None and effective_cnt > 0:
                        # CSV sale price including VAT is authoritative. Preserve it exactly
                        # instead of reconstructing it from a two-decimal ex-VAT subtotal.
                        mats_sell_inc += round(unit_inc * effective_cnt, 2)
                        mats_inc_have = True
                if mats_have:
                    derived_materials_total = round(mats_sell, 2)
                if mats_inc_have:
                    derived_materials_total_inc = round(mats_sell_inc, 2)
        except Exception:
            pass
        try:
            total_m = sum(float(v or 0.0) for v in (per_mat_meters or {}).values())
            if total_m > 0:
                derived_edge_total = round(total_m * float((sell or {}).get('edgeBandPricePerM', EDGE_BAND_PRICE_PER_M)), 2)
        except Exception:
            pass
        try:
            total_sheets_guess = 0
            for m in mats_used:
                if isinstance(m, dict):
                    total_sheets_guess += int(float(m.get('sheetCount') or 0) or 0)
            if total_sheets_guess <= 0 and len(mats_used) == 1:
                total_sheets_guess = 1
            if total_sheets_guess > 0:
                derived_cnc_total = round(total_sheets_guess * float((sell or {}).get('cncCostPerSheet', CNC_COST_PER_SHEET)), 2)
        except Exception:
            pass
        try:
            derived_drawing_total = round(float((sell or {}).get('drawingCostFixed', DRAWING_COST_FIXED)), 2)
        except Exception:
            pass
        try:
            derived_transport_total = round(float((sell or {}).get('transportCostFixed', TRANSPORT_COST_FIXED)), 2)
        except Exception:
            pass
    
        # Always let the live/quote-derived component values win for the final human summary.
        # This prevents stale request payload summaries from leaking old transport/factor values.
        if derived_materials_total is not None:
            summary['materialsTotal'] = derived_materials_total  # accounting ex-VAT equivalent
        if derived_materials_total_inc is not None:
            summary['materialsTotalInclVat'] = derived_materials_total_inc  # exact CSV gross truth
        if derived_edge_total is not None:
            summary['edgeBandTotal'] = derived_edge_total
        if derived_cnc_total is not None:
            summary['cncTotal'] = derived_cnc_total
        if derived_drawing_total is not None:
            summary['drawingTotal'] = derived_drawing_total
        if derived_transport_total is not None:
            summary['transportTotal'] = derived_transport_total
    
        subtotal_ex = 0.0
        for key in ('materialsTotal','edgeBandTotal','cncTotal','drawingTotal','transportTotal'):
            try:
                subtotal_ex += float(summary.get(key) or 0.0)
            except Exception:
                pass
        subtotal_ex = round(subtotal_ex, 2) if subtotal_ex > 0 else 0.0
        if subtotal_ex:
            summary['subtotalExVat'] = subtotal_ex
        # Preserve the website's authoritative per-sheet incl-VAT material price exactly.
        # Only the remaining Admin-configurable costs receive VAT on top.
        other_ex = 0.0
        for _key in ('edgeBandTotal','cncTotal','drawingTotal','transportTotal'):
            try:
                other_ex += float(summary.get(_key) or 0.0)
            except Exception:
                pass
        other_ex = round(other_ex, 2)
        if derived_materials_total_inc is not None:
            material_inc = round(float(derived_materials_total_inc), 2)
            material_ex = round(float(summary.get('materialsTotal') or (material_inc / (1.0 + CATALOG_VAT_RATE))), 2)
            material_vat = round(material_inc - material_ex, 2)
            other_vat = round(other_ex * CATALOG_VAT_RATE, 2)
            total_inc = round(material_inc + other_ex + other_vat, 2)
            summary['materialsVatIncluded'] = material_vat
            summary['otherCostsExVat'] = other_ex
            summary['otherCostsVat'] = other_vat
        else:
            total_inc = round(subtotal_ex * (1.0 + CATALOG_VAT_RATE), 2) if subtotal_ex else 0.0
            material_vat = None
            other_vat = None
        if total_inc:
            summary['totalInclVat'] = total_inc
        vat_amt = round(total_inc - subtotal_ex, 2) if total_inc and subtotal_ex else 0.0
        if vat_amt or total_inc:
            summary['vatAmount'] = vat_amt
    
        lines = []
        lines.append("METOD One-Click – Berekeningsoverzicht")
        lines.append("=" * 40)
        lines.append(f"Job: {jid}")
        lines.append("")
        lines.extend(_customer_block_from_sources(request_status, request_payload))
    
        lines.append("Configuratie")
        lines.append("-" * 40)
        if not panel_qty_total and isinstance(request_payload, dict):
            try:
                panel_qty_total = len(request_payload.get('cart') or []) + len(request_payload.get('extraPanels') or [])
            except Exception:
                panel_qty_total = 0
        if panel_qty_total:
            lines.append(f"Aantal panelen: {panel_qty_total}")
        total_sheets = 0
        if mats_used:
            for m in mats_used:
                if isinstance(m, dict):
                    try:
                        total_sheets += int(m.get('sheetCount') or m.get('plates') or 0)
                    except Exception:
                        pass
        if total_sheets:
            lines.append(f"Aantal platen: {total_sheets}")
        lines.append("")
    
        lines.append("Materialen / platen")
        lines.append("-" * 40)
        lines.append("Materiaalprijs: directe CSV-verkoopprijs per plaat; deze prijs is al inclusief 21% BTW")
        lines.append("")
        if mats_used:
            for m in mats_used:
                if not isinstance(m, dict):
                    continue
                code = str(m.get("materialCode") or m.get('code') or "")
                meta = mat_meta.get(code, {})
                name = meta.get("productName") or m.get('productName') or m.get('materialDisplayName') or m.get('decorName') or m.get('name') or ''
                art = meta.get("articleNumber") or code
                th = m.get("thicknessMm") or meta.get("thicknessMm") or ""
                cnt = int(m.get("sheetCount") or m.get('plates') or 0)
                ss = m.get("sheetSizeMm") or meta.get("sheetSizeMm") or {}
                sw = ss.get("width") or ss.get("Width") or ""
                sh = ss.get("height") or ss.get("Height") or ""
                size_str = f"{int(sw)}×{int(sh)} mm" if sw and sh else ""
                lines.append(f"- {name} (artikel: {art})")
                detail = f"  Dikte: {th} mm | Platen: {cnt}"
                if size_str:
                    detail += f" | Plaatmaat: {size_str}"
                lines.append(detail)
                unit_sell_inc = m.get("sellPriceInclVatPerSheet")
                if unit_sell_inc is None:
                    unit_sell_inc = meta.get("sellPriceInclVatPerSheet")
                if unit_sell_inc is None:
                    unit_sell_ex = m.get("sellPriceExVatPerSheet")
                    if unit_sell_ex is None:
                        unit_sell_ex = m.get("sheetUnitCostRaw")
                    if unit_sell_ex is None:
                        unit_sell_ex = meta.get("purchasePricePerSheet") or meta.get("purchasePrice")
                    try:
                        unit_sell_inc = round(float(unit_sell_ex) * (1.0 + CATALOG_VAT_RATE), 2) if unit_sell_ex is not None else None
                    except Exception:
                        unit_sell_inc = None
                try:
                    unit_sell_inc = round(float(unit_sell_inc), 2) if unit_sell_inc is not None else None
                except Exception:
                    unit_sell_inc = None
                cost_sell_inc = None
                if unit_sell_inc is not None and cnt:
                    try:
                        cost_sell_inc = round(float(unit_sell_inc) * float(cnt) + 1e-9, 2)
                    except Exception:
                        cost_sell_inc = None
                if unit_sell_inc is not None:
                    lines.append(f"  Verkoopprijs plaat incl. btw: {_format_eur(unit_sell_inc)} p/st")
                if cost_sell_inc is not None:
                    lines.append(f"  Subtotaal plaatmateriaal incl. btw: {_format_eur(cost_sell_inc)}")
                lines.append("")
        else:
            mats_payload = request_payload.get('materialsSummary') if isinstance(request_payload, dict) and isinstance(request_payload.get('materialsSummary'), list) else []
            if mats_payload:
                for m in mats_payload:
                    if not isinstance(m, dict):
                        continue
                    code = str(m.get('code') or m.get('articleNumber') or m.get('materialCode') or '').strip()
                    name = _best_material_name(code, m.get('materialDisplayName'), m.get('materialName'), m.get('name'), m.get('productName'), m.get('decorName'))
                    cnt = m.get('plates') or ''
                    lines.append(f"- {name or code} (artikel: {code})")
                    if cnt:
                        lines.append(f"  Platen: {cnt}")
                    lines.append("")
            else:
                lines.append("(geen materialen gevonden in quote.json)")
                lines.append("")
    
        lines.append("Kantenband (m¹) per decor")
        lines.append("-" * 40)
        if per_mat_meters:
            for code, mtrs in sorted(per_mat_meters.items(), key=lambda kv: kv[0]):
                meta = mat_meta.get(code, {})
                name = meta.get("productName") or _best_material_name(code, '')
                art = meta.get("articleNumber") or code
                label = f"{name} (artikel: {art})" if name else f"Artikel: {art}"
                lines.append(f"- {label}: {_format_m(mtrs)}")
            lines.append("")
            total_m = sum(per_mat_meters.values())
            try:
                edge_price_live = float((sell or {}).get('edgeBandPricePerM', EDGE_BAND_PRICE_PER_M))
            except Exception:
                edge_price_live = EDGE_BAND_PRICE_PER_M
            lines.append(f"Totaal kantenband: {_format_m(total_m)}")
            lines.append(f"Prijs kantenband: {_format_eur(edge_price_live)} per meter")
            lines.append("")
        else:
            lines.append("(geen kantenband gevonden)")
            lines.append("")
    
        lines.append("Kostenopbouw")
        lines.append("-" * 40)
        if summary.get('materialsTotalInclVat') is not None:
            lines.append(f"Plaatmateriaal incl. btw: {_format_eur(summary['materialsTotalInclVat'])}")
        elif summary.get('materialsTotal') is not None:
            lines.append(f"Plaatmateriaal excl. btw (legacy fallback): {_format_eur(summary['materialsTotal'])}")
        if summary.get('edgeBandTotal') is not None:
            lines.append(f"Kantenband excl. btw:      {_format_eur(summary['edgeBandTotal'])}")
        if summary.get('cncTotal') is not None:
            lines.append(f"CNC excl. btw:             {_format_eur(summary['cncTotal'])}")
        if summary.get('drawingTotal') is not None:
            lines.append(f"Tekenen excl. btw:         {_format_eur(summary['drawingTotal'])}")
        if summary.get('transportTotal') is not None:
            lines.append(f"Transport excl. btw:       {_format_eur(summary['transportTotal'])}")
        lines.append("")
        lines.append("Fiscale uitsplitsing")
        lines.append("-" * 40)
        if summary.get('materialsTotal') is not None:
            lines.append(f"Plaatmateriaal netto-equivalent: {_format_eur(summary['materialsTotal'])}")
        if summary.get('materialsVatIncluded') is not None:
            lines.append(f"BTW reeds in plaatprijs:          {_format_eur(summary['materialsVatIncluded'])}")
        if summary.get('otherCostsExVat') is not None:
            lines.append(f"Overige kosten excl. btw:         {_format_eur(summary['otherCostsExVat'])}")
        if summary.get('otherCostsVat') is not None:
            lines.append(f"BTW over overige kosten:          {_format_eur(summary['otherCostsVat'])}")
        lines.append("")
        lines.append(f"Subtotaal excl. btw: {_format_eur(subtotal_ex)}")
        lines.append(f"BTW (21%):          {_format_eur(vat_amt)}")
        lines.append(f"Totaal incl. btw:    {_format_eur(total_inc)}")
        lines.append("")
    
        out_txt = "\n".join(lines).strip() + "\n"
        durable_write_text(output_dir / 'calculation_summary.txt', out_txt)

    EXPORTS = ('_write_human_calculation_summary',)

__all__ = ("PricingReportRuntime",)
