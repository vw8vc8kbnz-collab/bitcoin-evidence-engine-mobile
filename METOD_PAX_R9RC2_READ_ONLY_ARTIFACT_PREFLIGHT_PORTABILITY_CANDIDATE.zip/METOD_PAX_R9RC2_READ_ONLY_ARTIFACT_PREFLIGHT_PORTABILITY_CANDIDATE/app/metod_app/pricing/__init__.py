"""Pure pricing contracts for the R9 modularization line."""
