from __future__ import annotations

"""Pure material-price truth and accounting conversion helpers.

The published CSV amount including VAT remains authoritative. This module does
not load pricing configuration, catalog state or quote data and performs no I/O.
"""

from typing import Any


VAT_RATE = 0.21


def material_direct_sell_incl_vat(record: dict[str, Any]) -> float:
    """Return the authoritative direct sheet sell price including VAT."""

    if not isinstance(record, dict):
        return 0.0
    for key in (
        "sellPriceInclVatPerSheet",
        "salePriceInclVatPerSheet",
        "directSellPriceInclVatPerSheet",
    ):
        try:
            value = float(record.get(key) or 0.0)
            if value > 0:
                return round(value, 2)
        except Exception:
            pass
    for key in (
        "sellPriceExVatPerSheet",
        "salePriceExVatPerSheet",
        "directSellPriceExVatPerSheet",
    ):
        try:
            value = float(record.get(key) or 0.0)
            if value > 0:
                return round(value * (1.0 + VAT_RATE), 2)
        except Exception:
            pass
    return 0.0


def material_direct_sell_ex_vat(record: dict[str, Any]) -> float:
    """Return the accounting net equivalent of the authoritative gross price."""

    including_vat = material_direct_sell_incl_vat(record)
    return (including_vat / (1.0 + VAT_RATE)) if including_vat > 0 else 0.0


__all__ = (
    "VAT_RATE",
    "material_direct_sell_ex_vat",
    "material_direct_sell_incl_vat",
)
