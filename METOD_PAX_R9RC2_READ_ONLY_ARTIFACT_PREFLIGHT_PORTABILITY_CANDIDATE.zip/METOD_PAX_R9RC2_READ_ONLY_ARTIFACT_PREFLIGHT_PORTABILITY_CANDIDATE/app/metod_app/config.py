"""Immutable runtime configuration and pure environment readers.

Only values that the legacy server already captured once at import time belong
in :class:`RuntimeConfig`. Request-, queue- and maintenance limits that were
read dynamically remain dynamic through ``env_int`` and ``env_flag``.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Mapping


Environment = Mapping[str, str]


def _environment(environment: Environment | None) -> Environment:
    return os.environ if environment is None else environment


def env_int(name: str, default: int, *, environment: Environment | None = None) -> int:
    """Return the existing forgiving integer environment projection."""

    try:
        raw = str(_environment(environment).get(name, "")).strip()
        return int(raw) if raw else int(default)
    except Exception:
        return int(default)


def env_flag(
    name: str,
    default: bool = False,
    *,
    environment: Environment | None = None,
) -> bool:
    """Return the existing boolean environment projection."""

    raw = str(_environment(environment).get(name, "")).strip().lower()
    if not raw:
        return bool(default)
    return raw in ("1", "true", "yes", "on", "prod", "production")


def split_env_csv(
    name: str,
    default: str = "",
    *,
    environment: Environment | None = None,
) -> list[str]:
    """Read a comma-separated setting without caching mutable environment state."""

    raw = str(_environment(environment).get(name, default) or "")
    return [item.strip() for item in raw.split(",") if item.strip()]


def production_hardening_enabled(*, environment: Environment | None = None) -> bool:
    source = _environment(environment)
    if env_flag("PRODUCTION_HARDENING", False, environment=source) or env_flag(
        "ADMIN_HASH_ONLY", False, environment=source
    ):
        return True
    app_environment = str(source.get("APP_ENV", "")).strip().lower()
    return app_environment in ("prod", "production")


@dataclass(frozen=True, slots=True)
class RuntimeConfig:
    """Values intentionally fixed for the lifetime of one server process."""

    host: str
    port: int
    public_host: str
    public_base_url: str
    admin_session_idle_seconds: int
    admin_session_absolute_seconds: int
    max_sse_clients: int
    job_output_max_bytes: int
    retention_active_days: int
    retention_open_request_max_days: int
    retention_archive_days: int
    orphan_job_retention_days: int
    legacy_sheet_price_factor_default: float
    edge_band_price_per_m: float
    cnc_cost_per_sheet: float
    drawing_cost_fixed: float
    transport_cost_fixed: float

    @classmethod
    def from_environment(cls, environment: Environment | None = None) -> "RuntimeConfig":
        source = _environment(environment)
        port = int(source.get("METOD_PORT", "8787"))
        public_host = source.get("METOD_PUBLIC_HOST", "werkplaats")
        retention_active = max(
            1, env_int("RETENTION_ACTIVE_DAYS", 90, environment=source)
        )
        return cls(
            host="127.0.0.1",
            port=port,
            public_host=public_host,
            public_base_url=source.get(
                "METOD_PUBLIC_BASE_URL", f"http://{public_host}:{port}"
            ),
            admin_session_idle_seconds=int(
                source.get("ADMIN_SESSION_IDLE_SEC", str(30 * 60))
            ),
            admin_session_absolute_seconds=int(
                source.get("ADMIN_SESSION_ABSOLUTE_SEC", str(8 * 60 * 60))
            ),
            max_sse_clients=max(
                1, min(128, env_int("MAX_SSE_CLIENTS", 24, environment=source))
            ),
            job_output_max_bytes=int(
                source.get("JOB_OUTPUT_MAX_BYTES", str(512 * 1024 * 1024))
            ),
            retention_active_days=retention_active,
            retention_open_request_max_days=max(
                retention_active + 1,
                env_int("RETENTION_OPEN_REQUEST_MAX_DAYS", 365, environment=source),
            ),
            retention_archive_days=max(
                1, env_int("RETENTION_ARCHIVE_DAYS", 90, environment=source)
            ),
            orphan_job_retention_days=max(
                1, env_int("ORPHAN_JOB_RETENTION_DAYS", 7, environment=source)
            ),
            legacy_sheet_price_factor_default=float(
                source.get("METOD_SHEET_PRICE_FACTOR", "1.4")
            ),
            edge_band_price_per_m=float(
                source.get("METOD_EDGE_BAND_PRICE_PER_M", "4.5")
            ),
            cnc_cost_per_sheet=float(source.get("METOD_CNC_COST_PER_SHEET", "85")),
            drawing_cost_fixed=float(source.get("METOD_DRAWING_COST_FIXED", "125")),
            transport_cost_fixed=float(
                source.get("METOD_TRANSPORT_COST_FIXED", "54.95")
            ),
        )


__all__ = (
    "RuntimeConfig",
    "env_flag",
    "env_int",
    "production_hardening_enabled",
    "split_env_csv",
)
