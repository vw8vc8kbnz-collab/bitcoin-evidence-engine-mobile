from __future__ import annotations

"""Construct long-lived application services without owning mutable runtime state."""

from dataclasses import dataclass
from pathlib import Path
from types import ModuleType

from metod_app.admin.access import AdminAccessController, AdminAccessDependencies
from metod_app.http.static import StaticHttpAdapterService, StaticHttpDependencies
from metod_app.jobs.finalization import JobFinalizationService
from metod_app.jobs.lifecycle import JobLifecycleDependencies, JobLifecycleFacadeService
from metod_app.observability import (
    ObservabilityDependencies,
    ObservabilityPaths,
    ObservabilityService,
)
from metod_app.requests.downloads import (
    RequestDownloadDependencies,
    RequestDownloadProjectionService,
)
from metod_app.requests.submission import SubmissionClaimRepository, SubmissionService


@dataclass(frozen=True, slots=True)
class RuntimeServices:
    submission_claims: SubmissionClaimRepository
    submission_service: SubmissionService
    request_downloads: RequestDownloadProjectionService


@dataclass(frozen=True, slots=True)
class CoreRuntimeServices:
    """Long-lived HTTP/job services composed against the live runtime module."""

    job_finalization: JobFinalizationService
    observability: ObservabilityService
    admin_access: AdminAccessController
    static_http: StaticHttpAdapterService
    job_lifecycle: JobLifecycleFacadeService


def build_core_runtime_services(runtime: ModuleType) -> CoreRuntimeServices:
    """Build the main service graph without copying runtime state or behavior."""

    finalization = JobFinalizationService(
        jobs_root=runtime.JOBS,
        safety_error=runtime.SafetyContractError,
        validate_job_id=runtime.validate_job_id,
        resolve_identifier_child=runtime.resolve_identifier_child,
        resolve_relative_file=runtime.resolve_relative_file,
        read_json=lambda path: runtime.strict_json_load(path),
        cached_sha256_file=lambda path: runtime._cached_sha256_file(path),
        parse_panels_csv=lambda text: runtime._parse_panels_csv(text),
        input_dxf_source_map=lambda input_dir, part_ids: runtime._input_dxf_source_map(
            input_dir, part_ids
        ),
        link_or_copy_file=lambda source, destination: runtime._link_or_copy_file(
            source, destination
        ),
        fsync_directory=lambda path: runtime.fsync_directory(path),
        generate_labels=lambda root: runtime._generate_labels_json_strict(root),
        generate_stickertool=lambda root: runtime._generate_stickertool_json(root),
        write_calculation_summary=lambda root, **kwargs: runtime._write_human_calculation_summary(
            root, **kwargs
        ),
        durable_write_json=lambda path, value: runtime.durable_write_json(path, value),
        atomic_write_json=lambda path, value: runtime._atomic_write_json(path, value),
        load_runtime_state=lambda job_id: runtime._load_job_runtime_state(job_id),
        utc_now_iso=lambda: runtime._utc_now_iso(),
    )
    observability = ObservabilityService(
        ObservabilityDependencies(
            paths=ObservabilityPaths(
                system_log_file=lambda: runtime.SYSTEM_LOG_FILE,
                system_dir=lambda: runtime.SYSTEM_DIR,
                state_root=lambda: runtime.STATE_ROOT,
                material_library_path=lambda: runtime.MATERIAL_LIBRARY_PATH,
                dxf_library_root=lambda: runtime.DXF_LIBRARY_ROOT,
                jobs_root=lambda: runtime.JOBS,
                requests_root=lambda: runtime.REQUESTS,
                queue_pending_root=lambda: runtime.QUEUE_PENDING,
                queue_processing_root=lambda: runtime.QUEUE_PROCESSING,
            ),
            build=runtime.SECURITY_BUILD,
            environment=runtime.os.environ,
            path_factory=lambda value: runtime.Path(value),
            env_int=lambda name, default: runtime._env_int(name, default),
            production_hardening_enabled=lambda: runtime._is_production_hardening_enabled(),
            ensure_system_dirs=lambda: runtime._ensure_system_dirs(),
            now_iso=lambda: runtime._now_iso(),
            safe_text=lambda value, limit: runtime._safe_text(value, limit),
            redact_sensitive_text=lambda value, limit: runtime._redact_sensitive_text(
                value, limit
            ),
            sanitize_log_value=lambda value, **kwargs: runtime._sanitize_log_value(
                value, **kwargs
            ),
            append_jsonl_rotating=lambda path, value, **kwargs: runtime.append_jsonl_rotating(
                path, value, **kwargs
            ),
            tail_text_lines=lambda path, count, **kwargs: runtime.tail_text_lines(
                path, count, **kwargs
            ),
            strict_json_load=lambda path: runtime.strict_json_load(path),
            strict_json_loads=lambda value: runtime.strict_json_loads(value),
            sha256_file=lambda path: runtime.sha256_file(path),
            load_pricing_config=lambda: runtime._load_pricing_config(),
            ensure_finite_json=lambda value: runtime.ensure_finite_json(value),
            durable_write_text=lambda path, value, **kwargs: runtime.durable_write_text(
                path, value, **kwargs
            ),
            disk_usage=lambda path: runtime.shutil.disk_usage(path),
            statvfs=(lambda path: runtime.os.statvfs(path))
            if hasattr(runtime.os, "statvfs")
            else None,
            process_id=lambda: runtime.os.getpid(),
            token_hex=lambda size: runtime.secrets.token_hex(size),
            sse_client_count=runtime._observability_sse_client_count,
            public_job_snapshot=runtime._observability_public_job_snapshot,
        )
    )
    admin_access = AdminAccessController(
        AdminAccessDependencies(
            root=runtime.ROOT,
            environment=runtime.os.environ,
            credentials_file_path=runtime._get_admin_credentials_file_path,
            strict_json_load=runtime.strict_json_load,
            strict_json_dumps=runtime.strict_json_dumps,
            read_json_body_limited=runtime._read_json_body_limited,
            production_runtime=runtime._is_production_runtime,
            production_hardening_enabled=runtime._is_production_hardening_enabled,
            secure_admin_transport=runtime._is_secure_admin_transport,
            https_request=runtime._is_https_request,
            client_ip=runtime._client_ip,
            loopback_client=runtime._is_loopback_client,
            rate_limit_is_blocked=runtime._rate_limit_is_blocked,
            rate_limit_record=runtime._rate_limit_record,
            rate_limit_clear=runtime._rate_limit_clear,
            verify_password=runtime._verify_password_against_stored,
            verify_totp=runtime._verify_totp,
            append_system_event=runtime._append_system_event,
            extract_bearer_token=runtime._extract_bearer_token,
            extract_session_cookie=runtime._extract_admin_session_cookie,
            dummy_password_hash=runtime._DUMMY_ADMIN_PASSWORD_HASH,
            dummy_totp_secret=runtime._DUMMY_ADMIN_TOTP_SECRET,
        ),
        runtime._ADMIN_SESSION_STORE,
    )
    static_http = StaticHttpAdapterService(
        StaticHttpDependencies(
            root=lambda: runtime.ROOT,
            state_root=lambda: runtime.STATE_ROOT,
            dxf_manifest_path=lambda: runtime.DXF_MANIFEST_PATH,
            dxf_library_root=lambda: runtime.DXF_LIBRARY_ROOT,
            resolve_relative_file=runtime.resolve_relative_file,
            sanitize_filename=runtime._sanitize_filename,
            strict_json_dumps=runtime.strict_json_dumps,
            origin_allowed=runtime._origin_allowed,
            production_hardening_enabled=runtime._is_production_hardening_enabled,
            https_request=runtime._is_https_request,
        )
    )
    lifecycle = JobLifecycleFacadeService(
        JobLifecycleDependencies(
            JOBS=lambda: runtime.JOBS,
            _OPTIMIZER_PROCESS_SUPERVISOR=lambda: runtime._OPTIMIZER_PROCESS_SUPERVISOR,
            _cancel_queued_public_job=lambda *args, **kwargs: runtime._cancel_queued_public_job(
                *args, **kwargs
            ),
            _client_ip=lambda *args, **kwargs: runtime._client_ip(*args, **kwargs),
            _finish_public_job_slot=lambda *args, **kwargs: runtime._finish_public_job_slot(
                *args, **kwargs
            ),
            _job_lock=lambda: runtime._job_lock,
            _job_meta=lambda: runtime._job_meta,
            _now_iso=lambda *args, **kwargs: runtime._now_iso(*args, **kwargs),
            _rate_limit_allow=lambda *args, **kwargs: runtime._rate_limit_allow(
                *args, **kwargs
            ),
            _read_json_body_limited=lambda *args, **kwargs: runtime._read_json_body_limited(
                *args, **kwargs
            ),
            _save_job_runtime_state=lambda *args, **kwargs: runtime._save_job_runtime_state(
                *args, **kwargs
            ),
            _terminate_optimizer_process=lambda *args, **kwargs: runtime._terminate_optimizer_process(
                *args, **kwargs
            ),
            resolve_identifier_child=lambda *args, **kwargs: runtime.resolve_identifier_child(
                *args, **kwargs
            ),
            validate_job_id=lambda *args, **kwargs: runtime.validate_job_id(*args, **kwargs),
            _dxf_transport_stats=lambda *args, **kwargs: runtime._dxf_transport_stats(
                *args, **kwargs
            ),
            _estimate_payload_area_lower_bound=lambda *args, **kwargs: runtime._estimate_payload_area_lower_bound(
                *args, **kwargs
            ),
            JobCancelledError=runtime.JobCancelledError,
            SafetyContractError=runtime.SafetyContractError,
            _commit_public_job_slot=lambda *args, **kwargs: runtime._commit_public_job_slot(
                *args, **kwargs
            ),
            _create_job_from_payload=lambda *args, **kwargs: runtime._create_job_from_payload(
                *args, **kwargs
            ),
            _finalization_complete=lambda *args, **kwargs: runtime._finalization_complete(
                *args, **kwargs
            ),
            _job_cancel_requested=lambda *args, **kwargs: runtime._job_cancel_requested(
                *args, **kwargs
            ),
            durable_write_text=lambda *args, **kwargs: runtime.durable_write_text(
                *args, **kwargs
            ),
            _atomic_write_json=lambda *args, **kwargs: runtime._atomic_write_json(
                *args, **kwargs
            ),
            _redact_sensitive_text=lambda *args, **kwargs: runtime._redact_sensitive_text(
                *args, **kwargs
            ),
            JOB_OUTPUT_MAX_BYTES=lambda: runtime.JOB_OUTPUT_MAX_BYTES,
            PRICING_SEED_PATH=lambda: runtime.PRICING_SEED_PATH,
            _append_client_log=lambda *args, **kwargs: runtime._append_client_log(
                *args, **kwargs
            ),
            _append_system_event=lambda *args, **kwargs: runtime._append_system_event(
                *args, **kwargs
            ),
            _enforce_job_total_qty_limit=lambda *args, **kwargs: runtime._enforce_job_total_qty_limit(
                *args, **kwargs
            ),
            _ensure_pricing_materials=lambda *args, **kwargs: runtime._ensure_pricing_materials(
                *args, **kwargs
            ),
            _env_int=lambda *args, **kwargs: runtime._env_int(*args, **kwargs),
            _estimate_preflight_job_family_bytes=lambda *args, **kwargs: runtime._estimate_preflight_job_family_bytes(
                *args, **kwargs
            ),
            _is_production_runtime=lambda *args, **kwargs: runtime._is_production_runtime(
                *args, **kwargs
            ),
            _job_output_limit_message=lambda *args, **kwargs: runtime._job_output_limit_message(
                *args, **kwargs
            ),
            _load_pricing_config=lambda *args, **kwargs: runtime._load_pricing_config(
                *args, **kwargs
            ),
            _new_public_access_token=lambda *args, **kwargs: runtime._new_public_access_token(
                *args, **kwargs
            ),
            _public_error_message=lambda *args, **kwargs: runtime._public_error_message(
                *args, **kwargs
            ),
            _public_job_queue_limits=lambda *args, **kwargs: runtime._public_job_queue_limits(
                *args, **kwargs
            ),
            _release_public_job_slot=lambda *args, **kwargs: runtime._release_public_job_slot(
                *args, **kwargs
            ),
            _release_state_capacity_reservation=lambda *args, **kwargs: runtime._release_state_capacity_reservation(
                *args, **kwargs
            ),
            _reserve_state_capacity=lambda *args, **kwargs: runtime._reserve_state_capacity(
                *args, **kwargs
            ),
            _try_acquire_public_job_slot=lambda *args, **kwargs: runtime._try_acquire_public_job_slot(
                *args, **kwargs
            ),
            _utc_now_iso=lambda *args, **kwargs: runtime._utc_now_iso(*args, **kwargs),
            fsync_directory=lambda *args, **kwargs: runtime.fsync_directory(*args, **kwargs),
            strict_json_dumps=lambda *args, **kwargs: runtime.strict_json_dumps(
                *args, **kwargs
            ),
            strict_json_load=lambda *args, **kwargs: runtime.strict_json_load(
                *args, **kwargs
            ),
            strict_json_loads=lambda *args, **kwargs: runtime.strict_json_loads(
                *args, **kwargs
            ),
            _apply_sell_pricing_to_quote=lambda *args, **kwargs: runtime._apply_sell_pricing_to_quote(
                *args, **kwargs
            ),
            _extract_strict_calculation_pricing_summary=lambda *args, **kwargs: runtime._extract_strict_calculation_pricing_summary(
                *args, **kwargs
            ),
            _linked_subjob_ids=lambda *args, **kwargs: runtime._linked_subjob_ids(
                *args, **kwargs
            ),
            _load_job_runtime_state=lambda *args, **kwargs: runtime._load_job_runtime_state(
                *args, **kwargs
            ),
            _master_job_id_for=lambda *args, **kwargs: runtime._master_job_id_for(
                *args, **kwargs
            ),
            _public_job_family_complete=lambda *args, **kwargs: runtime._public_job_family_complete(
                *args, **kwargs
            ),
        )
    )
    return CoreRuntimeServices(
        finalization,
        observability,
        admin_access,
        static_http,
        lifecycle,
    )


def build_runtime_services(runtime: ModuleType) -> RuntimeServices:
    """Wire services to the live composition module through narrow callbacks."""

    claims = SubmissionClaimRepository(
        marker_root=lambda: runtime.SUBMISSION_IDEMPOTENCY_DIR,
        requests_root=lambda: runtime.REQUESTS,
        utc_now_iso=lambda: runtime._utc_now_iso(),
    )
    submission = SubmissionService(
        claims=claims,
        claim_lock=lambda: runtime._SUBMISSION_IDEMPOTENCY_LOCK,
        read_json=lambda path: runtime.strict_json_load(path),
        email_is_valid=lambda email: bool(runtime._EMAIL_RE.fullmatch(email)),
        linked_subjob_ids=lambda parent_job_id: runtime._linked_subjob_ids(parent_job_id),
        resolve_job_root=lambda job_id: runtime.resolve_identifier_child(runtime.JOBS, job_id),
        finalization_complete=lambda job_root: runtime._finalization_complete(job_root),
        pricing_summary=lambda job_ids: runtime._extract_strict_calculation_pricing_summary(job_ids),
        new_request_id=lambda: runtime._new_request_id(),
        new_cancel_token=lambda: runtime.secrets.token_urlsafe(32),
        resolve_request_root=lambda request_id: runtime.resolve_identifier_child(
            runtime.REQUESTS,
            runtime.validate_request_id(request_id),
            kind="request",
        ),
        atomic_write_json=lambda path, value: runtime._atomic_write_json(
            path, value, mode=0o600
        ),
        utc_now_iso=lambda: runtime._utc_now_iso(),
        extract_summary=lambda payload: runtime._extract_request_summary(payload),
        save_status=lambda request_id, status: runtime._save_status(request_id, status),
        load_status=lambda request_id: runtime._load_status(request_id),
        request_status_exists=lambda request_id: (
            runtime.REQUESTS / request_id / "status.json"
        ).exists(),
        safe_identifier=lambda value, max_len: runtime._safe_id(value, max_len),
        notify_submitted=lambda *args, **kwargs: runtime._notify_submitted(*args, **kwargs),
        broadcast=lambda event, payload: runtime._sse_broadcast(event, payload),
    )
    downloads = RequestDownloadProjectionService(
        RequestDownloadDependencies(
            requests_root=lambda: runtime.REQUESTS,
            jobs_root=lambda: runtime.JOBS,
            ensure_request_directories=lambda: runtime._ensure_request_dirs(),
            load_status=lambda request_id: runtime._load_status(request_id),
            strict_json_load=lambda path: runtime.strict_json_load(path),
            safe_identifier=lambda value, max_len: runtime._safe_id(value, max_len),
            validate_job_id=lambda job_id: runtime.validate_job_id(job_id),
            resolve_job_root=lambda job_id: runtime.resolve_identifier_child(runtime.JOBS, job_id),
            collect_job_output_files=lambda job_id: runtime._collect_job_output_files(job_id),
            find_stickertool_file=lambda job_id: runtime._find_or_generate_stickertool_file(job_id),
            sealed_output_artifacts=lambda job_root: runtime._sealed_output_artifacts(job_root),
            job_material_context=lambda job_root: runtime._job_material_context(job_root),
            best_material_name=lambda *args: runtime._best_material_name(*args),
            classify_output_kind=lambda name: runtime._classify_output_kind(name),
            dedupe_admin_dxf_files=lambda files: runtime._dedupe_admin_dxf_files(files),
            admin_sheet_download_name=lambda *args, **kwargs: runtime._admin_sheet_download_name(
                *args, **kwargs
            ),
            strict_pricing_summary=lambda job_ids: runtime._extract_strict_calculation_pricing_summary(
                job_ids
            ),
            finalization_complete=lambda job_root: runtime._finalization_complete(job_root),
            directory_size_bytes=lambda path: runtime._dir_size_bytes(path),
            sanitize_filename=lambda value, max_len: runtime._sanitize_filename(value, max_len),
            relative_parts=lambda relative: tuple(Path(relative).parts),
            relative_basename=lambda relative: Path(relative).name,
            build_manifest=lambda request_id: runtime._build_request_file_manifest(request_id),
        )
    )
    return RuntimeServices(claims, submission, downloads)


__all__ = (
    "CoreRuntimeServices",
    "RuntimeServices",
    "build_core_runtime_services",
    "build_runtime_services",
)
