#!/usr/bin/env python3
# METOD Tool A + Tool B local server (py-only)
# Serves Tool A UI, Admin UI, and runs Tool B optimizer jobs.

from __future__ import annotations

# Build stamps are deliberately public module constants.  A leading double
# underscore is name-mangled when it is referenced from a class method (for
# example Handler.do_GET), which used to crash /health/live after the socket
# had already opened.
STICKERTOOL_V2_BUILD = 'FIX626_ADMIN_LOGIN_CLEAN_SESSION'
OUTPUT_PIPELINE_BUILD = 'FIX654_OUTPUT_PIPELINE_AUDIT'
PERFORMANCE_BUILD = 'FIX660_GRAIN_STUDIO'
SECURITY_BUILD = 'FIX660R8_PRELIVE_HARDENED'

import json
import csv
import math
import os
import re
import shutil
import stat
import subprocess
import sys
import threading
import traceback
import time
import uuid
import base64
import binascii
import io
import hmac
import hashlib
import secrets
import queue
import zipfile
import gzip
import ssl
import ipaddress
import socket
import signal
from collections import OrderedDict
try:
    import fcntl as _fcntl  # type: ignore
except Exception:  # pragma: no cover - non-POSIX development fallback
    _fcntl = None
from datetime import datetime, timedelta, timezone
from dataclasses import replace
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs, unquote, quote
from typing import Optional, List, Dict, Any, Union

from metod_app.admin.access import (
    AdminAccessController,
    AdminAccessDependencies,
    AdminSessionStore,
    find_admin_user as _admin_find_user,
    normalized_admin_users as _admin_normalized_users,
)
from metod_app.admin.presentation import ADMIN_HTML, ADMIN_LOGIN_HTML, admin_asset_for_path

from metod_app.application import build_app_context
from metod_app.config import (
    env_flag as _env_flag,
    env_int as _env_int,
    production_hardening_enabled as _is_production_hardening_enabled,
    split_env_csv as _split_env_csv,
)
from metod_app.contracts.submission import (
    EMAIL_RE as _EMAIL_RE,
    clean_text as _clean_text,
    sanitize_phone_text as _sanitize_phone_text,
    sanitize_postcode_text as _sanitize_postcode_text,
    sanitize_user_text as _sanitize_user_text,
    validate_submit_payload as _validate_submit_payload,
)
from metod_app.errors import public_error_message as _public_error_message
from metod_app.identifiers import (
    safe_identifier as _safe_id,
    sanitize_filename as _sanitize_filename,
    sanitize_key as _sanitize_key,
)
from metod_app.security.redaction import (
    redact_sensitive_text as _redact_sensitive_text,
    safe_text as _safe_text,
    sanitize_log_value as _sanitize_log_value,
)
from metod_app.security.headers import (
    extract_admin_session_cookie as _extract_admin_session_cookie,
    extract_bearer_token as _extract_bearer_token,
    extract_forwarded_client_ip as _extract_forwarded_client_ip,
)
from metod_app.security.credentials import (
    pbkdf2_hash_password as _pbkdf2_hash_password,
    totp_code as _totp_code,
    verify_password_against_stored as _verify_password_against_stored,
    verify_totp as _verify_totp,
)

from server_helpers import (
    atomic_write_json as _helpers_atomic_write_json,
    atomic_write_text as _helpers_atomic_write_text,
    extract_request_token as _helpers_extract_request_token,
    read_json_body as _helpers_read_json_body,
    read_json_body_limited as _helpers_read_json_body_limited,
    require_same_origin_admin_write as _helpers_require_same_origin_admin_write,
    safe_job_file as _helpers_safe_job_file,
)
from pricing_helpers import (
    aggregate_materials_from_subjob_quotes as _pricing_aggregate_materials_from_subjob_quotes,
    parse_calculation_summary_totals as _pricing_parse_calculation_summary_totals,
)
from metod_app.pricing.contracts import (
    material_direct_sell_ex_vat as _material_direct_sell_ex_vat,
    material_direct_sell_incl_vat as _material_direct_sell_incl_vat,
)
from metod_app.requests.repository import (
    RequestRepository,
    request_index_row as _request_index_row,
)
from metod_app.requests.projections import (
    RequestProjection,
    customer_block_from_sources as _customer_block_from_sources,
    customer_block_from_status as _customer_block_from_status,
)
from metod_app.requests.downloads import (
    RequestDownloadDependencies,
    RequestDownloadProjectionService,
)
from metod_app.requests.submission import SubmissionClaimRepository, SubmissionService
from metod_app.storage.maintenance import StateMaintenanceBarrier
from metod_app.jobs.status import (
    build_job_runtime_state as _build_job_runtime_state,
    job_cancel_requested as _runtime_job_cancel_requested,
    startup_recovery_decision as _startup_recovery_decision,
)
from metod_app.jobs.admission import (
    PublicJobAdmission,
    StateCapacityReservations,
    public_job_queue_limits as _bounded_public_job_queue_limits,
)
from metod_app.jobs.scheduler import PublicJobScheduler
from metod_app.jobs.process_supervisor import OptimizerDeadline, OptimizerProcessSupervisor
from metod_app.jobs.finalization import JobFinalizationService
from metod_app.jobs.lifecycle import JobLifecycleDependencies, JobLifecycleFacadeService
from metod_app.jobs.reconciliation import JobRestartReconciler
from metod_app.http.matcher import match_route as _match_http_route
from metod_app.http.static import StaticHttpAdapterService, StaticHttpDependencies
from metod_app.notifications.projections import (
    merge_notification_pricing as _merge_ntfy_pricing,
    parse_calculation_summary as _parse_calculation_summary_for_ntfy,
    privacy_safe_customer_lines as _privacy_safe_customer_lines,
)
from metod_app.notifications.messages import (
    build_failed_notification as _build_failed_notification,
    build_submitted_notification as _build_submitted_notification,
)
from metod_app.observability import (
    ObservabilityDependencies,
    ObservabilityPaths,
    ObservabilityService,
)
from catalog_importer import (
    ALLOWED_THICKNESSES_MM as CATALOG_ALLOWED_THICKNESSES_MM,
    VAT_RATE as CATALOG_VAT_RATE,
    atomic_write_cached_image as _catalog_atomic_write_cached_image,
    catalog_diff as _catalog_diff,
    download_catalog_image as _catalog_download_image,
    parse_catalog_csv as _parse_catalog_csv,
    read_cached_image as _catalog_read_cached_image,
    classify_catalog_presentation as _catalog_classify_presentation,
    _PinnedHTTPSConnection as _catalog_pinned_https_connection,
)
from catalog_taxonomy import (
    PUBLIC_FAMILIES as CATALOG_PUBLIC_FAMILIES,
    SUBSTRATE_LABELS as CATALOG_SUBSTRATE_LABELS,
    apply_admin_override as _taxonomy_apply_admin_override,
    apply_admin_family_override as _taxonomy_apply_admin_family_override,
    clear_admin_family_override as _taxonomy_clear_admin_family_override,
    enrich_catalog_records as _taxonomy_enrich_records,
    load_registry as _taxonomy_load_registry,
    registry_with_records as _taxonomy_registry_with_records,
    save_registry as _taxonomy_save_registry,
    taxonomy_summary as _taxonomy_summary,
)
from dxf_geometry import entities_section as _strict_dxf_entities_section
from dxf_geometry import parse_pairs as _strict_dxf_parse_pairs
from dxf_geometry import split_entities as _strict_dxf_split_entities
from dxf_geometry import entity_type as _strict_dxf_entity_type
from dxf_geometry import entity_layer as _strict_dxf_entity_layer
from dxf_geometry import entities_bbox as _strict_dxf_entities_bbox
from dxf_geometry import entity_bbox as _strict_dxf_entity_bbox
from panel_contract import canonical_csv as _canonical_panels_csv
from panel_contract import parse_panels_csv as _parse_panels_csv_contract
from safety_contracts import (
    ContractError as SafetyContractError,
    append_jsonl_rotating,
    durable_copy_file,
    durable_create_json_exclusive,
    durable_write_many_bytes,
    durable_write_bytes,
    durable_write_json,
    durable_write_text,
    delete_rotating_log_if_older_than,
    ensure_finite_json,
    finite_number,
    fsync_directory,
    resolve_identifier_child,
    resolve_relative_file,
    sha256_file,
    strict_json_dumps,
    strict_json_load,
    strict_json_loads,
    tail_text_lines,
    validate_job_id,
    validate_public_material_id,
    validate_request_id,
)

_APP_CONTEXT = build_app_context(app_root=Path(__file__).resolve().parents[2])
_APP_PATHS = _APP_CONTEXT.paths
_RUNTIME_CONFIG = _APP_CONTEXT.config

ROOT = _APP_PATHS.app_root
RELEASE_ROOT = _APP_PATHS.release_root
STATE_ROOT = _APP_PATHS.state_root
DXF_LIBRARY_ROOT = _APP_PATHS.dxf_library_root
DXF_MANIFEST_PATH = _APP_PATHS.dxf_manifest_path
PRICING_SEED_PATH = _APP_PATHS.pricing_seed_path
MATERIAL_LIBRARY_SEED_PATH = _APP_PATHS.material_library_seed_path
BUILD_MARKER_FIX651 = 'FIX651_CSV_CATALOG_DIRECT_PRICING'
BUILD_MARKER_FIX652 = 'FIX652_CSV_ONLY_LIBRARY_RESET'
BUILD_MARKER_FIX653 = 'FIX653_LIBRARY_UX_CLASSIFICATION'
BASE_DIR = str(ROOT)
MATERIAL_LIBRARY_PATH = _APP_PATHS.material_library_path
CATALOG_PUBLIC_ID_REGISTRY = _APP_PATHS.catalog_public_id_registry
CATALOG_TAXONOMY_REGISTRY = _APP_PATHS.catalog_taxonomy_registry
DECOR_MEDIA_ROOT = _APP_PATHS.decor_media_root
_MATERIAL_LIBRARY_LOCK = threading.RLock()
_PRICING_CONFIG_LOCK = threading.RLock()
_CATALOG_IMAGE_SYNC_LOCK = threading.Lock()
_CATALOG_IMAGE_SYNC_ACTIVE: set[str] = set()
_CATALOG_IMAGE_STORAGE_RESERVATION_ID = 'state_catalog_image_sync'
# One worker can hold a 12 MiB source plus durable temp/final files and the two
# bounded WebP variants. 32 MiB is a conservative fixed on-disk in-flight bound.
_CATALOG_IMAGE_STORAGE_BYTES_PER_WORKER = 32 * 1024 * 1024
_CATALOG_IMAGE_STORAGE_INODES_PER_WORKER = 16
_PUBLIC_MATERIAL_ID_RE = re.compile(r'^decor_[a-f0-9]{20,40}$')
PUBLIC_MATERIAL_CATALOG_CACHE_PATH = _APP_PATHS.public_material_catalog_cache_path
PUBLIC_MATERIAL_CATALOG_CACHE_META_PATH = _APP_PATHS.public_material_catalog_cache_meta_path
PUBLIC_MATERIAL_CATALOG_CACHE_SCHEMA = 2
PUBLIC_MATERIAL_CATALOG_CACHE_BUILD = 'FIX660R8F_CATALOG_IMAGES'
_PUBLIC_MATERIALS_RESPONSE_CACHE_LOCK = threading.RLock()
_PUBLIC_MATERIALS_RESPONSE_CACHE: dict[str, Any] = {'mtimeNs': None, 'body': None, 'etag': None}
_MATERIAL_LOOKUP_CACHE: dict[str, Any] = {
    'signature': None,
    'publicToInternal': {},
    'internalToPublic': {},
    'catalogByInternal': {},
    'replacements': (),
}
_ARTIFACT_HASH_CACHE_LOCK = threading.RLock()
_ARTIFACT_HASH_CACHE: OrderedDict[tuple[int, int, int, int, int], str] = OrderedDict()


# Bounded domain owners. Each owner resolves mutable dependencies from this live
# composition module at call time, preserving operational/test overrides.
from metod_app.catalog.runtime import CatalogRuntime
_CATALOG_RUNTIME = CatalogRuntime(sys.modules[__name__])
_invalidate_public_materials_response_cache = _CATALOG_RUNTIME._invalidate_public_materials_response_cache
_path_content_signature = _CATALOG_RUNTIME._path_content_signature
_invalidate_material_lookup_cache = _CATALOG_RUNTIME._invalidate_material_lookup_cache
_material_lookup_snapshot = _CATALOG_RUNTIME._material_lookup_snapshot
_cached_sha256_file = _CATALOG_RUNTIME._cached_sha256_file
_classify_dxf_filename = _CATALOG_RUNTIME._classify_dxf_filename
migrate_embedded_dxfs_on_startup = _CATALOG_RUNTIME.migrate_embedded_dxfs_on_startup
classify_dxf_category = _CATALOG_RUNTIME.classify_dxf_category
migrate_embedded_dxfs_to_categories = _CATALOG_RUNTIME.migrate_embedded_dxfs_to_categories
get_embedded_dxfs_version = _CATALOG_RUNTIME.get_embedded_dxfs_version
rebuild_embedded_dxfs_manifest = _CATALOG_RUNTIME.rebuild_embedded_dxfs_manifest
_looks_numeric_material_name = _CATALOG_RUNTIME._looks_numeric_material_name
_best_material_name = _CATALOG_RUNTIME._best_material_name
_material_label_for_filename = _CATALOG_RUNTIME._material_label_for_filename

from metod_app.security.access_runtime import SecurityAccessRuntime
_SECURITY_ACCESS_RUNTIME = SecurityAccessRuntime(sys.modules[__name__])
_direct_peer_ip = _SECURITY_ACCESS_RUNTIME._direct_peer_ip
_ip_matches = _SECURITY_ACCESS_RUNTIME._ip_matches
_is_trusted_proxy_peer = _SECURITY_ACCESS_RUNTIME._is_trusted_proxy_peer
_client_ip = _SECURITY_ACCESS_RUNTIME._client_ip
_is_loopback_value = _SECURITY_ACCESS_RUNTIME._is_loopback_value
_is_loopback_client = _SECURITY_ACCESS_RUNTIME._is_loopback_client
_rate_limit_allow = _SECURITY_ACCESS_RUNTIME._rate_limit_allow
_rate_limit_is_blocked = _SECURITY_ACCESS_RUNTIME._rate_limit_is_blocked
_rate_limit_record = _SECURITY_ACCESS_RUNTIME._rate_limit_record
_rate_limit_clear = _SECURITY_ACCESS_RUNTIME._rate_limit_clear
_normalized_admin_users = _SECURITY_ACCESS_RUNTIME._normalized_admin_users
_find_admin_user = _SECURITY_ACCESS_RUNTIME._find_admin_user
_admin_session_create = _SECURITY_ACCESS_RUNTIME._admin_session_create
_admin_session_valid = _SECURITY_ACCESS_RUNTIME._admin_session_valid
_admin_session_revoke = _SECURITY_ACCESS_RUNTIME._admin_session_revoke
_admin_session_actor = _SECURITY_ACCESS_RUNTIME._admin_session_actor
_admin_session_roles = _SECURITY_ACCESS_RUNTIME._admin_session_roles
_is_password_hash_value = _SECURITY_ACCESS_RUNTIME._is_password_hash_value
_is_https_request = _SECURITY_ACCESS_RUNTIME._is_https_request
_is_secure_admin_transport = _SECURITY_ACCESS_RUNTIME._is_secure_admin_transport
_is_production_runtime = _SECURITY_ACCESS_RUNTIME._is_production_runtime
_get_admin_credentials_file_path = _SECURITY_ACCESS_RUNTIME._get_admin_credentials_file_path
_get_admin_password_reset_activation_file_path = _SECURITY_ACCESS_RUNTIME._get_admin_password_reset_activation_file_path
_load_admin_password_reset_activation = _SECURITY_ACCESS_RUNTIME._load_admin_password_reset_activation
_admin_password_reset_activation_is_enabled = _SECURITY_ACCESS_RUNTIME._admin_password_reset_activation_is_enabled
_origin_allowed = _SECURITY_ACCESS_RUNTIME._origin_allowed
_extract_request_token = _SECURITY_ACCESS_RUNTIME._extract_request_token
_new_public_access_token = _SECURITY_ACCESS_RUNTIME._new_public_access_token
_write_job_access_token = _SECURITY_ACCESS_RUNTIME._write_job_access_token
_read_job_access_token = _SECURITY_ACCESS_RUNTIME._read_job_access_token

from metod_app.jobs.admission_runtime import JobAdmissionRuntime
_JOB_ADMISSION_RUNTIME = JobAdmissionRuntime(sys.modules[__name__])
_public_job_queue_limits = _JOB_ADMISSION_RUNTIME._public_job_queue_limits
_decrement_public_job_ip_locked = _JOB_ADMISSION_RUNTIME._decrement_public_job_ip_locked
_refresh_public_job_queue_meta_locked = _JOB_ADMISSION_RUNTIME._refresh_public_job_queue_meta_locked
_launch_public_job_item = _JOB_ADMISSION_RUNTIME._launch_public_job_item
_try_acquire_public_job_slot = _JOB_ADMISSION_RUNTIME._try_acquire_public_job_slot
_release_public_job_slot = _JOB_ADMISSION_RUNTIME._release_public_job_slot
_commit_public_job_slot = _JOB_ADMISSION_RUNTIME._commit_public_job_slot
_finish_public_job_slot = _JOB_ADMISSION_RUNTIME._finish_public_job_slot
_cancel_queued_public_job = _JOB_ADMISSION_RUNTIME._cancel_queued_public_job
_catalog_review_sha256 = _JOB_ADMISSION_RUNTIME._catalog_review_sha256

from metod_app.observability.runtime import ObservabilityRuntime
_OBSERVABILITY_RUNTIME = ObservabilityRuntime(sys.modules[__name__])
_sse_broadcast = _OBSERVABILITY_RUNTIME._sse_broadcast
_sse_handler = _OBSERVABILITY_RUNTIME._sse_handler
_guess_customer_name_from_payload = _OBSERVABILITY_RUNTIME._guess_customer_name_from_payload
_guess_customer_name = _OBSERVABILITY_RUNTIME._guess_customer_name
_append_system_event = _OBSERVABILITY_RUNTIME._append_system_event
_read_system_events = _OBSERVABILITY_RUNTIME._read_system_events
_observability_sse_client_count = _OBSERVABILITY_RUNTIME._observability_sse_client_count
_observability_public_job_snapshot = _OBSERVABILITY_RUNTIME._observability_public_job_snapshot

from metod_app.storage.backup_runtime import BackupRuntime
_BACKUP_RUNTIME = BackupRuntime(sys.modules[__name__])
_ensure_system_dirs = _BACKUP_RUNTIME._ensure_system_dirs
_initialize_external_state = _BACKUP_RUNTIME._initialize_external_state
_cleanup_old_backups = _BACKUP_RUNTIME._cleanup_old_backups
_backup_source_inventory = _BACKUP_RUNTIME._backup_source_inventory
_assert_backup_capacity = _BACKUP_RUNTIME._assert_backup_capacity
_verify_system_backup_zip = _BACKUP_RUNTIME._verify_system_backup_zip
_write_last_auto_backup = _BACKUP_RUNTIME._write_last_auto_backup
_read_last_auto_backup_dt = _BACKUP_RUNTIME._read_last_auto_backup_dt
run_backup_maintenance = _BACKUP_RUNTIME.run_backup_maintenance
_create_system_backup = _BACKUP_RUNTIME._create_system_backup
_list_backups = _BACKUP_RUNTIME._list_backups

from metod_app.notifications.runtime import NotificationRuntime
_NOTIFICATION_RUNTIME = NotificationRuntime(sys.modules[__name__])
_get_notify_config_file_path = _NOTIFICATION_RUNTIME._get_notify_config_file_path
_ntfy_log = _NOTIFICATION_RUNTIME._ntfy_log
_load_notify_config = _NOTIFICATION_RUNTIME._load_notify_config
_validated_ntfy_target = _NOTIFICATION_RUNTIME._validated_ntfy_target
_ntfy_send = _NOTIFICATION_RUNTIME._ntfy_send
_calculation_summary_text_for_ntfy = _NOTIFICATION_RUNTIME._calculation_summary_text_for_ntfy
_notify_privacy_options = _NOTIFICATION_RUNTIME._notify_privacy_options
_ntfy_public_safe_customer_lines = _NOTIFICATION_RUNTIME._ntfy_public_safe_customer_lines
_notify_submitted = _NOTIFICATION_RUNTIME._notify_submitted
_notify_failed = _NOTIFICATION_RUNTIME._notify_failed

from metod_app.jobs.payload_runtime import JobPayloadRuntime
_JOB_PAYLOAD_RUNTIME = JobPayloadRuntime(sys.modules[__name__])
_job_output_limit_message = _JOB_PAYLOAD_RUNTIME._job_output_limit_message
_job_family_size_bytes = _JOB_PAYLOAD_RUNTIME._job_family_size_bytes
_enforce_job_output_limit = _JOB_PAYLOAD_RUNTIME._enforce_job_output_limit
_enforce_state_capacity = _JOB_PAYLOAD_RUNTIME._enforce_state_capacity
_reserve_state_capacity = _JOB_PAYLOAD_RUNTIME._reserve_state_capacity
_release_state_capacity_reservation = _JOB_PAYLOAD_RUNTIME._release_state_capacity_reservation
_state_capacity_reservation_totals = _JOB_PAYLOAD_RUNTIME._state_capacity_reservation_totals
_expand_dxf_payload = _JOB_PAYLOAD_RUNTIME._expand_dxf_payload
_compact_dxf_transport = _JOB_PAYLOAD_RUNTIME._compact_dxf_transport
_validated_canonical_dxf_transport = _JOB_PAYLOAD_RUNTIME._validated_canonical_dxf_transport
_dxf_transport_stats = _JOB_PAYLOAD_RUNTIME._dxf_transport_stats
_estimate_preflight_job_family_bytes = _JOB_PAYLOAD_RUNTIME._estimate_preflight_job_family_bytes
_preflight_job_family_limit_message = _JOB_PAYLOAD_RUNTIME._preflight_job_family_limit_message
_get_payload_total_qty = _JOB_PAYLOAD_RUNTIME._get_payload_total_qty
_enforce_job_total_qty_limit = _JOB_PAYLOAD_RUNTIME._enforce_job_total_qty_limit
_estimate_payload_area_lower_bound = _JOB_PAYLOAD_RUNTIME._estimate_payload_area_lower_bound

from metod_app.jobs.state_runtime import JobStateRuntime
_JOB_STATE_RUNTIME = JobStateRuntime(sys.modules[__name__])
_get_python_base_cmd = _JOB_STATE_RUNTIME._get_python_base_cmd
_job_runtime_state_path = _JOB_STATE_RUNTIME._job_runtime_state_path
_load_job_runtime_state = _JOB_STATE_RUNTIME._load_job_runtime_state
_save_job_runtime_state = _JOB_STATE_RUNTIME._save_job_runtime_state
_job_cancel_requested = _JOB_STATE_RUNTIME._job_cancel_requested
_register_job_process = _JOB_STATE_RUNTIME._register_job_process
_unregister_job_process = _JOB_STATE_RUNTIME._unregister_job_process
_terminate_optimizer_process = _JOB_STATE_RUNTIME._terminate_optimizer_process
_reconcile_interrupted_jobs_on_startup = _JOB_STATE_RUNTIME._reconcile_interrupted_jobs_on_startup
_find_existing_file = _JOB_STATE_RUNTIME._find_existing_file
_find_placements_any = _JOB_STATE_RUNTIME._find_placements_any
_find_labels_any = _JOB_STATE_RUNTIME._find_labels_any

from metod_app.storage.io_runtime import StorageIoRuntime
_STORAGE_IO_RUNTIME = StorageIoRuntime(sys.modules[__name__])
_now_iso = _STORAGE_IO_RUNTIME._now_iso
_safe_json = _STORAGE_IO_RUNTIME._safe_json
_read_json_body = _STORAGE_IO_RUNTIME._read_json_body
_read_json_body_limited = _STORAGE_IO_RUNTIME._read_json_body_limited
_safe_job_file = _STORAGE_IO_RUNTIME._safe_job_file
_write_file = _STORAGE_IO_RUNTIME._write_file
_write_bytes = _STORAGE_IO_RUNTIME._write_bytes
_write_replaceable_bytes = _STORAGE_IO_RUNTIME._write_replaceable_bytes
_write_replaceable_text = _STORAGE_IO_RUNTIME._write_replaceable_text
_write_replaceable_json = _STORAGE_IO_RUNTIME._write_replaceable_json
_link_or_copy_file = _STORAGE_IO_RUNTIME._link_or_copy_file
_atomic_write_text = _STORAGE_IO_RUNTIME._atomic_write_text
_atomic_write_json = _STORAGE_IO_RUNTIME._atomic_write_json
_utc_now_iso = _STORAGE_IO_RUNTIME._utc_now_iso
_ensure_request_dirs = _STORAGE_IO_RUNTIME._ensure_request_dirs
_ensure_archive_dirs = _STORAGE_IO_RUNTIME._ensure_archive_dirs

from metod_app.storage.archive_runtime import ArchiveRuntime
_ARCHIVE_RUNTIME = ArchiveRuntime(sys.modules[__name__])
_parse_iso_dt = _ARCHIVE_RUNTIME._parse_iso_dt
_path_dt = _ARCHIVE_RUNTIME._path_dt
_request_status_path = _ARCHIVE_RUNTIME._request_status_path
_request_created_dt_from_status = _ARCHIVE_RUNTIME._request_created_dt_from_status
_request_archive_meta_dt = _ARCHIVE_RUNTIME._request_archive_meta_dt
_job_created_dt = _ARCHIVE_RUNTIME._job_created_dt
_write_archive_meta = _ARCHIVE_RUNTIME._write_archive_meta
_unique_archive_dest = _ARCHIVE_RUNTIME._unique_archive_dest
_archive_journal_path = _ARCHIVE_RUNTIME._archive_journal_path
_archive_journal_write = _ARCHIVE_RUNTIME._archive_journal_write
_archive_journal_entries = _ARCHIVE_RUNTIME._archive_journal_entries
_complete_archive_journal = _ARCHIVE_RUNTIME._complete_archive_journal
_reconcile_archive_transactions = _ARCHIVE_RUNTIME._reconcile_archive_transactions
_linked_job_ids_from_status = _ARCHIVE_RUNTIME._linked_job_ids_from_status
_archive_request_and_linked_jobs = _ARCHIVE_RUNTIME._archive_request_and_linked_jobs

from metod_app.storage.retention_runtime import RetentionRuntime
_RETENTION_RUNTIME = RetentionRuntime(sys.modules[__name__])
_purge_old_archives = _RETENTION_RUNTIME._purge_old_archives
_request_is_terminal_for_retention = _RETENTION_RUNTIME._request_is_terminal_for_retention
_archive_expired_active_data = _RETENTION_RUNTIME._archive_expired_active_data
_cleanup_operational_state = _RETENTION_RUNTIME._cleanup_operational_state
_move_queue_file_safe = _RETENTION_RUNTIME._move_queue_file_safe
_mark_request_failed_if_stale = _RETENTION_RUNTIME._mark_request_failed_if_stale
_record_maintenance_failure = _RETENTION_RUNTIME._record_maintenance_failure
_server_maintenance_loop = _RETENTION_RUNTIME._server_maintenance_loop

from metod_app.requests.runtime import RequestRuntime
_REQUEST_RUNTIME = RequestRuntime(sys.modules[__name__])
_new_request_id = _REQUEST_RUNTIME._new_request_id
_linked_subjob_ids = _REQUEST_RUNTIME._linked_subjob_ids
_master_job_id_for = _REQUEST_RUNTIME._master_job_id_for
_public_job_family_complete = _REQUEST_RUNTIME._public_job_family_complete
_iter_request_statuses = _REQUEST_RUNTIME._iter_request_statuses
_find_request_status_for_job = _REQUEST_RUNTIME._find_request_status_for_job
_load_request_payload = _REQUEST_RUNTIME._load_request_payload

from metod_app.pricing.runtime import PricingRuntime
_PRICING_RUNTIME = PricingRuntime(sys.modules[__name__])
_default_pricing_config = _PRICING_RUNTIME._default_pricing_config
_normalize_pricing_config_schema = _PRICING_RUNTIME._normalize_pricing_config_schema
_load_pricing_config = _PRICING_RUNTIME._load_pricing_config
_ensure_pricing_config_files = _PRICING_RUNTIME._ensure_pricing_config_files
_save_pricing_config = _PRICING_RUNTIME._save_pricing_config
_migrate_legacy_materials_to_direct_sell_prices = _PRICING_RUNTIME._migrate_legacy_materials_to_direct_sell_prices
_ensure_pricing_materials = _PRICING_RUNTIME._ensure_pricing_materials
_apply_sell_pricing_to_quote = _PRICING_RUNTIME._apply_sell_pricing_to_quote
_format_eur = _PRICING_RUNTIME._format_eur
_format_m = _PRICING_RUNTIME._format_m
_extract_pricing_from_any = _PRICING_RUNTIME._extract_pricing_from_any
_aggregate_materials_from_subjob_quotes = _PRICING_RUNTIME._aggregate_materials_from_subjob_quotes
_parse_calculation_summary_totals = _PRICING_RUNTIME._parse_calculation_summary_totals

from metod_app.pricing.report_runtime import PricingReportRuntime
_PRICING_REPORT_RUNTIME = PricingReportRuntime(sys.modules[__name__])
_write_human_calculation_summary = _PRICING_REPORT_RUNTIME._write_human_calculation_summary

from metod_app.jobs.output_runtime import JobOutputRuntime
_JOB_OUTPUT_RUNTIME = JobOutputRuntime(sys.modules[__name__])
_parse_panels_csv = _JOB_OUTPUT_RUNTIME._parse_panels_csv
_is_subjob = _JOB_OUTPUT_RUNTIME._is_subjob
_filter_panels_csv_by_material = _JOB_OUTPUT_RUNTIME._filter_panels_csv_by_material
_parts_for_panels_rows = _JOB_OUTPUT_RUNTIME._parts_for_panels_rows
_customer_display_name = _JOB_OUTPUT_RUNTIME._customer_display_name
_customer_name_from_job = _JOB_OUTPUT_RUNTIME._customer_name_from_job
_material_name_and_thickness = _JOB_OUTPUT_RUNTIME._material_name_and_thickness
_resolve_stickertool_material_display_name = _JOB_OUTPUT_RUNTIME._resolve_stickertool_material_display_name
_job_material_context = _JOB_OUTPUT_RUNTIME._job_material_context
_sheet_sequence_from_filename = _JOB_OUTPUT_RUNTIME._sheet_sequence_from_filename
_admin_sheet_download_name = _JOB_OUTPUT_RUNTIME._admin_sheet_download_name
_generate_stickertool_json = _JOB_OUTPUT_RUNTIME._generate_stickertool_json
_placements_item_count = _JOB_OUTPUT_RUNTIME._placements_item_count
_generate_labels_json_strict = _JOB_OUTPUT_RUNTIME._generate_labels_json_strict
_input_dxf_source_map = _JOB_OUTPUT_RUNTIME._input_dxf_source_map
_finalize_subjob_outputs = _JOB_OUTPUT_RUNTIME._finalize_subjob_outputs
_write_master_job_links = _JOB_OUTPUT_RUNTIME._write_master_job_links
_finalization_complete = _JOB_OUTPUT_RUNTIME._finalization_complete
_sealed_output_artifacts = _JOB_OUTPUT_RUNTIME._sealed_output_artifacts


_DEFAULT_ADMIN_PASSWORDS = {"change-me", "changeme", "admin", "password", "123456", "SET_STRONG_PASSWORD"}
_ADMIN_PBKDF2_ITERATIONS = 600000
_DUMMY_ADMIN_PASSWORD_HASH = 'pbkdf2_sha256$600000$fix660r9-dummy-salt-2026$0ab0f58806255e1b2a672e3fe29950b38fd63833caea1afcb7171ce347b1ee45'
_DUMMY_ADMIN_TOTP_SECRET = 'JBSWY3DPEHPK3PXP'
_RATE_LIMITS_LOCK = threading.Lock()
_RATE_LIMITS: dict[tuple[str, str], list[float]] = {}
_PUBLIC_JOB_ADMISSION = PublicJobAdmission(lock=threading.Lock())
_PUBLIC_JOB_CREATE_LOCK = _PUBLIC_JOB_ADMISSION.lock
_PUBLIC_JOB_CREATE_BY_IP = _PUBLIC_JOB_ADMISSION.by_ip
_PUBLIC_JOB_CREATE_TOTAL = _PUBLIC_JOB_ADMISSION.total
_PUBLIC_JOB_RESERVED_TOTAL = _PUBLIC_JOB_ADMISSION.reserved_total
_PUBLIC_JOB_RESERVED_BY_IP = _PUBLIC_JOB_ADMISSION.reserved_by_ip
_PUBLIC_JOB_SCHEDULER = PublicJobScheduler(
    admission=_PUBLIC_JOB_ADMISSION,
    max_active=lambda: _public_job_queue_limits()[0],
)
_PUBLIC_JOB_QUEUE = _PUBLIC_JOB_SCHEDULER.queue
_PUBLIC_JOB_ACTIVE_BY_ID = _PUBLIC_JOB_SCHEDULER.active_by_id
_PUBLIC_JOB_ACTIVE_TOTAL = _PUBLIC_JOB_SCHEDULER.active_total
_STATE_CAPACITY_RESERVATIONS = StateCapacityReservations(lock=threading.RLock())
_JOB_STORAGE_RESERVATION_LOCK = _STATE_CAPACITY_RESERVATIONS.lock
_JOB_STORAGE_RESERVATIONS = _STATE_CAPACITY_RESERVATIONS.records
_ADMIN_SESSION_STORE = AdminSessionStore(
    idle_seconds=_RUNTIME_CONFIG.admin_session_idle_seconds,
    absolute_seconds=_RUNTIME_CONFIG.admin_session_absolute_seconds,
    max_sessions=lambda: _env_int('ADMIN_MAX_SESSIONS', 1024),
    lock=threading.Lock(),
)


class BoundedThreadingHTTPServer(ThreadingHTTPServer):
    """Thread-per-request development server with a strict global concurrency cap.

    Nginx remains the public edge, but the application must also fail closed when
    upstream limits are misconfigured or bypassed.
    """

    daemon_threads = True
    allow_reuse_address = True
    request_queue_size = 128

    def __init__(self, server_address, request_handler_class):
        self._request_slots = threading.BoundedSemaphore(max(1, min(256, _env_int('HTTP_MAX_CONCURRENT', 64))))
        super().__init__(server_address, request_handler_class)

    def process_request(self, request, client_address):
        if not self._request_slots.acquire(blocking=False):
            try:
                request.sendall(
                    b'HTTP/1.1 503 Service Unavailable\r\n'
                    b'Connection: close\r\nContent-Type: text/plain; charset=utf-8\r\n'
                    b'Content-Length: 21\r\n\r\nServer is at capacity'
                )
            except Exception:
                pass
            self.shutdown_request(request)
            return
        try:
            super().process_request(request, client_address)
        except Exception:
            self._request_slots.release()
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self._request_slots.release()


def _sync_public_job_admission_legacy_counters() -> None:
    """Keep read-only legacy diagnostics aligned during scheduler migration."""

    global _PUBLIC_JOB_CREATE_TOTAL, _PUBLIC_JOB_RESERVED_TOTAL
    _PUBLIC_JOB_CREATE_TOTAL = _PUBLIC_JOB_ADMISSION.total
    _PUBLIC_JOB_RESERVED_TOTAL = _PUBLIC_JOB_ADMISSION.reserved_total


def _sync_public_job_scheduler_legacy_counter() -> None:
    """Keep the read-only legacy active counter aligned during extraction."""

    global _PUBLIC_JOB_ACTIVE_TOTAL
    _PUBLIC_JOB_ACTIVE_TOTAL = _PUBLIC_JOB_SCHEDULER.active_total


def _sync_public_job_scheduler_legacy_state() -> None:
    """Synchronize all read-only migration diagnostics under scheduler lock."""

    _sync_public_job_admission_legacy_counters()
    _sync_public_job_scheduler_legacy_counter()


# Prefer the Windows Python launcher (py -3) to avoid binding to a specific installed python.exe
# and to keep compatibility with environments where sys.executable may be a newer Python (e.g. 3.14).

# --- Server-Sent Events (SSE) for live updates (ToolA reload without page refresh) ---
_SSE_CLIENTS_LOCK = threading.Lock()
_SSE_CLIENTS: list[queue.Queue] = []
_MAX_SSE_CLIENTS = _RUNTIME_CONFIG.max_sse_clients


_PUBLIC_SSE_EVENT_ALLOWLIST = frozenset({'dxf_changed'})


# --- DXF startup migration (file-based, deterministic) ---
DXF_CATEGORIES = [
    "Deuren METOD",
    "Ladefront METOD",
    "Deuren PAX",
    "Overige panelen",
]


OPTIMIZER_TOOL_B = 'dxf_nesting_optimizer.py'  # rollback: set to 'dxf_nesting_optimizer_v1_2.py'
JOBS = _APP_PATHS.jobs
DRAFTS = _APP_PATHS.drafts

# Lightweight index/registry folder (used by some endpoints).
INDEX_DIR = _APP_PATHS.index_dir

# Append-only requests index (JSONL). This is used to power Admin inbox views
# without scanning the full requests tree. Must be defined at module load so
# endpoints like /api/submit_config never fail with NameError.
REQUESTS_INDEX = _APP_PATHS.requests_index
_REQUESTS_INDEX_LOCK = threading.RLock()

# --- Requests/Queue (online A-only foundation; file-based, deterministic) ---
REQUESTS = _APP_PATHS.requests
QUEUE_DIR = _APP_PATHS.queue_dir
QUEUE_PENDING = _APP_PATHS.queue_pending
QUEUE_PROCESSING = _APP_PATHS.queue_processing
QUEUE_DONE = _APP_PATHS.queue_done
QUEUE_FAILED = _APP_PATHS.queue_failed
SUBMISSION_IDEMPOTENCY_DIR = _APP_PATHS.submission_idempotency_dir
_SUBMISSION_IDEMPOTENCY_LOCK = threading.Lock()
_ARCHIVE_TRANSACTION_LOCK = threading.RLock()

# --- Retention / archive (terminal 90d, open hard max 365d -> archive; archive 90d; orphan jobs 7d) ---
ARCHIVE_ROOT = _APP_PATHS.archive_root
ARCHIVE_JOBS = _APP_PATHS.archive_jobs
ARCHIVE_REQUESTS = _APP_PATHS.archive_requests
ARCHIVE_QUEUE_DONE = _APP_PATHS.archive_queue_done
ARCHIVE_QUEUE_FAILED = _APP_PATHS.archive_queue_failed
ARCHIVE_TRANSACTIONS = _APP_PATHS.archive_transactions
RETENTION_ACTIVE_DAYS = _RUNTIME_CONFIG.retention_active_days
RETENTION_OPEN_REQUEST_MAX_DAYS = _RUNTIME_CONFIG.retention_open_request_max_days
RETENTION_ARCHIVE_DAYS = _RUNTIME_CONFIG.retention_archive_days
ORPHAN_JOB_RETENTION_DAYS = _RUNTIME_CONFIG.orphan_job_retention_days
ARCHIVE_META_NAME = ".archived_meta.json"
_LAST_RETENTION_RUN_TS = 0.0
_RETENTION_MIN_INTERVAL_SECONDS = 6 * 60 * 60  # max 1x per 6 uur per proces

# Queue / maintenance hardening
STALE_PENDING_QUEUE_DAYS = 7
STALE_PROCESSING_QUEUE_HOURS = 24
_LAST_QUEUE_MAINTENANCE_TS = 0.0
_QUEUE_MAINTENANCE_MIN_INTERVAL_SECONDS = 60 * 60  # max 1x per uur per proces
_SERVER_MAINTENANCE_LOOP_SECONDS = 15 * 60

# --- System logs / backups ---
SYSTEM_DIR = _APP_PATHS.system_dir
CATALOG_IMPORT_ROOT = _APP_PATHS.catalog_import_root
CATALOG_IMPORT_HISTORY = _APP_PATHS.catalog_import_history
SYSTEM_LOG_FILE = _APP_PATHS.system_log_file
BACKUPS_DIR = _APP_PATHS.backups_dir
AUTO_BACKUP_INTERVAL_DAYS = 7
AUTO_BACKUP_KEEP = 8
MANUAL_BACKUP_KEEP = 12
LAST_AUTO_BACKUP_FILE = _APP_PATHS.last_auto_backup_file
_STATE_SNAPSHOT_LOCK = threading.RLock()
_STATE_MAINTENANCE_LOCK = threading.Lock()
_STATE_MUTATION_CV = threading.Condition(threading.RLock())
_STATE_MUTATION_COUNT = 0
_STATE_SNAPSHOT_ACTIVE = False


# --- Notifications (ntfy) ---
CONFIG_NOTIFY = _APP_PATHS.config_notify
CONFIG_NOTIFY_EXAMPLE = ROOT / "config_notify.example.json"


NTFY_LOG = _APP_PATHS.ntfy_log


_MATERIAL_NAME_BY_CODE = None

def _load_material_name_by_code() -> dict:
    global _MATERIAL_NAME_BY_CODE
    if isinstance(_MATERIAL_NAME_BY_CODE, dict):
        return _MATERIAL_NAME_BY_CODE
    out = {}
    try:
        ml_path = MATERIAL_LIBRARY_PATH
        if ml_path.exists():
            raw = strict_json_load(ml_path)
            recs = raw.get("records") if isinstance(raw, dict) else raw
            if isinstance(recs, list):
                for r in recs:
                    if not isinstance(r, dict):
                        continue
                    code = str(r.get("articleNo") or r.get("articleNumber") or r.get("materialCode") or "").strip()
                    name = str(r.get("productName") or r.get("materialDisplayName") or r.get("materialName") or "").strip()
                    if code and name and code not in out:
                        out[code] = name
    except Exception:
        pass
    _MATERIAL_NAME_BY_CODE = out
    return out


_REQUEST_PROJECTION = RequestProjection(best_material_name=_best_material_name)
_extract_request_summary = _REQUEST_PROJECTION.extract_summary


PORT = _RUNTIME_CONFIG.port
JOB_OUTPUT_MAX_BYTES = _RUNTIME_CONFIG.job_output_max_bytes


DXF_CATEGORIES = [
    "Deuren METOD",
    "Ladefront METOD",
    "Deuren PAX",
    "Overige panelen",
]


CONFIG_DIR = _APP_PATHS.config_dir
PRICING_ACTIVE = _APP_PATHS.pricing_active
PRICING_VERSIONS = _APP_PATHS.pricing_versions
PRICING_AUDIT = _APP_PATHS.pricing_audit

# --- Pricing rules (sell prices) ---
# Legacy factor is read only once for one-time migration of existing material prices.
# New calculations never apply a material factor: each material carries its own direct sell price.
LEGACY_SHEET_PRICE_FACTOR_DEFAULT = _RUNTIME_CONFIG.legacy_sheet_price_factor_default
# Edge banding sell price per meter.
EDGE_BAND_PRICE_PER_M = _RUNTIME_CONFIG.edge_band_price_per_m
# CNC routing cost per used sheet.
CNC_COST_PER_SHEET = _RUNTIME_CONFIG.cnc_cost_per_sheet
# One-time drawing / setup cost per job.
DRAWING_COST_FIXED = _RUNTIME_CONFIG.drawing_cost_fixed
# One-time transport cost per job.
TRANSPORT_COST_FIXED = _RUNTIME_CONFIG.transport_cost_fixed


HOST = _RUNTIME_CONFIG.host
PUBLIC_HOST = _RUNTIME_CONFIG.public_host
PUBLIC_BASE_URL = _RUNTIME_CONFIG.public_base_url

# in-memory job status
_job_lock = threading.Lock()
_job_meta: dict[str, dict] = {}
_OPTIMIZER_PROCESS_SUPERVISOR = OptimizerProcessSupervisor(
    lock=threading.RLock(),
    validate_job_id=validate_job_id,
    os_module=os,
    signal_module=signal,
)
# Compatibility aliases for the unchanged maintenance-barrier contract.
_ACTIVE_JOB_PROCESSES_LOCK = _OPTIMIZER_PROCESS_SUPERVISOR.lock
_ACTIVE_JOB_PROCESSES = _OPTIMIZER_PROCESS_SUPERVISOR.processes

_STATE_MAINTENANCE_BARRIER = StateMaintenanceBarrier(
    ensure_directories=lambda: _ensure_system_dirs(),
    backups_root=lambda: BACKUPS_DIR,
    maintenance_lock=lambda: _STATE_MAINTENANCE_LOCK,
    file_lock_module=lambda: _fcntl,
    mutation_condition=lambda: _STATE_MUTATION_CV,
    snapshot_active=lambda: _STATE_SNAPSHOT_ACTIVE,
    set_snapshot_active=lambda value: globals().__setitem__(
        '_STATE_SNAPSHOT_ACTIVE', bool(value)
    ),
    mutation_count=lambda: _STATE_MUTATION_COUNT,
    set_mutation_count=lambda value: globals().__setitem__(
        '_STATE_MUTATION_COUNT', max(0, int(value))
    ),
    public_job_create_lock=lambda: _PUBLIC_JOB_CREATE_LOCK,
    public_job_create_total=lambda: _PUBLIC_JOB_CREATE_TOTAL,
    active_job_processes_lock=lambda: _ACTIVE_JOB_PROCESSES_LOCK,
    active_job_processes=lambda: _ACTIVE_JOB_PROCESSES,
    catalog_image_sync_lock=lambda: _CATALOG_IMAGE_SYNC_LOCK,
    catalog_image_sync_active=lambda: _CATALOG_IMAGE_SYNC_ACTIVE,
    queue_processing_root=lambda: QUEUE_PROCESSING,
    monotonic=lambda: time.monotonic(),
    sleep=lambda seconds: time.sleep(seconds),
)
_state_snapshot_is_active = _STATE_MAINTENANCE_BARRIER.snapshot_is_active
_exclusive_state_maintenance = _STATE_MAINTENANCE_BARRIER.exclusive
_begin_consistent_snapshot = _STATE_MAINTENANCE_BARRIER.begin_consistent_snapshot
_end_consistent_snapshot = _STATE_MAINTENANCE_BARRIER.end_consistent_snapshot


class JobCancelledError(RuntimeError):
    pass


_JOB_RESTART_RECONCILER = JobRestartReconciler(
    jobs_root=JOBS,
    read_json=lambda path: strict_json_load(path),
    validate_job_id=lambda value: validate_job_id(value),
    save_runtime_state=lambda job_id, state, **extra: _save_job_runtime_state(
        job_id, state, **extra
    ),
    append_system_event=lambda **event: _append_system_event(**event),
)


# --- Atomic file utilities (avoid 0-byte / race conditions) ---


_REQUEST_REPOSITORY = RequestRepository(
    requests_root=lambda: REQUESTS,
    requests_index=lambda: REQUESTS_INDEX,
    index_lock=lambda: _REQUESTS_INDEX_LOCK,
    ensure_directories=_ensure_request_dirs,
    utc_now_iso=_utc_now_iso,
    jsonl_max_bytes=lambda: _env_int("JSONL_MAX_BYTES", 20 * 1024 * 1024),
    max_active_rows=lambda: _env_int("REQUEST_INDEX_MAX_ACTIVE_ROWS", 250_000),
    file_lock_module=lambda: _fcntl,
)
_load_status = _REQUEST_REPOSITORY.load_status
_save_status = _REQUEST_REPOSITORY.save_status
_compact_requests_index = _REQUEST_REPOSITORY.compact_index


def run_retention_maintenance(force: bool = False) -> dict:
    global _LAST_RETENTION_RUN_TS
    with _exclusive_state_maintenance():
        now_ts = time.time()
        if (not force) and _LAST_RETENTION_RUN_TS and (now_ts - _LAST_RETENTION_RUN_TS) < _RETENTION_MIN_INTERVAL_SECONDS:
            return {'ok': True, 'skipped': True, 'reason': 'interval'}

        # An attempted-but-failed run must never suppress the next retry for
        # six hours. Only a fully successful pass below records a timestamp.
        _LAST_RETENTION_RUN_TS = 0.0
        snapshot_started = False
        try:
            _begin_consistent_snapshot(timeout_seconds=max(10, _env_int('RETENTION_DRAIN_TIMEOUT_SEC', 60)))
            snapshot_started = True
            now_dt = datetime.now(timezone.utc).replace(tzinfo=None)
            recovered = _reconcile_archive_transactions()
            archived = _archive_expired_active_data(now_dt)
            purged = _purge_old_archives(now_dt)
            operational = _cleanup_operational_state(now_dt)
            try:
                request_index = _compact_requests_index()
            except Exception as exc:
                request_index = {'error': str(exc)}
        finally:
            if snapshot_started:
                _end_consistent_snapshot()

        errors: list[Any] = []
        errors.extend(recovered.get('errors') or [])
        errors.extend(archived.get('errors') or [])
        errors.extend(purged.get('errors') or [])
        errors.extend(operational.get('errors') or [])
        if request_index.get('error'):
            errors.append({'requestIndex': str(request_index['error'])})
        ok = not errors
        if ok:
            _LAST_RETENTION_RUN_TS = time.time()
        return {
            'ok': ok,
            'archived': archived,
            'recoveredArchives': recovered,
            'purged': purged,
            'operational': operational,
            'requestIndex': request_index,
            'errors': errors,
            'ranAt': now_dt.isoformat() + 'Z',
        }


def run_queue_maintenance(force: bool = False) -> dict:
    global _LAST_QUEUE_MAINTENANCE_TS
    with _exclusive_state_maintenance():
        if _state_snapshot_is_active():
            return {'ok': True, 'skipped': True, 'reason': 'state-snapshot'}
        now_ts = time.time()
        if (not force) and _LAST_QUEUE_MAINTENANCE_TS and (now_ts - _LAST_QUEUE_MAINTENANCE_TS) < _QUEUE_MAINTENANCE_MIN_INTERVAL_SECONDS:
            return {'ok': True, 'skipped': True, 'reason': 'interval'}
        # Failed queue maintenance must remain immediately retryable rather than
        # being hidden behind the normal one-hour success interval.
        _LAST_QUEUE_MAINTENANCE_TS = 0.0
        now_dt = datetime.now(timezone.utc).replace(tzinfo=None)
        result = {'ok': True, 'pendingFailed': 0, 'processingFailed': 0, 'errors': [], 'ranAt': now_dt.isoformat() + 'Z'}

        def _handle_stale(path: Path, *, age_delta: timedelta, bucket: str, code: str, message: str) -> None:
            try:
                mtime = datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc).replace(tzinfo=None)
            except Exception as e:
                result['errors'].append({'file': path.name, 'error': str(e)})
                return
            if now_dt - mtime < age_delta:
                return
            request_id = ''
            try:
                payload = strict_json_load(path)
                request_id = _safe_id((payload or {}).get('requestId') or '', 120)
            except Exception:
                payload = None
            try:
                if request_id:
                    _mark_request_failed_if_stale(request_id, code=code, message=message)
                _move_queue_file_safe(path, QUEUE_FAILED)
                result[bucket] += 1
                _append_system_event(level='warning', component='jobs', message_user='Een verouderd queue-item is automatisch afgehandeld', message_tech=f'{path.name} marked stale in {path.parent.name}', request_id=request_id or None, status='open')
            except Exception as e:
                result['errors'].append({'file': path.name, 'error': str(e)})

        for path in sorted(QUEUE_PENDING.glob('*.json')):
            _handle_stale(path, age_delta=timedelta(days=STALE_PENDING_QUEUE_DAYS), bucket='pendingFailed', code='STALE_PENDING_QUEUE_ITEM', message='Aanvraag te lang in wachtrij gebleven en automatisch als fout gemarkeerd.')
        for path in sorted(QUEUE_PROCESSING.glob('*.json')):
            _handle_stale(path, age_delta=timedelta(hours=STALE_PROCESSING_QUEUE_HOURS), bucket='processingFailed', code='STALE_PROCESSING_QUEUE_ITEM', message='Aanvraag bleef te lang in verwerking hangen en is automatisch als fout gemarkeerd.')
        result['ok'] = not result['errors']
        if result['ok']:
            _LAST_QUEUE_MAINTENANCE_TS = time.time()
        return result


# Submission claims and the authenticated commit transaction are composed below,
# after the strict authoritative pricing reader is defined.


# --- Pricing config (Option B: versioned active pricing) ---


    # New jobs have one authoritative, finalization-sealed summary in output/.
    # Readers retain the input/ fallback solely for historical jobs; writing an
    # identical unsealed mirror cost two extra storage barriers per job/subjob.


# FIX660R8X_ADMIN_DXF_CUSTOMER_DECOR_SEQUENCE


from metod_app.runtime.composition import (
    build_core_runtime_services as _build_core_runtime_services,
)


_CORE_RUNTIME_SERVICES = _build_core_runtime_services(sys.modules[__name__])
_JOB_FINALIZATION_SERVICE = _CORE_RUNTIME_SERVICES.job_finalization
_OBSERVABILITY = _CORE_RUNTIME_SERVICES.observability
_ADMIN_ACCESS = _CORE_RUNTIME_SERVICES.admin_access
_STATIC_HTTP = _CORE_RUNTIME_SERVICES.static_http
_JOB_LIFECYCLE = _CORE_RUNTIME_SERVICES.job_lifecycle

from metod_app.http.handler import build_handler as _build_http_handler


Handler = _build_http_handler(sys.modules[__name__])


# Thin compatibility adapters keep the established internal call surface while
# endpoint implementation is owned by bounded HTTP modules.
from metod_app.http.endpoints import drafts as _http_drafts
from metod_app.http.endpoints import admin_jobs as _http_admin_jobs
from metod_app.http.endpoints import admin_requests as _http_admin_requests
from metod_app.http.endpoints import downloads as _http_downloads
from metod_app.http.endpoints import control_center as _http_control_center


def api_draft_save(self):
    return _http_drafts.api_draft_save(sys.modules[__name__], self)

def api_dxf_manifest_meta(handler, parsed):
    return _http_drafts.api_dxf_manifest_meta(sys.modules[__name__], handler, parsed)

def api_draft_load(self, parsed):
    return _http_drafts.api_draft_load(sys.modules[__name__], self, parsed)

def _edge_meters_by_decor(job_dir: Path):
    return _http_admin_jobs._edge_meters_by_decor(sys.modules[__name__], job_dir)

def api_admin_jobs(self):
    return _http_admin_jobs.api_admin_jobs(sys.modules[__name__], self)

def _classify_output_kind(name: str):
    return _http_admin_jobs._classify_output_kind(sys.modules[__name__], name)

def _collect_job_output_files(job_id: str):
    return _http_admin_jobs._collect_job_output_files(sys.modules[__name__], job_id)

def _dedupe_admin_dxf_files(files: list[dict]):
    return _http_admin_jobs._dedupe_admin_dxf_files(sys.modules[__name__], files)

def _extract_strict_calculation_pricing_summary(job_ids: list[str]):
    return _http_admin_jobs._extract_strict_calculation_pricing_summary(sys.modules[__name__], job_ids)

def _extract_admin_pricing_summary(job_ids: list[str], request_status: dict | None=None):
    return _http_admin_jobs._extract_admin_pricing_summary(sys.modules[__name__], job_ids, request_status)

def _find_or_generate_stickertool_file(job_id: str):
    return _http_admin_jobs._find_or_generate_stickertool_file(sys.modules[__name__], job_id)

def _dir_size_bytes(root: Path):
    return _http_admin_requests._dir_size_bytes(sys.modules[__name__], root)

def _build_request_file_manifest(request_id: str):
    return _http_admin_requests._build_request_file_manifest(sys.modules[__name__], request_id)

def api_admin_request_files(self):
    return _http_admin_requests.api_admin_request_files(sys.modules[__name__], self)

def api_admin_request_file(self):
    return _http_admin_requests.api_admin_request_file(sys.modules[__name__], self)

def api_admin_request_download_zip(self):
    return _http_admin_requests.api_admin_request_download_zip(sys.modules[__name__], self)

def api_admin_requests(self):
    return _http_admin_requests.api_admin_requests(sys.modules[__name__], self)

def api_admin_requests_update(self):
    return _http_admin_requests.api_admin_requests_update(sys.modules[__name__], self)

def api_job_file(self, job_id: str, rel: str, parsed=None, *, download_name_override: str | None=None):
    return _http_downloads.api_job_file(sys.modules[__name__], self, job_id, rel, parsed, download_name_override=download_name_override)

def api_stickertool_v2(self, subjob_id: str):
    return _http_downloads.api_stickertool_v2(sys.modules[__name__], self, subjob_id)

def api_subjob_file(self, job_id: str, subjob_id: str, rel: str, parsed=None):
    return _http_downloads.api_subjob_file(sys.modules[__name__], self, job_id, subjob_id, rel, parsed)

def api_download(self, job_id: str, fname: str, parsed=None):
    return _http_downloads.api_download(sys.modules[__name__], self, job_id, fname, parsed)

def _fmt_bytes(n: int):
    return _http_control_center._fmt_bytes(sys.modules[__name__], n)

def api_admin_control_center(self):
    return _http_control_center.api_admin_control_center(sys.modules[__name__], self)

from metod_app.runtime.composition import build_runtime_services as _build_runtime_services


_RUNTIME_SERVICES = _build_runtime_services(sys.modules[__name__])
_SUBMISSION_CLAIMS = _RUNTIME_SERVICES.submission_claims
_submission_marker_path = _SUBMISSION_CLAIMS.marker_path
_read_submission_claim = _SUBMISSION_CLAIMS.read_claim
_reserve_submission_claim = _SUBMISSION_CLAIMS.reserve_claim
_SUBMISSION_SERVICE = _RUNTIME_SERVICES.submission_service
_REQUEST_DOWNLOAD_PROJECTIONS = _RUNTIME_SERVICES.request_downloads

from metod_app.jobs import execution as _job_execution
from metod_app.runtime import worker as _queue_worker


def _acquire_worker_lock() -> bool:
    return _queue_worker.acquire_worker_lock(sys.modules[__name__])


def _release_worker_lock() -> None:
    _queue_worker.release_worker_lock(sys.modules[__name__])


def _create_job_from_payload(payload: dict, master_job_id: str | None = None,
                             public_access_token: str = '') -> dict:
    return _job_execution.create_job_from_payload(
        sys.modules[__name__], payload, master_job_id, public_access_token,
    )


def process_one_queue_item() -> bool:
    return _queue_worker.process_one_queue_item(sys.modules[__name__])


def _recover_processing_queue_items_fix657() -> dict:
    return _queue_worker.recover_processing_queue_items(sys.modules[__name__])


def worker_loop(poll_seconds: float = 1.0) -> None:
    _queue_worker.worker_loop(sys.modules[__name__], poll_seconds)


def _readiness_report() -> tuple[dict[str, Any], int]:
    return _OBSERVABILITY.readiness_report()


def _prometheus_metrics() -> str:
    return _OBSERVABILITY.prometheus_metrics()

from metod_app.runtime import startup as _startup_runtime


def _validate_production_runtime_or_die() -> None:
    _startup_runtime.validate_production_runtime_or_die(sys.modules[__name__])


def main() -> None:
    _startup_runtime.run_server(sys.modules[__name__])


def run_worker() -> None:
    _startup_runtime.run_worker(sys.modules[__name__])
