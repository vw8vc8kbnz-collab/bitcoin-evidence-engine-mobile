from __future__ import annotations

"""Fail-closed production validation and explicit process startup owners."""

def validate_production_runtime_or_die(runtime) -> None:
    """Fail closed before binding a public socket when production invariants are unsafe."""
    MATERIAL_LIBRARY_PATH = runtime.MATERIAL_LIBRARY_PATH
    Path = runtime.Path
    RELEASE_ROOT = runtime.RELEASE_ROOT
    ROOT = runtime.ROOT
    STATE_ROOT = runtime.STATE_ROOT
    SYSTEM_DIR = runtime.SYSTEM_DIR
    SafetyContractError = runtime.SafetyContractError
    _admin_password_reset_activation_is_enabled = runtime._admin_password_reset_activation_is_enabled
    _env_flag = runtime._env_flag
    _env_int = runtime._env_int
    _get_admin_credentials_file_path = runtime._get_admin_credentials_file_path
    _is_password_hash_value = runtime._is_password_hash_value
    _is_production_hardening_enabled = runtime._is_production_hardening_enabled
    _normalized_admin_users = runtime._normalized_admin_users
    _split_env_csv = runtime._split_env_csv
    _totp_code = runtime._totp_code
    datetime = runtime.datetime
    hmac = runtime.hmac
    os = runtime.os
    re = runtime.re
    sha256_file = runtime.sha256_file
    strict_json_load = runtime.strict_json_load
    timedelta = runtime.timedelta
    timezone = runtime.timezone
    urlparse = runtime.urlparse

    if not _is_production_hardening_enabled():
        return
    errors: list[str] = []
    app_env = str(os.environ.get('APP_ENV') or '').strip().lower()
    if app_env not in ('prod', 'production'):
        errors.append('APP_ENV must be production')
    if not _env_flag('PRODUCTION_HARDENING', False):
        errors.append('PRODUCTION_HARDENING must be 1')
    if not _env_flag('ADMIN_HASH_ONLY', False):
        errors.append('ADMIN_HASH_ONLY must be 1')
    if _env_flag('ADMIN_STAGING_OPEN', False):
        errors.append('ADMIN_STAGING_OPEN must be 0')
    legacy_admin_env = [
        name for name in ('ADMIN_USER', 'ADMIN_PASS', 'ADMIN_PASS_HASH', 'ADMIN_TOTP_SECRET')
        if str(os.environ.get(name) or '').strip()
    ]
    if legacy_admin_env:
        errors.append(
            'legacy shared admin environment credentials are forbidden: '
            + ', '.join(legacy_admin_env)
        )

    if _env_flag('LEGACY_HTTP_COMPAT', False) or str(os.environ.get('LEGACY_HTTP_ORIGIN') or '').strip():
        errors.append('legacy plaintext HTTP compatibility is forbidden in production')

    def _check_origins(name: str) -> None:
        vals = _split_env_csv(name)
        if not vals:
            errors.append(f'{name} must be set')
            return
        for origin in vals:
            try:
                u = urlparse(origin)
                structural_ok = bool(
                    u.hostname and not u.username and not u.password and '*' not in origin
                    and not u.query and not u.fragment and u.path in ('', '/')
                )
                if not (structural_ok and u.scheme.lower() == 'https'):
                    raise ValueError('origin must be exact HTTPS origin')
            except Exception:
                errors.append(f'{name} contains unsafe origin: {origin!r}')
    _check_origins('ALLOWED_ORIGINS')
    _check_origins('ALLOWED_ADMIN_ORIGINS')

    try:
        public_url = urlparse(str(os.environ.get('METOD_PUBLIC_BASE_URL') or '').strip())
        if not (
            public_url.scheme.lower() == 'https' and public_url.hostname
            and not public_url.username and not public_url.password
            and not public_url.query and not public_url.fragment
        ):
            raise ValueError('invalid HTTPS URL')
    except Exception:
        errors.append('METOD_PUBLIC_BASE_URL must be an absolute HTTPS URL')

    try:
        release_resolved = RELEASE_ROOT.resolve()
        state_resolved = STATE_ROOT.resolve()
        if state_resolved == release_resolved or release_resolved in state_resolved.parents:
            errors.append('METOD_STATE_ROOT must be outside the immutable release directory')
    except Exception:
        errors.append('METOD_STATE_ROOT cannot be resolved')
    if os.name != 'nt' and hasattr(os, 'geteuid') and os.geteuid() == 0:
        errors.append('the application service must run as a dedicated non-root user')

    public_limit = _env_int('PUBLIC_JSON_MAX_BYTES', 16 * 1024 * 1024)
    submit_limit = _env_int('SUBMIT_MAX_BYTES', 8 * 1024 * 1024)
    dxf_limit = _env_int('PUBLIC_DXF_BLOB_MAX_BYTES', 2 * 1024 * 1024)
    dxf_count_limit = _env_int('PUBLIC_DXF_MAX_COUNT', 500)
    if public_limit <= 0 or public_limit > 16 * 1024 * 1024:
        errors.append('PUBLIC_JSON_MAX_BYTES must be between 1 and 16777216')
    if submit_limit <= 0 or submit_limit > 8 * 1024 * 1024:
        errors.append('SUBMIT_MAX_BYTES must be between 1 and 8388608')
    if dxf_limit <= 0 or dxf_limit > 2 * 1024 * 1024:
        errors.append('PUBLIC_DXF_BLOB_MAX_BYTES must be between 1 and 2097152')
    if dxf_count_limit <= 0 or dxf_count_limit > 500:
        errors.append('PUBLIC_DXF_MAX_COUNT must be between 1 and 500')
    if not (1 <= _env_int('PUBLIC_JOB_MAX_CONCURRENT', 2) <= 8):
        errors.append('PUBLIC_JOB_MAX_CONCURRENT must be between 1 and 8')
    if _env_int('PUBLIC_JOB_MAX_QUEUED', 8) != 8:
        errors.append('PUBLIC_JOB_MAX_QUEUED must be 8 on the current production baseline')
    if _env_int('PUBLIC_JOB_MAX_CONCURRENT_PER_IP', 2) != 2:
        errors.append('PUBLIC_JOB_MAX_CONCURRENT_PER_IP must be 2 on the current production baseline')
    optimizer_timeout = _env_int('OPTIMIZER_TIMEOUT_SECONDS', 300)
    optimizer_job_timeout = _env_int('OPTIMIZER_JOB_TIMEOUT_SECONDS', 900)
    if not (30 <= optimizer_timeout <= 3_600):
        errors.append('OPTIMIZER_TIMEOUT_SECONDS must be between 30 and 3600')
    if not (optimizer_timeout <= optimizer_job_timeout <= 86_400):
        errors.append('OPTIMIZER_JOB_TIMEOUT_SECONDS must be between the subjob timeout and 86400')
    if not (1 <= _env_int('HTTP_MAX_CONCURRENT', 64) <= 256):
        errors.append('HTTP_MAX_CONCURRENT must be between 1 and 256')
    if not (1 <= _env_int('MAX_SSE_CLIENTS', 24) <= 128):
        errors.append('MAX_SSE_CLIENTS must be between 1 and 128')

    try:
        lib = strict_json_load(MATERIAL_LIBRARY_PATH)
        records = lib.get('records') if isinstance(lib, dict) else None
        if not isinstance(records, list):
            raise SafetyContractError('records must be a list')
        active_count = sum(
            1 for rec in records
            if isinstance(rec, dict)
            and str(rec.get('sourceKind') or '').upper() == 'CATALOG_IMPORT'
            and rec.get('active') is not False and rec.get('archived') is not True
            and rec.get('published') is True and rec.get('catalogMissing') is not True
            and rec.get('catalogExcluded') is not True
        )
        required_count = max(1, _env_int('PRODUCTION_MIN_CATALOG_RECORDS', 1))
        if active_count < required_count:
            errors.append(f'active published catalog has {active_count} records; requires at least {required_count}')
        signoff_path = Path(os.environ.get('CATALOG_SIGNOFF_FILE') or (SYSTEM_DIR / 'catalog_signoff.json')).expanduser()
        signoff = strict_json_load(signoff_path)
        if not isinstance(signoff, dict) or signoff.get('approved') is not True:
            errors.append('catalog signoff must explicitly be approved')
        elif not hmac.compare_digest(str(signoff.get('materialLibrarySha256') or ''), sha256_file(MATERIAL_LIBRARY_PATH)):
            errors.append('catalog signoff hash does not match the active material library')
        elif not str(signoff.get('approvedBy') or '').strip() or not str(signoff.get('approvedAt') or '').strip():
            errors.append('catalog signoff must contain approvedBy and approvedAt')
    except Exception as e:
        errors.append(f'catalog/signoff validation failed: {e}')

    creds_path = _get_admin_credentials_file_path()
    try:
        root_resolved = ROOT.resolve()
        creds_resolved = creds_path.resolve()
        if creds_resolved == root_resolved or root_resolved in creds_resolved.parents:
            errors.append('ADMIN_CREDENTIALS_FILE must be outside the application directory')
    except Exception:
        errors.append('ADMIN_CREDENTIALS_FILE path cannot be resolved')
    try:
        creds = strict_json_load(creds_path)
        users = _normalized_admin_users(creds if isinstance(creds, dict) else {})
        if not users:
            errors.append('admin credentials must contain at least one active individual user')
        usernames = [str(user.get('username') or '') for user in users]
        if len(usernames) != len(set(usernames)):
            errors.append('admin usernames must be unique')
        for user in users:
            username = str(user.get('username') or '')
            if not re.fullmatch(r'[A-Za-z0-9_.@-]{3,80}', username):
                errors.append(f'admin username is invalid: {username!r}')
            if not _is_password_hash_value(user.get('password_hash')):
                errors.append(f'admin user {username!r} requires a PBKDF2-SHA256 password_hash')
            secret = str(user.get('totp_secret') or '')
            try:
                _totp_code(secret, 0)
            except Exception:
                errors.append(f'admin user {username!r} requires a valid TOTP secret')
            if 'admin' not in set(user.get('roles') or []):
                errors.append(f'admin user {username!r} requires the admin role')
        if isinstance(creds, dict) and (str(creds.get('password') or '').strip() or creds.get('username')):
            errors.append('legacy shared/plaintext admin credentials are forbidden in production')
        if isinstance(creds, dict):
            for raw_user in creds.get('users') or []:
                if isinstance(raw_user, dict) and str(raw_user.get('password') or '').strip():
                    errors.append('plaintext passwords are forbidden in production credentials')
        if os.name != 'nt' and (creds_path.stat().st_mode & 0o777) not in {0o400, 0o600}:
            errors.append('admin credentials permissions must be 0400 or 0600')
    except Exception as e:
        errors.append(f'admin credentials unreadable: {e}')
    if _admin_password_reset_activation_is_enabled():
        errors.append('admin password reset activation must be disabled')

    if not _env_flag('OFFSITE_BACKUP_VERIFIED', False):
        errors.append('OFFSITE_BACKUP_VERIFIED must be 1 after encrypted off-host backup verification')
    if not str(os.environ.get('OFFSITE_BACKUP_PROVIDER') or '').strip():
        errors.append('OFFSITE_BACKUP_PROVIDER must identify the encrypted off-host backup target')
    try:
        restore_proof_path = Path(os.environ.get('RESTORE_TEST_PROOF_FILE') or (SYSTEM_DIR / 'restore_test_proof.json')).expanduser()
        proof = strict_json_load(restore_proof_path)
        verified_at = datetime.fromisoformat(str(proof.get('verifiedAt') or '').replace('Z', '+00:00'))
        if verified_at.tzinfo is None:
            verified_at = verified_at.replace(tzinfo=timezone.utc)
        age = datetime.now(timezone.utc) - verified_at.astimezone(timezone.utc)
        if proof.get('ok') is not True or age < timedelta(0) or age > timedelta(days=max(1, _env_int('RESTORE_TEST_MAX_AGE_DAYS', 90))):
            errors.append('restore-test proof is missing, failed or too old')
        if not re.fullmatch(r'[a-f0-9]{64}', str(proof.get('backupSha256') or '')):
            errors.append('restore-test proof requires backupSha256')
    except Exception as e:
        errors.append(f'restore-test proof validation failed: {e}')

    if errors:
        for err in errors:
            print('[SECURITY ERROR]', err)
        raise SystemExit(2)

def run_server(runtime):
    BoundedThreadingHTTPServer = runtime.BoundedThreadingHTTPServer
    HOST = runtime.HOST
    Handler = runtime.Handler
    PORT = runtime.PORT
    ROOT = runtime.ROOT
    _ensure_archive_dirs = runtime._ensure_archive_dirs
    _ensure_request_dirs = runtime._ensure_request_dirs
    _ensure_system_dirs = runtime._ensure_system_dirs
    _get_admin_credentials_file_path = runtime._get_admin_credentials_file_path
    _initialize_external_state = runtime._initialize_external_state
    _migrate_legacy_materials_to_direct_sell_prices = runtime._migrate_legacy_materials_to_direct_sell_prices
    _reconcile_archive_transactions = runtime._reconcile_archive_transactions
    _reconcile_interrupted_jobs_on_startup = runtime._reconcile_interrupted_jobs_on_startup
    _server_maintenance_loop = runtime._server_maintenance_loop
    migrate_embedded_dxfs_to_categories = runtime.migrate_embedded_dxfs_to_categories
    os = runtime.os
    rebuild_embedded_dxfs_manifest = runtime.rebuild_embedded_dxfs_manifest
    run_queue_maintenance = runtime.run_queue_maintenance
    run_retention_maintenance = runtime.run_retention_maintenance
    threading = runtime.threading
    _validate_production_runtime_or_die = lambda: validate_production_runtime_or_die(runtime)

    os.chdir(str(ROOT))
    _initialize_external_state()
    _validate_production_runtime_or_die()
    _ensure_request_dirs()
    _ensure_archive_dirs()
    _ensure_system_dirs()
    migration = _migrate_legacy_materials_to_direct_sell_prices()
    if not migration.get('ok'):
        print('[PRICING MIGRATION ERROR]', migration.get('error') or 'unknown')
        raise SystemExit(2)
    if migration.get('updated'):
        print(f"[PRICING MIGRATION] froze {migration.get('updated')} legacy material prices into direct per-material sell prices")
    archive_recovery = _reconcile_archive_transactions()
    if archive_recovery.get('errors'):
        print('[ARCHIVE RECOVERY ERROR]', archive_recovery.get('errors'))
        raise SystemExit(2)
    try:
        run_retention_maintenance(force=True)
    except Exception:
        pass
    _reconcile_interrupted_jobs_on_startup()
    try:
        run_queue_maintenance(force=True)
    except Exception:
        pass
    # Align embedded DXFs with Tool A categories and rebuild manifest
    migrate_embedded_dxfs_to_categories()
    rebuild_embedded_dxfs_manifest()
    httpd = BoundedThreadingHTTPServer((HOST, PORT), Handler)
    maintenance_thread = threading.Thread(target=_server_maintenance_loop, name='server-maintenance', daemon=True)
    maintenance_thread.start()
    print(f"Server listening on http://{HOST}:{PORT}")
    print(f"Admin: http://{HOST}:{PORT}/admin")
    creds_path = _get_admin_credentials_file_path()
    print(f"Admin credentials source: {creds_path}")
    httpd.serve_forever()

def run_worker(runtime) -> None:
    """Initialize durable runtime state and enter the queue worker loop."""
    ROOT = runtime.ROOT
    _ensure_archive_dirs = runtime._ensure_archive_dirs
    _ensure_request_dirs = runtime._ensure_request_dirs
    _ensure_system_dirs = runtime._ensure_system_dirs
    _initialize_external_state = runtime._initialize_external_state
    _migrate_legacy_materials_to_direct_sell_prices = runtime._migrate_legacy_materials_to_direct_sell_prices
    _reconcile_archive_transactions = runtime._reconcile_archive_transactions
    _reconcile_interrupted_jobs_on_startup = runtime._reconcile_interrupted_jobs_on_startup
    os = runtime.os
    run_queue_maintenance = runtime.run_queue_maintenance
    run_retention_maintenance = runtime.run_retention_maintenance
    worker_loop = runtime.worker_loop
    _validate_production_runtime_or_die = lambda: validate_production_runtime_or_die(runtime)

    os.chdir(str(ROOT))
    _initialize_external_state()
    _validate_production_runtime_or_die()
    _ensure_request_dirs()
    _ensure_archive_dirs()
    _ensure_system_dirs()
    migration = _migrate_legacy_materials_to_direct_sell_prices()
    if not migration.get('ok'):
        print('[PRICING MIGRATION ERROR]', migration.get('error') or 'unknown')
        raise SystemExit(2)
    archive_recovery = _reconcile_archive_transactions()
    if archive_recovery.get('errors'):
        print('[ARCHIVE RECOVERY ERROR]', archive_recovery.get('errors'))
        raise SystemExit(2)
    try:
        run_retention_maintenance(force=True)
    except Exception:
        pass
    _reconcile_interrupted_jobs_on_startup()
    try:
        run_queue_maintenance(force=True)
    except Exception:
        pass
    worker_loop()
