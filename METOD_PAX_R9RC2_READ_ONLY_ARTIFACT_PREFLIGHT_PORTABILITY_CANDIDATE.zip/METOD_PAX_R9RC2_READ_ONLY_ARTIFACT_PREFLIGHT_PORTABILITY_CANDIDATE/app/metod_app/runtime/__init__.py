"""Runtime composition package for the METOD/PAX application.

Public execution starts in :mod:`server_py`; domain code lives below this
package so the executable file does not own business, storage or HTTP logic.
"""
