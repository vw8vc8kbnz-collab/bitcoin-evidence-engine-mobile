from __future__ import annotations

"""Focused CatalogImportRuntimeMixin owner; dependencies resolve through the composition runtime."""

class CatalogImportRuntimeMixin:
    _runtime: object

    def _catalog_import_file(self, import_id: str) -> Path | None:
        runtime = self._runtime
        CATALOG_IMPORT_ROOT = runtime.CATALOG_IMPORT_ROOT
        Path = runtime.Path
        re = runtime.re

        iid = str(import_id or '').strip().lower()
        if not re.fullmatch(r'cat_[a-f0-9]{24}', iid):
            return None
        root = CATALOG_IMPORT_ROOT.resolve()
        path = (CATALOG_IMPORT_ROOT / f'{iid}.json').resolve()
        if root not in path.parents:
            return None
        return path

    def _catalog_import_status_file(self, import_id: str) -> Path | None:
        runtime = self._runtime
        CATALOG_IMPORT_ROOT = runtime.CATALOG_IMPORT_ROOT
        Path = runtime.Path
        re = runtime.re

        iid = str(import_id or '').strip().lower()
        if not re.fullmatch(r'cat_[a-f0-9]{24}', iid):
            return None
        root = CATALOG_IMPORT_ROOT.resolve()
        path = (CATALOG_IMPORT_ROOT / f'{iid}_images.json').resolve()
        if root not in path.parents:
            return None
        return path

    def _catalog_import_media_dir(self, import_id: str) -> Path | None:
        runtime = self._runtime
        CATALOG_IMPORT_ROOT = runtime.CATALOG_IMPORT_ROOT
        Path = runtime.Path
        re = runtime.re

        iid = str(import_id or '').strip().lower()
        if not re.fullmatch(r'cat_[a-f0-9]{24}', iid):
            return None
        root = CATALOG_IMPORT_ROOT.resolve()
        path = (CATALOG_IMPORT_ROOT / f'{iid}_media').resolve()
        if root not in path.parents:
            return None
        return path

    def _reserve_catalog_stage_ids_and_images(self, stage: dict) -> tuple[dict[str, str], list[dict]]:
        """Reserve stable opaque IDs and decide which images must be prepared.

        Reservation is private/backend-only and does not publish catalog records. This
        lets the potentially slow network/image work happen during Admin review rather
        than after customers can already see the new catalog.
        """
        runtime = self._runtime
        DECOR_MEDIA_ROOT = runtime.DECOR_MEDIA_ROOT
        _PUBLIC_MATERIAL_ID_RE = runtime._PUBLIC_MATERIAL_ID_RE
        _catalog_read_cached_image = runtime._catalog_read_cached_image
        hashlib = runtime.hashlib

        _, existing_all = self._load_material_library_bundle()
        existing = [r for r in existing_all if isinstance(r, dict) and str(r.get('sourceKind') or '').upper() == 'CATALOG_IMPORT']
        existing_by_article = {str(r.get('articleNo') or r.get('articleNumber') or r.get('materialCode') or '').strip(): r for r in existing if str(r.get('articleNo') or r.get('articleNumber') or r.get('materialCode') or '').strip()}
        registry = self._load_catalog_public_id_registry()
        for rec in existing_all:
            if not isinstance(rec, dict):
                continue
            art = str(rec.get('articleNo') or rec.get('articleNumber') or rec.get('materialCode') or '').strip()
            pid = str(rec.get('publicMaterialId') or '').strip().lower()
            if art and _PUBLIC_MATERIAL_ID_RE.fullmatch(pid):
                registry.setdefault(art, pid)
        used = set(registry.values())
        reserved = {}
        targets = []
        for rec in (stage.get('records') or []):
            if not isinstance(rec, dict):
                continue
            art = str(rec.get('articleNo') or '').strip()
            if not art:
                continue
            old = existing_by_article.get(art) or {}
            pid = str(registry.get(art) or old.get('publicMaterialId') or '').strip().lower()
            if not _PUBLIC_MATERIAL_ID_RE.fullmatch(pid):
                pid = self._new_public_material_id(used)
            used.add(pid); registry[art] = pid; reserved[art] = pid
            urls = [str(u or '').strip() for u in (rec.get('imageSourceUrls') or []) if str(u or '').strip()]
            source_hash = hashlib.sha256('|'.join(urls).encode('utf-8')).hexdigest() if urls else ''
            old_hash = str(old.get('catalogImageSourceHash') or '')
            cached = _catalog_read_cached_image(DECOR_MEDIA_ROOT / pid)
            # Reuse an already prepared live image only when its source set is unchanged.
            if urls and (not cached or source_hash != old_hash):
                targets.append({'articleNo': art, 'publicMaterialId': pid, 'urls': urls, 'sourceHash': source_hash})
        self._save_catalog_public_id_registry(registry)
        stage['reservedPublicIds'] = reserved
        stage['imageTargets'] = targets
        stage['imagePreparationRequired'] = len(targets)
        return reserved, targets

    def _promote_catalog_stage_images(self, import_id: str, stage: dict) -> int:
        """Promote fully prepared staged images into the live opaque media cache."""
        runtime = self._runtime
        DECOR_MEDIA_ROOT = runtime.DECOR_MEDIA_ROOT
        _PUBLIC_MATERIAL_ID_RE = runtime._PUBLIC_MATERIAL_ID_RE
        _catalog_read_cached_image = runtime._catalog_read_cached_image
        durable_copy_file = runtime.durable_copy_file
        fsync_directory = runtime.fsync_directory

        iid = str(import_id or '').strip().lower()
        stage_root = self._catalog_import_media_dir(iid)
        if stage_root is None:
            raise ValueError('Ongeldige catalogus-image stagingmap.')
        promoted = 0
        for target in (stage.get('imageTargets') or []):
            if not isinstance(target, dict):
                continue
            pid = str(target.get('publicMaterialId') or '').strip().lower()
            if not _PUBLIC_MATERIAL_ID_RE.fullmatch(pid):
                raise ValueError('Ongeldige publieke decor-ID in image staging.')
            src = stage_root / pid
            cached = _catalog_read_cached_image(src)
            if not cached:
                raise RuntimeError('Niet alle catalogusafbeeldingen zijn voorbereid.')
            dst = DECOR_MEDIA_ROOT / pid
            dst.mkdir(parents=True, exist_ok=True)
            # Copy current prepared files to same-filesystem temp names, then replace.
            staged_names = {fp.name for fp in src.iterdir() if fp.is_file() and fp.name in {'catalog.img','catalog.meta.json','thumb.webp','preview.webp'}}
            if not {'catalog.img','catalog.meta.json'}.issubset(staged_names):
                raise RuntimeError('Catalogusafbeelding staging is incompleet.')
            for name in ('catalog.img','thumb.webp','preview.webp','catalog.meta.json'):
                srcf = src / name
                dstf = dst / name
                if srcf.exists():
                    durable_copy_file(srcf, dstf, mode=0o640)
                elif name in ('thumb.webp','preview.webp') and dstf.exists():
                    # Prevent an old WebP variant from being paired with a new raw image.
                    dstf.unlink(missing_ok=True)
                    fsync_directory(dst)
            promoted += 1
        return promoted

    def _api_admin_live_taxonomy_family(self):
        """Persist one Admin-only filter-family override for an active CSV product.

        This endpoint deliberately cannot mutate CSV truth fields such as price, size,
        thickness, product name, image source or catalog membership.
        """
        runtime = self._runtime
        CATALOG_PUBLIC_FAMILIES = runtime.CATALOG_PUBLIC_FAMILIES
        CATALOG_TAXONOMY_REGISTRY = runtime.CATALOG_TAXONOMY_REGISTRY
        _MATERIAL_LIBRARY_LOCK = runtime._MATERIAL_LIBRARY_LOCK
        _PUBLIC_MATERIAL_ID_RE = runtime._PUBLIC_MATERIAL_ID_RE
        _append_system_event = runtime._append_system_event
        _read_json_body_limited = runtime._read_json_body_limited
        _taxonomy_apply_admin_family_override = runtime._taxonomy_apply_admin_family_override
        _taxonomy_clear_admin_family_override = runtime._taxonomy_clear_admin_family_override
        _taxonomy_load_registry = runtime._taxonomy_load_registry
        _taxonomy_registry_with_records = runtime._taxonomy_registry_with_records
        _taxonomy_save_registry = runtime._taxonomy_save_registry
        json = runtime.json

        try:
            data = _read_json_body_limited(self, 'ADMIN_JSON_MAX_BYTES', 65536) or {}
            pid = str(data.get('publicMaterialId') or '').strip().lower()
            requested = str(data.get('primaryVisualFamily') or '').strip()
            if not _PUBLIC_MATERIAL_ID_RE.fullmatch(pid):
                return self._send_json({'ok': False, 'error': 'Ongeldige publieke decor-ID.'}, 400)
            if requested != 'AUTO' and requested not in CATALOG_PUBLIC_FAMILIES:
                return self._send_json({'ok': False, 'error': 'Ongeldige filtercategorie.'}, 400)

            with _MATERIAL_LIBRARY_LOCK:
                raw, records = self._load_material_library_bundle()
                idx = next((i for i,r in enumerate(records) if isinstance(r,dict) and str(r.get('publicMaterialId') or '').strip().lower()==pid), None)
                if idx is None:
                    return self._send_json({'ok': False, 'error': 'Catalogusproduct niet gevonden.'}, 404)
                original = records[idx]
                if str(original.get('sourceKind') or '').upper() != 'CATALOG_IMPORT' or original.get('catalogMissing') is True or original.get('catalogExcluded') is True or original.get('active') is False or original.get('published') is False:
                    return self._send_json({'ok': False, 'error': 'Alleen een actief gepubliceerd CSV-product kan worden aangepast.'}, 409)

                immutable_before = {k: json.dumps(original.get(k), ensure_ascii=False, sort_keys=True) for k in (
                    'articleNo','publicMaterialId','productName','publicName','sheetWid','sheetLen','thicknessMm',
                    'sellPriceInclVatPerSheet','sellPriceExVatPerSheet','priceVatRate','priceSource',
                    'imageSourceUrl','imageVersion','sourceKind','active','published'
                )}
                updated = _taxonomy_clear_admin_family_override(original) if requested == 'AUTO' else _taxonomy_apply_admin_family_override(original, requested)
                immutable_after = {k: json.dumps(updated.get(k), ensure_ascii=False, sort_keys=True) for k in immutable_before}
                if immutable_before != immutable_after:
                    raise RuntimeError('Taxonomy override probeerde CSV-waarheid te wijzigen.')
                records[idx] = updated
                raw['records'] = records
                registry = _taxonomy_load_registry(CATALOG_TAXONOMY_REGISTRY)
                registry = _taxonomy_registry_with_records(registry, [updated])
                # Registry first is safe: it cannot activate products; active catalog remains CSV-only.
                _taxonomy_save_registry(CATALOG_TAXONOMY_REGISTRY, registry)
                self._save_material_library_bundle(raw)

            normalized = self._normalize_material_record_for_admin(updated)
            _append_system_event(
                level='info', component='catalog_taxonomy',
                message_user='Filtercategorie materiaal aangepast',
                message_tech=f'publicMaterialId={pid}; mode={"AUTO" if requested=="AUTO" else "MANUAL"}; family={normalized.get("primaryVisualFamily")}',
                status='resolved', details={'actor': self._current_admin_actor() or 'unknown-admin', 'publicMaterialId': pid}
            )
            return self._send_json({
                'ok': True,
                'record': normalized,
                'primaryVisualFamily': normalized.get('primaryVisualFamily'),
                'manualOverride': bool(normalized.get('taxonomyManualFamilyOverride')),
            })
        except ValueError as e:
            return self._send_json({'ok': False, 'error': str(e)}, 400)
        except Exception as e:
            _append_system_event(level='error', component='catalog_taxonomy', message_user='Filtercategorie opslaan is mislukt', message_tech=str(e), status='open')
            return self._send_json({'ok': False, 'error': 'Filtercategorie opslaan is mislukt.'}, 500)

    def _api_admin_catalog_preview(self):
        runtime = self._runtime
        CATALOG_PUBLIC_FAMILIES = runtime.CATALOG_PUBLIC_FAMILIES
        CATALOG_SUBSTRATE_LABELS = runtime.CATALOG_SUBSTRATE_LABELS
        CATALOG_TAXONOMY_REGISTRY = runtime.CATALOG_TAXONOMY_REGISTRY
        _append_system_event = runtime._append_system_event
        _atomic_write_json = runtime._atomic_write_json
        _catalog_diff = runtime._catalog_diff
        _catalog_review_sha256 = runtime._catalog_review_sha256
        _parse_catalog_csv = runtime._parse_catalog_csv
        _read_json_body_limited = runtime._read_json_body_limited
        _taxonomy_enrich_records = runtime._taxonomy_enrich_records
        _taxonomy_load_registry = runtime._taxonomy_load_registry
        _utc_now_iso = runtime._utc_now_iso
        secrets = runtime.secrets
        time = runtime.time

        try:
            data = _read_json_body_limited(self, 'ADMIN_CATALOG_IMPORT_MAX_BYTES', 4 * 1024 * 1024) or {}
            csv_text = data.get('csvText') if isinstance(data, dict) else None
            if not isinstance(csv_text, str) or not csv_text.strip():
                return self._send_json({'ok': False, 'error': 'Kies eerst een CSV-bestand.'}, 400)
            parsed = _parse_catalog_csv(csv_text)
            taxonomy_registry = _taxonomy_load_registry(CATALOG_TAXONOMY_REGISTRY)
            enriched_records, taxonomy_summary, taxonomy_review = _taxonomy_enrich_records(parsed.get('records') or [], taxonomy_registry)
            parsed['records'] = enriched_records
            raw, existing_all = self._load_material_library_bundle()
            existing = [r for r in existing_all if isinstance(r, dict) and str(r.get('sourceKind') or '').upper() == 'CATALOG_IMPORT']
            diff = _catalog_diff(parsed.get('records') or [], existing, parsed.get('excluded') or [])
            import_id = 'cat_' + secrets.token_hex(12)
            stage = {
                'schemaVersion': 1,
                'importId': import_id,
                'createdAt': _utc_now_iso(),
                'createdAtEpoch': time.time(),
                'csvSha256': parsed.get('csvSha256'),
                'sourceType': parsed.get('sourceType'),
                'records': parsed.get('records') or [],
                'excluded': parsed.get('excluded') or [],
                'warnings': parsed.get('warnings') or [],
                'errors': parsed.get('errors') or [],
                'summary': parsed.get('summary') or {},
                'diff': diff,
                'taxonomySummary': taxonomy_summary,
                'taxonomyReview': taxonomy_review,
            }
            path = self._catalog_import_file(import_id)
            if path is None:
                raise ValueError('Kon import-ID niet aanmaken')
            _, image_targets = self._reserve_catalog_stage_ids_and_images(stage)
            _atomic_write_json(path, stage)
            image_started = False
            if image_targets and not stage.get('errors'):
                image_started = self._start_catalog_image_sync(import_id, image_targets, staging=True)
            elif not image_targets:
                status_path = self._catalog_import_status_file(import_id)
                if status_path is not None:
                    _atomic_write_json(status_path, {'ok': True, 'importId': import_id, 'state': 'DONE', 'phase':'PREPARE_BEFORE_PUBLISH', 'total':0, 'processed':0, 'success':0, 'failed':0, 'skipped':0, 'errors':[], 'finishedAt':_utc_now_iso()})
            summary = dict(stage['summary'])
            summary.update(diff.get('counts') or {})
            summary.update({
                'taxonomyVerified': int(taxonomy_summary.get('verified') or 0),
                'taxonomyReused': int(taxonomy_summary.get('reused') or 0),
                'taxonomyAutoVerified': int(taxonomy_summary.get('autoVerified') or 0),
                'taxonomyAdminVerified': int(taxonomy_summary.get('adminVerified') or 0),
                'taxonomyReviewRequired': int(taxonomy_summary.get('reviewRequired') or 0),
            })
            preview_rows = []
            for r in (stage['records'] or [])[:60]:
                preview_rows.append({
                    'articleNo': r.get('articleNo'),
                    'productName': r.get('productName'),
                    'thicknessMm': r.get('thicknessMm'),
                    'sheetLen': r.get('sheetLen'),
                    'sheetWid': r.get('sheetWid'),
                    'sellPriceInclVatPerSheet': r.get('sellPriceInclVatPerSheet'),
                    'dimensionSource': r.get('dimensionSource'),
                    'imageCount': len(r.get('imageSourceUrls') or []),
                    'primaryVisualFamily': r.get('primaryVisualFamily'),
                    'substrateLabel': r.get('substrateLabel'),
                    'collection': r.get('collection'),
                })
            return self._send_json({
                'ok': True,
                'importId': import_id,
                'reviewSha256': _catalog_review_sha256(stage),
                'summary': summary,
                'warnings': stage['warnings'][:120],
                'errors': stage['errors'][:120],
                'excluded': stage['excluded'][:120],
                'recordsPreview': preview_rows,
                'taxonomySummary': taxonomy_summary,
                'taxonomyReview': taxonomy_review[:120],
                'taxonomyFamilies': list(CATALOG_PUBLIC_FAMILIES),
                'taxonomySubstrates': [{'value': k, 'label': v} for k,v in CATALOG_SUBSTRATE_LABELS.items() if k != 'ONBEKEND'],
                # Publication is unlocked only when taxonomy is complete and all required images are local.
                'canPublish': len(stage['errors']) == 0 and len(stage['records']) > 0 and int(taxonomy_summary.get('reviewRequired') or 0) == 0 and len(image_targets) == 0,
                'canPublishAfterImages': len(stage['errors']) == 0 and len(stage['records']) > 0 and int(taxonomy_summary.get('reviewRequired') or 0) == 0,
                'imagePreparationStarted': image_started,
                'imageSyncTotal': len(image_targets),
            })
        except Exception as e:
            _append_system_event(level='error', component='catalog_import', message_user='CSV controleren is mislukt', message_tech=str(e), status='open')
            return self._send_json({'ok': False, 'error': 'CSV kon niet veilig worden gecontroleerd.'}, 400)

    def _catalog_snapshot_before_publish(self, import_id: str) -> str:
        runtime = self._runtime
        CATALOG_IMPORT_HISTORY = runtime.CATALOG_IMPORT_HISTORY
        MATERIAL_LIBRARY_PATH = runtime.MATERIAL_LIBRARY_PATH
        PRICING_ACTIVE = runtime.PRICING_ACTIVE
        datetime = runtime.datetime
        durable_copy_file = runtime.durable_copy_file
        secrets = runtime.secrets
        timezone = runtime.timezone

        CATALOG_IMPORT_HISTORY.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f')
        folder = CATALOG_IMPORT_HISTORY / f'{stamp}_{import_id}_{secrets.token_hex(3)}'
        folder.mkdir(parents=True, exist_ok=True)
        if MATERIAL_LIBRARY_PATH.exists():
            durable_copy_file(MATERIAL_LIBRARY_PATH, folder / 'material_library.json', mode=0o640)
        if PRICING_ACTIVE.exists():
            durable_copy_file(PRICING_ACTIVE, folder / 'pricing_active.json', mode=0o640)
        return folder.name

    def _load_catalog_public_id_registry(self) -> dict[str, str]:
        runtime = self._runtime
        CATALOG_PUBLIC_ID_REGISTRY = runtime.CATALOG_PUBLIC_ID_REGISTRY
        _PUBLIC_MATERIAL_ID_RE = runtime._PUBLIC_MATERIAL_ID_RE
        strict_json_load = runtime.strict_json_load

        try:
            if CATALOG_PUBLIC_ID_REGISTRY.exists():
                raw = strict_json_load(CATALOG_PUBLIC_ID_REGISTRY)
                if isinstance(raw, dict):
                    values = raw.get('byArticle') if isinstance(raw.get('byArticle'), dict) else raw
                    return {str(k): str(v).lower() for k,v in values.items() if str(k).strip() and _PUBLIC_MATERIAL_ID_RE.fullmatch(str(v).strip().lower())}
        except Exception:
            pass
        return {}

    def _save_catalog_public_id_registry(self, mapping: dict[str, str]) -> None:
        runtime = self._runtime
        CATALOG_PUBLIC_ID_REGISTRY = runtime.CATALOG_PUBLIC_ID_REGISTRY
        _PUBLIC_MATERIAL_ID_RE = runtime._PUBLIC_MATERIAL_ID_RE
        _atomic_write_json = runtime._atomic_write_json
        _utc_now_iso = runtime._utc_now_iso

        CATALOG_PUBLIC_ID_REGISTRY.parent.mkdir(parents=True, exist_ok=True)
        clean = {str(k).strip(): str(v).strip().lower() for k,v in mapping.items() if str(k).strip() and _PUBLIC_MATERIAL_ID_RE.fullmatch(str(v).strip().lower())}
        _atomic_write_json(CATALOG_PUBLIC_ID_REGISTRY, {'schemaVersion': 1, 'updatedAt': _utc_now_iso(), 'byArticle': dict(sorted(clean.items()))})

    def _merge_catalog_stage(self, stage: dict) -> dict:
        """Publish the staged CSV as the *entire* active catalog.

        FIX652 deliberately has no merge-with-legacy semantics. The active records list is
        exactly the eligible current CSV rows. A snapshot and an internal opaque-ID registry
        preserve history/stable public IDs without keeping old seed records active.
        """
        runtime = self._runtime
        CATALOG_SUBSTRATE_LABELS = runtime.CATALOG_SUBSTRATE_LABELS
        CATALOG_TAXONOMY_REGISTRY = runtime.CATALOG_TAXONOMY_REGISTRY
        DECOR_MEDIA_ROOT = runtime.DECOR_MEDIA_ROOT
        _PUBLIC_MATERIAL_ID_RE = runtime._PUBLIC_MATERIAL_ID_RE
        _catalog_read_cached_image = runtime._catalog_read_cached_image
        _taxonomy_load_registry = runtime._taxonomy_load_registry
        _taxonomy_registry_with_records = runtime._taxonomy_registry_with_records
        _taxonomy_save_registry = runtime._taxonomy_save_registry
        _utc_now_iso = runtime._utc_now_iso
        hashlib = runtime.hashlib

        raw, existing_all = self._load_material_library_bundle()
        existing = [r for r in existing_all if isinstance(r, dict) and str(r.get('sourceKind') or '').upper() == 'CATALOG_IMPORT']
        existing_by_article = {str(r.get('articleNo') or r.get('articleNumber') or r.get('materialCode') or '').strip(): r for r in existing if str(r.get('articleNo') or r.get('articleNumber') or r.get('materialCode') or '').strip()}
        registry = self._load_catalog_public_id_registry()
        # Seed/refresh registry from anything that ever had a valid opaque ID, including a
        # pre-FIX652 legacy library. This preserves opaque IDs without preserving fake data.
        for rec in existing_all:
            if not isinstance(rec, dict):
                continue
            art = str(rec.get('articleNo') or rec.get('articleNumber') or rec.get('materialCode') or '').strip()
            pid = str(rec.get('publicMaterialId') or '').strip().lower()
            if art and _PUBLIC_MATERIAL_ID_RE.fullmatch(pid):
                registry.setdefault(art, pid)
        used_ids = set(registry.values())
        staged_records = [r for r in (stage.get('records') or []) if isinstance(r, dict)]
        now = _utc_now_iso()
        final_records = []
        image_targets = []

        authoritative_fields = (
            'articleNo','materialCode','productName','decorName','thicknessMm','sheetLen','sheetWid',
            'sellPriceInclVatPerSheet','sellPriceExVatPerSheet','priceVatRate','priceSource',
            'imageSourceUrls','imageSourceUrl','dimensionSource','catalogSource','brand','categoryName',
            'primaryVisualFamily','visualFamily','visualTags','substrateType','substrateLabel','manufacturerCode','collection',
            'taxonomyStatus','taxonomySource','taxonomyConfidence','taxonomyRulesetVersion','classificationFingerprint','taxonomyManualFamilyOverride',
            'colorGroup','searchTags',
        )
        for staged in staged_records:
            art = str(staged.get('articleNo') or '').strip()
            if not art:
                continue
            old = existing_by_article.get(art) or {}
            merged = {}
            for key in authoritative_fields:
                if key in staged:
                    merged[key] = staged.get(key)
            reserved_ids = stage.get('reservedPublicIds') if isinstance(stage.get('reservedPublicIds'), dict) else {}
            pid = str(reserved_ids.get(art) or registry.get(art) or old.get('publicMaterialId') or '').strip().lower()
            if not _PUBLIC_MATERIAL_ID_RE.fullmatch(pid):
                pid = self._new_public_material_id(used_ids)
            used_ids.add(pid)
            registry[art] = pid
            merged['publicMaterialId'] = pid
            merged['publicName'] = str(staged.get('publicName') or staged.get('productName') or 'Decor').strip()[:180]
            merged['brand'] = str(staged.get('brand') or self._infer_material_brand(merged)).strip() or 'Overig'
            merged['categoryName'] = str(staged.get('categoryName') or '').strip()
            presentation = self._material_presentation(merged)
            merged['primaryVisualFamily'] = str(staged.get('primaryVisualFamily') or staged.get('visualFamily') or presentation.get('visualFamily') or 'Onbekend')
            merged['visualFamily'] = merged['primaryVisualFamily']
            merged['visualTags'] = [merged['primaryVisualFamily']]
            merged['decorType'] = merged['primaryVisualFamily']
            merged['substrateType'] = str(staged.get('substrateType') or 'ONBEKEND').upper()
            merged['substrateLabel'] = str(staged.get('substrateLabel') or CATALOG_SUBSTRATE_LABELS.get(merged['substrateType']) or 'Onbekend')
            merged['colorGroup'] = str(staged.get('colorGroup') or presentation.get('colorGroup') or 'Overig')
            merged['searchTags'] = list(staged.get('searchTags') or presentation.get('searchTags') or [])
            # No second hand-maintained catalog: these presentation flags are deterministic defaults.
            merged['hasGrain'] = True
            merged['grainDefaultOn'] = True
            merged['isPopular'] = False
            merged['isNew'] = False
            merged['active'] = True
            merged['published'] = True
            merged['archived'] = False
            merged['sourceKind'] = 'CATALOG_IMPORT'
            merged['catalogMissing'] = False
            merged['catalogExcluded'] = False
            merged['catalogImportedAt'] = now
            urls = list(staged.get('imageSourceUrls') or [])
            source_hash = hashlib.sha256('|'.join(urls).encode('utf-8')).hexdigest() if urls else ''
            merged['catalogImageSourceHash'] = source_hash
            old_hash = str(old.get('catalogImageSourceHash') or '')
            cached = _catalog_read_cached_image(DECOR_MEDIA_ROOT / pid)
            if urls and (not cached or source_hash != old_hash):
                image_targets.append({'articleNo': art, 'publicMaterialId': pid, 'urls': urls})
            final_records.append(merged)

        old_active_articles = {str(r.get('articleNo') or r.get('articleNumber') or r.get('materialCode') or '').strip() for r in existing if str(r.get('articleNo') or r.get('articleNumber') or r.get('materialCode') or '').strip()}
        new_articles = {str(r.get('articleNo') or '').strip() for r in final_records}
        removed_from_active = len(old_active_articles - new_articles)

        new_raw = {
            'source': 'CSV_CATALOG_ONLY',
            'pricingModel': 'catalog_sell_price_incl_vat_v2',
            'decorLibrarySchemaVersion': 4,
            'records': final_records,
            'recordCountOriginal': len(final_records),
            'recordCountFiltered': len(final_records),
            'lastCatalogImport': {
                'importId': stage.get('importId'),
                'publishedAt': now,
                'csvSha256': stage.get('csvSha256'),
                'eligibleRows': len(final_records),
                'excludedThickness': len(stage.get('excluded') or []),
                'warnings': len(stage.get('warnings') or []),
                'removedFromActive': removed_from_active,
                'taxonomyVerified': int((stage.get('taxonomySummary') or {}).get('verified') or 0),
                'taxonomyReviewRequired': int((stage.get('taxonomySummary') or {}).get('reviewRequired') or 0),
            },
        }
        taxonomy_registry = _taxonomy_load_registry(CATALOG_TAXONOMY_REGISTRY)
        taxonomy_registry = _taxonomy_registry_with_records(taxonomy_registry, final_records)
        # Safe to write first: an orphan private taxonomy entry can never activate a product.
        _taxonomy_save_registry(CATALOG_TAXONOMY_REGISTRY, taxonomy_registry)
        self._save_material_library_bundle(new_raw)
        self._save_catalog_public_id_registry(registry)
        return {'count': len(final_records), 'imageTargets': image_targets, 'missingFromSource': removed_from_active, 'removedFromActive': removed_from_active, 'catalogExcludedExisting': 0}

    def _start_catalog_image_sync(self, import_id: str, targets: list[dict], staging: bool = False) -> bool:
        runtime = self._runtime
        DECOR_MEDIA_ROOT = runtime.DECOR_MEDIA_ROOT
        _CATALOG_IMAGE_STORAGE_BYTES_PER_WORKER = runtime._CATALOG_IMAGE_STORAGE_BYTES_PER_WORKER
        _CATALOG_IMAGE_STORAGE_INODES_PER_WORKER = runtime._CATALOG_IMAGE_STORAGE_INODES_PER_WORKER
        _CATALOG_IMAGE_STORAGE_RESERVATION_ID = runtime._CATALOG_IMAGE_STORAGE_RESERVATION_ID
        _CATALOG_IMAGE_SYNC_ACTIVE = runtime._CATALOG_IMAGE_SYNC_ACTIVE
        _CATALOG_IMAGE_SYNC_LOCK = runtime._CATALOG_IMAGE_SYNC_LOCK
        _PUBLIC_MATERIAL_ID_RE = runtime._PUBLIC_MATERIAL_ID_RE
        _append_system_event = runtime._append_system_event
        _atomic_write_json = runtime._atomic_write_json
        _catalog_atomic_write_cached_image = runtime._catalog_atomic_write_cached_image
        _catalog_download_image = runtime._catalog_download_image
        _enforce_state_capacity = runtime._enforce_state_capacity
        _env_int = runtime._env_int
        _release_state_capacity_reservation = runtime._release_state_capacity_reservation
        _reserve_state_capacity = runtime._reserve_state_capacity
        _safe_text = runtime._safe_text
        _utc_now_iso = runtime._utc_now_iso
        threading = runtime.threading

        iid = str(import_id or '').strip().lower()
        status_path = self._catalog_import_status_file(iid)
        if status_path is None:
            return False
        max_workers = max(1, min(6, _env_int('CATALOG_IMAGE_WORKERS', 4)))
        reservation_bytes = max_workers * _CATALOG_IMAGE_STORAGE_BYTES_PER_WORKER
        reservation_inodes = max_workers * _CATALOG_IMAGE_STORAGE_INODES_PER_WORKER
        with _CATALOG_IMAGE_SYNC_LOCK:
            # A single global sync prevents different importIds from multiplying
            # the worker pool and bypassing shared disk admission.
            if _CATALOG_IMAGE_SYNC_ACTIVE:
                return False
            _reserve_state_capacity(
                _CATALOG_IMAGE_STORAGE_RESERVATION_ID,
                reservation_bytes,
                reservation_inodes,
                reservation_kind='catalog-image-sync',
            )
            _CATALOG_IMAGE_SYNC_ACTIVE.add(iid)

        initial = {
            'ok': True, 'importId': iid, 'state': 'RUNNING', 'phase': ('PREPARE_BEFORE_PUBLISH' if staging else 'LIVE_RETRY'), 'startedAt': _utc_now_iso(),
            'total': len(targets), 'processed': 0, 'success': 0, 'failed': 0, 'skipped': 0, 'errors': [],
        }
        try:
            _atomic_write_json(status_path, initial)
        except Exception:
            with _CATALOG_IMAGE_SYNC_LOCK:
                _release_state_capacity_reservation(_CATALOG_IMAGE_STORAGE_RESERVATION_ID)
                _CATALOG_IMAGE_SYNC_ACTIVE.discard(iid)
            raise

        def run():
            st = dict(initial)
            status_lock = threading.Lock()
            try:
                target_root = self._catalog_import_media_dir(iid) if staging else DECOR_MEDIA_ROOT
                if target_root is None:
                    raise ValueError('Ongeldige image stagingmap.')
                target_root.mkdir(parents=True, exist_ok=True)

                def process_one(target):
                    pid = str(target.get('publicMaterialId') or '').strip().lower()
                    article = str(target.get('articleNo') or '').strip()
                    urls = [str(u or '').strip() for u in (target.get('urls') or []) if str(u or '').strip()]
                    last_error = ''
                    if _PUBLIC_MATERIAL_ID_RE.fullmatch(pid) and urls:
                        for url in urls:
                            try:
                                # Physical free space shrinks as completed images
                                # accumulate. Re-check it before every download while
                                # counting all queued jobs and this sync reservation.
                                _enforce_state_capacity(0, 1)
                                payload = _catalog_download_image(url)
                                meta = _catalog_atomic_write_cached_image(target_root / pid, payload)
                                return {'ok': True, 'articleNo': article, 'pid': pid, 'variantGenerator': meta.get('variantGenerator')}
                            except Exception as e:
                                last_error = str(e)
                    else:
                        last_error = 'Geen geldige publieke decor-ID of afbeeldingslink.'
                    return {'ok': False, 'articleNo': article, 'pid': pid, 'error': last_error}

                # A small bounded pool keeps Admin imports practical without hammering the
                # source website or the VPS. Public Tool A never waits for this work.
                from concurrent.futures import ThreadPoolExecutor, as_completed
                with ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix='catalog-img') as pool:
                    futures = [pool.submit(process_one, t) for t in targets]
                    for fut in as_completed(futures):
                        res = fut.result()
                        with status_lock:
                            if res.get('ok'):
                                st['success'] += 1
                                if res.get('variantGenerator') == 'pillow-webp':
                                    st['webpPrepared'] = int(st.get('webpPrepared') or 0) + 1
                                else:
                                    st['rawFallback'] = int(st.get('rawFallback') or 0) + 1
                            else:
                                st['failed'] += 1
                                if len(st['errors']) < 100:
                                    st['errors'].append({'articleNo': res.get('articleNo') or '', 'message': _safe_text(res.get('error') or '', 220)})
                            st['processed'] = int(st.get('processed') or 0) + 1
                            st['updatedAt'] = _utc_now_iso()
                            _atomic_write_json(status_path, st)
                st['state'] = 'DONE' if st['failed'] == 0 else 'DONE_WITH_ERRORS'
                st['finishedAt'] = _utc_now_iso()
                _atomic_write_json(status_path, st)
                _append_system_event(level='info' if st['failed'] == 0 else 'warning', component='catalog_images', message_user='Catalogusafbeeldingen voorbereid' if staging else 'Catalogusafbeeldingen bijgewerkt', message_tech=f"import={iid}; staging={staging}; success={st['success']}; failed={st['failed']}; webp={st.get('webpPrepared',0)}", status='resolved' if st['failed'] == 0 else 'open')
            except Exception as e:
                st['state'] = 'FAILED'; st['fatalError'] = _safe_text(str(e), 240); st['finishedAt'] = _utc_now_iso()
                try: _atomic_write_json(status_path, st)
                except Exception: pass
                _append_system_event(level='error', component='catalog_images', message_user='Catalogusafbeeldingen voorbereiden is mislukt', message_tech=str(e), status='open')
            finally:
                with _CATALOG_IMAGE_SYNC_LOCK:
                    # Keep the active marker until its fixed reservation is gone;
                    # a simultaneous restart can then never have its replacement
                    # reservation deleted by this finishing thread.
                    _release_state_capacity_reservation(_CATALOG_IMAGE_STORAGE_RESERVATION_ID)
                    _CATALOG_IMAGE_SYNC_ACTIVE.discard(iid)

        try:
            threading.Thread(target=run, name=f'catalog-images-{iid[-8:]}', daemon=True).start()
        except Exception:
            with _CATALOG_IMAGE_SYNC_LOCK:
                _release_state_capacity_reservation(_CATALOG_IMAGE_STORAGE_RESERVATION_ID)
                _CATALOG_IMAGE_SYNC_ACTIVE.discard(iid)
            raise
        return True

    def _api_admin_catalog_taxonomy_override(self):
        runtime = self._runtime
        _append_system_event = runtime._append_system_event
        _atomic_write_json = runtime._atomic_write_json
        _catalog_review_sha256 = runtime._catalog_review_sha256
        _read_json_body_limited = runtime._read_json_body_limited
        _taxonomy_apply_admin_override = runtime._taxonomy_apply_admin_override
        _taxonomy_summary = runtime._taxonomy_summary
        strict_json_load = runtime.strict_json_load

        try:
            data = _read_json_body_limited(self, 'ADMIN_JSON_MAX_BYTES', 262144) or {}
            iid = str(data.get('importId') or '').strip().lower()
            article = str(data.get('articleNo') or '').strip()
            family = str(data.get('primaryVisualFamily') or '').strip()
            substrate = str(data.get('substrateType') or '').strip().upper()
            path = self._catalog_import_file(iid)
            if path is None or not path.exists():
                return self._send_json({'ok': False, 'error': 'Importpreview niet gevonden.'}, 404)
            stage = strict_json_load(path)
            if stage.get('publishedAt'):
                return self._send_json({'ok': False, 'error': 'Deze import is al gepubliceerd.'}, 409)
            records = list(stage.get('records') or [])
            found = False
            for idx, rec in enumerate(records):
                if isinstance(rec, dict) and str(rec.get('articleNo') or '').strip() == article:
                    records[idx] = _taxonomy_apply_admin_override(rec, family, substrate)
                    found = True
                    break
            if not found:
                return self._send_json({'ok': False, 'error': 'Product niet gevonden in deze import.'}, 404)
            stage['records'] = records
            tax_summary, tax_review = _taxonomy_summary(records)
            stage['taxonomySummary'] = tax_summary
            stage['taxonomyReview'] = tax_review
            _atomic_write_json(path, stage)
            _append_system_event(
                level='info', component='catalog_taxonomy',
                message_user='Catalogusclassificatie beoordeeld',
                message_tech=f'import={iid}; article={article}; family={family}; substrate={substrate}',
                status='resolved',
                details={'actor': self._current_admin_actor() or 'unknown-admin', 'importId': iid, 'articleNo': article},
            )
            return self._send_json({
                'ok': True,
                'importId': iid,
                'reviewSha256': _catalog_review_sha256(stage),
                'taxonomySummary': tax_summary,
                'taxonomyReview': tax_review[:120],
                'canPublishAfterImages': len(stage.get('errors') or []) == 0 and len(records) > 0 and int(tax_summary.get('reviewRequired') or 0) == 0,
                'canPublish': len(stage.get('errors') or []) == 0 and len(records) > 0 and int(tax_summary.get('reviewRequired') or 0) == 0 and len(stage.get('imageTargets') or []) == 0,
            })
        except ValueError as e:
            return self._send_json({'ok': False, 'error': str(e)}, 400)
        except Exception as e:
            _append_system_event(level='error', component='catalog_taxonomy', message_user='Productclassificatie opslaan is mislukt', message_tech=str(e), status='open')
            return self._send_json({'ok': False, 'error': 'Classificatie kon niet veilig worden opgeslagen.'}, 400)

    def _api_admin_catalog_publish(self):
        runtime = self._runtime
        MATERIAL_LIBRARY_PATH = runtime.MATERIAL_LIBRARY_PATH
        Path = runtime.Path
        SYSTEM_DIR = runtime.SYSTEM_DIR
        _append_system_event = runtime._append_system_event
        _atomic_write_json = runtime._atomic_write_json
        _catalog_review_sha256 = runtime._catalog_review_sha256
        _invalidate_public_materials_response_cache = runtime._invalidate_public_materials_response_cache
        _read_json_body_limited = runtime._read_json_body_limited
        _taxonomy_summary = runtime._taxonomy_summary
        _utc_now_iso = runtime._utc_now_iso
        durable_write_bytes = runtime.durable_write_bytes
        durable_write_json = runtime.durable_write_json
        fsync_directory = runtime.fsync_directory
        hmac = runtime.hmac
        os = runtime.os
        re = runtime.re
        sha256_file = runtime.sha256_file
        strict_json_load = runtime.strict_json_load
        time = runtime.time

        try:
            data = _read_json_body_limited(self, 'ADMIN_JSON_MAX_BYTES', 262144) or {}
            iid = str(data.get('importId') or '').strip().lower()
            path = self._catalog_import_file(iid)
            if path is None or not path.exists():
                return self._send_json({'ok': False, 'error': 'Importpreview niet gevonden. Controleer de CSV opnieuw.'}, 404)
            stage = strict_json_load(path)
            if stage.get('publishedAt'):
                return self._send_json({'ok': False, 'error': 'Deze import is al gepubliceerd.'}, 409)
            if time.time() - float(stage.get('createdAtEpoch') or 0) > 24 * 60 * 60:
                return self._send_json({'ok': False, 'error': 'Importpreview is ouder dan 24 uur. Controleer de CSV opnieuw.'}, 409)
            if stage.get('errors'):
                return self._send_json({'ok': False, 'error': 'Import bevat blokkerende fouten en kan niet worden gepubliceerd.'}, 400)
            if not stage.get('records'):
                return self._send_json({'ok': False, 'error': 'Import bevat geen toegestane 18/19/20 mm materialen.'}, 400)
            taxonomy_summary, taxonomy_review = _taxonomy_summary(stage.get('records') or [])
            stage['taxonomySummary'] = taxonomy_summary
            stage['taxonomyReview'] = taxonomy_review
            if int(taxonomy_summary.get('reviewRequired') or 0) != 0:
                _atomic_write_json(path, stage)
                return self._send_json({'ok': False, 'error': f"Classificatie is nog niet compleet: {int(taxonomy_summary.get('reviewRequired') or 0)} product(en) vereisen Admin-controle."}, 409)
            expected_review_sha256 = _catalog_review_sha256(stage)
            supplied_review_sha256 = str(data.get('reviewSha256') or '').strip().lower()
            if not re.fullmatch(r'[a-f0-9]{64}', supplied_review_sha256) or not hmac.compare_digest(supplied_review_sha256, expected_review_sha256):
                return self._send_json({'ok': False, 'error': 'De gecontroleerde catalogus is gewijzigd. Controleer waarschuwingen en CSV opnieuw.'}, 409)
            actor = self._current_admin_actor()
            if not actor:
                return self._send_json({'ok': False, 'error': 'Admin-identiteit ontbreekt; log opnieuw in.'}, 403)
            required_images = list(stage.get('imageTargets') or [])
            if required_images:
                status_path = self._catalog_import_status_file(iid)
                image_status = {}
                try:
                    image_status = strict_json_load(status_path) if status_path and status_path.exists() else {}
                except Exception:
                    image_status = {}
                if str(image_status.get('state') or '') != 'DONE' or int(image_status.get('failed') or 0) != 0 or int(image_status.get('processed') or 0) < len(required_images):
                    return self._send_json({'ok': False, 'error': 'De catalogusafbeeldingen zijn nog niet volledig voorbereid. Wacht tot 100% en probeer daarna opnieuw te publiceren.'}, 409)
            snapshot = self._catalog_snapshot_before_publish(iid)
            promoted_images = self._promote_catalog_stage_images(iid, stage) if required_images else 0
            signoff_path = Path(os.environ.get('CATALOG_SIGNOFF_FILE') or (SYSTEM_DIR / 'catalog_signoff.json')).expanduser()
            previous_library = MATERIAL_LIBRARY_PATH.read_bytes()
            previous_signoff = signoff_path.read_bytes() if signoff_path.is_file() else None
            try:
                merged = self._merge_catalog_stage(stage)
                durable_write_json(signoff_path, {
                    'schemaVersion': 1,
                    'approved': True,
                    'approvedBy': actor,
                    'approvedAt': _utc_now_iso(),
                    'importId': iid,
                    'csvSha256': str(stage.get('csvSha256') or ''),
                    'reviewSha256': expected_review_sha256,
                    'warningCount': len(stage.get('warnings') or []),
                    'excludedCount': len(stage.get('excluded') or []),
                    'materialLibrarySha256': sha256_file(MATERIAL_LIBRARY_PATH),
                }, mode=0o640)
            except Exception as commit_error:
                rollback_errors = []
                try:
                    durable_write_bytes(MATERIAL_LIBRARY_PATH, previous_library, mode=0o640)
                    _invalidate_public_materials_response_cache()
                except Exception as rollback_error:
                    rollback_errors.append(f'library rollback: {rollback_error}')
                try:
                    if previous_signoff is None:
                        signoff_path.unlink(missing_ok=True)
                        fsync_directory(signoff_path.parent)
                    else:
                        durable_write_bytes(signoff_path, previous_signoff, mode=0o640)
                except Exception as rollback_error:
                    rollback_errors.append(f'signoff rollback: {rollback_error}')
                suffix = '; ' + '; '.join(rollback_errors) if rollback_errors else ''
                raise RuntimeError(f'catalog commit rolled back: {commit_error}{suffix}') from commit_error
            # FIX656: pay catalog normalization/cache cost during Admin publication, not on
            # the customer's first Tool A page load.
            try:
                self._public_materials_response_bytes(force_rebuild=True)
            except Exception as cache_err:
                _append_system_event(level='warning', component='catalog_cache', message_user='Publieke cataloguscache wordt later opgebouwd', message_tech=str(cache_err), status='open')
            stage['publishedAt'] = _utc_now_iso()
            stage['snapshot'] = snapshot
            stage['publishedResult'] = {'count': merged['count'], 'removedFromActive': merged.get('removedFromActive', 0)}
            try:
                _atomic_write_json(path, stage)
                _append_system_event(level='info', component='catalog_import', message_user='CSV-catalogus gepubliceerd', message_tech=f"import={iid}; records={len(stage.get('records') or [])}; preparedImages={promoted_images}; snapshot={snapshot}", status='resolved', details={'actor': actor, 'reviewSha256': expected_review_sha256, 'warningCount': len(stage.get('warnings') or [])})
            except Exception as audit_error:
                # The active library + hash-bound signoff are already the atomic commit.
                # A private history/audit write cannot turn that success into an ambiguous
                # client retry that might publish twice.
                print('[CATALOG AUDIT WARNING]', audit_error)
            return self._send_json({
                'ok': True, 'importId': iid, 'published': len(stage.get('records') or []),
                'libraryCount': merged['count'], 'missingFromSource': merged.get('removedFromActive', 0), 'removedFromActive': merged.get('removedFromActive', 0),
                'excludedThickness': len(stage.get('excluded') or []),
                'imageSyncStarted': False, 'imageSyncTotal': 0, 'preparedImages': promoted_images,
                'snapshot': snapshot,
            })
        except Exception as e:
            _append_system_event(level='error', component='catalog_import', message_user='CSV-catalogus publiceren is mislukt', message_tech=str(e), status='open')
            return self._send_json({'ok': False, 'error': 'Catalogus kon niet veilig worden gepubliceerd.'}, 400)

    def _api_admin_catalog_status(self, parsed):
        runtime = self._runtime
        parse_qs = runtime.parse_qs
        strict_json_load = runtime.strict_json_load

        try:
            qs = parse_qs(parsed.query)
            iid = str((qs.get('importId') or [''])[0]).strip().lower()
            path = self._catalog_import_status_file(iid)
            if path is None or not path.exists():
                return self._send_json({'ok': True, 'importId': iid, 'state': 'NOT_STARTED', 'total': 0, 'processed': 0, 'success': 0, 'failed': 0})
            data = strict_json_load(path)
            return self._send_json(data)
        except Exception:
            return self._send_json({'ok': False, 'error': 'Importstatus kon niet worden geladen.'}, 400)

    def _api_admin_catalog_retry_images(self):
        runtime = self._runtime
        _read_json_body_limited = runtime._read_json_body_limited
        fsync_directory = runtime.fsync_directory
        shutil = runtime.shutil
        strict_json_load = runtime.strict_json_load

        try:
            data = _read_json_body_limited(self, 'ADMIN_JSON_MAX_BYTES', 262144) or {}
            iid = str(data.get('importId') or '').strip().lower()
            stage_path = self._catalog_import_file(iid)
            if stage_path is None or not stage_path.exists():
                return self._send_json({'ok': False, 'error': 'Import niet gevonden.'}, 404)
            stage = strict_json_load(stage_path)
            if stage.get('publishedAt'):
                return self._send_json({'ok': False, 'error': 'Deze import is al gepubliceerd. Controleer voor een nieuwe versie opnieuw de CSV.'}, 409)
            targets = list(stage.get('imageTargets') or [])
            status_path = self._catalog_import_status_file(iid)
            if status_path and status_path.exists():
                status_path.unlink(missing_ok=True)
                fsync_directory(status_path.parent)
            stage_media = self._catalog_import_media_dir(iid)
            if stage_media and stage_media.exists():
                shutil.rmtree(stage_media, ignore_errors=True)
                fsync_directory(stage_media.parent)
            started = self._start_catalog_image_sync(iid, targets, staging=True)
            return self._send_json({'ok': started, 'importId': iid, 'imageSyncTotal': len(targets), 'error': None if started else 'Afbeeldingssync draait al.'})
        except Exception:
            return self._send_json({'ok': False, 'error': 'Afbeeldingen opnieuw ophalen is mislukt.'}, 400)
