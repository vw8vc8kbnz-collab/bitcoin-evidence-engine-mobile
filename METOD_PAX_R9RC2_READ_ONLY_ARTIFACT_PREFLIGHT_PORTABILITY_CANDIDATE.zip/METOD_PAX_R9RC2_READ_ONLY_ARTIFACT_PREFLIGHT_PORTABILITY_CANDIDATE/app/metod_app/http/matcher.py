from __future__ import annotations

"""Pure matcher for the reviewed R9F HTTP route catalog.

R9F-5 lets the live ``Handler`` use this module to classify every reviewed
GET, HEAD, OPTIONS and POST request-target.  The Handler still owns
authentication, policy checks, body reads, handler invocation and responses.
"""

from dataclasses import dataclass
from urllib.parse import unquote, urlparse

from .contracts import RouteDefinition
from .routes import ROUTES, ROUTES_BY_KEY


from .static import (
    BLOCKED_STATIC_TOP_LEVEL,
    PUBLIC_STATIC_MODULE_FILES,
    PUBLIC_STATIC_ROOT_FILES,
    PUBLIC_STATIC_SHELL_FILES,
    is_blocked_static_relpath as _is_blocked_static_relpath,
    is_public_static_relpath as _is_public_static_relpath,
)


@dataclass(frozen=True, slots=True)
class RouteMatch:
    """Immutable route classification with transport-neutral path parameters."""

    route: RouteDefinition
    path: str
    parameters: tuple[tuple[str, str], ...] = ()

    @property
    def key(self) -> str:
        return self.route.key

    def parameter(self, name: str) -> str | None:
        for key, value in self.parameters:
            if key == name:
                return value
        return None


_EXACT_ROUTES = {
    route.key: route
    for route in ROUTES
    if route.pattern != "*" and "{" not in route.pattern
}


def request_path(request_target: object) -> str:
    """Return the path exactly as the live Handler's ``urlparse`` does."""

    return urlparse(str(request_target)).path


def _static_relpath(path: str) -> str | None:
    rel = unquote(path.lstrip("/"))
    if _is_blocked_static_relpath(rel) or not _is_public_static_relpath(rel):
        return None
    return str(rel or "").strip().lstrip("/").replace("\\", "/") or "toolA.html"


def _match(method: str, pattern: str, path: str, **parameters: str) -> RouteMatch:
    route = ROUTES_BY_KEY[f"{method} {pattern}"]
    return RouteMatch(route, path, tuple(parameters.items()))


def match_route(method: object, request_target: object) -> RouteMatch | None:
    """Classify one request without taking any runtime responsibility.

    Method matching is deliberately case-sensitive: ``BaseHTTPRequestHandler``
    dispatches ``GET`` and ``get`` differently.  Dynamic branch order mirrors
    the existing Handler, including its broad download-before-file precedence.
    """

    method = str(method)
    path = request_path(request_target)

    if method == "OPTIONS":
        return _match(method, "*", path)

    exact = _EXACT_ROUTES.get(f"{method} {path}")
    if exact is not None:
        return RouteMatch(exact, path)

    if method == "HEAD":
        if path.startswith("/api/admin/"):
            return _match(method, "/api/admin/", path)
        rel = _static_relpath(path)
        if rel is not None:
            return _match(method, "/{allowlistedStaticAsset}", path, relativePath=rel)
        return None

    if method != "GET":
        return None

    if path == "":
        return _match(method, "/", path)

    if path.startswith("/api/materials/image/"):
        parts = path.split("/")
        if len(parts) == 6:
            return _match(
                method, "/api/materials/image/{publicId}/{variant}", path,
                publicId=unquote(parts[4]), variant=unquote(parts[5]),
            )
        return None

    if path.startswith("/api/stickertool_v2/"):
        return _match(method, "/api/stickertool_v2/", path)

    if path.startswith("/api/jobs/") and "/download/" in path:
        parts = path.split("/")
        if len(parts) >= 6:
            return _match(
                method, "/api/jobs/{jobId}/download/{filename}", path,
                jobId=parts[3], filename=parts[5],
            )
        return None

    if path.startswith("/api/jobs/") and "/subjobs/" in path and "/file/" in path:
        parts = path.split("/")
        if len(parts) >= 8 and parts[4] == "subjobs" and parts[6] == "file":
            return _match(
                method, "/api/jobs/{jobId}/subjobs/{subjobId}/file/{relativePath}", path,
                jobId=unquote(parts[3]), subjobId=unquote(parts[5]),
                relativePath=unquote("/".join(parts[7:])),
            )

    if path.startswith("/api/jobs/") and "/file/" in path:
        parts = path.split("/")
        if len(parts) >= 6:
            return _match(
                method, "/api/jobs/{jobId}/file/{relativePath}", path,
                jobId=unquote(parts[3]), relativePath=unquote("/".join(parts[5:])),
            )

    if path.startswith("/api/jobs/") and path.endswith("/status"):
        return _match(
            method, "/api/jobs/{jobId}/status", path,
            jobId=path.split("/")[3],
        )

    rel = _static_relpath(path)
    if rel is not None:
        return _match(method, "/{allowlistedStaticAsset}", path, relativePath=rel)
    return None


__all__ = (
    "BLOCKED_STATIC_TOP_LEVEL",
    "PUBLIC_STATIC_MODULE_FILES",
    "PUBLIC_STATIC_ROOT_FILES",
    "PUBLIC_STATIC_SHELL_FILES",
    "RouteMatch",
    "match_route",
    "request_path",
)
