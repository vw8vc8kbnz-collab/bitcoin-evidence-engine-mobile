from __future__ import annotations

"""Focused MaterialCatalogRuntimeMixin owner; dependencies resolve through the composition runtime."""

class MaterialCatalogRuntimeMixin:
    _runtime: object

    def _dxf_root(self) -> Path:
        runtime = self._runtime
        DXF_LIBRARY_ROOT = runtime.DXF_LIBRARY_ROOT
        Path = runtime.Path

        return DXF_LIBRARY_ROOT

    def _sanitize_category(self, cat: str):
        runtime = self._runtime
        re = runtime.re

        if not isinstance(cat, str):
            return None
        cat = cat.strip()
        if not cat:
            return None
        # Keep legacy behavior: allow "(root)" to point to the base folder.
        if cat == "(root)":
            return cat
        # Prevent path traversal / separators
        if "/" in cat or "\\" in cat or ".." in cat:
            return None
        # Allow categories with spaces (labels must match Tool A)
        if len(cat) > 60:
            return None
        if not re.fullmatch(r"[\w \-]{1,60}", cat, flags=re.UNICODE):
            return None
        return cat

    def _sanitize_filename(self, name: str):
        runtime = self._runtime
        re = runtime.re

        if not isinstance(name, str):
            return None
        name = name.strip()
        if not name:
            return None
        if "/" in name or "\\" in name or ".." in name:
            return None
        if not name.lower().endswith(".dxf"):
            return None
        if not re.fullmatch(r"[A-Za-z0-9 _,.-]{1,80}\.dxf", name, flags=re.IGNORECASE):
            return None
        return name

    def _dxf_category_folder(self, cat: str) -> Path:
        runtime = self._runtime
        Path = runtime.Path

        root = self._dxf_root()
        root.mkdir(parents=True, exist_ok=True)
        if cat == "(root)":
            return root
        return root / cat

    def _list_dxf_categories(self):
        root = self._dxf_root()
        root.mkdir(parents=True, exist_ok=True)
        cats = ["(root)"]
        for p in sorted(root.iterdir()):
            if p.is_dir():
                cats.append(p.name)
        return cats

    def _list_dxf_files_in_category(self, cat: str):
        folder = self._dxf_category_folder(cat)
        if not folder.exists() or not folder.is_dir():
            return None
        files = []
        for p in sorted(folder.iterdir()):
            if not p.is_file():
                continue
            name = p.name
            if name.startswith('.'):
                continue
            # Accept normal .dxf and (optionally) extensionless DXF files
            if name.lower().endswith(".dxf") or p.suffix == "":
                files.append(name)
        return files

    def _new_public_material_id(self, used: set[str] | None = None) -> str:
        runtime = self._runtime
        secrets = runtime.secrets

        used = used if isinstance(used, set) else set()
        for _ in range(100):
            value = 'decor_' + secrets.token_hex(10)
            if value not in used:
                used.add(value)
                return value
        raise RuntimeError('Kon geen unieke publieke decor-ID genereren')

    def _infer_material_brand(self, rec: dict) -> str:
        existing = str((rec or {}).get('brand') or '').strip()
        if existing:
            return existing[:80]
        hay = ' '.join(str((rec or {}).get(k) or '') for k in ('productName','categoryName','shortDescription')).upper()
        for brand in ('EGGER','PFLEIDERER','UNILIN','DECORLEGNO','DECOLEGNO','SHINNOKI','CLEAF','FINSA','KRONOSPAN','ARPA','FENIX','NUXE','TOPFIX'):
            if brand in hay:
                return brand if brand in ('EGGER','ARPA','FENIX') else brand.title()
        return 'Overig'

    def _material_presentation(self, rec: dict) -> dict:
        runtime = self._runtime
        _catalog_classify_presentation = runtime._catalog_classify_presentation

        rec = rec or {}
        return _catalog_classify_presentation(
            str(rec.get('productName') or rec.get('publicName') or rec.get('decorName') or ''),
            str(rec.get('brand') or self._infer_material_brand(rec) or ''),
            str(rec.get('categoryName') or ''),
            rec.get('imageSourceUrls') or [],
        )

    def _infer_material_decor_type(self, rec: dict) -> str:
        presentation = self._material_presentation(rec)
        return str(presentation.get('visualFamily') or 'Overig')[:60]

    def _public_material_name(self, rec: dict) -> str:
        rec = rec or {}
        art = str(rec.get('articleNo') or rec.get('articleNumber') or rec.get('materialCode') or '').strip()
        name = str(rec.get('publicName') or rec.get('displayName') or rec.get('productName') or rec.get('decorName') or 'Decor').strip()
        if art:
            name = name.replace(art, '').strip(' -/|') or 'Decor'
        return name[:180]

    def _ensure_material_public_metadata(self, raw: dict, recs: list[dict]) -> bool:
        runtime = self._runtime
        _PUBLIC_MATERIAL_ID_RE = runtime._PUBLIC_MATERIAL_ID_RE

        changed = False
        used: set[str] = set()
        for r in recs:
            if not isinstance(r, dict):
                continue
            pid = str(r.get('publicMaterialId') or '').strip().lower()
            if _PUBLIC_MATERIAL_ID_RE.fullmatch(pid) and pid not in used:
                used.add(pid)
            else:
                r['publicMaterialId'] = self._new_public_material_id(used)
                changed = True
        for r in recs:
            if not isinstance(r, dict):
                continue
            # FIX656: CSV publication already persists presentation fields. Do not run the
            # classifier four/five times again on every public library request. Only infer
            # presentation once when an older record genuinely misses one of these fields.
            brand = str(r.get('brand') or '').strip() or self._infer_material_brand(r)
            presentation_keys_ok = (
                bool(str(r.get('visualFamily') or r.get('decorType') or '').strip()) and
                isinstance(r.get('visualTags'), list) and
                bool(str(r.get('colorGroup') or '').strip()) and
                isinstance(r.get('searchTags'), list)
            )
            presentation = None if presentation_keys_ok else self._material_presentation({**r, 'brand': brand})
            family = str(r.get('visualFamily') or r.get('decorType') or (presentation or {}).get('visualFamily') or 'Overig').strip() or 'Overig'
            defaults = {
                'publicName': self._public_material_name(r),
                'brand': brand,
                'decorType': family,
                'visualFamily': family,
                'visualTags': list(r.get('visualTags') or (presentation or {}).get('visualTags') or [family]),
                'colorGroup': str(r.get('colorGroup') or (presentation or {}).get('colorGroup') or 'Overig').strip() or 'Overig',
                'searchTags': list(r.get('searchTags') or (presentation or {}).get('searchTags') or []),
                'published': bool(r.get('active', True)) if r.get('published') is None else bool(r.get('published')),
                'isPopular': bool(r.get('isPopular', False)),
                'isNew': bool(r.get('isNew', False)),
                'hasGrain': True if r.get('hasGrain') is None else bool(r.get('hasGrain')),
                'grainDefaultOn': True if r.get('grainDefaultOn') is None else bool(r.get('grainDefaultOn')),
                'archived': bool(r.get('archived', False)),
                'sourceKind': str(r.get('sourceKind') or 'LEGACY_LIBRARY').strip() or 'LEGACY_LIBRARY',
                'catalogMissing': bool(r.get('catalogMissing', False)),
            }
            for key, value in defaults.items():
                if key not in r:
                    r[key] = value
                    changed = True
        if raw.get('decorLibrarySchemaVersion') != 4:
            raw['decorLibrarySchemaVersion'] = 4
            changed = True
        return changed

    def _load_material_library_bundle(self):
        runtime = self._runtime
        MATERIAL_LIBRARY_PATH = runtime.MATERIAL_LIBRARY_PATH
        _MATERIAL_LIBRARY_LOCK = runtime._MATERIAL_LIBRARY_LOCK
        strict_json_load = runtime.strict_json_load

        with _MATERIAL_LIBRARY_LOCK:
            target = MATERIAL_LIBRARY_PATH
            if target.exists():
                raw = strict_json_load(target)
            else:
                raw = {'source': 'admin', 'records': []}
            if isinstance(raw, list):
                raw = {'source': 'admin', 'records': raw}
            if not isinstance(raw, dict):
                raise ValueError('Material library must be a JSON object or list')
            recs = raw.get('records')
            if recs is None:
                recs = []
                raw['records'] = recs
            if not isinstance(recs, list):
                raise ValueError('material_library.json must contain a records list')
            changed = self._ensure_material_public_metadata(raw, recs)
            if changed:
                raw['recordCountOriginal'] = len(recs)
                raw['recordCountFiltered'] = len(recs)
                self._save_material_library_bundle(raw)
            return raw, recs

    def _save_material_library_bundle(self, raw):
        runtime = self._runtime
        MATERIAL_LIBRARY_PATH = runtime.MATERIAL_LIBRARY_PATH
        _MATERIAL_LIBRARY_LOCK = runtime._MATERIAL_LIBRARY_LOCK
        _invalidate_material_lookup_cache = runtime._invalidate_material_lookup_cache
        _invalidate_public_materials_response_cache = runtime._invalidate_public_materials_response_cache
        durable_write_json = runtime.durable_write_json

        with _MATERIAL_LIBRARY_LOCK:
            target = MATERIAL_LIBRARY_PATH
            durable_write_json(target, raw, mode=0o640)
            _invalidate_public_materials_response_cache()
            _invalidate_material_lookup_cache()
            runtime._MATERIAL_NAME_BY_CODE = None

    def _normalize_material_record_for_admin(self, rec):
        runtime = self._runtime
        CATALOG_VAT_RATE = runtime.CATALOG_VAT_RATE
        DECOR_MEDIA_ROOT = runtime.DECOR_MEDIA_ROOT
        _PUBLIC_MATERIAL_ID_RE = runtime._PUBLIC_MATERIAL_ID_RE
        _catalog_read_cached_image = runtime._catalog_read_cached_image
        quote = runtime.quote

        if not isinstance(rec, dict):
            rec = {}
        out = dict(rec)
        art = str(out.get('articleNo') or out.get('articleNumber') or out.get('materialCode') or '').strip()
        out['articleNo'] = art
        out['materialCode'] = str(out.get('materialCode') or art).strip()
        if out.get('sheetWid') is None and out.get('sheetWidth') is not None:
            out['sheetWid'] = out.get('sheetWidth')
        if out.get('sheetLen') is None:
            for k in ('sheetHeight', 'height'):
                if out.get(k) is not None:
                    out['sheetLen'] = out.get(k); break
        if out.get('thicknessMm') is None and out.get('thickness') is not None:
            out['thicknessMm'] = out.get('thickness')

        # Direct per-material sell price is the active pricing model. Keep legacy purchase
        # fields only as internal historical data; never expose them to Tool A.
        try: incl = float(out.get('sellPriceInclVatPerSheet') or 0.0)
        except Exception: incl = 0.0
        try: ex = float(out.get('sellPriceExVatPerSheet') or 0.0)
        except Exception: ex = 0.0
        if incl <= 0 and ex > 0:
            incl = round(ex * (1.0 + CATALOG_VAT_RATE), 2)
        if ex <= 0 and incl > 0:
            ex = round(incl / (1.0 + CATALOG_VAT_RATE), 6)
        out['sellPriceInclVatPerSheet'] = incl if incl > 0 else None
        out['sellPriceExVatPerSheet'] = ex if ex > 0 else None

        pid = str(out.get('publicMaterialId') or '').strip().lower()
        if pid and not _PUBLIC_MATERIAL_ID_RE.fullmatch(pid):
            pid = ''
        out['publicMaterialId'] = pid
        out['publicName'] = self._public_material_name(out)
        out['brand'] = str(out.get('brand') or '').strip() or self._infer_material_brand(out)
        # FIX656 fast path: imported CSV records already contain deterministic presentation
        # fields. Reclassify only legacy/incomplete records, never 597 records per request.
        have_presentation = (
            bool(str(out.get('visualFamily') or out.get('decorType') or '').strip()) and
            isinstance(out.get('visualTags'), list) and
            bool(str(out.get('colorGroup') or '').strip()) and
            isinstance(out.get('searchTags'), list)
        )
        presentation = {} if have_presentation else self._material_presentation(out)
        out['visualFamily'] = str(out.get('visualFamily') or out.get('decorType') or presentation.get('visualFamily') or 'Overig')
        out['visualTags'] = list(out.get('visualTags') or presentation.get('visualTags') or [out['visualFamily']])
        out['decorType'] = str(out.get('decorType') or out['visualFamily'])
        out['colorGroup'] = str(out.get('colorGroup') or presentation.get('colorGroup') or 'Overig')
        out['searchTags'] = list(out.get('searchTags') or presentation.get('searchTags') or [])
        out['published'] = bool(out.get('published', out.get('active', True)))
        out['isPopular'] = bool(out.get('isPopular', False))
        out['isNew'] = bool(out.get('isNew', False))
        out['hasGrain'] = True if out.get('hasGrain') is None else bool(out.get('hasGrain'))
        out['grainDefaultOn'] = True if out.get('grainDefaultOn') is None else bool(out.get('grainDefaultOn'))
        out['archived'] = bool(out.get('archived', False))
        out['sourceKind'] = str(out.get('sourceKind') or 'LEGACY_LIBRARY').strip() or 'LEGACY_LIBRARY'
        out['catalogMissing'] = bool(out.get('catalogMissing', False))
        out['catalogExcluded'] = bool(out.get('catalogExcluded', False))

        if pid:
            version = str(out.get('imageVersion') or '').strip()
            thumb = DECOR_MEDIA_ROOT / pid / 'thumb.webp'
            preview = DECOR_MEDIA_ROOT / pid / 'preview.webp'
            catalog_cached = _catalog_read_cached_image(DECOR_MEDIA_ROOT / pid)
            prefer_catalog = str(out.get('sourceKind') or '').upper() == 'CATALOG_IMPORT'
            catalog_meta = catalog_cached[1] if catalog_cached else {}
            catalog_version = str(version or catalog_meta.get('sha256') or '')[:64]
            suffix = ('?v=' + quote(catalog_version)) if catalog_version else ''
            variants = catalog_meta.get('variants') if isinstance(catalog_meta, dict) and isinstance(catalog_meta.get('variants'), dict) else {}
            # FIX654: imported images are prepared before publication. Prefer the lightweight
            # WebP variants when the cache metadata confirms they belong to the current source.
            if prefer_catalog and catalog_cached and thumb.exists() and preview.exists() and 'thumb.webp' in variants and 'preview.webp' in variants:
                out['imageAvailable'] = True
                out['imageThumbUrl'] = f'/api/materials/image/{pid}/thumb.webp{suffix}'
                out['imagePreviewUrl'] = f'/api/materials/image/{pid}/preview.webp{suffix}'
                out['imageCacheKind'] = 'catalog_webp'
            elif prefer_catalog and catalog_cached:
                out['imageAvailable'] = True
                out['imageThumbUrl'] = f'/api/materials/image/{pid}/catalog{suffix}'
                out['imagePreviewUrl'] = f'/api/materials/image/{pid}/catalog{suffix}'
                out['imageCacheKind'] = 'catalog_cache'
            elif thumb.exists() and preview.exists():
                out['imageAvailable'] = True
                suffix = ('?v=' + quote(version)) if version else ''
                out['imageThumbUrl'] = f'/api/materials/image/{pid}/thumb.webp{suffix}'
                out['imagePreviewUrl'] = f'/api/materials/image/{pid}/preview.webp{suffix}'
                out['imageCacheKind'] = 'manual_webp'
            elif catalog_cached:
                out['imageAvailable'] = True
                meta = catalog_cached[1]
                catalog_version = str(version or meta.get('sha256') or '')[:64]
                suffix = ('?v=' + quote(catalog_version)) if catalog_version else ''
                out['imageThumbUrl'] = f'/api/materials/image/{pid}/catalog{suffix}'
                out['imagePreviewUrl'] = f'/api/materials/image/{pid}/catalog{suffix}'
                out['imageCacheKind'] = 'catalog_cache'
            else:
                out['imageAvailable'] = False
        return out

    def _material_record_to_toola_catalog(self, rec, already_normalized: bool = False):
        """Return the minimal public material contract.

        Internal article numbers, supplier fields and purchase prices never leave this
        method. Tool A creates its own opaque compatibility aliases client-side.
        """
        rr = rec if already_normalized and isinstance(rec, dict) else self._normalize_material_record_for_admin(rec)
        pid = str(rr.get('publicMaterialId') or '').strip()
        public_name = self._public_material_name(rr)
        try: w = float(rr.get('sheetWid') or rr.get('sheetWidth') or 0)
        except Exception: w = 0.0
        try: h = float(rr.get('sheetLen') or rr.get('sheetHeight') or rr.get('height') or 0)
        except Exception: h = 0.0
        try: t = float(rr.get('thicknessMm') or rr.get('thickness') or 0)
        except Exception: t = 0.0
        active = bool(rr.get('active', True)) and not bool(rr.get('archived', False))
        return {
            'publicMaterialId': pid,
            'publicName': public_name,
            'brand': str(rr.get('brand') or 'Overig').strip() or 'Overig',
            'decorType': str(rr.get('primaryVisualFamily') or rr.get('decorType') or rr.get('visualFamily') or 'Onbekend').strip() or 'Onbekend',
            'primaryVisualFamily': str(rr.get('primaryVisualFamily') or rr.get('visualFamily') or rr.get('decorType') or 'Onbekend').strip() or 'Onbekend',
            'visualFamily': str(rr.get('primaryVisualFamily') or rr.get('visualFamily') or rr.get('decorType') or 'Onbekend').strip() or 'Onbekend',
            'visualTags': [str(x)[:40] for x in (rr.get('visualTags') or []) if str(x).strip()][:12],
            'substrateType': str(rr.get('substrateType') or 'ONBEKEND').strip().upper() or 'ONBEKEND',
            'substrateLabel': str(rr.get('substrateLabel') or 'Onbekend').strip() or 'Onbekend',
            'collection': str(rr.get('collection') or '').strip()[:80],
            'colorGroup': str(rr.get('colorGroup') or 'Overig').strip() or 'Overig',
            'searchTags': [str(x)[:60] for x in (rr.get('searchTags') or []) if str(x).strip()][:48],
            'thicknessMm': t,
            'sheetSizeMm': {'width': w, 'height': h},
            'hasGrain': bool(rr.get('hasGrain', True)),
            'grainDefaultOn': bool(rr.get('grainDefaultOn', True)),
            'active': active,
            'published': bool(rr.get('published', active)),
            'isPopular': bool(rr.get('isPopular', False)),
            'isNew': bool(rr.get('isNew', False)),
            'imageAvailable': bool(rr.get('imageAvailable', False)),
            'imageThumbUrl': rr.get('imageThumbUrl') or '',
            'imagePreviewUrl': rr.get('imagePreviewUrl') or '',
        }

    def _material_id_maps(self) -> tuple[dict[str, str], dict[str, str]]:
        runtime = self._runtime
        _material_lookup_snapshot = runtime._material_lookup_snapshot

        snapshot = _material_lookup_snapshot()
        # Return shallow map copies so a caller cannot mutate the shared cache.
        return dict(snapshot.get('publicToInternal') or {}), dict(snapshot.get('internalToPublic') or {})

    def _resolve_public_material_value(self, value, public_to_internal: dict[str, str]):
        runtime = self._runtime
        validate_public_material_id = runtime.validate_public_material_id

        if not isinstance(value, str):
            raise ValueError('Publieke materiaal-ID moet tekst zijn.')
        raw = validate_public_material_id(value.strip().lower())
        if raw not in public_to_internal:
            raise ValueError('Dit decor is niet meer beschikbaar. Kies het materiaal opnieuw.')
        return public_to_internal[raw]

    def _rewrite_panels_csv_material_ids(self, text: str, public_to_internal: dict[str, str]) -> str:
        runtime = self._runtime
        csv = runtime.csv
        io = runtime.io

        text = str(text or '')
        if not text.strip():
            return text
        inp = io.StringIO(text)
        reader = csv.DictReader(inp, delimiter=';')
        if not reader.fieldnames:
            return text
        out = io.StringIO(newline='')
        writer = csv.DictWriter(out, fieldnames=reader.fieldnames, delimiter=';', lineterminator='\n', extrasaction='ignore')
        writer.writeheader()
        for row in reader:
            for key in ('MaterialCode','ArticleNumber','articleNumber','articleNo','materialCode'):
                if key in row and row.get(key) is not None:
                    row[key] = self._resolve_public_material_value(str(row.get(key) or ''), public_to_internal)
            writer.writerow(row)
        return out.getvalue()

    def _canonicalize_public_job_payload(self, payload: dict) -> dict:
        """Convert browser intent into the complete server-owned production contract."""
        runtime = self._runtime
        Any = runtime.Any
        CATALOG_ALLOWED_THICKNESSES_MM = runtime.CATALOG_ALLOWED_THICKNESSES_MM
        SafetyContractError = runtime.SafetyContractError
        _EMAIL_RE = runtime._EMAIL_RE
        _canonical_panels_csv = runtime._canonical_panels_csv
        _clean_text = runtime._clean_text
        _env_int = runtime._env_int
        _expand_dxf_payload = runtime._expand_dxf_payload
        _material_lookup_snapshot = runtime._material_lookup_snapshot
        _parse_panels_csv_contract = runtime._parse_panels_csv_contract
        _sanitize_phone_text = runtime._sanitize_phone_text
        _sanitize_user_text = runtime._sanitize_user_text
        _strict_dxf_entities_bbox = runtime._strict_dxf_entities_bbox
        _strict_dxf_entities_section = runtime._strict_dxf_entities_section
        _strict_dxf_entity_bbox = runtime._strict_dxf_entity_bbox
        _strict_dxf_entity_layer = runtime._strict_dxf_entity_layer
        _strict_dxf_entity_type = runtime._strict_dxf_entity_type
        _strict_dxf_parse_pairs = runtime._strict_dxf_parse_pairs
        _strict_dxf_split_entities = runtime._strict_dxf_split_entities
        _utc_now_iso = runtime._utc_now_iso
        finite_number = runtime.finite_number
        hashlib = runtime.hashlib
        os = runtime.os
        replace = runtime.replace
        validate_public_material_id = runtime.validate_public_material_id


        if not isinstance(payload, dict):
            raise SafetyContractError('Job payload must be an object')
        allowed_keys = {
            'panelsCsv', 'dxfParts', 'dxfBlobs', 'dxfPartRefs', 'jobJson',
            'pricing', 'preflightEstimate', 'payloadSchema',
        }
        unknown = sorted(set(payload) - allowed_keys)
        if unknown:
            raise SafetyContractError(f'Unknown job payload fields: {unknown[:8]}')

        catalog_snapshot = _material_lookup_snapshot()
        if not (catalog_snapshot.get('publicToInternal') or {}):
            # One-time compatibility migration for a pre-public-ID library.  Normal
            # requests never enter this path once the active CSV catalog is current.
            self._load_material_library_bundle()
            catalog_snapshot = _material_lookup_snapshot()
        public_to_internal = catalog_snapshot.get('publicToInternal') or {}
        if not public_to_internal:
            raise SafetyContractError('De actieve materiaalcatalogus is leeg')
        raw_csv = payload.get('panelsCsv')
        if not isinstance(raw_csv, str):
            raise SafetyContractError('panelsCsv is required')
        rows = _parse_panels_csv_contract(
            raw_csv,
            allowed_thicknesses=CATALOG_ALLOWED_THICKNESSES_MM,
            allowed_edge_codes={0, 1},
            max_rows=_env_int('PUBLIC_JOB_MAX_PANEL_ROWS', 500),
            max_total_qty=_env_int('PUBLIC_JOB_TOTAL_QTY_LIMIT', 250),
        )

        catalog_by_internal = catalog_snapshot.get('catalogByInternal') or {}

        canonical_rows = []
        for row in rows:
            public_id = validate_public_material_id(row.MaterialCode.lower())
            internal = public_to_internal.get(public_id)
            if not internal:
                raise SafetyContractError('Dit decor is niet meer beschikbaar. Kies het materiaal opnieuw.')
            record = catalog_by_internal.get(internal)
            if not isinstance(record, dict):
                raise SafetyContractError('Materiaal ontbreekt in de actieve servercatalogus')
            if (
                str(record.get('sourceKind') or '').upper() != 'CATALOG_IMPORT'
                or record.get('catalogMissing') is True
                or record.get('active') is False
                or record.get('archived') is True
                or record.get('published') is False
                or record.get('catalogExcluded') is True
            ):
                raise SafetyContractError('Materiaal is niet actief gepubliceerd')
            live_thickness = finite_number(
                record.get('thicknessMm'),
                field=f'{public_id}.thicknessMm',
                minimum=0.1,
                maximum=100.0,
            )
            if abs(live_thickness - row.ThicknessMm) > 1e-9:
                raise SafetyContractError(f'{row.PartId}: plaatdikte wijkt af van de actieve catalogus')
            if row.GrainGroup and record.get('hasGrain') is False:
                raise SafetyContractError(f'{row.PartId}: dit materiaal staat geen GrainGroup toe')
            canonical_rows.append(replace(row, MaterialCode=internal, ThicknessMm=live_thickness))

        dxf_parts = _expand_dxf_payload(payload)
        expected_part_ids = {row.PartId for row in canonical_rows}
        supplied_part_ids = set(dxf_parts)
        if supplied_part_ids != expected_part_ids:
            missing = sorted(expected_part_ids - supplied_part_ids)[:10]
            extra = sorted(supplied_part_ids - expected_part_ids)[:10]
            raise SafetyContractError(f'DXF-set komt niet exact overeen met panelen; ontbreekt={missing}, extra={extra}')

        max_blob_bytes = _env_int('PUBLIC_DXF_BLOB_MAX_BYTES', 2 * 1024 * 1024)
        max_total_bytes = _env_int('PUBLIC_DXF_TOTAL_MAX_BYTES', 12 * 1024 * 1024)
        unique_dxf_bytes = 0
        # Compact browser transport deliberately maps many PartIds to one immutable
        # DXF body. Validate that body once, then repeat only the per-panel bbox check.
        # The old loop reparsed the same potentially large DXF hundreds of times before
        # the API could even return 202 for a 200–250 panel order.
        validated_geometry: dict[str, Any] = {}
        # Browser compact transport can map hundreds of PartIds to one Python string
        # object.  Encode/hash/parse that body once, then only perform the required
        # per-panel bbox comparison.  This changes no geometry or placement policy.
        validated_body_text: dict[str, tuple[str, Any]] = {}
        canonical_dxf_blobs: dict[str, str] = {}
        canonical_dxf_refs: dict[str, str] = {}
        row_by_id = {row.PartId: row for row in canonical_rows}
        bbox_tolerance = finite_number(
            os.environ.get('DXF_BBOX_TOLERANCE_MM', '0.1'),
            field='DXF_BBOX_TOLERANCE_MM',
            minimum=0.0,
            maximum=1.0,
        )
        for part_id, dxf_text in dxf_parts.items():
            body_info = validated_body_text.get(dxf_text)
            if body_info is None:
                encoded = dxf_text.encode('utf-8', errors='strict')
                if len(encoded) > max_blob_bytes:
                    raise SafetyContractError(f'{part_id}: DXF is te groot')
                digest = hashlib.sha256(encoded).hexdigest()
                unique_dxf_bytes += len(encoded)
                if unique_dxf_bytes > max_total_bytes:
                    raise SafetyContractError('Totale DXF-invoer is te groot')
                pairs = _strict_dxf_parse_pairs(dxf_text)
                entities = _strict_dxf_split_entities(_strict_dxf_entities_section(pairs))
                if not entities:
                    raise SafetyContractError(f'{part_id}: DXF bevat geen geometrie')
                for entity in entities:
                    kind = _strict_dxf_entity_type(entity)
                    if kind not in {'LINE', 'CIRCLE', 'ARC', 'LWPOLYLINE'}:
                        raise SafetyContractError(f'{part_id}: niet-ondersteund DXF-entitytype {kind}')
                    if kind == 'LWPOLYLINE' and _strict_dxf_entity_layer(entity).upper() != 'OUTLINE':
                        raise SafetyContractError(f'{part_id}: alleen OUTLINE LWPOLYLINE is toegestaan')
                    if _strict_dxf_entity_bbox(entity) is None:
                        raise SafetyContractError(f'{part_id}: DXF-entity heeft geen geldige bbox')
                bbox = _strict_dxf_entities_bbox(entities)
                validated_geometry[digest] = bbox
                validated_body_text[dxf_text] = (digest, bbox)
                previous_body = canonical_dxf_blobs.get(digest)
                if previous_body is not None and previous_body != dxf_text:
                    raise SafetyContractError('DXF content-address collision')
                canonical_dxf_blobs.setdefault(digest, dxf_text)
            else:
                digest, bbox = body_info
            canonical_dxf_refs[part_id] = digest
            row = row_by_id[part_id]
            if abs(bbox.width - row.WidthMm) > bbox_tolerance or abs(bbox.height - row.LengthMm) > bbox_tolerance:
                raise SafetyContractError(
                    f'{part_id}: DXF bbox {bbox.width:.3f}x{bbox.height:.3f} wijkt af van CSV '
                    f'{row.WidthMm:.3f}x{row.LengthMm:.3f}'
                )

        raw_job = payload.get('jobJson') if isinstance(payload.get('jobJson'), dict) else {}
        raw_customer = raw_job.get('customer') if isinstance(raw_job.get('customer'), dict) else {}
        customer: dict[str, Any] = {}
        for key in ('name', 'fullName', 'firstName', 'lastName', 'company', 'companyName', 'city', 'country'):
            if raw_customer.get(key) not in (None, ''):
                customer[key] = _sanitize_user_text(raw_customer.get(key), 240)
        for key in ('email', 'mail'):
            if raw_customer.get(key) not in (None, ''):
                value = _clean_text(raw_customer.get(key), 320).strip()
                if not _EMAIL_RE.fullmatch(value):
                    raise SafetyContractError('E-mailadres is ongeldig')
                customer[key] = value
        for key in ('phone', 'tel', 'telephone'):
            if raw_customer.get(key) not in (None, ''):
                customer[key] = _sanitize_phone_text(raw_customer.get(key), 60)
        for key in (
            'address', 'addressLine1', 'street', 'billingAddress', 'invoiceAddress',
            'shippingAddress', 'deliveryAddress', 'address1', 'houseNumber',
            'postalCode', 'postcode'
        ):
            if raw_customer.get(key) not in (None, ''):
                customer[key] = _sanitize_user_text(raw_customer.get(key), 320)
        if isinstance(raw_customer.get('shippingSameAsBilling'), bool):
            customer['shippingSameAsBilling'] = bool(raw_customer.get('shippingSameAsBilling'))
        rest = raw_job.get('rest_material') if isinstance(raw_job.get('rest_material'), dict) else {}
        carry_out = rest.get('carry_out') is True
        note = _sanitize_user_text(raw_job.get('note'), 2000, allow_note_chars=True)
        canonical_job = {
            'createdAt': _utc_now_iso(),
            'project': 'METOD_PAX',
            'grainEnabled': any(bool(row.GrainGroup) for row in canonical_rows),
            'grainPolicy': 'server-canonical-v1',
            'rest_material': {'carry_out': carry_out},
            'customer': customer,
            'note': note,
        }
        return {
            'panelsCsv': _canonical_panels_csv(canonical_rows),
            'dxfBlobs': canonical_dxf_blobs,
            'dxfPartRefs': canonical_dxf_refs,
            'jobJson': canonical_job,
            'payloadSchema': 'FIX660R8_SERVER_CANONICAL_V1',
        }

    def _resolve_public_material_payload(self, payload: dict) -> dict:
        if not isinstance(payload, dict):
            return payload
        public_to_internal, _ = self._material_id_maps()
        if not public_to_internal:
            raise ValueError('De actieve materiaalcatalogus is leeg.')
        if isinstance(payload.get('panelsCsv'), str):
            payload['panelsCsv'] = self._rewrite_panels_csv_material_ids(payload.get('panelsCsv') or '', public_to_internal)
        code_keys = {'articleNumber','articleNo','materialCode','MaterialCode','ArticleNumber','materialKey','material'}
        def walk(value, parent_key=''):
            if isinstance(value, dict):
                for key in list(value.keys()):
                    if key == 'panelsCsv':
                        continue
                    item = value.get(key)
                    if key in code_keys and isinstance(item, str):
                        value[key] = self._resolve_public_material_value(item, public_to_internal)
                    else:
                        walk(item, key)
            elif isinstance(value, list):
                for item in value:
                    walk(item, parent_key)
        walk(payload)
        return payload

    def _sanitize_public_material_response(self, obj):
        """Remove or replace internal material identifiers in public job output."""
        runtime = self._runtime
        _material_lookup_snapshot = runtime._material_lookup_snapshot

        catalog_snapshot = _material_lookup_snapshot()
        internal_to_public = catalog_snapshot.get('internalToPublic') or {}
        replacements = catalog_snapshot.get('replacements') or ()
        sensitive = {
            'purchaseprice', 'purchasepricepersheet', 'purchase_price', 'inkoopprijs',
            'supplier', 'suppliername', 'leverancier', 'suppliercode', 'supplierarticle',
            'internalarticlenumber', 'internal_article_number', 'internalcode',
            # Raw/internal pricing audit fields never belong in customer responses.
            'sheetunitcostraw', 'sheetcosttotalraw', 'bycodecostraw', 'edgecosttotalraw',
            'imagesourceurl', 'imagesourceurls', 'sourceimageurl', 'catalogsourceurl',
        }
        code_keys = {
            'articlenumber', 'articleno', 'article_number', 'article_no',
            'materialcode', 'material_code', 'sku',
        }

        def replace_codes(text: str) -> str:
            result = str(text)
            for internal, public_id in replacements:
                if internal in result:
                    result = result.replace(internal, public_id)
            return result

        def clean(value, key=''):
            if isinstance(value, dict):
                out = {}
                for k, v in value.items():
                    lk = str(k).lower()
                    if lk in sensitive:
                        continue
                    if lk in code_keys and isinstance(v, str):
                        mapped = internal_to_public.get(v)
                        out[k] = mapped or (v if v.startswith('decor_') else replace_codes(v))
                        continue
                    out[k] = clean(v, k)
                return out
            if isinstance(value, list):
                return [clean(v, key) for v in value]
            if isinstance(value, str):
                return replace_codes(value)
            return value
        return clean(obj)

    def _public_quote_view(self, quote):
        """Return the minimum customer-safe quote projection Tool A needs.

        Internal quote.json can contain production identifiers and audit fields. Public
        callers receive only totals plus opaque public material IDs, display names and
        sheet counts. This makes article numbers unavailable even to a customer who
        inspects the network response instead of merely hiding them in the UI.
        """
        if not isinstance(quote, dict):
            return None
        safe = self._sanitize_public_material_response(quote)
        out = {'currency': str(safe.get('currency') or 'EUR')}
        totals_in = safe.get('totals') if isinstance(safe.get('totals'), dict) else {}
        totals = {}
        for key in ('grandTotal','total','totalInclVat','grandTotalInclVat','sheetCount'):
            if totals_in.get(key) is not None:
                totals[key] = totals_in.get(key)
        if totals:
            out['totals'] = totals
        for key in ('grandTotal','total','totalInclVat','grandTotalInclVat','total_incl_vat','sheetCount'):
            if safe.get(key) is not None:
                out[key] = safe.get(key)
        mats_out = []
        for m in safe.get('materials') or []:
            if not isinstance(m, dict):
                continue
            code = str(m.get('publicMaterialId') or m.get('materialCode') or m.get('code') or m.get('articleNumber') or '').strip()
            if code and not code.startswith('decor_'):
                # Never echo an unresolved identifier to a public caller.
                code = ''
            name = str(m.get('publicName') or m.get('materialDisplayName') or m.get('materialName') or m.get('productName') or m.get('decorName') or m.get('name') or '').strip()
            item = {}
            if code:
                item['publicMaterialId'] = code
                item['materialCode'] = code  # compatibility alias; value is opaque public ID
            if name:
                item['name'] = name
            for src, dst in (('sheetCount','sheetCount'),('plates','plates'),('sheets','sheets')):
                if m.get(src) is not None:
                    item[dst] = m.get(src)
            if item:
                mats_out.append(item)
        if mats_out:
            out['materials'] = mats_out
        return out

    def _decor_image_file(self, public_id: str, variant: str) -> Path | None:
        runtime = self._runtime
        DECOR_MEDIA_ROOT = runtime.DECOR_MEDIA_ROOT
        Path = runtime.Path
        _PUBLIC_MATERIAL_ID_RE = runtime._PUBLIC_MATERIAL_ID_RE
        _catalog_read_cached_image = runtime._catalog_read_cached_image

        pid = str(public_id or '').strip().lower()
        if not _PUBLIC_MATERIAL_ID_RE.fullmatch(pid):
            return None
        root = DECOR_MEDIA_ROOT.resolve()
        if variant == 'catalog':
            cached = _catalog_read_cached_image(DECOR_MEDIA_ROOT / pid)
            if not cached:
                return None
            target = cached[0].resolve()
        elif variant in ('thumb.webp','preview.webp'):
            target = (DECOR_MEDIA_ROOT / pid / variant).resolve()
        else:
            return None
        if root not in target.parents:
            return None
        return target

    def _webp_dimensions(self, data: bytes) -> tuple[int, int] | None:
        try:
            if len(data) < 30 or data[:4] != b'RIFF' or data[8:12] != b'WEBP':
                return None
            pos = 12
            while pos + 8 <= len(data):
                fourcc = data[pos:pos+4]
                size = int.from_bytes(data[pos+4:pos+8], 'little')
                chunk = data[pos+8:pos+8+size]
                if len(chunk) < size:
                    return None
                if fourcc == b'VP8X' and len(chunk) >= 10:
                    w = 1 + int.from_bytes(chunk[4:7], 'little')
                    h = 1 + int.from_bytes(chunk[7:10], 'little')
                    return w, h
                if fourcc == b'VP8 ' and len(chunk) >= 10 and chunk[3:6] == b'\x9d\x01\x2a':
                    w = int.from_bytes(chunk[6:8], 'little') & 0x3fff
                    h = int.from_bytes(chunk[8:10], 'little') & 0x3fff
                    return w, h
                if fourcc == b'VP8L' and len(chunk) >= 5 and chunk[0] == 0x2f:
                    b1,b2,b3,b4 = chunk[1],chunk[2],chunk[3],chunk[4]
                    w = 1 + (b1 | ((b2 & 0x3f) << 8))
                    h = 1 + ((b2 >> 6) | (b3 << 2) | ((b4 & 0x0f) << 10))
                    return w, h
                pos += 8 + size + (size & 1)
        except Exception:
            return None
        return None

    def _public_materials_response_bytes(self, force_rebuild: bool = False) -> tuple[bytes, str, str]:
        """Return a prebuilt PUBLIC-ONLY catalog JSON response.

        FIX656 moves the expensive 597-record normalization/media discovery out of every
        customer page load. The cache key is material_library.json mtime, so every Admin
        publish invalidates automatically. A disk cache survives server restarts.
        """
        runtime = self._runtime
        CATALOG_ALLOWED_THICKNESSES_MM = runtime.CATALOG_ALLOWED_THICKNESSES_MM
        MATERIAL_LIBRARY_PATH = runtime.MATERIAL_LIBRARY_PATH
        PUBLIC_MATERIAL_CATALOG_CACHE_BUILD = runtime.PUBLIC_MATERIAL_CATALOG_CACHE_BUILD
        PUBLIC_MATERIAL_CATALOG_CACHE_META_PATH = runtime.PUBLIC_MATERIAL_CATALOG_CACHE_META_PATH
        PUBLIC_MATERIAL_CATALOG_CACHE_PATH = runtime.PUBLIC_MATERIAL_CATALOG_CACHE_PATH
        PUBLIC_MATERIAL_CATALOG_CACHE_SCHEMA = runtime.PUBLIC_MATERIAL_CATALOG_CACHE_SCHEMA
        _PUBLIC_MATERIALS_RESPONSE_CACHE = runtime._PUBLIC_MATERIALS_RESPONSE_CACHE
        _PUBLIC_MATERIALS_RESPONSE_CACHE_LOCK = runtime._PUBLIC_MATERIALS_RESPONSE_CACHE_LOCK
        _atomic_write_json = runtime._atomic_write_json
        _utc_now_iso = runtime._utc_now_iso
        durable_write_bytes = runtime.durable_write_bytes
        hashlib = runtime.hashlib
        json = runtime.json
        strict_json_load = runtime.strict_json_load
        time = runtime.time

        try:
            source_mtime_ns = int(MATERIAL_LIBRARY_PATH.stat().st_mtime_ns)
        except Exception:
            source_mtime_ns = 0
        with _PUBLIC_MATERIALS_RESPONSE_CACHE_LOCK:
            if (not force_rebuild and _PUBLIC_MATERIALS_RESPONSE_CACHE.get('mtimeNs') == source_mtime_ns
                    and isinstance(_PUBLIC_MATERIALS_RESPONSE_CACHE.get('body'), (bytes, bytearray))):
                return (bytes(_PUBLIC_MATERIALS_RESPONSE_CACHE['body']),
                        str(_PUBLIC_MATERIALS_RESPONSE_CACHE.get('etag') or ''), str(source_mtime_ns))

        if not force_rebuild and source_mtime_ns:
            try:
                meta = strict_json_load(PUBLIC_MATERIAL_CATALOG_CACHE_META_PATH)
                if (
                    int(meta.get('schemaVersion') or 0) == PUBLIC_MATERIAL_CATALOG_CACHE_SCHEMA
                    and str(meta.get('build') or '') == PUBLIC_MATERIAL_CATALOG_CACHE_BUILD
                    and int(meta.get('sourceMtimeNs') or -1) == source_mtime_ns
                    and PUBLIC_MATERIAL_CATALOG_CACHE_PATH.exists()
                ):
                    body = PUBLIC_MATERIAL_CATALOG_CACHE_PATH.read_bytes()
                    etag = str(meta.get('etag') or '')
                    if body and etag:
                        with _PUBLIC_MATERIALS_RESPONSE_CACHE_LOCK:
                            _PUBLIC_MATERIALS_RESPONSE_CACHE.update({'mtimeNs': source_mtime_ns, 'body': body, 'etag': etag})
                        return body, etag, str(source_mtime_ns)
            except Exception:
                pass

        raw, recs = self._load_material_library_bundle()
        norm = []
        for r in recs:
            if not isinstance(r, dict):
                continue
            rr = self._normalize_material_record_for_admin(r)
            if str(rr.get('sourceKind') or '').upper() != 'CATALOG_IMPORT' or rr.get('active') is False or rr.get('archived') is True or rr.get('published') is False or rr.get('catalogExcluded') is True or rr.get('catalogMissing') is True:
                continue
            try:
                thickness_public = float(rr.get('thicknessMm') or 0.0)
            except Exception:
                thickness_public = 0.0
            if not any(abs(thickness_public - float(x)) < 1e-9 for x in CATALOG_ALLOWED_THICKNESSES_MM):
                continue
            pub = self._material_record_to_toola_catalog(rr, already_normalized=True)
            if pub.get('publicMaterialId'):
                norm.append(pub)
        try:
            source_mtime_ns = int(MATERIAL_LIBRARY_PATH.stat().st_mtime_ns)
        except Exception:
            source_mtime_ns = int(time.time() * 1_000_000_000)
        version = str(source_mtime_ns)
        body = json.dumps({'ok': True, 'records': norm, 'version': version, 'count': len(norm), 'schemaVersion': 1},
                          ensure_ascii=False, separators=(',', ':')).encode('utf-8')
        etag = '"fix656-' + hashlib.sha256(body).hexdigest()[:24] + '"'
        try:
            durable_write_bytes(PUBLIC_MATERIAL_CATALOG_CACHE_PATH, body, mode=0o640)
            _atomic_write_json(PUBLIC_MATERIAL_CATALOG_CACHE_META_PATH, {
                'schemaVersion': PUBLIC_MATERIAL_CATALOG_CACHE_SCHEMA,
                'sourceMtimeNs': source_mtime_ns, 'etag': etag,
                'count': len(norm), 'builtAt': _utc_now_iso(),
                'build': PUBLIC_MATERIAL_CATALOG_CACHE_BUILD,
            })
        except Exception:
            pass
        with _PUBLIC_MATERIALS_RESPONSE_CACHE_LOCK:
            _PUBLIC_MATERIALS_RESPONSE_CACHE.update({'mtimeNs': source_mtime_ns, 'body': body, 'etag': etag})
        return body, etag, version

    def _api_public_materials_library(self):
        runtime = self._runtime
        _append_system_event = runtime._append_system_event
        gzip = runtime.gzip

        try:
            body, etag, version = self._public_materials_response_bytes()
            incoming = str(self.headers.get('If-None-Match') or '').strip()
            if incoming and incoming == etag:
                self.send_response(304)
                self.send_header('ETag', etag)
                self.send_header('Cache-Control', 'private, max-age=0, must-revalidate')
                self.send_header('X-ToolA-Catalog-Build', 'FIX656')
                self.end_headers()
                return
            accept_encoding = str(self.headers.get('Accept-Encoding') or '').lower()
            wire_body = gzip.compress(body, compresslevel=5) if 'gzip' in accept_encoding else body
            self.send_response(200)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Content-Length', str(len(wire_body)))
            if wire_body is not body:
                self.send_header('Content-Encoding', 'gzip')
            self.send_header('Vary', 'Accept-Encoding')
            self.send_header('ETag', etag)
            self.send_header('Cache-Control', 'private, max-age=0, must-revalidate')
            self.send_header('X-ToolA-Catalog-Build', 'FIX656')
            self.end_headers()
            self.wfile.write(wire_body)
        except Exception as e:
            _append_system_event(level='error', component='materials', message_user='Materiaalbibliotheek laden is mislukt', message_tech=str(e), status='open')
            return self._send_json({'ok': False, 'error': 'Materiaalbibliotheek kon niet worden geladen'}, 500)

    def _api_admin_materials_library(self):
        runtime = self._runtime
        _append_system_event = runtime._append_system_event

        try:
            raw, recs = self._load_material_library_bundle()
            norm = []
            for r in recs:
                if not isinstance(r, dict):
                    continue
                rr = self._normalize_material_record_for_admin(r)
                if str(rr.get('sourceKind') or '').upper() != 'CATALOG_IMPORT' or rr.get('catalogMissing') is True or rr.get('catalogExcluded') is True:
                    continue
                norm.append(rr)
            return self._send_json({'ok': True, 'records': norm, 'meta': {'source': 'CSV_CATALOG_ONLY', 'count': len(norm), 'decorLibrarySchemaVersion': raw.get('decorLibrarySchemaVersion', 4), 'mode': 'CSV_ONLY', 'lastCatalogImport': raw.get('lastCatalogImport')}})
        except Exception as e:
            _append_system_event(level='error', component='materials', message_user='Materiaalbeheer laden is mislukt', message_tech=str(e), status='open')
            return self._send_json({'ok': False, 'error': 'Materiaalbeheer kon niet worden geladen'}, 500)

    def _api_admin_materials_save_item(self):
        return self._send_json({'ok': False, 'error': 'FIX652: actieve Decor Library wordt uitsluitend via CSV controleren + publiceren beheerd.'}, 410)

    def _api_admin_materials_delete_item(self):
        return self._send_json({'ok': False, 'error': 'FIX652: actieve Decor Library wordt uitsluitend via CSV controleren + publiceren beheerd.'}, 410)

    def _api_admin_materials_upload(self):
        return self._send_json({'ok': False, 'error': 'FIX652: actieve Decor Library wordt uitsluitend via CSV controleren + publiceren beheerd.'}, 410)

    def _api_public_material_image(self, public_id: str, variant: str):
        runtime = self._runtime
        DECOR_MEDIA_ROOT = runtime.DECOR_MEDIA_ROOT
        _PUBLIC_MATERIAL_ID_RE = runtime._PUBLIC_MATERIAL_ID_RE
        _catalog_read_cached_image = runtime._catalog_read_cached_image

        pid = str(public_id or '').strip().lower()
        if not _PUBLIC_MATERIAL_ID_RE.fullmatch(pid):
            return self._send_text('Not found', 404)
        ctype = 'image/webp'
        path = None
        if variant == 'catalog':
            cached = _catalog_read_cached_image(DECOR_MEDIA_ROOT / pid)
            if cached:
                path, meta = cached
                ctype = str(meta.get('mime') or 'application/octet-stream')
        else:
            path = self._decor_image_file(pid, variant)
        if path is None or not path.exists() or not path.is_file():
            return self._send_text('Not found', 404)
        try:
            data = path.read_bytes()
            self.send_response(200)
            self.send_header('Content-Type', ctype)
            self.send_header('Content-Length', str(len(data)))
            self.send_header('Cache-Control', 'public, max-age=31536000, immutable')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.end_headers()
            self.wfile.write(data)
        except Exception:
            return self._send_text('Image unavailable', 500)

    def _api_admin_material_image_upload(self):
        return self._send_json({'ok': False, 'error': 'FIX652: actieve Decor Library wordt uitsluitend via CSV controleren + publiceren beheerd.'}, 410)

    def _api_admin_material_image_delete(self):
        return self._send_json({'ok': False, 'error': 'FIX652: actieve Decor Library wordt uitsluitend via CSV controleren + publiceren beheerd.'}, 410)
