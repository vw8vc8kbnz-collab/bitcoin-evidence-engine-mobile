from __future__ import annotations

"""Immutable, transport-neutral descriptions of the current HTTP surface.

These types deliberately contain identifiers rather than callables.  R9F-2 uses
them as an audited catalog only; they do not dispatch, authorize, read bodies or
write responses.
"""

from dataclasses import dataclass


HTTP_METHODS = frozenset({"GET", "HEAD", "OPTIONS", "POST"})
BODY_CONSUMPTION = frozenset({"none", "bounded-json"})


@dataclass(frozen=True, slots=True)
class BodyPolicy:
    consumption: str
    owner_id: str | None
    reader_id: str | None
    limit_environment: str | None
    default_bytes: int | None
    declared_maximum: str


@dataclass(frozen=True, slots=True)
class RateLimitPolicy:
    owner_id: str | None
    bucket: str | None
    maximum: int | None
    window_seconds: int | None
    declared: str


@dataclass(frozen=True, slots=True)
class RouteDefinition:
    method: str
    pattern: str
    dispatch_id: str
    handler_id: str
    access_policy: str
    origin_policy: str
    body: BodyPolicy
    rate_limit: RateLimitPolicy
    maintenance_policy: str
    response_kind: str
    business_mutation: bool
    runtime_mutation: bool
    pii_classification: str
    security_header_profile: str
    error_schema: str

    @property
    def key(self) -> str:
        return f"{self.method} {self.pattern}"


def validate_route_catalog(routes: tuple[RouteDefinition, ...]) -> tuple[str, ...]:
    """Return deterministic catalog errors; an empty tuple is valid."""

    errors: list[str] = []
    keys: set[str] = set()
    for index, route in enumerate(routes):
        label = route.key or f"route[{index}]"
        if route.method not in HTTP_METHODS:
            errors.append(f"{label}: unsupported method")
        if not route.pattern or not route.pattern.startswith("/") and route.pattern != "*":
            errors.append(f"{label}: unsafe pattern")
        if route.key in keys:
            errors.append(f"{label}: duplicate route")
        keys.add(route.key)
        if not route.dispatch_id or not route.handler_id:
            errors.append(f"{label}: missing owner identifier")
        if route.body.consumption not in BODY_CONSUMPTION:
            errors.append(f"{label}: unsupported body policy")
        if route.body.consumption == "none":
            if any((route.body.owner_id, route.body.reader_id,
                    route.body.limit_environment, route.body.default_bytes)):
                errors.append(f"{label}: bodyless route has a reader or limit")
        elif not all((route.body.owner_id, route.body.reader_id,
                      route.body.limit_environment)) or not isinstance(route.body.default_bytes, int):
            errors.append(f"{label}: bounded body policy is incomplete")
        rate_values = (
            route.rate_limit.owner_id, route.rate_limit.bucket,
            route.rate_limit.maximum, route.rate_limit.window_seconds,
        )
        if any(value is not None for value in rate_values) and not all(
            value is not None for value in rate_values
        ):
            errors.append(f"{label}: partial rate-limit policy")
        if route.method in {"GET", "HEAD", "OPTIONS"} and route.business_mutation:
            errors.append(f"{label}: read method declares a business mutation")
        if route.method != "POST" and route.origin_policy not in {
            "none", "allowlisted-public-or-admin-origin-reflection",
        }:
            errors.append(f"{label}: read method declares a write-origin policy")
        if route.method == "POST" and route.pattern.startswith("/api/admin/"):
            if "admin-origin" not in route.origin_policy:
                errors.append(f"{label}: Admin mutation lacks its origin policy")
    return tuple(errors)


__all__ = (
    "BODY_CONSUMPTION",
    "HTTP_METHODS",
    "BodyPolicy",
    "RateLimitPolicy",
    "RouteDefinition",
    "validate_route_catalog",
)
