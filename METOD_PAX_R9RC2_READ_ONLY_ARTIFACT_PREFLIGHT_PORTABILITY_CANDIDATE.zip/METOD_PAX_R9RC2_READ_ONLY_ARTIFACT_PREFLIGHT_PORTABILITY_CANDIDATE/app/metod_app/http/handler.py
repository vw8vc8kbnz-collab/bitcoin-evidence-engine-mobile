from __future__ import annotations

"""Compose the concrete HTTP handler from bounded behavior owners."""

from .admin_operations_runtime import AdminOperationsRuntimeMixin
from .catalog_import_runtime import CatalogImportRuntimeMixin
from .material_catalog_runtime import MaterialCatalogRuntimeMixin
from .public_api_runtime import PublicApiRuntimeMixin
from .transport_runtime import TransportRuntimeMixin


def build_handler(runtime):
    class Handler(
        TransportRuntimeMixin,
        MaterialCatalogRuntimeMixin,
        CatalogImportRuntimeMixin,
        AdminOperationsRuntimeMixin,
        PublicApiRuntimeMixin,
        runtime.SimpleHTTPRequestHandler,
    ):
        _runtime = runtime

    Handler.__name__ = "Handler"
    Handler.__qualname__ = "Handler"
    return Handler
