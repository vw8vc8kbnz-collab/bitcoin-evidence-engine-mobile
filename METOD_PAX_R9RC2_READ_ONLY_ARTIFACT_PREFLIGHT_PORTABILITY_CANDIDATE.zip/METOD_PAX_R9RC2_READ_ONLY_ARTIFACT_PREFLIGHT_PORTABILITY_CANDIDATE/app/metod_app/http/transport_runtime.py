from __future__ import annotations

"""Focused TransportRuntimeMixin owner; dependencies resolve through the composition runtime."""

class TransportRuntimeMixin:
    _runtime: object

    def _prepare_html(self, text: str) -> str:
        runtime = self._runtime
        _STATIC_HTTP = runtime._STATIC_HTTP

        prepared, nonce = _STATIC_HTTP.prepare_html(text)
        self._csp_nonce = nonce
        return prepared

    def translate_path(self, path: str) -> str:
        runtime = self._runtime
        _STATIC_HTTP = runtime._STATIC_HTTP

        return _STATIC_HTTP.translate_path(path)

    def guess_type(self, path: str) -> str:
        runtime = self._runtime
        _STATIC_HTTP = runtime._STATIC_HTTP

        return _STATIC_HTTP.guess_type(path, super().guess_type)

    def end_headers(self):
        runtime = self._runtime
        _STATIC_HTTP = runtime._STATIC_HTTP

        _STATIC_HTTP.apply_default_headers(self)
        super().end_headers()

    def do_OPTIONS(self):
        runtime = self._runtime
        _match_http_route = runtime._match_http_route

        route_match = _match_http_route('OPTIONS', self.path)
        route_key = route_match.key if route_match is not None else None
        if route_key == 'OPTIONS *':
            self.send_response(204)
            self.end_headers()
            return
        return self._send_text('Not found', 404)

    def _load_admin_credentials(self):
        runtime = self._runtime
        _ADMIN_ACCESS = runtime._ADMIN_ACCESS

        return _ADMIN_ACCESS.load_credentials()

    def _warn_if_local_admin_credentials_in_production(self, creds: dict | None) -> None:
        runtime = self._runtime
        _ADMIN_ACCESS = runtime._ADMIN_ACCESS

        _ADMIN_ACCESS.warn_if_local_credentials_in_production(self, creds)

    def _require_admin_write_origin(self) -> bool:
        runtime = self._runtime
        _helpers_require_same_origin_admin_write = runtime._helpers_require_same_origin_admin_write
        _is_loopback_client = runtime._is_loopback_client
        _is_loopback_value = runtime._is_loopback_value

        ok, error = _helpers_require_same_origin_admin_write(
            self,
            is_loopback_value=_is_loopback_value,
            is_loopback_client=_is_loopback_client,
        )
        if ok:
            return True
        return self._send_json({'ok': False, 'error': error or 'Admin write origin blocked'}, 403)

    def _require_same_origin_public_write(self) -> bool:
        runtime = self._runtime
        _is_loopback_client = runtime._is_loopback_client
        _is_loopback_value = runtime._is_loopback_value
        _is_production_runtime = runtime._is_production_runtime
        _origin_allowed = runtime._origin_allowed
        _public_error_message = runtime._public_error_message
        urlparse = runtime.urlparse

        try:
            origin = str(self.headers.get('Origin') or '').strip()
            referer = str(self.headers.get('Referer') or '').strip()
            host_header = str(self.headers.get('Host') or '').strip()
            host_name = host_header.split(':', 1)[0].strip().lower() if host_header else ''

            def _matches_host(candidate_host: str) -> bool:
                # Development convenience only. Production writes require an exact
                # ALLOWED_ORIGINS match and never trust a client-controlled Host header.
                if _is_production_runtime():
                    return False
                candidate_host = str(candidate_host or '').strip().lower()
                if not candidate_host:
                    return False
                if host_name and candidate_host == host_name:
                    return True
                if host_name and _is_loopback_value(candidate_host) and _is_loopback_value(host_name):
                    return True
                return False

            if origin:
                if _origin_allowed(origin, admin=False):
                    return True
                try:
                    o = urlparse(origin)
                    if _matches_host(o.hostname or ''):
                        return True
                except Exception:
                    pass
                return self._send_json({'ok': False, 'error': _public_error_message(403)}, 403)

            if referer:
                try:
                    r = urlparse(referer)
                    ref_origin = f"{r.scheme}://{r.netloc}" if r.scheme and r.netloc else ''
                    if ref_origin and _origin_allowed(ref_origin, admin=False):
                        return True
                    if _matches_host(r.hostname or ''):
                        return True
                except Exception:
                    pass
                return self._send_json({'ok': False, 'error': _public_error_message(403)}, 403)

            if not _is_production_runtime() and _is_loopback_client(self):
                return True
            return self._send_json({'ok': False, 'error': _public_error_message(403)}, 403)
        except Exception:
            return self._send_json({'ok': False, 'error': _public_error_message(403)}, 403)

    def _api_admin_login(self):
        runtime = self._runtime
        _ADMIN_ACCESS = runtime._ADMIN_ACCESS

        return _ADMIN_ACCESS.login(self)

    def _check_admin_auth_silent(self) -> bool:
        runtime = self._runtime
        _ADMIN_ACCESS = runtime._ADMIN_ACCESS

        return _ADMIN_ACCESS.check_silent(self)

    def _current_admin_session_token(self) -> str:
        runtime = self._runtime
        _ADMIN_ACCESS = runtime._ADMIN_ACCESS

        return _ADMIN_ACCESS.current_session_token(self)

    def _current_admin_actor(self) -> str:
        runtime = self._runtime
        _ADMIN_ACCESS = runtime._ADMIN_ACCESS

        return _ADMIN_ACCESS.current_actor(self)

    def _api_admin_logout(self):
        runtime = self._runtime
        _ADMIN_ACCESS = runtime._ADMIN_ACCESS

        return _ADMIN_ACCESS.logout(self)

    def _wants_native_basic_prompt(self) -> bool:
        runtime = self._runtime
        _ADMIN_ACCESS = runtime._ADMIN_ACCESS

        return _ADMIN_ACCESS.wants_native_basic_prompt(self)

    def _send_admin_auth_challenge(self, code: int = 401, message: str = 'Admin authentication required'):
        runtime = self._runtime
        _ADMIN_ACCESS = runtime._ADMIN_ACCESS

        return _ADMIN_ACCESS.send_challenge(self, code, message)

    def _require_admin_auth(self) -> bool:
        runtime = self._runtime
        _ADMIN_ACCESS = runtime._ADMIN_ACCESS

        return _ADMIN_ACCESS.require_auth(self)
