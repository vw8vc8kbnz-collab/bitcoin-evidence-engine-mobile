"""Pure HTTP contracts; runtime dispatch remains in ``server_py`` during R9F-2."""

