from __future__ import annotations

"""HTTP endpoint adapters for drafts."""

def api_draft_save(runtime, self):
    """Compatibility no-op.

    Tool A no longer stores shared server-side drafts. The historical endpoint was
    unauthenticated and could expose or overwrite data. Empty reset writes remain
    accepted so the current reset flow stays compatible.
    """
    _read_json_body_limited = runtime._read_json_body_limited

    try:
        data = _read_json_body_limited(self, 'PUBLIC_DRAFT_MAX_BYTES', 16384) or {}
        draft = data.get('draft')
        if draft not in (None, {}):
            return self._send_json({'ok': False, 'error': 'Serverconcepten worden niet meer ondersteund'}, code=410)
        return self._send_json({'ok': True, 'disabled': True})
    except Exception:
        return self._send_json({'ok': False, 'error': 'Ongeldig conceptverzoek'}, code=400)


def api_dxf_manifest_meta(runtime, handler, parsed):
    """Return current embedded DXF catalog version.

    IMPORTANT: must not be cached by browsers/proxies, because Tool A relies on this
    to detect live updates when SSE is flaky or blocked.
    """
    get_embedded_dxfs_version = runtime.get_embedded_dxfs_version
    json = runtime.json

    try:
        version = get_embedded_dxfs_version()
        body = json.dumps({"version": version}).encode("utf-8")
        handler.send_response(200)
        handler.send_header("Content-Type", "application/json; charset=utf-8")
        handler.send_header("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate")
        handler.send_header("Pragma", "no-cache")
        handler.send_header("Expires", "0")
        handler.send_header("Content-Length", str(len(body)))
        handler.end_headers()
        handler.wfile.write(body)
    except Exception:
        handler._send_json({"version": None, "error": "Manifest ophalen is mislukt"}, code=500)


def api_draft_load(runtime, self, parsed):
    # Shared server-side drafts are disabled. Returning an empty result preserves
    # compatibility without reading historical files containing internal data.
    return self._send_json({'ok': True, 'draft': None, 'disabled': True})

