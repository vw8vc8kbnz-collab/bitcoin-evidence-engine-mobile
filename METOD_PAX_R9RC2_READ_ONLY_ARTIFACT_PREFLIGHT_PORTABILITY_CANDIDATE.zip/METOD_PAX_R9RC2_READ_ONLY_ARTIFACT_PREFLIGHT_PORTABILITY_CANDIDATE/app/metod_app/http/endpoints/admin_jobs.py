from __future__ import annotations

"""HTTP endpoint adapters for admin jobs."""

def _edge_meters_by_decor(runtime, job_dir: Path):
    """Read input/panels.csv and sum required edge band meters per DecorName.

    Reporting-only helper for /admin. Never affects pricing or nesting.
    """
    Path = runtime.Path
    csv = runtime.csv

    try:
        import csv
        panels_path = job_dir / 'input' / 'panels.csv'
        if not panels_path.exists():
            return {}
        out = {}
        with panels_path.open('r', encoding='utf-8-sig', newline='') as f:
            reader = csv.DictReader(f)
            for r in reader:
                try:
                    qty = int(float((r.get('Qty') or '1').strip() or '1'))
                except Exception:
                    qty = 1
                try:
                    L = float((r.get('LengthMm') or '0').strip() or '0')
                    W = float((r.get('WidthMm') or '0').strip() or '0')
                except Exception:
                    L = 0.0; W = 0.0

                decor = (r.get('DecorName') or r.get('MaterialCode') or '').strip() or '—'

                def _code(name: str) -> int:
                    try:
                        return int(float((r.get(name) or '0').strip() or '0'))
                    except Exception:
                        return 0

                # Same meter model as Tool B quote: H* uses LengthMm, W* uses WidthMm
                meters = 0.0
                if _code('H1') != 0: meters += (L/1000.0) * qty
                if _code('H2') != 0: meters += (L/1000.0) * qty
                if _code('W1') != 0: meters += (W/1000.0) * qty
                if _code('W2') != 0: meters += (W/1000.0) * qty

                if meters <= 0:
                    continue
                out[decor] = out.get(decor, 0.0) + meters
        # round for display
        return {k: round(v, 3) for k, v in sorted(out.items(), key=lambda kv: kv[0].lower())}
    except Exception:
        return {}


def api_admin_jobs(runtime, self):
    JOBS = runtime.JOBS
    _admin_sheet_download_name = runtime._admin_sheet_download_name
    _classify_output_kind = runtime._classify_output_kind
    _customer_name_from_job = runtime._customer_name_from_job
    _edge_meters_by_decor = runtime._edge_meters_by_decor
    _job_lock = runtime._job_lock
    _job_meta = runtime._job_meta
    _parse_panels_csv = runtime._parse_panels_csv
    _sealed_output_artifacts = runtime._sealed_output_artifacts
    strict_json_load = runtime.strict_json_load

    jobs = []
    for p in sorted(JOBS.glob('*')):
        if not p.is_dir():
            continue
        job_id = p.name
        with _job_lock:
            meta = _job_meta.get(job_id, {})
        output_dir = p / 'output'
        sealed = _sealed_output_artifacts(p)
        # Read-only endpoint: production exports are created and sealed by the
        # finalizer. Admin browsing must never mutate a completed job.
        sheets_dir = output_dir / 'sheets'
        sheets = []
        if sealed:
            # Tool B may output sheet files with .dxf/.DXF or (on some systems) without an extension (e.g. 'Sheet_001').
            # Also allow nested folders under sheets/.
            sheet_files = [
                fp for rel, fp in sorted(sealed.items())
                if rel.startswith('output/sheets/') and fp.suffix.lower() == '.dxf'
            ]
            # Return relative names (under output/sheets) so download endpoint works.
            rels = []
            for f in sheet_files:
                try:
                    rels.append(str(f.relative_to(sheets_dir)).replace('\\','/'))
                except Exception:
                    rels.append(f.name)
            seen=set(); sheets=[x for x in rels if (x.lower() not in seen and not seen.add(x.lower()))]


        # --- Zaagplaten ---
        # Return both the real filename (for download) and a human-friendly label for display.
        # Some runs use short filenames (e.g. "105574_S01.dxf") as a fallback for Windows path limits.
        # The workshop still needs to SEE customer + material in Admin.
        zaag_dir = output_dir / 'DXF_Zaagplaten'
        zaag_files = []
        if sealed:
            zaag_files = [
                fp.name for rel, fp in sorted(sealed.items())
                if rel.startswith('output/DXF_Zaagplaten/') and fp.suffix.lower() == '.dxf'
            ]
            seen=set(); zaag_files=[x for x in zaag_files if (x.lower() not in seen and not seen.add(x.lower()))]
            # De-duplicate per sheet index (S01, S02, ...) in case both a short and a long filename exist.
            # Preference: short physical filename like "105574_S01.dxf", otherwise the shortest name.
            try:
                import re as _re
                def _sheet_key(fn: str):
                    mm = _re.search(r'(S\d{2})', fn or '')
                    return mm.group(1).upper() if mm else (fn or '').lower()

                def _score(fn: str):
                    low = (fn or '').lower()
                    if _re.match(r'^\d+_s\d{2}\.dxf$', low):
                        return (0, len(fn))
                    return (1, len(fn))

                chosen = {}
                for fn in zaag_files:
                    k = _sheet_key(fn)
                    if k not in chosen or _score(fn) < _score(chosen[k]):
                        chosen[k] = fn
                zaag_files = [chosen[k] for k in sorted(chosen.keys())]
            except Exception:
                pass


        # Build label context from input.
        customer_name = ""
        try:
            job_json_path = (p / 'input' / 'job.json')
            if job_json_path.exists():
                jj = strict_json_load(job_json_path)
                customer_name = _customer_name_from_job(jj)
                if customer_name == 'Onbekend':
                    customer_name = ''
        except Exception:
            customer_name = ""

        decor_name = ""
        mat_code = ""
        try:
            panels_path = (p / 'input' / 'panels.csv')
            if panels_path.exists():
                rows = _parse_panels_csv(panels_path.read_text(encoding='utf-8'))
                if rows:
                    r0 = rows[0]
                    decor_name = (r0.get('DecorName') or r0.get('decorName') or '').strip()
                    mat_code = (r0.get('MaterialCode') or r0.get('materialCode') or '').strip()
        except Exception:
            decor_name = ""; mat_code = ""

        def _label_for_file(fname: str) -> str:
            return _admin_sheet_download_name(
                p,
                fname,
                customer=customer_name or None,
            )

        zaag = [{'file': f, 'label': _label_for_file(f)} for f in zaag_files]


        parts_dir = output_dir / 'DXF_Onderdelen'
        parts = []
        if sealed:
            parts = [
                fp.name for rel, fp in sorted(sealed.items())
                if rel.startswith('output/DXF_Onderdelen/') and fp.suffix.lower() == '.dxf'
            ]
            seen=set(); parts=[x for x in parts if (x.lower() not in seen and not seen.add(x.lower()))]


        jobs.append({
            'jobId': job_id,
            'status': meta.get('status', 'unknown'),
            'createdAt': meta.get('createdAt', ''),
            'sheets': sheets,
            'zaagplaten': zaag,
            'onderdelen': parts,
            'sealedFiles': [
                {'rel': rel, 'name': fp.name, 'kind': _classify_output_kind(fp.name)}
                for rel, fp in sorted(sealed.items())
            ],
            'edgeBandByDecorMeters': _edge_meters_by_decor(p),
            'customerName': customer_name,
        })
    return self._send_json({'jobs': jobs})


def _classify_output_kind(runtime, name: str) -> str:
    n = str(name or '').lower()
    if n.endswith('.dxf'):
        return 'dxf'
    if n == 'quote.json':
        return 'quote'
    if n == 'report.json':
        return 'report'
    if n == 'placements.json':
        return 'placements'
    if n == 'stickertool.json':
        return 'stickertool'
    if n == 'calculation_summary.txt':
        return 'summary'
    if n == 'pricing.json':
        return 'pricing'
    return 'other'


def _collect_job_output_files(runtime, job_id: str) -> list[dict]:
    JOBS = runtime.JOBS
    SafetyContractError = runtime.SafetyContractError
    _best_material_name = runtime._best_material_name
    _classify_output_kind = runtime._classify_output_kind
    _job_material_context = runtime._job_material_context
    _sealed_output_artifacts = runtime._sealed_output_artifacts
    datetime = runtime.datetime
    resolve_identifier_child = runtime.resolve_identifier_child
    timezone = runtime.timezone
    validate_job_id = runtime.validate_job_id

    try:
        job_id = validate_job_id(job_id)
        job_root = resolve_identifier_child(JOBS, job_id)
    except SafetyContractError:
        return []
    sealed = _sealed_output_artifacts(job_root)
    if not sealed:
        return []
    ctx = _job_material_context(job_root)
    code = str(ctx.get('materialCode') or '').strip()
    material_name = str(ctx.get('materialName') or (_best_material_name(code, '') if code else '')).strip()
    rows = []
    for rel, fp in sorted(sealed.items()):
        kind = _classify_output_kind(fp.name)
        rows.append({
            'jobId': job_id,
            'materialCode': code,
            'materialName': material_name,
            'name': fp.name,
            'rel': rel,
            'kind': kind,
            'size': fp.stat().st_size if fp.exists() else 0,
            'mtime': datetime.fromtimestamp(fp.stat().st_mtime, tz=timezone.utc).isoformat().replace('+00:00', 'Z') if fp.exists() else '',
        })
    return rows


def _dedupe_admin_dxf_files(runtime, files: list[dict]) -> list[dict]:
    """Hide duplicate generic Sheet_001.dxf-style files in Admin when a renamed
    workshop-friendly S01 export exists for the same sheet. Keep generic Sheet files
    only as a fallback when no nicer counterpart is available.
    """
    try:
        import re as _re
        rows = list(files or [])

        def _sheet_key(name: str) -> str:
            n = str(name or '').strip()
            m = _re.search(r'(?:^|[^a-z0-9])s(\d{2})(?:\.dxf)?$', n, _re.I)
            if m:
                return f"S{int(m.group(1)):02d}"
            m = _re.fullmatch(r'sheet[_\- ]?(\d+)(?:\.dxf)?', n, _re.I)
            if m:
                return f"S{int(m.group(1)):02d}"
            return n.lower()

        def _is_generic_sheet(name: str) -> bool:
            return bool(_re.fullmatch(r'sheet[_\- ]?\d+(?:\.dxf)?', str(name or '').strip(), _re.I))

        chosen = {}
        for f in rows:
            name = str((f or {}).get('name') or '')
            key = _sheet_key(name)
            cur = chosen.get(key)
            if cur is None:
                chosen[key] = f
                continue
            cur_generic = _is_generic_sheet(str(cur.get('name') or ''))
            new_generic = _is_generic_sheet(name)
            if cur_generic and not new_generic:
                chosen[key] = f
                continue
            if cur_generic == new_generic:
                # Keep shorter rel/name as a deterministic fallback.
                cur_score = (len(str(cur.get('rel') or cur.get('name') or '')), len(str(cur.get('name') or '')))
                new_score = (len(str(f.get('rel') or f.get('name') or '')), len(name))
                if new_score < cur_score:
                    chosen[key] = f

        # Preserve stable ordering from original rows.
        keep_ids = {id(v) for v in chosen.values()}
        return [f for f in rows if id(f) in keep_ids]
    except Exception:
        return list(files or [])


def _extract_strict_calculation_pricing_summary(runtime, job_ids: list[str]) -> dict:
    """Strict authoritative pricing for Tool A status/submit flows.

    Only return pricing when a final human calculation summary exists for one of the
    candidate jobs. Never fall back to request payloads, legacy quote totals, or
    interim frontend values. This prevents stale/partial prices from surfacing in
    the first price overlay before the true server calculation is finished.
    """
    JOBS = runtime.JOBS
    _parse_calculation_summary_totals = runtime._parse_calculation_summary_totals

    out = {
        'materialsTotal': None,
        'materialsTotalInclVat': None,
        'materialsVatIncluded': None,
        'otherCostsExVat': None,
        'otherCostsVat': None,
        'edgeBandTotal': None,
        'cncTotal': None,
        'drawingTotal': None,
        'transportTotal': None,
        'subtotalExVat': None,
        'vatAmount': None,
        'totalInclVat': None,
        'currency': 'EUR',
        'source': '',
    }
    for jid in (job_ids or []):
        if not jid:
            continue
        try:
            jr = JOBS / jid
            calc = _parse_calculation_summary_totals(jr)
            if isinstance(calc, dict) and (calc.get('subtotalExVat') is not None or calc.get('totalInclVat') is not None):
                for k in ('materialsTotal','materialsTotalInclVat','materialsVatIncluded','otherCostsExVat','otherCostsVat','edgeBandTotal','cncTotal','drawingTotal','transportTotal','subtotalExVat','vatAmount','totalInclVat'):
                    out[k] = calc.get(k)
                out['source'] = 'calculation-summary'
                return out
        except Exception:
            pass
    return out


def _extract_admin_pricing_summary(runtime, job_ids: list[str], request_status: dict | None = None) -> dict:
    """Best-effort compact price breakdown for Admin orderdetails.

    STRICT: prefer totals from calculation_summary.txt when available,
    so the Admin card matches the downloadable berekening exactly.
    """
    JOBS = runtime.JOBS
    _extract_pricing_from_any = runtime._extract_pricing_from_any
    _extract_request_summary = runtime._extract_request_summary
    _load_request_payload = runtime._load_request_payload
    _parse_calculation_summary_totals = runtime._parse_calculation_summary_totals
    strict_json_load = runtime.strict_json_load

    out = {
        'materialsTotal': None,
        'materialsTotalInclVat': None,
        'materialsVatIncluded': None,
        'otherCostsExVat': None,
        'otherCostsVat': None,
        'edgeBandTotal': None,
        'cncTotal': None,
        'drawingTotal': None,
        'transportTotal': None,
        'subtotalExVat': None,
        'vatAmount': None,
        'totalInclVat': None,
        'currency': 'EUR',
        'source': '',
    }

    # STRICT source of truth: the human calculation summary.
    for jid in job_ids:
        if not jid:
            continue
        try:
            calc = _parse_calculation_summary_totals(JOBS / jid)
            if isinstance(calc, dict) and (calc.get('subtotalExVat') is not None or calc.get('totalInclVat') is not None):
                for k in ('materialsTotal','materialsTotalInclVat','materialsVatIncluded','otherCostsExVat','otherCostsVat','edgeBandTotal','cncTotal','drawingTotal','transportTotal','subtotalExVat','vatAmount','totalInclVat'):
                    out[k] = calc.get(k)
                out['source'] = 'calculation-summary'
                return out
        except Exception:
            pass


    def _merge(candidate: dict, label: str) -> bool:
        changed = False
        for k in ('materialsTotal','materialsTotalInclVat','materialsVatIncluded','otherCostsExVat','otherCostsVat','edgeBandTotal','cncTotal','drawingTotal','transportTotal','subtotalExVat','vatAmount','totalInclVat'):
            v = candidate.get(k)
            if v is not None and out.get(k) is None:
                out[k] = v
                changed = True
        if changed and not out.get('source'):
            out['source'] = label
        return (out.get('totalInclVat') is not None) or (out.get('subtotalExVat') is not None and any(out.get(x) is not None for x in ('materialsTotal','edgeBandTotal','cncTotal','drawingTotal','transportTotal')))

    for jid in job_ids:
        if not jid:
            continue
        for fp, label in (
            (JOBS / jid / 'output' / 'quote.json', 'job-output-quote'),
            (JOBS / jid / 'output' / 'pricing.json', 'job-output-pricing'),
            (JOBS / jid / 'input' / 'pricing.json', 'job-input-pricing'),
        ):
            try:
                if fp.exists():
                    data = strict_json_load(fp)
                    if _merge(_extract_pricing_from_any(data), label):
                        return out
            except Exception:
                pass

    payload = _load_request_payload(str(request_status.get('requestId') or '')) if isinstance(request_status, dict) else {}
    if isinstance(payload, dict) and payload:
        for src_name in ('quote','pricing','summary'):
            src = payload.get(src_name)
            if isinstance(src, dict):
                if _merge(_extract_pricing_from_any(src), f'request-payload-{src_name}'):
                    return out
        try:
            summ = _extract_request_summary(payload)
            if out['totalInclVat'] is None and summ.get('priceInclVat') is not None:
                out['totalInclVat'] = round(float(summ['priceInclVat']), 2)
            if out['materialsTotal'] is None and summ.get('materialsPrice') is not None:
                out['materialsTotal'] = round(float(summ['materialsPrice']), 2)
            if out['vatAmount'] is None and out['subtotalExVat'] is not None and out['totalInclVat'] is not None:
                out['vatAmount'] = round(out['totalInclVat'] - out['subtotalExVat'], 2)
            if (out['totalInclVat'] is not None or out['materialsTotal'] is not None) and not out.get('source'):
                out['source'] = 'request-payload-summary'
        except Exception:
            pass

    if isinstance(request_status, dict):
        for src_name in ('quote','summary','pricing'):
            src = request_status.get(src_name)
            if isinstance(src, dict):
                if _merge(_extract_pricing_from_any(src), f'request-status-{src_name}'):
                    return out

    if out['subtotalExVat'] is None and out['totalInclVat'] is not None:
        try:
            out['subtotalExVat'] = round(float(out['totalInclVat']) / 1.21, 2)
        except Exception:
            pass
    if out['vatAmount'] is None and out['subtotalExVat'] is not None and out['totalInclVat'] is not None:
        out['vatAmount'] = round(out['totalInclVat'] - out['subtotalExVat'], 2)
    return out


def _find_or_generate_stickertool_file(runtime, job_id: str):
    _REQUEST_DOWNLOAD_PROJECTIONS = runtime._REQUEST_DOWNLOAD_PROJECTIONS

    return _REQUEST_DOWNLOAD_PROJECTIONS.find_finalized_stickertool_file(job_id)

