from __future__ import annotations

"""HTTP endpoint adapters for admin requests."""

def _dir_size_bytes(runtime, root: Path) -> int:
    Path = runtime.Path

    try:
        total = 0
        if not root.exists() or not root.is_dir():
            return 0
        for fp in root.rglob('*'):
            try:
                if fp.is_file():
                    total += fp.stat().st_size
            except Exception:
                pass
        return int(total)
    except Exception:
        return 0


def _build_request_file_manifest(runtime, request_id: str) -> dict:
    _REQUEST_DOWNLOAD_PROJECTIONS = runtime._REQUEST_DOWNLOAD_PROJECTIONS

    return _REQUEST_DOWNLOAD_PROJECTIONS.build_manifest(request_id)


def api_admin_request_files(runtime, self):
    _build_request_file_manifest = runtime._build_request_file_manifest
    _load_status = runtime._load_status
    _safe_id = runtime._safe_id
    parse_qs = runtime.parse_qs
    urlparse = runtime.urlparse

    parsed = urlparse(self.path)
    qs = parse_qs(parsed.query or '')
    rid = _safe_id(str((qs.get('requestId') or [''])[0]).strip(), 120)
    if not rid:
        return self._send_json({'ok': False, 'error': 'Missing requestId'}, 400)
    st = _load_status(rid)
    if not isinstance(st, dict):
        return self._send_json({'ok': False, 'error': 'Unknown requestId'}, 404)
    manifest = _build_request_file_manifest(rid)
    return self._send_json({'ok': True, 'requestId': rid, 'files': manifest})


def api_admin_request_file(runtime, self):
    _REQUEST_DOWNLOAD_PROJECTIONS = runtime._REQUEST_DOWNLOAD_PROJECTIONS
    _load_status = runtime._load_status
    _safe_id = runtime._safe_id
    api_job_file = runtime.api_job_file
    parse_qs = runtime.parse_qs
    urlparse = runtime.urlparse

    parsed = urlparse(self.path)
    qs = parse_qs(parsed.query or '')
    rid = _safe_id(str((qs.get('requestId') or [''])[0]).strip(), 120)
    job_id = _safe_id(str((qs.get('jobId') or [''])[0]).strip(), 200)
    rel = str((qs.get('rel') or [''])[0]).strip()
    if not rid or not job_id or not rel:
        return self._send_text('Missing requestId/jobId/rel', 400)
    st = _load_status(rid)
    if not isinstance(st, dict):
        return self._send_text('Unknown requestId', 404)
    matched = _REQUEST_DOWNLOAD_PROJECTIONS.resolve_linked_file(rid, job_id, rel)
    if matched is None:
        return self._send_text('File not linked to this request', 404)
    return api_job_file(
        self,
        job_id,
        rel,
        download_name_override=str(matched.get('downloadName') or '').strip() or None,
    )


def api_admin_request_download_zip(runtime, self):
    SYSTEM_DIR = runtime.SYSTEM_DIR
    SafetyContractError = runtime.SafetyContractError
    _REQUEST_DOWNLOAD_PROJECTIONS = runtime._REQUEST_DOWNLOAD_PROJECTIONS
    _env_int = runtime._env_int
    _load_status = runtime._load_status
    fsync_directory = runtime.fsync_directory
    os = runtime.os
    parse_qs = runtime.parse_qs
    secrets = runtime.secrets
    urlparse = runtime.urlparse
    validate_request_id = runtime.validate_request_id
    zipfile = runtime.zipfile

    parsed = urlparse(self.path)
    qs = parse_qs(parsed.query or '')
    try:
        rid = validate_request_id(str((qs.get('requestId') or [''])[0]).strip())
    except SafetyContractError:
        return self._send_text('Invalid requestId', 400)
    scope = str((qs.get('scope') or ['all'])[0]).strip().lower()
    if scope not in {'all', 'dxf'}:
        return self._send_text('Invalid scope', 400)
    st = _load_status(rid)
    if not isinstance(st, dict):
        return self._send_text('Unknown requestId', 404)
    export_limit = max(1, _env_int('ADMIN_EXPORT_MAX_INPUT_BYTES', 1024 * 1024 * 1024))
    plan = _REQUEST_DOWNLOAD_PROJECTIONS.build_export_plan(rid, scope, export_limit)
    if not plan.ok:
        return self._send_text(plan.message, plan.status)

    export_dir = SYSTEM_DIR / 'exports'
    export_dir.mkdir(parents=True, exist_ok=True)
    export_path = export_dir / f'.request_export_{rid}_{secrets.token_hex(8)}.zip'
    try:
        with zipfile.ZipFile(export_path, 'w', zipfile.ZIP_DEFLATED, allowZip64=True) as zf:
            for source, arcname in plan.selected:
                zf.write(source, arcname)
        with export_path.open('rb') as handle:
            os.fsync(handle.fileno())
        fsync_directory(export_dir)
        if export_path.stat().st_size > export_limit:
            return self._send_text('Compressed export exceeds the configured limit', 413)
        return self._stream_file(
            export_path,
            content_type='application/zip',
            download_name=plan.download_name,
            max_bytes=export_limit,
        )
    finally:
        try:
            export_path.unlink(missing_ok=True)
            fsync_directory(export_dir)
        except Exception:
            pass


def api_admin_requests(runtime, self):
    """Admin endpoint: list requests (mailbox)."""
    _REQUEST_DOWNLOAD_PROJECTIONS = runtime._REQUEST_DOWNLOAD_PROJECTIONS
    parse_qs = runtime.parse_qs
    urlparse = runtime.urlparse

    parsed = urlparse(self.path)
    qs = parse_qs(parsed.query or "")
    try:
        limit = int((qs.get("limit") or ["200"])[0])
    except Exception:
        limit = 200
    limit = max(1, min(2000, limit))
    rows = _REQUEST_DOWNLOAD_PROJECTIONS.list_requests(limit)
    return self._send_json({"ok": True, "requests": rows})


def api_admin_requests_update(runtime, self):
    """Admin endpoint: update request mailbox status (e.g., mark quote sent)."""
    SafetyContractError = runtime.SafetyContractError
    _append_system_event = runtime._append_system_event
    _ensure_request_dirs = runtime._ensure_request_dirs
    _load_status = runtime._load_status
    _public_error_message = runtime._public_error_message
    _read_json_body_limited = runtime._read_json_body_limited
    _save_status = runtime._save_status
    validate_request_id = runtime.validate_request_id

    _ensure_request_dirs()
    try:
        body = _read_json_body_limited(self, 'ADMIN_JSON_MAX_BYTES', 262144)
    except Exception as e:
        return self._send_json({"ok": False, "error": _public_error_message(400)}, 400)

    try:
        rid = validate_request_id(body.get("requestId"))
    except SafetyContractError:
        return self._send_json({"ok": False, "error": "Missing requestId"}, 400)

    st = _load_status(rid)
    if not isinstance(st, dict):
        return self._send_json({"ok": False, "error": "Unknown requestId"}, 404)

    action = str(body.get("action") or "").strip().lower()
    before = {
        'publicStatus': st.get('publicStatus'),
        'internalStatus': st.get('internalStatus'),
        'quoteStatus': st.get('quoteStatus'),
    }
    if action == "mark_quote_sent":
        st["quoteStatus"] = "DONE"
        st["needsQuote"] = False
        st["publicStatus"] = "DONE"
        st["publicStatusLabel"] = "Afgehandeld"
        st["internalStatus"] = "DONE"
        st["internalStatusLabel"] = "Afgehandeld"
    elif action == "reopen":
        st["quoteStatus"] = "TODO"
        st["needsQuote"] = True
        st["publicStatus"] = "SUBMITTED"
        st["publicStatusLabel"] = "Aanvraag verzonden"
        if str(st.get("internalStatus") or "").upper() in ("PROCESSING", "OFFER_SENT", ""):
            st["internalStatus"] = "QUEUED"
            st["internalStatusLabel"] = "In wachtrij"
    else:
        return self._send_json({"ok": False, "error": "Unknown action"}, 400)

    _save_status(rid, st)
    _append_system_event(
        level='info', component='admin_request',
        message_user='Aanvraagstatus aangepast',
        message_tech=f'request={rid}; action={action}',
        request_id=rid, status='resolved',
        details={
            'actor': self._current_admin_actor() or 'unknown-admin',
            'action': action,
            'before': before,
            'after': {
                'publicStatus': st.get('publicStatus'),
                'internalStatus': st.get('internalStatus'),
                'quoteStatus': st.get('quoteStatus'),
            },
        },
    )
    return self._send_json({"ok": True})

