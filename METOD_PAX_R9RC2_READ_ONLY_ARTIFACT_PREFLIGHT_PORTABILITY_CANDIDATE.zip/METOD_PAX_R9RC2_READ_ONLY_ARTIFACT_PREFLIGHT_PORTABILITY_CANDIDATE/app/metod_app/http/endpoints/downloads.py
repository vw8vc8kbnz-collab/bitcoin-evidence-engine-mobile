from __future__ import annotations

"""HTTP endpoint adapters for downloads."""

def api_job_file(runtime, 
    self,
    job_id: str,
    rel: str,
    parsed=None,
    *,
    download_name_override: str | None = None,
):
    """Serve a file inside jobs/<jobId> safely.

    This endpoint is used by Admin downloads. It must never fail silently
    (ERR_EMPTY_RESPONSE). If something goes wrong, return an error body.
    """
    JOBS = runtime.JOBS
    _admin_sheet_download_name = runtime._admin_sheet_download_name
    _customer_name_from_job = runtime._customer_name_from_job
    _env_int = runtime._env_int
    _finalization_complete = runtime._finalization_complete
    _public_job_family_complete = runtime._public_job_family_complete
    _sanitize_filename = runtime._sanitize_filename
    _sealed_output_artifacts = runtime._sealed_output_artifacts
    resolve_identifier_child = runtime.resolve_identifier_child
    strict_json_dumps = runtime.strict_json_dumps
    strict_json_load = runtime.strict_json_load
    strict_json_loads = runtime.strict_json_loads
    validate_job_id = runtime.validate_job_id

    try:
        job_id = validate_job_id(job_id)
        job_root = resolve_identifier_child(JOBS, job_id)
        if not self._require_job_access(job_id, parsed=parsed):
            return
        is_admin_request = bool(self._check_admin_auth_silent())
        rel_norm_public = (rel or '').replace('\\', '/').lstrip('/').lower()
        # Public job tokens are only allowed to read a sanitized quote. Production
        # inputs, CSV, pricing, stickers and DXF remain Admin-only.
        if not is_admin_request and rel_norm_public != 'output/quote.json':
            return self._send_text('Forbidden', 403)
        if not job_root.exists():
            return self._send_text('Not found', 404)

        if not _finalization_complete(job_root):
            return self._send_text('Production output is not finalized', 409)
        if not is_admin_request and not _public_job_family_complete(job_id, memo={}):
            return self._send_text('Complete job family is not finalized', 409)

        rel_norm = (rel or '').replace('\\', '/').lstrip('/')
        fpath = _sealed_output_artifacts(job_root).get(rel_norm)
        if fpath is None:
            return self._send_text('Not found', 404)

        if (not fpath.exists()) or (not fpath.is_file()):
            return self._send_text('Not found', 404)

        data: bytes | None = None
        if not is_admin_request and rel_norm_public == 'output/quote.json':
            try:
                data = fpath.read_bytes()
                obj = strict_json_loads(data)
                obj = self._public_quote_view(obj)
                data = strict_json_dumps(obj).encode('utf-8')
            except Exception:
                return self._send_text('Quote unavailable', 500)

        ctype = 'application/octet-stream'
        name = fpath.name.lower()
        if name.endswith('.json'):
            ctype = 'application/json'
        elif name.endswith('.csv'):
            ctype = 'text/csv'
        elif name.endswith('.txt'):
            ctype = 'text/plain'
        elif name.endswith('.dxf'):
            ctype = 'application/dxf'
        elif name.endswith('.html'):
            ctype = 'text/html'

        # Friendly download name for Stickertool v2
        download_name = fpath.name
        try:
            if download_name_override:
                download_name = _sanitize_filename(download_name_override, 160) or fpath.name
            elif (
                fpath.suffix.lower() == '.dxf'
                and (
                    rel_norm.startswith('output/DXF_Zaagplaten/')
                    or rel_norm.startswith('output/sheets/')
                )
            ):
                download_name = _admin_sheet_download_name(job_root, fpath.name)
            elif rel_norm == 'output/stickertool.json':
                job_json_path = job_root / 'input' / 'job.json'
                job_json = {}
                if job_json_path.exists():
                    try:
                        job_json = strict_json_load(job_json_path)
                    except Exception:
                        job_json = {}
                cust_name = _customer_name_from_job(job_json)
                safe_cust = _sanitize_filename(cust_name or 'Onbekend', 50)
                safe_job = _sanitize_filename(job_id, 60)
                download_name = f"{safe_cust}__{safe_job}__stickertool.json"
        except Exception:
            download_name = fpath.name

        if is_admin_request:
            return self._stream_file(
                fpath,
                content_type='application/json; charset=utf-8' if ctype == 'application/json' else ctype,
                download_name=download_name,
                max_bytes=max(1, _env_int('ADMIN_FILE_DOWNLOAD_MAX_BYTES', 2 * 1024 * 1024 * 1024)),
            )
        if data is None:
            return self._send_text('Forbidden', 403)

        self.send_response(200)
        self.send_header('Cache-Control', 'no-store')
        if ctype == 'application/json':
            self.send_header('Content-Type', 'application/json; charset=utf-8')
        else:
            self.send_header('Content-Type', ctype)
        self.send_header('Content-Disposition', f'attachment; filename="{download_name}"')
        self.send_header('Content-Length', str(len(data)))
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.end_headers()
        self.wfile.write(data)
        return
    except Exception as e:
        return self._send_text('Error serving file', 500)


def api_stickertool_v2(runtime, self, subjob_id: str):
    """Retired unauthenticated compatibility route."""
    return self._send_text('Deprecated. Use an authenticated job file route.', 410)


def api_subjob_file(runtime, self, job_id: str, subjob_id: str, rel: str, parsed=None):
    """Serve a sealed file from a subjob linked to the specified master job."""
    JOBS = runtime.JOBS
    SafetyContractError = runtime.SafetyContractError
    _admin_sheet_download_name = runtime._admin_sheet_download_name
    _customer_name_from_job = runtime._customer_name_from_job
    _env_int = runtime._env_int
    _extract_request_token = runtime._extract_request_token
    _finalization_complete = runtime._finalization_complete
    _linked_subjob_ids = runtime._linked_subjob_ids
    _public_job_family_complete = runtime._public_job_family_complete
    _read_job_access_token = runtime._read_job_access_token
    _sanitize_filename = runtime._sanitize_filename
    _sealed_output_artifacts = runtime._sealed_output_artifacts
    hmac = runtime.hmac
    resolve_identifier_child = runtime.resolve_identifier_child
    strict_json_dumps = runtime.strict_json_dumps
    strict_json_load = runtime.strict_json_load
    strict_json_loads = runtime.strict_json_loads
    validate_job_id = runtime.validate_job_id

    try:
        job_id = validate_job_id(job_id)
        subjob_id = validate_job_id(subjob_id)
        master_root = resolve_identifier_child(JOBS, job_id)
        subjob_root = resolve_identifier_child(JOBS, subjob_id)
    except SafetyContractError:
        return self._send_text('Not found', 404)
    if subjob_id not in _linked_subjob_ids(job_id):
        return self._send_text('Not found', 404)
    if not master_root.is_dir() or not subjob_root.is_dir() or not _finalization_complete(subjob_root):
        return self._send_text('Production output is not finalized', 409)

    is_admin_request = bool(self._check_admin_auth_silent())
    if not is_admin_request:
        supplied = _extract_request_token(self, parsed=parsed)
        expected_master = _read_job_access_token(job_id)
        expected_subjob = _read_job_access_token(subjob_id)
        allowed = bool(supplied) and any(
            expected and hmac.compare_digest(str(supplied), str(expected))
            for expected in (expected_master, expected_subjob)
        )
        if not allowed:
            return self._send_text('Forbidden', 403)
        if not _public_job_family_complete(job_id, memo={}):
            return self._send_text('Complete job family is not finalized', 409)
    rel_norm_public = (rel or '').replace('\\', '/').lstrip('/').lower()
    if not is_admin_request and rel_norm_public != 'output/quote.json':
        return self._send_text('Forbidden', 403)
    rel_norm = (rel or '').replace('\\', '/').lstrip('/')
    fpath = _sealed_output_artifacts(subjob_root).get(rel_norm)
    if fpath is None:
        return self._send_text('Not found', 404)
    if not fpath.exists() or not fpath.is_file():
        return self._send_text('Not found', 404)

    data: bytes | None = None
    if not is_admin_request and rel_norm_public == 'output/quote.json':
        try:
            data = fpath.read_bytes()
            obj = strict_json_loads(data)
            obj = self._public_quote_view(obj)
            data = strict_json_dumps(obj).encode('utf-8')
        except Exception:
            return self._send_text('Quote unavailable', 500)
    ctype = 'application/octet-stream'
    name = fpath.name.lower()
    if name.endswith('.json'):
        ctype = 'application/json'
    elif name.endswith('.csv'):
        ctype = 'text/csv'
    elif name.endswith('.txt'):
        ctype = 'text/plain'

    # Friendly filename for sealed Admin production artifacts.
    download_name = fpath.name
    try:
        if (
            fpath.suffix.lower() == '.dxf'
            and (
                rel_norm.startswith('output/DXF_Zaagplaten/')
                or rel_norm.startswith('output/sheets/')
            )
        ):
            download_name = _admin_sheet_download_name(subjob_root, fpath.name)
        elif rel_norm.lower() == 'output/stickertool.json':
            # Try to derive customer from the subjob's job.json if present
            job_json_path = subjob_root / 'input' / 'job.json'
            job_json = {}
            if job_json_path.exists():
                try:
                    job_json = strict_json_load(job_json_path)
                except Exception:
                    job_json = {}
            cust_name = _customer_name_from_job(job_json)
            safe_cust = _sanitize_filename(cust_name or 'Onbekend', 50)
            safe_sub = _sanitize_filename(subjob_id, 80)
            download_name = f"{safe_cust}__{safe_sub}__stickertool.json"
    except Exception:
        download_name = fpath.name

    if is_admin_request:
        return self._stream_file(
            fpath,
            content_type='application/json; charset=utf-8' if ctype == 'application/json' else ctype,
            download_name=download_name,
            max_bytes=max(1, _env_int('ADMIN_FILE_DOWNLOAD_MAX_BYTES', 2 * 1024 * 1024 * 1024)),
        )
    if data is None:
        return self._send_text('Forbidden', 403)

    self.send_response(200)
    self.send_header('Content-Type', ctype)
    self.send_header('Cache-Control', 'no-store')
    self.send_header('Content-Disposition', f'attachment; filename="{download_name}"')
    self.send_header('Content-Length', str(len(data)))
    self.end_headers()
    self.wfile.write(data)


def api_download(runtime, self, job_id: str, fname: str, parsed=None):
    JOBS = runtime.JOBS
    SafetyContractError = runtime.SafetyContractError
    _admin_sheet_download_name = runtime._admin_sheet_download_name
    _env_int = runtime._env_int
    _sealed_output_artifacts = runtime._sealed_output_artifacts
    resolve_identifier_child = runtime.resolve_identifier_child
    validate_job_id = runtime.validate_job_id

    try:
        job_id = validate_job_id(job_id)
        job_root = resolve_identifier_child(JOBS, job_id)
    except SafetyContractError:
        return self._send_text('Not found', 404)
    if not self._require_job_access(job_id, parsed=parsed):
        return
    if not self._check_admin_auth_silent():
        return self._send_text('Forbidden', 403)
    rel = 'output/sheets/' + str(fname).replace('\\', '/')
    fpath = _sealed_output_artifacts(job_root).get(rel)
    if fpath is None:
        return self._send_text('Not found', 404)
    if not fpath.exists():
        return self._send_text('Not found', 404)
    return self._stream_file(
        fpath,
        content_type='application/dxf',
        download_name=_admin_sheet_download_name(job_root, str(fname)),
        max_bytes=max(1, _env_int('ADMIN_FILE_DOWNLOAD_MAX_BYTES', 2 * 1024 * 1024 * 1024)),
    )

