"""Bounded HTTP endpoint adapters; process state stays in runtime.application."""
