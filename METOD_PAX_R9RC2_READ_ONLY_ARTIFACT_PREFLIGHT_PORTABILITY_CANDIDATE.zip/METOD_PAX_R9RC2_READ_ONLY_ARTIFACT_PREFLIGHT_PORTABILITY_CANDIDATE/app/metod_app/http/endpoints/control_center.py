from __future__ import annotations

"""HTTP endpoint adapters for control center."""

def _fmt_bytes(runtime, n: int) -> str:
    try:
        n = int(n)
    except Exception:
        return "0 B"
    units = ["B","KB","MB","GB","TB"]
    i = 0
    f = float(n)
    while f >= 1024 and i < len(units)-1:
        f /= 1024.0
        i += 1
    if i == 0:
        return f"{int(f)} {units[i]}"
    return f"{f:.1f} {units[i]}"


def api_admin_control_center(runtime, self):
    """Read-only info for the Admin Control Center (Phase 1)."""
    DXF_MANIFEST_PATH = runtime.DXF_MANIFEST_PATH
    JOBS = runtime.JOBS
    MATERIAL_LIBRARY_PATH = runtime.MATERIAL_LIBRARY_PATH
    OPTIMIZER_TOOL_B = runtime.OPTIMIZER_TOOL_B
    PRICING_ACTIVE = runtime.PRICING_ACTIVE
    Path = runtime.Path
    _dir_size_bytes = runtime._dir_size_bytes
    _safe_json = runtime._safe_json
    time = runtime.time

    # Active versions (Phase 1 = simple file timestamps; no editing here)
    def _file_ver(path: Path) -> dict:
        if not path.exists():
            return {"exists": False}
        st = path.stat()
        return {
            "exists": True,
            "file": path.name,
            "modified": time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(st.st_mtime)),
            "bytes": int(st.st_size),
        }

    pricing = _file_ver(PRICING_ACTIVE)
    materials = _file_ver(MATERIAL_LIBRARY_PATH)
    dxf_library = _file_ver(DXF_MANIFEST_PATH)
    optimizer = {"active": OPTIMIZER_TOOL_B}

    # Storage
    jobs_count = 0
    largest = {"jobId": None, "bytes": 0}
    try:
        for p in JOBS.glob('*'):
            if not p.is_dir(): 
                continue
            jobs_count += 1
            sz = _dir_size_bytes(p)
            if sz > largest["bytes"]:
                largest = {"jobId": p.name, "bytes": sz}
    except Exception:
        pass

    # Recent failures (best-effort): jobs with non-empty toolb_stderr.txt
    failures = []
    try:
        job_dirs = [p for p in JOBS.glob('*') if p.is_dir()]
        job_dirs.sort(key=lambda p: p.stat().st_mtime, reverse=True)
        for p in job_dirs[:200]:
            err = p / 'output' / 'toolb_stderr.txt'
            if err.exists():
                try:
                    txt = err.read_text(encoding='utf-8', errors='ignore').strip()
                except Exception:
                    txt = ''
                if txt:
                    # short excerpt
                    excerpt = '\n'.join(txt.splitlines()[:5]).strip()
                    failures.append({
                        "jobId": p.name,
                        "modified": time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(p.stat().st_mtime)),
                        "excerpt": excerpt[:600],
                    })
            if len(failures) >= 5:
                break
    except Exception:
        pass

    # Disk usage (jobs folder only)
    jobs_bytes = _dir_size_bytes(JOBS)

    payload = {
        "versions": {
            "pricing": pricing,
            "materials": materials,
            "dxfLibrary": dxf_library,
            "optimizer": optimizer,
        },
        "storage": {
            "jobsCount": jobs_count,
            "jobsBytes": jobs_bytes,
            "largestJob": largest,
        },
        "failures": failures,
    }
    body, code = _safe_json(payload, 200)
    self.send_response(code)
    self.send_header('Content-Type', 'application/json; charset=utf-8')
    self.send_header('Content-Length', str(len(body)))
    self.end_headers()
    self.wfile.write(body)

