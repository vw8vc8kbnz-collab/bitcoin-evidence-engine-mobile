from __future__ import annotations

"""Single owner for public static exposure and generic HTTP responses.

Business-route selection, authentication and request-body handling deliberately
remain outside this module.  The live handler supplies only transport methods.
"""

import re
import secrets
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable
from urllib.parse import unquote, urlparse


PUBLIC_STATIC_ROOT_FILES = {
    "toolA.html", "embedded_dxfs_manifest.json",
}

PUBLIC_STATIC_MODULE_FILES = {
    "tool-a/bootstrap.js", "tool-a/api/jobs.js", "tool-a/api/requests.js",
    "tool-a/components/checkout-review.js", "tool-a/components/dialog.js",
    "tool-a/components/footer.js", "tool-a/components/grain-preview.js",
    "tool-a/components/material-card.js", "tool-a/components/mobile-material-cart.js",
    "tool-a/components/overlay-router.js", "tool-a/components/panel-editor.js",
    "tool-a/components/progress-overlay.js", "tool-a/components/thank-you.js",
    "tool-a/state/store.js", "tool-a/state/selectors.js",
    "tool-a/steps/materials.js", "tool-a/steps/panels.js", "tool-a/steps/grain.js",
    "tool-a/steps/customer.js",
}

PUBLIC_STATIC_SHELL_FILES = {
    "tool-a/styles/tool-a.bundle.css",
    "tool-a/runtime/classic-runtime.bundle.js",
    "tool-a/shell/script-01-early-catalog-bootstrap.js",
}

BLOCKED_STATIC_TOP_LEVEL = {
    "config", "jobs", "requests", "archive", "backups", "system", "docs",
    "__pycache__",
}


def is_public_static_relpath(rel: str) -> bool:
    rel = str(rel or "").strip().lstrip("/")
    if not rel:
        rel = "toolA.html"
    rel = rel.replace("\\", "/")
    if rel in PUBLIC_STATIC_ROOT_FILES or rel in PUBLIC_STATIC_MODULE_FILES or rel in PUBLIC_STATIC_SHELL_FILES:
        return True
    if rel.startswith("embedded_dxfs/"):
        return rel.lower().endswith(".dxf")
    if rel.startswith("assets/"):
        return rel.lower().endswith((".png", ".jpg", ".jpeg", ".webp", ".svg"))
    return False


def is_blocked_static_relpath(rel: str) -> bool:
    rel = str(rel or "").strip().lstrip("/").replace("\\", "/")
    if not rel:
        return False
    parts = [part for part in rel.split("/") if part not in ("", ".")]
    if not parts:
        return False
    if parts[0] in BLOCKED_STATIC_TOP_LEVEL:
        return True
    if any(part.startswith(".") for part in parts):
        return True
    return rel.lower().endswith((".log", ".jsonl", ".py", ".pyc", ".bat", ".ps1", ".sh"))


@dataclass(frozen=True, slots=True)
class StaticHttpDependencies:
    root: Callable[[], Path]
    state_root: Callable[[], Path]
    dxf_manifest_path: Callable[[], Path]
    dxf_library_root: Callable[[], Path]
    resolve_relative_file: Callable[[Path, str], Path]
    sanitize_filename: Callable[[str, int], str]
    strict_json_dumps: Callable[[Any], str]
    origin_allowed: Callable[..., bool]
    production_hardening_enabled: Callable[[], bool]
    https_request: Callable[[Any], bool]


class StaticHttpAdapterService:
    def __init__(self, dependencies: StaticHttpDependencies):
        self._dependencies = dependencies

    def translate_path(self, request_target: str) -> str:
        deps = self._dependencies
        root = deps.root()
        parsed = urlparse(request_target)
        rel = unquote(parsed.path.lstrip("/"))
        if rel == "":
            rel = "toolA.html"
        if rel == "admin":
            return str(root / "__admin__.html")
        if is_blocked_static_relpath(rel) or not is_public_static_relpath(rel):
            return str(root / "__forbidden_static__.404")
        if rel == "embedded_dxfs_manifest.json":
            target = deps.dxf_manifest_path().resolve()
            allowed_root = deps.state_root().resolve()
        elif rel.startswith("embedded_dxfs/"):
            try:
                target = deps.resolve_relative_file(
                    deps.dxf_library_root(), rel[len("embedded_dxfs/"):]
                )
            except Exception:
                return str(root / "__forbidden_static__.404")
            allowed_root = deps.dxf_library_root().resolve()
        else:
            target = (root / rel).resolve()
            allowed_root = root.resolve()
        if target != allowed_root and allowed_root not in target.parents:
            return str(root / "__forbidden_static__.404")
        if target.is_dir():
            return str(root / "__forbidden_static__.404")
        return str(target)

    @staticmethod
    def guess_type(path: str, fallback: Callable[[str], str]) -> str:
        if str(path).lower().endswith(".dxf"):
            return "application/dxf"
        return fallback(path)

    @staticmethod
    def prepare_html(text: str) -> tuple[str, str]:
        nonce = secrets.token_urlsafe(18)
        prepared = re.sub(
            r"<(script|style)(?=[\s>])",
            lambda match: f'<{match.group(1)} nonce="{nonce}"',
            str(text), flags=re.IGNORECASE,
        )
        return prepared, nonce

    def apply_default_headers(self, handler: Any) -> None:
        deps = self._dependencies
        origin = str(handler.headers.get("Origin") or "").strip()
        if origin:
            try:
                if deps.origin_allowed(origin, admin=False) or deps.origin_allowed(origin, admin=True):
                    handler.send_header("Access-Control-Allow-Origin", origin)
                    handler.send_header("Vary", "Origin")
            except Exception:
                pass
        handler.send_header("Access-Control-Allow-Methods", "GET,POST,OPTIONS")
        handler.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        handler.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        handler.send_header("Pragma", "no-cache")
        handler.send_header("Expires", "0")
        handler.send_header("X-Content-Type-Options", "nosniff")
        handler.send_header("X-Frame-Options", "DENY")
        handler.send_header("Referrer-Policy", "strict-origin-when-cross-origin")
        handler.send_header("Permissions-Policy", "accelerometer=(), autoplay=(), camera=(), geolocation=(), gyroscope=(), magnetometer=(), microphone=(), payment=(), usb=()")
        handler.send_header("Cross-Origin-Opener-Policy", "same-origin")
        handler.send_header("Cross-Origin-Resource-Policy", "same-origin")
        try:
            path = urlparse(handler.path).path.lower()
            if path.startswith("/embedded_dxfs/") and path.endswith(".dxf"):
                name = deps.sanitize_filename(Path(unquote(urlparse(handler.path).path)).name, 120) or "drawing.dxf"
                handler.send_header("Content-Disposition", f'attachment; filename="{name}"')
        except Exception:
            pass
        if deps.production_hardening_enabled():
            nonce = str(getattr(handler, "_csp_nonce", "") or "")
            nonce_source = f" 'nonce-{nonce}'" if nonce else ""
            csp = "; ".join([
                "default-src 'self'", "base-uri 'self'", "object-src 'none'",
                "frame-ancestors 'none'", "frame-src 'none'",
                "img-src 'self' data: blob:", "font-src 'self' data:",
                f"style-src-elem 'self'{nonce_source}",
                "style-src-attr 'unsafe-inline'", f"script-src 'self'{nonce_source}",
                "script-src-attr 'none'", "connect-src 'self'",
                "worker-src 'self' blob:", "manifest-src 'self'",
                "media-src 'self' data: blob:", "form-action 'self'",
            ])
            handler.send_header("Content-Security-Policy", csp)
            if deps.https_request(handler):
                handler.send_header("Strict-Transport-Security", "max-age=31536000")

    def send_text(self, handler: Any, text: str, code: int = 200,
                  content_type: str = "text/plain; charset=utf-8") -> None:
        if str(content_type).lower().startswith("text/html"):
            text, nonce = self.prepare_html(text)
            handler._csp_nonce = nonce
        body = text.encode("utf-8")
        handler.send_response(code)
        handler.send_header("Content-Type", content_type)
        handler.send_header("Content-Length", str(len(body)))
        handler.end_headers()
        handler.wfile.write(body)

    def send_json(self, handler: Any, value: Any, code: int = 200) -> None:
        try:
            body = self._dependencies.strict_json_dumps(value).encode("utf-8")
        except Exception:
            body = b'{"ok":false,"error":"Response serialization failed"}'
            code = 500
        handler.send_response(code)
        handler.send_header("Content-Type", "application/json; charset=utf-8")
        handler.send_header("Content-Length", str(len(body)))
        handler.end_headers()
        handler.wfile.write(body)

    def stream_file(self, handler: Any, path: Path, *, content_type: str,
                    download_name: str, max_bytes: int) -> None:
        resolved = Path(path)
        stat = resolved.stat()
        if not resolved.is_file() or stat.st_size < 0 or stat.st_size > max_bytes:
            return self.send_text(handler, "Download exceeds the configured limit", 413)
        safe_name = self._dependencies.sanitize_filename(download_name, 160) or "download.bin"
        handler.send_response(200)
        handler.send_header("Content-Type", content_type)
        handler.send_header("Content-Disposition", f'attachment; filename="{safe_name}"')
        handler.send_header("Content-Length", str(stat.st_size))
        handler.send_header("X-Content-Type-Options", "nosniff")
        handler.end_headers()
        with resolved.open("rb") as source:
            while True:
                chunk = source.read(1024 * 1024)
                if not chunk:
                    break
                handler.wfile.write(chunk)


__all__ = (
    "BLOCKED_STATIC_TOP_LEVEL", "PUBLIC_STATIC_MODULE_FILES",
    "PUBLIC_STATIC_ROOT_FILES", "PUBLIC_STATIC_SHELL_FILES",
    "StaticHttpAdapterService", "StaticHttpDependencies",
    "is_blocked_static_relpath", "is_public_static_relpath",
)
