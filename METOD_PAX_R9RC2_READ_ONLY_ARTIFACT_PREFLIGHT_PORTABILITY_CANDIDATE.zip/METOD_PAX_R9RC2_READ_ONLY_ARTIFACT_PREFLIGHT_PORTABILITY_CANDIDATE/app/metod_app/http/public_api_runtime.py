from __future__ import annotations

"""Focused PublicApiRuntimeMixin owner; dependencies resolve through the composition runtime."""

class PublicApiRuntimeMixin:
    _runtime: object

    def _require_job_access(self, job_id: str, parsed=None, body: Optional[dict]=None, deny_as_json: bool = False) -> bool:
        runtime = self._runtime
        JOBS = runtime.JOBS
        Optional = runtime.Optional
        SafetyContractError = runtime.SafetyContractError
        _extract_request_token = runtime._extract_request_token
        _read_job_access_token = runtime._read_job_access_token
        hmac = runtime.hmac
        resolve_identifier_child = runtime.resolve_identifier_child
        validate_job_id = runtime.validate_job_id

        try:
            job_id = validate_job_id(job_id)
            resolve_identifier_child(JOBS, job_id)
        except SafetyContractError:
            if deny_as_json:
                return self._send_json({'ok': False, 'error': 'Not found'}, 404)
            return self._send_text('Not found', 404)
        try:
            if self._check_admin_auth_silent():
                return True
        except Exception:
            pass
        expected = _read_job_access_token(job_id)
        supplied = _extract_request_token(self, parsed=parsed, body=body)
        if expected and supplied and hmac.compare_digest(str(supplied), str(expected)):
            return True
        if deny_as_json:
            return self._send_json({'ok': False, 'error': 'Forbidden'}, 403)
        return self._send_text('Forbidden', 403)

    def do_HEAD(self):
        runtime = self._runtime
        _match_http_route = runtime._match_http_route
        admin_asset_for_path = runtime.admin_asset_for_path
        urlparse = runtime.urlparse

        parsed = urlparse(self.path)
        route_match = _match_http_route('HEAD', self.path)
        route_key = route_match.key if route_match is not None else None
        admin_asset = admin_asset_for_path(parsed.path)
        if admin_asset is not None and route_key is not None:
            if admin_asset.requires_session and not self._check_admin_auth_silent():
                self.send_response(404)
                self.send_header('Content-Type', 'text/plain; charset=utf-8')
                self.end_headers()
                return
            body = admin_asset.body.encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', admin_asset.content_type)
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            return
        if route_key in ('HEAD /admin', 'HEAD /admin/', 'HEAD /admin/index.html'):
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.end_headers()
            return
        if route_key == 'HEAD /api/admin/':
            if not self._require_admin_auth():
                return
            self.send_response(204)
            self.end_headers()
            return
        return super().do_HEAD()

    def do_GET(self):
        runtime = self._runtime
        ADMIN_HTML = runtime.ADMIN_HTML
        ADMIN_LOGIN_HTML = runtime.ADMIN_LOGIN_HTML
        ROOT = runtime.ROOT
        SECURITY_BUILD = runtime.SECURITY_BUILD
        _load_pricing_config = runtime._load_pricing_config
        _match_http_route = runtime._match_http_route
        _prometheus_metrics = runtime._prometheus_metrics
        _readiness_report = runtime._readiness_report
        _safe_json = runtime._safe_json
        _sse_handler = runtime._sse_handler
        admin_asset_for_path = runtime.admin_asset_for_path
        api_admin_control_center = runtime.api_admin_control_center
        api_admin_jobs = runtime.api_admin_jobs
        api_admin_request_download_zip = runtime.api_admin_request_download_zip
        api_admin_request_file = runtime.api_admin_request_file
        api_admin_request_files = runtime.api_admin_request_files
        api_admin_requests = runtime.api_admin_requests
        api_download = runtime.api_download
        api_draft_load = runtime.api_draft_load
        api_dxf_manifest_meta = runtime.api_dxf_manifest_meta
        api_job_file = runtime.api_job_file
        api_subjob_file = runtime.api_subjob_file
        urlparse = runtime.urlparse

        parsed = urlparse(self.path)
        route_match = _match_http_route('GET', self.path)
        route_key = route_match.key if route_match is not None else None

        if route_key == 'GET /health/live':
            return self._send_json({'ok': True, 'build': SECURITY_BUILD})
        if route_key == 'GET /health/ready':
            payload, code = _readiness_report()
            # This route is public for load-balancers. Do not disclose capacity,
            # catalog sign-off identity or internal check names here.
            return self._send_json({'ok': bool(payload.get('ok')), 'build': SECURITY_BUILD}, code)

        if route_key in ('GET /', 'GET /toolA.html'):
            try:
                return self._send_text((ROOT / 'toolA.html').read_text(encoding='utf-8'), 200, 'text/html; charset=utf-8')
            except Exception:
                return self._send_text('Tool A kon niet worden geladen', 500)

        # Public SSE stream used by Tool A to refresh embedded DXF catalog live.
        if route_key == 'GET /api/events':
            return _sse_handler(self)

        admin_asset = admin_asset_for_path(parsed.path)
        if admin_asset is not None and route_key is not None:
            if admin_asset.requires_session and not self._check_admin_auth_silent():
                return self._send_text('Not found', 404)
            return self._send_text(admin_asset.body, 200, admin_asset.content_type)

        # FIX622: Serve the Admin shell itself without browser Basic Auth.
        # The admin data/actions under /api/admin/* remain protected and the
        # Admin shell adds Authorization headers from its own login overlay.
        # This avoids iOS Safari offering /admin as a download on 401 responses.
        if parsed.path.startswith('/api/admin/'):
            if not self._require_admin_auth():
                return

        if route_key == 'GET /api/admin/health/ready':
            payload, code = _readiness_report()
            return self._send_json(payload, code)

        # FIX628: clean admin login rebuild.
        # /admin/ is never Basic-Auth challenged. If no valid session cookie/basic auth is
        # present, serve a standalone login page. After /api/admin/login sets the HttpOnly
        # session cookie, serve the real Admin HTML.
        if route_key in ('GET /admin', 'GET /admin/', 'GET /admin/index.html'):
            if self._check_admin_auth_silent():
                return self._send_text(ADMIN_HTML, 200, 'text/html; charset=utf-8')
            return self._send_text(ADMIN_LOGIN_HTML, 200, 'text/html; charset=utf-8')

        if route_key == 'GET /favicon.ico':
            # Avoid noisy 404s in the browser console.
            self.send_response(204)
            self.end_headers()
            return

        if route_key == 'GET /.well-known/appspecific/com.chrome.devtools.json':
            # Chrome DevTools sometimes probes this path; respond without crashing.
            self.send_response(204)
            self.end_headers()
            return

        if route_key == 'GET /api/draft/load':
            return api_draft_load(self, parsed)

        if route_key == 'GET /api/dxf_manifest_meta':
            return api_dxf_manifest_meta(self, parsed)


        if route_key == 'GET /api/admin/jobs':
            return api_admin_jobs(self)

        if route_key == 'GET /api/admin/metrics':
            return self._send_text(_prometheus_metrics(), 200, 'text/plain; version=0.0.4; charset=utf-8')

        if route_key == 'GET /api/admin/requests':
            return api_admin_requests(self)
        if route_key == 'GET /api/admin/request_files':
            return api_admin_request_files(self)
        if route_key == 'GET /api/admin/request_file':
            return api_admin_request_file(self)
        if route_key == 'GET /api/admin/request_download_zip':
            return api_admin_request_download_zip(self)
        if route_key == 'GET /api/admin/requests/update':
            # State changes are POST-only so the existing same-origin write gate
            # cannot be bypassed through a link, prefetch or cross-site GET.
            return self._send_json({'ok': False, 'error': 'Method not allowed'}, 405)

        if route_key == 'GET /api/admin/control_center':
            return api_admin_control_center(self)

        if route_key == 'GET /api/admin/dxf/categories':
            return self._api_admin_dxf_categories()

        if route_key == 'GET /api/admin/dxf/list':
            return self._api_admin_dxf_list(parsed)

        if route_key == 'GET /api/admin/materials/library':
            return self._api_admin_materials_library()
        if route_key == 'GET /api/admin/materials/catalog_status':
            return self._api_admin_catalog_status(parsed)

        if route_key == 'GET /api/materials/library':
            return self._api_public_materials_library()

        if route_key == 'GET /api/materials/image/{publicId}/{variant}':
            return self._api_public_material_image(
                route_match.parameter('publicId'), route_match.parameter('variant')
            )
        if parsed.path.startswith('/api/materials/image/'):
            return self._send_text('Not found', 404)

        if route_key == 'GET /api/admin/system/logs':
            return self._api_admin_system_logs()

        if route_key == 'GET /api/admin/system/backups':
            return self._api_admin_system_backups()
        if route_key == 'GET /api/admin/system/backup_download':
            return self._api_admin_system_backup_download(parsed)

        if route_key == 'GET /api/admin/pricing':
            cfg = _load_pricing_config()
            body, code = _safe_json(cfg, 200)
            self.send_response(code)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return


        # Deprecated: unauthenticated StickerTool v2 direct route. Admin obtains
        # the single sealed output/stickertool.json through the file manifest.
        if route_key == 'GET /api/stickertool_v2/':
            return self._send_text('Deprecated. Use the authenticated Admin output manifest.', 410)

        if route_key == 'GET /api/jobs/{jobId}/download/{filename}':
            return api_download(
                self, route_match.parameter('jobId'), route_match.parameter('filename'), parsed
            )

        # Subjob file serving (Stickertool v2 contract)
        # /api/jobs/<jobId>/subjobs/<subjobId>/file/<relpath>
        if route_key == 'GET /api/jobs/{jobId}/subjobs/{subjobId}/file/{relativePath}':
            return api_subjob_file(
                self,
                route_match.parameter('jobId'),
                route_match.parameter('subjobId'),
                route_match.parameter('relativePath'),
                parsed,
            )

        if route_key == 'GET /api/jobs/{jobId}/file/{relativePath}':
            return api_job_file(
                self, route_match.parameter('jobId'), route_match.parameter('relativePath'), parsed
            )


        if route_key == 'GET /api/jobs/{jobId}/status':
            return self._api_status(route_match.parameter('jobId'), parsed)

        return super().do_GET()

    def do_POST(self):
        runtime = self._runtime
        _STATE_MAINTENANCE_BARRIER = runtime._STATE_MAINTENANCE_BARRIER
        _match_http_route = runtime._match_http_route

        route_match = _match_http_route('POST', self.path)
        route_key = route_match.key if route_match is not None else ''
        if route_key == 'POST /api/admin/system/backup_now':
            return self._do_POST_impl(route_key)
        if not _STATE_MAINTENANCE_BARRIER.begin_mutation():
            return self._send_json({'ok': False, 'error': 'Systeemonderhoud actief; probeer het zo opnieuw.'}, 503)
        try:
            return self._do_POST_impl(route_key)
        finally:
            _STATE_MAINTENANCE_BARRIER.end_mutation()

    def _do_POST_impl(self, route_key=None):
        runtime = self._runtime
        _append_system_event = runtime._append_system_event
        _is_production_runtime = runtime._is_production_runtime
        _match_http_route = runtime._match_http_route
        _public_error_message = runtime._public_error_message
        _read_json_body_limited = runtime._read_json_body_limited
        _safe_json = runtime._safe_json
        _save_pricing_config = runtime._save_pricing_config
        api_admin_requests_update = runtime.api_admin_requests_update
        api_draft_save = runtime.api_draft_save
        urlparse = runtime.urlparse

        parsed = urlparse(self.path)
        if route_key is None:
            route_match = _match_http_route('POST', self.path)
            route_key = route_match.key if route_match is not None else ''

        if route_key == 'POST /api/admin/login':
            if _is_production_runtime() and not self._require_admin_write_origin():
                return
            return self._api_admin_login()

        if parsed.path in ('/admin', '/admin/') or parsed.path.startswith('/api/admin/'):
            if not self._require_admin_auth():
                return
            if parsed.path.startswith('/api/admin/') and not self._require_admin_write_origin():
                return

        if route_key == 'POST /api/admin/logout':
            return self._api_admin_logout()

        if route_key == 'POST /api/admin/materials/catalog_preview':
            return self._api_admin_catalog_preview()
        if route_key == 'POST /api/admin/materials/catalog_publish':
            return self._api_admin_catalog_publish()
        if route_key == 'POST /api/admin/materials/catalog_taxonomy_override':
            return self._api_admin_catalog_taxonomy_override()
        if route_key == 'POST /api/admin/materials/live_taxonomy_family':
            return self._api_admin_live_taxonomy_family()
        if route_key == 'POST /api/admin/materials/catalog_retry_images':
            return self._api_admin_catalog_retry_images()

        if route_key == 'POST /api/admin/materials/upload':
            return self._api_admin_materials_upload()

        if route_key == 'POST /api/admin/materials/save_item':
            return self._api_admin_materials_save_item()

        if route_key == 'POST /api/admin/materials/delete_item':
            return self._api_admin_materials_delete_item()

        if route_key == 'POST /api/admin/materials/image_upload':
            return self._api_admin_material_image_upload()

        if route_key == 'POST /api/admin/materials/image_delete':
            return self._api_admin_material_image_delete()

        if route_key == 'POST /api/admin/system/backup_now':
            return self._api_admin_system_backup_now()

        if route_key == 'POST /api/admin/dxf/create_category':
            return self._api_admin_dxf_create_category()

        if route_key == 'POST /api/admin/dxf/upload':
            return self._api_admin_dxf_upload()

        if route_key == 'POST /api/admin/dxf/delete':
            return self._api_admin_dxf_delete()

        if route_key == 'POST /api/admin/requests/update':
            return api_admin_requests_update(self)

        if route_key in (
            'POST /api/submit_config', 'POST /api/cancel', 'POST /api/jobs/cancel',
            'POST /api/jobs', 'POST /api/draft/save', 'POST /api/client_log',
        ):
            if _is_production_runtime() and not self._require_same_origin_public_write():
                return

        if route_key == 'POST /api/submit_config':
            try:
                return self._api_submit_config()
            except Exception as e:
                _append_system_event(level="error", component="toola", message_user="Aanvraag verwerken is mislukt", message_tech=str(e), status="open")
                return self._send_json({"ok": False, "error": _public_error_message(500)}, 500)
        if route_key == 'POST /api/cancel':
            return self._api_cancel_request()

        if route_key == 'POST /api/client_log':
            return self._api_client_log(parsed=parsed)
        if route_key == 'POST /api/send_to_odoo':
            if not self._require_admin_auth():
                return
            if not self._require_admin_write_origin():
                return
            return self._api_send_to_odoo()
        if route_key == 'POST /api/jobs/cancel':
            return self._api_cancel_job(parsed=parsed)
        if route_key == 'POST /api/jobs':
            return self._api_create_job()

        if route_key == 'POST /api/draft/save':
            return api_draft_save(self)

        if route_key == 'POST /api/admin/pricing':
            try:
                data = _read_json_body_limited(self, 'ADMIN_JSON_MAX_BYTES', 262144)
                actor = self._current_admin_actor() or 'unknown-admin'
                res = _save_pricing_config(data, actor=actor)
                _append_system_event(level="info", component="pricing", message_user="Prijsinstellingen opgeslagen", message_tech=f"Saved pricing config by {actor}", status="resolved", details={'actor': actor, 'version': res.get('version')})
                body, code = _safe_json(res, 200)
            except Exception as e:
                _append_system_event(level="error", component="pricing", message_user="Prijsinstellingen konden niet worden opgeslagen", message_tech=str(e), status="open")
                body, code = _safe_json({'ok': False, 'error': str(e)}, 400)
            self.send_response(code)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        return self._send_text('Not found', 404)

    def _api_send_to_odoo(self):
        """Store a payload for later Odoo integration.

        This route is admin-only and should never be exposed as a public write
        surface. It persists a bounded JSON payload inside the target job.
        """
        runtime = self._runtime
        JOBS = runtime.JOBS
        SafetyContractError = runtime.SafetyContractError
        _append_system_event = runtime._append_system_event
        _finalization_complete = runtime._finalization_complete
        _read_json_body_limited = runtime._read_json_body_limited
        _utc_now_iso = runtime._utc_now_iso
        durable_write_json = runtime.durable_write_json
        resolve_identifier_child = runtime.resolve_identifier_child
        validate_job_id = runtime.validate_job_id

        try:
            payload = _read_json_body_limited(self, 'ADMIN_JSON_MAX_BYTES', 262144)
        except Exception:
            return self._send_json({'ok': False, 'error': 'Invalid JSON'}, 400)

        try:
            job_id = validate_job_id(payload.get('jobId'))
            job_root = resolve_identifier_child(JOBS, job_id)
            if not job_root.is_dir() or not _finalization_complete(job_root):
                return self._send_json({'ok': False, 'error': 'Job is niet definitief afgerond'}, 409)
            durable_write_json(job_root / 'output' / 'odoo_payload.json', {
                'schemaVersion': 1,
                'jobId': job_id,
                'state': 'STAGED_NOT_SENT',
                'createdAt': _utc_now_iso(),
                'actor': self._current_admin_actor() or 'unknown-admin',
                'payload': {key: value for key, value in payload.items() if key != 'jobId'},
            })
        except SafetyContractError:
            return self._send_json({'ok': False, 'error': 'Ongeldige jobId'}, 400)
        except Exception as exc:
            _append_system_event(
                level='error', component='odoo',
                message_user='Odoo-export kon niet worden klaargezet',
                message_tech=str(exc), status='open',
            )
            return self._send_json({'ok': False, 'error': 'Failed to store payload'}, 500)

        return self._send_json({'ok': True, 'stored': True, 'jobId': job_id})

    def _api_submit_config(self):
        """Finalize a customer submission by linking an already-finalized Tool A job.

        FIX657 invariant: /api/jobs is the only route that performs optimization. Submit
        never nests again. It requires the parent job bearer token, verifies finalization,
        links server-derived subjobs, and is idempotent per parent job.
        """
        runtime = self._runtime
        JOBS = runtime.JOBS
        SafetyContractError = runtime.SafetyContractError
        _SUBMISSION_SERVICE = runtime._SUBMISSION_SERVICE
        _client_ip = runtime._client_ip
        _ensure_request_dirs = runtime._ensure_request_dirs
        _finalization_complete = runtime._finalization_complete
        _is_production_runtime = runtime._is_production_runtime
        _job_cancel_requested = runtime._job_cancel_requested
        _public_error_message = runtime._public_error_message
        _rate_limit_allow = runtime._rate_limit_allow
        _read_json_body_limited = runtime._read_json_body_limited
        _safe_id = runtime._safe_id
        _validate_submit_payload = runtime._validate_submit_payload
        resolve_identifier_child = runtime.resolve_identifier_child
        validate_job_id = runtime.validate_job_id

        _ensure_request_dirs()
        ip = _client_ip(self)
        if not _rate_limit_allow('submit_config', ip, 30, 300):
            return self._send_json({"ok": False, "error": "Te veel verzoeken. Probeer het later opnieuw."}, 429)
        try:
            # Size limit (basic anti-abuse). Default 1 MB.
            payload = _read_json_body_limited(self, 'SUBMIT_MAX_BYTES', 8388608 if _is_production_runtime() else 16777216)
            if not isinstance(payload, dict) or not payload:
                return self._send_json({"ok": False, "error": "Lege aanvraagpayload."}, 400)
        except Exception as e:
            return self._send_json({"ok": False, "error": _public_error_message(400)}, 400)

        ok_payload, payload_errors, cleaned_payload = _validate_submit_payload(payload)
        if not ok_payload:
            return self._send_json({"ok": False, "error": "Validatie mislukt"}, 400)
        # Build a new request DTO. Browser quote/pricing/material summaries and unknown
        # nested checkout fields are deliberately not persisted or trusted.
        payload = {
            key: cleaned_payload[key]
            for key in ('jobId', 'parentJobId', 'customer', 'note')
            if key in cleaned_payload
        }

        # A final submission MUST refer to the already-calculated parent job. Never accept
        # a bare cart here, because that would recreate the historical duplicate optimization.
        parent_job_id = str(payload.get("parentJobId") or payload.get("jobId") or "").strip()
        quote_for_link = payload.get("quote") if isinstance(payload.get("quote"), dict) else {}
        if not parent_job_id and isinstance(quote_for_link, dict):
            parent_job_id = str(quote_for_link.get("parentJobId") or quote_for_link.get("jobId") or "").strip()
        parent_job_id = _safe_id(parent_job_id, 200) if parent_job_id else ''
        if not parent_job_id:
            return self._send_json({"ok": False, "error": "Bereken de prijs opnieuw voordat je de aanvraag verstuurt."}, 409)
        try:
            parent_root = resolve_identifier_child(JOBS, validate_job_id(parent_job_id))
        except SafetyContractError:
            return self._send_json({"ok": False, "error": "Bereken de prijs opnieuw voordat je de aanvraag verstuurt."}, 409)
        if not parent_root.exists() or not _finalization_complete(parent_root):
            return self._send_json({"ok": False, "error": "De berekening is nog niet volledig afgerond. Bereken opnieuw en verstuur daarna de aanvraag."}, 409)
        if _job_cancel_requested(parent_job_id):
            return self._send_json({"ok": False, "error": "Deze berekening is geannuleerd. Bereken opnieuw."}, 409)
        if not self._require_job_access(parent_job_id, deny_as_json=True):
            return

        # The authenticated durable transaction is owned outside HTTP. It still
        # preserves the exact claim -> payload -> status -> notify/SSE order and
        # retains the submit-config-link state contract.
        outcome = _SUBMISSION_SERVICE.finalize(parent_job_id, parent_root, payload)
        if outcome.kind == "missing_email":
            return self._send_json({"ok": False, "error": "E-mailadres ontbreekt. Ga terug naar Gegevens en bereken opnieuw."}, 400)
        if outcome.kind == "invalid_email":
            return self._send_json({"ok": False, "error": "E-mailadres is ongeldig."}, 400)
        if outcome.kind == "incomplete_output":
            return self._send_json({"ok": False, "error": "De productie-output kon niet opnieuw worden geverifieerd. Bereken opnieuw."}, 409)
        if outcome.kind == "missing_price":
            return self._send_json({"ok": False, "error": "De definitieve serverprijs ontbreekt. Bereken de prijs opnieuw voordat je verstuurt."}, 409)
        if outcome.kind == "in_progress":
            return self._send_json({"ok": False, "error": "Deze aanvraag wordt al verwerkt. Gebruik de bestaande aanvraag in plaats van opnieuw te versturen."}, 409)
        return self._send_json(outcome.response)

    def _api_cancel_request(self):
        """Public endpoint: mark a request as cancelled by the customer."""
        runtime = self._runtime
        _client_ip = runtime._client_ip
        _ensure_request_dirs = runtime._ensure_request_dirs
        _load_status = runtime._load_status
        _public_error_message = runtime._public_error_message
        _rate_limit_allow = runtime._rate_limit_allow
        _read_json_body_limited = runtime._read_json_body_limited
        _safe_id = runtime._safe_id
        _save_status = runtime._save_status
        _sse_broadcast = runtime._sse_broadcast
        _utc_now_iso = runtime._utc_now_iso
        hmac = runtime.hmac

        _ensure_request_dirs()
        try:
            payload = _read_json_body_limited(self, 'CLIENT_LOG_MAX_BYTES', 65536)
        except Exception:
            return self._send_json({"ok": False, "error": _public_error_message(400)}, 400)

        ip = _client_ip(self)
        if not _rate_limit_allow('public_cancel_request', ip, 10, 60):
            return self._send_json({"ok": False, "error": "Too many requests"}, 429)

        request_id = str(payload.get("requestId") or "").strip()
        if not request_id:
            return self._send_json({"ok": False, "error": "Missing requestId"}, 400)
        request_id = _safe_id(request_id, 120)

        supplied_cancel_token = str(payload.get("cancelToken") or payload.get("token") or '').strip()
        if not supplied_cancel_token:
            return self._send_json({"ok": False, "error": "Forbidden"}, 403)

        status = _load_status(request_id)
        if not isinstance(status, dict):
            return self._send_json({"ok": False, "error": "Unknown requestId"}, 404)

        expected_cancel_token = ''
        try:
            cc = status.get('cancelControl') if isinstance(status.get('cancelControl'), dict) else {}
            expected_cancel_token = str(cc.get('cancelToken') or '').strip()
        except Exception:
            expected_cancel_token = ''
        if not expected_cancel_token or not hmac.compare_digest(supplied_cancel_token, expected_cancel_token):
            return self._send_json({"ok": False, "error": "Forbidden"}, 403)

        # Update status
        status["publicStatus"] = "CANCELLED"
        status["publicStatusLabel"] = "Geannuleerd door klant"
        status["needsQuote"] = False
        status["quoteStatus"] = "CANCELLED"
        # If it hasn't started processing, cancel internal as well
        if status.get("internalStatus") in ("QUEUED", "RECEIVED", None, ""):
            status["internalStatus"] = "CANCELLED"
            status["internalStatusLabel"] = "Geannuleerd"
        status["cancel"] = {
            "cancelledAt": _utc_now_iso(),
            "cancelReason": str(payload.get("reason") or "USER_CANCELLED"),
            "context": str(payload.get("context") or "PRICE_OVERLAY"),
        }
        try:
            if isinstance(status.get('cancelControl'), dict):
                status['cancelControl']['cancelledAt'] = status['cancel'].get('cancelledAt')
                status['cancelControl'].pop('cancelToken', None)
        except Exception:
            pass
        _save_status(request_id, status)

        _sse_broadcast("request_cancelled", {"requestId": request_id})
        return self._send_json({"ok": True, "requestId": request_id, "cancelled": True})

    def _api_cancel_job(self, parsed=None):
        runtime = self._runtime
        _JOB_LIFECYCLE = runtime._JOB_LIFECYCLE

        return _JOB_LIFECYCLE.api_cancel_job(self, parsed=parsed)

    def _send_text(self, text: str, code: int = 200, ctype: str = 'text/plain; charset=utf-8'):
        runtime = self._runtime
        _STATIC_HTTP = runtime._STATIC_HTTP

        return _STATIC_HTTP.send_text(self, text, code, ctype)

    def _send_json(self, obj, code: int = 200):
        runtime = self._runtime
        _STATIC_HTTP = runtime._STATIC_HTTP

        return _STATIC_HTTP.send_json(self, obj, code)

    def _stream_file(self, path: Path, *, content_type: str, download_name: str, max_bytes: int) -> None:
        runtime = self._runtime
        Path = runtime.Path
        _STATIC_HTTP = runtime._STATIC_HTTP

        return _STATIC_HTTP.stream_file(
            self, path, content_type=content_type, download_name=download_name, max_bytes=max_bytes
        )

    def _api_client_log(self, parsed=None):
        """Receive bounded client-side debug logs.

        Security policy:
        - same-origin / loopback only
        - small payloads only
        - rate-limited per client IP
        - best-effort logging with generic failures
        """
        runtime = self._runtime
        JOBS = runtime.JOBS
        STATE_ROOT = runtime.STATE_ROOT
        SafetyContractError = runtime.SafetyContractError
        _client_ip = runtime._client_ip
        _env_int = runtime._env_int
        _extract_request_token = runtime._extract_request_token
        _now_iso = runtime._now_iso
        _rate_limit_allow = runtime._rate_limit_allow
        _read_job_access_token = runtime._read_job_access_token
        _read_json_body_limited = runtime._read_json_body_limited
        _redact_sensitive_text = runtime._redact_sensitive_text
        _sanitize_log_value = runtime._sanitize_log_value
        append_jsonl_rotating = runtime.append_jsonl_rotating
        hmac = runtime.hmac
        resolve_identifier_child = runtime.resolve_identifier_child
        validate_job_id = runtime.validate_job_id

        if not self._require_same_origin_public_write():
            return
        ip = _client_ip(self)
        if not _rate_limit_allow('client_log', ip, 120, 300):
            return self._send_json({"ok": False, "error": "Te veel verzoeken. Probeer het later opnieuw."}, 429)
        try:
            payload = _read_json_body_limited(self, 'CLIENT_LOG_MAX_BYTES', 16384)
        except Exception:
            return self._send_json({"ok": False, "error": "Invalid JSON"}, 400)

        try:
            job_id = str(payload.get("jobId") or "").strip()
            if job_id:
                try:
                    job_id = validate_job_id(job_id)
                    job_root = resolve_identifier_child(JOBS, job_id)
                except SafetyContractError:
                    return self._send_json({"ok": False, "error": "Ongeldige job."}, 400)
                supplied = _extract_request_token(self, parsed=parsed, body=payload)
                expected = _read_job_access_token(job_id)
                is_admin = self._check_admin_auth_silent()
                if not is_admin and not (expected and supplied and hmac.compare_digest(expected, supplied)):
                    return self._send_json({"ok": False, "error": "Geen toegang tot deze job."}, 403)
                if not job_root.is_dir():
                    return self._send_json({"ok": False, "error": "Job niet gevonden."}, 404)
            ts = payload.get("ts") or _now_iso()
            rec = {
                "ts": ts,
                "level": str(payload.get("level") or "info")[:24],
                "event": str(payload.get("event") or "")[:120],
                "message": _redact_sensitive_text(payload.get("message") or "", 400),
                "url": _redact_sensitive_text(str(payload.get("url") or "").split("#",1)[0].split("?",1)[0], 300),
                "ua": "",
                "data": _sanitize_log_value(payload.get("data"), max_depth=1, max_items=10),
            }
            if job_id:
                path = job_root / "client_log.jsonl"
            else:
                path = STATE_ROOT / "client_logs" / "general_client_log.jsonl"
            append_jsonl_rotating(path, rec, max_bytes=max(1024, _env_int('CLIENT_LOG_QUOTA_BYTES', 10 * 1024 * 1024)), backups=3)
            return self._send_json({"ok": True})
        except Exception:
            return self._send_json({"ok": False, "error": "Log write failed"}, 500)

    def _estimate_job_complexity(self, payload: dict) -> dict:
        runtime = self._runtime
        _JOB_LIFECYCLE = runtime._JOB_LIFECYCLE

        return _JOB_LIFECYCLE.estimate_job_complexity(self, payload)

    def _start_async_job_create(self, payload: dict, master_job_id: str, public_access_token: str = '', acquired_ip: str = '') -> dict[str, Any]:
        runtime = self._runtime
        Any = runtime.Any
        _JOB_LIFECYCLE = runtime._JOB_LIFECYCLE

        return _JOB_LIFECYCLE.start_async_job_create(self, payload, master_job_id, public_access_token, acquired_ip)

    def _write_api_jobs_crashlog(self, label: str, payload: dict | None = None, err: Exception | None = None, extra: dict | None = None) -> None:
        runtime = self._runtime
        _JOB_LIFECYCLE = runtime._JOB_LIFECYCLE

        return _JOB_LIFECYCLE.write_api_jobs_crashlog(self, label, payload, err, extra)

    def _api_create_job(self):
        runtime = self._runtime
        _JOB_LIFECYCLE = runtime._JOB_LIFECYCLE

        return _JOB_LIFECYCLE.api_create_job(self)

    def _api_status(self, job_id: str, parsed=None):
        runtime = self._runtime
        _JOB_LIFECYCLE = runtime._JOB_LIFECYCLE

        return _JOB_LIFECYCLE.api_status(self, job_id, parsed=parsed)
