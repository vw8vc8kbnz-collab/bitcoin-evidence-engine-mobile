from __future__ import annotations

"""Bounded SecurityAccessRuntime implementation with explicit runtime injection."""

class SecurityAccessRuntime:
    def __init__(self, runtime):
        self._runtime = runtime

    def _direct_peer_ip(_owner, handler) -> str:
        runtime = _owner._runtime

        try:
            return str((handler.client_address or ["?"])[0] or "?").strip()
        except Exception:
            return "?"


    def _ip_matches(_owner, value: str, pattern: str) -> bool:
        runtime = _owner._runtime
        ipaddress = runtime.ipaddress

        try:
            ip = ipaddress.ip_address(str(value).strip())
            pat = str(pattern).strip()
            if "/" in pat:
                return ip in ipaddress.ip_network(pat, strict=False)
            return ip == ipaddress.ip_address(pat)
        except Exception:
            return str(value or "").strip() == str(pattern or "").strip()


    def _is_trusted_proxy_peer(_owner, handler) -> bool:
        runtime = _owner._runtime
        _direct_peer_ip = runtime._direct_peer_ip
        _ip_matches = runtime._ip_matches
        _split_env_csv = runtime._split_env_csv

        peer = _direct_peer_ip(handler)
        proxies = _split_env_csv("TRUSTED_PROXY_IPS", "127.0.0.1,::1")
        return any(_ip_matches(peer, p) for p in proxies)


    def _client_ip(_owner, handler) -> str:
        runtime = _owner._runtime
        _direct_peer_ip = runtime._direct_peer_ip
        _extract_forwarded_client_ip = runtime._extract_forwarded_client_ip
        _is_trusted_proxy_peer = runtime._is_trusted_proxy_peer

        try:
            # Only trust forwarded headers from a configured reverse proxy.
            if _is_trusted_proxy_peer(handler):
                # The production Nginx contract overwrites X-Real-IP and X-Forwarded-For
                # with $remote_addr. Prefer X-Real-IP and reject comma-separated chains.
                real = _extract_forwarded_client_ip(handler.headers.get('X-Real-IP') or '')
                if real:
                    return real
                real = _extract_forwarded_client_ip(handler.headers.get('X-Forwarded-For') or '')
                if real:
                    return real
            return _direct_peer_ip(handler)
        except Exception:
            return _direct_peer_ip(handler) or "?"


    def _is_loopback_value(_owner, value: str) -> bool:
        runtime = _owner._runtime

        v = str(value or '').strip().lower()
        return v in {'127.0.0.1', '::1', 'localhost'}


    def _is_loopback_client(_owner, handler) -> bool:
        runtime = _owner._runtime
        _client_ip = runtime._client_ip
        _is_loopback_value = runtime._is_loopback_value

        return _is_loopback_value(_client_ip(handler))


    def _rate_limit_allow(_owner, bucket: str, key: str, max_hits: int, window_sec: int) -> bool:
        runtime = _owner._runtime
        _RATE_LIMITS = runtime._RATE_LIMITS
        _RATE_LIMITS_LOCK = runtime._RATE_LIMITS_LOCK
        time = runtime.time

        now = time.time()
        kk = (str(bucket), str(key))
        with _RATE_LIMITS_LOCK:
            if len(_RATE_LIMITS) >= 10_000:
                cutoff = now - max(60.0, float(window_sec))
                for stale_key, values in list(_RATE_LIMITS.items()):
                    kept = [ts for ts in values[-max(10, int(max_hits) * 2):] if ts >= cutoff]
                    if kept:
                        _RATE_LIMITS[stale_key] = kept
                    else:
                        _RATE_LIMITS.pop(stale_key, None)
                while len(_RATE_LIMITS) >= 10_000:
                    oldest_key = min(
                        _RATE_LIMITS,
                        key=lambda item: _RATE_LIMITS[item][-1] if _RATE_LIMITS[item] else 0.0,
                    )
                    _RATE_LIMITS.pop(oldest_key, None)
            arr = [ts for ts in _RATE_LIMITS.get(kk, []) if now - ts < float(window_sec)]
            if len(arr) >= int(max_hits):
                _RATE_LIMITS[kk] = arr
                return False
            arr.append(now)
            _RATE_LIMITS[kk] = arr
            return True


    def _rate_limit_is_blocked(_owner, bucket: str, key: str, max_hits: int, window_sec: int) -> bool:
        runtime = _owner._runtime
        _RATE_LIMITS = runtime._RATE_LIMITS
        _RATE_LIMITS_LOCK = runtime._RATE_LIMITS_LOCK
        time = runtime.time

        now = time.time()
        kk = (str(bucket), str(key))
        with _RATE_LIMITS_LOCK:
            arr = [ts for ts in _RATE_LIMITS.get(kk, []) if now - ts < float(window_sec)]
            if arr:
                _RATE_LIMITS[kk] = arr
            else:
                _RATE_LIMITS.pop(kk, None)
            return len(arr) >= int(max_hits)


    def _rate_limit_record(_owner, bucket: str, key: str) -> None:
        runtime = _owner._runtime
        _RATE_LIMITS = runtime._RATE_LIMITS
        _RATE_LIMITS_LOCK = runtime._RATE_LIMITS_LOCK
        time = runtime.time

        now = time.time()
        kk = (str(bucket), str(key))
        with _RATE_LIMITS_LOCK:
            if kk not in _RATE_LIMITS and len(_RATE_LIMITS) >= 10_000:
                oldest_key = min(
                    _RATE_LIMITS,
                    key=lambda item: _RATE_LIMITS[item][-1] if _RATE_LIMITS[item] else 0.0,
                )
                _RATE_LIMITS.pop(oldest_key, None)
            arr = _RATE_LIMITS.get(kk, [])[-999:]
            arr.append(now)
            _RATE_LIMITS[kk] = arr


    def _rate_limit_clear(_owner, bucket: str, key: str) -> None:
        runtime = _owner._runtime
        _RATE_LIMITS = runtime._RATE_LIMITS
        _RATE_LIMITS_LOCK = runtime._RATE_LIMITS_LOCK

        kk = (str(bucket), str(key))
        with _RATE_LIMITS_LOCK:
            _RATE_LIMITS.pop(kk, None)


    def _normalized_admin_users(_owner, credentials: dict | None) -> list[dict[str, Any]]:
        runtime = _owner._runtime
        Any = runtime.Any
        _admin_normalized_users = runtime._admin_normalized_users

        return _admin_normalized_users(credentials)


    def _find_admin_user(_owner, credentials: dict | None, username: str) -> dict[str, Any] | None:
        runtime = _owner._runtime
        Any = runtime.Any
        _admin_find_user = runtime._admin_find_user

        return _admin_find_user(credentials, username)


    def _admin_session_create(_owner, actor: str, roles: list[str] | None = None) -> tuple[str, float]:
        runtime = _owner._runtime
        _ADMIN_SESSION_STORE = runtime._ADMIN_SESSION_STORE

        return _ADMIN_SESSION_STORE.create(actor, roles)


    def _admin_session_valid(_owner, token: str) -> bool:
        runtime = _owner._runtime
        _ADMIN_SESSION_STORE = runtime._ADMIN_SESSION_STORE

        return _ADMIN_SESSION_STORE.valid(token)


    def _admin_session_revoke(_owner, token: str) -> None:
        runtime = _owner._runtime
        _ADMIN_SESSION_STORE = runtime._ADMIN_SESSION_STORE

        _ADMIN_SESSION_STORE.revoke(token)


    def _admin_session_actor(_owner, token: str) -> str:
        runtime = _owner._runtime
        _ADMIN_SESSION_STORE = runtime._ADMIN_SESSION_STORE

        return _ADMIN_SESSION_STORE.actor(token)


    def _admin_session_roles(_owner, token: str) -> frozenset[str]:
        runtime = _owner._runtime
        _ADMIN_SESSION_STORE = runtime._ADMIN_SESSION_STORE

        return _ADMIN_SESSION_STORE.roles(token)


    def _is_password_hash_value(_owner, v: Any) -> bool:
        runtime = _owner._runtime
        Any = runtime.Any
        re = runtime.re

        try:
            raw = str(v or '')
            return bool(re.fullmatch(r'pbkdf2_sha256\$600000\$[A-Za-z0-9._-]{16,128}\$[a-f0-9]{64}', raw))
        except Exception:
            return False


    def _is_https_request(_owner, handler) -> bool:
        runtime = _owner._runtime
        _is_trusted_proxy_peer = runtime._is_trusted_proxy_peer

        try:
            if _is_trusted_proxy_peer(handler):
                xf = str(handler.headers.get('X-Forwarded-Proto') or '').strip().lower()
                if xf:
                    return xf == 'https'
        except Exception:
            pass
        try:
            return bool(getattr(handler.server, 'server_port', None) == 443)
        except Exception:
            return False


    def _is_secure_admin_transport(_owner, handler) -> bool:
        runtime = _owner._runtime
        _is_https_request = runtime._is_https_request
        _is_loopback_client = runtime._is_loopback_client

        try:
            if _is_loopback_client(handler):
                return True
        except Exception:
            pass
        return _is_https_request(handler)


    def _is_production_runtime(_owner) -> bool:
        runtime = _owner._runtime
        _is_production_hardening_enabled = runtime._is_production_hardening_enabled

        return _is_production_hardening_enabled()


    def _get_admin_credentials_file_path(_owner) -> Path:
        runtime = _owner._runtime
        Path = runtime.Path
        ROOT = runtime.ROOT
        os = runtime.os

        raw = str(os.environ.get('ADMIN_CREDENTIALS_FILE') or os.environ.get('ADMIN_CREDENTIALS_PATH') or '').strip()
        if raw:
            try:
                return Path(raw).expanduser()
            except Exception:
                pass
        credential_dir = str(os.environ.get('CREDENTIALS_DIRECTORY') or '').strip()
        if credential_dir:
            candidate = Path(credential_dir) / 'admin_credentials.live.json'
            if candidate.is_file():
                return candidate
        # FIX618: live deployments must prefer credentials outside the app directory.
        # This preserves existing VPS convention and avoids shipping real credentials in ZIPs.
        external_default = Path('/etc/adzaagt/metod-pax/admin_credentials.live.json')
        try:
            if external_default.exists():
                return external_default
        except Exception:
            pass
        return ROOT / 'config' / 'admin_credentials.json'


    def _get_admin_password_reset_activation_file_path(_owner) -> Path:
        runtime = _owner._runtime
        Path = runtime.Path
        ROOT = runtime.ROOT
        os = runtime.os

        raw = str(os.environ.get('ADMIN_PASSWORD_RESET_ACTIVATION_FILE') or os.environ.get('ADMIN_PASSWORD_RESET_ACTIVATION_PATH') or '').strip()
        if raw:
            try:
                return Path(raw).expanduser()
            except Exception:
                pass
        return ROOT / 'config' / 'admin_password_reset_activation.json'


    def _load_admin_password_reset_activation(_owner) -> dict | None:
        runtime = _owner._runtime
        _get_admin_password_reset_activation_file_path = runtime._get_admin_password_reset_activation_file_path
        strict_json_load = runtime.strict_json_load

        path = _get_admin_password_reset_activation_file_path()
        try:
            obj = strict_json_load(path)
            if isinstance(obj, dict):
                obj['_path'] = str(path)
                return obj
        except Exception:
            return None
        return None


    def _admin_password_reset_activation_is_enabled(_owner) -> bool:
        runtime = _owner._runtime
        _load_admin_password_reset_activation = runtime._load_admin_password_reset_activation

        try:
            obj = _load_admin_password_reset_activation() or {}
            return bool(obj.get('enabled'))
        except Exception:
            return False


    def _origin_allowed(_owner, origin: str, *, admin: bool = False) -> bool:
        runtime = _owner._runtime
        _is_loopback_value = runtime._is_loopback_value
        _is_production_runtime = runtime._is_production_runtime
        _split_env_csv = runtime._split_env_csv
        urlparse = runtime.urlparse

        origin = str(origin or '').strip()
        if not origin:
            return False
        extra = _split_env_csv('ALLOWED_ADMIN_ORIGINS' if admin else 'ALLOWED_ORIGINS')
        if origin in extra:
            return True
        try:
            parsed = urlparse(origin)
            host = str(parsed.hostname or '').strip().lower()
        except Exception:
            return False
        if not host:
            return False
        if _is_production_runtime():
            return False
        return _is_loopback_value(host)


    def _extract_request_token(_owner, handler, parsed=None, body: Optional[dict]=None) -> str:
        runtime = _owner._runtime
        Optional = runtime.Optional
        _helpers_extract_request_token = runtime._helpers_extract_request_token

        return _helpers_extract_request_token(handler, parsed=parsed, body=body)


    def _new_public_access_token(_owner) -> str:
        runtime = _owner._runtime
        uuid = runtime.uuid

        return uuid.uuid4().hex + uuid.uuid4().hex


    def _write_job_access_token(_owner, job_id: str, token: str) -> None:
        runtime = _owner._runtime
        JOBS = runtime.JOBS
        _atomic_write_json = runtime._atomic_write_json
        _utc_now_iso = runtime._utc_now_iso
        resolve_identifier_child = runtime.resolve_identifier_child
        validate_job_id = runtime.validate_job_id

        try:
            job_root = resolve_identifier_child(JOBS, validate_job_id(job_id))
            if not job_root.exists():
                return
            _atomic_write_json(job_root / '.public_access.json', {'token': str(token), 'jobId': str(job_id), 'updatedAt': _utc_now_iso()})
        except Exception:
            pass


    def _read_job_access_token(_owner, job_id: str) -> str:
        runtime = _owner._runtime
        JOBS = runtime.JOBS
        resolve_identifier_child = runtime.resolve_identifier_child
        strict_json_load = runtime.strict_json_load
        validate_job_id = runtime.validate_job_id

        try:
            job_root = resolve_identifier_child(JOBS, validate_job_id(job_id))
            path = job_root / '.public_access.json'
            if not path.exists():
                return ''
            data = strict_json_load(path)
            return str(data.get('token') or '').strip()
        except Exception:
            return ''

    EXPORTS = ('_direct_peer_ip', '_ip_matches', '_is_trusted_proxy_peer', '_client_ip', '_is_loopback_value', '_is_loopback_client', '_rate_limit_allow', '_rate_limit_is_blocked', '_rate_limit_record', '_rate_limit_clear', '_normalized_admin_users', '_find_admin_user', '_admin_session_create', '_admin_session_valid', '_admin_session_revoke', '_admin_session_actor', '_admin_session_roles', '_is_password_hash_value', '_is_https_request', '_is_secure_admin_transport', '_is_production_runtime', '_get_admin_credentials_file_path', '_get_admin_password_reset_activation_file_path', '_load_admin_password_reset_activation', '_admin_password_reset_activation_is_enabled', '_origin_allowed', '_extract_request_token', '_new_public_access_token', '_write_job_access_token', '_read_job_access_token')

__all__ = ("SecurityAccessRuntime",)
