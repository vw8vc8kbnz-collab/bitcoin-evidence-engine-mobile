from __future__ import annotations

"""Pure parsing for security-relevant request header values.

This module deliberately contains no trust, authentication or authorization
decisions. The caller remains responsible for deciding whether a proxy header,
bearer capability or session cookie may be used.
"""

import ipaddress


def extract_forwarded_client_ip(raw: str) -> str:
    """Accept one proxy-normalized client IP, never a client-supplied chain."""

    candidate = str(raw or "").strip()
    if not candidate or "," in candidate:
        return ""
    if candidate.startswith("[") and "]" in candidate:
        candidate = candidate[1:candidate.index("]")]
    try:
        return str(ipaddress.ip_address(candidate))
    except Exception:
        return ""


def extract_bearer_token(authorization_header: str) -> str:
    raw = str(authorization_header or "").strip()
    if raw.lower().startswith("bearer "):
        return raw.split(" ", 1)[1].strip()
    return ""


def extract_admin_session_cookie(cookie_header: str) -> str:
    try:
        raw = str(cookie_header or "")
        for part in raw.split(";"):
            if "=" not in part:
                continue
            key, value = part.split("=", 1)
            if key.strip() == "adzaagt_admin_session":
                return value.strip()
    except Exception:
        pass
    return ""


__all__ = (
    "extract_admin_session_cookie",
    "extract_bearer_token",
    "extract_forwarded_client_ip",
)
