"""Pure security primitives for the R9 modularization line."""

