from __future__ import annotations

"""Stateless password and TOTP primitives.

This module owns only hashing and code verification. Credential lookup,
account policy, roles, rate limiting, sessions and HTTP decisions remain with
their existing callers.
"""

import base64
import hashlib
import hmac
import re
import secrets
import time
from typing import Optional


PBKDF2_ITERATIONS = 600_000
PBKDF2_LEGACY_ITERATIONS = frozenset({260_000})


def pbkdf2_hash_password(
    password: str,
    *,
    iterations: int = PBKDF2_ITERATIONS,
    salt: Optional[str] = None,
) -> str:
    salt = salt or secrets.token_hex(16)
    derived = hashlib.pbkdf2_hmac(
        "sha256",
        str(password).encode("utf-8"),
        str(salt).encode("utf-8"),
        int(iterations),
    )
    return f"pbkdf2_sha256${int(iterations)}${salt}${derived.hex()}"


def verify_password_against_stored(password: str, stored: str) -> bool:
    try:
        raw = str(stored or "")
        if not raw:
            return False
        if raw.startswith("pbkdf2_sha256$"):
            parts = raw.split("$", 3)
            if len(parts) != 4:
                return False
            _, iteration_text, salt, expected = parts
            iterations = int(iteration_text)
            if iterations not in ({PBKDF2_ITERATIONS} | PBKDF2_LEGACY_ITERATIONS):
                return False
            if not re.fullmatch(r"[A-Za-z0-9._-]{16,128}", salt):
                return False
            if not re.fullmatch(r"[a-f0-9]{64}", expected):
                return False
            calculated = pbkdf2_hash_password(
                password,
                iterations=iterations,
                salt=salt,
            )
            return hmac.compare_digest(calculated, raw)
        # Plaintext and unknown credential formats are never accepted. Legacy
        # PBKDF2 hashes remain verifiable only to support an explicit migration;
        # the production validator requires the current work factor.
        return False
    except Exception:
        return False


def totp_code(secret: str, counter: int, digits: int = 6) -> str:
    normalized = re.sub(r"\s+", "", str(secret or "")).upper()
    padded = normalized + ("=" * ((8 - len(normalized) % 8) % 8))
    key = base64.b32decode(padded, casefold=True)
    digest = hmac.new(
        key,
        int(counter).to_bytes(8, "big"),
        hashlib.sha1,
    ).digest()
    offset = digest[-1] & 0x0F
    binary = int.from_bytes(digest[offset:offset + 4], "big") & 0x7FFFFFFF
    return str(binary % (10 ** digits)).zfill(digits)


def verify_totp(secret: str, supplied: str, now: float | None = None) -> bool:
    value = re.sub(r"\s+", "", str(supplied or ""))
    if not re.fullmatch(r"\d{6}", value):
        return False
    try:
        counter = int((time.time() if now is None else float(now)) // 30)
        return any(
            hmac.compare_digest(totp_code(secret, counter + offset), value)
            for offset in (-1, 0, 1)
        )
    except Exception:
        return False


__all__ = (
    "PBKDF2_ITERATIONS",
    "PBKDF2_LEGACY_ITERATIONS",
    "pbkdf2_hash_password",
    "totp_code",
    "verify_password_against_stored",
    "verify_totp",
)
