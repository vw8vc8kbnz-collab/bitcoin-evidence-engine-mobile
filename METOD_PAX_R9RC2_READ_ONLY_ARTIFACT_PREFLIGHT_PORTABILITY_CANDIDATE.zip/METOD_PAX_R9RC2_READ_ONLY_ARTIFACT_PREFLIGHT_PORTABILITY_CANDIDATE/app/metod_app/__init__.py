"""METOD/PAX R9 application package.

R9 modules are introduced one owner at a time. Importing this package has no
runtime side effects; process-context composition lives in
``metod_app.application`` and public job lifecycle facades live in
``metod_app.jobs.lifecycle``. The HTTP and process boundaries remain in the
composition root.
"""

__all__: tuple[str, ...] = ()
