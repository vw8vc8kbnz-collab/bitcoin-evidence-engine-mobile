(function(){
  const w = window;

  function currentStep(){
    try{
      const step = String(w.__metod_uiStep || w.document?.body?.dataset?.uiStep || 'material');
      return step || 'material';
    }catch(_){ return 'material'; }
  }

  function safeFooter(step){
    try{
      if(w.ToolAEntry && typeof w.ToolAEntry.safeRenderFooter === 'function'){
        return w.ToolAEntry.safeRenderFooter(step || currentStep());
      }
      if(typeof w.renderFooterForStep === 'function'){
        return w.renderFooterForStep(step || currentStep());
      }
    }catch(err){
      console.warn('ToolARouteFooter call failed', err);
    }
    return null;
  }

  const api = {
    version: 'FIX308_TOOLA_ROUTE_FOOTER_HELPERS_PHASE7',
    currentStep,
    renderCurrentFooter(){ return safeFooter(currentStep()); },
    renderPanelsFooter(){ return safeFooter('panels'); },
    renderFooterFor(step){ return safeFooter(step); },
    getFooterDecision(step){
      try{
        if(toolAFoundation && typeof toolAFoundation.getFooterDecision === 'function'){
          const snapshot = w.ToolACoreSelectors?.getWizardSnapshot?.() || null;
          return toolAFoundation.getFooterDecision(step || currentStep(), snapshot);
        }
      }catch(err){
        console.warn('ToolARouteFooter decision call failed', err);
      }
      return null;
    },
    ensurePanelsUi(){
      try{
        if(currentStep() !== 'panels') return;
        if(w.panelDockLauncher) w.panelDockLauncher.style.display = 'inline-flex';
        if(w.panelDock && Array.isArray(w.state?.cart) && !w.state.cart.length && !(Array.isArray(w.state?.extraPanels) && w.state.extraPanels.length)){
          if(typeof w.setPanelDockOpen === 'function') w.setPanelDockOpen(false);
        }
      }catch(_){ }
    }
  };

  w.ToolARouteFooter = api;
  w.__ToolARouteFooterVersion = api.version;
})();
