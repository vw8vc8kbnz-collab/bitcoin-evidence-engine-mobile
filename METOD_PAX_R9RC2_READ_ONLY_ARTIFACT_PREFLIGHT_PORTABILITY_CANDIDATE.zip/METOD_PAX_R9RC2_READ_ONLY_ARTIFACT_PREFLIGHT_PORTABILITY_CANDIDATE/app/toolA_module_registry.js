(function(){
  const g = window;
  const registry = g.ToolAModuleRegistry || {
    loadedAt: new Date().toISOString(),
    modules: {},
    order: [],
    register(name, details){
      if (!name) return;
      this.modules[name] = Object.assign({ loaded: true }, details || {});
      this.order.push(name);
    },
    getReport(){
      return {
        loadedAt: this.loadedAt,
        order: this.order.slice(),
        modules: Object.assign({}, this.modules)
      };
    },
    printReport(){
      console.log('[ToolA Module Registry]', this.getReport());
      return this.getReport();
    }
  };
  g.ToolAModuleRegistry = registry;
  registry.register('ToolAModuleRegistry', { role: 'runtime metadata / load-order aid' });
  registry.register('ToolAValidators', { role: 'pure validators / normalizers / input safety rules' });
  registry.register('ToolACoreSelectors', { role: 'core selector layer / read-only snapshots' });
  registry.register('ToolAPanelEditContext', { role: 'step-2 edit context / read-only selectors + labels' });
  registry.register('ToolAPanelFormState', { role: 'panel form prefill/reset decisions / read-only snapshots' });
  registry.register('ToolAPanelFormApply', { role: 'panel form apply / live prefill + reset application around panel form state snapshots' });
  registry.register('ToolATypeSizeDecisions', { role: 'step-2 type/size decisions / pure defaults + grouping + ui state' });
  registry.register('ToolAExtraPanelViewState', { role: 'extra-panel overlay display/read layer / pure options + preview snapshots' });
  registry.register('ToolAExtraPanelMutations', { role: 'extra-panel overlay mutation adapter / normalized prefill + reset + upsert plan' });
  registry.register('ToolAExtraPanelFormApply', { role: 'extra-panel form apply / live prefill + reset application around extra-panel form snapshots' });
  registry.register('ToolAExtraPanelSubmitFlow', { role: 'extra-panel submit flow / validation + mutation + post-submit planning' });
  registry.register('ToolAPanelMutations', { role: 'standard-panel mutation adapter / normalized item + upsert plan' });
  registry.register('ToolAPanelSubmitFlow', { role: 'standard-panel submit flow / submit plan + post-submit actions' });
  registry.register('ToolAPanelBootstrapMutations', { role: 'panel bootstrap/reset mutation adapter / normalized bootstrap + empty-material reset plans' });
  registry.register('ToolAMaterialBatchMutations', { role: 'material batch mutation adapter / remove-material cleanup + active-material fallback planning' });
  registry.register('ToolACustomerValidation', { role: 'customer validation / required-field decision layer' });
  registry.register('ToolAGrainValidation', { role: 'grain validation / pure grain-set drop + fit + alert decisions' });
  registry.register('ToolAPanelsViewModels', { role: 'step-2 display layer / pure panels view models' });
  registry.register('ToolAPanelRowViewModels', { role: 'panel dock row display layer / pure row text + editing badges' });
  registry.register('ToolACoreReadHelpers', { role: 'mini core candidate / read-only selectors' });
  registry.register('ToolARouteFooter', { role: 'core-adapter / footer helper surface' });
})();

;try{ window.ToolAModuleRegistry && window.ToolAModuleRegistry.register && window.ToolAModuleRegistry.register('ToolAPanelDockState', window.ToolAPanelDockState); }catch(_){ }

;try{ window.ToolAModuleRegistry && window.ToolAModuleRegistry.register && window.ToolAModuleRegistry.register('ToolAPanelUiState', { role: 'panel ui state / pure control + custom label decisions' }); }catch(_){ }

;try{ window.ToolAModuleRegistry && window.ToolAModuleRegistry.register && window.ToolAModuleRegistry.register('ToolAPanelControlsApply', { role: 'panel controls apply / live disabled-state application around existing panel ui decisions' }); }catch(_){ }

;try{ window.ToolAModuleRegistry && window.ToolAModuleRegistry.register && window.ToolAModuleRegistry.register('ToolARouteState', { role: 'route state / pure step normalization + prev/next/stepbar decisions' }); }catch(_){ }

;try{ window.ToolAModuleRegistry && window.ToolAModuleRegistry.register && window.ToolAModuleRegistry.register('ToolAPanelBootstrapApply', { role: 'panel bootstrap apply / live bootstrap + no-material reset application around existing bootstrap mutation plans' }); }catch(_){ }
