#!/usr/bin/env python3
from __future__ import annotations

"""Stable executable/import boundary for the METOD/PAX application.

Business, HTTP, job and storage owners live in ``metod_app``. Importers from
older operational tools receive the packaged runtime module itself, preserving
their patch/instrumentation behavior without duplicating an API facade here.
"""

import sys

from metod_app.runtime import application as _application


if __name__ == "__main__":
    if "--worker" in sys.argv:
        _application.run_worker()
    else:
        _application.main()
else:
    sys.modules[__name__] = _application
