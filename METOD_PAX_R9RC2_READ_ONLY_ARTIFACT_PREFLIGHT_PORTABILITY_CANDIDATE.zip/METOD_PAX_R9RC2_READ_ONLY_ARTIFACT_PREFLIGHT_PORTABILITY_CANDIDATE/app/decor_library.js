(function(){
  'use strict';
  window.__TOOLA_DECOR_LIBRARY_BUILD='FIX660R8Y_WOOD_VENEER_LABEL';

  const INITIAL_VISIBLE = 16;
  const CHUNK_SIZE = 24;

  const UI = {
    filter: 'all',
    brand: '',
    color: '',
    search: '',
    searchText: '',
    visible: INITIAL_VISIBLE,
    indexVersion: '',
    indexedRows: [],
    initialized: false,
    sheetOpen: false,
    sheetTouchStartY: null,
    infiniteObserver: null,
    scrollFallbackBound: false,
  };

  function esc(value){
    return String(value == null ? '' : value)
      .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  }
  function catalog(){ return Array.isArray(window.MATERIAL_CATALOG) ? window.MATERIAL_CATALOG : []; }
  function keyOf(m){ return String(m?.publicMaterialId || m?.articleNumber || m?.materialCode || '').trim(); }
  function nameOf(m){ return String(m?.publicName || m?.displayName || m?.productName || m?.decorName || 'Decor').trim(); }
  function brandOf(m){ return String(m?.brand || 'Overig').trim() || 'Overig'; }
  function typeOf(m){ return String(m?.decorType || m?.categoryName || 'Overig').trim() || 'Overig'; }
  function colorOf(m){ return String(m?.colorGroup || 'Overig').trim() || 'Overig'; }
  function familyOf(m){ return String(m?.primaryVisualFamily || m?.visualFamily || m?.decorType || 'Onbekend').trim() || 'Onbekend'; }
  function searchTagsOf(m){ return Array.isArray(m?.searchTags) ? m.searchTags.map(x=>String(x||'').trim()).filter(Boolean) : []; }
  function visualTagsOf(m){ const tags=Array.isArray(m?.visualTags)?m.visualTags:[]; return Array.from(new Set([familyOf(m),...tags].map(x=>String(x||'').trim()).filter(Boolean))); }
  function r9MaterialsView(){
    try{
      const view = toolAFoundation?.getMaterialsView?.();
      return view && typeof view === 'object' ? view : null;
    }catch(_){ return null; }
  }
  function selectedKey(){
    const view = r9MaterialsView();
    return String(view ? view.activeMaterialKey : (window.state?.activeMaterialKey || '')).trim();
  }
  function selectedMaterialCount(){
    const view = r9MaterialsView();
    if(view && Number.isSafeInteger(view.selectedMaterialCount) && view.selectedMaterialCount >= 0) return view.selectedMaterialCount;
    return Array.isArray(window.state?.materialBatches) ? window.state.materialBatches.length : 0;
  }
  function activeMaterial(){ return window.state?.material || null; }
  function isMobile(){ return !!(window.matchMedia && window.matchMedia('(max-width:700px)').matches); }
  function isMaterialStep(){
    const view = r9MaterialsView();
    if(view && typeof view.isMaterialStep === 'boolean') return view.isMaterialStep;
    const step = String(document.body?.dataset?.uiStep || '').toLowerCase();
    return step === 'material' || step === 'materials';
  }
  function typeBucket(m){
    // FIX658: hoofdfilters zijn uitsluitend gebaseerd op één geverifieerde primaire familie.
    // Zoekwoorden/secondary tags mogen een product nooit meer in een tweede hoofdfilter duwen.
    const family = familyOf(m).toLowerCase();
    if(family === 'hout') return 'wood';
    if(family === 'uni') return 'uni';
    if(family === 'steen & beton' || family === 'steen' || family === 'beton') return 'stone';
    if(family === 'metaal') return 'metal';
    if(family === 'textiel & leer' || family === 'textiel') return 'textile';
    if(family === 'grafisch') return 'graphic';
    if(family === 'fantasie') return 'fantasy';
    return 'other';
  }
  function displayBrandOf(m){
    const brand = brandOf(m);
    // R8Y: the CSV records in Hout/Overig are veneered boards. Keep the
    // authoritative internal value for state/filtering, and rename only the UI.
    return typeBucket(m) === 'wood' && brand.toLowerCase() === 'overig' ? 'Fineer' : brand;
  }
  function displayBrandFilterValue(value){
    const brand = String(value || '').trim();
    return UI.filter === 'wood' && brand.toLowerCase() === 'overig' ? 'Fineer' : brand;
  }
  function typeLabel(m){
    return ({wood:'Hout',uni:'Uni',stone:'Steen & beton',metal:'Metaal',textile:'Textiel & leer',graphic:'Grafisch',fantasy:'Fantasie',other:'Decor'})[typeBucket(m)] || 'Decor';
  }
  function substrateLabel(m){
    const explicit=String(m?.substrateLabel||'').trim();
    if(explicit) return explicit;
    return ({MDF:'MDF',SPAANPLAAT:'Spaanplaat',MULTIPLEX:'Multiplex',OVERIG:'Overig',ONBEKEND:'Onbekend'})[String(m?.substrateType||'').toUpperCase()] || 'Onbekend';
  }
  function sheetSizeLabel(m){
    const w=Number(m?.sheetSizeMm?.width), h=Number(m?.sheetSizeMm?.height);
    if(!(w>0)||!(h>0)) return '';
    const fmt=n=>Number.isInteger(n)?String(n):String(Math.round(n*10)/10).replace('.',',');
    return `${fmt(h)} × ${fmt(w)} mm`;
  }
  function activeBatch(){
    const key = selectedKey();
    return (window.state?.materialBatches || []).find(x=>String(x?.key||'') === key) || null;
  }
  function grainIsOn(){
    const batch = activeBatch();
    if(batch && typeof batch.grainEnabled === 'boolean') return batch.grainEnabled;
    if(typeof window.state?.grainEnabled === 'boolean') return window.state.grainEnabled;
    const m = activeMaterial();
    if(m?.hasGrain === false) return false;
    return m?.grainDefaultOn !== false;
  }
  function thicknessLabel(m){
    const t = Number(m?.thicknessMm);
    return Number.isFinite(t) ? `${String(t).replace('.0','')} mm` : '';
  }
  function thumbHtml(m, cls, preferPreview, priority){
    const src = String((preferPreview ? m?.imagePreviewUrl : m?.imageThumbUrl) || m?.imageThumbUrl || '').trim();
    if(src){
      const eager = priority === true;
      return `<img src="${esc(src)}" alt="${esc(nameOf(m))}" data-decor-image-type="${esc(typeBucket(m))}" loading="${eager?'eager':'lazy'}" decoding="async"${eager?' fetchpriority="high"':''}>`;
    }
    return `<div class="decorPlaceholder ${cls||''}" data-type="${esc(typeBucket(m))}" aria-hidden="true">${typeBucket(m)==='wood'?'▥':typeBucket(m)==='stone'?'◫':typeBucket(m)==='metal'?'▦':'○'}</div>`;
  }

  function ensureStyle(){ return true; }

  function restoreMobileMaterialLibraryShell(){
    try{
      const left = document.querySelector('.left');
      const right = document.querySelector('.right');
      if(!left) return;
      const mobileMaterial = isMobile() && isMaterialStep();
      const leftProps = ['display','visibility','opacity','position','width','height','min-height','max-height','margin','padding','overflow','pointer-events'];
      const hideTarget = (el,key)=>{
        if(!el) return;
        if(el.dataset[key] !== '1'){
          el.dataset[key] = '1';
          el.dataset[`${key}PrevDisplay`] = el.style.getPropertyValue('display') || '';
          el.dataset[`${key}PrevDisplayPriority`] = el.style.getPropertyPriority('display') || '';
        }
        if(el.style.getPropertyValue('display') !== 'none' || el.style.getPropertyPriority('display') !== 'important') el.style.setProperty('display','none','important');
      };
      const restoreTarget = (el,key)=>{
        if(!el || el.dataset[key] !== '1') return;
        const value = el.dataset[`${key}PrevDisplay`] || '';
        const priority = el.dataset[`${key}PrevDisplayPriority`] || '';
        if(value) el.style.setProperty('display',value,priority); else el.style.removeProperty('display');
        delete el.dataset[key];
        delete el.dataset[`${key}PrevDisplay`];
        delete el.dataset[`${key}PrevDisplayPriority`];
      };
      if(!mobileMaterial){
        if(left.dataset.decorLibraryShellOverride === '1'){
          leftProps.forEach(prop=>left.style.removeProperty(prop));
          delete left.dataset.decorLibraryShellOverride;
        }
        restoreTarget(right,'decorLibraryRightHidden');
        if(!isMaterialStep()) closeMobileSheet(false);
        return;
      }
      left.dataset.decorLibraryShellOverride = '1';
      left.style.setProperty('display','block','important');
      left.style.setProperty('visibility','visible','important');
      left.style.setProperty('opacity','1','important');
      left.style.setProperty('position','relative','important');
      left.style.setProperty('width','calc(100vw - 16px)','important');
      left.style.setProperty('height','auto','important');
      left.style.setProperty('min-height','0','important');
      left.style.setProperty('max-height','none','important');
      left.style.setProperty('margin','0 auto','important');
      left.style.setProperty('padding','0','important');
      left.style.setProperty('overflow','hidden','important');
      left.style.setProperty('pointer-events','auto','important');
      hideTarget(right,'decorLibraryRightHidden');
    }catch(_){ }
  }

  function ensureMobileSelectionUi(){
    if(document.getElementById('decorMobileSticky') && document.getElementById('decorMobileSheetBackdrop')) return;

    const sticky = document.createElement('div');
    sticky.id = 'decorMobileSticky';
    sticky.setAttribute('aria-hidden','true');
    sticky.innerHTML = `
      <button type="button" class="decorMobileStickyInfo" id="decorMobileStickyOpen" aria-label="Open materiaalinstellingen">
        <span class="decorMobileStickyThumb" id="decorMobileStickyThumb"></span>
        <span><span class="decorMobileStickyName" id="decorMobileStickyName"></span><span class="decorMobileStickyMeta" id="decorMobileStickyMeta"></span></span>
      </button>
      <button type="button" class="decorMobileStickyNext" id="decorMobileStickyNext">Verder&nbsp; →</button>`;
    document.body.appendChild(sticky);

    const backdrop = document.createElement('div');
    backdrop.id = 'decorMobileSheetBackdrop';
    backdrop.setAttribute('aria-hidden','true');
    backdrop.innerHTML = `
      <section id="decorMobileSheet" role="dialog" aria-modal="true" aria-labelledby="decorMobileSheetTitle">
        <button type="button" class="decorSheetHandle" id="decorSheetHandle" aria-label="Sleep omlaag om te sluiten"></button>
        <button type="button" class="decorSheetClose" id="decorSheetClose" aria-label="Sluiten">×</button>
        <div class="decorSheetMain">
          <div class="decorSheetMedia" id="decorSheetMedia"></div>
          <div>
            <div class="decorSheetBrand" id="decorSheetBrand"></div>
            <h2 class="decorSheetName" id="decorMobileSheetTitle"></h2>
            <div class="decorSheetTags" id="decorSheetTags"></div>
          </div>
        </div>
        <div class="decorSheetChoiceLabel">Nerfrichting</div>
        <div class="decorSheetChoice" role="group" aria-label="Nerfrichting">
          <button type="button" class="decorSheetChoiceBtn" id="decorSheetGrainOn" data-grain-choice="on">Nerf aan<small>Niet roteren</small></button>
          <button type="button" class="decorSheetChoiceBtn" id="decorSheetGrainOff" data-grain-choice="off">Nerf uit<small>Vrij roteren</small></button>
        </div>
        <div class="decorSheetActions">
          <button type="button" class="decorSheetAction decorSheetAddMore" id="decorSheetAddMore">Nog een materiaal toevoegen</button>
          <button type="button" class="decorSheetAction decorSheetGoPanels" id="decorSheetGoPanels">Naar panelen&nbsp; →</button>
        </div>
      </section>`;
    document.body.appendChild(backdrop);

    document.getElementById('decorMobileStickyOpen')?.addEventListener('click',openMobileSheet);
    document.getElementById('decorMobileStickyNext')?.addEventListener('click',()=>goToPanels());
    document.getElementById('decorSheetClose')?.addEventListener('click',()=>closeMobileSheet(true));
    document.getElementById('decorSheetGrainOn')?.addEventListener('click',()=>setGrainForActive(true));
    document.getElementById('decorSheetGrainOff')?.addEventListener('click',()=>setGrainForActive(false));
    document.getElementById('decorSheetAddMore')?.addEventListener('click',()=>{
      closeMobileSheet(true);
      setTimeout(()=>focusDecorLibrary(),80);
    });
    document.getElementById('decorSheetGoPanels')?.addEventListener('click',()=>goToPanels());
    backdrop.addEventListener('click',ev=>{ if(ev.target === backdrop) closeMobileSheet(true); });

    const handle = document.getElementById('decorSheetHandle');
    const sheet = document.getElementById('decorMobileSheet');
    if(handle && sheet){
      handle.addEventListener('pointerdown',ev=>{
        UI.sheetTouchStartY = ev.clientY;
        try{ handle.setPointerCapture(ev.pointerId); }catch(_){ }
      });
      handle.addEventListener('pointermove',ev=>{
        if(UI.sheetTouchStartY == null) return;
        const dy = Math.max(0, ev.clientY - UI.sheetTouchStartY);
        sheet.style.transform = `translateY(${Math.min(180,dy)}px)`;
      });
      const finish = ev=>{
        if(UI.sheetTouchStartY == null) return;
        const dy = Math.max(0, ev.clientY - UI.sheetTouchStartY);
        UI.sheetTouchStartY = null;
        sheet.style.transform = '';
        if(dy > 80) closeMobileSheet(true);
      };
      handle.addEventListener('pointerup',finish);
      handle.addEventListener('pointercancel',()=>{ UI.sheetTouchStartY = null; sheet.style.transform=''; });
    }

    document.addEventListener('keydown',ev=>{ if(ev.key === 'Escape' && UI.sheetOpen) closeMobileSheet(true); });
  }

  function lockBodyForSheet(){
    try{
      if(document.body.dataset.decorSheetLocked === '1') return;
      const y = window.scrollY || 0;
      document.body.dataset.decorSheetLocked = '1';
      document.body.dataset.decorSheetScrollY = String(y);
      document.body.dataset.decorSheetPrevPosition = document.body.style.position || '';
      document.body.dataset.decorSheetPrevTop = document.body.style.top || '';
      document.body.dataset.decorSheetPrevWidth = document.body.style.width || '';
      document.body.style.position = 'fixed';
      document.body.style.top = `-${y}px`;
      document.body.style.width = '100%';
    }catch(_){ }
  }
  function unlockBodyForSheet(restoreScroll){
    try{
      if(document.body.dataset.decorSheetLocked !== '1') return;
      const y = Number(document.body.dataset.decorSheetScrollY || 0) || 0;
      document.body.style.position = document.body.dataset.decorSheetPrevPosition || '';
      document.body.style.top = document.body.dataset.decorSheetPrevTop || '';
      document.body.style.width = document.body.dataset.decorSheetPrevWidth || '';
      delete document.body.dataset.decorSheetLocked;
      delete document.body.dataset.decorSheetScrollY;
      delete document.body.dataset.decorSheetPrevPosition;
      delete document.body.dataset.decorSheetPrevTop;
      delete document.body.dataset.decorSheetPrevWidth;
      if(restoreScroll !== false) window.scrollTo(0,y);
    }catch(_){ }
  }

  function openMobileSheet(){
    ensureMobileSelectionUi();
    if(!isMobile() || !isMaterialStep() || !activeMaterial()) return;
    const backdrop = document.getElementById('decorMobileSheetBackdrop');
    if(!backdrop) return;
    UI.sheetOpen = true;
    renderMobileSelection();
    backdrop.classList.add('is-open');
    backdrop.setAttribute('aria-hidden','false');
    document.body.dataset.decorSheetOpen = '1';
    lockBodyForSheet();
    setTimeout(()=>{ try{ document.getElementById('decorSheetClose')?.focus({preventScroll:true}); }catch(_){ } },40);
  }
  function closeMobileSheet(restoreScroll){
    const backdrop = document.getElementById('decorMobileSheetBackdrop');
    if(backdrop){ backdrop.classList.remove('is-open'); backdrop.setAttribute('aria-hidden','true'); }
    UI.sheetOpen = false;
    delete document.body?.dataset?.decorSheetOpen;
    unlockBodyForSheet(restoreScroll !== false);
    try{ renderMobileSelection(); }catch(_){ }
  }

  function findExistingGrainButton(key, next){
    const groups = Array.from(document.querySelectorAll('.grainChoice[data-gkey]'));
    const group = groups.find(el=>String(el.getAttribute('data-gkey')||'') === String(key||''));
    return group?.querySelector(`.grainChoiceBtn[data-gval="${next?'on':'off'}"]`) || null;
  }
  function setGrainForActive(next){
    try{
      const key = selectedKey();
      if(!key) return;
      const existing = findExistingGrainButton(key,next);
      if(existing){
        existing.click();
      }else{
        const batch = activeBatch();
        if(batch) batch.grainEnabled = !!next;
        if(window.state) window.state.grainEnabled = !!next;
      }
      setTimeout(()=>{ renderMobileSelection(); renderSelected(); },0);
    }catch(_){ }
  }

  function goToPanels(){
    closeMobileSheet(false);
    try{
      if(typeof window.__showWizardStep === 'function') window.__showWizardStep('panels');
      else if(typeof window.showStep === 'function') window.showStep('panels');
    }catch(_){ }
  }

  function focusDecorLibrary(){
    try{
      const panel = document.getElementById('decorLibraryPanel');
      if(isMobile()){
        const selected = document.querySelector('.decorCard.is-selected');
        selected?.scrollIntoView({block:'center',behavior:'smooth'});
      }else{
        panel?.scrollTo({top:0,behavior:'smooth'});
        panel?.classList.add('decorLibraryAttention');
        setTimeout(()=>panel?.classList.remove('decorLibraryAttention'),500);
      }
    }catch(_){ }
  }

  function materialBatches(){ return Array.isArray(window.state?.materialBatches) ? window.state.materialBatches : []; }

  function desktopBatchRowsHtml(){
    const active = selectedKey();
    return materialBatches().map(batch=>{
      const m = batch?.mat || {};
      const key = String(batch?.key || keyOf(m));
      return `<div class="decorDesktopBatchRow${key===active?' is-active':''}" data-desktop-batch-key="${esc(key)}" role="button" tabindex="0">
        <span class="decorDesktopBatchThumb">${thumbHtml(m,'',false)}</span>
        <span class="decorDesktopBatchName">${esc(nameOf(m))}</span>
        <button type="button" class="decorDesktopBatchRemove" data-desktop-remove-key="${esc(key)}" aria-label="Verwijder ${esc(nameOf(m))}">×</button>
      </div>`;
    }).join('');
  }

  function bindDesktopSelectionEvents(){
    document.getElementById('decorDesktopGrainOn')?.addEventListener('click',()=>setGrainForActive(true));
    document.getElementById('decorDesktopGrainOff')?.addEventListener('click',()=>setGrainForActive(false));
    document.getElementById('decorDesktopAddMore')?.addEventListener('click',focusDecorLibrary);
    document.getElementById('decorDesktopGoPanels')?.addEventListener('click',goToPanels);
    document.querySelectorAll('[data-desktop-batch-key]').forEach(row=>{
      const activate=()=>{
        const key=String(row.getAttribute('data-desktop-batch-key')||'');
        if(key && typeof window.__setActiveMaterial==='function'){
          window.__setActiveMaterial(key);
          try{ document.dispatchEvent(new CustomEvent('adzaagt-material-selection-updated')); }catch(_){ }
          render();
        }
      };
      row.addEventListener('click',ev=>{ if(ev.target.closest('[data-desktop-remove-key]')) return; activate(); });
      row.addEventListener('keydown',ev=>{ if(ev.key==='Enter'||ev.key===' '){ev.preventDefault();activate();} });
    });
    document.querySelectorAll('[data-desktop-remove-key]').forEach(btn=>btn.addEventListener('click',ev=>{
      ev.preventDefault();ev.stopPropagation();
      const key=String(btn.getAttribute('data-desktop-remove-key')||'');
      if(key && typeof window.removeMaterialBatch==='function'){
        window.removeMaterialBatch(key);
        setTimeout(render,0);
      }
    }));
  }

  function bindMaterialCardOwner(panel, gridEl){
    const owner = toolAFoundation;
    if(!owner || typeof owner.bindMaterialCardGrid !== 'function'){
      if(!document.__materialCardOwnerReadyBound){
        document.__materialCardOwnerReadyBound = true;
        document.addEventListener('tool-a-material-card-owner-ready',()=>{
          try{
            const currentPanel=document.getElementById('decorLibraryPanel');
            bindMaterialCardOwner(currentPanel,currentPanel?.querySelector?.('#decorGrid'));
            render();
          }catch(_){ }
        },{once:true});
      }
      return false;
    }
    return owner.bindMaterialCardGrid({
      grid:gridEl,
      fallbackRoot:panel,
      getCatalog:catalog,
      getSelectedKey:selectedKey,
      onSelect:(mat,meta)=>{
        if(!mat || typeof window.setMaterial !== 'function') return;
        window.setMaterial(mat);
        syncSearchInputs(UI.searchText);
        render();
        /* The multi-material cart is the sole mobile owner once loaded. The
           legacy single-material sheet otherwise opens over the new footer
           and intercepts its first tap. */
        if(isMobile() && !toolAFoundation?.renderMobileMaterialCart) setTimeout(()=>openMobileSheet(),meta?.wasSelected?0:90);
        else { try{ document.getElementById('decorSelectedSummary')?.scrollIntoView({block:'nearest',behavior:'smooth'}); }catch(_){ } }
      }
    });
  }

  function ensureUi(){
    restoreMobileMaterialLibraryShell();
    ensureStyle();
    ensureMobileSelectionUi();
    if(UI.initialized) return;
    const left = document.querySelector('.left');
    const leftHeader = left?.querySelector('.leftHeader');
    const stepMaterial = document.getElementById('stepMaterial');
    if(!left || !leftHeader || !stepMaterial) return;

    let panel = document.getElementById('decorLibraryPanel');
    if(!panel){
      panel = document.createElement('section');
      panel.id = 'decorLibraryPanel';
      panel.setAttribute('aria-label','Decorbibliotheek');
      panel.innerHTML = `
        <div class="decorLibraryHead"><div><div class="decorMobileStepBadge">Stap 1 van 5</div><h2 class="decorLibraryTitle">Kies jouw decor</h2><p class="decorLibrarySub">Zoek of filter direct in de tegelbibliotheek.</p></div></div>
        <div class="decorMobileSearchWrap"><span class="decorMobileSearchIcon">⌕</span><input id="decorMobileSearch" type="search" placeholder="Zoek op merk, decornaam, kleur of type…" autocomplete="off" enterkeyhint="search"></div>
        <div class="decorFilterRow" id="decorFilterRow">
          <button class="decorFilterBtn is-active" type="button" data-filter="all"><span class="decorFilterIcon">▦</span>Alle</button>
          <button class="decorFilterBtn" type="button" data-filter="wood"><span class="decorFilterIcon">▥</span>Hout</button>
          <button class="decorFilterBtn" type="button" data-filter="uni"><span class="decorFilterIcon">○</span>Uni</button>
          <button class="decorFilterBtn" type="button" data-filter="stone"><span class="decorFilterIcon">◫</span>Steen</button>
          <button class="decorFilterBtn" type="button" data-filter="metal"><span class="decorFilterIcon">▦</span>Metaal</button>
          <button class="decorFilterBtn" type="button" data-filter="textile"><span class="decorFilterIcon">▧</span>Textiel & leer</button>
          <button class="decorFilterBtn" type="button" data-filter="graphic"><span class="decorFilterIcon">◇</span>Grafisch</button>
          <button class="decorFilterBtn" type="button" data-filter="fantasy"><span class="decorFilterIcon">✦</span>Fantasie</button>
          <button class="decorFilterBtn" id="decorMoreFiltersBtn" type="button"><span class="decorFilterIcon">⌄</span>Filters</button>
        </div>
        <div class="decorMoreFilters" id="decorMoreFilters">
          <label>Merk<select id="decorBrandFilter"><option value="">Alle merken</option></select></label>
          <label>Kleurgroep<select id="decorColorFilter"><option value="">Alle kleuren</option></select></label>
        </div>
        <div class="decorSectionHead"><div class="decorSectionTitle" id="decorSectionTitle">Alle decors</div><div class="decorSectionCount" id="decorSectionCount">Laden…</div></div>
        <div class="decorGrid" id="decorGrid"></div>
        <div class="decorInfiniteSentinel" id="decorInfiniteSentinel" aria-live="polite"></div>`;
      left.insertBefore(panel, left.querySelector('#canvasWrap'));
    }

    let selected = document.getElementById('decorSelectedSummary');
    if(!selected){
      selected = document.createElement('div');
      selected.id = 'decorSelectedSummary';
      const searchWrap = document.getElementById('matSearch')?.parentElement;
      if(searchWrap?.parentElement) searchWrap.parentElement.insertBefore(selected, searchWrap.nextSibling);
    }

    const gridEl = panel.querySelector('#decorGrid');
    bindMaterialCardOwner(panel,gridEl);

    panel.querySelectorAll('[data-filter]').forEach(btn=>btn.addEventListener('click',()=>{
      UI.filter = btn.getAttribute('data-filter') || 'all';
      UI.visible = INITIAL_VISIBLE;
      scrollLibraryTop();
      panel.querySelectorAll('[data-filter]').forEach(x=>x.classList.toggle('is-active',x===btn));
      render();
    }));
    panel.querySelector('#decorMoreFiltersBtn')?.addEventListener('click',()=>{
      panel.querySelector('#decorMoreFilters')?.classList.toggle('is-open');
    });
    panel.querySelector('#decorBrandFilter')?.addEventListener('change',ev=>{UI.brand=ev.target.value||'';UI.visible=INITIAL_VISIBLE;scrollLibraryTop();render();});
    panel.querySelector('#decorColorFilter')?.addEventListener('change',ev=>{UI.color=ev.target.value||'';UI.visible=INITIAL_VISIBLE;scrollLibraryTop();render();});
    let searchTimer = null;
    const applySearch = value=>{
      clearTimeout(searchTimer);
      searchTimer = setTimeout(()=>{
        UI.searchText=String(value||'');
        UI.search=UI.searchText.trim().toLowerCase();
        UI.visible=INITIAL_VISIBLE;
        syncSearchInputs(UI.searchText);
        scrollLibraryTop();
        render();
      },90);
    };
    panel.querySelector('#decorMobileSearch')?.addEventListener('input',ev=>applySearch(ev.target.value));
    const desktopSearch = document.getElementById('matSearch');
    desktopSearch?.addEventListener('input',ev=>applySearch(ev.target.value));
    desktopSearch?.addEventListener('search',ev=>applySearch(ev.target.value));

    try{
      const leftStyleObserver = new MutationObserver(()=>restoreMobileMaterialLibraryShell());
      leftStyleObserver.observe(left,{attributes:true,attributeFilter:['style']});
      const bodyStepObserver = new MutationObserver(()=>{restoreMobileMaterialLibraryShell();render();});
      bodyStepObserver.observe(document.body,{attributes:true,attributeFilter:['data-ui-step']});
      const right = document.querySelector('.right');
      if(right){
        const rightStyleObserver = new MutationObserver(()=>restoreMobileMaterialLibraryShell());
        rightStyleObserver.observe(right,{attributes:true,attributeFilter:['style']});
      }
    }catch(_){ }
    try{
      const mq = window.matchMedia('(max-width:700px)');
      const onMq = ()=>{ restoreMobileMaterialLibraryShell(); render(); };
      if(mq.addEventListener) mq.addEventListener('change',onMq); else mq.addListener(onMq);
    }catch(_){ }

    UI.initialized = true;
    restoreMobileMaterialLibraryShell();
    render();
  }

  function syncSearchInputs(value){
    const text = String(value == null ? '' : value);
    const mobile = document.getElementById('decorMobileSearch');
    const desktop = document.getElementById('matSearch');
    if(mobile && mobile.value !== text) mobile.value = text;
    if(desktop && desktop.value !== text) desktop.value = text;
    const suggest = document.getElementById('matSuggest');
    if(suggest){ suggest.style.display='none'; suggest.innerHTML=''; }
  }

  function scrollLibraryTop(){
    const panel = document.getElementById('decorLibraryPanel');
    if(panel && panel.scrollTop > 0) panel.scrollTop = 0;
    if(isMobile()){ try{ panel?.scrollIntoView({block:'start',behavior:'auto'}); }catch(_){ } }
  }

  function updateSentinel(rows){
    const sentinel = document.getElementById('decorInfiniteSentinel');
    if(!sentinel) return;
    const remaining = Math.max(0, rows.length - UI.visible);
    sentinel.classList.toggle('is-done', remaining === 0);
    sentinel.textContent = remaining > 0 ? `Nog ${remaining} decor${remaining===1?'':'s'} laden…` : (rows.length ? `${rows.length} decor${rows.length===1?'':'s'} geladen` : '');
  }

  function loadNextChunk(){
    const rows = filteredCatalog();
    if(UI.visible >= rows.length) return;
    const grid = document.getElementById('decorGrid');
    if(!grid) return;
    const from = UI.visible;
    UI.visible = Math.min(rows.length, UI.visible + CHUNK_SIZE);
    const chunk = rows.slice(from,UI.visible);
    if(chunk.length) grid.insertAdjacentHTML('beforeend',chunk.map((m,i)=>cardHtml(m,from+i)).join(''));
    updateSentinel(rows);
  }

  function ensureInfiniteLoading(){
    const sentinel = document.getElementById('decorInfiniteSentinel');
    const panel = document.getElementById('decorLibraryPanel');
    if(!sentinel || !panel) return;
    if(!UI.infiniteObserver && 'IntersectionObserver' in window){
      UI.infiniteObserver = new IntersectionObserver(entries=>{
        if(entries.some(entry=>entry.isIntersecting)) loadNextChunk();
      },{root:null,rootMargin:'320px 0px 320px 0px',threshold:0.01});
      UI.infiniteObserver.observe(sentinel);
    }
    if(!UI.scrollFallbackBound){
      UI.scrollFallbackBound = true;
      panel.addEventListener('scroll',()=>{
        if(panel.scrollHeight - panel.scrollTop - panel.clientHeight < 420) loadNextChunk();
      },{passive:true});
      window.addEventListener('scroll',()=>{
        if(!isMobile() || !isMaterialStep()) return;
        const rect=sentinel.getBoundingClientRect();
        if(rect.top < window.innerHeight + 420) loadNextChunk();
      },{passive:true});
    }
  }

  function populateSelect(select, values, current, allLabel, displayValue){
    if(!select) return;
    const labelOf = typeof displayValue === 'function' ? displayValue : (value=>value);
    const labels = values.map(value=>labelOf(value));
    const sig = JSON.stringify([allLabel,values,labels]);
    if(select.dataset.optionsSig !== sig){
      const opts = [`<option value="">${esc(allLabel)}</option>`].concat(values.map(v=>`<option value="${esc(v)}">${esc(labelOf(v))}</option>`));
      select.innerHTML = opts.join('');
      select.dataset.optionsSig = sig;
    }
    select.value = current || '';
  }

  function indexedCatalog(){
    const src = catalog();
    const signature = `${src.length}|${src[0]?.publicMaterialId||''}|${src[src.length-1]?.publicMaterialId||''}`;
    if(UI.indexVersion === signature && UI.indexedRows.length === src.length) return UI.indexedRows;
    UI.indexVersion = signature;
    UI.indexedRows = src.map(m=>{
      const visualTags = visualTagsOf(m);
      return {
        m,
        brand: brandOf(m), color: colorOf(m), bucket: typeBucket(m),
        visualLower: new Set(visualTags.map(x=>x.toLowerCase())),
        hay: `${brandOf(m)} ${displayBrandOf(m)} ${nameOf(m)} ${familyOf(m)} ${visualTags.join(' ')} ${typeOf(m)} ${substrateLabel(m)} ${sheetSizeLabel(m)} ${m?.collection||''} ${colorOf(m)} ${searchTagsOf(m).join(' ')}`.toLowerCase(),
        sort: `${brandOf(m)} ${nameOf(m)}`,
        score: (m?.isPopular?4:0)+(m?.isNew?2:0),
      };
    });
    return UI.indexedRows;
  }

  function filteredCatalog(){
    let idx = indexedCatalog().filter(x=>x.m && x.m.active !== false && x.m.published !== false);
    if(UI.filter !== 'all') idx = idx.filter(x=>x.bucket===UI.filter);
    if(UI.brand) idx = idx.filter(x=>x.brand===UI.brand);
    if(UI.color) idx = idx.filter(x=>x.color===UI.color);
    if(UI.search){
      const terms = UI.search.split(/\s+/).filter(Boolean);
      idx = idx.filter(x=>terms.every(term=>x.hay.includes(term)));
    }
    idx.sort((a,b)=>{
      if(a.score!==b.score) return b.score-a.score;
      return a.sort.localeCompare(b.sort,'nl',{numeric:true,sensitivity:'base'});
    });
    return idx.map(x=>x.m);
  }

  function cardHtml(m, position){
    try{
      return toolAFoundation?.renderMaterialCard?.(m,{activeMaterialKey:selectedKey(),position}) || '';
    }catch(_){ return ''; }
  }

  function renderSelected(){
    const wrap = document.getElementById('decorSelectedSummary');
    if(!wrap) return;
    const m = activeMaterial();
    if(!m){
      wrap.innerHTML = `<div class="decorDesktopEmpty"><strong>Nog geen materiaal gekozen</strong>Kies links een decor of gebruik de zoekbalk hierboven.</div>`;
      return;
    }
    const thickness = thicknessLabel(m);
    const substrate = substrateLabel(m);
    const sheetSize = sheetSizeLabel(m);
    const batches = materialBatches();
    wrap.innerHTML = `<div class="decorSelectedCard">
      <div class="decorSelectedLabel">Actief materiaal</div>
      <div class="decorSelectedMain">
        <div class="decorSelectedThumb">${thumbHtml(m,'',true)}</div>
        <div>
          <div class="decorSelectedBrand">${esc(displayBrandOf(m))}</div>
          <div class="decorSelectedName">${esc(nameOf(m))}</div>
          <div class="decorSelectedMeta"><span class="decorTag">${esc(typeLabel(m))}</span><span class="decorTag">${esc(substrate)}</span>${thickness?`<span class="decorTag">${esc(thickness)}</span>`:''}${sheetSize?`<span class="decorTag">${esc(sheetSize)}</span>`:''}<span class="decorTag">${grainIsOn()?'Nerf':'Vrij roteren'}</span></div>
        </div>
      </div>
      <div class="decorDesktopChoiceLabel">Nerfrichting</div>
      <div class="decorDesktopChoice" role="group" aria-label="Nerfrichting">
        <button type="button" class="decorDesktopChoiceBtn${grainIsOn()?' is-active':''}" id="decorDesktopGrainOn">Nerf aan<small>Niet roteren</small></button>
        <button type="button" class="decorDesktopChoiceBtn${!grainIsOn()?' is-active':''}" id="decorDesktopGrainOff">Nerf uit<small>Vrij roteren</small></button>
      </div>
      ${batches.length?`<div class="decorDesktopBatchTitle">Geselecteerde materialen (${selectedMaterialCount()})</div><div class="decorDesktopBatchList">${desktopBatchRowsHtml()}</div>`:''}
      <div class="decorDesktopActions">
        <button type="button" class="decorDesktopAction decorDesktopActionSecondary" id="decorDesktopAddMore">Nog een materiaal toevoegen</button>
        <button type="button" class="decorDesktopAction decorDesktopActionPrimary" id="decorDesktopGoPanels">Naar panelen&nbsp; →</button>
      </div>
    </div>`;
    bindDesktopSelectionEvents();
  }

  function renderMobileSelection(){
    ensureMobileSelectionUi();
    const sticky = document.getElementById('decorMobileSticky');
    const m = activeMaterial();
    // FIX660R8O: Tool A now owns one multi-material basket trigger. Keeping the
    // older single-material sticky bar underneath it duplicated the same swatch,
    // title and navigation action on mobile. Leave the legacy sheet available as
    // a fallback for older pages, but do not render its trigger when the new
    // basket module is active.
    const supersededByMaterialCart = !!toolAFoundation?.renderMobileMaterialCart;
    const visible = !!(m && isMobile() && isMaterialStep() && !supersededByMaterialCart);
    if(sticky){
      sticky.classList.toggle('is-visible',visible && !UI.sheetOpen);
      sticky.setAttribute('aria-hidden',visible && !UI.sheetOpen ? 'false':'true');
    }
    if(!m) return;

    const thickness = thicknessLabel(m);
    const substrate = substrateLabel(m);
    const sheetSize = sheetSizeLabel(m);
    const grainText = grainIsOn() ? 'Nerf' : 'Vrij roteren';
    const stickyThumb = document.getElementById('decorMobileStickyThumb');
    if(stickyThumb) stickyThumb.innerHTML = thumbHtml(m,'',false);
    const stickyName = document.getElementById('decorMobileStickyName');
    if(stickyName) stickyName.textContent = nameOf(m);
    const stickyMeta = document.getElementById('decorMobileStickyMeta');
    if(stickyMeta) stickyMeta.textContent = [substrate,thickness,sheetSize].filter(Boolean).join(' · ');

    const sheetMedia = document.getElementById('decorSheetMedia');
    if(sheetMedia) sheetMedia.innerHTML = thumbHtml(m,'',true);
    const sheetBrand = document.getElementById('decorSheetBrand');
    if(sheetBrand) sheetBrand.textContent = displayBrandOf(m);
    const sheetName = document.getElementById('decorMobileSheetTitle');
    if(sheetName) sheetName.textContent = nameOf(m);
    const sheetTags = document.getElementById('decorSheetTags');
    if(sheetTags) sheetTags.innerHTML = `<span class="decorTag">${esc(typeLabel(m))}</span><span class="decorTag">${esc(substrate)}</span>${thickness?`<span class="decorTag">${esc(thickness)}</span>`:''}${sheetSize?`<span class="decorTag">${esc(sheetSize)}</span>`:''}<span class="decorTag">${grainText}</span>`;
    document.getElementById('decorSheetGrainOn')?.classList.toggle('is-active',grainIsOn());
    document.getElementById('decorSheetGrainOff')?.classList.toggle('is-active',!grainIsOn());
  }

  function render(){
    restoreMobileMaterialLibraryShell();
    ensureUi();
    const panel = document.getElementById('decorLibraryPanel');
    const grid = document.getElementById('decorGrid');
    if(!panel || !grid) return;
    const all = catalog().filter(m=>m && m.active !== false && m.published !== false);
    const brands = Array.from(new Set(all.map(brandOf).filter(Boolean))).sort((a,b)=>a.localeCompare(b,'nl',{sensitivity:'base'}));
    const colors = Array.from(new Set(all.map(colorOf).filter(v=>v && v!=='Overig'))).sort((a,b)=>a.localeCompare(b,'nl',{sensitivity:'base'}));
    populateSelect(document.getElementById('decorBrandFilter'),brands,UI.brand,'Alle merken',displayBrandFilterValue);
    populateSelect(document.getElementById('decorColorFilter'),colors,UI.color,'Alle kleuren');
    const rows = filteredCatalog();
    const shown = rows.slice(0,UI.visible);
    const sectionTitle = document.getElementById('decorSectionTitle');
    if(sectionTitle) sectionTitle.textContent = UI.search ? 'Zoekresultaten' : (UI.filter==='all' ? (rows.some(x=>x.isPopular)?'Populair en alle decors':'Alle decors') : ({wood:'Houtdecors',uni:'Uni kleuren',stone:'Steen & beton',metal:'Metaal',textile:'Textiel & leer',graphic:'Grafisch',fantasy:'Fantasie'}[UI.filter]||'Decors'));
    const sectionCount = document.getElementById('decorSectionCount');
    if(sectionCount) sectionCount.textContent = `${rows.length} decor${rows.length===1?'':'s'}`;
    grid.innerHTML = shown.length ? shown.map((m,i)=>cardHtml(m,i)).join('') : `<div class="decorEmpty tool-dyn-51377a917eb3">Geen decors gevonden met deze filters.</div>`;
    updateSentinel(rows);
    ensureInfiniteLoading();
    renderSelected();
    renderMobileSelection();
  }

  document.addEventListener('DOMContentLoaded',()=>{ ensureUi(); setTimeout(render,0); });
  document.addEventListener('adzaagt-material-catalog-updated',()=>{UI.indexVersion='';UI.indexedRows=[];UI.visible=INITIAL_VISIBLE;render();});
  document.addEventListener('adzaagt-material-selection-updated',render);
  window.addEventListener('pageshow',()=>setTimeout(render,0));
  window.addEventListener('resize',()=>setTimeout(()=>{restoreMobileMaterialLibraryShell();renderMobileSelection();},40));
  setTimeout(()=>{ensureUi();render();},500);
})();
