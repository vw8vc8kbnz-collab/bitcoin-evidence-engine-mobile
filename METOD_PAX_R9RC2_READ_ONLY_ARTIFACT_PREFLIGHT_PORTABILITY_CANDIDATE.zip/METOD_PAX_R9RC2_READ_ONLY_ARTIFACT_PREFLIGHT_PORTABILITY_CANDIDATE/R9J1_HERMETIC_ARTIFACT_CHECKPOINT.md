# R9J-1 hermetisch artifactcheckpoint

Status: **PROVISIONAL DEVELOPMENT CHECKPOINT**  
Release-eligibility: **NO_GO totdat alle externe browser-, VPS-, security- en operationele gates aantoonbaar PASS zijn**

## Doel

Het echte METOD/PAX-productartifact moet volledig controleerbaar zijn nadat het in een lege map is uitgepakt. Geen regressietest in de release mag afhankelijk zijn van een aangrenzende `.git`-map, lokale tags of een ontwikkelaarswerkboom.

## Uitgevoerd

- De zes resterende Git-afhankelijke R9H/R9I-regressietests gebruiken `R9J1_HERMETIC_AUDIT_REFERENCE.json` voor lokale, byte-exacte bestandsidentiteit.
- Historische bronvergelijking blijft beschikbaar in de afzonderlijke volledige Git-bundle; zij is geen runtimevoorwaarde meer.
- `tools/verify_standalone_artifact.py` weigert padtraversal, absolute paden, dubbele leden, symlinks, speciale bestanden, `.git`, meerdere release-roots en onbegrensde extractie.
- De release-builder bouwt eerst deterministisch, pakt daarna het gemaakte ZIP-bestand uit in een nieuwe tijdelijke map en draait daar de volledige preflight met interne checksumverificatie.
- Het standalone rapport bindt artifactnaam, artifact-SHA-256, bestandenaantal en de SHA-256 van de volledige preflightuitvoer.

## Bewijsgrens

Dit checkpoint bewijst dat de release zelfdragend en hermetisch testbaar is. Het claimt geen productie-GO: echte Chromium/WebKit/Safari-, VPS-, deployment-, logging-, backup/restore- en organisatorische privacybewijzen blijven afzonderlijke externe gates.
