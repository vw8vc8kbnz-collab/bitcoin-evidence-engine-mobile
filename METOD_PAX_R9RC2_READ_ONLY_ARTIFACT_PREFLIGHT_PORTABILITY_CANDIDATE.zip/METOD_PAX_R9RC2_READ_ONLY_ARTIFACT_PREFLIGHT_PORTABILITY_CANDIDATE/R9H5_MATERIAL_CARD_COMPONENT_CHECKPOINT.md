# R9H-5 checkpoint — native materiaalkaart

Datum: 22 augustus 2026  
Status: ontwikkelcheckpoint, R9H 5/10  
Voorgestelde annotated tag: `r9h-material-card-component-checkpoint`

## Uitkomst

`app/tool-a/components/material-card.js` is de enige native eigenaar van het
materiaalkaartmodel, de exacte kaartmarkup, selectieklik en de fallback voor een
defecte decorafbeelding. `decor_library.js` behoudt catalogusfilters, zoekindex,
geselecteerde-materiaalsamenvatting en de bestaande state-mutaties, maar bevat
voor kaarten alleen nog een dunne adapter naar `ToolAR9Foundation`.

De foundation publiceert twee extra frozen methoden:

- `renderMaterialCard`;
- `bindMaterialCardGrid`.

## Behouden contract

- dezelfde publieke materiaal-id, naam, merk-, familie- en substraatlabels;
- Hout met intern merk `Overig` blijft zichtbaar `Fineer`;
- dezelfde dikte- en plaatmaataanduiding, inclusief decimale komma;
- eerste vier afbeeldingen blijven eager/high-priority, overige lazy;
- geselecteerde kaart behoudt exact class, `aria-pressed` en vinkmarkering;
- defecte afbeeldingen worden eenmaal vervangen door hetzelfde familiesymbool;
- onbekende ids, clicks buiten het grid en ontbrekende DOM-capabilities zijn
  side-effectvrij en no-throw;
- filters, zoekindex, materiaalstate, mandje, panelen, nerf, optimizer, DXF,
  pricing, API-owners en jobpayloadbuilder zijn niet verplaatst of gewijzigd;
- de bestaande 19.784 bytes decor-CSS zijn bytegelijk aan R9H-4.

## Bewijs

- 12/12 materiaalkaartcomponenttests: PASS;
- 12/12 footer-, 12/12 mobile-cart-, 12/12 progress- en 11/11 dialogtests:
  PASS;
- 16/16 foundationtests en 83/83 R9G-tests: PASS;
- architectuurgate: 14 native modules, vijf beoordeelde DOM-/eventowners,
  twee netwerkowners, nul storageowners en één compatibilityglobal: PASS;
- twee vaste kaartfixtures zijn bytegelijk aan de R9H-4-owner;
- optimizer-, DXF-, pricing-, panelcontract-, API-, dialog-, progress-,
  mobile-cart-, footer- en jobpayloadfingerprints: onveranderd.

## Gatebesluit

R9H staat op 5/10. Dit checkpoint is `PROVISIONAL_DEVELOPMENT_ONLY` en niet
release-eligible. Echte WebKit/Safari- en productie-identieke externe gates
blijven `DEFERRED NO-GO`.

Volgende afgebakende stap: R9H-6, de paneeleditor als native componentowner.
