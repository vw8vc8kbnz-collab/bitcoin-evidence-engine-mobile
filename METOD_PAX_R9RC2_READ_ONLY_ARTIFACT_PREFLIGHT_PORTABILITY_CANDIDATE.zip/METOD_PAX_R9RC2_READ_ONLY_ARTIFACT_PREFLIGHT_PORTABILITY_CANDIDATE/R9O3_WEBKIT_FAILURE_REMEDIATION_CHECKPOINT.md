# R9O3 — WebKit failure remediation

## Status

R9O3 is a targeted local remediation candidate. It is explicitly
`PROVISIONAL_DEVELOPMENT_ONLY`, is not release-eligible and is not a production
GO. Only a new external run of the sealed 15-fixture/100-assertion Chromium and
WebKit gate may determine whether the R9O2 browser failures are closed.

## Corrected failure groups

1. The wizard refresh now waits for actual completion of all embedded-DXF
   request bodies before navigation and again before teardown. Failed or pending
   requests remain hard failures; no WebKit page-error allowlist exists.
2. Grain-preview, material-swatch and legacy panel-canvas observers no longer
   mutate layout synchronously from a ResizeObserver delivery. Work is
   coalesced on animation frames, unchanged sizes are ignored, detached/hidden
   hosts are skipped and the redundant parent-card observation is removed.
3. The controlled optimizer barrier is rearmed for every engine/profile and
   for golden and candidate separately. The real optimizer process, cancel
   endpoint and cleanup path remain under test.
4. The authenticated Admin header and shell have a scoped responsive contract
   for the real 393px WebKit-iPhone viewport. The viewport assertion is unchanged
   and horizontal overflow is not hidden.

## Unchanged protected behavior

No optimizer, nesting, geometry, pricing, submission, storage, authentication
or immutable R8Z behavior was changed. Existing security boundaries and the
expected anonymous 404 behavior of protected Admin assets remain intact.

## Required next gate

Run `R9O4_EXTERNAL_CHROMIUM_WEBKIT_RERUN` in the exact pinned Playwright image
and digest with real Chromium and WebKit, `--network none`, `--init` and
`--ipc=host`. PASS requires all 15 fixtures, all 100 contract assertions, both
engines, zero blocked fixtures and unchanged candidate/R8Z source manifests.
