# R9H-6 checkpoint — native paneeleditor

Datum: 22 augustus 2026  
Status: ontwikkelcheckpoint, R9H 6/10  
Voorgestelde annotated tag: `r9h-panel-editor-component-checkpoint`

## Uitkomst

`app/tool-a/components/panel-editor.js` is de native eigenaar van de
formulieracties en mutatieroutes voor zowel standaard METOD/PAX-panelen als
overige maatwerkpanelen. De bestaande, uitvoerig bewezen submit-, validatie-,
prefill- en upsertmodules blijven tijdelijk als compatibilitylaag achter deze
ene owner actief.

De foundation publiceert uitsluitend dunne adapters voor:

- het eenmalig binden van standaard- en extra-paneelacties;
- toevoegen en bijwerken via de bestaande canonieke submitflows;
- verwijderen vanuit paneeldock, overlay en overzicht;
- standaard- en extra-paneel-prefill en reset.

## Behouden contract

- alle bestaande paneeltypen, templates en speciale DXF-varianten;
- naam, materiaal, dikte, maat, aantal, scharnier, rotatietoestemming,
  verlenging, kantenband en nerfvelden;
- de minimummaat- en plaatfitvalidaties van overige panelen;
- edit-in-place, groepsaantal en materiaalheractivatie bij standaardpanelen;
- dezelfde render-, draftsave-, prijsbar- en previewcallbacks na mutaties;
- één reset van nerftoewijzingen wanneer de paneelverzameling verandert;
- optimizer, payloadbuilder, DXF, pricing, serverroutes en inline CSS zijn niet
  gewijzigd.

## Bewijs

- 12/12 gerichte paneeleditorcomponenttests: PASS;
- de frontendarchitectuurgate ziet exact 15 native modules, zes beoordeelde
  DOM-/eventowners, twee netwerkowners en één compatibilityglobal: PASS;
- de oudere R9H-component-, R9G-, R9B- en serverregressies blijven verplicht;
- optimizer-, DXF-, pricing-, panelcontract- en legacy-paneelplanfingerprints
  blijven bytegelijk beschermd.

## Gatebesluit

R9H staat op 6/10. Dit checkpoint is `PROVISIONAL_DEVELOPMENT_ONLY` en niet
release-eligible. Echte WebKit/Safari- en productie-identieke externe gates
blijven `DEFERRED NO-GO`.

Volgende afgebakende stap: R9H-7, de nerfpreview als native componentowner.
