# R9I-4 — centrale job-annuleringsroute

Status: **PROVISIONAL DEVELOPMENT ONLY**. Dit checkpoint is niet release- of
productiegoedgekeurd zolang Chromium, WebKit, VPS-staging en de externe
auditgates niet aantoonbaar groen zijn.

## Uitgevoerde cleanup

Exact één publieke frontendroute is gecentraliseerd:
`POST /api/jobs/cancel`.

De bestaande native `app/tool-a/api/jobs.js`-eigenaar bouwt en verstuurt nu de
annuleringsrequest. De legacyfunctie `_markJobCancelled` bewaart het bestaande
annuleringsmoment en de bestaande tokenfallback, maar delegeert de request als
dunne adapter via de bevroren `ToolAR9Foundation`-laag.

Behoud is expliciet bewezen voor:

- route en methode;
- `Content-Type` en optionele bearer-header;
- JSON-payload met `jobId` en reden `customer_cancelled`;
- ontbrekende-job-no-op;
- het bestaande best-effortgedrag zonder nieuwe responseparsing;
- exact één call vanuit de resetflow.

`POST /api/cancel` voor de reeds ingediende aanvraag blijft bewust buiten deze
tranche. De backend is byte-exact ongewijzigd.

## Meetbare grens

De legacy-runtime bevat nog 9 in plaats van 10 directe `fetch`-sites. De
runtime kromp ten opzichte van R9I-3 met 39 bytes en 2 regels; cumulatief sinds
R9H-10 met 3.507 bytes en 79 regels. Er blijven exact twee native
netwerkowners, negen DOM-owners en één compatibility-global.

`tools/r9i_job_cancel_route_tests.py` bewijst de exacte wire-request, no-op,
adaptergrens, module-eigenaarschap en byte-identiteit van backend, optimizer,
DXF-, prijs- en paneelcontracten. De R9I clean-codegate bindt deze route aan de
bestaande reader- en architectuurgrenzen.

## Niet gewijzigd

- serverroute, methoden, statuscodes, payloadacceptatie en rate limits;
- optimizer, nesting, DXF-bytes, plaatsingen en manifesten;
- prijs-, btw- en afrondingslogica;
- request-annulering na submit, definitieve submit en thank-you;
- CSS-fixlagen, DOM-owners en gedragdragende inline styles.

## Vervolg

De volgende tranche beoordeelt één router/overlay-owner. Alleen een eigenaar met
een begrensde consumerlijst en sterk goldenbewijs mag worden gekozen. Visuele
cleanup blijft geblokkeerd totdat Chromium én WebKit gelijkheid aantonen.
