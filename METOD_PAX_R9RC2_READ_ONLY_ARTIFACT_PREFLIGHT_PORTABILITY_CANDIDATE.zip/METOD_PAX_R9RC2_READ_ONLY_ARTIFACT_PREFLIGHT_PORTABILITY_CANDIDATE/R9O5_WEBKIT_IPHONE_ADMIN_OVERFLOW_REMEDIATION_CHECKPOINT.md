# R9O5 WebKit-iPhone Admin overflow remediation

## Besluit

R9O5 is een smalle audit-candidate en blijft **NO-GO voor productie** totdat de onafhankelijke R9O6 Chromium/WebKit-run alle 15 fixtures en alle 100 contractasserties als PASS bindt.

## Onafhankelijke aanleiding

De ontvangen R9O4-evidence-ZIP heeft SHA-256 `930a576b4331feb773b5e1a98706fbfcf8509bae4bece77b1c287b8e9330608a`; alle interne bewijschecksums zijn geverifieerd. R9O4 leverde 14/15 fixtures PASS. Alleen `admin-presentation-session-assets` faalde, uitsluitend in `webkit-iphone`: `bodyScrollWidth=492` bij `viewportWidth=393`. De andere drie profielen slaagden. Er waren geen blockers en de overige 99 contractasserties slaagden.

## Correctie

De inbox-tabstrip is een wrapping flexcontainer maar bleef zelf een flex-item met een automatische intrinsieke minimumbreedte. WebKit behield daardoor de gecombineerde tabbreedte binnen de smalle contentkolom. De bestaande mobiele breakpoint geeft nu uitsluitend aan `.tabs` `min-width:0` en `max-width:100%`. Er wordt niets verborgen en de viewportassertie blijft ongewijzigd fail-closed.

De browserdriver legt bij een toekomstige overflow daarnaast de zichtbare overschrijdende DOM-elementen met geometrie en berekende sizing vast. Dit verandert geen acceptatievoorwaarde; het versterkt alleen het bewijs. De R9O6 tmux-runner herstelt de ownership van Docker-output vóór exit- en checksumverwerking en sluit zijn eigen checksummanifest expliciet uit.

## Niet gewijzigd

- optimizer, nesting, geometrie en prijzen;
- aanvraag-, job- of downloadgedrag;
- de immutable R8Z golden baseline;
- browser-, console- of page-errorbeleid;
- fixture-, engine-, profiel- of assertionaantallen.

## Vereiste vervolgstap

Voer `operations/RUN_R9O6_EXTERNAL_BROWSER_GATE_TMUX.sh` uit op de externe VPS met de vastgepinde Playwright-container, echte Chromium en echte WebKit, `--network none`, 15 fixtures en 100 contractasserties. Alleen een cryptografisch gebonden volledige PASS kan deze browsergate sluiten. Overige productiepoorten blijven daarna nog afzonderlijk vereist.
