# R9K1 — dormant Admin-authcleanup

Status: `PROVISIONAL_DEVELOPMENT_ONLY` / `NO_GO` voor productie.

## Exacte wijziging

Vanaf exact R9J8-commit `9e779bacd300fdf914b479cd3c78682f9e505d66`
is uitsluitend het reeds onbereikbare FIX626-script uit `ADMIN_HTML` verwijderd.
Het segment bestond uit een password-only login, bearerresponse, Admin-token in
`sessionStorage` en een globale `window.fetch`-monkeypatch. De vooraf geplaatste
marker forceerde vóór R9K1 altijd een onmiddellijke return.

De cleanup verwijdert 178 regels en 9.511 bytes uit `app/server_py.py`. De vier
R8Z-frozen behaviorfiles zijn niet gewijzigd. De actieve login-HTML en actieve
TOTP-, cookie-, origin-, role-, timeout- en logout/revokeeigenaren zijn op
bronsegmenthash verzegeld en byte-identiek aan R9J8.

## Nieuwe negatieve gates

- geen dormant FIX626-authmarker of -body;
- geen Admincredential of -bearer via `localStorage`/`sessionStorage` set/get;
- geen password-only actieve browserlogin;
- geen globale Adminauth-fetchmonkeypatch;
- precies één browserloginowner: `ADMIN_LOGIN_HTML`;
- browseroracle controleert dat de loginresponse geen bearer bevat, geen
  Adminauth-Web-Storage-key ontstaat en de sessiecookie `HttpOnly` is.

## Scopegrens

R9K2, R9K3, R9K4, verdere backendextractie en verdere professionele splitsing
van Admin HTML/CSS/JS zijn bewust niet gecombineerd met deze patch. De bekende
resterende dode 410-bodies en lege iterable staan daardoor nog open.

## Releasebesluit

R9K1 mag pas worden getagd nadat alle lokaal beschikbare gates groen zijn en de
Git-tree schoon is. Een ontbrekende Chromium- of WebKit-binary blijft een echte
browsergate `NO_GO`; ook VPS-, onafhankelijke securityaudit- en productie-evidence
blijven deferred. Dit checkpoint claimt dus geen live-gereedheid.
