# R9I-2 — pure nerf-readers

Status: **PROVISIONAL DEVELOPMENT ONLY**. Dit checkpoint is niet release- of
productiegoedgekeurd zolang Chromium, WebKit, VPS-staging en de externe
auditgates niet aantoonbaar groen zijn.

## Uitgevoerde cleanup

Vier pure nerf-readers uit de grote legacy-runtime zijn gecentraliseerd in de
bestaande native selector- en storelaag:

- geselecteerde nerfmateriaalkey;
- nerf-aan/uit per materiaalbatch;
- de read-only beslissing of een paneel nerfgeschikt is;
- parsing van bestaande `cart:*`- en `extra:*`-referenties.

De oorspronkelijke functienamen blijven uitsluitend als dunne adapters op de
ene bevroren `ToolAR9Foundation`-compatibilitylaag bestaan. Geen mutatie-, DOM-,
event-, netwerk-, render-, submit-, poll- of optimizerowner is toegevoegd of
verplaatst.

## Meetbare grens

Ten opzichte van de R9H10-baseline kromp de legacy-runtime cumulatief van
449.328 naar 447.522 bytes en van 9.890 naar 9.848 regels. Deze tranche verwijdert
nog eens 206 bytes en 6 regels uit de legacy-runtime. Zes legacy-readers zijn nu
in totaal via de centrale read-store ontsloten.

`tools/r9i_grain_reader_tests.py` bewijst de uitkomstgelijkheid met de verwijderde
legacylogica voor materiaalkeuze, expliciet in-/uitgeschakelde nerf, materiaal-
aliases, lege invoer en alle bestaande referentievormen. De clean-codegate
verifieert daarnaast exacte hashes, minimale cumulatieve én incrementele krimp,
dunne adapters en onveranderde gevoelige ownertokens.

## Niet gewijzigd

- optimizer, nesting, DXF-bytes en manifesten;
- prijs-, btw- en afrondingslogica;
- routes, methoden, statussen en payloads;
- CSS-fixlagen en gedragdragende inline styles;
- grain renderer, preview, validatie en mutatieroutes.

## Vervolg

De volgende lokale tranche blijft reader-first en klein. Een API-route of
router/overlay-owner volgt pas nadat de pure readextracties met alle gates groen
zijn. Visuele cleanup blijft geblokkeerd totdat Chromium én WebKit gelijkheid
aantonen.
