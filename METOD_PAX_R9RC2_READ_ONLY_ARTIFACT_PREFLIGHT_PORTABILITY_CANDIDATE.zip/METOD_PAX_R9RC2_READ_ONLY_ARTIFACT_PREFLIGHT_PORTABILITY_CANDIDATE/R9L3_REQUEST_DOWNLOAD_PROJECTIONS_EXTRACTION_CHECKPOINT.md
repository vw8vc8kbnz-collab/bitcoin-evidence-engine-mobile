# R9L3 — request- en downloadprojectie-extractie

R9L3 verplaatst de actieve Admin-mailbox-, requestmanifest-, gelinkte-
bestands- en ZIP-selectielogica uit `app/server_py.py` naar één eigenaar:
`app/metod_app/requests/downloads.py`.

## Eigenaarsgrens

`RequestDownloadProjectionService` bezit:

- de begrensde newest-first requestmailboxprojectie;
- het read-only request-naar-job/subjob-bestandsmanifest;
- selectie van één uitsluitend via het request gelinkt bestand;
- selectie van verzegelde ZIP-inputs en collision-safe archiefnamen;
- de bestaande inputlimiet en fail-closed foutprojecties.

De server houdt authenticatie, queryvalidatie, HTTP-antwoorden, ZIP-creatie,
fsync, streaming en tijdelijke-bestandsopruiming. De owner importeert geen
HTTP-server, `server_py`, socket-, subprocess-, threading- of ZIP-module en
bezit geen lock of schrijfpad.

## Gedragbehoud

De vóór-extractiefixture verzegelt de volledige R9L2-server, zes actieve
bronnen, mailboxvolgorde en limieten, manifestinhoud, request-file-uitkomsten,
ZIP-fouten en een succesvolle ZIP inclusief memberhash en downloadnaam. Die
fixture blijft na extractie byte-exact slagen.

`server_py.py` krimpt van 526.841 bytes en 11.542 regels naar 518.347 bytes en
11.329 regels. De nieuwe owner is 16.204 bytes en 377 regels. De immutable R8Z-
baseline en alle generieke/public downloadroutes blijven buiten deze wijziging.

## Status

Dit checkpoint blijft `PROVISIONAL_DEVELOPMENT_ONLY` en niet release-eligible.
Browser, echte iPhone/Safari, kandidaat-VPS, onafhankelijke securityaudit,
productie-identieke load/chaos/soak, off-host restore en operationele signoff
blijven externe NO_GO-poorten.

De volgende exclusieve stap is
`R9L4_STATIC_FILE_AND_REMAINING_HTTP_ADAPTERS_EXTRACTION`. R9M-professionele
HTML/CSS/JavaScript-splitsing hoort niet in R9L3 of R9L4.
