# R9G-8 checkpoint — ownershipcleanup

Datum: 22 augustus 2026
Status: ontwikkelcheckpoint, R9G 8/8
Voorgestelde annotated tag: `r9g-complete-ownership-cleanup-checkpoint`

## Uitkomst

R9G is compleet. De native Tool A-grens heeft één productie-eigenaar per
netwerkactie en één fysieke clickadapter per compute-/submitactie. De laatste
aantoonbaar inactieve submitbridge is fysiek verwijderd en wordt niet meer door
de HTTP-static allowlists aangeboden.

## Exacte eigenaars

| Actie/route | Enige productie-eigenaar | Fysieke delegatie |
|---|---|---|
| `POST /api/jobs` | `app/tool-a/api/jobs.js` | één `saveQuoteBtn` clicklistener |
| `GET /api/jobs/{jobId}/status` | `app/tool-a/api/jobs.js` | dezelfde computeflow, één poller |
| `POST /api/submit_config` | `app/tool-a/api/requests.js` | één vroege document-captureadapter |

Eén compute-click veroorzaakt maximaal één job-POST en één pollerlifecycle.
Een dubbele definitieve submit tijdens inflight veroorzaakt maximaal één
submit-POST. Er is geen target-/fallbacksubmitlistener en geen inline
submit-/jobfetch meer in productie-HTML.

## Tijdelijke compatibilitygrens

`ToolAR9Foundation` is één non-configurable, non-writable, frozen global met
exact veertien keys: revision, mode, vijf readmethoden, vier job-/prijsmethoden
en drie submitstatemethoden. Geen module buiten `api/jobs.js` en
`api/requests.js` bezit netwerk-I/O; de overige modules bezitten geen DOM,
storage, events of globals.

## Verwijderde inactieve code

- `app/toolA_final_submit_bridge.js` verwijderd;
- verwijderd uit `_PUBLIC_STATIC_ROOT_FILES` in `app/server_py.py`;
- verwijderd uit `PUBLIC_STATIC_ROOT_FILES` in
  `app/metod_app/http/matcher.py`;
- historische bridge-executie uit de functionele regressiegate verwijderd;
- vervangen door een R9G-complete ownershipinventaris die afwezigheid,
  eigenaarschap, API-oppervlak, pure grenzen en one-click/one-request bewijst.

## Beschermde fingerprints

| Onderdeel | SHA-256 |
|---|---|
| optimizer | `42480b301cd660dac1e5e9fec2c8d30bb5c6826c32234a9c1cce765b758bebb8` |
| DXF-geometrie | `b80a2d006241908bf7b33516f7e0faf59ef61e1e08db86966b23cc5de292c1ff` |
| pricinghelpers | `646c2f5186e9b080f6ba8dcf364884411c18e946254bb5c9001647f7cbb425df` |
| panelcontract | `e23314fd63a2358a48daa580a92cebb8a40c9862548ba0243461a59347da7fc9` |
| `buildJobPayload()` | `342dac02c2650ac2798e20e62d38d8e1e6b7d518a54daa8fd760d734ae527e47` |

De jobpayloadbuilder blijft exact 9.697 bytes.

## Bewijsstatus

- nieuwe R9G-8 ownershiptests: 10/10 PASS;
- eerdere R9G-suites: 73/73 PASS;
- skips/xfails toegestaan: nee;
- complete kandidaat- en uitgepakte artifactpreflight: verplicht PASS;
- verse R8Z↔R9G-8 black-boxoracle: verplicht 12/12 fixtures en 47/47 assertions;
- echte iOS WebKit/Safari: `DEFERRED NO-GO`;
- productie-identieke VPS/load/chaos/TLS/firewall/backup-restore/CAM:
  `DEFERRED NO-GO`.

Dit checkpoint sluit R9G af maar verleent geen productie-GO. De volgende
modulariseringsfase is R9H, met behoud van alle R8Z/R9-oracles.
