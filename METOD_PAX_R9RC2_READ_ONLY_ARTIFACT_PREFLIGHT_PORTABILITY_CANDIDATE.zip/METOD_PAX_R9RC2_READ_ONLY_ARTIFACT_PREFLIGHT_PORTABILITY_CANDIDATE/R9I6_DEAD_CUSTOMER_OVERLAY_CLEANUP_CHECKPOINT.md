# R9I-6 — obsolete customer-overlay cleanup

Status: **PROVISIONAL DEVELOPMENT CHECKPOINT — NO GO**

Basis: `r9i-overlay-router-cleanup-checkpoint`

## Uitgevoerd

- De niet-bestaande `customerOverlay`-surface en de oude velden `customerNameInput` en `customerOrderInput` zijn uit de legacy-runtime verwijderd.
- Dubbele open/closeglobals, niet-bestaande knoppen, lege listeners en de obsolete customer-overlaybinding zijn verwijderd.
- `stepCustomer` blijft de enige gerenderde klantgegevenssurface.
- De actieve klantinvoer, statecapture, validatie, checkoutflow en draft-hydratatie zijn byte-exact behouden.
- Prijsberekening, prijsweergave, submit, API-routes en functionele waarheidsbestanden zijn niet gewijzigd.

## Meetbare clean-codewinst

| Grens | R9I-5 | R9I-6 | Delta |
|---|---:|---:|---:|
| Legacy-runtime | 441.207 bytes / 9.695 regels | 437.686 bytes / 9.612 regels | −3.521 bytes / −83 regels |
| Volledige klassieke scriptstream | 502.203 bytes | 498.682 bytes | −3.521 bytes |
| `addEventListener(` in legacy-runtime | 156 | 151 | −5 |
| Native modules | 19 | 19 | ongewijzigd |
| Gecontroleerde DOM-eigenaars | 10 | 10 | ongewijzigd |
| Netwerkeigenaars | 2 | 2 | ongewijzigd |
| Klassieke shellscripts | 34 | 34 | ongewijzigd |

Sinds de R9I-baseline is de legacy-runtime in totaal 11.642 bytes en 278 regels gekrompen.

## Expliciet ongewijzigd

- actieve klantvelden, validatie en customer-snapshotsemantiek;
- checkout-submit, prijs-/btw-/afrondingslogica en catalogustruth;
- DXF-optimizer, geometrie, plaatsing en paneelcontract;
- publieke API-routes, methodes, statussen en payloads;
- DXF-bytes, namen, ZIP-plaatsingen, manifests en outputhashcontracten;
- PII-opslag- en redactiebeleid;
- CSS-stream, 34-delige klassieke scriptindeling en 19-delige native modulearchitectuur.

## Bewijsgrenzen

- `R9I6_DEAD_CUSTOMER_OVERLAY_CLEANUP.json` sluit runtime-, scriptstream-, native owner-, netwerkowner- en protected-filehashes fail-closed af.
- `tools/r9i_dead_customer_overlay_tests.py` bewijst dat de obsolete surface niet in HTML bestaat, alle dode owners weg zijn en de actieve klantflow byte-exact gelijk bleef.
- `tools/r9i_clean_code_gate.py` verbiedt terugkeer van de verwijderde tokens en bewaakt cumulatieve en incrementele krimp.
- De bestaande R9I-overlayroutertests blijven de vier echte generieke overlays en hun exacte gedrag bewaken.

## Resterende gates

Dit checkpoint is geen productie-GO. Een productie-identieke VPS-proef en de verplichte Chromium/WebKit/Safari-browserevidence blijven open. Tot die tijd blijven visuele/CSS-cleanups en verdere compatibilityverwijderingen die browsergedrag kunnen raken geblokkeerd.
