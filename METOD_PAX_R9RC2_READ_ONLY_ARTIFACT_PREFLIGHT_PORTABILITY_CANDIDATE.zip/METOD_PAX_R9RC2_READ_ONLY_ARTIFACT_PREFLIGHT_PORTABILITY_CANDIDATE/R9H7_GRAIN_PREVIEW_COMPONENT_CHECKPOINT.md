# R9H-7 — Native nerfpreviewcomponent

Status: ontwikkelcheckpoint 7/10; geen productie-GO.

De nerfpreview heeft één native eigenaar voor binden, renderroutering,
animation-frame scheduling, resize-observatie en data-readiness. De bestaande
Grain Studio canvas-engine blijft de beschermde compatibilitylaag voor echte
millimeterproporties, materiaalstalen, DXF-boringen en de fysieke volgorde
onder→boven.

Ongewijzigd en buiten scope: optimizer, payloadbuilder, DXF-geometrie, pricing,
serverroutes, panelcontract en alle CSS. Safari/WebKit en productie-identieke
externe gates blijven `DEFERRED NO-GO`.

Bewijs wordt vastgelegd in `contracts/R9H_GRAIN_PREVIEW_SCOPE.json` en
`reports/R9H_GRAIN_PREVIEW_CHECKPOINT.md`.
