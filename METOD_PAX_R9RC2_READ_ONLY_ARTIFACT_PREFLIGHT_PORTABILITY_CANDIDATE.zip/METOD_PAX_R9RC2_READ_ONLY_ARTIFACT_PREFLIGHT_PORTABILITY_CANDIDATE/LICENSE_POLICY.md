# METOD/PAX licentie- en componentbeleid

Status: **provisional audit evidence**

## Applicatiebron

De METOD/PAX-applicatiebron is project-eigen en wordt als **proprietary / all rights reserved** behandeld. Deze overdracht verleent uitsluitend de rechten die de eigenaar afzonderlijk met ontwikkelaars, auditors of operators overeenkomt. Er ontstaat door aanwezigheid in dit pakket geen impliciete open-sourcelicentie of redistributierecht.

## Productieruntime

- Het verplichte Pythonproductiepad gebruikt alleen de Python standard library.
- `requirements.txt` bevat geen verplichte third-party package.
- Pillow/PIL is uitsluitend een optionele, niet meegeleverde cacheprestatieverbetering en is niet nodig voor correctheid.
- De browserfrontend laadt geen remote JavaScript- of CSS-package.
- De release bevat geen `node_modules`, vendored packageboom of package-managerlock als productieonderdeel.

De Pythoninterpreter en standard library worden niet in dit ZIP-bestand gebundeld en vallen onder hun eigen upstreamvoorwaarden op de doelserver.

## Projectassets en fixtures

De meegeleverde DXF-, PNG-, JSON- en testfixtures worden als project-eigen audit-/productieassets behandeld. Voor finale externe vrijgave moet de eigenaar de herkomst en gebruiksrechten van merklogo's, materiaalafbeeldingen en andere aangeleverde bedrijfsassets organisatorisch bevestigen. Deze broncodegate kan eigendomsrechten niet zelfstandig bewijzen.

## Auditgrens

`R9J2_SOURCE_SBOM.cdx.json` beschrijft de source/runtimecomponenten in dit artifact. Een onafhankelijke juridische licentiereview en controle van de daadwerkelijk op de VPS geïnstalleerde OS-/proxy-/Pythonpackages blijven vereist voor finale productie-GO.
