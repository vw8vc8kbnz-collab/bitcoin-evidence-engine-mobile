# R9H-2 checkpoint — progress-overlaycomponent

Datum: 22 augustus 2026  
Status: ontwikkelcheckpoint, R9H 2/10  
Voorgestelde annotated tag: `r9h-progress-overlay-component-checkpoint`

## Uitkomst

De grote optimalisatie-overlay en de kleine fail-safe voortgangsbadge hebben één
native eigenaar: `app/tool-a/components/progress-overlay.js`. Deze component
bezit creatie, dynamische stijl, markup, voortgangsweergave, scroll-lock en
fallbackstatus.

De bestaande namen `hideMetodProgressOverlay` en `updateMetodProgressBadge`
blijven tijdelijk als dunne delegatie beschikbaar voor de oude applicatiecode.
De autoritatieve prijscontrole leest de fallbackstatus via dezelfde native
component en inspecteert de progress-DOM niet meer rechtstreeks. De adapters
blijven bewust staan tot R9RC1.

## Exact behouden gedrag

- afgeronde en op 0–100 begrensde percentages;
- minimaal 6% zichtbare balkvulling;
- minimaal 8 graden en maximaal 360 graden ringvulling;
- `…` en 6% als onbekende voortgang;
- bestaande Nederlandse standaard- en fallbackteksten;
- grote overlay boven desktop en mobiel met dezelfde responsive CSS;
- kleine badge wanneer de grote overlay niet kan worden gemaakt;
- body-scroll blokkeren tijdens busy en exact herstellen bij sluiten;
- DOM-, overlay-, badge- en stijlhergebruik zonder duplicaten;
- no-throw gedrag bij ontbrekende DOM-capabilities.

## Architectuurgrens

- 11 expliciet toegestane native modules;
- twee beoordeelde DOM-componenten: `components/dialog.js` en
  `components/progress-overlay.js`;
- precies twee netwerkmodules: `api/jobs.js` en `api/requests.js`;
- geen storage in de native moduleboom;
- precies één tijdelijke compatibilityglobal: `ToolAR9Foundation`;
- de frozen foundationadapter publiceert drie progressmethoden naast het reeds
  bewezen R9H-1-oppervlak.

## Visuele fingerprints

| Onderdeel | Bytes | SHA-256 |
|---|---:|---|
| progress-CSS | 3.866 | `a7471c9450e2085ac2a5070bebeb6cbfa2ec3f2b2e9630921e9a1805d2e916c3` |
| progress-markup | 1.000 | `798b96c1137edcc7b6dbfdc1d2b43f69cb48d205730619d8150ace9e81b9642d` |

## Beschermde fingerprints

| Onderdeel | SHA-256 |
|---|---|
| optimizer | `42480b301cd660dac1e5e9fec2c8d30bb5c6826c32234a9c1cce765b758bebb8` |
| DXF-geometrie | `b80a2d006241908bf7b33516f7e0faf59ef61e1e08db86966b23cc5de292c1ff` |
| pricinghelpers | `646c2f5186e9b080f6ba8dcf364884411c18e946254bb5c9001647f7cbb425df` |
| panelcontract | `e23314fd63a2358a48daa580a92cebb8a40c9862548ba0243461a59347da7fc9` |
| `buildJobPayload()` | `342dac02c2650ac2798e20e62d38d8e1e6b7d518a54daa8fd760d734ae527e47` |

De jobpayloadbuilder blijft exact 9.697 bytes.

## Bewijsstatus

- R9H-2 progress-/ownershiptests: 12/12 PASS;
- R9H-1 dialog-/ownershiptests: 11/11 PASS;
- R9B-architectuurgate en 16 foundationtests: PASS;
- bestaande R9G- en FIX660-regressies: verplicht PASS;
- complete kandidaat- en uitgepakte artifactpreflight: verplicht PASS;
- verse R8Z↔R9H-2 black-boxoracle: verplicht 12/12 fixtures en 47/47 assertions;
- echte iOS WebKit/Safari: `DEFERRED NO-GO`;
- productie-identieke VPS/load/chaos/TLS/firewall/backup-restore/CAM:
  `DEFERRED NO-GO`.

Dit checkpoint verleent geen productie-GO. De volgende gecontroleerde stap is
R9H-3: mobile-cart/bottom-sheet.
