# R9O9 externe-audit security- en privacyremediation

Status: `PROVISIONAL_DEVELOPMENT_ONLY`  
Productie: `NO_GO`

R9O9 is een smalle runtimewijziging naar aanleiding van een onafhankelijke
statische en uitvoerbare audit van R9O8/R9O7. De R9O8 Chromium/WebKit-PASS blijft
authentiek bewijs voor exact R9O7, maar geldt niet automatisch voor de gewijzigde
R9O9-runtime. Een nieuwe externe Chromium/WebKit-run is verplicht.

## Opgeloste blockers

- Admincredentials hebben nog maar één runtimebron: het aangewezen JSON-bestand.
- Production hardening weigert `ADMIN_USER`, `ADMIN_PASS`, `ADMIN_PASS_HASH` en
  `ADMIN_TOTP_SECRET` vóór socketbinding.
- Plaintext en onbekende passwordformaten worden nooit meer geaccepteerd.
- Nieuwe productiehashes gebruiken PBKDF2-HMAC-SHA256 met 600.000 iteraties.
  Oude 260.000-iteratiehashes zijn alleen verifieerbaar voor een gecontroleerde
  migratie; productiepreflight en deployment vereisen direct 600.000.
- Login-throttling geldt per bron-IP én per genormaliseerd account.
- Rate-limitstate heeft een harde bovengrens van 10.000 sleutels.
- Publieke jobwaarschuwingen loggen geen client-IP meer; tekst- en gestructureerde
  redactie verwijderen IPv4, IPv6 en IP-velden.
- Actieve laag-volume applicatielogs vallen nu ook onder de harde leeftijdsgrens.
- Nginx gebruikt eigen access/errorlogs met dagelijkse rotatie en `maxage 30`.
- De dubbele `_dir_size_bytes`-owner is verwijderd.
- `admin.js` bezit zijn eigen HTML-escape-alias en is niet meer afhankelijk van
  de globale laadvolgorde van `dxf.js`.
- `start_server.bat` bevat geen `admin/change-me`-credentials meer.

## Exacte frontendstatus

Admin is professioneel gesplitst in templates, CSS en JavaScript. Tool A is
professioneel geëxternaliseerd en auditbaar, maar blijft bewust een
compatibiliteitsarchitectuur: `toolA.html` laadt negen stylesheets en tachtig
scripts in totaal. Daarbinnen vormen 34 genummerde shellscripts het verzegelde
compatibiliteitscontract. `script-06-legacy-application-runtime.js` blijft actief.
De HTML bevat geen inline `<script>`- of `<style>`-elementen en geen inline
eventhandlers, maar wel 157 gedraggebonden `style`-attributen. Daarom blijft
`style-src-attr 'unsafe-inline'` expliciet nodig; `script-src-attr 'none'` en de
noncegebaseerde script-CSP blijven gehandhaafd.

## Exacte Pythonstatus

De backend heeft afgebakende services en één composition root, maar
`app/server_py.py` is nog een grote transitionele façade. R9O9 claimt niet dat
de historische optimizer- en serverkern volledig herschreven of klein zijn.
Grote structurele extracties worden alleen per eigenaar uitgevoerd met
uitkomstequivalentie; een brede rewrite vlak vóór fysieke acceptatie is verboden.

## Verplicht resterend bewijs

- nieuwe hermetische artifactbuild en alle lokale gates;
- nieuwe externe Chromium/WebKit-gate tegen exact R9O9;
- fysieke iPhone/Mobile Safari en een tweede ondersteunde iOS/Safari-versie;
- productie-identieke DNS/TLS/Nginx/systemd/firewall-controle;
- onafhankelijke SAST/DAST, volledige Git-history secretscan, dependency/CVE- en
  licentiebeoordeling en gerichte pentest;
- formele privacygrondslag, bewaartermijnen, verwerkers en betrokkenenrechten;
- versleutelde off-host backup plus schone restore;
- monitoring/alerts, load/chaos/soak, catalogus/pricing/CAM/werkplaats/fysieke
  proefsnede en formele eigenaarsgoedkeuring.

Geen van deze open poorten mag met lokale PASS-resultaten worden gelijkgesteld.
