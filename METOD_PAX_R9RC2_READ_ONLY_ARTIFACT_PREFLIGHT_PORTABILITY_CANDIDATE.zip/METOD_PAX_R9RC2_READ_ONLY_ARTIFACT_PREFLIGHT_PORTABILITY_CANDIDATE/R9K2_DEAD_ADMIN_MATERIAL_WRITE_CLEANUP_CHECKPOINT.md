# R9K2 — dode Admin-materiaalwritecode verwijderd

R9K2 start exact vanaf `r9k1-dormant-admin-auth-cleanup-checkpoint` en verwijdert
uitsluitend statements die onbereikbaar stonden na de eerste onvoorwaardelijke
HTTP 410-return in vier Admin-materiaalhandlers:

- `_api_admin_materials_save_item`;
- `_api_admin_materials_delete_item`;
- `_api_admin_materials_upload`;
- `_api_admin_material_image_upload`.

Methodehandtekeningen, routebindingen en de actieve response bleven exact gelijk.
De echte R9K1-wirefixture is voor alle vier routes: HTTP 410, contenttype
`application/json; charset=utf-8`, 115 bytes en body-SHA-256
`d24352320ea66ca2c49c338309c6c58a0d80bedce9697f39e1d23ee800a6ad8a`.
De proces-HTTP-test verstuurt bewust ongeldige JSON om te bewijzen dat deze
deprecated routes de body niet meer lezen en controleert tevens dat materiaal-
en mediastate niet veranderen.

De server is daardoor 15.662 bytes en 231 regels kleiner. In totaal verdwenen
24 top-level AST-statements. De actieve CSV-preview/publicatie/taxonomie/
image-retrypaden, Admin-authenticatie, dispatcher, JSON-serializer, routes,
optimizer, geometrie, pricing en panelcontracten bleven beschermd.

Dit is een provisioneel auditcheckpoint, geen productie-GO. Browser-, VPS-, echte
iPhone/Safari-, onafhankelijke security- en productie-evidence blijven vereist.
R9K3, `_merge_raw_quotes`, custom-env rollback en HTML/CSS/JS-extractie zijn
expliciet niet meegenomen.
