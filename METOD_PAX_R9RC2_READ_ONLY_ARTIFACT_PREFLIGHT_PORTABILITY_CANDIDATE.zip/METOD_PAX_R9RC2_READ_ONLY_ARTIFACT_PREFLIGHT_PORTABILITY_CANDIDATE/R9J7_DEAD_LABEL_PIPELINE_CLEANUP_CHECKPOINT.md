# R9J-7 dead label pipeline cleanup

Status: **PROVISIONAL_DEVELOPMENT_ONLY**. Dit checkpoint is niet vrijgegeven
voor productie. Browser-, VPS- en onafhankelijke-auditbewijzen blijven
expliciet `DEFERRED_NO_GO`.

## Resultaat

De ongebruikte schema-v1-labelgenerator `_generate_labels_json` en haar twee
exclusieve helpers `_edge_name_from_code` en `_guess_sheet_dxf_file` zijn uit
`app/server_py.py` verwijderd. De generator had nul AST name-loads; de helpers
werden uitsluitend vanuit die dode generator geladen.

De actieve route is niet gewijzigd. `JobFinalizationService` gebruikt nog
precies één callback naar `_generate_labels_json_strict`. Deze actieve,
fail-closed schema-v2-generator is bronsegment-byte-exact gebleven.

## Meetbaar effect

- `server_py.py`: 724.847 -> 718.193 bytes;
- `server_py.py`: 14.884 -> 14.706 regels;
- netto productiebronkrimp: 6.654 bytes en 178 regels;
- geen nieuwe productieadapter, module of compatibilitylaag toegevoegd.

## Gedragsbewijs

`tools/r9j7_dead_label_pipeline_cleanup_tests.py` bewaakt zeven contracten:

1. de drie obsolete definities zijn volledig afwezig;
2. uitsluitend legacy schema-v1-labelmarkers zijn verwijderd;
3. de strict-generator blijft de enige actieve labelowner;
4. `JobFinalizationService` behoudt exact één strict-labelcallback;
5. het actieve strict-functiesegment blijft byte-exact;
6. serveridentiteit en meetbare krimp zijn afgedicht;
7. status, gedragspolicy en bewijsomvang zijn machineleesbaar vastgelegd.

De bestaande R9E-finalisatiesuite blijft 10/10 groen en de echte
serverlifecyclesuite 11/11. De volledige golden-, HTTP-, reset-, security-,
clean-code- en standalonegates blijven voor dit checkpoint verplicht.

## Release-identiteit

- release: `R9J7`;
- build: `R9J7_DEAD_LABEL_PIPELINE_CLEANUP`;
- artifact: `METOD_PAX_R9J7_DEAD_LABEL_PIPELINE_CANDIDATE.zip`;
- voorgenomen tag: `r9j-dead-label-pipeline-cleanup-checkpoint`;
- immutable golden behavior oracle: `R8Z`;
- runtime-compatibiliteitsbuild: `FIX660R8_PRELIVE_HARDENED`.

De complete checkpointbundel moet opnieuw de echte tool-ZIP, R8Z-golden,
volledige Git-historie en alle machineleesbare verificatierapporten bevatten.
