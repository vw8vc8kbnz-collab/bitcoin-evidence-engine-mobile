# R9H-4 checkpoint — wizardfooter

Datum: 22 augustus 2026  
Status: ontwikkelcheckpoint, R9H 4/10  
Voorgestelde annotated tag: `r9h-footer-component-checkpoint`

## Uitkomst

De gedeelde wizardfooter heeft één native DOM-/eventeigenaar:
`app/tool-a/components/footer.js`. Deze component bezit de vijfstapsbeslissingen,
viewstate, deterministische knoppen, disabled-/editstatus, vorige-/volgende- en
overzichtsbindings en gecontroleerde verplaatsing naar en uit de mobiele
panelendrawer.

De vier oude runtimes `toolA_footer_decisions.js`, `toolA_footer_view_state.js`,
`toolA_footer_apply.js` en `toolA_footer_bindings.js` zijn verwijderd, samen met
hun vier globals. Bestaande aanroepplaatsen delegeren tijdelijk via de enige
frozen compatibilitygrens `ToolAR9Foundation`.

## Exact behouden gedrag

- dezelfde vijf stappen: materiaal, panelen, nerfrichting, klant en overzicht;
- dezelfde zichtbaarheid, labels en disabled-status van vorige/volgende;
- materiaal en panelen blijven de bestaande navigatieguards gebruiken;
- klantvalidatie blijft vóór navigatie naar het overzicht plaatsvinden;
- toevoegen/wijzigen houdt dezelfde tekst, editklasse en disabled-regels;
- overzicht sluiten en terug keren naar dezelfde herkomststap;
- precies één set footerknoppen en idempotente listenerbinding;
- de bestaande footer kan gecontroleerd in de mobiele panelendrawer worden
  geplaatst en exact op zijn ankerpositie worden hersteld;
- bestaande markup en alle complete footer-CSS-blokken blijven bytegelijk;
- no-throw gedrag bij ontbrekende DOM-capabilities.

## Architectuurgrens

- 13 expliciet toegestane native modules;
- vier beoordeelde DOM-componenten: `components/dialog.js`,
  `components/progress-overlay.js`, `components/mobile-material-cart.js` en
  `components/footer.js`;
- precies twee netwerkmodules: `api/jobs.js` en `api/requests.js`;
- geen storage in de native moduleboom;
- precies één tijdelijke compatibilityglobal: `ToolAR9Foundation`;
- de frozen foundationadapter bevat 35 sleutels en publiceert vier tijdelijke
  footermethoden naast het reeds bewezen R9H-3-oppervlak.

## Visuele fingerprints

| Onderdeel | Bytes | SHA-256 |
|---|---:|---|
| vaste wizardfootermarkup | 1.127 | `d2d84c32f6b60cd6b3708b6b5987ac58390dceb2fae0b9ff03e80437795f3562` |
| 14 complete footer-CSS-blokken | 139.538 | `3192b4fc83ec0b62463ae702873df7ec2a22acb12fd8f0f713b17f0715a947a1` |

## Beschermde fingerprints

| Onderdeel | SHA-256 |
|---|---|
| optimizer | `42480b301cd660dac1e5e9fec2c8d30bb5c6826c32234a9c1cce765b758bebb8` |
| DXF-geometrie | `b80a2d006241908bf7b33516f7e0faf59ef61e1e08db86966b23cc5de292c1ff` |
| pricinghelpers | `646c2f5186e9b080f6ba8dcf364884411c18e946254bb5c9001647f7cbb425df` |
| panelcontract | `e23314fd63a2358a48daa580a92cebb8a40c9862548ba0243461a59347da7fc9` |
| job-API-owner | `d8ab88690f44ae053c4ef33df60807f0daf6eeba9c335dec814fb48d30a8be6a` |
| request-API-owner | `4760bfd9733c8739ca96a15cdb3c8f3ef65028b3e95d61c061721cbe125c445e` |
| dialogowner | `19ef5855b144fd4cbfd551566560b3294e5571c6025c6824f5645430166ff928` |
| progressowner | `cd8ede9e209702b5a855982eba6f89b641fa725a3892dc421203db3fe32033bf` |
| mobile-cartowner | `9cdd9cba78e651d6f2376079d90febf576d01f88f4b1cb91e86a4626c9ebd44f` |
| `buildJobPayload()` | `342dac02c2650ac2798e20e62d38d8e1e6b7d518a54daa8fd760d734ae527e47` |

De jobpayloadbuilder blijft exact 9.697 bytes.

## Bewijsstatus

- R9H-4 footer-/ownershiptests: 12/12 PASS;
- R9H-3 mobile-cart-/ownershiptests: 12/12 PASS;
- R9H-2 progress-/ownershiptests: 12/12 PASS;
- R9H-1 dialog-/ownershiptests: 11/11 PASS;
- R9B-architectuurgate en 16 foundationtests: PASS;
- bestaande 83 R9G-tests, route- en FIX660-regressies: verplicht PASS;
- complete kandidaat- en uitgepakte artifactpreflight: verplicht PASS;
- verse R8Z↔R9H-4 black-boxoracle: verplicht 12/12 fixtures en 47/47 assertions;
- echte iOS WebKit/Safari: `DEFERRED NO-GO`;
- productie-identieke VPS/load/chaos/TLS/firewall/backup-restore/CAM:
  `DEFERRED NO-GO`.

Dit checkpoint verleent geen productie-GO. De volgende gecontroleerde stap is
R9H-5: materiaalkaart.
