# R9J-6 dead finalization cleanup

Status: **PROVISIONAL_DEVELOPMENT_ONLY**. Dit checkpoint is niet vrijgegeven
voor productie. Browser-, VPS- en onafhankelijke-auditbewijzen blijven
expliciet `DEFERRED_NO_GO`.

## Resultaat

De 117 regels tellende functie
`_finalize_subjob_outputs_legacy_unused` is uit `app/server_py.py` verwijderd.
De functie was een oude, dubbele finalisatie-implementatie met nul AST-referenties
en nul referenties buiten haar eigen definitie.

De actieve route is niet gewijzigd: optimizerafronding roept nog steeds precies
één keer de serveradapter `_finalize_subjob_outputs` aan, die uitsluitend
delegeert naar `JobFinalizationService` in
`app/metod_app/jobs/finalization.py`.

## Meetbaar effect

- `server_py.py`: 730.352 -> 724.847 bytes;
- `server_py.py`: 15.003 -> 14.884 regels;
- netto productiebronkrimp: 5.505 bytes en 119 regels;
- geen nieuwe productieadapter, module of compatibilitylaag toegevoegd.

## Gedragsbewijs

`tools/r9j6_dead_finalization_cleanup_tests.py` bewaakt zeven contracten:

1. de obsolete eigenaar is volledig afwezig;
2. uitsluitend bij die eigenaar horende foutpaden zijn verwijderd, terwijl de
   publieke compatibility-buildmarker behouden blijft;
3. `JobFinalizationService` blijft de enige actieve eigenaar;
4. optimizerafronding roept de actieve adapter exact één keer aan;
5. de actieve finalisatiemodule blijft byte-exact;
6. serveridentiteit en meetbare krimp zijn afgedicht;
7. status, gedragspolicy en bewijsomvang zijn machineleesbaar vastgelegd.

De bestaande R9E-finalisatiesuite blijft daarnaast 10/10 groen. De volledige
golden-, HTTP-, reset-, security-, clean-code- en standalonegates blijven voor
dit checkpoint verplicht.

## Release-identiteit

- release: `R9J6`;
- build: `R9J6_DEAD_FINALIZATION_CLEANUP`;
- artifact: `METOD_PAX_R9J6_DEAD_FINALIZATION_CANDIDATE.zip`;
- voorgenomen tag: `r9j-dead-finalization-cleanup-checkpoint`;
- immutable golden behavior oracle: `R8Z`;
- runtime-compatibiliteitsbuild: `FIX660R8_PRELIVE_HARDENED`.

De complete checkpointbundel moet opnieuw de echte tool-ZIP, R8Z-golden,
volledige Git-historie en alle machineleesbare verificatierapporten bevatten.
