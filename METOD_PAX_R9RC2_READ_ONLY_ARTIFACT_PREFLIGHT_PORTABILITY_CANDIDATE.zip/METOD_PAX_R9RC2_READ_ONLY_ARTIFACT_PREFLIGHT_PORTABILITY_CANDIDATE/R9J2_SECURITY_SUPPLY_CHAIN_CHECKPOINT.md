# R9J-2 security- en supply-chaincheckpoint

Status: **PROVISIONAL DEVELOPMENT CHECKPOINT**  
Release-eligibility: **NO_GO totdat externe browser-, VPS-, onafhankelijke security- en operationele gates aantoonbaar PASS zijn**

## Doel

Iedere bron- en artifactbuild moet fail-closed controleren op hoog-signaal secrets, gevaarlijke uitvoerings-API's, onverklaarde dependencies, remote frontendpackages, licentie-/SBOM-ontbreken en groei van bestaande DOM-injectiesinks. De workflow moet daadwerkelijk actief zijn in `.github/workflows` op repositoryniveau.

## Lokale gate

`tools/r9j2_supply_chain_gate.py` controleert het volledige releaseartifact met uitsluitend Python standard library:

- negen secretfamilies zonder gevonden geheimbytes in rapporten terug te schrijven;
- verboden Pythoncalls, `subprocess(..., shell=True)` en onveilige YAML-load;
- shell download-pipes, `eval`, `chmod 777` en `mktemp -u`;
- nul `eval`, `new Function`, `document.write` en remote frontendimports;
- fail-closed inventaris van 91 `innerHTML`-assignments en één `insertAdjacentHTML`-sink, zodat groei niet stil kan plaatsvinden;
- lege verplichte `requirements.txt`, alleen optionele niet-gebundelde PIL-import en nul mandatory third-party Pythonimports;
- CycloneDX source-SBOM, proprietary licentiebeleid en zeven beschermde applicatiehashes.

## Repositoryworkflow

De actieve workflow staat in de repositoryroot en:

- gebruikt alleen read-permissions;
- weigert mutabele actiontags doordat alle `uses:`-regels commit-pinned moeten zijn;
- draait repository- en release-securitygates;
- bouwt het echte product-ZIP;
- pakt dat ZIP uit in een lege map en draait daar de volledige preflight;
- controleert dat de committed `candidate/SHA256SUMS.txt` door de build niet verandert.

## Bewijsgrens

Dit is een deterministische first-party gate. Zij vervangt niet: onafhankelijke vendor-SAST, volledige Git-historie-secret scan, externe CVE-database, juridische licentiereview, pentest, echte hosted GitHub-run, Chromium/WebKit/Safari of VPS-runtimebewijs. Die grenzen blijven expliciet NO_GO tot afzonderlijk bewijs beschikbaar is.
