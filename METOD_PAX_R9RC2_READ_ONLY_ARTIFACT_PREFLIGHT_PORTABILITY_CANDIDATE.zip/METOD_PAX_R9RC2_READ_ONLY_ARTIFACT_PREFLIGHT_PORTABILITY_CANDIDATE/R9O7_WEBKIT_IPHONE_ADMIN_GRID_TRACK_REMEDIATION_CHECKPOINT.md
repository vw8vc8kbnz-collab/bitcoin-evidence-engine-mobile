# R9O7 WebKit-iPhone Admin grid-track remediation

## Besluit

R9O7 is een smalle audit-candidate en blijft **NO-GO voor productie** totdat de onafhankelijke R9O8 Chromium/WebKit-run alle 15 fixtures en alle 100 contractasserties als PASS bindt.

## Onafhankelijke aanleiding

De ontvangen R9O6-evidence-ZIP heeft SHA-256 `d49ee1875baf9e31e7e1050221e79109c73d7578db16a5c21d08f7666530cbf0`; de ZIP-CRC en alle interne bewijschecksums zijn geverifieerd. R9O6 leverde 14/15 fixtures en 99/100 assertions PASS. Alleen `admin-presentation-session-assets` faalde, uitsluitend in `webkit-iphone`: `bodyScrollWidth=492` bij `viewportWidth=393`. De andere drie profielen slaagden en er waren geen blockers.

De door R9O5 toegevoegde diagnose lokaliseert het eerste overlopende element als `section#adminSection-inbox.adminSection.active`: links `80px`, rechts `492.39px`, breedte `412.39px`, `min-width:auto`. Alle gemelde kinderen passen binnen die 412px. Daarmee is bewezen dat niet de tabstrip, maar de impliciete `auto`-gridtrack van `.adminPages` de resterende intrinsieke minimumbreedte vasthoudt.

## Correctie

Binnen het bestaande mobiele breakpoint krijgt `.adminPages` één expliciete `minmax(0,1fr)`-kolom. `.adminSection` krijgt `min-width:0` en `max-width:100%`. Hierdoor kan WebKit de actieve Admin-pagina verkleinen tot de werkelijk beschikbare contentkolom naast de navigatierail.

Er wordt geen overflow verborgen en de bestaande viewportassertie blijft volledig ongewijzigd en fail-closed.

## Niet gewijzigd

- optimizer, nesting, geometrie en prijzen;
- aanvraag-, job- of downloadgedrag;
- de immutable R8Z golden baseline;
- browser-, console- of page-errorbeleid;
- fixtures, profielen, engines, assertions of timeouts.

## Vereiste vervolgstap

Voer `operations/RUN_R9O8_EXTERNAL_BROWSER_GATE_TMUX.sh` uit op de externe VPS. Alleen een cryptografisch gebonden PASS met 15/15 fixtures, 100 assertions, Chromium én WebKit kan deze browserpoort sluiten. Overige productiepoorten blijven daarna afzonderlijk vereist.
