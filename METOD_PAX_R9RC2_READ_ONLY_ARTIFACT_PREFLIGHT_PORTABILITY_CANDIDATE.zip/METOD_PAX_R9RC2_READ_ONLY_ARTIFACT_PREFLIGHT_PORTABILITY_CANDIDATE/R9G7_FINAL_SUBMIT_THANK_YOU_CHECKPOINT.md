# R9G-7 checkpoint — definitieve submit/thank-you

Datum: 22 augustus 2026
Status: ontwikkelcheckpoint, R9G 7/8
Voorgestelde annotated tag: `r9g-final-submit-thank-you-checkpoint`

## Scope

Deze stap verplaatst uitsluitend de definitieve Tool A-submitketen naar één
native eigenaar. Optimizer, DXF-geometrie, jobpayloadbuilder, prijsregels,
publieke submitroute en server-side submissionservice zijn inhoudelijk niet
gewijzigd.

## Nieuwe eigenaar

`app/tool-a/api/requests.js` bezit nu:

- exact één `POST /api/submit_config`;
- de expliciete toestanden `idle`, `submitting`, `committed` en `failed`;
- inflight-deduplicatie voor dubbeltikken;
- parentjob- en completionproof vóór netwerk-I/O;
- parentjobbearer, compacte wirepayload en responsevalidatie;
- de harde eis van een niet-lege `requestId` vóór `committed`;
- herstelbare `failed`-state en expliciete reset voor een nieuwe configuratie.

De vroege document-capture in `toolA.html` blijft de enige fysieke Safari-clickadapter.
Hij roept de bestaande dunne UI-adapter aan. De vroegere targetlistener, de latere
fallbacklistener en het geladen `toolA_final_submit_bridge.js`-pad zijn uit de
productie-HTML verwijderd. Het historische bridgebestand blijft in deze stap nog
onaangeroerd als inactief compatibility-asset; R9G-8 beslist over definitieve
bestandsopruiming.

## Gedragscontract

- Eén tik geeft maximaal één POST.
- Een tweede tik tijdens `submitting` wordt genegeerd.
- Thank-you wordt exact eenmaal en pas na een committed requestreferentie aangeroepen.
- HTTP-fout, netwerkfout, onleesbare JSON, `{ok:false}` of ontbrekende `requestId`
  laat de prijs-overlay herstelbaar en maakt retry mogelijk.
- De volledige in-memory klantmomentopname en notitie blijven behouden.
- `Nieuwe configuratie` wist native submitstate plus de bestaande PII/job/requestcapabilities.
- Submit start nooit een tweede `/api/jobs`-actie.

## Beschermde fingerprints

| Onderdeel | SHA-256 |
|---|---|
| `dxf_nesting_optimizer.py` | `42480b301cd660dac1e5e9fec2c8d30bb5c6826c32234a9c1cce765b758bebb8` |
| `dxf_geometry.py` | `b80a2d006241908bf7b33516f7e0faf59ef61e1e08db86966b23cc5de292c1ff` |
| `pricing_helpers.py` | `646c2f5186e9b080f6ba8dcf364884411c18e946254bb5c9001647f7cbb425df` |
| `panel_contract.py` | `e23314fd63a2358a48daa580a92cebb8a40c9862548ba0243461a59347da7fc9` |
| `buildJobPayload()` | `342dac02c2650ac2798e20e62d38d8e1e6b7d518a54daa8fd760d734ae527e47` |

De jobpayloadbuilder is 9.697 bytes en byte-exact gelijk aan de oorspronkelijke
R9G-6-checkpointtag uit de herstelde Git-bundle.

## Bewijs

- Nieuwe R9G-7-suite: 13/13 PASS.
- R9B architecture gate: 9 frontendmodules, exact één compatibilityglobal, PASS.
- Alle bestaande R9G read-consumer/jobpollertests: PASS.
- FIX660 functionele regressiesuite: PASS.
- Server submissionservice: 9/9 PASS.
- Server lifecycle inclusief canonical customer → exact één Adminrequest: 11/11 PASS.
- Performancecontract: 11/11 PASS.
- Security/privacycontract: 7/7 PASS.
- R9F routecatalogus/dispatch blijft 70 routes en 25 POST-routes; alleen de
  statische allowlist bevat één extra native modulebestand.

De complete bronpreflight en een volledig uitgepakte artifactpreflight zijn PASS,
inclusief interne checksumdekking, alle Python-/JavaScript-syntaxchecks en alle
geregistreerde R9B–R9G-/FIX660-tests. De definitieve artifacthash wordt buiten dit
interne rapport vastgelegd, zodat het rapport zelf onderdeel van dezelfde sealed
artifact kan blijven.

## Hersteld uitvoerbaar bewijs

De aanvullende complete overdracht heeft de oorspronkelijke Git-bundle, alle
36 annotated checkpointtags en de immutable R8Z-goldenboom hersteld. R9G-7 is
daarom opnieuw op de echte R9G-6-parent geplaatst en fail-closed aan de volledige
scopecontractketen gebonden. De verse R8Z↔R9G-7 server-black-boxoracle levert
12/12 fixtures en 47/47 assertions PASS, zonder skip, xfail of blocker. De golden
R8Z-boom zelf heeft vooraf alle 153 interne checksums en de volledige preflight
doorstaan.

## Open poorten

- R9G-8 ownershipcleanup is nog niet uitgevoerd.
- Echte iOS WebKit/Safari blijft deferred NO-GO.
- Productie-identieke VPS/load/chaos/TLS/firewall/backup-restore/CAM-audit blijft
  deferred NO-GO.
- Dit checkpoint is geen productie-GO.
