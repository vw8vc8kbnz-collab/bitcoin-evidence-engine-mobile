# R9I-7 — shadowed price-overlay owner cleanup

Status: **PROVISIONAL DEVELOPMENT CHECKPOINT — NO GO**

Basis: `r9i-dead-customer-overlay-cleanup-checkpoint`

## Uitgevoerd

- Eén overschreven `openPriceOverlay`-implementatie en één overschreven `closePriceOverlay`-implementatie zijn uit de legacy-runtime verwijderd.
- Beide oude declaraties stonden in dezelfde runtimeclosure als de latere gelijknamige declaraties. Door JavaScript function-hoisting konden uitsluitend de latere definities actief zijn.
- De resterende lokale open/closefuncties, alle consumenten en de bestaande `window.openPriceOverlay`-publicatie zijn ongewijzigd behouden.
- De autoritatieve prijslaag, pricing-summaryfetch, btw-/afrondingslogica, checkoutreview en definitieve submitstate-machine zijn byte-exact behouden.

## Meetbare clean-codewinst

| Grens | R9I-6 | R9I-7 | Delta |
|---|---:|---:|---:|
| Legacy-runtime | 437.686 bytes / 9.612 regels | 437.280 bytes / 9.596 regels | −406 bytes / −16 regels |
| Volledige klassieke scriptstream | 498.682 bytes | 498.276 bytes | −406 bytes |
| Lokale `openPriceOverlay`-definities | 2 | 1 | −1 shadow owner |
| Lokale `closePriceOverlay`-definities | 2 | 1 | −1 shadow owner |
| Native modules | 19 | 19 | ongewijzigd |
| Gecontroleerde DOM-eigenaars | 10 | 10 | ongewijzigd |
| Netwerkeigenaars | 2 | 2 | ongewijzigd |
| Klassieke shellscripts | 34 | 34 | ongewijzigd |

Sinds de R9I-baseline is de legacy-runtime in totaal 12.048 bytes en 294 regels gekrompen.

## Expliciet ongewijzigd

- prijs-summaryfetch en autoritatieve totaalprijs incl. btw;
- prijsweergave, pending-state en submitvalidatie;
- actieve klantflow, checkoutreview en definitieve submit;
- DXF-optimizer, geometrie, plaatsing en paneelcontract;
- publieke API-routes, methodes, statussen en payloads;
- DXF-bytes, namen, ZIP-plaatsingen, manifests en outputhashcontracten;
- PII-opslag- en redactiebeleid;
- CSS-stream en de 19/10/2/1/34-architectuurgrens.

## Bewijsgrenzen

- `R9I7_PRICE_OVERLAY_SHADOW_CLEANUP.json` sluit runtime, klassieke scriptstream, prijscompatibiliteitslagen, netwerkeigenaars en functional-truthbestanden fail-closed af.
- `tools/r9i_price_overlay_shadow_owner_tests.py` reconstrueert de huidige runtime exact uit R9I-6 door alleen het shadowblock te verwijderen.
- Dezelfde test bewijst exact één resterende lokale open/closeowner en byte-exacte prijs-, checkout- en submitlagen.
- `tools/r9i_clean_code_gate.py` verbiedt terugkeer van een tweede lokale prijs-overlayowner.

## Resterende gates

Dit checkpoint is geen productie-GO. De productie-identieke VPS-proef en verplichte Chromium/WebKit/Safari-browserevidence blijven open. Verdere samenvoeging van de prijscompatibiliteitslagen vereist eerst een expliciete gedragsequivalentietest in beide browserengines.
