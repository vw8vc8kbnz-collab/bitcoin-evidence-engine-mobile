# R9I-5 — generieke overlay-router cleanup

Status: **PROVISIONAL DEVELOPMENT CHECKPOINT — NO GO**

Basis: `r9i-job-cancel-route-cleanup-checkpoint`

## Uitgevoerd

- `app/tool-a/components/overlay-router.js` is de enige native DOM-eigenaar voor `overlay`, `grainOverlay`, `extraOverlay` en `overviewOverlay`.
- De eigenaar beheert zichtbaarheid, actieve-overlaystate, aliases, scroll lock, backdrop-dismissal en beide click-blocker-watchdogs.
- De 350 ms dismissalguard en beide intervallen van 500 ms zijn als exact gedragscontract behouden.
- `script-06-legacy-application-runtime.js` bevat alleen nog dunne adapters voor `setOverlayVisible`, `hideAllOverlays`, `openOverlay` en `closeOverlay`.
- De oude DOM-mutaties in `ToolADomHelpers` zijn verwijderd; `setGrainMsg` blijft daar ongewijzigd beschikbaar.
- De publieke moduleallowlists in server en matcher kregen exact één nieuw statisch bestand. API-routes, methodes, statussen en payloads zijn niet gewijzigd.

## Meetbare clean-codewinst

| Grens | R9I-4 | R9I-5 | Delta |
|---|---:|---:|---:|
| Legacy-runtime | 445.821 bytes / 9.811 regels | 441.207 bytes / 9.695 regels | −4.614 bytes / −116 regels |
| Volledige klassieke scriptstream | 506.817 bytes | 502.203 bytes | −4.614 bytes |
| `setInterval(` in legacy-runtime | 5 | 3 | −2 |
| `addEventListener(` in legacy-runtime | 157 | 156 | −1 |
| Native modules | 18 | 19 | +1 expliciete eigenaar |
| Gecontroleerde DOM-eigenaars | 9 | 10 | +1 expliciete eigenaar |
| Netwerkeigenaars | 2 | 2 | ongewijzigd |
| Klassieke shellscripts | 34 | 34 | ongewijzigd |

## Expliciet ongewijzigd

- DXF-optimizer, geometrie, plaatsing en paneelcontract;
- prijs-/btw-/afrondingslogica en catalogustruth;
- job- en requestnetwerkeigenaars;
- publieke API-routes, methodes, statussen en payloads;
- DXF-bytes, namen, ZIP-plaatsingen, manifests en outputhashcontracten;
- PII-opslag- en redactiebeleid;
- CSS-stream en semantische HTML-structuur.

## Bewijsgrenzen

- `R9I5_OVERLAY_ROUTER_CLEANUP.json` sluit runtime-, klassieke stream-, component-, helper-, guard-, allowlist- en protected-filehashes fail-closed af.
- `tools/r9i_overlay_router_tests.py` bewijst initialisatie, aliases, open/close, 350 ms-guard, backdropgedrag, beide watchdogs, teardown en single-ownerarchitectuur.
- `tools/r9i_clean_code_gate.py` bewaakt cumulatieve en incrementele krimp en verbiedt terugkeer van de verwijderde overlaylogica.
- `tools/r9b_architecture_gate.py` eist exact 19 native modules, 10 DOM-eigenaars, 2 netwerkeigenaars en één compatibilityglobal.

## Resterende gates

Dit checkpoint is geen productie-GO. Een productie-identieke VPS-proef en de verplichte Chromium/WebKit/Safari-browserevidence blijven open. Tot die tijd blijven verdere visuele/CSS-cleanups en compatibilityverwijderingen geblokkeerd.
