# R9I-8 — ongebruikte prijscompatibiliteit opgeschoond

Status: `PROVISIONAL_DEVELOPMENT_ONLY`  
Release-eligible: **nee** — productie-identieke Chromium/WebKit/Safari-evidence op de VPS blijft verplicht.

## Afgebakende wijziging

R9I-8 verwijdert uitsluitend aantoonbaar ongebruikte code uit
`app/tool-a/shell/script-08-compat.js`:

- vier ongebruikte `window.__priceOverlayEls`-cachevelden;
- de ongebruikte lokale `send`-referentie;
- de onbereikbare helper `computeTotalInclFromQuote`.

De complete compatibiliteitsasset daalt daardoor exact van 4.683 naar 3.754 bytes
en van 95 naar 75 regels. De complete klassieke scriptstream daalt exact met
929 bytes, van 498.276 naar 497.347 bytes.

## Bewust beschermd

De actieve `window.openPriceOverlay`- en `window.closePriceOverlay`-paden blijven
behouden. Ook de serverprijsbron, pending-guard, checkout-review, final-submit,
thank-you, jobs/requests API, legacy runtime, optimizer, geometrie, prijshelpers,
panelcontract en grainrenderer blijven byte-exact gelijk aan R9I-7.

De HTML-wijziging bestaat alleen uit cache-revisies voor de gewijzigde
compatibiliteitsasset, de bestaande legacy-runtimeverwijzing en de native
bootstrap. De architectuur blijft begrensd op 19 native modules, 10 DOM-eigenaars,
2 netwerkeigenaars, 1 compatibiliteitsglobal en 34 klassieke scripts.

## Fail-closed bewijs

- `R9I8_UNUSED_PRICE_COMPAT_CLEANUP.json` vergrendelt runtime, klassieke
  scriptstream, gewijzigde compatibiliteitsasset en functionele waarheid met hashes.
- `tools/r9i_unused_price_compat_tests.py` bewijst het exacte remove-only verschil
  ten opzichte van het R9I-7 checkpoint.
- `tools/r9i_clean_code_gate.py` weigert terugkeer van de verwijderde tokens en
  bewaakt de actieve prijscompatibiliteit.
- De volledige preflight, echte HTTP-smoke, golden blackbox, reset/PII/ancestry en
  expliciete browser NO-GO worden opnieuw uitgevoerd voor het checkpointpakket.

## Open releasepoort

Zonder productie-identieke browserruntime worden visuele CSS-fixes,
behavior-gebonden inline styles en verdere browsergevoelige adapters niet
verwijderd. R9I-8 is daarom een controleerbaar ontwikkelcheckpoint, geen GO-live.
