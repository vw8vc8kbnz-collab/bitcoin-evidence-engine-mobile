# R9I-9 — ongebruikte synchrone catalogusrefresh verwijderd

Status: `PROVISIONAL_DEVELOPMENT_ONLY`  
Release-eligible: **nee** — productie-identieke Chromium/WebKit/Safari-evidence op de VPS blijft verplicht.

## Afgebakende wijziging

R9I-9 verwijdert uitsluitend twee lokale functies uit
`app/tool-a/shell/script-06-legacy-application-runtime.js`:

- `_syncRefreshEmbedManifestIfNeeded`, waarvoor geen enkele aanroep bestond;
- `_syncGetJson`, waarvan beide aanroepen uitsluitend binnen die dode functie stonden.

Daarmee verdwijnt ook de laatste synchrone `XMLHttpRequest` uit de runtime. De
legacy-runtime daalt exact van 437.280 naar 435.812 bytes en van 9.596 naar
9.563 regels. De complete klassieke scriptstream daalt eveneens exact met 1.468
bytes, van 497.347 naar 495.879 bytes.

## Bewust beschermd

De actieve asynchrone catalogusroute blijft volledig behouden:
`_loadEmbedManifest`, `refreshEmbeddedDxfCatalogNow`, de initiële warm-up, de
dropdown-refresh, manifestversiecontrole, catalogusrebuild en type-optie-update.

Prijs, checkout, final-submit, thank-you, jobs/requests API, optimizer, geometrie,
prijshelpers, panelcontract en grainrenderer blijven byte-exact gelijk aan R9I-8.
De architectuur blijft begrensd op 19 native modules, 10 DOM-eigenaars, 2
netwerkeigenaars, 1 compatibiliteitsglobal en 34 klassieke scripts.

## Fail-closed bewijs

- `R9I9_SYNC_CATALOG_REFRESH_CLEANUP.json` vergrendelt de exacte runtime- en
  scriptstreamidentiteit, netwerktokentellingen en functionele eigenaars.
- `tools/r9i_sync_catalog_refresh_tests.py` bewijst dat het verschil met R9I-8
  exact uit het ongebruikte synchrone blok bestaat.
- `tools/r9i_clean_code_gate.py` weigert terugkeer van de synchrone keten en
  bewaakt de actieve asynchrone catalogusroute.
- De volledige preflight, echte HTTP-smoke, golden blackbox, reset/PII/ancestry
  en expliciete browser NO-GO worden opnieuw uitgevoerd voor dit checkpoint.

## Open releasepoort

Zonder productie-identieke browserruntime worden visuele CSS-fixes,
behavior-gebonden inline styles en browsergevoelige adapters niet verwijderd.
R9I-9 is daarom een controleerbaar ontwikkelcheckpoint, geen productie-GO.
