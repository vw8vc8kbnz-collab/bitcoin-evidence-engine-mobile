# R9H-10 — Semantische applicatieshell en assetgrenzen

Status: ontwikkelcheckpoint 10/10; geen productie-GO.

`app/toolA.html` is teruggebracht van een monolithisch document naar een
semantische applicatieshell. De volledige CSS-stroom staat, in ongewijzigde
volgorde, in zeven expliciete fasen: `tokens`, `base`, `layout`, `components`,
`mobile`, `grain` en `checkout`. Alle 34 klassieke inline scripts staan als
afzonderlijke bestanden op exact hun bestaande uitvoeringspositie en behouden
daarmee hun eigen klassieke scriptscope.

De byte-ledger verzegelt 246.282 CSS-bytes en 510.324 JavaScriptbytes. Er is
geen selector, declaratie, `fixXXX`-regel of scriptbody verwijderd of
herschreven. Bestaande gedraggebonden `style`-attributen blijven bewust staan:
verwijdering daarvan vereist eerst berekende-stijl- en visuele gelijkheid in
Chromium én WebKit.

De shell gebruikt nu één `main`, één `footer` en benoemde navigatie-/regio-
grenzen. De server en pure routematcher delen een expliciete allowlist voor de
7 stylesheets en 34 shellscripts. De native modulearchitectuur blijft exact 18
modules, 9 DOM-/eventowners en 2 netwerkowners.

Ongewijzigd en buiten scope: optimizer, DXF-geometrie, panelcontract,
payloadbuilder, prijslogica, request-/jobstate-machines, consent, resetlogica en
productieroutes. Safari/WebKit, echte productie-infrastructuur, CAM/CNC en
fysieke proefsnede blijven `DEFERRED NO-GO`.

Bewijs wordt vastgelegd in `contracts/R9H_SEMANTIC_SHELL_SCOPE.json` en
`reports/R9H_SEMANTIC_SHELL_CHECKPOINT.md`.
