# R9L2 — observability/metrics-extractie

R9L2 verplaatst de actieve system-event-, readiness- en Prometheuslogica uit
`app/server_py.py` naar één eigenaar:
`app/metod_app/observability/service.py`.

## Eigenaarsgrens

`ObservabilityService` bezit:

- begrensde, roterende en geredigeerde JSONL-system-events;
- reverse-tail lezen met tolerantie voor beschadigde regels;
- catalogus-, signoff-, pricing-, state-, disk-, inode- en DXF-readiness;
- de elf bestaande Prometheus-gauges en hun vaste tekstvolgorde.

De server houdt vier dunne behavior-adapters en twee gelockte
counter-snapshotadapters. HTTP-authenticatie en de minimale publieke
readinessprojectie blijven aan de transportgrens. Er is geen tweede event-,
readiness- of metricspad geïntroduceerd.

## Gedragbehoud

De pre-extractiefixture verzegelt de volledige R9L1-server, vier actieve
ownerbronnen, consumer-aantallen, het eventrecord inclusief redactie, drie
readinessscenario's, elf metricfamilies en vijf routes. De fixture slaagt na
extractie zonder outputwijziging.

De echte HTTP-processuite verifieert daarnaast de minimale publieke
readinessprojectie, 401-afwijzing van anonieme metrics- en logrequests, de
gedetailleerde geauthenticeerde readinesspayload, het Prometheus-contenttype
met exact elf gaugefamilies en het begrensde system-logantwoord.

`server_py.py` krimpt van 529.902 bytes en 11.612 regels naar 526.841 bytes en
11.542 regels. De nieuwe owner is 11.050 bytes en 287 regels.

## Status

Dit blijft `PROVISIONAL_DEVELOPMENT_ONLY` en niet release-eligible. Browser,
echte iPhone/Safari, kandidaat-VPS, onafhankelijke securityaudit,
productie-identieke load/chaos/soak, off-host restore en operationele signoff
blijven externe NO_GO-poorten.

De volgende exclusieve stap is
`R9L3_REQUEST_DOWNLOAD_PROJECTIONS_EXTRACTION`. R9M-HTML/CSS/JavaScript-
splitsing hoort niet in R9L2 of R9L3.
