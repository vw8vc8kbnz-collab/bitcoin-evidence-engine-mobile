# R9H-1 checkpoint — dialog/alertcomponent

Datum: 22 augustus 2026
Status: ontwikkelcheckpoint, R9H 1/10
Voorgestelde annotated tag: `r9h-dialog-component-checkpoint`

## Uitkomst

De dialog-/alertfamilie heeft één native eigenaar:
`app/tool-a/components/dialog.js`. Deze component bezit zowel de gewone
alert/confirm-overlay als de visueel afwijkende harde nooddialog, inclusief
DOM-mutaties, events, callbacks, focus en sluitvertraging.

De bestaande namen `ToolAAlertHelpers`, `showToolAlert`, `showToolConfirm` en de
hard-fallbacknamen blijven tijdelijk beschikbaar als dunne delegatie voor de
oude applicatiecode. Zij bezitten geen dialog-DOM of dialog-events meer. Deze
compatibiliteitslaag blijft bewust staan tot R9RC1.

## Exact behouden gedrag

- tekstpartitionering voor titel, body en details;
- alert-, confirm-, backdrop-, Escape-, OK- en Annulerensemantiek;
- confirm kan niet via backdrop of Escape worden gesloten;
- focus via `requestAnimationFrame`;
- sluitcallback na 120 ms;
- console-fallback bij ontbrekende vaste overlaymarkup;
- dynamische hard-fallbackkaart, stijlen en async closecontract;
- vaste alertmarkup en alle bijbehorende inline stijlbytes zijn exact gelijk
  aan het afgesloten R9G-checkpoint.

## Architectuurgrens

- 10 expliciet toegestane native modules;
- precies één beoordeelde DOM-/eventmodule: `components/dialog.js`;
- precies twee netwerkmodules: `api/jobs.js` en `api/requests.js`;
- geen storage in de native moduleboom;
- precies één tijdelijke compatibilityglobal: `ToolAR9Foundation`;
- de frozen foundationadapter publiceert zes dialogmethoden naast het reeds
  bewezen R9G-oppervlak.

## Beschermde fingerprints

| Onderdeel | SHA-256 |
|---|---|
| optimizer | `42480b301cd660dac1e5e9fec2c8d30bb5c6826c32234a9c1cce765b758bebb8` |
| DXF-geometrie | `b80a2d006241908bf7b33516f7e0faf59ef61e1e08db86966b23cc5de292c1ff` |
| pricinghelpers | `646c2f5186e9b080f6ba8dcf364884411c18e946254bb5c9001647f7cbb425df` |
| panelcontract | `e23314fd63a2358a48daa580a92cebb8a40c9862548ba0243461a59347da7fc9` |
| `buildJobPayload()` | `342dac02c2650ac2798e20e62d38d8e1e6b7d518a54daa8fd760d734ae527e47` |

De jobpayloadbuilder blijft exact 9.697 bytes.

## Bewijsstatus

- R9H-1 component-/ownershiptests: 11/11 PASS;
- R9B-architectuurgate: PASS;
- bestaande R9G- en FIX660-regressies: verplicht PASS;
- complete kandidaat- en uitgepakte artifactpreflight: verplicht PASS;
- verse R8Z↔R9H-1 black-boxoracle: verplicht 12/12 fixtures en 47/47 assertions;
- echte iOS WebKit/Safari: `DEFERRED NO-GO`;
- productie-identieke VPS/load/chaos/TLS/firewall/backup-restore/CAM:
  `DEFERRED NO-GO`.

Dit checkpoint verleent geen productie-GO. De volgende gecontroleerde stap is
R9H-2: progress-overlay.
