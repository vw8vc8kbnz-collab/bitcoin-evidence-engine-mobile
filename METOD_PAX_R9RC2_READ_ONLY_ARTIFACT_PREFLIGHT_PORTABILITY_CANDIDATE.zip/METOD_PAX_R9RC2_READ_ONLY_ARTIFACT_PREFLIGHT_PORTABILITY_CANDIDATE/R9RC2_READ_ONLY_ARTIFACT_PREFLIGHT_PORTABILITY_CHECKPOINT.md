# R9RC2 — read-only artifactpreflight-portabiliteit

Status: **PROVISIONAL_DEVELOPMENT_ONLY**  
Productie-GO: **nee**

## Aanleiding

De exacte R9RC1-ZIP slaagde lokaal en als veilig zelfstandig uitgepakt artifact,
maar stopte fail-closed op de VPS vóór deployment. Een standaard Linux `unzip`
respecteert de in het artifact vastgelegde immutable bestandsmodus `0444`.
Twee negatieve release-identiteitfixtures kopieerden die modus en probeerden
daarna hun eigen tijdelijke `RELEASE_IDENTITY.json` te muteren. Python 3.14 gaf
daarom terecht `PermissionError`.

De echte release-identiteit en directe gate waren groen. Er is geen applicatie-,
klantdata- of deployfout waargenomen en R9RC1 is niet geïnstalleerd.

## Correctie

`tools/r9rc2_release_identity_tests.py` maakt uitsluitend het ene bestand in
zijn private `TemporaryDirectory` owner-writable met modus `0600` voordat de
bewuste negatieve mutatie wordt uitgevoerd. De releasebron, het uitgepakte
artifact en alle echte identiteitsbestanden blijven immutable.

De applicatiecomponent blijft exact
`R9RC1_PROFESSIONAL_ARCHITECTURE_COMPLETION`. R9RC2 wijzigt geen runtime-,
frontend-, optimizer-, prijs-, request-, opslag- of klantgedrag.

## Verplichte verificatie

R9RC2 is pas intern PASS wanneer:

1. de volledige actuele matrix op de bronboom slaagt;
2. de ZIP-checksum en alle interne checksums kloppen;
3. een standaard Linux `unzip` de files als read-only uitpakt en de volledige
   preflight daar alsnog slaagt;
4. de bestaande veilige standalone-extractor dezelfde volledige preflight
   slaagt;
5. de gates geen releasebronbytes wijzigen.

Daarna blijven exact-R9RC2 Chromium, WebKit, VPS-deployment, echte iPhone Safari,
onafhankelijke security/privacyreview en formele sign-off afzonderlijke NO-GO-
poorten.

## Intern resultaat

- bronpreflight: **PASS**;
- actuele matrix: **29 suites, 280/280 tests, 0 failures, 0 skips**;
- veilige standalone-extractie en volledige preflight: **PASS**;
- standaard Linux `unzip` met `RELEASE_IDENTITY.json` als `0444` en testscripts
  als `0555`, gevolgd door de volledige preflight: **PASS**;
- supply-chain: **547 bestanden**, **497 tekstbestanden**, nul gevonden secrets,
  nul Python-SAST-bevindingen en nul gevaarlijke JavaScript-sinks.
