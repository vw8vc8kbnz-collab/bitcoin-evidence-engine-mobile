# R9L5 — resterende job-lifecyclefacades

De publieke job-create-, cancel-, async-, complexity-, crashlog- en
statusfacades zijn uit `app/server_py.py` verplaatst naar
`app/metod_app/jobs/lifecycle.py`.

`JobLifecycleFacadeService` krijgt alle filesystem-, state-, queue-, process-,
pricing-, security- en serialisatiedependencies expliciet geïnjecteerd. De zes
Handler-methoden zijn adapters van elk twee regels. Canonical payloadbouw,
optimizer/nesting, pricingalgoritmen en finalization-artifactconstructie zijn
niet verplaatst of gedupliceerd.

De R9L4-vóór-fixture blijft exact groen voor complexity, cancellation,
async-success/failure/cancellation en terminal statusprojecties. Bestaande
lifecycle-, queue-, performance- en real-jobtests bewijzen daarnaast duurzame
ACCEPTED-before-202, slot-/capacitycleanup, processbeëindiging, family-integrity
en subjobprivacy.

Dit checkpoint is lokaal provisioneel. Productie blijft NO_GO zolang browser,
echte iPhone/Safari, kandidaat-VPS, onafhankelijke security- en operationele
evidence ontbreken.

De exclusieve volgende stap is
`R9M_ADMIN_HTML_CSS_JAVASCRIPT_PROFESSIONAL_SPLIT`.
