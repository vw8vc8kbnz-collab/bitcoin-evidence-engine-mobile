# R9J-5 notification message extraction

Status: **PROVISIONAL_DEVELOPMENT_ONLY**. Dit checkpoint is niet vrijgegeven
voor productie. Browser-, VPS- en onafhankelijke-auditbewijzen blijven
expliciet `DEFERRED_NO_GO`.

## Resultaat

De opbouw van notificationtitels, berichtteksten en tags is uit
`app/server_py.py` gehaald en ondergebracht in
`app/metod_app/notifications/messages.py`. De nieuwe module is transportneutraal
en bevat alleen deterministische berichtopbouw en notification-specifieke
formattering.

De server blijft composition root. Configuratie, bestanden, klantbronprojectie,
privacyfiltering, logging en het daadwerkelijke netwerktransport blijven daar.

## Meetbaar effect

- `server_py.py`: 734.459 -> 730.352 bytes;
- `server_py.py`: 15.106 -> 15.003 regels;
- afname composition root: 4.107 bytes en 103 regels;
- nieuwe pure module: 6.125 bytes en 175 regels;
- netto bronwijziging: +2.018 bytes en +72 regels door types, documentatie en
  een expliciet testbare modulegrens.

Dit is geen claim van totale codekrimp. De winst is een kleinere composition
root, één eigenaar voor berichtopbouw en een side-effectvrije testgrens.

## Gedrags- en privacybewijs

`tools/r9j5_notification_message_tests.py` bewaakt negen contracten: exacte
minimale en uitgebreide ordermeldingen, prijs- en meterformattering,
fallbackmateriaal, begrensde klant- en configuratieregels, begrensde
foutmeldingen, een immutable transportwaarde, afwezigheid van side effects en
de server als composition/transport owner.

De bestaande R9J-4 notification-projectietests bleven 8/8 groen en de
FIX660R8 security/privacy-suite bleef 7/7 groen.

De nieuwe tests maakten één bestaande randfout zichtbaar: bij een lege
optimizerfout kon `splitlines()[0]` zelf een `IndexError` veroorzaken. R9J-5
geeft in dat uitsluitend lege geval fail-safe `Onbekende fout` terug. Niet-lege
foutmeldingen blijven begrensd tot hun eerste 180 tekens en normaal gedrag is
niet gewijzigd.

## Release-identiteit

- release: `R9J5`;
- build: `R9J5_NOTIFICATION_MESSAGE_EXTRACTION`;
- artifact: `METOD_PAX_R9J5_NOTIFICATION_MESSAGE_CANDIDATE.zip`;
- voorgenomen tag: `r9j-notification-message-checkpoint`;
- immutable golden behavior oracle: `R8Z`;
- runtime-compatibiliteitsbuild: `FIX660R8_PRELIVE_HARDENED`.

De complete checkpointbundel moet altijd zowel de echte tool-ZIP als de
volledige Git-historie en machineleesbare verificatierapporten bevatten.

## Resterende externe grens

Lokale en hermetische bewijzen vervangen geen browsermatrix,
doel-VPS-deployment, onafhankelijke security-audit of expliciete production-go
beslissing.
