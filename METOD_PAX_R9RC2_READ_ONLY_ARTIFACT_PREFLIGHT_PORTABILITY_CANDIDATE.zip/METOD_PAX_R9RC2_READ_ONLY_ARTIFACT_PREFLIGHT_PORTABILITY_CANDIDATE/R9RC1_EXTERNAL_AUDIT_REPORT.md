# R9RC1 extern-auditrapport

> Historische applicatiecomponent-audit. Het actuele artifact is R9RC2; zie
> `R9RC2_READ_ONLY_ARTIFACT_PREFLIGHT_PORTABILITY_CHECKPOINT.md`. De
> applicatiecomponent zelf bleef ongewijzigd.

## Conclusie

De HTML- en Pythonarchitectuur is nu professioneel gesplitst en aantoonbaar
opgeschoond. De interne audit geeft **PASS** voor de exacte bronkandidaat. Dit
rapport geeft nadrukkelijk geen productie-GO: externe browser-, VPS-, echte
iPhone-, security/privacy- en businessbewijzen ontbreken nog voor exact R9RC1.

## Auditbevindingen en afhandeling

| Bevinding | Afhandeling | Status |
|---|---|---|
| Tool A bevatte presentatie en runtime in één HTML | Markup-only shell, externe CSS, reproduceerbare classic bundle en ES-modules | Gesloten |
| Legacy runtimebron was te groot voor review | Byte-exact verdeeld in 13 begrensde `.jsfrag`-delen met hashledger | Gesloten |
| Tijdelijke globale foundationadapter | Lexicale adapter plus eenmalig ready-event | Gesloten |
| `server_py.py` was een monolithische runtime | 22-regelige boundary; domein-, HTTP-, worker-, startup- en service-eigenaren uitgepakt | Gesloten |
| Compositielaag bevatte nog inline service-wiring | Verplaatst naar expliciete `runtime/composition.py` | Gesloten |
| Import van runtime maakte state-directories | Import-time directory-I/O verwijderd; startup is enige initialisatie-eigenaar | Gesloten |
| Klant-/secretbestanden konden op te ruime defaults vallen | `0600` files, `0700` klant/state-subtrees, afgedwongen modes bij append/replace | Gesloten |
| Losse Bearertokens konden in technische tekst blijven staan | Volledige standalone Bearerredactie toegevoegd | Gesloten |
| Requestindex/logprojecties konden privacyrisico geven | PII-vrije index, klantnaam verwijderd, gestructureerde redactie, begrensde logs | Gesloten |
| Supply-chainscan miste `.jsfrag` en dubbel telde de bundle | `.jsfrag` volledig gescand; gegenereerde bundle uitgesloten van canonieke sinktelling | Gesloten |
| Login toonde een standaard adminnaam | Voorinvulling verwijderd | Gesloten |
| Oude checkpointtests rapporteerden bronlayout-drift als runtimefout | Actuele outcome-matrix en expliciete historische classificatie | Gesloten |

## Onafhankelijke reproduceerbaarheid

Gebruik uitsluitend:

```bash
PYTHONDONTWRITEBYTECODE=1 python3 -B tools/final_preflight.py \
  --release . --verify-checksums
```

De preflight valideert de exacte releaseboom, strict JSON, Pythoncompilatie,
JavaScript- en Bash-syntax, bundle-reproduceerbaarheid, 29 actuele suites,
twee directe fail-closed gates, onveranderlijkheid tijdens tests en alle
interne SHA-256-checksums.

## Resterende risico-/bewijsgrenzen

- `style-src-attr 'unsafe-inline'` is nog nodig voor bestaande CSSOM-mutaties.
  Er zijn geen inline markupstyles of dynamische style-elementen; verdere CSP-
  aanscherping vereist een nieuwe browsergedragsronde.
- Klantgegevens zijn binnen de servicefilesystemgrens leesbare JSON. Rechten en
  retentie zijn gehard, maar host/volume-encryptie en versleutelde offsite
  backups moeten operationeel en onafhankelijk worden bewezen.
- De interne Node/fake-DOM-componenttests vervangen geen echte browserengine.
- De R9O8 Chromium/WebKit- en VPS-resultaten horen bij een oudere kandidaat en
  mogen niet aan R9RC1 worden toegeschreven.

Daarom is de juiste vrijgavebeslissing na deze code-audit:
**intern technisch kandidaat-PASS; productie NO_GO tot alle externe bewijzen
op exact het canonieke R9RC1-artifact zijn afgerond.**
