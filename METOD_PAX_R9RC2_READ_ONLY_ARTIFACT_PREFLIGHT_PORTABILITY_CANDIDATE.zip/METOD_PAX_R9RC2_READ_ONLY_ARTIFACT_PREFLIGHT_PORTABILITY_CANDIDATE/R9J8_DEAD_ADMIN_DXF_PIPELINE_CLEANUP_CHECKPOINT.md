# R9J-8 dead Admin DXF pipeline cleanup

Status: **PROVISIONAL_DEVELOPMENT_ONLY**. Browser-, VPS- en onafhankelijke
auditbewijzen blijven expliciet `DEFERRED_NO_GO`.

## Resultaat

De ongebruikte `_rename_sheet_dxfs` en `_build_admin_dxf_exports` zijn uit
`app/server_py.py` verwijderd. Beide functies hadden nul AST name-loads en nul
repositorybrede aanroepen. Zij vormden een oude muterende pipeline die output
kon hernoemen of naar extra Admin-mappen kon kopiëren.

De actieve route blijft read-only: Admin leest uitsluitend artifacts uit het
finalization-seal en projecteert een vriendelijke downloadnaam via
`_admin_sheet_download_name`, zonder het opgeslagen bestand of zijn hash te
wijzigen.

## Meetbaar effect

- `server_py.py`: 718.193 -> 703.989 bytes;
- `server_py.py`: 14.706 -> 14.375 regels;
- netto productiebronkrimp: 14.204 bytes en 331 regels;
- geen nieuwe productieadapter, module of compatibilitylaag toegevoegd.

## Gedragsbewijs

`tools/r9j8_dead_admin_dxf_pipeline_cleanup_tests.py` bewaakt zeven contracten:

1. beide obsolete definities zijn afwezig;
2. uitsluitend hun muterende markers zijn verwijderd;
3. sealed artifacts blijven de actieve Admin-bron;
4. de actieve naamprojector heeft exact vijf runtimecallers;
5. naamprojector en DXF-deduplicator blijven bronsegment-byte-exact;
6. serveridentiteit en krimp zijn afgedicht;
7. status en gedragspolicy zijn machineleesbaar vastgelegd.

De echte serverlifecyclesuite en performancetests blijven beide 11/11 groen.

## Release-identiteit

- release: `R9J8`;
- build: `R9J8_DEAD_ADMIN_DXF_PIPELINE_CLEANUP`;
- artifact: `METOD_PAX_R9J8_DEAD_ADMIN_DXF_PIPELINE_CANDIDATE.zip`;
- voorgenomen tag: `r9j-dead-admin-dxf-pipeline-cleanup-checkpoint`;
- golden behavior oracle: `R8Z`.

De complete checkpointbundel moet opnieuw de echte tool-ZIP, R8Z-golden,
volledige Git-historie en alle machineleesbare verificatierapporten bevatten.
