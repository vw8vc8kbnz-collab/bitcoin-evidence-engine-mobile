# R9I-1 — legacy read-cleanup

Status: **PROVISIONAL DEVELOPMENT ONLY**. Dit checkpoint is niet release- of
productiegoedgekeurd zolang Chromium, WebKit, VPS-staging en de externe
auditgates niet aantoonbaar groen zijn.

## Uitgevoerde cleanup

De twee resterende klant-readers in de grote legacy-runtime zijn omgezet naar
dunne adapters op de bestaande native read-store:

- `copyCustomerSnapshot` gebruikt uitsluitend `normalizeCustomerSnapshot` van
  de centrale selectorlaag;
- `customerForCurrentCalculation` gebruikt uitsluitend de verse snapshot uit
  de centrale store;
- de dubbele aliasnormalisatie en veld-voor-veld merge zijn uit de legacy-closure
  verwijderd;
- DOM-, event-, netwerk-, opslag-, mutatie-, submit- en poll-eigenaarschap is
  niet verplaatst of gedupliceerd.

De legacy-runtime kromp van 449.328 naar 447.728 bytes en van 9.890 naar 9.854
regels. Dit is een eerste gecontroleerde tranche, niet de claim dat de complete
legacy-runtime al is gemigreerd.

## Nieuwe fail-closed grenzen

`tools/r9i_clean_code_gate.py` verifieert exact:

- de huidige legacy-runtimehash, bestandsgrootte en regelreductie;
- de twee dunne adapters en afwezigheid van de oude duplicatielogica;
- de hashes en side-effectvrije grens van selectors/store/bootstrap;
- onveranderde aantallen gevoelige DOM-, netwerk-, timer- en opslagtokens;
- expliciet dat de release nog niet geschikt is voor productie.

De algemene architectuurgate weigert daarnaast native modules boven 500 regels
en een bootstrap boven 180 regels. De importgraaf, 9 DOM-owners, 2
netwerkowners en ene compatibility-global blijven exact begrensd.

## Browser- en CSS-grens

De browseroracle is lokaal correct gestart tegen de immutable R8Z-golden en de
kandidaat. Alle 14 fixtures zijn fail-closed geblokkeerd door de ontbrekende
vastgepinde Playwright-installatie (`pinned-playwright-module-missing`). Daarom
zijn geen genummerde CSS-fixes, gedragdragende `style`-attributen of visuele
compatibility-adapters verwijderd. Dat mag pas na gelijkheid in Chromium én
WebKit.

## Vervolg

De volgende lokale tranche is opnieuw klein en eigenaarschap-neutraal:
selectors/readers verder migreren, daarna één API-route en vervolgens één
router/overlay-owner. Iedere brug verdwijnt pas nadat de laatste consument is
gemigreerd en de volledige regressie- en browsergates groen zijn.
