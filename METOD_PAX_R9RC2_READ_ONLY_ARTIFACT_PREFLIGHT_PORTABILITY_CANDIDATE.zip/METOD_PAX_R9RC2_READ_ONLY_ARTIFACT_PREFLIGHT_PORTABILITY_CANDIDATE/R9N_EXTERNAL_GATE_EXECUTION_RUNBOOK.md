# R9N extern uitvoerrunbook

## 1. Vertrouwensbasis

Verifieer eerst de complete outer checkpoint-ZIP, clone de Git-bundle en
checkout de R9N-tag. Verifieer daarna de R9N runtime-ZIP en de immutable
R8Z-ZIP met hun sidecars. Gebruik exact deze twee artifacts voor alle rapporten.

## 2. Gepinde browsers

Voer installatie uit op een disposable auditworker met uitgaand verkeer alleen
naar de vooraf goedgekeurde npm/Playwrightbronnen:

```sh
npm --prefix browser ci
npx --prefix browser playwright install --with-deps chromium webkit
node --version
node -e "console.log(require('./browser/node_modules/playwright/package.json').version)"
```

Leg de hashes vast van `browser/package.json`, `browser/package-lock.json`, de
Playwrightmodule en de werkelijk gestarte Chromium- en WebKitexecutables. Start
daarna vanaf de herstelde bronrepository:

```sh
python3 -B tools/r9a_browser_oracle.py \
  --registry contracts/R9A_BROWSER_FIXTURES.json \
  --golden-release /ABSOLUTE/R8Z_EXTRACT_ROOT \
  --candidate /ABSOLUTE/R9N_EXTRACT_ROOT \
  --engines webkit chromium \
  --playwright-module "$PWD/browser/node_modules/playwright" \
  --chromium-executable /ABSOLUTE/REVIEWED_CHROMIUM \
  --webkit-executable /ABSOLUTE/REVIEWED_WEBKIT \
  --no-partial-engine-evidence \
  --json-output /ABSOLUTE/EVIDENCE/raw/browser-oracle.json
```

PASS vereist 15/15 fixtures, beide engines, nul blocked/failed/skipped fixtures
en alle verplichte assertionledgers. Screenshots zijn alleen diagnostiek.

## 3. Overige echte omgevingen

Gebruik `R9N_EXTERNAL_EVIDENCE_CONTRACT.json` als machineleesbare checklist.
Ieder generiek rapport bevat minimaal:

- `schemaVersion: 1`, exact `reportType` en `status: PASS`;
- SHA-256 van exact dezelfde runtime-ZIP en `SHA256SUMS.txt`;
- tijdzonebewuste `observedAtUtc` binnen de toegestane leeftijd;
- concrete omgevingdetails;
- benoemde reviewer en organisatie;
- exact alle vereiste check-ID's met `status: PASS` en `evidenceRefs`;
- minimaal één attachment met relatief pad en juiste SHA-256.

De iPhone-omgeving moet `actualHardware: true` bevatten. De securityreviewer
moet `independentFromBuilder: true` attesteren. Deze declaraties vervangen geen
menselijke identiteitscontrole door de releaseboard.

## 4. Aggregate validatie

Plaats `browser.json`, `vps.json`, `iphone.json`, `security.json`,
`operations.json`, `cam.json`, `signoff.json` en hun attachments in één map.
Voer uit:

```sh
python3 -B tools/r9n_external_evidence_gate.py \
  --contract R9N_EXTERNAL_EVIDENCE_CONTRACT.json \
  --artifact /ABSOLUTE/METOD_PAX_R9N_RELEASE_CANDIDATE_EXTERNAL_GATE_PREPARATION_CANDIDATE.zip \
  --golden-artifact /ABSOLUTE/METOD_PAX_FIX660R8Z_PRELIVE_HARDENED.zip \
  --release /ABSOLUTE/R9N_EXTRACT_ROOT \
  --evidence-dir /ABSOLUTE/EVIDENCE \
  --json-output /ABSOLUTE/EVIDENCE/R9N_EXTERNAL_EVIDENCE_RESULT.json
```

Alleen exit 0 en status
`EVIDENCE_COMPLETE_PENDING_SEPARATE_PRODUCTION_DECISION` betekenen dat het
pack compleet is. Productie-GO vereist daarna nog een afzonderlijk change-
record en releaseboardbesluit.
