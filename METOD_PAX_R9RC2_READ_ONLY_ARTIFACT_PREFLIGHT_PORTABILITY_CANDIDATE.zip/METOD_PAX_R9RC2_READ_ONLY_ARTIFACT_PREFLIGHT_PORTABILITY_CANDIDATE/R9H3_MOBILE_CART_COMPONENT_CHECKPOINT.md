# R9H-3 checkpoint — mobiel materialenmandje en bottom-sheet

Datum: 22 augustus 2026  
Status: ontwikkelcheckpoint, R9H 3/10  
Voorgestelde annotated tag: `r9h-mobile-cart-component-checkpoint`

## Uitkomst

Het mobiele multi-materialenmandje en de bijbehorende bottom-sheet hebben één
native eigenaar: `app/tool-a/components/mobile-material-cart.js`. De component
bezit de read-projectie, dynamische rijen, swatches, openen/sluiten, focusherstel,
Escape- en resizegedrag, activatie, verwijderdelegatie en navigatie naar Panelen.

De oude `toolA_mobile_material_cart.js`-runtime en zijn
`ToolAMobileMaterialCart`-global zijn verwijderd. Bestaande aanroepplaatsen
delegeren tijdelijk via de enige frozen compatibilitygrens
`ToolAR9Foundation`. De adapters blijven bewust staan tot R9RC1.

## Exact behouden gedrag

- één deterministische rij per gekozen materiaal;
- publieke materiaalnaam, visuele familie, dikte en plaatmaat;
- exact één actieve materiaalkeuze;
- gekoppelde standaardpanelen plus aantallen van extra panelen;
- autoritatieve materiaal-swatchrenderer met bestaande afbeeldingsfallback;
- enkelvoud/meervoud voor titel, triggertekst en subtitel;
- bestaande 50/50 mobiele footer met gelijke 58px acties;
- bottom-sheet alleen op maximaal 700px en alleen bij minimaal één materiaal;
- backdrop, `aria-expanded`, `aria-hidden`, closeknop, handle en Escape;
- focus op sluiten en herstel naar de eerdere trigger;
- sluiten bij resize naar desktop zonder desktopregressie;
- verwijdering via de canonieke materiaaltransactie en gedeelde bevestiging;
- gedeelde bevestigingsdialoog blijft boven de sheet;
- geen dubbele legacy sticky bar of tweede mobiele sheet;
- geen grijze waas, gradient of schaduw achter de footeracties;
- no-throw gedrag bij ontbrekende DOM-capabilities.

## Architectuurgrens

- 12 expliciet toegestane native modules;
- drie beoordeelde DOM-componenten: `components/dialog.js`,
  `components/progress-overlay.js` en `components/mobile-material-cart.js`;
- precies twee netwerkmodules: `api/jobs.js` en `api/requests.js`;
- geen storage in de native moduleboom;
- precies één tijdelijke compatibilityglobal: `ToolAR9Foundation`;
- de frozen foundationadapter bevat 31 sleutels en publiceert acht tijdelijke
  mobile-cartmethoden naast het reeds bewezen R9H-2-oppervlak.

## Visuele fingerprints

| Onderdeel | Bytes | SHA-256 |
|---|---:|---|
| vaste trigger- en sheetmarkup | 1.917 | `db53b34607f1cc998bdc08a37be169bfa38fc6e704f3e13f02838454d27637a7` |
| complete R8S mobile-cart-CSS | 9.546 | `b0814a7f7440a7bd98179129dc92f2b0f8308ca4893ec3448a0e8773fb926cca` |

## Beschermde fingerprints

| Onderdeel | SHA-256 |
|---|---|
| optimizer | `42480b301cd660dac1e5e9fec2c8d30bb5c6826c32234a9c1cce765b758bebb8` |
| DXF-geometrie | `b80a2d006241908bf7b33516f7e0faf59ef61e1e08db86966b23cc5de292c1ff` |
| pricinghelpers | `646c2f5186e9b080f6ba8dcf364884411c18e946254bb5c9001647f7cbb425df` |
| panelcontract | `e23314fd63a2358a48daa580a92cebb8a40c9862548ba0243461a59347da7fc9` |
| `buildJobPayload()` | `342dac02c2650ac2798e20e62d38d8e1e6b7d518a54daa8fd760d734ae527e47` |

De jobpayloadbuilder blijft exact 9.697 bytes.

## Bewijsstatus

- R9H-3 mobile-cart-/ownershiptests: 12/12 PASS;
- R9H-2 progress-/ownershiptests: 12/12 PASS;
- R9H-1 dialog-/ownershiptests: 11/11 PASS;
- R9B-architectuurgate en 16 foundationtests: PASS;
- bestaande R9G-, route- en FIX660-regressies: verplicht PASS;
- complete kandidaat- en uitgepakte artifactpreflight: verplicht PASS;
- verse R8Z↔R9H-3 black-boxoracle: verplicht 12/12 fixtures en 47/47 assertions;
- echte iOS WebKit/Safari: `DEFERRED NO-GO`;
- productie-identieke VPS/load/chaos/TLS/firewall/backup-restore/CAM:
  `DEFERRED NO-GO`.

Dit checkpoint verleent geen productie-GO. De volgende gecontroleerde stap is
R9H-4: footer.
