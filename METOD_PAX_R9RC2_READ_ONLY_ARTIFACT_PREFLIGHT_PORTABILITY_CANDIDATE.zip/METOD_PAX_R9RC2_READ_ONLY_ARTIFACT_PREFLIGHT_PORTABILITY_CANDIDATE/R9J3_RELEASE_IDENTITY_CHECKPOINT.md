# R9J-3 release-identiteitscheckpoint

Status: **PROVISIONAL DEVELOPMENT CHECKPOINT**  
Release-eligibility: **NO_GO totdat de externe browser-, VPS-, onafhankelijke security- en operationele gates aantoonbaar PASS zijn**

## Canonieke identiteit

`RELEASE_IDENTITY.json` is vanaf dit checkpoint de enige primaire bron voor de
identiteit van de actuele kandidaat:

- release: `R9J3`;
- build: `R9J3_RELEASE_IDENTITY_CONSOLIDATION`;
- kanaal: `AUDIT_CANDIDATE`;
- artifact: `METOD_PAX_R9J3_RELEASE_IDENTITY_CANDIDATE.zip`;
- status: `PROVISIONAL_DEVELOPMENT_ONLY`, dus niet productie-eligible.

Dezelfde waarden zijn fail-closed gespiegeld in `RUNTIME_CONTRACT.json`, de
CycloneDX-SBOM en de publieke Tool A-metagegevens. De artifactbuilder weigert
een andere ZIP-naam en schrijft één expliciete artifact-root.

## Gescheiden rollen

`R8Z` is uitsluitend de immutable golden behavior oracle. De exacte baseline-
ZIP, SHA-256, grootte en manifest-SHA zijn in het identiteitscontract vastgelegd
en moeten gelijk blijven aan `baseline/R8Z_BASELINE_LOCK.json` in de volledige
repositoryhistorie.

`FIX660R8_PRELIVE_HARDENED` blijft een runtime- en deploymentcompatibiliteits-
identiteit. Bestaande servervelden, protocolnamen, immutable releasefolders en
deployscripts behouden die waarde om gedrag en rollbackcompatibiliteit niet te
wijzigen. Zij claimen nadrukkelijk niet de actuele release-identiteit.

`R9I_SYNC_CATALOG_REFRESH_CLEANUP_9` blijft de componentrevisie van de actieve
browserapplicatie. R9J-3 verandert alleen release-identiteit, provenance en
artifactverpakking; de beschermde optimizer-, server-, pricing-, geometrie-,
bootstrap- en legacy-runtimebytes blijven exact gelijk.

## Auditgrens

Een groene R9J-3 bron- en artifactgate bewijst consistente identiteit en
herkomst, niet productiegeschiktheid. Zonder echte Chromium/WebKit/Safari,
productie-identieke VPS, onafhankelijke securityreview en operationele
deploy/rollback/restorebewijzen blijft de uitkomst expliciet `NO_GO`.
