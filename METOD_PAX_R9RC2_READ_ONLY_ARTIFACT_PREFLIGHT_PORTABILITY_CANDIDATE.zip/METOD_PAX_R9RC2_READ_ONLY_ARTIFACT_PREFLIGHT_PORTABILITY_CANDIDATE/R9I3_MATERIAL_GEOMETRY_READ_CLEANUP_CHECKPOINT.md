# R9I-3 — materiaalgeometrie-readers

Status: **PROVISIONAL DEVELOPMENT ONLY**. Dit checkpoint is niet release- of
productiegoedgekeurd zolang Chromium, WebKit, VPS-staging en de externe
auditgates niet aantoonbaar groen zijn.

## Uitgevoerde cleanup

Drie samenhangende materiaalgeometrie-readers zijn gecentraliseerd in de
bestaande native selector- en storelaag:

- materiaaldikte per geselecteerde materiaalkey;
- bruto plaatafmetingen uit batch, actief materiaal of catalogusfallback;
- bruikbare plaatafmetingen na de bestaande plaatmarge.

`materialThicknessKey` blijft een dunne adapter omdat bestaande formuliercode
deze callback nog gebruikt. De oude `sheetDimsForMaterialKey`- en
`usableSheetDimsForMaterialKey`-functies zijn volledig verwijderd; hun enige
consument leest nu rechtstreeks via de ene bevroren `ToolAR9Foundation`-laag.
De historische `ensureStateShape()`-aanroep voor dikteresolutie blijft exact op
dezelfde plek staan.

## Meetbare grens

Ten opzichte van R9I-2 kromp de legacy-runtime met 1.662 bytes en 35 regels.
Cumulatief sinds R9H10 is de runtime gekrompen van 449.328 naar 445.860 bytes en
van 9.890 naar 9.813 regels. Negen legacy-readers zijn nu gecentraliseerd of na
migratie volledig verwijderd.

`tools/r9i_material_geometry_reader_tests.py` bewijst legacy-uitkomstgelijkheid
voor batch-, actief-materiaal-, catalogus- en defaultfallbacks, inclusief
stringwaarden en marges. De clean-codegate controleert exacte hashes, minimale
cumulatieve en incrementele krimp, verwijderde functies, de dunne adapter en
onveranderde DOM-, netwerk-, opslag- en timertokens.

## Niet gewijzigd

- optimizer, nesting, DXF-bytes, plaatsingen en manifesten;
- prijs-, btw- en afrondingslogica;
- publieke routes, methoden, statussen en payloads;
- panelmutaties, submit/poll, grain renderer en validatiebeleid;
- CSS-fixlagen en gedragdragende inline styles.

## Vervolg

De reader-first fase kan na dit checkpoint opnieuw worden beoordeeld. Pas na
een groene volledige regressie- en blackboxcyclus volgt één afgebakende
API-route; een router/overlay-owner komt daarna. Visuele cleanup blijft
geblokkeerd totdat Chromium én WebKit gelijkheid aantonen.
