# R9K3 — constant-lege Admin-requestjobsfallback verwijderd

R9K3 start exact vanaf
`r9k2-dead-admin-material-write-cleanup-checkpoint` en verwijdert uitsluitend
de constant-lege `for jp in []`-jobsfallback uit `api_admin_requests`, inclusief
de try/except en variabelen die alleen voor die nooit uitgevoerde lus bestonden.

De requestdirectory-read, limiet van 1–2000, standaardlimiet 200, sortering,
responsepayload, privacy en Admin-route bleven exact gelijk. Een jobsdirectory
zonder echte REQUESTS-mailboxrij werd vóór R9K3 niet getoond en wordt nog steeds
niet getoond. Vijf R9K2-uitvoerfixtures en echte proces-HTTP-controles binden dit
gedrag.

De server is 3.154 bytes en 64 regels kleiner. Eén top-level AST-statement met
416 AST-nodes verdween; de constante lus bevatte 15 nooit uitgevoerde
bodystatements.

Dit is een provisioneel auditcheckpoint, geen productie-GO. Browser-, VPS-,
echte iPhone/Safari-, onafhankelijke security- en productie-evidence blijven
vereist. `_merge_raw_quotes`, custom-env rollback, HTML/CSS/JavaScript-extractie
en functionele wijzigingen zijn expliciet niet meegenomen.
