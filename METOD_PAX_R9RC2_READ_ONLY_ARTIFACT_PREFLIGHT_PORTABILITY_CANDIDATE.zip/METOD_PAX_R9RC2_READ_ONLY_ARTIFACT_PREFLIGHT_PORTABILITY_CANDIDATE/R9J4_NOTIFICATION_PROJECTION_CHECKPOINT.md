# R9J-4 notification projection extraction

Status: **PROVISIONAL_DEVELOPMENT_ONLY**. Dit checkpoint is niet vrijgegeven
voor productie. Browser-, VPS- en onafhankelijke-auditbewijzen blijven
expliciet `DEFERRED_NO_GO`.

## Resultaat

De notification-projectielaag is uit `app/server_py.py` gehaald en ondergebracht
in `app/metod_app/notifications/projections.py`. De nieuwe module bevat alleen
deterministische transformaties: samenvattingsvelden parsen, prijsinformatie
samenvoegen en reeds geprojecteerde klantregels privacyveilig filteren.

De server blijft de composition root en houdt de verantwoordelijkheden die wel
side effects hebben: bestanden kiezen/lezen, configuratie laden, klantbronnen
projecteren en de uiteindelijke netwerknotificatie versturen.

## Meetbaar effect

- `server_py.py`: 740.026 -> 734.459 bytes;
- `server_py.py`: 15.239 -> 15.106 regels;
- afname composition root: 5.567 bytes en 133 regels;
- nieuwe pure module: 6.780 bytes en 187 regels;
- netto bronwijziging: +1.213 bytes en +54 regels door types, documentatie en
  een expliciet testbare modulegrens.

Dit checkpoint claimt dus geen kunstmatige totale codekrimp. Het resultaat is
een kleinere composition root en een los testbare verantwoordelijkheid.

## Gedragsbewijs

`tools/r9j4_notification_projection_tests.py` bewaakt acht contracten:

1. stabiele lege parseruitvoer;
2. panelen, platen, materialen, kantenmeters en prijzen;
3. prijs-precedentie;
4. fouttolerantie voor oude payloadprijzen;
5. privacy-default zonder klantgegevens;
6. expliciete allowlist, afkapping en maximumaantal regels;
7. afwezigheid van I/O-, netwerk-, proces- en threadgrenzen;
8. de server is alleen nog composition root voor deze projectie.

Aanvullend zijn 1.000 deterministische gegenereerde gevallen vergeleken met de
functies uit de Git-parent; alle uitkomsten waren byte-/waarde-equivalent. De
bestaande FIX660R8 security/privacy-suite bleef 7/7 groen.

## Release-identiteit

- release: `R9J4`;
- build: `R9J4_NOTIFICATION_PROJECTION_EXTRACTION`;
- artifact: `METOD_PAX_R9J4_NOTIFICATION_PROJECTION_CANDIDATE.zip`;
- voorgenomen tag: `r9j-notification-projection-checkpoint`;
- immutable golden behavior oracle: `R8Z`;
- runtime-compatibiliteitsbuild: `FIX660R8_PRELIVE_HARDENED`.

De complete checkpointbundel moet altijd zowel deze echte tool-ZIP als de
volledige Git-historie en machineleesbare verificatierapporten bevatten.

## Resterende externe grens

De lokale en hermetische bewijzen kunnen code- en packagingregressies aantonen,
maar vervangen geen browsermatrix, doel-VPS-deployment, onafhankelijke
security-audit of expliciete production-go beslissing.
