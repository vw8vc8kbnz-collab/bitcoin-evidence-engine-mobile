# Productiegereedheidsaudit R8Z

**Systeem:** METOD/PAX FIX660R8 PRELIVE HARDENED  
**Auditdatum:** 13 augustus 2026  
**Karakter:** broncode-, release- en operationele-readinessreview  
**Besluit:** **NO-GO voor publieke productie** totdat alle P0-poorten in dit document aantoonbaar zijn gesloten.

## 1. Doel, scope en bewijskracht

Deze audit beoordeelt of de huidige release veilig en beheersbaar live kan met echte klantgegevens en zware optimalisaties. Beoordeeld zijn:

- release-integriteit, checksums, SBOM, runtimecontract en CI/preflight;
- installer, deploy, immutable releases, rollback, systemd en Nginx/TLS;
- authenticatie, sessies, autorisatie, klantgegevens en bestandsgrenzen;
- optimizerwachtrij, gelijktijdigheid, time-outs, annuleren, crash- en herstelgedrag;
- state, archivering, retentie, back-up, restore en disaster recovery;
- logging, metrics, signalering, notificaties en incidentrespons;
- mismatches tussen documentatie, broncode en aantoonbare productiebediening.

De review is uitgevoerd op de releaseboom en de daarin aanwezige tests/documentatie.
De finale artifactbuilder moet dit auditdocument en alle testbestanden exact in
`SHA256SUMS.txt` opnemen en dat manifest opnieuw verifiëren voordat de ZIP wordt
gepubliceerd. Dit is **geen** bewijs van de actuele VPS-configuratie, publieke
firewall/TLS, een externe restore, echte belasting, Safari/iPhone-gedrag of
CAM/werkplaatsuitvoer. Die onderdelen vragen afzonderlijk productieachtig bewijs.

Een controle heet hieronder:

- **Afgedekt in bron:** de maatregel is zichtbaar in de release, maar moet nog op de doelserver worden bewezen;
- **Operationeel bewijs nodig:** code alleen is onvoldoende;
- **NO-GO:** livegang is niet toegestaan zolang dit punt openstaat.

### Post-remediationstatus van dit R8Z-artifact

De audit is tijdens dezelfde gecontroleerde hardeningronde direct verwerkt. De
volgende bronpunten zijn in het finale R8Z-artifact gesloten en hebben uitvoerende
regressietests: crash-herstelbare request/job/claim-archivering met een duurzaam
`PREPARED`/`COMMITTED`-journaal en startup roll-forward, PII-vrije requestindex,
bounded catalogus-/media-/queue-/claim-/draft-/logretentie,
backup-age/count/byte/free-space/inode-admission plus verify-before-publish,
begrensde immutable release-/configgeschiedenis, Admin-GET-mutator 405,
Admin-only detailreadiness, volledige auth-/cookieredactie, redirectvrije ntfy,
cumulatieve job-storage-reservering, procesgroepkill en een totale jobfamilie-
deadline. Verder zijn een globale catalogusbeeldsync met capaciteitsreservering,
een globale deploylock, current-release-hercontrole vóór pruning en bescherming
van de laatst bekende goede lokale back-up toegevoegd. Het optimizer-/
nestingalgoritme is niet gewijzigd.

Productie-Nginx heeft nu vaste-domeinredirects, reject-default vhosts, schone
proxy-headerhashinstellingen en HSTS zonder `includeSubDomains`. Installergebruik
via `sudo -E` is verwijderd; productie behoudt standaard minimaal 597 actieve
catalogusrecords. Deze bronmaatregelen moeten nog op exact de doelserver worden
bewezen. Offsite DR, autonome monitoring, privacy/legal, echte Safari→Admin→CAM,
infrastructuur-/TLS-/firewallbewijs en externe assurance blijven NO-GO-poorten.

## 2. Samenvatting

De applicatie heeft een sterke technische basis: immutable releases, een atomaire releasepointer, state buiten de release, een niet-root systemd-service, loopback-backend, fail-closed productie-TLS, individuele adminaccounts met TOTP, begrensde invoer en subprocessen, duurzame jobstatussen, integriteitschecks en gecontroleerde restore. De optimizer zelf hoeft voor deze audit **niet** te worden gewijzigd.

De resterende risico's zitten hoofdzakelijk rond productiebediening en externe
bewijsvoering. De belangrijkste zijn: een lokale back-up die nog geen echte
offsite disaster recovery is, ontbrekende autonome monitoring, nog niet op de
doelserver bewezen Nginx/firewall/TLS-renewal, productie-identieke load- en
chaosevidence en nog niet formeel vastgelegde privacy-/retentiebesluiten.

## 3. Reeds afgedekte beheersmaatregelen

| Onderwerp | Aanwezige beheersmaatregel | Bewijsbron | Nog te bewijzen |
|---|---|---|---|
| Release-integriteit | Interne SHA-256-manifesten, releasepreflight, SBOM en stdlib-only productiepad | `SHA256SUMS.txt`, `SBOM.cdx.json`, `RUNTIME_CONTRACT.json`, `tools/final_preflight.py` | Hash en preflight op exact het live artifact |
| Deploy/rollback | Immutable releasefolders, atomische `metod-pax-current`-pointer, maintenance tijdens deploy; rollback verandert release/config en niet bewust live state | `INSTALL_FIX660R8_FROM_STAGE.sh`, `DEPLOY_FIX660.sh` | Deploy plus rollbackoefening op productie-identieke staging |
| Service-isolatie | Dedicated niet-root gebruiker, systemd-sandbox, capabilitybeperking, resourcegrenzen en loopback-appsocket | deploy/systemd-unit in `DEPLOY_FIX660.sh` | `systemd-analyze security`, cgroup- en procesbewijs op doelserver |
| Reverse proxy | Nginx vóór loopback-backend, request-/connectionlimits, bounded proxying en cachepreventie voor dynamische Tool A-assets | Nginx-config in `DEPLOY_FIX660.sh` | Volledige actieve Nginx-config en alle luisterpoorten |
| Productie-TLS | Productiemodus vereist domein, certificaat en sleutel; onveilige legacyproductiemodus wordt geweigerd; exacte origincontrole | `DEPLOY_FIX660.sh`, `app/server_py.py` | Publieke keten, renewal, expiry-alert en redirectgedrag |
| Adminauthenticatie | Individuele gebruikers, PBKDF2-SHA256, TOTP, rollen, sessie-idle/absolute timeout en veilige cookies | `app/server_py.py`, `tools/bootstrap_admin_credentials.py` | Accountinventaris, herstel/revoke en MFA-proef |
| Invoer/bestanden | Strikte identifiers en paden, sealed hashes, JSON-/DXF-/maat-/aantal-/outputlimieten en disk-/inodechecks | `app/server_py.py`, `app/safety_contracts.py`, optimizer- en lifecycle-tests | Adversarial testresultaat uit definitief artifact |
| Optimizerisolatie | Job per subprocess, time-out, terminate/kill, annulering, duurzame status en startup-reconciliatie naar eindstatus | `app/server_py.py`, `tools/fix660r8_server_lifecycle_tests.py` | Crash/timeout/restart met meerdere gelijktijdige klanten |
| Wachtrij | Begrensde FIFO, per-IP-limiet, cumulatieve storage-reservering en procesgroepkill; CPU-afhankelijk 1/2-workerdefault | `DEPLOY_FIX660.sh`, `app/server_py.py`, queue-/performancetests | Gekozen tier opnieuw op exact de doelserver bewijzen |
| Catalogus/pricing | Publicatiesignoff, hashes en readiness-poorten; Tool A gebruikt de gepubliceerde catalogus | catalogus-/pricingcode en preflight | Definitieve 597-catalogus en handmatige prijssteekproef |
| Restoreveiligheid | ZIP-manifest met hashes; restore weigert traversal, symlinks, duplicaten, extra bestanden en bestaande target | `tools/restore_system_backup.py`, `tools/fix660r8_restore_tests.py` | Restore van echte offsite kopie naar schone host en functionele start |
| PII in logs/drafts | Logredactie en rotatie; publieke tokens zijn sessiegebonden; persistente PII-drafts zijn uitgeschakeld | `app/server_py.py` | Productielogsteekproef en vastgelegde bewaartermijn |
| Notificatie | Ntfy is optioneel, HTTPS-only en allowlisted; falen verliest de order in de app niet | `app/server_py.py`, configuratievoorbeeld | DPA/providerkeuze, afleveringstest en operationeel fallbackproces |

## 4. Resterende NO-GO-poorten

### P0-1 — Bron gesloten; bewijs begrensde opslag op doelserver

R8Z begrenst nu de eerder open bomen: actieve/archive/orphan data,
catalogusstages en -historie, staged/orphan media, idempotencyclaims, orphan
queuebestanden, oude drafts/logrotaties, lokale backups, immutable releases en
configbackups. Actieve data/catalogus en de actieve/vorige release zijn beschermd.

**Resterend bewijs:** draai cleanup onder echte aantallen/volumes, inspecteer de
dry-run/resultaatlogs en voer disk-/inode-druktests uit op productie-identieke
staging. De vaste technische termijnen blijven ondertekening door privacy- en
businessowner vereisen.

### P0-2 — Lokale backup begrensd; maak er echte disaster recovery van

De ingebouwde back-up is nu op leeftijd, aantal, totaalbytes, bronvolume, files,
vrije bytes en inodes begrensd en wordt volledig geverifieerd vóór atomaire
publicatie. Hij staat echter nog op dezelfde storage en is niet aantoonbaar
versleuteld of offsite. De ZIP bevat mogelijk PII, job-/canceltokens en
notificatieconfiguratie. De `OFFSITE_*`-instellingen zijn verklaringen; de
applicatie voert zelf geen versleutelde externe transfer uit. Een restore-proof
bewijst byte-integriteit, niet dat de applicatie op een schone host functioneert.

Verder draait back-upwerk binnen het webproces/cgroup en kan het POST-verkeer
blokkeren tijdens de consistente snapshot. De huidige afgedekte architectuur
draait back-up en retentie daarom binnen het enige webproces achter dezelfde
snapshot-/maintenancebarrière. Start later **geen** afzonderlijke back-up- of
retentieservice parallel met de webapp: de normale mutatietellers zijn
process-local.

**Minimale veilige correctie:** gebruik voor een afzonderlijke low-priority
service/timer altijd een expliciete app-drain/stop of een aantoonbaar consistente
filesystem-/providersnapshot. Alleen een tweede proces dat dezelfde helper
aanroept is niet consistent. Zet daarnaast een versleutelde,
versievaste offsite kopie met eigen minimale credentials op; alarmeer op
ouderdom/falen; test ophalen en volledig herstel op een schone geïsoleerde host.
Leg RPO en RTO vast.

### P0-3 — Nginx-template gesloten; bewijs firewall/TLS op doelserver

R8Z weigert in productie onverwachte enabled sites, maakt reject-default vhosts,
redirect naar het vaste geconfigureerde domein en configureert de proxy-headerhash
zonder de eerder waargenomen waarschuwing. Dit bewijst nog niet dat cloud- en
hostfirewall, alle luisterpoorten en certificate renewal op de echte VPS kloppen.

**Minimale veilige correctie en bewijs:**

- alleen SSH, HTTP en HTTPS publiek; applicatiepoort uitsluitend loopback;
- cloudfirewall én hostfirewall gecontroleerd;
- vaste domeinredirect en default-vhost die onbekende hosts weigert;
- alle enabled sites en de volledige `nginx -T` gereviewd;
- automatische certificaatrenewal, dry-run, gecontroleerde reload en expiry-alert;
- expliciet besluit over HSTS `includeSubDomains`;
- waarschuwingen oplossen zonder routinggedrag te wijzigen.

### P0-4 — Publieke readiness geminimaliseerd; autonome monitoring ontbreekt

De publieke readiness geeft in R8Z alleen `ok` en build; de volledige detailroute
vereist Adminauthenticatie. De aanwezige adminmetrics vragen echter nog een
ingelogde admin/TOTP-sessie en zijn daarom geen robuust autonoom scrape-endpoint.

Minimaal ontbrekend operationeel zicht:

- service active/restarts/OOM en cgroupgeheugen;
- HTTP-latency, 4xx/429/5xx en externe synthetic check;
- optimizer actief, queuewait, duur, failure, timeout en cancel;
- diskbytes, inodes en grootte van state-/archive-/back-upbomen;
- laatste succesvolle lokale en offsite back-up en laatste restoretest;
- certificaatverloop/renewal en Nginx-errors;
- catalogus-, pricing- en readinessstatus.

**Minimale veilige correctie:** een loopback/service-auth metricsroute of loggebaseerde exporter, node/systemd/Nginx-metrics, externe HTTPS-synthetic en geteste alarmering naar twee benoemde responders.

### P0-5 — Crashisolatie gesloten; bevestig capaciteit op doelserver

Met de echte optimizer en complexe 250-paneelfixtures bleef op twee afgeschermde
CPU's één job rond 2,09 s en twee gelijktijdige jobs rond 2,18 s batch; vier
gelijktijdig liepen op tot circa 4,53 s. Op één CPU verdubbelde twee tegelijk de
latency. R8Z kiest daarom één worker op 1 effectieve CPU en standaard twee vanaf
2 CPU's. Op grotere hosts is de harde bovengrens conservatief de helft van de
effectieve CPU's, maximaal 8. Dit vervangt geen meting op de werkelijke VPS/SKU.

Queue-/chaostests bewijzen slotvrijgave na runnerfout, FIFO-promotie,
cumulatieve storage-admission, queued cancel, totale familydeadline en
TERM→KILL→reap van een SIGTERM-negerend kleinkind.

**Resterend bewijs:** laat het algoritme ongemoeid en herhaal de stapsgewijze
load-/chaostest op productie-identieke hardware, inclusief HTTP/SSE/backupdruk.
Gebruik bij afwijking expliciet `PUBLIC_JOB_MAX_CONCURRENT=1`.

### P0-6 — Retentie, privacy en toegangsbeheer formaliseren

De broncode archiveert terminale aanvragen standaard na 90 dagen, geeft nog open
aanvragen een harde bovengrens van 365 dagen en verwijdert archieven standaard na
nog eens 90 dagen. Losse orphan jobs hebben standaard 7 dagen. Dit zijn nog geen
formele privacybesluiten. Handmatige of offsite back-ups kunnen PII langer bewaren
dan de applicatieretentie. Ook moet worden voorkomen dat herstel reeds verlopen
persoonsgegevens blijvend terugzet.

Vóór livegang zijn nodig:

- doel en grondslag per datatype, bewaartermijn en eigenaar;
- privacyverklaring en intern verwerkingsregister;
- verwerkersafspraken met VPS-, back-up-, notificatie- en eventuele e-mailprovider;
- inzage-, correctie-, verwijder- en exportprocedure inclusief back-upbeleid;
- periodieke admin-toegangsreview, revoke- en recoveryprocedure;
- datalekregister en procedure voor beoordeling/escalatie binnen de wettelijke termijn.

Juridische/privacy-eigenaar moet deze besluiten ondertekenen; dit document stelt geen juridische grondslag vast.

### P0-7 — Bewijs de volledige bedrijfsflow

Vóór publieke klanten zijn minimaal aantoonbaar:

- definitieve catalogus- en pricingsignoff plus handmatige prijssteekproef;
- volledige Safari/iPhone-flow: configureren, twee materialen, meerdere nerfgroepen, optimaliseren, akkoord, bedankscherm, adminjob en download;
- onafhankelijke CAM-import van productie-DXF en fysieke proefsnede;
- adminlogin, TOTP, rolbeperking, account revoke en herstel;
- benoemde operationele eigenaar voor aanvragen, pricing/Odoo en werkplaats;
- klantcommunicatie bij storing en handmatige fallback.

### P0-8 — Externe assurance en supply-chainbewijzen

De eigen regressie- en veiligheidstests zijn sterk, maar de releasepipeline toont nog geen aantoonbare SAST, secretscan, dependency-/OS-CVE-scan, DAST, coveragegrens, licentiecheck of ondertekende provenance. De SBOM beschrijft vooral de applicatie en niet alle deployment-/OS-componenten zoals Nginx, Python/OpenSSL en systemd.

**Minimale veilige correctie:** laat de externe auditor exact het finale artifact en deploymentbaseline beoordelen; archiveer testlogs, toolingversies, bevindingen en gesloten uitzonderingen. Vul een deployment-SBOM/assetinventaris aan zonder vlak voor live een grote code-refactor te starten.

## 5. Gelijktijdigheidsbeleid

Meer klanten toelaten is een capaciteitsbesluit, geen algoritmewijziging.

| Tier | Actieve zware optimizers | Wachtrij/per-IP | Status en toelatingsvoorwaarde |
|---|---:|---:|---|
| 0 — 1 effectieve CPU | 1 | maximaal 8 / maximaal 2 per IP | Automatische veilige fallback; twee tegelijk verdubbelde de gemeten latency |
| 1 — 2–3 effectieve CPU's | standaard 2 | 8 / 2 behouden | Bronmeting met 2×complex250 groen; opnieuw bewijzen op exacte server/SKU |
| 2 — toekomstige server | 4 CPU: max 2; 8 CPU: max 4; 16 CPU: max 8 | alleen na meting aanpassen | Conservatieve harde cap; iedere stap afzonderlijk load-/chaostesten |

Een tier slaagt alleen als:

- er geen crash, dataverlies, cross-job-lek, dubbele aanvraag of onsealed output is;
- outputfingerprints gelijk zijn aan de single-jobreferentie;
- geen OOM of swapthrash optreedt en geheugen-high-water voorlopig onder circa 70–75% van de cgroupgrens blijft;
- CPU en storage-I/O voldoende headroom houden; als voorlopig startpunt: duurzaam niet boven circa 75–80%, nader te bevestigen met een afgesproken SLO;
- HTTP/SSE-respons, queuewait en totale jobduur binnen de vooraf vastgelegde p95-doelen blijven;
- cancel, timeout, child-exit en servicerestart deterministisch eindigen in `DONE`, `FAILED` of `CANCELLED`;
- falen van één klantjob andere jobs en de webinterface niet blokkeert of vervuilt.

Kies als eerste live limiet één tier lager dan de hoogste volledig geslaagde testtier. Een begrensde volle wachtrij moet fail-closed antwoorden met een duidelijke klantmelding en passende `429`/`503`; nooit onbeperkt werk in geheugen aannemen.

## 6. Retentie- en privacymatrix

De genoemde livepolicy is een technisch voorstel. Product-, operations- en privacy-eigenaar moeten de definitieve termijnen vastleggen.

| Dataset | Huidig gedrag | Vereist livebesluit/minimale beheersing | Eigenaar/bewijs |
|---|---|---|---|
| Actieve aanvragen, gekoppelde jobs, klant-PII en DXF | Terminale aanvragen na circa 90 dagen naar archief; open aanvragen hebben een harde bovengrens van circa 365 dagen met waarschuwing/auditmeta | Bevestig doel, noodzaak en statusdefinitie; automatische overgang en purge-test | Product + privacy; testrapport |
| Archief | Circa 90 dagen na archivering verwijderd; technisch totaal circa 180 dagen voor terminale en circa 455 dagen voor langdurig open aanvragen | Formele termijnen, verwijderbewijs en uitzonderingsprocedure | Privacy + operations |
| Losse calculation jobs | Orphans circa 7 dagen | Behouden indien passend; bewijs dat gekoppelde jobs niet worden geraakt | Operations; cleanup-test |
| Pending/processing queue | Stale verwerking wordt fail-closed gereconcilieerd | Begrens en ruim ook ongekoppelde done/failed-restanten op | Operations; restart-/agingtest |
| Idempotencymarkers | Via hetzelfde duurzame archiefjournaal met de request verplaatst; orphan claim na grace verwijderd | Termijn en duplicatebeleid formeel bevestigen | Engineering + privacy |
| Applicatie-, client- en notificatielogs | Byte-rotatie plus 30 dagen voor rotaties; secrets volledig geredigeerd | Termijn formeel bevestigen; productielogsteekproef | Security/operations |
| Catalogusimports, historie en media | Actief import/catalogus beschermd; stale stage 7d, historie 12/180d, orphan media 30d | Dry-run/purge onder echte catalogusvolumes | Catalog owner |
| Lokale automatische back-ups | 8, max 70d, gezamenlijke lokale cap 20 GiB, broncap 16 GiB en vrije-ruimte/inode-admission | Freshness-alert; afzonderlijke service alleen met app-drain/stop of echte snapshot | Operations |
| Lokale handmatige back-ups | 12, max 120d binnen dezelfde gezamenlijke 20-GiB-cap | Legal hold en privacytermijn vastleggen | Operations + privacy |
| Offsite back-up | Niet door applicatie uitgevoerd | Encryptie, versioning/immutability, providerlifecycle en geverifieerde delete | Operations + privacy |
| Immutable releases/configback-ups | Exact benoemde directe children begrensd op count/age/bytes; actieve/vorige release beschermd | Resultaatlog en diskdruk op VPS inspecteren; auditartifact apart bewaren | Release owner |
| Admincredentials/TOTP | Buiten applicatiestate, actieve accounts blijven | Inventaris, least privilege, revoke/rotate/recovery; afzonderlijke DR | Security owner |

Na een restore moet direct opnieuw retentie draaien, zodat reeds verlopen records niet opnieuw een volledige bewaartermijn krijgen.

## 7. Back-up- en DR-acceptatie

Een geldige DR-proef bevat alle volgende bewijzen:

1. consistente applicatieback-up met succesvol SHA-manifest;
2. versleutelde offsite kopie met remote objectversie en hash;
3. download **uitsluitend vanuit offsite** naar een schone herstelhost;
4. `--verify-only` en restore naar een nieuw, leeg target;
5. installatie van exact releaseartifact en hash, productieconfig en correcte ownership;
6. geïsoleerde start en succesvolle `/health/ready`-controle;
7. adminlogin, catalogusweergave, voorbeeldjob, sealed output en download;
8. gemeten RPO en RTO tegen de vooraf goedgekeurde doelen;
9. herstelplan voor admincredentials, TOTP, notificatieconfig en TLS-heruitgifte;
10. gedateerd en ondertekend bewijs; herhaal periodiek en na wezenlijke statewijziging.

`OFFSITE_BACKUP_VERIFIED=true` of alleen `restore_test_proof.json` is nooit zelfstandig bewijs. Een restore mag de live state niet overschrijven; voer de proef gepland en geïsoleerd uit.

## 8. Monitoring, incidenten en chaostests

### Minimale alerts

| Signaal | Voorbeeldtrigger | Actie |
|---|---|---|
| Service | inactive, restartloop, OOM, cgroup pressure | Responder pagineren; geen automatische state rollback |
| Publieke flow | synthetic HTTPS faalt of p95 overschrijdt SLO | Nginx/app/TLS controleren, maintenance indien nodig |
| Optimizer | queuewait, duur, failure/timeout of cancelratio boven baseline | Nieuwe toelating begrenzen; falende child isoleren |
| Capaciteit | disk/inodes/state/back-upvolume boven drempel | Imports/back-ups/jobs fail-closed; gecontroleerde cleanup |
| Back-up | lokale/offsite kopie te oud, transfer/hash faalt, restoretest verlopen | NO-GO voor nieuwe release; herstel uitvoeren |
| TLS | renewal faalt of certificaat nadert verloop | Certificaat vernieuwen en keten opnieuw testen |
| Catalogus/pricing | signoff/readiness faalt | Publicatie blokkeren; bekende goede catalogus behouden |
| Security | herhaalde auth/rate-limit/pathfouten | IP-/accountonderzoek, tokens/account revoke indien nodig |

### Incidentrunbook

Voor livegang moeten een primaire en secundaire responder benoemd zijn. Het runbook bevat minimaal:

1. severity, SLO, pagerkanaal en escalatie;
2. gecontroleerd inschakelen van maintenance aan de edge;
3. vastleggen van tijdlijn, releasehash, service-/Nginxlogs en job-ID's zonder PII te lekken;
4. alleen de getroffen child annuleren/killen; andere jobs ongemoeid laten;
5. code-rollback via releasepointer met expliciete statecompatibiliteitscheck;
6. sessie-, token- en accountrevoke plus privacybeoordeling bij mogelijk datalek;
7. klant- en interne communicatie, handmatige aanvraagfallback;
8. herstelverificatie, postmortem en wijzigingsregistratie.

### Verplichte chaoscases op staging

- optimizerchild stopt non-zero;
- optimizer bereikt time-out en doorloopt terminate/kill;
- annuleren tijdens queue, processing en outputfinalisatie;
- service krijgt `SIGTERM` of restart tijdens één en meerdere jobs;
- Nginx reload tijdens actieve aanvraag;
- gesimuleerde lage diskruimte en inode-uitputting vóór write/admission;
- back-up terwijl werk arriveert en terwijl queue gevuld is;
- ntfy/offsiteprovider onbereikbaar;
- één corrupte/unsealed output terwijl andere job correct afrondt.

## 9. Exacte bewijscommando's

Onderstaande controles zijn read-only, behalve waar expliciet een geplande stagingproef staat. Vervang `$DOMAIN` en placeholders bewust.

### Artifact en service

```bash
P="$(readlink -f /opt/adzaagt/metod-pax-current)"
echo "ACTIVE_RELEASE=$P"
(cd "$P" && sudo sha256sum -c SHA256SUMS.txt)

sudo systemctl show metod-pax.service \
  -p ActiveState -p SubState -p MainPID -p ExecMainStartTimestamp \
  -p User -p Group -p NRestarts -p MemoryMax -p TasksMax -p LimitNOFILE
sudo systemd-analyze security metod-pax.service
PID="$(systemctl show metod-pax.service -p MainPID --value)"
sudo readlink -f "/proc/$PID/cwd"
```

### Nginx, listeners en firewall

```bash
sudo nginx -t
sudo nginx -T > /tmp/nginx.full.txt
sudo find /etc/nginx/sites-enabled -maxdepth 1 -type l -printf '%f -> %l\n'
sudo ss -ltnp
sudo ufw status verbose || true
sudo nft list ruleset
```

Acceptatie: backend alleen loopback; uitsluitend de bedoelde publieke poorten; geen onverwachte enabled vhost; onbekende Host wordt niet naar de applicatie geleid.

### TLS, redirect en headers

```bash
DOMAIN="voorbeeld.nl"
curl -sSI "http://$DOMAIN/" | head
curl -sSI "https://$DOMAIN/" \
  | grep -iE 'HTTP/|strict-transport|content-security|x-content|referrer|permissions'
echo | openssl s_client -connect "$DOMAIN:443" -servername "$DOMAIN" \
  -verify_return_error 2>/dev/null \
  | openssl x509 -noout -subject -issuer -dates -ext subjectAltName
systemctl status certbot.timer --no-pager
sudo certbot renew --dry-run
```

### Capaciteit en begrensde groei

```bash
sudo df -hT /var/lib/metod-pax /opt /var/backups
sudo df -i /var/lib/metod-pax /opt /var/backups
sudo du -xhd2 /var/lib/metod-pax | sort -h
sudo du -xhd1 /opt/adzaagt/metod-pax-releases /var/backups/metod-pax | sort -h
```

### Logs en servicefouten

```bash
sudo journalctl -u metod-pax.service --since '24 hours ago' --no-pager
sudo journalctl -u nginx --since '24 hours ago' --no-pager
sudo tail -n 200 /var/log/nginx/error.log
sudo ls -lh /var/lib/metod-pax/system/system_events.jsonl* \
  /var/lib/metod-pax/client_logs/* 2>/dev/null
```

Controleer steekproefsgewijs dat namen, e-mailadressen, adressen, sessies, TOTP-secrets en download-/canceltokens niet onnodig in logs staan.

### Lokale back-up verifiëren

```bash
sudo ls -lht /var/lib/metod-pax/backups
sudo -u metod-pax python3 "$P/tools/restore_system_backup.py" \
  /var/lib/metod-pax/backups/<backup>.zip --verify-only
```

### Geplande geïsoleerde offsite-restoreproef

```bash
python3 tools/restore_system_backup.py <opgehaalde-offsite-kopie>.zip \
  --target /var/lib/metod-pax-restore-test-YYYYMMDD \
  --proof /var/lib/metod-pax/system/restore_test_proof.json
```

Dit commando hoort alleen in een onderhoudsvenster op een schone herstelhost. Zet daarna expliciet juiste owner/mode en voer de functionele DR-stappen uit; overschrijf nooit live state.

### Productie-identieke loadtelemetrie

```bash
pidstat -dur 1
iostat -xz 1
vmstat 1
systemctl show metod-pax.service -p MemoryCurrent -p MemoryPeak -p CPUUsageNSec -p NRestarts
CG="/sys/fs/cgroup/system.slice/metod-pax.service"
sudo cat "$CG/memory.current" "$CG/memory.events"
```

Leg per tier inputfingerprints, outputfingerprints, queuewait, jobduur, HTTP-p95, CPU, RSS, I/O-wait, disk en inodes vast. Test nooit voor het eerst met echte klanten.

## 10. Productiedeployprocedure: mismatch in R8Z gesloten

Oudere documentatie noemde `sudo -E bash`. Op hardened sudo kan `-E` worden
genegeerd; dit is eerder daadwerkelijk waargenomen. R8Z documenteert en gebruikt
nu uitsluitend uitvoering als normale SSH-beheerder. De installer verhoogt zelf
de rechten en stuurt alleen een expliciete whitelist aan omgevingswaarden door.
In production kiest de installer bovendien standaard catalogusminimum 597; een
ontbrekende variabele kan niet meer stil naar 1 terugvallen.

**Resterend bewijs:** exporteer variabelen als normale SSH-beheerder en voer
`bash INSTALL_FIX660R8_FROM_STAGE.sh` uit. Bewijs daarna modus, catalogusminimum,
bind-adressen, origin, actieve release en service-CWD. Gebruik nooit `sudo -E`.

## 11. Go-livechecklist buiten domein en serveraanschaf

| Status | Poort | Vereist bewijs | Eigenaar |
|---|---|---|---|
| [ ] | Finale artifactintegriteit | SHA-256, SBOM, preflight en externe audit horen bij exact hetzelfde ZIP/artifact | Release + security |
| [ ] | Canonieke deploy/rollback | Geslaagde productie-identieke deploy, maintenance, rollback en statecompatibiliteit | Operations |
| [ ] | Servicehardening | systemd securityreport, resourcegrenzen, non-root, loopback en restartgedrag | Operations + security |
| [ ] | Netwerk | Cloud- en hostfirewall, luisterpoorten, default-vhost en onbekende Host getest | Security |
| [ ] | TLS | Geldige keten, vaste redirect, headers, renewal dry-run en expiry-alert | Operations |
| [ ] | Accounts | Unieke admins, rollen, TOTP, revoke, recovery en periodieke review | Security + business owner |
| [ ] | Catalogus/pricing | Definitieve catalogussignoff, pricingversie en handmatige steekproef | Catalog/pricing owner |
| [ ] | Klantflow | Safari/iPhone end-to-end, twee materialen/nerfgroepen, bedanktscherm en adminjob | Product/QA |
| [ ] | Werkplaats | DXF in onafhankelijke CAM en fysieke proefsnede akkoord | Workshop/CAM |
| [ ] | Concurrency | 1/2/3/4-stappentest; gekozen tier voldoet aan alle criteria met veiligheidsmarge | Performance owner |
| [ ] | Crashisolatie | Timeout, cancel, childcrash, servicerestart en Nginx reload bewezen | QA + operations |
| [ ] | Retentie/capaciteit | Alle state-/release-/back-upbomen begrensd; purge- en disk/inodetest | Operations + privacy |
| [ ] | Offsite DR | Versleutelde offsite kopie, schone restore, functionele boot en gemeten RPO/RTO | Operations |
| [ ] | Monitoring | Synthetic, metrics, dashboards en echte alarmdelivery naar twee responders | Operations |
| [ ] | Privacy/legal | Privacyverklaring, register, DPA's, rechten-/verwijderworkflow en datalekproces | Privacy/legal |
| [ ] | Notificatie/e-mail | Ntfy-keuze en fallback vastgelegd; indien klantmail vereist: DPA, SPF/DKIM/DMARC, bouncebewaking | Business + operations |
| [ ] | Incidentbediening | Runbook, primaire/secundaire on-call, maintenance en klantcommunicatie geoefend | Operations + management |
| [ ] | Finale signoff | Product, operations, security/privacy en workshop tekenen exact dezelfde releasehash af | Alle eigenaren |

## 12. Finale beslisregel

De release is pas **GO** wanneer:

1. alle P0-punten aantoonbaar gesloten zijn;
2. alle checklistregels een eigenaar, datum en bewijslink hebben;
3. de externe auditor het exacte finale artifact en de productiebaseline heeft beoordeeld;
4. de gekozen optimizerconcurrency door productie-identieke load- en chaostests is onderbouwd;
5. een echte offsite restore en de volledige klant-naar-admin-naar-CAM-flow zijn geslaagd.

Tot dat moment blijft de juiste status **PRELIVE / NO-GO**. De veilige route is gerichte operationele hardening en bewijsvoering, zonder optimizeralgoritme of bewezen klantflow vlak voor live grootschalig te herschrijven.

## 13. Officiële operationele en privacyreferenties

Deze audit geeft geen juridisch advies. De operationele en privacy-eigenaren kunnen
de volgende primaire bronnen gebruiken bij hun formele besluiten:

- [EDPB — Data protection basics](https://www.edpb.europa.eu/sme/learn-the-basics/data-protection-basics_en): doelbinding, dataminimalisatie, opslagbeperking en beveiliging;
- [Autoriteit Persoonsgegevens — Datalek: dit moet u doen](https://autoriteitpersoonsgegevens.nl/themas/beveiliging/datalekken/datalek-dit-moet-u-doen): beoordeling, datalekregister en waar van toepassing melding binnen 72 uur;
- [Autoriteit Persoonsgegevens — Privacyrechten in de praktijk](https://autoriteitpersoonsgegevens.nl/themas/basis-avg/privacyrechten-avg/voor-organisaties-privacyrechten-in-de-praktijk): identiteitscontrole, behandeling van verzoeken en de gebruikelijke reactietermijn;
- [NCSC — Basisprincipe 5: bereid je voor op incidenten](https://www.ncsc.nl/basisprincipes/basisprincipe-5-bereid-je-voor-op-incidenten): incidentrespons, herstel en het testen van back-ups;
- [NCSC — Forensic readiness](https://www.ncsc.nl/incidenten-en-herstellen/forensic-readiness): vooraf ingerichte logging, rollen, procedures en oefeningen voor onderzoek na incidenten.
