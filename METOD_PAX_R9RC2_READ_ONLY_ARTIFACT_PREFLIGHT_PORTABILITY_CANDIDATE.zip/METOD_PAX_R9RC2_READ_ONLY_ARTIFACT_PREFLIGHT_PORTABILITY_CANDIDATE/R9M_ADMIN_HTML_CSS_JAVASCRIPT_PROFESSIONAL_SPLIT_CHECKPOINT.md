# R9M — professionele Admin-presentatiesplit

## Uitkomst

De actieve Admin- en Admin-loginpresentatie staan niet meer als twee zeer grote
Python-stringconstanten in `admin/access.py`. Markup, CSS en JavaScript hebben nu
afzonderlijke, reviewbare bestanden onder `app/metod_app/admin/templates` en
`app/metod_app/admin/assets`. `admin/presentation.py` is de enige fail-closed
resource-owner; `access.py` bezit alleen nog authenticatie en sessies.

Dit checkpoint is een auditkandidaat en **geen productie-GO**.

## Bewijsbare grenzen

- 2 embedded Python-templates naar 2 HTML-bestanden en 5 same-origin assets.
- 2 `<style>`-elementen, 3 inline scriptbodies en 209 `style`-attributen naar nul.
- Nul inline eventattributen en nul remote frontendimports.
- Alle 89 DOM-ID's blijven in dezelfde volgorde aanwezig.
- Alle 24 Admin-API-literalen en 6 `data-admin-action`-routes blijven gelijk.
- Alle 81 JavaScriptfuncties blijven aanwezig; alleen `_systemTone` heet nu
  `_systemToneClass`, omdat de drie kleuren vaste CSS-klassen zijn geworden.
- De oorspronkelijke hoofd- en loginstylesheets zijn byte-exact als prefix of
  volledig bestand behouden. De 154 unieke statische styledeclaraties zijn één-op-één
  als gegenereerde, verzegelde utilityklassen opgenomen.
- De catalogusvoortgang gebruikt één expliciet begrensde `0..100` breedtemutatie.

## HTTP- en beveiligingsmodel

De routecatalogus groeit gecontroleerd van 70 naar 80 routes: voor vijf assets
bestaan exact één GET- en één HEAD-route. `login.css` en `login.js` zijn anoniem
beschikbaar zodat het loginformulier werkt. `admin.css`, `admin.js` en `dxf.js`
zijn alleen met een geldige Admin-sessie beschikbaar; zonder sessie wordt hun
bestaan verborgen met 404. Onbekende of traverserende assetpaden worden niet
gematcht. Alle responses blijven `no-store` en `nosniff`.

De echte HTTP-procesproef controleert anonieme login, publieke login-assets,
afgeschermde hoofdassets, login met HttpOnly-cookie, geauthenticeerde GET/HEAD,
Content-Type, Content-Length, bytehashes en intrekking na logout.

## Niet gewijzigd

Admin-API-DTO's, cookie- en origincontracten, autorisatievolgorde, optimizer,
nesting, geometrie, pricing, jobs, persistence en Tool A-functionaliteit zijn
niet als functionele scope gewijzigd. De publieke Tool A-markers zijn uitsluitend
naar de canonieke R9M-auditidentiteit verplaatst.

## Externe blokkades

Pinned Chromium/WebKit, kandidaat-VPS, echte iPhone Safari, onafhankelijke
securityaudit en productie-GO blijven `DEFERRED_NO_GO`. De volgende exclusieve
stap is `R9N_RELEASE_CANDIDATE_EXTERNAL_GATE_PREPARATION`.
