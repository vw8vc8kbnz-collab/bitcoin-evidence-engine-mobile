# R9L4 — static-file- en generieke HTTP-adapterextractie

R9L4 verplaatst de actieve publieke static-policy en generieke HTTP-
responsewriters uit `app/server_py.py` naar
`app/metod_app/http/static.py`.

`StaticHttpAdapterService` bezit nu:

- de expliciete public allowlist en gevoelige top-level blocklist;
- URL-decoding, rootcontainment, directoryweigering en DXF-libraryresolutie;
- DXF-MIME-overrides en HTML-nonce-injectie;
- default CORS-, cache-, security-, CSP-, HSTS- en DXF-attachmentheaders;
- strikte UTF-8 tekst/JSON-responses en begrensde file-streaming.

`Handler` houdt uitsluitend dunne transportadapters. De route-matcher importeert
dezelfde static-policy en bevat geen tweede allow/block-implementatie meer.
Authenticatie, autorisatie, bodyreads, route dispatch, SSE, gespecialiseerde
cataloguscompressie en download-businesspolicy zijn niet gewijzigd.

De R9L3-before-fixture verzegelt 49 rootbestanden, 19 modules, 41 shellassets,
8 geblokkeerde top-levels, pathmatrices, contenttypes, responsebytes,
serialisatiefouten, HTML-nonces en streamlimieten. De R9L4-contractsuite en de
echte HTTP-procesgate bewaken daarnaast HEAD, OPTIONS en gevoelige static
denials.

Dit checkpoint blijft `PROVISIONAL_DEVELOPMENT_ONLY` en `releaseEligible=false`.
Externe browser-, VPS-, onafhankelijke security-, load/chaos/soak-, off-host-
restore-, operationele en CAM-poorten ontbreken nog; productie blijft NO_GO.

De volgende exclusieve stap is
`R9L5_REMAINING_JOB_LIFECYCLE_FACADES_EXTRACTION`. De professionele Admin- en
frontend-HTML/CSS/JavaScript-splitsing blijft R9M-scope.
