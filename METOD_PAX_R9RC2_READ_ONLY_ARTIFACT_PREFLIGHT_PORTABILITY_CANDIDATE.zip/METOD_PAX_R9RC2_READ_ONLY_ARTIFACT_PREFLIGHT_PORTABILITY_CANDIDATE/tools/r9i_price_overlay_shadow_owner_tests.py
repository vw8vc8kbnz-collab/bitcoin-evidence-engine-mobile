#!/usr/bin/env python3
from __future__ import annotations

"""Fail-closed proof for the R9I-7 shadowed price-overlay owner removal."""

import hashlib
import json
import re
import unittest
from pathlib import Path

from r9j_hermetic_reference import assert_sealed_file, load_reference


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
RUNTIME = APP / "tool-a/shell/script-06-legacy-application-runtime.js"
HTML = APP / "toolA.html"
BOOTSTRAP = APP / "tool-a/bootstrap.js"
RULES = ROOT / "R9B_ARCHITECTURE_RULES.json"
REFERENCE = load_reference(ROOT)

REMOVED_SHADOW_BLOCK = """  function openPriceOverlay(){
    ensurePriceOverlayEls();
    if(!priceOverlay) return;
    refreshPriceOverlay();
    closeOverlay('grain');
    closeOverlay('overview');
    closeOverlay('other');
        // overlay uses flex centering
    priceOverlay.style.display = 'flex';
    setStep('overview');
  }

  function closePriceOverlay(){
    if(priceOverlay) priceOverlay.style.display = 'none';
  }

"""


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def function_bodies(source: str, name: str) -> list[str]:
    return [
        match.group("body")
        for match in re.finditer(
            rf"^  function {re.escape(name)}\([^\n]*\)\{{(?P<body>.*?)^  \}}$",
            source,
            re.MULTILINE | re.DOTALL,
        )
    ]


class R9IPriceOverlayShadowOwnerTests(unittest.TestCase):
    def test_01_runtime_delta_is_exactly_the_shadowed_pair(self) -> None:
        current = assert_sealed_file(
            self, ROOT, REFERENCE,
            "app/tool-a/shell/script-06-legacy-application-runtime.js",
        ).decode("utf-8")
        self.assertNotIn(REMOVED_SHADOW_BLOCK, current)
        self.assertEqual(REFERENCE["cleanupDeltas"]["priceOverlayShadowOwner"], {
            "definitionsRemoved": 2,
            "remainingOpenDefinitions": 1,
            "remainingCloseDefinitions": 1,
        })

    def test_02_one_local_open_and_close_owner_remain(self) -> None:
        source = RUNTIME.read_text(encoding="utf-8")
        opens = function_bodies(source, "openPriceOverlay")
        closes = function_bodies(source, "closePriceOverlay")
        self.assertEqual(len(opens), 1)
        self.assertEqual(len(closes), 1)
        self.assertIn("po.style.display='flex'", opens[0])
        self.assertIn("document.body.style.overflow='hidden'", opens[0])
        self.assertIn("refreshPriceOverlay", opens[0])
        self.assertIn("po.style.display = 'none'", closes[0])
        self.assertIn("document.body.style.overflow=''", closes[0])
        self.assertEqual(source.count("window.openPriceOverlay = openPriceOverlay;"), 1)

    def test_03_authoritative_price_and_compatibility_layers_are_byte_exact(self) -> None:
        for relative in (
            "app/tool-a/shell/script-13-fix486-final-single-source-overlay-v2.js",
            "app/tool-a/api/jobs.js",
            "app/tool-a/api/requests.js",
            "app/tool-a/components/checkout-review.js",
            "app/tool-a/components/thank-you.js",
        ):
            assert_sealed_file(self, ROOT, REFERENCE, relative)

    def test_04_html_changes_only_by_revision_cache_key(self) -> None:
        current = HTML.read_text(encoding="utf-8")
        self.assertIn(REFERENCE["applicationCacheRevision"], current)
        self.assertNotIn("r9i-dead-customer-overlay-cleanup-6", current)
        self.assertEqual(current.count('id="priceOverlay"'), 1)
        self.assertEqual(current.count('id="priceOverlayTotal"'), 1)
        self.assertIn('content="R9O9"', current)

    def test_05_pricing_optimizer_and_payload_truth_remain_hash_locked(self) -> None:
        exact = {
            "dxf_nesting_optimizer.py": "42480b301cd660dac1e5e9fec2c8d30bb5c6826c32234a9c1cce765b758bebb8",
            "dxf_geometry.py": "b80a2d006241908bf7b33516f7e0faf59ef61e1e08db86966b23cc5de292c1ff",
            "pricing_helpers.py": "646c2f5186e9b080f6ba8dcf364884411c18e946254bb5c9001647f7cbb425df",
            "panel_contract.py": "e23314fd63a2358a48daa580a92cebb8a40c9862548ba0243461a59347da7fc9",
            "toolA_grain_studio_renderer.js": "922cd4ac479fbaf86ebfbb0256808119b96a8344e9b0bf1ffb4f668518a03204",
        }
        for relative, expected in exact.items():
            self.assertEqual(sha256(APP / relative), expected, relative)

    def test_06_foundation_and_architecture_do_not_expand(self) -> None:
        bootstrap = BOOTSTRAP.read_text(encoding="utf-8")
        rules = json.loads(RULES.read_text(encoding="utf-8"))["frontend"]
        self.assertIn('"R9I_SYNC_CATALOG_REFRESH_CLEANUP_9"', bootstrap)
        self.assertEqual(len(rules["moduleImports"]), 19)
        self.assertEqual(len(rules["domOwnerModules"]), 10)
        self.assertEqual(len(rules["networkOwnerModules"]), 2)
        self.assertEqual(rules["compatibilityGlobal"], "ToolAR9Foundation")
        shell = json.loads((ROOT / "R9H10_SEMANTIC_SHELL_ASSETS.json").read_text(encoding="utf-8"))
        self.assertEqual(len(shell["scriptFiles"]), 34)


if __name__ == "__main__":
    unittest.main(verbosity=2)
