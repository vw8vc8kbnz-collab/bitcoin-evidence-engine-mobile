#!/usr/bin/env python3
from __future__ import annotations

"""Executable contracts for the R9J-8 dead Admin DXF pipeline cleanup."""

import ast
import hashlib
import json
import unittest
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SERVER = ROOT / "app/server_py.py"
REQUEST_DOWNLOAD_OWNER = ROOT / "app/metod_app/requests/downloads.py"
CONTRACT = ROOT / "R9J8_DEAD_ADMIN_DXF_PIPELINE_CLEANUP.json"
SERVER_SHA256 = "47e889f8930462c1bc75878055bb638cd202a51cd7b4b24cf556a551e29c50f2"
PROJECTOR_SHA256 = "887f40a160f4468b8cb671c050d3edca4588c4abfb99a1059182e4ea728cf6f7"
DEDUPLICATOR_SHA256 = "db5c57394e5b1df8941ed9cc9e96283ab1e5c80395db5e143a7ef16955ec4f4b"


class R9J8DeadAdminDxfPipelineCleanupTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.source = SERVER.read_text(encoding="utf-8")
        cls.request_download_source = REQUEST_DOWNLOAD_OWNER.read_text(encoding="utf-8")
        cls.tree = ast.parse(cls.source)
        cls.contract = json.loads(CONTRACT.read_text(encoding="utf-8"))
        cls.definitions = {
            node.name: node
            for node in cls.tree.body
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        }
        cls.loads = Counter(
            node.id
            for node in ast.walk(cls.tree)
            if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load)
        )

    def test_01_obsolete_mutating_pipeline_is_absent(self) -> None:
        self.assertNotIn("_rename_sheet_dxfs", self.definitions)
        self.assertNotIn("_build_admin_dxf_exports", self.definitions)

    def test_02_legacy_mutation_markers_are_absent(self) -> None:
        for token in self.contract["cleanup"]["removedMutationMarkers"]:
            self.assertNotIn(token, self.source)

    def test_03_sealed_artifacts_remain_the_active_admin_source(self) -> None:
        self.assertGreaterEqual(self.source.count("_sealed_output_artifacts("), 7)
        self.assertGreaterEqual(
            self.request_download_source.count("sealed_output_artifacts("), 2,
        )
        self.assertIn("Admin browsing must never mutate a completed job.", self.source)
        self.assertIn("fpath = _sealed_output_artifacts(subjob_root).get(rel_norm)", self.source)

    def test_04_download_name_projector_has_exactly_five_runtime_callers(self) -> None:
        self.assertEqual(self.loads["_admin_sheet_download_name"], 5)
        self.assertEqual(self.source.count("def _admin_sheet_download_name("), 1)

    def test_05_active_admin_owners_are_source_segment_byte_exact(self) -> None:
        expected = {
            "_admin_sheet_download_name": PROJECTOR_SHA256,
            "_dedupe_admin_dxf_files": DEDUPLICATOR_SHA256,
        }
        for name, digest in expected.items():
            segment = ast.get_source_segment(self.source, self.definitions[name])
            self.assertIsNotNone(segment)
            self.assertEqual(hashlib.sha256(segment.encode("utf-8")).hexdigest(), digest)

    def test_06_historical_r9j8_identity_and_reduction_are_sealed(self) -> None:
        evidence = self.contract["sizeEvidence"]
        self.assertEqual(evidence["serverAfter"]["sha256"], SERVER_SHA256)
        self.assertEqual(evidence["serverBefore"]["lines"], 14706)
        self.assertEqual(evidence["serverAfter"]["lines"], 14375)
        self.assertEqual(evidence["serverReduction"], {"bytes": 14204, "lines": 331})
        self.assertLessEqual(len(SERVER.read_bytes()), evidence["serverAfter"]["bytes"])

    def test_07_contract_is_provisional_and_behavior_preserving(self) -> None:
        self.assertEqual(self.contract["contractId"], "R9J8_DEAD_ADMIN_DXF_PIPELINE_CLEANUP")
        self.assertEqual(self.contract["status"], "PROVISIONAL_DEVELOPMENT_ONLY")
        self.assertFalse(self.contract["releaseEligible"])
        self.assertFalse(self.contract["cleanup"]["activeRuntimePathChanged"])
        self.assertEqual(self.contract["executableEvidence"]["cleanupTestCount"], 7)


if __name__ == "__main__":
    unittest.main(verbosity=2)
