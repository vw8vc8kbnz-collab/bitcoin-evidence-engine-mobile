import getpass
import hashlib
import secrets


def pbkdf2_hash_password(password: str, iterations: int = 600000, salt: str | None = None) -> str:
    salt = salt or secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt.encode("utf-8"), int(iterations))
    return f"pbkdf2_sha256${int(iterations)}${salt}${dk.hex()}"


def main() -> None:
    pw1 = getpass.getpass("Nieuw admin-wachtwoord: ")
    pw2 = getpass.getpass("Herhaal wachtwoord: ")
    if not pw1:
        raise SystemExit("Leeg wachtwoord is niet toegestaan.")
    if pw1 != pw2:
        raise SystemExit("Wachtwoorden komen niet overeen.")
    print()
    print("Kopieer deze hash in private_config\admin_credentials.live.json:")
    print()
    print(pbkdf2_hash_password(pw1))


if __name__ == "__main__":
    main()
