#!/usr/bin/env python3
from __future__ import annotations

"""Outcome-based API-to-production lifecycle checks for FIX660R8.

This suite uses a temporary external state tree and one real METOD DXF. It proves
that public intent is canonicalized against the live catalog, the real optimizer
runs, finalization hashes are enforced, and common boundary tampering fails closed.
No persistent application or customer state is touched.
"""

import importlib
import importlib.util
import io
import json
import os
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path
from types import SimpleNamespace
from unittest import mock


RELEASE_ROOT = Path(__file__).resolve().parents[1]
APP_ROOT = RELEASE_ROOT / "app"
PUBLIC_ID = "decor_0123456789abcdefabcd"
INTERNAL_CODE = "LIFECYCLE_MAT_18"
HEADER = (
    "PartId;PanelName;Qty;LengthMm;WidthMm;ThicknessMm;MaterialCode;"
    "GrainGroup;RotationAllowed;H1;H2;W1;W2\n"
)


class ServerLifecycleTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls._temp = tempfile.TemporaryDirectory(prefix="fix660r8_server_lifecycle_")
        cls.state_root = Path(cls._temp.name) / "state"
        cls._old_state_env = os.environ.get("METOD_STATE_ROOT")
        os.environ["METOD_STATE_ROOT"] = str(cls.state_root)
        sys.path.insert(0, str(APP_ROOT))
        # Other full-suite modules intentionally rebind server globals to their
        # own temporary state roots. Reload so this process-level oracle is
        # isolated even when unittest imports every suite in one interpreter.
        cls.server = importlib.reload(importlib.import_module("server_py"))
        cls.server._initialize_external_state()

        library = {
            "source": "CSV_CATALOG_ONLY",
            "pricingModel": "catalog_sell_price_incl_vat_v2",
            "decorLibrarySchemaVersion": 4,
            "records": [
                {
                    "articleNo": INTERNAL_CODE,
                    "publicMaterialId": PUBLIC_ID,
                    "productName": "Lifecycle testmateriaal",
                    "sourceKind": "CATALOG_IMPORT",
                    "active": True,
                    "published": True,
                    "archived": False,
                    "catalogMissing": False,
                    "catalogExcluded": False,
                    "thicknessMm": 18,
                    "sheetWid": 2070,
                    "sheetLen": 2800,
                    "sellPriceInclVatPerSheet": 121.00,
                    "priceSource": "CSV_SALE_PRICE_INCL_VAT",
                    "hasGrain": True,
                    "grainDefaultOn": True,
                    "visualFamily": "Hout",
                    "visualTags": ["Hout"],
                    "colorGroup": "Bruin",
                    "searchTags": ["lifecycle"],
                }
            ],
        }
        cls.server.durable_write_json(cls.server.MATERIAL_LIBRARY_PATH, library)
        cls.handler = object.__new__(cls.server.Handler)
        cls.dxf_text = (
            APP_ROOT / "embedded_dxfs" / "Deuren METOD" / "Metod deur 60x40.dxf"
        ).read_text(encoding="utf-8", errors="strict")

    @classmethod
    def tearDownClass(cls) -> None:
        if cls._old_state_env is None:
            os.environ.pop("METOD_STATE_ROOT", None)
        else:
            os.environ["METOD_STATE_ROOT"] = cls._old_state_env
        try:
            sys.path.remove(str(APP_ROOT))
        except ValueError:
            pass
        cls._temp.cleanup()

    def _public_payload(
        self,
        *,
        material: str = PUBLIC_ID,
        thickness: str = "18",
        dxf_text: str | None = None,
        extra_dxf: bool = False,
    ) -> dict:
        dxf_parts = {"PANEL_A": dxf_text if dxf_text is not None else self.dxf_text}
        if extra_dxf:
            dxf_parts["UNUSED"] = self.dxf_text
        return {
            "panelsCsv": (
                HEADER
                + f"PANEL_A;Testdeur;1;397;597;{thickness};{material};;true;1;0;0;0\n"
            ),
            "dxfParts": dxf_parts,
            "jobJson": {
                "customer": {
                    "firstName": " Test ",
                    "lastName": " Klant ",
                    "company": " Zaagbedrijf BV ",
                    "email": "test@example.invalid",
                    "phone": "+31 6 12345678",
                    "billingAddress": "Teststraat",
                    "shippingAddress": "Werkplaatsweg",
                    "shippingSameAsBilling": False,
                    "houseNumber": "42-A",
                    "postcode": "1234 AB",
                    "city": "Utrecht",
                    "country": "Nederland",
                },
                "rest_material": {"carry_out": True},
                "note": " lifecycle ",
                "grainEnabled": True,
                "sheetMarginMm": -999,
            },
            # Deliberately hostile browser pricing must disappear from the canonical DTO.
            "pricing": {
                "currency": "FREE",
                "edgeBanding": {"defaultLossPercent": -200},
            },
        }

    def test_01_public_boundary_fails_closed(self) -> None:
        with self.assertRaises(self.server.SafetyContractError):
            self.handler._canonicalize_public_job_payload(
                self._public_payload(material=INTERNAL_CODE)
            )
        with self.assertRaises(self.server.SafetyContractError):
            self.handler._canonicalize_public_job_payload(
                self._public_payload(thickness="19")
            )
        with self.assertRaises(self.server.SafetyContractError):
            self.handler._canonicalize_public_job_payload(
                self._public_payload(extra_dxf=True)
            )

        wrong_dxf = (
            APP_ROOT / "embedded_dxfs" / "Ladefront METOD" / "Metod lade 80x40.dxf"
        ).read_text(encoding="utf-8", errors="strict")
        with self.assertRaises(self.server.SafetyContractError):
            self.handler._canonicalize_public_job_payload(
                self._public_payload(dxf_text=wrong_dxf)
            )

    def test_01b_duplicate_dxf_bodies_are_parsed_once_at_public_boundary(self) -> None:
        payload = self._public_payload()
        payload["panelsCsv"] = (
            HEADER
            + f"PANEL_A;Testdeur A;1;397;597;18;{PUBLIC_ID};;true;1;0;0;0\n"
            + f"PANEL_B;Testdeur B;1;397;597;18;{PUBLIC_ID};;true;1;0;0;0\n"
        )
        payload["dxfParts"] = {"PANEL_A": self.dxf_text, "PANEL_B": self.dxf_text}
        with mock.patch.object(
            self.server,
            "_strict_dxf_parse_pairs",
            wraps=self.server._strict_dxf_parse_pairs,
        ) as parse_pairs:
            canonical = self.handler._canonicalize_public_job_payload(payload)
        self.assertEqual(parse_pairs.call_count, 1)
        self.assertIn("PANEL_A", canonical["panelsCsv"])
        self.assertIn("PANEL_B", canonical["panelsCsv"])

    def test_01c_250_compact_refs_stay_compact_through_optimizer_start(self) -> None:
        payload = self._public_payload()
        part_ids = [f"PANEL_{index:03d}" for index in range(250)]
        payload["panelsCsv"] = HEADER + "".join(
            f"{part_id};Bulk {index};1;397;597;18;{PUBLIC_ID};;true;1;0;0;0\n"
            for index, part_id in enumerate(part_ids)
        )
        payload.pop("dxfParts", None)
        payload["dxfBlobs"] = {"g0001": self.dxf_text}
        payload["dxfPartRefs"] = {part_id: "g0001" for part_id in part_ids}

        canonical = self.handler._canonicalize_public_job_payload(payload)
        self.assertNotIn("dxfParts", canonical)
        self.assertEqual(len(canonical["dxfBlobs"]), 1)
        self.assertEqual(len(canonical["dxfPartRefs"]), 250)

        master_id = "LIFECYCLE_BULK_250"
        result = self.server._create_job_from_payload(
            canonical,
            master_job_id=master_id,
            public_access_token="bulk-test-token",
        )
        self.assertEqual(result["jobId"], master_id)
        subjob_root = self.server.resolve_identifier_child(
            self.server.JOBS, result["subjobs"][0]["subjobId"]
        )
        self.assertEqual(len(list((subjob_root / "input" / "dxf_blobs").glob("*.dxf"))), 1)
        refs = json.loads((subjob_root / "input" / "dxf_part_refs.json").read_text(encoding="utf-8"))
        self.assertEqual(len(refs["partRefs"]), 250)
        report = json.loads((subjob_root / "output" / "report.json").read_text(encoding="utf-8"))
        self.assertEqual(report["dxfInput"]["storageMode"], "content_addressed_refs_v1")
        self.assertEqual(report["dxfInput"]["logicalParts"], 250)
        self.assertEqual(report["dxfInput"]["uniqueBodies"], 1)
        finalization = json.loads((subjob_root / "output" / "finalization.json").read_text(encoding="utf-8"))
        self.assertEqual(finalization["counts"]["instances"], 250)
        self.assertEqual(finalization["counts"]["placements"], 250)
        self.assertEqual(finalization["counts"]["partDxfs"], 250)

    def test_02_real_job_finalization_and_tamper_detection(self) -> None:
        canonical = self.handler._canonicalize_public_job_payload(self._public_payload())
        self.assertEqual(canonical["payloadSchema"], "FIX660R8_SERVER_CANONICAL_V1")
        self.assertNotIn("pricing", canonical)
        self.assertNotIn("sheetMarginMm", canonical["jobJson"])
        self.assertFalse(canonical["jobJson"]["grainEnabled"])
        self.assertIn(INTERNAL_CODE, canonical["panelsCsv"])
        self.assertNotIn(PUBLIC_ID, canonical["panelsCsv"])

        master_id = "LIFECYCLE_JOB_001"
        result = self.server._create_job_from_payload(
            canonical,
            master_job_id=master_id,
            public_access_token="test-token-never-persisted-outside-temp-state",
        )
        self.assertEqual(result["jobId"], master_id)
        self.assertEqual(len(result["subjobs"]), 1)
        subjob_id = result["subjobs"][0]["subjobId"]
        master_root = self.server.resolve_identifier_child(self.server.JOBS, master_id)
        subjob_root = self.server.resolve_identifier_child(self.server.JOBS, subjob_id)
        self.assertTrue(self.server._finalization_complete(subjob_root))
        self.assertTrue(self.server._finalization_complete(master_root))

        finalization = json.loads(
            (subjob_root / "output" / "finalization.json").read_text(encoding="utf-8")
        )
        self.assertEqual(finalization["schemaVersion"], 2)
        self.assertEqual(finalization["state"], "COMPLETE")
        self.assertEqual(finalization["counts"]["instances"], 1)
        self.assertEqual(finalization["counts"]["placements"], 1)
        self.assertEqual(finalization["counts"]["sheetDxfs"], 1)

        quote_path = subjob_root / "output" / "quote.json"
        original_quote = quote_path.read_bytes()
        quote_path.write_bytes(original_quote + b"\n")
        self.assertFalse(self.server._finalization_complete(subjob_root))
        self.assertFalse(self.server._finalization_complete(master_root))
        quote_path.write_bytes(original_quote)
        self.assertTrue(self.server._finalization_complete(subjob_root))
        self.assertTrue(self.server._finalization_complete(master_root))

        with self.assertRaises(self.server.SafetyContractError):
            self.server.resolve_identifier_child(self.server.JOBS, "../../victim")
        with self.assertRaises(self.server.SafetyContractError):
            self.server.resolve_relative_file(subjob_root, "output/../../secrets")

    def test_03_admin_manifest_is_read_only_and_cancel_fails_closed(self) -> None:
        master_id = "LIFECYCLE_JOB_001"
        master_root = self.server.resolve_identifier_child(self.server.JOBS, master_id)
        links = self.server.strict_json_load(master_root / "output" / "links.json")
        subjob_id = links["subjobs"][0]["subjobId"]
        subjob_root = self.server.resolve_identifier_child(self.server.JOBS, subjob_id)
        summary_path = subjob_root / "output" / "calculation_summary.txt"
        summary_before = summary_path.read_bytes()
        finalization_before = (
            subjob_root / "output" / "finalization.json"
        ).read_bytes()

        request_id = "REQ_LIFECYCLE_001"
        self.server._ensure_request_dirs()
        self.server._save_status(
            request_id,
            {
                "requestId": request_id,
                "customer": {"name": "Test Klant"},
                "job": {
                    "parentJobId": master_id,
                    "subjobs": [{"subjobId": subjob_id}],
                },
            },
        )
        manifest = self.server._build_request_file_manifest(request_id)
        self.assertTrue(manifest["allFiles"])
        unsealed = subjob_root / "output" / "diagnostic-unsealed.txt"
        unsealed.write_text("must never be downloadable\n", encoding="utf-8")
        manifest_with_unsealed_file = self.server._build_request_file_manifest(request_id)
        self.assertNotIn(
            "output/diagnostic-unsealed.txt",
            {str(item.get("rel") or "") for item in manifest_with_unsealed_file["allFiles"]},
        )
        jobs_handler = object.__new__(self.server.Handler)
        jobs_handler._send_json = lambda obj, code=200: (obj, code)
        admin_jobs, admin_code = self.server.api_admin_jobs(jobs_handler)
        self.assertEqual(admin_code, 200)
        subjob_row = next(row for row in admin_jobs["jobs"] if row["jobId"] == subjob_id)
        sealed_relations = {str(item.get("rel") or "") for item in subjob_row["sealedFiles"]}
        self.assertNotIn("output/diagnostic-unsealed.txt", sealed_relations)
        self.assertNotIn("output/toolb_stdout.txt", sealed_relations)
        self.assertEqual(summary_path.read_bytes(), summary_before)
        self.assertEqual(
            (subjob_root / "output" / "finalization.json").read_bytes(),
            finalization_before,
        )
        self.assertTrue(self.server._finalization_complete(subjob_root))
        self.assertTrue(self.server._finalization_complete(master_root))

        self.server._save_job_runtime_state(master_id, "CANCELLED", reason="test")
        self.assertFalse(self.server._finalization_complete(subjob_root))
        self.assertFalse(self.server._finalization_complete(master_root))
        self.assertIsNone(self.server._find_or_generate_stickertool_file(subjob_id))
        self.server._save_job_runtime_state(master_id, "DONE", reason="test-cleanup")
        self.assertTrue(self.server._finalization_complete(master_root))

    def test_03b_admin_sheet_names_use_customer_decor_and_sequence_everywhere(self) -> None:
        master_id = "LIFECYCLE_JOB_001"
        master_root = self.server.resolve_identifier_child(self.server.JOBS, master_id)
        links = self.server.strict_json_load(master_root / "output" / "links.json")
        subjob_id = links["subjobs"][0]["subjobId"]
        subjob_root = self.server.resolve_identifier_child(self.server.JOBS, subjob_id)
        request_id = "REQ_LIFECYCLE_001"

        sealed = self.server._sealed_output_artifacts(subjob_root)
        zaag_rel = next(
            rel for rel in sealed
            if rel.startswith("output/DXF_Zaagplaten/") and rel.endswith(".dxf")
        )
        sheet_rel = next(
            rel for rel in sealed
            if rel.startswith("output/sheets/") and rel.endswith(".dxf")
        )
        expected = "Test Klant__Lifecycle testmateriaal__001.dxf"

        # Request manifest drives the primary Admin order screen.
        manifest = self.server._build_request_file_manifest(request_id)
        zaag_item = next(
            item for item in manifest["allFiles"]
            if item["jobId"] == subjob_id and item["rel"] == zaag_rel
        )
        self.assertEqual(zaag_item["downloadName"], expected)
        group_item = next(
            item for group in manifest["dxfGroups"] for item in group["files"]
            if item["jobId"] == subjob_id and item["rel"] == zaag_rel
        )
        self.assertEqual(group_item["downloadName"], expected)

        # The technical Admin job list must show the identical friendly label.
        jobs_handler = object.__new__(self.server.Handler)
        jobs_handler._send_json = lambda obj, code=200: (obj, code)
        jobs_body, jobs_code = self.server.api_admin_jobs(jobs_handler)
        self.assertEqual(jobs_code, 200)
        job_row = next(row for row in jobs_body["jobs"] if row["jobId"] == subjob_id)
        self.assertEqual(job_row["zaagplaten"][0]["label"], expected)

        # Both sealed file routes set Content-Disposition to the friendly name;
        # the physical filename and finalization hash remain unchanged.
        def admin_download_handler():
            handler = object.__new__(self.server.Handler)
            handler._require_job_access = lambda *args, **kwargs: True
            handler._check_admin_auth_silent = lambda: True
            handler._send_text = lambda text, code=200, ctype="text/plain": (text, code)
            handler._stream_file = lambda path, **kwargs: kwargs["download_name"]
            return handler

        self.assertEqual(
            self.server.api_job_file(admin_download_handler(), subjob_id, zaag_rel),
            expected,
        )
        self.assertEqual(
            self.server.api_download(
                admin_download_handler(), subjob_id, Path(sheet_rel).name
            ),
            expected,
        )

        # The ZIP keeps material folders collision-safe, while each plate entry
        # itself has the exact customer/decor/sequence filename.
        zip_handler = object.__new__(self.server.Handler)
        zip_handler.path = f"/api/admin/request_download_zip?requestId={request_id}&scope=dxf"
        zip_handler._send_text = lambda text, code=200, ctype="text/plain": (text, code)

        def capture_zip(path, **kwargs):
            with zipfile.ZipFile(path, "r") as archive:
                return archive.namelist()

        zip_handler._stream_file = capture_zip
        zip_names = self.server.api_admin_request_download_zip(zip_handler)
        self.assertTrue(
            any(name.endswith("/DXF_Zaagplaten/" + expected) for name in zip_names),
            zip_names,
        )

        self.assertEqual(
            self.server._admin_sheet_download_name(
                subjob_root,
                "Sheet_002.dxf",
                customer={"name": "Klant/Naam:*?"},
            ),
            "Klant_Naam__Lifecycle testmateriaal__002.dxf",
        )
        self.assertTrue(self.server._finalization_complete(subjob_root))
        self.assertTrue(self.server._finalization_complete(master_root))

    def test_04_capacity_and_catalog_review_hash_fail_closed(self) -> None:
        with mock.patch.object(
            self.server.shutil,
            "disk_usage",
            return_value=SimpleNamespace(total=1024, used=1023, free=1),
        ):
            with self.assertRaises(self.server.SafetyContractError):
                self.server._enforce_state_capacity(1)

        stage = {
            "csvSha256": "a" * 64,
            "warnings": [{"row": 2, "message": "review"}],
            "excluded": [],
            "errors": [],
            "summary": {"accepted": 1},
            "taxonomySummary": {"reviewRequired": 0},
            "records": [{"articleNo": "A", "sellPriceInclVatPerSheet": 121.0}],
        }
        signed = self.server._catalog_review_sha256(stage)
        stage["warnings"].append({"row": 3, "message": "changed"})
        self.assertNotEqual(self.server._catalog_review_sha256(stage), signed)

        valid_hash = self.server._pbkdf2_hash_password("test-password")
        self.assertTrue(self.server._verify_password_against_stored("test-password", valid_hash))
        self.assertFalse(
            self.server._verify_password_against_stored(
                "test-password", valid_hash.replace("$600000$", "$600001$", 1)
            )
        )

    def test_05_public_status_never_surfaces_tampered_quote(self) -> None:
        master_id = "LIFECYCLE_JOB_001"
        master_root = self.server.resolve_identifier_child(self.server.JOBS, master_id)
        links = self.server.strict_json_load(master_root / "output" / "links.json")
        subjob_id = links["subjobs"][0]["subjobId"]
        subjob_root = self.server.resolve_identifier_child(self.server.JOBS, subjob_id)
        quote_path = subjob_root / "output" / "quote.json"
        original = quote_path.read_bytes()

        status_handler = object.__new__(self.server.Handler)
        status_handler._require_job_access = lambda *args, **kwargs: True
        status_handler._send_json = lambda obj, code=200: (obj, code)
        valid_body, valid_code = status_handler._api_status(master_id)
        self.assertEqual(valid_code, 200)
        self.assertEqual(valid_body["meta"]["status"], "done")
        self.assertIsNotNone(valid_body["quote"])

        quote_path.write_bytes(original + b"\n")
        blocked_body, blocked_code = status_handler._api_status(master_id)
        self.assertEqual(blocked_code, 409)
        self.assertIsNone(blocked_body["quote"])
        self.assertEqual(blocked_body["pricingSummary"], {})
        admin_manifest = self.server._build_request_file_manifest("REQ_LIFECYCLE_001")
        self.assertEqual(admin_manifest["allFiles"], [])
        self.assertEqual(admin_manifest["pricingSummary"], {})
        quote_path.write_bytes(original)

    def test_05b_public_subjob_waits_for_complete_master_family(self) -> None:
        master_id = "LIFECYCLE_JOB_001"
        master_root = self.server.resolve_identifier_child(self.server.JOBS, master_id)
        links = self.server.strict_json_load(master_root / "output" / "links.json")
        subjob_id = links["subjobs"][0]["subjobId"]
        subjob_root = self.server.resolve_identifier_child(self.server.JOBS, subjob_id)
        token = self.server._read_job_access_token(master_id)

        status_handler = object.__new__(self.server.Handler)
        status_handler._require_job_access = lambda *args, **kwargs: True
        status_handler._send_json = lambda obj, code=200: (obj, code)

        def public_file_handler():
            handler = object.__new__(self.server.Handler)
            handler.headers = {"Authorization": f"Bearer {token}"}
            handler._require_job_access = lambda *args, **kwargs: True
            handler._check_admin_auth_silent = lambda: False
            handler._send_text = lambda text, code=200, ctype="text/plain; charset=utf-8": (
                text,
                code,
            )
            handler.response_code = None
            handler.response_headers = []
            handler.send_response = lambda code: setattr(handler, "response_code", code)
            handler.send_header = lambda key, value: handler.response_headers.append(
                (key, value)
            )
            handler.end_headers = lambda: None
            handler.wfile = io.BytesIO()
            return handler

        try:
            self.server._save_job_runtime_state(master_id, "PROCESSING", reason="family-gate-test")
            processing_body, processing_code = status_handler._api_status(subjob_id)
            self.assertEqual(processing_code, 200)
            self.assertEqual(processing_body["meta"]["status"], "processing")
            self.assertIsNone(processing_body["quote"])
            self.assertEqual(processing_body["pricingSummary"], {})

            direct_processing = self.server.api_job_file(
                public_file_handler(), subjob_id, "output/quote.json"
            )
            self.assertEqual(direct_processing[1], 409)
            linked_processing = self.server.api_subjob_file(
                public_file_handler(), master_id, subjob_id, "output/quote.json"
            )
            self.assertEqual(linked_processing[1], 409)

            self.server._save_job_runtime_state(master_id, "FAILED", reason="family-gate-test")
            failed_body, failed_code = status_handler._api_status(subjob_id)
            self.assertEqual(failed_code, 409)
            self.assertEqual(failed_body["meta"]["status"], "error")
            self.assertIsNone(failed_body["quote"])
            self.assertEqual(failed_body["pricingSummary"], {})
            self.assertEqual(
                self.server.api_job_file(
                    public_file_handler(), subjob_id, "output/quote.json"
                )[1],
                409,
            )
            self.assertEqual(
                self.server.api_subjob_file(
                    public_file_handler(), master_id, subjob_id, "output/quote.json"
                )[1],
                409,
            )

            # The sealed partial result remains available to authenticated Admin
            # forensics; only public exposure is tied to the complete family.
            self.assertTrue(self.server._finalization_complete(subjob_root, _memo={}))
            self.assertIn(
                "output/quote.json",
                self.server._sealed_output_artifacts(subjob_root),
            )

            self.server._save_job_runtime_state(master_id, "DONE", reason="family-gate-test")
            self.assertTrue(self.server._public_job_family_complete(subjob_id, memo={}))
            done_body, done_code = status_handler._api_status(subjob_id)
            self.assertEqual(done_code, 200)
            self.assertEqual(done_body["meta"]["status"], "done")
            self.assertIsNotNone(done_body["quote"])
            self.assertGreater(float(done_body["pricingSummary"]["totalInclVat"]), 0.0)

            direct_done_handler = public_file_handler()
            self.server.api_job_file(
                direct_done_handler, subjob_id, "output/quote.json"
            )
            self.assertEqual(direct_done_handler.response_code, 200)
            self.assertIsInstance(
                json.loads(direct_done_handler.wfile.getvalue().decode("utf-8")),
                dict,
            )

            linked_done_handler = public_file_handler()
            self.server.api_subjob_file(
                linked_done_handler, master_id, subjob_id, "output/quote.json"
            )
            self.assertEqual(linked_done_handler.response_code, 200)
            self.assertIsInstance(
                json.loads(linked_done_handler.wfile.getvalue().decode("utf-8")),
                dict,
            )

            # DONE is only authoritative while the complete master family proof
            # remains valid. A sealed-child tamper is permanent integrity failure,
            # never a synthetic "processing" response with partial pricing.
            quote_path = subjob_root / "output" / "quote.json"
            original_quote = quote_path.read_bytes()
            try:
                quote_path.write_bytes(original_quote + b"\n")
                self.assertFalse(
                    self.server._public_job_family_complete(subjob_id, memo={})
                )
                tampered_body, tampered_code = status_handler._api_status(subjob_id)
                self.assertEqual(tampered_code, 409)
                self.assertEqual(tampered_body["meta"]["status"], "error")
                self.assertIsNone(tampered_body["quote"])
                self.assertEqual(tampered_body["pricingSummary"], {})
            finally:
                quote_path.write_bytes(original_quote)
            self.assertTrue(
                self.server._public_job_family_complete(subjob_id, memo={})
            )
        finally:
            self.server._save_job_runtime_state(master_id, "DONE", reason="test-cleanup")

    def test_05c_submit_recovers_canonical_customer_and_admin_receives_every_field(self) -> None:
        master_id = "LIFECYCLE_JOB_001"
        master_root = self.server.resolve_identifier_child(self.server.JOBS, master_id)
        stored_job = self.server.strict_json_load(master_root / "input" / "job.json")
        self.assertEqual(stored_job["customer"]["firstName"], "Test")
        self.assertEqual(stored_job["customer"]["billingAddress"], "Teststraat")
        self.assertEqual(stored_job["customer"]["houseNumber"], "42-A")
        self.assertFalse(stored_job["customer"]["shippingSameAsBilling"])

        submit_handler = object.__new__(self.server.Handler)
        submit_handler.client_address = ("127.0.0.1", 43123)
        submit_handler.headers = {}
        submit_handler._require_job_access = lambda *args, **kwargs: True
        submit_handler._send_json = lambda obj, code=200: (obj, code)
        # Deliberately omit the browser customer copy. The authenticated,
        # finalized job snapshot must remain the lossless source of truth.
        incoming = {"parentJobId": master_id, "customer": {}, "note": "Eindcontrole"}
        with mock.patch.object(self.server, "_read_json_body_limited", return_value=incoming), mock.patch.object(
            self.server, "_rate_limit_allow", return_value=True
        ), mock.patch.object(self.server, "_notify_submitted", return_value=(True, "")):
            body, code = submit_handler._api_submit_config()
        self.assertEqual(code, 200, body)
        self.assertTrue(body["ok"])

        request_id = body["requestId"]
        status = self.server._load_status(request_id)
        self.assertIsInstance(status, dict)
        customer = status["customer"]
        self.assertEqual(customer["name"], "Test Klant")
        self.assertEqual(customer["company"], "Zaagbedrijf BV")
        self.assertEqual(customer["email"], "test@example.invalid")
        self.assertEqual(customer["phone"], "+31 6 12345678")
        self.assertEqual(customer["billingAddress"], "Teststraat")
        self.assertEqual(customer["shippingAddress"], "Werkplaatsweg")
        self.assertEqual(customer["houseNumber"], "42-A")
        self.assertEqual(customer["postalCode"], "1234 AB")
        self.assertEqual(customer["city"], "Utrecht")

        persisted = self.server.strict_json_load(
            self.server.REQUESTS / request_id / "input" / "submit_payload.json"
        )
        self.assertEqual(persisted["customer"]["houseNumber"], "42-A")
        self.assertEqual(persisted["customer"]["billingAddress"], "Teststraat")

        admin_handler = object.__new__(self.server.Handler)
        admin_handler.path = "/api/admin/requests?limit=500"
        admin_handler._send_json = lambda obj, code=200: (obj, code)
        admin_body, admin_code = self.server.api_admin_requests(admin_handler)
        self.assertEqual(admin_code, 200)
        admin_row = next(row for row in admin_body["requests"] if row["requestId"] == request_id)
        self.assertEqual(admin_row["customer"], customer)

    def test_06_real_backup_restore_roundtrip(self) -> None:
        marker = self.server.SUBMISSION_IDEMPOTENCY_DIR / "roundtrip-marker.json"
        self.server.durable_write_json(
            marker,
            {"schemaVersion": 1, "parentJobId": "LIFECYCLE_JOB_001", "requestId": "REQ_LIFECYCLE_001"},
        )
        created = self.server._create_system_backup(actor="lifecycle-test", backup_kind="manual")
        backup = self.server.BACKUPS_DIR / created["file"]
        self.assertTrue(backup.is_file())

        restore_path = RELEASE_ROOT / "tools" / "restore_system_backup.py"
        spec = importlib.util.spec_from_file_location("fix660r8_restore_runtime", restore_path)
        self.assertIsNotNone(spec)
        self.assertIsNotNone(spec.loader)
        restore_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(restore_module)

        verified = restore_module.verify_backup(backup)
        self.assertGreater(verified["stateFileCount"], 0)
        target = Path(self._temp.name) / "restored-state"
        result = restore_module.restore_backup(backup, target)
        self.assertTrue(result["ok"])
        self.assertEqual((target / marker.relative_to(self.state_root)).read_bytes(), marker.read_bytes())
        self.assertEqual(
            (target / "material_library.json").read_bytes(),
            self.server.MATERIAL_LIBRARY_PATH.read_bytes(),
        )
        self.assertFalse((target / "backups").exists())


if __name__ == "__main__":
    unittest.main(verbosity=2)
