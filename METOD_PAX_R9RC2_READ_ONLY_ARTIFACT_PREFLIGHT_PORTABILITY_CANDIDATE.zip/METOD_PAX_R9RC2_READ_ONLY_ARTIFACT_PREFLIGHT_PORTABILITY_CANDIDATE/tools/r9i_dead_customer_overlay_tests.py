#!/usr/bin/env python3
from __future__ import annotations

"""Fail-closed proof for the R9I-6 obsolete customer-overlay removal."""

import hashlib
import json
import unittest
from pathlib import Path

from r9j_hermetic_reference import assert_sealed_file, load_reference


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
RUNTIME = APP / "tool-a/shell/script-06-legacy-application-runtime.js"
HTML = APP / "toolA.html"
BOOTSTRAP = APP / "tool-a/bootstrap.js"
RULES = ROOT / "R9B_ARCHITECTURE_RULES.json"
REFERENCE = load_reference(ROOT)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


class R9IDeadCustomerOverlayTests(unittest.TestCase):
    def test_01_inline_customer_step_is_the_only_rendered_customer_surface(self) -> None:
        html = HTML.read_text(encoding="utf-8")
        self.assertEqual(html.count('id="stepCustomer"'), 1)
        for element_id in (
            "custFirstName", "custLastName", "custCompany", "custEmail",
            "custPhone", "custBillingAddress", "custPostcode",
            "custHouseNumber", "custShipSame", "custShippingAddress",
            "custRestYes", "custRestNo", "custNote",
        ):
            self.assertEqual(html.count(f'id="{element_id}"'), 1, element_id)
        for obsolete_id in (
            "customerOverlay", "customerCloseBtn", "customerBackBtn",
            "customerNextBtn", "customerNameInput", "customerOrderInput",
            "customerConfirmBtn",
        ):
            self.assertNotIn(obsolete_id, html)

    def test_02_obsolete_customer_overlay_owner_and_globals_are_retired(self) -> None:
        runtime = RUNTIME.read_text(encoding="utf-8")
        for token in (
            "customerOverlay", "customerCloseBtn", "customerBackBtn",
            "customerNextBtn", "customerNameInput", "customerOrderInput",
            "customerConfirmBtn", "ensureCustomerOverlayEls",
            "openCustomerOverlay", "closeCustomerOverlay", "ensureCustomerEls",
        ):
            self.assertNotIn(token, runtime)

    def test_03_active_customer_capture_and_validation_remain_byte_exact(self) -> None:
        current = assert_sealed_file(
            self, ROOT, REFERENCE,
            "app/tool-a/shell/script-06-legacy-application-runtime.js",
        ).decode("utf-8")
        for name in (
            "applyRestCarryToggleUI", "setRestCarryValue", "ensureRestCarryDefault",
            "applyCustShipSameUI", "syncCheckoutUIFromState", "readCustomerFromUI",
            "commitCustomerCalculationSnapshot", "customerForCurrentCalculation",
            "runCheckoutOverlays",
        ):
            self.assertEqual(current.count(f"function {name}"), 1, name)

    def test_04_removal_does_not_touch_price_checkout_or_truth_owners(self) -> None:
        current = assert_sealed_file(
            self, ROOT, REFERENCE,
            "app/tool-a/shell/script-06-legacy-application-runtime.js",
        ).decode("utf-8")
        marker = "  function closePriceOverlay(){\n    try{ const po = byId('priceOverlay');"
        self.assertIn(marker, current)
        exact = {
            "dxf_nesting_optimizer.py": "42480b301cd660dac1e5e9fec2c8d30bb5c6826c32234a9c1cce765b758bebb8",
            "dxf_geometry.py": "b80a2d006241908bf7b33516f7e0faf59ef61e1e08db86966b23cc5de292c1ff",
            "pricing_helpers.py": "646c2f5186e9b080f6ba8dcf364884411c18e946254bb5c9001647f7cbb425df",
            "panel_contract.py": "e23314fd63a2358a48daa580a92cebb8a40c9862548ba0243461a59347da7fc9",
            "toolA_grain_studio_renderer.js": "922cd4ac479fbaf86ebfbb0256808119b96a8344e9b0bf1ffb4f668518a03204",
        }
        for relative, expected in exact.items():
            self.assertEqual(sha256(APP / relative), expected, relative)

    def test_05_foundation_and_architecture_counts_do_not_expand(self) -> None:
        bootstrap = BOOTSTRAP.read_text(encoding="utf-8")
        rules = json.loads(RULES.read_text(encoding="utf-8"))["frontend"]
        self.assertIn('"R9I_SYNC_CATALOG_REFRESH_CLEANUP_9"', bootstrap)
        self.assertEqual(len(rules["moduleImports"]), 19)
        self.assertEqual(len(rules["domOwnerModules"]), 10)
        self.assertEqual(len(rules["networkOwnerModules"]), 2)
        self.assertEqual(rules["compatibilityGlobal"], "ToolAR9Foundation")
        self.assertEqual(rules["maxCompatibilityGlobals"], 1)
        shell = json.loads((ROOT / "R9H10_SEMANTIC_SHELL_ASSETS.json").read_text(encoding="utf-8"))
        self.assertEqual(len(shell["scriptFiles"]), 34)

    def test_06_only_expected_runtime_regions_were_removed(self) -> None:
        current = assert_sealed_file(
            self, ROOT, REFERENCE,
            "app/tool-a/shell/script-06-legacy-application-runtime.js",
        ).decode("utf-8")
        delta = REFERENCE["cleanupDeltas"]["deadCustomerOverlay"]
        self.assertGreaterEqual(delta["minimumBytesRemoved"], 1)
        self.assertGreaterEqual(delta["minimumLinesRemoved"], 1)
        for retained in (
            "function ensurePriceOverlayEls", "function refreshPriceOverlay",
            "function openPriceOverlay", "function closePriceOverlay",
            "function readCustomerFromUI", "function runCheckoutOverlays",
        ):
            self.assertIn(retained, current)


if __name__ == "__main__":
    unittest.main(verbosity=2)
