#!/usr/bin/env python3
from __future__ import annotations

"""One-shot, fail-closed R9H-10 inline asset extraction.

The rewrite preserves the complete CSS byte stream and every classic-script
body in its original order and execution position. It deliberately does not
rewrite selectors, declarations, fix markers or JavaScript behavior.
"""

import hashlib
import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
HTML = APP / "toolA.html"
STYLE_ROOT = APP / "tool-a/styles"
SHELL_ROOT = APP / "tool-a/shell"
ASSET_MANIFEST = ROOT / "R9H10_SEMANTIC_SHELL_ASSETS.json"

STYLE_PATTERN = re.compile(r"<style([^>]*)>([\s\S]*?)</style>", re.IGNORECASE)
SCRIPT_PATTERN = re.compile(r"<script(?![^>]*\bsrc=)([^>]*)>([\s\S]*?)</script>", re.IGNORECASE)

EXPECTED_HTML_SHA256 = "0332e70736f6abee8189813a44566c5b2604e00a49035d2de16c38a78b47b205"
EXPECTED_STYLE_COUNT = 54
EXPECTED_STYLE_BYTES = 246_282
EXPECTED_STYLE_SHA256 = "d53b646045dea70d963915abb46a33889cd24af91cf0f1ea1ce377c6c918bdc9"
EXPECTED_SCRIPT_COUNT = 34
EXPECTED_SCRIPT_BYTES = 510_324
EXPECTED_SCRIPT_SHA256 = "19ab0e30a24e44c618e78c14e16c63089739e235e12cd0cd7af84946f1911d1c"

STYLE_PHASES = (
    ("tokens", 1),
    ("base", 2),
    ("layout", 3),
    ("components", 25),
    ("mobile", 17),
    ("grain", 2),
    ("checkout", 4),
)

SCRIPT_NAMES = {
    1: "early-catalog-bootstrap",
    2: "overview-helpers",
    3: "fresh-configuration-guard",
    4: "first-event-owner",
    5: "bootstrap-bridge",
    6: "legacy-application-runtime",
}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def slug(value: str) -> str:
    value = re.sub(r"([a-z0-9])([A-Z])", r"\1-\2", value)
    value = re.sub(r"[^A-Za-z0-9]+", "-", value).strip("-").lower()
    return value or "compat"


def script_name(index: int, attrs: str) -> str:
    if index in SCRIPT_NAMES:
        label = SCRIPT_NAMES[index]
    else:
        match = re.search(r"\bid=[\"']([^\"']+)", attrs, re.IGNORECASE)
        label = slug(match.group(1)) if match else "compat"
    return f"script-{index:02d}-{label}.js"


def main() -> int:
    source_bytes = HTML.read_bytes()
    if sha256(source_bytes) != EXPECTED_HTML_SHA256:
        raise SystemExit("R9H-10 extraction refused: toolA.html is not the sealed R9H-9 source")
    source = source_bytes.decode("utf-8")
    styles = list(STYLE_PATTERN.finditer(source))
    scripts = list(SCRIPT_PATTERN.finditer(source))
    style_stream = "".join(match.group(2) for match in styles).encode()
    script_stream = "".join(match.group(2) for match in scripts).encode()
    if (len(styles), len(style_stream), sha256(style_stream)) != (
        EXPECTED_STYLE_COUNT, EXPECTED_STYLE_BYTES, EXPECTED_STYLE_SHA256,
    ):
        raise SystemExit("R9H-10 extraction refused: inline style ledger drift")
    if (len(scripts), len(script_stream), sha256(script_stream)) != (
        EXPECTED_SCRIPT_COUNT, EXPECTED_SCRIPT_BYTES, EXPECTED_SCRIPT_SHA256,
    ):
        raise SystemExit("R9H-10 extraction refused: inline script ledger drift")

    STYLE_ROOT.mkdir(parents=True, exist_ok=True)
    SHELL_ROOT.mkdir(parents=True, exist_ok=True)

    style_files: list[dict[str, object]] = []
    style_replacements: dict[int, str] = {}
    cursor = 0
    for phase, count in STYLE_PHASES:
        selected = styles[cursor:cursor + count]
        payload = "".join(match.group(2) for match in selected).encode()
        relative = f"tool-a/styles/{phase}.css"
        (APP / relative).write_bytes(payload)
        style_files.append({"path": relative, "bytes": len(payload), "sha256": sha256(payload), "blockCount": count})
        style_replacements[selected[0].start()] = (
            f'<link rel="stylesheet" href="{relative}?v=r9h-semantic-shell-10" '
            f'data-r9h-style-phase="{phase}">'
        )
        for match in selected[1:]:
            style_replacements[match.start()] = ""
        cursor += count
    if cursor != len(styles):
        raise SystemExit("R9H-10 extraction refused: CSS phase ledger incomplete")

    def replace_style(match: re.Match[str]) -> str:
        return style_replacements[match.start()]

    rewritten = STYLE_PATTERN.sub(replace_style, source)

    script_files: list[dict[str, object]] = []
    script_index = 0

    def replace_script(match: re.Match[str]) -> str:
        nonlocal script_index
        script_index += 1
        attrs = match.group(1)
        payload = match.group(2).encode()
        name = script_name(script_index, attrs)
        relative = f"tool-a/shell/{name}"
        (APP / relative).write_bytes(payload)
        script_files.append({"path": relative, "bytes": len(payload), "sha256": sha256(payload)})
        return f'<script{attrs} src="{relative}?v=r9h-semantic-shell-10"></script>'

    rewritten = SCRIPT_PATTERN.sub(replace_script, rewritten)
    if script_index != EXPECTED_SCRIPT_COUNT:
        raise SystemExit("R9H-10 extraction refused: script ledger incomplete")

    rewritten = rewritten.replace(
        '<meta name="metod-release-revision" content="R9K5" />',
        '<meta name="metod-release-revision" content="R9K5" />\n'
        '  <meta name="metod-shell-revision" content="R9H_SEMANTIC_SHELL_10" />',
        1,
    )
    rewritten = rewritten.replace(
        '<div class="app">',
        '<main class="app" id="toolAAppShell" aria-label="METOD/PAX configurator">',
        1,
    )
    rewritten = rewritten.replace(
        '<div class="left">',
        '<div class="left" role="region" aria-label="Paneelvoorbeeld">',
        1,
    )
    rewritten = rewritten.replace(
        '<div class="right">',
        '<div class="right" role="region" aria-label="Configuratiestappen">',
        1,
    )
    rewritten = rewritten.replace(
        '<div class="stepbar" id="stepbar">',
        '<div class="stepbar" id="stepbar" role="navigation" aria-label="Configuratiestappen">',
        1,
    )
    rewritten = rewritten.replace(
        '<div class="rightScroll" id="rightScroll">',
        '<div class="rightScroll" id="rightScroll" role="region" aria-label="Actieve configuratiestap">',
        1,
    )
    rewritten = rewritten.replace(
        '<div id="wizardFooter" class="section" style=',
        '<footer id="wizardFooter" class="section" style=',
        1,
    )
    rewritten = rewritten.replace(
        '        </div>\n    </div>\n\n    <div id="mobileMaterialCartBackdrop"',
        '        </div>\n    </footer>\n\n    <div id="mobileMaterialCartBackdrop"',
        1,
    )
    rewritten = rewritten.replace(
        '    </section>\n  </div>\n\n\n\n<script id="fix660r8wFreshConfigurationGuard"',
        '    </section>\n  </main>\n\n\n\n<script id="fix660r8wFreshConfigurationGuard"',
        1,
    )

    if STYLE_PATTERN.search(rewritten) or SCRIPT_PATTERN.search(rewritten):
        raise SystemExit("R9H-10 extraction refused: inline application assets remain")
    if rewritten.count('<main class="app" id="toolAAppShell"') != 1 or rewritten.count("</main>") != 1:
        raise SystemExit("R9H-10 extraction refused: semantic app shell is incomplete")
    if rewritten.count('<footer id="wizardFooter"') != 1 or rewritten.count("</footer>") != 1:
        raise SystemExit("R9H-10 extraction refused: semantic footer is incomplete")

    HTML.write_text(rewritten, encoding="utf-8")
    combined_styles = b"".join((APP / item["path"]).read_bytes() for item in style_files)
    combined_scripts = b"".join((APP / item["path"]).read_bytes() for item in script_files)
    manifest = {
        "schemaVersion": 1,
        "contractId": "R9H10_SEMANTIC_SHELL_ASSETS",
        "sourceHtmlSha256": EXPECTED_HTML_SHA256,
        "stylePhases": style_files,
        "styleBlockBytes": [len(match.group(2).encode()) for match in styles],
        "styleBlockAttributes": [match.group(1) for match in styles],
        "scriptFiles": script_files,
        "combinedStyleBytes": len(combined_styles),
        "combinedStyleSha256": sha256(combined_styles),
        "combinedScriptBytes": len(combined_scripts),
        "combinedScriptSha256": sha256(combined_scripts),
        "inlineStyleElementCount": 0,
        "inlineScriptElementCount": 0,
    }
    ASSET_MANIFEST.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(manifest, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
