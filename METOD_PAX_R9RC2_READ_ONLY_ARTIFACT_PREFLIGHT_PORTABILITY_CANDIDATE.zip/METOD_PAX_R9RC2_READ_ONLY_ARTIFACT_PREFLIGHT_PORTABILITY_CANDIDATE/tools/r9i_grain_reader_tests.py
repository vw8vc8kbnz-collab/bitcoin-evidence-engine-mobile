#!/usr/bin/env python3
from __future__ import annotations

"""Fail-closed equivalence proof for the R9I-2 pure grain readers."""

import base64
import json
import re
import shutil
import subprocess
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
SELECTORS = APP / "tool-a/state/selectors.js"
STORE = APP / "tool-a/state/store.js"
BOOTSTRAP = APP / "tool-a/bootstrap.js"
RUNTIME = APP / "tool-a/shell/script-06-legacy-application-runtime.js"


def data_url(data: bytes) -> str:
    return "data:text/javascript;base64," + base64.b64encode(data).decode()


def run_node(source: str) -> dict:
    node = shutil.which("node")
    if not node:
        raise AssertionError("Node is required by the R9I clean-code gate")
    completed = subprocess.run(
        [node, "--input-type=module"],
        input=source,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=10,
        check=False,
    )
    if completed.returncode != 0:
        raise AssertionError(completed.stdout)
    return json.loads(completed.stdout.strip().splitlines()[-1])


class R9IGrainReaderTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.selectors_url = data_url(SELECTORS.read_bytes())
        store_source = STORE.read_text(encoding="utf-8").replace(
            "./selectors.js", cls.selectors_url,
        )
        cls.store_url = data_url(store_source.encode())

    def test_01_selectors_match_the_removed_legacy_decisions(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(self.selectors_url)});
const states=[
  {{grain:{{materialKey:' grain-a '}},activeMaterialKey:'active',materialBatches:[{{key:'grain-a',grainEnabled:false}}]}},
  {{grain:{{materialKey:''}},activeMaterialKey:' active ',materialBatches:[{{key:'active',grainEnabled:true}}]}},
  {{grain:{{materialKey:'   '}},activeMaterialKey:' active ',materialBatches:[{{key:' active ',grainEnabled:false}}]}},
  {{grain:{{}},activeMaterialKey:'',materialBatches:[]}},
  null,
];
const items=[
  {{materialKey:'grain-a'}},
  {{materialCode:'active'}},
  {{articleNumber:'other'}},
  null,
];
function legacyMaterialKey(state){{
  try{{const k=String(state.grain?.materialKey||'').trim();return k||String(state.activeMaterialKey||'').trim()||'';}}catch(_e){{return '';}}
}}
function legacyEnabled(state,mk){{
  try{{const k=String(mk||'').trim();if(!k)return true;const b=(state.materialBatches||[]).find(x=>String(x.key||'')===k);if(b&&typeof b.grainEnabled==='boolean')return b.grainEnabled;}}catch(_e){{}}
  return true;
}}
function legacyCapable(state,item){{
  const mk=item?.materialKey||item?.materialCode||item?.articleNumber||'';
  if(!legacyEnabled(state,mk))return false;
  const selected=legacyMaterialKey(state);
  return !(selected&&String(mk)!==String(selected));
}}
const observed=[];
for(const state of states){{
  observed.push({{
    material:[legacyMaterialKey(state),m.selectGrainMaterialKey(state)],
    enabled:['grain-a','active','missing',''].map(key=>[legacyEnabled(state,key),m.selectGrainEnabledForMaterial(state,key)]),
    capable:items.map(item=>[legacyCapable(state,item),m.selectIsGrainCapableItem(state,item)]),
  }});
}}
console.log(JSON.stringify({{observed}}));
""")
        for case in result["observed"]:
            self.assertEqual(case["material"][0], case["material"][1])
            self.assertTrue(all(pair[0] == pair[1] for pair in case["enabled"]))
            self.assertTrue(all(pair[0] == pair[1] for pair in case["capable"]))

    def test_02_reference_parser_is_byte_for_byte_shape_equivalent(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(self.selectors_url)});
function legacy(ref){{
  if(typeof ref==='number')return {{kind:'cart',idx:Number(ref),rep:null}};
  const s=String(ref||'').trim();if(!s)return null;
  if(/^\\d+$/.test(s))return {{kind:'cart',idx:Number(s),rep:null}};
  const parts=s.split(':');
  if(parts[0]==='extra')return {{kind:'extra',idx:Number(parts[1]),rep:Number(parts[2]||0)}};
  if(parts[0]==='cart')return {{kind:'cart',idx:Number(parts[1]),rep:null}};
  return null;
}}
const refs=[0,3,' 12 ','cart:4','extra:5:2','extra:7','cart:nope','extra:nope:x','',null,'other:1'];
const pairs=refs.map(ref=>[legacy(ref),m.parseGrainReference(ref)]);
console.log(JSON.stringify({{pairs}}));
""")
        self.assertTrue(all(pair[0] == pair[1] for pair in result["pairs"]))

    def test_03_store_reads_fresh_state_and_fails_closed(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(self.store_url)});
let state={{grain:{{materialKey:'a'}},materialBatches:[{{key:'a',grainEnabled:false}}]}};
const store=m.createToolAStore(()=>({{state,runtime:{{}}}}));
const first={{key:store.getGrainMaterialKey(),enabled:store.isGrainEnabledForMaterial('a'),capable:store.isGrainCapableItem({{materialKey:'a'}})}};
state={{grain:{{materialKey:'b'}},materialBatches:[{{key:'b',grainEnabled:true}}]}};
const second={{key:store.getGrainMaterialKey(),enabled:store.isGrainEnabledForMaterial('b'),capable:store.isGrainCapableItem({{materialKey:'b'}}),parsed:store.parseGrainReference('extra:2:1')}};
const broken=m.createToolAStore(()=>{{throw new Error('boom')}});
const fallback={{key:broken.getGrainMaterialKey(),enabled:broken.isGrainEnabledForMaterial('a'),capable:broken.isGrainCapableItem({{materialKey:'a'}})}};
console.log(JSON.stringify({{first,second,fallback,keys:Reflect.ownKeys(store),frozen:Object.isFrozen(store)}}));
""")
        self.assertEqual(result["first"], {"key": "a", "enabled": False, "capable": False})
        self.assertEqual(result["second"], {
            "key": "b", "enabled": True, "capable": True,
            "parsed": {"kind": "extra", "idx": 2, "rep": 1},
        })
        self.assertEqual(result["fallback"], {"key": "", "enabled": True, "capable": False})
        self.assertEqual(result["keys"], [
            "getSnapshot", "getCustomerSnapshot", "normalizeCustomerSnapshot",
            "getGrainMaterialKey", "isGrainEnabledForMaterial",
            "isGrainCapableItem", "parseGrainReference",
            "getMaterialThickness", "getUsableMaterialSheetDimensions",
        ])
        self.assertTrue(result["frozen"])

    def test_04_native_read_layer_has_no_side_effect_owner(self) -> None:
        source = SELECTORS.read_text(encoding="utf-8") + STORE.read_text(encoding="utf-8")
        for token in (
            "document", "addEventListener", "fetch(", "XMLHttpRequest", "EventSource",
            "WebSocket", "localStorage", "sessionStorage", "window", "globalThis",
        ):
            self.assertNotIn(token.lower(), source.lower(), token)

    def test_05_legacy_grain_readers_are_thin_adapters(self) -> None:
        source = RUNTIME.read_text(encoding="utf-8")
        expected = {
            "grainEnabledForKey": "owner.isGrainEnabledForMaterial(mk)",
            "grainOverlaySelectedMaterialKey": "owner.getGrainMaterialKey()",
            "isGrainCapable": "owner.isGrainCapableItem(it)",
            "parseGrainRef": "owner.parseGrainReference(ref)",
        }
        for name, call in expected.items():
            match = re.search(
                rf"^(?P<indent>[ \t]*)function {name}\([^\n]*\)\{{(?P<body>.*?)^(?P=indent)\}}",
                source,
                re.MULTILINE | re.DOTALL,
            )
            self.assertIsNotNone(match, name)
            body = match.group("body")
            self.assertIn(call, body)
            for removed in (
                "state.materialBatches", "state.grain", "const parts", ".split(':')",
            ):
                self.assertNotIn(removed, body)

    def test_06_bootstrap_exposes_only_the_single_frozen_adapter(self) -> None:
        source = BOOTSTRAP.read_text(encoding="utf-8")
        self.assertIn('"R9I_SYNC_CATALOG_REFRESH_CLEANUP_9"', source)
        for token in (
            "getGrainMaterialKey: () => toolAStore.getGrainMaterialKey()",
            "isGrainEnabledForMaterial: (materialKey) => toolAStore.isGrainEnabledForMaterial(materialKey)",
            "isGrainCapableItem: (item) => toolAStore.isGrainCapableItem(item)",
            "parseGrainReference: (reference) => toolAStore.parseGrainReference(reference)",
        ):
            self.assertEqual(source.count(token), 1, token)
        self.assertEqual(source.count("Object.defineProperty(globalThis"), 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
