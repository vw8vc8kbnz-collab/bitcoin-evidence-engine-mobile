#!/usr/bin/env python3
from __future__ import annotations

"""Executable ownership and behavior contracts for R9L3 request downloads."""

import ast
import hashlib
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
SERVER = APP / "server_py.py"
OWNER = APP / "metod_app/requests/downloads.py"
FIXTURE = ROOT / "R9L3_REQUEST_DOWNLOAD_BEFORE_FIXTURE.json"
SCOPE = ROOT / "R9L3_REQUEST_DOWNLOAD_PROJECTIONS_EXTRACTION_SCOPE.json"
CONTRACT = ROOT / "R9L3_REQUEST_DOWNLOAD_PROJECTIONS_EXTRACTION.json"
_STATE_TEMP = tempfile.TemporaryDirectory(prefix="r9l3_request_download_tests_")
os.environ.setdefault("METOD_STATE_ROOT", str(Path(_STATE_TEMP.name) / "state"))
os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")
sys.path.insert(0, str(APP))
sys.path.insert(0, str(ROOT / "tools"))

import server_py as server  # noqa: E402
from metod_app.requests.downloads import (  # noqa: E402
    RequestDownloadDependencies,
    RequestDownloadProjectionService,
    RequestExportPlan,
)
from r9l3_request_download_before_gate import _behavior  # noqa: E402


def sha256(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


class R9L3RequestDownloadTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.fixture = json.loads(FIXTURE.read_text(encoding="utf-8"))
        cls.scope = json.loads(SCOPE.read_text(encoding="utf-8"))
        cls.contract = json.loads(CONTRACT.read_text(encoding="utf-8"))
        cls.server_source = SERVER.read_text(encoding="utf-8", errors="strict")
        cls.owner_source = OWNER.read_text(encoding="utf-8", errors="strict")
        cls.server_tree = ast.parse(cls.server_source)
        cls.owner_tree = ast.parse(cls.owner_source)
        cls.server_functions = {
            node.name: node
            for node in cls.server_tree.body
            if isinstance(node, ast.FunctionDef)
        }

    def server_function_source(self, name: str) -> str:
        value = ast.get_source_segment(self.server_source, self.server_functions[name])
        self.assertIsNotNone(value)
        return str(value)

    def test_01_fixture_seals_exact_r9l2_source_before_extraction(self) -> None:
        self.assertEqual(self.fixture["sourceCheckpoint"], "R9L2")
        self.assertEqual(
            self.fixture["sourceCommit"],
            "8a703d8028cc42ffa860f5e102ce8897c0e58e00",
        )
        self.assertEqual(self.fixture["server"], {
            "bytes": 526841,
            "lines": 11542,
            "sha256": "1b8889d1679e6bb2f82abedf2313133d5a921f9d62b3ce7a5866dc17de576f42",
        })
        self.assertEqual(len(self.fixture["activeOwnerSource"]), 6)

    def test_02_one_module_owns_all_request_download_projections(self) -> None:
        classes = {
            node.name for node in self.owner_tree.body if isinstance(node, ast.ClassDef)
        }
        self.assertEqual(classes, {
            "RequestDownloadDependencies",
            "RequestExportPlan",
            "RequestDownloadProjectionService",
        })
        service = next(
            node for node in self.owner_tree.body
            if isinstance(node, ast.ClassDef)
            and node.name == "RequestDownloadProjectionService"
        )
        methods = {
            node.name for node in service.body if isinstance(node, ast.FunctionDef)
        }
        self.assertTrue({
            "find_finalized_stickertool_file",
            "list_requests",
            "build_manifest",
            "resolve_linked_file",
            "build_export_plan",
        }.issubset(methods))
        self.assertTrue(hasattr(server, "_REQUEST_DOWNLOAD_PROJECTIONS"))

    def test_03_owner_has_no_transport_zip_lock_or_mutation_ownership(self) -> None:
        imports: set[str] = set()
        for node in ast.walk(self.owner_tree):
            if isinstance(node, ast.Import):
                imports.update(alias.name.split(".")[0] for alias in node.names)
            elif isinstance(node, ast.ImportFrom) and node.module:
                imports.add(node.module.split(".")[0])
        self.assertTrue({
            "http", "server_py", "socket", "subprocess", "threading", "zipfile",
        }.isdisjoint(imports))
        for forbidden in (
            "SimpleHTTPRequestHandler", "Handler", "ZipFile(", "os.fsync",
            ".unlink(", ".write_text(", ".write_bytes(", "Lock(",
        ):
            self.assertNotIn(forbidden, self.owner_source)

    def test_04_server_keeps_only_thin_projection_and_transport_adapters(self) -> None:
        for name in ("_find_or_generate_stickertool_file", "_build_request_file_manifest"):
            source = self.server_function_source(name)
            self.assertIn("_REQUEST_DOWNLOAD_PROJECTIONS", source)
            self.assertLessEqual(len(source.splitlines()), 2)
        self.assertNotIn("for p in sorted(REQUESTS.glob", self.server_source)
        self.assertNotIn("files[:10_000]", self.server_source)
        self.assertIn("plan = _REQUEST_DOWNLOAD_PROJECTIONS.build_export_plan", self.server_source)
        zip_adapter = self.server_function_source("api_admin_request_download_zip")
        for retained in ("zipfile.ZipFile", "os.fsync", "_stream_file", "unlink"):
            self.assertIn(retained, zip_adapter)

    def test_05_all_sealed_behavior_scenarios_are_byte_exact(self) -> None:
        actual = _behavior()
        for key, value in actual.items():
            self.assertEqual(value, self.fixture[key], key)

    def test_06_mailbox_order_bounds_and_read_only_contract_are_preserved(self) -> None:
        mailbox = self.fixture["mailboxScenario"]
        self.assertTrue(mailbox["readOnly"])
        self.assertEqual(
            mailbox["limitOne"]["payload"]["requests"][0]["requestId"],
            "REQ_NEW",
        )
        self.assertEqual(
            len(mailbox["invalidLimitFallsBackTo200"]["payload"]["requests"]),
            2,
        )
        self.assertEqual(
            mailbox["zeroClampsToOne"], mailbox["limitOne"],
        )

    def test_07_manifest_remains_sealed_grouped_priced_and_storage_bounded(self) -> None:
        manifest = self.fixture["manifestScenario"]
        self.assertEqual(manifest["subjobs"], ["JOB_R9L3_PARENT__mat_001"])
        self.assertEqual(len(manifest["dxfGroups"]), 1)
        group_relatives = {item["rel"] for item in manifest["dxfGroups"][0]["files"]}
        self.assertNotIn("output/DXF_Onderdelen/part-a.dxf", group_relatives)
        self.assertEqual(manifest["pricingSummary"]["source"], "calculation-summary")
        self.assertEqual(manifest["storageSummary"], {
            "requestBytes": 10,
            "jobsBytes": 50,
            "totalBytes": 60,
            "jobCount": 2,
            "subjobCount": 1,
        })

    def test_08_individual_file_and_export_plans_fail_closed(self) -> None:
        routes = self.fixture["routeOutcomeMatrix"]
        self.assertEqual(routes["requestFileUnlinked"]["status"], 404)
        self.assertEqual(routes["requestFileLinked"]["downloadName"], "Klant_Een__Eiken__001.dxf")
        outcomes = self.fixture["zipOutcomeMatrix"]
        self.assertEqual(outcomes["staleManifest"]["status"], 409)
        self.assertEqual(outcomes["overInputLimit"]["status"], 413)
        self.assertEqual(outcomes["success"]["members"], [{
            "name": "MAT_ONE/DXF_Zaagplaten/Klant__Eiken__001.dxf",
            "sha256": "51a494aba62a93d0ec5a04dd3e1d33df61f4365820457e4976123b574bc9e09e",
        }])
        self.assertTrue(RequestExportPlan.failure(409, "x", "r", "all").selected == ())

    def test_09_all_four_routes_remain_behind_admin_auth_before_dispatch(self) -> None:
        auth = "if parsed.path.startswith('/api/admin/'):"
        auth_index = self.server_source.index(auth)
        for route in self.scope["sealedRoutes"]:
            route_key = route.replace("GET ", "GET ")
            marker = f"route_key == '{route_key}'"
            self.assertLess(auth_index, self.server_source.index(marker), route)

    def test_10_public_and_general_download_owners_remain_byte_exact(self) -> None:
        expected = {
            "api_job_file": "f3ab484d468a097b9b27777a056f8fba15404ec36b8c1dfe8f098ddda4bb5e5a",
            "api_subjob_file": "2dcc3d0b02dac3c623afaac92a72860d886563d86ab27c8a161c0b211f3538d2",
            "api_download": "b022c7b88787faef8ef664479f9ee0f72db799f2fcf70eae715ba2281cbda09c",
        }
        for name, digest in expected.items():
            self.assertEqual(sha256(self.server_function_source(name).encode("utf-8")), digest, name)

    def test_11_scope_is_exclusive_and_security_boundaries_are_explicit(self) -> None:
        self.assertEqual(
            self.scope["contractId"],
            "R9L3_REQUEST_DOWNLOAD_PROJECTIONS_EXTRACTION_SCOPE",
        )
        self.assertEqual(len(self.scope["sealedRoutes"]), 4)
        self.assertIn("R9M HTML, CSS or JavaScript splitting", self.scope["excluded"])
        self.assertIn("readOnlyProjection", self.scope["privacyAndSafetyBoundaries"])
        self.assertNotIn("optimizer", self.owner_source.lower())

    def test_12_checkpoint_is_provisional_and_next_scope_is_exclusive(self) -> None:
        self.assertEqual(
            self.contract["contractId"],
            "R9L3_REQUEST_DOWNLOAD_PROJECTIONS_EXTRACTION",
        )
        self.assertEqual(self.contract["status"], "PROVISIONAL_DEVELOPMENT_ONLY")
        self.assertFalse(self.contract["releaseEligible"])
        self.assertFalse(self.contract["externalEvidence"]["productionGo"])
        self.assertEqual(
            self.contract["nextExclusiveCheckpoint"],
            "R9L4_STATIC_FILE_AND_REMAINING_HTTP_ADAPTERS_EXTRACTION",
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
