#!/usr/bin/env python3
from __future__ import annotations

"""Pure-contract and bounded-runtime-use proofs for the R9F route catalog."""

import ast
import hashlib
import json
import sys
import unittest
from collections import Counter
from dataclasses import FrozenInstanceError, replace
from pathlib import Path


RELEASE = Path(__file__).resolve().parents[1]
APP = RELEASE / "app"
SERVER = APP / "server_py.py"
sys.path.insert(0, str(APP))

from metod_app.http.contracts import (  # noqa: E402
    BodyPolicy,
    RateLimitPolicy,
    RouteDefinition,
    validate_route_catalog,
)
from metod_app.http.routes import ROUTES, ROUTES_BY_KEY, route_definition  # noqa: E402


EXPECTED_CATALOG_SHA256 = "a1b9a94622cf4ece643c940836a358325a9e12b48bd66a47bacb1b373fd6edb9"
EXPECTED_SERVER_SHA256 = "84b3b0d3713d4d6da472d6b7d4351e166aac59e1fde1812cf60ccbd84d77556a"


def catalog_projection() -> list[dict[str, object]]:
    return [
        {
            "method": route.method,
            "pattern": route.pattern,
            "dispatchId": route.dispatch_id,
            "handlerId": route.handler_id,
            "accessPolicy": route.access_policy,
            "originPolicy": route.origin_policy,
            "body": {
                "consumption": route.body.consumption,
                "ownerId": route.body.owner_id,
                "readerId": route.body.reader_id,
                "limitEnvironment": route.body.limit_environment,
                "defaultBytes": route.body.default_bytes,
                "declaredMaximum": route.body.declared_maximum,
            },
            "rateLimit": {
                "ownerId": route.rate_limit.owner_id,
                "bucket": route.rate_limit.bucket,
                "maximum": route.rate_limit.maximum,
                "windowSeconds": route.rate_limit.window_seconds,
                "declared": route.rate_limit.declared,
            },
            "maintenancePolicy": route.maintenance_policy,
            "responseKind": route.response_kind,
            "businessMutation": route.business_mutation,
            "runtimeMutation": route.runtime_mutation,
            "piiClassification": route.pii_classification,
            "securityHeaderProfile": route.security_header_profile,
            "errorSchema": route.error_schema,
        }
        for route in ROUTES
    ]


def canonical_sha(value: object) -> str:
    encoded = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()
    return hashlib.sha256(encoded).hexdigest()


class R9FRouteCatalogTests(unittest.TestCase):
    def test_01_contracts_are_frozen_and_own_no_callables(self) -> None:
        route = ROUTES[0]
        with self.assertRaises(FrozenInstanceError):
            route.pattern = "/changed"  # type: ignore[misc]
        with self.assertRaises(FrozenInstanceError):
            route.body.consumption = "bounded-json"  # type: ignore[misc]
        for item in ROUTES:
            self.assertFalse(any(callable(value) for value in (
                item.dispatch_id, item.handler_id, item.access_policy,
                item.origin_policy, item.maintenance_policy,
            )))

    def test_02_catalog_has_exact_unique_80_route_surface(self) -> None:
        self.assertEqual(len(ROUTES), 80)
        self.assertEqual(len(ROUTES_BY_KEY), 80)
        self.assertEqual(len({route.key for route in ROUTES}), 80)
        self.assertEqual(
            Counter(route.method for route in ROUTES),
            {"GET": 42, "HEAD": 12, "OPTIONS": 1, "POST": 25},
        )

    def test_03_catalog_projection_is_bound_to_one_exact_digest(self) -> None:
        self.assertEqual(canonical_sha(catalog_projection()), EXPECTED_CATALOG_SHA256)

    def test_04_lookup_is_normalized_read_only_and_fail_closed(self) -> None:
        self.assertIs(route_definition("get", "/health/live"), ROUTES_BY_KEY["GET /health/live"])
        self.assertIsNone(route_definition("DELETE", "/health/live"))
        with self.assertRaises(TypeError):
            ROUTES_BY_KEY["GET /new"] = ROUTES[0]  # type: ignore[index]

    def test_05_body_policies_are_complete_and_exact(self) -> None:
        bounded = [route for route in ROUTES if route.body.consumption == "bounded-json"]
        self.assertEqual(len(bounded), 22)
        self.assertEqual(len(ROUTES) - len(bounded), 58)
        self.assertEqual({
            route.pattern for route in ROUTES
            if route.method == "POST" and route.body.consumption == "none"
        }, {
            "/api/admin/logout", "/api/admin/materials/image_delete",
            "/api/admin/system/backup_now",
        })
        self.assertTrue(all(route.body.reader_id == "_read_json_body_limited" for route in bounded))

    def test_06_rate_limit_policies_are_exact(self) -> None:
        limited = {route.key: route.rate_limit for route in ROUTES if route.rate_limit.owner_id}
        self.assertEqual(set(limited), {
            "POST /api/admin/login", "POST /api/cancel", "POST /api/client_log",
            "POST /api/jobs", "POST /api/jobs/cancel", "POST /api/submit_config",
        })
        self.assertEqual(
            (limited["POST /api/jobs"].bucket, limited["POST /api/jobs"].maximum,
             limited["POST /api/jobs"].window_seconds),
            ("api_jobs", 12, 300),
        )

    def test_07_security_and_mutation_metadata_stay_explicit(self) -> None:
        self.assertEqual(sum(route.business_mutation for route in ROUTES), 21)
        self.assertEqual(sum(route.runtime_mutation for route in ROUTES), 49)
        public_origin = {
            route.pattern for route in ROUTES if route.origin_policy == "exact-public-origin"
        }
        self.assertEqual(public_origin, {
            "/api/cancel", "/api/client_log", "/api/draft/save",
            "/api/jobs", "/api/jobs/cancel", "/api/submit_config",
        })
        self.assertTrue(all(
            "admin-origin" in route.origin_policy
            for route in ROUTES
            if route.method == "POST" and route.pattern.startswith("/api/admin/")
        ))

    def test_08_validator_rejects_duplicates_partial_limits_and_read_mutations(self) -> None:
        base = ROUTES[0]
        self.assertIn("duplicate route", " ".join(validate_route_catalog((base, base))))
        partial = replace(base, rate_limit=RateLimitPolicy(
            owner_id="owner", bucket=None, maximum=1, window_seconds=60, declared="partial",
        ))
        self.assertIn("partial rate-limit", " ".join(validate_route_catalog((partial,))))
        mutation = replace(base, business_mutation=True)
        self.assertIn("read method", " ".join(validate_route_catalog((mutation,))))
        body = replace(base, body=BodyPolicy(
            consumption="bounded-json", owner_id=None, reader_id=None,
            limit_environment=None, default_bytes=None, declared_maximum="none",
        ))
        self.assertIn("bounded body", " ".join(validate_route_catalog((body,))))

    def test_09_modules_have_no_runtime_owner_imports_or_side_effect_tokens(self) -> None:
        for relative in ("http/contracts.py", "http/routes.py"):
            path = APP / "metod_app" / relative
            source = path.read_text(encoding="utf-8")
            tree = ast.parse(source, filename=str(path))
            imports = {
                alias.name.split(".", 1)[0]
                for node in ast.walk(tree) if isinstance(node, ast.Import)
                for alias in node.names
            } | {
                str(node.module or "").split(".", 1)[0]
                for node in ast.walk(tree)
                if isinstance(node, ast.ImportFrom) and node.level == 0
            }
            self.assertFalse(imports & {
                "http", "os", "pathlib", "server_py", "socket", "subprocess", "threading",
            })
            for token in ("open(", "fetch(", "Popen(", "Thread(", "Lock(", "serve_forever("):
                self.assertNotIn(token, source, (relative, token))

    def test_10_live_server_is_exact_and_uses_catalog_only_through_matcher(self) -> None:
        source = SERVER.read_text(encoding="utf-8")
        self.assertEqual(hashlib.sha256(source.encode()).hexdigest(), EXPECTED_SERVER_SHA256)
        self.assertIn(
            "from metod_app.http.matcher import match_route as _match_http_route",
            source,
        )
        self.assertNotIn("metod_app.http.routes", source)
        self.assertNotIn("metod_app.http.contracts", source)
        self.assertNotIn("ROUTES_BY_KEY", source)
        self.assertNotIn("route_definition", source)


if __name__ == "__main__":
    unittest.main(verbosity=2)
