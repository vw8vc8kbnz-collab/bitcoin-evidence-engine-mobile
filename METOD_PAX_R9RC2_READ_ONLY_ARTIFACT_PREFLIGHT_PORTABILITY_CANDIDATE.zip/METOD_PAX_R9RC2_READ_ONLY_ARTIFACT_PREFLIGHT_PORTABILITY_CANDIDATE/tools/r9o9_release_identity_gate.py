#!/usr/bin/env python3
from __future__ import annotations

"""Fail-closed R9O9 release identity and protected-file gate."""

import argparse
import hashlib
import json
import sys
from pathlib import Path


REVISION = "R9O9"
BUILD = "R9O9_EXTERNAL_AUDIT_SECURITY_PRIVACY_REMEDIATION"
ARTIFACT = "METOD_PAX_R9O9_EXTERNAL_AUDIT_SECURITY_PRIVACY_REMEDIATION_CANDIDATE.zip"
ARTIFACT_ROOT = "METOD_PAX_R9O9_EXTERNAL_AUDIT_SECURITY_PRIVACY_REMEDIATION_CANDIDATE"
TAG = "r9o9-external-audit-security-privacy-remediation-candidate-checkpoint"
GOLDEN_SHA256 = "d3e8656d8d7d5a581a8186ef8fe2c91c19b2137a8654b2f2874497dd85255e62"


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_json(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise AssertionError(f"JSON object required: {path.name}")
    return value


def audit_release(release: Path) -> list[str]:
    failures: list[str] = []

    def require(condition: bool, message: str) -> None:
        if not condition:
            failures.append(message)

    try:
        identity = load_json(release / "RELEASE_IDENTITY.json")
        candidate = identity.get("canonicalCandidate") or {}
        golden = identity.get("immutableGoldenBaseline") or {}
        evidence = identity.get("externalEvidence") or {}
        require(identity.get("contractId") == "R9O9_RELEASE_IDENTITY", "identity-contract")
        require(candidate.get("releaseRevision") == REVISION, "release-revision")
        require(candidate.get("buildId") == BUILD, "build-id")
        require(candidate.get("artifactName") == ARTIFACT, "artifact-name")
        require(candidate.get("artifactRootDirectory") == ARTIFACT_ROOT, "artifact-root")
        require(candidate.get("intendedSourceTag") == TAG, "source-tag")
        require(candidate.get("releaseEligible") is False, "release-must-remain-ineligible")
        require(golden.get("artifactSha256") == GOLDEN_SHA256, "golden-sha256")
        require(evidence.get("productionGo") is False, "production-must-remain-no-go")
        require("R9O9_RERUN_REQUIRED_NO_GO" in str(evidence.get("browser") or ""), "browser-rerun-state")

        contract = load_json(release / "RUNTIME_CONTRACT.json")
        require(contract.get("build") == BUILD, "runtime-build")
        require(contract.get("releaseRevision") == REVISION, "runtime-revision")
        require(contract.get("artifactName") == ARTIFACT, "runtime-artifact")
        require(contract.get("artifactRootDirectory") == ARTIFACT_ROOT, "runtime-root")
        require(contract.get("releaseEligible") is False, "runtime-release-eligibility")

        sbom = load_json(release / "SBOM.cdx.json")
        metadata = sbom.get("metadata") or {}
        component = metadata.get("component") or {}
        properties = {
            str(item.get("name") or ""): str(item.get("value") or "")
            for item in metadata.get("properties") or [] if isinstance(item, dict)
        }
        require(component.get("version") == BUILD, "sbom-build")
        require(properties.get("releaseRevision") == REVISION, "sbom-revision")
        require(properties.get("artifactName") == ARTIFACT, "sbom-artifact")
        require(properties.get("artifactRootDirectory") == ARTIFACT_ROOT, "sbom-root")

        toola = (release / "app/toolA.html").read_text(encoding="utf-8")
        require(f'content="{REVISION}"' in toola and f'content="{BUILD}"' in toola, "public-metadata")

        protected = identity.get("protectedBehaviorFiles") or {}
        require(bool(protected), "protected-files-empty")
        for relative, expected in sorted(protected.items()):
            path = release / str(relative)
            require(path.is_file(), f"protected-file-missing:{relative}")
            if path.is_file():
                require(digest(path) == expected, f"protected-file-mismatch:{relative}")
    except Exception as exc:
        failures.append(f"identity-gate-exception:{exc}")
    return failures


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--release", type=Path, required=True)
    args = parser.parse_args()
    failures = audit_release(args.release.resolve())
    if failures:
        for failure in failures:
            print(f"FAIL: {failure}")
        return 1
    print("R9O9 RELEASE IDENTITY GATE: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
