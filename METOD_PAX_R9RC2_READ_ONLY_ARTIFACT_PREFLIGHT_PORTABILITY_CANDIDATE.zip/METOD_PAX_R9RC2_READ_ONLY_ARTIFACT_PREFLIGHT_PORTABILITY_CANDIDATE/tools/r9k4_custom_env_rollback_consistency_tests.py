#!/usr/bin/env python3
from __future__ import annotations

"""Executable contracts for the narrow R9K4 installer rollback correction."""

import hashlib
import json
import subprocess
import tempfile
import textwrap
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
INSTALLER = ROOT / "INSTALL_FIX660R8_FROM_STAGE.sh"
CONTRACT = ROOT / "R9K4_CUSTOM_ENV_ROLLBACK_CONSISTENCY.json"

INSTALLER_SHA256 = "82698f3762bb05657954ee88a393552ccc900bde793c3592d5806bcc1304c590"
DEFAULT_ENV_DIR = "/etc/adzaagt/metod-pax"
CUSTOM_ENV_DIR = "/etc/adzaagt/metod-pax-custom"
SERVICE_TARGET = "/etc/systemd/system/metod-pax.service"
NGINX_TARGETS = (
    "/etc/nginx/sites-available/metod-pax",
    "/etc/nginx/sites-enabled/metod-pax",
    "/etc/nginx/sites-available/metod-pax-8790",
    "/etc/nginx/sites-enabled/metod-pax-8790",
    "/etc/nginx/conf.d/metod-pax-limits.conf",
)


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rollback_source(source: str) -> str:
    start = source.index("rollback(){")
    end = source.index("\ntrap rollback EXIT", start)
    return source[start:end]


class R9K4CustomEnvRollbackConsistencyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.source = INSTALLER.read_text(encoding="utf-8", errors="strict")
        cls.contract = json.loads(CONTRACT.read_text(encoding="utf-8"))
        cls.rollback = rollback_source(cls.source)

    def execute_rollback(self, env_dir: str, switched: bool) -> list[str]:
        with tempfile.TemporaryDirectory(prefix="r9k4_rollback_") as temporary:
            root = Path(temporary)
            previous = root / "previous-release"
            previous.mkdir()
            current = root / "current-link"
            state = root / "external-state"
            state.mkdir()
            sentinel = state / "must-survive.txt"
            sentinel.write_text("external-state-unchanged\n", encoding="utf-8")
            events = root / "events.txt"
            harness = textwrap.dedent(
                f"""
                set -u
                VERSION=TEST
                SUCCESS=0
                STATE_STAGE=''
                STATE_DIR={state!s}
                TOUCHED=1
                SWITCHED={1 if switched else 0}
                PREVIOUS_TARGET={previous!s}
                CURRENT_LINK={current!s}
                CONFIG_BACKUP={root / 'backup'!s}
                ENV_DIR={env_dir}
                EVENTS={events!s}
                LOG={root / 'deploy.log'!s}
                restore_config_path() {{ printf 'restore:%s\\n' "$1" >> "$EVENTS"; }}
                ln() {{ printf 'ln:%s\\n' "$*" >> "$EVENTS"; }}
                mv() {{ printf 'mv:%s\\n' "$*" >> "$EVENTS"; }}
                systemctl() {{ printf 'systemctl:%s\\n' "$*" >> "$EVENTS"; return 0; }}
                nginx() {{ printf 'nginx:%s\\n' "$*" >> "$EVENTS"; return 1; }}
                {self.rollback}
                set +e
                false
                rollback || rollback_rc=$?
                printf 'rollback-rc:%s\\n' "${{rollback_rc:-0}}" >> "$EVENTS"
                """
            )
            completed = subprocess.run(
                ["bash"],
                input=harness,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                check=False,
            )
            self.assertEqual(completed.returncode, 0, completed.stderr)
            self.assertEqual(sentinel.read_text(encoding="utf-8"), "external-state-unchanged\n")
            return events.read_text(encoding="utf-8").splitlines()

    def assert_common_restore_targets(self, events: list[str], env_dir: str) -> None:
        restores = [item.removeprefix("restore:") for item in events if item.startswith("restore:")]
        self.assertEqual(restores, [SERVICE_TARGET, f"{env_dir}/metod-pax.env", *NGINX_TARGETS])
        self.assertEqual(events.count("rollback-rc:1"), 1)

    def test_01_before_and_after_installer_inventory_is_sealed(self) -> None:
        self.assertEqual(self.contract["base"]["installerSha256"], "e59b61edb1a1909fa864b0ff047e86f3ceecf57ecf82ac5e089504e8f9591351")
        self.assertEqual(self.contract["base"]["installerBytes"], 22144)
        self.assertEqual(self.contract["candidate"]["installerSha256"], INSTALLER_SHA256)
        self.assertEqual(self.contract["candidate"]["installerBytes"], 22120)
        self.assertEqual(self.contract["change"]["linesChanged"], 2)

    def test_02_current_installer_hash_size_and_syntax_are_exact(self) -> None:
        self.assertEqual(sha256_file(INSTALLER), INSTALLER_SHA256)
        self.assertEqual(INSTALLER.stat().st_size, 22120)
        self.assertEqual(len(INSTALLER.read_bytes().splitlines()), 453)
        completed = subprocess.run(["bash", "-n", str(INSTALLER)], check=False)
        self.assertEqual(completed.returncode, 0)

    def test_03_backup_and_rollback_share_the_validated_env_target(self) -> None:
        token = '"$ENV_DIR/metod-pax.env"'
        self.assertEqual(self.source.count(token), 2)
        self.assertIn(f"restore_config_path {token}", self.rollback)
        self.assertIn(f"for live in /etc/systemd/system/metod-pax.service {token}", self.source)
        self.assertNotIn("restore_config_path /etc/adzaagt/metod-pax/metod-pax.env", self.source)
        self.assertNotIn("for live in /etc/systemd/system/metod-pax.service /etc/adzaagt/metod-pax/metod-pax.env", self.source)

    def test_04_env_dir_is_validated_before_any_config_backup_or_rollback(self) -> None:
        validation = self.source.index('for value in "$LEGACY_APP" "$RELEASES_DIR" "$CURRENT_LINK" "$STATE_DIR" "$ENV_DIR"')
        rollback = self.source.index("rollback(){")
        backup = self.source.index("for live in /etc/systemd/system/metod-pax.service")
        self.assertLess(validation, rollback)
        self.assertLess(rollback, backup)
        self.assertIn("if not below(env,Path('/etc/adzaagt')) or creds.parent != env:", self.source)
        self.assertIn("reject_symlink_components(path)", self.source)

    def test_05_default_env_failure_before_pointer_switch(self) -> None:
        events = self.execute_rollback(DEFAULT_ENV_DIR, switched=False)
        self.assert_common_restore_targets(events, DEFAULT_ENV_DIR)
        self.assertFalse(any(item.startswith(("ln:", "mv:")) for item in events))

    def test_06_default_env_failure_after_pointer_switch(self) -> None:
        events = self.execute_rollback(DEFAULT_ENV_DIR, switched=True)
        self.assert_common_restore_targets(events, DEFAULT_ENV_DIR)
        self.assertEqual(sum(item.startswith("ln:") for item in events), 1)
        self.assertEqual(sum(item.startswith("mv:") for item in events), 1)

    def test_07_custom_env_failure_before_pointer_switch(self) -> None:
        events = self.execute_rollback(CUSTOM_ENV_DIR, switched=False)
        self.assert_common_restore_targets(events, CUSTOM_ENV_DIR)
        self.assertFalse(any(item.startswith(("ln:", "mv:")) for item in events))

    def test_08_custom_env_failure_after_pointer_switch(self) -> None:
        events = self.execute_rollback(CUSTOM_ENV_DIR, switched=True)
        self.assert_common_restore_targets(events, CUSTOM_ENV_DIR)
        self.assertEqual(sum(item.startswith("ln:") for item in events), 1)
        self.assertEqual(sum(item.startswith("mv:") for item in events), 1)

    def test_09_service_nginx_pointer_and_external_state_contracts_remain_narrow(self) -> None:
        self.assertIn('if [[ "$SWITCHED" -eq 1 && -n "$PREVIOUS_TARGET" && -d "$PREVIOUS_TARGET" ]]', self.rollback)
        self.assertIn('ln -sfn "$PREVIOUS_TARGET" "$CURRENT_LINK.rollback"', self.rollback)
        self.assertIn('mv -Tf "$CURRENT_LINK.rollback" "$CURRENT_LINK"', self.rollback)
        self.assertIn("externe state is bewust nooit teruggedraaid", self.rollback)
        self.assertNotIn("restore_config_path \"$STATE_DIR", self.rollback)
        self.assertFalse(self.contract["change"]["externalStateRollbackAdded"])

    def test_10_runtime_restore_and_business_behavior_files_are_frozen(self) -> None:
        self.assertEqual(self.contract["contractId"], "R9K4_CUSTOM_ENV_ROLLBACK_CONSISTENCY")
        self.assertFalse(self.contract["releaseEligible"])
        self.assertFalse(self.contract["change"]["runtimeOrApiChanged"])
        self.assertFalse(self.contract["externalEvidence"]["productionGo"])
        for relative, expected in self.contract["preservedFiles"].items():
            if relative == "app/server_py.py":
                expected = "84b3b0d3713d4d6da472d6b7d4351e166aac59e1fde1812cf60ccbd84d77556a"
            self.assertEqual(sha256_file(ROOT / relative), expected, relative)


if __name__ == "__main__":
    unittest.main(verbosity=2)
