#!/usr/bin/env python3
from __future__ import annotations

"""Conservatively bound immutable release and deploy-config history.

Only direct child directories with the exact METOD naming contract are ever
eligible.  The active release, the pre-deploy release and the current config
backup are mandatory keeps.  Unknown entries and symlinks are ignored.
"""

import argparse
import json
import os
import re
import shutil
import stat
import time
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Candidate:
    path: Path
    size: int
    mtime_ns: int


def _canonical_root(path: Path) -> Path:
    if not path.is_absolute():
        raise ValueError(f'root must be absolute: {path}')
    if path.is_symlink():
        raise ValueError(f'root may not be a symlink: {path}')
    resolved = path.resolve(strict=True)
    if not resolved.is_dir():
        raise ValueError(f'root is not a directory: {resolved}')
    return resolved


def _tree_size(path: Path) -> int:
    total = 0
    stack = [path]
    while stack:
        directory = stack.pop()
        with os.scandir(directory) as entries:
            for entry in entries:
                details = entry.stat(follow_symlinks=False)
                mode = details.st_mode
                if stat.S_ISDIR(mode) and not stat.S_ISLNK(mode):
                    stack.append(Path(entry.path))
                elif stat.S_ISREG(mode) or stat.S_ISLNK(mode):
                    total += max(0, int(details.st_size))
                else:
                    raise ValueError(f'special file in managed history: {entry.path}')
    return total


def _collect(root: Path, pattern: re.Pattern[str]) -> list[Candidate]:
    found: list[Candidate] = []
    with os.scandir(root) as entries:
        for entry in entries:
            if not pattern.fullmatch(entry.name) or entry.is_symlink():
                continue
            if not entry.is_dir(follow_symlinks=False):
                continue
            path = root / entry.name
            details = entry.stat(follow_symlinks=False)
            found.append(Candidate(path=path, size=_tree_size(path), mtime_ns=details.st_mtime_ns))
    return sorted(found, key=lambda item: (item.mtime_ns, item.path.name), reverse=True)


def _resolved_if_present(path: Path | None) -> Path | None:
    if path is None:
        return None
    try:
        return path.resolve(strict=True)
    except (FileNotFoundError, OSError):
        return None


def _fsync_directory(path: Path) -> None:
    descriptor = os.open(str(path), os.O_RDONLY | getattr(os, 'O_DIRECTORY', 0))
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def prune_history(
    *,
    root: Path,
    pattern: re.Pattern[str],
    protected: set[Path],
    keep_count: int,
    max_age_days: int,
    max_bytes: int,
    now_ns: int | None = None,
    dry_run: bool = False,
    current_link: Path | None = None,
) -> dict[str, object]:
    root = _canonical_root(root)
    if keep_count < 1 or max_age_days < 1 or max_bytes < 1:
        raise ValueError('history limits must be positive')
    candidates = _collect(root, pattern)
    recognized = {item.path.resolve(strict=True): item for item in candidates}
    mandatory = {path for path in protected if path in recognized}
    keep: set[Path] = set(mandatory)
    threshold_ns = int(now_ns if now_ns is not None else time.time_ns()) - max_age_days * 86_400 * 1_000_000_000

    for item in candidates:
        resolved = item.path.resolve(strict=True)
        if resolved in keep or item.mtime_ns < threshold_ns or len(keep) >= keep_count:
            continue
        keep.add(resolved)

    def kept_bytes() -> int:
        return sum(recognized[path].size for path in keep)

    optional_oldest = sorted(
        (recognized[path] for path in keep if path not in mandatory),
        key=lambda item: (item.mtime_ns, item.path.name),
    )
    while kept_bytes() > max_bytes and optional_oldest:
        remove = optional_oldest.pop(0)
        keep.discard(remove.path.resolve(strict=True))

    deletions = [item for item in candidates if item.path.resolve(strict=True) not in keep]
    deleted: list[str] = []
    reclaimed = 0
    for item in deletions:
        # Re-check the direct-child and exact-name invariants at mutation time.
        if item.path.parent != root or not pattern.fullmatch(item.path.name) or item.path.is_symlink():
            raise RuntimeError(f'unsafe history deletion target: {item.path}')
        resolved = item.path.resolve(strict=True)
        # The installer owns a global deploy lock, but the pruner is also safe
        # when invoked directly: never delete the release named by the live
        # current pointer at the actual mutation boundary.
        live_current = _resolved_if_present(current_link)
        if live_current is not None and live_current == resolved:
            keep.add(resolved)
            continue
        if not dry_run:
            shutil.rmtree(item.path)
        deleted.append(item.path.name)
        reclaimed += item.size
    if deleted and not dry_run:
        _fsync_directory(root)

    kept_names = [recognized[path].path.name for path in keep]
    kept_names.sort()
    return {
        'root': str(root),
        'recognized': len(candidates),
        'kept': kept_names,
        'deleted': deleted,
        'reclaimedBytes': reclaimed,
        'remainingBytes': kept_bytes(),
        'mandatoryBytesOverLimit': kept_bytes() > max_bytes,
        'dryRun': dry_run,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--releases-dir', type=Path, required=True)
    parser.add_argument('--backup-root', type=Path, required=True)
    parser.add_argument('--current-link', type=Path, required=True)
    parser.add_argument('--previous-target', type=Path)
    parser.add_argument('--current-config-backup', type=Path, required=True)
    parser.add_argument('--version', default='FIX660R8_PRELIVE_HARDENED')
    parser.add_argument('--release-keep', type=int, default=3)
    parser.add_argument('--release-max-age-days', type=int, default=180)
    parser.add_argument('--release-max-bytes', type=int, default=2 * 1024 * 1024 * 1024)
    parser.add_argument('--config-keep', type=int, default=10)
    parser.add_argument('--config-max-age-days', type=int, default=180)
    parser.add_argument('--config-max-bytes', type=int, default=512 * 1024 * 1024)
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args()

    if not re.fullmatch(r'[A-Z0-9_]{8,80}', args.version):
        raise SystemExit('invalid version prefix')
    release_pattern = re.compile(re.escape(args.version) + r'_[a-f0-9]{12}')
    config_pattern = re.compile(re.escape(args.version) + r'_config_[0-9]{8}_[0-9]{6}')
    current = _resolved_if_present(args.current_link)
    previous = _resolved_if_present(args.previous_target)
    current_config = _resolved_if_present(args.current_config_backup)

    report = {
        'schemaVersion': 1,
        'releases': prune_history(
            root=args.releases_dir,
            pattern=release_pattern,
            protected={path for path in (current, previous) if path is not None},
            keep_count=args.release_keep,
            max_age_days=args.release_max_age_days,
            max_bytes=args.release_max_bytes,
            dry_run=args.dry_run,
            current_link=args.current_link,
        ),
        'configBackups': prune_history(
            root=args.backup_root,
            pattern=config_pattern,
            protected={path for path in (current_config,) if path is not None},
            keep_count=args.config_keep,
            max_age_days=args.config_max_age_days,
            max_bytes=args.config_max_bytes,
            dry_run=args.dry_run,
        ),
    }
    print(json.dumps(report, sort_keys=True, separators=(',', ':')))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
