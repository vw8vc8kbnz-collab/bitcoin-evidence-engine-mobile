#!/usr/bin/env python3
from __future__ import annotations

"""Fail-closed gate for canonical R9L2 release identity and provenance roles."""

import argparse
import hashlib
import json
import math
import os
import re
import tempfile
from pathlib import Path
from typing import Any


DEFAULT_RELEASE = Path(__file__).resolve().parents[1]
IDENTITY_FILE = "RELEASE_IDENTITY.json"
REVISION = "R9L2"
BUILD = "R9L2_OBSERVABILITY_METRICS_EXTRACTION"
ARTIFACT = "METOD_PAX_R9L2_OBSERVABILITY_METRICS_EXTRACTION_CANDIDATE.zip"
ARTIFACT_ROOT = "METOD_PAX_R9L2_OBSERVABILITY_METRICS_EXTRACTION_CANDIDATE"
STATUS = "PROVISIONAL_DEVELOPMENT_ONLY"
CHANNEL = "AUDIT_CANDIDATE"
COMPONENT_REVISION = "R9I_SYNC_CATALOG_REFRESH_CLEANUP_9"
COMPATIBILITY_BUILD = "FIX660R8_PRELIVE_HARDENED"
GOLDEN_REVISION = "R8Z"
GOLDEN_SHA256 = "d3e8656d8d7d5a581a8186ef8fe2c91c19b2137a8654b2f2874497dd85255e62"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def strict_json(path: Path) -> Any:
    value = json.loads(
        path.read_text(encoding="utf-8", errors="strict"),
        parse_constant=lambda token: (_ for _ in ()).throw(ValueError(f"non-finite JSON: {token}")),
    )
    stack = [value]
    while stack:
        item = stack.pop()
        if isinstance(item, float) and not math.isfinite(item):
            raise ValueError("non-finite JSON number")
        if isinstance(item, dict):
            stack.extend(item.values())
        elif isinstance(item, list):
            stack.extend(item)
    return value


def sbom_properties(sbom: dict[str, Any]) -> dict[str, str]:
    return {
        str(item.get("name") or ""): str(item.get("value") or "")
        for item in (((sbom.get("metadata") or {}).get("properties")) or [])
        if isinstance(item, dict)
    }


def audit_release(release: Path) -> dict[str, Any]:
    release = release.resolve(strict=True)
    failures: list[dict[str, Any]] = []

    def require(condition: bool, rule_id: str, **details: Any) -> None:
        if not condition:
            failures.append({"ruleId": rule_id, **details})

    identity = strict_json(release / IDENTITY_FILE)
    require(isinstance(identity, dict), "identity-not-object")
    canonical = identity.get("canonicalCandidate") if isinstance(identity, dict) else None
    application = identity.get("application") if isinstance(identity, dict) else None
    golden = identity.get("immutableGoldenBaseline") if isinstance(identity, dict) else None
    compatibility = identity.get("compatibilitySurface") if isinstance(identity, dict) else None
    external = identity.get("externalEvidence") if isinstance(identity, dict) else None
    require(identity.get("contractId") == "R9L2_RELEASE_IDENTITY", "identity-contract-id")
    require(identity.get("schemaVersion") == 1, "identity-schema")
    require(isinstance(canonical, dict), "canonical-candidate-missing")
    require(isinstance(application, dict), "application-identity-missing")
    require(isinstance(golden, dict), "golden-identity-missing")
    require(isinstance(compatibility, dict), "compatibility-identity-missing")
    require(isinstance(external, dict), "external-evidence-boundary-missing")
    if not all(isinstance(value, dict) for value in (canonical, application, golden, compatibility, external)):
        return {"schemaVersion": 1, "gateId": "R9L2_RELEASE_IDENTITY_GATE", "status": "FAIL", "failures": failures}

    expected_candidate = {
        "releaseRevision": REVISION,
        "buildId": BUILD,
        "releaseChannel": CHANNEL,
        "status": STATUS,
        "releaseEligible": False,
        "artifactName": ARTIFACT,
        "artifactRootDirectory": ARTIFACT_ROOT,
    }
    for key, expected in expected_candidate.items():
        require(canonical.get(key) == expected, "canonical-candidate-field", field=key, expected=expected, actual=canonical.get(key))

    require(application.get("componentRevision") == COMPONENT_REVISION, "application-component-revision")
    require(application.get("runtimeCompatibilityBuild") == COMPATIBILITY_BUILD, "runtime-compatibility-build")
    require(
        application.get("publicServerBuildFieldMeaning") == "runtime-compatibility-build-not-release-revision",
        "public-server-build-semantics",
    )
    require(golden.get("role") == "behavior-oracle-only", "golden-role")
    require(golden.get("releaseRevision") == GOLDEN_REVISION, "golden-revision")
    require(golden.get("artifactSha256") == GOLDEN_SHA256, "golden-artifact-sha256")
    require(golden.get("mutationPolicy") == "immutable-golden-oracle", "golden-mutation-policy")
    require(external.get("productionGo") is False, "production-go-must-be-false")
    for gate in ("browser", "vps", "independentSecurityAudit"):
        require(external.get(gate) == "DEFERRED_NO_GO", "external-gate-not-no-go", gate=gate)

    runtime = strict_json(release / "RUNTIME_CONTRACT.json")
    runtime_expected = {
        "releaseIdentityContract": IDENTITY_FILE,
        "build": BUILD,
        "releaseRevision": REVISION,
        "artifactName": ARTIFACT,
        "artifactRootDirectory": ARTIFACT_ROOT,
        "releaseChannel": CHANNEL,
        "releaseStatus": STATUS,
        "releaseEligible": False,
        "applicationComponentRevision": COMPONENT_REVISION,
        "runtimeCompatibilityBuild": COMPATIBILITY_BUILD,
        "immutableGoldenBaselineRevision": GOLDEN_REVISION,
    }
    for key, expected in runtime_expected.items():
        require(runtime.get(key) == expected, "runtime-identity-mismatch", field=key, expected=expected, actual=runtime.get(key))

    sbom = strict_json(release / "SBOM.cdx.json")
    properties = sbom_properties(sbom)
    component = ((sbom.get("metadata") or {}).get("component") or {}) if isinstance(sbom, dict) else {}
    require(sbom.get("bomFormat") == "CycloneDX" and sbom.get("specVersion") == "1.5", "sbom-format")
    require(component.get("version") == BUILD, "sbom-component-build")
    property_expected = {
        "releaseRevision": REVISION,
        "artifactName": ARTIFACT,
        "artifactRootDirectory": ARTIFACT_ROOT,
        "releaseChannel": CHANNEL,
        "releaseStatus": STATUS,
        "releaseEligible": "false",
        "applicationComponentRevision": COMPONENT_REVISION,
        "runtimeCompatibilityBuild": COMPATIBILITY_BUILD,
        "immutableGoldenBaselineRevision": GOLDEN_REVISION,
    }
    for key, expected in property_expected.items():
        require(properties.get(key) == expected, "sbom-identity-mismatch", field=key, expected=expected, actual=properties.get(key))

    html = (release / "app/toolA.html").read_text(encoding="utf-8", errors="strict")
    public_markers = (
        f'<meta name="metod-release-revision" content="{REVISION}" />',
        f'<meta name="metod-release-build" content="{BUILD}" />',
        f'<meta name="metod-release-channel" content="{CHANNEL}" />',
        f'<meta name="metod-release-status" content="{STATUS}" />',
        f'<meta name="metod-application-revision" content="{COMPONENT_REVISION}" />',
        f'<meta name="metod-runtime-compatibility-build" content="{COMPATIBILITY_BUILD}" />',
        f'<meta name="metod-golden-baseline" content="{GOLDEN_REVISION}" />',
        f'<!-- {BUILD} -->',
    )
    for marker in public_markers:
        require(html.count(marker) == 1, "public-identity-marker", marker=marker, count=html.count(marker))
    require('name="metod-release-revision" content="R8Z"' not in html, "golden-misrepresented-as-current-release")

    deploy = (release / "DEPLOY_FIX660.sh").read_text(encoding="utf-8", errors="strict")
    require(f"grep -Fq '{BUILD}'" in deploy, "deploy-current-marker-missing")
    require("FIX660R8Z_PRODUCTION_HARDENING_AUDIT" not in deploy, "deploy-legacy-release-marker-active")

    builder = (release / "tools/build_release_artifact.py").read_text(encoding="utf-8", errors="strict")
    for token in ("RELEASE_IDENTITY.json", "artifactName", "artifactRootDirectory", "artifact name must be canonical", "root_name"):
        require(token in builder, "builder-identity-control-missing", token=token)

    workflow = (release / ".github/workflows/release-gate.yml").read_text(encoding="utf-8", errors="strict")
    for token in ("tools/r9l2_release_identity_gate.py", ARTIFACT):
        require(token in workflow, "workflow-identity-control-missing", token=token)

    historical = compatibility.get("historicalDocumentation")
    deploy_scripts = compatibility.get("deploymentScripts")
    require(isinstance(historical, list) and len(historical) == 7, "historical-document-inventory")
    require(isinstance(deploy_scripts, list) and len(deploy_scripts) == 2, "compatibility-script-inventory")
    for relative in list(historical or []) + list(deploy_scripts or []):
        require((release / str(relative)).is_file(), "declared-compatibility-file-missing", path=relative)

    protected_results: dict[str, str] = {}
    protected = identity.get("protectedBehaviorFiles")
    require(isinstance(protected, dict) and len(protected) == 11, "protected-behavior-inventory")
    for relative, expected in (protected or {}).items():
        path = release / str(relative)
        actual = sha256_file(path) if path.is_file() else "MISSING"
        protected_results[str(relative)] = actual
        require(actual == expected, "protected-behavior-drift", path=relative, expected=expected, actual=actual)

    report = {
        "schemaVersion": 1,
        "gateId": "R9L2_RELEASE_IDENTITY_GATE",
        "status": "PASS" if not failures else "FAIL",
        "release": str(release),
        "releaseRevision": canonical.get("releaseRevision"),
        "buildId": canonical.get("buildId"),
        "artifactName": canonical.get("artifactName"),
        "artifactRootDirectory": canonical.get("artifactRootDirectory"),
        "releaseStatus": canonical.get("status"),
        "releaseEligible": canonical.get("releaseEligible"),
        "applicationComponentRevision": application.get("componentRevision"),
        "runtimeCompatibilityBuild": application.get("runtimeCompatibilityBuild"),
        "goldenBaselineRevision": golden.get("releaseRevision"),
        "goldenBaselineArtifactSha256": golden.get("artifactSha256"),
        "protectedBehaviorSha256": protected_results,
        "externalEvidence": external,
        "failures": failures,
    }
    return report


def write_json_atomic(path: Path, value: dict[str, Any]) -> None:
    path = path.expanduser().absolute()
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=path.parent, delete=False) as handle:
        json.dump(value, handle, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
        temporary = Path(handle.name)
    os.replace(temporary, path)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--release", type=Path, default=DEFAULT_RELEASE)
    parser.add_argument("--json-output", type=Path)
    args = parser.parse_args()
    report = audit_release(args.release)
    if args.json_output:
        write_json_atomic(args.json_output, report)
    print(json.dumps(report, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False))
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
