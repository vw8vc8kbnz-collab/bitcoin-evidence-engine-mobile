#!/usr/bin/env python3
from __future__ import annotations

"""Focused ownership and transition tests for the extracted public FIFO."""

import ast
import hashlib
import sys
import threading
import unittest
from pathlib import Path


RELEASE = Path(__file__).resolve().parents[1]
APP = RELEASE / "app"
sys.path.insert(0, str(APP))

from metod_app.jobs.admission import PublicJobAdmission  # noqa: E402
from metod_app.jobs.scheduler import PublicJobScheduler  # noqa: E402


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


class SchedulerHarness:
    def __init__(self, maximum: int = 1) -> None:
        self.maximum = maximum
        self.admission = PublicJobAdmission(lock=threading.Lock())
        self.scheduler = PublicJobScheduler(
            admission=self.admission,
            max_active=lambda: self.maximum,
        )
        self.refreshes: list[tuple[list[str], list[str], bool]] = []

    def refresh(self, starting: list[dict], queued: list[dict]) -> None:
        self.refreshes.append((
            [str(item["jobId"]) for item in starting],
            [str(item["jobId"]) for item in queued],
            self.scheduler.lock.locked(),
        ))

    def reserve(self, ip: str) -> None:
        accepted, reason = self.admission.try_acquire(
            ip,
            env_int=lambda name, default: {
                "PUBLIC_JOB_MAX_CONCURRENT": self.maximum,
                "PUBLIC_JOB_MAX_QUEUED": 8,
                "PUBLIC_JOB_MAX_CONCURRENT_PER_IP": 8,
            }.get(name, default),
        )
        if not accepted:
            raise AssertionError(reason)

    def commit(self, ip: str, job_id: str, runner=None):
        self.reserve(ip)
        return self.scheduler.commit(
            ip=ip, job_id=job_id, runner=runner, refresh_meta=self.refresh,
            state_changed=lambda: None,
        )


class R9ESchedulerBehaviorTests(unittest.TestCase):
    def test_01_first_job_starts_with_exact_result_and_identity(self) -> None:
        harness = SchedulerHarness()
        runner = object()
        result, starting = harness.commit("198.51.100.1", "A", runner)
        self.assertEqual(result, {"status": "processing", "queuePosition": 0})
        self.assertEqual(starting, [{"ip": "198.51.100.1", "jobId": "A", "runner": runner}])
        self.assertIs(harness.scheduler.active_by_id["A"], starting[0])

    def test_02_waiting_jobs_receive_strict_fifo_positions(self) -> None:
        harness = SchedulerHarness()
        harness.commit("198.51.100.1", "A")
        second, _ = harness.commit("198.51.100.2", "B")
        third, _ = harness.commit("198.51.100.3", "C")
        self.assertEqual(second, {"status": "queued", "queuePosition": 1})
        self.assertEqual(third, {"status": "queued", "queuePosition": 2})
        self.assertEqual([item["jobId"] for item in harness.scheduler.queue], ["B", "C"])

    def test_03_finish_promotes_only_fifo_head(self) -> None:
        harness = SchedulerHarness()
        harness.commit("198.51.100.1", "A")
        harness.commit("198.51.100.2", "B")
        harness.commit("198.51.100.3", "C")
        released, starting = harness.scheduler.finish(
            job_id="A", refresh_meta=harness.refresh, state_changed=lambda: None,
        )
        self.assertTrue(released)
        self.assertEqual([item["jobId"] for item in starting], ["B"])
        self.assertEqual(list(harness.scheduler.active_by_id), ["B"])
        self.assertEqual([item["jobId"] for item in harness.scheduler.queue], ["C"])

    def test_04_two_workers_promote_in_fifo_order(self) -> None:
        harness = SchedulerHarness(maximum=2)
        first = harness.commit("198.51.100.1", "A")[1]
        second = harness.commit("198.51.100.2", "B")[1]
        harness.commit("198.51.100.3", "C")
        harness.commit("198.51.100.4", "D")
        promoted = harness.scheduler.finish(
            job_id="A", refresh_meta=harness.refresh, state_changed=lambda: None,
        )[1]
        self.assertEqual([item["jobId"] for item in first + second + promoted], ["A", "B", "C"])
        self.assertEqual([item["jobId"] for item in harness.scheduler.queue], ["D"])

    def test_05_active_release_is_exactly_once(self) -> None:
        harness = SchedulerHarness()
        harness.commit("198.51.100.1", "A")
        self.assertTrue(harness.scheduler.finish(
            job_id="A", refresh_meta=harness.refresh, state_changed=lambda: None,
        )[0])
        self.assertFalse(harness.scheduler.finish(
            job_id="A", refresh_meta=harness.refresh, state_changed=lambda: None,
        )[0])
        self.assertEqual(harness.scheduler.active_total, 0)
        self.assertEqual(harness.admission.total, 0)

    def test_06_queued_cancel_compacts_positions_without_promotion(self) -> None:
        harness = SchedulerHarness()
        harness.commit("198.51.100.1", "A")
        harness.commit("198.51.100.2", "B")
        harness.commit("198.51.100.3", "C")
        self.assertTrue(harness.scheduler.cancel_queued(
            job_id="B", refresh_meta=harness.refresh, state_changed=lambda: None,
        ))
        self.assertEqual(harness.refreshes[-1][:2], ([], ["C"]))
        self.assertEqual(list(harness.scheduler.active_by_id), ["A"])
        self.assertEqual(harness.admission.total, 2)

    def test_07_missing_queued_cancel_is_side_effect_free(self) -> None:
        harness = SchedulerHarness()
        harness.commit("198.51.100.1", "A")
        refresh_count = len(harness.refreshes)
        self.assertFalse(harness.scheduler.cancel_queued(
            job_id="missing", refresh_meta=harness.refresh, state_changed=lambda: None,
        ))
        self.assertEqual(len(harness.refreshes), refresh_count)
        self.assertEqual(harness.admission.total, 1)

    def test_08_missing_admission_reservation_fails_before_enqueue(self) -> None:
        harness = SchedulerHarness()
        with self.assertRaisesRegex(RuntimeError, "admission reservation is missing"):
            harness.scheduler.commit(
                ip="198.51.100.1", job_id="A", runner=None,
                refresh_meta=harness.refresh, state_changed=lambda: None,
            )
        self.assertEqual(list(harness.scheduler.queue), [])
        self.assertEqual(harness.scheduler.active_by_id, {})

    def test_09_metadata_refresh_runs_under_scheduler_lock(self) -> None:
        harness = SchedulerHarness()
        harness.commit("198.51.100.1", "A")
        harness.commit("198.51.100.2", "B")
        harness.scheduler.finish(
            job_id="A", refresh_meta=harness.refresh, state_changed=lambda: None,
        )
        self.assertTrue(all(locked for _starting, _queued, locked in harness.refreshes))

    def test_10_scheduler_never_invokes_runner(self) -> None:
        harness = SchedulerHarness()
        calls: list[str] = []
        harness.commit("198.51.100.1", "A", lambda: calls.append("A"))
        harness.commit("198.51.100.2", "B", lambda: calls.append("B"))
        harness.scheduler.finish(
            job_id="A", refresh_meta=harness.refresh, state_changed=lambda: None,
        )
        self.assertEqual(calls, [])


class R9ESchedulerOwnershipTests(unittest.TestCase):
    def test_11_server_composes_single_fifo_and_active_map_owner(self) -> None:
        source = (APP / "server_py.py").read_text(encoding="utf-8")
        self.assertIn("_PUBLIC_JOB_QUEUE = _PUBLIC_JOB_SCHEDULER.queue", source)
        self.assertIn("_PUBLIC_JOB_ACTIVE_BY_ID = _PUBLIC_JOB_SCHEDULER.active_by_id", source)
        self.assertNotIn("_PUBLIC_JOB_QUEUE.append(", source)
        self.assertNotIn("_PUBLIC_JOB_QUEUE.popleft(", source)
        self.assertNotIn("_PUBLIC_JOB_QUEUE.remove(", source)

    def test_12_module_owns_no_http_thread_process_durable_io_or_optimizer(self) -> None:
        path = APP / "metod_app/jobs/scheduler.py"
        source = path.read_text(encoding="utf-8")
        tree = ast.parse(source)
        imports = {
            alias.name.split(".", 1)[0]
            for node in ast.walk(tree) if isinstance(node, ast.Import)
            for alias in node.names
        } | {
            str(node.module or "").split(".", 1)[0]
            for node in ast.walk(tree) if isinstance(node, ast.ImportFrom) and node.level == 0
        }
        self.assertTrue(imports.isdisjoint({"http", "os", "pathlib", "socket", "subprocess", "threading", "time"}))
        for token in ("Popen", "Thread(", "write_text", "write_bytes"):
            self.assertNotIn(token, source)

    def test_13_optimizer_and_tool_a_remain_byte_exact(self) -> None:
        self.assertEqual(
            sha256_file(APP / "dxf_nesting_optimizer.py"),
            "42480b301cd660dac1e5e9fec2c8d30bb5c6826c32234a9c1cce765b758bebb8",
        )
        self.assertEqual(
            sha256_file(APP / "toolA.html"),
            "8dc02939664026c3bffd407b083ad2febdd9d0aa61adf232deaef329b9479a22",
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
