#!/usr/bin/env python3
from __future__ import annotations

"""Deterministic R9L5 Admin-presentation inventory before the R9M split."""

import argparse
import ast
import hashlib
import json
import re
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
ACCESS = ROOT / "app/metod_app/admin/access.py"
SERVER = ROOT / "app/server_py.py"


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_text(value: str) -> str:
    return sha256_bytes(value.encode("utf-8"))


def presentation_values(source: str) -> dict[str, str]:
    result: dict[str, str] = {}
    tree = ast.parse(source)
    for node in tree.body:
        if not isinstance(node, ast.Assign) or len(node.targets) != 1:
            continue
        target = node.targets[0]
        if not isinstance(target, ast.Name) or target.id not in {"ADMIN_HTML", "ADMIN_LOGIN_HTML"}:
            continue
        value = ast.literal_eval(node.value)
        if not isinstance(value, str):
            raise TypeError(f"{target.id} is not a string")
        result[target.id] = value
    if set(result) != {"ADMIN_HTML", "ADMIN_LOGIN_HTML"}:
        raise RuntimeError("Admin presentation constants are incomplete")
    return result


def blocks(html: str, tag: str) -> list[str]:
    return re.findall(rf"<{tag}[^>]*>(.*?)</{tag}>", html, re.IGNORECASE | re.DOTALL)


def ordered_unique(values: list[str]) -> list[str]:
    return list(dict.fromkeys(values))


def html_inventory(html: str) -> dict[str, Any]:
    styles = blocks(html, "style")
    scripts = blocks(html, "script")
    ids = ordered_unique(re.findall(r'\bid=["\']([^"\']+)["\']', html, re.IGNORECASE))
    api_paths = sorted(set(re.findall(r"/api/[A-Za-z0-9_{}?=&./-]+", html)))
    actions = sorted(set(re.findall(r'data-admin-action=["\']([^"\']+)["\']', html)))
    functions: list[str] = []
    for script in scripts:
        functions.extend(
            match.group(1) or match.group(2)
            for match in re.finditer(
                r"(?m)^\s*(?:async\s+)?function\s+([A-Za-z_$][\w$]*)"
                r"|^\s*window\.([A-Za-z_$][\w$]*)\s*=\s*(?:async\s+)?function",
                script,
            )
        )
    return {
        "bytes": len(html.encode("utf-8")),
        "lines": len(html.splitlines()),
        "sha256": sha256_text(html),
        "styleElementCount": len(styles),
        "styleBlocks": [
            {"bytes": len(value.encode("utf-8")), "lines": len(value.splitlines()), "sha256": sha256_text(value)}
            for value in styles
        ],
        "scriptElementCount": len(scripts),
        "scriptBlocks": [
            {"bytes": len(value.encode("utf-8")), "lines": len(value.splitlines()), "sha256": sha256_text(value)}
            for value in scripts
        ],
        "styleAttributeCount": len(re.findall(r"\sstyle\s*=", html, re.IGNORECASE)),
        "inlineEventAttributeCount": len(re.findall(r"\son[a-z]+\s*=", html, re.IGNORECASE)),
        "externalStylesheetCount": len(re.findall(r'<link\b[^>]*rel=["\']stylesheet["\']', html, re.IGNORECASE)),
        "externalScriptCount": len(re.findall(r'<script\b[^>]*\bsrc=', html, re.IGNORECASE)),
        "domIds": ids,
        "domIdsSha256": sha256_text("\n".join(ids)),
        "apiLiteralPaths": api_paths,
        "dataAdminActions": actions,
        "functionNames": ordered_unique(functions),
    }


def inventory() -> dict[str, Any]:
    source = ACCESS.read_text(encoding="utf-8", errors="strict")
    server = SERVER.read_bytes()
    values = presentation_values(source)
    return {
        "schemaVersion": 1,
        "contractId": "R9M_ADMIN_PRESENTATION_BEFORE_FIXTURE",
        "sourceCheckpoint": "R9L5",
        "sourceTag": "r9l5-remaining-job-lifecycle-facades-extraction-checkpoint",
        "sourceCommit": "9d3fedcb5cdc1a7ed4428fe67734780c9082f678",
        "accessOwner": {
            "bytes": len(source.encode("utf-8")),
            "lines": len(source.splitlines()),
            "sha256": sha256_text(source),
        },
        "server": {
            "bytes": len(server),
            "lines": len(server.splitlines()),
            "sha256": sha256_bytes(server),
        },
        "presentations": {name: html_inventory(value) for name, value in values.items()},
        "serverBindings": {
            "importsAdminHtml": source.count("ADMIN_HTML =") == 1,
            "importsAdminLoginHtml": source.count("ADMIN_LOGIN_HTML =") == 1,
            "authenticatedMainProjection": "return self._send_text(ADMIN_HTML, 200, 'text/html; charset=utf-8')" in SERVER.read_text(encoding="utf-8"),
            "anonymousLoginProjection": "return self._send_text(ADMIN_LOGIN_HTML, 200, 'text/html; charset=utf-8')" in SERVER.read_text(encoding="utf-8"),
        },
        "externalEvidence": {
            "browser": "DEFERRED_NO_GO",
            "candidateVps": "DEFERRED_NO_GO",
            "productionGo": False,
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--json-output", type=Path)
    args = parser.parse_args()
    result = inventory()
    encoded = json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2) + "\n"
    if args.json_output:
        args.json_output.write_text(encoded, encoding="utf-8")
    print(encoded, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
