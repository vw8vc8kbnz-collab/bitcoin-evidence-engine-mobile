#!/usr/bin/env python3
from __future__ import annotations

"""AST, source and HTTP-oracle contracts for the R9K2 cleanup."""

import ast
import hashlib
import json
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SERVER = ROOT / "app/server_py.py"
ROUTES = ROOT / "app/metod_app/http/routes.py"
CONTRACT = ROOT / "R9K2_DEAD_ADMIN_MATERIAL_WRITE_CLEANUP.json"
HTTP_FIXTURE = ROOT / "R9K2_ADMIN_410_HTTP_FIXTURE.json"
HTTP_SMOKE = ROOT / "tools/fix660r8_http_smoke_tests.py"

ROUTE_CATALOG_SHA256 = "05907bd65c55d92494df626fc7e0674465d0cae8111a6c8b4543ae62d6a0bfac"
RESPONSE_ERROR = "FIX652: actieve Decor Library wordt uitsluitend via CSV controleren + publiceren beheerd."

HANDLER_TO_ROUTE = {
    "_api_admin_materials_upload": "POST /api/admin/materials/upload",
    "_api_admin_materials_save_item": "POST /api/admin/materials/save_item",
    "_api_admin_materials_delete_item": "POST /api/admin/materials/delete_item",
    "_api_admin_material_image_upload": "POST /api/admin/materials/image_upload",
}

FROZEN_BEHAVIOR_SHA256 = {
    "app/dxf_nesting_optimizer.py": "42480b301cd660dac1e5e9fec2c8d30bb5c6826c32234a9c1cce765b758bebb8",
    "app/dxf_geometry.py": "b80a2d006241908bf7b33516f7e0faf59ef61e1e08db86966b23cc5de292c1ff",
    "app/pricing_helpers.py": "646c2f5186e9b080f6ba8dcf364884411c18e946254bb5c9001647f7cbb425df",
    "app/panel_contract.py": "e23314fd63a2358a48daa580a92cebb8a40c9862548ba0243461a59347da7fc9",
}


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


class R9K2DeadAdminMaterialWriteCleanupTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.source = SERVER.read_text(encoding="utf-8", errors="strict")
        cls.tree = ast.parse(cls.source)
        cls.contract = json.loads(CONTRACT.read_text(encoding="utf-8"))
        cls.http_fixture = json.loads(HTTP_FIXTURE.read_text(encoding="utf-8"))
        cls.functions = {
            node.name: node
            for node in ast.walk(cls.tree)
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        }

    def function_source(self, name: str) -> str:
        segment = ast.get_source_segment(self.source, self.functions[name])
        self.assertIsNotNone(segment)
        return str(segment)

    def test_01_each_target_handler_contains_exactly_one_statement(self) -> None:
        self.assertEqual(set(HANDLER_TO_ROUTE), set(self.contract["cleanup"]["handlers"]))
        for name in HANDLER_TO_ROUTE:
            node = self.functions[name]
            self.assertEqual([arg.arg for arg in node.args.args], ["self"], name)
            self.assertEqual(len(node.body), 1, name)
            self.assertIsInstance(node.body[0], ast.Return, name)

    def test_02_each_only_statement_is_the_exact_preserved_410_response(self) -> None:
        for name in HANDLER_TO_ROUTE:
            returned = self.functions[name].body[0]
            self.assertIsInstance(returned, ast.Return)
            call = returned.value
            self.assertIsInstance(call, ast.Call, name)
            self.assertIsInstance(call.func, ast.Attribute, name)
            self.assertEqual(call.func.attr, "_send_json", name)
            self.assertEqual(ast.literal_eval(call.args[0]), {"ok": False, "error": RESPONSE_ERROR}, name)
            self.assertEqual(ast.literal_eval(call.args[1]), 410, name)
            self.assertEqual(call.keywords, [], name)

    def test_03_after_source_hashes_are_exact(self) -> None:
        handlers = self.contract["cleanup"]["handlers"]
        for name in HANDLER_TO_ROUTE:
            self.assertEqual(
                sha256_bytes(self.function_source(name).encode("utf-8")),
                handlers[name]["afterSourceSha256"],
                name,
            )

    def test_04_before_ast_inventory_and_reduction_are_sealed(self) -> None:
        handlers = self.contract["cleanup"]["handlers"]
        self.assertEqual(sum(item["removedBodyStatements"] for item in handlers.values()), 24)
        self.assertEqual([handlers[name]["beforeBodyStatements"] for name in HANDLER_TO_ROUTE], [21, 3, 2, 2])
        self.assertEqual(self.contract["cleanup"]["serverBytesRemoved"], 15662)
        self.assertEqual(self.contract["cleanup"]["serverLinesRemoved"], 231)

    def test_05_dead_mutation_markers_are_absent(self) -> None:
        for marker in (
            "Legacy/advanced JSON library replacement.",
            "Saved internal articleNo=",
            "Archived articleNo=",
            "Uploaded WebP images for",
            "ADMIN_JSON_DIRECT_SELL_PRICE",
        ):
            self.assertNotIn(marker, self.source)

    def test_06_routes_and_dispatch_bindings_remain_exact(self) -> None:
        self.assertEqual(sha256_bytes(ROUTES.read_bytes()), ROUTE_CATALOG_SHA256)
        dispatcher = self.function_source("_do_POST_impl")
        for handler, route in HANDLER_TO_ROUTE.items():
            self.assertIn(f"route_key == '{route}'", dispatcher)
            self.assertIn(f"return self.{handler}()", dispatcher)
        self.assertEqual(
            sha256_bytes(dispatcher.encode("utf-8")),
            self.contract["preservedOwners"]["postDispatcherSourceSha256"],
        )

    def test_07_active_csv_material_owners_remain_byte_exact(self) -> None:
        for name, expected in self.contract["preservedOwners"]["activeCsvHandlers"].items():
            self.assertEqual(sha256_bytes(self.function_source(name).encode("utf-8")), expected, name)

    def test_08_serializer_and_sibling_delete_owner_remain_byte_exact(self) -> None:
        preserved = self.contract["preservedOwners"]
        self.assertEqual(sha256_bytes(self.function_source("_send_json").encode()), preserved["sendJsonSourceSha256"])
        self.assertEqual(
            sha256_bytes(self.function_source("_api_admin_material_image_delete").encode()),
            preserved["imageDeleteSourceSha256"],
        )

    def test_09_real_http_oracle_is_bound_to_all_four_routes(self) -> None:
        fixture = self.http_fixture
        expected = fixture["expectedResponse"]
        self.assertEqual(expected["status"], 410)
        self.assertEqual(expected["contentLength"], 115)
        self.assertEqual(sha256_bytes(expected["bodyUtf8"].encode()), expected["bodySha256"])
        self.assertEqual(expected["semanticJson"], json.loads(expected["bodyUtf8"]))
        smoke = HTTP_SMOKE.read_text(encoding="utf-8", errors="strict")
        for route in fixture["routes"]:
            self.assertIn(route, smoke)
        for marker in ("R9K2_DEPRECATED_MATERIAL_ROUTES", "R9K2_DEPRECATED_RESPONSE_BODY", "material_state_before"):
            self.assertIn(marker, smoke)

    def test_10_four_frozen_behavior_files_remain_exact_in_descendants(self) -> None:
        for relative, expected in FROZEN_BEHAVIOR_SHA256.items():
            self.assertEqual(sha256_bytes((ROOT / relative).read_bytes()), expected, relative)

    def test_11_scope_is_narrow_provisional_and_future_work_is_deferred(self) -> None:
        self.assertEqual(self.contract["contractId"], "R9K2_DEAD_ADMIN_MATERIAL_WRITE_CLEANUP")
        self.assertEqual(self.contract["status"], "PROVISIONAL_DEVELOPMENT_ONLY")
        self.assertFalse(self.contract["releaseEligible"])
        self.assertFalse(self.contract["cleanup"]["activeRuntimePathChanged"])
        self.assertFalse(self.contract["cleanup"]["externallyObservableBehaviorExpectedChanged"])
        self.assertEqual(len(self.contract["deferredUnchangedScope"]), 5)
        self.assertFalse(self.contract["externalEvidence"]["productionGo"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
