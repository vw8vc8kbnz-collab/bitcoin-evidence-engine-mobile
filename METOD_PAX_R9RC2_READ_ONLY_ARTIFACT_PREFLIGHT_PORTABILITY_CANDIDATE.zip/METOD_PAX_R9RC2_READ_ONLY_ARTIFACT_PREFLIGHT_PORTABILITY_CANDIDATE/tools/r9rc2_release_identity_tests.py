#!/usr/bin/env python3
from __future__ import annotations

import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path


RELEASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RELEASE / "tools"))

from r9rc2_release_identity_gate import (  # noqa: E402
    ARTIFACT,
    ARTIFACT_ROOT,
    BUILD,
    REVISION,
    audit_release,
)


class R9RC2ReleaseIdentityTests(unittest.TestCase):
    def test_01_current_release_identity_passes(self) -> None:
        self.assertEqual(audit_release(RELEASE), [])

    def test_02_expected_identity_is_exact(self) -> None:
        self.assertEqual(REVISION, "R9RC2")
        self.assertEqual(BUILD, "R9RC2_READ_ONLY_ARTIFACT_PREFLIGHT_PORTABILITY")
        self.assertEqual(ARTIFACT, f"METOD_PAX_{BUILD}_CANDIDATE.zip")
        self.assertEqual(ARTIFACT_ROOT, f"METOD_PAX_{BUILD}_CANDIDATE")

    def _mutated_release(self, mutator) -> list[str]:
        with tempfile.TemporaryDirectory(prefix="r9rc1-identity-") as temporary:
            release = Path(temporary) / "release"
            shutil.copytree(RELEASE, release)
            identity_path = release / "RELEASE_IDENTITY.json"
            # Release ZIPs deliberately extract immutable. The negative gate
            # tests mutate only their private temporary copy, so make exactly
            # that copied fixture owner-writable before writing it.
            identity_path.chmod(0o600)
            identity = json.loads(identity_path.read_text(encoding="utf-8"))
            mutator(identity)
            identity_path.write_text(json.dumps(identity), encoding="utf-8")
            return audit_release(release)

    def test_03_gate_fails_closed_on_release_eligibility(self) -> None:
        failures = self._mutated_release(
            lambda identity: identity["canonicalCandidate"].__setitem__("releaseEligible", True)
        )
        self.assertIn("release-must-remain-ineligible", failures)

    def test_04_gate_fails_closed_on_production_go(self) -> None:
        failures = self._mutated_release(
            lambda identity: identity["externalEvidence"].__setitem__("productionGo", True)
        )
        self.assertIn("production-must-remain-no-go", failures)


if __name__ == "__main__":
    unittest.main(verbosity=2)
