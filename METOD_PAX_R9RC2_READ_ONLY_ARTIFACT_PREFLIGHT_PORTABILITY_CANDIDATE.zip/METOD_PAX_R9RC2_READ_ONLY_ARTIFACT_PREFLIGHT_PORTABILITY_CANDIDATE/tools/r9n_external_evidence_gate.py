#!/usr/bin/env python3
from __future__ import annotations

"""Validate an external evidence pack without turning it into production GO.

Missing or incomplete real-world evidence is NO_GO (exit 3). Invalid JSON,
unsafe paths, hash drift and internally contradictory PASS claims are FAIL
(exit 1). A complete pack means only that the reviewed evidence is present,
current and bound to one artifact; a separate human release decision remains
mandatory.
"""

import argparse
import contextlib
import hashlib
import json
import os
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any


EXIT_FAIL = 1
EXIT_NO_GO = 3


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_object(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON root must be an object: {path}")
    return value


def parse_utc(value: Any) -> datetime:
    raw = str(value or "").strip()
    parsed = datetime.fromisoformat(raw.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise ValueError("timestamp must include a timezone")
    return parsed.astimezone(timezone.utc)


def atomic_json(path: Path, value: dict[str, Any]) -> None:
    path = path.resolve()
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=path.parent, delete=False) as handle:
        os.fchmod(handle.fileno(), 0o600)
        json.dump(value, handle, ensure_ascii=False, sort_keys=True, indent=2)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
        temporary = Path(handle.name)
    os.replace(temporary, path)
    path.chmod(0o600)


def safe_attachment(root: Path, relative: Any) -> Path:
    rendered = str(relative or "")
    if not rendered or Path(rendered).is_absolute():
        raise ValueError("attachment path must be non-empty and relative")
    target = (root / rendered).resolve(strict=True)
    if not target.is_relative_to(root) or target.is_symlink() or not target.is_file():
        raise ValueError(f"unsafe attachment path: {rendered}")
    return target


def validate_attachments(root: Path, report: dict[str, Any]) -> list[str]:
    attachments = report.get("attachments")
    if not isinstance(attachments, list) or not attachments:
        raise ValueError("report requires at least one hash-bound attachment")
    seen: set[str] = set()
    paths: list[str] = []
    for item in attachments:
        if not isinstance(item, dict):
            raise ValueError("attachment entry must be an object")
        relative = str(item.get("path") or "")
        if relative in seen:
            raise ValueError(f"duplicate attachment: {relative}")
        seen.add(relative)
        target = safe_attachment(root, relative)
        expected = str(item.get("sha256") or "").lower()
        if len(expected) != 64 or sha256_file(target) != expected:
            raise ValueError(f"attachment hash mismatch: {relative}")
        paths.append(relative)
    return paths


def validate_generic_report(
    root: Path,
    report: dict[str, Any],
    spec: dict[str, Any],
    artifact_sha: str,
    manifest_sha: str,
    now: datetime,
) -> dict[str, Any]:
    report_type = str(spec["reportType"])
    if report.get("schemaVersion") != 1 or report.get("reportType") != report_type:
        raise ValueError(f"{report_type}: schema/reportType mismatch")
    if report.get("subjectArtifactSha256") != artifact_sha or report.get("candidateManifestSha256") != manifest_sha:
        raise ValueError(f"{report_type}: artifact or candidate manifest binding mismatch")
    observed = parse_utc(report.get("observedAtUtc"))
    if observed > now + timedelta(minutes=5):
        raise ValueError(f"{report_type}: observedAtUtc is in the future")
    if observed < now - timedelta(days=int(spec["maxAgeDays"])):
        return {"reportType": report_type, "status": "NO_GO", "reason": "evidence-expired"}
    attestation = report.get("attestation")
    if not isinstance(attestation, dict) or not str(attestation.get("reviewerName") or "").strip() or not str(attestation.get("organization") or "").strip():
        return {"reportType": report_type, "status": "NO_GO", "reason": "named-attestation-missing"}
    if spec.get("independentRequired") is True and attestation.get("independentFromBuilder") is not True:
        return {"reportType": report_type, "status": "NO_GO", "reason": "independence-not-attested"}
    environment = report.get("environment")
    if not isinstance(environment, dict) or not environment:
        return {"reportType": report_type, "status": "NO_GO", "reason": "environment-missing"}
    if spec.get("actualHardwareRequired") is True and environment.get("actualHardware") is not True:
        return {"reportType": report_type, "status": "NO_GO", "reason": "actual-hardware-not-proven"}
    attachments = validate_attachments(root, report)
    checks = report.get("checks")
    if not isinstance(checks, list):
        return {"reportType": report_type, "status": "NO_GO", "reason": "checks-missing"}
    check_index = {item.get("id"): item for item in checks if isinstance(item, dict) and isinstance(item.get("id"), str)}
    required = list(spec["requiredCheckIds"])
    if len(check_index) != len(checks) or set(check_index) != set(required):
        return {"reportType": report_type, "status": "NO_GO", "reason": "required-check-set-incomplete"}
    for check_id in required:
        check = check_index[check_id]
        refs = check.get("evidenceRefs")
        if check.get("status") != "PASS" or not isinstance(refs, list) or not refs or any(ref not in attachments for ref in refs):
            return {"reportType": report_type, "status": "NO_GO", "reason": f"check-not-proven:{check_id}"}
    if report.get("status") != "PASS":
        return {"reportType": report_type, "status": "NO_GO", "reason": "report-not-pass"}
    return {"reportType": report_type, "status": "PASS", "observedAtUtc": observed.isoformat().replace("+00:00", "Z"), "attachmentCount": len(attachments)}


def validate_browser_report(root: Path, wrapper: dict[str, Any], spec: dict[str, Any], artifact_sha: str, manifest_sha: str) -> dict[str, Any]:
    if wrapper.get("schemaVersion") != 1 or wrapper.get("reportType") != "pinned-browser-oracle":
        raise ValueError("browser wrapper schema/reportType mismatch")
    if wrapper.get("subjectArtifactSha256") != artifact_sha or wrapper.get("candidateManifestSha256") != manifest_sha:
        raise ValueError("browser wrapper artifact binding mismatch")
    attachments = validate_attachments(root, wrapper)
    raw_relative = wrapper.get(spec["rawOracleReportPathField"])
    if raw_relative not in attachments:
        raise ValueError("raw browser oracle report is not an attachment")
    raw = read_object(safe_attachment(root, raw_relative))
    fixture_count = int(spec["requiredFixtureCount"])
    required_engines = sorted(spec["requiredEngines"])
    candidate = raw.get("candidateRelease") if isinstance(raw.get("candidateRelease"), dict) else {}
    complete = (
        raw.get("oracleId") == spec["oracleId"]
        and raw.get("status") == "PASS"
        and candidate.get("manifestSha256") == manifest_sha
        and int(raw.get("fixtureCount") if raw.get("fixtureCount") is not None else -1) == fixture_count
        and int(raw.get("passedFixtureCount") if raw.get("passedFixtureCount") is not None else -1) == fixture_count
        and int(raw.get("failedFixtureCount") if raw.get("failedFixtureCount") is not None else -1) == 0
        and int(raw.get("blockedFixtureCount") if raw.get("blockedFixtureCount") is not None else -1) == int(spec["requiredBlockedFixtureCount"])
        and int(raw.get("skippedFixtureCount") if raw.get("skippedFixtureCount") is not None else -1) == int(spec["requiredSkippedFixtureCount"])
        and sorted(raw.get("enginesPassed") or []) == required_engines
        and len(raw.get("fixtureIdsPassed") or []) == fixture_count
    )
    return {"reportType": "pinned-browser-oracle", "status": "PASS" if complete else "NO_GO", "reason": None if complete else "raw-browser-oracle-incomplete", "attachmentCount": len(attachments)}


def evaluate(contract: dict[str, Any], artifact: Path, golden: Path, release: Path, evidence_root: Path, now: datetime | None = None) -> tuple[dict[str, Any], int]:
    artifact = artifact.resolve(strict=True)
    golden = golden.resolve(strict=True)
    release = release.resolve(strict=True)
    evidence_root = evidence_root.resolve(strict=True)
    if artifact.is_symlink() or golden.is_symlink() or not artifact.is_file() or not golden.is_file():
        raise ValueError("artifact inputs must be regular non-symlink files")
    artifact_sha = sha256_file(artifact)
    golden_sha = sha256_file(golden)
    if golden_sha != contract.get("goldenArtifactSha256"):
        raise ValueError("immutable golden artifact hash mismatch")
    manifest = release / "SHA256SUMS.txt"
    if not manifest.is_file() or manifest.is_symlink():
        raise ValueError("candidate SHA256SUMS.txt missing or unsafe")
    manifest_sha = sha256_file(manifest)
    moment = now or datetime.now(timezone.utc)
    results: list[dict[str, Any]] = []
    missing: list[str] = []
    browser_spec = contract["browserOracle"]
    browser_path = evidence_root / browser_spec["report"]
    if not browser_path.is_file():
        missing.append(browser_spec["report"])
    else:
        results.append(validate_browser_report(evidence_root, read_object(browser_path), browser_spec, artifact_sha, manifest_sha))
    for spec in contract["reports"]:
        report_path = evidence_root / spec["filename"]
        if not report_path.is_file():
            missing.append(spec["filename"])
            continue
        results.append(validate_generic_report(evidence_root, read_object(report_path), spec, artifact_sha, manifest_sha, moment))
    complete = not missing and all(item["status"] == "PASS" for item in results)
    status = "EVIDENCE_COMPLETE_PENDING_SEPARATE_PRODUCTION_DECISION" if complete else "NO_GO"
    output = {
        "schemaVersion": 1,
        "gateId": "R9N_EXTERNAL_EVIDENCE_GATE",
        "status": status,
        "subjectArtifact": artifact.name,
        "subjectArtifactSha256": artifact_sha,
        "candidateManifestSha256": manifest_sha,
        "goldenArtifactSha256": golden_sha,
        "missingReports": missing,
        "reportResults": results,
        "productionGo": False,
        "releaseEligible": False,
        "evidenceLimit": "This gate validates completeness, freshness, hashes and declared attestations; it does not authenticate human identity or authorize production."
    }
    return output, 0 if complete else EXIT_NO_GO


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--contract", type=Path, required=True)
    parser.add_argument("--artifact", type=Path, required=True)
    parser.add_argument("--golden-artifact", type=Path, required=True)
    parser.add_argument("--release", type=Path, required=True)
    parser.add_argument("--evidence-dir", type=Path, required=True)
    parser.add_argument("--json-output", type=Path, required=True)
    args = parser.parse_args()
    try:
        output, exit_code = evaluate(read_object(args.contract), args.artifact, args.golden_artifact, args.release, args.evidence_dir)
    except Exception as exc:
        output = {"schemaVersion": 1, "gateId": "R9N_EXTERNAL_EVIDENCE_GATE", "status": "FAIL", "error": str(exc), "productionGo": False, "releaseEligible": False}
        exit_code = EXIT_FAIL
    atomic_json(args.json_output, output)
    print(json.dumps(output, ensure_ascii=False, sort_keys=True, indent=2))
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
