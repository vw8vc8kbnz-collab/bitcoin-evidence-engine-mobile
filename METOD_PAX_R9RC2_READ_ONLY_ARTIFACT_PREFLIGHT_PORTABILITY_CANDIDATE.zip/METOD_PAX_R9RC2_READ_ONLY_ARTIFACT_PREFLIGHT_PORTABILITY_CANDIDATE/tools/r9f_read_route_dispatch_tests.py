#!/usr/bin/env python3
from __future__ import annotations

"""Fail-closed runtime contract for the preserved R9F GET/HEAD adoption."""

import ast
import hashlib
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
SERVER = APP / "server_py.py"
MATCHER = APP / "metod_app/http/matcher.py"
sys.path.insert(0, str(APP))

from metod_app.http.matcher import match_route  # noqa: E402
from metod_app.http.routes import ROUTES  # noqa: E402


SERVER_SHA256 = "84b3b0d3713d4d6da472d6b7d4351e166aac59e1fde1812cf60ccbd84d77556a"
READ_SOURCE_SHA256 = "9dde5456e80d72100199b9bc69c7a7d53ceb54963c1a7ade7cf7eed9e4b8097e"


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def class_method_source(source: str, class_name: str, method_name: str) -> str:
    tree = ast.parse(source)
    for node in tree.body:
        if isinstance(node, ast.ClassDef) and node.name == class_name:
            for item in node.body:
                if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)) and item.name == method_name:
                    segment = ast.get_source_segment(source, item)
                    if segment is None:
                        raise AssertionError(f"missing source segment {class_name}.{method_name}")
                    return segment
    raise AssertionError(f"missing method {class_name}.{method_name}")


class ReadRouteDispatchTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.server = SERVER.read_text(encoding="utf-8")
        cls.head = class_method_source(cls.server, "Handler", "do_HEAD")
        cls.get = class_method_source(cls.server, "Handler", "do_GET")

    def test_01_runtime_imports_exactly_one_pure_matcher(self) -> None:
        marker = "from metod_app.http.matcher import match_route as _match_http_route"
        self.assertEqual(self.server.count(marker), 1)
        self.assertEqual(self.head.count("_match_http_route('HEAD', self.path)"), 1)
        self.assertEqual(self.get.count("_match_http_route('GET', self.path)"), 1)

    def test_02_read_dispatch_source_remains_exact(self) -> None:
        combined = (self.head + "\n" + self.get).encode()
        self.assertEqual(hashlib.sha256(combined).hexdigest(), READ_SOURCE_SHA256)

    def test_03_head_application_decisions_use_route_keys(self) -> None:
        self.assertIn("route_key in ('HEAD /admin', 'HEAD /admin/', 'HEAD /admin/index.html')", self.head)
        self.assertIn("route_key == 'HEAD /api/admin/'", self.head)
        self.assertNotIn("parsed.path in", self.head)
        self.assertNotIn("parsed.path.startswith", self.head)

    def test_04_get_application_decisions_use_route_keys(self) -> None:
        self.assertGreaterEqual(self.get.count("route_key == 'GET "), 25)
        self.assertGreaterEqual(self.get.count("route_key in ('GET "), 2)
        self.assertNotIn("parsed.path ==", self.get)
        self.assertNotIn("parsed.path in", self.get)

    def test_05_admin_auth_policy_remains_before_admin_handlers(self) -> None:
        auth = "if parsed.path.startswith('/api/admin/'):\n            if not self._require_admin_auth():"
        self.assertIn(auth, self.get)
        self.assertLess(self.get.index(auth), self.get.index("route_key == 'GET /api/admin/health/ready'"))
        self.assertEqual(self.get.count("parsed.path.startswith('/api/admin/')"), 1)

    def test_06_malformed_material_images_keep_the_explicit_404(self) -> None:
        dynamic = "route_key == 'GET /api/materials/image/{publicId}/{variant}'"
        malformed = "if parsed.path.startswith('/api/materials/image/'):\n            return self._send_text('Not found', 404)"
        self.assertIn(dynamic, self.get)
        self.assertIn(malformed, self.get)
        self.assertLess(self.get.index(dynamic), self.get.index(malformed))
        self.assertIsNone(match_route("GET", "/api/materials/image/a/b/c"))

    def test_07_dynamic_handlers_receive_matcher_parameters(self) -> None:
        for name in ("publicId", "variant", "jobId", "filename", "subjobId", "relativePath"):
            self.assertIn(f"route_match.parameter('{name}')", self.get)
        self.assertNotIn("parts = parsed.path.split", self.get)

    def test_08_framework_static_fallback_and_unknown_routes_are_preserved(self) -> None:
        self.assertTrue(self.head.rstrip().endswith("return super().do_HEAD()"))
        self.assertTrue(self.get.rstrip().endswith("return super().do_GET()"))
        self.assertEqual(match_route("GET", "/assets/logo.png").key, "GET /{allowlistedStaticAsset}")
        self.assertIsNone(match_route("GET", "/api/not-reviewed"))

    def test_09_get_and_head_remain_single_matcher_adoptions(self) -> None:
        methods = {route.method for route in ROUTES}
        self.assertEqual(methods, {"GET", "HEAD", "OPTIONS", "POST"})
        self.assertIn("_match_http_route('GET', self.path)", self.get)
        self.assertIn("_match_http_route('HEAD', self.path)", self.head)
        self.assertEqual(self.server.count("_match_http_route('GET', self.path)"), 1)
        self.assertEqual(self.server.count("_match_http_route('HEAD', self.path)"), 1)

    def test_10_server_and_matcher_are_exactly_bound(self) -> None:
        self.assertEqual(digest(SERVER), SERVER_SHA256)
        matcher_source = MATCHER.read_text(encoding="utf-8")
        self.assertNotIn("Handler(", matcher_source)
        self.assertNotIn("getattr(", matcher_source)
        self.assertNotIn("import_module(", matcher_source)


if __name__ == "__main__":
    unittest.main(verbosity=2)
