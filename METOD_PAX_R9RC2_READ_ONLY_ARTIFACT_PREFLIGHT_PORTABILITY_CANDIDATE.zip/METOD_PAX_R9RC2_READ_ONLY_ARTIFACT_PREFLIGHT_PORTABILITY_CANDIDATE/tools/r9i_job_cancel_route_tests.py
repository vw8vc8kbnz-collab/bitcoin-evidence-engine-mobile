#!/usr/bin/env python3
from __future__ import annotations

"""Fail-closed equivalence proof for the R9I-4 job-cancel route owner."""

import base64
import hashlib
import json
import re
import shutil
import subprocess
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
JOBS = APP / "tool-a/api/jobs.js"
REQUESTS = APP / "tool-a/api/requests.js"
BOOTSTRAP = APP / "tool-a/bootstrap.js"
RUNTIME = APP / "tool-a/shell/script-06-legacy-application-runtime.js"
RULES = ROOT / "R9B_ARCHITECTURE_RULES.json"


def data_url(data: bytes) -> str:
    return "data:text/javascript;base64," + base64.b64encode(data).decode()


def run_node(source: str) -> dict:
    node = shutil.which("node")
    if not node:
        raise AssertionError("Node is required by the R9I route gate")
    completed = subprocess.run(
        [node, "--input-type=module"],
        input=source,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=10,
        check=False,
    )
    if completed.returncode != 0:
        raise AssertionError(completed.stdout)
    return json.loads(completed.stdout.strip().splitlines()[-1])


class R9IJobCancelRouteTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.jobs_url = data_url(JOBS.read_bytes())

    def test_01_cancel_preserves_route_bearer_payload_and_response(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(self.jobs_url)});const calls=[];
const response={{ok:false,status:409}};
const api=m.createJobsApi({{fetchImpl:async(url,options)=>{{calls.push({{url,options}});return response;}}}});
const returned=await api.cancelJob({{jobId:'JOB-9',accessToken:'secret-token',reason:'customer_cancelled'}});
console.log(JSON.stringify({{calls,same:returned===response,frozen:Object.isFrozen(api)}}));
""")
        self.assertEqual(result["calls"], [{
            "url": "/api/jobs/cancel",
            "options": {
                "method": "POST",
                "headers": {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer secret-token",
                },
                "body": '{"jobId":"JOB-9","reason":"customer_cancelled"}',
            },
        }])
        self.assertTrue(result["same"])
        self.assertTrue(result["frozen"])

    def test_02_missing_job_remains_a_network_noop(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(self.jobs_url)});let calls=0;
const api=m.createJobsApi({{fetchImpl:async()=>{{calls+=1;throw new Error('must not run');}}}});
const missing=await api.cancelJob();const empty=await api.cancelJob({{jobId:''}});
console.log(JSON.stringify({{calls,missing,empty}}));
""")
        self.assertEqual(result, {"calls": 0, "missing": None, "empty": None})

    def test_03_missing_token_keeps_content_type_and_default_reason(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(self.jobs_url)});const calls=[];
const api=m.createJobsApi({{fetchImpl:async(url,options)=>{{calls.push({{url,options}});return {{ok:true,status:200}};}}}});
await api.cancelJob({{jobId:17}});console.log(JSON.stringify(calls[0]));
""")
        self.assertEqual(result["url"], "/api/jobs/cancel")
        self.assertEqual(result["options"]["headers"], {"Content-Type": "application/json"})
        self.assertEqual(result["options"]["body"], '{"jobId":17,"reason":"customer_cancelled"}')

    def test_04_legacy_consumer_is_thin_and_has_no_direct_cancel_fetch(self) -> None:
        source = RUNTIME.read_text(encoding="utf-8")
        match = re.search(
            r"^  async function _markJobCancelled\([^\n]*\)\{(?P<body>.*?)^  \}",
            source,
            re.MULTILINE | re.DOTALL,
        )
        self.assertIsNotNone(match)
        body = match.group("body")
        self.assertIn("owner.cancelJob({jobId, accessToken:token, reason:'customer_cancelled'})", body)
        self.assertIn("state.lastJobAccessToken || window.__metod_last_job_access_token", body)
        for forbidden in ("fetch(", "'/api/jobs/cancel'", "buildJobTokenHeaders(", "JSON.stringify("):
            self.assertNotIn(forbidden, body)
        self.assertEqual(source.count("await _markJobCancelled(jobId)"), 1)
        self.assertEqual(source.count("await _markRequestCancelled(requestId, cancelToken)"), 1)

    def test_05_jobs_owner_and_bootstrap_publish_exactly_one_cancel_surface(self) -> None:
        jobs = JOBS.read_text(encoding="utf-8")
        bootstrap = BOOTSTRAP.read_text(encoding="utf-8")
        self.assertEqual(jobs.count('fetchImpl("/api/jobs/cancel",'), 1)
        self.assertEqual(jobs.count("async function cancelJob("), 1)
        self.assertEqual(bootstrap.count("cancelJob: (options) => jobsApi.cancelJob(options)"), 1)
        self.assertIn('"R9I_SYNC_CATALOG_REFRESH_CLEANUP_9"', bootstrap)
        self.assertEqual(bootstrap.count("Object.defineProperty(globalThis"), 1)

    def test_06_network_owner_inventory_stays_two_and_request_api_is_untouched(self) -> None:
        rules = json.loads(RULES.read_text(encoding="utf-8"))["frontend"]
        self.assertEqual(rules["networkOwnerModules"], [
            "app/tool-a/api/jobs.js", "app/tool-a/api/requests.js",
        ])
        self.assertEqual(
            hashlib.sha256(REQUESTS.read_bytes()).hexdigest(),
            "4760bfd9733c8739ca96a15cdb3c8f3ef65028b3e95d61c061721cbe125c445e",
        )
        self.assertNotIn("/api/jobs/cancel", REQUESTS.read_text(encoding="utf-8"))

    def test_07_backend_and_protected_functional_owners_are_byte_exact(self) -> None:
        expected = {
            "server_py.py": "84b3b0d3713d4d6da472d6b7d4351e166aac59e1fde1812cf60ccbd84d77556a",
            "dxf_nesting_optimizer.py": "42480b301cd660dac1e5e9fec2c8d30bb5c6826c32234a9c1cce765b758bebb8",
            "dxf_geometry.py": "b80a2d006241908bf7b33516f7e0faf59ef61e1e08db86966b23cc5de292c1ff",
            "pricing_helpers.py": "646c2f5186e9b080f6ba8dcf364884411c18e946254bb5c9001647f7cbb425df",
            "panel_contract.py": "e23314fd63a2358a48daa580a92cebb8a40c9862548ba0243461a59347da7fc9",
        }
        for name, expected_hash in expected.items():
            self.assertEqual(hashlib.sha256((APP / name).read_bytes()).hexdigest(), expected_hash, name)


if __name__ == "__main__":
    unittest.main(verbosity=2)
