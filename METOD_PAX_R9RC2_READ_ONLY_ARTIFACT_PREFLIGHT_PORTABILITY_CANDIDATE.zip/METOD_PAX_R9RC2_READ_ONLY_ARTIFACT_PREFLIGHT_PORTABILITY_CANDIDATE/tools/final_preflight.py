#!/usr/bin/env python3
from __future__ import annotations

"""Outcome-based release and runtime preflight for the METOD/PAX audit candidate.

The source preflight executes the real safety, lifecycle and regression suites in
isolated processes. ``--runtime`` additionally validates the external state and
the deployed staging/production profile. It never creates a real customer job;
the lifecycle job always lives in an automatically removed temporary directory.
"""

import argparse
import ast
import base64
import hashlib
import json
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import urlparse


BUILD = "R9RC2_READ_ONLY_ARTIFACT_PREFLIGHT_PORTABILITY"
RELEASE_REVISION = "R9RC2"
ARTIFACT_NAME = "METOD_PAX_R9RC2_READ_ONLY_ARTIFACT_PREFLIGHT_PORTABILITY_CANDIDATE.zip"
ARTIFACT_ROOT = "METOD_PAX_R9RC2_READ_ONLY_ARTIFACT_PREFLIGHT_PORTABILITY_CANDIDATE"
COMPATIBILITY_BUILD = "FIX660R8_PRELIVE_HARDENED"
EXPECTED_SEED_SOURCE = "CSV_CATALOG_ONLY"
MAX_PUBLIC_JSON = 16 * 1024 * 1024
MAX_SUBMIT_JSON = 8 * 1024 * 1024
MAX_DXF_BLOB = 2 * 1024 * 1024


class Preflight:
    def __init__(self) -> None:
        self.failures: list[str] = []
        self.warnings: list[str] = []

    def ok(self, message: str) -> None:
        print(f"OK:   {message}")

    def fail(self, message: str) -> None:
        self.failures.append(message)
        print(f"FAIL: {message}")

    def warn(self, message: str) -> None:
        self.warnings.append(message)
        print(f"WARN: {message}")

    def require(self, condition: bool, message: str) -> bool:
        if condition:
            self.ok(message)
            return True
        self.fail(message)
        return False


def strict_json(path: Path):
    def reject_constant(value: str):
        raise ValueError(f"non-finite JSON constant {value}")

    value = json.loads(path.read_text(encoding="utf-8", errors="strict"), parse_constant=reject_constant)

    def walk(item):
        if isinstance(item, float) and not math.isfinite(item):
            raise ValueError("non-finite JSON number")
        if isinstance(item, dict):
            for key, child in item.items():
                if not isinstance(key, str):
                    raise ValueError("JSON object key is not text")
                walk(child)
        elif isinstance(item, list):
            for child in item:
                walk(child)

    walk(value)
    return value


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_env(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.is_file():
        return values
    for line in path.read_text(encoding="utf-8", errors="strict").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            continue
        key, value = stripped.split("=", 1)
        values[key.strip()] = value.strip().strip('"').strip("'")
    return values


def truthy(value: str | None) -> bool:
    return str(value or "").strip().lower() in {"1", "true", "yes", "on"}


def exact_origin(value: str, *, scheme: str | None = None) -> bool:
    try:
        parsed = urlparse(str(value or "").strip())
        return bool(
            parsed.hostname
            and not parsed.username
            and not parsed.password
            and not parsed.query
            and not parsed.fragment
            and parsed.path in {"", "/"}
            and "*" not in str(value)
            and (scheme is None or parsed.scheme.lower() == scheme)
        )
    except Exception:
        return False


def run_check(checks: Preflight, label: str, command: list[str], *, cwd: Path, env: dict[str, str]) -> None:
    result = subprocess.run(
        command,
        cwd=str(cwd),
        env=env,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=180,
        check=False,
    )
    if result.returncode == 0:
        checks.ok(label)
        summary = [line for line in result.stdout.splitlines() if line.strip()][-3:]
        for line in summary:
            print(f"      {line[:500]}")
        return
    checks.fail(f"{label} (exit {result.returncode})")
    for line in result.stdout.splitlines()[-80:]:
        print(f"      {line[:1000]}")


def validate_checksum_manifest(checks: Preflight, release: Path, *, verify: bool) -> None:
    manifest = release / "SHA256SUMS.txt"
    if not checks.require(manifest.is_file(), "SHA256SUMS.txt aanwezig"):
        return
    listed: dict[str, str] = {}
    try:
        for number, line in enumerate(manifest.read_text(encoding="utf-8", errors="strict").splitlines(), 1):
            if not line.strip():
                continue
            match = re.fullmatch(r"([a-f0-9]{64})  \./([^\r\n]+)", line)
            if not match:
                raise ValueError(f"ongeldige regel {number}")
            relative = match.group(2)
            if relative.startswith("/") or ".." in Path(relative).parts or relative in listed:
                raise ValueError(f"onveilig/dubbel pad op regel {number}")
            listed[relative] = match.group(1)
    except Exception as exc:
        checks.fail(f"checksummanifest ongeldig: {exc}")
        return

    excluded_names = {"SHA256SUMS.txt"}
    actual = {
        path.relative_to(release).as_posix()
        for path in release.rglob("*")
        if path.is_file()
        and path.name not in excluded_names
        and "__pycache__" not in path.parts
        and path.suffix.lower() not in {".pyc", ".bak"}
    }
    checks.require(set(listed) == actual, "checksummanifest dekt exact alle releasebestanden")
    if not verify:
        checks.warn("checksumbytes niet opnieuw berekend (gebruik --verify-checksums voor artifactgate)")
        return
    mismatches = [relative for relative, expected in sorted(listed.items()) if sha256_file(release / relative) != expected]
    checks.require(not mismatches, "alle interne releasechecksums kloppen")
    if mismatches:
        for relative in mismatches[:20]:
            print(f"      mismatch: {relative}")


def _release_file_map(release: Path) -> dict[str, str]:
    """Hash every release file except the mutable checksum manifest."""

    return {
        path.relative_to(release).as_posix(): sha256_file(path)
        for path in sorted(release.rglob("*"))
        if path.is_file()
        and path.name != "SHA256SUMS.txt"
        and "__pycache__" not in path.parts
        and path.suffix.lower() not in {".pyc", ".bak"}
    }


def _validate_python_sources(checks: Preflight, release: Path) -> None:
    failures: list[str] = []
    for path in sorted(release.rglob("*.py")):
        if "__pycache__" in path.parts:
            continue
        try:
            source = path.read_text(encoding="utf-8", errors="strict")
            compile(source, str(path), "exec", dont_inherit=True)
        except Exception as exc:
            failures.append(f"{path.relative_to(release)}: {exc}")
    checks.require(not failures, "alle Python-bronnen compileren in-memory")
    for failure in failures[:20]:
        print(f"      {failure}")


def _validate_javascript_sources(
    checks: Preflight,
    release: Path,
    *,
    env: dict[str, str],
) -> None:
    node = shutil.which("node")
    if not checks.require(bool(node), "Node.js is beschikbaar voor JavaScript-syntaxcontrole"):
        return
    failures: list[str] = []
    for path in sorted((release / "app").rglob("*.js")):
        result = subprocess.run(
            [str(node), "--check", str(path)],
            cwd=str(release),
            env=env,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=30,
            check=False,
        )
        if result.returncode:
            failures.append(
                f"{path.relative_to(release)}: "
                + " | ".join(result.stdout.splitlines()[-4:])
            )
    checks.require(not failures, "alle JavaScript-bronnen en gegenereerde bundle parsen")
    for failure in failures[:20]:
        print(f"      {failure[:1000]}")


def _validate_shell_sources(
    checks: Preflight,
    release: Path,
    *,
    env: dict[str, str],
) -> None:
    bash = shutil.which("bash")
    if not checks.require(bool(bash), "Bash is beschikbaar voor deploy-syntaxcontrole"):
        return
    failures: list[str] = []
    for path in sorted(release.rglob("*.sh")):
        result = subprocess.run(
            [str(bash), "-n", str(path)],
            cwd=str(release),
            env=env,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=30,
            check=False,
        )
        if result.returncode:
            failures.append(f"{path.relative_to(release)}: {result.stdout.strip()}")
    checks.require(not failures, "alle shell/deployscripts parsen met bash -n")
    for failure in failures[:20]:
        print(f"      {failure[:1000]}")


def _load_active_commands(checks: Preflight, release: Path) -> list[tuple[str, list[str]]]:
    matrix_path = release / "R9RC2_ACTIVE_TEST_MATRIX.json"
    try:
        matrix = strict_json(matrix_path)
        if not isinstance(matrix, dict):
            raise ValueError("matrix root is not an object")
        if matrix.get("matrixId") != "R9RC2_ACTIVE_OUTCOME_TEST_MATRIX":
            raise ValueError("unexpected matrix id")
        if matrix.get("buildId") != BUILD or matrix.get("status") != "CURRENT":
            raise ValueError("matrix identity/status mismatch")
        evidence = matrix.get("externalEvidence")
        if not isinstance(evidence, dict):
            raise ValueError("external-evidence state missing")
        if evidence.get("productionGo") is not False or evidence.get("releaseEligible") is not False:
            raise ValueError("matrix must remain NO_GO")
        rows = matrix.get("suites")
        gates = matrix.get("directGates")
        if not isinstance(rows, list) or not rows or not isinstance(gates, list) or not gates:
            raise ValueError("active suites/direct gates missing")

        commands: list[tuple[str, list[str]]] = []
        seen_ids: set[str] = set()
        seen_paths: set[str] = set()
        for row in [*rows, *gates]:
            if not isinstance(row, dict):
                raise ValueError("matrix row is not an object")
            identifier = str(row.get("id") or "")
            relative = str(row.get("path") or "")
            target = Path(relative)
            if (
                not re.fullmatch(r"[a-z0-9][a-z0-9-]*", identifier)
                or identifier in seen_ids
                or target.is_absolute()
                or ".." in target.parts
                or target.suffix != ".py"
                or not relative.startswith("tools/")
                or not (release / target).is_file()
            ):
                raise ValueError(f"unsafe/duplicate matrix row: {identifier or relative}")
            seen_ids.add(identifier)
            if relative in seen_paths:
                raise ValueError(f"duplicate matrix path: {relative}")
            seen_paths.add(relative)
            arguments = row.get("arguments") or []
            if not isinstance(arguments, list) or any(
                not isinstance(value, str) or "\x00" in value for value in arguments
            ):
                raise ValueError(f"invalid arguments: {identifier}")
            commands.append(
                (
                    f"{identifier} [{row.get('category') or 'direct-gate'}]",
                    [sys.executable, "-B", relative, *arguments],
                )
            )
        checks.ok(
            f"actuele R9RC2-testmatrix is veilig, uniek en compleet "
            f"({len(rows)} suites + {len(gates)} directe gates)"
        )
        return commands
    except Exception as exc:
        checks.fail(f"actuele R9RC2-testmatrix ongeldig: {exc}")
        return []


def validate_release_tree(checks: Preflight, release: Path, *, verify_checksums: bool) -> None:
    required = (
        "INSTALL_FIX660R8_FROM_STAGE.sh",
        "DEPLOY_FIX660.sh",
        "RELEASE_IDENTITY.json",
        "RUNTIME_CONTRACT.json",
        "SBOM.cdx.json",
        "R9J2_SOURCE_SBOM.cdx.json",
        "R9J2_SECURITY_SUPPLY_CHAIN_POLICY.json",
        "R9RC2_ACTIVE_TEST_MATRIX.json",
        "R9RC1_PROFESSIONAL_ARCHITECTURE_RULES.json",
        "R9RC1_PROFESSIONAL_ARCHITECTURE_COMPLETION_CHECKPOINT.md",
        "R9RC1_PROFESSIONAL_ARCHITECTURE_COMPLETION.json",
        "R9RC1_EXTERNAL_AUDIT_REPORT.md",
        "R9RC2_READ_ONLY_ARTIFACT_PREFLIGHT_PORTABILITY_CHECKPOINT.md",
        "R9RC2_READ_ONLY_ARTIFACT_PREFLIGHT_PORTABILITY.json",
        "LICENSE_POLICY.md",
        "requirements.txt",
        "app/server_py.py",
        "app/metod_app/runtime/application.py",
        "app/metod_app/runtime/composition.py",
        "app/metod_app/http/handler.py",
        "app/toolA.html",
        "app/tool-a/styles/tool-a.bundle.css",
        "app/tool-a/runtime/classic-runtime.bundle.js",
        "app/tool-a/runtime/bundle-manifest.json",
        "app/tool-a/runtime/legacy-source/parts.json",
        "tools/r9rc1_build_toola_assets.py",
        "tools/r9rc1_architecture_tests.py",
        "tools/r9rc1_security_privacy_tests.py",
        "tools/r9rc2_release_identity_gate.py",
        "tools/r9rc2_release_identity_tests.py",
        "tools/r9j2_supply_chain_gate.py",
        "tools/build_release_artifact.py",
        "tools/verify_standalone_artifact.py",
    )
    missing = [relative for relative in required if not (release / relative).is_file()]
    checks.require(not missing, "alle actuele architectuur-, security- en release-evidence is aanwezig")
    for relative in missing:
        print(f"      ontbreekt: {relative}")

    unsafe: list[str] = []
    for path in sorted(release.rglob("*")):
        relative = path.relative_to(release).as_posix()
        if path.is_symlink():
            unsafe.append(f"symlink:{relative}")
        elif path.is_file() and (
            "__pycache__" in path.parts
            or path.suffix.lower() in {".pyc", ".bak"}
            or path.name in {".DS_Store", "Thumbs.db"}
        ):
            unsafe.append(f"build-residu:{relative}")
    checks.require(not unsafe, "releaseboom bevat geen links, bytecode, backups of OS-residu")
    for item in unsafe[:20]:
        print(f"      {item}")

    invalid_json: list[str] = []
    for path in sorted(release.rglob("*.json")):
        try:
            strict_json(path)
        except Exception as exc:
            invalid_json.append(f"{path.relative_to(release)}: {exc}")
    checks.require(not invalid_json, "alle JSON-evidence is strict en finite")
    for item in invalid_json[:20]:
        print(f"      {item}")

    test_env = dict(os.environ)
    test_env["PYTHONDONTWRITEBYTECODE"] = "1"
    with tempfile.TemporaryDirectory(prefix="r9rc2-preflight-state-") as temporary:
        test_env["METOD_STATE_ROOT"] = str(Path(temporary) / "isolated-state")
        _validate_python_sources(checks, release)
        _validate_javascript_sources(checks, release, env=test_env)
        _validate_shell_sources(checks, release, env=test_env)
        run_check(
            checks,
            "Tool A CSS/JavaScript-bundles zijn deterministisch reproduceerbaar",
            [sys.executable, "-B", "tools/r9rc1_build_toola_assets.py", "--check"],
            cwd=release,
            env=test_env,
        )

        before = _release_file_map(release)
        for label, command in _load_active_commands(checks, release):
            run_check(checks, label, command, cwd=release, env=test_env)
        after = _release_file_map(release)
        checks.require(before == after, "actuele gates wijzigen geen releasebronbestanden")

    validate_checksum_manifest(checks, release, verify=verify_checksums)
    checks.warn(
        "Interne bron-/artifactgate PASS is geen productie-GO: exact R9RC2 moet "
        "nog extern in Chromium, WebKit, op VPS en op echte iPhone Safari worden bewezen."
    )


def active_catalog_records(library: object) -> list[dict]:
    records = library.get("records") if isinstance(library, dict) else None
    if not isinstance(records, list):
        raise ValueError("material_library.json mist records[]")
    active = []
    for record in records:
        if not isinstance(record, dict):
            continue
        if (
            str(record.get("sourceKind") or "").upper() == "CATALOG_IMPORT"
            and record.get("active") is not False
            and record.get("archived") is not True
            and record.get("published") is True
            and record.get("catalogMissing") is not True
            and record.get("catalogExcluded") is not True
        ):
            active.append(record)
    return active


def validate_admin_credentials(checks: Preflight, path: Path, *, production: bool) -> None:
    try:
        credentials = strict_json(path)
        mode = path.stat().st_mode & 0o777
        checks.require(mode in {0o400, 0o600}, "Admin credentials mode is 0400/0600")
        if not production:
            users = credentials.get("users") if isinstance(credentials, dict) else None
            valid = bool(users) and all(
                isinstance(user, dict)
                and (
                    user.get("active") is False
                    or bool(re.fullmatch(
                        r"pbkdf2_sha256\$600000\$[A-Za-z0-9._-]{16,128}\$[a-f0-9]{64}",
                        str(user.get("password_hash") or ""),
                    ))
                )
                and not str(user.get("password") or "").strip()
                for user in users
            )
            checks.require(valid, "staging Admin credentials gebruiken individuele 600000-hash users[]")
            return
        users = credentials.get("users") if isinstance(credentials, dict) else None
        if not isinstance(users, list) or not users:
            raise ValueError("production vereist users[]")
        seen: set[str] = set()
        active_count = 0
        for user in users:
            if not isinstance(user, dict) or user.get("active") is False:
                continue
            active_count += 1
            username = str(user.get("username") or "")
            if not re.fullmatch(r"[A-Za-z0-9_.@-]{3,80}", username) or username in seen:
                raise ValueError("ongeldige/dubbele individuele Admin username")
            seen.add(username)
            password_hash = str(user.get("password_hash") or "")
            if not re.fullmatch(r"pbkdf2_sha256\$600000\$[A-Za-z0-9._-]{16,128}\$[a-f0-9]{64}", password_hash):
                raise ValueError(f"{username}: PBKDF2-hash moet exact het 600000-iteratiecontract volgen")
            if str(user.get("password") or "").strip():
                raise ValueError(f"{username}: plaintext password verboden")
            secret = re.sub(r"\s+", "", str(user.get("totp_secret") or "")).upper()
            if not re.fullmatch(r"[A-Z2-7]{16,128}", secret):
                raise ValueError(f"{username}: ongeldig TOTP-secretcontract")
            if len(base64.b32decode(secret + "=" * ((8 - len(secret) % 8) % 8), casefold=True)) < 10:
                raise ValueError(f"{username}: TOTP-secret is te kort")
            if "admin" not in set(user.get("roles") or []):
                raise ValueError(f"{username}: adminrol ontbreekt")
        checks.require(active_count > 0, "production gebruikt individuele Admins met MFA en adminrol")
    except Exception as exc:
        checks.fail(f"Admin credentials ongeldig: {exc}")


def validate_runtime(checks: Preflight, release: Path, env_path: Path, state_override: str | None) -> None:
    env = read_env(env_path)
    checks.require(env_path.is_file(), f"runtime env aanwezig: {env_path}")
    mode = str(env.get("APP_ENV") or "").strip().lower()
    production = mode in {"prod", "production"}
    staging = mode == "staging"
    checks.require(production or staging, "APP_ENV is staging of production")
    legacy_admin_env = [
        name for name in ("ADMIN_USER", "ADMIN_PASS", "ADMIN_PASS_HASH", "ADMIN_TOTP_SECRET")
        if str(env.get(name) or "").strip()
    ]
    checks.require(not legacy_admin_env, "legacy Admin environment credentials ontbreken")

    state_root = Path(state_override or env.get("METOD_STATE_ROOT") or "").expanduser()
    try:
        state_resolved = state_root.resolve(strict=True)
        release_resolved = release.resolve(strict=True)
        outside = state_resolved != release_resolved and release_resolved not in state_resolved.parents
        checks.require(outside, "mutable state staat buiten immutable release")
    except Exception as exc:
        checks.fail(f"state root ongeldig: {exc}")
        return

    origin = str(env.get("METOD_PUBLIC_BASE_URL") or "").strip()
    if production:
        checks.require(exact_origin(origin, scheme="https"), "production public base URL is exact HTTPS")
        checks.require(truthy(env.get("PRODUCTION_HARDENING")), "PRODUCTION_HARDENING=1")
        checks.require(truthy(env.get("ADMIN_HASH_ONLY")), "ADMIN_HASH_ONLY=1")
        checks.require(not truthy(env.get("ADMIN_STAGING_OPEN")), "ADMIN_STAGING_OPEN=0")
        checks.require(not truthy(env.get("LEGACY_HTTP_COMPAT")) and not env.get("LEGACY_HTTP_ORIGIN"), "legacy HTTP is uit")
    else:
        checks.require(exact_origin(origin, scheme="http"), "staging public base URL is exact HTTP en expliciet niet live")

    for name in ("ALLOWED_ORIGINS", "ALLOWED_ADMIN_ORIGINS"):
        origins = [item.strip() for item in str(env.get(name) or "").split(",") if item.strip()]
        scheme = "https" if production else "http"
        checks.require(bool(origins) and all(exact_origin(item, scheme=scheme) for item in origins), f"{name} bevat alleen exacte {scheme.upper()} origins")

    limits = {
        "PUBLIC_JSON_MAX_BYTES": MAX_PUBLIC_JSON,
        "SUBMIT_MAX_BYTES": MAX_SUBMIT_JSON,
        "PUBLIC_DXF_BLOB_MAX_BYTES": MAX_DXF_BLOB,
    }
    for name, maximum in limits.items():
        try:
            value = int(env.get(name) or 0)
        except Exception:
            value = 0
        checks.require(0 < value <= maximum, f"{name} valt binnen hard maximum")
    try:
        dxf_count = int(env.get("PUBLIC_DXF_MAX_COUNT") or 0)
    except Exception:
        dxf_count = 0
    checks.require(0 < dxf_count <= 500, "PUBLIC_DXF_MAX_COUNT valt binnen hard maximum")
    try:
        optimizer_workers = int(env.get("PUBLIC_JOB_MAX_CONCURRENT") or 0)
    except Exception:
        optimizer_workers = 0
    checks.require(1 <= optimizer_workers <= 8, "PUBLIC_JOB_MAX_CONCURRENT valt binnen 1..8")
    queue_contract = {
        "PUBLIC_JOB_MAX_QUEUED": "8",
        "PUBLIC_JOB_MAX_CONCURRENT_PER_IP": "2",
    }
    for name, expected in queue_contract.items():
        checks.require(str(env.get(name) or "") == expected, f"{name}={expected} op huidige kleine-serverbaseline")
    try:
        optimizer_timeout = int(env.get("OPTIMIZER_TIMEOUT_SECONDS") or 0)
        optimizer_job_timeout = int(env.get("OPTIMIZER_JOB_TIMEOUT_SECONDS") or 0)
    except Exception:
        optimizer_timeout = optimizer_job_timeout = 0
    checks.require(30 <= optimizer_timeout <= 3600, "OPTIMIZER_TIMEOUT_SECONDS valt binnen 30..3600")
    checks.require(
        optimizer_timeout <= optimizer_job_timeout <= 86400,
        "OPTIMIZER_JOB_TIMEOUT_SECONDS begrenst de volledige jobfamilie",
    )
    bounded_state_contract = {
        "RETENTION_ACTIVE_DAYS": "90",
        "RETENTION_OPEN_REQUEST_MAX_DAYS": "365",
        "RETENTION_ARCHIVE_DAYS": "90",
        "ORPHAN_JOB_RETENTION_DAYS": "7",
        "CATALOG_STAGE_RETENTION_DAYS": "7",
        "CATALOG_HISTORY_KEEP": "12",
        "CATALOG_HISTORY_RETENTION_DAYS": "180",
        "ORPHAN_DECOR_MEDIA_RETENTION_DAYS": "30",
        "ORPHAN_QUEUE_RETENTION_DAYS": "30",
        "ORPHAN_SUBMISSION_CLAIM_RETENTION_DAYS": "1",
        "ORPHAN_DRAFT_RETENTION_DAYS": "30",
        "ROTATED_LOG_RETENTION_DAYS": "30",
        "REQUEST_INDEX_MAX_ACTIVE_ROWS": "250000",
        "AUTO_BACKUP_KEEP": "8",
        "MANUAL_BACKUP_KEEP": "12",
        "AUTO_BACKUP_MAX_AGE_DAYS": "70",
        "MANUAL_BACKUP_MAX_AGE_DAYS": "120",
        "BACKUP_TEMP_RETENTION_HOURS": "24",
        "BACKUP_TOTAL_MAX_BYTES": "21474836480",
        "BACKUP_MAX_SOURCE_BYTES": "17179869184",
        "BACKUP_MAX_FILES": "200000",
        "BACKUP_DRAIN_TIMEOUT_SEC": "60",
        "RETENTION_DRAIN_TIMEOUT_SEC": "60",
        "RESTORE_TEST_MAX_AGE_DAYS": "90",
    }
    for name, expected in bounded_state_contract.items():
        checks.require(str(env.get(name) or "") == expected, f"{name}={expected} volgens begrensd statebeleid")
    try:
        backup_source_cap = int(env.get("BACKUP_MAX_SOURCE_BYTES") or 0)
        backup_total_cap = int(env.get("BACKUP_TOTAL_MAX_BYTES") or 0)
        backup_projection_margin = max(16 * 1024 * 1024, backup_source_cap // 10)
    except Exception:
        backup_source_cap = backup_total_cap = backup_projection_margin = 0
    checks.require(
        backup_source_cap > 0 and backup_total_cap >= backup_source_cap + backup_projection_margin,
        "backup total-bytecap omvat maximale bron plus verificatie/publishmarge",
    )
    checks.require(
        str(env.get("BACKUP_MIN_FREE_BYTES") or "") == str(env.get("MIN_FREE_STATE_BYTES") or ""),
        "backup behoudt dezelfde vrije-byte-reserve als jobadmission",
    )
    checks.require(
        str(env.get("BACKUP_MIN_FREE_INODES") or "") == str(env.get("MIN_FREE_STATE_INODES") or ""),
        "backup behoudt dezelfde vrije-inodereserve als jobadmission",
    )

    library_path = state_resolved / "material_library.json"
    try:
        library = strict_json(library_path)
        active = active_catalog_records(library)
        minimum = max(1, int(env.get("PRODUCTION_MIN_CATALOG_RECORDS") or 1))
        checks.require(len(active) >= minimum, f"actieve gepubliceerde catalogus bevat {len(active)} records (minimum {minimum})")
        for record in active:
            if float(record.get("sellPriceInclVatPerSheet") or 0) <= 0:
                raise ValueError("actief materiaal zonder verkoopprijs incl. btw")
            if float(record.get("thicknessMm") or 0) not in {18.0, 19.0, 20.0}:
                raise ValueError("actief materiaal met verboden dikte")
            if float(record.get("sheetWid") or 0) <= 0 or float(record.get("sheetLen") or 0) <= 0:
                raise ValueError("actief materiaal zonder plaatmaat")
        checks.ok("actieve catalogusrecords hebben prijs/dikte/plaatmaat")
    except Exception as exc:
        checks.fail(f"runtime catalogus ongeldig: {exc}")

    pricing_path = state_resolved / "config/pricing_active.json"
    try:
        pricing = strict_json(pricing_path)
        sell = pricing.get("sellPricing") if isinstance(pricing, dict) else None
        if not isinstance(sell, dict) or "sheetPriceFactor" in sell:
            raise ValueError("ongeldig mixed-VAT pricingmodel")
        for key in ("edgeBandPricePerM", "cncCostPerSheet", "drawingCostFixed", "transportCostFixed"):
            value = float(sell[key])
            if not math.isfinite(value) or value < 0:
                raise ValueError(f"ongeldige {key}")
        checks.ok("runtime pricing is finite, non-negatief en zonder algemene materiaalfactor")
    except Exception as exc:
        checks.fail(f"runtime pricing ongeldig: {exc}")

    credential_value = env.get("ADMIN_CREDENTIALS_FILE") or os.environ.get("ADMIN_CREDENTIALS_FILE")
    credential_path = Path(credential_value or "/etc/adzaagt/metod-pax/admin_credentials.live.json").expanduser()
    validate_admin_credentials(checks, credential_path, production=production)

    probe = state_resolved / f".preflight-write-{os.getpid()}"
    try:
        with probe.open("x", encoding="utf-8") as handle:
            handle.write("ok\n")
            handle.flush()
            os.fsync(handle.fileno())
        checks.ok("service-identiteit kan externe state duurzaam schrijven")
    except Exception as exc:
        checks.fail(f"externe state niet schrijfbaar: {exc}")
    finally:
        probe.unlink(missing_ok=True)

    usage = shutil.disk_usage(state_resolved)
    minimum_free = max(64 * 1024 * 1024, int(env.get("MIN_FREE_STATE_BYTES") or 1024 * 1024 * 1024))
    checks.require(usage.free >= minimum_free, f"vrije state-opslag >= {minimum_free} bytes")
    if hasattr(os, "statvfs"):
        stat = os.statvfs(state_resolved)
        minimum_inodes = max(100, int(env.get("MIN_FREE_STATE_INODES") or 10_000))
        checks.require(stat.f_favail >= minimum_inodes, f"vrije state-inodes >= {minimum_inodes}")

    if production:
        signoff_path = Path(env.get("CATALOG_SIGNOFF_FILE") or state_resolved / "system/catalog_signoff.json")
        try:
            signoff = strict_json(signoff_path)
            valid = bool(
                isinstance(signoff, dict)
                and signoff.get("approved") is True
                and str(signoff.get("approvedBy") or "").strip()
                and str(signoff.get("approvedAt") or "").strip()
                and str(signoff.get("materialLibrarySha256") or "") == sha256_file(library_path)
            )
            checks.require(valid, "business-signoff is hashgebonden aan actieve catalogus")
        except Exception as exc:
            checks.fail(f"catalogussignoff ongeldig: {exc}")

        checks.require(truthy(env.get("OFFSITE_BACKUP_VERIFIED")), "encrypted off-host backup is expliciet geverifieerd")
        checks.require(bool(str(env.get("OFFSITE_BACKUP_PROVIDER") or "").strip()), "off-host backupprovider is vastgelegd")
        proof_path = Path(env.get("RESTORE_TEST_PROOF_FILE") or state_resolved / "system/restore_test_proof.json")
        try:
            proof = strict_json(proof_path)
            verified_at = datetime.fromisoformat(str(proof.get("verifiedAt") or "").replace("Z", "+00:00"))
            if verified_at.tzinfo is None:
                verified_at = verified_at.replace(tzinfo=timezone.utc)
            age = datetime.now(timezone.utc) - verified_at.astimezone(timezone.utc)
            max_age = max(1, int(env.get("RESTORE_TEST_MAX_AGE_DAYS") or 90))
            valid = bool(
                proof.get("ok") is True
                and timedelta(0) <= age <= timedelta(days=max_age)
                and re.fullmatch(r"[a-f0-9]{64}", str(proof.get("backupSha256") or ""))
            )
            checks.require(valid, "recente volledige restoreproef heeft geldig bewijs")
        except Exception as exc:
            checks.fail(f"restore-testbewijs ongeldig: {exc}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--release", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--verify-checksums", action="store_true")
    parser.add_argument("--runtime", action="store_true")
    parser.add_argument("--env-file", type=Path, default=Path("/etc/adzaagt/metod-pax/metod-pax.env"))
    parser.add_argument("--state-root")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    checks = Preflight()
    try:
        release = args.release.expanduser().resolve(strict=True)
    except Exception as exc:
        checks.fail(f"releasepad ongeldig: {exc}")
        release = args.release
    print(f"METOD/PAX {BUILD} preflight")
    print(f"Release: {release}")
    validate_release_tree(checks, release, verify_checksums=args.verify_checksums)
    if args.runtime:
        print("\nRuntimeprofiel")
        validate_runtime(checks, release, args.env_file.expanduser(), args.state_root)

    print("\nRESULTAAT:", "PASS" if not checks.failures else f"FAIL ({len(checks.failures)} fout(en))")
    if checks.failures:
        print("FOUTSAMENVATTING:")
        for index, failure in enumerate(checks.failures, 1):
            print(f"  {index}. {failure}")
    if checks.warnings:
        print(f"WAARSCHUWINGEN: {len(checks.warnings)}")
        for index, warning in enumerate(checks.warnings, 1):
            print(f"  {index}. {warning}")
    return 0 if not checks.failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
