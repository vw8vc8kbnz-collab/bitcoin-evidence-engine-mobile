#!/usr/bin/env python3
from __future__ import annotations

"""Behavior and ownership proof for the R9C pure-header extraction."""

import ast
import importlib
import os
import sys
import tempfile
import unittest
from pathlib import Path


RELEASE = Path(__file__).resolve().parents[1]
APP = RELEASE / "app"
SERVER = APP / "server_py.py"
sys.path.insert(0, str(APP))

from metod_app.security.headers import (  # noqa: E402
    extract_admin_session_cookie,
    extract_bearer_token,
    extract_forwarded_client_ip,
)


class BrokenString:
    def __str__(self) -> str:
        raise RuntimeError("deliberate")


class R9CSecurityHeaderBehaviorTests(unittest.TestCase):
    def test_forwarded_ip_accepts_one_canonical_ip(self) -> None:
        self.assertEqual(extract_forwarded_client_ip(" 192.0.2.10 "), "192.0.2.10")
        self.assertEqual(extract_forwarded_client_ip("2001:0db8::1"), "2001:db8::1")
        self.assertEqual(extract_forwarded_client_ip("[2001:db8::2]"), "2001:db8::2")
        self.assertEqual(extract_forwarded_client_ip("[2001:db8::1]:443"), "2001:db8::1")

    def test_forwarded_ip_rejects_chains_ports_zones_and_invalid_values(self) -> None:
        for value in (
            "", "192.0.2.1, 198.51.100.2", "192.0.2.1:443",
            "not-an-ip", None,
        ):
            self.assertEqual(extract_forwarded_client_ip(value), "", value)
        with self.assertRaises(RuntimeError):
            extract_forwarded_client_ip(BrokenString())

    def test_bearer_parser_preserves_established_case_and_spacing(self) -> None:
        self.assertEqual(extract_bearer_token("Bearer abc"), "abc")
        self.assertEqual(extract_bearer_token(" bearer   abc  "), "abc")
        self.assertEqual(extract_bearer_token("BEARER a.b-c_d"), "a.b-c_d")

    def test_bearer_parser_does_not_accept_other_schemes_or_missing_value(self) -> None:
        for value in ("", "Bearer", "Basic abc", "Token abc", None):
            self.assertEqual(extract_bearer_token(value), "", value)
        with self.assertRaises(RuntimeError):
            extract_bearer_token(BrokenString())

    def test_admin_cookie_parser_is_exact_and_keeps_embedded_equals(self) -> None:
        self.assertEqual(
            extract_admin_session_cookie("theme=dark; adzaagt_admin_session=a=b=c; other=1"),
            "a=b=c",
        )
        self.assertEqual(
            extract_admin_session_cookie("adzaagt_admin_session=first; adzaagt_admin_session=second"),
            "first",
        )
        for value in ("", "ADZAAGT_ADMIN_SESSION=x", "broken", None, BrokenString()):
            self.assertEqual(extract_admin_session_cookie(value), "", value)


class R9CSecurityHeaderOwnershipTests(unittest.TestCase):
    def test_server_imports_exact_aliases_and_has_no_duplicate_owners(self) -> None:
        tree = ast.parse(SERVER.read_text(encoding="utf-8"), filename=str(SERVER))
        definitions = {
            node.name for node in tree.body
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
        }
        expected = {
            "_extract_admin_session_cookie",
            "_extract_bearer_token",
            "_extract_forwarded_client_ip",
        }
        self.assertEqual(definitions & expected, set())
        aliases = {
            alias.asname: alias.name
            for node in tree.body
            if isinstance(node, ast.ImportFrom)
            and node.module == "metod_app.security.headers"
            for alias in node.names
        }
        self.assertEqual(
            aliases,
            {
                "_extract_admin_session_cookie": "extract_admin_session_cookie",
                "_extract_bearer_token": "extract_bearer_token",
                "_extract_forwarded_client_ip": "extract_forwarded_client_ip",
            },
        )

    def test_server_uses_the_single_header_parser_owner(self) -> None:
        previous = os.environ.get("METOD_STATE_ROOT")
        with tempfile.TemporaryDirectory(prefix="r9c-header-owner-") as temp_name:
            os.environ["METOD_STATE_ROOT"] = str(Path(temp_name) / "state")
            try:
                server = importlib.import_module("server_py")
                self.assertIs(server._extract_forwarded_client_ip, extract_forwarded_client_ip)
                self.assertIs(server._extract_bearer_token, extract_bearer_token)
                self.assertIs(server._extract_admin_session_cookie, extract_admin_session_cookie)
            finally:
                if previous is None:
                    os.environ.pop("METOD_STATE_ROOT", None)
                else:
                    os.environ["METOD_STATE_ROOT"] = previous

    def test_header_module_has_no_policy_runtime_or_io_dependencies(self) -> None:
        path = APP / "metod_app/security/headers.py"
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        imports = {
            alias.name.split(".", 1)[0]
            for node in ast.walk(tree)
            if isinstance(node, ast.Import)
            for alias in node.names
        }
        imports.update(
            node.module.split(".", 1)[0]
            for node in ast.walk(tree)
            if isinstance(node, ast.ImportFrom) and node.module
        )
        self.assertEqual(
            imports & {
                "http", "logging", "os", "pathlib", "server_py", "socket",
                "subprocess", "threading", "time",
            },
            set(),
        )
        calls = {
            node.func.id for node in ast.walk(tree)
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
        }
        self.assertFalse(calls & {"open", "print", "exec", "eval", "compile", "__import__"})


if __name__ == "__main__":
    unittest.main(verbosity=2)
