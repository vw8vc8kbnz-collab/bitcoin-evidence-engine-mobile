#!/usr/bin/env python3
from __future__ import annotations

"""Fail-closed gate for canonical R9O7 identity, provenance and protected behavior."""

import argparse
import hashlib
import json
import math
import os
import tempfile
from pathlib import Path
from typing import Any


DEFAULT_RELEASE = Path(__file__).resolve().parents[1]
REVISION = "R9O7"
BUILD = "R9O7_WEBKIT_IPHONE_ADMIN_GRID_TRACK_REMEDIATION"
ARTIFACT = "METOD_PAX_R9O7_WEBKIT_IPHONE_ADMIN_GRID_TRACK_REMEDIATION_CANDIDATE.zip"
ARTIFACT_ROOT = "METOD_PAX_R9O7_WEBKIT_IPHONE_ADMIN_GRID_TRACK_REMEDIATION_CANDIDATE"
TAG = "r9o7-webkit-iphone-admin-grid-track-remediation-candidate-checkpoint"
STATUS = "PROVISIONAL_DEVELOPMENT_ONLY"
CHANNEL = "AUDIT_CANDIDATE"
COMPONENT_REVISION = "R9I_SYNC_CATALOG_REFRESH_CLEANUP_9"
COMPATIBILITY_BUILD = "FIX660R8_PRELIVE_HARDENED"
GOLDEN_REVISION = "R8Z"
GOLDEN_SHA256 = "d3e8656d8d7d5a581a8186ef8fe2c91c19b2137a8654b2f2874497dd85255e62"
EXPECTED_BROWSER = "R9O6_WEBKIT_IPHONE_ADMIN_GRID_TRACK_FAIL_R9O7_RERUN_PENDING_NO_GO"
EXPECTED_VPS = "R9O6_EXTERNAL_BROWSER_EVIDENCE_FAIL_R9O7_PENDING_NO_GO"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def strict_json(path: Path) -> Any:
    value = json.loads(
        path.read_text(encoding="utf-8", errors="strict"),
        parse_constant=lambda token: (_ for _ in ()).throw(ValueError(f"non-finite JSON: {token}")),
    )
    stack = [value]
    while stack:
        item = stack.pop()
        if isinstance(item, float) and not math.isfinite(item):
            raise ValueError("non-finite JSON number")
        if isinstance(item, dict):
            stack.extend(item.values())
        elif isinstance(item, list):
            stack.extend(item)
    return value


def sbom_properties(sbom: dict[str, Any]) -> dict[str, str]:
    return {
        str(item.get("name") or ""): str(item.get("value") or "")
        for item in (((sbom.get("metadata") or {}).get("properties")) or [])
        if isinstance(item, dict)
    }


def audit_release(release: Path) -> dict[str, Any]:
    release = release.resolve(strict=True)
    failures: list[dict[str, Any]] = []

    def require(condition: bool, rule_id: str, **details: Any) -> None:
        if not condition:
            failures.append({"ruleId": rule_id, **details})

    identity = strict_json(release / "RELEASE_IDENTITY.json")
    canonical = identity.get("canonicalCandidate") or {}
    application = identity.get("application") or {}
    golden = identity.get("immutableGoldenBaseline") or {}
    external = identity.get("externalEvidence") or {}
    require(identity.get("contractId") == "R9O7_RELEASE_IDENTITY", "identity-contract-id")
    require(identity.get("schemaVersion") == 1, "identity-schema")

    expected_candidate = {
        "releaseRevision": REVISION,
        "buildId": BUILD,
        "releaseChannel": CHANNEL,
        "status": STATUS,
        "releaseEligible": False,
        "artifactName": ARTIFACT,
        "artifactRootDirectory": ARTIFACT_ROOT,
        "intendedSourceTag": TAG,
    }
    for key, expected in expected_candidate.items():
        require(canonical.get(key) == expected, "canonical-candidate-field", field=key, expected=expected, actual=canonical.get(key))

    require(application.get("componentRevision") == COMPONENT_REVISION, "application-component-revision")
    require(application.get("runtimeCompatibilityBuild") == COMPATIBILITY_BUILD, "runtime-compatibility-build")
    require(golden.get("role") == "behavior-oracle-only", "golden-role")
    require(golden.get("releaseRevision") == GOLDEN_REVISION, "golden-revision")
    require(golden.get("artifactSha256") == GOLDEN_SHA256, "golden-artifact-sha256")
    require(golden.get("mutationPolicy") == "immutable-golden-oracle", "golden-mutation-policy")
    require(external.get("productionGo") is False, "production-go-must-be-false")
    require(external.get("browser") == EXPECTED_BROWSER, "external-browser-gate-state")
    require(external.get("vps") == EXPECTED_VPS, "external-vps-gate-state")
    for gate in ("realIphoneSafari", "independentSecurityAudit", "productionOperations", "camWorkshopBusiness", "formalReleaseSignoff"):
        require(external.get(gate) == "DEFERRED_NO_GO", "external-gate-not-no-go", gate=gate)

    runtime = strict_json(release / "RUNTIME_CONTRACT.json")
    runtime_expected = {
        "releaseIdentityContract": "RELEASE_IDENTITY.json",
        "build": BUILD,
        "releaseRevision": REVISION,
        "artifactName": ARTIFACT,
        "artifactRootDirectory": ARTIFACT_ROOT,
        "releaseChannel": CHANNEL,
        "releaseStatus": STATUS,
        "releaseEligible": False,
        "applicationComponentRevision": COMPONENT_REVISION,
        "runtimeCompatibilityBuild": COMPATIBILITY_BUILD,
        "immutableGoldenBaselineRevision": GOLDEN_REVISION,
    }
    for key, expected in runtime_expected.items():
        require(runtime.get(key) == expected, "runtime-identity-mismatch", field=key, expected=expected, actual=runtime.get(key))

    sbom = strict_json(release / "SBOM.cdx.json")
    properties = sbom_properties(sbom)
    component = ((sbom.get("metadata") or {}).get("component") or {})
    require(sbom.get("bomFormat") == "CycloneDX" and sbom.get("specVersion") == "1.5", "sbom-format")
    require(component.get("version") == BUILD, "sbom-component-build")
    for key, expected in {
        "releaseRevision": REVISION,
        "artifactName": ARTIFACT,
        "artifactRootDirectory": ARTIFACT_ROOT,
        "releaseChannel": CHANNEL,
        "releaseStatus": STATUS,
        "releaseEligible": "false",
        "applicationComponentRevision": COMPONENT_REVISION,
        "runtimeCompatibilityBuild": COMPATIBILITY_BUILD,
        "immutableGoldenBaselineRevision": GOLDEN_REVISION,
    }.items():
        require(properties.get(key) == expected, "sbom-identity-mismatch", field=key, expected=expected, actual=properties.get(key))

    html = (release / "app/toolA.html").read_text(encoding="utf-8", errors="strict")
    for marker in (
        f'<meta name="metod-release-revision" content="{REVISION}" />',
        f'<meta name="metod-release-build" content="{BUILD}" />',
        f'<meta name="metod-release-channel" content="{CHANNEL}" />',
        f'<meta name="metod-release-status" content="{STATUS}" />',
        f'<meta name="metod-application-revision" content="{COMPONENT_REVISION}" />',
        f'<meta name="metod-runtime-compatibility-build" content="{COMPATIBILITY_BUILD}" />',
        f'<meta name="metod-golden-baseline" content="{GOLDEN_REVISION}" />',
        f'<!-- {BUILD} -->',
    ):
        require(html.count(marker) == 1, "public-identity-marker", marker=marker, count=html.count(marker))
    require('name="metod-release-revision" content="R8Z"' not in html, "golden-misrepresented-as-current-release")

    deploy = (release / "DEPLOY_FIX660.sh").read_text(encoding="utf-8", errors="strict")
    require(f"grep -Fq '{BUILD}'" in deploy, "deploy-current-marker-missing")
    builder = (release / "tools/build_release_artifact.py").read_text(encoding="utf-8", errors="strict")
    require('"R9O7_RELEASE_IDENTITY"' in builder, "builder-identity-control-missing")
    workflow = (release / ".github/workflows/release-gate.yml").read_text(encoding="utf-8", errors="strict")
    require("tools/r9o7_release_identity_gate.py" in workflow, "workflow-identity-gate-missing")
    require(ARTIFACT in workflow, "workflow-artifact-missing")

    protected_results: dict[str, str] = {}
    protected = identity.get("protectedBehaviorFiles")
    require(isinstance(protected, dict) and len(protected) == 24, "protected-behavior-inventory")
    for relative, expected in (protected or {}).items():
        path = release / str(relative)
        actual = sha256_file(path) if path.is_file() else "MISSING"
        protected_results[str(relative)] = actual
        require(actual == expected, "protected-behavior-drift", path=relative, expected=expected, actual=actual)

    return {
        "schemaVersion": 1,
        "gateId": "R9O7_RELEASE_IDENTITY_GATE",
        "status": "PASS" if not failures else "FAIL",
        "release": str(release),
        "releaseRevision": canonical.get("releaseRevision"),
        "buildId": canonical.get("buildId"),
        "artifactName": canonical.get("artifactName"),
        "artifactRootDirectory": canonical.get("artifactRootDirectory"),
        "releaseStatus": canonical.get("status"),
        "releaseEligible": canonical.get("releaseEligible"),
        "applicationComponentRevision": application.get("componentRevision"),
        "runtimeCompatibilityBuild": application.get("runtimeCompatibilityBuild"),
        "goldenBaselineRevision": golden.get("releaseRevision"),
        "goldenBaselineArtifactSha256": golden.get("artifactSha256"),
        "protectedBehaviorSha256": protected_results,
        "externalEvidence": external,
        "failures": failures,
    }


def write_json_atomic(path: Path, value: dict[str, Any]) -> None:
    path = path.expanduser().absolute()
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=path.parent, delete=False) as handle:
        json.dump(value, handle, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
        temporary = Path(handle.name)
    os.replace(temporary, path)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--release", type=Path, default=DEFAULT_RELEASE)
    parser.add_argument("--json-output", type=Path)
    args = parser.parse_args()
    report = audit_release(args.release)
    if args.json_output:
        write_json_atomic(args.json_output, report)
    print(json.dumps(report, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False))
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
