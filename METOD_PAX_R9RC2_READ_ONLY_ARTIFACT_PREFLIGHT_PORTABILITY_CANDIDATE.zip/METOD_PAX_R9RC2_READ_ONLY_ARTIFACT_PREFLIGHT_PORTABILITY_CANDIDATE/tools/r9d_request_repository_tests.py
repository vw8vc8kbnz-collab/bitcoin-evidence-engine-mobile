#!/usr/bin/env python3
from __future__ import annotations

"""Behavior and ownership proof for the R9D request repository extraction."""

import ast
import json
import sys
import tempfile
import threading
import unittest
from pathlib import Path


RELEASE = Path(__file__).resolve().parents[1]
APP = RELEASE / "app"
SERVER = APP / "server_py.py"
REPOSITORY_SOURCE = APP / "metod_app/requests/repository.py"
sys.path.insert(0, str(APP))

from metod_app.requests.repository import RequestRepository, request_index_row  # noqa: E402


class CountingLock:
    def __init__(self) -> None:
        self.entries = 0
        self._lock = threading.RLock()

    def __enter__(self):
        self._lock.acquire()
        self.entries += 1
        return self

    def __exit__(self, exc_type, exc, traceback) -> None:
        self._lock.release()


class RepositoryFixture(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory(prefix="r9d-request-repository-")
        self.base = Path(self.temporary.name)
        self.paths = {
            "requests": self.base / "state/requests",
            "index": self.base / "state/requests_index.jsonl",
        }
        self.lock = CountingLock()
        self.clock = iter(("2026-08-20T10:00:00+00:00", "2026-08-20T10:00:01+00:00"))
        self.repository = self.make_repository()

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def ensure_directories(self) -> None:
        self.paths["requests"].mkdir(parents=True, exist_ok=True)
        self.paths["index"].parent.mkdir(parents=True, exist_ok=True)

    def make_repository(self, *, max_rows: int = 250_000) -> RequestRepository:
        return RequestRepository(
            requests_root=lambda: self.paths["requests"],
            requests_index=lambda: self.paths["index"],
            index_lock=lambda: self.lock,
            ensure_directories=self.ensure_directories,
            utc_now_iso=lambda: next(self.clock),
            jsonl_max_bytes=lambda: 20 * 1024 * 1024,
            max_active_rows=lambda: max_rows,
            file_lock_module=lambda: None,
        )


class R9DRequestRepositoryBehaviorTests(RepositoryFixture):
    def test_01_index_row_is_exact_and_contains_no_customer_pii(self) -> None:
        status = {
            "createdAt": "created",
            "updatedAt": "updated",
            "publicStatus": "received",
            "internalStatus": "NEW",
            "quoteStatus": "pending",
            "needsQuote": 1,
            "job": {"parentJobId": "job_parent", "bearer": "secret"},
            "customer": {"firstName": "Ada", "email": "ada@example.invalid"},
            "address": "Secret street",
        }
        self.assertEqual(
            request_index_row("request_001", status),
            {
                "ts": "updated",
                "requestId": "request_001",
                "publicStatus": "received",
                "internalStatus": "NEW",
                "quoteStatus": "pending",
                "needsQuote": True,
                "parentJobId": "job_parent",
            },
        )

    def test_02_save_then_load_preserves_status_and_exact_index_shape(self) -> None:
        status = {
            "createdAt": "created",
            "publicStatus": "received",
            "internalStatus": "NEW",
            "quoteStatus": "pending",
            "needsQuote": False,
            "customer": {"email": "private@example.invalid"},
        }
        self.repository.save_status("request_001", status)
        self.assertEqual(status["updatedAt"], "2026-08-20T10:00:00+00:00")
        self.assertEqual(self.repository.load_status("request_001"), status)
        rows = [json.loads(line) for line in self.paths["index"].read_text().splitlines()]
        self.assertEqual(rows, [request_index_row("request_001", status)])
        self.assertNotIn("private@example.invalid", self.paths["index"].read_text())

    def test_03_load_fails_closed_for_invalid_missing_and_non_object_status(self) -> None:
        self.assertIsNone(self.repository.load_status("../escape"))
        self.assertIsNone(self.repository.load_status("missing"))
        path = self.paths["requests"] / "request_001/status.json"
        path.parent.mkdir(parents=True)
        path.write_text("[]\n", encoding="utf-8")
        self.assertIsNone(self.repository.load_status("request_001"))
        path.write_text("{broken", encoding="utf-8")
        self.assertIsNone(self.repository.load_status("request_001"))

    def test_04_path_providers_follow_runtime_state_root_changes(self) -> None:
        first_root = self.paths["requests"]
        self.repository.save_status("request_first", {"publicStatus": "received"})
        self.paths["requests"] = self.base / "other/requests"
        self.paths["index"] = self.base / "other/requests_index.jsonl"
        self.repository.save_status("request_second", {"publicStatus": "received"})
        self.assertTrue((first_root / "request_first/status.json").is_file())
        self.assertFalse((first_root / "request_second/status.json").exists())
        self.assertTrue((self.paths["requests"] / "request_second/status.json").is_file())
        self.assertIn("request_second", self.paths["index"].read_text())

    def test_05_compaction_rebuilds_ordered_index_and_only_removes_numeric_rotations(self) -> None:
        self.ensure_directories()
        for request_id, timestamp in (("request_003", "3"), ("request_001", "1"), ("request_002", "2")):
            path = self.paths["requests"] / request_id / "status.json"
            path.parent.mkdir(parents=True)
            path.write_text(json.dumps({"updatedAt": timestamp, "publicStatus": "received"}), encoding="utf-8")
        (self.paths["index"].parent / "requests_index.jsonl.1").write_text("old", encoding="utf-8")
        (self.paths["index"].parent / "requests_index.jsonl.keep").write_text("keep", encoding="utf-8")
        result = self.repository.compact_index()
        self.assertEqual(result, {"rows": 3, "truncated": False, "removedRotations": 1})
        ids = [json.loads(line)["requestId"] for line in self.paths["index"].read_text().splitlines()]
        self.assertEqual(ids, ["request_001", "request_002", "request_003"])
        self.assertFalse((self.paths["index"].parent / "requests_index.jsonl.1").exists())
        self.assertTrue((self.paths["index"].parent / "requests_index.jsonl.keep").is_file())

    def test_06_compaction_keeps_established_minimum_bound_and_reports_truncation(self) -> None:
        self.ensure_directories()
        for index in range(1001):
            request_id = f"request_{index:04d}"
            path = self.paths["requests"] / request_id / "status.json"
            path.parent.mkdir(parents=True)
            path.write_text('{"publicStatus":"received"}', encoding="utf-8")
        result = self.make_repository(max_rows=1).compact_index()
        self.assertEqual(result["rows"], 1000)
        self.assertTrue(result["truncated"])
        self.assertEqual(len(self.paths["index"].read_text().splitlines()), 1000)

    def test_07_save_and_compaction_use_the_same_injected_lock(self) -> None:
        self.repository.save_status("request_001", {"publicStatus": "received"})
        self.repository.compact_index()
        self.assertEqual(self.lock.entries, 2)


class R9DRequestRepositoryOwnershipTests(unittest.TestCase):
    def test_08_server_has_one_repository_owner_and_module_creates_no_lock_or_thread(self) -> None:
        server_tree = ast.parse(SERVER.read_text(encoding="utf-8"), filename=str(SERVER))
        definitions = {
            node.name for node in server_tree.body
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
        }
        self.assertFalse(
            definitions & {
                "_append_jsonl", "_load_status", "_save_status",
                "_request_index_row", "_compact_requests_index",
            }
        )
        server_source = SERVER.read_text(encoding="utf-8")
        self.assertIn("_load_status = _REQUEST_REPOSITORY.load_status", server_source)
        self.assertIn("_save_status = _REQUEST_REPOSITORY.save_status", server_source)
        self.assertIn("_compact_requests_index = _REQUEST_REPOSITORY.compact_index", server_source)
        self.assertIn("index_lock=lambda: _REQUESTS_INDEX_LOCK", server_source)

        repository_tree = ast.parse(REPOSITORY_SOURCE.read_text(encoding="utf-8"), filename=str(REPOSITORY_SOURCE))
        imports = {
            alias.name.split(".", 1)[0]
            for node in ast.walk(repository_tree)
            if isinstance(node, ast.Import)
            for alias in node.names
        }
        imports.update(
            node.module.split(".", 1)[0]
            for node in ast.walk(repository_tree)
            if isinstance(node, ast.ImportFrom) and node.module
        )
        self.assertFalse(imports & {"server_py", "threading", "subprocess", "http", "socket"})
        calls = {
            node.func.id for node in ast.walk(repository_tree)
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
        }
        self.assertNotIn("RLock", calls)
        self.assertNotIn("Lock", calls)


if __name__ == "__main__":
    unittest.main(verbosity=2)
