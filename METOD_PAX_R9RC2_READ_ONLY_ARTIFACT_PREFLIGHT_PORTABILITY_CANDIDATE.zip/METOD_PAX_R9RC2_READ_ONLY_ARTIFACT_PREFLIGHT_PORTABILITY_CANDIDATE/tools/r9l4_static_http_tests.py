#!/usr/bin/env python3
from __future__ import annotations

"""Executable ownership, safety and parity contracts for R9L4."""

import ast
import io
import json
import os
import sys
import tempfile
import types
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
SERVER = APP / "server_py.py"
OWNER = APP / "metod_app/http/static.py"
MATCHER = APP / "metod_app/http/matcher.py"
FIXTURE = ROOT / "R9L4_STATIC_HTTP_BEFORE_FIXTURE.json"
SCOPE = ROOT / "R9L4_STATIC_HTTP_ADAPTERS_EXTRACTION_SCOPE.json"
CONTRACT = ROOT / "R9L4_STATIC_HTTP_ADAPTERS_EXTRACTION.json"
os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")
_STATE_TEMP = tempfile.TemporaryDirectory(prefix="r9l4_static_http_tests_")
os.environ.setdefault("METOD_STATE_ROOT", str(Path(_STATE_TEMP.name) / "state"))
sys.path.insert(0, str(APP))
sys.path.insert(0, str(ROOT / "tools"))

import server_py as server  # noqa: E402
from metod_app.http.static import (  # noqa: E402
    BLOCKED_STATIC_TOP_LEVEL,
    PUBLIC_STATIC_MODULE_FILES,
    PUBLIC_STATIC_ROOT_FILES,
    PUBLIC_STATIC_SHELL_FILES,
    StaticHttpAdapterService,
    StaticHttpDependencies,
)
from r9l4_static_http_before_gate import _behavior  # noqa: E402


class R9L4StaticHttpTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.fixture = json.loads(FIXTURE.read_text(encoding="utf-8"))
        cls.scope = json.loads(SCOPE.read_text(encoding="utf-8"))
        cls.contract = json.loads(CONTRACT.read_text(encoding="utf-8"))
        cls.server_source = SERVER.read_text(encoding="utf-8")
        cls.owner_source = OWNER.read_text(encoding="utf-8")
        cls.matcher_source = MATCHER.read_text(encoding="utf-8")
        cls.server_tree = ast.parse(cls.server_source)
        cls.owner_tree = ast.parse(cls.owner_source)

    def test_01_fixture_seals_exact_r9l3_source_before_extraction(self) -> None:
        self.assertEqual(self.fixture["sourceCheckpoint"], "R9L3")
        self.assertEqual(self.fixture["sourceCommit"], "ec144cd890b064873d0246c8c9bf2a244802b16a")
        self.assertEqual(self.fixture["server"], {
            "bytes": 518347,
            "lines": 11329,
            "sha256": "54d3600b66496cc361cdf6c4d96d9f196d48555c44a9ea49a6a2fb3369b593c0",
        })
        self.assertEqual(len(self.fixture["activeOwnerSource"]), 9)

    def test_02_one_module_owns_static_policy_and_generic_responses(self) -> None:
        classes = {node.name for node in self.owner_tree.body if isinstance(node, ast.ClassDef)}
        self.assertEqual(classes, {"StaticHttpDependencies", "StaticHttpAdapterService"})
        service = next(node for node in self.owner_tree.body if isinstance(node, ast.ClassDef) and node.name == "StaticHttpAdapterService")
        methods = {node.name for node in service.body if isinstance(node, ast.FunctionDef)}
        self.assertTrue({
            "translate_path", "guess_type", "prepare_html", "apply_default_headers",
            "send_text", "send_json", "stream_file",
        }.issubset(methods))
        for name in ("PUBLIC_STATIC_ROOT_FILES", "PUBLIC_STATIC_MODULE_FILES", "PUBLIC_STATIC_SHELL_FILES", "BLOCKED_STATIC_TOP_LEVEL"):
            self.assertNotIn(f"{name} =", self.server_source)
        self.assertNotIn("def _is_public_static_relpath", self.server_source)
        self.assertNotIn("def _is_blocked_static_relpath", self.server_source)

    def test_03_handler_retains_only_thin_transport_adapters(self) -> None:
        handler = next(node for node in self.server_tree.body if isinstance(node, ast.ClassDef) and node.name == "Handler")
        methods = {node.name: node for node in handler.body if isinstance(node, ast.FunctionDef)}
        limits = {
            "_prepare_html": 4, "translate_path": 2, "guess_type": 2,
            "end_headers": 3, "_send_text": 2, "_send_json": 2, "_stream_file": 5,
        }
        for name, maximum in limits.items():
            segment = ast.get_source_segment(self.server_source, methods[name])
            self.assertIsNotNone(segment)
            self.assertLessEqual(len(str(segment).splitlines()), maximum, name)
            self.assertIn("_STATIC_HTTP", str(segment), name)

    def test_04_matcher_reuses_static_owner_without_policy_duplication(self) -> None:
        self.assertIn("from .static import (", self.matcher_source)
        self.assertNotIn("PUBLIC_STATIC_ROOT_FILES =", self.matcher_source)
        self.assertNotIn("def _is_public_static_relpath", self.matcher_source)
        self.assertEqual(len(PUBLIC_STATIC_ROOT_FILES), 49)
        self.assertEqual(len(PUBLIC_STATIC_MODULE_FILES), 19)
        self.assertEqual(len(PUBLIC_STATIC_SHELL_FILES), 41)
        self.assertEqual(len(BLOCKED_STATIC_TOP_LEVEL), 8)

    def test_05_all_sealed_behavior_is_byte_exact(self) -> None:
        actual = _behavior()
        for key, value in actual.items():
            self.assertEqual(value, self.fixture[key], key)

    def test_06_default_header_order_and_production_security_are_exact(self) -> None:
        service = StaticHttpAdapterService(StaticHttpDependencies(
            root=lambda: Path("/unused"), state_root=lambda: Path("/unused"),
            dxf_manifest_path=lambda: Path("/unused"), dxf_library_root=lambda: Path("/unused"),
            resolve_relative_file=lambda root, rel: root / rel,
            sanitize_filename=lambda value, limit: value.replace('"', "_")[:limit],
            strict_json_dumps=json.dumps,
            origin_allowed=lambda origin, *, admin=False: origin == "https://allowed.invalid",
            production_hardening_enabled=lambda: True,
            https_request=lambda handler: True,
        ))
        handler = types.SimpleNamespace(
            path="/embedded_dxfs/door%20one.dxf", headers={"Origin": "https://allowed.invalid"},
            _csp_nonce="sealed-nonce", sent_headers=[],
        )
        handler.send_header = lambda key, value: handler.sent_headers.append((key, value))
        service.apply_default_headers(handler)
        keys = [key for key, _ in handler.sent_headers]
        self.assertEqual(keys[:4], [
            "Access-Control-Allow-Origin", "Vary",
            "Access-Control-Allow-Methods", "Access-Control-Allow-Headers",
        ])
        self.assertIn(("Content-Disposition", 'attachment; filename="door one.dxf"'), handler.sent_headers)
        csp = dict(handler.sent_headers)["Content-Security-Policy"]
        self.assertIn("script-src 'self' 'nonce-sealed-nonce'", csp)
        self.assertEqual(dict(handler.sent_headers)["Strict-Transport-Security"], "max-age=31536000")

    def test_07_static_resolution_is_deny_by_default_and_contained(self) -> None:
        matrix = self.fixture["translationMatrix"]
        self.assertEqual(matrix["/"], "APP/toolA.html")
        self.assertEqual(matrix["/embedded_dxfs/safe/a.dxf"], "STATE/dxf/safe/a.dxf")
        for path in ("/embedded_dxfs/../secret.dxf", "/config/app.json", "/server_py.py", "/assets/../toolA.html", "/missing.js"):
            self.assertEqual(matrix[path], "FORBIDDEN", path)

    def test_08_response_and_stream_failures_are_closed_before_leakage(self) -> None:
        matrix = self.fixture["responseMatrix"]
        self.assertEqual(matrix["jsonSerializationFailure"]["status"], 500)
        self.assertEqual(bytes.fromhex(matrix["jsonSerializationFailure"]["bodyHex"]), b'{"ok":false,"error":"Response serialization failed"}')
        self.assertEqual(matrix["streamOverLimit"]["status"], 413)
        self.assertEqual(matrix["stream"]["headers"][1], ["Content-Disposition", 'attachment; filename="bad_name_.bin"'])

    def test_09_owner_has_no_auth_route_business_or_mutation_ownership(self) -> None:
        for token in (
            "server_py", "do_GET", "do_POST", "_require_admin_auth", "validate_job_id",
            "optimizer", "pricing", "ZipFile", "subprocess", "threading", ".unlink(",
            ".write_text(", ".write_bytes(",
        ):
            self.assertNotIn(token, self.owner_source, token)

    def test_10_scope_excludes_r9l5_and_r9m_work(self) -> None:
        self.assertEqual(self.scope["contractId"], "R9L4_STATIC_HTTP_ADAPTERS_EXTRACTION_SCOPE")
        self.assertIn("remaining job lifecycle facades reserved for R9L5", self.scope["excluded"])
        self.assertIn("R9M HTML, CSS or JavaScript splitting", self.scope["excluded"])

    def test_11_checkpoint_remains_external_no_go(self) -> None:
        self.assertEqual(self.contract["contractId"], "R9L4_STATIC_HTTP_ADAPTERS_EXTRACTION")
        self.assertEqual(self.contract["status"], "PROVISIONAL_DEVELOPMENT_ONLY")
        self.assertFalse(self.contract["releaseEligible"])
        self.assertFalse(self.contract["externalEvidence"]["productionGo"])

    def test_12_next_scope_is_exclusively_r9l5(self) -> None:
        self.assertEqual(
            self.contract["nextExclusiveCheckpoint"],
            "R9L5_REMAINING_JOB_LIFECYCLE_FACADES_EXTRACTION",
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
