#!/usr/bin/env python3
from __future__ import annotations

"""Start the real server and prove its public HTTP control plane responds.

Import- and handler-unit tests do not execute ``Handler.do_GET`` through
``http.server``.  This process-level smoke test exists specifically to catch
startup/dispatch failures such as class name-mangling of module constants.
"""

import ast
import csv
import hashlib
import io
import json
import os
import re
import socket
import subprocess
import sys
import tempfile
import time
import unittest
import zipfile
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import ProxyHandler, Request, build_opener


RELEASE_ROOT = Path(__file__).resolve().parents[1]
SERVER = RELEASE_ROOT / "app/server_py.py"
EXPECTED_BUILD = "FIX660R8_PRELIVE_HARDENED"
TEST_PUBLIC_ID = "decor_0123456789abcdefabcd"
TEST_PASSWORD = "http-smoke-safe-password"
TEST_IMAGE_URL = "https://adzaagt.nl/11922-large_default/decolegno-b003-decobasic-fsc-2800-2070-18.jpg"
R9K2_DEPRECATED_MATERIAL_ROUTES = (
    "/api/admin/materials/upload",
    "/api/admin/materials/save_item",
    "/api/admin/materials/delete_item",
    "/api/admin/materials/image_upload",
)
R9K2_DEPRECATED_RESPONSE_BODY = (
    b'{"ok": false, "error": "FIX652: actieve Decor Library wordt uitsluitend via CSV controleren + publiceren beheerd."}'
)
R9K2_DEPRECATED_RESPONSE_SHA256 = "d24352320ea66ca2c49c338309c6c58a0d80bedce9697f39e1d23ee800a6ad8a"
R9K3_JOB_ONLY_REQUEST_ID = "JOB_ONLY_IGNORED"
R9K3_REQUEST_OLD = "REQ_R9K3_OLD"
R9K3_REQUEST_NEW = "REQ_R9K3_NEW"
R9L3_EXPORT_JOB = "JOB_R9L3_HTTP_EXPORT"
R9L3_EXPORT_REL = "output/DXF_Zaagplaten/S01.dxf"
R9L3_EXPORT_BYTES = b"0\nSECTION\n2\nENTITIES\n0\nENDSEC\n0\nEOF\n"
R9M_ADMIN_HTML_SHA256 = "bc92febb40e7817ee0cccdd2c85b33affcd3c9e8f021e0d79d2a0810e0e94b22"
R9RC1_ADMIN_LOGIN_HTML_SHA256 = "caea75af8011ea377d048de113576380add26dead213fde12f6b2fd9f0ce8488"
R9M_ADMIN_ASSET_SHA256 = {
    "/admin/assets/admin.css": "7a6204cce598b9fa0d985a78156948f58caff7114ccf5ac60c30c48ad8961a28",
    "/admin/assets/admin.js": "141e71f2f0de57da6b40063283ae281348844c127f10f795744356afe3bb4745",
    "/admin/assets/dxf.js": "8fa36fd05f36519fdc731d758f33b38a1a4001434ae0bf755a326428901dc481",
    "/admin/assets/login.css": "aefb17e04655795803caa55d0f12f350832f8096031431d3e42d8e09be728955",
    "/admin/assets/login.js": "a32aa7d111b2e891a72b21f79ff15db3a1d332af0d5affe97c753768ff38fcc5",
}
R9L2_PROMETHEUS_GAUGES = (
    "metod_sse_clients",
    "metod_job_creates_active",
    "metod_job_creates_admitted",
    "metod_job_queue_waiting",
    "metod_job_admissions_reserved",
    "metod_jobs_total",
    "metod_requests_total",
    "metod_queue_pending",
    "metod_queue_processing",
    "metod_catalog_records",
    "metod_state_free_bytes",
)


def normalized_admin_html_sha256(body: bytes) -> str:
    normalized = re.sub(br' nonce="[A-Za-z0-9_-]+"', b"", body)
    return hashlib.sha256(normalized).hexdigest()


def minimal_jpeg(width: int = 2, height: int = 2) -> bytes:
    return (
        b"\xff\xd8\xff\xc0\x00\x11\x08"
        + int(height).to_bytes(2, "big")
        + int(width).to_bytes(2, "big")
        + b"\x03\x01\x11\x00\x02\x11\x00\x03\x11\x00\xff\xd9"
    )


def seed_catalog_and_credentials(state_root: Path, credentials_path: Path) -> bytes:
    state_root.mkdir(parents=True, exist_ok=True)
    image = minimal_jpeg()
    image_sha = hashlib.sha256(image).hexdigest()
    image_folder = state_root / "decor_media" / TEST_PUBLIC_ID
    image_folder.mkdir(parents=True, exist_ok=True)
    (image_folder / "catalog.img").write_bytes(image)
    (image_folder / "catalog.meta.json").write_text(
        json.dumps(
            {
                "mime": "image/jpeg",
                "sha256": image_sha,
                "bytes": len(image),
                "width": 2,
                "height": 2,
                "variantGenerator": "raw-fallback",
                "variants": {},
            }
        ),
        encoding="utf-8",
    )
    source_hash = hashlib.sha256(TEST_IMAGE_URL.encode("utf-8")).hexdigest()
    library = {
        "source": "CSV_CATALOG_ONLY",
        "pricingModel": "catalog_sell_price_incl_vat_v2",
        "decorLibrarySchemaVersion": 4,
        "records": [
            {
                "articleNo": "HTTP-SMOKE-001",
                "materialCode": "HTTP-SMOKE-001",
                "publicMaterialId": TEST_PUBLIC_ID,
                "productName": "DecoLegno B003 DECObasic FSC",
                "publicName": "DecoLegno B003 DECObasic FSC",
                "brand": "DecoLegno",
                "sourceKind": "CATALOG_IMPORT",
                "active": True,
                "published": True,
                "archived": False,
                "catalogMissing": False,
                "catalogExcluded": False,
                "thicknessMm": 18,
                "sheetWid": 2070,
                "sheetLen": 2800,
                "sellPriceInclVatPerSheet": 140.24,
                "primaryVisualFamily": "Uni",
                "visualFamily": "Uni",
                "visualTags": ["Uni"],
                "substrateType": "SPAANPLAAT",
                "substrateLabel": "Spaanplaat",
                "colorGroup": "Wit",
                "searchTags": ["uni", "wit"],
                "imageSourceUrls": [TEST_IMAGE_URL],
                "imageSourceUrl": TEST_IMAGE_URL,
                "catalogImageSourceHash": source_hash,
            }
        ],
    }
    library_path = state_root / "material_library.json"
    library_path.write_text(json.dumps(library), encoding="utf-8")

    # This deliberately stale derived cache has a matching source mtime. R8F must
    # reject it by schema/build and regenerate image URLs from verified media.
    system = state_root / "system"
    system.mkdir(parents=True, exist_ok=True)
    stale_body = b'{"ok":true,"records":[],"staleR8E":true}'
    (system / "public_material_catalog_v1.json").write_bytes(stale_body)
    (system / "public_material_catalog_v1.meta.json").write_text(
        json.dumps(
            {
                "schemaVersion": 1,
                "sourceMtimeNs": library_path.stat().st_mtime_ns,
                "etag": '"stale-r8e"',
                "count": 0,
                "build": "FIX656",
            }
        ),
        encoding="utf-8",
    )
    # Avoid racing this focused HTTP test with the independent automatic-backup
    # thread that intentionally drains mutations during its first snapshot.
    (system / "last_auto_backup.json").write_text(
        json.dumps({"ts": "2099-01-01T00:00:00", "file": "http-smoke-fixture.zip"}),
        encoding="utf-8",
    )

    salt = "0123456789abcdef0123456789abcdef"
    digest = hashlib.pbkdf2_hmac("sha256", TEST_PASSWORD.encode(), salt.encode(), 600_000).hex()
    credentials_path.write_text(
        json.dumps(
            {
                "schemaVersion": 2,
                "users": [
                    {
                        "username": "admin",
                        "password_hash": f"pbkdf2_sha256$600000${salt}${digest}",
                        "totp_secret": "",
                        "roles": ["admin"],
                        "active": True,
                    }
                ],
            }
        ),
        encoding="utf-8",
    )
    credentials_path.chmod(0o600)
    return image


def seed_r9k3_admin_requests(state_root: Path) -> None:
    requests = state_root / "requests"
    jobs = state_root / "jobs"
    requests.mkdir(parents=True, exist_ok=True)
    jobs.mkdir(parents=True, exist_ok=True)
    fixtures = {
        R9K3_REQUEST_OLD: {
            "createdAt": "2026-01-01T10:00:00",
            "customer": {"name": "Oud"},
            "privateMarker": "kept",
        },
        R9K3_REQUEST_NEW: {
            "createdAt": "2026-02-01T10:00:00",
            "customer": {"name": "Nieuw"},
            "job": {"parentJobId": R9L3_EXPORT_JOB, "subjobs": []},
        },
    }
    for request_id, status in fixtures.items():
        folder = requests / request_id
        folder.mkdir()
        (folder / "status.json").write_text(json.dumps(status), encoding="utf-8")
    (requests / "REQ_R9K3_MISSING").mkdir()
    corrupt = requests / "REQ_R9K3_CORRUPT"
    corrupt.mkdir()
    (corrupt / "status.json").write_text("{broken", encoding="utf-8")
    job_input = jobs / R9K3_JOB_ONLY_REQUEST_ID / "input"
    job_input.mkdir(parents=True)
    (job_input / "job.json").write_text(
        json.dumps({"customer": {"name": "Mag niet lekken"}}),
        encoding="utf-8",
    )

    export_root = jobs / R9L3_EXPORT_JOB
    export_input = export_root / "input"
    export_output = export_root / "output"
    export_dxf = export_output / "DXF_Zaagplaten" / "S01.dxf"
    export_dxf.parent.mkdir(parents=True)
    export_input.mkdir(parents=True)
    export_dxf.write_bytes(R9L3_EXPORT_BYTES)
    (export_input / "job.json").write_text(
        json.dumps({
            "customer": {"name": "Nieuw"},
            "material": {"materialCode": "HTTP-MAT", "materialName": "Eiken"},
        }),
        encoding="utf-8",
    )
    optimizer_manifest = export_output / "optimizer_manifest.json"
    optimizer_manifest.write_text("{}\n", encoding="utf-8")
    (export_output / "finalization.json").write_text(
        json.dumps({
            "schemaVersion": 2,
            "state": "COMPLETE",
            "optimizerManifestSha256": hashlib.sha256(optimizer_manifest.read_bytes()).hexdigest(),
            "artifactsSha256": {
                "DXF_Zaagplaten/S01.dxf": hashlib.sha256(R9L3_EXPORT_BYTES).hexdigest(),
            },
        }),
        encoding="utf-8",
    )


def preview_csv_text() -> str:
    output = io.StringIO(newline="")
    writer = csv.writer(output, lineterminator="\n")
    writer.writerow(
        [
            "Product Reference Code",
            "Product Image Urls",
            "Product Name",
            "Feature Max. dikte (mm)",
            "Feature Max. lengte (mm)",
            "Feature Max. breedte (mm)",
            "Prijs per plaat inclusief BTW",
        ]
    )
    writer.writerow(
        [
            "HTTP-SMOKE-001",
            TEST_IMAGE_URL,
            "DecoLegno B003 DECObasic FSC",
            "18",
            "2800",
            "2070",
            "140,24",
        ]
    )
    return output.getvalue()


def reserve_loopback_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        probe.bind(("127.0.0.1", 0))
        return int(probe.getsockname()[1])


class RealHTTPProcessTests(unittest.TestCase):
    def test_01_class_methods_have_no_mangling_prone_global_names(self) -> None:
        tree = ast.parse(SERVER.read_text(encoding="utf-8", errors="strict"), filename=str(SERVER))
        violations: list[str] = []
        for class_node in (node for node in ast.walk(tree) if isinstance(node, ast.ClassDef)):
            for node in ast.walk(class_node):
                if (
                    isinstance(node, ast.Name)
                    and node.id.startswith("__")
                    and not node.id.endswith("__")
                ):
                    violations.append(f"{class_node.name}:{node.lineno}:{node.id}")
        self.assertEqual(violations, [], f"class name-mangling hazard: {violations}")

    def test_02_real_server_answers_liveness_readiness_and_tool_a(self) -> None:
        opener = build_opener(ProxyHandler({}))
        port = reserve_loopback_port()
        with tempfile.TemporaryDirectory(prefix="fix660r8_http_smoke_") as temp_dir:
            temp_root = Path(temp_dir)
            state_root = temp_root / "state"
            credentials_path = temp_root / "admin_credentials.live.json"
            expected_image = seed_catalog_and_credentials(state_root, credentials_path)
            seed_r9k3_admin_requests(state_root)
            log_path = temp_root / "server.log"
            env = dict(os.environ)
            env.update(
                {
                    "PYTHONDONTWRITEBYTECODE": "1",
                    "PYTHONUNBUFFERED": "1",
                    "METOD_STATE_ROOT": str(state_root),
                    "METOD_HOST": "127.0.0.1",
                    "METOD_PORT": str(port),
                    "APP_ENV": "staging",
                    "PRODUCTION_HARDENING": "0",
                    "ADMIN_CREDENTIALS_FILE": str(credentials_path),
                    "HTTP_MAX_CONCURRENT": "64",
                }
            )
            with log_path.open("wb") as log_handle:
                process = subprocess.Popen(
                    [sys.executable, "-B", str(SERVER)],
                    cwd=str(RELEASE_ROOT / "app"),
                    env=env,
                    stdin=subprocess.DEVNULL,
                    stdout=log_handle,
                    stderr=subprocess.STDOUT,
                )
                try:
                    live_status = None
                    live_body = b""
                    deadline = time.monotonic() + 30
                    last_error: Exception | None = None
                    while time.monotonic() < deadline:
                        if process.poll() is not None:
                            break
                        try:
                            with opener.open(f"http://127.0.0.1:{port}/health/live", timeout=2) as response:
                                live_status = response.status
                                live_body = response.read()
                            break
                        except HTTPError as exc:
                            last_error = RuntimeError(f"HTTP {exc.code}")
                            exc.close()
                            time.sleep(0.1)
                        except (URLError, TimeoutError, ConnectionError) as exc:
                            last_error = exc
                            time.sleep(0.1)

                    log_handle.flush()
                    if live_status is None:
                        log_text = log_path.read_text(encoding="utf-8", errors="replace")[-12000:]
                        self.fail(
                            f"server gaf geen livenessantwoord; exit={process.poll()}; "
                            f"laatste fout={last_error!r}\n{log_text}"
                        )

                    self.assertEqual(live_status, 200)
                    live = json.loads(live_body)
                    self.assertEqual(live, {"ok": True, "build": EXPECTED_BUILD})

                    try:
                        with opener.open(f"http://127.0.0.1:{port}/health/ready", timeout=5) as response:
                            ready_status = response.status
                            ready_body = response.read()
                    except HTTPError as exc:
                        ready_status = exc.code
                        try:
                            ready_body = exc.read()
                        finally:
                            exc.close()
                    self.assertIn(ready_status, {200, 503})
                    ready = json.loads(ready_body)
                    self.assertEqual(ready, {"ok": ready_status == 200, "build": EXPECTED_BUILD})
                    self.assertNotIn("checks", ready)
                    self.assertNotIn("details", ready)

                    with opener.open(f"http://127.0.0.1:{port}/", timeout=10) as response:
                        tool_status = response.status
                        tool_body = response.read()
                    self.assertEqual(tool_status, 200)
                    self.assertIn(b"R9RC1_PROFESSIONAL_ARCHITECTURE_COMPLETION", tool_body)
                    self.assertIn(b"R9H_SEMANTIC_SHELL_10", tool_body)

                    with opener.open(
                        f"http://127.0.0.1:{port}/tool-a/shell/script-01-early-catalog-bootstrap.js",
                        timeout=10,
                    ) as response:
                        shell_status = response.status
                        shell_type = response.headers.get_content_type()
                        shell_body = response.read()
                    self.assertEqual(shell_status, 200)
                    self.assertEqual(shell_type, "text/javascript")
                    self.assertIn(b"FIX660_GRAIN_STUDIO", shell_body)

                    with opener.open(
                        f"http://127.0.0.1:{port}/tool-a/styles/tool-a.bundle.css", timeout=10,
                    ) as response:
                        style_status = response.status
                        style_type = response.headers.get_content_type()
                        style_body = response.read()
                    self.assertEqual(style_status, 200)
                    self.assertEqual(style_type, "text/css")
                    self.assertIn(b":root", style_body)

                    with opener.open(
                        f"http://127.0.0.1:{port}/tool-a/runtime/classic-runtime.bundle.js",
                        timeout=10,
                    ) as response:
                        runtime_status = response.status
                        runtime_type = response.headers.get_content_type()
                        runtime_body = response.read()
                    self.assertEqual(runtime_status, 200)
                    self.assertEqual(runtime_type, "text/javascript")
                    self.assertIn(b"R9RC1 generated classic compatibility bundle", runtime_body)

                    head_request = Request(
                        f"http://127.0.0.1:{port}/tool-a/bootstrap.js",
                        method="HEAD",
                    )
                    with opener.open(head_request, timeout=10) as response:
                        self.assertEqual(response.status, 200)
                        self.assertEqual(response.headers.get_content_type(), "text/javascript")
                        self.assertEqual(response.read(), b"")

                    options_request = Request(
                        f"http://127.0.0.1:{port}/r9l4-options-wildcard",
                        method="OPTIONS",
                    )
                    with opener.open(options_request, timeout=10) as response:
                        self.assertEqual(response.status, 204)
                        self.assertEqual(response.headers.get("X-Frame-Options"), "DENY")
                        self.assertEqual(response.read(), b"")

                    for denied_static in (
                        "/server_py.py",
                        "/config/pricing.json",
                        "/assets/.secret.svg",
                        "/assets/%2e%2e/toolA.html",
                        "/tool-a/unknown.js",
                        "/tool-a/styles/tokens.css",
                        "/tool-a/shell/script-06-legacy-application-runtime.js",
                    ):
                        with self.assertRaises(HTTPError) as denied_error:
                            opener.open(
                                f"http://127.0.0.1:{port}{denied_static}",
                                timeout=10,
                            )
                        self.assertEqual(denied_error.exception.code, 404, denied_static)
                        self.assertEqual(
                            denied_error.exception.headers.get("X-Content-Type-Options"),
                            "nosniff",
                            denied_static,
                        )
                        denied_error.exception.close()

                    with opener.open(f"http://127.0.0.1:{port}/api/materials/library", timeout=10) as response:
                        catalog_status = response.status
                        catalog_body = response.read()
                    self.assertEqual(catalog_status, 200)
                    catalog = json.loads(catalog_body)
                    self.assertNotIn("staleR8E", catalog)
                    self.assertEqual(catalog.get("count"), 1)
                    material = catalog["records"][0]
                    self.assertTrue(material.get("imageAvailable"))
                    image_url = str(material.get("imageThumbUrl") or "")
                    self.assertIn(f"/api/materials/image/{TEST_PUBLIC_ID}/catalog", image_url)

                    with opener.open(f"http://127.0.0.1:{port}{image_url}", timeout=10) as response:
                        image_status = response.status
                        image_type = response.headers.get_content_type()
                        image_body = response.read()
                    self.assertEqual(image_status, 200)
                    self.assertEqual(image_type, "image/jpeg")
                    self.assertEqual(image_body, expected_image)

                    with opener.open(f"http://127.0.0.1:{port}/admin/", timeout=10) as response:
                        anonymous_admin_status = response.status
                        anonymous_admin_type = response.headers.get("Content-Type")
                        anonymous_admin_cache = response.headers.get("Cache-Control")
                        anonymous_admin_frame = response.headers.get("X-Frame-Options")
                        anonymous_admin_body = response.read()
                    self.assertEqual(anonymous_admin_status, 200)
                    self.assertEqual(anonymous_admin_type, "text/html; charset=utf-8")
                    self.assertEqual(anonymous_admin_cache, "no-store, no-cache, must-revalidate, max-age=0")
                    self.assertEqual(anonymous_admin_frame, "DENY")
                    self.assertEqual(
                        normalized_admin_html_sha256(anonymous_admin_body),
                        R9RC1_ADMIN_LOGIN_HTML_SHA256,
                    )

                    for login_asset in ("/admin/assets/login.css", "/admin/assets/login.js"):
                        with opener.open(f"http://127.0.0.1:{port}{login_asset}", timeout=10) as response:
                            self.assertEqual(response.status, 200, login_asset)
                            self.assertEqual(
                                response.headers.get_content_type(),
                                "text/css" if login_asset.endswith(".css") else "text/javascript",
                                login_asset,
                            )
                            self.assertEqual(
                                hashlib.sha256(response.read()).hexdigest(),
                                R9M_ADMIN_ASSET_SHA256[login_asset],
                                login_asset,
                            )

                    for protected_asset in (
                        "/admin/assets/admin.css",
                        "/admin/assets/admin.js",
                        "/admin/assets/dxf.js",
                    ):
                        for method in ("GET", "HEAD"):
                            request = Request(
                                f"http://127.0.0.1:{port}{protected_asset}", method=method
                            )
                            with self.assertRaises(HTTPError) as protected_error:
                                opener.open(request, timeout=10)
                            self.assertEqual(protected_error.exception.code, 404, (protected_asset, method))
                            protected_error.exception.close()

                    for protected_path in (
                        "/api/admin/metrics",
                        "/api/admin/system/logs",
                        "/api/admin/requests",
                        f"/api/admin/request_files?requestId={R9K3_REQUEST_NEW}",
                        f"/api/admin/request_file?requestId={R9K3_REQUEST_NEW}&jobId={R9L3_EXPORT_JOB}&rel={R9L3_EXPORT_REL}",
                        f"/api/admin/request_download_zip?requestId={R9K3_REQUEST_NEW}&scope=dxf",
                    ):
                        protected_request = Request(
                            f"http://127.0.0.1:{port}{protected_path}",
                            method="GET",
                        )
                        with self.assertRaises(HTTPError) as protected_error:
                            opener.open(protected_request, timeout=10)
                        self.assertEqual(protected_error.exception.code, 401, protected_path)
                        protected_error.exception.close()

                    login_request = Request(
                        f"http://127.0.0.1:{port}/api/admin/login",
                        data=json.dumps({"username": "admin", "password": TEST_PASSWORD, "otp": ""}).encode(),
                        headers={"Content-Type": "application/json", "Origin": f"http://127.0.0.1:{port}"},
                        method="POST",
                    )
                    try:
                        with opener.open(login_request, timeout=10) as response:
                            login_status = response.status
                            login_set_cookie = str(response.headers.get("Set-Cookie") or "")
                            login_cookie = login_set_cookie.split(";", 1)[0]
                            login_body = json.loads(response.read())
                    except HTTPError as exc:
                        try:
                            login_error_body = exc.read().decode("utf-8", errors="replace")
                        finally:
                            exc.close()
                        self.fail(f"adminlogin gaf HTTP {exc.code}: {login_error_body}")
                    self.assertEqual(login_status, 200)
                    self.assertTrue(login_body.get("ok"))
                    self.assertTrue(login_cookie.startswith("adzaagt_admin_session="))
                    self.assertRegex(
                        login_set_cookie,
                        r"^adzaagt_admin_session=[A-Za-z0-9_-]+; Path=/; SameSite=Strict; "
                        r"HttpOnly; Max-Age=28800$",
                    )
                    self.assertEqual(set(login_body), {"ok", "expiresAt", "actor"})
                    self.assertEqual(login_body["actor"], "admin")

                    authenticated_admin_request = Request(
                        f"http://127.0.0.1:{port}/admin/",
                        headers={"Cookie": login_cookie},
                        method="GET",
                    )
                    with opener.open(authenticated_admin_request, timeout=10) as response:
                        authenticated_admin_status = response.status
                        authenticated_admin_body = response.read()
                    self.assertEqual(authenticated_admin_status, 200)
                    self.assertEqual(
                        normalized_admin_html_sha256(authenticated_admin_body),
                        R9M_ADMIN_HTML_SHA256,
                    )

                    for protected_asset in (
                        "/admin/assets/admin.css",
                        "/admin/assets/admin.js",
                        "/admin/assets/dxf.js",
                    ):
                        asset_request = Request(
                            f"http://127.0.0.1:{port}{protected_asset}",
                            headers={"Cookie": login_cookie},
                            method="GET",
                        )
                        with opener.open(asset_request, timeout=10) as response:
                            asset_body = response.read()
                            self.assertEqual(response.status, 200, protected_asset)
                            self.assertEqual(
                                response.headers.get_content_type(),
                                "text/css" if protected_asset.endswith(".css") else "text/javascript",
                                protected_asset,
                            )
                            self.assertEqual(
                                hashlib.sha256(asset_body).hexdigest(),
                                R9M_ADMIN_ASSET_SHA256[protected_asset],
                                protected_asset,
                            )
                        head_request = Request(
                            f"http://127.0.0.1:{port}{protected_asset}",
                            headers={"Cookie": login_cookie},
                            method="HEAD",
                        )
                        with opener.open(head_request, timeout=10) as response:
                            self.assertEqual(response.status, 200, protected_asset)
                            self.assertEqual(response.read(), b"", protected_asset)
                            self.assertEqual(
                                response.headers.get_all("Cache-Control"),
                                ["no-store, no-cache, must-revalidate, max-age=0"],
                                protected_asset,
                            )
                            self.assertEqual(
                                response.headers.get_all("X-Content-Type-Options"),
                                ["nosniff"],
                                protected_asset,
                            )
                            self.assertEqual(
                                int(response.headers.get("Content-Length") or -1),
                                len(asset_body),
                                protected_asset,
                            )

                    r9k3_admin_requests = []
                    for query in ("limit=500", "limit=1", "limit=not-an-int"):
                        admin_requests_request = Request(
                            f"http://127.0.0.1:{port}/api/admin/requests?{query}",
                            headers={"Cookie": login_cookie},
                            method="GET",
                        )
                        with opener.open(admin_requests_request, timeout=10) as response:
                            self.assertEqual(response.status, 200)
                            r9k3_admin_requests.append(json.loads(response.read()))
                    expected_rows = [
                        {
                            "createdAt": "2026-02-01T10:00:00",
                            "customer": {"name": "Nieuw"},
                            "job": {"parentJobId": R9L3_EXPORT_JOB, "subjobs": []},
                            "requestId": R9K3_REQUEST_NEW,
                        },
                        {
                            "createdAt": "2026-01-01T10:00:00",
                            "customer": {"name": "Oud"},
                            "privateMarker": "kept",
                            "requestId": R9K3_REQUEST_OLD,
                        },
                    ]
                    self.assertEqual(r9k3_admin_requests[0], {"ok": True, "requests": expected_rows})
                    self.assertEqual(r9k3_admin_requests[1], {"ok": True, "requests": expected_rows[:1]})
                    self.assertEqual(r9k3_admin_requests[2], {"ok": True, "requests": expected_rows})
                    for body in r9k3_admin_requests:
                        request_ids = {str(row.get("requestId") or "") for row in body["requests"]}
                        self.assertNotIn(R9K3_JOB_ONLY_REQUEST_ID, request_ids)

                    manifest_request = Request(
                        f"http://127.0.0.1:{port}/api/admin/request_files?requestId={R9K3_REQUEST_NEW}",
                        headers={"Cookie": login_cookie},
                        method="GET",
                    )
                    with opener.open(manifest_request, timeout=10) as response:
                        self.assertEqual(response.status, 200)
                        manifest_response = json.loads(response.read())
                    self.assertTrue(manifest_response["ok"])
                    manifest = manifest_response["files"]
                    self.assertEqual(manifest["parentJobId"], R9L3_EXPORT_JOB)
                    self.assertEqual(len(manifest["allFiles"]), 1)
                    linked = manifest["allFiles"][0]
                    self.assertEqual(linked["rel"], R9L3_EXPORT_REL)
                    self.assertEqual(linked["kind"], "dxf")
                    self.assertTrue(str(linked.get("downloadName") or "").endswith(".dxf"))

                    linked_request = Request(
                        f"http://127.0.0.1:{port}{linked['url']}",
                        headers={"Cookie": login_cookie},
                        method="GET",
                    )
                    with opener.open(linked_request, timeout=10) as response:
                        self.assertEqual(response.status, 200)
                        self.assertEqual(response.headers.get_content_type(), "application/dxf")
                        self.assertIn("attachment;", str(response.headers.get("Content-Disposition") or ""))
                        self.assertEqual(response.read(), R9L3_EXPORT_BYTES)

                    zip_request = Request(
                        f"http://127.0.0.1:{port}{manifest['zip']['allDxfUrl']}",
                        headers={"Cookie": login_cookie},
                        method="GET",
                    )
                    with opener.open(zip_request, timeout=10) as response:
                        self.assertEqual(response.status, 200)
                        self.assertEqual(response.headers.get_content_type(), "application/zip")
                        self.assertIn(
                            f'filename="{R9K3_REQUEST_NEW}_dxf.zip"',
                            str(response.headers.get("Content-Disposition") or ""),
                        )
                        zip_body = response.read()
                    with zipfile.ZipFile(io.BytesIO(zip_body), "r") as archive:
                        self.assertEqual(len(archive.namelist()), 1)
                        member_name = archive.namelist()[0]
                        self.assertTrue(member_name.endswith(".dxf"))
                        self.assertEqual(archive.read(member_name), R9L3_EXPORT_BYTES)

                    material_state_before = (state_root / "material_library.json").read_bytes()
                    media_state_before = sorted(
                        (
                            path.relative_to(state_root / "decor_media").as_posix(),
                            hashlib.sha256(path.read_bytes()).hexdigest(),
                        )
                        for path in (state_root / "decor_media").rglob("*")
                        if path.is_file()
                    )
                    for deprecated_route in R9K2_DEPRECATED_MATERIAL_ROUTES:
                        deprecated_request = Request(
                            f"http://127.0.0.1:{port}{deprecated_route}",
                            data=b"not-json-and-must-not-be-read",
                            headers={
                                "Content-Type": "application/json",
                                "Cookie": login_cookie,
                                "Origin": f"http://127.0.0.1:{port}",
                                "X-Requested-With": "fetch",
                            },
                            method="POST",
                        )
                        try:
                            with opener.open(deprecated_request, timeout=10) as response:
                                deprecated_status = response.status
                                deprecated_type = response.headers.get("Content-Type")
                                deprecated_length = response.headers.get("Content-Length")
                                deprecated_body = response.read()
                        except HTTPError as exc:
                            deprecated_status = exc.code
                            deprecated_type = exc.headers.get("Content-Type")
                            deprecated_length = exc.headers.get("Content-Length")
                            try:
                                deprecated_body = exc.read()
                            finally:
                                exc.close()
                        self.assertEqual(deprecated_status, 410, deprecated_route)
                        self.assertEqual(deprecated_type, "application/json; charset=utf-8", deprecated_route)
                        self.assertEqual(deprecated_length, "115", deprecated_route)
                        self.assertEqual(deprecated_body, R9K2_DEPRECATED_RESPONSE_BODY, deprecated_route)
                        self.assertEqual(
                            hashlib.sha256(deprecated_body).hexdigest(),
                            R9K2_DEPRECATED_RESPONSE_SHA256,
                            deprecated_route,
                        )
                        self.assertEqual(
                            json.loads(deprecated_body),
                            {
                                "ok": False,
                                "error": "FIX652: actieve Decor Library wordt uitsluitend via CSV controleren + publiceren beheerd.",
                            },
                            deprecated_route,
                        )
                    self.assertEqual((state_root / "material_library.json").read_bytes(), material_state_before)
                    media_state_after = sorted(
                        (
                            path.relative_to(state_root / "decor_media").as_posix(),
                            hashlib.sha256(path.read_bytes()).hexdigest(),
                        )
                        for path in (state_root / "decor_media").rglob("*")
                        if path.is_file()
                    )
                    self.assertEqual(media_state_after, media_state_before)

                    admin_ready_request = Request(
                        f"http://127.0.0.1:{port}/api/admin/health/ready",
                        headers={"Cookie": login_cookie},
                        method="GET",
                    )
                    try:
                        with opener.open(admin_ready_request, timeout=10) as response:
                            admin_ready_status = response.status
                            admin_ready_body = response.read()
                    except HTTPError as exc:
                        admin_ready_status = exc.code
                        try:
                            admin_ready_body = exc.read()
                        finally:
                            exc.close()
                    self.assertIn(admin_ready_status, {200, 503})
                    admin_ready = json.loads(admin_ready_body)
                    self.assertEqual(admin_ready.get("build"), EXPECTED_BUILD)
                    self.assertIsInstance(admin_ready.get("checks"), dict)
                    self.assertIsInstance(admin_ready.get("details"), dict)

                    metrics_request = Request(
                        f"http://127.0.0.1:{port}/api/admin/metrics",
                        headers={"Cookie": login_cookie},
                        method="GET",
                    )
                    with opener.open(metrics_request, timeout=10) as response:
                        self.assertEqual(response.status, 200)
                        self.assertEqual(
                            response.headers.get("Content-Type"),
                            "text/plain; version=0.0.4; charset=utf-8",
                        )
                        metrics_text = response.read().decode("utf-8")
                    for gauge in R9L2_PROMETHEUS_GAUGES:
                        self.assertEqual(metrics_text.count(f"# TYPE {gauge} gauge\n"), 1, gauge)
                        self.assertRegex(metrics_text, rf"(?m)^{re.escape(gauge)} [0-9]+$")

                    logs_request = Request(
                        f"http://127.0.0.1:{port}/api/admin/system/logs",
                        headers={"Cookie": login_cookie},
                        method="GET",
                    )
                    with opener.open(logs_request, timeout=10) as response:
                        self.assertEqual(response.status, 200)
                        logs_payload = json.loads(response.read())
                    self.assertTrue(logs_payload.get("ok"))
                    self.assertIsInstance(logs_payload.get("items"), list)
                    self.assertEqual(logs_payload.get("count"), len(logs_payload["items"]))
                    for event in logs_payload["items"]:
                        self.assertIsInstance(event, dict)
                        self.assertFalse(event.get("customerName"))

                    preview_request = Request(
                        f"http://127.0.0.1:{port}/api/admin/materials/catalog_preview",
                        data=json.dumps({"csvText": preview_csv_text()}).encode(),
                        headers={
                            "Content-Type": "application/json",
                            "Cookie": login_cookie,
                            "Origin": f"http://127.0.0.1:{port}",
                            "X-Requested-With": "fetch",
                        },
                        method="POST",
                    )
                    with opener.open(preview_request, timeout=20) as response:
                        preview_status = response.status
                        preview = json.loads(response.read())
                    self.assertEqual(preview_status, 200)
                    self.assertTrue(preview.get("ok"))
                    self.assertEqual(preview.get("summary", {}).get("eligible"), 1)
                    self.assertRegex(str(preview.get("reviewSha256") or ""), r"^[a-f0-9]{64}$")

                    logout_request = Request(
                        f"http://127.0.0.1:{port}/api/admin/logout",
                        data=b"{}",
                        headers={
                            "Content-Type": "application/json",
                            "Cookie": login_cookie,
                            "Origin": f"http://127.0.0.1:{port}",
                        },
                        method="POST",
                    )
                    with opener.open(logout_request, timeout=10) as response:
                        logout_status = response.status
                        logout_type = response.headers.get("Content-Type")
                        logout_cookie = response.headers.get("Set-Cookie")
                        logout_body = response.read()
                    self.assertEqual(logout_status, 200)
                    self.assertEqual(logout_type, "application/json; charset=utf-8")
                    self.assertEqual(logout_body, b'{"ok":true}')
                    self.assertEqual(
                        logout_cookie,
                        "adzaagt_admin_session=; Path=/; SameSite=Strict; HttpOnly; Max-Age=0",
                    )

                    revoked_admin_request = Request(
                        f"http://127.0.0.1:{port}/admin/",
                        headers={"Cookie": login_cookie},
                        method="GET",
                    )
                    with opener.open(revoked_admin_request, timeout=10) as response:
                        revoked_admin_body = response.read()
                    self.assertEqual(
                        normalized_admin_html_sha256(revoked_admin_body),
                        R9RC1_ADMIN_LOGIN_HTML_SHA256,
                    )
                finally:
                    process.terminate()
                    try:
                        process.wait(timeout=10)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait(timeout=10)


if __name__ == "__main__":
    unittest.main(verbosity=2)
