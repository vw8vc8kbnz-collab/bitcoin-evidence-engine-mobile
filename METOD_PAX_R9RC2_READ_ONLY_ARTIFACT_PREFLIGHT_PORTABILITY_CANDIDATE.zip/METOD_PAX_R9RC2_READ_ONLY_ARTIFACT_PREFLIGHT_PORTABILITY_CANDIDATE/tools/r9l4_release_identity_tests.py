#!/usr/bin/env python3
from __future__ import annotations

"""Executable contracts for the R9L4 canonical release identity boundary."""

import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from r9l4_release_identity_gate import (
    ARTIFACT,
    ARTIFACT_ROOT,
    BUILD,
    COMPONENT_REVISION,
    COMPATIBILITY_BUILD,
    GOLDEN_REVISION,
    REVISION,
    STATUS,
    audit_release,
    sbom_properties,
)


ROOT = Path(__file__).resolve().parents[1]


@unittest.skipUnless(
    json.loads((ROOT / "RELEASE_IDENTITY.json").read_text(encoding="utf-8"))["canonicalCandidate"]["releaseRevision"] == REVISION,
    "R9L4 identity gate is historical after a newer canonical checkpoint",
)
class R9L4ReleaseIdentityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.identity = json.loads((ROOT / "RELEASE_IDENTITY.json").read_text(encoding="utf-8"))
        cls.runtime = json.loads((ROOT / "RUNTIME_CONTRACT.json").read_text(encoding="utf-8"))
        cls.sbom = json.loads((ROOT / "SBOM.cdx.json").read_text(encoding="utf-8"))

    def test_01_complete_gate_passes(self) -> None:
        report = audit_release(ROOT)
        self.assertEqual(report["status"], "PASS", report["failures"])

    def test_02_candidate_identity_is_explicitly_provisional(self) -> None:
        candidate = self.identity["canonicalCandidate"]
        self.assertEqual(candidate["releaseRevision"], REVISION)
        self.assertEqual(candidate["buildId"], BUILD)
        self.assertEqual(candidate["status"], STATUS)
        self.assertFalse(candidate["releaseEligible"])
        self.assertFalse(self.identity["externalEvidence"]["productionGo"])

    def test_03_artifact_filename_and_root_are_unique_and_canonical(self) -> None:
        candidate = self.identity["canonicalCandidate"]
        self.assertEqual(candidate["artifactName"], ARTIFACT)
        self.assertEqual(candidate["artifactRootDirectory"], ARTIFACT_ROOT)
        self.assertNotEqual(candidate["artifactName"], self.identity["immutableGoldenBaseline"]["artifactName"])

    def test_04_golden_and_compatibility_roles_are_not_current_release(self) -> None:
        golden = self.identity["immutableGoldenBaseline"]
        application = self.identity["application"]
        self.assertEqual(golden["releaseRevision"], GOLDEN_REVISION)
        self.assertEqual(golden["role"], "behavior-oracle-only")
        self.assertEqual(application["runtimeCompatibilityBuild"], COMPATIBILITY_BUILD)
        self.assertNotEqual(REVISION, GOLDEN_REVISION)
        self.assertNotEqual(BUILD, COMPATIBILITY_BUILD)

    def test_05_application_component_revision_remains_separate(self) -> None:
        self.assertEqual(self.identity["application"]["componentRevision"], COMPONENT_REVISION)
        bootstrap = (ROOT / "app/tool-a/bootstrap.js").read_text(encoding="utf-8")
        self.assertIn(f'"{COMPONENT_REVISION}"', bootstrap)
        self.assertNotIn(f'"{BUILD}"', bootstrap)

    def test_06_runtime_contract_and_sbom_mirror_canonical_candidate(self) -> None:
        candidate = self.identity["canonicalCandidate"]
        self.assertEqual(self.runtime["releaseRevision"], candidate["releaseRevision"])
        self.assertEqual(self.runtime["build"], candidate["buildId"])
        self.assertEqual(self.runtime["artifactName"], candidate["artifactName"])
        self.assertEqual(self.runtime["artifactRootDirectory"], candidate["artifactRootDirectory"])
        properties = sbom_properties(self.sbom)
        self.assertEqual(properties["releaseRevision"], candidate["releaseRevision"])
        self.assertEqual(properties["artifactName"], candidate["artifactName"])
        self.assertEqual(properties["runtimeCompatibilityBuild"], COMPATIBILITY_BUILD)

    def test_07_public_metadata_never_calls_r8z_the_current_release(self) -> None:
        html = (ROOT / "app/toolA.html").read_text(encoding="utf-8")
        self.assertIn(f'name="metod-release-revision" content="{REVISION}"', html)
        self.assertIn(f'name="metod-golden-baseline" content="{GOLDEN_REVISION}"', html)
        self.assertNotIn('name="metod-release-revision" content="R8Z"', html)

    def test_08_builder_rejects_a_noncanonical_artifact_name_before_building(self) -> None:
        with tempfile.TemporaryDirectory(prefix="r9l4_identity_name_") as temporary:
            completed = subprocess.run(
                [
                    sys.executable,
                    "-B",
                    str(ROOT / "tools/build_release_artifact.py"),
                    "--output",
                    str(Path(temporary) / "ambiguous.zip"),
                ],
                cwd=ROOT,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                timeout=10,
                check=False,
            )
        self.assertNotEqual(completed.returncode, 0)
        self.assertIn(f"artifact name must be canonical: {ARTIFACT}", completed.stdout)


if __name__ == "__main__":
    unittest.main(verbosity=2)
