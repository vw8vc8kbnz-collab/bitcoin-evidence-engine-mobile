#!/usr/bin/env python3
from __future__ import annotations

"""Shared fail-closed file identity checks for standalone R9J audit tests."""

import hashlib
import json
from pathlib import Path
from typing import Any


CONTRACT_NAME = "R9J1_HERMETIC_AUDIT_REFERENCE.json"


def load_reference(root: Path) -> dict[str, Any]:
    path = root / CONTRACT_NAME
    value = json.loads(path.read_text(encoding="utf-8", errors="strict"))
    if not isinstance(value, dict) or value.get("schemaVersion") != 1:
        raise AssertionError(f"invalid hermetic reference schema: {path}")
    if value.get("contractId") != "R9J1_HERMETIC_AUDIT_REFERENCE":
        raise AssertionError(f"invalid hermetic reference identity: {path}")
    files = value.get("files")
    if not isinstance(files, dict) or not files:
        raise AssertionError(f"empty hermetic file reference: {path}")
    return value


def sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def assert_sealed_file(testcase: Any, root: Path, reference: dict[str, Any], relative: str) -> bytes:
    entry = reference["files"].get(relative)
    testcase.assertIsInstance(entry, dict, f"missing sealed identity: {relative}")
    path = root / relative
    testcase.assertTrue(path.is_file(), relative)
    payload = path.read_bytes()
    testcase.assertEqual(len(payload), entry.get("bytes"), f"byte size: {relative}")
    testcase.assertEqual(len(payload.splitlines()), entry.get("lines"), f"line count: {relative}")
    testcase.assertEqual(sha256_bytes(payload), entry.get("sha256"), f"sha256: {relative}")
    return payload
