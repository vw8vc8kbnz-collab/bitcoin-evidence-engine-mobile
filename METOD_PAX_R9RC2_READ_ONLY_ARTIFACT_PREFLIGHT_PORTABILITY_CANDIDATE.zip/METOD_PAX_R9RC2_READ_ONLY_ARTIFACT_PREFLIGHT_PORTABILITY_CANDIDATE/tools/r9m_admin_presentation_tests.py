#!/usr/bin/env python3
from __future__ import annotations

"""Executable R9M contracts for the professional Admin presentation split."""

import ast
import hashlib
import json
import re
import subprocess
import sys
import unittest
from pathlib import Path
from types import MappingProxyType


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
ADMIN = APP / "metod_app/admin"
TEMPLATES = ADMIN / "templates"
ASSETS = ADMIN / "assets"
PRESENTATION = ADMIN / "presentation.py"
ACCESS = ADMIN / "access.py"
SERVER = APP / "server_py.py"
BEFORE = ROOT / "R9M_ADMIN_PRESENTATION_BEFORE_FIXTURE.json"
SCOPE = ROOT / "R9M_ADMIN_HTML_CSS_JAVASCRIPT_PROFESSIONAL_SPLIT_SCOPE.json"
sys.path.insert(0, str(APP))

from metod_app.admin.presentation import (  # noqa: E402
    ADMIN_ASSETS,
    ADMIN_HTML,
    ADMIN_LOGIN_HTML,
    admin_asset_for_path,
)
from metod_app.http.matcher import match_route  # noqa: E402
from metod_app.http.routes import ROUTES  # noqa: E402


ASSET_SHA256 = {
    "admin.css": "7a6204cce598b9fa0d985a78156948f58caff7114ccf5ac60c30c48ad8961a28",
    "admin.js": "141e71f2f0de57da6b40063283ae281348844c127f10f795744356afe3bb4745",
    "dxf.js": "8fa36fd05f36519fdc731d758f33b38a1a4001434ae0bf755a326428901dc481",
    "login.css": "aefb17e04655795803caa55d0f12f350832f8096031431d3e42d8e09be728955",
    "login.js": "a32aa7d111b2e891a72b21f79ff15db3a1d332af0d5affe97c753768ff38fcc5",
}
TEMPLATE_SHA256 = {
    "admin.html": "bc92febb40e7817ee0cccdd2c85b33affcd3c9e8f021e0d79d2a0810e0e94b22",
    "login.html": "ca8da83a996ae0e800e541754f415915f5431cad689da5de3c9ba0199f7b014c",
}


def digest(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def ordered_unique(values: list[str]) -> list[str]:
    return list(dict.fromkeys(values))


def functions(scripts: list[str]) -> list[str]:
    result: list[str] = []
    for script in scripts:
        result.extend(
            match.group(1) or match.group(2)
            for match in re.finditer(
                r"(?m)^\s*(?:async\s+)?function\s+([A-Za-z_$][\w$]*)"
                r"|^\s*window\.([A-Za-z_$][\w$]*)\s*=\s*(?:async\s+)?function",
                script,
            )
        )
    return result


class R9MAdminPresentationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.before = json.loads(BEFORE.read_text(encoding="utf-8"))
        cls.scope = json.loads(SCOPE.read_text(encoding="utf-8"))
        cls.admin_html = (TEMPLATES / "admin.html").read_text(encoding="utf-8")
        cls.login_html = (TEMPLATES / "login.html").read_text(encoding="utf-8")
        cls.dxf_js = (ASSETS / "dxf.js").read_text(encoding="utf-8")
        cls.admin_js = (ASSETS / "admin.js").read_text(encoding="utf-8")
        cls.login_js = (ASSETS / "login.js").read_text(encoding="utf-8")

    def test_01_before_fixture_is_exactly_bound_to_r9l5(self) -> None:
        self.assertEqual(self.before["contractId"], "R9M_ADMIN_PRESENTATION_BEFORE_FIXTURE")
        self.assertEqual(self.before["sourceCommit"], "9d3fedcb5cdc1a7ed4428fe67734780c9082f678")
        self.assertEqual(self.before["presentations"]["ADMIN_HTML"]["styleAttributeCount"], 209)
        self.assertEqual(self.before["presentations"]["ADMIN_HTML"]["scriptElementCount"], 2)
        self.assertEqual(self.before["presentations"]["ADMIN_LOGIN_HTML"]["scriptElementCount"], 1)

    def test_02_templates_and_assets_are_exact_and_have_one_runtime_owner(self) -> None:
        for name, expected in TEMPLATE_SHA256.items():
            self.assertEqual(digest((TEMPLATES / name).read_bytes()), expected, name)
        for name, expected in ASSET_SHA256.items():
            self.assertEqual(digest((ASSETS / name).read_bytes()), expected, name)
        self.assertEqual(ADMIN_HTML, self.admin_html)
        self.assertEqual(ADMIN_LOGIN_HTML, self.login_html)
        self.assertIsInstance(ADMIN_ASSETS, MappingProxyType)
        with self.assertRaises(TypeError):
            ADMIN_ASSETS["/admin/assets/extra.js"] = next(iter(ADMIN_ASSETS.values()))  # type: ignore[index]
        access_source = ACCESS.read_text(encoding="utf-8")
        self.assertNotRegex(access_source, r"(?m)^(?:ADMIN_HTML|ADMIN_LOGIN_HTML)\s*=")
        self.assertIn("from .presentation import ADMIN_HTML, ADMIN_LOGIN_HTML", access_source)

    def test_03_templates_have_no_inline_presentation_or_remote_dependency(self) -> None:
        for name, html in (("admin", self.admin_html), ("login", self.login_html)):
            self.assertNotRegex(html, r"(?i)<style\b", name)
            self.assertNotRegex(html, r"(?i)\sstyle\s*=", name)
            self.assertNotRegex(html, r"(?i)\son[a-z]+\s*=", name)
            self.assertNotRegex(html, r'(?i)(?:href|src)="(?:https?:)?//', name)
            for attributes, body in re.findall(r"<script\b([^>]*)>(.*?)</script>", html, re.I | re.S):
                self.assertFalse(body.strip(), name)
                self.assertRegex(attributes, r'\bsrc="/admin/assets/[^"]+"', name)
        for script in (self.dxf_js, self.admin_js, self.login_js):
            self.assertNotRegex(script, r"(?i)\sstyle\s*=")
            self.assertNotRegex(script, r"(?i)\son[a-z]+\s*=")

    def test_04_dom_api_and_action_contracts_are_preserved(self) -> None:
        before = self.before["presentations"]["ADMIN_HTML"]
        combined = "\n".join((self.admin_html, self.dxf_js, self.admin_js))
        ids = ordered_unique(re.findall(r'\bid=["\']([^"\']+)["\']', combined, re.I))
        self.assertEqual(ids, before["domIds"])
        self.assertEqual(digest("\n".join(ids).encode()), before["domIdsSha256"])
        self.assertEqual(
            sorted(set(re.findall(r"/api/[A-Za-z0-9_{}?=&./-]+", combined))),
            before["apiLiteralPaths"],
        )
        self.assertEqual(
            sorted(set(re.findall(r'data-admin-action=["\']([^"\']+)', combined))),
            before["dataAdminActions"],
        )
        login_combined = self.login_html + "\n" + self.login_js
        login_before = self.before["presentations"]["ADMIN_LOGIN_HTML"]
        self.assertEqual(
            sorted(set(re.findall(r"/api/[A-Za-z0-9_{}?=&./-]+", login_combined))),
            login_before["apiLiteralPaths"],
        )

    def test_05_javascript_inventory_is_preserved_with_one_reviewed_tone_rename(self) -> None:
        expected = list(self.before["presentations"]["ADMIN_HTML"]["functionNames"])
        expected[expected.index("_systemTone")] = "_systemToneClass"
        self.assertEqual(functions([self.dxf_js, self.admin_js]), expected)
        self.assertEqual(functions([self.login_js]), ["setMsg"])
        self.assertIn("progressValue.style.width=`${pct}%`", self.admin_js)
        self.assertEqual(self.admin_js.count("progressValue.style.width"), 1)
        self.assertEqual(re.findall(r"\.style\.[A-Za-z_$][\w$]*", self.admin_js), [".style.width"])
        for name in ("dxf.js", "admin.js", "login.js"):
            completed = subprocess.run(
                ["node", "--check", str(ASSETS / name)],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                check=False,
            )
            self.assertEqual(completed.returncode, 0, completed.stdout)

    def test_06_original_stylesheets_and_all_migrated_declarations_are_sealed(self) -> None:
        admin_css = (ASSETS / "admin.css").read_bytes()
        original = self.before["presentations"]["ADMIN_HTML"]["styleBlocks"][0]
        self.assertEqual(digest(admin_css[: original["bytes"]]), original["sha256"])
        login_original = self.before["presentations"]["ADMIN_LOGIN_HTML"]["styleBlocks"][0]
        self.assertEqual(digest((ASSETS / "login.css").read_bytes()), login_original["sha256"])
        css_classes = set(re.findall(rb"\.admin-u-(\d{3})\{", admin_css))
        rendered_classes = set(
            re.findall(rb"admin-u-(\d{3})", (self.admin_html + self.admin_js + self.dxf_js).encode())
        )
        self.assertEqual(len(css_classes), 154)
        self.assertEqual(rendered_classes, css_classes)
        self.assertIn(b".systemToneError{background:rgba(255,107,107,.14)}", admin_css)
        self.assertIn(b".catalogProgressValue{height:100%;width:0", admin_css)

    def test_07_asset_allowlist_and_session_policy_are_exact(self) -> None:
        expected = {
            "/admin/assets/admin.css": ("text/css; charset=utf-8", True),
            "/admin/assets/admin.js": ("text/javascript; charset=utf-8", True),
            "/admin/assets/dxf.js": ("text/javascript; charset=utf-8", True),
            "/admin/assets/login.css": ("text/css; charset=utf-8", False),
            "/admin/assets/login.js": ("text/javascript; charset=utf-8", False),
        }
        self.assertEqual(set(ADMIN_ASSETS), set(expected))
        for path, contract in expected.items():
            asset = admin_asset_for_path(path)
            self.assertIsNotNone(asset)
            self.assertEqual((asset.content_type, asset.requires_session), contract)
            self.assertEqual(match_route("GET", path).route.pattern, path)
            self.assertEqual(match_route("HEAD", path).route.pattern, path)
        self.assertIsNone(admin_asset_for_path("/admin/assets/../access.py"))
        self.assertIsNone(match_route("GET", "/admin/assets/unknown.js"))

    def test_08_route_catalog_and_dispatch_fail_closed_contract_are_explicit(self) -> None:
        asset_routes = [route for route in ROUTES if route.pattern.startswith("/admin/assets/")]
        self.assertEqual(len(asset_routes), 10)
        self.assertEqual({route.method for route in asset_routes}, {"GET", "HEAD"})
        self.assertEqual(
            {route.access_policy for route in asset_routes},
            {"admin-session-hidden", "public-login-presentation"},
        )
        server = SERVER.read_text(encoding="utf-8")
        self.assertEqual(server.count("admin_asset = admin_asset_for_path(parsed.path)"), 2)
        self.assertEqual(server.count("admin_asset.requires_session and not self._check_admin_auth_silent()"), 2)
        self.assertIn("return self._send_text('Not found', 404)", server)
        self.assertNotIn("# serve admin html", server)

    def test_09_presentation_owner_has_no_filesystem_or_server_dependency(self) -> None:
        tree = ast.parse(PRESENTATION.read_text(encoding="utf-8"))
        imports = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                imports.update(alias.name.split(".", 1)[0] for alias in node.names)
            elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
                imports.add(node.module.split(".", 1)[0])
        self.assertTrue(imports.isdisjoint({"http", "os", "pathlib", "server_py", "socket", "subprocess", "threading"}))
        source = PRESENTATION.read_text(encoding="utf-8")
        for fail_closed_marker in (
            "embedded style element is forbidden",
            "inline style attribute is forbidden",
            "inline event attribute is forbidden",
            "remote presentation dependency is forbidden",
        ):
            self.assertIn(fail_closed_marker, source)

    def test_10_scope_remains_provisional_and_external_gates_remain_no_go(self) -> None:
        self.assertEqual(self.scope["contractId"], "R9M_ADMIN_HTML_CSS_JAVASCRIPT_PROFESSIONAL_SPLIT_SCOPE")
        self.assertEqual(self.scope["status"], "PROVISIONAL_DEVELOPMENT_ONLY")
        self.assertFalse(self.scope["releaseEligible"])
        self.assertFalse(self.scope["productionGo"])
        self.assertIn("candidate VPS, real iPhone Safari or production GO", self.scope["excluded"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
