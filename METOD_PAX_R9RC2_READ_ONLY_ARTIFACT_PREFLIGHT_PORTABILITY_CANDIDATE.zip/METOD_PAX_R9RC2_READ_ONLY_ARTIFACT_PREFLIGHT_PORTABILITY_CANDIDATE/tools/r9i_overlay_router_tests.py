#!/usr/bin/env python3
from __future__ import annotations

"""Fail-closed behavior and ownership proof for the R9I-5 overlay router."""

import base64
import hashlib
import json
import re
import shutil
import subprocess
import unittest
from pathlib import Path

from r9j_hermetic_reference import assert_sealed_file, load_reference


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
COMPONENT = APP / "tool-a/components/overlay-router.js"
BOOTSTRAP = APP / "tool-a/bootstrap.js"
RUNTIME = APP / "tool-a/shell/script-06-legacy-application-runtime.js"
HELPERS = APP / "toolA_safe_helper_layer.js"
RULES = ROOT / "R9B_ARCHITECTURE_RULES.json"
REFERENCE = load_reference(ROOT)


def data_url(path: Path) -> str:
    return "data:text/javascript;base64," + base64.b64encode(path.read_bytes()).decode()


def run_node(source: str) -> dict:
    node = shutil.which("node")
    if not node:
        raise AssertionError("Node is required by the R9I overlay-router gate")
    completed = subprocess.run(
        [node, "--input-type=module"], input=source, text=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=10, check=False,
    )
    if completed.returncode != 0:
        raise AssertionError(completed.stdout)
    return json.loads(completed.stdout.strip().splitlines()[-1])


def fake_dom_probe(actions: str) -> dict:
    return run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});
class FakeHTMLElement {{
  constructor(id){{this.id=id;this.style={{display:'',pointerEvents:''}};this.attrs={{}};}}
  setAttribute(name,value){{this.attrs[name]=String(value);}}
  getAttribute(name){{return this.attrs[name]??null;}}
  closest(selector){{return selector==='.overlay'&&this.isOverlay?this:null;}}
}}
const ids=['overlay','grainOverlay','extraOverlay','overviewOverlay'];
const nodes=Object.fromEntries(ids.map(id=>[id,new FakeHTMLElement(id)]));
const listeners=[];const removed=[];const intervals=[];const cleared=[];let clock=1000;
const documentRef={{body:{{style:{{overflow:'auto'}}}},getElementById:id=>nodes[id]||null,
  addEventListener:(...args)=>listeners.push(args),removeEventListener:(...args)=>removed.push(args)}};
const component=m.createOverlayRouterComponent({{documentRef,htmlElementClass:FakeHTMLElement,now:()=>clock,
  getComputedStyleImpl:el=>({{display:el.style.display||'flex',visibility:el.visibility||'visible',opacity:el.opacity??'1'}}),
  setIntervalImpl:(fn,ms)=>{{const handle=intervals.length+11;intervals.push({{fn,ms,handle}});return handle;}},
  clearIntervalImpl:handle=>cleared.push(handle)}});
{actions}
""")


def function_body(source: str, name: str) -> str:
    match = re.search(
        rf"^  function {re.escape(name)}\([^\n]*\)\{{(?P<body>.*?)^  \}}$",
        source, re.MULTILINE | re.DOTALL,
    )
    if not match:
        raise AssertionError(name)
    return match.group("body")


class R9IOverlayRouterTests(unittest.TestCase):
    def test_01_bind_initializes_exact_visibility_listener_and_watchdogs(self) -> None:
        result = fake_dom_probe("""
component.bind();component.bind();
console.log(JSON.stringify({nodes:Object.fromEntries(ids.map(id=>[id,{display:nodes[id].style.display,
 pointer:nodes[id].style.pointerEvents,hidden:nodes[id].attrs['aria-hidden']}])) ,
 state:component.getState(),listeners:listeners.map(v=>[v[0],v[2]]),
 intervals:intervals.map(v=>[v.ms,v.handle]),frozen:Object.isFrozen(component)}));
""")
        self.assertEqual(result["nodes"], {
            "overlay": {"display": "flex", "pointer": "auto", "hidden": "false"},
            "grainOverlay": {"display": "none", "pointer": "none", "hidden": "true"},
            "extraOverlay": {"display": "none", "pointer": "none", "hidden": "true"},
            "overviewOverlay": {"display": "none", "pointer": "none", "hidden": "true"},
        })
        self.assertEqual(result["state"], {
            "activeOverlayId": "overlay", "ignoreDismissUntil": 1350, "bound": True,
        })
        self.assertEqual(result["listeners"], [["pointerdown", {"capture": True}]])
        self.assertEqual(result["intervals"], [[500, 11], [500, 12]])
        self.assertTrue(result["frozen"])

    def test_02_alias_open_hides_peers_and_preserves_scroll_lock(self) -> None:
        result = fake_dom_probe("""
component.bind();clock=2000;const opened=component.open('grain');const unknown=component.open('price');
console.log(JSON.stringify({opened,unknown,state:component.getState(),overflow:documentRef.body.style.overflow,
 nodes:Object.fromEntries(ids.map(id=>[id,[nodes[id].style.display,nodes[id].style.pointerEvents,nodes[id].attrs['aria-hidden']]]))}));
""")
        self.assertTrue(result["opened"])
        self.assertFalse(result["unknown"])
        self.assertEqual(result["state"], {
            "activeOverlayId": "grainOverlay", "ignoreDismissUntil": 2350, "bound": True,
        })
        self.assertEqual(result["overflow"], "hidden")
        self.assertEqual(result["nodes"]["grainOverlay"], ["flex", "auto", "false"])
        for overlay_id in ("overlay", "extraOverlay", "overviewOverlay"):
            self.assertEqual(result["nodes"][overlay_id], ["none", "none", "true"])

    def test_03_close_alias_and_unknown_target_keep_existing_contract(self) -> None:
        result = fake_dom_probe("""
component.bind();component.open('overview');const closed=component.close('overview');
documentRef.body.style.overflow='sentinel';const unknown=component.close({id:'customerOverlay'});
console.log(JSON.stringify({closed,unknown,state:component.getState(),overflow:documentRef.body.style.overflow,
 display:nodes.overviewOverlay.style.display,hidden:nodes.overviewOverlay.attrs['aria-hidden']}));
""")
        self.assertEqual(result, {
            "closed": True, "unknown": False,
            "state": {"activeOverlayId": None, "ignoreDismissUntil": 1350, "bound": True},
            "overflow": "sentinel", "display": "none", "hidden": "true",
        })

    def test_04_backdrop_dismissal_respects_the_350ms_guard(self) -> None:
        result = fake_dom_probe("""
component.bind();const backdrop=nodes.overlay;backdrop.isOverlay=true;const listener=listeners[0][1];
clock=1200;listener({target:backdrop});const guarded=nodes.overlay.style.display;
clock=1350;listener({target:backdrop});const dismissed=ids.map(id=>nodes[id].style.display);
component.open('extra');clock=2000;const child=new FakeHTMLElement('child');child.closest=()=>nodes.extraOverlay;
listener({target:child});const childClick=nodes.extraOverlay.style.display;
console.log(JSON.stringify({guarded,dismissed,childClick}));
""")
        self.assertEqual(result, {
            "guarded": "flex", "dismissed": ["none", "none", "none", "none"],
            "childClick": "flex",
        })

    def test_05_both_watchdogs_preserve_click_blocker_safety(self) -> None:
        result = fake_dom_probe("""
component.bind();nodes.extraOverlay.style.display='flex';nodes.extraOverlay.attrs['aria-hidden']='true';
intervals[0].fn();const recovered={hidden:nodes.extraOverlay.attrs['aria-hidden'],pointer:nodes.extraOverlay.style.pointerEvents,state:component.getState()};
nodes.extraOverlay.visibility='hidden';nodes.extraOverlay.style.display='flex';intervals[1].fn();
const killed={display:nodes.extraOverlay.style.display,pointer:nodes.extraOverlay.style.pointerEvents,state:component.getState()};
console.log(JSON.stringify({recovered,killed}));
""")
        self.assertEqual(result["recovered"], {
            "hidden": "false", "pointer": "auto",
            "state": {"activeOverlayId": "extraOverlay", "ignoreDismissUntil": 1350, "bound": True},
        })
        self.assertEqual(result["killed"], {
            "display": "none", "pointer": "none",
            "state": {"activeOverlayId": None, "ignoreDismissUntil": 1350, "bound": True},
        })

    def test_06_destroy_removes_one_listener_and_both_timers(self) -> None:
        result = fake_dom_probe("""
component.bind();component.destroy();component.destroy();
console.log(JSON.stringify({removed:removed.map(v=>[v[0],v[2]]),cleared,state:component.getState()}));
""")
        self.assertEqual(result, {
            "removed": [["pointerdown", {"capture": True}]], "cleared": [11, 12],
            "state": {"activeOverlayId": "overlay", "ignoreDismissUntil": 1350, "bound": False},
        })

    def test_07_legacy_runtime_is_thin_and_classic_dom_owner_is_retired(self) -> None:
        runtime = RUNTIME.read_text(encoding="utf-8")
        helpers = HELPERS.read_text(encoding="utf-8")
        self.assertIn("owner.setOverlayVisible(id, visible)", function_body(runtime, "setOverlayVisible"))
        self.assertIn("owner.hideAllOverlays()", function_body(runtime, "hideAllOverlays"))
        self.assertIn("owner.openOverlay(el)", function_body(runtime, "openOverlay"))
        self.assertIn("owner.closeOverlay(el)", function_body(runtime, "closeOverlay"))
        retired_section = runtime[runtime.index("  // Overlay manager"):runtime.index("  const choiceMetod")]
        for token in ("OVERLAY_IDS", "getComputedStyle", "setInterval", "pointerdown", "aria-hidden"):
            self.assertNotIn(token, retired_section)
        for token in ("function setOverlayVisible", "function hideAllOverlays"):
            self.assertNotIn(token, helpers)
        self.assertIn("setGrainMsg", helpers)

    def test_08_bootstrap_and_architecture_publish_one_exact_owner(self) -> None:
        bootstrap = BOOTSTRAP.read_text(encoding="utf-8")
        rules = json.loads(RULES.read_text(encoding="utf-8"))["frontend"]
        owner = "app/tool-a/components/overlay-router.js"
        self.assertEqual(bootstrap.count('from "./components/overlay-router.js"'), 1)
        self.assertEqual(bootstrap.count("createOverlayRouterComponent()"), 1)
        self.assertIn('"R9I_SYNC_CATALOG_REFRESH_CLEANUP_9"', bootstrap)
        for method in ("bindOverlayRouter", "setOverlayVisible", "hideAllOverlays", "openOverlay", "closeOverlay"):
            self.assertEqual(bootstrap.count(f"  {method}:"), 1)
        self.assertEqual(len(rules["moduleImports"]), 19)
        self.assertEqual(len(rules["domOwnerModules"]), 10)
        self.assertEqual(rules["moduleImports"][owner], [])
        self.assertIn(owner, rules["domOwnerModules"])
        self.assertIn("tool-a/components/overlay-router.js", rules["publicStaticFiles"])
        self.assertEqual(len(rules["networkOwnerModules"]), 2)

    def test_09_static_owner_exposes_one_module_and_consumers_do_not_duplicate_it(self) -> None:
        static = (APP / "metod_app/http/static.py").read_bytes()
        matcher = (APP / "metod_app/http/matcher.py").read_bytes()
        server = (APP / "server_py.py").read_bytes()
        marker = b'"tool-a/components/overlay-router.js"'
        self.assertEqual(static.count(marker), 1)
        self.assertEqual(matcher.count(marker), 0)
        self.assertEqual(server.count(marker), 0)
        self.assertIn(b"from .static import (", matcher)

    def test_10_functional_truth_files_remain_byte_exact(self) -> None:
        exact = {
            "dxf_nesting_optimizer.py": "42480b301cd660dac1e5e9fec2c8d30bb5c6826c32234a9c1cce765b758bebb8",
            "dxf_geometry.py": "b80a2d006241908bf7b33516f7e0faf59ef61e1e08db86966b23cc5de292c1ff",
            "pricing_helpers.py": "646c2f5186e9b080f6ba8dcf364884411c18e946254bb5c9001647f7cbb425df",
            "panel_contract.py": "e23314fd63a2358a48daa580a92cebb8a40c9862548ba0243461a59347da7fc9",
            "toolA_grain_studio_renderer.js": "922cd4ac479fbaf86ebfbb0256808119b96a8344e9b0bf1ffb4f668518a03204",
        }
        for relative, digest in exact.items():
            self.assertEqual(hashlib.sha256((APP / relative).read_bytes()).hexdigest(), digest, relative)


if __name__ == "__main__":
    unittest.main(verbosity=2)
