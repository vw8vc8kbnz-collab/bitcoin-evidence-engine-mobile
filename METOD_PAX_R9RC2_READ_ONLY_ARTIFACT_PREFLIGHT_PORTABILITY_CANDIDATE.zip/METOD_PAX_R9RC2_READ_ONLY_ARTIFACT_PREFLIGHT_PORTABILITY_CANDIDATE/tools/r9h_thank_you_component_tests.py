#!/usr/bin/env python3
from __future__ import annotations

import ast
import base64
import hashlib
import json
import re
import subprocess
import unittest
from pathlib import Path

from r9h_shell_source import read_toola_expanded


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
COMPONENT = APP / "tool-a/components/thank-you.js"
CHECKOUT = APP / "tool-a/components/checkout-review.js"
BOOTSTRAP = APP / "tool-a/bootstrap.js"
HTML = APP / "toolA.html"
RULES = ROOT / "R9B_ARCHITECTURE_RULES.json"


def data_url(path: Path) -> str:
    return "data:text/javascript;base64," + base64.b64encode(path.read_bytes()).decode()


def run_node(source: str) -> dict:
    completed = subprocess.run(
        ["node", "--input-type=module"], input=source, text=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=10, check=False,
    )
    if completed.returncode != 0:
        raise AssertionError(completed.stdout)
    return json.loads(completed.stdout.strip().splitlines()[-1])


def assignment_set(path: Path, name: str) -> set[str]:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(
            isinstance(target, ast.Name) and target.id == name for target in node.targets
        ):
            value = node.value
            if isinstance(value, ast.Call) and isinstance(value.func, ast.Name) and value.func.id == "frozenset":
                value = value.args[0]
            return set(ast.literal_eval(value))
    raise AssertionError(name)


HARNESS = r"""
function makeHarness(){
  let appended=0,removed=0;const listeners={};
  const closeBtn={disabled:false,closest:s=>s.includes('#submitThanksClose')?closeBtn:null};
  const newBtn={disabled:false,closest:s=>s.includes('#submitThanksNew')?newBtn:null};
  const overlay={id:'',className:'',innerHTML:'',attrs:{},setAttribute:(k,v)=>overlay.attrs[k]=v,
    addEventListener:(t,f)=>listeners[t]=f,removeEventListener:t=>delete listeners[t],remove:()=>removed++,
    querySelector:s=>s==='#submitThanksClose'?closeBtn:(s==='#submitThanksNew'?newBtn:null)};
  const documentRef={createElement:()=>overlay,getElementById:()=>null,body:{appendChild:()=>appended++}};
  return {documentRef,overlay,closeBtn,newBtn,listeners,stats:()=>({appended,removed})};
}
"""


class R9HThankYouComponentTests(unittest.TestCase):
    def test_01_component_surface_is_frozen_and_revisioned(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});const c=m.createThankYouComponent({{documentRef:{{}},rootRef:{{}}}});
console.log(JSON.stringify({{build:m.THANK_YOU_COMPONENT_BUILD,componentBuild:c.BUILD,frozen:Object.isFrozen(c),keys:Reflect.ownKeys(c)}}));
""")
        self.assertEqual(result["build"], "R9H_THANK_YOU_COMPONENT_9")
        self.assertEqual(result["componentBuild"], result["build"])
        self.assertTrue(result["frozen"])
        self.assertEqual(result["keys"], ["BUILD", "show", "close", "handleEvent", "isOpen", "announceReady"])

    def test_02_render_escapes_customer_reference_and_uses_committed_total(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});{HARNESS}const h=makeHarness();let hidden=0;
const c=m.createThankYouComponent({{documentRef:h.documentRef,rootRef:{{setTimeout:f=>f()}},hideProgress:()=>hidden++}});
const shown=c.show({{requestId:'REQ-<1>',priceInclVat:620.43,customer:{{firstName:'Ada <',lastName:'& Zaag',email:'a&b@example.invalid'}}}});
console.log(JSON.stringify({{shown,open:c.isOpen(),html:h.overlay.innerHTML,className:h.overlay.className,hidden,stats:h.stats()}}));
""")
        self.assertTrue(result["shown"])
        self.assertTrue(result["open"])
        self.assertEqual(result["hidden"], 1)
        self.assertEqual(result["stats"]["appended"], 1)
        self.assertIn("Ada &lt; &amp; Zaag", result["html"])
        self.assertIn("REQ-&lt;1&gt;", result["html"])
        self.assertIn("620,43", result["html"])
        self.assertNotIn("REQ-<1>", result["html"])
        self.assertEqual(result["className"], "submitThanksOverlay")
        self.assertIn(".submitThanksOverlay{position:fixed;inset:0;z-index:2147483647",
            (APP / "tool-a/styles/static-utilities.css").read_text(encoding="utf-8"))

    def test_03_render_reads_customer_fallback_without_owning_state(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});{HARNESS}const h=makeHarness();
const state={{checkout:{{customer:{{firstName:'Bep',lastName:'Zager',email:'bep@example.invalid'}}}}}};
const c=m.createThankYouComponent({{documentRef:h.documentRef,rootRef:{{setTimeout:f=>f()}},getState:()=>state}});c.show({{requestId:'REQ-2',pricingSummary:{{totalInclVat:99.5}}}});
console.log(JSON.stringify({{html:h.overlay.innerHTML,state}}));
""")
        self.assertIn("Bep Zager", result["html"])
        self.assertIn("bep@example.invalid", result["html"])
        self.assertIn("99,50", result["html"])
        self.assertEqual(result["state"]["checkout"]["customer"]["firstName"], "Bep")

    def test_04_show_replaces_existing_overlay_and_progress_is_delegated(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});{HARNESS}const h=makeHarness();let oldRemoved=0,hidden=0;
h.documentRef.getElementById=id=>id==='submitThanksOverlay'?{{remove:()=>oldRemoved++}}:null;
const c=m.createThankYouComponent({{documentRef:h.documentRef,rootRef:{{setTimeout:f=>f()}},hideProgress:()=>hidden++}});
const first=c.show({{requestId:'ONE'}});const second=c.show({{requestId:'TWO'}});
console.log(JSON.stringify({{first,second,open:c.isOpen(),oldRemoved,hidden,stats:h.stats(),html:h.overlay.innerHTML}}));
""")
        self.assertTrue(result["first"] and result["second"] and result["open"])
        self.assertEqual(result["oldRemoved"], 2)
        self.assertEqual(result["hidden"], 2)
        self.assertGreaterEqual(result["stats"]["removed"], 1)
        self.assertIn("TWO", result["html"])

    def test_05_backdrop_closes_without_reset_or_reload(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});{HARNESS}const h=makeHarness();let resets=0,reloads=0,prevented=0;
const c=m.createThankYouComponent({{documentRef:h.documentRef,rootRef:{{setTimeout:f=>f(),location:{{reload:()=>reloads++}}}},resetConfiguration:()=>resets++}});c.show({{requestId:'REQ'}});
const handled=c.handleEvent({{target:h.overlay,preventDefault:()=>prevented++}});
console.log(JSON.stringify({{handled,open:c.isOpen(),resets,reloads,prevented,stats:h.stats()}}));
""")
        self.assertEqual(result["handled"], True)
        self.assertFalse(result["open"])
        self.assertEqual((result["resets"], result["reloads"], result["prevented"]), (0, 0, 1))

    def test_06_both_buttons_share_one_reentrant_safe_hard_reset_route(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});{HARNESS}const h=makeHarness();let resets=0,prevented=0,stopped=0;
let release;const wait=new Promise(r=>release=r);const c=m.createThankYouComponent({{documentRef:h.documentRef,rootRef:{{setTimeout:f=>f()}},resetConfiguration:async()=>{{resets++;await wait;}}}});c.show({{requestId:'REQ'}});
const event=t=>({{target:t,preventDefault:()=>prevented++,stopImmediatePropagation:()=>stopped++}});
const first=c.handleEvent(event(h.closeBtn));const second=c.handleEvent(event(h.newBtn));release();await Promise.resolve();await Promise.resolve();
console.log(JSON.stringify({{first,second,resets,prevented,stopped,closeDisabled:h.closeBtn.disabled,newDisabled:h.newBtn.disabled}}));
""")
        self.assertTrue(result["first"] and result["second"])
        self.assertEqual(result["resets"], 1)
        self.assertEqual((result["prevented"], result["stopped"]), (2, 2))
        self.assertTrue(result["closeDisabled"] and result["newDisabled"])

    def test_07_missing_or_failed_reset_falls_back_to_close_and_reload(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});{HARNESS}const h=makeHarness();let reloads=0;
const c=m.createThankYouComponent({{documentRef:h.documentRef,rootRef:{{setTimeout:f=>f(),location:{{reload:()=>reloads++}}}},resetConfiguration:async()=>{{throw new Error('reset');}}}});c.show({{requestId:'REQ'}});
c.handleEvent({{target:h.newBtn,preventDefault:()=>{{}},stopImmediatePropagation:()=>{{}}}});await Promise.resolve();await Promise.resolve();
console.log(JSON.stringify({{open:c.isOpen(),reloads,stats:h.stats()}}));
""")
        self.assertFalse(result["open"])
        self.assertEqual(result["reloads"], 1)
        self.assertGreaterEqual(result["stats"]["removed"], 1)

    def test_08_dom_failure_uses_exact_text_fallback(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});let alerts=[];const c=m.createThankYouComponent({{documentRef:{{createElement:()=>null,getElementById:()=>null}},rootRef:{{alert:v=>alerts.push(v)}}}});
console.log(JSON.stringify({{shown:c.show({{requestId:'REQ'}}),alerts,open:c.isOpen()}}));
""")
        self.assertFalse(result["shown"])
        self.assertFalse(result["open"])
        self.assertEqual(result["alerts"], ["Bedankt voor je aanvraag. Binnen 2 werkdagen sturen wij de factuur naar het opgegeven e-mailadres."])

    def test_09_ready_event_is_idempotent(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});let events=[];class E{{constructor(type){{this.type=type;}}}};const c=m.createThankYouComponent({{documentRef:{{dispatchEvent:e=>events.push(e.type)}},rootRef:{{Event:E}}}});
console.log(JSON.stringify({{first:c.announceReady(),second:c.announceReady(),events}}));
""")
        self.assertEqual(result, {"first": True, "second": False, "events": ["tool-a-thank-you-owner-ready"]})

    def test_10_bootstrap_and_html_publish_one_native_thank_you_route(self) -> None:
        bootstrap = BOOTSTRAP.read_text(encoding="utf-8")
        html = read_toola_expanded(HTML)
        self.assertEqual(bootstrap.count('from "./components/thank-you.js"'), 1)
        self.assertEqual(bootstrap.count("createThankYouComponent({"), 1)
        self.assertIn('"R9RC1_PROFESSIONAL_ARCHITECTURE_COMPLETION"', bootstrap)
        self.assertIn('mode: "legacy-read-cleanup-adapter"', bootstrap)
        for method in ("showSubmissionThankYou", "closeSubmissionThankYou", "handleSubmissionThankYouEvent", "isSubmissionThankYouOpen"):
            self.assertEqual(bootstrap.count(f"  {method}:"), 1, method)
        self.assertIn("tool-a/bootstrap.js?v=r9rc1-professional-architecture-completion", html)
        self.assertEqual(html.count("thankYouOwner.showSubmissionThankYou({"), 1)
        self.assertNotIn("function showSubmissionThankYou(data)", html)
        self.assertNotIn("__metodShowSubmissionThankYou", html)

    def test_11_architecture_serves_eighteen_modules_and_nine_dom_owners(self) -> None:
        rules = json.loads(RULES.read_text(encoding="utf-8"))["frontend"]
        owner = "app/tool-a/components/thank-you.js"
        self.assertIn(owner, rules["domOwnerModules"])
        self.assertEqual(rules["moduleImports"][owner], [])
        self.assertEqual(len(rules["domOwnerModules"]), 10)
        self.assertEqual(len(rules["publicStaticFiles"]), 19)
        server = assignment_set(APP / "metod_app/http/static.py", "PUBLIC_STATIC_MODULE_FILES")
        matcher = assignment_set(APP / "metod_app/http/static.py", "PUBLIC_STATIC_MODULE_FILES")
        self.assertEqual(server, matcher)
        self.assertEqual(len(server), 19)

    def test_12_submit_pricing_payload_css_consent_checkout_and_reset_are_protected(self) -> None:
        exact = {
            "tool-a/api/jobs.js": "eab6fb65e7886d7cb38be81fb1a2a6bcf912e5b6fea88f0a80ca773456b83e70",
            "tool-a/api/requests.js": "4760bfd9733c8739ca96a15cdb3c8f3ef65028b3e95d61c061721cbe125c445e",
            "tool-a/components/checkout-review.js": "67aa0ef632193d30b87ac97e199a955d0266b56d9f8efe61a6397dac4c702db7",
            "pricing_helpers.py": "646c2f5186e9b080f6ba8dcf364884411c18e946254bb5c9001647f7cbb425df",
            "dxf_nesting_optimizer.py": "42480b301cd660dac1e5e9fec2c8d30bb5c6826c32234a9c1cce765b758bebb8",
        }
        for name, expected in exact.items():
            self.assertEqual(hashlib.sha256((APP / name).read_bytes()).hexdigest(), expected, name)
        html = read_toola_expanded(HTML)
        self.assertEqual(len(re.findall(r"<style[^>]*>", HTML.read_text(encoding="utf-8"))), 0)
        self.assertNotRegex(COMPONENT.read_text(encoding="utf-8"), r"<[^>]+\sstyle\s*=")
        styles = (APP / "tool-a/styles/tool-a.bundle.css").read_text(encoding="utf-8")
        for selector in (".submitThanksOverlay{", ".submitThanksCard", ".tool-component-u-c36ec52ad7c4{"):
            self.assertIn(selector, styles)
        start = html.index("async function buildJobPayload(){")
        end = html.index("  // ---------------------------\n  // Checkout overlays (restmateriaal + klantgegevens)", start)
        payload = html[start:end].encode()
        self.assertEqual((len(payload), hashlib.sha256(payload).hexdigest()),
            (9697, "342dac02c2650ac2798e20e62d38d8e1e6b7d518a54daa8fd760d734ae527e47"))
        self.assertIn("Door deze aanvraag te verzenden, ga je akkoord met de bovenstaande totaalprijs incl. btw.", html)
        self.assertIn("async function _resetConfigurationHard()", html)


if __name__ == "__main__":
    unittest.main(verbosity=2)
