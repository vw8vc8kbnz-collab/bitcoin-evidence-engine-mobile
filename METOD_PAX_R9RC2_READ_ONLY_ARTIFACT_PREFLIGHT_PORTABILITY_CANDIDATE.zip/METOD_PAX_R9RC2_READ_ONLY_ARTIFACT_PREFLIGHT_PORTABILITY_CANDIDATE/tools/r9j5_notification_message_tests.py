#!/usr/bin/env python3
from __future__ import annotations

"""Executable contracts for the R9J-5 notification message extraction."""

import ast
import dataclasses
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / 'app'
sys.path.insert(0, str(APP))

from metod_app.notifications.messages import (  # noqa: E402
    NotificationMessage,
    build_failed_notification,
    build_submitted_notification,
)


class R9J5NotificationMessageTests(unittest.TestCase):
    def test_01_minimal_notice_is_exact_and_excludes_verbose_inputs(self) -> None:
        notification = build_submitted_notification(
            'REQ-42',
            {'panelsTotal': 99, 'materials': [{'name': 'Verborgen'}]},
            {'panelsTotal': 88, 'materials': [{'label': 'Verborgen'}]},
            {'totalInclVat': 1234.5},
            ['Naam: Niet versturen'],
            minimal_order_notice=True,
            include_price_breakdown=True,
            calculation_summary_present=True,
            calculation_job_id='JOB-SECRET',
        )
        self.assertEqual(
            notification,
            NotificationMessage(
                title='AD Zaagt Configurator',
                message=(
                    'Nieuwe order ontvangen\n'
                    'Totaal: €1.234,50\n'
                    'Request: REQ-42\n'
                    'Open admin voor details.'
                ),
                tags=('new',),
            ),
        )
        for forbidden in ('Niet versturen', 'Verborgen', 'JOB-SECRET'):
            self.assertNotIn(forbidden, notification.message)

    def test_02_minimal_notice_without_price_keeps_stable_shape(self) -> None:
        notification = build_submitted_notification('REQ-0', {}, {}, {})
        self.assertEqual(
            notification.message,
            'Nieuwe order ontvangen\nRequest: REQ-0\nOpen admin voor details.',
        )

    def test_03_verbose_calculation_projection_is_exact(self) -> None:
        notification = build_submitted_notification(
            'REQ-9',
            {'panelsTotal': 2, 'platesTotal': 1, 'materials': []},
            {
                'panelsTotal': 12,
                'platesTotal': 3,
                'materials': [
                    {'label': 'U999 ST2 Zwart', 'detail': 'Platen: 2 | Dikte: 18 mm'},
                    {'label': 'H1180 Halifax', 'detail': ''},
                ],
                'edgeMeters': [
                    {'label': 'U999', 'meters': 12.5},
                    {'label': 'H1180', 'meters': 1234.56},
                ],
            },
            {
                'materialsTotalInclVat': 1234.56,
                'edgeBandTotal': 20,
                'cncTotal': 30,
                'drawingTotal': 10,
                'transportTotal': 40,
                'subtotalExVat': 1120.3,
                'vatAmount': 235.26,
                'totalInclVat': 1355.56,
            },
            ['Naam: Voorbeeld', 'Email: klant@example.invalid'],
            minimal_order_notice=False,
            include_price_breakdown=True,
            calculation_summary_present=True,
            calculation_job_id='JOB-9',
        )
        self.assertEqual(
            notification.message,
            '\n'.join(
                (
                    'Nieuwe configuratie',
                    '',
                    '👤 Klant/order',
                    'Naam: Voorbeeld',
                    'Email: klant@example.invalid',
                    '',
                    'Configuratie',
                    'Panelen: 12',
                    'Platen: 3',
                    '• U999 ST2 Zwart',
                    '  Platen: 2 | Dikte: 18 mm',
                    '• H1180 Halifax',
                    '',
                    'Kantenband',
                    '• U999: 12,50 m',
                    '• H1180: 1.234,56 m',
                    '',
                    'Berekening (exact uit calculation_summary)',
                    'Plaatmateriaal incl. btw: €1.234,56',
                    'Kantenband excl. btw: €20,00',
                    'CNC: €30,00',
                    'Tekenen: €10,00',
                    'Transport: €40,00',
                    'Subtotaal excl. btw: €1.120,30',
                    'BTW: €235,26',
                    'Totaal incl. btw: €1.355,56',
                    '',
                    'Request',
                    'REQ-9',
                    'Job: JOB-9',
                )
            ),
        )

    def test_04_verbose_fallback_materials_and_total_only_are_exact(self) -> None:
        notification = build_submitted_notification(
            'REQ-FALLBACK',
            {
                'panelsTotal': 4,
                'platesTotal': 2,
                'materials': [
                    {'name': 'Decor zwart', 'code': 'U999', 'plates': 2},
                    {'name': 'H1180 Halifax', 'code': 'H1180'},
                    {'name': '', 'code': ''},
                ],
            },
            {'panelsTotal': None, 'platesTotal': None, 'materials': [], 'edgeMeters': []},
            {'totalInclVat': 100},
            minimal_order_notice=False,
            include_price_breakdown=False,
        )
        self.assertEqual(
            notification.message,
            '\n'.join(
                (
                    'Nieuwe configuratie',
                    '',
                    'Configuratie',
                    'Panelen: 4',
                    'Platen: 2',
                    '• Decor zwart (U999) - 2 plaat/platen',
                    '• H1180 Halifax',
                    '',
                    'Totaal incl. btw: €100,00',
                    '',
                    'Request',
                    'REQ-FALLBACK',
                )
            ),
        )

    def test_05_customer_and_configuration_lines_remain_bounded(self) -> None:
        customer_lines = [f'Naam: Klant {index}' for index in range(20)]
        materials = [
            {'label': f'Materiaal {index}', 'detail': f'Detail {index}'}
            for index in range(20)
        ]
        notification = build_submitted_notification(
            'REQ-BOUND',
            {},
            {'materials': materials, 'edgeMeters': []},
            {},
            customer_lines,
            minimal_order_notice=False,
        )
        self.assertIn('Naam: Klant 9', notification.message)
        self.assertNotIn('Naam: Klant 10', notification.message)
        self.assertIn('• Materiaal 5', notification.message)
        self.assertNotIn('• Materiaal 6', notification.message)

    def test_06_failed_notice_is_bounded_and_uses_only_the_first_line(self) -> None:
        notification = build_failed_notification('REQ-FAIL', ('x' * 220) + '\nsecret')
        lines = notification.message.splitlines()
        self.assertEqual(lines[0], '🔴 Optimizer fout')
        self.assertEqual(lines[1], 'Request: REQ-FAIL')
        self.assertEqual(lines[2], 'x' * 180)
        self.assertEqual(lines[3], 'Check Admin')
        self.assertNotIn('secret', notification.message)
        self.assertEqual(notification.tags, ('warning',))
        self.assertEqual(
            build_failed_notification('REQ-EMPTY', '').message,
            '🔴 Optimizer fout\nRequest: REQ-EMPTY\nOnbekende fout\nCheck Admin',
        )

    def test_07_message_value_object_is_frozen_and_transport_neutral(self) -> None:
        self.assertTrue(dataclasses.is_dataclass(NotificationMessage))
        notification = build_failed_notification('REQ', 'fout')
        with self.assertRaises(dataclasses.FrozenInstanceError):
            notification.message = 'gewijzigd'  # type: ignore[misc]
        self.assertEqual([field.name for field in dataclasses.fields(notification)], ['title', 'message', 'tags'])

    def test_08_message_module_has_no_side_effect_boundary_imports_or_calls(self) -> None:
        path = APP / 'metod_app/notifications/messages.py'
        tree = ast.parse(path.read_text(encoding='utf-8'))
        imported_roots = {
            alias.name.split('.')[0]
            for node in ast.walk(tree)
            if isinstance(node, ast.Import)
            for alias in node.names
        }
        imported_roots.update(
            node.module.split('.')[0]
            for node in ast.walk(tree)
            if isinstance(node, ast.ImportFrom) and node.module
        )
        self.assertTrue(imported_roots.isdisjoint(
            {'http', 'json', 'os', 'pathlib', 'socket', 'subprocess', 'threading', 'urllib'}
        ))
        called_names = {
            node.func.id
            for node in ast.walk(tree)
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
        }
        self.assertTrue(called_names.isdisjoint({'open', 'print', 'exec', 'eval'}))

    def test_09_server_is_only_composition_and_transport_owner(self) -> None:
        source = (APP / 'server_py.py').read_text(encoding='utf-8')
        self.assertIn('build_submitted_notification as _build_submitted_notification', source)
        self.assertIn('build_failed_notification as _build_failed_notification', source)
        self.assertEqual(source.count('_build_submitted_notification('), 1)
        self.assertEqual(source.count('_build_failed_notification('), 1)
        self.assertNotIn('Nieuwe configuratie', source)
        self.assertNotIn('🔴 Optimizer fout', source)
        self.assertNotIn('def _format_money_eur(', source)


if __name__ == '__main__':
    unittest.main(verbosity=2)
