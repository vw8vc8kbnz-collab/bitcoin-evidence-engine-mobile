#!/usr/bin/env python3
from __future__ import annotations

import json
import importlib
import os
import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path


RELEASE = Path(__file__).resolve().parents[1]
APP = RELEASE / "app"
sys.path.insert(0, str(APP))

from metod_app.admin.access import (  # noqa: E402
    AdminAccessController,
    AdminAccessDependencies,
    AdminSessionStore,
    normalized_admin_users,
)
from metod_app.security.credentials import (  # noqa: E402
    PBKDF2_ITERATIONS,
    pbkdf2_hash_password,
    verify_password_against_stored,
)
from metod_app.security.redaction import redact_sensitive_text, sanitize_log_value  # noqa: E402
from safety_contracts import delete_rotating_log_if_older_than, strict_json_load  # noqa: E402


class R9O9SecurityPrivacyTests(unittest.TestCase):
    def test_runtime_credentials_are_file_only_even_with_legacy_environment(self) -> None:
        with tempfile.TemporaryDirectory(prefix="r9o9-creds-") as temp_name:
            root = Path(temp_name)
            credentials_path = root / "admin.json"
            current_hash = pbkdf2_hash_password("file-password", salt="testsalt01234567")
            credentials_path.write_text(json.dumps({"schemaVersion": 2, "users": [{
                "username": "file-admin",
                "password_hash": current_hash,
                "totp_secret": "JBSWY3DPEHPK3PXP",
                "roles": ["admin"],
                "active": True,
            }]}), encoding="utf-8")
            dependencies = AdminAccessDependencies(
                root=root,
                environment={
                    "ADMIN_USER": "legacy-admin",
                    "ADMIN_PASS": "legacy-plaintext",
                    "ADMIN_PASS_HASH": "legacy-hash",
                    "ADMIN_TOTP_SECRET": "JBSWY3DPEHPK3PXP",
                },
                credentials_file_path=lambda: credentials_path,
                strict_json_load=strict_json_load,
                strict_json_dumps=json.dumps,
                read_json_body_limited=lambda *_: {},
                production_runtime=lambda: True,
                production_hardening_enabled=lambda: True,
                secure_admin_transport=lambda *_: True,
                https_request=lambda *_: True,
                client_ip=lambda *_: "127.0.0.1",
                loopback_client=lambda *_: True,
                rate_limit_is_blocked=lambda *_: False,
                rate_limit_record=lambda *_: None,
                rate_limit_clear=lambda *_: None,
                verify_password=verify_password_against_stored,
                verify_totp=lambda *_: True,
                append_system_event=lambda **_: None,
                extract_bearer_token=lambda *_: "",
                extract_session_cookie=lambda *_: "",
                dummy_password_hash=current_hash,
                dummy_totp_secret="JBSWY3DPEHPK3PXP",
            )
            sessions = AdminSessionStore(
                idle_seconds=1800,
                absolute_seconds=28800,
                max_sessions=lambda: 64,
                lock=threading.RLock(),
            )
            loaded = AdminAccessController(dependencies, sessions).load_credentials()
            self.assertEqual(loaded["source"], "external_config")
            self.assertEqual(normalized_admin_users(loaded)[0]["username"], "file-admin")
            self.assertNotIn("password", loaded)

    def test_plaintext_is_rejected_and_current_pbkdf2_is_strong(self) -> None:
        self.assertEqual(PBKDF2_ITERATIONS, 600_000)
        self.assertFalse(verify_password_against_stored("secret", "secret"))
        self.assertEqual(normalized_admin_users({"username": "admin", "password": "secret"}), [])
        current = pbkdf2_hash_password("secret", salt="testsalt01234567")
        self.assertTrue(verify_password_against_stored("secret", current))

    def test_ip_addresses_are_removed_from_text_and_structured_logs(self) -> None:
        redacted = redact_sensitive_text(
            "client=203.0.113.42 proxy=2001:db8::2 email=person@example.com", 500
        )
        self.assertNotIn("203.0.113.42", redacted)
        self.assertNotIn("2001:db8::2", redacted)
        self.assertIn("[redacted-ip]", redacted)
        structured = sanitize_log_value({"client_ip": "203.0.113.42", "safe": "ok"})
        self.assertEqual(structured["client_ip"], "[redacted]")
        self.assertEqual(structured["safe"], "ok")

    def test_low_volume_active_log_obeys_hard_age_limit(self) -> None:
        with tempfile.TemporaryDirectory(prefix="r9o9-log-") as temp_name:
            path = Path(temp_name) / "system_log.jsonl"
            path.write_text('{"safe":true}\n', encoding="utf-8")
            old = time.time() - 40 * 86400
            os.utime(path, (old, old))
            self.assertTrue(delete_rotating_log_if_older_than(
                path, cutoff_timestamp=time.time() - 30 * 86400
            ))
            self.assertFalse(path.exists())

    def test_server_has_one_directory_size_owner(self) -> None:
        implementation = (
            APP / "metod_app/http/endpoints/admin_requests.py"
        ).read_text(encoding="utf-8")
        composition = (
            APP / "metod_app/runtime/application.py"
        ).read_text(encoding="utf-8")
        self.assertEqual(implementation.count("def _dir_size_bytes("), 1)
        self.assertEqual(composition.count("def _dir_size_bytes("), 1)
        self.assertIn("return _http_admin_requests._dir_size_bytes(", composition)

    def test_rate_limit_state_has_a_hard_cardinality_cap(self) -> None:
        with tempfile.TemporaryDirectory(prefix="r9o9-rate-") as temp_name:
            previous = os.environ.get("METOD_STATE_ROOT")
            os.environ["METOD_STATE_ROOT"] = str(Path(temp_name) / "state")
            try:
                server = importlib.import_module("server_py")
                with server._RATE_LIMITS_LOCK:
                    server._RATE_LIMITS.clear()
                for index in range(10_050):
                    server._rate_limit_record("audit-cap", f"key-{index}")
                self.assertLessEqual(len(server._RATE_LIMITS), 10_000)
                for index in range(10_050):
                    server._rate_limit_is_blocked("empty-probe", f"probe-{index}", 10, 300)
                self.assertLessEqual(len(server._RATE_LIMITS), 10_000)
            finally:
                if previous is None:
                    os.environ.pop("METOD_STATE_ROOT", None)
                else:
                    os.environ["METOD_STATE_ROOT"] = previous

    def test_deploy_owns_bounded_nginx_log_retention(self) -> None:
        deploy = (RELEASE / "DEPLOY_FIX660.sh").read_text(encoding="utf-8")
        self.assertIn("access_log /var/log/nginx/metod-pax-access.log", deploy)
        self.assertIn("error_log /var/log/nginx/metod-pax-error.log", deploy)
        self.assertIn("maxage 30", deploy)
        self.assertIn("logrotate --debug", deploy)


if __name__ == "__main__":
    unittest.main(verbosity=2)
