#!/usr/bin/env python3
from __future__ import annotations

"""Executable ownership, safety and parity contracts for R9L5."""

import ast
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
SERVER = APP / "server_py.py"
OWNER = APP / "metod_app/jobs/lifecycle.py"
FIXTURE = ROOT / "R9L5_JOB_LIFECYCLE_BEFORE_FIXTURE.json"
SCOPE = ROOT / "R9L5_REMAINING_JOB_LIFECYCLE_FACADES_EXTRACTION_SCOPE.json"
CONTRACT = ROOT / "R9L5_REMAINING_JOB_LIFECYCLE_FACADES_EXTRACTION.json"
os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")
_STATE_TEMP = tempfile.TemporaryDirectory(prefix="r9l5_lifecycle_tests_")
os.environ.setdefault("METOD_STATE_ROOT", str(Path(_STATE_TEMP.name) / "state"))
sys.path.insert(0, str(APP))
sys.path.insert(0, str(ROOT / "tools"))

import server_py as server  # noqa: E402
from metod_app.jobs.lifecycle import (  # noqa: E402
    JobLifecycleDependencies,
    JobLifecycleFacadeService,
)
from r9l5_job_lifecycle_before_gate import _behavior  # noqa: E402


ADAPTERS = (
    "_api_cancel_job", "_estimate_job_complexity", "_start_async_job_create",
    "_write_api_jobs_crashlog", "_api_create_job", "_api_status",
)


class R9L5JobLifecycleTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.fixture = json.loads(FIXTURE.read_text(encoding="utf-8"))
        cls.scope = json.loads(SCOPE.read_text(encoding="utf-8"))
        cls.contract = json.loads(CONTRACT.read_text(encoding="utf-8"))
        cls.server_source = SERVER.read_text(encoding="utf-8")
        cls.owner_source = OWNER.read_text(encoding="utf-8")
        cls.server_tree = ast.parse(cls.server_source)
        cls.owner_tree = ast.parse(cls.owner_source)

    def test_01_fixture_seals_exact_r9l4_source_before_extraction(self) -> None:
        self.assertEqual(self.fixture["sourceCheckpoint"], "R9L4")
        self.assertEqual(self.fixture["sourceCommit"], "00a3650b4dcce7238d161829dae789e07f24bd63")
        self.assertEqual(self.fixture["server"], {
            "bytes": 507230,
            "lines": 11063,
            "sha256": "72a63d24b763b6a78372d0819aadd5402828e0dc2cc84064f17774ad9fac00f3",
        })
        self.assertEqual(len(self.fixture["activeOwnerSource"]), 6)

    def test_02_one_module_owns_all_remaining_public_lifecycle_facades(self) -> None:
        classes = {node.name for node in self.owner_tree.body if isinstance(node, ast.ClassDef)}
        self.assertEqual(classes, {"JobLifecycleDependencies", "JobLifecycleFacadeService"})
        service = next(node for node in self.owner_tree.body if isinstance(node, ast.ClassDef) and node.name == "JobLifecycleFacadeService")
        methods = {node.name for node in service.body if isinstance(node, ast.FunctionDef)}
        self.assertTrue({
            "api_cancel_job", "estimate_job_complexity", "start_async_job_create",
            "write_api_jobs_crashlog", "api_create_job", "api_status",
        }.issubset(methods))

    def test_03_handler_retains_only_two_line_lifecycle_adapters(self) -> None:
        handler = next(node for node in self.server_tree.body if isinstance(node, ast.ClassDef) and node.name == "Handler")
        methods = {node.name: node for node in handler.body if isinstance(node, ast.FunctionDef)}
        for name in ADAPTERS:
            segment = ast.get_source_segment(self.server_source, methods[name])
            self.assertEqual(len(str(segment).splitlines()), 2, name)
            self.assertIn("_JOB_LIFECYCLE", str(segment), name)

    def test_04_all_sealed_lifecycle_behavior_is_exact(self) -> None:
        actual = _behavior()
        for key, value in actual.items():
            self.assertEqual(value, self.fixture[key], key)

    def test_05_cancellation_order_is_durable_and_slot_safe(self) -> None:
        events = self.fixture["cancelSnapshot"]["events"]
        self.assertEqual([event[0] for event in events], [
            "state", "cancelQueued", "terminate", "state", "finishSlot",
        ])
        self.assertEqual(events[0][2], "CANCEL_REQUESTED")
        self.assertEqual(events[3][2], "CANCELLED")

    def test_06_async_terminal_states_remain_exact(self) -> None:
        cases = self.fixture["asyncSnapshots"]
        self.assertEqual(cases["success"]["events"][-1][1], "DONE")
        self.assertEqual(cases["failed"]["events"][-1][1], "FAILED")
        self.assertEqual(cases["cancelled"]["events"][-1][1], "CANCELLED")
        self.assertTrue(cases["failed"]["events"][-1][2]["retryable"])
        self.assertFalse(cases["cancelled"]["events"][-1][2]["retryable"])

    def test_07_terminal_public_status_projection_remains_fail_closed(self) -> None:
        matrix = self.fixture["statusMatrix"]
        self.assertEqual(matrix["invalid"]["code"], 404)
        self.assertEqual(matrix["missing"]["body"]["meta"]["status"], "unknown")
        self.assertIsNone(matrix["cancelled"]["body"]["quote"])
        self.assertIsNone(matrix["failed"]["body"]["quote"])

    def test_08_dependencies_are_explicit_and_owner_has_no_hidden_server_import(self) -> None:
        dependency_class = next(node for node in self.owner_tree.body if isinstance(node, ast.ClassDef) and node.name == "JobLifecycleDependencies")
        fields = [node.target.id for node in dependency_class.body if isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name)]
        self.assertGreaterEqual(len(fields), 50)
        for token in ("import server_py", "from server_py", "import subprocess", "dxf_geometry", "dxf_nesting_optimizer", "pricing_helpers"):
            self.assertNotIn(token, self.owner_source, token)

    def test_09_optimizer_and_finalization_algorithms_remain_existing_owners(self) -> None:
        self.assertIn("def _create_job_from_payload", self.server_source)
        self.assertIn("_JOB_FINALIZATION_SERVICE.seal_master", self.server_source)
        self.assertNotIn("def _create_job_from_payload", self.owner_source)
        self.assertNotIn("seal_master(", self.owner_source)

    def test_10_scope_excludes_r9m_and_optimizer_changes(self) -> None:
        self.assertEqual(self.scope["contractId"], "R9L5_REMAINING_JOB_LIFECYCLE_FACADES_EXTRACTION_SCOPE")
        self.assertIn("R9M HTML, CSS or JavaScript splitting", self.scope["excluded"])
        self.assertIn("optimizer, geometry, nesting, pricing and CAM algorithms", self.scope["excluded"])

    def test_11_checkpoint_remains_external_no_go(self) -> None:
        self.assertEqual(self.contract["status"], "PROVISIONAL_DEVELOPMENT_ONLY")
        self.assertFalse(self.contract["releaseEligible"])
        self.assertFalse(self.contract["externalEvidence"]["productionGo"])

    def test_12_next_scope_is_exclusively_r9m_professional_split(self) -> None:
        self.assertEqual(
            self.contract["nextExclusiveCheckpoint"],
            "R9M_ADMIN_HTML_CSS_JAVASCRIPT_PROFESSIONAL_SPLIT",
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
