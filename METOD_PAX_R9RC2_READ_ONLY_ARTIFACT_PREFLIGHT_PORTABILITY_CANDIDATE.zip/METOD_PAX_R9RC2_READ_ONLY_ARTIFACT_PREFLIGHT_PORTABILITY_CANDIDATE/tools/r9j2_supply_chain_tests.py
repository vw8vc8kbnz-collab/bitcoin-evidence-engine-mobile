#!/usr/bin/env python3
from __future__ import annotations

import unittest
from pathlib import Path

from r9j2_supply_chain_gate import (
    audit_release,
    scan_javascript_source,
    scan_python_source,
    scan_secret_text,
)


ROOT = Path(__file__).resolve().parents[1]


class R9J2SupplyChainTests(unittest.TestCase):
    def test_01_complete_release_passes_the_supply_chain_gate(self) -> None:
        report = audit_release(ROOT)
        self.assertEqual(report["status"], "PASS", report["failures"])
        self.assertEqual(report["secretFindings"], [])
        self.assertEqual(report["sastFindings"], [])
        self.assertEqual(report["javascriptFindings"], [])
        self.assertEqual(report["pythonMandatoryThirdPartyImports"], [])
        self.assertEqual(report["requirementsEntries"], [])

    def test_02_high_signal_secret_families_fail_closed(self) -> None:
        probes = {
            "private-key-pem": "-----BEGIN " + "PRIVATE KEY-----",
            "aws-access-key": "AKIA" + "IOSFODNN7EXAMPLE",
            "github-token": "ghp_" + "abcdefghijklmnopqrstuvwxyz123456",
            "gitlab-token": "glpat-" + "abcdefghijklmnopqrstuvwxyz",
            "google-api-key": "AIza" + ("A" * 35),
            "slack-token": "xoxb-" + "123456789012-abcdefghijklmnopqrstuv",
            "stripe-live-key": "sk_live_" + "abcdefghijklmnopqrstuv",
            "npm-token": "npm_" + "abcdefghijklmnopqrstuvwxyz1234567890",
            "credential-in-url": "https://admin:" + "secret@example.invalid/path",
        }
        for expected, source in probes.items():
            findings = scan_secret_text("probe.txt", source)
            self.assertIn(expected, {row["ruleId"] for row in findings}, expected)
            self.assertNotIn(source, repr(findings), "reports must never echo detected secret bytes")

    def test_03_dangerous_python_execution_fails_closed(self) -> None:
        probes = {
            "eval": "eval('1+1')\n",
            "exec": "exec('pass')\n",
            "os.system": "import os\nos.system('id')\n",
            "pickle.loads": "import pickle\npickle.loads(b'x')\n",
            "tempfile.mktemp": "import tempfile\ntempfile.mktemp()\n",
            "subprocess-shell-true": "import subprocess\nsubprocess.run('id', shell=True)\n",
            "unsafe-yaml-load": "import yaml\nyaml.load('x')\n",
        }
        for expected, source in probes.items():
            findings = scan_python_source("probe.py", source)
            rule_ids = {row["ruleId"] for row in findings}
            if expected in {"eval", "exec", "os.system", "pickle.loads", "tempfile.mktemp"}:
                self.assertIn("forbidden-python-call", rule_ids, expected)
            else:
                self.assertIn(expected, rule_ids, expected)

    def test_04_application_identity_and_dom_sink_inventory_are_sealed(self) -> None:
        report = audit_release(ROOT)
        self.assertEqual(report["javascriptSinkInventory"], {
            "eval": 0,
            "newFunction": 0,
            "documentWrite": 0,
            "remoteImports": 0,
            "innerHtmlAssignmentsReviewedInventory": 120,
            "insertAdjacentHtmlReviewedInventory": 1,
        })
        self.assertEqual(report["javascriptSourceFilesScanned"], 115)
        self.assertEqual(len(report["protectedApplicationSha256"]), 47)

    def test_05_dangerous_javascript_sinks_fail_closed_with_locations(self) -> None:
        probes = {
            "eval": "eval('1 + 1')",
            "newFunction": "const f = new Function('return 1')",
            "documentWrite": "document.writeln('<p>unsafe</p>')",
            "remoteImports": "import('https://example.invalid/module.js')",
        }
        for expected, source in probes.items():
            findings = scan_javascript_source("probe.jsfrag", source)
            self.assertIn(expected, {row["sink"] for row in findings}, expected)
            self.assertTrue(all(row["path"] == "probe.jsfrag" for row in findings))

    def test_06_license_and_source_sbom_evidence_are_present(self) -> None:
        report = audit_release(ROOT)
        self.assertEqual(report["sourceSbomThirdPartyComponentCount"], 0)
        self.assertTrue((ROOT / "LICENSE_POLICY.md").is_file())
        self.assertTrue((ROOT / "R9J2_SOURCE_SBOM.cdx.json").is_file())


if __name__ == "__main__":
    unittest.main(verbosity=2)
