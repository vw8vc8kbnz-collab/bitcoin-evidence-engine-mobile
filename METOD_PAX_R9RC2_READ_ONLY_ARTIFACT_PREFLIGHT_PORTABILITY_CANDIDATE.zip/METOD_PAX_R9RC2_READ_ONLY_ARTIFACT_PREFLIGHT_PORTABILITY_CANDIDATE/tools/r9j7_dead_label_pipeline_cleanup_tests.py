#!/usr/bin/env python3
from __future__ import annotations

"""Executable contracts for the R9J-7 dead label pipeline cleanup."""

import ast
import hashlib
import json
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SERVER = ROOT / "app/server_py.py"
CONTRACT = ROOT / "R9J7_DEAD_LABEL_PIPELINE_CLEANUP.json"
R9J7_SERVER_SHA256 = "551e1e9f62f6c64a9742864739af6acb3332fd9e1b2e6bab0b0632477e2ad24b"
STRICT_SOURCE_SHA256 = "1871066702442a41a615ebcbe9d91b3c6178b35d1021151c27c0ea779ac6f3c1"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


class R9J7DeadLabelPipelineCleanupTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.source = SERVER.read_text(encoding="utf-8")
        cls.tree = ast.parse(cls.source)
        cls.contract = json.loads(CONTRACT.read_text(encoding="utf-8"))
        cls.definitions = {
            node.name: node
            for node in cls.tree.body
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        }

    def test_01_obsolete_label_pipeline_is_completely_absent(self) -> None:
        for name in ("_generate_labels_json", "_edge_name_from_code", "_guess_sheet_dxf_file"):
            self.assertNotIn(name, self.definitions)

    def test_02_legacy_schema_v1_label_markers_are_absent(self) -> None:
        for token in ("rotation_deg_cw", "edge_H1", "Sheet_{sheet_index:03d}"):
            self.assertNotIn(token, self.source)

    def test_03_strict_generator_remains_the_single_active_owner(self) -> None:
        self.assertIn("_generate_labels_json_strict", self.definitions)
        self.assertEqual(self.source.count("def _generate_labels_json_strict(job_root: Path)"), 1)
        self.assertEqual(self.source.count("'schema_version': 2"), 1)
        self.assertIn("raise SafetyContractError('labels do not match requested panel instances')", self.source)

    def test_04_finalization_service_keeps_one_strict_callback(self) -> None:
        callback = "generate_labels=lambda root: _generate_labels_json_strict(root)"
        self.assertEqual(self.source.count(callback), 1)
        calls = [
            node
            for node in ast.walk(self.tree)
            if isinstance(node, ast.Call)
            and isinstance(node.func, ast.Name)
            and node.func.id == "_generate_labels_json_strict"
        ]
        self.assertEqual(len(calls), 1)

    def test_05_active_strict_generator_source_is_byte_exact(self) -> None:
        node = self.definitions["_generate_labels_json_strict"]
        segment = ast.get_source_segment(self.source, node)
        self.assertIsNotNone(segment)
        self.assertEqual(hashlib.sha256(segment.encode("utf-8")).hexdigest(), STRICT_SOURCE_SHA256)
        protected = self.contract["protectedActiveOwner"]
        self.assertEqual(len(segment.encode("utf-8")), protected["bytes"])
        self.assertEqual(node.end_lineno - node.lineno + 1, protected["lines"])

    def test_06_server_identity_and_reduction_are_sealed(self) -> None:
        evidence = self.contract["sizeEvidence"]
        self.assertEqual(evidence["serverAfter"]["sha256"], R9J7_SERVER_SHA256)
        self.assertEqual(evidence["serverBefore"]["lines"], 14884)
        self.assertEqual(evidence["serverAfter"]["lines"], 14706)
        self.assertEqual(evidence["serverReduction"], {"bytes": 6654, "lines": 178})
        self.assertLessEqual(len(self.source.splitlines()), evidence["serverAfter"]["lines"])

    def test_07_contract_is_explicitly_provisional_and_behavior_preserving(self) -> None:
        self.assertEqual(self.contract["contractId"], "R9J7_DEAD_LABEL_PIPELINE_CLEANUP")
        self.assertEqual(self.contract["status"], "PROVISIONAL_DEVELOPMENT_ONLY")
        self.assertFalse(self.contract["releaseEligible"])
        self.assertFalse(self.contract["cleanup"]["activeRuntimePathChanged"])
        self.assertEqual(self.contract["executableEvidence"]["cleanupTestCount"], 7)


if __name__ == "__main__":
    unittest.main(verbosity=2)
