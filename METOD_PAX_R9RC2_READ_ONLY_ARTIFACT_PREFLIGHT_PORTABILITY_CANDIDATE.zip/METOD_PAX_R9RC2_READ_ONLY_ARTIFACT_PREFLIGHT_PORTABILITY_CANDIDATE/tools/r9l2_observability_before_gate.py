#!/usr/bin/env python3
from __future__ import annotations

"""Reproduce the sealed R9L1 observability behavior used by R9L2."""

import argparse
import ast
import hashlib
import json
import os
import sys
import tempfile
import types
from pathlib import Path
from unittest import mock


ROOT = Path(__file__).resolve().parents[1]
SERVER = ROOT / "app/server_py.py"
FIXTURE = ROOT / "R9L2_OBSERVABILITY_METRICS_BEFORE_FIXTURE.json"
APP = ROOT / "app"
os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")
_STATE_TEMP = tempfile.TemporaryDirectory(prefix="r9l2_observability_import_")
os.environ.setdefault("METOD_STATE_ROOT", str(Path(_STATE_TEMP.name) / "state"))
sys.path.insert(0, str(APP))

import server_py as server  # noqa: E402


OWNER_NAMES = (
    "_append_system_event",
    "_read_system_events",
    "_readiness_report",
    "_prometheus_metrics",
)


class FakeVfs:
    f_favail = 20_000


class FakeUsage:
    free = 5 * 1024 * 1024 * 1024


def _source_metrics(source: str) -> dict[str, object]:
    tree = ast.parse(source)
    owners: dict[str, object] = {}
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name in OWNER_NAMES:
            segment = ast.get_source_segment(source, node)
            if segment is None:
                raise RuntimeError(f"cannot read source for {node.name}")
            owners[node.name] = {
                "lines": len(segment.splitlines()),
                "bytes": len(segment.encode("utf-8")),
                "sha256": hashlib.sha256(segment.encode("utf-8")).hexdigest(),
            }
    return {
        "server": {
            "bytes": len(source.encode("utf-8")),
            "lines": len(source.splitlines()),
            "sha256": hashlib.sha256(source.encode("utf-8")).hexdigest(),
        },
        "activeOwnerSource": owners,
        "activeCallCountsExcludingDefinition": {
            name: source.count(f"{name}(") - 1 for name in OWNER_NAMES
        },
    }


def _readiness(root: Path, records: list[dict], *, production: bool = False):
    system = root / "system"
    state = root / "state"
    dxf = root / "dxf"
    for path in (system, state, dxf):
        path.mkdir(parents=True, exist_ok=True)
    (dxf / "seed.dxf").write_text("0\nEOF\n", encoding="utf-8")
    material = root / "material_library.json"
    material.write_text(json.dumps({"records": records}), encoding="utf-8")
    environment = {}
    if production:
        signoff = system / "catalog_signoff.json"
        signoff.write_text(
            json.dumps({
                "approved": True,
                "approvedBy": "auditor",
                "approvedAt": "2026-08-25T07:00:00Z",
                "materialLibrarySha256": server.sha256_file(material),
            }),
            encoding="utf-8",
        )
        environment["CATALOG_SIGNOFF_FILE"] = str(signoff)
    with (
        mock.patch.dict(os.environ, environment, clear=False),
        mock.patch.multiple(
            server,
            MATERIAL_LIBRARY_PATH=material,
            SYSTEM_DIR=system,
            STATE_ROOT=state,
            DXF_LIBRARY_ROOT=dxf,
        ),
        mock.patch.object(server, "_is_production_hardening_enabled", return_value=production),
        mock.patch.object(server, "_load_pricing_config", return_value={"currency": "EUR"}),
        mock.patch.object(server, "_env_int", side_effect=lambda _name, default: default),
        mock.patch.object(server.shutil, "disk_usage", return_value=FakeUsage()),
        mock.patch.object(server.os, "statvfs", return_value=FakeVfs()),
        mock.patch.object(server.secrets, "token_hex", return_value="abcd1234"),
        mock.patch.object(server.os, "getpid", return_value=4321),
    ):
        payload, status = server._readiness_report()
    return [payload, status]


def _behavior() -> dict[str, object]:
    with tempfile.TemporaryDirectory(prefix="r9l2_observability_gate_") as temp_name:
        root = Path(temp_name)
        system = root / "events-system"
        log = system / "system_events.jsonl"
        with (
            mock.patch.multiple(server, SYSTEM_DIR=system, SYSTEM_LOG_FILE=log),
            mock.patch.object(server, "_now_iso", return_value="2026-08-25T07:00:00"),
            mock.patch.object(server, "_env_int", side_effect=lambda _name, default: default),
        ):
            server._append_system_event(
                level=" warning ",
                component=" test ",
                message_user="  Gebruikerbericht  ",
                message_tech="Authorization: Bearer TOP_SECRET",
                request_id="REQ-1",
                job_id="JOB-1",
                customer_name="Must Not Persist",
                status=" open ",
                details={
                    "token": "TOP_SECRET",
                    "nested": {"authorization": "Bearer ALSO_SECRET"},
                },
            )
            events = server._read_system_events(limit=200)

        valid = [{
            "sourceKind": "CATALOG_IMPORT",
            "active": True,
            "archived": False,
            "published": True,
            "catalogMissing": False,
            "catalogExcluded": False,
        }]
        ready_ok = _readiness(root / "ready-ok", valid)
        ready_bad = _readiness(root / "ready-bad", [])
        ready_production = _readiness(root / "ready-production", valid, production=True)

        material = root / "metrics-material.json"
        material.write_text(json.dumps({"records": [{}, {}, {}]}), encoding="utf-8")
        jobs = root / "jobs"
        requests = root / "requests"
        pending = root / "pending"
        processing = root / "processing"
        state = root / "metrics-state"
        for path in (jobs, requests, pending, processing, state):
            path.mkdir(parents=True, exist_ok=True)
        (jobs / "a").mkdir()
        (jobs / "b").mkdir()
        (requests / "r").mkdir()
        (pending / "1.json").write_text("{}", encoding="utf-8")
        (pending / "2.json").write_text("{}", encoding="utf-8")
        (processing / "3.json").write_text("{}", encoding="utf-8")
        with (
            mock.patch.multiple(
                server,
                MATERIAL_LIBRARY_PATH=material,
                JOBS=jobs,
                REQUESTS=requests,
                QUEUE_PENDING=pending,
                QUEUE_PROCESSING=processing,
                STATE_ROOT=state,
                _SSE_CLIENTS=[1, 2],
                _PUBLIC_JOB_CREATE_TOTAL=7,
                _PUBLIC_JOB_ACTIVE_TOTAL=2,
                _PUBLIC_JOB_QUEUE=[1, 2, 3],
                _PUBLIC_JOB_RESERVED_TOTAL=1,
            ),
            mock.patch.object(server.shutil, "disk_usage", return_value=FakeUsage()),
        ):
            metrics = server._prometheus_metrics()

    return {
        "systemEventScenario": events,
        "readinessOk": ready_ok,
        "readinessCatalogFailure": ready_bad,
        "readinessProductionSignoff": ready_production,
        "prometheusText": metrics,
    }


def _route_projection() -> dict[str, object]:
    detailed = {
        "ok": True,
        "build": server.SECURITY_BUILD,
        "checks": {"freeBytes": True, "catalogSignoff": True},
        "details": {"freeBytes": 123456789, "catalogSignoffActor": "private-admin"},
    }

    def handler(path: str):
        value = object.__new__(server.Handler)
        value.path = path
        value.client_address = ("127.0.0.1", 12345)
        value.headers = {}
        value.responses = []
        value._send_json = types.MethodType(
            lambda self, payload, status=200, headers=None: (int(status), payload), value
        )
        return value

    with mock.patch.object(server, "_readiness_report", return_value=(detailed, 200)):
        public_status, public = server.Handler.do_GET(handler("/health/ready"))
        admin = handler("/api/admin/health/ready")
        admin._require_admin_auth = types.MethodType(lambda self: True, admin)
        admin_status, admin_payload = server.Handler.do_GET(admin)
    if public_status != 200 or admin_status != 200 or admin_payload != detailed:
        raise AssertionError("readiness route projection changed")
    return {
        "publicReadyKeys": sorted(public),
        "publicReadyDisclosesChecks": "checks" in public or "details" in public,
        "adminReadyReturnsDetailedPayload": admin_payload == detailed,
        "adminMetricsContentType": "text/plain; version=0.0.4; charset=utf-8",
        "adminRoutesRequireAuthenticationBeforeDispatch": True,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--source-check",
        action="store_true",
        help="also require the exact pre-extraction R9L1 server source",
    )
    args = parser.parse_args()
    fixture = json.loads(FIXTURE.read_text(encoding="utf-8"))
    actual = _behavior()
    actual["routeProjection"] = _route_projection()
    expected = {key: fixture[key] for key in actual}
    if actual != expected:
        raise AssertionError(json.dumps({"expected": expected, "actual": actual}, indent=2))
    if args.source_check:
        source_actual = _source_metrics(SERVER.read_text(encoding="utf-8", errors="strict"))
        source_expected = {
            key: fixture[key]
            for key in ("server", "activeOwnerSource", "activeCallCountsExcludingDefinition")
        }
        if source_actual != source_expected:
            raise AssertionError(json.dumps({"expected": source_expected, "actual": source_actual}, indent=2))
    print(json.dumps({
        "schemaVersion": 1,
        "gate": "R9L2_OBSERVABILITY_BEFORE_GATE",
        "status": "PASS",
        "sourceCheck": bool(args.source_check),
        "behaviorScenarios": 5,
        "sealedRoutes": 5,
    }, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
