#!/usr/bin/env python3
from __future__ import annotations

"""Executable contracts for the R9J-4 notification projection extraction."""

import ast
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / 'app'
sys.path.insert(0, str(APP))

from metod_app.notifications.projections import (  # noqa: E402
    merge_notification_pricing,
    parse_calculation_summary,
    privacy_safe_customer_lines,
)


SUMMARY = """Berekening
Aantal panelen: 12
Aantal platen: 3

Materialen / platen
--------------------
- U999 ST2 Zwart
  Platen: 2 | Dikte: 18 mm | Plaatmaat: 2800 x 2070 mm
  Plaatprijs incl. btw: € 100,00
- H1180 ST37 Halifax eik
  Dikte: 18 mm | Plaatmaat: 2800 x 2070 mm | Platen: 1
  Opslagfactor: 1,15

Kantenband (m¹) per decor
--------------------------
- U999: 12,50 m
- H1180: 1.234,56 m

Kostenopbouw
------------
Plaatmateriaal incl. btw: € 1.234,56
Plaatmateriaal netto-equivalent: € 1.020,30
BTW reeds in plaatprijs: € 214,26
Overige kosten excl. btw: € 100,00
BTW over overige kosten: € 21,00
Kantenband excl. btw: € 20,00
CNC excl. btw: € 30,00
Tekenen excl. btw: € 10,00
Transport excl. btw: € 40,00
Subtotaal excl. btw: € 1.120,30
BTW (21%): € 235,26
Totaal incl. btw: € 1.355,56
"""


class R9J4NotificationProjectionTests(unittest.TestCase):
    def test_01_empty_summary_has_stable_shape(self) -> None:
        self.assertEqual(
            parse_calculation_summary(''),
            {
                'panelsTotal': None,
                'platesTotal': None,
                'materials': [],
                'edgeMeters': [],
                'pricing': {},
            },
        )

    def test_02_summary_projection_preserves_counts_materials_edges_and_prices(self) -> None:
        projected = parse_calculation_summary(SUMMARY)
        self.assertEqual(projected['panelsTotal'], 12)
        self.assertEqual(projected['platesTotal'], 3)
        self.assertEqual(
            projected['materials'],
            [
                {
                    'label': 'U999 ST2 Zwart',
                    'detail': 'Platen: 2 | Dikte: 18 mm | Plaatmaat: 2800 x 2070 mm',
                },
                {
                    'label': 'H1180 ST37 Halifax eik',
                    'detail': 'Dikte: 18 mm | Plaatmaat: 2800 x 2070 mm | Platen: 1',
                },
            ],
        )
        self.assertEqual(
            projected['edgeMeters'],
            [
                {'label': 'U999', 'meters': 12.5},
                {'label': 'H1180', 'meters': 1234.56},
            ],
        )
        self.assertEqual(
            projected['pricing'],
            {
                'materialsTotalInclVat': 1234.56,
                'materialsTotal': 1020.3,
                'materialsVatIncluded': 214.26,
                'otherCostsExVat': 100.0,
                'otherCostsVat': 21.0,
                'edgeBandTotal': 20.0,
                'cncTotal': 30.0,
                'drawingTotal': 10.0,
                'transportTotal': 40.0,
                'subtotalExVat': 1120.3,
                'vatAmount': 235.26,
                'totalInclVat': 1355.56,
            },
        )

    def test_03_pricing_precedence_is_calculation_then_authoritative_then_summary(self) -> None:
        merged = merge_notification_pricing(
            {'materialsPrice': '10.25', 'priceInclVat': '20.50'},
            {'pricing': {'totalInclVat': 33.0, 'cncTotal': 4.0, 'ignoredNone': None}},
            {'totalInclVat': 30.0, 'cncTotal': 3.0, 'transportTotal': 8.0},
        )
        self.assertEqual(
            merged,
            {
                'materialsTotal': 10.25,
                'totalInclVat': 33.0,
                'cncTotal': 4.0,
                'transportTotal': 8.0,
            },
        )

    def test_04_invalid_legacy_summary_price_does_not_escape(self) -> None:
        self.assertEqual(
            merge_notification_pricing(
                {'materialsPrice': 'not-a-number', 'priceInclVat': '21.00'},
                {},
                {'totalInclVat': 30.0},
            ),
            {'totalInclVat': 30.0},
        )

    def test_05_customer_details_are_private_by_default(self) -> None:
        lines = ['Klant', 'Naam: Voorbeeld', 'Email: klant@example.invalid']
        self.assertEqual(
            privacy_safe_customer_lines(lines, include_customer_details=False),
            [],
        )

    def test_06_explicit_customer_projection_is_allowlisted_truncated_and_bounded(self) -> None:
        long_note = 'x' * 240
        source = [
            'Aanvraag REQ-1',
            'Request ID: REQ-1',
            'Datum: vandaag',
            '----------------',
            'Klant',
            'Naam: Voorbeeld',
            'Email: klant@example.invalid',
            'Telefoon: 0612345678',
            'Niet toegestaan: geheim',
            'Adres',
            'Factuur: Straat 1',
            'Bezorg: Straat 2',
            'Plaats: Utrecht',
            'Land: NL',
            'Restmateriaal',
            'Meeleveren: ja',
            'Opmerking klant',
            long_note,
            'extra regel',
        ]
        projected = privacy_safe_customer_lines(source, include_customer_details=True)
        self.assertEqual(len(projected), 10)
        self.assertEqual(
            projected[:8],
            [
                'Naam: Voorbeeld',
                'Email: klant@example.invalid',
                'Telefoon: 0612345678',
                'Factuur: Straat 1',
                'Bezorg: Straat 2',
                'Plaats: Utrecht',
                'Land: NL',
                'Restmateriaal Meeleveren: ja',
            ],
        )
        self.assertEqual(projected[8], 'Opmerking: ' + ('x' * 220))
        self.assertEqual(projected[9], 'Opmerking: extra regel')
        self.assertNotIn('Niet toegestaan: geheim', projected)

    def test_07_projection_module_has_no_side_effect_boundary_imports_or_calls(self) -> None:
        path = APP / 'metod_app/notifications/projections.py'
        tree = ast.parse(path.read_text(encoding='utf-8'))
        imported_roots = {
            alias.name.split('.')[0]
            for node in ast.walk(tree)
            if isinstance(node, ast.Import)
            for alias in node.names
        }
        imported_roots.update(
            node.module.split('.')[0]
            for node in ast.walk(tree)
            if isinstance(node, ast.ImportFrom) and node.module
        )
        self.assertTrue(imported_roots.isdisjoint(
            {'os', 'pathlib', 'socket', 'subprocess', 'threading', 'urllib', 'http'}
        ))
        called_names = {
            node.func.id
            for node in ast.walk(tree)
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
        }
        self.assertTrue(called_names.isdisjoint({'open', 'print', 'exec', 'eval'}))

    def test_08_server_is_a_composition_root_not_the_projection_owner(self) -> None:
        server_tree = ast.parse((APP / 'server_py.py').read_text(encoding='utf-8'))
        defined = {
            node.name
            for node in server_tree.body
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        }
        self.assertNotIn('_parse_calculation_summary_for_ntfy', defined)
        self.assertNotIn('_merge_ntfy_pricing', defined)
        self.assertIn('_ntfy_public_safe_customer_lines', defined)

        notification_imports = [
            node
            for node in server_tree.body
            if isinstance(node, ast.ImportFrom)
            and node.module == 'metod_app.notifications.projections'
        ]
        self.assertEqual(len(notification_imports), 1)
        aliases = {alias.asname for alias in notification_imports[0].names}
        self.assertEqual(
            aliases,
            {
                '_merge_ntfy_pricing',
                '_parse_calculation_summary_for_ntfy',
                '_privacy_safe_customer_lines',
            },
        )


if __name__ == '__main__':
    unittest.main(verbosity=2)
