#!/usr/bin/env python3
from __future__ import annotations

"""Fail-closed runtime contract for R9F-5 POST/OPTIONS matcher adoption."""

import ast
import hashlib
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
SERVER = APP / "server_py.py"
MATCHER = APP / "metod_app/http/matcher.py"
sys.path.insert(0, str(APP))

from metod_app.http.matcher import match_route  # noqa: E402
from metod_app.http.routes import ROUTES  # noqa: E402


SERVER_SHA256 = "84b3b0d3713d4d6da472d6b7d4351e166aac59e1fde1812cf60ccbd84d77556a"
DISPATCH_SOURCE_SHA256 = "942a8dd716b4a05b19e8b48e85d06fd730352e7f64ea0541db501fbda5a1a775"
API_HANDLER_SOURCE_SHA256 = "1829a4e59a0ac41f869b0d1793977b2e42ff9d39e9fbccb24c2a46303efddfb7"


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def handler_methods(source: str) -> dict[str, str]:
    result: dict[str, str] = {}
    tree = ast.parse(source)
    for node in tree.body:
        if isinstance(node, ast.ClassDef) and node.name == "Handler":
            for item in node.body:
                if isinstance(item, ast.FunctionDef):
                    segment = ast.get_source_segment(source, item)
                    if segment is not None:
                        result[item.name] = segment
    return result


class MutatingRouteDispatchTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.server = SERVER.read_text(encoding="utf-8")
        cls.methods = handler_methods(cls.server)
        cls.options = cls.methods["do_OPTIONS"]
        cls.post = cls.methods["do_POST"]
        cls.post_impl = cls.methods["_do_POST_impl"]

    def test_01_options_and_post_use_the_same_pure_matcher(self) -> None:
        marker = "from metod_app.http.matcher import match_route as _match_http_route"
        self.assertEqual(self.server.count(marker), 1)
        self.assertEqual(self.options.count("_match_http_route('OPTIONS', self.path)"), 1)
        self.assertEqual(self.post.count("_match_http_route('POST', self.path)"), 1)

    def test_02_options_wildcard_preserves_the_bodyless_204(self) -> None:
        self.assertIn("route_key == 'OPTIONS *'", self.options)
        self.assertIn("self.send_response(204)", self.options)
        self.assertIn("self.end_headers()", self.options)
        self.assertEqual(match_route("OPTIONS", "/any/request-target").key, "OPTIONS *")

    def test_03_post_classifies_once_and_passes_the_key_to_dispatch(self) -> None:
        self.assertEqual(self.post.count("_match_http_route('POST', self.path)"), 1)
        self.assertEqual(self.post.count("self._do_POST_impl(route_key)"), 2)
        self.assertNotIn("urlparse(self.path).path", self.post)

    def test_04_backup_keeps_its_dedicated_barrier_bypass(self) -> None:
        backup = "route_key == 'POST /api/admin/system/backup_now'"
        begin = "_STATE_MAINTENANCE_BARRIER.begin_mutation()"
        self.assertIn(backup, self.post)
        self.assertIn(begin, self.post)
        self.assertLess(self.post.index(backup), self.post.index(begin))
        self.assertEqual(self.post.count("_STATE_MAINTENANCE_BARRIER.end_mutation()"), 1)

    def test_05_direct_internal_dispatch_still_classifies_safely(self) -> None:
        self.assertIn("def _do_POST_impl(self, route_key=None):", self.post_impl)
        self.assertIn("if route_key is None:", self.post_impl)
        self.assertEqual(self.post_impl.count("_match_http_route('POST', self.path)"), 1)
        self.assertTrue(self.post_impl.rstrip().endswith("return self._send_text('Not found', 404)"))

    def test_06_admin_auth_and_origin_prefix_policy_remains_in_handler(self) -> None:
        login = "route_key == 'POST /api/admin/login'"
        admin = "parsed.path in ('/admin', '/admin/') or parsed.path.startswith('/api/admin/')"
        self.assertIn(login, self.post_impl)
        self.assertIn(admin, self.post_impl)
        self.assertLess(self.post_impl.index(login), self.post_impl.index(admin))
        self.assertEqual(self.post_impl.count("self._require_admin_auth()"), 2)
        self.assertEqual(self.post_impl.count("self._require_admin_write_origin()"), 3)

    def test_07_public_same_origin_route_set_is_exact(self) -> None:
        expected = {
            "POST /api/submit_config", "POST /api/cancel", "POST /api/jobs/cancel",
            "POST /api/jobs", "POST /api/draft/save", "POST /api/client_log",
        }
        for key in expected:
            self.assertEqual(self.post_impl.count(repr(key)), 2, key)
        self.assertEqual(self.post_impl.count("self._require_same_origin_public_write()"), 1)

    def test_08_all_25_post_routes_have_one_existing_dispatch_branch(self) -> None:
        routes = [route for route in ROUTES if route.method == "POST"]
        self.assertEqual(len(routes), 25)
        combined = self.post + "\n" + self.post_impl
        for route in routes:
            self.assertIn(repr(route.key), combined, route.key)
            self.assertEqual(match_route("POST", route.pattern).key, route.key)

    def test_09_all_32_api_handlers_remain_exact(self) -> None:
        names = sorted(name for name in self.methods if name.startswith("_api_"))
        self.assertEqual(len(names), 32)
        source = "\n".join(self.methods[name] for name in names).encode()
        self.assertEqual(hashlib.sha256(source).hexdigest(), API_HANDLER_SOURCE_SHA256)

    def test_10_dispatch_server_and_matcher_are_exactly_bound(self) -> None:
        dispatch = "\n".join(
            self.methods[name] for name in ("do_OPTIONS", "do_POST", "_do_POST_impl")
        ).encode()
        self.assertEqual(hashlib.sha256(dispatch).hexdigest(), DISPATCH_SOURCE_SHA256)
        self.assertEqual(digest(SERVER), SERVER_SHA256)
        matcher = MATCHER.read_text(encoding="utf-8")
        self.assertNotIn("Handler(", matcher)
        self.assertNotIn("_read_json_body", matcher)


if __name__ == "__main__":
    unittest.main(verbosity=2)
