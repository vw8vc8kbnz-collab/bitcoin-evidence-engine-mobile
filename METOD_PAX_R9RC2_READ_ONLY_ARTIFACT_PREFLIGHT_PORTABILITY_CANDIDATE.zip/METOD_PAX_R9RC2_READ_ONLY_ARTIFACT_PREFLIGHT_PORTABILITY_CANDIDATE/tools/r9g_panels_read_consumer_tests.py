#!/usr/bin/env python3
from __future__ import annotations

"""Fail-closed R9G-3 proof for the read-only panels view consumer."""

import ast
import base64
import hashlib
import json
import shutil
import subprocess
import unittest
from pathlib import Path

from r9h_shell_source import read_toola_expanded


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
SELECTORS = APP / "tool-a/state/selectors.js"
STORE = APP / "tool-a/state/store.js"
MATERIALS = APP / "tool-a/steps/materials.js"
PANELS = APP / "tool-a/steps/panels.js"
GRAIN = APP / "tool-a/steps/grain.js"
CUSTOMER = APP / "tool-a/steps/customer.js"
JOBS = APP / "tool-a/api/jobs.js"
REQUESTS = APP / "tool-a/api/requests.js"
DIALOG = APP / "tool-a/components/dialog.js"
FOOTER = APP / "tool-a/components/footer.js"
GRAIN_PREVIEW = APP / "tool-a/components/grain-preview.js"
CHECKOUT_REVIEW = APP / "tool-a/components/checkout-review.js"
MATERIAL_CARD = APP / "tool-a/components/material-card.js"
PANEL_EDITOR = APP / "tool-a/components/panel-editor.js"
MOBILE_CART = APP / "tool-a/components/mobile-material-cart.js"
OVERLAY_ROUTER = APP / "tool-a/components/overlay-router.js"
PROGRESS = APP / "tool-a/components/progress-overlay.js"
THANK_YOU = APP / "tool-a/components/thank-you.js"
BOOTSTRAP = APP / "tool-a/bootstrap.js"
HTML = APP / "toolA.html"
RULES = ROOT / "R9B_ARCHITECTURE_RULES.json"


def data_url(data: bytes) -> str:
    return "data:text/javascript;base64," + base64.b64encode(data).decode()


def linked_sources() -> tuple[str, str]:
    selectors_url = data_url(SELECTORS.read_bytes())
    store_source = STORE.read_text(encoding="utf-8").replace("./selectors.js", selectors_url)
    store_url = data_url(store_source.encode())
    materials_url = data_url(MATERIALS.read_bytes())
    panels_url = data_url(PANELS.read_bytes())
    grain_url = data_url(GRAIN.read_bytes())
    customer_url = data_url(CUSTOMER.read_bytes())
    bootstrap_source = BOOTSTRAP.read_text(encoding="utf-8")
    bootstrap_source = bootstrap_source.replace("./state/store.js", store_url)
    bootstrap_source = bootstrap_source.replace("./steps/materials.js", materials_url)
    bootstrap_source = bootstrap_source.replace("./steps/panels.js", panels_url)
    bootstrap_source = bootstrap_source.replace("./steps/grain.js", grain_url)
    bootstrap_source = bootstrap_source.replace("./steps/customer.js", customer_url)
    bootstrap_source = bootstrap_source.replace("./api/jobs.js", data_url(JOBS.read_bytes()))
    bootstrap_source = bootstrap_source.replace("./api/requests.js", data_url(REQUESTS.read_bytes()))
    bootstrap_source = bootstrap_source.replace("./components/dialog.js", data_url(DIALOG.read_bytes()))
    bootstrap_source = bootstrap_source.replace("./components/footer.js", data_url(FOOTER.read_bytes()))
    bootstrap_source = bootstrap_source.replace("./components/grain-preview.js", data_url(GRAIN_PREVIEW.read_bytes()))
    bootstrap_source = bootstrap_source.replace("./components/checkout-review.js", data_url(CHECKOUT_REVIEW.read_bytes()))
    bootstrap_source = bootstrap_source.replace("./components/material-card.js", data_url(MATERIAL_CARD.read_bytes()))
    bootstrap_source = bootstrap_source.replace("./components/panel-editor.js", data_url(PANEL_EDITOR.read_bytes()))
    bootstrap_source = bootstrap_source.replace("./components/mobile-material-cart.js", data_url(MOBILE_CART.read_bytes()))
    bootstrap_source = bootstrap_source.replace("./components/overlay-router.js", data_url(OVERLAY_ROUTER.read_bytes()))
    bootstrap_source = bootstrap_source.replace("./components/progress-overlay.js", data_url(PROGRESS.read_bytes()))
    bootstrap_source = bootstrap_source.replace("./components/thank-you.js", data_url(THANK_YOU.read_bytes()))
    return panels_url, data_url(bootstrap_source.encode())


def run_node(source: str) -> dict:
    node = shutil.which("node")
    if not node:
        raise AssertionError("Node is required by the release architecture gate")
    completed = subprocess.run(
        [node, "--input-type=module"], input=source, text=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=10, check=False,
    )
    if completed.returncode != 0:
        raise AssertionError(completed.stdout)
    return json.loads(completed.stdout.strip().splitlines()[-1])


class R9GPanelsReadConsumerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.panels_url, cls.bootstrap_url = linked_sources()

    def test_01_panels_module_is_pure_and_owner_free(self) -> None:
        source = PANELS.read_text(encoding="utf-8")
        for token in (
            "window", "globalThis", "document", "addEventListener", "fetch(",
            "localStorage", "sessionStorage", "dispatch", "subscribe", "setState",
            "XMLHttpRequest", "EventSource",
        ):
            self.assertNotIn(token.lower(), source.lower(), token)
        self.assertIn("export function selectPanelsView", source)
        self.assertIn("export function createPanelsViewConsumer", source)

    def test_02_projection_is_exact_frozen_and_pii_free(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(self.panels_url)});
const view=m.selectPanelsView({{
 currentStep:'panels',standardPanelLineCount:4,extraPanelLineCount:2,hasPanels:true,
 customer:{{email:'private@example.test'}},jobBearer:'secret'
}});
console.log(JSON.stringify({{view,keys:Reflect.ownKeys(view),frozen:Object.isFrozen(view)}}));
""")
        self.assertEqual(result, {
            "view": {
                "standardPanelLineCount": 4, "extraPanelLineCount": 2,
                "totalPanelLineCount": 6, "hasPanels": True, "isPanelsStep": True,
            },
            "keys": [
                "standardPanelLineCount", "extraPanelLineCount", "totalPanelLineCount",
                "hasPanels", "isPanelsStep",
            ],
            "frozen": True,
        })
        serialized = json.dumps(result).lower()
        for forbidden in ("private@example.test", "secret", "customer", "bearer"):
            self.assertNotIn(forbidden, serialized)

    def test_03_invalid_counts_fail_closed_without_hiding_valid_presence(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(self.panels_url)});
const values=[null,[],{{standardPanelLineCount:-1,extraPanelLineCount:1.5}},{{hasPanels:true}}];
console.log(JSON.stringify(values.map(value=>m.selectPanelsView(value))));
""")
        empty = {
            "standardPanelLineCount": 0, "extraPanelLineCount": 0,
            "totalPanelLineCount": 0, "hasPanels": False, "isPanelsStep": False,
        }
        self.assertEqual(result[0], empty)
        self.assertEqual(result[1], empty)
        self.assertEqual(result[2], empty)
        self.assertTrue(result[3]["hasPanels"])

    def test_04_consumer_reads_fresh_snapshots_without_caching(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(self.panels_url)});
let snapshot={{currentStep:'material',standardPanelLineCount:0,extraPanelLineCount:0,hasPanels:false}};
const consumer=m.createPanelsViewConsumer({{getSnapshot:()=>snapshot}});
const first=consumer.getView();
snapshot={{currentStep:'panels',standardPanelLineCount:2,extraPanelLineCount:1,hasPanels:true}};
const second=consumer.getView();
console.log(JSON.stringify({{first,second,separate:first!==second}}));
""")
        self.assertFalse(result["first"]["hasPanels"])
        self.assertEqual(result["second"]["totalPanelLineCount"], 3)
        self.assertTrue(result["second"]["isPanelsStep"])
        self.assertTrue(result["separate"])

    def test_05_consumer_surface_is_read_only_and_fail_safe(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(self.panels_url)});
const consumer=m.createPanelsViewConsumer({{getSnapshot:()=>{{throw new Error('boom')}}}});
let rejected=false;try{{m.createPanelsViewConsumer({{}})}}catch(_error){{rejected=true}}
console.log(JSON.stringify({{
 keys:Reflect.ownKeys(consumer),frozen:Object.isFrozen(consumer),view:consumer.getView(),rejected
}}));
""")
        self.assertEqual(result["keys"], ["getView"])
        self.assertTrue(result["frozen"])
        self.assertTrue(result["rejected"])
        self.assertFalse(result["view"]["hasPanels"])

    def test_06_bootstrap_publishes_one_frozen_read_only_adapter(self) -> None:
        result = run_node(f"""
globalThis.state={{cart:[{{id:'P1'}}],extraPanels:[{{id:'E1'}}]}};
globalThis.__metod_uiStep='panels';
const m=await import({json.dumps(self.bootstrap_url)});
const adapter=globalThis.ToolAR9Foundation;
console.log(JSON.stringify({{
 revision:adapter.revision,mode:adapter.mode,keys:Reflect.ownKeys(adapter),
 view:adapter.getPanelsView(),frozen:Object.isFrozen(adapter),
 consumerKeys:Reflect.ownKeys(m.panelsViewConsumer),
 mutation:['dispatch','subscribe','setState','replaceState'].some(key=>key in adapter)
}}));
""")
        self.assertEqual(result["revision"], "R9I_SYNC_CATALOG_REFRESH_CLEANUP_9")
        self.assertEqual(result["mode"], "legacy-read-cleanup-adapter")
        self.assertTrue(set([
            "revision", "mode", "getSnapshot", "getMaterialsView", "getPanelsView",
            "getGrainView", "getCustomerView", "startJob", "pollJob",
            "fetchJobPricingSummary", "authoritativeTotalInclVat",
            "submitFinalConfiguration", "resetFinalSubmission", "getFinalSubmissionState",
        ]).issubset(result["keys"]))
        self.assertEqual(result["consumerKeys"], ["getView"])
        self.assertEqual(result["view"]["totalPanelLineCount"], 2)
        self.assertTrue(result["frozen"])
        self.assertFalse(result["mutation"])

    def test_07_legacy_panel_presence_and_price_bar_have_exact_fallbacks(self) -> None:
        source = read_toola_expanded(HTML)
        self.assertEqual(source.count("function r9PanelsView()"), 1)
        self.assertEqual(source.count("window.ToolAR9Foundation?.getPanelsView?.()"), 1)
        self.assertIn("typeof view.hasPanels === 'boolean'", source)
        self.assertIn("Number.isSafeInteger(panelsView.totalPanelLineCount)", source)
        self.assertIn("(state?.cart?.length||0) + (state?.extraPanels?.length||0)", source)
        self.assertIn("((st.cart && st.cart.length) || (st.extraPanels && st.extraPanels.length))", source)

    def test_08_panel_mutation_grain_optimizer_and_submit_owners_are_unchanged(self) -> None:
        expected = {
            "toolA_panel_mutations.js": "4fd36df984c6416e0e394397ecafd53c0f20a6e432bf8330226c03ef00230356",
            "toolA_panel_submit_flow.js": "5010767a8a40922fca1969e5751c2ecf4c6bad627b933da4172a18c62ccae86e",
            "toolA_grain_studio_renderer.js": "922cd4ac479fbaf86ebfbb0256808119b96a8344e9b0bf1ffb4f668518a03204",
            "dxf_nesting_optimizer.py": "42480b301cd660dac1e5e9fec2c8d30bb5c6826c32234a9c1cce765b758bebb8",
        }
        for name, digest in expected.items():
            self.assertEqual(hashlib.sha256((APP / name).read_bytes()).hexdigest(), digest, name)
        module_source = PANELS.read_text(encoding="utf-8")
        for owner in ("applyUpsert", "remove", "submit", "optimiz", "grainGroup"):
            self.assertNotIn(owner.lower(), module_source.lower())

    def test_09_static_module_graph_and_html_revision_are_exact(self) -> None:
        rules = json.loads(RULES.read_text(encoding="utf-8"))["frontend"]
        self.assertTrue(set([
            "tool-a/bootstrap.js", "tool-a/api/jobs.js", "tool-a/api/requests.js", "tool-a/state/store.js", "tool-a/state/selectors.js",
            "tool-a/steps/materials.js", "tool-a/steps/panels.js", "tool-a/steps/grain.js",
            "tool-a/steps/customer.js",
        ]).issubset(rules["publicStaticFiles"]))
        self.assertEqual(rules["moduleImports"]["app/tool-a/steps/panels.js"], [])
        marker = '<script type="module" src="tool-a/bootstrap.js?v=r9i-sync-catalog-refresh-cleanup-9"></script>'
        self.assertEqual(read_toola_expanded(HTML).count(marker), 1)

    def test_10_server_allowlist_and_protected_algorithms_are_exact(self) -> None:
        tree = ast.parse((APP / "metod_app/http/static.py").read_text(encoding="utf-8"))
        public_files = None
        for node in tree.body:
            if isinstance(node, ast.Assign) and any(
                isinstance(target, ast.Name) and target.id == "PUBLIC_STATIC_MODULE_FILES"
                for target in node.targets
            ):
                public_files = ast.literal_eval(node.value)
                break
        self.assertTrue({
            "tool-a/bootstrap.js", "tool-a/api/jobs.js", "tool-a/api/requests.js", "tool-a/state/store.js", "tool-a/state/selectors.js",
            "tool-a/steps/materials.js", "tool-a/steps/panels.js", "tool-a/steps/grain.js",
            "tool-a/steps/customer.js",
        }.issubset(public_files))
        expected = {
            "dxf_geometry.py": "b80a2d006241908bf7b33516f7e0faf59ef61e1e08db86966b23cc5de292c1ff",
            "pricing_helpers.py": "646c2f5186e9b080f6ba8dcf364884411c18e946254bb5c9001647f7cbb425df",
            "panel_contract.py": "e23314fd63a2358a48daa580a92cebb8a40c9862548ba0243461a59347da7fc9",
        }
        for name, digest in expected.items():
            self.assertEqual(hashlib.sha256((APP / name).read_bytes()).hexdigest(), digest, name)


if __name__ == "__main__":
    unittest.main(verbosity=2)
