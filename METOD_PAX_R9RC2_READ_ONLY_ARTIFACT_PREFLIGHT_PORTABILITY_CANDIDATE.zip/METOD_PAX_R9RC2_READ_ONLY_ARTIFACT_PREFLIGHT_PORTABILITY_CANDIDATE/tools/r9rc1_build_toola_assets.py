#!/usr/bin/env python3
from __future__ import annotations

"""Build deterministic Tool A browser bundles without changing source owners.

The legacy classic scripts must retain their reviewed execution order.  The
early catalog bootstrap intentionally remains a separate blocking head asset;
the native ES-module graph remains source-native and starts after the classic
compatibility stream.  Styles are concatenated in their original cascade order.
"""

import argparse
import hashlib
import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
HTML = APP / "toolA.html"
RUNTIME_DIR = APP / "tool-a/runtime"
STYLE_DIR = APP / "tool-a/styles"
CLASSIC_BUNDLE = RUNTIME_DIR / "classic-runtime.bundle.js"
STYLE_BUNDLE = STYLE_DIR / "tool-a.bundle.css"
MANIFEST = RUNTIME_DIR / "bundle-manifest.json"
RUNTIME_COMPONENT_STYLE = "tool-a/styles/runtime-components.css"
LEGACY_SOURCE = "tool-a/shell/script-06-legacy-application-runtime.js"
LEGACY_FRAGMENT_DIR = RUNTIME_DIR / "legacy-source"
LEGACY_PARTS_MANIFEST = LEGACY_FRAGMENT_DIR / "parts.json"
LEGACY_FRAGMENT_SPECS = (
    ("01-runtime-bootstrap-state.jsfrag", 1, 774),
    ("02-materials-catalog.jsfrag", 775, 1633),
    ("03-dom-overlay-controls.jsfrag", 1634, 2054),
    ("04-panels-preview.jsfrag", 2055, 2727),
    ("05-panel-dock-overview.jsfrag", 2728, 3411),
    ("06-grain-state.jsfrag", 3412, 4000),
    ("07-grain-rendering.jsfrag", 4001, 4613),
    ("08-overlay-review.jsfrag", 4614, 5477),
    ("09-template-drawing.jsfrag", 5478, 6329),
    ("10-export-payload.jsfrag", 6330, 7143),
    ("11-customer-pricing.jsfrag", 7144, 7966),
    ("12-event-binding.jsfrag", 7967, 8691),
    ("13-fallback-renderers.jsfrag", 8692, 9577),
)

EARLY_SOURCE = "tool-a/shell/script-01-early-catalog-bootstrap.js"
MODULE_SOURCE = "tool-a/bootstrap.js"
DISABLED_SOURCE = "tool-a/shell/script-14-fix615-handle-tap-rescue.js"
OVERVIEW_SOURCE = "toolA_overview_fix655.js"
FINAL_MARKER_SOURCE = "tool-a/shell/script-34-fix655-build-marker.js"

SCRIPT_RE = re.compile(r"<script\b(?P<attrs>[^>]*)></script>", re.IGNORECASE)
LINK_RE = re.compile(r"<link\b(?P<attrs>[^>]*)>", re.IGNORECASE)
ATTR_RE = re.compile(r'([:\w-]+)\s*=\s*"([^"]*)"')


def _attrs(raw: str) -> dict[str, str]:
    return {key.lower(): value for key, value in ATTR_RE.findall(raw)}


def _asset_path(source: str) -> Path:
    relative = source.split("?", 1)[0].lstrip("/")
    candidate = (APP / relative).resolve()
    if APP.resolve() not in candidate.parents or not candidate.is_file():
        raise RuntimeError(f"bundle source is outside app or missing: {source}")
    return candidate


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _legacy_fragment_payload() -> tuple[bytes, list[dict[str, object]], bytes]:
    chunks: list[bytes] = []
    records: list[dict[str, object]] = []
    for filename, first_line, last_line in LEGACY_FRAGMENT_SPECS:
        path = LEGACY_FRAGMENT_DIR / filename
        if not path.is_file():
            raise RuntimeError(f"legacy runtime fragment is missing: {filename}")
        payload = path.read_bytes()
        actual_lines = len(payload.splitlines())
        if actual_lines < 1 or actual_lines > 900:
            raise RuntimeError(f"legacy fragment exceeds the 900-line boundary: {filename}")
        chunks.append(payload)
        records.append({
            "path": path.relative_to(APP).as_posix(),
            "originalSourceLines": [first_line, last_line],
            "lines": actual_lines,
            "bytes": len(payload),
            "sha256": _sha256(payload),
        })
    combined = b"".join(chunks)
    manifest = {
        "schemaVersion": 1,
        "build": "R9RC1_PROFESSIONAL_ARCHITECTURE_COMPLETION",
        "logicalSource": LEGACY_SOURCE,
        "assembly": "byte-exact-concatenation-without-separators",
        "maximumFragmentLines": max(int(item["lines"]) for item in records),
        "bytes": len(combined),
        "sha256": _sha256(combined),
        "fragments": records,
    }
    manifest_payload = (json.dumps(manifest, indent=2, ensure_ascii=False) + "\n").encode("utf-8")
    return combined, records, manifest_payload


def _classic_bundle(
    sources: list[str],
) -> tuple[bytes, list[dict[str, object]], bytes]:
    chunks = [
        "/* R9RC1 generated classic compatibility bundle.\n"
        " * Authoritative sources and hashes are sealed in bundle-manifest.json.\n"
        " */\n"
        "let toolAFoundation = null;\n"
        "document.addEventListener('tool-a:foundation-ready', (event) => {\n"
        "  const candidate = event && event.detail;\n"
        "  if (!candidate || toolAFoundation) return;\n"
        "  toolAFoundation = candidate;\n"
        "}, { once: true });\n"
    ]
    records: list[dict[str, object]] = []
    legacy_manifest_payload = b""
    for source in sources:
        if source == LEGACY_SOURCE:
            payload, fragments, legacy_manifest_payload = _legacy_fragment_payload()
            record: dict[str, object] = {
                "path": source,
                "sourceType": "ordered-lexical-fragments",
                "bytes": len(payload),
                "sha256": _sha256(payload),
                "fragmentManifest": LEGACY_PARTS_MANIFEST.relative_to(APP).as_posix(),
                "fragmentManifestSha256": _sha256(legacy_manifest_payload),
                "fragments": fragments,
            }
        else:
            path = _asset_path(source)
            payload = path.read_bytes()
            record = {"path": source, "bytes": len(payload), "sha256": _sha256(payload)}
        text = payload.decode("utf-8", errors="strict")
        records.append(record)
        chunks.append(f"\n/* source: {source} */\n{text}\n;\n")
    if sources.count(LEGACY_SOURCE) != 1 or not legacy_manifest_payload:
        raise RuntimeError("classic source inventory must contain one fragmented legacy runtime")
    return "".join(chunks).encode("utf-8"), records, legacy_manifest_payload


def _style_bundle(sources: list[str]) -> tuple[bytes, list[dict[str, object]]]:
    chunks = [
        "/* R9RC1 generated Tool A cascade bundle.\n"
        " * Source order and hashes are sealed in bundle-manifest.json.\n"
        " */\n"
    ]
    records: list[dict[str, object]] = []
    for source in sources:
        path = _asset_path(source)
        payload = path.read_bytes()
        text = payload.decode("utf-8", errors="strict")
        records.append({"path": source, "bytes": len(payload), "sha256": _sha256(payload)})
        chunks.append(f"\n/* source: {source} */\n{text}\n")
    return "".join(chunks).encode("utf-8"), records


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--check", action="store_true",
        help="verify that checked-in bundles exactly match their reviewed sources",
    )
    args = parser.parse_args()
    html = HTML.read_text(encoding="utf-8", errors="strict")
    already_linked = "classic-runtime.bundle.js" in html and "tool-a.bundle.css" in html
    module_tags: list[str] = []
    early_tags: list[str] = []
    disabled_tags: list[str] = []
    style_tags: list[str] = []
    if already_linked:
        current = json.loads(MANIFEST.read_text(encoding="utf-8"))
        classic_sources = [str(item["path"]) for item in current["classic"]["sources"]]
        style_sources = [str(item["path"]) for item in current["styles"]["sources"]]
        if RUNTIME_COMPONENT_STYLE not in style_sources:
            style_sources.append(RUNTIME_COMPONENT_STYLE)
    else:
        classic_sources = []
        for match in SCRIPT_RE.finditer(html):
            attributes = _attrs(match.group("attrs"))
            source = attributes.get("src", "").split("?", 1)[0]
            script_type = attributes.get("type", "").strip().lower()
            if not source:
                raise RuntimeError("inline script encountered during R9RC1 bundling")
            if source == EARLY_SOURCE:
                early_tags.append(match.group(0))
            elif script_type == "module":
                module_tags.append(match.group(0))
            elif script_type and script_type not in {"text/javascript", "application/javascript"}:
                if source != DISABLED_SOURCE:
                    raise RuntimeError(f"unexpected non-executable script type for {source}: {script_type}")
                disabled_tags.append(match.group(0))
            else:
                classic_sources.append(source)
        if len(early_tags) != 1 or len(module_tags) != 1 or len(disabled_tags) != 1:
            raise RuntimeError("Tool A script phase inventory drifted")
        if classic_sources.count(OVERVIEW_SOURCE) != 1 or classic_sources.count(FINAL_MARKER_SOURCE) != 1:
            raise RuntimeError("deferred overview/final marker contract drifted")

        # The overview asset was deferred in the document. Its effective execution
        # happened after the following classic final marker, so encode that order.
        classic_sources.remove(OVERVIEW_SOURCE)
        classic_sources.append(OVERVIEW_SOURCE)

        style_sources = []
        for match in LINK_RE.finditer(html):
            attributes = _attrs(match.group("attrs"))
            if attributes.get("rel", "").lower() != "stylesheet":
                continue
            source = attributes.get("href", "").split("?", 1)[0]
            if not source:
                raise RuntimeError("stylesheet without href")
            style_sources.append(source)
            style_tags.append(match.group(0))
        if len(style_sources) != 10:
            raise RuntimeError(f"expected ten linked source stylesheets, found {len(style_sources)}")
        style_sources.append(RUNTIME_COMPONENT_STYLE)

    classic_payload, classic_records, legacy_manifest_payload = _classic_bundle(classic_sources)
    style_payload, style_records = _style_bundle(style_sources)
    manifest = {
        "schemaVersion": 1,
        "build": "R9RC1_PROFESSIONAL_ARCHITECTURE_COMPLETION",
        "classic": {
            "output": CLASSIC_BUNDLE.relative_to(APP).as_posix(),
            "bytes": len(classic_payload),
            "sha256": _sha256(classic_payload),
            "sources": classic_records,
        },
        "styles": {
            "output": STYLE_BUNDLE.relative_to(APP).as_posix(),
            "bytes": len(style_payload),
            "sha256": _sha256(style_payload),
            "sources": style_records,
        },
        "preservedEarlySource": EARLY_SOURCE,
        "moduleEntrypoint": MODULE_SOURCE,
        "disabledSourceNotBundled": DISABLED_SOURCE,
        "dependencyInjectionEvent": "tool-a:foundation-ready",
        "foundationCompatibilityGlobals": [],
    }
    manifest_payload = (json.dumps(manifest, indent=2, ensure_ascii=False) + "\n").encode("utf-8")
    if args.check:
        mismatches = []
        for path, expected in (
            (CLASSIC_BUNDLE, classic_payload),
            (STYLE_BUNDLE, style_payload),
            (MANIFEST, manifest_payload),
            (LEGACY_PARTS_MANIFEST, legacy_manifest_payload),
        ):
            if not path.is_file() or path.read_bytes() != expected:
                mismatches.append(path.relative_to(ROOT).as_posix())
        if mismatches:
            raise RuntimeError(f"stale generated Tool A assets: {', '.join(mismatches)}")
    else:
        RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
        CLASSIC_BUNDLE.write_bytes(classic_payload)
        STYLE_BUNDLE.write_bytes(style_payload)
        MANIFEST.write_bytes(manifest_payload)
        LEGACY_PARTS_MANIFEST.write_bytes(legacy_manifest_payload)
        if not already_linked:
            preserved = {early_tags[0], module_tags[0]}
            transformed = SCRIPT_RE.sub(
                lambda match: match.group(0) if match.group(0) in preserved else "",
                html,
            )
            transformed = LINK_RE.sub(
                lambda match: "" if match.group(0) in set(style_tags) else match.group(0),
                transformed,
            )
            style_link = (
                '<link rel="stylesheet" href="tool-a/styles/tool-a.bundle.css?v=r9rc1" '
                'data-r9rc1-style-bundle="ordered-cascade">'
            )
            if transformed.count("</head>") != 1:
                raise RuntimeError("Tool A head boundary drifted")
            transformed = transformed.replace("</head>", f"  {style_link}\n</head>", 1)
            module_tag = module_tags[0]
            if transformed.count(module_tag) != 1:
                raise RuntimeError("module entrypoint boundary drifted")
            runtime_tag = (
                '<script id="toolAClassicRuntime" '
                'src="tool-a/runtime/classic-runtime.bundle.js?v=r9rc1"></script>'
            )
            transformed = transformed.replace(module_tag, runtime_tag + "\n" + module_tag, 1)
            transformed = re.sub(r"\n[ \t]*\n(?:[ \t]*\n)+", "\n\n", transformed)
            HTML.write_text(transformed, encoding="utf-8")
    print(
        f"bundled {len(classic_sources)} classic sources and {len(style_sources)} styles; "
        "active HTML now has three script tags and one stylesheet"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
