#!/usr/bin/env python3
from __future__ import annotations

"""Safely extract a release ZIP and run its full preflight without Git metadata."""

import argparse
import hashlib
import json
import os
import shutil
import stat
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path, PurePosixPath


MAX_MEMBER_BYTES = 1024 * 1024 * 1024
MAX_TOTAL_BYTES = 4 * 1024 * 1024 * 1024


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def safe_extract(artifact: Path, destination: Path) -> tuple[Path, int]:
    with zipfile.ZipFile(artifact, "r") as archive:
        infos = archive.infolist()
        if not infos:
            raise RuntimeError("artifact ZIP is empty")
        names = [info.filename for info in infos]
        if len(names) != len(set(names)):
            raise RuntimeError("artifact ZIP contains duplicate members")
        if archive.testzip() is not None:
            raise RuntimeError("artifact ZIP CRC verification failed")

        top_levels: set[str] = set()
        total_bytes = 0
        for info in infos:
            member = PurePosixPath(info.filename)
            mode = (info.external_attr >> 16) & 0xFFFF
            if (
                member.is_absolute()
                or len(member.parts) < 2
                or any(part in {"", ".", ".."} for part in member.parts)
                or "\\" in info.filename
            ):
                raise RuntimeError(f"unsafe artifact ZIP member: {info.filename}")
            if any(part.lower() == ".git" for part in member.parts):
                raise RuntimeError(f"Git metadata is forbidden: {info.filename}")
            if info.is_dir() or not stat.S_ISREG(mode):
                raise RuntimeError(f"non-regular artifact ZIP member: {info.filename}")
            if info.file_size < 0 or info.file_size > MAX_MEMBER_BYTES:
                raise RuntimeError(f"artifact member exceeds size limit: {info.filename}")
            total_bytes += info.file_size
            if total_bytes > MAX_TOTAL_BYTES:
                raise RuntimeError("artifact ZIP exceeds total extraction limit")
            top_levels.add(member.parts[0])

        if len(top_levels) != 1:
            raise RuntimeError(f"artifact must contain exactly one release root: {sorted(top_levels)}")

        for info in infos:
            target = destination.joinpath(*PurePosixPath(info.filename).parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(info, "r") as source, target.open("xb") as output:
                shutil.copyfileobj(source, output, length=1024 * 1024)
            if target.stat().st_size != info.file_size:
                raise RuntimeError(f"extracted byte count mismatch: {info.filename}")

    release = destination / next(iter(top_levels))
    if not release.is_dir():
        raise RuntimeError("extracted release root is missing")
    for path in release.rglob("*"):
        if path.is_symlink() or path.name.lower() == ".git":
            raise RuntimeError(f"forbidden extracted path: {path.relative_to(release)}")
    return release, len(infos)


def write_json_atomic(path: Path, value: dict[str, object]) -> None:
    path = path.expanduser().absolute()
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.parent / f".{path.name}.tmp.{os.getpid()}"
    try:
        temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        with temporary.open("rb") as handle:
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--artifact", type=Path, required=True)
    parser.add_argument("--json-output", type=Path)
    args = parser.parse_args()

    artifact = args.artifact.expanduser().absolute()
    if not artifact.is_file():
        raise RuntimeError(f"artifact does not exist: {artifact}")

    with tempfile.TemporaryDirectory(prefix="metod_r9j_standalone_") as temporary:
        temp_root = Path(temporary)
        release, member_count = safe_extract(artifact, temp_root / "empty-extraction-root")
        env = dict(os.environ)
        env["PYTHONDONTWRITEBYTECODE"] = "1"
        env["METOD_STATE_ROOT"] = str(temp_root / "isolated-state")
        env["GIT_CEILING_DIRECTORIES"] = str(temp_root)
        completed = subprocess.run(
            [sys.executable, "-B", "tools/final_preflight.py", "--release", ".", "--verify-checksums"],
            cwd=str(release),
            env=env,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=1200,
            check=False,
        )
        output = completed.stdout
        if completed.returncode != 0:
            sys.stdout.write(output)
            raise RuntimeError(f"standalone full preflight failed with exit {completed.returncode}")
        report: dict[str, object] = {
            "schemaVersion": 1,
            "gate": "METOD_STANDALONE_ARTIFACT_FULL_PREFLIGHT",
            "status": "PASS",
            "artifact": artifact.name,
            "artifactBytes": artifact.stat().st_size,
            "artifactSha256": sha256_file(artifact),
            "topLevelDirectory": release.name,
            "memberCount": member_count,
            "gitMetadataPresent": False,
            "checksumVerification": "PASS",
            "fullPreflightExitCode": completed.returncode,
            "fullPreflightOutputSha256": hashlib.sha256(output.encode("utf-8")).hexdigest(),
            "fullPreflightTail": output.splitlines()[-12:],
        }
        identity = json.loads((release / "RELEASE_IDENTITY.json").read_text(encoding="utf-8"))
        candidate = identity.get("canonicalCandidate") if isinstance(identity, dict) else None
        if not isinstance(candidate, dict):
            raise RuntimeError("canonical release identity missing after extraction")
        if artifact.name != candidate.get("artifactName"):
            raise RuntimeError("artifact filename differs from canonical release identity")
        if release.name != candidate.get("artifactRootDirectory"):
            raise RuntimeError("artifact root differs from canonical release identity")
        report["releaseRevision"] = candidate.get("releaseRevision")
        report["buildId"] = candidate.get("buildId")
        report["releaseStatus"] = candidate.get("status")
        report["releaseEligible"] = candidate.get("releaseEligible")
        if args.json_output:
            write_json_atomic(args.json_output, report)
        print(json.dumps(report, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
