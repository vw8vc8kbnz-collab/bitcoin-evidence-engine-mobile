#!/usr/bin/env python3
from __future__ import annotations

"""Read Tool A with generated shell assets expanded in place.

Historical source-contract tests intentionally inspect the pre-R9H-10 logical
source stream.  This helper reconstructs that stream without changing what the
server ships: stylesheet links become style elements and only the reviewed
``tool-a/shell`` scripts are expanded back into their original tag positions.
"""

import re
import json
from pathlib import Path


STYLE_LINK_RE = re.compile(
    r'<link\s+rel="stylesheet"\s+href="(?P<src>tool-a/styles/[^"?]+)(?:\?[^" ]*)?"'
    r'\s+data-r9h-style-phase="[^"]+">',
    re.IGNORECASE,
)
SHELL_SCRIPT_RE = re.compile(
    r'<script(?P<before>[^>]*)\s+src="(?P<src>tool-a/shell/[^"?]+)(?:\?[^" ]*)?"'
    r'(?P<after>[^>]*)></script>',
    re.IGNORECASE,
)
R9RC1_STYLE_RE = re.compile(
    r'<link\s+rel="stylesheet"\s+href="tool-a/styles/tool-a\.bundle\.css(?:\?[^" ]*)?"[^>]*>',
    re.IGNORECASE,
)
R9RC1_RUNTIME_RE = re.compile(
    r'<script[^>]+src="tool-a/runtime/classic-runtime\.bundle\.js(?:\?[^" ]*)?"[^>]*></script>',
    re.IGNORECASE,
)


def read_toola_expanded(html_path: Path) -> str:
    html_path = Path(html_path)
    app_root = html_path.parent
    source = html_path.read_text(encoding="utf-8")
    r9rc1_manifest = app_root / "tool-a/runtime/bundle-manifest.json"
    if r9rc1_manifest.is_file() and "classic-runtime.bundle.js" in source:
        bundle = json.loads(r9rc1_manifest.read_text(encoding="utf-8"))
        style_path = app_root / str(bundle["styles"]["output"])
        runtime_path = app_root / str(bundle["classic"]["output"])
        source = R9RC1_STYLE_RE.sub(
            lambda _match: f"<style>{style_path.read_text(encoding='utf-8')}</style>",
            source,
        )
        source = R9RC1_RUNTIME_RE.sub(
            lambda _match: f"<script>{runtime_path.read_text(encoding='utf-8')}</script>",
            source,
        )
        source = SHELL_SCRIPT_RE.sub(
            lambda match: (
                f'<script{match.group("before")}{match.group("after")}>'
                f'{(app_root / match.group("src")).read_text(encoding="utf-8")}</script>'
            ),
            source,
        )
        return source

    manifest = json.loads((app_root.parent / "R9H10_SEMANTIC_SHELL_ASSETS.json").read_text(encoding="utf-8"))
    block_sizes = iter(manifest["styleBlockBytes"])
    block_attributes = iter(manifest["styleBlockAttributes"])

    def expand_style(match: re.Match[str]) -> str:
        payload = (app_root / match.group("src")).read_text(encoding="utf-8")
        phase = next(item for item in manifest["stylePhases"] if item["path"] == match.group("src"))
        chunks = []
        offset = 0
        for _ in range(int(phase["blockCount"])):
            size = int(next(block_sizes))
            attributes = str(next(block_attributes))
            chunk = payload.encode()[offset:offset + size].decode()
            chunks.append(f"<style{attributes}>{chunk}</style>")
            offset += size
        if offset != len(payload.encode()):
            raise ValueError(f"style block ledger drift for {match.group('src')}")
        return "".join(chunks)

    def expand_script(match: re.Match[str]) -> str:
        payload = (app_root / match.group("src")).read_text(encoding="utf-8")
        return f'<script{match.group("before")}{match.group("after")}>{payload}</script>'

    source = STYLE_LINK_RE.sub(expand_style, source)
    source = SHELL_SCRIPT_RE.sub(expand_script, source)
    source = source.replace(
        '  <meta name="metod-shell-revision" content="R9H_SEMANTIC_SHELL_10" />\n', "", 1,
    )
    source = source.replace(
        '<main class="app" id="toolAAppShell" aria-label="METOD/PAX configurator">',
        '<div class="app">', 1,
    )
    source = source.replace(
        '<div class="left" role="region" aria-label="Paneelvoorbeeld">', '<div class="left">', 1,
    )
    source = source.replace(
        '<div class="right" role="region" aria-label="Configuratiestappen">', '<div class="right">', 1,
    )
    source = source.replace(
        '<div class="stepbar" id="stepbar" role="navigation" aria-label="Configuratiestappen">',
        '<div class="stepbar" id="stepbar">', 1,
    )
    source = source.replace(
        '<div class="rightScroll" id="rightScroll" role="region" aria-label="Actieve configuratiestap">',
        '<div class="rightScroll" id="rightScroll">', 1,
    )
    source = source.replace('<footer id="wizardFooter"', '<div id="wizardFooter"', 1)
    source = source.replace('    </footer>\n\n    <div id="mobileMaterialCartBackdrop"',
                            '    </div>\n\n    <div id="mobileMaterialCartBackdrop"', 1)
    source = source.replace('    </section>\n  </main>\n\n\n\n<script id="fix660r8wFreshConfigurationGuard"',
                            '    </section>\n  </div>\n\n\n\n<script id="fix660r8wFreshConfigurationGuard"', 1)
    return source


__all__ = ("read_toola_expanded",)
