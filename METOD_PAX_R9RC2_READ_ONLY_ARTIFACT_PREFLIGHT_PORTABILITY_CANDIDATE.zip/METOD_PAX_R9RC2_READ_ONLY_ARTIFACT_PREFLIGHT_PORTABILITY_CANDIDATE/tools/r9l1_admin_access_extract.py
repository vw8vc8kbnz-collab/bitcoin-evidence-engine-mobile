#!/usr/bin/env python3
from __future__ import annotations

"""Deterministically extract the R9L1 Admin access owner from server_py.py."""

import ast
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SERVER = ROOT / "app/server_py.py"
ACCESS = ROOT / "app/metod_app/admin/access.py"


IMPORT_BLOCK = """from metod_app.admin.access import (
    ADMIN_HTML,
    ADMIN_LOGIN_HTML,
    AdminAccessController,
    AdminAccessDependencies,
    AdminSessionStore,
    find_admin_user as _admin_find_user,
    normalized_admin_users as _admin_normalized_users,
)
"""

SESSION_GLOBALS_BEFORE = """_ADMIN_SESSIONS_LOCK = threading.Lock()
_ADMIN_SESSIONS: dict[str, dict[str, Any]] = {}
_ADMIN_SESSION_IDLE_SEC = _RUNTIME_CONFIG.admin_session_idle_seconds
_ADMIN_SESSION_ABSOLUTE_SEC = _RUNTIME_CONFIG.admin_session_absolute_seconds
"""

SESSION_GLOBALS_AFTER = """_ADMIN_SESSION_STORE = AdminSessionStore(
    idle_seconds=_RUNTIME_CONFIG.admin_session_idle_seconds,
    absolute_seconds=_RUNTIME_CONFIG.admin_session_absolute_seconds,
    max_sessions=lambda: _env_int('ADMIN_MAX_SESSIONS', 1024),
    lock=threading.Lock(),
)
"""

TOP_LEVEL_REPLACEMENTS = {
    "_normalized_admin_users": """def _normalized_admin_users(credentials: dict | None) -> list[dict[str, Any]]:
    return _admin_normalized_users(credentials)
""",
    "_find_admin_user": """def _find_admin_user(credentials: dict | None, username: str) -> dict[str, Any] | None:
    return _admin_find_user(credentials, username)
""",
    "_admin_session_create": """def _admin_session_create(actor: str, roles: list[str] | None = None) -> tuple[str, float]:
    return _ADMIN_SESSION_STORE.create(actor, roles)
""",
    "_admin_session_valid": """def _admin_session_valid(token: str) -> bool:
    return _ADMIN_SESSION_STORE.valid(token)
""",
    "_admin_session_revoke": """def _admin_session_revoke(token: str) -> None:
    _ADMIN_SESSION_STORE.revoke(token)
""",
    "_admin_session_actor": """def _admin_session_actor(token: str) -> str:
    return _ADMIN_SESSION_STORE.actor(token)
""",
    "_admin_session_roles": """def _admin_session_roles(token: str) -> frozenset[str]:
    return _ADMIN_SESSION_STORE.roles(token)
""",
}

HANDLER_REPLACEMENTS = {
    "_load_admin_credentials": """    def _load_admin_credentials(self):
        return _ADMIN_ACCESS.load_credentials()
""",
    "_warn_if_local_admin_credentials_in_production": """    def _warn_if_local_admin_credentials_in_production(self, creds: dict | None) -> None:
        _ADMIN_ACCESS.warn_if_local_credentials_in_production(self, creds)
""",
    "_api_admin_login": """    def _api_admin_login(self):
        return _ADMIN_ACCESS.login(self)
""",
    "_check_admin_auth_silent": """    def _check_admin_auth_silent(self) -> bool:
        return _ADMIN_ACCESS.check_silent(self)
""",
    "_current_admin_session_token": """    def _current_admin_session_token(self) -> str:
        return _ADMIN_ACCESS.current_session_token(self)
""",
    "_current_admin_actor": """    def _current_admin_actor(self) -> str:
        return _ADMIN_ACCESS.current_actor(self)
""",
    "_api_admin_logout": """    def _api_admin_logout(self):
        return _ADMIN_ACCESS.logout(self)
""",
    "_wants_native_basic_prompt": """    def _wants_native_basic_prompt(self) -> bool:
        return _ADMIN_ACCESS.wants_native_basic_prompt(self)
""",
    "_send_admin_auth_challenge": """    def _send_admin_auth_challenge(self, code: int = 401, message: str = 'Admin authentication required'):
        return _ADMIN_ACCESS.send_challenge(self, code, message)
""",
    "_require_admin_auth": """    def _require_admin_auth(self) -> bool:
        return _ADMIN_ACCESS.require_auth(self)
""",
}

CONTROLLER_BLOCK = """_ADMIN_ACCESS = AdminAccessController(
    AdminAccessDependencies(
        root=ROOT,
        environment=os.environ,
        credentials_file_path=_get_admin_credentials_file_path,
        strict_json_load=strict_json_load,
        strict_json_dumps=strict_json_dumps,
        read_json_body_limited=_read_json_body_limited,
        production_runtime=_is_production_runtime,
        production_hardening_enabled=_is_production_hardening_enabled,
        secure_admin_transport=_is_secure_admin_transport,
        https_request=_is_https_request,
        client_ip=_client_ip,
        loopback_client=_is_loopback_client,
        rate_limit_is_blocked=_rate_limit_is_blocked,
        rate_limit_record=_rate_limit_record,
        rate_limit_clear=_rate_limit_clear,
        verify_password=_verify_password_against_stored,
        verify_totp=_verify_totp,
        append_system_event=_append_system_event,
        extract_bearer_token=_extract_bearer_token,
        extract_session_cookie=_extract_admin_session_cookie,
        dummy_password_hash=_DUMMY_ADMIN_PASSWORD_HASH,
        dummy_totp_secret=_DUMMY_ADMIN_TOTP_SECRET,
    ),
    _ADMIN_SESSION_STORE,
)


"""


def line_offsets(source: str) -> list[int]:
    offsets = [0]
    for index, char in enumerate(source):
        if char == "\n":
            offsets.append(index + 1)
    return offsets


def span(source: str, node: ast.AST) -> tuple[int, int]:
    offsets = line_offsets(source)
    # Replace complete source lines. Class members otherwise leave their four
    # leading spaces behind and would receive double indentation.
    start = offsets[node.lineno - 1]
    end = offsets[node.end_lineno - 1] + node.end_col_offset
    if end < len(source) and source[end] == "\n":
        end += 1
    return start, end


def replace_nodes(source: str, replacements: list[tuple[ast.AST, str]]) -> str:
    edits = [(span(source, node)[0], span(source, node)[1], replacement) for node, replacement in replacements]
    for start, end, replacement in sorted(edits, reverse=True):
        source = source[:start] + replacement + source[end:]
    return source


def main() -> None:
    server_source = SERVER.read_text(encoding="utf-8", errors="strict")
    access_source = ACCESS.read_text(encoding="utf-8", errors="strict")
    if "from metod_app.admin.access import (" in server_source:
        print("R9L1 Admin access extraction already applied")
        return

    tree = ast.parse(server_source)
    presentation_nodes: dict[str, ast.Assign] = {}
    top_functions: dict[str, ast.FunctionDef] = {}
    handler: ast.ClassDef | None = None
    for node in tree.body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            if node.targets[0].id in {"ADMIN_HTML", "ADMIN_LOGIN_HTML"}:
                presentation_nodes[node.targets[0].id] = node
        elif isinstance(node, ast.FunctionDef) and node.name in TOP_LEVEL_REPLACEMENTS:
            top_functions[node.name] = node
        elif isinstance(node, ast.ClassDef) and node.name == "Handler":
            handler = node

    if set(presentation_nodes) != {"ADMIN_HTML", "ADMIN_LOGIN_HTML"}:
        raise RuntimeError("Admin presentation constants are not the sealed R9K5 shape")
    if set(top_functions) != set(TOP_LEVEL_REPLACEMENTS):
        raise RuntimeError("Admin top-level functions are not the sealed R9K5 shape")
    if handler is None:
        raise RuntimeError("Handler class missing")
    handler_functions = {
        node.name: node
        for node in handler.body
        if isinstance(node, ast.FunctionDef) and node.name in HANDLER_REPLACEMENTS
    }
    if set(handler_functions) != set(HANDLER_REPLACEMENTS):
        raise RuntimeError("Admin Handler methods are not the sealed R9K5 shape")

    presentation_segments = []
    for name in ("ADMIN_HTML", "ADMIN_LOGIN_HTML"):
        start, end = span(server_source, presentation_nodes[name])
        presentation_segments.append(server_source[start:end].rstrip("\n"))
    marker = "# R9L1_PRESENTATION_CONSTANTS"
    if access_source.count(marker) != 1:
        raise RuntimeError("Admin access presentation marker missing or ambiguous")
    access_source = access_source.replace(marker, "\n\n".join(presentation_segments), 1)

    node_replacements: list[tuple[ast.AST, str]] = []
    node_replacements.extend((node, "") for node in presentation_nodes.values())
    node_replacements.extend((top_functions[name], replacement) for name, replacement in TOP_LEVEL_REPLACEMENTS.items())
    node_replacements.extend((handler_functions[name], replacement) for name, replacement in HANDLER_REPLACEMENTS.items())
    server_source = replace_nodes(server_source, node_replacements)

    import_anchor = "from metod_app.application import build_app_context\n"
    if server_source.count(import_anchor) != 1:
        raise RuntimeError("Admin import anchor missing or ambiguous")
    server_source = server_source.replace(import_anchor, IMPORT_BLOCK + "\n" + import_anchor, 1)
    if server_source.count(SESSION_GLOBALS_BEFORE) != 1:
        raise RuntimeError("Admin session global block missing or ambiguous")
    server_source = server_source.replace(SESSION_GLOBALS_BEFORE, SESSION_GLOBALS_AFTER, 1)
    class_anchor = "class Handler(SimpleHTTPRequestHandler):\n"
    if server_source.count(class_anchor) != 1:
        raise RuntimeError("Handler insertion anchor missing or ambiguous")
    server_source = server_source.replace(class_anchor, CONTROLLER_BLOCK + class_anchor, 1)

    ACCESS.write_text(access_source, encoding="utf-8", newline="\n")
    SERVER.write_text(server_source, encoding="utf-8", newline="\n")
    print("R9L1 Admin access extraction applied")


if __name__ == "__main__":
    main()
