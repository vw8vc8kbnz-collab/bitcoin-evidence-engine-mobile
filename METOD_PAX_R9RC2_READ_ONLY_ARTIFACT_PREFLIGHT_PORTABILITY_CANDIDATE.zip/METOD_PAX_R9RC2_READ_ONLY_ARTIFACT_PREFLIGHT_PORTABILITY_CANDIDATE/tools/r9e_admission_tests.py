#!/usr/bin/env python3
from __future__ import annotations

"""Behavior and ownership proof for R9E admission/capacity extraction."""

import ast
import importlib
import os
import sys
import tempfile
import threading
import unittest
from pathlib import Path
from types import SimpleNamespace


RELEASE = Path(__file__).resolve().parents[1]
APP = RELEASE / "app"
SERVER = APP / "server_py.py"
sys.path.insert(0, str(APP))

from metod_app.jobs.admission import (  # noqa: E402
    PublicJobAdmission,
    StateCapacityReservations,
    public_job_queue_limits,
)


def env_from(values: dict[str, int]):
    return lambda name, default: int(values.get(name, default))


class CapacityError(RuntimeError):
    pass


class R9EAdmissionBehaviorTests(unittest.TestCase):
    def test_01_limits_preserve_defaults_and_bounds(self) -> None:
        self.assertEqual(public_job_queue_limits(env_from({})), (2, 8, 2))
        self.assertEqual(public_job_queue_limits(env_from({
            "PUBLIC_JOB_MAX_CONCURRENT": 99,
            "PUBLIC_JOB_MAX_QUEUED": -5,
            "PUBLIC_JOB_MAX_CONCURRENT_PER_IP": 99,
        })), (8, 0, 8))
        self.assertEqual(public_job_queue_limits(env_from({
            "PUBLIC_JOB_MAX_CONCURRENT": 0,
            "PUBLIC_JOB_MAX_QUEUED": 99,
            "PUBLIC_JOB_MAX_CONCURRENT_PER_IP": 0,
        })), (1, 64, 1))

    def test_02_global_and_per_ip_admission_fail_closed(self) -> None:
        admission = PublicJobAdmission(lock=threading.Lock())
        limits = env_from({
            "PUBLIC_JOB_MAX_CONCURRENT": 1,
            "PUBLIC_JOB_MAX_QUEUED": 1,
            "PUBLIC_JOB_MAX_CONCURRENT_PER_IP": 1,
        })
        self.assertEqual(admission.try_acquire("ip-a", env_int=limits), (True, "ok"))
        self.assertEqual(admission.try_acquire("ip-a", env_int=limits), (False, "ip"))
        self.assertEqual(admission.try_acquire("ip-b", env_int=limits), (True, "ok"))
        self.assertEqual(admission.try_acquire("ip-c", env_int=limits), (False, "queue_full"))
        self.assertEqual(admission.total, 2)
        self.assertEqual(admission.reserved_total, 2)

    def test_03_release_is_idempotent_and_normalizes_empty_ip(self) -> None:
        admission = PublicJobAdmission(lock=threading.Lock())
        self.assertEqual(admission.try_acquire("", env_int=env_from({})), (True, "ok"))
        self.assertEqual(admission.by_ip, {"?": 1})
        self.assertTrue(admission.release_reservation(None))
        self.assertFalse(admission.release_reservation(None))
        self.assertEqual(admission.total, 0)
        self.assertEqual(admission.reserved_total, 0)
        self.assertEqual(admission.by_ip, {})

    def test_04_commit_finish_and_queued_cancel_preserve_accounting(self) -> None:
        admission = PublicJobAdmission(lock=threading.Lock())
        limits = env_from({"PUBLIC_JOB_MAX_CONCURRENT_PER_IP": 3})
        for _ in range(2):
            self.assertTrue(admission.try_acquire("ip-a", env_int=limits)[0])
        with admission.lock:
            admission.consume_reservation_locked("ip-a")
            admission.consume_reservation_locked("ip-a")
            admission.finish_locked("ip-a")
            admission.cancel_queued_locked("ip-a")
        self.assertEqual(admission.total, 0)
        self.assertEqual(admission.reserved_total, 0)
        self.assertEqual(admission.by_ip, {})

    def test_05_missing_commit_reservation_is_rejected(self) -> None:
        admission = PublicJobAdmission(lock=threading.Lock())
        with admission.lock:
            with self.assertRaisesRegex(RuntimeError, "reservation is missing"):
                admission.consume_reservation_locked("ip-a")

    def _capacity(self) -> StateCapacityReservations:
        return StateCapacityReservations(lock=threading.RLock())

    def _dependencies(self, *, free: int, inodes: int | None = 20_000) -> dict:
        return {
            "state_root": Path("/state"),
            "env_int": env_from({
                "MIN_FREE_STATE_BYTES": 1024 * 1024 * 1024,
                "MIN_FREE_STATE_INODES": 10_000,
            }),
            "disk_usage": lambda _root: SimpleNamespace(free=free),
            "statvfs": (
                None if inodes is None
                else lambda _root: SimpleNamespace(f_favail=inodes)
            ),
            "capacity_error": CapacityError,
        }

    def test_06_capacity_enforcement_counts_all_existing_reservations(self) -> None:
        capacity = self._capacity()
        deps = self._dependencies(free=2 * 1024**3)
        capacity.reserve("A", 128 * 1024**2, 200, reservation_kind="job", **deps)
        result = capacity.enforce(64 * 1024**2, 50, **deps)
        self.assertEqual(result["reservedBytes"], 128 * 1024**2)
        self.assertEqual(result["reservedInodes"], 200)
        self.assertEqual(result["requiredFreeBytes"], 1216 * 1024**2)

    def test_07_byte_and_inode_shortage_have_exact_public_messages(self) -> None:
        capacity = self._capacity()
        with self.assertRaisesRegex(CapacityError, "veilige opslagruimte"):
            capacity.enforce(1, 1, **self._dependencies(free=1024**3))
        with self.assertRaisesRegex(CapacityError, "vrije bestandsposities"):
            capacity.enforce(
                0, 1, **self._dependencies(free=2 * 1024**3, inodes=10_000)
            )

    def test_08_reservation_replacement_is_atomic_and_key_order_is_exact(self) -> None:
        capacity = self._capacity()
        deps = self._dependencies(free=2 * 1024**3)
        first = capacity.reserve("A", 10, 20, reservation_kind="job", **deps)
        second = capacity.reserve("A", 30, 40, reservation_kind="job", **deps)
        self.assertEqual(list(first), [
            "freeBytes", "requiredFreeBytes", "reservedBytesBefore",
            "reservationBytes", "freeInodes", "requiredFreeInodes",
            "reservedInodesBefore", "reservationInodes",
            "replacedReservationBytes", "replacedReservationInodes",
        ])
        self.assertEqual(second["reservedBytesBefore"], 0)
        self.assertEqual(second["replacedReservationBytes"], 10)
        self.assertEqual(second["replacedReservationInodes"], 20)
        self.assertEqual(capacity.totals(), {"jobs": 1, "bytes": 30, "inodes": 40})

    def test_09_kind_validation_totals_and_release_are_exact(self) -> None:
        capacity = self._capacity()
        deps = self._dependencies(free=2 * 1024**3)
        with self.assertRaisesRegex(ValueError, "Invalid state capacity"):
            capacity.reserve("A", 1, 1, reservation_kind="other", **deps)
        capacity.reserve("A", 10, 2, reservation_kind="job", **deps)
        capacity.reserve(
            "SYNC", 20, 3, reservation_kind="catalog-image-sync", **deps
        )
        self.assertEqual(capacity.totals(), {"jobs": 1, "bytes": 30, "inodes": 5})
        self.assertTrue(capacity.release("A"))
        self.assertFalse(capacity.release("A"))
        self.assertEqual(capacity.totals(), {"jobs": 0, "bytes": 20, "inodes": 3})


class R9EAdmissionOwnershipTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls._previous_state = os.environ.get("METOD_STATE_ROOT")
        cls._temp = tempfile.TemporaryDirectory(prefix="r9e-admission-")
        os.environ["METOD_STATE_ROOT"] = str(Path(cls._temp.name) / "state")
        cls.server = importlib.import_module("server_py")

    @classmethod
    def tearDownClass(cls) -> None:
        if cls._previous_state is None:
            os.environ.pop("METOD_STATE_ROOT", None)
        else:
            os.environ["METOD_STATE_ROOT"] = cls._previous_state
        cls._temp.cleanup()

    def test_10_server_composes_the_single_accounting_owners(self) -> None:
        server = self.server
        self.assertIs(server._PUBLIC_JOB_CREATE_LOCK, server._PUBLIC_JOB_ADMISSION.lock)
        self.assertIs(server._PUBLIC_JOB_CREATE_BY_IP, server._PUBLIC_JOB_ADMISSION.by_ip)
        self.assertIs(
            server._PUBLIC_JOB_RESERVED_BY_IP,
            server._PUBLIC_JOB_ADMISSION.reserved_by_ip,
        )
        self.assertIs(
            server._JOB_STORAGE_RESERVATION_LOCK,
            server._STATE_CAPACITY_RESERVATIONS.lock,
        )
        self.assertIs(
            server._JOB_STORAGE_RESERVATIONS,
            server._STATE_CAPACITY_RESERVATIONS.records,
        )

    def test_11_server_wrappers_delegate_without_duplicate_policy(self) -> None:
        source = SERVER.read_text(encoding="utf-8")
        tree = ast.parse(source, filename=str(SERVER))
        functions = {
            node.name: ast.get_source_segment(source, node) or ""
            for node in tree.body if isinstance(node, ast.FunctionDef)
        }
        self.assertIn("_bounded_public_job_queue_limits", functions["_public_job_queue_limits"])
        self.assertIn("_PUBLIC_JOB_ADMISSION.try_acquire", functions["_try_acquire_public_job_slot"])
        self.assertIn("_STATE_CAPACITY_RESERVATIONS.reserve", functions["_reserve_state_capacity"])
        self.assertIn("_STATE_CAPACITY_RESERVATIONS.enforce", functions["_enforce_state_capacity"])
        self.assertNotIn("shutil.disk_usage", (APP / "metod_app/jobs/admission.py").read_text())

    def test_12_module_does_not_own_fifo_process_http_or_durable_io(self) -> None:
        path = APP / "metod_app/jobs/admission.py"
        source = path.read_text(encoding="utf-8")
        tree = ast.parse(source, filename=str(path))
        imports = {
            alias.name.split(".", 1)[0]
            for node in ast.walk(tree) if isinstance(node, ast.Import)
            for alias in node.names
        }
        imports.update(
            node.module.split(".", 1)[0]
            for node in ast.walk(tree)
            if isinstance(node, ast.ImportFrom) and node.module
        )
        self.assertFalse(imports & {
            "http", "json", "os", "pathlib", "server_py", "socket",
            "subprocess", "threading", "time",
        })
        for forbidden in (
            "deque(", "durable_write", "open(", "Popen(", "Thread(",
            "_PUBLIC_JOB_QUEUE", "_PUBLIC_JOB_ACTIVE_BY_ID",
        ):
            self.assertNotIn(forbidden, source, forbidden)

    def test_13_optimizer_and_tool_a_remain_byte_exact(self) -> None:
        import hashlib

        expected = {
            "app/dxf_nesting_optimizer.py": "42480b301cd660dac1e5e9fec2c8d30bb5c6826c32234a9c1cce765b758bebb8",
                "app/toolA.html": "8dc02939664026c3bffd407b083ad2febdd9d0aa61adf232deaef329b9479a22",
        }
        for relative, digest in expected.items():
            self.assertEqual(
                hashlib.sha256((RELEASE / relative).read_bytes()).hexdigest(),
                digest,
                relative,
            )


if __name__ == "__main__":
    unittest.main(verbosity=2)
