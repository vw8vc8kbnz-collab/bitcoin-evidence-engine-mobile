#!/usr/bin/env python3
from __future__ import annotations

"""Focused ownership and behavior tests for the first R9B extraction."""

import ast
import base64
import importlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from dataclasses import FrozenInstanceError
from pathlib import Path


RELEASE = Path(__file__).resolve().parents[1]
APP = RELEASE / "app"
SERVER = APP / "server_py.py"
sys.path.insert(0, str(APP))

from metod_app.application import AppContext, build_app_context  # noqa: E402
from metod_app.contracts.submission import (  # noqa: E402
    EMAIL_RE,
    clean_text,
    sanitize_phone_text,
    sanitize_postcode_text,
    sanitize_user_text,
    validate_submit_payload,
)
from metod_app.config import (  # noqa: E402
    RuntimeConfig,
    env_flag,
    env_int,
    production_hardening_enabled,
    split_env_csv,
)
from metod_app.http.static import (  # noqa: E402
    PUBLIC_STATIC_MODULE_FILES,
    is_public_static_relpath,
)
from metod_app.errors import public_error_message  # noqa: E402
from metod_app.paths import AppPaths  # noqa: E402


EXTRACTED_SERVER_NAMES = {
    "_public_error_message",
    "_is_str",
    "_clean_text",
    "_sanitize_user_text",
    "_sanitize_phone_text",
    "_sanitize_postcode_text",
    "_validate_submit_payload",
    "_env_int",
    "_env_flag",
    "_split_env_csv",
    "_split_env_origins",
    "_is_production_hardening_enabled",
}


class R9BModuleBoundaryTests(unittest.TestCase):
    def test_server_no_longer_defines_extracted_owners(self) -> None:
        tree = ast.parse(SERVER.read_text(encoding="utf-8"), filename=str(SERVER))
        definitions = {
            node.name
            for node in tree.body
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
        }
        self.assertEqual(definitions & EXTRACTED_SERVER_NAMES, set())

        imported_aliases = {
            alias.asname
            for node in tree.body
            if isinstance(node, ast.ImportFrom)
            for alias in node.names
            if alias.asname
        }
        self.assertTrue(
            {
                "_public_error_message",
                "_clean_text",
                "_sanitize_user_text",
                "_sanitize_phone_text",
                "_sanitize_postcode_text",
                "_validate_submit_payload",
                "_EMAIL_RE",
            }.issubset(imported_aliases)
        )

    def test_new_contract_layer_does_not_import_server_or_runtime_owners(self) -> None:
        forbidden = {"server_py", "subprocess", "threading", "socket", "http"}
        for path in sorted((APP / "metod_app").rglob("*.py")):
            tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
            imports = set()
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    imports.update(alias.name.split(".", 1)[0] for alias in node.names)
                elif isinstance(node, ast.ImportFrom) and node.module:
                    imports.add(node.module.split(".", 1)[0])
            self.assertEqual(imports & forbidden, set(), path.relative_to(RELEASE))
            relative = path.relative_to(APP).as_posix()
            path_owns_filesystem_paths = (
                path.name == "paths.py"
                or "storage" in path.relative_to(APP).parts
                or relative == "metod_app/http/static.py"
            )
            if not path_owns_filesystem_paths:
                self.assertNotIn("pathlib", imports, path.relative_to(RELEASE))

    def test_server_aliases_have_one_module_owner(self) -> None:
        previous = os.environ.get("METOD_STATE_ROOT")
        with tempfile.TemporaryDirectory(prefix="r9b-owner-state-") as temp_name:
            os.environ["METOD_STATE_ROOT"] = str(Path(temp_name) / "state")
            try:
                server = importlib.import_module("server_py")
                self.assertIs(server._validate_submit_payload, validate_submit_payload)
                self.assertIs(server._sanitize_user_text, sanitize_user_text)
                self.assertIs(server._clean_text, clean_text)
                self.assertIs(server._public_error_message, public_error_message)
                self.assertIs(server._env_int, env_int)
                self.assertIs(server._env_flag, env_flag)
                self.assertIs(server._split_env_csv, split_env_csv)
                self.assertIs(
                    server._is_production_hardening_enabled,
                    production_hardening_enabled,
                )
                self.assertIsInstance(server._RUNTIME_CONFIG, RuntimeConfig)
                self.assertIsInstance(server._APP_PATHS, AppPaths)
                self.assertIsInstance(server._APP_CONTEXT, AppContext)
                self.assertIs(server._RUNTIME_CONFIG, server._APP_CONTEXT.config)
                self.assertIs(server._APP_PATHS, server._APP_CONTEXT.paths)
                self.assertEqual(server.STATE_ROOT, server._APP_PATHS.state_root)
                self.assertEqual(server.REQUESTS, server._APP_PATHS.requests)
                self.assertEqual(server.PRICING_ACTIVE, server._APP_PATHS.pricing_active)
            finally:
                if previous is None:
                    os.environ.pop("METOD_STATE_ROOT", None)
                else:
                    os.environ["METOD_STATE_ROOT"] = previous


class R9BConfigAndPathContractTests(unittest.TestCase):
    def test_server_builds_context_once_without_direct_config_path_construction(self) -> None:
        tree = ast.parse(SERVER.read_text(encoding="utf-8"), filename=str(SERVER))
        calls = [
            node for node in ast.walk(tree)
            if isinstance(node, ast.Call)
            and isinstance(node.func, ast.Name)
            and node.func.id == "build_app_context"
        ]
        self.assertEqual(len(calls), 1)
        source = SERVER.read_text(encoding="utf-8")
        self.assertNotIn("RuntimeConfig.from_environment", source)
        self.assertNotIn("AppPaths.from_environment", source)

    def test_app_context_composes_one_frozen_environment_projection(self) -> None:
        with tempfile.TemporaryDirectory(prefix="r9b-context-") as temp_name:
            state_root = Path(temp_name) / "state"
            context = build_app_context(
                app_root=Path(temp_name) / "release/app",
                environment={
                    "METOD_STATE_ROOT": str(state_root),
                    "METOD_PORT": "9012",
                    "METOD_PUBLIC_HOST": "context.test",
                },
            )
            self.assertEqual(context.config.port, 9012)
            self.assertEqual(context.config.public_base_url, "http://context.test:9012")
            self.assertEqual(context.paths.state_root, state_root.resolve())
            with self.assertRaises(FrozenInstanceError):
                context.config = RuntimeConfig.from_environment({})  # type: ignore[misc]

    def test_environment_helpers_remain_dynamic_and_fail_safe(self) -> None:
        environment = {
            "COUNT": " not-an-int ",
            "ENABLED": "production",
            "DISABLED": "no",
            "VALUES": " one, ,two ",
            "APP_ENV": "prod",
        }
        self.assertEqual(env_int("COUNT", 17, environment=environment), 17)
        self.assertTrue(env_flag("ENABLED", environment=environment))
        self.assertFalse(env_flag("DISABLED", True, environment=environment))
        self.assertEqual(split_env_csv("VALUES", environment=environment), ["one", "two"])
        self.assertTrue(production_hardening_enabled(environment=environment))

    def test_runtime_config_preserves_defaults_bounds_and_immutability(self) -> None:
        config = RuntimeConfig.from_environment(
            {
                "METOD_PORT": "9001",
                "METOD_PUBLIC_HOST": "example.test",
                "MAX_SSE_CLIENTS": "999",
                "RETENTION_ACTIVE_DAYS": "20",
                "RETENTION_OPEN_REQUEST_MAX_DAYS": "5",
                "METOD_EDGE_BAND_PRICE_PER_M": "7.25",
            }
        )
        self.assertEqual(config.port, 9001)
        self.assertEqual(config.public_base_url, "http://example.test:9001")
        self.assertEqual(config.max_sse_clients, 128)
        self.assertEqual(config.retention_active_days, 20)
        self.assertEqual(config.retention_open_request_max_days, 21)
        self.assertEqual(config.edge_band_price_per_m, 7.25)
        with self.assertRaises(FrozenInstanceError):
            config.port = 1  # type: ignore[misc]

    def test_app_paths_preserve_the_complete_state_layout(self) -> None:
        with tempfile.TemporaryDirectory(prefix="r9b-path-contract-") as temp_name:
            temp = Path(temp_name)
            app_root = temp / "release" / "app"
            state_root = temp / "state"
            paths = AppPaths.from_environment(
                app_root=app_root,
                environment={"METOD_STATE_ROOT": str(state_root)},
            )
            self.assertEqual(paths.app_root, app_root.resolve())
            self.assertEqual(paths.release_root, app_root.resolve().parent)
            self.assertEqual(paths.state_root, state_root.resolve())
            self.assertEqual(paths.jobs, state_root / "jobs")
            self.assertEqual(paths.requests_index, state_root / "index/requests_index.jsonl")
            self.assertEqual(paths.archive_transactions, state_root / "archive/.transactions")
            self.assertEqual(paths.pricing_active, state_root / "config/pricing_active.json")
            self.assertEqual(paths.ntfy_log, state_root / "client_logs/ntfy.log")
            with self.assertRaises(FrozenInstanceError):
                paths.state_root = temp  # type: ignore[misc]


class R9BFrontendFoundationTests(unittest.TestCase):
    def test_native_bootstrap_is_frozen_read_only_and_pii_free(self) -> None:
        node = shutil.which("node")
        self.assertIsNotNone(node, "Node is required by the existing release regression gate")
        selectors_source = (APP / "tool-a/state/selectors.js").read_bytes()
        selectors_url = "data:text/javascript;base64," + base64.b64encode(selectors_source).decode()
        store_source = (APP / "tool-a/state/store.js").read_text(encoding="utf-8")
        store_source = store_source.replace("./selectors.js", selectors_url).encode()
        bootstrap_source = (APP / "tool-a/bootstrap.js").read_text(encoding="utf-8")
        store_url = "data:text/javascript;base64," + base64.b64encode(store_source).decode()
        materials_source = (APP / "tool-a/steps/materials.js").read_bytes()
        materials_url = "data:text/javascript;base64," + base64.b64encode(materials_source).decode()
        panels_source = (APP / "tool-a/steps/panels.js").read_bytes()
        panels_url = "data:text/javascript;base64," + base64.b64encode(panels_source).decode()
        grain_source = (APP / "tool-a/steps/grain.js").read_bytes()
        grain_url = "data:text/javascript;base64," + base64.b64encode(grain_source).decode()
        customer_source = (APP / "tool-a/steps/customer.js").read_bytes()
        customer_url = "data:text/javascript;base64," + base64.b64encode(customer_source).decode()
        jobs_source = (APP / "tool-a/api/jobs.js").read_bytes()
        jobs_url = "data:text/javascript;base64," + base64.b64encode(jobs_source).decode()
        requests_source = (APP / "tool-a/api/requests.js").read_bytes()
        requests_url = "data:text/javascript;base64," + base64.b64encode(requests_source).decode()
        checkout_review_source = (APP / "tool-a/components/checkout-review.js").read_bytes()
        checkout_review_url = "data:text/javascript;base64," + base64.b64encode(checkout_review_source).decode()
        dialog_source = (APP / "tool-a/components/dialog.js").read_bytes()
        dialog_url = "data:text/javascript;base64," + base64.b64encode(dialog_source).decode()
        footer_source = (APP / "tool-a/components/footer.js").read_bytes()
        footer_url = "data:text/javascript;base64," + base64.b64encode(footer_source).decode()
        grain_preview_source = (APP / "tool-a/components/grain-preview.js").read_bytes()
        grain_preview_url = "data:text/javascript;base64," + base64.b64encode(grain_preview_source).decode()
        material_card_source = (APP / "tool-a/components/material-card.js").read_bytes()
        panel_editor_source = (APP / "tool-a/components/panel-editor.js").read_bytes()
        material_card_url = "data:text/javascript;base64," + base64.b64encode(material_card_source).decode()
        panel_editor_url = "data:text/javascript;base64," + base64.b64encode(panel_editor_source).decode()
        mobile_cart_source = (APP / "tool-a/components/mobile-material-cart.js").read_bytes()
        mobile_cart_url = "data:text/javascript;base64," + base64.b64encode(mobile_cart_source).decode()
        overlay_router_source = (APP / "tool-a/components/overlay-router.js").read_bytes()
        overlay_router_url = "data:text/javascript;base64," + base64.b64encode(overlay_router_source).decode()
        progress_source = (APP / "tool-a/components/progress-overlay.js").read_bytes()
        progress_url = "data:text/javascript;base64," + base64.b64encode(progress_source).decode()
        thank_you_source = (APP / "tool-a/components/thank-you.js").read_bytes()
        thank_you_url = "data:text/javascript;base64," + base64.b64encode(thank_you_source).decode()
        bootstrap_source = bootstrap_source.replace("./state/store.js", store_url)
        bootstrap_source = bootstrap_source.replace("./steps/materials.js", materials_url)
        bootstrap_source = bootstrap_source.replace("./steps/panels.js", panels_url)
        bootstrap_source = bootstrap_source.replace("./steps/grain.js", grain_url)
        bootstrap_source = bootstrap_source.replace("./steps/customer.js", customer_url)
        bootstrap_source = bootstrap_source.replace("./api/jobs.js", jobs_url)
        bootstrap_source = bootstrap_source.replace("./api/requests.js", requests_url)
        bootstrap_source = bootstrap_source.replace("./components/checkout-review.js", checkout_review_url)
        bootstrap_source = bootstrap_source.replace("./components/dialog.js", dialog_url)
        bootstrap_source = bootstrap_source.replace("./components/footer.js", footer_url)
        bootstrap_source = bootstrap_source.replace("./components/grain-preview.js", grain_preview_url)
        bootstrap_source = bootstrap_source.replace("./components/material-card.js", material_card_url)
        bootstrap_source = bootstrap_source.replace("./components/panel-editor.js", panel_editor_url)
        bootstrap_source = bootstrap_source.replace("./components/mobile-material-cart.js", mobile_cart_url)
        bootstrap_source = bootstrap_source.replace("./components/overlay-router.js", overlay_router_url)
        bootstrap_source = bootstrap_source.replace("./components/progress-overlay.js", progress_url)
        bootstrap_source = bootstrap_source.replace("./components/thank-you.js", thank_you_url)
        bootstrap_url = "data:text/javascript;base64," + base64.b64encode(
            bootstrap_source.encode("utf-8")
        ).decode()
        probe = f"""
globalThis.state = {{
  activeMaterialKey: 'M2',
  materialBatches: [{{key:'M1'}}, {{key:'M2'}}],
  cart: [{{id:'P1', customerEmail:'must-not-project@example.test'}}],
  extraPanels: [{{id:'E1'}}],
  grain: {{groups:[{{id:'G1'}}]}},
  checkout: {{customer:{{firstName:'Private'}}}},
}};
globalThis.__metod_uiStep = 'panels';
const module = await import({json.dumps(bootstrap_url)});
const descriptor = Object.getOwnPropertyDescriptor(globalThis, 'ToolAR9Foundation');
const snapshot = globalThis.ToolAR9Foundation.getSnapshot();
const materialsView = globalThis.ToolAR9Foundation.getMaterialsView();
const panelsView = globalThis.ToolAR9Foundation.getPanelsView();
const grainView = globalThis.ToolAR9Foundation.getGrainView();
const customerView = globalThis.ToolAR9Foundation.getCustomerView();
const secondSnapshot = module.toolAStore.getSnapshot();
console.log(JSON.stringify({{
  revision: globalThis.ToolAR9Foundation.revision,
  mode: globalThis.ToolAR9Foundation.mode,
  globalFrozen: Object.isFrozen(globalThis.ToolAR9Foundation),
  descriptorWritable: descriptor.writable,
  descriptorConfigurable: descriptor.configurable,
  snapshotFrozen: Object.isFrozen(snapshot),
  sameAdapter: module.foundationAdapter === globalThis.ToolAR9Foundation,
  snapshot,
  materialsView,
  materialsViewFrozen: Object.isFrozen(materialsView),
  panelsView,
  panelsViewFrozen: Object.isFrozen(panelsView),
  grainView,
  grainViewFrozen: Object.isFrozen(grainView),
  customerView,
  customerViewFrozen: Object.isFrozen(customerView),
  customerSnapshotFrozen: Object.isFrozen(customerView.customerSnapshot),
  snapshotKeys: Reflect.ownKeys(snapshot),
  sameSnapshotShape: JSON.stringify(secondSnapshot) === JSON.stringify(snapshot),
  separateSnapshots: secondSnapshot !== snapshot,
  hasMutationSurface: ['dispatch','subscribe','setState','replaceState'].some(
    key => key in globalThis.ToolAR9Foundation || key in module.toolAStore
      || key in module.materialsViewConsumer || key in module.panelsViewConsumer
      || key in module.grainViewConsumer || key in module.customerViewConsumer
  ),
  compatibilityGlobals: Reflect.ownKeys(globalThis).filter(
    key => typeof key === 'string' && key.startsWith('ToolAR9')
  ),
}}));
"""
        completed = subprocess.run(
            [str(node), "--input-type=module"],
            input=probe,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=10,
            check=False,
        )
        self.assertEqual(completed.returncode, 0, completed.stdout)
        result = json.loads(completed.stdout.strip().splitlines()[-1])
        self.assertEqual(
            result,
            {
                "revision": "R9I_SYNC_CATALOG_REFRESH_CLEANUP_9",
                "mode": "legacy-read-cleanup-adapter",
                "globalFrozen": True,
                "descriptorWritable": False,
                "descriptorConfigurable": False,
                "snapshotFrozen": True,
                "snapshot": {
                    "currentStep": "panels",
                    "activeMaterialKey": "M2",
                    "materialBatchCount": 2,
                    "standardPanelLineCount": 1,
                    "extraPanelLineCount": 1,
                    "grainGroupCount": 1,
                    "hasActiveMaterial": True,
                    "hasPanels": True,
                },
                "materialsView": {
                    "activeMaterialKey": "M2",
                    "selectedMaterialCount": 2,
                    "hasSelection": True,
                    "isMaterialStep": False,
                },
                "materialsViewFrozen": True,
                "panelsView": {
                    "standardPanelLineCount": 1,
                    "extraPanelLineCount": 1,
                    "totalPanelLineCount": 2,
                    "hasPanels": True,
                    "isPanelsStep": True,
                },
                "panelsViewFrozen": True,
                "grainView": {
                    "grainGroupCount": 1,
                    "hasGrainGroups": True,
                    "isGrainStep": False,
                },
                "grainViewFrozen": True,
                "customerView": {
                    "customerSnapshot": {
                        "firstName": "Private", "lastName": "", "company": "",
                        "email": "", "phone": "", "billingAddress": "",
                        "shippingAddress": "", "shippingSameAsBilling": True,
                        "postcode": "", "houseNumber": "", "address1": "",
                        "address2": "", "city": "", "country": "",
                    },
                    "hasCustomerData": True,
                    "hasRequiredEmail": False,
                    "isCustomerStep": False,
                    "readSucceeded": True,
                },
                "customerViewFrozen": True,
                "customerSnapshotFrozen": True,
                "snapshotKeys": [
                    "currentStep", "activeMaterialKey", "materialBatchCount",
                    "standardPanelLineCount", "extraPanelLineCount", "grainGroupCount",
                    "hasActiveMaterial", "hasPanels",
                ],
                "sameAdapter": True,
                "sameSnapshotShape": True,
                "separateSnapshots": True,
                "hasMutationSurface": False,
                "compatibilityGlobals": ["ToolAR9Foundation"],
            },
        )

    def test_native_modules_are_exactly_allowlisted_and_nonce_compatible(self) -> None:
        server = importlib.import_module("server_py")
        expected = {
            "tool-a/bootstrap.js", "tool-a/api/jobs.js", "tool-a/api/requests.js", "tool-a/state/store.js",
            "tool-a/components/checkout-review.js",
            "tool-a/components/dialog.js", "tool-a/components/footer.js", "tool-a/components/grain-preview.js", "tool-a/components/material-card.js", "tool-a/components/mobile-material-cart.js",
            "tool-a/components/overlay-router.js",
            "tool-a/components/panel-editor.js",
            "tool-a/components/progress-overlay.js",
            "tool-a/components/thank-you.js",
            "tool-a/state/selectors.js", "tool-a/steps/materials.js",
            "tool-a/steps/panels.js",
            "tool-a/steps/grain.js",
            "tool-a/steps/customer.js",
        }
        self.assertEqual(PUBLIC_STATIC_MODULE_FILES, expected)
        for relative in expected:
            self.assertTrue(is_public_static_relpath(relative), relative)
        for relative in (
            "tool-a/unknown.js",
            "tool-a/state/../bootstrap.js",
            "tool-a/state/store.json",
        ):
            self.assertFalse(is_public_static_relpath(relative), relative)
        handler = object.__new__(server.Handler)
        translated = server.Handler.translate_path(
            handler, "/tool-a/bootstrap.js?v=r9b-foundation-1"
        )
        self.assertEqual(Path(translated), APP / "tool-a/bootstrap.js")
        prepared = server.Handler._prepare_html(
            handler,
            '<script type="module" src="tool-a/bootstrap.js?v=r9i-sync-catalog-refresh-cleanup-9"></script>',
        )
        self.assertRegex(prepared, r'<script nonce="[^"]+" type="module"')

    def test_architecture_gate_passes_with_node_syntax_proof(self) -> None:
        completed = subprocess.run(
            [
                sys.executable,
                "-B",
                str(RELEASE / "tools/r9b_architecture_gate.py"),
                "--release",
                str(RELEASE),
                "--require-node",
            ],
            cwd=RELEASE,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=20,
            check=False,
        )
        self.assertEqual(completed.returncode, 0, completed.stdout)
        self.assertIn("R9B ARCHITECTURE GATE: PASS", completed.stdout)


class R9BSubmissionContractTests(unittest.TestCase):
    def test_public_error_messages_remain_exact(self) -> None:
        self.assertEqual(
            {code: public_error_message(code) for code in (400, 403, 404, 413, 429)},
            {
                400: "Ongeldige aanvraag.",
                403: "Actie niet toegestaan.",
                404: "Niet gevonden.",
                413: "Aanvraag te groot.",
                429: "Te veel verzoeken. Probeer het later opnieuw.",
            },
        )
        self.assertEqual(public_error_message(500, "veilig"), "veilig")

    def test_text_normalization_remains_bounded_and_deterministic(self) -> None:
        self.assertEqual(clean_text("abcdef", 3), "abc")
        self.assertEqual(sanitize_user_text("  Jan\nvan/Dijk 😀 "), "Jan van Dijk")
        self.assertEqual(sanitize_phone_text("+31 (0)6 abc 12 34"), "+31 (0)6 12 34")
        self.assertEqual(sanitize_postcode_text(" 1234-ab "), "1234AB")

    def test_valid_submit_payload_keeps_the_existing_projection(self) -> None:
        payload = {
            "parentJobId": "JOB_123",
            "customer": {
                "firstName": "  Jan ",
                "lastName": "van/Dijk",
                "email": "jan@example.nl",
                "phone": "+31 (0)6-123",
                "postalCode": "1234 ab",
                "shippingSameAsBilling": True,
            },
            "note": "Graag\nvoorzichtig/afwerken",
            "materialsSummary": [{"code": "M1", "name": "Decor", "plates": 2}],
            "priceInclVat": "120.50",
            "cart": [{"id": "P1", "qty": 2, "width": 597, "edgeBanding": {"left": 1}}],
        }
        ok, errors, clean = validate_submit_payload(payload)
        self.assertTrue(ok)
        self.assertEqual(errors, [])
        self.assertEqual(clean["parentJobId"], "JOB_123")
        self.assertEqual(clean["customer"]["lastName"], "van Dijk")
        self.assertEqual(clean["customer"]["postalCode"], "1234 AB")
        self.assertEqual(clean["note"], "Graag voorzichtig afwerken")
        self.assertEqual(clean["priceInclVat"], 120.5)
        self.assertEqual(clean["cart"][0]["qty"], 2)

    def test_invalid_boundaries_remain_fail_closed(self) -> None:
        cases = (
            (None, "Payload must be a JSON object."),
            ({"unknown": True}, "Onbekende velden in aanvraagpayload."),
            ({"parentJobId": "../escape"}, "Ongeldige waarde voor parentJobId."),
            ({"customer": {"email": "geen-email"}}, "E-mailadres is ongeldig."),
            ({"grainEnabled": "true"}, "grainEnabled moet true of false zijn."),
            ({"quote": {"bad": float("nan")}}, "Quote kon niet worden verwerkt."),
            ({"cart": [{"qty": 0}]}, "cart regel 1 heeft een ongeldig aantal."),
        )
        for payload, expected_error in cases:
            with self.subTest(payload=payload):
                ok, errors, _clean = validate_submit_payload(payload)
                self.assertFalse(ok)
                self.assertIn(expected_error, errors)

    def test_email_contract_is_unchanged(self) -> None:
        self.assertIsNotNone(EMAIL_RE.fullmatch("klant@example.nl"))
        self.assertIsNone(EMAIL_RE.fullmatch("ongeldig"))


if __name__ == "__main__":
    unittest.main(verbosity=2)
