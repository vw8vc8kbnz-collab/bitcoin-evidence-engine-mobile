#!/usr/bin/env python3
from __future__ import annotations

import ast
import base64
import hashlib
import json
import subprocess
import unittest
from pathlib import Path

from r9h_shell_source import read_toola_expanded
from r9j_hermetic_reference import assert_sealed_file, load_reference


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
COMPONENT = APP / "tool-a/components/grain-preview.js"
BOOTSTRAP = APP / "tool-a/bootstrap.js"
HTML = APP / "toolA.html"
RENDERER = APP / "toolA_grain_studio_renderer.js"
MOBILE = APP / "toolA_grain_mobile_scale.js"
RULES = ROOT / "R9B_ARCHITECTURE_RULES.json"
REFERENCE = load_reference(ROOT)


def data_url(path: Path) -> str:
    encoded = base64.b64encode(path.read_bytes()).decode("ascii")
    return f"data:text/javascript;base64,{encoded}"


def run_node(source: str) -> dict:
    completed = subprocess.run(
        ["node", "--input-type=module"], input=source, text=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=10, check=False,
    )
    if completed.returncode != 0:
        raise AssertionError(completed.stdout)
    return json.loads(completed.stdout.strip().splitlines()[-1])


def assignment_set(path: Path, name: str) -> set[str]:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(
            isinstance(target, ast.Name) and target.id == name for target in node.targets
        ):
            value = node.value
            if isinstance(value, ast.Call) and isinstance(value.func, ast.Name) and value.func.id == "frozenset":
                value = value.args[0]
            return set(ast.literal_eval(value))
    raise AssertionError(name)


class R9HGrainPreviewComponentTests(unittest.TestCase):
    def test_01_component_surface_is_frozen_and_revisioned(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});
const c=m.createGrainPreviewComponent({{documentRef:{{}},rootRef:{{}}}});
console.log(JSON.stringify({{build:m.GRAIN_PREVIEW_COMPONENT_BUILD,componentBuild:c.BUILD,frozen:Object.isFrozen(c),keys:Reflect.ownKeys(c)}}));
""")
        self.assertEqual(result["build"], "R9H_GRAIN_PREVIEW_COMPONENT_7")
        self.assertEqual(result["componentBuild"], result["build"])
        self.assertTrue(result["frozen"])
        self.assertEqual(result["keys"], [
            "BUILD", "bind", "render", "schedule", "productionReadiness",
            "groupDimensions", "announceReady",
        ])

    def test_02_render_delegates_once_to_exact_legacy_draw_engine(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});let calls=0,prepared=0,received=null;
const host={{id:'grainPreview'}};const renderer={{prepareHost:h=>{{prepared++;received=h;}},render:h=>{{calls++;received=h;}}}};
const c=m.createGrainPreviewComponent({{documentRef:{{getElementById:()=>host}},rootRef:{{ToolAGrainStudioRenderer:renderer}}}});
console.log(JSON.stringify({{ok:c.render({{prepare:true}}),calls,prepared,same:received===host}}));
""")
        self.assertEqual(result, {"ok": True, "calls": 1, "prepared": 1, "same": True})

    def test_03_render_fails_closed_without_host_or_renderer(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});
const a=m.createGrainPreviewComponent({{documentRef:{{}},rootRef:{{}}}});
const b=m.createGrainPreviewComponent({{documentRef:{{getElementById:()=>({{}})}},rootRef:{{}}}});
console.log(JSON.stringify({{noHost:a.render(),noRenderer:b.render()}}));
""")
        self.assertEqual(result, {"noHost": False, "noRenderer": False})

    def test_04_schedule_coalesces_on_one_native_animation_frame(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});let next=0,cancelled=[],frames=new Map(),renders=0;
const host={{isConnected:true,getBoundingClientRect:()=>({{width:420,height:520}})}};const rootRef={{ToolAGrainStudioRenderer:{{render:()=>renders++}},requestAnimationFrame:fn=>{{const id=++next;frames.set(id,fn);return id;}},cancelAnimationFrame:id=>cancelled.push(id)}};
const c=m.createGrainPreviewComponent({{documentRef:{{getElementById:()=>host}},rootRef}});c.schedule();c.schedule();frames.get(2)();
console.log(JSON.stringify({{renders,cancelled,pending:frames.size}}));
""")
        self.assertEqual(result["renders"], 1)
        self.assertEqual(result["cancelled"], [1])

    def test_05_bind_observes_only_host_once_and_deduplicates_equal_boxes(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});let observed=[],created=0,renders=0,observer=null;const host={{id:'host',isConnected:true,getBoundingClientRect:()=>({{width:420,height:520}})}};
class O{{constructor(fn){{created++;this.fn=fn;observer=this;}}observe(x){{observed.push(x.id);}}}}
const rootRef={{ToolAGrainStudioRenderer:{{render:()=>renders++}}}};const c=m.createGrainPreviewComponent({{documentRef:{{getElementById:()=>host}},rootRef}});
c.bind({{ResizeObserver:O}});c.bind({{ResizeObserver:O}});observer.fn([{{target:host,contentRect:{{width:420,height:520}}}}]);observer.fn([{{target:host,contentRect:{{width:420,height:520}}}}]);
console.log(JSON.stringify({{created,observed,renders}}));
""")
        self.assertEqual(result, {"created": 1, "observed": ["host"], "renders": 3})

    def test_06_readiness_and_group_dimensions_are_transparent(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});const readiness={{ok:true,required:2,token:'grain-data:v2:x'}};const dims={{summary:{{validSameWidth:true}},semanticPanels:[1,2]}};
const c=m.createGrainPreviewComponent({{documentRef:{{}},rootRef:{{ToolAGrainStudioRenderer:{{render:()=>{{}},productionReadiness:()=>readiness,groupDims:g=>g===7?dims:null}}}}}});
console.log(JSON.stringify({{sameReadiness:c.productionReadiness()===readiness,sameDims:c.groupDimensions(7)===dims}}));
""")
        self.assertEqual(result, {"sameReadiness": True, "sameDims": True})

    def test_07_missing_renderer_readiness_is_explicit_no_go(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});const c=m.createGrainPreviewComponent({{documentRef:{{}},rootRef:{{}}}});console.log(JSON.stringify(c.productionReadiness()));
""")
        self.assertFalse(result["ok"])
        self.assertEqual(result["problems"][0]["code"], "missing-preview-renderer")
        self.assertEqual(result["token"], "grain-data:v2:")

    def test_08_ready_event_is_idempotent(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});const events=[];class E{{constructor(type){{this.type=type;}}}}
const c=m.createGrainPreviewComponent({{documentRef:{{dispatchEvent:e=>events.push(e.type)}},rootRef:{{Event:E}}}});
console.log(JSON.stringify({{first:c.announceReady(),second:c.announceReady(),events}}));
""")
        self.assertEqual(result, {"first": True, "second": False, "events": ["tool-a-grain-preview-owner-ready"]})

    def test_09_bootstrap_and_html_publish_one_native_preview_route(self) -> None:
        bootstrap = BOOTSTRAP.read_text(encoding="utf-8")
        html = read_toola_expanded(HTML)
        self.assertEqual(bootstrap.count('from "./components/grain-preview.js"'), 1)
        self.assertEqual(bootstrap.count("createGrainPreviewComponent()"), 1)
        self.assertEqual(bootstrap.count("grainPreviewComponent.bind();"), 1)
        self.assertEqual(bootstrap.count("grainPreviewComponent.announceReady();"), 1)
        self.assertIn('"R9RC1_PROFESSIONAL_ARCHITECTURE_COMPLETION"', bootstrap)
        self.assertIn('mode: "legacy-read-cleanup-adapter"', bootstrap)
        for method in ("bindGrainPreview", "renderGrainPreview", "scheduleGrainPreview", "getGrainPreviewReadiness", "getGrainGroupDimensions"):
            self.assertEqual(bootstrap.count(f"  {method}:"), 1, method)
        self.assertIn("tool-a/bootstrap.js?v=r9rc1-professional-architecture-completion", html)
        self.assertEqual(html.count("toolAFoundation.renderGrainPreview({container:grainPreview})"), 1)
        self.assertNotIn("ToolAR9Foundation", html)

    def test_10_legacy_renderer_and_mobile_adapters_route_to_native_owner(self) -> None:
        renderer = RENDERER.read_text(encoding="utf-8")
        mobile = MOBILE.read_text(encoding="utf-8")
        self.assertIn("owner.scheduleGrainPreview({container:host})", renderer)
        self.assertNotIn("function observe()", renderer)
        self.assertNotIn("new ResizeObserver", renderer)
        self.assertEqual(mobile.count("const schedulePreview="), 1)
        self.assertEqual(mobile.count("const renderPreview="), 1)
        self.assertNotIn("try{r.render(host)", mobile)
        self.assertNotIn("renderGroups();root.ToolAGrainStudioRenderer&&root.ToolAGrainStudioRenderer.schedule()", mobile)

    def test_11_architecture_and_static_allowlists_publish_eighteen_modules(self) -> None:
        rules = json.loads(RULES.read_text(encoding="utf-8"))["frontend"]
        owner = "app/tool-a/components/grain-preview.js"
        self.assertIn(owner, rules["domOwnerModules"])
        self.assertEqual(rules["moduleImports"][owner], [])
        self.assertEqual(len(rules["domOwnerModules"]), 10)
        self.assertEqual(len(rules["publicStaticFiles"]), 19)
        self.assertEqual(assignment_set(APP / "metod_app/http/static.py", "PUBLIC_STATIC_MODULE_FILES"),
                         assignment_set(APP / "metod_app/http/static.py", "PUBLIC_STATIC_MODULE_FILES"))
        self.assertEqual(len(assignment_set(APP / "metod_app/http/static.py", "PUBLIC_STATIC_MODULE_FILES")), 19)

    def test_12_protected_geometry_payload_optimizer_and_css_are_unchanged(self) -> None:
        # Exact known-good hashes; the explicit list keeps this component extraction fail-closed.
        exact = {
            "dxf_nesting_optimizer.py": "42480b301cd660dac1e5e9fec2c8d30bb5c6826c32234a9c1cce765b758bebb8",
            "dxf_geometry.py": "b80a2d006241908bf7b33516f7e0faf59ef61e1e08db86966b23cc5de292c1ff",
            "pricing_helpers.py": "646c2f5186e9b080f6ba8dcf364884411c18e946254bb5c9001647f7cbb425df",
            "panel_contract.py": "e23314fd63a2358a48daa580a92cebb8a40c9862548ba0243461a59347da7fc9",
        }
        for name, digest in exact.items():
            self.assertEqual(hashlib.sha256((APP / name).read_bytes()).hexdigest(), digest, name)
        for css in ("toolA_grain_studio.css", "toolA_grain_mobile_scale.css"):
            assert_sealed_file(self, ROOT, REFERENCE, f"app/{css}")


if __name__ == "__main__":
    unittest.main(verbosity=2)
