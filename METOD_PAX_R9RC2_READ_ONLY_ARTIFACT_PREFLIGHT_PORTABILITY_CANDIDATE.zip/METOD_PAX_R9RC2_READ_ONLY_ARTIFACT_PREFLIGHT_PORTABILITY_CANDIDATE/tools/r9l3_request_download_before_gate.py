#!/usr/bin/env python3
from __future__ import annotations

"""Seal and reproduce the R9L2 request/download projection behavior."""

import argparse
import ast
import hashlib
import json
import os
import sys
import tempfile
import types
import zipfile
from pathlib import Path
from unittest import mock


ROOT = Path(__file__).resolve().parents[1]
SERVER = ROOT / "app/server_py.py"
FIXTURE = ROOT / "R9L3_REQUEST_DOWNLOAD_BEFORE_FIXTURE.json"
APP = ROOT / "app"
os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")
_STATE_TEMP = tempfile.TemporaryDirectory(prefix="r9l3_request_download_import_")
os.environ.setdefault("METOD_STATE_ROOT", str(Path(_STATE_TEMP.name) / "state"))
sys.path.insert(0, str(APP))

import server_py as server  # noqa: E402


OWNER_NAMES = (
    "_find_or_generate_stickertool_file",
    "_build_request_file_manifest",
    "api_admin_request_files",
    "api_admin_request_file",
    "api_admin_request_download_zip",
    "api_admin_requests",
)


def _sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def _source_metrics(source: str) -> dict[str, object]:
    tree = ast.parse(source)
    owners: dict[str, object] = {}
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name in OWNER_NAMES:
            segment = ast.get_source_segment(source, node)
            if segment is None:
                raise RuntimeError(f"cannot read source for {node.name}")
            owners[node.name] = {
                "lines": len(segment.splitlines()),
                "bytes": len(segment.encode("utf-8")),
                "sha256": _sha256_bytes(segment.encode("utf-8")),
            }
    if set(owners) != set(OWNER_NAMES):
        raise RuntimeError(f"owner inventory mismatch: {sorted(owners)}")
    return {
        "server": {
            "bytes": len(source.encode("utf-8")),
            "lines": len(source.splitlines()),
            "sha256": _sha256_bytes(source.encode("utf-8")),
        },
        "activeOwnerSource": owners,
        "activeCallCountsExcludingDefinition": {
            name: source.count(f"{name}(") - 1 for name in OWNER_NAMES
        },
    }


def _handler(path: str):
    value = object.__new__(server.Handler)
    value.path = path
    value.client_address = ("127.0.0.1", 12345)
    value.headers = {}
    value._send_json = types.MethodType(
        lambda self, payload, status=200, headers=None: {
            "kind": "json", "status": int(status), "payload": payload,
        },
        value,
    )
    value._send_text = types.MethodType(
        lambda self, text, status=200, ctype="text/plain": {
            "kind": "text", "status": int(status), "text": str(text), "contentType": ctype,
        },
        value,
    )
    return value


def _mailbox_scenario(root: Path) -> dict[str, object]:
    requests = root / "mailbox"
    requests.mkdir(parents=True)
    rows = {
        "REQ_OLD": {"createdAt": "2026-01-01T10:00:00Z", "customer": {"name": "Oud"}},
        "REQ_NEW": {"updatedAt": "2026-02-01T10:00:00Z", "customer": {"name": "Nieuw"}},
    }
    for request_id, status in rows.items():
        request_root = requests / request_id
        request_root.mkdir()
        (request_root / "status.json").write_text(json.dumps(status), encoding="utf-8")
    broken = requests / "REQ_BROKEN"
    broken.mkdir()
    (broken / "status.json").write_text("{broken", encoding="utf-8")
    before = {
        path.relative_to(requests).as_posix(): _sha256_bytes(path.read_bytes())
        for path in requests.rglob("*") if path.is_file()
    }
    with (
        mock.patch.multiple(server, REQUESTS=requests),
        mock.patch.object(server, "_ensure_request_dirs", return_value=None),
    ):
        one = server.api_admin_requests(_handler("/api/admin/requests?limit=1"))
        invalid = server.api_admin_requests(_handler("/api/admin/requests?limit=not-an-int"))
        zero = server.api_admin_requests(_handler("/api/admin/requests?limit=0"))
    after = {
        path.relative_to(requests).as_posix(): _sha256_bytes(path.read_bytes())
        for path in requests.rglob("*") if path.is_file()
    }
    return {
        "limitOne": one,
        "invalidLimitFallsBackTo200": invalid,
        "zeroClampsToOne": zero,
        "readOnly": before == after,
    }


def _manifest_fixture(root: Path) -> tuple[dict[str, object], dict[str, object]]:
    requests = root / "requests"
    jobs = root / "jobs"
    request_id = "REQ_R9L3_001"
    parent_id = "JOB_R9L3_PARENT"
    subjob_id = "JOB_R9L3_PARENT__mat_001"
    request_root = requests / request_id
    parent_root = jobs / parent_id
    subjob_root = jobs / subjob_id
    for path in (request_root, parent_root, subjob_root):
        path.mkdir(parents=True, exist_ok=True)
    status = {
        "requestId": request_id,
        "createdAt": "2026-08-25T08:00:00Z",
        "customer": {"name": "Klant Eén", "email": "klant@example.invalid"},
        "job": {"parentJobId": parent_id, "subjobs": [{"subjobId": subjob_id}]},
    }
    (request_root / "status.json").write_text(json.dumps(status), encoding="utf-8")
    fixed_files = {
        parent_id: [
            {"jobId": parent_id, "materialCode": "", "materialName": "", "name": "quote.json", "rel": "output/quote.json", "kind": "quote", "size": 11, "mtime": "2026-08-25T08:01:00Z"},
        ],
        subjob_id: [
            {"jobId": subjob_id, "materialCode": "MAT-1", "materialName": "Eiken", "name": "Sheet_001.dxf", "rel": "output/DXF_Zaagplaten/Sheet_001.dxf", "kind": "dxf", "size": 12, "mtime": "2026-08-25T08:02:00Z"},
            {"jobId": subjob_id, "materialCode": "MAT-1", "materialName": "Eiken", "name": "S01.dxf", "rel": "output/DXF_Zaagplaten/S01.dxf", "kind": "dxf", "size": 13, "mtime": "2026-08-25T08:03:00Z"},
            {"jobId": subjob_id, "materialCode": "MAT-1", "materialName": "Eiken", "name": "part-a.dxf", "rel": "output/DXF_Onderdelen/part-a.dxf", "kind": "dxf", "size": 14, "mtime": "2026-08-25T08:04:00Z"},
            {"jobId": subjob_id, "materialCode": "MAT-1", "materialName": "Eiken", "name": "stickertool.json", "rel": "output/stickertool.json", "kind": "stickertool", "size": 15, "mtime": "2026-08-25T08:05:00Z"},
            {"jobId": subjob_id, "materialCode": "MAT-1", "materialName": "Eiken", "name": "calculation_summary.txt", "rel": "output/calculation_summary.txt", "kind": "summary", "size": 16, "mtime": "2026-08-25T08:06:00Z"},
        ],
    }

    def material_context(job_root):
        if job_root.name == subjob_id:
            return {"materialCode": "MAT-1", "materialName": "Eiken"}
        return {"materialCode": "", "materialName": ""}

    def directory_size(path):
        return {request_id: 10, parent_id: 20, subjob_id: 30}.get(path.name, 0)

    patches = (
        mock.patch.multiple(server, REQUESTS=requests, JOBS=jobs),
        mock.patch.object(server, "_load_status", side_effect=lambda rid: status if rid == request_id else None),
        mock.patch.object(server, "_collect_job_output_files", side_effect=lambda jid: [dict(item) for item in fixed_files.get(jid, [])]),
        mock.patch.object(server, "_find_or_generate_stickertool_file", return_value=None),
        mock.patch.object(server, "_job_material_context", side_effect=material_context),
        mock.patch.object(server, "_admin_sheet_download_name", side_effect=lambda _root, _name, customer=None: "Klant_Een__Eiken__001.dxf"),
        mock.patch.object(server, "_extract_strict_calculation_pricing_summary", return_value={"totalInclVat": 121.0, "currency": "EUR", "source": "calculation-summary"}),
        mock.patch.object(server, "_finalization_complete", return_value=True),
        mock.patch.object(server, "_dir_size_bytes", side_effect=directory_size),
    )
    for patcher in patches:
        patcher.start()
    try:
        manifest = server._build_request_file_manifest(request_id)
        missing = server.api_admin_request_files(_handler("/api/admin/request_files"))
        unknown = server.api_admin_request_files(_handler("/api/admin/request_files?requestId=REQ_UNKNOWN"))
        found = server.api_admin_request_files(_handler(f"/api/admin/request_files?requestId={request_id}"))

        file_missing = server.api_admin_request_file(_handler("/api/admin/request_file"))
        file_unknown = server.api_admin_request_file(_handler("/api/admin/request_file?requestId=REQ_UNKNOWN&jobId=JOB_UNKNOWN&rel=output/x"))
        file_unlinked = server.api_admin_request_file(_handler(f"/api/admin/request_file?requestId={request_id}&jobId={subjob_id}&rel=output/not-linked.dxf"))
        with mock.patch.object(
            server,
            "api_job_file",
            side_effect=lambda _handler, job_id, rel, parsed=None, download_name_override=None: {
                "delegated": True,
                "jobId": job_id,
                "rel": rel,
                "downloadName": download_name_override,
            },
        ):
            linked = server.api_admin_request_file(_handler(
                f"/api/admin/request_file?requestId={request_id}&jobId={subjob_id}&rel=output/DXF_Zaagplaten/S01.dxf"
            ))
    finally:
        for patcher in reversed(patches):
            patcher.stop()
    routes = {
        "requestFilesMissing": missing,
        "requestFilesUnknown": unknown,
        "requestFilesFound": found,
        "requestFileMissing": file_missing,
        "requestFileUnknown": file_unknown,
        "requestFileUnlinked": file_unlinked,
        "requestFileLinked": linked,
    }
    return manifest, routes


def _zip_scenario(root: Path) -> dict[str, object]:
    jobs = root / "zip-jobs"
    system = root / "zip-system"
    source_root = jobs / "JOB_R9L3_ZIP"
    source = source_root / "output" / "DXF_Zaagplaten" / "S01.dxf"
    source.parent.mkdir(parents=True)
    source.write_bytes(b"0\nSECTION\n0\nEOF\n")
    system.mkdir(parents=True)
    request_id = "REQ_R9L3_ZIP"
    item = {
        "jobId": "JOB_R9L3_ZIP",
        "materialCode": "MAT/ONE",
        "name": "S01.dxf",
        "rel": "output/DXF_Zaagplaten/S01.dxf",
        "kind": "dxf",
        "downloadName": "Klant__Eiken__001.dxf",
    }
    status = {"requestId": request_id}
    manifest = {"allFiles": [item]}

    def stream_zip(path, **kwargs):
        with zipfile.ZipFile(path, "r") as archive:
            names = archive.namelist()
            members = [{"name": name, "sha256": _sha256_bytes(archive.read(name))} for name in names]
        return {"kind": "zip", "members": members, "downloadName": kwargs.get("download_name"), "contentType": kwargs.get("content_type"), "maxBytes": kwargs.get("max_bytes")}

    base_patches = (
        mock.patch.multiple(server, JOBS=jobs, SYSTEM_DIR=system),
        mock.patch.object(server, "_load_status", side_effect=lambda rid: status if rid == request_id else None),
        mock.patch.object(server, "_build_request_file_manifest", return_value=manifest),
        mock.patch.object(server, "_finalization_complete", return_value=True),
        mock.patch.object(server, "_sealed_output_artifacts", return_value={item["rel"]: source}),
        mock.patch.object(server, "_env_int", side_effect=lambda _name, default: default),
        mock.patch.object(server.secrets, "token_hex", return_value="12345678"),
    )
    for patcher in base_patches:
        patcher.start()
    try:
        invalid_id = server.api_admin_request_download_zip(_handler("/api/admin/request_download_zip?requestId=../bad&scope=dxf"))
        invalid_scope = server.api_admin_request_download_zip(_handler(f"/api/admin/request_download_zip?requestId={request_id}&scope=bad"))
        unknown = server.api_admin_request_download_zip(_handler("/api/admin/request_download_zip?requestId=REQ_UNKNOWN&scope=dxf"))
        success_handler = _handler(f"/api/admin/request_download_zip?requestId={request_id}&scope=dxf")
        success_handler._stream_file = stream_zip
        success = server.api_admin_request_download_zip(success_handler)
        with mock.patch.object(server, "_env_int", return_value=2):
            over_limit = server.api_admin_request_download_zip(_handler(f"/api/admin/request_download_zip?requestId={request_id}&scope=dxf"))
        with mock.patch.object(server, "_sealed_output_artifacts", return_value={}):
            stale = server.api_admin_request_download_zip(_handler(f"/api/admin/request_download_zip?requestId={request_id}&scope=dxf"))
        with mock.patch.object(server, "_build_request_file_manifest", return_value={"allFiles": []}):
            no_files = server.api_admin_request_download_zip(_handler(f"/api/admin/request_download_zip?requestId={request_id}&scope=dxf"))
    finally:
        for patcher in reversed(base_patches):
            patcher.stop()
    return {
        "invalidRequestId": invalid_id,
        "invalidScope": invalid_scope,
        "unknownRequestId": unknown,
        "noFiles": no_files,
        "staleManifest": stale,
        "overInputLimit": over_limit,
        "success": success,
    }


def _behavior() -> dict[str, object]:
    with tempfile.TemporaryDirectory(prefix="r9l3_request_download_gate_") as temp_name:
        root = Path(temp_name)
        manifest, routes = _manifest_fixture(root)
        return {
            "mailboxScenario": _mailbox_scenario(root),
            "manifestScenario": manifest,
            "routeOutcomeMatrix": routes,
            "zipOutcomeMatrix": _zip_scenario(root),
        }


def _fixture_value() -> dict[str, object]:
    source = _source_metrics(SERVER.read_text(encoding="utf-8", errors="strict"))
    return {
        "schemaVersion": 1,
        "fixtureId": "R9L3_REQUEST_DOWNLOAD_BEFORE_FIXTURE",
        "sourceCheckpoint": "R9L2",
        "sourceTag": "r9l2-observability-metrics-extraction-checkpoint",
        "sourceCommit": "8a703d8028cc42ffa860f5e102ce8897c0e58e00",
        **source,
        **_behavior(),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-check", action="store_true")
    parser.add_argument("--write-fixture", action="store_true")
    args = parser.parse_args()
    if args.write_fixture:
        FIXTURE.write_text(json.dumps(_fixture_value(), indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        print(json.dumps({"gate": "R9L3_REQUEST_DOWNLOAD_BEFORE_GATE", "status": "WRITTEN", "fixture": str(FIXTURE)}, sort_keys=True))
        return 0
    fixture = json.loads(FIXTURE.read_text(encoding="utf-8"))
    actual = _behavior()
    expected = {key: fixture[key] for key in actual}
    if actual != expected:
        raise AssertionError(json.dumps({"expected": expected, "actual": actual}, indent=2, ensure_ascii=False))
    if args.source_check:
        source_actual = _source_metrics(SERVER.read_text(encoding="utf-8", errors="strict"))
        source_expected = {key: fixture[key] for key in ("server", "activeOwnerSource", "activeCallCountsExcludingDefinition")}
        if source_actual != source_expected:
            raise AssertionError(json.dumps({"expected": source_expected, "actual": source_actual}, indent=2))
    print(json.dumps({
        "schemaVersion": 1,
        "gate": "R9L3_REQUEST_DOWNLOAD_BEFORE_GATE",
        "status": "PASS",
        "sourceCheck": bool(args.source_check),
        "behaviorScenarios": 4,
        "sealedRoutes": 4,
    }, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
