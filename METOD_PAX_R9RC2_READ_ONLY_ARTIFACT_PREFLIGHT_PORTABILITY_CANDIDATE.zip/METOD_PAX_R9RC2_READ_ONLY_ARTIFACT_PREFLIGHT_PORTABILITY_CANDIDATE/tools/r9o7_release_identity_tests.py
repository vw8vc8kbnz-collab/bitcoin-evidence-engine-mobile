#!/usr/bin/env python3
from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from r9o7_release_identity_gate import ARTIFACT, BUILD, GOLDEN_REVISION, REVISION, STATUS, audit_release, sbom_properties


ROOT = Path(__file__).resolve().parents[1]


class R9O7ReleaseIdentityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.identity = json.loads((ROOT / "RELEASE_IDENTITY.json").read_text(encoding="utf-8"))
        cls.runtime = json.loads((ROOT / "RUNTIME_CONTRACT.json").read_text(encoding="utf-8"))
        cls.sbom = json.loads((ROOT / "SBOM.cdx.json").read_text(encoding="utf-8"))

    def test_complete_gate_passes(self) -> None:
        report = audit_release(ROOT)
        self.assertEqual(report["status"], "PASS", report["failures"])

    def test_candidate_is_explicitly_provisional(self) -> None:
        candidate = self.identity["canonicalCandidate"]
        self.assertEqual(candidate["releaseRevision"], REVISION)
        self.assertEqual(candidate["buildId"], BUILD)
        self.assertEqual(candidate["status"], STATUS)
        self.assertFalse(candidate["releaseEligible"])
        self.assertFalse(self.identity["externalEvidence"]["productionGo"])

    def test_identity_surfaces_are_consistent(self) -> None:
        candidate = self.identity["canonicalCandidate"]
        properties = sbom_properties(self.sbom)
        self.assertEqual(candidate["artifactName"], ARTIFACT)
        self.assertEqual(self.runtime["releaseRevision"], candidate["releaseRevision"])
        self.assertEqual(self.runtime["build"], candidate["buildId"])
        self.assertEqual(properties["releaseRevision"], candidate["releaseRevision"])
        self.assertEqual(properties["artifactName"], candidate["artifactName"])
        self.assertEqual(self.identity["immutableGoldenBaseline"]["releaseRevision"], GOLDEN_REVISION)

    def test_builder_rejects_noncanonical_artifact_name(self) -> None:
        with tempfile.TemporaryDirectory(prefix="r9o7_identity_name_") as temporary:
            completed = subprocess.run(
                [sys.executable, "-B", str(ROOT / "tools/build_release_artifact.py"), "--output", str(Path(temporary) / "ambiguous.zip")],
                cwd=ROOT,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                timeout=10,
                check=False,
            )
        self.assertNotEqual(completed.returncode, 0)
        self.assertIn(f"artifact name must be canonical: {ARTIFACT}", completed.stdout)


if __name__ == "__main__":
    unittest.main(verbosity=2)
