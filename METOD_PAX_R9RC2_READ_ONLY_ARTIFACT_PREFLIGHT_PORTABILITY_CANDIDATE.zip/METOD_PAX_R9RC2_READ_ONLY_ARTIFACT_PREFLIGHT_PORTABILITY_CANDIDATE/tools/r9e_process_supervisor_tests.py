#!/usr/bin/env python3
from __future__ import annotations

import os
import signal
import subprocess
import sys
import threading
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "app"))

from metod_app.jobs.process_supervisor import (  # noqa: E402
    OptimizerDeadline,
    OptimizerProcessSupervisor,
)


class FakeProcess:
    def __init__(self, *, pid: int = 123, polls: list[int | None] | None = None) -> None:
        self.pid = pid
        self.polls = list(polls or [None, None])
        self.terminated = 0
        self.killed = 0
        self.waits: list[float] = []

    def poll(self) -> int | None:
        return self.polls.pop(0) if self.polls else None

    def terminate(self) -> None:
        self.terminated += 1

    def kill(self) -> None:
        self.killed += 1

    def wait(self, timeout: float) -> int:
        self.waits.append(timeout)
        return -15


class OptimizerProcessSupervisorTests(unittest.TestCase):
    def supervisor(self, *, platform: str = "posix", os_module=None):
        fake_os = os_module or SimpleNamespace(
            name=platform,
            getpgid=lambda pid: pid,
            getpgrp=lambda: 9999,
            killpg=lambda pgid, sig: None,
        )
        return OptimizerProcessSupervisor(
            lock=threading.RLock(), validate_job_id=lambda value: str(value),
            os_module=fake_os, signal_module=signal,
        )

    def test_registration_snapshot_and_cleanup_have_one_owner(self) -> None:
        owner = self.supervisor()
        first, second = object(), object()
        owner.register("job", first)
        owner.register("job", second)
        self.assertEqual(set(owner.active("job")), {first, second})
        owner.unregister("job", first)
        owner.unregister("job", second)
        self.assertEqual(owner.processes, {})

    def test_spawn_creates_dedicated_posix_session_and_remembers_group(self) -> None:
        owner = self.supervisor()
        process = FakeProcess(pid=321)
        popen = mock.Mock(return_value=process)
        self.assertIs(owner.spawn(popen=popen, command=["python", "tool.py"], cwd="/tmp"), process)
        popen.assert_called_once_with(
            ["python", "tool.py"], cwd="/tmp", start_new_session=True,
        )
        self.assertEqual(process._metod_process_group_id, 321)

    def test_spawn_non_posix_keeps_direct_process_fallback(self) -> None:
        owner = self.supervisor(platform="nt")
        process = FakeProcess()
        popen = mock.Mock(return_value=process)
        owner.spawn(popen=popen, command=["python"])
        popen.assert_called_once_with(["python"], start_new_session=False)
        self.assertFalse(hasattr(process, "_metod_process_group_id"))

    def test_already_exited_direct_process_returns_without_signal(self) -> None:
        owner = self.supervisor(platform="nt")
        process = FakeProcess(polls=[7])
        self.assertEqual(owner.terminate(process), 7)
        self.assertEqual((process.terminated, process.killed, process.waits), (0, 0, []))

    def test_posix_group_is_probed_and_escalated_after_parent_reap(self) -> None:
        signals: list[tuple[int, int]] = []
        fake_os = SimpleNamespace(
            name="posix", getpgid=lambda pid: pid, getpgrp=lambda: 9999,
            killpg=lambda pgid, sig: signals.append((pgid, sig)),
        )
        owner = self.supervisor(os_module=fake_os)
        process = FakeProcess(pid=456, polls=[None, 0])
        setattr(process, "_metod_process_group_id", 456)
        self.assertEqual(owner.terminate(process, terminate_timeout=0, kill_timeout=0), -15)
        self.assertEqual(signals, [(456, signal.SIGTERM), (456, 0), (456, signal.SIGKILL)])
        self.assertEqual(process.waits, [0.1, 0.1])

    def test_deadline_boundaries_and_family_priority_are_exact(self) -> None:
        clock = iter([10.0, 14.9, 15.0, 20.0, 16.0, 15.0])
        deadline = OptimizerDeadline.start(monotonic=lambda: next(clock), timeout_seconds=5)
        deadline.check_family("prepare")
        with self.assertRaisesRegex(RuntimeError, "Optimizer job family timeout during start"):
            deadline.check_family("start")
        subjob = deadline.start_subjob(3)
        self.assertEqual(subjob, 23.0)
        self.assertEqual(deadline.timeout_kind(subjob), "job family")
        self.assertEqual(deadline.timeout_kind(99), "job family")

    def test_subjob_timeout_and_non_timeout_are_distinguished(self) -> None:
        values = iter([0.0, 4.0, 6.0])
        deadline = OptimizerDeadline.start(monotonic=lambda: next(values), timeout_seconds=10)
        self.assertEqual(deadline.timeout_kind(5.0), "")
        self.assertEqual(deadline.timeout_kind(5.0), "subjob")

    @unittest.skipUnless(os.name == "posix", "POSIX process-group proof")
    def test_real_process_group_kills_sigterm_ignoring_child(self) -> None:
        owner = OptimizerProcessSupervisor(
            lock=threading.RLock(), validate_job_id=str,
            os_module=os, signal_module=signal,
        )
        script = (
            "import signal,subprocess,sys,time;"
            "signal.signal(signal.SIGTERM,lambda *_:None);"
            "c=subprocess.Popen([sys.executable,'-c',"
            "'import signal,time;signal.signal(signal.SIGTERM,lambda *_:None);time.sleep(60)']);"
            "print(c.pid,flush=True);time.sleep(60)"
        )
        process = owner.spawn(
            popen=subprocess.Popen, command=[sys.executable, "-c", script],
            stdout=subprocess.PIPE, text=True,
        )
        child_pid = int(process.stdout.readline().strip())
        try:
            owner.terminate(process, terminate_timeout=0.1, kill_timeout=2)
            process.wait(timeout=2)
            for _ in range(100):
                if not Path(f"/proc/{child_pid}").exists():
                    break
                try:
                    os.waitpid(child_pid, os.WNOHANG)
                except ChildProcessError:
                    pass
            self.assertFalse(Path(f"/proc/{child_pid}").exists())
        finally:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            if process.stdout is not None:
                process.stdout.close()


if __name__ == "__main__":
    unittest.main(verbosity=2)
