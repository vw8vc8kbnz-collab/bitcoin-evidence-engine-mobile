#!/usr/bin/env python3
from __future__ import annotations

"""Behavior and ownership proof for the R9C pure pricing-contract extraction."""

import ast
import importlib
import math
import os
import sys
import tempfile
import unittest
from pathlib import Path


RELEASE = Path(__file__).resolve().parents[1]
APP = RELEASE / "app"
SERVER = APP / "server_py.py"
sys.path.insert(0, str(APP))

from metod_app.pricing.contracts import (  # noqa: E402
    VAT_RATE,
    material_direct_sell_ex_vat,
    material_direct_sell_incl_vat,
)


class BrokenRecord(dict):
    def get(self, key, default=None):
        raise RuntimeError("deliberate")


class R9CPricingContractBehaviorTests(unittest.TestCase):
    def test_authoritative_gross_field_is_selected_in_established_order(self) -> None:
        record = {
            "sellPriceInclVatPerSheet": 69.57,
            "salePriceInclVatPerSheet": 88.88,
            "directSellPriceInclVatPerSheet": 99.99,
            "sellPriceExVatPerSheet": 1.0,
        }
        self.assertEqual(material_direct_sell_incl_vat(record), 69.57)
        self.assertEqual(VAT_RATE, 0.21)

    def test_all_established_gross_aliases_remain_supported(self) -> None:
        self.assertEqual(material_direct_sell_incl_vat({"salePriceInclVatPerSheet": "123.456"}), 123.46)
        self.assertEqual(material_direct_sell_incl_vat({"directSellPriceInclVatPerSheet": 42}), 42.0)

    def test_legacy_net_aliases_are_only_a_fallback_and_receive_vat(self) -> None:
        for key in (
            "sellPriceExVatPerSheet",
            "salePriceExVatPerSheet",
            "directSellPriceExVatPerSheet",
        ):
            self.assertEqual(
                material_direct_sell_incl_vat({key: 57.5}),
                round(57.5 * 1.21, 2),
                key,
            )
        self.assertEqual(
            material_direct_sell_incl_vat({
                "sellPriceInclVatPerSheet": -1,
                "sellPriceExVatPerSheet": 57.5,
            }),
            round(57.5 * 1.21, 2),
        )

    def test_invalid_and_unrelated_values_fail_closed(self) -> None:
        for record in (
            None,
            [],
            {},
            {"purchasePrice": 99.0},
            {"retailPriceWithoutTax": 99.0},
            {"sellPriceInclVatPerSheet": "bad"},
            {"sellPriceInclVatPerSheet": 0},
            {"sellPriceInclVatPerSheet": -10},
            {"sellPriceInclVatPerSheet": float("nan")},
            BrokenRecord(),
        ):
            self.assertEqual(material_direct_sell_incl_vat(record), 0.0, record)

    def test_accounting_net_equivalent_uses_the_exact_gross_truth(self) -> None:
        gross = material_direct_sell_incl_vat({"sellPriceInclVatPerSheet": 69.57})
        net = material_direct_sell_ex_vat({"sellPriceInclVatPerSheet": 69.57})
        self.assertEqual(gross, 69.57)
        self.assertTrue(math.isclose(net, 69.57 / 1.21, rel_tol=0.0, abs_tol=1e-12))
        self.assertEqual(material_direct_sell_ex_vat({}), 0.0)

    def test_helpers_do_not_mutate_catalog_records(self) -> None:
        record = {
            "sellPriceInclVatPerSheet": "69.57",
            "priceSource": "CSV_SALE_PRICE_INCL_VAT",
            "nested": {"preserve": True},
        }
        before = repr(record)
        material_direct_sell_incl_vat(record)
        material_direct_sell_ex_vat(record)
        self.assertEqual(repr(record), before)


class R9CPricingContractOwnershipTests(unittest.TestCase):
    def test_server_imports_exact_aliases_and_has_no_duplicate_owners(self) -> None:
        tree = ast.parse(SERVER.read_text(encoding="utf-8"), filename=str(SERVER))
        definitions = {
            node.name for node in tree.body
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
        }
        expected = {
            "_material_direct_sell_incl_vat",
            "_material_direct_sell_ex_vat",
        }
        self.assertEqual(definitions & expected, set())
        aliases = {
            alias.asname: alias.name
            for node in tree.body
            if isinstance(node, ast.ImportFrom)
            and node.module == "metod_app.pricing.contracts"
            for alias in node.names
        }
        self.assertEqual(
            aliases,
            {
                "_material_direct_sell_ex_vat": "material_direct_sell_ex_vat",
                "_material_direct_sell_incl_vat": "material_direct_sell_incl_vat",
            },
        )

    def test_server_uses_single_owner_and_module_has_no_state_or_io(self) -> None:
        previous = os.environ.get("METOD_STATE_ROOT")
        with tempfile.TemporaryDirectory(prefix="r9c-pricing-owner-") as temp_name:
            os.environ["METOD_STATE_ROOT"] = str(Path(temp_name) / "state")
            try:
                server = importlib.import_module("server_py")
                self.assertIs(server._material_direct_sell_incl_vat, material_direct_sell_incl_vat)
                self.assertIs(server._material_direct_sell_ex_vat, material_direct_sell_ex_vat)
            finally:
                if previous is None:
                    os.environ.pop("METOD_STATE_ROOT", None)
                else:
                    os.environ["METOD_STATE_ROOT"] = previous

        path = APP / "metod_app/pricing/contracts.py"
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        imports = {
            alias.name.split(".", 1)[0]
            for node in ast.walk(tree)
            if isinstance(node, ast.Import)
            for alias in node.names
        }
        imports.update(
            node.module.split(".", 1)[0]
            for node in ast.walk(tree)
            if isinstance(node, ast.ImportFrom) and node.module
        )
        self.assertEqual(
            imports & {
                "http", "json", "logging", "os", "pathlib", "server_py",
                "socket", "subprocess", "threading", "time",
            },
            set(),
        )
        calls = {
            node.func.id for node in ast.walk(tree)
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
        }
        self.assertFalse(calls & {"open", "print", "exec", "eval", "compile", "__import__"})


if __name__ == "__main__":
    unittest.main(verbosity=2)
