#!/usr/bin/env python3
from __future__ import annotations

"""Fail-closed equivalence proof for the R9I-3 material geometry readers."""

import base64
import json
import re
import shutil
import subprocess
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
SELECTORS = APP / "tool-a/state/selectors.js"
STORE = APP / "tool-a/state/store.js"
BOOTSTRAP = APP / "tool-a/bootstrap.js"
RUNTIME = APP / "tool-a/shell/script-06-legacy-application-runtime.js"


def data_url(data: bytes) -> str:
    return "data:text/javascript;base64," + base64.b64encode(data).decode()


def run_node(source: str) -> dict:
    node = shutil.which("node")
    if not node:
        raise AssertionError("Node is required by the R9I clean-code gate")
    completed = subprocess.run(
        [node, "--input-type=module"],
        input=source,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=10,
        check=False,
    )
    if completed.returncode != 0:
        raise AssertionError(completed.stdout)
    return json.loads(completed.stdout.strip().splitlines()[-1])


class R9IMaterialGeometryReaderTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.selectors_url = data_url(SELECTORS.read_bytes())
        store_source = STORE.read_text(encoding="utf-8").replace(
            "./selectors.js", cls.selectors_url,
        )
        cls.store_url = data_url(store_source.encode())

    def test_01_material_thickness_matches_removed_legacy_reader(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(self.selectors_url)});
function batch(state,key){{return (state.materialBatches||[]).find(b=>String(b&&b.key)===String(key));}}
function legacy(state,keyInput,catalog,defaultThickness){{
  const key=String(keyInput||'').trim();
  const activeKey=String(state?.activeMaterialKey||'').trim();
  const foundBatch=key?batch(state,key):null;
  const matObj=(foundBatch&&foundBatch.mat)?foundBatch.mat:((key&&activeKey&&key===activeKey)?state?.material:null)||state?.material||null;
  const thickness=Number(matObj?.thicknessMm);
  if(Number.isFinite(thickness)&&thickness>0)return thickness;
  try{{
    const found=(catalog||[]).find(item=>String(item?.articleNumber||'')===key||String(item?.materialCode||'')===key);
    const value=Number(found?.thicknessMm);
    if(Number.isFinite(value)&&value>0)return value;
  }}catch(_error){{}}
  return Number(state?.material?.thicknessMm||defaultThickness||18);
}}
const cases=[
  [{{activeMaterialKey:'a',material:{{thicknessMm:18}},materialBatches:[{{key:'a',mat:{{thicknessMm:19}}}}]}},'a',[],18],
  [{{activeMaterialKey:' active ',material:{{thicknessMm:'20'}},materialBatches:[]}},' active ',[],18],
  [{{material:{{thicknessMm:0}},materialBatches:[{{key:'bad',mat:{{thicknessMm:-1}}}}]}},'bad',[{{articleNumber:'bad',thicknessMm:21}}],18],
  [{{material:{{thicknessMm:''}},materialBatches:[]}},'catalog',[{{materialCode:'catalog',thicknessMm:'22'}}],18],
  [{{material:{{thicknessMm:''}},materialBatches:[]}},'missing',[],17],
  [{{material:{{thicknessMm:16}},materialBatches:[]}},'',[],18],
];
const pairs=cases.map(([state,key,catalog,fallback])=>[
  legacy(state,key,catalog,fallback),m.selectMaterialThickness(state,key,catalog,fallback)
]);
console.log(JSON.stringify({{pairs}}));
""")
        self.assertTrue(all(pair[0] == pair[1] for pair in result["pairs"]))

    def test_02_sheet_dimensions_and_margins_match_removed_legacy_readers(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(self.selectors_url)});
function legacyDimensions(state,keyInput,catalog){{
  try{{
    const key=String(keyInput||'').trim();
    const batch=(state?.materialBatches||[]).find(item=>String(item.key||'')===key);
    const mat=batch?.mat||((String(state?.activeMaterialKey||'')===key)?state?.material:null)||state?.material||null;
    const width=Number(mat?.sheetSizeMm?.width||0),height=Number(mat?.sheetSizeMm?.height||0);
    if(Number.isFinite(width)&&width>0&&Number.isFinite(height)&&height>0)return {{width,height,mat}};
    const found=(catalog||[]).find(item=>String(item.articleNumber||'')===key||String(item.materialCode||'')===key);
    const fw=Number(found?.sheetSizeMm?.width||0),fh=Number(found?.sheetSizeMm?.height||0);
    if(Number.isFinite(fw)&&fw>0&&Number.isFinite(fh)&&fh>0)return {{width:fw,height:fh,mat:found}};
  }}catch(_error){{}}
  return {{width:0,height:0,mat:null}};
}}
function legacyUsable(state,key,catalog){{
  const dimensions=legacyDimensions(state,key,catalog);
  const margin=Number(state?.defaults?.sheetMarginMm??state?.sheetMarginMm??7);
  return {{...dimensions,margin,usableW:Math.max(0,dimensions.width-2*margin),usableH:Math.max(0,dimensions.height-2*margin)}};
}}
const cases=[
  [{{materialBatches:[{{key:'a',mat:{{id:'batch',sheetSizeMm:{{width:2800,height:2070}}}}}}],defaults:{{sheetMarginMm:7}}}},'a',[]],
  [{{activeMaterialKey:'a',material:{{id:'active',sheetSizeMm:{{width:'3050',height:'1220'}}}},materialBatches:[],sheetMarginMm:5}},'a',[]],
  [{{activeMaterialKey:'other',material:{{id:'fallback',sheetSizeMm:{{width:2440,height:1220}}}},materialBatches:[],defaults:{{sheetMarginMm:0}}}},'missing',[]],
  [{{material:{{sheetSizeMm:{{width:0,height:0}}}},materialBatches:[]}},'catalog',[{{articleNumber:'catalog',id:'catalog',sheetSizeMm:{{width:3200,height:1600}}}}]],
  [{{material:null,materialBatches:[]}},'missing',[]],
];
const pairs=cases.map(([state,key,catalog])=>[
  legacyUsable(state,key,catalog),m.selectUsableMaterialSheetDimensions(state,key,catalog)
]);
console.log(JSON.stringify({{pairs}}));
""")
        self.assertTrue(all(pair[0] == pair[1] for pair in result["pairs"]))

    def test_03_store_reads_fresh_state_and_is_frozen(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(self.store_url)});
let state={{activeMaterialKey:'a',material:{{thicknessMm:18,sheetSizeMm:{{width:2800,height:2070}}}},materialBatches:[],defaults:{{sheetMarginMm:7}}}};
const store=m.createToolAStore(()=>({{state,runtime:{{}}}}));
const first={{thickness:store.getMaterialThickness('a',[],18),sheet:store.getUsableMaterialSheetDimensions('a',[])}};
state={{activeMaterialKey:'b',material:{{thicknessMm:20,sheetSizeMm:{{width:3050,height:1220}}}},materialBatches:[],sheetMarginMm:5}};
const second={{thickness:store.getMaterialThickness('b',[],18),sheet:store.getUsableMaterialSheetDimensions('b',[])}};
const broken=m.createToolAStore(()=>{{throw new Error('boom')}});
const fallback={{thickness:broken.getMaterialThickness('x',[],19),sheet:broken.getUsableMaterialSheetDimensions('x',[])}};
console.log(JSON.stringify({{first,second,fallback,keys:Reflect.ownKeys(store),frozen:Object.isFrozen(store)}}));
""")
        self.assertEqual(result["first"]["thickness"], 18)
        self.assertEqual(result["first"]["sheet"]["usableW"], 2786)
        self.assertEqual(result["second"]["thickness"], 20)
        self.assertEqual(result["second"]["sheet"]["usableH"], 1210)
        self.assertEqual(result["fallback"], {
            "thickness": 19,
            "sheet": {"width": 0, "height": 0, "mat": None, "margin": 7, "usableW": 0, "usableH": 0},
        })
        self.assertEqual(result["keys"], [
            "getSnapshot", "getCustomerSnapshot", "normalizeCustomerSnapshot",
            "getGrainMaterialKey", "isGrainEnabledForMaterial",
            "isGrainCapableItem", "parseGrainReference",
            "getMaterialThickness", "getUsableMaterialSheetDimensions",
        ])
        self.assertTrue(result["frozen"])

    def test_04_native_material_readers_have_no_side_effect_owner(self) -> None:
        source = SELECTORS.read_text(encoding="utf-8") + STORE.read_text(encoding="utf-8")
        for token in (
            "document", "addEventListener", "fetch(", "XMLHttpRequest", "EventSource",
            "WebSocket", "localStorage", "sessionStorage", "window", "globalThis",
        ):
            self.assertNotIn(token.lower(), source.lower(), token)

    def test_05_legacy_thickness_adapter_is_thin_and_sheet_readers_are_removed(self) -> None:
        source = RUNTIME.read_text(encoding="utf-8")
        match = re.search(
            r"^  function materialThicknessKey\([^\n]*\)\{(?P<body>.*?)^  \}",
            source,
            re.MULTILINE | re.DOTALL,
        )
        self.assertIsNotNone(match)
        body = match.group("body")
        self.assertIn("ensureStateShape()", body)
        self.assertIn("owner.getMaterialThickness(k, window.MATERIAL_CATALOG, DEFAULT_THICKNESS_MM)", body)
        for removed in ("activeKey", "batch", "matObj", ".find("):
            self.assertNotIn(removed, body)
        self.assertNotIn("function sheetDimsForMaterialKey", source)
        self.assertNotIn("function usableSheetDimsForMaterialKey", source)
        self.assertEqual(
            source.count("owner.getUsableMaterialSheetDimensions(materialKey, window.MATERIAL_CATALOG)"),
            1,
        )

    def test_06_bootstrap_exposes_one_material_read_surface(self) -> None:
        source = BOOTSTRAP.read_text(encoding="utf-8")
        self.assertIn('"R9I_SYNC_CATALOG_REFRESH_CLEANUP_9"', source)
        self.assertEqual(
            source.count("getMaterialThickness: (materialKey, materialCatalog, defaultThicknessMm)"),
            1,
        )
        self.assertEqual(
            source.count("getUsableMaterialSheetDimensions: (materialKey, materialCatalog)"),
            1,
        )
        self.assertEqual(source.count("Object.defineProperty(globalThis"), 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
