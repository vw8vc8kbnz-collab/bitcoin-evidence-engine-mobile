#!/usr/bin/env python3
from __future__ import annotations

"""AST, source and behavior contracts for the narrow R9K3 cleanup."""

import ast
import hashlib
import importlib
import json
import os
import shutil
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
SERVER = APP / "server_py.py"
ROUTES = APP / "metod_app/http/routes.py"
CONTRACT = ROOT / "R9K3_DEAD_ADMIN_REQUEST_JOBS_FALLBACK_CLEANUP.json"
FIXTURE = ROOT / "R9K3_ADMIN_REQUESTS_BEHAVIOR_FIXTURE.json"
HTTP_SMOKE = ROOT / "tools/fix660r8_http_smoke_tests.py"

SERVER_SHA256 = "84b3b0d3713d4d6da472d6b7d4351e166aac59e1fde1812cf60ccbd84d77556a"
FROZEN_BEHAVIOR_SHA256 = {
    "app/dxf_nesting_optimizer.py": "42480b301cd660dac1e5e9fec2c8d30bb5c6826c32234a9c1cce765b758bebb8",
    "app/dxf_geometry.py": "b80a2d006241908bf7b33516f7e0faf59ef61e1e08db86966b23cc5de292c1ff",
    "app/pricing_helpers.py": "646c2f5186e9b080f6ba8dcf364884411c18e946254bb5c9001647f7cbb425df",
    "app/panel_contract.py": "e23314fd63a2358a48daa580a92cebb8a40c9862548ba0243461a59347da7fc9",
}


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


class R9K3DeadAdminRequestJobsFallbackCleanupTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.source = SERVER.read_text(encoding="utf-8", errors="strict")
        cls.tree = ast.parse(cls.source)
        cls.contract = json.loads(CONTRACT.read_text(encoding="utf-8"))
        cls.fixture = json.loads(FIXTURE.read_text(encoding="utf-8"))
        cls.functions = {
            node.name: node
            for node in ast.walk(cls.tree)
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        }
        cls._temp = tempfile.TemporaryDirectory(prefix="r9k3_admin_requests_")
        cls._old_state = os.environ.get("METOD_STATE_ROOT")
        os.environ["METOD_STATE_ROOT"] = cls._temp.name
        sys.path.insert(0, str(APP))
        cls.server = importlib.import_module("server_py")
        cls.server._initialize_external_state()

    @classmethod
    def tearDownClass(cls) -> None:
        if cls._old_state is None:
            os.environ.pop("METOD_STATE_ROOT", None)
        else:
            os.environ["METOD_STATE_ROOT"] = cls._old_state
        try:
            sys.path.remove(str(APP))
        except ValueError:
            pass
        cls._temp.cleanup()

    def function_source(self, name: str) -> str:
        segment = ast.get_source_segment(self.source, self.functions[name])
        self.assertIsNotNone(segment)
        return str(segment)

    def clear_mailbox_and_jobs(self) -> None:
        for directory in (self.server.REQUESTS, self.server.JOBS):
            if directory.exists():
                shutil.rmtree(directory)
            directory.mkdir(parents=True)

    def write_request(self, request_id: str, status: dict[str, object]) -> None:
        folder = self.server.REQUESTS / request_id
        folder.mkdir(parents=True)
        self.server.durable_write_json(folder / "status.json", status)

    def call(self, path: str) -> dict[str, object]:
        handler = object.__new__(self.server.Handler)
        handler.path = path
        handler._send_json = lambda obj, code=200: (obj, code)
        body, status = self.server.api_admin_requests(handler)
        return {"status": status, "body": body}

    def seed_common_request_cases(self) -> None:
        self.clear_mailbox_and_jobs()
        self.write_request(
            "REQ_OLD",
            {
                "createdAt": "2026-01-01T10:00:00",
                "customer": {"name": "Oud"},
                "privateMarker": "kept",
            },
        )
        self.write_request(
            "REQ_NEW",
            {
                "createdAt": "2026-02-01T10:00:00",
                "customer": {"name": "Nieuw"},
            },
        )
        (self.server.REQUESTS / "REQ_MISSING").mkdir()
        corrupt = self.server.REQUESTS / "REQ_CORRUPT"
        corrupt.mkdir()
        (corrupt / "status.json").write_text("{broken", encoding="utf-8")
        (self.server.REQUESTS / "plain-file").write_text("ignore", encoding="utf-8")

    def test_01_target_has_no_constant_empty_for_and_exact_body_shape(self) -> None:
        node = self.functions["api_admin_requests"]
        empty = [
            item for item in ast.walk(node)
            if isinstance(item, ast.For) and isinstance(item.iter, ast.List) and not item.iter.elts
        ]
        self.assertEqual(empty, [])
        self.assertEqual(len(node.body), 7)
        self.assertIn(
            "_REQUEST_DOWNLOAD_PROJECTIONS.list_requests",
            self.function_source("api_admin_requests"),
        )

    def test_02_before_inventory_and_exact_reduction_are_sealed(self) -> None:
        cleanup = self.contract["cleanup"]
        self.assertEqual(cleanup["beforeFunctionBodyStatements"], 13)
        self.assertEqual(cleanup["afterFunctionBodyStatements"], 12)
        self.assertEqual(cleanup["topLevelAstStatementsRemoved"], 1)
        self.assertEqual(cleanup["removedSubtreeAstNodes"], 416)
        self.assertEqual(cleanup["emptyForBodyStatementsRemoved"], 15)
        self.assertEqual(cleanup["serverBytesRemoved"], 3154)
        self.assertEqual(cleanup["serverLinesRemoved"], 64)

    def test_03_after_function_and_server_hashes_are_exact(self) -> None:
        self.assertEqual(
            self.contract["cleanup"]["afterFunctionSourceSha256"],
            "f0efb38c3afb47d6015952c1dd768a6abbfcde09136a772d131aef396de7aca4",
        )
        self.assertEqual(
            sha256_bytes(self.function_source("api_admin_requests").encode()),
            "f91ea992eb8f2ae5cdb0091ea48a07349f203f92b98f280aedcf8053b8909280",
        )
        self.assertEqual(
            self.contract["candidate"]["serverSha256"],
            "e5499193c4308b84ce98913b45ff227ab4648e5dbc72801786d760c865a1f055",
        )
        self.assertEqual(sha256_bytes(SERVER.read_bytes()), SERVER_SHA256)
        self.assertEqual(SERVER.stat().st_size, 474682)
        self.assertEqual(len(SERVER.read_bytes().splitlines()), 10402)

    def test_04_dead_fallback_markers_are_absent_from_target(self) -> None:
        target = self.function_source("api_admin_requests")
        for marker in ("for jp in []", "jobs-fallback", "existing_ids", "Admin kon job fallback"):
            self.assertNotIn(marker, target)
        names = {item.id for item in ast.walk(self.functions["api_admin_requests"]) if isinstance(item, ast.Name)}
        self.assertNotIn("JOBS", names)

    def test_05_historical_route_digest_is_preserved_and_r9m_dispatch_is_explicit(self) -> None:
        preserved = self.contract["preservedOwners"]
        self.assertEqual(
            preserved["routeCatalogSha256"],
            "2498058718d43db2cc9e7416bba287ebf1bf7b139be69ede9eedf50bf6792f52",
        )
        dispatcher = self.function_source("do_GET")
        self.assertEqual(
            preserved["getDispatcherSourceSha256"],
            "7305acce042b096240c9fed67125a86473c6bb33fb582a81cf2dc312c0324901",
        )
        self.assertIn("admin_asset = admin_asset_for_path(parsed.path)", dispatcher)
        self.assertIn("route_key == 'GET /api/admin/requests'", dispatcher)
        self.assertIn("return api_admin_requests(self)", dispatcher)

    def test_06_related_request_owners_remain_byte_exact(self) -> None:
        preserved = self.contract["preservedOwners"]
        names = {
            "api_admin_requests_update": "requestUpdateSourceSha256",
            "_ensure_request_dirs": "ensureRequestDirsSourceSha256",
            "_send_json": "sendJsonSourceSha256",
            "_api_submit_config": "finalSubmitSourceSha256",
        }
        for name, key in names.items():
            self.assertEqual(sha256_bytes(self.function_source(name).encode()), preserved[key], name)

    def test_07_jobs_only_directory_remains_excluded(self) -> None:
        self.clear_mailbox_and_jobs()
        job_input = self.server.JOBS / "JOB_ONLY_IGNORED" / "input"
        job_input.mkdir(parents=True)
        self.server.durable_write_json(
            job_input / "job.json",
            {"customer": {"name": "Mag niet lekken"}},
        )
        expected = self.fixture["cases"]["jobs_only_is_ignored"]
        self.assertEqual(self.call(expected["requestPath"]), {"status": expected["status"], "body": expected["body"]})

    def test_08_sorting_invalid_entries_and_payload_are_exact(self) -> None:
        self.seed_common_request_cases()
        expected = self.fixture["cases"]["sorting_and_invalid_entries"]
        self.assertEqual(self.call(expected["requestPath"]), {"status": expected["status"], "body": expected["body"]})

    def test_09_limit_behavior_is_exact(self) -> None:
        self.seed_common_request_cases()
        for case_name in ("limit_one", "limit_zero_clamps_to_one", "invalid_limit_defaults"):
            expected = self.fixture["cases"][case_name]
            self.assertEqual(
                self.call(expected["requestPath"]),
                {"status": expected["status"], "body": expected["body"]},
                case_name,
            )

    def test_10_real_http_smoke_binds_the_admin_request_cases(self) -> None:
        smoke = HTTP_SMOKE.read_text(encoding="utf-8", errors="strict")
        for marker in (
            "R9K3_JOB_ONLY_REQUEST_ID",
            "R9K3_REQUEST_OLD",
            "R9K3_REQUEST_NEW",
            "r9k3_admin_requests",
        ):
            self.assertIn(marker, smoke)

    def test_11_scope_is_narrow_provisional_and_behavior_files_are_frozen(self) -> None:
        self.assertEqual(self.contract["contractId"], "R9K3_DEAD_ADMIN_REQUEST_JOBS_FALLBACK_CLEANUP")
        self.assertEqual(self.contract["status"], "PROVISIONAL_DEVELOPMENT_ONLY")
        self.assertFalse(self.contract["releaseEligible"])
        self.assertFalse(self.contract["cleanup"]["activeRuntimePathChanged"])
        self.assertFalse(self.contract["cleanup"]["externallyObservableBehaviorExpectedChanged"])
        self.assertFalse(self.contract["externalEvidence"]["productionGo"])
        for relative, expected in FROZEN_BEHAVIOR_SHA256.items():
            self.assertEqual(sha256_bytes((ROOT / relative).read_bytes()), expected, relative)


if __name__ == "__main__":
    unittest.main(verbosity=2)
