#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "app"))

from metod_app.jobs.finalization import JobFinalizationService  # noqa: E402


class SafetyError(RuntimeError):
    pass


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, sort_keys=True), encoding="utf-8")


class FinalizationTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory(prefix="r9e_finalization_")
        self.jobs = Path(self.temp.name) / "jobs"
        self.jobs.mkdir()
        self.states: dict[str, dict] = {}

    def tearDown(self) -> None:
        self.temp.cleanup()

    def service(self) -> JobFinalizationService:
        def validate(value) -> str:
            rendered = str(value or "")
            if not rendered or "/" in rendered or ".." in rendered:
                raise SafetyError("invalid id")
            return rendered

        def resolve_child(root: Path, value, **_kwargs) -> Path:
            child = Path(root) / validate(value)
            if child.resolve().parent != Path(root).resolve():
                raise SafetyError("outside root")
            return child

        def resolve_relative(root: Path, relative: str) -> Path:
            path = (Path(root) / relative).resolve()
            if not path.is_relative_to(Path(root).resolve()):
                raise SafetyError("outside output")
            return path

        def summary(root: Path, **_kwargs) -> None:
            target = Path(root) / "output" / "calculation_summary.txt"
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text("total", encoding="utf-8")

        return JobFinalizationService(
            jobs_root=self.jobs,
            safety_error=SafetyError,
            validate_job_id=validate,
            resolve_identifier_child=resolve_child,
            resolve_relative_file=resolve_relative,
            read_json=lambda path: json.loads(Path(path).read_text(encoding="utf-8")),
            cached_sha256_file=sha,
            parse_panels_csv=lambda _text: [],
            input_dxf_source_map=lambda _root, _parts: {},
            link_or_copy_file=lambda _source, _destination: "copy",
            fsync_directory=lambda _path: None,
            generate_labels=lambda root: Path(root) / "output" / "labels.json",
            generate_stickertool=lambda _root: None,
            write_calculation_summary=summary,
            durable_write_json=write_json,
            atomic_write_json=write_json,
            load_runtime_state=lambda job_id: dict(self.states.get(job_id, {})),
            utc_now_iso=lambda: "2026-08-20T00:00:00Z",
        )

    def seal_subjob(self, job_id: str, *, artifact_text: str = "safe") -> Path:
        root = self.jobs / job_id
        output = root / "output"
        output.mkdir(parents=True)
        artifact = output / "artifact.txt"
        artifact.write_text(artifact_text, encoding="utf-8")
        manifest = output / "optimizer_manifest.json"
        write_json(manifest, {"release": "FIX660R8"})
        write_json(output / "finalization.json", {
            "schemaVersion": 2,
            "state": "COMPLETE",
            "optimizerManifestSha256": sha(manifest),
            "artifactsSha256": {"artifact.txt": sha(artifact)},
        })
        return root

    def test_subjob_manifest_verifies_and_tamper_fails_closed(self) -> None:
        root = self.seal_subjob("MASTER__mat_001")
        service = self.service()
        self.assertTrue(service.finalization_complete(root))
        (root / "output" / "artifact.txt").write_text("tampered", encoding="utf-8")
        self.assertFalse(service.finalization_complete(root))

    def test_cancelled_master_invalidates_already_sealed_subjob(self) -> None:
        root = self.seal_subjob("MASTER__mat_001")
        self.states["MASTER"] = {"state": "CANCELLED"}
        self.assertFalse(self.service().finalization_complete(root))

    def test_outside_job_root_and_path_escape_fail_closed(self) -> None:
        outside = Path(self.temp.name) / "outside"
        outside.mkdir()
        self.assertFalse(self.service().finalization_complete(outside))

    def test_sealed_artifacts_return_only_verified_files(self) -> None:
        root = self.seal_subjob("MASTER__mat_001")
        service = self.service()
        self.assertEqual(set(service.sealed_output_artifacts(root)), {"output/artifact.txt"})
        (root / "output" / "artifact.txt").write_text("tampered", encoding="utf-8")
        self.assertEqual(service.sealed_output_artifacts(root), {})

    def test_master_recursively_binds_subjob_finalization(self) -> None:
        service = self.service()
        subjob = self.seal_subjob("MASTER__mat_001")
        master = self.jobs / "MASTER"
        output = master / "output"
        output.mkdir(parents=True)
        links = output / "links.json"
        summary = output / "calculation_summary.txt"
        links.write_text("links", encoding="utf-8")
        summary.write_text("total", encoding="utf-8")
        sub_final = subjob / "output" / "finalization.json"
        write_json(output / "finalization.json", {
            "schemaVersion": 2,
            "kind": "master",
            "state": "COMPLETE",
            "subjobFinalizationsSha256": {subjob.name: sha(sub_final)},
            "artifactsSha256": {"links.json": sha(links), "calculation_summary.txt": sha(summary)},
        })
        self.assertTrue(service.finalization_complete(master, memo={}))
        write_json(sub_final, {"state": "ERROR"})
        self.assertFalse(service.finalization_complete(master, memo={}))

    def test_public_family_requires_done_or_preserved_legacy_finalization(self) -> None:
        service = self.service()
        subjob = self.seal_subjob("MASTER__mat_001")
        master = self.jobs / "MASTER"
        output = master / "output"
        output.mkdir(parents=True)
        artifact = output / "summary.txt"
        artifact.write_text("ok", encoding="utf-8")
        write_json(output / "finalization.json", {
            "kind": "master",
            "state": "COMPLETE",
            "subjobFinalizationsSha256": {
                subjob.name: sha(subjob / "output" / "finalization.json")
            },
            "artifactsSha256": {"summary.txt": sha(artifact)},
        })
        self.states["MASTER"] = {"state": "PROCESSING"}
        self.assertFalse(service.public_family_complete("MASTER__mat_001", memo={}))
        self.states["MASTER"] = {"state": "DONE"}
        self.assertTrue(service.public_family_complete("MASTER__mat_001", memo={}))
        self.states["MASTER"] = {}
        self.assertTrue(service.public_family_complete("MASTER", memo={}))

    def test_seal_master_publishes_exact_hashes(self) -> None:
        service = self.service()
        master = self.jobs / "MASTER"
        (master / "output").mkdir(parents=True)
        (master / "output" / "links.json").write_text("links", encoding="utf-8")
        subjob = self.seal_subjob("MASTER__mat_001")
        sub_hash = sha(subjob / "output" / "finalization.json")
        result = service.seal_master(
            master_root=master,
            subjobs=[{"subjobId": subjob.name}],
            finalized_subjob_hashes={subjob.name: sub_hash},
        )
        self.assertEqual(result["state"], "COMPLETE")
        self.assertEqual(result["subjobFinalizationsSha256"], {subjob.name: sub_hash})
        self.assertEqual(set(result["artifactsSha256"]), {"links.json", "calculation_summary.txt"})

    def test_seal_master_failure_publishes_error_marker(self) -> None:
        service = self.service()
        master = self.jobs / "MASTER"
        (master / "output").mkdir(parents=True)
        with self.assertRaisesRegex(RuntimeError, "Masteroutput finaliseren mislukt"):
            service.seal_master(
                master_root=master,
                subjobs=[{"subjobId": "MISSING"}],
                finalized_subjob_hashes={},
            )
        marker = json.loads((master / "output" / "finalization.json").read_text())
        self.assertEqual(marker["state"], "ERROR")

    def test_finalize_subjob_failure_is_durably_marked_error(self) -> None:
        root = self.jobs / "MASTER__mat_001"
        (root / "output").mkdir(parents=True)
        with self.assertRaisesRegex(SafetyError, "Required optimizer artifact missing"):
            self.service().finalize_subjob(root)
        marker = json.loads((root / "output" / "finalization.json").read_text())
        self.assertEqual(marker["state"], "ERROR")

    def test_service_source_has_no_http_process_pricing_or_optimizer_execution(self) -> None:
        source = (ROOT / "app/metod_app/jobs/finalization.py").read_text(encoding="utf-8")
        for forbidden in ("BaseHTTPRequestHandler", "subprocess", "Popen(", "pricing_helpers", "dxf_nesting_optimizer"):
            self.assertNotIn(forbidden, source)


if __name__ == "__main__":
    unittest.main(verbosity=2)
