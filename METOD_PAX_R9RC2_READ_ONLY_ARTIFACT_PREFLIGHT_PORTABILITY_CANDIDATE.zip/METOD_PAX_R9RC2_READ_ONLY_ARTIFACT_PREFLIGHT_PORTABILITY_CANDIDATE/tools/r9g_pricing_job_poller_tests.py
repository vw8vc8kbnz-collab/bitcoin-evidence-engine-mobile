#!/usr/bin/env python3
from __future__ import annotations

"""Fail-closed R9G-6 proof for the single Tool A job/pricing API owner."""

import ast
import base64
import hashlib
import json
import shutil
import subprocess
import unittest
from pathlib import Path

from r9h_shell_source import read_toola_expanded


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
JOBS = APP / "tool-a/api/jobs.js"
BOOTSTRAP = APP / "tool-a/bootstrap.js"
HTML = APP / "toolA.html"
RULES = ROOT / "R9B_ARCHITECTURE_RULES.json"


def data_url(data: bytes) -> str:
    return "data:text/javascript;base64," + base64.b64encode(data).decode()


def run_node(source: str) -> dict:
    node = shutil.which("node")
    if not node:
        raise AssertionError("Node is required by the release architecture gate")
    completed = subprocess.run(
        [node, "--input-type=module"], input=source, text=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=10, check=False,
    )
    if completed.returncode != 0:
        raise AssertionError(completed.stdout)
    return json.loads(completed.stdout.strip().splitlines()[-1])


class R9GPricingJobPollerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.jobs_url = data_url(JOBS.read_bytes())

    def test_01_jobs_module_has_one_bounded_network_owner_and_no_ui_or_storage(self) -> None:
        source = JOBS.read_text(encoding="utf-8")
        for token in (
            "document", "window", "addEventListener", "localStorage", "sessionStorage",
            "XMLHttpRequest", "EventSource", "WebSocket", "innerHTML",
        ):
            self.assertNotIn(token, source)
        self.assertEqual(source.count('fetchImpl("/api/jobs",'), 1)
        self.assertEqual(source.count("/status`"), 1)
        self.assertIn("DEFAULT_MAX_TOTAL_MS", source)
        self.assertIn("DEFAULT_MAX_STATUS_OUTAGE_MS", source)

    def test_02_one_start_call_is_exactly_one_post_with_unchanged_serialized_payload(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(self.jobs_url)});
const calls=[];
const api=m.createJobsApi({{fetchImpl:async(url,options)=>{{calls.push({{url,options}});return {{ok:true,status:202}};}}}});
const payload='{{"panelsCsv":"exact","customer":{{"email":"private@example.test"}}}}';
const response=await api.startJob(payload);
console.log(JSON.stringify({{calls,status:response.status,frozen:Object.isFrozen(api)}}));
""")
        self.assertEqual(len(result["calls"]), 1)
        call = result["calls"][0]
        self.assertEqual(call["url"], "/api/jobs")
        self.assertEqual(call["options"], {
            "method": "POST",
            "headers": {"Content-Type": "application/json"},
            "body": '{"panelsCsv":"exact","customer":{"email":"private@example.test"}}',
        })
        self.assertEqual(result["status"], 202)
        self.assertTrue(result["frozen"])

    def test_03_direct_done_has_one_get_zero_timers_and_authoritative_cent_total(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(self.jobs_url)});
const calls=[],progress=[];let sleeps=0;
const done={{meta:{{status:'done',progressPct:100,progressMessage:'Klaar'}},pricingSummary:{{totalInclVat:620.43}}}};
const api=m.createJobsApi({{fetchImpl:async(url,options)=>{{calls.push({{url,options}});return {{ok:true,status:200,json:async()=>done}};}},sleep:async()=>{{sleeps+=1;}}}});
const output=await api.pollJob({{jobId:'JOB 01',accessToken:'secret',onProgress:value=>progress.push(value)}});
console.log(JSON.stringify({{calls,progress,sleeps,total:api.authoritativeTotalInclVat(output)}}));
""")
        self.assertEqual(len(result["calls"]), 1)
        self.assertEqual(result["calls"][0]["url"], "/api/jobs/JOB%2001/status")
        self.assertEqual(result["calls"][0]["options"]["headers"], {"Authorization": "Bearer secret"})
        self.assertEqual(result["sleeps"], 0)
        self.assertEqual(result["progress"][-1]["progressPct"], 100)
        self.assertEqual(result["total"], 620.43)

    def test_04_processing_then_done_has_one_poller_and_one_bounded_sleep(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(self.jobs_url)});
let index=0,sleeps=0;const progress=[];
const values=[
 {{meta:{{status:'processing',progressPct:37,progressMessage:'Nesten'}}}},
 {{meta:{{status:'done',progressPct:100,progressMessage:'Klaar'}},pricingSummary:{{totalInclVat:123.45}}}}
];
const api=m.createJobsApi({{fetchImpl:async()=>({{ok:true,status:200,json:async()=>values[Math.min(index++,1)]}}),sleep:async(ms)=>{{sleeps+=1;if(ms!==350)throw new Error('wrong sleep');}}}});
const output=await api.pollJob({{jobId:'JOB',onProgress:value=>progress.push(value)}});
console.log(JSON.stringify({{fetches:index,sleeps,progress,total:m.authoritativeTotalInclVat(output)}}));
""")
        self.assertEqual(result["fetches"], 2)
        self.assertEqual(result["sleeps"], 1)
        self.assertEqual(result["progress"][-1]["progressPct"], 100)
        self.assertEqual(result["total"], 123.45)

    def test_05_terminal_409_fails_immediately_without_retry(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(self.jobs_url)});
let fetches=0,sleeps=0;
const api=m.createJobsApi({{fetchImpl:async()=>{{fetches+=1;return {{ok:false,status:409,text:async()=>JSON.stringify({{meta:{{progressMessage:'Integriteitscontrole mislukt.'}}}})}};}},sleep:async()=>{{sleeps+=1;}}}});
let error=null;try{{await api.pollJob({{jobId:'JOB'}})}}catch(value){{error={{message:value.message,httpStatus:value.httpStatus,terminal:value.metodTerminalStatus===true}}}}
console.log(JSON.stringify({{fetches,sleeps,error}}));
""")
        self.assertEqual(result, {
            "fetches": 1,
            "sleeps": 0,
            "error": {"message": "Integriteitscontrole mislukt.", "httpStatus": 409, "terminal": True},
        })

    def test_06_transient_failure_retries_but_outage_and_total_deadlines_fail_closed(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(self.jobs_url)});
let clock=0,fetches=0,sleeps=[];
const api=m.createJobsApi({{fetchImpl:async()=>{{fetches+=1;if(fetches===1)throw new Error('offline');return {{ok:true,json:async()=>({{meta:{{status:'done'}},pricingSummary:{{totalInclVat:1}}}})}};}},now:()=>clock,sleep:async(ms)=>{{sleeps.push(ms);clock+=ms;}}}});
await api.pollJob({{jobId:'JOB'}});
let deadline='';const blocked=m.createJobsApi({{fetchImpl:async()=>{{throw new Error('offline')}},now:()=>clock,sleep:async(ms)=>{{clock+=200;}} ,maxStatusOutageMs:100}});
try{{await blocked.pollJob({{jobId:'BLOCKED'}})}}catch(error){{deadline=error.message}}
console.log(JSON.stringify({{fetches,sleeps,deadline}}));
""")
        self.assertEqual(result["fetches"], 2)
        self.assertEqual(result["sleeps"], [850])
        self.assertIn("langere tijd niet worden opgehaald", result["deadline"])

    def test_07_pricing_hydration_accepts_only_terminal_server_summary(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(self.jobs_url)});
const responses=[
 {{meta:{{status:'processing'}},pricingSummary:{{totalInclVat:999}}}},
 {{meta:{{status:'done'}},pricingSummary:{{totalInclVat:620.43}}}},
 {{meta:{{status:'done'}},pricingSummary:{{totalInclVat:'bad'}}}}
];let index=0;
const api=m.createJobsApi({{fetchImpl:async()=>({{ok:true,json:async()=>responses[index++]}})}});
const processing=await api.fetchPricingSummary({{jobId:'A'}});
const done=await api.fetchPricingSummary({{jobId:'A'}});
const invalid=await api.fetchPricingSummary({{jobId:'A'}});
console.log(JSON.stringify({{processing,done,invalid,total:m.authoritativeTotalInclVat({{pricingSummary:done}})}}));
""")
        self.assertIsNone(result["processing"])
        self.assertEqual(result["done"]["totalInclVat"], 620.43)
        self.assertIsNone(result["invalid"])
        self.assertEqual(result["total"], 620.43)

    def test_08_html_has_one_click_owner_one_start_and_one_poll_delegation(self) -> None:
        source = read_toola_expanded(HTML)
        self.assertEqual(source.count("saveQuoteBtn.addEventListener('click', async ()=>"), 1)
        self.assertEqual(source.count("r9JobsOwner().startJob(__payloadJson)"), 1)
        self.assertEqual(source.count("r9JobsOwner().pollJob({"), 1)
        self.assertEqual(source.count("async function pollJob(jobId, accessToken)"), 1)
        self.assertNotIn("fetch('/api/jobs',", source)
        self.assertNotIn("fetch(`/api/jobs/${encodeURIComponent(jobId)}/status`", source)
        self.assertEqual(source.count("fetchJobPricingSummary({jobId:"), 2)

    def test_09_adapter_and_public_graph_are_exactly_bound(self) -> None:
        bootstrap = BOOTSTRAP.read_text(encoding="utf-8")
        self.assertIn('"R9I_SYNC_CATALOG_REFRESH_CLEANUP_9"', bootstrap)
        self.assertIn('mode: "legacy-read-cleanup-adapter"', bootstrap)
        for method in ("startJob", "cancelJob", "pollJob", "fetchJobPricingSummary", "authoritativeTotalInclVat"):
            self.assertEqual(bootstrap.count(f"  {method}:"), 1)
        rules = json.loads(RULES.read_text(encoding="utf-8"))["frontend"]
        self.assertGreaterEqual(len(rules["publicStaticFiles"]), 9)
        self.assertIn("tool-a/api/jobs.js", rules["publicStaticFiles"])
        self.assertEqual(rules["moduleImports"]["app/tool-a/api/jobs.js"], [])
        self.assertEqual(rules["moduleImports"]["app/tool-a/bootstrap.js"][:2], ["./api/jobs.js", "./api/requests.js"])
        marker = '<script type="module" src="tool-a/bootstrap.js?v=r9i-sync-catalog-refresh-cleanup-9"></script>'
        self.assertEqual(read_toola_expanded(HTML).count(marker), 1)

    def test_10_optimizer_pricing_math_payload_submit_and_routes_are_protected(self) -> None:
        expected = {
            "dxf_nesting_optimizer.py": "42480b301cd660dac1e5e9fec2c8d30bb5c6826c32234a9c1cce765b758bebb8",
            "dxf_geometry.py": "b80a2d006241908bf7b33516f7e0faf59ef61e1e08db86966b23cc5de292c1ff",
            "pricing_helpers.py": "646c2f5186e9b080f6ba8dcf364884411c18e946254bb5c9001647f7cbb425df",
            "toolA_customer_validation.js": "b58a45b76100be0d4d0c8fac7c5bf1285dec3d31143e53469ae5bfb92f99f734",
        }
        for name, expected_hash in expected.items():
            self.assertEqual(hashlib.sha256((APP / name).read_bytes()).hexdigest(), expected_hash, name)
        tree = ast.parse((APP / "server_py.py").read_text(encoding="utf-8"))
        handlers = [node.name for node in ast.walk(tree) if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))]
        self.assertIn("_api_status", handlers)
        self.assertIn("_api_create_job", handlers)


if __name__ == "__main__":
    unittest.main(verbosity=2)
