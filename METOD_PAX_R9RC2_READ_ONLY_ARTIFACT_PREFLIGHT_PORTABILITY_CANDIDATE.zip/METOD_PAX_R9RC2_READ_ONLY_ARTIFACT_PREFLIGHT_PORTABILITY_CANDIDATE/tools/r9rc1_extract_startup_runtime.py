#!/usr/bin/env python3
from __future__ import annotations

"""One-shot extraction of production validation and process startup."""

import ast
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
APPLICATION = APP / "metod_app/runtime/application.py"
STARTUP = APP / "metod_app/runtime/startup.py"

VALIDATION_DEPS = (
    "MATERIAL_LIBRARY_PATH", "Path", "RELEASE_ROOT", "ROOT", "STATE_ROOT",
    "SYSTEM_DIR", "SafetyContractError", "_admin_password_reset_activation_is_enabled",
    "_env_flag", "_env_int", "_get_admin_credentials_file_path",
    "_is_password_hash_value", "_is_production_hardening_enabled",
    "_normalized_admin_users", "_split_env_csv", "_totp_code", "datetime", "hmac",
    "os", "re", "sha256_file", "strict_json_load", "timedelta", "timezone", "urlparse",
)
SERVER_DEPS = (
    "BoundedThreadingHTTPServer", "HOST", "Handler", "PORT", "ROOT",
    "_ensure_archive_dirs", "_ensure_request_dirs", "_ensure_system_dirs",
    "_get_admin_credentials_file_path", "_initialize_external_state",
    "_migrate_legacy_materials_to_direct_sell_prices", "_reconcile_archive_transactions",
    "_reconcile_interrupted_jobs_on_startup", "_server_maintenance_loop",
    "migrate_embedded_dxfs_to_categories", "os", "rebuild_embedded_dxfs_manifest",
    "run_queue_maintenance", "run_retention_maintenance", "threading",
)
WORKER_DEPS = (
    "ROOT", "_ensure_archive_dirs", "_ensure_request_dirs", "_ensure_system_dirs",
    "_initialize_external_state", "_migrate_legacy_materials_to_direct_sell_prices",
    "_reconcile_archive_transactions", "_reconcile_interrupted_jobs_on_startup", "os",
    "run_queue_maintenance", "run_retention_maintenance", "worker_loop",
)


def _node(source: str, name: str) -> ast.FunctionDef:
    for node in ast.parse(source).body:
        if isinstance(node, ast.FunctionDef) and node.name == name:
            return node
    raise RuntimeError(f"startup function missing: {name}")


def _extract(source: str, node: ast.FunctionDef) -> str:
    lines = source.splitlines(keepends=True)
    return "".join(lines[node.lineno - 1 : node.end_lineno])


def _adapt(
    source: str,
    node: ast.FunctionDef,
    *,
    name: str,
    dependencies: tuple[str, ...],
    custom: tuple[str, ...] = (),
) -> str:
    original = _extract(source, node)
    lines = original.splitlines(keepends=True)
    suffix = lines[0][len(f"def {node.name}(") :]
    lines[0] = f"def {name}(runtime" + (suffix if suffix.startswith(")") else f", {suffix}")
    insert = 1
    if node.body and isinstance(node.body[0], ast.Expr):
        value = node.body[0].value
        if isinstance(value, ast.Constant) and isinstance(value.value, str):
            insert = node.body[0].end_lineno - node.lineno + 1
    bindings = [f"    {dep} = runtime.{dep}\n" for dep in dependencies]
    bindings.extend(f"    {line}\n" for line in custom)
    lines[insert:insert] = bindings + ["\n"]
    return "".join(lines).rstrip() + "\n"


def main() -> int:
    if STARTUP.exists():
        raise RuntimeError("R9RC1 startup extraction has already run")
    source = APPLICATION.read_text(encoding="utf-8", errors="strict")
    validation_node = _node(source, "_validate_production_runtime_or_die")
    main_node = _node(source, "main")
    worker_node = _node(source, "run_worker")

    validation = _adapt(
        source, validation_node, name="validate_production_runtime_or_die",
        dependencies=VALIDATION_DEPS,
    )
    run_server = _adapt(
        source, main_node, name="run_server", dependencies=SERVER_DEPS,
        custom=("_validate_production_runtime_or_die = lambda: validate_production_runtime_or_die(runtime)",),
    )
    run_worker = _adapt(
        source, worker_node, name="run_worker", dependencies=WORKER_DEPS,
        custom=("_validate_production_runtime_or_die = lambda: validate_production_runtime_or_die(runtime)",),
    )
    module = (
        "from __future__ import annotations\n\n"
        '"""Fail-closed production validation and explicit process startup owners."""\n\n'
        + validation + "\n" + run_server + "\n" + run_worker
    )

    start = source.index("def _validate_production_runtime_or_die()")
    wrappers = '''from metod_app.runtime import startup as _startup_runtime


def _validate_production_runtime_or_die() -> None:
    _startup_runtime.validate_production_runtime_or_die(sys.modules[__name__])


def main() -> None:
    _startup_runtime.run_server(sys.modules[__name__])


def run_worker() -> None:
    _startup_runtime.run_worker(sys.modules[__name__])
'''
    APPLICATION.write_text(source[:start] + wrappers + "\n", encoding="utf-8")
    STARTUP.write_text(module, encoding="utf-8")
    print("extracted production validation and server/worker startup owners")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
