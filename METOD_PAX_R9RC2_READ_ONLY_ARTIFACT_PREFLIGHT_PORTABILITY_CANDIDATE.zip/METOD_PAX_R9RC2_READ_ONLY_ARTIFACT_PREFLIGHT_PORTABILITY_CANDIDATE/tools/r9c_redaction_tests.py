#!/usr/bin/env python3
from __future__ import annotations

"""Behavior and ownership proof for the R9C pure-redaction extraction."""

import ast
import importlib
import os
import sys
import tempfile
import unittest
from pathlib import Path


RELEASE = Path(__file__).resolve().parents[1]
APP = RELEASE / "app"
SERVER = APP / "server_py.py"
sys.path.insert(0, str(APP))

from metod_app.security.redaction import (  # noqa: E402
    redact_sensitive_text,
    safe_text,
    sanitize_log_value,
)


class BrokenString:
    def __str__(self) -> str:
        raise RuntimeError("deliberate")


class R9CRedactionBehaviorTests(unittest.TestCase):
    def test_safe_text_preserves_trimming_bounds_and_failed_stringification(self) -> None:
        self.assertEqual(safe_text("  hello  "), "hello")
        self.assertEqual(safe_text("abcdef", 4), "abc…")
        self.assertEqual(safe_text(BrokenString()), "")
        self.assertEqual(safe_text(None), "")

    def test_all_established_sensitive_text_classes_are_redacted(self) -> None:
        source = (
            "user@example.com +31 6 12345678\n"
            "Authorization: Bearer AUTH_SECRET\n"
            "Proxy-Authorization: Basic PROXY_SECRET\n"
            "Cookie: session=COOKIE_SECRET; preference=private\n"
            "Set-Cookie: session=SET_COOKIE_SECRET; HttpOnly\n"
            "authorization=Bearer ASSIGN_SECRET token=TOKEN_SECRET "
            "password=PASSWORD_SECRET "
            "https://example.invalid/?email=private@example.com&phone=0612345678"
        )
        redacted = redact_sensitive_text(source, 4000)
        for secret in (
            "AUTH_SECRET", "PROXY_SECRET", "COOKIE_SECRET", "SET_COOKIE_SECRET",
            "ASSIGN_SECRET", "TOKEN_SECRET", "PASSWORD_SECRET", "preference=private",
        ):
            self.assertNotIn(secret, redacted)
        self.assertIn("u***@example.com", redacted)
        self.assertIn("[redacted-phone]", redacted)
        self.assertEqual(redact_sensitive_text("postcode 1234 AB", 100), "postcode [redacted-postcode]")
        self.assertIn("[redacted-secret]", redacted)
        self.assertIn("[redacted-query]", redacted)

    def test_redaction_output_keeps_the_established_final_length_bound(self) -> None:
        self.assertEqual(redact_sensitive_text("x" * 50, 8), "xxxxxxx…")
        self.assertEqual(redact_sensitive_text("", 8), "")

    def test_structured_sensitive_keys_are_redacted_case_insensitively(self) -> None:
        value = {
            "Password": "secret-one",
            "EMAIL": "person@example.com",
            "nested": {"token": "secret-two", "safe": "visible"},
        }
        self.assertEqual(
            sanitize_log_value(value),
            {
                "Password": "[redacted]",
                "EMAIL": "[redacted]",
                "nested": {"token": "[redacted]", "safe": "visible"},
            },
        )

    def test_structured_depth_item_and_tuple_contracts_are_preserved(self) -> None:
        self.assertEqual(sanitize_log_value({"a": {"b": {"c": 1}}}), {"a": {"b": {"c": "[truncated]"}}})
        self.assertEqual(sanitize_log_value([1, 2, 3], max_items=2), [1, 2, "[truncated]"])
        self.assertEqual(sanitize_log_value(("a", "b")), ["a", "b"])
        self.assertEqual(sanitize_log_value({"a": 1, "b": 2}, max_items=1), {"a": 1, "__truncated__": True})


class R9CRedactionOwnershipTests(unittest.TestCase):
    def test_server_imports_exact_aliases_and_has_no_duplicate_owners(self) -> None:
        tree = ast.parse(SERVER.read_text(encoding="utf-8"), filename=str(SERVER))
        definitions = {
            node.name for node in tree.body
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
        }
        self.assertEqual(
            definitions & {"_safe_text", "_redact_sensitive_text", "_sanitize_log_value"},
            set(),
        )
        aliases = {
            alias.asname: alias.name
            for node in tree.body
            if isinstance(node, ast.ImportFrom)
            and node.module == "metod_app.security.redaction"
            for alias in node.names
        }
        self.assertEqual(
            aliases,
            {
                "_redact_sensitive_text": "redact_sensitive_text",
                "_safe_text": "safe_text",
                "_sanitize_log_value": "sanitize_log_value",
            },
        )

    def test_server_uses_the_single_redaction_owner(self) -> None:
        previous = os.environ.get("METOD_STATE_ROOT")
        with tempfile.TemporaryDirectory(prefix="r9c-redaction-owner-") as temp_name:
            os.environ["METOD_STATE_ROOT"] = str(Path(temp_name) / "state")
            try:
                server = importlib.import_module("server_py")
                self.assertIs(server._safe_text, safe_text)
                self.assertIs(server._redact_sensitive_text, redact_sensitive_text)
                self.assertIs(server._sanitize_log_value, sanitize_log_value)
            finally:
                if previous is None:
                    os.environ.pop("METOD_STATE_ROOT", None)
                else:
                    os.environ["METOD_STATE_ROOT"] = previous

    def test_redaction_module_has_no_runtime_or_io_dependencies(self) -> None:
        path = APP / "metod_app/security/redaction.py"
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        imports = {
            alias.name.split(".", 1)[0]
            for node in ast.walk(tree)
            if isinstance(node, ast.Import)
            for alias in node.names
        }
        imports.update(
            node.module.split(".", 1)[0]
            for node in ast.walk(tree)
            if isinstance(node, ast.ImportFrom) and node.module
        )
        self.assertEqual(
            imports & {
                "http", "logging", "os", "pathlib", "server_py", "socket",
                "subprocess", "threading",
            },
            set(),
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
