#!/usr/bin/env python3
from __future__ import annotations

"""Fail-closed R9G-7 proof for one final-submit/thank-you owner."""

import ast
import base64
import hashlib
import json
import shutil
import subprocess
import unittest
from pathlib import Path

from r9h_shell_source import read_toola_expanded


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
REQUESTS = APP / "tool-a/api/requests.js"
BOOTSTRAP = APP / "tool-a/bootstrap.js"
HTML = APP / "toolA.html"
CHECKOUT_REVIEW = APP / "tool-a/components/checkout-review.js"
RULES = ROOT / "R9B_ARCHITECTURE_RULES.json"


def data_url(data: bytes) -> str:
    return "data:text/javascript;base64," + base64.b64encode(data).decode()


def run_node(source: str) -> dict:
    node = shutil.which("node")
    if not node:
        raise AssertionError("Node is required by the release architecture gate")
    completed = subprocess.run(
        [node, "--input-type=module"], input=source, text=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=10, check=False,
    )
    if completed.returncode != 0:
        raise AssertionError(completed.stdout)
    return json.loads(completed.stdout.strip().splitlines()[-1])


class R9GFinalSubmitThankYouTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.requests_url = data_url(REQUESTS.read_bytes())

    def test_01_requests_module_is_the_only_bounded_network_owner(self) -> None:
        source = REQUESTS.read_text(encoding="utf-8")
        for token in (
            "document", "window", "addEventListener", "localStorage", "sessionStorage",
            "XMLHttpRequest", "EventSource", "WebSocket", "innerHTML", "/api/jobs",
        ):
            self.assertNotIn(token, source)
        self.assertEqual(source.count('fetchImpl("/api/submit_config",'), 1)
        self.assertIn('IDLE: "idle"', source)
        self.assertIn('SUBMITTING: "submitting"', source)
        self.assertIn('COMMITTED: "committed"', source)
        self.assertIn('FAILED: "failed"', source)

    def test_02_one_submit_is_one_post_with_exact_capability_and_customer_snapshot(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(self.requests_url)});const calls=[];
const api=m.createRequestsApi({{fetchImpl:async(url,options)=>{{calls.push({{url,options}});return {{ok:true,status:200,json:async()=>({{ok:true,requestId:'REQ-1',cancelToken:'cancel',pricingSummary:{{totalInclVat:620.43}}}})}};}}}});
const customer={{firstName:'Ada',lastName:'Zaag',company:'Werkplaats BV',email:'ada@example.invalid',phone:'0612345678',billingAddress:'Houtstraat',shippingAddress:'Magazijnweg',shippingSameAsBilling:false,postcode:'1234 AB',houseNumber:'7',address1:'Magazijnweg',address2:'',city:'Utrecht',country:'Nederland'}};
const output=await api.submitConfiguration({{parentJobId:'JOB PARENT',accessToken:'parent-secret',customer,note:'Bel vooraf'}});
console.log(JSON.stringify({{calls,output}}));
""")
        self.assertEqual(len(result["calls"]), 1)
        call = result["calls"][0]
        self.assertEqual(call["url"], "/api/submit_config")
        self.assertEqual(call["options"]["method"], "POST")
        self.assertEqual(call["options"]["headers"], {
            "Content-Type": "application/json", "Authorization": "Bearer parent-secret",
        })
        body = json.loads(call["options"]["body"])
        self.assertEqual(set(body), {"jobId", "parentJobId", "customer", "note"})
        self.assertEqual(body["jobId"], "JOB PARENT")
        self.assertEqual(body["customer"]["houseNumber"], "7")
        self.assertEqual(body["customer"]["shippingAddress"], "Magazijnweg")
        self.assertEqual(body["note"], "Bel vooraf")
        self.assertEqual(result["output"]["requestId"], "REQ-1")
        self.assertEqual(result["output"]["pricingSummary"]["totalInclVat"], 620.43)

    def test_03_double_tap_during_inflight_is_one_post(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(self.requests_url)});let calls=0,release;
const api=m.createRequestsApi({{fetchImpl:async()=>{{calls+=1;await new Promise(resolve=>{{release=resolve;}});return {{ok:true,status:200,json:async()=>({{requestId:'REQ-2'}})}};}}}});
const action=m.createFinalSubmitAction({{requestsApi:api}});const context={{parentJobId:'JOB-2',jobComplete:true,customer:{{email:'ada@example.invalid'}}}};
const first=action.submit(context);await Promise.resolve();
const second=await action.submit(context);release();const committed=await first;
console.log(JSON.stringify({{calls,second,committed,state:action.getState()}}));
""")
        self.assertEqual(result["calls"], 1)
        self.assertTrue(result["second"]["ignored"])
        self.assertTrue(result["committed"]["ok"])
        self.assertEqual(result["state"]["status"], "committed")

    def test_04_committed_request_opens_thank_you_exactly_once_and_never_reposts(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(self.requests_url)});let calls=0,thanks=0,pricing=null;
const action=m.createFinalSubmitAction({{fetchImpl:async()=>{{calls+=1;return {{ok:true,status:200,json:async()=>({{requestId:'REQ-3',pricingSummary:{{totalInclVat:321.09}}}})}};}}}});
const context={{parentJobId:'JOB-3',jobComplete:true,customer:{{email:'ada@example.invalid'}}}};
const first=await action.submit(context,{{onCommitted:({{committed}})=>{{thanks+=1;pricing=committed.pricingSummary;}}}});
const second=await action.submit(context,{{onCommitted:()=>{{thanks+=1;}}}});
console.log(JSON.stringify({{calls,thanks,pricing,first,second,state:action.getState()}}));
""")
        self.assertEqual(result["calls"], 1)
        self.assertEqual(result["thanks"], 1)
        self.assertEqual(result["pricing"]["totalInclVat"], 321.09)
        self.assertTrue(result["first"]["ok"])
        self.assertTrue(result["second"]["ignored"])
        self.assertEqual(result["state"]["committedRequestId"], "REQ-3")

    def test_05_http_200_without_request_id_is_failed_without_thank_you(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(self.requests_url)});let thanks=0,failed=0;
const action=m.createFinalSubmitAction({{fetchImpl:async()=>({{ok:true,status:200,json:async()=>({{ok:true}})}})}});
const output=await action.submit({{parentJobId:'JOB',jobComplete:true,customer:{{email:'a@b.test'}}}},{{onCommitted:()=>{{thanks+=1;}},onFailed:()=>{{failed+=1;}}}});
console.log(JSON.stringify({{thanks,failed,ok:output.ok,message:output.error.message,state:action.getState()}}));
""")
        self.assertEqual(result["thanks"], 0)
        self.assertEqual(result["failed"], 1)
        self.assertFalse(result["ok"])
        self.assertIn("aanvraagreferentie", result["message"])
        self.assertEqual(result["state"]["status"], "failed")

    def test_06_http_error_and_unreadable_json_fail_recoverably(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(self.requests_url)});let index=0;
const responses=[
 {{ok:false,status:503,json:async()=>({{error:'Tijdelijk niet beschikbaar'}})}},
 {{ok:true,status:200,json:async()=>{{throw new Error('bad json')}}}}
];
const action=m.createFinalSubmitAction({{fetchImpl:async()=>responses[index++]}});const context={{parentJobId:'JOB',jobComplete:true,customer:{{email:'a@b.test'}}}};
const a=await action.submit(context);const b=await action.submit(context);
console.log(JSON.stringify({{a:a.error.message,b:b.error.message,state:action.getState()}}));
""")
        self.assertEqual(result["a"], "Tijdelijk niet beschikbaar")
        self.assertIn("serverbevestiging", result["b"])
        self.assertEqual(result["state"]["status"], "failed")

    def test_07_network_failure_restores_failed_state_and_retry_can_commit(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(self.requests_url)});let calls=0,failed=0,committed=0;
const action=m.createFinalSubmitAction({{fetchImpl:async()=>{{calls+=1;if(calls===1)throw new Error('offline');return {{ok:true,status:200,json:async()=>({{requestId:'REQ-RETRY'}})}};}}}});
const context={{parentJobId:'JOB',jobComplete:true,customer:{{email:'a@b.test'}}}};
const first=await action.submit(context,{{onFailed:()=>{{failed+=1;}}}});const afterFirst=action.getState();
const second=await action.submit(context,{{onCommitted:()=>{{committed+=1;}}}});
console.log(JSON.stringify({{calls,failed,committed,first:first.ok,afterFirst,second:second.ok,state:action.getState()}}));
""")
        self.assertEqual(result["calls"], 2)
        self.assertEqual(result["failed"], 1)
        self.assertEqual(result["committed"], 1)
        self.assertFalse(result["first"])
        self.assertEqual(result["afterFirst"]["status"], "failed")
        self.assertTrue(result["second"])
        self.assertEqual(result["state"]["status"], "committed")

    def test_08_incomplete_parent_job_fails_before_network(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(self.requests_url)});let calls=0,failed=0;
const action=m.createFinalSubmitAction({{fetchImpl:async()=>{{calls+=1;}}}});
const output=await action.submit({{parentJobId:'JOB',jobComplete:false,customer:{{email:'a@b.test'}}}},{{onFailed:()=>{{failed+=1;}}}});
console.log(JSON.stringify({{calls,failed,ok:output.ok,message:output.error.message,state:action.getState()}}));
""")
        self.assertEqual(result["calls"], 0)
        self.assertEqual(result["failed"], 1)
        self.assertFalse(result["ok"])
        self.assertIn("nog niet volledig afgerond", result["message"])

    def test_09_reset_erases_submit_capability_state_without_persisting_pii(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(self.requests_url)});let body='';
const action=m.createFinalSubmitAction({{fetchImpl:async(_url,options)=>{{body=options.body;return {{ok:true,status:200,json:async()=>({{requestId:'REQ-PRIVATE'}})}};}}}});
await action.submit({{parentJobId:'JOB-PRIVATE',jobComplete:true,accessToken:'SECRET',customer:{{email:'private@example.test'}}}});
const committed=action.getState();const reset=action.reset();
console.log(JSON.stringify({{committed,reset,body,moduleSourceHasStorage:{json.dumps('localStorage' in REQUESTS.read_text(encoding='utf-8') or 'sessionStorage' in REQUESTS.read_text(encoding='utf-8'))}}}));
""")
        self.assertEqual(result["committed"]["committedRequestId"], "REQ-PRIVATE")
        self.assertEqual(result["reset"], {
            "status": "idle", "committedRequestId": "", "committedParentJobId": "",
        })
        self.assertFalse(result["moduleSourceHasStorage"])

    def test_10_production_html_has_one_click_owner_and_zero_submit_network_owners(self) -> None:
        source = read_toola_expanded(HTML)
        component = CHECKOUT_REVIEW.read_text(encoding="utf-8")
        self.assertEqual(source.count("R9G8_SINGLE_FINAL_SUBMIT_CLICK_ADAPTER"), 1)
        self.assertEqual(source.count("handleCheckoutReviewEvent?.(event)"), 3)
        self.assertEqual(component.count('const submit = closest("#sendConfigBtn, #btnSendConfig");'), 1)
        self.assertEqual(component.count("const submitFinal = rootRef.__metodSubmitFinalConfiguration;"), 1)
        self.assertNotIn("priceSendBtn.addEventListener('click'", source)
        self.assertNotIn("fetch('/api/submit_config'", source)
        self.assertNotIn("toolA_final_submit_bridge.js?v=", source)
        self.assertNotIn("__metod_force_canonical_submit", source)
        self.assertEqual(source.count("finalSubmitOwner.submitFinalConfiguration({"), 1)

    def test_11_bootstrap_api_and_static_graph_have_one_submit_action(self) -> None:
        bootstrap = BOOTSTRAP.read_text(encoding="utf-8")
        self.assertIn('"R9RC1_PROFESSIONAL_ARCHITECTURE_COMPLETION"', bootstrap)
        self.assertIn('mode: "legacy-read-cleanup-adapter"', bootstrap)
        for method in ("submitFinalConfiguration", "resetFinalSubmission", "getFinalSubmissionState"):
            self.assertEqual(bootstrap.count(f"  {method}:"), 1)
        rules = json.loads(RULES.read_text(encoding="utf-8"))["frontend"]
        self.assertEqual(rules["moduleImports"]["app/tool-a/api/requests.js"], [])
        self.assertIn("tool-a/api/requests.js", rules["publicStaticFiles"])
        tree = ast.parse((APP / "metod_app/http/static.py").read_text(encoding="utf-8"))
        public_files = next(
            ast.literal_eval(node.value) for node in tree.body
            if isinstance(node, ast.Assign) and any(
                isinstance(target, ast.Name) and target.id == "PUBLIC_STATIC_MODULE_FILES"
                for target in node.targets
            )
        )
        self.assertEqual(public_files, set(rules["publicStaticFiles"]))

    def test_12_new_configuration_resets_native_and_legacy_submit_state(self) -> None:
        source = read_toola_expanded(HTML)
        self.assertGreaterEqual(source.count("resetFinalSubmission==='function'"), 2)
        hard_reset = source[
            source.index("async function _resetConfigurationHard()"):
            source.index("function closeCancelRequestDialog()", source.index("async function _resetConfigurationHard()"))
        ]
        self.assertIn("resetFinalSubmission()", hard_reset)
        for token in (
            "__metod_last_job_access_token = null", "__metod_last_request_id = null",
            "__metod_checkout_live_customer = null", "state.checkout.customerSnapshot = null",
        ):
            self.assertIn(token, hard_reset)

    def test_13_optimizer_pricing_geometry_and_job_payload_builder_are_unchanged(self) -> None:
        expected = {
            "dxf_nesting_optimizer.py": "42480b301cd660dac1e5e9fec2c8d30bb5c6826c32234a9c1cce765b758bebb8",
            "dxf_geometry.py": "b80a2d006241908bf7b33516f7e0faf59ef61e1e08db86966b23cc5de292c1ff",
            "pricing_helpers.py": "646c2f5186e9b080f6ba8dcf364884411c18e946254bb5c9001647f7cbb425df",
            "panel_contract.py": "e23314fd63a2358a48daa580a92cebb8a40c9862548ba0243461a59347da7fc9",
        }
        for name, expected_hash in expected.items():
            self.assertEqual(hashlib.sha256((APP / name).read_bytes()).hexdigest(), expected_hash, name)
        source = read_toola_expanded(HTML)
        start = source.index("async function buildJobPayload(){")
        end = source.index(
            "  // ---------------------------\n  // Checkout overlays (restmateriaal + klantgegevens)",
            start,
        )
        payload_builder = source[start:end].encode()
        self.assertEqual(len(payload_builder), 9697)
        self.assertEqual(
            hashlib.sha256(payload_builder).hexdigest(),
            "342dac02c2650ac2798e20e62d38d8e1e6b7d518a54daa8fd760d734ae527e47",
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
