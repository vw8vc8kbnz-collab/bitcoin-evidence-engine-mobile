#!/usr/bin/env python3
from __future__ import annotations

"""Negative source and browser contracts for the R9K1 Admin-auth cleanup."""

import ast
import hashlib
import json
import re
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
REPOSITORY = ROOT.parent
SERVER = ROOT / "app/server_py.py"
ADMIN_ACCESS = ROOT / "app/metod_app/admin/access.py"
ADMIN_PRESENTATION = ROOT / "app/metod_app/admin"
R9M_BEFORE = ROOT / "R9M_ADMIN_PRESENTATION_BEFORE_FIXTURE.json"
CONTRACT = ROOT / "R9K1_DORMANT_ADMIN_AUTH_CLEANUP.json"
BROWSER_EVIDENCE = ROOT / "R9K1_BROWSER_NEGATIVE_ASSERTIONS.json"
BROWSER_CONTRACT = REPOSITORY / "contracts/R9A_BROWSER_FIXTURES.json"
BROWSER_DRIVER = REPOSITORY / "tools/r9a_browser_driver.js"

SERVER_SHA256 = "1d07e63ca83e18822c655566f42f67c2cbb54c2c3a2a80bae78124214f76aa69"
ADMIN_LOGIN_HTML_SHA256 = "657cbf323eb978dcefc039e79870ed42f55b585c37915e978b974136739df1b6"
ROUTE_CATALOG_SHA256 = "05907bd65c55d92494df626fc7e0674465d0cae8111a6c8b4543ae62d6a0bfac"
BROWSER_CONTRACT_SHA256 = "1afbc7be5e35a6a9f503637ecc526a26ed92480de655f2475a8c19fc8f8d497e"
BROWSER_DRIVER_SHA256 = "d1716badfc1bd48b9c68226b9cd2246a82d46cce870df08055d40d0b7b17ac72"
R9O5_BROWSER_DRIVER_SHA256 = "1651fcc01376abc5bfee8ff1063cdf4d07349569d4320836a3249e03ca4d1e38"

ACTIVE_OWNER_SHA256 = {
    "_require_admin_write_origin": "321dbac49a0576093a056534b1b7c50f2168678397088023b395ad8fcd3fdf0a",
    "_api_admin_login": "0c50477881f204a428d1ec596568d032fc04745b357dc2c96c4f09bc83c8b5d6",
    "_check_admin_auth_silent": "9a8d05b44872b4f78ca2d11cae3adcf4efd86bf30223df3eb64eaf523dbaec46",
    "_current_admin_session_token": "e72ea11c3a3a4e220fe7125a30be6bd7d524c1b3a5423dd667146c7744a00192",
    "_api_admin_logout": "e0a65362243e8544a9de31214a63e57271bc9d9faba6dc16f9c1da079321163b",
    "_admin_session_create": "68a0c1825b4a70d1c2b4464b153e62b94e2ad275024358bbfb862c68923f943c",
    "_admin_session_valid": "06fa8c6627fe9224871729c506f27b4ff7d115336062ec26b678e46c41706617",
    "_admin_session_revoke": "16c0f1fd060e1592058ed0f9c7fd3f0c16457e06504b3ecbebdc4a10b3783136",
    "_admin_session_roles": "1b4e2d808c62c105e54a0a86ee96ad6599ca9f8343b79c473317d81303c901c7",
    "_do_POST_impl": "3e03fb5ca3dd886358e13827ba9fc1dd915b79c6e7e23a59cb79f8e89375ee95",
}

FROZEN_BEHAVIOR_SHA256 = {
    "app/dxf_nesting_optimizer.py": "42480b301cd660dac1e5e9fec2c8d30bb5c6826c32234a9c1cce765b758bebb8",
    "app/dxf_geometry.py": "b80a2d006241908bf7b33516f7e0faf59ef61e1e08db86966b23cc5de292c1ff",
    "app/pricing_helpers.py": "646c2f5186e9b080f6ba8dcf364884411c18e946254bb5c9001647f7cbb425df",
    "app/panel_contract.py": "e23314fd63a2358a48daa580a92cebb8a40c9862548ba0243461a59347da7fc9",
}


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


class R9K1DormantAdminAuthCleanupTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.source = SERVER.read_text(encoding="utf-8", errors="strict")
        cls.tree = ast.parse(cls.source)
        cls.access_source = ADMIN_ACCESS.read_text(encoding="utf-8", errors="strict")
        cls.access_tree = ast.parse(cls.access_source)
        cls.contract = json.loads(CONTRACT.read_text(encoding="utf-8"))
        cls.browser_evidence = json.loads(BROWSER_EVIDENCE.read_text(encoding="utf-8"))
        cls.r9m_before = json.loads(R9M_BEFORE.read_text(encoding="utf-8"))
        cls.functions = {
            node.name: node
            for node in ast.walk(cls.tree)
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        }
        cls.access_functions = {
            node.name: node
            for node in ast.walk(cls.access_tree)
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        }
        cls.html: dict[str, str] = {}
        for node in cls.tree.body:
            if not isinstance(node, ast.Assign) or len(node.targets) != 1:
                continue
            target = node.targets[0]
            if isinstance(target, ast.Name) and target.id in {"ADMIN_HTML", "ADMIN_LOGIN_HTML"}:
                cls.html[target.id] = ast.literal_eval(node.value)
        if set(cls.html) != {"ADMIN_HTML", "ADMIN_LOGIN_HTML"}:
            for node in cls.access_tree.body:
                if not isinstance(node, ast.Assign) or len(node.targets) != 1:
                    continue
                target = node.targets[0]
                if isinstance(target, ast.Name) and target.id in {"ADMIN_HTML", "ADMIN_LOGIN_HTML"}:
                    cls.html[target.id] = ast.literal_eval(node.value)
        if set(cls.html) != {"ADMIN_HTML", "ADMIN_LOGIN_HTML"}:
            cls.html = {
                "ADMIN_HTML": "\n".join((
                    (ADMIN_PRESENTATION / "templates/admin.html").read_text(encoding="utf-8"),
                    (ADMIN_PRESENTATION / "assets/dxf.js").read_text(encoding="utf-8"),
                    (ADMIN_PRESENTATION / "assets/admin.js").read_text(encoding="utf-8"),
                )),
                "ADMIN_LOGIN_HTML": "\n".join((
                    (ADMIN_PRESENTATION / "templates/login.html").read_text(encoding="utf-8"),
                    (ADMIN_PRESENTATION / "assets/login.js").read_text(encoding="utf-8"),
                )),
            }

    def function_source(self, name: str) -> str:
        segment = ast.get_source_segment(self.source, self.functions[name])
        self.assertIsNotNone(segment)
        return str(segment)

    def access_function_source(self, name: str) -> str:
        segment = ast.get_source_segment(self.access_source, self.access_functions[name])
        self.assertIsNotNone(segment)
        return str(segment)

    def test_01_dormant_fix626_auth_is_fully_absent(self) -> None:
        for marker in self.contract["cleanup"]["forbiddenMarkers"]:
            self.assertNotIn(marker, self.html["ADMIN_HTML"])
        self.assertNotIn("FIX626: clean admin session login", self.html["ADMIN_HTML"])

    def test_02_admin_auth_never_sets_or_reads_web_storage(self) -> None:
        combined = self.html["ADMIN_HTML"] + self.html["ADMIN_LOGIN_HTML"]
        forbidden = re.findall(r"(?:localStorage|sessionStorage)\s*\.\s*(?:setItem|getItem)\s*\(", combined)
        self.assertEqual(forbidden, [])
        self.assertIn("sessionStorage.clear()", self.html["ADMIN_LOGIN_HTML"])

    def test_03_no_global_admin_auth_fetch_monkeypatch_remains(self) -> None:
        combined = self.html["ADMIN_HTML"] + self.html["ADMIN_LOGIN_HTML"]
        self.assertNotRegex(combined, r"window\s*\.\s*fetch\s*=")
        self.assertNotIn("ADMIN_FETCH_PATCHED", combined)

    def test_04_browser_has_exactly_one_login_owner(self) -> None:
        self.assertEqual(self.html["ADMIN_HTML"].count("/api/admin/login"), 0)
        self.assertEqual(self.html["ADMIN_LOGIN_HTML"].count("/api/admin/login"), 1)
        self.assertEqual(self.source.count("def _api_admin_login("), 1)

    def test_05_active_browser_login_requires_password_and_otp(self) -> None:
        login = self.html["ADMIN_LOGIN_HTML"]
        self.assertIn('id="pass" name="password" type="password"', login)
        self.assertIn('id="otp" name="otp"', login)
        self.assertIn("JSON.stringify({username,password,otp})", login)
        self.assertNotIn("j.token", login)
        self.assertEqual(
            self.r9m_before["presentations"]["ADMIN_LOGIN_HTML"]["sha256"],
            ADMIN_LOGIN_HTML_SHA256,
        )

    def test_06_production_handler_keeps_password_totp_and_no_token_body(self) -> None:
        login = self.function_source("_api_admin_login")
        if "_ADMIN_ACCESS.login(self)" in login:
            login = self.access_function_source("login")
        for marker in ("password_ok =", "mfa_ok =", "not deps.production_runtime() and not stored_totp"):
            self.assertIn(marker, login)
        self.assertIn('"expiresAt": int(expires_at)', login)
        self.assertNotRegex(login, r"['\"]token['\"]\s*:")

    def test_07_cookie_origin_role_and_logout_owners_are_byte_exact(self) -> None:
        if "from metod_app.admin.access import (" not in self.source:
            for name, expected in ACTIVE_OWNER_SHA256.items():
                self.assertEqual(sha256_bytes(self.function_source(name).encode("utf-8")), expected, name)
            self.assertIn("SameSite=Strict; HttpOnly", self.function_source("_api_admin_login"))
            self.assertIn("'admin' in _admin_session_roles", self.function_source("_check_admin_auth_silent"))
            self.assertIn("_admin_session_revoke(token)", self.function_source("_api_admin_logout"))
            return
        self.assertEqual(
            sha256_bytes(self.function_source("_require_admin_write_origin").encode("utf-8")),
            ACTIVE_OWNER_SHA256["_require_admin_write_origin"],
        )
        self.assertIn("SameSite=Strict; HttpOnly", self.access_function_source("login"))
        self.assertIn('"admin" in self.sessions.roles(token)', self.access_function_source("_has_admin_session"))
        self.assertIn("self.sessions.revoke(token)", self.access_function_source("logout"))

    def test_08_route_catalog_keeps_exact_admin_origin_and_bounded_login(self) -> None:
        routes = ROOT / "app/metod_app/http/routes.py"
        self.assertEqual(sha256_bytes(routes.read_bytes()), ROUTE_CATALOG_SHA256)
        route_text = routes.read_text(encoding="utf-8", errors="strict")
        self.assertIn("'exact-admin-origin-in-production'", route_text)
        self.assertIn("'bounded-json'", route_text)
        self.assertIn("'authentication-secret'", route_text)

    def test_09_browser_oracle_has_negative_bearer_and_storage_assertions(self) -> None:
        evidence = self.browser_evidence
        required = set(evidence["requiredAssertionIds"])
        self.assertTrue({"admin-login-response-has-no-bearer", "admin-auth-web-storage-empty", "admin-cookie-httponly"} <= required)
        self.assertEqual(evidence["status"], "DEFINED_NOT_EXECUTED_NO_GO")
        self.assertEqual(evidence["requiredEngines"], ["chromium", "webkit"])
        repository_evidence = evidence["repositoryEvidence"]
        self.assertEqual(repository_evidence["fixtureContract"]["sha256"], BROWSER_CONTRACT_SHA256)
        self.assertEqual(repository_evidence["browserDriver"]["sha256"], BROWSER_DRIVER_SHA256)
        if BROWSER_CONTRACT.is_file() and BROWSER_DRIVER.is_file():
            self.assertEqual(sha256_bytes(BROWSER_CONTRACT.read_bytes()), BROWSER_CONTRACT_SHA256)
            self.assertEqual(sha256_bytes(BROWSER_DRIVER.read_bytes()), R9O5_BROWSER_DRIVER_SHA256)
            browser_contract = json.loads(BROWSER_CONTRACT.read_text(encoding="utf-8"))
            fixture = next(item for item in browser_contract["fixtures"] if item["id"] == evidence["fixtureId"])
            self.assertTrue(required <= set(fixture["requiredAssertionIds"]))
            browser_driver = BROWSER_DRIVER.read_text(encoding="utf-8", errors="strict")
            for marker in (
                "loginHasToken: Object.prototype.hasOwnProperty.call(login, 'token')",
                "adminStorageKeys",
                "'admin-login-response-has-no-bearer'",
                "'admin-auth-web-storage-empty'",
            ):
                self.assertIn(marker, browser_driver)

    def test_10_four_r8z_behavior_files_remain_byte_exact(self) -> None:
        for relative, expected in FROZEN_BEHAVIOR_SHA256.items():
            self.assertEqual(sha256_bytes((ROOT / relative).read_bytes()), expected, relative)

    def test_11_historical_r9k1_reduction_is_sealed_in_its_contract(self) -> None:
        evidence = self.contract["sizeEvidence"]
        self.assertEqual(evidence["serverReduction"], {"bytes": 9511, "lines": 178})
        self.assertEqual(evidence["serverAfter"]["sha256"], SERVER_SHA256)
        self.assertLessEqual(len(SERVER.read_bytes()), evidence["serverAfter"]["bytes"])

    def test_12_contract_is_narrow_provisional_and_keeps_future_scope_deferred(self) -> None:
        self.assertEqual(self.contract["contractId"], "R9K1_DORMANT_ADMIN_AUTH_CLEANUP")
        self.assertEqual(self.contract["status"], "PROVISIONAL_DEVELOPMENT_ONLY")
        self.assertFalse(self.contract["releaseEligible"])
        self.assertFalse(self.contract["cleanup"]["activeRuntimePathChanged"])
        self.assertEqual(self.contract["executableEvidence"]["cleanupTestCount"], 12)
        self.assertEqual(len(self.contract["deferredUnchangedScope"]), 5)
        self.assertFalse(self.contract["externalEvidence"]["productionGo"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
