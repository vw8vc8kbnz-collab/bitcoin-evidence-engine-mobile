#!/usr/bin/env python3
from __future__ import annotations

"""Behavior and ownership proof for the R9D request projection extraction."""

import ast
import sys
import unittest
from pathlib import Path


RELEASE = Path(__file__).resolve().parents[1]
APP = RELEASE / "app"
SERVER = APP / "server_py.py"
PROJECTION_SOURCE = APP / "metod_app/requests/projections.py"
sys.path.insert(0, str(APP))

from metod_app.requests.projections import (  # noqa: E402
    RequestProjection,
    customer_block_from_sources,
    customer_block_from_status,
)


def material_name(code: str, *names: object) -> str:
    for name in names:
        text = str(name or "").strip()
        if text:
            return text
    return f"Catalog {code}" if code else ""


class R9DRequestProjectionBehaviorTests(unittest.TestCase):
    def setUp(self) -> None:
        self.projection = RequestProjection(best_material_name=material_name)

    def test_01_customer_projection_preserves_established_aliases_and_address_shape(self) -> None:
        result = self.projection.extract_summary({
            "customer": {
                "firstName": " Ada ", "lastName": " Lovelace ",
                "mail": " ada@example.invalid ", "telephone": " 0123 ",
                "postcode": "1234 AB", "houseNumber": "10",
                "billingAddress": "Main street", "deliveryAddress": "Side street",
                "city": "London",
            }
        })
        self.assertEqual(result["customerName"], "Ada Lovelace")
        self.assertEqual(result["customerEmail"], "ada@example.invalid")
        self.assertEqual(result["customerPhone"], "0123")
        self.assertEqual(
            result["customerAddress"],
            "Factuur: Main street 1234 AB 10 | Bezorg: Side street 1234 AB 10 | London",
        )

    def test_02_price_and_material_price_priority_remain_exact(self) -> None:
        result = self.projection.extract_summary({
            "priceInclVat": "12.34", "totalPriceInclVat": 99,
            "materialsPrice": "7.89", "materialsTotal": 55,
            "quote": {"grandTotalInclVat": 200, "materialsTotal": 100},
        })
        self.assertEqual(result["priceInclVat"], 12.34)
        self.assertEqual(result["materialsPrice"], 7.89)

    def test_03_quote_fallback_preserves_nested_total_and_vat_behavior(self) -> None:
        nested = self.projection.extract_summary({"quote": {"totals": {"totalInclVat": "24.20"}}})
        vat_fallback = self.projection.extract_summary({"quote": {"totals": {"subtotal": 10}}})
        self.assertEqual(nested["priceInclVat"], 24.2)
        self.assertEqual(vat_fallback["priceInclVat"], 12.1)

    def test_04_material_summary_and_quote_plate_merge_remain_exact(self) -> None:
        result = self.projection.extract_summary({
            "materialsSummary": [
                {"code": "A", "materialName": "Alpha", "plates": "2"},
                {"articleNumber": "B", "plates": "broken"},
            ],
            "quote": {
                "materials": [
                    {"materialCode": "A", "name": "ignored", "sheetsUsed": "4"},
                    {"materialCode": "C", "decorName": "Gamma", "sheetCount": 1},
                ]
            },
        })
        self.assertEqual(result["materials"], [
            {"code": "A", "name": "Alpha", "plates": 4},
            {"code": "B", "name": "Catalog B", "plates": None},
            {"code": "C", "name": "Gamma", "plates": 1},
        ])

    def test_05_derived_material_deduplication_panel_count_and_plate_heuristic_are_exact(self) -> None:
        result = self.projection.extract_summary({
            "cart": [
                {"articleNumber": "A", "quantity": "2"},
                {"articleNumber": "A", "quantity": 0},
            ],
            "extraPanels": [{"materialCode": "B", "aantal": "3"}],
            "panels": ["ignored", {"materialKey": "C", "qty": "bad"}],
            "quote": {"nested": {"boardsUsed": 7}, "sheetCount": 4},
        })
        self.assertEqual([item["code"] for item in result["materials"]], ["A", "B", "C"])
        self.assertEqual(result["panelsTotal"], 7)
        self.assertEqual(result["platesTotal"], 7)

    def test_06_status_customer_block_preserves_house_and_postcode_heuristics(self) -> None:
        self.assertEqual(
            customer_block_from_status({
                "requestId": "request_1", "createdAt": "created",
                "customer": {
                    "fullName": "Ada", "email": "a@example.invalid",
                    "address": "Street", "houseNumber": "10", "city": "1234 AB",
                },
            }),
            [
                "Aanvraag", "----------------------------------------", "Request ID: request_1",
                "Datum: created", "", "Klant", "----------------------------------------",
                "Naam: Ada", "Email: a@example.invalid", "", "Adres",
                "----------------------------------------", "Factuur: Street 10",
                "Plaats: 1234 AB", "",
            ],
        )

    def test_07_source_merge_rest_material_and_note_order_remain_exact(self) -> None:
        result = customer_block_from_sources(
            {"requestId": "request_1", "customer": {"name": "Stored", "email": "old"}},
            {
                "customer": {"name": "Payload", "email": "new"},
                "checkout": {
                    "customer": {"phone": "0123"},
                    "rest_material": {"carry_out": True},
                    "note": "Keep grain order",
                },
            },
        )
        self.assertIn("Naam: Payload", result)
        self.assertIn("Email: new", result)
        self.assertIn("Telefoon: 0123", result)
        self.assertIn("Meeleveren: JA", result)
        self.assertEqual(result[-4:], ["", "Opmerking klant", "----------------------------------------", "Keep grain order", ""][-4:])


class R9DRequestProjectionOwnershipTests(unittest.TestCase):
    def test_08_server_has_one_projection_owner_and_module_has_no_io_or_http_owner(self) -> None:
        server_source = SERVER.read_text(encoding="utf-8")
        server_tree = ast.parse(server_source, filename=str(SERVER))
        definitions = {
            node.name for node in server_tree.body
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
        }
        self.assertFalse(definitions & {
            "_extract_request_summary", "_first_nonempty",
            "_customer_block_from_status", "_customer_block_from_sources",
        })
        self.assertEqual(server_source.count("_REQUEST_PROJECTION = RequestProjection("), 1)
        self.assertIn("_extract_request_summary = _REQUEST_PROJECTION.extract_summary", server_source)

        projection_tree = ast.parse(PROJECTION_SOURCE.read_text(encoding="utf-8"))
        imports = {
            alias.name.split(".", 1)[0]
            for node in ast.walk(projection_tree) if isinstance(node, ast.Import)
            for alias in node.names
        }
        imports.update(
            node.module.split(".", 1)[0]
            for node in ast.walk(projection_tree)
            if isinstance(node, ast.ImportFrom) and node.module
        )
        self.assertFalse(imports & {
            "server_py", "os", "pathlib", "threading", "subprocess",
            "http", "socket", "urllib", "shutil", "tempfile",
        })


if __name__ == "__main__":
    unittest.main(verbosity=2)
