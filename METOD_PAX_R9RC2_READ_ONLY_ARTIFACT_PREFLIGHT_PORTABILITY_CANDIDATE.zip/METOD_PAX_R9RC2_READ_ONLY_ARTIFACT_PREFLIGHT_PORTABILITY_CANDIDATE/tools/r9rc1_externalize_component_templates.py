#!/usr/bin/env python3
from __future__ import annotations

"""Externalize literal presentation from native Tool A component templates."""

import hashlib
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
DIALOG = APP / "tool-a/components/dialog.js"
THANK_YOU = APP / "tool-a/components/thank-you.js"
CSS = APP / "tool-a/styles/static-utilities.css"
MARKER = "/* R9RC1 native component-template presentation utilities. */"
STYLE_ATTRIBUTE = re.compile(r'(<[A-Za-z][^<>]*?)\sstyle="([^"]*)"([^<>]*>)')


def _class_name(declarations: str) -> str:
    return "tool-component-u-" + hashlib.sha256(declarations.encode("utf-8")).hexdigest()[:12]


def _externalize(source: str, entries: dict[str, str]) -> tuple[str, int]:
    count = 0

    def replace(match: re.Match[str]) -> str:
        nonlocal count
        prefix, declarations, suffix = match.groups()
        if "${" in declarations:
            raise RuntimeError(f"dynamic component style requires a state class: {declarations}")
        name = _class_name(declarations)
        previous = entries.setdefault(name, declarations)
        if previous != declarations:
            raise RuntimeError(f"component utility hash collision: {name}")
        class_match = re.search(r'\bclass="([^"]*)"', prefix)
        if class_match:
            prefix = (
                prefix[: class_match.start(1)]
                + f"{class_match.group(1)} {name}"
                + prefix[class_match.end(1) :]
            )
        else:
            prefix += f' class="{name}"'
        count += 1
        return prefix + suffix

    return STYLE_ATTRIBUTE.sub(replace, source), count


def main() -> int:
    css = CSS.read_text(encoding="utf-8", errors="strict")
    if MARKER in css:
        raise RuntimeError("R9RC1 component template migration has already run")

    dialog = DIALOG.read_text(encoding="utf-8", errors="strict")
    old_dialog = 'overlay.style.cssText = "position:fixed;inset:0;display:none;align-items:center;justify-content:center;background:rgba(20,24,22,.25);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);z-index:2147483646;padding:16px;pointer-events:auto;";'
    new_dialog = 'overlay.classList.add("tool-alert-direct-overlay");'
    if dialog.count(old_dialog) != 1:
        raise RuntimeError("direct-dialog overlay style contract drifted")
    dialog = dialog.replace(old_dialog, new_dialog, 1)

    thank_you = THANK_YOU.read_text(encoding="utf-8", errors="strict")
    start = '      active.setAttribute?.("style", ['
    end = '      ].join(";"));\n'
    start_index = thank_you.find(start)
    if start_index < 0:
        raise RuntimeError("thank-you overlay style contract drifted")
    end_index = thank_you.find(end, start_index)
    if end_index < 0:
        raise RuntimeError("thank-you overlay style terminator missing")
    thank_you = thank_you[:start_index] + thank_you[end_index + len(end) :]

    entries: dict[str, str] = {}
    dialog, dialog_count = _externalize(dialog, entries)
    thank_you, thanks_count = _externalize(thank_you, entries)
    if dialog_count != 9 or thanks_count != 17:
        raise RuntimeError(
            f"component template inventory drifted: dialog={dialog_count}, thank-you={thanks_count}"
        )
    if STYLE_ATTRIBUTE.search(dialog) or STYLE_ATTRIBUTE.search(thank_you):
        raise RuntimeError("component template style attribute remains")

    rules = [
        MARKER,
        ".tool-alert-direct-overlay{position:fixed;inset:0;display:none;align-items:center;justify-content:center;background:rgba(20,24,22,.25);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);z-index:2147483646;padding:16px;pointer-events:auto}",
        ".submitThanksOverlay{position:fixed;inset:0;z-index:2147483647;display:flex;align-items:center;justify-content:center;padding:24px;background:rgba(15,23,20,.42);backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px);box-sizing:border-box}",
    ]
    rules.extend(f".{name}{{{declarations}}}" for name, declarations in sorted(entries.items()))
    DIALOG.write_text(dialog, encoding="utf-8")
    THANK_YOU.write_text(thank_you, encoding="utf-8")
    CSS.write_text(css.rstrip() + "\n\n" + "\n".join(rules) + "\n", encoding="utf-8")
    print("externalized 26 native component template style attributes and two overlay cssText owners")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
