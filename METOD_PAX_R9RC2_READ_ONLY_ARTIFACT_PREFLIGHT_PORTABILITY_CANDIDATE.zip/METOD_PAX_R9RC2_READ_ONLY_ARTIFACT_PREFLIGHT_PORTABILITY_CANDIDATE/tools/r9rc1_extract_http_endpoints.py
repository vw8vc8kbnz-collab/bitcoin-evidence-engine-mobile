#!/usr/bin/env python3
from __future__ import annotations

"""One-shot extraction of HTTP endpoint adapters from the composition runtime.

The extracted functions keep all mutable process state in ``application``.  Each
call receives that live module explicitly, so tests and operational overrides do
not observe copied configuration or a second state owner.
"""

import ast
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
APPLICATION = APP / "metod_app/runtime/application.py"
ENDPOINTS = APP / "metod_app/http/endpoints"

GROUPS: tuple[tuple[str, tuple[str, ...]], ...] = (
    (
        "drafts.py",
        ("api_draft_save", "api_dxf_manifest_meta", "api_draft_load"),
    ),
    (
        "admin_jobs.py",
        (
            "_edge_meters_by_decor",
            "api_admin_jobs",
            "_classify_output_kind",
            "_collect_job_output_files",
            "_dedupe_admin_dxf_files",
            "_extract_strict_calculation_pricing_summary",
            "_extract_admin_pricing_summary",
            "_find_or_generate_stickertool_file",
        ),
    ),
    (
        "admin_requests.py",
        (
            "_dir_size_bytes",
            "_build_request_file_manifest",
            "api_admin_request_files",
            "api_admin_request_file",
            "api_admin_request_download_zip",
            "api_admin_requests",
            "api_admin_requests_update",
        ),
    ),
    (
        "downloads.py",
        ("api_job_file", "api_stickertool_v2", "api_subjob_file", "api_download"),
    ),
    (
        "control_center.py",
        ("_fmt_bytes", "api_admin_control_center"),
    ),
)


def _top_level_names(tree: ast.Module) -> set[str]:
    names: set[str] = set()
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            names.add(node.name)
        elif isinstance(node, ast.Import):
            names.update(alias.asname or alias.name.split(".", 1)[0] for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            names.update(alias.asname or alias.name for alias in node.names)
        elif isinstance(node, ast.Assign):
            names.update(target.id for target in node.targets if isinstance(target, ast.Name))
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            names.add(node.target.id)
    return names


def _dependencies(node: ast.FunctionDef, global_names: set[str]) -> tuple[str, ...]:
    local_names = {
        argument.arg
        for argument in (*node.args.posonlyargs, *node.args.args, *node.args.kwonlyargs)
    }
    if node.args.vararg:
        local_names.add(node.args.vararg.arg)
    if node.args.kwarg:
        local_names.add(node.args.kwarg.arg)
    for child in ast.walk(node):
        if isinstance(child, ast.Name) and isinstance(child.ctx, (ast.Store, ast.Param)):
            local_names.add(child.id)
    loaded = {
        child.id
        for child in ast.walk(node)
        if isinstance(child, ast.Name) and isinstance(child.ctx, ast.Load)
    }
    return tuple(sorted((loaded & global_names) - local_names))


def _extract_adapted(
    source: str,
    node: ast.FunctionDef,
    global_names: set[str],
) -> str:
    original = "".join(source.splitlines(keepends=True)[node.lineno - 1 : node.end_lineno])
    lines = original.splitlines(keepends=True)
    prefix = f"def {node.name}("
    if not lines[0].startswith(prefix):
        raise RuntimeError(f"unexpected endpoint signature: {node.name}")
    suffix = lines[0][len(prefix) :]
    lines[0] = f"def {node.name}(runtime" + (suffix if suffix.startswith(")") else f", {suffix}")

    insert = 1
    if node.body and isinstance(node.body[0], ast.Expr):
        value = node.body[0].value
        if isinstance(value, ast.Constant) and isinstance(value.value, str):
            insert = node.body[0].end_lineno - node.lineno + 1
    dependencies = _dependencies(node, global_names)
    bindings = [f"    {name} = runtime.{name}\n" for name in dependencies]
    if bindings:
        lines[insert:insert] = bindings + ["\n"]
    return "".join(lines).rstrip() + "\n"


def _wrapper(node: ast.FunctionDef, module_name: str) -> str:
    signature = ast.unparse(node.args)
    positional = [argument.arg for argument in (*node.args.posonlyargs, *node.args.args)]
    call_parts = ["sys.modules[__name__]", *positional]
    if node.args.vararg:
        call_parts.append(f"*{node.args.vararg.arg}")
    call_parts.extend(f"{argument.arg}={argument.arg}" for argument in node.args.kwonlyargs)
    if node.args.kwarg:
        call_parts.append(f"**{node.args.kwarg.arg}")
    call = ", ".join(call_parts)
    return (
        f"def {node.name}({signature}):\n"
        f"    return _http_{module_name}.{node.name}({call})\n"
    )


def main() -> int:
    targets = [ENDPOINTS / filename for filename, _ in GROUPS]
    if ENDPOINTS.exists() or any(path.exists() for path in targets):
        raise RuntimeError("R9RC1 endpoint extraction has already run")

    source = APPLICATION.read_text(encoding="utf-8", errors="strict")
    tree = ast.parse(source)
    nodes = {
        node.name: node
        for node in tree.body
        if isinstance(node, ast.FunctionDef)
    }
    required = {name for _, names in GROUPS for name in names}
    missing = required - set(nodes)
    if missing:
        raise RuntimeError(f"endpoint source inventory drifted: {sorted(missing)}")
    global_names = _top_level_names(tree)

    ENDPOINTS.mkdir()
    (ENDPOINTS / "__init__.py").write_text(
        '"""Bounded HTTP endpoint adapters; process state stays in runtime.application."""\n',
        encoding="utf-8",
    )

    imports: list[str] = []
    wrappers: list[str] = []
    for filename, names in GROUPS:
        module_name = Path(filename).stem
        imports.append(
            f"from metod_app.http.endpoints import {module_name} as _http_{module_name}"
        )
        functions = "\n\n".join(
            _extract_adapted(source, nodes[name], global_names) for name in names
        )
        module = (
            "from __future__ import annotations\n\n"
            f'"""HTTP endpoint adapters for {module_name.replace("_", " ")}."""\n\n'
            + functions
            + "\n"
        )
        (ENDPOINTS / filename).write_text(module, encoding="utf-8")
        wrappers.extend(_wrapper(nodes[name], module_name) for name in names)

    start = source.index("def api_draft_save(")
    end = source.index("def _acquire_worker_lock()", start)
    replacement = (
        "# Thin compatibility adapters keep the established internal call surface while\n"
        "# endpoint implementation is owned by bounded HTTP modules.\n"
        + "\n".join(imports)
        + "\n\n\n"
        + "\n".join(wrappers)
        + "\n"
        + "from metod_app.runtime.composition import build_runtime_services as _build_runtime_services\n\n\n"
        + "_RUNTIME_SERVICES = _build_runtime_services(sys.modules[__name__])\n"
        + "_SUBMISSION_CLAIMS = _RUNTIME_SERVICES.submission_claims\n"
        + "_submission_marker_path = _SUBMISSION_CLAIMS.marker_path\n"
        + "_read_submission_claim = _SUBMISSION_CLAIMS.read_claim\n"
        + "_reserve_submission_claim = _SUBMISSION_CLAIMS.reserve_claim\n"
        + "_SUBMISSION_SERVICE = _RUNTIME_SERVICES.submission_service\n"
        + "_REQUEST_DOWNLOAD_PROJECTIONS = _RUNTIME_SERVICES.request_downloads\n\n"
        + "from metod_app.jobs import execution as _job_execution\n"
        + "from metod_app.runtime import worker as _queue_worker\n\n\n"
    )
    APPLICATION.write_text(source[:start] + replacement + source[end:], encoding="utf-8")
    print(f"extracted {len(required)} HTTP endpoint functions into {len(GROUPS)} modules")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
