#!/usr/bin/env python3
from __future__ import annotations

"""Fail-closed proof for the R9I-9 synchronous catalog refresh cleanup."""

import hashlib
import json
import unittest
from pathlib import Path

from r9j_hermetic_reference import assert_sealed_file, load_reference


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
RUNTIME = APP / "tool-a/shell/script-06-legacy-application-runtime.js"
HTML = APP / "toolA.html"
BOOTSTRAP = APP / "tool-a/bootstrap.js"
RULES = ROOT / "R9B_ARCHITECTURE_RULES.json"
REFERENCE = load_reference(ROOT)

REMOVED_SYNC_CATALOG_BLOCK = """function _syncGetJson(url){
  // Synchronous JSON fetch (small local payload). Used to refresh the <select> options
  // BEFORE the native dropdown opens, so the user does not need to click twice.
  const xhr = new XMLHttpRequest();
  xhr.open('GET', url, false); // sync
  xhr.setRequestHeader('Cache-Control','no-cache');
  xhr.send(null);
  if(xhr.status >= 200 && xhr.status < 300){
    return JSON.parse(xhr.responseText || '{}');
  }
  return null;
}

function _syncRefreshEmbedManifestIfNeeded(){
  try{
    const meta = _syncGetJson('/api/dxf_manifest_meta?ts=' + Date.now());
    const v = meta && (meta.version !== undefined ? meta.version : null);
    if(v === null || v === undefined) return;
    if(EMBED_DXF_VERSION !== null && String(v) === String(EMBED_DXF_VERSION)) return;

    const man = _syncGetJson('/embedded_dxfs_manifest.json?ts=' + encodeURIComponent(String(v)));
    EMBED_DXF_FILES = (man && man.files) ? man.files : [];
    EMBED_DXF_COUNT = EMBED_DXF_FILES.length;
    EMBED_DXF_VERSION = v;
    try{ if(!state.embedIndex) state.embedIndex={}; for(const nm of EMBED_DXF_FILES){ const tid = makeTemplateId(String(nm)); if(!state.embedIndex[tid]) state.embedIndex[tid]=String(nm); } }catch(e){}
    try{ rebuildCatalogFromTemplates(); try{ updateTypeOptions(); }catch(e){} }catch(e){}
    try{
      const bc = document.getElementById('builtinCount');
      if(bc) bc.textContent = String(EMBED_DXF_COUNT);
    }catch(e){}
  }catch(e){}
}

"""


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


class R9ISyncCatalogRefreshTests(unittest.TestCase):
    def test_01_runtime_delta_is_exactly_the_unused_sync_chain(self) -> None:
        payload = assert_sealed_file(
            self, ROOT, REFERENCE,
            "app/tool-a/shell/script-06-legacy-application-runtime.js",
        )
        current = payload.decode("utf-8")
        self.assertNotIn(REMOVED_SYNC_CATALOG_BLOCK, current)
        delta = REFERENCE["cleanupDeltas"]["synchronousCatalogRefresh"]
        self.assertEqual(delta, {"bytesRemoved": 1468, "linesRemoved": 33})
        legacy = json.loads((ROOT / "R9I9_SYNC_CATALOG_REFRESH_CLEANUP.json").read_text(encoding="utf-8"))["legacyRuntime"]
        self.assertEqual(legacy["previousBytes"] - legacy["currentBytes"], delta["bytesRemoved"])
        self.assertEqual(legacy["previousLines"] - legacy["currentLines"], delta["linesRemoved"])

    def test_02_active_async_catalog_refresh_remains(self) -> None:
        source = RUNTIME.read_text(encoding="utf-8")
        for token in (
            "setTimeout(()=>{ try{ _loadEmbedManifest(); }catch(e){} }, 50)",
            "async function _loadEmbedManifest()",
            "async function refreshEmbeddedDxfCatalogNow()",
            "await _loadEmbedManifest()",
            "fetch('/embedded_dxfs_manifest.json', {cache:'no-store'})",
            "fetch(`/api/dxf_manifest_meta?ts=${Date.now()}`, { cache: 'no-store' })",
            "refreshEmbeddedDxfCatalogNow().then(()=>{",
            "await refreshEmbeddedDxfCatalogNow()",
            "rebuildCatalogFromTemplates()",
            "updateTypeOptions()",
        ):
            self.assertIn(token, source)
        for token in (
            "_syncGetJson",
            "_syncRefreshEmbedManifestIfNeeded",
            "XMLHttpRequest",
            "xhr.open('GET', url, false)",
        ):
            self.assertNotIn(token, source)

    def test_03_functional_truth_owners_are_byte_exact(self) -> None:
        for relative in (
            "app/tool-a/shell/script-08-compat.js",
            "app/tool-a/shell/script-13-fix486-final-single-source-overlay-v2.js",
            "app/tool-a/api/jobs.js",
            "app/tool-a/api/requests.js",
            "app/tool-a/components/checkout-review.js",
            "app/tool-a/components/thank-you.js",
        ):
            assert_sealed_file(self, ROOT, REFERENCE, relative)

    def test_04_html_and_bootstrap_change_only_by_revision(self) -> None:
        html = HTML.read_text(encoding="utf-8")
        bootstrap = assert_sealed_file(self, ROOT, REFERENCE, "app/tool-a/bootstrap.js").decode("utf-8")
        self.assertIn(REFERENCE["applicationCacheRevision"], html)
        self.assertNotIn("r9i-unused-price-compat-cleanup-8", html)
        self.assertIn(f'"{REFERENCE["applicationRevision"]}"', bootstrap)
        self.assertNotIn("R9I_UNUSED_PRICE_COMPAT_CLEANUP_8", bootstrap)
        self.assertIn('content="R9O9"', html)

    def test_05_pricing_optimizer_and_payload_truth_remain_hash_locked(self) -> None:
        exact = {
            "dxf_nesting_optimizer.py": "42480b301cd660dac1e5e9fec2c8d30bb5c6826c32234a9c1cce765b758bebb8",
            "dxf_geometry.py": "b80a2d006241908bf7b33516f7e0faf59ef61e1e08db86966b23cc5de292c1ff",
            "pricing_helpers.py": "646c2f5186e9b080f6ba8dcf364884411c18e946254bb5c9001647f7cbb425df",
            "panel_contract.py": "e23314fd63a2358a48daa580a92cebb8a40c9862548ba0243461a59347da7fc9",
            "toolA_grain_studio_renderer.js": "922cd4ac479fbaf86ebfbb0256808119b96a8344e9b0bf1ffb4f668518a03204",
        }
        for relative, expected in exact.items():
            self.assertEqual(sha256(APP / relative), expected, relative)

    def test_06_architecture_does_not_expand(self) -> None:
        rules = json.loads(RULES.read_text(encoding="utf-8"))["frontend"]
        self.assertEqual(len(rules["moduleImports"]), 19)
        self.assertEqual(len(rules["domOwnerModules"]), 10)
        self.assertEqual(len(rules["networkOwnerModules"]), 2)
        self.assertEqual(rules["compatibilityGlobal"], "ToolAR9Foundation")
        shell = json.loads((ROOT / "R9H10_SEMANTIC_SHELL_ASSETS.json").read_text(encoding="utf-8"))
        self.assertEqual(len(shell["scriptFiles"]), 34)


if __name__ == "__main__":
    unittest.main(verbosity=2)
