#!/usr/bin/env python3
from __future__ import annotations

"""One-shot extraction of remaining runtime functions into bounded domain owners."""

import ast
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
APPLICATION = APP / "metod_app/runtime/application.py"

GROUPS: tuple[tuple[str, str, tuple[str, ...]], ...] = (
    (
        "metod_app/catalog/runtime.py",
        "CatalogRuntime",
        (
            "_invalidate_public_materials_response_cache",
            "_path_content_signature",
            "_invalidate_material_lookup_cache",
            "_material_lookup_snapshot",
            "_cached_sha256_file",
            "_classify_dxf_filename",
            "migrate_embedded_dxfs_on_startup",
            "classify_dxf_category",
            "migrate_embedded_dxfs_to_categories",
            "get_embedded_dxfs_version",
            "rebuild_embedded_dxfs_manifest",
            "_looks_numeric_material_name",
            "_best_material_name",
            "_material_label_for_filename",
        ),
    ),
    (
        "metod_app/security/access_runtime.py",
        "SecurityAccessRuntime",
        (
            "_direct_peer_ip",
            "_ip_matches",
            "_is_trusted_proxy_peer",
            "_client_ip",
            "_is_loopback_value",
            "_is_loopback_client",
            "_rate_limit_allow",
            "_rate_limit_is_blocked",
            "_rate_limit_record",
            "_rate_limit_clear",
            "_normalized_admin_users",
            "_find_admin_user",
            "_admin_session_create",
            "_admin_session_valid",
            "_admin_session_revoke",
            "_admin_session_actor",
            "_admin_session_roles",
            "_is_password_hash_value",
            "_is_https_request",
            "_is_secure_admin_transport",
            "_is_production_runtime",
            "_get_admin_credentials_file_path",
            "_get_admin_password_reset_activation_file_path",
            "_load_admin_password_reset_activation",
            "_admin_password_reset_activation_is_enabled",
            "_origin_allowed",
            "_extract_request_token",
            "_new_public_access_token",
            "_write_job_access_token",
            "_read_job_access_token",
        ),
    ),
    (
        "metod_app/jobs/admission_runtime.py",
        "JobAdmissionRuntime",
        (
            "_public_job_queue_limits",
            "_decrement_public_job_ip_locked",
            "_refresh_public_job_queue_meta_locked",
            "_launch_public_job_item",
            "_try_acquire_public_job_slot",
            "_release_public_job_slot",
            "_commit_public_job_slot",
            "_finish_public_job_slot",
            "_cancel_queued_public_job",
            "_catalog_review_sha256",
        ),
    ),
    (
        "metod_app/observability/runtime.py",
        "ObservabilityRuntime",
        (
            "_sse_broadcast",
            "_sse_handler",
            "_guess_customer_name_from_payload",
            "_guess_customer_name",
            "_append_system_event",
            "_read_system_events",
            "_observability_sse_client_count",
            "_observability_public_job_snapshot",
        ),
    ),
    (
        "metod_app/storage/backup_runtime.py",
        "BackupRuntime",
        (
            "_ensure_system_dirs",
            "_initialize_external_state",
            "_cleanup_old_backups",
            "_backup_source_inventory",
            "_assert_backup_capacity",
            "_verify_system_backup_zip",
            "_write_last_auto_backup",
            "_read_last_auto_backup_dt",
            "run_backup_maintenance",
            "_create_system_backup",
            "_list_backups",
        ),
    ),
    (
        "metod_app/notifications/runtime.py",
        "NotificationRuntime",
        (
            "_get_notify_config_file_path",
            "_ntfy_log",
            "_load_notify_config",
            "_validated_ntfy_target",
            "_ntfy_send",
            "_calculation_summary_text_for_ntfy",
            "_notify_privacy_options",
            "_ntfy_public_safe_customer_lines",
            "_notify_submitted",
            "_notify_failed",
        ),
    ),
    (
        "metod_app/jobs/payload_runtime.py",
        "JobPayloadRuntime",
        (
            "_job_output_limit_message",
            "_job_family_size_bytes",
            "_enforce_job_output_limit",
            "_enforce_state_capacity",
            "_reserve_state_capacity",
            "_release_state_capacity_reservation",
            "_state_capacity_reservation_totals",
            "_expand_dxf_payload",
            "_compact_dxf_transport",
            "_validated_canonical_dxf_transport",
            "_dxf_transport_stats",
            "_estimate_preflight_job_family_bytes",
            "_preflight_job_family_limit_message",
            "_get_payload_total_qty",
            "_enforce_job_total_qty_limit",
            "_estimate_payload_area_lower_bound",
        ),
    ),
    (
        "metod_app/jobs/state_runtime.py",
        "JobStateRuntime",
        (
            "_get_python_base_cmd",
            "_job_runtime_state_path",
            "_load_job_runtime_state",
            "_save_job_runtime_state",
            "_job_cancel_requested",
            "_register_job_process",
            "_unregister_job_process",
            "_terminate_optimizer_process",
            "_reconcile_interrupted_jobs_on_startup",
            "_find_existing_file",
            "_find_placements_any",
            "_find_labels_any",
        ),
    ),
    (
        "metod_app/storage/io_runtime.py",
        "StorageIoRuntime",
        (
            "_now_iso",
            "_safe_json",
            "_read_json_body",
            "_read_json_body_limited",
            "_safe_job_file",
            "_write_file",
            "_write_bytes",
            "_write_replaceable_bytes",
            "_write_replaceable_text",
            "_write_replaceable_json",
            "_link_or_copy_file",
            "_atomic_write_text",
            "_atomic_write_json",
            "_utc_now_iso",
            "_ensure_request_dirs",
            "_ensure_archive_dirs",
        ),
    ),
    (
        "metod_app/storage/archive_runtime.py",
        "ArchiveRuntime",
        (
            "_parse_iso_dt",
            "_path_dt",
            "_request_status_path",
            "_request_created_dt_from_status",
            "_request_archive_meta_dt",
            "_job_created_dt",
            "_write_archive_meta",
            "_unique_archive_dest",
            "_archive_journal_path",
            "_archive_journal_write",
            "_archive_journal_entries",
            "_complete_archive_journal",
            "_reconcile_archive_transactions",
            "_linked_job_ids_from_status",
            "_archive_request_and_linked_jobs",
        ),
    ),
    (
        "metod_app/storage/retention_runtime.py",
        "RetentionRuntime",
        (
            "_purge_old_archives",
            "_request_is_terminal_for_retention",
            "_archive_expired_active_data",
            "_cleanup_operational_state",
            "_move_queue_file_safe",
            "_mark_request_failed_if_stale",
            "_record_maintenance_failure",
            "_server_maintenance_loop",
        ),
    ),
    (
        "metod_app/requests/runtime.py",
        "RequestRuntime",
        (
            "_new_request_id",
            "_linked_subjob_ids",
            "_master_job_id_for",
            "_public_job_family_complete",
            "_iter_request_statuses",
            "_find_request_status_for_job",
            "_load_request_payload",
        ),
    ),
    (
        "metod_app/pricing/runtime.py",
        "PricingRuntime",
        (
            "_default_pricing_config",
            "_normalize_pricing_config_schema",
            "_load_pricing_config",
            "_ensure_pricing_config_files",
            "_save_pricing_config",
            "_migrate_legacy_materials_to_direct_sell_prices",
            "_ensure_pricing_materials",
            "_apply_sell_pricing_to_quote",
            "_format_eur",
            "_format_m",
            "_extract_pricing_from_any",
            "_aggregate_materials_from_subjob_quotes",
            "_parse_calculation_summary_totals",
        ),
    ),
    (
        "metod_app/pricing/report_runtime.py",
        "PricingReportRuntime",
        ("_write_human_calculation_summary",),
    ),
    (
        "metod_app/jobs/output_runtime.py",
        "JobOutputRuntime",
        (
            "_parse_panels_csv",
            "_is_subjob",
            "_filter_panels_csv_by_material",
            "_parts_for_panels_rows",
            "_customer_display_name",
            "_customer_name_from_job",
            "_material_name_and_thickness",
            "_resolve_stickertool_material_display_name",
            "_job_material_context",
            "_sheet_sequence_from_filename",
            "_admin_sheet_download_name",
            "_generate_stickertool_json",
            "_placements_item_count",
            "_generate_labels_json_strict",
            "_input_dxf_source_map",
            "_finalize_subjob_outputs",
            "_write_master_job_links",
            "_finalization_complete",
            "_sealed_output_artifacts",
        ),
    ),
)


def _target_names(target: ast.AST) -> set[str]:
    if isinstance(target, ast.Name):
        return {target.id}
    if isinstance(target, (ast.Tuple, ast.List)):
        return {name for item in target.elts for name in _target_names(item)}
    return set()


def _top_level_names(tree: ast.Module) -> set[str]:
    names: set[str] = set()
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            names.add(node.name)
        elif isinstance(node, ast.Import):
            names.update(alias.asname or alias.name.split(".", 1)[0] for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            names.update(alias.asname or alias.name for alias in node.names)
        elif isinstance(node, ast.Assign):
            for target in node.targets:
                names.update(_target_names(target))
        elif isinstance(node, ast.AnnAssign):
            names.update(_target_names(node.target))
        elif not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            # Optional platform imports are commonly wrapped in a module-level
            # try/except (for example POSIX fcntl).
            for child in ast.walk(node):
                if isinstance(child, ast.Import):
                    names.update(
                        alias.asname or alias.name.split(".", 1)[0]
                        for alias in child.names
                    )
                elif isinstance(child, ast.ImportFrom):
                    names.update(alias.asname or alias.name for alias in child.names)
    return names


def _dependencies(node: ast.FunctionDef, global_names: set[str]) -> tuple[str, ...]:
    if any(isinstance(child, ast.Global) for child in ast.walk(node)):
        raise RuntimeError(f"global assignment requires explicit owner: {node.name}")
    local_names = {
        argument.arg
        for argument in (*node.args.posonlyargs, *node.args.args, *node.args.kwonlyargs)
    }
    if node.args.vararg:
        local_names.add(node.args.vararg.arg)
    if node.args.kwarg:
        local_names.add(node.args.kwarg.arg)
    for child in ast.walk(node):
        if isinstance(child, ast.Name) and isinstance(child.ctx, (ast.Store, ast.Param)):
            local_names.add(child.id)
        elif isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) and child is not node:
            local_names.add(child.name)
        elif isinstance(child, ast.Import):
            local_names.update(alias.asname or alias.name.split(".", 1)[0] for alias in child.names)
        elif isinstance(child, ast.ImportFrom):
            local_names.update(alias.asname or alias.name for alias in child.names)
        elif isinstance(child, ast.ExceptHandler) and child.name:
            local_names.add(child.name)
    loaded = {
        child.id
        for child in ast.walk(node)
        if isinstance(child, ast.Name) and isinstance(child.ctx, ast.Load)
    }
    return tuple(sorted((loaded & global_names) - local_names))


def _as_method(source: str, node: ast.FunctionDef, global_names: set[str]) -> str:
    original = "".join(source.splitlines(keepends=True)[node.lineno - 1 : node.end_lineno])
    if node.name == "_server_maintenance_loop":
        original = original.replace(
            "interval_seconds: float = _SERVER_MAINTENANCE_LOOP_SECONDS",
            "interval_seconds: float = 15 * 60",
            1,
        )
    lines = ["    " + line for line in original.splitlines(keepends=True)]
    prefix = f"    def {node.name}("
    if not lines[0].startswith(prefix):
        raise RuntimeError(f"unexpected runtime signature: {node.name}")
    suffix = lines[0][len(prefix) :]
    lines[0] = prefix + "_owner" + (suffix if suffix.startswith(")") else f", {suffix}")
    # Insert inside the body, not after the first physical line: several
    # signatures span multiple lines.
    insert = node.body[0].lineno - node.lineno
    if node.body and isinstance(node.body[0], ast.Expr):
        value = node.body[0].value
        if isinstance(value, ast.Constant) and isinstance(value.value, str):
            insert = node.body[0].end_lineno - node.lineno + 1
    dependencies = _dependencies(node, global_names)
    bindings = ["        runtime = _owner._runtime\n"]
    bindings.extend(f"        {name} = runtime.{name}\n" for name in dependencies)
    lines[insert:insert] = bindings + ["\n"]
    return "".join(lines).rstrip() + "\n"


def main() -> int:
    targets = [APP / relative for relative, _, _ in GROUPS]
    if any(path.exists() for path in targets):
        raise RuntimeError("R9RC1 domain extraction has already run")
    source = APPLICATION.read_text(encoding="utf-8", errors="strict")
    tree = ast.parse(source)
    nodes = {
        node.name: node
        for node in tree.body
        if isinstance(node, ast.FunctionDef)
    }
    required = {name for _, _, names in GROUPS for name in names}
    if len(required) != sum(len(names) for _, _, names in GROUPS):
        raise RuntimeError("duplicate runtime function ownership")
    missing = required - set(nodes)
    if missing:
        raise RuntimeError(f"runtime source inventory drifted: {sorted(missing)}")
    global_names = _top_level_names(tree)

    ownership_lines = [
        "# Bounded domain owners. Each owner resolves mutable dependencies from this live\n",
        "# composition module at call time, preserving operational/test overrides.\n",
    ]
    for relative, class_name, names in GROUPS:
        target = APP / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        init_file = target.parent / "__init__.py"
        if not init_file.exists():
            init_file.write_text(f'"""{target.parent.name.title()} runtime domain."""\n', encoding="utf-8")
        methods = "\n\n".join(_as_method(source, nodes[name], global_names) for name in names)
        module = (
            "from __future__ import annotations\n\n"
            f'"""Bounded {class_name} implementation with explicit runtime injection."""\n\n'
            f"class {class_name}:\n"
            "    def __init__(self, runtime):\n"
            "        self._runtime = runtime\n\n"
            + methods
            + "\n"
            f"    EXPORTS = {names!r}\n\n"
            f"__all__ = (\"{class_name}\",)\n"
        )
        target.write_text(module, encoding="utf-8")

        import_path = relative[:-3].replace("/", ".")
        owner_name = re.sub(r"(?<!^)(?=[A-Z])", "_", class_name).upper()
        ownership_lines.append(f"from {import_path} import {class_name}\n")
        ownership_lines.append(f"_{owner_name} = {class_name}(sys.modules[__name__])\n")
        for name in names:
            ownership_lines.append(f"{name} = _{owner_name}.{name}\n")
        ownership_lines.append("\n")

    skip: set[int] = set()
    for name in required:
        node = nodes[name]
        skip.update(range(node.lineno, node.end_lineno + 1))
    insert_at = min(nodes[name].lineno for name in required)
    output: list[str] = []
    for line_number, line in enumerate(source.splitlines(keepends=True), 1):
        if line_number == insert_at:
            output.extend(ownership_lines)
            output.append("\n")
        if line_number not in skip:
            output.append(line)
    transformed = re.sub(r"\n{4,}", "\n\n\n", "".join(output))
    APPLICATION.write_text(transformed, encoding="utf-8")
    print(f"extracted {len(required)} functions into {len(GROUPS)} bounded domain owners")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
