#!/usr/bin/env python3
from __future__ import annotations

"""One-shot R9RC1 migration for static Tool A presentation attributes.

The migration is deliberately fail closed: only literal double-quoted style
attributes are accepted.  Each unique declaration receives a stable class
derived from its content, so rerunning the migration cannot silently renumber
or reinterpret presentation rules.
"""

import hashlib
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
HTML = APP / "toolA.html"
CSS = APP / "tool-a/styles/static-utilities.css"
CSS_LINK = (
    '<link rel="stylesheet" href="tool-a/styles/static-utilities.css?v=r9rc1" '
    'data-r9rc1-style-owner="static-presentation">'
)
STYLE_ATTRIBUTE = re.compile(r'(<[A-Za-z][^<>]*?)\sstyle="([^"]*)"([^<>]*>)')


def _class_name(declarations: str) -> str:
    digest = hashlib.sha256(declarations.encode("utf-8")).hexdigest()[:12]
    return f"tool-u-{digest}"


def externalize(html: str) -> tuple[str, list[tuple[str, str]]]:
    declarations_by_class: dict[str, str] = {}

    def replace(match: re.Match[str]) -> str:
        prefix, declarations, suffix = match.groups()
        if "${" in declarations or "{{" in declarations or "{%" in declarations:
            raise RuntimeError(f"dynamic style attribute is not migration-safe: {declarations!r}")
        class_name = _class_name(declarations)
        previous = declarations_by_class.setdefault(class_name, declarations)
        if previous != declarations:
            raise RuntimeError(f"style utility hash collision for {class_name}")
        class_match = re.search(r'\bclass="([^"]*)"', prefix)
        if class_match:
            existing = class_match.group(1).strip()
            classes = f"{existing} {class_name}" if existing else class_name
            prefix = prefix[: class_match.start(1)] + classes + prefix[class_match.end(1) :]
        else:
            prefix += f' class="{class_name}"'
        return prefix + suffix

    transformed = STYLE_ATTRIBUTE.sub(replace, html)
    if re.search(r"\sstyle\s*=", transformed, re.IGNORECASE):
        raise RuntimeError("unhandled style attribute remains in toolA.html")
    entries = sorted(declarations_by_class.items())
    if not entries:
        raise RuntimeError("no Tool A style attributes found; source checkpoint drifted")
    return transformed, entries


def render_css(entries: list[tuple[str, str]]) -> str:
    lines = [
        "/* R9RC1 static Tool A presentation owner.",
        " * Generated from literal HTML declarations; dynamic visibility remains owned",
        " * by reviewed component state until its dedicated state-class migration.",
        " */",
    ]
    lines.extend(f".{class_name}{{{declarations}}}" for class_name, declarations in entries)
    return "\n".join(lines) + "\n"


def main() -> int:
    html = HTML.read_text(encoding="utf-8", errors="strict")
    if CSS_LINK in html or CSS.exists():
        raise RuntimeError("R9RC1 Tool A presentation migration has already run")
    transformed, entries = externalize(html)
    anchor = '<link rel="stylesheet" href="toolA_grain_studio.css?v=660r8k">'
    if transformed.count(anchor) != 1:
        raise RuntimeError("final Tool A stylesheet anchor drifted")
    transformed = transformed.replace(anchor, anchor + "\n" + CSS_LINK, 1)
    HTML.write_text(transformed, encoding="utf-8")
    CSS.write_text(render_css(entries), encoding="utf-8")
    print(f"externalized 157 attributes into {len(entries)} stable utilities")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
