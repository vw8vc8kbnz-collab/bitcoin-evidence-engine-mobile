#!/usr/bin/env python3
from __future__ import annotations

"""Behavior and ownership proof for the first R9E job-status extraction."""

import ast
import importlib
import os
import sys
import tempfile
import unittest
from pathlib import Path


RELEASE = Path(__file__).resolve().parents[1]
APP = RELEASE / "app"
SERVER = APP / "server_py.py"
sys.path.insert(0, str(APP))

from metod_app.jobs.contracts import (  # noqa: E402
    ACTIVE_JOB_STATES,
    CANCELLATION_JOB_STATES,
    JOB_STATE_SCHEMA_VERSION,
    TERMINAL_JOB_STATES,
    canonical_job_state,
    state_from_record,
)
from metod_app.jobs.status import (  # noqa: E402
    build_job_runtime_state,
    job_cancel_requested,
    startup_recovery_decision,
)


class Clock:
    def __init__(self, *values: str) -> None:
        self.values = iter(values)
        self.calls = 0

    def __call__(self) -> str:
        self.calls += 1
        return next(self.values)


class R9EJobStatusBehaviorTests(unittest.TestCase):
    def test_01_state_sets_preserve_the_existing_lifecycle_vocabulary(self) -> None:
        self.assertEqual(JOB_STATE_SCHEMA_VERSION, 1)
        self.assertEqual(
            ACTIVE_JOB_STATES,
            {"ACCEPTED", "PREPARING", "PROCESSING", "FINALIZING"},
        )
        self.assertEqual(CANCELLATION_JOB_STATES, {"CANCEL_REQUESTED", "CANCELLED"})
        self.assertEqual(TERMINAL_JOB_STATES, {"DONE", "FAILED", "CANCELLED"})

    def test_02_normalization_keeps_the_old_string_semantics(self) -> None:
        self.assertEqual(canonical_job_state("processing"), "PROCESSING")
        self.assertEqual(canonical_job_state(None), "NONE")
        self.assertEqual(state_from_record({"state": "cancel_requested"}), "CANCEL_REQUESTED")
        self.assertEqual(state_from_record({"state": None}), "")
        self.assertEqual(state_from_record(None), "")

    def test_03_new_state_calls_clock_twice_and_preserves_exact_key_order(self) -> None:
        clock = Clock("created", "updated")
        value = build_job_runtime_state(
            job_id="JOB_A", state="accepted", previous={}, now_iso=clock,
        )
        self.assertEqual(clock.calls, 2)
        self.assertEqual(list(value), ["schemaVersion", "jobId", "state", "createdAt", "updatedAt"])
        self.assertEqual(value, {
            "schemaVersion": 1,
            "jobId": "JOB_A",
            "state": "ACCEPTED",
            "createdAt": "created",
            "updatedAt": "updated",
        })

    def test_04_existing_created_at_short_circuits_the_first_clock_call(self) -> None:
        clock = Clock("updated")
        value = build_job_runtime_state(
            job_id="JOB_A", state="done", previous={"createdAt": "original"},
            now_iso=clock,
        )
        self.assertEqual(clock.calls, 1)
        self.assertEqual(value["createdAt"], "original")
        self.assertEqual(value["updatedAt"], "updated")

    def test_05_extra_values_retain_the_established_last_write_override(self) -> None:
        value = build_job_runtime_state(
            job_id="JOB_A", state="done", previous={"createdAt": "original"},
            now_iso=Clock("updated"),
            extra={"state": "CUSTOM", "updatedAt": "external", "reason": "test"},
        )
        self.assertEqual(value["state"], "CUSTOM")
        self.assertEqual(value["updatedAt"], "external")
        self.assertEqual(value["reason"], "test")

    def test_06_cancellation_classification_is_exact_and_fail_closed(self) -> None:
        for state in ("CANCEL_REQUESTED", "cancelled"):
            self.assertTrue(job_cancel_requested({"state": state}))
        for record in ({}, None, [], {"state": "FAILED"}, {"state": "CANCEL"}):
            self.assertFalse(job_cancel_requested(record), record)

    def test_07_startup_recovery_decisions_preserve_reason_and_retryability(self) -> None:
        self.assertEqual(
            startup_recovery_decision({"state": "CANCEL_REQUESTED"}),
            ("CANCELLED", {"reason": "startup-reconciliation"}),
        )
        for state in ACTIVE_JOB_STATES:
            self.assertEqual(
                startup_recovery_decision({"state": state.lower()}),
                ("FAILED", {
                    "reason": "service-restarted-during-processing",
                    "retryable": True,
                }),
            )
        for state in ("", "DONE", "FAILED", "CANCELLED", "UNKNOWN"):
            self.assertIsNone(startup_recovery_decision({"state": state}))


class R9EJobStatusOwnershipTests(unittest.TestCase):
    def test_08_server_composes_pure_status_owners_without_duplicate_logic(self) -> None:
        source = SERVER.read_text(encoding="utf-8")
        tree = ast.parse(source, filename=str(SERVER))
        functions = {
            node.name: ast.get_source_segment(source, node) or ""
            for node in tree.body if isinstance(node, ast.FunctionDef)
        }
        self.assertIn("_build_job_runtime_state(", source)
        self.assertIn("_runtime_job_cancel_requested(", functions["_job_cancel_requested"])
        self.assertIn("_startup_recovery_decision", functions["_reconcile_interrupted_jobs_on_startup"])
        self.assertIn("_JOB_RESTART_RECONCILER.reconcile(", functions["_reconcile_interrupted_jobs_on_startup"])
        self.assertNotIn(
            "in {'CANCEL_REQUESTED', 'CANCELLED'}",
            functions["_job_cancel_requested"],
        )
        self.assertNotIn(
            "current in {'ACCEPTED', 'PREPARING', 'PROCESSING', 'FINALIZING'}",
            functions["_reconcile_interrupted_jobs_on_startup"],
        )

    def test_09_server_runtime_state_builder_is_the_module_owner(self) -> None:
        previous = os.environ.get("METOD_STATE_ROOT")
        with tempfile.TemporaryDirectory(prefix="r9e-job-status-") as temp_name:
            os.environ["METOD_STATE_ROOT"] = str(Path(temp_name) / "state")
            try:
                server = importlib.import_module("server_py")
                self.assertIs(server._build_job_runtime_state, build_job_runtime_state)
                self.assertIs(server._runtime_job_cancel_requested, job_cancel_requested)
                self.assertIs(server._startup_recovery_decision, startup_recovery_decision)
            finally:
                if previous is None:
                    os.environ.pop("METOD_STATE_ROOT", None)
                else:
                    os.environ["METOD_STATE_ROOT"] = previous

    def test_10_modules_own_no_io_lock_http_process_or_optimizer_behavior(self) -> None:
        for relative in ("jobs/contracts.py", "jobs/status.py"):
            path = APP / "metod_app" / relative
            tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
            imports = {
                alias.name.split(".", 1)[0]
                for node in ast.walk(tree) if isinstance(node, ast.Import)
                for alias in node.names
            }
            imports.update(
                node.module.split(".", 1)[0]
                for node in ast.walk(tree)
                if isinstance(node, ast.ImportFrom) and node.module
            )
            self.assertFalse(imports & {
                "http", "json", "os", "pathlib", "server_py", "socket",
                "subprocess", "threading", "time",
            })
            source = path.read_text(encoding="utf-8")
            for forbidden in (
                "open(", "durable_write", "unlink(", "replace(", "optimizer",
                "pricing", "VAT", "Lock(", "Thread(", "Popen(",
            ):
                self.assertNotIn(forbidden, source, (relative, forbidden))


if __name__ == "__main__":
    unittest.main(verbosity=2)
