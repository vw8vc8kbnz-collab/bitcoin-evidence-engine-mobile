#!/usr/bin/env python3
from __future__ import annotations

"""Executable ownership and behavior contracts for R9L1 Admin access."""

import ast
import hashlib
import json
import sys
import threading
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SERVER = ROOT / "app/server_py.py"
ACCESS = ROOT / "app/metod_app/admin/access.py"
CONTRACT = ROOT / "R9L1_ACTIVE_ADMIN_PRESENTATION_AUTH_SESSION_EXTRACTION.json"
BEFORE = ROOT / "R9L1_ADMIN_ACCESS_BEFORE_FIXTURE.json"
R9L2_BEFORE = ROOT / "R9L2_OBSERVABILITY_METRICS_BEFORE_FIXTURE.json"
sys.path.insert(0, str(ROOT / "app"))

from metod_app.admin.access import AdminSessionStore, find_admin_user, normalized_admin_users  # noqa: E402


R9L1_ACCESS_SHA256 = "fe5b5248f9fdd58610a09d976fe11aad7562d04d5457b9e50fc4f60d952d1c08"
R9M_ACCESS_SHA256 = "5dad73fceb64b6bc04e57a92cc42d6fa16c1ae2f7b69bd078d5b134e15704271"
PRESENTATION_SHA256 = {
    "ADMIN_HTML": "3bea5f9e67eea6a2a4696d54a3e31aad83c1af087598fb1157c7df16caa5f241",
    "ADMIN_LOGIN_HTML": "657cbf323eb978dcefc039e79870ed42f55b585c37915e978b974136739df1b6",
}
OWNER_SHA256 = {
    "normalized_admin_users": "75c84f4e552814d3061137a3a19622a02a1dd1ecaa558f5e2b56e74f15847bf7",
    "find_admin_user": "9259a7233067163467cea8a7933642972a2fece5b19e788d9c4c8a8d7cf093f4",
    "create": "6eded5f31c5464d0a74cef7f92291c2cb51fa5bb55ef460d29d11e0fba216525",
    "valid": "55d51fb4f44250262014b6edb0a8db8e71afbb4bbdb56f3015784240d25a3972",
    "revoke": "659c54d9ac4af958797b2b02d8dd4e52d0c04627e6996613179639239ccc5afb",
    "actor": "039395b2af4a2610f9b3c4c2b9c886b7e08d90bf9385c41abad4915145e9b364",
    "roles": "306822946adfb96f6d5077fec0721fa41fd03f6d2ec151139a91915e3fc89a80",
    "load_credentials": "ac58379667829c40cf58bf103ee8c8516c20b7eb5520602e53c76400cab34235",
    "warn_if_local_credentials_in_production": "5c9b56ee85dfb5a1e95efa36238ec4b8adb2264232d6ca1fa730465fbe34f7fd",
    "login": "ba8e1b34c79049a1c10092670ce99502010fe37ef2f18f11bd37197f283e7696",
    "check_silent": "b1c1564c6d681e3af173662067baf9dab536dfbf29af2e0f61e7e33085a900a5",
    "current_session_token": "cd8c78c92c237cbced2a9458150471dd6e29506d660c1118f7cc532c89cb95fc",
    "current_actor": "770b68b3fdc539df02ae0ff76823a82826a59b80a77457457fbe3a1def6aff17",
    "logout": "ce7b539337566e438bd322cdcc205f6cfc96587361ab58a5998fadd524b3ee33",
    "wants_native_basic_prompt": "15501cd12fbe0cfbc6a21094b89d7b3d33e5e64269ec6cc3e6c504a7dd229340",
    "send_challenge": "325e6ead419dbcabad166d691e3455920ac18bda5db1021f27dd90665cfa97d2",
    "require_auth": "98fb99c8819e72f7664ebaad4f957a761d18b10a202ae4a544ba964cc5716d9e",
}
HANDLER_ADAPTERS = {
    "_load_admin_credentials",
    "_warn_if_local_admin_credentials_in_production",
    "_api_admin_login",
    "_check_admin_auth_silent",
    "_current_admin_session_token",
    "_current_admin_actor",
    "_api_admin_logout",
    "_wants_native_basic_prompt",
    "_send_admin_auth_challenge",
    "_require_admin_auth",
}


def sha256(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


class MutableClock:
    def __init__(self, now: float = 1000.0) -> None:
        self.now = now

    def __call__(self) -> float:
        return self.now


class R9L1AdminAccessTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.server_source = SERVER.read_text(encoding="utf-8", errors="strict")
        cls.access_source = ACCESS.read_text(encoding="utf-8", errors="strict")
        cls.server_tree = ast.parse(cls.server_source)
        cls.access_tree = ast.parse(cls.access_source)
        cls.contract = json.loads(CONTRACT.read_text(encoding="utf-8"))
        cls.before = json.loads(BEFORE.read_text(encoding="utf-8"))
        cls.r9l2_before = json.loads(R9L2_BEFORE.read_text(encoding="utf-8"))
        cls.access_functions = {
            node.name: node
            for node in ast.walk(cls.access_tree)
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        }
        cls.handler = next(
            node for node in cls.server_tree.body if isinstance(node, ast.ClassDef) and node.name == "Handler"
        )
        cls.handler_functions = {
            node.name: node for node in cls.handler.body if isinstance(node, ast.FunctionDef)
        }

    def access_function_source(self, name: str) -> str:
        segment = ast.get_source_segment(self.access_source, self.access_functions[name])
        self.assertIsNotNone(segment)
        return str(segment)

    def handler_function_source(self, name: str) -> str:
        segment = ast.get_source_segment(self.server_source, self.handler_functions[name])
        self.assertIsNotNone(segment)
        return str(segment)

    def test_01_before_fixture_seals_r9k5_source_and_active_owners(self) -> None:
        self.assertEqual(self.before["sourceCheckpoint"], "R9K5")
        self.assertEqual(self.before["server"], {
            "bytes": 672064,
            "lines": 13819,
            "sha256": "078a31084bb162bb226fda394f5f4efed52101d75760f5145661b5d33ea8ebc7",
        })
        self.assertEqual(len(self.before["activeHandlerSourceSha256"]), 11)

    def test_02_r9l1_presentation_fixture_is_byte_exact_and_r9m_has_one_new_owner(self) -> None:
        for name, expected in PRESENTATION_SHA256.items():
            self.assertEqual(self.before["presentation"][name]["valueSha256"], expected, name)
        self.assertNotRegex(self.access_source, r"(?m)^(?:ADMIN_HTML|ADMIN_LOGIN_HTML)\s*=")
        self.assertNotRegex(self.server_source, r"(?m)^(?:ADMIN_HTML|ADMIN_LOGIN_HTML)\s*=")
        self.assertIn("from .presentation import ADMIN_HTML, ADMIN_LOGIN_HTML", self.access_source)

    def test_03_server_contains_only_narrow_handler_and_session_adapters(self) -> None:
        self.assertIn("from metod_app.admin.access import (", self.server_source)
        for name in HANDLER_ADAPTERS:
            source = self.handler_function_source(name)
            self.assertLessEqual(len(source.splitlines()), 2, name)
            self.assertIn("_ADMIN_ACCESS", source, name)
        for forbidden in ("_ADMIN_SESSIONS_LOCK", "_ADMIN_SESSIONS:", "absoluteExpiresAt\") <= now"):
            self.assertNotIn(forbidden, self.server_source)

    def test_04_access_owner_and_security_sensitive_methods_are_byte_exact(self) -> None:
        self.assertEqual(sha256(ACCESS.read_bytes()), R9M_ACCESS_SHA256)
        for name, expected in OWNER_SHA256.items():
            self.assertEqual(sha256(self.access_function_source(name).encode("utf-8")), expected, name)

    def test_05_credential_normalization_and_constant_time_lookup_are_preserved(self) -> None:
        credentials = {
            "users": [
                {"username": "alice", "passwordHash": "hash-a", "roles": ["Admin", "ops"]},
                {"username": "disabled", "password_hash": "hash-b", "active": False},
            ]
        }
        self.assertEqual(normalized_admin_users(credentials), [{
            "username": "alice",
            "password_hash": "hash-a",
            "totp_secret": "",
            "roles": ["admin", "ops"],
        }])
        self.assertEqual(find_admin_user(credentials, "alice")["password_hash"], "hash-a")
        self.assertIsNone(find_admin_user(credentials, "Alice"))

    def test_06_session_create_role_actor_validity_and_revoke_are_preserved(self) -> None:
        clock = MutableClock()
        store = AdminSessionStore(
            idle_seconds=600,
            absolute_seconds=3600,
            max_sessions=lambda: 32,
            lock=threading.Lock(),
            clock=clock,
            token_factory=lambda: "sealed-token",
        )
        token, expires_at = store.create(" alice ", ["Admin", "ops", "admin"])
        self.assertEqual((token, expires_at), ("sealed-token", 4600.0))
        self.assertTrue(store.valid(token))
        self.assertEqual(store.actor(token), "alice")
        self.assertEqual(store.roles(token), frozenset({"admin", "ops"}))
        store.revoke(token)
        self.assertFalse(store.valid(token))

    def test_07_idle_absolute_and_cookie_expiry_clamps_are_preserved(self) -> None:
        clock = MutableClock()
        store = AdminSessionStore(
            idle_seconds=1,
            absolute_seconds=1,
            max_sessions=lambda: 32,
            lock=threading.Lock(),
            clock=clock,
            token_factory=lambda: "expiring-token",
        )
        token, expires_at = store.create("actor")
        self.assertEqual(store.idle_seconds, 300)
        self.assertEqual(store.cookie_max_age, 300)
        self.assertEqual(expires_at, 1300.0)
        clock.now = 1300.0
        self.assertFalse(store.valid(token))

    def test_08_bounded_store_evicts_the_oldest_session(self) -> None:
        clock = MutableClock()
        tokens = iter(f"token-{index}" for index in range(9))
        store = AdminSessionStore(
            idle_seconds=600,
            absolute_seconds=3600,
            max_sessions=lambda: 1,
            lock=threading.Lock(),
            clock=clock,
            token_factory=lambda: next(tokens),
        )
        created = []
        for index in range(9):
            clock.now += 1
            created.append(store.create(f"actor-{index}")[0])
        self.assertFalse(store.valid(created[0]))
        self.assertTrue(all(store.valid(token) for token in created[1:]))

    def test_09_login_logout_cookie_mfa_and_no_bearer_contract_are_explicit(self) -> None:
        login = self.access_function_source("login")
        logout = self.access_function_source("logout")
        for marker in (
            "password_ok = deps.verify_password",
            "mfa_ok = deps.verify_totp",
            "SameSite=Strict; HttpOnly",
            '"expiresAt": int(expires_at)',
            "deps.dummy_password_hash",
            "deps.dummy_totp_secret",
        ):
            self.assertIn(marker, login)
        self.assertNotRegex(login, r"['\"]token['\"]\s*:")
        self.assertIn("body = b'{\"ok\":true}'", logout)
        self.assertIn("Max-Age=0", logout)

    def test_10_csrf_origin_adapter_and_route_auth_order_remain_sealed(self) -> None:
        origin = self.handler_function_source("_require_admin_write_origin")
        self.assertEqual(
            sha256(origin.encode("utf-8")),
            "321dbac49a0576093a056534b1b7c50f2168678397088023b395ad8fcd3fdf0a",
        )
        self.assertIn("if parsed.path.startswith('/api/admin/'):", self.server_source)
        self.assertIn("if not self._require_admin_auth():", self.server_source)

    def test_11_contract_matches_extracted_owner_metrics_and_wire_fixture(self) -> None:
        extraction = self.contract["extraction"]
        self.assertEqual(extraction["serverAfter"], self.r9l2_before["server"])
        self.assertEqual(extraction["accessOwner"]["sha256"], R9L1_ACCESS_SHA256)
        self.assertFalse(extraction["presentationValuesChanged"])
        self.assertFalse(extraction["wireBehaviorExpectedChanged"])
        self.assertEqual(self.before["wireContract"]["logoutBodyUtf8"], '{"ok":true}')

    def test_12_scope_is_narrow_provisional_and_external_gates_stay_no_go(self) -> None:
        self.assertEqual(
            self.contract["contractId"],
            "R9L1_ACTIVE_ADMIN_PRESENTATION_AUTH_SESSION_EXTRACTION",
        )
        self.assertEqual(self.contract["status"], "PROVISIONAL_DEVELOPMENT_ONLY")
        self.assertFalse(self.contract["releaseEligible"])
        self.assertEqual(len(self.contract["deferredExclusiveScope"]), 6)
        external = self.contract["externalEvidence"]
        self.assertTrue(all(value == "DEFERRED_NO_GO" for key, value in external.items() if key != "productionGo"))
        self.assertFalse(external["productionGo"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
