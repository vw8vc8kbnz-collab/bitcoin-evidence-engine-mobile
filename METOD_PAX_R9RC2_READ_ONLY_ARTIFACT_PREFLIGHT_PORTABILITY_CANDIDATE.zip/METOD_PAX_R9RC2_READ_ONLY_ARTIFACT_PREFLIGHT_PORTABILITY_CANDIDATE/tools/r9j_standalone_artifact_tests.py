#!/usr/bin/env python3
from __future__ import annotations

"""Adversarial tests for the R9J standalone artifact extraction boundary."""

import stat
import tempfile
import unittest
import warnings
import zipfile
from pathlib import Path

from verify_standalone_artifact import safe_extract


def regular_info(name: str) -> zipfile.ZipInfo:
    info = zipfile.ZipInfo(name)
    info.create_system = 3
    info.external_attr = (stat.S_IFREG | 0o444) << 16
    return info


class R9JStandaloneArtifactTests(unittest.TestCase):
    def write_zip(self, root: Path, entries: list[tuple[zipfile.ZipInfo, bytes]]) -> Path:
        artifact = root / "probe.zip"
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            with zipfile.ZipFile(artifact, "w", compression=zipfile.ZIP_STORED) as archive:
                for info, payload in entries:
                    archive.writestr(info, payload)
        return artifact

    def assert_rejected(self, entries: list[tuple[zipfile.ZipInfo, bytes]]) -> None:
        with tempfile.TemporaryDirectory(prefix="r9j_zip_test_") as temporary:
            root = Path(temporary)
            artifact = self.write_zip(root, entries)
            with self.assertRaises(RuntimeError):
                safe_extract(artifact, root / "out")

    def test_01_one_regular_root_is_accepted(self) -> None:
        with tempfile.TemporaryDirectory(prefix="r9j_zip_test_") as temporary:
            root = Path(temporary)
            artifact = self.write_zip(root, [(regular_info("release/file.txt"), b"sealed\n")])
            release, count = safe_extract(artifact, root / "out")
            self.assertEqual(release.name, "release")
            self.assertEqual(count, 1)
            self.assertEqual((release / "file.txt").read_bytes(), b"sealed\n")

    def test_02_parent_traversal_is_rejected(self) -> None:
        self.assert_rejected([(regular_info("release/../escape.txt"), b"no")])

    def test_03_absolute_and_backslash_paths_are_rejected(self) -> None:
        self.assert_rejected([(regular_info("/release/file.txt"), b"no")])
        self.assert_rejected([(regular_info("release\\file.txt"), b"no")])

    def test_04_duplicate_members_are_rejected(self) -> None:
        info = regular_info("release/file.txt")
        self.assert_rejected([(info, b"first"), (regular_info(info.filename), b"second")])

    def test_05_symlink_member_is_rejected(self) -> None:
        info = zipfile.ZipInfo("release/link")
        info.create_system = 3
        info.external_attr = (stat.S_IFLNK | 0o777) << 16
        self.assert_rejected([(info, b"target")])

    def test_06_git_metadata_is_rejected_case_insensitively(self) -> None:
        self.assert_rejected([(regular_info("release/.GiT/config"), b"no")])

    def test_07_multiple_roots_are_rejected(self) -> None:
        self.assert_rejected([
            (regular_info("release-a/file.txt"), b"a"),
            (regular_info("release-b/file.txt"), b"b"),
        ])


if __name__ == "__main__":
    unittest.main(verbosity=2)
