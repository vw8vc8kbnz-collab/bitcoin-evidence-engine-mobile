#!/usr/bin/env python3
from __future__ import annotations

"""Focused mutation, snapshot and cross-process maintenance barrier contracts."""

import ast
import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path


RELEASE = Path(__file__).resolve().parents[1]
APP = RELEASE / "app"
sys.path.insert(0, str(APP))

from metod_app.storage.maintenance import StateMaintenanceBarrier  # noqa: E402


class FakeFileLock:
    LOCK_EX = "exclusive"
    LOCK_UN = "unlock"

    def __init__(self) -> None:
        self.calls: list[tuple[int, str]] = []

    def flock(self, descriptor: int, operation: str) -> None:
        self.calls.append((descriptor, operation))


class BarrierFixture:
    def __init__(self, root: Path, *, monotonic=None, sleep=None) -> None:
        self.root = root
        self.state = {"snapshot": False, "mutations": 0}
        self.condition = threading.Condition(threading.RLock())
        self.maintenance_lock = threading.Lock()
        self.create_lock = threading.Lock()
        self.process_lock = threading.RLock()
        self.catalog_lock = threading.Lock()
        self.creates = 0
        self.processes: dict[str, set[object]] = {}
        self.catalog: set[str] = set()
        self.file_lock = FakeFileLock()
        self.queue = root / "queue_processing"
        self.barrier = StateMaintenanceBarrier(
            ensure_directories=self.ensure_directories,
            backups_root=lambda: self.root / "backups",
            maintenance_lock=lambda: self.maintenance_lock,
            file_lock_module=lambda: self.file_lock,
            mutation_condition=lambda: self.condition,
            snapshot_active=lambda: self.state["snapshot"],
            set_snapshot_active=lambda value: self.state.__setitem__("snapshot", bool(value)),
            mutation_count=lambda: self.state["mutations"],
            set_mutation_count=lambda value: self.state.__setitem__("mutations", int(value)),
            public_job_create_lock=lambda: self.create_lock,
            public_job_create_total=lambda: self.creates,
            active_job_processes_lock=lambda: self.process_lock,
            active_job_processes=lambda: self.processes,
            catalog_image_sync_lock=lambda: self.catalog_lock,
            catalog_image_sync_active=lambda: self.catalog,
            queue_processing_root=lambda: self.queue,
            monotonic=monotonic or time.monotonic,
            sleep=sleep or time.sleep,
        )

    def ensure_directories(self) -> None:
        (self.root / "backups").mkdir(parents=True, exist_ok=True)
        self.queue.mkdir(parents=True, exist_ok=True)


class R9DMaintenanceBarrierTests(unittest.TestCase):
    def setUp(self) -> None:
        self.holder = tempfile.TemporaryDirectory(prefix="r9d-maintenance-")
        self.fixture = BarrierFixture(Path(self.holder.name))

    def tearDown(self) -> None:
        self.holder.cleanup()

    def test_01_mutations_are_counted_and_fail_closed_during_snapshot(self) -> None:
        barrier, state = self.fixture.barrier, self.fixture.state
        self.assertTrue(barrier.begin_mutation())
        self.assertEqual(state["mutations"], 1)
        barrier.end_mutation()
        self.assertEqual(state["mutations"], 0)
        state["snapshot"] = True
        self.assertFalse(barrier.begin_mutation())
        self.assertEqual(state["mutations"], 0)

    def test_02_snapshot_waits_for_live_mutation_and_notifies_on_close(self) -> None:
        barrier, state, condition = (
            self.fixture.barrier, self.fixture.state, self.fixture.condition
        )
        self.assertTrue(barrier.begin_mutation())
        entered = threading.Event()
        failures: list[BaseException] = []

        def worker() -> None:
            try:
                barrier.begin_consistent_snapshot(timeout_seconds=5)
                entered.set()
            except BaseException as exc:
                failures.append(exc)

        thread = threading.Thread(target=worker, daemon=True)
        thread.start()
        time.sleep(0.1)
        self.assertFalse(entered.is_set())
        barrier.end_mutation()
        thread.join(2)
        self.assertEqual(failures, [])
        self.assertTrue(entered.is_set())
        self.assertTrue(state["snapshot"])
        barrier.end_consistent_snapshot()
        self.assertFalse(state["snapshot"])
        with condition:
            self.assertEqual(state["mutations"], 0)

    def test_03_nested_snapshot_fails_without_changing_active_owner(self) -> None:
        self.fixture.state["snapshot"] = True
        with self.assertRaisesRegex(RuntimeError, "Another state snapshot is already active"):
            self.fixture.barrier.begin_consistent_snapshot()
        self.assertTrue(self.fixture.state["snapshot"])

    def test_04_snapshot_waits_for_jobs_catalog_and_queue_to_drain(self) -> None:
        fixture = self.fixture
        fixture.ensure_directories()
        fixture.creates = 1
        fixture.processes = {"job": {object()}}
        fixture.catalog = {"catalog"}
        queue_item = fixture.queue / "work.json"
        queue_item.write_text("{}\n", encoding="utf-8")
        sleeps: list[float] = []

        def drain(seconds: float) -> None:
            sleeps.append(seconds)
            fixture.creates = 0
            fixture.processes.clear()
            fixture.catalog.clear()
            queue_item.unlink()

        fixture.barrier._sleep = drain
        fixture.barrier.begin_consistent_snapshot(timeout_seconds=5)
        self.assertEqual(sleeps, [0.25])
        self.assertTrue(fixture.state["snapshot"])
        fixture.barrier.end_consistent_snapshot()

    def test_05_active_work_timeout_always_reopens_mutations(self) -> None:
        values = iter((0.0, 6.0))
        fixture = BarrierFixture(
            Path(self.holder.name),
            monotonic=lambda: next(values),
            sleep=lambda _seconds: None,
        )
        fixture.creates = 1
        with self.assertRaisesRegex(RuntimeError, "Timed out draining active jobs for backup"):
            fixture.barrier.begin_consistent_snapshot(timeout_seconds=5)
        self.assertFalse(fixture.state["snapshot"])

    def test_06_exclusive_lock_keeps_thread_then_flock_order_and_shared_path(self) -> None:
        fixture = self.fixture
        with fixture.barrier.exclusive():
            self.assertTrue((fixture.root / "backups/.state_maintenance.lock").is_file())
            self.assertEqual([call[1] for call in fixture.file_lock.calls], ["exclusive"])
        self.assertEqual(
            [call[1] for call in fixture.file_lock.calls],
            ["exclusive", "unlock"],
        )

    def test_07_exclusive_lock_serializes_threads(self) -> None:
        barrier = self.fixture.barrier
        first_entered = threading.Event()
        release_first = threading.Event()
        second_entered = threading.Event()

        def first() -> None:
            with barrier.exclusive():
                first_entered.set()
                release_first.wait(2)

        def second() -> None:
            with barrier.exclusive():
                second_entered.set()

        one = threading.Thread(target=first, daemon=True)
        two = threading.Thread(target=second, daemon=True)
        one.start()
        self.assertTrue(first_entered.wait(1))
        two.start()
        self.assertFalse(second_entered.wait(0.1))
        release_first.set()
        one.join(2)
        two.join(2)
        self.assertTrue(second_entered.is_set())

    def test_08_server_composes_one_owner_and_routes_post_mutations_through_it(self) -> None:
        source = (APP / "server_py.py").read_text(encoding="utf-8")
        tree = ast.parse(source)
        definitions = {node.name for node in tree.body if isinstance(node, ast.FunctionDef)}
        self.assertFalse(definitions & {
            "_state_snapshot_is_active", "_exclusive_state_maintenance",
            "_begin_consistent_snapshot", "_end_consistent_snapshot",
        })
        self.assertEqual(source.count("_STATE_MAINTENANCE_BARRIER = StateMaintenanceBarrier("), 1)
        self.assertEqual(source.count("_STATE_MAINTENANCE_BARRIER.begin_mutation()"), 1)
        self.assertEqual(source.count("_STATE_MAINTENANCE_BARRIER.end_mutation()"), 1)

    def test_09_module_owns_no_archive_backup_http_optimizer_or_thread_creation(self) -> None:
        source = (APP / "metod_app/storage/maintenance.py").read_text(encoding="utf-8")
        tree = ast.parse(source)
        imports = {
            alias.name.split(".", 1)[0]
            for node in ast.walk(tree) if isinstance(node, ast.Import)
            for alias in node.names
        }
        imports.update(
            node.module.split(".", 1)[0]
            for node in ast.walk(tree)
            if isinstance(node, ast.ImportFrom) and node.module
        )
        self.assertFalse(imports & {"server_py", "threading", "http", "socket", "subprocess"})
        for forbidden in (
            "archive_", "zipfile", "dxf_nesting_optimizer", "_run_optimizer",
            "vat", "requestId", "status_code",
        ):
            self.assertNotIn(forbidden, source)


if __name__ == "__main__":
    unittest.main(verbosity=2)
