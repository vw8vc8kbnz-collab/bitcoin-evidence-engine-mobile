#!/usr/bin/env python3
from __future__ import annotations

"""Fail-closed R9G-8 proof for the completed Tool A ownership boundary."""

import ast
import base64
import hashlib
import json
import re
import shutil
import subprocess
import unittest
from pathlib import Path

from r9h_shell_source import read_toola_expanded


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
HTML = APP / "toolA.html"
BOOTSTRAP = APP / "tool-a/bootstrap.js"
JOBS = APP / "tool-a/api/jobs.js"
REQUESTS = APP / "tool-a/api/requests.js"
DIALOG = APP / "tool-a/components/dialog.js"
FOOTER = APP / "tool-a/components/footer.js"
GRAIN_PREVIEW = APP / "tool-a/components/grain-preview.js"
CHECKOUT_REVIEW = APP / "tool-a/components/checkout-review.js"
MATERIAL_CARD = APP / "tool-a/components/material-card.js"
PANEL_EDITOR = APP / "tool-a/components/panel-editor.js"
MOBILE_CART = APP / "tool-a/components/mobile-material-cart.js"
OVERLAY_ROUTER = APP / "tool-a/components/overlay-router.js"
PROGRESS = APP / "tool-a/components/progress-overlay.js"
THANK_YOU = APP / "tool-a/components/thank-you.js"
RULES = ROOT / "R9B_ARCHITECTURE_RULES.json"


def data_url(data: bytes) -> str:
    return "data:text/javascript;base64," + base64.b64encode(data).decode()


def run_node(source: str) -> dict:
    node = shutil.which("node")
    if not node:
        raise AssertionError("Node is required by the release architecture gate")
    completed = subprocess.run(
        [node, "--input-type=module"], input=source, text=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=10, check=False,
    )
    if completed.returncode != 0:
        raise AssertionError(completed.stdout)
    return json.loads(completed.stdout.strip().splitlines()[-1])


def bootstrap_url() -> str:
    selectors = data_url((APP / "tool-a/state/selectors.js").read_bytes())
    store = (APP / "tool-a/state/store.js").read_text(encoding="utf-8").replace(
        "./selectors.js", selectors,
    )
    replacements = {
        "./api/jobs.js": data_url(JOBS.read_bytes()),
        "./api/requests.js": data_url(REQUESTS.read_bytes()),
        "./components/dialog.js": data_url(DIALOG.read_bytes()),
        "./components/footer.js": data_url(FOOTER.read_bytes()),
        "./components/grain-preview.js": data_url(GRAIN_PREVIEW.read_bytes()),
        "./components/checkout-review.js": data_url(CHECKOUT_REVIEW.read_bytes()),
        "./components/material-card.js": data_url(MATERIAL_CARD.read_bytes()),
        "./components/panel-editor.js": data_url(PANEL_EDITOR.read_bytes()),
        "./components/mobile-material-cart.js": data_url(MOBILE_CART.read_bytes()),
        "./components/overlay-router.js": data_url(OVERLAY_ROUTER.read_bytes()),
        "./components/progress-overlay.js": data_url(PROGRESS.read_bytes()),
        "./components/thank-you.js": data_url(THANK_YOU.read_bytes()),
        "./state/store.js": data_url(store.encode()),
        "./steps/materials.js": data_url((APP / "tool-a/steps/materials.js").read_bytes()),
        "./steps/panels.js": data_url((APP / "tool-a/steps/panels.js").read_bytes()),
        "./steps/grain.js": data_url((APP / "tool-a/steps/grain.js").read_bytes()),
        "./steps/customer.js": data_url((APP / "tool-a/steps/customer.js").read_bytes()),
    }
    source = BOOTSTRAP.read_text(encoding="utf-8")
    for old, new in replacements.items():
        source = source.replace(old, new)
    return data_url(source.encode())


def assignment_set(path: Path, name: str) -> set[str]:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(
            isinstance(target, ast.Name) and target.id == name for target in node.targets
        ):
            value = node.value
            if isinstance(value, ast.Call) and isinstance(value.func, ast.Name) and value.func.id == "frozenset":
                value = value.args[0]
            return set(ast.literal_eval(value))
    raise AssertionError(f"{name} not found in {path}")


class R9GOwnershipCleanupTests(unittest.TestCase):
    def test_01_superseded_bridge_is_absent_and_not_publicly_served(self) -> None:
        bridge = APP / "toolA_final_submit_bridge.js"
        self.assertFalse(bridge.exists())
        server_files = assignment_set(APP / "metod_app/http/static.py", "PUBLIC_STATIC_ROOT_FILES")
        matcher_source = (APP / "metod_app/http/matcher.py").read_text(encoding="utf-8")
        self.assertIn("from .static import (", matcher_source)
        self.assertNotIn("PUBLIC_STATIC_ROOT_FILES =", matcher_source)
        self.assertNotIn("toolA_final_submit_bridge.js", server_files)
        self.assertNotIn("toolA_final_submit_bridge.js", read_toola_expanded(HTML))

    def test_02_client_endpoint_literals_have_exactly_one_production_owner(self) -> None:
        html = read_toola_expanded(HTML)
        jobs = JOBS.read_text(encoding="utf-8")
        requests = REQUESTS.read_text(encoding="utf-8")
        module_sources = {
            path.relative_to(APP).as_posix(): path.read_text(encoding="utf-8")
            for path in (APP / "tool-a").rglob("*.js")
        }
        self.assertEqual(jobs.count('fetchImpl("/api/jobs",'), 1)
        self.assertEqual(jobs.count("/status`"), 1)
        self.assertEqual(requests.count('fetchImpl("/api/submit_config",'), 1)
        for name, source in module_sources.items():
            if name != "tool-a/api/jobs.js":
                self.assertNotIn('fetchImpl("/api/jobs"', source, name)
                self.assertNotIn("fetchImpl(`/api/jobs/", source, name)
            if name != "tool-a/api/requests.js":
                self.assertNotIn('fetchImpl("/api/submit_config"', source, name)
        self.assertNotIn("fetch('/api/jobs'", html)
        self.assertNotIn("fetch('/api/submit_config'", html)
        self.assertNotIn("XMLHttpRequest", jobs + requests)

    def test_03_compute_and_submit_have_one_physical_click_adapter_each(self) -> None:
        source = read_toola_expanded(HTML)
        component = CHECKOUT_REVIEW.read_text(encoding="utf-8")
        self.assertEqual(source.count("saveQuoteBtn.addEventListener('click', async ()=>"), 1)
        self.assertEqual(source.count("r9JobsOwner().startJob(__payloadJson)"), 1)
        self.assertEqual(source.count("r9JobsOwner().pollJob({"), 1)
        self.assertEqual(source.count("R9G8_SINGLE_FINAL_SUBMIT_CLICK_ADAPTER"), 1)
        self.assertEqual(source.count("handleCheckoutReviewEvent?.(event)"), 3)
        self.assertEqual(component.count('const submit = closest("#sendConfigBtn, #btnSendConfig");'), 1)
        self.assertEqual(component.count("const submitFinal = rootRef.__metodSubmitFinalConfiguration;"), 1)
        self.assertNotIn("priceSendBtn.addEventListener('click'", source)
        self.assertNotIn("sendConfigBtn.addEventListener('click'", source)
        self.assertNotIn("btnSendConfig.addEventListener('click'", source)

    def test_04_temporary_foundation_api_is_frozen_and_exact(self) -> None:
        url = bootstrap_url()
        result = run_node(f"""
globalThis.state={{cart:[],extraPanels:[]}};globalThis.__metod_uiStep='material';
await import({json.dumps(url)});const api=globalThis.ToolAR9Foundation;
console.log(JSON.stringify({{keys:Reflect.ownKeys(api),frozen:Object.isFrozen(api),
 revision:api.revision,mode:api.mode,descriptor:Object.getOwnPropertyDescriptor(globalThis,'ToolAR9Foundation')}}));
""")
        self.assertTrue(set([
            "revision", "mode", "getSnapshot", "getMaterialsView", "getPanelsView",
            "getGrainView", "getCustomerView", "startJob", "cancelJob", "pollJob",
            "fetchJobPricingSummary", "authoritativeTotalInclVat",
            "submitFinalConfiguration", "resetFinalSubmission", "getFinalSubmissionState",
        ]).issubset(result["keys"]))
        self.assertEqual(result["revision"], "R9I_SYNC_CATALOG_REFRESH_CLEANUP_9")
        self.assertEqual(result["mode"], "legacy-read-cleanup-adapter")
        self.assertTrue(result["frozen"])
        self.assertFalse(result["descriptor"]["configurable"])
        self.assertFalse(result["descriptor"]["writable"])

    def test_05_pure_modules_have_no_dom_storage_or_unapproved_network(self) -> None:
        rules = json.loads(RULES.read_text(encoding="utf-8"))["frontend"]
        self.assertGreaterEqual(len(rules["publicStaticFiles"]), 9)
        for relative, forbidden in rules["forbiddenTokens"].items():
            source = (ROOT / relative).read_text(encoding="utf-8")
            for token in forbidden:
                self.assertNotIn(token, source, f"{relative}: {token}")
        network_tokens = ("fetch(", "XMLHttpRequest", "EventSource", "WebSocket")
        for relative in rules["moduleImports"]:
            source = (ROOT / relative).read_text(encoding="utf-8")
            if relative not in {"app/tool-a/api/jobs.js", "app/tool-a/api/requests.js"}:
                for token in network_tokens:
                    self.assertNotIn(token, source, f"{relative}: {token}")

    def test_06_one_compute_action_is_one_job_post_and_one_poller(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(JOBS.read_bytes()))});const calls=[];
const api=m.createJobsApi({{fetchImpl:async(url,options)=>{{calls.push({{url,options}});return url==='/api/jobs'
 ? {{ok:true,status:202,json:async()=>({{jobId:'JOB-8'}})}}
 : {{ok:true,status:200,json:async()=>({{meta:{{status:'done'}},pricingSummary:{{totalInclVat:620.43}}}})}};}},sleep:async()=>{{}}}});
await api.startJob('{{"panelsCsv":"exact"}}');await api.pollJob({{jobId:'JOB-8'}});
console.log(JSON.stringify({{calls}}));
""")
        self.assertEqual([call["url"] for call in result["calls"]], [
            "/api/jobs", "/api/jobs/JOB-8/status",
        ])
        self.assertEqual(result["calls"][0]["options"]["body"], '{"panelsCsv":"exact"}')

    def test_07_double_submit_is_at_most_one_request(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(REQUESTS.read_bytes()))});let calls=0,release;
const action=m.createFinalSubmitAction({{fetchImpl:async()=>{{calls+=1;await new Promise(resolve=>release=resolve);return {{ok:true,status:200,json:async()=>({{requestId:'REQ-8'}})}};}}}});
const context={{parentJobId:'JOB-8',jobComplete:true,customer:{{email:'a@b.test'}}}};
const first=action.submit(context);await Promise.resolve();const second=await action.submit(context);release();await first;
console.log(JSON.stringify({{calls,ignored:second.ignored,state:action.getState()}}));
""")
        self.assertEqual(result["calls"], 1)
        self.assertTrue(result["ignored"])
        self.assertEqual(result["state"]["status"], "committed")

    def test_08_bootstrap_is_the_only_published_global_boundary(self) -> None:
        source = BOOTSTRAP.read_text(encoding="utf-8")
        self.assertEqual(source.count("Object.defineProperty(globalThis"), 1)
        self.assertEqual(source.count('"ToolAR9Foundation"'), 1)
        self.assertNotIn("document", source)
        self.assertNotIn("addEventListener", source)
        self.assertNotIn("localStorage", source)
        self.assertNotIn("sessionStorage", source)

    def test_09_protected_algorithms_payload_pricing_and_routes_are_unchanged(self) -> None:
        expected = {
            "dxf_nesting_optimizer.py": "42480b301cd660dac1e5e9fec2c8d30bb5c6826c32234a9c1cce765b758bebb8",
            "dxf_geometry.py": "b80a2d006241908bf7b33516f7e0faf59ef61e1e08db86966b23cc5de292c1ff",
            "pricing_helpers.py": "646c2f5186e9b080f6ba8dcf364884411c18e946254bb5c9001647f7cbb425df",
            "panel_contract.py": "e23314fd63a2358a48daa580a92cebb8a40c9862548ba0243461a59347da7fc9",
        }
        for name, digest in expected.items():
            self.assertEqual(hashlib.sha256((APP / name).read_bytes()).hexdigest(), digest, name)
        html = read_toola_expanded(HTML)
        start = html.index("async function buildJobPayload(){")
        end = html.index("  // ---------------------------\n  // Checkout overlays (restmateriaal + klantgegevens)", start)
        payload = html[start:end].encode()
        self.assertEqual(len(payload), 9697)
        self.assertEqual(hashlib.sha256(payload).hexdigest(), "342dac02c2650ac2798e20e62d38d8e1e6b7d518a54daa8fd760d734ae527e47")

    def test_10_preflight_requires_the_r9g_complete_ownership_gate(self) -> None:
        preflight = (ROOT / "tools/final_preflight.py").read_text(encoding="utf-8")
        self.assertIn('"tools/r9g_ownership_cleanup_tests.py"', preflight)
        self.assertIn("R9G complete ownership cleanup", preflight)
        self.assertEqual(
            read_toola_expanded(HTML).count(
                '<script type="module" src="tool-a/bootstrap.js?v=r9i-sync-catalog-refresh-cleanup-9"></script>'
            ),
            1,
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
