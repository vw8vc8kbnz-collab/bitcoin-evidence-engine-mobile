#!/usr/bin/env python3
from __future__ import annotations

"""Executable contracts for the R9J-6 dead finalization cleanup."""

import ast
import hashlib
import json
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SERVER = ROOT / "app/server_py.py"
FINALIZATION = ROOT / "app/metod_app/jobs/finalization.py"
CONTRACT = ROOT / "R9J6_DEAD_FINALIZATION_CLEANUP.json"
R9J6_SERVER_SHA256 = "5dc2a29ebf6aab757b780c812f3431f7844148194d498dd031431061de2b608b"
FINALIZATION_SHA256 = "0cea0d44edada230ff7298fe3ef98b59607aa92427e9725a7961c37559583e31"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


class R9J6DeadFinalizationCleanupTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.source = SERVER.read_text(encoding="utf-8")
        cls.tree = ast.parse(cls.source)
        cls.contract = json.loads(CONTRACT.read_text(encoding="utf-8"))

    def test_01_obsolete_finalization_owner_is_completely_absent(self) -> None:
        definitions = {
            node.name
            for node in self.tree.body
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        }
        self.assertNotIn("_finalize_subjob_outputs_legacy_unused", definitions)
        self.assertNotIn("_finalize_subjob_outputs_legacy_unused", self.source)

    def test_02_legacy_only_output_pipeline_markers_are_absent(self) -> None:
        for token in (
            "stickers_error.txt",
            "Kernoutput ontbreekt:",
            "Geen DXF-zaagplaten gevonden na succesvolle optimalisatie.",
        ):
            self.assertNotIn(token, self.source)

    def test_03_active_finalization_service_remains_the_single_owner(self) -> None:
        self.assertEqual(self.source.count("_JOB_FINALIZATION_SERVICE = JobFinalizationService("), 1)
        self.assertEqual(
            self.source.count("return _JOB_FINALIZATION_SERVICE.finalize_subjob(job_root)"),
            1,
        )
        self.assertEqual(self.source.count("def _finalize_subjob_outputs(job_root: Path)"), 1)

    def test_04_optimizer_completion_still_calls_the_active_adapter_once(self) -> None:
        calls = [
            node
            for node in ast.walk(self.tree)
            if isinstance(node, ast.Call)
            and isinstance(node.func, ast.Name)
            and node.func.id == "_finalize_subjob_outputs"
        ]
        self.assertEqual(len(calls), 1)
        owner = next(
            node for node in self.tree.body
            if isinstance(node, ast.FunctionDef) and node.name == "_create_job_from_payload"
        )
        self.assertGreaterEqual(calls[0].lineno, owner.lineno)
        self.assertLessEqual(calls[0].lineno, owner.end_lineno)

    def test_05_active_finalization_owner_is_byte_exact(self) -> None:
        self.assertEqual(sha256(FINALIZATION), FINALIZATION_SHA256)
        self.assertIn("class JobFinalizationService", FINALIZATION.read_text(encoding="utf-8"))

    def test_06_server_identity_and_reduction_are_sealed(self) -> None:
        evidence = self.contract["sizeEvidence"]
        self.assertEqual(evidence["serverBefore"]["lines"], 15003)
        self.assertEqual(evidence["serverAfter"]["lines"], 14884)
        self.assertEqual(evidence["serverAfter"]["sha256"], R9J6_SERVER_SHA256)
        self.assertEqual(evidence["serverReduction"], {"bytes": 5505, "lines": 119})
        self.assertLessEqual(len(SERVER.read_bytes().splitlines()), evidence["serverAfter"]["lines"])

    def test_07_contract_is_explicitly_provisional_and_behavior_preserving(self) -> None:
        self.assertEqual(self.contract["contractId"], "R9J6_DEAD_FINALIZATION_CLEANUP")
        self.assertEqual(self.contract["status"], "PROVISIONAL_DEVELOPMENT_ONLY")
        self.assertFalse(self.contract["releaseEligible"])
        self.assertFalse(self.contract["cleanup"]["activeRuntimePathChanged"])
        self.assertEqual(self.contract["executableEvidence"]["cleanupTestCount"], 7)


if __name__ == "__main__":
    unittest.main(verbosity=2)
