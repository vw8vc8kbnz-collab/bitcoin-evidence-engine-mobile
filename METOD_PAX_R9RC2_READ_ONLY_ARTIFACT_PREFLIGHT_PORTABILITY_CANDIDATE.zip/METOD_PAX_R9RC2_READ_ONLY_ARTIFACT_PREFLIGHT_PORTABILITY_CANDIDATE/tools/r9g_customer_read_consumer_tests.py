#!/usr/bin/env python3
from __future__ import annotations

"""Fail-closed R9G-5 proof for the in-memory customer read consumer."""

import ast
import base64
import hashlib
import json
import shutil
import subprocess
import unittest
from pathlib import Path

from r9h_shell_source import read_toola_expanded


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
SELECTORS = APP / "tool-a/state/selectors.js"
STORE = APP / "tool-a/state/store.js"
MATERIALS = APP / "tool-a/steps/materials.js"
PANELS = APP / "tool-a/steps/panels.js"
GRAIN = APP / "tool-a/steps/grain.js"
CUSTOMER = APP / "tool-a/steps/customer.js"
JOBS = APP / "tool-a/api/jobs.js"
REQUESTS = APP / "tool-a/api/requests.js"
DIALOG = APP / "tool-a/components/dialog.js"
FOOTER = APP / "tool-a/components/footer.js"
GRAIN_PREVIEW = APP / "tool-a/components/grain-preview.js"
CHECKOUT_REVIEW = APP / "tool-a/components/checkout-review.js"
MATERIAL_CARD = APP / "tool-a/components/material-card.js"
PANEL_EDITOR = APP / "tool-a/components/panel-editor.js"
MOBILE_CART = APP / "tool-a/components/mobile-material-cart.js"
OVERLAY_ROUTER = APP / "tool-a/components/overlay-router.js"
PROGRESS = APP / "tool-a/components/progress-overlay.js"
THANK_YOU = APP / "tool-a/components/thank-you.js"
BOOTSTRAP = APP / "tool-a/bootstrap.js"
HTML = APP / "toolA.html"
RULES = ROOT / "R9B_ARCHITECTURE_RULES.json"


def data_url(data: bytes) -> str:
    return "data:text/javascript;base64," + base64.b64encode(data).decode()


def linked_sources() -> tuple[str, str, str]:
    selectors_url = data_url(SELECTORS.read_bytes())
    store_source = STORE.read_text(encoding="utf-8").replace("./selectors.js", selectors_url)
    store_url = data_url(store_source.encode())
    module_urls = {
        "./steps/materials.js": data_url(MATERIALS.read_bytes()),
        "./steps/panels.js": data_url(PANELS.read_bytes()),
        "./steps/grain.js": data_url(GRAIN.read_bytes()),
        "./steps/customer.js": data_url(CUSTOMER.read_bytes()),
        "./api/jobs.js": data_url(JOBS.read_bytes()),
        "./api/requests.js": data_url(REQUESTS.read_bytes()),
        "./components/dialog.js": data_url(DIALOG.read_bytes()),
        "./components/footer.js": data_url(FOOTER.read_bytes()),
        "./components/grain-preview.js": data_url(GRAIN_PREVIEW.read_bytes()),
        "./components/checkout-review.js": data_url(CHECKOUT_REVIEW.read_bytes()),
        "./components/material-card.js": data_url(MATERIAL_CARD.read_bytes()),
        "./components/panel-editor.js": data_url(PANEL_EDITOR.read_bytes()),
        "./components/mobile-material-cart.js": data_url(MOBILE_CART.read_bytes()),
        "./components/overlay-router.js": data_url(OVERLAY_ROUTER.read_bytes()),
        "./components/progress-overlay.js": data_url(PROGRESS.read_bytes()),
        "./components/thank-you.js": data_url(THANK_YOU.read_bytes()),
    }
    bootstrap_source = BOOTSTRAP.read_text(encoding="utf-8").replace("./state/store.js", store_url)
    for relative, url in module_urls.items():
        bootstrap_source = bootstrap_source.replace(relative, url)
    return selectors_url, data_url(CUSTOMER.read_bytes()), data_url(bootstrap_source.encode())


def run_node(source: str) -> dict:
    node = shutil.which("node")
    if not node:
        raise AssertionError("Node is required by the release architecture gate")
    completed = subprocess.run(
        [node, "--input-type=module"], input=source, text=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=10, check=False,
    )
    if completed.returncode != 0:
        raise AssertionError(completed.stdout)
    return json.loads(completed.stdout.strip().splitlines()[-1])


class R9GCustomerReadConsumerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.selectors_url, cls.customer_url, cls.bootstrap_url = linked_sources()

    def test_01_customer_module_is_read_only_and_has_no_io_owner(self) -> None:
        source = CUSTOMER.read_text(encoding="utf-8")
        for token in (
            "window", "globalThis", "document", "addEventListener", "fetch(",
            "localStorage", "sessionStorage", "dispatch", "subscribe", "setState",
            "XMLHttpRequest", "EventSource",
        ):
            self.assertNotIn(token.lower(), source.lower(), token)
        self.assertIn("export function selectCustomerView", source)
        self.assertIn("export function createCustomerViewConsumer", source)

    def test_02_selector_matches_the_legacy_merge_order_exactly(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(self.selectors_url)});
const snapshot=m.selectCustomerSnapshot({{
 checkout:{{
  customer:{{firstName:' Ada ',email:'first@example.test',billingAddress:'Straat 1'}},
  customerSnapshot:{{email:'final@example.test',postcode:'1234 AB',shippingSameAsBilling:false,shippingAddress:'Laan 2'}}
 }},
 lastCalculatedCustomer:{{houseNumber:'7',city:'Utrecht'}}
}},{{liveCustomer:{{lastName:'Lovelace',phone:'0612345678'}}}});
console.log(JSON.stringify({{snapshot,keys:Reflect.ownKeys(snapshot),frozen:Object.isFrozen(snapshot)}}));
""")
        self.assertEqual(result["snapshot"], {
            "firstName": "Ada", "lastName": "Lovelace", "company": "",
            "email": "final@example.test", "phone": "0612345678",
            "billingAddress": "Straat 1", "shippingAddress": "Laan 2",
            "shippingSameAsBilling": False, "postcode": "1234 AB",
            "houseNumber": "7", "address1": "Laan 2", "address2": "",
            "city": "Utrecht", "country": "",
        })
        self.assertTrue(result["frozen"])

    def test_03_public_read_model_remains_pii_free(self) -> None:
        result = run_node(f"""
globalThis.state={{checkout:{{customer:{{email:'private@example.test'}}}}}};
globalThis.__metod_uiStep='customer';
const m=await import({json.dumps(self.bootstrap_url)});
const snapshot=globalThis.ToolAR9Foundation.getSnapshot();
const customer=globalThis.ToolAR9Foundation.getCustomerView();
console.log(JSON.stringify({{snapshot,customer,snapshotFrozen:Object.isFrozen(snapshot),customerFrozen:Object.isFrozen(customer),nestedFrozen:Object.isFrozen(customer.customerSnapshot)}}));
""")
        self.assertNotIn("private@example.test", json.dumps(result["snapshot"]))
        self.assertNotIn("customer", {key.lower() for key in result["snapshot"]})
        self.assertEqual(result["customer"]["customerSnapshot"]["email"], "private@example.test")
        self.assertTrue(result["snapshotFrozen"])
        self.assertTrue(result["customerFrozen"])
        self.assertTrue(result["nestedFrozen"])

    def test_04_consumer_reads_fresh_in_memory_snapshots_without_caching(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(self.customer_url)});
let email='first@example.test';
const store={{getSnapshot:()=>({{currentStep:'customer'}}),getCustomerSnapshot:()=>({{email}})}};
const consumer=m.createCustomerViewConsumer(store);
const first=consumer.getView();email='second@example.test';const second=consumer.getView();
console.log(JSON.stringify({{first:first.customerSnapshot.email,second:second.customerSnapshot.email,separate:first!==second,keys:Reflect.ownKeys(consumer)}}));
""")
        self.assertEqual(result, {
            "first": "first@example.test", "second": "second@example.test",
            "separate": True, "keys": ["getView"],
        })

    def test_05_invalid_sources_fail_closed_and_keep_legacy_fallback_available(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(self.customer_url)});
const invalid=m.selectCustomerView(null,null);
const throwing=m.createCustomerViewConsumer({{getSnapshot:()=>{{throw new Error('boom')}},getCustomerSnapshot:()=>({{}})}}).getView();
let rejected=false;try{{m.createCustomerViewConsumer({{getSnapshot:()=>({{}})}})}}catch(_error){{rejected=true}}
console.log(JSON.stringify({{invalid,throwing,rejected,same:invalid===throwing}}));
""")
        self.assertFalse(result["invalid"]["readSucceeded"])
        self.assertFalse(result["invalid"]["hasCustomerData"])
        self.assertTrue(result["rejected"])
        self.assertTrue(result["same"])

    def test_06_bootstrap_has_one_frozen_adapter_and_no_mutation_surface(self) -> None:
        result = run_node(f"""
globalThis.state={{checkout:{{customer:{{email:'ada@example.test'}}}}}};
globalThis.__metod_uiStep='customer';
const m=await import({json.dumps(self.bootstrap_url)});
const adapter=globalThis.ToolAR9Foundation;
console.log(JSON.stringify({{
 revision:adapter.revision,mode:adapter.mode,keys:Reflect.ownKeys(adapter),
 storeKeys:Reflect.ownKeys(m.toolAStore),consumerKeys:Reflect.ownKeys(m.customerViewConsumer),
 frozen:Object.isFrozen(adapter),view:adapter.getCustomerView(),
 mutation:['dispatch','subscribe','setState','replaceState'].some(key=>key in adapter)
}}));
""")
        self.assertEqual(result["revision"], "R9I_SYNC_CATALOG_REFRESH_CLEANUP_9")
        self.assertEqual(result["mode"], "legacy-read-cleanup-adapter")
        self.assertTrue(set([
            "revision", "mode", "getSnapshot", "getMaterialsView", "getPanelsView",
            "getGrainView", "getCustomerView", "startJob", "pollJob",
            "fetchJobPricingSummary", "authoritativeTotalInclVat",
            "submitFinalConfiguration", "resetFinalSubmission", "getFinalSubmissionState",
        ]).issubset(result["keys"]))
        self.assertEqual(result["storeKeys"], [
            "getSnapshot", "getCustomerSnapshot", "normalizeCustomerSnapshot",
            "getGrainMaterialKey", "isGrainEnabledForMaterial",
            "isGrainCapableItem", "parseGrainReference",
            "getMaterialThickness", "getUsableMaterialSheetDimensions",
        ])
        self.assertEqual(result["consumerKeys"], ["getView"])
        self.assertTrue(result["frozen"])
        self.assertTrue(result["view"]["hasRequiredEmail"])
        self.assertFalse(result["mutation"])

    def test_07_price_summary_uses_customer_view_with_exact_legacy_fallback(self) -> None:
        source = read_toola_expanded(HTML)
        self.assertEqual(source.count("function r9CustomerView()"), 1)
        self.assertEqual(source.count("window.ToolAR9Foundation?.getCustomerView?.()"), 1)
        self.assertIn("customerView?.readSucceeded === true", source)
        self.assertIn("? customerView.customerSnapshot\n        : customerForCurrentCalculation();", source)

    def test_08_customer_mutation_validation_and_submit_owners_are_unchanged(self) -> None:
        expected = {
            "toolA_customer_validation.js": "b58a45b76100be0d4d0c8fac7c5bf1285dec3d31143e53469ae5bfb92f99f734",
            "toolA_panel_mutations.js": "4fd36df984c6416e0e394397ecafd53c0f20a6e432bf8330226c03ef00230356",
            "dxf_nesting_optimizer.py": "42480b301cd660dac1e5e9fec2c8d30bb5c6826c32234a9c1cce765b758bebb8",
            "pricing_helpers.py": "646c2f5186e9b080f6ba8dcf364884411c18e946254bb5c9001647f7cbb425df",
        }
        for name, digest in expected.items():
            self.assertEqual(hashlib.sha256((APP / name).read_bytes()).hexdigest(), digest, name)
        module_source = CUSTOMER.read_text(encoding="utf-8").lower()
        for owner in (
            "validatecustomer", "submitconfiguration", "jobid", "requestid",
            "persistcustomer", "savecustomer",
        ):
            self.assertNotIn(owner, module_source)

    def test_09_static_module_graph_and_html_revision_are_exact(self) -> None:
        rules = json.loads(RULES.read_text(encoding="utf-8"))["frontend"]
        self.assertTrue(set([
            "tool-a/bootstrap.js", "tool-a/api/jobs.js", "tool-a/api/requests.js", "tool-a/state/store.js", "tool-a/state/selectors.js",
            "tool-a/steps/materials.js", "tool-a/steps/panels.js", "tool-a/steps/grain.js",
            "tool-a/steps/customer.js",
        ]).issubset(rules["publicStaticFiles"]))
        self.assertEqual(rules["moduleImports"]["app/tool-a/api/jobs.js"], [])
        self.assertEqual(rules["moduleImports"]["app/tool-a/steps/customer.js"], [])
        marker = '<script type="module" src="tool-a/bootstrap.js?v=r9i-sync-catalog-refresh-cleanup-9"></script>'
        self.assertEqual(read_toola_expanded(HTML).count(marker), 1)

    def test_10_server_allowlist_and_protected_algorithms_are_exact(self) -> None:
        tree = ast.parse((APP / "metod_app/http/static.py").read_text(encoding="utf-8"))
        public_files = None
        for node in tree.body:
            if isinstance(node, ast.Assign) and any(
                isinstance(target, ast.Name) and target.id == "PUBLIC_STATIC_MODULE_FILES"
                for target in node.targets
            ):
                public_files = ast.literal_eval(node.value)
                break
        self.assertTrue({
            "tool-a/bootstrap.js", "tool-a/api/jobs.js", "tool-a/api/requests.js", "tool-a/state/store.js", "tool-a/state/selectors.js",
            "tool-a/steps/materials.js", "tool-a/steps/panels.js", "tool-a/steps/grain.js",
            "tool-a/steps/customer.js",
        }.issubset(public_files))
        for name, digest in {
            "dxf_geometry.py": "b80a2d006241908bf7b33516f7e0faf59ef61e1e08db86966b23cc5de292c1ff",
            "panel_contract.py": "e23314fd63a2358a48daa580a92cebb8a40c9862548ba0243461a59347da7fc9",
        }.items():
            self.assertEqual(hashlib.sha256((APP / name).read_bytes()).hexdigest(), digest, name)


if __name__ == "__main__":
    unittest.main(verbosity=2)
