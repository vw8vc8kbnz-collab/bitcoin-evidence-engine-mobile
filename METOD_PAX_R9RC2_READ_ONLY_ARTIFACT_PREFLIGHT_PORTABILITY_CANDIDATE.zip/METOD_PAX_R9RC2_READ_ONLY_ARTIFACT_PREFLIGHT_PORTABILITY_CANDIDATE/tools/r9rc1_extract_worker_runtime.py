#!/usr/bin/env python3
from __future__ import annotations

"""One-shot extraction of job execution and queue-worker runtime owners."""

import ast
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
APPLICATION = APP / "metod_app/runtime/application.py"
EXECUTION = APP / "metod_app/jobs/execution.py"
WORKER = APP / "metod_app/runtime/worker.py"

EXECUTION_DEPS = (
    "JOBS", "JobCancelledError", "OPTIMIZER_TOOL_B", "OptimizerDeadline",
    "PRICING_SEED_PATH", "Path", "ROOT", "SafetyContractError",
    "_JOB_FINALIZATION_SERVICE", "_OPTIMIZER_PROCESS_SUPERVISOR",
    "_atomic_write_json", "_cached_sha256_file", "_enforce_job_output_limit",
    "_ensure_pricing_materials", "_env_int", "_filter_panels_csv_by_material",
    "_finalize_subjob_outputs", "_get_python_base_cmd", "_job_cancel_requested",
    "_job_lock", "_job_meta", "_link_or_copy_file", "_load_pricing_config",
    "_now_iso", "_parse_panels_csv", "_register_job_process",
    "_terminate_optimizer_process", "_unregister_job_process", "_utc_now_iso",
    "_validated_canonical_dxf_transport", "_write_file", "_write_master_job_links",
    "_write_replaceable_json", "_write_replaceable_text", "durable_write_many_bytes",
    "fsync_directory", "json", "resolve_identifier_child", "strict_json_dumps",
    "strict_json_load", "strict_json_loads", "subprocess", "time", "uuid",
    "validate_job_id",
)

QUEUE_DEPS = {
    "process_one_queue_item": (
        "JOBS", "QUEUE_DONE", "QUEUE_FAILED", "QUEUE_PENDING", "QUEUE_PROCESSING",
        "_append_system_event", "_ensure_request_dirs", "_finalization_complete",
        "_guess_customer_name", "_linked_subjob_ids", "_load_status",
        "_move_queue_file_safe", "_safe_id", "_safe_text", "_save_status",
        "_sse_broadcast", "_state_snapshot_is_active", "strict_json_load",
    ),
    "_recover_processing_queue_items_fix657": (
        "JOBS", "QUEUE_FAILED", "QUEUE_PENDING", "QUEUE_PROCESSING",
        "_ensure_request_dirs", "_finalization_complete", "_load_status",
        "_move_queue_file_safe", "_safe_id", "_save_status", "strict_json_load",
    ),
}


def _functions(source: str) -> dict[str, ast.FunctionDef]:
    return {
        node.name: node
        for node in ast.parse(source).body
        if isinstance(node, ast.FunctionDef)
    }


def _extract(source_lines: list[str], node: ast.FunctionDef) -> str:
    return "".join(source_lines[node.lineno - 1 : node.end_lineno])


def _rename_and_inject(
    source: str,
    node: ast.FunctionDef,
    *,
    public_name: str,
    dependencies: tuple[str, ...],
    custom_bindings: tuple[str, ...] = (),
) -> str:
    original = _extract(source.splitlines(keepends=True), node)
    first_line = original.splitlines(keepends=True)[0]
    if not first_line.startswith(f"def {node.name}("):
        raise RuntimeError(f"unexpected function signature for {node.name}")
    arguments = first_line[len(f"def {node.name}(") :]
    if arguments.startswith(")"):
        replacement = f"def {public_name}(runtime{arguments}"
    else:
        replacement = f"def {public_name}(runtime, {arguments}"
    body = replacement + "".join(original.splitlines(keepends=True)[1:])

    relative_insert = 1
    if node.body and isinstance(node.body[0], ast.Expr):
        value = node.body[0].value
        if isinstance(value, ast.Constant) and isinstance(value.value, str):
            relative_insert = node.body[0].end_lineno - node.lineno + 1
    lines = body.splitlines(keepends=True)
    bindings = [f"    {name} = runtime.{name}\n" for name in dependencies]
    bindings.extend(f"    {line}\n" for line in custom_bindings)
    lines[relative_insert:relative_insert] = bindings + (["\n"] if bindings else [])
    return "".join(lines).rstrip() + "\n"


def main() -> int:
    if EXECUTION.exists() or WORKER.exists():
        raise RuntimeError("R9RC1 worker extraction has already run")
    source = APPLICATION.read_text(encoding="utf-8", errors="strict")
    nodes = _functions(source)
    required = {
        "_acquire_worker_lock", "_release_worker_lock", "_create_job_from_payload",
        "process_one_queue_item", "_recover_processing_queue_items_fix657", "worker_loop",
    }
    if not required <= set(nodes):
        raise RuntimeError(f"worker source inventory drifted: {sorted(required - set(nodes))}")

    execution_source = _rename_and_inject(
        source,
        nodes["_create_job_from_payload"],
        public_name="create_job_from_payload",
        dependencies=EXECUTION_DEPS,
    )
    execution_module = (
        "from __future__ import annotations\n\n"
        '"""Single owner for canonical job-family execution and finalization."""\n\n'
        + execution_source
    )

    acquire = _rename_and_inject(
        source, nodes["_acquire_worker_lock"], public_name="acquire_worker_lock",
        dependencies=("WORKER_LOCK", "_fcntl", "fsync_directory", "os"),
    )
    release = _rename_and_inject(
        source, nodes["_release_worker_lock"], public_name="release_worker_lock",
        dependencies=("WORKER_LOCK", "_fcntl", "fsync_directory", "os"),
    )
    process = _rename_and_inject(
        source, nodes["process_one_queue_item"], public_name="process_one_queue_item",
        dependencies=QUEUE_DEPS["process_one_queue_item"],
    )
    recover = _rename_and_inject(
        source,
        nodes["_recover_processing_queue_items_fix657"],
        public_name="recover_processing_queue_items",
        dependencies=QUEUE_DEPS["_recover_processing_queue_items_fix657"],
    )
    loop = _rename_and_inject(
        source,
        nodes["worker_loop"],
        public_name="worker_loop",
        dependencies=("run_backup_maintenance", "run_queue_maintenance", "run_retention_maintenance", "time"),
        custom_bindings=(
            "_acquire_worker_lock = lambda: acquire_worker_lock(runtime)",
            "_release_worker_lock = lambda: release_worker_lock(runtime)",
            "_recover_processing_queue_items_fix657 = lambda: recover_processing_queue_items(runtime)",
            "process_one_queue_item = lambda: globals()['process_one_queue_item'](runtime)",
        ),
    )
    worker_module = (
        "from __future__ import annotations\n\n"
        '"""Queue admission recovery, locking and long-running worker loop."""\n\n'
        "_WORKER_LOCK_FD: int | None = None\n\n"
        + acquire + "\n" + release + "\n" + process + "\n" + recover + "\n" + loop
    )

    start = source.index("# --- Queue worker (Release 1 foundation) ---")
    end = source.index("def _readiness_report()", start)
    wrappers = '''# Runtime adapters retain the established import API while concrete owners live
# in focused modules. Passing this module keeps mutable paths and test overrides
# visible at call time; no configuration or state is copied.
from metod_app.jobs import execution as _job_execution
from metod_app.runtime import worker as _queue_worker


def _acquire_worker_lock() -> bool:
    return _queue_worker.acquire_worker_lock(sys.modules[__name__])


def _release_worker_lock() -> None:
    _queue_worker.release_worker_lock(sys.modules[__name__])


def _create_job_from_payload(payload: dict, master_job_id: str | None = None,
                             public_access_token: str = '') -> dict:
    return _job_execution.create_job_from_payload(
        sys.modules[__name__], payload, master_job_id, public_access_token,
    )


def process_one_queue_item() -> bool:
    return _queue_worker.process_one_queue_item(sys.modules[__name__])


def _recover_processing_queue_items_fix657() -> dict:
    return _queue_worker.recover_processing_queue_items(sys.modules[__name__])


def worker_loop(poll_seconds: float = 1.0) -> None:
    _queue_worker.worker_loop(sys.modules[__name__], poll_seconds)


'''
    transformed = source[:start] + wrappers + source[end:]
    APPLICATION.write_text(transformed, encoding="utf-8")
    EXECUTION.write_text(execution_module, encoding="utf-8")
    WORKER.write_text(worker_module, encoding="utf-8")
    print("extracted canonical job execution and queue worker owners")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
