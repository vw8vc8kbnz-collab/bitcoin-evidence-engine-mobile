#!/usr/bin/env python3
from __future__ import annotations

"""One-shot, deterministic R9M Admin presentation split.

The source checkpoint deliberately embeds the Admin templates in ``access.py``.
This migration extracts those immutable values, replaces static style attributes
with generated utility classes, and writes reviewable template/CSS/JS assets.
"""

import ast
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ADMIN = ROOT / "app/metod_app/admin"
ACCESS = ADMIN / "access.py"
TEMPLATES = ADMIN / "templates"
ASSETS = ADMIN / "assets"


def _constants(source: str) -> tuple[dict[str, str], dict[str, ast.Assign]]:
    values: dict[str, str] = {}
    nodes: dict[str, ast.Assign] = {}
    for node in ast.parse(source).body:
        if not isinstance(node, ast.Assign) or len(node.targets) != 1:
            continue
        target = node.targets[0]
        if not isinstance(target, ast.Name) or target.id not in {"ADMIN_HTML", "ADMIN_LOGIN_HTML"}:
            continue
        value = ast.literal_eval(node.value)
        if not isinstance(value, str):
            raise TypeError(f"{target.id} must be a string")
        values[target.id] = value
        nodes[target.id] = node
    if set(values) != {"ADMIN_HTML", "ADMIN_LOGIN_HTML"}:
        raise RuntimeError("embedded Admin presentations are incomplete")
    return values, nodes


def _extract_single(html: str, tag: str) -> tuple[str, str]:
    matches = list(re.finditer(rf"<{tag}[^>]*>(.*?)</{tag}>", html, re.I | re.S))
    if len(matches) != 1:
        raise RuntimeError(f"expected exactly one {tag} block, found {len(matches)}")
    match = matches[0]
    return match.group(1), html[: match.start()] + html[match.end() :]


def _extract_scripts(html: str) -> tuple[list[str], str]:
    matches = list(re.finditer(r"<script[^>]*>(.*?)</script>", html, re.I | re.S))
    scripts = [match.group(1) for match in matches]
    for match in reversed(matches):
        html = html[: match.start()] + f"@@R9M_SCRIPT_{matches.index(match)}@@" + html[match.end() :]
    return scripts, html


def _replace_dynamic_styles(html: str) -> str:
    old_tone = """function _systemTone(it){
  return (it.level === 'error') ? 'rgba(255,107,107,.14)' : (it.level === 'warning' ? 'rgba(255,196,87,.12)' : 'rgba(47,191,106,.08)');
}"""
    new_tone = """function _systemToneClass(it){
  return (it.level === 'error') ? 'systemToneError' : (it.level === 'warning' ? 'systemToneWarning' : 'systemToneInfo');
}"""
    if html.count(old_tone) != 1:
        raise RuntimeError("system tone implementation drifted")
    html = html.replace(old_tone, new_tone)
    replacements = {
        'class="card systemLogItem" style="padding:0; border-color:rgba(255,255,255,.08); background:${_systemTone(it)}; overflow:hidden;"':
            'class="card systemLogItem ${_systemToneClass(it)}" style="padding:0; border-color:rgba(255,255,255,.08); overflow:hidden;"',
        'class="card" style="padding:12px 14px; background:${_systemTone(it)}; display:grid; gap:5px;"':
            'class="card ${_systemToneClass(it)}" style="padding:12px 14px; display:grid; gap:5px;"',
        '<div style="height:100%;width:${pct}%;background:currentColor;opacity:.55;"></div>':
            '<div class="catalogProgressValue" data-progress-pct="${pct}"></div>',
    }
    for old, new in replacements.items():
        if html.count(old) != 1:
            raise RuntimeError(f"dynamic style contract drifted: {old[:70]}")
        html = html.replace(old, new)
    anchor = """  el.innerHTML=`<div style="display:flex;justify-content:space-between;gap:10px;align-items:center;"><strong>Afbeeldingen voorbereiden vóór publicatie</strong><span>${pct}%</span></div><div style="height:7px;border-radius:99px;background:rgba(255,255,255,.08);overflow:hidden;margin-top:8px;"><div class="catalogProgressValue" data-progress-pct="${pct}"></div></div><div class="muted" style="font-size:11px;margin-top:7px;">${processed} / ${total} verwerkt · ${ok} gelukt · ${failed} mislukt${done?' · klaar':''}</div>${publicationGate}${failed&&done?`<button class="btn secondary" type="button" id="matCsvRetryImagesBtn" style="margin-top:9px;">Afbeeldingen opnieuw proberen</button>`:''}`;
"""
    replacement = anchor + """  const progressValue=el.querySelector('.catalogProgressValue');
  if(progressValue) progressValue.style.width=`${pct}%`;
"""
    if html.count(anchor) != 1:
        raise RuntimeError("catalog progress render contract drifted")
    return html.replace(anchor, replacement)


def _externalize_style_attributes(html: str) -> tuple[str, list[tuple[str, str]]]:
    style_to_class: dict[str, str] = {}
    ordered: list[tuple[str, str]] = []
    pattern = re.compile(r'(<[A-Za-z][^<>]*?)\sstyle="([^"]*)"([^<>]*>)')

    def replace(match: re.Match[str]) -> str:
        prefix, declarations, suffix = match.groups()
        if "${" in declarations:
            raise RuntimeError(f"unhandled dynamic style: {declarations}")
        class_name = style_to_class.get(declarations)
        if class_name is None:
            class_name = f"admin-u-{len(style_to_class) + 1:03d}"
            style_to_class[declarations] = class_name
            ordered.append((class_name, declarations))
        class_match = re.search(r'\bclass="([^"]*)"', prefix)
        if class_match:
            existing = class_match.group(1)
            prefix = prefix[: class_match.start(1)] + f"{existing} {class_name}" + prefix[class_match.end(1) :]
        else:
            prefix += f' class="{class_name}"'
        return prefix + suffix

    transformed = pattern.sub(replace, html)
    if re.search(r"\sstyle\s*=", transformed, re.I):
        raise RuntimeError("style attributes remain after migration")
    return transformed, ordered


def _utility_css(entries: list[tuple[str, str]]) -> str:
    lines = [
        "/* R9M exact-declaration utilities generated from the reviewed embedded template. */",
        ".systemToneError{background:rgba(255,107,107,.14)}",
        ".systemToneWarning{background:rgba(255,196,87,.12)}",
        ".systemToneInfo{background:rgba(47,191,106,.08)}",
        ".catalogProgressValue{height:100%;width:0;background:currentColor;opacity:.55}",
    ]
    lines.extend(f".{class_name}{{{declarations}}}" for class_name, declarations in entries)
    return "\n".join(lines) + "\n"


def _write_assets(main_html: str, login_html: str) -> None:
    main_html = _replace_dynamic_styles(main_html)
    main_html, utilities = _externalize_style_attributes(main_html)
    main_css, main_html = _extract_single(main_html, "style")
    main_scripts, main_html = _extract_scripts(main_html)
    if len(main_scripts) != 2:
        raise RuntimeError(f"expected two Admin scripts, found {len(main_scripts)}")

    login_html, login_utilities = _externalize_style_attributes(login_html)
    if login_utilities:
        raise RuntimeError("login template unexpectedly has style attributes")
    login_css, login_html = _extract_single(login_html, "style")
    login_scripts, login_html = _extract_scripts(login_html)
    if len(login_scripts) != 1:
        raise RuntimeError(f"expected one login script, found {len(login_scripts)}")

    main_html = main_html.replace(
        "</title>", '</title>\n<link rel="stylesheet" href="/admin/assets/admin.css">', 1
    )
    main_html = main_html.replace("@@R9M_SCRIPT_0@@", '<script src="/admin/assets/dxf.js"></script>')
    main_html = main_html.replace("@@R9M_SCRIPT_1@@", '<script src="/admin/assets/admin.js"></script>')
    login_html = login_html.replace(
        "</title>", '</title>\n<link rel="stylesheet" href="/admin/assets/login.css">', 1
    )
    login_html = login_html.replace("@@R9M_SCRIPT_0@@", '<script src="/admin/assets/login.js"></script>')

    TEMPLATES.mkdir(parents=True, exist_ok=True)
    ASSETS.mkdir(parents=True, exist_ok=True)
    (TEMPLATES / "admin.html").write_text(main_html, encoding="utf-8")
    (TEMPLATES / "login.html").write_text(login_html, encoding="utf-8")
    (ASSETS / "admin.css").write_text(main_css + "\n" + _utility_css(utilities), encoding="utf-8")
    (ASSETS / "dxf.js").write_text(main_scripts[0], encoding="utf-8")
    (ASSETS / "admin.js").write_text(main_scripts[1], encoding="utf-8")
    (ASSETS / "login.css").write_text(login_css, encoding="utf-8")
    (ASSETS / "login.js").write_text(login_scripts[0], encoding="utf-8")


def _remove_constants(source: str, nodes: dict[str, ast.Assign]) -> str:
    lines = source.splitlines(keepends=True)
    for name in ("ADMIN_LOGIN_HTML", "ADMIN_HTML"):
        node = nodes[name]
        del lines[node.lineno - 1 : node.end_lineno]
    source = "".join(lines)
    import_anchor = "from typing import Any, Callable, Mapping\n"
    presentation_import = "\nfrom .presentation import ADMIN_HTML, ADMIN_LOGIN_HTML\n"
    if source.count(import_anchor) != 1:
        raise RuntimeError("access import anchor drifted")
    source = source.replace(import_anchor, import_anchor + presentation_import, 1)
    source = source.replace(
        "R9L1 moves ownership without changing Admin HTML, response bodies, status codes,\n"
        "security headers, cookie attributes, CSRF handling or development-only Basic\n"
        "authentication compatibility. Frontend asset splitting remains R9M scope.",
        "R9M keeps this module focused on authentication and sessions. Presentation\n"
        "templates and same-origin assets are owned by ``admin.presentation`` without\n"
        "changing cookie, CSRF or development-only Basic-authentication contracts.",
        1,
    )
    return source


def main() -> int:
    source = ACCESS.read_text(encoding="utf-8", errors="strict")
    values, nodes = _constants(source)
    _write_assets(values["ADMIN_HTML"], values["ADMIN_LOGIN_HTML"])
    ACCESS.write_text(_remove_constants(source, nodes), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
