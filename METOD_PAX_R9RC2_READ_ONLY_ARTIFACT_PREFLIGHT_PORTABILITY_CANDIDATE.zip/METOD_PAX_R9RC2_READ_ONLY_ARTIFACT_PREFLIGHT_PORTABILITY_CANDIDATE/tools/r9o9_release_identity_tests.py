#!/usr/bin/env python3
from __future__ import annotations

import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path


RELEASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RELEASE / "tools"))

from r9o9_release_identity_gate import ARTIFACT, ARTIFACT_ROOT, BUILD, REVISION, audit_release  # noqa: E402


class R9O9ReleaseIdentityTests(unittest.TestCase):
    def test_current_release_identity_passes(self) -> None:
        self.assertEqual(audit_release(RELEASE), [])

    def test_expected_identity_is_exact(self) -> None:
        self.assertEqual(REVISION, "R9O9")
        self.assertEqual(BUILD, "R9O9_EXTERNAL_AUDIT_SECURITY_PRIVACY_REMEDIATION")
        self.assertEqual(ARTIFACT, f"METOD_PAX_{BUILD}_CANDIDATE.zip")
        self.assertEqual(ARTIFACT_ROOT, f"METOD_PAX_{BUILD}_CANDIDATE")

    def test_identity_gate_fails_closed_on_release_eligibility(self) -> None:
        with tempfile.TemporaryDirectory(prefix="r9o9-identity-") as temp_name:
            temporary = Path(temp_name) / "release"
            shutil.copytree(RELEASE, temporary)
            path = temporary / "RELEASE_IDENTITY.json"
            identity = json.loads(path.read_text(encoding="utf-8"))
            identity["canonicalCandidate"]["releaseEligible"] = True
            path.write_text(json.dumps(identity), encoding="utf-8")
            self.assertIn("release-must-remain-ineligible", audit_release(temporary))


if __name__ == "__main__":
    unittest.main(verbosity=2)
