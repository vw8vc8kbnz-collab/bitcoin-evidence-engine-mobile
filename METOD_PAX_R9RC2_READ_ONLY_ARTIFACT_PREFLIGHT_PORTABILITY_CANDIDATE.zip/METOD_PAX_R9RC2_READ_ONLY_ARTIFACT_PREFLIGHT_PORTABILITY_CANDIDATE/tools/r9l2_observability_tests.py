#!/usr/bin/env python3
from __future__ import annotations

"""Executable ownership and behavior contracts for R9L2 observability."""

import ast
import hashlib
import json
import os
import sys
import tempfile
import unittest
from dataclasses import replace
from pathlib import Path
from unittest import mock


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
SERVER = APP / "server_py.py"
OWNER = APP / "metod_app/observability/service.py"
LIFECYCLE_OWNER = APP / "metod_app/jobs/lifecycle.py"
INIT = APP / "metod_app/observability/__init__.py"
FIXTURE = ROOT / "R9L2_OBSERVABILITY_METRICS_BEFORE_FIXTURE.json"
SCOPE = ROOT / "R9L2_OBSERVABILITY_METRICS_EXTRACTION_SCOPE.json"
CONTRACT = ROOT / "R9L2_OBSERVABILITY_METRICS_EXTRACTION.json"
_STATE_TEMP = tempfile.TemporaryDirectory(prefix="r9l2_observability_tests_")
os.environ.setdefault("METOD_STATE_ROOT", str(Path(_STATE_TEMP.name) / "state"))
os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")
sys.path.insert(0, str(APP))
sys.path.insert(0, str(ROOT / "tools"))

import server_py as server  # noqa: E402
from metod_app.observability import ObservabilityService  # noqa: E402
from r9l2_observability_before_gate import _behavior, _route_projection  # noqa: E402


ADAPTERS = {
    "_append_system_event",
    "_read_system_events",
    "_readiness_report",
    "_prometheus_metrics",
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


class R9L2ObservabilityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.fixture = json.loads(FIXTURE.read_text(encoding="utf-8"))
        cls.scope = json.loads(SCOPE.read_text(encoding="utf-8"))
        cls.contract = json.loads(CONTRACT.read_text(encoding="utf-8"))
        cls.server_source = SERVER.read_text(encoding="utf-8", errors="strict")
        cls.owner_source = OWNER.read_text(encoding="utf-8", errors="strict")
        cls.lifecycle_owner_source = LIFECYCLE_OWNER.read_text(encoding="utf-8", errors="strict")
        cls.server_tree = ast.parse(cls.server_source)
        cls.owner_tree = ast.parse(cls.owner_source)
        cls.server_functions = {
            node.name: node
            for node in cls.server_tree.body
            if isinstance(node, ast.FunctionDef)
        }

    def server_function_source(self, name: str) -> str:
        source = ast.get_source_segment(self.server_source, self.server_functions[name])
        self.assertIsNotNone(source)
        return str(source)

    def test_01_fixture_seals_exact_r9l1_source_before_extraction(self) -> None:
        self.assertEqual(self.fixture["sourceCheckpoint"], "R9L1")
        self.assertEqual(
            self.fixture["sourceCommit"],
            "c81cb3b4e5c233f19eaf3177beb069430dc7efbb",
        )
        self.assertEqual(self.fixture["server"], {
            "bytes": 529902,
            "lines": 11612,
            "sha256": "f6569429c804764200e0dbc6ee9840c69eb5538e2a3531b34a2870ab607375f4",
        })
        self.assertEqual(set(self.fixture["activeOwnerSource"]), ADAPTERS)

    def test_02_one_observability_module_owns_all_four_behaviors(self) -> None:
        classes = {
            node.name for node in self.owner_tree.body if isinstance(node, ast.ClassDef)
        }
        self.assertEqual(
            classes,
            {"ObservabilityPaths", "ObservabilityDependencies", "ObservabilityService"},
        )
        service = next(
            node for node in self.owner_tree.body
            if isinstance(node, ast.ClassDef) and node.name == "ObservabilityService"
        )
        methods = {
            node.name for node in service.body if isinstance(node, ast.FunctionDef)
        }
        self.assertTrue({
            "append_system_event",
            "read_system_events",
            "readiness_report",
            "prometheus_metrics",
        }.issubset(methods))
        self.assertTrue(INIT.is_file())

    def test_03_owner_has_no_server_lock_or_transport_imports(self) -> None:
        imports = set()
        for node in ast.walk(self.owner_tree):
            if isinstance(node, ast.Import):
                imports.update(alias.name.split(".")[0] for alias in node.names)
            elif isinstance(node, ast.ImportFrom) and node.module:
                imports.add(node.module.split(".")[0])
        self.assertTrue({"http", "server_py", "socket", "subprocess", "threading"}.isdisjoint(imports))
        self.assertNotIn("Handler", self.owner_source)
        self.assertNotIn("SimpleHTTPRequestHandler", self.owner_source)

    def test_04_server_retains_only_narrow_behavior_and_counter_adapters(self) -> None:
        for name in ADAPTERS:
            source = self.server_function_source(name)
            self.assertIn("_OBSERVABILITY", source, name)
            self.assertLessEqual(len(source.splitlines()), 8, name)
        self.assertNotIn("checks['catalog'] =", self.server_source)
        self.assertNotIn("'metod_sse_clients': sse_clients", self.server_source)
        self.assertIn("_OBSERVABILITY = ObservabilityService(", self.server_source)
        self.assertLessEqual(
            len(self.server_function_source("_observability_sse_client_count").splitlines()),
            3,
        )
        self.assertLessEqual(
            len(self.server_function_source("_observability_public_job_snapshot").splitlines()),
            9,
        )

    def test_05_all_sealed_behavior_scenarios_are_byte_exact(self) -> None:
        actual = _behavior()
        for key, value in actual.items():
            self.assertEqual(value, self.fixture[key], key)
        self.assertEqual(_route_projection(), self.fixture["routeProjection"])

    def test_06_event_failures_remain_non_recursive_and_fail_silent(self) -> None:
        def explode(*_args, **_kwargs):
            raise OSError("sealed failure")

        dependencies = replace(
            server._OBSERVABILITY.dependencies,
            append_jsonl_rotating=explode,
        )
        service = ObservabilityService(dependencies)
        self.assertIsNone(
            service.append_system_event(
                message_user="must not escape",
                message_tech="Authorization: Bearer NEVER_PERSIST",
            )
        )

    def test_07_event_schema_and_redaction_never_persist_customer_or_secrets(self) -> None:
        event = self.fixture["systemEventScenario"][0]
        self.assertEqual(list(event), [
            "ts", "level", "component", "messageUser", "messageTech",
            "requestId", "jobId", "customerName", "status", "details",
        ])
        encoded = json.dumps(event, sort_keys=True)
        self.assertEqual(event["customerName"], "")
        self.assertNotIn("TOP_SECRET", encoded)
        self.assertNotIn("ALSO_SECRET", encoded)
        self.assertIn("[redacted", encoded)

    def test_08_readiness_status_checks_and_signoff_are_unchanged(self) -> None:
        ok_payload, ok_status = self.fixture["readinessOk"]
        bad_payload, bad_status = self.fixture["readinessCatalogFailure"]
        prod_payload, prod_status = self.fixture["readinessProductionSignoff"]
        self.assertEqual(ok_status, 200)
        self.assertTrue(ok_payload["ok"])
        self.assertEqual(bad_status, 503)
        self.assertFalse(bad_payload["checks"]["catalog"])
        self.assertEqual(prod_status, 200)
        self.assertTrue(prod_payload["checks"]["catalogSignoff"])
        self.assertEqual(prod_payload["details"]["catalogSignoffActor"], "auditor")

    def test_09_prometheus_names_order_type_and_values_are_unchanged(self) -> None:
        text = self.fixture["prometheusText"]
        samples = [line for line in text.splitlines() if not line.startswith("#")]
        types = [line for line in text.splitlines() if line.startswith("# TYPE")]
        self.assertEqual(len(samples), 11)
        self.assertEqual(len(types), 11)
        self.assertEqual(samples[0], "metod_sse_clients 2")
        self.assertEqual(samples[-1], "metod_state_free_bytes 5368709120")
        self.assertTrue(all(line.endswith(" gauge") for line in types))

    def test_10_route_privacy_and_auth_dispatch_order_remain_explicit(self) -> None:
        projection = self.fixture["routeProjection"]
        self.assertEqual(projection["publicReadyKeys"], ["build", "ok"])
        self.assertFalse(projection["publicReadyDisclosesChecks"])
        auth = "if parsed.path.startswith('/api/admin/'):"
        for route in (
            "route_key == 'GET /api/admin/health/ready'",
            "route_key == 'GET /api/admin/metrics'",
            "route_key == 'GET /api/admin/system/logs'",
        ):
            self.assertLess(self.server_source.index(auth), self.server_source.index(route))

    def test_11_consumer_counts_and_exclusive_scope_are_preserved(self) -> None:
        for name, expected in self.fixture["activeCallCountsExcludingDefinition"].items():
            actual = self.server_source.count(f"{name}(") - 1
            if name == "_append_system_event":
                # R9L5 moved two job-lifecycle consumers and added one explicit
                # composition-root forwarding adapter; the adapter is ownership
                # wiring, not a second behavior consumer.
                actual += self.lifecycle_owner_source.count(f"{name}(") - 1
            self.assertEqual(actual, expected, name)
        self.assertEqual(
            self.scope["contractId"],
            "R9L2_OBSERVABILITY_METRICS_EXTRACTION_SCOPE",
        )
        self.assertEqual(len(self.scope["sealedRoutes"]), 5)
        self.assertIn("R9M HTML, CSS or JavaScript splitting", self.scope["excluded"])
        self.assertNotIn("pricing behavior", self.owner_source)

    def test_12_checkpoint_is_provisional_and_next_scope_is_exclusive(self) -> None:
        self.assertEqual(
            self.contract["contractId"],
            "R9L2_OBSERVABILITY_METRICS_EXTRACTION",
        )
        self.assertEqual(self.contract["status"], "PROVISIONAL_DEVELOPMENT_ONLY")
        self.assertFalse(self.contract["releaseEligible"])
        self.assertFalse(self.contract["externalEvidence"]["productionGo"])
        self.assertEqual(
            self.contract["nextExclusiveCheckpoint"],
            "R9L3_REQUEST_DOWNLOAD_PROJECTIONS_EXTRACTION",
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
