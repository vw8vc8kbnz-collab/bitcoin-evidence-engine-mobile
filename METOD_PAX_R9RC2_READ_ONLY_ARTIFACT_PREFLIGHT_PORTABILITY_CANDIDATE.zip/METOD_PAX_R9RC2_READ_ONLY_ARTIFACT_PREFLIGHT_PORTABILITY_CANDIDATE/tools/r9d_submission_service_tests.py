#!/usr/bin/env python3
from __future__ import annotations

"""Behavior, durability order and ownership proof for R9D submission."""

import ast
import hashlib
import json
import os
import sys
import tempfile
import threading
import unittest
from pathlib import Path


RELEASE = Path(__file__).resolve().parents[1]
APP = RELEASE / "app"
SERVER = APP / "server_py.py"
SUBMISSION_SOURCE = APP / "metod_app/requests/submission.py"
sys.path.insert(0, str(APP))

from metod_app.requests.submission import (  # noqa: E402
    SubmissionClaimRepository,
    SubmissionService,
)


class FakeClaims:
    def __init__(self, *, claimed: bool = True, request_id: str = "REQ_001", events=None) -> None:
        self.claimed = claimed
        self.request_id = request_id
        self.events = events if events is not None else []

    def reserve_claim(self, parent_job_id: str, request_id: str) -> tuple[bool, str]:
        self.events.append(("claim", parent_job_id, request_id))
        return self.claimed, self.request_id if not self.claimed else request_id


class SubmissionFixture(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory(prefix="r9d-submission-")
        self.root = Path(self.temporary.name)
        self.events: list[tuple] = []
        self.saved: dict[str, dict] = {}
        self.claims = FakeClaims(events=self.events)
        self.lock = threading.Lock()
        self.linked = ["JOB_PARENT__mat_1"]
        self.pricing = {"totalInclVat": 121.0, "source": "calculation-summary"}
        self.existing_status: dict | None = None
        self.status_exists = False
        self.service = self.make_service()

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def make_service(self) -> SubmissionService:
        return SubmissionService(
            claims=self.claims,
            claim_lock=lambda: self.lock,
            read_json=lambda path: {
                "customer": {
                    "firstName": "Stored", "lastName": "Customer",
                    "email": "stored@example.invalid", "phone": "0123",
                    "billingAddress": "Stored street", "houseNumber": "10",
                    "postalCode": "1234 AB", "city": "Utrecht",
                }
            },
            email_is_valid=lambda value: value.endswith("@example.invalid"),
            linked_subjob_ids=lambda parent: list(self.linked),
            resolve_job_root=lambda job_id: self.root / "jobs" / job_id,
            finalization_complete=lambda root: True,
            pricing_summary=lambda job_ids: dict(self.pricing),
            new_request_id=lambda: "REQ_001",
            new_cancel_token=lambda: "cancel-token",
            resolve_request_root=lambda request_id: self.root / "requests" / request_id,
            atomic_write_json=self.write_payload,
            utc_now_iso=lambda: "2026-08-20T15:00:00+00:00",
            extract_summary=lambda payload: {"customerEmail": payload["customer"]["email"]},
            save_status=self.save_status,
            load_status=lambda request_id: self.existing_status,
            request_status_exists=lambda request_id: self.status_exists,
            safe_identifier=lambda value, max_len: str(value or "")[:max_len],
            notify_submitted=self.notify,
            broadcast=lambda event, payload: self.events.append(("broadcast", event, payload)),
        )

    def write_payload(self, path: Path, payload: dict) -> None:
        self.events.append(("payload", path.name))
        path.write_text(json.dumps(payload, sort_keys=True), encoding="utf-8")

    def save_status(self, request_id: str, status: dict) -> None:
        self.events.append(("status", request_id))
        self.saved[request_id] = json.loads(json.dumps(status))

    def notify(self, request_id: str, payload: dict, **kwargs):
        self.events.append(("notify", request_id))
        return True, ""


class R9DSubmissionClaimTests(unittest.TestCase):
    def test_01_claim_path_payload_mode_and_duplicate_are_exact(self) -> None:
        with tempfile.TemporaryDirectory(prefix="r9d-claim-") as name:
            root = Path(name)
            markers, requests = root / "markers", root / "requests"
            repository = SubmissionClaimRepository(
                marker_root=lambda: markers,
                requests_root=lambda: requests,
                utc_now_iso=lambda: "created",
                wall_time=lambda: 1000.0,
            )
            expected_name = hashlib.sha256(b"JOB_PARENT").hexdigest() + ".json"
            self.assertEqual(repository.marker_path("JOB_PARENT").name, expected_name)
            self.assertEqual(repository.reserve_claim("JOB_PARENT", "REQ_001"), (True, "REQ_001"))
            marker = repository.marker_path("JOB_PARENT")
            self.assertEqual(os.stat(marker).st_mode & 0o777, 0o600)
            self.assertEqual(json.loads(marker.read_text()), {
                "schemaVersion": 1, "parentJobId": "JOB_PARENT",
                "requestId": "REQ_001", "createdAt": "created",
            })
            self.assertEqual(repository.reserve_claim("JOB_PARENT", "REQ_002"), (False, "REQ_001"))

    def test_02_persisted_claim_survives_and_stale_incomplete_claim_is_reclaimed(self) -> None:
        with tempfile.TemporaryDirectory(prefix="r9d-claim-stale-") as name:
            root = Path(name)
            now = 10_000.0
            repository = SubmissionClaimRepository(
                marker_root=lambda: root / "markers",
                requests_root=lambda: root / "requests",
                utc_now_iso=lambda: "created",
                wall_time=lambda: now,
            )
            repository.reserve_claim("JOB_PARENT", "REQ_001")
            status = root / "requests/REQ_001/status.json"
            status.parent.mkdir(parents=True)
            status.write_text("{}", encoding="utf-8")
            self.assertEqual(repository.read_claim("JOB_PARENT"), "REQ_001")
            status.unlink()
            marker = repository.marker_path("JOB_PARENT")
            os.utime(marker, (now - 301, now - 301))
            self.assertEqual(repository.read_claim("JOB_PARENT"), "")
            self.assertFalse(marker.exists())


class R9DSubmissionServiceTests(SubmissionFixture):
    def test_03_missing_and_invalid_email_fail_before_claim_or_write(self) -> None:
        service = self.make_service()
        service._read_json = lambda path: {"customer": {}}
        self.assertEqual(service.finalize("JOB_PARENT", self.root, {"customer": {}}).kind, "missing_email")
        service._read_json = lambda path: {"customer": {"email": "invalid"}}
        self.assertEqual(service.finalize("JOB_PARENT", self.root, {"customer": {}}).kind, "invalid_email")
        self.assertEqual(self.events, [])

    def test_04_incomplete_family_and_missing_server_price_fail_before_claim(self) -> None:
        self.linked = []
        self.assertEqual(
            self.service.finalize("JOB_PARENT", self.root, {"customer": {}}).kind,
            "incomplete_output",
        )
        self.linked = ["JOB_PARENT__mat_1"]
        self.pricing = {"totalInclVat": 0}
        self.assertEqual(
            self.service.finalize("JOB_PARENT", self.root, {"customer": {}}).kind,
            "missing_price",
        )
        self.assertEqual(self.events, [])

    def test_05_created_request_preserves_customer_status_response_and_durable_order(self) -> None:
        payload = {
            "customer": {"firstName": "Browser", "email": "new@example.invalid"},
            "note": "Exact note",
        }
        outcome = self.service.finalize("JOB_PARENT", self.root / "parent", payload)
        self.assertEqual(outcome.kind, "created")
        self.assertEqual(outcome.response, {
            "ok": True, "requestId": "REQ_001", "cancelToken": "cancel-token",
            "notificationQueued": True, "createdAt": "2026-08-20T15:00:00+00:00",
            "pricingSummary": self.pricing,
        })
        status = self.saved["REQ_001"]
        self.assertEqual(status["customer"]["firstName"], "Browser")
        self.assertEqual(status["customer"]["lastName"], "Customer")
        self.assertEqual(status["customer"]["email"], "new@example.invalid")
        self.assertEqual(status["customer"]["billingAddress"], "Stored street")
        self.assertEqual(status["customer"]["note"], "Exact note")
        self.assertEqual(status["job"], {
            "parentJobId": "JOB_PARENT", "subjobs": ["JOB_PARENT__mat_1"],
        })
        self.assertEqual(status["publicStatus"], "SUBMITTED")
        self.assertEqual(status["internalStatus"], "DONE")
        self.assertEqual(status["source"], "submit-config-link")
        self.assertEqual([event[0] for event in self.events], [
            "claim", "payload", "status", "notify", "broadcast",
        ])

    def test_06_duplicate_returns_exact_existing_contract_and_never_writes(self) -> None:
        self.claims.claimed = False
        self.claims.request_id = "REQ_EXISTING"
        self.status_exists = True
        self.existing_status = {
            "createdAt": "original", "cancelControl": {"cancelToken": "existing-token"},
        }
        outcome = self.service.finalize("JOB_PARENT", self.root, {"customer": {}})
        self.assertEqual(outcome.kind, "duplicate")
        self.assertEqual(outcome.response, {
            "ok": True, "duplicate": True, "requestId": "REQ_EXISTING",
            "cancelToken": "existing-token", "createdAt": "original",
            "pricingSummary": self.pricing,
        })
        self.assertEqual([event[0] for event in self.events], ["claim"])

    def test_07_unresolved_concurrent_claim_fails_closed_without_write(self) -> None:
        self.claims.claimed = False
        self.claims.request_id = ""
        outcome = self.service.finalize("JOB_PARENT", self.root, {"customer": {}})
        self.assertEqual(outcome.kind, "in_progress")
        self.assertEqual([event[0] for event in self.events], ["claim"])

    def test_08_notification_failure_is_nonfatal_and_broadcast_remains_after_status(self) -> None:
        self.service._notify_submitted = lambda *args, **kwargs: (_ for _ in ()).throw(RuntimeError("offline"))
        outcome = self.service.finalize("JOB_PARENT", self.root, {"customer": {}})
        self.assertEqual(outcome.kind, "created")
        self.assertFalse(outcome.response["notificationQueued"])
        self.assertEqual([event[0] for event in self.events], [
            "claim", "payload", "status", "broadcast",
        ])


class R9DSubmissionOwnershipTests(unittest.TestCase):
    def test_09_handler_keeps_http_security_and_service_owns_no_http_or_optimizer(self) -> None:
        server_source = SERVER.read_text(encoding="utf-8")
        server_tree = ast.parse(server_source)
        top_definitions = {
            node.name for node in server_tree.body if isinstance(node, ast.FunctionDef)
        }
        self.assertFalse(top_definitions & {
            "_submission_marker_path", "_read_submission_claim",
            "_reserve_submission_claim", "_submission_response_for_existing",
        })
        self.assertEqual(server_source.count("_SUBMISSION_CLAIMS = SubmissionClaimRepository("), 1)
        self.assertEqual(server_source.count("_SUBMISSION_SERVICE = SubmissionService("), 1)
        handler = next(
            node for node in ast.walk(server_tree)
            if isinstance(node, ast.FunctionDef) and node.name == "_api_submit_config"
        )
        handler_source = ast.get_source_segment(server_source, handler) or ""
        for required in (
            "_rate_limit_allow('submit_config'", "_read_json_body_limited(",
            "_validate_submit_payload(", "_finalization_complete(parent_root)",
            "self._require_job_access(parent_job_id",
            "_SUBMISSION_SERVICE.finalize(parent_job_id, parent_root, payload)",
        ):
            self.assertIn(required, handler_source)

        source = SUBMISSION_SOURCE.read_text(encoding="utf-8")
        tree = ast.parse(source)
        imports = {
            alias.name.split(".", 1)[0]
            for node in ast.walk(tree) if isinstance(node, ast.Import)
            for alias in node.names
        }
        imports.update(
            node.module.split(".", 1)[0]
            for node in ast.walk(tree)
            if isinstance(node, ast.ImportFrom) and node.module
        )
        self.assertFalse(imports & {"server_py", "http", "socket", "subprocess", "threading"})
        for forbidden in (
            "dxf_nesting_optimizer",
            "_run_optimizer",
            "_create_job_from_payload",
            "process_one_queue_item",
        ):
            self.assertNotIn(forbidden, source)
        self.assertNotIn("status_code", source)


if __name__ == "__main__":
    unittest.main(verbosity=2)
