#!/usr/bin/env python3
from __future__ import annotations

"""Move runtime-created style elements into the deterministic Tool A cascade."""

import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
PROGRESS = APP / "tool-a/components/progress-overlay.js"
DECOR = APP / "decor_library.js"
OVERVIEW = APP / "toolA_overview_fix655.js"
OUTPUT = APP / "tool-a/styles/runtime-components.css"


def _one(pattern: str, source: str, label: str) -> re.Match[str]:
    matches = list(re.finditer(pattern, source, flags=re.DOTALL))
    if len(matches) != 1:
        raise RuntimeError(f"{label} owner drifted: expected one match, found {len(matches)}")
    return matches[0]


def main() -> int:
    if OUTPUT.exists():
        raise RuntimeError("R9RC1 dynamic style extraction has already run")

    progress = PROGRESS.read_text(encoding="utf-8", errors="strict")
    progress_style = _one(
        r"export const PROGRESS_OVERLAY_STYLE_TEXT = `(?P<css>[\s\S]*?)`;\n\n",
        progress,
        "progress style",
    )
    progress_css = progress_style.group("css")
    progress = progress[:progress_style.start()] + progress[progress_style.end():]
    ensure_progress = _one(
        r"\n  function ensureMetodProgressOverlayStyles\(\) \{[\s\S]*?\n  \}\n",
        progress,
        "progress style installer",
    )
    progress = progress[:ensure_progress.start()] + "\n" + progress[ensure_progress.end():]
    if progress.count("      ensureMetodProgressOverlayStyles();") != 1:
        raise RuntimeError("progress style call drifted")
    progress = progress.replace("      ensureMetodProgressOverlayStyles();\n", "", 1)

    decor = DECOR.read_text(encoding="utf-8", errors="strict")
    decor_style = _one(
        r"  function ensureStyle\(\)\{[\s\S]*?style\.textContent = `(?P<css>[\s\S]*?)`;\n"
        r"    document\.head\.appendChild\(style\);\n  \}",
        decor,
        "decor style installer",
    )
    decor_css = decor_style.group("css")
    decor = decor[:decor_style.start()] + "  function ensureStyle(){ return true; }" + decor[decor_style.end():]

    overview = OVERVIEW.read_text(encoding="utf-8", errors="strict")
    overview_style = _one(
        r"\n  const css=document\.createElement\('style'\);\n"
        r"  css\.id='fix655OverviewCss';\n"
        r"  css\.textContent=`(?P<css>[\s\S]*?)`;\n"
        r"  document\.head\.appendChild\(css\);",
        overview,
        "overview style installer",
    )
    overview_css = overview_style.group("css")
    overview = overview[:overview_style.start()] + overview[overview_style.end():]

    stylesheet = (
        "/* R9RC1 runtime component presentation.\n"
        " * Former dynamic <style> owners are externalized for production CSP.\n"
        " */\n\n"
        "/* progress overlay */\n"
        + progress_css.strip()
        + "\n\n/* decor library */\n"
        + decor_css.strip()
        + "\n\n/* overview overlay */\n"
        + overview_css.strip()
        + "\n"
    )
    PROGRESS.write_text(progress, encoding="utf-8")
    DECOR.write_text(decor, encoding="utf-8")
    OVERVIEW.write_text(overview, encoding="utf-8")
    OUTPUT.write_text(stylesheet, encoding="utf-8")
    print("externalized three runtime style owners into runtime-components.css")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
