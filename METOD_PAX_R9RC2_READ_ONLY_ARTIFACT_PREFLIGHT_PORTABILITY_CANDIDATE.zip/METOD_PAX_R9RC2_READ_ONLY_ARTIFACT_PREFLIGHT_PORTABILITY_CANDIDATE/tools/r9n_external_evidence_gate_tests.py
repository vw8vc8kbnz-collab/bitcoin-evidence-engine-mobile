#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import importlib.util
import json
import sys
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
RUNNER = ROOT / "tools" / "r9n_external_evidence_gate.py"
SPEC = importlib.util.spec_from_file_location("r9n_external_evidence_gate", RUNNER)
assert SPEC and SPEC.loader
GATE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = GATE
SPEC.loader.exec_module(GATE)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


class ExternalEvidenceGateTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory(prefix="r9n-evidence-test-")
        self.root = Path(self.temp.name)
        self.release = self.root / "release"
        self.evidence = self.root / "evidence"
        self.release.mkdir()
        self.evidence.mkdir()
        (self.release / "SHA256SUMS.txt").write_text("fixture manifest\n", encoding="utf-8")
        self.artifact = self.root / "candidate.zip"
        self.golden = self.root / "golden.zip"
        self.artifact.write_bytes(b"candidate-artifact")
        self.golden.write_bytes(b"golden-artifact")
        self.contract = json.loads((ROOT / "R9N_EXTERNAL_EVIDENCE_CONTRACT.json").read_text(encoding="utf-8"))
        self.contract["goldenArtifactSha256"] = sha256(self.golden)
        self.artifact_sha = sha256(self.artifact)
        self.manifest_sha = sha256(self.release / "SHA256SUMS.txt")
        self.now = datetime(2026, 8, 25, 12, 0, tzinfo=timezone.utc)

    def tearDown(self) -> None:
        self.temp.cleanup()

    def write_json(self, relative: str, value: object) -> Path:
        target = self.evidence / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(value, sort_keys=True), encoding="utf-8")
        return target

    def attachment(self, relative: str, body: bytes = b"reviewed external proof") -> dict[str, str]:
        target = self.evidence / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(body)
        return {"path": relative, "sha256": sha256(target)}

    def complete_pack(self) -> None:
        raw_path = self.write_json("raw/browser-oracle.json", {
            "schemaVersion": 2,
            "oracleId": "browser-webkit-chromium",
            "status": "PASS",
            "candidateRelease": {"manifestSha256": self.manifest_sha},
            "fixtureCount": 15,
            "passedFixtureCount": 15,
            "failedFixtureCount": 0,
            "blockedFixtureCount": 0,
            "skippedFixtureCount": 0,
            "enginesPassed": ["webkit", "chromium"],
            "fixtureIdsPassed": [f"fixture-{index}" for index in range(15)]
        })
        self.write_json("browser.json", {
            "schemaVersion": 1,
            "reportType": "pinned-browser-oracle",
            "status": "PASS",
            "subjectArtifactSha256": self.artifact_sha,
            "candidateManifestSha256": self.manifest_sha,
            "rawOracleReportPath": "raw/browser-oracle.json",
            "attachments": [{"path": "raw/browser-oracle.json", "sha256": sha256(raw_path)}]
        })
        for spec in self.contract["reports"]:
            proof = self.attachment(f"proof/{spec['reportType']}.txt")
            environment = {"name": "reviewed environment"}
            if spec.get("actualHardwareRequired"):
                environment["actualHardware"] = True
                environment["deviceModel"] = "physical iPhone"
            self.write_json(spec["filename"], {
                "schemaVersion": 1,
                "reportType": spec["reportType"],
                "status": "PASS",
                "subjectArtifactSha256": self.artifact_sha,
                "candidateManifestSha256": self.manifest_sha,
                "observedAtUtc": "2026-08-25T11:00:00Z",
                "environment": environment,
                "attestation": {
                    "reviewerName": "Named Reviewer",
                    "organization": "Independent Audit BV" if spec.get("independentRequired") else "METOD Operations",
                    "independentFromBuilder": bool(spec.get("independentRequired"))
                },
                "attachments": [proof],
                "checks": [
                    {"id": check_id, "status": "PASS", "evidenceRefs": [proof["path"]]}
                    for check_id in spec["requiredCheckIds"]
                ]
            })

    def test_missing_external_evidence_is_no_go_not_pass(self) -> None:
        report, exit_code = GATE.evaluate(self.contract, self.artifact, self.golden, self.release, self.evidence, self.now)
        self.assertEqual(exit_code, GATE.EXIT_NO_GO)
        self.assertEqual(report["status"], "NO_GO")
        self.assertEqual(len(report["missingReports"]), 7)
        self.assertFalse(report["productionGo"])

    def test_complete_hash_bound_pack_is_only_evidence_complete(self) -> None:
        self.complete_pack()
        report, exit_code = GATE.evaluate(self.contract, self.artifact, self.golden, self.release, self.evidence, self.now)
        self.assertEqual(exit_code, 0)
        self.assertEqual(report["status"], "EVIDENCE_COMPLETE_PENDING_SEPARATE_PRODUCTION_DECISION")
        self.assertEqual(len(report["reportResults"]), 7)
        self.assertTrue(all(item["status"] == "PASS" for item in report["reportResults"]))
        self.assertFalse(report["productionGo"])
        self.assertFalse(report["releaseEligible"])

    def test_tampered_attachment_is_fail_closed(self) -> None:
        self.complete_pack()
        (self.evidence / "proof" / "candidate-vps.txt").write_bytes(b"tampered")
        with self.assertRaisesRegex(ValueError, "attachment hash mismatch"):
            GATE.evaluate(self.contract, self.artifact, self.golden, self.release, self.evidence, self.now)

    def test_missing_required_check_is_no_go(self) -> None:
        self.complete_pack()
        vps_path = self.evidence / "vps.json"
        value = json.loads(vps_path.read_text(encoding="utf-8"))
        value["checks"].pop()
        vps_path.write_text(json.dumps(value), encoding="utf-8")
        report, exit_code = GATE.evaluate(self.contract, self.artifact, self.golden, self.release, self.evidence, self.now)
        self.assertEqual(exit_code, GATE.EXIT_NO_GO)
        result = next(item for item in report["reportResults"] if item["reportType"] == "candidate-vps")
        self.assertEqual(result["reason"], "required-check-set-incomplete")

    def test_browser_report_cannot_bind_a_different_manifest(self) -> None:
        self.complete_pack()
        raw_path = self.evidence / "raw" / "browser-oracle.json"
        raw = json.loads(raw_path.read_text(encoding="utf-8"))
        raw["candidateRelease"]["manifestSha256"] = "0" * 64
        raw_path.write_text(json.dumps(raw), encoding="utf-8")
        wrapper_path = self.evidence / "browser.json"
        wrapper = json.loads(wrapper_path.read_text(encoding="utf-8"))
        wrapper["attachments"][0]["sha256"] = sha256(raw_path)
        wrapper_path.write_text(json.dumps(wrapper), encoding="utf-8")
        report, exit_code = GATE.evaluate(self.contract, self.artifact, self.golden, self.release, self.evidence, self.now)
        self.assertEqual(exit_code, GATE.EXIT_NO_GO)
        browser = next(item for item in report["reportResults"] if item["reportType"] == "pinned-browser-oracle")
        self.assertEqual(browser["reason"], "raw-browser-oracle-incomplete")


if __name__ == "__main__":
    unittest.main()
