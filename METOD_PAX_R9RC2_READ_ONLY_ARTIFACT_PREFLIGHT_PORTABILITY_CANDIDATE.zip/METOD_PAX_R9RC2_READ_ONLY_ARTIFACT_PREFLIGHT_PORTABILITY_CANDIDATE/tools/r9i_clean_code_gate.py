#!/usr/bin/env python3
from __future__ import annotations

"""Fail-closed R9I clean-code boundary for the shrinking legacy runtime."""

import argparse
import hashlib
import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CONTRACT = ROOT / "R9I9_SYNC_CATALOG_REFRESH_CLEANUP.json"


class GateFailure(RuntimeError):
    pass


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def function_body(source: str, name: str) -> str:
    match = re.search(
        rf"^(?P<indent>[ \t]*)(?:async\s+)?function {re.escape(name)}\([^\n]*\)\{{(?P<body>.*?)^(?P=indent)\}}$",
        source,
        re.MULTILINE | re.DOTALL,
    )
    if not match:
        raise GateFailure(f"thin legacy adapter missing: {name}")
    return match.group("body")


def check_contract(release: Path, contract_path: Path) -> dict[str, object]:
    contract = json.loads(contract_path.read_text(encoding="utf-8"))
    if contract.get("contractId") != "R9I9_SYNC_CATALOG_REFRESH_CLEANUP":
        raise GateFailure("R9I contract identity mismatch")

    runtime_rule = contract["legacyRuntime"]
    runtime_path = release / runtime_rule["path"]
    source = runtime_path.read_text(encoding="utf-8")
    current_bytes = len(runtime_path.read_bytes())
    current_lines = len(runtime_path.read_bytes().splitlines())
    current_sha = sha256(runtime_path)
    historical_expected = (
        runtime_rule["currentBytes"],
        runtime_rule["currentLines"],
        runtime_rule["currentSha256"],
    )
    active_expected = historical_expected
    active_stream_expected = None
    identity_path = release / "RELEASE_IDENTITY.json"
    if identity_path.is_file():
        identity = json.loads(identity_path.read_text(encoding="utf-8"))
        revision = ((identity.get("canonicalCandidate") or {}).get("releaseRevision"))
        if revision in {"R9O3", "R9O5", "R9O7", "R9O9"}:
            remediation_contract_name = {
                "R9O3": "R9O3_WEBKIT_FAILURE_REMEDIATION.json",
                "R9O5": "R9O5_WEBKIT_IPHONE_ADMIN_OVERFLOW_REMEDIATION.json",
                "R9O7": "R9O7_WEBKIT_IPHONE_ADMIN_GRID_TRACK_REMEDIATION.json",
                # R9O9 changes backend/security and release metadata only; the
                # sealed legacy runtime and classic stream remain R9O7-exact.
                "R9O9": "R9O7_WEBKIT_IPHONE_ADMIN_GRID_TRACK_REMEDIATION.json",
            }[revision]
            remediation = json.loads((release / remediation_contract_name).read_text(encoding="utf-8"))
            integrity = remediation["integrity"]
            active = integrity["legacyRuntime"]
            active_expected = (active["bytes"], active["lines"], active["sha256"])
            active_stream_expected = integrity["classicScriptStream"]
    if (current_bytes, current_lines, current_sha) != active_expected:
        raise GateFailure("legacy runtime identity drift")
    if runtime_rule["baselineBytes"] - runtime_rule["currentBytes"] < runtime_rule["minimumCumulativeByteReduction"]:
        raise GateFailure("legacy runtime cumulative byte reduction regressed")
    if runtime_rule["baselineLines"] - runtime_rule["currentLines"] < runtime_rule["minimumCumulativeLineReduction"]:
        raise GateFailure("legacy runtime cumulative line reduction regressed")
    if runtime_rule["previousBytes"] - runtime_rule["currentBytes"] < runtime_rule["minimumIncrementalByteReduction"]:
        raise GateFailure("legacy runtime incremental byte reduction regressed")
    if runtime_rule["previousLines"] - runtime_rule["currentLines"] < runtime_rule["minimumIncrementalLineReduction"]:
        raise GateFailure("legacy runtime incremental line reduction regressed")

    copy_body = function_body(source, "copyCustomerSnapshot")
    merged_body = function_body(source, "customerForCurrentCalculation")
    if "owner.normalizeCustomerSnapshot(raw)" not in copy_body:
        raise GateFailure("customer normalizer no longer routes through the native owner")
    if "owner.getCustomerSnapshot()" not in merged_body:
        raise GateFailure("customer snapshot no longer routes through the native store")
    forbidden_legacy_copy = (
        "invoiceAddress", "deliveryAddress", "postalCode", "companyName",
        "const sources", "Object.keys(c)",
    )
    if any(token in copy_body + merged_body for token in forbidden_legacy_copy):
        raise GateFailure("duplicated customer read logic returned to the legacy runtime")

    grain_adapters = {
        "grainEnabledForKey": "owner.isGrainEnabledForMaterial(mk)",
        "grainOverlaySelectedMaterialKey": "owner.getGrainMaterialKey()",
        "isGrainCapable": "owner.isGrainCapableItem(it)",
        "parseGrainRef": "owner.parseGrainReference(ref)",
    }
    for name, owner_call in grain_adapters.items():
        body = function_body(source, name)
        if owner_call not in body:
            raise GateFailure(f"grain reader no longer routes through the native owner: {name}")
        for forbidden in ("state.materialBatches", "state.grain", "const parts", ".split(':')"):
            if forbidden in body:
                raise GateFailure(f"duplicated grain read logic returned: {name}")

    material_body = function_body(source, "materialThicknessKey")
    if "owner.getMaterialThickness(k, window.MATERIAL_CATALOG, DEFAULT_THICKNESS_MM)" not in material_body:
        raise GateFailure("material thickness no longer routes through the native owner")
    if "ensureStateShape()" not in material_body:
        raise GateFailure("material thickness lost the existing state-shape compatibility call")
    for forbidden in ("activeKey", "matObj", ".find("):
        if forbidden in material_body:
            raise GateFailure("duplicated material thickness logic returned to the legacy runtime")
    for removed in contract["removedLegacyReaders"]:
        if re.search(rf"\bfunction\s+{re.escape(removed)}\s*\(", source):
            raise GateFailure(f"retired material sheet reader returned: {removed}")
    if source.count("owner.getUsableMaterialSheetDimensions(materialKey, window.MATERIAL_CATALOG)") != 1:
        raise GateFailure("material sheet consumer no longer has one native read route")

    native_hashes = {}
    for relative, expected_sha in contract["nativeReaders"].items():
        path = release / relative
        observed = sha256(path)
        if observed != expected_sha:
            raise GateFailure(f"native reader identity drift: {relative}")
        native_hashes[relative] = observed

    selectors = (release / "app/tool-a/state/selectors.js").read_text(encoding="utf-8")
    store = (release / "app/tool-a/state/store.js").read_text(encoding="utf-8")
    bootstrap = (release / "app/tool-a/bootstrap.js").read_text(encoding="utf-8")
    for token in (
        "export function normalizeCustomerSnapshot",
        "export function selectCustomerSnapshot",
        "export function selectGrainMaterialKey",
        "export function selectGrainEnabledForMaterial",
        "export function selectIsGrainCapableItem",
        "export function parseGrainReference",
        "export function selectMaterialThickness",
        "export function selectMaterialSheetDimensions",
        "export function selectUsableMaterialSheetDimensions",
    ):
        if token not in selectors:
            raise GateFailure(f"native selector surface missing: {token}")
    if "normalizeCustomerSnapshot(source)" not in store:
        raise GateFailure("read store normalizer surface missing")
    for token in (
        "getGrainMaterialKey()",
        "isGrainEnabledForMaterial(materialKey)",
        "isGrainCapableItem(item)",
        "parseGrainReference(reference)",
        "getMaterialThickness(materialKey, materialCatalog, defaultThicknessMm)",
        "getUsableMaterialSheetDimensions(materialKey, materialCatalog)",
    ):
        if token not in store:
            raise GateFailure(f"grain read-store surface missing: {token}")
    for token in (
        "getCustomerSnapshot: () => toolAStore.getCustomerSnapshot()",
        "normalizeCustomerSnapshot: (source) => toolAStore.normalizeCustomerSnapshot(source)",
        "getGrainMaterialKey: () => toolAStore.getGrainMaterialKey()",
        "isGrainEnabledForMaterial: (materialKey) => toolAStore.isGrainEnabledForMaterial(materialKey)",
        "isGrainCapableItem: (item) => toolAStore.isGrainCapableItem(item)",
        "parseGrainReference: (reference) => toolAStore.parseGrainReference(reference)",
        "getMaterialThickness: (materialKey, materialCatalog, defaultThicknessMm) => toolAStore.getMaterialThickness(materialKey, materialCatalog, defaultThicknessMm)",
        "getUsableMaterialSheetDimensions: (materialKey, materialCatalog) => toolAStore.getUsableMaterialSheetDimensions(materialKey, materialCatalog)",
    ):
        if token not in bootstrap:
            raise GateFailure(f"single compatibility adapter missing: {token}")

    cancel_body = function_body(source, "_markJobCancelled")
    owner_call = "owner.cancelJob({jobId, accessToken:token, reason:'customer_cancelled'})"
    if owner_call not in cancel_body:
        raise GateFailure("job cancellation no longer routes through the native jobs owner")
    for forbidden in ("fetch(", "'/api/jobs/cancel'", "buildJobTokenHeaders(", "JSON.stringify("):
        if forbidden in cancel_body:
            raise GateFailure("duplicated job-cancel request logic returned to the legacy runtime")
    if source.count("await _markJobCancelled(jobId)") != 1:
        raise GateFailure("job-cancel consumer count drifted")

    overlay_rule = contract["nativeOverlayOwner"]
    overlay_path = release / overlay_rule["path"]
    if (
        len(overlay_path.read_bytes()) != overlay_rule["bytes"]
        or len(overlay_path.read_bytes().splitlines()) != overlay_rule["lines"]
        or sha256(overlay_path) != overlay_rule["sha256"]
    ):
        raise GateFailure("native overlay owner identity drift")
    overlay_source = overlay_path.read_text(encoding="utf-8")
    for token in (
        '"overlay"', '"grainOverlay"', '"extraOverlay"', '"overviewOverlay"',
        "now() + 350", "setIntervalImpl(enforceActiveOverlay, 500)",
        "setIntervalImpl(disableHiddenOverlays, 500)",
        'addEventListener?.("pointerdown", handlePointerDown, { capture: true })',
    ):
        if token not in overlay_source:
            raise GateFailure(f"native overlay behavior contract drift: {token}")
    overlay_section = source[source.index("  // Overlay manager"):source.index("  const choiceMetod")]
    for token in ("OVERLAY_IDS", "getComputedStyle", "setInterval", "pointerdown", "aria-hidden"):
        if token in overlay_section:
            raise GateFailure(f"retired legacy overlay ownership returned: {token}")
    for name, owner_call in {
        "setOverlayVisible": "owner.setOverlayVisible(id, visible)",
        "hideAllOverlays": "owner.hideAllOverlays()",
        "openOverlay": "owner.openOverlay(el)",
        "closeOverlay": "owner.closeOverlay(el)",
    }.items():
        if owner_call not in function_body(source, name):
            raise GateFailure(f"overlay adapter no longer routes through native owner: {name}")

    html = (release / "app/toolA.html").read_text(encoding="utf-8")
    if html.count('id="stepCustomer"') != 1:
        raise GateFailure("inline customer step identity drift")
    for token in contract["retiredDeadDomOwners"]:
        if token in source or token in html:
            raise GateFailure(f"retired dead customer-overlay owner returned: {token}")

    shadow_rule = contract["retiredShadowOwners"]
    open_count = len(re.findall(r"^  function openPriceOverlay\(", source, re.MULTILINE))
    close_count = len(re.findall(r"^  function closePriceOverlay\(", source, re.MULTILINE))
    if open_count != shadow_rule["remainingLocalOpenDefinitions"]:
        raise GateFailure("price-overlay local open-owner count drifted")
    if close_count != shadow_rule["remainingLocalCloseDefinitions"]:
        raise GateFailure("price-overlay local close-owner count drifted")
    retained_open = function_body(source, "openPriceOverlay")
    retained_close = function_body(source, "closePriceOverlay")
    for token in ("po.style.display='flex'", "document.body.style.overflow='hidden'", "refreshPriceOverlay"):
        if token not in retained_open:
            raise GateFailure(f"retained price-overlay open behavior drifted: {token}")
    for token in ("po.style.display = 'none'", "document.body.style.overflow=''"):
        if token not in retained_close:
            raise GateFailure(f"retained price-overlay close behavior drifted: {token}")
    for relative, expected_sha in contract["protectedPriceOverlayLayers"].items():
        if sha256(release / relative) != expected_sha:
            raise GateFailure(f"protected authoritative price-overlay layer drift: {relative}")
    price_compat = (release / "app/tool-a/shell/script-08-compat.js").read_text(encoding="utf-8")
    for token in contract["retiredUnusedPriceCompatibility"]:
        if token in price_compat:
            raise GateFailure(f"retired unused price compatibility returned: {token}")
    for token in (
        "window.openPriceOverlay = function()",
        "window.closePriceOverlay = window.closePriceOverlay || function()",
        "refreshPriceOverlay()",
        "renderPriceSummary()",
        "_getFinalAuthoritativePriceForCurrentJob()",
        "_strictAuthoritativePriceInclVat",
    ):
        if token not in price_compat:
            raise GateFailure(f"active price compatibility behavior drifted: {token}")
    for token in contract["retiredSynchronousCatalogRefresh"]:
        if token in source:
            raise GateFailure(f"retired synchronous catalog refresh returned: {token}")
    for token in (
        "async function _loadEmbedManifest()",
        "async function refreshEmbeddedDxfCatalogNow()",
        "await _loadEmbedManifest()",
        "fetch('/embedded_dxfs_manifest.json', {cache:'no-store'})",
        "fetch(`/api/dxf_manifest_meta?ts=${Date.now()}`, { cache: 'no-store' })",
        "refreshEmbeddedDxfCatalogNow().then(()=>{",
    ):
        if token not in source:
            raise GateFailure(f"active asynchronous catalog refresh drifted: {token}")

    for relative, expected_sha in contract["changedClassicOwners"].items():
        if sha256(release / relative) != expected_sha:
            raise GateFailure(f"changed classic owner identity drift: {relative}")
    helpers = (release / "app/toolA_safe_helper_layer.js").read_text(encoding="utf-8")
    if "function setOverlayVisible" in helpers or "function hideAllOverlays" in helpers:
        raise GateFailure("retired classic overlay owner returned")

    stream_rule = contract["classicScriptStream"]
    shell_manifest = json.loads((release / stream_rule["manifest"]).read_text(encoding="utf-8"))
    classic_stream = b"".join(
        (release / "app" / item["path"]).read_bytes()
        for item in shell_manifest["scriptFiles"]
    )
    stream_expected = active_stream_expected or {
        "bytes": stream_rule["currentBytes"],
        "sha256": stream_rule["currentSha256"],
    }
    if len(classic_stream) != stream_expected["bytes"] or hashlib.sha256(classic_stream).hexdigest() != stream_expected["sha256"]:
        raise GateFailure("classic script stream identity drift")
    if stream_rule["previousBytes"] - stream_rule["currentBytes"] < stream_rule["minimumIncrementalByteReduction"]:
        raise GateFailure("classic script stream incremental byte reduction regressed")

    static_rule = contract["publicStaticAllowlist"]
    for relative in ("app/metod_app/http/static.py", "app/metod_app/http/matcher.py"):
        if sha256(release / relative) != static_rule[relative]:
            raise GateFailure(f"public static allowlist owner drift: {relative}")
    server_static_source = (release / "app/server_py.py").read_text(encoding="utf-8")
    if "PUBLIC_STATIC_ROOT_FILES =" in server_static_source or "def _is_public_static_relpath" in server_static_source:
        raise GateFailure("server reacquired public static policy ownership")

    network_hashes = {}
    for relative, expected_sha in contract["nativeNetworkOwners"].items():
        path = release / relative
        observed = sha256(path)
        if observed != expected_sha:
            raise GateFailure(f"native network owner identity drift: {relative}")
        network_hashes[relative] = observed
    jobs = (release / "app/tool-a/api/jobs.js").read_text(encoding="utf-8")
    requests = (release / "app/tool-a/api/requests.js").read_text(encoding="utf-8")
    if jobs.count('fetchImpl("/api/jobs/cancel",') != 1:
        raise GateFailure("job-cancel route does not have exactly one native request owner")
    if "cancelJob: (options) => jobsApi.cancelJob(options)" not in bootstrap:
        raise GateFailure("job-cancel foundation delegation missing")
    if "/api/jobs/cancel" in requests:
        raise GateFailure("request API acquired duplicate job-cancel ownership")
    for relative, expected_sha in contract["protectedFiles"].items():
        if sha256(release / relative) != expected_sha:
            raise GateFailure(f"protected functional owner drift: {relative}")

    pure_sources = selectors + store
    for token in (
        "document", "addEventListener", "fetch(", "XMLHttpRequest", "EventSource",
        "WebSocket", "localStorage", "sessionStorage", "window", "globalThis",
    ):
        if token.lower() in pure_sources.lower():
            raise GateFailure(f"native reader acquired forbidden side effect: {token}")

    token_counts = {
        token: source.count(token)
        for token in contract["legacyOwnerTokenCounts"]
    }
    if token_counts != contract["legacyOwnerTokenCounts"]:
        raise GateFailure("legacy DOM/network/storage owner token counts drifted")

    return {
        "schemaVersion": 1,
        "gateId": "r9i-clean-code",
        "status": "PASS",
        "legacyRuntime": {
            "bytes": current_bytes,
            "lines": current_lines,
            "sha256": current_sha,
            "historicalR9IBytesRemoved": runtime_rule["baselineBytes"] - runtime_rule["currentBytes"],
            "historicalR9ILinesRemoved": runtime_rule["baselineLines"] - runtime_rule["currentLines"],
        },
        "classicScriptStream": {
            "bytes": len(classic_stream),
            "sha256": hashlib.sha256(classic_stream).hexdigest(),
            "historicalR9IIncrementalBytesRemoved": stream_rule["previousBytes"] - stream_rule["currentBytes"],
        },
        "migratedReaders": contract["migratedReaders"],
        "centralizedRoutes": contract["centralizedRoutes"],
        "centralizedDomResponsibility": contract["centralizedDomResponsibility"],
        "nativeReaderSha256": native_hashes,
        "nativeNetworkOwnerSha256": network_hashes,
        "preservedOwnerTokenCounts": token_counts,
        "retiredSynchronousCatalogRefresh": contract["retiredSynchronousCatalogRefresh"],
        "browserStatus": contract["browserEvidence"]["status"],
        "releaseEligible": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--release", type=Path, default=ROOT)
    parser.add_argument("--contract", type=Path, default=DEFAULT_CONTRACT)
    parser.add_argument("--json-output", type=Path)
    args = parser.parse_args()
    try:
        report = check_contract(args.release.resolve(), args.contract.resolve())
    except Exception as exc:
        report = {
            "schemaVersion": 1,
            "gateId": "r9i-clean-code",
            "status": "FAIL",
            "error": str(exc),
            "releaseEligible": False,
        }
    if args.json_output:
        args.json_output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
