#!/usr/bin/env python3
from __future__ import annotations

"""Fail-closed R9G-1 contract for the passive Tool A shadow read model."""

import base64
import ast
import json
import shutil
import subprocess
import sys
import unittest
from pathlib import Path

from r9h_shell_source import read_toola_expanded


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
SELECTORS = APP / "tool-a/state/selectors.js"
STORE = APP / "tool-a/state/store.js"
BOOTSTRAP = APP / "tool-a/bootstrap.js"
MATERIALS = APP / "tool-a/steps/materials.js"
PANELS = APP / "tool-a/steps/panels.js"
GRAIN = APP / "tool-a/steps/grain.js"
CUSTOMER = APP / "tool-a/steps/customer.js"
JOBS = APP / "tool-a/api/jobs.js"
REQUESTS = APP / "tool-a/api/requests.js"
DIALOG = APP / "tool-a/components/dialog.js"
FOOTER = APP / "tool-a/components/footer.js"
GRAIN_PREVIEW = APP / "tool-a/components/grain-preview.js"
CHECKOUT_REVIEW = APP / "tool-a/components/checkout-review.js"
MATERIAL_CARD = APP / "tool-a/components/material-card.js"
PANEL_EDITOR = APP / "tool-a/components/panel-editor.js"
MOBILE_CART = APP / "tool-a/components/mobile-material-cart.js"
OVERLAY_ROUTER = APP / "tool-a/components/overlay-router.js"
PROGRESS = APP / "tool-a/components/progress-overlay.js"
THANK_YOU = APP / "tool-a/components/thank-you.js"
RULES = ROOT / "R9B_ARCHITECTURE_RULES.json"


def data_url(data: bytes) -> str:
    return "data:text/javascript;base64," + base64.b64encode(data).decode()


def linked_sources() -> tuple[str, str, str, str, str, str, str]:
    selectors_url = data_url(SELECTORS.read_bytes())
    store = STORE.read_text(encoding="utf-8").replace("./selectors.js", selectors_url)
    store_url = data_url(store.encode())
    materials_url = data_url(MATERIALS.read_bytes())
    panels_url = data_url(PANELS.read_bytes())
    grain_url = data_url(GRAIN.read_bytes())
    customer_url = data_url(CUSTOMER.read_bytes())
    bootstrap = BOOTSTRAP.read_text(encoding="utf-8")
    bootstrap = bootstrap.replace("./state/store.js", store_url)
    bootstrap = bootstrap.replace("./steps/materials.js", materials_url)
    bootstrap = bootstrap.replace("./steps/panels.js", panels_url)
    bootstrap = bootstrap.replace("./steps/grain.js", grain_url)
    bootstrap = bootstrap.replace("./steps/customer.js", customer_url)
    bootstrap = bootstrap.replace("./api/jobs.js", data_url(JOBS.read_bytes()))
    bootstrap = bootstrap.replace("./api/requests.js", data_url(REQUESTS.read_bytes()))
    bootstrap = bootstrap.replace("./components/dialog.js", data_url(DIALOG.read_bytes()))
    bootstrap = bootstrap.replace("./components/footer.js", data_url(FOOTER.read_bytes()))
    bootstrap = bootstrap.replace("./components/grain-preview.js", data_url(GRAIN_PREVIEW.read_bytes()))
    bootstrap = bootstrap.replace("./components/checkout-review.js", data_url(CHECKOUT_REVIEW.read_bytes()))
    bootstrap = bootstrap.replace("./components/material-card.js", data_url(MATERIAL_CARD.read_bytes()))
    bootstrap = bootstrap.replace("./components/panel-editor.js", data_url(PANEL_EDITOR.read_bytes()))
    bootstrap = bootstrap.replace("./components/mobile-material-cart.js", data_url(MOBILE_CART.read_bytes()))
    bootstrap = bootstrap.replace("./components/overlay-router.js", data_url(OVERLAY_ROUTER.read_bytes()))
    bootstrap = bootstrap.replace("./components/progress-overlay.js", data_url(PROGRESS.read_bytes()))
    bootstrap = bootstrap.replace("./components/thank-you.js", data_url(THANK_YOU.read_bytes()))
    return selectors_url, store_url, materials_url, panels_url, grain_url, customer_url, data_url(bootstrap.encode())


def run_node(source: str) -> dict:
    node = shutil.which("node")
    if not node:
        raise AssertionError("Node is required by the release architecture gate")
    completed = subprocess.run(
        [node, "--input-type=module"], input=source, text=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=10, check=False,
    )
    if completed.returncode != 0:
        raise AssertionError(completed.stdout)
    return json.loads(completed.stdout.strip().splitlines()[-1])


class R9GReadModelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        (
            cls.selectors_url, cls.store_url, cls.materials_url,
            cls.panels_url, cls.grain_url, cls.customer_url, cls.bootstrap_url,
        ) = linked_sources()

    def test_01_selectors_are_native_pure_and_runtime_owner_free(self) -> None:
        source = SELECTORS.read_text(encoding="utf-8")
        for token in (
            "window", "globalThis", "document", "addEventListener", "fetch(",
            "localStorage", "sessionStorage", "EventSource", "XMLHttpRequest",
        ):
            self.assertNotIn(token.lower(), source.lower(), token)
        self.assertIn("export function selectSafeToolAReadModel", source)
        self.assertIn("export function selectCurrentStep", source)
        self.assertIn("export function selectActiveMaterialKey", source)

    def test_02_projection_is_exact_frozen_and_contains_no_pii(self) -> None:
        result = run_node(f"""
const m = await import({json.dumps(self.selectors_url)});
const state = {{
  activeMaterialKey:'M1', materialBatches:[{{key:'M1'}}], cart:[{{id:'P1'}}],
  extraPanels:[{{id:'E1'}}], grain:{{groups:[{{id:'G1'}}]}},
  checkout:{{customer:{{firstName:'Private',email:'private@example.test'}}}},
  jobAccessToken:'secret',
}};
const snapshot = m.selectSafeToolAReadModel(state, {{uiStep:'grain'}});
console.log(JSON.stringify({{snapshot,frozen:Object.isFrozen(snapshot),keys:Reflect.ownKeys(snapshot)}}));
""")
        self.assertEqual(result["snapshot"], {
            "currentStep": "grain", "activeMaterialKey": "M1",
            "materialBatchCount": 1, "standardPanelLineCount": 1,
            "extraPanelLineCount": 1, "grainGroupCount": 1,
            "hasActiveMaterial": True, "hasPanels": True,
        })
        self.assertTrue(result["frozen"])
        self.assertEqual(result["keys"], list(result["snapshot"]))
        serialized = json.dumps(result)
        for forbidden in ("Private", "private@example.test", "secret", "customer", "token"):
            self.assertNotIn(forbidden.lower(), serialized.lower())

    def test_03_projection_never_mutates_the_legacy_source(self) -> None:
        result = run_node(f"""
const m = await import({json.dumps(self.selectors_url)});
const state = {{selection:{{materialKey:'M2'}},cart:null,grain:{{groups:null}}}};
const before = JSON.stringify(state);
m.selectSafeToolAReadModel(state, {{uiStep:'invalid'}});
console.log(JSON.stringify({{before,after:JSON.stringify(state)}}));
""")
        self.assertEqual(result["before"], result["after"])

    def test_04_store_reads_fresh_legacy_state_without_caching(self) -> None:
        result = run_node(f"""
const m = await import({json.dumps(self.store_url)});
let legacy = {{state:{{cart:[]}},runtime:{{uiStep:'material'}}}};
const store = m.createToolAStore(() => legacy);
const first = store.getSnapshot();
legacy.state.cart.push({{id:'P1'}});
legacy.runtime.uiStep = 'panels';
const second = store.getSnapshot();
console.log(JSON.stringify({{first,second,separate:first!==second}}));
""")
        self.assertFalse(result["first"]["hasPanels"])
        self.assertTrue(result["second"]["hasPanels"])
        self.assertEqual(result["second"]["currentStep"], "panels")
        self.assertTrue(result["separate"])

    def test_05_invalid_or_throwing_sources_fail_to_the_frozen_empty_model(self) -> None:
        result = run_node(f"""
const m = await import({json.dumps(self.store_url)});
const invalid = m.createToolAStore(() => null).getSnapshot();
const throwing = m.createToolAStore(() => {{throw new Error('boom')}}).getSnapshot();
let constructorRejected = false;
try {{ m.createToolAStore({{}}); }} catch (_error) {{ constructorRejected = true; }}
console.log(JSON.stringify({{
  invalid, throwing, constructorRejected,
  invalidFrozen:Object.isFrozen(invalid), throwingFrozen:Object.isFrozen(throwing),
}}));
""")
        self.assertEqual(result["invalid"], result["throwing"])
        self.assertTrue(result["constructorRejected"])
        self.assertTrue(result["invalidFrozen"])
        self.assertTrue(result["throwingFrozen"])

    def test_06_store_and_adapter_expose_no_action_or_subscription_surface(self) -> None:
        result = run_node(f"""
globalThis.state = {{cart:[]}};
globalThis.__metod_uiStep = 'material';
const m = await import({json.dumps(self.bootstrap_url)});
const descriptor = Object.getOwnPropertyDescriptor(globalThis,'ToolAR9Foundation');
console.log(JSON.stringify({{
  storeKeys:Reflect.ownKeys(m.toolAStore),
  adapterKeys:Reflect.ownKeys(globalThis.ToolAR9Foundation),
  storeFrozen:Object.isFrozen(m.toolAStore),
  adapterFrozen:Object.isFrozen(globalThis.ToolAR9Foundation),
  writable:descriptor.writable, configurable:descriptor.configurable,
}}));
""")
        self.assertEqual(result["storeKeys"], [
            "getSnapshot", "getCustomerSnapshot", "normalizeCustomerSnapshot",
            "getGrainMaterialKey", "isGrainEnabledForMaterial",
            "isGrainCapableItem", "parseGrainReference",
            "getMaterialThickness", "getUsableMaterialSheetDimensions",
        ])
        self.assertTrue(set([
            "revision", "mode", "getSnapshot", "getMaterialsView", "getPanelsView",
            "getGrainView", "getCustomerView", "startJob", "pollJob",
            "fetchJobPricingSummary", "authoritativeTotalInclVat",
            "submitFinalConfiguration", "resetFinalSubmission", "getFinalSubmissionState",
        ]).issubset(result["adapterKeys"]))
        self.assertTrue(result["storeFrozen"])
        self.assertTrue(result["adapterFrozen"])
        self.assertFalse(result["writable"])
        self.assertFalse(result["configurable"])

    def test_07_bootstrap_has_one_exact_shadow_owner_and_three_read_globals(self) -> None:
        source = BOOTSTRAP.read_text(encoding="utf-8")
        self.assertIn('"R9I_SYNC_CATALOG_REFRESH_CLEANUP_9"', source)
        self.assertIn('mode: "legacy-read-cleanup-adapter"', source)
        self.assertEqual(source.count("Object.defineProperty(globalThis"), 1)
        self.assertEqual(source.count("globalThis.state"), 1)
        self.assertEqual(source.count("globalThis.__metod_uiStep"), 1)
        self.assertEqual(source.count("globalThis.__metod_checkout_live_customer"), 1)
        for token in ("addEventListener", "fetch(", "localStorage", "sessionStorage"):
            self.assertNotIn(token, source)

    def test_08_architecture_contract_retains_the_r9g_module_graph(self) -> None:
        rules = json.loads(RULES.read_text(encoding="utf-8"))["frontend"]
        original = [
            "tool-a/bootstrap.js", "tool-a/api/jobs.js", "tool-a/api/requests.js", "tool-a/state/store.js", "tool-a/state/selectors.js",
            "tool-a/steps/materials.js", "tool-a/steps/panels.js", "tool-a/steps/grain.js",
            "tool-a/steps/customer.js",
        ]
        self.assertTrue(set(original).issubset(rules["publicStaticFiles"]))
        self.assertTrue(set(original).issubset({path.removeprefix("app/") for path in rules["moduleImports"]}))
        self.assertEqual(rules["moduleImports"]["app/tool-a/state/store.js"], ["./selectors.js"])
        self.assertEqual(rules["legacyReadGlobals"], [
            "state", "__metod_uiStep", "__metod_checkout_live_customer",
        ])

    def test_09_server_and_html_expose_only_the_reviewed_native_graph(self) -> None:
        server_tree = ast.parse((APP / "metod_app/http/static.py").read_text(encoding="utf-8"))
        public_files = None
        for node in server_tree.body:
            if isinstance(node, ast.Assign) and any(
                isinstance(target, ast.Name) and target.id == "PUBLIC_STATIC_MODULE_FILES"
                for target in node.targets
            ):
                public_files = ast.literal_eval(node.value)
                break
        self.assertTrue({
            "tool-a/bootstrap.js", "tool-a/api/jobs.js", "tool-a/api/requests.js", "tool-a/state/store.js", "tool-a/state/selectors.js",
            "tool-a/steps/materials.js", "tool-a/steps/panels.js", "tool-a/steps/grain.js",
            "tool-a/steps/customer.js",
        }.issubset(public_files))
        html = read_toola_expanded(APP / "toolA.html")
        marker = '<script type="module" src="tool-a/bootstrap.js?v=r9i-sync-catalog-refresh-cleanup-9"></script>'
        self.assertEqual(html.count(marker), 1)
        self.assertLess(html.rfind("toolA_overview_fix655.js"), html.index(marker))

    def test_10_all_legacy_read_mutation_route_and_submit_owners_remain_exact(self) -> None:
        expected = {
            "toolA_core_read_helpers.js": "2d6a80e7de9345cea82236665b1eb4f82a1c43502eacf1b401661a4b79234ce8",
            "toolA_core_selectors.js": "556a106c55fe91d67d0381fbbdbbee97fadeac78b9756d80200f7f04d6060ffd",
            "toolA_route_state.js": "7b93144d1522daa69e1187e7a4bd8f568f0e6d5af1e6b13c7fb58782c3e2c800",
            "toolA_material_batch_mutations.js": "c1ec2bb3c68d9e66704eba5c0287a4097c06b5dd2dc7eddc4270c0e8be16229b",
            "toolA_panel_mutations.js": "4fd36df984c6416e0e394397ecafd53c0f20a6e432bf8330226c03ef00230356",
            "toolA_entrypoints.js": "b808d54546c4658a437f3e0ee03b57ac5ddc9fa8e2b21cc702074c3c0e8b8148",
            "toolA_grain_studio_renderer.js": "922cd4ac479fbaf86ebfbb0256808119b96a8344e9b0bf1ffb4f668518a03204",
        }
        import hashlib
        for name, digest in expected.items():
            self.assertEqual(hashlib.sha256((APP / name).read_bytes()).hexdigest(), digest, name)


if __name__ == "__main__":
    unittest.main(verbosity=2)
