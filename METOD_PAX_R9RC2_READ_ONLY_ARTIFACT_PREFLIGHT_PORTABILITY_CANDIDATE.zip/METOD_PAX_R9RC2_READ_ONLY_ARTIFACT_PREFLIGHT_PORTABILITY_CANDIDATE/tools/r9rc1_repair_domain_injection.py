#!/usr/bin/env python3
from __future__ import annotations

"""Repair the first generated R9RC1 multiline-signature injection mechanically."""

import re
from pathlib import Path

from r9rc1_extract_runtime_domains import APP, GROUPS


MULTILINE_DEF = re.compile(r"^    def [A-Za-z0-9_]+\(_owner,\s*$")
RUNTIME_BINDING = "        runtime = _owner._runtime\n"


def repair(path: Path) -> int:
    lines = path.read_text(encoding="utf-8", errors="strict").splitlines(keepends=True)
    output: list[str] = []
    index = 0
    repaired = 0
    while index < len(lines):
        line = lines[index]
        output.append(line)
        index += 1
        if not MULTILINE_DEF.match(line) or index >= len(lines) or lines[index] != RUNTIME_BINDING:
            continue

        bindings: list[str] = []
        while index < len(lines):
            current = lines[index]
            bindings.append(current)
            index += 1
            if current.strip() == "":
                break

        balance = line.count("(") - line.count(")")
        while index < len(lines):
            current = lines[index]
            output.append(current)
            index += 1
            balance += current.count("(") - current.count(")")
            if balance <= 0 and current.rstrip().endswith(":"):
                break
        output.extend(bindings)
        repaired += 1
    path.write_text("".join(output), encoding="utf-8")
    return repaired


def main() -> int:
    total = 0
    for relative, _, _ in GROUPS:
        total += repair(APP / relative)
    if total < 1:
        raise RuntimeError("no multiline runtime bindings required repair")
    print(f"repaired {total} multiline runtime method signatures")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
