#!/usr/bin/env python3
from __future__ import annotations

"""Deterministic R9J-2 secrets, SAST, dependency, license and SBOM gate."""

import argparse
import ast
import hashlib
import json
import math
import os
import re
import stat
import sys
import tempfile
from pathlib import Path
from typing import Any


DEFAULT_RELEASE = Path(__file__).resolve().parents[1]
POLICY_NAME = "R9J2_SECURITY_SUPPLY_CHAIN_POLICY.json"
TEXT_SUFFIXES = {
    ".bat", ".css", ".html", ".js", ".jsfrag", ".json", ".md", ".py", ".sh", ".txt", ".yml", ".yaml",
}
SECRET_RULES = {
    "private-key-pem": re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----"),
    "aws-access-key": re.compile(r"(?<![A-Z0-9])(?:AKIA|ASIA)[A-Z0-9]{16}(?![A-Z0-9])"),
    "github-token": re.compile(r"(?<![A-Za-z0-9_])(?:gh[pousr]_[A-Za-z0-9_]{20,}|github_pat_[A-Za-z0-9_]{20,})"),
    "gitlab-token": re.compile(r"(?<![A-Za-z0-9_-])glpat-[A-Za-z0-9_-]{20,}"),
    "google-api-key": re.compile(r"(?<![A-Za-z0-9])AIza[0-9A-Za-z_-]{35}(?![A-Za-z0-9_-])"),
    "slack-token": re.compile(r"(?<![A-Za-z0-9-])xox[baprs]-[A-Za-z0-9-]{20,}"),
    "stripe-live-key": re.compile(r"(?<![A-Za-z0-9_])(?:sk|rk)_live_[A-Za-z0-9]{16,}"),
    "npm-token": re.compile(r"(?<![A-Za-z0-9])npm_[A-Za-z0-9]{30,}"),
    "credential-in-url": re.compile(r"(?:https?|ftp)://[^\s/:@]+:[^\s/@]+@", re.IGNORECASE),
}
FORBIDDEN_PYTHON_CALLS = {
    "eval", "exec", "os.system", "pickle.load", "pickle.loads", "marshal.load", "marshal.loads", "tempfile.mktemp",
}
JAVASCRIPT_DANGEROUS_SINKS = {
    "eval": re.compile(r"(?<![A-Za-z0-9_$])eval\s*\("),
    "newFunction": re.compile(r"\bnew\s+Function\s*\("),
    "documentWrite": re.compile(r"\bdocument\.write(?:ln)?\s*\("),
    "remoteImports": re.compile(
        r"(?:from|import)\s*['\"](?:https?:|//)|"
        r"(?:import|fetch)\s*\(\s*['\"](?:https?:|//)|"
        r"<(?:script|link)[^>]+(?:src|href)=['\"]https?:",
        re.IGNORECASE,
    ),
}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def strict_json(path: Path) -> Any:
    value = json.loads(
        path.read_text(encoding="utf-8", errors="strict"),
        parse_constant=lambda token: (_ for _ in ()).throw(ValueError(f"non-finite JSON: {token}")),
    )
    stack = [value]
    while stack:
        item = stack.pop()
        if isinstance(item, float) and not math.isfinite(item):
            raise ValueError("non-finite JSON number")
        if isinstance(item, dict):
            stack.extend(item.values())
        elif isinstance(item, list):
            stack.extend(item)
    return value


def qualified_name(node: ast.AST) -> str:
    names: list[str] = []
    while isinstance(node, ast.Attribute):
        names.append(node.attr)
        node = node.value
    if isinstance(node, ast.Name):
        names.append(node.id)
    return ".".join(reversed(names))


def scan_secret_text(relative: str, source: str) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    for rule_id, pattern in SECRET_RULES.items():
        for match in pattern.finditer(source):
            findings.append({
                "ruleId": rule_id,
                "path": relative,
                "line": source.count("\n", 0, match.start()) + 1,
                "matchSha256": hashlib.sha256(match.group(0).encode("utf-8")).hexdigest(),
            })
    return findings


def scan_python_source(relative: str, source: str) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    tree = ast.parse(source, filename=relative)
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        name = qualified_name(node.func)
        if name in FORBIDDEN_PYTHON_CALLS:
            findings.append({"ruleId": "forbidden-python-call", "path": relative, "line": node.lineno, "call": name})
        if name.startswith("subprocess."):
            for keyword in node.keywords:
                if keyword.arg == "shell" and isinstance(keyword.value, ast.Constant) and keyword.value.value is True:
                    findings.append({"ruleId": "subprocess-shell-true", "path": relative, "line": node.lineno, "call": name})
        if name == "yaml.load":
            findings.append({"ruleId": "unsafe-yaml-load", "path": relative, "line": node.lineno, "call": name})
    return findings


def scan_javascript_source(relative: str, source: str) -> list[dict[str, Any]]:
    """Return location-bearing findings for executable remote/dynamic sinks."""

    findings: list[dict[str, Any]] = []
    for sink, pattern in JAVASCRIPT_DANGEROUS_SINKS.items():
        for match in pattern.finditer(source):
            findings.append({
                "ruleId": "dangerous-javascript-sink",
                "sink": sink,
                "path": relative,
                "line": source.count("\n", 0, match.start()) + 1,
            })
    return findings


def canonical_javascript_sources(release: Path) -> list[Path]:
    """Return authored browser sources once, excluding the reproducible bundle."""

    app = release / "app"
    sources = [app / "toolA.html"]
    sources.extend(
        path for path in app.rglob("*")
        if path.is_file()
        and path.suffix.lower() in {".js", ".jsfrag"}
        and path.name != "classic-runtime.bundle.js"
    )
    return sorted(set(sources))


def python_import_inventory(release: Path) -> tuple[list[str], list[str]]:
    internal = {path.stem for path in (release / "app").glob("*.py")}
    internal.update(path.stem for path in (release / "tools").glob("*.py"))
    internal.update(path.name for path in (release / "app").iterdir() if path.is_dir())
    stdlib = set(getattr(sys, "stdlib_module_names", set()))
    optional = {"PIL"}
    external: set[str] = set()
    optional_seen: set[str] = set()
    for path in sorted((release / "app").rglob("*.py")) + sorted((release / "tools").glob("*.py")):
        tree = ast.parse(path.read_text(encoding="utf-8", errors="strict"), filename=str(path))
        for node in ast.walk(tree):
            modules: list[str] = []
            if isinstance(node, ast.Import):
                modules = [alias.name.split(".", 1)[0] for alias in node.names]
            elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
                modules = [node.module.split(".", 1)[0]]
            for module in modules:
                if module in optional:
                    optional_seen.add(module)
                elif module not in stdlib and module not in internal:
                    external.add(module)
    return sorted(external), sorted(optional_seen)


def write_json_atomic(path: Path, value: dict[str, Any]) -> None:
    path = path.expanduser().absolute()
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=path.parent, delete=False) as handle:
        json.dump(value, handle, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
        temporary = Path(handle.name)
    os.replace(temporary, path)


def audit_release(release: Path) -> dict[str, Any]:
    release = release.resolve(strict=True)
    policy = strict_json(release / POLICY_NAME)
    failures: list[dict[str, Any]] = []
    text_files: list[Path] = []
    all_files: list[Path] = []
    forbidden_suffixes = {str(value).lower() for value in policy["forbiddenCredentialFileSuffixes"]}

    for path in sorted(release.rglob("*")):
        relative = path.relative_to(release).as_posix()
        if path.is_symlink():
            failures.append({"ruleId": "symlink-forbidden", "path": relative})
            continue
        if not path.is_file():
            continue
        if not stat.S_ISREG(path.stat().st_mode):
            failures.append({"ruleId": "special-file-forbidden", "path": relative})
            continue
        all_files.append(path)
        if path.suffix.lower() in forbidden_suffixes:
            failures.append({"ruleId": "credential-file-forbidden", "path": relative})
        if path.suffix.lower() in TEXT_SUFFIXES:
            text_files.append(path)

    secret_findings: list[dict[str, Any]] = []
    sast_findings: list[dict[str, Any]] = []
    for path in text_files:
        relative = path.relative_to(release).as_posix()
        source = path.read_text(encoding="utf-8", errors="strict")
        secret_findings.extend(scan_secret_text(relative, source))
        if path.suffix.lower() == ".py":
            sast_findings.extend(scan_python_source(relative, source))
        if path.suffix.lower() == ".sh":
            shell_rules = {
                "pipe-download-to-shell": r"(?:curl|wget)[^\n|]*\|\s*(?:ba)?sh\b",
                "shell-eval": r"(^|[;\n]\s*)eval\s+",
                "chmod-777": r"\bchmod\s+(?:-R\s+)?777\b",
                "unsafe-mktemp": r"\bmktemp\s+-u\b",
            }
            for rule_id, expression in shell_rules.items():
                for match in re.finditer(expression, source, re.MULTILINE):
                    sast_findings.append({"ruleId": rule_id, "path": relative, "line": source.count("\n", 0, match.start()) + 1})

    javascript_sources = canonical_javascript_sources(release)
    source_by_path = {
        path: path.read_text(encoding="utf-8", errors="strict")
        for path in javascript_sources
    }
    javascript_findings: list[dict[str, Any]] = []
    for path, source in source_by_path.items():
        javascript_findings.extend(
            scan_javascript_source(path.relative_to(release).as_posix(), source)
        )
    app_sources = "\n".join(source_by_path.values())
    sink_counts = {
        key: sum(1 for row in javascript_findings if row["sink"] == key)
        for key in JAVASCRIPT_DANGEROUS_SINKS
    }
    sink_counts.update({
        "innerHtmlAssignmentsReviewedInventory": len(re.findall(r"\.innerHTML\s*=", app_sources)),
        "insertAdjacentHtmlReviewedInventory": len(re.findall(r"\.insertAdjacentHTML\s*\(", app_sources)),
    })
    for key, expected in policy["javascriptSinks"].items():
        if key == "inventoryGrowthAllowed":
            continue
        if sink_counts.get(key) != expected:
            failures.append({"ruleId": "javascript-sink-inventory-mismatch", "sink": key, "expected": expected, "actual": sink_counts.get(key)})

    external_imports, optional_imports = python_import_inventory(release)
    if external_imports:
        failures.append({"ruleId": "undeclared-python-dependency", "modules": external_imports})
    requirements = [
        line.strip() for line in (release / "requirements.txt").read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.lstrip().startswith("#")
    ]
    if requirements:
        failures.append({"ruleId": "mandatory-requirements-not-empty", "entries": requirements})

    sbom = strict_json(release / "R9J2_SOURCE_SBOM.cdx.json")
    sbom_components = sbom.get("components") if isinstance(sbom, dict) else None
    if not (
        isinstance(sbom, dict)
        and sbom.get("bomFormat") == "CycloneDX"
        and sbom.get("specVersion") == "1.5"
        and isinstance(sbom_components, list)
        and len(sbom_components) == policy["licenseEvidence"]["declaredRuntimeThirdPartyComponents"]
    ):
        failures.append({"ruleId": "source-sbom-invalid"})
    if not (release / policy["licenseEvidence"]["policy"]).is_file():
        failures.append({"ruleId": "license-policy-missing"})

    protected_results: dict[str, str] = {}
    for relative, expected in policy["protectedApplicationFiles"].items():
        path = release / relative
        actual = sha256_file(path) if path.is_file() else "MISSING"
        protected_results[relative] = actual
        if actual != expected:
            failures.append({"ruleId": "protected-application-file-mismatch", "path": relative, "expected": expected, "actual": actual})

    failures.extend(secret_findings)
    failures.extend(sast_findings)
    failures.extend(javascript_findings)
    report = {
        "schemaVersion": 1,
        "gateId": "R9J2_SECURITY_SUPPLY_CHAIN_GATE",
        "status": "PASS" if not failures else "FAIL",
        "release": str(release),
        "releaseManifestSha256": sha256_file(release / "SHA256SUMS.txt") if (release / "SHA256SUMS.txt").is_file() else None,
        "filesScanned": len(all_files),
        "textFilesScanned": len(text_files),
        "secretRuleCount": len(SECRET_RULES),
        "secretFindings": secret_findings,
        "sastFindings": sast_findings,
        "javascriptFindings": javascript_findings,
        "javascriptSourceFilesScanned": len(javascript_sources),
        "pythonMandatoryThirdPartyImports": external_imports,
        "pythonOptionalImportsSeen": optional_imports,
        "requirementsEntries": requirements,
        "javascriptSinkInventory": sink_counts,
        "sourceSbomThirdPartyComponentCount": len(sbom_components) if isinstance(sbom_components, list) else None,
        "protectedApplicationSha256": protected_results,
        "failures": failures,
        "evidenceLimit": policy["evidenceLimit"],
    }
    return report


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--release", type=Path, default=DEFAULT_RELEASE)
    parser.add_argument("--json-output", type=Path)
    args = parser.parse_args()
    report = audit_release(args.release)
    if args.json_output:
        write_json_atomic(args.json_output, report)
    print(json.dumps(report, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False))
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
