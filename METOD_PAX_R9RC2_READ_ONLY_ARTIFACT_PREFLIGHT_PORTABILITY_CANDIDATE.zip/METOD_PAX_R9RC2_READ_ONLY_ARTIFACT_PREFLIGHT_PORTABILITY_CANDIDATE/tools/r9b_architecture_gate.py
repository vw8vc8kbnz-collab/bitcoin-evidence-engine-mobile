#!/usr/bin/env python3
from __future__ import annotations

"""Fail-closed R9B package and native-module architecture gate."""

import argparse
import ast
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path


class GateFailure(RuntimeError):
    pass


def strict_object(path: Path) -> dict:
    def pairs(items):
        value = {}
        for key, child in items:
            if key in value:
                raise GateFailure(f"duplicate JSON key {key!r} in {path}")
            value[key] = child
        return value

    result = json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=pairs)
    if not isinstance(result, dict):
        raise GateFailure(f"{path} must contain one JSON object")
    return result


def normalized_relative(root: Path, relative: str) -> Path:
    candidate = (root / relative).resolve()
    resolved_root = root.resolve()
    if candidate != resolved_root and resolved_root not in candidate.parents:
        raise GateFailure(f"path escapes release root: {relative}")
    return candidate


def python_imports(path: Path) -> tuple[set[str], set[str]]:
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    absolute: set[str] = set()
    relative: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            absolute.update(alias.name.split(".", 1)[0] for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            if node.level:
                relative.add(str(node.module or ""))
            elif node.module:
                absolute.add(node.module.split(".", 1)[0])
    return absolute, relative


STATIC_IMPORT_RE = re.compile(
    r"^\s*import\s+(?:[^;\n]*?\s+from\s+)?[\"']([^\"']+)[\"']\s*;?\s*$",
    re.MULTILINE,
)
SCRIPT_RE = re.compile(r"<script\b([^>]*)>(.*?)</script\s*>", re.IGNORECASE | re.DOTALL)
STYLE_RE = re.compile(r"<style\b[^>]*>.*?</style\s*>", re.IGNORECASE | re.DOTALL)
ATTRIBUTE_RE = re.compile(
    r"([:\w-]+)\s*=\s*(?:\"([^\"]*)\"|'([^']*)')",
    re.IGNORECASE,
)


def module_script_sources(html: str) -> list[tuple[str, str]]:
    result: list[tuple[str, str]] = []
    for raw_attributes, body in SCRIPT_RE.findall(html):
        attributes = {
            name.lower(): double if double != "" else single
            for name, double, single in ATTRIBUTE_RE.findall(raw_attributes)
        }
        if attributes.get("type", "").strip().lower() == "module":
            result.append((attributes.get("src", ""), body))
    return result


def literal_assignment(source: str, variable: str) -> set[str]:
    tree = ast.parse(source)
    for node in tree.body:
        if isinstance(node, ast.Assign):
            if any(isinstance(target, ast.Name) and target.id == variable for target in node.targets):
                value = ast.literal_eval(node.value)
                if not isinstance(value, set) or not all(isinstance(item, str) for item in value):
                    break
                return value
    raise GateFailure(f"{variable} must be one literal string set")


def check_python(release: Path, rules: dict) -> list[str]:
    package_root = normalized_relative(release, str(rules["packageRoot"]))
    expected = rules.get("allowedRelativeImports")
    if not isinstance(expected, dict):
        raise GateFailure("python.allowedRelativeImports must be an object")
    actual_files = {
        path.relative_to(package_root).as_posix()
        for path in package_root.rglob("*.py")
        if "__pycache__" not in path.parts
    }
    if actual_files != set(expected):
        raise GateFailure(
            f"Python module inventory drift: expected {sorted(expected)}, got {sorted(actual_files)}"
        )
    forbidden = set(rules.get("forbiddenRuntimeImports") or [])
    for relative, allowed_relative in expected.items():
        path = package_root / relative
        absolute, local = python_imports(path)
        if absolute & forbidden:
            raise GateFailure(f"{relative} imports forbidden runtime owners: {sorted(absolute & forbidden)}")
        if local != set(allowed_relative):
            raise GateFailure(
                f"{relative} relative imports drift: expected {sorted(allowed_relative)}, got {sorted(local)}"
            )
    return [f"Python module inventory/import direction exact ({len(actual_files)} modules)"]


def check_frontend(release: Path, rules: dict, *, require_node: bool) -> list[str]:
    expected_imports = rules.get("moduleImports")
    forbidden_tokens = rules.get("forbiddenTokens")
    if not isinstance(expected_imports, dict) or not isinstance(forbidden_tokens, dict):
        raise GateFailure("frontend module rules must be objects")

    shell_static_files = set(rules.get("shellStaticFiles") or [])
    if len(shell_static_files) != 41:
        raise GateFailure(f"semantic shell asset inventory drift: {len(shell_static_files)}")
    module_root = normalized_relative(release, str(rules["moduleRoot"]))
    actual_modules = {
        path.relative_to(release).as_posix()
        for path in module_root.rglob("*.js")
        if path.is_file() and path.relative_to(release).as_posix() not in {
            f"app/{relative}" for relative in shell_static_files
        }
    }
    if actual_modules != set(expected_imports):
        raise GateFailure(
            f"frontend module inventory drift: expected {sorted(expected_imports)}, got {sorted(actual_modules)}"
        )

    dom_owners = set(rules.get("domOwnerModules") or [])
    network_owners = set(rules.get("networkOwnerModules") or [])
    if not dom_owners or not dom_owners <= actual_modules:
        raise GateFailure(f"DOM owner inventory drift: {sorted(dom_owners)}")
    if network_owners != {"app/tool-a/api/jobs.js", "app/tool-a/api/requests.js"}:
        raise GateFailure(f"network owner inventory drift: {sorted(network_owners)}")

    node = shutil.which("node")
    if require_node and not node:
        raise GateFailure("Node is required for the CI syntax boundary")
    for relative, allowed_imports in expected_imports.items():
        path = normalized_relative(release, relative)
        source = path.read_text(encoding="utf-8")
        line_count = len(source.splitlines())
        max_lines = int(rules.get("maxNativeModuleLines", 500))
        if line_count > max_lines:
            raise GateFailure(f"{relative} exceeds native module line limit: {line_count}>{max_lines}")
        if relative == str(rules["entrypoint"]) and line_count > int(rules.get("maxEntrypointLines", 180)):
            raise GateFailure(f"{relative} exceeds entrypoint line limit: {line_count}")
        imports = STATIC_IMPORT_RE.findall(source)
        if imports != list(allowed_imports):
            raise GateFailure(
                f"{relative} imports drift: expected {allowed_imports}, got {imports}"
            )
        if re.search(r"\bimport\s*\(", source):
            raise GateFailure(f"{relative} may not use dynamic import")
        for specifier in imports:
            if not specifier.startswith("./") or ".." in Path(specifier).parts:
                raise GateFailure(f"{relative} has unsafe import {specifier!r}")
            target = (path.parent / specifier).resolve()
            if module_root.resolve() not in target.parents or not target.is_file():
                raise GateFailure(f"{relative} import target is outside the exact module tree")
        for token in forbidden_tokens.get(relative, []):
            if str(token).lower() in source.lower():
                raise GateFailure(f"{relative} contains forbidden runtime token {token!r}")
        if relative not in dom_owners:
            for token in ("document", "addEventListener"):
                if token.lower() in source.lower():
                    raise GateFailure(f"{relative} contains DOM/event token outside its reviewed owner")
        if relative not in network_owners:
            for token in ("fetch(", "XMLHttpRequest", "EventSource", "WebSocket"):
                if token.lower() in source.lower():
                    raise GateFailure(f"{relative} contains network token outside its reviewed owner")
        for token in ("localStorage", "sessionStorage"):
            if token.lower() in source.lower():
                raise GateFailure(f"{relative} contains forbidden storage token {token!r}")
        if node:
            completed = subprocess.run(
                [node, "--input-type=module", "--check"],
                input=source,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                timeout=10,
                check=False,
            )
            if completed.returncode != 0:
                raise GateFailure(f"Node syntax failed for {relative}: {completed.stdout[-1000:]}")

    html = normalized_relative(release, str(rules["html"])).read_text(encoding="utf-8")
    shell_rules = rules.get("semanticShell")
    if not isinstance(shell_rules, dict):
        raise GateFailure("semantic shell rules must be an object")
    inline_scripts = []
    for raw_attributes, body in SCRIPT_RE.findall(html):
        attributes = {
            name.lower(): double if double != "" else single
            for name, double, single in ATTRIBUTE_RE.findall(raw_attributes)
        }
        if not attributes.get("src") and body.strip():
            inline_scripts.append(body)
    if len(STYLE_RE.findall(html)) != int(shell_rules["inlineStyleElementCount"]):
        raise GateFailure("inline style-element count drift")
    if len(inline_scripts) != int(shell_rules["inlineScriptElementCount"]):
        raise GateFailure("inline script-element count drift")
    if html.count(f'<meta name="metod-shell-revision" content="{shell_rules["revision"]}"') != 1:
        raise GateFailure("semantic shell revision marker drift")
    if html.count(f'<main class="app" id="{shell_rules["mainId"]}"') != 1 or html.count("</main>") != 1:
        raise GateFailure("semantic main shell drift")
    if html.count(f'<footer id="{shell_rules["footerId"]}"') != 1 or html.count("</footer>") != 1:
        raise GateFailure("semantic footer shell drift")
    observed_phases = re.findall(r'data-r9h-style-phase="([^"]+)"', html)
    if observed_phases != list(shell_rules["stylePhases"]):
        raise GateFailure(f"semantic style phase order drift: {observed_phases}")

    shell_css = {path for path in shell_static_files if path.endswith(".css")}
    shell_js = {path for path in shell_static_files if path.endswith(".js")}
    if len(shell_css) != 7 or len(shell_js) != 34:
        raise GateFailure("semantic shell CSS/script split drift")
    for relative in sorted(shell_static_files):
        path = normalized_relative(release / "app", relative)
        if not path.is_file() or not path.read_bytes():
            raise GateFailure(f"semantic shell asset missing or empty: {relative}")
    if node:
        for relative in sorted(shell_js):
            completed = subprocess.run(
                [node, "--check", str(normalized_relative(release / "app", relative))],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                timeout=10,
                check=False,
            )
            if completed.returncode != 0:
                raise GateFailure(f"shell script syntax failed for {relative}: {completed.stdout[-1000:]}")

    scripts = module_script_sources(html)
    expected_src = str(rules["moduleScriptSrc"])
    if len(scripts) != 1 or scripts[0][0].split("?", 1)[0] != expected_src or scripts[0][1].strip():
        raise GateFailure(f"Tool A must load exactly one external module entrypoint: {expected_src}")

    bootstrap = normalized_relative(release, str(rules["entrypoint"])).read_text(encoding="utf-8")
    compatibility_global = str(rules["compatibilityGlobal"])
    legacy_read_globals = set(rules.get("legacyReadGlobals") or [])
    referenced_globals = set(re.findall(r"globalThis\.([A-Za-z_$][\w$]*)", bootstrap))
    published_globals = set(
        re.findall(r"defineProperty\(globalThis,\s*[\"']([A-Za-z_$][\w$]*)[\"']", bootstrap)
    )
    published_globals.update(re.findall(
        r"globalThis\.([A-Za-z_$][\w$]*)\s*=", bootstrap
    ))
    if published_globals != {compatibility_global}:
        raise GateFailure(f"published compatibility-global drift: {sorted(published_globals)}")
    if referenced_globals - published_globals != legacy_read_globals:
        raise GateFailure(
            "legacy read-global drift: "
            f"expected {sorted(legacy_read_globals)}, "
            f"got {sorted(referenced_globals - published_globals)}"
        )
    if len(published_globals) > int(rules["maxCompatibilityGlobals"]):
        raise GateFailure("too many temporary compatibility globals")
    dom_owner_tokens = rules.get("domOwnerRequiredTokens")
    if not isinstance(dom_owner_tokens, dict) or set(dom_owner_tokens) != dom_owners:
        raise GateFailure("reviewed DOM owner token inventory drift")
    for relative, required_tokens in dom_owner_tokens.items():
        if not isinstance(required_tokens, list) or not required_tokens:
            raise GateFailure(f"reviewed DOM owner tokens missing for {relative}")
        owner_source = normalized_relative(release, relative).read_text(encoding="utf-8")
        missing = [token for token in required_tokens if str(token) not in owner_source]
        if missing:
            raise GateFailure(f"{relative} no longer owns reviewed DOM behavior: {missing}")

    static_source = (release / "app/metod_app/http/static.py").read_text(encoding="utf-8")
    public_modules = literal_assignment(static_source, "PUBLIC_STATIC_MODULE_FILES")
    if public_modules != set(rules["publicStaticFiles"]):
        raise GateFailure(
            f"public module allowlist drift: expected {rules['publicStaticFiles']}, got {sorted(public_modules)}"
        )
    public_shell = literal_assignment(static_source, "PUBLIC_STATIC_SHELL_FILES")
    if public_shell != shell_static_files:
        raise GateFailure(
            f"public shell allowlist drift: expected {sorted(shell_static_files)}, got {sorted(public_shell)}"
        )
    return [
        f"frontend module inventory/import graph exact ({len(actual_modules)} modules)",
        f"native module size boundary enforced (max {int(rules.get('maxNativeModuleLines', 500))} lines)",
        "single read-only compatibility global and legacy read surface exact",
        f"explicit public module allowlist exact ({len(public_modules)} files)",
        f"semantic shell allowlist and asset split exact ({len(public_shell)} files)",
        "zero inline application style/script elements",
        f"reviewed DOM/event owner inventory exact ({len(dom_owners)} components)",
        f"reviewed network owner inventory exact ({len(network_owners)} modules)",
        f"native module syntax checked with Node: {bool(node)}",
    ]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--release", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--rules", type=Path)
    parser.add_argument("--require-node", action="store_true")
    args = parser.parse_args()
    release = args.release.expanduser().resolve()
    rules_path = (args.rules or (release / "R9B_ARCHITECTURE_RULES.json")).expanduser().resolve()
    try:
        rules = strict_object(rules_path)
        if rules.get("contractId") != "R9B_FOUNDATION_ARCHITECTURE_RULES":
            raise GateFailure("architecture contractId mismatch")
        outcomes = check_python(release, rules["python"])
        outcomes.extend(check_frontend(release, rules["frontend"], require_node=args.require_node))
    except Exception as exc:
        print(f"R9B ARCHITECTURE GATE: FAIL: {exc}", file=sys.stderr)
        return 1
    for outcome in outcomes:
        print(f"OK: {outcome}")
    print("R9B ARCHITECTURE GATE: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
