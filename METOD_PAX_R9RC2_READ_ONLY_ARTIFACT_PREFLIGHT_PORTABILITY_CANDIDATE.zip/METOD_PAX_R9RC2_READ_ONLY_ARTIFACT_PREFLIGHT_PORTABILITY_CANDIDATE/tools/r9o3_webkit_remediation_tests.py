#!/usr/bin/env python3
from __future__ import annotations

import re
import json
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT.parent


@unittest.skipUnless(
    json.loads((ROOT / "RELEASE_IDENTITY.json").read_text(encoding="utf-8"))["canonicalCandidate"]["releaseRevision"] == "R9O3",
    "R9O3 remediation contract is historical after a newer canonical checkpoint",
)
class R9O3WebKitRemediationTests(unittest.TestCase):
    def test_browser_driver_waits_for_completed_dxf_requests_before_reload(self) -> None:
        source = (REPO / "tools/r9a_browser_driver.js").read_text(encoding="utf-8")
        self.assertIn("page.on('requestfinished'", source)
        self.assertIn("page.on('requestfailed'", source)
        self.assertEqual(source.count("network.waitForQuiescence({ routePrefix: '/embedded_dxfs/'"), 2)
        self.assertNotIn("ResizeObserver loop completed with undelivered notifications.*allow", source)

    def test_controlled_cancel_hold_is_rearmed_for_each_profile_and_side(self) -> None:
        driver = (REPO / "tools/r9a_browser_driver.js").read_text(encoding="utf-8")
        oracle = (REPO / "tools/r9a_browser_oracle.py").read_text(encoding="utf-8")
        self.assertIn("function armControlledOptimizerHold", driver)
        self.assertIn("flag: 'wx'", driver)
        self.assertIn("args.optimizerHoldRoots.golden", driver)
        self.assertIn("args.optimizerHoldRoots.candidate", driver)
        self.assertIn('"--optimizer-hold-root"', oracle)
        self.assertIn('"golden": str(golden_server.optimizer_hold_root)', oracle)
        self.assertIn('"candidate": str(candidate_server.optimizer_hold_root)', oracle)

    def test_resize_observers_do_not_mutate_layout_synchronously(self) -> None:
        grain = (ROOT / "app/tool-a/components/grain-preview.js").read_text(encoding="utf-8")
        swatch = (ROOT / "app/toolA_material_swatch_renderer.js").read_text(encoding="utf-8")
        legacy = (ROOT / "app/tool-a/shell/script-06-legacy-application-runtime.js").read_text(encoding="utf-8")
        self.assertIn("if (box.width === lastWidth && box.height === lastHeight) return", grain)
        self.assertNotIn('observer.observe(card)', grain)
        self.assertRegex(swatch, r"(?s)new root\.ResizeObserver\(function\(entries\).*requestAnimationFrame")
        self.assertRegex(legacy, r"(?s)new ResizeObserver\(\(entries\)=>.*requestAnimationFrame")
        self.assertIn("if(cv.width !== nextWidth)", legacy)
        self.assertIn("if(cv.height !== nextHeight)", legacy)

    def test_admin_393px_webkit_layout_has_explicit_shrink_rules(self) -> None:
        css = (ROOT / "app/metod_app/admin/assets/admin.css").read_text(encoding="utf-8")
        self.assertIn("@media (max-width:640px)", css)
        self.assertIn("header{flex-wrap:wrap", css)
        self.assertIn(".adminShell{grid-template-columns:58px minmax(0,1fr)", css)
        self.assertIn(".admin-u-005{min-width:0;width:100%;box-sizing:border-box;}", css)
        self.assertNotIn("overflow-x:hidden", css)


if __name__ == "__main__":
    unittest.main(verbosity=2)
