#!/usr/bin/env python3
from __future__ import annotations

"""Fail-closed semantic-shell proof for the bundled R9RC1 architecture."""

import ast
import hashlib
import json
import re
import shutil
import subprocess
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
HTML = APP / "toolA.html"
BUNDLE_MANIFEST = APP / "tool-a/runtime/bundle-manifest.json"
PARTS_MANIFEST = APP / "tool-a/runtime/legacy-source/parts.json"
R9RC1_RULES = ROOT / "R9RC1_PROFESSIONAL_ARCHITECTURE_RULES.json"
R9B_RULES = ROOT / "R9B_ARCHITECTURE_RULES.json"


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def literal_set(path: Path, name: str) -> set[str]:
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    for node in tree.body:
        if not isinstance(node, (ast.Assign, ast.AnnAssign)):
            continue
        targets = node.targets if isinstance(node, ast.Assign) else [node.target]
        if any(isinstance(target, ast.Name) and target.id == name for target in targets):
            value = node.value
            if isinstance(value, ast.Call) and value.args:
                value = value.args[0]
            return set(ast.literal_eval(value))
    raise AssertionError(f"missing literal set {name}")


class SemanticShellTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.html = HTML.read_text(encoding="utf-8")
        cls.manifest = json.loads(BUNDLE_MANIFEST.read_text(encoding="utf-8"))
        cls.parts = json.loads(PARTS_MANIFEST.read_text(encoding="utf-8"))
        cls.r9rc1 = json.loads(R9RC1_RULES.read_text(encoding="utf-8"))
        cls.frontend = json.loads(R9B_RULES.read_text(encoding="utf-8"))["frontend"]

    def test_01_manifest_identity_and_inventory_are_exact(self) -> None:
        self.assertEqual(self.manifest["schemaVersion"], 1)
        self.assertEqual(self.manifest["build"], "R9RC1_PROFESSIONAL_ARCHITECTURE_COMPLETION")
        shell = self.r9rc1["toolAShell"]
        self.assertEqual(len(self.manifest["classic"]["sources"]), shell["classicSourceCount"])
        self.assertEqual(len(self.manifest["styles"]["sources"]), shell["styleSourceCount"])
        self.assertEqual(len(self.parts["fragments"]), shell["legacyFragmentCount"])
        self.assertEqual(self.manifest["foundationCompatibilityGlobals"], [])

    def test_02_generated_bundle_payloads_match_their_sealed_records(self) -> None:
        for phase in ("classic", "styles"):
            record = self.manifest[phase]
            payload = (APP / record["output"]).read_bytes()
            self.assertEqual(len(payload), record["bytes"], phase)
            self.assertEqual(digest(payload), record["sha256"], phase)

    def test_03_fragmented_legacy_source_is_ordered_bounded_and_byte_exact(self) -> None:
        fragments = self.parts["fragments"]
        payload = b"".join((APP / item["path"]).read_bytes() for item in fragments)
        self.assertEqual(len(payload), self.parts["bytes"])
        self.assertEqual(digest(payload), self.parts["sha256"])
        self.assertEqual(self.parts["assembly"], "byte-exact-concatenation-without-separators")
        self.assertLessEqual(self.parts["maximumFragmentLines"], 900)
        legacy = next(item for item in self.manifest["classic"]["sources"] if item.get("sourceType"))
        self.assertEqual([item["path"] for item in fragments], [item["path"] for item in legacy["fragments"]])

    def test_04_every_authoritative_source_matches_manifest_hash_and_size(self) -> None:
        for phase in ("classic", "styles"):
            for item in self.manifest[phase]["sources"]:
                if item.get("sourceType") == "ordered-lexical-fragments":
                    payload = b"".join((APP / part["path"]).read_bytes() for part in item["fragments"])
                else:
                    payload = (APP / item["path"]).read_bytes()
                self.assertEqual(len(payload), item["bytes"], item["path"])
                self.assertEqual(digest(payload), item["sha256"], item["path"])

    def test_05_one_ordered_stylesheet_bundle_is_loaded(self) -> None:
        linked = re.findall(r'<link[^>]+rel="stylesheet"[^>]+href="([^"?]+)', self.html)
        self.assertEqual(linked, self.r9rc1["toolAShell"]["stylesheets"])
        self.assertEqual(self.html.count('data-r9rc1-style-bundle="ordered-cascade"'), 1)

    def test_06_three_script_phases_are_once_only_and_ordered(self) -> None:
        linked = re.findall(r'<script[^>]+src="([^"?]+)[^"]*"[^>]*></script>', self.html)
        self.assertEqual(linked, self.r9rc1["toolAShell"]["scripts"])
        self.assertEqual(len(linked), len(set(linked)))
        self.assertIn('type="module" src="tool-a/bootstrap.js', self.html)

    def test_07_shell_has_no_inline_executable_or_presentation_owners(self) -> None:
        self.assertIsNone(re.search(r"<style\b", self.html, re.IGNORECASE))
        self.assertIsNone(re.search(r"\sstyle\s*=", self.html, re.IGNORECASE))
        self.assertIsNone(re.search(r"\son[a-z]+\s*=", self.html, re.IGNORECASE))
        self.assertIsNone(
            re.search(r"<script(?![^>]*\bsrc=)[^>]*>[\s\S]*?</script>", self.html, re.IGNORECASE)
        )

    def test_08_semantic_main_footer_and_regions_are_exact(self) -> None:
        for token in (
            '<main class="app" id="toolAAppShell" aria-label="METOD/PAX configurator">',
            '<div class="left" role="region" aria-label="Paneelvoorbeeld">',
            '<div class="right" role="region" aria-label="Configuratiestappen">',
            '<div class="stepbar" id="stepbar" role="navigation"',
            '<footer id="wizardFooter"',
        ):
            self.assertEqual(self.html.count(token), 1, token)
        self.assertEqual(self.html.count("</main>"), 1)
        self.assertEqual(self.html.count("</footer>"), 1)

    def test_09_public_static_allowlists_publish_only_current_artifacts(self) -> None:
        static = APP / "metod_app/http/static.py"
        self.assertEqual(literal_set(static, "PUBLIC_STATIC_ROOT_FILES"), {
            "toolA.html", "embedded_dxfs_manifest.json",
        })
        self.assertEqual(literal_set(static, "PUBLIC_STATIC_SHELL_FILES"), {
            "tool-a/styles/tool-a.bundle.css",
            "tool-a/runtime/classic-runtime.bundle.js",
            "tool-a/shell/script-01-early-catalog-bootstrap.js",
        })
        self.assertEqual(literal_set(static, "PUBLIC_STATIC_MODULE_FILES"), set(self.frontend["publicStaticFiles"]))

    def test_10_native_module_architecture_remains_bounded(self) -> None:
        self.assertEqual(len(self.frontend["moduleImports"]), 19)
        self.assertEqual(len(self.frontend["domOwnerModules"]), 10)
        self.assertEqual(set(self.frontend["networkOwnerModules"]), {
            "app/tool-a/api/jobs.js", "app/tool-a/api/requests.js",
        })

    def test_11_fix_layers_and_current_architecture_marker_are_preserved(self) -> None:
        css = (APP / self.manifest["styles"]["output"]).read_text(encoding="utf-8")
        js = (APP / self.manifest["classic"]["output"]).read_text(encoding="utf-8")
        self.assertGreaterEqual(len(re.findall(r"FIX\d+", css, re.IGNORECASE)), 70)
        self.assertGreaterEqual(len(re.findall(r"fix\d+", js, re.IGNORECASE)), 80)
        self.assertEqual(self.r9rc1["buildId"], "R9RC1_PROFESSIONAL_ARCHITECTURE_COMPLETION")
        self.assertIn("R9RC1 generated", css)
        self.assertIn("R9RC1 generated", js)

    def test_12_bundles_are_reproducible_and_active_javascript_parses(self) -> None:
        check = subprocess.run(
            [sys.executable, "-B", "tools/r9rc1_build_toola_assets.py", "--check"],
            cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            timeout=30, check=False,
        )
        self.assertEqual(check.returncode, 0, check.stdout)
        node = shutil.which("node")
        if not node:
            self.skipTest("Node unavailable")
        paths = [APP / self.manifest["classic"]["output"]]
        paths.extend(APP / item for item in self.frontend["publicStaticFiles"] if item.endswith(".js"))
        for path in paths:
            completed = subprocess.run(
                [node, "--check", str(path)], stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT, text=True, timeout=10, check=False,
            )
            self.assertEqual(completed.returncode, 0, f"{path.relative_to(APP)}: {completed.stdout[-800:]}")


if __name__ == "__main__":
    unittest.main(verbosity=2)
