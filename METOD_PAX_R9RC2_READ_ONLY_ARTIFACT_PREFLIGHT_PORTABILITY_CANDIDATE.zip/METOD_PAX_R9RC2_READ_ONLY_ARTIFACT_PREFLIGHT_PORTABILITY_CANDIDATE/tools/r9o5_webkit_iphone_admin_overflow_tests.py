#!/usr/bin/env python3
from __future__ import annotations

import re
import subprocess
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT.parent


class R9O5WebKitIphoneAdminOverflowTests(unittest.TestCase):
    def test_browser_driver_waits_for_completed_dxf_requests_before_reload(self) -> None:
        source = (REPO / "tools/r9a_browser_driver.js").read_text(encoding="utf-8")
        self.assertIn("page.on('requestfinished'", source)
        self.assertIn("page.on('requestfailed'", source)
        self.assertEqual(source.count("network.waitForQuiescence({ routePrefix: '/embedded_dxfs/'"), 2)
        self.assertNotIn("ResizeObserver loop completed with undelivered notifications.*allow", source)

    def test_controlled_cancel_hold_is_rearmed_for_each_profile_and_side(self) -> None:
        driver = (REPO / "tools/r9a_browser_driver.js").read_text(encoding="utf-8")
        oracle = (REPO / "tools/r9a_browser_oracle.py").read_text(encoding="utf-8")
        self.assertIn("function armControlledOptimizerHold", driver)
        self.assertIn("flag: 'wx'", driver)
        self.assertIn("args.optimizerHoldRoots.golden", driver)
        self.assertIn("args.optimizerHoldRoots.candidate", driver)
        self.assertIn('"--optimizer-hold-root"', oracle)
        self.assertIn('"golden": str(golden_server.optimizer_hold_root)', oracle)
        self.assertIn('"candidate": str(candidate_server.optimizer_hold_root)', oracle)

    def test_resize_observers_do_not_mutate_layout_synchronously(self) -> None:
        grain = (ROOT / "app/tool-a/components/grain-preview.js").read_text(encoding="utf-8")
        swatch = (ROOT / "app/toolA_material_swatch_renderer.js").read_text(encoding="utf-8")
        legacy = (ROOT / "app/tool-a/shell/script-06-legacy-application-runtime.js").read_text(encoding="utf-8")
        self.assertIn("if (box.width === lastWidth && box.height === lastHeight) return", grain)
        self.assertNotIn('observer.observe(card)', grain)
        self.assertRegex(swatch, r"(?s)new root\.ResizeObserver\(function\(entries\).*requestAnimationFrame")
        self.assertRegex(legacy, r"(?s)new ResizeObserver\(\(entries\)=>.*requestAnimationFrame")
        self.assertIn("if(cv.width !== nextWidth)", legacy)
        self.assertIn("if(cv.height !== nextHeight)", legacy)

    def test_admin_393px_webkit_layout_has_explicit_shrink_rules(self) -> None:
        css = (ROOT / "app/metod_app/admin/assets/admin.css").read_text(encoding="utf-8")
        self.assertIn("@media (max-width:640px)", css)
        self.assertIn("header{flex-wrap:wrap", css)
        self.assertIn(".adminShell{grid-template-columns:58px minmax(0,1fr)", css)
        self.assertIn(".admin-u-002,.admin-u-004,.tabs,.mbDetailsHead,.mbFileLine{min-width:0;}", css)
        self.assertIn(".tabs{max-width:100%;}", css)
        self.assertIn(".admin-u-005{min-width:0;width:100%;box-sizing:border-box;}", css)
        self.assertNotIn("overflow-x:hidden", css)

    def test_browser_evidence_reports_the_elements_that_exceed_the_viewport(self) -> None:
        source = (REPO / "tools/r9a_browser_driver.js").read_text(encoding="utf-8")
        self.assertIn("const overflowElements = Array.from(document.querySelectorAll('body *'))", source)
        self.assertIn("rect.right > viewportWidth + 1 || rect.left < -1", source)
        self.assertIn("overflowElements: adminPresentation.overflowElements", source)
        self.assertNotIn("body.style.overflowX", source)

    def test_r9o6_runner_restores_evidence_ownership_before_hashing(self) -> None:
        runner = (REPO / "operations/RUN_R9O6_EXTERNAL_BROWSER_GATE_TMUX.sh").read_text(encoding="utf-8")
        ownership = 'sudo chown -R "$(id -u):$(id -g)" "$AUDIT_ROOT/evidence"'
        exit_record = "printf 'R9O6_DOCKER_EXIT=%s\\n'"
        checksum = "xargs -0 -r sha256sum > SHA256SUMS.txt"
        self.assertLess(runner.index(ownership), runner.index(exit_record))
        self.assertLess(runner.index(exit_record), runner.index(checksum))
        self.assertIn("! -name 'SHA256SUMS.txt'", runner)

    def test_r9i_clean_gate_accepts_the_current_contract_without_shadowing_it(self) -> None:
        completed = subprocess.run(
            [sys.executable, "-B", str(ROOT / "tools/r9i_clean_code_gate.py"), "--release", str(ROOT)],
            cwd=ROOT,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=20,
            check=False,
        )
        self.assertEqual(completed.returncode, 0, completed.stdout)
        self.assertIn('"status": "PASS"', completed.stdout)


if __name__ == "__main__":
    unittest.main(verbosity=2)
