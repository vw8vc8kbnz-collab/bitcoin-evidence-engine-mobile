#!/usr/bin/env python3
from __future__ import annotations

"""Seal and reproduce the R9L3 static and generic HTTP adapter behavior."""

import argparse
import ast
import hashlib
import io
import json
import os
import sys
import tempfile
import types
from pathlib import Path
from unittest import mock


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
SERVER = APP / "server_py.py"
FIXTURE = ROOT / "R9L4_STATIC_HTTP_BEFORE_FIXTURE.json"
os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")
_STATE_TEMP = tempfile.TemporaryDirectory(prefix="r9l4_static_http_import_")
os.environ.setdefault("METOD_STATE_ROOT", str(Path(_STATE_TEMP.name) / "state"))
sys.path.insert(0, str(APP))

import server_py as server  # noqa: E402
from metod_app.http.static import (  # noqa: E402
    BLOCKED_STATIC_TOP_LEVEL,
    PUBLIC_STATIC_MODULE_FILES,
    PUBLIC_STATIC_ROOT_FILES,
    PUBLIC_STATIC_SHELL_FILES,
    is_blocked_static_relpath,
    is_public_static_relpath,
)


TOP_LEVEL_OWNERS = ("_is_public_static_relpath", "_is_blocked_static_relpath")
HANDLER_OWNERS = (
    "_prepare_html", "translate_path", "guess_type", "end_headers",
    "_send_text", "_send_json", "_stream_file",
)


def _sha256(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def _source_metrics() -> dict[str, object]:
    source = SERVER.read_text(encoding="utf-8", errors="strict")
    tree = ast.parse(source)
    owners: dict[str, object] = {}
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name in TOP_LEVEL_OWNERS:
            segment = ast.get_source_segment(source, node)
            assert segment is not None
            owners[node.name] = {
                "lines": len(segment.splitlines()),
                "bytes": len(segment.encode("utf-8")),
                "sha256": _sha256(segment.encode("utf-8")),
            }
        if isinstance(node, ast.ClassDef) and node.name == "Handler":
            for child in node.body:
                if isinstance(child, ast.FunctionDef) and child.name in HANDLER_OWNERS:
                    segment = ast.get_source_segment(source, child)
                    assert segment is not None
                    owners[f"Handler.{child.name}"] = {
                        "lines": len(segment.splitlines()),
                        "bytes": len(segment.encode("utf-8")),
                        "sha256": _sha256(segment.encode("utf-8")),
                    }
    expected = set(TOP_LEVEL_OWNERS) | {f"Handler.{name}" for name in HANDLER_OWNERS}
    if set(owners) != expected:
        raise RuntimeError(f"owner inventory mismatch: {sorted(owners)}")
    return {
        "server": {
            "bytes": len(source.encode("utf-8")),
            "lines": len(source.splitlines()),
            "sha256": _sha256(source.encode("utf-8")),
        },
        "activeOwnerSource": owners,
        "publicInventory": {
            "rootFiles": len(PUBLIC_STATIC_ROOT_FILES),
            "moduleFiles": len(PUBLIC_STATIC_MODULE_FILES),
            "shellFiles": len(PUBLIC_STATIC_SHELL_FILES),
            "blockedTopLevel": sorted(BLOCKED_STATIC_TOP_LEVEL),
        },
    }


def _static_policy_matrix() -> dict[str, dict[str, bool]]:
    paths = (
        "", "toolA.html", "tool-a/bootstrap.js", "tool-a/styles/base.css",
        "embedded_dxfs/a.dxf", "embedded_dxfs/a.txt", "assets/logo.svg",
        "assets/logo.js", "config/app.json", "jobs/JOB/output/a.dxf",
        ".env", "assets/.secret.svg", "server_py.py", "run.sh",
        "../toolA.html", "tool-a/unknown.js",
    )
    return {
        path: {
            "public": bool(is_public_static_relpath(path)),
            "blocked": bool(is_blocked_static_relpath(path)),
        }
        for path in paths
    }


def _response_handler(path: str = "/health/live"):
    handler = object.__new__(server.Handler)
    handler.path = path
    handler.headers = {}
    handler.statuses = []
    handler.sent_headers = []
    handler.wfile = io.BytesIO()
    handler.send_response = types.MethodType(
        lambda self, code, *args, **kwargs: self.statuses.append(int(code)), handler
    )
    handler.send_header = types.MethodType(
        lambda self, key, value: self.sent_headers.append((str(key), str(value))), handler
    )
    handler.end_headers = types.MethodType(lambda self: None, handler)
    return handler


def _response_snapshot(handler) -> dict[str, object]:
    return {
        "status": handler.statuses[-1],
        "headers": [[key, value] for key, value in handler.sent_headers],
        "bodyHex": handler.wfile.getvalue().hex(),
        "bodySha256": _sha256(handler.wfile.getvalue()),
    }


def _response_matrix(root: Path) -> dict[str, object]:
    text = _response_handler()
    server.Handler._send_text(text, "hallo", 202, "text/plain; charset=utf-8")
    html = _response_handler("/")
    server.Handler._send_text(html, "<script>ok()</script><style>x{}</style>", 200, "text/html; charset=utf-8")
    html_body = html.wfile.getvalue().decode("utf-8")
    html._csp_nonce = "<sealed>"
    html_snapshot = _response_snapshot(html)
    html_snapshot["body"] = __import__("re").sub(r'nonce="[^"]+"', 'nonce="<nonce>"', html_body)
    html_snapshot.pop("bodyHex")
    html_snapshot.pop("bodySha256")
    js = _response_handler()
    server.Handler._send_json(js, {"z": 1, "ok": True}, 201)
    bad = _response_handler()
    server.Handler._send_json(bad, {"bad": object()}, 200)
    stream_file = root / "stream.bin"
    stream_file.write_bytes(b"R9L4-stream-bytes")
    stream = _response_handler()
    server.Handler._stream_file(
        stream, stream_file, content_type="application/octet-stream",
        download_name='bad/name\".bin', max_bytes=100,
    )
    limited = _response_handler()
    server.Handler._stream_file(
        limited, stream_file, content_type="application/octet-stream",
        download_name="large.bin", max_bytes=2,
    )
    return {
        "text": _response_snapshot(text),
        "html": html_snapshot,
        "json": _response_snapshot(js),
        "jsonSerializationFailure": _response_snapshot(bad),
        "stream": _response_snapshot(stream),
        "streamOverLimit": _response_snapshot(limited),
    }


def _translation_matrix(root: Path) -> dict[str, object]:
    app_root = root / "app"
    state_root = root / "state"
    dxf_root = state_root / "dxf"
    for path, data in (
        (app_root / "toolA.html", b"tool"),
        (app_root / "assets/logo.svg", b"svg"),
        (state_root / "embedded_dxfs_manifest.json", b"{}"),
        (dxf_root / "safe/a.dxf", b"dxf"),
    ):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
    handler = object.__new__(server.Handler)
    paths = (
        "/", "/toolA.html?x=1", "/admin", "/assets/logo.svg",
        "/embedded_dxfs_manifest.json", "/embedded_dxfs/safe/a.dxf",
        "/embedded_dxfs/../secret.dxf", "/config/app.json", "/server_py.py",
        "/assets/../toolA.html", "/missing.js",
    )
    result: dict[str, object] = {}
    with mock.patch.multiple(
        server, ROOT=app_root, STATE_ROOT=state_root,
        DXF_MANIFEST_PATH=state_root / "embedded_dxfs_manifest.json",
        DXF_LIBRARY_ROOT=dxf_root,
    ):
        for path in paths:
            translated = Path(server.Handler.translate_path(handler, path))
            if translated.name == "__forbidden_static__.404":
                value = "FORBIDDEN"
            elif translated.name == "__admin__.html":
                value = "ADMIN_PSEUDO"
            elif app_root in translated.parents or translated == app_root:
                value = "APP/" + translated.relative_to(app_root).as_posix()
            elif state_root in translated.parents or translated == state_root:
                value = "STATE/" + translated.relative_to(state_root).as_posix()
            else:
                value = "OUTSIDE"
            result[path] = value
    return result


def _behavior() -> dict[str, object]:
    with tempfile.TemporaryDirectory(prefix="r9l4_static_http_behavior_") as tmp:
        root = Path(tmp)
        return {
            "staticPolicyMatrix": _static_policy_matrix(),
            "translationMatrix": _translation_matrix(root),
            "responseMatrix": _response_matrix(root),
            "contentTypes": {
                "dxf": server.Handler.guess_type(object.__new__(server.Handler), "x.dxf"),
                "html": server.Handler.guess_type(object.__new__(server.Handler), "x.html"),
                "unknown": server.Handler.guess_type(object.__new__(server.Handler), "x.unknown-r9l4"),
            },
        }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--write", action="store_true")
    args = parser.parse_args()
    if args.write:
        payload = {
            "schemaVersion": 1,
            "fixtureId": "R9L4_STATIC_HTTP_BEFORE_FIXTURE",
            "sourceCheckpoint": "R9L3",
            "sourceCommit": "ec144cd890b064873d0246c8c9bf2a244802b16a",
            **_source_metrics(),
            **_behavior(),
        }
        FIXTURE.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        print(json.dumps({"gate": "R9L4_STATIC_HTTP_BEFORE_GATE", "status": "WRITTEN", "fixture": str(FIXTURE)}, sort_keys=True))
        return 0
    expected = json.loads(FIXTURE.read_text(encoding="utf-8"))
    actual = _behavior()
    checks = {key: actual[key] == expected[key] for key in actual}
    result = {"gate": "R9L4_STATIC_HTTP_BEFORE_GATE", "status": "PASS" if all(checks.values()) else "FAIL", "checks": checks}
    print(json.dumps(result, sort_keys=True))
    return 0 if all(checks.values()) else 1


if __name__ == "__main__":
    raise SystemExit(main())
