#!/usr/bin/env python3
from __future__ import annotations

"""One-shot extraction of the HTTP handler into focused runtime mixins."""

import ast
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
APPLICATION = APP / "metod_app/runtime/application.py"
HTTP = APP / "metod_app/http"

GROUPS = (
    ("transport_runtime.py", "TransportRuntimeMixin", "_prepare_html", "_require_admin_auth"),
    ("material_catalog_runtime.py", "MaterialCatalogRuntimeMixin", "_dxf_root", "_api_admin_material_image_delete"),
    ("catalog_import_runtime.py", "CatalogImportRuntimeMixin", "_catalog_import_file", "_api_admin_catalog_retry_images"),
    ("admin_operations_runtime.py", "AdminOperationsRuntimeMixin", "_api_admin_system_logs", "_api_admin_dxf_delete"),
    ("public_api_runtime.py", "PublicApiRuntimeMixin", "_require_job_access", "_api_status"),
)


def _bound_names(tree: ast.Module) -> set[str]:
    names: set[str] = set()
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            names.add(node.name)
        elif isinstance(node, ast.Import):
            names.update(alias.asname or alias.name.split(".", 1)[0] for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            names.update(alias.asname or alias.name for alias in node.names)
        elif isinstance(node, ast.Assign):
            names.update(target.id for target in node.targets if isinstance(target, ast.Name))
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            names.add(node.target.id)
    return names


def _method_dependencies(node: ast.FunctionDef, global_names: set[str]) -> tuple[str, ...]:
    local_names = {argument.arg for argument in (*node.args.posonlyargs, *node.args.args, *node.args.kwonlyargs)}
    if node.args.vararg:
        local_names.add(node.args.vararg.arg)
    if node.args.kwarg:
        local_names.add(node.args.kwarg.arg)
    for child in ast.walk(node):
        if isinstance(child, ast.Name) and isinstance(child.ctx, (ast.Store, ast.Param)):
            local_names.add(child.id)
    loaded = {
        child.id
        for child in ast.walk(node)
        if isinstance(child, ast.Name) and isinstance(child.ctx, ast.Load)
    }
    return tuple(sorted((loaded & global_names) - local_names - {"Handler"}))


def _inject(source: str, node: ast.FunctionDef, global_names: set[str]) -> str:
    lines = source.splitlines(keepends=True)[node.lineno - 1 : node.end_lineno]
    dependencies = _method_dependencies(node, global_names)
    insert = 1
    if node.body and isinstance(node.body[0], ast.Expr):
        value = node.body[0].value
        if isinstance(value, ast.Constant) and isinstance(value.value, str):
            insert = node.body[0].end_lineno - node.lineno + 1
    bindings: list[str] = []
    if dependencies or node.name == "_save_material_library_bundle":
        bindings.append("        runtime = self._runtime\n")
    bindings.extend(f"        {name} = runtime.{name}\n" for name in dependencies)
    if bindings:
        lines[insert:insert] = bindings + ["\n"]
    method = "".join(lines)
    if node.name == "_save_material_library_bundle":
        method = method.replace("        global _MATERIAL_NAME_BY_CODE\n", "", 1)
        if method.count("        _MATERIAL_NAME_BY_CODE = None") != 1:
            raise RuntimeError("material-name cache assignment contract drifted")
        method = method.replace(
            "        _MATERIAL_NAME_BY_CODE = None",
            "        runtime._MATERIAL_NAME_BY_CODE = None",
            1,
        )
    return method.rstrip() + "\n"


def main() -> int:
    targets = [HTTP / filename for filename, *_ in GROUPS] + [HTTP / "handler.py"]
    if any(path.exists() for path in targets):
        raise RuntimeError("R9RC1 HTTP handler extraction has already run")
    source = APPLICATION.read_text(encoding="utf-8", errors="strict")
    tree = ast.parse(source)
    handler = next(
        (node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == "Handler"),
        None,
    )
    if handler is None:
        raise RuntimeError("Handler class is missing")
    methods = [node for node in handler.body if isinstance(node, ast.FunctionDef)]
    method_names = [node.name for node in methods]
    global_names = _bound_names(tree)
    assigned: set[str] = set()

    for filename, class_name, first, last in GROUPS:
        try:
            start = method_names.index(first)
            end = method_names.index(last)
        except ValueError as exc:
            raise RuntimeError(f"HTTP method boundary drifted: {first}..{last}") from exc
        if start > end:
            raise RuntimeError(f"reversed HTTP method boundary: {first}..{last}")
        selected = methods[start : end + 1]
        overlap = assigned & {node.name for node in selected}
        if overlap:
            raise RuntimeError(f"duplicate HTTP method ownership: {sorted(overlap)}")
        assigned.update(node.name for node in selected)
        body = "\n".join(_inject(source, node, global_names) for node in selected)
        module = (
            "from __future__ import annotations\n\n"
            f'"""Focused {class_name} owner; dependencies resolve through the composition runtime."""\n\n'
            f"class {class_name}:\n"
            "    _runtime: object\n\n"
            + body
        )
        (HTTP / filename).write_text(module, encoding="utf-8")

    if assigned != set(method_names):
        raise RuntimeError(f"unassigned Handler methods: {sorted(set(method_names) - assigned)}")

    factory = '''from __future__ import annotations

"""Compose the concrete HTTP handler from bounded behavior owners."""

from .admin_operations_runtime import AdminOperationsRuntimeMixin
from .catalog_import_runtime import CatalogImportRuntimeMixin
from .material_catalog_runtime import MaterialCatalogRuntimeMixin
from .public_api_runtime import PublicApiRuntimeMixin
from .transport_runtime import TransportRuntimeMixin


def build_handler(runtime):
    class Handler(
        TransportRuntimeMixin,
        MaterialCatalogRuntimeMixin,
        CatalogImportRuntimeMixin,
        AdminOperationsRuntimeMixin,
        PublicApiRuntimeMixin,
        runtime.SimpleHTTPRequestHandler,
    ):
        _runtime = runtime

    Handler.__name__ = "Handler"
    Handler.__qualname__ = "Handler"
    return Handler
'''
    (HTTP / "handler.py").write_text(factory, encoding="utf-8")

    start_offset = source.index("class Handler(")
    end_offset = source.index("\ndef api_draft_save", start_offset)
    replacement = '''from metod_app.http.handler import build_handler as _build_http_handler


Handler = _build_http_handler(sys.modules[__name__])


'''
    APPLICATION.write_text(source[:start_offset] + replacement + source[end_offset + 1 :], encoding="utf-8")
    print(f"extracted {len(methods)} Handler methods into five focused mixins")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
