#!/usr/bin/env python3
from __future__ import annotations

"""One-shot byte-exact split of the final monolithic Tool A compatibility source."""

import hashlib
from pathlib import Path

from r9rc1_build_toola_assets import (
    APP,
    LEGACY_FRAGMENT_DIR,
    LEGACY_FRAGMENT_SPECS,
    LEGACY_SOURCE,
)


SOURCE = APP / LEGACY_SOURCE


def main() -> int:
    if LEGACY_FRAGMENT_DIR.exists():
        raise RuntimeError("R9RC1 legacy runtime source has already been split")
    payload = SOURCE.read_bytes()
    lines = payload.splitlines(keepends=True)
    if len(lines) != LEGACY_FRAGMENT_SPECS[-1][2]:
        raise RuntimeError(f"legacy runtime line inventory drifted: {len(lines)}")

    LEGACY_FRAGMENT_DIR.mkdir(parents=True)
    fragments: list[bytes] = []
    for filename, first_line, last_line in LEGACY_FRAGMENT_SPECS:
        fragment = b"".join(lines[first_line - 1 : last_line])
        if len(fragment.splitlines()) != last_line - first_line + 1:
            raise RuntimeError(f"fragment line contract failed: {filename}")
        (LEGACY_FRAGMENT_DIR / filename).write_bytes(fragment)
        fragments.append(fragment)
    rebuilt = b"".join(fragments)
    if rebuilt != payload:
        raise RuntimeError("legacy runtime split was not byte-exact")

    digest = hashlib.sha256(payload).hexdigest()
    SOURCE.write_text(
        "/* R9RC1 source descriptor only.\n"
        " * The reviewed legacy closure is byte-exactly assembled from bounded files in\n"
        " * tool-a/runtime/legacy-source/parts.json by r9rc1_build_toola_assets.py.\n"
        f" * Aggregate SHA-256 before splitting: {digest}\n"
        " */\n",
        encoding="utf-8",
    )
    print(
        f"split {len(lines)} legacy lines into {len(fragments)} bounded fragments; "
        f"aggregate sha256={digest}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
