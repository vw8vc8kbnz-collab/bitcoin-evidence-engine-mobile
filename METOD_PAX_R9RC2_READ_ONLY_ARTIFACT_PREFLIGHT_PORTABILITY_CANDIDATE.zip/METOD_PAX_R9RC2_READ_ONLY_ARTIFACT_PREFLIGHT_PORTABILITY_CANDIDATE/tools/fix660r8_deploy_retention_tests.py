#!/usr/bin/env python3
from __future__ import annotations

import os
import re
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest import mock


RELEASE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RELEASE_ROOT / 'tools'))

import prune_deploy_history as prune  # noqa: E402


VERSION = 'FIX660R8_PRELIVE_HARDENED'
RELEASE_PATTERN = re.compile(re.escape(VERSION) + r'_[a-f0-9]{12}')
CONFIG_PATTERN = re.compile(re.escape(VERSION) + r'_config_[0-9]{8}_[0-9]{6}')


class DeployRetentionTests(unittest.TestCase):
    def setUp(self) -> None:
        self.holder = tempfile.TemporaryDirectory(prefix='fix660r8_deploy_history_')
        self.root = Path(self.holder.name)
        self.releases = self.root / 'releases'
        self.backups = self.root / 'backups'
        self.releases.mkdir()
        self.backups.mkdir()

    def tearDown(self) -> None:
        self.holder.cleanup()

    def _release(self, suffix: str, *, age_days: int, size: int = 1) -> Path:
        path = self.releases / f'{VERSION}_{suffix}'
        path.mkdir()
        (path / 'payload').write_bytes(b'x' * size)
        stamp = time.time() - age_days * 86_400
        os.utime(path, (stamp, stamp))
        return path

    def test_active_and_previous_are_never_removed(self) -> None:
        active = self._release('a' * 12, age_days=400)
        previous = self._release('b' * 12, age_days=400)
        extra = self._release('c' * 12, age_days=1)
        report = prune.prune_history(
            root=self.releases,
            pattern=RELEASE_PATTERN,
            protected={active.resolve(), previous.resolve()},
            keep_count=2,
            max_age_days=30,
            max_bytes=1024,
        )
        self.assertTrue(active.is_dir())
        self.assertTrue(previous.is_dir())
        self.assertFalse(extra.exists())
        self.assertEqual(report['deleted'], [extra.name])

    def test_count_age_and_byte_caps_delete_only_exact_children(self) -> None:
        newest = self._release('d' * 12, age_days=1, size=20)
        second = self._release('e' * 12, age_days=2, size=20)
        old = self._release('f' * 12, age_days=200, size=20)
        unrelated = self.releases / 'customer-data'
        unrelated.mkdir()
        outside = self.root / 'outside'
        outside.mkdir()
        (self.releases / f'{VERSION}_{"1" * 12}').symlink_to(outside, target_is_directory=True)
        report = prune.prune_history(
            root=self.releases,
            pattern=RELEASE_PATTERN,
            protected={newest.resolve()},
            keep_count=3,
            max_age_days=30,
            max_bytes=25,
        )
        self.assertTrue(newest.exists())
        self.assertFalse(second.exists())
        self.assertFalse(old.exists())
        self.assertTrue(unrelated.exists())
        self.assertTrue(outside.exists())
        self.assertEqual(set(report['deleted']), {second.name, old.name})

    def test_config_backup_policy_preserves_current(self) -> None:
        names = [
            f'{VERSION}_config_20260813_12000{index}'
            for index in range(4)
        ]
        paths = []
        for index, name in enumerate(names):
            path = self.backups / name
            path.mkdir()
            (path / 'config').write_text(str(index), encoding='utf-8')
            stamp = time.time() - index * 86_400
            os.utime(path, (stamp, stamp))
            paths.append(path)
        protected = paths[-1]
        report = prune.prune_history(
            root=self.backups,
            pattern=CONFIG_PATTERN,
            protected={protected.resolve()},
            keep_count=2,
            max_age_days=180,
            max_bytes=1024,
        )
        self.assertTrue(protected.exists())
        self.assertLessEqual(len(report['kept']), 2)
        self.assertEqual(len(report['deleted']), 2)

    def test_dry_run_is_non_mutating(self) -> None:
        candidate = self._release('9' * 12, age_days=500)
        report = prune.prune_history(
            root=self.releases,
            pattern=RELEASE_PATTERN,
            protected=set(),
            keep_count=1,
            max_age_days=1,
            max_bytes=1,
            dry_run=True,
        )
        self.assertTrue(candidate.exists())
        self.assertEqual(report['deleted'], [candidate.name])

    def test_current_link_is_rechecked_immediately_before_delete(self) -> None:
        original_current = self._release('7' * 12, age_days=400)
        newly_current = self._release('8' * 12, age_days=400)
        current_link = self.root / 'current'
        current_link.symlink_to(original_current, target_is_directory=True)
        original_resolver = prune._resolved_if_present
        switched = False

        def switch_current_before_recheck(path: Path | None) -> Path | None:
            nonlocal switched
            if path == current_link and not switched:
                current_link.unlink()
                current_link.symlink_to(newly_current, target_is_directory=True)
                switched = True
            return original_resolver(path)

        with mock.patch.object(prune, '_resolved_if_present', side_effect=switch_current_before_recheck):
            report = prune.prune_history(
                root=self.releases,
                pattern=RELEASE_PATTERN,
                protected={original_current.resolve()},
                keep_count=1,
                max_age_days=1,
                max_bytes=1,
                current_link=current_link,
            )

        self.assertTrue(switched)
        self.assertTrue(original_current.is_dir())
        self.assertTrue(newly_current.is_dir())
        self.assertEqual(report['deleted'], [])
        self.assertIn(newly_current.name, report['kept'])

    def test_installer_lock_precedes_root_side_validation_and_mutation(self) -> None:
        installer = (RELEASE_ROOT / 'INSTALL_FIX660R8_FROM_STAGE.sh').read_text(encoding='utf-8')
        acquire = installer.index('flock -n "$DEPLOY_LOCK_FD"')
        validation = installer.index('python3 - "$LEGACY_APP"', acquire)
        pointer_switch = installer.index('mv -Tf "$CURRENT_LINK.next" "$CURRENT_LINK"')
        prune_call = installer.index('prune_deploy_history.py')
        self.assertIn('DEPLOY_LOCK_PATH="/run/metod-pax-deploy.lock"', installer)
        self.assertIn('exec {DEPLOY_LOCK_FD}>"$DEPLOY_LOCK_PATH"', installer)
        self.assertLess(acquire, validation)
        self.assertLess(acquire, pointer_switch)
        self.assertLess(acquire, prune_call)

    def test_runtime_release_marker_is_proven_before_edge_reopens(self) -> None:
        deploy = (RELEASE_ROOT / 'DEPLOY_FIX660.sh').read_text(encoding='utf-8')
        readiness = deploy.index('http://127.0.0.1:8792/health/ready')
        marker = deploy.index("grep -Fq 'R9O7_WEBKIT_IPHONE_ADMIN_GRID_TRACK_REMEDIATION'")
        edge_reopen = deploy.index('systemctl reload nginx')
        self.assertIn('http://127.0.0.1:8792/toolA.html', deploy)
        self.assertLess(readiness, marker)
        self.assertLess(marker, edge_reopen)

    def test_backup_total_cap_contains_source_and_publish_margin(self) -> None:
        deploy = (RELEASE_ROOT / 'DEPLOY_FIX660.sh').read_text(encoding='utf-8')
        server_source = (RELEASE_ROOT / 'app/server_py.py').read_text(encoding='utf-8')

        def env_int(name: str) -> int:
            match = re.search(rf'^{re.escape(name)}=(\d+)$', deploy, flags=re.MULTILINE)
            self.assertIsNotNone(match, f'{name} ontbreekt in runtime environment')
            return int(match.group(1))

        source_cap = env_int('BACKUP_MAX_SOURCE_BYTES')
        total_cap = env_int('BACKUP_TOTAL_MAX_BYTES')
        margin = max(16 * 1024 * 1024, source_cap // 10)
        self.assertGreaterEqual(total_cap, source_cap + margin)
        self.assertEqual(total_cap, 20 * 1024 * 1024 * 1024)
        self.assertEqual(
            server_source.count("_env_int('BACKUP_TOTAL_MAX_BYTES', 20 * 1024 * 1024 * 1024)"),
            2,
            'standalone fallback and deployed backup cap must not drift',
        )

    def test_edge_owns_one_conservative_hsts_policy(self) -> None:
        deploy = (RELEASE_ROOT / 'DEPLOY_FIX660.sh').read_text(encoding='utf-8')
        self.assertEqual(
            deploy.count('proxy_hide_header Strict-Transport-Security;'),
            4,
            'every proxied location must suppress the application fallback HSTS header',
        )
        self.assertIn(
            'add_header Strict-Transport-Security "max-age=31536000" always;',
            deploy,
        )
        self.assertNotIn(
            'add_header Strict-Transport-Security "max-age=31536000; includeSubDomains"',
            deploy,
        )


if __name__ == '__main__':
    unittest.main(verbosity=2)
