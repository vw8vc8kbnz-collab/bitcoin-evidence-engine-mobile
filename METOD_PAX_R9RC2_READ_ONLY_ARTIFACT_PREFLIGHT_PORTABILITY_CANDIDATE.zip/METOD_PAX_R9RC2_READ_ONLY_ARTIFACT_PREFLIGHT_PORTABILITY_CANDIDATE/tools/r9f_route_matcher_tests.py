#!/usr/bin/env python3
from __future__ import annotations

"""Executable contract for the R9F HTTP route matcher."""

import ast
import dataclasses
import hashlib
import json
import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
sys.path.insert(0, str(APP))

from metod_app.http.matcher import (  # noqa: E402
    BLOCKED_STATIC_TOP_LEVEL,
    PUBLIC_STATIC_MODULE_FILES,
    PUBLIC_STATIC_ROOT_FILES,
    PUBLIC_STATIC_SHELL_FILES,
    RouteMatch,
    match_route,
    request_path,
)
from metod_app.http.routes import ROUTES  # noqa: E402


SERVER_SHA256 = "84b3b0d3713d4d6da472d6b7d4351e166aac59e1fde1812cf60ccbd84d77556a"


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def witness(method: str, pattern: str) -> str:
    dynamic = {
        ("GET", "/api/jobs/{jobId}/download/{filename}"): "/api/jobs/J01/download/S001.dxf",
        ("GET", "/api/jobs/{jobId}/file/{relativePath}"): "/api/jobs/J01/file/output/quote.json",
        ("GET", "/api/jobs/{jobId}/status"): "/api/jobs/J01/status",
        ("GET", "/api/jobs/{jobId}/subjobs/{subjobId}/file/{relativePath}"):
            "/api/jobs/J01/subjobs/S01/file/output/quote.json",
        ("GET", "/api/materials/image/{publicId}/{variant}"):
            "/api/materials/image/decor_0123456789abcdef0123/card",
        ("GET", "/{allowlistedStaticAsset}"): "/assets/r9f-shadow.svg",
        ("HEAD", "/{allowlistedStaticAsset}"): "/assets/r9f-shadow.svg",
        ("HEAD", "/api/admin/"): "/api/admin/r9f-shadow",
        ("OPTIONS", "*"): "/any/request-target",
    }
    return dynamic.get((method, pattern), pattern)


def literal_set(source: Path, name: str) -> frozenset[str]:
    tree = ast.parse(source.read_text(encoding="utf-8"), filename=str(source))
    for node in tree.body:
        if isinstance(node, (ast.Assign, ast.AnnAssign)):
            target = node.targets[0] if isinstance(node, ast.Assign) else node.target
            if isinstance(target, ast.Name) and target.id == name:
                value = node.value
                if isinstance(value, ast.Call) and value.args:
                    value = value.args[0]
                result = ast.literal_eval(value)
                return frozenset(str(item) for item in result)
    raise AssertionError(f"missing literal set {name}")


class RouteMatcherTests(unittest.TestCase):
    def test_01_match_is_immutable_metadata_without_callable_owner(self) -> None:
        result = match_route("GET", "/health/live")
        self.assertIsInstance(result, RouteMatch)
        self.assertTrue(dataclasses.is_dataclass(result))
        self.assertEqual(result.key, "GET /health/live")
        with self.assertRaises(dataclasses.FrozenInstanceError):
            result.path = "/changed"  # type: ignore[misc]
        for field in dataclasses.fields(RouteMatch):
            self.assertNotIn("callable", str(field.type).lower())
        self.assertFalse(callable(result.route.handler_id))

    def test_02_all_80_catalog_routes_have_an_exact_witness(self) -> None:
        self.assertEqual(len(ROUTES), 80)
        observed: list[str] = []
        for route in ROUTES:
            result = match_route(route.method, witness(route.method, route.pattern))
            self.assertIsNotNone(result, route.key)
            self.assertEqual(result.key, route.key)
            observed.append(result.key)
        self.assertEqual(observed, [route.key for route in ROUTES])

    def test_03_request_target_parity_strips_query_and_fragment_only(self) -> None:
        self.assertEqual(request_path("/health/live?x=1#ignored"), "/health/live")
        self.assertEqual(match_route("GET", "/health/live?x=1#ignored").key, "GET /health/live")
        self.assertIsNone(match_route("GET", "/health%2Flive"))
        self.assertEqual(match_route("GET", "").key, "GET /")

    def test_04_dynamic_parameters_follow_current_decode_contract(self) -> None:
        image = match_route("GET", "/api/materials/image/decor%5F1/card%20large")
        self.assertEqual(image.parameters, (("publicId", "decor_1"), ("variant", "card large")))
        download = match_route("GET", "/api/jobs/J%2001/download/S%2001.dxf")
        self.assertEqual(download.parameter("jobId"), "J%2001")
        self.assertEqual(download.parameter("filename"), "S%2001.dxf")
        subjob = match_route("GET", "/api/jobs/J%2001/subjobs/S%2001/file/output/a%20b.dxf")
        self.assertEqual(subjob.parameter("jobId"), "J 01")
        self.assertEqual(subjob.parameter("subjobId"), "S 01")
        self.assertEqual(subjob.parameter("relativePath"), "output/a b.dxf")
        status = match_route("GET", "/api/jobs/J%2001/status")
        self.assertEqual(status.parameter("jobId"), "J%2001")

    def test_05_dynamic_precedence_matches_the_live_handler(self) -> None:
        download_first = match_route(
            "GET", "/api/jobs/J01/subjobs/S01/file/output/download/final.dxf"
        )
        self.assertEqual(download_first.key, "GET /api/jobs/{jobId}/download/{filename}")
        malformed_subjob = match_route(
            "GET", "/api/jobs/J01/subjobs/S01/not-file/file/output/quote.json"
        )
        self.assertEqual(malformed_subjob.key, "GET /api/jobs/{jobId}/file/{relativePath}")
        self.assertEqual(malformed_subjob.parameter("relativePath"), "S01/not-file/file/output/quote.json")
        self.assertIsNone(match_route("GET", "/api/materials/image/too/many/segments"))

    def test_06_static_allowlist_and_blocklist_are_exact(self) -> None:
        self.assertEqual(len(PUBLIC_STATIC_ROOT_FILES), 49)
        self.assertEqual(len(PUBLIC_STATIC_MODULE_FILES), 19)
        self.assertEqual(len(PUBLIC_STATIC_SHELL_FILES), 41)
        self.assertEqual(len(BLOCKED_STATIC_TOP_LEVEL), 8)
        allowed = (
            "/decor_library.js", "/tool-a/bootstrap.js", "/tool-a/steps/panels.js",
            "/tool-a/steps/grain.js", "/tool-a/steps/customer.js", "/tool-a/api/jobs.js",
            "/tool-a/api/requests.js",
            "/tool-a/components/checkout-review.js",
            "/tool-a/components/thank-you.js",
            "/tool-a/components/dialog.js",
            "/tool-a/components/footer.js",
            "/tool-a/components/grain-preview.js",
            "/tool-a/components/mobile-material-cart.js",
            "/tool-a/components/overlay-router.js",
            "/tool-a/components/progress-overlay.js",
            "/tool-a/styles/tokens.css",
            "/tool-a/styles/checkout.css",
            "/tool-a/shell/script-01-early-catalog-bootstrap.js",
            "/tool-a/shell/script-34-fix655-build-marker.js",
            "/assets/logo.PNG",
            "/embedded_dxfs/Deuren%20METOD/paneel.DXF",
        )
        for target in allowed:
            result = match_route("GET", target)
            self.assertEqual(result.key, "GET /{allowlistedStaticAsset}", target)
        for target in (
            "/server_py.py", "/config/pricing.json", "/assets/.secret.svg",
            "/assets/%2e%2e/config.svg", "/unknown.js", "/jobs/public.svg",
        ):
            self.assertIsNone(match_route("GET", target), target)

    def test_07_head_admin_prefix_and_options_wildcard_are_deliberate(self) -> None:
        self.assertEqual(match_route("HEAD", "/api/admin/anything").key, "HEAD /api/admin/")
        self.assertEqual(match_route("OPTIONS", "/not/in/catalog").key, "OPTIONS *")
        self.assertEqual(match_route("OPTIONS", "*").key, "OPTIONS *")
        self.assertIsNone(match_route("HEAD", "/health/live"))

    def test_08_unknown_unsupported_and_lowercase_methods_fail_closed(self) -> None:
        for method, target in (
            ("PUT", "/api/jobs"), ("DELETE", "/api/jobs"),
            ("get", "/health/live"), ("post", "/api/jobs"),
            ("GET", "/api/not-reviewed"), ("POST", "/api/not-reviewed"),
        ):
            self.assertIsNone(match_route(method, target), (method, target))

    def test_09_matcher_is_pure_and_all_reviewed_methods_adopt_it(self) -> None:
        matcher = (APP / "metod_app/http/matcher.py").read_text(encoding="utf-8")
        server = (APP / "server_py.py").read_text(encoding="utf-8")
        self.assertIn(
            "from metod_app.http.matcher import match_route as _match_http_route",
            server,
        )
        self.assertEqual(server.count("_match_http_route('GET', self.path)"), 1)
        self.assertEqual(server.count("_match_http_route('HEAD', self.path)"), 1)
        self.assertEqual(server.count("_match_http_route('OPTIONS', self.path)"), 1)
        self.assertEqual(server.count("_match_http_route('POST', self.path)"), 2)
        for token in (
            "server_py", "Handler(", "getattr(", "import_module(", "open(",
            "Popen(", "Thread(", "Lock(", "fetch(", "serve_forever(",
        ):
            self.assertNotIn(token, matcher, token)
        imports = {
            str(node.module or "").split(".", 1)[0]
            for node in ast.walk(ast.parse(matcher))
            if isinstance(node, ast.ImportFrom) and node.level == 0
        }
        self.assertFalse(imports & {"http", "os", "pathlib", "socket", "subprocess", "threading"})

    def test_10_live_static_literals_and_complete_dispatch_server_bytes_are_exact(self) -> None:
        server = APP / "server_py.py"
        matcher = APP / "metod_app/http/matcher.py"
        static = APP / "metod_app/http/static.py"
        self.assertEqual(digest(server), SERVER_SHA256)
        self.assertEqual(
            literal_set(static, "PUBLIC_STATIC_ROOT_FILES"),
            PUBLIC_STATIC_ROOT_FILES,
        )
        self.assertEqual(
            literal_set(static, "PUBLIC_STATIC_MODULE_FILES"),
            PUBLIC_STATIC_MODULE_FILES,
        )
        self.assertEqual(
            literal_set(static, "PUBLIC_STATIC_SHELL_FILES"),
            PUBLIC_STATIC_SHELL_FILES,
        )
        self.assertEqual(
            literal_set(static, "BLOCKED_STATIC_TOP_LEVEL"),
            BLOCKED_STATIC_TOP_LEVEL,
        )
        self.assertIn("from .static import (", matcher.read_text(encoding="utf-8"))
        rules = json.loads((ROOT / "R9B_ARCHITECTURE_RULES.json").read_text(encoding="utf-8"))
        self.assertEqual(rules["python"]["allowedRelativeImports"]["http/matcher.py"], ["contracts", "routes", "static"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
