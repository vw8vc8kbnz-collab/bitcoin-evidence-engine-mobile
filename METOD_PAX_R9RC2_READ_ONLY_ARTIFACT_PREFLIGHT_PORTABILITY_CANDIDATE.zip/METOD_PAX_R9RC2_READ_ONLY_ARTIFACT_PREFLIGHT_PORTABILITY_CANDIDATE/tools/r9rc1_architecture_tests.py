#!/usr/bin/env python3
from __future__ import annotations

"""Fail-closed architecture, presentation and browser-privacy gate for R9RC1."""

import ast
import json
import os
import re
import subprocess
import sys
import unittest
from html.parser import HTMLParser
from pathlib import Path


RELEASE = Path(__file__).resolve().parents[1]
APP = RELEASE / "app"
RULES_PATH = RELEASE / "R9RC1_PROFESSIONAL_ARCHITECTURE_RULES.json"
RULES = json.loads(RULES_PATH.read_text(encoding="utf-8"))
SERVER_ENTRY = APP / "server_py.py"
APPLICATION = APP / "metod_app/runtime/application.py"
HANDLER = APP / "metod_app/http/handler.py"
HTML = APP / "toolA.html"
BUNDLE_MANIFEST = APP / "tool-a/runtime/bundle-manifest.json"
PARTS_MANIFEST = APP / "tool-a/runtime/legacy-source/parts.json"


def line_count(path: Path) -> int:
    return len(path.read_text(encoding="utf-8", errors="strict").splitlines())


def active_javascript_sources() -> list[Path]:
    sources = [
        path for path in APP.rglob("*.js")
        if path.name != "classic-runtime.bundle.js"
    ]
    sources.extend(APP.rglob("*.jsfrag"))
    return sorted(set(sources))


class ShellParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.scripts: list[dict[str, str]] = []
        self.stylesheets: list[str] = []
        self.style_elements = 0
        self.style_attributes: list[str] = []
        self.event_attributes: list[str] = []
        self.javascript_urls: list[str] = []
        self.ids: list[str] = []

    def handle_starttag(self, tag: str, attrs) -> None:
        values = {str(key).lower(): str(value or "") for key, value in attrs}
        if tag.lower() == "script":
            self.scripts.append(values)
        elif tag.lower() == "style":
            self.style_elements += 1
        elif tag.lower() == "link" and values.get("rel", "").lower() == "stylesheet":
            self.stylesheets.append(values.get("href", "").split("?", 1)[0])
        if "id" in values:
            self.ids.append(values["id"])
        for key, value in values.items():
            if key == "style":
                self.style_attributes.append(values.get("id") or tag)
            if key.startswith("on"):
                self.event_attributes.append(f"{tag}:{key}")
            if value.strip().lower().startswith("javascript:"):
                self.javascript_urls.append(f"{tag}:{key}")


class R9RC1ArchitectureTests(unittest.TestCase):
    def test_01_python_entry_and_domain_boundaries_are_bounded(self) -> None:
        budgets = RULES["lineBudgets"]
        self.assertLessEqual(line_count(SERVER_ENTRY), budgets["serverEntry"])
        self.assertLessEqual(line_count(APPLICATION), budgets["compositionRuntime"])
        self.assertLessEqual(line_count(HANDLER), budgets["httpHandlerComposition"])

        entry_tree = ast.parse(SERVER_ENTRY.read_text(encoding="utf-8"))
        entry_owners = [
            node.name for node in entry_tree.body
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
        ]
        self.assertEqual(entry_owners, [])
        self.assertIn("sys.modules[__name__] = _application", SERVER_ENTRY.read_text(encoding="utf-8"))

        top_level_calls = [
            node for node in ast.parse(APPLICATION.read_text(encoding="utf-8")).body
            if isinstance(node, ast.Expr) and isinstance(node.value, ast.Call)
        ]
        self.assertEqual(top_level_calls, [], "composition module must not perform top-level I/O calls")

        domain_paths = sorted({
            *APP.glob("metod_app/**/*_runtime.py"),
            *APP.glob("metod_app/http/endpoints/*.py"),
            APP / "metod_app/jobs/execution.py",
            APP / "metod_app/runtime/startup.py",
            APP / "metod_app/runtime/worker.py",
        })
        oversized = {
            path.relative_to(APP).as_posix(): line_count(path)
            for path in domain_paths
            if path.name != "application.py"
            and line_count(path) > budgets["pythonDomainModule"]
        }
        self.assertEqual(oversized, {})
        self.assertNotIn("class Handler(", APPLICATION.read_text(encoding="utf-8"))

    def test_02_tool_a_is_a_markup_only_three_phase_shell(self) -> None:
        self.assertLessEqual(line_count(HTML), RULES["lineBudgets"]["toolAHtml"])
        parser = ShellParser()
        parser.feed(HTML.read_text(encoding="utf-8", errors="strict"))
        scripts = [item.get("src", "").split("?", 1)[0] for item in parser.scripts]
        self.assertEqual(scripts, RULES["toolAShell"]["scripts"])
        self.assertEqual(parser.stylesheets, RULES["toolAShell"]["stylesheets"])
        self.assertEqual(parser.style_elements, 0)
        self.assertEqual(parser.style_attributes, [])
        self.assertEqual(parser.event_attributes, [])
        self.assertEqual(parser.javascript_urls, [])
        duplicates = sorted({value for value in parser.ids if parser.ids.count(value) > 1})
        self.assertEqual(duplicates, [])
        self.assertTrue(all(item.get("src") for item in parser.scripts))
        self.assertEqual(parser.scripts[-1].get("type"), "module")

    def test_03_bundles_and_fragment_ledger_are_reproducible(self) -> None:
        manifest = json.loads(BUNDLE_MANIFEST.read_text(encoding="utf-8"))
        parts = json.loads(PARTS_MANIFEST.read_text(encoding="utf-8"))
        shell = RULES["toolAShell"]
        self.assertEqual(len(manifest["classic"]["sources"]), shell["classicSourceCount"])
        self.assertEqual(len(manifest["styles"]["sources"]), shell["styleSourceCount"])
        self.assertEqual(len(parts["fragments"]), shell["legacyFragmentCount"])
        self.assertLessEqual(
            parts["maximumFragmentLines"],
            RULES["lineBudgets"]["legacySourceFragment"],
        )
        self.assertEqual(parts["assembly"], "byte-exact-concatenation-without-separators")
        self.assertEqual(manifest["foundationCompatibilityGlobals"], [])
        self.assertEqual(
            line_count(APP / "tool-a/shell/script-06-legacy-application-runtime.js"),
            5,
        )
        build = subprocess.run(
            [sys.executable, "-B", "tools/r9rc1_build_toola_assets.py", "--check"],
            cwd=RELEASE,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            check=False,
        )
        self.assertEqual(build.returncode, 0, build.stdout)
        syntax = subprocess.run(
            ["node", "--check", "app/tool-a/runtime/classic-runtime.bundle.js"],
            cwd=RELEASE,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            check=False,
        )
        self.assertEqual(syntax.returncode, 0, syntax.stdout)

    def test_04_runtime_presentation_has_no_markup_or_style_element_owners(self) -> None:
        violations: list[str] = []
        for path in active_javascript_sources():
            source = path.read_text(encoding="utf-8", errors="strict")
            if re.search(r"createElement\(\s*['\"]style['\"]\s*\)", source):
                violations.append(f"dynamic-style:{path.relative_to(APP)}")
            if re.search(r"<[^>]+\sstyle\s*=", source, flags=re.IGNORECASE):
                violations.append(f"template-style:{path.relative_to(APP)}")
        self.assertEqual(violations, [])

    def test_05_temporary_foundation_global_and_dangerous_script_sinks_are_absent(self) -> None:
        violations: list[str] = []
        for path in [*active_javascript_sources(), APP / "tool-a/runtime/classic-runtime.bundle.js"]:
            source = path.read_text(encoding="utf-8", errors="strict")
            for token in (
                "ToolAR9Foundation",
                "document.write(",
                "document.writeln(",
                "eval(",
                "new Function(",
            ):
                if token in source:
                    violations.append(f"{token}:{path.relative_to(APP)}")
            if re.search(r"(?:import|fetch)\s*\(\s*['\"]https?://", source):
                violations.append(f"remote-code:{path.relative_to(APP)}")
        self.assertEqual(violations, [])

    def test_06_browser_persistence_and_diagnostics_are_privacy_bounded(self) -> None:
        source_by_path = {
            path: path.read_text(encoding="utf-8", errors="strict")
            for path in active_javascript_sources()
        }
        all_source = "\n".join(source_by_path.values())
        self.assertNotIn("console.error = function", all_source)
        self.assertNotIn("console.warn = function", all_source)
        self.assertNotIn("Job result:", all_source)
        self.assertNotIn("document.cookie", all_source)

        local_writes = re.findall(r"localStorage\.setItem\(([^\n;]+)", all_source)
        self.assertEqual(len(local_writes), 2, local_writes)
        self.assertTrue(any("CACHE_KEY" in call for call in local_writes))
        self.assertTrue(any("fix640_public_material_cache_migrated" in call for call in local_writes))
        pii_key = re.compile(
            r"sessionStorage\.setItem\(\s*['\"][^'\"]*"
            r"(?:customer|firstname|first_name|lastname|last_name|email|mail|phone|address|postcode|company|note|draft)",
            re.IGNORECASE,
        )
        self.assertIsNone(pii_key.search(all_source))

        client_log = source_by_path[
            APP / "tool-a/runtime/legacy-source/01-runtime-bootstrap-state.jsfrag"
        ]
        self.assertIn("function failureClass(value)", client_log)
        self.assertNotIn("JSON.stringify(a)", client_log)
        self.assertNotIn("e?.message||", client_log)

    def test_07_static_exposure_and_production_csp_are_fail_closed(self) -> None:
        sys.path.insert(0, str(APP))
        from metod_app.http.static import (  # noqa: E402
            PUBLIC_STATIC_MODULE_FILES,
            PUBLIC_STATIC_ROOT_FILES,
            PUBLIC_STATIC_SHELL_FILES,
            StaticHttpAdapterService,
            StaticHttpDependencies,
            is_public_static_relpath,
        )

        self.assertEqual(PUBLIC_STATIC_ROOT_FILES, {"toolA.html", "embedded_dxfs_manifest.json"})
        self.assertEqual(PUBLIC_STATIC_SHELL_FILES, {
            "tool-a/styles/tool-a.bundle.css",
            "tool-a/runtime/classic-runtime.bundle.js",
            "tool-a/shell/script-01-early-catalog-bootstrap.js",
        })
        self.assertEqual(len(PUBLIC_STATIC_MODULE_FILES), 19)
        for denied in (
            "server_py.py",
            "metod_app/runtime/application.py",
            "tool-a/runtime/bundle-manifest.json",
            "tool-a/runtime/legacy-source/parts.json",
            "tool-a/runtime/legacy-source/01-runtime-bootstrap-state.jsfrag",
            "tool-a/shell/script-06-legacy-application-runtime.js",
            "config/pricing.json",
        ):
            self.assertFalse(is_public_static_relpath(denied), denied)

        dependencies = StaticHttpDependencies(
            root=lambda: APP,
            state_root=lambda: APP / "state",
            dxf_manifest_path=lambda: APP / "embedded_dxfs_manifest.json",
            dxf_library_root=lambda: APP / "embedded_dxfs",
            resolve_relative_file=lambda root, relative: root / relative,
            sanitize_filename=lambda value, _limit: str(value),
            strict_json_dumps=json.dumps,
            origin_allowed=lambda *_args, **_kwargs: False,
            production_hardening_enabled=lambda: True,
            https_request=lambda _handler: True,
        )
        service = StaticHttpAdapterService(dependencies)

        class Handler:
            path = "/"
            headers: dict[str, str] = {}
            _csp_nonce = "r9rc1-test-nonce"

            def __init__(self) -> None:
                self.sent: dict[str, str] = {}

            def send_header(self, key: str, value: str) -> None:
                self.sent[key] = value

        handler = Handler()
        service.apply_default_headers(handler)
        csp = handler.sent["Content-Security-Policy"]
        for directive in (
            "default-src 'self'",
            "object-src 'none'",
            "frame-ancestors 'none'",
            "script-src 'self' 'nonce-r9rc1-test-nonce'",
            "script-src-attr 'none'",
            "connect-src 'self'",
        ):
            self.assertIn(directive, csp)
        self.assertEqual(handler.sent["Strict-Transport-Security"], "max-age=31536000")

    def test_08_packaged_runtime_composes_handler_and_routes_without_a_facade_copy(self) -> None:
        script = r'''
import json
import server_py as runtime
from metod_app.http.routes import ROUTES

cases = []
for method, target in (
    ("GET", "/"),
    ("GET", "/api/jobs/job_0123456789abcdef/status?view=public"),
    ("POST", "/api/jobs"),
    ("GET", "/server_py.py"),
):
    matched = runtime._match_http_route(method, target)
    cases.append(None if matched is None else {
        "pattern": matched.route.pattern,
        "parameters": dict(matched.parameters),
    })
print(json.dumps({
    "module": runtime.__name__,
    "routes": len(ROUTES),
    "uniqueRouteKeys": len({route.key for route in ROUTES}),
    "mro": [owner.__name__ for owner in runtime.Handler.__mro__[:7]],
    "cases": cases,
}))
'''
        environment = dict(os.environ)
        environment["PYTHONDONTWRITEBYTECODE"] = "1"
        result = subprocess.run(
            [sys.executable, "-B", "-c", script],
            cwd=APP,
            env=environment,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=30,
            check=False,
        )
        self.assertEqual(result.returncode, 0, result.stdout)
        actual = json.loads(result.stdout.strip().splitlines()[-1])
        self.assertEqual(actual["module"], "metod_app.runtime.application")
        self.assertEqual(actual["routes"], actual["uniqueRouteKeys"])
        self.assertGreaterEqual(actual["routes"], 80)
        self.assertEqual(actual["mro"], [
            "Handler",
            "TransportRuntimeMixin",
            "MaterialCatalogRuntimeMixin",
            "CatalogImportRuntimeMixin",
            "AdminOperationsRuntimeMixin",
            "PublicApiRuntimeMixin",
            "SimpleHTTPRequestHandler",
        ])
        self.assertEqual(actual["cases"], [
            {"pattern": "/", "parameters": {}},
            {
                "pattern": "/api/jobs/{jobId}/status",
                "parameters": {"jobId": "job_0123456789abcdef"},
            },
            {"pattern": "/api/jobs", "parameters": {}},
            None,
        ])

    def test_09_admin_templates_and_assets_are_split_and_session_bounded(self) -> None:
        sys.path.insert(0, str(APP))
        from metod_app.admin.presentation import (  # noqa: E402
            ADMIN_ASSETS,
            ADMIN_HTML,
            ADMIN_LOGIN_HTML,
        )

        self.assertEqual(set(ADMIN_ASSETS), {
            "/admin/assets/admin.css",
            "/admin/assets/admin.js",
            "/admin/assets/dxf.js",
            "/admin/assets/login.css",
            "/admin/assets/login.js",
        })
        self.assertTrue(ADMIN_ASSETS["/admin/assets/admin.css"].requires_session)
        self.assertTrue(ADMIN_ASSETS["/admin/assets/admin.js"].requires_session)
        self.assertTrue(ADMIN_ASSETS["/admin/assets/dxf.js"].requires_session)
        self.assertFalse(ADMIN_ASSETS["/admin/assets/login.css"].requires_session)
        self.assertFalse(ADMIN_ASSETS["/admin/assets/login.js"].requires_session)

        for name, html in (("admin", ADMIN_HTML), ("login", ADMIN_LOGIN_HTML)):
            parser = ShellParser()
            parser.feed(html)
            self.assertEqual(parser.style_elements, 0, name)
            self.assertEqual(parser.style_attributes, [], name)
            self.assertEqual(parser.event_attributes, [], name)
            self.assertEqual(parser.javascript_urls, [], name)
            self.assertTrue(all(script.get("src", "").startswith("/admin/assets/") for script in parser.scripts), name)
        self.assertNotRegex(ADMIN_LOGIN_HTML, r'<input[^>]+name="username"[^>]+value=')

        for path, asset in ADMIN_ASSETS.items():
            if path.endswith(".js"):
                for token in ("eval(", "new Function(", "document.write(", "http://", "https://"):
                    self.assertNotIn(token, asset.body, path)


if __name__ == "__main__":
    unittest.main(verbosity=2)
