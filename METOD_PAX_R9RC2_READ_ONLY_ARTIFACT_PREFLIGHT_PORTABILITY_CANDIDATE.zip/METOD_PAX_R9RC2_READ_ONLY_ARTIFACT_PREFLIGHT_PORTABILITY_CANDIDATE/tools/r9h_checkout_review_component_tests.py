#!/usr/bin/env python3
from __future__ import annotations

import ast
import base64
import hashlib
import json
import subprocess
import unittest
from pathlib import Path

from r9h_shell_source import read_toola_expanded


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
COMPONENT = APP / "tool-a/components/checkout-review.js"
BOOTSTRAP = APP / "tool-a/bootstrap.js"
HTML = APP / "toolA.html"
RULES = ROOT / "R9B_ARCHITECTURE_RULES.json"


def data_url(path: Path) -> str:
    return "data:text/javascript;base64," + base64.b64encode(path.read_bytes()).decode()


def run_node(source: str) -> dict:
    completed = subprocess.run(
        ["node", "--input-type=module"], input=source, text=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=10, check=False,
    )
    if completed.returncode != 0:
        raise AssertionError(completed.stdout)
    return json.loads(completed.stdout.strip().splitlines()[-1])


def assignment_set(path: Path, name: str) -> set[str]:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(
            isinstance(target, ast.Name) and target.id == name for target in node.targets
        ):
            value = node.value
            if isinstance(value, ast.Call) and isinstance(value.func, ast.Name) and value.func.id == "frozenset":
                value = value.args[0]
            return set(ast.literal_eval(value))
    raise AssertionError(name)


class R9HCheckoutReviewComponentTests(unittest.TestCase):
    def test_01_component_surface_is_frozen_and_revisioned(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});
const c=m.createCheckoutReviewComponent({{documentRef:{{}},rootRef:{{}}}});
console.log(JSON.stringify({{build:m.CHECKOUT_REVIEW_COMPONENT_BUILD,componentBuild:c.BUILD,frozen:Object.isFrozen(c),keys:Reflect.ownKeys(c)}}));
""")
        self.assertEqual(result["build"], "R9H_CHECKOUT_REVIEW_COMPONENT_8")
        self.assertEqual(result["componentBuild"], result["build"])
        self.assertTrue(result["frozen"])
        self.assertEqual(result["keys"], [
            "BUILD", "bind", "handleEvent", "captureCustomerSnapshot",
            "render", "canSubmit", "announceReady",
        ])

    def test_02_capture_preserves_live_customer_and_calculation_snapshot(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});
const values={{custFirstName:' Ada ',custLastName:'Zaag',custCompany:'Werkplaats BV',custEmail:'ada@example.invalid',custPhone:'0612',custBillingAddress:'Houtstraat',custShippingAddress:'Magazijnweg',custPostcode:'1234 AB',custHouseNumber:'7',custNote:'Bel vooraf'}};
const els=Object.fromEntries(Object.entries(values).map(([id,value])=>[id,{{value}}]));els.custShipSame={{checked:false}};
const state={{checkout:{{}}}};const rootRef={{state}};const c=m.createCheckoutReviewComponent({{documentRef:{{getElementById:id=>els[id]||null}},rootRef}});
const out=c.captureCustomerSnapshot();out.email='changed';
console.log(JSON.stringify({{live:rootRef.__metod_checkout_live_customer,checkout:state.checkout,last:state.lastCalculatedCustomer}}));
""")
        self.assertEqual(result["live"]["firstName"], "Ada")
        self.assertEqual(result["live"]["shippingAddress"], "Magazijnweg")
        self.assertFalse(result["live"]["shippingSameAsBilling"])
        self.assertEqual(result["checkout"]["note"], "Bel vooraf")
        self.assertEqual(result["checkout"]["customerSnapshot"]["email"], "ada@example.invalid")
        self.assertEqual(result["last"]["email"], "ada@example.invalid")

    def test_03_empty_form_does_not_erase_snapshot_unless_forced(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});const state={{checkout:{{note:'keep'}}}};const prior={{email:'saved@example.invalid'}};
const doc={{getElementById:id=>id==='custShipSame'?{{checked:true}}:{{value:''}}}};const rootRef={{state,__metod_checkout_live_customer:prior}};
const c=m.createCheckoutReviewComponent({{documentRef:doc,rootRef}});const normal=c.captureCustomerSnapshot();const forced=c.captureCustomerSnapshot({{force:true}});
console.log(JSON.stringify({{normal,forced,stored:rootRef.__metod_checkout_live_customer,note:state.checkout.note}}));
""")
        self.assertEqual(result["normal"]["email"], "saved@example.invalid")
        self.assertEqual(result["forced"]["email"], "")
        self.assertEqual(result["stored"]["email"], "")
        self.assertEqual(result["note"], "")

    def test_04_single_physical_submit_event_delegates_once(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});let submitCalls=0,prevented=0,stopped=0;
const values={{custEmail:'ada@example.invalid'}};const doc={{getElementById:id=>id==='custShipSame'?{{checked:true}}:{{value:values[id]||''}}}};
const button={{closest:s=>s.includes('sendConfigBtn')?button:null}};const rootRef={{state:{{checkout:{{}}}},__metodSubmitFinalConfiguration:b=>{{submitCalls++;return Promise.resolve(b);}}}};
const c=m.createCheckoutReviewComponent({{documentRef:doc,rootRef}});const handled=c.handleEvent({{type:'click',target:button,preventDefault:()=>prevented++,stopImmediatePropagation:()=>stopped++}});
await Promise.resolve();console.log(JSON.stringify({{handled,submitCalls,prevented,stopped,email:rootRef.state.checkout.customerSnapshot.email}}));
""")
        self.assertEqual(result, {
            "handled": True, "submitCalls": 1, "prevented": 1, "stopped": 1,
            "email": "ada@example.invalid",
        })

    def test_05_render_uses_immutable_customer_view_snapshot(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});const els={{}};for(const id of ['priceRO_personal','priceRO_contact','priceRO_address','priceCustomerSummary','priceMaterialSummary','priceGrainLine','pricePanelCountLine'])els[id]={{textContent:'',innerHTML:''}};
const state={{cart:[],extraPanels:[],checkout:{{customer:{{email:'stale@example.invalid'}}}}}};const view={{readSucceeded:true,customerSnapshot:{{firstName:'Ada',lastName:'Zaag',company:'Werkplaats BV',email:'sealed@example.invalid',phone:'0612',billingAddress:'Houtstraat',shippingAddress:'Magazijnweg',postcode:'1234 AB',houseNumber:'7'}}}};
const c=m.createCheckoutReviewComponent({{documentRef:{{getElementById:id=>els[id]||null}},rootRef:{{state}},getCustomerView:()=>view}});const ok=c.render();
console.log(JSON.stringify({{ok,personal:els.priceRO_personal.textContent,contact:els.priceRO_contact.textContent,address:els.priceRO_address.textContent,summary:els.priceCustomerSummary.textContent}}));
""")
        self.assertTrue(result["ok"])
        self.assertEqual(result["personal"], "Ada Zaag\nWerkplaats BV")
        self.assertIn("sealed@example.invalid", result["contact"])
        self.assertNotIn("stale@example.invalid", result["contact"])
        self.assertIn("Factuur: Houtstraat 1234 AB 7", result["address"])

    def test_06_review_materials_grain_and_counts_match_existing_projection(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});const els={{}};for(const id of ['priceRO_personal','priceRO_contact','priceRO_address','priceCustomerSummary','priceMaterialSummary','priceGrainLine','pricePanelCountLine'])els[id]={{textContent:'',innerHTML:''}};
const state={{checkout:{{customer:{{email:'a@b.test'}}}},materialBatches:[{{key:'oak',grainEnabled:true,mat:{{articleNumber:'A1',productName:'Eik & <Mooi>'}}}},{{key:'white',grainEnabled:false,mat:{{articleNumber:'B2',productName:'Wit'}}}}],cart:[{{materialKey:'oak',qty:2,rotationAllowed:false}},{{materialKey:'white',qty:1}}],extraPanels:[{{materialKey:'white',qty:3}}]}};
const c=m.createCheckoutReviewComponent({{documentRef:{{getElementById:id=>els[id]||null}},rootRef:{{state}}}});c.render();
console.log(JSON.stringify({{materials:els.priceMaterialSummary.innerHTML,grain:els.priceGrainLine.innerHTML,count:els.pricePanelCountLine.textContent}}));
""")
        self.assertIn("Eik &amp; &lt;Mooi&gt;", result["materials"])
        self.assertIn("· 2 panelen", result["materials"])
        self.assertIn("AAN (geen rotatie)", result["grain"])
        self.assertIn("UIT (rotatie toegestaan)", result["grain"])
        self.assertEqual(result["count"], "6")

    def test_07_submit_readiness_requires_snapshot_email_and_panels(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});const rootRef={{state:{{checkout:{{customer:{{email:'a@b.test'}}}},cart:[{{qty:1}}],extraPanels:[]}}}};const c=m.createCheckoutReviewComponent({{documentRef:{{}},rootRef}});
const ready=c.canSubmit();rootRef.state.cart=[];const noPanels=c.canSubmit();rootRef.state.extraPanels=[{{qty:1}}];rootRef.state.checkout.customer.email='';const noEmail=c.canSubmit();console.log(JSON.stringify({{ready,noPanels,noEmail}}));
""")
        self.assertEqual(result, {"ready": True, "noPanels": False, "noEmail": False})

    def test_08_bind_uses_early_safari_adapter_without_duplicate_listeners(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});const listeners=[];const documentRef={{addEventListener:(...args)=>listeners.push(args[0]),getElementById:()=>null}};const rootRef={{__TOOLA_FIRST_EVENT_OWNER_BUILD:'R9G8_SINGLE_FINAL_SUBMIT_CLICK_ADAPTER'}};const c=m.createCheckoutReviewComponent({{documentRef,rootRef}});
console.log(JSON.stringify({{first:c.bind(),second:c.bind(),listeners,compat:typeof rootRef.__metodCommitLiveCustomer}}));
""")
        self.assertEqual(result, {"first": True, "second": False, "listeners": [], "compat": "function"})

    def test_09_bind_fallback_and_ready_event_are_idempotent(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});const listeners=[],events=[];class E{{constructor(type){{this.type=type;}}}};const documentRef={{addEventListener:t=>listeners.push(t),dispatchEvent:e=>events.push(e.type),getElementById:()=>null}};const c=m.createCheckoutReviewComponent({{documentRef,rootRef:{{Event:E}}}});c.bind();
console.log(JSON.stringify({{listeners,first:c.announceReady(),second:c.announceReady(),events}}));
""")
        self.assertEqual(result["listeners"], ["input", "change", "click"])
        self.assertEqual(result["events"], ["tool-a-checkout-review-owner-ready"])
        self.assertTrue(result["first"])
        self.assertFalse(result["second"])

    def test_10_bootstrap_and_html_publish_one_native_checkout_route(self) -> None:
        bootstrap = BOOTSTRAP.read_text(encoding="utf-8")
        html = read_toola_expanded(HTML)
        self.assertEqual(bootstrap.count('from "./components/checkout-review.js"'), 1)
        self.assertEqual(bootstrap.count("createCheckoutReviewComponent({"), 1)
        self.assertIn('"R9RC1_PROFESSIONAL_ARCHITECTURE_COMPLETION"', bootstrap)
        self.assertIn('mode: "legacy-read-cleanup-adapter"', bootstrap)
        for method in (
            "bindCheckoutReview", "handleCheckoutReviewEvent", "captureCheckoutCustomer",
            "renderCheckoutReview", "canSubmitCheckoutReview",
        ):
            self.assertEqual(bootstrap.count(f"  {method}:"), 1, method)
        self.assertIn("tool-a/bootstrap.js?v=r9rc1-professional-architecture-completion", html)
        self.assertEqual(html.count("handleCheckoutReviewEvent?.(event)"), 3)
        self.assertEqual(html.count("owner.renderCheckoutReview({state})"), 1)
        self.assertEqual(html.count("owner.canSubmitCheckoutReview({state})"), 1)

    def test_11_architecture_serves_eighteen_modules_and_nine_dom_owners(self) -> None:
        rules = json.loads(RULES.read_text(encoding="utf-8"))["frontend"]
        owner = "app/tool-a/components/checkout-review.js"
        self.assertIn(owner, rules["domOwnerModules"])
        self.assertEqual(rules["moduleImports"][owner], [])
        self.assertEqual(len(rules["domOwnerModules"]), 10)
        self.assertEqual(len(rules["publicStaticFiles"]), 19)
        server = assignment_set(APP / "metod_app/http/static.py", "PUBLIC_STATIC_MODULE_FILES")
        matcher = assignment_set(APP / "metod_app/http/static.py", "PUBLIC_STATIC_MODULE_FILES")
        self.assertEqual(server, matcher)
        self.assertEqual(len(server), 19)

    def test_12_network_pricing_payload_css_consent_and_thank_you_are_protected(self) -> None:
        exact = {
            "tool-a/api/jobs.js": "eab6fb65e7886d7cb38be81fb1a2a6bcf912e5b6fea88f0a80ca773456b83e70",
            "tool-a/api/requests.js": "4760bfd9733c8739ca96a15cdb3c8f3ef65028b3e95d61c061721cbe125c445e",
            "pricing_helpers.py": "646c2f5186e9b080f6ba8dcf364884411c18e946254bb5c9001647f7cbb425df",
            "dxf_nesting_optimizer.py": "42480b301cd660dac1e5e9fec2c8d30bb5c6826c32234a9c1cce765b758bebb8",
        }
        for name, digest in exact.items():
            self.assertEqual(hashlib.sha256((APP / name).read_bytes()).hexdigest(), digest, name)
        html = read_toola_expanded(HTML)
        start = html.index("async function buildJobPayload(){")
        end = html.index("  // ---------------------------\n  // Checkout overlays (restmateriaal + klantgegevens)", start)
        payload = html[start:end].encode()
        self.assertEqual((len(payload), hashlib.sha256(payload).hexdigest()),
                         (9697, "342dac02c2650ac2798e20e62d38d8e1e6b7d518a54daa8fd760d734ae527e47"))
        self.assertIn("Door deze aanvraag te verzenden, ga je akkoord met de bovenstaande totaalprijs incl. btw.", html)
        self.assertEqual(html.count("thankYouOwner.showSubmissionThankYou({"), 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
