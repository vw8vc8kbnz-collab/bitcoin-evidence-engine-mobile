#!/usr/bin/env python3
from __future__ import annotations

"""One-shot split of archive transactions from periodic retention policy."""

import ast
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
APPLICATION = APP / "metod_app/runtime/application.py"
RETENTION = APP / "metod_app/storage/retention_runtime.py"
ARCHIVE = APP / "metod_app/storage/archive_runtime.py"

ARCHIVE_METHODS = (
    "_parse_iso_dt",
    "_path_dt",
    "_request_status_path",
    "_request_created_dt_from_status",
    "_request_archive_meta_dt",
    "_job_created_dt",
    "_write_archive_meta",
    "_unique_archive_dest",
    "_archive_journal_path",
    "_archive_journal_write",
    "_archive_journal_entries",
    "_complete_archive_journal",
    "_reconcile_archive_transactions",
    "_linked_job_ids_from_status",
    "_archive_request_and_linked_jobs",
)
RETENTION_METHODS = (
    "_purge_old_archives",
    "_request_is_terminal_for_retention",
    "_archive_expired_active_data",
    "_cleanup_operational_state",
    "_move_queue_file_safe",
    "_mark_request_failed_if_stale",
    "_record_maintenance_failure",
    "_server_maintenance_loop",
)


def _module(source: str, nodes: dict[str, ast.FunctionDef], class_name: str,
            names: tuple[str, ...]) -> str:
    lines = source.splitlines(keepends=True)
    methods = "\n\n".join(
        "".join(lines[nodes[name].lineno - 1 : nodes[name].end_lineno]).rstrip()
        for name in names
    )
    return (
        "from __future__ import annotations\n\n"
        f'"""Bounded {class_name} implementation with explicit runtime injection."""\n\n'
        f"class {class_name}:\n"
        "    def __init__(self, runtime):\n"
        "        self._runtime = runtime\n\n"
        + methods
        + "\n\n"
        f"    EXPORTS = {names!r}\n\n"
        f"__all__ = (\"{class_name}\",)\n"
    )


def main() -> int:
    if ARCHIVE.exists():
        raise RuntimeError("R9RC1 retention runtime has already been split")
    source = RETENTION.read_text(encoding="utf-8", errors="strict")
    tree = ast.parse(source)
    owner = next(node for node in tree.body if isinstance(node, ast.ClassDef))
    nodes = {
        node.name: node
        for node in owner.body
        if isinstance(node, ast.FunctionDef) and node.name != "__init__"
    }
    expected = set(ARCHIVE_METHODS) | set(RETENTION_METHODS)
    if set(nodes) != expected:
        raise RuntimeError(f"retention ownership drifted: {sorted(set(nodes) ^ expected)}")
    ARCHIVE.write_text(_module(source, nodes, "ArchiveRuntime", ARCHIVE_METHODS), encoding="utf-8")
    RETENTION.write_text(
        _module(source, nodes, "RetentionRuntime", RETENTION_METHODS),
        encoding="utf-8",
    )

    application = APPLICATION.read_text(encoding="utf-8", errors="strict")
    start = application.index("from metod_app.storage.retention_runtime import RetentionRuntime")
    end = application.index("from metod_app.requests.runtime import RequestRuntime", start)
    archive_bindings = "\n".join(
        f"{name} = _ARCHIVE_RUNTIME.{name}" for name in ARCHIVE_METHODS
    )
    retention_bindings = "\n".join(
        f"{name} = _RETENTION_RUNTIME.{name}" for name in RETENTION_METHODS
    )
    replacement = (
        "from metod_app.storage.archive_runtime import ArchiveRuntime\n"
        "_ARCHIVE_RUNTIME = ArchiveRuntime(sys.modules[__name__])\n"
        + archive_bindings
        + "\n\n"
        "from metod_app.storage.retention_runtime import RetentionRuntime\n"
        "_RETENTION_RUNTIME = RetentionRuntime(sys.modules[__name__])\n"
        + retention_bindings
        + "\n\n"
    )
    APPLICATION.write_text(application[:start] + replacement + application[end:], encoding="utf-8")
    print("split archive transactions from periodic retention policy")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
