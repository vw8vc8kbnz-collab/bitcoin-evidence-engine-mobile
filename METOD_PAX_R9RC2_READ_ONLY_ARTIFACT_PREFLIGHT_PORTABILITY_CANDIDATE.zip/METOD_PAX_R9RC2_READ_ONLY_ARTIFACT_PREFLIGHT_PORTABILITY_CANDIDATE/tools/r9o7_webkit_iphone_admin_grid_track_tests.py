#!/usr/bin/env python3
from __future__ import annotations

import json
import re
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


class R9O7WebKitIphoneAdminGridTrackTests(unittest.TestCase):
    def test_r9o6_external_evidence_is_bound_without_reclassifying_the_failure(self) -> None:
        contract = json.loads((ROOT / "R9O7_WEBKIT_IPHONE_ADMIN_GRID_TRACK_REMEDIATION.json").read_text(encoding="utf-8"))
        evidence = contract["r9o6Evidence"]
        self.assertEqual(evidence["evidenceZipSha256"], "d49ee1875baf9e31e7e1050221e79109c73d7578db16a5c21d08f7666530cbf0")
        self.assertEqual(evidence["status"], "FAIL")
        self.assertEqual((evidence["passedFixtureCount"], evidence["failedFixtureCount"]), (14, 1))
        self.assertEqual(evidence["contractAssertionCount"], 100)
        self.assertEqual(evidence["failedProfile"], "webkit-iphone")
        self.assertFalse(contract["releaseEligible"])
        self.assertFalse(contract["productionGo"])

    def test_mobile_admin_pages_uses_an_explicit_zero_minimum_grid_track(self) -> None:
        css = (ROOT / "app/metod_app/admin/assets/admin.css").read_text(encoding="utf-8")
        mobile = re.search(r"@media \(max-width:640px\)\{(?P<body>.*?)\n\}", css, re.DOTALL)
        self.assertIsNotNone(mobile)
        body = mobile.group("body")
        self.assertIn(".adminPages{grid-template-columns:minmax(0,1fr);}", body)
        self.assertIn(".adminSection{min-width:0;max-width:100%;}", body)

    def test_fix_does_not_hide_overflow_or_weaken_the_oracle(self) -> None:
        css = (ROOT / "app/metod_app/admin/assets/admin.css").read_text(encoding="utf-8")
        self.assertNotIn("overflow-x:hidden", css)
        self.assertNotIn("overflow-x:clip", css)

    def test_scope_preserves_the_exact_external_rerun(self) -> None:
        scope = json.loads((ROOT / "R9O7_WEBKIT_IPHONE_ADMIN_GRID_TRACK_REMEDIATION_SCOPE.json").read_text(encoding="utf-8"))
        rerun = scope["requiredExternalRerun"]
        self.assertEqual(rerun["checkpoint"], "R9O8_EXTERNAL_CHROMIUM_WEBKIT_RERUN")
        self.assertEqual(rerun["fixtures"], 15)
        self.assertEqual(rerun["contractAssertions"], 100)
        self.assertEqual(rerun["engines"], ["chromium", "webkit"])
        self.assertEqual(rerun["networkMode"], "none")
        self.assertFalse(scope["productionGo"])

if __name__ == "__main__":
    unittest.main(verbosity=2)
