#!/usr/bin/env python3
from __future__ import annotations

"""Outcome-based customer-data, logging and browser-security gate for R9RC1."""

import json
import os
import stat
import subprocess
import sys
import tempfile
import threading
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"


class R9RC1SecurityPrivacyTests(unittest.TestCase):
    def test_01_atomic_json_is_private_by_default(self) -> None:
        sys.path.insert(0, str(APP))
        from server_helpers import atomic_write_json

        with tempfile.TemporaryDirectory(prefix="r9rc1-private-json-") as temporary:
            target = Path(temporary) / "secret.json"
            atomic_write_json(target, {"token": "not-a-real-secret"})
            if os.name != "nt":
                self.assertEqual(stat.S_IMODE(target.stat().st_mode), 0o600)

    def test_02_request_status_is_private_and_index_is_pii_free(self) -> None:
        sys.path.insert(0, str(APP))
        from metod_app.requests.repository import RequestRepository

        with tempfile.TemporaryDirectory(prefix="r9rc1-request-repository-") as temporary:
            root = Path(temporary)
            requests = root / "requests"
            index = root / "index" / "requests.jsonl"
            lock = threading.RLock()
            repository = RequestRepository(
                requests_root=lambda: requests,
                requests_index=lambda: index,
                index_lock=lambda: lock,
                ensure_directories=lambda: requests.mkdir(parents=True, exist_ok=True),
                utc_now_iso=lambda: "2026-08-26T12:00:00Z",
                jsonl_max_bytes=lambda: 1024 * 1024,
                max_active_rows=lambda: 1000,
                file_lock_module=lambda: None,
            )
            status = {
                "createdAt": "2026-08-26T12:00:00Z",
                "customer": {"name": "Audit Persoon", "email": "audit@example.invalid"},
                "cancelControl": {"cancelToken": "private-cancel-value"},
                "publicStatus": "SUBMITTED",
                "internalStatus": "DONE",
                "quoteStatus": "TODO",
                "needsQuote": True,
                "job": {"parentJobId": "job_1"},
            }
            repository.save_status("request_1", status)
            status_path = requests / "request_1" / "status.json"
            if os.name != "nt":
                self.assertEqual(stat.S_IMODE(status_path.stat().st_mode), 0o600)
                self.assertEqual(stat.S_IMODE(index.stat().st_mode), 0o640)
            index_text = index.read_text(encoding="utf-8")
            for secret in ("Audit Persoon", "audit@example.invalid", "private-cancel-value"):
                self.assertNotIn(secret, index_text)

    def test_03_runtime_customer_state_directories_are_service_private(self) -> None:
        with tempfile.TemporaryDirectory(prefix="r9rc1-state-modes-") as temporary:
            state_root = Path(temporary) / "state"
            script = """
import json, os, stat
import server_py as runtime
runtime._initialize_external_state()
paths = {
    name: getattr(runtime, name)
    for name in (
        'JOBS', 'DRAFTS', 'REQUESTS', 'QUEUE_PENDING', 'QUEUE_PROCESSING',
        'QUEUE_DONE', 'QUEUE_FAILED', 'SUBMISSION_IDEMPOTENCY_DIR',
        'ARCHIVE_JOBS', 'ARCHIVE_REQUESTS', 'ARCHIVE_QUEUE_DONE',
        'ARCHIVE_QUEUE_FAILED',
    )
}
paths['CLIENT_LOG_ROOT'] = runtime.STATE_ROOT / 'client_logs'
print(json.dumps({name: stat.S_IMODE(path.stat().st_mode) for name, path in paths.items()}))
"""
            environment = dict(os.environ)
            environment.update({
                "METOD_STATE_ROOT": str(state_root),
                "PYTHONDONTWRITEBYTECODE": "1",
            })
            result = subprocess.run(
                [sys.executable, "-B", "-c", script], cwd=APP, env=environment,
                text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                timeout=30, check=False,
            )
            self.assertEqual(result.returncode, 0, result.stdout)
            modes = json.loads(result.stdout.strip().splitlines()[-1])
            if os.name != "nt":
                self.assertTrue(modes)
                self.assertEqual(set(modes.values()), {0o700})

    def test_04_operational_event_log_drops_customer_name_and_redacts_details(self) -> None:
        with tempfile.TemporaryDirectory(prefix="r9rc1-log-redaction-") as temporary:
            script = """
import json
import server_py as runtime
runtime._initialize_external_state()
runtime._append_system_event(
    message_user='Veilige melding', message_tech='Bearer top-secret-value',
    customer_name='Audit Persoon', details={'email': 'audit@example.invalid'},
)
line = runtime.SYSTEM_LOG_FILE.read_text(encoding='utf-8').splitlines()[-1]
print(json.dumps(json.loads(line)))
"""
            environment = dict(os.environ)
            environment.update({
                "METOD_STATE_ROOT": str(Path(temporary) / "state"),
                "PYTHONDONTWRITEBYTECODE": "1",
            })
            result = subprocess.run(
                [sys.executable, "-B", "-c", script], cwd=APP, env=environment,
                text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                timeout=30, check=False,
            )
            self.assertEqual(result.returncode, 0, result.stdout)
            record = json.loads(result.stdout.strip().splitlines()[-1])
            encoded = json.dumps(record, ensure_ascii=False)
            self.assertEqual(record["customerName"], "")
            for secret in ("Audit Persoon", "audit@example.invalid", "top-secret-value"):
                self.assertNotIn(secret, encoded)

    def test_05_browser_does_not_persist_customer_fields_or_intercept_console(self) -> None:
        sources = []
        for path in sorted(APP.rglob("*.js")) + sorted(APP.rglob("*.jsfrag")):
            if path.name == "classic-runtime.bundle.js":
                continue
            sources.append(path.read_text(encoding="utf-8", errors="strict"))
        source = "\n".join(sources)
        for forbidden in (
            "console.error = function", "console.warn = function", "Job result:",
            "document.cookie", "ToolAR9Foundation",
        ):
            self.assertNotIn(forbidden, source)
        sensitive_write_tokens = (
            "customer", "firstname", "lastname", "email", "phone", "address",
            "postcode", "company", "note", "draft",
        )
        for line in source.splitlines():
            lowered = line.lower()
            if "localstorage.setitem" in lowered or "sessionstorage.setitem" in lowered:
                self.assertFalse(any(token in lowered for token in sensitive_write_tokens), line)

    def test_06_customer_shell_has_no_inline_script_or_style_attack_surface(self) -> None:
        html = (APP / "toolA.html").read_text(encoding="utf-8")
        self.assertNotIn("<style", html.lower())
        self.assertNotRegex(html, r"(?i)\sstyle\s*=")
        self.assertNotRegex(html, r"(?i)\son[a-z]+\s*=")
        self.assertNotRegex(html, r"(?is)<script(?![^>]*\bsrc=)[^>]*>.*?</script>")
        self.assertEqual(html.count("<script"), 3)
        self.assertEqual(html.count('rel="stylesheet"'), 1)

    def test_07_public_static_policy_does_not_expose_sources_state_or_configuration(self) -> None:
        sys.path.insert(0, str(APP))
        from metod_app.http.static import is_public_static_relpath

        for denied in (
            "server_py.py", "metod_app/runtime/application.py", "config/pricing.json",
            "jobs/customer/input/job.json", "requests/request_1/status.json",
            "tool-a/runtime/bundle-manifest.json",
            "tool-a/runtime/legacy-source/01-runtime-bootstrap-state.jsfrag",
            "tool-a/shell/script-06-legacy-application-runtime.js",
        ):
            self.assertFalse(is_public_static_relpath(denied), denied)


if __name__ == "__main__":
    unittest.main(verbosity=2)
