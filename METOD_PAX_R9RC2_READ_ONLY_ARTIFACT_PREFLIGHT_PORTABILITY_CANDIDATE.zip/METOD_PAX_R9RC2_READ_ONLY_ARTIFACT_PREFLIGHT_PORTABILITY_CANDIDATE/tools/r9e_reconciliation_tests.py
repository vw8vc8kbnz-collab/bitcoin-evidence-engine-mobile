#!/usr/bin/env python3
from __future__ import annotations

import ast
import json
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
SERVER = APP / "server_py.py"
sys.path.insert(0, str(APP))

from metod_app.jobs.reconciliation import JobRestartReconciler  # noqa: E402
from metod_app.jobs.status import startup_recovery_decision  # noqa: E402


class ReconciliationTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory(prefix="r9e_reconciliation_")
        self.jobs = Path(self.temp.name) / "jobs"
        self.jobs.mkdir()
        self.writes: list[tuple[str, str, dict]] = []
        self.events: list[dict] = []

    def tearDown(self) -> None:
        self.temp.cleanup()

    def seed(self, job_id: str, state: object, *, raw: str | None = None) -> Path:
        path = self.jobs / job_id / "job_state.json"
        path.parent.mkdir(parents=True)
        path.write_text(raw if raw is not None else json.dumps({"state": state}), encoding="utf-8")
        return path

    def service(self, *, fail_save: str = "") -> JobRestartReconciler:
        def validate(value: object) -> str:
            rendered = str(value or "")
            if not rendered.replace("_", "").isalnum():
                raise ValueError("invalid job id")
            return rendered

        def save(job_id: str, state: str, **extra) -> dict:
            if job_id == fail_save:
                raise OSError("injected durable write failure")
            self.writes.append((job_id, state, extra))
            return {"jobId": job_id, "state": state, **extra}

        return JobRestartReconciler(
            jobs_root=self.jobs,
            read_json=lambda path: json.loads(path.read_text(encoding="utf-8")),
            validate_job_id=validate,
            save_runtime_state=save,
            append_system_event=lambda **event: self.events.append(event),
        )

    def test_01_active_and_cancel_states_keep_exact_transitions(self) -> None:
        states = ("ACCEPTED", "PREPARING", "PROCESSING", "FINALIZING", "CANCEL_REQUESTED")
        for index, state in enumerate(states):
            self.seed(f"JOB_{index}", state.lower())
        self.assertEqual(
            self.service().reconcile(recovery_decision=startup_recovery_decision),
            len(states),
        )
        self.assertEqual(self.writes[-1], (
            "JOB_4", "CANCELLED", {"reason": "startup-reconciliation"},
        ))
        for job_id, next_state, extra in self.writes[:-1]:
            self.assertEqual(next_state, "FAILED", job_id)
            self.assertEqual(extra, {
                "reason": "service-restarted-during-processing",
                "retryable": True,
            })

    def test_02_terminal_unknown_and_empty_states_are_untouched(self) -> None:
        for index, state in enumerate(("DONE", "FAILED", "CANCELLED", "UNKNOWN", "")):
            self.seed(f"JOB_{index}", state)
        self.assertEqual(
            self.service().reconcile(recovery_decision=startup_recovery_decision), 0
        )
        self.assertEqual(self.writes, [])
        self.assertEqual(self.events, [])

    def test_03_malformed_state_is_reported_and_scan_continues(self) -> None:
        self.seed("JOB_A", "", raw="{")
        self.seed("JOB_B", "PROCESSING")
        self.assertEqual(
            self.service().reconcile(recovery_decision=startup_recovery_decision), 1
        )
        self.assertEqual([item[0] for item in self.writes], ["JOB_B"])
        self.assertEqual(len(self.events), 1)
        self.assertEqual(self.events[0]["component"], "jobs")
        self.assertEqual(self.events[0]["message_user"], "Jobstate-reconciliatie mislukt")
        self.assertEqual(self.events[0]["job_id"], "JOB_A")
        self.assertEqual(self.events[0]["status"], "open")

    def test_04_invalid_job_identifier_is_reported_fail_closed(self) -> None:
        self.seed("BAD-ID", "ACCEPTED")
        self.assertEqual(
            self.service().reconcile(recovery_decision=startup_recovery_decision), 0
        )
        self.assertEqual(self.writes, [])
        self.assertEqual(self.events[0]["job_id"], "BAD-ID")
        self.assertIn("invalid job id", self.events[0]["message_tech"])

    def test_05_durable_write_failure_does_not_count_and_scan_continues(self) -> None:
        self.seed("JOB_A", "ACCEPTED")
        self.seed("JOB_B", "PROCESSING")
        service = self.service(fail_save="JOB_A")
        self.assertEqual(service.reconcile(recovery_decision=startup_recovery_decision), 1)
        self.assertEqual([item[0] for item in self.writes], ["JOB_B"])
        self.assertEqual(self.events[0]["job_id"], "JOB_A")
        self.assertIn("durable write failure", self.events[0]["message_tech"])

    def test_06_scan_order_is_deterministic(self) -> None:
        self.seed("JOB_Z", "ACCEPTED")
        self.seed("JOB_A", "ACCEPTED")
        self.service().reconcile(recovery_decision=startup_recovery_decision)
        self.assertEqual([item[0] for item in self.writes], ["JOB_A", "JOB_Z"])

    def test_07_artifacts_never_infer_done_without_a_runtime_transition(self) -> None:
        artifact = self.jobs / "JOB_A" / "output" / "finalization.json"
        artifact.parent.mkdir(parents=True)
        artifact.write_text(json.dumps({"state": "COMPLETE"}), encoding="utf-8")
        self.assertEqual(
            self.service().reconcile(recovery_decision=startup_recovery_decision), 0
        )
        self.assertEqual(self.writes, [])

    def test_08_server_composes_one_owner_and_keeps_a_thin_wrapper(self) -> None:
        source = SERVER.read_text(encoding="utf-8")
        tree = ast.parse(source)
        wrapper = next(
            node for node in tree.body
            if isinstance(node, ast.FunctionDef)
            and node.name == "_reconcile_interrupted_jobs_on_startup"
        )
        rendered = ast.get_source_segment(source, wrapper) or ""
        self.assertEqual(source.count("JobRestartReconciler("), 1)
        self.assertLessEqual(len(rendered.splitlines()), 5)
        self.assertIn("_JOB_RESTART_RECONCILER.reconcile(", rendered)
        self.assertIn("_startup_recovery_decision", rendered)

    def test_09_owner_has_no_http_process_optimizer_pricing_or_lock_behavior(self) -> None:
        path = APP / "metod_app/jobs/reconciliation.py"
        source = path.read_text(encoding="utf-8")
        tree = ast.parse(source)
        imports = {
            alias.name.split(".", 1)[0]
            for node in ast.walk(tree) if isinstance(node, ast.Import)
            for alias in node.names
        } | {
            str(node.module or "").split(".", 1)[0]
            for node in ast.walk(tree) if isinstance(node, ast.ImportFrom) and node.level == 0
        }
        self.assertFalse(imports & {
            "http", "os", "pathlib", "server_py", "socket", "subprocess", "threading",
        })
        for token in (
            "Popen(", "pricing_helpers", "dxf_nesting_optimizer",
            "JobFinalizationService", "Lock(", "Thread(", "DONE",
        ):
            self.assertNotIn(token, source)


if __name__ == "__main__":
    unittest.main(verbosity=2)
