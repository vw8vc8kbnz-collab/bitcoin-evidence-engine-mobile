#!/usr/bin/env python3
from __future__ import annotations

"""Remove inline presentation emitted by Tool A runtime templates."""

import hashlib
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
SOURCES = (
    APP / "tool-a/shell/script-06-legacy-application-runtime.js",
    APP / "decor_library.js",
)
CSS = APP / "tool-a/styles/static-utilities.css"
STYLE_ATTRIBUTE = re.compile(r'(<[A-Za-z][^<>]*?)\sstyle="([^"]*)"([^<>]*>)')
MARKER = "/* R9RC1 runtime-template presentation utilities. */"


def _class_name(declarations: str) -> str:
    digest = hashlib.sha256(declarations.encode("utf-8")).hexdigest()[:12]
    return f"tool-dyn-{digest}"


def _replace_state_styles(source: str) -> str:
    replacements = {
        'class="grainRow" data-mkey="${_esc(k)}" style="display:flex;flex-direction:column;gap:10px;padding:12px 14px;border-radius:14px;border:1px solid rgba(0,0,0,.10);background:${isActive?\'rgba(101,129,159,.12)\':\'rgba(255,255,255,.65)\'}"':
            'class="grainRow tool-runtime-grain-row ${isActive?\'is-active\':\'\'}" data-mkey="${_esc(k)}"',
        'class="grainChoiceBtn ${checked?\'is-active\':\'\'}" data-gval="on" aria-pressed="${checked?\'true\':\'false\'}" style="display:flex;flex-direction:column;align-items:flex-start;justify-content:center;gap:2px;text-align:left;padding:10px 12px;border-radius:14px;border:1px solid ${checked?\'rgba(101,129,159,.44)\':\'rgba(0,0,0,.10)\'};background:${checked?\'rgba(101,129,159,.16)\':\'rgba(255,255,255,.92)\'};color:#2b3f52;cursor:pointer;box-shadow:${checked?\'0 10px 24px rgba(101,129,159,.12)\':\'none\'};"':
            'class="grainChoiceBtn tool-runtime-grain-choice ${checked?\'is-active\':\'\'}" data-gval="on" aria-pressed="${checked?\'true\':\'false\'}"',
        'class="grainChoiceBtn ${checked?\'\':\'is-active\'}" data-gval="off" aria-pressed="${checked?\'false\':\'true\'}" style="display:flex;flex-direction:column;align-items:flex-start;justify-content:center;gap:2px;text-align:left;padding:10px 12px;border-radius:14px;border:1px solid ${checked?\'rgba(0,0,0,.10)\':\'rgba(101,129,159,.44)\'};background:${checked?\'rgba(255,255,255,.92)\':\'rgba(101,129,159,.16)\'};color:#2b3f52;cursor:pointer;box-shadow:${checked?\'none\':\'0 10px 24px rgba(101,129,159,.12)\'};"':
            'class="grainChoiceBtn tool-runtime-grain-choice ${checked?\'\':\'is-active\'}" data-gval="off" aria-pressed="${checked?\'false\':\'true\'}"',
    }
    for old, new in replacements.items():
        if source.count(old) != 1:
            raise RuntimeError(f"dynamic presentation contract drifted: {old[:80]}")
        source = source.replace(old, new, 1)
    opacity = 'class="chipDot" style="${active?\'\':\'opacity:.35\'}"'
    if source.count(opacity) != 3:
        raise RuntimeError("active chip opacity contract drifted")
    return source.replace(opacity, 'class="chipDot ${active?\'\':\'tool-runtime-muted\'}"')


def _externalize_literals(source: str, entries: dict[str, str]) -> tuple[str, int]:
    count = 0

    def replace(match: re.Match[str]) -> str:
        nonlocal count
        prefix, declarations, suffix = match.groups()
        if "${" in declarations:
            raise RuntimeError(f"unhandled dynamic runtime style: {declarations}")
        class_name = _class_name(declarations)
        previous = entries.setdefault(class_name, declarations)
        if previous != declarations:
            raise RuntimeError(f"runtime utility hash collision for {class_name}")
        class_match = re.search(r'\bclass="([^"]*)"', prefix)
        if class_match:
            existing = class_match.group(1)
            prefix = prefix[: class_match.start(1)] + f"{existing} {class_name}" + prefix[class_match.end(1) :]
        else:
            prefix += f' class="{class_name}"'
        count += 1
        return prefix + suffix

    return STYLE_ATTRIBUTE.sub(replace, source), count


def main() -> int:
    css = CSS.read_text(encoding="utf-8", errors="strict")
    if MARKER in css:
        raise RuntimeError("R9RC1 runtime presentation migration has already run")
    entries: dict[str, str] = {}
    total = 0
    transformed: dict[Path, str] = {}
    for path in SOURCES:
        source = path.read_text(encoding="utf-8", errors="strict")
        if path.name == "script-06-legacy-application-runtime.js":
            source = _replace_state_styles(source)
        source, count = _externalize_literals(source, entries)
        if STYLE_ATTRIBUTE.search(source):
            raise RuntimeError(f"runtime style attribute remains in {path.name}")
        transformed[path] = source
        total += count
    if total != 47:
        raise RuntimeError(f"expected 47 literal runtime style attributes, found {total}")

    rules = [
        MARKER,
        ".tool-runtime-grain-row{display:flex;flex-direction:column;gap:10px;padding:12px 14px;border-radius:14px;border:1px solid rgba(0,0,0,.10);background:rgba(255,255,255,.65)}",
        ".tool-runtime-grain-row.is-active{background:rgba(101,129,159,.12)}",
        ".tool-runtime-grain-choice{display:flex;flex-direction:column;align-items:flex-start;justify-content:center;gap:2px;text-align:left;padding:10px 12px;border-radius:14px;border:1px solid rgba(0,0,0,.10);background:rgba(255,255,255,.92);color:#2b3f52;cursor:pointer;box-shadow:none}",
        ".tool-runtime-grain-choice.is-active{border-color:rgba(101,129,159,.44);background:rgba(101,129,159,.16);box-shadow:0 10px 24px rgba(101,129,159,.12)}",
        ".tool-runtime-muted{opacity:.35}",
    ]
    rules.extend(f".{name}{{{declarations}}}" for name, declarations in sorted(entries.items()))
    for path, source in transformed.items():
        path.write_text(source, encoding="utf-8")
    CSS.write_text(css.rstrip() + "\n\n" + "\n".join(rules) + "\n", encoding="utf-8")
    print(f"externalized {total} literal and 6 state-dependent runtime style attributes")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
