#!/usr/bin/env python3
from __future__ import annotations

"""Behavior and ownership proof for the R9C pure-identifier extraction."""

import ast
import importlib
import itertools
import os
import re
import sys
import tempfile
import unittest
from pathlib import Path
from typing import Any


RELEASE = Path(__file__).resolve().parents[1]
APP = RELEASE / "app"
SERVER = APP / "server_py.py"
sys.path.insert(0, str(APP))

from metod_app.identifiers import (  # noqa: E402
    safe_identifier,
    sanitize_filename,
    sanitize_key,
)


def reference_sanitize_filename(name: Any, max_len: int = 120) -> str:
    try:
        raw = str(name or "")
    except Exception:
        raw = ""
    raw = raw.replace("\\", "_").replace("/", "_")
    raw = re.sub(r"[^A-Za-z0-9.,_ -]+", "_", raw).strip(" ._")
    if not raw:
        return ""
    try:
        limit = max(1, int(max_len or 120))
    except Exception:
        limit = 120
    return raw[:limit]


def reference_safe_identifier(value: str, max_len: int = 80) -> str:
    raw = str(value or "").strip()
    limit = min(120, max(1, int(max_len or 80)))
    if len(raw) > limit or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]*", raw):
        return ""
    return raw


def reference_sanitize_key(value: str) -> str:
    raw = str(value or "").strip()
    return re.sub(r"[^A-Za-z0-9_\-]+", "_", raw) or "mat"


class BrokenString:
    def __str__(self) -> str:
        raise RuntimeError("deliberate")


class R9CIdentifierBehaviorTests(unittest.TestCase):
    def test_filename_characterization_matches_for_broad_inputs(self) -> None:
        alphabet = ("A", "z", "0", " ", ".", "_", "-", "/", "\\", "é", "#")
        values: list[Any] = [None, "", 0, 42, BrokenString()]
        values.extend(
            "".join(chars)
            for size in range(1, 4)
            for chars in itertools.product(alphabet, repeat=size)
        )
        limits: list[Any] = [None, 0, 1, 5, 120, 200, "4", "bad"]
        for value in values:
            for limit in limits:
                self.assertEqual(
                    sanitize_filename(value, limit),
                    reference_sanitize_filename(value, limit),
                    (value, limit),
                )

    def test_safe_identifier_characterization_preserves_hard_120_cap(self) -> None:
        values = [
            None, "", " a ", "A", "A-1_b", "_bad", "-bad", "bad.dot",
            "sp ace", "é", "A" * 120, "A" * 121,
        ]
        for value in values:
            for limit in [None, 0, 1, 5, 80, 120, 200, "4"]:
                self.assertEqual(
                    safe_identifier(value, limit),
                    reference_safe_identifier(value, limit),
                    (value, limit),
                )

    def test_safe_identifier_invalid_limit_exception_is_preserved(self) -> None:
        with self.assertRaises(ValueError):
            safe_identifier("valid", "bad")  # type: ignore[arg-type]

    def test_key_characterization_matches_for_broad_inputs(self) -> None:
        values = [None, "", "   ", 0, 42, "mat-1_A", " a/b ", "één", "###"]
        for value in values:
            self.assertEqual(sanitize_key(value), reference_sanitize_key(value), value)


class R9CIdentifierOwnershipTests(unittest.TestCase):
    def test_server_has_imported_aliases_and_no_duplicate_definitions(self) -> None:
        tree = ast.parse(SERVER.read_text(encoding="utf-8"), filename=str(SERVER))
        definitions = {
            node.name for node in tree.body
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
        }
        self.assertEqual(
            definitions & {"_sanitize_filename", "_safe_id", "_sanitize_key"},
            set(),
        )
        aliases = {
            alias.asname: alias.name
            for node in tree.body
            if isinstance(node, ast.ImportFrom)
            and node.module == "metod_app.identifiers"
            for alias in node.names
        }
        self.assertEqual(
            aliases,
            {
                "_safe_id": "safe_identifier",
                "_sanitize_filename": "sanitize_filename",
                "_sanitize_key": "sanitize_key",
            },
        )

    def test_server_uses_the_single_identifier_owner(self) -> None:
        previous = os.environ.get("METOD_STATE_ROOT")
        with tempfile.TemporaryDirectory(prefix="r9c-identifier-owner-") as temp_name:
            os.environ["METOD_STATE_ROOT"] = str(Path(temp_name) / "state")
            try:
                server = importlib.import_module("server_py")
                self.assertIs(server._sanitize_filename, sanitize_filename)
                self.assertIs(server._safe_id, safe_identifier)
                self.assertIs(server._sanitize_key, sanitize_key)
            finally:
                if previous is None:
                    os.environ.pop("METOD_STATE_ROOT", None)
                else:
                    os.environ["METOD_STATE_ROOT"] = previous

    def test_identifier_module_has_no_runtime_or_io_dependencies(self) -> None:
        path = APP / "metod_app/identifiers.py"
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        imports = {
            alias.name.split(".", 1)[0]
            for node in ast.walk(tree)
            if isinstance(node, ast.Import)
            for alias in node.names
        }
        imports.update(
            node.module.split(".", 1)[0]
            for node in ast.walk(tree)
            if isinstance(node, ast.ImportFrom) and node.module
        )
        self.assertEqual(
            imports & {
                "http", "os", "pathlib", "server_py", "socket", "subprocess", "threading"
            },
            set(),
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
