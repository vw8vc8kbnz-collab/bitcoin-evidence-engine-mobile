#!/usr/bin/env python3
from __future__ import annotations

"""Static, dynamic-evidence and behavior-boundary contracts for R9K5."""

import ast
import hashlib
import json
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
SERVER = APP / "server_py.py"
CONTRACT = ROOT / "R9K5_DEAD_RAW_QUOTE_MERGE_CLEANUP.json"
FIXTURE = ROOT / "R9K5_RAW_QUOTE_MERGE_BEFORE_FIXTURE.json"
DYNAMIC = ROOT / "R9K5_PRE_REMOVAL_DYNAMIC_EVIDENCE.json"
TARGET = "_merge_raw_quotes"
SERVER_SHA256 = "84b3b0d3713d4d6da472d6b7d4351e166aac59e1fde1812cf60ccbd84d77556a"


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


class R9K5DeadRawQuoteMergeCleanupTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.source = SERVER.read_text(encoding="utf-8", errors="strict")
        cls.tree = ast.parse(cls.source)
        cls.contract = json.loads(CONTRACT.read_text(encoding="utf-8", errors="strict"))
        cls.fixture = json.loads(FIXTURE.read_text(encoding="utf-8", errors="strict"))
        cls.dynamic = json.loads(DYNAMIC.read_text(encoding="utf-8", errors="strict"))
        cls.functions = {
            node.name: node
            for node in cls.tree.body
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        }

    def function_source(self, name: str) -> str:
        segment = ast.get_source_segment(self.source, self.functions[name])
        self.assertIsNotNone(segment)
        return str(segment)

    def test_01_target_definition_and_direct_name_loads_are_absent(self) -> None:
        self.assertNotIn(TARGET, self.functions)
        loads = [
            node for node in ast.walk(self.tree)
            if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load) and node.id == TARGET
        ]
        self.assertEqual(loads, [])

    def test_02_application_tree_has_no_exact_target_text(self) -> None:
        occurrences: list[str] = []
        for path in sorted(APP.rglob("*")):
            if not path.is_file() or path.suffix.lower() in {".png", ".jpg", ".webp", ".pyc"}:
                continue
            try:
                text = path.read_text(encoding="utf-8", errors="strict")
            except UnicodeDecodeError:
                continue
            if TARGET in text:
                occurrences.append(path.relative_to(ROOT).as_posix())
        self.assertEqual(occurrences, [])

    def test_03_no_exact_dynamic_lookup_consumer_exists_in_python_application(self) -> None:
        dynamic_names = {"getattr", "setattr", "hasattr", "delattr", "globals", "locals", "vars", "eval", "exec"}
        findings: list[tuple[str, int, str]] = []
        for path in sorted(APP.rglob("*.py")):
            tree = ast.parse(path.read_text(encoding="utf-8", errors="strict"))
            for node in ast.walk(tree):
                if not isinstance(node, ast.Call):
                    continue
                name = node.func.id if isinstance(node.func, ast.Name) else node.func.attr if isinstance(node.func, ast.Attribute) else ""
                literals = [arg.value for arg in node.args if isinstance(arg, ast.Constant) and isinstance(arg.value, str)]
                if name in dynamic_names and TARGET in literals:
                    findings.append((path.relative_to(ROOT).as_posix(), node.lineno, name))
        self.assertEqual(findings, [])

    def test_04_before_function_inventory_is_exact(self) -> None:
        cleanup = self.contract["cleanup"]
        self.assertEqual(cleanup["beforeFunctionSourceSha256"], "d05dd90d65f731b3d5be6322a21ddb11c91a0593161f446149ad5ca04f574682")
        self.assertEqual(cleanup["beforeFunctionLines"], 82)
        self.assertEqual(cleanup["beforeFunctionAstNodes"], 791)
        self.assertEqual(cleanup["beforeFunctionBodyStatements"], 15)
        self.assertEqual(cleanup["directNameConsumersBeforeRemoval"], 0)
        self.assertEqual(cleanup["exactPythonStringConsumersBeforeRemoval"], 0)
        self.assertEqual(cleanup["exactDynamicLookupConsumersBeforeRemoval"], 0)

    def test_05_exact_server_reduction_and_after_hash_are_sealed(self) -> None:
        cleanup = self.contract["cleanup"]
        self.assertEqual(cleanup["removedSourceRegionLines"], 83)
        self.assertEqual(cleanup["serverBytesRemoved"], 3598)
        self.assertEqual(cleanup["serverLinesRemoved"], 83)
        self.assertEqual(
            self.contract["candidate"]["serverSha256"],
            "078a31084bb162bb226fda394f5f4efed52101d75760f5145661b5d33ea8ebc7",
        )
        self.assertEqual(sha256_bytes(SERVER.read_bytes()), SERVER_SHA256)
        self.assertEqual(SERVER.stat().st_size, 474682)
        self.assertEqual(len(SERVER.read_bytes().splitlines()), 10402)

    def test_06_adjacent_functions_are_byte_exact(self) -> None:
        preserved = self.contract["preservedOwners"]
        self.assertEqual(sha256_bytes(self.function_source("_parts_for_panels_rows").encode()), preserved["partsForPanelsRowsSourceSha256"])
        self.assertEqual(sha256_bytes(self.function_source("_customer_display_name").encode()), preserved["customerDisplayNameSourceSha256"])

    def test_07_pricing_and_summary_owners_are_byte_exact(self) -> None:
        preserved = self.contract["preservedOwners"]
        mapping = {
            "_apply_sell_pricing_to_quote": "applySellPricingSourceSha256",
            "_aggregate_materials_from_subjob_quotes": "aggregateMaterialsSourceSha256",
            "_write_human_calculation_summary": "writeCalculationSummarySourceSha256",
        }
        for name, key in mapping.items():
            self.assertEqual(sha256_bytes(self.function_source(name).encode()), preserved[key], name)

    def test_08_finalization_adapter_and_service_are_byte_exact(self) -> None:
        preserved = self.contract["preservedOwners"]
        self.assertEqual(sha256_bytes(self.function_source("_finalize_subjob_outputs").encode()), preserved["finalizeSubjobAdapterSourceSha256"])
        self.assertEqual(
            sha256_bytes((APP / "metod_app/jobs/finalization.py").read_bytes()),
            preserved["finalizationServiceSha256"],
        )

    def test_09_optimizer_geometry_pricing_and_panel_contracts_are_frozen(self) -> None:
        for relative, expected in self.contract["frozenBehaviorFiles"].items():
            self.assertEqual(sha256_bytes((ROOT / relative).read_bytes()), expected, relative)

    def test_10_pre_removal_dynamic_full_preflight_proved_zero_calls(self) -> None:
        self.assertEqual(self.dynamic["sourceCheckpoint"], "R9K4")
        self.assertEqual(self.dynamic["instrumentedTarget"], TARGET)
        self.assertEqual(self.dynamic["gateStatus"], "PASS")
        self.assertEqual(self.dynamic["profilerStarts"], 87)
        self.assertEqual(self.dynamic["uniqueInstrumentedProcessIds"], 87)
        self.assertEqual(self.dynamic["targetCallEvents"], 0)
        self.assertEqual(self.dynamic["rawTraceLines"], 171)
        self.assertEqual(self.dynamic["rawTraceSha256"], "865e146048c6da9e040f7545e4069a34f7f46318c6aebf815c16928a133c8345")

    def test_11_before_result_fixture_is_complete_and_sealed(self) -> None:
        self.assertEqual(self.fixture["sourceCheckpoint"], "R9K4")
        self.assertEqual(self.fixture["sourceFunction"], TARGET)
        self.assertEqual(self.fixture["sourceFunctionSha256"], self.contract["cleanup"]["beforeFunctionSourceSha256"])
        self.assertEqual(self.fixture["input"]["masterJobId"], "MASTER_R9K5")
        self.assertEqual(self.fixture["expected"]["materials"][0]["sheetCount"], 5)
        self.assertEqual(self.fixture["expected"]["totals"], {
            "sheetCostTotal": 58.75,
            "edgeCostTotal": 6.75,
            "grandTotal": 65.5,
        })
        self.assertEqual(self.fixture["expected"]["outputs"], {"subjobs": True})

    def test_12_scope_is_narrow_provisional_and_not_production_go(self) -> None:
        self.assertEqual(self.contract["contractId"], "R9K5_DEAD_RAW_QUOTE_MERGE_CLEANUP")
        self.assertEqual(self.contract["status"], "PROVISIONAL_DEVELOPMENT_ONLY")
        self.assertFalse(self.contract["releaseEligible"])
        self.assertFalse(self.contract["cleanup"]["activeRuntimePathChanged"])
        self.assertFalse(self.contract["cleanup"]["externallyObservableBehaviorExpectedChanged"])
        self.assertFalse(self.contract["externalEvidence"]["productionGo"])
        self.assertEqual(self.contract["executableEvidence"]["cleanupTestCount"], 12)


if __name__ == "__main__":
    unittest.main(verbosity=2)
