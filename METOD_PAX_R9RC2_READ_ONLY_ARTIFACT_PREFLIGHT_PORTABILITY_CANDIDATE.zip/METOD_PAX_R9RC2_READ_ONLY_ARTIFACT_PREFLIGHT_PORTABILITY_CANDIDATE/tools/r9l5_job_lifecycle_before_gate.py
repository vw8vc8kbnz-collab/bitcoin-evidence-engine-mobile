#!/usr/bin/env python3
from __future__ import annotations

"""Seal and reproduce the R9L4 public job lifecycle facade behavior."""

import argparse
import ast
import hashlib
import json
import os
import sys
import tempfile
import threading
import types
from pathlib import Path
from unittest import mock


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
SERVER = APP / "server_py.py"
FIXTURE = ROOT / "R9L5_JOB_LIFECYCLE_BEFORE_FIXTURE.json"
os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")
_STATE_TEMP = tempfile.TemporaryDirectory(prefix="r9l5_lifecycle_import_")
os.environ.setdefault("METOD_STATE_ROOT", str(Path(_STATE_TEMP.name) / "state"))
sys.path.insert(0, str(APP))

import server_py as server  # noqa: E402


HANDLER_OWNERS = (
    "_api_cancel_job",
    "_estimate_job_complexity",
    "_start_async_job_create",
    "_write_api_jobs_crashlog",
    "_api_create_job",
    "_api_status",
)


def _sha256(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def _source_metrics() -> dict[str, object]:
    source = SERVER.read_text(encoding="utf-8", errors="strict")
    tree = ast.parse(source)
    owners: dict[str, object] = {}
    for node in tree.body:
        if isinstance(node, ast.ClassDef) and node.name == "Handler":
            for child in node.body:
                if isinstance(child, ast.FunctionDef) and child.name in HANDLER_OWNERS:
                    segment = ast.get_source_segment(source, child)
                    assert segment is not None
                    owners[f"Handler.{child.name}"] = {
                        "lines": len(segment.splitlines()),
                        "bytes": len(segment.encode("utf-8")),
                        "sha256": _sha256(segment.encode("utf-8")),
                    }
    expected = {f"Handler.{name}" for name in HANDLER_OWNERS}
    if set(owners) != expected:
        raise RuntimeError(f"owner inventory mismatch: {sorted(owners)}")
    return {
        "server": {
            "bytes": len(source.encode("utf-8")),
            "lines": len(source.splitlines()),
            "sha256": _sha256(source.encode("utf-8")),
        },
        "activeOwnerSource": owners,
    }


def _handler() -> object:
    handler = object.__new__(server.Handler)
    handler.headers = {"Content-Length": "2"}
    handler._require_job_access = types.MethodType(lambda self, *a, **k: True, handler)
    handler._send_json = types.MethodType(
        lambda self, body, code=200: {"code": int(code), "body": body}, handler
    )
    handler._sanitize_public_material_response = types.MethodType(
        lambda self, value: value, handler
    )
    handler._public_quote_view = types.MethodType(lambda self, value: value, handler)
    return handler


def _complexity_matrix() -> dict[str, object]:
    payload = {
        "panelsCsv": "PartId;Qty\nA;1\nB;2\n",
        "dxfBlobs": {"one": "abc", "two": "defg"},
        "dxfPartRefs": {"A": "one", "B": "two", "C": "one"},
        "jobJson": {"grain": True},
    }
    with mock.patch.object(server, "_estimate_payload_area_lower_bound", return_value={"maxAreaLowerBound": 7}):
        return {
            "empty": server.Handler._estimate_job_complexity(_handler(), {}),
            "compact": server.Handler._estimate_job_complexity(_handler(), payload),
        }


class _Process:
    def __init__(self, returncode: int | None) -> None:
        self.returncode = returncode

    def poll(self) -> int | None:
        return self.returncode


def _cancel_snapshot(root: Path) -> dict[str, object]:
    jobs = root / "jobs"
    job_id = "R9L5_CANCEL_001"
    (jobs / job_id).mkdir(parents=True)
    handler = _handler()
    events: list[object] = []
    meta = {job_id: {"status": "processing", "phase": "optimizer"}}
    processes = [_Process(None), _Process(0)]
    supervisor = types.SimpleNamespace(active=lambda value: processes)

    def save_state(value: str, state: str, **extra: object) -> dict[str, object]:
        events.append(["state", value, state, extra])
        return {"state": state}

    with mock.patch.multiple(
        server,
        JOBS=jobs,
        _job_meta=meta,
        _job_lock=threading.RLock(),
        _OPTIMIZER_PROCESS_SUPERVISOR=supervisor,
        _client_ip=lambda value: "198.51.100.8",
        _rate_limit_allow=lambda *a, **k: True,
        _read_json_body_limited=lambda *a, **k: {"jobId": job_id},
        _save_job_runtime_state=save_state,
        _cancel_queued_public_job=lambda value: events.append(["cancelQueued", value]) or False,
        _terminate_optimizer_process=lambda value: events.append(["terminate", processes.index(value)]),
        _finish_public_job_slot=lambda value: events.append(["finishSlot", value]) or True,
        _now_iso=lambda: "2026-08-25T00:00:00Z",
    ):
        response = server.Handler._api_cancel_job(handler)
    return {"response": response, "events": events, "meta": meta[job_id]}


def _async_snapshots(root: Path) -> dict[str, object]:
    jobs = root / "async-jobs"
    job_id = "R9L5_ASYNC_001"
    (jobs / job_id / "output").mkdir(parents=True)
    handler = _handler()

    def run_case(kind: str) -> dict[str, object]:
        meta = {job_id: {"status": "processing", "phase": "accepted"}}
        events: list[object] = []

        def commit(ip: str, value: str, runner: object) -> dict[str, object]:
            events.append(["commit", ip, value])
            runner()
            return {"status": "processing", "queuePosition": 0}

        def create(*a: object, **k: object) -> dict[str, object]:
            events.append(["create"])
            if kind == "failed":
                raise RuntimeError("sealed failure")
            return {"jobId": job_id}

        cancelled = kind == "cancelled"
        with mock.patch.multiple(
            server,
            JOBS=jobs,
            _job_meta=meta,
            _job_lock=threading.RLock(),
            _commit_public_job_slot=commit,
            _job_cancel_requested=lambda value: cancelled,
            _create_job_from_payload=create,
            _finalization_complete=lambda *a, **k: True,
            _save_job_runtime_state=lambda value, state, **extra: events.append(["state", state, extra]) or {"state": state},
            _now_iso=lambda: "2026-08-25T00:00:00Z",
            durable_write_text=lambda path, text: events.append(["errorFile", str(text)]),
        ):
            result = server.Handler._start_async_job_create(
                handler, {"payloadSchema": "FIX660R8_SERVER_CANONICAL_V1"}, job_id,
                "token", "198.51.100.9",
            )
        return {"result": result, "events": events, "meta": meta[job_id]}

    return {name: run_case(name) for name in ("success", "failed", "cancelled")}


def _status_matrix(root: Path) -> dict[str, object]:
    jobs = root / "status-jobs"
    jobs.mkdir(parents=True)
    handler = _handler()
    result: dict[str, object] = {}
    with mock.patch.object(server, "JOBS", jobs):
        result["invalid"] = server.Handler._api_status(handler, "../bad")
        result["missing"] = server.Handler._api_status(handler, "R9L5_MISSING")
        for state in ("CANCELLED", "FAILED"):
            job_id = f"R9L5_{state}"
            (jobs / job_id / "output").mkdir(parents=True)
            server._save_job_runtime_state(job_id, state)
            result[state.lower()] = server.Handler._api_status(handler, job_id)
    return result


def _behavior() -> dict[str, object]:
    with tempfile.TemporaryDirectory(prefix="r9l5_lifecycle_behavior_") as tmp:
        root = Path(tmp)
        return {
            "complexityMatrix": _complexity_matrix(),
            "cancelSnapshot": _cancel_snapshot(root),
            "asyncSnapshots": _async_snapshots(root),
            "statusMatrix": _status_matrix(root),
        }


def _payload() -> dict[str, object]:
    return {
        "schemaVersion": 1,
        "fixtureId": "R9L5_JOB_LIFECYCLE_BEFORE_FIXTURE",
        "sourceCheckpoint": "R9L4",
        "sourceCommit": "00a3650b4dcce7238d161829dae789e07f24bd63",
        **_source_metrics(),
        **_behavior(),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--print-fixture", action="store_true")
    args = parser.parse_args()
    if args.print_fixture:
        print(json.dumps(_payload(), indent=2, sort_keys=True))
        return 0
    expected = json.loads(FIXTURE.read_text(encoding="utf-8"))
    actual = _behavior()
    checks = {key: actual[key] == expected[key] for key in actual}
    result = {
        "gate": "R9L5_JOB_LIFECYCLE_BEFORE_GATE",
        "status": "PASS" if all(checks.values()) else "FAIL",
        "checks": checks,
    }
    print(json.dumps(result, sort_keys=True))
    return 0 if all(checks.values()) else 1


if __name__ == "__main__":
    raise SystemExit(main())
