#!/usr/bin/env python3
from __future__ import annotations

"""Fail-closed proof for the R9I-8 unused price compatibility cleanup."""

import hashlib
import json
import unittest
from pathlib import Path

from r9j_hermetic_reference import assert_sealed_file, load_reference


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
COMPAT = APP / "tool-a/shell/script-08-compat.js"
HTML = APP / "toolA.html"
BOOTSTRAP = APP / "tool-a/bootstrap.js"
RULES = ROOT / "R9B_ARCHITECTURE_RULES.json"
REFERENCE = load_reference(ROOT)

REMOVED_CACHE_LINES = """    window.__priceOverlayEls.sendBtn = byId('sendConfigBtn') || byId('btnSendConfig');
    window.__priceOverlayEls.roPersonal = byId('priceRO_personal');
    window.__priceOverlayEls.roContact  = byId('priceRO_contact');
    window.__priceOverlayEls.roAddress  = byId('priceRO_address');
"""

REMOVED_SEND_LINE = "    const send = window.__priceOverlayEls.sendBtn;\n"

REMOVED_QUOTE_HELPER = """  function computeTotalInclFromQuote(q){
    if(!q) return null;
    // 1) already incl
    const direct = q.total_incl_vat ?? q.totalInclVat ?? q.total_incl ?? q.total ?? null;
    if(direct != null && isFinite(Number(direct))) return Number(direct);
    // 2) new schema
    const base = q.totals && (q.totals.grandTotal ?? q.totals.total ?? null);
    if(base != null && isFinite(Number(base))){
      const vat = (typeof VAT_RATE === 'number') ? VAT_RATE : 0.21;
      // treat base as excl -> show incl (best-effort)
      return Number(base) * (1 + vat);
    }
    return null;
  }

"""


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


class R9IUnusedPriceCompatTests(unittest.TestCase):
    def test_01_compat_delta_is_exactly_the_unused_code(self) -> None:
        current = assert_sealed_file(
            self, ROOT, REFERENCE, "app/tool-a/shell/script-08-compat.js",
        ).decode("utf-8")
        for block in (REMOVED_CACHE_LINES, REMOVED_SEND_LINE, REMOVED_QUOTE_HELPER):
            self.assertNotIn(block, current)
        self.assertEqual(REFERENCE["cleanupDeltas"]["unusedPriceCompatibility"]["bytesRemoved"], 929)

    def test_02_active_price_compatibility_behavior_remains(self) -> None:
        source = COMPAT.read_text(encoding="utf-8")
        for token in (
            "window.openPriceOverlay = function()",
            "window.closePriceOverlay = window.closePriceOverlay || function()",
            "refreshPriceOverlay()",
            "renderPriceSummary()",
            "_isAuthoritativePricingPending()",
            "_getFinalAuthoritativePriceForCurrentJob()",
            "_strictAuthoritativePriceInclVat",
            "document.body.style.overflow = 'hidden'",
            "document.body.style.overflow = ''",
        ):
            self.assertIn(token, source)
        for token in (
            "window.__priceOverlayEls.sendBtn",
            "window.__priceOverlayEls.roPersonal",
            "window.__priceOverlayEls.roContact",
            "window.__priceOverlayEls.roAddress",
            "computeTotalInclFromQuote",
        ):
            self.assertNotIn(token, source)

    def test_03_runtime_and_functional_truth_owners_are_byte_exact(self) -> None:
        for relative in (
            "app/tool-a/shell/script-13-fix486-final-single-source-overlay-v2.js",
            "app/tool-a/api/jobs.js",
            "app/tool-a/api/requests.js",
            "app/tool-a/components/checkout-review.js",
            "app/tool-a/components/thank-you.js",
        ):
            assert_sealed_file(self, ROOT, REFERENCE, relative)

    def test_04_html_and_bootstrap_change_only_by_revision_cache_keys(self) -> None:
        html = HTML.read_text(encoding="utf-8")
        bootstrap = assert_sealed_file(self, ROOT, REFERENCE, "app/tool-a/bootstrap.js").decode("utf-8")
        self.assertIn("tool-a/shell/script-08-compat.js?v=" + REFERENCE["applicationCacheRevision"], html)
        self.assertNotIn("r9i-price-overlay-shadow-cleanup-7", html)
        self.assertIn(f'"{REFERENCE["applicationRevision"]}"', bootstrap)
        self.assertNotIn("R9I_PRICE_OVERLAY_SHADOW_CLEANUP_7", bootstrap)
        self.assertIn('content="R9O9"', html)

    def test_05_pricing_optimizer_and_payload_truth_remain_hash_locked(self) -> None:
        exact = {
            "dxf_nesting_optimizer.py": "42480b301cd660dac1e5e9fec2c8d30bb5c6826c32234a9c1cce765b758bebb8",
            "dxf_geometry.py": "b80a2d006241908bf7b33516f7e0faf59ef61e1e08db86966b23cc5de292c1ff",
            "pricing_helpers.py": "646c2f5186e9b080f6ba8dcf364884411c18e946254bb5c9001647f7cbb425df",
            "panel_contract.py": "e23314fd63a2358a48daa580a92cebb8a40c9862548ba0243461a59347da7fc9",
            "toolA_grain_studio_renderer.js": "922cd4ac479fbaf86ebfbb0256808119b96a8344e9b0bf1ffb4f668518a03204",
        }
        for relative, expected in exact.items():
            self.assertEqual(sha256(APP / relative), expected, relative)

    def test_06_architecture_does_not_expand(self) -> None:
        rules = json.loads(RULES.read_text(encoding="utf-8"))["frontend"]
        self.assertEqual(len(rules["moduleImports"]), 19)
        self.assertEqual(len(rules["domOwnerModules"]), 10)
        self.assertEqual(len(rules["networkOwnerModules"]), 2)
        self.assertEqual(rules["compatibilityGlobal"], "ToolAR9Foundation")
        shell = json.loads((ROOT / "R9H10_SEMANTIC_SHELL_ASSETS.json").read_text(encoding="utf-8"))
        self.assertEqual(len(shell["scriptFiles"]), 34)


if __name__ == "__main__":
    unittest.main(verbosity=2)
