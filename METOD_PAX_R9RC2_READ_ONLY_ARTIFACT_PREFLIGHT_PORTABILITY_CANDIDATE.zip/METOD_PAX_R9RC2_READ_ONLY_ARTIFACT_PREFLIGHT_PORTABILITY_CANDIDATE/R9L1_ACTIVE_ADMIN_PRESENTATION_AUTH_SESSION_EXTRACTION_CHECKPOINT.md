# METOD/PAX R9L1 — actieve Admin access-extractie

R9L1 verplaatst de actieve Admin-presentatie, credentialnormalisatie, login,
sessiestatus, cookie-uitgifte, logout en authchallenge naar één eigenaar:
`app/metod_app/admin/access.py`. `Handler` houdt uitsluitend dunne adapters.

De twee HTML-waarden zijn bytegelijk aan R9K5. Dit checkpoint splitst de inline
Admin-CSS en -JavaScript bewust nog niet; die professionele frontendsplitsing is
exclusief R9M-scope. De real-HTTP-suite verzegelt anonieme en geauthenticeerde
Adminweergave, loginbody, cookieattributen, logoutbytes, sessierevocatie en
securityheaders. De unitcontracten verzegelen idle/absolute expiry, rollen,
bounded eviction, TOTP/passwordpaden en de adapters.

Dit is geen productie-GO. Browserengines, echte iPhone/Safari, kandidaat-VPS,
onafhankelijke securityaudit en productie-identieke operationele evidence zijn
nog externe NO_GO-poorten.
