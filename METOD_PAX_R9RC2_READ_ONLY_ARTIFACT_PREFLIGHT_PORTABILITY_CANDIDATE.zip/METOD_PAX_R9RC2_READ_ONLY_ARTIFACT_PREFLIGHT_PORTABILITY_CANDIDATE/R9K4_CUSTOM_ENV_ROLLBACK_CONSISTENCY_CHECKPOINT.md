# R9K4 — custom `METOD_ENV_DIR` rollbackconsistentie

R9K4 corrigeert uitsluitend twee installerdoelen. De configuratiebackup en de
rollback gebruiken nu beide het eerder gevalideerde
`"$ENV_DIR/metod-pax.env"`. Hierdoor blijft het standaardpad identiek en wordt
een ondersteunde custom `METOD_ENV_DIR` niet langer buiten de rollbacktransactie
gelaten.

Het uitvoerbare contract test de echte uit het installerschrift geëxtraheerde
`rollback()`-functie in een geïsoleerde shellharnas. Default/custom env-paden
worden beide vóór en na een gesimuleerde pointer-switch gecontroleerd. De
service- en nginxdoelen blijven exact gelijk; de releasepointer wordt alleen
na een switch teruggezet; externe state wordt nooit teruggedraaid.

R9K4 wijzigt geen server-, API-, Tool A-, optimizer-, pricing-, restore- of
HTML-functionaliteit. De kandidaat blijft provisioneel en niet release-eligible
totdat de uitgestelde browser-, VPS-, apparaat- en onafhankelijke auditgates
werkelijk zijn uitgevoerd.
