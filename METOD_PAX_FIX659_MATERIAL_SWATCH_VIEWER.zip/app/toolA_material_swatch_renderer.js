(function(root){
  'use strict';

  const BUILD = 'FIX659_MATERIAL_SWATCH_VIEWER';
  const cache = new Map();
  const domBindings = new WeakMap();

  function finite(v, fallback){
    const n = Number(v);
    return Number.isFinite(n) ? n : (fallback == null ? 0 : fallback);
  }

  function toKey(v){ return String(v == null ? '' : v).trim(); }

  function normalizeAxis(v){
    const s = String(v == null ? '' : v).trim().toLowerCase();
    if(!s) return 'V';
    if(['u','x','horizontal','horizontaal','width','breedte','cross','dwars'].includes(s)) return 'U';
    if(['v','y','vertical','verticaal','height','hoogte','length','lengte','long','langs'].includes(s)) return 'V';
    return 'V';
  }

  function panelGrainAxis(panel){
    const p = panel || {};
    // FIX659: only explicit LOCAL grain metadata may affect swatch orientation.
    // Never infer from world rotation or from the longest side.
    return normalizeAxis(
      p.localGrainAxis ?? p.grainAxis ?? p.localGrainDirection ?? p.grainDirection ?? p.grain ?? 'V'
    );
  }

  function imageGrainAxis(material){
    const m = material || {};
    return normalizeAxis(
      m.imageGrainAxis ?? m.swatchGrainAxis ?? m.textureGrainAxis ?? m.materialImageGrainAxis ?? 'V'
    );
  }

  function rotationForAxes(panelAxis, imageAxis){
    return normalizeAxis(panelAxis) === normalizeAxis(imageAxis) ? 0 : 90;
  }

  function coverGeometry(panelWidth, panelHeight, imageWidth, imageHeight, rotationDeg){
    const pw = Math.max(0, finite(panelWidth));
    const ph = Math.max(0, finite(panelHeight));
    const iw = Math.max(0, finite(imageWidth));
    const ih = Math.max(0, finite(imageHeight));
    const rot = ((Math.round(finite(rotationDeg)) % 360) + 360) % 360;
    if(!(pw > 0 && ph > 0 && iw > 0 && ih > 0)) return null;

    const quarterTurn = rot === 90 || rot === 270;
    const effectiveW = quarterTurn ? ih : iw;
    const effectiveH = quarterTurn ? iw : ih;
    const scale = Math.max(pw / effectiveW, ph / effectiveH);
    const sourceDrawWidth = iw * scale;
    const sourceDrawHeight = ih * scale;
    const renderedWidth = effectiveW * scale;
    const renderedHeight = effectiveH * scale;
    return {
      rotationDeg: rot,
      scale,
      sourceDrawWidth,
      sourceDrawHeight,
      renderedWidth,
      renderedHeight,
      left: (pw - renderedWidth) / 2,
      top: (ph - renderedHeight) / 2,
      centerX: pw / 2,
      centerY: ph / 2,
    };
  }

  function coverUv(panelWidth, panelHeight, imageWidth, imageHeight){
    const pw = Math.max(0, finite(panelWidth));
    const ph = Math.max(0, finite(panelHeight));
    const iw = Math.max(0, finite(imageWidth));
    const ih = Math.max(0, finite(imageHeight));
    if(!(pw > 0 && ph > 0 && iw > 0 && ih > 0)) return null;
    const panelRatio = pw / ph;
    const imageRatio = iw / ih;
    let uSpan = 1;
    let vSpan = 1;
    if(panelRatio <= imageRatio){
      uSpan = panelRatio / imageRatio;
    }else{
      vSpan = imageRatio / panelRatio;
    }
    return {
      panelRatio,
      imageRatio,
      uSpan,
      vSpan,
      uOffset: (1 - uSpan) / 2,
      vOffset: (1 - vSpan) / 2,
    };
  }

  function materialByKey(materialKey, state, catalog){
    const key = toKey(materialKey);
    const st = state || root.state || {};
    const batches = Array.isArray(st.materialBatches) ? st.materialBatches : [];
    if(key){
      const batch = batches.find(b => toKey(b && b.key) === key);
      if(batch && batch.mat) return batch.mat;
      if(toKey(st.activeMaterialKey) === key && st.material) return st.material;
    }
    if(!key && st.material) return st.material;
    const rows = Array.isArray(catalog) ? catalog : (Array.isArray(root.MATERIAL_CATALOG) ? root.MATERIAL_CATALOG : []);
    if(key){
      const found = rows.find(m => [m?.publicMaterialId,m?.articleNumber,m?.articleNo,m?.materialCode,m?.id].some(v => toKey(v) === key));
      if(found) return found;
    }
    return null;
  }

  function materialImageUrl(material){
    const m = material || {};
    return toKey(m.imagePreviewUrl || m.imageThumbUrl || '');
  }

  function materialFamily(material){
    return toKey(material?.primaryVisualFamily || material?.visualFamily || material?.decorType || 'Onbekend');
  }

  function fallbackColors(material){
    const f = materialFamily(material).toLowerCase();
    if(f === 'uni') return ['#e8e8e4','#d8d8d2'];
    if(f.includes('steen') || f.includes('beton')) return ['#dedfdd','#bfc2c0'];
    if(f.includes('metaal')) return ['#d7dbdd','#a9b0b4'];
    if(f.includes('textiel') || f.includes('leer')) return ['#e1d9d1','#c8bbb0'];
    if(f.includes('grafisch')) return ['#e5e2dc','#c8c4bd'];
    if(f.includes('fantasie')) return ['#e6e1db','#cec5bb'];
    if(f.includes('hout')) return ['#d7c2a4','#b99a77'];
    return ['#ececea','#d8d9d6'];
  }

  function loadImage(url, onReady){
    const src = toKey(url);
    if(!src || typeof root.Image !== 'function') return { status:'unavailable', image:null };
    let entry = cache.get(src);
    if(!entry){
      const img = new root.Image();
      try{ img.decoding = 'async'; }catch(_){ }
      entry = { status:'loading', image:img, listeners:new Set(), error:null };
      cache.set(src, entry);
      img.onload = function(){
        entry.status = 'ready';
        const listeners = Array.from(entry.listeners);
        entry.listeners.clear();
        listeners.forEach(fn => { try{ fn(); }catch(_){ } });
      };
      img.onerror = function(err){
        entry.status = 'error';
        entry.error = err || new Error('image load failed');
        const listeners = Array.from(entry.listeners);
        entry.listeners.clear();
        listeners.forEach(fn => { try{ fn(); }catch(_){ } });
      };
      img.src = src;
    }
    if(typeof onReady === 'function' && entry.status === 'loading') entry.listeners.add(onReady);
    return entry;
  }

  function drawFallback(ctx, rect, material){
    if(!ctx || !rect) return;
    const x = finite(rect.x), y = finite(rect.y), w = finite(rect.w), h = finite(rect.h);
    if(!(w > 0 && h > 0)) return;
    const colors = fallbackColors(material);
    const g = ctx.createLinearGradient(x, y, x + w, y + h);
    g.addColorStop(0, colors[0]);
    g.addColorStop(1, colors[1]);
    ctx.fillStyle = g;
    ctx.fillRect(x,y,w,h);
  }

  function applySurfaceShading(ctx, rect){
    if(!ctx || !rect) return;
    const x = finite(rect.x), y = finite(rect.y), w = finite(rect.w), h = finite(rect.h);
    if(!(w > 0 && h > 0)) return;
    try{
      const hi = ctx.createLinearGradient(x,y,x,y+h);
      hi.addColorStop(0,'rgba(255,255,255,.16)');
      hi.addColorStop(.22,'rgba(255,255,255,.035)');
      hi.addColorStop(1,'rgba(0,0,0,.11)');
      ctx.fillStyle = hi;
      ctx.fillRect(x,y,w,h);
    }catch(_){ }
  }

  function rectClip(ctx, rect, radius){
    const x = finite(rect.x), y = finite(rect.y), w = finite(rect.w), h = finite(rect.h);
    const r = Math.max(0, Math.min(finite(radius), w/2, h/2));
    ctx.beginPath();
    if(r > 0 && typeof ctx.roundRect === 'function'){
      ctx.roundRect(x,y,w,h,r);
    }else if(r > 0){
      ctx.moveTo(x+r,y);
      ctx.arcTo(x+w,y,x+w,y+h,r);
      ctx.arcTo(x+w,y+h,x,y+h,r);
      ctx.arcTo(x,y+h,x,y,r);
      ctx.arcTo(x,y,x+w,y,r);
      ctx.closePath();
    }else{
      ctx.rect(x,y,w,h);
    }
    ctx.clip();
  }

  function drawCanvasMaterial(ctx, rect, opts){
    const o = opts || {};
    if(!ctx || !rect) return { drawn:false, reason:'invalid' };
    let x = finite(rect.x), y = finite(rect.y), w = finite(rect.w), h = finite(rect.h);
    if(w < 0){ x += w; w = Math.abs(w); }
    if(h < 0){ y += h; h = Math.abs(h); }
    if(!(w > 0 && h > 0)) return { drawn:false, reason:'empty' };
    const safeRect = {x,y,w,h};
    const material = o.material || materialByKey(o.materialKey, o.state, o.catalog);
    const url = materialImageUrl(material);
    const pAxis = normalizeAxis(o.panelGrainAxis || panelGrainAxis(o.panel));
    const iAxis = normalizeAxis(o.imageGrainAxis || imageGrainAxis(material));
    const rotationDeg = rotationForAxes(pAxis, iAxis);

    ctx.save();
    try{
      if(typeof o.clip === 'function'){
        ctx.beginPath();
        o.clip(ctx, safeRect);
        ctx.clip();
      }else{
        rectClip(ctx, safeRect, finite(o.radius));
      }

      const entry = loadImage(url, o.onReady);
      if(entry.status === 'ready' && entry.image && entry.image.naturalWidth > 0 && entry.image.naturalHeight > 0){
        const geo = coverGeometry(w,h,entry.image.naturalWidth,entry.image.naturalHeight,rotationDeg);
        if(geo){
          ctx.translate(x + w/2, y + h/2);
          if(rotationDeg) ctx.rotate(rotationDeg * Math.PI / 180);
          ctx.drawImage(entry.image, -geo.sourceDrawWidth/2, -geo.sourceDrawHeight/2, geo.sourceDrawWidth, geo.sourceDrawHeight);
          if(rotationDeg) ctx.rotate(-rotationDeg * Math.PI / 180);
          ctx.translate(-(x + w/2), -(y + h/2));
          applySurfaceShading(ctx, safeRect);
          return { drawn:true, material, url, rotationDeg, status:'ready' };
        }
      }
      drawFallback(ctx, safeRect, material);
      applySurfaceShading(ctx, safeRect);
      return { drawn:false, material, url, rotationDeg, status: entry.status || 'fallback' };
    }finally{
      ctx.restore();
    }
  }

  function computeDomImageLayout(element, img, rotationDeg){
    if(!element || !img) return null;
    const w = Math.max(1, finite(element.clientWidth || element.getBoundingClientRect?.().width, 1));
    const h = Math.max(1, finite(element.clientHeight || element.getBoundingClientRect?.().height, 1));
    const iw = Math.max(1, finite(img.naturalWidth, 1));
    const ih = Math.max(1, finite(img.naturalHeight, 1));
    return coverGeometry(w,h,iw,ih,rotationDeg);
  }

  function updateDomImageLayout(element, img, rotationDeg){
    const geo = computeDomImageLayout(element, img, rotationDeg);
    if(!geo) return;
    img.style.width = `${geo.sourceDrawWidth}px`;
    img.style.height = `${geo.sourceDrawHeight}px`;
    img.style.left = '50%';
    img.style.top = '50%';
    img.style.transformOrigin = '50% 50%';
    img.style.transform = `translate(-50%,-50%) rotate(${rotationDeg}deg)`;
  }

  function applyDomSwatch(element, opts){
    if(!element || !root.document) return null;
    const o = opts || {};
    const material = o.material || materialByKey(o.materialKey, o.state, o.catalog);
    const url = materialImageUrl(material);
    const pAxis = normalizeAxis(o.panelGrainAxis || panelGrainAxis(o.panel));
    const iAxis = normalizeAxis(o.imageGrainAxis || imageGrainAxis(material));
    const rotationDeg = rotationForAxes(pAxis, iAxis);

    const previous = domBindings.get(element);
    if(previous && previous.cleanup){ try{ previous.cleanup(); }catch(_){ } }
    element.classList.add('fix659MaterialSurface');

    const layer = root.document.createElement('div');
    layer.className = 'fix659MaterialSwatchLayer';
    const fallback = root.document.createElement('div');
    fallback.className = 'fix659MaterialFallback';
    const colors = fallbackColors(material);
    fallback.style.background = `linear-gradient(135deg, ${colors[0]}, ${colors[1]})`;
    layer.appendChild(fallback);

    let img = null;
    let ro = null;
    if(url){
      img = root.document.createElement('img');
      img.className = 'fix659MaterialSwatchImage';
      img.alt = '';
      img.decoding = 'async';
      img.draggable = false;
      img.onload = function(){
        fallback.style.opacity = '0';
        updateDomImageLayout(element, img, rotationDeg);
        // The shell can still be detached while drawGrainPreview constructs the DOM.
        // Re-measure once after insertion/paint as a fallback even without ResizeObserver.
        try{ if(typeof root.requestAnimationFrame === 'function') root.requestAnimationFrame(()=>updateDomImageLayout(element, img, rotationDeg)); }catch(_){ }
      };
      img.onerror = function(){
        try{ img.remove(); }catch(_){ }
        fallback.style.opacity = '1';
      };
      layer.appendChild(img);
      img.src = url;
      if(typeof root.ResizeObserver === 'function'){
        ro = new root.ResizeObserver(function(){ if(img && img.complete && img.naturalWidth > 0) updateDomImageLayout(element,img,rotationDeg); });
        try{ ro.observe(element); }catch(_){ }
      }
    }

    element.insertBefore(layer, element.firstChild || null);
    try{
      if(img && img.complete && img.naturalWidth > 0 && typeof root.requestAnimationFrame === 'function')
        root.requestAnimationFrame(()=>updateDomImageLayout(element, img, rotationDeg));
    }catch(_){ }
    const cleanup = function(){
      if(ro){ try{ ro.disconnect(); }catch(_){ } }
      try{ layer.remove(); }catch(_){ }
    };
    domBindings.set(element, { cleanup, material, url, rotationDeg });
    return { cleanup, material, url, rotationDeg };
  }

  function preloadMaterial(materialKey, state, onReady){
    const material = materialByKey(materialKey, state);
    return loadImage(materialImageUrl(material), onReady);
  }

  root.ToolAMaterialSwatchRenderer = Object.freeze({
    BUILD,
    normalizeAxis,
    panelGrainAxis,
    imageGrainAxis,
    rotationForAxes,
    coverGeometry,
    coverUv,
    materialByKey,
    materialImageUrl,
    drawCanvasMaterial,
    applyDomSwatch,
    preloadMaterial,
    _cache: cache,
  });
})(typeof window !== 'undefined' ? window : globalThis);
