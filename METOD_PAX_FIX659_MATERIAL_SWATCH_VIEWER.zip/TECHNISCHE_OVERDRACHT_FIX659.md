# Technische overdracht — FIX659_MATERIAL_SWATCH_VIEWER

## 1. Golden parent
Parent: **FIX658R2_SUBMIT_CLARITY**.
FIX659 is intentionally viewer-only. Do not use FIX656/FIX657/FIX658 as a future implementation baseline.

## 2. Public infrastructure contract
Unchanged:
- Tool A `http://51.195.102.180:8790/`
- Admin `http://51.195.102.180:8790/admin/`
- Nginx `:8790`
- Python loopback `127.0.0.1:8792`
- production hardening and exact legacy HTTP origin bridge remain active.

## 3. New renderer architecture
New file: `app/toolA_material_swatch_renderer.js`.

Public API:
- `coverGeometry(panelW,panelH,imageW,imageH,rotationDeg)`
- `coverUv(panelW,panelH,imageW,imageH)`
- `panelGrainAxis(panel)`
- `imageGrainAxis(material)`
- `rotationForAxes(panelAxis,imageAxis)`
- `materialByKey(materialKey,state,catalog)`
- `drawCanvasMaterial(ctx,rect,opts)`
- `applyDomSwatch(element,opts)`
- `preloadMaterial(materialKey,state,onReady)`

The module has no pricing, optimizer, API mutation or deployment knowledge.

## 4. Exact cover contract
For non-rotated source images:

```
panelRatio = panelWidth / panelHeight
imageRatio = imageWidth / imageHeight
if panelRatio <= imageRatio:
    uSpan = panelRatio / imageRatio
    vSpan = 1
else:
    uSpan = 1
    vSpan = imageRatio / panelRatio
uOffset = (1-uSpan)/2
vOffset = (1-vSpan)/2
```

Canvas equivalent:

```
scale = max(panelWidth/effectiveImageWidth, panelHeight/effectiveImageHeight)
```

The source image is drawn once, centered, clipped, with unchanged aspect ratio.

## 5. Grain orientation contract
Authoritative input is local panel grain metadata only:
- `localGrainAxis`
- `grainAxis`
- `localGrainDirection`
- `grainDirection`
- `grain`

Recognized U aliases: horizontal/x/width/breedte/dwars.
Recognized V aliases: vertical/y/height/hoogte/length/lengte/langs.
Current Tool A panels default to local V, matching the existing “hoogte = nerfrichting/lengterichting” contract.

Material swatch axis can later be supplied as `imageGrainAxis`, `swatchGrainAxis`, `textureGrainAxis` or `materialImageGrainAxis`; absent metadata defaults to image V.

If panel axis != image axis, image rotates exactly 90 degrees. World rotation and longest-side inference are forbidden.

## 6. Viewer integration
### Normal panel viewer
`draw()` resolves the current active material and calls `drawCanvasMaterial`. The renderer redraw callback is the existing `draw` function.

### Overige panelen viewer
`drawExtraPreview()` resolves the selected `extraMat` material key and uses the same Canvas renderer. The old synthetic repeated grain-line pattern is removed; the explicit local grain arrow remains above the material.

### Doorlopende nerf viewer
`drawGrainPreview()` calls `applyDomSwatch()` per `.grainPanelShell`, using the panel/material key already stored in the grain entry. The DOM renderer uses one `<img>` per panel, center-cover, and `ResizeObserver` + requestAnimationFrame remeasurement.

Because the source is only a visual swatch, FIX659 deliberately does not project one pseudo-mm-scaled image across an entire multi-panel grain group. That would imply physical continuity the source data cannot prove.

## 7. Loading/cache behavior
- Primary URL: `imagePreviewUrl`.
- Fallback URL: `imageThumbUrl`.
- Main Canvas image loads are deduplicated through a URL-keyed cache.
- Active material is preloaded when changed.
- DOM `<img>` elements also benefit from the browser HTTP cache.
- Image URL version query from the material API naturally invalidates stale cache entries.
- Image failure never blocks configuration or submit.

## 8. Layer order
Material surface is the bottom visual layer. Existing UX/technical overlays remain above it:
- growth zones;
- outline;
- CNC holes/arcs;
- dimensions;
- edge banding;
- grain arrows and labels.

## 9. Protected baseline proof
The following files are byte-identical to FIX658R2:
- `app/dxf_nesting_optimizer.py`
- `app/pricing_helpers.py`
- `app/catalog_importer.py`
- `app/catalog_taxonomy.py`
- `app/server_helpers.py`
- `app/material_library.json`
- `app/config/pricing_active.json`
- `app/toolA_panel_submit_flow.js`
- `app/toolA_panel_submit_apply.js`
- `app/toolA_extra_panel_submit_flow.js`
- `app/toolA_extra_panel_submit_apply.js`

`server_py.py`: build stamp + static allowlist only (plus comment wording).
`decor_library.js`: build stamp only.
`toolA.html`: viewer integration/CSS/build/cache-bust only.
`final_preflight.py`: FIX659 marker/new-module viewer checks.

## 10. Regression gates
`tools/fix659_regression.py` retains all FIX658 taxonomy, Admin override, mixed-VAT, token, SSE, queue and submit tests and adds:
- exact cover UV math;
- exact Canvas cover geometry for tall/wide panels;
- one drawImage call per panel render;
- explicit U/V -> 90-degree rotation;
- no repeat/createPattern path;
- no world/longest-side orientation path;
- normal viewer integration;
- extra-panel viewer integration;
- grain viewer integration;
- active-material immediate redraw;
- public static allowlist;
- deployment scope protection;
- no `curl | grep -q` installer regression.

## 11. Future physical texture scaling
Do not add physical scaling to these swatches. A future physically accurate texture mode needs manufacturer/full-sheet imagery plus known physical image width/height in millimetres and a separate explicit mapping contract.
