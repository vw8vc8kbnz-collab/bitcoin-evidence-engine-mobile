# METOD/PAX Tool A — FIX659_MATERIAL_SWATCH_VIEWER

## Baseline
FIX659 is a surgical viewer-only release on top of the confirmed FIX658R2 baseline.
The live/public contract remains unchanged:

- Tool A: `http://51.195.102.180:8790/`
- Admin: `http://51.195.102.180:8790/admin/`
- Nginx public listener: `:8790`
- Python backend: `127.0.0.1:8792`

## What changes
The default synthetic wood surface in the customer viewers is replaced by the actual selected material image from the published material library.

Covered viewers:
1. normal panel/door/drawer preview;
2. Doorlopende nerf preview;
3. Overige panelen preview.

Rendering contract:
- one source swatch image per panel;
- aspect ratio is always preserved;
- center-cover crop;
- clip to panel surface;
- never repeat/tile;
- local panel grain axis is authoritative;
- image orientation never follows world rotation or the longest side;
- failed/missing image falls back to a neutral category-aware surface, not a fake wood grain;
- CNC/holes/dimensions/arrows remain drawn above the material surface.

Important: the library images are visual swatches, not millimetre-calibrated full-sheet textures. The Doorlopende nerf preview therefore does NOT invent physical texture continuity across multiple panels. Each panel shows one center-covered swatch while group order and grain arrows communicate the production intent.

## Scope protection
The following FIX658R2 files are byte-identical to the baseline:
- `app/dxf_nesting_optimizer.py`
- `app/pricing_helpers.py`
- `app/catalog_importer.py`
- `app/catalog_taxonomy.py`
- `app/server_helpers.py`
- `app/material_library.json`
- `app/config/pricing_active.json`
- panel/extra-panel submit flow/apply modules

`server_py.py` changes only the FIX659 build marker, public static allowlist for the new viewer module, and a comment label. No server pricing/job/business logic is changed.

## New module
`app/toolA_material_swatch_renderer.js`

This is the single shared renderer for cover math, image caching, material lookup, local grain-axis mapping, Canvas rendering and DOM swatch rendering.

## Safety
The release keeps all previous production guards, state-preserving backup/rollback, root-only Admin credentials, header-only bearer tokens, mixed-VAT v2 pricing, CSV-only library, idempotent finalized submit flow, SSE privacy and the pinned HTTP :8790 bridge.

Run `tools/fix659_regression.py` before deploy. The installer does this automatically before the live switch.
