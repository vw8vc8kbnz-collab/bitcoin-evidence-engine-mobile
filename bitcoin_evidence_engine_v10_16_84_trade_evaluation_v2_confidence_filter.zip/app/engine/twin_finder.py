from __future__ import annotations
import json
import numpy as np
from app.db.database import db
from app.engine.state_vector import FEATURE_KEYS
from app.core.time_utils import HORIZON_SECONDS

# v10.16.82: proven/important features get more weight in twin distance.
# This is not learned on the test sample; it is a transparent prior from the audits.
FEATURE_DISTANCE_WEIGHTS = {
    "fear_greed": 1.45,
    "volatility_24": 1.30,
    "return_24": 1.25,
    "rsi_14": 1.15,
    "drawdown_from_ath": 1.10,
    "funding_rate": 1.18,
    "spot_premium_coinbase_pct": 1.35,
    "regime": 1.20,
    "volume_zscore": 0.70,
    "volume_ratio_24": 0.75,
}

class HistoricalTwinFinder:
    def find(self, horizon: str, top_n: int = 120) -> dict:
        return self.find_at(horizon=horizon, cutoff_ms=None, top_n=top_n)

    def find_at(self, horizon: str, cutoff_ms: int | None = None, top_n: int = 120) -> dict:
        # v10.16.82 Claude audit fix: use full prior history, not LIMIT 5000 (~208 days).
        where_cutoff = "" if cutoff_ms is None else "AND timestamp_ms <= ?"
        params = [] if cutoff_ms is None else [int(cutoff_ms)]
        df = db.df(f"""
            SELECT timestamp_ms, close, high, low, state_json
            FROM features
            WHERE interval='1h' AND rsi_14 IS NOT NULL AND ma_50 IS NOT NULL {where_cutoff}
            ORDER BY timestamp_ms ASC
        """, params)
        if df is None or len(df) < 250:
            return {"matches": [], "evidence_count": 0, "bullish_probability": 0.5, "expected_move_pct": 0.0, "method": "full_history_weighted_twin_insufficient"}
        df = df.reset_index(drop=True)
        current = df.iloc[-1]
        cur_vec = self._vec(current.state_json)
        steps = int(HORIZON_SECONDS[horizon] / 3600)
        if len(df) <= steps + 250:
            return {"matches": [], "evidence_count": 0, "bullish_probability": 0.5, "expected_move_pct": 0.0, "method": "full_history_weighted_twin_insufficient_horizon"}
        hist = df.iloc[:-max(1, steps)].copy()
        if hist.empty:
            return {"matches": [], "evidence_count": 0, "bullish_probability": 0.5, "expected_move_pct": 0.0, "method": "full_history_weighted_twin_empty"}
        vectors = np.vstack([self._vec(s) for s in hist.state_json])
        med = np.nanmedian(vectors, axis=0)
        std = np.nanstd(vectors, axis=0)
        std[std == 0] = 1
        weights = self._weights(len(cur_vec))
        scaled = ((vectors - cur_vec) / std) * weights
        dist = np.linalg.norm(scaled, axis=1)
        hist["distance"] = dist
        hist = hist.sort_values("distance").head(max(top_n, 180))
        closes = list(df.close.astype(float))
        highs = list(df.high.astype(float)) if "high" in df else closes
        lows = list(df.low.astype(float)) if "low" in df else closes
        pos = {int(ts): i for i, ts in enumerate(df.timestamp_ms)}
        moves=[]; fav=[]; adv=[]; dists=[]; matches=[]
        for _, r in hist.iterrows():
            i = pos.get(int(r.timestamp_ms))
            if i is None or i + steps >= len(closes):
                continue
            start = float(r.close)
            if start <= 0:
                continue
            move = (float(closes[i+steps]) / start - 1) * 100
            # MFE/MAE style close-to-high/low windows for conditional target/stop hints.
            wh = max(highs[i+1:i+steps+1]) if i + steps > i else closes[i]
            wl = min(lows[i+1:i+steps+1]) if i + steps > i else closes[i]
            up_exc = (wh / start - 1) * 100
            dn_exc = (wl / start - 1) * 100
            moves.append(move)
            fav.append(max(abs(up_exc), abs(dn_exc)))
            adv.append(abs(dn_exc if move >= 0 else up_exc))
            dists.append(float(r.distance))
            matches.append({"timestamp_ms": int(r.timestamp_ms), "close": float(r.close), "future_move_pct": move, "distance": float(r.distance)})
        if not moves:
            return {"matches": [], "evidence_count": 0, "bullish_probability": 0.5, "expected_move_pct": 0.0, "method": "full_history_weighted_twin_no_moves"}
        arr=np.array(moves, dtype=float)
        d=np.array(dists, dtype=float)
        w=1.0/(1.0+d)
        w=w/np.maximum(w.sum(),1e-12)
        weighted_prob=float(w[arr>0].sum())
        weighted_mean=float((arr*w).sum())
        # Weighted median by distance.
        order=np.argsort(arr)
        arr_s=arr[order]; w_s=w[order]
        cdf=np.cumsum(w_s)
        weighted_median=float(arr_s[np.searchsorted(cdf,0.5)])
        abs_arr=np.abs(arr)
        return {
            "matches": matches[:50],
            "evidence_count": len(moves),
            "bullish_probability": weighted_prob,
            "expected_move_pct": weighted_median,
            "avg_move_pct": weighted_mean,
            "worst_move_pct": float(np.min(arr)),
            "best_move_pct": float(np.max(arr)),
            "abs_move_p50": float(np.percentile(abs_arr, 50)),
            "abs_move_p75": float(np.percentile(abs_arr, 75)),
            "adverse_move_p35": float(np.percentile(np.array(adv, dtype=float), 35)),
            "method": "full_history_weighted_distance_twins_v10_16_82",
            "history_rows_scanned": int(len(df)),
        }

    def _weights(self, n: int) -> np.ndarray:
        vals=[]
        for k in FEATURE_KEYS[:n]:
            vals.append(float(FEATURE_DISTANCE_WEIGHTS.get(k, 1.0)))
        if len(vals) < n:
            vals.extend([1.0]*(n-len(vals)))
        return np.array(vals, dtype=float)

    def _vec(self, state_json: str) -> np.ndarray:
        try:
            s=json.loads(state_json) if isinstance(state_json, str) else (state_json or {})
        except Exception:
            s={}
        out=[]
        for k in FEATURE_KEYS:
            v=s.get(k)
            if isinstance(v, str):
                # Stable hash bucket for string state fields such as regime.
                v=(sum(ord(ch) for ch in v.lower()[:32]) % 1000)/1000.0
            try:
                x=0.0 if v is None else float(v)
                if not np.isfinite(x): x=0.0
            except Exception:
                x=0.0
            out.append(x)
        return np.array(out, dtype=float)
