from __future__ import annotations

import math
from typing import Any

from app.core.config import settings
from app.db.database import db
from app.services.trade_evaluation_v2 import evaluate_historical_setup_v2

HORIZON_HOURS = {'1h':1, '4h':4, '8h':8, '24h':24, '7d':24*7, '30d':24*30, '90d':24*90}
HORIZON_SECONDS = {k: int(v * 3600) for k, v in HORIZON_HOURS.items()}
VERSION = 'v10.16.84_trade_evaluation_v2_confidence_filter'


def _finite(v: Any, default: float = 0.0) -> float:
    try:
        x = float(v)
        if math.isfinite(x):
            return x
    except Exception:
        pass
    return default


def _clamp(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, x))


def _sigmoid(x: float) -> float:
    try:
        return 1.0 / (1.0 + math.exp(-x))
    except Exception:
        return 0.5


class TradeSetupSelector:
    """Unified Time Machine + Forecast trade setup selector.

    v10.16.82 is built from the multi-AI audit (own audit + DeepSeek + Gemini + Claude):
    - no dependency on sparse premium features as historical core;
    - Regime Master Switch before any trade decision;
    - regime specialist logic for bull/bear/capitulation/transition;
    - Triple Gate selection: Direction Edge, Magnitude Edge, Trade Quality Edge;
    - extreme-crash reversal cluster and Fear&Greed U-shape as testable features;
    - transition/chop gets much more NO_TRADE;
    - forecast and Time Machine share this exact class.
    """

    MIN_RR = 1.18
    BASE_RR = 1.50

    def __init__(self):
        self._range_cache: dict[str, dict[str, float]] = {}

    def _recent_range_stats(self, horizon: str) -> dict[str, float]:
        horizon = str(horizon)
        if horizon in self._range_cache:
            return self._range_cache[horizon]
        h = max(1, int(HORIZON_HOURS.get(horizon, 24)))
        try:
            frame = db.df("""
                WITH c AS (
                    SELECT row_number() OVER (ORDER BY open_time) rn, open_time, close, high, low
                    FROM raw_candles
                    WHERE source='binance' AND symbol=? AND interval='1h'
                    ORDER BY open_time DESC LIMIT 25000
                ), ordered AS (
                    SELECT * FROM c ORDER BY rn
                )
                SELECT a.close AS entry_price,
                       b.close AS exit_price,
                       (SELECT MAX(x.high) FROM ordered x WHERE x.rn>a.rn AND x.rn<=a.rn+?) AS max_high,
                       (SELECT MIN(x.low) FROM ordered x WHERE x.rn>a.rn AND x.rn<=a.rn+?) AS min_low
                FROM ordered a
                JOIN ordered b ON b.rn=a.rn+?
                WHERE a.close IS NOT NULL AND a.close>0 AND b.close IS NOT NULL
                LIMIT 16000
            """, [settings.symbol, h, h, h])
            if frame.empty:
                raise RuntimeError('empty range stats')
            import pandas as pd
            entry = frame['entry_price'].astype(float).clip(lower=1e-9)
            up = ((frame['max_high'].astype(float) - entry) / entry * 100.0).clip(lower=0)
            down = ((entry - frame['min_low'].astype(float)) / entry * 100.0).clip(lower=0)
            abs_close = ((frame['exit_price'].astype(float) - entry) / entry * 100.0).abs()
            favorable = pd.concat([up, down], axis=0).dropna()
            out = {
                'median_range_pct': float(favorable.quantile(0.50)),
                'p65_range_pct': float(favorable.quantile(0.65)),
                'p75_range_pct': float(favorable.quantile(0.75)),
                'p85_range_pct': float(favorable.quantile(0.85)),
                'p92_range_pct': float(favorable.quantile(0.92)),
                'median_close_move_pct': float(abs_close.dropna().quantile(0.50)),
                'p75_close_move_pct': float(abs_close.dropna().quantile(0.75)),
                'samples': int(len(frame)),
            }
        except Exception as exc:
            base = {'1h':0.55,'4h':1.05,'8h':1.55,'24h':2.6,'7d':6.5,'30d':14.0,'90d':27.0}.get(horizon,2.0)
            out = {'median_range_pct':base*0.65,'p65_range_pct':base*0.85,'p75_range_pct':base,'p85_range_pct':base*1.25,'p92_range_pct':base*1.55,'median_close_move_pct':base*0.45,'p75_close_move_pct':base*0.75,'samples':0,'fallback_error':str(exc)[:180]}
        self._range_cache[horizon] = out
        return out

    def _feature_snapshot(self, item: dict) -> dict:
        f = dict(item.get('feature_snapshot') or {})
        return f

    def _ctx(self, item: dict) -> dict:
        f = self._feature_snapshot(item)
        # premium fields are intentionally included as optional modifiers only;
        # the Claude audit showed they are too sparse for historical core learning.
        return {
            'regime_raw': str(f.get('regime') or f.get('regime_code') or item.get('regime') or 'unknown'),
            'fear_greed': _finite(f.get('fear_greed'), 50.0),
            'rsi_14': _finite(f.get('rsi_14') or f.get('rsi'), 50.0),
            'return_1': _finite(f.get('return_1') or f.get('candle_body_pct'), 0.0),
            'return_4': _finite(f.get('return_4'), 0.0),
            'return_24': _finite(f.get('return_24') or f.get('trend'), 0.0),
            'candle_body_pct': _finite(f.get('candle_body_pct') or f.get('return_1'), 0.0),
            'range_pct': _finite(f.get('range_pct'), 0.0),
            'volatility_24': _finite(f.get('volatility_24') or f.get('volatility'), 0.0),
            'volume_zscore': _finite(f.get('volume_zscore'), 0.0),
            'volume_ratio_24': _finite(f.get('volume_ratio_24'), 1.0),
            'drawdown_from_ath': _finite(f.get('drawdown_from_ath'), 0.0),
            'cycle_progress': _finite(f.get('cycle_progress'), 0.0),
            'funding_rate': _finite(f.get('funding_rate'), 0.0),
            'data_completeness': _finite(f.get('data_completeness'), 0.0),
        }

    def _master_regime(self, ctx: dict) -> str:
        raw = str(ctx.get('regime_raw') or '').lower()
        fg = ctx['fear_greed']; rsi = ctx['rsi_14']; r24 = ctx['return_24']; dd = ctx['drawdown_from_ath']
        if 'capitulation' in raw or 'panic' in raw or 'crash' in raw:
            return 'capitulation'
        if 'bull' in raw or 'euphoria' in raw:
            return 'bull_trend'
        if 'bear' in raw:
            return 'bear_trend'
        if 'post_halving' in raw or 'accumulation' in raw:
            return 'post_halving_accumulation'
        # Transparent fallback for live rows whose stored label is missing/weak.
        if r24 <= -5.0 or (fg <= 20 and rsi <= 28):
            return 'capitulation'
        if r24 > 1.0 and rsi >= 55 and fg >= 55:
            return 'bull_trend'
        if r24 < -1.0 and rsi <= 45 and fg <= 45:
            return 'bear_trend'
        if dd <= -55 and fg <= 35:
            return 'capitulation'
        return 'transition'

    def _regime_bucket(self, ctx: dict, horizon: str, master: str) -> str:
        vol = abs(ctx['volatility_24']); rng = abs(ctx['range_pct']); trend = ctx['return_24']
        h = max(1, int(HORIZON_HOURS.get(str(horizon), 24)))
        vol_score = max(vol, rng)
        if master == 'capitulation':
            return 'capitulation_reversal'
        if master == 'bull_trend':
            return 'bull_momentum'
        if master == 'bear_trend':
            return 'bear_defensive'
        if master == 'post_halving_accumulation':
            return 'post_halving_accumulation'
        if vol_score >= (1.25 if h <= 4 else 2.2 if h <= 24 else 5.0):
            return 'transition_high_vol'
        if vol_score <= (0.25 if h <= 4 else 0.70 if h <= 24 else 1.8):
            return 'transition_low_vol'
        if abs(trend) >= (0.45 if h <= 4 else 1.0 if h <= 24 else 3.0):
            return 'transition_breakout_watch'
        return 'transition_chop'

    def _regime_specialist_bias(self, ctx: dict, horizon: str, candidate_side: str) -> tuple[float, str, dict]:
        """Return signed directional bias: positive favors LONG, negative favors SHORT."""
        h = str(horizon)
        master = self._master_regime(ctx)
        bucket = self._regime_bucket(ctx, h, master)
        fg = ctx['fear_greed']; rsi = ctx['rsi_14']; r1 = ctx['return_1']; r4 = ctx['return_4']; r24 = ctx['return_24']
        body = ctx['candle_body_pct']; volz = ctx['volume_zscore']; rng = ctx['range_pct']; vol = ctx['volatility_24']
        score = 0.0; tags=[]

        # Claude: strongest robust micro edge is asymmetric reversal after big red candles / crashes.
        extreme_red = (r24 <= -9.2) or (body <= -2.5) or (r1 <= -2.5)
        big_red = (body <= -1.3) or (r1 <= -1.3) or (r24 <= -5.0)
        extreme_green = (r24 >= 9.5) or (body >= 2.5) or (r1 >= 2.5)
        volume_absorption = big_red and (volz >= 1.5 or ctx['volume_ratio_24'] >= 1.8)

        if master == 'capitulation':
            score += 18.0
            tags.append('capitulation_long_reversal_bias')
            if extreme_red: score += 14.0; tags.append('top1pct_crash_reversal_cluster')
            if volume_absorption: score += 9.0; tags.append('volume_absorption_after_drop')
            if rsi <= 25: score += 7.0; tags.append('oversold_panic')
            if h == '1h': score -= 3.0  # immediate hour can still be noisy; 4h/24h cleaner.
        elif master == 'bull_trend':
            score += 10.0
            tags.append('bull_momentum_bias')
            if r24 > 0 and rsi >= 55: score += 8.0; tags.append('bull_momentum_confirmed')
            if r1 < 0 and rsi >= 45: score += 4.0; tags.append('bull_dip_buy_context')
            if extreme_green and h in ('1h','4h'): score -= 5.0; tags.append('short_term_post_pump_cooldown')
        elif master == 'bear_trend':
            score -= 10.0
            tags.append('bear_defensive_short_bias')
            if r24 < 0 and 45 <= rsi <= 62: score -= 8.0; tags.append('bear_flag_rejection_zone')
            if big_red and (rsi <= 25 or volume_absorption): score += 11.0; tags.append('bear_panic_rebound_override')
        elif master == 'post_halving_accumulation':
            score += 7.0
            tags.append('post_halving_accumulation_positive_bias')
            if fg >= 55 and r24 >= -1.0: score += 4.0
        else:
            tags.append('transition_requires_extra_edge')
            if abs(r24) < 0.6 and max(rng, vol) < 0.75:
                score += 0.0; tags.append('low_vol_chop_no_direction')
            elif r24 > 1.2 and rsi > 55:
                score += 7.0; tags.append('transition_breakout_up')
            elif r24 < -1.2 and rsi < 45:
                score -= 7.0; tags.append('transition_breakdown_down')

        # Fear & Greed U-shape from Claude: both extreme fear and extreme greed have positive forward skew, neutral/fear 20-40 is weakest.
        if fg <= 20:
            score += 6.0; tags.append('extreme_fear_u_shape_bullish')
        elif fg >= 80:
            score += 5.0; tags.append('extreme_greed_momentum_u_shape')
        elif 20 < fg < 40:
            score -= 3.0; tags.append('weak_fear_middle_zone')

        direction_sign = 1.0 if candidate_side == 'LONG' else -1.0
        aligned = score * direction_sign
        meta = {'master_regime': master, 'regime_bucket': bucket, 'bias_score_signed': round(score,3), 'specialist_tags': tags[:8], 'volume_absorption': volume_absorption, 'extreme_red': extreme_red, 'extreme_green': extreme_green}
        return aligned, bucket, meta

    def _market_potential_pct(self, item: dict, horizon: str, direction: str, ctx: dict, specialist_meta: dict) -> tuple[float, dict]:
        stats = self._recent_range_stats(horizon)
        h = max(1, int(HORIZON_HOURS.get(horizon, 24)))
        expected = abs(_finite(item.get('expected_move_pct'), 0.0))
        conf = _finite(item.get('confidence'), 50.0)
        vol_hint = max(ctx['range_pct'], ctx['volatility_24'] * math.sqrt(min(h,24)/24.0))
        hist_p = stats['p65_range_pct']
        if conf >= 68: hist_p = stats['p75_range_pct']
        if conf >= 78: hist_p = stats['p85_range_pct']
        if specialist_meta.get('extreme_red') or specialist_meta.get('extreme_green'):
            hist_p = max(hist_p, stats.get('p85_range_pct', hist_p))
        if specialist_meta.get('regime_bucket') == 'transition_low_vol':
            hist_p = min(hist_p, stats['p65_range_pct'] * 0.85)
        potential = max(hist_p, expected * 1.25, vol_hint * 1.10)
        if specialist_meta.get('volume_absorption') and direction == 'LONG':
            potential *= 1.12
        if conf < 55: potential *= 0.70
        elif conf < 62: potential *= 0.86
        caps = {'1h':1.8,'4h':3.5,'8h':5.2,'24h':8.5,'7d':20.0,'30d':42.0,'90d':72.0}
        potential = _clamp(potential, 0.03, caps.get(str(horizon), 15.0))
        return potential, {'range_stats': stats, 'context': ctx, 'vol_hint_pct': round(vol_hint,6)}

    def _policy(self, horizon: str, bucket: str, master: str, sample: int) -> dict:
        h = str(horizon)
        # v10.16.82: 1h was massively overtrading in v10.16.80, so the normal gate is materially stricter.
        min_dir = {'1h':69,'4h':65,'8h':64,'24h':65,'7d':66,'30d':67,'90d':68}.get(h,65)
        min_mag = {'1h':60,'4h':58,'8h':58,'24h':59,'7d':61,'30d':63,'90d':65}.get(h,59)
        min_qual = {'1h':67,'4h':64,'8h':64,'24h':65,'7d':66,'30d':68,'90d':70}.get(h,65)
        min_ev = {'1h':0.030,'4h':0.035,'8h':0.045,'24h':0.065,'7d':0.120,'30d':0.220,'90d':0.360}.get(h,0.06)
        min_potential = {'1h':0.35,'4h':0.62,'8h':0.90,'24h':1.35,'7d':2.8,'30d':6.2,'90d':10.0}.get(h,1.0)
        rr_target = {'1h':1.28,'4h':1.38,'8h':1.48,'24h':1.55,'7d':1.60,'30d':1.65,'90d':1.72}.get(h,1.5)
        if master == 'capitulation':
            min_dir -= 5; min_mag -= 2; min_qual -= 4; min_ev *= 0.82; rr_target += 0.05
        elif master == 'bull_trend':
            min_dir -= 2; min_qual -= 2; min_ev *= 0.90
        elif master == 'bear_trend':
            min_dir += 1; min_qual += 1; min_ev *= 1.08
        elif master == 'transition':
            min_dir += 4; min_mag += 3; min_qual += 5; min_ev *= 1.20
        if bucket in ('transition_chop','transition_low_vol'):
            min_dir += 3; min_qual += 4
        if bucket == 'transition_high_vol':
            min_dir += 2; min_qual += 3; rr_target += 0.12
        if sample < 500:
            min_dir += 2; min_qual += 3; min_ev *= 1.15
        return {'min_direction_edge':float(min_dir),'min_magnitude_edge':float(min_mag),'min_trade_quality':float(min_qual),'min_ev':float(min_ev),'min_potential':float(min_potential),'rr_target':float(rr_target)}

    def _strictness_bucket(self, direction_edge: float, magnitude_edge: float, trade_quality: float, ev_pct: float, rr: float) -> str:
        score = min(direction_edge, magnitude_edge, trade_quality)
        if score >= 84 and ev_pct > 0 and rr >= 1.45:
            return 'elite'
        if score >= 75 and ev_pct > 0 and rr >= 1.30:
            return 'strict'
        if score >= 66 and ev_pct > 0 and rr >= self.MIN_RR:
            return 'normal'
        if score >= 56:
            return 'loose_watch_only'
        return 'reject'

    def _reason(self, gates: dict, policy: dict, bucket: str) -> str:
        reasons=[]
        if gates['direction_edge'] < policy['min_direction_edge']:
            reasons.append('low_direction_edge')
        if gates['magnitude_edge'] < policy['min_magnitude_edge']:
            reasons.append('insufficient_market_potential')
        if gates['trade_quality'] < policy['min_trade_quality']:
            reasons.append('low_trade_quality')
        if gates['ev_pct'] < policy['min_ev']:
            reasons.append('negative_or_weak_expected_value')
        if gates['rr'] < self.MIN_RR:
            reasons.append('bad_rr')
        if bucket.startswith('transition'):
            reasons.append('transition_chop_requires_extra_edge')
        return 'no_trade_' + '__'.join(reasons[:5] or ['edge_not_confirmed'])

    def select(self, item: dict, horizon: str | None = None, *, live: bool = False) -> dict:
        horizon = str(horizon or item.get('horizon') or '1h')
        entry = _finite(item.get('entry_price') or item.get('start_price') or item.get('current_price'), 0.0)
        if entry <= 0:
            return {**item, 'setup_engine_version':VERSION, 'setup_action':'NO_TRADE', 'no_trade':True, 'setup_reason':'missing_entry_price'}

        move = _finite(item.get('expected_move_pct'), 0.0)
        conf = _finite(item.get('confidence'), 50.0)
        candidate = 'LONG' if move >= 0 else 'SHORT'
        ctx = self._ctx(item)
        aligned_bias, bucket, spec_meta = self._regime_specialist_bias(ctx, horizon, candidate)
        master = spec_meta['master_regime']

        # Specialist can override direction only for the strongest audited cluster: panic/capitulation reversal.
        if spec_meta.get('extreme_red') and (ctx['rsi_14'] <= 30 or spec_meta.get('volume_absorption')) and horizon in ('4h','8h','24h'):
            candidate = 'LONG'
            aligned_bias, bucket, spec_meta = self._regime_specialist_bias(ctx, horizon, candidate)
            spec_meta['direction_override'] = 'panic_reversal_forced_long'

        potential_pct, meta = self._market_potential_pct(item, horizon, candidate, ctx, spec_meta)
        potential_usd = entry * potential_pct / 100.0
        sample = int((meta.get('range_stats') or {}).get('samples') or 0)
        policy = self._policy(horizon, bucket, master, sample)

        conviction = _clamp((conf - 50.0) / 35.0, 0.0, 1.0)
        move_abs = abs(move)
        # Target learns from realised range potential + model move, not fixed dollars.
        # v10.16.82 Claude audit fix: do not construct target/stop only to make RR look good.
        # Prefer conditional target/stop hints from the shared TrustedCore/Twin path.  These are
        # estimated from comparable historical moments (MFE/MAE style) and can fail the RR/EV gate.
        cond_target = _finite(item.get('condition_target_pct'), 0.0)
        cond_stop = _finite(item.get('condition_stop_pct'), 0.0)
        noise_floor = {'1h':0.065,'4h':0.12,'8h':0.17,'24h':0.25,'7d':0.75,'30d':1.8,'90d':3.5}.get(horizon,0.25)
        noise_pct = max(noise_floor, ctx['range_pct']*0.36, ctx['volatility_24']*(0.34 if HORIZON_HOURS.get(horizon,24)<=4 else 0.48), (meta.get('range_stats') or {}).get('median_close_move_pct',0.0)*0.40)
        desired_rr = policy['rr_target']
        if cond_target > 0 and cond_stop > 0:
            target_pct = min(max(cond_target, noise_pct * 0.75), potential_pct * 1.05)
            stop_pct = max(cond_stop, noise_pct * 0.85)
            desired_rr = target_pct / max(stop_pct, 1e-9)
            target_stop_method = 'conditional_twin_distribution_mfe_mae'
        else:
            # Legacy fallback remains only for rows without conditional distribution data.
            raw_target_pct = max(potential_pct * (0.42 + 0.30 * conviction), move_abs * (1.00 + 0.25 * conviction))
            target_pct = min(max(raw_target_pct, noise_pct * 1.05), potential_pct * 0.96)
            stop_pct = max(noise_pct, target_pct / max(policy['rr_target'], 1e-9))
            target_stop_method = 'legacy_fallback_not_rr_forced'
        target_usd = entry * target_pct / 100.0
        stop_usd = entry * stop_pct / 100.0
        rr = target_usd / stop_usd if stop_usd > 0 else 0.0
        if candidate == 'LONG':
            target_price = entry + target_usd; stop_price = entry - stop_usd
        else:
            target_price = entry - target_usd; stop_price = entry + stop_usd

        # Three independent gates.
        # Gate A: direction edge = model confidence + regime specialist alignment + momentum/reversal evidence.
        direction_edge = 50.0 + (conf - 50.0)*0.72 + aligned_bias + min(6.0, move_abs*0.60)
        if abs(aligned_bias) < 2 and master == 'transition':
            direction_edge -= 6.0
        # Gate B: magnitude edge = enough realistic movement beyond market noise.
        magnitude_ratio = potential_pct / max(policy['min_potential'], 1e-9)
        target_noise_ratio = target_pct / max(noise_pct, 1e-9)
        magnitude_edge = 48.0 + min(26.0, math.log(max(0.10, magnitude_ratio))*18.0) + min(18.0, (target_noise_ratio-1.0)*9.0) + min(7.0, move_abs*0.50)
        if bucket in ('transition_low_vol','transition_chop'):
            magnitude_edge -= 5.0
        # Gate C: trade quality = EV/PF proxy + RR + sample + no overtrading/chop penalty.
        effective_conf = conf + max(-8.0, min(8.0, aligned_bias*0.18))
        if bucket.startswith('transition'):
            effective_conf -= 3.0
        if potential_pct < policy['min_potential']:
            effective_conf -= 4.0
        effective_conf = _clamp(effective_conf, 5.0, 92.0)
        ev_pct = (effective_conf/100.0)*target_pct - (1.0-effective_conf/100.0)*stop_pct
        trade_quality = 48.0 + (effective_conf-50.0)*0.55 + min(10.0, math.log10(max(10,sample))*2.0) + min(14.0, (ev_pct/max(policy['min_ev'],1e-9))*4.2 if ev_pct>0 else ev_pct*18.0) + min(10.0, (rr-1.0)*7.5)
        if bucket.startswith('transition'):
            trade_quality -= 4.0
        if rr < self.MIN_RR:
            trade_quality -= 14.0

        direction_edge = round(_clamp(direction_edge, 0, 100),3)
        magnitude_edge = round(_clamp(magnitude_edge, 0, 100),3)
        trade_quality = round(_clamp(trade_quality, 0, 100),3)
        strictness = self._strictness_bucket(direction_edge, magnitude_edge, trade_quality, ev_pct, rr)
        gates = {'direction_edge':direction_edge,'magnitude_edge':magnitude_edge,'trade_quality':trade_quality,'ev_pct':ev_pct,'rr':rr}
        action_ok = (direction_edge >= policy['min_direction_edge'] and magnitude_edge >= policy['min_magnitude_edge'] and trade_quality >= policy['min_trade_quality'] and ev_pct >= policy['min_ev'] and potential_pct >= policy['min_potential'] and rr >= self.MIN_RR)
        action = candidate if action_ok else 'NO_TRADE'
        reason = 'triple_gate_regime_specialist_valid_setup' if action_ok else self._reason(gates, policy, bucket)

        out = dict(item)
        out.update({
            'setup_engine_version': VERSION,
            'setup_action': action,
            'trade_action': action,
            'no_trade': action == 'NO_TRADE',
            'setup_side_candidate': candidate,
            'setup_master_regime': master,
            'setup_regime_bucket': bucket,
            'setup_direction_edge': direction_edge,
            'setup_magnitude_edge': magnitude_edge,
            'setup_trade_quality': trade_quality,
            'setup_quality': trade_quality,
            'setup_strictness_bucket': strictness,
            'setup_min_direction_edge': policy['min_direction_edge'],
            'setup_min_magnitude_edge': policy['min_magnitude_edge'],
            'setup_min_trade_quality': policy['min_trade_quality'],
            'setup_min_quality': policy['min_trade_quality'],
            'market_potential_pct': round(potential_pct,6),
            'market_potential_usd': round(potential_usd,2),
            'setup_target_price': round(target_price,2),
            'setup_target_distance_pct': round(target_pct,6),
            'setup_target_distance_usd': round(target_usd,2),
            'setup_invalidation_price': round(stop_price,2),
            'setup_invalidation_distance_pct': round(stop_pct,6),
            'setup_invalidation_distance_usd': round(stop_usd,2),
            'setup_rr': round(rr or 0.0,4),
            'setup_rr_target_dynamic': round(desired_rr,4),
            'setup_expected_value_pct': round(ev_pct,6),
            'setup_effective_confidence': round(effective_conf,3),
            'setup_confidence_bucket': ('elite_55_plus' if effective_conf >= 55 else 'watch_52_55' if effective_conf >= 52 else 'low_under_52'),
            'setup_confidence_filter_pass_52': bool(effective_conf >= 52),
            'setup_confidence_filter_pass_55': bool(effective_conf >= 55),
            'setup_min_expected_value_pct': policy['min_ev'],
            'setup_min_market_potential_pct': policy['min_potential'],
            'setup_reason': reason,
            'setup_specialist_tags': spec_meta.get('specialist_tags', []),
            'setup_context_json': {**meta, **spec_meta, 'dynamic_policy': policy, 'noise_pct': round(noise_pct,6), 'target_stop_method': target_stop_method, 'triple_gates': gates},
        })
        if not live:
            self.evaluate_historical_setup(out)
        return out

    def evaluate_historical_setup(self, item: dict) -> dict:
        action = str(item.get('setup_action') or 'NO_TRADE')
        entry = _finite(item.get('start_price') or item.get('entry_price'), 0.0)
        high = _finite(item.get('actual_high'), entry)
        low = _finite(item.get('actual_low'), entry)
        actual = _finite(item.get('actual_price'), entry)
        if entry <= 0:
            item.update({'setup_outcome':'unscored_missing_entry'})
            return item
        side = item.get('setup_side_candidate') or ('LONG' if _finite(item.get('expected_move_pct'),0)>=0 else 'SHORT')
        target = _finite(item.get('setup_target_price'), entry)
        stop = _finite(item.get('setup_invalidation_price'), entry)
        if side == 'LONG':
            mfe = max(0.0, high-entry); mae = max(0.0, entry-low)
            target_hit = high >= target; stop_hit = low <= stop; exit_usd = actual-entry
        else:
            mfe = max(0.0, entry-low); mae = max(0.0, high-entry)
            target_hit = low <= target; stop_hit = high >= stop; exit_usd = entry-actual
        target_usd = abs(target-entry); stop_usd = abs(stop-entry)
        # Conservative if both hit because intra-horizon ordering is unknown.
        valid_trade_existed = bool(target_hit and not stop_hit)
        no_trade_correct = None
        if action == 'NO_TRADE':
            no_trade_correct = not valid_trade_existed
            setup_outcome = 'no_trade_correct' if no_trade_correct else 'no_trade_missed_valid_trade'
            return_pct = 0.0
        else:
            if target_hit and not stop_hit:
                setup_outcome = 'target_hit_first_or_only'; return_pct = target_usd/entry*100.0
            elif stop_hit:
                setup_outcome = 'stop_hit_or_ambiguous'; return_pct = -stop_usd/entry*100.0
            else:
                setup_outcome = 'neither_hit_mark_to_horizon'; return_pct = exit_usd/entry*100.0
        item.update({
            'setup_target_hit': bool(target_hit), 'setup_stop_hit': bool(stop_hit), 'setup_both_hit_ambiguous': bool(target_hit and stop_hit),
            'setup_mfe_usd': round(mfe,2), 'setup_mae_usd': round(mae,2), 'setup_mfe_pct': round(mfe/entry*100.0,6), 'setup_mae_pct': round(mae/entry*100.0,6),
            'setup_return_pct': round(return_pct,6), 'setup_valid_trade_existed': valid_trade_existed, 'no_trade_correct': no_trade_correct, 'setup_outcome': setup_outcome,
            'setup_eval_method': 'legacy_high_low_conservative_both_loss',
        })
        # v10.16.84: keep legacy fields for comparison, but add fair v2
        # first-touch/mark-to-close evaluation so ambiguous target+stop rows are
        # no longer automatically counted as losses in audit exports.
        try:
            evaluate_historical_setup_v2(item, db=db, symbol=settings.symbol, horizon_seconds_map=HORIZON_SECONDS)
        except Exception as exc:
            item.update({'setup_eval_method_v2': 'v2_error', 'setup_eval_error_v2': str(exc)[:240]})
        return item

    def select_many(self, items: list[dict]) -> list[dict]:
        return [self.select(i, str(i.get('horizon') or '1h'), live=False) for i in items]
