from __future__ import annotations

import math
from typing import Any

from app.db.database import db


def _safe_float(v: Any, default: float = 0.0) -> float:
    try:
        if v is None:
            return default
        x = float(v)
        if not math.isfinite(x):
            return default
        return x
    except Exception:
        return default


def _clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


class ConfidenceCalibrationService:
    """Out-of-sample-safe probability calibration helper.

    v10.16.83 hardens the v10.16.82 foundation after the full-tool audit:
    no memoisation on a database-backed reliability table, because Time Machine
    backtests mutate that table during/after runs.  Every calibration request is
    built from the currently visible resolved rows and, when as_of_ms is supplied,
    only from rows with cutoff_ms < as_of_ms.

    The service also exposes an in-memory calibration path so Random100/1000 can
    run as an explicit two-pass walk-forward: first generate raw predictions, then
    walk chronologically and calibrate point t only with already-resolved points
    before t.
    """

    MIN_BIN_SAMPLE = 30

    def calibrate_probability(self, horizon: str, raw_prob: float, *, as_of_ms: int | None = None) -> dict[str, Any]:
        p = _clamp(_safe_float(raw_prob, 0.5), 0.01, 0.99)
        table = self._table(horizon, int(as_of_ms) if as_of_ms else None)
        return self._calibrate_from_table(p, table, method=("walk_forward_reliability_bins" if as_of_ms else "historical_reliability_bins_live"))

    def calibrate_probability_from_rows(self, horizon: str, raw_prob: float, rows: list[dict[str, Any]] | tuple[dict[str, Any], ...], *, method: str = "two_pass_walk_forward_in_memory") -> dict[str, Any]:
        """Calibrate from an explicit prior-row list.

        rows must contain bullish_probability/raw_probability and actual_move_pct.
        This is used by the Random Time Machine two-pass backtest so the current
        batch can calibrate chronologically without relying on stale DB state.
        """
        p = _clamp(_safe_float(raw_prob, 0.5), 0.01, 0.99)
        table = self._table_from_rows(rows)
        return self._calibrate_from_table(p, table, method=method)

    def confidence_from_probability(self, raw_prob: float, calibrated_prob: float, *, sample: int = 0, evidence_count: int = 0) -> float:
        p = _clamp(_safe_float(calibrated_prob, 0.5), 0.01, 0.99)
        raw = _clamp(_safe_float(raw_prob, p), 0.01, 0.99)
        calibrated_edge = abs(p - 0.5) * 2.0
        raw_edge = abs(raw - 0.5) * 2.0
        reliability_maturity = _clamp(sample / 500.0, 0.0, 1.0)
        evidence_maturity = _clamp(evidence_count / 180.0, 0.0, 1.0)
        conf = 35.0 + calibrated_edge * 42.0 + reliability_maturity * 9.0 + evidence_maturity * 6.0
        if raw_edge > calibrated_edge + 0.12:
            conf -= 7.0
        return round(_clamp(conf, 18.0, 78.0), 2)

    def reliability_report(self, horizon: str, *, as_of_ms: int | None = None) -> dict[str, Any]:
        table = self._table(horizon, int(as_of_ms) if as_of_ms else None)
        if not table:
            return {"horizon": horizon, "sample": 0, "brier_score": None, "bins": [], "method": "no_reliability_table"}
        total = sum(int(r.get("sample") or 0) for r in table)
        if total <= 0:
            return {"horizon": horizon, "sample": 0, "brier_score": None, "bins": [], "method": "empty_reliability_table"}
        brier = sum(float(r.get("brier_score") or 0.0) * int(r.get("sample") or 0) for r in table) / total
        return {"horizon": horizon, "sample": total, "brier_score": round(brier, 6), "bins": list(table), "method": "walk_forward_reliability_bins" if as_of_ms else "historical_reliability_bins_live"}

    def _calibrate_from_table(self, p: float, table: tuple[dict[str, Any], ...], *, method: str) -> dict[str, Any]:
        if not table:
            cp = 0.5 + (p - 0.5) * 0.55
            return {
                "probability": round(cp, 6),
                "raw_probability": round(p, 6),
                "method": "shrink_no_reliability_table",
                "sample": 0,
                "brier_score": None,
            }
        best = min(table, key=lambda r: abs(float(r.get("center", 0.5)) - p))
        hit = float(best.get("hitrate", 0.5))
        sample = int(best.get("sample", 0) or 0)
        maturity = _clamp(sample / 250.0, 0.10, 1.0)
        cp = (1.0 - maturity) * (0.5 + (p - 0.5) * 0.45) + maturity * hit
        if abs(cp - 0.5) > abs(p - 0.5) + 0.08:
            cp = 0.5 + math.copysign(abs(p - 0.5) + 0.08, cp - 0.5)
        return {
            "probability": round(_clamp(cp, 0.01, 0.99), 6),
            "raw_probability": round(p, 6),
            "method": method,
            "sample": sample,
            "bin_center": round(float(best.get("center", 0.5)), 3),
            "bin_hitrate": round(hit, 6),
            "brier_score": best.get("brier_score"),
        }

    def _table(self, horizon: str, as_of_ms: int | None) -> tuple[dict[str, Any], ...]:
        params: list[Any] = [str(horizon)]
        where = "WHERE horizon=? AND bullish_probability IS NOT NULL AND actual_move_pct IS NOT NULL"
        if as_of_ms is not None:
            where += " AND cutoff_ms < ?"
            params.append(int(as_of_ms))
        try:
            df = db.df(f"""
                SELECT bullish_probability, actual_move_pct
                FROM time_machine_tests
                {where}
            """, params)
        except Exception:
            return tuple()
        if df is None or len(df) < self.MIN_BIN_SAMPLE * 3:
            return tuple()
        rows = []
        for _, row in df.iterrows():
            rows.append({"bullish_probability": row.get("bullish_probability"), "actual_move_pct": row.get("actual_move_pct")})
        return self._table_from_rows(rows)

    def _table_from_rows(self, rows: list[dict[str, Any]] | tuple[dict[str, Any], ...]) -> tuple[dict[str, Any], ...]:
        clean: list[tuple[float, float]] = []
        for r in rows or []:
            p = _safe_float(r.get("bullish_probability", r.get("raw_probability")), float("nan"))
            yv = r.get("actual_move_pct")
            if yv is None:
                continue
            ymove = _safe_float(yv, float("nan"))
            if math.isfinite(p) and math.isfinite(ymove):
                clean.append((_clamp(p, 0.01, 0.99), 1.0 if ymove >= 0 else 0.0))
        if len(clean) < self.MIN_BIN_SAMPLE * 3:
            return tuple()
        out: list[dict[str, Any]] = []
        for i in range(10):
            lo, hi = i / 10.0, (i + 1) / 10.0
            sub = [(p, y) for p, y in clean if (p >= lo and (p < hi if i < 9 else p <= hi))]
            if len(sub) < self.MIN_BIN_SAMPLE:
                continue
            pavg = sum(p for p, _ in sub) / len(sub)
            hit = sum(y for _, y in sub) / len(sub)
            brier = sum((p - y) ** 2 for p, y in sub) / len(sub)
            out.append({"center": pavg, "hitrate": hit, "sample": int(len(sub)), "brier_score": round(brier, 6)})
        return tuple(out)
