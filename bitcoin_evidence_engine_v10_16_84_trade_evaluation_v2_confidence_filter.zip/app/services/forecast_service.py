from __future__ import annotations
import json
from app.db.database import db
from app.core.config import settings
from app.core.time_utils import utc_now, to_ms, horizon_delta
from app.engine.feature_engine import FeatureEngine
from app.engine.model_arena import ModelArena
from app.engine.meta_judge import MetaJudge
from app.engine.risk_rules import invalidation_price as calc_invalidation_price



def _clamp(v, lo, hi, default=0.0):
    try:
        import math
        x = float(v)
        if not math.isfinite(x):
            return default
        return max(lo, min(hi, x))
    except Exception:
        return default

def _normalise_forecast_item(combined: dict, current_price: float, horizon: str) -> dict:
    """V10.16.46: keep live forecast output human-scale and safe.

    Internal models use percent points for expected_move_pct and 0-100 for
    confidence. Older UI bugs multiplied those values by 100. This function also
    prevents absurd live targets or fake 90% confidence when evidence is weak.
    """
    out = dict(combined or {})
    bull = _clamp(out.get('bullish_probability', 0.5), 0.01, 0.99, 0.5)
    if bull > 1.0:  # tolerate accidental 0-100 probability payloads
        bull = _clamp(bull / 100.0, 0.01, 0.99, 0.5)
    out['bullish_probability'] = bull
    out['bearish_probability'] = _clamp(1.0 - bull, 0.01, 0.99, 0.5)
    conf = _clamp(out.get('confidence', 0.0), 0.0, 100.0, 0.0)
    evidence = int(out.get('evidence_count') or 0)
    edge = abs(bull - 0.5) * 2.0
    # Confidence needs both model edge and historical evidence. A neutral stack
    # must not display as a strong signal just because many weak models voted.
    evidence_cap = 38.0 + min(32.0, evidence / 35.0)
    edge_cap = 35.0 + edge * 75.0
    out['confidence'] = round(min(conf, evidence_cap, edge_cap, 88.0), 2)
    move = _clamp(out.get('expected_move_pct', 0.0), -80.0, 80.0, 0.0)
    horizon_caps = {'1h': 3.5, '4h': 6.0, '8h': 8.5, '24h': 13.0, '7d': 24.0, '30d': 45.0, '90d': 75.0}
    cap = horizon_caps.get(str(horizon), 20.0)
    move = _clamp(move, -cap, cap, 0.0)
    out['expected_move_pct'] = round(move, 6)
    if current_price and current_price > 0:
        out['expected_price'] = float(current_price) * (1 + move / 100.0)
    return out


def _bucket_live_feature(name, value):
    try:
        if value is None: return None
        if isinstance(value, str): return value.lower()[:32] if value else None
        x=float(value)
        if x!=x or x in (float('inf'), float('-inf')): return None
    except Exception:
        return None
    n=str(name).lower()
    if 'funding' in n:
        if x>=0.00030: return 'funding_high_positive'
        if x>=0.00008: return 'funding_positive'
        if x<=-0.00012: return 'funding_negative'
        return 'funding_neutral'
    if 'premium' in n or 'spread' in n:
        if x>=0.12: return 'premium_strong_positive'
        if x>=0.025: return 'premium_positive'
        if x<=-0.08: return 'premium_negative'
        return 'premium_neutral'
    if 'rsi' in n:
        if x>=72: return 'rsi_overheated'
        if x>=58: return 'rsi_bullish'
        if x<=30: return 'rsi_oversold'
        if x<=44: return 'rsi_weak'
        return 'rsi_neutral'
    if 'fear' in n:
        if x>=75: return 'greed_extreme'
        if x>=58: return 'greed'
        if x<=25: return 'fear_extreme'
        if x<=42: return 'fear'
        return 'sentiment_neutral'
    if 'volatility' in n:
        if x>=0.075: return 'vol_high'
        if x>=0.04: return 'vol_mid'
        return 'vol_low'
    if 'long_short' in n:
        if x>=1.35: return 'crowded_longs'
        if x<=0.78: return 'crowded_shorts'
        return 'crowding_neutral'
    if 'open_interest' in n:
        if x>=4: return 'oi_rising_fast'
        if x<=-4: return 'oi_falling_fast'
        return 'oi_neutral'
    if 'return' in n or n=='trend':
        if x>=3: return 'trend_up_strong'
        if x>=0.5: return 'trend_up'
        if x<=-3: return 'trend_down_strong'
        if x<=-0.5: return 'trend_down'
        return 'trend_flat'
    if 'drawdown' in n:
        if x<=-35: return 'deep_drawdown'
        if x<=-15: return 'drawdown'
        return 'near_highs'
    return 'positive' if x>0 else ('negative' if x<0 else 'neutral')

def _current_pair_context():
    row = db.df("""
        SELECT funding_rate, spot_premium_coinbase_pct, spot_premium_kraken_pct, cross_exchange_spread_pct,
               rsi_14, fear_greed, volatility_24, long_short_ratio, top_account_long_short_ratio,
               open_interest_change_24h, return_24, return_4, drawdown_from_ath, regime
        FROM features WHERE interval='1h' ORDER BY timestamp_ms DESC LIMIT 1
    """).to_dict('records')
    if not row: return {}, 'unknown'
    r=row[0]; reg=str(r.get('regime') or 'unknown').lower()[:32]
    ctx={}
    ctx['funding']=_bucket_live_feature('funding', r.get('funding_rate'))
    prem = r.get('spot_premium_coinbase_pct') if r.get('spot_premium_coinbase_pct') is not None else (r.get('spot_premium_kraken_pct') if r.get('spot_premium_kraken_pct') is not None else r.get('cross_exchange_spread_pct'))
    ctx['premium']=_bucket_live_feature('premium', prem)
    ctx['rsi']=_bucket_live_feature('rsi', r.get('rsi_14'))
    ctx['fear_greed']=_bucket_live_feature('fear', r.get('fear_greed'))
    ctx['volatility']=_bucket_live_feature('volatility', r.get('volatility_24'))
    ctx['long_short']=_bucket_live_feature('long_short', r.get('long_short_ratio') if r.get('long_short_ratio') is not None else r.get('top_account_long_short_ratio'))
    ctx['open_interest']=_bucket_live_feature('open_interest', r.get('open_interest_change_24h'))
    ctx['trend']=_bucket_live_feature('return_24', r.get('return_24') if r.get('return_24') is not None else r.get('return_4'))
    ctx['drawdown']=_bucket_live_feature('drawdown', r.get('drawdown_from_ath'))
    ctx['regime']=reg
    return {k:v for k,v in ctx.items() if v}, reg

def _apply_adaptive_pair_calibration(out: dict, horizon: str) -> dict:
    try:
        ctx, reg = _current_pair_context()
        if len(ctx) < 2: return out
        dims=list(ctx.keys())
        hits=[]
        for i in range(len(dims)):
            for j in range(i+1, len(dims)):
                a,b=dims[i],dims[j]
                rows=db.df("""
                    SELECT pair_key, feature_a, bucket_a, feature_b, bucket_b, sample, edge, weight, quality, hitrate_with_partial
                    FROM adaptive_feature_pair_weights
                    WHERE horizon=? AND regime=? AND ((feature_a=? AND bucket_a=? AND feature_b=? AND bucket_b=?) OR (feature_a=? AND bucket_a=? AND feature_b=? AND bucket_b=?))
                    ORDER BY quality DESC, sample DESC LIMIT 2
                """, [horizon, reg, a, ctx[a], b, ctx[b], b, ctx[b], a, ctx[a]]).to_dict('records')
                hits.extend(rows)
        if not hits: return out
        # Conservative: combinations may calibrate confidence and strength, but not flip direction.
        sample=sum(max(0,int(h.get('sample') or 0)) for h in hits)
        edge=sum(float(h.get('edge') or 0)*max(1,int(h.get('sample') or 1)) for h in hits)/max(1,sample)
        avg_weight=sum(float(h.get('weight') or 1)*max(1,int(h.get('sample') or 1)) for h in hits)/max(1,sample)
        conf=float(out.get('confidence') or 0)
        move=float(out.get('expected_move_pct') or 0)
        conf += max(-8.0, min(8.0, edge*55.0 + (avg_weight-1.0)*7.0))
        if edge < -0.03:
            move *= max(0.72, 1.0 + edge*1.8)
        elif edge > 0.03:
            move *= min(1.18, 1.0 + edge*0.85)
        out['confidence']=round(max(0.0,min(88.0,conf)),2)
        out['expected_move_pct']=round(max(-80.0,min(80.0,move)),6)
        out['expected_price']=float(out.get('expected_price') or 0) # overwritten below by normalise if needed
        out['adaptive_pair_edge']=round(edge,6)
        out['adaptive_pair_weight']=round(avg_weight,6)
        out['adaptive_pair_matches']=len(hits)
        try:
            contrib=list(out.get('contributions') or [])
            contrib.append({'model_id':'ADAPTIVE_PAIRS','name':'Adaptive Combinations','horizon':horizon,'weight':round(avg_weight,3),'confidence':round(conf,2),'evidence_count':sample,'note':f'{len(hits)} live feature-combinations matched learned Time Machine pairs'})
            out['contributions']=contrib
        except Exception: pass
    except Exception:
        pass
    return out


def _apply_adaptive_feature_calibration(out: dict, horizon: str) -> dict:
    """V10.16.72: use learned single-feature weights in live forecasts.

    Pair learning was already used, but adaptive_feature_weights could be empty
    or unused. This layer does not flip direction; it calibrates confidence and
    move strength according to broad feature dimensions that Time Machine proved
    useful or harmful. It keeps 30d/90d conservative when evidence quality is low.
    """
    try:
        ctx, reg = _current_pair_context()
        if not ctx:
            return out
        dims=[d for d in ctx.keys() if d!='regime']
        if not dims:
            return out
        rows=db.df("""
            SELECT dimension, weight, quality, sample
            FROM adaptive_feature_weights
            WHERE dimension IN ({})
        """.format(','.join(['?']*len(dims))), dims).to_dict('records')
        if not rows:
            return out
        total_sample=sum(max(1,int(r.get('sample') or 1)) for r in rows)
        avg_weight=sum(float(r.get('weight') or 1.0)*max(1,int(r.get('sample') or 1)) for r in rows)/max(1,total_sample)
        avg_quality=sum(float(r.get('quality') or 0.5)*max(1,int(r.get('sample') or 1)) for r in rows)/max(1,total_sample)
        maturity=min(1.0,total_sample/7000.0)
        conf=float(out.get('confidence') or 0)
        move=float(out.get('expected_move_pct') or 0)
        # Useful features can lift confidence a little; weak/noisy feature sets
        # reduce overconfidence. Never let this layer create fake certainty.
        conf_delta=max(-10.0,min(10.0, ((avg_weight-1.0)*9.0 + (avg_quality-0.5)*14.0) * (0.35+0.65*maturity)))
        move_factor=max(0.78,min(1.16, 1.0 + (avg_weight-1.0)*0.16 + (avg_quality-0.5)*0.18))
        # Long horizons were too target-heavy in Time Machine; until the evidence
        # proves otherwise, dampen low-quality long-horizon targets.
        if str(horizon) in ('30d','90d') and avg_quality < 0.54:
            move_factor=min(move_factor, 0.88 if str(horizon)=='30d' else 0.74)
            conf_delta=min(conf_delta, -2.0)
        out['confidence']=round(max(0.0,min(88.0,conf+conf_delta)),2)
        out['expected_move_pct']=round(max(-80.0,min(80.0,move*move_factor)),6)
        out['adaptive_feature_weight']=round(avg_weight,6)
        out['adaptive_feature_quality']=round(avg_quality,6)
        out['adaptive_feature_matches']=len(rows)
        try:
            contrib=list(out.get('contributions') or [])
            contrib.append({'model_id':'ADAPTIVE_FEATURES','name':'Adaptive Feature Weights','horizon':horizon,'weight':round(avg_weight,3),'confidence':round(out['confidence'],2),'evidence_count':total_sample,'note':f'{len(rows)} learned feature dimensions matched live context'})
            out['contributions']=contrib
        except Exception:
            pass
    except Exception:
        pass
    return out


# V10.16.73 — horizon-specific ensemble + confidence rebuild
# -----------------------------------------------------------
# Time Machine showed that “all models vote on all horizons” is too blunt:
# different specialists win on 1h than on 30d/90d.  These helpers make the live
# forecast consume the learned adaptive_model_weights more aggressively while
# keeping a safe fallback when the database has not learned enough yet.

def _adaptive_model_rows_for_horizon(horizon: str) -> list[dict]:
    try:
        return db.df("""
            SELECT model_id, horizon, weight, hitrate, sample, quality, avg_price_error_pct
            FROM adaptive_model_weights
            WHERE horizon=? AND sample>=20
            ORDER BY quality DESC, hitrate DESC, sample DESC
        """, [horizon]).to_dict('records')
    except Exception:
        return []


def _apply_horizon_specific_ensemble(models: list[dict], horizon: str) -> list[dict]:
    """Select/weight models according to their proven Time Machine horizon.

    The goal is not to throw away all dissenting evidence, but to stop weak
    horizon-specific specialists from diluting proven specialists.  Historical
    Twin is always retained as a reality anchor when it has evidence.
    """
    if not models:
        return models
    rows = _adaptive_model_rows_for_horizon(horizon)
    if len(rows) < 4:
        return models
    by_id = {str(r.get('model_id')): r for r in rows}
    ranked_ids = [str(r.get('model_id')) for r in rows]
    top_ids = set(ranked_ids[:7])
    keep: list[dict] = []
    kept_top = 0
    for m in models:
        mid = str(m.get('model_id') or '')
        rec = by_id.get(mid)
        mm = dict(m)
        # Historical twin is the deep evidence anchor; keep it unless it is truly empty.
        if mid == 'M_TWIN':
            if int(mm.get('evidence_count') or 0) >= 25:
                mm['horizon_ensemble_role'] = 'anchor'
                keep.append(mm)
            continue
        if rec:
            sample = int(rec.get('sample') or 0)
            quality = _clamp(rec.get('quality', 0.5), 0.0, 1.0, 0.5)
            hitrate = _clamp(rec.get('hitrate', 0.5), 0.0, 1.0, 0.5)
            learned_weight = _clamp(rec.get('weight', 1.0), 0.15, 3.0, 1.0)
            maturity = min(1.0, sample / 900.0)
            if mid in top_ids:
                # Top specialists get a stronger vote. This is the main edge boost.
                mm['weight'] = float(mm.get('weight') or 1.0) * (1.15 + 0.55*maturity) * learned_weight
                mm['horizon_ensemble_role'] = 'top_horizon_specialist'
                mm['tm_hitrate'] = round(hitrate, 4)
                mm['tm_quality'] = round(quality, 4)
                mm['tm_sample'] = sample
                keep.append(mm); kept_top += 1
            elif sample >= 80 and quality >= 0.49:
                # Mid-table models stay, but are damped.
                mm['weight'] = float(mm.get('weight') or 1.0) * (0.45 + 0.35*maturity) * learned_weight
                mm['horizon_ensemble_role'] = 'secondary_horizon_specialist'
                mm['tm_hitrate'] = round(hitrate, 4)
                mm['tm_quality'] = round(quality, 4)
                mm['tm_sample'] = sample
                keep.append(mm)
            else:
                # Learned weak on this horizon: do not let it dilute the ensemble.
                continue
        else:
            # Unknown/new models may contribute a little, but only as weak scouts.
            mm['weight'] = float(mm.get('weight') or 1.0) * 0.22
            mm['horizon_ensemble_role'] = 'unproven_scout'
            keep.append(mm)
    # Safety: do not collapse to a tiny set if the adaptive table is weird.
    if kept_top < 3 or len(keep) < 5:
        return models
    return keep


def _rebuild_confidence_from_tm(out: dict, horizon: str) -> dict:
    """Calibrate confidence from proven Time Machine reliability.

    Previous confidence often reflected model conviction more than realised
    hitrate.  This layer uses the horizon's learned top specialists, consensus,
    and sample size to cap/lift confidence in a transparent way.
    """
    try:
        rows = _adaptive_model_rows_for_horizon(horizon)[:7]
        if not rows:
            return out
        total_sample = sum(max(1, int(r.get('sample') or 1)) for r in rows)
        avg_hitrate = sum(float(r.get('hitrate') or 0.5)*max(1,int(r.get('sample') or 1)) for r in rows)/max(1,total_sample)
        avg_quality = sum(float(r.get('quality') or 0.5)*max(1,int(r.get('sample') or 1)) for r in rows)/max(1,total_sample)
        maturity = min(1.0, total_sample / 3500.0)
        model_agreement = _clamp(out.get('model_agreement', 0.55), 0.0, 1.0, 0.55)
        pair_edge = abs(float(out.get('adaptive_pair_edge') or 0.0))
        feature_quality = _clamp(out.get('adaptive_feature_quality', avg_quality), 0.0, 1.0, avg_quality)
        # Convert hitrate edge into cautious confidence. Do not imply high certainty
        # when Time Machine has only weak edge, even if model consensus is high.
        hit_edge = max(0.0, avg_hitrate - 0.50)
        base = 42.0 + hit_edge*170.0 + (avg_quality-0.50)*46.0
        consensus_bonus = (model_agreement-0.50)*24.0
        context_bonus = min(8.0, pair_edge*90.0 + max(0.0, feature_quality-0.52)*18.0)
        tm_conf = (base + consensus_bonus + context_bonus) * (0.60 + 0.40*maturity)
        # Long horizons still require extra humility until large samples prove a durable edge.
        if str(horizon) in ('30d','90d'):
            tm_conf = min(tm_conf, 68.0 if avg_hitrate < 0.57 else 74.0)
        old_conf = float(out.get('confidence') or 0.0)
        # Blend, but the TM-calibrated value is the cap for overconfident forecasts.
        new_conf = min(max(18.0, 0.35*old_conf + 0.65*tm_conf), 86.0)
        out['confidence'] = round(new_conf, 2)
        out['tm_confidence_hitrate'] = round(avg_hitrate, 6)
        out['tm_confidence_quality'] = round(avg_quality, 6)
        out['tm_confidence_sample'] = int(total_sample)
        out['tm_confidence_note'] = 'v10.16.73 confidence rebuilt from horizon-specific Time Machine model reliability, consensus and feature context'
        try:
            contrib=list(out.get('contributions') or [])
            contrib.append({'model_id':'TM_CONFIDENCE','name':'TM Confidence Rebuild','horizon':horizon,'weight':1.0,'confidence':round(new_conf,2),'evidence_count':int(total_sample),'note':f'top horizon specialists avg hitrate {avg_hitrate*100:.1f}%, quality {avg_quality:.3f}'})
            out['contributions']=contrib
        except Exception:
            pass
    except Exception:
        pass
    return out


class ForecastService:
    def __init__(self):
        self.features = FeatureEngine()
        self.arena = ModelArena()
        self.judge = MetaJudge()
        self.trusted_core = TrustedCoreModel()
        self.twin_finder = HistoricalTwinFinder()

    def maybe_create_run(self, force: bool = False) -> dict:
        now=utc_now()
        latest = db.fetchone("SELECT created_at_ms FROM forecast_runs ORDER BY created_at_ms DESC LIMIT 1")
        if latest and not force:
            age_min = (to_ms(now) - int(latest[0])) / 60000
            if age_min < settings.min_forecast_gap_minutes:
                return {"created": False, "reason": f"Laatste forecast is {age_min:.1f} minuten oud"}
        return self.create_run()

    def create_run(self) -> dict:
        rebuilt = self.features.rebuild()
        price_row = db.fetchone("SELECT close, open_time FROM raw_candles WHERE source='binance' AND symbol=? AND interval='1h' ORDER BY open_time DESC LIMIT 1", [settings.symbol])
        if not price_row:
            return {"created": False, "reason": "Geen candledata beschikbaar"}
        current_price = float(price_row[0])
        now=utc_now(); now_ms=to_ms(now)
        run_id = db.fetchone("SELECT nextval('seq_forecast_runs')")[0]
        data_points = db.fetchone("SELECT COUNT(*) FROM raw_candles WHERE source='binance' AND symbol=? AND interval='1h'", [settings.symbol])[0]
        db.execute("INSERT INTO forecast_runs VALUES (?, ?, ?, ?, ?, 'open', ?, ?)", [run_id, now, now_ms, current_price, data_points, settings.engine_version, f"features_rebuilt={rebuilt}"])
        items=[]
        feature_row = db.df("""
            SELECT * FROM features WHERE interval='1h' ORDER BY timestamp_ms DESC LIMIT 1
        """).to_dict('records')
        live_feature = feature_row[0] if feature_row else {}
        for horizon in settings.horizons:
            # v10.16.82 foundation: Forecast and Time Machine now share the same
            # trusted core model path.  The old 40-model arena is intentionally
            # bypassed for trade decisions until every extra model proves
            # out-of-sample edge.
            twin = self.twin_finder.find(horizon)
            combined = self.trusted_core.predict(horizon, live_feature, current_price, twin=twin, cutoff_ms=None)
            combined = _normalise_forecast_item(combined, current_price, horizon)
            # V10.16.78: live Forecast uses the exact same Trade Setup Selector
            # as Time Machine.  It may return LONG, SHORT or NO_TRADE with a
            # dynamic target/win price, invalidation, RR and market potential.
            setup_in = {**combined, 'horizon': horizon, 'start_price': current_price, 'entry_price': current_price}
            setup = TradeSetupSelector().select(setup_in, horizon, live=True)
            combined.update({k: v for k, v in setup.items() if str(k).startswith('setup_') or k in ('trade_action','no_trade','market_potential_usd','market_potential_pct')})
            if setup.get('setup_action') in ('LONG','SHORT'):
                combined['expected_price'] = float(setup.get('setup_target_price') or combined['expected_price'])
                combined['expected_move_pct'] = (combined['expected_price']/current_price - 1.0) * 100.0 if current_price else combined.get('expected_move_pct',0)
                if setup.get('setup_action') == 'SHORT' and combined['expected_move_pct'] > 0:
                    combined['expected_move_pct'] *= -1
                combined['confidence'] = max(0.0, min(88.0, float(combined.get('confidence') or 0)))
            else:
                # NO_TRADE is a real forecast, not a failure.  Keep the old model
                # evidence in contributions, but do not publish a fake trade target.
                combined['expected_price'] = float(current_price)
                combined['expected_move_pct'] = 0.0
                combined['confidence'] = max(0.0, min(88.0, float(combined.get('confidence') or 0)))
            try:
                contrib=list(combined.get('contributions') or [])
                contrib.append({'model_id':'TRADE_SETUP_SELECTOR','name':'Unified Trade Setup Selector','horizon':horizon,'weight':1.0,'confidence':combined.get('confidence'),'note':f"{setup.get('setup_action')} RR={setup.get('setup_rr')} potential=${setup.get('market_potential_usd')} target=${setup.get('setup_target_distance_usd')} stop=${setup.get('setup_invalidation_distance_usd')}"})
                combined['contributions']=contrib
            except Exception:
                pass
            due = now + horizon_delta(horizon)
            item_id = f"{run_id}_{horizon}"
            entry_price = float(current_price)
            target_price = float(combined['expected_price'])
            target_distance_usd = target_price - entry_price
            target_distance_pct = (target_distance_usd / entry_price * 100.0) if entry_price else float(combined['expected_move_pct'])
            inv_price_value = float(setup.get('setup_invalidation_price')) if setup.get('setup_action') in ('LONG','SHORT') else float(current_price)
            invalidation_distance_pct = float(setup.get('setup_invalidation_distance_pct') or 0.0)
            invalidation_distance_usd = float(inv_price_value) - entry_price if inv_price_value is not None else None
            # V10.16.46: store entry/target/invalidation distance explicitly.
            # Hitrate alone is not enough; Stijn wants to see how many dollars
            # away the target and invalidation are from the actual entry price.
            db.execute("""
                INSERT INTO forecast_items (
                    item_id, run_id, horizon, due_at, due_at_ms, start_price,
                    bullish_probability, bearish_probability, expected_move_pct, expected_price,
                    entry_price, target_price, target_distance_usd, target_distance_pct,
                    invalidation_price, invalidation_distance_usd, invalidation_distance_pct,
                    bullish_range_low, bullish_range_high, bearish_risk_low, bearish_risk_high,
                    confidence, evidence_count, contributions_json, status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'open')
            """, [item_id, run_id, horizon, due, to_ms(due), current_price, combined['bullish_probability'], combined['bearish_probability'], combined['expected_move_pct'], combined['expected_price'], entry_price, target_price, target_distance_usd, target_distance_pct, inv_price_value, invalidation_distance_usd, invalidation_distance_pct, combined['bullish_range_low'], combined['bullish_range_high'], combined['bearish_risk_low'], combined['bearish_risk_high'], combined['confidence'], combined['evidence_count'], json.dumps(combined['contributions'])])
            items.append({"horizon": horizon, **combined, "entry_price": entry_price, "target_price": target_price, "target_distance_usd": target_distance_usd, "target_distance_pct": target_distance_pct, "invalidation_price": inv_price_value, "invalidation_distance_usd": invalidation_distance_usd, "invalidation_distance_pct": invalidation_distance_pct})
        return {"created": True, "run_id": run_id, "items": items}
