# Outrun IQ v9.0.3

Mobile visual correction build. Deze versie fixt de visuele regressies uit v9.0.2:

- koper/buyer blijft light premium;
- top safe-area/statusbar sluit beter aan op de pagina;
- logo groter;
- hero titel minder dominant;
- zakelijke kant blijft darkmode en is weer leesbaar.

Deploy via de vaste Termius-rsync flow.
