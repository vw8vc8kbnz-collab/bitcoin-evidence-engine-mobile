# Changelog

## v9.0.3 — Mobile Visual Correction
- Buyer mobile header/safe-area kleur gelijkgetrokken zodat de witte statusbalk niet meer los oogt in PWA/Safari.
- Logo op mobile vergroot en beter uitgelijnd.
- Hero headline kleiner en minder dominant gemaakt.
- Zoekkaart en actiekaarten compact gehouden.
- Zakelijke partneromgeving expliciet teruggezet naar darkmode; v9.0.2 light override overschrijft partner niet meer.
- Partner headers, kaarten, voorraad, nieuw-product, promote en wallet opnieuw leesbaar op dark background.
