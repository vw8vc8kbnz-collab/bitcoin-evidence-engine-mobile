# METOD/PAX Tool A — Technische overdracht FIX647

## Doel
FIX647 corrigeert uitsluitend de mobiele UX van Tool A Stap 3 `Doorlopende nerf`.
FIX646 maakte binnen Stap 3 drie opeenvolgende interne fases. Dat bleek functioneel ongeschikt omdat het maken van nerfsets iteratief is: panelen toevoegen, ordenen, preview controleren, groep wisselen en opnieuw aanpassen.

## Nieuwe mobiele architectuur
Stap 3 is opnieuw één werkruimte.

1. Compacte bestaande branded header.
2. Permanente horizontale groepenbalk:
   - alle groepen van het actieve materiaal;
   - itemaantal per groep;
   - actieve groep duidelijk gemarkeerd;
   - onvolledige groep subtiel gemarkeerd;
   - actie `+ Nieuwe groep`.
3. Actieve groep direct in de scrollinhoud:
   - alleen de geselecteerde bestaande `.dropzone` wordt mobiel getoond;
   - bestaande reorder- en remove-actions blijven intact.
4. Beschikbare panelen direct onder de actieve groep:
   - bestaande `.grainChip` click-handler blijft panelen aan `state.grain.selectedGroupId` toevoegen.
5. Permanente live-previewdock:
   - toont actieve groep, aantal panelen en gereedstatus;
   - opent de bestaande preview als bottom sheet.
6. Eén footer voor de complete wizardstap:
   - `Sluiten` gebruikt de bestaande close-action;
   - `Toepassen` gebruikt de bestaande `grainApplyBtn` en validatie.

## Nieuwe bestanden
- `app/toolA_grain_mobile_workspace.css`
- `app/toolA_grain_mobile_workspace.js`

## Verwijderde release-assets
- `app/toolA_grain_mobile_flow.css`
- `app/toolA_grain_mobile_flow.js`

De oude bestanden zijn niet meer geladen of publiek toegestaan.

## Aangepaste bestanden
- `app/toolA.html`
  - interne fase-nav verwijderd;
  - mobile group rail toegevoegd;
  - mobile previewdock en backdrop toegevoegd;
  - preview close-action toegevoegd;
  - nieuwe v=647 assetreferenties en buildmarker.
- `app/server_py.py`
  - expliciete static allowlist wijst naar de FIX647 workspace-assets.
- `DEPLOY_FIX647.sh`
  - releasechecks en healthchecks voor FIX647.

## Niet gewijzigd
- `state.grain` schema;
- `newGroup()`;
- `addItemToGroup()`;
- `removeFromGroup()`;
- `moveInGroup()`;
- `syncGroupOrders()`;
- `drawGrainPreview()`;
- `applyGrainAndContinue()`;
- gelijke-breedtevalidatie;
- desktop Doorlopende-nerf layout;
- stappen 1, 2, 4 en 5;
- pricing, optimizer, Admin en productie.

## Belangrijke integratieregel
De FIX647-laag is een mobiele orchestratie- en presentatielaag. Zij schrijft alleen `state.grain.selectedGroupId` als fallback en roept verder bestaande DOM-actions aan. De bestaande Tool A-code blijft autoritatief voor validatie en mutaties.

## Acceptatie op iPhone
1. Open Stap 3 met minstens twee nerfmaterialen/paneelbreedtes.
2. Controleer dat groep G01 zichtbaar is en dat de panelenlijst tegelijk zichtbaar is.
3. Voeg meerdere panelen toe zonder van scherm te wisselen.
4. Open de previewdock en sluit hem weer; context en scrollpositie moeten behouden blijven.
5. Maak G02 en G03, wissel via de groepenbalk en controleer de aantallen.
6. Verwijder en reorder panelen binnen verschillende groepen.
7. Controleer dat een breedtefout de bestaande foutmelding toont.
8. Klik Toepassen en controleer overgang naar Stap 4.
9. Controleer dat desktop nog de drie bestaande kolommen toont.
