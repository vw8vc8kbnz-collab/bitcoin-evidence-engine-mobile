# METOD/PAX Tool A — technische overdracht FIX646

## Scope
FIX646 is een gerichte mobiele UX-laag voor de bestaande Doorlopende-nerf overlay (Tool A Stap 3). De berekenings-, validatie- en statefuncties blijven uit FIX645 afkomstig.

## Nieuwe bestanden
- `app/toolA_grain_mobile_flow.css`
- `app/toolA_grain_mobile_flow.js`

Deze bestanden zijn expliciet toegevoegd aan `_PUBLIC_STATIC_ROOT_FILES` in `server_py.py`.

## HTML-contract
De drie bestaande hoofdkaarten in `#grainOverlay` hebben nu `data-grain-phase`:
- `eligible`
- `groups`
- `preview`

De mobiele fasenavigatie gebruikt `data-grain-phase-target`. Op desktop worden de nieuwe mobiele elementen verborgen.

## Bestaande logica hergebruikt
- Panelen toevoegen: bestaande `grainChip` click-handler en `addItemToGroup`.
- Nieuwe groep: bestaande `grainNewGroupBtn`.
- Volgorde: bestaande drag/drop en up/down acties.
- Sluiten: bestaande `grainCloseBtn`.
- Toepassen: bestaande `grainApplyBtn` en `applyGrainAndContinue`.

## Geen regressies toegestaan
- Desktop drie-kolommenoverlay blijft werken.
- FIX638 drawer en FIX644/FIX645 keyboardgedrag blijven intact.
- Stap 1 Decor Library blijft intact.
- Nerfvalidatie op gelijke breedte blijft autoritatief.
- Optimizer- en pricinglogica blijven ongewijzigd.
