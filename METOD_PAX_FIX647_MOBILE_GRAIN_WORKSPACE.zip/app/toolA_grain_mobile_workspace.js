(function(){
  'use strict';
  if(window.__FIX647_GRAIN_MOBILE_WORKSPACE__) return;
  window.__FIX647_GRAIN_MOBILE_WORKSPACE__='FIX647_GRAIN_MOBILE_WORKSPACE';

  var overlay=null;
  var rail=null;
  var newGroupBtn=null;
  var previewDock=null;
  var previewThumb=null;
  var previewTitle=null;
  var previewStatus=null;
  var previewBackdrop=null;
  var previewCloseBtn=null;
  var backBtn=null;
  var applyBtn=null;
  var groupsWrap=null;
  var previewWrap=null;
  var wasOpen=false;
  var refreshQueued=false;

  function mobile(){
    return !!(window.matchMedia&&window.matchMedia('(max-width:700px)').matches);
  }
  function getOverlay(){
    overlay=overlay||document.getElementById('grainOverlay');
    return overlay;
  }
  function isVisible(){
    var el=getOverlay();
    if(!el) return false;
    var cs=window.getComputedStyle(el);
    return cs.display!=='none'&&cs.visibility!=='hidden';
  }
  function safeState(){
    try{return window.state||state||null;}catch(_e){return null;}
  }
  function selectedMaterialKey(){
    var s=safeState();
    try{
      return String((s&&s.grain&&s.grain.materialKey)||(s&&s.activeMaterialKey)||'').trim();
    }catch(_e){return '';}
  }
  function materialGroups(){
    var s=safeState();
    var key=selectedMaterialKey();
    try{
      return ((s&&s.grain&&s.grain.groups)||[]).filter(function(group){
        return !key||String(group&&group.materialKey||'')===key;
      });
    }catch(_e){return [];}
  }
  function activeGroup(){
    var s=safeState();
    var list=materialGroups();
    var selected='';
    try{selected=String(s&&s.grain&&s.grain.selectedGroupId||'');}catch(_e){}
    return list.find(function(group){return String(group&&group.id||'')===selected;})||list[0]||null;
  }
  function plural(count,singular,pluralValue){
    return count===1?singular:pluralValue;
  }
  function escapeSelector(value){
    if(window.CSS&&typeof window.CSS.escape==='function') return window.CSS.escape(String(value));
    return String(value).replace(/(["'\\.#:[\]()=+*~> ])/g,'\\$1');
  }
  function callCore(name){
    try{
      var fn=window[name];
      if(typeof fn==='function'){
        var args=Array.prototype.slice.call(arguments,1);
        return fn.apply(window,args);
      }
    }catch(_e){}
  }
  function scheduleRefresh(){
    if(refreshQueued) return;
    refreshQueued=true;
    requestAnimationFrame(function(){
      refreshQueued=false;
      refreshAll();
    });
  }

  function selectGroup(groupId){
    var id=String(groupId||'');
    if(!id) return;
    var el=getOverlay();
    var box=el&&el.querySelector('.dropzone[data-group-id="'+escapeSelector(id)+'"]');
    if(box){
      try{box.click();return;}catch(_e){}
    }
    var s=safeState();
    try{if(s&&s.grain)s.grain.selectedGroupId=id;}catch(_e){}
    callCore('rebuildGrainGroups');
    callCore('drawGrainPreview');
    scheduleRefresh();
  }

  function renderGroupsRail(){
    if(!rail) return;
    var groups=materialGroups();
    var active=activeGroup();
    var activeId=String(active&&active.id||'');
    rail.innerHTML='';
    if(!groups.length){
      var empty=document.createElement('span');
      empty.className='grainMobileGroupTab is-active is-incomplete';
      empty.textContent='Nog geen groep';
      rail.appendChild(empty);
      return;
    }
    groups.forEach(function(group){
      var count=Array.isArray(group&&group.items)?group.items.length:0;
      var button=document.createElement('button');
      button.type='button';
      button.className='grainMobileGroupTab'+(String(group.id||'')===activeId?' is-active':'')+(count<2?' is-incomplete':'');
      button.setAttribute('data-mobile-grain-group',String(group.id||''));
      button.setAttribute('aria-pressed',String(group.id||'')===activeId?'true':'false');
      button.innerHTML='<span>'+String(group.id||'Groep')+'</span><small>'+count+'</small>';
      button.addEventListener('click',function(){selectGroup(group.id);});
      rail.appendChild(button);
    });
    var selected=rail.querySelector('.grainMobileGroupTab.is-active');
    if(selected){
      try{selected.scrollIntoView({block:'nearest',inline:'center',behavior:'smooth'});}catch(_e){}
    }
  }

  function renderPreviewThumb(count){
    if(!previewThumb) return;
    previewThumb.innerHTML='';
    var bars=document.createElement('span');
    bars.className='grainMobilePreviewThumbBars';
    var shown=Math.max(1,Math.min(4,count||1));
    for(var i=0;i<shown;i++){
      var bar=document.createElement('i');
      bars.appendChild(bar);
    }
    previewThumb.appendChild(bars);
  }

  function renderPreviewDock(){
    if(!previewDock) return;
    var group=activeGroup();
    var count=Array.isArray(group&&group.items)?group.items.length:0;
    var groupId=String(group&&group.id||'Nerf-preview');
    var width=Number(group&&group.widthCm||0);
    if(previewTitle) previewTitle.textContent=group?('Nerfgroep '+groupId+' · '+count+' '+plural(count,'paneel','panelen')):'Nerf-preview';
    if(previewStatus){
      if(!group){
        previewStatus.textContent='Maak een groep en voeg panelen toe';
      }else if(count===0){
        previewStatus.textContent='Nog geen panelen · tik hieronder om toe te voegen';
      }else if(count===1){
        previewStatus.textContent='Nog 1 paneel nodig voor een geldige nerf-set';
      }else{
        previewStatus.textContent=(width?width+' cm · ':'')+'Preview gereed · tik om te controleren';
      }
    }
    previewDock.classList.toggle('is-ready',count>=2);
    previewDock.classList.toggle('is-incomplete',count<2);
    renderPreviewThumb(count);
    if(applyBtn){
      var original=document.getElementById('grainApplyBtn');
      applyBtn.disabled=!!(original&&original.disabled);
    }
  }

  function refreshAll(){
    if(!mobile()||!isVisible()) return;
    renderGroupsRail();
    renderPreviewDock();
  }

  function openPreview(){
    var el=getOverlay();
    if(!el) return;
    try{callCore('drawGrainPreview');}catch(_e){}
    el.classList.add('grain-mobile-preview-open');
    if(previewBackdrop) previewBackdrop.setAttribute('aria-hidden','false');
    try{previewCloseBtn&&previewCloseBtn.focus({preventScroll:true});}catch(_e){}
  }
  function closePreview(){
    var el=getOverlay();
    if(!el) return;
    el.classList.remove('grain-mobile-preview-open');
    if(previewBackdrop) previewBackdrop.setAttribute('aria-hidden','true');
    try{previewDock&&previewDock.focus({preventScroll:true});}catch(_e){}
  }
  function closeOverlay(){
    closePreview();
    var close=document.getElementById('grainCloseBtn');
    if(close) close.click();
  }
  function applyAndContinue(){
    closePreview();
    var apply=document.getElementById('grainApplyBtn');
    if(apply) apply.click();
  }

  function bind(){
    var el=getOverlay();
    if(!el) return false;
    rail=document.getElementById('grainMobileGroupsRail');
    newGroupBtn=document.getElementById('grainMobileNewGroupBtn');
    previewDock=document.getElementById('grainMobilePreviewDock');
    previewThumb=document.getElementById('grainMobilePreviewThumb');
    previewTitle=document.getElementById('grainMobilePreviewDockTitle');
    previewStatus=document.getElementById('grainMobilePreviewDockStatus');
    previewBackdrop=document.getElementById('grainMobilePreviewBackdrop');
    previewCloseBtn=document.getElementById('grainMobilePreviewCloseBtn');
    backBtn=el.querySelector('.grainMobileBackBtn');
    applyBtn=el.querySelector('.grainMobileNextBtn');
    groupsWrap=document.getElementById('grainGroups');
    previewWrap=document.getElementById('grainPreview');

    if(newGroupBtn&&!newGroupBtn.__fix647Bound){
      newGroupBtn.__fix647Bound=true;
      newGroupBtn.addEventListener('click',function(){
        var original=document.getElementById('grainNewGroupBtn');
        if(original) original.click();
        setTimeout(scheduleRefresh,30);
      });
    }
    if(previewDock&&!previewDock.__fix647Bound){
      previewDock.__fix647Bound=true;
      previewDock.addEventListener('click',openPreview);
    }
    if(previewBackdrop&&!previewBackdrop.__fix647Bound){
      previewBackdrop.__fix647Bound=true;
      previewBackdrop.addEventListener('click',closePreview);
    }
    if(previewCloseBtn&&!previewCloseBtn.__fix647Bound){
      previewCloseBtn.__fix647Bound=true;
      previewCloseBtn.addEventListener('click',closePreview);
    }
    if(backBtn&&!backBtn.__fix647Bound){
      backBtn.__fix647Bound=true;
      backBtn.textContent='Sluiten';
      backBtn.addEventListener('click',closeOverlay);
    }
    if(applyBtn&&!applyBtn.__fix647Bound){
      applyBtn.__fix647Bound=true;
      applyBtn.textContent='Toepassen';
      applyBtn.addEventListener('click',applyAndContinue);
    }
    if(!el.__fix647Delegated){
      el.__fix647Delegated=true;
      el.addEventListener('click',function(ev){
        if(!mobile()) return;
        var target=ev.target&&ev.target.closest&&ev.target.closest('.grainChip,.groupItem,.miniBtn,.dropzone,#grainNewGroupBtn');
        if(target) setTimeout(scheduleRefresh,35);
      },true);
      el.addEventListener('change',function(ev){
        if(!mobile()) return;
        if(ev.target&&(/^(grainMatSel|grainWidthSel|grainIncludeExtraToggle)$/.test(String(ev.target.id||'')))){
          setTimeout(scheduleRefresh,35);
        }
      },true);
    }
    return true;
  }

  function observe(){
    if(groupsWrap&&!groupsWrap.__fix647Observed){
      groupsWrap.__fix647Observed=true;
      try{new MutationObserver(scheduleRefresh).observe(groupsWrap,{childList:true,subtree:true,characterData:true});}catch(_e){}
    }
    if(previewWrap&&!previewWrap.__fix647Observed){
      previewWrap.__fix647Observed=true;
      try{new MutationObserver(scheduleRefresh).observe(previewWrap,{childList:true,subtree:true,characterData:true});}catch(_e){}
    }
  }

  function visibilityCheck(){
    if(!mobile()) return;
    var open=isVisible();
    if(open&&!wasOpen){
      bind();
      observe();
      closePreview();
      setTimeout(scheduleRefresh,25);
    }
    wasOpen=open;
    if(open) scheduleRefresh();
  }

  function start(){
    if(!bind()) return;
    observe();
    var el=getOverlay();
    try{new MutationObserver(visibilityCheck).observe(el,{attributes:true,attributeFilter:['style','class','aria-hidden']});}catch(_e){}
    document.addEventListener('keydown',function(ev){
      if(ev.key==='Escape'&&isVisible()&&el.classList.contains('grain-mobile-preview-open')){
        ev.preventDefault();
        closePreview();
      }
    });
    if(window.matchMedia){
      var mq=window.matchMedia('(max-width:700px)');
      var onChange=function(){
        if(mq.matches){bind();observe();visibilityCheck();}
        else{el.classList.remove('grain-mobile-preview-open');}
      };
      try{mq.addEventListener('change',onChange);}catch(_e){try{mq.addListener(onChange);}catch(_e2){}}
    }
    visibilityCheck();
  }

  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',start,{once:true});
  else start();
})();
