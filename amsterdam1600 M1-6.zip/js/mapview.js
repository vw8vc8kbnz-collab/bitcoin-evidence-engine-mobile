// Kaart-modus: van veraf wordt Amsterdam niet als tegels gerenderd
// maar als vectorkaart in gravurestijl — vloeiende bogen, crème kades
// langs het water, arceringen als perceel-textuur, de sterwal als
// polygon en het IJ vol scheepsglyphs. Resolutie-onafhankelijk, dus
// op elke zoom vlijmscherp.
//
// Truc: de isometrische projectie is een lineaire transformatie, dus
// we zetten hem als canvas-matrix en tekenen gewoon in tegelcoördinaten.
// Cirkels worden vanzelf ellipsen, bogen blijven vloeiend.
import { GRID, HALF_W, HALF_H, T, OBJ } from './config.js';
import { shoreY } from './world.js';
import MAP from './maps/amsterdam1662.js';

const INK = 'rgba(62, 50, 34, 0.55)';
const COL = {
  field: '#b6bc8d',
  fieldShade: 'rgba(120, 118, 70, 0.08)',
  water: '#a3bcc2',
  waterLine: 'rgba(255,255,255,0.35)',
  block: '#8a4a33',
  hatch: 'rgba(60, 25, 15, 0.28)',
  cream: '#e6dab2',
  plantage: '#a9b076',
  wallFill: '#8f9464',
  glyph: '#3c3222',
};

const DEG = Math.PI / 180;

export class MapView {
  constructor(ships) {
    this.ships = ships; // [[x, y, isLarge], ...]
    const { C, SWEEP, R } = MAP;
    this.C = C; this.SWEEP = SWEEP; this.R = R;

    // — oeverlijn (samples om de 8 tegels)
    this.shore = [];
    for (let x = 0; x <= GRID; x += 8) this.shore.push([x, shoreY(x)]);

    // — sterpolygon van de wal (curtain + bastions) + bastionpunten
    this.star = [];
    this.bastions = [];
    const { r, bastionOut, bastionHalfDeg, bastionEveryDeg } = MAP.wall;
    const pt = (a, rr) => [C.x + rr * Math.cos(a * DEG), C.y + rr * Math.sin(a * DEG)];
    let a = SWEEP.a0;
    this.star.push(pt(a, r));
    for (let ab = SWEEP.a0 - 4; ab > SWEEP.a1 + 2; ab -= bastionEveryDeg) {
      // curtain tot de bastionbasis
      for (; a > ab + bastionHalfDeg; a -= 2) this.star.push(pt(a, r));
      this.star.push(pt(ab + bastionHalfDeg, r));
      const apex = pt(ab, r + bastionOut);
      this.star.push(apex);
      this.star.push(pt(ab - bastionHalfDeg, r));
      this.bastions.push(apex);
      a = ab - bastionHalfDeg;
    }
    for (; a >= SWEEP.a1; a -= 2) this.star.push(pt(a, r));

    // — arceringen (perceel-textuur): radiale lijnen in de ringbanden,
    //   verticale lijnen in de oude kern
    this.hatch = [];
    const bands = [
      [R.singel + 3, R.heren - 3],
      [R.heren + 3, R.keizers - 3],
      [R.keizers + 3, R.prinsen - 3],
    ];
    for (const [r0, r1] of bands) {
      for (let ha = SWEEP.a0 - 2; ha > MAP.plantageMaxAngle; ha -= 1.4) {
        this.hatch.push([pt(ha, r0), pt(ha, r1)]);
      }
    }
    for (let hx = C.x - 122; hx < C.x + 122; hx += 3) {
      const y0 = shoreY(hx) + 4;
      const dy = Math.sqrt(Math.max(0, R.singel * R.singel - (hx - C.x) ** 2));
      this.hatch.push([[hx, y0], [hx, C.y + dy - 3]]);
    }
  }

  // Matrix: tegelcoördinaten → scherm (dpr-transform staat er al onder)
  applyTransform(ctx, cam) {
    ctx.transform(
      HALF_W * cam.zoom, HALF_H * cam.zoom,
      -HALF_W * cam.zoom, HALF_H * cam.zoom,
      -cam.x * cam.zoom + cam.w / 2,
      -cam.y * cam.zoom + cam.h / 2
    );
  }

  strokePts(ctx, pts, w, style, close = false) {
    ctx.beginPath();
    ctx.moveTo(pts[0][0], pts[0][1]);
    for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i][0], pts[i][1]);
    if (close) ctx.closePath();
    ctx.lineWidth = w;
    ctx.strokeStyle = style;
    ctx.stroke();
  }

  draw(ctx, cam, tMs) {
    const { C, SWEEP, R } = this;
    ctx.save();
    this.applyTransform(ctx, cam);
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';

    // 1. Velden
    ctx.fillStyle = COL.field;
    ctx.fillRect(-40, -40, GRID + 80, GRID + 80);
    ctx.fillStyle = COL.fieldShade;
    for (const [fx, fy, fr] of [[90, 400, 130], [400, 420, 150], [60, 200, 80], [470, 260, 90]]) {
      ctx.beginPath(); ctx.arc(fx, fy, fr, 0, 7); ctx.fill();
    }

    // 2. Het IJ
    ctx.beginPath();
    ctx.moveTo(-40, -40);
    ctx.lineTo(-40, this.shore[0][1]);
    for (const [sx, sy] of this.shore) ctx.lineTo(sx, sy);
    ctx.lineTo(GRID + 40, this.shore[this.shore.length - 1][1]);
    ctx.lineTo(GRID + 40, -40);
    ctx.closePath();
    ctx.fillStyle = COL.water;
    ctx.fill();
    // gegraveerde waterlijnen (subtiel bewegend)
    ctx.strokeStyle = COL.waterLine;
    ctx.lineWidth = 0.5;
    const phase = ((tMs / 400) % 14);
    ctx.beginPath();
    for (let wy = 4; wy < 96; wy += 7) {
      for (let wx = ((wy * 5) % 14) - phase; wx < GRID; wx += 26) {
        if (wy < shoreY(Math.max(0, Math.min(511, wx))) - 3) {
          ctx.moveTo(wx, wy);
          ctx.lineTo(wx + 11, wy);
        }
      }
    }
    ctx.stroke();

    // 3. Buitengracht (moat) + sterwal
    this.strokePts(ctx, MAP.arc(MAP.wall.moatR, SWEEP.a0, SWEEP.a1, 3), 13, COL.water);
    ctx.beginPath();
    ctx.moveTo(this.star[0][0], this.star[0][1]);
    for (const [px, py] of this.star) ctx.lineTo(px, py);
    ctx.fillStyle = COL.wallFill;
    ctx.lineWidth = 1.2;
    ctx.strokeStyle = INK;
    ctx.fill();
    ctx.stroke();

    // 4. Stadsmassa: sector binnen de wal, gesloten langs de oever
    ctx.beginPath();
    ctx.arc(C.x, C.y, R.wall - 2, SWEEP.a1 * DEG, SWEEP.a0 * DEG);
    ctx.closePath();
    ctx.fillStyle = COL.block;
    ctx.fill();

    // 5. Arceringen (perceel-textuur) binnen de stadsmassa
    ctx.save();
    ctx.clip(); // clip op de stadssector van hierboven
    ctx.strokeStyle = COL.hatch;
    ctx.lineWidth = 0.55;
    ctx.beginPath();
    for (const [p0, p1] of this.hatch) {
      ctx.moveTo(p0[0], p0[1]);
      ctx.lineTo(p1[0], p1[1]);
    }
    ctx.stroke();
    ctx.restore();

    // 6. Plantage: tuinsector in het oosten
    ctx.beginPath();
    ctx.arc(C.x, C.y, R.wall - 2, SWEEP.a1 * DEG, MAP.plantageMaxAngle * DEG);
    ctx.arc(C.x, C.y, R.singel, MAP.plantageMaxAngle * DEG, SWEEP.a1 * DEG, true);
    ctx.closePath();
    ctx.fillStyle = COL.plantage;
    ctx.fill();

    // 7. Eilanden
    for (const isl of MAP.islands) {
      ctx.beginPath();
      ctx.moveTo(isl.poly[0][0], isl.poly[0][1]);
      for (const [px, py] of isl.poly) ctx.lineTo(px, py);
      ctx.closePath();
      ctx.fillStyle = COL.block;
      ctx.fill();
      ctx.lineWidth = 1.4;
      ctx.strokeStyle = COL.cream;
      ctx.stroke();
    }

    // 8. Straten en pleinen (crème), dan grachten (kade + water)
    for (const s of MAP.streets) this.strokePts(ctx, s.pts, s.w * 0.9, COL.cream);
    ctx.fillStyle = COL.cream;
    for (const p of MAP.plazas) {
      const [x0, y0, x1, y1] = p.rect;
      ctx.fillRect(x0, y0, x1 - x0, y1 - y0);
    }
    for (const isl of MAP.islands) this.strokePts(ctx, isl.spine, 1.6, COL.cream);
    for (const c of MAP.canals) this.strokePts(ctx, c.pts, c.w + 3.2, COL.cream);
    for (const c of MAP.canals) this.strokePts(ctx, c.pts, c.w, COL.water);

    // 9. IJ-kade langs het havenfront
    ctx.beginPath();
    for (const [sx, sy] of this.shore) {
      if (sx < MAP.harbor.x0 || sx > MAP.harbor.x1) continue;
      ctx.lineTo(sx, sy + 1);
    }
    ctx.lineWidth = 2.6;
    ctx.strokeStyle = COL.cream;
    ctx.stroke();

    ctx.restore();

    // 10. Glyphs (buiten de transform, rechtop): schepen, molens, torens
    this.drawGlyphs(ctx, cam);
  }

  toScreen(cam, x, y) {
    return [
      ((x - y) * HALF_W - cam.x) * cam.zoom + cam.w / 2,
      ((x + y) * HALF_H - cam.y) * cam.zoom + cam.h / 2,
    ];
  }

  drawGlyphs(ctx, cam) {
    const z = cam.zoom;
    ctx.strokeStyle = COL.glyph;
    ctx.fillStyle = COL.glyph;

    // schepen: rompje + mast, gehinte grootte
    for (const [x, y, big] of this.ships) {
      const [px, py] = this.toScreen(cam, x, y);
      if (px < -20 || px > cam.w + 20 || py < -20 || py > cam.h + 20) continue;
      const s = (big ? 46 : 26) * z;
      ctx.lineWidth = Math.max(0.5, 10 * z);
      ctx.beginPath();
      ctx.moveTo(px - s, py);
      ctx.lineTo(px + s, py);
      ctx.stroke();
      ctx.lineWidth = Math.max(0.4, 6 * z);
      ctx.beginPath();
      ctx.moveTo(px, py);
      ctx.lineTo(px + 2 * z, py - (big ? 60 : 34) * z);
      ctx.stroke();
    }

    // molens op de bastions: kruisje op steeltje
    ctx.lineWidth = Math.max(0.5, 8 * z);
    for (let k = 0; k < this.bastions.length; k += 2) {
      const [bx, by] = this.bastions[k];
      if (by < shoreY(bx)) continue;
      const [px, py] = this.toScreen(cam, bx, by);
      const s = 34 * z;
      ctx.beginPath();
      ctx.moveTo(px, py); ctx.lineTo(px, py - s);
      ctx.moveTo(px - s * 0.5, py - s * 1.4); ctx.lineTo(px + s * 0.5, py - s * 0.6);
      ctx.moveTo(px - s * 0.5, py - s * 0.6); ctx.lineTo(px + s * 0.5, py - s * 1.4);
      ctx.stroke();
    }

    // kerktorens: spits driehoekje
    for (const lm of MAP.landmarks) {
      if (lm.obj !== 'tower') continue;
      const [px, py] = this.toScreen(cam, lm.x, lm.y);
      const s = 40 * z;
      ctx.beginPath();
      ctx.moveTo(px - s * 0.4, py);
      ctx.lineTo(px, py - s * 1.6);
      ctx.lineTo(px + s * 0.4, py);
      ctx.closePath();
      ctx.fill();
    }
  }
}
