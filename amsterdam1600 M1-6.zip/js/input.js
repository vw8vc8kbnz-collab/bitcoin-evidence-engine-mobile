// Input via Pointer Events: werkt uniform voor touch én muis.
//   1 vinger  → pan
//   2 vingers → pinch-zoom rond het middelpunt van de vingers
//   korte tik → tegel selecteren
//   muiswiel  → zoom (desktop-testen)
const TAP_MAX_MS = 300;
const TAP_MAX_MOVE = 10; // px

export function attachInput(canvas, camera, { onTap, onChange }) {
  const pointers = new Map();
  let pinchDist = 0;
  let tapStart = null;

  function pinchInfo() {
    const [a, b] = [...pointers.values()];
    const dx = b.x - a.x, dy = b.y - a.y;
    return {
      dist: Math.hypot(dx, dy),
      mx: (a.x + b.x) / 2,
      my: (a.y + b.y) / 2,
    };
  }

  canvas.addEventListener('pointerdown', (e) => {
    canvas.setPointerCapture(e.pointerId);
    pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pointers.size === 1) {
      tapStart = { x: e.clientX, y: e.clientY, t: performance.now() };
    } else {
      tapStart = null;
      if (pointers.size === 2) pinchDist = pinchInfo().dist;
    }
  });

  canvas.addEventListener('pointermove', (e) => {
    const p = pointers.get(e.pointerId);
    if (!p) return;

    if (pointers.size === 1) {
      camera.pan(e.clientX - p.x, e.clientY - p.y);
      onChange();
    }

    p.x = e.clientX;
    p.y = e.clientY;

    if (pointers.size === 2) {
      const { dist, mx, my } = pinchInfo();
      if (pinchDist > 0) {
        camera.zoomAt(mx, my, dist / pinchDist);
        onChange();
      }
      pinchDist = dist;
    }
  });

  function release(e) {
    pointers.delete(e.pointerId);
    if (pointers.size < 2) pinchDist = 0;

    if (tapStart && pointers.size === 0) {
      const dt = performance.now() - tapStart.t;
      const moved = Math.hypot(e.clientX - tapStart.x, e.clientY - tapStart.y);
      if (dt < TAP_MAX_MS && moved < TAP_MAX_MOVE) {
        onTap(e.clientX, e.clientY);
      }
      tapStart = null;
    }
  }
  canvas.addEventListener('pointerup', release);
  canvas.addEventListener('pointercancel', release);

  // Desktop: wielzoom rond de cursor
  canvas.addEventListener('wheel', (e) => {
    e.preventDefault();
    camera.zoomAt(e.clientX, e.clientY, e.deltaY < 0 ? 1.12 : 1 / 1.12);
    onChange();
  }, { passive: false });
}
