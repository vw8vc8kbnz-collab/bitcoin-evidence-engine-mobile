// Vectorkaart → tegelgrid. De kaartdata (maps/*.js) beschrijft grachten
// en straten als polylines en gebieden als polygonen; deze module
// rastert dat deterministisch naar de Uint8-wereld.
import { GRID } from './config.js';

function inBounds(x, y) {
  return x >= 0 && y >= 0 && x < GRID && y < GRID;
}

// Ronde stempel op (cx, cy) met straal r
function stamp(tiles, cx, cy, r, type) {
  const r2 = r * r;
  const x0 = Math.floor(cx - r), x1 = Math.ceil(cx + r);
  const y0 = Math.floor(cy - r), y1 = Math.ceil(cy + r);
  for (let y = y0; y <= y1; y++) {
    for (let x = x0; x <= x1; x++) {
      if (!inBounds(x, y)) continue;
      const dx = x + 0.5 - cx, dy = y + 0.5 - cy;
      if (dx * dx + dy * dy <= r2) tiles[y * GRID + x] = type;
    }
  }
}

// Polyline met breedte: langs elk segment stempelen met stap 0.5 tegel
export function strokePolyline(tiles, pts, width, type) {
  const r = Math.max(0.5, width / 2);
  for (let i = 0; i < pts.length - 1; i++) {
    const [ax, ay] = pts[i];
    const [bx, by] = pts[i + 1];
    const len = Math.hypot(bx - ax, by - ay);
    const steps = Math.max(1, Math.ceil(len * 2));
    for (let s = 0; s <= steps; s++) {
      const t = s / steps;
      stamp(tiles, ax + (bx - ax) * t, ay + (by - ay) * t, r, type);
    }
  }
}

// Even-odd ray-cast: ligt tegelcentrum binnen de polygon?
export function pointInPolygon(x, y, pts) {
  let inside = false;
  for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
    const [xi, yi] = pts[i];
    const [xj, yj] = pts[j];
    if ((yi > y) !== (yj > y) && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) {
      inside = !inside;
    }
  }
  return inside;
}

// Polygon vullen; `pick(x, y)` bepaalt per tegel het type (voor variatie)
export function fillPolygon(tiles, pts, pick) {
  let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
  for (const [x, y] of pts) {
    minX = Math.min(minX, x); maxX = Math.max(maxX, x);
    minY = Math.min(minY, y); maxY = Math.max(maxY, y);
  }
  for (let y = Math.max(0, Math.floor(minY)); y <= Math.min(GRID - 1, Math.ceil(maxY)); y++) {
    for (let x = Math.max(0, Math.floor(minX)); x <= Math.min(GRID - 1, Math.ceil(maxX)); x++) {
      if (pointInPolygon(x + 0.5, y + 0.5, pts)) {
        tiles[y * GRID + x] = pick(x, y);
      }
    }
  }
}

// Rechthoek vullen (pleinen)
export function fillRect(tiles, x0, y0, x1, y1, type) {
  for (let y = y0; y <= y1; y++) {
    for (let x = x0; x <= x1; x++) {
      if (inBounds(x, y)) tiles[y * GRID + x] = type;
    }
  }
}
