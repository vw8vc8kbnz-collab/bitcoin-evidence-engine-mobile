// Camera & isometrische wiskunde.
//   wereld-schermruimte (zoom 1):  sx = (x − y)·HALF_W,  sy = (x + y)·HALF_H
//   scherm:                        px = (sx − cam.x)·zoom + w/2
// De inverse hiervan is exact — nodig voor tile-picking en culling.
import { HALF_W, HALF_H, GRID, MIN_ZOOM, MAX_ZOOM } from './config.js';

export class Camera {
  constructor(w, h, startZoom) {
    this.w = w;
    this.h = h;
    this.zoom = startZoom;
    // start gecentreerd op het midden van de kaart
    const m = GRID / 2;
    this.x = (m - m) * HALF_W;      // = 0
    this.y = (m + m) * HALF_H;
  }

  resize(w, h) { this.w = w; this.h = h; }

  worldToScreen(sx, sy) {
    return [
      (sx - this.x) * this.zoom + this.w / 2,
      (sy - this.y) * this.zoom + this.h / 2,
    ];
  }

  screenToWorld(px, py) {
    return [
      (px - this.w / 2) / this.zoom + this.x,
      (py - this.h / 2) / this.zoom + this.y,
    ];
  }

  // Schermpixel → tegelcoördinaat (kan buiten het grid vallen)
  tileAtScreen(px, py) {
    const [sx, sy] = this.screenToWorld(px, py);
    const tx = Math.floor(sx / HALF_W / 2 + sy / HALF_H / 2);
    const ty = Math.floor(sy / HALF_H / 2 - sx / HALF_W / 2);
    return [tx, ty];
  }

  pan(dxPx, dyPx) {
    this.x -= dxPx / this.zoom;
    this.y -= dyPx / this.zoom;
    this.clamp();
  }

  // Zoomen rond een schermpunt: het wereldpunt onder de vinger blijft staan.
  zoomAt(px, py, factor) {
    const nz = Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, this.zoom * factor));
    if (nz === this.zoom) return;
    const [wx, wy] = this.screenToWorld(px, py);
    this.zoom = nz;
    this.x = wx - (px - this.w / 2) / this.zoom;
    this.y = wy - (py - this.h / 2) / this.zoom;
    this.clamp();
  }

  // Camera losjes binnen de kaartranden houden
  clamp() {
    const maxSX = GRID * HALF_W;
    const maxSY = GRID * HALF_H * 2;
    this.x = Math.max(-maxSX, Math.min(maxSX, this.x));
    this.y = Math.max(-HALF_H * 8, Math.min(maxSY + HALF_H * 8, this.y));
  }

  // Zichtbaar tegelbereik voor culling: inverse transform van de vier
  // schermhoeken, bounding box in tegelruimte + marge.
  visibleTileBounds() {
    const corners = [
      this.screenToWorld(0, 0),
      this.screenToWorld(this.w, 0),
      this.screenToWorld(0, this.h),
      this.screenToWorld(this.w, this.h),
    ];
    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    for (const [sx, sy] of corners) {
      const tx = sx / HALF_W / 2 + sy / HALF_H / 2;
      const ty = sy / HALF_H / 2 - sx / HALF_W / 2;
      minX = Math.min(minX, tx); maxX = Math.max(maxX, tx);
      minY = Math.min(minY, ty); maxY = Math.max(maxY, ty);
    }
    return [
      Math.max(0, Math.floor(minX) - 1),
      Math.min(GRID - 1, Math.ceil(maxX) + 1),
      Math.max(0, Math.floor(minY) - 1),
      Math.min(GRID - 1, Math.ceil(maxY) + 1),
    ];
  }
}
