// Deterministische randomness. Regel uit het GDD: één seeded bron,
// zodat dezelfde seed altijd exact dezelfde wereld oplevert (saves,
// tests, en later eventueel replays).

export function mulberry32(seed) {
  let a = seed >>> 0;
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// Stateloze integer-hash: zelfde (x, y, seed) → altijd zelfde waarde [0,1).
export function hash2d(x, y, seed) {
  let h = (x | 0) * 374761393 + (y | 0) * 668265263 + (seed | 0) * 2246822519;
  h = (h ^ (h >>> 13)) | 0;
  h = Math.imul(h, 1274126177);
  h = (h ^ (h >>> 16)) >>> 0;
  return h / 4294967296;
}

function smooth(t) { return t * t * (3 - 2 * t); }

// Value-noise op basis van hash2d — genoeg voor terreinvariatie,
// geen externe noise-library nodig.
export function noise2d(x, y, seed) {
  const x0 = Math.floor(x), y0 = Math.floor(y);
  const fx = smooth(x - x0), fy = smooth(y - y0);
  const a = hash2d(x0, y0, seed);
  const b = hash2d(x0 + 1, y0, seed);
  const c = hash2d(x0, y0 + 1, seed);
  const d = hash2d(x0 + 1, y0 + 1, seed);
  return a + (b - a) * fx + (c - a) * fy + (a - b - c + d) * fx * fy;
}

// Twee octaven fractal-noise voor organischer terrein.
export function fnoise(x, y, seed) {
  return 0.65 * noise2d(x, y, seed) + 0.35 * noise2d(x * 2.7 + 41.3, y * 2.7 + 17.9, seed ^ 0x9e37);
}
