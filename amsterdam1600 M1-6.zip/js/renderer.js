// Renderer met hoogte-objecten.
//   Dichtbij: diagonale painter's sort op (x+y) — grond en object per
//   tegel in één pass, zodat torens en pandjes elkaar correct afdekken.
//   Ver weg: één drawImage van de voorgerenderde overzichtskaart.
import {
  GRID, HALF_W, HALF_H, TILE_W, TILE_H, T, OBJ,
  OVERVIEW_CUTOFF, OVERVIEW_SCALE, WATER_FRAMES, WATER_FRAME_MS,
} from './config.js';
import { variantAt } from './world.js';
import { hash2d } from './rng.js';

const WORLD_SX_MIN = -GRID * HALF_W;
const WORLD_SW = GRID * TILE_W;
const WORLD_SH = GRID * TILE_H;

export class Renderer {
  constructor(ctx, world, objects, tileset, objectSprites, mapView) {
    this.ctx = ctx;
    this.world = world;
    this.objects = objects;
    this.sprites = tileset.sprites;
    this.selectionSprite = tileset.selection;
    this.objSprites = objectSprites;
    this.mapView = mapView;
    this.selected = null;
    this.overview = null;
    this.drawnTiles = 0;
  }

  buildOverview() {
    const c = document.createElement('canvas');
    c.width = Math.ceil(WORLD_SW * OVERVIEW_SCALE);
    c.height = Math.ceil(WORLD_SH * OVERVIEW_SCALE);
    const octx = c.getContext('2d');
    octx.imageSmoothingEnabled = false;
    const w = TILE_W * OVERVIEW_SCALE;
    const h = TILE_H * OVERVIEW_SCALE;
    for (let y = 0; y < GRID; y++) {
      for (let x = 0; x < GRID; x++) {
        const t = this.world[y * GRID + x];
        const frames = this.sprites[t];
        const sprite = frames[t === T.IJ || t === T.CANAL ? 0 : variantAt(x, y)];
        const sx = ((x - y) * HALF_W - WORLD_SX_MIN) * OVERVIEW_SCALE;
        const sy = (x + y) * HALF_H * OVERVIEW_SCALE;
        octx.drawImage(sprite, sx - w / 2, sy, w, h);
      }
    }
    // Objecten als markeringen meebakken: zo toont ook de verre blik
    // de schepen op het IJ, de torens en de bomen.
    const marks = {
      [OBJ.SHIP_L]: ['#3a2d1e', 4, 2],
      [OBJ.SHIP_S]: ['#463724', 2.5, 1.5],
      [OBJ.TOWER]:  ['#3f3a30', 3, 4],
      [OBJ.CHURCH]: ['#4a4238', 4, 3],
      [OBJ.MILL]:   ['#503e28', 3, 3],
      [OBJ.TREE]:   ['#48602f', 1.6, 1.6],
    };
    for (let y = 0; y < GRID; y++) {
      for (let x = 0; x < GRID; x++) {
        const o = this.objects[y * GRID + x];
        if (o === OBJ.NONE) continue;
        const m = marks[o];
        if (!m) continue;
        const sx = ((x - y) * HALF_W - WORLD_SX_MIN) * OVERVIEW_SCALE;
        const sy = (x + y) * HALF_H * OVERVIEW_SCALE;
        octx.fillStyle = m[0];
        octx.fillRect(sx - m[1] / 2, sy - m[2] / 2, m[1], m[2]);
      }
    }
    this.overview = c;
  }

  draw(cam, tMs) {
    const { ctx } = this;
    ctx.fillStyle = '#141a19';
    ctx.fillRect(0, 0, cam.w, cam.h);
    if (cam.zoom < OVERVIEW_CUTOFF && this.mapView) {
      this.mapView.draw(ctx, cam, tMs);
      this.drawnTiles = 1;
    } else {
      this.drawTiles(cam, tMs);
    }
    this.drawSelection(cam);
  }

  drawOverview(cam) {
    const [px, py] = cam.worldToScreen(WORLD_SX_MIN, 0);
    this.ctx.imageSmoothingEnabled = true;
    this.ctx.drawImage(this.overview, px, py, WORLD_SW * cam.zoom, WORLD_SH * cam.zoom);
    this.drawnTiles = 1;
  }

  // Kies deterministisch een objectvariant voor deze tegel
  pickObjSprite(o, x, y) {
    const list = this.objSprites[o];
    if (list.length === 1) return list[0];
    return list[(hash2d(x, y, 0x51) * list.length) | 0];
  }

  drawTiles(cam, tMs) {
    const { ctx, world, objects, sprites } = this;
    const [x0, x1, y0, y1] = cam.visibleTileBounds();
    const waterFrame = Math.floor(tMs / WATER_FRAME_MS) % WATER_FRAMES;
    const dw = TILE_W * cam.zoom;
    const dh = TILE_H * cam.zoom;
    // marge boven de tegel voor hoge objecten (hoogste sprite ≈ 60 px)
    const topMargin = 64 * cam.zoom;
    ctx.imageSmoothingEnabled = cam.zoom < 1;

    let drawn = 0;
    // Painter's sort: diagonalen van achter (klein x+y) naar voor (groot).
    for (let s = x0 + y0; s <= x1 + y1; s++) {
      const yStart = Math.max(y0, s - x1);
      const yEnd = Math.min(y1, s - x0);
      for (let y = yStart; y <= yEnd; y++) {
        const x = s - y;
        const i = y * GRID + x;
        const t = world[i];
        const isWater = t === T.IJ || t === T.CANAL;
        const sprite = sprites[t][isWater ? waterFrame : variantAt(x, y)];
        const [px, py] = cam.worldToScreen((x - y) * HALF_W, (x + y) * HALF_H);
        if (px < -dw || px > cam.w + dw || py < -topMargin || py > cam.h + dh) continue;
        ctx.drawImage(sprite, px - dw / 2, py, dw, dh);
        drawn++;
        const o = objects[i];
        if (o !== OBJ.NONE) {
          const os = this.pickObjSprite(o, x, y);
          ctx.drawImage(
            os.canvas,
            px - dw / 2,
            py - os.H * cam.zoom,
            dw,
            (TILE_H + os.H) * cam.zoom
          );
        }
      }
    }
    this.drawnTiles = drawn;
  }

  drawSelection(cam) {
    if (!this.selected) return;
    const [x, y] = this.selected;
    const [px, py] = cam.worldToScreen((x - y) * HALF_W, (x + y) * HALF_H);
    const dw = TILE_W * cam.zoom;
    const dh = TILE_H * cam.zoom;
    this.ctx.drawImage(this.selectionSprite, px - dw / 2, py, dw, dh);
  }
}
