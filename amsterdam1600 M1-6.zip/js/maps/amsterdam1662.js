// Amsterdam anno 1662 — de voltooide Grachtengordel.
// Dé kaart die iedereen herkent: de halve maan aan het IJ met de ring
// Singel–Herengracht–Keizersgracht–Prinsengracht–Lijnbaansgracht, de
// Jordaan als schuine waaier, de stervormige omwalling met bastions en
// molens, de westelijke en oostelijke haveneilanden, en een IJ vol
// schepen.
//
// De ring is opgebouwd als echte cirkelbogen rond centrum C.
// Grid 512×512, tegel ≈ 5 m, noord (het IJ) boven.

const C = { x: 258, y: 94 };     // middelpunt van de grachtenboog
const SWEEP = { a0: 176, a1: 4 } // graden; 176 = west aan het IJ, 4 = oost

// Boog als polyline (graden → punten)
function arc(r, a0 = SWEEP.a0, a1 = SWEEP.a1, step = 4) {
  const pts = [];
  const n = Math.max(2, Math.ceil(Math.abs(a0 - a1) / step));
  for (let i = 0; i <= n; i++) {
    const a = ((a0 + ((a1 - a0) * i) / n) * Math.PI) / 180;
    pts.push([C.x + r * Math.cos(a), C.y + r * Math.sin(a)]);
  }
  return pts;
}

// Radiale lijn van binnen- naar buitenradius op hoek a (graden)
function radial(a, r0, r1) {
  const rad = (a * Math.PI) / 180;
  return [
    [C.x + r0 * Math.cos(rad), C.y + r0 * Math.sin(rad)],
    [C.x + r1 * Math.cos(rad), C.y + r1 * Math.sin(rad)],
  ];
}

// Punt op (hoek, radius)
function at(a, r) {
  const rad = (a * Math.PI) / 180;
  return [Math.round(C.x + r * Math.cos(rad)), Math.round(C.y + r * Math.sin(rad))];
}

// Ringradii (tegels): het hart van deze kaart
const R = {
  singel: 126,
  heren: 158,
  keizers: 182,
  prinsen: 206,
  lijnbaans: 232,
  wall: 246,
  moat: 256,
};

// — Jordaan: schuine waaier van grachten tussen Prinsen- en Lijnbaansgracht
const jordaanCanals = [];
const jordaanStreets = [];
for (let a = 133; a <= 174; a += 6.5) {
  jordaanCanals.push({ pts: radial(a, R.prinsen, R.lijnbaans), w: 3, name: 'Jordaangracht' });
  if (a + 3.25 < 175) {
    jordaanStreets.push({ pts: radial(a + 3.25, R.prinsen, R.lijnbaans), w: 1.6, name: 'Jordaanstraat' });
  }
}

// — Plantage-lanen (oostelijke ring: tuinen in plaats van bebouwing)
const plantageStreets = [];
for (const a of [16, 30, 44]) {
  plantageStreets.push({ pts: radial(a, R.singel, R.lijnbaans), w: 2, name: 'Plantagelaan' });
}

export default {
  name: 'Amsterdam 1662 — de Grachtengordel',
  C, SWEEP, R, arc, at,

  // Zuidoever van het IJ (licht schuin)
  ijShore: { x0: 0, y0: 92, x1: 511, y1: 110 },

  // Analytische stadsdefinitie: binnen straal R.wall, binnen de sweep,
  // onder de oever. Plantage (hoek < 58°, buiten de Singel) is tuinen.
  plantageMaxAngle: 58,

  harbor: { x0: 40, x1: 470 },

  palisade: [
    { yOffset: -8,  x0: 130, x1: 400, dash: 16, gap: 7 },
    { yOffset: -14, x0: 170, x1: 360, dash: 20, gap: 9 },
  ],

  // Westelijke eilanden (Bickers-, Prinsen-, Realeneiland) en
  // oostelijke eilanden (Kattenburg, Wittenburg, Oostenburg)
  islands: [
    { poly: [[96, 62], [130, 54], [136, 72], [102, 80]],  spine: [[100, 70], [132, 63]], name: 'Realeneiland' },
    { poly: [[140, 52], [176, 46], [182, 64], [146, 70]], spine: [[144, 61], [178, 55]], name: 'Prinseneiland' },
    { poly: [[186, 46], [224, 42], [228, 60], [190, 62]], spine: [[190, 54], [224, 51]], name: 'Bickerseiland' },
    { poly: [[380, 66], [420, 58], [428, 80], [388, 88]], spine: [[386, 77], [422, 69]], name: 'Kattenburg' },
    { poly: [[426, 60], [464, 54], [472, 76], [434, 82]], spine: [[432, 71], [466, 65]], name: 'Wittenburg' },
    { poly: [[470, 56], [504, 50], [511, 72], [478, 78]], spine: [[476, 67], [506, 61]], name: 'Oostenburg' },
  ],

  // Waterlopen
  canals: [
    // de ring — het icoon
    { pts: arc(R.singel),   w: 7, name: 'Singel' },
    { pts: arc(R.heren),    w: 7, name: 'Herengracht' },
    { pts: arc(R.keizers),  w: 7, name: 'Keizersgracht' },
    { pts: arc(R.prinsen),  w: 7, name: 'Prinsengracht' },
    { pts: arc(R.lijnbaans), w: 5, name: 'Lijnbaansgracht' },
    // Brouwersgracht: verbindt de ring aan de noordwestkant
    { pts: [at(170, R.singel), at(167, R.heren), at(165, R.keizers), at(163, R.prinsen)], w: 5, name: 'Brouwersgracht' },
    // Leidsegracht: radiale gracht
    { pts: radial(122, R.singel, R.prinsen), w: 4, name: 'Leidsegracht' },
    // de Jordaan
    ...jordaanCanals,
    // de oude kern
    { pts: [[252, 98], [250, 150], [254, 190], [256, 212]], w: 8, name: 'Damrak' },
    { pts: [[258, 226], [262, 246], [268, 262]], w: 6, name: 'Rokin' },
    { pts: [[310, 511], [300, 440], [310, 380], [298, 330], [288, 292], [276, 258], [268, 262]], w: 13, name: 'Amstel' },
    { pts: [[272, 102], [270, 150], [266, 196], [262, 224], [264, 240]], w: 3.5, name: 'OZ Voorburgwal' },
    { pts: [[286, 106], [283, 152], [276, 198], [268, 228], [270, 244]], w: 3.5, name: 'OZ Achterburgwal' },
    { pts: [[238, 98], [234, 148], [240, 196], [248, 226], [254, 244]], w: 3.5, name: 'NZ Voorburgwal' },
    { pts: [[220, 102], [216, 152], [226, 204], [238, 238], [248, 254]], w: 3.5, name: 'NZ Achterburgwal' },
    { pts: [[330, 100], [328, 126], [326, 148]], w: 6, name: 'Geldersekade' },
    { pts: [[326, 156], [322, 196], [310, 224], [298, 240], [290, 250]], w: 6, name: 'Kloveniersburgwal' },
    { pts: [[332, 152], [356, 132], [382, 112]], w: 6, name: 'Oudeschans' },
    { pts: [[326, 136], [352, 118], [376, 102]], w: 3, name: 'Uilenburgergracht' },
    { pts: [[330, 144], [358, 126], [384, 108]], w: 3, name: 'Valkenburgergracht' },
  ],

  // De stervormige omwalling
  wall: {
    r: R.wall,
    moatR: R.moat,
    bastionEveryDeg: 8.6,
    bastionOut: 17,       // hoe ver de punt naar buiten steekt
    bastionHalfDeg: 2.6,  // halve basisbreedte in graden
  },

  streets: [
    // radiale hoofdstraten door de ring
    { pts: radial(112, R.singel - 6, R.wall), w: 2.5, name: 'Leidsestraat' },
    { pts: radial(95,  R.singel - 6, R.wall), w: 2.5, name: 'Vijzelstraat' },
    { pts: radial(78,  R.singel - 6, R.wall), w: 2.5, name: 'Utrechtsestraat' },
    { pts: radial(150, R.prinsen, R.lijnbaans), w: 3, name: 'Rozengracht-as' },
    // Haarlemmerdijk langs het IJ naar de Haarlemmerpoort
    { pts: [[150, 96], [110, 104], [70, 112]], w: 2.5, name: 'Haarlemmerdijk' },
    // de oude kern
    { pts: [[260, 100], [258, 150], [260, 195], [260, 210]], w: 2.5, name: 'Warmoesstraat' },
    { pts: [[244, 100], [241, 148], [245, 192], [248, 210]], w: 2.5, name: 'Nieuwendijk' },
    { pts: [[250, 228], [244, 252], [242, 272], [248, 288]], w: 2.5, name: 'Kalverstraat' },
    { pts: [[264, 228], [268, 248], [274, 264]], w: 2, name: 'Nes' },
    { pts: [[296, 100], [308, 118], [318, 136], [324, 150]], w: 2.5, name: 'Zeedijk' },
    { pts: [[334, 158], [352, 150], [368, 140]], w: 2.5, name: 'Sint Antoniesbreestraat' },
    { pts: [[266, 218], [292, 222], [314, 212], [324, 196], [326, 162]], w: 2, name: 'Damstraat–Hoogstraten' },
    ...plantageStreets,
    ...jordaanStreets,
  ],

  plazas: [
    { rect: [248, 212, 266, 224], name: 'de Dam' },
    { rect: [320, 148, 334, 160], name: 'Nieuwmarkt' },
    { rect: [277, 126, 289, 136], name: 'Oudekerksplein' },
    { rect: [110, 236, 122, 246], name: 'Westermarkt' },
  ],

  landmarks: [
    { x: 283, y: 130, obj: 'tower',  name: 'Oude Kerk' },
    { x: 281, y: 133, obj: 'church', name: 'Oude Kerk' },
    { x: 285, y: 133, obj: 'church', name: 'Oude Kerk' },
    { x: 243, y: 208, obj: 'tower',  name: 'Nieuwe Kerk' },
    { x: 241, y: 211, obj: 'church', name: 'Nieuwe Kerk' },
    { x: 106, y: 240, obj: 'tower',  name: 'Westerkerk' },
    { x: 104, y: 243, obj: 'church', name: 'Westerkerk' },
    { x: 108, y: 243, obj: 'church', name: 'Westerkerk' },
    { x: 306, y: 196, obj: 'tower',  name: 'Zuiderkerk' },
    { x: 304, y: 199, obj: 'church', name: 'Zuiderkerk' },
    { x: 328, y: 154, obj: 'church', name: 'de Waag' },
    { x: 386, y: 110, obj: 'tower',  name: 'Montelbaanstoren' },
    { x: 318, y: 100, obj: 'tower',  name: 'Schreierstoren' },
    { x: 278, y: 222, obj: 'tower',  name: 'Munttoren' },
  ],
};
