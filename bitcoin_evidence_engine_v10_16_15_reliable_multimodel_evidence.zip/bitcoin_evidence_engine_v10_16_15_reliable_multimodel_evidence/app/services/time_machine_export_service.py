from __future__ import annotations

import csv
import json
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from app.core.config import settings
from app.core.debug import append_jsonl
from app.db.database import db


def _safe_json(obj: Any) -> Any:
    try:
        import math
        if obj is None or isinstance(obj, (str, bool, int)):
            return obj
        if isinstance(obj, float):
            return obj if math.isfinite(obj) else None
        if isinstance(obj, dict):
            return {str(k): _safe_json(v) for k, v in obj.items()}
        if isinstance(obj, (list, tuple)):
            return [_safe_json(v) for v in obj]
        if hasattr(obj, 'item'):
            return _safe_json(obj.item())
        if hasattr(obj, 'isoformat'):
            return obj.isoformat()
    except Exception:
        pass
    return str(obj)


class TimeMachineExportService:
    """Persistent Time Machine evidence exports.

    Random100/Random1000 should be analyzable later exactly like the local debug
    folders. This service stores the raw native items, summary, and relevant DB
    rows under the shared data directory, so exports survive new ZIP versions.
    """

    ROOT = settings.data_dir / "time_machine_exports"

    def __init__(self) -> None:
        self.root = self.ROOT
        self.root.mkdir(parents=True, exist_ok=True)

    def _batch_dir(self, batch_id: str) -> Path:
        safe = ''.join(ch for ch in str(batch_id) if ch.isalnum() or ch in ('-', '_'))[:80] or 'batch'
        d = self.root / safe
        d.mkdir(parents=True, exist_ok=True)
        return d

    def write_random_batch(self, *, batch_id: str, count: int, native: dict, items: list[dict], summary: dict, source: str) -> dict:
        d = self._batch_dir(batch_id)
        now = datetime.now(timezone.utc).isoformat()
        meta = {
            "ok": True,
            "kind": "time_machine_random_batch",
            "batch_id": batch_id,
            "source": source,
            "requested_count": int(count),
            "item_count": len(items),
            "created_at": now,
            "engine_version": settings.engine_version,
            "data_dir": str(settings.data_dir),
            "db_path": str(settings.db_path),
            "native_elapsed_ms": native.get("elapsed_ms"),
            "native_bridge_elapsed_ms": native.get("native_bridge_elapsed_ms"),
        }
        (d / "manifest.json").write_text(json.dumps(_safe_json(meta), ensure_ascii=False, indent=2), encoding="utf-8")
        (d / "summary.json").write_text(json.dumps(_safe_json(summary), ensure_ascii=False, indent=2), encoding="utf-8")
        (d / "native_result_without_items.json").write_text(json.dumps(_safe_json({k:v for k,v in native.items() if k != 'items'}), ensure_ascii=False, indent=2), encoding="utf-8")
        (d / "random_items.json").write_text(json.dumps(_safe_json(items), ensure_ascii=False, indent=2), encoding="utf-8")
        # CSV is easier for ChatGPT/Python analysis and spreadsheet inspection.
        flat_keys = sorted({str(k) for item in items for k in item.keys()})
        with (d / "random_items.csv").open("w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=flat_keys)
            w.writeheader()
            for item in items:
                row = {}
                for k in flat_keys:
                    v = item.get(k)
                    if isinstance(v, (dict, list, tuple)):
                        row[k] = json.dumps(_safe_json(v), ensure_ascii=False)
                    else:
                        row[k] = _safe_json(v)
                w.writerow(row)
        # Snapshot current learning/stat tables where available. Failures should
        # never block Time Machine itself.
        for name, sql in {
            "time_machine_tests_snapshot.csv": "SELECT * FROM time_machine_tests ORDER BY created_at DESC LIMIT 50000",
            "time_machine_feature_snapshots.csv": "SELECT * FROM time_machine_feature_snapshots ORDER BY created_at DESC LIMIT 50000",
            "time_machine_signal_scores.csv": "SELECT * FROM time_machine_signal_scores ORDER BY total DESC, hitrate_with_partial DESC LIMIT 50000",
            "model_scores.csv": "SELECT * FROM model_scores ORDER BY horizon, total DESC",
            "adaptive_feature_weights.csv": "SELECT * FROM adaptive_feature_weights ORDER BY sample DESC, quality DESC",
            "data_health.csv": "SELECT * FROM data_health ORDER BY source",
            "raw_metric_points_recent.csv": "SELECT * FROM raw_metric_points ORDER BY timestamp_ms DESC LIMIT 20000",
            "features_recent_snapshot.csv": "SELECT * FROM features ORDER BY timestamp_ms DESC LIMIT 10000",
        }.items():
            try:
                frame = db.df(sql)
                frame.to_csv(d / name, index=False)
            except Exception as exc:
                (d / (name + ".error.txt")).write_text(str(exc), encoding="utf-8")
        zip_path = self._zip_dir(d)
        latest = {**meta, "path": str(zip_path), "download_url": f"/api/time-machine/export/download?batch_id={batch_id}"}
        (self.root / "latest_random_export.json").write_text(json.dumps(_safe_json(latest), ensure_ascii=False, indent=2), encoding="utf-8")
        append_jsonl("time_machine_export_audit.jsonl", {"event":"tm_random_export_written_v101615", **latest})
        return latest

    def _zip_dir(self, d: Path) -> Path:
        out = d.with_suffix(".zip")
        tmp = out.with_suffix(".zip.tmp")
        with zipfile.ZipFile(tmp, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
            for p in sorted(d.rglob("*")):
                if p.is_file():
                    zf.write(p, p.relative_to(d.parent))
        tmp.replace(out)
        return out

    def latest_info(self) -> dict:
        p = self.root / "latest_random_export.json"
        if p.exists():
            try:
                return json.loads(p.read_text(encoding="utf-8"))
            except Exception:
                pass
        zips = sorted(self.root.glob("*.zip"), key=lambda q: q.stat().st_mtime if q.exists() else 0, reverse=True)
        if not zips:
            return {"exists": False, "root": str(self.root)}
        batch_id = zips[0].stem
        return {"exists": True, "batch_id": batch_id, "path": str(zips[0]), "download_url": f"/api/time-machine/export/download?batch_id={batch_id}"}

    def export_path(self, batch_id: str | None = None) -> Path | None:
        if batch_id:
            p = self.root / f"{batch_id}.zip"
            return p if p.exists() else None
        info = self.latest_info()
        p = Path(info.get("path", "")) if info.get("path") else None
        return p if p and p.exists() else None
