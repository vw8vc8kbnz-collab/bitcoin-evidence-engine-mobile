# Configurator Studio v1.2 — Reliable Configurator Core

v1.1 combineert de UX-cleanup met de eerste echte Engine Foundation.

## Wat is nieuw

### UX
- Paywall-overlay volledig verwijderd.
- Plus/foto/3D-knoppen openen geen plannen-overlay meer.
- Sandbox-kliks tonen alleen een subtiele toast en scrollen naar pricing.
- Customer-facing UI noemt geen interne AI/provider/architectuur.
- Nieuwe Builder Foundation:
  - klikbaar 3D-model
  - smooth context action menu
  - koppel onderdeel
  - voeg materiaal/textuur toe
  - voeg maatoptie toe
  - voeg variant/zichtbaarheid toe
  - voeg prijsregel toe
  - voeg regel/waarschuwing toe
  - koppel orderdata
  - simuleer niet-configureerbaar model

### Engine Foundation
- Truth Graph v2
- AI-candidates zijn nooit confirmed facts.
- Confirmed betekent user/admin/measured/import verified.
- Boolean critical-field gates, geen pseudo readiness score als beslissing.
- Conflict resolution contract.
- Mesh inventory + Segmentation/Configurability Gate.
- Pricing Engine als enige prijsbron.
- Rule Engine mag pricing rules enable/disable, maar geen directe prijs toevoegen.
- Job + credit ledger schemas met failure taxonomy.
- Immutable runtime snapshot schema.
- Publish gate schema.
- Engine smoke tests.

## Belangrijke strategie

v1.1 is bewust GLB/configurator-core first. Echte foto-naar-3D generatie zit niet in deze versie. Dat voorkomt dat gegenereerde modellen als exact/configureerbaar worden behandeld voordat de betrouwbare kern staat.


## v1.1.1 mobile fix

- Builder modal gebruikt nu een flex layout met echte `100dvh` mobiele scroll.
- `.builder-shell` is de enige mobiele scrollcontainer met `-webkit-overflow-scrolling: touch`.
- 3D-preview is compacter op iPhone.
- Productblokken, inspector en publish checks staan onder elkaar en blijven bereikbaar.
- Contextmenu gedraagt zich op mobiel als bottom sheet.
- Paywall-overlay blijft verwijderd.


## v1.2 Builder State Engine

- Contextmenu-acties bouwen nu live de no-code blueprint-state op.
- Link part, material, dimension, variant, pricing, rule en orderdata hebben zichtbare effecten.
- Tabs Parts / Options / Pricing / Rules schakelen nu echt tussen builder-state.
- Pricing breakdown wordt dynamisch opgebouwd uit pricing rules.
- Publish checklist reageert op blueprint-state.
- Inspector heeft label-input, blok toevoegen en JSON-preview.
- Nieuwe engine helper: `createBuilderDraft`.
- Engine smoke-test uitgebreid met builder draft validatie.
