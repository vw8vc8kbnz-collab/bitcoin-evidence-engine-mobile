# BEE Trader's Read

Een multi-timeframe chart-analyse die de markt leest zoals een ervaren trader:
live BTC-chart + per timeframe (1D / 4H / 1H) een oordeel over trend, structuur,
VWAP, RSI, niveaus en break-of-structure, met een samenvattend verdict.

Bedoeld om NAAST je paper-engine signalen te leggen. Geen prijspercentage (dat
signaal bestaat niet betrouwbaar) — wel een onderbouwd trader-oordeel met de
niveaus die ertoe doen. Waar een gevalideerde engine vuurt, toont hij de echte
winrate.

## Installeren (na uitpakken via GitHub/Termius)
```
cd /home/ubuntu/bitcoin-engine-deploy/current
chmod +x tradersread/scripts/install_tradersread.sh
./tradersread/scripts/install_tradersread.sh
```
Kies een wachtwoord (alleen letters/cijfers). Open daarna:
```
http://<vps-ip>:8200/?key=<sleutel>
```

## Draait naast de rest
Eigen service (tradersread.service), eigen poort (8200). Raakt daemon, Alpha Lab
(8000) en MomentScope (8100) niet aan. Poort 8200 moet open bij je VPS-provider.

## Let op
De live chart komt van Binance's publieke API (puur visueel). De analyse komt
van je eigen engine-data. Twee bronnen, dat is normaal en geen probleem.
