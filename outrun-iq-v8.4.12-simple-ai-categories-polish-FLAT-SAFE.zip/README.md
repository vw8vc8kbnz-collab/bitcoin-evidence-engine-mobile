# Outrun IQ v8.4.12 — Simple AI & Categories Polish

Flat-safe Next.js build voor Outrun IQ.

Deze versie maakt de koperkant rustiger en logischer:
- Home zonder grote AI-uitlegkaart.
- AI Vinder compacter en simpeler.
- Categorieën-tab is nu een echte categoriehub.

Deployment blijft hetzelfde als eerdere flat-safe builds: ZIP uitpakken in `/var/www/outrun-iq-v5`, `.env`, `data`, `runtime_uploads`, `public/uploads`, `node_modules` en `.next` bewaren/uitsluiten bij rsync, daarna `npm install`, `npm run build`, `pm2 restart outrun-iq --update-env`.
