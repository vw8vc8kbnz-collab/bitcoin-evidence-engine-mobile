# Outrun IQ v8.4.12 — Simple AI & Categories Polish

Correctiebuild bovenop v8.4.11.

## Gefixt / verbeterd
- Grote AI Brain-kaart op Home verwijderd; Home opent nu rustiger direct met discovery/productcontent.
- AI Vinder-hero compacter gemaakt: minder tekst, duidelijke vraag en kleinere uitleg.
- Categorie-tab is nu een echte categoriepagina wanneer je via de onderbalk op Categorieën tikt.
- Nieuwe categoriekaarten toegevoegd voor Witgoed, Meubels, Keukens, Tuin en Overig.
- Categoriepagina houdt nog steeds AI-ranking beschikbaar, maar de eerste laag voelt nu als navigatie i.p.v. zoekresultatenlijst.
- AI-uitlegteksten korter en minder dominant gemaakt.

## Niet veranderd
- v8.4.11 account wisselen / business logout blijft intact.
- v8.4.10 echte logo/app-icon basis blijft intact.
- v8.4.9 image/navigation fixes blijven intact.
- Wallet/finance hardening blijft intact.
- Payment live blijft geblokkeerd totdat expliciet veilig vrijgegeven.
