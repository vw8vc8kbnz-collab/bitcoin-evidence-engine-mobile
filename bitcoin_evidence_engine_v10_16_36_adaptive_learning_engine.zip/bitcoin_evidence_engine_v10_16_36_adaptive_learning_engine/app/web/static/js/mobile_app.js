const $ = (id)=>document.getElementById(id);
// V10.16.32: Safari-safe debug export + honest Data/Model cockpit + Time Machine progress. First paint is instant; quick heartbeat loads first; heavy evidence/chart load later.
function authHeaders(){ return {}; }
const fmtUsd = (v)=> v==null || isNaN(v) ? '—' : '$' + Number(v).toLocaleString('nl-NL',{maximumFractionDigits:0});
const fmtPct = (v)=> v==null || isNaN(v) ? '—' : (Number(v)*100).toFixed(1)+'%';
const fmtTs = (ms)=> ms ? new Date(Number(ms)).toLocaleDateString('nl-NL',{day:'2-digit',month:'2-digit',year:'2-digit'}) : '—';
let installPrompt=null;
window.addEventListener('beforeinstallprompt', (e)=>{ e.preventDefault(); installPrompt=e; $('installBtn').hidden=false; });
function toast(msg){ const t=$('toast'); if(!t) return; t.textContent=msg; t.hidden=false; clearTimeout(window.__toastTimer); window.__toastTimer=setTimeout(()=>t.hidden=true,3600); }
function hideBoot(){ const b=document.getElementById('bootSplash'); if(b){ b.classList.add('hide'); setTimeout(()=>{ try{b.remove()}catch(e){} },350); } }
function safeSet(id, value){ const el=$(id); if(el) el.textContent=value; }
function cacheSet(k,v){ try{ localStorage.setItem(k, JSON.stringify({t:Date.now(), v})); }catch(e){} }
function cacheGet(k,maxAgeMs=86400000){ try{ const o=JSON.parse(localStorage.getItem(k)||'null'); if(o&&Date.now()-o.t<maxAgeMs) return o.v; }catch(e){} return null; }
function applyQuick(data){
  if(!data) return;
  cacheSet('bee_last_quick', data);
  setApi(data.sync_busy?'loading':'ok', data.sync_busy?'bezig':'online');
  safeSet('versionLabel', data.engine_version||'v10.16.36-adaptive-learning-engine');
  safeSet('priceLabel', fmtUsd(data.btc_price));
  const rows=Number(data.raw_candles || (data.candle_range&&data.candle_range.rows) || 0); const target=Number(data.target_rows||70000);
  const pct=Math.min(100, target?rows/target*100:0);
  safeSet('historyPct', pct.toFixed(1)+'%'); safeSet('historyRows', `${rows.toLocaleString('nl-NL')} / ${target.toLocaleString('nl-NL')} candles`); if($('historyBar')) $('historyBar').style.width=pct+'%';
  safeSet('nativeState', (data.native_available||data.native_core_available)?'Actief':'Check'); safeSet('nativeDetail', (data.native_available||data.native_core_available)?'C++ cloud core OK':'C++ check loopt');
  const tm=data.learning||{}; safeSet('tmTests', Number(tm.time_machine_tests||data.time_machine_tests||0).toLocaleString('nl-NL')); safeSet('tmSnapshots', Number(tm.feature_snapshots||data.time_machine_feature_snapshots||0).toLocaleString('nl-NL')); safeSet('tmSignals', Number(tm.signal_events||data.time_machine_signal_scores||0).toLocaleString('nl-NL'));
  safeSet('dataRows', rows.toLocaleString('nl-NL'));
  if(data.raw_candles_min_ms || data.raw_candles_max_ms){ safeSet('dataRange', `${fmtTs(data.raw_candles_min_ms)} → ${fmtTs(data.raw_candles_max_ms)}`); }
  hideBoot();
}

async function api(path, opts={}){
  const attempts=opts.attempts||1; let lastErr=null;
  for(let a=0;a<attempts;a++){
    const useTimeout=opts.timeout!==0; const ctrl=useTimeout?new AbortController():null; const to=useTimeout?setTimeout(()=>ctrl.abort(), opts.timeout||45000):null;
    try{
      const clean={...opts}; delete clean.timeout; delete clean.attempts;
      const r=await fetch(path,{...clean, signal:ctrl?ctrl.signal:undefined, headers:{'Content-Type':'application/json',...authHeaders(),...(opts.headers||{})}, cache:'no-store'});
      if(!r.ok) throw new Error('HTTP '+r.status);
      return await r.json();
    }catch(e){ lastErr=e; if(a<attempts-1) await new Promise(r=>setTimeout(r, 1200*(a+1))); }
    finally{ if(to) clearTimeout(to); }
  }
  throw lastErr || new Error('request failed');
}
function setApi(state,msg){ const dot=$('apiDot'); dot.className='status-dot '+state; $('apiLabel').textContent=msg; }
function drawChart(points){ const c=$('priceChart'); if(!c) return; const dpr=window.devicePixelRatio||1; const rect=c.getBoundingClientRect(); c.width=Math.max(300,Math.floor(rect.width*dpr)); c.height=Math.floor(190*dpr); const ctx=c.getContext('2d'); ctx.scale(dpr,dpr); ctx.clearRect(0,0,rect.width,190); const arr=(points||[]).map(p=>({x:p.time||p.timestamp_ms||p.t, y:Number(p.close ?? p.c ?? p.value)})).filter(p=>isFinite(p.y)); if(arr.length<2){ ctx.fillStyle='rgba(220,235,255,.55)'; ctx.font='13px -apple-system'; ctx.fillText('Chart wordt geladen…',14,28); return; } const ys=arr.map(p=>p.y); const min=Math.min(...ys), max=Math.max(...ys); const pad=12, w=rect.width-pad*2, h=166; const sx=(i)=>pad+(i/(arr.length-1))*w; const sy=(y)=>pad+(1-(y-min)/(max-min||1))*h; const grad=ctx.createLinearGradient(0,0,0,190); grad.addColorStop(0,'rgba(24,210,255,.25)'); grad.addColorStop(1,'rgba(24,210,255,0)'); ctx.beginPath(); arr.forEach((p,i)=>{ const x=sx(i), y=sy(p.y); i?ctx.lineTo(x,y):ctx.moveTo(x,y); }); ctx.lineTo(pad+w,188); ctx.lineTo(pad,188); ctx.closePath(); ctx.fillStyle=grad; ctx.fill(); ctx.beginPath(); arr.forEach((p,i)=>{ const x=sx(i), y=sy(p.y); i?ctx.lineTo(x,y):ctx.moveTo(x,y); }); ctx.lineWidth=2; ctx.strokeStyle='#18d2ff'; ctx.stroke(); ctx.fillStyle='rgba(237,245,255,.72)'; ctx.font='11px -apple-system'; ctx.fillText(fmtUsd(max), pad, 16); ctx.fillText(fmtUsd(min), pad, 184); }
function forecastCard(item){ const bull=Number(item.bullish_probability ?? 0); const bear=Number(item.bearish_probability ?? 0); const dir=bull>=bear?'UP bias':'DOWN bias'; const move=Number(item.expected_move_pct ?? 0); const cls=bull>=bear?'good':'danger'; return `<div class="forecast-row"><div class="h">${item.horizon||'—'}</div><div><div class="dir ${cls}">${dir} · ${(move*100).toFixed(2)}%</div><div class="sub">Target ${fmtUsd(item.expected_price)} · invalidatie ${fmtUsd(item.invalidation_price)}</div></div><div class="conf">${Math.round(Number(item.confidence||0)*100)}%</div></div>`; }
function accuracyRow(row){ const hit = row.hitrate==null ? '—' : (Number(row.hitrate)*100).toFixed(1)+'%'; return `<div class="accuracy-row"><div><b>${row.horizon}</b><br><span>${row.total||0} samples · score ${row.avg_score==null?'—':Number(row.avg_score).toFixed(1)}</span></div><b>${hit}</b></div>`; }
function syncStateLabel(states){ if(!Array.isArray(states)||!states.length) return '—'; const preferred=['historical_memory','sync_phase','startup_sync_status','manual_sync_status','external_evidence_backfill']; for(const k of preferred){ const hit=states.find(s=>s.key===k); if(hit) return `${hit.key}: ${hit.value}`; } return `${states[0].key}: ${states[0].value}`; }

function dataStatusLabel(s){ return s==='active'?'actief':(s==='partial'?'deels':'mist'); }
function renderExternalData(ed){
  const box=$('externalDataList'); if(!box) return;
  const rows=(ed&&ed.rows)||[];
  const sum=(ed&&ed.summary)||{};
  const f=(ed&&ed.features)||{};
  $('externalDataSummary') && ($('externalDataSummary').textContent=`${sum.active||0} actief · ${sum.partial||0} deels · ${sum.missing||0} mist`);
  box.innerHTML = rows.map(r=>`<div><span>${r.label}</span><b>${Number(r.rows||0).toLocaleString('nl-NL')} · ${dataStatusLabel(r.status)}</b></div>`).join('') || '<p class="hint">Nog geen externe datasources gemeten.</p>';
  const fb=$('featureEvidenceSummary'); if(fb){ fb.innerHTML = `<div><span>Feature rows</span><b>${Number(f.feature_rows||0).toLocaleString('nl-NL')}</b></div><div><span>Funding/OI rows</span><b>${Number(f.funding_rate_rows||0).toLocaleString('nl-NL')} / ${Number(f.open_interest_rows||0).toLocaleString('nl-NL')}</b></div><div><span>Orderflow rows</span><b>${Number(f.taker_rows||0).toLocaleString('nl-NL')}</b></div><div><span>Sentiment/on-chain</span><b>${Number(f.fear_greed_rows||0).toLocaleString('nl-NL')} / ${Number(f.mvrv_rows||0).toLocaleString('nl-NL')}</b></div>`; }
  renderProviderCockpit(rows);
}
function renderProviderCockpit(rows){
  const box=$('providerCockpit'); if(!box) return;
  const groups={}; (rows||[]).forEach(r=>{ const g=r.group||r.source||'overig'; groups[g]=groups[g]||{rows:0,active:0,partial:0,missing:0}; groups[g].rows+=Number(r.rows||0); groups[g][r.status==='active'?'active':(r.status==='partial'?'partial':'missing')]++; });
  const labels={core_price:'Binance Spot', futures:'Futures', orderflow:'Orderflow', orderbook:'Orderbook', sentiment:'Sentiment', cross_exchange:'Exchanges', onchain:'On-chain'};
  const html=Object.keys(groups).sort().map(k=>{ const g=groups[k]; const status=g.active?'active':(g.partial?'proxy':'missing'); return `<div class="data-pill"><span>${labels[k]||k}</span><b>${Number(g.rows||0).toLocaleString('nl-NL')}</b><small>${g.active} actief · ${g.partial} deels · ${g.missing} mist</small></div>`; }).join('');
  box.innerHTML = html || '<p class="hint">Providerstatus wordt geladen…</p>';
  $('providerSummary') && ($('providerSummary').textContent = Object.keys(groups).length ? `${Object.keys(groups).length} groepen` : 'geen data');
}
function renderModelStatus(ms){
  const box=$('modelCockpit'); if(!box) return;
  const rows=(ms&&ms.rows)||[]; const sum=(ms&&ms.summary)||{};
  $('modelSummary') && ($('modelSummary').textContent=`${sum.active||0} actief · ${sum.proxy||0} proxy · ${sum.missing||0} mist`);
  box.innerHTML = rows.map(m=>{ const cls=m.status==='active'?'active':(m.status==='proxy'?'proxy':(m.status==='partial'||m.status==='live_only'?'proxy':'missing')); const txt=m.status==='active'?'ACTIEF':(m.status==='partial'?'DEELS':(m.status==='live_only'?'LIVE':(m.status==='proxy'?'PROXY':'MIST'))); return `<div class="model-row"><div><b>${m.name||m.id}</b><span>${m.id} · ${m.group||'model'} · ${m.source||''} · ${Number(m.rows||0).toLocaleString('nl-NL')} rows</span></div><em class="badge ${cls}">${txt}</em></div>`; }).join('') || '<p class="hint">Modelstatus wordt geladen…</p>';
}

function renderAdaptiveLearning(ad){
  const box=$('adaptiveLearningBox'); if(!box) return;
  const sum=(ad&&ad.summary)||{};
  const fw=(ad&&ad.feature_weights)||[];
  const mw=(ad&&ad.model_weights)||[];
  $('adaptiveSummary') && ($('adaptiveSummary').textContent=`${sum.feature_dimensions||0} features · ${sum.model_dimensions||0} modelgewichten`);
  const topF=fw.slice(0,8).map(r=>`<div class="model-row"><div><b>${r.dimension||'feature'}</b><span>weight ${Number(r.weight||0).toFixed(3)} · sample ${Number(r.sample||0).toLocaleString('nl-NL')} · quality ${Number(r.quality||0).toFixed(3)}</span></div><em class="badge active">LEERT</em></div>`);
  const topM=mw.slice(0,6).map(r=>`<div class="model-row"><div><b>${r.model_id||'model'} · ${r.horizon||''}</b><span>weight ${Number(r.weight||0).toFixed(3)} · hitrate ${(Number(r.hitrate||0)*100).toFixed(1)}% · sample ${Number(r.sample||0).toLocaleString('nl-NL')}</span></div><em class="badge proxy">DARWIN</em></div>`);
  box.innerHTML = [...topF, ...topM].join('') || '<p class="hint">Nog geen adaptive weights. Draai Random1000 en wacht tot export klaar is.</p>';
}

async function loadAdaptiveLearning(){
  try{ const ad=await api('/api/adaptive-learning/status',{timeout:9000,attempts:1}); if(ad&&ad.ok) renderAdaptiveLearning(ad); }catch(_){ }
}


function statusWord(st){
  if(st==='active'||st==='done'||st==='complete'||st==='current') return 'klaar';
  if(st==='provider_limited_current') return 'provider-limiet · klaar';
  if(st==='provider_limited') return 'provider-limiet';
  if(st==='gap_repair_needed') return 'gap-repair';
  if(st==='stuck') return 'vast';
  if(st==='error') return 'fout';
  if(st==='partial'||st==='loading') return 'laden';
  if(st==='api_key_needed') return 'API-key';
  if(st==='missing') return 'mist';
  return st||'—';
}
function setBootProgressPayload(p){
  if(!p||!p.ok) return;
  const pct=Math.max(0,Math.min(100,Number(p.overall_pct||0)));
  safeSet('bootProgressPct', Math.round(pct)+'%');
  safeSet('bootProgressTitle', pct>=99?'Tool klaar':'Tool laadt op achtergrond');
  if($('bootProgressBar')) $('bootProgressBar').style.width=pct+'%';
  const steps=p.boot_steps||[];
  const stepBox=$('bootStepList');
  if(stepBox){ stepBox.innerHTML=steps.map(x=>`<div><span>${x.label||x.key}</span><b>${Math.round(Number(x.pct||0))}%</b><em>${statusWord(x.status)}${x.detail?' · '+x.detail:''}</em></div>`).join('') || '<div><span>Status</span><b>—</b></div>'; }
  const ex=p.external||{}; const epct=Math.max(0,Math.min(100,Number(ex.overall_pct||0)));
  safeSet('liveDataProgressPct', Math.round(epct)+'%');
  if($('liveDataProgressBar')) $('liveDataProgressBar').style.width=epct+'%';
  if($('liveDataProgressDetail')) $('liveDataProgressDetail').textContent = `Externe evidence warehouse: ${Math.round(epct)}% indicatief · ${p.phase||'idle'}`;
  const list=$('providerProgressList');
  if(list){
    const providers=(ex.providers||[]).slice(0,14);
    list.innerHTML = providers.map(r=>{ const rp=Math.max(0,Math.min(100,Number(r.coverage_pct||0))); return `<div class="provider-progress-row"><div class="r1"><b>${r.label}</b><span>${Number(r.rows||0).toLocaleString('nl-NL')} / ${Number(r.target_rows||0).toLocaleString('nl-NL')} · ${statusWord(r.status)}</span></div><div class="mini"><i style="width:${rp}%"></i></div><small>${r.source||''} · ${r.metric||''}</small></div>`; }).join('') || '<p class="hint">Providerstatus wordt geladen…</p>';
  }
}
async function loadBackgroundProgress(){
  try{ const p=await api('/api/mobile/live-progress',{timeout:5000,attempts:1}); setBootProgressPayload(p); }
  catch(_){ /* never block UI */ }
}

function healthToMobile(data){
  return {
    ok: !!data.ok, engine_version: data.engine_version, api_status:'ok', sync_busy:false,
    btc_price:null, history:data.history||{}, native:data.native_core||data.native||{},
    learning:{time_machine_tests:data.time_machine_tests||0,time_machine_batches:data.time_machine_batches||0,feature_snapshots:data.time_machine_feature_snapshots||0,signal_events:data.time_machine_signal_scores||0},
    candle_range:{from_ms:data.raw_candles_min_ms,to_ms:data.raw_candles_max_ms,rows:data.raw_candles||0},
    latest_items:[], accuracy:[], sync_state:[]
  };
}
async function loadEvidenceStatus(){
  try{ const e=await api('/api/mobile/evidence-status',{timeout:12000,attempts:1}); if(e&&e.ok){ renderExternalData(e.external_data); renderModelStatus(e.model_status); }
    loadAdaptiveLearning(); }catch(_){ /* evidence status is optional */ }
}
async function loadSummary(){
  try{
    let data;
    try{ data=await api('/api/mobile/status-fast',{timeout:8000,attempts:1}); }
    catch(_){
      try{ data=await api('/api/health',{timeout:5000,attempts:1}); data=healthToMobile(data); }
      catch(__){ data=await api('/api/mobile/summary',{timeout:12000,attempts:1}); }
    }
    if(!data.ok) throw new Error(data.error||'summary error');
    setApi(data.sync_busy?'loading':'ok', data.sync_busy?'bezig':'online');
    $('versionLabel').textContent=data.engine_version||'Cloud Mobile App';
    $('priceLabel').textContent=fmtUsd(data.btc_price);
    const hist=data.history||{}; const cr=data.candle_range||{};
    const rows=Number(hist.stored_rows ?? hist.rows ?? cr.rows ?? 0); const target=Number(hist.target_rows ?? 70000);
    const pct=Math.min(100, target? rows/target*100:0);
    $('historyPct').textContent=pct.toFixed(1)+'%'; $('historyRows').textContent=`${rows.toLocaleString('nl-NL')} / ${target.toLocaleString('nl-NL')} candles`; $('historyBar').style.width=pct+'%';
    $('nativeState').textContent=(data.native&&data.native.available)?'Actief':'Mist'; $('nativeDetail').textContent=(data.native&&data.native.available)?'C++ cloud core OK':'C++ core ontbreekt';
    const items=data.latest_items||[];
    if($('forecastCount')) $('forecastCount').textContent=items.length?`${items.length} items`:'geen run';
    if($('forecastCards')) $('forecastCards').innerHTML=items.slice(0,4).map(forecastCard).join('') || '<p class="hint">Nog geen forecast. Tik Sync + Forecast.</p>';
    if($('forecastFull')) $('forecastFull').innerHTML=items.map(forecastCard).join('') || '<p class="hint">Forecast wordt via stabiele status niet zwaar geladen; tik Sync + Forecast of ververs later.</p>';
    const learn=data.learning||{};
    $('tmTests').textContent=(learn.time_machine_tests||0).toLocaleString('nl-NL'); $('tmSnapshots').textContent=(learn.feature_snapshots||0).toLocaleString('nl-NL'); $('tmSignals').textContent=(learn.signal_events||0).toLocaleString('nl-NL');
    if($('accuracyList')) $('accuracyList').innerHTML=(data.accuracy||[]).map(accuracyRow).join('') || '<p class="hint">Nog geen accuracy samples.</p>';
    $('dataRows').textContent=((data.candle_range||{}).rows||0).toLocaleString('nl-NL'); $('dataRange').textContent=`${fmtTs((data.candle_range||{}).from_ms)} → ${fmtTs((data.candle_range||{}).to_ms)}`; $('syncStateLabel').textContent=syncStateLabel(data.sync_state);
    renderExternalData(data.external_data);
    cacheSet('bee_last_summary', data);
    window.__summaryErrorShown=false;
  }catch(err){
    // Quiet retry: the server may be doing external backfill or Random1000. Do not spam the UI red every 6 seconds.
    setApi('loading','herladen');
    if(!window.__summaryErrorShown){ toast('Status wordt op de achtergrond bijgewerkt; ik probeer automatisch opnieuw.'); window.__summaryErrorShown=true; }
  }
}
async function loadChart(){ try{ const data=await api('/api/mobile/chart?limit=240',{timeout:8000,attempts:1}); drawChart(data.points || data.items || data.candles || []); }catch(err){ drawChart([]); } }
async function postAction(path,label){ toast(label+' gestart…'); setApi('loading','bezig'); await loadBackgroundProgress(); try{ const res=await api(path,{method:'POST',body:'{}',timeout:0}); toast(res.message || res.reason || label+' OK'); await loadSummary(); await loadBackgroundProgress(); }catch(err){ toast(label+' draait mogelijk nog; status blijft live zichtbaar.'); await loadBackgroundProgress(); } }
document.querySelectorAll('.bottom-tabs button').forEach(btn=>btn.addEventListener('click',()=>{ document.querySelectorAll('.bottom-tabs button').forEach(b=>b.classList.remove('active')); btn.classList.add('active'); const target=btn.dataset.target; document.querySelectorAll('.mobile-page').forEach(p=>p.classList.toggle('active',p.dataset.page===target)); window.scrollTo({top:0,behavior:'smooth'}); }));
$('installBtn').addEventListener('click', async()=>{ if(installPrompt){ installPrompt.prompt(); await installPrompt.userChoice; installPrompt=null; } else { toast('iPhone: open Delen → Zet op beginscherm.'); } });
$('syncBtn').addEventListener('click',()=>postAction('/api/sync/background','Sync + Forecast'));
$('historyBtn').addEventListener('click',()=>postAction('/api/historical-memory/backfill?mode=daemon','History check'));

let tmProgressTimer=null;
let tmProgressLocal=0;
function setTmProgress(visible, title, pct, detail){
  const card=$('tmProgressCard'); if(!card) return;
  card.hidden=!visible;
  if(title) safeSet('tmProgressTitle', title);
  if(pct!=null){ const p=Math.max(0,Math.min(100,Number(pct)||0)); safeSet('tmProgressPct', Math.round(p)+'%'); if($('tmProgressBar')) $('tmProgressBar').style.width=p+'%'; }
  if(detail) $('tmProgressDetail').innerHTML=detail;
}
function stopTmProgressTimer(){ if(tmProgressTimer){ clearInterval(tmProgressTimer); tmProgressTimer=null; } }
function startLocalProgress(n){
  stopTmProgressTimer(); tmProgressLocal=2; const start=Date.now();
  setTmProgress(true, 'Random'+n+' wordt gestart…', tmProgressLocal, 'Native core rekent de random punten. Eerste fase kan ±30 sec duren.');
  tmProgressTimer=setInterval(()=>{ const elapsed=(Date.now()-start)/1000; const cap=n>=1000?72:82; tmProgressLocal=Math.min(cap, 5 + elapsed*(n>=1000?1.7:4.0)); setTmProgress(true, 'Random'+n+' bezig…', tmProgressLocal, `Native core + warehouse bezig · ±${Math.round(elapsed)} sec verstreken`); },1000);
}
function progressFromStatus(st, n, beforeTests){
  const expected=Number(st.expected_tests||n*7||0);
  // Also accept /api/mobile/live-progress payload shape.
  if(st && st.time_machine && !st.cumulative){ st={...st.time_machine, cumulative:{tests:st.time_machine.tests, feature_snapshots:st.time_machine.snapshots, signal_scores:st.time_machine.signals}, phase:(st.time_machine.current_job_parsed&&st.time_machine.current_job_parsed.phase)||'processing'}; }
  const cumulative=st&&st.cumulative||{};
  const tests=Number(st.tests_written||cumulative.tests||0);
  const snap=Number(st.snapshots_written||cumulative.feature_snapshots||0);
  const sig=Number(st.signals_written||cumulative.signal_scores||0);
  let pct=Number(st.progress_pct||0);
  if(!pct){
    pct=Math.min(98, Math.max(tmProgressLocal||0, (tests/Math.max(1,expected))*70 + Math.min(20,(snap/Math.max(1,expected))*20) + (sig>0?6:0)));
  }
  const phase=st.phase||st.status||'processing';
  const label=(st.status==='completed'||phase==='export_ready')?'klaar':phase;
  setTmProgress(true, `Random${n}: ${label}`, pct, `<b>${tests.toLocaleString('nl-NL')} / ${expected.toLocaleString('nl-NL')}</b> horizon-tests · snapshots ${snap.toLocaleString('nl-NL')} · signals ${sig.toLocaleString('nl-NL')}${st.download_url?' · export klaar':''}${st.error?' · fout: '+st.error:''}`);
}
async function runRandomBatch(n){
  toast('Random'+n+' gestart. Je ziet nu live voortgang onder de knoppen.');
  let jobId=null;
  let beforeTests=0;
  try{ const s=await api('/api/mobile/status-fast',{timeout:6000}); beforeTests=Number(((s.learning||{}).time_machine_tests)||0); }catch(_){ }
  startLocalProgress(n);
  try{
    const res=await api('/api/time-machine/random-tests/background',{method:'POST',body:JSON.stringify({count:n}),timeout:8000,attempts:1});
    jobId=res.job_id||res.batch_id||null;
    setTmProgress(true, 'Random'+n+' gestart', 8, 'Backend draait nu door op de VPS. Status wordt uit DuckDB job-truth gelezen.');
    toast(res.message || ('Random'+n+' gestart'));
  }catch(err){
    stopTmProgressTimer();
    setTmProgress(true, 'Random'+n+' status controleren…', Math.max(35,tmProgressLocal||35), 'Start-call kreeg geen directe response. Ik controleer de laatst bekende VPS-job.');
    toast('Random'+n+' draait mogelijk nog; ik blijf status controleren…');
  }
  for(let i=0;i<240;i++){
    await new Promise(r=>setTimeout(r,2500));
    try{
      const path='/api/time-machine/random-status'+(jobId?('?job_id='+encodeURIComponent(jobId)):'' );
      const st=await api(path,{timeout:6000,attempts:1});
      progressFromStatus(st,n,beforeTests);
      await loadSummary();
      const expected=Number(st.expected_tests||n*7||0);
      const tests=Number(st.tests_written||((st.cumulative||{}).tests)||0);
      const snapshots=Number(st.snapshots_written||((st.cumulative||{}).feature_snapshots)||0);
      if(st.status==='error'){ stopTmProgressTimer(); setTmProgress(true,'Random'+n+' fout',100,st.error||'Backend gaf een fout terug. Maak debug export.'); toast('Random'+n+' fout. Maak debug export.'); return; }
      if(st.status==='completed' || st.phase==='export_ready' || (expected && tests>=expected && snapshots>=expected)){
        stopTmProgressTimer();
        setTmProgress(true,'Random'+n+' klaar',100,`Volledig opgeslagen: ${tests.toLocaleString('nl-NL')} tests, ${snapshots.toLocaleString('nl-NL')} snapshots, export klaar.`);
        toast('Random'+n+' volledig opgeslagen. Download ZIP is klaar.');
        await loadSummary();
        setTimeout(()=>setTmProgress(false),12000);
        return;
      }
    }catch(_){ /* keep polling */ }
  }
  stopTmProgressTimer();
  setTmProgress(true,'Statuscheck gestopt',96,'De backend kan nog draaien. Open Data → Debug Export als dit blijft staan.');
}
$('random100Btn')?.addEventListener('click',()=>runRandomBatch(100));
$('random1000Btn')?.addEventListener('click',()=>runRandomBatch(1000));
$('tmExportBtn')?.addEventListener('click',async()=>{
  try{
    toast('Time Machine ZIP zoeken…');
    const info=await api('/api/time-machine/export/latest',{timeout:8000,attempts:1});
    const url=(info&&info.download_url)||'/api/time-machine/export/download';
    window.location.href=url+(url.includes('?')?'&':'?')+'ts='+Date.now();
  }catch(err){
    window.location.href='/api/time-machine/export/download?ts='+Date.now();
  }
});
$('tmResetBtn')?.addEventListener('click',async()=>{ if(!confirm('Time Machine warehouse wissen? Dit wist tests/snapshots/signals, maar NIET de 70.000 candles.')) return; toast('Time Machine reset…'); try{ const res=await api('/api/time-machine/reset',{method:'POST',body:JSON.stringify({delete_exports:false}),timeout:60000}); toast(res.ok?'Time Machine warehouse geleegd':'Reset fout'); await loadSummary(); }catch(err){ toast('Reset fout: '+err.message); }});
$('seedExportBtn').addEventListener('click',async()=>{ $('seedMsg').textContent='Export wordt gemaakt…'; try{ const res=await api('/api/seed-export/create',{method:'POST',body:'{}',timeout:60000}); $('seedMsg').textContent=res.path ? 'Seed ZIP klaar: '+res.path : (res.error||'klaar'); }catch(err){ $('seedMsg').textContent='Export fout: '+err.message; }});

$('adaptiveRebuildBtn')?.addEventListener('click', async ()=>{ const btn=$('adaptiveRebuildBtn'); const msg=$('adaptiveLearningMsg'); if(btn){btn.disabled=true;btn.textContent='Learning herberekenen…';} if(msg) msg.textContent='Adaptive Learning wordt opnieuw opgebouwd uit Time Machine resultaten.'; try{ const res=await api('/api/adaptive-learning/rebuild',{method:'POST',body:'{}',timeout:60000,attempts:1}); if(msg) msg.textContent=res.ok?`Learning klaar: ${res.feature_dimensions||0} features, ${res.model_dimensions||0} modelgewichten.`:'Learning fout'; await loadAdaptiveLearning(); }catch(err){ if(msg) msg.textContent='Learning fout: '+err.message; } finally{ if(btn){btn.disabled=false;btn.textContent='Herbereken Learning';} } });

$('debugExportBtn')?.addEventListener('click', async ()=>{
  const btn=$('debugExportBtn');
  const msg=$('debugExportMsg');
  const direct=$('debugExportDirectLink');
  if(btn){ btn.disabled=true; btn.textContent='Debug ZIP maken…'; }
  if(msg) msg.textContent='Debug ZIP wordt op de server gemaakt. Blijf op deze pagina; daarna start de download.';
  try{
    const res=await api('/api/debug/export/create',{method:'POST',body:'{}',timeout:120000,attempts:1});
    if(!res || res.ok===false) throw new Error((res&&res.error)||'export create failed');
    const url=(res.download_url||'/api/debug/export/download')+'?ts='+Date.now();
    if(direct){ direct.href=url; direct.style.display='block'; direct.textContent='Download klaar: tik hier als hij niet vanzelf start'; }
    if(msg) msg.textContent='Debug ZIP klaar. Download start nu. Als Safari niets downloadt: tik op de directe downloadknop onder deze tekst.';
    // iPhone/Safari opent window.open soms als lege about:blank. Daarom bewust dezelfde tab gebruiken.
    setTimeout(()=>{ window.location.href=url; }, 250);
  }catch(err){
    if(msg) msg.textContent='Debug export fout: '+err.message+' — probeer de directe downloadknop.';
    if(direct){ direct.href='/api/debug/export/download?ts='+Date.now(); direct.style.display='block'; direct.textContent='Probeer directe download alsnog'; }
    toast('Debug export fout: '+err.message);
  }finally{
    if(btn){ btn.disabled=false; btn.textContent='Maak Debug Export ZIP'; }
  }
});

async function loadQuick(){
  try{ const q=await api('/api/mobile/quick',{timeout:3500,attempts:1}); if(q&&q.ok) applyQuick(q); }
  catch(e){
    try{ const h=await api('/api/health',{timeout:4500,attempts:1}); applyQuick({ok:true, engine_version:h.engine_version, raw_candles:h.raw_candles, raw_candles_min_ms:h.raw_candles_min_ms, raw_candles_max_ms:h.raw_candles_max_ms, time_machine_tests:h.time_machine_tests, time_machine_feature_snapshots:h.time_machine_feature_snapshots, time_machine_signal_scores:h.time_machine_signal_scores, native_available:h.native_core&&h.native_core.available}); }
    catch(_){ setApi('loading','opstarten'); hideBoot(); }
  }
}
async function tick(){ await loadSummary(); }
try{ const cq=cacheGet('bee_last_quick'); if(cq) applyQuick(cq); const cs=cacheGet('bee_last_summary'); if(cs) { applyQuick(cs); } }catch(e){}
loadQuick(); setTimeout(loadBackgroundProgress, 150); setTimeout(loadSummary, 250); setTimeout(loadChart, 1200); setTimeout(loadEvidenceStatus, 2600); setTimeout(loadAdaptiveLearning, 3400);
setInterval(tick,15000); setInterval(loadBackgroundProgress,5000); setInterval(loadChart,90000); setInterval(loadEvidenceStatus,180000); setInterval(loadAdaptiveLearning,60000); window.addEventListener('resize',()=>setTimeout(loadChart,250));
if('serviceWorker' in navigator){ navigator.serviceWorker.register('/service-worker.js?v=10_16_36_adaptive_learning_engine').catch(()=>{}); }


// V10.16.27 VISUAL DATA COCKPIT OVERRIDES
function v27StatusClass(st){
  if(st==='active'||st==='done'||st==='complete'||st==='current'||st==='provider_limited_current') return 'active';
  if(st==='partial'||st==='loading'||st==='provider_limited'||st==='gap_repair_needed'||st==='stuck'||st==='error'||st==='live_only') return 'partial';
  if(st==='api_key_needed') return 'key';
  return 'missing';
}
function v27RenderProviderProgress(p){
  const list=$('providerProgressList');
  if(!list) return;
  const ex=(p&&p.external)||{};
  const providers=(ex.providers||[]).slice().sort((a,b)=>{
    const pr={'missing':0,'error':0,'stuck':0,'partial':1,'loading':1,'provider_limited':1,'gap_repair_needed':1,'live_only':1,'active':2,'complete':2,'current':2,'provider_limited_current':2,'api_key_needed':3};
    return (pr[a.status]||0)-(pr[b.status]||0) || String(a.label).localeCompare(String(b.label));
  });
  const pct=Number((ex.overall_pct!=null?ex.overall_pct:p.overall_pct)||0);
  safeSet('liveDataProgressPct', Math.round(Math.max(0,Math.min(100,pct)))+'%');
  if($('liveDataProgressBar')) $('liveDataProgressBar').style.width=Math.max(0,Math.min(100,pct))+'%';
  const busy=(p.sync_busy?' · forecast/sync bezig':'');
  const phase=p.phase&&p.phase!=='idle'?' · '+p.phase:'';
  if($('liveDataProgressDetail')) $('liveDataProgressDetail').innerHTML=`<b>Backfill live:</b> ${Math.round(pct)}% totaal${busy}${phase}<br><span>Alles wordt éénmalig in /home/ubuntu/bitcoin_evidence_data bewaard. Bij volgende start leest de app direct uit deze lokale DuckDB-cache.</span>`;
  list.innerHTML = providers.map(r=>{
    const rp=Math.max(0,Math.min(100,Number(r.coverage_pct||0)));
    const cls=v27StatusClass(r.status);
    const eta=r.eta_text||'';
    return `<div class="provider-progress-row ${cls}">
      <div class="r1"><b>${r.label}</b><em>${Math.round(rp)}%</em></div>
      <div class="mini"><i style="width:${rp}%"></i></div>
      <small>${Number(r.rows||0).toLocaleString('nl-NL')} / ${Number(r.target_rows||0).toLocaleString('nl-NL')} · ${statusWord(r.status)} · ${eta}</small>
    </div>`;
  }).join('') || '<p class="hint">Providerstatus wordt geladen…</p>';
}
const __oldSetBootProgressPayload = setBootProgressPayload;
setBootProgressPayload = function(p){
  try{ __oldSetBootProgressPayload(p); }catch(e){}
  try{ v27RenderProviderProgress(p); }catch(e){}
};
async function loadEvidenceStatus(){
  try{
    const e=await api('/api/mobile/evidence-status',{timeout:12000,attempts:1});
    if(e&&e.ok){ renderExternalData(e.external_data); renderModelStatus(e.model_status); }
    loadAdaptiveLearning();
  }catch(_){ }
  try{ const p=await api('/api/mobile/live-progress',{timeout:5000,attempts:1}); setBootProgressPayload(p); }catch(_){ }
}
