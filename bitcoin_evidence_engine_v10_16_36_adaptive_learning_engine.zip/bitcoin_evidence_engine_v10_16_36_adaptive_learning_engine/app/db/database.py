from __future__ import annotations
import duckdb
import threading
import shutil
from pathlib import Path
from app.core.config import settings
from app.core.debug import append_jsonl

class Database:
    """Small DuckDB wrapper.

    Important: DuckDB Python connections are not safe for simultaneous use
    across FastAPI request/background threads. V7.2 serializes every DB access
    through one RLock so dashboard polling cannot collide with sync/forecast
    writes. This fixes the intermittent DuckDB internal cast/result-closed
    errors that made the frontend show “Failed to fetch”.
    """
    def __init__(self, path: Path | None = None):
        self.path = path or settings.db_path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._migrate_existing_local_database_if_needed()
        self.lock = threading.RLock()
        self.conn = duckdb.connect(str(self.path))
        self.init_schema()

    def _migrate_existing_local_database_if_needed(self) -> None:
        """V10.15.5: preserve the 70k history across new ZIP versions.

        Older complete ZIP builds stored the DuckDB inside the extracted folder
        (`app/data`). Because Stijn receives every build as a fresh ZIP, that
        meant every new version could start with an empty database and download
        all 70k candles again. The launcher now points BEE_DATA_DIR to a shared
        LOCALAPPDATA folder. On the first run with that shared folder, copy the
        best existing database found in sibling Bitcoin Evidence Engine folders.
        """
        try:
            if self.path.exists() and self.path.stat().st_size > 1024 * 1024:
                return
            candidates: list[Path] = []
            # V10.16.2 Oracle Cloud Mobile: first prefer a shipped seed snapshot if present.
            # This lets Replit/VPS builds boot with the 70k historical memory immediately
            # after Stijn exports and sends the seed ZIP. If no seed exists, the normal
            # online Binance backfill still completes the history automatically.
            for seed_rel in (
                "seed_data/data/bitcoin_evidence_engine.duckdb",
                "seed_data/bitcoin_evidence_engine.duckdb",
                "app/seed_data/data/bitcoin_evidence_engine.duckdb",
            ):
                seed_db = settings.base_dir / seed_rel
                if seed_db.exists() and seed_db.resolve() != self.path.resolve():
                    candidates.append(seed_db)
            local_db = settings.base_dir / "app" / "data" / "bitcoin_evidence_engine.duckdb"
            if local_db.exists() and local_db.resolve() != self.path.resolve():
                candidates.append(local_db)
            parent = settings.base_dir.parent
            for folder in parent.glob("bitcoin_evidence_engine*"):
                cand = folder / "app" / "data" / "bitcoin_evidence_engine.duckdb"
                if cand.exists() and cand.resolve() != self.path.resolve():
                    candidates.append(cand)
            candidates = sorted(set(candidates), key=lambda q: q.stat().st_size if q.exists() else 0, reverse=True)
            if not candidates:
                return
            best = candidates[0]
            self.path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(best, self.path)
            append_jsonl("startup_data_migration.jsonl", {
                "event": "shared_or_seed_db_migrated_v10161",
                "from": str(best),
                "to": str(self.path),
                "bytes": self.path.stat().st_size,
                "candidates": [str(c) for c in candidates[:5]],
            })
        except Exception as exc:
            try:
                append_jsonl("startup_data_migration.jsonl", {"event": "shared_or_seed_db_migration_failed_v10161", "error": str(exc)})
            except Exception:
                pass

    def init_schema(self) -> None:
        schema_path = Path(__file__).with_name("schema.sql")
        with self.lock:
            self.conn.execute(schema_path.read_text(encoding="utf-8"))
            # Lightweight forward migrations for users who keep an older DuckDB.
            for stmt in (
                "ALTER TABLE features ADD COLUMN IF NOT EXISTS volume_zscore DOUBLE",
                "ALTER TABLE features ADD COLUMN IF NOT EXISTS volume_ratio_24 DOUBLE",
                "ALTER TABLE features ADD COLUMN IF NOT EXISTS range_pct DOUBLE",
                "ALTER TABLE features ADD COLUMN IF NOT EXISTS candle_body_pct DOUBLE",
                "ALTER TABLE time_machine_tests ADD COLUMN IF NOT EXISTS actual_high DOUBLE",
                "ALTER TABLE time_machine_tests ADD COLUMN IF NOT EXISTS actual_low DOUBLE",
                "ALTER TABLE time_machine_tests ADD COLUMN IF NOT EXISTS target_touched BOOLEAN",
                "ALTER TABLE time_machine_tests ADD COLUMN IF NOT EXISTS target_reached BOOLEAN",
                "ALTER TABLE time_machine_tests ADD COLUMN IF NOT EXISTS invalidation_price DOUBLE",
                "ALTER TABLE time_machine_tests ADD COLUMN IF NOT EXISTS invalidated BOOLEAN",
                "ALTER TABLE time_machine_tests ADD COLUMN IF NOT EXISTS invalidation_gap_pct DOUBLE",
                "ALTER TABLE time_machine_tests ADD COLUMN IF NOT EXISTS target_gap_pct DOUBLE",
                "ALTER TABLE forecast_items ADD COLUMN IF NOT EXISTS invalidation_price DOUBLE",
                "ALTER TABLE forecast_items ADD COLUMN IF NOT EXISTS invalidation_distance_pct DOUBLE",
                "ALTER TABLE forecast_items ADD COLUMN IF NOT EXISTS actual_high DOUBLE",
                "ALTER TABLE forecast_items ADD COLUMN IF NOT EXISTS actual_low DOUBLE",
                "ALTER TABLE forecast_items ADD COLUMN IF NOT EXISTS target_reached BOOLEAN",
                "ALTER TABLE forecast_items ADD COLUMN IF NOT EXISTS target_gap_pct DOUBLE",
                "ALTER TABLE features ADD COLUMN IF NOT EXISTS taker_delta_ratio DOUBLE",
                "ALTER TABLE features ADD COLUMN IF NOT EXISTS futures_basis_premium_pct DOUBLE",
                "ALTER TABLE features ADD COLUMN IF NOT EXISTS top_position_long_short_ratio DOUBLE",
                "ALTER TABLE features ADD COLUMN IF NOT EXISTS top_account_long_short_ratio DOUBLE",
                "ALTER TABLE features ADD COLUMN IF NOT EXISTS cross_exchange_spread_pct DOUBLE",
                "ALTER TABLE features ADD COLUMN IF NOT EXISTS spot_premium_kraken_pct DOUBLE",
                "ALTER TABLE features ADD COLUMN IF NOT EXISTS spot_premium_coinbase_pct DOUBLE",
                "ALTER TABLE time_machine_feature_snapshots ADD COLUMN IF NOT EXISTS partial_reached BOOLEAN",
                "ALTER TABLE time_machine_tests ADD COLUMN IF NOT EXISTS partial_reached BOOLEAN",
                "ALTER TABLE time_machine_tests ADD COLUMN IF NOT EXISTS outcome_tier TEXT",
                "CREATE TABLE IF NOT EXISTS time_machine_jobs (job_id TEXT PRIMARY KEY, batch_id TEXT, status TEXT, phase TEXT, count BIGINT, expected_tests BIGINT, progress_pct DOUBLE, tests_written BIGINT DEFAULT 0, snapshots_written BIGINT DEFAULT 0, signals_written BIGINT DEFAULT 0, export_ready BOOLEAN DEFAULT FALSE, download_url TEXT, error TEXT, started_at TIMESTAMP, updated_at TIMESTAMP, completed_at TIMESTAMP, metadata JSON)",
                "CREATE TABLE IF NOT EXISTS adaptive_model_weights (model_id TEXT NOT NULL, horizon TEXT NOT NULL, weight DOUBLE NOT NULL, hitrate DOUBLE DEFAULT 0.5, sample BIGINT DEFAULT 0, avg_price_error_pct DOUBLE DEFAULT 0, quality DOUBLE DEFAULT 0.5, updated_at TIMESTAMP, PRIMARY KEY(model_id, horizon))",
                "CREATE TABLE IF NOT EXISTS adaptive_learning_runs (run_id TEXT PRIMARY KEY, created_at TIMESTAMP NOT NULL, source_batch_id TEXT, status TEXT, feature_dimensions BIGINT DEFAULT 0, model_dimensions BIGINT DEFAULT 0, signal_buckets BIGINT DEFAULT 0, snapshot_rows BIGINT DEFAULT 0, summary_json JSON)",
            ):
                try:
                    self.conn.execute(stmt)
                except Exception:
                    pass

    def execute(self, sql: str, params: tuple | list | None = None):
        with self.lock:
            return self.conn.execute(sql, params or [])

    def executemany(self, sql: str, params: list | tuple):
        with self.lock:
            return self.conn.executemany(sql, params)

    def fetchone(self, sql: str, params: tuple | list | None = None):
        with self.lock:
            return self.conn.execute(sql, params or []).fetchone()

    def fetchall(self, sql: str, params: tuple | list | None = None):
        with self.lock:
            return self.conn.execute(sql, params or []).fetchall()

    def df(self, sql: str, params: tuple | list | None = None):
        with self.lock:
            return self.conn.execute(sql, params or []).df()

    def upsert_features_frame(self, frame):
        with self.lock:
            self.conn.register("_features_upsert", frame)
            try:
                self.conn.execute("""
                    INSERT OR REPLACE INTO features
                    SELECT interval, timestamp_ms, close, return_1, return_4, return_24,
                           ma_20, ma_50, ma_200, rsi_14, volatility_24, volume_zscore,
                           volume_ratio_24, range_pct, candle_body_pct, drawdown_from_ath,
                           days_since_halving, cycle_progress, fear_greed, funding_rate,
                           open_interest_value, open_interest_change_24h, long_short_ratio,
                           taker_buy_sell_ratio, orderbook_imbalance, orderbook_spread,
                           taker_delta_ratio, futures_basis_premium_pct, top_position_long_short_ratio,
                           top_account_long_short_ratio, cross_exchange_spread_pct, spot_premium_kraken_pct,
                           spot_premium_coinbase_pct, coinmetrics_mvrv, realized_cap_usd, market_cap_usd, regime,
                           data_completeness, state_json::JSON
                    FROM _features_upsert
                """)
            finally:
                try:
                    self.conn.unregister("_features_upsert")
                except Exception:
                    pass

db = Database()
