# AlgoRoute v2.0.0 — Planning Board Revolution

Nieuwe milestone-build met Planning Board als centrale workflow.

## Belangrijk
- Fullscreen Planning Board met Orders, Route Board en Map/Insights.
- CSV orders komen binnen via Planning Board.
- AI Mapping Assistant herkent veel meer synoniemen, typo’s, units en kolomgroepen.
- Drag & drop orders tussen routes na optimalisatie.
- Drop op route voert automatische beste invoegpositie uit en ververst geometry/load.
- Route lock en split route basis toegevoegd.
- Service time, pallets, rolcontainers, gewicht en volume blijven onderdeel van planning.

## Nog roadmap
- Multi-select drag/drop.
- Driver app publish-flow.
- Live recalculation onderweg.
- EV laadstop engine.
- 3D loading/bin packing.
