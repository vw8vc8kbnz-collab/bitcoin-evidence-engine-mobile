function bootIntro(){
  const overlay=document.getElementById('startupIntro');
  const video=document.getElementById('startupVideo');
  const app=document.getElementById('app');
  const skip=document.getElementById('skipIntro');
  if(!overlay||!app) return;
  let closed=false;
  function closeIntro(){
    if(closed) return; closed=true;
    app.classList.remove('introPending'); app.classList.add('introReady');
    overlay.classList.add('hidden');
    try{ if(video) video.pause(); }catch(e){}
    setTimeout(()=>{ try{overlay.remove()}catch(e){} },900);
  }
  if(skip) skip.addEventListener('click', closeIntro);
  if(video){
    video.muted=true; video.playsInline=true;
    const playPromise=video.play();
    if(playPromise && playPromise.catch){playPromise.catch(()=>setTimeout(closeIntro,1100));}
    video.addEventListener('ended', closeIntro);
    video.addEventListener('error', ()=>setTimeout(closeIntro,700));
  }
  setTimeout(closeIntro, 9500);
}

const API = location.origin;
const state = {
  page:'dashboard', planningStep:1, map:null, mapState:null, routingStatus:null, selectedRouteId:'all', expandedRouteId:null,
  fields:[], fieldCategories:[], detections:[], csvHeaders:[], csvRows:[], mapping:{}, templates:[], selectedTemplate:null,
  queue:null, optimizeResult:null, geocodeResult:null, optimizerStatus:null, error:null
};
const navGroups = [
  ['OPERATIONS',[['dashboard','Dashboard','⌂'],['planning','Planning','☷'],['routes','Routes','⌘'],['load','Load Optimization','▣'],['live','Live Kaart','◎']]],
  ['RESOURCES',[['vehicles','Wagenpark','▤'],['drivers','Chauffeurs','♙'],['orders','Orders','▦']]],
  ['MANAGEMENT',[['tracking','Klanttracking','⌾'],['reports','Rapportages','▥'],['settings','Instellingen','⚙']]]
];
function api(path, opts){return fetch(API+path, opts).then(async r=>{let j={};try{j=await r.json()}catch(e){}; if(!r.ok) throw {status:r.status,...j}; return j;});}
async function init(){
  try{state.mapState=await api('/api/map/state')}catch(e){}
  try{state.routingStatus=await api('/api/routing/status')}catch(e){}
  try{state.optimizerStatus=await api('/api/optimizer/status')}catch(e){}
  try{const f=await api('/api/import/fields'); state.fields=f.fields||[]; state.fieldCategories=f.categories||[]}catch(e){}
  try{state.templates=(await api('/api/import/templates')).templates||[]}catch(e){}
  try{state.queue=await api('/api/planning/queue')}catch(e){}
  try{state.vehicles=await api('/api/vehicles')}catch(e){state.vehicles=[]}
  try{state.drivers=await api('/api/drivers')}catch(e){state.drivers=[]}
  render();
}
function setPage(p){state.page=p; render();}
function setStep(n){state.planningStep=n; render();}
function escapeHtml(s){return String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));}
function shell(content){
  return `<div class="shell"><aside class="sidebar"><div class="brand brandOfficial"><img class="brandFullLogo" src="/assets/algoroute-logo-sidebar-white-lime.png" alt="AlgoRoute"/></div>${navGroups.map(([g,items])=>`<div class="sectionLabel">${g}</div>${items.map(([id,label,icon])=>`<div onclick="setPage('${id}')" class="navItem ${state.page===id?'active':''}"><span class="navIcon">${icon}</span><span>${label}</span></div>`).join('')}`).join('')}<div class="sideFooter"><div>◐ Donker sidebar</div><br><b>Stijn</b><div class="muted">Admin</div></div></aside><main class="main page-${state.page}"><div class="topbar"><div class="menuBtn">☰</div><div class="search">⌕ Zoek order, route, bus, mapping of klant...</div><div class="topRight"><span class="sync">● Live sync actief</span><span>🔔</span><span>?</span><span class="avatar">S</span></div></div>${content}</main></div>`;
}
function kpis(){
  const q=state.queue?.summary||{};
  const routes=(state.mapState?.routes||[]).length;
  return `<div class="kpis"><div class="card kpi"><div class="kpiIcon">⌘</div><div><small>Actieve routes</small><br><b>${routes}</b><br><small>${routes?'live beschikbaar':'vult na optimizer'}</small></div></div><div class="card kpi"><div class="kpiIcon">☷</div><div><small>Orders in queue</small><br><b>${q.count||0}</b><br><small>${q.ready||0} ready</small></div></div><div class="card kpi"><div class="kpiIcon">↗</div><div><small>OSRM routing</small><br><b>${state.routingStatus?.available?'online':'—'}</b><br><small>${state.routingStatus?.available?'echte routes':'setup nodig'}</small></div></div><div class="card kpi"><div class="kpiIcon">▧</div><div><small>Load utilization</small><br><b>—</b><br><small>na load optimization</small></div></div></div>`;
}
function dashboard(){return shell(`<h1 class="pageTitle">Dashboard</h1><p class="subtitle">Operationele cockpit. Widgets vullen automatisch vanuit import, voertuigen, OSRM en optimizer.</p>${kpis()}<section class="layout dashboardLayout"><div>${mapCard('Dashboard preview met echte kaartdata')}<div class="bottom"><div class="card panel"><h3>Routes vandaag</h3><div class="row"><span class="muted">${(state.mapState?.routes||[]).length||'Nog geen routes gegenereerd'}</span><span class="badge">routes</span></div></div><div class="card panel"><h3>Planning queue</h3><div class="row"><span class="muted">${state.queue?.summary?.count||0} orders</span><span class="badge green">ready</span></div></div><div class="card panel"><h3>Fleet status</h3><div class="row"><span class="muted">${(state.vehicles||[]).length} voertuigen</span><span class="badge">fleet</span></div></div></div></div><div>${osrmPanel()}${rightInfo()}</div></section>`)}
function routeFocusControls(){const routes=state.mapState?.routes||[]; if(!routes.length) return ''; const active=state.selectedRouteId||'all'; return `<div class="routeFocusPanel"><div class="routeFocusTitle">Route focus</div><button onclick="selectRoute('all')" class="routeChip ${active==='all'?'active':''}">Alle routes</button>${routes.map((r,i)=>`<button onclick="selectRoute('${escapeHtml(r.id||('route_'+(i+1)))}')" class="routeChip ${active===(r.id||('route_'+(i+1)))?'active':''}">${escapeHtml(r.name||('Route '+(i+1)))} · ${escapeHtml(r.vehicle_name||'voertuig')}</button>`).join('')}</div>`}

function serviceMinutes(r){return (r?.stops||[]).reduce((a,s)=>a+Number(s.service_time_minutes||15),0)}
function fmtMin(min){min=Math.round(Number(min||0)); const h=Math.floor(min/60), m=min%60; return h?`${h}u ${m}m`:`${m}m`;}
function routeTimeParts(r){const drive=Math.round((r?.duration_s||0)/60); const service=serviceMinutes(r); return {drive,service,total:drive+service};}
function mapRouteOverlay(full=false){
  const routes=state.mapState?.routes||[]; if(!routes.length) return '';
  const selected=state.selectedRouteId||'all';
  const active=selected==='all' ? routes[0] : routes.find((r,i)=>(r.id||('route_'+(i+1)))===selected) || routes[0];
  const rid=active?.id||'route_1';
  const stops=(active?.stops||[]).length;
  const km=Math.round((active?.distance_m||0)/1000);
  const tp=routeTimeParts(active);
  const load=active?.load||{};
  const metrics=[
    ['⌘',stops,'Stops'],['↗',km,'km'],['◷',fmtMin(tp.drive),'Rijtijd'],['⏱',fmtMin(tp.service),'Service'],['Σ',fmtMin(tp.total),'Totaal'],['▣',load.europallets||0,'Pallets'],['▥',load.roll_containers||0,'Rols'],['⚖',Math.round(load.weight_kg||0),'kg']
  ];
  const statHtml=metrics.map(m=>`<span><i>${m[0]}</i><b title="${escapeHtml(String(m[1]))}">${escapeHtml(String(m[1]))}</b><small>${m[2]}</small></span>`).join('');
  if(!full){
    return `<div class="premiumRouteOverlay dashboardOverlay"><div class="routeSummaryCard compact"><div><span class="routeDotBlue"></span><b>${escapeHtml(active?.name||rid)}</b><small>${escapeHtml(active?.vehicle_name||'Voertuig')}</small></div><div class="routeStats">${statHtml}</div></div></div>`;
  }
  const routeCards=routes.slice(0,6).map((r,i)=>{
    const id=r.id||('route_'+(i+1)); const on=selected===id || (selected==='all'&&i===0);
    const rkm=Math.round((r.distance_m||0)/1000); const s=(r.stops||[]).length;
    return `<button onclick="selectRoute('${escapeHtml(id)}')" class="miniRouteCard ${on?'active':''}"><span><b>${escapeHtml(r.name||('Route '+(i+1)))}</b><small>${escapeHtml(r.vehicle_name||'Voertuig')}</small></span><em>${s} stops · ${rkm} km</em></button>`;
  }).join('');
  return `<div class="premiumRouteOverlay liveOverlay"><div class="miniRouteList"><div class="miniRouteHeader">Routes <span>${routes.length}</span></div>${routeCards}</div><div class="routeSummaryCard"><div><span class="routeDotBlue"></span><b>${escapeHtml(active?.name||rid)}</b><small>${escapeHtml(active?.vehicle_name||'Voertuig')}</small></div><div class="routeStats">${statHtml}</div></div></div>`;
}
function mapCard(sub='Echte Nederland-kaart', full=false){return `<div class="card mapCard ${full?'mapCanvasFull':''}"><div class="mapHeader"><button class="pill">Traffic</button><button class="pill active">Routes</button><button class="pill">Stops</button></div>${routeFocusControls()}${mapRouteOverlay(full)}<div id="map" class="map"></div>${full?`<div class="roadLegend"><b>Route status</b><span class="legendLine"><i class="normal"></i>Premium blauw</span><span class="legendLine"><i class="delay"></i>Vertraging</span><span class="legendLine"><i class="jam"></i>File</span><span class="legendLine"><i class="ev"></i>EV route</span></div>`:''}${(!state.mapState || ((state.mapState.routes||[]).length===0 && (state.mapState.vehicles||[]).length===0))?`<div class="emptyMap"><b>Kaart is klaar voor echte data</b><br><span class="muted">Routes verschijnen na echte orders + optimalisatie.</span></div>`:''}</div>`}
function selectRoute(id){state.selectedRouteId=id||'all'; render();}
function osrmPanel(){const s=state.routingStatus||{};return `<div class="card panel" style="margin-bottom:18px"><h3>OSRM status</h3><div class="row"><span><i class="statusDot ${s.available?'ok':'bad'}"></i> Routing engine</span><span class="badge ${s.available?'green':'orange'}">${s.available?'online':'niet actief'}</span></div><p class="muted">${escapeHtml(s.message||'OSRM status wordt geladen.')}</p><button class="btn accent" onclick="setPage('settings')">OSRM setup bekijken</button></div>`}
function rightInfo(){return `<div class="card panel"><h3>Product flow</h3><div class="row"><b>1. Import</b><span class="badge green">CSV/ERP</span></div><div class="row"><b>2. Mapping</b><span class="badge green">smart</span></div><div class="row"><b>3. Queue</b><span class="badge">ready</span></div><div class="row"><b>4. Optimize</b><span class="badge orange">OSRM</span></div><div class="row"><b>5. Publish</b><span class="badge">later</span></div></div>`}
function initMap(){
  if(!window.maplibregl) return; const el=document.getElementById('map'); if(!el) return; el.innerHTML='';
  const style={version:8,sources:{carto:{type:'raster',tiles:['https://a.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}@2x.png','https://b.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}@2x.png','https://c.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}@2x.png','https://d.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}@2x.png'],tileSize:256,attribution:'© OpenStreetMap © CARTO'}},layers:[{id:'carto',type:'raster',source:'carto',paint:{'raster-opacity':.98,'raster-saturation':-.10,'raster-contrast':.18,'raster-brightness-min':.00,'raster-brightness-max':.88}}]};
  const map=new maplibregl.Map({container:el,style,center:[5.2913,52.1326],zoom: state.page==='live'?7.75:7.18,pixelRatio:Math.min(window.devicePixelRatio||1,2),attributionControl:true,preserveDrawingBuffer:false});
  state.map=map;
  map.addControl(new maplibregl.NavigationControl({showCompass:false}),'bottom-right');
  map.on('load',()=>{drawData(map); setTimeout(()=>map.resize(),60); setTimeout(()=>map.resize(),260);});
  setTimeout(()=>map.resize(),120);
  setTimeout(()=>map.resize(),520);
}
function drawData(map){
  const ms=state.mapState||{routes:[],vehicles:[]};
  const selected=state.selectedRouteId||'all';
  const routes=(ms.routes||[]).filter((r,i)=>selected==='all' || selected===(r.id||('route_'+(i+1))));
  const bounds=new maplibregl.LngLatBounds(); let hasBounds=false;
  routes.forEach((r,i)=>{
    const coords=r.geometry||r.coordinates||[]; if(!coords.length) return;
    const rid=r.id||('route_'+(i+1));
    const routeColor='#147CFF';
    coords.forEach(c=>{if(Array.isArray(c)&&c.length>=2){bounds.extend(c);hasBounds=true;}});
    map.addSource('route-'+i,{type:'geojson',data:{type:'Feature',properties:{id:rid,name:r.name||rid,vehicle:r.vehicle_name||''},geometry:{type:'LineString',coordinates:coords}}});
    map.addLayer({id:'route-shadow-'+i,type:'line',source:'route-'+i,layout:{'line-cap':'round','line-join':'round'},paint:{'line-color':'#061A3D','line-width':selected==='all'?13:18,'line-opacity':selected==='all'?.18:.26,'line-blur':6}});
    map.addLayer({id:'route-glow-'+i,type:'line',source:'route-'+i,layout:{'line-cap':'round','line-join':'round'},paint:{'line-color':'#2294FF','line-width':selected==='all'?9:13,'line-opacity':selected==='all'?.34:.50,'line-blur':4}});
    map.addLayer({id:'route-casing-'+i,type:'line',source:'route-'+i,layout:{'line-cap':'round','line-join':'round'},paint:{'line-color':'#EAF4FF','line-width':selected==='all'?6.2:8.8,'line-opacity':.98}});
    map.addLayer({id:'route-'+i,type:'line',source:'route-'+i,layout:{'line-cap':'round','line-join':'round'},paint:{'line-color':routeColor,'line-width':selected==='all'?4.2:6.2,'line-opacity':.98}});
    map.addLayer({id:'route-shine-'+i,type:'line',source:'route-'+i,layout:{'line-cap':'round','line-join':'round'},paint:{'line-color':'#7DD3FC','line-width':selected==='all'?1.4:2.0,'line-opacity':selected==='all'?.72:.88}});
    addRouteStartMarker(map, r, coords, rid);
    addStopMarkers(map, r, selected==='all');
    map.on('click','route-'+i,()=>selectRoute(rid));
    map.on('mouseenter','route-'+i,()=>{map.getCanvas().style.cursor='pointer'});
    map.on('mouseleave','route-'+i,()=>{map.getCanvas().style.cursor=''});
  });
  if(hasBounds){try{map.fitBounds(bounds,{padding:selected==='all'?70:90,maxZoom:selected==='all'?8.55:10.8,duration:550});}catch(e){}}
  (ms.vehicles||[]).forEach(v=>{if(!v.longitude||!v.latitude)return; const el=document.createElement('div');el.className='vehicleMarker';el.textContent='🚚';new maplibregl.Marker({element:el}).setLngLat([v.longitude,v.latitude]).addTo(map);});
}

function addRouteStartMarker(map,r,coords,rid){
  const start=coords[0]; if(!Array.isArray(start)||start.length<2) return;
  const el=document.createElement('div'); el.className='routeStartMarker';
  el.innerHTML=`<div class="startBus">🚐</div><div class="startLabel"><b>Start</b><span>${escapeHtml(r.vehicle_name||r.name||rid)}</span></div>`;
  new maplibregl.Marker({element:el,anchor:'bottom'}).setLngLat(start).addTo(map);
}
function addStopMarkers(map,r,compact=false){
  const stops=(r.stops||[]).filter(s=>s.longitude!==undefined&&s.latitude!==undefined).slice(0,40);
  stops.forEach((s,idx)=>{ if(!s.longitude||!s.latitude) return; const el=document.createElement('div'); el.className=compact?'stopMarker compact':'stopMarker'; el.textContent=String(s.sequence||idx+1); new maplibregl.Marker({element:el}).setLngLat([Number(s.longitude),Number(s.latitude)]).addTo(map); });
}

function live(){return shell(`<section class="liveMapPage"><h1 class="pageTitle">Live Kaart</h1><p class="subtitle">Full-canvas execution map met OSRM-routes, traffic-segmenten, voertuigen en laadstatus.</p><div class="liveMapShell">${mapCard('Echte Nederland-kaart', true)}</div></section>`)}
function planning(){return shell(`<h1 class="pageTitle">Planning Queue</h1><p class="subtitle">Controleer leverdatum, tijdvensters, service/kostijd en capaciteit voordat AlgoRoute de optimizer start.</p><div class="tabs">${[1,2,3,4,5].map((n,i)=>`<button onclick="setStep(${n})" class="tab ${state.planningStep===n?'active':''}">${n} ${['Import','Mapping','Queue','Optimize','Publish'][i]}</button>`).join('')}</div>${planningStep()}`)}
function planningStep(){
  if(state.planningStep===1) return importStep();
  if(state.planningStep===2) return mappingStep();
  if(state.planningStep===3) return queueStep();
  if(state.planningStep===4) return optimizeStep();
  return publishStep();
}
function importStep(){return `<div class="workflowCard card"><h2>1. Import</h2><p class="muted">Upload CSV. Mapping gebeurt bewust pas in stap 2.</p><div class="uploadBox"><input id="csvFile" class="input" type="file" accept=".csv,.txt" onchange="handleCsvUpload(event)"><div class="muted">CSV wordt lokaal geparsed en daarna naar Smart Mapping gestuurd.</div></div><div class="moduleGrid"><div class="card panel"><h3>Recent bestand</h3>${state.csvHeaders.length?`<div class="notice greenNotice"><b>${state.csvRows.length}</b> regels gelezen · <b>${state.csvHeaders.length}</b> kolommen gevonden</div><button class="btn accent" onclick="setStep(2)">Door naar Mapping →</button>`:`<p class="muted">Nog geen bestand geüpload.</p>`}</div><div class="card panel"><h3>Integraties later</h3><p class="muted">Odoo, Exact, AFAS, WooCommerce, SFTP en Custom API komen via dezelfde normalisatielaag binnen.</p></div></div></div>`;}
function mappingStep(){return `<div class="workflowCard card"><h2>2. Mapping</h2><p class="muted">Mega slimme CSV-detectie: fuzzy matching, synoniemen, spelfouten, NL/EN en waardeherkenning.</p>${state.csvHeaders.length?mappingContent():`<div class="notice">Upload eerst een CSV in stap 1 Import.</div>`}</div>`;}
function requiredFields(){return (state.fields||[]).filter(f=>f.required).map(f=>f.id)}
function hasMappedField(fid){return Object.values(state.mapping||{}).filter(Boolean).includes(fid)}
function addressMappingState(){
  const hasFull=hasMappedField('delivery_address_full');
  const hasStreet=hasMappedField('street');
  const hasPostal=hasMappedField('postal_code');
  const hasCity=hasMappedField('city');
  const hasGps=hasMappedField('latitude')&&hasMappedField('longitude');
  const ok=hasFull || hasGps || (hasStreet && (hasCity || hasPostal));
  let label='Adres compleet';
  let detail='Adres wordt opgebouwd uit gekoppelde velden.';
  if(hasFull){detail='Volledig afleveradres is gekoppeld.'}
  else if(hasGps){detail='GPS-coördinaten zijn gekoppeld; adres is optioneel.'}
  else if(hasStreet && hasCity && hasPostal){detail='Straat + postcode + plaats zijn gekoppeld.'}
  else if(hasStreet && hasCity){detail='Straat + plaats zijn gekoppeld; PDOK/BAG vult waar mogelijk aan.'}
  else if(hasStreet && hasPostal){detail='Straat + postcode zijn gekoppeld; PDOK/BAG vult waar mogelijk aan.'}
  else {label='Adresgroep mist'; detail='Koppel Volledig afleveradres óf Straat + Plaats/Postcode óf Latitude + Longitude.'}
  return {ok,label,detail,fields:['delivery_address_full','street','postal_code','city','latitude','longitude']};
}
function mappingStats(){
  const vals=Object.values(state.mapping||{}).filter(Boolean);
  const req=requiredFields();
  const missing=req.filter(f=>!vals.includes(f));
  const addr=addressMappingState();
  const missingGroups=addr.ok?[]:['address_group'];
  const unmapped=(state.csvHeaders||[]).filter(h=>!state.mapping[h]);
  return {mapped:vals.length, total:(state.csvHeaders||[]).length, missing, missingGroups, address:addr, unmapped};
}
function mappingStep(){const stats=mappingStats(); return `<div class="workflowCard card"><div class="sectionHero"><div><h2>2. Mapping Studio</h2><p class="muted">Koppel CSV-kolommen visueel aan AlgoRoute velden. Alles wat rood/oranje is vraagt aandacht.</p></div>${state.csvHeaders.length?`<div class="mappingScore ${stats.missing.length?'warn':'ok'}"><b>${stats.total-stats.unmapped.length}/${stats.total}</b><span>kolommen gekoppeld</span></div>`:''}</div>${state.csvHeaders.length?mappingContent():`<div class="notice">Upload eerst een CSV in stap 1 Import.</div>`}</div>`;}
function mappingContent(){
  const stats=mappingStats();
  const allOk=stats.missing.length===0 && stats.missingGroups.length===0;
  const missingText=[...stats.missing.map(f=>`<button onclick="highlightField('${f}')">${escapeHtml(labelForField(f))}</button>`), ...stats.missingGroups.map(g=>`<button onclick="highlightAddressGroup()">Adresgroep</button>`)].join('');
  return `<div class="mappingStudio"><div class="mappingActionBar"><button class="btn accent" onclick="runSmartDetect()">Smart detect opnieuw</button><button class="btn" onclick="commitImport()">Importeer naar Queue</button><input id="templateName" class="input templateInput" placeholder="Template naam opslaan"><span class="badge ${allOk?'green':'orange'}">${allOk?'mapping compleet':(stats.missing.length+stats.missingGroups.length)+' actiepunt'}</span><span class="badge ${stats.unmapped.length?'orange':'green'}">${stats.unmapped.length} ongemapt</span></div><div class="addressRule ${stats.address.ok?'ok':'warn'}"><b>${stats.address.ok?'Adresregel OK':'Actie nodig: adres'}</b><span>${escapeHtml(stats.address.detail)}</span></div>${allOk?`<div class="missingStrip ok"><b>Goed:</b><span>Verplichte velden en adresgroep zijn compleet. Je kunt importeren.</span></div>`:`<div class="missingStrip"><b>Actie nodig:</b>${missingText}</div>`}<div class="mappingCanvas"><div class="mappingColumns">${state.csvHeaders.map(h=>mappingCard(h)).join('')}</div><div class="card panel fieldPicker premiumPicker"><h3>Veldbibliotheek</h3><p class="muted">Zoek en selecteer handmatig het juiste doelveld wanneer Smart Detect twijfelt.</p><input id="fieldSearch" class="input" placeholder="Zoek veld: postcode, pallets, leverdatum..." oninput="renderFieldCatalog(this.value)"><div id="fieldCatalog" class="fieldCatalog">${fieldCatalogHtml('')}</div></div></div></div>`;
}
function mappingCard(h){const det=(state.detections||[]).find(d=>d.column===h); const best=det?.best; const current=state.mapping[h] || (best&&best.score>=82?best.field_id:''); if(current && !state.mapping[h]) state.mapping[h]=current; const samples=(det?.samples||[]).slice(0,3); const confidence=best?.score||0; const status=current?'mapped':(best?'review':'missing'); return `<div class="mappingCard ${status} ${confidence&&confidence<75?'lowConf':''}" data-field="${escapeHtml(current||'')}"><div class="mapCardTop"><div><b>${escapeHtml(h)}</b><small>${current?escapeHtml(labelForField(current)):'Geen veld gekoppeld'}</small></div><span class="mapStatus ${status}">${current?'gekoppeld':best?'check':'geen match'}</span></div><div class="sampleLine">${samples.length?samples.map(x=>`<em>${escapeHtml(x)}</em>`).join(''):'<em>Geen voorbeeldwaarden</em>'}</div><div class="mapSelectRow"><select onchange="state.mapping['${escapeHtml(h)}']=this.value; render()"><option value="">— Kies veld —</option>${state.fields.map(f=>`<option value="${f.id}" ${current===f.id?'selected':''}>${f.label} · ${f.category}</option>`).join('')}</select><div class="confidenceRing ${confidence<75?'warn':''}">${confidence?confidence+'%':'—'}</div></div>${!current?`<div class="mapHint">Geen match? Kies rechts of in deze dropdown het juiste veld.</div>`:''}</div>`;}
function highlightField(fid){const el=[...document.querySelectorAll('.mappingCard')].find(x=>x.dataset.field===fid); if(el){el.scrollIntoView({behavior:'smooth',block:'center'}); el.classList.add('pulse'); setTimeout(()=>el.classList.remove('pulse'),1500)}}
function highlightAddressGroup(){['delivery_address_full','street','postal_code','city','latitude','longitude'].forEach(highlightField)}
function fieldCatalogHtml(query){const q=(query||'').toLowerCase(); const fields=state.fields.filter(f=>!q || (f.label+' '+f.id+' '+f.category+' '+(f.aliases||[]).join(' ')).toLowerCase().includes(q)); const grouped={}; fields.forEach(f=>{(grouped[f.category]||(grouped[f.category]=[])).push(f)}); return Object.entries(grouped).map(([cat,fs])=>`<div class="fieldCat"><h4>${cat}</h4>${fs.map(f=>`<button class="fieldItem" onclick="copyFieldHint('${f.id}')"><b>${f.label}</b><span class="badge">${f.type||'text'}</span><small>${f.required?'verplicht':'optioneel'}</small></button>`).join('')}</div>`).join('');}
function copyFieldHint(fid){alert('Kies dit veld in de dropdown bij de juiste CSV-kolom: '+labelForField(fid));}
function renderFieldCatalog(q){const el=document.getElementById('fieldCatalog'); if(el) el.innerHTML=fieldCatalogHtml(q);}
function labelForField(id){const f=state.fields.find(x=>x.id===id); return f?f.label:id;}
function queueStep(){
  const orders=state.queue?.orders||[]; const geo=state.geocodeResult; const geocoded=orders.filter(o=>o.latitude&&o.longitude).length;
  return `<div class="workflowCard card"><h2>3. Queue</h2><p class="muted">Controleer adressen, status en service/lostijd per order voordat je optimaliseert.</p><div class="mappingToolbar"><button class="btn accent" onclick="geocodeQueue()">Adressen valideren via PDOK/BAG</button><button class="btn" onclick="setStep(4)">Door naar Optimize →</button><span class="badge green">Optimize kan GPS automatisch ophalen</span><button class="btn dangerSoft" onclick="clearQueue()">Queue leegmaken</button><span class="badge ${geocoded?'green':'orange'}">${geocoded}/${orders.length||0} met GPS</span></div>${geo?`<div class="notice ${geo.unresolved?'':'greenNotice'}"><b>PDOK resultaat</b><br>${geo.updated} adressen gekoppeld · ${geo.unresolved} onopgelost · ${geo.total_checked} gecontroleerd</div>`:''}${orders.length?`<div class="queueCards">${orders.map(o=>`<div class="queueCard"><div><b>${escapeHtml(o.order_number)}</b><span>${escapeHtml(o.customer_name)}</span></div><div class="queueAddress">${escapeHtml((o.delivery_address||'')+' '+(o.postal_code||'')+' '+(o.city||''))}</div><div class="chips"><span class="badge ${o.latitude&&o.longitude?'green':'orange'}">${o.latitude&&o.longitude?'PDOK':'GPS nodig'}</span><span class="badge ${o.status==='ready'?'green':'orange'}">${escapeHtml(o.status||'—')}</span><span class="badge serviceBadge">${o.service_time_minutes||15} min service</span><span class="badge">${o.europallets||0} EP</span><span class="badge">${o.roll_containers||0} RC</span></div></div>`).join('')}</div>`:`<div class="notice">Planning Queue is leeg. Importeer orders of koppel een ERP.</div>`}</div>`;}
function optimizeStep(){const core=state.optimizerStatus; const res=state.optimizeResult; return `<div class="workflowCard card"><h2>4. Optimize</h2><p class="muted">C++ Optimizer Core: routeoptimalisatie + load-capaciteit voor kg, m³, pallets en rolcontainers. Geen 3D loading in deze fase.</p><div class="notice ${core?.available?'greenNotice':''}"><b>Optimizer core</b><br>${core?`${core.core_mode} · ${core.available?'binary beschikbaar':'binary ontbreekt'} · ${core.scope}`:'status laden...'}</div>${osrmPanel()}<div class="serviceConfig card"><div><b>Service time schaalbaar</b><span>Per order via CSV-mapping of Order-detail. Fallback voor orders zonder waarde: 15 minuten.</span></div><div class="servicePills"><span>CSV: service_time_minutes</span><span>Queue zichtbaar</span><span>Route totaal = rijtijd + service</span></div></div><button class="btn accent" onclick="runOptimize()">Optimaliseer routes met C++ core + auto PDOK</button>${res?optimizeResultPanel(res):''}</div>`;}
function optimizeResultPanel(res){const geo=res.auto_geocode?`<span>PDOK auto: ${res.auto_geocode.updated||0} gekoppeld · ${res.auto_geocode.unresolved||0} onopgelost</span>`:''; if(!res.ok)return `<div class="resultPanel warn"><b>Optimalisatie niet gestart</b><span>${escapeHtml(res.reason||'Controleer queue en wagenpark.')}</span>${geo}</div>`; return `<div class="resultPanel ok"><div><b>${res.routes_created||0} routes gemaakt</b><span>${res.unplanned_orders||0} orders niet gepland</span>${geo}</div><div class="resultStats"><span>C++ core</span><span>${escapeHtml(res.core_version||'v1')}</span><button class="btn" onclick="setPage('routes')">Bekijk routes</button><button class="btn" onclick="setPage('live')">Open live kaart</button></div></div>`;}
function publishStep(){return `<div class="workflowCard card"><h2>5. Publish</h2><p class="muted">Routes publiceren naar chauffeur-app, klanttracking en live kaart.</p><div class="notice">Publish wordt actief zodra routes gegenereerd zijn.</div></div>`;}
function routeQuality(r){const stops=(r.stops||[]).length; const km=Math.round((r.distance_m||0)/1000); const tp=routeTimeParts(r); const load=r.load||{}; return {stops,km,drive:tp.drive,service:tp.service,total:tp.total,load};}
function routes(){const list=state.mapState?.routes||[]; return shell(`<h1 class="pageTitle">Routes</h1><p class="subtitle">Premium overzicht van routes, rijtijd, service time, totaalduur, stops en belading.</p>${list.length?`<div class="routeOverview">${list.map((r,i)=>routePanel(r,i)).join('')}</div>`:`<div class="workflowCard card"><h2>Nog geen routes</h2><p class="muted">Optimaliseer eerst de Planning Queue.</p><button class="btn accent" onclick="setPage('planning');state.planningStep=4;render()">Naar optimaliseren</button></div>`}`)}
function routePanel(r,i){const q=routeQuality(r); const id=r.id||('route_'+(i+1)); const open=state.expandedRouteId===id; return `<div class="card routePanel"><div class="routePanelHead"><div><span class="routeDotBlue"></span><b>${escapeHtml(r.name||('Route '+(i+1)))}</b><small>${escapeHtml(r.vehicle_name||'Voertuig')}</small></div><div class="routePanelStats"><span><b>${q.stops}</b><small>Stops</small></span><span><b>${q.km}</b><small>km</small></span><span><b>${fmtMin(q.drive)}</b><small>Rijtijd</small></span><span><b>${fmtMin(q.service)}</b><small>Service</small></span><span><b>${fmtMin(q.total)}</b><small>Totaal</small></span><span><b>${q.load.europallets||0}</b><small>Pallets</small></span><span><b>${q.load.roll_containers||0}</b><small>Rols</small></span><span><b>${Math.round(q.load.weight_kg||0)}</b><small>kg</small></span></div><button class="btn" onclick="toggleRoute('${escapeHtml(id)}')">${open?'Inklappen':'Stops bekijken'}</button></div>${open?`<div class="stopTimeline">${(r.stops||[]).map((s,j)=>stopRow(s,j)).join('')}</div>`:''}</div>`;}
function stopRow(s,j){return `<div class="stopRow"><div class="stopSeq">${j+1}</div><div><b>${escapeHtml(s.order_number||s.id||'Stop')}</b><span>${escapeHtml(s.customer_name||'')}</span></div><div class="muted">${escapeHtml((s.delivery_address||'')+' '+(s.postal_code||'')+' '+(s.city||''))}</div><div class="chips"><span class="badge">${s.service_time_minutes||15} min</span><span class="badge">${s.europallets||0} EP</span><span class="badge">${s.roll_containers||0} RC</span><span class="badge">${Math.round(s.weight_kg||0)} kg</span></div></div>`;}
function toggleRoute(id){state.expandedRouteId=state.expandedRouteId===id?null:id; render();}
function simple(title,txt){return shell(`<h1 class="pageTitle">${title}</h1><p class="subtitle">${txt}</p><div class="workflowCard card"><h2>Module foundation</h2><p class="muted">Deze pagina is klaar voor echte data en forms. Geen dummydata.</p></div>`)}

function vehicles(){
  const list=state.vehicles||[];
  const available=list.filter(v=>['available','beschikbaar','active','actief'].includes(String(v.status||'available'))).length;
  const ev=list.filter(v=>String(v.fuel_type||'').toLowerCase()==='electric').length;
  return shell(`<h1 class="pageTitle">Wagenpark</h1><p class="subtitle">Voertuigen, capaciteit, onderhoud, RDW-kentekenlookup en EV-profielen. EV-laadstops zijn roadmap; nu tonen we bereik en marge.</p><div class="setupActions"><button class="btn accent" onclick="seedFleet()">Test-vloot laden</button><button class="btn" onclick="refreshFleet()">Vernieuwen</button><span class="badge green">${available} beschikbaar</span><span class="badge ${ev?'green':''}">${ev} elektrisch</span></div><div class="fleetGrid premiumFleet"><div class="workflowCard card"><h2>Voertuig toevoegen</h2><form class="entityForm vehicleForm" onsubmit="saveVehicle(event)"><input name="name" placeholder="Naam voertuig, bijv. Bus 01" required><div class="plateLookup"><div class="nlPlate"><span>NL</span><input name="license_plate" id="licensePlateInput" placeholder="V-123-AB" oninput="formatPlateInput(this)" required></div><button type="button" class="btn" onclick="lookupRdw()">RDW lookup</button></div><div id="rdwPreview" class="rdwPreview">Kenteken invullen voor RDW merk/model voorstel.</div><div class="two"><input name="brand" id="vehicleBrand" placeholder="Merk"><input name="model" id="vehicleModel" placeholder="Model"></div><div class="two"><select name="status"><option value="available">Beschikbaar</option><option value="maintenance">Onderhoud</option><option value="unavailable">Niet beschikbaar</option></select><select name="fuel_type" onchange="toggleEvFields(this)"><option value="diesel">Diesel</option><option value="petrol">Benzine</option><option value="hybrid">Hybride</option><option value="electric">Elektrisch</option></select></div><div class="capacityGrid"><label>Europallets<input name="europallet_capacity" type="number" min="0" placeholder="8"></label><label>Rolcontainers<input name="roll_container_capacity" type="number" min="0" placeholder="10"></label><label>Max kg<input name="max_weight_kg" type="number" min="0" placeholder="1250"></label><label>Max m³<input name="max_volume_m3" type="number" min="0" step="0.1" placeholder="15"></label></div><div id="evFields" class="evFields hidden"><h3>EV-profiel</h3><p class="muted">Nog geen laadstop-calculatie in deze fase; deze waarden worden alvast opgeslagen voor EV Intelligence.</p><div class="three"><input name="battery_capacity_kwh" type="number" placeholder="kWh accu"><input name="range_empty_km" type="number" placeholder="Bereik leeg km"><input name="range_loaded_km" type="number" placeholder="Bereik beladen km"></div><div class="two"><input name="current_soc_percent" type="number" placeholder="Batterij nu %"><input name="min_soc_percent" type="number" placeholder="Min. marge %"></div></div><button class="btn accent" type="submit">Voertuig opslaan</button></form></div><div class="workflowCard card"><h2>Voertuigen</h2>${list.length?`<div class="entityList">${list.map(v=>vehicleCard(v)).join('')}</div>`:`<div class="notice">Nog geen voertuigen. Voeg handmatig toe of laad de test-vloot.</div>`}</div></div>`);
}
function vehicleCard(v){const ev=String(v.fuel_type||'').toLowerCase()==='electric'; return `<div class="entityCard vehicleEntity"><div><b>${escapeHtml(v.name||v.license_plate||'Voertuig')}</b><div class="muted"><span class="plateSmall">${escapeHtml(v.license_plate||'—')}</span> · ${escapeHtml(v.brand||'')} ${escapeHtml(v.model||'')}</div><div class="chips"><span class="badge ${v.status==='available'?'green':'orange'}">${escapeHtml(v.status||'available')}</span><span class="badge">${v.europallet_capacity||0} EP</span><span class="badge">${v.roll_container_capacity||0} RC</span><span class="badge">${v.max_weight_kg||0} kg</span><span class="badge">${v.max_volume_m3||0} m³</span>${ev?`<span class="badge ev">EV ${v.current_soc_percent||0}% · ${v.range_loaded_km||0} km beladen</span><span class="badge orange">laadstops roadmap</span>`:''}</div></div><button class="miniDanger" onclick="deleteVehicle('${escapeHtml(v.id)}')">Verwijder</button></div>`}
function formatPlateInput(el){let v=el.value.toUpperCase().replace(/[^A-Z0-9]/g,''); if(v.length>2&&v.length<=5)v=v.slice(0,1)+'-'+v.slice(1,4)+'-'+v.slice(4); else if(v.length>5)v=v.slice(0,1)+'-'+v.slice(1,4)+'-'+v.slice(4,6); el.value=v;}
async function lookupRdw(){const input=document.getElementById('licensePlateInput'); const box=document.getElementById('rdwPreview'); if(!input||!input.value)return; box.textContent='RDW wordt opgezocht...'; try{const res=await api('/api/rdw/lookup?kenteken='+encodeURIComponent(input.value)); if(!res.found){box.textContent='Geen RDW match gevonden.'; return;} document.getElementById('vehicleBrand').value=res.brand||''; document.getElementById('vehicleModel').value=res.model||''; box.innerHTML=`<b>RDW match</b> · ${escapeHtml(res.brand||'')} ${escapeHtml(res.model||'')} · ${escapeHtml(res.vehicle_type||'')}`;}catch(e){box.textContent='RDW lookup niet beschikbaar of tijdelijk geen verbinding.';}}
function drivers(){
  const list=state.drivers||[];
  return shell(`<h1 class="pageTitle">Chauffeurs</h1><p class="subtitle">Chauffeurs, beschikbaarheid en app-toegang. Klaar voor route-toewijzing.</p><div class="setupActions"><button class="btn accent" onclick="seedFleet()">Test-chauffeurs laden</button><button class="btn" onclick="refreshFleet()">Vernieuwen</button><span class="badge green">${list.filter(d=>d.status==='available').length} beschikbaar</span></div><div class="fleetGrid"><div class="workflowCard card"><h2>Chauffeur toevoegen</h2><form class="entityForm" onsubmit="saveDriver(event)"><input name="name" placeholder="Naam chauffeur" required><div class="two"><input name="phone" placeholder="Telefoon"><input name="email" placeholder="E-mail"></div><div class="two"><select name="status"><option value="available">Beschikbaar</option><option value="unavailable">Niet beschikbaar</option><option value="sick">Ziek</option><option value="holiday">Vakantie</option></select><select name="license_type"><option value="B">Rijbewijs B</option><option value="BE">BE</option><option value="C1">C1</option><option value="C">C</option></select></div><select name="assigned_vehicle_id"><option value="">Geen vast voertuig</option>${(state.vehicles||[]).map(v=>`<option value="${escapeHtml(v.id)}">${escapeHtml(v.name||v.license_plate)}</option>`).join('')}</select><button class="btn accent" type="submit">Chauffeur opslaan</button></form></div><div class="workflowCard card"><h2>Chauffeurs</h2>${list.length?`<div class="entityList">${list.map(d=>driverCard(d)).join('')}</div>`:`<div class="notice">Nog geen chauffeurs. Voeg handmatig toe of laad de testset.</div>`}</div></div>`);
}
function driverCard(d){const v=(state.vehicles||[]).find(x=>x.id===d.assigned_vehicle_id); return `<div class="entityCard"><div><b>${escapeHtml(d.name)}</b><div class="muted">${escapeHtml(d.phone||'—')} · ${escapeHtml(d.email||'')}</div><div class="chips"><span class="badge ${d.status==='available'?'green':'orange'}">${escapeHtml(d.status||'available')}</span><span class="badge">${escapeHtml(d.license_type||'B')}</span><span class="badge">${v?escapeHtml(v.name||v.license_plate):'geen voertuig'}</span><span class="badge">app ${escapeHtml(d.app_access||'pending')}</span></div></div><button class="miniDanger" onclick="deleteDriver('${escapeHtml(d.id)}')">Verwijder</button></div>`}
async function refreshFleet(){state.vehicles=await api('/api/vehicles'); state.drivers=await api('/api/drivers'); state.mapState=await api('/api/map/state'); render();}
async function seedFleet(){await api('/api/testdata/fleet',{method:'POST'}); await refreshFleet();}
async function saveVehicle(e){e.preventDefault(); const data=Object.fromEntries(new FormData(e.target).entries()); ['europallet_capacity','roll_container_capacity','max_weight_kg','max_volume_m3','battery_capacity_kwh','range_empty_km','range_loaded_km','current_soc_percent','min_soc_percent'].forEach(k=>{if(data[k]!==''&&data[k]!=null)data[k]=Number(data[k]);}); await api('/api/vehicles',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)}); e.target.reset(); await refreshFleet();}
async function saveDriver(e){e.preventDefault(); const data=Object.fromEntries(new FormData(e.target).entries()); await api('/api/drivers',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)}); e.target.reset(); await refreshFleet();}
async function deleteVehicle(id){if(!confirm('Voertuig verwijderen?'))return; await api('/api/vehicles/'+id,{method:'DELETE'}); await refreshFleet();}
async function deleteDriver(id){if(!confirm('Chauffeur verwijderen?'))return; await api('/api/drivers/'+id,{method:'DELETE'}); await refreshFleet();}
function toggleEvFields(sel){const box=document.getElementById('evFields'); if(box) box.classList.toggle('hidden', sel.value!=='electric');}

function settings(){return shell(`<h1 class="pageTitle">Instellingen</h1><p class="subtitle">OSRM, integraties, depots, transport-units en API keys.</p><div class="moduleGrid"><div class="card panel"><h3>OSRM Nederland setup</h3><pre>cd /home/ubuntu/algoroute_latest/algoroute_v1_7_TEST_READY
sudo ./scripts/setup_osrm_nl.sh</pre></div><div>${osrmPanel()}</div></div>`)}
function render(){const pages={dashboard,live,planning,routes,vehicles,drivers,orders:()=>simple('Orders','Alle geïmporteerde en handmatige orders.'),load:()=>simple('Load Optimization','Pallets, rolcontainers, LIFO en later 2D/3D belading.'),tracking:()=>simple('Klanttracking','Trackinglinks en klantmeldingen.'),reports:()=>simple('Rapportages','Punctualiteit, routekwaliteit, load en EV.'),settings}; document.getElementById('app').innerHTML=(pages[state.page]||dashboard)(); setTimeout(initMap,50);}
function detectDelimiter(text){const first=text.split(/\r?\n/).slice(0,5).join('\n'); const candidates=[',',';','\t','|']; return candidates.map(d=>[d,(first.match(new RegExp('\\'+d,'g'))||[]).length]).sort((a,b)=>b[1]-a[1])[0][0];}
function parseCsv(text){const d=detectDelimiter(text); const rows=[]; let row=[], cell='', q=false; for(let i=0;i<text.length;i++){const c=text[i], n=text[i+1]; if(c==='"'&&q&&n==='"'){cell+='"';i++;} else if(c==='"'){q=!q;} else if(c===d&&!q){row.push(cell);cell='';} else if((c==='\n'||c==='\r')&&!q){ if(c==='\r'&&n==='\n') i++; row.push(cell); if(row.some(x=>String(x).trim()!=='')) rows.push(row); row=[]; cell=''; } else cell+=c; } if(cell||row.length){row.push(cell); rows.push(row);} const headers=(rows.shift()||[]).map(h=>h.trim()); return {headers, rows:rows.map(r=>Object.fromEntries(headers.map((h,i)=>[h,r[i]||''])))};}
async function handleCsvUpload(e){const file=e.target.files[0]; if(!file) return; const text=await file.text(); const parsed=parseCsv(text); state.csvHeaders=parsed.headers; state.csvRows=parsed.rows; state.mapping={}; await runSmartDetect(false); state.planningStep=2; render();}
async function runSmartDetect(doRender=true){if(!state.csvHeaders.length)return; const res=await api('/api/import/detect',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({headers:state.csvHeaders,rows:state.csvRows.slice(0,50)})}); state.detections=res.detections||[]; state.detections.forEach(d=>{if(d.best&&d.best.score>=82&&!state.mapping[d.column]) state.mapping[d.column]=d.best.field_id}); if(doRender) render();}
async function commitImport(){if(!state.csvRows.length)return alert('Geen CSV geladen'); const templateName=document.getElementById('templateName')?.value||''; const res=await api('/api/import/commit',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({rows:state.csvRows,mapping:state.mapping,template_name:templateName})}); state.queue=await api('/api/planning/queue'); alert(`${res.orders_created} orders geïmporteerd (${res.ready} ready, ${res.incomplete} incomplete)`); state.planningStep=3; render();}


async function clearQueue(){if(!confirm('Planning Queue en routes leegmaken?'))return; await api('/api/planning/queue',{method:'DELETE'}); state.queue=await api('/api/planning/queue'); state.mapState=await api('/api/map/state'); render();}

async function geocodeQueue(){
  state.geocodeResult=await api('/api/geocode/queue',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({limit:500, overwrite:false})});
  state.queue=await api('/api/planning/queue');
  render();
}

async function runOptimize(){state.optimizeResult=await api('/api/planning/optimize',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({})}); state.mapState=await api('/api/map/state'); state.selectedRouteId='all'; render();}
window.setPage=setPage; window.setStep=setStep; window.state=state; window.handleCsvUpload=handleCsvUpload; window.runSmartDetect=runSmartDetect; window.commitImport=commitImport; window.runOptimize=runOptimize; window.geocodeQueue=geocodeQueue; window.clearQueue=clearQueue; window.renderFieldCatalog=renderFieldCatalog; window.seedFleet=seedFleet; window.refreshFleet=refreshFleet; window.saveVehicle=saveVehicle; window.saveDriver=saveDriver; window.deleteVehicle=deleteVehicle; window.deleteDriver=deleteDriver; window.toggleEvFields=toggleEvFields;
init(); bootIntro();


/* v1.9.0 — Simplified AI Mapping + Control Center overrides */
function planning(){
  const steps=['Import','Controle','Routes klaar'];
  const current=state.planningStep<=2?state.planningStep:(state.planningStep===5?3:2);
  return shell(`<h1 class="pageTitle">Planning</h1><p class="subtitle">Upload orders, laat AlgoRoute controleren en optimaliseer zonder technische tussenstappen.</p><div class="steps simplifiedSteps">${steps.map((s,i)=>`<button onclick="setStep(${i+1})" class="step ${current===i+1?'active':''}">${i+1} ${s}</button>`).join('')}</div>${current===1?importStep():current===2?controlCenterStep():routesReadyStep()}`);
}
function mappingStep(){return controlCenterStep()}
function queueStep(){return controlCenterStep()}
function simplifiedStatus(){
  const q=state.queue?.summary||{}; const count=q.count||0; const ready=q.ready||0; const incomplete=q.incomplete||Math.max(0,count-ready); const orders=state.queue?.orders||[]; const gps=orders.filter(o=>o.latitude&&o.longitude).length;
  return {count,ready,incomplete,gps,needsGps:Math.max(0,count-gps)};
}
function controlCenterStep(){
  const st=simplifiedStatus(); const stats=mappingStats(); const hasCsv=state.csvHeaders.length>0;
  const allMapOk = hasCsv && !stats.missing.length && !stats.missingGroups.length;
  const canOptimize = st.count && (st.ready>0 || st.needsGps>0);
  return `<div class="controlCenter"><div class="controlHero card"><div><h2>Controlecentrum</h2><p class="muted">AlgoRoute controleert mapping, adressen, GPS en capaciteit. Alleen echte problemen blijven zichtbaar.</p></div><div class="controlHeroScore ${canOptimize?'ok':'warn'}"><b>${st.ready}/${st.count||0}</b><span>ready</span></div></div>
  <div class="controlGrid">
    <div class="controlTile card ${allMapOk?'ok':'warn'}"><div class="tileIcon">🧠</div><h3>Smart Mapping</h3><b>${hasCsv?(allMapOk?'Compleet':'Aandacht nodig'):'Nog geen CSV'}</b><p>${hasCsv?`${state.csvHeaders.length} kolommen geanalyseerd · ${stats.unmapped.length} ongemapt`:'Upload eerst een CSV.'}</p><button class="btn" onclick="toggleAdvancedMapping()">${allMapOk?'Mapping bekijken':'Mapping oplossen'}</button></div>
    <div class="controlTile card ${st.needsGps?'warn':'ok'}"><div class="tileIcon">📍</div><h3>Adressen & GPS</h3><b>${st.gps}/${st.count||0} met GPS</b><p>${st.needsGps?'PDOK/BAG kan ontbrekende GPS automatisch ophalen.':'Alle routebare orders hebben GPS.'}</p><button class="btn accent" onclick="geocodeQueue()">Adressen controleren</button></div>
    <div class="controlTile card ${st.incomplete?'warn':'ok'}"><div class="tileIcon">✅</div><h3>Route readiness</h3><b>${st.incomplete?`${st.incomplete} aandacht nodig`:'Klaar'}</b><p>${st.incomplete?'Orders zonder GPS of verplichte velden worden automatisch bekeken bij optimaliseren.':'Je kunt optimaliseren.'}</p><button class="btn accent" onclick="runOptimizeFromControl()">Optimaliseer routes</button></div>
  </div>
  ${state.optimizeResult?optimizeResultPanel(state.optimizeResult):''}
  <div id="advancedMapping" class="advancedMapping ${state.showAdvancedMapping?'open':''}">${hasCsv?aiMappingContent():`<div class="notice">Nog geen CSV geladen.</div>`}</div>
  ${st.count?problemList():''}</div>`;
}
function aiMappingContent(){
  const stats=mappingStats();
  const problemHeaders=state.csvHeaders.filter(h=>{const det=(state.detections||[]).find(d=>d.column===h); const fid=state.mapping[h]; const conf=det?.best?.score||0; return !fid || conf<82;});
  const goodCount=state.csvHeaders.length-problemHeaders.length;
  const showHeaders=problemHeaders.length?problemHeaders:state.csvHeaders.slice(0,8);
  return `<div class="aiMapping card"><div class="aiMapHead"><div><h2>AI Smart Mapping</h2><p class="muted">Alleen twijfelgevallen staan bovenaan. De rest is automatisch gekoppeld.</p></div><div class="aiScore"><b>${goodCount}/${state.csvHeaders.length}</b><span>zeker gekoppeld</span></div></div><div class="aiMapActions"><button class="btn accent" onclick="runSmartDetect()">Opnieuw analyseren</button><button class="btn" onclick="commitImportSimplified()">Importeer + controleer GPS</button><span class="badge ${problemHeaders.length?'orange':'green'}">${problemHeaders.length?problemHeaders.length+' checken':'alles OK'}</span></div>${problemHeaders.length?`<div class="notice">Controleer vooral deze ${problemHeaders.length} kolommen. Groene velden hoeven niet handmatig bekeken te worden.</div>`:`<div class="notice greenNotice">Mapping voelt goed. Je kunt direct importeren.</div>`}<div class="aiMapLayout"><div class="aiProblemGrid">${showHeaders.map(h=>mappingCard(h)).join('')}</div><div class="card panel fieldPicker premiumPicker"><h3>Veldbibliotheek</h3><p class="muted">Zoek alleen wanneer een kolom niet klopt.</p><input id="fieldSearch" class="input" placeholder="Zoek veld..." oninput="renderFieldCatalog(this.value)"><div id="fieldCatalog" class="fieldCatalog compactCatalog">${fieldCatalogHtml('')}</div></div></div></div>`;
}
function problemList(){const orders=(state.queue?.orders||[]); const problems=orders.filter(o=>o.status!=='ready').slice(0,12); if(!problems.length)return `<div class="card problemList ok"><h3>Geen blokkades</h3><p class="muted">Alle orders zijn klaar of worden bij optimaliseren automatisch gecontroleerd.</p></div>`; return `<div class="card problemList"><h3>Aandacht nodig</h3><p class="muted">We tonen alleen de eerste problemen. Optimize probeert GPS automatisch op te halen.</p>${problems.map(o=>`<div class="problemRow"><b>${escapeHtml(o.order_number)}</b><span>${escapeHtml(o.customer_name||'')}</span><em>${(o.missing||[]).includes('gps')?'GPS nodig':'gegevens missen'}</em><button class="btn tiny" onclick="geocodeQueue()">Fix GPS</button></div>`).join('')}</div>`}
function routesReadyStep(){return `<div class="workflowCard card"><h2>Routes klaar</h2><p class="muted">Bekijk het resultaat in Routes of Live Kaart.</p><div class="mappingToolbar"><button class="btn accent" onclick="setPage('routes')">Bekijk routes</button><button class="btn" onclick="setPage('live')">Open live kaart</button></div>${state.optimizeResult?optimizeResultPanel(state.optimizeResult):''}</div>`}
function toggleAdvancedMapping(){state.showAdvancedMapping=!state.showAdvancedMapping; render()}
async function commitImportSimplified(){await commitImport();}
async function runOptimizeFromControl(){state.optimizeResult=await api('/api/planning/optimize',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({})}); state.queue=await api('/api/planning/queue'); state.mapState=await api('/api/map/state'); if(state.optimizeResult?.ok){state.planningStep=3} render();}
// Override import commit: after commit, no blocking alert; show control center with PDOK result.
async function commitImport(){if(!state.csvRows.length)return alert('Geen CSV geladen'); const templateName=document.getElementById('templateName')?.value||''; const res=await api('/api/import/commit',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({rows:state.csvRows,mapping:state.mapping,template_name:templateName})}); state.queue=await api('/api/planning/queue'); state.geocodeResult=res.auto_geocode||null; state.planningStep=2; state.showAdvancedMapping=false; render();}

/* v2.0.0 — Planning Board Revolution + Ultra Smart Mapping UX */
function shell(content){
  const groups=[['CORE',[['dashboard','Dashboard','⌂'],['planning','Planning Board','▦'],['routes','Routes','⌘'],['live','Live Kaart','◎']]],['OPERATIONS',[['orders','Orders','□'],['load','Load Optimization','▣'],['vehicles','Wagenpark','▤'],['drivers','Chauffeurs','◉']]],['GROWTH',[['tracking','Klanttracking','◌'],['reports','Analytics','◍'],['settings','Instellingen','⚙']]]];
  return `<div class="shell"><aside class="sidebar"><div class="brand brandOfficial"><img class="brandFullLogo" src="/assets/algoroute-logo-sidebar-white-lime.png" alt="AlgoRoute"/></div>${groups.map(([g,items])=>`<div class="sectionLabel">${g}</div>${items.map(([id,label,icon])=>`<div onclick="setPage('${id}')" class="navItem ${state.page===id?'active':''}"><span class="navIcon">${icon}</span><span>${label}</span></div>`).join('')}`).join('')}<div class="sideFooter"><div>Planning suite</div><br><b>Stijn</b><div class="muted">Admin</div></div></aside><main class="main page-${state.page}"><div class="topbar"><div class="menuBtn">☰</div><div class="search">⌕ Zoek order, route, bus, regio of klant...</div><div class="topRight"><span class="sync">● Live sync actief</span><span>🔔</span><span>?</span><span class="avatar">S</span></div></div>${content}</main></div>`;
}
function planning(){return planningBoard();}
function routesInUseIds(){const ids=new Set(); (state.mapState?.routes||[]).forEach(r=>(r.stops||[]).forEach(s=>ids.add(String(s.id||s.order_id||'')))); return ids;}
function boardOrders(){const used=routesInUseIds(); return (state.queue?.orders||[]).filter(o=>!used.has(String(o.id||'')));}
function boardRoutes(){return state.mapState?.routes||[];}
function planningBoard(){
  const routes=boardRoutes(); const unplanned=boardOrders(); const q=state.queue?.summary||{}; const ready=q.ready||0; const count=q.count||0;
  return shell(`<section class="boardShell"><div class="boardHero"><div><h1 class="pageTitle">Planning Board</h1><p class="subtitle">Orders toevoegen, controleren, auto-plannen en daarna routes handmatig finetunen met drag & drop.</p></div><div class="boardHeroActions"><button class="btn" onclick="state.showAdvancedMapping=!state.showAdvancedMapping; render()">AI Mapping</button><button class="btn" onclick="geocodeQueue()">Controleer adressen</button><button class="btn accent" onclick="runOptimizeFromBoard()">Auto Plan</button></div></div>${boardTopStats(count,ready,routes,unplanned)}<div class="boardGrid"><aside class="ordersPane card">${ordersPane(unplanned)}</aside><section class="routesPane">${routes.length?routesBoard(routes):emptyRoutesBoard()}</section><aside class="insightsPane card">${boardInsights(routes)}</aside></div>${state.showAdvancedMapping?`<div class="boardDrawer">${state.csvHeaders.length?aiMappingContentV2():`<div class="card"><h2>AI Mapping</h2><p class="muted">Upload eerst een CSV via Orders toevoegen.</p></div>`}</div>`:''}</section>`);
}
function boardTopStats(count,ready,routes,unplanned){const activeStops=routes.reduce((a,r)=>a+(r.stops||[]).length,0); const totalKm=routes.reduce((a,r)=>a+Math.round((r.distance_m||0)/1000),0); const attention=Math.max(0,count-ready); return `<div class="boardStats"><div class="boardStat ok"><span>Orders</span><b>${count}</b><small>${ready} klaar · ${attention} aandacht</small></div><div class="boardStat blue"><span>Routes</span><b>${routes.length}</b><small>${activeStops} stops gepland</small></div><div class="boardStat"><span>Ongepland</span><b>${unplanned.length}</b><small>sleep naar route</small></div><div class="boardStat"><span>Afstand</span><b>${totalKm}</b><small>km totaal</small></div></div>`}
function ordersPane(unplanned){return `<div class="paneHead"><div><h2>Orders</h2><p class="muted">CSV/ERP orders komen hier binnen.</p></div><span class="badge ${unplanned.length?'orange':'green'}">${unplanned.length} ongepland</span></div><div class="importMini"><label class="miniUpload"><input id="csvFile" type="file" accept=".csv,.txt" onchange="handleCsvUpload(event)"><span>＋ CSV uploaden</span></label><button class="btn tiny" onclick="state.showAdvancedMapping=!state.showAdvancedMapping; render()">Mapping</button></div><div class="orderFilters"><input class="input" placeholder="Zoek order of plaats..." oninput="filterBoardOrders(this.value)"><button class="filterPill active">Ready</button><button class="filterPill">Urgent</button><button class="filterPill">Regio</button></div><div id="boardOrderList" class="boardOrderList">${unplanned.length?unplanned.slice(0,250).map(orderBoardCard).join(''):`<div class="emptyPane"><b>Geen ongeplande orders</b><span>Upload CSV of optimaliseer om routes te maken.</span></div>`}</div>`}
function orderBoardCard(o){const ready=o.status==='ready'; return `<div class="boardOrderCard ${ready?'ready':'warn'}" draggable="true" ondragstart="dragOrder(event,'${escapeHtml(o.id||'')}')" data-search="${escapeHtml(((o.order_number||'')+' '+(o.customer_name||'')+' '+(o.city||'')).toLowerCase())}"><div class="orderTop"><b>${escapeHtml(o.order_number||'Order')}</b><span class="statusDotMini ${ready?'ok':'warn'}"></span></div><div class="customerName">${escapeHtml(o.customer_name||'')}</div><div class="orderMeta"><span>📍 ${escapeHtml(o.city||'—')}</span><span>⚖ ${Math.round(o.weight_kg||0)} kg</span><span>▣ ${o.europallets||0} EP</span><span>⏱ ${o.service_time_minutes||15}m</span></div>${!ready?`<div class="orderIssue">${(o.missing||[]).includes('gps')?'GPS/adres check':'gegevens check'}</div>`:''}</div>`}
function routesBoard(routes){return `<div class="routesToolbar card"><div><h2>Route Board</h2><p class="muted">Versleep orders tussen routes. AlgoRoute zoekt na drop automatisch de beste invoegpositie.</p></div><div class="toolbarBtns"><button class="btn" onclick="setPage('routes')">Route overzicht</button><button class="btn" onclick="setPage('live')">Live kaart</button></div></div><div class="routeLaneGrid">${routes.map((r,i)=>routeLane(r,i)).join('')}</div>`}
function emptyRoutesBoard(){return `<div class="emptyBoard card"><h2>Nog geen routes</h2><p class="muted">Upload orders of importeer CSV, laat AI Mapping controleren en klik daarna op Auto Plan.</p><div class="emptyActions"><button class="btn accent" onclick="runOptimizeFromBoard()">Auto Plan starten</button><button class="btn" onclick="state.showAdvancedMapping=true; render()">AI Mapping openen</button></div></div>`}
function routeLane(r,i){const id=r.id||('route_'+(i+1)); const q=routeQuality(r); const locked=!!r.locked; const util=routeUtilization(r); const selected=state.selectedRouteId===id; return `<div class="routeLane card ${selected?'selected':''} ${locked?'locked':''}" ondragover="allowDrop(event,'${escapeHtml(id)}')" ondragleave="dragLeaveRoute(event)" ondrop="dropOrderOnRoute(event,'${escapeHtml(id)}')"><div class="routeLaneHead" onclick="selectBoardRoute('${escapeHtml(id)}')"><div><span class="routeDotBlue"></span><b>${escapeHtml(r.name||('Route '+(i+1)))}</b><small>${escapeHtml(r.vehicle_name||'Voertuig')}</small></div><button class="lockBtn" onclick="event.stopPropagation();toggleRouteLock('${escapeHtml(id)}',${locked?'false':'true'})">${locked?'🔒':'🔓'}</button></div><div class="routeKpis"><span><b>${q.stops}</b><small>stops</small></span><span><b>${q.km}</b><small>km</small></span><span><b>${fmtMin(q.total)}</b><small>totaal</small></span><span><b>${util}%</b><small>load</small></span></div><div class="capacityBar"><i style="width:${Math.min(100,util)}%"></i></div><div class="dropHint">Sleep order hierheen · AI insert</div><div class="laneStops">${(r.stops||[]).map((s,j)=>laneStopCard(s,j,id)).join('')}</div></div>`}
function laneStopCard(s,j,rid){return `<div class="laneStop" draggable="true" ondragstart="dragOrder(event,'${escapeHtml(s.id||s.order_id||'')}','${escapeHtml(rid)}')"><span class="stopBubble">${j+1}</span><div><b>${escapeHtml(s.order_number||'Stop')}</b><small>${escapeHtml(s.city||s.customer_name||'')}</small></div><em>${s.service_time_minutes||15}m</em><button class="splitMini" title="Split route vanaf hier" onclick="event.stopPropagation();splitRouteAt('${escapeHtml(rid)}',${j})">↯</button></div>`}
function routeUtilization(r){const l=r.load||{}; const kg=Number(l.weight_kg||0), ep=Number(l.europallets||0), rc=Number(l.roll_containers||0); return Math.min(99, Math.round(Math.max(ep/10,rc/12,kg/1500)*100));}
function boardInsights(routes){const selected=state.selectedRouteId&&state.selectedRouteId!=='all'?routes.find((r,i)=>(r.id||('route_'+(i+1)))===state.selectedRouteId):routes[0]; if(!selected)return `<h2>Insights</h2><p class="muted">Selecteer een route voor kaart en capaciteit.</p><div class="miniMapPlaceholder">Kaart verschijnt na optimalisatie</div>`; const q=routeQuality(selected); return `<div class="paneHead"><div><h2>Map & Insights</h2><p class="muted">Route focus volgt je selectie.</p></div><span class="badge blue">${escapeHtml(selected.name||'Route')}</span></div><div class="boardMapMini">${mapCard('Planning board map',false)}</div><div class="insightGrid"><div><b>${q.stops}</b><span>Stops</span></div><div><b>${q.km}</b><span>km</span></div><div><b>${fmtMin(q.drive)}</b><span>Rijtijd</span></div><div><b>${fmtMin(q.service)}</b><span>Service</span></div><div><b>${fmtMin(q.total)}</b><span>Totaal</span></div><div><b>${routeUtilization(selected)}%</b><span>Load</span></div></div><div class="aiSuggestion"><b>🧠 AlgoRoute Assist</b><span>Sleep een order op een route. De engine voegt hem automatisch in op de beste positie en werkt afstand, ETA en load bij.</span></div>`}
function aiMappingContentV2(){
  const stats=mappingStats();
  const problemHeaders=state.csvHeaders.filter(h=>{const det=(state.detections||[]).find(d=>d.column===h); const fid=state.mapping[h]; const conf=det?.best?.score||0; return !fid || conf<78;});
  const certain=state.csvHeaders.length-problemHeaders.length;
  const autoRows=state.csvHeaders.filter(h=>!problemHeaders.includes(h)).slice(0,18);
  return `<div class="aiMappingV2 card"><div class="aiMapHead"><div><h2>AI Mapping Assistant</h2><p class="muted">Synoniemen, typo's, units, waardeprofielen en kolomgroepen worden gecombineerd. Alleen echte twijfel blijft over.</p></div><div class="aiScore"><b>${certain}/${state.csvHeaders.length}</b><span>automatisch</span></div></div><div class="aiMapActions"><button class="btn accent" onclick="runSmartDetect()">Opnieuw analyseren</button><button class="btn" onclick="commitImportSimplified()">Bevestig + importeer</button><span class="badge ${problemHeaders.length?'orange':'green'}">${problemHeaders.length?problemHeaders.length+' checken':'alles herkend'}</span></div>${problemHeaders.length?`<div class="aiProblemGrid">${problemHeaders.map(h=>mappingCard(h)).join('')}</div>`:`<div class="notice greenNotice"><b>Alles ziet er goed uit.</b><br>De mapping is zeker genoeg om direct te importeren.</div>`}<details class="autoMappedList"><summary>Automatisch herkend (${autoRows.length} tonen)</summary>${autoRows.map(h=>{const fid=state.mapping[h]; return `<div><b>${escapeHtml(h)}</b><span>${escapeHtml(labelForField(fid)||fid||'')}</span></div>`}).join('')}</details></div>`;
}
function selectBoardRoute(id){state.selectedRouteId=id; render();}
function filterBoardOrders(q){q=String(q||'').toLowerCase(); document.querySelectorAll('.boardOrderCard').forEach(el=>{el.style.display=el.dataset.search.includes(q)?'':'none';});}
function dragOrder(ev,orderId,sourceRouteId=''){ev.dataTransfer.setData('text/plain', JSON.stringify({orderId,sourceRouteId})); ev.dataTransfer.effectAllowed='move'; setTimeout(()=>ev.target?.classList?.add('dragging'),0);}
function allowDrop(ev,routeId){ev.preventDefault(); const lane=ev.currentTarget; lane.classList.add('dragOver');}
function dragLeaveRoute(ev){ev.currentTarget.classList.remove('dragOver');}
async function dropOrderOnRoute(ev,routeId){ev.preventDefault(); ev.currentTarget.classList.remove('dragOver'); let data={}; try{data=JSON.parse(ev.dataTransfer.getData('text/plain')||'{}')}catch(e){} if(!data.orderId)return; state.boardBusy=true; try{const res=await api('/api/planning/board/move-order',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({order_id:data.orderId,target_route_id:routeId})}); if(!res.ok) alert(res.reason||'Verplaatsen mislukt'); state.mapState=await api('/api/map/state'); state.queue=await api('/api/planning/queue'); state.selectedRouteId=routeId;}catch(e){alert('Drag/drop update mislukt: '+e.message)} state.boardBusy=false; render();}
async function toggleRouteLock(routeId,locked){await api('/api/planning/board/lock-route',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({route_id:routeId,locked})}); state.mapState=await api('/api/map/state'); render();}
async function splitRouteAt(routeId,index){if(index<1)return alert('Split vanaf stop 2 of later.'); const res=await api('/api/planning/board/split-route',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({route_id:routeId,index})}); if(!res.ok) alert(res.reason||'Split mislukt'); state.mapState=await api('/api/map/state'); render();}
async function runOptimizeFromBoard(){state.optimizeResult=await api('/api/planning/optimize',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({})}); state.queue=await api('/api/planning/queue'); state.mapState=await api('/api/map/state'); if(state.optimizeResult?.ok) state.selectedRouteId='all'; render();}
function render(){const pages={dashboard,live,planning,routes,vehicles,drivers,orders:()=>planningBoard(),load:()=>simple('Load Optimization','Pallets, rolcontainers, LIFO en later 2D/3D belading.'),tracking:()=>simple('Klanttracking','Trackinglinks en klantmeldingen.'),reports:()=>simple('Analytics','Punctualiteit, routekwaliteit, load en EV.'),settings}; document.getElementById('app').innerHTML=(pages[state.page]||dashboard)(); setTimeout(initMap,80);}
window.dragOrder=dragOrder; window.allowDrop=allowDrop; window.dropOrderOnRoute=dropOrderOnRoute; window.dragLeaveRoute=dragLeaveRoute; window.selectBoardRoute=selectBoardRoute; window.toggleRouteLock=toggleRouteLock; window.splitRouteAt=splitRouteAt; window.runOptimizeFromBoard=runOptimizeFromBoard; window.filterBoardOrders=filterBoardOrders;
