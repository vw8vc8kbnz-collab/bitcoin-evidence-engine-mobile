import Link from "next/link";
import { read } from "@/lib/store";
import { getUser } from "@/lib/auth";
import { sweepOrders, getPartnerWallet } from "@/lib/data";
import { financeSafetyMode, getFinanceSnapshot, getPaymentProviderStatus } from "@/lib/payments";
import { Mark } from "@/components/icons";
import { Empty } from "@/components/Empty";

export const dynamic = "force-dynamic";

const money = (cents: number) => {
  const n = Math.round(cents || 0);
  const sign = n < 0 ? "- " : "";
  return sign + new Intl.NumberFormat("nl-NL", { style: "currency", currency: "EUR", minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(Math.abs(n) / 100);
};
const day = (iso: string) => new Date(iso).toLocaleDateString("nl-NL", { day: "numeric", month: "short" });
const time = (iso: string) => new Date(iso).toLocaleString("nl-NL", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
const statusLabel = (s: string) => s.replaceAll("_", " ").toUpperCase();

export default async function Geld() {
  await sweepOrders();
  const db = await read();
  const user = await getUser();
  const sellerSlug = user?.partnerSlug;
  const orders = db.orders.filter(o => o.sellerSlug === sellerSlug).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  const wallet = sellerSlug ? await getPartnerWallet(sellerSlug) : null;
  const finance = sellerSlug ? await getFinanceSnapshot(sellerSlug) : null;
  const provider = getPaymentProviderStatus();
  const safety = financeSafetyMode();

  const available = wallet?.summary.availableCents ?? 0;
  const reserved = wallet?.summary.reservedCents ?? 0;
  const escrowCents = orders.filter(o => !["paid_out", "cancelled"].includes(o.status)).reduce((s, o) => s + Math.round(o.sellerNet * 100), 0);
  const paid30Cents = orders.filter(o => o.status === "paid_out" && Date.now() - +new Date(o.createdAt) < 30 * 864e5).reduce((s, o) => s + Math.round(o.sellerNet * 100), 0);
  const commission30Cents = orders.filter(o => Date.now() - +new Date(o.createdAt) < 30 * 864e5).reduce((s, o) => s + Math.round(o.commission * 100), 0);

  const ledger = wallet?.ledger ?? [];
  const latestOrders = orders.slice(0, 4);
  const totalTracked = Math.max(1, Math.abs(available) + Math.abs(reserved) + Math.abs(escrowCents) + Math.abs(paid30Cents) + Math.abs(commission30Cents));
  const escrowPct = Math.round((Math.abs(escrowCents) / totalTracked) * 100);
  const reservedPct = Math.round((Math.abs(reserved) / totalTracked) * 100);
  const availablePct = Math.round((Math.abs(available) / totalTracked) * 100);
  const ledgerPreview = ledger.slice(0, 6);

  return (
    <main className="page partnerScreen realWalletScreen">
      <header className="walletTopbar">
        <Link href="/partner" className="walletMenu" aria-label="Dashboard"><Mark glow /></Link>
        <div><h1>Wallet</h1><span><i /> {finance?.mode === "live" ? "Live" : "Test preview"} · {provider.label}</span></div>
        <Link href="/meldingen" className="walletBell" aria-label="Meldingen"><svg viewBox="0 0 24 24"><path d="M6 10a6 6 0 1112 0c0 4 1.5 5.5 1.5 5.5h-15S6 14 6 10z"/><path d="M10.5 19a1.8 1.8 0 003 0"/></svg></Link>
      </header>

      {!sellerSlug && <Empty title="Geen partnerwallet" text="Je partneraccount is nodig om je wallet te openen." />}

      {sellerSlug && (
        <>
          <section className="walletBalanceCard">
            <div className="walletCardHead"><span>Totaal saldo</span><b>EUR</b></div>
            <strong>{money(available)}</strong>
            <p><i /> Beschikbaar saldo</p>
            <div className="walletButtons">
              <button disabled={!safety.liveUnlocked}>Uitbetaling aanvragen <svg viewBox="0 0 24 24"><path d="M12 16V4m0 0l-4 4m4-4l4 4"/><path d="M5 14v4h14v-4"/></svg></button>
              <Link href="/partner/promoten">Promoot saldo <svg viewBox="0 0 24 24"><path d="M7 17L17 7M10 7h7v7"/></svg></Link>
            </div>
            <div className="walletCardGhost"><svg viewBox="0 0 80 70"><path d="M14 20h42a12 12 0 0112 12v20a8 8 0 01-8 8H14A12 12 0 012 48V32a12 12 0 0112-12z"/><path d="M18 12h42a8 8 0 018 8v8"/><path d="M54 36h18v12H54a6 6 0 010-12z"/><circle cx="58" cy="42" r="2"/></svg></div>
          </section>

          <section className="walletMetricStrip">
            <div><span className="micon lock">▣</span><small>In escrow</small><b>{money(escrowCents)}</b><em>{orders.filter(o => !["paid_out", "cancelled"].includes(o.status)).length} orders</em></div>
            <div><span className="micon bookmark">⌑</span><small>Gereserveerd</small><b>{money(reserved)}</b><em>Campagnes</em></div>
            <div><span className="micon up">↥</span><small>Uitbetaald</small><b>{money(paid30Cents)}</b><em>30 dagen</em></div>
            <div><span className="micon fee">%</span><small>Commissie</small><b>{money(commission30Cents)}</b><em>30 dagen</em></div>
          </section>

          <section className="walletQuickActions">
            <h2>Snelle acties</h2>
            <div>
              <button disabled={!safety.liveUnlocked}><span>↥</span>Uitbetaling</button>
              <Link href="#transacties"><span>☷</span>Transacties</Link>
              <Link href="/partner/orders"><span>▤</span>Orders</Link>
              <Link href="/partner/promoten"><span>◇</span>Campagnes</Link>
              <button disabled><span>□</span>Facturen</button>
            </div>
          </section>

          <section id="transacties" className="walletTransactions">
            <div className="walletSectionHead"><h2>Recente transacties</h2><Link href="#grootboek">Alles bekijken</Link></div>
            {ledgerPreview.length === 0 && <p className="walletMuted">Nog geen transacties. Nieuwe orders, refunds, commissies en uitbetalingen komen hier als walletregels te staan.</p>}
            {ledgerPreview.map(tx => {
              const incoming = tx.creditAccount.includes(":wallet") || tx.creditAccount.includes(":escrow");
              const tag = tx.type.replaceAll("_", " ").toUpperCase();
              return <article key={tx.id} className="walletTx">
                <span className={`txIcon ${incoming ? "in" : "out"}`}>{incoming ? "↓" : "−"}</span>
                <b>{tx.note ?? tx.type}<small>{time(tx.at)} · {tx.type}</small></b>
                <em>{tag}</em>
                <strong>{incoming ? "+ " : "- "}{money(tx.amountCents)}</strong>
              </article>;
            })}
          </section>

          <section className="walletDonutPanel">
            <div className="walletDonut" style={{ background: `conic-gradient(#23d0b3 0 ${escrowPct}%, #f1a632 ${escrowPct}% ${escrowPct + reservedPct}%, #3698ff ${escrowPct + reservedPct}% ${escrowPct + reservedPct + availablePct}%, rgba(255,255,255,.08) ${escrowPct + reservedPct + availablePct}% 100%)` }}><span>Totaal<br/><b>{money(escrowCents + available + reserved)}</b></span></div>
            <div className="walletLegend">
              <p><i className="a"/>In escrow <b>{money(escrowCents)}</b></p>
              <p><i className="b"/>Gereserveerd <b>{money(reserved)}</b></p>
              <p><i className="c"/>Beschikbaar <b>{money(available)}</b></p>
              <p><i className="d"/>Uitbetaald 30d <b>{money(paid30Cents)}</b></p>
            </div>
          </section>

          {latestOrders.length > 0 && <section className="walletOrdersCompact">
            <div className="walletSectionHead"><h2>Orders in je wallet</h2><Link href="/partner/orders">Open orders</Link></div>
            {latestOrders.map(o => <Link href={`/partner/orders/${o.id}`} key={o.id} className="walletOrderLine"><b>{o.itemTitle}<small>{o.id} · {day(o.createdAt)} · {statusLabel(o.status)}</small></b><span>{["paid_out", "cancelled"].includes(o.status) ? "AFGEROND" : "IN ESCROW"}</span><strong>{money(Math.round(o.sellerNet * 100))}</strong></Link>)}
          </section>}

          <section className="walletSafetyCard">
            <span>{safety.label}</span>
            <p>{safety.message}</p>
            <small>AI mag adviseren, maar nooit zelfstandig geld verplaatsen. Uitbetalingen blijven geblokkeerd totdat live payments expliciet veilig zijn vrijgegeven.</small>
          </section>

          <section id="grootboek" className="walletLedgerMini">
            <div className="walletSectionHead"><h2>Financieel grootboek</h2><span>Append-only</span></div>
            {ledger.slice(6, 14).map(tx => <article key={tx.id} className="walletTx compact"><span className="txIcon ledger">•</span><b>{tx.note ?? tx.type}<small>{time(tx.at)} · {tx.type}</small></b><strong>{money(tx.amountCents)}</strong></article>)}
          </section>
        </>
      )}
    </main>
  );
}
