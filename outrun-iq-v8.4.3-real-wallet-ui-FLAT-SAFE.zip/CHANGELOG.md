# v8.4.3 — Real Wallet UI

- Zakelijke Wallet vervangen door een echte wallet-app ervaring in plaats van een finance-informatiepagina.
- Grote saldo-card toegevoegd met beschikbaar saldo, currency-chip, payout/promote acties en wallet-visual.
- Wallet metrics toegevoegd: in escrow, gereserveerd, uitbetaald 30 dagen en commissie 30 dagen.
- Snelle acties toegevoegd: Uitbetaling, Transacties, Orders, Campagnes en Facturen.
- Recente transacties prominenter gemaakt met inkomend/uitgaand visueel onderscheid.
- Saldo-overzicht met donut/legend toegevoegd.
- Orders blijven bereikbaar vanuit Dashboard en Wallet; onderbalk blijft Wallet.
- Safety/AI guard blijft zichtbaar, maar ondergeschikt aan de wallet UX.
- Finance hardening uit v8.4.2 blijft behouden.
