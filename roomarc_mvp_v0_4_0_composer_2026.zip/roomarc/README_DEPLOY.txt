ROOMARC v0.4.0 — Composer 2026

Install/update op VPS na upload naar GitHub:

cd ~ && rm -rf roomarc-src roomarc-unpack roomarc && git clone https://github.com/vw8vc8kbnz-collab/bitcoin-evidence-engine-mobile.git roomarc-src && mkdir -p roomarc-unpack && unzip -oq roomarc-src/roomarc_mvp_v0_4_0_composer_2026.zip -d roomarc-unpack && bash roomarc-unpack/install_roomarc.sh

Open daarna:
http://51.195.102.180:8899

Demo-login:
demo@roomarc.local / demo123

Belangrijk:
- Stop eerst de draaiende Roomarc server met CTRL+C.
- De app draait los van de Bitcoin Evidence Engine.
- Uploads/testdata blijven in ~/roomarc_data.
