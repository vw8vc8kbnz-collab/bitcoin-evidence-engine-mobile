Roomarc MVP v0.5.0 — Premium Composer 2.0

Install/update command after uploading this ZIP to GitHub:

cd ~ && rm -rf roomarc-src roomarc-unpack roomarc && git clone https://github.com/vw8vc8kbnz-collab/bitcoin-evidence-engine-mobile.git roomarc-src && mkdir -p roomarc-unpack && unzip -oq roomarc-src/roomarc_mvp_v0_5_0_premium_composer.zip -d roomarc-unpack && bash roomarc-unpack/install_roomarc.sh

Open:
http://51.195.102.180:8899

Demo:
demo@roomarc.local / demo123

Notes:
- Bitcoin Evidence Engine remains separate on port 8787.
- CTRL+C only stops the foreground Roomarc dev server.
- This build contains bundled frontend/dist, so npm is not required on the VPS.
