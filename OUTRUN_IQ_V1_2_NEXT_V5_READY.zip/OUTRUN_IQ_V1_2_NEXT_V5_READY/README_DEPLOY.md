# OUTRUN IQ V1.2 — Next v5 VPS-ready

Basis: jouw aangeleverde `outrun-iq-v5-app(1).zip` + technische overdracht.

Gecontroleerd:
- `npm install` werkt
- `npm run build` werkt
- `npm run start` draait op `0.0.0.0:8795`
- `curl http://127.0.0.1:8795/` geeft HTTP 200

Belangrijk:
- Dit is een echte Next.js app, geen statische mockup en geen Python/FastAPI app.
- Node.js/npm zijn nodig op de VPS.
- Productfoto's zijn remote Unsplash-links met SVG fallback.

## Start lokaal/VPS handmatig

```bash
npm ci
npm run build
HOST=0.0.0.0 PORT=8795 npm run start
```

## URL

http://51.195.102.180:8795/
