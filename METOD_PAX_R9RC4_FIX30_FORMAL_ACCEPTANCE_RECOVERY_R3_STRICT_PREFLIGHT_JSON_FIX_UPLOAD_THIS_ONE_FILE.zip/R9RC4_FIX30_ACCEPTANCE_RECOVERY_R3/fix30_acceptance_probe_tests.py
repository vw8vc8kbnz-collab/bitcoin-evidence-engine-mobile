#!/usr/bin/env python3
from __future__ import annotations

import copy
import importlib.util
import json
import os
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("fix30_acceptance_probe", ROOT / "fix30_acceptance_probe.py")
assert SPEC and SPEC.loader
PROBE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(PROBE)


def base_snapshot(phase: str) -> dict:
    health_scope = {
        "live": {"ok": True, "build": PROBE.EXPECTED_BUILD},
        "ready": {"ok": True, "build": PROBE.EXPECTED_BUILD},
    }
    return {
        "schemaVersion": 1,
        "phase": phase,
        "releaseRevision": PROBE.EXPECTED_REVISION,
        "releaseManifestSha256": "a" * 64,
        "previewOrigin": "https://example.trycloudflare.com",
        "services": {"metod-pax.service": "active", "nginx": "active", "nginxConfig": "valid"},
        "stateCounts": {
            "entries": 100,
            "files": 80,
            "directories": 20,
            "catalogRecords": 597,
            "activeCatalogRecords": 597,
            "activeAdmins": 1,
        },
        "criticalStateHashes": {name: str(index) * 64 for index, name in enumerate(PROBE.CRITICAL_STATE_FILES, 1)},
        "health": {name: copy.deepcopy(health_scope) for name in ("backend", "localEdge", "externalPreview")},
        "assetProof": {path: {"sha256": "b" * 64, "bytes": 42, "originsEqual": True} for path in PROBE.ASSET_PATHS},
    }


def standalone_result(**overrides: object) -> dict:
    value = {
        "schemaVersion": 1,
        "gate": PROBE.STANDALONE_GATE,
        "status": "PASS",
        "artifactSha256": PROBE.EXPECTED_INNER_SHA256,
        "fullPreflightExitCode": 0,
        "releaseRevision": "R9RC4",
    }
    value.update(overrides)
    return value


class Fix30AcceptanceProbeTests(unittest.TestCase):
    def test_01_origin_is_exact_and_canonical(self) -> None:
        self.assertEqual(
            PROBE.validate_origin("https://example.trycloudflare.com/"),
            "https://example.trycloudflare.com",
        )
        for invalid in (
            "http://example.trycloudflare.com",
            "https://Example.trycloudflare.com",
            "https://user@example.trycloudflare.com",
            "https://example.trycloudflare.com/path",
            "https://example.trycloudflare.com/?x=1",
        ):
            with self.subTest(invalid=invalid), self.assertRaises(PROBE.AcceptanceError):
                PROBE.validate_origin(invalid)

    def test_02_equal_snapshots_pass_even_if_non_authoritative_counts_grow(self) -> None:
        before = base_snapshot("pre")
        after = base_snapshot("post")
        after["stateCounts"]["entries"] += 2
        after["stateCounts"]["files"] += 2
        self.assertEqual(PROBE.compare_snapshots(before, after)["status"], "PASS")

    def test_03_critical_state_drift_fails(self) -> None:
        before = base_snapshot("pre")
        after = base_snapshot("post")
        after["criticalStateHashes"]["material_library.json"] = "f" * 64
        with self.assertRaisesRegex(PROBE.AcceptanceError, "kritieke externe state"):
            PROBE.compare_snapshots(before, after)

    def test_04_catalog_admin_or_manifest_drift_fails(self) -> None:
        for mutation in ("catalogRecords", "activeCatalogRecords", "activeAdmins"):
            before = base_snapshot("pre")
            after = base_snapshot("post")
            after["stateCounts"][mutation] += 1
            with self.subTest(mutation=mutation), self.assertRaises(PROBE.AcceptanceError):
                PROBE.compare_snapshots(before, after)
        before = base_snapshot("pre")
        after = base_snapshot("post")
        after["releaseManifestSha256"] = "f" * 64
        with self.assertRaisesRegex(PROBE.AcceptanceError, "releasemanifest"):
            PROBE.compare_snapshots(before, after)

    def test_05_service_asset_or_health_drift_fails(self) -> None:
        mutations = []
        service = base_snapshot("post")
        service["services"]["nginx"] = "inactive"
        mutations.append(service)
        asset = base_snapshot("post")
        asset["assetProof"][PROBE.ASSET_PATHS[0]]["sha256"] = "e" * 64
        mutations.append(asset)
        health = base_snapshot("post")
        health["health"]["externalPreview"]["ready"]["ok"] = False
        mutations.append(health)
        for after in mutations:
            with self.subTest(after=after), self.assertRaises(PROBE.AcceptanceError):
                PROBE.compare_snapshots(base_snapshot("pre"), after)

    def test_06_latest_recent_regular_backup_is_selected(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            old = root / "system_backup_auto_20260901_000000_123456_012345.zip"
            # This is the exact shape emitted by Admin. The hexadecimal nonce
            # intentionally contains a-f to prevent the R1 regression.
            new = root / "system_backup_manual_20260902_000000_654321_a1b2c3.zip"
            old.write_bytes(b"old")
            new.write_bytes(b"new")
            now = datetime.now(timezone.utc).timestamp()
            os.utime(old, (now - 60, now - 60))
            os.utime(new, (now, now))
            self.assertEqual(PROBE.select_latest_backup(root, 7), new)

    def test_07_backup_symlink_and_unexpected_names_are_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            target = root / "payload.zip"
            target.write_bytes(b"payload")
            (root / "system_backup_auto_20260902_000000_123456_a1b2c3.zip").symlink_to(target)
            (root / "system_backup_hacked.zip").write_bytes(b"x")
            with self.assertRaisesRegex(PROBE.AcceptanceError, "geen veilig"):
                PROBE.select_latest_backup(root, 7)

    def test_08_backup_name_contract_matches_admin_runtime_exactly(self) -> None:
        valid = (
            "system_backup_manual_20260903_022500_123456_a1b2c3.zip",
            "system_backup_auto_20260903_022500_123456_00ff99.zip",
        )
        invalid = (
            "system_backup_manual_20260903T022500Z.zip",
            "system_backup_manual_20260903_022500_123456_ABCDE0.zip",
            "system_backup_manual_20260903_022500_123456_a1b2c3.zip.tmp",
            "system_backup_manual_20260903_022500_123456_a1b2c3/zip",
        )
        for name in valid:
            with self.subTest(valid=name):
                self.assertIsNotNone(PROBE.BACKUP_NAME.fullmatch(name))
        for name in invalid:
            with self.subTest(invalid=name):
                self.assertIsNone(PROBE.BACKUP_NAME.fullmatch(name))

    def test_09_restore_proof_must_be_real_and_identical(self) -> None:
        proof = {
            "ok": True,
            "backupSha256": "a" * 64,
            "manifestSha256": "b" * 64,
            "stateFileCount": 123,
            "totalBytes": 456,
        }
        result = PROBE.validate_restore(proof, dict(proof))
        self.assertTrue(result["isolatedRestore"])
        corrupt = dict(proof)
        corrupt["totalBytes"] = 457
        with self.assertRaisesRegex(PROBE.AcceptanceError, "verschillen"):
            PROBE.validate_restore(proof, corrupt)

    def test_10_noisy_standalone_output_yields_one_strict_json_result(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            raw_log = root / "standalone.log"
            output = root / "standalone.json"
            raw_log.write_text(
                "OK:   SHA256SUMS.txt is regulier en aanwezig\n"
                "RESULTAAT: PASS\n"
                + json.dumps(standalone_result(), sort_keys=True)
                + "\n",
                encoding="utf-8",
            )
            result = PROBE.extract_standalone_result(raw_log, output)
            self.assertEqual(result["status"], "PASS")
            self.assertEqual(PROBE.read_object(output), standalone_result())

    def test_11_standalone_extraction_rejects_missing_duplicate_or_forged_result(self) -> None:
        cases = {
            "missing": "OK: preflight\n",
            "duplicate": "\n".join(
                (json.dumps(standalone_result()), json.dumps(standalone_result()))
            ),
            "forged": json.dumps(standalone_result(artifactSha256="f" * 64)),
        }
        for label, content in cases.items():
            with self.subTest(label=label), tempfile.TemporaryDirectory() as temp:
                root = Path(temp)
                raw_log = root / "standalone.log"
                raw_log.write_text(content + "\n", encoding="utf-8")
                with self.assertRaises(PROBE.AcceptanceError):
                    PROBE.extract_standalone_result(raw_log, root / "standalone.json")

    def test_12_complete_phase_8_finalize_accepts_extracted_machine_result(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            evidence = root / "evidence"
            evidence.mkdir()
            raw_log = evidence / "standalone.log"
            raw_log.write_text(
                "METOD/PAX preflight\n"
                "OK: alle controles\n"
                + json.dumps(standalone_result(), sort_keys=True)
                + "\n",
                encoding="utf-8",
            )
            PROBE.extract_standalone_result(raw_log, evidence / "standalone.json")

            pre = base_snapshot("pre")
            post = base_snapshot("post")
            recovery = base_snapshot("recovery")
            PROBE.atomic_json(evidence / "pre-snapshot.json", pre)
            PROBE.atomic_json(evidence / "post-snapshot.json", post)
            PROBE.atomic_json(evidence / "recovery-snapshot.json", recovery)
            PROBE.atomic_json(
                evidence / "deploy-comparison.json",
                PROBE.compare_snapshots(pre, post),
            )
            PROBE.atomic_json(
                evidence / "recovery-comparison.json",
                PROBE.compare_snapshots(post, recovery),
            )
            restore = {
                "ok": True,
                "backupSha256": "c" * 64,
                "manifestSha256": "d" * 64,
                "stateFileCount": 123,
                "totalBytes": 456,
            }
            PROBE.atomic_json(evidence / "restore-proof.json", restore)
            PROBE.atomic_json(evidence / "restore-output.json", restore)

            output_zip = root / "evidence.zip"
            result = PROBE.finalize(
                evidence,
                output_zip,
                ROOT / "FIX30_ACCEPTANCE_RECOVERY_CONTRACT.json",
            )
            self.assertEqual(result["report"]["status"], "PASS")
            self.assertTrue(output_zip.is_file())
            report = PROBE.read_object(evidence / "FIX30_ACCEPTANCE_RECOVERY_R3_REPORT.json")
            self.assertEqual(report["contractId"], "R9RC4_FIX30_FORMAL_ACCEPTANCE_RECOVERY_R3")


if __name__ == "__main__":
    unittest.main(verbosity=2)
