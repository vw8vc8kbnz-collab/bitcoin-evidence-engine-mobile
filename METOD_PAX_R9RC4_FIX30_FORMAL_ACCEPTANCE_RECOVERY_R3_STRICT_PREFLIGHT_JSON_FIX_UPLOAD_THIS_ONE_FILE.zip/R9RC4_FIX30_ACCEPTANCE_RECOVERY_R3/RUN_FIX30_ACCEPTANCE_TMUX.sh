#!/usr/bin/env bash
set -uo pipefail
export PATH=/usr/sbin:/usr/bin:/sbin:/bin

LOG_PATH="${1:?logpad ontbreekt}"
RUN_DIR="${2:?tijdelijke runmap ontbreekt}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

[[ "$LOG_PATH" =~ ^/home/ubuntu/METOD_FIX30_ACCEPTANCE_R3_[A-Za-z0-9._-]+\.log$ ]] \
  || { echo "Onveilig acceptatielogpad" >&2; exit 1; }
[[ "$RUN_DIR" =~ ^/tmp/metod-fix30-acceptance\.[A-Za-z0-9]+$ ]] \
  || { echo "Onveilige tijdelijke acceptatiemap" >&2; exit 1; }
[[ -d "$RUN_DIR" && ! -L "$RUN_DIR" && "$SCRIPT_DIR" == "$RUN_DIR/R9RC4_FIX30_ACCEPTANCE_RECOVERY_R3" ]] \
  || { echo "Tijdelijke acceptatiemap is niet exact gebonden" >&2; exit 1; }

bash "$SCRIPT_DIR/RUN_FIX30_ACCEPTANCE_RECOVERY.sh" 2>&1 | tee "$LOG_PATH"
RUN_RC="${PIPESTATUS[0]}"

cd /home/ubuntu || exit 1
chmod -R u+w -- "$RUN_DIR" 2>/dev/null || true
rm -rf -- "$RUN_DIR"

echo
echo "FIX30_ACCEPTANCE_R3_EXIT=$RUN_RC"
echo "LOG=$LOG_PATH"
echo "Deze tmux-sessie blijft open voor controle. Typ exit om hem te sluiten."
exec bash --noprofile --norc
