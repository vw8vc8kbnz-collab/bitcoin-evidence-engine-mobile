# R9RC1 professionele architectuurafronding

## Status

R9RC1 is een **interne auditkandidaat**. De actuele bron-, architectuur-,
security-, privacy-, lifecycle- en artifacttests zijn groen. De kandidaat is
desondanks `PROVISIONAL_DEVELOPMENT_ONLY`, `releaseEligible=false` en
`productionGo=false`: exact dit artifact moet nog extern worden getest in
Chromium, WebKit, op de VPS en op echte iPhone Safari.

## Professionele splitsing

- `app/toolA.html`: 792 regels, alleen semantische markup, één externe
  stylesheet en drie externe scripts.
- Inline `<style>`, inline `<script>`, `style=`, `on…=` en `javascript:` in de
  klant-shell: allemaal nul.
- CSS: 11 canonieke bronbestanden, deterministisch samengebouwd tot
  `tool-a/styles/tool-a.bundle.css`.
- Klassieke JavaScript-runtime: 77 canonieke bronnen. Het enige resterende
  grote legacybronsegment is byte-exact verdeeld over 13 `.jsfrag`-bestanden;
  grootste fragment 886 regels. De publieke bundle wordt reproduceerbaar
  gegenereerd en de fragmenten zijn niet publiek routeerbaar.
- Moderne frontend: 19 expliciet toegestane ES-modules; tijdelijke
  `window.ToolAR9Foundation`-compatibiliteitsglobal verwijderd.
- `app/server_py.py`: 22 regels en uitsluitend executable/import boundary.
- `metod_app/runtime/application.py`: 1.101 regels en uitsluitend de ene
  compatibility/composition root; geen HTTP-handlerklasse en geen import-time
  directory-I/O.
- Service-wiring: apart in `metod_app/runtime/composition.py` (388 regels).
- HTTP-handler: 25 regels, samengesteld uit vijf begrensde mixins.
- Uitgepakte domeinmodules: maximaal 987 regels; expliciete eigenaren voor
  HTTP, jobs, requests, catalogus, pricing, opslag, notificaties en
  observability.

De live runtime-injectie in enkele `*Runtime`-klassen is bewust behouden als
compatibiliteitsnaad voor bestaande operationele monkeypatch-/instrumentatietests.
Er is één live state-eigenaar; er is geen gekopieerde façade-state.

## Security en klantgegevens

- Admincredentials zijn file-only, plaintext/shared credentials zijn in
  production verboden, PBKDF2-SHA256 gebruikt 600.000 iteraties en TOTP is
  verplicht.
- Klantpayloads, requests, jobs, toegangstokens, idempotencyclaims en archieven
  staan in `0700`-mappen; klant-/secret-JSON wordt `0600` geschreven.
- JSONL-log-/indexwriters dwingen `0640` af, ook bij reeds bestaande te ruime
  bestanden. De requestindex bevat geen naam, e-mail, telefoon, adres of
  canceltoken.
- System-events negeren `customer_name`; tekst en gestructureerde details
  worden geredigeerd. Losse Bearerwaarden, Authorization/Cookie-waarden,
  e-mail, telefoon, postcode en IP-adressen worden afgeschermd.
- De browser schrijft geen klant-PII naar local/session storage en onderschept
  de globale console niet.
- De publieke static policy is een allowlist. Pythonbron, configuratie, state,
  manifests, canonieke bundlebronnen en `.jsfrag`-bestanden worden geweigerd.
- CSP blokkeert inline/eventscripts, externe code, objecten en framing. De
  resterende `style-src-attr 'unsafe-inline'` is expliciet begrensd tot bewezen
  legacy-CSSOM-mutaties; markup-, template- en dynamische style-elementowners
  zijn nul.
- De supply-chaingate scant 545 bestanden, waaronder `.jsfrag`: nul gevonden
  secrets, nul verboden Python-sinks, nul gevaarlijke JavaScript-sinks, nul
  remote imports en nul verplichte third-party Pythonruntimepackages.

Klantdata blijft functioneel noodzakelijk als plaintext JSON binnen de
afgeschermde servicestate. R9RC1 claimt daarom geen applicatielaag-encryptie.
Productie vereist aantoonbare host/volume-encryptie, versleutelde offsite
backups, een recente restoreproef, privacy-/bewaargrondslag en externe
securitybeoordeling. Zonder die operationele bewijzen blijft het NO_GO.

## Actuele testgrens

`R9RC1_ACTIVE_TEST_MATRIX.json` is de enige actuele testselectie. Uitgevoerd:

- 29 geïsoleerde testsuites;
- 280 tests geslaagd;
- 0 mislukt;
- 0 overgeslagen;
- twee aanvullende fail-closed gates voor release-identiteit en supply chain.

Oudere checkpointtests blijven historische source-layout-/fingerprintevidence.
Zij zoeken doelbewust naar de monolithische bron of hashes van hun eigen
checkpoint en zijn daarom geen geldige R9RC1-gate. Dit is expliciet vastgelegd
in de actuele matrix; gedrag wordt door de huidige outcome-suites afgedekt.

## Verplichte resterende externe gates

1. Bouw het canonieke R9RC1-ZIP en bind alle resultaten aan artifact- en
   manifest-SHA-256.
2. Draai de volledige offline browseroracle opnieuw in Chromium én WebKit.
3. Deploy exact hetzelfde ZIP naar de VPS en voer runtime-, restore-, rechten-,
   proxy-, TLS- en operationele controles uit.
4. Voer de echte iPhone-Safari-, onafhankelijke security/privacy-, CAM/workshop-
   en formele business-signoff uit.

Geen intern PASS-resultaat in R9RC1 mag één van deze externe bewijzen vervangen.
