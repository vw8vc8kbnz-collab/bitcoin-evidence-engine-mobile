#!/usr/bin/env python3
from __future__ import annotations

"""Fail-closed identity, critical-file and NO-GO gate for R9RC1."""

import argparse
import hashlib
import json
from pathlib import Path


REVISION = "R9RC1"
BUILD = "R9RC1_PROFESSIONAL_ARCHITECTURE_COMPLETION"
ARTIFACT = f"METOD_PAX_{BUILD}_CANDIDATE.zip"
ARTIFACT_ROOT = f"METOD_PAX_{BUILD}_CANDIDATE"
TAG = "r9rc1-professional-architecture-completion-candidate-checkpoint"
GOLDEN_SHA256 = "d3e8656d8d7d5a581a8186ef8fe2c91c19b2137a8654b2f2874497dd85255e62"

EXPECTED_PROTECTED_FILES = frozenset({
    "app/catalog_importer.py",
    "app/dxf_geometry.py",
    "app/dxf_nesting_optimizer.py",
    "app/metod_app/admin/access.py",
    "app/metod_app/admin/assets/admin.css",
    "app/metod_app/admin/assets/admin.js",
    "app/metod_app/admin/assets/dxf.js",
    "app/metod_app/admin/assets/login.css",
    "app/metod_app/admin/assets/login.js",
    "app/metod_app/admin/presentation.py",
    "app/metod_app/admin/templates/admin.html",
    "app/metod_app/admin/templates/login.html",
    "app/metod_app/http/handler.py",
    "app/metod_app/http/matcher.py",
    "app/metod_app/http/routes.py",
    "app/metod_app/http/static.py",
    "app/metod_app/jobs/admission.py",
    "app/metod_app/jobs/execution.py",
    "app/metod_app/jobs/finalization.py",
    "app/metod_app/jobs/lifecycle.py",
    "app/metod_app/jobs/process_supervisor.py",
    "app/metod_app/requests/repository.py",
    "app/metod_app/requests/submission.py",
    "app/metod_app/runtime/application.py",
    "app/metod_app/runtime/composition.py",
    "app/metod_app/runtime/startup.py",
    "app/metod_app/runtime/worker.py",
    "app/metod_app/security/access_runtime.py",
    "app/metod_app/security/credentials.py",
    "app/metod_app/security/headers.py",
    "app/metod_app/security/redaction.py",
    "app/metod_app/storage/archive_runtime.py",
    "app/metod_app/storage/backup_runtime.py",
    "app/metod_app/storage/io_runtime.py",
    "app/metod_app/storage/retention_runtime.py",
    "app/panel_contract.py",
    "app/pricing_helpers.py",
    "app/safety_contracts.py",
    "app/server_helpers.py",
    "app/server_py.py",
    "app/tool-a/bootstrap.js",
    "app/tool-a/runtime/bundle-manifest.json",
    "app/tool-a/runtime/classic-runtime.bundle.js",
    "app/tool-a/runtime/legacy-source/parts.json",
    "app/tool-a/shell/script-01-early-catalog-bootstrap.js",
    "app/tool-a/styles/tool-a.bundle.css",
    "app/toolA.html",
})


def digest(path: Path) -> str:
    result = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            result.update(chunk)
    return result.hexdigest()


def load_object(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8", errors="strict"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON object required: {path.name}")
    return value


def audit_release(release: Path) -> list[str]:
    failures: list[str] = []

    def require(condition: bool, message: str) -> None:
        if not condition:
            failures.append(message)

    try:
        identity = load_object(release / "RELEASE_IDENTITY.json")
        candidate = identity.get("canonicalCandidate") or {}
        golden = identity.get("immutableGoldenBaseline") or {}
        evidence = identity.get("externalEvidence") or {}
        require(identity.get("contractId") == "R9RC1_RELEASE_IDENTITY", "identity-contract")
        require(candidate.get("releaseRevision") == REVISION, "release-revision")
        require(candidate.get("buildId") == BUILD, "build-id")
        require(candidate.get("artifactName") == ARTIFACT, "artifact-name")
        require(candidate.get("artifactRootDirectory") == ARTIFACT_ROOT, "artifact-root")
        require(candidate.get("intendedSourceTag") == TAG, "source-tag")
        require(candidate.get("status") == "PROVISIONAL_DEVELOPMENT_ONLY", "candidate-status")
        require(candidate.get("releaseEligible") is False, "release-must-remain-ineligible")
        require(golden.get("artifactSha256") == GOLDEN_SHA256, "golden-sha256")
        require(evidence.get("productionGo") is False, "production-must-remain-no-go")
        require(
            evidence.get("browser") == "R9RC1_CHROMIUM_WEBKIT_RERUN_REQUIRED_NO_GO",
            "browser-rerun-state",
        )
        require(
            evidence.get("vps") == "R9RC1_VPS_DEPLOYMENT_AND_RERUN_REQUIRED_NO_GO",
            "vps-rerun-state",
        )

        contract = load_object(release / "RUNTIME_CONTRACT.json")
        for field, expected in (
            ("build", BUILD),
            ("releaseRevision", REVISION),
            ("artifactName", ARTIFACT),
            ("artifactRootDirectory", ARTIFACT_ROOT),
        ):
            require(contract.get(field) == expected, f"runtime-{field}")
        require(contract.get("releaseEligible") is False, "runtime-release-eligibility")

        sbom = load_object(release / "SBOM.cdx.json")
        metadata = sbom.get("metadata") or {}
        component = metadata.get("component") or {}
        properties = {
            str(item.get("name") or ""): str(item.get("value") or "")
            for item in metadata.get("properties") or []
            if isinstance(item, dict)
        }
        require(component.get("version") == BUILD, "sbom-build")
        require(properties.get("releaseRevision") == REVISION, "sbom-revision")
        require(properties.get("artifactName") == ARTIFACT, "sbom-artifact")
        require(properties.get("artifactRootDirectory") == ARTIFACT_ROOT, "sbom-root")
        require(properties.get("releaseEligible") == "false", "sbom-release-eligibility")

        matrix = load_object(release / "R9RC1_ACTIVE_TEST_MATRIX.json")
        require(matrix.get("buildId") == BUILD, "test-matrix-build")
        require(matrix.get("status") == "CURRENT", "test-matrix-status")
        matrix_evidence = matrix.get("externalEvidence") or {}
        require(matrix_evidence.get("productionGo") is False, "test-matrix-production-go")
        require(matrix_evidence.get("releaseEligible") is False, "test-matrix-eligibility")

        rules = load_object(release / "R9RC1_PROFESSIONAL_ARCHITECTURE_RULES.json")
        require(rules.get("buildId") == BUILD, "architecture-rules-build")

        tool_a = (release / "app/toolA.html").read_text(encoding="utf-8", errors="strict")
        for token in (
            f'<meta name="metod-release-revision" content="{REVISION}" />',
            f'<meta name="metod-release-build" content="{BUILD}" />',
            f'<meta name="metod-application-revision" content="{BUILD}" />',
        ):
            require(token in tool_a, f"public-metadata:{token}")

        protected = identity.get("protectedCriticalFiles") or {}
        require(set(protected) == EXPECTED_PROTECTED_FILES, "protected-file-set")
        for relative, expected in sorted(protected.items()):
            path = release / str(relative)
            require(path.is_file() and not path.is_symlink(), f"protected-file-missing:{relative}")
            if path.is_file() and not path.is_symlink():
                require(digest(path) == expected, f"protected-file-mismatch:{relative}")
    except Exception as exc:
        failures.append(f"identity-gate-exception:{exc}")
    return failures


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--release", type=Path, required=True)
    args = parser.parse_args()
    failures = audit_release(args.release.resolve(strict=True))
    if failures:
        for failure in failures:
            print(f"FAIL: {failure}")
        return 1
    print("R9RC1 RELEASE IDENTITY GATE: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
