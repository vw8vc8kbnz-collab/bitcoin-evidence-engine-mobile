#!/usr/bin/env python3
from __future__ import annotations

"""Fail-closed R9H-3 mobile-cart/bottom-sheet behavior and ownership proof."""

import ast
import base64
import hashlib
import json
import re
import shutil
import subprocess
import unittest
from pathlib import Path

from r9h_shell_source import read_toola_expanded


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
HTML = APP / "toolA.html"
BOOTSTRAP = APP / "tool-a/bootstrap.js"
COMPONENT = APP / "tool-a/components/mobile-material-cart.js"
RULES = ROOT / "R9B_ARCHITECTURE_RULES.json"


def data_url(path: Path) -> str:
    return "data:text/javascript;base64," + base64.b64encode(path.read_bytes()).decode()


def run_node(source: str) -> dict:
    node = shutil.which("node")
    if not node:
        raise AssertionError("Node is required by the release architecture gate")
    completed = subprocess.run(
        [node, "--input-type=module"], input=source, text=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=10, check=False,
    )
    if completed.returncode != 0:
        raise AssertionError(completed.stdout)
    return json.loads(completed.stdout.strip().splitlines()[-1])


def fake_dom_probe(actions: str, *, mobile: bool = True) -> dict:
    return run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});
const ids=['mobileMaterialCartTrigger','mobileMaterialCartTriggerSwatch','mobileMaterialCartTriggerTitle',
'mobileMaterialCartTriggerMeta','mobileMaterialCartTriggerCount','mobileMaterialCartBackdrop',
'mobileMaterialCartSheet','mobileMaterialCartHandle','mobileMaterialCartClose','mobileMaterialCartSubtitle',
'mobileMaterialCartList','mobileMaterialCartContinue'];
function classList(){{const values=new Set();return{{add:v=>values.add(v),remove:v=>values.delete(v),
contains:v=>values.has(v),toggle:(v,on)=>on?values.add(v):values.delete(v),values}};}}
function element(id){{return{{id,style:{{}},attrs:{{}},hidden:false,disabled:false,textContent:'',html:'',focusCount:0,
classList:classList(),listeners:{{}},setAttribute(n,v){{this.attrs[n]=String(v);}},getAttribute(n){{return this.attrs[n]||'';}},
addEventListener(t,fn){{(this.listeners[t]||(this.listeners[t]=[])).push(fn);}},focus(){{this.focusCount++;}},
querySelectorAll(sel){{return sel==='[data-mobile-material-swatch]'?(this.swatches||[]):[];}}}};}}
const nodes=Object.fromEntries(ids.map(id=>[id,element(id)]));
Object.defineProperty(nodes.mobileMaterialCartList,'innerHTML',{{get(){{return this.html;}},set(v){{this.html=String(v);this.swatches=[];
for(const match of this.html.matchAll(/data-mobile-material-swatch="([^"]+)"/g)){{const el=element('swatch');el.attrs['data-mobile-material-swatch']=match[1].replaceAll('&amp;','&');this.swatches.push(el);}}}}}});
const body={{classList:classList(),style:{{}},dataset:{{}}}};
const docListeners={{}};const documentRef={{body,activeElement:nodes.mobileMaterialCartTrigger,
getElementById:id=>nodes[id]||null,contains:el=>Object.values(nodes).includes(el),
addEventListener:(t,fn)=>{{(docListeners[t]||(docListeners[t]=[])).push(fn);}}}};
const rootListeners={{}};const rootRef={{innerWidth:{430 if mobile else 900},state:{{}},
matchMedia:()=>({{matches:{str(mobile).lower()}}}),requestAnimationFrame:fn=>fn(),setTimeout:fn=>fn(),
addEventListener:(t,fn)=>{{(rootListeners[t]||(rootListeners[t]=[])).push(fn);}}}};
const calls=[];const component=m.createMobileMaterialCartComponent({{documentRef,rootRef,
getState:()=>rootRef.state,applySwatchImpl:(el,key)=>{{el.applied=key;calls.push('swatch:'+key);}},
matchMediaImpl:query=>rootRef.matchMedia(query),
activateMaterialImpl:key=>calls.push('activate:'+key),removeMaterialImpl:key=>calls.push('remove:'+key),
confirmRemoveImpl:key=>calls.push('confirm:'+key),showPanelsImpl:()=>calls.push('panels')}});
{actions}
""")


def assignment_set(path: Path, name: str) -> set[str]:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(
            isinstance(target, ast.Name) and target.id == name for target in node.targets
        ):
            value = node.value
            if isinstance(value, ast.Call) and isinstance(value.func, ast.Name) and value.func.id == "frozenset":
                value = value.args[0]
            return set(ast.literal_eval(value))
    raise AssertionError(name)


class R9HMobileMaterialCartTests(unittest.TestCase):
    def test_01_models_preserve_public_copy_active_material_and_panel_counts(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});
const rows=m.getMobileMaterialCartModels({{activeMaterialKey:'b',materialBatches:[
{{key:'a',mat:{{publicName:'Eiken A',primaryVisualFamily:'Hout',thicknessMm:18,sheetSizeMm:{{width:2070,height:2800}}}}}},
{{key:'b',mat:{{productName:'Uni B',decorType:'Uni',thicknessMm:19,sheetSizeMm:{{width:1220,height:3050}}}}}}],
cart:[{{materialKey:'a'}},{{materialKey:'a'}}],extraPanels:[{{materialKey:'a',qty:3}},{{materialKey:'b',qty:0}}]}});
console.log(JSON.stringify({{build:m.MOBILE_MATERIAL_CART_BUILD,rows}}));
""")
        self.assertEqual(result["build"], "R9H_MOBILE_CART_COMPONENT_3")
        self.assertEqual(result["rows"][0]["title"], "Eiken A")
        self.assertEqual(result["rows"][0]["meta"], "Hout · 18 mm · 2070 × 2800 mm")
        self.assertEqual(result["rows"][0]["panelCount"], 5)
        self.assertEqual(result["rows"][1]["panelCount"], 1)
        self.assertTrue(result["rows"][1]["active"])
        self.assertFalse(result["rows"][0]["active"])

    def test_02_render_preserves_plural_copy_rows_swatches_and_escaping(self) -> None:
        result = fake_dom_probe("""
rootRef.state={activeMaterialKey:'b',materialBatches:[{key:'a&',mat:{publicName:'<Eiken>',thicknessMm:18}},{key:'b',mat:{publicName:'Uni'}}],cart:[],extraPanels:[]};
const rows=component.render(rootRef.state);
console.log(JSON.stringify({count:rows.length,title:nodes.mobileMaterialCartTriggerTitle.textContent,
meta:nodes.mobileMaterialCartTriggerMeta.textContent,subtitle:nodes.mobileMaterialCartSubtitle.textContent,
badge:nodes.mobileMaterialCartTriggerCount.textContent,hidden:nodes.mobileMaterialCartTrigger.hidden,
hasClass:body.classList.contains('hasMobileMaterialCart'),html:nodes.mobileMaterialCartList.html,
swatches:calls.filter(v=>v.startsWith('swatch:'))}));
""")
        self.assertEqual(result["count"], 2)
        self.assertEqual(result["title"], "Jouw materialen")
        self.assertEqual(result["meta"], "2 gekozen · open")
        self.assertEqual(result["subtitle"], "2 materialen gekozen")
        self.assertEqual(result["badge"], "2")
        self.assertFalse(result["hidden"])
        self.assertTrue(result["hasClass"])
        self.assertIn("&lt;Eiken&gt;", result["html"])
        self.assertIn('data-mobile-material-row="a&amp;"', result["html"])
        self.assertEqual(result["swatches"], ["swatch:b", "swatch:a&", "swatch:b"])

    def test_03_empty_and_single_material_projection_remain_exact(self) -> None:
        result = fake_dom_probe("""
rootRef.state={activeMaterialKey:'a',materialBatches:[{key:'a',mat:{publicName:'Eiken'}}],cart:[],extraPanels:[]};
component.render(rootRef.state);const single={title:nodes.mobileMaterialCartTriggerTitle.textContent,
meta:nodes.mobileMaterialCartTriggerMeta.textContent,subtitle:nodes.mobileMaterialCartSubtitle.textContent};
rootRef.state={materialBatches:[],cart:[],extraPanels:[]};component.render(rootRef.state);
console.log(JSON.stringify({single,empty:{hidden:nodes.mobileMaterialCartTrigger.hidden,
disabled:nodes.mobileMaterialCartContinue.disabled,hasClass:body.classList.contains('hasMobileMaterialCart')}}));
""")
        self.assertEqual(result["single"], {
            "title": "Jouw materiaal", "meta": "1 gekozen · open",
            "subtitle": "1 materiaal gekozen",
        })
        self.assertEqual(result["empty"], {"hidden": True, "disabled": True, "hasClass": False})

    def test_04_init_is_idempotent_and_binds_all_accessible_close_routes(self) -> None:
        result = fake_dom_probe("""
rootRef.state={activeMaterialKey:'a',materialBatches:[{key:'a',mat:{publicName:'Eiken'}}],cart:[],extraPanels:[]};
const first=component.init();const second=component.init();
console.log(JSON.stringify({first,second,trigger:nodes.mobileMaterialCartTrigger.listeners.click.length,
backdrop:nodes.mobileMaterialCartBackdrop.listeners.click.length,handle:nodes.mobileMaterialCartHandle.listeners.click.length,
close:nodes.mobileMaterialCartClose.listeners.click.length,list:nodes.mobileMaterialCartList.listeners.click.length,
escape:docListeners.keydown.length,selection:docListeners['adzaagt-material-selection-updated'].length,resize:rootListeners.resize.length}));
""")
        self.assertEqual(result, {"first": True, "second": True, "trigger": 1, "backdrop": 1,
            "handle": 1, "close": 1, "list": 1, "escape": 1, "selection": 1, "resize": 1})

    def test_05_open_close_preserve_aria_backdrop_focus_and_body_state(self) -> None:
        result = fake_dom_probe("""
rootRef.state={activeMaterialKey:'a',materialBatches:[{key:'a',mat:{publicName:'Eiken'}}],cart:[],extraPanels:[]};
component.init();const opened=component.open();const openState={body:body.classList.contains('mobileMaterialCartOpen'),
backdrop:nodes.mobileMaterialCartBackdrop.hidden,sheet:nodes.mobileMaterialCartSheet.attrs['aria-hidden'],
expanded:nodes.mobileMaterialCartTrigger.attrs['aria-expanded'],closeFocus:nodes.mobileMaterialCartClose.focusCount};
component.close();const closed={body:body.classList.contains('mobileMaterialCartOpen'),backdrop:nodes.mobileMaterialCartBackdrop.hidden,
sheet:nodes.mobileMaterialCartSheet.attrs['aria-hidden'],expanded:nodes.mobileMaterialCartTrigger.attrs['aria-expanded'],
triggerFocus:nodes.mobileMaterialCartTrigger.focusCount};
console.log(JSON.stringify({opened,openState,closed}));
""")
        self.assertTrue(result["opened"])
        self.assertEqual(result["openState"], {"body": True, "backdrop": False, "sheet": "false", "expanded": "true", "closeFocus": 1})
        self.assertEqual(result["closed"], {"body": False, "backdrop": True, "sheet": "true", "expanded": "false", "triggerFocus": 1})

    def test_06_non_mobile_open_refuses_without_mutating_dialog_state(self) -> None:
        result = fake_dom_probe("""
rootRef.state={activeMaterialKey:'a',materialBatches:[{key:'a',mat:{publicName:'Eiken'}}],cart:[],extraPanels:[]};
component.init();const opened=component.open();
console.log(JSON.stringify({opened,body:body.classList.contains('mobileMaterialCartOpen'),
hidden:nodes.mobileMaterialCartBackdrop.hidden,aria:nodes.mobileMaterialCartSheet.attrs['aria-hidden']||null}));
""", mobile=False)
        self.assertEqual(result, {"opened": False, "body": False, "hidden": False, "aria": None})

    def test_07_mutations_activation_and_continue_use_canonical_callbacks_once(self) -> None:
        result = fake_dom_probe("""
rootRef.state={activeMaterialKey:'a',materialBatches:[{key:'a',mat:{publicName:'A'}},{key:'b',mat:{publicName:'B'}}],cart:[],extraPanels:[]};
component.init();component.remove('a');component.confirmRemove('b');component.cancelRemove();
nodes.mobileMaterialCartContinue.listeners.click[0]();
const select={preventDefault(){},target:{closest:sel=>sel==='[data-mobile-material-select]'?{getAttribute:()=> 'b'}:null}};
nodes.mobileMaterialCartList.listeners.click[0](select);
console.log(JSON.stringify({calls}));
""")
        self.assertEqual(result["calls"].count("remove:a"), 1)
        self.assertEqual(result["calls"].count("confirm:b"), 1)
        self.assertEqual(result["calls"].count("panels"), 1)
        self.assertEqual(result["calls"].count("activate:b"), 1)

    def test_08_escape_and_resize_close_only_the_owned_open_sheet(self) -> None:
        result = fake_dom_probe("""
rootRef.state={activeMaterialKey:'a',materialBatches:[{key:'a',mat:{publicName:'A'}}],cart:[],extraPanels:[]};
component.init();component.open();let prevented=0;docListeners.keydown[0]({key:'Escape',preventDefault:()=>prevented++});
const afterEscape=body.classList.contains('mobileMaterialCartOpen');component.open();rootRef.matchMedia=()=>({matches:false});
rootListeners.resize[0]();console.log(JSON.stringify({prevented,afterEscape,afterResize:body.classList.contains('mobileMaterialCartOpen')}));
""")
        self.assertEqual(result, {"prevented": 1, "afterEscape": False, "afterResize": False})

    def test_09_legacy_runtime_is_retired_and_inline_callers_are_thin_adapters(self) -> None:
        html = read_toola_expanded(HTML)
        decor = (APP / "decor_library.js").read_text(encoding="utf-8")
        self.assertFalse((APP / "toolA_mobile_material_cart.js").exists())
        self.assertNotIn("toolA_mobile_material_cart.js", html)
        self.assertNotIn("ToolAMobileMaterialCart", html + decor)
        self.assertEqual(html.count("toolAFoundation?.renderMobileMaterialCart?.(state)"), 2)
        owner = (APP / "tool-a/shell/script-04-first-event-owner.js").read_text(encoding="utf-8")
        for method in ("removeMobileMaterial", "confirmMobileMaterialRemoval", "cancelMobileMaterialRemoval"):
            self.assertIn(f"api.{method}", owner)
        self.assertIn("!!toolAFoundation?.renderMobileMaterialCart", decor)
        self.assertNotIn("ToolAR9Foundation", html + decor)

    def test_10_bootstrap_and_architecture_publish_one_native_mobile_cart_owner(self) -> None:
        source = BOOTSTRAP.read_text(encoding="utf-8")
        self.assertEqual(source.count('from "./components/mobile-material-cart.js"'), 1)
        self.assertEqual(source.count("createMobileMaterialCartComponent()"), 1)
        self.assertEqual(source.count("\nmobileMaterialCartComponent.init();"), 1)
        self.assertIn('"R9RC1_PROFESSIONAL_ARCHITECTURE_COMPLETION"', source)
        self.assertIn('mode: "legacy-read-cleanup-adapter"', source)
        methods = ("getMobileMaterialCartModels", "initMobileMaterialCart", "renderMobileMaterialCart",
            "openMobileMaterialCart", "closeMobileMaterialCart", "removeMobileMaterial",
            "confirmMobileMaterialRemoval", "cancelMobileMaterialRemoval")
        for method in methods:
            self.assertEqual(source.count(f"  {method}:"), 1)
        rules = json.loads(RULES.read_text(encoding="utf-8"))["frontend"]
        owners = {"app/tool-a/components/dialog.js", "app/tool-a/components/footer.js", "app/tool-a/components/mobile-material-cart.js",
            "app/tool-a/components/overlay-router.js",
            "app/tool-a/components/progress-overlay.js", "app/tool-a/components/material-card.js",
            "app/tool-a/components/panel-editor.js"}
        owners.add("app/tool-a/components/grain-preview.js")
        owners.add("app/tool-a/components/checkout-review.js")
        owners.add("app/tool-a/components/thank-you.js")
        self.assertEqual(set(rules["domOwnerModules"]), owners)
        self.assertEqual(set(rules["domOwnerRequiredTokens"]), owners)
        self.assertEqual(rules["moduleImports"]["app/tool-a/components/mobile-material-cart.js"], [])
        self.assertIn("tool-a/components/mobile-material-cart.js", rules["publicStaticFiles"])

    def test_11_visual_markup_css_and_protected_fingerprints_are_unchanged(self) -> None:
        html = read_toola_expanded(HTML)
        markup_start = '<button id="mobileMaterialCartTrigger"'
        markup_end = "</section>"
        markup = html[html.index(markup_start):html.index(markup_end, html.index(markup_start)) + len(markup_end)]
        self.assertNotRegex(markup, r"\sstyle\s*=")
        for element_id in ("mobileMaterialCartTrigger", "mobileMaterialCartBackdrop", "mobileMaterialCartSheet"):
            self.assertEqual(markup.count(f'id="{element_id}"'), 1, element_id)
        css = (APP / "tool-a/styles/checkout.css").read_text(encoding="utf-8")
        for selector in (".mobileMaterialCartBackdrop", ".mobileMaterialCartSheet", "body.mobileMaterialCartOpen"):
            self.assertIn(selector, css)
        expected = {"dxf_nesting_optimizer.py": "42480b301cd660dac1e5e9fec2c8d30bb5c6826c32234a9c1cce765b758bebb8",
            "dxf_geometry.py": "b80a2d006241908bf7b33516f7e0faf59ef61e1e08db86966b23cc5de292c1ff",
            "pricing_helpers.py": "646c2f5186e9b080f6ba8dcf364884411c18e946254bb5c9001647f7cbb425df",
            "panel_contract.py": "e23314fd63a2358a48daa580a92cebb8a40c9862548ba0243461a59347da7fc9"}
        for name, digest in expected.items():
            self.assertEqual(hashlib.sha256((APP / name).read_bytes()).hexdigest(), digest, name)
        start = html.index("async function buildJobPayload(){")
        end = html.index("  // ---------------------------\n  // Checkout overlays (restmateriaal + klantgegevens)", start)
        payload = html[start:end].encode()
        self.assertEqual((len(payload), hashlib.sha256(payload).hexdigest()),
            (9697, "342dac02c2650ac2798e20e62d38d8e1e6b7d518a54daa8fd760d734ae527e47"))

    def test_12_dom_io_allowlists_and_release_preflight_are_fail_closed(self) -> None:
        source = COMPONENT.read_text(encoding="utf-8")
        for token in ("fetch(", "XMLHttpRequest", "EventSource", "WebSocket", "localStorage",
            "sessionStorage", "defineProperty(globalThis"):
            self.assertNotIn(token, source)
        self.assertNotIn("ToolAMobileMaterialCart", source)
        self.assertEqual(assignment_set(APP / "metod_app/http/static.py", "PUBLIC_STATIC_MODULE_FILES"),
            assignment_set(APP / "metod_app/http/static.py", "PUBLIC_STATIC_MODULE_FILES"))
        matrix = json.loads((ROOT / "R9RC1_ACTIVE_TEST_MATRIX.json").read_text(encoding="utf-8"))
        suites = {row["path"] for row in matrix["suites"]}
        for path in (
            "tools/r9h_dialog_component_tests.py",
            "tools/r9h_progress_overlay_tests.py",
            "tools/r9h_mobile_material_cart_tests.py",
        ):
            self.assertIn(path, suites)
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});
const component=m.createMobileMaterialCartComponent({{documentRef:{{}},rootRef:{{}}}});
console.log(JSON.stringify({{frozen:Object.isFrozen(component),keys:Reflect.ownKeys(component),
init:component.init(),render:component.render(),open:component.open(),remove:component.remove('x')}}));
""")
        self.assertTrue(result["frozen"])
        self.assertEqual(result["keys"], ["BUILD", "getModels", "init", "render", "open", "close", "remove", "confirmRemove", "cancelRemove"])
        self.assertEqual({k: result[k] for k in ("init", "render", "open", "remove")},
            {"init": False, "render": [], "open": False, "remove": False})


if __name__ == "__main__":
    unittest.main(verbosity=2)
