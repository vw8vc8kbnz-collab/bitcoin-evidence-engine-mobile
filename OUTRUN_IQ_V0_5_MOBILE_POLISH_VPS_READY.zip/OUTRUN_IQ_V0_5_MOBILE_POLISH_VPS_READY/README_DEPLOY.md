# Outrun IQ v0.5 Mobile Polish VPS Ready

Updates:
- Mobile top tab navigation removed.
- Dark-mode bottom app navigation added.
- Mobile shell improved: cleaner app structure, stronger cards, trust/proof-density UI, seller dashboard and AI scan polish.
- Intro version key updated so intro runs once again after deploy.

Run:
```bash
HOST=0.0.0.0 PORT=8795 python3 server.py
```
