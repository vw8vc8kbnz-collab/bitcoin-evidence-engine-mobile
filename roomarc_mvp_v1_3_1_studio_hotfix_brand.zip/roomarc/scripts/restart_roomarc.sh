#!/usr/bin/env bash
set -euo pipefail
SERVICE_NAME="${ROOMARC_SERVICE_NAME:-roomarc}"
PORT="${ROOMARC_PORT:-8899}"
if command -v systemctl >/dev/null 2>&1 && systemctl list-unit-files | grep -q "^${SERVICE_NAME}.service"; then
  sudo systemctl restart "${SERVICE_NAME}.service"
  echo "Restarted ${SERVICE_NAME}.service"
else
  echo "No systemd service found. Freeing port ${PORT} and starting foreground server..."
  pkill -f "uvicorn app.main:app.*--port ${PORT}" || true
  sleep 1
  exec ./scripts/run_dev.sh
fi
./scripts/healthcheck.sh
