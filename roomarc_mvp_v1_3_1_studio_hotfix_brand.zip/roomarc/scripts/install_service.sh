#!/usr/bin/env bash
set -euo pipefail
APP_DIR="$(cd "$(dirname "$0")/.." && pwd)"
SERVICE_NAME="${ROOMARC_SERVICE_NAME:-roomarc}"
USER_NAME="${ROOMARC_SERVICE_USER:-$(whoami)}"
PORT="${ROOMARC_PORT:-8899}"
if ! command -v systemctl >/dev/null 2>&1; then
  echo "systemctl not found; cannot install service on this environment." >&2
  exit 1
fi
SERVICE_FILE="/etc/systemd/system/${SERVICE_NAME}.service"
cat <<EOF | sudo tee "$SERVICE_FILE" >/dev/null
[Unit]
Description=Roomarc mobile web app
After=network.target

[Service]
Type=simple
User=${USER_NAME}
WorkingDirectory=${APP_DIR}
Environment=ROOMARC_PORT=${PORT}
ExecStart=${APP_DIR}/scripts/run_service.sh
Restart=always
RestartSec=3
KillSignal=SIGINT
TimeoutStopSec=20

[Install]
WantedBy=multi-user.target
EOF
sudo systemctl daemon-reload
sudo systemctl enable "${SERVICE_NAME}.service"
echo "Installed systemd service: ${SERVICE_NAME}.service"
