#!/usr/bin/env bash
set -euo pipefail
PORT="${ROOMARC_PORT:-8899}"
URL="http://127.0.0.1:${PORT}/api/health"
echo "Checking $URL"
for i in $(seq 1 30); do
  if curl -fsS "$URL" >/tmp/roomarc_health.json 2>/dev/null; then
    cat /tmp/roomarc_health.json
    echo
    echo "Roomarc health OK"
    exit 0
  fi
  sleep 1
done
echo "Roomarc health check failed" >&2
exit 1
