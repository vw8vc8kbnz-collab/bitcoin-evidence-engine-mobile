export const FALLBACK_UPDATES = [
  {
    id: 'fb1',
    media_url: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1400&q=85',
    caption: 'De woonkamer heeft een warmere basis gekregen. De muren zijn klaar en de sfeer voelt direct rustiger.',
    phase_label: 'Muren afgerond',
    created_at: 'Vandaag',
    room: { id: 'demo-room-living', name: 'Woonkamer', cover_url: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1200&q=80' },
    home: { id: 'demo-home', title: 'The Atelier House', slug: 'the-atelier-house', cover_url: 'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&w=1200&q=80' },
    saved: false, following_room: false, following_home: false,
  },
  {
    id: 'fb2',
    media_url: 'https://images.unsplash.com/photo-1617104678098-de229db51175?auto=format&fit=crop&w=1400&q=85',
    caption: 'Casa Verde bouwt de eethoek om met terracotta, groen en veel zachter daglicht.',
    phase_label: 'Terracotta laag',
    created_at: 'Gisteren',
    room: { id: 'demo-room-dining', name: 'Eethoek', cover_url: 'https://images.unsplash.com/photo-1617104678098-de229db51175?auto=format&fit=crop&w=1200&q=80' },
    home: { id: 'demo-home-verde', title: 'Casa Verde', slug: 'casa-verde', cover_url: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1200&q=80' },
    saved: false, following_room: false, following_home: false,
  },
  {
    id: 'fb3',
    media_url: 'https://images.unsplash.com/photo-1593062096033-9a26b09da705?auto=format&fit=crop&w=1400&q=85',
    caption: 'Loft Noord maakt van een lege hoek een rustige werkplek met staal, hout en warm licht.',
    phase_label: 'Op maat bureau',
    created_at: 'Deze week',
    room: { id: 'demo-room-office', name: 'Werkplek', cover_url: 'https://images.unsplash.com/photo-1593062096033-9a26b09da705?auto=format&fit=crop&w=1200&q=80' },
    home: { id: 'demo-home-loft', title: 'Loft Noord', slug: 'loft-noord', cover_url: 'https://images.unsplash.com/photo-1600607687644-c7171b42498b?auto=format&fit=crop&w=1200&q=80' },
    saved: false, following_room: false, following_home: false,
  },
  {
    id: 'fb4',
    media_url: 'https://images.unsplash.com/photo-1600566753151-384129cf4e3e?auto=format&fit=crop&w=1400&q=85',
    caption: 'Studio Sand laat zien hoe een huurwoning-badkamer zonder verbouwing toch hotelgevoel krijgt.',
    phase_label: 'Hotelgevoel',
    created_at: 'Deze maand',
    room: { id: 'demo-room-bath', name: 'Badkamer', cover_url: 'https://images.unsplash.com/photo-1600566753151-384129cf4e3e?auto=format&fit=crop&w=1200&q=80' },
    home: { id: 'demo-home-sand', title: 'Studio Sand', slug: 'studio-sand', cover_url: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80' },
    saved: false, following_room: false, following_home: false,
  },
];

export const DEFAULT_COVER = 'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&w=1200&q=80';
export const DEFAULT_ROOM = 'https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=1200&q=80';
