import { useEffect, useMemo, useState } from 'react';
import { request, seedDemo } from '../lib/api';

export function useAuth() {
  const [token, setToken] = useState(localStorage.getItem('roomarc_token') || '');
  const [me, setMe] = useState(null);
  const [ready, setReady] = useState(false);

  const api = useMemo(() => ({
    req: (path, options = {}) => request(path, { token, ...options }),
  }), [token]);

  async function login(email = 'demo@roomarc.local', password = 'demo123') {
    await seedDemo();
    const data = await request('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    localStorage.setItem('roomarc_token', data.token);
    setToken(data.token);
    setMe(data.user);
    setReady(true);
  }

  function logout() {
    localStorage.removeItem('roomarc_token');
    setToken('');
    setMe(null);
    setReady(true);
  }

  useEffect(() => {
    let cancelled = false;
    async function verify() {
      if (!token) {
        if (!cancelled) setReady(true);
        return;
      }
      try {
        const user = await request('/api/auth/me', { token });
        if (!cancelled) {
          setMe(user);
          setReady(true);
        }
      } catch {
        localStorage.removeItem('roomarc_token');
        if (!cancelled) {
          setToken('');
          setMe(null);
          setReady(true);
        }
      }
    }
    setReady(false);
    verify();
    return () => { cancelled = true; };
  }, [token]);

  return { token, me, ready, login, logout, req: api.req };
}
