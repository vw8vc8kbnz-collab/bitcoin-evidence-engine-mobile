import React from 'react';

export function RoomarcWordmark({ compact = false, dark = false }) {
  return (
    <span className={`roomarc-wordmark ${compact ? 'roomarc-wordmark--compact' : ''} ${dark ? 'roomarc-wordmark--dark' : ''}`} aria-label="Roomarc">
      <span className="roomarc-wordmark__room">Room</span><span className="roomarc-wordmark__arc">arc</span>
    </span>
  );
}

export function RoomarcLogo({ size = 42, dark = false }) {
  return (
    <span className={`roomarc-logo ${dark ? 'roomarc-logo--dark' : ''}`} style={{ width: size, height: size }} aria-hidden="true">
      <svg viewBox="0 0 64 64" role="img" focusable="false">
        <defs>
          <linearGradient id="roomarcLogoGrad" x1="10" y1="10" x2="54" y2="58" gradientUnits="userSpaceOnUse">
            <stop offset="0" stopColor="#111111" />
            <stop offset="0.52" stopColor="#111111" />
            <stop offset="0.53" stopColor="#b8956a" />
            <stop offset="1" stopColor="#d0aa78" />
          </linearGradient>
        </defs>
        <rect x="4" y="4" width="56" height="56" rx="17" fill={dark ? '#f8f6f2' : '#0e0f11'} />
        <path d="M18 40V24.7L32 16.8l14 7.9V40" fill="none" stroke="#d0aa78" strokeWidth="4.6" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M22.5 41c5.1-8.6 13.9-8.6 19 0" fill="none" stroke={dark ? '#0e0f11' : '#f8f6f2'} strokeWidth="4.8" strokeLinecap="round" />
        <path d="M32 17v15" stroke="#f8f6f2" strokeOpacity="0.26" strokeWidth="2.2" strokeLinecap="round" />
      </svg>
    </span>
  );
}

export function RoomarcBrand({ subtitle, dark = false, compact = false }) {
  return (
    <span className={`roomarc-brand ${compact ? 'roomarc-brand--compact' : ''}`}>
      <RoomarcLogo size={compact ? 34 : 46} dark={dark} />
      <span className="roomarc-brand__text">
        <RoomarcWordmark compact={compact} dark={dark} />
        {subtitle ? <small>{subtitle}</small> : null}
      </span>
    </span>
  );
}
