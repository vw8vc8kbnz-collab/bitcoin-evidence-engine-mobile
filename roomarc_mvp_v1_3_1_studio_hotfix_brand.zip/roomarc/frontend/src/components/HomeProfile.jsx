import React, { useEffect, useState } from 'react';
import { ChevronLeft } from 'lucide-react';
import { motion } from 'framer-motion';

export function HomeProfile({ slug, auth, close, openRoom }) {
  const [home, setHome] = useState(null);

  async function load() {
    setHome(await auth.req(`/api/homes/${slug}`));
  }

  useEffect(() => { load(); }, [slug]);

  if (!home) return null;

  async function toggleFollow() {
    await auth.req(`/api/homes/${home.id}/follow`, { method: home.following ? 'DELETE' : 'POST' });
    load();
  }

  return (
    <motion.aside className="overlay overlay--light" initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }} transition={{ type: 'spring', damping: 28, stiffness: 240 }}>
      <button className="back-button" onClick={close}><ChevronLeft size={18} /> Terug</button>
      <section className="profile-hero">
        <img src={home.cover_url} alt={home.title} />
        <span className="profile-hero__gradient" />
        <span className="home-avatar">⌂</span>
        <div className="profile-hero__text">
          <span>@{home.slug}</span>
          <h1>{home.title}</h1>
          <p>{home.description || 'Een huisprofiel dat kamer voor kamer groeit.'}</p>
          <div className="profile-hero__buttons">
            <button onClick={toggleFollow}>{home.following ? 'Volgend' : 'Volgen'}</button>
            <button>Delen</button>
          </div>
        </div>
      </section>
      <section className="profile-social-proof-v9"><span>Populair huisprofiel</span><strong>{home.style_text || 'Interieur in ontwikkeling'}</strong><p>Volg het hele huis of open een specifieke kamer-tijdlijn.</p></section>
      <section className="stats-row stats-row--v9">
        <div><strong>{home.stats.rooms}</strong><span>Kamers</span></div>
        <div><strong>{home.stats.followers}</strong><span>Volgers</span></div>
        <div><strong>{home.stats.updates}</strong><span>Updates</span></div>
      </section>
      <div className="section-title padded"><h3>Kamers</h3><span>Tik om tijdlijn te openen</span></div>
      <div className="room-grid">
        {home.rooms.map((room) => (
          <motion.button className="room-tile" whileTap={{ scale: 0.98 }} onClick={() => openRoom(room.id)} key={room.id}>
            <img src={room.cover_url} alt={room.name} />
            <div><strong>{room.name}</strong><span>{room.updates} updates · {room.followers} volgers</span><small>{room.latest_phase || 'Bekijk tijdlijn'}</small></div>
          </motion.button>
        ))}
      </div>
    </motion.aside>
  );
}
