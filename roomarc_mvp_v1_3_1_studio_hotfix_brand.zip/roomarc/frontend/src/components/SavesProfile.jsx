import React, { useEffect, useMemo, useState } from 'react';
import { Bell, Bookmark, Grid3X3, Heart, Home, House, MessageCircle, Settings, Sparkles, UserPlus } from 'lucide-react';
import { EmptyState, TopBar } from './Layout';

export function Saves({ auth, openRoom }) {
  const [items, setItems] = useState([]);
  useEffect(() => { auth.req('/api/me/saves').then((data)=>setItems(Array.isArray(data)?data:[])).catch(() => setItems([])); }, []);
  return <main className="screen saves-v13"><TopBar title="Bewaard" subtitle="Je inspiratiecollectie" /><div className="save-grid save-grid--v13">{items.map((item) => <button key={item.id} onClick={() => openRoom(item.room.id)}><img src={item.media_url} alt={item.phase_label} /><span>{item.phase_label}</span></button>)}</div>{!items.length ? <EmptyState title="Nog niets bewaard" text="Bewaar kamerupdates uit de feed om ze hier terug te vinden." /> : null}</main>;
}

function iconFor(type) {
  if (type?.includes('like')) return <Heart size={18} />;
  if (type?.includes('comment')) return <MessageCircle size={18} />;
  if (type?.includes('follow')) return <UserPlus size={18} />;
  return <Sparkles size={18} />;
}

function ProfileHomeCard({ home, openRoom }) {
  const leadRoom = home.rooms?.[0];
  return <article className="profile-home-card"><img src={home.cover_url} alt={home.title}/><div><small>{home.style_text || 'Roomarc huis'}</small><strong>{home.title}</strong><p>{home.description}</p><span>{home.stats?.rooms || 0} kamers · {home.stats?.updates || 0} updates · {home.stats?.followers || 0} volgers</span></div>{leadRoom ? <button onClick={() => openRoom?.(leadRoom.id)}>Open eerste kamer</button> : null}</article>;
}

function ProfileRoomGrid({ rooms, openRoom }) {
  if (!rooms.length) return <EmptyState title="Nog geen kamers" text="Maak in Studio je eerste kamer en plaats daarna een update." />;
  return <div className="profile-room-grid">{rooms.map((room)=><button key={room.id} onClick={()=>openRoom?.(room.id)}><img src={room.cover_url || room.latest_update?.media_url} alt={room.name}/><strong>{room.name}</strong><span>{room.home.title} · {room.updates || 0} fases</span></button>)}</div>;
}

function ActivityList({ auth }) {
  const [activity, setActivity] = useState([]);
  useEffect(() => { auth.req('/api/activity').then((data)=>setActivity(Array.isArray(data)?data:[])).catch(() => setActivity([])); }, []);
  return <section className="activity-panel-v12 activity-panel--v13"><div className="section-title"><span><Bell size={18} /> Activiteit</span><small>Nieuw</small></div>{activity.map((item) => <article key={item.id}><i>{iconFor(item.event_type)}</i><div><strong>{item.message}</strong><span>{item.created_at?.slice?.(0, 16).replace('T',' ')}</span></div></article>)}{!activity.length ? <EmptyState title="Nog geen activiteit" text="Likes, reacties en nieuwe volgers verschijnen hier." /> : null}</section>;
}

export function Profile({ auth, openRoom }) {
  const [data, setData] = useState(null);
  const [tab, setTab] = useState('homes');
  useEffect(() => { auth.req('/api/me/homes').then(setData).catch(()=>setData(null)); }, []);
  const homes = data?.homes || [];
  const rooms = useMemo(() => homes.flatMap((home)=>(home.rooms||[]).map((room)=>({ ...room, home }))), [homes]);
  const updates = useMemo(() => rooms.map((room)=>room.latest_update).filter(Boolean), [rooms]);
  const stats = data?.stats || { homes: homes.length, rooms: rooms.length, updates: updates.length, followers: 0 };
  return (
    <main className="screen profile-v13">
      <TopBar title="Profiel" subtitle="Jouw interieurportfolio"><Settings size={22}/></TopBar>
      <section className="profile-hero-v13">
        <div className="profile-avatar-v13">{auth.me?.display_name?.[0] || 'R'}</div>
        <div className="profile-identity"><h1>{auth.me?.display_name || 'Roomarc gebruiker'}</h1><p>@{auth.me?.username || 'roomarc'} · warme, echte interieurs door de tijd</p></div>
        <button onClick={auth.logout}>Uitloggen</button>
      </section>
      <section className="profile-stats-v13"><div><strong>{stats.homes || 0}</strong><span>Huizen</span></div><div><strong>{stats.rooms || 0}</strong><span>Kamers</span></div><div><strong>{stats.updates || 0}</strong><span>Updates</span></div><div><strong>{stats.followers || 0}</strong><span>Volgers</span></div></section>
      <nav className="profile-tabs-v13"><button className={tab==='homes'?'active':''} onClick={()=>setTab('homes')}><House size={16}/> Huizen</button><button className={tab==='rooms'?'active':''} onClick={()=>setTab('rooms')}><Grid3X3 size={16}/> Kamers</button><button className={tab==='updates'?'active':''} onClick={()=>setTab('updates')}><Sparkles size={16}/> Updates</button><button className={tab==='activity'?'active':''} onClick={()=>setTab('activity')}><Bell size={16}/> Activiteit</button></nav>
      {tab==='homes' ? <section className="profile-home-list">{homes.map((home)=><ProfileHomeCard key={home.id} home={home} openRoom={openRoom}/>) }{!homes.length ? <EmptyState title="Nog geen huisprofiel" text="Start in Studio en maak je eerste huisprofiel." /> : null}</section> : null}
      {tab==='rooms' ? <ProfileRoomGrid rooms={rooms} openRoom={openRoom}/> : null}
      {tab==='updates' ? <div className="mini-update-grid-v9 profile-update-grid">{updates.map((update)=><button key={update.id} onClick={()=>openRoom?.(update.room.id)}><img src={update.media_url}/><span>{update.phase_label}</span></button>)}</div> : null}
      {tab==='activity' ? <ActivityList auth={auth}/> : null}
    </main>
  );
}
