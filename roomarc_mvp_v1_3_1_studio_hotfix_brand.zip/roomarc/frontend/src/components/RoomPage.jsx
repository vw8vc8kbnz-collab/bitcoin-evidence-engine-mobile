import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ChevronLeft, Flame, GitCompare, Layers3, Sparkles, Wand2 } from 'lucide-react';
import { motion } from 'framer-motion';
import { FALLBACK_UPDATES } from '../data/fallback';

function fallbackRoom(id) {
  const update = FALLBACK_UPDATES.find((item) => item.room.id === id) || FALLBACK_UPDATES[0];
  return {
    id: update.room.id,
    name: update.room.name,
    cover_url: update.room.cover_url,
    following: false,
    followers: 124,
    home: update.home,
    updates: FALLBACK_UPDATES.filter((item) => item.room.id === update.room.id),
  };
}

function clamp(value, min, max) { return Math.min(max, Math.max(min, value)); }

function journeyStats(updates = [], room) {
  const count = updates.length || 1;
  const first = updates[0];
  const last = updates[count - 1];
  const start = first?.created_at ? new Date(first.created_at) : null;
  const end = last?.created_at ? new Date(last.created_at) : null;
  const days = start && end && !Number.isNaN(start) && !Number.isNaN(end)
    ? Math.max(1, Math.round((end - start) / 86400000))
    : Math.max(7, count * 12);
  const score = clamp(68 + count * 7 + Math.min(12, Math.round((room?.followers || 0) / 80)), 72, 98);
  const milestones = updates.map((update, index) => ({
    id: update.id,
    title: update.phase_label || `Fase ${index + 1}`,
    text: update.caption || 'Nieuwe stap in deze kamer.',
    index,
  }));
  return { days, score, milestones };
}

export function RoomPage({ id, auth, close }) {
  const [room, setRoom] = useState(null);
  const [active, setActive] = useState(0);
  const [tab, setTab] = useState('timeline');
  const [compareRatio, setCompareRatio] = useState(54);
  const [dragRatio, setDragRatio] = useState(0);
  const trackRef = useRef(null);
  const compareRef = useRef(null);

  async function load() {
    try { setRoom(await auth.req(`/api/rooms/${id}`)); }
    catch { setRoom(fallbackRoom(id)); }
  }

  useEffect(() => { load(); setActive(0); setTab('timeline'); setDragRatio(0); }, [id]);

  const updates = room?.updates || [];
  const safeActive = Math.min(active, Math.max(updates.length - 1, 0));
  const current = updates[safeActive];
  const previous = updates[Math.max(safeActive - 1, 0)];
  const before = updates[0] || current;
  const after = updates[updates.length - 1] || current;
  const stats = useMemo(() => journeyStats(updates, room), [updates, room]);

  const progress = useMemo(() => {
    if (updates.length < 2) return 0;
    return safeActive / (updates.length - 1);
  }, [safeActive, updates.length]);

  function scrubFromClientX(clientX) {
    if (!trackRef.current || updates.length < 2) return;
    const box = trackRef.current.getBoundingClientRect();
    const ratio = clamp((clientX - box.left) / box.width, 0, 1);
    setDragRatio(ratio);
    setActive(Math.round(ratio * (updates.length - 1)));
  }

  function handleScrub(event) {
    event.currentTarget.setPointerCapture?.(event.pointerId);
    scrubFromClientX(event.clientX);
  }

  function compareFromClientX(clientX) {
    if (!compareRef.current) return;
    const box = compareRef.current.getBoundingClientRect();
    setCompareRatio(clamp(((clientX - box.left) / box.width) * 100, 6, 94));
  }

  function handleCompare(event) {
    event.currentTarget.setPointerCapture?.(event.pointerId);
    compareFromClientX(event.clientX);
  }

  if (!room) return null;

  async function toggleFollow() {
    if (String(room.id).startsWith('demo-room')) return;
    await auth.req(`/api/rooms/${room.id}/follow`, { method: room.following ? 'DELETE' : 'POST' });
    load();
  }

  return (
    <motion.aside className="overlay overlay--dark room-overlay-v10" initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }} transition={{ type: 'spring', damping: 31, stiffness: 235 }}>
      <button className="back-button back-button--dark" onClick={close}><ChevronLeft size={18} /> Terug</button>

      <section className="signature-hero">
        <img key={previous?.id || 'prev'} className="signature-hero__ghost" src={previous?.media_url || room.cover_url} alt="Vorige fase" />
        <motion.img key={current?.id || 'current'} className="signature-hero__main" initial={{ opacity: .22, scale: 1.035 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: .42, ease: 'easeOut' }} src={current?.media_url || room.cover_url} alt={room.name} />
        <span className="signature-hero__shade" />
        <div className="signature-hero__topline"><Sparkles size={14} /> Roomarc Signature</div>
        <div className="signature-hero__content">
          <span>{room.home.title}</span>
          <h1>{room.name}</h1>
          <p>{current?.phase_label || 'Nieuwe fase'} · {updates.length || 1} updates · {room.followers} volgers</p>
          <button onClick={toggleFollow}>{room.following ? 'Kamer volgend' : 'Volg kamer'}</button>
        </div>
      </section>

      <div className="signature-tabs">
        {[
          ['timeline', 'Tijdlijn'],
          ['before', 'Voor/na'],
          ['journey', 'Journey'],
          ['updates', 'Updates'],
        ].map(([key, label]) => <button key={key} className={tab === key ? 'active' : ''} onClick={() => setTab(key)}>{label}</button>)}
      </div>

      {tab === 'timeline' ? (
        <section className="timeline-v10-panel">
          <div className="timeline-v10-head">
            <span className="eyebrow">Fase {safeActive + 1} van {updates.length || 1}</span>
            <h2>{current?.phase_label || 'Nieuwe fase'}</h2>
            <p>{current?.caption || 'Deze kamer heeft nog geen updates.'}</p>
          </div>

          <div className="milestone-rail-v10">
            {updates.map((update, index) => (
              <button key={update.id} className={index === safeActive ? 'active' : ''} onClick={() => setActive(index)}>
                <span>{index + 1}</span>
                <strong>{update.phase_label}</strong>
              </button>
            ))}
          </div>

          <div className="timeline-scrub timeline-scrub--signature" ref={trackRef} onPointerDown={handleScrub} onPointerMove={(event) => { if (event.buttons) handleScrub(event); }}>
            <span className="timeline-scrub__glow" style={{ width: `${progress * 100}%` }} />
            <span className="timeline-scrub__fill" style={{ width: `${progress * 100}%` }} />
            {updates.map((update, index) => <button key={update.id} className={index === safeActive ? 'active' : ''} style={{ left: `${updates.length < 2 ? 0 : (index / (updates.length - 1)) * 100}%` }} onClick={() => setActive(index)} aria-label={update.phase_label} />)}
            <i style={{ left: `${progress * 100}%` }} />
          </div>

          <div className="timeline-v10-tip"><Wand2 size={16} /> Sleep over de lijn om de kamer door de tijd te beleven.</div>
        </section>
      ) : null}

      {tab === 'before' ? (
        <section className="before-after-panel">
          <div className="timeline-v10-head">
            <span className="eyebrow">Vergelijkmodus</span>
            <h2>Van {before?.phase_label || 'begin'} naar {after?.phase_label || 'nu'}</h2>
            <p>Sleep de lijn en vergelijk de eerste fase met het laatste resultaat.</p>
          </div>
          <div className="compare-card" ref={compareRef} onPointerDown={handleCompare} onPointerMove={(event) => { if (event.buttons) handleCompare(event); }}>
            <img src={after?.media_url || room.cover_url} alt="Na" />
            <div className="compare-card__before" style={{ width: `${compareRatio}%` }}><img src={before?.media_url || room.cover_url} alt="Voor" /></div>
            <span className="compare-card__divider" style={{ left: `${compareRatio}%` }}><GitCompare size={18} /></span>
            <b className="compare-card__label compare-card__label--before">Voor</b>
            <b className="compare-card__label compare-card__label--after">Na</b>
          </div>
          <div className="before-after-actions">
            <button onClick={() => setCompareRatio(12)}>Na</button>
            <button onClick={() => setCompareRatio(50)}>Split</button>
            <button onClick={() => setCompareRatio(88)}>Voor</button>
          </div>
        </section>
      ) : null}

      {tab === 'journey' ? (
        <section className="journey-panel">
          <div className="timeline-v10-head">
            <span className="eyebrow">Room Journey</span>
            <h2>De reis van {room.name.toLowerCase()}</h2>
            <p>Een compact verhaal van alle fases die deze kamer heeft doorgemaakt.</p>
          </div>
          <div className="journey-stats">
            <article><strong>{updates.length}</strong><span>updates</span></article>
            <article><strong>{stats.days}</strong><span>dagen</span></article>
            <article><strong>{stats.score}</strong><span>transformatie</span></article>
          </div>
          <div className="journey-list">
            {stats.milestones.map((step) => (
              <button key={step.id} onClick={() => { setActive(step.index); setTab('timeline'); }}>
                <i>{step.index + 1}</i>
                <div><strong>{step.title}</strong><p>{step.text}</p></div>
              </button>
            ))}
          </div>
        </section>
      ) : null}

      {tab === 'updates' ? (
        <section className="update-list update-list--v10">{updates.slice().reverse().map((update) => <article key={update.id}><img src={update.media_url} /><div><strong>{update.phase_label}</strong><p>{update.caption}</p></div></article>)}</section>
      ) : null}
    </motion.aside>
  );
}
