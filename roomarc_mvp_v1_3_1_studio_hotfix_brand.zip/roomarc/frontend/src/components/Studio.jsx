import React, { useEffect, useMemo, useState } from 'react';
import { ArrowLeft, Camera, Check, ChevronRight, Home, ImagePlus, Layers, Send, Sparkles, SplitSquareHorizontal } from 'lucide-react';
import { motion } from 'framer-motion';
import { DEFAULT_COVER, DEFAULT_ROOM } from '../data/fallback';
import { TopBar } from './Layout';

const PHASES = ['Startpunt', 'Vloer gelegd', 'Muren afgerond', 'Meubels geplaatst', 'Gestyled', 'Voor/na'];
const QUICK_CAPTIONS = [
  'Vandaag een duidelijke nieuwe stap gezet in deze ruimte.',
  'De materialen komen nu mooi samen in deze kamer.',
  'Kleine details maken de ruimte ineens veel warmer.',
  'Deze fase laat de kamer echt groeien.',
];

function ProjectCard({ room = {}, onClick }) {
  return (
    <motion.button className="studio-project-card" whileTap={{ scale: 0.985 }} onClick={onClick}>
      <img src={room.cover_url || room.latest_update?.media_url || DEFAULT_ROOM} alt={room.name || 'Kamer'} />
      <div><small>{room.home?.title || 'Jouw huis'}</small><strong>{room.name || 'Naamloze kamer'}</strong><span>{room.updates || 0} fases · {room.latest_phase || 'Start je tijdlijn'}</span></div>
      <ChevronRight size={18} />
    </motion.button>
  );
}

function StudioHome({ auth, setMode, preselectRoom }) {
  const [homeData, setHomeData] = useState(null);
  useEffect(() => { let mounted = true; auth.req('/api/me/homes').then((data) => { if (mounted) setHomeData(data && Array.isArray(data.homes) ? data : { homes: [] }); }).catch(()=>{ if (mounted) setHomeData({ homes: [] }); }); return () => { mounted = false; }; }, [auth]);
  const rooms = useMemo(() => { const homes = Array.isArray(homeData?.homes) ? homeData.homes : []; return homes.flatMap((home) => (Array.isArray(home.rooms) ? home.rooms : []).map((room) => ({ ...(room || {}), home }))).filter((room) => room && room.id); }, [homeData]);
  return (
    <main className="screen studio-v13">
      <TopBar title="Studio" subtitle="Jouw interieurwerkplek" />
      <button className="studio-primary-cta" onClick={() => setMode('update')}><span><Camera size={24} /></span><div><strong>Kamerupdate plaatsen</strong><small>Laat één kamer verder groeien op de tijdlijn</small></div><ChevronRight size={20}/></button>
      <section className="studio-workspace">
        <div className="section-title"><span>Verder werken aan</span><small>{rooms.length} kamers</small></div>
        <div className="studio-project-list">
          {rooms.slice(0, 6).map((room) => <ProjectCard room={room} key={room.id} onClick={() => { preselectRoom(room); setMode('update'); }} />)}
          {!rooms.length ? <div className="studio-empty-inline"><strong>Nog geen eigen kamers</strong><p>Maak eerst een huisprofiel en start daarna je eerste kamer.</p></div> : null}
        </div>
      </section>
      <section className="studio-quick-actions">
        <div className="section-title"><span>Snelle tools</span><small>Maak nieuw</small></div>
        <div className="quick-action-grid">
          <button onClick={() => setMode('room')}><Layers size={20}/><strong>Nieuwe kamer</strong><span>Start een ruimte</span></button>
          <button onClick={() => setMode('homeProfile')}><Home size={20}/><strong>Nieuw huis</strong><span>Bouw profiel</span></button>
          <button onClick={() => setMode('before')}><SplitSquareHorizontal size={20}/><strong>Before/after</strong><span>Vergelijk later</span></button>
          <button onClick={() => setMode('update')}><Sparkles size={20}/><strong>Snelle update</strong><span>Direct posten</span></button>
        </div>
      </section>
    </main>
  );
}

function ComposerTop({ title, subtitle, onBack, step }) {
  return <header className="composer-top-v13"><button onClick={onBack}><ArrowLeft size={18}/> Studio</button><span>{step}</span><h1>{title}</h1><p>{subtitle}</p></header>;
}

function UpdateComposer({ auth, onBack, onPosted, selectedRoom }) {
  const [homes, setHomes] = useState([]); const [homeId, setHomeId] = useState(selectedRoom?.home?.id || ''); const [roomId, setRoomId] = useState(selectedRoom?.id || '');
  const [file, setFile] = useState(null); const [preview, setPreview] = useState(''); const [phase, setPhase] = useState(''); const [caption, setCaption] = useState(''); const [busy, setBusy] = useState(false); const [status, setStatus] = useState('');
  useEffect(() => { let mounted = true; auth.req('/api/homes').then((data) => { if (!mounted) return; const list=Array.isArray(data)?data:[]; setHomes(list); if (!homeId && list[0]) setHomeId(list[0].id); }).catch(() => { if (mounted) setHomes([]); }); return () => { mounted = false; }; }, [auth]);
  const rooms = useMemo(() => { const found = homes.find((home) => home.id === homeId); return Array.isArray(found?.rooms) ? found.rooms : []; }, [homes, homeId]);
  useEffect(() => { if (!roomId && rooms[0]) setRoomId(rooms[0].id); }, [rooms, roomId]);
  const selectedHome = homes.find((h) => h.id === homeId); const selectedRoomLocal = rooms.find((r) => r.id === roomId) || selectedRoom;
  const ready = file && roomId && phase && caption.trim();
  function pickFile(event) { const selected = event.target.files?.[0]; if (!selected) return; setFile(selected); setPreview(URL.createObjectURL(selected)); }
  async function submit() {
    if (!ready) { setStatus('Maak de update compleet: foto, kamer, fase en korte tekst.'); return; }
    setBusy(true);
    try { const form = new FormData(); form.append('file', file); const uploaded = await auth.req('/api/media/upload', { method: 'POST', body: form }); await auth.req(`/api/rooms/${roomId}/updates`, { method: 'POST', body: JSON.stringify({ media_url: uploaded.url, caption, phase_label: phase }) }); setStatus('Geplaatst. Je kamer-tijdlijn is bijgewerkt.'); setTimeout(() => onPosted?.(), 500); }
    catch (error) { setStatus(`Upload mislukt: ${error.message}`); }
    finally { setBusy(false); }
  }
  return <main className="screen composer-v13"><ComposerTop onBack={onBack} step="Kamerupdate" title="Nieuwe fase" subtitle="Voeg één zichtbaar moment toe aan de tijdlijn van je kamer." />
    <label className={`media-stage-v13 ${preview ? 'has-preview' : ''}`}><input type="file" accept="image/*" onChange={pickFile}/>{preview ? <img src={preview} alt="Preview"/> : <div><ImagePlus size={36}/><strong>Kies je beste kamerfoto</strong><span>Foto eerst. Daarna alleen nog kamer, fase en verhaal.</span></div>}</label>
    <section className="composer-card-v13">
      <div className="smart-row"><label><small>Huis</small><select value={homeId} onChange={(e)=>{setHomeId(e.target.value); setRoomId('');}}>{homes.map(h=><option value={h.id} key={h.id}>{h.title}</option>)}</select></label><label><small>Kamer</small><select value={roomId} onChange={(e)=>setRoomId(e.target.value)}>{rooms.map(r=><option value={r.id} key={r.id}>{r.name}</option>)}</select></label></div>
      <div className="phase-picker-v13"><small>Kies fase</small><div>{PHASES.map(item=><button type="button" key={item} className={phase===item?'active':''} onClick={()=>setPhase(item)}>{item}</button>)}</div></div>
      <label className="caption-box-v13"><small>Wat is er veranderd?</small><textarea value={caption} onChange={(e)=>setCaption(e.target.value)} placeholder="Bijv. De vloer ligt erin en de kamer voelt direct warmer."/></label>
      <div className="quick-captions-v12">{QUICK_CAPTIONS.map(text=><button type="button" key={text} onClick={()=>setCaption(text)}>{text}</button>)}</div>
      <section className="live-preview-v13"><span>Zo verschijnt je update</span><article>{preview ? <img src={preview} alt="Preview"/> : <div className="preview-empty"><Camera size={20}/></div>}<div><small>{selectedHome?.title || 'Jouw huis'} · {selectedRoomLocal?.name || 'Kamer'}</small><strong>{phase || 'Nieuwe fase'}</strong><p>{caption || 'Schrijf kort wat er veranderd is.'}</p></div></article></section>
      {status ? <p className="status-message">{status}</p> : null}<button className="publish-bar-v13" disabled={busy} onClick={submit}><Send size={18}/> {busy ? 'Publiceren...' : ready ? 'Publiceer naar tijdlijn' : 'Maak update compleet'}</button>
    </section>
  </main>;
}

function RoomComposer({ auth, onBack }) {
  const [homes, setHomes] = useState([]); const [homeId, setHomeId] = useState(''); const [name, setName] = useState(''); const [type, setType] = useState(''); const [status, setStatus] = useState('');
  useEffect(() => { let mounted = true; auth.req('/api/homes').then((data) => { if (!mounted) return; const list=Array.isArray(data)?data:[]; setHomes(list); if (list[0]) setHomeId(list[0].id); }).catch(() => { if (mounted) setHomes([]); }); return () => { mounted = false; }; }, [auth]);
  async function submit() { try { await auth.req(`/api/homes/${homeId}/rooms`, { method: 'POST', body: JSON.stringify({ name, room_type: type, cover_url: DEFAULT_ROOM }) }); setStatus('Kamer aangemaakt. Plaats nu de eerste update.'); setName(''); setType(''); } catch (error) { setStatus(`Mislukt: ${error.message}`); } }
  return <main className="screen composer-v13"><ComposerTop onBack={onBack} step="Nieuwe ruimte" title="Nieuwe kamer" subtitle="Start een ruimte die mensen apart kunnen volgen."/><section className="composer-card-v13"><label><small>Kamernaam</small><input value={name} onChange={(e)=>setName(e.target.value)} placeholder="Bijv. Woonkamer"/></label><label><small>Kamertype</small><input value={type} onChange={(e)=>setType(e.target.value)} placeholder="Keuken, slaapkamer, badkamer..."/></label><label><small>Hoort bij huis</small><select value={homeId} onChange={(e)=>setHomeId(e.target.value)}>{homes.map(h=><option value={h.id} key={h.id}>{h.title}</option>)}</select></label>{status ? <p className="status-message">{status}</p>:null}<button className="publish-bar-v13" onClick={submit}><Check size={18}/> Maak kamer</button></section></main>;
}
function HomeComposer({ auth, onBack }) {
  const [title,setTitle]=useState(''); const [description,setDescription]=useState(''); const [style,setStyle]=useState(''); const [status,setStatus]=useState('');
  async function submit(){try{await auth.req('/api/homes',{method:'POST',body:JSON.stringify({title:title||'Mijn Roomarc huis',description,style_text:style,cover_url:DEFAULT_COVER})}); setStatus('Huisprofiel aangemaakt. Voeg nu kamers toe.');}catch(error){setStatus(`Mislukt: ${error.message}`)}}
  return <main className="screen composer-v13"><ComposerTop onBack={onBack} step="Huisprofiel" title="Bouw je profiel" subtitle="Een etalage voor je huis, kamers en stijl."/><section className="live-preview-v13 profile-live"><span>Profiel preview</span><article><img src={DEFAULT_COVER}/><div><small>{style || 'Stijlrichting'} · @roomarc</small><strong>{title || 'Jouw huisnaam'}</strong><p>{description || 'Korte bio over je interieur of verbouwing.'}</p></div></article></section><section className="composer-card-v13"><label><small>Naam</small><input value={title} onChange={(e)=>setTitle(e.target.value)} placeholder="Bijv. Villa Rutte"/></label><label><small>Bio</small><textarea value={description} onChange={(e)=>setDescription(e.target.value)} placeholder="Vertel kort over je huis/interieur."/></label><label><small>Stijl</small><input value={style} onChange={(e)=>setStyle(e.target.value)} placeholder="Japandi, hotel chique, minimal..."/></label>{status ? <p className="status-message">{status}</p>:null}<button className="publish-bar-v13" onClick={submit}><Check size={18}/> Bewaar huisprofiel</button></section></main>;
}
function BeforeAfter({ onBack }) { return <main className="screen composer-v13"><ComposerTop onBack={onBack} step="Voor/na" title="Before/after" subtitle="De slider wordt een apart contenttype naast de timeline."/><section className="before-mini-v12"><span>Voor</span><i/><span>Na</span></section><button className="publish-bar-v13" onClick={onBack}>Terug naar Studio</button></main>; }

export function Studio({ auth, onPosted }) {
  const [mode, setMode] = useState('home'); const [selectedRoom, setSelectedRoom] = useState(null);
  function goHome(){ setMode('home'); setSelectedRoom(null); }
  if (mode === 'update') return <UpdateComposer auth={auth} selectedRoom={selectedRoom} onBack={goHome} onPosted={onPosted} />;
  if (mode === 'room') return <RoomComposer auth={auth} onBack={goHome} />;
  if (mode === 'homeProfile') return <HomeComposer auth={auth} onBack={goHome} />;
  if (mode === 'before') return <BeforeAfter onBack={goHome} />;
  return <StudioHome auth={auth} setMode={setMode} preselectRoom={setSelectedRoom} />;
}
