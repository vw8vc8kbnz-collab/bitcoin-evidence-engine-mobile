#!/usr/bin/env python3
"""Deterministic FIX660 regression checks (no network, no live-state mutation)."""
from __future__ import annotations

import argparse
import importlib.util
import io
import types
import json
import os
import queue
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

RELEASE_ROOT = Path(__file__).resolve().parents[1]
APP = RELEASE_ROOT / 'app'
sys.path.insert(0, str(APP))

import catalog_importer
import catalog_taxonomy
import pricing_helpers
import server_helpers


def load_server():
    spec = importlib.util.spec_from_file_location('fix657_server_regression', APP / 'server_py.py')
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod


def check(condition: bool, label: str) -> None:
    if not condition:
        raise AssertionError(label)
    print('PASS:', label)


def csv_fixture() -> str:
    headers = ','.join(f'""{x}""' for x in catalog_importer.EXPECTED_HEADERS)
    row = ','.join([
        'TEST001',
        '""https://example.invalid/test-panel-2440x1220x18mm.jpg""',
        '""Test plaat""',
        '""18""',
        '""2440""',
        '""1220""',
        '""69.57""',
    ])
    return f'"{headers}"\n"{row}"\n'


def test_catalog_parser(optional_csv: Path | None = None) -> None:
    parsed = catalog_importer.parse_catalog_csv(csv_fixture())
    check(parsed.get('summary', {}).get('blockingErrors') == 0, 'synthetic website CSV accepted')
    rec = (parsed.get('records') or [None])[0]
    check(isinstance(rec, dict), 'synthetic catalog record created')
    check(rec.get('sellPriceInclVatPerSheet') == 69.57, 'CSV gross sheet cents preserved exactly')
    check(rec.get('priceSource') == 'CSV_SALE_PRICE_INCL_VAT', 'CSV price basis marked incl-VAT')
    if optional_csv:
        text = optional_csv.read_text(encoding='utf-8-sig')
        real = catalog_importer.parse_catalog_csv(text)
        summary = real.get('summary') or {}
        check(summary.get('blockingErrors') == 0, 'provided current CSV has no blocking import errors')
        check(int(summary.get('eligible') or 0) > 0, 'provided current CSV contains eligible 18/19/20 mm records')
        records = real.get('records') or []
        check(bool(records) and all(float(r.get('sellPriceInclVatPerSheet') or 0) > 0 for r in records), 'every eligible CSV record has gross sheet price')
        check(any(abs(float(r.get('sellPriceInclVatPerSheet') or 0) - 69.57) < 1e-9 for r in records), 'provided current CSV preserves the observed EUR 69.57 sheet price as gross')
        review=[r for r in records if r.get('taxonomyStatus')=='REVIEW_REQUIRED']
        check(not review, 'all eligible records in the provided current CSV are deterministically classified')
        check(all(r.get('primaryVisualFamily') in catalog_taxonomy.PUBLIC_FAMILIES for r in records), 'every current CSV record has exactly one public primary family')
        check(all(r.get('substrateType') in {'MDF','SPAANPLAAT','MULTIPLEX','OVERIG'} for r in records), 'every current CSV record has a resolved substrate')
        dup=[r for r in records if r.get('productName')=='MDF Grondeerfolie vochtwerend Wit 050 mat']
        sizes={(int(r.get('sheetLen') or 0),int(r.get('sheetWid') or 0)) for r in dup}
        check(len(dup)>=3 and {(2440,1220),(3050,1220),(2800,2070)}.issubset(sizes), 'duplicate grondeerfolie names retain distinct authoritative sheet sizes')

        # Future CSV lifecycle: a repeated import must reuse verified taxonomy and stay
        # unchanged; a price change is a catalog change without invalidating taxonomy; a
        # new safely-recognized item is auto-classified; a removed CSV item disappears.
        first_enriched,first_tax,first_review=catalog_taxonomy.enrich_catalog_records(records, {'byArticle':{}})
        check(not first_review and first_tax['verified']==len(records), 'current CSV can seed the private verified taxonomy registry')
        registry=catalog_taxonomy.registry_with_records({'byArticle':{}},first_enriched)
        repeat,repeat_tax,repeat_review=catalog_taxonomy.enrich_catalog_records(records, registry)
        check(not repeat_review and repeat_tax['reused']==len(records), 'identical future CSV reuses all verified taxonomy metadata')
        same_diff=catalog_importer.catalog_diff(repeat, first_enriched, [])
        check(same_diff['counts']['unchanged']==len(records) and same_diff['counts']['changed']==0 and same_diff['counts']['new']==0 and same_diff['counts']['missingFromSource']==0, 'identical future CSV produces a clean unchanged diff')

        modified=[dict(x) for x in records]
        modified[0]['sellPriceInclVatPerSheet']=round(float(modified[0]['sellPriceInclVatPerSheet'])+1.23,2)
        new_row=dict(dup[0]); new_row['articleNo']='FUTURE_SAFE_001'; new_row['materialCode']='FUTURE_SAFE_001'; new_row['sheetLen']=3200.0
        modified.append(new_row)
        removed_article=str(modified[1]['articleNo'])
        modified=[x for x in modified if str(x.get('articleNo'))!=removed_article]
        future,future_tax,future_review=catalog_taxonomy.enrich_catalog_records(modified, registry)
        check(not future_review and future_tax['reused']>=len(records)-2 and future_tax['autoVerified']>=1, 'future CSV auto-classifies safe new products while reusing known products')
        future_diff=catalog_importer.catalog_diff(future, first_enriched, [])
        check(future_diff['counts']['new']==1 and future_diff['counts']['changed']==1 and future_diff['counts']['missingFromSource']==1, 'future CSV diff detects added, changed and removed products exactly')
        print('INFO: current CSV summary', json.dumps(summary, ensure_ascii=False, sort_keys=True))


def _tax_record(name: str, brand: str = '') -> dict:
    return {'articleNo':'T1','productName':name,'brand':brand,'thicknessMm':18,'sheetLen':2800,'sheetWid':2070,'sellPriceInclVatPerSheet':100.0}


def test_taxonomy_rules() -> None:
    cases = [
        ('DecoLegno LS63 Ceppo MFC','DecoLegno','Hout','SPAANPLAAT'),
        ('DecoLegno FA84 Ametis MFC','DecoLegno','Textiel & leer','SPAANPLAAT'),
        ('DecoLegno S128 Frassino MFC','DecoLegno','Hout','SPAANPLAAT'),
        ('DecoLegno T051 Fusion MFC','DecoLegno','Textiel & leer','SPAANPLAAT'),
        ('DecoLegno FD53 ItalianStone MFC','DecoLegno','Steen & beton','SPAANPLAAT'),
        ('DecoLegno FB86 Toucher MFC','DecoLegno','Metaal','SPAANPLAAT'),
        ('DecoLegno FB11 Maloja MFC','DecoLegno','Steen & beton','SPAANPLAAT'),
        ('DecoLegno U129 Maloja MFC','DecoLegno','Hout','SPAANPLAAT'),
        ('DecoLegno FC13 Talco/ Fiocco FSC','DecoLegno','Steen & beton','SPAANPLAAT'),
        ('DecoLegno UA80 Talco/Fiocco FSC','DecoLegno','Uni','SPAANPLAAT'),
        ('DecoLegno FD37 Traccia/Fiocco MFC','DecoLegno','Metaal','SPAANPLAAT'),
        ('DecoLegno LS69 Traccia/Fiocco MFC','DecoLegno','Hout','SPAANPLAAT'),
        ('DecoLegno UB20 Traccia/Fiocco MFC','DecoLegno','Grafisch','SPAANPLAAT'),
        ('DecoLegno UB20 Riga/ Fiocco','DecoLegno','Grafisch','SPAANPLAAT'),
        ('DecoLegno FD36 Taranta MFC','DecoLegno','Metaal','SPAANPLAAT'),
        ('DecoLegno FD01 Taranta','DecoLegno','Steen & beton','SPAANPLAAT'),
        ('DecoLegno MDF HM04 Piombo/ Fiocco','DecoLegno','Uni','MDF'),
        ('Unilin Evola MDF 0U826 CST Stone','Unilin','Uni','MDF'),
        ('Unilin Evola MDF 0U830 CST Mahogany','Unilin','Uni','MDF'),
        ('Unilin Evola 0F981 CST Woven MFC','Unilin','Textiel & leer','SPAANPLAAT'),
        ('Unilin Evola 0F993 M01 Brushed steel blue','Unilin','Metaal','SPAANPLAAT'),
        ('Unilin Evola 0H598 W06 Oak','Unilin','Hout','SPAANPLAAT'),
        ('MDF Grondeerfolie vochtwerend Wit 050 mat','','Uni','MDF'),
        ('Gefineerd Populieren Multiplex Eiken Mixmatch A/A','','Hout','MULTIPLEX'),
        ('Shinnoki MDF 4.0 2-zijdig Bondi Oak','Shinnoki','Hout','MDF'),
    ]
    for name,brand,family,substrate in cases:
        got=catalog_taxonomy.classify_taxonomy(_tax_record(name,brand))
        check(got['primaryVisualFamily']==family and got['substrateType']==substrate and got['taxonomyStatus']=='AUTO_VERIFIED', f'taxonomy exact: {name}')
    unknown=catalog_taxonomy.classify_taxonomy(_tax_record('Nieuwe fabrikant Mysterie 2030',''))
    check(unknown['taxonomyStatus']=='REVIEW_REQUIRED' and unknown['primaryVisualFamily']=='Onbekend', 'unknown future product fails closed into REVIEW_REQUIRED')

    a=_tax_record('Unilin Evola 0H598 W06 Oak','Unilin')
    fp1=catalog_taxonomy.classification_fingerprint(a)
    b=dict(a); b['sellPriceInclVatPerSheet']=999.99; b['sheetLen']=3050; b['sheetWid']=1220
    fp2=catalog_taxonomy.classification_fingerprint(b)
    check(fp1==fp2, 'price or sheet-size changes do not invalidate verified taxonomy identity')
    c=dict(a); c['productName']='Unilin Evola 0F993 M01 Brushed steel blue'
    check(catalog_taxonomy.classification_fingerprint(c)!=fp1, 'classification-relevant product change invalidates taxonomy fingerprint')

    base=[dict(a, articleNo='TAX001')]
    enriched,summary,review=catalog_taxonomy.enrich_catalog_records(base, {'byArticle':{}})
    reg=catalog_taxonomy.registry_with_records({'byArticle':{}},enriched)
    enriched2,summary2,review2=catalog_taxonomy.enrich_catalog_records(base,reg)
    check(not review and not review2 and summary2['reused']==1, 'verified taxonomy registry is reused on later CSV imports')
    # A classifier ruleset upgrade must re-evaluate AUTO_VERIFIED metadata, but a manual
    # VERIFIED decision must survive it when the product identity is unchanged.
    stale_auto=catalog_taxonomy.registry_with_records({'byArticle':{}},enriched)
    stale_auto['byArticle']['TAX001']['taxonomyRulesetVersion']='older-ruleset'
    _,stale_summary,_=catalog_taxonomy.enrich_catalog_records(base,stale_auto)
    check(stale_summary['reused']==0, 'AUTO_VERIFIED registry data is re-evaluated after a ruleset upgrade')
    manual=dict(enriched[0]); manual['taxonomyStatus']='VERIFIED'; manual['taxonomySource']='ADMIN_VERIFIED_OVERRIDE'; manual['taxonomyRulesetVersion']='older-ruleset'
    manual_reg=catalog_taxonomy.registry_with_records({'byArticle':{}},[manual])
    _,manual_summary,_=catalog_taxonomy.enrich_catalog_records(base,manual_reg)
    check(manual_summary['reused']==1 and manual_summary['adminVerified']==1, 'manual VERIFIED taxonomy survives ruleset upgrades for the same product identity')
    override=catalog_taxonomy.apply_admin_override(_tax_record('Mysterieplaat'), 'Fantasie', 'MDF')
    check(override['taxonomyStatus']=='VERIFIED' and override['primaryVisualFamily']=='Fantasie' and override['substrateType']=='MDF', 'Admin can resolve a future REVIEW_REQUIRED product explicitly')


def test_manual_family_override_contract() -> None:
    base = _tax_record('DecoLegno FB11 Maloja MFC','DecoLegno')
    base.update({
        'articleNo':'OVERRIDE001',
        'publicMaterialId':'decor_' + ('a'*20),
        'sourceKind':'CATALOG_IMPORT',
        'active':True,
        'published':True,
        'sheetWid':2070,
        'sheetLen':2800,
        'sellPriceInclVatPerSheet':123.45,
        'sellPriceExVatPerSheet':123.45/1.21,
        'priceSource':'CSV_SALE_PRICE_INCL_VAT',
    })
    classified = dict(base, **catalog_taxonomy.classify_taxonomy(base))
    immutable = {k: classified.get(k) for k in (
        'articleNo','publicMaterialId','productName','sheetWid','sheetLen','thicknessMm',
        'sellPriceInclVatPerSheet','sellPriceExVatPerSheet','priceSource','sourceKind','active','published'
    )}
    manual = catalog_taxonomy.apply_admin_family_override(classified, 'Hout')
    check(manual['primaryVisualFamily']=='Hout' and manual['taxonomyManualFamilyOverride']=='Hout', 'Admin can override only the primary filter family')
    check(manual['substrateType']==classified['substrateType'], 'manual family override preserves MDF/spaanplaat substrate')
    check(all(manual.get(k)==v for k,v in immutable.items()), 'manual family override cannot mutate CSV price/size/identity truth')
    reg = catalog_taxonomy.registry_with_records({'byArticle':{}}, [manual])
    check(reg['byArticle']['OVERRIDE001'].get('taxonomyManualFamilyOverride')=='Hout', 'manual filter override is persisted in private taxonomy registry')
    later, summary, review = catalog_taxonomy.enrich_catalog_records([base], reg)
    check(not review and summary['reused']==1 and later[0]['primaryVisualFamily']=='Hout', 'manual filter override survives a later unchanged CSV import')
    price_changed=dict(base); price_changed['sellPriceInclVatPerSheet']=222.22
    later2, summary2, review2 = catalog_taxonomy.enrich_catalog_records([price_changed], reg)
    check(not review2 and summary2['reused']==1 and later2[0]['primaryVisualFamily']=='Hout', 'manual filter override survives price changes because CSV price is separate truth')
    restored = catalog_taxonomy.clear_admin_family_override(manual)
    check('taxonomyManualFamilyOverride' not in restored and restored['primaryVisualFamily']=='Steen & beton', 'Automatisch removes manual override and restores deterministic classifier')
    check(all(restored.get(k)==v for k,v in immutable.items()), 'automatic reset also preserves CSV truth fields')


def test_library_ui_taxonomy_contract() -> None:
    js=(APP/'decor_library.js').read_text(encoding='utf-8')
    html=(APP/'toolA.html').read_text(encoding='utf-8')
    src=(APP/'server_py.py').read_text(encoding='utf-8')
    check("if(UI.filter !== 'all') idx = idx.filter(x=>x.bucket===UI.filter);" in js, 'primary filters use only the one primary family bucket')
    filtered=js[js.index('function filteredCatalog'):js.index('function cardHtml')]
    check('visualLower.has' not in filtered, 'secondary visual/search tags cannot leak products into a second main filter')
    check('function sheetSizeLabel' in js and '${esc(sheetSize)}' in js, 'material cards render authoritative sheet dimensions')
    check('function substrateLabel' in js and '${esc(substrate)}' in js, 'material cards/selection render MDF-spaanplaat-multiplex substrate')
    check('data-filter="graphic"' in js and 'data-filter="fantasy"' in js, 'official Grafisch and Fantasie primary filters are available')
    check('primaryVisualFamily' in html and 'substrateType' in html and 'substrateLabel' in html, 'Tool A public normalization retains FIX658 taxonomy fields')
    check("'primaryVisualFamily':" in src and "'substrateType':" in src and "'collection':" in src, 'public material contract exposes only useful customer taxonomy metadata')
    public_method=src[src.index('def _material_record_to_toola_catalog'):src.index('def _material_id_maps')]
    check('manufacturerCode' not in public_method and 'taxonomySource' not in public_method and 'taxonomyConfidence' not in public_method and 'articleNo' not in public_method.split('return {',1)[1], 'private taxonomy evidence and internal article number do not enter public material contract')
    check('/api/admin/materials/catalog_taxonomy_override' in src and 'Classificatie is nog niet compleet:' in src and "reviewRequired') or 0) != 0" in src, 'future uncertain products have Admin review endpoint and publish guard')
    check('id="matCsvOnlyFamilyOverride"' in src and '<option value="AUTO">Automatisch</option>' in src, 'Admin active-library detail has compact per-product filter dropdown with automatic reset')
    check('/api/admin/materials/live_taxonomy_family' in src and 'def _api_admin_live_taxonomy_family' in src, 'Admin active-library dropdown has authenticated live taxonomy endpoint')
    check('Taxonomy override probeerde CSV-waarheid te wijzigen.' in src, 'live override endpoint contains immutable CSV-truth guard')
    public_method=src[src.index('def _material_record_to_toola_catalog'):src.index('def _material_id_maps')]
    check('taxonomyManualFamilyOverride' not in public_method, 'manual override state remains private and is not exposed to Tool A')
    check("'decorLibrarySchemaVersion': 4" in src and "raw['decorLibrarySchemaVersion'] = 4" in src, 'FIX658 active/public material schema remains v4 after load and future publish')


def test_backfill_contract() -> None:
    server=(APP/'server_py.py').read_text(encoding='utf-8')
    endpoint=server[server.index('def _api_admin_live_taxonomy_family'):server.index('def _api_admin_catalog_preview')]
    check('Taxonomy override probeerde CSV-waarheid te wijzigen.' in endpoint and 'sellPriceInclVatPerSheet' in endpoint and 'publicMaterialId' in endpoint, 'live taxonomy updates protect price, public ID and CSV source fields')
    check('_catalog_review_sha256' in server and 'catalog_signoff.json' in server and 'materialLibrarySha256' in server, 'catalog publication is bound to reviewed content and the active-library hash')
    deploy=(RELEASE_ROOT/'DEPLOY_FIX660.sh').read_text(encoding='utf-8')
    installer=(RELEASE_ROOT/'INSTALL_FIX660R8_FROM_STAGE.sh').read_text(encoding='utf-8')
    check('METOD_STATE_ROOT' in deploy and 'ReadWritePaths=$STATE_DIR' in deploy, 'deploy binds all mutable catalog/state to the external state root')
    check('material_library.json' in installer and 'Actieve gepubliceerde catalogus is leeg' in installer, 'installer migrates the live catalog and blocks an empty catalog before switch')


def test_live_admin_family_endpoint(server) -> None:
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        system = root / 'system'; system.mkdir()
        media = root / 'decor_media'; media.mkdir()
        record = _tax_record('DecoLegno FB11 Maloja MFC','DecoLegno')
        record.update(catalog_taxonomy.classify_taxonomy(record))
        record.update({
            'articleNo':'LIVE001','materialCode':'LIVE001','publicMaterialId':'decor_' + ('b'*20),
            'sourceKind':'CATALOG_IMPORT','active':True,'published':True,'archived':False,
            'catalogMissing':False,'catalogExcluded':False,'sheetWid':2070,'sheetLen':2800,
            'sellPriceInclVatPerSheet':123.45,'sellPriceExVatPerSheet':round(123.45/1.21,6),
            'priceVatRate':0.21,'priceSource':'CSV_SALE_PRICE_INCL_VAT',
        })
        lib = root / 'material_library.json'
        lib.write_text(json.dumps({'source':'CSV_CATALOG_ONLY','decorLibrarySchemaVersion':4,'records':[record]}),encoding='utf-8')
        reg = system / 'catalog_taxonomy_registry.json'
        catalog_taxonomy.save_registry(reg, catalog_taxonomy.registry_with_records({'byArticle':{}}, [record]))
        old = (server.ROOT, server.MATERIAL_LIBRARY_PATH, server.CATALOG_TAXONOMY_REGISTRY, server.DECOR_MEDIA_ROOT, server.PUBLIC_MATERIAL_CATALOG_CACHE_PATH, server.PUBLIC_MATERIAL_CATALOG_CACHE_META_PATH, server._append_system_event)
        server.ROOT=root; server.MATERIAL_LIBRARY_PATH=lib; server.CATALOG_TAXONOMY_REGISTRY=reg; server.DECOR_MEDIA_ROOT=media
        server.PUBLIC_MATERIAL_CATALOG_CACHE_PATH=system/'public_material_catalog_v1.json'
        server.PUBLIC_MATERIAL_CATALOG_CACHE_META_PATH=system/'public_material_catalog_v1.meta.json'
        server._append_system_event=lambda **kwargs: None
        try:
            def call(family):
                payload=json.dumps({'publicMaterialId':record['publicMaterialId'],'primaryVisualFamily':family}).encode()
                h=object.__new__(server.Handler)
                h.headers=DummyHeaders({'Content-Length':str(len(payload)),'Content-Type':'application/json'})
                h.rfile=io.BytesIO(payload)
                h._send_json=types.MethodType(lambda self,obj,status=200,headers=None:(status,obj),h)
                return server.Handler._api_admin_live_taxonomy_family(h)
            status,j=call('Hout')
            check(status==200 and j.get('ok') and j.get('manualOverride') is True and j.get('primaryVisualFamily')=='Hout', 'live Admin endpoint persists a manual Hout filter override')
            stored=json.loads(lib.read_text(encoding='utf-8'))['records'][0]
            check(stored['sellPriceInclVatPerSheet']==123.45 and stored['sheetWid']==2070 and stored['sheetLen']==2800, 'live Admin endpoint preserves CSV price and dimensions byte-semantically')
            persisted=catalog_taxonomy.load_registry(reg)['byArticle']['LIVE001']
            check(persisted.get('taxonomyManualFamilyOverride')=='Hout', 'live Admin endpoint writes manual family to private registry')
            status2,j2=call('AUTO')
            check(status2==200 and j2.get('ok') and not j2.get('manualOverride') and j2.get('primaryVisualFamily')=='Steen & beton', 'live Admin endpoint can reset product back to automatic classification')
        finally:
            server.ROOT, server.MATERIAL_LIBRARY_PATH, server.CATALOG_TAXONOMY_REGISTRY, server.DECOR_MEDIA_ROOT, server.PUBLIC_MATERIAL_CATALOG_CACHE_PATH, server.PUBLIC_MATERIAL_CATALOG_CACHE_META_PATH, server._append_system_event = old
            server._invalidate_public_materials_response_cache()


def test_material_mapping(server) -> None:
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        (root / 'material_library.json').write_text(json.dumps({
            'source': 'CSV_CATALOG_ONLY',
            'records': [{
                'articleNo': 'TEST001',
                'sourceKind': 'CATALOG_IMPORT',
                'active': True,
                'archived': False,
                'published': True,
                'catalogExcluded': False,
                'thicknessMm': 18,
                'sheetWid': 1220,
                'sheetLen': 2440,
                'productName': 'Test plaat',
                'sellPriceInclVatPerSheet': 69.57,
                'priceSource': 'CSV_SALE_PRICE_INCL_VAT',
            }],
        }), encoding='utf-8')
        old_library = server.MATERIAL_LIBRARY_PATH
        server.MATERIAL_LIBRARY_PATH = root / 'material_library.json'
        try:
            pricing = {
                'defaults': {
                    'sheetMarginMm': 7,
                    'nestingGapMm': 16,
                    'kerfMm': 13,
                },
                'edgeBanding': {'defaultLossPercent': 10},
            }
            out = server._ensure_pricing_materials(
                pricing,
                'PartId;PanelName;Qty;LengthMm;WidthMm;ThicknessMm;MaterialCode;GrainGroup;RotationAllowed;H1;H2;W1;W2\n'
                'P1;Test paneel;1;500;500;18;TEST001;;true;0;0;0;0\n',
            )
        finally:
            server.MATERIAL_LIBRARY_PATH = old_library
        mat = out['materials'][0]
        check(mat['sellPriceInclVatPerSheet'] == 69.57, 'pricing material keeps exact gross CSV price')
        check(abs(mat['purchasePricePerSheet'] - (69.57 / 1.21)) < 1e-9, 'legacy optimizer field is accounting net equivalent only')
        check(mat['materialPriceBasis'] == 'CSV_SELL_PRICE_INCL_VAT', 'material basis explicit in pricing payload')


def test_mixed_vat_quote(server) -> None:
    original = server._load_pricing_config
    server._load_pricing_config = lambda: {'sellPricing': {
        'edgeBandPricePerM': 4.5,
        'cncCostPerSheet': 10.0,
        'drawingCostFixed': 20.0,
        'transportCostFixed': 30.0,
    }}
    try:
        quote = {
            'materials': [{
                'materialCode': 'TEST001', 'thicknessMm': 18, 'sheetCount': 1,
                'sheetUnitCost': 69.57 / 1.21,
                'sellPriceExVatPerSheet': 69.57 / 1.21,
                'sellPriceInclVatPerSheet': 69.57,
            }],
            'edgeBanding': {'byCodeMetersWithLoss': {'1': 2.0}},
            'totals': {},
        }
        out = server._apply_sell_pricing_to_quote(quote)
    finally:
        server._load_pricing_config = original
    totals = out['totals']
    check(out['materials'][0]['sheetCostTotalInclVat'] == 69.57, 'one sheet remains EUR 69.57 incl-VAT')
    check(totals['sheetCostTotalInclVat'] == 69.57, 'material total is gross CSV truth')
    check(totals['otherCostsExVat'] == 69.00, 'other Admin costs remain ex-VAT')
    check(totals['otherCostsVat'] == 14.49, '21% VAT is added only to other costs')
    check(totals['totalInclVat'] == 153.06, 'mixed VAT final total is exact')


def test_summary_parser() -> None:
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        (root / 'calculation_summary.txt').write_text(
            'Kostenopbouw\n----------------------------------------\n'
            'Plaatmateriaal incl. btw: €69,57\n'
            'Kantenband excl. btw:      €9,00\n'
            'CNC excl. btw:             €10,00\n'
            'Tekenen excl. btw:         €20,00\n'
            'Transport excl. btw:       €30,00\n\n'
            'Fiscale uitsplitsing\n----------------------------------------\n'
            'Plaatmateriaal netto-equivalent: €57,50\n'
            'BTW reeds in plaatprijs:          €12,07\n'
            'Overige kosten excl. btw:         €69,00\n'
            'BTW over overige kosten:          €14,49\n'
            'Subtotaal excl. btw: €126,50\n'
            'BTW (21%):          €26,56\n'
            'Totaal incl. btw:    €153,06\n',
            encoding='utf-8',
        )
        parsed = pricing_helpers.parse_calculation_summary_totals(root)
    expected = {
        'materialsTotalInclVat': 69.57, 'materialsTotal': 57.50,
        'materialsVatIncluded': 12.07, 'edgeBandTotal': 9.0, 'cncTotal': 10.0,
        'drawingTotal': 20.0, 'transportTotal': 30.0, 'otherCostsExVat': 69.0,
        'otherCostsVat': 14.49, 'subtotalExVat': 126.50, 'vatAmount': 26.56,
        'totalInclVat': 153.06,
    }
    check(parsed == expected, 'human summary parser retains full mixed-VAT breakdown')


class DummyHeaders(dict):
    def get(self, key, default=None):
        return super().get(key, default)


class DummyHandler:
    def __init__(self, headers=None):
        self.headers = DummyHeaders(headers or {})


def test_header_only_job_token() -> None:
    check(server_helpers.extract_request_token(DummyHandler({'Authorization': 'Bearer abc'})) == 'abc', 'Bearer job token accepted')
    check(server_helpers.extract_request_token(DummyHandler({'X-Job-Token': 'abc'})) == '', 'X-Job-Token retired')
    check(server_helpers.extract_request_token(DummyHandler({}), parsed='?token=abc', body={'accessToken': 'abc'}) == '', 'query/body job token rejected')


def test_sse_privacy(server) -> None:
    q = queue.Queue()
    server._SSE_CLIENTS[:] = [q]
    server._sse_broadcast('request_submitted', {'requestId': 'SECRET'})
    check(q.empty(), 'public SSE drops request lifecycle events')
    server._sse_broadcast('dxf_changed', {'dxfVersion': 'v123', 'category': 'private', 'filename': 'x.dxf'})
    item = q.get_nowait()
    check(item['event'] == 'dxf_changed', 'public SSE still carries DXF freshness')
    check(item['data'] == {'dxfVersion': 'v123'}, 'public SSE strips filename/category metadata')
    server._SSE_CLIENTS[:] = []


def test_queue_no_optimizer(server) -> None:
    src = (APP / 'server_py.py').read_text(encoding='utf-8')
    a = src.index('def process_one_queue_item')
    b = src.index('def _recover_processing_queue_items_fix657', a)
    check('_create_job_from_payload(' not in src[a:b], 'queue worker can no longer launch optimization')
    check('LEGACY_QUEUE_ITEM_REQUIRES_REVIEW' in src[a:b], 'unsafe legacy queue work fails closed')


def test_production_source_contract() -> None:
    src = (APP / 'server_py.py').read_text(encoding='utf-8')
    helper = (APP / 'server_helpers.py').read_text(encoding='utf-8')
    html = (APP / 'toolA.html').read_text(encoding='utf-8')
    check("_PUBLIC_SSE_EVENT_ALLOWLIST = frozenset({'dxf_changed'})" in src, 'SSE allowlist source contract')
    check("secure = '; Secure' if (_is_production_runtime() or _is_https_request(self))" in src, 'production Admin cookie is always Secure')
    check('def _is_legacy_http_proxy_request(handler)' not in src and 'legacy plaintext HTTP compatibility is forbidden' in src, 'production legacy HTTP bridge is removed and rejected')
    check("if _is_production_runtime():\n            return False\n        if not auth.startswith(\"Basic \")" in src, 'Basic authentication is disabled in production')
    check("script-src 'self'{nonce_source}" in src and "script-src-attr 'none'" in src, 'production CSP authorizes inline scripts only through per-response nonces')
    check('class BoundedThreadingHTTPServer' in src and '_MAX_SSE_CLIENTS' in src, 'application HTTP and SSE concurrency are bounded')
    check('if production:\n                return False' in helper, 'Admin same-origin host fallback disabled in production')
    check('if _is_production_runtime():\n                    return False' in src, 'Public same-origin host fallback disabled in production')
    check("buildJobTokenHeaders(state?.lastJobAccessToken" in html, 'final submit transmits bearer header')
    check("sessionStorage.setItem('metod_last_job_access_token'" in html and "localStorage.setItem('metod_last_job_access_token'" not in html, 'job bearer token is session-scoped, not durable localStorage')
    check("localStorage.setItem('metod_draft_v1'" not in html and "sessionStorage.setItem('metod_last_request_cancel_token'" in html, 'customer PII is not draft-persisted and cancel capability stays tab-scoped')
    check('FIX660_GRAIN_STUDIO' in src and "__TOOLA_GRAIN_STUDIO_BUILD='FIX660_GRAIN_STUDIO'" in html, 'FIX660 build marker present in backend and Tool A')



def test_submission_idempotency(server) -> None:
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        old_requests = server.REQUESTS
        old_markers = server.SUBMISSION_IDEMPOTENCY_DIR
        server.REQUESTS = root / 'requests'
        server.SUBMISSION_IDEMPOTENCY_DIR = root / 'markers'
        try:
            claimed, rid = server._reserve_submission_claim('job_parent_1', 'REQ_A')
            check(claimed and rid == 'REQ_A', 'first final submission atomically claims parent job')
            claimed2, rid2 = server._reserve_submission_claim('job_parent_1', 'REQ_B')
            check((not claimed2) and rid2 == 'REQ_A', 'duplicate final submission reuses existing claim instead of duplicating work')
            (server.REQUESTS / 'REQ_A').mkdir(parents=True, exist_ok=True)
            (server.REQUESTS / 'REQ_A' / 'status.json').write_text('{}', encoding='utf-8')
            check(server._read_submission_claim('job_parent_1') == 'REQ_A', 'submission claim survives after request status persistence')
        finally:
            server.REQUESTS = old_requests
            server.SUBMISSION_IDEMPOTENCY_DIR = old_markers


def test_production_runtime_guard(server) -> None:
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        release = root / 'release'; release.mkdir()
        state = root / 'state'; (state / 'system').mkdir(parents=True)
        creds = root / 'admin.json'
        creds.write_text(json.dumps({'schemaVersion':2,'users':[{
            'username':'release-admin','password_hash':'pbkdf2_sha256$260000$testsalt01234567$' + ('a'*64),
            'totp_secret':'JBSWY3DPEHPK3PXP','roles':['admin'],'active':True,
        }]}), encoding='utf-8')
        os.chmod(creds, 0o600)
        library = state / 'material_library.json'
        library.write_text(json.dumps({'source':'CSV_CATALOG_ONLY','records':[{
            'sourceKind':'CATALOG_IMPORT','active':True,'archived':False,'published':True,
            'catalogMissing':False,'catalogExcluded':False,
        }]}), encoding='utf-8')
        import hashlib
        library_hash=hashlib.sha256(library.read_bytes()).hexdigest()
        signoff=state/'system/catalog_signoff.json'
        signoff.write_text(json.dumps({'approved':True,'approvedBy':'owner','approvedAt':'2026-08-12T00:00:00Z','materialLibrarySha256':library_hash}),encoding='utf-8')
        restore=state/'system/restore_test_proof.json'
        restore.write_text(json.dumps({'ok':True,'verifiedAt':datetime.now(timezone.utc).isoformat(),'backupSha256':'b'*64}),encoding='utf-8')
        base = {
            'APP_ENV':'production', 'PRODUCTION_HARDENING':'1', 'ADMIN_HASH_ONLY':'1', 'ADMIN_STAGING_OPEN':'0',
            'PUBLIC_JSON_MAX_BYTES':str(16*1024*1024), 'SUBMIT_MAX_BYTES':str(8*1024*1024),
            'PUBLIC_DXF_BLOB_MAX_BYTES':str(2*1024*1024), 'PUBLIC_JOB_MAX_CONCURRENT':'1',
            'PUBLIC_JOB_MAX_QUEUED':'8', 'PUBLIC_JOB_MAX_CONCURRENT_PER_IP':'2',
            'ADMIN_CREDENTIALS_FILE':str(creds),
            'ADMIN_PASSWORD_RESET_ACTIVATION_FILE':str(root / 'reset-disabled.json'),
            'ALLOWED_ORIGINS':'https://example.invalid','ALLOWED_ADMIN_ORIGINS':'https://example.invalid',
            'METOD_PUBLIC_BASE_URL':'https://example.invalid','PRODUCTION_MIN_CATALOG_RECORDS':'1',
            'CATALOG_SIGNOFF_FILE':str(signoff),'OFFSITE_BACKUP_VERIFIED':'1',
            'OFFSITE_BACKUP_PROVIDER':'test-encrypted-offsite','RESTORE_TEST_PROOF_FILE':str(restore),
        }
        touched = set(base) | {'ALLOWED_ORIGINS','ALLOWED_ADMIN_ORIGINS','LEGACY_HTTP_COMPAT','LEGACY_HTTP_ORIGIN'}
        old = {k: os.environ.get(k) for k in touched}
        old_globals=(server.RELEASE_ROOT,server.STATE_ROOT,server.MATERIAL_LIBRARY_PATH,server.SYSTEM_DIR,server.os.geteuid)
        try:
            server.RELEASE_ROOT=release; server.STATE_ROOT=state; server.MATERIAL_LIBRARY_PATH=library; server.SYSTEM_DIR=state/'system'
            server.os.geteuid=lambda:1000
            os.environ.update(base)
            os.environ.pop('LEGACY_HTTP_COMPAT', None)
            os.environ.pop('LEGACY_HTTP_ORIGIN', None)
            server._validate_production_runtime_or_die()
            check(True, 'production guard accepts HTTPS + non-root + MFA + catalog/backup evidence')

            os.environ['LEGACY_HTTP_COMPAT']='1'
            os.environ['LEGACY_HTTP_ORIGIN']='http://51.195.102.180:8790'
            os.environ['ALLOWED_ORIGINS']='http://example.invalid:8790'
            rejected=False
            try:
                server._validate_production_runtime_or_die()
            except SystemExit:
                rejected=True
            check(rejected, 'production guard rejects every legacy/plaintext HTTP profile')
        finally:
            server.RELEASE_ROOT,server.STATE_ROOT,server.MATERIAL_LIBRARY_PATH,server.SYSTEM_DIR,server.os.geteuid=old_globals
            for k, v in old.items():
                if v is None: os.environ.pop(k, None)
                else: os.environ[k] = v


class ProxyDummyHandler(DummyHandler):
    def __init__(self, headers=None, peer='127.0.0.1'):
        super().__init__(headers=headers)
        self.client_address = (peer, 43210)
        self.server = type('S', (), {'server_port': 8792})()


def test_https_admin_transport(server) -> None:
    keys={'TRUSTED_PROXY_IPS'}
    old={k:os.environ.get(k) for k in keys}
    try:
        os.environ['TRUSTED_PROXY_IPS']='127.0.0.1,::1'
        https=ProxyDummyHandler({
            'X-Forwarded-Proto':'https','X-Real-IP':'203.0.113.10',
        })
        http=ProxyDummyHandler({
            'X-Forwarded-Proto':'http','X-Real-IP':'203.0.113.10',
        })
        chain=ProxyDummyHandler({'X-Forwarded-Proto':'https','X-Real-IP':'198.51.100.1, 203.0.113.10'})
        check(server._is_secure_admin_transport(https), 'Admin transport accepts trusted HTTPS only')
        check(not server._is_secure_admin_transport(http), 'Admin transport rejects plaintext HTTP')
        check(server._client_ip(https)=='203.0.113.10', 'trusted proxy uses normalized X-Real-IP')
        check(server._client_ip(chain)=='127.0.0.1', 'comma-separated spoofable proxy chains are rejected')
    finally:
        for k,v in old.items():
            if v is None: os.environ.pop(k,None)
            else: os.environ[k]=v




def test_submit_clarity_copy_contract() -> None:
    html = (APP / 'toolA.html').read_text(encoding='utf-8')
    check('Akkoord en aanvraag verzenden' in html, 'customer CTA explicitly states agreement before submission')
    check('Door deze aanvraag te verzenden, ga je akkoord met de bovenstaande totaalprijs incl. btw.' in html, 'price screen explains that submission accepts the displayed price')
    check('factuur binnen <strong>2 werkdagen</strong> naar het opgegeven e-mailadres' in html, 'price screen states the two-working-day invoice window')
    check('Binnen <strong>2 werkdagen</strong> sturen wij de factuur naar' in html, 'thank-you screen repeats the invoice timing')
    check('Je ontvangt per e-mail ook de verdere informatie over je aanvraag.' in html, 'thank-you screen explains follow-up information by email')
    check('Je bent akkoord gegaan met de totaalprijs van <strong>${safeTotal}</strong> incl. btw.' in html, 'thank-you screen records explicit price agreement')
    check('mailto:${encodeURIComponent(String(customerEmail))}' in html, 'thank-you email address is rendered as a safe mailto link')
    check("priceSendBtn.textContent = 'Akkoord en aanvraag verzenden'" in html, 'failed submit restores the clarified CTA')
    check('decor_library.js?v=660r8f' in html, 'Tool A loads the FIX660R8F catalog-image recovery bundle')


def test_material_swatch_renderer_contract() -> None:
    renderer = (APP / 'toolA_material_swatch_renderer.js').read_text(encoding='utf-8')
    html = (APP / 'toolA.html').read_text(encoding='utf-8')
    server = (APP / 'server_py.py').read_text(encoding='utf-8')
    check("BUILD = 'FIX659R1_ADAPTIVE_CNC_MOBILE_FIT'" in renderer, 'shared swatch renderer has FIX659R1 build marker')
    check('toolA_material_swatch_renderer.js?v=659r1' in html, 'Tool A loads shared swatch renderer with cache bust')
    check('"toolA_material_swatch_renderer.js"' in server, 'swatch renderer is in public static allowlist')
    check('Math.max(pw / effectiveW, ph / effectiveH)' in renderer, 'center-cover uses max scale and preserves aspect ratio')
    check('uSpan = panelRatio / imageRatio' in renderer and 'vSpan = imageRatio / panelRatio' in renderer, 'UV center-cover matches agreed exact formula')
    check('ctx.drawImage(entry.image' in renderer, 'canvas renderer draws one source image')
    check('background-repeat' not in renderer.lower() and 'createPattern' not in renderer, 'renderer has no repeat/tile path')
    check('worldRotation' not in renderer and 'rotationDeg ??' not in renderer, 'renderer does not derive material orientation from world rotation')
    check("p.localGrainAxis ?? p.grainAxis" in renderer, 'renderer orientation is driven by explicit local grain metadata')
    check('longest' in renderer and 'Never infer from world rotation or from the longest side.' in renderer, 'source documents and blocks longest-side inference')
    check('drawCanvasMaterial(ctx, rect' in html and "materialKey: String(state.activeMaterialKey || state.selection.materialKey || '')" in html, 'normal panel viewer renders active material')
    check('drawCanvasMaterial(ctx, {x,y,w:rw,h:rh}' in html and '__extraMaterialKey' in html, 'other-panel viewer renders its selected material')
    check('applyDomSwatch(shell' in html and "d.entry?.materialKey || g.materialKey" in html, 'continuous-grain viewer renders each panel assigned material')
    check('synthetic/repeating wood lines' in html and 'const grainGap' not in html[html.find('function drawExtraPreview()'):html.find('function roundRect(', html.find('function drawExtraPreview()'))], 'other-panel preview removed synthetic repeated grain lines')
    check('try{ draw(); }catch(_){ }' in html[html.find('function setActiveMaterial'):html.find('function bootstrapPanelSelectionForActiveMaterial')], 'active material switch redraws main viewer immediately')

    # Exact cover math: square swatch -> tall panel keeps full height and crops left/right.
    js = r"""
require(process.argv[1]);
const r=globalThis.ToolAMaterialSwatchRenderer;
const a=r.coverUv(600,2200,1000,1000);
const b=r.coverGeometry(600,2200,1000,1000,0);
const c=r.coverGeometry(2200,600,1000,1000,0);
console.log(JSON.stringify({a,b,c,rot:r.rotationForAxes('V','U'),same:r.rotationForAxes('V','V')}));
"""
    cp = subprocess.run(['node','-e',js,str(APP/'toolA_material_swatch_renderer.js')], capture_output=True, text=True, check=True)
    data = json.loads(cp.stdout.strip().splitlines()[-1])
    check(abs(data['a']['uSpan'] - (600/2200)) < 1e-9 and data['a']['vSpan'] == 1, 'tall panel UV cover crops symmetrically only in U for square swatch')
    check(abs(data['b']['renderedHeight'] - 2200) < 1e-9 and data['b']['renderedWidth'] > 600, 'tall panel canvas cover fills full height without stretching')
    check(abs(data['c']['renderedWidth'] - 2200) < 1e-9 and data['c']['renderedHeight'] > 600, 'wide panel canvas cover fills full width without stretching')
    check(data['rot'] == 90 and data['same'] == 0, 'only local/image grain-axis mismatch rotates swatch 90 degrees')

    js_draw = r"""
globalThis.Image=class {
  constructor(){ this.naturalWidth=1000; this.naturalHeight=1000; this.complete=false; }
  set src(v){ this._src=v; this.complete=true; if(this.onload) this.onload(); }
  get src(){ return this._src; }
};
require(process.argv[1]);
const r=globalThis.ToolAMaterialSwatchRenderer;
const calls=[];
const grad=()=>({addColorStop(){}});
const ctx={
  save(){},restore(){},beginPath(){},rect(){},clip(){},fillRect(){},
  createLinearGradient:grad, translate(x,y){calls.push(['translate',x,y]);},
  rotate(v){calls.push(['rotate',v]);}, drawImage(){calls.push(['drawImage']);}
};
const result=r.drawCanvasMaterial(ctx,{x:0,y:0,w:600,h:2200},{
  material:{imagePreviewUrl:'/one-square-swatch',primaryVisualFamily:'Hout',imageGrainAxis:'V'},
  panel:{localGrainAxis:'V'}
});
const ctx2={...ctx, rotate(v){calls.push(['rotate2',v]);}, drawImage(){calls.push(['drawImage2']);}};
const result2=r.drawCanvasMaterial(ctx2,{x:0,y:0,w:600,h:2200},{
  material:{imagePreviewUrl:'/two-square-swatch',primaryVisualFamily:'Hout',imageGrainAxis:'V'},
  panel:{localGrainAxis:'U'}
});
console.log(JSON.stringify({result,result2,draws:calls.filter(x=>x[0].startsWith('drawImage')).length,rotated:calls.some(x=>x[0]==='rotate2'&&Math.abs(x[1]-Math.PI/2)<1e-9)}));
"""
    cp2 = subprocess.run(['node','-e',js_draw,str(APP/'toolA_material_swatch_renderer.js')], capture_output=True, text=True, check=True)
    d2 = json.loads(cp2.stdout.strip().splitlines()[-1])
    check(d2['draws'] == 2 and d2['result']['drawn'] is True, 'canvas swatch renderer draws exactly one image per panel call')
    check(d2['rotated'] is True and d2['result2']['rotationDeg'] == 90, 'canvas swatch renderer applies only the explicit local-axis 90-degree rotation')


def test_adaptive_cnc_and_mobile_fit_contract() -> None:
    renderer = (APP / 'toolA_material_swatch_renderer.js').read_text(encoding='utf-8')
    view_math = (APP / 'toolA_view_math_helpers.js').read_text(encoding='utf-8')
    html = (APP / 'toolA.html').read_text(encoding='utf-8')
    check('contrastStrokeAt' in renderer and 'getImageData' in renderer, 'CNC contrast is derived from the actually rendered local swatch pixels')
    check("dark:'rgba(18,28,25,.90)'" in html and "light:'rgba(247,250,248,.94)'" in html, 'viewer uses premium adaptive dark/light CNC stroke pair')
    hole_slice = html[html.find('// FIX659R1: keep the exact 1px CNC line weight'):html.find('// label corner/header', html.find('// FIX659R1: keep the exact 1px CNC line weight'))]
    check('ctx.lineWidth = 1;' in hole_slice and 'ctx.lineWidth = 2;' not in hole_slice and 'shadowBlur' not in hole_slice, 'adaptive CNC visibility keeps the boring line at exactly 1px with no halo')
    check('computePanelPreviewFit' in view_math and 'dimensionGutters' in view_math, 'mobile viewer fit reserves explicit dimension gutters')
    check('toolA_view_math_helpers.js?v=659r1' in html, 'mobile fit helper is cache-busted for FIX659R1')
    check("ctx.fillText(`${formatMm(baseW)} × ${formatMm(baseH + extTopVal + extBotVal)} mm`, 18, 29);" in html, 'mobile header keeps actual panel dimensions on their own untruncated line')

    js_contrast = r"""
global.window=globalThis;
require(process.argv[1]);
const r=globalThis.ToolAMaterialSwatchRenderer;
function ctxFor(rgb){return {canvas:{width:100,height:100,clientWidth:100,clientHeight:100},getImageData(){const d=[];for(let i=0;i<25;i++)d.push(rgb[0],rgb[1],rgb[2],255);return {data:Uint8ClampedArray.from(d)};}};}
console.log(JSON.stringify({light:r.contrastStrokeAt(ctxFor([245,245,240]),50,50),dark:r.contrastStrokeAt(ctxFor([24,28,27]),50,50)}));
"""
    cp=subprocess.run(['node','-e',js_contrast,str(APP/'toolA_material_swatch_renderer.js')],capture_output=True,text=True,check=True)
    data=json.loads(cp.stdout.strip().splitlines()[-1])
    check(data['light'].startswith('rgba(18,28,25') and data['dark'].startswith('rgba(247,250,248'), 'light swatch selects dark CNC detail and dark swatch selects light CNC detail')

    js_fit = r"""
global.window=globalThis;
require(process.argv[1]);
const h=globalThis.ToolAViewMathHelpers;
const m=h.computePanelPreviewFit({canvasWidth:390,canvasHeight:640,previewMinX:0,previewMaxX:600,previewMinY:0,previewMaxY:2200,mobile:true});
const d=h.computePanelPreviewFit({canvasWidth:900,canvasHeight:700,previewMinX:0,previewMaxX:600,previewMinY:0,previewMaxY:2200,mobile:false});
const left=m.ox, top=m.oy-2200*m.scale, right=m.ox+600*m.scale, bottom=m.oy;
console.log(JSON.stringify({m,d,left,top,right,bottom}));
"""
    cp2=subprocess.run(['node','-e',js_fit,str(APP/'toolA_view_math_helpers.js')],capture_output=True,text=True,check=True)
    fit=json.loads(cp2.stdout.strip().splitlines()[-1])
    check(fit['left']-18 >= 10 and fit['top']-22 >= 70 and fit['right'] <= 380 and fit['bottom'] <= 570, 'mobile panel fit keeps outer dimension lines/text inside the visible canvas safe area')
    expected_desktop=min((900-68)/600,(700-68)/2200)*0.90
    check(abs(fit['d']['scale']-expected_desktop) < 1e-12, 'desktop panel fit remains numerically identical to FIX659')



def test_mobile_polish_and_smart_qty_contract() -> None:
    html = (APP / 'toolA.html').read_text(encoding='utf-8')
    check('top:62% !important' in html and '#fix636DrawerHandle' in html, 'mobile Step 2 drawer handle is moved below the typical panel centerline')
    check('width:48px !important' in html and 'font-size:21px !important' in html and '.panelDockMini' in html, 'mobile edit/delete controls have readable icons and 48px tap targets')
    check('id="custPersonalHeading"' in html and 'padding-left:4px !important' in html, 'Persoonlijke gegevens heading has protected left inset and cannot lose its first glyph')
    hinge = html[html.index('function drawMiniSideView'):html.index('function roundRect', html.index('function drawMiniSideView'))]
    check("const x0 = isMobile ? 12" in hinge and "h - boxH - 18" in hinge, 'mobile hinge badge is anchored bottom-left')
    check("ctx.fillText('DRAAIRICHTING'" in hinge and "hingeLabel = hingeOnLeft ? 'Scharnier links' : 'Scharnier rechts'" in hinge, 'hinge control is a clear modern direction badge with explicit text')
    check('cabinet opening/frame' not in hinge and 'miniature product picture' in hinge, 'legacy thumbnail-style hinge drawing is removed')
    qty = html[html.index('<script id="fix659r2SmartQuantityInput">'):html.index('</script>', html.index('<script id="fix659r2SmartQuantityInput">'))]
    check("el.matches('#qty,#extraQty')" in qty, 'smart default-one behavior covers standard and other-panel quantity inputs')
    check("trim() !== '1'" in qty and "el.value=''" in qty and "pointerdown" in qty, 'tapping default quantity 1 clears it for immediate typing')
    check("trim() === ''" in qty and "el.value='1'" in qty, 'leaving an empty quantity restores safe default 1')

    # Execute the inline quantity controller against a tiny fake DOM so iOS-safe
    # clear-on-focus/restore-on-blur semantics are behaviorally checked, not just grepped.
    import re
    m = re.search(r'<script id="fix659r2SmartQuantityInput">(.*?)</script>', html, re.S)
    check(bool(m), 'smart quantity inline controller is present')
    js = r"""
const listeners={};
global.window=globalThis;
global.document={addEventListener:(n,fn)=>{listeners[n]=fn;}};
%s
function input(v){return {value:v,disabled:false,dataset:{},matches:(s)=>s==='#qty,#extraQty',events:[],getBoundingClientRect(){return {right:200};},dispatchEvent(e){this.events.push(e.type);}};}
let a=input('1');listeners.pointerdown({target:a,pointerType:'touch',clientX:100});let afterTap=a.value;listeners.focusout({target:a});let afterBlur=a.value;
let b=input('2');listeners.pointerdown({target:b,pointerType:'touch',clientX:100});let two=b.value;
let c=input('1');listeners.pointerdown({target:c,pointerType:'mouse',clientX:190});let spinner=c.value;
console.log(JSON.stringify({afterTap,afterBlur,two,spinner,events:a.events}));
""" % m.group(1)
    cp = subprocess.run(['node','-e',js],capture_output=True,text=True,check=True)
    data=json.loads(cp.stdout.strip().splitlines()[-1])
    check(data['afterTap']=='' and data['afterBlur']=='1', 'default 1 clears on tap and safely returns on empty blur')
    check(data['two']=='2', 'non-default quantities are never erased on tap')
    check(data['spinner']=='1', 'desktop native number spinner zone keeps its default value and step behavior')
    check('input' in data['events'] and 'change' in data['events'], 'restoring default quantity re-synchronizes existing form state')

def test_viewer_scope_protection() -> None:
    html = (APP / 'toolA.html').read_text(encoding='utf-8')
    server = (APP / 'server_py.py').read_text(encoding='utf-8')
    pricing = (APP / 'pricing_helpers.py').read_text(encoding='utf-8')
    check('catalog_sell_price_incl_vat_v2' in server and 'CSV_SELL_PRICE_INCL_VAT' in server, 'FIX660 retains mixed-VAT material truth')
    check('_finalization_complete(parent_root)' in server and 'submit-config-link' in server, 'FIX660 retains finalized idempotent submit contract')
    check("_PUBLIC_SSE_EVENT_ALLOWLIST = frozenset({'dxf_changed'})" in server, 'FIX660 retains SSE privacy contract')
    check('materialsTotalInclVat' in pricing, 'FIX660 retains pricing helper gross-material fields')
    renderer = (APP / 'toolA_material_swatch_renderer.js').read_text(encoding='utf-8')
    check('51.195.102.180' not in renderer and '8790' not in renderer, 'viewer module carries no deployment/origin policy')


def test_installer_smoke_contract() -> None:
    installer = (RELEASE_ROOT / "INSTALL_FIX660R8_FROM_STAGE.sh").read_text(encoding="utf-8")
    check('EXPECTED_R7' in installer and 'Exacte FIX660R7-baseline bevestigd' in installer, 'installer accepts only the exact R7 baseline or a verified immutable release')
    check('PREVIOUS_TARGET" == "$LEGACY_APP' in installer and 'verify_legacy_r7' in installer, 'rollback symlink to exact legacy R7 is classified as legacy rather than immutable')
    check('PREVIOUS_TARGET" == "$RELEASES_DIR/"*' in installer and 'Huidige immutable release volledig geverifieerd' in installer, 'only managed release-tree targets use immutable full-manifest verification')
    check('sudo env "${SUDO_ENV[@]}"' in installer and 'sudo -E bash' not in installer, 'privilege escalation forwards only explicit deploy environment values')
    check('metod-pax-releases' in installer and 'mv -Tf "$CURRENT_LINK.next" "$CURRENT_LINK"' in installer, 'installer publishes an immutable release through an atomic symlink switch')
    check('state is bewust nooit teruggedraaid' in installer and 'Releasepointer/config teruggezet' in installer, 'rollback changes code/config pointer but never live state')
    check('staging-maintenance' in installer and 'systemctl reload nginx' in installer, 'edge is drained before migration and only reopened after backend checks')
    check('Actieve gepubliceerde catalogus is leeg' in installer, 'empty active catalog blocks the live switch')
    deploy=(RELEASE_ROOT / "DEPLOY_FIX660.sh").read_text(encoding="utf-8")
    check('User=metod-pax' in deploy and 'ProtectSystem=strict' in deploy and 'CapabilityBoundingSet=' in deploy, 'systemd runs non-root with OS sandboxing and no capabilities')
    check('X-Forwarded-For $remote_addr' in deploy and 'limit_req_zone' in deploy and 'limit_conn_zone' in deploy, 'Nginx normalizes proxy IP and enforces request/connection limits')
    check('METOD_DEPLOY_MODE' in deploy and 'https://$DOMAIN' in deploy and 'return 308 https://' in deploy, 'production mode is domain/TLS-only with HTTP redirect')
    check('STAGING_BIND_ADDRESS:-127.0.0.1' in deploy and 'remote staging bind requires STAGING_ALLOWED_CIDR' in deploy, 'staging is loopback-only unless a remote CIDR is explicitly allowlisted')
    check('LEGACY_HTTP_COMPAT' not in deploy, 'deployment never enables legacy plaintext production mode')


def test_mobile_material_cart_and_step_stability_contract() -> None:
    html = (APP / 'toolA.html').read_text(encoding='utf-8')
    cart = (APP / 'toolA_mobile_material_cart.js').read_text(encoding='utf-8')
    check("FIX660R8N_MOBILE_MATERIAL_CART_STEP_STABLE" in html and "FIX660R8N_MOBILE_MATERIAL_CART_STEP_STABLE" in cart, 'R8N mobile basket and step-stability marker is present')
    check('id="mobileMaterialCartTrigger"' in html and 'id="mobileMaterialCartSheet"' in html and 'id="mobileMaterialCartList"' in html, 'mobile footer basket has a trigger, accessible bottom sheet and material list')
    check('toolA_mobile_material_cart.js?v=660r8n' in html, 'mobile basket module has a fresh release cache-buster')
    check('"toolA_mobile_material_cart.js"' in (APP / 'server_py.py').read_text(encoding='utf-8'), 'mobile basket module is served by the explicit public static allowlist')
    auto_start = html[html.index('// Auto-start: route overlay verwijderd'):html.index('// -----------------------------\n  // Ingebouwde METOD templates')]
    check("const __startupStep = String(window.__metod_uiStep || 'material');" in auto_start, 'startup step is committed before asynchronous template loading')
    after_template_await = auto_start[auto_start.index('await loadEmbeddedTemplates()'):]
    check("setStep('material')" not in after_template_await and '__currentStepAfterTemplates' in after_template_await, 'late template completion preserves the customer current wizard step')
    check('body:not([data-ui-step="material"]) #mobileMaterialCartTrigger' in html and '#mobileMaterialCartTrigger,\n.mobileMaterialCartBackdrop,\n.mobileMaterialCartSheet{display:none;}' in html, 'basket remains mobile/material-step only and desktop keeps its right column')
    check("root.document.addEventListener('keydown'" in cart and "event.key === 'Escape'" in cart and "aria-hidden','false'" in cart, 'mobile basket has keyboard close and dialog visibility semantics')
    check('ToolAMaterialSwatchRenderer.applyDomSwatch' in cart and 'ToolAPanelsEntry.removeMaterial' in cart and 'ToolAPanelsEntry.activateMaterial' in cart, 'basket reuses authoritative swatches and existing material mutations')

    js = r"""
global.window=globalThis;
require(process.argv[1]);
const state={activeMaterialKey:'b',materialBatches:[
  {key:'a',mat:{publicName:'Eiken A',primaryVisualFamily:'Hout',thicknessMm:18,sheetSizeMm:{width:2070,height:2800}}},
  {key:'b',mat:{productName:'Uni B',decorType:'Uni',thicknessMm:19,sheetSizeMm:{width:1220,height:3050}}}
]};
const rows=ToolAMobileMaterialCart.getModels(state);
console.log(JSON.stringify({build:ToolAMobileMaterialCart.BUILD,rows}));
"""
    cp = subprocess.run(['node','-e',js,str(APP/'toolA_mobile_material_cart.js')], capture_output=True, text=True, check=True)
    data = json.loads(cp.stdout.strip().splitlines()[-1])
    check(data['build']=='FIX660R8N_MOBILE_MATERIAL_CART_STEP_STABLE' and len(data['rows'])==2, 'mobile basket produces one deterministic row per selected material')
    check(data['rows'][1]['active'] is True and data['rows'][0]['active'] is False, 'mobile basket preserves the one active material selection')
    check(data['rows'][0]['title']=='Eiken A' and '18 mm' in data['rows'][0]['meta'] and '2070 × 2800 mm' in data['rows'][0]['meta'], 'mobile basket shows public material name, thickness and sheet size')


def test_fix660_grain_studio_contract() -> None:
    html=(APP/'toolA.html').read_text(encoding='utf-8')
    mobile=(APP/'toolA_grain_mobile_scale.js').read_text(encoding='utf-8')
    renderer=(APP/'toolA_grain_studio_renderer.js').read_text(encoding='utf-8')
    mathjs=(APP/'toolA_grain_studio_math.js').read_text(encoding='utf-8')
    css=(APP/'toolA_grain_studio.css').read_text(encoding='utf-8')
    legacy_mobile_css=(APP/'toolA_grain_mobile_scale.css').read_text(encoding='utf-8')
    validation=(APP/'toolA_grain_validation.js').read_text(encoding='utf-8')
    server=(APP/'server_py.py').read_text(encoding='utf-8')
    check("__TOOLA_GRAIN_STUDIO_BUILD='FIX660_GRAIN_STUDIO'" in html, 'FIX660 grain studio build marker present')
    check("__TOOLA_PERFORMANCE_BUILD='FIX660_GRAIN_STUDIO'" in html, 'FIX660 overall Tool A performance marker')
    check("FIX660R6_GRAIN_BRIDGE" in html and "window.ToolAGrainBridge" in html, 'legacy closure exposes a narrow explicit Grain Studio bridge')
    check("ToolAGrainStudioMobile.renderEligible" in html and "ToolAGrainStudioMobile.renderGroups" in html and "ToolAGrainStudioRenderer.render" in html, 'legacy grain render entrypoints delegate to the bridged mobile/preview modules')
    check("const bridge=()=>root.ToolAGrainBridge" in mobile and "function bridge(){try{return root.ToolAGrainBridge" in renderer, 'external Grain Studio modules consume the explicit bridge instead of unreachable closure globals')
    for asset in ('toolA_grain_studio_math.js','toolA_grain_studio_renderer.js','toolA_grain_studio.css'):
        check(f'"{asset}"' in server, f'FIX660 public static allowlist serves {asset}')
    check('toolA_grain_mobile_scale.css?v=660r8k' in html and 'toolA_grain_studio_renderer.js?v=660r8k' in html and 'toolA_grain_studio_math.js?v=660r8k' in html and 'toolA_grain_mobile_scale.js?v=660r8k' in html and 'toolA_grain_studio.css?v=660r8k' in html, 'FIX660R8K grain studio assets and legacy mobile CSS have a fresh cache-buster')
    check('@media (max-width:900px)' in css and 'position:fixed!important' in css and 'translateY(calc(100% - 46px))' in css and 'visibility:hidden!important' in css, 'mobile grain preview defaults to a true handle-only bottom drawer across the 900px breakpoint')
    check('id="fix660DrawerHandle"' in html and 'onOverlayOpen' in mobile and "pointermove" in mobile and 'setDrawer' in mobile and 'forceClosed' in mobile, 'mobile preview drawer has a static handle, drag interaction and defaults closed on every overlay open')
    check("style.setProperty('transform'" in mobile and "'important'" in mobile and 'lastPointerToggleAt' in mobile and "pointerup" in mobile, 'iOS drawer uses an important drag transform and completes a tap on pointerup without relying on suppressed click')
    check("top:var(--fix660-grain-drawer-top,154px)!important" in css and "height:100%!important" in css and "function syncDrawerTop()" in mobile, 'mobile preview starts at the measured header edge and gives the canvas the full drawer body')
    check(".grainPreviewIntro,#grainOverlay .grainPreviewCard .fix649PreviewSummary{display:none!important" in css and "top:7px!important" in css, 'mobile duplicate intro/summary are removed and the collapse handle remains fully inside the open drawer')
    check("function prepareHost(container)" in renderer and "container.style.setProperty('height',h+'px','important')" in renderer and "card.getBoundingClientRect().height" in renderer, 'renderer measures and pins an iOS-safe preview host before canvas sizing')
    check("function renderOpenPreview()" in mobile and "requestAnimationFrame(()=>root.requestAnimationFrame" in mobile and "transitionend" in mobile and "setTimeout(renderOpenPreview,340)" in mobile, 'drawer renders after committed layout and again after its transform transition')
    check('fix660MobileActions' in mobile and "a.textContent='Toepassen'" in mobile, 'mobile grain apply/cancel remain independently reachable while preview is collapsed')
    check('fix660DragHandle' in mobile and 'elementFromPoint' in mobile and 'g.items=visual.reverse()' in mobile, 'mobile drag-to-reorder writes physical top-to-bottom DOM back as semantic bottom-to-top order')
    check('fix660OrderBadge' in mobile and 'fix660PanelMiniShape' in mobile and 'groupHeight' in mobile, 'mobile group tiles show order, true-shape miniatures and real group dimensions')
    check('fix660CompactAvailable' in mobile and 'fix660CompactPlus' in mobile and "plus.textContent='+'" in mobile, 'available panels use compact one-tap rows instead of oversized tiles')
    check('fix660CompactGroup' in mobile and 'fix660CompactStackHint' in mobile and 'fix660DragHandle' in mobile, 'active grain set uses a compact stack card with clear order and drag affordance')
    check('fix660DrawerHandleText' not in html and 'fix660DrawerChevron' in html and 'fix660DrawerChevron' in css, 'closed preview shows only a compact grip/chevron handle without a text tab')

    check("g.items.push(ref)" in mobile, 'new mobile additions append to semantic bottom-to-top production order')
    check("g.items.slice().reverse().forEach" in mobile and "pos=semanticIndex+1" in mobile, 'mobile group list renders the physical stack top-to-bottom while position 1 remains bottom')
    check("const panels=semanticPanels.slice().reverse();" in renderer and "position:semanticIndex+1" in renderer, 'preview projects bottom-to-top semantic order into top-to-bottom canvas coordinates')
    check("model.position" in renderer and "positie 1 onderaan" in renderer, 'preview numbering explicitly keeps position 1 at the bottom of the stack')
    check("FIX660R8K_MULTI_GROUP_SELECTION" in html and "FIX660R8K_MULTI_GROUP_SELECTION" in mobile and "FIX660R8K_MULTI_GROUP_SELECTION" in renderer, 'FIX660R8K multi-group mobile marker is present end-to-end')
    check('.grainPreviewCard:not(.fix649PreviewOpen) #grainPreview{display:none!important' not in legacy_mobile_css, 'retired FIX649 class can no longer hide the active FIX660 canvas')
    check('.grainPreviewCard.fix660PreviewDrawer.fix660DrawerOpen:not(.fix649PreviewOpen) #grainPreview' in css and 'display:block!important' in css, 'open FIX660 drawer explicitly owns a visible canvas even against an older cached FIX649 rule')
    check('100% voorbereid, maar nog niet actief in Tool A' in server and 'matCsvPublishReadyBtn' in server and 'Nu catalogus publiceren' in server, 'Admin clearly distinguishes staged images from the active published Tool A catalog')
    check('function productionReadiness()' in renderer and 'renderedGroups.set' in renderer and 'previewReadiness.ok' in html, 'final submit is blocked until every current grain group has a visibly sized preview render')
    check('candidates.find(x=>(x&&x.items||[]).length)' in renderer and 's.grain.selectedGroupId=g.id' in renderer, 'preview auto-selects an available populated grain group instead of staying empty')
    check('font-size:22px!important' in css and 'height:19px!important' in css and '✓ Exact dezelfde breedte' in html, 'mobile Grain Studio header is compact and removes duplicated long explanation')
    check('g.items.slice().reverse().forEach((idx, visualOrder)' in html and 'const position = semanticIndex + 1' in html, 'base group renderer also presents the physical stack top-to-bottom with position 1 at the bottom')
    check('drawPanelCnc' in renderer and 't.holes' in renderer and 't.holeArcs' in renderer and 'contrastStrokeAt' in renderer, 'grain preview reuses true DXF boring/arc geometry with adaptive CNC contrast')
    check('drawCanvasMaterial' in renderer and 'materialKey:String(e.materialKey' in renderer, 'grain preview renders each panel assigned real material swatch')
    check('computeVerticalGroupFit' in mathjs and 'p.heightMm*scale' in mathjs and 'groupW*scale' in mathjs, 'grain preview uses one uniform real-mm scale for the whole vertical group')
    check('Math.max(d.totalH, 160)' not in renderer and 'Math.max(d.totalH, 160)' not in mobile, 'FIX660 removes artificial equal/minimum panel heights from grain preview')
    check('groupWidthMm' in validation and 'itemWidthMm' in validation and '> 0.001' in validation, 'drop validation enforces exact real-width millimetres')
    check('Math.round(Number(e.widthMm||0)*1000)/1000' in html and 'distinctWidthsMm(widthCheck)' in html, 'final Apply validation checks true widthMm rather than nominal cm width')
    check('Werkelijke breedte' in html and 'mm</option>' in html, 'desktop grain UI also exposes real production width in mm')
    check('const w = Math.round(Number(e.widthMm||0)*1000)/1000;' in html and 'Werkelijke breedte ${Number.isInteger(w)?w:w.toFixed(1)} mm' in html, 'desktop available-panel buckets use exact widthMm')
    check("while(usedIds.has(`G${String(nextNr).padStart(2,'0')}`)) nextNr++;" in html, 'new grain groups always receive a unique id after deletes')
    check("if(grainWidthSel) grainWidthSel.value = 'all';" in html and "widthMm: null, widthCm: null" in html, 'a new grain group starts width-neutral and clears the previous width filter')
    check("lockedW=(active&&(active.items||[]).length)?groupWidth(active):0" in mobile and "ensureSelectedGroup(false)" in mobile, 'mobile width filtering locks only a populated explicitly selected grain group')
    check("__TOOLA_JOB_SUBMIT_BUILD = 'FIX660R8L_SUBMIT_RUNTIME_SCOPE'" in html, 'R8L submit runtime repair marker is present')
    check("__TOOLA_JOB_PERFORMANCE_BUILD = 'FIX660R8M_POLL_IO_QUEUE_STABLE'" in html, 'R8M polling/I-O/queue performance marker is present')
    check('window.__TOOLA_DXF_TEXT_CACHE = window.__TOOLA_DXF_TEXT_CACHE || Object.create(null)' in html and 'window.__TOOLA_DXF_CLASSIFIED_PAIR_CACHE = window.__TOOLA_DXF_CLASSIFIED_PAIR_CACHE || new Map()' in html, 'initial template loading owns shared DXF caches on the cross-scope window bridge')
    check('const _DXF_TEXT_CACHE = window.__TOOLA_DXF_TEXT_CACHE' in html and 'const _DXF_CLASSIFIED_PAIR_CACHE = window.__TOOLA_DXF_CLASSIFIED_PAIR_CACHE' in html and "return await _fetchEmbedDXF(srcName);" in html, 'submit preparation binds local aliases to the same immutable DXF caches')
    check("let __startedJobId = null;\n      try{" in html and html.count('let __startedJobId = null;') == 1, 'submit start state remains visible to both the try body and its error handler')
    check('await new Promise(resolve=>requestAnimationFrame(()=>resolve()))' in html, 'Safari receives a paint frame before DXF preparation continues')
    catch_pos=html.index('} catch(err){', html.index("saveQuoteBtn.addEventListener('click', async"))
    alert_pos=html.index('await showToolAlertHardFallbackAsync', catch_pos)
    hide_pos=html.index('updateMetodProgressBadge({busy:false})', catch_pos)
    check(catch_pos < hide_pos < alert_pos, 'early submit failure hides the progress layer before presenting the real error dialog')
    check("'dxfBlobs': canonical_dxf_blobs" in server and "masterDxfStorageMode'] = 'content_addressed_refs_v1'" in server and "dxf_part_refs.json" in server, 'validated compact DXF transport remains compact until optimizer input')
    check('layoutDimensionLabels' in renderer and 'dimensionLabels.push' in renderer, 'tiny drawer dimensions use a non-overlapping label rail without changing panel scale')
    check('51.195.102.180' not in renderer and '8790' not in renderer and 'sellPrice' not in renderer, 'grain renderer remains isolated from deployment and pricing concerns')

    js=r"""
global.window=globalThis;
require(process.argv[1]);
const m=globalThis.ToolAGrainStudioMath;
const tall=m.computeVerticalGroupFit({containerWidth:390,containerHeight:620,panels:[{ref:'a',widthMm:597,heightMm:1997},{ref:'b',widthMm:597,heightMm:97}],padLeft:54,padRight:86,padTop:64,padBottom:54,gapPx:4});
const wide=m.computeVerticalGroupFit({containerWidth:390,containerHeight:620,panels:[{ref:'a',widthMm:1200,heightMm:200},{ref:'b',widthMm:1200,heightMm:200}],padLeft:54,padRight:86,padTop:64,padBottom:54,gapPx:4});
const bad=m.computeVerticalGroupFit({containerWidth:390,containerHeight:620,panels:[{ref:'a',widthMm:597,heightMm:500},{ref:'b',widthMm:596,heightMm:500}]});
console.log(JSON.stringify({tall,wide,bad,same:m.sameWidthMm(597,597),diff:m.sameWidthMm(597,596)}));
"""
    cp=subprocess.run(['node','-e',js,str(APP/'toolA_grain_studio_math.js')],capture_output=True,text=True,check=True)
    data=json.loads(cp.stdout.strip().splitlines()[-1])
    check(data['tall']['ok'] and data['wide']['ok'] and not data['bad']['ok'], 'group-fit handles tall/wide groups and rejects mixed real widths')
    ratio=data['tall']['placements'][0]['h']/data['tall']['placements'][1]['h']
    check(abs(ratio-(1997/97))<1e-9, 'drawer preview preserves exact relative door/lade height scaling')
    check(data['same'] is True and data['diff'] is False, 'same-width helper accepts 597/597 and rejects 597/596')

    js_preview=r"""
global.window=globalThis;
global.matchMedia=()=>({matches:true});
global.requestAnimationFrame=(fn)=>1;global.cancelAnimationFrame=()=>{};global.devicePixelRatio=3;
const styles={};
const intro={getBoundingClientRect:()=>({height:48}),offsetHeight:48};
const summaryEl={getBoundingClientRect:()=>({height:30}),offsetHeight:30,textContent:''};
const card={getBoundingClientRect:()=>({height:520}),clientHeight:520,querySelector:(s)=>s.includes('grainPreviewIntro')?intro:s.includes('fix649PreviewSummary')?summaryEl:null};
function ctx(){const grad={addColorStop(){}};return {setTransform(){},clearRect(){},createLinearGradient(){return grad},fillRect(){this.fills=(this.fills||0)+1},save(){},restore(){},beginPath(){},roundRect(){},clip(){},strokeRect(){},arc(){},stroke(){},fill(){},moveTo(){},lineTo(){},closePath(){},fillText(){},setLineDash(){},getImageData(){return {data:new Uint8ClampedArray([40,40,40,255])}},translate(){},rotate(){},arcTo(){}};}
const context=ctx();
const canvas={className:'',width:0,height:0,style:{},dataset:{},getContext:()=>context,addEventListener(){},getBoundingClientRect:()=>({left:0,top:0,width:350,height:400})};
const container={clientWidth:350,clientHeight:0,innerHTML:'',children:[],getBoundingClientRect:()=>({width:350,height:parseInt(styles.height)||0}),closest:()=>card,style:{setProperty:(k,v)=>styles[k]=v},dataset:{},appendChild(x){this.children.push(x)}};
global.document={readyState:'complete',getElementById:(id)=>id==='grainPreview'?container:id==='fix649PreviewSummary'?summaryEl:null,createElement:(tag)=>tag==='canvas'?canvas:{className:'',textContent:''}};
global.ResizeObserver=undefined;
global.ToolAMaterialSwatchRenderer={drawCanvasMaterial(ctx,p){ctx.fillRect(p.x,p.y,p.w,p.h)},contrastStrokeAt(){return '#fff'}};
require(process.argv[1]);
global.ToolAGrainBridge={state:()=>global.state,selectedMaterialKey:()=> 'm',getEntry:(ref)=>({ref,label:ref,widthMm:197,baseHeightMm:797,extTop:0,extBot:0,materialKey:'m',raw:{}}),getTemplate:()=>null};
global.state={grain:{groups:[{id:'G01',materialKey:'m',items:['a','b'],widthMm:197}],selectedGroupId:'G01'}};
require(process.argv[2]);
ToolAGrainStudioRenderer.render(container);
console.log(JSON.stringify({styles,children:container.children.length,canvasW:canvas.width,canvasH:canvas.height,rendered:container.dataset.fix660Rendered,summary:summaryEl.textContent,fills:context.fills||0,readiness:ToolAGrainStudioRenderer.productionReadiness()}));
"""
    cp2=subprocess.run(['node','-e',js_preview,str(APP/'toolA_grain_studio_math.js'),str(APP/'toolA_grain_studio_renderer.js')],capture_output=True,text=True,check=True)
    pv=json.loads(cp2.stdout.strip().splitlines()[-1])
    check(pv['styles'].get('height')=='502px' and pv['styles'].get('min-height')=='502px', 'collapsed iOS-style preview host fills the measured mobile drawer without duplicate header rows')
    check(pv['children']==1 and pv['canvasW']==700 and pv['canvasH']==1004 and pv['rendered']=='1' and pv['fills']>=3, 'mobile preview creates and paints a visible DPR-capped edge-to-edge canvas even when initial host height is zero')
    check(pv['readiness']['ok'] and pv['readiness']['required']==1, 'successful visibly sized mobile render satisfies the submission acceptance gate')
    check('G01' in pv['summary'] and '197 mm' in pv['summary'] and '1594 mm' in pv['summary'], 'mobile preview render uses the real selected grain-group geometry')

    js_desktop=js_preview.replace("matches:true", "matches:false").replace("clientHeight:0", "clientHeight:520").replace("height:parseInt(styles.height)||0", "height:520")
    cpd=subprocess.run(['node','-e',js_desktop,str(APP/'toolA_grain_studio_math.js'),str(APP/'toolA_grain_studio_renderer.js')],capture_output=True,text=True,check=True)
    dv=json.loads(cpd.stdout.strip().splitlines()[-1])
    check(dv['children']==1 and dv['canvasW']==700 and dv['canvasH']==1040 and dv['rendered']=='1', 'desktop uses the same real-scale Grain Studio renderer and paints a visible 2D canvas')
    check(dv['readiness']['ok'] and dv['readiness']['required']==1 and 'positie 1 onderaan' not in dv['summary'], 'desktop grain-group rendering satisfies the same production readiness contract')

    js_drawer=r"""
global.window=globalThis;
global.matchMedia=()=>({matches:true,addEventListener(){}});
global.requestAnimationFrame=fn=>{fn();return 1;};
global.setTimeout=fn=>{fn();return 1;};
class Classes{constructor(){this.v=new Set()}add(...xs){xs.forEach(x=>this.v.add(x))}remove(...xs){xs.forEach(x=>this.v.delete(x))}toggle(x,on){if(on)this.v.add(x);else this.v.delete(x)}contains(x){return this.v.has(x)}}
class El{constructor(){this.dataset={};this.classList=new Classes();this.listeners={};this.attrs={};this.children=[];this.style={values:{},priorities:{},setProperty:(k,v,p='')=>{this.style.values[k]=v;this.style.priorities[k]=p},removeProperty:k=>{delete this.style.values[k];delete this.style.priorities[k]}}}addEventListener(t,f){(this.listeners[t]||(this.listeners[t]=[])).push(f)}fire(t,x={}){const e=Object.assign({type:t,button:0,clientY:0,pointerId:1,preventDefault(){this.prevented=true}},x);(this.listeners[t]||[]).forEach(f=>f(e));return e}setAttribute(k,v){this.attrs[k]=v}querySelector(){return null}append(...xs){this.children.push(...xs)}appendChild(x){this.children.push(x)}getBoundingClientRect(){return {height:500}}setPointerCapture(){}releasePointerCapture(){}}
const drawer=new El(),handle=new El(),modal=new El();
global.document={readyState:'complete',getElementById:id=>id==='fix660DrawerHandle'?handle:null,querySelector:s=>s==='#grainOverlay .grainPreviewCard'?drawer:s==='#grainOverlay .modal'?modal:null,createElement:()=>new El()};
require(process.argv[1]);
global.grainState={grain:{groups:[{id:'G01',materialKey:'m',widthMm:597,items:['a','b']},{id:'G02',materialKey:'m',widthMm:null,items:[]}],selectedGroupId:'G02'}};
global.ToolAGrainBridge={state:()=>global.grainState,selectedMaterialKey:()=>'m'};
const selectedEmpty=ToolAGrainStudioMobile.ensureSelectedGroup();
const initiallyClosed=drawer.classList.contains('fix660DrawerClosed');
handle.fire('pointerdown',{clientY:100});handle.fire('pointerup',{clientY:100});
const tapOpened=drawer.classList.contains('fix660DrawerOpen');
handle.fire('click');
const noDoubleToggle=drawer.classList.contains('fix660DrawerOpen');
handle.fire('pointerdown',{clientY:100});handle.fire('pointermove',{clientY:450});
const dragValue=drawer.style.values.transform||'',dragPriority=drawer.style.priorities.transform||'';
handle.fire('pointerup',{clientY:450});
console.log(JSON.stringify({initiallyClosed,tapOpened,noDoubleToggle,dragValue,dragPriority,dragClosed:drawer.classList.contains('fix660DrawerClosed'),build:ToolAGrainStudioMobile.BUILD,selectedEmpty:selectedEmpty&&selectedEmpty.id,stateSelected:global.grainState.grain.selectedGroupId}));
"""
    cp3=subprocess.run(['node','-e',js_drawer,str(APP/'toolA_grain_mobile_scale.js')],capture_output=True,text=True,check=True)
    dr=json.loads(cp3.stdout.strip().splitlines()[-1])
    check(dr['initiallyClosed'] and dr['tapOpened'] and dr['noDoubleToggle'], 'iOS-style pointer tap opens the closed preview exactly once')
    check(dr['dragPriority']=='important' and 'translateY(' in dr['dragValue'] and dr['dragClosed'], 'iOS-style pointer drag visibly follows the finger and closes past the threshold')
    check(dr['build']=='FIX660R8K_MULTI_GROUP_SELECTION', 'mobile drawer runtime exposes the R8K build marker')
    check(dr['selectedEmpty']=='G02' and dr['stateSelected']=='G02', 'a newly selected empty G02 is not silently replaced by populated G01')


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--csv', type=Path, help='Optional real current CSV to validate without copying it into the release.')
    args = parser.parse_args()
    server = load_server()
    test_catalog_parser(args.csv)
    test_taxonomy_rules()
    test_manual_family_override_contract()
    test_library_ui_taxonomy_contract()
    test_backfill_contract()
    test_live_admin_family_endpoint(server)
    test_material_mapping(server)
    test_mixed_vat_quote(server)
    test_summary_parser()
    test_header_only_job_token()
    test_sse_privacy(server)
    test_queue_no_optimizer(server)
    test_submission_idempotency(server)
    test_production_runtime_guard(server)
    test_https_admin_transport(server)
    test_production_source_contract()
    test_submit_clarity_copy_contract()
    test_material_swatch_renderer_contract()
    test_adaptive_cnc_and_mobile_fit_contract()
    test_mobile_polish_and_smart_qty_contract()
    test_viewer_scope_protection()
    test_mobile_material_cart_and_step_stability_contract()
    test_fix660_grain_studio_contract()
    test_installer_smoke_contract()
    print('\nFIX660 REGRESSION: PASS')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
