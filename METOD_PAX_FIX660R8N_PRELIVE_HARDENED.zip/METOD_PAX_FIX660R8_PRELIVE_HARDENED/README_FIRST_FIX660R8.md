# METOD/PAX FIX660R8 — eerst lezen

Build: `FIX660R8_PRELIVE_HARDENED`  
Status: pre-live releasecandidate voor gecontroleerde staging. Dit pakket is geen zelfstandig productie-GO.

## Wat R8 oplost

R8 vervangt de onveilige FIX660R7-baseline door een fail-closed productiepad voor paneelinput, DXF-geometrie, prijsberekening, jobidentiteit, finalisatie, downloads, cataloguspublicatie, deploy en backup/restore. De volledige koppeling met de bevindingen staat in `FIX660R8_REMEDIATION_MATRIX.md`.

Revisie R8N voorkomt dat een laat afgeronde template-loader Stap 2 onverwacht
terugzet naar Stap 1 en voegt op mobiel een uitschuifbaar materialenmandje toe
aan de onderbalk. De drawer hergebruikt exact dezelfde materiaalstate en
verwijderacties als de desktopkolom.

Revisie R8M verwijdert specifiek de wachttijd vóór de eerste zichtbare
optimalisatieprogressie en na 100%: geen procent-voor-procent JavaScriptwachtrij,
geen redundante eindstatusfetch, geen herhaalde volledige hashcontrole tijdens
polling en veel minder afzonderlijke filesystembarrières. De nestingresultaten
zijn met vaste 200/250-panelenfingerprints beschermd. Meerdere klanten worden
begrensd FIFO toegelaten; op de kleine VPS blijft één optimizer tegelijk actief.

## Artifact controleren

Gebruik altijd de meegeleverde externe `.zip.sha256` naast de ZIP. Pak daarna uit in een lege map en controleer de interne manifesthashes:

```bash
sha256sum -c METOD_PAX_FIX660R8_PRELIVE_HARDENED.zip.sha256
unzip -tq METOD_PAX_FIX660R8_PRELIVE_HARDENED.zip
STAGE="$(mktemp -d /tmp/metod_fix660r8_XXXXXX)"
unzip -q METOD_PAX_FIX660R8_PRELIVE_HARDENED.zip -d "$STAGE"
cd "$STAGE/METOD_PAX_FIX660R8_PRELIVE_HARDENED"
sha256sum -c SHA256SUMS.txt
PYTHONDONTWRITEBYTECODE=1 python3 tools/final_preflight.py --release . --verify-checksums
```

De preflight voert echte optimizer-, lifecycle-, backup/restore- en regressieproeven uit. Een checksum- of testfout is een harde stop.

## Gecontroleerde staginginstallatie

De installer accepteert alleen de exacte FIX660R7-baseline of een reeds geverifieerde immutable release. Hij zet verkeer eerst in maintenance, migreert mutable state naar `/var/lib/metod-pax`, publiceert code via een atomische release-symlink en opent Nginx pas na runtimepreflight en healthchecks.

```bash
sudo -E bash INSTALL_FIX660R8_FROM_STAGE.sh
```

Staging is standaard HTTP op alleen `127.0.0.1:8790` en draagt bewust de header `X-METOD-Environment: staging`. Test op afstand via een SSH-tunnel, bijvoorbeeld `ssh -L 8790:127.0.0.1:8790 <server>`, en open lokaal `http://127.0.0.1:8790`. Een remote bind vereist expliciet `STAGING_BIND_ADDRESS` plus een geldig `STAGING_ALLOWED_CIDR`; staging is nooit een publiek liveprofiel.

## Productie

Productie vereist minimaal:

- een publiek DNS-domein en een passend TLS-certificaat/key die nog minstens zeven dagen geldig zijn;
- individuele Admin-accounts met PBKDF2-SHA256 (exact 260.000 iteraties), TOTP en de rol `admin`;
- de actieve CSV-catalogus met hashgebonden business-signoff;
- een versleutelde off-host backupbestemming en een recente echte restoreproef;
- afgetekende externe gates uit `GO_LIVE_GATES_FIX660R8.md`.

Voorbeeld van de vereiste expliciete productie-instellingen:

```bash
export METOD_DEPLOY_MODE=production
export METOD_DOMAIN=configurator.example.nl
export PUBLIC_ORIGIN=https://configurator.example.nl
export TLS_CERT_FILE=/etc/letsencrypt/live/configurator.example.nl/fullchain.pem
export TLS_KEY_FILE=/etc/letsencrypt/live/configurator.example.nl/privkey.pem
export OFFSITE_BACKUP_VERIFIED=1
export OFFSITE_BACKUP_PROVIDER='versleutelde-provider/locatie'
sudo -E bash INSTALL_FIX660R8_FROM_STAGE.sh
```

Ontbrekend bewijs laat de production runtimepreflight falen. Zet flags nooit op `1` zonder het bijbehorende bewijsbestand en een echte operationele controle.

## Backup herstellen

Herstel nooit over live state heen. De restoretool accepteert alleen een nieuwe, nog niet bestaande stagingmap:

```bash
python3 tools/restore_system_backup.py /pad/backup.zip --verify-only
python3 tools/restore_system_backup.py /pad/backup.zip \
  --target /var/lib/metod-pax-restore-test-20260812 \
  --proof /var/lib/metod-pax/system/restore_test_proof.json
```

Controleer de herstelde applicatiestate functioneel voordat een afzonderlijk, gepland herstel naar productie plaatsvindt.

## Rollback

Rollback zet alleen de immutable releasepointer en infrastructuurconfig terug. Externe live state wordt bewust nooit automatisch teruggedraaid. Dat voorkomt verlies van requests die na de switch zijn ontvangen. Zie `TECHNISCHE_OVERDRACHT_FIX660R8.md` voor het incidentpad.

## Nog verplicht vóór publiek live

De bron- en artifactgates zijn niet hetzelfde als een live-acceptatie. Echte iPhone/Safari-acceptatie, onafhankelijke CAM/CNC-validatie en fysieke proefsnede, load/chaostest, TLS-/systemd-/Nginx-inspectie, off-host herstelproef, monitoring/alerts en businesssignoff blijven expliciete productiegates.
