#!/usr/bin/env bash
set -euo pipefail
APP_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$APP_DIR"
if [ ! -f .env ]; then cp .env.example .env; fi
if [ ! -d .venv ]; then
  echo "Missing .venv. Running installer first..."
  ./scripts/install.sh
fi
. .venv/bin/activate
set -a
. .env
set +a
# Convert relative env paths to absolute paths before cd backend.
case "${MEDIA_DIR:-}" in
  /*) export MEDIA_DIR="$MEDIA_DIR" ;;
  "") export MEDIA_DIR="$APP_DIR/storage/media" ;;
  *) export MEDIA_DIR="$APP_DIR/$MEDIA_DIR" ;;
esac
case "${FRONTEND_DIST:-}" in
  /*) export FRONTEND_DIST="$FRONTEND_DIST" ;;
  "") export FRONTEND_DIST="$APP_DIR/frontend/dist" ;;
  *) export FRONTEND_DIST="$APP_DIR/$FRONTEND_DIST" ;;
esac
mkdir -p "$MEDIA_DIR"
echo "Starting Roomarc on ${ROOMARC_HOST:-0.0.0.0}:${ROOMARC_PORT:-8899}"
echo "Frontend dist: $FRONTEND_DIST"
echo "Media dir: $MEDIA_DIR"
cd backend
exec python -m uvicorn app.main:app --host "${ROOMARC_HOST:-0.0.0.0}" --port "${ROOMARC_PORT:-8899}"
