ROOMARC MVP v0.2.0

Wat nieuw is:
- echte iPhone fullscreen UI blijft behouden
- visuele polish op feed/cards/timeline/bottom nav
- echte Create/upload-flow: kies foto vanaf iPhone, kies room, vul phase + caption in, publiceer
- update verschijnt daarna in feed en room timeline
- lokale media-opslag werkt op VPS voor testfase
- persistent data directory voorbereid: standaard ~/roomarc_data voor database + uploads
- Cloudflare R2 blijft de volgende stap voor publieke beta

Installatie via GitHub ZIP:
1. Upload roomarc_mvp_v0_2_0_upload_visual_polish.zip naar je GitHub repo.
2. Stop de huidige Roomarc server met CTRL+C.
3. Run de command uit ChatGPT.

Belangrijk:
- Draai Roomarc los van de Bitcoin Evidence Engine.
- Roomarc draait standaard op poort 8899.
- Test URL: http://SERVER-IP:8899
- Demo-login: demo@roomarc.local / demo123

Data bewaren:
De auto-installer zet database en uploads standaard in:
~/roomarc_data
Daardoor blijven testuploads beter bewaard bij nieuwe Roomarc deploys.

Stoppen:
CTRL+C in Termius.

Health check:
curl http://127.0.0.1:8899/api/health
