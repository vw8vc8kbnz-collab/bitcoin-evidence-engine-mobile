#!/usr/bin/env python3
from __future__ import annotations

"""Deterministic performance contracts for the FIX660R8 job lifecycle.

These checks intentionally assert operation counts and cache invalidation rather
than elapsed wall-clock time.  They exercise orchestration, status verification
and browser progress rendering without changing or mocking the nesting algorithm.
"""

import importlib
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest import mock


RELEASE_ROOT = Path(__file__).resolve().parents[1]
APP_ROOT = RELEASE_ROOT / "app"
TOOL_A = APP_ROOT / "toolA.html"
PUBLIC_ID = "decor_0123456789abcdefabcd"
INTERNAL_CODE = "PERF_MAT_18"
HEADER = (
    "PartId;PanelName;Qty;LengthMm;WidthMm;ThicknessMm;MaterialCode;"
    "GrainGroup;RotationAllowed;H1;H2;W1;W2\n"
)


def _library(public_id: str = PUBLIC_ID, internal_code: str = INTERNAL_CODE) -> dict:
    return {
        "source": "CSV_CATALOG_ONLY",
        "pricingModel": "catalog_sell_price_incl_vat_v2",
        "decorLibrarySchemaVersion": 4,
        "records": [
            {
                "articleNo": internal_code,
                "materialCode": internal_code,
                "publicMaterialId": public_id,
                "productName": "Performance-contractmateriaal",
                "sourceKind": "CATALOG_IMPORT",
                "active": True,
                "published": True,
                "archived": False,
                "catalogMissing": False,
                "catalogExcluded": False,
                "thicknessMm": 18,
                "sheetWid": 2070,
                "sheetLen": 2800,
                "sellPriceInclVatPerSheet": 121.0,
                "priceSource": "CSV_SALE_PRICE_INCL_VAT",
                "hasGrain": True,
                "grainDefaultOn": True,
                "visualFamily": "Hout",
                "visualTags": ["Hout"],
                "colorGroup": "Bruin",
                "searchTags": ["performance"],
            }
        ],
    }


def _extract_balanced_function(source: str, marker: str) -> str:
    """Extract one JavaScript function using a small quote-aware brace scanner."""

    start = source.index(marker)
    opening = source.index("{", start)
    depth = 0
    quote = ""
    escaped = False
    line_comment = False
    block_comment = False
    index = opening
    while index < len(source):
        char = source[index]
        nxt = source[index + 1] if index + 1 < len(source) else ""
        if line_comment:
            if char == "\n":
                line_comment = False
            index += 1
            continue
        if block_comment:
            if char == "*" and nxt == "/":
                block_comment = False
                index += 2
            else:
                index += 1
            continue
        if quote:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == quote:
                quote = ""
            index += 1
            continue
        if char in {"'", '"', "`"}:
            quote = char
            index += 1
            continue
        if char == "/" and nxt == "/":
            line_comment = True
            index += 2
            continue
        if char == "/" and nxt == "*":
            block_comment = True
            index += 2
            continue
        if char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                return source[start : index + 1]
        index += 1
    raise AssertionError(f"Unclosed JavaScript function: {marker}")


class PerformanceContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls._temp = tempfile.TemporaryDirectory(prefix="fix660r8_performance_")
        cls.state_root = Path(cls._temp.name) / "state"
        cls._old_state_env = os.environ.get("METOD_STATE_ROOT")
        os.environ["METOD_STATE_ROOT"] = str(cls.state_root)
        sys.path.insert(0, str(APP_ROOT))
        cls.server = importlib.import_module("server_py")
        cls.server._initialize_external_state()
        cls.server.durable_write_json(cls.server.MATERIAL_LIBRARY_PATH, _library())
        cls.server._invalidate_material_lookup_cache()
        cls.handler = object.__new__(cls.server.Handler)
        cls.dxf_text = (
            APP_ROOT / "embedded_dxfs" / "Deuren METOD" / "Metod deur 60x40.dxf"
        ).read_text(encoding="utf-8", errors="strict")

        payload = {
            "panelsCsv": (
                HEADER
                + f"PANEL_A;Testdeur;1;397;597;18;{PUBLIC_ID};;true;1;0;0;0\n"
            ),
            "dxfParts": {"PANEL_A": cls.dxf_text},
            "jobJson": {
                "customer": {"name": "Performance Test", "email": "perf@example.invalid"},
                "rest_material": {"carry_out": True},
            },
        }
        canonical = cls.handler._canonicalize_public_job_payload(payload)
        cls.master_id = "PERFORMANCE_JOB_001"
        result = cls.server._create_job_from_payload(
            canonical,
            master_job_id=cls.master_id,
            public_access_token="performance-contract-token",
        )
        cls.subjob_id = result["subjobs"][0]["subjobId"]
        cls.master_root = cls.server.resolve_identifier_child(cls.server.JOBS, cls.master_id)
        cls.subjob_root = cls.server.resolve_identifier_child(cls.server.JOBS, cls.subjob_id)
        cls.server._save_job_runtime_state(cls.master_id, "DONE")
        if not cls.server._finalization_complete(cls.master_root, _memo={}):
            raise AssertionError("Performance fixture did not finalize")

    @classmethod
    def tearDownClass(cls) -> None:
        if cls._old_state_env is None:
            os.environ.pop("METOD_STATE_ROOT", None)
        else:
            os.environ["METOD_STATE_ROOT"] = cls._old_state_env
        try:
            sys.path.remove(str(APP_ROOT))
        except ValueError:
            pass
        cls._temp.cleanup()

    def _status_handler(self):
        handler = object.__new__(self.server.Handler)
        handler._require_job_access = lambda *args, **kwargs: True
        handler._send_json = lambda obj, code=200: (obj, code)
        return handler

    def _bulk_canonical_payload(self) -> tuple[dict, str]:
        part_ids = [f"BULK_{index:03d}" for index in range(250)]
        public_payload = {
            "panelsCsv": HEADER + "".join(
                f"{part_id};Bulk {index};1;397;597;18;{PUBLIC_ID};;true;0;0;0;0\n"
                for index, part_id in enumerate(part_ids)
            ),
            "dxfBlobs": {"shared": self.dxf_text},
            "dxfPartRefs": {part_id: "shared" for part_id in part_ids},
            "jobJson": {
                "customer": {"name": "Bulk Performance", "email": "bulk@example.invalid"},
                "rest_material": {"carry_out": True},
            },
        }
        canonical = self.handler._canonicalize_public_job_payload(public_payload)
        self.assertEqual(len(canonical["dxfBlobs"]), 1)
        self.assertEqual(len(canonical["dxfPartRefs"]), 250)
        blob_id = next(iter(canonical["dxfBlobs"]))
        self.assertEqual(blob_id, hashlib.sha256(self.dxf_text.encode("utf-8")).hexdigest())
        return canonical, blob_id

    def test_01_material_snapshot_cold_warm_and_signature_invalidation(self) -> None:
        target = self.server.MATERIAL_LIBRARY_PATH.resolve()
        original_bytes = target.read_bytes()
        original_loader = self.server.strict_json_load
        reads: list[Path] = []

        def counted_load(path):
            resolved = Path(path).resolve()
            if resolved == target:
                reads.append(resolved)
            return original_loader(path)

        replacement_public_id = "decor_abcdef0123456789abcd"
        replacement_internal = "PERF_MAT_REPLACED"
        try:
            self.server._invalidate_material_lookup_cache()
            with mock.patch.object(self.server, "strict_json_load", side_effect=counted_load):
                cold = self.server._material_lookup_snapshot()
                warm = self.server._material_lookup_snapshot()
                self.assertEqual(len(reads), 1, "warm lookup reparsed material_library.json")
                self.assertIs(cold, warm)
                self.assertEqual(cold["publicToInternal"][PUBLIC_ID], INTERNAL_CODE)

                # Deliberately bypass the explicit cache invalidator: the file signature
                # must independently notice an atomic catalog replacement.
                self.server.durable_write_json(
                    self.server.MATERIAL_LIBRARY_PATH,
                    _library(replacement_public_id, replacement_internal),
                )
                replaced = self.server._material_lookup_snapshot()
                self.assertEqual(len(reads), 2)
                self.assertEqual(
                    replaced["publicToInternal"][replacement_public_id],
                    replacement_internal,
                )
                self.assertNotIn(PUBLIC_ID, replaced["publicToInternal"])
        finally:
            self.server.durable_write_bytes(self.server.MATERIAL_LIBRARY_PATH, original_bytes)
            self.server._invalidate_material_lookup_cache()

    def test_02_done_status_uses_links_and_hashes_each_signature_once(self) -> None:
        # A prefix-compatible but unlinked directory must not join this job family.
        decoy = self.server.JOBS / f"{self.master_id}__mat_999"
        (decoy / "output").mkdir(parents=True, exist_ok=True)
        with self.server._ARTIFACT_HASH_CACHE_LOCK:
            self.server._ARTIFACT_HASH_CACHE.clear()

        physical_hashes: list[tuple[int, int, int, int, int] | None] = []
        original_sha = self.server.sha256_file

        def counted_sha(path):
            physical_hashes.append(self.server._path_content_signature(Path(path)))
            return original_sha(path)

        status = self._status_handler()
        with (
            mock.patch.object(self.server, "sha256_file", side_effect=counted_sha),
            mock.patch.object(
                Path,
                "glob",
                side_effect=AssertionError("DONE status must use output/links.json"),
            ),
        ):
            first_body, first_code = status._api_status(self.master_id)
            first_hash_count = len(physical_hashes)
            second_body, second_code = status._api_status(self.master_id)

        self.assertEqual(first_code, 200)
        self.assertEqual(second_code, 200)
        self.assertEqual(first_body["meta"]["status"], "done")
        self.assertEqual(second_body["meta"]["status"], "done")
        self.assertIsNotNone(first_body["quote"])
        self.assertNotIn(f"{self.master_id}__mat_999", json.dumps(first_body))
        self.assertGreater(first_hash_count, 0)
        self.assertEqual(
            first_hash_count,
            len(set(physical_hashes[:first_hash_count])),
            "one DONE response physically hashed one file signature more than once",
        )
        self.assertEqual(
            len(physical_hashes),
            first_hash_count,
            "an unchanged repeated DONE poll physically rehashed sealed artifacts",
        )

    def test_03_same_size_tamper_with_restored_mtime_invalidates_hash_cache(self) -> None:
        status = self._status_handler()
        warm_body, warm_code = status._api_status(self.master_id)
        self.assertEqual(warm_code, 200)
        self.assertEqual(warm_body["meta"]["status"], "done")

        quote_path = self.subjob_root / "output" / "quote.json"
        original = quote_path.read_bytes()
        original_stat = quote_path.stat()
        tampered = bytearray(original)
        marker = original.find(b"EUR")
        if marker >= 0:
            tampered[marker : marker + 3] = b"XUR"
        else:
            index = next(
                i for i, value in enumerate(tampered)
                if value not in b" \t\r\n{}[],:\""
            )
            tampered[index] = ord("X") if tampered[index] != ord("X") else ord("Y")

        try:
            quote_path.write_bytes(bytes(tampered))
            os.utime(
                quote_path,
                ns=(original_stat.st_atime_ns, original_stat.st_mtime_ns),
            )
            changed_stat = quote_path.stat()
            self.assertEqual(changed_stat.st_size, original_stat.st_size)
            self.assertEqual(changed_stat.st_mtime_ns, original_stat.st_mtime_ns)
            self.assertNotEqual(changed_stat.st_ctime_ns, original_stat.st_ctime_ns)

            blocked_body, blocked_code = status._api_status(self.master_id)
            self.assertEqual(blocked_code, 409)
            self.assertIsNone(blocked_body["quote"])
            self.assertEqual(blocked_body["pricingSummary"], {})
        finally:
            quote_path.write_bytes(original)
            os.utime(
                quote_path,
                ns=(original_stat.st_atime_ns, original_stat.st_mtime_ns),
            )

        restored_body, restored_code = status._api_status(self.master_id)
        self.assertEqual(restored_code, 200)
        self.assertEqual(restored_body["meta"]["status"], "done")

    def test_03b_preserved_finalized_job_without_runtime_state_is_verified(self) -> None:
        state_path = self.master_root / "job_state.json"
        original_state = state_path.read_bytes()
        status = self._status_handler()
        try:
            state_path.unlink()
            body, code = status._api_status(self.master_id)
            self.assertEqual(code, 200)
            self.assertEqual(body["meta"]["status"], "done")
            self.assertIsNotNone(body["quote"])
        finally:
            state_path.write_bytes(original_state)

    def test_03c_subjob_token_record_is_independent_for_safe_rotation(self) -> None:
        master_token_path = self.master_root / ".public_access.json"
        subjob_token_path = self.subjob_root / ".public_access.json"
        master_stat = master_token_path.stat()
        subjob_stat = subjob_token_path.stat()
        self.assertNotEqual(
            (master_stat.st_dev, master_stat.st_ino),
            (subjob_stat.st_dev, subjob_stat.st_ino),
            "master/subjob bearer records must not share an inode",
        )
        original_master = self.server._read_job_access_token(self.master_id)
        original_subjob = self.server._read_job_access_token(self.subjob_id)
        try:
            self.server._write_job_access_token(self.master_id, "rotated-master-token")
            self.assertEqual(
                self.server._read_job_access_token(self.master_id),
                "rotated-master-token",
            )
            self.assertEqual(
                self.server._read_job_access_token(self.subjob_id),
                original_subjob,
            )
        finally:
            self.server._write_job_access_token(self.master_id, original_master)

    def test_03d_unsealed_master_quote_cannot_override_verified_subjob_quote(self) -> None:
        status = self._status_handler()
        master_quote = self.master_root / "output" / "quote.json"
        self.assertFalse(master_quote.exists())
        baseline_body, baseline_code = status._api_status(self.master_id)
        self.assertEqual(baseline_code, 200)
        baseline_quote = baseline_body["quote"]
        try:
            master_quote.write_text(
                json.dumps({"currency": "EUR", "totals": {"grandTotal": 999999.0}}),
                encoding="utf-8",
            )
            self.assertTrue(self.server._finalization_complete(self.master_root, _memo={}))
            body, code = status._api_status(self.master_id)
            self.assertEqual(code, 200)
            self.assertEqual(body["meta"]["status"], "done")
            self.assertNotEqual(body["quote"]["totals"]["grandTotal"], 999999.0)
            self.assertEqual(body["quote"], baseline_quote)
        finally:
            master_quote.unlink(missing_ok=True)

    def test_04_poll_job_static_contract_has_no_per_percent_await(self) -> None:
        html = TOOL_A.read_text(encoding="utf-8", errors="strict")
        polling = _extract_balanced_function(html, "async function pollJob(")
        self.assertNotIn("while(shownPct <", polling)
        self.assertNotIn("await animateTo", polling)
        self.assertNotIn("await sleep(done ?", polling)
        render = _extract_balanced_function(polling, "function renderServerProgress(")
        self.assertNotIn("await ", render)

        post_start = html.index("const result = await pollJob(")
        post_end = html.index("if(inclVat != null", post_start)
        post = html[post_start:post_end]
        guard = "if((inclVat == null || !Number.isFinite(Number(inclVat)))){"
        self.assertIn("const directDoneTotal = result?.pricingSummary?.totalInclVat", post)
        self.assertIn(guard, post)
        self.assertEqual(post.count("_hydrateAuthoritativePricingSummary("), 1)
        self.assertGreater(
            post.index("_hydrateAuthoritativePricingSummary("),
            post.index(guard),
            "authoritative pricing was hydrated despite a price in the DONE response",
        )

    @unittest.skipUnless(shutil.which("node"), "Node is unavailable; static poll contract still ran")
    def test_05_poll_job_done_path_has_no_animation_timers(self) -> None:
        javascript = r"""
const fs=require('fs');
const html=fs.readFileSync(process.argv[1],'utf8');
const start=html.indexOf('async function pollJob(');
const end=html.indexOf('// Pricing display',start);
if(start<0||end<0) throw new Error('pollJob not found');
global.window=globalThis; global.state={};
global.buildJobTokenHeaders=()=>({}); global.statusMsg=()=>{};
async function run(responses){
  let fetches=0,timers=0,updates=[];
  global.fetch=async()=>{
    const value=responses[Math.min(fetches,responses.length-1)];
    fetches+=1;
    return {ok:true,json:async()=>value};
  };
  global.setTimeout=(fn,ms)=>{timers+=1;queueMicrotask(fn);return timers;};
  global.updatePriceBar=value=>updates.push(value);
  eval(html.slice(start,end));
  const result=await pollJob('PERF_JOB','TOKEN');
  return {fetches,timers,updates:updates.length,last:updates.at(-1),price:result.pricingSummary.totalInclVat};
}
(async()=>{
  const done={meta:{status:'done',progressPct:100,progressMessage:'Klaar'},pricingSummary:{totalInclVat:123.45}};
  const direct=await run([done]);
  const stepped=await run([{meta:{status:'processing',progressPct:37,progressMessage:'Nesten'}},done]);
  console.log(JSON.stringify({direct,stepped}));
})().catch(error=>{console.error(error);process.exit(1);});
"""
        completed = subprocess.run(
            [shutil.which("node") or "node", "-e", javascript, str(TOOL_A)],
            cwd=str(RELEASE_ROOT),
            capture_output=True,
            text=True,
            check=True,
        )
        result = json.loads(completed.stdout.strip().splitlines()[-1])
        direct = result["direct"]
        stepped = result["stepped"]
        self.assertEqual(direct["fetches"], 1)
        self.assertEqual(direct["timers"], 0)
        self.assertLessEqual(direct["updates"], 3)
        self.assertEqual(direct["last"]["progressPct"], 100)
        self.assertEqual(direct["price"], 123.45)
        self.assertEqual(stepped["fetches"], 2)
        self.assertEqual(stepped["timers"], 1, "processing poll used per-percent timers")
        self.assertLessEqual(stepped["updates"], 4)
        self.assertEqual(stepped["last"]["progressPct"], 100)

    @unittest.skipUnless(shutil.which("node"), "Node is unavailable; static poll contract still ran")
    def test_05b_poll_job_terminal_409_stops_without_retry_timer(self) -> None:
        javascript = r"""
const fs=require('fs');
const html=fs.readFileSync(process.argv[1],'utf8');
const start=html.indexOf('async function pollJob(');
const end=html.indexOf('// Pricing display',start);
if(start<0||end<0) throw new Error('pollJob not found');
global.window=globalThis; global.state={};
global.buildJobTokenHeaders=()=>({}); global.statusMsg=()=>{};
let fetches=0,timers=0,updates=0;
global.fetch=async()=>{
  fetches+=1;
  return {
    ok:false,
    status:409,
    text:async()=>JSON.stringify({meta:{progressMessage:'Integriteitscontrole van de job is mislukt.'},quote:null,pricingSummary:{}})
  };
};
global.setTimeout=(fn,ms)=>{timers+=1;throw new Error(`unexpected retry timer ${ms}`);};
global.updatePriceBar=()=>{updates+=1;};
eval(html.slice(start,end));
(async()=>{
  let rejection=null;
  try{
    await pollJob('PERF_JOB','TOKEN');
  }catch(error){
    rejection={
      message:String(error?.message||error),
      httpStatus:error?.httpStatus,
      terminal:error?.metodTerminalStatus===true
    };
  }
  console.log(JSON.stringify({fetches,timers,updates,rejection}));
})().catch(error=>{console.error(error);process.exit(1);});
"""
        completed = subprocess.run(
            [shutil.which("node") or "node", "-e", javascript, str(TOOL_A)],
            cwd=str(RELEASE_ROOT),
            capture_output=True,
            text=True,
            check=True,
        )
        result = json.loads(completed.stdout.strip().splitlines()[-1])
        self.assertEqual(result["fetches"], 1)
        self.assertEqual(result["timers"], 0)
        self.assertIsNotNone(result["rejection"])
        self.assertEqual(
            result["rejection"]["message"],
            "Integriteitscontrole van de job is mislukt.",
        )
        self.assertEqual(result["rejection"]["httpStatus"], 409)
        self.assertTrue(result["rejection"]["terminal"])

    def test_06_250_shared_dxf_hashes_o1_and_fsyncs_hardlink_batches(self) -> None:
        canonical, blob_id = self._bulk_canonical_payload()
        master_id = "PERFORMANCE_BULK_O1"
        subjob_id = f"{master_id}__mat_001"
        sub_root = self.server.resolve_identifier_child(self.server.JOBS, subjob_id)
        sub_input = (sub_root / "input").resolve()
        sub_blobs = (sub_root / "input" / "dxf_blobs").resolve()
        part_exports = (sub_root / "output" / "DXF_Onderdelen").resolve()

        with self.server._ARTIFACT_HASH_CACHE_LOCK:
            self.server._ARTIFACT_HASH_CACHE.clear()
        hash_signatures: list[tuple[int, int]] = []
        events: list[tuple[str, Path | None, str]] = []
        original_sha = self.server.sha256_file
        original_fsync_directory = self.server.fsync_directory
        original_durable_json = self.server.durable_write_json
        original_popen = self.server.subprocess.Popen

        def counted_sha(path):
            stat_result = Path(path).stat()
            hash_signatures.append((int(stat_result.st_dev), int(stat_result.st_ino)))
            return original_sha(path)

        def recorded_fsync_directory(path):
            resolved = Path(path).resolve()
            events.append(("fsync", resolved, ""))
            return original_fsync_directory(path)

        def recorded_durable_json(path, value, *args, **kwargs):
            target = Path(path).resolve()
            if target.name == "finalization.json":
                events.append(("finalization", target, str((value or {}).get("state") or "")))
            return original_durable_json(path, value, *args, **kwargs)

        def recorded_popen(*args, **kwargs):
            events.append(("popen", None, ""))
            return original_popen(*args, **kwargs)

        with (
            mock.patch.object(self.server, "sha256_file", side_effect=counted_sha),
            mock.patch.object(
                self.server,
                "fsync_directory",
                side_effect=recorded_fsync_directory,
            ),
            mock.patch.object(
                self.server,
                "durable_write_json",
                side_effect=recorded_durable_json,
            ),
            mock.patch.object(
                self.server.subprocess,
                "Popen",
                side_effect=recorded_popen,
            ),
        ):
            result = self.server._create_job_from_payload(
                canonical,
                master_job_id=master_id,
                public_access_token="bulk-o1-token",
            )

        self.assertEqual(result["subjobs"][0]["subjobId"], subjob_id)
        blob_path = sub_root / "input" / "dxf_blobs" / f"{blob_id}.dxf"
        blob_stat = blob_path.stat()
        blob_identity = (int(blob_stat.st_dev), int(blob_stat.st_ino))
        shared_blob_physical_hashes = sum(
            signature == blob_identity for signature in hash_signatures
        )
        self.assertGreater(shared_blob_physical_hashes, 0)
        self.assertLessEqual(
            shared_blob_physical_hashes,
            3,
            "250 logical PartIds caused O(panel-count) physical DXF hashing",
        )

        popen_index = next(index for index, event in enumerate(events) if event[0] == "popen")
        finalization_index = next(
            index
            for index, event in enumerate(events)
            if event[0] == "finalization"
            and event[1] is not None
            and event[1].parent.parent.name == subjob_id
            and event[2] == "COMPLETE"
        )
        fsync_positions = {
            path: min(
                index
                for index, event in enumerate(events)
                if event[0] == "fsync" and event[1] == path
            )
            for path in (sub_input, sub_blobs, part_exports)
        }
        self.assertLess(fsync_positions[sub_input], popen_index)
        self.assertLess(fsync_positions[sub_blobs], popen_index)
        self.assertLess(fsync_positions[part_exports], finalization_index)
        self.assertTrue(self.server._finalization_complete(sub_root, _memo={}))
        print(
            "BULK_O1_MEASUREMENT "
            f"shared_blob_physical_hashes={shared_blob_physical_hashes} "
            f"sub_input_fsyncs={sum(1 for event in events if event[0] == 'fsync' and event[1] == sub_input)} "
            f"sub_blob_dir_fsyncs={sum(1 for event in events if event[0] == 'fsync' and event[1] == sub_blobs)} "
            f"part_export_dir_fsyncs={sum(1 for event in events if event[0] == 'fsync' and event[1] == part_exports)}"
        )

    def test_07_hardlink_batch_fsync_failure_never_reaches_done(self) -> None:
        canonical, _blob_id = self._bulk_canonical_payload()
        master_id = "PERFORMANCE_BATCH_FSYNC_FAIL"
        master_root = self.server.resolve_identifier_child(self.server.JOBS, master_id)
        part_exports = (
            self.server.JOBS
            / f"{master_id}__mat_001"
            / "output"
            / "DXF_Onderdelen"
        ).resolve()
        original_fsync_directory = self.server.fsync_directory

        def fail_part_export_batch(path):
            if Path(path).resolve() == part_exports:
                raise OSError("injected hardlink batch fsync failure")
            return original_fsync_directory(path)

        # Exercise the real asynchronous boundary: only the runner is allowed to
        # publish terminal DONE, so a failed durability barrier must become FAILED.
        (master_root / "input").mkdir(parents=True, exist_ok=True)
        (master_root / "output").mkdir(parents=True, exist_ok=True)
        self.server._save_job_runtime_state(master_id, "ACCEPTED")
        admission_ip = "performance-fsync-test"
        acquired, reason = self.server._try_acquire_public_job_slot(admission_ip)
        self.assertTrue(acquired, f"performance fixture could not reserve optimizer slot: {reason}")
        with mock.patch.object(
            self.server,
            "fsync_directory",
            side_effect=fail_part_export_batch,
        ):
            self.handler._start_async_job_create(
                canonical,
                master_job_id=master_id,
                public_access_token="batch-fsync-failure-token",
                acquired_ip=admission_ip,
            )
            deadline = time.monotonic() + 15.0
            terminal_state = ""
            while time.monotonic() < deadline:
                terminal_state = str(
                    self.server._load_job_runtime_state(master_id).get("state") or ""
                ).upper()
                if terminal_state in {"DONE", "FAILED", "CANCELLED"}:
                    break
                time.sleep(0.02)

        self.assertEqual(terminal_state, "FAILED")
        self.assertNotEqual(terminal_state, "DONE")
        self.assertFalse(self.server._finalization_complete(master_root, _memo={}))


if __name__ == "__main__":
    unittest.main(verbosity=2)
