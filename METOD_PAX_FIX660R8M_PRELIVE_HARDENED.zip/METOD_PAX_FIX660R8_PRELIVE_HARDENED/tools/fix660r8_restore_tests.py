#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))

from restore_system_backup import RestoreError, restore_backup, verify_backup  # noqa: E402


class RestoreTests(unittest.TestCase):
    def setUp(self) -> None:
        self.holder = tempfile.TemporaryDirectory(prefix='fix660r8_restore_')
        self.root = Path(self.holder.name)

    def tearDown(self) -> None:
        self.holder.cleanup()

    def _backup(self, *, wrong_hash: bool = False, extra_name: str | None = None) -> Path:
        state_payload = b'{"records":[]}\n'
        release_payload = b'FIX660R8\n'
        files = {
            'state/material_library.json': {
                'sha256': ('0' * 64 if wrong_hash else hashlib.sha256(state_payload).hexdigest()),
                'size': len(state_payload),
            },
            'release/server_py.py': {
                'sha256': hashlib.sha256(release_payload).hexdigest(),
                'size': len(release_payload),
            },
        }
        manifest = {
            'schemaVersion': 2,
            'createdAt': '2026-08-12T00:00:00Z',
            'files': files,
        }
        target = self.root / ('bad.zip' if wrong_hash or extra_name else 'good.zip')
        with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as archive:
            archive.writestr('state/material_library.json', state_payload)
            archive.writestr('release/server_py.py', release_payload)
            archive.writestr('BACKUP_MANIFEST.json', json.dumps(manifest))
            if extra_name:
                archive.writestr(extra_name, b'evil')
        return target

    def test_verify_and_restore_to_new_directory(self) -> None:
        backup = self._backup()
        verified = verify_backup(backup)
        self.assertEqual(verified['stateFileCount'], 1)
        target = self.root / 'restored-state'
        proof = self.root / 'proof.json'
        result = restore_backup(backup, target, proof_path=proof)
        self.assertTrue(result['ok'])
        self.assertEqual((target / 'material_library.json').read_bytes(), b'{"records":[]}\n')
        self.assertFalse((target / 'server_py.py').exists())
        self.assertEqual(json.loads(proof.read_text())['backupSha256'], verified['backupSha256'])
        with self.assertRaises(RestoreError):
            restore_backup(backup, target)

    def test_hash_tampering_is_rejected_without_target(self) -> None:
        backup = self._backup(wrong_hash=True)
        target = self.root / 'must-not-exist'
        with self.assertRaises(RestoreError):
            restore_backup(backup, target)
        self.assertFalse(target.exists())

    def test_traversal_and_extra_members_are_rejected(self) -> None:
        for name in ('../escape', 'state/../escape', '/absolute'):
            with self.subTest(name=name):
                backup = self._backup(extra_name=name)
                with self.assertRaises(RestoreError):
                    verify_backup(backup)


if __name__ == '__main__':
    unittest.main(verbosity=2)
