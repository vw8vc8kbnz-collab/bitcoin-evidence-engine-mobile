#!/usr/bin/env python3
from __future__ import annotations

"""Start the real server and prove its public HTTP control plane responds.

Import- and handler-unit tests do not execute ``Handler.do_GET`` through
``http.server``.  This process-level smoke test exists specifically to catch
startup/dispatch failures such as class name-mangling of module constants.
"""

import ast
import csv
import hashlib
import io
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import ProxyHandler, Request, build_opener


RELEASE_ROOT = Path(__file__).resolve().parents[1]
SERVER = RELEASE_ROOT / "app/server_py.py"
EXPECTED_BUILD = "FIX660R8_PRELIVE_HARDENED"
TEST_PUBLIC_ID = "decor_0123456789abcdefabcd"
TEST_PASSWORD = "http-smoke-safe-password"
TEST_IMAGE_URL = "https://adzaagt.nl/11922-large_default/decolegno-b003-decobasic-fsc-2800-2070-18.jpg"


def minimal_jpeg(width: int = 2, height: int = 2) -> bytes:
    return (
        b"\xff\xd8\xff\xc0\x00\x11\x08"
        + int(height).to_bytes(2, "big")
        + int(width).to_bytes(2, "big")
        + b"\x03\x01\x11\x00\x02\x11\x00\x03\x11\x00\xff\xd9"
    )


def seed_catalog_and_credentials(state_root: Path, credentials_path: Path) -> bytes:
    state_root.mkdir(parents=True, exist_ok=True)
    image = minimal_jpeg()
    image_sha = hashlib.sha256(image).hexdigest()
    image_folder = state_root / "decor_media" / TEST_PUBLIC_ID
    image_folder.mkdir(parents=True, exist_ok=True)
    (image_folder / "catalog.img").write_bytes(image)
    (image_folder / "catalog.meta.json").write_text(
        json.dumps(
            {
                "mime": "image/jpeg",
                "sha256": image_sha,
                "bytes": len(image),
                "width": 2,
                "height": 2,
                "variantGenerator": "raw-fallback",
                "variants": {},
            }
        ),
        encoding="utf-8",
    )
    source_hash = hashlib.sha256(TEST_IMAGE_URL.encode("utf-8")).hexdigest()
    library = {
        "source": "CSV_CATALOG_ONLY",
        "pricingModel": "catalog_sell_price_incl_vat_v2",
        "decorLibrarySchemaVersion": 4,
        "records": [
            {
                "articleNo": "HTTP-SMOKE-001",
                "materialCode": "HTTP-SMOKE-001",
                "publicMaterialId": TEST_PUBLIC_ID,
                "productName": "DecoLegno B003 DECObasic FSC",
                "publicName": "DecoLegno B003 DECObasic FSC",
                "brand": "DecoLegno",
                "sourceKind": "CATALOG_IMPORT",
                "active": True,
                "published": True,
                "archived": False,
                "catalogMissing": False,
                "catalogExcluded": False,
                "thicknessMm": 18,
                "sheetWid": 2070,
                "sheetLen": 2800,
                "sellPriceInclVatPerSheet": 140.24,
                "primaryVisualFamily": "Uni",
                "visualFamily": "Uni",
                "visualTags": ["Uni"],
                "substrateType": "SPAANPLAAT",
                "substrateLabel": "Spaanplaat",
                "colorGroup": "Wit",
                "searchTags": ["uni", "wit"],
                "imageSourceUrls": [TEST_IMAGE_URL],
                "imageSourceUrl": TEST_IMAGE_URL,
                "catalogImageSourceHash": source_hash,
            }
        ],
    }
    library_path = state_root / "material_library.json"
    library_path.write_text(json.dumps(library), encoding="utf-8")

    # This deliberately stale derived cache has a matching source mtime. R8F must
    # reject it by schema/build and regenerate image URLs from verified media.
    system = state_root / "system"
    system.mkdir(parents=True, exist_ok=True)
    stale_body = b'{"ok":true,"records":[],"staleR8E":true}'
    (system / "public_material_catalog_v1.json").write_bytes(stale_body)
    (system / "public_material_catalog_v1.meta.json").write_text(
        json.dumps(
            {
                "schemaVersion": 1,
                "sourceMtimeNs": library_path.stat().st_mtime_ns,
                "etag": '"stale-r8e"',
                "count": 0,
                "build": "FIX656",
            }
        ),
        encoding="utf-8",
    )
    # Avoid racing this focused HTTP test with the independent automatic-backup
    # thread that intentionally drains mutations during its first snapshot.
    (system / "last_auto_backup.json").write_text(
        json.dumps({"ts": "2099-01-01T00:00:00", "file": "http-smoke-fixture.zip"}),
        encoding="utf-8",
    )

    salt = "0123456789abcdef0123456789abcdef"
    digest = hashlib.pbkdf2_hmac("sha256", TEST_PASSWORD.encode(), salt.encode(), 260_000).hex()
    credentials_path.write_text(
        json.dumps(
            {
                "schemaVersion": 2,
                "users": [
                    {
                        "username": "admin",
                        "password_hash": f"pbkdf2_sha256$260000${salt}${digest}",
                        "totp_secret": "",
                        "roles": ["admin"],
                        "active": True,
                    }
                ],
            }
        ),
        encoding="utf-8",
    )
    credentials_path.chmod(0o600)
    return image


def preview_csv_text() -> str:
    output = io.StringIO(newline="")
    writer = csv.writer(output, lineterminator="\n")
    writer.writerow(
        [
            "Product Reference Code",
            "Product Image Urls",
            "Product Name",
            "Feature Max. dikte (mm)",
            "Feature Max. lengte (mm)",
            "Feature Max. breedte (mm)",
            "Prijs per plaat inclusief BTW",
        ]
    )
    writer.writerow(
        [
            "HTTP-SMOKE-001",
            TEST_IMAGE_URL,
            "DecoLegno B003 DECObasic FSC",
            "18",
            "2800",
            "2070",
            "140,24",
        ]
    )
    return output.getvalue()


def reserve_loopback_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
        probe.bind(("127.0.0.1", 0))
        return int(probe.getsockname()[1])


class RealHTTPProcessTests(unittest.TestCase):
    def test_01_class_methods_have_no_mangling_prone_global_names(self) -> None:
        tree = ast.parse(SERVER.read_text(encoding="utf-8", errors="strict"), filename=str(SERVER))
        violations: list[str] = []
        for class_node in (node for node in ast.walk(tree) if isinstance(node, ast.ClassDef)):
            for node in ast.walk(class_node):
                if (
                    isinstance(node, ast.Name)
                    and node.id.startswith("__")
                    and not node.id.endswith("__")
                ):
                    violations.append(f"{class_node.name}:{node.lineno}:{node.id}")
        self.assertEqual(violations, [], f"class name-mangling hazard: {violations}")

    def test_02_real_server_answers_liveness_readiness_and_tool_a(self) -> None:
        opener = build_opener(ProxyHandler({}))
        port = reserve_loopback_port()
        with tempfile.TemporaryDirectory(prefix="fix660r8_http_smoke_") as temp_dir:
            temp_root = Path(temp_dir)
            state_root = temp_root / "state"
            credentials_path = temp_root / "admin_credentials.live.json"
            expected_image = seed_catalog_and_credentials(state_root, credentials_path)
            log_path = temp_root / "server.log"
            env = dict(os.environ)
            env.update(
                {
                    "PYTHONDONTWRITEBYTECODE": "1",
                    "PYTHONUNBUFFERED": "1",
                    "METOD_STATE_ROOT": str(state_root),
                    "METOD_HOST": "127.0.0.1",
                    "METOD_PORT": str(port),
                    "APP_ENV": "staging",
                    "PRODUCTION_HARDENING": "0",
                    "ADMIN_CREDENTIALS_FILE": str(credentials_path),
                    "HTTP_MAX_CONCURRENT": "64",
                }
            )
            with log_path.open("wb") as log_handle:
                process = subprocess.Popen(
                    [sys.executable, "-B", str(SERVER)],
                    cwd=str(RELEASE_ROOT / "app"),
                    env=env,
                    stdin=subprocess.DEVNULL,
                    stdout=log_handle,
                    stderr=subprocess.STDOUT,
                )
                try:
                    live_status = None
                    live_body = b""
                    deadline = time.monotonic() + 30
                    last_error: Exception | None = None
                    while time.monotonic() < deadline:
                        if process.poll() is not None:
                            break
                        try:
                            with opener.open(f"http://127.0.0.1:{port}/health/live", timeout=2) as response:
                                live_status = response.status
                                live_body = response.read()
                            break
                        except HTTPError as exc:
                            last_error = RuntimeError(f"HTTP {exc.code}")
                            exc.close()
                            time.sleep(0.1)
                        except (URLError, TimeoutError, ConnectionError) as exc:
                            last_error = exc
                            time.sleep(0.1)

                    log_handle.flush()
                    if live_status is None:
                        log_text = log_path.read_text(encoding="utf-8", errors="replace")[-12000:]
                        self.fail(
                            f"server gaf geen livenessantwoord; exit={process.poll()}; "
                            f"laatste fout={last_error!r}\n{log_text}"
                        )

                    self.assertEqual(live_status, 200)
                    live = json.loads(live_body)
                    self.assertEqual(live, {"ok": True, "build": EXPECTED_BUILD})

                    try:
                        with opener.open(f"http://127.0.0.1:{port}/health/ready", timeout=5) as response:
                            ready_status = response.status
                            ready_body = response.read()
                    except HTTPError as exc:
                        ready_status = exc.code
                        try:
                            ready_body = exc.read()
                        finally:
                            exc.close()
                    self.assertIn(ready_status, {200, 503})
                    ready = json.loads(ready_body)
                    self.assertEqual(ready.get("build"), EXPECTED_BUILD)
                    self.assertIsInstance(ready.get("checks"), dict)

                    with opener.open(f"http://127.0.0.1:{port}/", timeout=10) as response:
                        tool_status = response.status
                        tool_body = response.read()
                    self.assertEqual(tool_status, 200)
                    self.assertIn(b"FIX660_GRAIN_STUDIO", tool_body)

                    with opener.open(f"http://127.0.0.1:{port}/api/materials/library", timeout=10) as response:
                        catalog_status = response.status
                        catalog_body = response.read()
                    self.assertEqual(catalog_status, 200)
                    catalog = json.loads(catalog_body)
                    self.assertNotIn("staleR8E", catalog)
                    self.assertEqual(catalog.get("count"), 1)
                    material = catalog["records"][0]
                    self.assertTrue(material.get("imageAvailable"))
                    image_url = str(material.get("imageThumbUrl") or "")
                    self.assertIn(f"/api/materials/image/{TEST_PUBLIC_ID}/catalog", image_url)

                    with opener.open(f"http://127.0.0.1:{port}{image_url}", timeout=10) as response:
                        image_status = response.status
                        image_type = response.headers.get_content_type()
                        image_body = response.read()
                    self.assertEqual(image_status, 200)
                    self.assertEqual(image_type, "image/jpeg")
                    self.assertEqual(image_body, expected_image)

                    login_request = Request(
                        f"http://127.0.0.1:{port}/api/admin/login",
                        data=json.dumps({"username": "admin", "password": TEST_PASSWORD, "otp": ""}).encode(),
                        headers={"Content-Type": "application/json", "Origin": f"http://127.0.0.1:{port}"},
                        method="POST",
                    )
                    try:
                        with opener.open(login_request, timeout=10) as response:
                            login_status = response.status
                            login_cookie = str(response.headers.get("Set-Cookie") or "").split(";", 1)[0]
                            login_body = json.loads(response.read())
                    except HTTPError as exc:
                        try:
                            login_error_body = exc.read().decode("utf-8", errors="replace")
                        finally:
                            exc.close()
                        self.fail(f"adminlogin gaf HTTP {exc.code}: {login_error_body}")
                    self.assertEqual(login_status, 200)
                    self.assertTrue(login_body.get("ok"))
                    self.assertTrue(login_cookie.startswith("adzaagt_admin_session="))

                    preview_request = Request(
                        f"http://127.0.0.1:{port}/api/admin/materials/catalog_preview",
                        data=json.dumps({"csvText": preview_csv_text()}).encode(),
                        headers={
                            "Content-Type": "application/json",
                            "Cookie": login_cookie,
                            "Origin": f"http://127.0.0.1:{port}",
                            "X-Requested-With": "fetch",
                        },
                        method="POST",
                    )
                    with opener.open(preview_request, timeout=20) as response:
                        preview_status = response.status
                        preview = json.loads(response.read())
                    self.assertEqual(preview_status, 200)
                    self.assertTrue(preview.get("ok"))
                    self.assertEqual(preview.get("summary", {}).get("eligible"), 1)
                    self.assertRegex(str(preview.get("reviewSha256") or ""), r"^[a-f0-9]{64}$")
                finally:
                    process.terminate()
                    try:
                        process.wait(timeout=10)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait(timeout=10)


if __name__ == "__main__":
    unittest.main(verbosity=2)
