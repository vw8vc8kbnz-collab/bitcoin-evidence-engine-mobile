#!/usr/bin/env python3
from __future__ import annotations

"""Focused concurrency-contract tests for the bounded public optimizer FIFO."""

import importlib
import hashlib
import os
import sys
import tempfile
import threading
import time
import unittest
from contextlib import ExitStack
from pathlib import Path
from unittest import mock


RELEASE_ROOT = Path(__file__).resolve().parents[1]
APP_ROOT = RELEASE_ROOT / "app"
PUBLIC_ID = "decor_0123456789abcdefabcd"
INTERNAL_CODE = "QUEUE_DURABILITY_MAT_18"
PANELS_HEADER = (
    "PartId;PanelName;Qty;LengthMm;WidthMm;ThicknessMm;MaterialCode;"
    "GrainGroup;RotationAllowed;H1;H2;W1;W2\n"
)


class PublicOptimizerQueueTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls._temp = tempfile.TemporaryDirectory(prefix="fix660r8_public_queue_")
        cls._old_state_env = os.environ.get("METOD_STATE_ROOT")
        os.environ["METOD_STATE_ROOT"] = str(Path(cls._temp.name) / "state")
        sys.path.insert(0, str(APP_ROOT))
        cls.server = importlib.import_module("server_py")
        cls.server._initialize_external_state()
        cls.dxf_text = (
            APP_ROOT / "embedded_dxfs" / "Deuren METOD" / "Metod deur 60x40.dxf"
        ).read_text(encoding="utf-8", errors="strict")
        cls.server.durable_write_json(cls.server.MATERIAL_LIBRARY_PATH, {
            "source": "CSV_CATALOG_ONLY",
            "records": [{
                "articleNo": INTERNAL_CODE,
                "publicMaterialId": PUBLIC_ID,
                "productName": "Queue durability testmateriaal",
                "sourceKind": "CATALOG_IMPORT",
                "active": True,
                "published": True,
                "archived": False,
                "catalogMissing": False,
                "catalogExcluded": False,
                "thicknessMm": 18,
                "sheetWid": 2070,
                "sheetLen": 2800,
                "sellPriceInclVatPerSheet": 121.00,
            }],
        })
        cls.server._invalidate_material_lookup_cache()

    @classmethod
    def tearDownClass(cls) -> None:
        if cls._old_state_env is None:
            os.environ.pop("METOD_STATE_ROOT", None)
        else:
            os.environ["METOD_STATE_ROOT"] = cls._old_state_env
        try:
            sys.path.remove(str(APP_ROOT))
        except ValueError:
            pass
        cls._temp.cleanup()

    def setUp(self) -> None:
        self._old_limits = {
            name: os.environ.get(name)
            for name in (
                "PUBLIC_JOB_MAX_CONCURRENT",
                "PUBLIC_JOB_MAX_QUEUED",
                "PUBLIC_JOB_MAX_CONCURRENT_PER_IP",
            )
        }
        os.environ.update({
            "PUBLIC_JOB_MAX_CONCURRENT": "1",
            "PUBLIC_JOB_MAX_QUEUED": "8",
            "PUBLIC_JOB_MAX_CONCURRENT_PER_IP": "2",
        })
        with self.server._PUBLIC_JOB_CREATE_LOCK:
            self.assertEqual(self.server._PUBLIC_JOB_CREATE_TOTAL, 0)
            self.assertEqual(self.server._PUBLIC_JOB_ACTIVE_TOTAL, 0)
            self.assertEqual(self.server._PUBLIC_JOB_RESERVED_TOTAL, 0)
            self.assertEqual(len(self.server._PUBLIC_JOB_QUEUE), 0)
            self.server._PUBLIC_JOB_CREATE_BY_IP.clear()
            self.server._PUBLIC_JOB_RESERVED_BY_IP.clear()
        with self.server._job_lock:
            self.server._job_meta.clear()

    def tearDown(self) -> None:
        deadline = time.monotonic() + 5.0
        while time.monotonic() < deadline:
            with self.server._PUBLIC_JOB_CREATE_LOCK:
                if self.server._PUBLIC_JOB_CREATE_TOTAL == 0:
                    break
            time.sleep(0.01)
        for name, value in self._old_limits.items():
            if value is None:
                os.environ.pop(name, None)
            else:
                os.environ[name] = value

    def _reserve_and_commit(self, ip: str, job_id: str, runner) -> dict:
        accepted, reason = self.server._try_acquire_public_job_slot(ip)
        self.assertTrue(accepted, reason)
        with self.server._job_lock:
            self.server._job_meta[job_id] = {
                "status": "processing",
                "phase": "accepted",
                "progressPct": 1,
            }
        return self.server._commit_public_job_slot(ip, job_id, runner)

    def _wait_queue_idle(self) -> None:
        deadline = time.monotonic() + 5.0
        while time.monotonic() < deadline:
            with self.server._PUBLIC_JOB_CREATE_LOCK:
                if self.server._PUBLIC_JOB_CREATE_TOTAL == 0:
                    return
            time.sleep(0.01)
        self.fail("public optimizer queue did not become idle")

    def _canonical_payload(self) -> dict:
        digest = hashlib.sha256(self.dxf_text.encode("utf-8")).hexdigest()
        return {
            "payloadSchema": "FIX660R8_SERVER_CANONICAL_V1",
            "panelsCsv": (
                PANELS_HEADER
                + f"PANEL_A;Testdeur;1;397;597;18;{INTERNAL_CODE};;true;1;0;0;0\n"
            ),
            "dxfBlobs": {digest: self.dxf_text},
            "dxfPartRefs": {"PANEL_A": digest},
            "jobJson": {},
        }

    def _api_create_harness(self, fsync_impl, events: list[str] | None = None):
        events = events if events is not None else []
        handler = object.__new__(self.server.Handler)
        handler.headers = {"Content-Length": "2"}
        handler._canonicalize_public_job_payload = lambda payload: self._canonical_payload()
        handler._estimate_job_complexity = lambda payload: {}
        handler._write_api_jobs_crashlog = lambda *args, **kwargs: None

        def fake_start(payload, job_id, access_token, ip):
            events.append("schedule")
            return self.server._commit_public_job_slot(ip, job_id, lambda: None)

        def fake_send(body, code=200):
            events.append(f"send:{code}")
            return body, code

        handler._start_async_job_create = fake_start
        handler._send_json = fake_send
        patches = (
            mock.patch.object(self.server, "_client_ip", return_value="198.51.100.77"),
            mock.patch.object(self.server, "_rate_limit_allow", return_value=True),
            mock.patch.object(self.server, "_read_json_body_limited", return_value={"intent": True}),
            mock.patch.object(self.server, "_load_pricing_config", return_value={"pricing": {}}),
            mock.patch.object(self.server, "_ensure_pricing_materials", return_value={}),
            mock.patch.object(self.server, "_estimate_payload_area_lower_bound", return_value={"maxAreaLowerBound": 1}),
            mock.patch.object(self.server, "_estimate_preflight_job_family_bytes", return_value={"projectedTotalBytes": 1024, "totalQty": 1, "dxfCount": 1}),
            mock.patch.object(self.server, "_enforce_job_total_qty_limit", return_value=1),
            mock.patch.object(self.server, "_enforce_state_capacity", return_value=None),
            mock.patch.object(self.server, "fsync_directory", side_effect=fsync_impl),
        )
        return handler, events, patches

    def test_crash_durability_master_jobs_fsync_precedes_scheduling_and_202(self) -> None:
        original_fsync = self.server.fsync_directory
        events: list[str] = []

        def tracked_fsync(path):
            if Path(path).resolve() == self.server.JOBS.resolve():
                events.append("jobs-fsync")
            return original_fsync(path)

        handler, _harness_events, patches = self._api_create_harness(tracked_fsync, events)
        with ExitStack() as stack:
            for patcher in patches:
                stack.enter_context(patcher)
            body, code = handler._api_create_job()
        self.assertEqual(code, 202)
        self.assertTrue(body.get("jobId"))
        self.assertLess(events.index("jobs-fsync"), events.index("schedule"))
        self.assertLess(events.index("schedule"), events.index("send:202"))
        self._wait_queue_idle()
        self.server._save_job_runtime_state(body["jobId"], "FAILED", reason="test-cleanup")

    def test_crash_durability_master_jobs_fsync_failure_returns_no_202_and_leaks_no_slot(self) -> None:
        def failing_fsync(path):
            if Path(path).resolve() == self.server.JOBS.resolve():
                raise OSError("injected JOBS directory fsync failure")
            return None

        handler, events, patches = self._api_create_harness(failing_fsync)
        with ExitStack() as stack:
            for patcher in patches:
                stack.enter_context(patcher)
            _body, code = handler._api_create_job()
        self.assertNotEqual(code, 202)
        self.assertNotIn("schedule", events)
        with self.server._PUBLIC_JOB_CREATE_LOCK:
            self.assertEqual(self.server._PUBLIC_JOB_CREATE_TOTAL, 0)
            self.assertEqual(self.server._PUBLIC_JOB_ACTIVE_TOTAL, 0)
            self.assertEqual(self.server._PUBLIC_JOB_RESERVED_TOTAL, 0)
            self.assertEqual(len(self.server._PUBLIC_JOB_QUEUE), 0)
            self.assertEqual(self.server._PUBLIC_JOB_CREATE_BY_IP, {})
            self.assertEqual(self.server._PUBLIC_JOB_RESERVED_BY_IP, {})

    def test_crash_durability_subjob_jobs_fsync_precedes_popen(self) -> None:
        job_id = "QUEUE_DURABILITY_ORDER"
        events: list[str] = []
        original_fsync = self.server.fsync_directory

        def tracked_fsync(path):
            if Path(path).resolve() == self.server.JOBS.resolve():
                events.append("jobs-fsync")
            return original_fsync(path)

        class FailedProcess:
            def poll(self):
                return 1

        def fake_popen(*args, **kwargs):
            events.append("popen")
            return FailedProcess()

        with (
            mock.patch.object(self.server, "fsync_directory", side_effect=tracked_fsync),
            mock.patch.object(self.server.subprocess, "Popen", side_effect=fake_popen),
        ):
            with self.assertRaisesRegex(RuntimeError, "Optimizer failed"):
                self.server._create_job_from_payload(
                    self._canonical_payload(), master_job_id=job_id
                )
        self.assertIn("jobs-fsync", events)
        self.assertIn("popen", events)
        self.assertLess(events.index("jobs-fsync"), events.index("popen"))

    def test_crash_durability_subjob_fsync_failure_never_reaches_done(self) -> None:
        job_id = "QUEUE_DURABILITY_FAIL"
        ip = "198.51.100.88"
        job_root = self.server.resolve_identifier_child(self.server.JOBS, job_id)
        (job_root / "input").mkdir(parents=True, exist_ok=True)
        (job_root / "output").mkdir(parents=True, exist_ok=True)
        self.server._save_job_runtime_state(job_id, "ACCEPTED")
        with self.server._job_lock:
            self.server._job_meta[job_id] = {
                "status": "processing", "phase": "accepted", "progressPct": 1,
            }
        accepted, reason = self.server._try_acquire_public_job_slot(ip)
        self.assertTrue(accepted, reason)

        def failing_subjob_fsync(path):
            if Path(path).resolve() == self.server.JOBS.resolve():
                raise OSError("injected subjob JOBS fsync failure")
            return None

        with (
            mock.patch.object(self.server, "fsync_directory", side_effect=failing_subjob_fsync),
            mock.patch.object(self.server.subprocess, "Popen") as popen,
        ):
            scheduling = self.server.Handler._start_async_job_create(
                object.__new__(self.server.Handler),
                self._canonical_payload(),
                job_id,
                "",
                ip,
            )
            self.assertEqual(scheduling["status"], "processing")
            self._wait_queue_idle()

        popen.assert_not_called()
        state = self.server._load_job_runtime_state(job_id)
        self.assertEqual(state.get("state"), "FAILED")
        self.assertNotEqual(state.get("state"), "DONE")
        with self.server._job_lock:
            self.assertEqual(self.server._job_meta[job_id].get("status"), "error")

    def test_fifo_bounds_per_ip_and_queue_cancellation(self) -> None:
        first_release = threading.Event()
        second_release = threading.Event()
        second_started = threading.Event()
        started: list[str] = []
        started_lock = threading.Lock()

        def blocking_runner(job_id: str, release: threading.Event, started_event=None):
            def _run() -> None:
                with started_lock:
                    started.append(job_id)
                if started_event is not None:
                    started_event.set()
                self.assertTrue(release.wait(5.0))
            return _run

        first = self._reserve_and_commit(
            "198.51.100.1",
            "QUEUE_TEST_A",
            blocking_runner("QUEUE_TEST_A", first_release),
        )
        self.assertEqual(first, {"status": "processing", "queuePosition": 0})

        queued_root = self.server.resolve_identifier_child(self.server.JOBS, "QUEUE_TEST_B")
        queued_root.mkdir(parents=True, exist_ok=True)
        self.server._save_job_runtime_state("QUEUE_TEST_B", "ACCEPTED")
        second = self._reserve_and_commit(
            "198.51.100.1",
            "QUEUE_TEST_B",
            blocking_runner("QUEUE_TEST_B", second_release, second_started),
        )
        self.assertEqual(second, {"status": "queued", "queuePosition": 1})
        self.assertEqual(
            self.server._load_job_runtime_state("QUEUE_TEST_B").get("state"),
            "ACCEPTED",
        )
        with self.server._job_lock:
            self.assertEqual(self.server._job_meta["QUEUE_TEST_B"]["phase"], "queued")

        handler = object.__new__(self.server.Handler)
        handler._require_job_access = lambda *args, **kwargs: True
        handler._send_json = lambda body, code=200: (body, code)
        status_body, status_code = handler._api_status("QUEUE_TEST_B")
        self.assertEqual(status_code, 200)
        self.assertEqual(status_body["meta"]["status"], "queued")
        self.assertEqual(status_body["meta"]["queuePosition"], 1)

        accepted, reason = self.server._try_acquire_public_job_slot("198.51.100.1")
        self.assertFalse(accepted)
        self.assertEqual(reason, "ip")

        queued_ids = []
        for index in range(7):
            job_id = f"QUEUE_TEST_C{index}"
            queued_ids.append(job_id)
            result = self._reserve_and_commit(
                f"198.51.100.{index + 10}", job_id, lambda: None
            )
            self.assertEqual(result["status"], "queued")
            self.assertEqual(result["queuePosition"], index + 2)

        accepted, reason = self.server._try_acquire_public_job_slot("203.0.113.200")
        self.assertFalse(accepted)
        self.assertEqual(reason, "queue_full")

        first_release.set()
        self.assertTrue(second_started.wait(5.0))
        with started_lock:
            self.assertEqual(started[:2], ["QUEUE_TEST_A", "QUEUE_TEST_B"])
        with self.server._job_lock:
            self.assertEqual(self.server._job_meta["QUEUE_TEST_B"]["phase"], "worker_start")

        self.assertTrue(self.server._cancel_queued_public_job(queued_ids[0]))
        replacement = self._reserve_and_commit("203.0.113.201", "QUEUE_TEST_REPLACEMENT", lambda: None)
        self.assertEqual(replacement, {"status": "queued", "queuePosition": 7})

        second_release.set()

    def test_startup_reconciles_durable_queued_accepted_state(self) -> None:
        job_id = "QUEUE_RESTART_ACCEPTED"
        job_root = self.server.resolve_identifier_child(self.server.JOBS, job_id)
        job_root.mkdir(parents=True, exist_ok=True)
        self.server._save_job_runtime_state(job_id, "ACCEPTED")
        self.assertGreaterEqual(self.server._reconcile_interrupted_jobs_on_startup(), 1)
        state = self.server._load_job_runtime_state(job_id)
        self.assertEqual(state.get("state"), "FAILED")
        self.assertEqual(state.get("reason"), "service-restarted-during-processing")


if __name__ == "__main__":
    unittest.main(verbosity=2)
