#!/usr/bin/env python3
from __future__ import annotations

"""Verify and restore a FIX660R8 state backup into a new staging directory.

The tool never overwrites an existing target and never extracts ZIP paths directly.
Every archive member is allowlisted by the signed-in-manifest hash contract before
any restored state is atomically published.
"""

import argparse
import hashlib
import os
import re
import secrets
import shutil
import stat
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


RELEASE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RELEASE_ROOT / 'app'))

from safety_contracts import (  # noqa: E402
    durable_write_json,
    fsync_directory,
    sha256_file,
    strict_json_loads,
)


HASH_RE = re.compile(r'^[a-f0-9]{64}$')
MANIFEST_NAME = 'BACKUP_MANIFEST.json'
DEFAULT_MAX_FILES = 200_000
DEFAULT_MAX_BYTES = 32 * 1024 * 1024 * 1024


class RestoreError(RuntimeError):
    pass


def _safe_member_name(name: str) -> str:
    raw = str(name or '')
    if not raw or '\\' in raw or '\x00' in raw or raw.startswith('/'):
        raise RestoreError(f'onveilig ZIP-pad: {raw!r}')
    parts = raw.split('/')
    if any(part in {'', '.', '..'} for part in parts):
        raise RestoreError(f'onveilig ZIP-pad: {raw!r}')
    if raw != MANIFEST_NAME and parts[0] not in {'state', 'release'}:
        raise RestoreError(f'onverwacht ZIP-pad: {raw!r}')
    return raw


def _is_zip_symlink(info: zipfile.ZipInfo) -> bool:
    return stat.S_ISLNK((int(info.external_attr) >> 16) & 0xFFFF)


def _sha256_stream(handle, *, expected_size: int, max_bytes: int) -> str:
    digest = hashlib.sha256()
    total = 0
    while True:
        chunk = handle.read(1024 * 1024)
        if not chunk:
            break
        total += len(chunk)
        if total > expected_size or total > max_bytes:
            raise RestoreError('ZIP-lid overschrijdt de gemanifesteerde grootte')
        digest.update(chunk)
    if total != expected_size:
        raise RestoreError('ZIP-lidgrootte wijkt af van manifest')
    return digest.hexdigest()


def verify_backup(
    backup_path: Path,
    *,
    max_files: int = DEFAULT_MAX_FILES,
    max_bytes: int = DEFAULT_MAX_BYTES,
) -> dict[str, Any]:
    backup = Path(backup_path).expanduser().resolve(strict=True)
    if not backup.is_file() or backup.suffix.lower() != '.zip':
        raise RestoreError('backup moet een bestaand ZIP-bestand zijn')
    if backup.stat().st_size <= 0:
        raise RestoreError('backup-ZIP is leeg')
    max_files = max(1, int(max_files))
    max_bytes = max(1, int(max_bytes))

    with zipfile.ZipFile(backup, 'r') as archive:
        infos = archive.infolist()
        if len(infos) > max_files + 1:
            raise RestoreError('backup bevat te veel bestanden')
        names: set[str] = set()
        by_name: dict[str, zipfile.ZipInfo] = {}
        for info in infos:
            name = _safe_member_name(info.filename)
            if name in names:
                raise RestoreError(f'dubbel ZIP-pad: {name}')
            if info.is_dir() or _is_zip_symlink(info):
                raise RestoreError(f'directory/symlink-lid is verboden: {name}')
            if info.file_size < 0 or info.file_size > max_bytes:
                raise RestoreError(f'ongeldige ZIP-lidgrootte: {name}')
            names.add(name)
            by_name[name] = info
        if MANIFEST_NAME not in by_name:
            raise RestoreError('BACKUP_MANIFEST.json ontbreekt')
        if by_name[MANIFEST_NAME].file_size > 64 * 1024 * 1024:
            raise RestoreError('backupmanifest is te groot')
        manifest_raw = archive.read(MANIFEST_NAME)
        manifest = strict_json_loads(manifest_raw)
        files = manifest.get('files') if isinstance(manifest, dict) else None
        if not isinstance(manifest, dict) or int(manifest.get('schemaVersion') or 0) != 2:
            raise RestoreError('niet-ondersteunde backupmanifestversie')
        if not isinstance(files, dict) or not files:
            raise RestoreError('backupmanifest mist files')
        if len(files) > max_files:
            raise RestoreError('backupmanifest bevat te veel bestanden')

        expected_names: set[str] = {MANIFEST_NAME}
        total_bytes = 0
        state_files = 0
        for raw_name, evidence in files.items():
            name = _safe_member_name(raw_name)
            if name == MANIFEST_NAME or not isinstance(evidence, dict):
                raise RestoreError(f'ongeldig manifestitem: {name}')
            try:
                size = int(evidence.get('size'))
            except Exception as exc:
                raise RestoreError(f'ongeldige grootte in manifest: {name}') from exc
            expected_hash = str(evidence.get('sha256') or '').lower()
            if size < 0 or size > max_bytes or not HASH_RE.fullmatch(expected_hash):
                raise RestoreError(f'ongeldig hash/groottecontract: {name}')
            info = by_name.get(name)
            if info is None or info.file_size != size:
                raise RestoreError(f'ZIP/manifest verschilt voor: {name}')
            total_bytes += size
            if total_bytes > max_bytes:
                raise RestoreError('totale backupgrootte overschrijdt de limiet')
            with archive.open(info, 'r') as source:
                actual_hash = _sha256_stream(source, expected_size=size, max_bytes=max_bytes)
            if actual_hash != expected_hash:
                raise RestoreError(f'hash mismatch voor: {name}')
            if name.startswith('state/'):
                state_files += 1
            expected_names.add(name)
        if names != expected_names:
            extra = sorted(names - expected_names)
            missing = sorted(expected_names - names)
            raise RestoreError(f'ZIP bevat extra/ontbrekende leden; extra={extra[:3]}, ontbrekend={missing[:3]}')
        if state_files <= 0:
            raise RestoreError('backup bevat geen herstelbare state-bestanden')

    return {
        'backup': str(backup),
        'backupSha256': sha256_file(backup),
        'manifestSha256': hashlib.sha256(manifest_raw).hexdigest(),
        'manifest': manifest,
        'fileCount': len(files),
        'stateFileCount': state_files,
        'totalBytes': total_bytes,
    }


def _validate_new_target(target_path: Path) -> Path:
    target = Path(target_path).expanduser().absolute()
    forbidden = {Path('/'), Path('/root'), Path('/home'), Path('/var'), Path('/var/lib')}
    if target in forbidden or target.name in {'', '.', '..'}:
        raise RestoreError('restoredoel is te breed')
    if target.exists() or target.is_symlink():
        raise RestoreError('restoredoel moet nog niet bestaan')
    parent = target.parent.resolve(strict=True)
    if not parent.is_dir():
        raise RestoreError('bovenliggende restoremap bestaat niet')
    resolved_candidate = parent / target.name
    if resolved_candidate.parent != parent:
        raise RestoreError('ongeldig restoredoel')
    return resolved_candidate


def restore_backup(
    backup_path: Path,
    target_path: Path,
    *,
    proof_path: Path | None = None,
    max_files: int = DEFAULT_MAX_FILES,
    max_bytes: int = DEFAULT_MAX_BYTES,
) -> dict[str, Any]:
    verified = verify_backup(backup_path, max_files=max_files, max_bytes=max_bytes)
    target = _validate_new_target(target_path)
    staging = target.parent / f'.{target.name}.restore.{os.getpid()}.{secrets.token_hex(6)}'
    if staging.exists() or staging.is_symlink():
        raise RestoreError('tijdelijk restoredoel bestaat onverwacht al')
    staging.mkdir(mode=0o750)
    try:
        files = verified['manifest']['files']
        with zipfile.ZipFile(Path(verified['backup']), 'r') as archive:
            for name, evidence in sorted(files.items()):
                if not str(name).startswith('state/'):
                    continue
                relative_parts = str(name).split('/')[1:]
                destination = staging.joinpath(*relative_parts)
                destination.parent.mkdir(parents=True, exist_ok=True, mode=0o750)
                fd = os.open(str(destination), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o640)
                try:
                    digest = hashlib.sha256()
                    total = 0
                    with archive.open(str(name), 'r') as source, os.fdopen(fd, 'wb', closefd=False) as output:
                        while True:
                            chunk = source.read(1024 * 1024)
                            if not chunk:
                                break
                            total += len(chunk)
                            if total > int(evidence['size']):
                                raise RestoreError(f'restoregrootte mismatch: {name}')
                            digest.update(chunk)
                            output.write(chunk)
                        output.flush()
                        os.fsync(output.fileno())
                    os.close(fd)
                except Exception:
                    try:
                        os.close(fd)
                    except Exception:
                        pass
                    raise
                if total != int(evidence['size']) or digest.hexdigest() != str(evidence['sha256']):
                    raise RestoreError(f'restorehash mismatch: {name}')
        # Publish the complete restored tree only after a second write-time hash check.
        for name, evidence in sorted(files.items()):
            if str(name).startswith('state/'):
                restored = staging.joinpath(*str(name).split('/')[1:])
                if not restored.is_file() or restored.stat().st_size != int(evidence['size']):
                    raise RestoreError(f'hersteld bestand ontbreekt: {name}')
                if sha256_file(restored) != str(evidence['sha256']):
                    raise RestoreError(f'hersteld bestand heeft verkeerde hash: {name}')
        for directory in sorted((path for path in staging.rglob('*') if path.is_dir()), reverse=True):
            fsync_directory(directory)
        fsync_directory(staging)
        os.replace(staging, target)
        fsync_directory(target.parent)
    except Exception:
        shutil.rmtree(staging, ignore_errors=True)
        raise

    result = {
        'ok': True,
        'verifiedAt': datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'),
        'backupSha256': verified['backupSha256'],
        'manifestSha256': verified['manifestSha256'],
        'restoredTo': str(target),
        'stateFileCount': verified['stateFileCount'],
        'totalBytes': verified['totalBytes'],
    }
    if proof_path is not None:
        proof = Path(proof_path).expanduser().absolute()
        durable_write_json(proof, result, mode=0o600)
        result['proof'] = str(proof)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description='Verify or restore a FIX660R8 system backup')
    parser.add_argument('backup', type=Path)
    parser.add_argument('--verify-only', action='store_true')
    parser.add_argument('--target', type=Path, help='new, non-existing staging directory')
    parser.add_argument('--proof', type=Path, help='write restore-test proof after a real restore')
    parser.add_argument('--max-files', type=int, default=int(os.environ.get('RESTORE_MAX_FILES', DEFAULT_MAX_FILES)))
    parser.add_argument('--max-bytes', type=int, default=int(os.environ.get('RESTORE_MAX_BYTES', DEFAULT_MAX_BYTES)))
    args = parser.parse_args()
    if args.verify_only:
        if args.target is not None or args.proof is not None:
            parser.error('--verify-only cannot be combined with --target/--proof')
        verified = verify_backup(args.backup, max_files=args.max_files, max_bytes=args.max_bytes)
        result = {
            'ok': True,
            'verifiedOnly': True,
            'backupSha256': verified['backupSha256'],
            'manifestSha256': verified['manifestSha256'],
            'stateFileCount': verified['stateFileCount'],
            'totalBytes': verified['totalBytes'],
        }
    else:
        if args.target is None:
            parser.error('--target is required unless --verify-only is used')
        result = restore_backup(
            args.backup,
            args.target,
            proof_path=args.proof,
            max_files=args.max_files,
            max_bytes=args.max_bytes,
        )
    import json
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (RestoreError, OSError, zipfile.BadZipFile) as exc:
        print(f'RESTORE FAILED: {exc}', file=sys.stderr)
        raise SystemExit(2)
