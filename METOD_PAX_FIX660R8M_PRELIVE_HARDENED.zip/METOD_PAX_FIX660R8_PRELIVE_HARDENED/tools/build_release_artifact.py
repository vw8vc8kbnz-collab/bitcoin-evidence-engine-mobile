#!/usr/bin/env python3
from __future__ import annotations

"""Build a deterministic FIX660R8 ZIP after the complete release gate passes."""

import argparse
import hashlib
import os
import stat
import subprocess
import sys
import zipfile
from pathlib import Path, PurePosixPath


RELEASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RELEASE / 'app'))

from safety_contracts import durable_write_text, fsync_directory  # noqa: E402


EXCLUDED_NAMES = {'SHA256SUMS.txt'}
EXCLUDED_SUFFIXES = {'.pyc', '.bak'}
FIXED_ZIP_TIME = (2026, 8, 12, 0, 0, 0)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def release_files() -> list[Path]:
    files: list[Path] = []
    for path in RELEASE.rglob('*'):
        relative = path.relative_to(RELEASE)
        if path.is_symlink():
            raise RuntimeError(f'symlink is forbidden in release: {relative}')
        if not path.is_file():
            continue
        if path.name in EXCLUDED_NAMES or path.suffix.lower() in EXCLUDED_SUFFIXES:
            continue
        if '__pycache__' in path.parts or '.git' in path.parts:
            continue
        files.append(path)
    return sorted(files, key=lambda item: item.relative_to(RELEASE).as_posix())


def write_manifest(files: list[Path]) -> None:
    lines = [f'{sha256_file(path)}  ./{path.relative_to(RELEASE).as_posix()}' for path in files]
    durable_write_text(RELEASE / 'SHA256SUMS.txt', '\n'.join(lines) + '\n', mode=0o444)


def run_gate() -> None:
    env = dict(os.environ)
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    subprocess.run(
        [sys.executable, str(RELEASE / 'tools/final_preflight.py'), '--release', str(RELEASE), '--verify-checksums'],
        cwd=str(RELEASE),
        env=env,
        check=True,
    )


def write_zip(output: Path, files: list[Path]) -> None:
    output = output.expanduser().absolute()
    if output.parent == RELEASE or RELEASE in output.parents:
        raise RuntimeError('artifact ZIP must be written outside the release tree')
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.parent / f'.{output.name}.tmp.{os.getpid()}'
    try:
        with zipfile.ZipFile(temporary, 'w', compression=zipfile.ZIP_STORED, allowZip64=True) as archive:
            all_files = sorted(files + [RELEASE / 'SHA256SUMS.txt'], key=lambda item: item.relative_to(RELEASE).as_posix())
            for path in all_files:
                relative = path.relative_to(RELEASE).as_posix()
                info = zipfile.ZipInfo(f'{RELEASE.name}/{relative}', FIXED_ZIP_TIME)
                info.create_system = 3
                executable = path.suffix in {'.sh', '.py'} or os.access(path, os.X_OK)
                info.external_attr = (stat.S_IFREG | (0o555 if executable else 0o444)) << 16
                info.compress_type = zipfile.ZIP_STORED
                archive.writestr(info, path.read_bytes())
        expected = {
            f'{RELEASE.name}/{path.relative_to(RELEASE).as_posix()}': path
            for path in all_files
        }
        with zipfile.ZipFile(temporary, 'r') as archive:
            infos = archive.infolist()
            names = [info.filename for info in infos]
            if len(names) != len(set(names)) or set(names) != set(expected):
                raise RuntimeError('artifact ZIP has missing, extra, or duplicate members')
            if archive.testzip() is not None:
                raise RuntimeError('artifact ZIP CRC verification failed')
            for info in infos:
                member = PurePosixPath(info.filename)
                mode = (info.external_attr >> 16) & 0xFFFF
                if member.is_absolute() or '..' in member.parts or '\\' in info.filename:
                    raise RuntimeError(f'unsafe artifact ZIP member: {info.filename}')
                if not stat.S_ISREG(mode):
                    raise RuntimeError(f'non-regular artifact ZIP member: {info.filename}')
                digest = hashlib.sha256()
                with archive.open(info, 'r') as source:
                    for chunk in iter(lambda: source.read(1024 * 1024), b''):
                        digest.update(chunk)
                if digest.hexdigest() != sha256_file(expected[info.filename]):
                    raise RuntimeError(f'artifact ZIP byte mismatch: {info.filename}')
        with temporary.open('rb') as handle:
            os.fsync(handle.fileno())
        os.replace(temporary, output)
        fsync_directory(output.parent)
    finally:
        temporary.unlink(missing_ok=True)
    durable_write_text(output.with_suffix(output.suffix + '.sha256'), f'{sha256_file(output)}  {output.name}\n', mode=0o444)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    files = release_files()
    write_manifest(files)
    run_gate()
    # Re-read after the gate to prove it did not create or change tracked files.
    after = release_files()
    if [p.relative_to(RELEASE) for p in files] != [p.relative_to(RELEASE) for p in after]:
        raise RuntimeError('release tree changed while the gate was running')
    write_zip(args.output, after)
    print(args.output.expanduser().absolute())
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
