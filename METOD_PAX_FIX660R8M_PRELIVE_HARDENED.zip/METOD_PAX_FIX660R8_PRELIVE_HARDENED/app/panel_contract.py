from __future__ import annotations

"""Canonical panel CSV validation shared by the API and Tool B optimizer."""

import csv
import io
import math
import re
from dataclasses import dataclass
from typing import Any, Iterable, Optional

from safety_contracts import (
    ContractError,
    finite_number,
    strict_bool,
    strict_integer,
    validate_grain_group,
    validate_part_id,
)


REQUIRED_COLUMNS = (
    "PartId",
    "PanelName",
    "Qty",
    "LengthMm",
    "WidthMm",
    "ThicknessMm",
    "MaterialCode",
    "GrainGroup",
    "RotationAllowed",
    "H1",
    "H2",
    "W1",
    "W2",
)

MATERIAL_CODE_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,119}$")


@dataclass(frozen=True)
class CanonicalPanel:
    PartId: str
    PanelName: str
    Qty: int
    LengthMm: float
    WidthMm: float
    ThicknessMm: float
    MaterialCode: str
    GrainGroup: str
    RotationAllowed: bool
    H1: int
    H2: int
    W1: int
    W2: int

    @property
    def grain_group_id(self) -> str:
        parsed = validate_grain_group(self.GrainGroup)
        return parsed[0] if parsed else ""

    @property
    def grain_position(self) -> Optional[int]:
        parsed = validate_grain_group(self.GrainGroup)
        return parsed[1] if parsed else None

    def as_dict(self) -> dict[str, Any]:
        return {
            "PartId": self.PartId,
            "PanelName": self.PanelName,
            "Qty": self.Qty,
            "LengthMm": self.LengthMm,
            "WidthMm": self.WidthMm,
            "ThicknessMm": self.ThicknessMm,
            "MaterialCode": self.MaterialCode,
            "GrainGroup": self.GrainGroup,
            "RotationAllowed": self.RotationAllowed,
            "H1": self.H1,
            "H2": self.H2,
            "W1": self.W1,
            "W2": self.W2,
        }


def _normal_mm(value: Any, *, field: str, maximum: float = 10000.0) -> float:
    number = finite_number(value, field=field, minimum=0.1, maximum=maximum)
    normalized = round(number, 1)
    if abs(number - normalized) > 1e-7:
        raise ContractError(f"{field} must use 0.1 mm precision")
    return normalized


def _clean_panel_name(value: Any) -> str:
    raw = str(value or "").strip()
    if not raw:
        raise ContractError("PanelName is required")
    if len(raw) > 240 or any(ord(ch) < 32 and ch not in "\t" for ch in raw):
        raise ContractError("PanelName is invalid")
    return " ".join(raw.split())


def _edge_code(value: Any, *, field: str, allowed_edge_codes: set[int]) -> int:
    code = strict_integer(value, field=field, minimum=0, maximum=999)
    if code not in allowed_edge_codes:
        raise ContractError(f"{field} contains unknown edge code {code}")
    return code


def parse_panels_csv(
    text: str,
    *,
    allowed_thicknesses: Iterable[float] = (18.0, 19.0, 20.0),
    allowed_edge_codes: Iterable[int] = (0, 1),
    max_rows: int = 500,
    max_total_qty: int = 250,
) -> list[CanonicalPanel]:
    if not isinstance(text, str) or not text.strip():
        raise ContractError("panels.csv is empty")
    if "\x00" in text:
        raise ContractError("panels.csv contains a NUL byte")
    first_line = text.splitlines()[0] if text.splitlines() else ""
    delimiter = ";" if ";" in first_line else ","
    reader = csv.DictReader(io.StringIO(text), delimiter=delimiter)
    if not reader.fieldnames:
        raise ContractError("panels.csv has no header")
    missing = [name for name in REQUIRED_COLUMNS if name not in reader.fieldnames]
    if missing:
        raise ContractError(f"panels.csv missing columns: {', '.join(missing)}")

    allowed_th = {round(float(item), 3) for item in allowed_thicknesses}
    edge_codes = {int(item) for item in allowed_edge_codes}
    rows: list[CanonicalPanel] = []
    seen_ids: set[str] = set()
    total_qty = 0

    for row_number, raw in enumerate(reader, start=2):
        if len(rows) >= int(max_rows):
            raise ContractError(f"panels.csv exceeds {max_rows} rows")
        try:
            part_id = validate_part_id(raw.get("PartId"))
            if part_id in seen_ids:
                raise ContractError(f"duplicate PartId {part_id}")
            seen_ids.add(part_id)

            qty = strict_integer(raw.get("Qty"), field="Qty", minimum=1, maximum=max_total_qty)
            total_qty += qty
            if total_qty > int(max_total_qty):
                raise ContractError(f"total Qty exceeds {max_total_qty}")

            length = _normal_mm(raw.get("LengthMm"), field="LengthMm")
            width = _normal_mm(raw.get("WidthMm"), field="WidthMm")
            thickness = _normal_mm(raw.get("ThicknessMm"), field="ThicknessMm", maximum=100.0)
            if round(thickness, 3) not in allowed_th:
                raise ContractError(f"ThicknessMm {thickness:g} is not allowed")

            material = str(raw.get("MaterialCode") or "").strip()
            if not MATERIAL_CODE_RE.fullmatch(material):
                raise ContractError("MaterialCode is invalid")

            grain_raw = str(raw.get("GrainGroup") or "").strip()
            grain = validate_grain_group(grain_raw)
            rotation = strict_bool(raw.get("RotationAllowed"), field="RotationAllowed")
            if grain is not None:
                if qty != 1:
                    raise ContractError("a GrainGroup row must have Qty=1")
                if rotation:
                    raise ContractError("a GrainGroup row cannot rotate")

            rows.append(
                CanonicalPanel(
                    PartId=part_id,
                    PanelName=_clean_panel_name(raw.get("PanelName")),
                    Qty=qty,
                    LengthMm=length,
                    WidthMm=width,
                    ThicknessMm=thickness,
                    MaterialCode=material,
                    GrainGroup=grain_raw,
                    RotationAllowed=rotation,
                    H1=_edge_code(raw.get("H1"), field="H1", allowed_edge_codes=edge_codes),
                    H2=_edge_code(raw.get("H2"), field="H2", allowed_edge_codes=edge_codes),
                    W1=_edge_code(raw.get("W1"), field="W1", allowed_edge_codes=edge_codes),
                    W2=_edge_code(raw.get("W2"), field="W2", allowed_edge_codes=edge_codes),
                )
            )
        except ContractError as exc:
            raise ContractError(f"panels.csv row {row_number}: {exc}") from exc

    if not rows:
        raise ContractError("panels.csv contains no panel rows")
    validate_grain_groups(rows)
    return rows


def validate_grain_groups(rows: Iterable[CanonicalPanel]) -> None:
    groups: dict[tuple[str, str, float], list[CanonicalPanel]] = {}
    group_material: dict[str, tuple[str, float]] = {}
    for row in rows:
        parsed = validate_grain_group(row.GrainGroup)
        if parsed is None:
            continue
        group_id, _ = parsed
        material_key = (row.MaterialCode, row.ThicknessMm)
        previous = group_material.setdefault(group_id, material_key)
        if previous != material_key:
            raise ContractError(f"GrainGroup {group_id} spans multiple materials or thicknesses")
        groups.setdefault((group_id, row.MaterialCode, row.ThicknessMm), []).append(row)

    for (group_id, _material, _thickness), members in groups.items():
        positions = [int(row.grain_position or 0) for row in members]
        expected = list(range(1, len(members) + 1))
        if sorted(positions) != expected:
            raise ContractError(f"GrainGroup {group_id} positions must be unique and contiguous 1..{len(members)}")
        widths = {round(row.WidthMm, 1) for row in members}
        if len(widths) != 1:
            values = ", ".join(f"{item:g}" for item in sorted(widths))
            raise ContractError(f"GrainGroup {group_id} has mixed WidthMm values: {values}")


def canonical_csv(rows: Iterable[CanonicalPanel]) -> str:
    out = io.StringIO(newline="")
    writer = csv.DictWriter(out, fieldnames=list(REQUIRED_COLUMNS), delimiter=";", lineterminator="\n")
    writer.writeheader()
    for row in rows:
        item = row.as_dict()
        item["RotationAllowed"] = "true" if row.RotationAllowed else "false"
        writer.writerow(item)
    return out.getvalue()

