from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Optional, Any, Callable
from urllib.parse import urlparse

from safety_contracts import (
    ContractError,
    durable_write_json,
    durable_write_text,
    resolve_relative_file,
    strict_json_loads,
)


def read_json_body(handler, max_bytes: Optional[int] = None) -> dict:
    raw_len = handler.headers.get('Content-Length', '0') or '0'
    try:
        n = int(raw_len)
    except Exception:
        raise ValueError('Invalid Content-Length')
    if n < 0:
        raise ValueError('Invalid Content-Length')
    if max_bytes is not None and n > int(max_bytes):
        raise ValueError(f'JOB_PAYLOAD_TOO_LARGE::{n}::{int(max_bytes)}')
    raw = handler.rfile.read(n) if n else b''
    if max_bytes is not None and len(raw) > int(max_bytes):
        raise ValueError(f'JOB_PAYLOAD_TOO_LARGE::{len(raw)}::{int(max_bytes)}')
    if not raw:
        return {}
    value = strict_json_loads(raw)
    if not isinstance(value, dict):
        raise ValueError('JSON body must be an object')
    return value


def read_json_body_limited(handler, env_name: str, default_bytes: int) -> dict:
    try:
        max_bytes = int(os.environ.get(env_name, str(default_bytes)) or str(default_bytes))
    except Exception:
        max_bytes = int(default_bytes)
    return read_json_body(handler, max_bytes=max_bytes)


def extract_request_token(handler, parsed=None, body: Optional[dict] = None) -> str:
    """Return the public job bearer token from the Authorization header only.

    FIX657 production contract: public job secrets must never be accepted from query
    strings or JSON bodies because URLs can leak through history/referers/proxy logs and
    request bodies are unnecessarily broad compatibility surfaces.  X-Job-Token is also
    retired so there is exactly one canonical transport: ``Authorization: Bearer``.

    ``parsed`` and ``body`` remain in the signature only to keep older internal callers
    source-compatible; they are intentionally ignored.
    """
    try:
        auth = str(handler.headers.get('Authorization') or '').strip()
        if auth.lower().startswith('bearer '):
            return auth.split(' ', 1)[1].strip()
    except Exception:
        pass
    return ''


def safe_job_file(job_root: Path, rel: str) -> Optional[Path]:
    try:
        return resolve_relative_file(Path(job_root), rel)
    except (ContractError, OSError, RuntimeError, ValueError):
        return None


def atomic_write_text(path: Path, text: str) -> None:
    durable_write_text(path, text)


def atomic_write_json(path: Path, obj: dict) -> None:
    durable_write_json(path, obj)


def require_same_origin_admin_write(
    handler,
    *,
    is_loopback_value: Callable[[str], bool],
    is_loopback_client: Callable[[Any], bool],
) -> tuple[bool, Optional[str]]:
    try:
        origin = str(handler.headers.get('Origin') or '').strip()
        referer = str(handler.headers.get('Referer') or '').strip()
        host_header = str(handler.headers.get('Host') or '').strip()
        host_name = host_header.split(':', 1)[0].strip().lower() if host_header else ''

        allowed_origins = {
            x.strip() for x in str(os.environ.get('ALLOWED_ADMIN_ORIGINS', '')).split(',') if x.strip()
        }

        production = (
            str(os.environ.get('APP_ENV', '')).strip().lower() in ('prod', 'production')
            or str(os.environ.get('PRODUCTION_HARDENING', '')).strip().lower() in ('1', 'true', 'yes', 'on')
            or str(os.environ.get('ADMIN_HASH_ONLY', '')).strip().lower() in ('1', 'true', 'yes', 'on')
        )

        def host_ok(candidate_host: str) -> bool:
            # Host-header equality is only a local/development compatibility fallback.
            # In production the browser Origin/Referer must match the explicit allowlist;
            # trusting Host here would let a direct backend request spoof both values.
            if production:
                return False
            candidate_host = str(candidate_host or '').strip().lower()
            if not candidate_host:
                return False
            if host_name and candidate_host == host_name:
                return True
            if host_name and is_loopback_value(candidate_host) and is_loopback_value(host_name):
                return True
            return False

        if origin:
            if origin in allowed_origins:
                return True, None
            o = urlparse(origin)
            if host_ok(o.hostname or ''):
                return True, None
            return False, 'Admin write origin blocked'

        if referer:
            try:
                r = urlparse(referer)
                ref_origin = f"{r.scheme}://{r.netloc}" if r.scheme and r.netloc else ''
                if ref_origin and ref_origin in allowed_origins:
                    return True, None
                if host_ok(r.hostname or ''):
                    return True, None
            except Exception:
                pass
            return False, 'Admin write referer blocked'

        if (not production) and is_loopback_client(handler):
            return True, None
        return False, 'Admin write origin missing'
    except Exception:
        return False, 'Admin write origin check failed'
