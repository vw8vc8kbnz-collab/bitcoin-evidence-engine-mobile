/* FIX324: low-risk view/math helper extraction */
(function(){
  function polygonArea(pts){
    var a = 0;
    pts = Array.isArray(pts) ? pts : [];
    for(var i=0;i<pts.length;i++){
      var p = pts[i] || {x:0,y:0};
      var q = pts[(i+1)%pts.length] || {x:0,y:0};
      a += (Number(p.x)||0)*(Number(q.y)||0) - (Number(q.x)||0)*(Number(p.y)||0);
    }
    return a/2;
  }

  function computeBounds(pts){
    pts = Array.isArray(pts) ? pts : [];
    var minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;
    for(var i=0;i<pts.length;i++){
      var p = pts[i] || {x:0,y:0};
      var x = Number(p.x)||0;
      var y = Number(p.y)||0;
      if(x<minX) minX=x;
      if(y<minY) minY=y;
      if(x>maxX) maxX=x;
      if(y>maxY) maxY=y;
    }
    if(!pts.length){
      minX=minY=maxX=maxY=0;
    }
    return {minX:minX,minY:minY,maxX:maxX,maxY:maxY};
  }

  function computePanelPreviewFit(opts){
    opts = opts || {};
    var canvasWidth = Math.max(1, Number(opts.canvasWidth)||1);
    var canvasHeight = Math.max(1, Number(opts.canvasHeight)||1);
    var minX = Number(opts.previewMinX)||0;
    var maxX = Number(opts.previewMaxX)||0;
    var minY = Number(opts.previewMinY)||0;
    var maxY = Number(opts.previewMaxY)||0;
    var mobile = !!opts.mobile;
    var previewW = Math.max(1, maxX-minX);
    var previewH = Math.max(1, maxY-minY);

    // Desktop intentionally keeps the established FIX659 geometry. On mobile we reserve
    // explicit screen-space gutters for dimension lines/text instead of allowing the
    // drawing to consume the full canvas and then clipping the left/top dimensions.
    var pad = mobile ? 14 : 34;
    var headerReserve = mobile ? 66 : 0;
    var footerReserve = mobile ? 64 : 0;
    var dimLeft = mobile ? 42 : 0;
    var dimRight = mobile ? 8 : 0;
    var dimTop = mobile ? 28 : 0;
    var dimBottom = mobile ? 10 : 0;

    var boxLeft = pad + dimLeft;
    var boxTop = pad + headerReserve + dimTop;
    var boxRight = canvasWidth - pad - dimRight;
    var boxBottom = canvasHeight - pad - footerReserve - dimBottom;
    var availW = Math.max(48, boxRight-boxLeft);
    var availH = Math.max(48, boxBottom-boxTop);
    var scale = Math.min(availW/previewW, availH/previewH) * (mobile ? 0.985 : 0.90);
    if(!Number.isFinite(scale) || scale <= 0) scale = 1;

    var drawW = previewW*scale;
    var drawH = previewH*scale;
    var ox = boxLeft + (availW-drawW)/2 - minX*scale;
    // Canvas y-axis is inverted for the local panel coordinates.
    var oy = boxTop + (availH-drawH)/2 + maxY*scale;
    return {
      pad:pad, headerReserve:headerReserve, footerReserve:footerReserve,
      dimensionGutters:{left:dimLeft,right:dimRight,top:dimTop,bottom:dimBottom},
      contentBox:{left:boxLeft,top:boxTop,right:boxRight,bottom:boxBottom,width:availW,height:availH},
      previewW:previewW, previewH:previewH, scale:scale, ox:ox, oy:oy
    };
  }

  window.ToolAViewMathHelpers = {
    polygonArea: polygonArea,
    computeBounds: computeBounds,
    computePanelPreviewFit: computePanelPreviewFit
  };
})();
