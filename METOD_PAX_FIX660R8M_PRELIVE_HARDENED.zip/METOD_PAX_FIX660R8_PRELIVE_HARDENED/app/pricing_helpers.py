from __future__ import annotations

import json
import re
from pathlib import Path

from safety_contracts import strict_json_load


def _find_existing_file(base_dir: Path, candidates):
    for rel in candidates:
        p = base_dir / rel
        if p.exists():
            return p
    return None


def _find_placements_any(output_dir: Path):
    candidates = [Path("placements.json"), Path("placements"), Path("Placements.json"), Path("Placements")]
    p = _find_existing_file(output_dir, candidates)
    if p:
        return p
    try:
        for f in output_dir.iterdir():
            if f.is_file() and f.name.lower().startswith('placements'):
                return f
    except Exception:
        return None
    return None


def aggregate_materials_from_subjob_quotes(JOBS: Path, parent_job_id: str) -> list[dict]:
    """For parent jobs, derive actual material sheet counts from real material subjobs.

    Prefer real material subjobs over the parent summary. Do *not* depend solely on links.json:
    some runs clearly produce the material subjob folders and placements, but the parent links file
    can be missing/stale. In those cases the old logic returned [], causing the calculation summary
    to fall back to the parent quote/request payload and flatten big orders to 1 sheet per material.
    """
    try:
        parent_root = JOBS / str(parent_job_id)
        links_path = parent_root / "output" / "links.json"
        subs = []
        if links_path.exists():
            try:
                links = strict_json_load(links_path)
                raw_subs = links.get("subjobs") if isinstance(links, dict) else []
                if isinstance(raw_subs, list):
                    subs.extend([sj for sj in raw_subs if isinstance(sj, dict)])
            except Exception:
                pass
        prefix = f"{str(parent_job_id).strip()}__mat_"
        for cand in JOBS.iterdir():
            try:
                if not cand.is_dir():
                    continue
                nm = cand.name
                if not nm.startswith(prefix):
                    continue
                jid = nm.strip()
                if not jid:
                    continue
                if not any(str((x.get("jobId") or "")).strip() == jid for x in subs):
                    subs.append({"jobId": jid})
            except Exception:
                continue
        if not subs:
            return []

        acc = {}

        def _safe_th(v):
            try:
                return float(v or 0.0)
            except Exception:
                return 0.0

        def _safe_cnt(v):
            try:
                return int(float(v or 0) or 0)
            except Exception:
                return 0

        def _merge_material(rec: dict):
            if not isinstance(rec, dict):
                return
            code = str(rec.get("materialCode") or "").strip()
            if not code:
                return
            th = _safe_th(rec.get("thicknessMm"))
            key = (code, th)
            prev = acc.get(key)
            if prev is None:
                prev = json.loads(json.dumps(rec))
                prev["sheetCount"] = _safe_cnt(prev.get("sheetCount"))
                acc[key] = prev
            else:
                prev["sheetCount"] = prev.get("sheetCount") or 0
                incoming = _safe_cnt(rec.get("sheetCount"))
                prev["sheetCount"] = int(prev["sheetCount"] or 0) + incoming
                for kk in ("sheetSizeMm", "productName", "materialDisplayName", "decorName", "name", "sheetUnitCost", "sheetUnitCostRaw"):
                    if not prev.get(kk) and rec.get(kk) is not None:
                        prev[kk] = rec.get(kk)
            try:
                unit = prev.get("sheetUnitCost")
                if unit is None:
                    unit = prev.get("sheetUnitCostRaw")
                unit = float(unit or 0.0)
                prev["sheetCostTotal"] = round(unit * int(prev.get("sheetCount") or 0), 2)
            except Exception:
                pass

        for sj in subs:
            if not isinstance(sj, dict):
                continue
            sjid = str(sj.get("jobId") or "").strip()
            if not sjid:
                continue
            sj_root = JOBS / sjid
            quote_materials = []
            qpath = sj_root / "output" / "quote.json"
            if qpath.exists():
                try:
                    q = strict_json_load(qpath)
                    if isinstance(q, dict) and isinstance(q.get("materials"), list):
                        quote_materials = [m for m in (q.get("materials") or []) if isinstance(m, dict)]
                except Exception:
                    quote_materials = []

            placements_counts = {}
            try:
                ppath = _find_placements_any(sj_root / "output") or (sj_root / "output" / "placements.json")
                if ppath and Path(ppath).exists():
                    pobj = strict_json_load(Path(ppath))

                    if isinstance(pobj, dict):
                        for sh in (pobj.get("sheets") or []):
                            if not isinstance(sh, dict):
                                continue
                            code = str(sh.get("materialCode") or "").strip()
                            if not code:
                                continue
                            th = _safe_th(sh.get("thicknessMm"))
                            cnt = _safe_cnt(sh.get("sheetsUsed") or sh.get("sheetCount") or sh.get("plates"))
                            if cnt <= 0:
                                continue
                            key = (code, th)
                            placements_counts[key] = max(placements_counts.get(key, 0), cnt)

                    plist = []
                    if isinstance(pobj, list):
                        plist = pobj
                    elif isinstance(pobj, dict):
                        plist = pobj.get("placements") or pobj.get("items") or []
                    for p in plist:
                        if not isinstance(p, dict):
                            continue
                        code = str(p.get("materialCode") or "").strip()
                        if not code:
                            continue
                        th = _safe_th(p.get("thicknessMm"))
                        try:
                            sheet_idx = int(float(p.get("sheetIndex") or p.get("sheet") or 0) or 0)
                        except Exception:
                            sheet_idx = 0
                        if sheet_idx <= 0:
                            continue
                        key = (code, th)
                        placements_counts[key] = max(placements_counts.get(key, 0), sheet_idx)

                    if sj_root.exists():
                        try:
                            dxf_count = len(list((sj_root / "output").glob("Sheet_*.dxf")))
                        except Exception:
                            dxf_count = 0
                        if dxf_count > 0:
                            code_from_jid = ""
                            try:
                                code_from_jid = sjid.split("__mat_", 1)[1].strip()
                            except Exception:
                                code_from_jid = ""
                            if code_from_jid:
                                known_th = 0.0
                                if placements_counts:
                                    for (pc, pth), _cnt in placements_counts.items():
                                        if pc == code_from_jid:
                                            known_th = pth
                                            break
                                if not known_th and quote_materials:
                                    for qm in quote_materials:
                                        if str(qm.get("materialCode") or "").strip() == code_from_jid:
                                            known_th = _safe_th(qm.get("thicknessMm"))
                                            break
                                key = (code_from_jid, known_th)
                                placements_counts[key] = max(placements_counts.get(key, 0), dxf_count)
            except Exception:
                placements_counts = {}

            if quote_materials:
                seen_keys = set()
                for m in quote_materials:
                    code = str(m.get("materialCode") or "").strip()
                    th = _safe_th(m.get("thicknessMm"))
                    key = (code, th)
                    rec = json.loads(json.dumps(m))
                    rec["sheetCount"] = max(_safe_cnt(rec.get("sheetCount")), placements_counts.get(key, 0))
                    _merge_material(rec)
                    seen_keys.add(key)
                for key, cnt in placements_counts.items():
                    if key in seen_keys or cnt <= 0:
                        continue
                    code, th = key
                    _merge_material({"materialCode": code, "thicknessMm": th, "sheetCount": cnt})
            else:
                for key, cnt in placements_counts.items():
                    if cnt <= 0:
                        continue
                    code, th = key
                    _merge_material({"materialCode": code, "thicknessMm": th, "sheetCount": cnt})

        return [m for m in acc.values() if int(m.get("sheetCount") or 0) > 0]
    except Exception:
        return []


def parse_calculation_summary_totals(job_root: Path) -> dict:
    """Read the human calculation summary and extract the real order totals."""
    out = {}
    try:
        p = Path(job_root) / "calculation_summary.txt"
        if not p.exists():
            p = Path(job_root) / "output" / "calculation_summary.txt"
        if not p.exists():
            return out
        s = p.read_text(encoding="utf-8", errors="ignore")
        pats = {
            "materialsTotalInclVat": r"Plaatmateriaal incl\. btw:\s*€\s*([0-9\.,]+)",
            "materialsTotal": r"Plaatmateriaal netto-equivalent:\s*€\s*([0-9\.,]+)",
            "materialsVatIncluded": r"BTW reeds in plaatprijs:\s*€\s*([0-9\.,]+)",
            "edgeBandTotal": r"Kantenband excl\. btw:\s*€\s*([0-9\.,]+)",
            "cncTotal": r"CNC excl\. btw:\s*€\s*([0-9\.,]+)",
            "drawingTotal": r"Tekenen excl\. btw:\s*€\s*([0-9\.,]+)",
            "transportTotal": r"Transport excl\. btw:\s*€\s*([0-9\.,]+)",
            "otherCostsExVat": r"Overige kosten excl\. btw:\s*€\s*([0-9\.,]+)",
            "otherCostsVat": r"BTW over overige kosten:\s*€\s*([0-9\.,]+)",
            "subtotalExVat": r"Subtotaal excl\. btw:\s*€\s*([0-9\.,]+)",
            "vatAmount": r"BTW\s*\(21%\):\s*€\s*([0-9\.,]+)",
            "totalInclVat": r"Totaal incl\. btw:\s*€\s*([0-9\.,]+)",
        }
        for k, pat in pats.items():
            m = re.search(pat, s, flags=re.I)
            if m:
                raw = m.group(1).replace(".", "").replace(",", ".")
                try:
                    out[k] = round(float(raw), 2)
                except Exception:
                    pass
    except Exception:
        return out
    return out
