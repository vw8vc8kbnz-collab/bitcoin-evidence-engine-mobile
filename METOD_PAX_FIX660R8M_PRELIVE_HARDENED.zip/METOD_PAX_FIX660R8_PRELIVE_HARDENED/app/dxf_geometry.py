from __future__ import annotations

"""Small, deterministic DXF geometry contract used by the production optimizer.

The application only accepts ASCII DXF ENTITIES and a deliberately finite entity
allowlist. Unknown entities fail closed instead of being silently dropped.
"""

import math
from dataclasses import dataclass
from typing import Iterable, Optional

from safety_contracts import ContractError, finite_number, sha256_bytes

Pair = tuple[int, str]
Entity = list[Pair]

SUPPORTED_MACHINING_TYPES = {
    "CIRCLE",
    "ARC",
    "LINE",
    "LWPOLYLINE",
    "POLYLINE",
    "VERTEX",
    "ELLIPSE",
    "SPLINE",
    "POINT",
    "SOLID",
    "TRACE",
}


@dataclass(frozen=True)
class BBox:
    min_x: float
    min_y: float
    max_x: float
    max_y: float

    @property
    def width(self) -> float:
        return self.max_x - self.min_x

    @property
    def height(self) -> float:
        return self.max_y - self.min_y

    def union(self, other: "BBox") -> "BBox":
        return BBox(
            min(self.min_x, other.min_x),
            min(self.min_y, other.min_y),
            max(self.max_x, other.max_x),
            max(self.max_y, other.max_y),
        )


def parse_pairs(text: str) -> list[Pair]:
    if not isinstance(text, str) or not text.strip():
        raise ContractError("DXF is empty")
    if "\x00" in text:
        raise ContractError("DXF contains a NUL byte")
    lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    while lines and lines[-1] == "":
        lines.pop()
    if len(lines) % 2:
        raise ContractError("DXF has an incomplete group-code pair")
    pairs: list[Pair] = []
    for index in range(0, len(lines), 2):
        try:
            code = int(lines[index].strip())
        except Exception as exc:
            raise ContractError(f"DXF has invalid group code at line {index + 1}") from exc
        pairs.append((code, lines[index + 1]))
    return pairs


def pairs_to_text(pairs: Iterable[Pair]) -> str:
    return "\n".join(f"{int(code)}\n{value}" for code, value in pairs) + "\n"


def entities_section(pairs: list[Pair]) -> list[Pair]:
    in_entities = False
    result: list[Pair] = []
    index = 0
    while index < len(pairs):
        code, value = pairs[index]
        upper = str(value).strip().upper()
        if code == 0 and upper == "SECTION" and index + 1 < len(pairs):
            next_code, next_value = pairs[index + 1]
            if next_code == 2 and str(next_value).strip().upper() == "ENTITIES":
                in_entities = True
                index += 2
                continue
        if in_entities and code == 0 and upper == "ENDSEC":
            break
        if in_entities:
            result.append((code, value))
        index += 1
    if not in_entities:
        raise ContractError("DXF ENTITIES section is missing")
    return result


def split_entities(flat_pairs: Iterable[Pair]) -> list[Entity]:
    entities: list[Entity] = []
    current: Entity = []
    for code, value in flat_pairs:
        if code == 0:
            if current:
                entities.append(current)
            current = [(code, value)]
        elif current:
            current.append((code, value))
        else:
            raise ContractError("DXF entity data appears before an entity type")
    if current:
        entities.append(current)
    return entities


def entity_type(entity: Entity) -> str:
    if not entity or entity[0][0] != 0:
        raise ContractError("DXF entity has no type")
    return str(entity[0][1]).strip().upper()


def entity_layer(entity: Entity) -> str:
    return next((str(value).strip() for code, value in entity if code == 8), "0")


def _number(value: str, *, field: str = "DXF coordinate") -> float:
    return finite_number(value, field=field, minimum=-1.0e9, maximum=1.0e9)


def _first(entity: Entity, code: int, default: Optional[float] = None) -> Optional[float]:
    for item_code, value in entity:
        if item_code == code:
            return _number(value)
    return default


def _paired_points(entity: Entity, x_codes: set[int]) -> list[tuple[float, float]]:
    y_by_x = {10: 20, 11: 21, 12: 22, 13: 23, 14: 24, 15: 25, 16: 26, 17: 27, 18: 28}
    out: list[tuple[float, float]] = []
    pending: dict[int, float] = {}
    for code, value in entity:
        if code in x_codes:
            pending[code] = _number(value)
            continue
        for x_code, y_code in y_by_x.items():
            if code == y_code and x_code in pending:
                out.append((pending.pop(x_code), _number(value)))
                break
    return out


def _angle_on_sweep(angle: float, start: float, end: float) -> bool:
    angle %= 360.0
    start %= 360.0
    end %= 360.0
    sweep = (end - start) % 360.0
    delta = (angle - start) % 360.0
    return delta <= sweep + 1e-9


def entity_bbox(entity: Entity) -> Optional[BBox]:
    kind = entity_type(entity)
    if kind in {"CIRCLE", "ARC"}:
        cx = _first(entity, 10)
        cy = _first(entity, 20)
        radius = _first(entity, 40)
        if cx is None or cy is None or radius is None or radius <= 0:
            raise ContractError(f"{kind} has invalid center/radius")
        if kind == "CIRCLE":
            return BBox(cx - radius, cy - radius, cx + radius, cy + radius)
        start = _first(entity, 50)
        end = _first(entity, 51)
        if start is None or end is None:
            raise ContractError("ARC has no start/end angle")
        angles = [start, end] + [value for value in (0.0, 90.0, 180.0, 270.0) if _angle_on_sweep(value, start, end)]
        points = [(cx + radius * math.cos(math.radians(angle)), cy + radius * math.sin(math.radians(angle))) for angle in angles]
    elif kind == "ELLIPSE":
        center_x = _first(entity, 10)
        center_y = _first(entity, 20)
        major_x = _first(entity, 11)
        major_y = _first(entity, 21)
        ratio = _first(entity, 40)
        if None in (center_x, center_y, major_x, major_y, ratio) or ratio is None or ratio <= 0:
            raise ContractError("ELLIPSE is invalid")
        major_len = math.hypot(float(major_x), float(major_y))
        minor_len = major_len * ratio
        # Conservative full-ellipse bounds; safe for partial ellipses too.
        extent_x = math.sqrt(float(major_x) ** 2 + (minor_len * (-float(major_y) / max(major_len, 1e-12))) ** 2)
        extent_y = math.sqrt(float(major_y) ** 2 + (minor_len * (float(major_x) / max(major_len, 1e-12))) ** 2)
        return BBox(float(center_x) - extent_x, float(center_y) - extent_y, float(center_x) + extent_x, float(center_y) + extent_y)
    else:
        points = _paired_points(entity, {10, 11, 12, 13, 14, 15, 16, 17, 18})
    if not points:
        return None
    xs = [point[0] for point in points]
    ys = [point[1] for point in points]
    return BBox(min(xs), min(ys), max(xs), max(ys))


def entities_bbox(entities: Iterable[Entity]) -> BBox:
    result: Optional[BBox] = None
    for entity in entities:
        bbox = entity_bbox(entity)
        if bbox is None:
            continue
        result = bbox if result is None else result.union(bbox)
    if result is None or result.width <= 0 or result.height <= 0:
        raise ContractError("DXF has no non-empty finite geometry bbox")
    return result


def _rotation(rot_deg: int):
    if rot_deg not in {0, 90, 180, 270}:
        raise ContractError("rotation must be 0/90/180/270")

    def rotate(x: float, y: float) -> tuple[float, float]:
        if rot_deg == 0:
            return x, y
        if rot_deg == 90:
            return -y, x
        if rot_deg == 180:
            return -x, -y
        return y, -x

    return rotate


def transform_entity(
    entity: Entity,
    *,
    rotation_deg: int,
    translate_x: float,
    translate_y: float,
    source_width: float,
    source_height: float,
) -> Entity:
    kind = entity_type(entity)
    if kind not in SUPPORTED_MACHINING_TYPES:
        raise ContractError(f"Unsupported production DXF entity: {kind}")
    rotate = _rotation(int(rotation_deg))
    if rotation_deg == 0:
        shift_x, shift_y = 0.0, 0.0
    elif rotation_deg == 90:
        shift_x, shift_y = source_height, 0.0
    elif rotation_deg == 180:
        shift_x, shift_y = source_width, source_height
    else:
        shift_x, shift_y = 0.0, source_width

    point_x_codes = {
        "CIRCLE": {10},
        "ARC": {10},
        "LINE": {10, 11},
        "LWPOLYLINE": {10},
        "POLYLINE": {10},
        "VERTEX": {10},
        "ELLIPSE": {10},
        "SPLINE": {10, 11},
        "POINT": {10},
        "SOLID": {10, 11, 12, 13},
        "TRACE": {10, 11, 12, 13},
    }[kind]
    vector_x_codes = {
        "ELLIPSE": {11},
        "SPLINE": {12, 13},
    }.get(kind, set())
    y_by_x = {10: 20, 11: 21, 12: 22, 13: 23, 14: 24, 15: 25, 16: 26, 17: 27, 18: 28}
    output = list(entity)
    consumed_y: set[int] = set()
    for index, (code, raw_value) in enumerate(list(output)):
        if code not in point_x_codes and code not in vector_x_codes:
            continue
        y_code = y_by_x[code]
        y_index = next((cursor for cursor in range(index + 1, len(output)) if output[cursor][0] == y_code and cursor not in consumed_y), None)
        if y_index is None:
            raise ContractError(f"{kind} coordinate {code} has no matching {y_code}")
        x = _number(raw_value)
        y = _number(output[y_index][1])
        new_x, new_y = rotate(x, y)
        if code in point_x_codes:
            new_x += shift_x + translate_x
            new_y += shift_y + translate_y
        output[index] = (code, format(new_x, ".12g"))
        output[y_index] = (y_code, format(new_y, ".12g"))
        consumed_y.add(y_index)

    if kind == "ARC":
        for index, (code, value) in enumerate(output):
            if code in {50, 51}:
                angle = (_number(value, field="ARC angle") + rotation_deg) % 360.0
                output[index] = (code, format(angle, ".12g"))
    return output


def transform_entities(
    entities: Iterable[Entity],
    *,
    rotation_deg: int,
    translate_x: float,
    translate_y: float,
    source_width: float,
    source_height: float,
) -> list[Entity]:
    return [
        transform_entity(
            entity,
            rotation_deg=rotation_deg,
            translate_x=translate_x,
            translate_y=translate_y,
            source_width=source_width,
            source_height=source_height,
        )
        for entity in entities
    ]


def set_entity_layer(entity: Entity, layer: str) -> Entity:
    if not layer or len(layer) > 80:
        raise ContractError("Invalid DXF layer")
    result = list(entity)
    for index, (code, _value) in enumerate(result):
        if code == 8:
            result[index] = (8, layer)
            return result
    result.insert(1 if result and result[0][0] == 0 else 0, (8, layer))
    return result


def shift_entity_x(entity: Entity, delta_x: float) -> Entity:
    kind = entity_type(entity)
    if kind not in SUPPORTED_MACHINING_TYPES and kind not in {"TEXT"}:
        raise ContractError(f"Unsupported DXF entity during shift: {kind}")
    point_codes = {
        "CIRCLE": {10}, "ARC": {10}, "LINE": {10, 11}, "LWPOLYLINE": {10},
        "POLYLINE": {10}, "VERTEX": {10}, "ELLIPSE": {10}, "SPLINE": {10, 11},
        "POINT": {10}, "SOLID": {10, 11, 12, 13}, "TRACE": {10, 11, 12, 13},
        "TEXT": {10, 11},
    }[kind]
    result: Entity = []
    for code, value in entity:
        if code in point_codes:
            result.append((code, format(_number(value) + delta_x, ".12g")))
        else:
            result.append((code, value))
    return result


def geometry_sha256(entities: Iterable[Entity]) -> str:
    canonical: list[Pair] = []
    for entity in entities:
        canonical.extend(entity)
    return sha256_bytes(pairs_to_text(canonical).encode("utf-8"))

