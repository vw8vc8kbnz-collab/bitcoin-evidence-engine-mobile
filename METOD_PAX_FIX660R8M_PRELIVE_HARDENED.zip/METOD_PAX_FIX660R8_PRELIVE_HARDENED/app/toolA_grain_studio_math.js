(function(root){
  'use strict';
  const BUILD='FIX660_GRAIN_STUDIO_MATH';
  function n(v,d=0){ const x=Number(v); return Number.isFinite(x)?x:d; }
  function qmm(v){ return Math.round(n(v)*1000)/1000; }
  function sameWidthMm(a,b,tol=0.001){ return Math.abs(qmm(a)-qmm(b)) <= Math.max(0,n(tol,0.001)); }
  function distinctWidthsMm(values,tol=0.001){
    const out=[];
    for(const raw of (values||[])){
      const v=qmm(raw);
      if(!(v>0)) continue;
      if(!out.some(x=>sameWidthMm(x,v,tol))) out.push(v);
    }
    return out;
  }
  function summarizePanels(panels){
    const list=(panels||[]).map(p=>({
      widthMm:Math.max(0,n(p&&p.widthMm)),
      heightMm:Math.max(0,n(p&&p.heightMm)),
      ref:String(p&&p.ref||'')
    })).filter(p=>p.widthMm>0&&p.heightMm>0);
    const widths=distinctWidthsMm(list.map(p=>p.widthMm));
    return {
      count:list.length,
      widthsMm:widths,
      widthMm:widths.length===1?widths[0]:0,
      totalHeightMm:list.reduce((s,p)=>s+p.heightMm,0),
      validSameWidth:!!list.length&&widths.length===1
    };
  }
  function computeVerticalGroupFit(cfg){
    const c=cfg||{};
    const cw=Math.max(1,n(c.containerWidth,1));
    const ch=Math.max(1,n(c.containerHeight,1));
    const panels=(c.panels||[]).map(p=>({
      ref:String(p&&p.ref||''),
      widthMm:Math.max(0,n(p&&p.widthMm)),
      heightMm:Math.max(0,n(p&&p.heightMm))
    })).filter(p=>p.widthMm>0&&p.heightMm>0);
    const summary=summarizePanels(panels);
    if(!panels.length || !summary.validSameWidth) return {ok:false,reason:panels.length?'mixed_widths':'empty',summary};

    const padL=Math.max(0,n(c.padLeft,54));
    const padR=Math.max(0,n(c.padRight,78));
    const padT=Math.max(0,n(c.padTop,52));
    const padB=Math.max(0,n(c.padBottom,48));
    const gapPx=Math.max(0,n(c.gapPx,1));
    const availW=Math.max(1,cw-padL-padR);
    const availH=Math.max(1,ch-padT-padB-gapPx*Math.max(0,panels.length-1));
    const groupW=summary.widthMm;
    const groupH=summary.totalHeightMm;
    const scale=Math.max(0,Math.min(availW/groupW,availH/groupH));
    const drawW=groupW*scale;
    const drawH=groupH*scale+gapPx*Math.max(0,panels.length-1);
    const x=padL+(availW-drawW)/2;
    const y=padT+(availH-(groupH*scale))/2;
    let cy=y;
    const placements=[];
    panels.forEach((p,index)=>{
      const h=p.heightMm*scale;
      placements.push({ref:p.ref,index,x,y:cy,w:drawW,h,widthMm:p.widthMm,heightMm:p.heightMm});
      cy+=h+gapPx;
    });
    return {ok:true,scale,x,y,drawW,drawH,placements,summary,bounds:{x,y,w:drawW,h:drawH}};
  }
  root.ToolAGrainStudioMath=Object.freeze({BUILD,qmm,sameWidthMm,distinctWidthsMm,summarizePanels,computeVerticalGroupFit});
})(typeof window!=='undefined'?window:globalThis);
