/* FIX655 — single Overview controller.
   Loaded after toolA.html is parsed. It deliberately owns the customer Overview
   render path so legacy overview handlers cannot leave an empty white modal. */
(function(){
  'use strict';
  window.__TOOLA_OVERVIEW_BUILD = 'FIX655_OVERVIEW_SINGLE_CONTROLLER';

  function byId(id){ return document.getElementById(id); }
  function esc(v){
    return String(v == null ? '' : v)
      .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  }
  function state(){ return (window.state && typeof window.state === 'object') ? window.state : null; }
  function arr(v){ return Array.isArray(v) ? v : []; }
  function text(v){ return String(v == null ? '' : v).trim(); }
  function finite(v, fallback=0){ const n=Number(v); return Number.isFinite(n) ? n : fallback; }

  // Customer-facing label only. Never fall back to material key/article/code.
  function publicMaterialName(batch){
    const m = batch && batch.mat && typeof batch.mat === 'object' ? batch.mat : {};
    const label = text(m.publicName || m.displayName || m.productName || m.decorName || batch?.publicName || batch?.displayName);
    return label || 'Materiaal';
  }
  function materialNameByKey(key){
    const st = state();
    const hit = arr(st?.materialBatches).find(b => String(b?.key ?? '') === String(key ?? ''));
    return publicMaterialName(hit);
  }
  function cartTitle(it){
    return text(it?.customName || it?.name || it?.label) || 'Paneel';
  }
  function extraTitle(p){
    return text(p?.name || p?.label) || 'Overig paneel';
  }
  function edgeText(value){
    const v=text(value).toLowerCase();
    if(!v || v==='none' || v==='0' || v==='false') return 'geen';
    if(v==='all' || v==='1' || v==='true') return 'rondom';
    if(v==='lr') return 'links + rechts';
    if(v==='tb') return 'boven + onder';
    const m=v.match(/^t([01])r([01])b([01])l([01])$/);
    if(m){
      const names=[];
      if(m[1]==='1') names.push('boven');
      if(m[2]==='1') names.push('rechts');
      if(m[3]==='1') names.push('onder');
      if(m[4]==='1') names.push('links');
      return names.length ? names.join(' + ') : 'geen';
    }
    return 'ingesteld';
  }
  function cartMeta(it){
    const w = finite(it?.cmW, NaN), h=finite(it?.cmH, NaN);
    const dims = Number.isFinite(w) && Number.isFinite(h) ? `${w}×${h} cm` : 'Afmetingen ingesteld';
    const top=finite(it?.extTop,0), bot=finite(it?.extBot,0);
    const qty=Math.max(1, Math.round(finite(it?.qty,1)));
    return `${dims} · aantal ${qty} · verlenging +${top} boven / +${bot} onder · kantenband ${edgeText(it?.edge || 'all')}`;
  }
  function extraMeta(p){
    const w=finite(p?.w,NaN), h=finite(p?.h,NaN), qty=Math.max(1, Math.round(finite(p?.qty,1)));
    const dims=Number.isFinite(w)&&Number.isFinite(h) ? `${w}×${h} mm` : 'Afmetingen ingesteld';
    return `${dims} · aantal ${qty} · kantenband ${edgeText(p?.edge || '')}`;
  }
  function buildGroups(st){
    const groups = new Map();
    function get(key){
      const k=String(key ?? '');
      if(!groups.has(k)) groups.set(k,{key:k, cart:[], extra:[]});
      return groups.get(k);
    }
    arr(st?.cart).forEach(it => get(it?.materialKey).cart.push(it));
    arr(st?.extraPanels).forEach(p => get(p?.materialKey).extra.push(p));
    return Array.from(groups.values()).sort((a,b)=>materialNameByKey(a.key).localeCompare(materialNameByKey(b.key),'nl',{sensitivity:'base'}));
  }

  function rowHtml(kind, token, title, meta){
    return `<div class="overviewRow fix655OverviewRow">
      <div class="overviewRowMain">
        <div class="overviewRowTitle">${esc(title)}</div>
        <div class="muted overviewRowMeta">${esc(meta)}</div>
      </div>
      <div class="overviewRowActions">
        <button type="button" class="miniBtn overviewRemoveBtn" data-fix655-remove-kind="${esc(kind)}" data-fix655-remove-token="${esc(token)}">Verwijder</button>
      </div>
    </div>`;
  }
  function sectionHtml(title, rows){
    if(!rows) return '';
    return `<section class="overviewSection fix655OverviewSection"><div class="overviewSectionTitle">${esc(title)}</div><div class="overviewList">${rows}</div></section>`;
  }
  function groupHtml(group){
    const cartRows=group.cart.map((it,idx)=>rowHtml('cart', text(it?.id) || `idx:${idx}`, cartTitle(it), cartMeta(it))).join('');
    const extraRows=group.extra.map((p)=>{
      const st=state();
      const index=arr(st?.extraPanels).indexOf(p);
      return rowHtml('extra', String(index), extraTitle(p), extraMeta(p));
    }).join('');
    return `<div class="overviewGroupCard fix655OverviewGroup">
      <div class="overviewGroupHeader"><div class="overviewGroupTitle">${esc(materialNameByKey(group.key))}</div><div class="fix655OverviewCount">${group.cart.reduce((n,it)=>n+Math.max(1,Math.round(finite(it?.qty,1))),0) + group.extra.reduce((n,p)=>n+Math.max(1,Math.round(finite(p?.qty,1))),0)} onderdeel${(group.cart.reduce((n,it)=>n+Math.max(1,Math.round(finite(it?.qty,1))),0) + group.extra.reduce((n,p)=>n+Math.max(1,Math.round(finite(p?.qty,1))),0))===1?'':'delen'}</div></div>
      ${sectionHtml('METOD deuren & ladefronten',cartRows)}
      ${sectionHtml('Overige panelen',extraRows)}
    </div>`;
  }

  function activeKey(st){
    const wanted=text(st?.ui?.overviewMaterialKey);
    if(wanted) return wanted;
    const groups=buildGroups(st);
    return groups[0]?.key || '';
  }

  function render(){
    const st=state();
    const content=byId('overviewContent');
    const tabs=byId('overviewTabs');
    const hint=byId('overviewTabHint');
    const empty=byId('overviewEmpty');
    const summary=byId('overviewSummary');
    if(!content || !tabs){
      window.__TOOLA_OVERVIEW_RENDER_OK=false;
      return false;
    }
    try{
      if(!st){ throw new Error('Tool A state ontbreekt'); }
      st.ui = st.ui && typeof st.ui==='object' ? st.ui : {};
      if(st.ui.overviewTab !== 'material') st.ui.overviewTab='all';
      const groups=buildGroups(st);
      const total=arr(st.cart).reduce((n,it)=>n+Math.max(1,Math.round(finite(it?.qty,1))),0) + arr(st.extraPanels).reduce((n,p)=>n+Math.max(1,Math.round(finite(p?.qty,1))),0);

      const batchByKey=new Map(arr(st.materialBatches).map(b=>[String(b?.key ?? ''),b]));
      const groupKeys=new Set(groups.map(g=>g.key));
      const availableBatches=arr(st.materialBatches).filter(b=>groupKeys.has(String(b?.key ?? '')));
      const allActive=st.ui.overviewTab!=='material';
      let tabHtml=`<button type="button" class="chip ${allActive?'chipActive':''}" data-fix655-otab="all"><span class="chipTxt">Alle onderdelen</span></button>`;
      for(const b of availableBatches){
        const k=String(b?.key ?? '');
        const isActive=!allActive && String(st.ui.overviewMaterialKey||'')===k;
        tabHtml += `<button type="button" class="chip ${isActive?'chipActive':''}" data-fix655-otab="material" data-fix655-mkey="${esc(k)}"><span class="chipTxt">${esc(publicMaterialName(batchByKey.get(k)))}</span></button>`;
      }
      tabs.innerHTML=`<div class="chipRow fix655OverviewTabs">${tabHtml}</div>`;

      let visibleGroups=groups;
      if(!allActive){
        let key=activeKey(st);
        if(!groupKeys.has(key) && groups.length) key=groups[0].key;
        st.ui.overviewMaterialKey=key;
        visibleGroups=groups.filter(g=>g.key===key);
        if(hint) hint.textContent=`Je bekijkt alleen: ${materialNameByKey(key)}`;
      } else if(hint){
        hint.textContent=total ? `${total} onderdeel${total===1?'':'delen'} · gegroepeerd per materiaal` : 'Nog geen panelen toegevoegd.';
      }

      if(!groups.length){
        content.innerHTML='<div class="fix655OverviewEmpty"><strong>Nog geen panelen toegevoegd.</strong><span>Ga terug naar Panelen om onderdelen toe te voegen.</span></div>';
        if(empty) empty.style.display='none';
      }else{
        content.innerHTML=visibleGroups.map(groupHtml).join('');
        if(empty) empty.style.display='none';
      }
      if(summary){ summary.textContent=''; summary.style.display='none'; }
      window.__TOOLA_OVERVIEW_RENDER_OK=!!content.innerHTML.trim();
      window.__TOOLA_OVERVIEW_RENDERED_AT=Date.now();
      return true;
    }catch(err){
      try{ console.error('FIX655 overview render failed',err); }catch(_){ }
      content.innerHTML='<div class="fix655OverviewError"><strong>Overzicht kon niet worden opgebouwd.</strong><span>Ga één stap terug en probeer opnieuw.</span></div>';
      tabs.innerHTML='<div class="chipRow"><button type="button" class="chip chipActive"><span class="chipTxt">Alle onderdelen</span></button></div>';
      if(hint) hint.textContent='Er ging iets mis tijdens het tonen van het overzicht.';
      if(empty) empty.style.display='none';
      window.__TOOLA_OVERVIEW_RENDER_OK=false;
      return false;
    }
  }

  function show(){
    const ov=byId('overviewOverlay');
    if(!ov) return false;
    const st=state();
    if(st){
      st.ui=st.ui&&typeof st.ui==='object'?st.ui:{};
      st.ui.overviewTab='all';
      try{ window.__overviewReturnStep=String(window.__metod_uiStep || document.body?.dataset?.uiStep || 'customer'); }catch(_){ }
    }
    render();
    ov.style.display='flex';
    ov.style.pointerEvents='auto';
    ov.setAttribute('aria-hidden','false');
    document.body.classList.add('fix655OverviewOpen');
    try{ document.body.style.overflow='hidden'; }catch(_){ }
    // One extra pass after layout/legacy listeners have had a chance to run.
    requestAnimationFrame(()=>{ render(); requestAnimationFrame(render); });
    return true;
  }
  function close(){
    const ov=byId('overviewOverlay');
    if(ov){ ov.style.display='none'; ov.style.pointerEvents='none'; ov.setAttribute('aria-hidden','true'); }
    document.body.classList.remove('fix655OverviewOpen');
    try{ document.body.style.overflow=''; }catch(_){ }
  }
  function goBack(){
    close();
    try{
      const raw=String(window.__overviewReturnStep || window.__metod_uiStep || document.body?.dataset?.uiStep || 'customer');
      const ret=(raw==='material'||raw==='panels'||raw==='grain'||raw==='customer')?raw:'customer';
      if(typeof window.__showWizardStep==='function') window.__showWizardStep(ret);
      else if(typeof window.setStep==='function') window.setStep(ret);
      if(typeof window.renderFooterForStep==='function') window.renderFooterForStep(ret);
    }catch(_){ }
  }
  function calculate(){
    close();
    const b=byId('saveQuoteBtn');
    if(b) b.click();
  }

  function remove(kind, token){
    const st=state(); if(!st) return;
    if(kind==='cart'){
      const before=arr(st.cart);
      st.cart=before.filter((it,idx)=>{
        const t=text(it?.id) || `idx:${idx}`;
        return t!==token;
      });
      try{
        if(st.grain && typeof st.grain==='object'){
          st.grain.groups=[]; st.grain.selectedGroupId=null;
          arr(st.cart).forEach(it=>{it.grainGroupId=null;it.grainOrder=null;});
        }
      }catch(_){ }
    }else if(kind==='extra'){
      const idx=parseInt(token,10);
      if(Number.isInteger(idx) && idx>=0 && idx<arr(st.extraPanels).length) st.extraPanels.splice(idx,1);
    }
    try{ if(typeof window.renderCart==='function') window.renderCart(); }catch(_){ }
    try{ if(typeof window.renderExtraPanels==='function') window.renderExtraPanels(); }catch(_){ }
    try{ if(typeof window.drawExtraPreview==='function') window.drawExtraPreview(); }catch(_){ }
    try{ if(typeof window.scheduleDraftSave==='function') window.scheduleDraftSave(); }catch(_){ }
    render();
  }

  // Make every legacy overview call converge on this exact renderer.
  window.__FIX655_RENDER_OVERVIEW__=render;
  window.renderOverviewSafe=render;
  window.openOverviewOverlay=show;
  window.closeOverviewOverlay=close;

  // Capture before target-level legacy handlers. This removes competing overview routes
  // without deleting the old code that other historical flows may still depend on.
  document.addEventListener('click',function(ev){
    const target=ev.target && ev.target.closest ? ev.target.closest('#overviewBtn,#wizardOverviewBtn,#priceBarBtnOverview,#overviewCloseBtn,#overviewBackBtn,#overviewNextBtn,[data-fix655-otab],[data-fix655-remove-kind]') : null;
    if(!target) return;
    if(target.matches('#overviewBtn,#wizardOverviewBtn,#priceBarBtnOverview')){
      ev.preventDefault(); ev.stopImmediatePropagation(); show(); return;
    }
    if(target.id==='overviewCloseBtn' || target.id==='overviewBackBtn'){
      ev.preventDefault(); ev.stopImmediatePropagation(); goBack(); return;
    }
    if(target.id==='overviewNextBtn'){
      ev.preventDefault(); ev.stopImmediatePropagation(); calculate(); return;
    }
    if(target.hasAttribute('data-fix655-otab')){
      ev.preventDefault(); ev.stopImmediatePropagation();
      const st=state(); if(!st) return;
      st.ui=st.ui&&typeof st.ui==='object'?st.ui:{};
      st.ui.overviewTab=target.getAttribute('data-fix655-otab')==='material'?'material':'all';
      const mk=target.getAttribute('data-fix655-mkey'); if(mk) st.ui.overviewMaterialKey=mk;
      render(); return;
    }
    if(target.hasAttribute('data-fix655-remove-kind')){
      ev.preventDefault(); ev.stopImmediatePropagation();
      remove(target.getAttribute('data-fix655-remove-kind'),target.getAttribute('data-fix655-remove-token')||'');
    }
  },true);

  function installObserver(){
    const ov=byId('overviewOverlay'); if(!ov || ov.__fix655Observed) return;
    ov.__fix655Observed=true;
    let wasVisible=false;
    const check=()=>{
      const visible=getComputedStyle(ov).display!=='none' && ov.getClientRects().length>0;
      if(visible && !wasVisible){ requestAnimationFrame(()=>{render();requestAnimationFrame(render);}); }
      wasVisible=visible;
    };
    try{ new MutationObserver(check).observe(ov,{attributes:true,attributeFilter:['style','class','aria-hidden']}); }catch(_){ }
    check();
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',installObserver,{once:true}); else installObserver();

  const css=document.createElement('style');
  css.id='fix655OverviewCss';
  css.textContent=`
    #overviewOverlay .modalHead{display:flex!important;align-items:flex-start!important;justify-content:space-between!important;gap:18px!important;}
    #overviewOverlay #overviewCloseBtn{flex:0 0 auto!important;margin:0!important;min-width:42px!important;width:42px!important;height:42px!important;display:grid!important;place-items:center!important;}
    #overviewOverlay #overviewTabs{min-height:38px!important;}
    #overviewOverlay .fix655OverviewTabs{display:flex;gap:8px;flex-wrap:wrap;}
    #overviewOverlay .fix655OverviewCount{font-size:12px;font-weight:750;color:#6b7785;white-space:nowrap;}
    #overviewOverlay .fix655OverviewEmpty,#overviewOverlay .fix655OverviewError{min-height:140px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:7px;padding:28px;text-align:center;border:1px dashed rgba(84,108,136,.22);border-radius:18px;background:rgba(255,255,255,.74);color:#26384a;}
    #overviewOverlay .fix655OverviewEmpty span,#overviewOverlay .fix655OverviewError span{font-size:13px;color:#6a7886;}
    #overviewOverlay .fix655OverviewError{border-color:rgba(170,85,70,.24);background:rgba(255,248,246,.86);}
    @media(max-width:700px){#overviewOverlay .modalHead{padding-right:14px!important;}#overviewOverlay .fix655OverviewCount{display:none;}}
  `;
  document.head.appendChild(css);
})();
