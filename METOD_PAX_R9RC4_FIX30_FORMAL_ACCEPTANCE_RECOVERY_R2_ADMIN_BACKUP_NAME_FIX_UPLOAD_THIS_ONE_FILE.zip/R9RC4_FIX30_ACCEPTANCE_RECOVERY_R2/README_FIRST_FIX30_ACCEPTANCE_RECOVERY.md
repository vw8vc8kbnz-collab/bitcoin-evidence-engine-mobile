# FIX30 formele acceptatie- en recoveryronde R2

R2 corrigeert uitsluitend de back-upselectie van het eerdere acceptatiepakket.
De selectie volgt nu exact de bestandsnaam die Admin werkelijk aanmaakt,
inclusief de zescijferige hexadecimale nonce. Tool A en de bevroren FIX30-
releasebytes zijn niet gewijzigd.

Dit pakket wijzigt geen FIX30-broncode. Het bevat exact de reeds geaccepteerde,
bevroren FIX30-upload-ZIP en voert uitsluitend operationele bewijscontroles uit.

De runner:

1. verifieert alle pakket- en artifactchecksums;
2. voert de volledige standalone preflight van FIX30 opnieuw uit;
3. legt het actieve release-, state-, service-, health- en assetcontract vast;
4. herdeployt exact dezelfde FIX30-release via de bestaande atomische updater;
5. vergelijkt kritieke statebytes, catalogus/admincounts en publieke assets;
6. herstelt de nieuwste echte systeembackup naar een nieuwe tijdelijke map;
7. bewijst daarna opnieuw dat live state en services ongewijzigd/gezond zijn;
8. verwijdert alleen de geïsoleerde tijdelijke restore en verzegelt een
   privacy-veilige evidence-ZIP onder `/home/ubuntu`.

De runner overschrijft nooit `/var/lib/metod-pax` met een backup en neemt geen
klantrecords, credentials, requestinhoud of private bestandsnamen op in het
rapport. Bij iedere afwijking stopt hij fail-closed.

## Uitvoering

Upload uitsluitend de buitenste acceptatie-ZIP naar de hoofdmap van de GitHub-
repository en plak daarna de enige regel uit het meegeleverde Termiusbestand.
De regel start de proef in een eigen tmux-sessie. Daardoor blijft de volledige
run doorgaan als de mobiele Termiusverbinding tijdelijk wegvalt. De sessie
blijft na afloop open zodat de eindmarkers en het log gecontroleerd kunnen
worden.

PASS eindigt exact met:

```text
FIX30_ACCEPTANCE_RECOVERY_R2_PASS
```

Ook bij PASS blijft `PRODUCTIE_GO=NEE_NOG_EXTERNE_GATES`. De onafhankelijke
Chromium/WebKit-oracle, securityreview, werkplaats/CAM-signoff, clean-server-
installatie en formele productie-goedkeuring blijven afzonderlijke stappen.
