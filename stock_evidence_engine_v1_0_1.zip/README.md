# Stock Evidence Engine v1.0.1

Backtest-first stock research lab. This version deliberately avoids FastAPI/Uvicorn for the dashboard to prevent module/venv/service issues on VPS. Dashboard uses Python stdlib HTTP server.

Port: 8798
Service: stock-evidence-dashboard.service

Install:
```bash
cd /home/ubuntu
rm -rf stock_evidence_engine
unzip -o stock_evidence_engine_v1_0_1.zip -d stock_evidence_engine
cd stock_evidence_engine
chmod +x install.sh run_backtest.sh
./install.sh
./run_backtest.sh "BB,PLTR,IONQ,SOUN,NVDA,AMD,TSLA" "2y"
```
