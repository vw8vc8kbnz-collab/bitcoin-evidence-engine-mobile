#!/usr/bin/env bash
set -euo pipefail
cd /home/ubuntu/stock_evidence_engine
TICKERS="${1:-BB,PLTR,IONQ,SOUN,NVDA,AMD,TSLA}"
PERIOD="${2:-2y}"
venv/bin/python -m stock_evidence_engine.cli --tickers "$TICKERS" --period "$PERIOD"
