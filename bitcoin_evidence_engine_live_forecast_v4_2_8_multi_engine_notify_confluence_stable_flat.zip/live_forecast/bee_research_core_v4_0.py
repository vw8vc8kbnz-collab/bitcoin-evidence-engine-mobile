from __future__ import annotations

VERSION = "v4.2.8_multi_engine_notify_confluence"

MODEL_STATS = {
    "cycle_reversal": {
        "30d": {"historical_winrate": 0.65, "oos_winrate": 0.61, "sample_size": "research_core_approx", "profit_factor": None, "ev": None},
        "90d": {"historical_winrate": 0.68, "oos_winrate": 0.62, "sample_size": "research_core_approx", "profit_factor": None, "ev": None},
    },
    "elite_reversal": {
        "30d": {"historical_winrate": 0.73, "oos_winrate": 0.66, "sample_size": "research_core_approx", "profit_factor": None, "ev": None},
        "90d": {"historical_winrate": 0.95, "oos_winrate": 0.90, "sample_size": "elite_overlap_adjusted_approx", "profit_factor": None, "ev": None},
    },
    "reversal": {
        "30d": {"historical_winrate": 0.62, "oos_winrate": 0.58, "sample_size": "research_core_approx", "profit_factor": None, "ev": None},
        "90d": {"historical_winrate": 0.70, "oos_winrate": 0.64, "sample_size": "research_core_approx", "profit_factor": None, "ev": None},
    },
}

PRIMARY_HORIZON = {
    "cycle_reversal": "30d",
    "elite_reversal": "90d",
    "reversal": "90d",
}

ENGINE_PRIORITY = {
    "elite_reversal": 3,
    "cycle_reversal": 2,
    "reversal": 1,
}

def _f(row, key, default=0.0):
    try:
        v = row.get(key, default)
        if v is None: return default
        return float(v)
    except Exception:
        return default

def _base_result(row):
    close = _f(row, "close", _f(row, "price", 0.0))
    return {
        "action":"NO_TRADE", "decision":"NO_TRADE", "specialist":"none", "tier":"none", "horizon":"none", "prob":0.0,
        "entry_price": close, "take_profit": None, "stop_loss": None,
        "exit_policy":"none", "levels_label":"none", "reason":"NO_ENGINE_TRIGGER", "priority":0,
        "diagnostics": {}, "notify": False,
        "all_applicable": [], "all_applicable_models": "", "confluence_score": 0,
        "confluence_label": "NO_SIGNAL", "consensus_direction": "NONE"
    }

def cycle_debug(row):
    fg = _f(row, "fear_greed", 50)
    mom4 = _f(row, "mom_4h", _f(row, "return_4", 0))
    dd = _f(row, "drawdown_from_ath", 0)
    risk_on = bool(row.get("risk_on", False))
    gate = (fg < 25 and mom4 > 0)
    fear_bonus = max(0.0, min(1.0, (25.0 - fg) / 25.0)) * 0.12
    dd_bonus = 0.04 if dd < -30 else 0.0
    risk_bonus = 0.02 if risk_on else 0.0
    prob = min(0.88, 0.62 + fear_bonus + dd_bonus + risk_bonus)
    return {"applies": gate, "prob": round(prob, 6), "reason": f"CYCLE_GATE_{'OK' if gate else 'FAIL'} fear_greed={fg:.2f}<25 mom_4h={mom4:.6f}>0; CORE_PROB=0.62+fear_bonus({fear_bonus:.4f})+dd_bonus({dd_bonus:.2f})+risk_bonus({risk_bonus:.2f})"}

def elite_reversal_debug(row):
    fg = _f(row, "fear_greed", 50); dd = _f(row,"drawdown_from_ath",0); rsi = _f(row,"rsi_14",50); mom4=_f(row,"mom_4h", _f(row,"return_4",0))
    gate = (fg <= 18 and dd <= -30 and rsi <= 38 and mom4 > -0.02)
    prob = 0.78 + max(0, (18-fg)/18)*0.08 + (0.04 if dd <= -40 else 0) + (0.03 if rsi <= 32 else 0)
    prob = min(0.95, prob)
    return {"applies": gate, "prob": round(prob,6), "reason": f"ELITE_GATE_{'OK' if gate else 'FAIL'} fg={fg:.2f}<=18 dd={dd:.2f}<=-30 rsi={rsi:.2f}<=38 mom4={mom4:.6f}>-0.02"}

def reversal_debug(row):
    fg = _f(row,"fear_greed",50); dd=_f(row,"drawdown_from_ath",0); rsi=_f(row,"rsi_14",50); r24=_f(row,"return_24",0)
    gate = (fg < 30 and dd < -20 and rsi < 50 and r24 > -0.03)
    prob = 0.60 + max(0, (30-fg)/30)*0.08 + (0.03 if dd < -35 else 0) + (0.02 if r24 > 0 else 0)
    prob = min(0.82, prob)
    return {"applies": gate, "prob": round(prob,6), "reason": f"REVERSAL_GATE_{'OK' if gate else 'FAIL'} fg={fg:.2f}<30 dd={dd:.2f}<-20 rsi={rsi:.2f}<50 return_24={r24:.6f}>-0.03"}

def _levels(entry, horizon="30d"):
    # Indicative monitor levels only; not fixed validated exit policy.
    # For now levels are deliberately the same baseline monitor bands. The horizon stays per engine for evaluation.
    return round(entry*1.18,2), round(entry*0.90,2)

def _tier(prob):
    if prob >= 0.78: return "elite"
    if prob >= 0.66: return "strong"
    if prob >= 0.62: return "push"
    return "watch"

def _pct(v):
    if v is None: return None
    try: return round(float(v)*100, 1)
    except Exception: return None

def _engine_payload(name, dbg, entry):
    horizon = PRIMARY_HORIZON.get(name, "30d")
    tp, sl = _levels(entry, horizon)
    st = MODEL_STATS.get(name, {}).get(horizon, {})
    return {
        "action":"LONG", "decision":"LONG", "specialist": name,
        "applies": bool(dbg["applies"]), "prob": dbg["prob"], "tier": _tier(dbg["prob"]),
        "reason": dbg["reason"], "priority": ENGINE_PRIORITY.get(name, 0), "horizon": horizon,
        "entry_price": round(entry, 2), "take_profit": tp, "stop_loss": sl,
        "exit_policy":"wide_trailing_paper", "levels_label":"indicative_monitoring_levels_not_fixed_exit",
        "historical_winrate_pct": _pct(st.get("historical_winrate")),
        "oos_winrate_pct": _pct(st.get("oos_winrate")),
        "sample_size": st.get("sample_size", "n/a"),
        "profit_factor": st.get("profit_factor"), "ev": st.get("ev"),
    }

def _confluence_label(n):
    if n >= 3: return "EXTREME_CONFLUENCE"
    if n == 2: return "HIGH_CONFLUENCE"
    if n == 1: return "SINGLE_ENGINE"
    return "NO_SIGNAL"

def decide_all(row):
    entry = _f(row,"close", _f(row,"price",0.0))
    raw_outputs=[]
    debug_fns = [
        ("cycle_reversal", cycle_debug),
        ("elite_reversal", elite_reversal_debug),
        ("reversal", reversal_debug),
    ]
    for name, dbgfn in debug_fns:
        dbg = dbgfn(row)
        payload = _engine_payload(name, dbg, entry)
        raw_outputs.append(payload)
    active_sorted = sorted([o for o in raw_outputs if o["applies"]], key=lambda x:(-x["priority"], -x["prob"]))
    if not active_sorted:
        res = _base_result(row); res["diagnostics"]={"engine_outputs":raw_outputs}; return res
    best = dict(active_sorted[0])
    all_models = ",".join([o["specialist"] for o in active_sorted])
    res = dict(best)
    res.update({
        "notify": True,
        "all_applicable": active_sorted,
        "all_applicable_models": all_models,
        "confluence_score": len(active_sorted),
        "confluence_label": _confluence_label(len(active_sorted)),
        "consensus_direction": "LONG", # Current enabled research engines are LONG-only reversal specialists.
        "diagnostics": {"engine_outputs": raw_outputs},
    })
    return res
