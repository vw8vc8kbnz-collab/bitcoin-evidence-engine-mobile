RoomBudget v1.0.10 local assets + devmode fix
- bundled local visual assets
- dev mode accessible at /dev/assets
- customer prompt retained
