import sqlite3
from contextlib import contextmanager
from .config import DB_PATH

SCHEMA = """
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  plan TEXT NOT NULL DEFAULT 'free',
  credits INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS projects (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'design',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS rooms (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL,
  room_type TEXT NOT NULL,
  style TEXT NOT NULL,
  budget_class TEXT NOT NULL,
  user_prompt TEXT,
  original_image_path TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(project_id) REFERENCES projects(id)
);
CREATE TABLE IF NOT EXISTS render_jobs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  room_id INTEGER NOT NULL,
  status TEXT NOT NULL,
  provider TEXT NOT NULL,
  model TEXT NOT NULL,
  cost_estimate REAL NOT NULL DEFAULT 0,
  input_image_path TEXT,
  output_image_path TEXT,
  error_message TEXT,
  idempotency_key TEXT UNIQUE,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  completed_at TEXT,
  FOREIGN KEY(user_id) REFERENCES users(id),
  FOREIGN KEY(room_id) REFERENCES rooms(id)
);
CREATE TABLE IF NOT EXISTS budgets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  room_id INTEGER NOT NULL,
  total_min REAL NOT NULL,
  total_max REAL NOT NULL,
  materials_min REAL NOT NULL,
  materials_max REAL NOT NULL,
  labor_min REAL NOT NULL,
  labor_max REAL NOT NULL,
  confidence TEXT NOT NULL DEFAULT 'indicatief',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(room_id) REFERENCES rooms(id)
);
CREATE TABLE IF NOT EXISTS budget_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  budget_id INTEGER NOT NULL,
  category TEXT NOT NULL,
  title TEXT NOT NULL,
  quantity REAL NOT NULL,
  unit TEXT NOT NULL,
  min_price REAL NOT NULL,
  max_price REAL NOT NULL,
  diy_possible INTEGER NOT NULL DEFAULT 0,
  FOREIGN KEY(budget_id) REFERENCES budgets(id)
);
CREATE TABLE IF NOT EXISTS plan_steps (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  room_id INTEGER NOT NULL,
  order_index INTEGER NOT NULL,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  duration_days INTEGER NOT NULL DEFAULT 1,
  dependency_notes TEXT,
  FOREIGN KEY(room_id) REFERENCES rooms(id)
);
CREATE TABLE IF NOT EXISTS ai_safety_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  event_type TEXT NOT NULL,
  details TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS visual_assets (
  asset_key TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  category TEXT NOT NULL,
  url TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
"""

def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

@contextmanager
def db():
    conn = get_conn()
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()

DEFAULT_VISUAL_ASSETS = [
    ("hero.home", "Home hero foto", "hero", "/static/assets/photos/hero-home.jpg"),
    ("room.woonkamer", "Woonkamer tegel", "room", "/static/assets/photos/room-living.jpg"),
    ("room.keuken", "Keuken tegel", "room", "/static/assets/photos/room-kitchen.jpg"),
    ("room.badkamer", "Badkamer tegel", "room", "/static/assets/photos/room-bathroom.jpg"),
    ("room.slaapkamer", "Slaapkamer tegel", "room", "/static/assets/photos/room-bedroom.jpg"),
    ("room.eetkamer", "Eetkamer tegel", "room", "/static/assets/photos/room-dining.jpg"),
    ("room.kantoor", "Home office tegel", "room", "/static/assets/photos/room-office.jpg"),
    ("style.japandi", "Japandi stijl", "style", "/static/assets/photos/style-japandi.jpg"),
    ("style.modern_warm", "Modern warm stijl", "style", "/static/assets/photos/style-modern.jpg"),
    ("style.hotel_chic", "Hotel Chic stijl", "style", "/static/assets/photos/style-hotel.jpg"),
    ("style.luxe_minimal", "Minimal stijl", "style", "/static/assets/photos/style-minimal.jpg"),
    ("style.scandinavisch", "Scandinavisch stijl", "style", "/static/assets/photos/style-scandi.jpg"),
    ("style.luxury", "Luxury stijl", "style", "/static/assets/photos/style-luxury.jpg"),
]
def init_db():
    with db() as conn:
        conn.executescript(SCHEMA)
        # Lightweight migrations for existing VPS databases.
        cols = [r[1] for r in conn.execute("PRAGMA table_info(rooms)").fetchall()]
        if "user_prompt" not in cols:
            conn.execute("ALTER TABLE rooms ADD COLUMN user_prompt TEXT")
        for key, title, category, url in DEFAULT_VISUAL_ASSETS:
            existing = conn.execute("SELECT url FROM visual_assets WHERE asset_key=?", (key,)).fetchone()
            if not existing:
                conn.execute("INSERT INTO visual_assets(asset_key,title,category,url) VALUES(?,?,?,?)", (key,title,category,url))
            else:
                old_url = (existing["url"] or "").strip()
                # v1.0.10: force bundled local assets when the previous value was an
                # external/empty default, but preserve user-uploaded /media assets.
                if not old_url or old_url.startswith("http://") or old_url.startswith("https://") or old_url.startswith("/static/assets/photos/"):
                    conn.execute("UPDATE visual_assets SET title=?, category=?, url=?, updated_at=CURRENT_TIMESTAMP WHERE asset_key=?", (title, category, url, key))
