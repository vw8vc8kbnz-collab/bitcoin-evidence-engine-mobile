# v8.4.2 Finance Hardening + Partner Wallet

- Partner onderbalk aangepast: Orders uit de hoofdnavigatie, Wallet als vaste zakelijke geld-tab.
- Orders blijven bereikbaar via Dashboard/actieblokken en directe orderlinks.
- Wallet/Financiën visueel uitgebreid als echte zakelijke geldpagina: beschikbaar, escrow, gereserveerd campagnebudget, 30d uitbetalingen, commissie, transacties en finance safety.
- Claude audit verwerkt: order-escrow funding bij ordercreatie, commissie in centen, payout uit leespad gehaald, campaign reserve gebruikt `reservedCents`, verlopen campagnes worden lazy gesweept.
- Ledger uitgebreid met order_escrow, order_commission, order_delivery en order_refund voor reconcilieerbare geldstromen.
- Finance audit uitgebreid met nul-som en escrow-per-order invariant.
- AI-guard verplaatst naar datalaag: `createPromotionCampaign` weigert AI-geïnitieerde budgetreservering.

# v8.4.2 Safety & Finance Audit Hardening

- Finance safety mode toegevoegd: live geldverplaatsing blijft geblokkeerd tot PAYMENT_LIVE_ENABLED=true.
- Ledger integrity checker toegevoegd aan beheer en payment-status API.
- Payment status API toont provider, safety, audit en architectuur.
- Partner Financiën/Promoten tonen duidelijke Finance Preview waarschuwing.
- AI auto-execute voor promotiebudget expliciet geblokkeerd in backend.
- Campaign spend-engine voorbereid met append-only ledgerboekingen.
- Documentatie toegevoegd: docs/SECURITY_FINANCE_HARDENING.md.
