import Link from "next/link";
import { read } from "@/lib/store";
import { getUser } from "@/lib/auth";
import { sweepOrders, getPartnerWallet } from "@/lib/data";
import { eur } from "@/lib/types";
import { financeSafetyMode, getFinanceSnapshot, getPaymentProviderStatus, PAYMENT_ARCHITECTURE } from "@/lib/payments";
import { Mark } from "@/components/icons";
import { Empty } from "@/components/Empty";

export const dynamic = "force-dynamic";

const fmt = (iso: string) => new Date(iso).toLocaleDateString("nl-NL", { day: "numeric", month: "short" });

export default async function Geld() {
  await sweepOrders();
  const db = await read();
  const user = await getUser();
  const orders = db.orders.filter(o => o.sellerSlug === user?.partnerSlug).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  const escrow = orders.filter(o => !["paid_out", "cancelled"].includes(o.status));
  const paid = orders.filter(o => o.status === "paid_out");
  const d30 = Date.now() - 30 * 864e5;
  const wallet = user?.partnerSlug ? await getPartnerWallet(user.partnerSlug) : null;
  const finance = user?.partnerSlug ? await getFinanceSnapshot(user.partnerSlug) : null;
  const provider = getPaymentProviderStatus();
  const safety = financeSafetyMode();
  return (
    <main className="page partnerScreen moneyScreen financeEngineScreen">
      <header className="hd">
        <Link href="/partner" className="lock" style={{ color: "#fff" }}><Mark glow />Financiën</Link>
        <span className="sp" />
        <span className="mini" style={{ color: "#8B96A0" }}>{provider.label.toUpperCase()}</span>
      </header>

      <section className="financeProviderHero">
        <span className="eyebrow">PAYMENT ENGINE · PROVIDER-ONAFHANKELIJK</span>
        <h1>Je geldstromen blijven veilig bij de betaalprovider.</h1>
        <p>Outrun toont Wallet, escrow, campagnes en uitbetalingen als één financiële laag. Nu staat Stripe Connect klaar; later kunnen Mollie, Adyen of Mangopay als adapter worden toegevoegd zonder de app te verbouwen.</p>
        <div className="financeSafetyBanner"><b>{safety.label}</b><span>{safety.message}</span></div>
        <div className="financeProviderGrid">
          <span><b>{provider.label}</b><small>{provider.configured ? "geconfigureerd" : "klaar voor configuratie"}</small></span>
          <span><b>{finance?.mode === "live" ? "Live" : "Test"}</b><small>provider modus</small></span>
          <span><b>{finance?.payoutEnabled ? "Actief" : "Nog niet actief"}</b><small>bankuitbetalingen</small></span>
        </div>
      </section>

      <section className="moneyHero financeHero"><div className="big"><label>BESCHIKBAAR SALDO</label>
        <b>{eur((wallet?.summary.availableCents ?? 0) / 100)}</b><small>Beschikbaar voor AI-campagnes of uitbetaling via de betaalprovider.</small></div>
      <div className="dkchips moneyStats">
        <span className="dkc"><label>IN ESCROW</label><b>{eur(escrow.reduce((s, o) => s + o.sellerNet, 0))}</b></span>
        <span className="dkc"><label>GERESERVEERD</label><b>{eur((wallet?.summary.reservedCents ?? 0) / 100)}</b></span>
        <span className="dkc"><label>UITBETAALD 30D</label><b>{eur(paid.filter(o => +new Date(o.createdAt) > d30).reduce((s, o) => s + o.sellerNet, 0))}</b></span>
        <span className="dkc"><label>COMMISSIE 30D</label><b>{eur(paid.filter(o => +new Date(o.createdAt) > d30).reduce((s, o) => s + o.commission, 0))}</b></span>
      </div></section>

      <section className="financeAiAdvice">
        <span className="eyebrow">AI FINANCIEEL ADVIES</span>
        <h2>AI mag adviseren, maar nooit zelfstandig geld verplaatsen.</h2>
        <p>{(wallet?.summary.availableCents ?? 0) > 0 ? `Je hebt ${eur((wallet?.summary.availableCents ?? 0) / 100)} beschikbaar. Gebruik dit voor promotie als de AI-marketeer een positieve ROI verwacht, of vraag uitbetaling aan zodra provider-uitbetalingen actief zijn.` : "Zodra orders zijn vrijgegeven, verschijnt hier beschikbaar saldo. Daarna kan AI campagnes voorstellen of een uitbetaling adviseren."}</p>
        <div className="financeActionRow"><Link href="/partner/promoten">Promoot producten</Link><button disabled>{safety.liveUnlocked ? "Uitbetaling aanvragen" : "Uitbetaling geblokkeerd"}</button></div>
      </section>

      {orders.length === 0 && <Empty title="Nog geen geldstromen" text="Uitbetalingen, escrow en campagnekosten verschijnen hier per order/campagne, netto na 10% commissie." />}
      {orders.length > 0 && <div className="dsec"><h2>Per order</h2><span>NA 10% COMMISSIE</span></div>}
      {orders.map(o => (
        <div key={o.id} className="pay premiumPay">
          <b>{o.itemTitle} · {o.id}{o.partnerRef ? ` · ${o.partnerRef}` : ""}<small>{fmt(o.createdAt)} · {o.status.replaceAll("_", " ").toUpperCase()}</small></b>
          <span className={`flag ${o.status === "paid_out" ? "ok3" : "hot"}`}>{o.status === "paid_out" ? "BESCHIKBAAR" : "IN ESCROW"}</span>
          <span className="amt2">{eur(o.sellerNet)}</span>
        </div>
      ))}
      <div className="dsec"><h2>Financieel grootboek</h2><span>APPEND-ONLY</span></div>
      {(wallet?.ledger ?? []).slice(0, 8).map(tx => <div key={tx.id} className="pay premiumPay"><b>{tx.note ?? tx.type}<small>{new Date(tx.at).toLocaleString("nl-NL")} · {tx.type}</small></b><span className={`flag ${tx.creditAccount.includes(":wallet") ? "ok3" : "hot"}`}>{tx.creditAccount.includes(":wallet") ? "+" : "-"}</span><span className="amt2">{eur(tx.amountCents / 100)}</span></div>)}
      <section className="financeArchitectureNote">
        <b>Architectuur</b>
        <span>{PAYMENT_ARCHITECTURE.layers.join(" → ")}</span>
        <small>{provider.note}</small>
      </section>
    </main>
  );
}
