import Link from "next/link";
import { eur, unreadCount } from "@/lib/data";
import { getUser } from "@/lib/auth";
import { Img } from "@/components/Img";
import { Score } from "@/components/icons";
import { BrandLockup } from "@/components/Brand";
import { Empty } from "@/components/Empty";
import { DiscoveryCarousel } from "@/components/DiscoveryCarousel";
import { buildHomeBrain, dealQualityScore } from "@/lib/ai/brain";
import { read } from "@/lib/store";
import type { Listing, Seller } from "@/lib/types";

export const dynamic = "force-dynamic";
const disc = (p: number, n: number) => Math.round((1 - p / n) * 100);

function takeUnique(items: Listing[], used: Set<string>, count: number) {
  const out: Listing[] = [];
  for (const item of items) {
    if (used.has(item.id)) continue;
    used.add(item.id);
    out.push(item);
    if (out.length >= count) break;
  }
  return out;
}

function shortName(title: string) {
  return title.length > 32 ? `${title.slice(0, 31)}…` : title;
}

function CompactDealCard({ listing, tag, score }: { listing: Listing; tag?: string; score?: number }) {
  return (
    <Link href={`/listing/${listing.id}`} className="v2CompactDeal">
      <div className="v2CompactMedia"><Img src={listing.photos[0]} fallback={listing.fallback} />{score !== undefined && <Score v={score} />}</div>
      {tag && <span className="v2MiniTag">{tag}</span>}
      <b>{shortName(listing.title)}</b>
      <span><i>{eur(listing.price)}</i><em>−{disc(listing.price, listing.newPrice)}%</em></span>
    </Link>
  );
}

function FeatureDealCard({ listing, seller, score }: { listing: Listing; seller?: Seller; score: number }) {
  return (
    <Link href={`/listing/${listing.id}`} className="v2FeatureDeal aiBrainFeatureDeal">
      <Img src={listing.photos[0]} fallback={listing.fallback} />
      <span className="v2FeatureCopy">
        <small>AI PICK · MATCH {score}/100</small>
        <b>{listing.title}</b>
        <em>{seller?.name ?? listing.sellerSlug} · {listing.conditionScore}/10 · {listing.pickupCity}</em>
      </span>
      <span className="v2FeaturePrice">{eur(listing.price)}</span>
    </Link>
  );
}

function Rail({ title, href, items, tag }:{ title: string; href?: string; items: Listing[]; tag?: string }) {
  if (!items.length) return null;
  return <section className="v2RailBlock">
    <div className="v2SectionHead"><h2>{title}</h2>{href && <Link href={href}>BEKIJK →</Link>}</div>
    <div className="v2Rail">
      {items.map(l => <CompactDealCard key={l.id} listing={l} tag={tag} score={l.confidence} />)}
    </div>
  </section>;
}

export default async function Home() {
  const user = await getUser();
  const unread = user ? await unreadCount(user.id) : 0;
  const db = await read();
  const home = await buildHomeBrain(user);
  const sellers = db.sellers;
  const used = new Set<string>();

  const hero = home.hero[0] ?? home.aiPicks[0] ?? home.newListings[0];
  const dealOfDay = takeUnique([home.dealOfDay, ...home.aiPicks].filter(Boolean) as Listing[], used, 1)[0];
  const aiPicks = takeUnique(home.aiPicks, used, 5);
  const spotlightListing = takeUnique([home.partnerSpotlight, ...home.promoted].filter(Boolean) as Listing[], used, 1)[0];
  const newListings = takeUnique(home.newListings, used, 6);
  const trending = takeUnique(home.trending, used, 6);
  const lastChance = takeUnique(home.lastChance, used, 6);

  const spotlightSeller = spotlightListing ? sellers.find(s => s.slug === spotlightListing.sellerSlug) : undefined;
  const dealSeller = dealOfDay ? sellers.find(s => s.slug === dealOfDay.sellerSlug) : undefined;
  const collections = [
    { title: "Beste prijsbewijs", text: "Deals met hoge AI-score", href: "/zoeken?sort=score" },
    { title: "Onder €250", text: "Scherpe deals met lage instap", href: "/zoeken?max=250" },
    { title: "Showroommodellen", text: "Netter geprijsde voorraad", href: "/zoeken?q=showroom" },
    { title: "Laatste stuks", text: "Voorraad die snel weg kan zijn", href: "/zoeken?q=laatste" },
  ];

  return (
    <main className="page homeAIPage homeV2Page">
      <header className="hd homeAIHeader v2Header">
        <BrandLockup />
        <span className="sp" />
        <Link href="/meldingen" className="icbtn" aria-label="Alerts">
          <svg viewBox="0 0 24 24"><path d="M6 10a6 6 0 1112 0c0 4 1.5 5.5 1.5 5.5h-15S6 14 6 10z" /><path d="M10.5 19a1.8 1.8 0 003 0" /></svg>
          {unread > 0 && <span className="bub">{unread > 9 ? "9+" : unread}</span>}
        </Link>
      </header>

      {!hero && <Empty title="Nog geen live deals" text="Outrun IQ staat klaar. Zodra partners hun voorraad publiceren, bouwt de AI hier je persoonlijke etalage." cta="Word partner" href="/word-partner" />}

      {hero && <>

        <section className="publicMarketplaceHero premiumMobileHero">
          <div className="premiumHeroCopy">
            <h1>Outletdeals van betrouwbare bedrijven.</h1>
            <p>Nieuwe deals, scherpe prijzen en AI-prijsinzichten. Zonder account.</p>
            <div className="heroActionCards">
              <Link href="/zoeken" className="heroActionCard">
                <span className="heroActionIcon">
                  <svg viewBox="0 0 24 24"><path d="M5 12.5l7.5-7.5 6.5 6.5-7.5 7.5H5v-6.5z"/><path d="M9 9h.01"/></svg>
                </span>
                <b>Deals</b>
                <small>Nieuwe deals</small>
              </Link>
              <Link href="/vinder" className="heroActionCard">
                <span className="heroActionIcon">
                  <svg viewBox="0 0 24 24"><path d="M11 19a8 8 0 1 0-7.4-5"/><path d="M5 21l4-4"/><path d="M15 3l.7 2.2L18 6l-2.3.8L15 9l-.7-2.2L12 6l2.3-.8L15 3z"/></svg>
                </span>
                <b>AI zoeken</b>
                <small>Vind jouw product</small>
              </Link>
              <Link href="/word-partner" className="heroActionCard">
                <span className="heroActionIcon">
                  <svg viewBox="0 0 24 24"><path d="M4 10h16l-1-5H5l-1 5z"/><path d="M5 10v9h14v-9"/><path d="M9 19v-5h6v5"/></svg>
                </span>
                <b>Verkopen</b>
                <small>Als bedrijf starten</small>
              </Link>
            </div>
          </div>
          <form action="/zoeken" className="publicSearchBox premiumSearchBox">
            <label>Waar zoek je naar?</label>
            <div className="premiumSearchInput">
              <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/></svg>
              <input name="q" placeholder="Bijv. Samsung wasmachine, bank, koffiemachine…" />
              <span>✦</span>
            </div>
            <button type="submit">Zoeken</button>
          </form>
          <div className="premiumTrustStrip">
            <span>Geverifieerde bedrijven</span>
            <span>Outlet & retouren</span>
            <span>AI-prijsinzichten</span>
          </div>
        </section>

        <DiscoveryCarousel cards={home.discoveryCards} />

        {dealOfDay && (
          <section className="aiDealOfDay v2DealOfDay">
            <Link href={`/listing/${dealOfDay.id}`} className="aiDealHero">
              <span className="copy">
                <span className="eyebrow">AI DEAL VAN DE DAG</span>
                <b>{dealOfDay.title}</b>
                <small>{dealSeller?.name ?? dealOfDay.sellerSlug} · Deal Score {dealQualityScore(dealOfDay, sellers)}/100 · −{disc(dealOfDay.price, dealOfDay.newPrice)}%</small>
              </span>
              <span className="price">{eur(dealOfDay.price)}</span>
            </Link>
          </section>
        )}

        {!!aiPicks.length && <section className="v2RailBlock v2AiPicks">
          <div className="v2SectionHead"><h2>AI Picks</h2><Link href="/vinder">BEKIJK →</Link></div>
          <div className="v2FeatureRail">
            {aiPicks.map(l => <FeatureDealCard key={l.id} listing={l} seller={sellers.find(s => s.slug === l.sellerSlug)} score={dealQualityScore(l, sellers)} />)}
          </div>
        </section>}

        {spotlightListing && (
          <section className="v2PartnerSpotlight">
            <div className="spotHead"><span>Partner Spotlight</span><small>Outrun Promote · subtiel</small></div>
            <Link href={`/store/${spotlightSeller?.slug ?? spotlightListing.sellerSlug}`} className="v2PartnerCard">
              <Img src={spotlightListing.photos[0]} fallback={spotlightListing.fallback} />
              <span><b>{spotlightSeller?.name ?? spotlightListing.sellerSlug}</b><small>{spotlightListing.title} · {eur(spotlightListing.price)} · {spotlightListing.stock} stuk</small></span>
              <i>Store →</i>
            </Link>
          </section>
        )}

        <Rail title="Nieuw binnen" href="/zoeken?sort=nieuw" items={newListings} />
        <Rail title="Trending volgens AI" href="/zoeken?sort=ai" items={trending} />
        <Rail title="Laatste stuks" href="/zoeken?sort=snel" items={lastChance} tag="LAATSTE" />

        <section className="v2Collections">
          <div className="v2SectionHead"><h2>Collecties</h2><Link href="/zoeken">ALLE →</Link></div>
          <div className="v2CollectionGrid">
            {collections.map(c => <Link key={c.title} href={c.href} className="v2Collection"><b>{c.title}</b><span>{c.text}</span></Link>)}
          </div>
        </section>

        <section className="v2AiFinderCta">
          <span>✨ AI Vinder</span>
          <b>Kun je niet vinden wat je zoekt?</b>
          <p>Beschrijf je wens. Outrun zoekt door alle live voorraad en legt uit waarom iets past.</p>
          <Link href="/vinder">Laat AI zoeken →</Link>
        </section>
      </>}
    </main>
  );
}
