# Outrun IQ v9.0.1

Premium Mobile Scale & Partner Polish.

Deze release bouwt voort op v9.0.0 Public Marketplace. De schaal van de mobiele buyer UI is opnieuw afgestemd op een premium, compactere iPhone-ervaring en dezelfde schaal is doorgetrokken naar de zakelijke partneromgeving.

Belangrijkste wijzigingen:
- Home-hero herschreven: geen letterlijke uitlegtekst meer, maar korte marketplace-positionering.
- Drie compacte actiekaarten: Deals, AI zoeken, Verkopen.
- Zoekkaart in premium mobiele stijl met compactere input en CTA.
- Productrails/cards compacter zodat meer content boven de vouw staat.
- Bottom dock compacter en beter visueel gebalanceerd.
- Productdetail, listing-sheet en koopblokken iets kleiner geschaald.
- Partner Hub krijgt dezelfde mobiele schaal: compactere hero, metrics, acties en orderkaarten.
- Desktop behoudt fullscreen aanpak met dezelfde designrichting.

Deploypad: `/var/www/outrun-iq-v5`.
