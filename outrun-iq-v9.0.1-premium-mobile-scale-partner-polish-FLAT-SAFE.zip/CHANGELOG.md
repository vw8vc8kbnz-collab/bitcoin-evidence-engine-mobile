# Changelog

## v9.0.1 — Premium Mobile Scale & Partner Polish

- Mobile marketplace hero opnieuw opgebouwd rond een kortere, relevantere boodschap.
- Vervangt de grote tekstknoppen door drie compacte premium actiekaarten.
- Zoekkaart visueel afgestemd op de goedgekeurde mobiele mock-up richting.
- Product cards, rails, deal-of-day, bottom dock en detailpagina compacter geschaald.
- Partneromgeving visueel opgeschoond met dezelfde compacte schaal.
- Geen nieuwe bulk/werkbank-flow toegevoegd; single-product partnerflow blijft de richting.

## v9.0.0 — Public Marketplace & Soft Authentication Foundation Reset

- `/` is publieke marketplace geworden.
- Login pas bij acties met intentie.
- Basis voor soft-auth en publieke discovery.
