"""
Seed companies for TEST MODE discovery. Realistic Dutch outlet/overstock
candidates so the whole pipeline is demonstrable without any live scraping.
In live mode the discovery engine uses a real search source instead (see
pipeline/discovery.py).
"""

SEED_COMPANIES = [
    {"kvk": "17204418", "name": "Meubelhal Brabant B.V.", "city": "Tilburg", "sector": "Meubelen",
     "website": "meubelhalbrabant.nl", "size": 24,
     "signals": ["outlet-sectie", "showroom-uitverkoop", "340 sale-items"]},
    {"kvk": "52118890", "name": "LichtPunt Groothandel", "city": "Utrecht", "sector": "Verlichting",
     "website": "lichtpunt.nl", "size": 11, "signals": ["restpartijen", "op=op campagne"]},
    {"kvk": "63001229", "name": "Keukenconcurrent Zuid", "city": "Eindhoven", "sector": "Keukens",
     "website": "keukenconcurrentzuid.nl", "size": 31, "signals": ["showroommodellen"]},
    {"kvk": "71449002", "name": "TuinLeven Outdoor", "city": "Zwolle", "sector": "Tuinmeubelen",
     "website": "tuinleven.nl", "size": 9, "signals": ["einde-seizoen leegverkoop", "50% korting"]},
    {"kvk": "48820013", "name": "SanitairDirect NL", "city": "Rotterdam", "sector": "Sanitair",
     "website": "sanitairdirect.nl", "size": 18, "signals": ["b-keuze", "retouren"]},
    {"kvk": "09188442", "name": "WoonExpo Gelderland", "city": "Arnhem", "sector": "Wonen",
     "website": "woonexpo.nl", "size": 15, "signals": ["showroom-rotatie", "sale groeit"]},
    {"kvk": "55012877", "name": "ElektroStock B.V.", "city": "Amsterdam", "sector": "Elektronica",
     "website": "elektrostock.nl", "size": 22, "signals": ["refurbished"]},
    {"kvk": "30291184", "name": "VloerDepot", "city": "Breda", "sector": "Vloeren",
     "website": "vloerdepot.nl", "size": 14, "signals": ["restpartijen laminaat"]},
    {"kvk": "61200934", "name": "SlaapComfort Outlet", "city": "Almere", "sector": "Slapen",
     "website": "slaapcomfort.nl", "size": 12, "signals": ["outlet-vestiging", "modellen moeten weg"]},
    {"kvk": "27884410", "name": "KantoorMeubel Pro", "city": "Den Haag", "sector": "Kantoor",
     "website": "kantoormeubelpro.nl", "size": 17, "signals": ["projectrestanten"]},
    {"kvk": "66120845", "name": "DecoRestpartij", "city": "Groningen", "sector": "Wonen",
     "website": "decorestpartij.nl", "size": 7, "signals": ["verse restpartij"]},
    {"kvk": "58990123", "name": "BadkamerXL Warehouse", "city": "Venlo", "sector": "Sanitair",
     "website": "badkamerxl.nl", "size": 20, "signals": ["warehouse-outlet"]},
    {"kvk": "70338821", "name": "Trendhuis Living", "city": "Nijmegen", "sector": "Wonen",
     "website": "trendhuis.nl", "size": 8, "signals": []},
    {"kvk": "41027756", "name": "MegaMeubel Discount", "city": "Apeldoorn", "sector": "Meubelen",
     "website": "megameubel.nl", "size": 29, "signals": ["magazijn-leegverkoop", "overstock-rotatie"]},
    {"kvk": "83004512", "name": "Verlichting Direct", "city": "Haarlem", "sector": "Verlichting",
     "website": "verlichtingdirect.nl", "size": 10, "signals": ["showroommodellen", "uitlopende serie"]},
    {"kvk": "90223317", "name": "TapijtHal Overijssel", "city": "Deventer", "sector": "Vloeren",
     "website": "tapijthal.nl", "size": 13, "signals": ["partij restvoorraad"]},
]
