# Outrun OS — Acquisition Intelligence

Autonome supply-side intelligentielaag achter Outrun IQ. Vindt bedrijven, scant en
scoort ze op twee assen (Fit + Timing), schrijft persoonlijke outreach, en houdt
elke beslissing onder jouw controle. Draait standaard in **testmodus**: niets wordt
verzonden tot je bewust live gaat.

## Wat het is (en niet is)

- **Geen npm, geen build.** De frontend is één static bestand (`web/index.html`),
  geserveerd door FastAPI. Dit omzeilt de registry-blocker volledig.
- **Twee keys, verder niets.** Zet alleen `DEEPSEEK_API_KEY` en `OPENAI_API_KEY`.
  Al het andere heeft veilige defaults.
- **Werkt zónder keys.** Zonder keys draait alles op mock-providers, zodat je de
  volledige pijplijn kunt verkennen. Zodra je de keys zet, schakelt de router naar
  DeepSeek/GPT.

## Dual-LLM (de kern)

Rolverdeling naar echte sterktes, met kruislingse controle:

| Taak | Model | Waarom |
|---|---|---|
| Scoring (fit/timing) | DeepSeek | goedkoop, bulk-analyse |
| Score-verificatie (alleen Priority A) | GPT | duur oordeel, alleen waar het telt |
| Outreach schrijven | GPT | toon en nuance |
| Claim-verificatie op de mail | DeepSeek | fact-check tegen bewijs |
| Reply-classificatie | DeepSeek | bulk |
| Vision (screenshot) | GPT | DeepSeek kan geen beelden |

**Generator → Verifier:** GPT schrijft de mail, DeepSeek markeert elke claim die
niet door het bewijs wordt gedekt. **Confidence-as-disagreement:** waar DeepSeek en
GPT het oneens zijn over een score, wordt de lead naar jou geëscaleerd (`review`).

De router zit in `app/llm/router.py`. Model wisselen = één regel.

## Testmodus (server-side, geen vinkje)

`OUTRUN_TEST_MODE` staat standaard op `true` en is **alleen** via env te wijzigen —
er is bewust geen browser-knop. In testmodus gaat "verzenden" naar de **Outbox**
(inspecteerbaar), niet naar SMTP. Synthetische replies laten je de hele loop droog
testen: mail → reactie → classificatie → follow-up.

## Architectuur

```
run.py                     entrypoint (uvicorn, 1 worker)
app/config.py              env, testmodus, keys
app/db.py                  SQLite (WAL), multi-tenant schema
app/llm/                   provider-interface + DeepSeek/OpenAI/mock + router
app/pipeline/
  discovery.py             MODULE 1  test-seed of echte search-source
  scan.py                  MODULE 2  structured-first features + evidence
  scoring.py               MODULE 3/4  dual-LLM fit/timing + decay
  outreach.py              MODULE 5/6  GPT schrijft, DeepSeek verifieert
  followup.py              MODULE 7  dag 4/10/21
  replies.py               MODULE 8  reply brain + synthetische replies
app/services/
  mailer.py                de ENIGE send-plek; testmodus-gate zit hier
  seed.py                  test-bedrijven
app/worker.py              background: 1 stap per tick (live gevoel)
app/api.py                 FastAPI routes + static frontend
web/index.html             volledige UI, geen build
```

## Eerlijk over de grenzen

- **Discovery** gebruikt in testmodus een seed-lijst. Echte discovery vereist een
  search-API-key (`SERPAPI_KEY`) en is een expliciete stap — er wordt géén LinkedIn
  gescrapet (ban- + juridisch risico).
- **Learning Engine** is nu een activiteitenlog (`events`-tabel). Een écht eigen
  model komt pas als er honderden gelabelde uitkomsten zijn; alles daarvoor zou
  fictie zijn.
- **Deliverability** (verzendsubdomein, SPF/DKIM/DMARC, warmup) is een operationele
  stap vóór live gaan, geen code-schakelaar.

## Lokaal draaien

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env      # keys mag je leeg laten om met mock te testen
python run.py             # http://localhost:8700
```

Deploy op de VPS: zie `deploy/DEPLOY.md`.

## v1.3.0-step1 — Evidence Engine: Deep Crawl

Deze build voegt alleen Stap 1 toe: **Deep Crawl zonder AI-kosten**.

Wat nieuw is:
- Nieuwe module `app/pipeline/deep_crawl.py`.
- Nieuwe tabellen `crawl_runs` en `crawl_pages`.
- Nieuwe endpoints:
  - `POST /api/lead/{id}/deep-crawl` — start deep crawl handmatig.
  - `GET /api/lead/{id}/deep-crawl` — laatste crawlrapport.
- Dashboardknop **Deep crawl** in de lead-detaildrawer.
- Crawlrapport toont hoeveel pagina’s en welke harde signalen zijn gevonden.
- Geen betaalde AI/API-calls in deze stap.
- `OUTRUN_WORKER` staat vanaf v1.3 standaard uit om onnodige API-kosten te voorkomen.

Truth-first regel:
- Alleen gevonden signalen mogen later als feit worden gebruikt.
- `not_found` betekent alleen: niet gevonden in deze crawl. Het is geen bewijs dat iets absoluut niet bestaat.
- Latere mailgeneratie moet uitsluitend gevalideerde evidence gebruiken.
