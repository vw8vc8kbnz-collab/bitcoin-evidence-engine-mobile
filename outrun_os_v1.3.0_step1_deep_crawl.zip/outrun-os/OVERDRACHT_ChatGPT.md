# MEGA-OVERDRACHT — Outrun OS

**Voor: ChatGPT (voortzetting ontwikkeling) · Versie: 1.2 · Stack: FastAPI + SQLite + vanilla-JS frontend**

Dit document is geschreven zodat je (ChatGPT) zonder verdere context kunt doorwerken aan Outrun OS. Het beschrijft de architectuur, elk bestand, het datamodel, de dual-LLM orchestratie, de test-mode gating, de volledige API, de deploy-pipeline en de roadmap. Lees dit volledig voordat je iets wijzigt. De code is leidend; waar dit document en de code verschillen, wint de code — maar meld de discrepantie.

---

## 0. Wat Outrun OS is

Outrun OS is de **supply-side acquisitie-intelligentielaag** achter Outrun IQ (een B2C outletmarktplaats, KvK-geverifieerde partners, 10% commissie). Outrun OS vindt bedrijven, scant en scoort ze, schrijft persoonlijke outreach, en houdt elke beslissing onder menselijke controle. Het draait als **losstaande deployable app** naast Outrun IQ.

Drie principes die door alles heen lopen — schend deze niet zonder expliciete reden:

1. **Evidence-based, glass box.** Elke score en elke claim is herleidbaar naar concreet bewijs met bron + datum. Geen `Math.random()`, geen zwarte doos. Als je een score introduceert, koppel je bewijs.
2. **Test-mode-first.** Standaard wordt er niets verzonden. De overgang naar live is een bewuste, server-side handeling. Zie §5.
3. **Dual-LLM met rolverdeling + kruiscontrole.** DeepSeek en GPT doen elk waar ze goed in zijn, en controleren elkaar op de dure beslissingen. Zie §4.

Twee scoringsassen, overal aanwezig:
- **FIT** (structureel, stabiel): past assortiment/prijstier/KvK/merken. Verandert traag.
- **TIMING** (event-driven, verloopt): hoe vers/sterk is het huidige uitverkoop-/voorraadsignaal. Koelt af met de tijd (half-life decay).

---

## 1. Repository- en bestandsstructuur

```
outrun-os/
  run.py                     entrypoint (uvicorn, 1 worker) — print status + start server
  requirements.txt           losse pins met floors die op Python 3.13 EN 3.14 wheels hebben
  .env.example               alleen de 2 keys zijn verplicht; rest optioneel
  .gitignore                 negeert .env, .venv, *.db
  deploy/
    outrun-os.service        systemd unit (EnvironmentFile=-  => .env optioneel)
    DEPLOY.md                deploy-instructies
  app/
    __init__.py
    config.py                ALLE env/config; VERSION; status_summary()
    db.py                    sqlite3 (WAL), schema, get_conn(), log_event()
    llm/
      base.py                LLMProvider interface + LLMTask + extract_json()
      mock.py                deterministische mock (app draait volledig zonder keys)
      deepseek.py            DeepSeek provider (OpenAI-compatible /chat/completions)
      openai.py              OpenAI/GPT provider (chat + vision)
      router.py              route(task) -> provider op basis van capability
    pipeline/
      discovery.py           MODULE 1  test-seed of echte search-source (stub)
      scan.py                MODULE 2  structured-first features + evidence-rijen
      scoring.py             MODULE 3/4  dual-LLM fit/timing + timing-decay
      outreach.py            MODULE 5/6  GPT schrijft, DeepSeek verifieert claims
      followup.py            MODULE 7  dag 4/10/21 scheduler
      replies.py             MODULE 8  reply brain + synthetische replies (testloop)
    services/
      mailer.py              DE ENIGE send-plek; test-mode gate zit hier
      seed.py                16 realistische NL test-bedrijven
    worker.py                background: 1 pipeline-stap per tick (live gevoel)
    api.py                   FastAPI routes + static frontend + no-store header
  web/
    index.html               volledige UI, vanilla JS, GEEN build/npm
```

**Waarom geen npm/build voor de frontend?** De VPS had een npm-registry-misdirectie (interne OpenAI-registry) die builds brak. De frontend is daarom bewust één self-contained `index.html` (HTML+CSS+vanilla JS) die FastAPI als static file serveert. Introduceer geen bundler/React zonder deze constraint op te lossen. Als je de UI uitbreidt, doe dat in `web/index.html`.

---

## 2. Config & environment (`app/config.py`)

De ENIGE twee verplichte env-vars:
- `DEEPSEEK_API_KEY`
- `OPENAI_API_KEY`

Als een key ontbreekt, valt die provider terug op de mock (app blijft volledig werken). Alle overige vars hebben defaults:

| Env var | Default | Betekenis |
|---|---|---|
| `OUTRUN_TEST_MODE` | `true` | Server-side test-mode. Geen browser-toggle. |
| `OUTRUN_TENANT` | `outruniq` | Multi-tenant sleutel (zit op elke rij). |
| `OUTRUN_DB` | `<repo>/outrun_os.db` | SQLite-pad. |
| `OUTRUN_HOST` / `OUTRUN_PORT` | `0.0.0.0` / `8700` | Bind. |
| `OUTRUN_WORKER` / `OUTRUN_WORKER_INTERVAL` | `true` / `20` | Background worker aan + interval (s). |
| `OUTRUN_SENDER_NAME` / `_BRAND` / `_COMMISSION` | `Stijn` / `Outrun IQ` / `10` | Outreach-identiteit. |
| `OUTRUN_DEEPSEEK_MODEL` | `deepseek-chat` | DeepSeek model. |
| `OUTRUN_OPENAI_MODEL` / `_VISION_MODEL` | `gpt-4o` | GPT model(len). |
| `SERPAPI_KEY` | leeg | Echte discovery (anders test-seed). |
| `OUTRUN_SMTP_*` | leeg | Alleen gebruikt bij LIVE. |
| `OUTRUN_TIMING_HALFLIFE` | `10` | Half-life (dagen) van timing-decay. |

`config.status_summary()` levert een dict met o.a. `version`, `test_mode`, `deepseek`/`openai` (`live`|`mock`), `can_send`. Deze wordt door `/api/config` blootgesteld en door de frontend gebruikt (versielabel + testbanner + provider-bolletjes).

**Belangrijk:** `VERSION` staat in `config.py`. Verhoog dit bij elke release; de frontend toont het in de topbalk (`v1.2 · acquisition intelligence`), zodat je direct ziet of een deploy geland is (cache-debugging).

---

## 3. Datamodel (`app/db.py`)

SQLite met `PRAGMA journal_mode=WAL`. Eén verbinding per operatie via `get_conn()` (context manager, commit+close). **Multi-tenant vanaf dag één:** elke tabel heeft `tenant_id`. Gebruik altijd `config.TENANT` in queries.

Tabellen (kolommen samengevat):

- **companies** `(id, tenant_id, kvk, name, city, sector, website, size, source, stage, created_at)` — `UNIQUE(tenant_id, kvk)` => dedup op KvK. `stage ∈ {discovered, scanned, scored, drafted, contacted, replied, nurture}`.
- **scans** `(id, company_id, tenant_id, features_json, summary, created_at)` — ruwe feature-extractie per scan.
- **evidence** `(id, company_id, tenant_id, axis, label, detail, source, source_url, observed_at)` — `axis ∈ {fit, timing}`. Dit is de glass-box: elke UI-claim komt hiervandaan.
- **scores** `(id, company_id, tenant_id, fit, timing_base, timing_observed_at, priority, confidence, deepseek_json, gpt_json, created_at)` — `confidence ∈ {aligned, review, flag}`. `timing_base` + `timing_observed_at` worden gebruikt om de HUIDIGE timing te decayen (zie §4). `deepseek_json`/`gpt_json` bewaren de ruwe modeloutput voor transparantie.
- **drafts** `(id, company_id, tenant_id, subject, body, status, verifier_json, created_at, decided_at)` — `status ∈ {awaiting, approved, rejected, edited}`. `verifier_json` = `{flags:[{quote, reason}]}` van de DeepSeek-verificatie.
- **messages** `(id, company_id, tenant_id, direction, channel, subject, body, status, is_synthetic, created_at)` — `direction ∈ {out, in}`. In test-mode krijgen uitgaande mails `status='outbox'` (= niet verzonden). Live: `sent`/`error`.
- **replies** `(id, company_id, message_id, tenant_id, body, intent, summary, is_synthetic, created_at)` — `intent ∈ {HOT, WARM, QUESTION, NOT_NOW, NO}`.
- **followups** `(id, company_id, tenant_id, step, due_at, status, created_at)` — `step ∈ {1,2,3}` => dag 4/10/21. `status ∈ {scheduled, done, cancelled}`.
- **events** `(id, tenant_id, company_id, kind, payload_json, created_at)` — activiteitenlog. Dit is tevens de **datavoorraad voor de toekomstige Learning Engine** (zie §8). Elke pipeline-stap logt hier via `db.log_event()`.

Indexen op `companies(tenant_id, stage)`, `scores(company_id)`, `evidence(company_id)`.

**Migraties:** er is nu geen migratieframework; `init_db()` draait `CREATE TABLE IF NOT EXISTS`. Als je kolommen toevoegt, doe dat additief met een idempotente `ALTER TABLE ... ADD COLUMN` in `init_db()` achter een try/except, of introduceer een simpele `schema_version`-tabel. Verwijder nooit bestaande kolommen zonder migratiepad.

---

## 4. Dual-LLM orchestratie — het hart

### 4.1 Provider-abstractie (`app/llm/base.py`)
`LLMTask` declareert wat een taak NODIG heeft:
```python
LLMTask(name, system, user, needs_vision=False, prefer_quality=False,
        prefer_cheap=True, want_json=True, image_b64=None, meta={})
```
`LLMProvider.complete(task) -> {"text", "json", "provider"}`. `extract_json()` haalt JSON uit een modelantwoord (strip code fences, fallback naar eerste `{...}`).

### 4.2 Router (`app/llm/router.py`)
```
needs_vision      -> OpenAI  (DeepSeek-chat kan GEEN beelden; harde regel)
prefer_quality    -> OpenAI  (toon, nuance, oordeel)
anders (cheap)    -> DeepSeek (bulk-analyse)
key ontbreekt     -> mock    (app blijft draaien)
```
Wijzig je modellen? Doe het hier of via env. De pipeline hoeft niet aangepast.

### 4.3 Rolverdeling per taak
| Taak (`LLMTask.name`) | Provider | Plek |
|---|---|---|
| `score` (fit/timing + rationale) | DeepSeek | `scoring.py` |
| `verify_score` (alleen Priority A) | GPT | `scoring.py` |
| `write_outreach` | GPT | `outreach.py` |
| `verify_claims` (fact-check mail vs bewijs) | DeepSeek | `outreach.py` |
| `classify_reply` | DeepSeek | `replies.py` |
| `synthetic_reply` (testloop) | DeepSeek | `replies.py` |
| `vision_scan` (screenshot) | GPT | (voorzien, nog niet actief) |

### 4.4 Twee slimme patronen
**Generator → Verifier (kruislings).** GPT schrijft de outreach; DeepSeek krijgt de mail + het bewijs en markeert elke claim die niet gedekt is (`verify_claims`). Zo gaat er geen verzonnen feit de deur uit. Dit is zichtbaar in de UI als het gele DeepSeek-verificatieblok.

**Confidence-as-disagreement.** DeepSeek scoort alles (goedkoop). Alleen voor **Priority-A** leads laat GPT de score second-guessen (`verify_score`). Eens → `confidence='aligned'` (vertrouw de pipeline). Oneens → `confidence='review'` en de lead escaleert naar de founder. Dun bewijs → `confidence='flag'`. Zo krijg je een gratis onzekerheidssignaal in plaats van ruis.

### 4.5 Timing-decay (`scoring.timing_now`)
```
timing_now = timing_base * 0.5 ** (dagen_sinds_observatie / HALFLIFE)
```
Priority wordt herberekend op de gedecayde timing: `A` = fit≥78 én timing≥75; `B` = gemiddelde≥62; anders `C`. Zo koelen leads zichtbaar af als er niet gehandeld wordt.

**Let op — bekende scherpe rand:** in de huidige seed-flow krijgen sommige bedrijven een hoge `timing_base` met `observed_at = nu`, waardoor er in de testset veel Priority-A/B leads tegelijk ontstaan (zie de screenshots: veel "WACHT OP AKKOORD"). Dat is test-data-artefact, geen bug. Bij echte discovery spreidt dit vanzelf. Als je de testset realistischer wilt, varieer de `observed_at` van timing-evidence in `scan.py`/`seed.py`.

---

## 5. Test-mode gating (`app/services/mailer.py`)

`mailer.send()` is de ENIGE plek waar verzonden wordt. De gate zit server-side:
```
TEST_MODE of geen SMTP_HOST  -> schrijf naar messages(status='outbox'), sent=False
anders                       -> echte SMTP-send
```
`OUTRUN_TEST_MODE` is **niet** via de browser te wijzigen (bewust — een eerder project had een publiek toegankelijke test-mode). Live gaan = env-var wijzigen + `systemctl restart`. De UI toont een permanente gele TEST-balk; bij live wordt die rood.

**Synthetische replies** (`replies.synthesize_reply`) laten de hele loop droog testen: outreach → gesimuleerde bedrijfsreactie (met persona) → classificatie → follow-up cancel. Alleen actief in test-mode; replies worden gelabeld `is_synthetic=1`.

---

## 6. Pipeline & worker

**Worker** (`app/worker.py`) draait één stap per tick (interval `OUTRUN_WORKER_INTERVAL`, default 20s) zodat de pijplijn "stroomt" i.p.v. in één burst. Volgorde per tick:
1. `discovered` → `scan_company` (feature-extractie + evidence)
2. `scanned` → `score_company` (dual-LLM)
3. `scored` zonder draft, priority A/B → `generate_draft` (GPT schrijft + DeepSeek verifieert); C → `nurture`
4. funnel leeg → `run_discovery` (nieuwe seed of search)
5. test-mode: `contacted` zonder reply → `synthesize_reply`

Drafts stoppen bij de approval queue — niets gaat naar contact zonder de founder (`approve` endpoint).

**Handmatige triggers** (handig in test-mode): `POST /api/pipeline/discover` en `POST /api/pipeline/tick`.

---

## 7. HTTP API (`app/api.py`)

| Method | Route | Doel |
|---|---|---|
| GET | `/` | serveert `web/index.html` met `Cache-Control: no-store` |
| GET | `/api/config` | `status_summary()` (version, test_mode, provider-status) |
| GET | `/api/stats` | pipeline-tellingen (discovered/scanned/scored/queue/discovered_today) |
| GET | `/api/leads` | lijst leadsamenvattingen (gesorteerd op fit+timing) + config |
| GET | `/api/lead/{id}` | company + score (incl. deepseek/gpt JSON) + evidence + draft + events |
| POST | `/api/lead/{id}/approve` | keur draft goed → mailer.send (outbox in test) + schedule follow-ups. Body optioneel `{subject, body}` voor edits. |
| POST | `/api/lead/{id}/reject` | draft afwijzen → nurture |
| POST | `/api/lead/{id}/regenerate` | nieuwe draft genereren |
| POST | `/api/lead/{id}/simulate-reply` | (test-mode) synthetische reply |
| GET | `/api/outbox` | uitgaande messages (test = niet verzonden) |
| POST | `/api/pipeline/discover` | trigger discovery |
| POST | `/api/pipeline/tick` | trigger één worker-stap |

Leadsamenvatting-velden: `id, name, kvk, city, sector, stage, fit, timing, priority, confidence, status, reply_intent, days`. `status` wordt afgeleid in `_derive_status()` (bepaalt de pill in de UI). `days` = dagen sinds laatste timing-evidence.

---

## 8. Frontend (`web/index.html`)

Vanilla JS, geen framework. Design: donker "instrument", mono voor data, twee assen in kleur (FIT = teal `#38D6C4`, TIMING = indigo→magenta `#6D6BF6`→`#E24DAE` dat afkoelt). Kernonderdelen:
- **Topbalk** (2 rijen, stapelt op mobiel): brand + versielabel + Outbox-knop; daaronder testbanner + provider-bolletjes.
- **Pipeline** (2×2 op mobiel, 4-koloms op desktop): Discovery/Deep scan/Scored/Approval queue met live tellingen.
- **Triage-kaarten**: Priority A / Reacties / Concepten / Koelt af — klikbaar, zetten een filter.
- **Filters**: zoekveld + horizontaal scrollbare sector-chips + "koelt af" + reset.
- **Lead-lijst**: **kaarten** (1 kolom mobiel, 2-3 desktop). Geen tabel — tabellen breken op mobiel. Elke kaart: naam + KvK/plaats/sector, Fit/Timing mini-bars, confidence + status.
- **Detail-drawer** (schuift in): scores, dual-model oordeel, evidence-reveal (gefaseerd), concept-outreach met geel gemarkeerde onbewezen claims + DeepSeek-verificatieblok, en Goedkeuren/Concept opnieuw/Afwijzen.
- **Outbox-modal**: inspecteer wat er "verzonden" zou zijn.

Belangrijke JS-functies: `boot()` (laadt config, dan `refresh()` elke 8s), `renderConfig`, `renderPipeline`, `renderTriage`, `renderSectorChips`, `renderRows` (kaarten), `openLead`/`renderDrawer`, `approve/reject/regenerate/simulateReply`, `openOutbox`. Statusmapping in `STATUS`, timing-kleur in `timingColor()`.

**Cache-les:** de frontend wordt met `no-store` geserveerd (§7). Als een UI-wijziging niet verschijnt, is het bijna altijd browser-cache — hard verversen. Het versielabel in de balk bevestigt of de nieuwe build geladen is.

---

## 9. Deploy (GitHub → VPS → Termius)

- **Python 3.14 valkuil:** oude pydantic-pins triggerden een Rust/Cargo broncode-build van `pydantic-core` (faalt). `requirements.txt` gebruikt nu floors (`pydantic>=2.13`, `fastapi>=0.115`, `uvicorn[standard]>=0.34`, `httpx>=0.28`) die kant-en-klare wheels voor 3.14 hebben. **Draai nooit oude exacte pins terug.**
- **systemd:** `deploy/outrun-os.service`, `EnvironmentFile=-/home/ubuntu/outrun-os/.env` (de `-` maakt `.env` optioneel; anders weigert de service te starten als het bestand mist).
- **Frontend-deploy:** de repo bevat een zip (`outrun-os_vX.Y.zip`); die wordt naar `/home/ubuntu/outrun-os` uitgepakt. `.venv` en `.env` staan buiten de zip en blijven behouden.
- **VPS-feiten:** IP `51.195.102.180`, poort `8700`, user `ubuntu`, app-pad `/home/ubuntu/outrun-os`, venv `/home/ubuntu/outrun-os/.venv`. Repo: `github.com/vw8vc8kbnz-collab/bitcoin-evidence-engine-mobile` (de zip staat in die repo).

Deploy-details staan in `deploy/DEPLOY.md`.

---

## 10. Wat echt af is vs. stub (wees hier eerlijk tegen de gebruiker)

**Af en werkend:** discovery (test-seed), scan+evidence, dual-LLM scoring met confidence, outreach + verifier, approval → outbox, follow-up scheduling, reply brain + synthetische replies, CRM-opslag, de volledige UI en deploy.

**Bewust stub / operationeel, nog niet af:**
1. **Echte discovery** (`discovery.discover_search`) — leeg tenzij `SERPAPI_KEY`. Wire hier een search-API (SerpAPI/Bing) op de signaalqueries (`outlet`, `op=op`, `showroommodellen`, `restpartij`), parse bedrijfsresultaten, resolve KvK via de KvK-API, en roep `_insert_company()` aan. **Scrape GEEN LinkedIn** (ban- + juridisch risico).
2. **Vision-scan** — router en rol zijn voorzien (`vision_scan` → GPT), maar er wordt nog geen screenshot gemaakt/gestuurd. Implementatie: render homepage naar PNG (bijv. Playwright), base64, `LLMTask(needs_vision=True, image_b64=...)`.
3. **Learning Engine** — nu een `events`-log. Een echt eigen model kan pas na honderden gelabelde uitkomsten (welke leads/mails/branches converteerden). Bouw eerst outcome-labeling in, dan pas calibratie. Doe geen "AI-model" alsof het al bestaat.
4. **Deliverability** — vóór live gaan: apart verzendsubdomein, SPF/DKIM/DMARC, warmup, suppression list, dag-caps. Dit is operationeel, geen code-schakelaar. Veel ESP's verbieden cold email in hun TOS.
5. **AVG** — B2B cold outreach kan in NL op gerechtvaardigd belang, mits opt-out, dataminimalisatie, bewaartermijn en verwijderrecht vanaf dag één. Bouw dit in vóór echte verzending.
6. **Auth** — de app draait nu open op het IP. Zet auth + reverse proxy (met TLS) vóór echte bedrijfsdata/keys in productie.

---

## 11. Roadmap (concrete volgende stappen, in prioriteitsvolgorde)

1. **Echte discovery-source** (§10.1) — grootste waarde: échte bedrijven i.p.v. seed. Begin met SerpAPI op signaalqueries + KvK-resolutie + dedup (bestaat al op KvK).
2. **Outcome-tracking** voor de Learning Engine: markeer per lead het eindresultaat (gereageerd/geconverteerd/afgewezen) en log dat in `events`. Dit is de databasis voor alles daarna.
3. **AVG-basislaag**: suppression-tabel, opt-out-link in outreach, bewaartermijn-job. Verplicht vóór live.
4. **Deliverability-setup** + `TEST_MODE=false` pas daarna.
5. **Vision-scan** activeren voor rijkere fit-signalen.
6. **Multi-tenant UI**: het datamodel is al multi-tenant; voeg tenant-selectie/-scoping toe zodat de tool voor andere bedrijven inzetbaar wordt (langetermijndoel van de gebruiker).

---

## 12. Conventies & valkuilen voor jou (ChatGPT)

- **Cursor vs. connection in sqlite3:** `conn.execute(...)` geeft een cursor terug; `conn.lastrowid` bestaat NIET. Gebruik `cur = c.execute(...); cur.lastrowid`. (Dit was een bug in v1.0.)
- **Altijd `tenant_id = config.TENANT`** in queries.
- **Elke nieuwe score/claim koppelt bewijs** (evidence-rij), anders schend je het glass-box principe.
- **Nieuwe LLM-taak toevoegen:** maak een `LLMTask` met de juiste capability-vlaggen; de router kiest de provider. Voeg een `_h_<taaknaam>`-handler toe in `mock.py` zodat de app zonder keys blijft werken.
- **Nooit auto-verzenden.** Alles via `mailer.send()` en dus via de test-mode gate.
- **Frontend blijft één static bestand.** Geen build-stap introduceren.
- **VERSION verhogen** bij elke release (`config.py`), zodat de UI + gebruiker de deploy kunnen verifiëren.
- **requirements floors niet verstrakken** (Python 3.14).
- **Bij UI-wijziging die niet verschijnt:** browser-cache; hard verversen. `no-store` staat al aan.

---

## 13. Snelle referentie — een lead door de pijplijn

```
discovery.run_discovery()      -> companies(stage='discovered')
scan.scan_company(id)          -> scans + evidence(fit/timing) ; stage='scanned'
scoring.score_company(id)      -> DeepSeek score (+ GPT verify bij A) ; scores ; stage='scored'
outreach.generate_draft(id)    -> GPT mail + DeepSeek verify ; drafts(status='awaiting') ; stage='drafted'
api approve(id)                -> drafts.approved + mailer.send (OUTBOX in test) + followup.schedule ; stage='contacted'
replies.synthesize_reply(id)   -> (test) reply + classify_reply ; replies ; stage='replied' ; followup.cancel_for
```

Einde overdracht. Werk incrementeel, respecteer de drie principes (§0), en houd de test-mode gate heilig.
