# Stock Evidence Engine v1.3.0

Core Intelligence Release. Stable stdlib dashboard on port 8798.

Adds measurable intelligence layers without changing the proven deployment baseline:
- Catalyst proxy score
- Theme rotation export
- Regime score export
- New intelligence setups: `theme_momentum_leader`, `catalyst_momentum_proxy`

Runtime: `/usr/bin/python3 /home/ubuntu/stock_evidence_latest/server.py`
Backtest: `./venv/bin/python engine.py ...`
