#!/usr/bin/env python3
import argparse, math, json, zipfile
from pathlib import Path
from datetime import datetime
import numpy as np
import pandas as pd
import yfinance as yf

VERSION='v1.3.0'
OUT=Path('data'); OUT.mkdir(exist_ok=True)
EXPORT=Path('exports'); EXPORT.mkdir(exist_ok=True)
HOLDS=[3,5,10,20]
COST=0.002

THEMES={
 'AI':['SOUN','BBAI','PLTR','AI','NVDA','AMD'],
 'QUANTUM':['IONQ'],
 'SPACE':['RKLB','ACHR','JOBY'],
 'CRYPTO':['COIN','MARA','RIOT'],
 'EV':['TSLA','LCID','RIVN'],
 'NUCLEAR':['SMR'],
 'FINTECH':['HOOD','UPST'],
 'LEGACY_AI_TURNAROUND':['BB'],
}
THEME_BY={t:theme for theme,vals in THEMES.items() for t in vals}
CATALYST_BASE={'AI':18,'QUANTUM':20,'SPACE':16,'CRYPTO':12,'EV':6,'NUCLEAR':14,'FINTECH':8,'LEGACY_AI_TURNAROUND':24}

def dl(ticker, period):
    try:
        df=yf.download(ticker, period=period, interval='1d', auto_adjust=True, progress=False, threads=False)
        if df is None or df.empty: return pd.DataFrame()
        if isinstance(df.columns, pd.MultiIndex): df.columns=[c[0] for c in df.columns]
        df=df.reset_index()
        df.columns=[str(c).lower() for c in df.columns]
        if 'date' not in df.columns: df=df.rename(columns={df.columns[0]:'date'})
        return df[['date','open','high','low','close','volume']].dropna().copy()
    except Exception as e:
        print(f'[WARN] {ticker} download failed: {e}')
        return pd.DataFrame()

def add_features(df, spy=None, qqq=None):
    d=df.copy()
    d['ret1']=d.close.pct_change()
    d['ret5']=d.close.pct_change(5)
    d['ret20']=d.close.pct_change(20)
    d['ma20']=d.close.rolling(20).mean(); d['ma50']=d.close.rolling(50).mean()
    d['vol20']=d.volume.rolling(20).mean()
    d['rv']=d.volume/d['vol20']
    d['high20']=d.high.rolling(20).max().shift(1)
    d['low10']=d.low.rolling(10).min().shift(1)
    delta=d.close.diff(); gain=delta.clip(lower=0).rolling(14).mean(); loss=(-delta.clip(upper=0)).rolling(14).mean()
    rs=gain/loss.replace(0,np.nan); d['rsi']=100-(100/(1+rs))
    if spy is not None and not spy.empty:
        s=spy[['date','close']].rename(columns={'close':'spy_close'})
        d=d.merge(s,on='date',how='left'); d['spy_ret20']=d.spy_close.pct_change(20); d['rs_spy20']=d.ret20-d.spy_ret20
    else: d['rs_spy20']=np.nan
    if qqq is not None and not qqq.empty:
        q=qqq[['date','close']].rename(columns={'close':'qqq_close'})
        d=d.merge(q,on='date',how='left'); d['qqq_ret20']=d.qqq_close.pct_change(20); d['rs_qqq20']=d.ret20-d.qqq_ret20
    else: d['rs_qqq20']=np.nan
    return d

def regime_series(spy, qqq):
    m=spy[['date','close']].rename(columns={'close':'spy'}).merge(qqq[['date','close']].rename(columns={'close':'qqq'}),on='date',how='outer').sort_values('date')
    m['spy_ma50']=m.spy.rolling(50).mean(); m['qqq_ma50']=m.qqq.rolling(50).mean()
    m['spy_ret20']=m.spy.pct_change(20); m['qqq_ret20']=m.qqq.pct_change(20)
    score=50+25*((m.spy>m.spy_ma50).astype(float)-0.5)*2+25*((m.qqq>m.qqq_ma50).astype(float)-0.5)*2+100*((m.spy_ret20.fillna(0)+m.qqq_ret20.fillna(0))/2).clip(-.1,.1)
    m['regime_score']=score.clip(0,100)
    m['regime_label']=pd.cut(m.regime_score,[-1,35,60,100],labels=['RISK_OFF','NEUTRAL','RISK_ON'])
    return m[['date','regime_score','regime_label','spy_ret20','qqq_ret20']]

def signals(d, ticker):
    out=[]
    theme=THEME_BY.get(ticker,'GENERAL')
    theme_bonus=CATALYST_BASE.get(theme,4)
    theme_score=min(100,50+theme_bonus*2)
    catalyst_proxy=theme_bonus
    for i in range(60,len(d)-max(HOLDS)-1):
        r=d.iloc[i]
        common={'date':r.date,'ticker':ticker,'theme':theme,'theme_score':theme_score,'catalyst_score':catalyst_proxy,'rs_spy20':r.rs_spy20,'rs_qqq20':r.rs_qqq20,'rv':r.rv,'rsi':r.rsi}
        if r.close>r.ma50 and r.ret20>.08 and r.rv>1.15:
            out.append({**common,'setup':'momentum_continuation_legacy','entry_idx':i,'entry':r.close,'trigger_strength':r.ret20*100+r.rv*5})
        if r.rs_spy20>.08 and r.rs_qqq20>.04 and r.close>r.ma20:
            out.append({**common,'setup':'relative_strength_leader','entry_idx':i,'entry':r.close,'trigger_strength':(r.rs_spy20+r.rs_qqq20)*100})
        if r.ret20>.08 and r.rs_spy20>.05 and r.rv>1.1 and r.close>r.ma20:
            out.append({**common,'setup':'momentum_rs_continuation','entry_idx':i,'entry':r.close,'trigger_strength':r.ret20*100+r.rs_spy20*100})
        if r.close>r.high20 and r.rv>1.25:
            out.append({**common,'setup':'breakout_continuation','entry_idx':i,'entry':r.close,'trigger_strength':r.rv*10})
        if r.rv>1.75 and r.ret5>.05:
            out.append({**common,'setup':'volume_expansion_followthrough','entry_idx':i,'entry':r.close,'trigger_strength':r.rv*8+r.ret5*100})
        # v1.3.0 intelligence combinations
        if r.ret20>.06 and r.rs_spy20>.05 and theme_score>=75:
            out.append({**common,'setup':'theme_momentum_leader','entry_idx':i,'entry':r.close,'trigger_strength':theme_score/2+r.rs_spy20*100})
        if catalyst_proxy>=16 and r.rv>1.2 and r.close>r.ma20:
            out.append({**common,'setup':'catalyst_momentum_proxy','entry_idx':i,'entry':r.close,'trigger_strength':catalyst_proxy*2+r.rv*5})
    return out

def summarize(trades):
    df=pd.DataFrame(trades)
    if df.empty: return pd.DataFrame()
    rows=[]
    for (ticker,setup,hold),g in df.groupby(['ticker','setup','hold_days']):
        n=len(g); avg=g.ret_net.mean(); win=(g.ret_net>0).mean()*100; med=g.ret_net.median()
        theme=g.theme.iloc[0]; theme_score=float(g.theme_score.mean()); cat=float(g.catalyst_score.mean())
        rs=float(g.rs_spy20.mean()*100) if g.rs_spy20.notna().any() else 0
        reg=float(g.regime_score.mean()) if 'regime_score' in g else 50
        evidence=(avg*100*3)+(win-50)+min(n,60)*0.6+max(rs,0)*0.5+theme_score*0.12+cat*0.25+(reg-50)*0.15
        fake= n<15 or (win>=90 and n<30)
        usable= n>=15 and not fake
        good= usable and win>=55 and avg>0.02 and evidence>=40
        elite= usable and n>=25 and win>=58 and avg>0.035 and evidence>=60
        rows.append(dict(version=VERSION,ticker=ticker,setup=setup,hold_days=hold,trades=n,winrate=round(win,2),avg_return=round(avg*100,3),median_return=round(med*100,3),expectancy=round(avg*100,3),theme=theme,theme_score=round(theme_score,2),catalyst_score=round(cat,2),avg_rs_spy20=round(rs,2),avg_regime_score=round(reg,2),evidence_score=round(evidence,2),fake_alpha_warning=int(fake),usable=int(usable),good_candidate=int(good),elite=int(elite),rank_reason=('ELITE' if elite else 'GOOD' if good else 'USABLE' if usable else 'FILTERED')))
    return pd.DataFrame(rows).sort_values(['elite','good_candidate','evidence_score'],ascending=[False,False,False])

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--tickers',required=True); ap.add_argument('--period',default='2y'); args=ap.parse_args()
    tickers=[x.strip().upper() for x in args.tickers.split(',') if x.strip()]
    print(f'[SEE {VERSION}] tickers={len(tickers)} period={args.period}')
    spy=add_features(dl('SPY',args.period)); qqq=add_features(dl('QQQ',args.period))
    reg=regime_series(spy,qqq)
    all_tr=[]
    for t in tickers:
        raw=dl(t,args.period)
        if raw.empty or len(raw)<100: continue
        d=add_features(raw,spy,qqq).merge(reg[['date','regime_score','regime_label']],on='date',how='left')
        sigs=signals(d,t)
        for s in sigs:
            i=s.pop('entry_idx'); entry=s['entry']
            for h in HOLDS:
                if i+h < len(d):
                    exitp=float(d.iloc[i+h].close); ret=exitp/entry-1-COST
                    all_tr.append({**s,'hold_days':h,'exit_date':d.iloc[i+h].date,'exit':exitp,'ret_net':ret,'regime_score':float(d.iloc[i].regime_score) if pd.notna(d.iloc[i].regime_score) else 50,'regime_label':str(d.iloc[i].regime_label)})
    trades=pd.DataFrame(all_tr)
    summary=summarize(all_tr)
    # aggregate exports
    def save(df,name): df.to_csv(EXPORT/name,index=False)
    save(trades, f'see_trades_{VERSION}.csv')
    save(summary, f'see_summary_{VERSION}.csv')
    save(summary[summary.elite==1] if not summary.empty else summary, f'see_elite_{VERSION}.csv')
    save(summary[summary.usable==1] if not summary.empty else summary, f'see_usable_{VERSION}.csv')
    if not trades.empty:
        by_setup=summary.groupby('setup').agg(rows=('setup','count'),trades=('trades','sum'),good=('good_candidate','sum'),elite=('elite','sum'),avg_expectancy=('expectancy','mean'),avg_evidence=('evidence_score','mean')).reset_index().sort_values('avg_evidence',ascending=False)
        by_ticker=summary.groupby('ticker').agg(rows=('ticker','count'),trades=('trades','sum'),good=('good_candidate','sum'),elite=('elite','sum'),avg_expectancy=('expectancy','mean'),avg_evidence=('evidence_score','mean')).reset_index().sort_values('avg_evidence',ascending=False)
        diag=summary.groupby('setup').agg(total_rows=('setup','count'),usable=('usable','sum'),good=('good_candidate','sum'),elite=('elite','sum'),trades=('trades','sum'),mean_evidence=('evidence_score','mean')).reset_index()
        theme=summary.groupby('theme').agg(rows=('theme','count'),trades=('trades','sum'),elite=('elite','sum'),avg_evidence=('evidence_score','mean'),avg_expectancy=('expectancy','mean')).reset_index().sort_values('avg_evidence',ascending=False)
        catalyst=summary.groupby(['ticker','theme']).agg(rows=('ticker','count'),elite=('elite','sum'),avg_catalyst=('catalyst_score','mean'),avg_theme_score=('theme_score','mean'),avg_evidence=('evidence_score','mean')).reset_index().sort_values('avg_evidence',ascending=False)
        save(by_setup,f'see_by_setup_{VERSION}.csv'); save(by_ticker,f'see_by_ticker_{VERSION}.csv'); save(diag,f'see_engine_diagnostics_{VERSION}.csv'); save(theme,f'see_theme_rotation_{VERSION}.csv'); save(catalyst,f'see_catalyst_{VERSION}.csv'); save(reg,f'see_regime_{VERSION}.csv')
    else:
        for n in ['by_setup','by_ticker','engine_diagnostics','theme_rotation','catalyst','regime']:
            pd.DataFrame().to_csv(EXPORT/f'see_{n}_{VERSION}.csv',index=False)
    with zipfile.ZipFile(EXPORT/'all.zip','w',zipfile.ZIP_DEFLATED) as z:
        for p in EXPORT.glob(f'*.csv'): z.write(p,p.name)
    status={'ok':True,'version':VERSION,'generated_at':datetime.utcnow().isoformat()+'Z','trades':int(len(trades)),'summary_rows':int(len(summary)),'elite':int(summary.elite.sum()) if not summary.empty else 0,'good':int(summary.good_candidate.sum()) if not summary.empty else 0}
    (OUT/'status.json').write_text(json.dumps(status,indent=2))
    print('[SEE] Done.', status)
if __name__=='__main__': main()
