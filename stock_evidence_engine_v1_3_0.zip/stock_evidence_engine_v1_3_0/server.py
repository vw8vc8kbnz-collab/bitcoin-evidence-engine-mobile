#!/usr/bin/env python3
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
import json, html
VERSION='v1.3.0'; PORT=8798
BASE=Path('/home/ubuntu/stock_evidence_latest') if Path('/home/ubuntu/stock_evidence_latest').exists() else Path.cwd()
EXPORT=BASE/'exports'; DATA=BASE/'data'

def read_status():
    p=DATA/'status.json'
    if p.exists():
        try: return json.loads(p.read_text())
        except Exception: pass
    return {'ok':True,'version':VERSION,'trades':0,'summary_rows':0,'elite':0,'good':0}

def table(path, limit=80):
    if not path.exists(): return '<p>No data yet. Run backtest first.</p>'
    import csv
    rows=list(csv.DictReader(path.open()))
    if not rows: return '<p>No rows.</p>'
    cols=list(rows[0].keys())[:12]
    h='<table><thead><tr>'+''.join(f'<th>{html.escape(c)}</th>' for c in cols)+'</tr></thead><tbody>'
    for r in rows[:limit]:
        h+='<tr>'+''.join(f'<td>{html.escape(str(r.get(c,"")))}</td>' for c in cols)+'</tr>'
    return h+'</tbody></table>'

def page():
    st=read_status()
    summary=EXPORT/f'see_summary_{VERSION}.csv'; elite=EXPORT/f'see_elite_{VERSION}.csv'; setup=EXPORT/f'see_by_setup_{VERSION}.csv'; theme=EXPORT/f'see_theme_rotation_{VERSION}.csv'; catalyst=EXPORT/f'see_catalyst_{VERSION}.csv'; regime=EXPORT/f'see_regime_{VERSION}.csv'
    return f'''<!doctype html><html><head><meta name="viewport" content="width=device-width, initial-scale=1"><title>SEE {VERSION}</title><style>
body{{font-family:-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;background:#f6f7fb;color:#111827;margin:0;padding:22px}}a{{color:#111827}}.hero,.card{{background:white;border-radius:24px;padding:22px;margin:0 0 16px;box-shadow:0 12px 32px rgba(15,23,42,.08)}}.badge{{display:inline-block;background:#111827;color:white;border-radius:999px;padding:7px 12px;font-weight:800}}h1{{margin:10px 0 5px;font-size:32px}}.grid{{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}}.metric{{background:#f8fafc;border-radius:18px;padding:16px}}.big{{font-size:30px;font-weight:900}}small{{color:#64748b}}table{{border-collapse:collapse;width:100%;font-size:13px}}th,td{{padding:8px;border-bottom:1px solid #e5e7eb;text-align:left;white-space:nowrap}}.scroll{{overflow-x:auto}}@media(max-width:700px){{.grid{{grid-template-columns:1fr 1fr}}}}
</style></head><body><div class="hero"><span class="badge">Stock Evidence Engine {VERSION}</span><h1>Narrative Momentum Intelligence</h1><p>Core intelligence release: Catalyst proxy + Theme Rotation + Regime scoring bovenop bewezen momentum/relative-strength engines.</p><p><a href="/exports/all.zip">Download audit export ZIP</a> · <a href="/health">Health</a></p></div><div class="grid"><div class="metric"><div class="big">{st.get('trades',0)}</div><small>Trades</small></div><div class="metric"><div class="big">{st.get('summary_rows',0)}</div><small>Summary rows</small></div><div class="metric"><div class="big">{st.get('elite',0)}</div><small>Elite</small></div><div class="metric"><div class="big">{st.get('good',0)}</div><small>Good</small></div></div><div class="card"><h2>Elite</h2><div class="scroll">{table(elite,80)}</div></div><div class="card"><h2>By Setup</h2><div class="scroll">{table(setup,80)}</div></div><div class="card"><h2>Theme Rotation</h2><div class="scroll">{table(theme,80)}</div></div><div class="card"><h2>Catalyst Proxy</h2><div class="scroll">{table(catalyst,80)}</div></div><div class="card"><h2>Regime</h2><div class="scroll">{table(regime,20)}</div></div><div class="card"><h2>Summary</h2><div class="scroll">{table(summary,100)}</div></div></body></html>'''
class H(BaseHTTPRequestHandler):
    def sendb(self,code,body,ctype='text/html; charset=utf-8'):
        if isinstance(body,str): body=body.encode('utf-8')
        self.send_response(code); self.send_header('Content-Type',ctype); self.send_header('Content-Length',str(len(body))); self.end_headers();
        if self.command!='HEAD': self.wfile.write(body)
    def do_HEAD(self): self.do_GET()
    def do_GET(self):
        if self.path.startswith('/health'): self.sendb(200,json.dumps(read_status()),'application/json')
        elif self.path.startswith('/exports/all.zip'):
            p=EXPORT/'all.zip'
            if p.exists(): self.sendb(200,p.read_bytes(),'application/zip')
            else: self.sendb(404,'missing export')
        else: self.sendb(200,page())
HTTPServer(('0.0.0.0',PORT),H).serve_forever()
