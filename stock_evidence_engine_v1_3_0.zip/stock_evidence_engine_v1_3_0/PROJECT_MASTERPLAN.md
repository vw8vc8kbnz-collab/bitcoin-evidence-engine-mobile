# SEE v1.3.0 Masterplan

Goal: test whether narrative/catalyst/theme/regime intelligence improves the already proven momentum + relative strength alpha stack.

Locked deployment baseline:
- `/home/ubuntu/stock_evidence_latest`
- stdlib `server.py` dashboard, port 8798
- no uvicorn/FastAPI for dashboard
- `install.sh` always writes systemd service
- `run_backtest.sh` always uses fixed `venv/bin/python`

Core engines:
- momentum_continuation_legacy
- relative_strength_leader
- momentum_rs_continuation
- breakout_continuation
- volume_expansion_followthrough
- theme_momentum_leader
- catalyst_momentum_proxy

Exports include summary/trades/elite/usable/by_setup/by_ticker/engine_diagnostics/theme_rotation/catalyst/regime in one `exports/all.zip`.
