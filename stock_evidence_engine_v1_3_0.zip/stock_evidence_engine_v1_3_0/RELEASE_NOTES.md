# v1.3.0
- Adds Catalyst proxy scoring
- Adds Theme Rotation scoring/export
- Adds Regime scoring/export using SPY/QQQ
- Adds theme/catalyst momentum test setups
- Keeps v1.2.1 stable deployment baseline
