from __future__ import annotations
from fastapi import APIRouter
import asyncio
import math
import json
from app.db.database import db
from app.services.sync_service import SyncService
from app.services.data_foundation_service import DataFoundationService
from app.services.audit_service import AuditService
from app.services.forecast_service import ForecastService
from app.services.health_service import HealthService
from app.services.time_machine_service import TimeMachineService
from app.services.evidence_attribution_service import EvidenceAttributionService
from app.services.time_machine_learning_service import TimeMachineLearningService
from app.services.native_core_service import NativeCoreService
from app.services.historical_memory_service import HistoricalMemoryService
from app.services.seed_export_service import SeedExportService
from app.services.time_machine_export_service import TimeMachineExportService
from app.core.logger import log
from app.core.config import settings
from app.core.runtime_locks import sync_lock, tm_priority_event
from app.core.debug import append_jsonl
from pathlib import Path
from fastapi.responses import FileResponse


def _clean_for_json(obj):
    """FastAPI refuses NaN/Inf values. DuckDB/Pandas can return them when some
    evidence layers are still empty. Convert all non-finite floats to None so
    the dashboard never collapses into API error while sync is running.
    """
    if obj is None:
        return None
    if isinstance(obj, float):
        return obj if math.isfinite(obj) else None
    if isinstance(obj, int) or isinstance(obj, bool) or isinstance(obj, str):
        return obj
    if isinstance(obj, dict):
        return {str(k): _clean_for_json(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_clean_for_json(v) for v in obj]
    try:
        # pandas Timestamp / numpy scalars / datetime objects
        if hasattr(obj, "isoformat"):
            return obj.isoformat()
        if hasattr(obj, "item"):
            return _clean_for_json(obj.item())
    except Exception:
        pass
    return str(obj)


def _safe_df(sql: str, params=None):
    try:
        return db.df(sql, params or []).to_dict('records')
    except Exception as exc:
        log.exception("Dashboard query failed: %s", exc)
        return []


def _safe_one(sql: str, params=None):
    try:
        return db.fetchone(sql, params or [])
    except Exception as exc:
        log.exception("Dashboard scalar query failed: %s", exc)
        return None

def _real_candle_range() -> tuple | None:
    """Authoritative candle count for UI/health.

    V10.16.15: the mobile dashboard may never rely on cached sync_state for
    Historical Memory. The source of truth is always raw_candles in the shared
    DuckDB database at /home/ubuntu/bitcoin_evidence_data.
    """
    return _safe_one("""
        SELECT MIN(open_time), MAX(open_time), COUNT(*)
        FROM raw_candles
        WHERE source='binance' AND symbol=? AND interval='1h'
    """, [settings.symbol])

def _authoritative_history_payload() -> dict:
    row = _real_candle_range()
    target = int(getattr(settings, 'historical_target_rows_1h', 70000))
    count = int(row[2] or 0) if row else 0
    min_ts = int(row[0]) if row and row[0] is not None else None
    max_ts = int(row[1]) if row and row[1] is not None else None
    raw_coverage = min(100.0, (count / target) * 100.0) if target else 0.0
    complete = bool(count >= target or (min_ts is not None and min_ts <= int(settings.historical_start_ms) + 2 * 3600000))
    coverage = 100.0 if complete else raw_coverage
    return {
        "symbol": settings.symbol,
        "interval": "1h",
        "stored_rows": count,
        "rows": count,
        "target_rows": target,
        "target_years": settings.historical_target_years,
        "min_ts": min_ts,
        "max_ts": max_ts,
        "coverage_pct": round(coverage, 2),
        "raw_coverage_pct": round(raw_coverage, 2),
        "remaining_rows": max(0, target - count),
        "complete": complete,
        "running": False,
        "loading_state": "complete" if complete else "backfill_required",
        "status_label": "Volledig geladen" if complete else "Aanvullen nodig",
        "ui_message": (
            f"Volledig geladen in gedeelde database · {count:,}/{target:,} · 100%"
            if complete else f"Aanvullen nodig · {count:,}/{target:,} · {raw_coverage:.2f}%"
        ),
        "shared_data_dir": str(settings.data_dir),
        "db_path": str(settings.db_path),
        "status_source": "authoritative_raw_candles",
    }


def _external_data_status_payload() -> dict:
    """Cheap, stable evidence-data status for mobile UI and exports.

    This must never call external APIs or heavy rebuilds. It only inspects the
    shared DuckDB warehouse so the phone app can always show what data is truly
    present right now.
    """
    metrics = [
        ("Binance Spot candles", "raw_candles", "binance", "BTCUSDT 1h OHLCV", "core_price"),
        ("Binance Futures funding", "raw_metric_points", "binance_futures", "funding_rate", "futures"),
        ("Binance Futures open interest", "raw_metric_points", "binance_futures", "open_interest_value", "futures"),
        ("Long/Short ratio", "raw_metric_points", "binance_futures", "long_short_ratio", "futures"),
        ("Top position L/S", "raw_metric_points", "binance_futures", "top_position_long_short_ratio", "futures"),
        ("Top account L/S", "raw_metric_points", "binance_futures", "top_account_long_short_ratio", "futures"),
        ("Taker buy/sell ratio", "raw_metric_points", "binance_futures", "taker_buy_sell_ratio", "orderflow"),
        ("Taker delta", "raw_metric_points", "binance_futures", "taker_delta_ratio", "orderflow"),
        ("Futures basis/premium", "raw_metric_points", "binance_futures", "futures_basis_premium_pct", "futures"),
        ("Composite orderbook", "raw_metric_points", "composite_orderbook", "orderbook_imbalance", "orderbook"),
        ("Fear & Greed", "raw_metric_points", "alternative_me", "fear_greed", "sentiment"),
        ("Coinbase premium", "raw_metric_points", "spot_composite", "spot_premium_coinbase_pct", "cross_exchange"),
        ("Kraken premium", "raw_metric_points", "spot_composite", "spot_premium_kraken_pct", "cross_exchange"),
        ("CoinMetrics MVRV", "raw_metric_points", "coinmetrics_community", "CapMVRVCur", "onchain"),
    ]
    rows = []
    for label, table, source, metric, group in metrics:
        try:
            if table == "raw_candles":
                r = _safe_one("SELECT COUNT(*), MIN(open_time), MAX(open_time) FROM raw_candles WHERE source='binance' AND symbol=? AND interval='1h'", [settings.symbol])
            else:
                r = _safe_one("SELECT COUNT(*), MIN(timestamp_ms), MAX(timestamp_ms) FROM raw_metric_points WHERE source=? AND metric=?", [source, metric])
            count = int(r[0] or 0) if r else 0
            min_ms = int(r[1]) if r and r[1] is not None else None
            max_ms = int(r[2]) if r and r[2] is not None else None
        except Exception:
            count, min_ms, max_ms = 0, None, None
        status = "active" if count >= 1000 else ("partial" if count > 0 else "missing")
        rows.append({"label": label, "source": source, "metric": metric, "group": group, "rows": count, "min_ms": min_ms, "max_ms": max_ms, "status": status})
    try:
        f = _safe_one("""
            SELECT COUNT(*),
                   SUM(CASE WHEN funding_rate IS NOT NULL THEN 1 ELSE 0 END),
                   SUM(CASE WHEN open_interest_value IS NOT NULL THEN 1 ELSE 0 END),
                   SUM(CASE WHEN long_short_ratio IS NOT NULL THEN 1 ELSE 0 END),
                   SUM(CASE WHEN taker_buy_sell_ratio IS NOT NULL THEN 1 ELSE 0 END),
                   SUM(CASE WHEN orderbook_imbalance IS NOT NULL THEN 1 ELSE 0 END),
                   SUM(CASE WHEN fear_greed IS NOT NULL THEN 1 ELSE 0 END),
                   SUM(CASE WHEN coinmetrics_mvrv IS NOT NULL THEN 1 ELSE 0 END)
            FROM features WHERE interval='1h'
        """)
        feature_summary = {
            "feature_rows": int(f[0] or 0) if f else 0,
            "funding_rate_rows": int(f[1] or 0) if f else 0,
            "open_interest_rows": int(f[2] or 0) if f else 0,
            "long_short_rows": int(f[3] or 0) if f else 0,
            "taker_rows": int(f[4] or 0) if f else 0,
            "orderbook_rows": int(f[5] or 0) if f else 0,
            "fear_greed_rows": int(f[6] or 0) if f else 0,
            "mvrv_rows": int(f[7] or 0) if f else 0,
        }
    except Exception:
        feature_summary = {}
    active = sum(1 for r in rows if r["status"] == "active")
    partial = sum(1 for r in rows if r["status"] == "partial")
    missing = sum(1 for r in rows if r["status"] == "missing")
    return {"rows": rows, "summary": {"active": active, "partial": partial, "missing": missing, "total": len(rows)}, "features": feature_summary}


def _model_status_payload() -> dict:
    """Cheap cockpit list: which models are active and whether they use real data.

    This is intentionally based on DB coverage, not marketing labels. A model is
    only 'real' when the underlying feature has non-null rows. Otherwise it is
    explicitly shown as proxy/missing.
    """
    ext = _external_data_status_payload()
    features = ext.get("features", {}) or {}
    def n(k):
        try: return int(features.get(k) or 0)
        except Exception: return 0
    rows = [
        {"id":"M_FAST_TWIN","name":"Historical Twin Similarity","group":"historical","status":"active","data_quality":"real","rows":_safe_one("SELECT COUNT(*) FROM raw_candles")[0] if _safe_one("SELECT COUNT(*) FROM raw_candles") else 0,"source":"Binance Spot OHLCV"},
        {"id":"M_MOMENTUM_STACK","name":"Momentum Stack","group":"price","status":"active","data_quality":"real","rows":n("feature_rows"),"source":"OHLCV derived returns"},
        {"id":"M_TREND_STRUCTURE","name":"MA Trend Structure","group":"price","status":"active","data_quality":"real","rows":n("feature_rows"),"source":"OHLCV derived MA50/MA200"},
        {"id":"M_RSI_CONTEXT","name":"RSI Context","group":"price","status":"active","data_quality":"real","rows":n("feature_rows"),"source":"OHLCV derived RSI"},
        {"id":"M_VOLUME_VOLATILITY","name":"Volume / Volatility","group":"price","status":"active","data_quality":"real","rows":n("feature_rows"),"source":"OHLCV volume/volatility"},
        {"id":"M_DRAWDOWN_REGIME","name":"Drawdown Regime","group":"regime","status":"active","data_quality":"real","rows":n("feature_rows"),"source":"OHLCV drawdown/regime"},
        {"id":"M_FUNDING_OI","name":"Funding + Open Interest","group":"futures","status":"active" if n("funding_rate_rows") or n("open_interest_rows") else "proxy","data_quality":"real" if n("funding_rate_rows") or n("open_interest_rows") else "proxy_from_ohlcv","rows":max(n("funding_rate_rows"), n("open_interest_rows")),"source":"Binance Futures"},
        {"id":"M_CROWDING","name":"Long/Short Crowding","group":"futures","status":"active" if n("long_short_rows") else "proxy","data_quality":"real" if n("long_short_rows") else "proxy_from_ohlcv","rows":n("long_short_rows"),"source":"Binance Futures Long/Short"},
        {"id":"M_TAKER_FLOW","name":"Taker Flow / CVD","group":"orderflow","status":"active" if n("taker_rows") else "proxy","data_quality":"real" if n("taker_rows") else "proxy_from_ohlcv","rows":n("taker_rows"),"source":"Binance Futures taker flow"},
        {"id":"M_ORDERBOOK_IMBALANCE","name":"Orderbook Imbalance","group":"orderflow","status":"active" if n("orderbook_rows") else "proxy","data_quality":"real" if n("orderbook_rows") else "proxy_from_ohlcv","rows":n("orderbook_rows"),"source":"Composite orderbook"},
        {"id":"M_SENTIMENT_FNG","name":"Fear & Greed","group":"sentiment","status":"active" if n("fear_greed_rows") else "missing","data_quality":"real" if n("fear_greed_rows") else "missing","rows":n("fear_greed_rows"),"source":"Alternative.me historical"},
        {"id":"M_ONCHAIN_MVRV","name":"On-chain MVRV","group":"onchain","status":"active" if n("mvrv_rows") else "missing","data_quality":"real" if n("mvrv_rows") else "missing","rows":n("mvrv_rows"),"source":"CoinMetrics / API key needed"},
    ]
    try:
        scores = _safe_df("SELECT model_id, horizon, total, hitrate, avg_score FROM model_scores ORDER BY total DESC LIMIT 200")
    except Exception:
        scores = []
    active = sum(1 for r in rows if r["status"] == "active")
    proxy = sum(1 for r in rows if r["status"] == "proxy")
    missing = sum(1 for r in rows if r["status"] == "missing")
    return {"rows": rows, "summary": {"active": active, "proxy": proxy, "missing": missing, "total": len(rows)}, "scores": scores}


def _parse_sync_progress_value(value: str | None) -> dict:
    """Parse sync_state progress strings like 'rows=123 pages=4 last_ts=...'."""
    out = {}
    if not value:
        return out
    try:
        for part in str(value).replace(',', ' ').split():
            if '=' in part:
                k, v = part.split('=', 1)
                try:
                    out[k] = int(float(v))
                except Exception:
                    out[k] = v
    except Exception:
        pass
    return out

def _count_metric(source: str, metric: str) -> int:
    r = _safe_one("SELECT COUNT(*) FROM raw_metric_points WHERE source=? AND metric=?", [source, metric])
    return int(r[0] or 0) if r else 0

def _sync_state_map() -> dict:
    rows = _safe_df("SELECT key, value, updated_at FROM sync_state")
    return {str(r.get('key')): r for r in rows}

def _mobile_background_progress_payload() -> dict:
    """Single cheap progress endpoint for everything that can be loading in background.

    It never calls external providers and never rebuilds features. It only reads
    DuckDB counts + sync_state. This is what the phone UI should poll to avoid
    vague 'herladen' or long blank screens.
    """
    hist = _authoritative_history_payload()
    candle_rows = int(hist.get('rows') or hist.get('stored_rows') or 0)
    target_rows = int(hist.get('target_rows') or 70000)
    candle_pct = 100.0 if hist.get('complete') else (min(100.0, candle_rows / max(1, target_rows) * 100.0))
    native = NativeCoreService().status()
    tm_counts = _safe_one("SELECT COUNT(*), COUNT(DISTINCT batch_id), MAX(created_at) FROM time_machine_tests")
    fs = _safe_one("SELECT COUNT(*), MAX(created_at) FROM time_machine_feature_snapshots")
    ss = _safe_one("SELECT COUNT(*), MAX(last_seen_at) FROM time_machine_signal_scores")
    state = _sync_state_map()

    # Historical external warehouse coverage. Be honest: active if enough rows,
    # partial when present, missing if absent/API-key needed. Percentage is a
    # practical fill estimate against expected historical cadence.
    expected_hourly = max(1, candle_rows)
    expected_funding = max(1, candle_rows // 8)
    providers = [
        ('Binance Spot candles', 'binance', 'raw_candles', candle_rows, target_rows, 'active' if candle_rows >= target_rows else 'partial'),
        ('Funding', 'binance_futures', 'funding_rate', _count_metric('binance_futures','funding_rate'), expected_funding, None),
        ('Open Interest', 'binance_futures', 'open_interest_value', _count_metric('binance_futures','open_interest_value'), expected_hourly, None),
        ('Long/Short', 'binance_futures', 'long_short_ratio', _count_metric('binance_futures','long_short_ratio'), expected_hourly, None),
        ('Top Position L/S', 'binance_futures', 'top_position_long_short_ratio', _count_metric('binance_futures','top_position_long_short_ratio'), expected_hourly, None),
        ('Top Account L/S', 'binance_futures', 'top_account_long_short_ratio', _count_metric('binance_futures','top_account_long_short_ratio'), expected_hourly, None),
        ('Taker Flow', 'binance_futures', 'taker_buy_sell_ratio', _count_metric('binance_futures','taker_buy_sell_ratio'), expected_hourly, None),
        ('Coinbase Premium', 'spot_composite', 'spot_premium_coinbase_pct', _count_metric('spot_composite','spot_premium_coinbase_pct'), expected_hourly, None),
        ('Kraken Premium', 'spot_composite', 'spot_premium_kraken_pct', _count_metric('spot_composite','spot_premium_kraken_pct'), expected_hourly, None),
        ('Fear & Greed', 'alternative_me', 'fear_greed', _count_metric('alternative_me','fear_greed'), max(1, candle_rows // 24), None),
        ('Orderbook', 'composite_orderbook', 'orderbook_imbalance', _count_metric('composite_orderbook','orderbook_imbalance'), 1000, None),
        ('MVRV / On-chain', 'coinmetrics_community', 'CapMVRVCur', _count_metric('coinmetrics_community','CapMVRVCur'), max(1, candle_rows // 24), 'api_key_needed'),
    ]
    pdata=[]
    for label, source, metric, rows, target, forced in providers:
        pct = min(100.0, float(rows) / max(1, int(target)) * 100.0)
        status = forced or ('active' if pct >= 90 else ('partial' if rows > 0 else 'missing'))
        # Known APIs with limited/free windows should not pretend to be finished.
        pdata.append({'label': label, 'source': source, 'metric': metric, 'rows': int(rows), 'target_rows': int(target), 'coverage_pct': round(pct, 2), 'status': status})
    external_pct = round(sum(p['coverage_pct'] for p in pdata if p['status'] != 'api_key_needed') / max(1, len([p for p in pdata if p['status'] != 'api_key_needed'])), 2)

    # Use sync_state to show live background phase/rows. These are text markers,
    # not blockers.
    progress_rows = []
    for k, r in sorted(state.items()):
        if k.startswith('external_progress_') or k in ('external_evidence_backfill','external_evidence_backfill_progress','external_evidence_daemon','sync_phase','historical_memory','startup_sync_status','manual_sync_status','coinmetrics_status'):
            progress_rows.append({'key': k, 'value': r.get('value'), 'updated_at': r.get('updated_at'), 'parsed': _parse_sync_progress_value(r.get('value'))})
    progress_rows = progress_rows[-60:]
    sync_phase = state.get('sync_phase', {}).get('value') if state else None
    external_state = (state.get('external_evidence_backfill_progress') or state.get('external_evidence_backfill') or state.get('external_evidence_daemon') or {})

    boot_steps = [
        {'key':'ui','label':'Mobiele UI', 'status':'done', 'pct':100},
        {'key':'candles','label':'70k candles', 'status':'done' if candle_pct >= 100 else 'loading', 'pct':round(candle_pct,1), 'detail': f"{candle_rows:,}/{target_rows:,}"},
        {'key':'native','label':'Native core', 'status':'done' if native.get('available') else 'loading', 'pct':100 if native.get('available') else 40},
        {'key':'forecast','label':'Forecast cache', 'status':'loading' if bool(sync_lock.locked()) else 'done', 'pct':65 if bool(sync_lock.locked()) else 100, 'detail': sync_phase or 'idle'},
        {'key':'external','label':'Externe evidence', 'status':'loading' if external_pct < 85 else 'done', 'pct':external_pct, 'detail': external_state.get('value') or 'warehouse vullen op achtergrond'},
    ]
    overall = round(sum(float(x.get('pct') or 0) for x in boot_steps) / len(boot_steps), 1)
    return _clean_for_json({
        'ok': True,
        'engine_version': settings.engine_version,
        'overall_pct': overall,
        'sync_busy': bool(sync_lock.locked()),
        'phase': sync_phase or 'idle',
        'history': hist,
        'native': native,
        'time_machine': {
            'tests': int(tm_counts[0] or 0) if tm_counts else 0,
            'batches': int(tm_counts[1] or 0) if tm_counts else 0,
            'snapshots': int(fs[0] or 0) if fs else 0,
            'signals': int(ss[0] or 0) if ss else 0,
        },
        'boot_steps': boot_steps,
        'external': {'overall_pct': external_pct, 'providers': pdata, 'progress': progress_rows},
        'message': 'Instant boot gebruikt lokale DuckDB; externe data vult door op achtergrond.'
    })

router = APIRouter(prefix="/api")


@router.get("/health")
def api_health():
    """Stable VPS/update health endpoint.

    Older update scripts poll /api/health. Keep this endpoint permanently so
    new releases can be verified without guessing route names. It also reports
    the persistent warehouse path and the real candle/test counts.
    """
    candle_range = _real_candle_range()
    tm_counts = _safe_one("SELECT COUNT(*), COUNT(DISTINCT batch_id), MAX(created_at) FROM time_machine_tests")
    feature_counts = _safe_one("SELECT COUNT(*), MAX(created_at) FROM time_machine_feature_snapshots")
    signal_counts = _safe_one("SELECT COUNT(*), MAX(last_seen_at) FROM time_machine_signal_scores")
    return _clean_for_json({
        "ok": True,
        "status": "ok",
        "engine_version": settings.engine_version,
        "data_dir": str(settings.data_dir),
        "db_path": str(settings.db_path),
        "raw_candles": int(candle_range[2] or 0) if candle_range else 0,
        "raw_candles_min_ms": candle_range[0] if candle_range else None,
        "raw_candles_max_ms": candle_range[1] if candle_range else None,
        "time_machine_tests": int(tm_counts[0] or 0) if tm_counts else 0,
        "time_machine_batches": int(tm_counts[1] or 0) if tm_counts else 0,
        "time_machine_feature_snapshots": int(feature_counts[0] or 0) if feature_counts else 0,
        "time_machine_signal_scores": int(signal_counts[0] or 0) if signal_counts else 0,
        "native_core": NativeCoreService().status(),
        "history": _authoritative_history_payload(),
    })



@router.get("/mobile/quick")
def mobile_quick():
    """V10.16.23 first-paint heartbeat for iPhone/PWA.

    This endpoint intentionally avoids forecast, accuracy, evidence-status and
    wide queries. It must stay fast even while external evidence backfill or
    Random1000 is running.
    """
    candle_range = _real_candle_range()
    tm_counts = _safe_one("SELECT COUNT(*), COUNT(DISTINCT batch_id) FROM time_machine_tests")
    feature_counts = _safe_one("SELECT COUNT(*) FROM time_machine_feature_snapshots")
    signal_counts = _safe_one("SELECT COUNT(*) FROM time_machine_signal_scores")
    ticker_price = _safe_one("SELECT value FROM raw_metric_points WHERE source='binance_ticker' AND metric='btc_last_price' ORDER BY timestamp_ms DESC LIMIT 1")
    latest_candle = _safe_one("SELECT close, open_time FROM raw_candles WHERE source='binance' AND symbol=? AND interval='1h' ORDER BY open_time DESC LIMIT 1", [settings.symbol])
    price = ticker_price or latest_candle
    native_status = NativeCoreService().status()
    return _clean_for_json({
        "ok": True,
        "engine_version": settings.engine_version,
        "sync_busy": bool(sync_lock.locked()),
        "btc_price": float(price[0]) if price and price[0] is not None else None,
        "raw_candles": int(candle_range[2] or 0) if candle_range else 0,
        "raw_candles_min_ms": candle_range[0] if candle_range else None,
        "raw_candles_max_ms": candle_range[1] if candle_range else None,
        "target_rows": 70000,
        "native_available": bool(native_status.get("available")),
        "learning": {
            "time_machine_tests": int(tm_counts[0] or 0) if tm_counts else 0,
            "time_machine_batches": int(tm_counts[1] or 0) if tm_counts else 0,
            "feature_snapshots": int(feature_counts[0] or 0) if feature_counts else 0,
            "signal_events": int(signal_counts[0] or 0) if signal_counts else 0,
        }
    })

@router.get("/mobile/status-fast")
def mobile_status_fast():
    """Ultra-stable mobile status endpoint.

    Used by the iPhone UI as the primary heartbeat. It only does cheap SQL
    counts and therefore should stay responsive while external evidence backfill,
    Random1000, or forecast work is running.
    """
    candle_range = _real_candle_range()
    tm_counts = _safe_one("SELECT COUNT(*), COUNT(DISTINCT batch_id), MAX(created_at) FROM time_machine_tests")
    feature_counts = _safe_one("SELECT COUNT(*), MAX(created_at) FROM time_machine_feature_snapshots")
    signal_counts = _safe_one("SELECT COUNT(*), MAX(last_seen_at) FROM time_machine_signal_scores")
    ticker_price = _safe_one("SELECT value FROM raw_metric_points WHERE source='binance_ticker' AND metric='btc_last_price' ORDER BY timestamp_ms DESC LIMIT 1")
    latest_candle = _safe_one("SELECT close, open_time FROM raw_candles WHERE source='binance' AND symbol=? AND interval='1h' ORDER BY open_time DESC LIMIT 1", [settings.symbol])
    price = ticker_price or latest_candle
    return _clean_for_json({
        "ok": True,
        "engine_version": settings.engine_version,
        "api_status": "busy" if sync_lock.locked() else "ok",
        "sync_busy": bool(sync_lock.locked()),
        "btc_price": float(price[0]) if price and price[0] is not None else None,
        "history": _authoritative_history_payload(),
        "native": NativeCoreService().status(),
        "learning": {
            "time_machine_tests": int(tm_counts[0] or 0) if tm_counts else 0,
            "time_machine_batches": int(tm_counts[1] or 0) if tm_counts else 0,
            "latest_test_at": tm_counts[2] if tm_counts else None,
            "feature_snapshots": int(feature_counts[0] or 0) if feature_counts else 0,
            "latest_feature_snapshot_at": feature_counts[1] if feature_counts else None,
            "signal_events": int(signal_counts[0] or 0) if signal_counts else 0,
            "latest_signal_at": signal_counts[1] if signal_counts else None,
        },
        "candle_range": {"from_ms": candle_range[0] if candle_range else None, "to_ms": candle_range[1] if candle_range else None, "rows": int(candle_range[2] or 0) if candle_range else 0},
        # V10.16.21: keep this heartbeat ultra-light. Do not include external_data here;
        # those counts can be inspected through /api/evidence/data-sources and export ZIPs.
        "sync_state": _safe_df("SELECT key, value, updated_at FROM sync_state WHERE key IN ('historical_memory','sync_phase','startup_sync_status','manual_sync_status','external_evidence_backfill') ORDER BY updated_at DESC LIMIT 8"),
    })


@router.get("/mobile/background-progress")
def mobile_background_progress():
    return _mobile_background_progress_payload()

@router.get("/mobile/evidence-status")
def mobile_evidence_status():
    """Separate, non-critical evidence status. If this is slow or fails, the core app still loads."""
    try:
        return _clean_for_json({"ok": True, "external_data": _external_data_status_payload(), "model_status": _model_status_payload()})
    except Exception as exc:
        log.exception("Mobile evidence status failed: %s", exc)
        return _clean_for_json({"ok": False, "error": str(exc), "external_data": {"rows": [], "summary": {}, "features": {}}, "model_status": {"rows": [], "summary": {}}})

@router.get("/dashboard/status")
def dashboard_status():
    """Fast, lightweight dashboard status.

    This endpoint avoids heavy archive/model queries so the frontend can always
    keep price/sync/integrity visible even while the full dashboard is being
    refreshed or sync is active.
    """
    try:
        foundation = DataFoundationService()
        readiness = foundation.readiness()
        integrity = foundation.data_integrity(record_state=False)
        ticker_price = _safe_one("SELECT value FROM raw_metric_points WHERE source='binance_ticker' AND metric='btc_last_price' ORDER BY timestamp_ms DESC LIMIT 1")
        latest_candle = _safe_one("SELECT close, open_time FROM raw_candles WHERE source='binance' AND symbol=? AND interval='1h' ORDER BY open_time DESC LIMIT 1", [settings.symbol])
        latest_feature = _safe_df("""
            SELECT timestamp_ms, close, regime, data_completeness, funding_rate, open_interest_value,
                   open_interest_change_24h, long_short_ratio, taker_buy_sell_ratio, orderbook_imbalance,
                   orderbook_spread, taker_delta_ratio, futures_basis_premium_pct, top_position_long_short_ratio,
                   top_account_long_short_ratio, cross_exchange_spread_pct, spot_premium_kraken_pct,
                   spot_premium_coinbase_pct, coinmetrics_mvrv, fear_greed, drawdown_from_ath, cycle_progress,
                   volume_zscore, volume_ratio_24, range_pct, candle_body_pct
            FROM features WHERE interval='1h' ORDER BY timestamp_ms DESC LIMIT 1
        """)
        sync_state = _safe_df("SELECT key, value, updated_at FROM sync_state")
        price = ticker_price or (latest_candle if latest_candle else None)
        return _clean_for_json({
            "api_status": "busy" if sync_lock.locked() else "ok",
            "btc_price": float(price[0]) if price and price[0] is not None else None,
            "latest_feature": latest_feature[0] if latest_feature else None,
            "sync_state": sync_state,
            "readiness": readiness,
            "data_integrity": integrity,
            "sync_busy": sync_lock.locked(),
            "history": _authoritative_history_payload(),
        })
    except Exception as exc:
        log.exception("Dashboard status failed: %s", exc)
        return _clean_for_json({"api_status":"error", "error":str(exc), "sync_state": _safe_df("SELECT key, value, updated_at FROM sync_state")})

@router.get("/dashboard")
def dashboard():
    try:
        # If a sync owns the pipeline, return a lightweight but useful payload.
        # Keep cached/visible price + sync state instead of forcing the frontend
        # into a red timeout/error state.
        if sync_lock.locked():
            status = dashboard_status()
            if isinstance(status, dict):
                status.setdefault("latest_items", [])
                status.setdefault("data_health", HealthService().list())
                status["message"] = "sync/forecast busy; lightweight status returned"
                return _clean_for_json(status)
        latest_run = _safe_one("SELECT run_id FROM forecast_runs ORDER BY created_at_ms DESC LIMIT 1")
        latest_items=[]
        if latest_run:
            latest_items = _safe_df("""
                SELECT * FROM forecast_items WHERE run_id=?
                ORDER BY CASE horizon WHEN '1h' THEN 1 WHEN '4h' THEN 2 WHEN '8h' THEN 3 WHEN '24h' THEN 4 WHEN '7d' THEN 5 WHEN '30d' THEN 6 WHEN '90d' THEN 7 ELSE 99 END
            """, [latest_run[0]])
        runs = _safe_df("SELECT * FROM forecast_runs ORDER BY created_at_ms DESC LIMIT 25")
        archive = _safe_df("SELECT * FROM forecast_items ORDER BY run_id DESC, due_at_ms ASC LIMIT 150")
        acc = _safe_df("""
            SELECT horizon, COUNT(*) AS total, SUM(CASE WHEN direction_correct THEN 1 ELSE 0 END) AS correct,
                   AVG(CASE WHEN direction_correct THEN 1.0 ELSE 0.0 END) AS hitrate,
                   AVG(ABS(price_error_pct)) AS avg_abs_price_error
            FROM forecast_items WHERE status='resolved' GROUP BY horizon ORDER BY CASE horizon WHEN '1h' THEN 1 WHEN '4h' THEN 2 WHEN '8h' THEN 3 WHEN '24h' THEN 4 WHEN '7d' THEN 5 WHEN '30d' THEN 6 WHEN '90d' THEN 7 ELSE 99 END
        """)
        model_scores = _safe_df("SELECT * FROM model_scores ORDER BY hitrate DESC, total DESC LIMIT 50")
        ticker_price = _safe_one("SELECT value FROM raw_metric_points WHERE source='binance_ticker' AND metric='btc_last_price' ORDER BY timestamp_ms DESC LIMIT 1")
        price = ticker_price or _safe_one("SELECT close FROM raw_candles WHERE source='binance' AND symbol='BTCUSDT' AND interval='1h' ORDER BY open_time DESC LIMIT 1")
        latest_feature = _safe_df("""
            SELECT timestamp_ms, close, regime, data_completeness, funding_rate, open_interest_value,
                   open_interest_change_24h, long_short_ratio, taker_buy_sell_ratio, orderbook_imbalance,
                   orderbook_spread, taker_delta_ratio, futures_basis_premium_pct, top_position_long_short_ratio,
                   top_account_long_short_ratio, cross_exchange_spread_pct, spot_premium_kraken_pct,
                   spot_premium_coinbase_pct, coinmetrics_mvrv, fear_greed, drawdown_from_ath, cycle_progress,
                   volume_zscore, volume_ratio_24, range_pct, candle_body_pct
            FROM features WHERE interval='1h' ORDER BY timestamp_ms DESC LIMIT 1
        """)
        composite_orderbook = _safe_df("""
            SELECT timestamp_ms, value, metadata
            FROM raw_metric_points
            WHERE source='composite_orderbook' AND metric='orderbook_imbalance'
            ORDER BY timestamp_ms DESC LIMIT 1
        """)
        sync_state = _safe_df("SELECT key, value, updated_at FROM sync_state")
        foundation = DataFoundationService()
        readiness = foundation.readiness()
        integrity = foundation.data_integrity(record_state=False)
        result = {
            "btc_price": float(price[0]) if price and price[0] is not None else None,
            "latest_feature": latest_feature[0] if latest_feature else None,
            "latest_items": latest_items,
            "runs": runs,
            "archive": archive,
            "accuracy": acc,
            "model_scores": model_scores,
            "data_health": HealthService().list(),
            "composite_orderbook": composite_orderbook[0] if composite_orderbook else None,
            "sync_state": sync_state,
            "readiness": readiness,
            "data_integrity": integrity,
            "api_status": "ok",
        }
        return _clean_for_json(result)
    except Exception as exc:
        log.exception("Dashboard API hard failure: %s", exc)
        return _clean_for_json({
            "api_status":"error",
            "error":str(exc),
            "btc_price":None,
            "latest_items":[],
            "data_health":HealthService().list(),
            "sync_state":_safe_df("SELECT key, value, updated_at FROM sync_state"),
        })

@router.post("/sync")
async def sync():
    log.info("Manual sync+forecast requested from dashboard")
    append_jsonl("sync_button_audit.jsonl", {"event": "api_sync_entered"})
    now_fn = __import__("app.core.time_utils", fromlist=["utc_now"]).utc_now
    if sync_lock.locked():
        append_jsonl("sync_button_audit.jsonl", {"event": "api_sync_rejected_busy"})
        return _clean_for_json({"created": False, "reason": "sync already running", "status": "busy"})
    async with sync_lock:
        try:
            db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ["manual_sync_status", "syncing", now_fn()])
            append_jsonl("sync_button_audit.jsonl", {"event": "api_sync_phase", "phase": "sync_forecast_fast_start"})
            result = await DataFoundationService().run_forecast_pipeline(source="manual")
            append_jsonl("sync_button_audit.jsonl", {"event": "api_sync_phase", "phase": "data_foundation_done", "result": result})
            log.info("Manual Data Foundation sync completed. forecast_created=%s run=%s reason=%s", result.get("created"), result.get("run_id"), result.get("reason"))
            append_jsonl("sync_button_audit.jsonl", {"event": "api_sync_completed", "forecast_created": result.get("created"), "run_id": result.get("run_id"), "reason": result.get("reason")})
            return _clean_for_json(result)
        except Exception as exc:
            log.exception("Manual sync+forecast failed: %s", exc)
            append_jsonl("sync_button_audit.jsonl", {"event": "api_sync_failed", "error": str(exc)})
            db.execute("INSERT OR REPLACE INTO sync_state VALUES (?, ?, ?)", ["manual_sync_status", "error", now_fn()])
            return _clean_for_json({"created": False, "error": str(exc), "reason": str(exc)})

@router.post("/forecast")
def forecast():
    try:
        return _clean_for_json(ForecastService().create_run())
    except Exception as exc:
        log.exception("Manual forecast failed: %s", exc)
        return {"created": False, "reason": str(exc)}

@router.post("/audit")
def audit():
    return AuditService().audit_due_predictions()

@router.get("/data/readiness")
def data_readiness():
    return _clean_for_json(DataFoundationService().readiness())

@router.get("/data/integrity")
def data_integrity():
    return _clean_for_json(DataFoundationService().data_integrity())



@router.get("/native/status")
def native_status():
    return _clean_for_json(NativeCoreService().status())

@router.get("/time-machine/chart")
def time_machine_chart(timeframe: str = "1h", limit: int = 5000, start_ms: int | None = None, end_ms: int | None = None):
    return TimeMachineService().chart_points(timeframe=timeframe, limit=limit, start_ms=start_ms, end_ms=end_ms)

@router.post("/time-machine/resolve")
def time_machine_resolve(payload: dict):
    return TimeMachineService().resolve_click(int(payload.get("timestamp_ms")))

@router.post("/time-machine/run")
def time_machine_run(payload: dict):
    try:
        ts = int(payload.get("timestamp_ms"))
        log.info("Time Machine manual run requested timestamp_ms=%s", ts)
        result = TimeMachineService().run(ts, bool(payload.get("reveal", True)), persist=bool(payload.get("persist", True)), source="manual", hydrate_context=bool(payload.get("hydrate_context", False)))
        log.info("Time Machine manual run finished ok=%s items=%s", result.get("ok"), len(result.get("items", [])) if isinstance(result, dict) else "?")
        return _clean_for_json(result)
    except Exception as exc:
        tm_priority_event.clear()
        log.exception("Time Machine manual run failed: %s", exc)
        return _clean_for_json({"ok": False, "reason": str(exc), "items": []})

@router.post("/time-machine/random-tests")
def time_machine_random_tests(payload: dict):
    try:
        return _clean_for_json(TimeMachineService().random_tests(int(payload.get("count", 100))))
    except Exception as exc:
        tm_priority_event.clear()
        log.exception("Time Machine random tests failed: %s", exc)
        return _clean_for_json({"ok": False, "reason": str(exc), "summary": {}, "native_status": NativeCoreService().status()})

@router.get("/time-machine/random-status")
def time_machine_random_status(batch_id: str | None = None):
    return _clean_for_json(TimeMachineService().random_batch_status(batch_id))



@router.get("/time-machine/export/latest")
def time_machine_export_latest():
    return _clean_for_json(TimeMachineExportService().latest_info())

@router.get("/time-machine/export/list")
def time_machine_export_list(limit: int = 25):
    return _clean_for_json(TimeMachineExportService().list_exports(limit=limit))

@router.post("/time-machine/reset")
def time_machine_reset(payload: dict | None = None):
    payload = payload or {}
    delete_exports = bool(payload.get("delete_exports", False))
    try:
        tm_priority_event.clear()
    except Exception:
        pass
    return _clean_for_json(TimeMachineExportService().reset_warehouse(delete_exports=delete_exports))

@router.get("/time-machine/export/download")
def time_machine_export_download(batch_id: str | None = None):
    path = TimeMachineExportService().export_path(batch_id)
    if not path or not path.exists():
        return _clean_for_json({"ok": False, "reason": "Nog geen Time Machine random export gevonden. Draai eerst Random100 of Random1000."})
    return FileResponse(str(path), media_type="application/zip", filename=path.name)

@router.get("/time-machine/stats")
def time_machine_stats():
    return TimeMachineService().stats()


@router.get("/debug/snapshot")
def debug_snapshot():
    """Human-readable debug state for support/log exports."""
    try:
        candle_range = _safe_one("SELECT MIN(open_time), MAX(open_time), COUNT(*) FROM raw_candles WHERE source='binance' AND symbol='BTCUSDT' AND interval='1h'")
        metric_counts = _safe_df("SELECT source, metric, COUNT(*) AS rows, MAX(timestamp_ms) AS last_ts FROM raw_metric_points GROUP BY source, metric ORDER BY source, metric")
        feature_range = _safe_one("SELECT MIN(timestamp_ms), MAX(timestamp_ms), COUNT(*) FROM features WHERE interval='1h'")
        latest_tm = _safe_df("SELECT horizon, COUNT(*) AS tests, SUM(CASE WHEN target_reached THEN 1 ELSE 0 END) AS wins FROM time_machine_tests GROUP BY horizon ORDER BY horizon")
        return _clean_for_json({
            "engine_version": settings.engine_version,
            "db_path": str(settings.db_path),
            "candle_range": candle_range,
            "feature_range": feature_range,
            "metric_counts": metric_counts,
            "time_machine_scoreboard": latest_tm,
            "time_machine_learning_snapshots": _safe_one("SELECT COUNT(*), MAX(created_at) FROM time_machine_feature_snapshots"),
            "time_machine_learning_signals": _safe_one("SELECT COUNT(*), MAX(last_seen_at) FROM time_machine_signal_scores"),
            "data_health": HealthService().list(),
            "sync_state": _safe_df("SELECT key, value, updated_at FROM sync_state"),
        })
    except Exception as exc:
        log.exception("Debug snapshot failed: %s", exc)
        return {"error": str(exc)}


@router.post("/debug/frontend-event")
def frontend_event(payload: dict):
    """Small frontend diagnostics endpoint used by the Time Machine chart.
    It makes click/drag/pointer problems visible in exported logs without
    disturbing the UI if logging fails.
    """
    try:
        from app.core.debug import append_jsonl
        append_jsonl("frontend_audit.jsonl", {"event": "frontend", **(payload or {})})
        return {"ok": True}
    except Exception as exc:
        log.warning("Frontend debug event failed: %s", exc)
        return {"ok": False, "reason": str(exc)}


@router.get("/evidence-attribution")
def evidence_attribution(min_total: int = 3):
    try:
        return _clean_for_json(EvidenceAttributionService().leaderboard(min_total=min_total))
    except Exception as exc:
        log.exception("Evidence attribution endpoint failed: %s", exc)
        return _clean_for_json({"top": [], "by_horizon": [], "weak": [], "error": str(exc)})



@router.post("/evidence/backfill")
async def evidence_backfill(passes: int = 8):
    """Start/fill external evidence layers without deleting candles or TM tests.

    V10.16.19: this is the manual button/API for deeper market context:
    futures funding/OI/long-short/taker/top-trader, Fear & Greed history,
    CoinMetrics community metrics, orderbook/flow and cross-exchange premium.
    """
    try:
        if sync_lock.locked():
            return _clean_for_json({"ok": False, "status": "busy", "reason": "sync already running"})
        async with sync_lock:
            result = await SyncService().sync_external_evidence_deep_fill(passes=max(1, min(int(passes), 48)))
            return _clean_for_json({"ok": result.get("status") == "ok", **result})
    except Exception as exc:
        log.exception("External evidence backfill failed: %s", exc)
        return _clean_for_json({"ok": False, "error": str(exc)})

@router.get("/evidence/data-sources")
def evidence_data_sources():
    """Show exactly which data layers are actually present.

    This is intentionally DB-based, not marketing text: if a field has 0 rows or
    0 non-null feature values, it is not treated as active evidence.
    """
    metric_counts = _safe_df("""
        SELECT source, metric, COUNT(*) AS rows, MIN(timestamp_ms) AS min_ts, MAX(timestamp_ms) AS max_ts
        FROM raw_metric_points
        GROUP BY source, metric
        ORDER BY source, metric
    """)
    feature_cols = [
        'fear_greed','funding_rate','open_interest_value','open_interest_change_24h',
        'long_short_ratio','taker_buy_sell_ratio','orderbook_imbalance','taker_delta_ratio',
        'futures_basis_premium_pct','top_position_long_short_ratio','top_account_long_short_ratio',
        'cross_exchange_spread_pct','spot_premium_kraken_pct','spot_premium_coinbase_pct',
        'coinmetrics_mvrv','realized_cap_usd','market_cap_usd'
    ]
    feature_coverage = {}
    total = _safe_one("SELECT COUNT(*) FROM features WHERE interval='1h'")
    total_n = int(total[0] or 0) if total else 0
    for col in feature_cols:
        row = _safe_one(f"SELECT COUNT(*) FROM features WHERE interval='1h' AND \"{col}\" IS NOT NULL")
        n = int(row[0] or 0) if row else 0
        feature_coverage[col] = {"non_null_rows": n, "feature_rows": total_n, "coverage_pct": round((n/total_n*100),2) if total_n else 0}
    model_scores = _safe_df("SELECT * FROM model_scores ORDER BY horizon, total DESC")
    active_layers = {k:v for k,v in feature_coverage.items() if v.get("non_null_rows",0) > 0}
    missing_layers = {k:v for k,v in feature_coverage.items() if v.get("non_null_rows",0) == 0}
    progress = _safe_df("""
        SELECT key, value, updated_at
        FROM sync_state
        WHERE key LIKE 'external_progress_%' OR key IN ('external_evidence_backfill','external_evidence_daemon','coinmetrics_status')
        ORDER BY updated_at DESC
        LIMIT 80
    """)
    return _clean_for_json({
        "ok": True,
        "engine_version": settings.engine_version,
        "source_of_truth": "raw_metric_points + non-null feature coverage",
        "currently_core_data": "Binance BTCUSDT 1h OHLCV in raw_candles",
        "external_backfill_endpoint": "/api/evidence/backfill?passes=8",
        "metric_counts": metric_counts,
        "feature_coverage": feature_coverage,
        "active_external_layers": active_layers,
        "missing_external_layers": missing_layers,
        "external_progress": progress,
        "model_scores": model_scores,
        "important_note": "Missing external fields are exported as missing and receive zero model weight; they do not fake confidence.",
    })

@router.get("/evidence/model-status")
def evidence_model_status():
    return _clean_for_json({"ok": True, "model_status": _model_status_payload()})

@router.get("/time-machine/learning")
def time_machine_learning(min_total: int = 5):
    try:
        return _clean_for_json(TimeMachineLearningService().leaderboard(min_total=min_total))
    except Exception as exc:
        log.exception("Time Machine learning endpoint failed: %s", exc)
        return _clean_for_json({"top": [], "by_horizon": [], "weak": [], "coverage": [], "error": str(exc)})


@router.get("/historical-memory/status")
def historical_memory_status():
    try:
        # V10.15.3: this endpoint must be extremely light. Do NOT rebuild/write
        # adaptive weights on every UI poll; that can block behind DuckDB while
        # history is inserting chunks and caused 6000ms frontend timeouts.
        svc = HistoricalMemoryService()
        weights = {}
        try:
            from app.core.config import settings as _settings
            import json as _json
            p = _settings.base_dir / "logs" / "adaptive_feature_weights.json"
            if p.exists():
                weights = _json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            weights = {}
        return _clean_for_json({"ok": True, "history": _authoritative_history_payload(), "service_status": svc.history_status(), "adaptive_weights": weights})
    except Exception as exc:
        log.exception("Historical memory status failed: %s", exc)
        return _clean_for_json({"ok": False, "error": str(exc)})

@router.post("/historical-memory/backfill")
async def historical_memory_backfill(mode: str = "daemon"):
    try:
        svc = HistoricalMemoryService()
        if str(mode).lower() in ("pass", "single", "once"):
            return _clean_for_json(await svc.ensure_eight_year_history_background())
        # V10.15.1: manual button may never block until 70k is complete.
        # It only checks/restarts the same auto-completion daemon and returns immediately.
        asyncio.create_task(svc.ensure_eight_year_history_daemon())
        return _clean_for_json({"ok": True, "queued": True, "message": "Historical Memory auto-completion daemon is running/queued", "status": svc.history_status()})
    except Exception as exc:
        log.exception("Historical memory backfill failed: %s", exc)
        return _clean_for_json({"ok": False, "error": str(exc)})

@router.post("/historical-memory/daemon")
async def historical_memory_daemon():
    try:
        svc = HistoricalMemoryService()
        asyncio.create_task(svc.ensure_eight_year_history_daemon())
        return _clean_for_json({"ok": True, "queued": True, "message": "Historical Memory auto-completion daemon is running/queued", "status": svc.history_status()})
    except Exception as exc:
        log.exception("Historical memory daemon failed: %s", exc)
        return _clean_for_json({"ok": False, "error": str(exc)})

@router.post("/adaptive-weights/rebuild")
def adaptive_weights_rebuild():
    try:
        return _clean_for_json(HistoricalMemoryService().adaptive_weights())
    except Exception as exc:
        log.exception("Adaptive weights rebuild failed: %s", exc)
        return _clean_for_json({"ok": False, "error": str(exc)})

@router.get("/logs/tail")
def logs_tail(lines: int = 300):
    path = settings.base_dir / "logs" / "bee_runtime.log"
    if not path.exists():
        return {"path": str(path), "lines": []}
    data = path.read_text(encoding="utf-8", errors="replace").splitlines()
    return {"path": str(path), "lines": data[-max(1, min(lines, 2000)):]}


@router.get("/seed-export/status")
def seed_export_status():
    try:
        svc = SeedExportService()
        return _clean_for_json({"ok": True, "latest_export": svc.latest_export_info(), "manifest_preview": svc.manifest()})
    except Exception as exc:
        log.exception("Seed export status failed: %s", exc)
        return _clean_for_json({"ok": False, "error": str(exc)})

@router.post("/seed-export/create")
def seed_export_create():
    try:
        return _clean_for_json(SeedExportService().export_seed_zip())
    except Exception as exc:
        log.exception("Seed export create failed: %s", exc)
        return _clean_for_json({"ok": False, "error": str(exc)})

@router.get("/seed-export/download")
def seed_export_download():
    svc = SeedExportService()
    info = svc.latest_export_info()
    path = Path(info.get("path", ""))
    if not path.exists():
        result = svc.export_seed_zip()
        path = Path(result["path"])
    return FileResponse(str(path), media_type="application/zip", filename=path.name)

@router.get("/mobile/summary")
def mobile_summary():
    """iPhone-first lightweight payload.

    Designed for cloud/PWA use: never runs heavy forecast rebuilds and avoids
    wide archive queries so mobile Safari stays responsive while the backend is
    loading history or learning data.
    """
    try:
        # V10.16.20: do NOT call dashboard_status() here. That route can be
        # slow while external evidence is filling. Mobile summary must remain
        # stable and should only use cheap DB queries.
        hist = _authoritative_history_payload()
        native = NativeCoreService().status()
        ticker_price = _safe_one("SELECT value FROM raw_metric_points WHERE source='binance_ticker' AND metric='btc_last_price' ORDER BY timestamp_ms DESC LIMIT 1")
        latest_candle = _safe_one("SELECT close, open_time FROM raw_candles WHERE source='binance' AND symbol=? AND interval='1h' ORDER BY open_time DESC LIMIT 1", [settings.symbol])
        price = ticker_price or latest_candle
        sync_state = _safe_df("SELECT key, value, updated_at FROM sync_state")
        dash = {"api_status": "busy" if sync_lock.locked() else "ok", "sync_busy": bool(sync_lock.locked()), "btc_price": float(price[0]) if price and price[0] is not None else None, "latest_feature": None, "sync_state": sync_state}
        latest_items = _safe_df("""
            SELECT horizon, bullish_probability, bearish_probability, expected_move_pct,
                   expected_price, invalidation_price, confidence, status, due_at_ms
            FROM forecast_items
            WHERE run_id=(SELECT run_id FROM forecast_runs ORDER BY created_at_ms DESC LIMIT 1)
            ORDER BY CASE horizon WHEN '1h' THEN 1 WHEN '4h' THEN 2 WHEN '8h' THEN 3 WHEN '24h' THEN 4 WHEN '7d' THEN 5 WHEN '30d' THEN 6 WHEN '90d' THEN 7 ELSE 99 END
        """)
        accuracy = _safe_df("""
            SELECT horizon, COUNT(*) AS total,
                   SUM(CASE WHEN direction_correct THEN 1 ELSE 0 END) AS correct,
                   AVG(CASE WHEN direction_correct THEN 1.0 ELSE 0.0 END) AS hitrate,
                   AVG(total_score) AS avg_score
            FROM time_machine_tests
            GROUP BY horizon
            ORDER BY CASE horizon WHEN '1h' THEN 1 WHEN '4h' THEN 2 WHEN '8h' THEN 3 WHEN '24h' THEN 4 WHEN '7d' THEN 5 WHEN '30d' THEN 6 WHEN '90d' THEN 7 ELSE 99 END
        """)
        tm_counts = _safe_one("SELECT COUNT(*), COUNT(DISTINCT batch_id), MAX(created_at) FROM time_machine_tests")
        feature_snapshots = _safe_one("SELECT COUNT(*), MAX(created_at) FROM time_machine_feature_snapshots")
        signals = _safe_one("SELECT COUNT(*), MAX(last_seen_at) FROM time_machine_signal_scores")
        candle_range = _real_candle_range()
        return _clean_for_json({
            "ok": True,
            "engine_version": settings.engine_version,
            "api_status": dash.get("api_status") if isinstance(dash, dict) else "ok",
            "sync_busy": bool(dash.get("sync_busy")) if isinstance(dash, dict) else False,
            "btc_price": dash.get("btc_price") if isinstance(dash, dict) else None,
            "latest_feature": dash.get("latest_feature") if isinstance(dash, dict) else None,
            "sync_state": dash.get("sync_state") if isinstance(dash, dict) else [],
            "history": hist,
            "native": native,
            "latest_items": latest_items,
            "accuracy": accuracy,
            "learning": {
                "time_machine_tests": int(tm_counts[0] or 0) if tm_counts else 0,
                "time_machine_batches": int(tm_counts[1] or 0) if tm_counts else 0,
                "latest_test_at": tm_counts[2] if tm_counts else None,
                "feature_snapshots": int(feature_snapshots[0] or 0) if feature_snapshots else 0,
                "latest_feature_snapshot_at": feature_snapshots[1] if feature_snapshots else None,
                "signal_events": int(signals[0] or 0) if signals else 0,
                "latest_signal_at": signals[1] if signals else None,
            },
            "candle_range": {
                "from_ms": candle_range[0] if candle_range else None,
                "to_ms": candle_range[1] if candle_range else None,
                "rows": int(candle_range[2] or 0) if candle_range else 0,
            },
            "external_data": _external_data_status_payload(),
        })
    except Exception as exc:
        log.exception("Mobile summary failed: %s", exc)
        return _clean_for_json({"ok": False, "error": str(exc), "engine_version": settings.engine_version})

@router.get("/mobile/chart")
def mobile_chart(limit: int = 360):
    return TimeMachineService().chart_points(timeframe="1h", limit=max(50, min(int(limit), 1000)))
