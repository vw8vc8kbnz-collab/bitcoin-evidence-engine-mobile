from http.server import HTTPServer, BaseHTTPRequestHandler
from datetime import datetime
from html import escape
from pathlib import Path
import json
import sqlite3
import urllib.parse

PORT = 8798
DB = Path('data/see_results.sqlite')
VERSION = '1.0.5'


def db_rows(sql, params=()):
    if not DB.exists():
        return []
    with sqlite3.connect(DB) as con:
        con.row_factory = sqlite3.Row
        return [dict(r) for r in con.execute(sql, params)]


def metrics():
    if not DB.exists():
        return {'rows':0,'trades':0,'avg':0,'positive':0,'usable':0,'tickers':0,'setups':0}
    rows = db_rows('select * from summary')
    trades = db_rows('select count(*) as c from trades')
    avg = sum(float(r.get('avg_return') or 0) for r in rows)/len(rows) if rows else 0
    return {
        'rows': len(rows),
        'trades': trades[0]['c'] if trades else 0,
        'avg': avg,
        'positive': sum(1 for r in rows if float(r.get('avg_return') or 0) > 0),
        'usable': sum(1 for r in rows if int(r.get('trades') or 0) >= 15),
        'tickers': len({r.get('ticker') for r in rows}),
        'setups': len({r.get('setup') for r in rows}),
    }


def summary_rows(limit=120):
    if not DB.exists():
        return []
    return db_rows('select * from summary order by usable desc, evidence_score desc, trades desc, avg_return desc limit ?', (limit,))


def ticker_rows(ticker):
    return db_rows('select * from summary where ticker=? order by usable desc, evidence_score desc, trades desc', (ticker.upper(),))


def setup_rows(setup):
    return db_rows('select * from summary where setup=? order by usable desc, evidence_score desc, trades desc', (setup,))


def trade_rows(where='', params=(), limit=250):
    sql = 'select * from trades '
    if where:
        sql += 'where ' + where + ' '
    sql += 'order by date desc limit ?'
    return db_rows(sql, tuple(params) + (limit,))


def html_header(title='Stock Evidence Engine'):
    css = """
body{font-family:-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;background:#f3f6fb;color:#101827;margin:0;padding:18px 18px 80px}.hero{background:linear-gradient(135deg,#0d315b,#176da7);color:white;border-radius:28px;padding:28px 24px;margin:18px 0 24px;box-shadow:0 20px 50px rgba(13,49,91,.22)}.kicker{letter-spacing:.22em;color:#f8c954;font-weight:900;font-size:13px}.hero h1{font-size:42px;line-height:.95;margin:20px 0 12px}.hero p{font-size:21px;line-height:1.25;margin:0}.pill{display:inline-block;background:#ffd15a;color:#111827;border-radius:20px;padding:14px 22px;margin-top:22px;font-weight:900}.grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}.metric{background:white;border-radius:24px;padding:24px 20px;box-shadow:0 12px 32px rgba(15,23,42,.07)}.metric .big{font-size:43px;font-weight:950;letter-spacing:-.04em}.metric small{color:#667085;font-size:18px;font-weight:800}.section{font-size:30px;margin:28px 0 14px}.tablewrap{overflow:auto;border-radius:20px;background:white;box-shadow:0 12px 32px rgba(15,23,42,.07)}table{border-collapse:collapse;width:100%;min-width:920px}th{background:#111827;color:white;text-align:left;padding:16px 14px;font-size:16px}td{padding:15px 14px;border-bottom:1px solid #e8edf5;font-size:16px}.ticker{font-weight:950}.badge{border-radius:999px;padding:6px 10px;font-weight:900;font-size:12px;display:inline-block}.ok{background:#dcfce7;color:#166534}.weak{background:#fef3c7;color:#92400e}.low{background:#fee2e2;color:#991b1b}.nav{display:flex;gap:10px;overflow:auto;margin:12px 0 20px}.nav a{white-space:nowrap;background:white;border-radius:999px;padding:12px 16px;color:#111827;text-decoration:none;font-weight:900;box-shadow:0 8px 22px rgba(15,23,42,.06)}.card{background:white;border-radius:24px;padding:22px;margin:16px 0;box-shadow:0 12px 32px rgba(15,23,42,.07)}.note{color:#667085;font-weight:700}.footer{color:#667085;margin-top:20px;font-size:13px}.warn{background:#fff7ed;color:#9a3412;border-radius:18px;padding:14px;font-weight:800}.good{background:#ecfdf5;color:#166534;border-radius:18px;padding:14px;font-weight:800}a{color:#0d5c9b}@media(min-width:760px){body{max-width:980px;margin:auto}.hero h1{font-size:56px}.metric .big{font-size:54px}}
"""
    return f"""<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'><title>{escape(title)}</title><style>{css}</style></head><body><div class='nav'><a href='/'>Home</a><a href='/tickers'>Tickers</a><a href='/setups'>Setups</a><a href='/exports/summary.csv'>Summary CSV</a><a href='/exports/trades.csv'>Trades CSV</a><a href='/health'>Health</a></div>"""


def html_footer():
    return f"<div class='footer'>v{VERSION} · server time {datetime.utcnow().isoformat()}Z · backtest-first, no live trading advice</div></body></html>"


def badge(conf):
    cls = 'ok' if conf in ('STRONG','ELITE_SAMPLE','GOOD','USABLE') else 'weak' if conf == 'WEAK' else 'low'
    return f"<span class='badge {cls}'>{escape(str(conf))}</span>"


def table_summary(rows):
    if not rows:
        return "<div class='card'>Nog geen resultaten. Run eerst: <b>./run_backtest.sh \"BB,PLTR,IONQ,SOUN,NVDA,AMD,TSLA\" \"2y\"</b></div>"
    body = ''
    for r in rows:
        ticker = escape(str(r.get('ticker','')))
        setup = escape(str(r.get('setup','')))
        warning = '⚠️' if int(r.get('trades') or 0) < 15 else ''
        body += f"<tr><td class='ticker'><a href='/ticker/{ticker}'>{ticker}</a></td><td><a href='/setup/{setup}'>{setup}</a></td><td>{int(r.get('hold_days') or 0)}d</td><td>{int(r.get('trades') or 0)} {warning}</td><td>{float(r.get('winrate') or 0)*100:.1f}%</td><td>{float(r.get('avg_return') or 0):.2f}%</td><td>{float(r.get('worst_return') or 0):.2f}%</td><td>{float(r.get('evidence_score') or 0):.1f}</td><td>{badge(r.get('confidence','LOW'))}</td></tr>"
    return f"<div class='tablewrap'><table><thead><tr><th>Ticker</th><th>Setup</th><th>Hold</th><th>Trades</th><th>Winrate</th><th>Avg</th><th>Worst</th><th>Evidence</th><th>Confidence</th></tr></thead><tbody>{body}</tbody></table></div>"


def render_home():
    m = metrics(); rows = summary_rows(120)
    return html_header() + f"""
<div class='hero'><div class='kicker'>BACKTEST-FIRST STOCK ALPHA LAB</div><h1>Stock Evidence Engine</h1><p>v1.0.5: robuuste VPS deploy + betere research ranking, ticker/setup details, exports en tiny-sample bescherming.</p><div class='pill'>v{VERSION} · poort 8798</div></div>
<div class='grid'><div class='metric'><div class='big'>{m['rows']}</div><small>summary rows</small></div><div class='metric'><div class='big'>{m['trades']}</div><small>historical trades</small></div><div class='metric'><div class='big'>{m['avg']:.2f}%</div><small>avg expectancy</small></div><div class='metric'><div class='big'>{m['usable']}</div><small>usable samples ≥15</small></div></div>
<div class='card'><div class='good'>Ranking is nu conservatiever: kleine samples worden gepenalized en krijgen een waarschuwing.</div><p class='note'>Gebruik dit als research-lab. Nog geen live buy-signalen totdat setups echt gevalideerd zijn.</p></div>
<h2 class='section'>Beste evidence-resultaten</h2>{table_summary(rows)}
""" + html_footer()


def render_tickers():
    rows = db_rows('select ticker, count(*) rows, sum(trades) trades, avg(avg_return) avg_return, max(evidence_score) best_score, sum(case when usable then 1 else 0 end) usable_rows from summary group by ticker order by best_score desc, trades desc')
    body=''
    for r in rows:
        t=escape(str(r['ticker']))
        body += f"<tr><td class='ticker'><a href='/ticker/{t}'>{t}</a></td><td>{int(r['rows'])}</td><td>{int(r['trades'] or 0)}</td><td>{float(r['avg_return'] or 0):.2f}%</td><td>{float(r['best_score'] or 0):.1f}</td><td>{int(r['usable_rows'] or 0)}</td></tr>"
    return html_header('Tickers') + "<h1>Tickers</h1><div class='tablewrap'><table><thead><tr><th>Ticker</th><th>Rows</th><th>Trades</th><th>Avg</th><th>Best score</th><th>Usable rows</th></tr></thead><tbody>"+body+"</tbody></table></div>" + html_footer()


def render_setups():
    rows = db_rows('select setup, count(*) rows, sum(trades) trades, avg(avg_return) avg_return, max(evidence_score) best_score, sum(case when usable then 1 else 0 end) usable_rows from summary group by setup order by best_score desc, trades desc')
    body=''
    for r in rows:
        s=escape(str(r['setup']))
        body += f"<tr><td><a href='/setup/{s}'>{s}</a></td><td>{int(r['rows'])}</td><td>{int(r['trades'] or 0)}</td><td>{float(r['avg_return'] or 0):.2f}%</td><td>{float(r['best_score'] or 0):.1f}</td><td>{int(r['usable_rows'] or 0)}</td></tr>"
    return html_header('Setups') + "<h1>Setups</h1><div class='tablewrap'><table><thead><tr><th>Setup</th><th>Rows</th><th>Trades</th><th>Avg</th><th>Best score</th><th>Usable rows</th></tr></thead><tbody>"+body+"</tbody></table></div>" + html_footer()


def render_ticker(ticker):
    ticker = ticker.upper()
    rows = ticker_rows(ticker)
    trades = trade_rows('ticker=?', (ticker,), 80)
    trs=''.join(f"<tr><td>{escape(str(t.get('date','')))}</td><td>{escape(str(t.get('setup','')))}</td><td>{int(t.get('hold_days') or 0)}d</td><td>{float(t.get('return_pct') or 0):.2f}%</td><td>{escape(str(t.get('exit_date','')))}</td></tr>" for t in trades)
    return html_header(ticker) + f"<h1>{escape(ticker)}</h1><div class='card'><b>Ticker detail</b><p class='note'>Hier zie je welke setups voor deze ticker historisch werken en de laatste trades.</p></div><h2>Setup summary</h2>{table_summary(rows)}<h2>Laatste trades</h2><div class='tablewrap'><table><thead><tr><th>Date</th><th>Setup</th><th>Hold</th><th>Return</th><th>Exit date</th></tr></thead><tbody>{trs}</tbody></table></div>" + html_footer()


def render_setup(setup):
    rows = setup_rows(setup)
    trades = trade_rows('setup=?', (setup,), 100)
    trs=''.join(f"<tr><td class='ticker'><a href='/ticker/{escape(str(t.get('ticker','')))}'>{escape(str(t.get('ticker','')))}</a></td><td>{escape(str(t.get('date','')))}</td><td>{int(t.get('hold_days') or 0)}d</td><td>{float(t.get('return_pct') or 0):.2f}%</td></tr>" for t in trades)
    return html_header(setup) + f"<h1>{escape(setup)}</h1><div class='card'><b>Setup detail</b><p class='note'>Bekijk per setup welke tickers/holdtijden echte sample-size hebben.</p></div><h2>Evidence summary</h2>{table_summary(rows)}<h2>Laatste trades</h2><div class='tablewrap'><table><thead><tr><th>Ticker</th><th>Date</th><th>Hold</th><th>Return</th></tr></thead><tbody>{trs}</tbody></table></div>" + html_footer()


def csv_response(table):
    if table not in ('summary','trades') or not DB.exists():
        return b''
    with sqlite3.connect(DB) as con:
        con.row_factory = sqlite3.Row
        rows = [dict(r) for r in con.execute(f'select * from {table}')]
    if not rows:
        return b''
    cols = list(rows[0].keys())
    lines = [','.join(cols)]
    for r in rows:
        vals = []
        for c in cols:
            v = str(r.get(c,'')).replace('"','""')
            if ',' in v or '\n' in v:
                v = f'"{v}"'
            vals.append(v)
        lines.append(','.join(vals))
    return ('\n'.join(lines) + '\n').encode('utf-8')


class Handler(BaseHTTPRequestHandler):
    def do_HEAD(self):
        self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.end_headers()
    def do_GET(self):
        path = urllib.parse.unquote(self.path.split('?',1)[0]).rstrip('/') or '/'
        if path == '/health':
            data=json.dumps({'ok':True,'version':VERSION,'db_exists':DB.exists()}).encode()
            self.send_response(200); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data); return
        if path == '/api/results':
            data=json.dumps({'metrics':metrics(),'summary':summary_rows(200)}, default=str).encode()
            self.send_response(200); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data); return
        if path == '/exports/summary.csv':
            data=csv_response('summary'); self.send_response(200); self.send_header('Content-Type','text/csv'); self.send_header('Content-Disposition','attachment; filename="see_summary_v1_0_4.csv"'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data); return
        if path == '/exports/trades.csv':
            data=csv_response('trades'); self.send_response(200); self.send_header('Content-Type','text/csv'); self.send_header('Content-Disposition','attachment; filename="see_trades_v1_0_4.csv"'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data); return
        if path == '/tickers': page=render_tickers()
        elif path == '/setups': page=render_setups()
        elif path.startswith('/ticker/'): page=render_ticker(path.split('/ticker/',1)[1])
        elif path.startswith('/setup/'): page=render_setup(path.split('/setup/',1)[1])
        else: page=render_home()
        data=page.encode('utf-8'); self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)


if __name__ == '__main__':
    print(f'[SEE] dashboard v{VERSION} listening on 0.0.0.0:{PORT}', flush=True)
    HTTPServer(('0.0.0.0', PORT), Handler).serve_forever()
