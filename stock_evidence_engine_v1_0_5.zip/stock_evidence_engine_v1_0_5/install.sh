#!/usr/bin/env bash
set -euo pipefail

APP_DIR="/home/ubuntu/stock_evidence_latest"
SERVICE_NAME="stock-evidence-dashboard.service"
PORT="8798"
RUN_USER="${SUDO_USER:-ubuntu}"

echo "[SEE] Installing Stock Evidence Engine in $APP_DIR"
cd "$APP_DIR"

mkdir -p data logs exports

# Fix ownership first. This prevents old sudo-created venv/data permission problems.
sudo chown -R "$RUN_USER:$RUN_USER" "$APP_DIR" || true

# Create/refresh venv for research/backtest only. Dashboard itself uses stdlib python3.
if [ ! -x "$APP_DIR/venv/bin/python" ]; then
  rm -rf "$APP_DIR/venv"
  python3 -m venv "$APP_DIR/venv"
fi

"$APP_DIR/venv/bin/python" -m pip install --upgrade pip
"$APP_DIR/venv/bin/python" -m pip install -r "$APP_DIR/requirements.txt"

sudo chown -R "$RUN_USER:$RUN_USER" "$APP_DIR" || true

# Always overwrite the systemd unit. No stale v1_0_2/v1_0_3/uvicorn paths.
sudo tee "/etc/systemd/system/$SERVICE_NAME" > /dev/null <<SERVICE
[Unit]
Description=Stock Evidence Engine Dashboard
After=network.target

[Service]
Type=simple
User=$RUN_USER
WorkingDirectory=$APP_DIR
ExecStart=/usr/bin/python3 $APP_DIR/server.py --host 0.0.0.0 --port $PORT
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
SERVICE

sudo systemctl daemon-reload
sudo systemctl enable "$SERVICE_NAME"
sudo systemctl restart "$SERVICE_NAME"

echo "[SEE] Installed. Dashboard should listen on :$PORT"
