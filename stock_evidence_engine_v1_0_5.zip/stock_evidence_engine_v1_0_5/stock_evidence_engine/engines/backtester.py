from __future__ import annotations
import pandas as pd
from .features import add_features
from .setups import setup_signals

HOLDS = [1, 3, 5, 10, 20]
FEE_SLIPPAGE = 0.004
MIN_USABLE_TRADES = 15


def backtest_ticker(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return pd.DataFrame()
    d = add_features(df).reset_index(drop=True)
    sigs = setup_signals(d)
    trades = []
    for sig in sigs:
        idxs = d.index[d['date'].astype(str).str[:10] == sig['date']].tolist()
        if not idxs:
            continue
        i = idxs[0]
        for hold in HOLDS:
            exit_i = i + hold
            if exit_i >= len(d):
                continue
            entry = float(sig['entry'])
            exit_price = float(d.iloc[exit_i]['close'])
            raw_ret = exit_price / entry - 1.0
            net_ret = raw_ret - FEE_SLIPPAGE
            trades.append({
                **sig,
                'hold_days': hold,
                'exit_date': str(d.iloc[exit_i]['date'])[:10],
                'exit': exit_price,
                'raw_return_pct': raw_ret * 100,
                'return_pct': net_ret * 100,
                'win': net_ret > 0,
            })
    return pd.DataFrame(trades)


def _confidence(n: int) -> str:
    if n >= 75:
        return 'ELITE_SAMPLE'
    if n >= 50:
        return 'STRONG'
    if n >= 30:
        return 'GOOD'
    if n >= 15:
        return 'USABLE'
    if n >= 5:
        return 'WEAK'
    return 'LOW'


def summarize(trades: pd.DataFrame) -> pd.DataFrame:
    if trades.empty:
        return pd.DataFrame()
    g = trades.groupby(['ticker', 'setup', 'hold_days']).agg(
        trades=('return_pct', 'count'),
        winrate=('win', 'mean'),
        avg_return=('return_pct', 'mean'),
        median_return=('return_pct', 'median'),
        best_return=('return_pct', 'max'),
        worst_return=('return_pct', 'min'),
        first_signal=('date', 'min'),
        last_signal=('date', 'max'),
    ).reset_index()
    g['sample_score'] = (g['trades'].clip(0, 75) / 75.0) * 100
    g['expectancy_score'] = (50 + g['avg_return'] * 6).clip(0, 100)
    g['winrate_score'] = (g['winrate'] * 100).clip(0, 100)
    g['downside_penalty'] = (-g['worst_return']).clip(0, 40) * 1.15
    g['tiny_sample_penalty'] = (MIN_USABLE_TRADES - g['trades']).clip(lower=0) * 4.0
    g['evidence_score_raw'] = (
        0.40 * g['expectancy_score']
        + 0.25 * g['winrate_score']
        + 0.25 * g['sample_score']
        - 0.10 * g['downside_penalty']
        - g['tiny_sample_penalty']
    )
    g['evidence_score'] = g['evidence_score_raw'].clip(0, 100).round(1)
    g['confidence'] = g['trades'].apply(lambda x: _confidence(int(x)))
    g['usable'] = g['trades'] >= MIN_USABLE_TRADES
    g['fake_alpha_warning'] = g['trades'] < MIN_USABLE_TRADES
    g = g.sort_values(['usable', 'evidence_score', 'trades', 'avg_return'], ascending=[False, False, False, False])
    return g
