from __future__ import annotations
import sqlite3
from pathlib import Path
import pandas as pd

DB = Path('data/see_results.sqlite')

def write_tables(trades: pd.DataFrame, summary: pd.DataFrame) -> None:
    DB.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(DB) as con:
        trades.to_sql('trades', con, if_exists='replace', index=False)
        summary.to_sql('summary', con, if_exists='replace', index=False)

def read_summary() -> pd.DataFrame:
    if not DB.exists():
        return pd.DataFrame()
    with sqlite3.connect(DB) as con:
        return pd.read_sql_query('select * from summary order by usable desc, evidence_score desc, trades desc', con)

def read_trades() -> pd.DataFrame:
    if not DB.exists():
        return pd.DataFrame()
    with sqlite3.connect(DB) as con:
        return pd.read_sql_query('select * from trades', con)

def export_csvs(export_dir: str = 'exports') -> tuple[str, str]:
    Path(export_dir).mkdir(parents=True, exist_ok=True)
    s = read_summary()
    t = read_trades()
    summary_path = str(Path(export_dir) / 'summary_latest.csv')
    trades_path = str(Path(export_dir) / 'trades_latest.csv')
    s.to_csv(summary_path, index=False)
    t.to_csv(trades_path, index=False)
    return summary_path, trades_path
