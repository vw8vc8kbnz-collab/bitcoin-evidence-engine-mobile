#!/usr/bin/env bash
set -euo pipefail

ZIP_NAME="stock_evidence_engine_v1_0_5.zip"
RAW_URL="${1:-https://raw.githubusercontent.com/vw8vc8kbnz-collab/bitcoin-evidence-engine-mobile/main/$ZIP_NAME}"

cd /home/ubuntu

sudo systemctl stop stock-evidence-dashboard.service || true
sudo systemctl disable stock-evidence-dashboard.service || true
sudo rm -f /etc/systemd/system/stock-evidence-dashboard.service

sudo rm -rf /home/ubuntu/stock_evidence_latest
sudo rm -rf /home/ubuntu/stock_evidence_engine_v1_0_5
rm -f "/home/ubuntu/$ZIP_NAME"

wget -O "/home/ubuntu/$ZIP_NAME" "$RAW_URL"

unzip -o "/home/ubuntu/$ZIP_NAME" -d /home/ubuntu
sudo mv /home/ubuntu/stock_evidence_engine_v1_0_5 /home/ubuntu/stock_evidence_latest
sudo chown -R ubuntu:ubuntu /home/ubuntu/stock_evidence_latest

cd /home/ubuntu/stock_evidence_latest
chmod +x install.sh run_backtest.sh
./install.sh
./run_backtest.sh "BB,PLTR,IONQ,SOUN,NVDA,AMD,TSLA" "2y"

sudo systemctl status stock-evidence-dashboard.service --no-pager -l
sudo lsof -i :8798
curl -I http://127.0.0.1:8798
curl http://127.0.0.1:8798/health
