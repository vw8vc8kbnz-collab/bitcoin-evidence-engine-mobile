# Stock Evidence Engine v1.0.5

Backtest-first Stock Evidence Engine.

## v1.0.5 fixes
- Robuuste VPS install.
- Service wordt altijd volledig overschreven.
- Geen uvicorn/FastAPI runtime voor dashboard.
- Dashboard draait via `/usr/bin/python3 /home/ubuntu/stock_evidence_latest/server.py --host 0.0.0.0 --port 8798`.
- Venv is alleen voor backtests/yfinance.
- `sudo chown -R ubuntu:ubuntu` voorkomt oude permission-problemen.

## Run
```bash
chmod +x install.sh run_backtest.sh
./install.sh
./run_backtest.sh "BB,PLTR,IONQ,SOUN,NVDA,AMD,TSLA" "2y"
```

Dashboard:
`http://51.195.102.180:8798`
