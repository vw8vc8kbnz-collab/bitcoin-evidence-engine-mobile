#!/usr/bin/env bash
set -euo pipefail

APP_DIR="/home/ubuntu/stock_evidence_latest"
cd "$APP_DIR"

TICKERS="${1:-BB,PLTR,IONQ,SOUN,NVDA,AMD,TSLA}"
PERIOD="${2:-2y}"

mkdir -p data logs exports

if [ ! -x "$APP_DIR/venv/bin/python" ]; then
  echo "[SEE] venv missing; run ./install.sh first"
  exit 1
fi

"$APP_DIR/venv/bin/python" -m stock_evidence_engine.cli "$TICKERS" "$PERIOD"
