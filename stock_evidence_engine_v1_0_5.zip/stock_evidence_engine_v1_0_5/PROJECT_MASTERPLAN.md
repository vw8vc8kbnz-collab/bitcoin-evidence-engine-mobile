# Stock Evidence Engine v1.0.5

Werkende baseline na v1.0.3/v1.0.4 deploymentproblemen.

## Vastgezet
- Eén live dashboard runtime: `server.py`.
- Eén poort: 8798.
- Eén map: `/home/ubuntu/stock_evidence_latest`.
- Systemd service: `stock-evidence-dashboard.service`.
- Geen uvicorn/FastAPI/module-importpaden in dashboard runtime.
- Backtest dependencies zitten alleen in `venv`.

## Research volgende stap
- News/catalyst dataset toevoegen.
- Narrative setup hypotheses testen.
- Ticker/setup detailpagina's verder uitbreiden.
- ntfy pas na bewezen setups.
