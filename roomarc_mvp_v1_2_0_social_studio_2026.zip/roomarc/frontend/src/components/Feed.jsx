import React, { useEffect, useMemo, useState } from 'react';
import { Bookmark, ChevronRight, Heart, MessageCircle, RefreshCw, Send, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { FALLBACK_UPDATES } from '../data/fallback';
import { TopBar } from './Layout';

function IntroCard({ goCreate }) {
  return (
    <motion.section className="intro-card intro-card--v8" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
      <span>Welkom bij Roomarc</span>
      <h2>Volg kamers die door de tijd veranderen.</h2>
      <p>Niet alleen losse inspiratiebeelden, maar echte ruimtes met fases, updates en een eigen tijdlijn.</p>
      <div><button onClick={goCreate}>Maak je eerste update</button><button className="plain-button">Bekijk kamers</button></div>
    </motion.section>
  );
}

function CreatorRail({ items, openHome }) {
  const homes = useMemo(() => {
    const map = new Map();
    items.forEach((item) => { if (!map.has(item.home.slug)) map.set(item.home.slug, { ...item.home, count: 0, room: item.room.name, image: item.media_url }); map.get(item.home.slug).count += 1; });
    return Array.from(map.values()).slice(0, 8);
  }, [items]);
  if (!homes.length) return null;
  return <section className="creator-rail"><div className="section-title"><span>Huizen van anderen</span><small>Testfeed</small></div><div className="creator-rail__scroll">{homes.map((home) => <button key={home.slug} className="creator-pill" onClick={() => openHome?.(home.slug)}><img src={home.cover_url || home.image} alt={home.title} /><strong>{home.title}</strong><span>{home.count} updates · {home.room}</span></button>)}</div></section>;
}

function CommentSheet({ update, auth, onClose, onRefresh }) {
  const [comments, setComments] = useState([]);
  const [body, setBody] = useState('');
  const [busy, setBusy] = useState(false);
  useEffect(() => { auth.req(`/api/updates/${update.id}/comments`).then(setComments).catch(() => setComments([])); }, [update.id]);
  async function submit() {
    if (!body.trim()) return;
    setBusy(true);
    try {
      const comment = await auth.req(`/api/updates/${update.id}/comments`, { method: 'POST', body: JSON.stringify({ body }) });
      setComments((items) => [...items, comment]);
      setBody('');
      onRefresh?.();
    } finally { setBusy(false); }
  }
  return (
    <motion.aside className="comment-sheet" initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }} transition={{ type: 'spring', damping: 30, stiffness: 260 }}>
      <div className="comment-sheet__handle" />
      <header><div><small>{update.home.title} · {update.room.name}</small><strong>Reacties</strong></div><button onClick={onClose}>Sluiten</button></header>
      <section className="comment-list">
        {comments.map((comment) => <article key={comment.id}><i>{comment.user.display_name?.[0] || 'R'}</i><div><strong>{comment.user.display_name}</strong><p>{comment.body}</p></div></article>)}
        {!comments.length ? <div className="comment-empty"><MessageCircle size={24} /><strong>Nog geen reacties</strong><p>Start het gesprek over deze kamerupdate.</p></div> : null}
      </section>
      <footer><input value={body} onChange={(e) => setBody(e.target.value)} placeholder="Schrijf een reactie..." /><button disabled={busy} onClick={submit}><Send size={18} /></button></footer>
    </motion.aside>
  );
}

export function FeedCard({ update, auth, openRoom, openHome, onRefresh }) {
  const [commentsOpen, setCommentsOpen] = useState(false);
  const isFallback = String(update.id).startsWith('fb');
  async function toggleSave(event) { event.stopPropagation(); if (isFallback) return; await auth.req(`/api/updates/${update.id}/save`, { method: update.saved ? 'DELETE' : 'POST' }); onRefresh?.(); }
  async function toggleLike(event) { event.stopPropagation(); if (isFallback) return; await auth.req(`/api/updates/${update.id}/like`, { method: 'POST' }); onRefresh?.(); }
  async function followRoom(event) { event.stopPropagation(); if (String(update.room.id).startsWith('demo-room')) return; await auth.req(`/api/rooms/${update.room.id}/follow`, { method: update.following_room ? 'DELETE' : 'POST' }); onRefresh?.(); }
  return (
    <>
      <motion.article className="feed-card feed-card--v12" layout initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} whileTap={{ scale: 0.99 }}>
        <button className="feed-card__media" onClick={() => openRoom(update.room.id)} aria-label={`Open tijdlijn van ${update.room.name}`}>
          <img src={update.media_url} alt={update.room.name} /><span className="feed-card__gradient" />
          <span className="feed-card__home" onClick={(event) => { event.stopPropagation(); openHome?.(update.home.slug); }}>{update.home.title}</span>
          <span className="feed-card__label"><small>{update.room.name}</small><strong>{update.phase_label}</strong></span>
          <span className="feed-card__hint">Bekijk tijdlijn <ChevronRight size={15} /></span>
        </button>
        <div className="feed-card__body">
          <div className="update-meta"><Sparkles size={15} /><span>Kamerupdate · {update.created_at?.slice?.(0,10) || update.created_at}</span></div>
          <p>{update.caption}</p>
          <div className="social-bar-v12">
            <button onClick={toggleLike} className={update.liked ? 'active' : ''}><Heart size={19} fill={update.liked ? 'currentColor' : 'none'} /> {update.likes_count || 0}</button>
            <button onClick={(e) => { e.stopPropagation(); if (!isFallback) setCommentsOpen(true); }}><MessageCircle size={19} /> {update.comments_count || 0}</button>
            <button className="icon-button" onClick={toggleSave}><Bookmark size={19} fill={update.saved ? 'currentColor' : 'none'} /></button>
          </div>
          <div className="feed-card__actions"><button onClick={followRoom} className={update.following_room ? 'is-following' : ''}>{update.following_room ? 'Kamer volgend' : 'Volg kamer'}</button></div>
        </div>
      </motion.article>
      <AnimatePresence>{commentsOpen ? <CommentSheet update={update} auth={auth} onClose={() => setCommentsOpen(false)} onRefresh={onRefresh} /> : null}</AnimatePresence>
    </>
  );
}

export function Feed({ auth, openRoom, openHome, version, setTab }) {
  const [items, setItems] = useState(FALLBACK_UPDATES); const [loading, setLoading] = useState(false);
  async function load() { setLoading(true); try { await fetch('/api/seed-demo', { method: 'POST', cache: 'no-store' }); const data = await auth.req('/api/feed/following'); setItems(data?.length ? data : FALLBACK_UPDATES); } catch { setItems(FALLBACK_UPDATES); } finally { setLoading(false); } }
  useEffect(() => { if (auth.token) load(); }, [version, auth.token]);
  return <main className="screen feed-screen-v8"><TopBar subtitle="Echte ruimtes die veranderen" /><IntroCard goCreate={() => setTab('create')} /><CreatorRail items={items} openHome={openHome} /><div className="tab-row tab-row--v8"><strong>Volgend</strong><span>Nieuwe fases</span><button onClick={load}><RefreshCw className={loading ? 'spin' : ''} size={15} /></button></div>{items.map((item) => <FeedCard key={item.id} update={item} auth={auth} openRoom={openRoom} openHome={openHome} onRefresh={load} />)}</main>;
}
