import React, { useEffect, useState } from 'react';
import { Bell, Heart, MessageCircle, Sparkles, UserPlus } from 'lucide-react';
import { EmptyState, TopBar } from './Layout';

export function Saves({ auth, openRoom }) {
  const [items, setItems] = useState([]);
  useEffect(() => { auth.req('/api/me/saves').then(setItems).catch(() => setItems([])); }, []);
  return <main className="screen"><TopBar title="Bewaard" subtitle="Je inspiratie" /><div className="save-grid">{items.map((item) => <button key={item.id} onClick={() => openRoom(item.room.id)}><img src={item.media_url} alt={item.phase_label} /></button>)}</div>{!items.length ? <EmptyState title="Nog niets bewaard" text="Bewaar kamerupdates uit de feed om ze hier terug te vinden." /> : null}</main>;
}

function iconFor(type) {
  if (type?.includes('like')) return <Heart size={18} />;
  if (type?.includes('comment')) return <MessageCircle size={18} />;
  if (type?.includes('follow')) return <UserPlus size={18} />;
  return <Sparkles size={18} />;
}

export function Profile({ auth }) {
  const [activity, setActivity] = useState([]);
  useEffect(() => { auth.req('/api/activity').then(setActivity).catch(() => setActivity([])); }, []);
  return (
    <main className="screen">
      <TopBar title="Profiel" subtitle="Jouw Roomarc-account" />
      <section className="profile-card">
        <div className="profile-avatar">R</div>
        <h2>{auth.me?.display_name}</h2>
        <p>@{auth.me?.username}</p>
        <div className="version-card"><strong>ROOMARC v1.2.0</strong><span>Social release: likes, reacties, activity en Studio 3.0.</span></div>
        <button className="primary-button" onClick={auth.logout}>Uitloggen</button>
      </section>
      <section className="activity-panel-v12">
        <div className="section-title"><span><Bell size={18} /> Activiteit</span><small>Nieuw</small></div>
        {activity.map((item) => <article key={item.id}><i>{iconFor(item.event_type)}</i><div><strong>{item.message}</strong><span>{item.created_at?.slice?.(0, 16).replace('T',' ')}</span></div></article>)}
        {!activity.length ? <EmptyState title="Nog geen activiteit" text="Likes, reacties en nieuwe volgers verschijnen hier." /> : null}
      </section>
    </main>
  );
}
