import React, { useEffect, useMemo, useState } from 'react';
import { ArrowLeft, Camera, Check, ChevronRight, Home, ImagePlus, Layers, Send, Sparkles, SplitSquareHorizontal, Wand2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { DEFAULT_COVER, DEFAULT_ROOM } from '../data/fallback';
import { TopBar } from './Layout';

const PHASES = ['Startpunt', 'Vloer gelegd', 'Muren afgerond', 'Meubels geplaatst', 'Gestyled', 'Voor/na'];
const QUICK_CAPTIONS = [
  'De basis staat nu goed en de kamer voelt direct rustiger.',
  'Vandaag een duidelijke nieuwe stap gezet in deze ruimte.',
  'De materialen komen nu mooi samen in deze kamer.',
  'Kleine details maken de ruimte ineens veel warmer.',
];

function StudioHome({ setMode }) {
  const cards = [
    ['update', Camera, 'Kamerupdate plaatsen', 'Foto → kamer → fase → preview. De snelste manier om je tijdlijn te laten groeien.', 'Meest gebruikt'],
    ['room', Layers, 'Nieuwe kamer starten', 'Maak een woonkamer, keuken of slaapkamer die mensen apart kunnen volgen.', 'Room follow'],
    ['homeProfile', Home, 'Huisprofiel bouwen', 'Maak de basis van jouw interieurpagina met cover, stijl en bio.', 'Profiel'],
    ['before', SplitSquareHorizontal, 'Before/after maken', 'Leg een transformatie vast als krachtige vergelijk-slider.', 'Binnenkort'],
  ];
  return (
    <main className="screen studio-v12">
      <TopBar title="Roomarc Studio" subtitle="Maak je huis, kamer of update" />
      <section className="studio-command">
        <span><Sparkles size={15} /> Studio 2026</span>
        <h1>Wat wil je nu maken?</h1>
        <p>Roomarc kiest daarna automatisch de juiste flow. Geen oude formulieren, maar korte stappen met directe preview.</p>
      </section>
      <section className="studio-action-stack">
        {cards.map(([mode, Icon, title, text, tag], index) => (
          <motion.button key={mode} className="studio-action-card" onClick={() => setMode(mode)} initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: index * 0.035 }} whileTap={{ scale: 0.985 }}>
            <i><Icon size={24} /></i>
            <div><small>{tag}</small><strong>{title}</strong><p>{text}</p></div>
            <ChevronRight size={20} />
          </motion.button>
        ))}
      </section>
      <section className="studio-explainer">
        <Wand2 size={18} />
        <p><strong>Zo werkt Roomarc:</strong> bouw eerst je huisprofiel, maak kamers aan en plaats per kamer updates. Volgers zien iedere nieuwe fase direct in hun feed.</p>
      </section>
    </main>
  );
}

function ComposerTop({ title, subtitle, onBack, step }) {
  return (
    <header className="composer-top-v12">
      <button onClick={onBack}><ArrowLeft size={18} /> Studio</button>
      <span>{step}</span>
      <h1>{title}</h1>
      <p>{subtitle}</p>
    </header>
  );
}

function UpdateComposer({ auth, onBack, onPosted }) {
  const [homes, setHomes] = useState([]);
  const [rooms, setRooms] = useState([]);
  const [homeId, setHomeId] = useState('');
  const [roomId, setRoomId] = useState('');
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState('');
  const [phase, setPhase] = useState('');
  const [caption, setCaption] = useState('');
  const [status, setStatus] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    auth.req('/api/homes').then((data) => {
      setHomes(data || []);
      if (data?.[0]) setHomeId(data[0].id);
    }).catch(() => setHomes([]));
  }, []);

  useEffect(() => {
    const selected = homes.find((home) => home.id === homeId);
    if (!selected) return;
    auth.req(`/api/homes/${selected.slug}`).then((detail) => {
      setRooms(detail.rooms || []);
      if (detail.rooms?.[0]) setRoomId(detail.rooms[0].id);
    }).catch(() => setRooms([]));
  }, [homeId, homes.length]);

  const selectedHome = homes.find((home) => home.id === homeId);
  const selectedRoom = rooms.find((room) => room.id === roomId);
  const ready = file && roomId && phase && caption.trim();
  const progress = [file, roomId, phase, caption.trim()].filter(Boolean).length;

  function pickFile(event) {
    const selected = event.target.files?.[0];
    if (!selected) return;
    setFile(selected);
    setPreview(URL.createObjectURL(selected));
  }

  async function submit() {
    if (!ready) {
      setStatus('Maak de update compleet: foto, kamer, fase en korte tekst.');
      return;
    }
    setBusy(true);
    try {
      setStatus('Foto uploaden...');
      const form = new FormData();
      form.append('file', file);
      const uploaded = await auth.req('/api/media/upload', { method: 'POST', body: form });
      setStatus('Update publiceren...');
      await auth.req(`/api/rooms/${roomId}/updates`, { method: 'POST', body: JSON.stringify({ media_url: uploaded.url, caption, phase_label: phase }) });
      setStatus('Geplaatst. Je gaat terug naar de feed.');
      setTimeout(() => onPosted?.(), 450);
    } catch (error) {
      setStatus(`Upload mislukt: ${error.message}`);
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="screen composer-v12">
      <ComposerTop onBack={onBack} step={`Stap ${progress}/4`} title="Kamerupdate" subtitle="Maak één nieuwe fase voor de tijdlijn van je kamer." />

      <section className="composer-progress"><span style={{ width: `${(progress / 4) * 100}%` }} /></section>

      <label className={`photo-first-card ${preview ? 'has-preview' : ''}`}>
        <input type="file" accept="image/*" onChange={pickFile} />
        {preview ? <img src={preview} alt="Preview" /> : <div><ImagePlus size={36} /><strong>Voeg kamerfoto toe</strong><span>Deze foto wordt het beeld van je nieuwe fase.</span></div>}
      </label>

      <section className="smart-panel-v12">
        <div className="smart-row">
          <label><small>Huis</small><select value={homeId} onChange={(event) => setHomeId(event.target.value)}>{homes.map((home) => <option value={home.id} key={home.id}>{home.title}</option>)}</select></label>
          <label><small>Kamer</small><select value={roomId} onChange={(event) => setRoomId(event.target.value)}>{rooms.map((room) => <option value={room.id} key={room.id}>{room.name}</option>)}</select></label>
        </div>
        <div className="phase-picker-v12">
          <small>Fase</small>
          <div>{PHASES.map((item) => <button key={item} className={phase === item ? 'active' : ''} onClick={() => setPhase(item)} type="button">{item}</button>)}</div>
        </div>
        <label className="caption-box-v12"><small>Wat is er veranderd?</small><textarea value={caption} onChange={(event) => setCaption(event.target.value)} placeholder="Bijv. De vloer ligt erin en de kamer voelt direct warmer." /></label>
        <div className="quick-captions-v12">{QUICK_CAPTIONS.map((text) => <button type="button" key={text} onClick={() => setCaption(text)}>{text}</button>)}</div>
      </section>

      <section className="live-preview-v12">
        <span>Live preview</span>
        <article>
          {preview ? <img src={preview} alt="Preview" /> : <div className="preview-empty"><Camera size={20} /></div>}
          <div><small>{selectedHome?.title || 'Jouw huis'} · {selectedRoom?.name || 'Kamer'}</small><strong>{phase || 'Nieuwe fase'}</strong><p>{caption || 'Schrijf kort wat er veranderd is.'}</p></div>
        </article>
      </section>

      {status ? <p className="status-message">{status}</p> : null}
      <button className="publish-bar-v12" disabled={busy} onClick={submit}><Send size={18} /> {busy ? 'Publiceren...' : ready ? 'Publiceer naar tijdlijn' : 'Maak update compleet'}</button>
    </main>
  );
}

function RoomComposer({ auth, onBack }) {
  const [homes, setHomes] = useState([]);
  const [homeId, setHomeId] = useState('');
  const [name, setName] = useState('');
  const [type, setType] = useState('');
  const [status, setStatus] = useState('');
  useEffect(() => { auth.req('/api/homes').then((data) => { setHomes(data); if (data[0]) setHomeId(data[0].id); }); }, []);
  async function submit() {
    try { await auth.req(`/api/homes/${homeId}/rooms`, { method: 'POST', body: JSON.stringify({ name, room_type: type, cover_url: DEFAULT_ROOM }) }); setStatus('Kamer aangemaakt. Plaats nu de eerste update.'); setName(''); setType(''); }
    catch (error) { setStatus(`Mislukt: ${error.message}`); }
  }
  return <main className="screen composer-v12"><ComposerTop onBack={onBack} step="Nieuwe ruimte" title="Nieuwe kamer" subtitle="Start een ruimte die mensen apart kunnen volgen." /><section className="smart-panel-v12"><label><small>Kamernaam</small><input value={name} onChange={(e) => setName(e.target.value)} placeholder="Bijv. Woonkamer" /></label><label><small>Kamertype</small><input value={type} onChange={(e) => setType(e.target.value)} placeholder="Keuken, slaapkamer, badkamer..." /></label><label><small>Hoort bij huis</small><select value={homeId} onChange={(e) => setHomeId(e.target.value)}>{homes.map((h) => <option value={h.id} key={h.id}>{h.title}</option>)}</select></label>{status ? <p className="status-message">{status}</p> : null}<button className="publish-bar-v12" onClick={submit}><Check size={18} /> Maak kamer</button></section></main>;
}

function HomeComposer({ auth, onBack }) {
  const [title, setTitle] = useState(''); const [description, setDescription] = useState(''); const [style, setStyle] = useState(''); const [status, setStatus] = useState('');
  async function submit() { try { await auth.req('/api/homes', { method: 'POST', body: JSON.stringify({ title: title || 'Mijn Roomarc huis', description, style_text: style, cover_url: DEFAULT_COVER }) }); setStatus('Huisprofiel aangemaakt. Voeg nu kamers toe.'); } catch (error) { setStatus(`Mislukt: ${error.message}`); } }
  return <main className="screen composer-v12"><ComposerTop onBack={onBack} step="Huisprofiel" title="Bouw je profiel" subtitle="Een Instagram-achtige pagina, maar dan voor je huis." /><section className="live-preview-v12 profile-live"><span>Profiel preview</span><article><img src={DEFAULT_COVER} /><div><small>{style || 'Stijlrichting'} · @roomarc</small><strong>{title || 'Jouw huisnaam'}</strong><p>{description || 'Korte bio over je interieur of verbouwing.'}</p></div></article></section><section className="smart-panel-v12"><label><small>Naam</small><input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Bijv. Villa Rutte" /></label><label><small>Bio</small><textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Vertel kort over je huis/interieur." /></label><label><small>Stijl</small><input value={style} onChange={(e) => setStyle(e.target.value)} placeholder="Japandi, hotel chique, minimal..." /></label>{status ? <p className="status-message">{status}</p> : null}<button className="publish-bar-v12" onClick={submit}><Check size={18} /> Bewaar huisprofiel</button></section></main>;
}

function BeforeAfter({ onBack }) {
  return <main className="screen composer-v12"><ComposerTop onBack={onBack} step="Voor/na" title="Before/after" subtitle="De slider wordt een apart contenttype. Voor nu staat de flow klaar." /><section className="before-mini-v12"><span>Voor</span><i /><span>Na</span></section><button className="publish-bar-v12" onClick={onBack}>Terug naar Studio</button></main>;
}

export function Studio({ auth, onPosted }) {
  const [mode, setMode] = useState('home');
  if (mode === 'update') return <UpdateComposer auth={auth} onBack={() => setMode('home')} onPosted={onPosted} />;
  if (mode === 'room') return <RoomComposer auth={auth} onBack={() => setMode('home')} />;
  if (mode === 'homeProfile') return <HomeComposer auth={auth} onBack={() => setMode('home')} />;
  if (mode === 'before') return <BeforeAfter onBack={() => setMode('home')} />;
  return <StudioHome setMode={setMode} />;
}
