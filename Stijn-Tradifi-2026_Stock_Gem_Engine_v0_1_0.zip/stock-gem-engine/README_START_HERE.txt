Stock Gem Evidence Engine - eerste MVP

Doel: vroege global small/microcap gems vinden voordat ze gepumpt zijn.
Draait licht op VPS: FastAPI + SQLite + gratis bronnen + ntfy.
DeepSeek R1 draait NIET lokaal op 4GB RAM; deze build heeft alvast een AI-ready evidence prompt/output laag.

Start lokaal/server:
  bash scripts/install_or_update.sh

Daarna:
  http://SERVER-IP:8791

Service:
  sudo systemctl status stock-gem.service --no-pager
  tail -n 80 /home/ubuntu/stock-gem-engine/logs/app.log

Belangrijk:
- Gratis data/APIs zijn rate-limited en incompleet.
- Dit is research tooling, geen financieel advies.
- v1 gebruikt een start-universum en kan later API-keys krijgen voor veel bredere coverage.
