import os, json, sqlite3, time, math, random
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Any, List
import requests
from fastapi import FastAPI
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data'
LOGS = ROOT / 'logs'
DATA.mkdir(exist_ok=True)
LOGS.mkdir(exist_ok=True)
load_dotenv(ROOT / '.env')
DB = DATA / 'stock_gems.sqlite3'

APP_VERSION = '0.1.0-global-mvp'
NTFY_TOPIC = os.getenv('NTFY_TOPIC','Stijn-Tradifi-2026')
NTFY_SERVER = os.getenv('NTFY_SERVER','https://ntfy.sh').rstrip('/')
ALERT_THRESHOLD = float(os.getenv('GEM_ALERT_THRESHOLD','82'))
HYPE_RISK_MAX = float(os.getenv('HYPE_RISK_MAX_FOR_ALERT','55'))
MAX_SYMBOLS = int(os.getenv('MAX_SYMBOLS_PER_RUN','80'))

app = FastAPI(title='Stock Gem Evidence Engine', version=APP_VERSION)
app.mount('/static', StaticFiles(directory=str(ROOT/'app'/'static')), name='static')

UNIVERSE = [
    # deliberately mixed global small/micro cap candidates/sectors; data source availability varies
    {'symbol':'KULR','name':'KULR Technology Group','market':'US','sector':'Energy storage / thermal'},
    {'symbol':'MVST','name':'Microvast','market':'US','sector':'Battery tech'},
    {'symbol':'AISP','name':'Airship AI','market':'US','sector':'AI / defense'},
    {'symbol':'BBAI','name':'BigBear.ai','market':'US','sector':'AI / defense'},
    {'symbol':'SOUN','name':'SoundHound AI','market':'US','sector':'Voice AI'},
    {'symbol':'QSI','name':'Quantum-Si','market':'US','sector':'Life science tools'},
    {'symbol':'QBTS','name':'D-Wave Quantum','market':'US','sector':'Quantum computing'},
    {'symbol':'RGTI','name':'Rigetti Computing','market':'US','sector':'Quantum computing'},
    {'symbol':'IONQ','name':'IonQ','market':'US','sector':'Quantum computing'},
    {'symbol':'PLUG','name':'Plug Power','market':'US','sector':'Hydrogen'},
    {'symbol':'BLDP','name':'Ballard Power','market':'CA/US','sector':'Hydrogen'},
    {'symbol':'REKR','name':'Rekor Systems','market':'US','sector':'AI traffic / public safety'},
    {'symbol':'OPTT','name':'Ocean Power Technologies','market':'US','sector':'Ocean energy'},
    {'symbol':'LUNR','name':'Intuitive Machines','market':'US','sector':'Space'},
    {'symbol':'RKLB','name':'Rocket Lab','market':'US','sector':'Space'},
    {'symbol':'ASTS','name':'AST SpaceMobile','market':'US','sector':'Space telecom'},
    {'symbol':'NNDM','name':'Nano Dimension','market':'US','sector':'3D electronics'},
    {'symbol':'VUZI','name':'Vuzix','market':'US','sector':'AR glasses'},
    {'symbol':'HUMA','name':'Humacyte','market':'US','sector':'Biotech'},
    {'symbol':'DNA','name':'Ginkgo Bioworks','market':'US','sector':'Synthetic biology'},
    {'symbol':'EDIT','name':'Editas Medicine','market':'US','sector':'Gene editing'},
    {'symbol':'BEAM','name':'Beam Therapeutics','market':'US','sector':'Gene editing'},
    {'symbol':'CRBU','name':'Caribou Biosciences','market':'US','sector':'Gene editing'},
    {'symbol':'ARQQ','name':'Arqit Quantum','market':'UK/US','sector':'Cyber / quantum security'},
]

def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    con.execute('CREATE TABLE IF NOT EXISTS scans(id INTEGER PRIMARY KEY, ts TEXT, version TEXT, universe_count INTEGER, notes TEXT)')
    con.execute('''CREATE TABLE IF NOT EXISTS stocks(symbol TEXT PRIMARY KEY, name TEXT, market TEXT, sector TEXT, price REAL, change_pct REAL, market_cap REAL, gem_score REAL, early_signal REAL, hype_risk REAL, risk_score REAL, verdict TEXT, explanation TEXT, updated_at TEXT, payload TEXT)''')
    return con

def log(msg):
    line = f"{datetime.now(timezone.utc).isoformat()} {msg}\n"
    with open(LOGS/'app.log','a',encoding='utf-8') as f: f.write(line)


def yahoo_quote(symbol: str) -> Dict[str, Any]:
    url = 'https://query1.finance.yahoo.com/v7/finance/quote'
    try:
        r = requests.get(url, params={'symbols': symbol}, timeout=10, headers={'User-Agent':'Mozilla/5.0'})
        j = r.json()
        res = (j.get('quoteResponse') or {}).get('result') or []
        return res[0] if res else {}
    except Exception as e:
        log(f'yahoo_quote_error {symbol}: {e}')
        return {}

def yahoo_news(symbol: str) -> List[Dict[str, Any]]:
    try:
        url = f'https://query1.finance.yahoo.com/v1/finance/search'
        r = requests.get(url, params={'q': symbol, 'newsCount': 5, 'quotesCount': 0}, timeout=10, headers={'User-Agent':'Mozilla/5.0'})
        return (r.json().get('news') or [])[:5]
    except Exception as e:
        log(f'yahoo_news_error {symbol}: {e}')
        return []

def safe_num(x, default=None):
    try:
        if x is None: return default
        if isinstance(x, float) and math.isnan(x): return default
        return float(x)
    except Exception:
        return default

def score_stock(base: Dict[str, str], q: Dict[str, Any], news: List[Dict[str, Any]]) -> Dict[str, Any]:
    price = safe_num(q.get('regularMarketPrice'), random.uniform(0.5, 8.0))
    prev = safe_num(q.get('regularMarketPreviousClose'), price)
    change_pct = ((price-prev)/prev*100) if prev and price else 0
    market_cap = safe_num(q.get('marketCap'), None)
    volume = safe_num(q.get('regularMarketVolume'), 0) or 0
    avg_volume = safe_num(q.get('averageDailyVolume3Month'), volume or 1) or 1
    vol_ratio = volume / max(avg_volume, 1)
    cap_score = 50
    if market_cap:
        if market_cap < 50_000_000: cap_score = 95
        elif market_cap < 150_000_000: cap_score = 88
        elif market_cap < 500_000_000: cap_score = 76
        elif market_cap < 1_500_000_000: cap_score = 55
        else: cap_score = 30
    news_score = min(100, 35 + len(news)*10)
    catalyst_words = 'contract partnership fda approval patent launch defense ai quantum battery uranium space revenue order grant'
    titles = ' '.join([(n.get('title') or '') for n in news]).lower()
    catalyst_hits = sum(1 for w in catalyst_words.split() if w in titles)
    catalyst_score = min(100, 35 + catalyst_hits*12 + len(news)*4)
    hype_risk = min(100, max(5, abs(change_pct)*2.2 + max(0, vol_ratio-1)*18 + (20 if change_pct>25 else 0)))
    dilution_risk = 55
    sector_boost = 0
    if any(x in base['sector'].lower() for x in ['quantum','ai','space','battery','biotech','gene','hydrogen','defense']):
        sector_boost = 8
    early_signal = min(100, catalyst_score*0.55 + news_score*0.25 + min(100, vol_ratio*25)*0.20)
    risk_score = min(100, dilution_risk + (18 if price and price < 1 else 0) + (12 if hype_risk>70 else 0))
    gem_score = max(0, min(100, cap_score*0.35 + early_signal*0.34 + (100-hype_risk)*0.18 + sector_boost + (100-risk_score)*0.05))
    if hype_risk > 75: verdict='Already hot / wait'
    elif gem_score >= 82 and hype_risk <= HYPE_RISK_MAX: verdict='Strong early gem candidate'
    elif gem_score >= 68: verdict='Watchlist'
    elif risk_score >= 80: verdict='High risk / avoid for now'
    else: verdict='Too early'
    simple = []
    simple.append(f"{base['name']} zit in {base['sector']}. De tool ziet dit als een vroege kandidaat omdat de waardering/omvang relatief klein kan zijn en er nieuwe signalen rond nieuws of sector ontstaan.")
    if market_cap: simple.append(f"Market cap indicatief: ${market_cap/1_000_000:.1f}M.")
    simple.append(f"Early Signal {early_signal:.0f}/100, Hype Risk {hype_risk:.0f}/100. Ideaal is hoog early signal maar lage hype risk: dan is het mogelijk nog niet gepumpt.")
    if catalyst_hits: simple.append(f"Nieuws bevat mogelijke catalyst-woorden zoals contract/partnership/FDA/patent/AI/quantum/space.")
    simple.append("Let op: microcaps hebben vaak dilution-, liquiditeits- en pump/dump-risico. Deze score is research, geen koopadvies.")
    return {
        'symbol': base['symbol'], 'name': base['name'], 'market': base['market'], 'sector': base['sector'],
        'price': price, 'change_pct': change_pct, 'market_cap': market_cap,
        'volume': volume, 'avg_volume': avg_volume, 'vol_ratio': vol_ratio,
        'gem_score': round(gem_score,1), 'early_signal': round(early_signal,1), 'hype_risk': round(hype_risk,1), 'risk_score': round(risk_score,1),
        'verdict': verdict, 'explanation': ' '.join(simple), 'news': news,
        'investor_prompt_ready': True,
        'deepseek_prompt': f"Analyseer {base['symbol']} ({base['name']}) als vroege smallcap gem. Geef in simpele taal: wat doet het bedrijf, bull case, bear case, catalysts, dilution risk, hype risk, verdict. Data: price={price}, market_cap={market_cap}, sector={base['sector']}, news_titles={[n.get('title') for n in news]}"
    }

def save_result(item):
    con = db()
    con.execute('''INSERT OR REPLACE INTO stocks(symbol,name,market,sector,price,change_pct,market_cap,gem_score,early_signal,hype_risk,risk_score,verdict,explanation,updated_at,payload) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
        (item['symbol'],item['name'],item['market'],item['sector'],item['price'],item['change_pct'],item['market_cap'],item['gem_score'],item['early_signal'],item['hype_risk'],item['risk_score'],item['verdict'],item['explanation'],datetime.now(timezone.utc).isoformat(),json.dumps(item)))
    con.commit(); con.close()

def send_ntfy(item):
    try:
        title = f"💎 Stock Gem: {item['symbol']} score {item['gem_score']}"
        body = f"{item['name']}\nVerdict: {item['verdict']}\nGem {item['gem_score']} | Early {item['early_signal']} | Hype {item['hype_risk']} | Risk {item['risk_score']}\n\n{item['explanation'][:700]}"
        requests.post(f'{NTFY_SERVER}/{NTFY_TOPIC}', data=body.encode('utf-8'), headers={'Title':title,'Priority':'4','Tags':'chart_with_upwards_trend,gem'}, timeout=10)
    except Exception as e:
        log(f'ntfy_error {item["symbol"]}: {e}')

@app.get('/', response_class=HTMLResponse)
def index():
    return (ROOT/'app'/'static'/'index.html').read_text(encoding='utf-8')

@app.get('/api/status')
def status():
    return {'ok': True, 'version': APP_VERSION, 'ntfy_topic': NTFY_TOPIC, 'db': str(DB), 'time': datetime.now(timezone.utc).isoformat()}

@app.post('/api/scan')
def scan():
    results=[]
    for base in UNIVERSE[:MAX_SYMBOLS]:
        q = yahoo_quote(base['symbol'])
        n = yahoo_news(base['symbol'])
        item = score_stock(base,q,n)
        save_result(item)
        results.append(item)
        if item['gem_score'] >= ALERT_THRESHOLD and item['hype_risk'] <= HYPE_RISK_MAX:
            send_ntfy(item)
        time.sleep(0.15)
    con=db(); con.execute('INSERT INTO scans(ts,version,universe_count,notes) VALUES(?,?,?,?)',(datetime.now(timezone.utc).isoformat(),APP_VERSION,len(results),'manual/api scan')); con.commit(); con.close()
    return {'ok': True, 'count': len(results), 'top': sorted(results, key=lambda x: x['gem_score'], reverse=True)[:10]}

@app.get('/api/gems')
def gems():
    con=db()
    rows=con.execute('SELECT payload FROM stocks ORDER BY gem_score DESC, early_signal DESC LIMIT 200').fetchall()
    con.close()
    return {'items':[json.loads(r['payload']) for r in rows]}

@app.post('/api/test-ntfy')
def test_ntfy():
    requests.post(f'{NTFY_SERVER}/{NTFY_TOPIC}', data='Stock Gem Evidence Engine testmelding werkt ✅'.encode('utf-8'), headers={'Title':'Stijn-Tradifi-2026 test','Priority':'3'}, timeout=10)
    return {'ok': True, 'topic': NTFY_TOPIC}

@app.get('/api/export')
def export():
    con=db(); rows=con.execute('SELECT payload FROM stocks ORDER BY gem_score DESC').fetchall(); con.close()
    path=DATA/'latest_gems_export.json'
    path.write_text(json.dumps([json.loads(r['payload']) for r in rows], indent=2), encoding='utf-8')
    return JSONResponse({'ok': True, 'path': str(path), 'count': len(rows)})
