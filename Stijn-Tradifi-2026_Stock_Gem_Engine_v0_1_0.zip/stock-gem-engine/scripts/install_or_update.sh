#!/usr/bin/env bash
set -euo pipefail
APP_DIR="/home/ubuntu/stock-gem-engine"
SRC_DIR="$(cd "$(dirname "$0")/.." && pwd)"
PORT="${APP_PORT:-8791}"
SERVICE="stock-gem.service"
mkdir -p "$APP_DIR" "$APP_DIR/data" "$APP_DIR/logs" "$APP_DIR/backups"
rsync -a --delete --exclude '.venv' --exclude 'data' --exclude 'logs' "$SRC_DIR/" "$APP_DIR/current/"
cd "$APP_DIR/current"
if [ ! -f "$APP_DIR/.env" ]; then cp .env.example "$APP_DIR/.env"; fi
ln -sf "$APP_DIR/.env" "$APP_DIR/current/.env"
PYBIN="python3"
if command -v python3.12 >/dev/null 2>&1; then PYBIN="python3.12"; fi
$PYBIN -m venv "$APP_DIR/.venv"
"$APP_DIR/.venv/bin/python" -m pip install --upgrade pip
"$APP_DIR/.venv/bin/python" -m pip install --only-binary=:all: -r requirements.txt
sudo tee /etc/systemd/system/$SERVICE >/dev/null <<EOF
[Unit]
Description=Stock Gem Evidence Engine
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=$APP_DIR/current
EnvironmentFile=$APP_DIR/.env
ExecStart=$APP_DIR/.venv/bin/python -m uvicorn app.main:app --host 0.0.0.0 --port $PORT
Restart=always
RestartSec=5
StandardOutput=append:$APP_DIR/logs/app.log
StandardError=append:$APP_DIR/logs/app.log

[Install]
WantedBy=multi-user.target
EOF
sudo systemctl daemon-reload
sudo systemctl enable $SERVICE
sudo systemctl restart $SERVICE
sleep 2
sudo systemctl status $SERVICE --no-pager || true
echo ""
echo "Klaar: http://SERVER-IP:$PORT"
echo "Logs: tail -n 100 $APP_DIR/logs/app.log"
