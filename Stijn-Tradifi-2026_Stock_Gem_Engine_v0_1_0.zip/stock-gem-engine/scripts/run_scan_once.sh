#!/usr/bin/env bash
set -euo pipefail
curl -sS -X POST http://127.0.0.1:${APP_PORT:-8791}/api/scan | python3 -m json.tool
