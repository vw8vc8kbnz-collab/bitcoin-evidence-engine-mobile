#!/usr/bin/env bash
# Pas REPO_URL en ZIP_NAME aan naar jouw GitHub repo/bestand.
set -euo pipefail
cd /home/ubuntu
rm -rf github_latest stock_gem_update_extract
# git clone REPO_URL github_latest
# mkdir -p stock_gem_update_extract
# unzip -o github_latest/ZIP_NAME.zip -d stock_gem_update_extract
# cd stock_gem_update_extract/stock-gem-engine
# bash scripts/install_or_update.sh
# curl -s http://127.0.0.1:8791/api/status | python3 -m json.tool
# curl -s -X POST http://127.0.0.1:8791/api/test-ntfy | python3 -m json.tool
