# v1.3.1
- Compact mobile dashboard with tabs.
- Richer Yahoo news intelligence: catalyst classes, risk classes, recency decay, source weighting, theme fit, news clustering.
- New exports: see_news_intelligence and see_news_items.
- Same stable server.py/systemd/venv baseline.
