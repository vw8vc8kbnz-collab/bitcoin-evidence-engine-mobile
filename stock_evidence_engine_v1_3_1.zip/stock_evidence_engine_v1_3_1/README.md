# Stock Evidence Engine v1.3.1
Stable stdlib dashboard on port 8798. Adds compact mobile tabs and richer Yahoo news intelligence scoring.
