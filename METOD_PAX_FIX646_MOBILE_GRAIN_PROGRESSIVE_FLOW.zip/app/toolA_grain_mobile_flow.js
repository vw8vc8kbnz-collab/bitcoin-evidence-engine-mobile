(function(){
  'use strict';
  if(window.__FIX646_GRAIN_MOBILE_PROGRESSIVE_FLOW__) return;
  window.__FIX646_GRAIN_MOBILE_PROGRESSIVE_FLOW__='FIX646_GRAIN_MOBILE_PROGRESSIVE_FLOW';

  var PHASES=['eligible','groups','preview'];
  var phase='eligible';
  var overlay=null;
  var navButtons=[];
  var backBtn=null;
  var nextBtn=null;
  var grid=null;
  var wasOpen=false;

  function mobile(){
    return !!(window.matchMedia&&window.matchMedia('(max-width:700px)').matches);
  }
  function getOverlay(){
    overlay=overlay||document.getElementById('grainOverlay');
    return overlay;
  }
  function isVisible(){
    var el=getOverlay();
    if(!el) return false;
    var cs=window.getComputedStyle(el);
    return cs.display!=='none'&&cs.visibility!=='hidden';
  }
  function selectedMaterialKey(){
    try{
      return String((window.state&&state.grain&&state.grain.materialKey)||
        (window.state&&state.activeMaterialKey)||'').trim();
    }catch(_e){return '';}
  }
  function visibleGroups(){
    try{
      var key=selectedMaterialKey();
      return ((state&&state.grain&&state.grain.groups)||[]).filter(function(group){
        return !key||String(group&&group.materialKey||'')===key;
      });
    }catch(_e){return [];}
  }
  function groupHasItems(){
    return visibleGroups().some(function(group){return Array.isArray(group&&group.items)&&group.items.length>0;});
  }
  function eligibleCount(){
    var el=document.getElementById('grainEligibleCount');
    var n=Number(el&&el.textContent);
    return Number.isFinite(n)?n:0;
  }
  function normalizePhase(value){
    return PHASES.indexOf(value)>=0?value:'eligible';
  }
  function phaseIndex(){return PHASES.indexOf(phase);}
  function updateNavigation(){
    var el=getOverlay();
    if(!el) return;
    el.setAttribute('data-mobile-grain-phase',phase);
    var idx=phaseIndex();
    navButtons.forEach(function(btn){
      var target=String(btn.getAttribute('data-grain-phase-target')||'');
      var targetIndex=PHASES.indexOf(target);
      btn.classList.toggle('is-active',target===phase);
      btn.classList.toggle('is-complete',targetIndex<idx);
      btn.setAttribute('aria-current',target===phase?'step':'false');
    });
    if(backBtn){
      backBtn.textContent=idx===0?'Sluiten':'Terug';
      backBtn.setAttribute('aria-label',idx===0?'Doorlopende nerf sluiten':'Terug naar vorige interne fase');
    }
    if(nextBtn){
      nextBtn.textContent=idx===PHASES.length-1?'Toepassen':'Volgende';
      nextBtn.setAttribute('aria-label',idx===PHASES.length-1?'Doorlopende nerf toepassen':'Naar volgende interne fase');
    }
    if(grid){
      try{grid.scrollTop=0;}catch(_e){}
    }
    if(phase==='preview'){
      try{if(typeof window.drawGrainPreview==='function')window.drawGrainPreview();}catch(_e){}
    }
    updateCounts();
  }
  function setPhase(value,opts){
    phase=normalizePhase(value);
    updateNavigation();
    if(opts&&opts.focus){
      var btn=navButtons.find(function(item){return item.getAttribute('data-grain-phase-target')===phase;});
      try{btn&&btn.focus({preventScroll:true});}catch(_e){}
    }
  }
  function updateCounts(){
    navButtons.forEach(function(btn){
      var target=btn.getAttribute('data-grain-phase-target');
      var hasData=(target==='eligible'&&eligibleCount()>0)||(target==='groups'&&visibleGroups().length>0)||(target==='preview'&&groupHasItems());
      btn.classList.toggle('has-data',!!hasData);
    });
  }
  function closeOverlay(){
    var btn=document.getElementById('grainCloseBtn');
    if(btn) btn.click();
  }
  function goBack(){
    var idx=phaseIndex();
    if(idx<=0) closeOverlay();
    else setPhase(PHASES[idx-1],{focus:false});
  }
  function goNext(){
    var idx=phaseIndex();
    if(idx<PHASES.length-1){
      setPhase(PHASES[idx+1],{focus:false});
      return;
    }
    var apply=document.getElementById('grainApplyBtn');
    if(apply) apply.click();
  }
  function bind(){
    var el=getOverlay();
    if(!el) return false;
    navButtons=Array.prototype.slice.call(el.querySelectorAll('[data-grain-phase-target]'));
    backBtn=el.querySelector('.grainMobileBackBtn');
    nextBtn=el.querySelector('.grainMobileNextBtn');
    grid=el.querySelector('.grainGrid3');
    navButtons.forEach(function(btn){
      if(btn.__fix646Bound) return;
      btn.__fix646Bound=true;
      btn.addEventListener('click',function(){setPhase(btn.getAttribute('data-grain-phase-target'),{focus:false});});
    });
    if(backBtn&&!backBtn.__fix646Bound){
      backBtn.__fix646Bound=true;
      backBtn.addEventListener('click',goBack);
    }
    if(nextBtn&&!nextBtn.__fix646Bound){
      nextBtn.__fix646Bound=true;
      nextBtn.addEventListener('click',goNext);
    }
    if(!el.__fix646Delegated){
      el.__fix646Delegated=true;
      el.addEventListener('click',function(ev){
        if(!mobile()) return;
        var chip=ev.target&&ev.target.closest&&ev.target.closest('.grainChip:not(.disabled)');
        var groupAction=ev.target&&ev.target.closest&&ev.target.closest('#grainNewGroupBtn,.miniBtn,.groupItem');
        if(chip||groupAction){setTimeout(updateCounts,30);}
      },true);
    }
    updateNavigation();
    return true;
  }
  function onVisibilityCheck(){
    if(!mobile()) return;
    var open=isVisible();
    if(open&&!wasOpen){
      bind();
      setPhase('eligible',{focus:false});
    }
    wasOpen=open;
    if(open) updateCounts();
  }
  function start(){
    if(!bind()) return;
    var el=getOverlay();
    try{
      new MutationObserver(onVisibilityCheck).observe(el,{attributes:true,attributeFilter:['style','class','aria-hidden']});
    }catch(_e){}
    try{
      new MutationObserver(function(){if(isVisible())updateCounts();}).observe(el,{subtree:true,childList:true,characterData:true});
    }catch(_e){}
    if(window.matchMedia){
      var mq=window.matchMedia('(max-width:700px)');
      var change=function(){if(mq.matches){bind();onVisibilityCheck();}else{el.removeAttribute('data-mobile-grain-phase');}};
      try{mq.addEventListener('change',change);}catch(_e){try{mq.addListener(change);}catch(_e2){}}
    }
    onVisibilityCheck();
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});
  else start();
})();
