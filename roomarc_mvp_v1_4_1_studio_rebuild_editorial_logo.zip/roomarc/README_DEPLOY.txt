ROOMARC v1.4.1 — Service Deploy + PWA Polish

Deze versie draait Roomarc als systemd-service zodat Termius openhouden niet meer nodig is.

Upload roomarc_mvp_v1_1_0_service_pwa_polish.zip naar GitHub en voer uit:

cd ~ && rm -rf roomarc-src roomarc-unpack roomarc && git clone https://github.com/vw8vc8kbnz-collab/bitcoin-evidence-engine-mobile.git roomarc-src && mkdir -p roomarc-unpack && unzip -oq roomarc-src/roomarc_mvp_v1_1_0_service_pwa_polish.zip -d roomarc-unpack && bash roomarc-unpack/install_roomarc.sh

Open:
http://51.195.102.180:8899/?v=110

Demo-login:
demo@roomarc.local / demo123

Service checks:
sudo systemctl status roomarc.service
journalctl -u roomarc.service -f
curl http://127.0.0.1:8899/api/health

Belangrijk:
- De installer stopt oude Roomarc-processen op poort 8899 automatisch.
- Bitcoin Evidence Engine draait op poort 8787 en wordt niet aangepast.
- Data/media blijven persistent in ~/roomarc_data.
- PWA metadata is verbeterd; voor fullscreen appgevoel op iPhone: Safari > Delen > Zet op beginscherm.
