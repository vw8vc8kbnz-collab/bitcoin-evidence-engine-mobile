import React, { useEffect, useMemo, useState } from 'react';
import { Bookmark, ChevronRight, Heart, MessageCircle, RefreshCw, Send, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { FALLBACK_UPDATES } from '../data/fallback';
import { TopBar } from './Layout';

function LivingRoomsRail({ items, openHome, openRoom }) {
  const rooms = useMemo(() => {
    const map = new Map();
    (items || []).forEach((item) => {
      if (!item?.room?.id) return;
      const key = item.room.id;
      if (!map.has(key)) map.set(key, { room: item.room, home: item.home, image: item.media_url, updates: 0, latest: item.phase_label });
      map.get(key).updates += 1;
    });
    return Array.from(map.values()).slice(0, 8);
  }, [items]);
  if (!rooms.length) return null;
  return (
    <section className="living-rail">
      <div className="section-title"><span>Kamers die groeien</span><small>volg een ruimte</small></div>
      <div className="living-rail__scroll">
        {rooms.map((item) => <button key={item.room.id} onClick={() => openRoom(item.room.id)}><img src={item.image || item.room.cover_url} alt={item.room.name} /><strong>{item.room.name}</strong><span>{item.home.title}</span></button>)}
      </div>
    </section>
  );
}

function CommentSheet({ update, auth, onClose, onRefresh }) {
  const [comments, setComments] = useState([]);
  const [body, setBody] = useState('');
  const [busy, setBusy] = useState(false);
  useEffect(() => { let active = true; auth.req(`/api/updates/${update.id}/comments`).then((data) => { if (active) setComments(Array.isArray(data) ? data : []); }).catch(() => { if (active) setComments([]); }); return () => { active = false; }; }, [auth, update.id]);
  async function submit() {
    if (!body.trim()) return;
    setBusy(true);
    try { const comment = await auth.req(`/api/updates/${update.id}/comments`, { method: 'POST', body: JSON.stringify({ body }) }); setComments((items) => [...items, comment]); setBody(''); onRefresh?.(); } finally { setBusy(false); }
  }
  return (
    <motion.aside className="comment-sheet" initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }} transition={{ type: 'spring', damping: 30, stiffness: 260 }}>
      <div className="comment-sheet__handle" />
      <header><div><small>{update.home.title} · {update.room.name}</small><strong>Reacties</strong></div><button onClick={onClose}>Sluiten</button></header>
      <section className="comment-list">
        {comments.map((comment) => <article key={comment.id}><i>{comment.user.display_name?.[0] || 'R'}</i><div><strong>{comment.user.display_name}</strong><p>{comment.body}</p></div></article>)}
        {!comments.length ? <div className="comment-empty"><MessageCircle size={24} /><strong>Nog geen reacties</strong><p>Start het gesprek over deze kamerupdate.</p></div> : null}
      </section>
      <footer><input value={body} onChange={(e) => setBody(e.target.value)} placeholder="Schrijf een reactie..." /><button disabled={busy} onClick={submit}><Send size={18} /></button></footer>
    </motion.aside>
  );
}

function TimelineHint({ update }) {
  const current = Math.max(1, Math.min(7, update.phase_index || Math.ceil(((update.phase_label || '').length + 1) % 6) + 1));
  return <div className="timeline-hint-pro"><span>Fase {current} van 7</span><div>{Array.from({ length: 7 }).map((_, index) => <i key={index} className={index < current ? 'active' : ''} />)}</div></div>;
}

function FeedCard({ update, auth, openRoom, openHome, onRefresh }) {
  const [commentsOpen, setCommentsOpen] = useState(false);
  const isFallback = String(update.id).startsWith('fb');
  async function toggleLike(event) { event.stopPropagation(); if (isFallback) return; await auth.req(`/api/updates/${update.id}/like`, { method: 'POST' }); onRefresh?.(); }
  async function toggleSave(event) { event.stopPropagation(); if (isFallback) return; await auth.req(`/api/updates/${update.id}/save`, { method: update.saved ? 'DELETE' : 'POST' }); onRefresh?.(); }
  async function followRoom(event) { event.stopPropagation(); if (isFallback || String(update.room.id).startsWith('demo-room')) return; await auth.req(`/api/rooms/${update.room.id}/follow`, { method: update.following_room ? 'DELETE' : 'POST' }); onRefresh?.(); }
  return (
    <>
      <motion.article className="feed-card-pro" layout initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} whileTap={{ scale: 0.992 }}>
        <button className="feed-card-pro__image" onClick={() => openRoom(update.room.id)}>
          <img src={update.media_url} alt={update.room.name} />
          <span className="feed-card-pro__gradient" />
          <span className="feed-card-pro__room"><small>{update.home.title}</small><strong>{update.room.name}</strong></span>
          <span className="feed-card-pro__open">Tijdlijn <ChevronRight size={15} /></span>
        </button>
        <div className="feed-card-pro__content">
          <div className="feed-card-pro__meta"><button onClick={(event) => { event.stopPropagation(); openHome?.(update.home.slug); }}>{update.home.title}</button><span>{update.phase_label}</span></div>
          <TimelineHint update={update} />
          <p>{update.caption}</p>
          <div className="feed-social-pro">
            <button onClick={toggleLike} className={update.liked ? 'active' : ''}><Heart size={19} fill={update.liked ? 'currentColor' : 'none'} /> {update.likes_count || 0}</button>
            <button onClick={(e) => { e.stopPropagation(); if (!isFallback) setCommentsOpen(true); }}><MessageCircle size={19} /> {update.comments_count || 0}</button>
            <button onClick={toggleSave}><Bookmark size={19} fill={update.saved ? 'currentColor' : 'none'} /></button>
            <button className="follow-mini-pro" onClick={followRoom}>{update.following_room ? 'Volgend' : 'Volg kamer'}</button>
          </div>
        </div>
      </motion.article>
      <AnimatePresence>{commentsOpen ? <CommentSheet update={update} auth={auth} onClose={() => setCommentsOpen(false)} onRefresh={onRefresh} /> : null}</AnimatePresence>
    </>
  );
}

export function Feed({ auth, openRoom, openHome, version }) {
  const [items, setItems] = useState(FALLBACK_UPDATES);
  const [loading, setLoading] = useState(false);
  async function load() {
    setLoading(true);
    try { await fetch('/api/seed-demo', { method: 'POST', cache: 'no-store' }); const data = await auth.req('/api/feed/following'); setItems(Array.isArray(data) && data.length ? data : FALLBACK_UPDATES); } catch { setItems(FALLBACK_UPDATES); } finally { setLoading(false); }
  }
  useEffect(() => { if (auth.token) load(); }, [version, auth.token]);
  return (
    <main className="screen feed-pro-screen">
      <TopBar title="ROOMARC" subtitle="Echte ruimtes die veranderen"><button className="refresh-pro" onClick={load}><RefreshCw className={loading ? 'spin' : ''} size={18} /></button></TopBar>
      <LivingRoomsRail items={items} openHome={openHome} openRoom={openRoom} />
      <div className="feed-section-header"><div><small>Volgend</small><strong>Nieuwe fases</strong></div><Sparkles size={20} /></div>
      {items.map((item) => <FeedCard key={item.id} update={item} auth={auth} openRoom={openRoom} openHome={openHome} onRefresh={load} />)}
    </main>
  );
}
