import React, { useEffect, useMemo, useState } from 'react';
import { Bell, Bookmark, Grid3X3, Heart, Home as HomeIcon, House, MessageCircle, Settings, Sparkles, UserPlus } from 'lucide-react';
import { EmptyState, TopBar } from './Layout';

export function Saves({ auth, openRoom }) {
  const [items, setItems] = useState([]);
  useEffect(() => { let active = true; auth.req('/api/me/saves').then((data) => { if (active) setItems(Array.isArray(data) ? data : []); }).catch(() => { if (active) setItems([]); }); return () => { active = false; }; }, [auth]);
  return (
    <main className="screen saves-pro-screen">
      <TopBar title="Bewaard" subtitle="Je interieurcollectie" />
      <div className="saves-masonry-pro">
        {items.map((item) => <button key={item.id} onClick={() => openRoom(item.room.id)}><img src={item.media_url} alt={item.phase_label} /><span>{item.home?.title || item.room?.name}</span><strong>{item.phase_label}</strong></button>)}
      </div>
      {!items.length ? <EmptyState title="Nog niets bewaard" text="Bewaar updates uit de feed. Hier bouw je straks je eigen inspiratiecollectie." /> : null}
    </main>
  );
}

function iconFor(type) {
  if (type?.includes('like')) return <Heart size={18} />;
  if (type?.includes('comment')) return <MessageCircle size={18} />;
  if (type?.includes('follow')) return <UserPlus size={18} />;
  return <Sparkles size={18} />;
}

function ProfileHomeCard({ home, openRoom }) {
  const rooms = Array.isArray(home?.rooms) ? home.rooms : [];
  const leadRoom = rooms[0];
  return (
    <article className="portfolio-home-card">
      <img src={home.cover_url || leadRoom?.cover_url} alt={home.title} />
      <div>
        <small>{home.style_text || 'Interieurprofiel'}</small>
        <strong>{home.title}</strong>
        <p>{home.description || 'Een huis dat stap voor stap groeit op Roomarc.'}</p>
        <span>{rooms.length} kamers · {home.stats?.updates || 0} updates · {home.stats?.followers || 0} volgers</span>
      </div>
      {leadRoom ? <button onClick={() => openRoom?.(leadRoom.id)}>Open kamer</button> : null}
    </article>
  );
}

function RoomPortfolioGrid({ rooms, openRoom }) {
  if (!rooms.length) return <EmptyState title="Nog geen kamers" text="Start in Studio je eerste kamer en bouw daarna je tijdlijn op." />;
  return (
    <div className="room-portfolio-grid">
      {rooms.map((room) => {
        const image = room.latest_update?.media_url || room.cover_url;
        return <button key={room.id} onClick={() => openRoom?.(room.id)}><img src={image} alt={room.name} /><span>{room.home.title}</span><strong>{room.name}</strong><small>{room.latest_phase || 'Startpunt'} · {room.updates || 0} fases</small></button>;
      })}
    </div>
  );
}

function UpdateGrid({ updates, openRoom }) {
  if (!updates.length) return <EmptyState title="Nog geen updates" text="Plaats je eerste kamerupdate in Studio." />;
  return (
    <div className="update-portfolio-grid">
      {updates.map((update) => <button key={update.id} onClick={() => openRoom?.(update.room.id)}><img src={update.media_url} alt={update.phase_label} /><span>{update.room.name}</span><strong>{update.phase_label}</strong></button>)}
    </div>
  );
}

function ActivityList({ auth }) {
  const [activity, setActivity] = useState([]);
  useEffect(() => { let active = true; auth.req('/api/activity').then((data) => { if (active) setActivity(Array.isArray(data) ? data : []); }).catch(() => { if (active) setActivity([]); }); return () => { active = false; }; }, [auth]);
  return (
    <section className="activity-list-pro">
      {activity.map((item) => <article key={item.id}><i>{iconFor(item.event_type)}</i><div><strong>{item.message}</strong><span>{item.created_at?.slice?.(0, 16).replace('T', ' ')}</span></div></article>)}
      {!activity.length ? <EmptyState title="Nog geen activiteit" text="Likes, reacties en volgers verschijnen hier." /> : null}
    </section>
  );
}

export function Profile({ auth, openRoom }) {
  const [data, setData] = useState(null);
  const [tab, setTab] = useState('homes');
  useEffect(() => { let active = true; auth.req('/api/me/homes').then((payload) => { if (active) setData(payload || { homes: [], stats: {} }); }).catch(() => { if (active) setData({ homes: [], stats: {} }); }); return () => { active = false; }; }, [auth]);

  const homes = Array.isArray(data?.homes) ? data.homes : [];
  const rooms = useMemo(() => homes.flatMap((home) => (home.rooms || []).map((room) => ({ ...room, home }))), [homes]);
  const updates = useMemo(() => rooms.map((room) => room.latest_update).filter(Boolean), [rooms]);
  const stats = data?.stats || { homes: homes.length, rooms: rooms.length, updates: updates.length, followers: 0 };
  const me = data?.user || auth.me || {};

  return (
    <main className="screen profile-pro-screen">
      <TopBar title="Profiel" subtitle="Jouw interieurportfolio"><Settings size={22} /></TopBar>
      <section className="profile-cover-pro">
        <div className="profile-avatar-pro">{me.display_name?.[0] || 'R'}</div>
        <div className="profile-title-pro"><h1>{me.display_name || 'Roomarc gebruiker'}</h1><p>@{me.username || 'roomarc'} · echte ruimtes die veranderen</p></div>
        <button onClick={auth.logout}>Uitloggen</button>
      </section>
      <section className="profile-stats-pro"><div><strong>{stats.homes || 0}</strong><span>Huizen</span></div><div><strong>{stats.rooms || 0}</strong><span>Kamers</span></div><div><strong>{stats.updates || 0}</strong><span>Updates</span></div><div><strong>{stats.followers || 0}</strong><span>Volgers</span></div></section>
      <nav className="profile-tabs-pro"><button className={tab === 'homes' ? 'active' : ''} onClick={() => setTab('homes')}><House size={16} /> Huizen</button><button className={tab === 'rooms' ? 'active' : ''} onClick={() => setTab('rooms')}><Grid3X3 size={16} /> Kamers</button><button className={tab === 'updates' ? 'active' : ''} onClick={() => setTab('updates')}><Sparkles size={16} /> Updates</button><button className={tab === 'activity' ? 'active' : ''} onClick={() => setTab('activity')}><Bell size={16} /> Activiteit</button></nav>
      {tab === 'homes' ? <section className="portfolio-home-list">{homes.map((home) => <ProfileHomeCard home={home} key={home.id} openRoom={openRoom} />)}{!homes.length ? <EmptyState title="Nog geen huisprofiel" text="Maak in Studio je eerste huisprofiel." /> : null}</section> : null}
      {tab === 'rooms' ? <RoomPortfolioGrid rooms={rooms} openRoom={openRoom} /> : null}
      {tab === 'updates' ? <UpdateGrid updates={updates} openRoom={openRoom} /> : null}
      {tab === 'activity' ? <ActivityList auth={auth} /> : null}
    </main>
  );
}
