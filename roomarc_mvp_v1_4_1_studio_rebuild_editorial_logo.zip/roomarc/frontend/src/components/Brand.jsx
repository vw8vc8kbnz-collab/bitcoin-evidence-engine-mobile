import React from 'react';

export function RoomarcWordmark({ compact = false, dark = false }) {
  return (
    <span className={`roomarc-wordmark roomarc-wordmark--editorial ${compact ? 'roomarc-wordmark--compact' : ''} ${dark ? 'roomarc-wordmark--dark' : ''}`} aria-label="Roomarc">
      <span className="roomarc-wordmark__room">Room</span><span className="roomarc-wordmark__arc">arc</span>
    </span>
  );
}

export function RoomarcLogo({ size = 42, dark = false }) {
  return (
    <span className={`roomarc-logo roomarc-logo--editorial ${dark ? 'roomarc-logo--dark' : ''}`} style={{ width: size, height: size }} aria-hidden="true">
      <svg viewBox="0 0 64 64" role="img" focusable="false">
        <defs>
          <linearGradient id="roomarcEditorialGrad" x1="7" y1="7" x2="58" y2="58" gradientUnits="userSpaceOnUse">
            <stop offset="0" stopColor="#191613" />
            <stop offset="0.56" stopColor="#191613" />
            <stop offset="0.57" stopColor="#a77a50" />
            <stop offset="1" stopColor="#d7bd93" />
          </linearGradient>
        </defs>
        <rect x="4" y="4" width="56" height="56" rx="14" fill={dark ? '#f7f4ee' : '#11110f'} />
        <path d="M15 39.5C19.2 26.2 28.3 18 39.3 18C45.8 18 50.8 20.9 54 25.7" fill="none" stroke="#d7bd93" strokeWidth="4.2" strokeLinecap="round" />
        <path d="M17.5 42.5H48.5" stroke={dark ? '#11110f' : '#f7f4ee'} strokeWidth="4.2" strokeLinecap="round" />
        <path d="M20 42V27.5L32 19.8L44 27.5V42" fill="none" stroke="url(#roomarcEditorialGrad)" strokeWidth="3.8" strokeLinecap="round" strokeLinejoin="round" />
        <circle cx="32" cy="33" r="3.4" fill="#d7bd93" />
      </svg>
    </span>
  );
}

export function RoomarcBrand({ subtitle, dark = false, compact = false }) {
  return (
    <span className={`roomarc-brand ${compact ? 'roomarc-brand--compact' : ''}`}>
      <RoomarcLogo size={compact ? 34 : 46} dark={dark} />
      <span className="roomarc-brand__text">
        <RoomarcWordmark compact={compact} dark={dark} />
        {subtitle ? <small>{subtitle}</small> : null}
      </span>
    </span>
  );
}
