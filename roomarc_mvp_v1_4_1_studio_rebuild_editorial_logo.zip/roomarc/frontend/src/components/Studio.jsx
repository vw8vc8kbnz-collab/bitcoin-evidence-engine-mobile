import React, { useEffect, useMemo, useState } from 'react';
import { Camera, Check, ChevronRight, Home, ImagePlus, Layers, Palette, Plus, Send, Sparkles, SplitSquareHorizontal, Wand2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { DEFAULT_COVER, DEFAULT_ROOM } from '../data/fallback';
import { TopBar, EmptyState } from './Layout';

const PHASES = ['Startpunt', 'Sloop/voorbereiding', 'Vloer gelegd', 'Muren afgerond', 'Meubels geplaatst', 'Gestyled', 'Voor/na'];
const ROOM_TYPES = ['Woonkamer', 'Keuken', 'Slaapkamer', 'Badkamer', 'Hal', 'Tuin', 'Werkplek'];
const STYLE_OPTIONS = ['Scandinavisch', 'Japandi', 'Hotel chique', 'Mediterraan', 'Industrieel', 'Warm minimal'];
const CAPTION_IDEAS = [
  'Vandaag voelt deze kamer voor het eerst echt als een ruimte met richting.',
  'Een nieuwe fase in de tijdlijn: materiaal, licht en sfeer vallen steeds beter samen.',
  'Deze update laat goed zien hoe de kamer stap voor stap groeit.',
  'Kleine details, maar ze maken de ruimte direct warmer en persoonlijker.',
];

function safeHomes(data) { return Array.isArray(data?.homes) ? data.homes : []; }
function flattenRooms(data) {
  return safeHomes(data).flatMap((home) => (Array.isArray(home.rooms) ? home.rooms : []).map((room) => ({ ...room, home })));
}
function progressCount(room) { return Math.max(1, Math.min(7, Number(room?.updates || 1))); }

function StudioProjectCard({ room, active, onClick }) {
  const image = room?.latest_update?.media_url || room?.cover_url || DEFAULT_ROOM;
  const count = progressCount(room);
  return (
    <motion.button className={`studio-project-editor-card ${active ? 'active' : ''}`} whileTap={{ scale: 0.985 }} onClick={onClick}>
      <img src={image} alt={room?.name || 'Kamer'} />
      <div className="studio-project-editor-card__content">
        <small>{room?.home?.title || 'Jouw huis'}</small>
        <strong>{room?.name || 'Nieuwe kamer'}</strong>
        <span>{room?.latest_phase || 'Startpunt'} · {room?.updates || 0} updates</span>
        <div className="studio-progress-rail" aria-hidden="true">
          {Array.from({ length: 7 }).map((_, i) => <i key={i} className={i < count ? 'active' : ''} />)}
        </div>
      </div>
      <ChevronRight size={17} />
    </motion.button>
  );
}

function StudioModeSwitch({ mode, setMode }) {
  const modes = [
    ['update', 'Update', Camera],
    ['room', 'Kamer', Layers],
    ['home', 'Huis', Home],
    ['before', 'Voor/na', SplitSquareHorizontal],
  ];
  return (
    <nav className="studio-mode-switch" aria-label="Studio-modus">
      {modes.map(([key, label, Icon]) => <button key={key} className={mode === key ? 'active' : ''} onClick={() => setMode(key)}><Icon size={16} />{label}</button>)}
    </nav>
  );
}

function StudioIntro({ stats, primaryRoom, setMode, chooseRoom }) {
  return (
    <section className="studio-editor-hero">
      <div>
        <small>Roomarc Studio</small>
        <h1>Werk verder aan je interieurverhaal.</h1>
        <p>Geen los uploadformulier: kies een kamer, leg de volgende fase vast en zie direct hoe je tijdlijn groeit.</p>
      </div>
      <button onClick={() => { if (primaryRoom) chooseRoom(primaryRoom); setMode('update'); }}>
        <Plus size={20} /> Kamerupdate plaatsen
      </button>
      <div className="studio-editor-stats">
        <span><strong>{stats.homes || 0}</strong> huizen</span>
        <span><strong>{stats.rooms || 0}</strong> kamers</span>
        <span><strong>{stats.updates || 0}</strong> updates</span>
      </div>
    </section>
  );
}

function UpdateWorkbench({ auth, homes, rooms, selectedRoom, setSelectedRoom, onPosted }) {
  const [homeId, setHomeId] = useState(selectedRoom?.home?.id || homes[0]?.id || '');
  const [roomId, setRoomId] = useState(selectedRoom?.id || rooms[0]?.id || '');
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState('');
  const [phase, setPhase] = useState(selectedRoom?.latest_phase || PHASES[0]);
  const [caption, setCaption] = useState('');
  const [goal, setGoal] = useState('sfeer');
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState('');

  const roomsForHome = useMemo(() => rooms.filter((room) => room.home?.id === homeId), [rooms, homeId]);
  useEffect(() => {
    if (selectedRoom?.id) { setHomeId(selectedRoom.home?.id || ''); setRoomId(selectedRoom.id); }
  }, [selectedRoom?.id]);
  useEffect(() => {
    if (!roomsForHome.some((room) => room.id === roomId) && roomsForHome[0]) setRoomId(roomsForHome[0].id);
  }, [roomsForHome, roomId]);

  const currentHome = homes.find((home) => home.id === homeId) || selectedRoom?.home || homes[0];
  const currentRoom = rooms.find((room) => room.id === roomId) || selectedRoom || rooms[0];
  const ready = Boolean(file && roomId && phase && caption.trim());

  function pickFile(event) {
    const selected = event.target.files?.[0];
    if (!selected) return;
    setFile(selected);
    setPreview(URL.createObjectURL(selected));
  }

  async function submit() {
    if (!ready) { setStatus('Maak je update compleet: foto, kamer, fase en kort verhaal.'); return; }
    setBusy(true); setStatus('Publiceren naar je kamertijdlijn...');
    try {
      const form = new FormData();
      form.append('file', file);
      const uploaded = await auth.req('/api/media/upload', { method: 'POST', body: form });
      await auth.req(`/api/rooms/${roomId}/updates`, { method: 'POST', body: JSON.stringify({ media_url: uploaded.url, caption, phase_label: phase }) });
      setStatus('Geplaatst. Deze kamer heeft een nieuwe fase in de tijdlijn.');
      setFile(null); setPreview(''); setCaption('');
      setTimeout(() => onPosted?.(), 800);
    } catch (error) {
      setStatus(`Upload mislukt: ${error.message}`);
    } finally { setBusy(false); }
  }

  return (
    <section className="studio-canvas-panel update-canvas">
      <div className="studio-panel-heading">
        <small>Hoofdactie</small>
        <h2>Kamerupdate maken</h2>
        <p>Leg een volgende fase vast. Je volgers zien dit als onderdeel van de kamerreis.</p>
      </div>

      <div className="project-picker-strip">
        {rooms.slice(0, 8).map((room) => <button key={room.id} className={room.id === roomId ? 'active' : ''} onClick={() => { setSelectedRoom(room); setHomeId(room.home?.id || ''); setRoomId(room.id); }}><img src={room.latest_update?.media_url || room.cover_url || DEFAULT_ROOM} alt={room.name} /><span>{room.name}</span></button>)}
      </div>

      <label className={`editor-media-stage ${preview ? 'has-preview' : ''}`}>
        <input type="file" accept="image/*" onChange={pickFile} />
        {preview ? <img src={preview} alt="Nieuwe update preview" /> : <div><ImagePlus size={36} /><strong>Voeg een beeld toe</strong><span>Begin met wat mensen moeten voelen: de foto.</span></div>}
      </label>

      <div className="studio-editor-grid">
        <label><small>Huis</small><select value={homeId} onChange={(e) => { setHomeId(e.target.value); setRoomId(''); }}>{homes.map((home) => <option key={home.id} value={home.id}>{home.title}</option>)}</select></label>
        <label><small>Kamer</small><select value={roomId} onChange={(e) => setRoomId(e.target.value)}>{roomsForHome.map((room) => <option key={room.id} value={room.id}>{room.name}</option>)}</select></label>
      </div>

      <div className="studio-phase-timeline">
        <small>Waar zit deze update in de reis?</small>
        <div>{PHASES.map((item) => <button key={item} className={phase === item ? 'active' : ''} onClick={() => setPhase(item)}>{item}</button>)}</div>
      </div>

      <div className="studio-intent-row">
        {[['sfeer', 'Sfeer'], ['materiaal', 'Materiaal'], ['indeling', 'Indeling'], ['detail', 'Detail']].map(([key, label]) => <button key={key} className={goal === key ? 'active' : ''} onClick={() => setGoal(key)}>{label}</button>)}
      </div>

      <label className="studio-story-field"><small>Kort verhaal</small><textarea value={caption} onChange={(e) => setCaption(e.target.value)} placeholder="Wat is er veranderd en waarom voelt deze fase belangrijk?" /></label>
      <div className="studio-suggestion-row">{CAPTION_IDEAS.map((idea) => <button key={idea} onClick={() => setCaption(idea)}>{idea}</button>)}</div>

      <article className="studio-live-preview">
        <div className="studio-live-preview__image">{preview ? <img src={preview} alt="Preview" /> : <Camera size={22} />}</div>
        <div><small>{currentHome?.title || 'Jouw huis'} · {currentRoom?.name || 'Kamer'}</small><strong>{phase || 'Nieuwe fase'}</strong><p>{caption || 'Je feed-preview verschijnt hier terwijl je bouwt.'}</p><span>{goal === 'sfeer' ? 'Focus op sfeer' : goal === 'materiaal' ? 'Focus op materiaal' : goal === 'indeling' ? 'Focus op indeling' : 'Focus op detail'}</span></div>
      </article>
      {status ? <p className="status-message">{status}</p> : null}
      <button className="studio-publish-button" disabled={busy} onClick={submit}><Send size={18} /> {ready ? 'Publiceer update' : 'Maak update compleet'}</button>
    </section>
  );
}

function RoomBlueprint({ auth, homes }) {
  const [homeId, setHomeId] = useState(homes[0]?.id || '');
  const [name, setName] = useState('');
  const [type, setType] = useState(ROOM_TYPES[0]);
  const [status, setStatus] = useState('');
  useEffect(() => { if (!homeId && homes[0]) setHomeId(homes[0].id); }, [homes, homeId]);
  async function submit() {
    if (!homeId || !name.trim()) { setStatus('Kies een huis en geef je kamer een naam.'); return; }
    try {
      await auth.req(`/api/homes/${homeId}/rooms`, { method: 'POST', body: JSON.stringify({ name, room_type: type, cover_url: DEFAULT_ROOM }) });
      setStatus('Kamer aangemaakt. Je kunt nu de eerste fase plaatsen.'); setName('');
    } catch (error) { setStatus(`Mislukt: ${error.message}`); }
  }
  return (
    <section className="studio-canvas-panel">
      <div className="studio-panel-heading"><small>Nieuwe ruimte</small><h2>Kamer als tijdlijn starten</h2><p>Een kamer is geen mapje. Het is een verhaal waar mensen op kunnen terugkomen.</p></div>
      <div className="room-type-grid">{ROOM_TYPES.map((item) => <button key={item} className={type === item ? 'active' : ''} onClick={() => setType(item)}>{item}</button>)}</div>
      <div className="studio-editor-grid"><label><small>Kamernaam</small><input value={name} onChange={(e) => setName(e.target.value)} placeholder="Bijv. Woonkamer beneden" /></label><label><small>Hoort bij</small><select value={homeId} onChange={(e) => setHomeId(e.target.value)}>{homes.map((home) => <option key={home.id} value={home.id}>{home.title}</option>)}</select></label></div>
      <div className="studio-blueprint-preview"><Layers size={24} /><div><strong>{name || type}</strong><span>Start met fase 1 en bouw daarna je kamertijdlijn op.</span></div></div>
      {status ? <p className="status-message">{status}</p> : null}
      <button className="studio-publish-button" onClick={submit}><Check size={18} /> Start kamer</button>
    </section>
  );
}

function HomeBuilder({ auth }) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [style, setStyle] = useState(STYLE_OPTIONS[0]);
  const [status, setStatus] = useState('');
  async function submit() {
    if (!title.trim()) { setStatus('Geef je huisprofiel een naam.'); return; }
    try {
      await auth.req('/api/homes', { method: 'POST', body: JSON.stringify({ title, description, style_text: style, cover_url: DEFAULT_COVER }) });
      setStatus('Huisprofiel aangemaakt. Voeg nu kamers toe.'); setTitle(''); setDescription('');
    } catch (error) { setStatus(`Mislukt: ${error.message}`); }
  }
  return (
    <section className="studio-canvas-panel">
      <div className="studio-panel-heading"><small>Portfolio</small><h2>Huisprofiel bouwen</h2><p>Maak de etalage waar al je kamers onder vallen.</p></div>
      <article className="home-builder-preview"><img src={DEFAULT_COVER} alt="Huisprofiel preview" /><div><small>{style}</small><strong>{title || 'Naam van je huis'}</strong><p>{description || 'Schrijf hier kort welke sfeer, verbouwing of stijl je volgt.'}</p></div></article>
      <div className="studio-editor-grid"><label><small>Naam</small><input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Bijv. Villa Rutte" /></label><label><small>Stijlrichting</small><select value={style} onChange={(e) => setStyle(e.target.value)}>{STYLE_OPTIONS.map((item) => <option key={item}>{item}</option>)}</select></label></div>
      <label className="studio-story-field"><small>Bio</small><textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Wat maakt dit huis of project interessant om te volgen?" /></label>
      {status ? <p className="status-message">{status}</p> : null}
      <button className="studio-publish-button" onClick={submit}><Check size={18} /> Maak huisprofiel</button>
    </section>
  );
}

function BeforeAfterLab() {
  return (
    <section className="studio-canvas-panel">
      <div className="studio-panel-heading"><small>Lab</small><h2>Voor/na voorbereiden</h2><p>Dit wordt geen losse gimmick, maar een extra laag bovenop je kamertijdlijn.</p></div>
      <div className="before-after-lab"><div><span>Voor</span></div><i /><div><span>Na</span></div></div>
      <div className="studio-roadmap-list"><p><strong>Volgende release:</strong> twee foto’s kiezen, slider slepen en koppelen aan een bestaande kamer.</p><p><strong>Later:</strong> delen als story/reel en bewaren als transformatie-case.</p></div>
    </section>
  );
}

export function Studio({ auth, onPosted }) {
  const [data, setData] = useState({ homes: [], stats: {} });
  const [loading, setLoading] = useState(true);
  const [mode, setMode] = useState('update');
  const [selectedRoom, setSelectedRoom] = useState(null);

  useEffect(() => {
    let active = true;
    auth.req('/api/me/homes')
      .then((payload) => { if (active) setData(payload || { homes: [], stats: {} }); })
      .catch(() => { if (active) setData({ homes: [], stats: {} }); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [auth]);

  const homes = safeHomes(data);
  const rooms = useMemo(() => flattenRooms(data), [data]);
  const stats = { homes: homes.length, rooms: rooms.length, updates: data?.stats?.updates || rooms.reduce((sum, room) => sum + Number(room.updates || 0), 0), ...data?.stats };
  const primaryRoom = selectedRoom || rooms[0];

  return (
    <main className="screen studio-pro-screen studio-editor-screen">
      <TopBar title="Studio" subtitle="Jouw interieurwerkplaats" />
      <StudioIntro stats={stats} primaryRoom={primaryRoom} setMode={setMode} chooseRoom={setSelectedRoom} />

      <section className="studio-section">
        <div className="section-title"><span>Verder werken aan</span><small>{loading ? 'laden...' : `${rooms.length} kamers`}</small></div>
        <div className="studio-project-carousel">
          {rooms.slice(0, 10).map((room) => <StudioProjectCard key={room.id} room={room} active={selectedRoom?.id === room.id} onClick={() => { setSelectedRoom(room); setMode('update'); }} />)}
        </div>
        {!loading && !rooms.length ? <EmptyState title="Nog geen eigen kamers" text="Start met een huisprofiel of kamer. Daarna wordt Studio je projectoverzicht." /> : null}
      </section>

      <StudioModeSwitch mode={mode} setMode={setMode} />
      <AnimatePresence mode="wait">
        <motion.div key={mode} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: .22 }}>
          {mode === 'update' ? <UpdateWorkbench auth={auth} homes={homes} rooms={rooms} selectedRoom={primaryRoom} setSelectedRoom={setSelectedRoom} onPosted={onPosted} /> : null}
          {mode === 'room' ? <RoomBlueprint auth={auth} homes={homes} /> : null}
          {mode === 'home' ? <HomeBuilder auth={auth} /> : null}
          {mode === 'before' ? <BeforeAfterLab /> : null}
        </motion.div>
      </AnimatePresence>
    </main>
  );
}
