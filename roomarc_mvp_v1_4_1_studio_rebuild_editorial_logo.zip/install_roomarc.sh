#!/usr/bin/env bash
set -euo pipefail
SRC_DIR="$(cd "$(dirname "$0")" && pwd)"
TARGET="${ROOMARC_TARGET:-$HOME/roomarc}"
DATA_DIR="${ROOMARC_DATA_DIR:-$HOME/roomarc_data}"
SERVICE_NAME="${ROOMARC_SERVICE_NAME:-roomarc}"
PORT="${ROOMARC_PORT:-8899}"
PUBLIC_URL="http://$(hostname -I 2>/dev/null | awk '{print $1}'):${PORT}"

echo "============================================================"
echo "ROOMARC v1.4.1 service deployer"
echo "============================================================"
echo "Source: $SRC_DIR"
echo "Target: $TARGET"
echo "Persistent data: $DATA_DIR"
echo "Port: $PORT"

if [ ! -d "$SRC_DIR/roomarc" ]; then
  echo "ERROR: expected $SRC_DIR/roomarc inside extracted ZIP." >&2
  exit 1
fi

# Stop existing Roomarc service/process before replacing files.
if command -v systemctl >/dev/null 2>&1 && systemctl list-unit-files | grep -q "^${SERVICE_NAME}.service"; then
  echo "Stopping existing ${SERVICE_NAME}.service..."
  sudo systemctl stop "${SERVICE_NAME}.service" || true
fi
echo "Freeing port ${PORT} from old manual Roomarc uvicorn processes..."
pkill -f "uvicorn app.main:app.*--port ${PORT}" || true
sleep 1

rm -rf "$TARGET"
mkdir -p "$TARGET"
cp -a "$SRC_DIR/roomarc" "$TARGET/roomarc"
cd "$TARGET/roomarc"
mkdir -p "$DATA_DIR/media"

# Preserve existing JWT_SECRET if an old .env exists in persistent data, otherwise generate one.
SECRET=""
if [ -f "$DATA_DIR/roomarc.env" ]; then
  SECRET="$(grep '^JWT_SECRET=' "$DATA_DIR/roomarc.env" | sed 's/^JWT_SECRET=//' || true)"
fi
if [ -z "$SECRET" ]; then
  if command -v python3 >/dev/null 2>&1; then
    SECRET="$(python3 - <<'PY'
import secrets
print(secrets.token_urlsafe(32))
PY
)"
  else
    SECRET="roomarc-dev-secret"
  fi
fi

cat > .env <<EOF
ROOMARC_ENV=development
ROOMARC_HOST=0.0.0.0
ROOMARC_PORT=${PORT}
DATABASE_URL=sqlite:///${DATA_DIR}/roomarc.db
JWT_SECRET=${SECRET}
MEDIA_BACKEND=local
MEDIA_DIR=${DATA_DIR}/media
FRONTEND_DIST=frontend/dist
EOF
cp .env "$DATA_DIR/roomarc.env"

chmod +x scripts/*.sh
./scripts/install.sh

# Install/start systemd service when possible; fallback to foreground run otherwise.
if command -v systemctl >/dev/null 2>&1 && command -v sudo >/dev/null 2>&1; then
  echo "Installing/updating systemd service..."
  ./scripts/install_service.sh
  sudo systemctl restart "${SERVICE_NAME}.service"
  echo "Waiting for Roomarc service to become healthy..."
  ./scripts/healthcheck.sh
  echo "============================================================"
  echo "Roomarc v1.4.1 is running as a service."
  echo "URL: ${PUBLIC_URL:-http://SERVER-IP:${PORT}}"
  echo "Demo: demo@roomarc.local / demo123"
  echo "Service commands:"
  echo "  sudo systemctl status ${SERVICE_NAME}.service"
  echo "  sudo systemctl restart ${SERVICE_NAME}.service"
  echo "  journalctl -u ${SERVICE_NAME}.service -f"
  echo "============================================================"
else
  echo "systemd/sudo not available. Starting foreground server instead."
  echo "URL: http://SERVER-IP:${PORT}"
  exec ./scripts/run_dev.sh
fi
