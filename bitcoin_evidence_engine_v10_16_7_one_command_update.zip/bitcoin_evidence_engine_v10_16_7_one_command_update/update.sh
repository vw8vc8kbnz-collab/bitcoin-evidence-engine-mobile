#!/usr/bin/env bash
set -euo pipefail

# Bitcoin Evidence Engine - vaste VPS updater v10.16.7
# Gebruik voortaan op de VPS:
#   cd ~/bitcoin-engine-deploy
#   bash update.sh

REPO_URL="${REPO_URL:-https://github.com/vw8vc8kbnz-collab/bitcoin-evidence-engine-mobile.git}"
BASE_DIR="${BASE_DIR:-$HOME/bitcoin-engine-deploy}"
REPO_DIR="$BASE_DIR/github_latest"
RELEASES_DIR="$BASE_DIR/releases"
CURRENT_LINK="$BASE_DIR/current"
LOGS_DIR="$BASE_DIR/logs"
PORT="${PORT:-8787}"
APP_URL="http://51.195.102.180:${PORT}"

mkdir -p "$BASE_DIR" "$RELEASES_DIR" "$LOGS_DIR" "$HOME/bitcoin_evidence_data"
cd "$BASE_DIR"

echo "=============================================="
echo "Bitcoin Evidence Engine auto-update v10.16.7"
echo "Repo: $REPO_URL"
echo "Base: $BASE_DIR"
echo "=============================================="

if ! command -v git >/dev/null 2>&1 || ! command -v unzip >/dev/null 2>&1 || ! command -v curl >/dev/null 2>&1; then
  echo "Benodigde systeemtools installeren..."
  sudo apt-get update
  sudo apt-get install -y git unzip curl python3 python3-venv python3-pip build-essential golang-go procps rsync
fi

if [ ! -d "$REPO_DIR/.git" ]; then
  rm -rf "$REPO_DIR"
  echo "GitHub repo clonen..."
  git clone "$REPO_URL" "$REPO_DIR"
else
  echo "GitHub repo bijwerken..."
  git -C "$REPO_DIR" fetch --all --prune
  git -C "$REPO_DIR" reset --hard origin/main
fi

ZIP_FILE="$(find "$REPO_DIR" -maxdepth 2 -type f \( -iname 'bitcoin_evidence_engine*.zip' -o -iname 'engine*.zip' \) -printf '%T@ %p\n' | sort -nr | head -1 | cut -d' ' -f2-)"
STAMP="$(date +%Y%m%d_%H%M%S)"

if [ -n "${ZIP_FILE:-}" ] && [ -f "$ZIP_FILE" ]; then
  NAME="$(basename "$ZIP_FILE" .zip)"
  DEST="$RELEASES_DIR/${STAMP}_${NAME}"
  TMP="$BASE_DIR/.tmp_unpack_$STAMP"
  rm -rf "$TMP" "$DEST"
  mkdir -p "$TMP"
  echo "Nieuwste ZIP gevonden: $(basename "$ZIP_FILE")"
  unzip -q "$ZIP_FILE" -d "$TMP"

  APP_DIR=""
  while IFS= read -r mainfile; do
    candidate="$(dirname "$(dirname "$mainfile")")"
    if [ -f "$candidate/requirements.txt" ] && [ -f "$candidate/app/main.py" ]; then
      APP_DIR="$candidate"
      break
    fi
  done < <(find "$TMP" -type f -path '*/app/main.py' | sort)

  if [ -z "${APP_DIR:-}" ]; then
    while IFS= read -r reqfile; do
      candidate="$(dirname "$reqfile")"
      if [ -f "$candidate/app/main.py" ]; then
        APP_DIR="$candidate"
        break
      fi
    done < <(find "$TMP" -type f -name 'requirements.txt' | sort)
  fi

  if [ -z "${APP_DIR:-}" ]; then
    echo "❌ Geen geldige release-root gevonden in ZIP. Verwacht: requirements.txt + app/main.py."
    find "$TMP" -maxdepth 4 -type f | head -120
    exit 1
  fi
  mv "$APP_DIR" "$DEST"
  rm -rf "$TMP"
elif [ -f "$REPO_DIR/app/main.py" ] && [ -f "$REPO_DIR/requirements.txt" ]; then
  DEST="$RELEASES_DIR/${STAMP}_repo_direct"
  rm -rf "$DEST"
  mkdir -p "$DEST"
  rsync -a --exclude='.git' "$REPO_DIR/" "$DEST/"
else
  echo "❌ Geen ZIP en geen directe app gevonden in GitHub repo."
  echo "Zet je nieuwe bitcoin_evidence_engine*.zip in GitHub root en draai opnieuw: bash update.sh"
  exit 1
fi

ln -sfn "$DEST" "$CURRENT_LINK"
cd "$CURRENT_LINK"
echo "Actieve release: $DEST"

if [ ! -f requirements.txt ] || [ ! -f app/main.py ]; then
  echo "❌ Release mist requirements.txt of app/main.py. Inhoud:"
  ls -la
  exit 1
fi

echo "Oude server stoppen..."
pkill -f "uvicorn app.main:app" >/dev/null 2>&1 || true
sleep 1

if [ ! -d .venv ]; then
  echo "Virtualenv maken..."
  if ! python3 -m venv .venv >/dev/null 2>&1; then
    echo "python3-venv ontbreekt; installeren..."
    sudo apt-get update
    sudo apt-get install -y python3-venv python3-pip
    python3 -m venv .venv
  fi
fi
. .venv/bin/activate
python -m pip install --upgrade pip wheel setuptools

echo "Dependencies installeren met binary wheels..."
python -m pip install --only-binary=:all: -r requirements.txt

if [ -f build_native_core_linux.sh ]; then
  echo "Native core bouwen/controleren..."
  bash build_native_core_linux.sh || echo "Native build waarschuwing; ga door als bestaande binary aanwezig is."
fi

mkdir -p logs "$HOME/bitcoin_evidence_data"

echo "Nieuwe server starten..."
nohup .venv/bin/python -m uvicorn app.main:app --host 0.0.0.0 --port "$PORT" --proxy-headers > "$LOGS_DIR/server.log" 2>&1 &

ok=0
for i in $(seq 1 25); do
  if curl -fsS "http://127.0.0.1:${PORT}/api/health" >/dev/null 2>&1; then
    ok=1
    break
  fi
  sleep 1
done

if [ "$ok" = "1" ]; then
  echo ""
  echo "✅ UPDATE KLAAR"
  echo "Open: $APP_URL"
  echo "Log: $LOGS_DIR/server.log"
  echo "Voortaan alleen dit draaien:"
  echo "  cd $BASE_DIR && bash update.sh"
else
  echo ""
  echo "❌ Server startte niet goed. Laatste logregels:"
  tail -100 "$LOGS_DIR/server.log" || true
  exit 1
fi
