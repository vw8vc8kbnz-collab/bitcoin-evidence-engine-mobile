# SEE v1.5.0 Masterplan

Goal: move from headline classification to catalyst intelligence.

The engine now scores: event class, materiality, theme alignment, attention, historical analog strength, and probability of continuation. This remains local/no paid API, but is structured for future Ollama/FinBERT integration.
