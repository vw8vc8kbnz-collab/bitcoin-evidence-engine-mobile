#!/usr/bin/env bash
set -euo pipefail
APP_DIR="/home/ubuntu/stock_evidence_latest"
SERVICE="stock-evidence-dashboard.service"
cd "$APP_DIR"

sudo chown -R ubuntu:ubuntu "$APP_DIR" || true
chmod +x install.sh run_backtest.sh selftest.sh 2>/dev/null || true

python3 -m venv venv
./venv/bin/python -m pip install --upgrade pip
./venv/bin/python -m pip install -r requirements.txt
./venv/bin/python - <<'PY'
import yfinance, pandas, numpy, requests
print('[SEE install] dependency check OK')
PY

sudo tee /etc/systemd/system/$SERVICE > /dev/null <<'UNIT'
[Unit]
Description=Stock Evidence Engine Dashboard
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/home/ubuntu/stock_evidence_latest
ExecStart=/usr/bin/python3 /home/ubuntu/stock_evidence_latest/server.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
UNIT

sudo systemctl daemon-reload
sudo systemctl enable $SERVICE
sudo systemctl restart $SERVICE
sleep 1
sudo systemctl status $SERVICE --no-pager -l || true
