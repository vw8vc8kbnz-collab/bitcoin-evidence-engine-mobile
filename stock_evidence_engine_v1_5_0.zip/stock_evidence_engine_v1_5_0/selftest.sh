#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
for f in server.py engine.py install.sh run_backtest.sh requirements.txt VERSION; do
  test -f "$f" || { echo "missing $f"; exit 1; }
done
python3 -m py_compile server.py engine.py
python3 - <<'PY'
from pathlib import Path
s=Path('install.sh').read_text()
assert '/usr/bin/python3 /home/ubuntu/stock_evidence_latest/server.py' in s
assert 'stock-evidence-dashboard.service' in s
print('[SEE selftest] OK')
PY
