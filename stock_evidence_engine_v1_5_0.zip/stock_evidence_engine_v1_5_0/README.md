# Stock Evidence Engine v1.5.0

AI Catalyst Intelligence release. Stable stdlib dashboard on port 8798.

New:
- semantic materiality scoring
- event quality labels
- historical analog export
- 3d/10d continuation probability model
- AI catalyst + market reaction dashboard tabs
