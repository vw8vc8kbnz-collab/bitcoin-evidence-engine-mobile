#!/usr/bin/env python3
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
import json, html
VERSION='v1.5.0'; PORT=8798
BASE=Path('/home/ubuntu/stock_evidence_latest') if Path('/home/ubuntu/stock_evidence_latest').exists() else Path.cwd()
EXPORT=BASE/'exports'; DATA=BASE/'data'

def read_status():
    p=DATA/'status.json'
    if p.exists():
        try: return json.loads(p.read_text())
        except Exception: pass
    return {'ok':True,'version':VERSION,'trades':0,'summary_rows':0,'elite':0,'good':0,'news_items':0}

def table(path, limit=80):
    if not path.exists(): return '<p>No data yet. Run backtest first.</p>'
    import csv
    rows=list(csv.DictReader(path.open()))
    if not rows: return '<p>No rows.</p>'
    preferred=['ticker','theme','setup','hold_days','trades','winrate','avg_return','expectancy','evidence_score','ai_catalyst_score','materiality_score','prob_3d_continuation','prob_10d_continuation','top_event_type','top_event_quality','catalyst_score','theme_score','news_items','bullish_classes','bearish_classes','top_headline','rank_reason']
    cols=[c for c in preferred if c in rows[0]] or list(rows[0].keys())[:12]
    h='<table><thead><tr>'+''.join(f'<th>{html.escape(c)}</th>' for c in cols)+'</tr></thead><tbody>'
    for r in rows[:limit]:
        h+='<tr>'+''.join(f'<td>{html.escape(str(r.get(c,"")))}</td>' for c in cols)+'</tr>'
    return h+'</tbody></table>'

def page():
    st=read_status()
    summary=EXPORT/f'see_summary_{VERSION}.csv'; elite=EXPORT/f'see_elite_{VERSION}.csv'; setup=EXPORT/f'see_by_setup_{VERSION}.csv'; theme=EXPORT/f'see_theme_rotation_{VERSION}.csv'; catalyst=EXPORT/f'see_catalyst_{VERSION}.csv'; regime=EXPORT/f'see_regime_{VERSION}.csv'; news=EXPORT/f'see_news_intelligence_{VERSION}.csv'; events=EXPORT/f'see_catalyst_events_{VERSION}.csv'; ai=EXPORT/f'see_ai_catalyst_intelligence_{VERSION}.csv'; analog=EXPORT/f'see_historical_analogs_{VERSION}.csv'; reaction=EXPORT/f'see_market_reaction_model_{VERSION}.csv'
    return f'''<!doctype html><html><head><meta name="viewport" content="width=device-width, initial-scale=1"><title>SEE {VERSION}</title><style>
body{{font-family:-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;background:#f6f7fb;color:#111827;margin:0;padding:14px}}a{{color:#111827}}.hero,.card{{background:white;border-radius:24px;padding:18px;margin:0 0 14px;box-shadow:0 10px 28px rgba(15,23,42,.07)}}.badge{{display:inline-block;background:#111827;color:white;border-radius:999px;padding:7px 12px;font-weight:800;font-size:13px}}h1{{margin:10px 0 5px;font-size:34px;line-height:1.02}}h2{{font-size:24px;margin:4px 0 12px}}p{{line-height:1.35}}.grid{{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:14px 0}}.metric{{background:#fff;border-radius:22px;padding:16px;box-shadow:0 8px 22px rgba(15,23,42,.05)}}.big{{font-size:32px;font-weight:900}}small{{color:#64748b}}.tabs{{display:flex;gap:8px;overflow-x:auto;position:sticky;top:0;background:#f6f7fb;padding:8px 0;z-index:5}}.tab{{border:0;border-radius:999px;background:#e5e7eb;padding:10px 14px;font-weight:800;white-space:nowrap}}.tab.on{{background:#111827;color:white}}.panel{{display:none}}.panel.on{{display:block}}table{{border-collapse:collapse;width:100%;font-size:13px}}th,td{{padding:8px;border-bottom:1px solid #e5e7eb;text-align:left;white-space:nowrap}}.scroll{{overflow-x:auto;max-height:560px}}@media(min-width:760px){{body{{padding:22px}}.grid{{grid-template-columns:repeat(5,1fr)}}h1{{font-size:42px}}}}
</style></head><body><div class="hero"><span class="badge">Stock Evidence Engine {VERSION}</span><h1>AI Catalyst Intelligence</h1><p>Real headlines + semantic materiality + historical analogs + market reaction probability. No paid API required.</p><p><a href="/exports/all.zip">Download audit export ZIP</a> · <a href="/health">Health</a></p></div><div class="grid"><div class="metric"><div class="big">{st.get('trades',0)}</div><small>Trades</small></div><div class="metric"><div class="big">{st.get('summary_rows',0)}</div><small>Summary</small></div><div class="metric"><div class="big">{st.get('elite',0)}</div><small>Elite</small></div><div class="metric"><div class="big">{st.get('good',0)}</div><small>Good</small></div><div class="metric"><div class="big">{st.get('news_items',0)}</div><small>News</small></div></div><div class="tabs"><button class="tab on" onclick="show(event,'elite')">Elite</button><button class="tab" onclick="show(event,'news')">News</button><button class="tab" onclick="show(event,'events')">Catalysts</button><button class="tab" onclick="show(event,'ai')">AI Catalyst</button><button class="tab" onclick="show(event,'analog')">Analogs</button><button class="tab" onclick="show(event,'reaction')">Reaction</button><button class="tab" onclick="show(event,'setup')">Engines</button><button class="tab" onclick="show(event,'theme')">Themes</button><button class="tab" onclick="show(event,'regime')">Regime</button><button class="tab" onclick="show(event,'summary')">Summary</button></div><div id="elite" class="panel on card"><h2>Elite</h2><div class="scroll">{table(elite,80)}</div></div><div id="news" class="panel card"><h2>News Intelligence</h2><div class="scroll">{table(news,80)}</div></div><div id="events" class="panel card"><h2>Catalyst Events</h2><div class="scroll">{table(events,120)}</div></div><div id="ai" class="panel card"><h2>AI Catalyst Intelligence</h2><div class="scroll">{table(ai,80)}</div></div><div id="analog" class="panel card"><h2>Historical Analogs</h2><div class="scroll">{table(analog,100)}</div></div><div id="reaction" class="panel card"><h2>Market Reaction Model</h2><div class="scroll">{table(reaction,100)}</div></div><div id="setup" class="panel card"><h2>By Setup</h2><div class="scroll">{table(setup,80)}</div></div><div id="theme" class="panel card"><h2>Theme Rotation</h2><div class="scroll">{table(theme,80)}</div></div><div id="regime" class="panel card"><h2>Regime</h2><div class="scroll">{table(regime,20)}</div></div><div id="summary" class="panel card"><h2>Summary</h2><div class="scroll">{table(summary,100)}</div></div><script>function show(e,id){{document.querySelectorAll('.panel').forEach(x=>x.classList.remove('on'));document.querySelectorAll('.tab').forEach(x=>x.classList.remove('on'));document.getElementById(id).classList.add('on');e.target.classList.add('on')}}</script></body></html>'''
class H(BaseHTTPRequestHandler):
    def sendb(self,code,body,ctype='text/html; charset=utf-8'):
        if isinstance(body,str): body=body.encode('utf-8')
        self.send_response(code); self.send_header('Content-Type',ctype); self.send_header('Content-Length',str(len(body))); self.end_headers()
        if self.command!='HEAD': self.wfile.write(body)
    def do_HEAD(self): self.do_GET()
    def do_GET(self):
        if self.path.startswith('/health'): self.sendb(200,json.dumps(read_status()),'application/json')
        elif self.path.startswith('/exports/all.zip'):
            p=EXPORT/'all.zip'
            self.sendb(200,p.read_bytes(),'application/zip') if p.exists() else self.sendb(404,'missing export')
        else: self.sendb(200,page())
HTTPServer(('0.0.0.0',PORT),H).serve_forever()
