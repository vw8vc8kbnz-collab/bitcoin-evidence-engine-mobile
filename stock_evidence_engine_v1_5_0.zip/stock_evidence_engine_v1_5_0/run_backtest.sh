#!/usr/bin/env bash
set -euo pipefail
cd /home/ubuntu/stock_evidence_latest
TICKERS="${1:-BB,PLTR,IONQ,SOUN,NVDA,AMD,TSLA,AI,BBAI,RKLB,SMR,ACHR,JOBY,UPST,HOOD,COIN,MARA,RIOT,LCID,RIVN}"
PERIOD="${2:-2y}"
if [ ! -x ./venv/bin/python ]; then
  echo "[SEE] venv missing. Run ./install.sh first." >&2
  exit 1
fi
./venv/bin/python - <<'PY'
import yfinance
print('[SEE] yfinance OK')
PY
./venv/bin/python engine.py --tickers "$TICKERS" --period "$PERIOD"
