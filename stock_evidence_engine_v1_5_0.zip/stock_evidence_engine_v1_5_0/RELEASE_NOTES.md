# v1.5.0

Adds local AI-style catalyst intelligence without paid LLM/API dependency.

- Materiality layer: minor/medium/major bullish or bearish event quality
- Historical analog model: theme/setup/ticker analog strength
- Market reaction model: 3d and 10d continuation probabilities
- New exports: see_ai_catalyst_intelligence, see_historical_analogs, see_market_reaction_model
- Keeps v1.1.0+ deployment baseline: server.py, port 8798, fixed venv for backtest
