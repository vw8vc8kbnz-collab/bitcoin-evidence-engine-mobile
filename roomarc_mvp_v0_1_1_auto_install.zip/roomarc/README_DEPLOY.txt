ROOMARC MVP v0.1.1

One-command GitHub/VPS install after you upload this ZIP to the repo root:

cd ~ && rm -rf roomarc-src roomarc-unpack roomarc && git clone https://github.com/vw8vc8kbnz-collab/bitcoin-evidence-engine-mobile.git roomarc-src && mkdir -p roomarc-unpack && unzip -oq roomarc-src/roomarc_mvp_v0_1_1_auto_install.zip -d roomarc-unpack && bash roomarc-unpack/install_roomarc.sh

Manual install:

unzip roomarc_mvp_v0_1_1_auto_install.zip -d roomarc-unpack
bash roomarc-unpack/install_roomarc.sh

Open:
http://SERVER-IP:8899

Demo login:
demo@roomarc.local
demo123

Notes:
- Do not run inside the Bitcoin Evidence Engine folder.
- Installer prefers Python 3.12/3.11 and avoids Python 3.13 source-build issues.
- Frontend dist is bundled, so Node/npm is not required for normal VPS testing.
