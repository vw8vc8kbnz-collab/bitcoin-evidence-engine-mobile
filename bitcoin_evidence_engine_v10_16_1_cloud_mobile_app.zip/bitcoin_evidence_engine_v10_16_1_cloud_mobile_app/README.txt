Bitcoin Evidence Engine V10.15.5 - Fast Incremental History

Deze versie fixt het probleem waarbij Historical Memory na één pass rond 15.416 rows kon blijven hangen.

Belangrijkste wijziging:
- De history-daemon doet nu eerst alleen history completion.
- Feature rebuild en learning bootstrap worden niet meer tussendoor gestart zolang 70k history nog niet compleet is.
- Daardoor kan Random/Learning de DB/native core niet meer bezetten terwijl de backfill nog bezig is.
- De daemon blijft meerdere passes draaien tot 70.000 rows of de historische startdatum is bereikt.
- UI-status blijft live tonen hoeveel rows geladen zijn.

Start met start.bat.

Bitcoin Evidence Engine V10.15.5 - Fast Incremental History

Start met start.bat.

Belangrijk in deze versie:
- Historical Memory Completion is nu volledig automatisch bij opstarten: de app start zelf de 70k BTCUSDT 1H backfill-daemon.
- De gebruiker hoeft niet meer op Complete History te klikken om de grote historical-memory bottleneck aan te pakken.
- De knop is hernoemd naar "Check Auto History" en blokkeert niet meer; hij controleert/start alleen dezelfde auto-daemon opnieuw als dat nodig is.
- De zijbalk toont duidelijk of history nog automatisch laadt, in wachtrij staat, wacht/retry doet of volledig geladen is.
- De zijbalk toont stored_rows / target_rows, coverage percentage, remaining rows en een voortgangsbalk.
- Als history compleet is, toont de UI expliciet "Volledig geladen" / "Klaar · 100%".
- De 70k history-daemon blijft onafhankelijk van de startup forecast-pipeline. Als forecast startup timeout/fout geeft, loopt de memory-backfill alsnog door.
- Binance historical backfill gebruikt langere timeouts, retries per chunk en duidelijke auditregels in logs/sync_audit.jsonl.
- Adaptive learning blijft bewust conservatief: eerst echte historische samples opbouwen, daarna pas weights activeren.
- C++ native core blijft leidend voor zware Time Machine / similarity paden; geen Python fallback als hoofdstrategie.

Eerste controle na starten:
1. Open de app.
2. Kijk links bij HISTORY MEMORY AUTO.
3. Je moet automatisch voortgang zien richting 70.000 / 70.000.
4. Als alles binnen is, moet daar duidelijk "Volledig geladen" en 100% staan.
5. Details staan in logs/sync_audit.jsonl en logs/historical_memory_audit.jsonl.


V10.15.7 Seed Snapshot Verifier
- Fix: failsafe frontend now polls /api/historical-memory/status directly.
- Fix: HISTORY MEMORY AUTO no longer stays on startup text while backend is actually backfilling.
- Fix: Check Auto History button is wired in failsafe UI and shows live progress/error/complete state.
- Cache bust updated so browser reloads the corrected JS.

V10.15.5 FAST INCREMENTAL HISTORY
---------------------------------
Deze build voorkomt dat de volledige 70k Binance 1h-historie opnieuw wordt geladen bij elke nieuwe ZIP-versie.

Belangrijk:
- De database/cache staat nu standaard gedeeld in:
  %LOCALAPPDATA%\BitcoinEvidenceEngine\data
- Bij eerste start probeert de app automatisch de grootste/beste database uit oudere uitgepakte Bitcoin Evidence Engine-mappen te kopiëren.
- Als History Memory al 70.000+ candles heeft, wordt bij opstart alleen de recente Binance-window bijgewerkt.
- De UI moet dan tonen: Volledig geladen / 100%, in plaats van minutenlang opnieuw backfillen.

Als de gedeelde cache nog leeg is en er geen oude database gevonden wordt, moet de eerste run nog steeds één keer de volledige historie ophalen.
