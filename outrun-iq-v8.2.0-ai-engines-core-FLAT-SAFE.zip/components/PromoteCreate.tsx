"use client";
import { useMemo, useState } from "react";
import type { Listing } from "@/lib/types";

export function PromoteCreate({ listings }:{ listings: Pick<Listing, "id" | "title" | "category">[] }) {
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");
  const [selected, setSelected] = useState<string[]>(listings.slice(0, 4).map(l => l.id));
  const selectedSet = useMemo(() => new Set(selected), [selected]);
  function toggle(id: string) {
    setSelected(cur => cur.includes(id) ? cur.filter(x => x !== id) : [...cur, id].slice(0, 20));
  }
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true); setMsg("");
    const fd = new FormData(e.currentTarget);
    const kind = String(fd.get("kind") || "seller");
    const category = String(fd.get("category") || "");
    const name = String(fd.get("name") || "Outrun Promote");
    const objective = String(fd.get("objective") || "views");
    const budgetDaily = Number(fd.get("budgetDaily") || 5);
    const days = Number(fd.get("days") || 7);
    const listingIds = selected;
    try {
      if (kind === "listing" && listingIds.length === 0) throw new Error("Kies minimaal één product voor een productcampagne");
      const r = await fetch("/api/partner/promote", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ kind, listingIds, category, name, objective, budgetDaily, days }),
      });
      const j = await r.json().catch(() => ({}));
      if (!r.ok || j.error) throw new Error(j.error || "Campagne kon niet starten");
      setMsg(`Campagne gestart met ${kind === "listing" ? listingIds.length : "AI-geselecteerde"} producten. AI maakt 5 varianten en verdeelt zichtbaarheid eerlijk over de dag.`);
      setTimeout(() => location.reload(), 650);
    } catch (err) { setMsg(err instanceof Error ? err.message : "Fout"); }
    finally { setBusy(false); }
  }
  return (
    <form className="promoteForm promoteFormMulti" onSubmit={submit}>
      <label>Campagnenaam<input name="name" defaultValue="Partner Spotlight" /></label>
      <label>Type<select name="kind" defaultValue="seller"><option value="seller">Bedrijf promoten</option><option value="listing">Productcollectie promoten</option><option value="category">Categorie promoten</option></select></label>
      <div className="promoteProductPicker">
        <span className="promoteLabel">Producten</span>
        <p className="note">Vink meerdere producten aan. De AI maakt hier één campagnecollectie van en wisselt de producten slim af.</p>
        <div className="promoteChecks">
          {listings.slice(0, 40).map(l => <button key={l.id} type="button" onClick={() => toggle(l.id)} className={selectedSet.has(l.id) ? "on" : ""}>
            <span>{selectedSet.has(l.id) ? "✓" : "+"}</span><b>{l.title}</b><small>{l.category}</small>
          </button>)}
        </div>
        <div className="promoteSelectBar"><b>{selected.length}</b><span>producten geselecteerd</span><button type="button" onClick={() => setSelected(listings.slice(0, 8).map(l => l.id))}>AI startselectie</button><button type="button" onClick={() => setSelected([])}>Wis</button></div>
      </div>
      <label>Categorie<select name="category"><option value="">— kies categorie —</option><option value="witgoed">Witgoed</option><option value="meubels">Meubels</option><option value="keukens">Keukens</option><option value="tuin">Tuin</option><option value="overig">Overig</option></select></label>
      <label>Doel<select name="objective" defaultValue="sell_faster"><option value="views">Meer views</option><option value="chats">Meer chats</option><option value="sell_faster">Sneller verkopen</option><option value="brand">Meer winkelbezoeken</option></select></label>
      <div className="promoteSplit"><label>Budget/dag<input name="budgetDaily" type="number" min="3" max="100" defaultValue="7" /></label><label>Dagen<input name="days" type="number" min="1" max="30" defaultValue="7" /></label></div>
      <article className="promoteFairness"><b>AI-verdeling</b><span>Campagnes worden niet achter elkaar afgespeeld. Outrun mixt alle actieve campagnes op relevantie, budget, cooldown en fairness, zodat meerdere bedrijven verspreid door de dag terugkomen.</span></article>
      <button className="btn pri" disabled={busy}>{busy ? "AI maakt varianten..." : "Maak AI-campagne"}</button>
      {msg && <p className="note">{msg}</p>}
    </form>
  );
}
