# AlgoRoute v1.8.12 — Queue Geocode Optimize Fix

Fix voor Mapping → Queue → Optimize vastloper.

- Optimize voert nu automatisch PDOK/BAG geocoding uit als orders nog GPS nodig hebben.
- Queue status wordt server-side opnieuw berekend.
- Postcode ontbreekt blokkeert niet meer zolang adres/plaats bruikbaar is voor PDOK.
- Optimize geeft PDOK auto-resultaat terug.
- C++ optimizer blijft de route/load core.
