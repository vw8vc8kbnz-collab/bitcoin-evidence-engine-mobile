OUTRUN IQ — LOGO PACK V1
========================

MERKTEKEN "SIGNAL RING": open petrol score-ring, amber marker breekt uit de baan.
Betekenis: voorraad die de stilstand outrunt. Zelfde motief als de Outlet Score
ring en de Price Evidence Strip in het platform-UI.

KLEUREN
  Ink          #12161B   (donkere achtergronden / mono-black)
  Paper        #EFF1ED   (lichte achtergronden)
  Petrol       #0E5A5E   (ring + "IQ" op licht)
  Petrol Glow  #35A9AC   (ring + "IQ" op donker)
  Amber        #E9A13B   (de marker — nooit vervangen)

MAPPEN
  /lockup       Volledig logo (mark + woordmerk), 4096 / 2048 / 1024 px breed
                - transparent_light-bg-use : transparant, voor LICHTE achtergronden
                - transparent_dark-bg-use  : transparant, voor DONKERE achtergronden
                - on-paper / on-ink        : met achtergrondvlak
                - mono-black / mono-white  : één kleur (print, watermerk, embossing)
  /wordmark     Alleen het woordmerk, transparant, 4096 / 1024 px
  /mark         Alleen het merkteken, transparant, 4096 t/m 32 px (incl. favicon-maten)
  /app-icon     Afgeronde app-tegel (ink & petrol), 1024 / 512 px
  /svg-masters  Vector-bronbestanden (oneindig schaalbaar, custom letterpaths — geen font nodig)

GEBRUIKSREGELS
  1. Minimale vrije ruimte rond het logo: de diameter van de amber marker.
  2. De marker is altijd amber, ook in kleurvarianten. Alleen mono-versies zijn uniform.
  3. Kleinste formaat lockup: 140 px breed. Daaronder: alleen het merkteken.
  4. Nooit roteren, schuintrekken, van schaduw of gloed voorzien.
  5. Op fotografie: mono-white of mono-black gebruiken.

Woordmerk is custom getekende geometrische monoline — geen fontlicentie nodig.
