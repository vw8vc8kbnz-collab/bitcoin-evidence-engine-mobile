# Outrun IQ v0.2 Intro Splash VPS Ready

Run locally:

```bash
HOST=0.0.0.0 PORT=8795 python3 server.py
```

Health:

```bash
curl -s http://127.0.0.1:8795/api/health
```

This package is the first custom foundation build: premium buyer homepage, product grid/detail, checkout trust flow, seller dashboard, AI pricing upload flow, language switcher and seller intake endpoint.


## v0.2 changes
- Desktop startup intro video (landscape)
- Mobile startup intro video (portrait)
- Smooth fade transition into app/site
- Intro shown once per browser session; skip button included
- Server defaults to HOST=0.0.0.0 for VPS access
