#!/usr/bin/env python3
import json, os, time, uuid
from pathlib import Path
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent
STATIC = ROOT / 'static'
DATA = ROOT / 'data'
DATA.mkdir(exist_ok=True)
SELLERS = DATA / 'seller_intakes.jsonl'

PORT = int(os.environ.get('PORT', '8795'))
HOST = os.environ.get('HOST', '0.0.0.0')
VERSION = 'outrun-iq-v0.4-mobile-app-shell-intro'

class Handler(SimpleHTTPRequestHandler):
    server_version = 'OutrunIQ/0.4'
    def translate_path(self, path):
        parsed = urlparse(path).path
        if parsed.startswith('/static/'):
            return str(ROOT / parsed.lstrip('/'))
        if parsed in ('/', '/zoeken', '/listing', '/checkout', '/order', '/seller', '/pricing', '/store', '/verkopen'):
            return str(STATIC / 'index.html')
        return str(STATIC / parsed.lstrip('/'))

    def do_GET(self):
        parsed = urlparse(self.path).path
        if parsed == '/api/health':
            self._json({'ok': True, 'version': VERSION, 'ts': int(time.time())})
            return
        if parsed == '/api/demo/state':
            self._json({
                'ok': True,
                'version': VERSION,
                'brand': 'Outrun IQ',
                'tagline': 'Move inventory smarter.',
                'default_language': 'nl',
                'languages': ['nl','en','de','fr'],
                'ux_locks': ['mobile app shell','bewijsdichtheid','Price Evidence Strip','full-page checkout','visible escrow','single overlay system','no dark patterns'],
                'intro': {'desktop':'landscape 3840x2160', 'mobile':'portrait 2160x3840'}
            })
            return
        super().do_GET()

    def do_POST(self):
        parsed = urlparse(self.path).path
        if parsed == '/api/seller/intake':
            length = int(self.headers.get('content-length') or 0)
            raw = self.rfile.read(length).decode('utf-8') if length else '{}'
            try:
                payload = json.loads(raw)
            except Exception:
                self._json({'ok': False, 'error': 'invalid_json'}, 400); return
            payload['id'] = str(uuid.uuid4())
            payload['created_at'] = int(time.time())
            with SELLERS.open('a', encoding='utf-8') as f:
                f.write(json.dumps(payload, ensure_ascii=False) + '\n')
            self._json({'ok': True, 'id': payload['id']})
            return
        self._json({'ok': False, 'error': 'not_found'}, 404)

    def _json(self, data, status=200):
        body = json.dumps(data, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control','no-store')
        self.end_headers(); self.wfile.write(body)

if __name__ == '__main__':
    os.chdir(STATIC)
    print(f'Outrun IQ {VERSION} on http://{HOST}:{PORT}')
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
