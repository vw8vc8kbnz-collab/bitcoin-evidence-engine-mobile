# Outrun IQ v0.4 — Mobile App Shell + Intro Diagnostics

Wijzigingen:
- Mobile is nu een echte app-shell: vaste topbar, tabbar, losse schermen, interne scroll per screen.
- Geen lange mobiele webpagina meer.
- Mobile schermen: Home, Deals, Stores, Productdetail, Checkout, Order, Seller Dashboard, AI Scan.
- Desktop blijft premium landing/mockflow.
- Intro-video's worden 1-op-1 meegeleverd zonder extra compressie.

Let op introkwaliteit:
De meegeleverde bestanden hebben bestandsnamen met 4K, maar de daadwerkelijk ontvangen MP4's zijn ongeveer:
- mobile: 512x910, ±1.08 Mbps totaal
- desktop: 910x512, ±1.11 Mbps totaal
Dus als de intro zacht/blokkerig oogt, komt dat door de bron die in deze chat is ontvangen, niet door de serverbuild.

Start:
HOST=0.0.0.0 PORT=8795 python3 server.py
