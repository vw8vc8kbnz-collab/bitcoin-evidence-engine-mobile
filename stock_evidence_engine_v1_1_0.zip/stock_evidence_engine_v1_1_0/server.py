#!/usr/bin/env python3
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from datetime import datetime
import json, argparse, urllib.parse

ROOT=Path(__file__).resolve().parent
DATA=ROOT/'data'; EXPORTS=ROOT/'exports'
VERSION='v1.1.0'

def load_state():
    p=DATA/'state.json'
    if not p.exists():
        return {'version':VERSION,'updated_at':'never','summary_rows':0,'trades':0,'elite':0,'good':0,'tickers':0,'top':[],'by_setup':[],'by_ticker':[]}
    try: return json.loads(p.read_text())
    except Exception: return {'version':VERSION,'top':[],'by_setup':[],'by_ticker':[]}

def esc(x):
    return str(x).replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')

def rows_table(rows, cols):
    if not rows: return '<div class="card"><b>Geen data.</b> Run eerst backtest.</div>'
    head=''.join(f'<th>{esc(c)}</th>' for c in cols)
    body=''
    for r in rows[:80]:
        body+='<tr>'+''.join(f'<td>{esc(r.get(c,""))}</td>' for c in cols)+'</tr>'
    return f'<div class="tablewrap"><table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></div>'

def page(path='/'):
    s=load_state(); top=s.get('top',[]); elite=[r for r in top if r.get('elite')]
    usable=[r for r in top if not r.get('fake_alpha_warning')]
    by_setup=s.get('by_setup',[]); by_ticker=s.get('by_ticker',[])
    nav='''<div class="nav"><a href="/">Overview</a><a href="/elite">Elite</a><a href="/diagnostics">Diagnostics</a><a href="/tickers">Tickers</a><a href="/exports/all.zip">Download ZIP</a></div>'''
    if path.startswith('/elite'):
        content='<h2>Elite evidence</h2>'+rows_table(elite or [r for r in top if r.get('tier')=='ELITE'], ['ticker','setup','hold','trades','winrate','expectancy_pct','evidence_score','catalyst_score','rank_reason'])
    elif path.startswith('/diagnostics'):
        content='<h2>Engine diagnostics</h2>'+rows_table(by_setup, ['name','rows','trades','good','elite','avg_evidence','avg_expectancy'])+'<div class="note">Doel v1.1.0: legacy momentum ontleden en zien welke engine daadwerkelijk bijdraagt.</div>'
    elif path.startswith('/tickers'):
        content='<h2>By ticker</h2>'+rows_table(by_ticker, ['name','rows','trades','good','elite','avg_evidence','avg_expectancy'])
    else:
        content='<h2>Beste evidence-resultaten</h2>'+rows_table(top, ['ticker','setup','hold','trades','winrate','expectancy_pct','evidence_score','confidence','catalyst_score','tier'])
    html=f'''<!doctype html><html><head><meta name="viewport" content="width=device-width, initial-scale=1"><title>SEE {VERSION}</title><style>
body{{font-family:-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;background:#f4f7fb;color:#0f172a;margin:0;padding:18px 16px 80px}} .hero{{background:linear-gradient(135deg,#0b3158,#1378b5);color:white;border-radius:28px;padding:28px;margin:8px 0 22px;box-shadow:0 18px 40px rgba(2,8,23,.18)}} .kicker{{letter-spacing:.2em;color:#ffd166;font-weight:900;font-size:13px}} h1{{font-size:42px;line-height:1;margin:12px 0}} h2{{font-size:30px;margin:24px 0 14px}} .grid{{display:grid;grid-template-columns:1fr 1fr;gap:14px}} .metric,.card{{background:white;border-radius:22px;padding:20px;box-shadow:0 10px 28px rgba(15,23,42,.08)}} .big{{font-size:40px;font-weight:900}} small,.muted{{color:#64748b;font-weight:700}} .nav{{display:flex;gap:10px;overflow:auto;margin:10px 0 18px}} .nav a{{white-space:nowrap;text-decoration:none;background:#0f172a;color:white;border-radius:999px;padding:11px 14px;font-weight:800}} .tablewrap{{overflow:auto;background:white;border-radius:20px;box-shadow:0 10px 28px rgba(15,23,42,.08)}} table{{border-collapse:collapse;width:100%;min-width:860px}} th{{background:#111827;color:white;text-align:left;padding:14px}} td{{padding:13px;border-bottom:1px solid #e5e7eb}} .note{{margin-top:16px;background:#fff7ed;border-radius:18px;padding:16px;font-weight:700}} .footer{{margin-top:22px;color:#64748b}}
</style></head><body><div class="hero"><div class="kicker">ENGINE DIAGNOSTICS + CATALYST SCORING</div><h1>Stock Evidence Engine</h1><p>v1.1.0 · legacy momentum dissectie · catalyst proxy · export ZIP.</p></div>{nav}<div class="grid"><div class="metric"><div class="big">{s.get('summary_rows',0)}</div><small>result rows</small></div><div class="metric"><div class="big">{s.get('trades',0)}</div><small>historical trades</small></div><div class="metric"><div class="big">{s.get('elite',0)}</div><small>elite rows</small></div><div class="metric"><div class="big">{s.get('good',0)}</div><small>good candidates</small></div></div>{content}<div class="footer">{VERSION} · server time {datetime.utcnow().isoformat()}Z · backtest-first, no live trading advice</div></body></html>'''
    return html.encode()

class H(BaseHTTPRequestHandler):
    def do_HEAD(self):
        self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.end_headers()
    def do_GET(self):
        path=urllib.parse.urlparse(self.path).path
        if path=='/health':
            data=json.dumps({'ok':True,'version':VERSION,'time':datetime.utcnow().isoformat()+'Z'}).encode(); self.send_response(200); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data); return
        if path=='/exports/all.zip':
            p=EXPORTS/'all.zip'
            if not p.exists(): self.send_response(404); self.end_headers(); return
            data=p.read_bytes(); self.send_response(200); self.send_header('Content-Type','application/zip'); self.send_header('Content-Disposition','attachment; filename="see_audit_export_v1_1_0.zip"'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data); return
        data=page(path); self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('--host',default='0.0.0.0'); ap.add_argument('--port',type=int,default=8798); args=ap.parse_args()
    print(f'[SEE] dashboard {VERSION} on {args.host}:{args.port}', flush=True)
    HTTPServer((args.host,args.port),H).serve_forever()
