# Stock Evidence Engine v1.1.0

Engine Diagnostics + Catalyst Scoring release.

- One runtime: `server.py`
- Port: `8798`
- Export ZIP: `/exports/all.zip`
- New export: `see_engine_diagnostics_v1.1.0.csv`

Run:
```bash
./install.sh
./run_backtest.sh "BB,PLTR,IONQ,SOUN,NVDA,AMD,TSLA,AI,BBAI,RKLB,SMR,ACHR,JOBY,UPST,HOOD,COIN,MARA,RIOT,LCID,RIVN" "2y"
```


## v1.1.0 fix
- Installer creates `venv` and installs yfinance/pandas/numpy/requests.
- `run_backtest.sh` always uses `./venv/bin/python`.
- Backtest fails loudly if dependencies are missing instead of silently exporting zero trades.
- Dashboard stays stdlib `server.py` on port 8798.
