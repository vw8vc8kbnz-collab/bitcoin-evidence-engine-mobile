#!/usr/bin/env bash
set -euo pipefail

APP_DIR="/home/ubuntu/stock_evidence_latest"
SERVICE="/etc/systemd/system/stock-evidence-dashboard.service"
PORT="8798"

cd "$APP_DIR"
mkdir -p data exports logs

echo "[SEE] Fix ownership"
sudo chown -R ubuntu:ubuntu "$APP_DIR" || true

echo "[SEE] Create/repair venv"
rm -rf venv
python3 -m venv venv
./venv/bin/python -m pip install --upgrade pip
./venv/bin/python -m pip install -r requirements.txt

echo "[SEE] Dependency check"
./venv/bin/python - <<'PY'
import importlib, sys
mods=["yfinance","pandas","numpy","requests"]
missing=[m for m in mods if importlib.util.find_spec(m) is None]
if missing:
    print("[SEE] Missing deps:", missing)
    sys.exit(2)
print("[SEE] Dependencies OK")
PY

echo "[SEE] Write systemd service"
sudo tee "$SERVICE" > /dev/null <<EOF
[Unit]
Description=Stock Evidence Engine Dashboard
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=$APP_DIR
ExecStart=/usr/bin/python3 $APP_DIR/server.py --host 0.0.0.0 --port $PORT
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable stock-evidence-dashboard.service
sudo systemctl restart stock-evidence-dashboard.service

echo "[SEE] Install complete on port $PORT"
