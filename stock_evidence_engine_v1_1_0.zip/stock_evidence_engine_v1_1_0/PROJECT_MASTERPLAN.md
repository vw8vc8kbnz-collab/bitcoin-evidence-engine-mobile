# SEE v1.1.0 Masterplan

Focus: diagnose why legacy momentum works and add a first measurable catalyst proxy.

New in v1.1.0:
- Engine diagnostics by setup
- Catalyst/theme proxy score
- Extra export CSV for diagnostics
- Dashboard tabs: Overview, Elite, Diagnostics, Tickers
- Same stable server.py deployment baseline
