import { NextResponse, type NextRequest } from "next/server";
import { randomUUID } from "node:crypto";
import { mutate } from "@/lib/store";
import { createSession, SESSION_COOKIE, hashPassword } from "@/lib/auth";
import type { User, Seller } from "@/lib/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function testModeEnabled() {
  return process.env.TEST_MODE_ENABLED === "true" || process.env.NEXT_PUBLIC_TEST_MODE_ENABLED === "true";
}

const nowIso = () => new Date().toISOString();
const pass = () => hashPassword(`test-mode-${Date.now()}-${Math.random()}`);

type TestProfile = {
  id: string;
  role: "consument" | "partner" | "admin";
  email: string;
  name: string;
  redirectRoleLabel: string;
  seller?: Omit<Seller, "createdAt">;
};

const TEST_PROFILES: TestProfile[] = [
  {
    id: "buyer",
    role: "consument",
    email: "test-buyer@outrun.test",
    name: "Test Buyer",
    redirectRoleLabel: "Buyer testaccount",
  },
  {
    id: "partner-outlet-a",
    role: "partner",
    email: "test-partner-a@outrun.test",
    name: "Partner A Tester",
    redirectRoleLabel: "Partner — Outletbedrijf A",
    seller: {
      slug: "test-outlet-a",
      name: "Outrun Test Outlet A",
      city: "Amsterdam",
      kvk: "00000001",
      contactPerson: "Partner A Tester",
      businessEmail: "test-partner-a@outrun.test",
      businessPhone: "020-0000001",
      deliveryOptions: ["Ophalen", "Bezorging in overleg"],
      shippingCost: 0,
      payout: { bankStatus: "verified", ibanMasked: "NL** TEST 0001" },
      stripeConnect: { status: "not_started" },
      support: { email: "test-partner-a@outrun.test", returnsInfo: "Testmodus: retourregels niet actief." },
      about: "Testbedrijf A voor outletvoorraad, showroommodellen en restpartijen.",
      address: { street: "Teststraat 1", postcode: "1000 AA", city: "Amsterdam" },
      trusted: true,
      payment: { provider: "test", onboardingStatus: "complete", payoutsEnabled: false },
    },
  },
  {
    id: "partner-outlet-b",
    role: "partner",
    email: "test-partner-b@outrun.test",
    name: "Partner B Tester",
    redirectRoleLabel: "Partner — Outletbedrijf B",
    seller: {
      slug: "test-outlet-b",
      name: "Outrun Test Outlet B",
      city: "Rotterdam",
      kvk: "00000002",
      contactPerson: "Partner B Tester",
      businessEmail: "test-partner-b@outrun.test",
      businessPhone: "010-0000002",
      deliveryOptions: ["Ophalen", "Pallettransport"],
      shippingCost: 39,
      payout: { bankStatus: "pending", ibanMasked: "NL** TEST 0002" },
      stripeConnect: { status: "pending" },
      support: { email: "test-partner-b@outrun.test", returnsInfo: "Testmodus: retourregels niet actief." },
      about: "Testbedrijf B voor restpartijen en B-stock.",
      address: { street: "Havenweg 22", postcode: "3000 BB", city: "Rotterdam" },
      trusted: false,
      payment: { provider: "test", onboardingStatus: "pending", payoutsEnabled: false },
    },
  },
  {
    id: "partner-witgoed",
    role: "partner",
    email: "test-witgoed@outrun.test",
    name: "Witgoed Tester",
    redirectRoleLabel: "Partner — Witgoed/retourbedrijf",
    seller: {
      slug: "test-witgoed-retouren",
      name: "Test Witgoed Retouren",
      city: "Eindhoven",
      kvk: "00000003",
      contactPerson: "Witgoed Tester",
      businessEmail: "test-witgoed@outrun.test",
      businessPhone: "040-0000003",
      deliveryOptions: ["Bezorging met afspraak", "Ophalen magazijn"],
      shippingCost: 49,
      payout: { bankStatus: "verified", ibanMasked: "NL** TEST 0003" },
      stripeConnect: { status: "restricted" },
      support: { email: "test-witgoed@outrun.test", returnsInfo: "Testmodus: witgoed-retouren." },
      about: "Testpartner gespecialiseerd in witgoed, retouren en showroommodellen.",
      address: { street: "Magazijnlaan 7", postcode: "5600 CC", city: "Eindhoven" },
      trusted: true,
      payment: { provider: "test", onboardingStatus: "pending", payoutsEnabled: false },
    },
  },
  {
    id: "admin",
    role: "admin",
    email: "test-admin@outrun.test",
    name: "Test Admin",
    redirectRoleLabel: "Admin testaccount",
  },
];

export async function POST(req: NextRequest) {
  if (!testModeEnabled()) return NextResponse.json({ error: "Test mode staat uit" }, { status: 404 });

  const b = await req.json().catch(() => ({}));
  const profileId = String(b.profileId || "buyer");
  const profile = TEST_PROFILES.find(p => p.id === profileId) || TEST_PROFILES[0];
  const now = nowIso();
  let userId = "";

  const result = await mutate(db => {
    let partnerSlug: string | undefined;
    if (profile.seller) {
      const existingSeller = db.sellers.find(s => s.slug === profile.seller!.slug);
      if (existingSeller) {
        Object.assign(existingSeller, profile.seller);
      } else {
        db.sellers.push({ ...profile.seller, createdAt: now });
      }
      partnerSlug = profile.seller.slug;
    }

    let u = db.users.find(x => x.email === profile.email && x.role === profile.role);
    if (!u) {
      const hp = pass();
      const user: User = {
        id: randomUUID(),
        email: profile.email,
        name: profile.name,
        passHash: hp.passHash,
        salt: hp.salt,
        role: profile.role,
        partnerSlug,
        partnerProfile: profile.role === "partner" && profile.seller ? {
          companyName: profile.seller.name,
          kvk: profile.seller.kvk || "00000000",
          city: profile.seller.city,
          status: "approved",
          termsAcceptedAt: now,
          appliedAt: now,
          decidedAt: now,
        } : undefined,
        createdAt: now,
      };
      db.users.push(user);
      u = user;
    } else {
      u.name = profile.name;
      u.partnerSlug = partnerSlug;
      u.partnerProfile = profile.role === "partner" && profile.seller ? {
        companyName: profile.seller.name,
        kvk: profile.seller.kvk || "00000000",
        city: profile.seller.city,
        status: "approved",
        termsAcceptedAt: u.partnerProfile?.termsAcceptedAt || now,
        appliedAt: u.partnerProfile?.appliedAt || now,
        decidedAt: now,
      } : undefined;
    }

    userId = u.id;
    return {
      ok: true,
      testMode: true,
      profileId: profile.id,
      profileLabel: profile.redirectRoleLabel,
      role: u.role,
      partner: u.role === "partner" && !!u.partnerSlug,
      partnerPending: false,
      name: u.name,
      partnerSlug: u.partnerSlug,
    };
  });

  const { token, expires } = await createSession(userId);
  const res = NextResponse.json(result);
  res.cookies.set(SESSION_COOKIE, token, { httpOnly: true, sameSite: "lax", path: "/", expires });
  return res;
}
