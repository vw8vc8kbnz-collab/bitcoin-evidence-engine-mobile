# v8.8.6 Developer Test Mode

- Developer/Test Mode toegevoegd op `/welkom`, runtime-gated via `.env`.
- Knoppen: Open als Buyer, Open als Partner, Open als Admin.
- Werkt met `TEST_MODE=true` of `DUMMY_LOGIN_ENABLED=true`; uitschakelen met `false` en rebuild/restart.
- Geen bulk/foto-werkbank teruggebracht; single-product partnerflow blijft leidend.

# Changelog

## v8.8.5 — Dummy Login Test Mode

- Testmodus toegevoegd voor dummy-login zonder e-mail/wachtwoord.
- Login-scherm blijft zichtbaar; alleen bij `NEXT_PUBLIC_DUMMY_LOGIN_ENABLED=true` verschijnt een testknop.
- Serverroute `/api/auth/dummy-login` werkt alleen als `DUMMY_LOGIN_ENABLED=true` of `NEXT_PUBLIC_DUMMY_LOGIN_ENABLED=true` staat.
- Dummy koperaccount en dummy partneraccount worden veilig in `data/db.json` aangemaakt/hergebruikt.
- Zakelijke dummy-login maakt/hergebruikt een approved testpartner `dummy-outlet`, zodat de Partner Hub direct testbaar is.
- Default in `.env.example` blijft false; productie kan dit eenvoudig weer uitzetten.
