# v8.8.6 Developer Test Mode

- Developer/Test Mode toegevoegd op `/welkom`, runtime-gated via `.env`.
- Knoppen: Open als Buyer, Open als Partner, Open als Admin.
- Werkt met `TEST_MODE=true` of `DUMMY_LOGIN_ENABLED=true`; uitschakelen met `false` en rebuild/restart.
- Geen bulk/foto-werkbank teruggebracht; single-product partnerflow blijft leidend.

# Outrun IQ v8.8.5 — Dummy Login Test Mode

Deze build is bedoeld om de live/staging website snel te kunnen testen zonder echte accounts te hoeven aanmaken.

## Wat is toegevoegd

- Login UI blijft bestaan.
- Bij testmodus verschijnt in het inlogscherm een knop:
  - `Test zonder invoer → Shop`
  - `Test zonder invoer → Partner Hub`
- De knop maakt een tijdelijke sessie via `/api/auth/dummy-login`.
- De serverroute werkt alleen als de env-flag aan staat.

## Veilig aan/uit zetten

Aan:

```env
DUMMY_LOGIN_ENABLED=true
NEXT_PUBLIC_DUMMY_LOGIN_ENABLED=true
```

Uit:

```env
DUMMY_LOGIN_ENABLED=false
NEXT_PUBLIC_DUMMY_LOGIN_ENABLED=false
```

Daarna opnieuw bouwen en PM2 herstarten, omdat `NEXT_PUBLIC_*` tijdens de frontend-build wordt ingebakken.

## Testaccounts

De route maakt automatisch aan/hergebruikt:

- `dummy-koper@outrun.test` als consument
- `dummy-partner@outrun.test` als goedgekeurde partner
- seller/store `dummy-outlet`

Deze accounts zijn alleen voor test/staging bedoeld.
