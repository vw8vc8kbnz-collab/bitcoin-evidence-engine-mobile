import sqlite3
from contextlib import contextmanager
from .config import DB_PATH

SCHEMA = """
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  plan TEXT NOT NULL DEFAULT 'free',
  credits INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS projects (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'design',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS rooms (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id INTEGER NOT NULL,
  room_type TEXT NOT NULL,
  style TEXT NOT NULL,
  budget_class TEXT NOT NULL,
  user_prompt TEXT,
  original_image_path TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(project_id) REFERENCES projects(id)
);
CREATE TABLE IF NOT EXISTS render_jobs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  room_id INTEGER NOT NULL,
  status TEXT NOT NULL,
  provider TEXT NOT NULL,
  model TEXT NOT NULL,
  cost_estimate REAL NOT NULL DEFAULT 0,
  input_image_path TEXT,
  output_image_path TEXT,
  error_message TEXT,
  idempotency_key TEXT UNIQUE,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  completed_at TEXT,
  FOREIGN KEY(user_id) REFERENCES users(id),
  FOREIGN KEY(room_id) REFERENCES rooms(id)
);
CREATE TABLE IF NOT EXISTS budgets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  room_id INTEGER NOT NULL,
  total_min REAL NOT NULL,
  total_max REAL NOT NULL,
  materials_min REAL NOT NULL,
  materials_max REAL NOT NULL,
  labor_min REAL NOT NULL,
  labor_max REAL NOT NULL,
  confidence TEXT NOT NULL DEFAULT 'indicatief',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(room_id) REFERENCES rooms(id)
);
CREATE TABLE IF NOT EXISTS budget_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  budget_id INTEGER NOT NULL,
  category TEXT NOT NULL,
  title TEXT NOT NULL,
  quantity REAL NOT NULL,
  unit TEXT NOT NULL,
  min_price REAL NOT NULL,
  max_price REAL NOT NULL,
  diy_possible INTEGER NOT NULL DEFAULT 0,
  FOREIGN KEY(budget_id) REFERENCES budgets(id)
);
CREATE TABLE IF NOT EXISTS plan_steps (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  room_id INTEGER NOT NULL,
  order_index INTEGER NOT NULL,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  duration_days INTEGER NOT NULL DEFAULT 1,
  dependency_notes TEXT,
  FOREIGN KEY(room_id) REFERENCES rooms(id)
);
CREATE TABLE IF NOT EXISTS ai_safety_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  event_type TEXT NOT NULL,
  details TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS visual_assets (
  asset_key TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  category TEXT NOT NULL,
  url TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
"""

def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

@contextmanager
def db():
    conn = get_conn()
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()

# v1.0.11: temporarily curated Pinterest CDN defaults for prototype visuals.
# Keep /dev/assets available so these can later be replaced with licensed/owned images.
DEFAULT_VISUAL_ASSETS = [
    ("hero.home", "Home hero foto - warm japandi woonkamer", "hero", "https://i.pinimg.com/736x/73/62/23/7362236282e2e60b2649fa00ee123fb6.jpg"),
    ("room.woonkamer", "Woonkamer tegel - warm modern/japandi", "room", "https://i.pinimg.com/736x/73/62/23/7362236282e2e60b2649fa00ee123fb6.jpg"),
    ("room.keuken", "Keuken tegel - luxe donker hout/marmer", "room", "https://i.pinimg.com/736x/cb/ff/1d/cbff1d22e2f4a5263b3df5114b8dff34.jpg"),
    ("room.badkamer", "Badkamer tegel - hotel chic marmer/goud", "room", "https://i.pinimg.com/736x/f9/2b/c3/f92bc3711824587e92984fe05d197c5c.jpg"),
    ("room.slaapkamer", "Slaapkamer tegel - warm hotel chic", "room", "https://i.pinimg.com/736x/89/fd/dc/89fddc09c57d05a312349e9a06170845.jpg"),
    ("room.eetkamer", "Eetkamer tegel - luxe warm interieur", "room", "https://i.pinimg.com/736x/7a/9b/6c/7a9b6c7b60a4d53b34fce99faec06cf8.jpg"),
    ("room.kantoor", "Home office tegel - dark luxury office", "room", "https://i.pinimg.com/736x/01/45/d4/0145d4c13db4fa2b345e70740efe9fe9.jpg"),
    ("style.japandi", "Japandi stijl - licht hout, rust, naturel", "style", "https://i.pinimg.com/736x/73/62/23/7362236282e2e60b2649fa00ee123fb6.jpg"),
    ("style.modern_warm", "Modern warm stijl - aardetinten, strak", "style", "https://i.pinimg.com/736x/4a/1a/85/4a1a85367e70ba952a1d58b23ef9b190.jpg"),
    ("style.hotel_chic", "Hotel Chic stijl - donker, marmer, goud", "style", "https://i.pinimg.com/736x/f9/2b/c3/f92bc3711824587e92984fe05d197c5c.jpg"),
    ("style.luxe_minimal", "Minimal stijl - rustig en architectonisch", "style", "https://i.pinimg.com/736x/22/ce/31/22ce31680eaccf58b655381987914487.jpg"),
    ("style.scandinavisch", "Scandinavisch stijl - licht, fris, natuurlijk", "style", "https://i.pinimg.com/736x/22/ce/31/22ce31680eaccf58b655381987914487.jpg"),
    ("style.luxury", "Luxury stijl - high-end keuken/marmer", "style", "https://i.pinimg.com/736x/d9/bc/a3/d9bca3639c17c89bff02fed826effd28.jpg"),
    ("style.woonkamer.japandi", "Japandi woonkamer foto", "style_matrix", "https://i.pinimg.com/736x/73/62/23/7362236282e2e60b2649fa00ee123fb6.jpg"),
    ("style.woonkamer.modern_warm", "Modern warm woonkamer foto", "style_matrix", "https://i.pinimg.com/736x/4a/1a/85/4a1a85367e70ba952a1d58b23ef9b190.jpg"),
    ("style.woonkamer.hotel_chic", "Hotel Chic woonkamer foto", "style_matrix", "https://i.pinimg.com/736x/7a/9b/6c/7a9b6c7b60a4d53b34fce99faec06cf8.jpg"),
    ("style.woonkamer.luxe_minimal", "Minimal woonkamer foto", "style_matrix", "https://i.pinimg.com/736x/22/ce/31/22ce31680eaccf58b655381987914487.jpg"),
    ("style.woonkamer.scandinavisch", "Scandinavisch woonkamer foto", "style_matrix", "https://i.pinimg.com/736x/22/ce/31/22ce31680eaccf58b655381987914487.jpg"),
    ("style.woonkamer.luxury", "Luxury woonkamer foto", "style_matrix", "https://i.pinimg.com/736x/d9/bc/a3/d9bca3639c17c89bff02fed826effd28.jpg"),
    ("style.keuken.japandi", "Japandi keuken foto", "style_matrix", "https://i.pinimg.com/736x/cb/ff/1d/cbff1d22e2f4a5263b3df5114b8dff34.jpg"),
    ("style.keuken.modern_warm", "Modern warm keuken foto", "style_matrix", "https://i.pinimg.com/736x/cb/ff/1d/cbff1d22e2f4a5263b3df5114b8dff34.jpg"),
    ("style.keuken.hotel_chic", "Hotel Chic keuken foto", "style_matrix", "https://i.pinimg.com/736x/d9/bc/a3/d9bca3639c17c89bff02fed826effd28.jpg"),
    ("style.keuken.luxe_minimal", "Minimal keuken foto", "style_matrix", "https://i.pinimg.com/736x/22/ce/31/22ce31680eaccf58b655381987914487.jpg"),
    ("style.keuken.scandinavisch", "Scandinavisch keuken foto", "style_matrix", "https://i.pinimg.com/736x/22/ce/31/22ce31680eaccf58b655381987914487.jpg"),
    ("style.keuken.luxury", "Luxury keuken foto", "style_matrix", "https://i.pinimg.com/736x/d9/bc/a3/d9bca3639c17c89bff02fed826effd28.jpg"),
    ("style.badkamer.japandi", "Japandi badkamer foto", "style_matrix", "https://i.pinimg.com/736x/f9/2b/c3/f92bc3711824587e92984fe05d197c5c.jpg"),
    ("style.badkamer.modern_warm", "Modern warm badkamer foto", "style_matrix", "https://i.pinimg.com/736x/f9/2b/c3/f92bc3711824587e92984fe05d197c5c.jpg"),
    ("style.badkamer.hotel_chic", "Hotel Chic badkamer foto", "style_matrix", "https://i.pinimg.com/736x/f9/2b/c3/f92bc3711824587e92984fe05d197c5c.jpg"),
    ("style.badkamer.luxe_minimal", "Minimal badkamer foto", "style_matrix", "https://i.pinimg.com/736x/22/ce/31/22ce31680eaccf58b655381987914487.jpg"),
    ("style.badkamer.scandinavisch", "Scandinavisch badkamer foto", "style_matrix", "https://i.pinimg.com/736x/22/ce/31/22ce31680eaccf58b655381987914487.jpg"),
    ("style.badkamer.luxury", "Luxury badkamer foto", "style_matrix", "https://i.pinimg.com/736x/f9/2b/c3/f92bc3711824587e92984fe05d197c5c.jpg"),
    ("style.slaapkamer.japandi", "Japandi slaapkamer foto", "style_matrix", "https://i.pinimg.com/736x/89/fd/dc/89fddc09c57d05a312349e9a06170845.jpg"),
    ("style.slaapkamer.modern_warm", "Modern warm slaapkamer foto", "style_matrix", "https://i.pinimg.com/736x/89/fd/dc/89fddc09c57d05a312349e9a06170845.jpg"),
    ("style.slaapkamer.hotel_chic", "Hotel Chic slaapkamer foto", "style_matrix", "https://i.pinimg.com/736x/89/fd/dc/89fddc09c57d05a312349e9a06170845.jpg"),
    ("style.slaapkamer.luxe_minimal", "Minimal slaapkamer foto", "style_matrix", "https://i.pinimg.com/736x/22/ce/31/22ce31680eaccf58b655381987914487.jpg"),
    ("style.slaapkamer.scandinavisch", "Scandinavisch slaapkamer foto", "style_matrix", "https://i.pinimg.com/736x/22/ce/31/22ce31680eaccf58b655381987914487.jpg"),
    ("style.slaapkamer.luxury", "Luxury slaapkamer foto", "style_matrix", "https://i.pinimg.com/736x/89/fd/dc/89fddc09c57d05a312349e9a06170845.jpg"),
    ("style.eetkamer.japandi", "Japandi eetkamer foto", "style_matrix", "https://i.pinimg.com/736x/7a/9b/6c/7a9b6c7b60a4d53b34fce99faec06cf8.jpg"),
    ("style.eetkamer.modern_warm", "Modern warm eetkamer foto", "style_matrix", "https://i.pinimg.com/736x/7a/9b/6c/7a9b6c7b60a4d53b34fce99faec06cf8.jpg"),
    ("style.eetkamer.hotel_chic", "Hotel Chic eetkamer foto", "style_matrix", "https://i.pinimg.com/736x/7a/9b/6c/7a9b6c7b60a4d53b34fce99faec06cf8.jpg"),
    ("style.eetkamer.luxe_minimal", "Minimal eetkamer foto", "style_matrix", "https://i.pinimg.com/736x/22/ce/31/22ce31680eaccf58b655381987914487.jpg"),
    ("style.eetkamer.scandinavisch", "Scandinavisch eetkamer foto", "style_matrix", "https://i.pinimg.com/736x/22/ce/31/22ce31680eaccf58b655381987914487.jpg"),
    ("style.eetkamer.luxury", "Luxury eetkamer foto", "style_matrix", "https://i.pinimg.com/736x/d9/bc/a3/d9bca3639c17c89bff02fed826effd28.jpg"),
    ("style.kantoor.japandi", "Japandi home office foto", "style_matrix", "https://i.pinimg.com/736x/01/45/d4/0145d4c13db4fa2b345e70740efe9fe9.jpg"),
    ("style.kantoor.modern_warm", "Modern warm home office foto", "style_matrix", "https://i.pinimg.com/736x/01/45/d4/0145d4c13db4fa2b345e70740efe9fe9.jpg"),
    ("style.kantoor.hotel_chic", "Hotel Chic home office foto", "style_matrix", "https://i.pinimg.com/736x/01/45/d4/0145d4c13db4fa2b345e70740efe9fe9.jpg"),
    ("style.kantoor.luxe_minimal", "Minimal home office foto", "style_matrix", "https://i.pinimg.com/736x/22/ce/31/22ce31680eaccf58b655381987914487.jpg"),
    ("style.kantoor.scandinavisch", "Scandinavisch home office foto", "style_matrix", "https://i.pinimg.com/736x/22/ce/31/22ce31680eaccf58b655381987914487.jpg"),
    ("style.kantoor.luxury", "Luxury home office foto", "style_matrix", "https://i.pinimg.com/736x/01/45/d4/0145d4c13db4fa2b345e70740efe9fe9.jpg"),
]
def init_db():
    with db() as conn:
        conn.executescript(SCHEMA)
        # Lightweight migrations for existing VPS databases.
        cols = [r[1] for r in conn.execute("PRAGMA table_info(rooms)").fetchall()]
        if "user_prompt" not in cols:
            conn.execute("ALTER TABLE rooms ADD COLUMN user_prompt TEXT")
        for key, title, category, url in DEFAULT_VISUAL_ASSETS:
            existing = conn.execute("SELECT url FROM visual_assets WHERE asset_key=?", (key,)).fetchone()
            if not existing:
                conn.execute("INSERT INTO visual_assets(asset_key,title,category,url) VALUES(?,?,?,?)", (key,title,category,url))
            else:
                old_url = (existing["url"] or "").strip()
                # v1.0.10: force bundled local assets when the previous value was an
                # external/empty default, but preserve user-uploaded /media assets.
                if not old_url or old_url.startswith("http://") or old_url.startswith("https://") or old_url.startswith("/static/assets/photos/"):
                    conn.execute("UPDATE visual_assets SET title=?, category=?, url=?, updated_at=CURRENT_TIMESTAMP WHERE asset_key=?", (title, category, url, key))
