# Outrun IQ v8.0.0 — AI Foundation

- Added Outrun AI Brain foundation with AI Router (OpenAI + DeepSeek + Rules fallback).
- Added rules-based Discovery/Ranking/Home Builder engine for scalable home curation.
- Added AI Decision Logger (`db.aiDecisions`) capped for admin/debug use.
- Added Outrun Promote data model and partner campaign creation API/page.
- Added Partner Spotlight / promoted relevance slot on Home.
- Reworked buyer Home into AI-curated premium showcase: slideshow, AI Deal of the Day, Partner Spotlight, AI Picks, New, Trending, Last Chance.
- Updated buyer nav direction: Home | Categorieën | AI Vinder | Alerts | Account.
- Added admin AI Brain config/decision JSON endpoints and Beheer summary.
- Added env options for `AI_ROUTER_MODE`, `OPENAI_API_KEY`, `OPENAI_MODEL`.
- Service worker cache bumped to v8.0.0.

Notes:
- OpenAI is routed first for natural-language/UX tasks.
- DeepSeek is routed first for structured analysis/ranking/promotion tasks.
- Rules Engine remains the safe fast fallback and powers Home by default to avoid slow page loads.
