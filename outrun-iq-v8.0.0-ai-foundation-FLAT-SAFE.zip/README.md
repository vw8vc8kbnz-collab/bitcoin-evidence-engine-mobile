# Outrun IQ v8.0.0 — AI Foundation

Flat-safe VPS package. Keep `.env`, `data/`, `runtime_uploads/`, `public/uploads/`, `node_modules/`, `.next/` excluded during rsync deploy.

## AI env

```env
AI_ROUTER_MODE=hybrid
OPENAI_API_KEY=
OPENAI_MODEL=gpt-4o-mini
DEEPSEEK_API_KEY=
DEEPSEEK_MODEL=deepseek-chat
```

Home uses the local Rules/Ranking engine first for speed and stability. LLM providers are available through the AI Router for Vinder, partner coaching, promotion advice and future agents.
