"use client";
import { useState } from "react";
import type { Listing } from "@/lib/types";

export function PromoteCreate({ listings }:{ listings: Pick<Listing, "id" | "title" | "category">[] }) {
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true); setMsg("");
    const fd = new FormData(e.currentTarget);
    const kind = String(fd.get("kind") || "seller");
    const listingId = String(fd.get("listingId") || "");
    const category = String(fd.get("category") || "");
    const name = String(fd.get("name") || "Outrun Promote");
    const objective = String(fd.get("objective") || "views");
    const budgetDaily = Number(fd.get("budgetDaily") || 5);
    const days = Number(fd.get("days") || 7);
    try {
      const r = await fetch("/api/partner/promote", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ kind, listingId, category, name, objective, budgetDaily, days }),
      });
      const j = await r.json().catch(() => ({}));
      if (!r.ok || j.error) throw new Error(j.error || "Campagne kon niet starten");
      setMsg("Campagne gestart. De AI neemt hem subtiel mee in Home, categorieën en ranking.");
      setTimeout(() => location.reload(), 650);
    } catch (err) { setMsg(err instanceof Error ? err.message : "Fout"); }
    finally { setBusy(false); }
  }
  return (
    <form className="promoteForm" onSubmit={submit}>
      <label>Naam<input name="name" defaultValue="Partner Spotlight" /></label>
      <label>Type<select name="kind" defaultValue="seller"><option value="seller">Bedrijf promoten</option><option value="listing">Product promoten</option><option value="category">Categorie promoten</option></select></label>
      <label>Product<select name="listingId"><option value="">— kies product —</option>{listings.map(l => <option key={l.id} value={l.id}>{l.title}</option>)}</select></label>
      <label>Categorie<select name="category"><option value="">— kies categorie —</option><option value="witgoed">Witgoed</option><option value="meubels">Meubels</option><option value="keukens">Keukens</option><option value="tuin">Tuin</option><option value="overig">Overig</option></select></label>
      <label>Doel<select name="objective" defaultValue="sell_faster"><option value="views">Meer views</option><option value="chats">Meer chats</option><option value="sell_faster">Sneller verkopen</option><option value="brand">Meer winkelbezoeken</option></select></label>
      <div className="promoteSplit"><label>Budget/dag<input name="budgetDaily" type="number" min="3" max="100" defaultValue="7" /></label><label>Dagen<input name="days" type="number" min="1" max="30" defaultValue="7" /></label></div>
      <button className="btn pri" disabled={busy}>{busy ? "Starten..." : "Start Outrun Promote"}</button>
      {msg && <p className="note">{msg}</p>}
    </form>
  );
}
