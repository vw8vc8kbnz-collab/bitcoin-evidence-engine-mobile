"use client";
import { useRef, useState } from "react";
import { Illu, type IlluKind } from "./icons";

export function Gallery({ photos, fallback, defect, title }:{
  photos: string[]; fallback: IlluKind; defect?: string; title: string;
}) {
  const [i, setI] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  function onScroll() {
    const el = ref.current;
    if (el) setI(Math.round(el.scrollLeft / el.clientWidth));
  }
  if (photos.length === 0) {
    return (
      <>
        <span style={{ position: "absolute", inset: 0, display: "grid", placeItems: "center", opacity: .6 }}>
          <span style={{ width: 130 }}><Illu kind={fallback} /></span>
        </span>
        {defect && <span className="gebrek"><i />{defect}</span>}
      </>
    );
  }
  return (
    <>
      <div className="gal" ref={ref} onScroll={onScroll}>
        {photos.map(u => (
          /* eslint-disable-next-line @next/next/no-img-element */
          <img key={u} src={u} alt={title} loading="lazy" />
        ))}
      </div>
      {defect && <span className="gebrek"><i />{defect}</span>}
      <span className="cnt">{Math.min(i + 1, photos.length)} / {photos.length}</span>
    </>
  );
}
