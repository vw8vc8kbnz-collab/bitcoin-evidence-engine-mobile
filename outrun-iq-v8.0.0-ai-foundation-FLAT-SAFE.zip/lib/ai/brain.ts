import { read, mutate } from "@/lib/store";
import type { AiDecision, Listing, PromotionCampaign, Seller, User } from "@/lib/types";
import { aiJson, providerPlan } from "./router";

const DAY = 864e5;
const clamp = (n: number, a = 0, b = 100) => Math.max(a, Math.min(b, n));
const discount = (l: Listing) => l.newPrice > 0 ? clamp((1 - l.price / l.newPrice) * 100) : 0;
const ageDays = (iso: string) => Math.max(0, (Date.now() - +new Date(iso)) / DAY);

function freshness(l: Listing) { return clamp(100 - ageDays(l.createdAt) * 8); }
function stockPressure(l: Listing) { return l.stock <= 1 ? 100 : l.stock <= 3 ? 72 : l.stock <= 8 ? 38 : 15; }
function sellerTrust(l: Listing, sellers: Seller[]) { return sellers.find(s => s.slug === l.sellerSlug)?.trusted ? 94 : 68; }

export function dealQualityScore(l: Listing, sellers: Seller[]) {
  const d = discount(l);
  const score =
    d * 0.28 +
    clamp(l.confidence) * 0.22 +
    clamp(l.conditionScore * 10) * 0.18 +
    sellerTrust(l, sellers) * 0.14 +
    freshness(l) * 0.10 +
    stockPressure(l) * 0.08;
  return Math.round(clamp(score));
}

export function promotionBoost(l: Listing, campaigns: PromotionCampaign[]) {
  const now = Date.now();
  const active = campaigns.filter(c => c.status === "active" && +new Date(c.startsAt) <= now && (!c.endsAt || +new Date(c.endsAt) >= now));
  const hits = active.filter(c =>
    c.sellerSlug === l.sellerSlug && (
      c.kind === "seller" ||
      (c.kind === "listing" && c.listingId === l.id) ||
      (c.kind === "category" && c.category === l.category)
    )
  );
  if (!hits.length) return { boost: 0, campaignIds: [] as string[] };
  // Promotie is een subtiele factor, nooit een garantie op plek 1.
  const budget = hits.reduce((a, c) => a + Math.min(25, Math.max(0, c.budgetDaily)), 0);
  return { boost: Math.min(14, 5 + budget * 0.35), campaignIds: hits.map(h => h.id) };
}

function preferenceScore(l: Listing, prefCats: Set<string>, savedIds: Set<string>) {
  let s = 0;
  if (prefCats.has(l.category)) s += 28;
  if (savedIds.has(l.id)) s += 10;
  if (l.stock <= 1) s += 5;
  return s;
}

function diversify(list: Listing[], maxPerSeller = 2) {
  const seen = new Map<string, number>();
  const out: Listing[] = [];
  for (const l of list) {
    const n = seen.get(l.sellerSlug) ?? 0;
    if (n >= maxPerSeller) continue;
    out.push(l); seen.set(l.sellerSlug, n + 1);
  }
  return out.length >= Math.min(4, list.length) ? out : list;
}

export async function logAiDecision(input: Omit<AiDecision, "id" | "at">) {
  return mutate(db => {
    db.aiDecisions ??= [];
    db.aiDecisions.push({ id: Math.random().toString(36).slice(2, 10), at: new Date().toISOString(), ...input });
    if (db.aiDecisions.length > 3000) db.aiDecisions.splice(0, db.aiDecisions.length - 3000);
  });
}

export async function buildHomeBrain(user?: User | null) {
  const db = await read();
  const listings = db.listings.filter(l => l.status === "active" && l.stock > 0);
  const sellers = db.sellers;
  const campaigns = db.promotionCampaigns ?? [];
  const saved = user ? db.saved.filter(s => s.userId === user.id) : [];
  const orders = user ? db.orders.filter(o => o.buyerId === user.id) : [];
  const savedIds = new Set(saved.map(s => s.listingId));
  const prefCats = new Set<string>();
  for (const s of saved) { const l = listings.find(x => x.id === s.listingId); if (l) prefCats.add(l.category); }
  for (const o of orders) { const l = listings.find(x => x.id === o.listingId); if (l) prefCats.add(l.category); }

  const ranked = listings.map(l => {
    const dq = dealQualityScore(l, sellers);
    const promo = promotionBoost(l, campaigns);
    const personal = preferenceScore(l, prefCats, savedIds);
    const score = dq * 0.48 + personal * 0.24 + freshness(l) * 0.10 + stockPressure(l) * 0.07 + promo.boost + Math.random() * 1.5;
    return { l, score, dq, personal, promo };
  }).sort((a, b) => b.score - a.score);

  const aiPicks = diversify(ranked.map(x => x.l), 2).slice(0, 8);
  const hero = aiPicks.slice(0, 5);
  const newListings = [...listings].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 10);
  const lastChance = ranked.filter(x => x.l.stock <= 2).map(x => x.l).slice(0, 8);
  const trending = [...ranked].sort((a, b) => (b.l.views + b.dq) - (a.l.views + a.dq)).map(x => x.l).slice(0, 8);
  const dealOfDay = [...ranked].sort((a, b) => b.dq - a.dq)[0]?.l;
  const promoted = ranked.filter(x => x.promo.boost > 0).slice(0, 6);
  const partnerSpotlight = promoted[0]?.l ?? null;

  void logAiDecision({
    agent: "home_builder",
    provider: "hybrid",
    userId: user?.id,
    role: user?.role,
    context: "home-render",
    subjectType: "home",
    confidence: listings.length ? 86 : 40,
    reason: `Home samengesteld uit ${listings.length} live producten met rules + promotieboost.`,
    features: { liveListings: listings.length, aiPicks: aiPicks.length, promoted: promoted.length, prefCats: prefCats.size },
  }).catch(() => undefined);

  return { hero, aiPicks, newListings, lastChance, trending, dealOfDay, partnerSpotlight, promoted: promoted.map(x => x.l), prefCats };
}

export function aiProviderMatrix() {
  return ["vinder", "copy", "partner_coach", "deal_quality", "ranking", "home_builder", "promotion", "inventory"].map(task => ({
    task,
    plan: providerPlan(task as Parameters<typeof providerPlan>[0]),
  }));
}

export async function promotionAdvice(input: { listing: Listing; seller: Seller | undefined }) {
  const system = `Je bent Outrun Promotion AI. Geef uitsluitend JSON: {"promote":true,"budgetDaily":0,"confidence":0,"reason":"","expectedViews":0,"objective":""}. Wees conservatief. Promotie mag nooit irritant zijn; alleen zinvol als product extra zichtbaarheid nodig heeft.`;
  const res = await aiJson<{ promote: boolean; budgetDaily: number; confidence: number; reason: string; expectedViews: number; objective: string }>({
    task: "promotion",
    system,
    user: { titel: input.listing.title, categorie: input.listing.category, prijs: input.listing.price, nieuwprijs: input.listing.newPrice, views: input.listing.views, voorraad: input.listing.stock, conditie: input.listing.conditionScore, partner: input.seller?.name },
    temperature: 0.1,
    timeoutMs: 12_000,
  });
  if (res.ok && res.data) return { ...res.data, provider: res.provider };
  const dq = dealQualityScore(input.listing, input.seller ? [input.seller] : []);
  return { promote: input.listing.views < 20 && input.listing.stock > 0, budgetDaily: dq > 78 ? 5 : 8, confidence: 68, reason: "Rules-advies: weinig views en voldoende voorraad.", expectedViews: 180, objective: "Meer relevante bezoekers", provider: "rules" };
}
