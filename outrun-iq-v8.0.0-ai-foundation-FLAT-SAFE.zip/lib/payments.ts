/** Betaal-abstractie (M4-voorbereiding). Zelfde patroon als AI/mail/push:
 *  zonder STRIPE_SECRET_KEY draait alles in testmodus (orders direct "paid",
 *  geen echt geld). Mét key wordt hier de Stripe-flow ingehangen:
 *
 *  M4-plan (vastgelegd, zie mega-overdracht DEEL 13):
 *  1. createCheckout(order) → stripe.checkout.sessions.create met
 *     payment_intent_data.transfer_group = order.id; redirect naar session.url.
 *  2. Webhook (app/api/stripe/webhook) verwerkt checkout.session.completed →
 *     order.status "paid" + order.paymentRef = payment_intent.
 *  3. Escrow-vrijgave (sweep/bevestiging) → stripe.transfers.create naar het
 *     Connect-account van de partner (Express onboarding; IBAN blijft bij Stripe).
 *  4. Retour vóór uitbetaling → stripe.refunds.create; ná uitbetaling →
 *     verrekening met volgende transfer (art. 13 Partnervoorwaarden).
 */
export function paymentsMode(): "test" | "stripe" {
  return process.env.STRIPE_SECRET_KEY ? "stripe" : "test";
}
