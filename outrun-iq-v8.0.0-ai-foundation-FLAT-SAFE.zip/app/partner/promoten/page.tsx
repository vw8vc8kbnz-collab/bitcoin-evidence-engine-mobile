import Link from "next/link";
import { read } from "@/lib/store";
import { getUser } from "@/lib/auth";
import { eur } from "@/lib/types";
import { Mark } from "@/components/icons";
import { PromoteCreate } from "@/components/PromoteCreate";
import { promotionAdvice } from "@/lib/ai/brain";

export const dynamic = "force-dynamic";

export default async function Promoten() {
  const db = await read();
  const user = await getUser();
  const seller = db.sellers.find(s => s.slug === user?.partnerSlug);
  const listings = db.listings.filter(l => l.sellerSlug === user?.partnerSlug && l.status === "active").sort((a,b)=>b.createdAt.localeCompare(a.createdAt));
  const campaigns = (db.promotionCampaigns ?? []).filter(c => c.sellerSlug === user?.partnerSlug).sort((a,b)=>b.createdAt.localeCompare(a.createdAt));
  const advice = listings[0] ? await promotionAdvice({ listing: listings[0], seller }) : null;
  const active = campaigns.filter(c => c.status === "active");
  return <main className="page partnerScreen promoteScreen">
    <header className="hd"><Link href="/partner" className="lock" style={{ color: "#fff" }}><Mark glow />Outrun <b>Promote</b></Link><span className="sp" /><span className="mini" style={{ color: "#8B96A0" }}>BETA</span></header>
    <section className="partnerHero promoteHero"><div className="big"><label>ACTIEF BUDGET</label><b>{eur(active.reduce((a,c)=>a+c.budgetDaily,0))}/dag</b></div><p>Promotie telt mee als subtiele AI-boost. Relevantie, dealkwaliteit en vertrouwen blijven leidend.</p></section>
    <div className="dkchips partnerMetricGrid"><span className="dkc"><label>ACTIEF</label><b>{active.length}</b></span><span className="dkc"><label>IMPRESSIES</label><b>{campaigns.reduce((a,c)=>a+c.impressions,0)}</b></span><span className="dkc"><label>KLIKS</label><b>{campaigns.reduce((a,c)=>a+c.clicks,0)}</b></span></div>
    {advice && <article className="promoteAdvice"><span className="eyebrow">PROMOTION AI</span><b>{advice.promote ? "Promoten is zinvol" : "Nog niet promoten"}</b><p>{advice.reason}</p><small>Advies: {eur(advice.budgetDaily)}/dag · verwacht +{advice.expectedViews} views · confidence {advice.confidence}% · {advice.provider}</small></article>}
    <div className="dsec"><h2>Nieuwe campagne</h2><span>AI-GESTUURD</span></div>
    <PromoteCreate listings={listings.map(l => ({ id: l.id, title: l.title, category: l.category }))} />
    <div className="dsec"><h2>Campagnes</h2><span>{campaigns.length}</span></div>
    <div className="inventoryList">
      {campaigns.length === 0 && <p className="note">Nog geen campagnes. Start klein met €5–€10 per dag.</p>}
      {campaigns.map(c => <article key={c.id} className="partnerItem promoteCampaign"><div className="partnerItemMain"><span className="promoGlyph">🚀</span><span className="partnerItemText"><b>{c.name}</b><span>{c.kind.toUpperCase()} · {c.objective.replaceAll("_", " ")} · {c.status.toUpperCase()}</span></span><span className="partnerAmount">{eur(c.budgetDaily)}/d<i>{c.impressions} views · {c.clicks} kliks</i></span></div></article>)}
    </div>
  </main>;
}
