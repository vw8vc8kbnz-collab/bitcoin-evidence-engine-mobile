import { NextResponse, type NextRequest } from "next/server";
import { getUser, isApprovedPartner } from "@/lib/auth";
import { createPromotionCampaign, getPromotionCampaigns, setPromotionCampaignStatus } from "@/lib/data";
import type { Listing, PromotionCampaign } from "@/lib/types";
export const runtime = "nodejs";

const cats = new Set(["witgoed", "meubels", "keukens", "tuin", "overig"]);
const objectives = new Set(["views", "chats", "sell_faster", "brand"]);

export async function GET() {
  const u = await getUser();
  if (!isApprovedPartner(u) || !u?.partnerSlug) return NextResponse.json({ error: "Alleen partners" }, { status: 403 });
  return NextResponse.json({ campaigns: await getPromotionCampaigns(u.partnerSlug) });
}

export async function POST(req: NextRequest) {
  const u = await getUser();
  if (!isApprovedPartner(u) || !u?.partnerSlug) return NextResponse.json({ error: "Alleen partners" }, { status: 403 });
  const b = await req.json().catch(() => null);
  const action = String(b?.action ?? "create");
  if (action === "status") {
    const status = String(b?.status ?? "paused") as PromotionCampaign["status"];
    if (!["active", "paused", "ended"].includes(status)) return NextResponse.json({ error: "Ongeldige status" }, { status: 400 });
    return NextResponse.json(await setPromotionCampaignStatus(u.partnerSlug, String(b?.id ?? ""), status));
  }
  const kind = String(b?.kind ?? "seller") as PromotionCampaign["kind"];
  if (!["listing", "seller", "category"].includes(kind)) return NextResponse.json({ error: "Ongeldig campagnetype" }, { status: 400 });
  const objective = String(b?.objective ?? "views") as PromotionCampaign["objective"];
  if (!objectives.has(objective)) return NextResponse.json({ error: "Ongeldig doel" }, { status: 400 });
  const category = cats.has(String(b?.category ?? "")) ? String(b.category) as Listing["category"] : undefined;
  const result = await createPromotionCampaign({
    sellerSlug: u.partnerSlug,
    kind,
    listingId: b?.listingId ? String(b.listingId) : undefined,
    category,
    name: String(b?.name ?? "Outrun Promote").trim() || "Outrun Promote",
    objective,
    budgetDaily: Number(b?.budgetDaily) || 5,
    days: Number(b?.days) || 7,
  });
  const status = "error" in result ? 400 : 200;
  return NextResponse.json(result, { status });
}
