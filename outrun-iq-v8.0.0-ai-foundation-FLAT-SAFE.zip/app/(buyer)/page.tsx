import Link from "next/link";
import { eur, unreadCount } from "@/lib/data";
import { getUser } from "@/lib/auth";
import { Img } from "@/components/Img";
import { Mark, Check, Score } from "@/components/icons";
import { EvidenceStrip } from "@/components/EvidenceStrip";
import { Empty } from "@/components/Empty";
import { HeroSlider } from "@/components/HeroSlider";
import { buildHomeBrain, dealQualityScore } from "@/lib/ai/brain";
import { read } from "@/lib/store";
import type { Listing } from "@/lib/types";

export const dynamic = "force-dynamic";
const disc = (p: number, n: number) => Math.round((1 - p / n) * 100);

function Rail({ title, href, items, tag }:{ title: string; href?: string; items: Listing[]; tag?: string }) {
  if (!items.length) return null;
  return <>
    <div className="sec aiSec"><h2>{title}</h2>{href && <Link href={href}>BEKIJK →</Link>}</div>
    <div className="rail dealRail aiRail">
      {items.map(l => (
        <Link key={l.id} href={`/listing/${l.id}`} className="rc dealCard aiDealCard">
          <Img src={l.photos[0]} fallback={l.fallback}><Score v={l.confidence} /></Img>
          {tag && <span className="aiMiniTag">{tag}</span>}
          <span className="tx">
            <span className="t">{l.title}</span>
            <span className="p"><b>{eur(l.price)}{l.perUnit && "/st"}</b><span>−{disc(l.price, l.newPrice)}%</span></span>
          </span>
        </Link>
      ))}
    </div>
  </>;
}

export default async function Home() {
  const user = await getUser();
  const unread = user ? await unreadCount(user.id) : 0;
  const db = await read();
  const home = await buildHomeBrain(user);
  const feat = home.hero[0] ?? home.aiPicks[0] ?? home.newListings[0];
  const seller = feat ? db.sellers.find(s => s.slug === feat.sellerSlug) : undefined;
  const dq = feat ? dealQualityScore(feat, db.sellers) : 0;

  return (
    <main className="page homeAIPage">
      <header className="hd homeAIHeader">
        <Link href="/" className="lock"><Mark />OUTRUN <b>IQ</b></Link>
        <span className="sp" />
        <Link href="/meldingen" className="icbtn" aria-label="Alerts">
          <svg viewBox="0 0 24 24"><path d="M6 10a6 6 0 1112 0c0 4 1.5 5.5 1.5 5.5h-15S6 14 6 10z" /><path d="M10.5 19a1.8 1.8 0 003 0" /></svg>
          {unread > 0 && <span className="bub">{unread > 9 ? "9+" : unread}</span>}
        </Link>
      </header>

      {!feat && <Empty title="Nog geen live deals" text="Outrun IQ staat klaar. Zodra partners hun voorraad publiceren, bouwt de AI hier je persoonlijke etalage." cta="Word partner" href="/word-partner" />}

      {feat && <>
        <section className="aiWelcome">
          <span className="eyebrow">OUTRUN AI BRAIN</span>
          <h1>{user ? `Voor jou geselecteerd` : `De beste deals van vandaag`}</h1>
          <p>Outrun rangschikt outletvoorraad op relevantie, prijsbewijs, partnerbetrouwbaarheid en beschikbaarheid.</p>
        </section>

        <div className="sec aiSec heroLabel"><h2>Persoonlijke slideshow</h2><span>{home.prefCats.size ? "OP BASIS VAN JE GEDRAG" : "AI-CURATED"}</span></div>
        <HeroSlider items={home.hero} personalized={home.prefCats.size > 0} />

        <section className="aiDealOfDay">
          <Link href={`/listing/${feat.id}`} className="aiDealHero">
            <span className="copy">
              <span className="eyebrow">AI DEAL VAN DE DAG</span>
              <b>{feat.title}</b>
              <small>{seller?.name ?? feat.sellerSlug} · Deal Score {dq}/100 · −{disc(feat.price, feat.newPrice)}%</small>
            </span>
            <span className="price">{eur(feat.price)}</span>
          </Link>
        </section>

        {home.partnerSpotlight && (
          <section className="promoteSpotlight">
            <div className="spotHead"><span>✨ Partner Spotlight</span><small>Outrun Promote · relevant gekozen</small></div>
            <Link href={`/listing/${home.partnerSpotlight.id}`} className="spotCard">
              <Img src={home.partnerSpotlight.photos[0]} fallback={home.partnerSpotlight.fallback} />
              <span><b>{db.sellers.find(s => s.slug === home.partnerSpotlight!.sellerSlug)?.name ?? home.partnerSpotlight.sellerSlug}</b><small>{home.partnerSpotlight.title}</small></span>
              <i>{eur(home.partnerSpotlight.price)}</i>
            </Link>
          </section>
        )}

        <Rail title="AI Picks" href="/vinder" items={home.aiPicks.slice(0, 8)} tag="AI" />
        <Rail title="Nieuw toegevoegd" href="/zoeken" items={home.newListings.slice(0, 8)} />
        <Rail title="Trending" href="/zoeken" items={home.trending.slice(0, 8)} />
        <Rail title="Laatste stuks" href="/zoeken?q=laatste" items={home.lastChance.slice(0, 8)} tag="LAATSTE" />

        <section className="aiHomeGrid">
          <Link href="/zoeken" className="aiHomeTile"><b>Categorieën</b><span>Bekijk alle deals per markt, merk en prijsklasse.</span></Link>
          <Link href="/vinder" className="aiHomeTile accent"><b>AI Vinder</b><span>Beschrijf wat je zoekt. De AI zoekt voor je.</span></Link>
          <Link href="/meldingen" className="aiHomeTile"><b>Alerts</b><span>Prijsdrops, nieuwe matches en orderupdates.</span></Link>
        </section>

        <section className="homeTrust trustStrip aiTrust" aria-label="Outrun IQ koperbescherming">
          <div><b>AI-score</b><span>ranking op dealkwaliteit, niet alleen nieuwheid</span></div>
          <div><b>Subtiele promotie</b><span>betaalde zichtbaarheid telt mee, maar relevantie wint</span></div>
          <div><b>Kopersbescherming</b><span>betaling beschermd tot levering is afgerond</span></div>
        </section>
      </>}
    </main>
  );
}
