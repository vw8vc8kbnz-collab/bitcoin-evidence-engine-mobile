import Link from "next/link";
import { searchListings, eur } from "@/lib/data";
import { Img } from "@/components/Img";
import { Check, Score } from "@/components/icons";
import { Empty } from "@/components/Empty";

export const dynamic = "force-dynamic";

const SORTS = [
  { v: "nieuw", label: "Nieuwste" },
  { v: "prijs", label: "Prijs ↑" },
  { v: "korting", label: "Korting ↓" },
] as const;

export default async function Zoeken({ searchParams }:{
  searchParams: Promise<{ q?: string; sort?: string }>;
}) {
  const { q = "", sort = "nieuw" } = await searchParams;
  const res = await searchListings(q);
  if (sort === "prijs") res.sort((a, b) => a.price - b.price);
  if (sort === "korting") res.sort((a, b) => (1 - b.price / b.newPrice) - (1 - a.price / a.newPrice));
  return (
    <main className="page">
      <header className="hd">
        <Link href="/" className="back" aria-label="Terug">
          <svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7" /></svg>
        </Link>
        <form action="/zoeken" className="srchbar">
          <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="6.5" /><path d="M20 20l-4.2-4.2" /></svg>
          <input name="q" defaultValue={q} placeholder="Zoek producten, merken of stores" autoComplete="off" />
        </form>
      </header>
      <div className="fbar">
        {SORTS.map(s2 => (
          <Link key={s2.v} href={`/zoeken?q=${encodeURIComponent(q)}&sort=${s2.v}`} className={`f${sort === s2.v ? " on" : ""}`}>{s2.label}</Link>
        ))}
      </div>
      <div className="count">{res.length} {res.length === 1 ? "RESULTAAT" : "RESULTATEN"}{q ? ` · "${q.toUpperCase()}"` : ""}</div>
      {res.length === 0 && (
        <Empty title="Niets gevonden" text={q ? `Geen listings voor "${q}". Probeer een ander woord of kijk later terug.` : "Er staan nog geen listings live."} cta="Terug naar home" href="/" />
      )}
      <div className="rows">
        {res.map(l => (
          <Link key={l.id} href={`/listing/${l.id}`} className="rowc">
            <Img src={l.photos[0]} fallback={l.fallback}><Score v={l.confidence} /></Img>
            <span className="tx">
              <span className="t">{l.title}</span>
              <span className="c">{l.condition || `Conditie ${l.conditionScore}/10`}</span>
              <span className="s"><Check />{l.pickupCity}</span>
              <span className="bot">
                <b>{eur(l.price)}{l.perUnit && "/st"}</b>
                <span className="d">−{Math.round((1 - l.price / l.newPrice) * 100)}%</span>
                <span className="km">{l.stock > 1 ? `${l.stock} ST` : ""}</span>
              </span>
            </span>
          </Link>
        ))}
      </div>
    </main>
  );
}
