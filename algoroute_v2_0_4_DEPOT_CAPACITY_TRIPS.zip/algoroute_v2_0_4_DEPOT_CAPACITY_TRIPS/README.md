# AlgoRoute v2.0.4 — Depot + Capacity Trips

Deze build voegt het vertrekadres/depot toe, verbetert de Live Kaart routebalk en maakt capaciteit harde optimizer-logica.

## Belangrijk
- AlgoRoute maakt nooit automatisch voertuigen aan.
- Geen route mag boven max kg, volume, vloeroppervlak, EP/RC mix of max ritduur komen.
- Als een route te zwaar/te lang wordt, maakt AlgoRoute extra ritten met hetzelfde voertuig waar nodig.
- Depot/vertrekadres staat nu in Instellingen en wordt gebruikt als route start/eindpunt.
- Live Kaart onderbalk is vervangen door een horizontale route-switcher + geselecteerde route detaildock.

