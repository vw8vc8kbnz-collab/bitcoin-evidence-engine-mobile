# v8.1.1 — Outrun Promote multi-product

- Partner kan nu meerdere producten aanvinken in één campagne.
- Productcampagnes bewaren `listingIds` en AI maakt campagnecollecties op basis van meerdere producten.
- Promote matching/ranking gebruikt alle geselecteerde producten.
- Campagne-invoer onderin verbeterd met selectiebar en fairness-uitleg.
- Home/promote kaarten linken bij multi-product campagnes naar de partnercollectie i.p.v. één product.
