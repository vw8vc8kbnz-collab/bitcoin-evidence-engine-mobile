# Outrun IQ v8.1.1

Flat-root deploy ZIP. Gebouwd bovenop v8.1.0. Focus: Outrun Promote AI met multi-product campagnes en betere campagne-invoer.
