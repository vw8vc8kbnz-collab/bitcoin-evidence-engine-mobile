# AlgoRoute v0.3.1 ROOT FIXED

Deze versie fixt de fout waarbij `/` een 403 gaf terwijl `/api/health` wel werkte.

Belangrijkste fix:
- Docker build context staat nu op project-root.
- FastAPI serveert `apps/web/static/index.html` direct op `/`.
- `/api/health` blijft werken.
- Poort blijft `8787`.

Open na installatie:

```text
http://51.195.102.180:8787/
```
