const navItems = document.querySelectorAll('.sidebar a');
const pages = document.querySelectorAll('.page');
navItems.forEach(item => item.addEventListener('click', () => {
  navItems.forEach(i => i.classList.remove('active'));
  item.classList.add('active');
  pages.forEach(p => p.classList.remove('active-page'));
  const target = document.getElementById(item.dataset.page);
  if (target) target.classList.add('active-page');
}));

async function ping(){
  try { const r = await fetch('/api/health'); console.log(await r.json()); } catch(e) { console.warn(e); }
}
ping();
