# AlgoRoute v0.3.1 ROOT FIXED - Termius update

Upload eerst `algoroute_v0_3_1_ROOT_FIXED.zip` naar GitHub root.

```bash
cd /home/ubuntu

rm -rf algoroute_latest
rm -f algoroute_v0_3_1_ROOT_FIXED.zip

wget -O /home/ubuntu/algoroute_v0_3_1_ROOT_FIXED.zip \
"https://raw.githubusercontent.com/vw8vc8kbnz-collab/bitcoin-evidence-engine-mobile/main/algoroute_v0_3_1_ROOT_FIXED.zip"

mkdir -p /home/ubuntu/algoroute_latest
unzip -o /home/ubuntu/algoroute_v0_3_1_ROOT_FIXED.zip -d /home/ubuntu/algoroute_latest

cd /home/ubuntu/algoroute_latest/algoroute_v0_3_1_root_fixed 2>/dev/null || cd /home/ubuntu/algoroute_latest

chmod +x scripts/install.sh
sudo ./scripts/install.sh

sudo ufw allow 8787/tcp || true

sudo docker compose down || true
sudo docker compose up -d --build

sudo docker compose ps
curl -I http://localhost:8787/
curl http://localhost:8787/api/health
```

Open:

```text
http://51.195.102.180:8787/
```
