from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pathlib import Path
from datetime import datetime

app = FastAPI(title="AlgoRoute API", version="0.3.1-root-fixed")
BASE = Path(__file__).parent
STATIC = BASE / "static"
app.mount("/static", StaticFiles(directory=str(STATIC)), name="static")

@app.get("/api/health")
def health():
    return {"ok": True, "app": "AlgoRoute", "version": "v0.3.1-root-fixed", "time": datetime.utcnow().isoformat() + "Z"}

@app.get("/api/fleet/live")
def fleet_live():
    return {
        "vehicles": [
            {"id":"V-01","driver":"Jan de Vries","status":"active","speed":60,"stops_done":7,"stops_total":12,"eta":"10:45","lat":52.09,"lng":5.12},
            {"id":"V-02","driver":"Pieter Smit","status":"active","speed":48,"stops_done":4,"stops_total":10,"eta":"11:20","lat":51.92,"lng":4.48},
            {"id":"V-03","driver":"Marco Jansen","status":"maintenance","speed":0,"stops_done":0,"stops_total":0,"eta":"-","lat":51.44,"lng":5.47}
        ]
    }

@app.get("/{path:path}")
def index(path: str):
    return FileResponse(str(STATIC / "index.html"))
