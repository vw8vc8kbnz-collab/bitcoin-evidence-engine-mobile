# AlgoRoute C++ Optimization Core placeholder

Future modules:
- VRPTW route solver
- Route + load coupling
- Customer Promise Guard
- Live recalculation
- EV Intelligence
