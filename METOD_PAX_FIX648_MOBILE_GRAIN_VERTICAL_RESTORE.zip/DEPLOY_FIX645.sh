#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="/opt/adzaagt/metod-pax"
ENV_DIR="/etc/adzaagt/metod-pax"
ENV_FILE="$ENV_DIR/metod-pax.env"
SERVICE_FILE="/etc/systemd/system/metod-pax.service"
NGINX_SITE="/etc/nginx/sites-available/metod-pax-8790"

if [[ "${EUID}" -ne 0 ]]; then
  echo "Voer dit script met sudo uit." >&2
  exit 1
fi

mkdir -p "$ENV_DIR" "$APP_DIR/app/backups" "$APP_DIR/app/decor_media"
touch "$ENV_FILE" "$APP_DIR/app/backups/.keep" "$APP_DIR/app/decor_media/.keep"

# FIX645 is a test/acceptance release. Existing HTTP/dev-mode infrastructure is
# intentionally kept unchanged; the separate production-hardening release follows
# after functional acceptance.
sed -i \
  '/^METOD_PORT=/d;/^PRODUCTION_HARDENING=/d;/^ADMIN_HASH_ONLY=/d;/^APP_ENV=/d;/^ADMIN_CREDENTIALS_FILE=/d;/^ADMIN_STAGING_OPEN=/d;/^PUBLIC_JOB_MAX_CONCURRENT=/d;/^PUBLIC_JOB_MAX_CONCURRENT_PER_IP=/d;/^ALLOWED_ADMIN_ORIGINS=/d;/^ALLOWED_ORIGINS=/d;/^PUBLIC_JSON_MAX_BYTES=/d;/^PUBLIC_JOB_TOTAL_QTY_LIMIT=/d;/^PUBLIC_JOB_MAX_AREA_LB=/d;/^JOB_OUTPUT_MAX_BYTES=/d' \
  "$ENV_FILE"
cat >> "$ENV_FILE" <<'ENVEOF'
METOD_PORT=8792
PRODUCTION_HARDENING=0
ADMIN_HASH_ONLY=0
APP_ENV=development
ADMIN_CREDENTIALS_FILE=/etc/adzaagt/metod-pax/admin_credentials.live.json
ADMIN_STAGING_OPEN=0
PUBLIC_JOB_MAX_CONCURRENT=1
PUBLIC_JOB_MAX_CONCURRENT_PER_IP=1
PUBLIC_JSON_MAX_BYTES=134217728
PUBLIC_JOB_TOTAL_QTY_LIMIT=250
PUBLIC_JOB_MAX_AREA_LB=250
JOB_OUTPUT_MAX_BYTES=536870912
ALLOWED_ADMIN_ORIGINS=http://51.195.102.180:8790
ALLOWED_ORIGINS=http://51.195.102.180:8790
ENVEOF

cat > "$SERVICE_FILE" <<'SVCEOF'
[Unit]
Description=METOD PAX Tool
After=network.target

[Service]
Type=simple
WorkingDirectory=/opt/adzaagt/metod-pax/app
EnvironmentFile=/etc/adzaagt/metod-pax/metod-pax.env
ExecStart=/usr/bin/python3 /opt/adzaagt/metod-pax/app/server_py.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
SVCEOF
rm -f /etc/systemd/system/metod-pax.service.d/10-http-test.conf

cat > "$NGINX_SITE" <<'NGINXEOF'
server {
    listen 8790;
    listen [::]:8790;
    server_name 51.195.102.180 _;
    client_max_body_size 160m;

    location / {
        proxy_pass http://127.0.0.1:8792;
        proxy_http_version 1.1;
        proxy_set_header Host $http_host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header X-Forwarded-Host $http_host;
        proxy_set_header X-Forwarded-Port $server_port;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_connect_timeout 30s;
        proxy_send_timeout 1800s;
        proxy_read_timeout 1800s;
        proxy_buffering off;
    }
}
NGINXEOF
ln -sfn "$NGINX_SITE" /etc/nginx/sites-enabled/metod-pax-8790

# Safe, idempotent data migration. Internal articles/prices are preserved; only
# opaque public IDs and public catalog metadata are added where missing.
python3 "$APP_DIR/tools/migrate_decor_library.py" \
  --path "$APP_DIR/app/material_library.json" \
  --backup-dir "$APP_DIR/app/backups"

python3 -m py_compile "$APP_DIR/app/server_py.py" "$APP_DIR/tools/migrate_decor_library.py"
grep -q "FIX644_STEP2_KEYBOARD_STABILITY_ALL_FIELDS" "$APP_DIR/app/toolA.html"
grep -q "FIX645_STEP2_KEYBOARD_FOOTER_HIDE" "$APP_DIR/app/toolA.html"
grep -q "fix644ExtensionGrid" "$APP_DIR/app/toolA.html"
grep -q "window.visualViewport" "$APP_DIR/app/toolA.html"
grep -q "decor_library.js?v=643" "$APP_DIR/app/toolA.html"
grep -q "const MATERIAL_CATALOG = (window.MATERIAL_CATALOG = \[\]);" "$APP_DIR/app/toolA.html"
grep -q "decorSheetAddMore" "$APP_DIR/app/decor_library.js"
grep -q "decorDesktopGoPanels" "$APP_DIR/app/decor_library.js"

systemctl daemon-reload
systemctl enable metod-pax.service >/dev/null
systemctl restart metod-pax.service
nginx -t
systemctl reload nginx
sleep 3

curl -fsSI http://127.0.0.1:8792/toolA.html >/dev/null
curl -fsSI http://127.0.0.1:8792/admin/ >/dev/null
curl -fsS http://127.0.0.1:8792/decor_library.js >/dev/null
curl -fsS http://127.0.0.1:8792/api/materials/library | python3 -c '
import json,re,sys
obj=json.load(sys.stdin)
assert obj.get("ok") is True
records=obj.get("records") or []
assert records
allowed={"publicMaterialId","publicName","brand","decorType","colorGroup","thicknessMm","sheetSizeMm","hasGrain","grainDefaultOn","active","published","isPopular","isNew","imageAvailable","imageThumbUrl","imagePreviewUrl"}
for record in records:
    assert set(record).issubset(allowed)
    assert re.fullmatch(r"decor_[a-f0-9]{20}", str(record.get("publicMaterialId") or ""))
forbidden={"articleNumber","articleNo","materialCode","purchasePrice","purchasePricePerSheet","supplier","leverancier"}
assert not any(forbidden.intersection(record) for record in records)
print(f"Publieke Decor Library OK: {len(records)} decors")
'
curl -fsSI http://51.195.102.180:8790/toolA.html?v=645 >/dev/null

echo "FIX645 actief. Open: http://51.195.102.180:8790/toolA.html?v=645"
echo "Admin: http://51.195.102.180:8790/admin/?v=645"
echo 'Controleer buildmarkers: FIX644 keyboard stability + FIX645 keyboard footer hide'
