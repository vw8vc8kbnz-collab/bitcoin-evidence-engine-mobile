# METOD/PAX Tool A — Technische overdracht FIX648

## Basis
FIX648 is bewust gebaseerd op **FIX645**, omdat dat de laatste bewezen versie vóór de mobiele Doorlopende-nerf-experimenten FIX646 en FIX647 is. Hierdoor blijven de Decor Library, publieke materiaal-ID's, desktop Stap 1, mobiele Stap 1, Stap 2 drawer, keyboardstabiliteit en footer-hide behouden.

## Wijziging
Alleen de mobiele presentatie van `#grainOverlay` is aangepast.

De bestaande verticale DOM-volgorde is behouden:

1. `#grainEligible` — beschikbare panelen;
2. `#grainGroups` — nerf-sets samenstellen;
3. `#grainPreview` — visuele controle;
4. `#grainCancelBtn` en `#grainApplyBtn`.

Er is een mobiele merkregel toegevoegd binnen `.grainHero`:

- `.grainMobileBrandRow`;
- `.grainMobileBrandLogo`;
- `.grainMobileStepPill`.

De echte asset `assets/adzaagt_logo.png` wordt gebruikt. De merkregel is alleen zichtbaar tot en met 700 px. Desktop blijft functioneel en visueel op de bestaande opzet.

## Verwijderde/afwezige experimentele lagen
FIX648 bevat niet:

- `toolA_grain_mobile_flow.css`;
- `toolA_grain_mobile_flow.js`;
- `toolA_grain_mobile_workspace.css`;
- `toolA_grain_mobile_workspace.js`.

Daarmee is er geen tweede mobiele state- of navigatielaag bovenop de bestaande nerflogica.

## Autoritatieve logica
De bestaande functies in `toolA.html` en `toolA_grain_validation.js` blijven leidend voor:

- materiaalfilter;
- breedtefilter;
- gelijke-breedtevalidatie;
- nerfgroepen;
- paneelvolgorde;
- verlengingen;
- drag-and-drop;
- preview;
- annuleren en toepassen.

## Buildmarker

```javascript
window.__TOOLA_GRAIN_MOBILE_BUILD = 'FIX648_VERTICAL_GRAIN_RESTORE';
```

## Deploy
Gebruik `DEPLOY_FIX648.sh`. De installer moet bedrijfsdata uitsluiten van `rsync`, waaronder jobs, requests, pricing, Material Library, decorafbeeldingen en DXF-bibliotheek.

## Acceptatie
Op een echte iPhone in Safari controleren:

1. Stap 3 openen;
2. bevestigen dat alles in één verticale pagina staat;
3. panelen naar meerdere nerf-sets slepen;
4. groepen en volgorde aanpassen;
5. preview bekijken;
6. Toepassen;
7. bevestigen dat de rest van de wizard ongewijzigd blijft.
