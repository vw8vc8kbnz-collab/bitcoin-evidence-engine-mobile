# METOD/PAX Tool A — technische overdracht FIX642

## Scope
FIX642 is een gerichte UX-correctie op FIX641. Er is geen herbouw van de onderliggende materiaal-, pricing-, optimizer- of productiearchitectuur uitgevoerd.

## Mobiele Stap 1
Tijdens `material`/`materials` en viewport `<=700px` is uitsluitend de nieuwe Decor Library zichtbaar. `restoreMobileMaterialLibraryShell()` plaatst een herstelbare inline `display:none !important` op `.right`. Een MutationObserver bewaakt oudere code die deze inline stijl opnieuw probeert te wijzigen. Bij verlaten van Stap 1 wordt uitsluitend deze FIX642-override verwijderd.

De bottom sheet heeft twee routes:
- `#decorSheetAddMore`: sluit de sheet, behoudt selectie en scrollpositie en brengt de gebruiker terug naar de library.
- `#decorSheetGoPanels`: sluit de sheet en navigeert naar `panels`.

De sticky knop `Verder` opent alleen de sheet; hij omzeilt de materiaalinstellingen niet.

## Desktop Stap 1
`#decorSelectedSummary` wordt als premium materiaalkaart gerenderd. De kaart gebruikt de bestaande actieve material state en toont alleen publieke metadata. Functies:
- afbeelding;
- publiek merk en publieke decornaam;
- Nerf aan / Nerf uit via de bestaande per-batch grain-logica;
- alle geselecteerde `materialBatches`;
- actief materiaal wisselen via `window.__setActiveMaterial`;
- verwijderen via `window.removeMaterialBatch`;
- terug naar library of door naar Stap 2.

De oude `#matChosen`, `#matClearBtn`, `#grainByMaterialWrap` en helpertekst zijn uitsluitend in desktop Stap 1 visueel vervangen; de onderliggende code blijft aanwezig voor compatibiliteit.

## Compatibiliteitscorrectie
Bij het opnieuw selecteren van een al bestaande materiaalbatch wordt de bestaande batch uitgebreid met de nieuwe materiaalreferentie in plaats van vervangen. Daardoor blijft onder andere `grainEnabled` behouden.

## Niet gewijzigd
- server/API-contracten;
- publicMaterialId-mapping;
- artikelnummerafscherming;
- Admin Decor Library;
- afbeeldingenopslag;
- pricing;
- optimizer;
- Stap 2 t/m 5;
- deployment hardeningstatus.

## Buildmarker
```js
window.__TOOLA_DECOR_LIBRARY_BUILD === 'FIX642_DECOR_FLOW_CLEAN_DESKTOP'
```
