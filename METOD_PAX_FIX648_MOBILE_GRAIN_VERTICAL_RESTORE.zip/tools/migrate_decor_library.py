#!/usr/bin/env python3
"""Idempotent migration for the FIX640 public Decor Library metadata.

The internal material article number stays untouched. Each record receives a random,
opaque publicMaterialId used by Tool A and public image URLs.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import secrets
import shutil
import tempfile
from datetime import datetime
from pathlib import Path

KNOWN_BRANDS = (
    'EGGER', 'PFLEIDERER', 'UNILIN', 'DECORLEGNO', 'SHINNOKI', 'CLEAF',
    'FINSA', 'KRONOSPAN', 'ARPA', 'FENIX', 'DECOLEGNO', 'NUXE', 'TOPFIX',
)
PUBLIC_ID_RE = re.compile(r'decor_[a-f0-9]{20}')


def new_id(used: set[str]) -> str:
    while True:
        value = 'decor_' + secrets.token_hex(10)
        if value not in used:
            used.add(value)
            return value


def public_name(record: dict) -> str:
    article = str(record.get('articleNo') or record.get('articleNumber') or record.get('materialCode') or '').strip()
    raw = str(
        record.get('publicName') or record.get('displayName') or
        record.get('productName') or record.get('decorName') or 'Decor'
    ).strip()
    if article:
        raw = raw.replace(article, '').strip(' -/|') or 'Decor'
    return raw[:180]


def infer_brand(record: dict) -> str:
    existing = str(record.get('brand') or '').strip()
    if existing:
        return existing[:80]
    hay = ' '.join(str(record.get(key) or '') for key in ('productName', 'categoryName', 'shortDescription')).upper()
    for brand in KNOWN_BRANDS:
        if brand in hay:
            return brand.title() if brand not in ('EGGER', 'FENIX', 'ARPA') else brand
    return 'Overig'


def infer_type(record: dict) -> str:
    existing = str(record.get('decorType') or '').strip()
    if existing:
        return existing[:60]
    hay = ' '.join(str(record.get(key) or '') for key in ('productName', 'categoryName', 'shortDescription')).lower()
    if re.search(r'hout|eiken|noten|fineer|bamboe|multiplex', hay):
        return 'Hout'
    if re.search(r'steen|beton|marmer|leisteen|graniet|travertin', hay):
        return 'Steen'
    if re.search(r'metaal|aluminium|staal|koper|brons', hay):
        return 'Metaal'
    if re.search(r'uni|effen|solid|wit|zwart|grijs|kleur|mat', hay):
        return 'Uni'
    return 'Overig'


def migrate(path: Path, backup_dir: Path) -> dict:
    if not path.exists():
        raise ValueError(f'Bestand niet gevonden: {path}')
    original = path.read_bytes()
    raw = json.loads(original.decode('utf-8'))
    if isinstance(raw, list):
        raw = {'source': 'migrated', 'records': raw}
    if not isinstance(raw, dict) or not isinstance(raw.get('records'), list):
        raise ValueError('Ongeldige material library')

    used: set[str] = set()
    changes = 0
    for record in raw['records']:
        if not isinstance(record, dict):
            continue
        public_id = str(record.get('publicMaterialId') or '').strip().lower()
        if not PUBLIC_ID_RE.fullmatch(public_id) or public_id in used:
            record['publicMaterialId'] = new_id(used)
            changes += 1
        else:
            used.add(public_id)
            if record.get('publicMaterialId') != public_id:
                record['publicMaterialId'] = public_id
                changes += 1

        defaults = {
            'publicName': public_name(record),
            'brand': infer_brand(record),
            'decorType': infer_type(record),
            'colorGroup': str(record.get('colorGroup') or 'Overig').strip() or 'Overig',
            'published': bool(record.get('active', True)) if record.get('published') is None else bool(record.get('published')),
            'isPopular': bool(record.get('isPopular', False)),
            'isNew': bool(record.get('isNew', False)),
            'hasGrain': True if record.get('hasGrain') is None else bool(record.get('hasGrain')),
            'grainDefaultOn': True if record.get('grainDefaultOn') is None else bool(record.get('grainDefaultOn')),
            'archived': bool(record.get('archived', False)),
        }
        for key, value in defaults.items():
            if key not in record:
                record[key] = value
                changes += 1

    meta = {
        'decorLibrarySchemaVersion': 1,
        'recordCountOriginal': len(raw['records']),
        'recordCountFiltered': len(raw['records']),
    }
    for key, value in meta.items():
        if raw.get(key) != value:
            raw[key] = value
            changes += 1

    if changes == 0:
        return {'ok': True, 'records': len(raw['records']), 'changes': 0, 'backup': None, 'written': False}

    backup_dir.mkdir(parents=True, exist_ok=True)
    backup = backup_dir / (path.name + '.before_decor_migration_' + datetime.now().strftime('%Y%m%d_%H%M%S') + '.bak')
    shutil.copy2(path, backup)

    fd, tmp_name = tempfile.mkstemp(prefix=path.name + '.', suffix='.tmp', dir=str(path.parent))
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as handle:
            json.dump(raw, handle, ensure_ascii=False, indent=2)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp_name, path)
        try:
            directory_fd = os.open(str(path.parent), os.O_RDONLY)
            try:
                os.fsync(directory_fd)
            finally:
                os.close(directory_fd)
        except OSError:
            pass
    finally:
        if os.path.exists(tmp_name):
            os.unlink(tmp_name)

    return {'ok': True, 'records': len(raw['records']), 'changes': changes, 'backup': str(backup), 'written': True}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--path', required=True)
    parser.add_argument('--backup-dir', default='')
    args = parser.parse_args()
    path = Path(args.path).resolve()
    backup_dir = Path(args.backup_dir).resolve() if args.backup_dir else (path.parent / 'backups')
    try:
        result = migrate(path, backup_dir)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        raise SystemExit(str(exc)) from exc
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
