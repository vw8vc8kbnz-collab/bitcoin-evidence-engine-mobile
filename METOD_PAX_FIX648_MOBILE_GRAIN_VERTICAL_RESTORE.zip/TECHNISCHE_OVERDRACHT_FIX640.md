# FIX640 — Technische overdracht Decor Library

## Autoritatieve data

`app/material_library.json` blijft de interne autoritatieve materiaalbibliotheek. Een record bevat zowel interne productievelden als publieke catalogusvelden. Het interne artikelnummer blijft leidend voor pricing en productie.

De browser ontvangt nooit het volledige interne record. `/api/materials/library` levert uitsluitend het minimale publieke contract met een willekeurige `publicMaterialId`.

## Selectieflow

1. Tool A haalt de gepubliceerde publieke catalogus op.
2. De klant selecteert een `publicMaterialId`.
3. Tool A gebruikt de opaque ID in state, panelen-CSV en jobpayload.
4. De backend vertaalt alle relevante materiaalvelden server-side naar het interne artikelnummer.
5. Preflight, pricing, optimizer en productie draaien met de bestaande interne code.
6. Publieke status- en quotegegevens worden vóór verzending opnieuw geschoond.

Tool A gebruikt bestaande compatibility-propertynamen zoals `articleNumber` intern in de browser, maar de waarde daarvan is uitsluitend de opaque publieke ID. Het echte artikelnummer wordt nooit naar Tool A gestuurd.

## Stap 1

Links wordt alleen tijdens de materiaalstap de Decor Library getoond. Vanaf Stap 2 wordt hetzelfde linkerdeel weer door de bestaande paneelviewer gebruikt.

Desktop:
- library links;
- bestaande zoek-, selectie- en nerfbediening rechts.

Mobiel:
- library bovenaan;
- na kaartselectie wordt naar de bestaande materiaalinstellingen gescrold;
- historische mobiele CSS die de Step-1 viewer verbergt, wordt uitsluitend tijdens de materiaalstap gericht overschreven en daarna hersteld.

## Afbeeldingen

Persistente map:

```text
app/decor_media/<publicMaterialId>/thumb.webp
app/decor_media/<publicMaterialId>/preview.webp
```

Verplichte afmetingen:

```text
thumb.webp   720×540
preview.webp 1600×1200
```

De Admin-browser converteert de bronafbeelding via canvas naar WebP. Daardoor worden originele bestandsnaam en metadata niet overgenomen. De server controleert type, raw-size en afmetingen en publiceert pas na een geslaagde atomische write.

Tijdens updates moet `app/decor_media/` altijd worden behouden. In een latere data-rootmigratie is deze map persistente bedrijfsdata.

## Admin

Admin kan:

- een los nieuw decor als concept aanmaken;
- publieke metadata en interne productievelden afzonderlijk beheren;
- een live publieke kaartvoorvertoning bekijken;
- publiceren of als concept bewaren;
- markeren als populair of nieuw;
- afbeelding uploaden, vervangen of verwijderen;
- archiveren zonder historische data te verwijderen.

Een afbeelding kan pas worden gekoppeld nadat het decor is opgeslagen en een stabiele publieke ID heeft. Een nieuw decor is standaard niet gepubliceerd.

## Migratie

```bash
python3 tools/migrate_decor_library.py \
  --path app/material_library.json \
  --backup-dir app/backups
```

De migratie is idempotent. Bestaande geldige IDs blijven behouden. Ongeldige of dubbele IDs worden vervangen door nieuwe willekeurige IDs. Interne artikelnummers en prijsvelden veranderen niet.

## Updatebehoud

Bij iedere volgende release behouden:

- `app/material_library.json`
- `app/decor_media/`
- `app/backups/`
- alle overige eerder vastgelegde runtime- en bedrijfsdatapaden.

Wanneer `material_library.json` op een lege installatie nog niet bestaat, mag de release-seed éénmalig worden geplaatst en daarna uitsluitend via migratie/Admin worden aangepast.

## Beveiligingsgrens

CSS-verbergen is geen beveiligingsmaatregel. De kern is server-side dataminimalisatie:

- interne artikelnummers ontbreken uit Tool A HTML en de publieke API;
- interne prijs-/leveranciersvelden ontbreken uit publieke responses;
- productie-input en exports blijven Admin-only;
- publieke afbeeldingen gebruiken alleen de opaque decor-ID;
- gedeelde drafts zijn uitgeschakeld om oude interne materiaaldata niet terug naar de browser te laten lekken.

## Bekende vervolgstappen

- Automatisch afgeleide publieke namen, merken, types en kleuren in Admin nalopen.
- Echte decorafbeeldingen uploaden.
- Eén fictieve volledige order op de VPS uitvoeren en intern controleren.
- Eventuele bulkimport voor afbeeldingen later als afzonderlijke feature bouwen.
- De reeds vastgelegde productiehardening uitvoeren na functionele acceptatie.
