# FIX641 — Technische overdracht mobiele Decor Library

## Scope

FIX641 bouwt uitsluitend voort op FIX640. De publieke Decor Library API, opaque `publicMaterialId`, Adminbeheer, afbeeldingsopslag en server-side vertaling naar interne artikelnummers blijven ongewijzigd.

## Mobiele Stap 1

Bij een viewport van maximaal 700 px:

1. Het linker applicatiepaneel toont de Decor Library over de beschikbare breedte.
2. De bestaande rechterkolom wordt alleen tijdens Stap 1 verborgen.
3. Een mobiele zoekbalk filtert uitsluitend op publieke velden.
4. Decorcards staan in twee kolommen.
5. Een kaartselectie roept de bestaande `window.setMaterial(material)` aan.
6. Na selectie opent de mobiele bottom sheet.
7. De bottom sheet toont en wijzigt de bestaande per-materiaal `grainEnabled`-waarde.
8. Bevestigen roept de bestaande wizardnavigatie naar `panels` aan.
9. Vanaf Stap 2 zijn de bestaande paneelviewer en FIX638-drawer weer volledig leidend.

Er is geen tweede materiaalstate en geen tweede nerflogica geïntroduceerd.

## Nerfkoppeling

De bottom sheet zoekt de bestaande `.grainChoice[data-gkey]`-bediening van de actieve materiaalbatch en activeert de bestaande knop voor `on` of `off`. Hierdoor blijven bestaande side effects behouden, waaronder het verwijderen van oude nerfgroepen wanneer nerf wordt uitgezet.

Alleen wanneer die bestaande DOM-bediening onverwacht niet beschikbaar is, wordt defensief dezelfde `grainEnabled`-waarde op de actieve batch en legacy state bijgewerkt.

## Mobiele bediening

- Kaartselectie opent de bottom sheet.
- Backdrop, sluitknop, Escape of omlaag slepen sluit de sheet.
- Na sluiten blijft een sticky selectiekaart zichtbaar.
- De knop `Verder` op de sticky kaart opent de sheet opnieuw.
- `Bevestig materiaal` sluit de sheet en gaat door naar Stap 2.
- De body-scrollpositie wordt tijdens de open sheet bevroren en daarna hersteld.
- `env(safe-area-inset-bottom)` wordt gebruikt voor iPhone-safe-area.

## Privacygrens

De mobiele UI gebruikt uitsluitend de reeds geschoonde publieke catalogusvelden. Er zijn geen interne artikelnummers, leverancierscodes, inkoopprijzen of interne bestandsnamen toegevoegd aan:

- kaarten;
- filters;
- mobiele zoekresultaten;
- sticky selectiekaart;
- bottom sheet;
- DOM-data-attributen.

`data-decor-id` bevat uitsluitend de opaque publieke decor-ID.

## Library en afbeeldingen

FIX641 verandert de huidige catalogusinhoud niet. De volledige actuele library en afbeeldingen worden later via een afzonderlijke gecontroleerde bulkimport ingeladen. De bestaande Admin-workflow voor losse nieuwe decors blijft beschikbaar.

## Verplichte vervolgtest

Na installatie op de VPS minimaal testen op een echte iPhone in Safari:

- verticaal scrollen door de library;
- horizontaal scrollen door filterchips;
- zoeken met geopend toetsenbord;
- kaart selecteren;
- bottom sheet sluiten via alle methodes;
- nerf aan en uit;
- portrait en landscape;
- Safari-adresbalk in- en uitklappen;
- bevestigen naar Stap 2;
- terugkeren naar Stap 1 met behoud van selectie.
