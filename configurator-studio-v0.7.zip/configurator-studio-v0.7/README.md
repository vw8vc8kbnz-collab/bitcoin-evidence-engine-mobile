# Configurator Studio v0.7

v0.7 is een echte rebuild van de UX in de gekozen premium light SaaS-stijl.

## Nieuw in v0.7

- Nieuwe premium light UI, gebaseerd op de gekozen mockup-richting.
- Desktop en mobile responsive in één echte app-build.
- Eén centrale AI Product Studio composer.
- Prompt, foto’s en 3D-model import zitten in dezelfde workflow.
- AI clarification card met meerdere gerichte vragen:
  - producttype
  - configureerbare onderdelen
  - materialen/afwerkingen
  - kwaliteit: photorealistic / balanced / performance
  - doel: e-commerce / lead gen / intern
- Refined generation brief.
- Detected configurable parts.
- Tripo/Rodin provider-routing mock.
- Geen zichtbare demo-tafel als hoofdflow.
- Self-contained HTML zodat deploy betrouwbaar blijft.

## Belangrijk

Dit is nog een frontend-prototype/mock. Echte ChatGPT API, Tripo/Rodin generatie, storage en Shopify moeten server-side worden gekoppeld in een volgende build.
