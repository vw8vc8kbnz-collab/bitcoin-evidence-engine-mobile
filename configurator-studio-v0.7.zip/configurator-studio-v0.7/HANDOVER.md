# HANDOVER — Configurator Studio v0.7

## Status

v0.7 vervangt de eerdere ruwe AI Product Studio door een premium light SaaS UX, gebaseerd op de mockup die de gebruiker koos.

## Kernbeslissingen

- Look: warm off-white, witte cards, champagne accents, charcoal text, subtiele borders/shadows.
- UX: één composer voor prompt + foto’s + 3D-model.
- De AI start niet direct met genereren; de gebruiker beantwoordt eerst meerdere AI-clarification vragen.
- De app toont daarna een refined generation brief en detected configurable parts.
- Tripo/Rodin zijn nog mock/provider-routing, geen echte API.
- Alles is self-contained in `index.html` om server/cache/MIME-problemen te vermijden.

## Volgende technische stappen

1. Next.js/Supabase backend of minimal API-server.
2. ChatGPT API koppelen voor echte clarification + refined prompt JSON.
3. Tripo/Rodin adapterlaag.
4. Async job status en polling.
5. Asset storage voor foto’s/GLB/gegenereerde modellen.
6. Echte review-editor voor mesh/part/material zones.
7. Shopify app block en checkout bridge.
