const app=document.getElementById('app');
let state={view:'dashboard',map:null,selected:'veh-01',mapInstances:{},planning:{orders:[],summary:null,selected:null,date:'all',status:'all'},mapInstances:{},import:{rows:[],headers:[],mapping:{},selectedCol:null,search:'',templates:JSON.parse(localStorage.getItem('algoroute_import_templates')||'[]'),activeCategory:'Aanbevolen',validation:null}};

function logo(){return `<svg viewBox="0 0 92 72" fill="none" aria-hidden="true"><circle cx="17" cy="52" r="5" fill="#101418"/><circle cx="36" cy="20" r="5" fill="#101418"/><circle cx="58" cy="43" r="5" fill="#9fb71f"/><circle cx="76" cy="16" r="7" fill="#b7cc2f"/><path d="M17 52 36 20 58 43 76 16" stroke="#101418" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/><path d="M58 43 76 16" stroke="#b7cc2f" stroke-width="5" stroke-linecap="round"/><path d="M68 16h8v8" stroke="#fff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`}
async function load(){const r=await fetch('/api/map/state');state.map=await r.json();try{const q=await fetch('/api/planning/queue');const pq=await q.json();state.planning.orders=pq.orders||[];state.planning.summary=pq.summary||null;state.planning.selected=state.planning.orders[0]?.id||null;}catch(e){console.warn('planning queue unavailable',e)}render()}
const navGroups=[
  ['OPERATIONS',[['dashboard','⌂','Dashboard'],['planning','▦','Planning'],['routes','⌘','Routes'],['load','◫','Load Optimization'],['map','⌾','Live Kaart']]],
  ['RESOURCES',[['vehicles','▣','Wagenpark'],['drivers','♙','Chauffeurs'],['orders','▤','Orders']]],
  ['MANAGEMENT',[['tracking','◎','Klanttracking'],['reports','▥','Rapportages'],['settings','⚙','Instellingen']]]
];
function shell(content){return `<div class="app"><aside class="rail"><div class="mark">${logo()}<div class="brandWord">Algo<span>Route</span></div></div><nav class="nav grouped">${navGroups.map(([group,items])=>`<div class="navGroup"><div class="navLabel">${group}</div>${items.map(([id,ic,label])=>`<button class="${state.view===id?'active':''}" onclick="go('${id}')"><span class="ic">${ic}</span>${label}</button>`).join('')}</div>`).join('')}</nav><div class="railFooter"><div class="themeSwitch">☾ <span>Premium cockpit</span></div><div class="userMini"><div class="avatar">S</div><div><b>Stijn</b><div class="muted">Admin</div></div></div></div></aside><main class="main"><header class="topbar"><div class="hamb">☰</div><div class="search">⌕&nbsp;&nbsp; Zoek order, route, bus, mapping of klant… <span style="margin-left:auto;color:#9ca3af">⌘K</span></div><div class="topActions"><span class="sync">● Live sync actief</span><span>🔔</span><span>?</span><div class="circle">S</div></div></header>${content}</main></div>`}

function kpis(){return `<section class="kpis"><div class="card kpi"><div class="kpiIcon i-lime">⌘</div><div><label>Actieve routes</label><div class="value">${state.map.routes.length}</div><small>+2 sinds 08:00</small></div></div><div class="card kpi"><div class="kpiIcon i-green">↗</div><div><label>On-time performance</label><div class="value">94%</div><small>Customer Promise Guard</small></div></div><div class="card kpi"><div class="kpiIcon i-purple">⌖</div><div><label>Stops voltooid</label><div class="value">35/70</div><small style="color:#6b7280">50% dagprogressie</small></div></div><div class="card kpi"><div class="kpiIcon i-orange">□</div><div><label>Load utilization</label><div class="value">82%</div><small>Pallet/rolcontainer check</small></div></div></section>`}
function mapBlock(full=false){const id=full?'map-full':'map-preview';setTimeout(()=>initRealMap(id,full),50);return `<section class="card mapCard"><div class="mapHead"><div class="mapTitle"><b>${full?'Live Kaart Nederland':'Operations Map'}</b><span>${full?'Echte kaartdata · routes · traffic segments':'Dashboard preview met lichte NL kaartdata'}</span></div><div class="mapTools"><button class="mapTool">Traffic</button><button class="mapTool active">Routes</button><button class="mapTool">Stops</button></div></div><div id="${id}" class="realMap"><div class="mapFallback"><div class="mapFallbackInner"><b>Kaart laden…</b><p>MapLibre start de lichte NL basemap. Als externe tiles niet laden, blijft deze fallback zichtbaar.</p></div></div></div></section>`}
function initRealMap(id,full=false){
  if(!state.map || state.mapInstances[id] || !document.getElementById(id)) return;
  if(!window.maplibregl){return;}
  const center=state.map.center || [5.2913,52.1326];
  const map=new maplibregl.Map({
    container:id, center:center, zoom: full ? 7.2 : 6.85, pitch:0, bearing:0, attributionControl:true,
    style:{version:8,sources:{carto:{type:'raster',tiles:['https://a.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png','https://b.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png','https://c.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png','https://d.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png'],tileSize:256,attribution:'© OpenStreetMap © CARTO'}},layers:[{id:'carto',type:'raster',source:'carto',paint:{'raster-opacity':.96,'raster-saturation':-.08,'raster-contrast':-.04,'raster-brightness-min':.06,'raster-brightness-max':.98}}]}
  });
  state.mapInstances[id]=map;
  map.on('load',()=>{map.resize();addAlgoLayers(map);fitToRoutes(map);});
}
function addAlgoLayers(map){
  const routeFeatures=state.map.routes.map(r=>({type:'Feature',properties:{id:r.id,name:r.name,color:r.color,risk:r.risk,vehicle_id:r.vehicle_id},geometry:{type:'LineString',coordinates:r.coordinates}}));
  map.addSource('algoroute-routes',{type:'geojson',data:{type:'FeatureCollection',features:routeFeatures}});
  map.addLayer({id:'route-underlay',type:'line',source:'algoroute-routes',paint:{'line-color':'#ffffff','line-width':8,'line-opacity':.85}});
  map.addLayer({id:'route-main',type:'line',source:'algoroute-routes',paint:{'line-color':['get','color'],'line-width':4.4,'line-opacity':.96}});
  const trafficFeatures=(state.map.traffic_segments||[]).map(t=>({type:'Feature',properties:{id:t.id,status:t.status,label:t.label,color:t.status==='red'?'#ef4444':'#f97316'},geometry:{type:'LineString',coordinates:t.coordinates}}));
  map.addSource('algoroute-traffic',{type:'geojson',data:{type:'FeatureCollection',features:trafficFeatures}});
  map.addLayer({id:'traffic-underlay',type:'line',source:'algoroute-traffic',paint:{'line-color':'#ffffff','line-width':10,'line-opacity':.9}});
  map.addLayer({id:'traffic-main',type:'line',source:'algoroute-traffic',paint:{'line-color':['get','color'],'line-width':5.4,'line-opacity':.98}});
  addCityLabels(map);
  map.on('click','route-main',(e)=>{const vid=e.features?.[0]?.properties?.vehicle_id;if(vid) selectVehicle(vid)});
  map.on('mouseenter','route-main',()=>map.getCanvas().style.cursor='pointer');
  map.on('mouseleave','route-main',()=>map.getCanvas().style.cursor='');
  state.map.routes.forEach(route=>{
    const mid=route.coordinates[Math.floor(route.coordinates.length/2)];
    const el=document.createElement('div');el.className='routeLabel';el.innerHTML=`${route.name}<br><span>${route.km} km · ${route.risk}</span>`;
    new maplibregl.Marker({element:el,anchor:'bottom'}).setLngLat(mid).addTo(map);
    route.stops.forEach(stop=>{const s=document.createElement('div');s.className=`stopMarker ${stop.status}`;s.textContent=stop.seq;s.title=`${stop.city} · ETA ${stop.eta}`;new maplibregl.Marker({element:s}).setLngLat([stop.lng,stop.lat]).addTo(map);});
  });
  state.map.vehicles.forEach(v=>{const el=document.createElement('div');el.className=`truckMarker ${v.status==='delay'?'delay':v.status==='critical'?'critical':''}`;el.title=`${v.name} · ${v.driver}`;el.onclick=()=>selectVehicle(v.id);new maplibregl.Marker({element:el}).setLngLat([v.lng,v.lat]).addTo(map);});
  map.addControl(new maplibregl.NavigationControl({showCompass:false}),'bottom-right');
}
function addCityLabels(map){[['Amsterdam',4.9041,52.3676],['Rotterdam',4.4777,51.9244],['Den Haag',4.3007,52.0705],['Utrecht',5.1214,52.0907],['Eindhoven',5.4697,51.4416],['Tilburg',5.0913,51.5555],['Groningen',6.5665,53.2194],['Leeuwarden',5.7999,53.2012],['Zwolle',6.083,52.5168],['Arnhem',5.8987,51.9851],['Nijmegen',5.8528,51.8426],['Breda',4.7683,51.5719],['Alkmaar',4.7486,52.6324],['Hoorn',5.059,52.642],['Den Bosch',5.3037,51.6905]].forEach(([name,lng,lat])=>{const el=document.createElement('div');el.className='cityLabel';el.textContent=name;new maplibregl.Marker({element:el,anchor:'center'}).setLngLat([lng,lat]).addTo(map);});}
function fitToRoutes(map){const coords=state.map.routes.flatMap(r=>r.coordinates).concat(state.map.vehicles.map(v=>[v.lng,v.lat]));const bounds=coords.reduce((b,c)=>b.extend(c),new maplibregl.LngLatBounds(coords[0],coords[0]));map.fitBounds(bounds,{padding:{top:90,bottom:55,left:60,right:60},duration:0,maxZoom:8.3});}
function badge(status){return status==='done'?'green':status==='current'?'orange':status==='planned'?'red':status==='critical'?'red':status==='delay'?'orange':'green'}
function selectedPanel(){let veh=state.map.vehicles.find(v=>v.id===state.selected)||state.map.vehicles[0];let route=state.map.routes.find(r=>r.vehicle_id===veh.id)||state.map.routes[0];return `<section class="card panel"><h3>${veh.name} — ${veh.driver} <span class="badge green" style="float:right">actief</span></h3><div class="muted">${veh.plate} · ${veh.status} · ${veh.speed} km/u</div><div class="progress"><i style="width:${veh.progress}%"></i></div><div class="routeItem active"><div><b>Volgende stop</b><div class="muted">${veh.eta} · ${veh.stops_done}/${veh.stops_total} stops</div></div><span class="badge green">${veh.load}</span></div><h3>Stopvolgorde</h3>${route.stops.map(s=>`<div class="stopRow"><div><b>${s.seq}. ${s.city}</b><div class="muted">ETA ${s.eta}</div></div><span class="badge ${badge(s.status)}">${s.status}</span></div>`).join('')}</section>`}
function routePanel(){return `<section class="card panel"><h3>Routes vandaag <span class="muted" style="float:right">Bekijk alle</span></h3>${state.map.routes.map(r=>`<div class="routeItem ${state.map.vehicles.find(v=>v.id===state.selected)?.id===r.vehicle_id?'active':''}" onclick="selectVehicle('${r.vehicle_id}')"><div><b>${r.name}</b><div class="muted">${r.km} km · ${r.duration}</div></div><span class="badge ${r.risk==='high'?'red':r.risk==='medium'?'orange':'green'}">${r.risk}</span></div>`).join('')}</section>`}
function eventPanel(){return `<section class="card panel"><h3>Live alerts <span class="muted" style="float:right">Bekijk alle</span></h3>${state.map.events.map(e=>`<div class="event"><div><b>${e.title}</b><div class="muted">${e.route}</div></div><span class="badge ${e.severity==='critical'?'red':e.severity==='medium'?'orange':'green'}">${e.type}</span></div>`).join('')}</section>`}
function dashboard(){return shell(`${kpis()}<section class="contentGrid">${mapBlock()}<div class="side">${selectedPanel()}${eventPanel()}</div></section><section class="bottom">${routePanel()}<section class="card panel"><h3>Planning queue <span class="muted" style="float:right">Bekijk alle</span></h3><div class="routeItem"><b>18 orders klaar</b><span class="badge">CSV import</span></div><div class="routeItem"><b>4 capaciteits waarschuwingen</b><span class="badge red">load</span></div><div class="routeItem"><b>2 routes wachten op optimalisatie</b><span class="badge purple">plan</span></div></section><section class="card panel"><h3>Fleet status <span class="muted" style="float:right">Bekijk alle</span></h3><div class="routeItem"><b>3 beschikbaar</b><span class="badge green">ready</span></div><div class="routeItem"><b>1 EV kritisch</b><span class="badge orange">range</span></div><div class="routeItem"><b>2 onderhoud komende 7 dagen</b><span class="badge purple">maint</span></div></section></section>`)}
function liveMap(){return shell(`<section class="contentGrid" style="grid-template-columns:1fr 390px">${mapBlock(true)}<div class="side">${selectedPanel()}${routePanel()}${eventPanel()}</div></section>`)}
function vehicles(){return shell(`${kpis()}<section class="card panel moduleHero"><h3>Wagenpark</h3><p class="muted">Voertuigen, beschikbaarheid en pallet/rolcontainer capaciteit. Deze module krijgt hierna echte CRUD-formulieren en RDW-kentekenlookup.</p><div class="tableLine"><b>Voertuig</b><b>Status</b><b>Capaciteit</b><b>Planning impact</b></div>${state.map.vehicles.map(v=>`<div class="tableLine"><div><b>${v.name}</b><div class="muted">${v.plate} · ${v.driver}</div></div><span class="badge ${badge(v.status)}">${v.status}</span><div>${v.load}</div><div class="muted">Beschikbaar voor solver</div></div>`).join('')}</section>`)}

const FIELD_CATALOG = [
  ['Negeren','negeren','Kolom niet importeren','System','none','—'],
  ['Ordernummer','order_number','Uniek ordernummer of transportreferentie','Order','text','Verplicht'],
  ['Extern order ID','external_order_id','ID uit webshop/ERP/marktplaats','Order','text','Optioneel'],
  ['Referentie klant','customer_reference','Referentie van klant','Order','text','Optioneel'],
  ['Factuurnummer','invoice_number','Koppeling met finance','Order','text','Optioneel'],
  ['Orderdatum','order_date','Datum waarop order is aangemaakt','Order','date','Optioneel'],
  ['Leverdatum','delivery_date','Geplande leverdatum','Order','date','Aanbevolen'],
  ['Orderstatus','order_status','Status uit bronsysteem','Order','text','Optioneel'],
  ['Ordertype','order_type','Levering, retour, spoed, service','Order','enum','Optioneel'],
  ['Batch/dagroute','batch_name','Dagbatch of planningsgroep','Order','text','Optioneel'],
  ['Interne opmerking','internal_note','Niet zichtbaar voor chauffeur/klant','Order','text','Optioneel'],
  ['Opmerking chauffeur','driver_note','Instructie voor chauffeur','Order','text','Aanbevolen'],

  ['Klantnaam','customer_name','Naam ontvanger of particulier','Klant','text','Verplicht'],
  ['Bedrijfsnaam','company_name','Bedrijfsnaam ontvanger','Klant','text','Optioneel'],
  ['Contactpersoon','contact_person','Contactpersoon bij aflevering','Klant','text','Optioneel'],
  ['Telefoonnummer','phone','Telefoon voor bel/sms/tracking','Klant','phone','Aanbevolen'],
  ['E-mailadres','email','Mail voor tracking/updates','Klant','email','Aanbevolen'],
  ['Klantnummer','customer_number','Intern klantnummer','Klant','text','Optioneel'],
  ['Taal klant','customer_language','NL/EN/DE/etc.','Klant','enum','Optioneel'],
  ['SMS toegestaan','sms_allowed','Mag klant sms ontvangen?','Klant','boolean','Optioneel'],
  ['E-mail tracking toegestaan','email_tracking_allowed','Mag klant e-mail ontvangen?','Klant','boolean','Optioneel'],

  ['Volledig adres','full_address','Adres in één kolom','Adres','address','Aanbevolen'],
  ['Straat','street','Straatnaam','Adres','text','Optioneel'],
  ['Huisnummer','house_number','Huisnummer','Adres','text','Optioneel'],
  ['Toevoeging','house_number_addition','Toevoeging','Adres','text','Optioneel'],
  ['Postcode','postal_code','Postcode voor geocoding','Adres','postcode','Aanbevolen'],
  ['Plaats','city','Plaats/stad','Adres','text','Aanbevolen'],
  ['Provincie','province','Provincie/regio','Adres','text','Optioneel'],
  ['Land','country','Landcode of landnaam','Adres','text','Optioneel'],
  ['Latitude','latitude','GPS latitude','Adres','number','Optioneel'],
  ['Longitude','longitude','GPS longitude','Adres','number','Optioneel'],
  ['Adresnotitie','address_note','Details over locatie','Adres','text','Optioneel'],
  ['Toegangscode','access_code','Poort/deurcode','Adres','text','Optioneel'],
  ['Verdieping','floor','Verdieping voor levering','Adres','text','Optioneel'],
  ['Lift aanwezig','elevator_available','Lift ja/nee','Adres','boolean','Optioneel'],

  ['Tijdvenster start','time_window_start','Vroegste levertijd','Tijdvenster','time','Aanbevolen'],
  ['Tijdvenster eind','time_window_end','Laatste levertijd','Tijdvenster','time','Aanbevolen'],
  ['Tijdvenster gecombineerd','time_window_combined','Bijv. 08:00-12:00','Tijdvenster','timerange','Optioneel'],
  ['Tweede tijdvenster start','time_window_2_start','Tweede mogelijke start','Tijdvenster','time','Optioneel'],
  ['Tweede tijdvenster eind','time_window_2_end','Tweede mogelijke eind','Tijdvenster','time','Optioneel'],
  ['Niet leveren vóór','not_before','Hard constraint start','Tijdvenster','time','Optioneel'],
  ['Niet leveren na','not_after','Hard constraint eind','Tijdvenster','time','Optioneel'],
  ['Afspraak verplicht','appointment_required','Afspraak/klant aanwezig vereist','Tijdvenster','boolean','Optioneel'],

  ['Productnaam','product_name','Naam artikel/orderregel','Producten','text','Aanbevolen'],
  ['SKU/artikelnummer','sku','Artikelnummer','Producten','text','Aanbevolen'],
  ['Omschrijving','description','Omschrijving product/orderregel','Producten','text','Optioneel'],
  ['Aantal','quantity','Aantal stuks','Producten','integer','Aanbevolen'],
  ['Eenheid','unit','Stuk, pallet, RC, colli','Producten','enum','Optioneel'],
  ['Orderregel ID','order_line_id','Unieke regel-ID','Producten','text','Optioneel'],
  ['Barcode','barcode','Barcode/scanwaarde','Producten','text','Optioneel'],
  ['Serienummer','serial_number','Serienummer','Producten','text','Optioneel'],

  ['Gewicht per stuk','weight_per_item','Gewicht per item','Gewicht & Volume','weight','Optioneel'],
  ['Totaalgewicht','total_weight','Totaalgewicht order/regel','Gewicht & Volume','weight','Aanbevolen'],
  ['Volume per stuk','volume_per_item','Volume per item','Gewicht & Volume','volume','Optioneel'],
  ['Totaalvolume','total_volume','Totaalvolume','Gewicht & Volume','volume','Optioneel'],
  ['Lengte','length','Lengte item/lading','Gewicht & Volume','dimension','Optioneel'],
  ['Breedte','width','Breedte item/lading','Gewicht & Volume','dimension','Optioneel'],
  ['Hoogte','height','Hoogte item/lading','Gewicht & Volume','dimension','Optioneel'],
  ['Afmetingen gecombineerd','dimensions_combined','Bijv. 120x80x180','Gewicht & Volume','dimension_set','Optioneel'],
  ['Laadmeters','load_meters','Laadmeters','Gewicht & Volume','number','Optioneel'],

  ['Aantal europallets','euro_pallets','Aantal europalletplaatsen','Pallets & Rolcontainers','integer','Belangrijk'],
  ['Aantal blokpallets','block_pallets','Aantal blokpallets','Pallets & Rolcontainers','integer','Optioneel'],
  ['Aantal rolcontainers','roll_containers','Totaal rolcontainers','Pallets & Rolcontainers','integer','Belangrijk'],
  ['Rolcontainer type','roll_container_type','Type rolcontainer','Pallets & Rolcontainers','enum','Belangrijk'],
  ['Aantal rolcontainers type A','roll_container_type_a','RC type A','Pallets & Rolcontainers','integer','Optioneel'],
  ['Aantal rolcontainers type B','roll_container_type_b','RC type B','Pallets & Rolcontainers','integer','Optioneel'],
  ['Aantal rolcontainers type C','roll_container_type_c','RC type C','Pallets & Rolcontainers','integer','Optioneel'],
  ['Palletplaatsen','pallet_positions','Totaal palletplaatsen','Pallets & Rolcontainers','integer','Optioneel'],
  ['Colli','colli','Aantal colli','Pallets & Rolcontainers','integer','Optioneel'],
  ['Stapelen toegestaan','stackable','Mag stapelen','Pallets & Rolcontainers','boolean','Optioneel'],
  ['Niet stapelen','non_stackable','Niet stapelen','Pallets & Rolcontainers','boolean','Optioneel'],
  ['Breekbaar','fragile','Breekbare lading','Pallets & Rolcontainers','boolean','Optioneel'],
  ['Zwaar','heavy','Zware lading','Pallets & Rolcontainers','boolean','Optioneel'],
  ['Koeltransport','chilled_transport','Koeltransport nodig','Pallets & Rolcontainers','boolean','Optioneel'],
  ['Gevaarlijke stof','hazardous','ADR/gevaarlijke stof','Pallets & Rolcontainers','boolean','Optioneel'],

  ['Prioriteit','priority','Planning prioriteit','Planning','integer','Optioneel'],
  ['Vaste chauffeur','fixed_driver','Order moet naar chauffeur','Planning','text','Optioneel'],
  ['Vast voertuig','fixed_vehicle','Order moet naar voertuig','Planning','text','Optioneel'],
  ['Depot','depot','Start/einddepot','Planning','text','Optioneel'],
  ['Routegroep','route_group','Groepering/gebied','Planning','text','Optioneel'],
  ['Regio','region','Regio','Planning','text','Optioneel'],
  ['Zone','zone','Zone','Planning','text','Optioneel'],
  ['Max vertraging toegestaan','max_delay_minutes','Customer Promise Guard marge','Planning','integer','Optioneel'],
  ['Service level','service_level','Premium/standard/etc.','Planning','enum','Optioneel'],
  ['Spoedlevering','urgent_delivery','Spoed ja/nee','Planning','boolean','Optioneel'],
  ['Alleen ochtend','morning_only','Alleen ochtend leveren','Planning','boolean','Optioneel'],
  ['Alleen middag','afternoon_only','Alleen middag leveren','Planning','boolean','Optioneel'],

  ['Lostijd minuten','unload_minutes','Lostijd bij klant','Service','integer','Aanbevolen'],
  ['Installatietijd minuten','installation_minutes','Montage/installatietijd','Service','integer','Belangrijk'],
  ['Wachttijd verwacht','expected_wait_minutes','Verwachte wachttijd','Service','integer','Optioneel'],
  ['Twee personen nodig','two_person_required','2-man levering','Service','boolean','Belangrijk'],
  ['Hulpmiddel nodig','equipment_required','Hulpmiddel nodig','Service','boolean','Optioneel'],
  ['Klant moet aanwezig zijn','customer_must_be_present','Aanwezigheid vereist','Service','boolean','Optioneel'],
  ['Handtekening verplicht','signature_required','POD handtekening','Service','boolean','Optioneel'],
  ['Foto verplicht','photo_required','POD foto','Service','boolean','Optioneel'],

  ['Bel vooraf','call_ahead','Chauffeur moet bellen','Instructies','boolean','Optioneel'],
  ['Aanbellen bij','ring_at','Aanbellen bij persoon/bedrijf','Instructies','text','Optioneel'],
  ['Achterom leveren','deliver_backdoor','Achterom leveren','Instructies','boolean','Optioneel'],
  ['Bij buren leveren toegestaan','neighbor_allowed','Buren toegestaan','Instructies','boolean','Optioneel'],
  ['Niet bij buren leveren','neighbor_not_allowed','Buren niet toegestaan','Instructies','boolean','Optioneel'],
  ['Parkeerinstructie','parking_instruction','Waar parkeren/lossen','Instructies','text','Optioneel'],
  ['Losinstructie','unload_instruction','Specifieke losinstructie','Instructies','text','Optioneel'],

  ['Tracking e-mail','tracking_email','Mail voor track & trace','Tracking','email','Aanbevolen'],
  ['Tracking telefoonnummer','tracking_phone','Mobiel voor track & trace','Tracking','phone','Aanbevolen'],
  ['Klant mag live tracking zien','customer_live_tracking','Live tracking aan/uit','Tracking','boolean','Optioneel'],
  ['Klant mag ETA updates ontvangen','customer_eta_updates','ETA updates aan/uit','Tracking','boolean','Optioneel'],
  ['SMS template type','sms_template','SMS template','Tracking','enum','Optioneel'],
  ['E-mail template type','email_template','Mail template','Tracking','enum','Optioneel'],

  ['Orderwaarde','order_value','Orderwaarde later finance','Finance','money','Later'],
  ['Verzendkosten','shipping_cost','Transportkosten','Finance','money','Later'],
  ['Betaalstatus','payment_status','Betaalstatus','Finance','enum','Later'],
  ['Betaalmethode','payment_method','Betaalmethode','Finance','enum','Later'],
  ['BTW-code','vat_code','BTW code','Finance','text','Later'],
  ['Kostenplaats','cost_center','Kostenplaats','Finance','text','Later'],
  ['Projectnummer','project_number','Projectnummer','Finance','text','Later'],
  ['Custom veld','custom_field','Maak eigen veld vanuit deze kolom','Custom','custom','Vrij']
].map(([label,key,desc,category,type,badge])=>({label,key,desc,category,type,badge}));

const SMART_SYNONYMS={
  order_number:['order','ordernummer','order nr','order-nr','orderid','order_id','orderno','bonnummer','referentie','ref','shipment','zending'],
  customer_name:['klant','klantnaam','naam klant','customer','customer name','customer_name','client','debiteur','debiteur naam','aflevernaam','consignee','ontvanger'],
  company_name:['bedrijf','bedrijfsnaam','company','company_name','firma','organisatie'],
  contact_person:['contact','contactpersoon','contact person','attention','tav','t.a.v.'],
  phone:['telefoon','tel','phone','mobile','mobiel','gsm','telephone','nummer'],
  email:['email','e-mail','mail','emailadres','e mail'],
  full_address:['adres','address','delivery address','afleveradres','volledig adres','straat adres'],
  street:['straat','street','straatnaam','road'],
  house_number:['huisnummer','nr','number','housenumber','house_number'],
  postal_code:['postcode','postal','postal code','zip','zipcode','zip code','pc'],
  city:['plaats','stad','city','woonplaats','town'],
  country:['land','country'],
  delivery_date:['leverdatum','datum','delivery date','delivery_date','date','planned date','afleverdatum','bezorgdatum'],
  time_window_start:['tijdvenster start','starttijd','start time','window start','from','vanaf','not before','niet voor'],
  time_window_end:['tijdvenster eind','eindtijd','end time','window end','to','tot','not after','niet na'],
  time_window_combined:['tijdslot','tijdvenster','timewindow','time window','slot','venster'],
  product_name:['product','productnaam','item','artikel','omschrijving','description'],
  sku:['sku','artikelnummer','art nr','item code','product code','barcode'],
  quantity:['aantal','qty','quantity','stuks','pieces','pcs'],
  total_weight:['gewicht','totaalgewicht','weight','kg','total weight','bruto gewicht','massa'],
  weight_per_item:['gewicht per stuk','stukgewicht','unit weight','gewicht/stuk'],
  total_volume:['volume','m3','kubiek','total volume','totaalvolume'],
  length:['lengte','length','l'],
  width:['breedte','width','w'],
  height:['hoogte','height','h'],
  euro_pallets:['europallet','europallets','ep','euro pallets','pallets','aantal pallets','palletplaatsen'],
  roll_containers:['rolcontainer','rolcontainers','rc','rollcontainer','roll containers','roll cage','rolcontainers aantal'],
  roll_container_type:['rolcontainer type','rc type','container type','roll type'],
  unload_minutes:['lostijd','los tijd','service time','servicetijd','unload','unload minutes','delivery duration','installatietijd'],
  priority:['prioriteit','priority','prio','urgent','spoed'],
  notes_driver:['opmerking','opmerking chauffeur','chauffeursnotitie','driver note','delivery note','instructie','instruction'],
  tracking_allowed:['tracking','tracktrace','track & trace','tracking toegestaan','send tracking'],
  max_delay_minutes:['max vertraging','max delay','promise guard','vertraging toegestaan']
};
function normalizeHeader(s){return String(s||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[_\-.\/]+/g,' ').replace(/\s+/g,' ').trim()}
function levenshtein(a,b){
  a=normalizeHeader(a); b=normalizeHeader(b);
  const m=[];
  for(let i=0;i<=b.length;i++) m[i]=[i];
  for(let j=0;j<=a.length;j++) m[0][j]=j;
  for(let i=1;i<=b.length;i++){
    for(let j=1;j<=a.length;j++){
      if(b.charAt(i-1)===a.charAt(j-1)){
        m[i][j]=m[i-1][j-1];
      }else{
        m[i][j]=Math.min(m[i-1][j-1]+1, m[i][j-1]+1, m[i-1][j]+1);
      }
    }
  }
  return m[b.length][a.length];
}
function valueSignal(value){const v=String(value||'').trim(); if(!v)return [];
  const sig=[];
  if(/^\d{4}\s?[A-Za-z]{2}$/.test(v))sig.push(['postal_code',0.96,'waarde lijkt NL-postcode']);
  if(/^\+?\d[\d\s\-()]{7,}$/.test(v))sig.push(['phone',0.82,'waarde lijkt telefoonnummer']);
  if(/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v))sig.push(['email',0.98,'waarde lijkt e-mail']);
  if(/^\d{1,2}:\d{2}\s*[-–]\s*\d{1,2}:\d{2}$/.test(v))sig.push(['time_window_combined',0.95,'waarde lijkt tijdslot']);
  if(/^\d{4}-\d{2}-\d{2}$|^\d{1,2}[-\/]\d{1,2}[-\/]\d{2,4}$/.test(v))sig.push(['delivery_date',0.86,'waarde lijkt datum']);
  if(/^\d+[\.,]?\d*\s?(kg|kilo)$/i.test(v))sig.push(['total_weight',0.9,'waarde lijkt gewicht']);
  if(/^\d+[\.,]?\d*\s?(m3|m³)$/i.test(v))sig.push(['total_volume',0.9,'waarde lijkt volume']);
  return sig;
}
function smartFieldCandidates(header,value){const h=normalizeHeader(header);const out=[];
  for(const [key,terms] of Object.entries(SMART_SYNONYMS)){
    let best=0,reason='';
    for(const t of terms){const n=normalizeHeader(t);let score=0;if(h===n)score=0.99;else if(h.includes(n)||n.includes(h))score=Math.min(0.93,0.62+Math.min(h.length,n.length)/Math.max(h.length,n.length)*0.25);else {const d=levenshtein(h,n);score=Math.max(0,1-d/Math.max(h.length,n.length,1)); if(score>0.72)score*=0.82; else score=0}
      if(score>best){best=score;reason=`header match: ${t}`}}
    if(best>0.52)out.push({key,score:best,reason});
  }
  valueSignal(value).forEach(([key,score,reason])=>out.push({key,score,reason}));
  const merged={};out.forEach(c=>{if(!merged[c.key]||merged[c.key].score<c.score)merged[c.key]=c});
  return Object.values(merged).sort((a,b)=>b.score-a.score).slice(0,6);
}
function confidenceLabel(score){return score>=0.9?'Zeer zeker':score>=0.78?'Waarschijnlijk':score>=0.62?'Mogelijk':'Lage zekerheid'}

const FIELD_CATEGORIES=['Aanbevolen','Recent gebruikt','Order','Klant','Adres','Tijdvenster','Producten','Gewicht & Volume','Pallets & Rolcontainers','Planning','Service','Instructies','Tracking','Finance','Custom','System'];
function parseCSV(text){const rows=[];let row=[],cur='',q=false;for(let i=0;i<text.length;i++){let c=text[i],n=text[i+1];if(c==='"'&&q&&n==='"'){cur+='"';i++;continue}if(c==='"'){q=!q;continue}if(c===','&&!q){row.push(cur.trim());cur='';continue}if((c==='\n'||c==='\r')&&!q){if(cur||row.length){row.push(cur.trim());rows.push(row);row=[];cur=''} if(c==='\r'&&n==='\n')i++;continue}cur+=c}if(cur||row.length){row.push(cur.trim());rows.push(row)}return rows.filter(r=>r.some(x=>x!==''));}
function fieldSuggestion(header, sample){const h=(header+' '+sample).toLowerCase();const rules=[['ordernummer',/order.?nr|ordernummer|order.?id|order_number|ref/],['customer_name',/klant|customer|naam|name/],['company_name',/bedrijf|company/],['phone',/telefoon|phone|mobiel|mobile/],['email',/mail|email|e-mail/],['postal_code',/postcode|zip|postal/],['city',/plaats|stad|city|woonplaats/],['full_address',/adres|address/],['delivery_date',/leverdatum|delivery.?date|datum/],['time_window_combined',/tijdvenster|window|slot/],['time_window_start',/start|vanaf/],['time_window_end',/eind|tot|end/],['sku',/sku|artikel|item/],['quantity',/aantal|qty|quantity/],['total_weight',/gewicht|weight|kg/],['total_volume',/volume|m3|m³/],['euro_pallets',/euro.?pallet|pallets/],['roll_containers',/rolcontainer|roll.?container|rc/],['unload_minutes',/lostijd|service.?time|unload/],['priority',/prioriteit|priority/],['driver_note',/chauffeur|driver.?note|opmerking/]];let m=rules.find(([,re])=>re.test(h));return m?FIELD_CATALOG.find(f=>f.key===m[0]):null;}
function getField(key){return FIELD_CATALOG.find(f=>f.key===key)}
function importStudio(){return shell(`<section class="importHero"><div><h1>Planning · Import & Mapping</h1><p>Upload CSV, laat AlgoRoute kolommen slim herkennen met fuzzy matching, controleer mapping en stuur geldige orders direct naar de Planning Queue.</p></div><div class="importSteps"><span class="active">1 Upload</span><span class="active">2 Mapping</span><span>3 Validatie</span><span>4 Queue</span></div></section>${planningTabs()}<section class="importGrid"><div class="card panel importUpload"><h3>CSV upload</h3><label class="dropzone"><input type="file" accept=".csv,text/csv" onchange="handleCSV(event)"><b>Sleep of kies CSV-bestand</b><span>Ondersteunt orderregels, meerdere regels per ordernummer en schaalbare kolommapping.</span></label><button class="primaryBtn" onclick="loadSampleCSV()">Laad voorbeeldbestand</button><div class="templateBox"><h3>Templates</h3>${state.import.templates.length?state.import.templates.map((t,i)=>`<button class="templateBtn" onclick="applyTemplate(${i})">${t.name}<span>${Object.keys(t.mapping).length} velden</span></button>`).join(''):'<p class="muted">Nog geen templates opgeslagen.</p>'}</div></div><div class="card panel importPreview"><div class="sectionHead"><h3>CSV Preview</h3><span class="muted">${state.import.rows.length?state.import.rows.length-1:0} datarijen</span></div>${csvPreview()}</div></section>${mappingStudio()}${validationPanel()}${fieldPickerOverlay()}`)}
function csvPreview(){if(!state.import.rows.length)return '<div class="emptyState">Nog geen CSV geladen. Gebruik voorbeeldbestand om de volledige mapper te testen.</div>';let rows=state.import.rows.slice(0,8);return `<div class="csvTable"><table><thead><tr>${state.import.headers.map((h,i)=>`<th>Kolom ${String.fromCharCode(65+i)}<br><small>${h||'zonder header'}</small></th>`).join('')}</tr></thead><tbody>${rows.slice(1).map(r=>`<tr>${state.import.headers.map((_,i)=>`<td>${r[i]||''}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`}
function mappingStudio(){if(!state.import.rows.length)return `<section class="card panel"><h3>Smart Field Mapping</h3><p class="muted">Na upload verschijnen alle CSV-kolommen hier als Apple-achtige mapping tiles.</p></section>`;return `<section class="card panel"><div class="sectionHead"><h3>Smart Field Mapping</h3><div><button class="ghostBtn" onclick="autoMap()">Auto-map</button><button class="ghostBtn" onclick="saveTemplate()">Template opslaan</button><button class="primaryBtn" onclick="validateImport()">Valideer import</button></div></div><div class="mappingGrid">${state.import.headers.map((h,i)=>mappingTile(i,h)).join('')}</div></section>`}
function mappingTile(i,h){let m=state.import.mapping[i],f=m?getField(m.key):fieldSuggestion(h,(state.import.rows[1]||[])[i]||'');let preview=(state.import.rows[1]||[])[i]||'—';return `<div class="mapTile ${m?'mapped':''}"><div class="colTag">Kolom ${String.fromCharCode(65+i)}</div><h4>${h||'Zonder header'}</h4><p>${preview}</p><button class="fieldBtn" onclick="openFieldPicker(${i})">${m?`<span>${getField(m.key)?.label||m.key}</span><small>${getField(m.key)?.category||''}</small>`:f?`<span>Aanbevolen: ${f.label}</span><small>${f.category}</small>`:'Kies veld…'}</button>${m?fieldConfig(i,m):''}</div>`}
function fieldConfig(i,m){let f=getField(m.key)||{};if(m.key==='negeren')return '<div class="fieldConfig muted">Wordt genegeerd</div>';let extra='';if(['weight','volume','dimension'].includes(f.type))extra=`<label>Eenheid <select onchange="setMapConfig(${i},'unit',this.value)"><option>kg</option><option>gram</option><option>m3</option><option>cm</option><option>mm</option></select></label>`;if(['date','time','timerange'].includes(f.type))extra=`<label>Formaat <select onchange="setMapConfig(${i},'format',this.value)"><option>auto</option><option>DD-MM-YYYY</option><option>YYYY-MM-DD</option><option>HH:mm</option><option>08:00-12:00</option></select></label>`;if(f.type==='custom')extra=`<label>Naam custom veld <input value="${m.customName||''}" oninput="setMapConfig(${i},'customName',this.value)" placeholder="Bijv. montageploeg"></label>`;return `<div class="fieldConfig"><small>Type: ${f.type||'text'} · ${f.badge||''}</small>${extra}</div>`}
function fieldPickerOverlay(){if(state.import.selectedCol===null)return '';let col=state.import.selectedCol;let header=state.import.headers[col]||`Kolom ${String.fromCharCode(65+col)}`;let q=(state.import.search||'').toLowerCase();let recent=(JSON.parse(localStorage.getItem('algoroute_recent_fields')||'[]')).map(k=>getField(k)).filter(Boolean);let recommended=fieldSuggestion(header,(state.import.rows[1]||[])[col]||'');let fields=FIELD_CATALOG.filter(f=>{let cat=state.import.activeCategory;if(cat==='Aanbevolen')return recommended?f.key===recommended.key:['order_number','customer_name','full_address','postal_code','city','delivery_date','time_window_start','time_window_end','total_weight','euro_pallets','roll_containers','unload_minutes','driver_note'].includes(f.key);if(cat==='Recent gebruikt')return recent.some(r=>r.key===f.key);return f.category===cat});if(q)fields=FIELD_CATALOG.filter(f=>(f.label+' '+f.key+' '+f.desc+' '+f.category).toLowerCase().includes(q));return `<div class="pickerBackdrop"><div class="fieldPicker"><div class="pickerTop"><div><h2>Kies veld voor ${header}</h2><p>Zoek zoals Google/Spotlight. Geen onoverzichtelijke dropdowns.</p></div><button onclick="closeFieldPicker()">×</button></div><input class="pickerSearch" autofocus placeholder="Zoek veld, bijv. gewicht, postcode, rolcontainer, tijdvenster…" value="${state.import.search}" oninput="setImportSearch(this.value)"><div class="pickerBody"><aside>${FIELD_CATEGORIES.map(c=>`<button class="${state.import.activeCategory===c?'active':''}" onclick="setPickerCategory('${c}')">${c}</button>`).join('')}</aside><main>${fields.map(f=>`<button class="fieldCard" onclick="chooseField('${f.key}')"><b>${f.label}</b><span>${f.desc}</span><small>${f.category} · ${f.type} · ${f.badge}</small></button>`).join('')}${q&&!fields.length?`<button class="fieldCard customNew" onclick="chooseCustomFromSearch()"><b>+ Maak custom veld “${state.import.search}”</b><span>Wordt opgeslagen als metadata bij order/orderregel.</span></button>`:''}</main></div></div></div>`}
function validationPanel(){if(!state.import.validation)return `<section class="card panel validation"><h3>Validatie</h3><p class="muted">Mapping nog niet gevalideerd.</p></section>`;let v=state.import.validation;return `<section class="card panel validation"><div class="sectionHead"><h3>Validatie resultaat</h3><button class="primaryBtn" onclick="commitImport()">Importeer naar Planning Queue</button></div><div class="validationStats"><div><b>${v.valid}</b><span>geldige regels</span></div><div><b>${v.warnings}</b><span>waarschuwingen</span></div><div><b>${v.errors.length}</b><span>fouten</span></div></div>${v.errors.length?`<div class="errorList">${v.errors.map(e=>`<div><b>Regel ${e.row}</b><span>${e.message}</span></div>`).join('')}</div>`:'<p class="okText">Alle verplichte velden zijn aanwezig. Klaar voor import.</p>'}</section>`}
function handleCSV(ev){let file=ev.target.files[0];if(!file)return;let reader=new FileReader();reader.onload=()=>{let rows=parseCSV(reader.result);state.import.rows=rows;state.import.headers=rows[0]||[];state.import.mapping={};state.import.validation=null;autoMap(false);render()};reader.readAsText(file)}
function loadSampleCSV(){let csv='ordernummer,klantnaam,straat,huisnummer,postcode,plaats,telefoon,email,leverdatum,tijdvenster,product,aantal,totaalgewicht,europallets,rolcontainers,lostijd,prioriteit,opmerking chauffeur,twee personen nodig,tracking toegestaan\nORD-1001,De Vries Keukens,Keizersgracht,12,1015CJ,Amsterdam,0612345678,planning@example.nl,2026-06-28,08:00-11:00,Keukenfronten,4,320,2,0,25,2,Bel 30 min vooraf,ja,ja\nORD-1002,Studio Wonen,Coolsingel,50,3011AD,Rotterdam,0687654321,info@studio.nl,2026-06-28,10:00-13:00,Witgoed set,2,180,1,1,35,1,Levering achterom,ja,ja\nORD-1003,Bouwmarkt Zuid,Markt,8,5611EC,Eindhoven,0611122233,logistiek@bouw.nl,2026-06-28,13:00-16:00,Sanitair pallet,1,540,3,0,45,3,Lossen bij magazijndeur,nee,ja';let rows=parseCSV(csv);state.import.rows=rows;state.import.headers=rows[0];state.import.mapping={};state.import.validation=null;autoMap(false);render()}
function autoMap(doRender=true){state.import.headers.forEach((h,i)=>{let f=fieldSuggestion(h,(state.import.rows[1]||[])[i]||'');if(f)state.import.mapping[i]={key:f.key,config:{}}});if(doRender)render()}
function openFieldPicker(i){state.import.selectedCol=i;state.import.search='';state.import.activeCategory='Aanbevolen';render()}function closeFieldPicker(){state.import.selectedCol=null;render()}function setImportSearch(v){state.import.search=v;render()}function setPickerCategory(c){state.import.activeCategory=c;state.import.search='';render()}
function chooseField(key){let i=state.import.selectedCol;state.import.mapping[i]={key,config:{}};let rec=JSON.parse(localStorage.getItem('algoroute_recent_fields')||'[]').filter(x=>x!==key);rec.unshift(key);localStorage.setItem('algoroute_recent_fields',JSON.stringify(rec.slice(0,8)));state.import.selectedCol=null;render()}
function chooseCustomFromSearch(){let i=state.import.selectedCol;state.import.mapping[i]={key:'custom_field',customName:state.import.search,config:{}};state.import.selectedCol=null;render()}
function setMapConfig(i,k,v){state.import.mapping[i]=state.import.mapping[i]||{key:'custom_field',config:{}};state.import.mapping[i][k]=v}
function saveTemplate(){let name=prompt('Naam template','Eigen CSV template');if(!name)return;state.import.templates.unshift({name,mapping:state.import.mapping,created:new Date().toISOString()});localStorage.setItem('algoroute_import_templates',JSON.stringify(state.import.templates.slice(0,12)));render()}
function applyTemplate(i){state.import.mapping=JSON.parse(JSON.stringify(state.import.templates[i].mapping||{}));state.import.validation=null;render()}
function validateImport(){let mapped=Object.values(state.import.mapping).map(m=>m.key);let required=['order_number','customer_name'];let errors=[];required.forEach(req=>{if(!mapped.includes(req))errors.push({row:'mapping',message:`Verplicht veld ontbreekt: ${getField(req).label}`})});let hasAddress=mapped.includes('full_address')||(mapped.includes('postal_code')&&mapped.includes('city'));if(!hasAddress)errors.push({row:'mapping',message:'Adres ontbreekt: gebruik Volledig adres of Postcode + Plaats'});let rows=state.import.rows.slice(1);rows.forEach((r,idx)=>{Object.entries(state.import.mapping).forEach(([ci,m])=>{let f=getField(m.key);let val=r[+ci]||'';if(['total_weight','quantity','euro_pallets','roll_containers','unload_minutes'].includes(m.key)&&val&&isNaN(Number(String(val).replace(',','.'))))errors.push({row:idx+2,message:`${f.label} is geen getal: ${val}`});});});state.import.validation={valid:Math.max(0,rows.length-errors.length),warnings:mapped.includes('phone')||mapped.includes('email')?0:1,errors};render()}
async function commitImport(){if(!state.import.validation||state.import.validation.errors.length){alert('Los eerst validatiefouten op.');return;}await fetch('/api/planning/queue/import',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({rows:state.import.rows,mapping:state.import.mapping})});alert(`${state.import.validation.valid} orders klaargezet voor Planning Queue.`);state.view='planning';render()}



function planningTabs(){const tabs=[['import','1 Import'],['mapping','2 Mapping'],['queue','3 Queue'],['optimize','4 Optimize'],['publish','5 Publish']];return `<div class="subTabs">${tabs.map(([id,label])=>`<button class="${state.planning.tab===id?'active':''}" onclick="setPlanningTab('${id}')">${label}</button>`).join('')}</div>`}
function setPlanningTab(t){state.planning.tab=t; if(t==='import'||t==='mapping'){state.view='import'} else {state.view='planning'} render()}
function planningImportShortcut(){return shell(`<section class="planningHero"><div><h1>Planning · Import</h1><p>Upload orders, kies of maak een template en ga daarna naar Mapping. Import is onderdeel van de Planning workflow, niet langer een los hoofdmenu-item.</p></div><div class="planningActions"><button class="primaryBtn" onclick="setPlanningTab('mapping')">Ga naar Mapping →</button></div></section>${planningTabs()}${importStudio().replace(/^<div class="app">[\s\S]*?<main class="main"><header[\s\S]*?<\/header>/,'').replace(/<\/main><\/div>$/,'')}`)}

function planningQueue(){
  const orders=state.planning.orders||[];
  const dates=['all',...Array.from(new Set(orders.map(o=>o.delivery_date||'ongepland'))).sort()];
  const filtered=orders.filter(o=>(state.planning.date==='all'||o.delivery_date===state.planning.date)&&(state.planning.status==='all'||o.status===state.planning.status));
  const selected=orders.find(o=>o.id===state.planning.selected)||filtered[0]||orders[0];
  const s=state.planning.summary||{};
  const totalLoad=`${s.total_euro_pallets||0} pallets · ${s.total_roll_containers||0} RC · ${s.total_weight_kg||0} kg`;
  return shell(`<section class="planningHero"><div><h1>Planning Queue</h1><p>Controleer leverdatum, tijdvensters, service/lostijd en capaciteit voordat AlgoRoute de optimizer start.</p></div><div class="planningActions"><button class="ghostBtn">Batch maken</button><button class="primaryBtn">Optimize Routes</button></div></section>${planningTabs()}<section class="planningKpis"><div class="card kpi"><div class="kpiIcon i-green">✓</div><div><label>Klaar voor planning</label><div class="value">${s.ready||0}</div><small>orders zonder blokkades</small></div></div><div class="card kpi"><div class="kpiIcon i-orange">!</div><div><label>Aandacht nodig</label><div class="value">${(s.attention||0)+(s.incomplete||0)}</div><small>tijdslot/capaciteit check</small></div></div><div class="card kpi"><div class="kpiIcon i-purple">▦</div><div><label>Totale lading</label><div class="value smallValue">${totalLoad}</div><small>voor geselecteerde dagfilter</small></div></div><div class="card kpi"><div class="kpiIcon i-lime">⇄</div><div><label>Beschikbare vloot</label><div class="value smallValue">${s.available_euro_pallets||0} pallets · ${s.available_weight_kg||0} kg</div><small>alleen beschikbare voertuigen</small></div></div></section><section class="planningGrid"><div class="card panel queuePanel"><div class="sectionHead"><h3>Orders in wachtrij</h3><span class="muted">${filtered.length} zichtbaar</span></div><div class="filters"><select onchange="setPlanningFilter('date',this.value)">${dates.map(d=>`<option value="${d}" ${state.planning.date===d?'selected':''}>${d==='all'?'Alle leverdagen':d}</option>`).join('')}</select><select onchange="setPlanningFilter('status',this.value)">${['all','ready','attention','incomplete'].map(st=>`<option value="${st}" ${state.planning.status===st?'selected':''}>${st==='all'?'Alle statussen':st}</option>`).join('')}</select></div><div class="queueList">${filtered.map(o=>orderRow(o)).join('')||'<div class="emptyState">Geen orders voor dit filter.</div>'}</div></div><div class="card panel batchPanel"><h3>Batch readiness</h3><div class="capacityBox"><b>Capacity pre-check</b><div class="capLine"><span>Europallets</span><i><em style="width:${Math.min(100,(s.total_euro_pallets||0)/(s.available_euro_pallets||1)*100)}%"></em></i><strong>${s.total_euro_pallets||0}/${s.available_euro_pallets||0}</strong></div><div class="capLine"><span>Rolcontainers</span><i><em style="width:${Math.min(100,(s.total_roll_containers||0)/(s.available_roll_containers||1)*100)}%"></em></i><strong>${s.total_roll_containers||0}/${s.available_roll_containers||0}</strong></div><div class="capLine"><span>Gewicht</span><i><em style="width:${Math.min(100,(s.total_weight_kg||0)/(s.available_weight_kg||1)*100)}%"></em></i><strong>${s.total_weight_kg||0}/${s.available_weight_kg||0} kg</strong></div></div><div class="routeItem"><b>Hard constraints</b><span class="badge green">tijdvensters</span></div><div class="routeItem"><b>Soft constraints</b><span class="badge orange">max vertraging</span></div><div class="routeItem"><b>Load check V1</b><span class="badge purple">pallet/RC</span></div></div>${selected?orderDetail(selected):'<div class="card panel"><h3>Order detail</h3><p class="muted">Selecteer een order.</p></div>'}</section>`)}
function orderRow(o){const color=o.status==='ready'?'green':o.status==='attention'?'orange':'red';return `<button class="orderRow ${state.planning.selected===o.id?'active':''}" onclick="selectOrder('${o.id}')"><div><b>${o.order_number}</b><span>${o.customer_name} · ${o.city}</span></div><div><strong>${o.delivery_date}</strong><span>${o.window_label}</span></div><div><strong>${o.euro_pallets} EP · ${o.roll_containers} RC</strong><span>${o.total_weight_kg} kg · ${o.unload_minutes} min</span></div><span class="badge ${color}">${o.status}</span></button>`}
function orderDetail(o){return `<div class="card panel detailPanel"><div class="sectionHead"><h3>${o.order_number}</h3><span class="badge ${o.status==='ready'?'green':o.status==='attention'?'orange':'red'}">${o.status}</span></div><h2>${o.customer_name}</h2><p class="muted">${o.postal_code} ${o.city} · ${o.product}</p><div class="detailGrid"><div><label>Leverdatum</label><b>${o.delivery_date}</b></div><div><label>Tijdvenster</label><b>${o.window_label}</b></div><div><label>Lostijd</label><b>${o.unload_minutes} min</b></div><div><label>Prioriteit</label><b>${o.priority}</b></div><div><label>Lading</label><b>${o.euro_pallets} EP · ${o.roll_containers} RC</b></div><div><label>Gewicht</label><b>${o.total_weight_kg} kg</b></div></div><h3>Readiness</h3><div class="readiness">${(o.readiness||[]).map(x=>`<span>✓ ${x.replaceAll('_',' ')}</span>`).join('')}${(o.warnings||[]).map(x=>`<span class="warn">⚠ ${x}</span>`).join('')}</div><h3>Chauffeursnotitie</h3><p class="noteBox">${o.notes||'Geen notitie'}</p><div class="planningActions"><button class="ghostBtn">Aanpassen</button><button class="primaryBtn">Toevoegen aan batch</button></div></div>`}
function setPlanningFilter(k,v){state.planning[k]=v;render()}function selectOrder(id){state.planning.selected=id;render()}

function placeholder(name){return shell(`${kpis()}<section class="card panel moduleHero"><h3>${name}</h3><p class="muted">Deze pagina staat klaar binnen de nieuwe premium light workspace. Volgende builds koppelen hier echte workflows aan: import mapping, planning jobs, load checks en customer tracking.</p><div class="bottom"><div class="card panel"><h3>API-ready</h3><p class="muted">Data via /api endpoints.</p></div><div class="card panel"><h3>Schaalbare module</h3><p class="muted">Eigen pagina en componentstructuur.</p></div><div class="card panel"><h3>Volgende stap</h3><p class="muted">Functionele workflow toevoegen.</p></div></div></section>`)}
function render(){state.mapInstances={}; if(!state.map)return; app.innerHTML= state.view==='dashboard'?dashboard():state.view==='map'?liveMap():state.view==='vehicles'?vehicles():state.view==='import'?importStudio():state.view==='planning'?planningQueue():placeholder({planning:'Planning',routes:'Routes',load:'Load Optimization',drivers:'Chauffeurs',orders:'Orders',tracking:'Klanttracking',reports:'Rapportages',settings:'Instellingen'}[state.view]||'Module')}
function go(v){state.view=v;if(v==='planning'&&!state.planning.tab)state.planning.tab='queue';render()}function selectVehicle(id){state.selected=id;render()}load();
