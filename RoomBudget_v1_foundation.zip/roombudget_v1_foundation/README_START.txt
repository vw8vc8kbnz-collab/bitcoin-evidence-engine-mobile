RoomBudget V1 Foundation
- Mobile-first PWA
- Eigen systemd service: roombudget.service
- Eigen poort: 8899 standaard
- Mock AI provider standaard: geen echte AI kosten
- AI safety layer: geen auto-retry, 1 gratis render, caps, admin safety page
- Bestaande VPS-tools worden niet gewijzigd; installatie gebruikt /opt/roombudget en eigen service.
