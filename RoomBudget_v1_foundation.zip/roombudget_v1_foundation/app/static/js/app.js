document.querySelectorAll('[data-compare]').forEach(c=>{const r=c.querySelector('input'),w=c.querySelector('.after-wrap');function u(){w.style.width=r.value+'%'}r.addEventListener('input',u);u()});
const btn=document.getElementById('generateBtn'); if(btn){btn.closest('form').addEventListener('submit',()=>{btn.disabled=true;btn.textContent='GENEREREN...';});}
