#!/usr/bin/env bash
set -euo pipefail
APP_DIR="${ROOMBUDGET_APP_DIR:-/opt/roombudget}"
PORT="${ROOMBUDGET_PORT:-8899}"
SERVICE="roombudget.service"
PYTHON_BIN="$(command -v python3)"
echo "Installing RoomBudget into $APP_DIR on port $PORT"
sudo mkdir -p "$APP_DIR"
sudo rsync -a --delete ./ "$APP_DIR/"
sudo chown -R "$USER":"$USER" "$APP_DIR"
cd "$APP_DIR"
$PYTHON_BIN -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/pip install --only-binary=:all: -r requirements.txt
SECRET="$(python3 - <<'PY'
import secrets; print(secrets.token_urlsafe(48))
PY
)"
cat > .env <<ENV
ROOMBUDGET_PORT=$PORT
ROOMBUDGET_SECRET_KEY=$SECRET
ROOMBUDGET_AI_PROVIDER=mock
ROOMBUDGET_AI_ENABLED=true
ROOMBUDGET_FREE_RENDERS_PER_USER=1
ROOMBUDGET_MAX_DAILY_RENDERS_GLOBAL=100
ROOMBUDGET_MAX_MONTHLY_AI_EUR=100
ENV
sudo tee /etc/systemd/system/$SERVICE >/dev/null <<UNIT
[Unit]
Description=RoomBudget PWA
After=network.target

[Service]
Type=simple
WorkingDirectory=$APP_DIR
EnvironmentFile=$APP_DIR/.env
ExecStart=$APP_DIR/.venv/bin/uvicorn app.main:app --host 0.0.0.0 --port $PORT
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
UNIT
sudo systemctl daemon-reload
sudo systemctl enable $SERVICE
sudo systemctl restart $SERVICE
sudo systemctl status $SERVICE --no-pager -l || true
echo "RoomBudget installed. Open: http://YOUR_VPS_IP:$PORT"
