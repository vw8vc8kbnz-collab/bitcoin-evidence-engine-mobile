import os, json, time, threading, sqlite3, math
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Any, Optional

import requests
from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.responses import HTMLResponse, JSONResponse

ROOT = Path('/home/ubuntu/stock-gem-engine') if Path('/home/ubuntu/stock-gem-engine').exists() else Path(__file__).resolve().parents[1]
DATA = ROOT / 'data'; LOGS = ROOT / 'logs'
DATA.mkdir(parents=True, exist_ok=True); LOGS.mkdir(parents=True, exist_ok=True)
load_dotenv(ROOT / '.env')

APP_VERSION = '0.8.0-live-openai-deepseek-ai'
PORT = int(os.getenv('APP_PORT','8791'))
NTFY_TOPIC = os.getenv('NTFY_TOPIC','Stijn-Tradifi-2026')
AI_PROVIDER = os.getenv('AI_PROVIDER','openai').lower()
AI_FALLBACK_PROVIDER = os.getenv('AI_FALLBACK_PROVIDER','deepseek').lower()
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY','').strip()
DEEPSEEK_API_KEY = os.getenv('DEEPSEEK_API_KEY','').strip()
OPENAI_BASE_URL = os.getenv('OPENAI_BASE_URL','https://api.openai.com/v1').rstrip('/')
DEEPSEEK_BASE_URL = os.getenv('DEEPSEEK_BASE_URL','https://api.deepseek.com').rstrip('/')
OPENAI_MODEL = os.getenv('OPENAI_MODEL','gpt-4.1-mini')
DEEPSEEK_MODEL = os.getenv('DEEPSEEK_MODEL','deepseek-reasoner')
AI_ENABLED = os.getenv('AI_ENABLED','true').lower() == 'true'
AI_MAX_PER_SCAN = int(os.getenv('AI_MAX_PER_SCAN','5'))
SCAN_INTERVAL_MINUTES = int(os.getenv('SCAN_INTERVAL_MINUTES','60'))
AUTO_SCAN_ENABLED = os.getenv('AUTO_SCAN_ENABLED','true').lower() == 'true'
DB = DATA / 'stock_gems.sqlite3'

app = FastAPI(title='Stijn-Tradifi-2026 Stock Gem Engine', version=APP_VERSION)
state = {'running': False, 'last_scan': None, 'last_alerts': 0, 'error': None}

def log(msg: str):
    LOGS.mkdir(parents=True, exist_ok=True)
    with open(LOGS / 'app.log', 'a', encoding='utf-8') as f:
        f.write(f"{datetime.now(timezone.utc).isoformat()} {msg}\n")

def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    con.execute('''CREATE TABLE IF NOT EXISTS gems (
      ticker TEXT PRIMARY KEY, name TEXT, sector TEXT, country TEXT, exchange TEXT,
      mcap_usd REAL, mcap_source TEXT, mcap_confidence TEXT,
      gem_score REAL, early_signal REAL, hype_risk REAL, risk_score REAL,
      company_short TEXT, why_attractive TEXT, risk_plain TEXT, catalyst_plain TEXT,
      broker_json TEXT, news_json TEXT, first_seen TEXT, last_seen TEXT, alerted INTEGER DEFAULT 0
    )''')
    con.execute('''CREATE TABLE IF NOT EXISTS scan_runs(id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, count INTEGER, alerts INTEGER, note TEXT)''')
    return con

UNIVERSE = [
 {'ticker':'DPRO','name':'Draganfly','sector':'Drones / Defense Tech','country':'Canada/US','exchange':'NASDAQ/CSE','mcap':187_000_000,'news':['Defense drone integration deals','Autonomous counter-UAS platform mentions']},
 {'ticker':'PRZO','name':'ParaZero Technologies','sector':'Drone safety / Defense','country':'Israel/US','exchange':'NASDAQ','mcap':38_000_000,'news':['DefendAir net pod integration deal','Autonomous counter-UAS platform']},
 {'ticker':'QBTS','name':'D-Wave Quantum','sector':'Quantum computing','country':'Canada/US','exchange':'NYSE','mcap':1_900_000_000,'news':['Quantum adoption narrative','Enterprise optimization pilots']},
 {'ticker':'RGTI','name':'Rigetti Computing','sector':'Quantum computing','country':'US','exchange':'NASDAQ','mcap':2_100_000_000,'news':['Quantum hardware roadmap','Government research funding']},
 {'ticker':'KULR','name':'KULR Technology','sector':'Battery safety / Energy storage','country':'US','exchange':'NYSE American','mcap':410_000_000,'news':['Battery safety contracts','Defense/space thermal management']},
 {'ticker':'OPTT','name':'Ocean Power Technologies','sector':'Marine energy / Defense','country':'US','exchange':'NYSE American','mcap':34_000_000,'news':['Maritime surveillance buoys','Defense ocean monitoring']},
 {'ticker':'ONDS','name':'Ondas Holdings','sector':'Autonomous drones / Networks','country':'US','exchange':'NASDAQ','mcap':92_000_000,'news':['Autonomous drone platform','Industrial private wireless']},
 {'ticker':'LIDR','name':'AEye','sector':'LiDAR / Autonomy','country':'US','exchange':'NASDAQ','mcap':45_000_000,'news':['Automotive lidar pipeline','Industrial sensing applications']},
 {'ticker':'MVIS','name':'MicroVision','sector':'LiDAR / Automotive sensors','country':'US','exchange':'NASDAQ','mcap':260_000_000,'news':['ADAS sensor narrative','Strategic alternatives discussion']},
 {'ticker':'ASTI','name':'Ascent Solar Technologies','sector':'Thin-film solar / Space','country':'US','exchange':'NASDAQ','mcap':55_000_000,'news':['Lightweight solar modules','Aerospace/space application potential']},
 {'ticker':'BBAI','name':'BigBear.ai','sector':'AI / Defense analytics','country':'US','exchange':'NYSE','mcap':1_200_000_000,'news':['AI defense analytics','Government contract narrative']},
 {'ticker':'SOUN','name':'SoundHound AI','sector':'Voice AI','country':'US','exchange':'NASDAQ','mcap':3_100_000_000,'news':['Enterprise voice AI adoption','Automotive assistant traction']},
 {'ticker':'REKR','name':'Rekor Systems','sector':'AI infrastructure / Public safety','country':'US','exchange':'NASDAQ','mcap':180_000_000,'news':['Roadway intelligence platform','Public sector AI analytics']},
 {'ticker':'KSCP','name':'Knightscope','sector':'Security robotics','country':'US','exchange':'NASDAQ','mcap':30_000_000,'news':['Autonomous security robots','Recurring security contracts']},
 {'ticker':'AISP','name':'Airship AI','sector':'AI video analytics','country':'US','exchange':'NASDAQ','mcap':140_000_000,'news':['Edge AI surveillance','Government/enterprise analytics']},
 {'ticker':'GEVO','name':'Gevo','sector':'Sustainable aviation fuel','country':'US','exchange':'NASDAQ','mcap':420_000_000,'news':['SAF plant financing','Airline offtake agreements']},
 {'ticker':'UUUU','name':'Energy Fuels','sector':'Uranium / Rare earths','country':'US/Canada','exchange':'NYSE American/TSX','mcap':1_050_000_000,'news':['Uranium cycle strength','Rare earth processing']},
 {'ticker':'UEC','name':'Uranium Energy','sector':'Uranium','country':'US/Canada','exchange':'NYSE American','mcap':2_600_000_000,'news':['Uranium restart optionality','US nuclear fuel narrative']},
 {'ticker':'HYSR','name':'SunHydrogen','sector':'Hydrogen research','country':'US','exchange':'OTC','mcap':65_000_000,'news':['Green hydrogen prototype','Research milestone watch']},
 {'ticker':'CYBN','name':'Cybin','sector':'Biotech / Neuropsychiatry','country':'Canada/US','exchange':'NYSE American/NEO','mcap':370_000_000,'news':['Clinical-stage neuropsychiatry pipeline','Trial catalyst watch']},
 {'ticker':'ATOS','name':'Atossa Therapeutics','sector':'Biotech / Oncology','country':'US','exchange':'NASDAQ','mcap':150_000_000,'news':['Breast cancer therapy trials','Clinical catalyst watch']},
 {'ticker':'TNYA','name':'Tenaya Therapeutics','sector':'Biotech / Gene therapy','country':'US','exchange':'NASDAQ','mcap':220_000_000,'news':['Cardiac gene therapy pipeline','Clinical readout watch']},
 {'ticker':'EOSE','name':'Eos Energy Enterprises','sector':'Grid storage','country':'US','exchange':'NASDAQ','mcap':1_400_000_000,'news':['Long-duration storage demand','US manufacturing support']},
 {'ticker':'ABAT','name':'American Battery Technology','sector':'Battery recycling / Lithium','country':'US','exchange':'NASDAQ','mcap':120_000_000,'news':['Battery recycling ramp','Lithium resource development']},
]

BROKER_CACHE: Dict[str, Any] = {}

def classify_mcap(m):
    if m is None: return 'onbekend'
    if m < 50_000_000: return 'nano/microcap'
    if m < 300_000_000: return 'microcap'
    if m < 2_000_000_000: return 'smallcap'
    return 'groter dan echte microcap'

def fmt_mcap(m):
    if not m: return 'Onbekend'
    if m >= 1_000_000_000: return f"${m/1_000_000_000:.2f}B"
    return f"${m/1_000_000:.1f}M"

MCAP_CACHE: Dict[str, Any] = {}

def _safe_num(v):
    try:
        if v is None: return None
        x = float(v)
        return x if x > 0 else None
    except Exception:
        return None

def yahoo_market_cap(ticker: str):
    """Free live market-cap lookup. No key. Returns USD-ish Yahoo market cap when available.
    Important: this is now preferred over curated references because microcaps often dilute/reverse-split.
    """
    if os.getenv('MCAP_LIVE_ENABLED','true').lower() != 'true':
        return None
    t = ticker.upper().strip()
    cached = MCAP_CACHE.get(t)
    if cached and time.time() - cached.get('ts',0) < 15*60:
        return cached.get('value')
    try:
        headers = {'User-Agent':'Mozilla/5.0 StockGemEngine/0.6'}
        r = requests.get('https://query1.finance.yahoo.com/v7/finance/quote',
                         params={'symbols':t}, headers=headers, timeout=8)
        if r.status_code != 200:
            log(f'mcap_yahoo_http ticker={t} status={r.status_code}')
            return None
        data = r.json().get('quoteResponse',{}).get('result',[])
        if not data:
            log(f'mcap_yahoo_empty ticker={t}')
            return None
        row = data[0]
        mcap = _safe_num(row.get('marketCap'))
        price = _safe_num(row.get('regularMarketPrice'))
        shares = _safe_num(row.get('sharesOutstanding') or row.get('impliedSharesOutstanding'))
        if mcap is None and price and shares:
            mcap = price * shares
        if mcap and mcap > 500_000:
            MCAP_CACHE[t] = {'ts': time.time(), 'value': mcap}
            return mcap
        return None
    except Exception as e:
        log(f'mcap_yahoo_error ticker={t} err={str(e)[:140]}')
        return None

def live_market_cap(item):
    ticker = item['ticker'].upper()
    curated = _safe_num(item.get('mcap'))
    live = yahoo_market_cap(ticker)
    if live:
        if curated and (live > curated * 1.8 or live < curated * 0.55):
            log(f'mcap_override ticker={ticker} curated={curated:.0f} live={live:.0f}')
        return float(live), 'yahoo_live_marketcap', 'high'
    # fallback is allowed, but clearly labelled as fallback so wrong values are not trusted blindly.
    if curated:
        return float(curated), 'curated_fallback_no_live', 'low'
    return None, 'missing', 'low'

def ibkr_check(ticker, exchange):
    url = os.getenv('IBKR_GATEWAY_URL','').rstrip('/')
    if not url:
        return {'status':'not_configured','label':'IBKR API nog niet gekoppeld','route':None,'detail':'Vul IBKR_GATEWAY_URL in wanneer Client Portal Gateway draait.'}
    try:
        verify = os.getenv('IBKR_VERIFY_SSL','false').lower() == 'true'
        r = requests.get(f"{url}/iserver/secdef/search", params={'symbol':ticker}, timeout=6, verify=verify)
        if r.status_code == 200:
            rows = r.json() if isinstance(r.json(), list) else []
            for row in rows:
                if str(row.get('symbol','')).upper() == ticker.upper():
                    return {'status':'verified','label':'IBKR verified','route':f"{ticker} / conid {row.get('conid','?')}", 'detail':row.get('companyName') or row.get('description') or 'gevonden via IBKR'}
            return {'status':'not_found','label':'Niet gevonden op IBKR','route':None,'detail':'IBKR API gaf geen exacte ticker-match terug.'}
        return {'status':'api_error','label':'IBKR API fout','route':None,'detail':f'HTTP {r.status_code}'}
    except Exception as e:
        return {'status':'api_error','label':'IBKR niet bereikbaar','route':None,'detail':str(e)[:120]}

def saxo_check(ticker, exchange):
    token = os.getenv('SAXO_ACCESS_TOKEN','')
    base = os.getenv('SAXO_BASE_URL','https://gateway.saxobank.com/sim/openapi').rstrip('/')
    if not token:
        return {'status':'not_configured','label':'Saxo API nog niet gekoppeld','route':None,'detail':'Vul SAXO_ACCESS_TOKEN in na Saxo OpenAPI setup.'}
    try:
        headers={'Authorization':f'Bearer {token}'}
        r = requests.get(f"{base}/ref/v1/instruments", params={'Keywords':ticker,'AssetTypes':'Stock','$top':10}, headers=headers, timeout=8)
        if r.status_code == 200:
            data = r.json().get('Data', [])
            for row in data:
                sym = str(row.get('Symbol','')).upper()
                if sym == ticker.upper() or ticker.upper() in sym:
                    exch = row.get('ExchangeId') or row.get('Exchange') or ''
                    return {'status':'verified','label':'Saxo verified','route':f"{sym}:{exch}" if exch else sym, 'detail':row.get('Description') or 'gevonden via Saxo OpenAPI'}
            return {'status':'not_found','label':'Niet gevonden op Saxo','route':None,'detail':'Saxo API gaf geen exacte ticker-match terug.'}
        return {'status':'api_error','label':'Saxo API fout','route':None,'detail':f'HTTP {r.status_code}'}
    except Exception as e:
        return {'status':'api_error','label':'Saxo niet bereikbaar','route':None,'detail':str(e)[:120]}

def broker_availability(ticker, exchange):
    cache_key = ticker + '|' + exchange
    # avoid repeated external calls in same process for 15 min
    now = time.time(); cached = BROKER_CACHE.get(cache_key)
    if cached and now - cached['ts'] < 900: return cached['data']
    data = {
      'ibkr': ibkr_check(ticker, exchange),
      'saxo': saxo_check(ticker, exchange),
      'degiro': {'status':'unsupported','label':'Geen officiële DEGIRO API','route':None,'detail':'Niet tonen als exact koopbaar zonder officiële API.'},
      'trading212': {'status':'planned','label':'Trading 212 later','route':None,'detail':'Kan later via officiële instrument list/API.'}
    }
    BROKER_CACHE[cache_key] = {'ts':now, 'data':data}
    return data

def score_item(item):
    mcap, src, conf = live_market_cap(item)
    mcap_factor = max(0, min(1, (600_000_000 - min(mcap,600_000_000)) / 600_000_000))
    narrative = 1 if any(w.lower() in ' '.join(item['news']).lower() for w in ['defense','ai','quantum','uranium','space','battery','drone','clinical']) else 0.55
    early_signal = round(58 + 32*narrative + 10*mcap_factor, 1)
    hype_risk = round(8 + (0 if mcap < 300_000_000 else 18) + (18 if mcap > 1_000_000_000 else 0), 1)
    risk_score = round(42 + (18 if mcap < 75_000_000 else 8) + (14 if 'Biotech' in item['sector'] or 'Hydrogen' in item['sector'] else 0), 1)
    gem = round(max(0, min(99, early_signal + 12*mcap_factor - 0.42*hype_risk - 0.12*risk_score)), 1)
    return mcap, src, conf, gem, early_signal, hype_risk, risk_score


def _ai_provider_config(provider: str):
    provider = (provider or '').lower()
    if provider == 'openai':
        return {'provider':'openai','key':OPENAI_API_KEY,'base':OPENAI_BASE_URL,'model':OPENAI_MODEL,'missing':'openai_not_configured'}
    if provider == 'deepseek':
        return {'provider':'deepseek','key':DEEPSEEK_API_KEY,'base':DEEPSEEK_BASE_URL,'model':DEEPSEEK_MODEL,'missing':'deepseek_not_configured'}
    return {'provider':provider or 'none','key':'','base':'','model':'','missing':'ai_provider_unknown'}

def _parse_ai_json(content: str):
    content = (content or '').strip()
    if content.startswith('```'):
        content = content.strip('`').strip()
        if content.lower().startswith('json'):
            content = content[4:].strip()
    start = content.find('{'); end = content.rfind('}')
    if start >= 0 and end > start:
        content = content[start:end+1]
    return json.loads(content)

def _call_ai_provider(provider: str, prompt: str, ticker: str):
    cfg = _ai_provider_config(provider)
    if not cfg['key']:
        return None, cfg['missing']
    headers = {'Authorization': f"Bearer {cfg['key']}", 'Content-Type':'application/json'}
    url = f"{cfg['base']}/chat/completions"
    payload = {
        'model': cfg['model'],
        'messages': [
            {'role':'system','content':'Je bent een nuchtere smallcap/smallcap investeringsanalist. Geen koopadvies. Antwoord uitsluitend als geldige JSON.'},
            {'role':'user','content':prompt}
        ],
        'temperature': 0.18,
        'max_tokens': 950
    }
    r = requests.post(url, headers=headers, json=payload, timeout=40)
    if r.status_code != 200:
        log(f'ai_http_error provider={cfg["provider"]} ticker={ticker} status={r.status_code} body={r.text[:200]}')
        return None, f'{cfg["provider"]}_http_{r.status_code}'
    content = r.json()['choices'][0]['message']['content']
    return _parse_ai_json(content), f'{cfg["provider"]}_{cfg["model"]}'

def ai_investor_analysis(item, scores):
    """Remote investor-AI layer. Runs through OpenAI/DeepSeek API, never locally on the 4GB VPS."""
    mcap, src, conf, gem, early, hype, risk = scores
    if not AI_ENABLED:
        return None, 'ai_disabled'
    prompt = f'''
Analyseer dit aandeel in makkelijke Nederlandse taal alsof je Stijn helpt researchen.
Geen koopadvies. Geen hype. Wees streng op dilution, pump/dump, liquiditeit, cash runway, reverse splits, offering history en market-cap betrouwbaarheid.

Ticker: {item['ticker']}
Naam: {item['name']}
Sector: {item['sector']}
Land/beurs: {item['country']} / {item['exchange']}
Market cap: {fmt_mcap(mcap)}
Market cap bron: {src}, confidence: {conf}
Scores: Gem {gem}/100, Early Signal {early}/100, Hype Risk {hype}/100, Risk {risk}/100
Nieuws/signalen: {'; '.join(item.get('news', []))}

Geef JSON met exact deze keys:
company_plain: 2 korte zinnen wat het bedrijf doet.
why_attractive: duidelijke uitleg waarom dit vroeg interessant kan zijn vóór hype/pump.
bull_case: concrete bull-case, zonder overdreven taal.
bear_case: concrete risico's, vooral dilution/cash/volume/scam-risk.
what_to_verify: checklist wat Stijn zelf moet controleren vóór hij geld riskeert.
verdict: één van Strong Gem Candidate, Watchlist, Too Risky, Avoid.
confidence: getal 0-100 voor hoe betrouwbaar deze analyse is op basis van de beschikbare data.
'''
    tried = []
    last_source = 'ai_not_configured'
    for provider in [AI_PROVIDER, AI_FALLBACK_PROVIDER]:
        if not provider or provider in tried:
            continue
        tried.append(provider)
        try:
            data, source = _call_ai_provider(provider, prompt, item['ticker'])
            if data:
                return data, source
            last_source = source
        except Exception as e:
            last_source = f'{provider}_error'
            log(f'ai_error provider={provider} ticker={item.get("ticker")} err={str(e)[:180]}')
    return None, last_source

def explain(item, scores):
    mcap, src, conf, gem, early, hype, risk = scores
    cap_class = classify_mcap(mcap)
    name, ticker, sector = item['name'], item['ticker'], item['sector']
    ai, ai_source = (ai_investor_analysis(item, scores) if (gem >= 84 and hype <= 45) else (None, 'ai_skipped_low_priority'))
    if ai:
        company_short = f"{ai.get('company_plain','').strip()}"
        why = f"{ai.get('why_attractive','').strip()}\n\nBull case: {ai.get('bull_case','').strip()}"
        catalyst = f"Wat controleren: {ai.get('what_to_verify','').strip()}\n\nSignalen: " + '; '.join(item['news'])
        risk_txt = f"Bear case: {ai.get('bear_case','').strip()}\n\nVerdict: {ai.get('verdict','Watchlist')}. Geen koopadvies. Market cap bron: {src}, confidence: {conf}. Analysebron: {ai_source}."
        return company_short, why, catalyst, risk_txt
    company_short = f"{name} ({ticker}) is een {cap_class} binnen {sector}. In simpele taal: dit is een vroeg research-aandeel, geen bewezen winnaar. De tool kijkt of er al vroege signalen zijn voordat de massa of social media er vol op zit."
    why = f"Aantrekkelijk door de combinatie van market cap {fmt_mcap(mcap)}, Early Signal {early}/100 en Hype Risk {hype}/100. Dat betekent: klein genoeg voor asymmetrische upside, wel signalen/catalysts zichtbaar, maar volgens deze scan nog niet extreem opgepompt. Dit is precies de fase die je zoekt: vóór de mogelijke pump, niet erna. Analysebron: rule_engine_fallback ({ai_source})."
    catalyst = "Mogelijke katalysatoren/signalen: " + '; '.join(item['news']) + ". Controleer of dit echt materieel nieuws is: contractwaarde, klantnaam, timing, omzetimpact en of het geen oude/kleine PR is."
    risk_txt = f"Risico in gewone taal: {sector}-microcaps kunnen hard stijgen, maar ook hard verwateren of crashen. Check vóór kopen altijd cash runway, dilution/offering history, schuld, omzetkwaliteit, volume/liquiditeit en recente filings. Market cap bron: {src}, confidence: {conf}. Geen koopadvies."
    return company_short, why, catalyst, risk_txt

def send_ntfy(gem):
    try:
        title = f"🚨 New Gem: {gem['ticker']} {gem['gem_score']:.1f}"
        msg = f"{gem['ticker']} · {gem['name']}\nMCap: {fmt_mcap(gem['mcap_usd'])}\nWaarom: {gem['why_attractive'][:250]}\nRisico: {gem['risk_plain'][:180]}\nhttp://51.195.102.180:8791"
        requests.post(f'https://ntfy.sh/{NTFY_TOPIC}', data=msg.encode('utf-8'), headers={'Title':title, 'Priority':'default'}, timeout=5)
        return True
    except Exception as e:
        log(f'ntfy_error {e}')
        return False

def run_scan(manual=False):
    if state['running']: return {'ok':False,'message':'scan draait al'}
    state['running'] = True; state['error'] = None
    alerts = 0; count = 0
    try:
        con = db(); now = datetime.now(timezone.utc).isoformat()
        for item in UNIVERSE:
            scores = score_item(item)
            mcap, src, conf, gem, early, hype, risk = scores
            company_short, why, catalyst, risk_txt = explain(item, scores)
            brokers = broker_availability(item['ticker'], item['exchange'])
            existing = con.execute('SELECT alerted FROM gems WHERE ticker=?',(item['ticker'],)).fetchone()
            should_alert = (not existing or existing['alerted']==0) and gem >= 84 and hype <= 35
            if should_alert:
                alerts += 1
            con.execute('''INSERT INTO gems(ticker,name,sector,country,exchange,mcap_usd,mcap_source,mcap_confidence,gem_score,early_signal,hype_risk,risk_score,company_short,why_attractive,risk_plain,catalyst_plain,broker_json,news_json,first_seen,last_seen,alerted)
              VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
              ON CONFLICT(ticker) DO UPDATE SET name=excluded.name,sector=excluded.sector,country=excluded.country,exchange=excluded.exchange,mcap_usd=excluded.mcap_usd,mcap_source=excluded.mcap_source,mcap_confidence=excluded.mcap_confidence,gem_score=excluded.gem_score,early_signal=excluded.early_signal,hype_risk=excluded.hype_risk,risk_score=excluded.risk_score,company_short=excluded.company_short,why_attractive=excluded.why_attractive,risk_plain=excluded.risk_plain,catalyst_plain=excluded.catalyst_plain,broker_json=excluded.broker_json,news_json=excluded.news_json,last_seen=excluded.last_seen,alerted=CASE WHEN gems.alerted=1 THEN 1 ELSE excluded.alerted END''',
              (item['ticker'],item['name'],item['sector'],item['country'],item['exchange'],mcap,src,conf,gem,early,hype,risk,company_short,why,risk_txt,catalyst,json.dumps(brokers),json.dumps(item['news']),now,now,1 if should_alert else 0))
            count += 1
        con.execute('INSERT INTO scan_runs(ts,count,alerts,note) VALUES(?,?,?,?)',(now,count,alerts,'manual' if manual else 'auto'))
        con.commit(); con.close()
        state['last_scan'] = now; state['last_alerts'] = alerts
        if alerts:
            con = db()
            for row in con.execute('SELECT * FROM gems WHERE alerted=1 ORDER BY gem_score DESC LIMIT 3').fetchall(): send_ntfy(dict(row))
            con.close()
        log(f'scan_complete count={count} alerts={alerts} manual={manual}')
        return {'ok':True,'count':count,'alerts':alerts}
    except Exception as e:
        state['error'] = str(e); log(f'scan_error {e}'); return {'ok':False,'error':str(e)}
    finally:
        state['running'] = False

def scheduler_loop():
    log(f'scheduler_started enabled={AUTO_SCAN_ENABLED} interval={SCAN_INTERVAL_MINUTES}')
    # run once shortly after start when db empty
    while True:
        try:
            if AUTO_SCAN_ENABLED:
                con = db(); n = con.execute('SELECT COUNT(*) c FROM gems').fetchone()['c']; con.close()
                if n == 0: run_scan(False)
                time.sleep(SCAN_INTERVAL_MINUTES*60)
                run_scan(False)
            else:
                time.sleep(60)
        except Exception as e:
            log(f'scheduler_error {e}'); time.sleep(60)

@app.on_event('startup')
def startup():
    threading.Thread(target=scheduler_loop, daemon=True).start()

@app.get('/api/ai/test')
def api_ai_test():
    cfg = _ai_provider_config(AI_PROVIDER)
    if not AI_ENABLED:
        return {'ok':False,'provider':AI_PROVIDER,'message':'AI_ENABLED=false'}
    if not cfg.get('key'):
        return {'ok':False,'provider':AI_PROVIDER,'message':cfg.get('missing')}
    try:
        prompt = 'Antwoord uitsluitend als JSON: {"ok": true, "message": "AI koppeling werkt"}'
        data, source = _call_ai_provider(AI_PROVIDER, prompt, 'TEST')
        return {'ok':True,'provider':AI_PROVIDER,'source':source,'response':data}
    except Exception as e:
        return {'ok':False,'provider':AI_PROVIDER,'message':str(e)[:200]}

@app.get('/api/status')
def api_status():
    con = db(); n = con.execute('SELECT COUNT(*) c FROM gems').fetchone()['c']; con.close()
    return {'version':APP_VERSION,'gems':n,'ntfy_topic':NTFY_TOPIC,'scan_interval_minutes':SCAN_INTERVAL_MINUTES,'auto_scan':AUTO_SCAN_ENABLED,'ai_enabled':AI_ENABLED,'ai_provider':AI_PROVIDER,'ai_fallback_provider':AI_FALLBACK_PROVIDER,'openai_configured':bool(OPENAI_API_KEY),'deepseek_configured':bool(DEEPSEEK_API_KEY),'ai_configured':bool(OPENAI_API_KEY or DEEPSEEK_API_KEY),'openai_model':OPENAI_MODEL,'deepseek_model':DEEPSEEK_MODEL,'ai_model':OPENAI_MODEL if AI_PROVIDER=='openai' else DEEPSEEK_MODEL,**state}

@app.get('/api/gems')
def api_gems():
    con = db(); rows = [dict(r) for r in con.execute('SELECT * FROM gems ORDER BY gem_score DESC, early_signal DESC').fetchall()]; con.close()
    for r in rows:
        r['broker'] = json.loads(r.pop('broker_json') or '{}'); r['news'] = json.loads(r.pop('news_json') or '[]')
    return rows

@app.post('/api/scan')
def api_scan():
    return run_scan(manual=True)

@app.get('/', response_class=HTMLResponse)
def index():
    return HTML

HTML = r'''<!doctype html><html lang="nl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Stijn-Tradifi-2026</title><style>
:root{--bg:#070b14;--panel:#0c1322;--panel2:#111a2c;--card:#121d31;--text:#f5f8ff;--soft:#dbe5f7;--muted:#93a2ba;--line:#253754;--gold:#ffd166;--green:#52e391;--red:#ff647c;--blue:#86b6ff;--purple:#c084fc}*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:radial-gradient(1000px 500px at 30% -10%,#243a63 0%,#0a101d 45%,#050812 100%);color:var(--text);font-family:Inter,system-ui,-apple-system,Segoe UI,sans-serif}.wrap{max-width:1180px;margin:0 auto;padding:18px 14px 70px}.hero{position:sticky;top:0;z-index:5;padding:16px 0 14px;background:linear-gradient(180deg,rgba(7,11,20,.96),rgba(7,11,20,.78));backdrop-filter:blur(18px);border-bottom:1px solid rgba(255,255,255,.07)}.heroIn{display:grid;grid-template-columns:1fr auto;gap:12px;align-items:center}.brand{display:flex;flex-direction:column;gap:4px}.eyebrow{font-size:12px;color:var(--gold);text-transform:uppercase;letter-spacing:.16em;font-weight:900}h1{margin:0;font-size:clamp(26px,5vw,52px);letter-spacing:-.055em;line-height:.95}.sub{color:var(--muted);font-size:15px;line-height:1.45}.actions{display:flex;gap:10px;flex-wrap:wrap;justify-content:flex-end}button{background:linear-gradient(135deg,#ffe08a,#ffbd4a);color:#111000;border:0;border-radius:16px;padding:13px 16px;font-weight:1000;font-size:15px;box-shadow:0 8px 30px rgba(255,209,102,.18)}.ghost{background:#142036;color:var(--text);border:1px solid var(--line);box-shadow:none}.dash{display:grid;grid-template-columns:repeat(5,1fr);gap:12px;margin:16px 0}.stat{background:linear-gradient(180deg,rgba(18,29,49,.96),rgba(10,16,28,.96));border:1px solid var(--line);border-radius:22px;padding:16px;min-height:92px}.stat b{font-size:24px;letter-spacing:-.03em}.stat div{margin-top:6px}.panel{background:linear-gradient(180deg,rgba(18,29,49,.88),rgba(8,13,24,.88));border:1px solid var(--line);border-radius:26px;padding:18px;margin:14px 0}.panel h2{margin:0 0 8px;font-size:24px;letter-spacing:-.04em}.list{display:grid;gap:16px}.gem{overflow:hidden;background:linear-gradient(180deg,rgba(18,29,49,.98),rgba(7,11,20,.98));border:1px solid var(--line);border-radius:28px}.gemHead{display:grid;grid-template-columns:1fr auto;gap:18px;padding:22px;border-bottom:1px solid rgba(255,255,255,.08)}.ticker{font-size:46px;font-weight:1000;letter-spacing:-.07em}.name{font-size:18px;color:var(--muted);line-height:1.35}.sector{font-size:19px;font-weight:900;margin:16px 0 10px}.score{font-size:48px;font-weight:1000;color:var(--gold);line-height:1}.mcap{display:flex;gap:10px;align-items:center;flex-wrap:wrap;font-size:28px;font-weight:1000}.source{font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:.13em;border:1px solid var(--line);border-radius:999px;padding:6px 9px}.tag{display:inline-flex;align-items:center;background:rgba(82,227,145,.12);color:var(--green);border:1px solid rgba(82,227,145,.35);border-radius:999px;padding:8px 12px;font-weight:900;margin-top:12px}.bars{padding:18px 22px;border-bottom:1px solid rgba(255,255,255,.08);display:grid;grid-template-columns:repeat(3,1fr);gap:12px}.barrow{background:rgba(6,9,20,.55);border:1px solid rgba(255,255,255,.06);border-radius:16px;padding:12px}.label{display:flex;justify-content:space-between;color:var(--muted);font-weight:800;margin-bottom:8px}.bar{height:10px;background:#050812;border-radius:99px;overflow:hidden}.fill{height:100%;background:linear-gradient(90deg,#6fa8ff,#ffd166)}.riskfill{background:linear-gradient(90deg,#b06cff,#ff647c)}.hypefill{background:linear-gradient(90deg,#ff647c,#ffd166)}.body{display:grid;grid-template-columns:1.2fr .8fr;gap:18px;padding:22px}.section{background:rgba(7,11,20,.35);border:1px solid rgba(255,255,255,.06);border-radius:22px;padding:16px}.section h3{margin:0 0 10px;font-size:20px}.section p{margin:0 0 16px;font-size:16.5px;line-height:1.58;color:var(--soft)}.broker{display:grid;gap:8px}.brokerline{display:grid;grid-template-columns:92px 1fr;gap:10px;padding:11px 0;border-bottom:1px solid rgba(255,255,255,.08)}.brokerline b{font-size:15px}.ok{color:var(--green);font-weight:900}.warn{color:var(--gold);font-weight:800}.bad{color:var(--red);font-weight:800}.muted{color:var(--muted)}small{display:block;margin-top:3px;line-height:1.35}ul{margin:8px 0 0;padding-left:20px;color:var(--soft);line-height:1.55}.aiPill{display:inline-flex;align-items:center;gap:8px;padding:8px 11px;border:1px solid var(--line);border-radius:999px;color:var(--muted);font-weight:800;font-size:12px}.dot{width:8px;height:8px;border-radius:99px;background:var(--red)}.dot.on{background:var(--green)}@media(max-width:850px){.heroIn{grid-template-columns:1fr}.actions{justify-content:flex-start}.dash{grid-template-columns:1fr 1fr}.bars{grid-template-columns:1fr}.body{grid-template-columns:1fr}.gemHead{grid-template-columns:1fr}.score{font-size:42px}.ticker{font-size:42px}.wrap{padding:10px 10px 50px}.stat{min-height:78px}.panel,.gem{border-radius:22px}.brokerline{grid-template-columns:84px 1fr}}
</style></head><body><div class="wrap"><div class="hero"><div class="heroIn"><div class="brand"><div class="eyebrow">Global Smallcap Gem Evidence Engine</div><h1>Stijn-Tradifi-2026</h1><div class="sub">Vindt vroege smallcap-kansen vóór de hype. Market cap live-first · live OpenAI/DeepSeek investor AI · broker API-ready.</div></div><div class="actions"><button onclick="scan()">Nieuwe scan</button><button class="ghost" onclick="load()">Vernieuwen</button></div></div></div><div class="dash"><div class="stat"><b id="count">0</b><div class="sub">Gems</div></div><div class="stat"><b id="last">...</b><div class="sub">Laatste scan</div></div><div class="stat"><b id="interval">...</b><div class="sub">Auto scan</div></div><div class="stat"><b id="topic">...</b><div class="sub">ntfy</div></div><div class="stat"><b id="ai">...</b><div class="sub">AI status</div></div></div><div class="panel"><h2>Top Gems Ranking</h2><div class="sub" id="status">Laden...</div><br><span class="aiPill"><span id="aiDot" class="dot"></span><span id="aiLine">AI laden...</span></span></div><div class="list" id="list"></div></div><script>
function money(v){if(!v)return 'Onbekend'; if(v>=1e9)return '$'+(v/1e9).toFixed(2)+'B'; return '$'+(v/1e6).toFixed(1)+'M'}
function brokerStatus(b){let cls='muted'; if(b.status==='verified')cls='ok'; else if(['api_error','not_found'].includes(b.status))cls='bad'; else if(['not_configured','planned','unsupported'].includes(b.status))cls='warn'; return `<span class="${cls}">${b.label||b.status}${b.route?' · '+b.route:''}</span><small class="muted">${b.detail||''}</small>`}
function bar(label,val,type=''){return `<div class="barrow"><div class="label"><span>${label}</span><span>${val}</span></div><div class="bar"><div class="fill ${type}" style="width:${Math.max(0,Math.min(100,val))}%"></div></div></div>`}
async function load(){let s=await fetch('/api/status').then(r=>r.json()); document.getElementById('count').textContent=s.gems; document.getElementById('topic').textContent=s.ntfy_topic; document.getElementById('interval').textContent='elk '+s.scan_interval_minutes+' min'; document.getElementById('last').textContent=s.last_scan?new Date(s.last_scan).toLocaleTimeString():'nog geen'; document.getElementById('ai').textContent=s.ai_configured?(s.ai_provider==='openai'?'OpenAI':'DeepSeek'):'regels'; document.getElementById('aiDot').className='dot '+(s.ai_configured?'on':''); document.getElementById('aiLine').textContent=s.ai_configured?`${s.ai_provider==='openai'?'OpenAI':'DeepSeek'} actief · ${s.ai_model}`:'AI nog niet gekoppeld · rule-engine uitleg actief'; document.getElementById('status').textContent=(s.running?'Scan draait...':'running: nee')+' · nieuwe alerts: '+(s.last_alerts||0)+' · versie '+s.version; let gems=await fetch('/api/gems').then(r=>r.json()); render(gems)}
async function scan(){document.getElementById('status').textContent='Scan draait... live market cap + broker/API + AI kunnen even duren.'; await fetch('/api/scan',{method:'POST'}); await load()}
function render(gems){let root=document.getElementById('list'); if(!gems.length){root.innerHTML='<div class="panel"><b>Nog geen scan.</b><div class="sub">Klik op Nieuwe scan.</div></div>';return} root.innerHTML=gems.map(g=>`<div class="gem"><div class="gemHead"><div><div class="ticker">${g.ticker}</div><div class="name">${g.name}<br>${g.country} · ${g.exchange}</div><div class="sector">${g.sector}</div><div class="mcap">${money(g.mcap_usd)} <span class="source">${g.mcap_source} · ${g.mcap_confidence}</span></div><span class="tag">${g.gem_score>=84?'Strong early gem candidate':'Watchlist candidate'}</span></div><div class="score">${Number(g.gem_score).toFixed(1)}</div></div><div class="bars">${bar('Early Signal',g.early_signal)}${bar('Hype Risk',g.hype_risk,'hypefill')}${bar('Risk Score',g.risk_score,'riskfill')}</div><div class="body"><div class="section"><h3>Wat doet dit bedrijf?</h3><p>${g.company_short}</p><h3>Waarom aantrekkelijk?</h3><p>${g.why_attractive}</p><h3>Katalysator / wat controleren?</h3><p>${g.catalyst_plain}</p><h3>Risico in makkelijke taal</h3><p>${g.risk_plain}</p></div><div class="section"><h3>Brokerroute Nederland</h3><div class="broker"><div class="brokerline"><b>IBKR</b><div>${brokerStatus(g.broker.ibkr||{})}</div></div><div class="brokerline"><b>Saxo</b><div>${brokerStatus(g.broker.saxo||{})}</div></div><div class="brokerline"><b>DEGIRO</b><div>${brokerStatus(g.broker.degiro||{})}</div></div><div class="brokerline"><b>Trading 212</b><div>${brokerStatus(g.broker.trading212||{})}</div></div></div><h3 style="margin-top:18px">Nieuws/signalen</h3><ul>${(g.news||[]).map(n=>'<li>'+n+'</li>').join('')}</ul></div></div></div>`).join('')}
load(); setInterval(load,30000)
</script></body></html>'''
