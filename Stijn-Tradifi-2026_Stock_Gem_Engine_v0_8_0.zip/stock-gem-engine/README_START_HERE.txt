Stijn-Tradifi-2026 Stock Gem Engine v0.8.0

Nieuw:
- Echte OpenAI API-koppeling via .env.
- DeepSeek blijft fallback.
- /api/ai/test test de actieve AI-provider.
- Investor AI schrijft: wat doet het bedrijf, waarom aantrekkelijk, bull case, bear case, checklist, verdict.
- Dashboard toont AI-status en blijft clean/2026.

OpenAI key veilig instellen:
sudo nano /home/ubuntu/stock-gem-engine/.env

Zet daarin:
AI_ENABLED=true
AI_PROVIDER=openai
OPENAI_API_KEY=sk-proj-...
OPENAI_MODEL=gpt-4.1-mini

Daarna:
sudo systemctl restart stock-gem.service
curl http://127.0.0.1:8791/api/ai/test

Plak API-keys nooit in chat of screenshots.
