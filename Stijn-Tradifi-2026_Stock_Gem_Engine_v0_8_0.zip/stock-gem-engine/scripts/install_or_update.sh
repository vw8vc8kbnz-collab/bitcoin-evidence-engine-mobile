#!/usr/bin/env bash
set -euo pipefail
APP_DIR="/home/ubuntu/stock-gem-engine"
SRC_DIR="$(cd "$(dirname "$0")/.." && pwd)"
SERVICE="stock-gem.service"
PYTHON_BIN="python3"
if command -v python3.12 >/dev/null 2>&1; then PYTHON_BIN="python3.12"; fi
sudo mkdir -p "$APP_DIR"
sudo rsync -a --delete --exclude '.venv' --exclude 'data' --exclude 'logs' "$SRC_DIR/" "$APP_DIR/"
sudo mkdir -p "$APP_DIR/data" "$APP_DIR/logs"
sudo touch "$APP_DIR/logs/app.log"
sudo chown -R ubuntu:ubuntu "$APP_DIR"
sudo chmod -R u+rwX,g+rwX "$APP_DIR/data" "$APP_DIR/logs"
cd "$APP_DIR"
if [ ! -f .env ]; then cp .env.example .env; fi
if [ ! -d .venv ]; then "$PYTHON_BIN" -m venv .venv; fi
.venv/bin/python -m pip install --upgrade pip wheel setuptools
.venv/bin/python -m pip install --only-binary=:all: -r requirements.txt
sudo tee /etc/systemd/system/$SERVICE >/dev/null <<EOF
[Unit]
Description=Stock Gem Evidence Engine
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=$APP_DIR
Environment=PYTHONUNBUFFERED=1
ExecStart=$APP_DIR/.venv/bin/python -m uvicorn app.main:app --host 0.0.0.0 --port 8791
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF
sudo systemctl daemon-reload
sudo systemctl enable $SERVICE
sudo systemctl restart $SERVICE
sleep 2
systemctl status $SERVICE --no-pager || true
echo "Klaar: http://SERVER-IP:8791"
echo "Logs: tail -n 100 $APP_DIR/logs/app.log"
