# FIX660R8 release notes

## R9RC3 — kant-en-klare installatie en disaster recovery

R9RC3 voegt drie strikt gescheiden installatiemodi toe: de bestaande
checksumgeverifieerde upgrade, een expliciete orphan-recovery voor een verdwenen
release met behouden externe state, en bootstrap vanaf een gevalideerde
versleutelde migratiebundle op een schone Debian/Ubuntu-server. Recovery maakt
na service-stop en vóór de codeswitch een volledige statecheckpoint met
SHA-256. De clean-serverketen gebruikt OpenPGP/AES-256, een per-bestandmanifest
en veilige extractie zonder links, speciale bestanden of padtraversal. De
R9RC1-applicatiecomponent zelf blijft ongewijzigd. Zie
`R9RC3_TURNKEY_INSTALL_DISASTER_RECOVERY_CHECKPOINT.md`.

Exact R9RC3 vereist nog de echte VPS-recovery, een wegwerpbare clean-serverproef,
Chromium/WebKit en iPhone Safari; productie blijft NO_GO.

## R9RC2 — read-only artifactpreflight-portabiliteit

R9RC2 repareert uitsluitend de negatieve release-identiteitfixtures die na een
standaard `unzip` terecht alleen-lezen waren en daardoor op de VPS niet hun
eigen tijdelijke kopie konden muteren. De test maakt nu alleen dat ene private
fixturebestand `0600`; runtime- en klantgedrag zijn ongewijzigd. R9RC1 is na de
fail-closed VPS-stop niet gedeployed en wordt niet stilzwijgend overschreven.

Exact R9RC2 moet opnieuw door bronpreflight, standaard-unzip artifactpreflight,
VPS-deploy, Chromium/WebKit en echte iPhone Safari. Productie blijft NO_GO.

## R9RC1 — professionele HTML/Python-architectuurafronding

R9RC1 maakt Tool A tot een markup-only shell met deterministische externe CSS-
en JavaScriptbundles, splitst de klassieke runtime in begrensde canonieke
bronnen en maakt `server_py.py` een 22-regelige import/CLI-boundary. De live
runtime is verdeeld over expliciete domein-, HTTP-, worker-, startup- en
servicecompositiemodules. Klant-/secretstate gebruikt `0700`/`0600`, logs en
indexen hebben afgedwongen rechten en Bearer-/PII-redactie is aangescherpt.

De actuele interne matrix is groen (29 suites, 280 tests, 0 failures, 0 skips),
maar de kandidaat blijft NO_GO totdat exact R9RC1 extern in Chromium, WebKit,
op VPS en op echte iPhone Safari is bewezen. Zie
`R9RC1_PROFESSIONAL_ARCHITECTURE_COMPLETION_CHECKPOINT.md` en
`R9RC1_EXTERNAL_AUDIT_REPORT.md`.

## R9O9 — externe-audit security- en privacyremediation

R9O9 sluit de gevonden credentialbron-, plaintext-, password-workfactor-,
IP-log-, actieve-logretentie-, Nginx-logretentie-, rate-limit-cap-, dubbele
Python-owner- en Admin-JavaScript ownershipbevindingen. De volledige technische
scope en resterende NO-GO-poorten staan in
`R9O9_EXTERNAL_AUDIT_SECURITY_PRIVACY_REMEDIATION_CHECKPOINT.md`.

## R9H-5 native materiaalkaart

- `app/tool-a/components/material-card.js` bezit nu het kaartmodel, de exacte
  materiaalkaartmarkup, selectieklik en defecte-afbeeldingfallback.
- `decor_library.js` delegeert kaartweergave en gridbinding via twee frozen
  foundationmethoden; filters, zoekindex, geselecteerde samenvatting en
  materiaalstate blijven bij hun bestaande eigenaar.
- De twee representatieve kaartfixtures en alle 19.784 decor-CSS-bytes blijven
  bytegelijk aan R9H-4; Hout/Overig blijft zichtbaar Fineer.
- De native architectuurgate bevat nu 14 modules, vijf DOM-/eventcomponenten,
  twee netwerkowners, nul storageowners en één compatibilityglobal.
- Dit is R9H 5/10 en geen productie-GO. WebKit en productie-identieke externe
  gates blijven `DEFERRED NO-GO`.

## R9H-4 native wizardfootercomponent

- De gedeelde wizardfooter heeft nu één native DOM-/eventeigenaar in
  `app/tool-a/components/footer.js`.
- Vier oude footer-runtimes en hun globals zijn verwijderd; tijdelijke
  aanroepplaatsen delegeren via de enige frozen `ToolAR9Foundation`-grens.
- Vijfstapsbeslissingen, navigatieguards, klantvalidatie, add/editstatus,
  overzichtsterugkeer en gecontroleerde plaatsing in de mobiele panelendrawer
  zijn door de component overgenomen.
- De 1.127 bytes vaste footermarkup en 14 complete CSS-blokken van samen
  139.538 bytes zijn gelijk aan R9H-3 en cryptografisch vergrendeld.
- De native architectuurgate bevat nu 13 modules, vier DOM-componenten, twee
  netwerkowners, nul storageowners en één frozen compatibilityglobal.
- Dit is R9H 4/10 en geen productie-GO. WebKit en productie-identieke externe
  gates blijven `DEFERRED NO-GO`.

## R9H-2 native progress-overlaycomponent

- De grote optimalisatie-overlay en de kleine fail-safe voortgangsbadge hebben
  nu één native DOM-eigenaar in `app/tool-a/components/progress-overlay.js`.
- De oude functienamen zijn uitsluitend dunne tijdelijke adapters; de inline
  applicatielaag maakt geen progress-DOM, markup of dynamische stijl meer.
- Procentafronding, 0–100-begrenzing, de minimale 6%-balk, ringgradient,
  standaardtekst, scroll-lock en herstel van de eerdere body-overflow blijven
  exact gelijk.
- De 3.866 stijlbytes en 1.000 markupbytes zijn cryptografisch gebonden aan het
  afgesloten R9H-1-checkpoint.
- De native architectuurgate onderscheidt nu twee beoordeelde DOM-componenten,
  twee netwerkowners, nul storageowners en één frozen compatibilityglobal.
- Dit is R9H 2/10 en geen productie-GO. WebKit en productie-identieke externe
  gates blijven `DEFERRED NO-GO`.

## R9H-1 native dialog-/alertcomponent

- De vaste alert/confirm-overlay en de harde nooddialog hebben nu één native
  DOM-/eventeigenaar in `app/tool-a/components/dialog.js`.
- De oude globale alertnamen delegeren tijdelijk naar deze eigenaar en houden
  geen eigen dialogmarkup, listeners, focus- of callbacklogica meer bij.
- Tekstpartitionering, knoppen, backdrop-/Escapegedrag, 120 ms-sluitvertraging,
  focus, callbackvolgorde en de visuele hard-fallbackkaart blijven gelijk.
- De native architectuurgate onderscheidt nu expliciet één DOM-/eventowner en
  twee netwerkowners; storage en extra globale publicatie blijven verboden.
- Dit is R9H 1/10 en geen productie-GO. WebKit en productie-identieke externe
  gates blijven `DEFERRED NO-GO`.

## R9G-8 — ownershipcleanup en R9G-complete grens

- Het inactieve `toolA_final_submit_bridge.js`-compatibilitybestand is verwijderd
  en staat niet meer in de twee fail-closed publieke static-allowlists.
- `tool-a/api/jobs.js` is aantoonbaar de enige productie-eigenaar van
  `POST /api/jobs` en `GET /api/jobs/{jobId}/status`; `tool-a/api/requests.js`
  blijft de enige eigenaar van `POST /api/submit_config`.
- Compute en definitieve submit hebben ieder exact één fysieke clickadapter;
  één klik veroorzaakt maximaal één actie en één bijbehorend request.
- De tijdelijke, frozen `ToolAR9Foundation`-API is exact vastgelegd op veertien
  keys en publiceert geen tweede global, DOM-, storage- of netwerkeigenaar.
- Alle negen native modules blijven pure grenzen; uitsluitend de twee expliciete
  API-modules mogen netwerk-I/O bezitten.
- Optimizer, DXF, prijsregels, panelcontract, jobpayloadbuilder, catalogus- en
  serverroutegedrag zijn ongewijzigd en fail-closed beschermd.
- R9G is hiermee 8/8 compleet. Dit is geen productie-GO; echte WebKit- en
  productie-infragates blijven deferred.

## R9G-7 — enkele definitieve submit-/thank-you-eigenaar

- Nieuwe native `tool-a/api/requests.js` met `idle/submitting/committed/failed`.
- Exact één `POST /api/submit_config`; dubbeltikken tijdens inflight veroorzaken
  geen tweede request.
- Thank-you verschijnt uitsluitend na een niet-lege committed `requestId`.
- HTTP-/netwerk-/JSON-fouten herstellen de verzendknop en houden retry mogelijk.
- De vroege document-capture is de enige fysieke Safari-clickadapter; twee oude
  target/fallbacklisteners en het geladen legacy bridgepad zijn retired.
- Nieuwe configuratie wist ook de native submitstate.
- Optimizer, DXF, prijsregels, jobpayloadbuilder en publieke routecontracten zijn
  functioneel beschermd gebleven.
- Dit is R9G 7/8 en geen productie-GO; WebKit en productie-infra blijven deferred.

## R8Z productiehardening zonder algoritmewijziging

- Laat de optimizer/nestingstrategieën en de vaste 200-/250-paneelplacements
  byte-semantisch ongemoeid.
- Laat deploy op één effectieve CPU één worker kiezen en vanaf twee CPU's twee;
  hogere expliciete tiers zijn aan een conservatieve CPU-cap en een live
  loadbesluit gebonden. Acht FIFO-wachtplaatsen en twee jobs per IP blijven vast.
- Reserveert cumulatief bytes en inodes voor actieve én wachtende jobs en geeft
  deze reserveringen idempotent vrij bij succes, crash, annulering, timeout en
  threadstartfout.
- Start optimizerprocessen in een eigen POSIX-procesgroep en beëindigt bij cancel
  of timeout ook kinderen/kleinkinderen met TERM→KILL→reap. Naast 300 seconden
  per materiaal geldt 900 seconden voor de complete materiaalfamilie.
- Archiveert request, gekoppelde niet-gedeelde jobs en idempotencyclaim met een
  vóór de eerste move duurzaam geschreven journaal. Gewone fouten rollen terug;
  na procesuitval/stroomverlies wordt de voorbereide transactie bij startup
  idempotent vooruit afgerond. Ontbrekende gekoppelde jobs worden zichtbaar in
  verplichte metadata en blokkeren PII-retentie niet onbeperkt.
- Verwijdert PII uit de requestindex en begrenst catalogusstages/-historie,
  orphan media/queue/claims, oude drafts, geroteerde logs en lokale backups op
  tijd/aantal/volume. Een backup wordt vóór atomaire publicatie volledig herlezen.
- Begrensd installeronderhoud draait onder één globale deploylock, hercontroleert
  de current-pointer direct vóór verwijdering, bewaart actieve/vorige immutable
  release en een kleine configgeschiedenis en verwijdert geen onbekende/symlinkentries.
- Verwijdert de muterende Admin-GET-route, houdt details van publieke readiness
  af, redigeert volledige auth-/cookieheaders, blokkeert ntfy-redirects en stuurt
  clientlogs met het bestaande jobbearercontract.
- Productie-Nginx gebruikt een vaste domeinredirect, reject-default vhosts,
  schone proxy-headerhashconfig en HSTS zonder onbewezen `includeSubDomains`.
- Eén globale catalogusimagesync reserveert vooraf bytes/inodes en geeft die bij
  ieder succes- en foutpad idempotent vrij.
- Nieuwe gates dekken security/privacy, crash-herstelbare archive-/retentie-/backup-
  paden, deployhistory, runtime-revisiebewijs, procesgroepkill, familydeadline en
  twee actieve workers.

## R8Y Hout/Overig heet zichtbaar Fineer

- Toont de interne houtmerkwaarde `Overig` als `Fineer` in de merkfilter en op
  alle materiaalpresentaties in Tool A.
- Voegt de zichtbare term aan de zoekindex toe, zodat zoeken op `fineer` dezelfde
  gefineerde platen teruggeeft.
- Laat de autoritatieve CSV-waarde en filterstate ongemoeid; er is dus geen
  catalogusmigratie en een volgende CSV-publicatie draait de wijziging niet terug.

## R8X herkenbare DXF-zaagplaatnamen in Admin

- Toont en downloadt iedere zaagplaat als
  `klantnaam__decornaam__001.dxf`, gevolgd door `002`, `003`, enzovoort.
- Gebruikt één centrale naamresolver voor Admin-orderdetails, technische jobs,
  losse sealed-filedownloads, de legacy sheetroute en beide ZIP-exports.
- Houdt materiaalcodes als collision-safe ZIP-map, terwijl de DXF zelf de voor
  de werkplaats herkenbare klant- en decornaam draagt.
- Hernoemt geen optimizeroutput op schijf: finalization manifests, hashes,
  plaatsingen, pricing en het nestingalgoritme blijven exact onaangeraakt.
- Werkt door de dynamische Adminprojectie ook voor reeds afgeronde R8-jobs.

## R8W multi-materiaalnerf en werkelijk lege nieuwe configuratie

- Herstelt de fout waarbij de frontend productiecodes per materiaal opnieuw bij
  `G001` liet beginnen. De server behandelt een GrainGroup terecht als
  job-globaal en zag daardoor twee geldige materiaalgroepen als één gemengde
  groep. R8W kent `G001`, `G002`, … nu eenmaal deterministisch toe over de
  volledige job, terwijl de lokale groepnamen per materiaal mogen overlappen.
- De frontend controleert vóór de request expliciet dat ieder groepslid bij het
  groepsmateriaal hoort en, wanneer bekend, dezelfde dikte heeft. Echte
  materiaal- of diktemenging blijft dus fail-closed.
- `Nieuwe configuratie starten` wist de klant uit DOM-controls, live globals,
  checkoutstate, snapshots en notitie. Een eenmalige pre-hydrationguard herhaalt
  dit na Safari `pageshow`, zodat browser form restoration oude persoonsgegevens
  niet opnieuw in de verse configuratie kan injecteren.
- Optimizer, nestingstrategie, plaatsingen, prijsberekening en serverfinalisatie
  zijn niet gewijzigd.

## R8V nerfcontrole op productiegegevens

- Verwijdert de foutieve afhankelijkheid van een zichtbaar canvas van minimaal
  200×200 pixels uit de route vóór optimalisatie. Een ingeklapte, losgekoppelde
  of nog niet geschilderde iOS-drawer maakt een geldige groep niet langer ongeldig.
- De controle gebruikt nu uitsluitend de autoritatieve groepsinhoud: minimaal
  twee panelen, iedere paneelreferentie bestaat, iedere werkelijke breedte is
  geldig en alle breedtes zijn exact gelijk binnen 0,001 mm.
- De groepssignature blijft gekoppeld aan de werkelijke paneelvolgorde,
  afmetingen en materiaal. Een echte datamutatie wordt dus nog steeds vóór
  optimalisatie en vóór definitieve verzending opnieuw gecontroleerd.
- De Grain Studio-preview blijft volledig beschikbaar als visuele controle, maar
  viewport- en renderlifecycle zijn geen productiedata en blokkeren geen job.
- Optimizer, nestingstrategie, plaatsingen, prijsberekening en serverfinalisatie
  zijn niet gewijzigd.

## R8U submit commit → Admin → bedankscherm

- Herstelt de verborgen late nerf-previewgate die pas na een succesvolle
  optimalisatie kon ingrijpen en de klant zonder aanvraag terug naar stap 2 stuurde.
- Iedere vereiste, zichtbaar gerenderde nerfpreview wordt nu vóór `/api/jobs`
  geattesteerd voor de exacte groepsinhoud; de optimalisatie start niet zolang die
  productiecontrole ontbreekt.
- De finale submit accepteert uitsluitend de attestation van dezelfde parent-job en
  dezelfde nerfgroepsignatures. Een door iOS ingeklapte/losgekoppelde previewdrawer
  kan een reeds gecontroleerde job daardoor niet meer vals blokkeren.
- Een echte serverbevestiging met `requestId` is verplicht voordat Tool A de aanvraag
  als verzonden markeert en het bedanktscherm opent.
- Een ontbrekende preview leidt voortaan met uitleg naar Doorlopende nerf; nooit meer
  stilletjes naar Panelen en nooit met de indruk dat Admin de aanvraag ontving.

## R8T live browser-reparatie van mandje en checkout

- Een echte mobiele Chromium-doorloop tegen de publieke staging reproduceerde
  zowel het niet-werkende prullenbakje als de lege klantkaart en geblokkeerde CTA.
- Het prullenbakje riep een aanwezige wrapper zonder gekoppelde raw hook aan; de
  module gebruikt nu eerst de werkelijk beschikbare canonieke
  `removeMaterialBatch`-transactie.
- De oude enkel-materiaal-sheet wordt niet meer automatisch over `Jouw
  materialen` geopend en onderschept dus geen eerste tik meer.
- De definitieve submitbrug rendert klantgegevens rechtstreeks uit de bestaande
  live/snapshot-state en maakt de knop alleen actief bij prijs, panelen en e-mail.
  Daardoor is de prijsweergave niet meer afhankelijk van onbereikbare functies
  in een oudere JavaScript-scope.
- De mobiele footertegels zijn in de browsertest exact 50/50 en 58 px hoog; de
  footerrail heeft geen achtergrond, blur, border of schaduw.
- Onveilige live verzending is in de browsertest onderschept; de eindbrug is
  aanvullend getest op exact één verzendaanroep.

## R8S checkout- en verwijderroute daadwerkelijk vrijgemaakt

- Live bewijs toonde dat R8R byte-exact actief was; cache en deployment waren
  daarmee uitgesloten. De resterende verzendfout zat in een oudere
  prijs-overlaywrapper die de correct gevonden eindknop na het tonen alsnog als
  native `disabled` markeerde. iOS levert voor zo'n knop geen klikevent. R8S
  houdt de CTA daarom altijd event-capable; alleen de canonieke submitfunctie
  vergrendelt hem kort tijdens de echte POST.
- Klantdata wordt niet meer als één gedeeltelijk object gekozen. Beschikbare
  live state en berekeningssnapshots worden per veld samengevoegd, waarbij
  niet-lege berekeningswaarden autoritatief blijven. Een oude snapshot met
  bijvoorbeeld alleen e-mail kan naam, telefoon en adres niet meer verbergen.
- Het mobiele prullenbakje gebruikt de bestaande centrale materiaaltransactie.
  De bijbehorende bevestigingsdialoog staat nu aantoonbaar boven de mobiele
  drawer; materiaal en gekoppelde panelen worden daarna exact eenmaal verwijderd.
- Footerrails gebruiken geen achtergrond, blur, outline, pseudo-element of
  buiten-schaduw meer. De twee afgeronde acties blijven zelf zichtbaar.
- Optimizer, nestingstrategie, prijsformules en serverfinalisatie zijn niet
  gewijzigd.

## R8R eerste event-eigenaar voor Safari

- De live R8Q-release en Nginx-assets bleken byte-exact actief, terwijl de drie
  gemelde interacties toch niet veranderden. De resterende oorzaak zat in de
  historische eventvolgorde: oudere document- en targethandlers konden een tik
  verwerken voordat de later geladen R8Q-knopbinding eigenaar werd.
- R8R registreert daarom vóór alle legacy-applicatiescripts één document-capture
  eigenaar. Die resolveert de pas later gemaakte eindknop op het moment van de
  echte tik, stopt alle oudere submitroutes en roept precies één canonieke
  submitfunctie aan. De test voert nadrukkelijk de eerste geregistreerde
  documentlistener uit, niet een los geïsoleerd knopfragment.
- Dezelfde eerste eventlaag legt bij invoer én vóór berekenen alle zichtbare
  klantvelden vast. Daardoor worden ook Safari-autofillvelden zonder events
  meegenomen en kunnen latere verborgen of lege controls de berekeningssnapshot
  niet overschrijven.
- Mobiele prullenbak-, bevestig- en annuleertikken lopen eveneens via deze eerste
  eigenaar naar de ene basketmutatie. Oude listeners krijgen dezelfde fysieke
  tik niet meer en kunnen de actie dus niet stil absorberen.
- De rechthoekige footer-/modalrails zijn mobiel volledig transparant gemaakt;
  ook de beide losse footertegels hebben geen buiten-schaduw meer. Desktop,
  pricing en het nestingalgoritme zijn ongewijzigd.

## R8Q checkout bij de wortel hersteld

- De hoofd-JavaScript werd historisch uitgevoerd voordat de prijsoverlay in de
  HTML bestond. Daardoor bewaarde de verzendfunctie permanent `null` als knop;
  bij een tik werd de interne submitvergrendeling gezet en crashte de functie
  nog vóór `/api/submit_config`. R8Q resolveert de knop pas bij de echte tik en
  geeft één dynamisch aangemaakte knop aan precies één canonieke eigenaar.
- De klantinvoer wordt vóór de berekening als één onveranderlijke snapshot
  vastgelegd en voedt daarna jobinput, prijscontrole en finale submit. Safari-
  autofill zonder `input`-event kan niet meer door nog lege state over de zichtbare
  velden heen worden geschreven. De server bewaart dezelfde volledige snapshot
  in de finalized job en herstelt ontbrekende laatste browservelden daaruit,
  voordat precies één Admin-/salesrequest duurzaam wordt aangemaakt.
- De finale browserrequest bevat bewust alleen `jobId`, `parentJobId`, klant en
  notitie. Panelen, prijs en quote komen uitsluitend uit de reeds verzegelde
  serverjob; concurrerende clientkopieën kunnen Admin daardoor niet vervuilen.
- Het prullenbakje in `Jouw materialen` gebruikt rechtstreeks dezelfde bevestigde
  materiaalmutatie als desktop. Materiaal zonder panelen verdwijnt onmiddellijk;
  bij gekoppelde panelen verschijnt in dezelfde sheet een duidelijke bevestiging.
- De grijze vierkante waas rond mobiele actiegebieden kwam uit een oude globale
  gradient/shadow-regel voor footers en modals. De mobiele materiaal-, klant-,
  overzichts- en previewrails hebben nu een effen witte achtergrond zonder
  backdrop-filter of vierkante buiten-schaduw. Desktop en het nestingalgoritme
  zijn niet gewijzigd.

## R8P compacte mobiele materiaalbalk en één betrouwbare verzendroute

- De mobiele materiaalstap heeft voortaan één lage onderbalk met twee exact even
  brede en hoge tegels: `Jouw materiaal/materialen` en `Volgende stap`. Eerdere
  mobiele CSS die de vervolgknop alsnog over de volle rij liet lopen wordt door
  het R8P-contract expliciet overschreven; desktop behoudt de rechterkolom.
- `Jouw materialen` opent als één rustige bottom sheet met de bestaande centrale
  materiaalstate. Bij verwijderen sluit die sheet eerst volledig en opent daarna
  pas de gedeelde bevestigingsdialoog. Daardoor staat de dialoog op iOS niet meer
  onzichtbaar achter de nog sluitende drawer en bereikt de bevestiging dezelfde
  mutation als de desktopactie.
- De finale knop werd niet door pricing of de server geblokkeerd: een oude
  capture-listener op de knop stopte het event al voordat de canonieke
  verzendhandler het kon ontvangen. R8P vangt één fysieke tik vóór die retired
  listener af en leidt hem precies eenmaal naar één benoemde submitfunctie. Een
  lopende aanvraag wordt zichtbaar vergrendeld, een fout maakt de knop opnieuw
  bruikbaar en een succesvolle aanvraag kan niet dubbel worden verzonden.
- Regressieproeven simuleren de mobiele verwijderactie en de volledige
  document-capture klikroute. Het optimizer-/nestingalgoritme, de berekende prijs
  en de serverfinalisatie zijn niet gewijzigd.

## R8O één mobiel mandje en herstelbare eindcontrole

- Op mobiel werd naast het nieuwe uitschuifbare materialenmandje ook de oude
  single-material onderbalk getoond. R8O onderdrukt die oude balk zodra de
  multi-material basket actief is; het mandje blijft de enige materiaalweergave
  en bevat zelf de actie om naar Panelen te gaan.
- Een geverifieerde eindprijs kon de knop `Akkoord en aanvraag verzenden`
  vervolgens opnieuw uitschakelen wanneer klantgegevens in state nog niet
  compleet leken. Een uitgeschakelde knop kon geen uitleg of herstelpad tonen.
  De CTA blijft bij een definitieve serverprijs nu bedienbaar en stuurt bij
  werkelijk ontbrekende gegevens gericht terug naar Stap 4 met veldvalidatie.
- De prijsweergave leest voortaan uitsluitend de vóór optimalisatie vastgelegde
  klantstate. Verborgen, nog niet gehydrateerde invoervelden kunnen die gegevens
  niet meer tijdens het renderen wissen. Ook een ontbrekende actuele
  nerf-preview ontgrendelt de prijslaag en brengt de klant terug naar de juiste
  herstelstap. Het optimizer-/nestingalgoritme is niet gewijzigd.

## R8N stabiele stapovergang en mobiel materialenmandje

- De asynchrone opstartloader voor ingebouwde DXF-templates zette na afronding
  onvoorwaardelijk opnieuw Stap 1 actief. Wie op mobiel snel een materiaal koos
  en doorging, kon daardoor enkele ogenblikken later onverwacht uit Stap 2 worden
  teruggezet. R8N commit de beginstap vóór het laden en ververst na afloop alleen
  de bediening van de stap die de klant op dat moment daadwerkelijk open heeft.
- De mobiele onderbalk toont naast Verder een compact materialenblok met de echte
  actieve materiaalafbeelding en het aantal gekozen materialen. Een tik opent een
  bottom sheet met alle materialen in het mandje, naam, dikte, plaatafmeting,
  actieve selectie en de bestaande veilige verwijderactie.
- De bottom sheet gebruikt dezelfde `materialBatches`, actieve-materiaalselectie,
  swatchrenderer en verwijderlogica als de desktopkolom. Er ontstaat dus geen
  tweede mobiele state die kan afwijken van prijsberekening of productie-input.
  Escape, backdrop, sluitknop en de greep sluiten de sheet; desktop blijft
  functioneel en visueel ongewijzigd.

## R8M stabiele optimalisatie-start, afronding en multi-klantwachtrij

- Het nesting-/plaatsingsalgoritme is inhoudelijk niet gewijzigd. De exacte
  productieplacements voor de vaste 200- en 250-panelenfixtures zijn nu met een
  semantische SHA-256-fingerprint vergrendeld, zodat iedere toekomstige
  performancewijziging die één positie verandert de releasegate laat falen.
- Tool A animeerde iedere serverprocent met een afzonderlijke JavaScript-wachttijd.
  Een normale sprong kon daardoor circa 1,7 seconde kosten en een direct afgeronde
  job bleef kunstmatig bijna één seconde op 100% staan. De UI verwerkt nu iedere
  serverstand in één update; de bestaande CSS-transitie verzorgt alleen de visuele
  beweging.
- De DONE-status bevatte de definitieve serverprijs al, maar de nog actieve
  busy-marker liet die prijs afwijzen en forceerde een tweede zware statusaanvraag.
  R8M gebruikt de reeds geverifieerde `pricingSummary` direct en haalt alleen bij
  werkelijk ontbrekende prijsdata één herstelresponse op.
- Statuspolling voerde per request herhaald complete SHA-256-familiecontroles uit,
  scande de volledige jobmap en normaliseerde de 597 materiaalrecords meerdere
  keren onder één globale lock. Status leest tijdens verwerking nu alleen de
  actuele fase/progressie, ontdekt subjobs via de vastgelegde links en hergebruikt
  mutation-sensitive materiaal- en artifactcaches. Downloads en de overgang naar
  DONE blijven fail-closed volledig verzegeld.
- Masterinput wordt als één durabilitybatch gepubliceerd, identieke subjobinput
  gebruikt hardlinks en de reeds canonieke compacte DXF-referenties worden niet
  opnieuw per PartId uitgepakt, geëncodeerd en gehasht. Tijdelijke timing- en
  commandodiagnostiek blokkeert de productieresultaten niet meer met afzonderlijke
  `fsync`-barrières. Definitieve DXF's, rapporten, prijs, manifest en finalization
  blijven duurzaam en volledig gehasht.
- Bij de onderdeel-export wijzigde iedere hardlink de ctime van de gedeelde
  broninode. Daardoor werd dezelfde DXF bij 250 PartIds ondanks de cache nog 252
  keer fysiek gehasht. Een hardlink wordt nu via exacte device/inode-identiteit
  bewezen; alleen een echte kopie krijgt de volledige bron/doel-hashvergelijking.
  De complete hardlinkdoelmappen worden vóór publicatie één keer duurzaam geflusht.
- Eén 250-panelenproef daalde vóór de eerste optimizerstart van 30 naar 16
  parent-`fsync`-barrières en over de volledige serverfinalisatie van 56 naar 31.
  De ene extra barrière borgt dat de nieuwe subjobmap zelf een stroomuitval overleeft.
  In dezelfde proef daalden de fysieke hashlezingen van circa 290 naar 41 en werd
  de ene gedeelde DXF nog hoogstens drie keer gelezen in plaats van 252 keer.
  De browserproef eist bij direct DONE exact één statusrequest en nul animatietimers.
- Publieke aanvragen gebruiken een begrensde FIFO: R8Z kiest één optimizer op
  één effectieve CPU en standaard twee vanaf twee CPU's, terwijl maximaal acht
  gevalideerde jobs ordelijk kunnen wachten. Daardoor starten meerdere klanten niet onbegrensd
  tegelijk en krijgt een toegelaten tweede klant een traceerbare wachtrijstatus in
  plaats van directe 429-afwijzing.
- De eerdere bewezen FIX655/FIX656-contracten blijven intact: de job is een echte
  backendjob die in Admin terugkomt, compacte DXF-bodies blijven gedeeld en een
  versnelling mag nooit extra platen accepteren. R8M wijzigt daarom geen
  plaatsingsstrategie, fast-mode of tijdslimiet; uitsluitend voorbereiding,
  polling, verificatiehergebruik, finalisatie-I/O en scheduling zijn aangepast.

## R8L prijsberekening-submit en zichtbare optimalisatie-overlay

- R8K deelde de DXF-cache tussen de eerste templateweergave en de submitroute,
  maar de cachevariabelen stonden door de historische opbouw van `toolA.html` in
  een andere callbackscope. Bij `Prijs berekenen` stopte de browser daarom vóór
  de job-POST op `_DXF_CLASSIFIED_PAIR_CACHE is not defined`; het overzicht sloot
  al wel en liet een half-afgebouwde stap-5-layout achter.
- De vier DXF-caches hebben nu één expliciete `window`-bridge. De loader en de
  submitpipeline binden daar ieder hun eigen lokale alias aan, zodat hergebruik
  snel blijft zonder een onbereikbare lexical binding.
- De jobstart-ID staat nu buiten het `try`-blok van de submitketen. Daardoor kan
  een vroege validatie-, netwerk- of JavaScriptfout niet langer zelf de
  foutafhandeling laten crashen; de echte reden verschijnt in het foutvenster.
- Safari krijgt direct na het openen van de optimalisatie-overlay één paint-frame
  voordat DXF-voorbereiding verdergaat. Bij een vroege afwijzing verdwijnt die
  overlay eerst en komt de foutmelding er zichtbaar bovenop.
- Een browserachtige DOM-runtimeproef drukt de echte verborgen berekenknop in,
  verwerkt een echte ingebedde METOD-DXF, controleert de compacte job-POST, ziet
  de optimalisatie-overlay en eindigt in de prijsoverlay. Een tweede route dwingt
  een HTTP 400 af en bewijst dat de voortgangslaag sluit en de servermelding
  zichtbaar wordt.

## R8K meerdere nerfgroepen en end-to-end compacte DXF-jobstart

- Op mobiel werd een nieuw aangemaakte lege G02 tijdens het renderen direct weer
  vervangen door de eerste gevulde groep G01. Daardoor bleef G01 geselecteerd en
  vergrendelde de beschikbare panelenlijst zich op de breedte van G01. Een nieuwe
  groep blijft nu expliciet geselecteerd, start zonder breedtefilter en toont alle
  nog beschikbare werkelijke breedtes. Pas het eerste toegevoegde paneel legt de
  exacte breedte van die groep vast. Dezelfde groepsstate en validatie blijven op
  desktop actief.
- R8J valideerde gedeelde DXF-geometrie al één keer aan de publieke grens, maar
  bouwde daarna opnieuw een uitgeklapte interne `dxfParts`-map. De worker telde die
  als legacy-invoer en kon een geldige 250-panelenjob alsnog vóór Tool B weigeren
  als meer dan 12 MB. R8K houdt de canonieke DTO en de input op schijf end-to-end
  compact: één SHA-256-geadresseerde DXF-body plus een PartId-referentiemanifest.
- Voor 250 identieke PartIds ontstaan vóór de optimizer niet langer circa 500
  master-/subjob-DXF-bestandsentries. Er worden twee unieke bodybestanden (master
  en subjob) plus twee kleine referentiemanifesten aangemaakt. Tool B verifieert
  manifest, exacte PartId-set en bodyhash vóór verwerking; 250 paneelidentiteiten,
  placements, labels, StickerTool-items en onderdeeldownloads blijven afzonderlijk.
- De browser deelt nu de al tijdens template-initialisatie geladen DXF-tekstcache
  met de submitroute. Gebruikte templates worden bij Optimaliseren niet opnieuw
  via HTTP opgehaald. De server berekent pre-acceptatiecomplexiteit over unieke
  bodies en serialiseert geen tijdelijk uitgeklapte 25–35 MB payload meer.
- Lokale volledige 250-panelenmeting met één echte METOD-DXF: publieke
  canonicalisatie 25,15 ms, pre-202-complexiteit 3,36 ms, serverjob inclusief
  optimizer en finalisatie 488,53 ms. Tool B zelf mat 224 ms totaal, waarvan
  123 ms nesting. De gate bewijst 250/250 placements, 12 platen, één unieke
  DXF-body in subjobinput en 250 afzonderlijke onderdeel-DXF-exports.

## R8J 200–250-panelen performance- en compact-DXF-correctie

- De compacte browserpayload stuurt één unieke DXF-body plus PartId-verwijzingen.
  De publieke servergrens vouwde dit correct uit, maar parseerde, valideerde en
  telde daarna dezelfde body opnieuw voor ieder PartId. Bij 250 gelijke panelen
  werd de geldige compacte aanvraag daardoor zelfs foutief als meer dan 12 MB
  geweigerd. R8J hash-identificeert unieke bodies en voert de volledige entity-
  en geometrievalidatie exact één keer per unieke body uit; de bbox blijft daarna
  afzonderlijk tegen ieder canoniek paneel gecontroleerd.
- De MaxRects-hot-path beoordeelde in iedere iteratie ieder fysiek exemplaar van
  exact dezelfde paneelgeometrie opnieuw, hoewel score, vrije rechthoeken en de
  uiteindelijke eerste-instantie-tiebreak identiek waren. In een 250-panelenprofiel
  bleken 92.385 pending- en 4.438 anchor-beoordelingen aantoonbaar equivalent.
  R8J slaat uitsluitend zulke bewezen equivalente berekeningen over; iedere
  fysieke instantie blijft afzonderlijk geplaatst, gevalideerd en geëxporteerd.
- Sorteervarianten die dezelfde geometrische itemvolgorde opleveren worden niet
  opnieuw volledig uitgevoerd. Voor homogene rechthoekjobs levert een geldige
  reguliere gridplaatsing bovendien een betere start-upper-bound; MaxRects en de
  bestaande bewijsruns mogen die uitkomst nog steeds verbeteren.
- Gemeten uitkomsten met identieke productie-input:
  - 200 gelijke panelen: 6,303 → 0,214 seconde; 11 → 10 platen;
  - 200 gemengde panelen: 5,898 → 0,667 seconde; 10 platen gebleven;
  - 250 gelijke panelen: 0,631 seconde totale optimizerduur, 12 platen, 250/250
    unieke plaatsingen en slechts één echte DXF-parse in de optimizer. De gekozen
    21-per-plaatindeling gebruikt drie 0°- en twee 90°-kolommen.
- Definitieve productie-DXF's worden nog steeds eenmaal per echte plaat duurzaam
  geschreven en vervolgens volledig op layer, entityaantal, plaatgrens, overlap,
  instance-identiteit en SHA-256 gecontroleerd. De versnelling verwijdert geen
  productiecontrole en verlaagt de nestingkwaliteit niet.

## R8I rand-tot-rand nerfpreview en optimizer-I/O-correctie

- De geopende mobiele nerfpreview begint nu op de werkelijk gemeten onderrand
  van de Grain Studio-bovenbalk. De dubbele mobiele tekstregels en samenvattingsbalk
  zijn uit de drawer verwijderd; het echte canvas gebruikt de volledige beschikbare
  ruimte tot aan de vaste actieknoppen.
- De inklapgreep ligt volledig binnen de drawer, heeft een groter zichtbaar
  handvat en blijft zowel open als gesloten bereikbaar. Een viewport- of
  oriëntatiewijziging meet de bovenrand opnieuw en rendert het canvas opnieuw.
- Desktop gebruikt aantoonbaar dezelfde real-mm renderer, materiaalweergave,
  DXF-boringen en bottom-to-top-productievolgorde. De regressiegate voert nu naast
  de iOS-route ook een aparte desktop-canvasroute uit.
- Tijdens het nesten werden iedere voortgangsstap en het groeiende tussenrapport
  met volledige file- plus directory-`fsync` gepubliceerd. Dat veroorzaakte op
  VPS-opslag veel synchrone diskbarriers. R8I schrijft uitsluitend deze vervangbare
  tussenstanden atomisch zonder `fsync`; definitieve rapporten, manifesten,
  productie-DXF's en finalization-hashes blijven volledig duurzaam geschreven.
- Een representatieve 100-panelenproef daalde lokaal van 2,543 naar 1,252 seconde
  optimizerduur (de herhaalde baseline bleef 2,100 seconde). De plaatindeling en
  het aantal van zes platen bleven exact gelijk. De UI begint bovendien na de
  reeds voltooide serverpreflight eerlijk op 3% in plaats van schijnbaar op 1%.

## R8H zichtbare iPhone-canvascorrectie

- De geopende FIX660-previewdrawer werd nog geraakt door een oude FIX649-regel
  met hogere CSS-specificiteit: zolang `fix649PreviewOpen` ontbrak, kreeg
  `#grainPreview` ondanks de nieuwe drawerstatus `display:none !important`.
  Daardoor waren groep, aantallen en maten zichtbaar, maar bleef de kaart wit.
- De oude FIX649-inline-previewpoort is verwijderd uit de actieve mobiele CSS.
  De geopende FIX660-drawer heeft daarnaast een expliciete ownershipselector
  die ook een eventueel nog door Safari gecachte oude regel overrulet.
- Zowel de oude mobiele stylesheet als alle Grain Studio-assets hebben een
  R8H-cachebuster. Schaal, bottom-to-top-volgorde, materiaalweergave,
  DXF-boringen/arcs en de Apply-readinessgate zijn inhoudelijk ongewijzigd.

## R8G publicatiepoort- en iOS-drawercorrectie

- Admin maakt nu ondubbelzinnig onderscheid tussen `100% voorbereid` en
  `actief gepubliceerd`. De 597 staged beelden blijven bewust onzichtbaar voor
  Tool A totdat de beheerder de complete CSV en beelden samen publiceert.
- Zodra de beeldvoorbereiding volledig geslaagd is, verschijnt direct in het
  voortgangsvak een tweede expliciete knop `Nu catalogus publiceren`; de
  bestaande reviewhash, bevestiging, snapshot en atomische publicatie blijven
  verplicht.
- De mobiele Doorlopende Nerf-preview voltooit een echte iOS-pointertap nu op
  `pointerup`, zodat Safari niet meer afhankelijk is van een `click` die na
  `preventDefault` kan worden onderdrukt. De sleep-transform krijgt dezelfde
  `!important`-prioriteit als de drawer-CSS en volgt daardoor zichtbaar de vinger.
- Een uitvoerende Node-regressietest bewijst openen met één tap, geen dubbele
  toggle en sluiten voorbij de sleepdrempel.

## R8F CSV-preview- en catalogusbeeldcorrectie

- De CSV-preview bevatte per ongeluk een auditblok uit de classificatie-override
  met vier variabelen die binnen preview niet bestaan. Daardoor eindigde iedere
  geldige CSV na het veilig opslaan van de stage alsnog in de generieke foutmelding.
- De afgeleide publieke cataloguscache heeft nu een expliciet schema/buildcontract.
  Een oude cache met beeld-URL's wordt na upgrade niet meer hergebruikt op basis
  van alleen de mtime van `material_library.json`.
- De proces-/HTTP-gate controleert nu ook een echte beveiligde CSV-preview en een
  lokaal gecachte catalogusafbeelding via de publieke API. Tool A vervangt een
  incidenteel niet-laadbaar beeld bovendien door de decorplaceholder.

## R8E live-HTTP-correctie

- De healthhandler gebruikt geen dubbel-underscore moduleconstant meer. De oude
  naam werd binnen `Handler.do_GET` door Python gemangeld naar
  `_Handler__SECURITY_BUILD`, waardoor de poort wel opende maar iedere
  livenessrequest zonder antwoord eindigde.
- De artifactgate start nu het echte serverproces en roept liveness, readiness
  en Tool A via loopback-HTTP aan. Alleen import-, compile- en directe
  handlertests zijn daardoor niet langer voldoende.
- De deploy onderdrukt herhaalde tijdelijke curlmeldingen en toont bij een
  blijvende healthfout automatisch de relevante systemd-journalregels.

## R8D rollback-/baselinecorrectie

- Een `metod-pax-current`-symlink die na rollback exact naar de legacy R7-map
  wijst, wordt nu als R7-baseline gevalideerd en niet meer ten onrechte als een
  immutable checksummanifest-release behandeld.
- Een echte immutable current-link is alleen geldig onder de beheerde
  releases-map en blijft volledig byte-voor-byte geverifieerd.
- `sudo -E` is verwijderd. Alleen de expliciete deployconfiguratie wordt als
  afzonderlijke, niet-uitvoerbare omgevingswaarden naar root doorgegeven.

## R8C installerfix

- Iedere installer- en deploy-Pythonaanroep draait met bytecode uitgeschakeld;
  de state-migratie kan daardoor geen `app/__pycache__` in de immutable release
  meer creëren.
- De immutable release-ID is nu afgeleid van het volledige interne
  checksummanifest. Een eerder geweigerde of vervuilde releasefolder met dezelfde
  backendbron kan daardoor nooit door een gecorrigeerde revisie worden hergebruikt.

## R8B packagingcorrectie

- Het runtimecontract ondersteunt nu expliciet Python `>=3.10,<3.15`.
- Python 3.14.4 is door de volledige preflight op de doel-VPS gevalideerd; de
  eerdere blokkade was uitsluitend de te smalle declaratieve bovengrens.
- De geïsoleerde preflight-state en expliciete `FOUTSAMENVATTING` uit R8A blijven
  actief.

Datum: 13 augustus 2026  
Build: `FIX660R8_PRELIVE_HARDENED`  
Basis: FIX660R7 pre-live audit

## Productie- en prijsintegriteit

- De publieke jobpayload wordt server-side opnieuw opgebouwd uit opaque materiaal-ID, actieve catalogus, live pricing en de ingebedde DXF-library.
- Paneelvelden zijn strict finite; aantallen, kantenbandcodes, nerfposities, dikte en plaatmaat hebben vaste contracten.
- DXF/CSV-bboxafwijking, onbekende machining, overlap, buiten-plaatgeometrie en exportfouten zijn fatal.
- ARC-hoeken roteren correct op 0/90/180/270 graden.
- Nerfpositie 1 is fysiek de onderste positie en ongelijke groepsbreedtes worden geweigerd.
- Clientpricing en clientgekozen productiepolicy hebben geen autoriteit meer.
- Finalisatie bindt input, optimizeroutputs, exacte identities/counts en alle downloadbare artifacts aan SHA-256.
- Status, submit en Admin-download falen gesloten bij ontbrekende of gemanipuleerde finalisatie.

## Security en privacy

- Job- en request-ID's gebruiken een strict allowlistcontract met vaste-root containment.
- Public quote-output is minimaal; productie-, prijs- en materiaalinterne data blijven Admin-only.
- Admin gebruikt in productie individuele accounts, TOTP MFA, HttpOnly sessiecookies, idle/absolute TTL, logout/revocation en server-derived actorlogging.
- Basic auth is in productie uitgeschakeld; login voert dummy PBKDF2/TOTP uit voor onbekende gebruikers.
- CSP gebruikt nonces en statische/DXF-responses gebruiken een beperkte allowlist en `nosniff`.
- Nginx normaliseert client-IP en begrenst jobs, login, SSE, requests en connecties.
- Staging bindt standaard alleen aan loopback; een remote bind vereist een expliciete CIDR-allowlist.
- Clientlogs zijn klein, geratelimit, geredigeerd, roterend en vereisen een jobtoken wanneer een job wordt genoemd.
- Catalogusafbeeldingen valideren DNS één keer en verbinden via het gepinde publieke IP met TLS-SNI/certificaatcontrole op de originele host.

## State, deploy en herstel

- Mutable state staat buiten de immutable release onder `/var/lib/metod-pax`.
- Migratie gebeurt naar een sibling stagingmap en wordt atomisch gepubliceerd na durable markerwrite.
- Releases zijn immutable; de current-symlink wordt atomisch gewisseld.
- Maintenance/drain voorkomt gemengde assets en verlies van deploy-windowdata.
- Rollback wijzigt code/config, nooit live state.
- Backups omvatten de volledige noodzakelijke state, gebruiken een schema-2 manifest met size/SHA-256 per bestand en worden na creatie byte-voor-byte herverifieerd.
- Restore weigert traversal, symlinks, extra/dubbele leden, hashverschillen en bestaande targets; publicatie gebeurt pas na een tweede hashcontrole.
- Kritieke writes gebruiken durable temp-write/replace/fsync; JSONL-logs hebben cross-process locking en rotatie.

## Catalogus en operations

- Cataloguspreview geeft een reviewhash over CSV, warnings, exclusions, errors, samenvatting, taxonomie en genormaliseerde records.
- Publicatie vereist dezelfde reviewhash en maakt een signoff die aan de actieve libraryhash is gebonden.
- Readiness controleert catalogus, signoff, pricing, schrijfbaarheid, vrije bytes/inodes, DXF-library en restore/offsite-evidence in productie.
- Runtimecontract, stdlib-only requirements, CycloneDX-SBOM, reproduceerbare artifactbuilder en CI releasegate zijn toegevoegd.

## Bewuste incompatibiliteiten

- De auth-loze StickerTool-route is 410 Gone.
- Per materiaaljob bestaat nog maar één authoritative `output/stickertool.json`; oude `stickers.json`-spiegels zijn verwijderd.
- Admin kan uitsluitend files downloaden die in een geldige finalization-hashlijst staan. Oude debuglogs en inputbestanden zijn niet meer via outputknoppen bereikbaar.
- Legacy queue-items worden niet opnieuw geoptimaliseerd; onveilig hervatwerk gaat naar handmatige controle.

## Geen productiecertificaat

Deze build is een pre-live candidate. De resterende externe gates staan in `GO_LIVE_GATES_FIX660R8.md` en kunnen niet met alleen broncode worden afgetekend.
# R9H-3 native mobile-cart-/bottom-sheetcheckpoint

- Het mobiele multi-materialenmandje en de bottom-sheet hebben nu één native
  eigenaar in `app/tool-a/components/mobile-material-cart.js`.
- De oude runtime-eigenaar `toolA_mobile_material_cart.js` en de extra
  `ToolAMobileMaterialCart`-global zijn verwijderd; tijdelijke aanroepplaatsen
  delegeren via de enige frozen `ToolAR9Foundation`-grens.
- Bestaande markup, R8S-CSS, 50/50-footer, swatches, activatie,
  verwijdertransactie, focus-, Escape-, resize- en desktopgedrag zijn exact
  behouden en met vaste fingerprints vergrendeld.
- R9H staat hiermee op 3/10. Externe iPhone/Safari- en productie-identieke gates
  blijven `DEFERRED NO-GO`.
# R9H-6 native paneeleditorcheckpoint

- Standaard METOD/PAX-panelen en overige maatwerkpanelen delen nu één native
  formulieractie- en mutatieroute-eigenaar in
  `app/tool-a/components/panel-editor.js`.
- Toevoegen, wijzigen, verwijderen, prefill en reset lopen via de frozen
  `ToolAR9Foundation`; de bestaande validatie- en submitmodules blijven als
  tijdelijke compatibilitylaag behouden.
- Paneeldock, overige-panelenoverlay en beide overzichtsrenderers voeren geen
  eigen directe verwijdermutaties meer uit.
- Er is geen CSS gewijzigd. Optimizer, DXF, prijslogica, payloadbuilder en
  serverroutes blijven buiten scope en bytegelijk beschermd.
- R9H staat hiermee op 6/10; WebKit/Safari en productie-identieke externe gates
  blijven `DEFERRED NO-GO`.

# R9H-7 native nerfpreviewcheckpoint

- Eén native component bezit nu de nerfpreview-bindings, renderroute,
  animation-frame scheduling, resize-observatie en data-readiness in
  `app/tool-a/components/grain-preview.js`.
- Desktop, mobiel en de inline compatibility-entrypoint gebruiken dezelfde
  frozen `ToolAR9Foundation`-route; de bestaande canvasrenderer blijft de
  beschermde draw-engine voor echte millimeterschaal, materialen en boringen.
- Fysieke nerfvolgorde blijft positie 1 onderaan; de canvasprojectie keert
  uitsluitend de visuele boven→onderweergave om. Exacte werkelijke breedte in
  millimeters blijft de groepsinvariant.
- Er is geen CSS gewijzigd. Optimizer, payloadbuilder, DXF, pricing,
  serverroutes en panelcontract blijven buiten scope en beschermd.
- R9H staat hiermee op 7/10; WebKit/Safari en productie-identieke externe gates
  blijven `DEFERRED NO-GO`.

# R9H-8 native checkout/reviewcheckpoint

- Eén native component bezit nu de live klant-snapshot, read-only
  checkoutcontrole, verzendgereedheid en fysieke submit-eventroutering in
  `app/tool-a/components/checkout-review.js`.
- De vroeg geregistreerde Safari-adapter blijft uitsluitend voor gegarandeerde
  eventvolgorde aanwezig en delegeert alle checkoutbeslissingen naar de frozen
  `ToolAR9Foundation`-route.
- Eén tik blijft exact één final-submit action en maximaal één
  `POST /api/submit_config`; de bestaande request-state-machine en jobbearer
  blijven de enige netwerk- en capability-eigenaren.
- Consenttekst, autoritatieve serverprijs, live klantgegevens, foutrecovery en
  correctieroutes blijven ongewijzigd. Thank-you blijft bewust de volgende
  afgebakende componentstap.
- Er is geen CSS gewijzigd. Optimizer, payloadbuilder, DXF, pricing,
  serverroutes en panelcontract blijven buiten scope en beschermd.
- R9H staat hiermee op 8/10; WebKit/Safari en productie-identieke externe gates
  blijven `DEFERRED NO-GO`.

# R9H-9 native thank-youcheckpoint

- Eén native component bezit nu de committed bedankpagina-markup, veilige
  klant-/referentieweergave, openen/sluiten en de fysieke acties `Sluiten` en
  `Nieuwe configuratie` in `app/tool-a/components/thank-you.js`.
- De inline renderer en de extra `__metodShowSubmissionThankYou`-global zijn
  verwijderd; final submit gebruikt uitsluitend de frozen
  `ToolAR9Foundation`-route.
- Eén fysieke actie blijft maximaal één hard-resetroute. De bestaande reset
  wist draft-, klant-, job- en requestcapabilities voordat een schone
  cache-onafhankelijke documentnavigatie plaatsvindt.
- Er is geen CSS gewijzigd. Request-API, submit-state-machine, jobbearer,
  consenttekst, autoritatieve prijs, optimizer, payloadbuilder, DXF en
  panelcontract blijven buiten scope en beschermd.
- R9H staat hiermee op 9/10; WebKit/Safari en productie-identieke externe gates
  blijven `DEFERRED NO-GO`.

# R9H-10 semantische shell en CSS-/scriptgrenzen

- De 54 bestaande styleblokken zijn bytegelijk en in dezelfde cascadevolgorde
  ondergebracht in zeven fasen: tokens, base, layout, components, mobile, grain
  en checkout.
- De 34 klassieke inline scripts zijn bytegelijk op hun bestaande
  uitvoeringsposities geëxternaliseerd; iedere scriptbody behoudt een eigen
  klassieke scope.
- `toolA.html` bevat geen inline style-elementen en geen inline uitvoerbare
  scripts meer, en gebruikt één semantische `main`, `footer`, navigatie en
  benoemde regio's.
- Een aparte allowlist publiceert exact 41 shellassets zonder de 18 native
  modules of hun 9 DOM- en 2 netwerkowners uit te breiden.
- Gedraggebonden `style`-attributen en alle `fixXXX`-regels blijven bewust
  behouden totdat berekende-stijl- en visuele vergelijking in Chromium én
  WebKit gelijkheid bewijst.
- R9H staat hiermee op 10/10; WebKit/Safari en productie-identieke externe gates
  blijven `DEFERRED NO-GO`.
