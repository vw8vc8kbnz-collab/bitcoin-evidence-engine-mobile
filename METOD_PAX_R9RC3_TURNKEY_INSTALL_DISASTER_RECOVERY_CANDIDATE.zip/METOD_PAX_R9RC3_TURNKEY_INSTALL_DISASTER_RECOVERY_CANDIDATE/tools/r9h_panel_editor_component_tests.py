#!/usr/bin/env python3
from __future__ import annotations

"""Fail-closed R9H-6 panel-editor behavior, mutation-route and ownership proof."""

import ast
import base64
import hashlib
import json
import shutil
import subprocess
import unittest
from pathlib import Path

from r9h_shell_source import read_toola_expanded


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
HTML = APP / "toolA.html"
BOOTSTRAP = APP / "tool-a/bootstrap.js"
COMPONENT = APP / "tool-a/components/panel-editor.js"
RULES = ROOT / "R9B_ARCHITECTURE_RULES.json"


def data_url(path: Path) -> str:
    return "data:text/javascript;base64," + base64.b64encode(path.read_bytes()).decode()


def run_node(source: str) -> dict:
    node = shutil.which("node")
    if not node:
        raise AssertionError("Node is required by the release architecture gate")
    completed = subprocess.run(
        [node, "--input-type=module"], input=source, text=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=10, check=False,
    )
    if completed.returncode != 0:
        raise AssertionError(completed.stdout)
    return json.loads(completed.stdout.strip().splitlines()[-1])


def assignment_set(path: Path, name: str) -> set[str]:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(
            isinstance(target, ast.Name) and target.id == name for target in node.targets
        ):
            value = node.value
            if isinstance(value, ast.Call) and isinstance(value.func, ast.Name) and value.func.id == "frozenset":
                value = value.args[0]
            return set(ast.literal_eval(value))
    raise AssertionError(name)


class R9HPanelEditorComponentTests(unittest.TestCase):
    def test_01_component_surface_is_frozen_and_revisioned(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});
const c=m.createPanelEditorComponent({{documentRef:{{}},rootRef:{{}}}});
console.log(JSON.stringify({{build:m.PANEL_EDITOR_COMPONENT_BUILD,componentBuild:c.BUILD,frozen:Object.isFrozen(c),keys:Reflect.ownKeys(c)}}));
""")
        self.assertEqual(result["build"], "R9H_PANEL_EDITOR_COMPONENT_6")
        self.assertEqual(result["componentBuild"], result["build"])
        self.assertTrue(result["frozen"])
        self.assertEqual(result["keys"], [
            "BUILD", "bind", "submitStandard", "submitExtra", "removeStandard", "removeExtra",
            "getStandardEditSnapshot", "applyStandardPrefill", "resetStandard",
            "getExtraEditSnapshot", "applyExtraPrefill", "resetExtra", "announceReady",
        ])

    def test_02_standard_submit_has_one_exact_compatibility_route(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});let calls=0;let received=null;
const owner={{execute:(input)=>{{calls++;received=input;return {{ok:true,mode:'edit'}};}}}};
const c=m.createPanelEditorComponent({{documentRef:{{}},rootRef:{{}}}});const input={{submitOwner:owner,state:{{cart:[]}},token:'standard'}};
console.log(JSON.stringify({{result:c.submitStandard(input),calls,same:received===input}}));
""")
        self.assertEqual(result, {"result": {"ok": True, "mode": "edit"}, "calls": 1, "same": True})

    def test_03_extra_submit_and_missing_or_throwing_owners_fail_closed(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});let calls=0;
const c=m.createPanelEditorComponent({{documentRef:{{}},rootRef:{{ToolAExtraPanelSubmitApply:{{execute:(input)=>{{calls++;return {{ok:true,id:input.id}};}}}}}}}});
console.log(JSON.stringify({{extra:c.submitExtra({{id:'EX_1'}}),calls,missing:c.submitStandard({{}}),failed:c.submitExtra({{submitOwner:{{execute:()=>{{throw Error('x')}}}}}})}}));
""")
        self.assertEqual(result["extra"], {"ok": True, "id": "EX_1"})
        self.assertEqual(result["calls"], 1)
        self.assertEqual(result["missing"]["reason"], "missing-standard-submit-owner")
        self.assertEqual(result["failed"]["reason"], "extra-submit-failed")

    def test_04_standard_remove_clears_grain_and_runs_exact_post_hooks(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});const calls=[];
const state={{cart:[{{id:'a',grainGroupId:'g',grainOrder:1}},{{id:'b',grainGroupId:'g',grainOrder:2}}],grain:{{groups:[1],selectedGroupId:'g'}}}};
const hooks={{resetPanelEntryFields:()=>calls.push('reset'),draw:()=>calls.push('draw'),renderCart:()=>calls.push('cart'),renderExtraPanels:()=>calls.push('extra'),renderOverview:()=>calls.push('overview'),syncChecksFromSelect:()=>calls.push('checks'),drawExtraPreview:()=>calls.push('preview'),scheduleDraftSave:()=>calls.push('save')}};
const c=m.createPanelEditorComponent({{documentRef:{{}},rootRef:{{}}}});const removed=c.removeStandard({{state,id:'a',isRemovingEdited:true,hooks}});
console.log(JSON.stringify({{removed,state,calls}}));
""")
        self.assertEqual(result["removed"], {"ok": True, "removedId": "a", "remaining": 1})
        self.assertEqual(result["state"]["cart"][0]["id"], "b")
        self.assertEqual((result["state"]["cart"][0]["grainGroupId"], result["state"]["cart"][0]["grainOrder"]), (None, None))
        self.assertEqual(result["state"]["grain"], {"groups": [], "selectedGroupId": None})
        self.assertEqual(result["calls"], ["reset", "draw", "cart", "extra", "overview", "checks", "preview", "save"])

    def test_05_missing_standard_remove_is_side_effect_free(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});let calls=0;const state={{cart:[{{id:'a'}}],grain:{{groups:[1]}}}};
const c=m.createPanelEditorComponent({{documentRef:{{}},rootRef:{{}}}});const out=c.removeStandard({{state,id:'x',hooks:{{renderCart:()=>calls++}}}});
console.log(JSON.stringify({{out,state,calls}}));
""")
        self.assertEqual(result["out"]["reason"], "standard-panel-not-found")
        self.assertEqual(result["state"], {"cart": [{"id": "a"}], "grain": {"groups": [1]}})
        self.assertEqual(result["calls"], 0)

    def test_06_extra_remove_preserves_order_identity_and_edit_reset(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});const calls=[];const state={{cart:[],extraPanels:[{{id:'x'}},{{id:'y'}},{{id:'z'}}],grain:{{groups:[1],selectedGroupId:'g'}}}};
const hooks={{clearAllGrainAssignments:()=>calls.push('grain'),setEditIndex:v=>calls.push(['edit',v]),renderExtraPanels:()=>calls.push('extra'),renderCart:()=>calls.push('cart'),renderOverview:()=>calls.push('overview'),scheduleDraftSave:()=>calls.push('save'),updatePriceBar:()=>calls.push('price'),syncChecksFromSelect:()=>calls.push('checks'),drawExtraPreview:()=>calls.push('preview')}};
const c=m.createPanelEditorComponent({{documentRef:{{}},rootRef:{{}}}});const out=c.removeExtra({{state,index:1,editIndex:1,hooks}});
console.log(JSON.stringify({{out,ids:state.extraPanels.map(x=>x.id),calls}}));
""")
        self.assertEqual(result["out"], {"ok": True, "removedId": "y", "remaining": 2})
        self.assertEqual(result["ids"], ["x", "z"])
        self.assertEqual(result["calls"], ["grain", ["edit", None], "extra", "cart", "overview", "save", "price", "checks", "preview"])

    def test_07_bind_is_idempotent_and_routes_both_submit_buttons_once(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});function el(){{const listeners={{}};return {{listeners,addEventListener:(t,f)=>(listeners[t]||(listeners[t]=[])).push(f)}};}}
const standard=el(),extra=el();let standardCalls=0,extraCalls=0;
const c=m.createPanelEditorComponent({{documentRef:{{}},rootRef:{{}}}});const input={{standardAddButton:standard,extraAddButton:extra,getStandardSubmitInput:()=>({{submitOwner:{{execute:()=>{{standardCalls++;return {{ok:true}};}}}}}}),getExtraSubmitInput:()=>({{submitOwner:{{execute:()=>{{extraCalls++;return {{ok:true}};}}}}}})}};
c.bind(input);c.bind(input);standard.listeners.click[0]();extra.listeners.click[0]();
console.log(JSON.stringify({{standardCalls,extraCalls,standardListeners:standard.listeners.click.length,extraListeners:extra.listeners.click.length}}));
""")
        self.assertEqual(result, {"standardCalls": 1, "extraCalls": 1, "standardListeners": 1, "extraListeners": 1})

    def test_08_preview_and_edge_events_have_one_native_owner(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});function el(){{const listeners={{}};return {{listeners,addEventListener:(t,f)=>(listeners[t]||(listeners[t]=[])).push(f)}};}}
const preview=el(),edge=el(),name=el();let draws=0,syncs=0;const c=m.createPanelEditorComponent({{documentRef:{{}},rootRef:{{}}}});
c.bind({{extraPreviewInputs:[preview,edge],extraNameInput:name,extraEdgeInputs:[edge],drawExtraPreview:()=>draws++,syncExtraEdges:()=>syncs++}});
preview.listeners.input[0]();preview.listeners.change[0]();edge.listeners.change[0]();edge.listeners.change[1]();name.listeners.input[0]();
console.log(JSON.stringify({{draws,syncs,edgeChanges:edge.listeners.change.length}}));
""")
        self.assertEqual(result, {"draws": 4, "syncs": 1, "edgeChanges": 2})

    def test_09_edit_and_reset_adapters_keep_legacy_form_contracts(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});const calls=[];
const rootRef={{ToolAPanelFormState:{{getEditPrefillSnapshot:(item,o)=>({{kind:'standard',id:item.id,count:o.originalCount}}),getResetSnapshot:o=>({{kind:'reset',hinge:o.currentHingeValue}})}},ToolAPanelFormApply:{{applyPrefill:i=>{{calls.push(i.snapshot.kind);return true;}},applyReset:i=>{{calls.push(i.snapshot.hinge);return true;}}}},ToolAExtraPanelMutations:{{getEditPrefillSnapshot:(item,o)=>({{kind:'extra',id:item.id,index:o.index}}),getResetFormState:o=>({{kind:'extra-reset',edge:o.defaultEdge}})}},ToolAExtraPanelFormApply:{{applyPrefill:i=>{{calls.push(i.snapshot.kind);return true;}},applyReset:i=>{{calls.push(i.snapshot.edge);return true;}}}}}};
const c=m.createPanelEditorComponent({{documentRef:{{}},rootRef}});const standard=c.getStandardEditSnapshot({{id:'a'}},{{originalCount:3}});const extra=c.getExtraEditSnapshot({{id:'x'}},{{index:2}});
console.log(JSON.stringify({{standard,extra,prefill:c.applyStandardPrefill({{snapshot:standard}}),reset:c.resetStandard({{options:{{currentHingeValue:'right'}}}}),extraPrefill:c.applyExtraPrefill({{snapshot:extra}}),extraReset:c.resetExtra({{options:{{defaultEdge:'all'}}}}),calls}}));
""")
        self.assertEqual(result["standard"], {"kind": "standard", "id": "a", "count": 3})
        self.assertEqual(result["extra"], {"kind": "extra", "id": "x", "index": 2})
        self.assertEqual(result["calls"], ["standard", "right", "extra", "all"])
        self.assertTrue(all(result[key] for key in ("prefill", "reset", "extraPrefill", "extraReset")))

    def test_10_ready_event_is_idempotent_and_no_dom_is_no_throw(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});const events=[];class E{{constructor(type){{this.type=type;}}}}
const c=m.createPanelEditorComponent({{documentRef:{{dispatchEvent:e=>events.push(e.type)}},rootRef:{{Event:E}}}});
console.log(JSON.stringify({{first:c.announceReady(),second:c.announceReady(),events,empty:c.bind({{}})}}));
""")
        self.assertEqual(result, {"first": True, "second": False, "events": ["tool-a-panel-editor-owner-ready"], "empty": False})

    def test_11_bootstrap_html_and_architecture_publish_one_panel_editor_owner(self) -> None:
        bootstrap = BOOTSTRAP.read_text(encoding="utf-8")
        html = read_toola_expanded(HTML)
        self.assertEqual(bootstrap.count('from "./components/panel-editor.js"'), 1)
        self.assertEqual(bootstrap.count("createPanelEditorComponent()"), 1)
        self.assertEqual(bootstrap.count("panelEditorComponent.announceReady();"), 1)
        self.assertIn('"R9RC1_PROFESSIONAL_ARCHITECTURE_COMPLETION"', bootstrap)
        self.assertIn('mode: "legacy-read-cleanup-adapter"', bootstrap)
        for method in ("bindPanelEditor", "submitPanel", "submitExtraPanel", "removePanel", "removeExtraPanel", "getPanelEditSnapshot", "resetPanelEditor", "getExtraPanelEditSnapshot", "resetExtraPanelEditor"):
            self.assertEqual(bootstrap.count(f"  {method}:"), 1, method)
        self.assertIn('tool-a/bootstrap.js?v=r9rc1-professional-architecture-completion', html)
        self.assertEqual(html.count("bindNativePanelEditor"), 3)
        self.assertNotIn("addBtn.addEventListener('click'", html)
        self.assertNotIn("addExtraBtn.addEventListener('click'", html)
        self.assertNotIn("state.extraPanels.splice", html)
        rules = json.loads(RULES.read_text(encoding="utf-8"))["frontend"]
        self.assertIn("app/tool-a/components/panel-editor.js", rules["domOwnerModules"])
        self.assertEqual(rules["moduleImports"]["app/tool-a/components/panel-editor.js"], [])
        self.assertEqual(len(rules["publicStaticFiles"]), 19)

    def test_12_io_allowlists_preflight_and_protected_fingerprints_are_exact(self) -> None:
        expected = {
            "dxf_nesting_optimizer.py": "42480b301cd660dac1e5e9fec2c8d30bb5c6826c32234a9c1cce765b758bebb8",
            "dxf_geometry.py": "b80a2d006241908bf7b33516f7e0faf59ef61e1e08db86966b23cc5de292c1ff",
            "pricing_helpers.py": "646c2f5186e9b080f6ba8dcf364884411c18e946254bb5c9001647f7cbb425df",
            "panel_contract.py": "e23314fd63a2358a48daa580a92cebb8a40c9862548ba0243461a59347da7fc9",
            "toolA_panel_mutations.js": "4fd36df984c6416e0e394397ecafd53c0f20a6e432bf8330226c03ef00230356",
            "toolA_panel_submit_flow.js": "5010767a8a40922fca1969e5751c2ecf4c6bad627b933da4172a18c62ccae86e",
        }
        for name, digest in expected.items():
            self.assertEqual(hashlib.sha256((APP / name).read_bytes()).hexdigest(), digest, name)
        source = COMPONENT.read_text(encoding="utf-8")
        for token in ("fetch(", "XMLHttpRequest", "EventSource", "WebSocket", "localStorage", "sessionStorage", "defineProperty(globalThis"):
            self.assertNotIn(token, source)
        self.assertEqual(assignment_set(APP / "metod_app/http/static.py", "PUBLIC_STATIC_MODULE_FILES"),
            assignment_set(APP / "metod_app/http/static.py", "PUBLIC_STATIC_MODULE_FILES"))
        self.assertEqual(len(assignment_set(APP / "metod_app/http/static.py", "PUBLIC_STATIC_MODULE_FILES")), 19)
        matrix = json.loads((ROOT / "R9RC3_ACTIVE_TEST_MATRIX.json").read_text(encoding="utf-8"))
        self.assertIn(
            "tools/r9h_panel_editor_component_tests.py",
            {row["path"] for row in matrix["suites"]},
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
