#!/usr/bin/env python3
from __future__ import annotations

"""Fail-closed R9H-2 progress-overlay behavior and ownership proof."""

import ast
import base64
import hashlib
import json
import re
import shutil
import subprocess
import unittest
from pathlib import Path

from r9h_shell_source import read_toola_expanded


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
HTML = APP / "toolA.html"
BOOTSTRAP = APP / "tool-a/bootstrap.js"
PROGRESS = APP / "tool-a/components/progress-overlay.js"
RULES = ROOT / "R9B_ARCHITECTURE_RULES.json"


def data_url(data: bytes | Path) -> str:
    raw = data.read_bytes() if isinstance(data, Path) else data
    return "data:text/javascript;base64," + base64.b64encode(raw).decode()


def run_node(source: str) -> dict:
    node = shutil.which("node")
    if not node:
        raise AssertionError("Node is required by the release architecture gate")
    completed = subprocess.run(
        [node, "--input-type=module"], input=source, text=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=10, check=False,
    )
    if completed.returncode != 0:
        raise AssertionError(completed.stdout)
    return json.loads(completed.stdout.strip().splitlines()[-1])


def fake_dom_probe(actions: str, *, fail_overlay: bool = False) -> dict:
    return run_node(f"""
const m=await import({json.dumps(data_url(PROGRESS))});
const nodes={{}};const appended=[];let divCount=0;
function makeElement(tag){{
  let id='';let html='';
  const element={{tag,style:{{}},attrs:{{}},dataset:{{}},textContent:'',
    setAttribute(name,value){{this.attrs[name]=String(value);}},
    getAttribute(name){{return this.attrs[name];}},
    querySelector(selector){{return nodes[String(selector).replace(/^#/,'')]||null;}}
  }};
  Object.defineProperty(element,'id',{{get:()=>id,set:(value)=>{{id=String(value);nodes[id]=element;}}}});
  Object.defineProperty(element,'innerHTML',{{get:()=>html,set:(value)=>{{
    if({json.dumps(fail_overlay)} && element.id==='metodProgressOverlay') throw new Error('overlay unavailable');
    html=String(value);
    for(const childId of ['metodProgressOverlayRing','metodProgressOverlayPct','metodProgressOverlayFill','metodProgressOverlayLabel']){{
      const child=makeElement('child');child.id=childId;
    }}
  }}}});
  return element;
}}
const body={{style:{{overflow:'auto'}},dataset:{{}},children:[],
  appendChild(el){{this.children.push(el);appended.push(el.id);}},
  contains(el){{return this.children.includes(el);}}
}};
const head={{children:[],appendChild(el){{this.children.push(el);appended.push(el.id);}}}};
const documentRef={{body,head,getElementById:(id)=>nodes[id]||null,createElement:(tag)=>{{if(tag==='div')divCount++;return makeElement(tag);}}}};
const component=m.createProgressOverlayComponent({{documentRef}});
{actions}
""")


def assignment_set(path: Path, name: str) -> set[str]:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(
            isinstance(target, ast.Name) and target.id == name for target in node.targets
        ):
            value = node.value
            if isinstance(value, ast.Call) and isinstance(value.func, ast.Name) and value.func.id == "frozenset":
                value = value.args[0]
            return set(ast.literal_eval(value))
    raise AssertionError(name)


class R9HProgressOverlayTests(unittest.TestCase):
    def test_01_busy_state_rounds_progress_and_preserves_visual_math(self) -> None:
        result = fake_dom_probe("""
component.updateMetodProgressBadge({busy:true,progressPct:42.6,progressLabel:'  Panelen voorbereiden…  '});
console.log(JSON.stringify({pct:nodes.metodProgressOverlayPct.textContent,
 fill:nodes.metodProgressOverlayFill.style.width,label:nodes.metodProgressOverlayLabel.textContent,
 ring:nodes.metodProgressOverlayRing.style.background,display:nodes.metodProgressOverlay.style.display,
 hidden:nodes.metodProgressOverlay.attrs['aria-hidden'],overflow:body.style.overflow,
 fallback:nodes.metodProgressBadge.style.display}));
""")
        self.assertEqual(result, {
            "pct": "43%", "fill": "43%", "label": "Panelen voorbereiden…",
            "ring": "conic-gradient(rgba(102,198,152,.95) 0deg 154.8deg, rgba(218,236,226,1) 154.8deg 360deg)",
            "display": "flex", "hidden": "false", "overflow": "hidden", "fallback": "none",
        })

    def test_02_percentage_bounds_default_and_six_percent_floor_are_exact(self) -> None:
        result = fake_dom_probe("""
component.updateMetodProgressBadge({busy:true,progressPct:-4,progressLabel:''});
const low={pct:nodes.metodProgressOverlayPct.textContent,fill:nodes.metodProgressOverlayFill.style.width,ring:nodes.metodProgressOverlayRing.style.background,label:nodes.metodProgressOverlayLabel.textContent};
component.updateMetodProgressBadge({busy:true,progressPct:140,progressLabel:'Klaar'});
const high={pct:nodes.metodProgressOverlayPct.textContent,fill:nodes.metodProgressOverlayFill.style.width,ring:nodes.metodProgressOverlayRing.style.background};
component.updateMetodProgressBadge({busy:true,progressPct:'niet-numeriek'});
const unknown={pct:nodes.metodProgressOverlayPct.textContent,fill:nodes.metodProgressOverlayFill.style.width,ring:nodes.metodProgressOverlayRing.style.background};
console.log(JSON.stringify({low,high,unknown}));
""")
        self.assertEqual(result["low"], {
            "pct": "0%", "fill": "6%",
            "ring": "conic-gradient(rgba(102,198,152,.95) 0deg 8deg, rgba(218,236,226,1) 8deg 360deg)",
            "label": "Bezig met optimaliseren…",
        })
        self.assertEqual(result["high"], {
            "pct": "100%", "fill": "100%",
            "ring": "conic-gradient(rgba(102,198,152,.95) 0deg 360deg, rgba(218,236,226,1) 360deg 360deg)",
        })
        self.assertEqual(result["unknown"], {
            "pct": "…", "fill": "6%",
            "ring": "conic-gradient(rgba(102,198,152,.95) 0deg 21.6deg, rgba(218,236,226,1) 21.6deg 360deg)",
        })

    def test_03_scroll_lock_is_idempotent_and_restores_the_previous_overflow(self) -> None:
        result = fake_dom_probe("""
component.updateMetodProgressBadge({busy:true,progressPct:1});
body.style.overflow='hidden';
component.updateMetodProgressBadge({busy:true,progressPct:2});
const saved=body.dataset.metodProgressOverlayPrevOverflow;
component.hideMetodProgressOverlay();
console.log(JSON.stringify({saved,overflow:body.style.overflow,open:'metodProgressOverlayOpen' in body.dataset,
 previous:'metodProgressOverlayPrevOverflow' in body.dataset,display:nodes.metodProgressOverlay.style.display,
 hidden:nodes.metodProgressOverlay.attrs['aria-hidden']}));
""")
        self.assertEqual(result, {
            "saved": "auto", "overflow": "auto", "open": False, "previous": False,
            "display": "none", "hidden": "true",
        })

    def test_04_overlay_failure_uses_the_existing_small_badge_contract(self) -> None:
        result = fake_dom_probe("""
component.updateMetodProgressBadge({busy:true,progressPct:12,progressLabel:'Laden'});
const shown={display:nodes.metodProgressBadge.style.display,text:nodes.metodProgressBadge.textContent,
 visible:component.isMetodProgressFallbackVisible(),overflow:body.style.overflow};
component.updateMetodProgressBadge({busy:false});
const hidden={display:nodes.metodProgressBadge.style.display,text:nodes.metodProgressBadge.textContent,
 visible:component.isMetodProgressFallbackVisible(),overflow:body.style.overflow};
console.log(JSON.stringify({shown,hidden}));
""", fail_overlay=True)
        self.assertEqual(result, {
            "shown": {"display": "block", "text": "Optimaliseren 12% • Laden", "visible": True, "overflow": "auto"},
            "hidden": {"display": "none", "text": "", "visible": False, "overflow": "auto"},
        })

    def test_05_dom_style_overlay_and_badge_are_reused_without_duplicates(self) -> None:
        result = fake_dom_probe("""
component.updateMetodProgressBadge({busy:true,progressPct:5});
component.updateMetodProgressBadge({busy:true,progressPct:8});
component.hideMetodProgressOverlay();
component.updateMetodProgressBadge({busy:true,progressPct:9});
console.log(JSON.stringify({appended,bodyChildren:body.children.map(v=>v.id),headChildren:head.children.map(v=>v.id),
 pct:nodes.metodProgressOverlayPct.textContent}));
""")
        self.assertEqual(result, {
            "appended": ["metodProgressOverlay", "metodProgressBadge"],
            "bodyChildren": ["metodProgressOverlay", "metodProgressBadge"],
            "headChildren": [], "pct": "9%",
        })

    def test_06_missing_document_capabilities_remain_a_no_throw_boundary(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(PROGRESS))});
const component=m.createProgressOverlayComponent({{documentRef:{{}}}});
component.updateMetodProgressBadge({{busy:true,progressPct:50}});
component.hideMetodProgressOverlay();
console.log(JSON.stringify({{visible:component.isMetodProgressFallbackVisible(),frozen:Object.isFrozen(component),keys:Reflect.ownKeys(component)}}));
""")
        self.assertEqual(result, {
            "visible": False, "frozen": True,
            "keys": ["hideMetodProgressOverlay", "updateMetodProgressBadge", "isMetodProgressFallbackVisible"],
        })

    def test_07_legacy_functions_are_thin_adapters_and_pricing_reads_component_state(self) -> None:
        html = read_toola_expanded(HTML)
        section = html[html.index("  function hideMetodProgressOverlay(){"):html.index("\n  function updatePriceBar(opts={})")]
        for token in ("createElement", "innerHTML", "getElementById", ".dataset", "#metodProgressOverlay"):
            self.assertNotIn(token, section)
        for method in (
            "hideMetodProgressOverlay", "updateMetodProgressBadge", "isMetodProgressFallbackVisible",
        ):
            self.assertIn(f"owner.{method}", section)
        pending = html[html.index("function _isAuthoritativePricingPending(){"):html.index("function _strictAuthoritativePriceInclVat", html.index("function _isAuthoritativePricingPending(){"))]
        self.assertIn("isMetodProgressFallbackVisible()", pending)
        self.assertNotIn("document.getElementById('metodProgressBadge')", pending)
        raw_html = HTML.read_text(encoding="utf-8")
        for token in ("metodProgressOverlayCard", "#metodProgressOverlay", "metodProgressOverlayStyles"):
            self.assertNotIn(token, raw_html)
        component = PROGRESS.read_text(encoding="utf-8")
        self.assertNotIn('createElement("style")', component)
        self.assertNotIn("PROGRESS_OVERLAY_STYLE_TEXT", component)

    def test_08_bootstrap_publishes_one_frozen_boundary_and_one_progress_owner(self) -> None:
        source = BOOTSTRAP.read_text(encoding="utf-8")
        self.assertEqual(source.count('from "./components/progress-overlay.js"'), 1)
        self.assertEqual(source.count("createProgressOverlayComponent()"), 1)
        self.assertEqual(source.count("Object.defineProperty(globalThis"), 0)
        self.assertEqual(source.count("export const foundationAdapter = passiveAdapter;"), 1)
        self.assertEqual(source.count('new CustomEvent("tool-a:foundation-ready"'), 1)
        self.assertIn('"R9RC1_PROFESSIONAL_ARCHITECTURE_COMPLETION"', source)
        self.assertIn('mode: "legacy-read-cleanup-adapter"', source)
        for method in (
            "hideMetodProgressOverlay", "updateMetodProgressBadge", "isMetodProgressFallbackVisible",
        ):
            self.assertEqual(source.count(f"  {method}:"), 1)

    def test_09_dom_and_io_ownership_are_fail_closed(self) -> None:
        rules = json.loads(RULES.read_text(encoding="utf-8"))["frontend"]
        owners = {
            "app/tool-a/components/dialog.js",
            "app/tool-a/components/footer.js",
            "app/tool-a/components/mobile-material-cart.js",
            "app/tool-a/components/overlay-router.js",
            "app/tool-a/components/panel-editor.js",
            "app/tool-a/components/progress-overlay.js",
            "app/tool-a/components/material-card.js",
            "app/tool-a/components/grain-preview.js",
            "app/tool-a/components/checkout-review.js",
            "app/tool-a/components/thank-you.js",
        }
        self.assertEqual(set(rules["domOwnerModules"]), owners)
        self.assertEqual(set(rules["domOwnerRequiredTokens"]), owners)
        self.assertEqual(set(rules["networkOwnerModules"]), {
            "app/tool-a/api/jobs.js", "app/tool-a/api/requests.js",
        })
        self.assertEqual(rules["moduleImports"]["app/tool-a/components/progress-overlay.js"], [])
        self.assertIn("tool-a/components/progress-overlay.js", rules["publicStaticFiles"])
        source = PROGRESS.read_text(encoding="utf-8")
        for token in (
            "addEventListener", "fetch(", "XMLHttpRequest", "EventSource", "WebSocket",
            "localStorage", "sessionStorage", "defineProperty(globalThis",
        ):
            self.assertNotIn(token, source)
        self.assertEqual(
            assignment_set(APP / "metod_app/http/static.py", "PUBLIC_STATIC_MODULE_FILES"),
            assignment_set(APP / "metod_app/http/static.py", "PUBLIC_STATIC_MODULE_FILES"),
        )

    def test_10_visual_style_is_external_and_markup_remains_sealed(self) -> None:
        source = PROGRESS.read_text(encoding="utf-8")
        markup = re.search(r"export const PROGRESS_OVERLAY_MARKUP = `([\s\S]*?)`;", source)
        self.assertIsNotNone(markup)
        markup_bytes = markup.group(1).encode()
        self.assertEqual((len(markup_bytes), hashlib.sha256(markup_bytes).hexdigest()), (
            1000, "798b96c1137edcc7b6dbfdc1d2b43f69cb48d205730619d8150ace9e81b9642d",
        ))
        css = (APP / "tool-a/styles/runtime-components.css").read_text(encoding="utf-8")
        for token in ("#metodProgressOverlay{", ".metodProgressOverlayCard{", ".metodProgressOverlayRing{"):
            self.assertIn(token, css)
        self.assertNotIn("createElement(\"style\")", source)

    def test_11_protected_algorithms_dialog_markup_and_payload_are_unchanged(self) -> None:
        expected = {
            "dxf_nesting_optimizer.py": "42480b301cd660dac1e5e9fec2c8d30bb5c6826c32234a9c1cce765b758bebb8",
            "dxf_geometry.py": "b80a2d006241908bf7b33516f7e0faf59ef61e1e08db86966b23cc5de292c1ff",
            "pricing_helpers.py": "646c2f5186e9b080f6ba8dcf364884411c18e946254bb5c9001647f7cbb425df",
            "panel_contract.py": "e23314fd63a2358a48daa580a92cebb8a40c9862548ba0243461a59347da7fc9",
        }
        for name, digest in expected.items():
            self.assertEqual(hashlib.sha256((APP / name).read_bytes()).hexdigest(), digest, name)
        html = read_toola_expanded(HTML)
        dialog_start = '<div id="toolAlertOverlay"'
        dialog_end = '<div id="removeMaterialOverlay"'
        dialog = html[html.index(dialog_start):html.index(dialog_end)]
        self.assertNotRegex(dialog, r"\sstyle\s*=")
        self.assertIn('role="dialog"', dialog)
        self.assertEqual(dialog.count('id="toolAlertOkBtn"'), 1)
        start = html.index("async function buildJobPayload(){")
        end = html.index("  // ---------------------------\n  // Checkout overlays (restmateriaal + klantgegevens)", start)
        payload = html[start:end].encode()
        self.assertEqual((len(payload), hashlib.sha256(payload).hexdigest()), (
            9697, "342dac02c2650ac2798e20e62d38d8e1e6b7d518a54daa8fd760d734ae527e47",
        ))

    def test_12_release_preflight_requires_both_r9h_components(self) -> None:
        matrix = json.loads((ROOT / "R9RC3_ACTIVE_TEST_MATRIX.json").read_text(encoding="utf-8"))
        suites = {row["path"] for row in matrix["suites"]}
        self.assertIn("tools/r9h_dialog_component_tests.py", suites)
        self.assertIn("tools/r9h_progress_overlay_tests.py", suites)


if __name__ == "__main__":
    unittest.main(verbosity=2)
