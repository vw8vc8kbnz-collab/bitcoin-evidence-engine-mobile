#!/usr/bin/env python3
from __future__ import annotations

"""Fail-closed behavior and ownership proof for R9H-1 dialog/alert."""

import ast
import base64
import hashlib
import json
import shutil
import subprocess
import unittest
from pathlib import Path

from r9h_shell_source import read_toola_expanded


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
DIALOG = APP / "tool-a/components/dialog.js"
BOOTSTRAP = APP / "tool-a/bootstrap.js"
HELPERS = APP / "toolA_safe_helper_layer.js"
HTML = APP / "toolA.html"
STATIC_CSS = APP / "tool-a/styles/static-utilities.css"
RULES = ROOT / "R9B_ARCHITECTURE_RULES.json"


def data_url(path: Path) -> str:
    return "data:text/javascript;base64," + base64.b64encode(path.read_bytes()).decode()


def run_node(source: str) -> dict:
    node = shutil.which("node")
    if not node:
        raise AssertionError("Node is required by the release architecture gate")
    completed = subprocess.run(
        [node, "--input-type=module"], input=source, text=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=10, check=False,
    )
    if completed.returncode != 0:
        raise AssertionError(completed.stdout)
    return json.loads(completed.stdout.strip().splitlines()[-1])


def fake_dom_probe(body: str) -> dict:
    return run_node(f"""
const module=await import({json.dumps(data_url(DIALOG))});
function fakeElement(id){{
  const listeners={{}};const classes=new Set();
  return {{id,style:{{display:'none'}},textContent:'',focused:0,listeners,
    classList:{{add:(v)=>classes.add(v),remove:(v)=>classes.delete(v),has:(v)=>classes.has(v)}},
    addEventListener:(type,fn)=>{{(listeners[type]||(listeners[type]=[])).push(fn);}},
    emit(type,event={{}}){{for(const fn of listeners[type]||[])fn(event);}},
    focus(){{this.focused+=1;}}
  }};
}}
const ids=['toolAlertOverlay','toolAlertTitle','toolAlertBody','toolAlertDetailsWrap','toolAlertDetails','toolAlertOkBtn','toolAlertCancelBtn'];
const elements=Object.fromEntries(ids.map(id=>[id,fakeElement(id)]));
const documentListeners={{}};
const documentRef={{getElementById:(id)=>elements[id]||null,
 addEventListener:(type,fn)=>{{(documentListeners[type]||(documentListeners[type]=[])).push(fn);}},
 emit(type,event){{for(const fn of documentListeners[type]||[])fn(event);}}}};
const delays=[];const warnings=[];
const component=module.createDialogComponent({{documentRef,
 requestAnimationFrameImpl:(fn)=>fn(),setTimeoutImpl:(fn,ms)=>{{delays.push(ms);fn();}},
 confirmImpl:()=>false,consoleRef:{{warn:(...args)=>warnings.push(args.map(String).join(' '))}}}});
{body}
""")


def assignment_set(path: Path, name: str) -> set[str]:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(
            isinstance(target, ast.Name) and target.id == name for target in node.targets
        ):
            value = node.value
            if isinstance(value, ast.Call) and isinstance(value.func, ast.Name) and value.func.id == "frozenset":
                value = value.args[0]
            return set(ast.literal_eval(value))
    raise AssertionError(name)


class R9HDialogComponentTests(unittest.TestCase):
    def test_01_message_partitioning_is_byte_for_byte_equivalent(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(DIALOG))});
const values=[m.toolAlertParts('', 'Titel'),m.toolAlertParts('Kop\\n\\nTekst\\n\\nDetail 1\\n\\nDetail 2','X'),
 m.toolAlertParts('Kop\\nTekst\\nDetail 1\\nDetail 2','X'),m.toolAlertParts('Enkele tekst','Waarschuwing')];
console.log(JSON.stringify(values));
""")
        self.assertEqual(result, [
            {"title": "Titel", "body": "", "details": ""},
            {"title": "Kop", "body": "Tekst", "details": "Detail 1\n\nDetail 2"},
            {"title": "Kop", "body": "Tekst", "details": "Detail 1\nDetail 2"},
            {"title": "Waarschuwing", "body": "Enkele tekst", "details": ""},
        ])

    def test_02_alert_render_focus_and_listener_binding_are_exact(self) -> None:
        result = fake_dom_probe("""
component.showToolAlert('Kop\\n\\nBericht\\n\\nDetails','Fallback');
component.showToolAlert({title:'Tweede',body:'Body',details:'',okText:'Prima'});
console.log(JSON.stringify({title:elements.toolAlertTitle.textContent,body:elements.toolAlertBody.textContent,
 details:elements.toolAlertDetails.textContent,detailsDisplay:elements.toolAlertDetailsWrap.style.display,
 overlayDisplay:elements.toolAlertOverlay.style.display,open:elements.toolAlertOverlay.classList.has('isOpen'),
 ok:elements.toolAlertOkBtn.textContent,cancelDisplay:elements.toolAlertCancelBtn.style.display,
 focused:elements.toolAlertOkBtn.focused,okListeners:elements.toolAlertOkBtn.listeners.click.length,
 cancelListeners:elements.toolAlertCancelBtn.listeners.click.length,backdropListeners:elements.toolAlertOverlay.listeners.click.length,
 escapeListeners:documentListeners.keydown.length}));
""")
        self.assertEqual(result, {
            "title": "Tweede", "body": "Body", "details": "", "detailsDisplay": "none",
            "overlayDisplay": "flex", "open": True, "ok": "Prima", "cancelDisplay": "none",
            "focused": 2, "okListeners": 1, "cancelListeners": 1,
            "backdropListeners": 1, "escapeListeners": 1,
        })

    def test_03_ok_backdrop_and_escape_preserve_close_semantics(self) -> None:
        result = fake_dom_probe("""
let closed=0;
component.showToolAlert({title:'A',body:'B',onClose:()=>closed++});
elements.toolAlertOverlay.emit('click',{target:elements.toolAlertOverlay});
component.showToolAlert({title:'A',body:'B',onClose:()=>closed++});
documentRef.emit('keydown',{key:'Escape'});
component.showToolAlert({title:'A',body:'B',onClose:()=>closed++});
elements.toolAlertOkBtn.emit('click');
console.log(JSON.stringify({closed,display:elements.toolAlertOverlay.style.display,open:elements.toolAlertOverlay.classList.has('isOpen'),delays}));
""")
        self.assertEqual(result, {"closed": 3, "display": "none", "open": False, "delays": [120, 120, 120]})

    def test_04_confirm_ignores_ambient_dismiss_and_resolves_buttons(self) -> None:
        result = fake_dom_probe("""
const cancelled=component.showToolConfirm({title:'Zeker?',body:'Controle',okText:'Ja',cancelText:'Nee'});
elements.toolAlertOverlay.emit('click',{target:elements.toolAlertOverlay});documentRef.emit('keydown',{key:'Escape'});
const stillOpen=elements.toolAlertOverlay.style.display;
elements.toolAlertCancelBtn.emit('click');const cancelValue=await cancelled;
const accepted=component.showToolConfirm('Doorgaan?');elements.toolAlertOkBtn.emit('click');const okValue=await accepted;
console.log(JSON.stringify({stillOpen,cancelValue,okValue,ok:elements.toolAlertOkBtn.textContent,
 cancel:elements.toolAlertCancelBtn.textContent,delays}));
""")
        self.assertEqual(result, {
            "stillOpen": "flex", "cancelValue": False, "okValue": True,
            "ok": "Doorgaan", "cancel": "Annuleren", "delays": [120, 120],
        })

    def test_05_missing_markup_fails_safe_to_the_existing_console_contract(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(DIALOG))});const warnings=[];
const component=m.createDialogComponent({{documentRef:{{getElementById:()=>null}},consoleRef:{{warn:(...v)=>warnings.push(v.map(String).join(' '))}}}});
const value=component.showToolAlert('Probleem');console.log(JSON.stringify({{warnings,value:value??null}}));
""")
        self.assertEqual(result, {
            "warnings": ["toolAlertOverlay ontbreekt; fallback naar console", "Probleem"],
            "value": None,
        })

    def test_06_hard_fallback_keeps_its_visual_card_and_async_close_contract(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(DIALOG))});const elements={{}};let appended=0;
function el(id){{const listeners={{}},classes=new Set();return elements[id]={{id,style:{{display:'none'}},textContent:'',focused:0,listeners,
 classList:{{add:v=>classes.add(v),remove:v=>classes.delete(v),contains:v=>classes.has(v)}},
 setAttribute(){{}},addEventListener:(t,f)=>{{(listeners[t]||(listeners[t]=[])).push(f);}},
 emit(t,e={{}}){{for(const f of listeners[t]||[])f(e);}},focus(){{this.focused++;}}}};}}
const body={{style:{{overflow:''}},appendChild(node){{appended++;elements[node.id]=node;}}}};
const documentRef={{body,getElementById:(id)=>elements[id]||null,createElement:()=>{{
 const overlay=el('toolAlertDirectOverlay');let html='';Object.defineProperty(overlay,'innerHTML',{{get:()=>html,set:(value)=>{{
  html=String(value);for(const id of ['toolAlertDirectTitle','toolAlertDirectBody','toolAlertDirectDetailsWrap','toolAlertDirectDetails','toolAlertDirectOkBtn'])el(id);
 }}}});return overlay;}}}};
const component=m.createDialogComponent({{documentRef,requestAnimationFrameImpl:(fn)=>fn()}});let closed=0;
const shown=component.showToolAlertHardFallback({{title:'Nood',body:'Bericht',details:'Details',onClose:()=>closed++}});
const firstHtml=elements.toolAlertDirectOverlay.innerHTML;const promise=component.showToolAlertHardFallbackAsync({{title:'Nogmaals',body:'B',onClose:()=>closed++}});
elements.toolAlertDirectOkBtn.emit('click');const resolved=await promise;
console.log(JSON.stringify({{shown,resolved,closed,appended,title:elements.toolAlertDirectTitle.textContent,
 body:elements.toolAlertDirectBody.textContent,detailsDisplay:elements.toolAlertDirectDetailsWrap.style.display,
 display:elements.toolAlertDirectOverlay.style.display,overflow:body.style.overflow,focused:elements.toolAlertDirectOkBtn.focused,
 listeners:elements.toolAlertDirectOkBtn.listeners.click.length,hasCard:firstHtml.includes('toolAlertDirectCard'),
 hasPresentationClass:elements.toolAlertDirectOverlay.classList.contains('tool-alert-direct-overlay')}}));
""")
        self.assertEqual(result, {
            "shown": True, "resolved": True, "closed": 1, "appended": 3,
            "title": "Nogmaals", "body": "B", "detailsDisplay": "none",
            "display": "none", "overflow": "", "focused": 2, "listeners": 1,
            "hasCard": True, "hasPresentationClass": True,
        })

    def test_07_legacy_helpers_are_only_thin_temporary_adapters(self) -> None:
        source = HELPERS.read_text(encoding="utf-8")
        section = source[source.index("/* --- toolA_alert_helpers.js --- */"):source.index("/* --- toolA_dom_helpers.js --- */")]
        for token in ("getElementById", "addEventListener", "requestAnimationFrame", "__toolAlertOnClose"):
            self.assertNotIn(token, section)
        self.assertEqual(section.count("toolAFoundation"), 1)
        self.assertNotIn("ToolAR9Foundation", section)
        for method in ("toolAlertParts", "closeToolAlert", "showToolAlert", "showToolConfirm"):
            self.assertIn(f"owner.{method}", section)
        html = read_toola_expanded(HTML)
        hard = html[html.index("function showToolAlertHardFallback(opts)"):html.index("window.showToolAlertHardFallback =")]
        for token in ("createElement", "innerHTML", "toolAlertDirectCard", "addEventListener"):
            self.assertNotIn(token, hard)
        self.assertIn("owner.showToolAlertHardFallback(opts)", hard)
        self.assertIn("owner.showToolAlertHardFallbackAsync(opts)", hard)

    def test_08_bootstrap_exposes_one_frozen_boundary_and_one_dialog_owner(self) -> None:
        source = BOOTSTRAP.read_text(encoding="utf-8")
        self.assertEqual(source.count('from "./components/dialog.js"'), 1)
        self.assertEqual(source.count("createDialogComponent()"), 1)
        self.assertEqual(source.count("Object.defineProperty(globalThis"), 0)
        self.assertEqual(source.count("export const foundationAdapter = passiveAdapter;"), 1)
        self.assertEqual(source.count('new CustomEvent("tool-a:foundation-ready"'), 1)
        self.assertIn('"R9RC1_PROFESSIONAL_ARCHITECTURE_COMPLETION"', source)
        self.assertIn('mode: "legacy-read-cleanup-adapter"', source)
        for method in (
            "toolAlertParts", "closeToolAlert", "showToolAlert", "showToolConfirm",
            "showToolAlertHardFallback", "showToolAlertHardFallbackAsync",
        ):
            self.assertEqual(source.count(f"  {method}:"), 1)

    def test_09_dom_event_and_io_ownership_are_fail_closed(self) -> None:
        rules = json.loads(RULES.read_text(encoding="utf-8"))["frontend"]
        relative = "app/tool-a/components/dialog.js"
        self.assertEqual(set(rules["domOwnerModules"]), {
            relative, "app/tool-a/components/footer.js", "app/tool-a/components/mobile-material-cart.js",
            "app/tool-a/components/overlay-router.js",
            "app/tool-a/components/progress-overlay.js", "app/tool-a/components/material-card.js",
            "app/tool-a/components/panel-editor.js",
            "app/tool-a/components/grain-preview.js",
            "app/tool-a/components/checkout-review.js",
            "app/tool-a/components/thank-you.js",
        })
        self.assertEqual(set(rules["networkOwnerModules"]), {
            "app/tool-a/api/jobs.js", "app/tool-a/api/requests.js",
        })
        self.assertEqual(rules["moduleImports"][relative], [])
        self.assertIn("tool-a/components/dialog.js", rules["publicStaticFiles"])
        source = DIALOG.read_text(encoding="utf-8")
        self.assertIn("documentRef", source)
        self.assertIn("addEventListener", source)
        for token in ("fetch(", "XMLHttpRequest", "EventSource", "WebSocket", "localStorage", "sessionStorage", "defineProperty(globalThis"):
            self.assertNotIn(token, source)
        self.assertEqual(
            assignment_set(APP / "metod_app/http/static.py", "PUBLIC_STATIC_MODULE_FILES"),
            assignment_set(APP / "metod_app/http/static.py", "PUBLIC_STATIC_MODULE_FILES"),
        )

    def test_10_dialog_markup_and_external_presentation_contract_are_complete(self) -> None:
        current = read_toola_expanded(HTML)
        start = '<div id="toolAlertOverlay"'
        end = '<div id="removeMaterialOverlay"'
        current_fragment = current[current.index(start):current.index(end)]
        self.assertNotRegex(current_fragment, r"\sstyle\s*=")
        for element_id in (
            "toolAlertOverlay", "toolAlertTitle", "toolAlertBody", "toolAlertDetailsWrap",
            "toolAlertDetails", "toolAlertCancelBtn", "toolAlertOkBtn",
        ):
            self.assertEqual(current_fragment.count(f'id="{element_id}"'), 1, element_id)
        self.assertIn('role="dialog"', current_fragment)
        self.assertIn('aria-modal="true"', current_fragment)
        css = STATIC_CSS.read_text(encoding="utf-8")
        self.assertIn(".tool-alert-direct-overlay{position:fixed", css)
        self.assertIn(".tool-u-69f03d325701{display:none;", css)

    def test_11_protected_behavior_and_release_gate_remain_bound(self) -> None:
        expected = {
            "dxf_nesting_optimizer.py": "42480b301cd660dac1e5e9fec2c8d30bb5c6826c32234a9c1cce765b758bebb8",
            "dxf_geometry.py": "b80a2d006241908bf7b33516f7e0faf59ef61e1e08db86966b23cc5de292c1ff",
            "pricing_helpers.py": "646c2f5186e9b080f6ba8dcf364884411c18e946254bb5c9001647f7cbb425df",
            "panel_contract.py": "e23314fd63a2358a48daa580a92cebb8a40c9862548ba0243461a59347da7fc9",
        }
        for name, digest in expected.items():
            self.assertEqual(hashlib.sha256((APP / name).read_bytes()).hexdigest(), digest, name)
        html = read_toola_expanded(HTML)
        start = html.index("async function buildJobPayload(){")
        end = html.index("  // ---------------------------\n  // Checkout overlays (restmateriaal + klantgegevens)", start)
        payload = html[start:end].encode()
        self.assertEqual((len(payload), hashlib.sha256(payload).hexdigest()), (
            9697, "342dac02c2650ac2798e20e62d38d8e1e6b7d518a54daa8fd760d734ae527e47",
        ))
        matrix = json.loads((ROOT / "R9RC3_ACTIVE_TEST_MATRIX.json").read_text(encoding="utf-8"))
        self.assertIn(
            "tools/r9h_dialog_component_tests.py",
            {row["path"] for row in matrix["suites"]},
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
