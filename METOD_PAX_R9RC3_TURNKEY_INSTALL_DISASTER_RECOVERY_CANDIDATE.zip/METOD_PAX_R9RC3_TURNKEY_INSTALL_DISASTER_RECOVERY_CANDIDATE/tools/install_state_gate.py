#!/usr/bin/env python3
from __future__ import annotations

"""Fail-closed external-state and credential gate for install/recovery flows.

The gate deliberately reports structure and counts only.  It never prints
customer records, filenames below private state domains, password hashes or
TOTP secrets.
"""

import argparse
import base64
import json
import math
import os
import re
import stat
from pathlib import Path


REQUIRED_DIRECTORIES = frozenset({
    "archive", "backups", "client_logs", "config", "decor_media", "drafts",
    "embedded_dxfs", "index", "jobs", "queue", "requests", "system",
})
REQUIRED_FILES = frozenset({
    ".fix660r8_external_state_v1.json", "embedded_dxfs_manifest.json",
    "material_library.json", "config/pricing_active.json",
})
MAX_ENTRIES = 1_000_000
PASSWORD_HASH = re.compile(
    r"pbkdf2_sha256\$600000\$[A-Za-z0-9._-]{16,128}\$[a-f0-9]{64}"
)
USERNAME = re.compile(r"[A-Za-z0-9_.@-]{3,80}")


def strict_json(path: Path):
    def reject_constant(value: str):
        raise ValueError(f"non-finite JSON constant {value}")

    return json.loads(
        path.read_text(encoding="utf-8", errors="strict"),
        parse_constant=reject_constant,
    )


def _contained_regular(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
    except ValueError:
        return False
    mode = path.lstat().st_mode
    return stat.S_ISREG(mode) and not path.is_symlink()


def inspect_tree(root: Path) -> dict[str, int]:
    entries = files = directories = 0
    stack = [root]
    while stack:
        directory = stack.pop()
        with os.scandir(directory) as scan:
            for item in scan:
                entries += 1
                if entries > MAX_ENTRIES:
                    raise ValueError(f"state bevat meer dan {MAX_ENTRIES} entries")
                mode = item.stat(follow_symlinks=False).st_mode
                if stat.S_ISLNK(mode):
                    raise ValueError("symlink in externe state is verboden")
                if stat.S_ISDIR(mode):
                    directories += 1
                    stack.append(Path(item.path))
                elif stat.S_ISREG(mode):
                    files += 1
                else:
                    raise ValueError("speciaal bestand in externe state is verboden")
    return {"entries": entries, "files": files, "directories": directories}


def validate_credentials(path: Path, *, production: bool) -> int:
    if path.is_symlink() or not path.is_file():
        raise ValueError("credentials zijn geen regulier bestand")
    if stat.S_IMODE(path.stat().st_mode) not in {0o400, 0o600}:
        raise ValueError("credentials moeten mode 0400 of 0600 hebben")
    value = strict_json(path)
    users = value.get("users") if isinstance(value, dict) else None
    if not isinstance(users, list) or not users:
        raise ValueError("credentials missen individuele users[]")
    active = 0
    seen: set[str] = set()
    for user in users:
        if not isinstance(user, dict) or user.get("active") is False:
            continue
        active += 1
        username = str(user.get("username") or "")
        if not USERNAME.fullmatch(username) or username in seen:
            raise ValueError("ongeldige of dubbele actieve adminusername")
        seen.add(username)
        if not PASSWORD_HASH.fullmatch(str(user.get("password_hash") or "")):
            raise ValueError("adminhash wijkt af van PBKDF2-SHA256/600000-contract")
        if str(user.get("password") or "").strip():
            raise ValueError("plaintext adminwachtwoord is verboden")
        if production:
            secret = re.sub(r"\s+", "", str(user.get("totp_secret") or "")).upper()
            if not re.fullmatch(r"[A-Z2-7]{16,128}", secret):
                raise ValueError("production-admin mist geldig TOTP-contract")
            decoded = base64.b32decode(
                secret + "=" * ((8 - len(secret) % 8) % 8), casefold=True
            )
            if len(decoded) < 10 or "admin" not in set(user.get("roles") or []):
                raise ValueError("production-admin mist voldoende TOTP-entropie/adminrol")
    if active < 1:
        raise ValueError("geen actief individueel adminaccount")
    return active


def validate_state(root: Path) -> dict[str, int]:
    if root.is_symlink() or not root.is_dir():
        raise ValueError("externe state is geen echte directory")
    top = {item.name: item for item in root.iterdir()}
    missing_dirs = sorted(name for name in REQUIRED_DIRECTORIES if not (root / name).is_dir())
    missing_files = sorted(name for name in REQUIRED_FILES if not (root / name).is_file())
    if missing_dirs or missing_files:
        raise ValueError(
            f"statecontract incompleet: {len(missing_dirs)} map(pen), "
            f"{len(missing_files)} bestand(en) ontbreken"
        )
    if any(item.is_symlink() for item in top.values()):
        raise ValueError("symlink op state-rootniveau is verboden")
    counts = inspect_tree(root)

    marker = strict_json(root / ".fix660r8_external_state_v1.json")
    if not isinstance(marker, dict) or marker.get("schemaVersion") != 1:
        raise ValueError("R8 externe-state-migratiemarkering is ongeldig")

    library_path = root / "material_library.json"
    if not _contained_regular(library_path, root):
        raise ValueError("materiaalcatalogus is geen regulier statebestand")
    library = strict_json(library_path)
    records = library.get("records") if isinstance(library, dict) else None
    if not isinstance(records, list):
        raise ValueError("materiaalcatalogus mist records[]")
    active = [
        record for record in records
        if isinstance(record, dict)
        and str(record.get("sourceKind") or "").upper() == "CATALOG_IMPORT"
        and record.get("active") is not False
        and record.get("archived") is not True
        and record.get("published") is True
        and record.get("catalogMissing") is not True
        and record.get("catalogExcluded") is not True
    ]
    if not active:
        raise ValueError("actieve gepubliceerde catalogus is leeg")
    for record in active:
        if float(record.get("sellPriceInclVatPerSheet") or 0) <= 0:
            raise ValueError("actief materiaal zonder positieve plaatprijs")
        if float(record.get("thicknessMm") or 0) not in {18.0, 19.0, 20.0}:
            raise ValueError("actief materiaal met verboden dikte")
        if float(record.get("sheetWid") or 0) <= 0 or float(record.get("sheetLen") or 0) <= 0:
            raise ValueError("actief materiaal zonder geldige plaatmaat")

    pricing = strict_json(root / "config/pricing_active.json")
    sell = pricing.get("sellPricing") if isinstance(pricing, dict) else None
    if not isinstance(sell, dict) or "sheetPriceFactor" in sell:
        raise ValueError("pricing gebruikt niet het actuele mixed-VAT-contract")
    for key in ("edgeBandPricePerM", "cncCostPerSheet", "drawingCostFixed", "transportCostFixed"):
        value = float(sell.get(key, -1))
        if not math.isfinite(value) or value < 0:
            raise ValueError(f"ongeldige pricingwaarde: {key}")
    counts["catalogRecords"] = len(records)
    counts["activeCatalogRecords"] = len(active)
    return counts


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--state-root", type=Path, required=True)
    parser.add_argument("--credentials", type=Path, required=True)
    parser.add_argument("--production", action="store_true")
    args = parser.parse_args()
    try:
        state = args.state_root.resolve(strict=True)
        credentials = args.credentials.resolve(strict=True)
        if state == credentials or state in credentials.parents:
            raise ValueError("credentials mogen niet binnen klantstate staan")
        result = validate_state(state)
        result["activeAdmins"] = validate_credentials(credentials, production=args.production)
    except Exception as exc:
        print(f"INSTALL STATE GATE: FAIL: {exc}")
        return 1
    print("INSTALL STATE GATE: PASS")
    print(json.dumps(result, sort_keys=True, separators=(",", ":")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
