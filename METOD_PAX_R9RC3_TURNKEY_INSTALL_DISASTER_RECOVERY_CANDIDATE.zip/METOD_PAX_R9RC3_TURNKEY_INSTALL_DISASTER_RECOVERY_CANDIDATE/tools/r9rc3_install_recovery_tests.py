#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import os
import stat
import subprocess
import sys
import tarfile
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))

import install_state_gate as gate  # noqa: E402
import migration_bundle_tool as migration  # noqa: E402


VALID_HASH = "pbkdf2_sha256$600000$testsalt01234567$" + "a" * 64


class R9RC3InstallRecoveryTests(unittest.TestCase):
    def setUp(self) -> None:
        self.holder = tempfile.TemporaryDirectory(prefix="r9rc3-install-")
        self.root = Path(self.holder.name)

    def tearDown(self) -> None:
        self.holder.cleanup()

    def make_state(self, parent: Path | None = None) -> tuple[Path, Path]:
        base = parent or self.root
        state = base / "state"
        state.mkdir(parents=True)
        for name in sorted(gate.REQUIRED_DIRECTORIES):
            (state / name).mkdir(parents=True, exist_ok=True)
        (state / ".fix660r8_external_state_v1.json").write_text(
            '{"schemaVersion":1,"source":"/opt/adzaagt/metod-pax"}\n', encoding="utf-8"
        )
        library = {"source": "CSV_CATALOG_ONLY", "records": [{
            "sourceKind": "CATALOG_IMPORT", "active": True, "archived": False,
            "published": True, "catalogMissing": False, "catalogExcluded": False,
            "sellPriceInclVatPerSheet": 100.0, "thicknessMm": 18.0,
            "sheetWid": 2070.0, "sheetLen": 2800.0,
        }]}
        (state / "material_library.json").write_text(json.dumps(library), encoding="utf-8")
        (state / "embedded_dxfs_manifest.json").write_text('{"items":[]}\n', encoding="utf-8")
        pricing = {"sellPricing": {
            "edgeBandPricePerM": 1.0, "cncCostPerSheet": 1.0,
            "drawingCostFixed": 1.0, "transportCostFixed": 1.0,
        }}
        (state / "config/pricing_active.json").write_text(json.dumps(pricing), encoding="utf-8")
        credentials = base / "admin_credentials.live.json"
        credentials.write_text(json.dumps({"schemaVersion": 2, "users": [{
            "username": "auditor", "password_hash": VALID_HASH,
            "totp_secret": "JBSWY3DPEHPK3PXP", "roles": ["admin"], "active": True,
        }]}), encoding="utf-8")
        credentials.chmod(0o600)
        return state, credentials

    def test_01_valid_external_state_and_credentials_pass_without_pii_output(self) -> None:
        state, credentials = self.make_state()
        result = gate.validate_state(state)
        self.assertEqual(result["activeCatalogRecords"], 1)
        self.assertEqual(gate.validate_credentials(credentials, production=True), 1)

    def test_02_state_gate_rejects_links_special_files_and_empty_catalog(self) -> None:
        state, _ = self.make_state()
        (state / "jobs/escape").symlink_to(self.root / "outside")
        with self.assertRaisesRegex(ValueError, "symlink"):
            gate.validate_state(state)
        (state / "jobs/escape").unlink()
        library = json.loads((state / "material_library.json").read_text(encoding="utf-8"))
        library["records"][0]["published"] = False
        (state / "material_library.json").write_text(json.dumps(library), encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "catalogus is leeg"):
            gate.validate_state(state)

    def test_03_credentials_fail_closed_on_plaintext_mode_and_mfa(self) -> None:
        _, credentials = self.make_state()
        credentials.chmod(0o644)
        with self.assertRaisesRegex(ValueError, "mode"):
            gate.validate_credentials(credentials, production=True)
        credentials.chmod(0o600)
        value = json.loads(credentials.read_text(encoding="utf-8"))
        value["users"][0]["password"] = "must-never-exist"
        credentials.write_text(json.dumps(value), encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "plaintext"):
            gate.validate_credentials(credentials, production=True)

    def test_04_manifested_payload_roundtrip_is_byte_exact(self) -> None:
        payload = self.root / migration.PAYLOAD_ROOT
        state, credentials = self.make_state(payload)
        config = payload / "config"
        config.mkdir()
        target_credentials = config / "admin_credentials.live.json"
        target_credentials.write_bytes(credentials.read_bytes())
        target_credentials.chmod(0o600)
        credentials.unlink()
        migration.create_manifest(payload)
        archive = self.root / "migration.tar"
        with tarfile.open(archive, "w:") as handle:
            handle.add(payload, arcname=migration.PAYLOAD_ROOT, recursive=True)
        extracted = migration.extract_archive(archive, self.root / "extracted")
        self.assertEqual(
            hashlib.sha256((extracted / "state/material_library.json").read_bytes()).hexdigest(),
            hashlib.sha256((state / "material_library.json").read_bytes()).hexdigest(),
        )

    def test_05_archive_traversal_and_links_are_rejected(self) -> None:
        archive = self.root / "attack.tar"
        source = self.root / "source"
        source.write_text("attack", encoding="utf-8")
        with tarfile.open(archive, "w:") as handle:
            handle.add(source, arcname="../escape")
        with self.assertRaisesRegex(ValueError, "onveilig pad"):
            migration.extract_archive(archive, self.root / "attack-output")

    def test_06_install_scripts_parse_and_keep_modes_explicit(self) -> None:
        installer = ROOT / "INSTALL_FIX660R8_FROM_STAGE.sh"
        exporter = ROOT / "EXPORT_METOD_PAX_MIGRATION_BUNDLE.sh"
        clean = ROOT / "INSTALL_METOD_PAX_CLEAN_SERVER.sh"
        for script in (installer, exporter, clean):
            completed = subprocess.run(["bash", "-n", str(script)], check=False)
            self.assertEqual(completed.returncode, 0, script.name)
        source = installer.read_text(encoding="utf-8")
        self.assertIn('INSTALL_MODE="${METOD_INSTALL_MODE:-upgrade}"', source)
        self.assertIn("upgrade|recovery|bootstrap", source)
        self.assertIn("ORPHANED_RELEASE_AND_STATE_CONFIRMED", source)
        self.assertIn("CLEAN_SERVER_STATE_IMPORT_CONFIRMED", source)
        self.assertIn('tar --one-file-system --numeric-owner --xattrs --acls', source)
        self.assertLess(source.index('systemctl stop metod-pax.service'), source.index('external-state.tar'))
        self.assertLess(source.index('external-state.tar'), source.index('mv -Tf "$CURRENT_LINK.next"'))

    def test_07_migration_is_encrypted_and_clean_import_does_not_source_old_env(self) -> None:
        exporter = (ROOT / "EXPORT_METOD_PAX_MIGRATION_BUNDLE.sh").read_text(encoding="utf-8")
        clean = (ROOT / "INSTALL_METOD_PAX_CLEAN_SERVER.sh").read_text(encoding="utf-8")
        self.assertIn("--symmetric", exporter)
        self.assertIn("--cipher-algo AES256", exporter)
        self.assertIn("--s2k-digest-algo SHA512", exporter)
        self.assertIn("--decrypt", clean)
        self.assertIn("migration_bundle_tool.py", clean)
        self.assertNotIn("source $PAYLOAD/config/metod-pax.env.previous", clean)
        self.assertNotIn(". $PAYLOAD/config/metod-pax.env.previous", clean)
        self.assertIn("METOD_INSTALL_PACKAGES", clean)

    def test_08_recovery_rollback_never_pretends_deleted_code_can_return(self) -> None:
        source = (ROOT / "INSTALL_FIX660R8_FROM_STAGE.sh").read_text(encoding="utf-8")
        rollback = source[source.index("rollback(){"):source.index("\ntrap rollback EXIT")]
        self.assertIn('INSTALL_MODE" == "recovery"', rollback)
        self.assertIn("maintenance blijft actief", rollback)
        self.assertIn("service blijft gestopt", rollback)
        self.assertNotIn("ORPHANED_RELEASE_AND_STATE_CONFIRMED:-", source)


if __name__ == "__main__":
    unittest.main(verbosity=2)
