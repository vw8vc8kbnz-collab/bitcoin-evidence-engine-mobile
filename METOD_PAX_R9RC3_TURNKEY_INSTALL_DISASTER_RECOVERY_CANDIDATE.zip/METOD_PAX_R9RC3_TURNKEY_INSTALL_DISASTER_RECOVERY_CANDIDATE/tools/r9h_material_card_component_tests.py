#!/usr/bin/env python3
from __future__ import annotations

"""Fail-closed R9H-5 material-card behavior, visual and ownership proof."""

import ast
import base64
import hashlib
import json
import re
import shutil
import subprocess
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
HTML = APP / "toolA.html"
BOOTSTRAP = APP / "tool-a/bootstrap.js"
COMPONENT = APP / "tool-a/components/material-card.js"
DECOR = APP / "decor_library.js"
RULES = ROOT / "R9B_ARCHITECTURE_RULES.json"


def data_url(path: Path) -> str:
    return "data:text/javascript;base64," + base64.b64encode(path.read_bytes()).decode()


def run_node(source: str) -> dict:
    node = shutil.which("node")
    if not node:
        raise AssertionError("Node is required by the release architecture gate")
    completed = subprocess.run(
        [node, "--input-type=module"], input=source, text=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=10, check=False,
    )
    if completed.returncode != 0:
        raise AssertionError(completed.stdout)
    return json.loads(completed.stdout.strip().splitlines()[-1])


def assignment_set(path: Path, name: str) -> set[str]:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(
            isinstance(target, ast.Name) and target.id == name for target in node.targets
        ):
            value = node.value
            if isinstance(value, ast.Call) and isinstance(value.func, ast.Name) and value.func.id == "frozenset":
                value = value.args[0]
            return set(ast.literal_eval(value))
    raise AssertionError(name)


class R9HMaterialCardComponentTests(unittest.TestCase):
    def test_01_model_preserves_public_key_labels_fineer_and_selection(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});
const material={{publicMaterialId:' m<& ',publicName:'Eiken <A>',brand:'Overig',primaryVisualFamily:'Hout',substrateType:'MDF',thicknessMm:18,sheetSizeMm:{{width:2070,height:2800}},imageThumbUrl:'https://x.test/a&b.jpg'}};
console.log(JSON.stringify({{build:m.MATERIAL_CARD_COMPONENT_BUILD,model:m.getMaterialCardModel(material,{{activeMaterialKey:'m<&',position:0}})}}));
""")
        self.assertEqual(result["build"], "R9H_MATERIAL_CARD_COMPONENT_5")
        model = result["model"]
        self.assertEqual((model["key"], model["name"], model["brand"]), ("m<&", "Eiken <A>", "Fineer"))
        self.assertEqual((model["type"], model["substrate"], model["thickness"]), ("Hout", "MDF", "18 mm"))
        self.assertEqual(model["sheetSize"], "2800 × 2070 mm")
        self.assertTrue(model["selected"])
        self.assertTrue(model["imageEager"])

    def test_02_image_card_markup_is_byte_exact_to_the_r9h4_owner(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});
const material={{publicMaterialId:'m<&',publicName:'Eiken <A>',brand:'Overig',primaryVisualFamily:'Hout',substrateType:'MDF',thicknessMm:18,sheetSizeMm:{{width:2070,height:2800}},imageThumbUrl:'https://x.test/a&b.jpg'}};
console.log(JSON.stringify({{html:m.renderMaterialCard(material,{{activeMaterialKey:'m<&',position:0}})}}));
""")
        markup = result["html"].encode()
        self.assertEqual((len(markup), hashlib.sha256(markup).hexdigest()),
            (636, "ce333c34a67c54433f49b369fd1714449559d035cacbeac03240c5e5360a221e"))
        self.assertIn('loading="eager" decoding="async" fetchpriority="high"', result["html"])
        self.assertIn('aria-pressed="true"', result["html"])

    def test_03_placeholder_card_markup_and_fractional_sheet_size_are_exact(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});
const material={{articleNumber:'U1',decorName:'Uni Wit',brand:'Merk',primaryVisualFamily:'Uni',substrateLabel:'Spaanplaat',thicknessMm:18.5,sheetSizeMm:{{width:2100.2,height:3000.7}}}};
console.log(JSON.stringify({{model:m.getMaterialCardModel(material,{{activeMaterialKey:'other',position:8}}),html:m.renderMaterialCard(material,{{activeMaterialKey:'other',position:8}})}}));
""")
        markup = result["html"].encode()
        self.assertEqual((len(markup), hashlib.sha256(markup).hexdigest()),
            (551, "c5b2eaa0de6844e6f6896f120d6d70c3c8e5d823ae68ca14c494549ced168632"))
        self.assertEqual(result["model"]["sheetSize"], "3000,7 × 2100,2 mm")
        self.assertEqual(result["model"]["placeholderSymbol"], "○")
        self.assertFalse(result["model"]["selected"])

    def test_04_all_primary_visual_families_and_substrates_keep_exact_labels(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});
const families=['Hout','Uni','Steen & beton','Steen','Beton','Metaal','Textiel & leer','Textiel','Grafisch','Fantasie','Onbekend'];
const substrates=['MDF','SPAANPLAAT','MULTIPLEX','OVERIG','ONBEKEND','x'];
console.log(JSON.stringify({{families:families.map(primaryVisualFamily=>m.getMaterialCardModel({{primaryVisualFamily}})),substrates:substrates.map(substrateType=>m.getMaterialCardModel({{substrateType}}).substrate)}}));
""")
        self.assertEqual([item["bucket"] for item in result["families"]],
            ["wood", "uni", "stone", "stone", "stone", "metal", "textile", "textile", "graphic", "fantasy", "other"])
        self.assertEqual([item["type"] for item in result["families"]],
            ["Hout", "Uni", "Steen & beton", "Steen & beton", "Steen & beton", "Metaal", "Textiel & leer", "Textiel & leer", "Grafisch", "Fantasie", "Decor"])
        self.assertEqual(result["substrates"], ["MDF", "Spaanplaat", "Multiplex", "Overig", "Onbekend", "Onbekend"])

    def test_05_invalid_input_is_frozen_escaped_and_never_leaks_private_fields(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});
const model=m.getMaterialCardModel(null);const html=m.renderMaterialCard({{publicMaterialId:'<x>',publicName:'<script>',internalArticle:'PRIVATE_SENTINEL'}});
console.log(JSON.stringify({{frozen:Object.isFrozen(model),keys:Reflect.ownKeys(model),model,html}}));
""")
        self.assertTrue(result["frozen"])
        self.assertEqual(result["model"]["name"], "Decor")
        self.assertIn("&lt;script&gt;", result["html"])
        self.assertNotIn("PRIVATE_SENTINEL", result["html"])
        self.assertEqual(len(result["keys"]), 13)

    def test_06_grid_click_selects_one_exact_catalog_material_and_is_idempotent(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});
const listeners={{}};const grid={{addEventListener:(t,fn)=>{{(listeners[t]||(listeners[t]=[])).push(fn);}},contains:()=>true}};
const root={{addEventListener:(t,fn,c)=>{{(listeners['root-'+t]||(listeners['root-'+t]=[])).push([fn,c]);}}}};
const selected=[];const component=m.createMaterialCardComponent({{documentRef:{{}},rootRef:{{}}}});
const opts={{grid,fallbackRoot:root,getCatalog:()=>[{{publicMaterialId:'a'}},{{publicMaterialId:'b',publicName:'B'}}],getSelectedKey:()=> 'a',onSelect:(mat,meta)=>selected.push([mat.publicMaterialId,meta])}};
component.bind(opts);component.bind(opts);
const button={{getAttribute:()=> 'b'}};listeners.click[0]({{target:{{closest:()=>button}}}});
console.log(JSON.stringify({{selected,clicks:listeners.click.length,errors:listeners['root-error'].length,capture:listeners['root-error'][0][1]}}));
""")
        self.assertEqual(result["selected"], [["b", {"id": "b", "wasSelected": False}]])
        self.assertEqual((result["clicks"], result["errors"], result["capture"]), (1, 1, True))

    def test_07_outside_unknown_and_callback_free_clicks_are_side_effect_free(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});
const listeners={{}};let inside=false;const grid={{addEventListener:(t,fn)=>listeners[t]=fn,contains:()=>inside}};let calls=0;
const component=m.createMaterialCardComponent({{documentRef:{{}},rootRef:{{}}}});component.bind({{grid,getCatalog:()=>[{{publicMaterialId:'a'}}],onSelect:()=>calls++}});
const button={{getAttribute:()=> 'a'}};listeners.click({{target:{{closest:()=>button}}}});inside=true;button.getAttribute=()=> 'missing';listeners.click({{target:{{closest:()=>button}}}});
console.log(JSON.stringify({{calls,missing:component.bind({{}})}}));
""")
        self.assertEqual(result, {"calls": 0, "missing": False})

    def test_08_broken_images_get_one_exact_placeholder_for_every_symbol_family(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});
const listeners={{}};const root={{addEventListener:(t,fn,c)=>listeners[t]=[fn,c]}};const made=[];
const documentRef={{createElement:()=>{{const el={{dataset:{{}},setAttribute:(k,v)=>el[k]=v}};made.push(el);return el;}}}};
const component=m.createMaterialCardComponent({{documentRef,rootRef:{{}}}});component.bind({{grid:root,fallbackRoot:root,getCatalog:()=>[]}});
function probe(bucket){{let replacement=null;const img={{tagName:'img',hasAttribute:()=>true,getAttribute:()=>bucket,replaceWith:v=>replacement=v}};listeners.error[0]({{target:img}});return [replacement.className,replacement.dataset.type,replacement['aria-hidden'],replacement.textContent];}}
console.log(JSON.stringify({{wood:probe('wood'),stone:probe('stone'),metal:probe('metal'),other:probe('other'),capture:listeners.error[1]}}));
""")
        self.assertEqual(result["wood"], ["decorPlaceholder", "wood", "true", "▥"])
        self.assertEqual(result["stone"], ["decorPlaceholder", "stone", "true", "◫"])
        self.assertEqual(result["metal"], ["decorPlaceholder", "metal", "true", "▦"])
        self.assertEqual(result["other"], ["decorPlaceholder", "other", "true", "○"])
        self.assertTrue(result["capture"])

    def test_09_ready_event_and_missing_dom_are_idempotent_no_throw_boundaries(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});const events=[];class E{{constructor(type){{this.type=type;}}}}
const component=m.createMaterialCardComponent({{documentRef:{{dispatchEvent:e=>events.push(e.type)}},rootRef:{{Event:E}}}});
console.log(JSON.stringify({{first:component.announceReady(),second:component.announceReady(),events,frozen:Object.isFrozen(component),keys:Reflect.ownKeys(component),bind:component.bind(null)}}));
""")
        self.assertEqual((result["first"], result["second"], result["events"]),
            (True, False, ["tool-a-material-card-owner-ready"]))
        self.assertTrue(result["frozen"])
        self.assertEqual(result["keys"], ["BUILD", "getModel", "render", "bind", "announceReady"])
        self.assertFalse(result["bind"])

    def test_10_decor_library_is_a_thin_card_adapter_without_a_second_event_owner(self) -> None:
        source = DECOR.read_text(encoding="utf-8")
        card = source[source.index("  function cardHtml(m, position){"):source.index("\n  function renderSelected(){")]
        self.assertIn("renderMaterialCard", card)
        for token in ("decorCardMedia", "decorCardBody", "decorSelectedCheck", "EAGER_IMAGE_COUNT"):
            self.assertNotIn(token, card)
        owner = source[source.index("  function bindMaterialCardOwner("):source.index("\n  function ensureUi(){")]
        self.assertIn("bindMaterialCardGrid", owner)
        self.assertNotIn("gridEl.addEventListener('click'", source)
        self.assertNotIn("panel.addEventListener('error'", source)
        self.assertNotIn("__decorDelegated", source)
        self.assertNotIn("__decorImageFallbackBound", source)

    def test_11_bootstrap_and_architecture_publish_one_native_material_card_owner(self) -> None:
        source = BOOTSTRAP.read_text(encoding="utf-8")
        self.assertEqual(source.count('from "./components/material-card.js"'), 1)
        self.assertEqual(source.count("createMaterialCardComponent()"), 1)
        self.assertEqual(source.count("materialCardComponent.announceReady();"), 1)
        self.assertIn('"R9RC1_PROFESSIONAL_ARCHITECTURE_COMPLETION"', source)
        self.assertIn('mode: "legacy-read-cleanup-adapter"', source)
        for method in ("renderMaterialCard", "bindMaterialCardGrid"):
            self.assertEqual(source.count(f"  {method}:"), 1)
        rules = json.loads(RULES.read_text(encoding="utf-8"))["frontend"]
        owners = {"app/tool-a/components/dialog.js", "app/tool-a/components/footer.js",
            "app/tool-a/components/material-card.js", "app/tool-a/components/mobile-material-cart.js",
            "app/tool-a/components/overlay-router.js",
            "app/tool-a/components/panel-editor.js", "app/tool-a/components/progress-overlay.js",
            "app/tool-a/components/grain-preview.js", "app/tool-a/components/checkout-review.js",
            "app/tool-a/components/thank-you.js"}
        self.assertEqual(set(rules["domOwnerModules"]), owners)
        self.assertEqual(set(rules["domOwnerRequiredTokens"]), owners)
        self.assertEqual(rules["moduleImports"]["app/tool-a/components/material-card.js"], [])
        self.assertEqual(len(rules["publicStaticFiles"]), 19)

    def test_12_css_io_allowlists_preflight_and_protected_fingerprints_are_exact(self) -> None:
        source = DECOR.read_text(encoding="utf-8")
        self.assertIn("function ensureStyle(){ return true; }", source)
        self.assertNotIn('createElement("style")', source)
        style = (APP / "tool-a/styles/runtime-components.css").read_text(encoding="utf-8")
        css_lines = "\n".join(line for line in style.splitlines() if any(token in line for token in (
            ".decorCard", ".decorCardMedia", ".decorCardBody", ".decorBrand", ".decorName",
            ".decorTags", ".decorTag", ".decorSelectedCheck", ".decorPlaceholder",
        )))
        self.assertEqual(len(css_lines.splitlines()), 26)
        for token in (".decorCard{", ".decorCardMedia{", ".decorCardBody{", ".decorSelectedCheck{"):
            self.assertIn(token, css_lines)
        expected = {"dxf_nesting_optimizer.py": "42480b301cd660dac1e5e9fec2c8d30bb5c6826c32234a9c1cce765b758bebb8",
            "dxf_geometry.py": "b80a2d006241908bf7b33516f7e0faf59ef61e1e08db86966b23cc5de292c1ff",
            "pricing_helpers.py": "646c2f5186e9b080f6ba8dcf364884411c18e946254bb5c9001647f7cbb425df",
            "panel_contract.py": "e23314fd63a2358a48daa580a92cebb8a40c9862548ba0243461a59347da7fc9"}
        for name, digest in expected.items():
            self.assertEqual(hashlib.sha256((APP / name).read_bytes()).hexdigest(), digest, name)
        component = COMPONENT.read_text(encoding="utf-8")
        for token in ("fetch(", "XMLHttpRequest", "EventSource", "WebSocket", "localStorage", "sessionStorage", "defineProperty(globalThis"):
            self.assertNotIn(token, component)
        self.assertEqual(assignment_set(APP / "metod_app/http/static.py", "PUBLIC_STATIC_MODULE_FILES"),
            assignment_set(APP / "metod_app/http/static.py", "PUBLIC_STATIC_MODULE_FILES"))
        self.assertEqual(len(assignment_set(APP / "metod_app/http/static.py", "PUBLIC_STATIC_ROOT_FILES")), 2)
        matrix = json.loads((ROOT / "R9RC3_ACTIVE_TEST_MATRIX.json").read_text(encoding="utf-8"))
        self.assertIn(
            "tools/r9h_material_card_component_tests.py",
            {row["path"] for row in matrix["suites"]},
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
