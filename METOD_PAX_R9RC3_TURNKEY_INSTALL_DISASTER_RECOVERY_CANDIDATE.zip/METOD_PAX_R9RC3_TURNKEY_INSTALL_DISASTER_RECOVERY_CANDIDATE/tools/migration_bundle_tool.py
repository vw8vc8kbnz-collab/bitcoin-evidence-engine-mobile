#!/usr/bin/env python3
from __future__ import annotations

"""Create and safely extract authenticated METOD/PAX migration payloads."""

import argparse
import hashlib
import json
import os
import shutil
import stat
import tarfile
import time
from pathlib import Path, PurePosixPath


PAYLOAD_ROOT = "metod-pax-migration"
MANIFEST_NAME = "MANIFEST.json"
MAX_ENTRIES = 1_000_000
MAX_BYTES = 32 * 1024 * 1024 * 1024
ALLOWED_PREFIXES = (
    f"{PAYLOAD_ROOT}/state/",
    f"{PAYLOAD_ROOT}/config/",
)
ALLOWED_SINGLE = {
    f"{PAYLOAD_ROOT}/{MANIFEST_NAME}",
    f"{PAYLOAD_ROOT}/state",
    f"{PAYLOAD_ROOT}/config",
}


def digest(path: Path) -> str:
    result = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            result.update(chunk)
    return result.hexdigest()


def inventory(payload: Path) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    total = 0
    for path in sorted(payload.rglob("*")):
        relative = path.relative_to(payload).as_posix()
        if relative == MANIFEST_NAME:
            continue
        mode = path.lstat().st_mode
        if stat.S_ISLNK(mode):
            raise ValueError("symlink in migratiepayload is verboden")
        if stat.S_ISDIR(mode):
            rows.append({"path": relative, "type": "directory", "mode": stat.S_IMODE(mode)})
        elif stat.S_ISREG(mode):
            size = path.stat().st_size
            total += size
            if total > MAX_BYTES:
                raise ValueError("migratiepayload overschrijdt 32 GiB")
            rows.append({
                "path": relative,
                "type": "file",
                "mode": stat.S_IMODE(mode),
                "size": size,
                "sha256": digest(path),
            })
        else:
            raise ValueError("speciaal bestand in migratiepayload is verboden")
        if len(rows) > MAX_ENTRIES:
            raise ValueError("migratiepayload bevat te veel entries")
    return rows


def create_manifest(payload: Path) -> None:
    if payload.name != PAYLOAD_ROOT or not (payload / "state").is_dir():
        raise ValueError("ongeldige migratiepayloadroot")
    credentials = payload / "config/admin_credentials.live.json"
    if not credentials.is_file() or credentials.is_symlink():
        raise ValueError("migratiepayload mist reguliere admincredentials")
    value = {
        "schemaVersion": 1,
        "bundleType": "METOD_PAX_ENCRYPTED_SERVER_MIGRATION",
        "createdAt": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "entries": inventory(payload),
    }
    target = payload / MANIFEST_NAME
    target.write_text(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n", encoding="utf-8")
    os.chmod(target, 0o600)


def safe_member_name(raw: str) -> PurePosixPath:
    name = PurePosixPath(raw)
    if name.is_absolute() or not name.parts or any(part in {"", ".", ".."} for part in name.parts):
        raise ValueError("onveilig pad in migratiearchief")
    normalized = name.as_posix().rstrip("/")
    if normalized != PAYLOAD_ROOT and normalized not in ALLOWED_SINGLE and not any(
        normalized.startswith(prefix) for prefix in ALLOWED_PREFIXES
    ):
        raise ValueError("onverwacht pad in migratiearchief")
    return name


def extract_archive(archive: Path, destination: Path) -> Path:
    if destination.exists():
        raise ValueError("extractiedoel bestaat al")
    destination.mkdir(mode=0o700, parents=True)
    total = 0
    count = 0
    directory_modes: list[tuple[Path, int]] = []
    try:
        with tarfile.open(archive, "r:") as bundle:
            members = bundle.getmembers()
            if not members or len(members) > MAX_ENTRIES:
                raise ValueError("ongeldig aantal archiefentries")
            seen_names: set[str] = set()
            for member in members:
                count += 1
                name = safe_member_name(member.name)
                normalized_name = name.as_posix().rstrip("/")
                if normalized_name in seen_names:
                    raise ValueError("dubbele entry in migratiearchief")
                seen_names.add(normalized_name)
                if member.issym() or member.islnk() or not (member.isdir() or member.isfile()):
                    raise ValueError("links en speciale archiefentries zijn verboden")
                if member.isfile():
                    total += member.size
                    if total > MAX_BYTES:
                        raise ValueError("migratiearchief overschrijdt 32 GiB")
                target = destination.joinpath(*name.parts)
                if member.isdir():
                    target.mkdir(mode=0o700, parents=True, exist_ok=True)
                    directory_modes.append((target, stat.S_IMODE(member.mode) & 0o777))
                    continue
                target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
                source = bundle.extractfile(member)
                if source is None:
                    raise ValueError("regulier archiefbestand heeft geen payload")
                with target.open("xb") as output:
                    shutil.copyfileobj(source, output, length=1024 * 1024)
                os.chmod(target, stat.S_IMODE(member.mode) & 0o777)

        for target, mode in sorted(directory_modes, key=lambda item: len(item[0].parts), reverse=True):
            os.chmod(target, mode)

        payload = destination / PAYLOAD_ROOT
        manifest_path = payload / MANIFEST_NAME
        manifest = json.loads(manifest_path.read_text(encoding="utf-8", errors="strict"))
        if (
            not isinstance(manifest, dict)
            or manifest.get("schemaVersion") != 1
            or manifest.get("bundleType") != "METOD_PAX_ENCRYPTED_SERVER_MIGRATION"
            or not isinstance(manifest.get("entries"), list)
        ):
            raise ValueError("migratiemanifestcontract ongeldig")
        expected = manifest["entries"]
        actual = inventory(payload)
        if expected != actual:
            raise ValueError("migratiemanifest komt niet exact overeen met uitgepakte bytes")
        return payload
    except Exception:
        shutil.rmtree(destination, ignore_errors=True)
        raise


def main() -> int:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    create = sub.add_parser("manifest")
    create.add_argument("--payload", type=Path, required=True)
    extract = sub.add_parser("extract")
    extract.add_argument("--archive", type=Path, required=True)
    extract.add_argument("--destination", type=Path, required=True)
    args = parser.parse_args()
    try:
        if args.command == "manifest":
            create_manifest(args.payload.resolve(strict=True))
            print("MIGRATION MANIFEST: PASS")
        else:
            payload = extract_archive(args.archive.resolve(strict=True), args.destination.absolute())
            print(f"MIGRATION EXTRACTION: PASS: {payload}")
    except Exception as exc:
        print(f"MIGRATION BUNDLE: FAIL: {exc}")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
