#!/usr/bin/env python3
from __future__ import annotations

"""Fail-closed identity, install-surface and NO-GO gate for R9RC3."""

import argparse
from pathlib import Path

from r9rc2_release_identity_gate import EXPECTED_PROTECTED_FILES, digest, load_object


REVISION = "R9RC3"
BUILD = "R9RC3_TURNKEY_INSTALL_DISASTER_RECOVERY"
APPLICATION_REVISION = "R9RC1_PROFESSIONAL_ARCHITECTURE_COMPLETION"
ARTIFACT = f"METOD_PAX_{BUILD}_CANDIDATE.zip"
ARTIFACT_ROOT = f"METOD_PAX_{BUILD}_CANDIDATE"
TAG = "r9rc3-turnkey-install-disaster-recovery-candidate-checkpoint"
GOLDEN_SHA256 = "d3e8656d8d7d5a581a8186ef8fe2c91c19b2137a8654b2f2874497dd85255e62"
EXPECTED_DEPLOYMENT_FILES = frozenset({
    "INSTALL_FIX660R8_FROM_STAGE.sh",
    "DEPLOY_FIX660.sh",
    "EXPORT_METOD_PAX_MIGRATION_BUNDLE.sh",
    "INSTALL_METOD_PAX_CLEAN_SERVER.sh",
    "tools/install_state_gate.py",
    "tools/migration_bundle_tool.py",
    "tools/r9rc3_install_recovery_tests.py",
})


def audit_release(release: Path) -> list[str]:
    failures: list[str] = []

    def require(condition: bool, message: str) -> None:
        if not condition:
            failures.append(message)

    try:
        identity = load_object(release / "RELEASE_IDENTITY.json")
        candidate = identity.get("canonicalCandidate") or {}
        golden = identity.get("immutableGoldenBaseline") or {}
        evidence = identity.get("externalEvidence") or {}
        install = identity.get("turnkeyInstallAndRecovery") or {}
        require(identity.get("contractId") == "R9RC3_RELEASE_IDENTITY", "identity-contract")
        require(candidate.get("releaseRevision") == REVISION, "release-revision")
        require(candidate.get("buildId") == BUILD, "build-id")
        require(candidate.get("artifactName") == ARTIFACT, "artifact-name")
        require(candidate.get("artifactRootDirectory") == ARTIFACT_ROOT, "artifact-root")
        require(candidate.get("intendedSourceTag") == TAG, "source-tag")
        require(candidate.get("status") == "PROVISIONAL_DEVELOPMENT_ONLY", "candidate-status")
        require(candidate.get("releaseEligible") is False, "release-must-remain-ineligible")
        require(golden.get("artifactSha256") == GOLDEN_SHA256, "golden-sha256")
        require(install.get("defaultMode") == "upgrade", "install-default-mode")
        require(install.get("explicitModes") == ["upgrade", "recovery", "bootstrap"], "install-mode-set")
        require(install.get("baselineBypassAllowed") is False, "baseline-bypass-forbidden")
        require(install.get("encryptedCleanServerMigration") is True, "encrypted-migration-required")
        require(evidence.get("productionGo") is False, "production-must-remain-no-go")
        require(evidence.get("browser") == "R9RC3_CHROMIUM_WEBKIT_RERUN_REQUIRED_NO_GO", "browser-rerun-state")
        require(evidence.get("vps") == "R9RC3_RECOVERY_EXECUTION_REQUIRED_NO_GO", "vps-recovery-state")
        require(evidence.get("cleanServer") == "R9RC3_CLEAN_INSTALL_EXECUTION_REQUIRED_NO_GO", "clean-server-state")

        contract = load_object(release / "RUNTIME_CONTRACT.json")
        for field, expected in (
            ("build", BUILD), ("releaseRevision", REVISION),
            ("artifactName", ARTIFACT), ("artifactRootDirectory", ARTIFACT_ROOT),
        ):
            require(contract.get(field) == expected, f"runtime-{field}")
        require(contract.get("releaseEligible") is False, "runtime-release-eligibility")

        sbom = load_object(release / "SBOM.cdx.json")
        metadata = sbom.get("metadata") or {}
        component = metadata.get("component") or {}
        properties = {
            str(item.get("name") or ""): str(item.get("value") or "")
            for item in metadata.get("properties") or [] if isinstance(item, dict)
        }
        require(component.get("version") == BUILD, "sbom-build")
        require(properties.get("releaseRevision") == REVISION, "sbom-revision")
        require(properties.get("artifactName") == ARTIFACT, "sbom-artifact")
        require(properties.get("artifactRootDirectory") == ARTIFACT_ROOT, "sbom-root")
        require(properties.get("releaseEligible") == "false", "sbom-release-eligibility")

        matrix = load_object(release / "R9RC3_ACTIVE_TEST_MATRIX.json")
        require(matrix.get("matrixId") == "R9RC3_ACTIVE_OUTCOME_TEST_MATRIX", "test-matrix-id")
        require(matrix.get("buildId") == BUILD, "test-matrix-build")
        require(matrix.get("status") == "CURRENT", "test-matrix-status")
        matrix_evidence = matrix.get("externalEvidence") or {}
        require(matrix_evidence.get("productionGo") is False, "test-matrix-production-go")
        require(matrix_evidence.get("releaseEligible") is False, "test-matrix-eligibility")

        rules = load_object(release / "R9RC1_PROFESSIONAL_ARCHITECTURE_RULES.json")
        require(rules.get("buildId") == APPLICATION_REVISION, "architecture-rules-build")
        tool_a = (release / "app/toolA.html").read_text(encoding="utf-8", errors="strict")
        for token in (
            f'<meta name="metod-release-revision" content="{REVISION}" />',
            f'<meta name="metod-release-build" content="{BUILD}" />',
            f'<meta name="metod-application-revision" content="{APPLICATION_REVISION}" />',
        ):
            require(token in tool_a, f"public-metadata:{token}")

        protected = identity.get("protectedCriticalFiles") or {}
        require(set(protected) == EXPECTED_PROTECTED_FILES, "protected-file-set")
        deployment = identity.get("protectedDeploymentFiles") or {}
        require(set(deployment) == EXPECTED_DEPLOYMENT_FILES, "protected-deployment-file-set")
        for relative, expected in sorted({**protected, **deployment}.items()):
            path = release / str(relative)
            require(path.is_file() and not path.is_symlink(), f"protected-file-missing:{relative}")
            if path.is_file() and not path.is_symlink():
                require(digest(path) == expected, f"protected-file-mismatch:{relative}")
    except Exception as exc:
        failures.append(f"identity-gate-exception:{exc}")
    return failures


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--release", type=Path, required=True)
    args = parser.parse_args()
    failures = audit_release(args.release.resolve(strict=True))
    if failures:
        for failure in failures:
            print(f"FAIL: {failure}")
        return 1
    print("R9RC3 RELEASE IDENTITY GATE: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

