#!/usr/bin/env python3
from __future__ import annotations

"""Fail-closed R9H-4 footer behavior, visual and ownership proof."""

import ast
import base64
import hashlib
import json
import re
import shutil
import subprocess
import unittest
from pathlib import Path

from r9h_shell_source import read_toola_expanded


ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
HTML = APP / "toolA.html"
BOOTSTRAP = APP / "tool-a/bootstrap.js"
COMPONENT = APP / "tool-a/components/footer.js"
RULES = ROOT / "R9B_ARCHITECTURE_RULES.json"


def data_url(path: Path) -> str:
    return "data:text/javascript;base64," + base64.b64encode(path.read_bytes()).decode()


def run_node(source: str) -> dict:
    node = shutil.which("node")
    if not node:
        raise AssertionError("Node is required by the release architecture gate")
    completed = subprocess.run(
        [node, "--input-type=module"], input=source, text=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=10, check=False,
    )
    if completed.returncode != 0:
        raise AssertionError(completed.stdout)
    return json.loads(completed.stdout.strip().splitlines()[-1])


def fake_dom_probe(actions: str) -> dict:
    return run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});
const ids={{}};
function classList(){{const values=new Set();return{{add:v=>values.add(v),remove:v=>values.delete(v),
contains:v=>values.has(v),toggle:(v,on)=>on?values.add(v):values.delete(v),values}};}}
function container(id){{return{{id,children:[],parentNode:null,dataset:{{}},style:{{}},classList:classList(),
appendChild(el){{if(el.parentNode){{const i=el.parentNode.children.indexOf(el);if(i>=0)el.parentNode.children.splice(i,1);}}this.children.push(el);el.parentNode=this;return el;}},
insertBefore(el,ref){{if(el.parentNode){{const i=el.parentNode.children.indexOf(el);if(i>=0)el.parentNode.children.splice(i,1);}}const i=ref?this.children.indexOf(ref):-1;if(i<0)this.children.push(el);else this.children.splice(i,0,el);el.parentNode=this;return el;}}}};}}
function element(initialId){{let ownId=initialId||'';const el={{type:'',className:'',textContent:'',disabled:false,
style:{{}},dataset:{{}},classList:classList(),listeners:{{}},parentNode:null,
addEventListener(t,fn){{(this.listeners[t]||(this.listeners[t]=[])).push(fn);}}}};
Object.defineProperty(el,'id',{{get:()=>ownId,set:v=>{{ownId=String(v);ids[ownId]=el;}}}});if(ownId)ids[ownId]=el;
Object.defineProperty(el,'nextSibling',{{get(){{if(!this.parentNode)return null;const i=this.parentNode.children.indexOf(this);return this.parentNode.children[i+1]||null;}}}});return el;}}
const source=container('source'),drawer=container('drawer');
const footer=element('wizardFooter'),inner=container('wizardFooterInner'),trigger=element('mobileMaterialCartTrigger'),addInline=element('addBtnInline');
source.appendChild(footer);footer.children=[];footer.appendChild=container('tmp').appendChild;footer.appendChild.call(footer,inner);inner.appendChild(trigger);
ids.wizardFooter=footer;ids.wizardFooterInner=inner;ids.mobileMaterialCartTrigger=trigger;ids.addBtnInline=addInline;
const comments=[];const events=[];
const documentRef={{getElementById:id=>ids[id]||null,createElement:()=>element(''),createComment:text=>{{const c=element('');c.comment=String(text);comments.push(c);return c;}},
dispatchEvent:event=>{{events.push(event.type);return true;}}}};
class FakeEvent{{constructor(type){{this.type=type;}}}}
const rootRef={{Event:FakeEvent,__metod_uiStep:'material'}};
const component=m.createFooterComponent({{documentRef,rootRef}});
{actions}
""")


def assignment_set(path: Path, name: str) -> set[str]:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(
            isinstance(target, ast.Name) and target.id == name for target in node.targets
        ):
            value = node.value
            if isinstance(value, ast.Call) and isinstance(value.func, ast.Name) and value.func.id == "frozenset":
                value = value.args[0]
            return set(ast.literal_eval(value))
    raise AssertionError(name)


class R9HFooterComponentTests(unittest.TestCase):
    def test_01_decisions_preserve_all_five_step_guards_and_labels(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});
const snapshot={{currentStep:'panels',material:{{hasActiveMaterial:true}},cart:{{hasPanels:false}},customer:{{requiredReady:false}},edit:{{isEditing:true}}}};
const out=Object.fromEntries(['material','panels','grain','customer','overview'].map(step=>[step,m.getFooterDecision(step,snapshot)]));
console.log(JSON.stringify({{build:m.FOOTER_COMPONENT_BUILD,out}}));
""")
        self.assertEqual(result["build"], "R9H_FOOTER_COMPONENT_4")
        out = result["out"]
        self.assertEqual((out["material"]["showNext"], out["material"]["nextDisabled"]), (True, False))
        self.assertEqual((out["panels"]["showPrev"], out["panels"]["showNext"], out["panels"]["nextDisabled"]), (True, True, True))
        self.assertEqual(out["panels"]["addInlineLabel"], "✓ Wijzigingen opslaan")
        self.assertEqual((out["grain"]["showPrev"], out["grain"]["showNext"]), (True, False))
        self.assertEqual((out["customer"]["showPrev"], out["customer"]["showNext"], out["customer"]["nextDisabled"]), (True, True, False))
        self.assertEqual((out["overview"]["showPrev"], out["overview"]["prevLabel"]), (True, "Terug"))

    def test_02_safe_step_overrides_and_view_state_mapping_are_exact(self) -> None:
        result = run_node(f"""
const m=await import({json.dumps(data_url(COMPONENT))});
const decision=m.getFooterDecision('unknown',{{currentStep:'panels',material:{{hasActiveMaterial:false}},cart:{{hasPanels:true}},edit:{{isEditing:false}}}},{{nextLabel:'Verder'}});
console.log(JSON.stringify({{decision,view:m.getFooterViewState(decision)}}));
""")
        self.assertEqual(result["decision"]["step"], "panels")
        self.assertEqual(result["decision"]["nextLabel"], "Verder")
        self.assertEqual(result["view"]["prev"], {"display": "inline-flex", "disabled": False, "text": "Vorige stap"})
        self.assertEqual(result["view"]["next"], {"display": "inline-flex", "disabled": False, "text": "Verder"})
        self.assertEqual(result["view"]["addInline"]["text"], "+ Toevoegen aan lijst")
        self.assertTrue(result["view"]["addInline"]["disabled"])

    def test_03_render_creates_one_ordered_button_set_and_preserves_existing_cart_trigger(self) -> None:
        result = fake_dom_probe("""
const options={step:'material',snapshot:{material:{hasActiveMaterial:false},cart:{hasPanels:false},customer:{},edit:{}},footerInner:inner,addInline};
const first=component.render(options);const second=component.render({...options,existing:first});
console.log(JSON.stringify({ids:inner.children.map(v=>v.id),listeners:second.next.listeners.click.length,
next:{display:second.next.style.display,disabled:second.next.disabled,text:second.next.textContent},
prev:second.prev.style.display,overview:second.overview.style.display,step:inner.dataset.currentStep}));
""")
        self.assertEqual(result["ids"], ["mobileMaterialCartTrigger", "wizardPrevBtn", "wizardOverviewBtn", "wizardNextBtn"])
        self.assertEqual(result["listeners"], 1)
        self.assertEqual(result["next"], {"display": "inline-flex", "disabled": True, "text": "Volgende stap"})
        self.assertEqual((result["prev"], result["overview"], result["step"]), ("none", "none", "material"))

    def test_04_panels_render_preserves_edit_copy_and_button_state(self) -> None:
        result = fake_dom_probe("""
const out=component.render({step:'panels',snapshot:{material:{hasActiveMaterial:true},cart:{hasPanels:true},customer:{},edit:{isEditing:true}},footerInner:inner,addInline});
console.log(JSON.stringify({prev:[out.prev.style.display,out.prev.disabled,out.prev.textContent],next:[out.next.style.display,out.next.disabled,out.next.textContent],
add:[addInline.disabled,addInline.textContent,addInline.classList.contains('is-editing')],datasets:[out.prev.dataset.currentStep,out.next.dataset.currentStep]}));
""")
        self.assertEqual(result["prev"], ["inline-flex", False, "Vorige stap"])
        self.assertEqual(result["next"], ["inline-flex", False, "Volgende stap"])
        self.assertEqual(result["add"], [False, "✓ Wijzigingen opslaan", True])
        self.assertEqual(result["datasets"], ["panels", "panels"])

    def test_05_prev_next_and_overview_bindings_route_once_and_are_idempotent(self) -> None:
        result = fake_dom_probe("""
const calls=[];const snapshot={material:{hasActiveMaterial:true},cart:{hasPanels:true},customer:{},edit:{}};
const opts={step:'panels',snapshot,footerInner:inner,addInline,showStep:s=>calls.push(s),hasMaterialSelected:()=>true,hasPanels:()=>true,
getPrevTarget:s=>s==='panels'?'material':'customer',getNextTarget:s=>s==='panels'?'grain':null};
const out=component.render(opts);component.render({...opts,existing:out});
out.prev.listeners.click[0]();out.next.listeners.click[0]();out.overview.listeners.click[0]();
console.log(JSON.stringify({calls,counts:[out.prev.listeners.click.length,out.next.listeners.click.length,out.overview.listeners.click.length]}));
""")
        self.assertEqual(result["calls"], ["material", "grain", "overview"])
        self.assertEqual(result["counts"], [1, 1, 1])

    def test_06_customer_validation_blocks_then_allows_the_same_canonical_next_route(self) -> None:
        result = fake_dom_probe("""
const calls=[];let valid=false;const opts={step:'customer',snapshot:{material:{hasActiveMaterial:true},cart:{hasPanels:true},customer:{},edit:{}},footerInner:inner,
showStep:s=>calls.push(s),hasMaterialSelected:()=>true,hasPanels:()=>true,validateCustomerStepRequired:()=>valid,getNextTarget:(s,c)=>c.customerValid?'overview':null};
const out=component.render(opts);out.next.listeners.click[0]();valid=true;out.next.listeners.click[0]();
console.log(JSON.stringify({calls}));
""")
        self.assertEqual(result["calls"], ["overview"])

    def test_07_overview_back_buttons_close_and_restore_the_recorded_step_once(self) -> None:
        result = fake_dom_probe("""
const close=element('overviewCloseBtn'),back=element('overviewBackBtn'),calls=[];
const opts={closeBtn:close,backBtn:back,closeOverview:()=>calls.push('close'),showStep:s=>calls.push(s),getOverviewReturnStep:()=> 'panels',getPrevTarget:(s,r)=>r};
component.bindOverview(opts);component.bindOverview(opts);close.listeners.click[0]();back.listeners.click[0]();
console.log(JSON.stringify({calls,counts:[close.listeners.click.length,back.listeners.click.length]}));
""")
        self.assertEqual(result["calls"], ["close", "panels", "close", "panels"])
        self.assertEqual(result["counts"], [1, 1])

    def test_08_mobile_drawer_placement_uses_one_anchor_and_restores_the_same_footer(self) -> None:
        result = fake_dom_probe("""
const anchored=component.place('anchor');const attached=component.place('attach',drawer);const during={source:source.children.map(v=>v.id||v.comment),drawer:drawer.children.map(v=>v.id)};
const restored=component.place('restore');component.place('anchor');
console.log(JSON.stringify({anchored,attached,restored,during,after:source.children.map(v=>v.id||v.comment),comments:comments.length}));
""")
        self.assertTrue(result["anchored"])
        self.assertTrue(result["attached"])
        self.assertTrue(result["restored"])
        self.assertEqual(result["during"]["drawer"], ["wizardFooter"])
        self.assertEqual(result["after"], ["R9H wizard footer original position", "wizardFooter"])
        self.assertEqual(result["comments"], 1)

    def test_09_ready_event_and_missing_dom_are_idempotent_no_throw_boundaries(self) -> None:
        result = fake_dom_probe("""
const first=component.announceReady(),second=component.announceReady();
const empty=m.createFooterComponent({documentRef:{},rootRef:{}});const rendered=empty.render({step:'panels'});
console.log(JSON.stringify({first,second,events,empty:{frozen:Object.isFrozen(empty),keys:Reflect.ownKeys(empty),rendered,place:empty.place('attach',{})}}));
""")
        self.assertEqual((result["first"], result["second"], result["events"]), (True, False, ["tool-a-footer-owner-ready"]))
        self.assertTrue(result["empty"]["frozen"])
        self.assertEqual(result["empty"]["keys"], ["BUILD", "getDecision", "getViewState", "render", "bindOverview", "place", "announceReady"])
        self.assertIsNone(result["empty"]["rendered"]["decision"])
        self.assertFalse(result["empty"]["place"])

    def test_10_legacy_owners_are_retired_and_inline_callers_are_thin_adapters(self) -> None:
        html = read_toola_expanded(HTML)
        all_app_source = "\n".join(
            path.read_text(encoding="utf-8", errors="replace")
            for path in APP.rglob("*") if path.is_file() and path.suffix in {".js", ".html"}
        )
        for name in ("toolA_footer_decisions.js", "toolA_footer_view_state.js", "toolA_footer_apply.js", "toolA_footer_bindings.js"):
            self.assertFalse((APP / name).exists(), name)
            self.assertNotIn(name, html)
        for global_name in ("ToolAFooterDecisions", "ToolAFooterViewState", "ToolAFooterApply", "ToolAFooterBindings"):
            self.assertNotIn(global_name, all_app_source)
        adapter = html[html.index("  function renderFooterForStep(step){"):html.index("\n  function showStep(step){")]
        self.assertIn("owner.renderWizardFooter", adapter)
        for token in ("createElement", "appendChild", "classList", ".style.display", "addEventListener"):
            self.assertNotIn(token, adapter)
        movable = (APP / "tool-a/shell/script-16-fix636-step2-single-unit-js.js").read_text(encoding="utf-8")
        self.assertIn("placeWizardFooter?.('attach',d)", movable)
        self.assertIn("placeWizardFooter?.('restore')", movable)
        self.assertNotIn("getElementById('wizardFooter')", movable)

    def test_11_bootstrap_and_architecture_publish_one_native_footer_owner(self) -> None:
        source = BOOTSTRAP.read_text(encoding="utf-8")
        self.assertEqual(source.count('from "./components/footer.js"'), 1)
        self.assertEqual(source.count("createFooterComponent()"), 1)
        self.assertEqual(source.count("footerComponent.announceReady();"), 1)
        self.assertIn('"R9RC1_PROFESSIONAL_ARCHITECTURE_COMPLETION"', source)
        self.assertIn('mode: "legacy-read-cleanup-adapter"', source)
        for method in ("getFooterDecision", "renderWizardFooter", "bindOverviewFooter", "placeWizardFooter"):
            self.assertEqual(source.count(f"  {method}:"), 1)
        rules = json.loads(RULES.read_text(encoding="utf-8"))["frontend"]
        owners = {"app/tool-a/components/dialog.js", "app/tool-a/components/footer.js",
            "app/tool-a/components/mobile-material-cart.js", "app/tool-a/components/progress-overlay.js",
            "app/tool-a/components/overlay-router.js",
            "app/tool-a/components/material-card.js", "app/tool-a/components/panel-editor.js",
            "app/tool-a/components/grain-preview.js", "app/tool-a/components/checkout-review.js",
            "app/tool-a/components/thank-you.js"}
        self.assertEqual(set(rules["domOwnerModules"]), owners)
        self.assertEqual(set(rules["domOwnerRequiredTokens"]), owners)
        self.assertEqual(rules["moduleImports"]["app/tool-a/components/footer.js"], [])
        self.assertEqual(len(rules["publicStaticFiles"]), 19)
        self.assertIn("tool-a/components/footer.js", rules["publicStaticFiles"])

    def test_12_visual_io_allowlists_preflight_and_protected_fingerprints_are_exact(self) -> None:
        html = read_toola_expanded(HTML)
        markup_start = '      <footer id="wizardFooter"'
        markup_end = "\n\n    <div id=\"mobileMaterialCartBackdrop\""
        markup = html[html.index(markup_start):html.index(markup_end, html.index(markup_start))]
        self.assertIn('</footer>', markup)
        self.assertEqual(markup.count('id="wizardFooter"'), 1)
        self.assertEqual(markup.count('id="wizardFooterInner"'), 1)
        self.assertNotRegex(markup, r"\sstyle\s*=")
        css = (APP / "tool-a/styles/tool-a.bundle.css").read_text(encoding="utf-8")
        self.assertIn("#wizardFooter", css)
        self.assertIn("#wizardFooterInner", css)
        expected = {"dxf_nesting_optimizer.py": "42480b301cd660dac1e5e9fec2c8d30bb5c6826c32234a9c1cce765b758bebb8",
            "dxf_geometry.py": "b80a2d006241908bf7b33516f7e0faf59ef61e1e08db86966b23cc5de292c1ff",
            "pricing_helpers.py": "646c2f5186e9b080f6ba8dcf364884411c18e946254bb5c9001647f7cbb425df",
            "panel_contract.py": "e23314fd63a2358a48daa580a92cebb8a40c9862548ba0243461a59347da7fc9"}
        for name, digest in expected.items():
            self.assertEqual(hashlib.sha256((APP / name).read_bytes()).hexdigest(), digest, name)
        start = html.index("async function buildJobPayload(){")
        end = html.index("  // ---------------------------\n  // Checkout overlays (restmateriaal + klantgegevens)", start)
        payload = html[start:end].encode()
        self.assertEqual((len(payload), hashlib.sha256(payload).hexdigest()),
            (9697, "342dac02c2650ac2798e20e62d38d8e1e6b7d518a54daa8fd760d734ae527e47"))
        component = COMPONENT.read_text(encoding="utf-8")
        for token in ("fetch(", "XMLHttpRequest", "EventSource", "WebSocket", "localStorage", "sessionStorage", "defineProperty(globalThis"):
            self.assertNotIn(token, component)
        self.assertEqual(assignment_set(APP / "metod_app/http/static.py", "PUBLIC_STATIC_MODULE_FILES"),
            assignment_set(APP / "metod_app/http/static.py", "PUBLIC_STATIC_MODULE_FILES"))
        self.assertEqual(len(assignment_set(APP / "metod_app/http/static.py", "PUBLIC_STATIC_ROOT_FILES")), 2)
        matrix = json.loads((ROOT / "R9RC3_ACTIVE_TEST_MATRIX.json").read_text(encoding="utf-8"))
        self.assertIn(
            "tools/r9h_footer_component_tests.py",
            {row["path"] for row in matrix["suites"]},
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
