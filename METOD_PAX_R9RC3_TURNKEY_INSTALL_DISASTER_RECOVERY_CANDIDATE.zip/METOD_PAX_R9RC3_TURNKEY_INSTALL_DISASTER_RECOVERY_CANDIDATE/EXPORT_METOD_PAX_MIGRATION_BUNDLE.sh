#!/usr/bin/env bash
set -Eeuo pipefail
export PYTHONDONTWRITEBYTECODE=1

STAGE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STATE_DIR="${METOD_STATE_ROOT:-/var/lib/metod-pax}"
ENV_DIR="${METOD_ENV_DIR:-/etc/adzaagt/metod-pax}"
CREDS_FILE="${ADMIN_CREDENTIALS_FILE:-$ENV_DIR/admin_credentials.live.json}"
CURRENT_LINK="${METOD_CURRENT_LINK:-/opt/adzaagt/metod-pax-current}"
OUTPUT="${1:-}"
WAS_ACTIVE=0
TEMP_ROOT=""

fail(){ echo "[METOD-PAX-MIGRATION] FOUT: $*" >&2; exit 1; }
cleanup(){
  local rc=$?
  unset MIGRATION_PASSPHRASE MIGRATION_PASSPHRASE_REPEAT
  if [[ -n "$TEMP_ROOT" && -d "$TEMP_ROOT" ]]; then
    [[ "$TEMP_ROOT" == /var/tmp/metod-pax-migration.* ]] || { echo "Onverwacht tijdelijk pad; niet verwijderd: $TEMP_ROOT" >&2; return "$rc"; }
    rm -rf -- "$TEMP_ROOT"
  fi
  if [[ "$WAS_ACTIVE" -eq 1 && -f "$CURRENT_LINK/app/server_py.py" ]]; then
    systemctl start metod-pax.service || true
  fi
  return "$rc"
}
trap cleanup EXIT

[[ -n "$OUTPUT" && "$OUTPUT" == /* && "$OUTPUT" =~ ^/[A-Za-z0-9._/-]+\.gpg$ ]] || fail "Geef één veilig absoluut .gpg-uitvoerpad"
[[ ! -e "$OUTPUT" && ! -L "$OUTPUT" ]] || fail "Uitvoer bestaat al: $OUTPUT"
[[ -d "$(dirname "$OUTPUT")" && ! -L "$(dirname "$OUTPUT")" ]] || fail "Uitvoermap ontbreekt of is een symlink"
if [[ "$EUID" -ne 0 ]]; then
  exec sudo env PYTHONDONTWRITEBYTECODE=1 METOD_STATE_ROOT="$STATE_DIR" METOD_ENV_DIR="$ENV_DIR" \
    ADMIN_CREDENTIALS_FILE="$CREDS_FILE" METOD_CURRENT_LINK="$CURRENT_LINK" bash "$0" "$OUTPUT"
fi
for command in python3 rsync tar gpg sha256sum systemctl mktemp; do
  command -v "$command" >/dev/null || fail "Ontbrekend commando: $command"
done

PYTHONDONTWRITEBYTECODE=1 python3 "$STAGE/tools/install_state_gate.py" \
  --state-root "$STATE_DIR" --credentials "$CREDS_FILE"
systemctl is-active --quiet metod-pax.service && WAS_ACTIVE=1 || true
systemctl stop metod-pax.service || true

TEMP_ROOT="$(mktemp -d /var/tmp/metod-pax-migration.XXXXXX)"
chmod 0700 "$TEMP_ROOT"
PAYLOAD="$TEMP_ROOT/metod-pax-migration"
install -d -o root -g root -m 0700 "$PAYLOAD/state" "$PAYLOAD/config"
rsync -a --delete "$STATE_DIR/" "$PAYLOAD/state/"
cp -a --no-dereference "$CREDS_FILE" "$PAYLOAD/config/admin_credentials.live.json"
if [[ -f "$ENV_DIR/metod-pax.env" && ! -L "$ENV_DIR/metod-pax.env" ]]; then
  cp -a --no-dereference "$ENV_DIR/metod-pax.env" "$PAYLOAD/config/metod-pax.env.previous"
fi
chmod 0600 "$PAYLOAD/config/admin_credentials.live.json"
PYTHONDONTWRITEBYTECODE=1 python3 "$STAGE/tools/install_state_gate.py" \
  --state-root "$PAYLOAD/state" --credentials "$PAYLOAD/config/admin_credentials.live.json"
PYTHONDONTWRITEBYTECODE=1 python3 "$STAGE/tools/migration_bundle_tool.py" manifest --payload "$PAYLOAD"

printf 'Kies een sterk wachtwoord voor het versleutelde migratiebestand: ' >/dev/tty
IFS= read -rs MIGRATION_PASSPHRASE </dev/tty
printf '\nHerhaal het wachtwoord: ' >/dev/tty
IFS= read -rs MIGRATION_PASSPHRASE_REPEAT </dev/tty
printf '\n' >/dev/tty
[[ ${#MIGRATION_PASSPHRASE} -ge 16 ]] || fail "Migratiewachtwoord moet minimaal 16 tekens zijn"
[[ "$MIGRATION_PASSPHRASE" == "$MIGRATION_PASSPHRASE_REPEAT" ]] || fail "Migratiewachtwoorden zijn niet gelijk"
unset MIGRATION_PASSPHRASE_REPEAT

exec 3<<<"$MIGRATION_PASSPHRASE"
tar --numeric-owner --format=pax -C "$TEMP_ROOT" -cf - metod-pax-migration \
  | gpg --batch --yes --pinentry-mode loopback --passphrase-fd 3 --symmetric \
      --cipher-algo AES256 --s2k-mode 3 --s2k-digest-algo SHA512 --s2k-count 65011712 \
      --compress-algo none --no-symkey-cache --output "$OUTPUT"
exec 3<&-
unset MIGRATION_PASSPHRASE
chmod 0600 "$OUTPUT"
(cd "$(dirname "$OUTPUT")" && sha256sum "$(basename "$OUTPUT")" > "$(basename "$OUTPUT").sha256")
chmod 0600 "$OUTPUT.sha256"
if [[ -n "${SUDO_USER:-}" ]]; then
  chown "$SUDO_USER":"$(id -gn "$SUDO_USER")" "$OUTPUT" "$OUTPUT.sha256"
fi
echo "[METOD-PAX-MIGRATION] PASS: versleutelde migratiebundle: $OUTPUT"
echo "[METOD-PAX-MIGRATION] SHA256: $OUTPUT.sha256"
