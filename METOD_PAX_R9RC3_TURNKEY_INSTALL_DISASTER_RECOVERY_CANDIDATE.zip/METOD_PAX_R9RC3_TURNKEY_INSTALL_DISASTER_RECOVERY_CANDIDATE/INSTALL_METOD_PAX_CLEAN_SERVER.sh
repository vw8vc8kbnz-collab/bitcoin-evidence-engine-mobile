#!/usr/bin/env bash
set -Eeuo pipefail
export PYTHONDONTWRITEBYTECODE=1

STAGE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUNDLE="${1:-}"
STATE_DIR="${METOD_STATE_ROOT:-/var/lib/metod-pax}"
ENV_DIR="${METOD_ENV_DIR:-/etc/adzaagt/metod-pax}"
CREDS_FILE="${ADMIN_CREDENTIALS_FILE:-$ENV_DIR/admin_credentials.live.json}"
INSTALL_PACKAGES="${METOD_INSTALL_PACKAGES:-1}"
TEMP_ROOT=""
STATE_STAGE=""

fail(){ echo "[METOD-PAX-CLEAN-INSTALL] FOUT: $*" >&2; exit 1; }
cleanup(){
  local rc=$?
  unset MIGRATION_PASSPHRASE
  if [[ -n "$TEMP_ROOT" && -d "$TEMP_ROOT" ]]; then
    [[ "$TEMP_ROOT" == /var/tmp/metod-pax-clean-install.* ]] || { echo "Onverwacht tijdelijk pad; niet verwijderd: $TEMP_ROOT" >&2; return "$rc"; }
    rm -rf -- "$TEMP_ROOT"
  fi
  if [[ -n "$STATE_STAGE" && -d "$STATE_STAGE" ]]; then
    [[ "$STATE_STAGE" == "${STATE_DIR}.bootstrap."* ]] || { echo "Onverwachte state-stage; niet verwijderd: $STATE_STAGE" >&2; return "$rc"; }
    rm -rf -- "$STATE_STAGE"
  fi
  return "$rc"
}
trap cleanup EXIT

[[ -n "$BUNDLE" && "$BUNDLE" == /* && "$BUNDLE" =~ ^/[A-Za-z0-9._/-]+\.gpg$ ]] || fail "Geef één veilig absoluut pad naar de .gpg-migratiebundle"
[[ -f "$BUNDLE" && ! -L "$BUNDLE" ]] || fail "Migratiebundle ontbreekt of is een symlink"
if [[ "$EUID" -ne 0 ]]; then
  FORWARD=(PYTHONDONTWRITEBYTECODE=1 METOD_STATE_ROOT="$STATE_DIR" METOD_ENV_DIR="$ENV_DIR" ADMIN_CREDENTIALS_FILE="$CREDS_FILE" METOD_INSTALL_PACKAGES="$INSTALL_PACKAGES")
  for name in METOD_DEPLOY_MODE PUBLIC_ORIGIN METOD_DOMAIN TLS_CERT_FILE TLS_KEY_FILE OFFSITE_BACKUP_VERIFIED OFFSITE_BACKUP_PROVIDER PRODUCTION_MIN_CATALOG_RECORDS STAGING_PUBLIC_PORT STAGING_BIND_ADDRESS STAGING_ALLOWED_CIDR; do
    [[ -v "$name" ]] && FORWARD+=("$name=${!name}")
  done
  exec sudo env "${FORWARD[@]}" bash "$0" "$BUNDLE"
fi

[[ "$INSTALL_PACKAGES" =~ ^[01]$ ]] || fail "METOD_INSTALL_PACKAGES moet 0 of 1 zijn"
[[ ! -e /opt/adzaagt && ! -e "$STATE_DIR" && ! -e "$ENV_DIR" ]] || fail "Clean installer weigert bestaande METOD/PAX code, state of configuratie"
[[ ! -e /etc/systemd/system/metod-pax.service ]] || fail "Clean installer weigert bestaande METOD/PAX-service"
if [[ "$INSTALL_PACKAGES" == "1" ]]; then
  [[ -r /etc/os-release ]] || fail "Ondersteunde Debian/Ubuntu-identiteit ontbreekt"
  . /etc/os-release
  [[ "${ID:-}" =~ ^(ubuntu|debian)$ ]] || fail "Clean installer ondersteunt uitsluitend Debian/Ubuntu"
  command -v apt-get >/dev/null || fail "apt-get ontbreekt"
  DEBIAN_FRONTEND=noninteractive apt-get update
  DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends python3 nodejs nginx rsync curl ca-certificates gnupg tar logrotate
fi
for command in python3 node nginx rsync curl gpg tar sha256sum mktemp; do
  command -v "$command" >/dev/null || fail "Ontbrekend commando: $command"
done
[[ -f "$STAGE/SHA256SUMS.txt" ]] || fail "Releasechecksummanifest ontbreekt"
(cd "$STAGE" && sha256sum -c SHA256SUMS.txt)
[[ -f "$BUNDLE.sha256" && ! -L "$BUNDLE.sha256" ]] || fail "Verplichte migratiebundle-sidecar ontbreekt"
SIDECAR_LINE="$(cat "$BUNDLE.sha256")"
[[ "$SIDECAR_LINE" =~ ^([a-f0-9]{64})[[:space:]][[:space:]]([^/[:space:]]+)$ ]] || fail "Migratiebundle-sidecar heeft ongeldig formaat"
[[ "${BASH_REMATCH[2]}" == "$(basename "$BUNDLE")" ]] || fail "Migratiebundle-sidecar noemt niet exact de bundle"
[[ "$(sha256sum "$BUNDLE" | awk '{print $1}')" == "${BASH_REMATCH[1]}" ]] || fail "Migratiebundle-SHA256 wijkt af"

printf 'Wachtwoord van de versleutelde migratiebundle: ' >/dev/tty
IFS= read -rs MIGRATION_PASSPHRASE </dev/tty
printf '\n' >/dev/tty
[[ -n "$MIGRATION_PASSPHRASE" ]] || fail "Leeg migratiewachtwoord geweigerd"
TEMP_ROOT="$(mktemp -d /var/tmp/metod-pax-clean-install.XXXXXX)"
chmod 0700 "$TEMP_ROOT"
DECRYPTED="$TEMP_ROOT/migration.tar"
exec 3<<<"$MIGRATION_PASSPHRASE"
gpg --batch --yes --pinentry-mode loopback --passphrase-fd 3 --no-symkey-cache --decrypt --output "$DECRYPTED" "$BUNDLE"
exec 3<&-
unset MIGRATION_PASSPHRASE
chmod 0600 "$DECRYPTED"
PYTHONDONTWRITEBYTECODE=1 python3 "$STAGE/tools/migration_bundle_tool.py" extract \
  --archive "$DECRYPTED" --destination "$TEMP_ROOT/extracted"
PAYLOAD="$TEMP_ROOT/extracted/metod-pax-migration"
STATE_GATE_ARGS=()
if [[ "${METOD_DEPLOY_MODE:-staging}" == "production" ]]; then
  STATE_GATE_ARGS+=(--production)
fi
PYTHONDONTWRITEBYTECODE=1 python3 "$STAGE/tools/install_state_gate.py" \
  --state-root "$PAYLOAD/state" --credentials "$PAYLOAD/config/admin_credentials.live.json" \
  "${STATE_GATE_ARGS[@]}"

id -u metod-pax >/dev/null 2>&1 || useradd --system --home-dir "$STATE_DIR" --shell /usr/sbin/nologin metod-pax
install -d -o root -g root -m 0755 /opt/adzaagt
STATE_STAGE="${STATE_DIR}.bootstrap.$$"
[[ ! -e "$STATE_STAGE" ]] || fail "Tijdelijke state-import bestaat al"
install -d -o metod-pax -g metod-pax -m 0750 "$STATE_STAGE"
rsync -a --delete "$PAYLOAD/state/" "$STATE_STAGE/"
chown -R metod-pax:metod-pax "$STATE_STAGE"
chmod -R o-rwx "$STATE_STAGE"
chmod 0750 "$STATE_STAGE"
install -d -o root -g metod-pax -m 0750 "$ENV_DIR"
install -o root -g root -m 0600 "$PAYLOAD/config/admin_credentials.live.json" "$CREDS_FILE"
mv "$STATE_STAGE" "$STATE_DIR"
STATE_STAGE=""

METOD_INSTALL_MODE=bootstrap METOD_RECOVERY_ACK=CLEAN_SERVER_STATE_IMPORT_CONFIRMED \
  bash "$STAGE/INSTALL_FIX660R8_FROM_STAGE.sh"
echo "[METOD-PAX-CLEAN-INSTALL] PASS: code, externe state, credentials, service en Nginx zijn geïnstalleerd."
