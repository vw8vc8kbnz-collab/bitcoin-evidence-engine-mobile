# R9RC3 — kant-en-klare installatie en disaster recovery

R9RC3 repareert een operationele tekortkoming die tijdens de VPS-proef zichtbaar
werd: systemd kon nog `active` melden terwijl de immutable releasefolder al was
verwijderd en het Python-proces vanuit een verwijderde werkmap draaide. De
R9RC2-installer stopte in die situatie terecht fail-closed, maar bood nog geen
gecontroleerd herstelpad of volledige clean-servermigratie.

## Drie expliciete installatiemodi

- `upgrade` blijft de standaard en accepteert uitsluitend de exacte historische
  FIX660R7-baseline of een volledig checksumgeverifieerde immutable release.
- `recovery` vereist een afzonderlijke exacte bevestiging, ontbrekende canonieke
  code, een root-owned canonieke systemd-unit en een volledige validatie van
  externe state, catalogus, pricing en admincredentials. Vóór de switch wordt na
  het stoppen van de service een volledige mode-0600 statecheckpoint met SHA-256
  gemaakt. Een fout kan nooit beweren dat de verwijderde code is teruggezet.
- `bootstrap` accepteert alleen een schone coderoot plus vooraf veilig
  geïmporteerde en gevalideerde externe state en credentials.

## Verplaatsing naar een schone server

`EXPORT_METOD_PAX_MIGRATION_BUNDLE.sh` stopt de service voor een consistente
snapshot, kopieert uitsluitend externe state en operationele credentials naar
een tijdelijke root-only stagingmap, verzegelt ieder bestand met SHA-256 en
schrijft alleen een symmetrisch OpenPGP/AES-256-versleutelde bundle.

`INSTALL_METOD_PAX_CLEAN_SERVER.sh` installeert op Debian/Ubuntu de minimale
benodigdheden, controleert de optionele bundle-sidecar, ontsleutelt in een
root-only tijdelijke map, weigert padtraversal, links en speciale bestanden,
verifieert het volledige manifest, valideert state/credentials en start daarna
de bootstrapmodus. Oude environmentbestanden worden alleen als versleuteld
bewijs meegenomen en nooit als shellcode ingelezen.

## Ongewijzigde applicatie

De browserapplicatie, backend, optimizer, HTTP-contracten en klantdatamodellen
blijven exact de R9RC1-applicatiecomponent. R9RC3 wijzigt uitsluitend release-,
installatie-, migratie- en herstelinstrumentatie.

## Gates

De bron- en artifactgates moeten inclusief de nieuwe installatietests slagen.
Daarna blijven een echte orphan-recovery op de huidige VPS, een installatie op
een wegwerpbare schone server, Chromium/WebKit en echte iPhone Safari verplicht.
Tot die bewijzen bestaan blijft `releaseEligible=false` en productie `NO_GO`.

