# HANDOVER — Configurator Studio v1.5.1

## Definitieve richting

v1.1 is de Reliable Configurator Core, gebaseerd op het oorspronkelijke plan + Claude audit + fixes-file.

## Niet-onderhandelbare regels

1. AI/output mag nooit zelf facts bevestigen.
2. Confirmed facts vereisen user/admin/measured/import verification.
3. Maten/prijsinput mogen nooit op AI-schatting gebaseerd zijn.
4. Gate decisions zijn boolean/per critical field, niet score-based.
5. Model moet configureerbaar/segmenteerbaar zijn voordat builder/publish doorgaat.
6. Pricing Engine is de enige bron van prijs.
7. Rule Engine mag prijzen alleen activeren/deactiveren via pricing rules.
8. Runtime configs zijn immutable snapshots.
9. Elke schema/object is workspace/project scoped.
10. Customer UI verbergt interne provider- en architectuurdetails.

## v1.1 bevat

- Static premium UI.
- Builder Draft modal met click-to-action model.
- Context menu voor no-code acties.
- Simulatie van configureerbaar versus niet-configureerbaar model.
- Engine schemas in `engine/schemas`.
- Engine core functions in `engine/core`.
- Builder core in `engine/builder-core`.
- Job/ledger core in `engine/job-core`.
- Mock adapters in `engine/provider-adapters`.
- Smoke tests in `engine/tests/engine-smoke-test.js`.

## Testen

Run lokaal of op server in uitgepakte map:

```bash
node engine/tests/engine-smoke-test.js
```

of:

```bash
npm run test:engine
```

## Scope bewust niet in v1.1

- Geen echte externe provider calls.
- Geen echte foto-naar-3D generatie.
- Geen automatische match score als waarheid.
- Geen manual formula engine.
- Geen volledige Shopify app.


## v1.1.1 mobile fix

- Builder modal gebruikt nu een flex layout met echte `100dvh` mobiele scroll.
- `.builder-shell` is de enige mobiele scrollcontainer met `-webkit-overflow-scrolling: touch`.
- 3D-preview is compacter op iPhone.
- Productblokken, inspector en publish checks staan onder elkaar en blijven bereikbaar.
- Contextmenu gedraagt zich op mobiel als bottom sheet.
- Paywall-overlay blijft verwijderd.


## v1.2 Builder State Engine

- Contextmenu-acties bouwen nu live de no-code blueprint-state op.
- Link part, material, dimension, variant, pricing, rule en orderdata hebben zichtbare effecten.
- Tabs Parts / Options / Pricing / Rules schakelen nu echt tussen builder-state.
- Pricing breakdown wordt dynamisch opgebouwd uit pricing rules.
- Publish checklist reageert op blueprint-state.
- Inspector heeft label-input, blok toevoegen en JSON-preview.
- Nieuwe engine helper: `createBuilderDraft`.
- Engine smoke-test uitgebreid met builder draft validatie.


## v1.3 Customer-Friendly Builder

- “Productblokken” is verduidelijkt naar klantlogische onderdelen en klantkeuzes.
- Builder-tabs zijn nu: Onderdelen, Klantkeuzes, Prijzen, Regels, Order.
- Pricing start niet meer met verzonnen bedragen.
- Basisprijs staat als “nog instellen” totdat de gebruiker een bedrag invoert.
- Prijsregels gebruiken de inspector-invoer: prijssoort + bedrag.
- Publish checklist blokkeert nu duidelijk op ontbrekende basisprijs.
- Link tussen onderdeel → keuze → prijs → order is klantvriendelijker uitgelegd.
- Nieuwe engine helper: `customerBuilder.js`.


## v1.4 Capability-Aware Builder Modes

- Builder heeft nu duidelijke scopes/modes:
  - Productniveau
  - Losse onderdelen
  - Materiaalzones
  - Eerst voorbereiden / één geheel
- Productniveau bevat nu ook kleur, materiaal en textuur voor het hele product.
- Contextmenu toont niet langer alle acties overal.
- Materiaalzones tonen alleen logische acties zoals kleur/materiaal/textuur/afwerking en meerprijs voor keuze.
- Maatopties staan op productniveau of expliciete dimension-driven onderdelen, niet op willekeurige vlakken.
- Varianten/zichtbaarheid staan alleen bij losse onderdelen.
- Single-mesh/één-geheel-modus behandelt het model als één product met materiaal, maat, prijs en orderdata.
- Nieuwe engine helper: `selectionCapabilities.js`.


## v1.5 Test Table GLB Integrated

- Echte testtafel GLB toegevoegd: `assets/test_table_configurator.glb`.
- Manifest toegevoegd: `assets/test_table_configurator_manifest.json`.
- Builder gebruikt nu testtafel-onderdelen:
  - Tafelblad
  - Accentstrip
  - Metalen frame en poten
- GLB viewer probeert het echte bestand te laden via de browser.
- Bij klikken op een onderdeel wordt het geselecteerde mesh/object visueel gehighlight.
- Als de 3D-library niet laadt, blijft de bestaande fallback-preview actief.
- Nieuwe engine helper: `engine/core/testTableManifest.js`.


## v1.5.1 Real GLB Only

- Fallback nepviewer is volledig uit de builder-viewer verwijderd.
- De viewer toont alleen nog de echte `assets/test_table_configurator.glb`.
- Three.js laadt via import-map zodat GLTFLoader/OrbitControls correct resolven.
- Als GLB laden faalt, verschijnt een echte foutmelding in plaats van fallback.
- Geselecteerde onderdelen lichten op via materiaal-highlight + BoxHelper.
- Selectie vanuit mesh-lijst probeert ook het echte 3D-onderdeel te highlighten.
