# DEPLOY v1.3

Gebruik na upload naar GitHub:

```bash
cd ~/apps/bitcoin-evidence-engine-mobile && git pull && \
rm -rf configurator-studio-v1.3 && unzip -o configurator-studio-v1.3.zip && \
cd configurator-studio-v1.3 && bash deploy/deploy-9999.sh && \
node engine/tests/engine-smoke-test.js && \
curl -I http://127.0.0.1:9999/ && \
echo "KLAAR — http://51.195.102.180:9999/"
```
