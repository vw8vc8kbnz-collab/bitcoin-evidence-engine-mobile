# Stock Evidence Engine v1.0.1 Clean

Backtest-first research lab voor stock signals.

- Clean package structure
- FastAPI dashboard on port 8798
- SQLite auto-init
- Yahoo/yfinance daily candles
- 4 first setups x 5 hold periods
- No template dependency, robust dashboard

## Install

```bash
cd /home/ubuntu
rm -rf stock_evidence_engine stock_evidence_engine_v1_clean.zip
wget -L -O stock_evidence_engine_v1_clean.zip "RAW_GITHUB_ZIP_URL"
unzip -o stock_evidence_engine_v1_clean.zip -d stock_evidence_engine
cd stock_evidence_engine
chmod +x install.sh run_backtest.sh
./install.sh
./run_backtest.sh "BB,PLTR,IONQ,SOUN,NVDA,AMD,TSLA" "2y"
```

Open: `http://SERVER_IP:8798`
