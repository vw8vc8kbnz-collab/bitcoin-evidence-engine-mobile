import numpy as np
import pandas as pd
from .features import add_features
from .setups import SETUPS


def evaluate_setup(df: pd.DataFrame, setup_name: str, hold_days: int, fee_bps: float = 10.0) -> dict:
    fdf = add_features(df)
    if fdf.empty or setup_name not in SETUPS:
        return empty_result(setup_name, hold_days)
    entries = SETUPS[setup_name](fdf).fillna(False)
    gross = fdf["close"].shift(-hold_days) / fdf["close"] - 1.0
    net = gross - (fee_bps / 10000.0)
    trades = net[entries].dropna()
    if trades.empty:
        return empty_result(setup_name, hold_days)
    return {
        "setup": setup_name,
        "hold_days": hold_days,
        "trades": int(len(trades)),
        "winrate": float((trades > 0).mean()),
        "avg_return": float(trades.mean()),
        "median_return": float(trades.median()),
        "best_return": float(trades.max()),
        "worst_return": float(trades.min()),
        "expectancy": float(trades.mean()),
    }

def empty_result(setup_name: str, hold_days: int) -> dict:
    return {"setup": setup_name, "hold_days": hold_days, "trades": 0, "winrate": 0.0, "avg_return": 0.0, "median_return": 0.0, "best_return": 0.0, "worst_return": 0.0, "expectancy": 0.0}
