import pandas as pd


def setup_volume_breakout(df: pd.DataFrame) -> pd.Series:
    return (df["close"] > df["high20"]) & (df["rel_volume"] >= 2.0)

def setup_ma50_reclaim(df: pd.DataFrame) -> pd.Series:
    prev = df["close"].shift(1) < df["ma50"].shift(1)
    now = df["close"] > df["ma50"]
    return prev & now & (df["rel_volume"] >= 1.2)

def setup_oversold_recovery(df: pd.DataFrame) -> pd.Series:
    return (df["rsi14"].shift(1) < 35) & (df["rsi14"] >= 35) & (df["close"] > df["close"].shift(1))

def setup_momentum_continuation(df: pd.DataFrame) -> pd.Series:
    return (df["close"] > df["ma20"]) & (df["ma20"] > df["ma50"]) & (df["ret1"] > 0.04) & (df["rel_volume"] >= 1.5)

SETUPS = {
    "volume_breakout": setup_volume_breakout,
    "ma50_reclaim": setup_ma50_reclaim,
    "oversold_recovery": setup_oversold_recovery,
    "momentum_continuation": setup_momentum_continuation,
}
