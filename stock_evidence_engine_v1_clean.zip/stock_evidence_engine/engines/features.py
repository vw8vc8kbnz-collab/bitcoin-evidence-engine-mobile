import pandas as pd
import numpy as np


def add_features(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df
    out = df.copy()
    close = out["close"]
    out["ret1"] = close.pct_change()
    out["ma20"] = close.rolling(20).mean()
    out["ma50"] = close.rolling(50).mean()
    out["vol20"] = out["volume"].rolling(20).mean()
    out["rel_volume"] = out["volume"] / out["vol20"]
    delta = close.diff()
    gain = delta.clip(lower=0).rolling(14).mean()
    loss = (-delta.clip(upper=0)).rolling(14).mean()
    rs = gain / loss.replace(0, np.nan)
    out["rsi14"] = 100 - (100 / (1 + rs))
    out["high20"] = close.rolling(20).max().shift(1)
    out["low20"] = close.rolling(20).min().shift(1)
    return out.dropna().reset_index(drop=True)
