import sqlite3
from pathlib import Path
from stock_evidence_engine.config.settings import DB_PATH

SCHEMA = """
CREATE TABLE IF NOT EXISTS runs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  tickers TEXT NOT NULL,
  period TEXT NOT NULL,
  notes TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS results (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  run_id INTEGER,
  ticker TEXT NOT NULL,
  setup TEXT NOT NULL,
  hold_days INTEGER NOT NULL,
  trades INTEGER NOT NULL,
  winrate REAL NOT NULL,
  avg_return REAL NOT NULL,
  median_return REAL NOT NULL,
  best_return REAL NOT NULL,
  worst_return REAL NOT NULL,
  expectancy REAL NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS signals (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  ticker TEXT NOT NULL,
  signal_class TEXT NOT NULL,
  score REAL NOT NULL,
  reason TEXT NOT NULL
);
"""

def connect(path: Path | None = None):
    db_path = Path(path or DB_PATH)
    db_path.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(str(db_path), check_same_thread=False)
    con.row_factory = sqlite3.Row
    con.executescript(SCHEMA)
    con.commit()
    return con

def latest_results(limit=200):
    con = connect()
    rows = con.execute("""
      SELECT r.created_at, x.* FROM results x
      LEFT JOIN runs r ON r.id=x.run_id
      ORDER BY x.id DESC LIMIT ?
    """, (limit,)).fetchall()
    con.close()
    return [dict(x) for x in rows]
