from fastapi import FastAPI
from fastapi.responses import HTMLResponse, JSONResponse
from stock_evidence_engine import __version__
from stock_evidence_engine.storage.db import latest_results, connect

app = FastAPI(title="Stock Evidence Engine")

CSS = """
body{margin:0;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Arial;background:#f6f7fb;color:#101827}.wrap{max-width:1100px;margin:0 auto;padding:28px}.hero{background:linear-gradient(135deg,#0d2b4d,#1f6fab);color:white;border-radius:28px;padding:28px;box-shadow:0 20px 40px #0b1b331f}.eyebrow{letter-spacing:.25em;text-transform:uppercase;color:#d7a64a;font-weight:800;font-size:13px}.title{font-size:42px;line-height:1;margin:10px 0 8px;font-weight:900}.sub{font-size:18px;opacity:.9}.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin:20px 0}.card{background:white;border-radius:22px;padding:22px;box-shadow:0 10px 25px #15213d14;border:1px solid #e8ecf4}.num{font-size:34px;font-weight:900}.muted{color:#647084;font-weight:700}.btn{display:inline-block;margin-top:16px;background:#ffca50;color:#071426;border-radius:18px;padding:14px 20px;text-decoration:none;font-weight:900}.table{width:100%;border-collapse:collapse;background:white;border-radius:20px;overflow:hidden;box-shadow:0 10px 25px #15213d14}th,td{padding:12px 14px;border-bottom:1px solid #eef1f6;text-align:left;font-size:14px}th{background:#101827;color:white}.pos{color:#07833f;font-weight:900}.neg{color:#b91c1c;font-weight:900}@media(max-width:760px){.grid{grid-template-columns:repeat(2,1fr)}.title{font-size:34px}.wrap{padding:18px}th,td{font-size:12px;padding:9px}.hide-sm{display:none}}
"""

def pct(x):
    try: return f"{float(x)*100:.2f}%"
    except Exception: return "-"

@app.get("/health")
def health():
    connect().close()
    return {"ok": True, "version": __version__}

@app.get("/api/results")
def api_results():
    return JSONResponse(latest_results(500))

@app.get("/", response_class=HTMLResponse)
def home():
    rows = latest_results(100)
    best = sorted([r for r in rows if r.get("trades",0)>0], key=lambda r: r.get("expectancy",0), reverse=True)[:25]
    total = len(rows)
    trades = sum(int(r.get("trades",0)) for r in rows)
    avg_exp = sum(float(r.get("expectancy",0)) for r in rows)/total if total else 0
    elite = len([r for r in rows if r.get("trades",0)>=3 and r.get("expectancy",0)>0.03])
    body_rows = "".join([
        f"<tr><td><b>{r['ticker']}</b></td><td>{r['setup']}</td><td>{r['hold_days']}d</td><td>{r['trades']}</td><td>{pct(r['winrate'])}</td><td class='{ 'pos' if r['expectancy']>=0 else 'neg'}'>{pct(r['expectancy'])}</td><td class='hide-sm'>{pct(r['best_return'])}</td><td class='hide-sm'>{pct(r['worst_return'])}</td></tr>"
        for r in best
    ]) or "<tr><td colspan='8'>Nog geen backtest-resultaten. Run: ./run_backtest.sh \"BB,PLTR,IONQ,SOUN,NVDA,AMD,TSLA\" \"2y\"</td></tr>"
    return f"""<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'><title>Stock Evidence Engine</title><style>{CSS}</style></head><body><div class='wrap'><div class='hero'><div class='eyebrow'>Backtest-first stock alpha lab</div><div class='title'>Stock Evidence Engine</div><div class='sub'>Research vóór live signals — Yahoo candles, setups, holding-period tests en evidence-based ranking.</div><a class='btn' href='/api/results'>API results</a></div><div class='grid'><div class='card'><div class='num'>{total}</div><div class='muted'>result rows</div></div><div class='card'><div class='num'>{trades}</div><div class='muted'>historical trades</div></div><div class='card'><div class='num'>{pct(avg_exp)}</div><div class='muted'>avg expectancy</div></div><div class='card'><div class='num'>{elite}</div><div class='muted'>positive candidates</div></div></div><h2>Beste evidence-resultaten</h2><table class='table'><thead><tr><th>Ticker</th><th>Setup</th><th>Hold</th><th>Trades</th><th>Winrate</th><th>Expectancy</th><th class='hide-sm'>Best</th><th class='hide-sm'>Worst</th></tr></thead><tbody>{body_rows}</tbody></table><p class='muted'>Version {__version__} · poort vrij instelbaar via systemd</p></div></body></html>"""
