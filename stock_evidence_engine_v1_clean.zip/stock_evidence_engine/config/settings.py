from pathlib import Path
import os

BASE_DIR = Path(__file__).resolve().parents[2]
DB_PATH = Path(os.getenv("SEE_DB_PATH", str(BASE_DIR / "data" / "see.sqlite")))
HOST = os.getenv("SEE_HOST", "0.0.0.0")
PORT = int(os.getenv("SEE_PORT", "8798"))
NTFY_TOPIC = os.getenv("NTFY_TOPIC", "")
