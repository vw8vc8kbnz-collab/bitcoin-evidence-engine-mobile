import argparse
from stock_evidence_engine.data.yahoo_client import load_history
from stock_evidence_engine.engines.backtester import evaluate_setup
from stock_evidence_engine.engines.setups import SETUPS
from stock_evidence_engine.storage.db import connect

HOLDS = [1, 3, 5, 10, 20]

def run_backtest(tickers: list[str], period: str):
    con = connect()
    cur = con.execute("INSERT INTO runs(tickers, period, notes) VALUES(?,?,?)", (",".join(tickers), period, "clean_v1"))
    run_id = cur.lastrowid
    total = 0
    for ticker in tickers:
        print(f"[SEE] Loading {ticker} {period}")
        df = load_history(ticker, period)
        if df.empty:
            print(f"[SEE] No data for {ticker}")
            continue
        for setup in SETUPS:
            for hold in HOLDS:
                r = evaluate_setup(df, setup, hold)
                con.execute("""
                  INSERT INTO results(run_id,ticker,setup,hold_days,trades,winrate,avg_return,median_return,best_return,worst_return,expectancy)
                  VALUES(?,?,?,?,?,?,?,?,?,?,?)
                """, (run_id, ticker, r["setup"], r["hold_days"], r["trades"], r["winrate"], r["avg_return"], r["median_return"], r["best_return"], r["worst_return"], r["expectancy"]))
                total += 1
        con.commit()
    con.close()
    print(f"[SEE] Done. Stored {total} result rows. Run ID: {run_id}")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--tickers", default="BB,PLTR,IONQ,SOUN,NVDA,AMD,TSLA")
    p.add_argument("--period", default="2y")
    args = p.parse_args()
    tickers = [x.strip().upper() for x in args.tickers.split(",") if x.strip()]
    run_backtest(tickers, args.period)

if __name__ == "__main__":
    main()
