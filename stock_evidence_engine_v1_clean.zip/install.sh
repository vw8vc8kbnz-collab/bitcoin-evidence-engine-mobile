#!/usr/bin/env bash
set -euo pipefail
APP_DIR="/home/ubuntu/stock_evidence_engine"
cd "$APP_DIR"
python3 -m venv .venv
.venv/bin/python -m pip install --upgrade pip wheel setuptools
.venv/bin/python -m pip install -r requirements.txt
mkdir -p data logs
cp .env.example .env 2>/dev/null || true
cat > /tmp/stock-evidence-dashboard.service <<SERVICE
[Unit]
Description=Stock Evidence Engine Dashboard
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=$APP_DIR
Environment=PYTHONPATH=$APP_DIR
Environment=SEE_DB_PATH=$APP_DIR/data/see.sqlite
ExecStart=$APP_DIR/.venv/bin/python -m uvicorn stock_evidence_engine.dashboard.app:app --host 0.0.0.0 --port 8798
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
SERVICE
sudo cp /tmp/stock-evidence-dashboard.service /etc/systemd/system/stock-evidence-dashboard.service
sudo systemctl daemon-reload
sudo systemctl enable stock-evidence-dashboard.service
sudo systemctl restart stock-evidence-dashboard.service
sudo ufw allow 8798/tcp || true
echo "Installed Stock Evidence Engine on port 8798"
