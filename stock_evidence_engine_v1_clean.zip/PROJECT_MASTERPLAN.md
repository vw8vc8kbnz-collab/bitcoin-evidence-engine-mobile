# Masterplan

Deze clean V1 is bewust backtest-first. Live ntfy-signalen komen pas nadat setups bewezen expectancy tonen.

Fase 1: hypotheses testen.
Fase 2: news/catalyst dataset toevoegen.
Fase 3: live scanner + ntfy.
Fase 4: lokale AI laag via FinBERT/Ollama.
