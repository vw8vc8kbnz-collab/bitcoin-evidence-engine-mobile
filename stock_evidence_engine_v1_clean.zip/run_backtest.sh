#!/usr/bin/env bash
set -euo pipefail
TICKERS="${1:-BB,PLTR,IONQ,SOUN,NVDA,AMD,TSLA}"
PERIOD="${2:-2y}"
cd /home/ubuntu/stock_evidence_engine
.venv/bin/python -m stock_evidence_engine.cli --tickers "$TICKERS" --period "$PERIOD"
