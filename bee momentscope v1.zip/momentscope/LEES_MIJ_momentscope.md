# BEE MomentScope — installatie

Een aparte webserver die op DIT moment alle vier engines evalueert en een
eerlijke samengestelde score geeft. Draait naast je daemon en Alpha Lab, op
eigen poort 8100.

## Wat het is (en niet is)
- WEL: toont welke engines nu vuren, hun historische winrate, de marktcontext,
  en een gewogen "long-bewijs"-score (50 = neutraal, hoger = meer bewezen edges
  actief).
- NIET: een prijsvoorspelling. "73% kans dat BTC stijgt" bestaat niet. De score
  is een samenstelling van bewezen setup-winrates, niet een kristallen bol.

## Installeren (na uitpakken via GitHub/Termius)
```
cd /home/ubuntu/bitcoin-engine-deploy/current
chmod +x momentscope/scripts/install_momentscope.sh
./momentscope/scripts/install_momentscope.sh
```
Kies een toegangssleutel (alleen letters/cijfers — geen ?!/spaties, die breken
de URL). Het script print de URL.

## Openen
```
http://<vps-ip>:8100/?key=<jouw-sleutel>
```

## Draait dit naast de rest?
Ja. Eigen service (momentscope.service), eigen poort (8100), eigen map. Raakt de
daemon, de forecast en de Alpha Lab NIET aan. Drie losse services die naast
elkaar draaien:
- bee-forecast.service  (de daemon, poort n.v.t.)
- alpha-lab.service     (poort 8000)
- momentscope.service   (poort 8100)

## Als de pagina niet laadt
Firewall. Check: `sudo systemctl status momentscope`, dan
`curl -s "http://localhost:8100/?key=SLEUTEL" -o /dev/null -w "%{http_code}"`.
200 lokaal maar niks extern = poort 8100 openzetten bij je VPS-provider.
