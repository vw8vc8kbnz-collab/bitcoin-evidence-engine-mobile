#!/usr/bin/env bash
set -euo pipefail
LAB="/home/ubuntu/bitcoin-engine-deploy/current/momentscope"
DST="/etc/systemd/system/momentscope.service"
PORT="${MOMENTSCOPE_PORT:-8100}"
echo "=== Installing BEE MomentScope ==="
read -p "Kies een toegangssleutel (alleen letters/cijfers, geen ?!/spaties): " KEY
[ -z "$KEY" ] && { echo "ERROR: lege sleutel"; exit 1; }
echo "[1/6] Check bestanden..."
[ -f "$LAB/bee_momentscope_server.py" ] || { echo "ERROR: server mist"; exit 1; }
[ -f "$LAB/bee_momentscope.html" ] || { echo "ERROR: html mist"; exit 1; }
echo "[2/6] Check pandas/numpy..."
python3 -c "import pandas,numpy" || { echo "Run: pip install pandas numpy --break-system-packages"; exit 1; }
echo "[3/6] Service installeren..."
sudo cp "$LAB/scripts/momentscope.service" "$DST"
sudo sed -i "s/CHANGE_THIS_KEY/$KEY/" "$DST"
echo "[4/6] Firewall poort $PORT..."
command -v ufw >/dev/null 2>&1 && sudo ufw allow ${PORT}/tcp || echo "  geen ufw; check provider firewall voor poort $PORT"
echo "[5/6] Enable + start..."
sudo systemctl daemon-reload
sudo systemctl enable momentscope.service
sudo systemctl restart momentscope.service
sleep 3
echo "[6/6] Verify..."
if ! sudo systemctl is-active --quiet momentscope.service; then
  echo "ERROR: niet actief"; sudo journalctl -u momentscope.service -n 30 --no-pager; exit 1
fi
IP=$(curl -s ifconfig.me 2>/dev/null || echo "<vps-ip>")
echo ""
echo "MomentScope draait. Open: http://$IP:$PORT/?key=$KEY"
echo "Status: sudo systemctl status momentscope"
