#!/usr/bin/env python3
"""
BEE MomentScope — momentopname-engine.

Aparte standalone webserver voor de VPS (eigen poort, naast de daemon en de
Alpha Lab). Gebruikt DEZELFDE data en feature-bronnen, maar heeft een eigen
'engine': hij combineert alle vier gevalideerde engines tot EEN momentscore
voor NU.

EERLIJKHEID — lees dit:
Het percentage is GEEN prijsvoorspelling ("73% kans dat BTC stijgt" bestaat
niet). Het is een SAMENGESTELDE SCORE van de bewezen edges: elke engine die nu
vuurt draagt zijn GEVALIDEERDE historische winrate bij, gewogen naar
betrouwbaarheid (robuustheid + sample). De score zegt: "op basis van de edges
die nu actief zijn, leunt het bewijs zoveel naar omhoog." Altijd met de
onderbouwing erbij, zodat je ziet waar het getal vandaan komt.

Start: python bee_momentscope_server.py
Open:  http://<vps-ip>:8100/?key=<token>
"""
import json, os, http.server, socketserver
from urllib.parse import urlparse, parse_qs
import pandas as pd, numpy as np

PORT = int(os.environ.get("MOMENTSCOPE_PORT", "8100"))
ACCESS_KEY = os.environ.get("MOMENTSCOPE_KEY", "bee-change-me")
CSV_PATH = os.environ.get("MOMENTSCOPE_CSV",
    "/home/ubuntu/bitcoin-engine-deploy/current/data/BTC_alle_lagen_gecombineerd.csv")
HTML_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "bee_momentscope.html")

# ----------------------------------------------------------------------
# Engine-definities: elk met gevalideerde winrate + betrouwbaarheidsgewicht.
# Deze cijfers komen uit de walk-forward validaties (eerlijk, niet opgepoetst).
# ----------------------------------------------------------------------
ENGINES = {
    "cycle_reversal":  {"win": 67, "horizon": "7d",  "weight": 1.00, "dir": "LONG",
                        "label": "Cycle Reversal (fear + neg funding)"},
    "coinbase_premium":{"win": 66, "horizon": "7d",  "weight": 0.85, "dir": "LONG",
                        "label": "Coinbase Premium (US institutionele vraag)"},
    "vwap_long":       {"win": 67, "horizon": "24h", "weight": 0.90, "dir": "LONG",
                        "label": "VWAP Mean-Reversion (onder fair value)"},
    "mean_rev_24h":    {"win": 57, "horizon": "24h", "weight": 0.70, "dir": "LONG",
                        "label": "Mean-Reversion (onder 24u-MA)"},
}

_DF = None
def load_data():
    global _DF
    if _DF is not None: return _DF
    path = CSV_PATH
    if not os.path.exists(path) and os.path.exists(path + ".gz"): path += ".gz"
    df = pd.read_csv(path)
    df["dt"] = pd.to_datetime(df["dt"], utc=True, errors="coerce")
    df = df.sort_values("dt").reset_index(drop=True)  # chronologisch (sorteerbug-les)
    _DF = df
    return df

def _col(df, *names):
    for n in names:
        if n in df.columns: return n
    return None

def evaluate_moment():
    """Evalueer ALLE engines op de meest recente candle. Geef per engine of hij
       vuurt + context, en een samengestelde eerlijke score."""
    df = load_data()
    close = _col(df, "close", "close_raw")
    fg = _col(df, "fear_greed"); funding = _col(df, "funding_rate")
    prem = _col(df, "coinbase_premium_pct")

    # huidige (laatste) waarden
    last = df.iloc[-1]
    now = {
        "dt": str(last["dt"]),
        "price": round(float(last[close]), 2),
        "fear_greed": None if pd.isna(last[fg]) else int(last[fg]),
        "funding_rate": None if pd.isna(last[funding]) else float(last[funding]),
        "coinbase_premium_pct": None if pd.isna(last[prem]) else round(float(last[prem]), 4),
    }

    # --- features voor de engines ---
    # daily VWAP (vandaag, sinds 00:00 UTC)
    today = df[df["dt"].dt.date == last["dt"].date()]
    tp = (today[_col(today,"high")] + today[_col(today,"low")] + today[close]) / 3
    vwap = (tp * today["volume"]).sum() / today["volume"].sum() if today["volume"].sum() > 0 else np.nan
    dist_vwap = (last[close] / vwap - 1) * 100 if vwap == vwap else None
    # 24u-MA
    ma24 = df[close].tail(24).mean()
    dist_ma24 = (last[close] / ma24 - 1) * 100

    fgv = now["fear_greed"]; fnd = now["funding_rate"]; prm = now["coinbase_premium_pct"]

    # --- welke engines vuren NU ---
    fires = {}
    fires["cycle_reversal"]   = bool(fgv is not None and fnd is not None and fgv < 30 and fnd < 0)
    fires["coinbase_premium"] = bool(prm is not None and prm > 0.1)
    fires["vwap_long"]        = bool(dist_vwap is not None and fgv is not None and fnd is not None
                                 and dist_vwap < -2 and fgv < 30 and fnd < 0)
    fires["mean_rev_24h"]     = bool(dist_ma24 < -5)

    # --- samengestelde score ---
    # elke vurende engine draagt (win-50) * weight bij = zijn edge boven coinflip
    total_weight = sum(e["weight"] for e in ENGINES.values())
    score_sum = 0.0
    active = []
    for key, meta in ENGINES.items():
        if fires[key]:
            edge_pts = (meta["win"] - 50) * meta["weight"]
            score_sum += edge_pts
            active.append({"key": key, "label": meta["label"], "win": meta["win"],
                           "horizon": meta["horizon"], "weight": meta["weight"]})
    # normaliseer naar 50-100 (50 = neutraal/niks vuurt, hoger = meer long-bewijs)
    max_possible = sum((e["win"]-50)*e["weight"] for e in ENGINES.values())
    lean = 50 + (score_sum / max_possible) * 50 if max_possible > 0 else 50
    lean = round(lean, 1)

    # eerlijke verdict-tekst
    n_active = len(active)
    if n_active == 0:
        verdict = "GEEN SETUP ACTIEF"
        explanation = ("Geen enkele engine vuurt op dit moment. Er is nu geen "
                       "gevalideerde edge actief — het systeem zou NO_TRADE zeggen. "
                       "Dat is normaal; de engines vuren maar een paar keer per maand.")
    elif n_active == 1:
        verdict = "ZWAK LONG-SIGNAAL"
        explanation = (f"1 engine vuurt: {active[0]['label']} "
                       f"(historisch {active[0]['win']}% winrate over {active[0]['horizon']}). "
                       "Eén losse engine is een bescheiden signaal, geen sterke confluence.")
    else:
        verdict = f"CONFLUENTIE — {n_active} ENGINES VUREN"
        labels = ", ".join(a["label"].split(" (")[0] for a in active)
        explanation = (f"{n_active} onafhankelijke engines wijzen tegelijk naar LONG: {labels}. "
                       "Meerdere onafhankelijke edges samen is sterker dan één losse. "
                       "Dit is een hoge-conviction moment.")

    return {
        "now": now,
        "features": {
            "dist_daily_vwap_pct": None if dist_vwap is None else round(dist_vwap, 2),
            "dist_ma24_pct": round(float(dist_ma24), 2),
        },
        "engines": [
            {"key": k, "label": ENGINES[k]["label"], "fires": fires[k],
             "win": ENGINES[k]["win"], "horizon": ENGINES[k]["horizon"]}
            for k in ENGINES
        ],
        "active_count": n_active,
        "lean_pct": lean,             # 50 = neutraal, hoger = meer long-bewijs
        "verdict": verdict,
        "explanation": explanation,
        "disclaimer": ("Dit percentage is GEEN prijsvoorspelling. Het is een gewogen "
                       "samenstelling van de historische winrates van de engines die NU "
                       "vuren. 50 = neutraal/niks actief. Geen enkele engine voorspelt de "
                       "prijs; ze tonen alleen bewezen setups. Live blijft de rechter."),
    }


class Handler(http.server.BaseHTTPRequestHandler):
    def _auth(self, qs): return qs.get("key",[""])[0] == ACCESS_KEY
    def do_GET(self):
        p = urlparse(self.path); qs = parse_qs(p.query)
        if p.path in ("/", "/index.html"):
            if not self._auth(qs):
                self.send_response(401); self.send_header("Content-Type","text/html"); self.end_headers()
                self.wfile.write(b"<h2>Toegang geweigerd</h2><p>Voeg ?key=TOKEN toe.</p>"); return
            try:
                with open(HTML_PATH,"rb") as f: body=f.read()
                self.send_response(200); self.send_header("Content-Type","text/html; charset=utf-8")
                self.end_headers(); self.wfile.write(body)
            except FileNotFoundError:
                self.send_response(500); self.end_headers(); self.wfile.write(b"html niet gevonden")
            return
        if p.path == "/api/moment":
            if not self._auth(qs):
                self.send_response(401); self.end_headers(); return
            try:
                body = json.dumps(evaluate_moment()).encode()
                self.send_response(200); self.send_header("Content-Type","application/json")
                self.end_headers(); self.wfile.write(body)
            except Exception as e:
                self.send_response(500); self.send_header("Content-Type","application/json")
                self.end_headers(); self.wfile.write(json.dumps({"error":str(e)}).encode())
            return
        self.send_response(404); self.end_headers()
    def log_message(self,*a): pass

if __name__ == "__main__":
    print(f"Loading data from {CSV_PATH} ...")
    try: print(f"Loaded {len(load_data())} rows.")
    except Exception as e: print(f"WAARSCHUWING: {e}")
    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer(("0.0.0.0", PORT), Handler) as httpd:
        print(f"MomentScope op poort {PORT}. Open http://<vps-ip>:{PORT}/?key={ACCESS_KEY}")
        httpd.serve_forever()
