# Complete technische overdracht — R9O3 WebKit-failure-remediation

## Hervatpunt

R9O3 herstelt uitsluitend de vier foutgroepen die de echte R9O2-run bewees.
De runtime en alle lokale/standalone gates zijn groen. De echte Chromium- en
WebKit-rerun is nog niet uitgevoerd; daarom zijn `releaseEligible` en
`productionGo` bewust `false`.

- runtimecommit: `620b87d9fffdcb5f5fe8a3d9a5a177f6a1296aaa`;
- checkpointtag: `r9o3-webkit-failure-remediation-candidate-checkpoint`;
- runtime: `METOD_PAX_R9O3_WEBKIT_FAILURE_REMEDIATION_CANDIDATE.zip`;
- runtime-SHA-256: `4530802ad560b069e8af8c9996347e3b7f6e5492ae03ae714732f412f2bac0ad`;
- immutable R8Z-SHA-256: `d3e8656d8d7d5a581a8186ef8fe2c91c19b2137a8654b2f2874497dd85255e62`;
- lokale status: `PASS`;
- externe status: `PENDING_R9O4`;
- productie: `NO_GO`.

## Wat de tool is

METOD/PAX Tool A is de Adzaagt-webapplicatie voor maatwerk METOD- en
PAX-fronten/panelen. De browser beheert materiaal- en paneelconfiguratie,
DXF-gedreven maten, nerfpreview, klantgegevens, prijsjobs, aanvragen,
annulering en bedankflow. De Pythonruntime bezit HTTP/security, Adminsessies,
duurzame requests/jobs, FIFO/admission, optimizerprocessen, finalisatie,
downloads en statische assets. De publieke shell en Adminpresentatie zijn
professioneel gesplitst in semantische HTML en externe CSS/JavaScript.

## Bewezen R9O2-input

De externe R9O2-run gebruikte echte Chromium 151.0.7922.34 en WebKit 26.5.
Van 15 fixtures slaagden er 8 en faalden er 7. De 100 contractasserties wezen
vier oorzaken aan: embedded-DXF-lifecycle rond refresh, vier candidate-only
ResizeObserver-loops, een eenmalige cancellation-hold die Chromium vóór
WebKit verbruikte, en Admin-overflow van 528 px in een 393 px WebKit-iPhone-
viewport. Dit bewijs is ongewijzigd in het checkpoint opgenomen.

## R9O3-correcties

1. De browserdriver registreert `requestfinished` en `requestfailed` en vereist
   een stabiele, volledig afgeronde embedded-DXF-requestset vóór refresh en
   teardown. Er is geen foutallowlist toegevoegd.
2. De gecontroleerde optimizer-hold wordt vóór iedere golden/candidate-run per
   browserprofiel exclusief en symlink-veilig herbewapend.
3. De drie betrokken ResizeObserver-eigenaren zijn frame-deferred,
   size-deduplicated en connection-aware; de nerfpreview observeert nog maar
   één zichtbare host.
4. Admin heeft een begrensde 640px-breakpointfix met wrapping en `min-width:0`
   voor de 393px-layout. `overflow-x:hidden` is niet gebruikt en de
   viewportassertion is niet verzwakt.

## Bewijs en integriteit

De volledige preflight passeert, inclusief alle historische regressiesuites,
security/supply-chain, release-identiteit, Python- en JavaScript-syntax,
HTTP-processmoke, deployment/restore en checksumcontrole. De gebouwde runtime
is daarna zonder Gitmetadata in een lege map uitgepakt en heeft dezelfde
volledige preflight opnieuw doorlopen: `PASS`, 453 leden, geen links, geen
traversal en één canonieke root.

Historische hashes zijn niet overschreven met nieuwe waarden. Waar R9O3 een
bestand bewust wijzigde, legt het R9O3-contract de actuele hash vast terwijl
het oudere fasecontract zijn historische waarde behoudt.

## Hervatten in een nieuwe chat

1. Verifieer `PACKAGE_MANIFEST_SHA256.txt` in de outer checkpoint-ZIP.
2. Lees `README_FIRST.md`, dit document en `R9O3_NEXT_STEP_R9O4.md`.
3. Verifieer runtime en R8Z tegen hun `.sha256`-sidecars.
4. Clone `git/METOD_PAX_R9_FULL_HISTORY_THROUGH_R9O3.bundle` en checkout de
   checkpointtag.
5. Behandel R8Z uitsluitend als immutable behavior-oracle.
6. Voer `operations/RUN_R9O4_EXTERNAL_BROWSER_GATE_TMUX.sh` uit.
7. Lever na afloop de volledige map `evidence/` terug; classificeer nooit op
   alleen een screenshot of exitcode.

## Wat na een groene R9O4 nog resteert

Een browser-PASS is nog geen live-GO. Daarna blijven minimaal echte
iPhone/Safari, kandidaat-VPS met TLS/reverse proxy/systemd, onafhankelijke
security- en full-history-secretscan, load/chaos/soak, off-host restore,
operations/observability, CAM/werkplaats/bedrijf en formele release-signoff.
