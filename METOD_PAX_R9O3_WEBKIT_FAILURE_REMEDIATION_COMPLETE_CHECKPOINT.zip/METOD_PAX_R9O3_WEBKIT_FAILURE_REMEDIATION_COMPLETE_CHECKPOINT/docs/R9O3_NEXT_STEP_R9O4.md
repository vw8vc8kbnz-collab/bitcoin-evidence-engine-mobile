# Volgende stap — R9O4 externe Chromium/WebKit-rerun

R9O3 is lokaal volledig groen maar blijft fail-closed `NO_GO`. De volgende en
enige toegestane stap is een echte externe rerun van alle 15 fixtures en alle
100 contractasserties tegen de immutable R8Z-oracle en de nieuwe R9O3-runtime.

## Verplichte uitvoering

- gebruik exact Playwright `1.62.0` Noble op digest
  `sha256:baed2032d533817f3dbe6425de795788430ba345e819a1201337009ba17c9d07`;
- gebruik echte Chromium en WebKit;
- voer de browserrun uit met `--network none`;
- gebruik uitsluitend de meegeleverde R8Z-ZIP als golden oracle;
- test de uitgepakte R9O3-runtime-ZIP, niet een handmatig gewijzigde map;
- voer de run in `tmux` uit zodat Termius mag sluiten;
- bewaar JSON, consolelog, exitcode, image-inspect en checksums;
- wijzig geen fixture, assertion, timeout of foutclassificatie na het zien van
  de uitkomst.

Gebruik `operations/RUN_R9O4_EXTERNAL_BROWSER_GATE_TMUX.sh` uit de complete
checkpoint-ZIP. Het script maakt een nieuwe, begrensde auditmap en overschrijft
geen R9O2-bewijs.

## Slagingscriterium

R9O4 is alleen `PASS` als 15/15 fixtures en 100/100 vereiste contractasserties
in alle vereiste profielen slagen, beide engines een totale PASS hebben, geen
fixture geblokkeerd is en R8Z plus kandidaat voor/na byte-ongewijzigd zijn.

Bij elke andere uitkomst blijft productie `NO_GO` en wordt het volledige
authentieke R9O4-bewijs teruggeleverd voor classificatie.
