#!/usr/bin/env bash
set -Eeuo pipefail

SESSION_NAME="metod-r9o4-browser-gate"
AUDIT_ROOT="/home/ubuntu/metod-r9o4-audit"
IMAGE="mcr.microsoft.com/playwright@sha256:baed2032d533817f3dbe6425de795788430ba345e819a1201337009ba17c9d07"
TAG="r9o3-webkit-failure-remediation-candidate-checkpoint"
RUNTIME_NAME="METOD_PAX_R9O3_WEBKIT_FAILURE_REMEDIATION_CANDIDATE"
SCRIPT_PATH="$(readlink -f "$0")"
PACKAGE_ROOT="$(cd "$(dirname "$SCRIPT_PATH")/.." && pwd -P)"

if [[ "${1:-}" != "--execute" ]]; then
  command -v tmux >/dev/null || { echo "FOUT: tmux ontbreekt" >&2; exit 2; }
  command -v docker >/dev/null || { echo "FOUT: Docker ontbreekt" >&2; exit 2; }
  if tmux has-session -t "$SESSION_NAME" 2>/dev/null; then
    echo "FOUT: tmux-sessie $SESSION_NAME bestaat al" >&2
    exit 2
  fi
  tmux new-session -d -s "$SESSION_NAME" "bash '$SCRIPT_PATH' --execute 2>&1 | tee '$PACKAGE_ROOT/R9O4_TMUX_LAUNCH.log'"
  echo "R9O4 draait losgekoppeld in tmux: $SESSION_NAME"
  echo "Volgen: tmux attach -t $SESSION_NAME"
  echo "Termius mag nu sluiten."
  exit 0
fi

[[ "$AUDIT_ROOT" == "/home/ubuntu/metod-r9o4-audit" ]] || { echo "Onveilige auditroot" >&2; exit 2; }
sudo find "$AUDIT_ROOT" -xdev -mindepth 1 -delete 2>/dev/null || true
sudo mkdir -p "$AUDIT_ROOT"/{candidate,evidence,golden}
sudo chown -R "$(id -u):$(id -g)" "$AUDIT_ROOT"

cd "$PACKAGE_ROOT"
sha256sum -c PACKAGE_MANIFEST_SHA256.txt
(cd runtime && sha256sum -c METOD_PAX_R9O3_WEBKIT_FAILURE_REMEDIATION_CANDIDATE.zip.sha256)
(cd baseline && sha256sum -c METOD_PAX_FIX660R8Z_PRELIVE_HARDENED.zip.sha256)

git clone git/METOD_PAX_R9_FULL_HISTORY_THROUGH_R9O3.bundle "$AUDIT_ROOT/repo"
git -C "$AUDIT_ROOT/repo" checkout --detach "$TAG"
unzip -q baseline/METOD_PAX_FIX660R8Z_PRELIVE_HARDENED.zip -d "$AUDIT_ROOT/golden"
unzip -q runtime/METOD_PAX_R9O3_WEBKIT_FAILURE_REMEDIATION_CANDIDATE.zip -d "$AUDIT_ROOT/candidate"

sudo docker image inspect "$IMAGE" > "$AUDIT_ROOT/evidence/R9O4_DOCKER_IMAGE_INSPECT.json"
sudo docker run --rm --init \
  -v "$AUDIT_ROOT:/audit" -w /audit/repo "$IMAGE" \
  bash -lc 'npm --prefix browser ci --ignore-scripts && node -e "const p=require(\"./browser/node_modules/playwright/package.json\"); if(p.version!==\"1.62.0\") process.exit(3); console.log(p.version)"' \
  > "$AUDIT_ROOT/evidence/R9O4_PLAYWRIGHT_PROVISIONING.log" 2>&1

set +e
sudo docker run --rm --init --ipc=host --network none \
  -v "$AUDIT_ROOT:/audit" -w /audit/repo "$IMAGE" \
  bash -lc "git config --global --add safe.directory /audit/repo && python3 -B tools/r9a_browser_oracle_tests.py -q && python3 -B tools/r9a_browser_oracle.py --registry contracts/R9A_BROWSER_FIXTURES.json --golden-release /audit/golden/METOD_PAX_FIX660R8_PRELIVE_HARDENED --candidate /audit/candidate/$RUNTIME_NAME --engines chromium webkit --json-output /audit/evidence/R9O4_BROWSER_GATE.json --playwright-module /audit/repo/browser/node_modules/playwright --chromium-executable /ms-playwright/chromium-1234/chrome-linux64/chrome --webkit-executable /ms-playwright/webkit-2336/pw_run.sh --probe-timeout 60 --suite-timeout 1800" \
  2>&1 | tee "$AUDIT_ROOT/evidence/R9O4_BROWSER_GATE_EXECUTION.log"
gate_exit="${PIPESTATUS[0]}"
set -e

printf 'R9O4_DOCKER_EXIT=%s\n' "$gate_exit" > "$AUDIT_ROOT/evidence/R9O4_BROWSER_GATE_EXIT.txt"
sha256sum "$AUDIT_ROOT"/evidence/* > "$AUDIT_ROOT/evidence/SHA256SUMS.txt"
sudo chown -R "$(id -u):$(id -g)" "$AUDIT_ROOT"
echo "R9O4 gereed: exit=$gate_exit"
echo "Bewijs: $AUDIT_ROOT/evidence"
exit "$gate_exit"
