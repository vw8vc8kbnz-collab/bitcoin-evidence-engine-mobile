# R9O4 uitvoeren via Termius en tmux

Het meegeleverde script maakt `/home/ubuntu/metod-r9o4-audit` opnieuw aan,
verifieert alle pakketchecksums, cloneert de volledige Git-bundle, pakt de
immutable R8Z en R9O3-runtime uit, verifieert Playwright 1.62.0 en start daarna
de echte Chromium/WebKit-gate zonder extern containernetwerk.

Start vanuit de uitgepakte checkpointmap:

```bash
bash operations/RUN_R9O4_EXTERNAL_BROWSER_GATE_TMUX.sh
```

Na de melding `Termius mag nu sluiten` blijft de audit draaien. Later volgen:

```bash
tmux attach -t metod-r9o4-browser-gate
```

Na afloop staat alle uitvoer in:

```text
/home/ubuntu/metod-r9o4-audit/evidence
```

Lever die volledige map als ZIP terug. Een exitcode of screenshot alleen is
niet genoeg om de gate te classificeren.
