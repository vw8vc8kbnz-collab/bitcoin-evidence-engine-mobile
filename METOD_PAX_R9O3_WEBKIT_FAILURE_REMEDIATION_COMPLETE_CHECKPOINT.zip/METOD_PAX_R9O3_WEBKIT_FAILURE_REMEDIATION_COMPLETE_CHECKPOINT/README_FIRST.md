# METOD/PAX R9O3 — lees dit eerst

Dit is de volledige, zelfstandige overdracht van
`R9O3_WEBKIT_FAILURE_REMEDIATION`.

## Status

- lokale volledige preflight: `PASS`;
- standalone lege-extractiepreflight: `PASS`;
- runtime-SHA-256: `4530802ad560b069e8af8c9996347e3b7f6e5492ae03ae714732f412f2bac0ad`;
- immutable R8Z-SHA-256: `d3e8656d8d7d5a581a8186ef8fe2c91c19b2137a8654b2f2874497dd85255e62`;
- externe Chromium/WebKit-rerun: `PENDING_R9O4`;
- releaseEligible: `false`;
- productie: `NO_GO`.

R9O3 is dus een volledig gebouwde en lokaal bewezen kandidaat, maar nog geen
live-release. Alleen authentiek R9O4-bewijs mag de browsergate veranderen.

## Verifieer eerst

Voer vanuit deze map uit:

```bash
sha256sum -c PACKAGE_MANIFEST_SHA256.txt
(cd runtime && sha256sum -c METOD_PAX_R9O3_WEBKIT_FAILURE_REMEDIATION_CANDIDATE.zip.sha256)
(cd baseline && sha256sum -c METOD_PAX_FIX660R8Z_PRELIVE_HARDENED.zip.sha256)
git bundle verify git/METOD_PAX_R9_FULL_HISTORY_THROUGH_R9O3.bundle
```

## Leesvolgorde voor een nieuwe chat of auditor

1. `docs/R9O3_COMPLETE_TECHNICAL_HANDOFF.md`
2. `docs/R9O3_WEBKIT_FAILURE_REMEDIATION_SCOPE.json`
3. `docs/R9O3_WEBKIT_FAILURE_REMEDIATION.json`
4. `docs/R9O3_NEXT_STEP_R9O4.md`
5. `evidence/local/R9O3_LOCAL_REMEDIATION_PASS.json`
6. `evidence/r9o2_vps/R9O2_BROWSER_GATE_ATTEMPT2.json`
7. `operations/README_R9O4_TMUX.md`

## Inhoud

- `runtime/`: de volledige deploybare R9O3-applicatiekandidaat;
- `baseline/`: de ongewijzigde R8Z behavior-oracle;
- `git/`: volledige Git-historie en checkpointtags;
- `external_gate_kit/`: exacte browsercontracten en gecorrigeerde oracle;
- `evidence/local/`: volledige lokale build-/gatebewijzen;
- `evidence/r9o2_vps/`: authentieke externe FAIL-input waarop R9O3 rust;
- `prior_audit/`: onafhankelijke eerdere audit en correcties;
- `prior_checkpoint/`: R9O2-overdrachtsdocumenten;
- `operations/`: losgekoppelde R9O4-uitvoering voor de VPS.

R8Z mag nooit worden gewijzigd, herlabeld of gedeployed als R9O3. Mutable
productiestate mag nooit met een code-rollback worden teruggedraaid.
