#!/usr/bin/env node
'use strict';

/*
 * R9A real-browser driver.
 *
 * This process is deliberately separate from the Python orchestrator: Node owns
 * only real Playwright browser processes and returns raw DOM/network/state
 * evidence.  It never edits a release and never upgrades a failed assertion to
 * a skip.  Screenshots are diagnostics and are intentionally not collected as
 * passing evidence.
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DRIVER_ID = 'r9a-real-playwright-driver-v1';
const JOB_HEADER = 'PartId;PanelName;Qty;LengthMm;WidthMm;ThicknessMm;MaterialCode;GrainGroup;RotationAllowed;H1;H2;W1;W2\n';
const PUBLIC_ID = 'decor_0123456789abcdefabcd';
const SECOND_PUBLIC_ID = 'decor_0123456789abcdefabce';
const ADMIN_USER = 'admin';
const ADMIN_PASSWORD = 'r9a-browser-fixture-password';

function parseArgs(argv) {
  const out = { engines: [], browserExecutables: {}, fixtureIds: [], optimizerHoldRoots: {} };
  for (let i = 2; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === '--mode') out.mode = argv[++i];
    else if (arg === '--registry') out.registry = argv[++i];
    else if (arg === '--golden-url') out.goldenUrl = argv[++i];
    else if (arg === '--candidate-url') out.candidateUrl = argv[++i];
    else if (arg === '--output') out.output = argv[++i];
    else if (arg === '--playwright-module') out.playwrightModule = argv[++i];
    else if (arg === '--engine') out.engines.push(argv[++i]);
    else if (arg === '--fixture-id') out.fixtureIds.push(argv[++i]);
    else if (arg === '--optimizer-hold-root') {
      const value = String(argv[++i] || '');
      const split = value.indexOf('=');
      if (split <= 0) throw new Error(`invalid --optimizer-hold-root: ${value}`);
      out.optimizerHoldRoots[value.slice(0, split)] = value.slice(split + 1);
    }
    else if (arg === '--browser-executable') {
      const value = String(argv[++i] || '');
      const split = value.indexOf('=');
      if (split <= 0) throw new Error(`invalid --browser-executable: ${value}`);
      out.browserExecutables[value.slice(0, split)] = value.slice(split + 1);
    } else throw new Error(`unknown argument: ${arg}`);
  }
  return out;
}

function atomicJson(file, value) {
  const target = path.resolve(file);
  const tmp = `${target}.tmp.${process.pid}.${crypto.randomBytes(4).toString('hex')}`;
  fs.mkdirSync(path.dirname(target), { recursive: true, mode: 0o700 });
  fs.writeFileSync(tmp, `${JSON.stringify(value, null, 2)}\n`, { mode: 0o600 });
  fs.renameSync(tmp, target);
  fs.chmodSync(target, 0o600);
}

function sha256File(file) {
  const hash = crypto.createHash('sha256');
  hash.update(fs.readFileSync(file));
  return hash.digest('hex');
}

function loadPlaywright(explicitModule) {
  const candidates = [];
  if (explicitModule) candidates.push(explicitModule);
  if (process.env.R9A_PLAYWRIGHT_MODULE) candidates.push(process.env.R9A_PLAYWRIGHT_MODULE);
  candidates.push('playwright');
  let lastError = null;
  for (const candidate of candidates) {
    try {
      const resolved = require.resolve(candidate);
      const api = require(resolved);
      let packagePath = null;
      try { packagePath = require.resolve('playwright/package.json', { paths: [path.dirname(resolved)] }); } catch (_) {}
      const packageVersion = packagePath ? JSON.parse(fs.readFileSync(packagePath, 'utf8')).version : 'unknown';
      return { api, resolved, packageVersion };
    } catch (error) { lastError = error; }
  }
  throw new Error(`Playwright module unavailable: ${lastError ? lastError.message : 'not found'}`);
}

function executableCandidate(engineName, browserType, overrides) {
  const override = overrides[engineName];
  if (override) return path.resolve(override);
  return path.resolve(browserType.executablePath());
}

async function probe(args, playwrightInfo) {
  const requested = args.engines.length ? args.engines : ['webkit', 'chromium'];
  const engines = {};
  for (const name of requested) {
    const browserType = playwrightInfo.api[name];
    const item = {
      engine: name,
      playwrightPackageVersion: playwrightInfo.packageVersion,
      playwrightModule: playwrightInfo.resolved,
      available: false,
      launchable: false,
      expectedExecutablePath: null,
      resolvedExecutablePath: null,
      executableSha256: null,
      browserVersion: null,
      error: null
    };
    if (!browserType || typeof browserType.launch !== 'function') {
      item.error = `Playwright does not expose engine ${name}`;
      engines[name] = item;
      continue;
    }
    let executable = null;
    try {
      item.expectedExecutablePath = path.resolve(browserType.executablePath());
      executable = executableCandidate(name, browserType, args.browserExecutables);
      item.resolvedExecutablePath = executable;
      const stat = fs.statSync(executable);
      if (!stat.isFile()) throw new Error('not a regular file');
      fs.accessSync(executable, fs.constants.R_OK | fs.constants.X_OK);
      item.available = true;
      item.executableSha256 = sha256File(executable);
    } catch (error) {
      item.error = `browser executable unavailable at ${executable || item.expectedExecutablePath}: ${error.message}`;
      engines[name] = item;
      continue;
    }
    let browser = null;
    try {
      browser = await browserType.launch({ headless: true, executablePath: executable });
      const context = await browser.newContext({ viewport: { width: 320, height: 240 } });
      const page = await context.newPage();
      await page.setContent('<main id="r9a-browser-probe">real browser</main>');
      const content = await page.locator('#r9a-browser-probe').textContent();
      if (content !== 'real browser') throw new Error('DOM probe did not round-trip');
      item.browserVersion = browser.version();
      item.launchable = true;
      await context.close();
    } catch (error) {
      item.error = `browser launch failed: ${error.message}`;
    } finally {
      if (browser) await browser.close().catch(() => {});
    }
    engines[name] = item;
  }
  return {
    schemaVersion: 2,
    driverId: DRIVER_ID,
    status: Object.values(engines).every(item => item.launchable) ? 'PASS' : 'NO_GO',
    nodeVersion: process.version,
    playwrightPackageVersion: playwrightInfo.packageVersion,
    playwrightModule: playwrightInfo.resolved,
    engines
  };
}

function sanitizeValue(value) {
  if (value === undefined) return null;
  if (value === null || typeof value === 'boolean' || typeof value === 'number') return value;
  if (typeof value === 'string') return value.length > 500 ? `${value.slice(0, 500)}…` : value;
  if (Array.isArray(value)) return value.slice(0, 200).map(sanitizeValue);
  if (typeof value === 'object') {
    const out = {};
    for (const key of Object.keys(value).sort()) {
      if (/token|password|secret|authorization|cookie/i.test(key)) {
        const raw = String(value[key] == null ? '' : value[key]);
        out[`${key}Present`] = Boolean(raw);
        out[`${key}Sha256`] = raw ? crypto.createHash('sha256').update(raw).digest('hex') : null;
      } else out[key] = sanitizeValue(value[key]);
    }
    return out;
  }
  return String(value);
}

function normalizeSemantic(value) {
  const relations = { job: new Map(), subjob: new Map(), request: new Map(), capability: new Map() };
  function alias(kind, raw) {
    if (raw == null || raw === '') return null;
    const text = String(raw);
    const map = relations[kind];
    if (!map.has(text)) map.set(text, `<${kind}:${map.size + 1}>`);
    return map.get(text);
  }
  function visit(current, keyHint = '') {
    if (Array.isArray(current)) return current.map(item => visit(item, keyHint));
    if (!current || typeof current !== 'object') {
      if (/^(jobId|parentJobId)$/i.test(keyHint)) return alias('job', current);
      if (/^subjobId$/i.test(keyHint)) return alias('subjob', current);
      if (/^requestId$/i.test(keyHint)) return alias('request', current);
      if (/^(cancelToken|accessToken)$/i.test(keyHint)) return alias('capability', current);
      return current;
    }
    const out = {};
    for (const [key, raw] of Object.entries(current)) {
      if (/timestamp|duration|elapsed|startedAt|createdAt|updatedAt|finishedAt/i.test(key)) out[key] = '<volatile>';
      else out[key] = visit(raw, key);
    }
    return out;
  }
  const normalized = visit(value);
  return {
    value: normalized,
    relationCardinality: Object.fromEntries(Object.entries(relations).map(([key, map]) => [key, map.size]))
  };
}

function stableJson(value) {
  if (Array.isArray(value)) return `[${value.map(stableJson).join(',')}]`;
  if (value && typeof value === 'object') return `{${Object.keys(value).sort().map(k => `${JSON.stringify(k)}:${stableJson(value[k])}`).join(',')}}`;
  return JSON.stringify(value);
}

function normalizedRoute(rawUrl) {
  try {
    const url = new URL(rawUrl);
    const pathname = decodeURIComponent(url.pathname);
    if (/^\/api\/jobs\/[^/]+\/status$/.test(pathname)) return '/api/jobs/{jobId}/status';
    if (/^\/api\/jobs\/[^/]+\/download\//.test(pathname)) return '/api/jobs/{jobId}/download/{filename}';
    return pathname;
  } catch (_) { return String(rawUrl || '').split('?')[0]; }
}

function networkCollector(page, sentinelRef) {
  const requests = [];
  const pending = new Map();
  page.on('request', request => {
    const item = {
      method: request.method(),
      route: normalizedRoute(request.url()),
      resourceType: request.resourceType(),
      hasAuthorization: Boolean(request.headers()['authorization']),
      status: null,
      outcome: 'pending',
      failure: null
    };
    const text = `${request.url()}\n${request.postData() || ''}`;
    if (sentinelRef.value && text.includes(sentinelRef.value)) item.containsResetSentinel = true;
    requests.push(item);
    pending.set(request, item);
  });
  page.on('response', response => {
    const request = response.request();
    const item = pending.get(request);
    if (item) item.status = response.status();
  });
  page.on('requestfinished', request => {
    const item = pending.get(request);
    if (item) item.outcome = 'finished';
  });
  page.on('requestfailed', request => {
    const item = pending.get(request);
    if (item) {
      item.outcome = 'failed';
      item.failure = String((request.failure() || {}).errorText || 'request failed');
    }
  });
  return {
    requests,
    async waitForQuiescence({ routePrefix, timeoutMs = 30000, idleMs = 250 } = {}) {
      const prefix = String(routePrefix || '');
      const deadline = Date.now() + timeoutMs;
      let lastCount = -1;
      let stableSince = Date.now();
      while (Date.now() < deadline) {
        const matching = requests.filter(item => !prefix || item.route.startsWith(prefix));
        if (matching.length !== lastCount) {
          lastCount = matching.length;
          stableSince = Date.now();
        }
        const active = matching.filter(item => item.outcome === 'pending');
        const failed = matching.filter(item => item.outcome === 'failed');
        if (failed.length) {
          throw new Error(`request quiescence failed for ${prefix || 'all routes'}: ${failed.map(item => `${item.method} ${item.route}: ${item.failure}`).join('; ')}`);
        }
        if (matching.length && active.length === 0 && Date.now() - stableSince >= idleMs) {
          return { routePrefix: prefix, requestCount: matching.length, completedCount: matching.length };
        }
        await new Promise(resolve => setTimeout(resolve, 25));
      }
      const matching = requests.filter(item => !prefix || item.route.startsWith(prefix));
      const active = matching.filter(item => item.outcome === 'pending');
      throw new Error(`request quiescence timeout for ${prefix || 'all routes'}: ${active.length} of ${matching.length} still pending`);
    },
    summary() {
      const counts = {};
      const statuses = {};
      for (const item of requests) {
        const key = `${item.method} ${item.route}`;
        counts[key] = (counts[key] || 0) + 1;
        const statusKey = `${key} ${item.status == null ? 'pending' : item.status}`;
        statuses[statusKey] = (statuses[statusKey] || 0) + 1;
      }
      return {
        requestsTotal: requests.length,
        counts,
        statuses,
        authorizationRequestCount: requests.filter(item => item.hasAuthorization).length,
        resetSentinelLeakCount: requests.filter(item => item.containsResetSentinel).length
      };
    }
  };
}

async function enforceLoopbackOrigin(page, baseUrl) {
  const expected = new URL(baseUrl);
  const blocked = [];
  await page.route('**/*', async route => {
    const raw = route.request().url();
    let url;
    try { url = new URL(raw); } catch (_) { await route.abort('blockedbyclient'); return; }
    if (['data:', 'blob:', 'about:'].includes(url.protocol)) { await route.continue(); return; }
    if ((url.protocol === 'http:' || url.protocol === 'https:') && url.origin === expected.origin) {
      await route.continue();
      return;
    }
    blocked.push({ method: route.request().method(), origin: url.origin, route: normalizedRoute(raw) });
    await route.abort('blockedbyclient');
  });
  if (typeof page.routeWebSocket === 'function') {
    await page.routeWebSocket('**/*', socket => {
      let url;
      try { url = new URL(socket.url()); } catch (_) {
        blocked.push({ method: 'WEBSOCKET', origin: 'invalid', route: String(socket.url()) });
        socket.close();
        return;
      }
      const expectedWsProtocol = expected.protocol === 'https:' ? 'wss:' : 'ws:';
      const expectedHost = expected.host;
      if (url.protocol === expectedWsProtocol && url.host === expectedHost) {
        socket.connectToServer();
        return;
      }
      blocked.push({ method: 'WEBSOCKET', origin: url.origin, route: normalizedRoute(url.href) });
      socket.close();
    });
  }
  return blocked;
}

function assertionCollector() {
  const assertions = [];
  function check(kind, id, ok, actual, expected) {
    assertions.push({ id, kind, ok: Boolean(ok), actual: sanitizeValue(actual), expected: sanitizeValue(expected) });
    return Boolean(ok);
  }
  function equal(kind, name, actual, expected) { return check(kind, name, stableJson(actual) === stableJson(expected), actual, expected); }
  return { assertions, check, equal };
}

function enforceNetworkExpectations(fixture, networkSummary, assert) {
  const expectations = fixture.networkExpectations || {};
  for (const [requestKey, bounds] of Object.entries(expectations)) {
    const separator = requestKey.indexOf(' ');
    if (separator <= 0) {
      assert.check('network', `network-expectation-key:${requestKey}`, false, requestKey, 'METHOD /path');
      continue;
    }
    const count = Number(networkSummary.counts[requestKey] || 0);
    const minimum = Number(bounds.minimum || 0);
    const maximum = Number(bounds.maximum == null ? Number.MAX_SAFE_INTEGER : bounds.maximum);
    assert.check('network', `network-min:${requestKey}`, count >= minimum, count, `>=${minimum}`);
    assert.check('network', `network-max:${requestKey}`, count <= maximum, count, `<=${maximum}`);
    const statuses = [];
    for (const [statusKey, statusCount] of Object.entries(networkSummary.statuses)) {
      if (!statusKey.startsWith(`${requestKey} `)) continue;
      const statusText = statusKey.slice(requestKey.length + 1);
      for (let index = 0; index < Number(statusCount); index += 1) statuses.push(statusText);
    }
    const complete = statuses.length === count && statuses.every(status => /^\d+$/.test(status));
    assert.check('network', `network-complete:${requestKey}`, complete, statuses, `${count} completed responses`);
    const acceptedStatuses = Array.isArray(bounds.acceptedStatuses) && bounds.acceptedStatuses.length
      ? new Set(bounds.acceptedStatuses.map(String))
      : null;
    const success = statuses.every(status => {
      if (acceptedStatuses) return acceptedStatuses.has(status);
      const number = Number(status);
      return number >= 200 && number < 400;
    });
    assert.check('network', `network-status:${requestKey}`, success, statuses, acceptedStatuses ? Array.from(acceptedStatuses) : 'HTTP 2xx/3xx');
  }
}

async function waitForTool(page) {
  await page.goto('/toolA.html?oracle=r9a', { waitUntil: 'domcontentloaded', timeout: 30000 });
  await page.waitForFunction(() => Boolean(window.state && document.querySelector('#wizardFooter')), null, { timeout: 30000 });
  await page.locator('.decorCard[data-decor-id]').first().waitFor({ state: 'visible', timeout: 30000 });
}

async function activate(locator, profile) {
  if (profile.hasTouch) await locator.tap({ timeout: 15000 });
  else await locator.click({ timeout: 15000 });
}

async function selectMaterialCards(page, profile, count = 1) {
  await waitForTool(page);
  const cards = page.locator('.decorCard[data-decor-id]');
  const available = await cards.count();
  if (available < count) throw new Error(`fixture catalog has ${available} cards, expected ${count}`);
  for (let index = 0; index < count; index += 1) await activate(cards.nth(index), profile);
  await page.waitForFunction(expected => Array.isArray(window.state.materialBatches) && window.state.materialBatches.length === expected, count);
}

async function choosePanelThroughUi(page, profile, quantity = 2) {
  await activate(page.locator('#wizardNextBtn'), profile);
  await page.waitForFunction(() => document.body.dataset.uiStep === 'panels');
  await page.locator('#typeSel').selectOption('deur');
  await page.waitForFunction(() => Array.from(document.querySelectorAll('#sizeSel option')).some(option => /Metod deur 60x40/i.test(option.textContent || '')));
  const optionValue = await page.locator('#sizeSel').evaluate(select => {
    const option = Array.from(select.options).find(item => /Metod deur 60x40/i.test(item.textContent || ''));
    return option ? option.value : '';
  });
  if (!optionValue) throw new Error('Metod deur 60x40 option unavailable');
  await page.locator('#sizeSel').selectOption(optionValue);
  await page.locator('#qty').fill(String(quantity));
  await page.waitForFunction(() => {
    const button = document.getElementById('addBtnInline');
    return Boolean(button && !button.disabled);
  });
  // Use Playwright's trusted mouse click for this compact footer control on
  // every profile. A synthetic touchscreen tap can be retargeted while the
  // iPhone drawer/footer finishes its layout transition; the browser click is
  // still a real UI event and avoids silently adding zero panels. Touch input
  // remains covered by the dedicated mobile-cart and grain controls.
  await page.locator('#addBtnInline').click({ timeout: 15000 });
  await page.waitForFunction(expected => Array.isArray(window.state.cart) && window.state.cart.reduce((total, item) => total + Math.max(1, Number(item.qty || 1)), 0) === expected, quantity);
  return { optionValue };
}

async function buildGrainGroupThroughUi(page, profile) {
  await activate(page.locator('#wizardNextBtn'), profile);
  await page.locator('#grainOverlay').waitFor({ state: 'visible', timeout: 15000 });
  for (let index = 0; index < 2; index += 1) {
    const control = profile.formFactor === 'iphone'
      ? page.locator('#grainEligible .fix660CompactPlus:not([disabled])').first()
      : page.locator('#grainEligible .grainChip:not(.disabled)').first();
    await control.waitFor({ state: 'visible', timeout: 15000 });
    await activate(control, profile);
  }
  await page.waitForFunction(() => (window.state.grain.groups || []).some(group => Array.isArray(group.items) && group.items.length === 2));
  if (profile.formFactor === 'iphone') {
    const handle = page.locator('#fix660DrawerHandle');
    await handle.waitFor({ state: 'visible', timeout: 15000 });
    if (await handle.getAttribute('aria-expanded') !== 'true') await activate(handle, profile);
    await page.waitForFunction(() => {
      const group = (window.state.grain.groups || []).find(item => Array.isArray(item.items) && item.items.length === 2);
      const preview = document.getElementById('grainPreview');
      return Boolean(group && preview && preview.dataset.fix660Rendered === '1' && /2 panelen/.test(String((document.getElementById('fix649PreviewSummary') || {}).textContent || '')));
    });
  }
  await page.waitForFunction(() => {
    const readiness = window.ToolAGrainStudioRenderer && window.ToolAGrainStudioRenderer.productionReadiness();
    return Boolean(readiness && readiness.ok && readiness.required === 1);
  });
}

async function fillCustomerThroughUi(page, overrides = {}) {
  const fields = {
    custFirstName: 'R9A', custLastName: 'Browserklant', custCompany: 'R9A Audit BV',
    custEmail: 'r9a-browser@example.invalid', custPhone: '+31 6 12345678',
    custBillingAddress: 'Bewijsstraat', custPostcode: '1234 AB', custHouseNumber: '42-A',
    custNote: 'R9A browseroracle',
    ...overrides
  };
  for (const [id, value] of Object.entries(fields)) await page.locator(`#${id}`).fill(value);
  return fields;
}

async function publicJob(page, options = {}) {
  const quantity = Number(options.quantity || 1);
  const bulk = Boolean(options.bulk);
  return page.evaluate(async ({ publicId, jobHeader, quantityValue, bulkValue }) => {
    const dxfResponse = await fetch('/embedded_dxfs/Deuren%20METOD/Metod%20deur%2060x40.dxf', { cache: 'no-store' });
    if (!dxfResponse.ok) throw new Error(`DXF HTTP ${dxfResponse.status}`);
    const dxf = await dxfResponse.text();
    const customer = {
      firstName: 'R9A', lastName: 'Browserklant', company: 'R9A Audit BV',
      email: 'r9a-browser@example.invalid', phone: '+31 6 12345678',
      billingAddress: 'Bewijsstraat', shippingAddress: 'Bewijsstraat', shippingSameAsBilling: true,
      houseNumber: '42-A', postcode: '1234 AB', city: 'Utrecht', country: 'Nederland'
    };
    let payload;
    if (bulkValue) {
      const ids = Array.from({ length: quantityValue }, (_, index) => `PANEL_${String(index).padStart(3, '0')}`);
      payload = {
        panelsCsv: jobHeader + ids.map((id, index) => `${id};Browser bulk ${index};1;397;597;18;${publicId};;true;1;0;0;0\n`).join(''),
        dxfBlobs: { g0001: dxf }, dxfPartRefs: Object.fromEntries(ids.map(id => [id, 'g0001'])),
        jobJson: { customer, rest_material: { carry_out: true }, note: 'R9A browser bulk', grainEnabled: true }
      };
    } else {
      payload = {
        panelsCsv: jobHeader + `PANEL_A;Browserdeur;${quantityValue};397;597;18;${publicId};;true;1;0;0;0\n`,
        dxfParts: { PANEL_A: dxf },
        jobJson: { customer, rest_material: { carry_out: true }, note: 'R9A browser fixture', grainEnabled: true }
      };
    }
    const response = await fetch('/api/jobs', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    const body = await response.json().catch(() => ({}));
    return { status: response.status, body, customer };
  }, { publicId: PUBLIC_ID, jobHeader: JOB_HEADER, quantityValue: quantity, bulkValue: bulk });
}

async function pollJob(page, created, options = {}) {
  const maxPolls = Number(options.maxPolls || 120);
  const terminal = await page.evaluate(async ({ jobId, token, maximum, requireProcessing, requiredProgressMessage }) => {
    const history = [];
    for (let index = 0; index < maximum; index += 1) {
      const response = await fetch(`/api/jobs/${encodeURIComponent(jobId)}/status`, {
        cache: 'no-store', headers: { Authorization: `Bearer ${token}` }
      });
      const body = await response.json().catch(() => ({}));
      const status = String(body && body.meta && body.meta.status || '').toLowerCase();
      history.push({ httpStatus: response.status, status, progressPct: Number(body && body.meta && body.meta.progressPct || 0) });
      const progressMessage = String(body && body.meta && body.meta.progressMessage || '');
      if (requireProcessing && status === 'processing' && (!requiredProgressMessage || progressMessage.includes(requiredProgressMessage))) {
        return { body, history, observedProcessing: true };
      }
      if (['done', 'ready', 'ok', 'error', 'failed', 'cancelled', 'canceled'].includes(status)) return { body, history, observedProcessing: false };
      await new Promise(resolve => setTimeout(resolve, 20));
    }
    throw new Error('job poll budget exhausted');
  }, {
    jobId: created.body.jobId || created.body.parentJobId,
    token: created.body.accessToken,
    maximum: maxPolls,
    requireProcessing: Boolean(options.requireProcessing),
    requiredProgressMessage: String(options.requiredProgressMessage || '')
  });
  return terminal;
}

async function submitJob(page, created, customer) {
  return page.evaluate(async ({ jobId, token, customerValue }) => {
    const response = await fetch('/api/submit_config', {
      method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ parentJobId: jobId, customer: customerValue, note: 'R9A browser submit' })
    });
    return { status: response.status, body: await response.json().catch(() => ({})) };
  }, { jobId: created.body.jobId || created.body.parentJobId, token: created.body.accessToken, customerValue: customer });
}

async function adminProjection(page, requestId) {
  return page.evaluate(async ({ requestIdValue, user, password }) => {
    const loginResponse = await fetch('/api/admin/login', {
      method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: user, password, otp: '' })
    });
    const login = await loginResponse.json().catch(() => ({}));
    const adminStorageKeys = [...Object.keys(localStorage), ...Object.keys(sessionStorage)]
      .filter(key => /admin|auth|bearer/i.test(String(key || '')))
      .sort();
    const requestsResponse = await fetch('/api/admin/requests?limit=500', { cache: 'no-store', credentials: 'same-origin' });
    const requests = await requestsResponse.json().catch(() => ({}));
    const filesResponse = await fetch(`/api/admin/request_files?requestId=${encodeURIComponent(requestIdValue)}`, { cache: 'no-store', credentials: 'same-origin' });
    const filesPayload = await filesResponse.json().catch(() => ({}));
    const files = filesPayload && filesPayload.files && typeof filesPayload.files === 'object' ? filesPayload.files : filesPayload;
    const row = Array.isArray(requests.requests) ? requests.requests.find(item => String(item.requestId || '') === requestIdValue) : null;
    const listed = Array.isArray(files.allFiles) ? files.allFiles : [];
    const firstDxf = listed.find(item => /\.dxf$/i.test(String(item.rel || item.name || '')) && item.url);
    let individualDownload = null;
    if (firstDxf) {
      const response = await fetch(firstDxf.url, { cache: 'no-store', credentials: 'same-origin' });
      const bytes = new Uint8Array(await response.arrayBuffer());
      individualDownload = {
        status: response.status,
        bytes: bytes.byteLength,
        firstBytes: Array.from(bytes.slice(0, 8)),
        contentDisposition: response.headers.get('content-disposition') || '',
        expectedDownloadName: String(firstDxf.downloadName || firstDxf.name || '')
      };
    }
    const zipUrl = files && files.zip && files.zip.allDxfUrl;
    let zipDownload = null;
    if (zipUrl) {
      const response = await fetch(zipUrl, { cache: 'no-store', credentials: 'same-origin' });
      const bytes = new Uint8Array(await response.arrayBuffer());
      zipDownload = {
        status: response.status,
        bytes: bytes.byteLength,
        firstBytes: Array.from(bytes.slice(0, 8)),
        contentDisposition: response.headers.get('content-disposition') || ''
      };
    }
    return {
      loginStatus: loginResponse.status, loginOk: login.ok === true,
      loginHasToken: Object.prototype.hasOwnProperty.call(login, 'token'),
      adminStorageKeys,
      requestsStatus: requestsResponse.status, filesStatus: filesResponse.status,
      row, files, individualDownload, zipDownload
    };
  }, { requestIdValue: requestId, user: ADMIN_USER, password: ADMIN_PASSWORD });
}

async function scenarioAdminPresentationSessionAssets(env) {
  const { page, context, profile, assert } = env;
  const assetSnapshot = async (paths, method = 'GET') => page.evaluate(async ({ requested, requestMethod }) => {
    const rows = [];
    for (const path of requested) {
      const response = await fetch(path, { method: requestMethod, cache: 'no-store', credentials: 'same-origin' });
      const bytes = requestMethod === 'HEAD' ? 0 : (await response.arrayBuffer()).byteLength;
      rows.push({
        path,
        method: requestMethod,
        status: response.status,
        bytes,
        contentType: response.headers.get('content-type') || '',
        cacheControl: response.headers.get('cache-control') || '',
        nosniff: response.headers.get('x-content-type-options') || ''
      });
    }
    return rows;
  }, { requested: paths, requestMethod: method });
  const presentationSnapshot = () => page.evaluate(() => ({
    styleElements: document.querySelectorAll('style').length,
    inlineScripts: Array.from(document.scripts).filter(script => !script.src && String(script.textContent || '').trim()).length,
    styleAttributes: document.querySelectorAll('[style]').length,
    styleAttributeDetails: Array.from(document.querySelectorAll('[style]')).slice(0, 20).map(element => ({
      tag: element.tagName.toLowerCase(),
      id: element.id || '',
      className: String(element.className || ''),
      style: element.getAttribute('style') || ''
    })),
    inlineEventAttributes: Array.from(document.querySelectorAll('*')).reduce(
      (total, element) => total + Array.from(element.attributes).filter(attribute => /^on/i.test(attribute.name)).length,
      0
    ),
    stylesheets: Array.from(document.querySelectorAll('link[rel="stylesheet"]')).map(link => new URL(link.href).pathname).sort(),
    scripts: Array.from(document.scripts).filter(script => script.src).map(script => new URL(script.src).pathname).sort(),
    bodyScrollWidth: document.body.scrollWidth,
    viewportWidth: window.innerWidth
  }));

  const loginAssets = ['/admin/assets/login.css', '/admin/assets/login.js'];
  const protectedAssets = ['/admin/assets/admin.css', '/admin/assets/dxf.js', '/admin/assets/admin.js'];
  await page.goto('/admin/', { waitUntil: 'domcontentloaded' });
  await page.locator('#loginForm').waitFor({ state: 'visible', timeout: 15000 });
  const loginPresentation = await presentationSnapshot();
  const publicAssets = await assetSnapshot(loginAssets);
  const hiddenBefore = await assetSnapshot(protectedAssets);
  assert.check('dom', 'login-page-external-presentation-only',
    loginPresentation.styleElements === 0 && loginPresentation.inlineScripts === 0 && loginPresentation.styleAttributes === 0 &&
      loginPresentation.inlineEventAttributes === 0 &&
      stableJson(loginPresentation.stylesheets) === stableJson(['/admin/assets/login.css']) &&
      stableJson(loginPresentation.scripts) === stableJson(['/admin/assets/login.js']),
    loginPresentation, 'external login.css and login.js with no inline presentation');
  assert.check('network', 'anonymous-login-assets-http-200',
    publicAssets.every(item => item.status === 200 && item.bytes > 0 && item.cacheControl.includes('no-store') && item.nosniff === 'nosniff'),
    publicAssets, 'all anonymous login assets HTTP 200, non-empty, no-store and nosniff');
  assert.check('security', 'protected-assets-hidden-before-login', hiddenBefore.every(item => item.status === 404), hiddenBefore, 'all protected assets HTTP 404');

  const login = await page.evaluate(async ({ user, password }) => {
    const response = await fetch('/api/admin/login', {
      method: 'POST', credentials: 'same-origin', cache: 'no-store',
      headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' },
      body: JSON.stringify({ username: user, password, otp: '' })
    });
    return { status: response.status, body: await response.json().catch(() => ({})) };
  }, { user: ADMIN_USER, password: ADMIN_PASSWORD });
  assert.check('security', 'admin-login-ok', login.status === 200 && login.body && login.body.ok === true, login, 'HTTP 200 {ok:true}');

  await page.goto('/admin/', { waitUntil: 'domcontentloaded' });
  await page.locator('#adminLogoutBtn').waitFor({ state: 'visible', timeout: 15000 });
  const adminPresentation = await presentationSnapshot();
  const protectedGet = await assetSnapshot(protectedAssets);
  const protectedHead = await assetSnapshot(protectedAssets, 'HEAD');
  assert.check('dom', 'admin-main-external-presentation-only',
    adminPresentation.styleElements === 0 && adminPresentation.inlineScripts === 0 && adminPresentation.styleAttributes === 0 &&
      adminPresentation.inlineEventAttributes === 0 &&
      stableJson(adminPresentation.stylesheets) === stableJson(['/admin/assets/admin.css']) &&
      stableJson(adminPresentation.scripts) === stableJson(['/admin/assets/admin.js', '/admin/assets/dxf.js']),
    adminPresentation, 'external admin.css, dxf.js and admin.js with no inline presentation');
  assert.check('network', 'protected-assets-get-head-http-200',
    protectedGet.every(item => item.status === 200 && item.bytes > 0 && item.cacheControl.includes('no-store') && item.nosniff === 'nosniff') &&
      protectedHead.every(item => item.status === 200 && item.bytes === 0 && item.cacheControl.includes('no-store') && item.nosniff === 'nosniff'),
    { get: protectedGet, head: protectedHead }, 'authenticated GET/HEAD HTTP 200, no-store and nosniff');
  assert.check('dom', 'admin-layout-fits-viewport', adminPresentation.bodyScrollWidth <= adminPresentation.viewportWidth + 1,
    { bodyScrollWidth: adminPresentation.bodyScrollWidth, viewportWidth: adminPresentation.viewportWidth, formFactor: profile.formFactor }, 'body does not overflow viewport');
  await page.locator('#adminLogoutBtn').focus();
  const focused = await page.evaluate(() => document.activeElement && document.activeElement.id);
  assert.equal('dom', 'admin-keyboard-focus-target', focused, 'adminLogoutBtn');

  const logout = await page.evaluate(async () => {
    const response = await fetch('/api/admin/logout', {
      method: 'POST', credentials: 'same-origin', cache: 'no-store', headers: { 'X-Requested-With': 'fetch' }
    });
    return { status: response.status, body: await response.json().catch(() => ({})) };
  });
  assert.check('security', 'admin-logout-ok', logout.status === 200 && logout.body && logout.body.ok === true, logout, 'HTTP 200 {ok:true}');
  const hiddenAfter = await assetSnapshot(protectedAssets);
  assert.check('security', 'protected-assets-hidden-after-logout', hiddenAfter.every(item => item.status === 404), hiddenAfter, 'all protected assets HTTP 404 after logout');
  const cookies = await context.cookies();
  assert.equal('security', 'admin-cookie-cleared-after-logout', cookies.some(cookie => cookie.name === 'adzaagt_admin_session'), false);
  await page.goto('/admin/', { waitUntil: 'domcontentloaded' });
  const loginVisibleAfter = await page.locator('#loginForm').isVisible();
  assert.equal('dom', 'login-page-restored-after-logout', loginVisibleAfter, true);
  return {
    formFactor: profile.formFactor,
    externalLoginPresentation: true,
    protectedBeforeLogin: hiddenBefore.map(item => item.status),
    loginOk: login.status === 200 && login.body.ok === true,
    externalAdminPresentation: true,
    protectedGet: protectedGet.map(item => item.status),
    protectedHead: protectedHead.map(item => item.status),
    layoutFits: adminPresentation.bodyScrollWidth <= adminPresentation.viewportWidth + 1,
    keyboardFocus: focused,
    logoutOk: logout.status === 200 && logout.body.ok === true,
    protectedAfterLogout: hiddenAfter.map(item => item.status),
    loginRestored: loginVisibleAfter
  };
}

async function scenarioMaterialDesktopCart(env) {
  const { page, profile, assert } = env;
  await selectMaterialCards(page, profile, 2);
  const visible = await page.locator('.decorCard.is-selected').count();
  const snapshot = await page.evaluate(() => ({
    batches: (window.state.materialBatches || []).map(batch => String(batch.key || '')),
    active: String(window.state.activeMaterialKey || ''),
    chosen: document.querySelectorAll('#matChosen [data-mkey], #matChosen .matChip').length
  }));
  assert.check('dom', 'one-active-material-card', visible === 1, visible, 1);
  assert.check('state', 'two-material-batches', snapshot.batches.length === 2, snapshot.batches.length, 2);
  assert.check('state', 'active-key-is-selected', snapshot.batches.includes(snapshot.active), snapshot.active, snapshot.batches);
  return { selectedCardCount: visible, batchCount: snapshot.batches.length, activePresent: Boolean(snapshot.active) };
}

async function scenarioMaterialMobileCartRemove(env) {
  const { page, profile, assert } = env;
  await selectMaterialCards(page, profile, 2);
  await activate(page.locator('#mobileMaterialCartTrigger'), profile);
  await page.waitForFunction(() => document.body.classList.contains('mobileMaterialCartOpen'));
  const dialog = await page.locator('#mobileMaterialCartSheet').evaluate(element => ({
    ariaHidden: element.getAttribute('aria-hidden'), rect: element.getBoundingClientRect().toJSON()
  }));
  await activate(page.locator('[data-mobile-material-remove]').first(), profile);
  const removedImmediately = await page.waitForFunction(() => (window.state.materialBatches || []).length === 1, null, { timeout: 500 }).then(() => true).catch(() => false);
  if (!removedImmediately) {
    const confirm = page.locator('#removeMaterialConfirmBtn');
    await confirm.waitFor({ state: 'visible' });
    await activate(confirm, profile);
  }
  await page.waitForFunction(() => (window.state.materialBatches || []).length === 1);
  const snapshot = await page.evaluate(() => ({
    batchKeys: (window.state.materialBatches || []).map(batch => String(batch.key || '')),
    rows: document.querySelectorAll('[data-mobile-material-row]').length,
    orphanCart: (window.state.cart || []).some(item => !(window.state.materialBatches || []).some(batch => String(batch.key) === String(item.materialKey))),
    orphanGrain: (window.state.grain.groups || []).some(group => (group.items || []).some(ref => !String(ref || '').trim()))
  }));
  assert.equal('dom', 'mobile-dialog-open', dialog.ariaHidden, 'false');
  assert.check('dom', 'mobile-dialog-touch-size', dialog.rect.width > 250 && dialog.rect.height > 200, dialog.rect, 'width>250,height>200');
  assert.equal('dom', 'one-cart-row-after-remove', snapshot.rows, 1);
  assert.equal('state', 'one-batch-after-remove', snapshot.batchKeys.length, 1);
  assert.equal('state', 'no-orphan-cart', snapshot.orphanCart, false);
  assert.equal('state', 'no-orphan-grain', snapshot.orphanGrain, false);
  return { remainingBatchCount: 1, remainingRowCount: snapshot.rows, noOrphans: !snapshot.orphanCart && !snapshot.orphanGrain };
}

async function scenarioWizardKeyboardRefresh(env) {
  const { page, assert, network } = env;
  await waitForTool(page);
  const first = page.locator('.decorCard[data-decor-id]').first();
  await first.focus();
  await first.press('Enter');
  await page.waitForFunction(() => (window.state.materialBatches || []).length === 1);
  await page.locator('#wizardNextBtn').focus();
  await page.locator('#wizardNextBtn').press('Enter');
  await page.waitForFunction(() => document.body.dataset.uiStep === 'panels');
  const before = await page.evaluate(() => ({ step: document.body.dataset.uiStep, batches: window.state.materialBatches.length, visiblePages: Array.from(document.querySelectorAll('.stepPage')).filter(el => getComputedStyle(el).display !== 'none').length }));
  const beforeReloadQuiescence = await network.waitForQuiescence({ routePrefix: '/embedded_dxfs/', timeoutMs: 30000, idleMs: 250 });
  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.waitForFunction(() => Boolean(window.state && document.body.dataset.uiStep));
  const afterReloadQuiescence = await network.waitForQuiescence({ routePrefix: '/embedded_dxfs/', timeoutMs: 30000, idleMs: 250 });
  const after = await page.evaluate(() => ({
    step: document.body.dataset.uiStep,
    visiblePages: Array.from(document.querySelectorAll('.stepPage')).filter(el => getComputedStyle(el).display !== 'none').length,
    interactiveOverlays: Array.from(document.querySelectorAll('.overlay')).filter(el => getComputedStyle(el).display !== 'none' && getComputedStyle(el).pointerEvents !== 'none').length
  }));
  assert.equal('dom', 'keyboard-route-before-refresh', before.step, 'panels');
  assert.equal('dom', 'one-visible-page-before-refresh', before.visiblePages, 1);
  assert.equal('dom', 'one-visible-page-after-refresh', after.visiblePages, 1);
  assert.check('dom', 'no-competing-overlay-after-refresh', after.interactiveOverlays <= 1, after.interactiveOverlays, '<=1');
  assert.check('dom', 'refresh-route-is-valid', ['material', 'panels'].includes(after.step), after.step, ['material', 'panels']);
  return {
    keyboardRoute: before.step,
    refreshRoute: after.step,
    visiblePageCount: after.visiblePages,
    overlayCount: after.interactiveOverlays,
    dxfQuiescentBeforeReload: beforeReloadQuiescence.completedCount > 0,
    dxfQuiescentAfterReload: afterReloadQuiescence.completedCount > 0
  };
}

async function scenarioPanelConfiguration(env) {
  const { page, profile, assert } = env;
  await selectMaterialCards(page, profile, 1);
  const selected = await choosePanelThroughUi(page, profile, 2);
  const snapshot = await page.evaluate(() => {
    const item = (window.state.cart || [])[0] || {};
    return {
      rows: document.querySelectorAll('#cart .item, #panelDockList .panelDockRow').length,
      cartLength: (window.state.cart || []).length,
      groupCount: new Set((window.state.cart || []).map(entry => window.ToolAPanelMutations.groupKeyForItem(entry))).size,
      qty: (window.state.cart || []).reduce((total, entry) => total + Math.max(1, Number(entry.qty || 1)), 0), materialKey: String(item.materialKey || ''),
      activeKey: String(window.state.activeMaterialKey || ''), templateId: String(item.templateId || item.id || '')
    };
  });
  assert.equal('state', 'one-cart-group', snapshot.groupCount, 1);
  assert.equal('state', 'quantity-two', snapshot.qty, 2);
  assert.equal('state', 'panel-material-is-active', snapshot.materialKey, snapshot.activeKey);
  assert.check('state', 'selected-template-bound', Boolean(snapshot.templateId || selected.optionValue), snapshot.templateId, 'non-empty');
  assert.check('dom', 'cart-projection-present', snapshot.rows >= 1, snapshot.rows, '>=1');
  return { cartGroups: snapshot.groupCount, panelItemCount: snapshot.cartLength, quantity: snapshot.qty, materialBound: snapshot.materialKey === snapshot.activeKey, templateSelected: Boolean(snapshot.templateId || selected.optionValue) };
}

async function scenarioContinuousGrainPreview(env) {
  const { page, profile, assert } = env;
  await selectMaterialCards(page, profile, 1);
  await choosePanelThroughUi(page, profile, 2);
  await buildGrainGroupThroughUi(page, profile);
  const snapshot = await page.evaluate(() => {
    const group = (window.state.grain.groups || []).find(item => Array.isArray(item.items) && item.items.length) || {};
    const readiness = window.ToolAGrainStudioRenderer.productionReadiness();
    const preview = document.getElementById('grainPreview');
    const rect = preview.getBoundingClientRect();
    return {
      groupId: String(group.id || ''), itemCount: (group.items || []).length,
      materialKey: String(group.materialKey || ''), widthMm: Number(group.widthMm || 0),
      readiness: { ok: readiness.ok, required: readiness.required, tokenPrefix: String(readiness.token || '').split(':').slice(0, 2).join(':') },
      preview: {
        width: Math.round(rect.width), height: Math.round(rect.height),
        rendered: preview.dataset.fix660Rendered || '',
        canvasCount: preview.querySelectorAll('canvas.fix660GrainCanvas').length,
        summaryText: String((document.getElementById('fix649PreviewSummary') || {}).textContent || ''),
        panels: (group.items || []).length
      }
    };
  });
  assert.equal('state', 'grain-two-items', snapshot.itemCount, 2);
  assert.check('state', 'grain-material-local', Boolean(snapshot.materialKey), snapshot.materialKey, 'non-empty');
  assert.check('state', 'grain-width-positive', snapshot.widthMm > 0, snapshot.widthMm, '>0');
  assert.equal('state', 'grain-readiness-ok', snapshot.readiness.ok, true);
  assert.equal('state', 'grain-readiness-required-one', snapshot.readiness.required, 1);
  assert.check('dom', 'grain-preview-visible-box', snapshot.preview.width > 150 && snapshot.preview.height > 150, snapshot.preview, 'width,height>150');
  assert.check('dom', 'grain-preview-two-panels', snapshot.preview.panels === 2 && snapshot.preview.canvasCount === 1 && snapshot.preview.rendered === '1', snapshot.preview, 'two-panel group with one successfully rendered canvas');
  return snapshot;
}

async function scenarioCustomerSnapshotRefresh(env) {
  const { page, assert } = env;
  await waitForTool(page);
  await page.evaluate(() => window.__showWizardStep('customer'));
  const fields = await fillCustomerThroughUi(page);
  await page.locator('#custShipSame').uncheck();
  await page.locator('#custShippingAddress').fill('Andereweg');
  await page.evaluate(() => window.__showWizardStep('overview'));
  const before = await page.evaluate(() => ({
    checkout: window.state.checkout && window.state.checkout.customer,
    calculated: window.state.lastCalculatedCustomer,
    localDraft: localStorage.getItem('metod_draft_v1') || localStorage.getItem('metod_draft') || ''
  }));
  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.waitForFunction(() => Boolean(window.state));
  const storage = await page.evaluate(() => ({
    localDraft: localStorage.getItem('metod_draft_v1') || localStorage.getItem('metod_draft') || '',
    localKeys: Object.keys(localStorage), sessionKeys: Object.keys(sessionStorage)
  }));
  assert.equal('state', 'customer-first-name-committed', before.checkout.firstName, fields.custFirstName);
  assert.equal('state', 'customer-shipping-different', before.checkout.shippingAddress, 'Andereweg');
  assert.equal('state', 'customer-postcode-committed', before.checkout.postcode, fields.custPostcode);
  assert.check('privacy', 'pii-absent-local-draft-before', !before.localDraft.includes(fields.custEmail), before.localDraft.includes(fields.custEmail), false);
  assert.check('privacy', 'pii-absent-local-draft-after', !storage.localDraft.includes(fields.custEmail), storage.localDraft.includes(fields.custEmail), false);
  return { committedFields: Object.keys(before.checkout || {}).filter(key => String(before.checkout[key] || '').trim()).sort(), shippingSameAsBilling: before.checkout.shippingSameAsBilling, piiPersistedInLocalDraft: false };
}

async function scenarioJobCreatePollPricing(env) {
  const { page, assert } = env;
  await waitForTool(page);
  const created = await publicJob(page);
  assert.equal('network', 'job-create-http-status', created.status, 202);
  assert.check('network', 'job-id-present', Boolean(created.body.jobId), created.body.jobId, 'opaque present');
  assert.check('network', 'job-token-present', Boolean(created.body.accessToken), Boolean(created.body.accessToken), true);
  const terminal = await pollJob(page, created);
  const status = String(terminal.body && terminal.body.meta && terminal.body.meta.status || '').toLowerCase();
  const total = Number(terminal.body && terminal.body.pricingSummary && terminal.body.pricingSummary.totalInclVat || 0);
  assert.check('network', 'job-terminal-done', ['done', 'ready', 'ok'].includes(status), status, ['done', 'ready', 'ok']);
  assert.check('state', 'authoritative-price-positive', total > 0, total, '>0');
  assert.check('network', 'status-polled', terminal.history.length >= 1, terminal.history.length, '>=1');
  return { createStatus: created.status, terminalStatus: status, statusWasPolled: terminal.history.length >= 1, totalInclVat: total, pricingKeys: Object.keys(terminal.body.pricingSummary || {}).sort() };
}

async function fullUiPath(page, profile, assert, options = {}) {
  await selectMaterialCards(page, profile, 1);
  await choosePanelThroughUi(page, profile, 2);
  await buildGrainGroupThroughUi(page, profile);
  await activate(
    profile.formFactor === 'iphone'
      ? page.locator('#grainOverlay .fix660MobileActions .btnPrimary')
      : page.locator('#grainApplyBtn'),
    profile
  );
  await page.waitForFunction(() => document.body.dataset.uiStep === 'customer');
  const fields = await fillCustomerThroughUi(page, options.customerOverrides || {});
  await activate(page.locator('#wizardNextBtn'), profile);
  await page.locator('#overviewOverlay').waitFor({ state: 'visible' });
  const jobResponsePromise = page.waitForResponse(response => {
    const request = response.request();
    return request.method() === 'POST' && normalizedRoute(response.url()) === '/api/jobs';
  }, { timeout: 180000 });
  await activate(page.locator('#overviewNextBtn'), profile);
  const jobResponse = await jobResponsePromise;
  const jobBody = await jobResponse.json().catch(() => ({}));
  assert.equal('network', 'full-ui-job-create-http-202', jobResponse.status(), 202);
  assert.check('network', 'full-ui-job-id-present', Boolean(jobBody.jobId || jobBody.parentJobId), jobBody.jobId || jobBody.parentJobId, 'opaque present');
  await page.locator('#priceOverlay').waitFor({ state: 'visible', timeout: 180000 });
  const beforeSubmit = await page.evaluate(() => ({
    requestId: String(window.__metod_last_request_id || ''),
    thankYou: Boolean(document.getElementById('submitThanksOverlay')),
    total: document.getElementById('priceOverlayTotal') && document.getElementById('priceOverlayTotal').textContent,
    customer: window.state.checkout && window.state.checkout.customer
  }));
  assert.equal('dom', 'thank-you-absent-before-submit', beforeSubmit.thankYou, false);
  assert.equal('state', 'request-id-absent-before-submit', beforeSubmit.requestId, '');
  assert.check('state', 'price-visible-before-submit', /\d/.test(String(beforeSubmit.total || '')), beforeSubmit.total, 'formatted positive price');
  const submitResponsePromise = page.waitForResponse(response => {
    const request = response.request();
    return request.method() === 'POST' && normalizedRoute(response.url()) === '/api/submit_config';
  }, { timeout: 30000 });
  await activate(page.locator('#sendConfigBtn'), profile);
  const submitResponse = await submitResponsePromise;
  const submitBody = await submitResponse.json().catch(() => ({}));
  assert.equal('network', 'full-ui-submit-http-200', submitResponse.status(), 200);
  assert.equal('network', 'full-ui-submit-ok', submitBody.ok, true);
  await page.locator('#submitThanksOverlay').waitFor({ state: 'visible', timeout: 30000 });
  const committed = await page.evaluate(() => ({
    requestId: String(window.__metod_last_request_id || ''),
    title: document.getElementById('submitThanksTitle') && document.getElementById('submitThanksTitle').textContent,
    overlayText: document.getElementById('submitThanksOverlay') && document.getElementById('submitThanksOverlay').textContent,
    customer: window.state.checkout && window.state.checkout.customer
  }));
  assert.check('state', 'request-id-present-after-submit', Boolean(committed.requestId), committed.requestId, 'opaque present');
  assert.equal('state', 'submit-response-request-correlates', submitBody.requestId, committed.requestId);
  assert.check('dom', 'thank-you-title-visible', /Bedankt/i.test(committed.title || ''), committed.title, 'Bedankt');
  assert.check('dom', 'thank-you-references-request', String(committed.overlayText || '').includes(committed.requestId), true, true);
  const admin = await adminProjection(page, committed.requestId);
  const cookies = await page.context().cookies();
  const adminCookie = cookies.find(cookie => cookie.name === 'adzaagt_admin_session');
  assert.equal('network', 'admin-login-http-200', admin.loginStatus, 200);
  assert.equal('network', 'admin-login-ok', admin.loginOk, true);
  assert.equal('network', 'admin-requests-http-200', admin.requestsStatus, 200);
  assert.equal('network', 'admin-files-http-200', admin.filesStatus, 200);
  assert.check('state', 'admin-request-row-present', Boolean(admin.row), Boolean(admin.row), true);
  const adminEmail = admin.row && admin.row.customer && admin.row.customer.email;
  assert.equal('state', 'admin-customer-email-equals-ui', adminEmail, fields.custEmail);
  const allFiles = admin.files && Array.isArray(admin.files.allFiles) ? admin.files.allFiles : [];
  assert.check('state', 'admin-sealed-dxf-present', allFiles.some(item => /\.dxf$/i.test(String(item.rel || item.name || ''))), allFiles.length, '>=1 sealed DXF');
  assert.equal('privacy', 'admin-no-unsealed-diagnostic', allFiles.some(item => /diagnostic-unsealed|toolb_stdout/i.test(String(item.rel || ''))), false);
  return {
    jobId: String(jobBody.jobId || jobBody.parentJobId || ''),
    parentJobId: String(submitBody.parentJobId || jobBody.parentJobId || jobBody.jobId || ''),
    requestId: committed.requestId,
    requestCommitted: true,
    thankYouVisible: true,
    adminProjected: Boolean(admin.row),
    adminEmailMatches: adminEmail === fields.custEmail,
    sealedDxfCount: allFiles.filter(item => /\.dxf$/i.test(String(item.rel || item.name || ''))).length,
    adminLoginOk: admin.loginOk === true,
    adminLoginResponseHasBearer: admin.loginHasToken === true,
    adminAuthWebStorageKeys: admin.adminStorageKeys,
    adminSessionHttpOnly: Boolean(adminCookie && adminCookie.httpOnly),
    sealedFileCount: allFiles.length,
    individualDownload: {
      status: Number((admin.individualDownload || {}).status || 0),
      bytes: Number((admin.individualDownload || {}).bytes || 0),
      firstBytes: (admin.individualDownload || {}).firstBytes || [],
      validDxfName: /\.dxf/i.test(String((admin.individualDownload || {}).contentDisposition || '')) && /\.dxf$/i.test(String((admin.individualDownload || {}).expectedDownloadName || ''))
    },
    zipDownload: {
      status: Number((admin.zipDownload || {}).status || 0),
      bytes: Number((admin.zipDownload || {}).bytes || 0),
      firstBytes: (admin.zipDownload || {}).firstBytes || [],
      validZipName: /\.zip/i.test(String((admin.zipDownload || {}).contentDisposition || ''))
    }
  };
}

async function scenarioFullUiCheckout(env) {
  return fullUiPath(env.page, env.profile, env.assert);
}

async function scenarioSubmitThankYouAdmin(env) {
  const { page, assert } = env;
  await waitForTool(page);
  const created = await publicJob(page);
  assert.equal('network', 'submit-prerequisite-create', created.status, 202);
  const terminal = await pollJob(page, created);
  const status = String(terminal.body && terminal.body.meta && terminal.body.meta.status || '').toLowerCase();
  assert.check('network', 'submit-prerequisite-done', ['done', 'ready', 'ok'].includes(status), status, 'done');
  const submitted = await submitJob(page, created, created.customer);
  assert.equal('network', 'submit-http-status', submitted.status, 200);
  assert.equal('network', 'submit-ok', submitted.body.ok, true);
  assert.check('network', 'submit-request-id', Boolean(submitted.body.requestId), submitted.body.requestId, 'opaque present');
  await page.evaluate(data => window.__metodShowSubmissionThankYou(data), { requestId: submitted.body.requestId, pricingSummary: submitted.body.pricingSummary, customer: created.customer });
  const overlay = await page.locator('#submitThanksOverlay').evaluate(element => ({ text: element.textContent, rect: element.getBoundingClientRect().toJSON() }));
  assert.check('dom', 'thank-you-request-visible', overlay.text.includes(submitted.body.requestId), true, true);
  assert.check('dom', 'thank-you-touch-target', overlay.rect.width > 250 && overlay.rect.height > 250, overlay.rect, 'visible dialog');
  return { submitStatus: submitted.status, committed: true, thankYouVisible: true, totalInclVat: Number(submitted.body.pricingSummary && submitted.body.pricingSummary.totalInclVat || 0) };
}

async function scenarioAdminProjectionDownload(env) {
  const { page, profile, assert } = env;
  const completed = await fullUiPath(page, profile, assert);
  const individual = completed.individualDownload || {};
  const zip = completed.zipDownload || {};
  assert.equal('security', 'admin-cookie-httponly', completed.adminSessionHttpOnly, true);
  assert.equal('security', 'admin-login-response-has-no-bearer', completed.adminLoginResponseHasBearer, false);
  assert.equal('security', 'admin-auth-web-storage-empty', completed.adminAuthWebStorageKeys, []);
  assert.equal('state', 'admin-row-present', completed.adminProjected, true);
  assert.check('state', 'sealed-files-present', Number(completed.sealedFileCount || 0) > 0, completed.sealedFileCount, '>0');
  assert.check('network', 'admin-individual-download-bytes', individual.status === 200 && Number(individual.bytes || 0) > 0, individual, 'HTTP 200 non-empty DXF bytes');
  assert.equal('network', 'admin-individual-download-name', individual.validDxfName, true);
  assert.check('network', 'admin-zip-download-bytes', zip.status === 200 && Number(zip.bytes || 0) > 0 && zip.firstBytes && zip.firstBytes[0] === 80 && zip.firstBytes[1] === 75, zip, 'HTTP 200 non-empty ZIP bytes with PK signature');
  return {
    requestId: completed.requestId,
    parentJobId: completed.parentJobId,
    adminSessionHttpOnly: completed.adminSessionHttpOnly,
    adminLoginResponseHasBearer: completed.adminLoginResponseHasBearer,
    adminAuthWebStorageKeys: completed.adminAuthWebStorageKeys,
    customerProjectionMatches: completed.adminEmailMatches,
    sealedFileCount: completed.sealedFileCount,
    individualDownloadBytes: Number(individual.bytes || 0),
    zipDownloadBytes: Number(zip.bytes || 0)
  };
}

async function scenarioNewConfigurationReset(env) {
  const { page, profile, assert, sentinelRef, consoleMessages, network } = env;
  const sentinel = `R9A-PII-${crypto.randomBytes(12).toString('hex')}`;
  sentinelRef.value = sentinel;
  const committed = await fullUiPath(page, profile, assert, {
    customerOverrides: {
      custFirstName: sentinel,
      custLastName: 'Resetklant',
      custCompany: `Audit ${sentinel}`,
      custEmail: `${sentinel.toLowerCase()}@example.invalid`,
      custNote: `notitie ${sentinel}`
    }
  });
  const requestId = committed.requestId;
  const networkMarker = network.requests.length;
  const consoleMarker = consoleMessages.length;
  const capabilitySentinel = `R9A-CAP-${crypto.randomBytes(12).toString('hex')}`;
  await page.evaluate(({ value, capability }) => {
    window.__r9a_reset_generation = 'before-reset';
    window.__metod_checkout_live_customer = { email: `${value.toLowerCase()}@example.invalid`, note: value };
    window.__metod_active_parent_job_id = capability;
    window.__metod_last_job_access_token = capability;
    window.__metod_last_job_id = capability;
    window.__metod_last_parent_job_id = capability;
    window.__metod_last_request_cancel_token = capability;
    window.__metod_last_request_id = capability;
    window.__metod_price_auto_opened_job_id = capability;
    window.__metod_price_validated_key = capability;
    window.__metod_submitted_parent_job_id = capability;
    if (window.state) {
      window.state.activeAuthoritativeJobId = capability;
      window.state.lastJobAccessToken = capability;
      window.state.lastParentJobId = capability;
      window.state.lastJobId = capability;
      window.state.jobId = capability;
    }
    localStorage.setItem('metod_draft_v1', JSON.stringify({ note: value }));
    // Seed only storage keys that the product actually owns. The remaining
    // capability-shaped keys are asserted absent, but arbitrary attacker keys
    // are not incorrectly assigned to the application's reset contract.
    localStorage.setItem('metod_last_job_access_token', capability);
    for (const key of ['metod_last_job_access_token','metod_last_parent_job_id','metod_last_request_cancel_token','metod_last_request_id']) sessionStorage.setItem(key, capability);
    // Do not invent a PII-bearing URL that the product never creates. The
    // post-reset scan below still proves that the real submitted customer data
    // is absent from URL, reload requests, console and all browser stores.
    setTimeout(() => { window.__r9a_stale_callback_value = value; }, 120);
  }, { value: sentinel, capability: capabilitySentinel });
  await activate(page.locator('#submitThanksNew'), profile);
  await page.waitForFunction(() => Boolean(window.state && document.body.dataset.uiStep === 'material' && !window.__r9a_reset_generation), null, { timeout: 30000 });
  await page.waitForTimeout(300);
  const scan = await page.evaluate(async value => {
    const dom = document.documentElement.outerHTML.includes(value) || Array.from(document.querySelectorAll('input,textarea')).some(el => String(el.value || '').includes(value));
    const memory = JSON.stringify({ state: window.state, live: window.__metod_checkout_live_customer, stale: window.__r9a_stale_callback_value }).includes(value);
    const local = Object.entries(localStorage).some(([k, v]) => `${k}${v}`.includes(value));
    const session = Object.entries(sessionStorage).some(([k, v]) => `${k}${v}`.includes(value));
    let indexedDb = false;
    if (indexedDB.databases) {
      const dbs = await indexedDB.databases();
      for (const info of dbs) {
        if (`${info.name || ''}${info.version || ''}`.includes(value)) indexedDb = true;
        if (!info.name) continue;
        const db = await new Promise(resolve => { const request=indexedDB.open(info.name); request.onsuccess=()=>resolve(request.result); request.onerror=()=>resolve(null); });
        if (!db) continue;
        for (const storeName of Array.from(db.objectStoreNames)) {
          const found = await new Promise(resolve => {
            let hit=false;
            try {
              const request=db.transaction(storeName,'readonly').objectStore(storeName).openCursor();
              request.onsuccess=()=>{ const cursor=request.result; if(!cursor) return resolve(hit); if(JSON.stringify([cursor.key,cursor.value]).includes(value)) return resolve(true); cursor.continue(); };
              request.onerror=()=>resolve(hit);
            } catch (_) { resolve(false); }
          });
          if (found) indexedDb=true;
        }
        db.close();
      }
    }
    let cacheStorage = false;
    if ('caches' in window) { const names = await caches.keys(); for (const name of names) { const cache = await caches.open(name); for (const request of await cache.keys()) { const response = await cache.match(request); if (`${name}${request.url}${response ? await response.clone().text() : ''}`.includes(value)) cacheStorage = true; } } }
    const capabilityKeys = [
      'metod_last_job_access_token','metod_last_job_id','metod_last_parent_job_id',
      'metod_last_request_id','metod_last_request_cancel_token','metod_active_parent_job_id',
      'metod_price_validated_key','metod_submitted_parent_job_id'
    ];
    const capabilitySnapshot = {
      memory: {
        activeParentJobId: window.__metod_active_parent_job_id,
        lastJobAccessToken: window.__metod_last_job_access_token,
        lastJobId: window.__metod_last_job_id,
        lastParentJobId: window.__metod_last_parent_job_id,
        lastRequestCancelToken: window.__metod_last_request_cancel_token,
        lastRequestId: window.__metod_last_request_id,
        priceAutoOpenedJobId: window.__metod_price_auto_opened_job_id,
        priceValidatedKey: window.__metod_price_validated_key,
        submittedParentJobId: window.__metod_submitted_parent_job_id
      },
      controls: {
        priceLocked: window.__metod_price_locked,
        submitDone: window.__metod_submit_done,
        submitInflight: window.__metod_submit_inflight
      },
      state: {
        activeAuthoritativeJobId: window.state && window.state.activeAuthoritativeJobId,
        lastJobAccessToken: window.state && window.state.lastJobAccessToken,
        lastParentJobId: window.state && window.state.lastParentJobId,
        lastJobId: window.state && window.state.lastJobId,
        jobId: window.state && window.state.jobId
      },
      local: Object.fromEntries(capabilityKeys.map(key => [key, localStorage.getItem(key)])),
      session: Object.fromEntries(capabilityKeys.map(key => [key, sessionStorage.getItem(key)]))
    };
    const emptyIdentifier = item => item == null || item === false || item === 0 || String(item).trim() === '';
    const capabilityEmpty = Object.values(capabilitySnapshot).every(group => Object.values(group).every(emptyIdentifier));
    const customerValueFields = Array.from(document.querySelectorAll(
      '#stepCustomer textarea,#stepCustomer input:not([type="checkbox"]):not([type="radio"]):not([type="button"]):not([type="submit"]):not([type="hidden"])'
    ));
    return { dom, memory, local, session, indexedDb, cacheStorage, url: location.href.includes(value), capabilityEmpty, capabilitySnapshot, step: document.body.dataset.uiStep, cart: (window.state.cart || []).length, grain: (window.state.grain.groups || []).length, fields: customerValueFields.filter(el => String(el.value || '').trim()).length };
  }, sentinel);
  const postResetNetwork = network.requests.slice(networkMarker);
  const networkLeak = postResetNetwork.some(item => item.containsResetSentinel === true);
  const consoleLeak = consoleMessages.slice(consoleMarker).some(message => JSON.stringify(message).includes(sentinel));
  const preserved = await adminProjection(page, requestId);
  assert.equal('privacy', 'reset-sentinel-absent-dom', scan.dom, false);
  assert.equal('privacy', 'reset-sentinel-absent-memory', scan.memory, false);
  assert.equal('privacy', 'reset-sentinel-absent-local-storage', scan.local, false);
  assert.equal('privacy', 'reset-sentinel-absent-session-storage', scan.session, false);
  assert.equal('privacy', 'reset-sentinel-absent-indexeddb', scan.indexedDb, false);
  assert.equal('privacy', 'reset-sentinel-absent-cache-storage', scan.cacheStorage, false);
  assert.equal('privacy', 'reset-sentinel-absent-url', scan.url, false);
  assert.equal('privacy', 'reset-sentinel-absent-console', consoleLeak, false);
  assert.equal('privacy', 'reset-sentinel-absent-network-after-reset', networkLeak, false);
  assert.equal('security', 'reset-capabilities-empty', scan.capabilityEmpty, true);
  assert.equal('dom', 'reset-route-material', scan.step, 'material');
  assert.equal('state', 'reset-cart-empty', scan.cart, 0);
  assert.equal('state', 'reset-grain-empty', scan.grain, 0);
  assert.equal('dom', 'reset-visible-fields-empty', scan.fields, 0);
  assert.check('state', 'reset-backend-request-preserved', Boolean(preserved.row) && String(preserved.row.requestId || '') === requestId, preserved.row && preserved.row.requestId, requestId);
  return {
    requestId,
    parentJobId: committed.parentJobId,
    sentinelLeaks: ['dom','memory','local','session','indexedDb','cacheStorage','url'].filter(key => scan[key] === true),
    capabilityEmpty: scan.capabilityEmpty,
    capabilitySnapshot: scan.capabilitySnapshot,
    consoleLeak,
    networkLeak,
    route: scan.step,
    cartCount: scan.cart,
    grainGroupCount: scan.grain,
    backendRequestPreserved: Boolean(preserved.row)
  };
}

async function scenarioJobAndRequestCancellation(env) {
  const { page, assert } = env;
  await waitForTool(page);
  const created = await publicJob(page, { quantity: 250, bulk: true });
  assert.equal('network', 'cancel-job-create', created.status, 202);
  const active = await pollJob(page, created, {
    maxPolls: 200,
    requireProcessing: true,
    requiredProgressMessage: 'R9A optimizer active hold'
  });
  assert.equal('state', 'active-processing-observed', active.observedProcessing, true);
  const cancel = await page.evaluate(async ({ jobId, token }) => {
    const wrong = await fetch('/api/jobs/cancel', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer wrong-token' }, body: JSON.stringify({ jobId, reason: 'oracle-wrong-token' }) });
    const right = await fetch('/api/jobs/cancel', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` }, body: JSON.stringify({ jobId, reason: 'oracle-active-cancel' }) });
    const rightBody = await right.json().catch(() => ({}));
    const history = [];
    for (let index = 0; index < 120; index += 1) {
      const response = await fetch(`/api/jobs/${encodeURIComponent(jobId)}/status`, { cache: 'no-store', headers: { Authorization: `Bearer ${token}` } });
      const body = await response.json().catch(() => ({}));
      const status = String(body && body.meta && body.meta.status || '').toLowerCase();
      history.push(status);
      if (status === 'cancelled') break;
      if (['done','ready','ok','error','failed'].includes(status)) break;
      await new Promise(resolve => setTimeout(resolve, 20));
    }
    for (let index = 0; index < 3; index += 1) {
      await new Promise(resolve => setTimeout(resolve, 80));
      const response = await fetch(`/api/jobs/${encodeURIComponent(jobId)}/status`, { cache: 'no-store', headers: { Authorization: `Bearer ${token}` } });
      const body = await response.json().catch(() => ({}));
      history.push(String(body && body.meta && body.meta.status || '').toLowerCase());
    }
    return { wrongStatus: wrong.status, rightStatus: right.status, rightBody, history };
  }, { jobId: created.body.jobId, token: created.body.accessToken });
  const finalStatuses = cancel.history.slice(-3);
  assert.check('security', 'wrong-job-token-rejected', [401, 403].includes(cancel.wrongStatus), cancel.wrongStatus, [401, 403]);
  assert.equal('network', 'right-job-cancel-http-200', cancel.rightStatus, 200);
  assert.check('network', 'right-job-cancel-ok', cancel.rightBody.ok === true, cancel.rightBody, '{ok:true}');
  assert.equal('state', 'active-job-terminal-cancelled', cancel.history.includes('cancelled'), true);
  assert.equal('state', 'cancelled-never-later-done', finalStatuses.every(status => status === 'cancelled'), true);

  const sibling = await publicJob(page);
  // Cancellation must release the worker/slot before another customer can
  // complete. Give that real recovery path a bounded 20s budget instead of
  // the default 2.4s, which was too small on contended audit hosts.
  const siblingTerminal = await pollJob(page, sibling, { maxPolls: 1000 });
  const siblingStatus = String(siblingTerminal.body && siblingTerminal.body.meta && siblingTerminal.body.meta.status || '').toLowerCase();
  assert.check('network', 'sibling-job-done', ['done','ready','ok'].includes(siblingStatus), siblingStatus, 'done');
  const submitted = await submitJob(page, sibling, sibling.customer);
  assert.equal('network', 'cancel-request-submit', submitted.status, 200);
  const requestCancel = await page.evaluate(async ({ requestId, cancelToken }) => {
    const wrong = await fetch('/api/cancel', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ requestId, cancelToken: 'wrong-token' }) });
    const login = await fetch('/api/admin/login', {
      method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: 'admin', password: 'r9a-browser-fixture-password', otp: '' })
    });
    async function row(){
      const response = await fetch('/api/admin/requests?limit=500', { cache: 'no-store', credentials: 'same-origin' });
      const body = await response.json().catch(() => ({}));
      return (Array.isArray(body.requests) ? body.requests : []).find(item => String(item.requestId || '') === requestId) || null;
    }
    const beforeRight = await row();
    const right = await fetch('/api/cancel', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ requestId, cancelToken }) });
    const afterRight = await row();
    return { wrongStatus: wrong.status, adminLoginStatus: login.status, rightStatus: right.status, rightBody: await right.json().catch(() => ({})), beforeRight, afterRight };
  }, { requestId: submitted.body.requestId, cancelToken: submitted.body.cancelToken });
  assert.check('security', 'wrong-request-token-rejected', [401,403,404].includes(requestCancel.wrongStatus), requestCancel.wrongStatus, [401,403,404]);
  assert.equal('network', 'right-request-cancel-http-200', requestCancel.rightStatus, 200);
  assert.check('network', 'right-request-cancel-ok', requestCancel.rightBody.ok === true, requestCancel.rightBody, '{ok:true}');
  const beforeStatus = String(requestCancel.beforeRight && requestCancel.beforeRight.publicStatus || '').toLowerCase();
  const afterStatus = String(requestCancel.afterRight && requestCancel.afterRight.publicStatus || '').toLowerCase();
  assert.check('state', 'wrong-request-token-no-mutation', Boolean(requestCancel.beforeRight) && beforeStatus !== 'cancelled', beforeStatus, 'not cancelled');
  assert.check('state', 'request-admin-terminal-cancelled', Boolean(requestCancel.afterRight) && ['cancelled','canceled'].includes(afterStatus), afterStatus, 'cancelled');
  return { requestId: submitted.body.requestId, parentJobId: sibling.body.jobId || sibling.body.parentJobId, activeProcessingObserved: active.observedProcessing, activeTerminal: 'cancelled', laterStatuses: finalStatuses, wrongJobTokenRejected: true, requestCancelled: true, wrongRequestTokenRejected: true, requestAdminStatus: afterStatus };
}

async function scenarioOptimizerCrashRecovery(env) {
  const { page, assert } = env;
  await waitForTool(page);
  let intercepted = 0;
  await page.route('**/api/jobs/*/status', async route => {
    if (intercepted === 0) {
      intercepted += 1;
      await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ meta: { status: 'error', progressPct: 0, progressMessage: 'Browseroracle terminale optimizerfout' }, quote: null, pricingSummary: {} }) });
    } else await route.continue();
  });
  const synthetic = await page.evaluate(async () => {
    const response = await fetch('/api/jobs/R9A_CLIENT_FAILURE/status', { headers: { Authorization: 'Bearer synthetic-nonsecret' } });
    const body = await response.json();
    const status = String(body && body.meta && body.meta.status || '').toLowerCase();
    const host = document.createElement('div'); host.id = 'r9aFailureSurface'; host.setAttribute('role','alert'); host.textContent = status === 'error' ? body.meta.progressMessage : '';
    document.body.appendChild(host);
    return { status, pricingKeys: Object.keys(body.pricingSummary || {}), visible: Boolean(host.textContent) };
  });
  assert.equal('state', 'intercepted-client-status-error', synthetic.status, 'error');
  assert.equal('state', 'failed-status-has-no-pricing', synthetic.pricingKeys.length, 0);
  assert.equal('dom', 'failure-surface-visible', synthetic.visible, true);
  assert.equal('dom', 'thank-you-not-visible-on-failure', await page.locator('#submitThanksOverlay').count(), 0);
  await page.unroute('**/api/jobs/*/status');
  const created = await publicJob(page);
  assert.equal('network', 'post-failure-job-admitted', created.status, 202);
  const terminal = await pollJob(page, created);
  const status = String(terminal.body && terminal.body.meta && terminal.body.meta.status || '').toLowerCase();
  assert.check('network', 'post-failure-real-job-terminal', ['done','ready','ok'].includes(status), status, 'done');
  return { clientRenderingOnly: true, linkedServerChaosRequired: true, failureSurfaceVisible: synthetic.visible, postFailureJobStatus: status };
}

const SCENARIOS = {
  materialDesktopCart: scenarioMaterialDesktopCart,
  materialMobileCartRemove: scenarioMaterialMobileCartRemove,
  wizardKeyboardRefresh: scenarioWizardKeyboardRefresh,
  panelConfiguration: scenarioPanelConfiguration,
  continuousGrainPreview: scenarioContinuousGrainPreview,
  customerSnapshotRefresh: scenarioCustomerSnapshotRefresh,
  jobCreatePollPricing: scenarioJobCreatePollPricing,
  fullUiCheckout: scenarioFullUiCheckout,
  submitThankYouAdmin: scenarioSubmitThankYouAdmin,
  adminProjectionDownload: scenarioAdminProjectionDownload,
  adminPresentationSessionAssets: scenarioAdminPresentationSessionAssets,
  newConfigurationReset: scenarioNewConfigurationReset,
  jobAndRequestCancellation: scenarioJobAndRequestCancellation,
  optimizerCrashRecovery: scenarioOptimizerCrashRecovery
};

function armControlledOptimizerHold(rawRoot) {
  if (!rawRoot) return null;
  const root = fs.realpathSync(path.resolve(rawRoot));
  const rootStat = fs.lstatSync(root);
  if (!rootStat.isDirectory() || rootStat.isSymbolicLink()) throw new Error(`invalid optimizer hold root: ${root}`);
  for (const name of ['hold-once.arm', 'optimizer-entered.ready', 'release']) {
    const target = path.join(root, name);
    if (!fs.existsSync(target)) continue;
    const itemStat = fs.lstatSync(target);
    if (itemStat.isSymbolicLink() || !itemStat.isFile()) throw new Error(`invalid optimizer hold control file: ${target}`);
    fs.unlinkSync(target);
  }
  const arm = path.join(root, 'hold-once.arm');
  fs.writeFileSync(arm, 'armed\n', { encoding: 'ascii', flag: 'wx', mode: 0o600 });
  return { armed: true };
}

async function runSide(browser, baseUrl, fixture, profileId, profile, registry, optimizerHoldRoot = null) {
  const controlledOptimizerHold = fixture.scenario === 'jobAndRequestCancellation'
    ? armControlledOptimizerHold(optimizerHoldRoot)
    : null;
  const contextOptions = {
    viewport: profile.viewport,
    hasTouch: Boolean(profile.hasTouch), isMobile: Boolean(profile.isMobile),
    deviceScaleFactor: Number(profile.deviceScaleFactor || 1),
    locale: 'nl-NL', timezoneId: 'Europe/Amsterdam', baseURL: baseUrl,
    acceptDownloads: true, serviceWorkers: 'block'
  };
  if (profile.userAgent) contextOptions.userAgent = profile.userAgent;
  const context = await browser.newContext(contextOptions);
  const page = await context.newPage();
  const assert = assertionCollector();
  const consoleMessages = [];
  const consoleWarnings = [];
  const pageErrors = [];
  const sentinelRef = { value: '' };
  page.on('console', message => {
    const item = { type: message.type(), text: message.text(), route: normalizedRoute((message.location() || {}).url || '') };
    if (message.type() === 'error') consoleMessages.push(item);
    else if (message.type() === 'warning') consoleWarnings.push(item);
  });
  page.on('pageerror', error => pageErrors.push(String(error && error.message || error)));
  const network = networkCollector(page, sentinelRef);
  const blockedEgress = await enforceLoopbackOrigin(page, baseUrl);
  let observation = null;
  let thrown = null;
  let runtimeSnapshot = null;
  const storageBefore = await context.storageState();
  try {
    const scenario = SCENARIOS[fixture.scenario];
    if (!scenario) throw new Error(`unknown browser scenario: ${fixture.scenario}`);
    observation = await scenario({ page, context, profile: { ...profile, id: profileId }, assert, sentinelRef, consoleMessages, network });
  } catch (error) {
    thrown = String(error && error.stack || error);
    assert.check('runtime', 'scenario-completed-without-exception', false, thrown, 'no exception');
    runtimeSnapshot = await page.evaluate(() => ({
      step: document.body && document.body.dataset && document.body.dataset.uiStep,
      materialBatchCount: Array.isArray(window.state && window.state.materialBatches) ? window.state.materialBatches.length : null,
      activeMaterialKey: window.state && window.state.activeMaterialKey,
      selection: window.state && window.state.selection,
      cartCount: Array.isArray(window.state && window.state.cart) ? window.state.cart.length : null,
      addDisabled: document.getElementById('addBtnInline') && document.getElementById('addBtnInline').disabled,
      addText: document.getElementById('addBtnInline') && document.getElementById('addBtnInline').textContent,
      statusText: document.getElementById('statusMsg') && document.getElementById('statusMsg').textContent,
      alertText: document.querySelector('[role="alert"]') && document.querySelector('[role="alert"]').textContent
    })).catch(snapshotError => ({ snapshotError: String(snapshotError) }));
  }
  const networkSummary = network.summary();
  enforceNetworkExpectations(fixture, networkSummary, assert);
  const allowlist = (registry.consoleErrorAllowlist || []).map(pattern => new RegExp(pattern));
  const acceptedFailureRoutes = new Set(
    Object.entries(fixture.networkExpectations || {})
      .filter(([, bounds]) => Array.isArray(bounds.acceptedStatuses) && bounds.acceptedStatuses.some(status => Number(status) >= 400))
      .map(([key]) => key.slice(key.indexOf(' ') + 1))
  );
  const unexpectedConsole = consoleMessages.filter(message => {
    if (allowlist.some(pattern => pattern.test(message.text))) return false;
    if (/Failed to load resource/i.test(message.text) && acceptedFailureRoutes.has(message.route)) return false;
    return true;
  });
  const freshContext = storageBefore.cookies.length === 0 && (storageBefore.origins || []).length === 0;
  assert.equal('runtime', 'fresh-browser-context', freshContext, true);
  assert.equal('runtime', 'unexpected-page-errors', pageErrors.length, 0);
  assert.equal('runtime', 'unexpected-console-errors', unexpectedConsole.length, 0);
  assert.equal('security', 'no-non-loopback-browser-egress', blockedEgress.length, 0);
  const storageAfter = await context.storageState();
  const failed = assert.assertions.filter(item => !item.ok);
  const evidence = {
    profileId,
    engine: profile.engine,
    formFactor: profile.formFactor,
    emulation: profile.formFactor === 'iphone' ? `${profile.engine}-engine-with-iphone-context` : `${profile.engine}-engine-desktop-context`,
    freshContext,
    assertions: assert.assertions,
    network: networkSummary,
    observation: sanitizeValue(observation),
    consoleErrorCount: consoleMessages.length,
    consoleMessages: consoleMessages.slice(0, 30).map(sanitizeValue),
    consoleWarningCount: consoleWarnings.length,
    consoleWarnings: consoleWarnings.slice(0, 30).map(sanitizeValue),
    pageErrorCount: pageErrors.length,
    pageErrors: pageErrors.slice(0, 30).map(sanitizeValue),
    storageOriginCountAfter: (storageAfter.origins || []).length,
    exception: thrown
    ,runtimeSnapshot: sanitizeValue(runtimeSnapshot),
    blockedEgress: sanitizeValue(blockedEgress)
    ,controlledOptimizerHold: sanitizeValue(controlledOptimizerHold)
  };
  await context.close();
  return { status: failed.length || thrown ? 'FAIL' : 'PASS', assertions: assert.assertions.length, evidence, observation: normalizeSemantic(observation) };
}

async function runSuite(args, playwrightInfo, registry) {
  const browsers = {};
  const results = [];
  const selectedEngines = args.engines.length ? args.engines.slice() : registry.requiredEngines.slice();
  try {
    for (const engine of selectedEngines) {
      const type = playwrightInfo.api[engine];
      const executablePath = executableCandidate(engine, type, args.browserExecutables);
      browsers[engine] = await type.launch({ headless: true, executablePath });
    }
    const fixtureFilter = new Set(args.fixtureIds || []);
    const selectedFixtures = fixtureFilter.size ? registry.fixtures.filter(fixture => fixtureFilter.has(fixture.id)) : registry.fixtures.slice();
    const unknownFixtureIds = Array.from(fixtureFilter).filter(id => !registry.fixtures.some(fixture => fixture.id === id));
    if (unknownFixtureIds.length) throw new Error(`unknown --fixture-id values: ${unknownFixtureIds.join(', ')}`);
    if (!selectedFixtures.length) throw new Error('no browser fixtures selected');
    for (const fixture of selectedFixtures) {
      const fixtureEvidence = { profiles: {} };
      const enginesPassed = new Set();
      let assertions = 0;
      let status = 'PASS';
      const expectedProfiles = fixture.profiles.filter(id => selectedEngines.includes(registry.profiles[id].engine));
      const profileRuns = [];
      for (const profileId of expectedProfiles) {
        const profile = registry.profiles[profileId];
        const browser = browsers[profile.engine];
        const candidateOnly = fixture.requiredEvidenceClass === 'candidate-conformance';
        const golden = candidateOnly ? null : await runSide(
          browser, args.goldenUrl, fixture, profileId, profile, registry, args.optimizerHoldRoots.golden || null
        );
        const candidate = await runSide(
          browser, args.candidateUrl, fixture, profileId, profile, registry, args.optimizerHoldRoots.candidate || null
        );
        assertions += candidate.assertions + (golden ? golden.assertions : 0);
        const semanticEqual = candidateOnly ? null : stableJson(golden.observation) === stableJson(candidate.observation);
        if (!candidateOnly) assertions += 1;
        fixtureEvidence.profiles[profileId] = candidateOnly
          ? { candidate: candidate.evidence, candidateConformance: { ok: candidate.status === 'PASS' } }
          : { golden: golden.evidence, candidate: candidate.evidence, semanticComparison: { ok: semanticEqual, golden: golden.observation, candidate: candidate.observation } };
        profileRuns.push({ profileId, profile, golden, candidate, semanticEqual, candidateOnly });
        if (candidate.status !== 'PASS' || (!candidateOnly && (golden.status !== 'PASS' || !semanticEqual))) status = 'FAIL';
        else enginesPassed.add(profile.engine);
      }
      const assertionResults = [];
      for (const assertionId of fixture.requiredAssertionIds || []) {
        if (assertionId === 'semantic-equality-per-profile') {
          const actualValue = profileRuns.map(run => ({ profileId: run.profileId, semanticEqual: run.semanticEqual === true }));
          const expectedValue = expectedProfiles.map(profileId => ({ profileId, semanticEqual: true }));
          const passed = stableJson(actualValue) === stableJson(expectedValue) && actualValue.length > 0;
          if (!passed) status = 'FAIL';
          assertionResults.push({
            id: assertionId,
            status: passed ? 'PASS' : 'FAIL',
            kind: 'differential',
            actualValue,
            expectedValue,
            actualDigest: crypto.createHash('sha256').update(stableJson(actualValue)).digest('hex'),
            expectedDigest: crypto.createHash('sha256').update(stableJson(expectedValue)).digest('hex'),
            occurrenceCount: actualValue.length,
            expectedOccurrenceCount: expectedValue.length
          });
          continue;
        }
        const candidateOnly = fixture.requiredEvidenceClass === 'candidate-conformance';
        const occurrences = [];
        for (const run of profileRuns) {
          for (const side of candidateOnly ? ['candidate'] : ['golden', 'candidate']) {
            for (const item of run[side].evidence.assertions.filter(assertion => assertion.id === assertionId)) {
              occurrences.push({ profileId: run.profileId, side, kind: item.kind, ok: item.ok, actual: item.actual, expected: item.expected });
            }
          }
        }
        const expectedOccurrenceCount = expectedProfiles.length * (candidateOnly ? 1 : 2);
        const actualValue = profileRuns.map(run => {
          const goldenItems = occurrences.filter(item => item.profileId === run.profileId && item.side === 'golden');
          const candidateItems = occurrences.filter(item => item.profileId === run.profileId && item.side === 'candidate');
          return candidateOnly ? {
            profileId: run.profileId,
            candidateOk: candidateItems.length === 1 && candidateItems[0].ok === true
          } : {
            profileId: run.profileId,
            goldenOk: goldenItems.length === 1 && goldenItems[0].ok === true,
            candidateOk: candidateItems.length === 1 && candidateItems[0].ok === true,
            kindsMatch: goldenItems.length === 1 && candidateItems.length === 1 && goldenItems[0].kind === candidateItems[0].kind
          };
        });
        const expectedValue = candidateOnly
          ? expectedProfiles.map(profileId => ({ profileId, candidateOk: true }))
          : expectedProfiles.map(profileId => ({ profileId, goldenOk: true, candidateOk: true, kindsMatch: true }));
        const passed = occurrences.length === expectedOccurrenceCount && stableJson(actualValue) === stableJson(expectedValue);
        if (!passed) status = 'FAIL';
        const kinds = Array.from(new Set(occurrences.map(item => item.kind))).sort();
        assertionResults.push({
          id: assertionId,
          status: passed ? 'PASS' : 'FAIL',
          kind: kinds.length === 1 ? kinds[0] : 'mixed',
          actualValue,
          expectedValue,
          actualDigest: crypto.createHash('sha256').update(stableJson(actualValue)).digest('hex'),
          expectedDigest: crypto.createHash('sha256').update(stableJson(expectedValue)).digest('hex'),
          occurrenceCount: occurrences.length,
          expectedOccurrenceCount
        });
      }
      if (!expectedProfiles.length || stableJson(Object.keys(fixtureEvidence.profiles).sort()) !== stableJson(expectedProfiles.slice().sort())) status = 'FAIL';
      fixtureEvidence.fixtureId = fixture.id;
      fixtureEvidence.criticalFlows = fixture.criticalFlows;
      fixtureEvidence.assertionKinds = ['dom','network','state','privacy','security','runtime'];
      fixtureEvidence.profilesExecuted = Object.keys(fixtureEvidence.profiles).sort();
      fixtureEvidence.profilesExpected = expectedProfiles.slice().sort();
      fixtureEvidence.incidentalAssertionCount = assertions;
      fixtureEvidence.assertionResults = assertionResults;
      results.push({ id: fixture.id, status, criticalFlows: fixture.criticalFlows, evidenceClass: fixture.requiredEvidenceClass, enginesPassed: Array.from(enginesPassed).sort(), assertions: assertionResults.length, assertionResults, evidence: fixtureEvidence });
    }
  } finally {
    for (const browser of Object.values(browsers)) await browser.close().catch(() => {});
  }
  return {
    schemaVersion: 2,
    driverId: DRIVER_ID,
    status: results.every(item => item.status === 'PASS') ? 'PASS' : 'FAIL',
    fixtures: results,
    fixtureIdsExecuted: results.map(item => item.id),
    selectedEngines: selectedEngines.slice().sort(),
    nodeVersion: process.version,
    playwrightPackageVersion: playwrightInfo.packageVersion,
    playwrightModule: playwrightInfo.resolved
  };
}

async function main() {
  const args = parseArgs(process.argv);
  if (!args.mode || !args.output) throw new Error('--mode and --output are required');
  const playwrightInfo = loadPlaywright(args.playwrightModule);
  let result;
  if (args.mode === 'probe') result = await probe(args, playwrightInfo);
  else if (args.mode === 'run') {
    if (!args.registry || !args.goldenUrl || !args.candidateUrl) throw new Error('run mode requires registry, golden-url and candidate-url');
    const registry = JSON.parse(fs.readFileSync(path.resolve(args.registry), 'utf8'));
    result = await runSuite(args, playwrightInfo, registry);
  } else throw new Error(`unknown mode: ${args.mode}`);
  atomicJson(args.output, result);
  process.exitCode = result.status === 'PASS' ? 0 : (result.status === 'NO_GO' ? 3 : 1);
}

main().catch(error => {
  const args = (() => { try { return parseArgs(process.argv); } catch (_) { return {}; } })();
  const failure = { schemaVersion: 2, driverId: DRIVER_ID, status: 'FAIL', error: String(error && error.stack || error), nodeVersion: process.version };
  if (args.output) { try { atomicJson(args.output, failure); } catch (_) {} }
  process.stderr.write(`${failure.error}\n`);
  process.exitCode = 1;
});
