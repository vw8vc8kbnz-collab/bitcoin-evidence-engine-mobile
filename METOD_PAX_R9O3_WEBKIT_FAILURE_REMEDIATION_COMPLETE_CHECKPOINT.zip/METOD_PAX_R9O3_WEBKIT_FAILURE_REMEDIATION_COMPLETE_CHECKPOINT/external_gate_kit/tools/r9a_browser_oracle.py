#!/usr/bin/env python3
from __future__ import annotations

"""Run the R9A differential browser oracle in real Chromium and WebKit.

The runner is intentionally fail-closed.  A browser executable is evidence only
after Playwright launches it and completes a DOM probe.  Missing WebKit or
Chromium produces ``NO_GO`` and exit 3; it can never be normalized into PASS.
Release sources are copied to private sandboxes before server startup because
R8Z rebuilds a derived DXF manifest during boot.  The immutable input trees are
fingerprinted before and after the run.
"""

import argparse
import contextlib
import ctypes
import hashlib
import json
import os
import re
import shutil
import signal
import socket
import stat
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable
from urllib.error import HTTPError, URLError
from urllib.request import ProxyHandler, build_opener


ORACLE_ID = "browser-webkit-chromium"
SCHEMA_VERSION = 2
EXIT_FAIL = 1
EXIT_NO_GO = 3
REQUIRED_ENGINES = ("webkit", "chromium")
REQUIRED_FLOWS = frozenset(
    {
        "material-catalog-and-cart",
        "wizard-step-routing",
        "panel-configuration",
        "continuous-grain",
        "customer-data-snapshot",
        "job-payload-create",
        "job-poll-and-authoritative-pricing",
        "final-submit-and-thank-you",
        "new-configuration-reset",
        "admin-request-projection-download",
        "admin-presentation-session-assets",
        "optimizer-crash-isolation-recovery",
        "job-and-request-cancellation",
    }
)
KNOWN_SCENARIOS = frozenset(
    {
        "materialDesktopCart",
        "materialMobileCartRemove",
        "wizardKeyboardRefresh",
        "panelConfiguration",
        "continuousGrainPreview",
        "customerSnapshotRefresh",
        "jobCreatePollPricing",
        "fullUiCheckout",
        "submitThankYouAdmin",
        "adminProjectionDownload",
        "adminPresentationSessionAssets",
        "newConfigurationReset",
        "jobAndRequestCancellation",
        "optimizerCrashRecovery",
    }
)
PUBLIC_ID = "decor_0123456789abcdefabcd"
SECOND_PUBLIC_ID = "decor_0123456789abcdefabce"
ADMIN_PASSWORD = "r9a-browser-fixture-password"


class OracleError(RuntimeError):
    """A deterministic oracle configuration or execution failure."""


def enable_child_subreaper() -> bool:
    """Adopt detached optimizer descendants so the oracle can reap them."""
    if sys.platform != "linux":
        return False
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.prctl(36, 1, 0, 0, 0) != 0:  # PR_SET_CHILD_SUBREAPER
        error_number = ctypes.get_errno()
        raise OracleError(f"cannot enable Linux child subreaper: errno={error_number}")
    return True


def process_exists(pid: int) -> bool:
    if pid <= 1:
        return False
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def owned_process_ids(roots: Iterable[Path], explicit: Iterable[int] = ()) -> set[int]:
    resolved_roots = tuple(root.resolve() for root in roots)
    found = {int(pid) for pid in explicit if process_exists(int(pid))}
    if sys.platform != "linux":
        return found
    records: dict[int, tuple[int, int, bool]] = {}
    for proc in Path("/proc").iterdir():
        if not proc.name.isdigit():
            continue
        host_pid = int(proc.name)
        local_pid = host_pid
        with contextlib.suppress(OSError, ValueError, IndexError):
            status_lines = (proc / "status").read_text(encoding="utf-8", errors="replace").splitlines()
            namespace_line = next(line for line in status_lines if line.startswith("NSpid:"))
            local_pid = int(namespace_line.split()[-1])
        if local_pid in {os.getpid(), os.getppid()}:
            continue
        parent_host_pid = 0
        with contextlib.suppress(OSError, ValueError, IndexError):
            # /proc/<pid>/stat field four is PPID; comm may contain spaces but
            # is terminated by the final ')' before the state and PPID.
            stat_line = (proc / "stat").read_text(encoding="utf-8", errors="replace")
            stat_tail = stat_line.rsplit(")", 1)[1].strip().split()
            parent_host_pid = int(stat_tail[1])
        owned = False
        with contextlib.suppress(OSError):
            cwd = (proc / "cwd").resolve(strict=True)
            owned = any(cwd == root or cwd.is_relative_to(root) for root in resolved_roots)
        if not owned:
            with contextlib.suppress(OSError):
                command = (proc / "cmdline").read_bytes().replace(b"\0", b" ").decode("utf-8", "replace")
                owned = any(str(root) in command for root in resolved_roots)
        if owned:
            found.add(local_pid)
        records[host_pid] = (local_pid, parent_host_pid, owned)
    # Preserve ownership through forks and setsid(): once the server/root
    # process is identified, every live descendant belongs to this fixture,
    # even if it has changed cwd and removed the sandbox path from argv.
    changed = True
    owned_hosts = {
        host_pid
        for host_pid, (local_pid, _parent, root_owned) in records.items()
        if root_owned or local_pid in found
    }
    while changed:
        changed = False
        for host_pid, (_local_pid, parent_host_pid, _root_owned) in records.items():
            if host_pid not in owned_hosts and parent_host_pid in owned_hosts:
                owned_hosts.add(host_pid)
                changed = True
    found.update(records[host_pid][0] for host_pid in owned_hosts)
    return found


def terminate_owned_processes(roots: Iterable[Path], explicit: Iterable[int] = ()) -> list[int]:
    roots = tuple(roots)
    tracked = owned_process_ids(roots, explicit)
    own_group = os.getpgrp()
    for sig, budget in ((signal.SIGTERM, 1.5), (signal.SIGKILL, 1.5)):
        current = owned_process_ids(roots, tracked)
        tracked.update(current)
        groups: set[int] = set()
        for pid in current:
            with contextlib.suppress(ProcessLookupError, PermissionError):
                group = os.getpgid(pid)
                if group > 1 and group != own_group:
                    groups.add(group)
        for group in groups:
            with contextlib.suppress(ProcessLookupError, PermissionError):
                os.killpg(group, sig)
        for pid in current:
            with contextlib.suppress(ProcessLookupError, PermissionError):
                os.kill(pid, sig)
        deadline = time.monotonic() + budget
        while time.monotonic() < deadline and owned_process_ids(roots, tracked):
            for pid in tuple(tracked):
                with contextlib.suppress(ChildProcessError):
                    os.waitpid(pid, os.WNOHANG)
            time.sleep(0.03)
        if not owned_process_ids(roots, tracked):
            break
    reap_deadline = time.monotonic() + 3.0
    while time.monotonic() < reap_deadline:
        for pid in tuple(tracked):
            with contextlib.suppress(ChildProcessError):
                os.waitpid(pid, os.WNOHANG)
        if not owned_process_ids(roots, tracked):
            return []
        time.sleep(0.03)
    return sorted(owned_process_ids(roots, tracked))


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def canonical_json_bytes(value: Any) -> bytes:
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    ).encode("utf-8")


def evidence_sha256(value: dict[str, Any]) -> str:
    return sha256_bytes(canonical_json_bytes(value))


def atomic_json(path: Path, value: dict[str, Any]) -> None:
    path = path.resolve()
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    temp_path = path.with_name(f".{path.name}.tmp.{os.getpid()}.{os.urandom(4).hex()}")
    descriptor = os.open(temp_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            json.dump(value, handle, indent=2, ensure_ascii=False, allow_nan=False)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_path, path)
        path.chmod(0o600)
    finally:
        with contextlib.suppress(FileNotFoundError):
            temp_path.unlink()


def read_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise OracleError(f"invalid JSON {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise OracleError(f"expected JSON object: {path}")
    return value


def resolved_file(path: Path, label: str) -> Path:
    try:
        resolved = path.expanduser().resolve(strict=True)
    except Exception as exc:
        raise OracleError(f"{label} does not exist: {path}") from exc
    if not resolved.is_file() or resolved.is_symlink():
        raise OracleError(f"{label} must be a regular non-symlink file: {resolved}")
    return resolved


def resolved_release(path: Path, label: str) -> Path:
    try:
        resolved = path.expanduser().resolve(strict=True)
    except Exception as exc:
        raise OracleError(f"{label} release does not exist: {path}") from exc
    if not resolved.is_dir() or resolved.is_symlink():
        raise OracleError(f"{label} release must be a non-symlink directory: {resolved}")
    for relative in ("SHA256SUMS.txt", "app/server_py.py", "app/toolA.html"):
        item = resolved / relative
        if not item.is_file() or item.is_symlink():
            raise OracleError(f"{label} release is missing non-symlink file {relative}: {resolved}")
    return resolved


def tree_sha256(root: Path) -> str:
    """Hash every source entry, including paths and executable mode bits."""
    digest = hashlib.sha256()
    for item in sorted(root.rglob("*"), key=lambda value: value.relative_to(root).as_posix()):
        relative = item.relative_to(root).as_posix()
        info = item.lstat()
        if stat.S_ISLNK(info.st_mode):
            raise OracleError(f"release contains forbidden symlink: {root / relative}")
        if stat.S_ISDIR(info.st_mode):
            digest.update(f"D\0{relative}\0{stat.S_IMODE(info.st_mode):o}\n".encode())
        elif stat.S_ISREG(info.st_mode):
            digest.update(f"F\0{relative}\0{stat.S_IMODE(info.st_mode):o}\0{info.st_size}\0".encode())
            digest.update(sha256_file(item).encode("ascii"))
            digest.update(b"\n")
        else:
            raise OracleError(f"release contains unsupported filesystem entry: {root / relative}")
    return digest.hexdigest()


def git_head(workspace: Path) -> str:
    process = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=workspace,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=10,
        check=False,
    )
    value = process.stdout.strip()
    if process.returncode != 0 or not re.fullmatch(r"[a-f0-9]{40}", value):
        raise OracleError(f"cannot bind browser evidence to git HEAD: {process.stderr.strip()}")
    return value


def validate_registry(registry: dict[str, Any]) -> None:
    if registry.get("schemaVersion") != 1:
        raise OracleError("browser registry schemaVersion must be 1")
    if registry.get("oracleId") != ORACLE_ID:
        raise OracleError(f"browser registry oracleId must be {ORACLE_ID}")
    if registry.get("requiredEngines") != list(REQUIRED_ENGINES):
        raise OracleError(f"browser registry requiredEngines must be {list(REQUIRED_ENGINES)} in reviewed order")
    policy = registry.get("executionPolicy")
    if not isinstance(policy, dict) or policy.get("skipsAllowed") is not False or policy.get("xfailAllowed") is not False:
        raise OracleError("browser registry must forbid skips and xfails")
    if policy.get("screenshotsAreEvidence") is not False:
        raise OracleError("browser registry must explicitly reject screenshots as passing evidence")
    dependencies = registry.get("oracleDependencies")
    if not isinstance(dependencies, list) or not dependencies or any(
        not isinstance(item, str) or not item.strip() for item in dependencies
    ) or len(dependencies) != len(set(dependencies)):
        raise OracleError("browser registry requires unique string oracleDependencies")
    profiles = registry.get("profiles")
    if not isinstance(profiles, dict) or not profiles:
        raise OracleError("browser registry profiles are missing")
    form_factors: set[str] = set()
    profile_engines: set[str] = set()
    for profile_id, profile in profiles.items():
        if not re.fullmatch(r"[a-z0-9-]+", str(profile_id)) or not isinstance(profile, dict):
            raise OracleError(f"invalid browser profile: {profile_id!r}")
        engine = profile.get("engine")
        form_factor = profile.get("formFactor")
        if engine not in REQUIRED_ENGINES:
            raise OracleError(f"profile {profile_id} has unsupported engine {engine!r}")
        if form_factor not in {"desktop", "iphone"}:
            raise OracleError(f"profile {profile_id} has unsupported formFactor {form_factor!r}")
        viewport = profile.get("viewport")
        if not isinstance(viewport, dict) or not all(isinstance(viewport.get(key), int) and viewport[key] > 0 for key in ("width", "height")):
            raise OracleError(f"profile {profile_id} must have a positive integer viewport")
        profile_engines.add(engine)
        form_factors.add(form_factor)
    if profile_engines != set(REQUIRED_ENGINES) or form_factors != {"desktop", "iphone"}:
        raise OracleError("registry must cover real Chromium/WebKit and desktop/iPhone contexts")

    fixtures = registry.get("fixtures")
    if not isinstance(fixtures, list) or len(fixtures) < 12:
        raise OracleError("browser registry must contain at least 12 fixtures")
    ids: set[str] = set()
    covered_flows: set[str] = set()
    full_ui_engines: set[str] = set()
    for index, fixture in enumerate(fixtures):
        if not isinstance(fixture, dict):
            raise OracleError(f"fixture #{index + 1} must be an object")
        fixture_id = fixture.get("id")
        if not isinstance(fixture_id, str) or not re.fullmatch(r"[a-z0-9-]+", fixture_id):
            raise OracleError(f"fixture #{index + 1} has invalid id")
        if fixture_id in ids:
            raise OracleError(f"duplicate browser fixture id: {fixture_id}")
        ids.add(fixture_id)
        if fixture.get("scenario") not in KNOWN_SCENARIOS:
            raise OracleError(f"fixture {fixture_id} has unknown scenario {fixture.get('scenario')!r}")
        evidence_class = fixture.get("requiredEvidenceClass")
        if evidence_class not in {"differential", "characterization", "candidate-conformance"}:
            raise OracleError(f"fixture {fixture_id} requires an explicit evidence class")
        flows = fixture.get("criticalFlows")
        if not isinstance(flows, list) or not flows or any(flow not in REQUIRED_FLOWS for flow in flows):
            raise OracleError(f"fixture {fixture_id} has invalid criticalFlows")
        covered_flows.update(flows)
        profile_ids = fixture.get("profiles")
        if not isinstance(profile_ids, list) or not profile_ids or len(profile_ids) != len(set(profile_ids)):
            raise OracleError(f"fixture {fixture_id} requires unique profiles")
        if any(profile_id not in profiles for profile_id in profile_ids):
            raise OracleError(f"fixture {fixture_id} references an unknown profile")
        engines = {profiles[profile_id]["engine"] for profile_id in profile_ids}
        if engines != set(REQUIRED_ENGINES):
            raise OracleError(f"fixture {fixture_id} must execute in both WebKit and Chromium")
        for key in ("actions", "requiredAssertions"):
            value = fixture.get(key)
            if not isinstance(value, list) or not value or any(not isinstance(item, str) or not item.strip() for item in value):
                raise OracleError(f"fixture {fixture_id} requires non-empty {key}")
        required_assertion_ids = fixture.get("requiredAssertionIds")
        if (
            not isinstance(required_assertion_ids, list)
            or not required_assertion_ids
            or len(required_assertion_ids) != len(set(required_assertion_ids))
            or any(not isinstance(item, str) or not re.fullmatch(r"[a-z0-9:-]+", item) for item in required_assertion_ids)
        ):
            raise OracleError(f"fixture {fixture_id} requires unique machine-bound requiredAssertionIds")
        if not isinstance(fixture.get("networkExpectations"), dict):
            raise OracleError(f"fixture {fixture_id} requires networkExpectations")
        if fixture.get("scenario") == "fullUiCheckout":
            full_ui_engines.update(engines)
        if fixture.get("scenario") == "optimizerCrashRecovery":
            if evidence_class != "characterization" or not isinstance(fixture.get("linkedServerOracle"), dict):
                raise OracleError("client-only crash surface must be characterization linked to the real server-chaos oracle")
        if evidence_class == "candidate-conformance" and "semantic-equality-per-profile" in required_assertion_ids:
            raise OracleError(f"candidate-only fixture {fixture_id} cannot claim R8Z semantic equality")
    missing = REQUIRED_FLOWS - covered_flows
    if missing:
        raise OracleError(f"browser registry misses critical flows: {sorted(missing)}")
    if full_ui_engines != set(REQUIRED_ENGINES):
        raise OracleError("at least one full real click checkout must execute in both Chromium and WebKit")


def reserve_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def minimal_jpeg() -> bytes:
    return b"\xff\xd8\xff\xc0\x00\x11\x08\x00\x02\x00\x02\x03\x01\x11\x00\x02\x11\x00\x03\x11\x00\xff\xd9"


def catalog_record(public_id: str, article: str, name: str, price: float, family: str) -> dict[str, Any]:
    return {
        "articleNo": article,
        "materialCode": article,
        "publicMaterialId": public_id,
        "productName": name,
        "publicName": name,
        "brand": "R9A Audit",
        "sourceKind": "CATALOG_IMPORT",
        "active": True,
        "published": True,
        "archived": False,
        "catalogMissing": False,
        "catalogExcluded": False,
        "thicknessMm": 18,
        "sheetWid": 2070,
        "sheetLen": 2800,
        "sellPriceInclVatPerSheet": price,
        "priceSource": "CSV_SALE_PRICE_INCL_VAT",
        "primaryVisualFamily": family,
        "visualFamily": family,
        "visualTags": [family],
        "substrateType": "SPAANPLAAT",
        "substrateLabel": "Spaanplaat",
        "colorGroup": "Bruin",
        "searchTags": ["r9a", "audit", family.lower()],
        "hasGrain": True,
        "grainDefaultOn": True,
    }


def seed_state(state_root: Path, credentials: Path) -> None:
    state_root.mkdir(parents=True, exist_ok=False, mode=0o700)
    library = {
        "source": "CSV_CATALOG_ONLY",
        "pricingModel": "catalog_sell_price_incl_vat_v2",
        "decorLibrarySchemaVersion": 4,
        "records": [
            catalog_record(PUBLIC_ID, "R9A-BROWSER-001", "R9A Audit Eiken", 140.24, "Hout"),
            catalog_record(SECOND_PUBLIC_ID, "R9A-BROWSER-002", "R9A Audit Noten", 151.75, "Hout"),
        ],
    }
    (state_root / "material_library.json").write_text(json.dumps(library), encoding="utf-8")
    system = state_root / "system"
    system.mkdir(mode=0o700)
    (system / "last_auto_backup.json").write_text(
        json.dumps({"ts": "2099-01-01T00:00:00", "file": "r9a-browser-fixture.zip"}),
        encoding="utf-8",
    )
    image = minimal_jpeg()
    for public_id in (PUBLIC_ID, SECOND_PUBLIC_ID):
        media = state_root / "decor_media" / public_id
        media.mkdir(parents=True, mode=0o700)
        (media / "catalog.img").write_bytes(image)
        (media / "catalog.meta.json").write_text(
            json.dumps(
                {
                    "mime": "image/jpeg",
                    "sha256": sha256_bytes(image),
                    "bytes": len(image),
                    "width": 2,
                    "height": 2,
                    "variantGenerator": "raw-fallback",
                    "variants": {},
                }
            ),
            encoding="utf-8",
        )
    salt = "f48c01166f4f6e8f0a98225507f66ce4"
    digest = hashlib.pbkdf2_hmac("sha256", ADMIN_PASSWORD.encode(), salt.encode(), 260_000).hex()
    credentials.write_text(
        json.dumps(
            {
                "schemaVersion": 2,
                "users": [
                    {
                        "username": "admin",
                        "password_hash": f"pbkdf2_sha256$260000${salt}${digest}",
                        "totp_secret": "",
                        "roles": ["admin"],
                        "active": True,
                    }
                ],
            }
        ),
        encoding="utf-8",
    )
    credentials.chmod(0o600)


@dataclass
class ServerProcess:
    label: str
    source_root: Path
    execution_root: Path
    state_root: Path
    port: int
    log_path: Path
    process: subprocess.Popen[bytes]
    residual_pids: list[int] | None = None
    optimizer_hold_root: Path | None = None

    @property
    def base_url(self) -> str:
        return f"http://127.0.0.1:{self.port}"

    def stop(self) -> None:
        self.residual_pids = terminate_owned_processes(
            (self.execution_root, self.state_root),
            (self.process.pid,),
        )
        with contextlib.suppress(subprocess.TimeoutExpired, ChildProcessError):
            self.process.wait(timeout=1)
        if self.process.returncode is None and not process_exists(self.process.pid):
            self.process.returncode = -int(signal.SIGKILL)


def wait_server(server: ServerProcess, timeout: float = 40.0) -> None:
    opener = build_opener(ProxyHandler({}))
    deadline = time.monotonic() + timeout
    last_error = "not attempted"
    while time.monotonic() < deadline:
        if server.process.poll() is not None:
            break
        try:
            with opener.open(f"{server.base_url}/health/live", timeout=2) as response:
                body = json.loads(response.read().decode("utf-8"))
                if response.status == 200 and body.get("ok") is True:
                    return
                last_error = f"HTTP {response.status}: {body!r}"
        except HTTPError as exc:
            last_error = f"HTTP {exc.code}"
            exc.close()
        except (URLError, TimeoutError, OSError, ValueError) as exc:
            last_error = str(exc)
        time.sleep(0.1)
    tail = ""
    with contextlib.suppress(Exception):
        tail = server.log_path.read_text(encoding="utf-8", errors="replace")[-4000:]
    raise OracleError(
        f"{server.label} server did not become live ({last_error}); return={server.process.poll()}; log tail={tail}"
    )


def install_private_optimizer_hold(execution_root: Path, hold_root: Path) -> None:
    """Instrument only the disposable copy with a deterministic cancel barrier.

    The reviewed release remains byte-for-byte untouched. The barrier arms once,
    after Tool B starts, and is terminated by the real cancellation path. This
    avoids timing-based claims on fast hardware while still exercising the real
    optimizer process, cancel endpoint, and process cleanup.
    """
    optimizer = execution_root / "app" / "dxf_nesting_optimizer.py"
    source = optimizer.read_text(encoding="utf-8")
    future_line = "from __future__ import annotations\n"
    if future_line not in source or "R9A_PRIVATE_CANCEL_BARRIER" in source:
        raise OracleError("cannot safely instrument private optimizer cancel barrier")
    hook = """
# R9A_PRIVATE_CANCEL_BARRIER: disposable browser-oracle sandbox only.
import json as _r9a_json, os as _r9a_os, pathlib as _r9a_pathlib, sys as _r9a_sys, time as _r9a_time
_r9a_hold_root = _r9a_os.environ.get('R9A_BROWSER_OPTIMIZER_HOLD_ROOT', '')
if _r9a_hold_root:
    _r9a_hold = _r9a_pathlib.Path(_r9a_hold_root)
    _r9a_arm = _r9a_hold / 'hold-once.arm'
    if _r9a_arm.exists():
        try:
            _r9a_arm.unlink()
        except FileNotFoundError:
            pass
        else:
            _r9a_hold.mkdir(parents=True, exist_ok=True)
            (_r9a_hold / 'optimizer-entered.ready').write_text(str(_r9a_os.getpid()), encoding='ascii')
            try:
                _r9a_output = _r9a_pathlib.Path(_r9a_sys.argv[_r9a_sys.argv.index('--output') + 1])
                _r9a_output.mkdir(parents=True, exist_ok=True)
                (_r9a_output / 'progress.json').write_text(_r9a_json.dumps({
                    'percent': 1,
                    'message': 'R9A optimizer active hold',
                    'phase': 'r9a_active_hold',
                }), encoding='utf-8')
            except Exception:
                pass
            _r9a_deadline = _r9a_time.monotonic() + 120.0
            while not (_r9a_hold / 'release').exists() and _r9a_time.monotonic() < _r9a_deadline:
                _r9a_time.sleep(0.02)
"""
    original_mode = stat.S_IMODE(optimizer.stat().st_mode)
    try:
        # The immutable R8Z archive deliberately ships executable sources as
        # read-only (0555). Only the disposable oracle copy may be made
        # owner-writable for deterministic instrumentation.
        optimizer.chmod(original_mode | stat.S_IWUSR)
        optimizer.write_text(source.replace(future_line, future_line + hook, 1), encoding="utf-8")
    finally:
        optimizer.chmod(original_mode)
    hold_root.mkdir(mode=0o700)
    (hold_root / "hold-once.arm").write_text("armed\n", encoding="ascii")


def start_server(label: str, release: Path, sandbox_root: Path, *, controlled_optimizer_hold: bool = False) -> ServerProcess:
    execution_root = sandbox_root / f"{label}-release"
    state_root = sandbox_root / f"{label}-state"
    credentials = sandbox_root / f"{label}-credentials.json"
    temp_root = sandbox_root / f"{label}-tmp"
    shutil.copytree(release, execution_root, symlinks=False)
    seed_state(state_root, credentials)
    hold_root = state_root / ".r9a-browser-optimizer-hold" if controlled_optimizer_hold else None
    if hold_root is not None:
        install_private_optimizer_hold(execution_root, hold_root)
    temp_root.mkdir(mode=0o700)
    port = reserve_port()
    log_path = sandbox_root / f"{label}-server.log"
    environment = {
        key: os.environ[key]
        for key in ("PATH", "LANG", "LC_ALL", "TZ", "SSL_CERT_FILE", "SSL_CERT_DIR")
        if os.environ.get(key)
    }
    environment.update(
        {
            "PYTHONDONTWRITEBYTECODE": "1",
            "PYTHONUNBUFFERED": "1",
            "METOD_STATE_ROOT": str(state_root),
            "METOD_HOST": "127.0.0.1",
            "METOD_PORT": str(port),
            "APP_ENV": "staging",
            "PRODUCTION_HARDENING": "0",
            "ADMIN_CREDENTIALS_FILE": str(credentials),
            "HTTP_MAX_CONCURRENT": "64",
            "TMPDIR": str(temp_root),
            "HOME": str(temp_root),
            "XDG_CACHE_HOME": str(temp_root / "xdg-cache"),
            "NO_PROXY": "127.0.0.1,localhost",
            "no_proxy": "127.0.0.1,localhost",
            "METOD_PUBLIC_BASE_URL": f"http://127.0.0.1:{port}",
            "ALLOWED_ORIGINS": f"http://127.0.0.1:{port}",
            "ALLOWED_ADMIN_ORIGINS": f"http://127.0.0.1:{port}",
            "NOTIFY_CONFIG_FILE": str(temp_root / "notifications-disabled.json"),
            "MIN_FREE_STATE_BYTES": str(64 * 1024 * 1024),
            "MIN_FREE_STATE_INODES": "100",
            "AUTO_BACKUP_INTERVAL_SECONDS": "86400",
        }
    )
    if hold_root is not None:
        environment["R9A_BROWSER_OPTIMIZER_HOLD_ROOT"] = str(hold_root)
    log_handle = log_path.open("wb")
    try:
        process = subprocess.Popen(
            [sys.executable, "-B", str(execution_root / "app" / "server_py.py")],
            cwd=execution_root / "app",
            env=environment,
            stdin=subprocess.DEVNULL,
            stdout=log_handle,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
    finally:
        log_handle.close()
    server = ServerProcess(label, release, execution_root, state_root, port, log_path, process, optimizer_hold_root=hold_root)
    try:
        wait_server(server)
    except Exception:
        server.stop()
        raise
    return server


def playwright_command(
    node: str,
    driver: Path,
    mode: str,
    output: Path,
    engines: Iterable[str],
    executable_paths: dict[str, str],
    playwright_module: str | None,
    registry: Path | None = None,
    golden_url: str | None = None,
    candidate_url: str | None = None,
    fixture_ids: Iterable[str] = (),
    optimizer_hold_roots: dict[str, str] | None = None,
) -> list[str]:
    command = [node, str(driver), "--mode", mode, "--output", str(output)]
    if registry:
        command += ["--registry", str(registry)]
    if golden_url:
        command += ["--golden-url", golden_url]
    if candidate_url:
        command += ["--candidate-url", candidate_url]
    if playwright_module:
        command += ["--playwright-module", playwright_module]
    for engine in engines:
        command += ["--engine", engine]
        if executable_paths.get(engine):
            command += ["--browser-executable", f"{engine}={executable_paths[engine]}"]
    for fixture_id in fixture_ids:
        command += ["--fixture-id", fixture_id]
    for side, hold_root in sorted((optimizer_hold_roots or {}).items()):
        if hold_root:
            command += ["--optimizer-hold-root", f"{side}={hold_root}"]
    return command


def run_node(command: list[str], cwd: Path, timeout: float) -> tuple[int, str, str]:
    # `cwd` is retained as an API-level provenance input, but execution uses a
    # private runtime cwd. All command/config paths passed by this oracle are
    # absolute. This gives detached browser descendants a unique ownership
    # root without scanning or terminating unrelated workspace processes.
    if not cwd.is_absolute():
        raise OracleError(f"Node provenance cwd must be absolute: {cwd}")
    with tempfile.TemporaryDirectory(prefix="r9a-browser-node-") as runtime_name:
        runtime_root = Path(runtime_name)
        (runtime_root / "cache").mkdir(mode=0o700)
        environment = {
            key: os.environ[key]
            for key in ("PATH", "LANG", "LC_ALL", "TZ")
            if os.environ.get(key)
        }
        environment.update(
            {
                "HOME": runtime_name,
                "TMPDIR": runtime_name,
                "XDG_CACHE_HOME": str(runtime_root / "cache"),
                "NO_PROXY": "127.0.0.1,localhost,::1",
                "no_proxy": "127.0.0.1,localhost,::1",
                "PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD": "1",
            }
        )
        managed_browsers = Path.home() / ".cache" / "ms-playwright"
        if managed_browsers.is_dir():
            environment["PLAYWRIGHT_BROWSERS_PATH"] = str(managed_browsers)
        process = subprocess.Popen(
            command,
            cwd=runtime_root,
            env=environment,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            stdin=subprocess.DEVNULL,
            start_new_session=True,
        )
        try:
            stdout, stderr = process.communicate(timeout=timeout)
        except subprocess.TimeoutExpired:
            residual = terminate_owned_processes((runtime_root,), (process.pid,))
            if process.returncode is None and not process_exists(process.pid):
                process.returncode = -int(signal.SIGKILL)
            if residual:
                raise OracleError(f"Node/browser timeout left residual owned processes: {residual}")
            raise
        finally:
            residual = terminate_owned_processes((runtime_root,), (process.pid,))
            if residual:
                raise OracleError(f"Node/browser execution left residual owned processes: {residual}")
            with contextlib.suppress(subprocess.TimeoutExpired, ChildProcessError):
                process.wait(timeout=2)
            if process.returncode is None and not process_exists(process.pid):
                process.returncode = -int(signal.SIGKILL)
            for stream in (process.stdout, process.stderr):
                if stream is not None:
                    stream.close()
        return int(process.returncode), stdout, stderr


def report_fixture(
    fixture: dict[str, Any],
    status: str,
    engines_passed: list[str],
    assertions: int,
    evidence: dict[str, Any],
    assertion_results: list[dict[str, Any]] | None = None,
    profiles_passed: list[str] | None = None,
) -> dict[str, Any]:
    ledger = list(assertion_results or [])
    bound_evidence = dict(evidence)
    bound_evidence["assertionResults"] = ledger
    return {
        "id": fixture["id"],
        "status": status,
        "criticalFlows": list(fixture["criticalFlows"]),
        "evidenceClass": fixture["requiredEvidenceClass"],
        "enginesPassed": sorted(set(engines_passed)),
        "assertions": int(assertions),
        "profilesPassed": sorted(set(profiles_passed or [])),
        "assertionResults": ledger,
        "evidence": bound_evidence,
        "evidenceSha256": evidence_sha256(bound_evidence),
    }


def validate_driver_fixture_result(
    suite: dict[str, Any],
    suite_return: int,
    fixture: dict[str, Any],
    registry: dict[str, Any],
    selected_engines: list[str],
) -> dict[str, Any]:
    if int(suite.get("schemaVersion") or 0) < 2 or suite.get("driverId") != "r9a-real-playwright-driver-v1":
        raise OracleError(f"driver emitted an unsupported schema for fixture {fixture['id']}")
    status = str(suite.get("status") or "")
    expected_return = 0 if status == "PASS" else 1
    if status not in {"PASS", "FAIL"} or suite_return != expected_return:
        raise OracleError(
            f"driver status/exit mismatch for {fixture['id']}: status={status!r}, exit={suite_return}"
        )
    if sorted(suite.get("selectedEngines") or []) != sorted(selected_engines):
        raise OracleError(f"driver engine selection drift for fixture {fixture['id']}")
    if suite.get("fixtureIdsExecuted") != [fixture["id"]]:
        raise OracleError(f"driver fixture execution list drift for {fixture['id']}")
    items = suite.get("fixtures")
    if not isinstance(items, list) or len(items) != 1 or not isinstance(items[0], dict) or items[0].get("id") != fixture["id"]:
        raise OracleError(f"driver did not emit exactly one result for fixture {fixture['id']}")
    item = items[0]
    if item.get("evidenceClass") != fixture.get("requiredEvidenceClass"):
        raise OracleError(f"driver evidence class drift for fixture {fixture['id']}")
    evidence = item.get("evidence")
    if not isinstance(evidence, dict) or not evidence:
        raise OracleError(f"driver fixture {fixture['id']} omitted evidence")
    expected_profiles = sorted(
        profile_id
        for profile_id in fixture["profiles"]
        if registry["profiles"][profile_id]["engine"] in selected_engines
    )
    if sorted(evidence.get("profilesExecuted") or []) != expected_profiles:
        raise OracleError(f"driver profile evidence drift for fixture {fixture['id']}")
    assertion_results = item.get("assertionResults")
    if not isinstance(assertion_results, list):
        raise OracleError(f"driver fixture {fixture['id']} omitted assertionResults")
    actual_ids = [str(result.get("id") or "") for result in assertion_results if isinstance(result, dict)]
    if len(actual_ids) != len(assertion_results) or actual_ids != fixture["requiredAssertionIds"]:
        raise OracleError(f"driver required assertion binding drift for fixture {fixture['id']}")
    if item.get("status") == "PASS" and any(result.get("status") != "PASS" for result in assertion_results):
        raise OracleError(f"driver fixture {fixture['id']} passed with a failed required assertion")
    if int(item.get("assertions") or 0) != len(assertion_results) or not assertion_results:
        raise OracleError(f"driver fixture {fixture['id']} assertion count is not ledger-bound")
    for result in assertion_results:
        for key in ("actualValue", "expectedValue"):
            if key not in result:
                raise OracleError(f"driver fixture {fixture['id']} assertion {result.get('id')} omitted {key}")
        actual_digest = evidence_sha256(result["actualValue"])
        expected_digest = evidence_sha256(result["expectedValue"])
        if result.get("actualDigest") != actual_digest or result.get("expectedDigest") != expected_digest:
            raise OracleError(f"driver fixture {fixture['id']} assertion {result.get('id')} has an invalid value digest")
        if result.get("status") == "PASS" and actual_digest != expected_digest:
            raise OracleError(f"driver fixture {fixture['id']} assertion {result.get('id')} passed with unequal values")
    expected_engines = sorted(
        {
            registry["profiles"][profile_id]["engine"]
            for profile_id in expected_profiles
        }
    )
    if item.get("status") == "PASS" and sorted(item.get("enginesPassed") or []) != expected_engines:
        raise OracleError(f"driver fixture {fixture['id']} passed without every selected engine")
    return item


def blocker(blocker_id: str, kind: str, message: str, remediation: list[str], details: dict[str, Any] | None = None) -> dict[str, Any]:
    value: dict[str, Any] = {
        "id": blocker_id,
        "kind": kind,
        "message": message,
        "remediation": remediation,
    }
    if details:
        value["details"] = details
    return value


def release_binding(path: Path, source_tree_sha: str) -> dict[str, Any]:
    manifest = path / "SHA256SUMS.txt"
    return {
        "path": str(path),
        "manifestSha256": sha256_file(manifest),
        "sourceTreeSha256": source_tree_sha,
    }


def dependency_hashes(workspace: Path, registry: dict[str, Any]) -> dict[str, str]:
    values: dict[str, str] = {}
    for relative in registry.get("oracleDependencies") or []:
        path = resolved_file(workspace / str(relative), f"oracle dependency {relative}")
        if not path.is_relative_to(workspace):
            raise OracleError(f"oracle dependency escapes workspace: {relative}")
        values[path.relative_to(workspace).as_posix()] = sha256_file(path)
    return values


def build_base_report(
    started: str,
    workspace: Path,
    head_commit: str,
    registry_path: Path,
    runner_path: Path,
    driver_path: Path,
    normalization_path: Path,
    golden_binding: dict[str, Any],
    candidate_binding: dict[str, Any],
    registry: dict[str, Any],
) -> dict[str, Any]:
    dependencies = dependency_hashes(workspace, registry)
    hashes = {
        "registrySha256": sha256_file(registry_path),
        "runnerSha256": sha256_file(runner_path),
        "driverSha256": sha256_file(driver_path),
        "normalizationSha256": sha256_file(normalization_path),
        "goldenManifestSha256": golden_binding["manifestSha256"],
        "candidateManifestSha256": candidate_binding["manifestSha256"],
        "criticalFlowsSha256": sha256_file(resolved_file(workspace / "contracts" / "R9A_CRITICAL_FLOWS.json", "critical-flow contract")),
        "executableOraclesSha256": sha256_file(resolved_file(workspace / "contracts" / "R9A_EXECUTABLE_ORACLES.json", "executable-oracle contract")),
    }
    return {
        "schemaVersion": SCHEMA_VERSION,
        "oracleId": ORACLE_ID,
        "status": "FAIL",
        "startedAtUtc": started,
        "finishedAtUtc": None,
        "goldenRelease": golden_binding,
        "candidateRelease": candidate_binding,
        "registry": {"path": str(registry_path), "sha256": hashes["registrySha256"]},
        "runner": {"path": str(runner_path), "sha256": hashes["runnerSha256"]},
        "driver": {"path": str(driver_path), "sha256": hashes["driverSha256"]},
        "normalization": {"path": str(normalization_path), "sha256": hashes["normalizationSha256"]},
        "oracleDependencies": dependencies,
        "bindings": {
            "headCommit": head_commit,
            "workspace": str(workspace),
            "goldenRelease": str(Path(golden_binding["path"]).resolve()),
            "candidateRelease": str(Path(candidate_binding["path"]).resolve()),
            "runner": str(runner_path),
            "registry": str(registry_path),
            "driver": str(driver_path),
            "normalization": str(normalization_path),
            "goldenManifestSha256": hashes["goldenManifestSha256"],
            "candidateManifestSha256": hashes["candidateManifestSha256"],
            "runnerSha256": hashes["runnerSha256"],
            "registrySha256": hashes["registrySha256"],
            "driverSha256": hashes["driverSha256"],
            "normalizationSha256": hashes["normalizationSha256"],
            "criticalFlowsSha256": hashes["criticalFlowsSha256"],
            "executableOraclesSha256": hashes["executableOraclesSha256"],
            "dependencySha256": dependencies,
        },
        "fixtureCount": len(registry["fixtures"]),
        "passedFixtureCount": 0,
        "skippedFixtureCount": 0,
        "failedFixtureCount": 0,
        "blockedFixtureCount": 0,
        "flowIdsPassed": [],
        "fixtureIdsPassed": [],
        "enginesPassed": [],
        "assertionsTotal": 0,
        "fixtures": [],
        "blockers": [],
        "scope": registry.get("scope", {}),
        "productionEvidenceLimitations": list((registry.get("scope") or {}).get("doesNotProve") or []),
    }


def parse_arguments(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--registry", required=True, type=Path)
    parser.add_argument("--golden-release", required=True, type=Path)
    parser.add_argument("--candidate", required=True, type=Path)
    parser.add_argument("--engines", nargs="+", required=True, choices=REQUIRED_ENGINES)
    parser.add_argument("--json-output", required=True, type=Path)
    parser.add_argument("--node", default=shutil.which("node") or "node")
    parser.add_argument("--playwright-module")
    parser.add_argument("--chromium-executable", type=Path)
    parser.add_argument("--webkit-executable", type=Path)
    parser.add_argument("--probe-timeout", type=float, default=45.0)
    parser.add_argument("--suite-timeout", type=float, default=1800.0)
    parser.add_argument("--no-partial-engine-evidence", action="store_true")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_arguments(argv)
    subreaper_enabled = enable_child_subreaper()
    started = utc_now()
    workspace = Path(__file__).resolve().parents[1]
    runner_path = resolved_file(Path(__file__), "browser runner")
    driver_path = resolved_file(workspace / "tools" / "r9a_browser_driver.js", "browser driver")
    normalization_path = resolved_file(workspace / "contracts" / "R9A_NORMALIZATION.json", "normalization contract")
    registry_path = resolved_file(args.registry, "browser registry")
    registry = read_json(registry_path)
    validate_registry(registry)
    requested_engines = list(dict.fromkeys(args.engines))
    golden = resolved_release(args.golden_release, "golden")
    candidate = resolved_release(args.candidate, "candidate")
    if golden == candidate:
        raise OracleError("golden and candidate releases must be distinct resolved directories")
    golden_tree_before = tree_sha256(golden)
    candidate_tree_before = tree_sha256(candidate)
    base_report = build_base_report(
        started,
        workspace,
        git_head(workspace),
        registry_path,
        runner_path,
        driver_path,
        normalization_path,
        release_binding(golden, golden_tree_before),
        release_binding(candidate, candidate_tree_before),
        registry,
    )
    base_report["processIsolation"] = {
        "linuxChildSubreaperEnabled": subreaper_enabled,
        "fixtureProcessGroupTermination": True,
        "detachedDescendantScan": True,
    }
    output_path = args.json_output.resolve()
    node = shutil.which(args.node) if not Path(args.node).is_absolute() else args.node
    if not node or not Path(node).is_file():
        base_report["status"] = "NO_GO"
        base_report["blockers"] = [
            blocker("node-runtime-missing", "runtime", f"Node runtime unavailable: {args.node}", ["Install the reviewed Node LTS runtime and rerun the browser oracle."])
        ]
        base_report["blockedFixtureCount"] = len(registry["fixtures"])
        for fixture in registry["fixtures"]:
            evidence = {"blockedBy": ["node-runtime-missing"], "browserRuns": [], "reason": "No real Playwright process could be launched."}
            base_report["fixtures"].append(report_fixture(fixture, "NO_GO", [], 0, evidence, [], []))
        base_report["finishedAtUtc"] = utc_now()
        atomic_json(output_path, base_report)
        return EXIT_NO_GO

    playwright_module = args.playwright_module
    if not playwright_module:
        local_playwright = workspace / "browser" / "node_modules" / "playwright"
        if local_playwright.is_dir():
            playwright_module = str(local_playwright.resolve())
        else:
            base_report["status"] = "NO_GO"
            base_report["blockers"] = [
                blocker(
                    "pinned-playwright-module-missing",
                    "runtime",
                    f"Pinned Playwright installation unavailable at {local_playwright}",
                    [
                        "Run PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD=1 npm --prefix browser ci from the repository.",
                        "Then install the pinned Chromium and WebKit browser revisions and rerun the oracle.",
                    ],
                )
            ]
            base_report["blockedFixtureCount"] = len(registry["fixtures"])
            for fixture in registry["fixtures"]:
                evidence = {"blockedBy": ["pinned-playwright-module-missing"], "browserRuns": [], "reason": "The reviewed Playwright package was not installed."}
                base_report["fixtures"].append(report_fixture(fixture, "NO_GO", [], 0, evidence, [], []))
            base_report["finishedAtUtc"] = utc_now()
            atomic_json(output_path, base_report)
            return EXIT_NO_GO
    base_report["playwrightToolchain"] = {
        "module": str(playwright_module),
        "packageJsonSha256": sha256_file(resolved_file(workspace / "browser" / "package.json", "browser package")),
        "packageLockSha256": sha256_file(resolved_file(workspace / "browser" / "package-lock.json", "browser package lock")),
    }

    executable_paths: dict[str, str] = {}
    if args.chromium_executable:
        executable_paths["chromium"] = str(args.chromium_executable.expanduser().resolve())
    elif Path("/tmp/chromium").is_file() and os.access("/tmp/chromium", os.X_OK):
        # Development images sometimes provide this separately from Playwright.
        # It is accepted only after the driver hashes, launches and versions it.
        executable_paths["chromium"] = "/tmp/chromium"
    if args.webkit_executable:
        executable_paths["webkit"] = str(args.webkit_executable.expanduser().resolve())

    with tempfile.TemporaryDirectory(prefix="r9a-browser-oracle-") as temp_name:
        temp_root = Path(temp_name)
        probe_path = temp_root / "browser-probe.json"
        probe_command = playwright_command(
            str(node),
            driver_path,
            "probe",
            probe_path,
            requested_engines,
            executable_paths,
            playwright_module,
        )
        probe_return, probe_stdout, probe_stderr = run_node(probe_command, workspace, args.probe_timeout)
        if not probe_path.is_file():
            raise OracleError(
                f"browser probe did not write evidence (exit {probe_return}); stdout={probe_stdout[-2000:]}; stderr={probe_stderr[-4000:]}"
            )
        probe = read_json(probe_path)
        base_report["runtimeProbe"] = probe
        available_engines = [
            engine
            for engine in requested_engines
            if isinstance((probe.get("engines") or {}).get(engine), dict)
            and (probe["engines"][engine]).get("launchable") is True
        ]
        missing_engines = [engine for engine in requested_engines if engine not in available_engines]
        if set(requested_engines) != set(REQUIRED_ENGINES):
            missing_from_request = sorted(set(REQUIRED_ENGINES) - set(requested_engines))
            missing_engines.extend(engine for engine in missing_from_request if engine not in missing_engines)
            base_report["blockers"].append(
                blocker(
                    "required-engine-set-incomplete",
                    "configuration",
                    f"The requested engine set is incomplete: {requested_engines}; required: {list(REQUIRED_ENGINES)}",
                    [f"Rerun with --engines {' '.join(REQUIRED_ENGINES)}."],
                )
            )
        for engine in missing_engines:
            engine_probe = (probe.get("engines") or {}).get(engine) or {}
            expected_path = engine_probe.get("expectedExecutablePath") or f"Playwright-managed {engine} executable"
            base_report["blockers"].append(
                blocker(
                    f"real-{engine}-unavailable",
                    "browser-binary",
                    f"Real {engine} could not be launched: {engine_probe.get('error') or 'engine was not requested/provisioned'}",
                    [
                        "Provision browsers from the exact pinned Playwright package on the isolated audit host.",
                        "From the repository: npm --prefix browser ci && npx --prefix browser playwright install chromium webkit.",
                        f"Verify the reviewed executable exists at {expected_path}, then rerun; do not substitute a simulated engine.",
                    ],
                    {
                        "engine": engine,
                        "expectedExecutablePath": expected_path,
                        "playwrightPackageVersion": probe.get("playwrightPackageVersion"),
                        "probe": engine_probe,
                    },
                )
            )

        partial_by_id: dict[str, dict[str, Any]] = {}
        server_logs: dict[str, Any] = {}
        driver_executions: list[dict[str, Any]] = []
        process_cleanup_failed = False
        if available_engines and (not missing_engines or not args.no_partial_engine_evidence):
            selected = requested_engines if not missing_engines else available_engines
            for fixture in registry["fixtures"]:
                fixture_root = temp_root / f"fixture-{fixture['id']}"
                fixture_root.mkdir(mode=0o700)
                servers: list[ServerProcess] = []
                try:
                    controlled_hold = fixture.get("scenario") == "jobAndRequestCancellation"
                    golden_server = start_server("golden", golden, fixture_root, controlled_optimizer_hold=controlled_hold)
                    servers.append(golden_server)
                    candidate_server = start_server("candidate", candidate, fixture_root, controlled_optimizer_hold=controlled_hold)
                    servers.append(candidate_server)
                    suite_path = fixture_root / "browser-suite.json"
                    suite_command = playwright_command(
                        str(node),
                        driver_path,
                        "run",
                        suite_path,
                        selected,
                        executable_paths,
                        playwright_module,
                        registry_path,
                        golden_server.base_url,
                        candidate_server.base_url,
                        [fixture["id"]],
                        {
                            "golden": str(golden_server.optimizer_hold_root) if golden_server.optimizer_hold_root else "",
                            "candidate": str(candidate_server.optimizer_hold_root) if candidate_server.optimizer_hold_root else "",
                        },
                    )
                    suite_return, suite_stdout, suite_stderr = run_node(suite_command, workspace, args.suite_timeout)
                    if not suite_path.is_file():
                        raise OracleError(
                            f"browser fixture {fixture['id']} did not write evidence (exit {suite_return}); "
                            f"stdout={suite_stdout[-2000:]}; stderr={suite_stderr[-4000:]}"
                        )
                    suite = read_json(suite_path)
                    item = validate_driver_fixture_result(suite, suite_return, fixture, registry, selected)
                    partial_by_id[fixture["id"]] = item
                    driver_executions.append(
                        {
                            "fixtureId": fixture["id"],
                            "status": suite.get("status"),
                            "selectedEngines": list(suite.get("selectedEngines") or []),
                            "nodeVersion": suite.get("nodeVersion"),
                            "playwrightPackageVersion": suite.get("playwrightPackageVersion"),
                            "playwrightModule": suite.get("playwrightModule"),
                            "exitCode": suite_return,
                            "stdoutSha256": sha256_bytes(suite_stdout.encode()),
                            "stderrSha256": sha256_bytes(suite_stderr.encode()),
                            "suiteEvidenceSha256": sha256_file(suite_path),
                        }
                    )
                except (OracleError, subprocess.TimeoutExpired) as exc:
                    blocker_id = f"fixture-execution-failed-{fixture['id']}"
                    base_report["blockers"].append(
                        blocker(
                            blocker_id,
                            "browser-execution",
                            f"Available-engine fixture {fixture['id']} failed: {exc}",
                            ["Inspect this fixture's isolated browser/server evidence and repair it; never mark this run PASS."],
                        )
                    )
                finally:
                    for server in reversed(servers):
                        server.stop()
                        if server.residual_pids:
                            process_cleanup_failed = True
                            base_report["blockers"].append(
                                blocker(
                                    f"residual-processes-{fixture['id']}-{server.label}",
                                    "process-isolation",
                                    f"Fixture {fixture['id']} left owned processes after TERM/KILL: {server.residual_pids}",
                                    ["Quarantine the run and inspect the detached optimizer/browser process tree."],
                                )
                            )
                        with contextlib.suppress(Exception):
                            server_logs[f"{fixture['id']}:{server.label}"] = {
                                "sha256": sha256_file(server.log_path),
                                "bytes": server.log_path.stat().st_size,
                                "processExitCode": server.process.poll(),
                                "port": server.port,
                                "stateRootDistinct": str(server.state_root),
                                "executionRootDistinct": str(server.execution_root),
                                "fixtureStateIsolation": True,
                                "residualPidsAfterCleanup": list(server.residual_pids or []),
                                "controlledOptimizerHold": server.optimizer_hold_root is not None,
                                "optimizerEnteredHold": bool(server.optimizer_hold_root and (server.optimizer_hold_root / "optimizer-entered.ready").is_file()),
                                "optimizerHoldReleasedByCancellation": bool(server.optimizer_hold_root and not (server.optimizer_hold_root / "release").exists()),
                            }
                shutil.rmtree(fixture_root, ignore_errors=True)
        base_report["driverExecutions"] = driver_executions
        base_report["serverEvidence"] = server_logs

        if missing_engines:
            partial_failures = 0
            blocked_fixtures = 0
            partial_passed_engines: set[str] = set()
            for fixture in registry["fixtures"]:
                partial = partial_by_id.get(fixture["id"])
                partial_failed = bool(partial and partial.get("status") == "FAIL")
                engines_passed = list(partial.get("enginesPassed") or []) if partial and partial.get("status") == "PASS" else []
                assertions = int(partial.get("assertions") or 0) if partial else 0
                if partial and partial.get("status") == "PASS":
                    partial_passed_engines.update(engines_passed)
                if partial_failed:
                    partial_failures += 1
                else:
                    blocked_fixtures += 1
                evidence = {
                    "blockedBy": [item["id"] for item in base_report["blockers"] if item["kind"] in {"browser-binary", "configuration"}],
                    "missingEngines": sorted(set(missing_engines)),
                    "availableEngineExecution": partial.get("evidence") if partial else None,
                    "availableEngineStatus": partial.get("status") if partial else "NOT_RUN",
                    "note": "Available-engine observations are retained as partial evidence. This fixture is NO_GO and is not counted as passed until both real engines pass.",
                }
                profiles_passed = list(((partial or {}).get("evidence") or {}).get("profilesExecuted") or []) if partial and partial.get("status") == "PASS" else []
                assertion_results = list(partial.get("assertionResults") or []) if partial else []
                base_report["fixtures"].append(
                    report_fixture(
                        fixture,
                        "FAIL" if partial_failed else "NO_GO",
                        engines_passed,
                        assertions,
                        evidence,
                        assertion_results,
                        profiles_passed,
                    )
                )
            base_report["enginesPassed"] = sorted(partial_passed_engines)
            base_report["assertionsTotal"] = sum(item["assertions"] for item in base_report["fixtures"])
            base_report["failedFixtureCount"] = partial_failures
            base_report["blockedFixtureCount"] = blocked_fixtures
            base_report["status"] = "FAIL" if partial_failures else "NO_GO"
        else:
            for fixture in registry["fixtures"]:
                item = partial_by_id.get(fixture["id"])
                if item is None:
                    evidence = {
                        "reason": "The isolated driver/server invocation did not produce a validated fixture result.",
                        "blockedBy": [f"fixture-execution-failed-{fixture['id']}"],
                    }
                    base_report["fixtures"].append(report_fixture(fixture, "FAIL", [], 0, evidence, [], []))
                    continue
                evidence = item.get("evidence")
                if not isinstance(evidence, dict):
                    raise OracleError(f"driver fixture {fixture['id']} omitted evidence object")
                base_report["fixtures"].append(
                    report_fixture(
                        fixture,
                        str(item.get("status") or "FAIL"),
                        list(item.get("enginesPassed") or []),
                        int(item.get("assertions") or 0),
                        evidence,
                        list(item.get("assertionResults") or []),
                        list(evidence.get("profilesExecuted") or []) if item.get("status") == "PASS" else [],
                    )
                )
            passed = [item for item in base_report["fixtures"] if item["status"] == "PASS"]
            failed = [item for item in base_report["fixtures"] if item["status"] != "PASS"]
            base_report["passedFixtureCount"] = len(passed)
            base_report["failedFixtureCount"] = len(failed)
            base_report["fixtureIdsPassed"] = [item["id"] for item in passed]
            base_report["assertionsTotal"] = sum(item["assertions"] for item in base_report["fixtures"])
            engines_passed = set(REQUIRED_ENGINES)
            for item in passed:
                engines_passed.intersection_update(item["enginesPassed"])
            base_report["enginesPassed"] = sorted(engines_passed if not failed else set())
            if not failed:
                base_report["flowIdsPassed"] = sorted(REQUIRED_FLOWS)
                base_report["status"] = "PASS"
            else:
                base_report["status"] = "FAIL"

        golden_tree_after = tree_sha256(golden)
        candidate_tree_after = tree_sha256(candidate)
        base_report["sourceMutationCheck"] = {
            "goldenBeforeSha256": golden_tree_before,
            "goldenAfterSha256": golden_tree_after,
            "candidateBeforeSha256": candidate_tree_before,
            "candidateAfterSha256": candidate_tree_after,
            "unchanged": golden_tree_before == golden_tree_after and candidate_tree_before == candidate_tree_after,
        }
        if not base_report["sourceMutationCheck"]["unchanged"]:
            base_report["status"] = "FAIL"
            base_report["blockers"].append(
                blocker(
                    "source-release-mutated",
                    "integrity",
                    "A source release tree changed during browser execution.",
                    ["Discard the run, restore immutable releases and investigate the oracle sandbox boundary."],
                )
            )
        if process_cleanup_failed:
            base_report["status"] = "FAIL"
        base_report["finishedAtUtc"] = utc_now()
        atomic_json(output_path, base_report)
        if base_report["status"] == "PASS":
            return 0
        if base_report["status"] == "NO_GO":
            return EXIT_NO_GO
        return EXIT_FAIL


def entrypoint() -> int:
    try:
        return main()
    except (OracleError, subprocess.TimeoutExpired, OSError, ValueError) as exc:
        with contextlib.suppress(Exception):
            index = sys.argv.index("--json-output")
            output = Path(sys.argv[index + 1]).resolve()
            now = utc_now()
            atomic_json(
                output,
                {
                    "schemaVersion": SCHEMA_VERSION,
                    "oracleId": ORACLE_ID,
                    "status": "FAIL",
                    "startedAtUtc": now,
                    "finishedAtUtc": now,
                    "fixtureCount": 0,
                    "passedFixtureCount": 0,
                    "skippedFixtureCount": 0,
                    "failedFixtureCount": 1,
                    "blockedFixtureCount": 0,
                    "assertionsTotal": 0,
                    "fixtures": [],
                    "blockers": [
                        {
                            "id": "orchestrator-failure",
                            "kind": "browser-execution",
                            "message": str(exc)[:4000],
                            "remediation": ["Repair the deterministic runner failure and rerun; this report is not passing evidence."],
                        }
                    ],
                },
            )
        sys.stderr.write(f"R9A browser oracle failed: {exc}\n")
        return EXIT_FAIL


if __name__ == "__main__":
    raise SystemExit(entrypoint())
