# Volgende exclusieve stap — R9O8 externe Chromium/WebKit-gate

## Doel

Bewijs op de externe VPS dat de R9O7-candidate alle 15 fixtures en alle 100
contractasserties in Chromium én WebKit passeert, inclusief WebKit iPhone.

## Uitvoering

Voer vanuit de uitgepakte complete checkpointmap uit:

```bash
bash operations/RUN_R9O8_EXTERNAL_BROWSER_GATE_TMUX.sh
```

De runner start losgekoppeld in tmux onder
`metod-r9o8-browser-gate`. Termius mag daarna sluiten. Volgen kan met:

```bash
tmux attach -t metod-r9o8-browser-gate
```

## Acceptatie

R9O8 is uitsluitend PASS wanneer het rapport status `PASS` heeft, 15/15
fixtures en 100/100 assertions slagen, `enginesPassed` zowel Chromium als
WebKit bevat, er geen blockers zijn en de bewijschecksums kloppen. Iedere
andere uitkomst blijft NO-GO en moet integraal worden teruggeleverd.
