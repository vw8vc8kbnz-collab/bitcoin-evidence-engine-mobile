# Complete technische overdracht — R9O7 WebKit-iPhone Admin-gridtrack

## Status en hervatpunt

R9O7 herstelt de enige resterende fout uit de authentieke externe R9O6-run.
Alle lokale bron-, security-, build- en standalone-gates zijn groen. De echte
Chromium/WebKit-rerun is nog niet uitgevoerd. Daarom blijven
`releaseEligible=false`, `productionGo=false` en de formele status **NO-GO**.

- checkpointtag: `r9o7-webkit-iphone-admin-grid-track-remediation-candidate-checkpoint`;
- runtime: `METOD_PAX_R9O7_WEBKIT_IPHONE_ADMIN_GRID_TRACK_REMEDIATION_CANDIDATE.zip`;
- runtime-SHA-256: `695cdc51bb3aecb18e042f4c09ffcd972615618b7bcd47f73be1f06f732aed64`;
- runtimeleden: `465`;
- lokale status: `PASS`;
- externe status: `PENDING_R9O8`;
- productie: `NO_GO`.

## Wat de tool is

METOD/PAX Tool A is een webapplicatie voor maatwerk METOD- en PAX-fronten en
panelen. De klantflow beheert materiaal- en paneelconfiguratie, DXF-gedreven
maten, nerfpreview, klantgegevens, prijsjobs, aanvragen, annulering en
bedankflow. De Pythonruntime bezit HTTP/security, Adminsessies, duurzame
requests/jobs, FIFO/admission, optimizerprocessen, finalisatie, downloads en
statische assets. Publieke UI en Adminpresentatie zijn gesplitst in
semantische HTML en externe CSS/JavaScript.

## Bewezen R9O6-input

De ontvangen evidence-ZIP heeft SHA-256
`d49ee1875baf9e31e7e1050221e79109c73d7578db16a5c21d08f7666530cbf0`.
ZIP-CRC en alle interne checksums zijn geverifieerd. R9O6 behaalde 14/15
fixtures en 99/100 assertions. Alleen `admin-presentation-session-assets`
faalde in `webkit-iphone`: `bodyScrollWidth=492` bij `viewportWidth=393`.
Chromium desktop, WebKit desktop en Chromium iPhone waren groen; er waren
geen blockers.

De eerste overlopende node was
`section#adminSection-inbox.adminSection.active`, vanaf x=80 met een breedte
van 412.39px en `min-width:auto`. Alle gemelde kinderen pasten binnen die
section. Daarmee is de impliciete auto-gridtrack van `.adminPages` de bewezen
resterende oorzaak; de eerdere tabstripcorrectie was geldig maar niet afdoende.

## R9O7-correctie

Binnen het bestaande 640px-breakpoint krijgt `.adminPages` één expliciete
`minmax(0,1fr)`-kolom. `.adminSection` krijgt `min-width:0` en
`max-width:100%`. Er is geen overflow verborgen, geen fixture of assertion
gewijzigd en geen browserprofiel, engine of timeout verzwakt.

## Hervatten in een nieuwe chat

1. Verifieer `PACKAGE_MANIFEST_SHA256.txt` in de complete checkpointmap.
2. Lees `README_FIRST.md`, dit document en `R9O7_NEXT_STEP_R9O8.md`.
3. Verifieer runtime en R8Z tegen hun `.sha256`-sidecars.
4. Clone `git/METOD_PAX_R9_FULL_HISTORY_THROUGH_R9O7.bundle` en checkout de
   checkpointtag.
5. Behandel R8Z uitsluitend als immutable behavior-oracle.
6. Voer `operations/RUN_R9O8_EXTERNAL_BROWSER_GATE_TMUX.sh` uit.
7. Lever na afloop de volledige R9O8-map `evidence/` terug. Classificeer nooit
   op alleen een screenshot of exitcode.

## Wat na een groene R9O8 nog resteert

Een browser-PASS is geen zelfstandig live-GO. Daarna blijven minimaal echte
iPhone/Safari-validatie, een kandidaat-VPS met TLS/reverse proxy/servicebeheer,
onafhankelijke security- en full-history-secretscan, load/chaos/soak,
off-host restore, operations/observability, CAM/werkplaats/bedrijfsacceptatie
en formele release-signoff vereist.
