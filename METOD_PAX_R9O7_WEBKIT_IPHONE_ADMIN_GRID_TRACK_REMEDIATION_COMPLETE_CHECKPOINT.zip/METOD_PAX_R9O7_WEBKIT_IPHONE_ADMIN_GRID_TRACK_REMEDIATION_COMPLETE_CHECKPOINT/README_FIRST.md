# METOD/PAX R9O7 — lees dit eerst

Dit is een volledig, zelfstandig overdrachtscheckpoint voor de
`R9O7_WEBKIT_IPHONE_ADMIN_GRID_TRACK_REMEDIATION`-candidate.

## Formele status

- lokale bron-, security-, build- en standalone-gates: **PASS**;
- authentieke externe R9O6-browsergate: **FAIL** (14/15 fixtures, 99/100
  assertions; alleen WebKit iPhone Admin-layout);
- R9O7-correctie: gebouwd en lokaal geverifieerd;
- externe R9O8 Chromium/WebKit-rerun: **PENDING**;
- `releaseEligible`: `false`;
- `productionGo`: `false`;
- eindbesluit: **NO-GO** totdat R9O8 én de resterende live-gates aantoonbaar
  groen zijn.

## Identiteit

- Gitcommit: `0970ea6e317463624e884dc9d6928e8e181e77fd`;
- tag: `r9o7-webkit-iphone-admin-grid-track-remediation-candidate-checkpoint`;
- runtime-ZIP: `METOD_PAX_R9O7_WEBKIT_IPHONE_ADMIN_GRID_TRACK_REMEDIATION_CANDIDATE.zip`;
- runtime-SHA-256: `695cdc51bb3aecb18e042f4c09ffcd972615618b7bcd47f73be1f06f732aed64`;
- immutable R8Z-SHA-256: `d3e8656d8d7d5a581a8186ef8fe2c91c19b2137a8654b2f2874497dd85255e62`;
- authentieke R9O6-evidence-ZIP-SHA-256:
  `d49ee1875baf9e31e7e1050221e79109c73d7578db16a5c21d08f7666530cbf0`.

## Verificatie

Voer vanuit deze map uit:

```bash
sha256sum -c PACKAGE_MANIFEST_SHA256.txt
(cd runtime && sha256sum -c METOD_PAX_R9O7_WEBKIT_IPHONE_ADMIN_GRID_TRACK_REMEDIATION_CANDIDATE.zip.sha256)
(cd baseline && sha256sum -c METOD_PAX_FIX660R8Z_PRELIVE_HARDENED.zip.sha256)
git bundle verify git/METOD_PAX_R9_FULL_HISTORY_THROUGH_R9O7.bundle
```

Lees daarna in deze volgorde:

1. `docs/01_COMPLETE_TECHNICAL_HANDOFF_R9O7.md`;
2. `docs/R9O6_EXTERNAL_CHROMIUM_WEBKIT_GATE_RESULT.json`;
3. `docs/R9O7_WEBKIT_IPHONE_ADMIN_GRID_TRACK_REMEDIATION_CHECKPOINT.md`;
4. `docs/02_NEXT_STEP_R9O8.md`.

## Mappen

- `runtime/`: de zelfstandig gevalideerde R9O7-candidate;
- `baseline/`: immutable R8Z behavior-oracle;
- `git/`: volledige Git-history tot en met R9O7;
- `docs/`: contracten, auditbesluiten en exacte overdracht;
- `evidence/external/r9o6/`: originele en uitgepakte VPS-bewijsset;
- `evidence/release/`: lokale R9O7-gateresultaten en logs;
- `operations/`: fail-closed tmux-runner voor R9O8;
- `prior_checkpoint/`: directe R9O5-correctiecontext.

## Volgende exclusieve technische stap

Op de audit-VPS:

```bash
bash operations/RUN_R9O8_EXTERNAL_BROWSER_GATE_TMUX.sh
```

De runner meldt de tmux-sessie en de bewijsmap. Termius mag daarna sluiten.
Lever na afloop de volledige R9O8-`evidence/`-map als ZIP terug. Een groene
browsergate is noodzakelijk, maar vormt op zichzelf nog geen productie-GO.
