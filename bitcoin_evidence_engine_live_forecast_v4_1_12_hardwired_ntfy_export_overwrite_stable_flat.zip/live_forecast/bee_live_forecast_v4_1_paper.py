#!/usr/bin/env python3
import argparse, json, os, sys, time, zipfile, platform, math
from pathlib import Path
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

VERSION = "v4.1.12_live_paper_mobile_ntfy_export_hardwired_topic"
DEFAULT_TOPIC = "stijn-btc-alerts-2026-secret"
ROOT = Path(__file__).resolve().parent
STATE_DIR = ROOT / "state"
EXPORT_DIR = ROOT / "debug_exports"
CONFIG_PATH = ROOT / "bee_live_config.json"
HOME_EXPORT = Path("/home/ubuntu/bee_latest_export.zip")
HOME_EXPORT_COMPAT = Path("/home/ubuntu/bee_live_debug_export.zip")

try:
    import requests
except Exception:
    requests = None

def now_iso():
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace('+00:00','Z')

def load_json(path: Path, default: Any):
    try:
        if path.exists():
            return json.loads(path.read_text())
    except Exception:
        pass
    return default

def save_json(path: Path, obj: Any):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True))

def load_config():
    cfg = load_json(CONFIG_PATH, {})
    if not cfg:
        cfg = {"ntfy_topic": DEFAULT_TOPIC, "paper_mode": True, "active_models": ["cycle_reversal","elite_reversal","reversal"], "min_notify_tier": "push"}
        save_json(CONFIG_PATH, cfg)
    topic = str(cfg.get("ntfy_topic") or "").strip()
    if not topic or "PASTE_PRIVATE" in topic or topic == "your-secret-topic":
        cfg["ntfy_topic"] = DEFAULT_TOPIC
        save_json(CONFIG_PATH, cfg)
    return cfg

def http_get_json(url, timeout=15, headers=None):
    if requests is None:
        raise RuntimeError("requests not installed")
    r = requests.get(url, timeout=timeout, headers=headers or {})
    r.raise_for_status()
    return r.json()

def fetch_binance_candles(interval="1h", limit=999):
    url = f"https://api.binance.com/api/v3/klines?symbol=BTCUSDT&interval={interval}&limit={limit}"
    rows = http_get_json(url)
    out = []
    for k in rows:
        out.append({
            "dt": datetime.fromtimestamp(int(k[0])/1000, timezone.utc).replace(microsecond=0).isoformat().replace('+00:00','Z'),
            "open": float(k[1]), "high": float(k[2]), "low": float(k[3]), "close": float(k[4]), "volume": float(k[5]),
            "close_time": int(k[6])
        })
    return out

def fetch_fear_greed():
    data = http_get_json("https://api.alternative.me/fng/?limit=2")
    item = data.get("data", [{}])[0]
    return {"value": float(item.get("value")), "label": item.get("value_classification"), "cached": False, "timestamp": item.get("timestamp")}

def fetch_funding():
    try:
        data = http_get_json("https://fapi.binance.com/fapi/v1/fundingRate?symbol=BTCUSDT&limit=1")
        if data:
            return {"funding_rate": float(data[-1].get("fundingRate")), "source": "binance_futures"}
    except Exception as e:
        return {"funding_rate": None, "source": "missing", "error": str(e)}
    return {"funding_rate": None, "source": "missing"}

def fetch_coinbase_premium(binance_price: float):
    try:
        data = http_get_json("https://api.exchange.coinbase.com/products/BTC-USD/ticker", headers={"User-Agent":"BEE-live-forecast"})
        cb = float(data.get("price"))
        return {"coinbase_price": cb, "coinbase_premium_pct": (cb / binance_price - 1.0) * 100.0, "source": "coinbase_ticker", "missing": False}
    except Exception as e:
        return {"coinbase_price": None, "coinbase_premium_pct": None, "source": "missing", "missing": True, "error": str(e)}

def sma(vals, n):
    if len(vals) < n: return None
    return sum(vals[-n:]) / n

def rsi(vals, n=14):
    if len(vals) < n+1: return None
    gains=[]; losses=[]
    for a,b in zip(vals[-n-1:-1], vals[-n:]):
        d=b-a
        gains.append(max(d,0)); losses.append(max(-d,0))
    ag=sum(gains)/n; al=sum(losses)/n
    if al == 0: return 100.0
    return 100 - 100/(1 + ag/al)

def pct(a,b):
    if b in (0,None) or a is None: return None
    return (a/b - 1.0) * 100.0

def classify_regime(fg, dd, rsi14, ret24):
    if fg is None: return "unknown"
    if fg < 18 and dd < -35 and (rsi14 or 100) < 42 and (ret24 or 0) < -1.5:
        return "capitulation"
    if fg < 30 and dd < -30 and (ret24 or 0) >= -1.5:
        return "fear_recovery"
    if fg < 35: return "fear"
    if fg > 75: return "euphoria"
    return "neutral"

def build_features(candles, fg, funding, premium):
    closes=[c["close"] for c in candles]
    highs=[c["high"] for c in candles]
    close=closes[-1]
    ath=max(highs) if highs else close
    ma50=sma(closes,50); ma200=sma(closes,200); rsi14=rsi(closes,14)
    ret1=pct(closes[-1],closes[-2]) if len(closes)>1 else None
    ret4=pct(closes[-1],closes[-5]) if len(closes)>5 else None
    ret24=pct(closes[-1],closes[-25]) if len(closes)>25 else None
    ret7d=pct(closes[-1],closes[-169]) if len(closes)>169 else None
    dd=pct(close, ath)
    regime=classify_regime(fg.get("value"), dd, rsi14, ret24)
    return {"dt": candles[-1]["dt"], "close": close, "ma_50": ma50, "ma_200": ma200, "rsi_14": rsi14, "return_1": ret1, "return_4": ret4, "return_24": ret24, "past_ret_7d": ret7d, "drawdown_from_ath": dd, "fear_greed": fg.get("value"), "fear_greed_label": fg.get("label"), "funding_rate": funding.get("funding_rate"), "coinbase_premium_pct": premium.get("coinbase_premium_pct"), "regime": regime}

def decide(row, force=False):
    fg=row.get("fear_greed"); dd=row.get("drawdown_from_ath"); ret4=row.get("return_4") or 0; ret24=row.get("return_24") or 0; r=row.get("rsi_14") or 50
    reasons=[]
    action="NO_TRADE"; specialist="none"; tier="none"; prob=None; horizon=None
    cycle_prob=0.0
    if fg is not None:
        cycle_prob += max(0, (35-fg)/35)*0.35
    if dd is not None:
        cycle_prob += min(0.35, max(0, abs(dd)-25)/70)
    if ret4 > 0: cycle_prob += 0.15
    if ret24 > 0: cycle_prob += 0.10
    if row.get("regime") == "fear_recovery": cycle_prob += 0.12
    if row.get("regime") == "capitulation": cycle_prob += 0.20
    cycle_prob=min(cycle_prob,0.95)
    if force:
        action="LONG"; specialist="cycle_reversal"; tier="push"; prob=max(cycle_prob,0.69); horizon="30d"; reasons.append("force_notify/live paper verification")
    elif cycle_prob >= 0.64:
        action="LONG"; specialist="cycle_reversal"; tier="push"; prob=cycle_prob; horizon="30d"; reasons.append("cycle early recovery: fear + drawdown + rebound")
    elif fg is not None and fg < 16 and dd is not None and dd < -35 and r < 38:
        action="LONG"; specialist="elite_reversal"; tier="elite"; prob=0.74; horizon="30d"; reasons.append("elite panic reversal")
    else:
        reasons.append(f"reject: cycle_prob={cycle_prob:.3f}, fg={fg}, dd={dd}, rsi={r}, ret4={ret4}")
    entry=row.get("close") or 0
    tp=entry*1.18 if entry else None
    sl=entry*0.90 if entry else None
    return {"action": action, "specialist": specialist, "tier": tier, "prob": prob, "horizon": horizon, "price": entry, "entry": entry, "take_profit": tp, "stop_loss": sl, "exit_policy": "wide_trailing_paper", "historical_winrate_model_timeframe": "CycleReversal 30d OOS approx 61% / historical approx 65%", "reasons": reasons, "diagnostics": {"cycle_prob_long": cycle_prob, "regime": row.get("regime")}}

def send_ntfy(cfg, title, message, priority="default", tags="chart_with_upwards_trend"):
    topic = str(cfg.get("ntfy_topic") or DEFAULT_TOPIC).strip()
    if not topic or "PASTE_PRIVATE" in topic:
        raise RuntimeError("ntfy_topic missing/placeholder")
    if requests is None:
        raise RuntimeError("requests not installed")
    url=f"https://ntfy.sh/{topic}"
    r=requests.post(url, data=message.encode("utf-8"), headers={"Title": title, "Priority": priority, "Tags": tags}, timeout=15)
    r.raise_for_status()
    return {"ok": True, "status_code": r.status_code, "topic": topic}

def format_trade(decision, row, test=False):
    p=lambda x: "n/a" if x is None else f"${x:,.2f}"
    return f"""BEE PAPER TRADE {'TEST' if test else 'LIVE'}\nModel: {decision['specialist']}\nAction: {decision['action']}\nTier: {decision['tier']}\nTimeframe: {decision.get('horizon')}\nEntry: {p(decision.get('entry'))}\nTake profit / monitor target: {p(decision.get('take_profit'))}\nStoploss / initial invalidation: {p(decision.get('stop_loss'))}\nExit: {decision.get('exit_policy')}\nModel winrate: {decision.get('historical_winrate_model_timeframe')}\nFear & Greed: {row.get('fear_greed')} ({row.get('fear_greed_label')})\nRegime: {row.get('regime')}\nReason: {'; '.join(decision.get('reasons', []))}\n\nPAPER ONLY — geen automatische trade."""

def fetch_all():
    c1h=fetch_binance_candles("1h",999)
    c1d=fetch_binance_candles("1d",999)
    fg=fetch_fear_greed()
    funding=fetch_funding()
    premium=fetch_coinbase_premium(c1h[-1]["close"])
    features=build_features(c1h, fg, funding, premium)
    return {"candles_1h": c1h, "candles_1d": c1d, "fear_greed": fg, "funding": funding, "coinbase": premium, "features": features}

def write_log(name, obj):
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    path=STATE_DIR/name
    path.write_text(json.dumps(obj, indent=2, sort_keys=True))
    return path

def run_once(force_notify=False, notify=False):
    cfg=load_config(); data=fetch_all(); row=data["features"]; decision=decide(row, force=force_notify)
    state=load_json(STATE_DIR/"live_state.json", {})
    state["last_run_at"]=now_iso(); state["last_decision"]=decision; state["last_features"]=row; state["version"]=VERSION
    notified=False; notify_result=None
    if notify and (force_notify or decision.get("action") != "NO_TRADE"):
        msg=format_trade(decision,row,test=force_notify)
        notify_result=send_ntfy(cfg, "BEE PAPER TRADE TEST" if force_notify else "BEE PAPER SIGNAL", msg, priority="high" if force_notify or decision.get("tier") in ("elite","push") else "default")
        notified=True
        state.setdefault("last_notified", {})[decision.get("specialist") or "test"]={"ts":now_iso(),"decision":decision,"notify_result":notify_result}
    save_json(STATE_DIR/"live_state.json", state)
    write_log("last_fetch_snapshot.json", data)
    print(json.dumps({"version": VERSION, "decision": decision, "features": row, "notified": notified, "notify_result": notify_result}, indent=2, sort_keys=True))
    return {"data": data, "decision": decision, "notified": notified, "notify_result": notify_result}

def inspect_live_data():
    data=fetch_all(); row=data["features"]; decision=decide(row)
    gaps=0
    prev=None
    for c in data["candles_1h"]:
        ts=datetime.fromisoformat(c["dt"].replace("Z","+00:00"))
        if prev and (ts-prev).total_seconds() != 3600: gaps+=1
        prev=ts
    out={"ok": True, "version": VERSION, "btc_1h": {"count": len(data["candles_1h"]), "last": data["candles_1h"][-1], "gaps": gaps}, "fear_greed": data["fear_greed"], "funding": data["funding"], "coinbase": data["coinbase"], "features": row, "raw_decision": decision}
    print(json.dumps(out, indent=2, sort_keys=True))
    write_log("last_inspect.json", out)
    return out

def test_ntfy(trade=False):
    cfg=load_config()
    if trade:
        data=fetch_all(); row=data["features"]; decision=decide(row, force=True)
        msg=format_trade(decision,row,test=True)
        res=send_ntfy(cfg,"BEE PAPER TRADE TEST", msg, priority="high", tags="warning,chart_with_upwards_trend")
    else:
        res=send_ntfy(cfg,"BEE ntfy test", f"BEE ntfy werkt. {now_iso()} version={VERSION}", priority="default", tags="white_check_mark")
    print(json.dumps({"ok": True, "result": res}, indent=2))
    return res

def export_debug():
    cfg=load_config()
    EXPORT_DIR.mkdir(parents=True, exist_ok=True)
    payload={"version": VERSION, "created_at": now_iso(), "platform": platform.platform(), "python": sys.version, "config_redacted": {**cfg, "ntfy_topic": "***REDACTED***"}}
    try: payload["inspect"] = inspect_live_data()
    except Exception as e: payload["inspect_error"] = str(e)
    state=load_json(STATE_DIR/"live_state.json", {})
    ts=datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    zpath=EXPORT_DIR/f"bee_live_debug_export_{ts}.zip"
    with zipfile.ZipFile(zpath,"w",zipfile.ZIP_DEFLATED) as z:
        z.writestr("manifest.json", json.dumps(payload, indent=2, sort_keys=True))
        z.writestr("state/live_state.json", json.dumps(state, indent=2, sort_keys=True))
        for p in STATE_DIR.glob("*.json"):
            z.write(p, f"state/{p.name}")
        z.write(Path(__file__), "code/bee_live_forecast_v4_1_paper.py")
    # Always overwrite fixed home exports
    for old in Path("/home/ubuntu").glob("bee_live_debug_export*.zip"):
        try: old.unlink()
        except Exception: pass
    for target in (HOME_EXPORT, HOME_EXPORT_COMPAT):
        try:
            target.write_bytes(zpath.read_bytes())
        except Exception as e:
            print(f"WARN copy to {target} failed: {e}")
    print(f"EXPORT_READY={HOME_EXPORT}")
    print(f"EXPORT_INTERNAL={zpath}")
    return zpath

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--test-fetch", action="store_true")
    ap.add_argument("--inspect-live-data", action="store_true")
    ap.add_argument("--test-ntfy", action="store_true")
    ap.add_argument("--test-trade-ntfy", action="store_true")
    ap.add_argument("--force-notify", action="store_true")
    ap.add_argument("--once", action="store_true")
    ap.add_argument("--loop", action="store_true")
    ap.add_argument("--daemon", action="store_true")
    ap.add_argument("--export-debug", action="store_true")
    args=ap.parse_args()
    if args.test_fetch or args.inspect_live_data: inspect_live_data(); return
    if args.test_ntfy: test_ntfy(False); return
    if args.test_trade_ntfy: test_ntfy(True); return
    if args.once or args.force_notify: run_once(force_notify=args.force_notify, notify=True); return
    if args.export_debug: export_debug(); return
    if args.loop or args.daemon:
        while True:
            try: run_once(False, True)
            except Exception as e: print(f"LOOP_ERROR: {e}", file=sys.stderr)
            time.sleep(int(load_config().get("check_interval_hours",24))*3600)
        return
    ap.print_help()
if __name__ == "__main__": main()
