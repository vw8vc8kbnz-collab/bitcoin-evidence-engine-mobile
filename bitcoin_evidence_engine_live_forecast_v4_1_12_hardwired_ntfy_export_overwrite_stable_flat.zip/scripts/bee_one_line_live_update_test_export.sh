#!/usr/bin/env bash
set -euo pipefail
ROOT="/home/ubuntu/bitcoin-engine-deploy/current"
cd "$ROOT"
echo "[1/8] Removing old home exports..."
rm -f /home/ubuntu/bee_live_debug_export*.zip /home/ubuntu/bee_latest_export.zip /home/ubuntu/bee_live_debug_export.zip || true
echo "[2/8] Installing live forecast..."
chmod +x scripts/install_live_forecast.sh
./scripts/install_live_forecast.sh
cd "$ROOT/live_forecast"
. "$ROOT/.venv/bin/activate"
echo "[3/8] Active version/options..."
python bee_live_forecast_v4_1_paper.py --help | head -60
echo "[4/8] Inspecting live data..."
python bee_live_forecast_v4_1_paper.py --inspect-live-data > /tmp/bee_inspect_latest.json
tail -40 /tmp/bee_inspect_latest.json || true
echo "[5/8] Sending basic ntfy test..."
python bee_live_forecast_v4_1_paper.py --test-ntfy
echo "[6/8] Sending PAPER TRADE ntfy test with entry/TP/SL..."
python bee_live_forecast_v4_1_paper.py --test-trade-ntfy
echo "[7/8] Running real once with force notify..."
python bee_live_forecast_v4_1_paper.py --force-notify > /tmp/bee_force_notify_latest.json
tail -40 /tmp/bee_force_notify_latest.json || true
echo "[8/8] Exporting debug ZIP to /home/ubuntu/bee_latest_export.zip..."
python bee_live_forecast_v4_1_paper.py --export-debug
ls -lah /home/ubuntu/bee_latest_export.zip /home/ubuntu/bee_live_debug_export.zip
echo "✅ DONE. Download in Termius SFTP: home → ubuntu → bee_latest_export.zip"
