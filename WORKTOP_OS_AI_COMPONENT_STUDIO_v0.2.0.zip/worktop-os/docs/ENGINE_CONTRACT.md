# C++ Engine Contract

## Doel

Dezelfde canonical geometry moet 2D, 3D, validatie, DXF en nesting voeden.

## Eerste native contract

De foundation ondersteunt:

- rechthoek genereren;
- gesloten contour controleren;
- oppervlakte en omtrek berekenen;
- foutdiagnostiek;
- JSON-output via CLI.

## Latere modules

1. `shape_builder`
2. `constraints`
3. `component_geometry`
4. `placement`
5. `meshing`
6. `validation`
7. `dxf`
8. `nesting`

## Fail-closed

Wanneer de native of WASM-engine geen geldig resultaat geeft, wordt productie-export geblokkeerd. Er komt geen alternatieve JavaScript-geometrie als stille fallback.
