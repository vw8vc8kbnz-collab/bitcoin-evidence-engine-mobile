# Architectuur

## Hoofdregel

UI, SaaS-orchestratie, AI-extractie, databronnen en de autoritatieve C++-engine blijven strikt gescheiden.

```text
apps/web
  ├─ app routes
  ├─ feature modules
  ├─ server-only OpenAI adapter
  ├─ secure upload storage
  └─ reusable components

packages/domain
  ├─ pure domain types
  └─ pure derived-state functions

packages/contracts
  └─ runtime validated geometry API contracts

packages/ai-ingestion
  ├─ strict Structured Output schema
  ├─ extraction prompt contract
  └─ candidate types

packages/data
  ├─ PostgreSQL repositories
  └─ ordered SQL migrations

engine/core
  ├─ geometry
  ├─ validation
  ├─ placement
  └─ later: vector ingest, meshing, DXF and nesting
```

## Dependency-richting

```text
web -> ai-ingestion schema
web -> data repositories
web -> contracts -> domain
web -> future engine adapter
C++ core -> no web dependency
```

## AI Component Ingestion

```text
Product photo + official PDF + optional DXF/DWG
        ↓
File validation, SHA-256 and rights scope
        ↓
Encrypted/private server storage boundary
        ↓
OpenAI extractor pass
        ↓
OpenAI verifier pass
        ↓
Zod Structured Output validation
        ↓
PostgreSQL AI_EXTRACTED_CANDIDATE
        ↓
native C++ candidate DXF compiler
        ↓
future human source review
        ↓
verified C++ Geometry Set and machine export
```

### Hard boundary

The OpenAI adapter never publishes production geometry. The native C++ compiler may produce review-only DXF files from complete, explicitly sourced parameters. These carry an unverified marker and cannot become machine output. Uploaded DXF/DWG sources are stored but deliberately not interpreted by the language model; the future C++ vector importer owns that responsibility.

## Secrets

`OPENAI_API_KEY` is server-only and lives outside the repository in `/etc/worktop-os/worktop-os.env` on the VPS. The client receives only a boolean configuration status.

## Geen oneindige HTML-bestanden

- Pages only orchestrate sections.
- Each section is its own component.
- Data and schemas live outside JSX.
- Styling uses central tokens.
- `npm run structure:check` blocks oversized source files.

## State and persistence

- PostgreSQL stores jobs and structured candidates.
- Object files remain on server storage under `WORKTOP_DATA_DIR`.
- Released production data will later be immutable.
- Demo library seed data remains isolated from real component candidates.

## C++ as truth

The browser can render previews and AI can structure candidate data, but production geometry, validation, DXF and nesting must ultimately come exclusively from the C++ core.
