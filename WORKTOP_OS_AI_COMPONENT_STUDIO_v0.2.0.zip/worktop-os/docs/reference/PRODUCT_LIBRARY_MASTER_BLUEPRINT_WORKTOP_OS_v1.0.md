# PRODUCT LIBRARY MASTER BLUEPRINT — WORKTOP OS

**Documentstatus:** Definitieve moduleblueprint  
**Versie:** 1.0  
**Module:** Product Library / Component Intelligence  
**Platform:** Worktop OS  
**Doel:** Een premium, visuele, waarheidsgestuurde productbibliotheek waarin gebruikers echte producten herkennen, slim zoeken, technisch controleren en direct naar een werkblad slepen  
**Scope:** Kookplaten, spoelbakken, kranen, zeeppompjes, dispensers, stopcontactunits, afvoeren en overige werkbladgerelateerde componenten  
**Belangrijkste productregel:** De foto is voor herkenning; de geverifieerde technische geometrie bepaalt de productie

---

# 1. Executive summary

De Product Library wordt een centrale kernmodule van Worktop OS. Het is nadrukkelijk geen eenvoudige artikeltabel en ook geen decoratieve catalogus. De module combineert vier functies:

1. **Visuele productherkenning**  
   De gebruiker ziet echte productfoto’s, merk, model, afmetingen en installatiemethoden.

2. **Slim zoeken en filteren**  
   De gebruiker kan zoeken op merk, model, artikelnummer, categorie, afmeting, installatiemethode, kleur, eigenschappen en vrije tekst.

3. **Technische waarheid en verificatie**  
   Achter ieder product zitten revisioneerbare geometriesets, productiegegevens, bronnen, toleranties, dieptes, radii, veiligheidszones en compatibiliteitsregels.

4. **Directe werkbladinteractie**  
   De gebruiker sleept een product vanuit de library naar het actieve werkblad. Na loslaten kiest hij alleen een installatiemethode die aantoonbaar bij het exacte product, materiaal en de bladdikte past.

De library moet aanvoelen als een luxe, moderne productcatalogus, maar functioneren als een productiekritische componentdatabase.

De centrale belofte luidt:

> **Vind het echte product, herken het aan de echte foto, controleer de technische status en sleep het als intelligent productieobject direct naar het werkblad.**

---

# 2. Vastgezette scope

## 2.1 Productcategorieën

### Kookplaten

- inductiekookplaten;
- gaskookplaten;
- keramische kookplaten;
- kookplaten met geïntegreerde afzuiging;
- domino-elementen;
- speciale inbouwkookplaten.

### Spoelbakken

- enkele bak;
- dubbele bak;
- anderhalve bak;
- ronde bak;
- vierkante bak;
- spoelbak met afdruipdeel;
- geïntegreerde werkbak;
- speciale maatwerkspoelbak.

### Kranen

- standaard kraan;
- kokendwaterkraan;
- mengkraan;
- uittrekbare kraan;
- sensor- of elektronisch model;
- aparte bedieningsunit.

### Kleine componenten

- zeeppomp;
- dispenser;
- drukknop;
- afvoerbediening;
- stopcontactunit;
- kabeldoorvoer;
- afvaldoorvoer;
- ventilatieopening;
- losse boorcomponent;
- speciale werkbladuitsparing.

## 2.2 Installatiemethoden binnen de normale scope

### Kookplaat

- opbouw / bovenbouw;
- vlakinbouw.

Onderbouw wordt niet als normale kookplaatoptie getoond.

### Spoelbak

- opbouw / bovenbouw;
- vlakinbouw;
- onderbouw.

### Kraan en kleine componenten

- doorvoer / boorgat;
- eventuele verzonken montage;
- modelspecifieke montagewijze.

## 2.3 Geen generieke aannames

De library mag nooit aannemen dat:

- iedere kookplaat vlakinbouw ondersteunt;
- iedere spoelbak onderbouw ondersteunt;
- dezelfde uitsparing voor meerdere installatiemethoden geldt;
- een productfoto technische geometrie bewijst;
- een modelnaam zonder revisie voldoende is;
- een fabrikantmaat automatisch voor ieder materiaal geldig is;
- een vergelijkbaar model dezelfde contour heeft.

---

# 3. Productprincipes

## 3.1 Visual first, truth underneath

De eerste laag is visueel en toegankelijk:

- echte foto;
- merk;
- model;
- hoofdafmetingen;
- categorie;
- installatiemethoden;
- verificatiestatus.

De tweede laag is technisch:

- uitsparingscontour;
- sponningcontour;
- dieptes;
- radii;
- toleranties;
- veiligheidszones;
- materiaalvoorwaarden;
- bronverwijzingen;
- revisiegeschiedenis.

## 3.2 Echte foto, intelligent object

Een productkaart representeert één intelligent componentobject.

De gebruiker sleept niet alleen een afbeelding. Hij sleept:

```text
Productidentiteit
+ exacte revisie
+ installatiecapaciteiten
+ geometry sets
+ productie-intenties
+ veiligheidszones
+ bronstatus
+ verificatiestatus
```

## 3.3 Capability-aware interface

De interface toont alleen acties en installatiemethoden die voor de geselecteerde productrevisie relevant zijn.

## 3.4 Geen schijnzekerheid

Ontbreekt een geverifieerde sponningcontour, dan is vlakinbouw niet productieklaar.

Ontbreekt onderbouwinformatie, dan wordt onderbouw niet actief gemaakt.

## 3.5 Revision first

Een product is nooit alleen:

> Franke Mythos

maar bijvoorbeeld:

> Franke Mythos MTX 110-50 — artikelnummer X — revisie 2026-02

## 3.6 Bron per kritieke waarde

Iedere kritieke maat of productie-eigenschap moet traceerbare herkomst hebben.

## 3.7 Snel tijdens projecten, volledig in beheer

In de projecteditor moet de library razendsnel en compact werken.

In het beheercentrum moet de volledige technische diepte beschikbaar zijn.

---

# 4. Gebruikersrollen

## 4.1 Designer

Mag:

- producten zoeken;
- producten bekijken;
- geverifieerde producten slepen;
- favorieten gebruiken;
- tenantcollecties gebruiken.

Mag niet:

- kritieke productdata aanpassen;
- componenten platformbreed publiceren;
- kandidaten productieklaar verklaren.

## 4.2 Werkvoorbereider

Mag daarnaast:

- technische details bekijken;
- bronnen openen;
- tenant-verified componenten gebruiken;
- bepaalde waarschuwingen beoordelen;
- een custom component aanvragen.

## 4.3 Component Manager

Mag:

- nieuwe tenantcomponenten aanmaken;
- bronbestanden toevoegen;
- geometry sets beheren;
- revisions maken;
- human checks uitvoeren;
- tenantverificatie geven.

## 4.4 Tenant Admin

Mag:

- tenantcollecties bepalen;
- voorkeursproducten instellen;
- verboden modellen markeren;
- gebruiksrechten beheren;
- tenantcomponenten publiceren binnen de organisatie.

## 4.5 Platform Data Manager

Mag:

- platformcatalogus beheren;
- fabrikantdata controleren;
- platformverificatie geven;
- producten superseden;
- bronlicenties beheren;
- productfamilies onderhouden.

---

# 5. Modulearchitectuur

De Product Library bestaat uit acht logisch gescheiden lagen.

```text
1. Visual Catalog
2. Search & Discovery
3. Product Identity
4. Capability & Compatibility
5. Geometry Sets
6. Provenance & Verification
7. Project Placement
8. Revision & Lifecycle Management
```

## 5.1 Visual Catalog

- echte productfoto’s;
- productkaarten;
- galerijen;
- merkpresentatie;
- categoriepresentatie.

## 5.2 Search & Discovery

- slimme zoekbalk;
- filters;
- facetten;
- synoniemen;
- typefouten;
- maatinterpretatie;
- favorieten;
- recent gebruikt;
- aanbevelingen.

## 5.3 Product Identity

- merk;
- model;
- modelserie;
- artikelnummer;
- EAN;
- revisie;
- variant;
- kleur;
- categorie.

## 5.4 Capability & Compatibility

- installatiemethoden;
- materiaalgeschiktheid;
- diktegeschiktheid;
- vereiste geometrie;
- conditions;
- blokkades.

## 5.5 Geometry Sets

- doorfreescontour;
- sponningcontour;
- pocket;
- boorgaten;
- componentanker;
- reveal;
- veiligheidszones;
- servicevolume;
- visual envelope.

## 5.6 Provenance & Verification

- bronbestanden;
- bronregels;
- controlehistorie;
- verificatiestatus;
- afwijkingen;
- revisiestatus.

## 5.7 Project Placement

- drag-and-drop;
- installatieoverlay;
- voorlopige plaatsing;
- exact positioneren;
- 2D/3D-preview;
- validatie.

## 5.8 Revision & Lifecycle Management

- conceptrevisies;
- review;
- publicatie;
- superseding;
- vergelijking;
- migratie van actieve projecten.

---

# 6. Informatiearchitectuur

## 6.1 Hoofdnavigatie

De module verschijnt als één hoofditem:

**Product Library**

Onderliggende pagina’s:

1. Ontdekken  
2. Alle producten  
3. Favorieten  
4. Recent gebruikt  
5. Bedrijfscollecties  
6. Eigen componenten  
7. Review & verificatie  
8. Revisies  
9. Bronnen  
10. Merken  
11. Importeren  
12. Library-instellingen  

Niet iedere rol ziet iedere pagina.

## 6.2 Embedded project library

Binnen de werkbladeditor bestaat een compacte librarydrawer:

- snelle zoekbalk;
- categoriechips;
- favorieten;
- recent gebruikt;
- zoekresultaten;
- drag-and-drop;
- quick preview.

De gebruiker hoeft dus niet steeds de projecteditor te verlaten.

---

# 7. Paginaoverzicht

# 7.1 Product Library — Ontdekken

## Doel

Een visuele startpagina die snel toegang geeft tot veelgebruikte producten.

## Header

- titel: `Product Library`;
- globale zoekbalk;
- knop `Nieuw component`;
- knop `Importeren`;
- toggle `Platform / Bedrijf / Alles`;
- gebruikerscollectie.

## Secties

### Recent gebruikt

Horizontale rij met de laatste acht producten.

### Favorieten

Persoonlijke favorieten.

### Bedrijfsstandaard

Door de tenantbeheerder goedgekeurde voorkeursproducten.

### Populaire categorieën

- kookplaten;
- spoelbakken;
- kranen;
- kleine componenten.

### Recent geverifieerd

Nieuwe platform- of tenantverified producten.

### Update vereist

Alleen zichtbaar wanneer gebruikte producten een nieuwe revisie hebben.

## Productkaartgedrag

- klik opent quick preview;
- dubbelklik opent detailpagina;
- slepen activeert dragobject;
- ster voegt toe aan favorieten;
- contextmenu toont aanvullende acties.

---

# 7.2 Alle producten

## Desktoplayout

```text
┌────────────────────────────────────────────────────────────────────────────┐
│ Product Library                                                           │
│ [ Zoek op merk, model, artikelnummer, maat of eigenschap... ]             │
├────────────────┬─────────────────────────────────────────┬─────────────────┤
│ Filters        │ Productresultaten                       │ Quick preview   │
│                │                                         │                 │
│ Categorie      │  [kaart] [kaart] [kaart]               │ Productfoto     │
│ Merk           │  [kaart] [kaart] [kaart]               │ Kerngegevens    │
│ Installatie    │  [kaart] [kaart] [kaart]               │ Status          │
│ Materiaal      │                                         │ Acties          │
│ Afmetingen     │                                         │                 │
│ Status         │                                         │                 │
└────────────────┴─────────────────────────────────────────┴─────────────────┘
```

## Resultatenheader

- aantal resultaten;
- actieve filters;
- sortering;
- grid/list toggle;
- compacte/ruime kaarttoggle;
- filters resetten;
- zoekopdracht opslaan.

## Sorteeropties

- meest relevant;
- recent gebruikt;
- alfabetisch;
- merk;
- recent geverifieerd;
- meest compleet;
- meest gebruikt binnen bedrijf;
- nieuwste revisie.

## Belangrijke regel

`Meest relevant` mag een exact artikelnummer nooit onder een populariteitsresultaat plaatsen.

---

# 7.3 Categorielanding

Iedere hoofdcategorie krijgt een eigen landing.

## Kookplaten

Filters en highlights:

- breedte;
- diepte;
- met afzuiging;
- installatiemethode;
- energie- of functietype;
- merk;
- kleur;
- verificatie.

## Spoelbakken

Filters:

- aantal bakken;
- vorm;
- buitenmaat;
- bakmaat;
- afdruipdeel;
- installatiemethode;
- materiaal;
- kleur;
- kraanbank;
- overloop;
- verificatie.

## Kranen

Filters:

- boorgatdiameter;
- extra bediening;
- kokendwaterfunctie;
- montagevoet;
- kleur;
- merk;
- hoogte;
- verificatie.

## Kleine componenten

Filters:

- componenttype;
- gatdiameter;
- verzonken montage;
- materiaal;
- afwerking;
- merk.

---

# 7.4 Zoekresultatenpagina

## Doel

Volledige resultaten voor complexe zoekopdrachten.

## Zoekvoorbeeld

```text
franke zwarte onderbouw spoelbak 500
```

De zoekmachine interpreteert:

- merk: Franke;
- kleur: zwart;
- installatie: onderbouw;
- categorie: spoelbak;
- maat rond 500 mm.

## Resultaatuitleg

Boven de resultaten:

> 24 producten gevonden voor Franke, onderbouw, zwart en circa 500 mm.

## Correctievoorstel

Bij typefout:

> Bedoelde je `Quooker` in plaats van `Quoker`?

## Geen-resultaatflow

Toon:

- welke filters de blokkade veroorzaken;
- vergelijkbare producten;
- minder strenge zoekoptie;
- custom component aanvragen;
- fabrikant-PDF of DXF uploaden.

---

# 7.5 Quick preview-paneel

## Doel

Snel technisch beoordelen zonder volledige productpagina te openen.

## Opbouw

### Boven

- grote echte productfoto;
- afbeeldingsteller;
- favoriet;
- verificatiebadge.

### Identiteit

- merk;
- model;
- artikelnummer;
- variant;
- revisie.

### Kerngegevens

- buitenmaat;
- categorie;
- installatiemethoden;
- materiaalgeschiktheid;
- status technische data.

### Productiestatus

- uitsparing beschikbaar;
- sponning beschikbaar;
- diepte bekend;
- radii bekend;
- bron gecontroleerd;
- revisie actief.

### Acties

- `Sleep naar werkblad`;
- `Open volledige details`;
- `Vergelijk`;
- `Toevoegen aan favorieten`;
- `Bronnen bekijken`.

## Projectcontext

Wanneer het paneel binnen een actief project wordt geopend, toont het direct:

- past bij materiaal: ja/nee;
- past bij dikte: ja/nee;
- beschikbare installatieopties in dit project;
- eventuele blokkade.

---

# 7.6 Productdetailpagina

## Doel

Volledige visuele, technische en bronmatige productweergave.

## Header

- terug naar resultaten;
- productidentiteit;
- statusbadge;
- favoriet;
- vergelijken;
- revisiekiezer;
- primaire actie `Plaats op werkblad`.

## Hoofdgrid

### Linkerkolom — fotogalerij

- grote hoofdafbeelding;
- thumbnails;
- zoom;
- full-screen;
- weergavetype:
  - productfoto;
  - technische afbeelding;
  - installatiefoto;
  - onderzijde;
  - 3D-preview.

### Rechterkolom — kerninformatie

- merk;
- model;
- serie;
- artikelnummer;
- EAN;
- variant;
- kleur;
- categorie;
- buitenmaten;
- status;
- bronupdate.

## Tabs

1. Overzicht  
2. Installatie  
3. Productiegeometrie  
4. Materialen  
5. Bronnen  
6. Revisies  
7. Gebruik in projecten  
8. Audit  

---

# 7.7 Productdetail — tab Overzicht

## Inhoud

- korte productomschrijving;
- hoofdafmetingen;
- producttype;
- afbeeldingen;
- ondersteunde installatiemethoden;
- technische volledigheid;
- verificatiestatus;
- bedrijfsstatus;
- gebruiksstatistiek;
- alternatieve varianten.

## Productfamilie

Toon gerelateerde modellen:

- zelfde serie;
- andere maat;
- andere kleur;
- andere bakvariant;
- opvolgend model.

---

# 7.8 Productdetail — tab Installatie

## Installatiekaarten

Per ondersteunde installatiemethode een kaart.

### Opbouw

- status;
- kleine doorsnede;
- geometry set;
- vereiste toleranties;
- materiaalvoorwaarden;
- minimumdikte;
- bron.

### Vlakinbouw

- sponningcontour;
- diepte;
- speling;
- minimum resterende dikte;
- toegestane materialen;
- bron.

### Onderbouw

Alleen bij relevante componenten:

- zichtopening;
- revealmodi;
- montagezone;
- binnenrandafwerking;
- toegestane materialen;
- bron.

## Niet-ondersteunde methode

Kan informatief grijs worden getoond:

> Niet ondersteund voor deze productrevisie.

Of:

> Technische data ontbreekt; methode niet productieklaar.

---

# 7.9 Productdetail — tab Productiegeometrie

## Visuele lagen

- apparaatbuitenmaat;
- doorfreescontour;
- sponningcontour;
- pockets;
- boringen;
- veiligheidszone;
- componentanker;
- fabrikant-datumpunt;
- servicevolume.

## Viewer

2D/3D-toggle.

### 2D

- exacte contouren;
- maatlijnen;
- radii;
- kleurlegenda;
- bronstatus per feature.

### 3D

- werkbladfragment;
- componentmodel;
- installatiehoogte;
- sponning;
- gat;
- onderzijde;
- doorsnede.

## Featureselectie

Klik op een contour om rechts te zien:

- type;
- maat;
- diepte;
- bron;
- verificatie;
- revisie;
- tolerantie.

---

# 7.10 Productdetail — tab Materialen

## Compatibiliteitsmatrix

Rijen:

- HPL;
- compact;
- solid surface;
- composiet;
- keramiek;
- natuursteen;
- hout;
- custom.

Kolommen:

- opbouw;
- vlakinbouw;
- onderbouw;
- minimumdikte;
- opmerkingen.

## Statussen

- toegestaan;
- toegestaan onder voorwaarden;
- tenantregel vereist;
- niet ondersteund;
- onbekend.

## Regelherkomst

Maak onderscheid tussen:

- fabrikantregel;
- materiaalregel;
- tenantstandaard;
- platformbeperking.

---

# 7.11 Productdetail — tab Bronnen

## Bronlijst

Per bron:

- type;
- titel;
- fabrikant;
- documentnummer;
- revisie;
- datum;
- bestand;
- pagina’s;
- gekoppelde waarden;
- verificatiestatus;
- rechtenstatus.

## Voorbeelden

- officiële DXF;
- installatiehandleiding;
- technisch datablad;
- fabrikantmail;
- tenantmeting;
- handmatige controletekening.

## Bronviewer

Open PDF of technische afbeelding naast de gekoppelde productdata.

De gebruiker ziet bijvoorbeeld:

```text
Uitsparing 750 × 490 mm
Bron: Officiële installatietekening, revisie 2026-02, pagina 14
```

---

# 7.12 Productdetail — tab Revisies

## Revisietijdlijn

- aangemaakt;
- gecontroleerd;
- gepubliceerd;
- vervangen;
- teruggetrokken.

## Verschilweergave

Vergelijk revisies op:

- foto’s;
- artikelnummer;
- buitenmaat;
- uitsparing;
- sponning;
- diepte;
- radius;
- installatiemethoden;
- materiaalvoorwaarden;
- bronnen.

## Projectimpact

Toon:

- aantal conceptprojecten met oude revisie;
- aantal vrijgegeven projecten;
- migratie mogelijk;
- handmatige controle nodig.

---

# 7.13 Product vergelijken

## Selectie

Maximaal vier producten tegelijk.

## Vergelijkingsvelden

- echte foto;
- merk/model;
- buitenmaat;
- uitsparing;
- installatiemethoden;
- materialen;
- dikte;
- radii;
- dieptes;
- verificatiestatus;
- bronvolledigheid;
- laatste revisie.

## Verschillen highlighten

Toggle:

- alleen verschillen;
- alleen productiekritieke verschillen;
- alle eigenschappen.

## Actie

- kies product;
- plaats in project;
- voeg toe aan collectie.

---

# 7.14 Favorieten

## Niveaus

- persoonlijke favorieten;
- teamfavorieten;
- bedrijfsstandaard.

## Functies

- slepen;
- sorteren;
- groeperen;
- notitie;
- verwijderen;
- delen binnen tenant.

## Bedrijfsfavoriet

Kan alleen door bevoegde rol worden ingesteld.

---

# 7.15 Recent gebruikt

## Doel

Razendsnelle toegang binnen dagelijkse productie.

## Inhoud

- recent geplaatst;
- recent bekeken;
- recent gezocht;
- recent bijgewerkt.

## Context

Recent gebruikt binnen:

- huidige gebruiker;
- huidig team;
- huidige organisatie.

---

# 7.16 Bedrijfscollecties

## Voorbeelden

- standaard spoelbakken;
- voorkeurskookplaten;
- Quooker assortiment;
- showroomcollectie 2026;
- alleen onderbouwmodellen;
- eigen goedgekeurde componenten.

## Collectie-eigenschappen

- naam;
- beschrijving;
- eigenaar;
- zichtbaarheid;
- volgorde;
- gebruiksdoel;
- verplichte of aanbevolen status.

## Beperkingsmodus

Een tenant kan instellen:

- alle libraryproducten toegestaan;
- alleen bedrijfscollecties standaard tonen;
- niet-goedgekeurde producten vereisen review;
- bepaalde producten blokkeren.

---

# 7.17 Eigen componenten

## Doel

Producten beheren die niet platformbreed beschikbaar zijn.

## Lijstweergave

- foto;
- merk/model;
- status;
- eigenaar;
- revisie;
- compleetheid;
- laatst gewijzigd;
- gebruik in projecten.

## Statussen

- concept;
- data invoeren;
- review vereist;
- tenant verified;
- geblokkeerd;
- superseded.

## Acties

- nieuw component;
- dupliceren;
- bron uploaden;
- review aanvragen;
- revisie maken;
- blokkeren;
- archiveren.

---

# 7.18 Nieuw component — wizard

## Stap 1 — Identiteit

- categorie;
- merk;
- model;
- serie;
- artikelnummer;
- EAN;
- variant;
- kleur;
- revisie.

## Stap 2 — Foto’s

- hoofdafbeelding;
- galerij;
- technische afbeeldingen;
- bron;
- rechtenstatus;
- uitsnede;
- achtergrondcontrole.

## Stap 3 — Bronnen

- PDF;
- DXF;
- afbeelding;
- datasheet;
- fabrikantlink als bronreferentie;
- handmatige verklaring.

## Stap 4 — Installatiemethoden

- opbouw;
- vlakinbouw;
- onderbouw indien categorie dit toestaat;
- voorwaarden;
- bron per methode.

## Stap 5 — Geometrie

- DXF-contour importeren;
- parametrisch invoeren;
- contour classificeren;
- datum point;
- gaten;
- sponning;
- pockets;
- veiligheidszones.

## Stap 6 — Dieptes en toleranties

- doorfrezen;
- sponningdiepte;
- speling;
- radius;
- minimumdikte;
- reveal;
- boorgatdiameters.

## Stap 7 — Materiaalcompatibiliteit

- materiaal;
- dikte;
- uitzonderingen;
- tenantregels.

## Stap 8 — Visuele controle

- 2D;
- 3D;
- doorsnede;
- maatlabels;
- bronoverlay.

## Stap 9 — Review

- ontbrekende velden;
- conflicten;
- ongeverifieerde waarden;
- reviewer kiezen.

## Stap 10 — Publicatie

- tenantcandidate;
- human checked;
- tenant verified.

Platformverified vereist een apart platformproces.

---

# 7.19 Review & verificatie

## Queue

Kolommen:

- product;
- categorie;
- aangevraagd door;
- status;
- ontbrekende gegevens;
- bronvolledigheid;
- risico;
- reviewer;
- deadline.

## Reviewworkspace

Links:

- bronbestanden.

Midden:

- technische geometrie.

Rechts:

- waarden;
- bronkoppeling;
- status;
- opmerkingen.

## Vier-ogenprincipe

Voor platformverificatie:

- invoerder;
- eerste reviewer;
- finale verifier.

Dezelfde persoon mag niet alle stappen uitvoeren wanneer de organisatie dit vereist.

---

# 7.20 Revisievergelijking

## Visueel

Overlay van oude en nieuwe contour:

- groen toegevoegd;
- rood verwijderd;
- blauw ongewijzigd.

## Technisch

Tabel met verschillen.

## Impactclassificatie

- cosmetisch;
- metadata;
- niet-kritieke maat;
- kritieke geometrie;
- installatiemethode;
- materiaalregel;
- blokkade.

## Projectactie

- behouden oude revisie;
- migreren;
- kopie maken;
- project blokkeren tot review.

---

# 7.21 Bronbeheer

## Centrale bronrepository

- fabrikantdocumenten;
- DXF’s;
- datasheets;
- productfoto’s;
- installatietekeningen;
- tenantmetingen.

## Metadata

- fabrikant;
- documentnummer;
- revisie;
- datum;
- rechten;
- taal;
- gekoppelde producten;
- checksum;
- vervangende bron.

## Duplicaatdetectie

Vergelijk:

- checksum;
- bestandsnaam;
- documentnummer;
- revisie;
- inhoudssignatuur.

---

# 7.22 Merkenbeheer

## Merkpagina

- logo;
- naam;
- alternatieve schrijfwijzen;
- website als metadata;
- categorieën;
- productseries;
- broncontact;
- fotoafspraken;
- actieve producten;
- verouderde producten.

## Synoniemen

Voor zoekmachine:

- `BORA`;
- `Bora`;
- serienamen;
- veelgebruikte afkortingen.

---

# 8. Embedded project library

De projecteditor bevat geen volledige beheeromgeving, maar een snelle drawer.

## 8.1 Openen

Via:

- knop `Component toevoegen`;
- sneltoets;
- categorieknop;
- command palette.

## 8.2 Layout

```text
┌────────────────────────────────────┐
│ Component toevoegen                │
│ [ Zoek merk, model of maat... ]    │
│                                    │
│ [Kookplaten] [Spoelbakken] [Kraan] │
│                                    │
│ Recent gebruikt                    │
│ [kaart] [kaart]                    │
│                                    │
│ Resultaten                         │
│ [kaart] [kaart]                    │
└────────────────────────────────────┘
```

## 8.3 Contextfiltering

De drawer weet:

- actief materiaal;
- bladdikte;
- projectstatus;
- tenantregels.

Standaard toont hij producten die in de actieve context inzetbaar zijn.

Toggle:

- `Alleen geschikt`;
- `Alles tonen`.

## 8.4 Productkaart in drawer

Compacter dan op de hoofdpagina:

- echte foto;
- merk;
- model;
- kernmaat;
- installatiemethoden;
- verificatie;
- draghandle.

## 8.5 Quick preview

Klik opent kleine popover:

- grotere foto;
- beschikbare installatieopties;
- technische status;
- materiaalcompatibiliteit;
- knop slepen.

---

# 9. Drag-and-dropflow

## 9.1 Begin

De gebruiker pakt een productkaart vast.

De kaart verandert in een dragobject met:

- mini-foto;
- merk/model;
- categorie;
- footprint;
- statusbadge.

## 9.2 Boven het canvas

De engine toont:

- voorlopige componentcontour;
- transparante veiligheidszone;
- 2D-positioneringspreview;
- 3D-apparaatpreview;
- geldige/ongeldige zone;
- mogelijke snaps.

## 9.3 Ongeldige plaatsing

Wanneer het product volledig buiten het blad ligt:

- contour rood;
- duidelijke tekst;
- loslaten plaatst niets.

## 9.4 Voorlopige plaatsing

Na loslaten bestaat het object nog in status:

```text
PLACED_PROVISIONAL
```

Nog niet productieklaar.

## 9.5 Installatieoverlay

Direct daarna verschijnt het capability-aware menu.

## 9.6 Exact positioneren

Na installatiekeuze verschijnt:

- relevante maatlijnen;
- positioneringspaneel;
- referentiekeuzes;
- vergrendelingen.

## 9.7 Commit

Na bevestiging:

- exacte C++-geometrie;
- 2D-update;
- 3D-update;
- validatie;
- componentstatus.

---

# 10. Installatieoverlay

## 10.1 Doel

Een kleine, duidelijke keuze bieden zonder technische overload.

## 10.2 Layout

```text
┌──────────────────────────────────────┐
│ Kies installatiewijze                │
│                                      │
│ [ doorsnede ] Opbouw                 │
│ [ doorsnede ] Vlakinbouw             │
│ [ doorsnede ] Onderbouw              │
│                                      │
│ Modelgegevens: Platform Verified ✓   │
└──────────────────────────────────────┘
```

## 10.3 Capabilityregels

De overlay ontvangt een lijst van de engine:

```json
{
  "availableModes": [
    {
      "mode": "TOP_MOUNT",
      "status": "AVAILABLE"
    },
    {
      "mode": "FLUSH_MOUNT",
      "status": "BLOCKED",
      "reason": "NO_VERIFIED_REBATE_GEOMETRY"
    }
  ]
}
```

## 10.4 Verbergen of grijs tonen

### Volledig irrelevant

Niet tonen.

Voorbeeld: onderbouw bij normale kookplaat.

### Verwacht maar niet beschikbaar

Grijs tonen met reden.

Voorbeeld: spoelbak ondersteunt volgens productfamilie vaak onderbouw, maar deze revisie niet.

## 10.5 Na keuze

- juiste geometry set laden;
- juiste productie-intenties activeren;
- 3D aanpassen;
- materiaalregels draaien;
- positie behouden via componentanker.

---

# 11. Search engine blueprint

# 11.1 Zoekvelden

De index bevat:

- merk;
- model;
- serie;
- artikelnummer;
- EAN;
- categorie;
- subcategorie;
- synoniemen;
- kleur;
- afwerking;
- buitenmaat;
- uitsparingsmaat;
- installatiemethode;
- componenteigenschappen;
- tenanttags;
- collecties;
- verificatiestatus.

## 11.2 Query-interpretatie

Een query wordt ontleed in:

- exacte tokens;
- merk;
- model;
- numerieke maten;
- categorie;
- eigenschappen;
- filters;
- installatieterm;
- kleur;
- artikelnummer.

## 11.3 Voorbeelden

### Query

```text
bora x pure
```

Interpretatie:

- merk BORA;
- modeltokens X Pure.

### Query

```text
onderbouw spoelbak 500 zwart
```

Interpretatie:

- categorie spoelbak;
- installatie onderbouw;
- maat circa 500;
- kleur zwart.

### Query

```text
MTX11050
```

Interpretatie:

- artikelnummer of modelcode;
- normaliseer streepjes en spaties.

## 11.4 Normalisatie

- hoofdletterongevoelig;
- spaties en streepjes normaliseren;
- accenten;
- enkelvoud/meervoud;
- `80 cm` naar `800 mm`;
- `1.5 bak` naar anderhalve bak;
- Nederlandse en Engelse installatietermen.

## 11.5 Synoniemen

Voorbeelden:

```text
opbouw = bovenbouw = top mount
vlakinbouw = flush mount = vlakbouw
onderbouw = undermount
kookplaat = hob = cooktop
spoelbak = sink = wasbak
zeeppomp = soap dispenser
```

## 11.6 Typefouten

Fuzzy matching mag:

- merkspelfouten opvangen;
- modelspelfouten beperkt opvangen;
- artikelnummer nooit agressief wijzigen.

## 11.7 Ranking

Voorgestelde prioriteit:

1. exact artikelnummer;
2. exact merk + model;
3. exact model;
4. prefix merk/model;
5. categorie + exacte kenmerken;
6. synoniemmatch;
7. fuzzy match;
8. populariteit;
9. recency.

## 11.8 Contextboost

Binnen project:

- geschikt materiaal;
- geschikte dikte;
- tenantverified;
- bedrijfsstandaard;
- recent gebruikt.

Maar contextboost mag geen exact model verbergen.

## 11.9 Uitlegbaar resultaat

Optioneel label:

> Match op merk, model en installatiemethode.

---

# 12. Filterblueprint

## 12.1 Facetten

- categorie;
- merk;
- serie;
- installatiemethode;
- verificatiestatus;
- bronstatus;
- materiaalgeschiktheid;
- dikte;
- buitenmaat;
- uitsparingsmaat;
- kleur;
- afwerking;
- tenant/platform;
- collectie;
- actief/verouderd.

## 12.2 Afmetingen

Gebruik slimme rangefilters:

- breedte;
- diepte;
- hoogte;
- gatdiameter;
- bakmaat.

## 12.3 Exact versus ongeveer

Opties:

- exact;
- ±5 mm;
- ±10 mm;
- bereik.

## 12.4 Filterbadges

Actieve filters verschijnen boven resultaten:

```text
Franke ×   Onderbouw ×   Zwart ×   Breedte 480–520 mm ×
```

## 12.5 Resultaattelling

Elke facetoptie toont aantal resultaten.

## 12.6 Incompatibele filters

De UI legt uit waarom nul resultaten ontstaan.

---

# 13. Productkaartdesign

## 13.1 Standaardkaart

```text
┌───────────────────────────────┐
│ [ echte productfoto ]         │
│                               │
│ BORA                          │
│ X Pure                        │
│ Kookplaat · 830 × 515 mm      │
│                               │
│ Opbouw · Vlakinbouw           │
│ Platform Verified ✓           │
└───────────────────────────────┘
```

## 13.2 Kaartlagen

### Visueel

- productfoto;
- rustige achtergrond;
- consistente beeldverhouding.

### Identiteit

- merk;
- model;
- variant.

### Technisch

- kernmaat;
- installatiemethoden;
- status.

### Acties

- favoriet;
- quick view;
- vergelijken;
- draghandle.

## 13.3 Badges

Maximaal twee badges permanent zichtbaar.

Bijvoorbeeld:

- `Platform Verified`;
- `Recent gebruikt`.

Overige status via tooltip of detailpaneel.

## 13.4 Hover

- foto subtiel zoomen;
- kaart verheffen;
- draghandle tonen;
- quick actions tonen.

## 13.5 Geselecteerd

- duidelijke border;
- previewpaneel openen;
- toetsenbordfocus.

## 13.6 Incompatibel binnen project

Kaart blijft eventueel zichtbaar maar:

- gedimd;
- redenlabel;
- slepen geblokkeerd.

---

# 14. Beeldsysteem

## 14.1 Beeldtypes

- hero;
- gallery;
- technical;
- installation;
- underside;
- detail;
- swatch;
- 3D render;
- source image.

## 14.2 Hero-eisen

- minimaal voldoende resolutie;
- object centraal;
- rustige achtergrond;
- geen storende marketingtekst;
- juiste modelvariant;
- geen verwarrende accessoires tenzij duidelijk.

## 14.3 Bronmetadata

Per beeld:

- bron;
- eigenaar;
- gebruiksrecht;
- licentiestatus;
- datum;
- productrevisie;
- checksum;
- goedkeuring.

## 14.4 Beeldverwerking

- automatische thumbnails;
- webformaten;
- achtergrondnormalisatie;
- veilige crop;
- geen vervorming;
- kleurprofiel;
- lazy loading.

## 14.5 Rechtenstatus

- approved;
- tenant provided;
- manufacturer approved;
- internal only;
- restricted;
- expired;
- unknown.

Beelden met onbekende rechten mogen niet platformbreed worden gepubliceerd.

## 14.6 Fallback

Wanneer geen echte foto beschikbaar is:

1. officiële technische afbeelding;
2. neutrale 3D-render;
3. categorieplaceholder.

Nooit een willekeurig vergelijkbaar product tonen.

---

# 15. Productdata- en componentmodel

## 15.1 ProductModel

```json
{
  "id": "prod_123",
  "brandId": "brand_franke",
  "name": "Mythos MTX 110-50",
  "series": "Mythos",
  "category": "SINK",
  "articleNumber": "123456",
  "ean": "0000000000000",
  "activeRevisionId": "rev_7",
  "visibility": "PLATFORM",
  "status": "ACTIVE"
}
```

## 15.2 ProductRevision

```json
{
  "id": "rev_7",
  "productId": "prod_123",
  "revisionLabel": "2026-02",
  "variant": "Black",
  "overallDimensionsMm": {
    "width": 540,
    "depth": 440,
    "height": 200
  },
  "verificationStatus": "PLATFORM_VERIFIED",
  "lifecycleStatus": "ACTIVE"
}
```

## 15.3 InstallationCapability

```json
{
  "id": "cap_1",
  "revisionId": "rev_7",
  "mode": "UNDERMOUNT",
  "status": "VERIFIED",
  "geometrySetId": "geom_undermount_4",
  "conditions": {
    "minimumThicknessMm": 12,
    "allowedMaterialGroups": [
      "COMPOSITE",
      "SOLID_SURFACE",
      "NATURAL_STONE"
    ]
  }
}
```

## 15.4 GeometrySet

```json
{
  "id": "geom_undermount_4",
  "datumPoint": {
    "type": "MANUFACTURER_DATUM",
    "x": 0,
    "y": 0
  },
  "features": [
    {
      "type": "INNER_THROUGH_CUT",
      "geometryId": "poly_1"
    },
    {
      "type": "MOUNTING_ZONE",
      "geometryId": "poly_2"
    }
  ],
  "revealModes": [
    "ZERO_REVEAL",
    "POSITIVE_REVEAL"
  ]
}
```

## 15.5 ProductImage

```json
{
  "id": "img_1",
  "revisionId": "rev_7",
  "type": "HERO",
  "storageKey": "products/...",
  "sourceId": "src_12",
  "rightsStatus": "MANUFACTURER_APPROVED",
  "sortOrder": 1
}
```

## 15.6 SourceRecord

```json
{
  "id": "src_12",
  "type": "MANUFACTURER_DRAWING",
  "title": "Installation drawing",
  "documentRevision": "2026-02",
  "pageReference": "14",
  "verificationStatus": "HUMAN_CHECKED"
}
```

---

# 16. Verification model

## 16.1 Statussen

### Candidate

Data ingevoerd maar niet technisch gecontroleerd.

### Document Extracted

Waarden uit bron gehaald, mogelijk met AI, nog niet gecontroleerd.

### Human Checked

Een mens heeft bron en waarden vergeleken.

### Tenant Verified

Door de tenant goedgekeurd voor eigen productie.

### Platform Verified

Platformbreed gecontroleerd en gepubliceerd.

### Superseded

Nieuwe revisie vervangt deze revisie.

### Blocked

Niet gebruiken voor nieuwe productie.

## 16.2 Status per waarde

Niet alleen het hele product, maar ook kritieke velden krijgen status.

Voorbeeld:

```text
Doorfreescontour: Platform Verified
Sponningdiepte: Human Checked
Onderbouwmontage: Niet beschikbaar
Productfoto: Manufacturer Approved
```

## 16.3 Productieklaarheidsregel

Een installatiemethode is alleen productieklaar wanneer alle daarvoor kritieke velden voldoende status hebben.

## 16.4 Geen gemiddelde score

Geen misleidende `89% verified`.

Wel:

- 8 vereiste velden geldig;
- 1 kritisch veld ontbreekt;
- vlakinbouw geblokkeerd.

---

# 17. Technische geometry sets

## 17.1 Kookplaat opbouw

- apparaatbuitenmaat;
- doorfreescontour;
- tolerantie;
- hoekradius;
- servicezone;
- installatievolume.

## 17.2 Kookplaat vlakinbouw

- apparaatbuitenmaat;
- sponningcontour;
- doorfreescontour;
- sponningdiepte;
- speling;
- minimum resterende dikte;
- radius;
- servicevolume.

## 17.3 Spoelbak opbouw

- buitenrand;
- doorfreescontour;
- tolerantie;
- montagerand;
- veiligheidszone.

## 17.4 Spoelbak vlakinbouw

- sponningcontour;
- doorfreescontour;
- diepte;
- speling;
- radius;
- montagezone.

## 17.5 Spoelbak onderbouw

- zichtopening;
- spoelbakreferentie;
- reveal;
- afwerkingsrand;
- montagezone;
- bevestigingsgaten of pockets;
- veiligheidszone.

## 17.6 Kraan

- boorgat;
- montagevoet;
- eventuele tweede bediening;
- onderruimte;
- draaibereik optioneel.

---

# 18. Materiaalcompatibiliteit

## 18.1 Evaluatie

```text
Component Capability
× Material Revision
× Worktop Thickness
× Tenant Production Standard
= Available / Warning / Blocked
```

## 18.2 Voorbeeld

Een spoelbak ondersteunt onderbouw:

- producttechnisch: ja;
- gekozen HPL-profiel: nee;
- resultaat: geblokkeerd.

## 18.3 Overlayuitleg

> Onderbouw wordt door het product ondersteund, maar is niet toegestaan voor materiaalprofiel HPL 38 mm.

---

# 19. Projectplaatsing en componentstatus

## 19.1 Statussen

- `UNPLACED`;
- `PLACED_PROVISIONAL`;
- `INSTALLATION_SELECTED`;
- `POSITION_INCOMPLETE`;
- `EXACT_POSITIONED`;
- `VALIDATION_REQUIRED`;
- `MANUFACTURABLE`;
- `BLOCKED`.

## 19.2 Vereisten exact positioneren

- horizontale constraint;
- verticale constraint;
- rotatie;
- componentanker;
- installatiemethode;
- geometry set.

## 19.3 Bij productrevisiewijziging

Het systeem vergelijkt oude en nieuwe geometry set.

Mogelijke uitkomst:

- geen productie-impact;
- herberekening vereist;
- positie blijft geldig;
- randafstand is ongeldig geworden;
- handmatige review vereist.

---

# 20. Keyboard en desktopinteractie

## Library

- `/` focust zoekbalk;
- pijltjestoetsen navigeren kaarten;
- Enter opent quick preview;
- Ctrl/Cmd + Enter opent detail;
- `F` favoriet;
- `C` vergelijken;
- Escape sluit paneel.

## Drag

- muis slepen;
- Alt schakelt snaps tijdelijk uit;
- Escape annuleert;
- Enter bevestigt keuze;
- Tab navigeert installatieopties.

## Toegankelijkheid

- kaarten toetsenbordtoegankelijk;
- duidelijke focusring;
- alt-tekst;
- tekst naast kleur;
- screenreaderlabels;
- voldoende contrast.

---

# 21. Loading, empty en error states

## 21.1 Loading

Gebruik skeletonkaarten met vaste afmetingen.

## 21.2 Afbeelding laadt niet

- technische fallback;
- categorieplaceholder;
- geen layoutverspringing.

## 21.3 Geen resultaten

Toon:

- actieve zoekinterpretatie;
- filters wissen;
- vergelijkbare resultaten;
- nieuw component aanvragen;
- bron uploaden.

## 21.4 Productdata tijdelijk niet beschikbaar

Geen plaatsing toestaan wanneer kritieke data niet geladen of gevalideerd is.

## 21.5 Verouderde revisie

Waarschuw duidelijk:

> Dit product is vervangen door revisie 2026-04.

---

# 22. Search- en data-infrastructuur

## 22.1 Index

Aanbevolen aparte zoekindex met:

- normalized text;
- exact identifiers;
- dimensions;
- facets;
- synonyms;
- tenantvisibility;
- verification;
- compatibility hints.

## 22.2 Tenantisolatie

Een gebruiker ziet:

- platformproducten;
- eigen tenantproducten;
- gedeelde producten waarvoor rechten bestaan.

Nooit componenten van andere tenants.

## 22.3 Caching

- afbeeldingen via CDN/object storage;
- zoekresultaten kort cachen;
- projectcompatibiliteit lokaal cachen;
- revisie-invalidation.

## 22.4 Indexupdates

Bij publicatie of revisiewijziging:

- nieuwe indexversie;
- atomische switch;
- geen half bijgewerkte resultaten.

---

# 23. API-contracten

## 23.1 Zoeken

```json
POST /api/library/search
{
  "query": "franke onderbouw 500 zwart",
  "filters": {
    "category": ["SINK"],
    "installationMode": ["UNDERMOUNT"]
  },
  "projectContext": {
    "materialRevisionId": "mat_12",
    "thicknessMm": 20
  },
  "page": 1,
  "pageSize": 30
}
```

## 23.2 Resultaat

```json
{
  "interpretedQuery": {
    "brand": "Franke",
    "category": "SINK",
    "installationMode": "UNDERMOUNT",
    "dimensionApproxMm": 500,
    "color": "black"
  },
  "results": [],
  "facets": {},
  "total": 24
}
```

## 23.3 Capability check

```json
POST /api/library/revisions/rev_7/capabilities
{
  "materialRevisionId": "mat_12",
  "thicknessMm": 20,
  "tenantStandardId": "std_3"
}
```

## 23.4 Plaatsing voorbereiden

```json
POST /api/projects/prj_1/components/prepare
{
  "productRevisionId": "rev_7",
  "approximatePosition": {
    "xMm": 1200,
    "yMm": 300
  }
}
```

## 23.5 Resultaat

```json
{
  "placementToken": "tmp_123",
  "availableInstallationModes": [],
  "previewGeometry": {},
  "warnings": []
}
```

---

# 24. Audit en lifecycle

## Audititems

- product aangemaakt;
- foto toegevoegd;
- bron toegevoegd;
- geometry gewijzigd;
- capability gewijzigd;
- verificatiestatus gewijzigd;
- product geplaatst;
- productrevisie gemigreerd;
- product geblokkeerd;
- foto-rechten gewijzigd.

## Immutable publicatie

Een gepubliceerde revisie wordt niet stil aangepast.

Correctie:

- nieuwe revisie;
- of expliciete terugtrekking.

---

# 25. Analytics

## Productmetrics

- zoekfrequentie;
- geen-resultaatqueries;
- meest bekeken;
- meest geplaatst;
- plaatsing per installatiemethode;
- drop-off na quick preview;
- incompatibiliteitsredenen;
- ontbrekende producten;
- revisiemigraties.

## Privacy

Gebruik analytics voor productverbetering zonder onnodige klantinhoud te verzamelen.

## Belangrijke inzichten

- welke merken ontbreken;
- welke modellen vaak worden gezocht;
- welke producten vaak blokkeren;
- welke filters weinig opleveren;
- welke componenten vaak custom worden aangemaakt.

---

# 26. SaaS- en pakketlogica

## Designer

- platformlibrary;
- zoeken;
- foto’s;
- geverifieerde producten;
- favorieten;
- drag-and-drop.

## Production

- technische detaildata;
- tenantcollecties;
- custom componenten;
- bronviewer;
- tenant verification.

## Factory

- private catalogus;
- bulkimport;
- reviewworkflow;
- meerdere locaties;
- leveranciersfeeds;
- uitgebreide rechten.

## Enterprise

- private manufacturer feeds;
- custom datamodellen;
- SLA;
- dedicated verificatie;
- leveranciersportal.

---

# 27. MVP-afbakening

## Wel in eerste sterke versie

- visuele productgrid;
- echte foto’s;
- slimme zoekbalk;
- categorieën;
- merkfilter;
- installatiemethodefilter;
- verificatiefilter;
- productkaart;
- quick preview;
- productdetail;
- favorieten;
- recent gebruikt;
- projectdrawer;
- drag-and-drop;
- capability-aware installatieoverlay;
- materiaal- en diktecheck;
- platform- en tenantverified status;
- eigen componentwizard;
- bronbestanden;
- revisioneerbaar datamodel.

## Later

- vergelijkfunctie;
- bedrijfscollecties;
- leveranciersfeeds;
- uitgebreide AI-extractie;
- automatische productfamiliekoppeling;
- fabrikantportal;
- productupdatefeed;
- visuele similarity search;
- barcode/EAN-scan;
- meertalige catalogus.

---

# 28. Acceptatiecriteria MVP

De module is pas gereed voor pilot wanneer:

1. een gebruiker een exact model op merk en model kan vinden;  
2. een artikelnummermatch boven algemene resultaten staat;  
3. echte foto en technische data duidelijk gescheiden zijn;  
4. alleen geldige installatiemethoden worden aangeboden;  
5. materiaal- en dikteblokkades correct worden getoond;  
6. drag-and-drop een intelligent componentobject plaatst;  
7. de installatieoverlay direct na loslaten verschijnt;  
8. de juiste geometry set in 2D en 3D zichtbaar wordt;  
9. kandidaatproducten productie-export blokkeren;  
10. bron en revisie per kritisch veld traceerbaar zijn;  
11. tenantdata volledig geïsoleerd blijft;  
12. productrevisies reproduceerbaar blijven;  
13. een ontbrekend model veilig als tenantcomponent kan worden toegevoegd;  
14. zoeken, filteren en slepen zonder merkbare vertraging werken;  
15. foto’s consistent, scherp en zonder layoutverspringing laden.

---

# 29. Voorbeeldflow — kookplaat

1. Gebruiker opent projectdrawer.  
2. Typt `BORA X Pure`.  
3. Ziet echte foto, 830 × 515 mm, opbouw en vlakinbouw.  
4. Product is Platform Verified.  
5. Gebruiker sleept kaart naar het blad.  
6. 2D toont footprint; 3D toont transparant apparaat.  
7. Na loslaten verschijnt overlay:
   - Opbouw;
   - Vlakinbouw.
8. Gebruiker kiest vlakinbouw.  
9. C++-engine laadt doorfrees- en sponningcontour.  
10. 3D toont de vlakke inbouw.  
11. Exacte maatpositionering verschijnt.  
12. Materiaal- en dikteregels worden gecontroleerd.  
13. Component krijgt status `EXACT_POSITIONED` en daarna `MANUFACTURABLE`.

---

# 30. Voorbeeldflow — spoelbak

1. Gebruiker zoekt `Franke Mythos 500 onderbouw zwart`.  
2. Zoekmachine interpreteert merk, serie, maat, kleur en installatie.  
3. Resultaten tonen echte productfoto’s.  
4. Gebruiker opent quick preview.  
5. Onderbouw is beschikbaar; vlakinbouw niet.  
6. Gebruiker sleept het product naar het blad.  
7. Overlay toont:
   - Onderbouw;
   - eventueel andere geverifieerde methoden.
8. Gebruiker kiest onderbouw.  
9. Systeem vraagt reveal:
   - zero;
   - positive;
   - alleen wanneer productdata dit ondersteunt.
10. Zichtopening, montagezone en 3D-bak worden zichtbaar.  
11. Exacte positionering volgt.  
12. Materiaalprofiel controleert minimale afstand en onderbouwgeschiktheid.

---

# 31. Voorbeeldflow — ontbrekend product

1. Gebruiker zoekt exact model.  
2. Geen resultaten.  
3. Systeem toont:
   - vergelijkbare producten;
   - filters resetten;
   - `Nieuw component aanmaken`.
4. Gebruiker uploadt officiële PDF en DXF.  
5. Product krijgt status Candidate.  
6. AI mag kandidaatvelden voorstellen.  
7. Component Manager controleert contour, diepte en bron.  
8. Product wordt Tenant Verified.  
9. Daarna kan het binnen de tenant productief worden gebruikt.

---

# 32. Definitieve UX-regels

1. De echte productfoto is altijd herkenningsmiddel, nooit productiebron op zichzelf.  
2. Productkaarten blijven rustig en tonen alleen kerninformatie.  
3. Technische diepte zit één klik verder.  
4. Exact artikelnummer gaat vóór populariteit.  
5. Zoekresultaten zijn contextbewust maar niet misleidend.  
6. Drag-and-drop moet vanaf hoofdgrid en projectdrawer werken.  
7. Installatieopties komen uitsluitend uit geverifieerde capabilities.  
8. Onderbouw wordt bij normale kookplaten niet aangeboden.  
9. Ongeldige opties krijgen een concrete reden.  
10. Een productrevisie mag niet stil wijzigen.  
11. Iedere kritieke waarde heeft provenance.  
12. Een candidate mag geen productie-export mogelijk maken.  
13. Een foto zonder bekende rechten mag niet platformbreed worden gepubliceerd.  
14. Een ontbrekend product moet veilig als tenantcomponent toegevoegd kunnen worden.  
15. De library moet visueel premium voelen én technisch streng blijven.

---

# 33. Eindvisie

De Product Library wordt de plaats waar commerciële productherkenning en productie-intelligentie samenkomen.

De gebruiker ervaart:

- echte productfoto’s;
- snelle visuele herkenning;
- slimme zoekresultaten;
- betrouwbare technische status;
- eenvoudige drag-and-drop;
- relevante installatiekeuzes;
- directe 2D/3D-feedback.

De fabrikant krijgt:

- herbruikbare componentkennis;
- minder zoekwerk;
- minder verkeerde modellen;
- minder handmatige uitsparingstekeningen;
- revisioneerbare brondata;
- consistente productiegeometrie;
- tenant- en platformverificatie;
- volledige audit.

De module wordt daarmee niet slechts een catalogus, maar een **Component Intelligence Platform** binnen Worktop OS:

> **Visueel als een premium productcatalogus, intelligent als een zoekmachine en streng als een productiedatabase.**
