# MASTER BLUEPRINT — WORKTOP OS

**Documentstatus:** Definitieve product- en architectuurrichting  
**Versie:** 1.0  
**Doel:** Volledige master blueprint voor een desktop-first B2B SaaS-platform voor het ontwerpen, valideren, visualiseren, optimaliseren en exporteren van CNC-werkbladen  
**Kern:** Slimme parametrische werkbladsoftware met een autoritatieve C++-engine, live 2D/3D, een waarheidsgestuurde componentenbibliotheek, exacte positionering, materiaal- en nerflogica, DXF-nesting en machineprofielen  
**Belangrijkste scopebeslissing:** Het product maakt en produceert **werkbladen**. Het is geen keukenplanner, geen kastensysteem en geen generieke CAD-applicatie.

---

# 1. Executive summary

Worktop OS wordt een gespecialiseerd productieplatform waarmee een werkvoorbereider, tekenaar, inmeter of fabrikant een werkbladorder kan omzetten naar een gecontroleerd en machineklaar productiepakket.

De gebruiker hoeft geen traditioneel CAD-programma te beheersen. In plaats daarvan bouwt hij een werkblad via:

- slimme parametrische vormen;
- maatgestuurde segmenten;
- gecontroleerde rondingen;
- DXF-import;
- drag-and-dropcomponenten;
- exacte maatrelaties;
- gevalideerde installatiewijzen;
- live gekoppelde 2D- en 3D-weergave;
- automatische productiechecks;
- C++-gebaseerde nesting en optimalisatie;
- configureerbare DXF-layer- en machineprofielen.

Het systeem moet voelen als een moderne, visuele configurator, maar onder de motorkap werken als een streng productiesysteem.

De kernbelofte luidt:

> **Wat de gebruiker opbouwt, valideert en in 3D ziet, komt uit exact hetzelfde autoritatieve productiemodel als de uiteindelijke DXF-export en nesting.**

Er bestaan dus geen losse, mogelijk afwijkende 2D-, 3D- en exportmodellen.

---

# 2. Vastgezette productscope

## 2.1 Wat Worktop OS wél is

Worktop OS is een desktop-first SaaS-platform voor:

- werkbladorders;
- werkbladvormen;
- gaten en uitsparingen;
- spoelbakken;
- kookplaten;
- kranen;
- zeeppompjes;
- stopcontactunits;
- afvoergaten;
- sponningen;
- pockets;
- boorbewerkingen;
- zichtzijden;
- randen en profielen;
- verstek- en opgedikte randen;
- naden en deelverbindingen;
- materiaaleigenschappen;
- plaatvoorraad;
- restplaten;
- nerfrichting;
- doorlopende nerf;
- unieke plaatfoto’s en aderpositionering;
- DXF-import en -export;
- productietechnische validatie;
- nesting en plaatoptimalisatie;
- klanttekeningen;
- productiebladen;
- machine- en layerprofielen;
- component- en bronverificatie;
- productiehistorie en audit.

## 2.2 Wat Worktop OS nadrukkelijk niet is

Het systeem is geen:

- keukenplanner;
- kastconfigurator;
- interieurplanner;
- meubelontwerper;
- keukenoffertetool;
- generiek CAD-pakket;
- onbeperkte vrije tekenapp;
- directe universele G-codegenerator voor iedere machine;
- automatisch waarheidsorgaan voor fabrikantdata;
- AI-systeem dat onbekende uitsparingsmaten gokt.

Er worden geen keukenmeubels, laden, kasten of corpusconstructies gemodelleerd. Positionering gebeurt uitsluitend ten opzichte van het werkblad, werkbladsegmenten, naden, referentiepunten, referentielijnen en andere werkbladcomponenten.

---

# 3. Productprincipes

## 3.1 Easy outside, strict inside

De interface moet eenvoudig, visueel en voorspelbaar voelen. De kernengine moet streng, deterministisch en productiegericht zijn.

## 3.2 Geen traditioneel CAD als primaire UX

De gebruiker kiest:

- vormtype;
- zijde;
- hoektype;
- radius;
- maatrelatie;
- installatiemethode;
- component;
- materiaal;
- afwerking.

Hij hoeft niet primair te werken met:

- losse lijnen;
- trimcommando’s;
- verlengen;
- offsetten;
- filletcommando’s;
- polylijnen repareren;
- handmatige layers.

Een geavanceerde expertmodus mag later beperkt meer vrijheid bieden, maar blijft ondergeschikt aan het slimme parametrische model.

## 3.3 Eén autoritatief model

Alle functies gebruiken één `Canonical Worktop Model`.

```text
Gebruikersinvoer
      ↓
C++ Geometry & Constraint Core
      ↓
Canonical Worktop Model
 ┌────┼────────┬──────────┬────────────┐
 ↓    ↓        ↓          ↓            ↓
2D   3D    Validatie   Nesting      DXF-output
```

## 3.4 Fail-closed

Wanneer de C++-engine niet correct beschikbaar is:

- geen productie-export;
- geen stille JavaScript- of Python-fallback;
- duidelijke foutstatus;
- orderdata blijft bewaard;
- diagnose en herstelactie worden getoond.

## 3.5 Truth-first componentdata

Een component is alleen productieklaar wanneer:

- het exacte merk en model bekend zijn;
- de revisie bekend is;
- de installatiemethode wordt ondersteund;
- de geometrie geverifieerd is;
- dieptes en toleranties bekend zijn;
- materiaalvoorwaarden bekend zijn;
- herkomst en bron traceerbaar zijn.

## 3.6 Visuele eenvoud zonder schijnzekerheid

De software mag makkelijk voelen, maar mag ontbrekende informatie nooit verbergen of invullen alsof die zeker is.

---

# 4. Doelgroepen

## 4.1 Primaire doelgroepen

- keukenbladfabrikanten;
- interieurbouwers met eigen CNC-productie;
- solid-surfaceverwerkers;
- compacte plaat- en HPL-verwerkers;
- composiet- en steenverwerkers in latere productfases;
- werkvoorbereiders;
- technische tekenaars;
- inmeters;
- productieplanners.

## 4.2 Primaire gebruiker

De belangrijkste gebruiker is de werkvoorbereider die:

- meetgegevens ontvangt;
- bladvormen controleert;
- apparatuur plaatst;
- productieregels bewaakt;
- DXF-bestanden maakt;
- plaatgebruik optimaliseert;
- productie vrijgeeft.

## 4.3 Secundaire rollen

- inmeter;
- verkoper met beperkte rechten;
- productieoperator;
- kwaliteitscontroleur;
- tenantbeheerder;
- componentdatabeheerder;
- machineprofielbeheerder;
- platformbeheerder.

---

# 5. End-to-end hoofdworkflow

## Stap 1 — Project starten

De gebruiker kiest:

- nieuw leeg project;
- slimme vormtemplate;
- DXF importeren;
- bestaand project dupliceren;
- project vanuit API/ERP ontvangen.

## Stap 2 — Projectgegevens

- projectnaam;
- ordernummer;
- klantreferentie;
- interne notitie;
- gewenste leverdatum;
- materiaal;
- dikte;
- eenheid;
- standaard machineprofiel;
- standaard toleranties.

## Stap 3 — Werkbladonderdelen opbouwen

De gebruiker kan één of meerdere werkbladonderdelen maken via:

- rechthoek;
- L-vorm;
- U-vorm;
- eiland;
- trapezium;
- D-vorm;
- capsule;
- cirkel;
- ellips;
- halfovaal;
- vorm met schuine zijde;
- vorm met insprong;
- gecontroleerde segmentenroute;
- DXF-import.

## Stap 4 — Zijden en geometrie classificeren

Iedere zijde krijgt betekenis:

- voorzijde;
- achterzijde;
- linkerzijde;
- rechterzijde;
- muurzijde;
- zichtzijde;
- naadzijde;
- gekoppelde zijde;
- ruwe zijde;
- gepolijste zijde;
- verstekzijde;
- profielzijde.

## Stap 5 — Componenten toevoegen

Via drag-and-drop:

- spoelbak;
- kookplaat;
- kraan;
- zeeppomp;
- afvoergat;
- stopcontact;
- dispenser;
- eigen component;
- vrije productiefeature.

## Stap 6 — Installatiemethode kiezen

Direct na plaatsing verschijnt een contextoverlay met uitsluitend ondersteunde opties.

Voor kookplaten:

- opbouw;
- vlakinbouw;
- onderbouw niet tonen binnen de normale scope.

Voor spoelbakken:

- opbouw;
- vlakinbouw;
- onderbouw.

De beschikbare opties komen uit het exacte componentmodel, de componentrevisie, het materiaalprofiel en de werkbladdikte.

## Stap 7 — Exact positioneren

Drag-and-drop geeft een voorlopige positie. Daarna legt de gebruiker de productiepositie vast met maatrelaties.

Voorbeelden:

- midden uitsparing gecentreerd in werkblad;
- voorzijde uitsparing 65 mm vanaf voorzijde;
- midden uitsparing 1.420 mm vanaf linkerzijde;
- 180 mm vanaf een naad;
- uitlijnen op een andere uitsparing;
- symmetrisch tussen twee zijden;
- positie ten opzichte van een eigen referentielijn.

## Stap 8 — Live 2D/3D controleren

De 2D-editor en 3D-viewer zijn volledig gekoppeld.

De gebruiker ziet:

- echte werkbladdikte;
- doorlopende gaten;
- sponningen;
- pockets;
- boorgaten;
- randprofielen;
- zichtzijden;
- componentvolume;
- materiaal en nerfrichting;
- veiligheidszones;
- eventuele conflicten.

## Stap 9 — Productievalidatie

De engine controleert:

- gesloten contouren;
- zelfsnijdingen;
- te kleine segmenten;
- minimale radii;
- freesbaarheid;
- randafstanden;
- materiaalbruggen;
- dieptes;
- resterende materiaaldikte;
- componentconflicten;
- naadafstanden;
- installatiemethode;
- gegevensstatus;
- machineprofielcompatibiliteit.

## Stap 10 — Plaatselectie en nesting

De gebruiker kiest:

- volledige plaat;
- restplaat;
- unieke slab;
- batch;
- plaatfoto;
- defectzones;
- nerfmodus;
- rotatiemogelijkheden;
- doorlopende nerfgroepen.

De C++-solver maakt meerdere optimalisatieresultaten.

## Stap 11 — Productiecontrole

De gebruiker vergelijkt:

- materiaalbenutting;
- aantal platen;
- reststukken;
- geschatte machinetijd;
- gereedschapswissels;
- nerfcontinuïteit;
- risico’s;
- waarschuwingen;
- plaatpositie.

## Stap 12 — Vrijgeven en exporteren

Uitvoer kan bevatten:

- machine-DXF per onderdeel;
- nesting-DXF;
- klantmaat-PDF;
- productieblad;
- materiaaloverzicht;
- componentenlijst;
- validatierapport;
- project-JSON;
- engine-manifest;
- previews;
- checksums.

---

# 6. Informatiearchitectuur en hoofdnavigatie

De applicatie is desktop-only en gebruikt een vaste linkerzijbalk.

## Hoofdnavigatie

1. Dashboard  
2. Projecten  
3. Componentenbibliotheek  
4. Materialen & platen  
5. Restplaten  
6. Machineprofielen  
7. Layer mapping  
8. Productiestandaarden  
9. Exporthistorie  
10. Team & rollen  
11. Organisatie-instellingen  
12. Auditlog  
13. Help & onboarding  

## Binnen een project

1. Projectoverzicht  
2. Werkblad bouwen  
3. Componenten  
4. Randen & verbindingen  
5. 3D-controle  
6. Productiechecks  
7. Plaat & nesting  
8. Export  

De gebruiker hoeft niet iedere stap lineair te volgen, maar de statusbalk toont wel welke stappen gereed zijn.

---

# 7. Pagina-voor-pagina UX-blueprint

# 7.1 Login en tenantselectie

## Doel

Veilige toegang tot de juiste organisatie.

## Elementen

- logo;
- e-mail;
- wachtwoord of SSO;
- tenantselectie wanneer gebruiker meerdere organisaties heeft;
- recente organisatie;
- statusmeldingen;
- vergeten wachtwoord;
- supportlink.

## Regels

- geen productiegegevens buiten eigen tenant;
- laatste tenant onthouden;
- MFA voor beheerders en productie-vrijgevers optioneel verplicht.

---

# 7.2 Dashboard

## Doel

Direct overzicht van werk, blokkades en productie.

## Bovenste kaarten

- open projecten;
- wacht op controle;
- geblokkeerd;
- gereed voor productie;
- deze maand geëxporteerd;
- actieve engineversie.

## Hoofdsecties

### Recente projecten

Per kaart:

- ordernummer;
- projectnaam;
- klant;
- materiaal;
- laatst gewijzigd;
- status;
- gebruiker;
- miniatuur van werkblad;
- waarschuwingsteller.

### Acties

- nieuw project;
- DXF importeren;
- project zoeken;
- productieblokkades openen;
- laatst gebruikt project hervatten.

### Systeemstatus

- C++-engine online;
- WebAssembly-preview beschikbaar;
- machineprofielen geldig;
- componentupdates;
- geplande onderhoudsmelding.

---

# 7.3 Projectenoverzicht

## Functies

- tabel- en kaartweergave;
- zoeken;
- filteren;
- sorteren;
- favorieten;
- archiveren;
- dupliceren;
- versies vergelijken;
- exporthistorie;
- bulkstatus.

## Kolommen

- order;
- project;
- klantreferentie;
- materiaal;
- onderdelen;
- status;
- waarschuwingen;
- laatst gewijzigd;
- eigenaar;
- productievrijgave;
- exportversie.

## Statusfilters

- concept;
- geometrie geldig;
- controle vereist;
- geblokkeerd;
- klant akkoord;
- productievrijgegeven;
- geëxporteerd;
- gearchiveerd.

---

# 7.4 Nieuw project

## Startkeuzes

- leeg project;
- template;
- DXF importeren;
- project dupliceren;
- ERP/API-order.

## Rechterpaneel

- projectnaam;
- ordernummer;
- klantreferentie;
- materiaal;
- dikte;
- eenheid;
- machineprofiel;
- standaard productieregels.

## Templatecategorieën

- recht blad;
- L-vorm;
- U-vorm;
- eiland;
- D-vorm;
- capsule;
- rond;
- ellips;
- schuin;
- vrije segmentroute.

---

# 7.5 DXF-importwizard

## Fase 1 — Bestand

- drag-and-dropbestand;
- bestandsinfo;
- eenheiddetectie;
- schaalcontrole;
- layeroverzicht.

## Fase 2 — Geometrische analyse

Toont:

- open contouren;
- dubbele lijnen;
- overlappende lijnen;
- microsegmenten;
- onlogische bogen;
- zelfsnijdingen;
- losse tekst;
- maatvoering;
- onbekende blokken.

## Fase 3 — Interpretatie

De gebruiker wijst toe:

- buitencontour;
- uitsparing;
- boorgat;
- referentielijn;
- tekst;
- negeren.

## Fase 4 — Opschoning

Voorstel met vergelijking:

- origineel;
- gerepareerd;
- verschillen gemarkeerd.

## Fase 5 — Bevestiging

De gebruiker accepteert of corrigeert de interpretatie.

## Belangrijke regel

Importreparaties moeten volledig traceerbaar blijven. De software mag geen kritieke vormwijziging stil uitvoeren.

---

# 7.6 Werkbladeditor — hoofdscherm

## Layout

```text
┌────────────────────────────────────────────────────────────────────────────┐
│ Project | Materiaal | Status | Undo/Redo | 2D/3D | Opslaan | Vrijgeven   │
├──────────────┬──────────────────────────────────────────┬─────────────────┤
│ Bouwen       │                                          │ Eigenschappen   │
│              │             Hoofdcanvas                  │                 │
│ Vorm         │                                          │ Selectie        │
│ Componenten  │                                          │ Maten           │
│ Randen       │                                          │ Relaties        │
│ Naden        │                                          │ Bewerking       │
│ Referenties  │                                          │ Validatie       │
├──────────────┴──────────────────────────────────────────┴─────────────────┤
│ Statusbalk: geometrie | componenten | materiaal | productie | export      │
└────────────────────────────────────────────────────────────────────────────┘
```

## Werkmodi

- 2D;
- 3D;
- gesplitst;
- productie;
- veiligheid;
- maatvoering;
- nestingpreview.

## Selectiegedrag

- klik op blad: werkbladeigenschappen;
- klik op zijde: rand- en zijde-eigenschappen;
- klik op hoek: hoektype en radius;
- klik op component: positie, installatie en bewerking;
- klik op naad: verbindingseigenschappen;
- klik op maatlijn: direct numeriek aanpassen.

---

# 7.7 Smart Shape Builder

## Doel

Complexe vormen maken zonder traditioneel CAD.

## Vormtemplates

- rechthoek;
- L;
- U;
- trapezium;
- afgeschuinde hoek;
- afgeronde hoek;
- D-vorm;
- halfrond;
- capsule;
- cirkel;
- ellips;
- boogfront;
- vrije segmentvorm.

## Segmenttypen

- rechte zijde;
- schuine zijde;
- binnenhoek;
- buitenhoek;
- binnenboog;
- buitenboog;
- tangentboog;
- ronde kop;
- insprong;
- afschuining;
- fillet;
- gecontroleerde curve.

## Ronde invoermethoden

### Radius

- radius;
- begin- en eindpunt;
- binnen/buiten.

### Koorde en pijlmaat

- koordelengte;
- maximale pijl;
- richting.

### Driepuntsboog

- begin;
- midden;
- eind.

### Halfrond

- automatisch gekoppeld aan breedte.

### Ellips

- totale lengte;
- totale breedte;
- uitsnede.

## Schaalgedrag

Elke vormrelatie kan worden ingesteld als:

- vaste maat;
- gekoppelde maat;
- verhouding;
- gecentreerd;
- symmetrisch;
- tangent;
- gelijk aan andere zijde.

## Voorbeeld

Bij een capsule:

- lengte 2.600 mm;
- breedte 1.000 mm;
- koppen automatisch R500;
- bij breedtewijziging worden koppen opnieuw berekend.

---

# 7.8 Zijde- en randeditor

## Zijdefunctie

- voorzijde;
- achterzijde;
- links;
- rechts;
- muurzijde;
- zichtzijde;
- naad;
- koppeling;
- ruwe zijde;
- afgewerkte zijde.

## Afwerkingen

- recht;
- facet;
- R2;
- R5;
- volledig rond;
- afschuining;
- verstek;
- opgedikt;
- waterkering;
- materiaalafhankelijk profiel;
- custom profiel.

## 3D-koppeling

Elke wijziging wordt direct in 3D weergegeven.

## Productiegevolgen

De engine genereert:

- extra materiaal;
- stroken;
- profielbewerkingen;
- zaag- of freesintenties;
- zichtzijde-informatie;
- nestingrelaties.

---

# 7.9 Componentenbibliotheek

## Hoofdcategorieën

- kookplaten;
- spoelbakken;
- kranen;
- zeeppompen;
- dispensers;
- afvoeren;
- stopcontacten;
- speciale uitsparingen;
- eigen componenten.

## Filters

- merk;
- model;
- categorie;
- installatiemethode;
- materiaalgeschiktheid;
- diktegeschiktheid;
- verificatiestatus;
- revisie;
- laatst bijgewerkt.

## Componentkaart

- afbeelding;
- merk;
- model;
- artikelnummer;
- afmetingen;
- ondersteunde installatiemethoden;
- verificatiestatus;
- bronstatus;
- favoriet;
- laatst gebruikt.

## Verificatiebadges

- Platform Verified;
- Tenant Verified;
- Human Checked;
- Candidate;
- Superseded;
- Blocked.

## Drag-and-drop

Alleen componenten met voldoende gegevens kunnen direct productief worden gebruikt. Kandidaten kunnen eventueel in een niet-productieve ontwerpstatus worden geplaatst, maar blokkeren export.

---

# 7.10 Installatie-overlay na drag-and-drop

## Gedrag

Na loslaten verschijnt een compact menu direct naast het component.

## Kookplaat

Mogelijke opties:

- opbouw;
- vlakinbouw.

Onderbouw wordt niet getoond.

## Spoelbak

Mogelijke opties:

- opbouw;
- vlakinbouw;
- onderbouw.

## Capability-aware filtering

De overlay berekent de geldigheid op basis van:

```text
Exact model
× revisie
× installatiemethode
× materiaal
× dikte
× fabrikantvoorwaarden
× tenantregels
```

## Weergave

Elke geldige optie heeft:

- naam;
- kleine doorsnede;
- status;
- korte uitleg;
- bronlabel.

Niet-geldige opties kunnen grijs worden getoond wanneer uitleg nuttig is.

## Voorbeeldreden

> Vlakinbouw is voor deze revisie niet beschikbaar omdat geen geverifieerde sponningcontour aanwezig is.

## Bevestiging

Na keuze worden de juiste geometrieset en productiehandelingen actief.

---

# 7.11 Exacte componentpositionering

## Hoofdregel

Drag-and-drop bepaalt de voorlopige locatie. Maatrelaties bepalen de productiepositie.

## Componentanker

Standaard:

- midden van de productie-uitsparing;
- of een fabrikant-datumpunt.

Niet standaard:

- visueel midden van het apparaat.

## Horizontale opties

- centreren in werkblad;
- centreren tussen twee zijden;
- afstand vanaf linkerzijde;
- afstand vanaf rechterzijde;
- afstand vanaf hoek;
- afstand vanaf naad;
- koppelen aan referentielijn;
- koppelen aan andere uitsparing;
- absolute lokale X.

## Verticale opties

- afstand vanaf voorzijde;
- afstand vanaf achterzijde;
- centreren in bladdiepte;
- afstand vanaf geselecteerd segment;
- afstand vanaf referentielijn;
- positie loodrecht vanaf boog;
- absolute lokale Y.

## Directe maatbewerking

Dubbelklik op maatlijn en typ de waarde.

## Vergrendelingen

Per as:

- vrij;
- aanbevolen;
- vergrendeld;
- bedrijfsstandaard;
- fabrikantverplicht.

## Overbepaling voorkomen

Per as bestaat één primaire constraint. Andere maten zijn afgeleid.

## Ronde bladen

Gebruik:

- geometrisch middelpunt;
- lokale as;
- geselecteerde rechte referentiezijde;
- positie langs boog;
- loodrechte afstand vanaf boog.

---

# 7.12 Referentiepunten en referentielijnen

## Doel

Complexe maatvoering mogelijk maken zonder vrije CAD-constructie.

## Typen

- bladcentrum;
- lokale oorsprong;
- middenlijn;
- door gebruiker benoemd punt;
- meetpunt uit inmeetrapport;
- referentielijn;
- naadlijn;
- symmetrielijn;
- segmenthart;
- boogmidden;
- raaklijn.

## Eigenschappen

- naam;
- bron;
- positie;
- vergrendeling;
- zichtbaarheid;
- gebruikende constraints.

---

# 7.13 Live 3D Viewer

## Doel

Productiecontroles zichtbaar maken, niet alleen een cosmetische preview leveren.

## Modellen

### Werkbladvolume

- echte contour;
- echte dikte;
- echte gaten;
- echte pockets;
- echte sponningen;
- echte randprofielen.

### Componentweergave

- vereenvoudigd apparaatmodel;
- installatiediepte;
- servicevolume;
- productreferentie.

## Viewermodi

- realistisch;
- technisch;
- X-ray;
- veiligheid;
- bewerkingen;
- onderzijde;
- doorsnede;
- exploded view;
- nestingmateriaal.

## Camera-presets

- boven;
- perspectief;
- voorzijde;
- achterzijde;
- links;
- rechts;
- onderzijde;
- geselecteerde component;
- doorsnede.

## Selectiesynchronisatie

2D- en 3D-selectie verwijzen naar dezelfde feature-ID’s.

## Live gedrag

Tijdens slepen:

- snelle preview;
- transparante component;
- voorlopige uitsparing;
- veiligheidszone.

Na loslaten:

- exacte C++-rebuild;
- volledige validatie;
- definitief mesh.

---

# 7.14 Doorsnedeweergave

## Functies

- verticale snijlijn;
- horizontale snijlijn;
- vrije snijlijn;
- door geselecteerde component;
- maatlabels;
- laagopbouw;
- resterende dikte;
- dieptecontrole.

## Voorbeeldwaarden

- totale dikte;
- sponningdiepte;
- pocketdiepte;
- resterend materiaal;
- apparaatniveau;
- voegspeling;
- overhang/reveal.

---

# 7.15 Materialen

## Materiaalprofiel bevat

- naam;
- merk;
- collectie;
- decor;
- materiaalgroep;
- diktes;
- plaatmaten;
- nerfrichting;
- rotatiemogelijkheden;
- minimale randafstanden;
- minimale radii;
- minimale materiaalbrug;
- freesregels;
- zichtzijde-eisen;
- onderbouwgeschiktheid;
- vlakinbouwgeschiktheid;
- breukrisico;
- plaatfoto-ondersteuning;
- kostprijs;
- voorraadstatus.

## Materiaalgroepen

- HPL;
- compact;
- massief hout;
- multiplex;
- MDF;
- solid surface;
- composiet;
- keramiek;
- natuursteen;
- custom.

## Belangrijk

Productieregels moeten per materiaalprofiel configureerbaar en versioneerbaar zijn.

---

# 7.16 Plaatvoorraad

## Plaatobject

- materiaal;
- lengte;
- breedte;
- dikte;
- batch;
- serienummer;
- magazijnlocatie;
- status;
- defectzones;
- foto;
- kalibratie;
- nerfrichting;
- kostprijs;
- gereserveerd voor;
- reststuk of volle plaat.

## Unieke slab

Extra:

- hoge-resolutiefoto;
- fysieke kalibratiepunten;
- zichtbare aders;
- defecten;
- gewenste zones;
- bookmatchrelatie;
- waterfallrelatie.

---

# 7.17 Restplaten

## Functies

- reststuk registreren;
- geometrie bewaren;
- maat en vorm;
- materiaal;
- batch;
- plaatcoördinaten;
- foto;
- locatie;
- minimale bruikbare marge;
- reserveren;
- afboeken;
- opnieuw nesten.

## Automatisch na productie

Een bruikbaar restgebied kan als nieuw voorraadobject worden opgeslagen.

---

# 7.18 Nerf en patroon

## Modi

### Geen nerf

Vrije rotatie volgens machine- en geometrievoorwaarden.

### Richtingsnerf

Alle onderdelen volgen dezelfde richting.

### Doorlopende reeks

Onderdelen moeten in een vaste volgorde uit aangrenzende plaatzones komen.

### Visuele plaatmatching

Gebruik echte plaatfoto en fysieke coördinaten.

### Waterfall

Patroon loopt over een loodrechte overgang door.

### Bookmatch

Twee delen spiegelen visueel rond een gezamenlijke lijn.

## Relatieobject

Een `Grain Continuity Group` bevat:

- betrokken onderdelen;
- volgorde;
- gewenste afstand;
- oriëntatie;
- spiegelregel;
- tolerantie;
- prioriteit;
- hard/zacht karakter.

---

# 7.19 DXF-nesting en optimalisatie

## Engine

Volledig C++, geen fallback.

## Harde constraints

- onderdeel binnen plaat;
- geen overlap;
- minimale tussenruimte;
- randmarge;
- nerfrichting;
- rotatiebeperking;
- spiegelverbod;
- defectzones;
- klemzones;
- machinebereik;
- gereedschapsruimte;
- gekoppelde onderdelen;
- doorlopende nerf;
- zichtstrookrelaties;
- minimale restbreedtes;
- productierisico.

## Zachte doelen

- minimaal aantal platen;
- minimaal afval;
- maximale materiaalbenutting;
- minimale machinetijd;
- minimale gereedschapswissels;
- waardevolle reststukken behouden;
- visueel beste patroon;
- onderdelen logisch groeperen;
- kwetsbare plaatsingen vermijden.

## Solvermodi

- Quick;
- Balanced;
- Deep;
- Grain First;
- Remnant First;
- Machine Time First;
- Visual Match.

## Resultaatvergelijking

Per alternatief:

- aantal platen;
- benutting;
- afval;
- reststukken;
- geschatte tijd;
- gereedschapswissels;
- nerfscore;
- waarschuwingen;
- solverduur;
- seed;
- engineversie.

## Uitlegbaarheid

Geen onverklaarde totaalscore. De gebruiker ziet waarom een variant beter of slechter is.

---

# 7.20 Productiechecks

## Categorieën

### Geometrie

- contour gesloten;
- geen zelfsnijding;
- geen nulsegment;
- geldige boog;
- winding;
- gaten binnen contour;
- geen ongewenste overlapping.

### Componentdata

- exact model;
- revisie geldig;
- installatiemethode ondersteund;
- bron aanwezig;
- geometrieset geverifieerd;
- dieptes aanwezig;
- toleranties aanwezig.

### Materiaal

- minimale afstand;
- minimale radius;
- minimale resterende dikte;
- installatiemethode toegestaan;
- breukrisico;
- nerfrichting.

### Productie

- gereedschap beschikbaar;
- layer mapping compleet;
- machineprofiel geldig;
- freesdiameter past;
- contouren machineleesbaar;
- eenheid correct;
- output binnen machinebereik.

### Nesting

- plaat beschikbaar;
- onderdelen geplaatst;
- nerfrelaties geldig;
- defectzones vermeden;
- restplaatstatus geldig.

## Ernstniveaus

- informatie;
- advies;
- waarschuwing;
- blokkade.

## Override

Alleen bevoegde rollen kunnen waarschuwingen overrulen.

Iedere override bevat:

- gebruiker;
- tijd;
- reden;
- oude waarde;
- nieuwe waarde;
- bron;
- goedkeurder.

Harde blokkades kunnen niet worden genegeerd tenzij de productiestandaard expliciet een gecontroleerde uitzonderingsroute ondersteunt.

---

# 7.21 Productievrijgave

## Vereisten

- geometrie geldig;
- alle kritieke componenten geverifieerd;
- positie exact;
- materiaalregels geldig;
- nesting gekozen;
- machineprofiel geldig;
- klanttekening eventueel akkoord;
- bevoegde gebruiker geeft vrij.

## Statussen

- Concept;
- Geometry Valid;
- Review Required;
- Manufacturable;
- Customer Approved;
- Production Released;
- Exported;
- Superseded;
- Archived.

---

# 7.22 Exportcentrum

## Exportpakket

```text
ORDER-10483/
├── machine/
│   ├── PART-A.dxf
│   ├── PART-B.dxf
│   └── NESTING.dxf
├── documents/
│   ├── klant_maattekening.pdf
│   ├── productieblad.pdf
│   ├── componentenlijst.pdf
│   └── materiaaloverzicht.pdf
├── previews/
│   ├── worktop-preview.png
│   └── nesting-preview.png
├── data/
│   ├── order.json
│   ├── operations.json
│   ├── validation.json
│   └── engine-manifest.json
└── checksums.txt
```

## Exportopties

- individueel onderdeel;
- volledig project;
- machinepakket;
- klantpakket;
- API-output;
- herexport van vorige release;
- versie vergelijken.

## Manifest

Bevat:

- projectversie;
- engineversie;
- invoerhash;
- componentrevisies;
- materiaalregelversie;
- machineprofielversie;
- layer mapping;
- solverseed;
- tijdstip;
- vrijgever;
- checksums.

---

# 7.23 Machineprofielen

## Doel

Eén canoniek productiemodel vertalen naar klantspecifieke machine-intenties.

## Profiel bevat

- fabrikant;
- machinetype;
- CAM-software;
- versie;
- ondersteunde entiteiten;
- eenheden;
- coördinatenstelsel;
- oorsprong;
- layerregels;
- kleurregels;
- tekstregels;
- toolhints;
- dieptetokens;
- toleranties;
- maximumafmetingen;
- toegestane boogrepresentatie;
- contourrichting;
- exporttemplate;
- acceptatiestatus.

## Status

- Draft;
- Test Required;
- Accepted;
- Production Active;
- Deprecated.

## Acceptance test

Een profiel wordt pas productieactief na een goedgekeurde testset.

---

# 7.24 Layer Mapping

## Interne intenties

Voorbeelden:

- `OUTER_CUT`;
- `INNER_THROUGH_CUT`;
- `REBATE`;
- `POCKET_TOP`;
- `POCKET_BOTTOM`;
- `DRILL`;
- `ENGRAVE`;
- `MITRE`;
- `EDGE_PROFILE`;
- `REFERENCE`;
- `TEXT`.

## Mapping

Per intentie:

- DXF-laagnaam;
- ACI-kleur;
- linetype;
- lijngewicht;
- tokenpatroon;
- toolhint;
- diepteformaat;
- include/exclude;
- machinecondities.

## Tokens

Voorbeeld:

```text
ROUT_Z-[DEPTH]_T[TOOL]_D[DIAMETER]
```

## Preview

Toon live welke entiteit op welke laag terechtkomt.

---

# 7.25 Componentbeheer

## Componentrecord

- merk;
- model;
- artikelnummer;
- EAN;
- categorie;
- revisie;
- status;
- afbeeldingen;
- bronbestanden;
- ondersteunde installatiemethoden;
- geometriesets;
- materiaalvoorwaarden;
- diktevoorwaarden;
- tolerantie;
- radii;
- dieptes;
- veiligheidszones;
- datum points;
- wijzigingshistorie.

## Geometry Set per installatiemethode

### Opbouw

- doorfreescontour;
- toleranties;
- hoekradius;
- apparaatvoet;
- veiligheidszone.

### Vlakinbouw

- doorfreescontour;
- sponningcontour;
- sponningdiepte;
- montagespeling;
- minimale resterende dikte;
- hoekradius.

### Onderbouw

- zichtopening;
- bakreferentie;
- reveal;
- bevestigingszone;
- afwerkingscontour;
- eventuele pockets of boringen.

## Bronverificatie

Per kritieke waarde:

- bronsoort;
- document;
- revisie;
- pagina;
- controledatum;
- controleur;
- status.

## AI-gebruik

AI mag:

- PDF’s structureren;
- kandidaatwaarden detecteren;
- maten voorstellen;
- verschillen signaleren.

AI mag niet:

- een component automatisch productieklaar verklaren;
- ontbrekende uitsparingsmaten gokken;
- zonder menselijke verificatie een geometrieset publiceren.

---

# 7.26 Eigen component toevoegen

## Wizard

1. categorie;
2. merk/model;
3. bron uploaden;
4. installatiemethoden;
5. contour importeren of parametrisch invoeren;
6. dieptes en toleranties;
7. referentiepunt;
8. materiaalvoorwaarden;
9. visuele controle;
10. verificatie;
11. publiceren binnen tenant.

## Status

Tenant Verified is voldoende voor eigen productie, maar blijft zichtbaar onderscheiden van Platform Verified.

---

# 7.27 Organisatie-instellingen

- bedrijfsgegevens;
- standaard eenheid;
- standaard materiaal;
- nummering;
- productiestandaarden;
- toleranties;
- exportnamen;
- logo;
- PDF-template;
- notificaties;
- API-sleutels;
- bewaartermijnen;
- MFA;
- goedkeuringsroutes.

---

# 7.28 Team en rollen

## Rollen

### Viewer

Alleen lezen.

### Designer

Projecten maken en bewerken.

### Work Preparer

Productiechecks afhandelen en nesting kiezen.

### Production Releaser

Productie vrijgeven.

### Component Manager

Componenten beheren.

### Machine Profile Manager

Machine- en layerprofielen beheren.

### Tenant Admin

Organisatie beheren.

### Platform Admin

Platformbrede bibliotheek en infrastructuur.

## Rechtenmodel

Fijnmazig per actie:

- project maken;
- project wijzigen;
- component kandidaat gebruiken;
- waarschuwing overrulen;
- profiel activeren;
- exporteren;
- vrijgeven;
- audit bekijken.

---

# 7.29 Auditlog

## Audititems

- project aangemaakt;
- maat gewijzigd;
- component geplaatst;
- installatiemethode gewijzigd;
- componentrevisie gewijzigd;
- materiaal gewijzigd;
- waarschuwing geaccepteerd;
- machineprofiel gewijzigd;
- export uitgevoerd;
- productievrijgave;
- herroeping;
- componentstatus gewijzigd.

## Eigenschappen

- tijd;
- gebruiker;
- tenant;
- object;
- oude waarde;
- nieuwe waarde;
- reden;
- IP/device indien relevant;
- versie.

---

# 8. Visueel design system

## 8.1 Algemene uitstraling

De software moet:

- premium;
- rustig;
- technisch;
- modern;
- betrouwbaar;
- productief;
- overzichtelijk;
- desktop-geoptimaliseerd

aanvoelen.

## 8.2 Thema

Aanbevolen:

- donker neutraal canvas voor 2D/3D;
- lichtere panelen voor formulieren;
- één duidelijke accentkleur;
- waarschuwingen alleen waar nodig;
- statuskleuren consistent;
- voldoende contrast;
- geen decoratieve drukte.

## 8.3 Layoutregels

- vaste linkerzijbalk;
- vaste projectheader;
- centraal groot canvas;
- contextueel rechterpaneel;
- compacte onderste validatiebalk;
- panelen inklapbaar;
- geen lange scrollpagina’s binnen de editor;
- belangrijkste acties altijd zichtbaar.

## 8.4 Typografie

- grote paginatitels;
- compacte technische labels;
- monospaced cijfers voor maatvoering;
- duidelijke eenheden;
- decimalen consistent;
- geen afkortingen zonder uitleg.

## 8.5 Statuskleurgebruik

- groen: geldig;
- blauw: actief/informatie;
- oranje: waarschuwing;
- rood: blokkade;
- grijs: niet beschikbaar;
- paars of accent: geselecteerd.

Kleur is nooit de enige drager van betekenis; altijd ook tekst en icoon.

---

# 9. Canonical Worktop Model

## 9.1 Project

```text
Project
├── Metadata
├── WorktopParts[]
├── Materials
├── Components[]
├── References[]
├── Joints[]
├── GrainGroups[]
├── ValidationState
├── NestingScenarios[]
├── ReleaseHistory[]
└── ExportHistory[]
```

## 9.2 WorktopPart

```text
WorktopPart
├── id
├── name
├── localCoordinateSystem
├── outlineSegments[]
├── holes[]
├── edges[]
├── operations[]
├── materialAssignment
├── thickness
├── grainOrientation
├── references[]
├── joints[]
└── status
```

## 9.3 OutlineSegment

```text
OutlineSegment
├── type
├── start
├── end
├── length
├── angle
├── radius
├── center
├── tangentRules
├── constraints[]
├── sideClassification
├── finish
└── lockedState
```

## 9.4 PlacedComponent

```text
PlacedComponent
├── componentRevisionId
├── installationMode
├── datumPoint
├── positionConstraints
├── rotation
├── geometrySet
├── operations[]
├── materialCompatibility
├── validationState
└── sourceState
```

## 9.5 Operation

```text
Operation
├── type
├── contour
├── zStart
├── zEnd
├── depth
├── side
├── tolerance
├── radius
├── toolIntent
├── machineRequirements
└── provenance
```

---

# 10. C++-enginearchitectuur

## 10.1 Hoofdmodules

```text
worktop-core/
├── geometry/
├── constraints/
├── import/
├── shape_builder/
├── components/
├── placement/
├── operations/
├── validation/
├── meshing/
├── nesting/
├── grain/
├── output/
├── diagnostics/
└── api/
```

## 10.2 Geometry

- punten;
- vectoren;
- lijnen;
- cirkels;
- bogen;
- ellipsen;
- polylijnen;
- polygonen;
- offsets;
- booleans;
- intersections;
- winding;
- triangulatie;
- healing;
- simplificatie.

## 10.3 Constraints

- vaste lengte;
- vaste hoek;
- tangent;
- gelijk;
- parallel;
- loodrecht;
- gecentreerd;
- symmetrisch;
- afstand tot zijde;
- afstand tot punt;
- koppeling aan boog;
- vergrendeling;
- prioriteit;
- conflictanalyse.

## 10.4 Native en WebAssembly

Dezelfde broncode wordt gebouwd als:

- native Linux-engine voor autoritatieve serverruns;
- WebAssembly-module voor live preview.

De native serveruitvoer blijft leidend voor productie.

## 10.5 Determinisme

Iedere run registreert:

- engineversie;
- buildhash;
- invoerhash;
- seed;
- tolerantieprofiel;
- componentrevisies;
- materiaalregels;
- machineprofiel;
- resultaatchecksum.

## 10.6 Interne eenheid

Aanbevolen vaste geschaalde integerrepresentatie:

```text
1 interne unit = 0,001 mm
```

Dit verkleint floating-pointafwijkingen en bevordert reproduceerbaarheid.

---

# 11. Shape Engine

## Verantwoordelijkheden

- templategeometrie;
- segmentketens;
- boogconstructies;
- schaalbare vormen;
- gesloten contour;
- tangentovergangen;
- hoekbewerkingen;
- parametrische wijzigingen;
- constraintconflicten;
- reparatievoorstellen.

## Output

- geldige gesloten outline;
- segmentmetadata;
- zijdeclassificatie;
- lokale assen;
- maatlabels;
- diagnostiek.

---

# 12. Placement Constraint Engine

## Verantwoordelijkheden

- voorlopige dragpositie;
- snapkandidaten;
- exacte referenties;
- componentanker;
- relationele positionering;
- vergrendelingen;
- collision checks;
- veiligheidsafstanden;
- conflictresolutie;
- automatische voorstellen.

## Snaptypen

### Sterk

- werkbladcentrum;
- segmentcentrum;
- referentielijn;
- andere component;
- naad;
- vaste offset.

### Zwak

- nabijgelegen punt;
- afgeronde maat;
- grafische hulplijn;
- gelijke tussenruimte.

## Regel

Een snap toont altijd expliciet waaraan wordt gesnapt.

---

# 13. 3D Meshing Engine

## Verantwoordelijkheden

- 2D-outline extruderen;
- doorlopende uitsparingen verwijderen;
- pockets genereren;
- sponningen genereren;
- boorgaten;
- randprofielen;
- triangulatie;
- normals;
- feature-ID’s;
- doorsnededata;
- delta-updates.

## Previewmodus

Tijdens slepen:

- lagere resolutie;
- gedeeltelijke update;
- geen volledige productiecheck.

## Commitmodus

Na loslaten:

- volledige nauwkeurigheid;
- volledige booleans;
- validatie;
- definitieve mesh.

---

# 14. Validation Engine

## Invoer

- canonical model;
- componentdata;
- materiaalregels;
- machineprofiel;
- nestingresultaat.

## Uitvoer

```text
ValidationResult
├── geometryIssues[]
├── componentIssues[]
├── materialIssues[]
├── productionIssues[]
├── nestingIssues[]
├── warnings[]
├── blockers[]
└── derivedStatus
```

## Statusberekening

Status wordt door pure regels afgeleid. Geen handmatige “92% gereed”-score.

---

# 15. Nesting Engine

## Algoritmische aanpak

De solver mag hybride werken met:

- polygon placement;
- no-fit polygon-logica;
- guillotinebeperkingen waar relevant;
- heuristics;
- simulated annealing;
- genetic search;
- local improvement;
- branch-and-bound voor kleine sets;
- multi-start;
- deterministische seed.

## Resultaat

Meerdere Pareto-varianten in plaats van één verborgen uitkomst.

---

# 16. DXF Compiler

## Principes

- gesloten polylijnen;
- consistente eenheid;
- juiste contourrichting;
- layersegregatie;
- arcbehoud waar machineprofiel dit ondersteunt;
- fallback binnen de C++-compiler naar gecontroleerde segmentatie, niet naar andere programmeertaal;
- tekst en metadata volgens profiel;
- volledige manifestkoppeling.

## Entiteiten

Afhankelijk van profiel:

- `LWPOLYLINE`;
- `POLYLINE`;
- `LINE`;
- `ARC`;
- `CIRCLE`;
- `TEXT`;
- `MTEXT`;
- `INSERT`.

## Geen directe belofte

Geen universele directe G-code zonder afzonderlijk gevalideerde postprocessor.

---

# 17. Backend- en SaaS-architectuur

## 17.1 Aanbevolen stack

### Frontend

- Next.js / React;
- TypeScript;
- WebGL via Three.js of React Three Fiber;
- 2D-canvas via eigen renderer, PixiJS of SVG/canvashybride;
- Web Workers;
- WebAssembly C++ core;
- state management met duidelijke command/history-laag.

### Backend

- TypeScript/Node.js voor SaaS-orchestratie;
- PostgreSQL;
- object storage;
- queue-systeem;
- native C++ workers;
- REST of typed RPC;
- websocket/SSE voor enginejobs;
- achtergrondtaken voor imports, nesting en exports.

### Waarom geen Python als core

Python kan eventueel voor niet-autoritatieve data- of beheertaken worden gebruikt, maar niet voor geometrie, nesting, validatie of DXF-productie.

## 17.2 Services

```text
Web App
API Gateway
Auth Service
Project Service
Component Library Service
Material Service
C++ Geometry Worker
C++ Nesting Worker
C++ Export Worker
File Service
Audit Service
Notification Service
Billing Service
```

## 17.3 Jobmodel

Zware engineacties draaien als job:

- import;
- exact rebuild;
- volledige validatie;
- deep nesting;
- exportpakket;
- previewgeneratie.

Jobstatus:

- queued;
- running;
- completed;
- failed;
- cancelled.

---

# 18. API-contracten

## Voorbeeld: geometry rebuild

```json
{
  "projectId": "prj_123",
  "revisionId": "rev_17",
  "engineMode": "EXACT",
  "inputHash": "sha256:...",
  "worktopModel": {}
}
```

## Resultaat

```json
{
  "ok": true,
  "engineVersion": "1.0.0",
  "outputHash": "sha256:...",
  "canonicalGeometry": {},
  "meshManifest": {},
  "validation": {},
  "diagnostics": []
}
```

## Belangrijk

Server accepteert geen productie-export wanneer:

- invoerrevisie niet actueel is;
- previewresultaat ouder is;
- componentrevisie is vervangen;
- machineprofiel niet actief is;
- blocker bestaat.

---

# 19. Databasehoofdentiteiten

- tenants;
- users;
- memberships;
- roles;
- permissions;
- projects;
- project_revisions;
- worktop_parts;
- shape_segments;
- placed_components;
- component_models;
- component_revisions;
- component_geometry_sets;
- component_sources;
- materials;
- material_revisions;
- slabs;
- remnants;
- machine_profiles;
- layer_mappings;
- validation_runs;
- nesting_jobs;
- nesting_results;
- export_jobs;
- exports;
- release_records;
- audit_events;
- overrides;
- files;
- subscriptions;
- usage_records.

---

# 20. Multi-tenancy en beveiliging

## Tenantisolatie

- tenant-ID op alle records;
- row-level security of gelijkwaardig;
- object storage per tenant;
- gescheiden exports;
- gescheiden componentbibliotheken;
- platformbibliotheek read-only voor tenants.

## Security

- MFA;
- SSO enterprise;
- encrypted storage;
- encrypted transport;
- signed downloadlinks;
- malwarecontrole uploads;
- rate limiting;
- auditlog;
- immutable release manifests;
- least privilege;
- secrets buiten broncode;
- back-ups;
- hersteltests.

## Productiekritische acties

Vereisen eventueel:

- herauthenticatie;
- tweede goedkeurder;
- expliciete reden;
- digitale handtekening.

---

# 21. Performance-eisen

## Editor

- dragpreview circa 60 fps waar haalbaar;
- zichtbare maatwijziging binnen 100 ms;
- exacte componentcommit binnen circa 500 ms voor normale projecten;
- 3D-delta-update zonder volledig project te herladen.

## Nesting

- quick resultaat binnen enkele seconden;
- deep optimize als achtergrondtaak;
- tussentijdse beste resultaten zichtbaar;
- annuleren mogelijk;
- reproduceerbare run.

## Grote projecten

- delen cachen;
- lazy-load componenten;
- viewportculling;
- meshdelta’s;
- worker threads;
- geen zware berekening op UI-thread.

---

# 22. Foutafhandeling

## Geen generieke foutmeldingen

Niet:

> Er is iets misgegaan.

Wel:

> De sponningcontour van component `BORA X Pure revisie 2026-02` kruist de buitencontour van werkbladdeel A. Verplaats het component minimaal 18,4 mm naar binnen of kies opbouw.

## Enginefouten

Toon:

- foutcode;
- betrokken object;
- herstelsuggestie;
- laatste geldige versie;
- retry;
- supportbundel genereren.

## Autosave

- command-based history;
- lokale tijdelijke buffer;
- serversnapshot;
- herstel na crash;
- conflictmelding bij gelijktijdig bewerken.

---

# 23. Versiebeheer

## Projectrevisies

Iedere betekenisvolle wijziging kan een revisie opleveren.

## Productievrijgave

Een vrijgegeven revisie is immutable.

Nieuwe wijziging maakt een nieuwe revisie.

## Componentupdates

Wanneer een componentrevisie wordt vervangen:

- bestaande vrijgegeven orders blijven reproduceerbaar;
- actieve conceptprojecten krijgen een updatewaarschuwing;
- gebruiker kan oude en nieuwe geometrie vergelijken;
- update nooit automatisch zonder bevestiging.

---

# 24. Teststrategie

## 24.1 Unit tests

- polygonbooleans;
- offsets;
- bogen;
- tangentregels;
- constraintsolver;
- componentplaatsing;
- materiaalregels;
- layer mapping;
- DXF-output;
- hashing.

## 24.2 Golden files

Bekende input levert exact verwachte:

- geometrie;
- DXF;
- mesh;
- validatie;
- nesting;
- manifest.

## 24.3 Property-based tests

- contour blijft gesloten;
- geen overlap na geldige nesting;
- offsets behouden topologie;
- rotatie respecteert nerf;
- component blijft binnen outline;
- determinisme bij gelijke seed.

## 24.4 Fuzzing

Voor DXF-import en geometrie.

## 24.5 Machine Acceptance Tests

Per machineprofiel:

- bekende vormen;
- boog;
- gat;
- sponning;
- pocket;
- boor;
- tekst;
- layer mapping;
- eenheid;
- oorsprong.

## 24.6 Productiepilot

Eerst materiaal- en machinecategorie beperken en echte proefstukken produceren.

---

# 25. Observability

## Metrics

- enginejobduur;
- foutpercentage;
- nestingduur;
- exportduur;
- projectgrootte;
- WebAssemblyfouten;
- componentverificaties;
- blockers per categorie;
- machineprofielproblemen.

## Logs

- gestructureerd;
- correlation ID;
- tenantveilig;
- geen onnodige persoonsgegevens;
- engineversie;
- projectrevisie.

## Supportbundle

Bevat:

- manifest;
- logselectie;
- engineversie;
- anonieme diagnostiek;
- foutcode;
- geen volledige klantdata tenzij expliciet goedgekeurd.

---

# 26. Onboarding

## Organisatiewizard

1. bedrijfsgegevens;
2. materiaalprofielen;
3. machineprofiel;
4. layer mapping;
5. test-DXF;
6. testproductie;
7. componentbibliotheek;
8. rollen;
9. productieacceptatie.

## Guided first project

- rechthoekig blad;
- één spoelbak;
- installatiekeuze;
- exacte positionering;
- 3D-check;
- DXF-preview;
- exporttest.

## Geen directe productie zonder acceptatie

Nieuwe tenant start in testmodus totdat:

- machineprofiel is goedgekeurd;
- test-DXF is geaccepteerd;
- bevoegd gebruiker productie activeert.

---

# 27. Verdienmodel

## Designer

- projecten;
- slimme vormbouwer;
- componentbibliotheek;
- 2D/3D;
- klant-PDF;
- beperkte export.

## Production

- machineprofielen;
- volledige validatie;
- DXF-export;
- nesting;
- restplaten;
- productiehistorie.

## Factory

- meerdere machines;
- meerdere locaties;
- API/ERP;
- geavanceerde rollen;
- unieke slabs;
- grain matching;
- SLA.

## Enterprise

- maatwerkpostprocessors;
- private componentcatalogus;
- SSO;
- uitgebreide audit;
- dedicated onboarding;
- contractuele support.

## Eenmalige implementatie

- machineprofiel;
- layer mapping;
- proefproductie;
- data-import;
- training;
- acceptatietest.

---

# 28. Gefaseerde roadmap

# Fase 0 — Technisch bewijs

- C++ outline;
- rechthoek;
- één gat;
- één sponning;
- DXF-export;
- 3D-extrusie;
- golden tests.

## Exitcriteria

- exact reproduceerbare geometrie;
- DXF leest correct in test-CAM;
- 3D en DXF gebruiken dezelfde contour.

# Fase 1 — Reliable Worktop Core

- projecten;
- rechthoek, L, U;
- rondingen;
- slimme maatvoering;
- componentdrag;
- opbouw/vlakinbouw/onderbouw;
- exacte positionering;
- 2D/3D;
- materiaalregels;
- validatie;
- machineprofiel;
- DXF-export.

## Exitcriteria

- echte pilotorders;
- geen handmatige CAD-correctie nodig binnen ondersteunde scope;
- machine acceptatietest geslaagd.

# Fase 2 — Production Nesting

- meerdere onderdelen;
- plaatvoorraad;
- C++ nesting;
- nerfrichting;
- restplaten;
- resultaten vergelijken;
- productieblad.

# Fase 3 — Component Intelligence

- uitgebreid verificatiebeheer;
- tenantcomponenten;
- bronworkflow;
- leveranciersportal;
- componentupdates;
- platformbibliotheek.

# Fase 4 — Grain & Slab Intelligence

- gekalibreerde plaatfoto;
- defectzones;
- doorlopende nerfgroepen;
- waterfall;
- bookmatch;
- visuele nesting.

# Fase 5 — Factory Integrations

- ERP/API;
- orderimport;
- voorraadkoppeling;
- productiequeue;
- meerdere locaties;
- analytics;
- enterprise SSO.

---

# 29. MVP-afbakening

## Wel in eerste productie-MVP

- desktopwebapp;
- één tenant;
- gebruikersrollen;
- rechthoek, L, U;
- radius en afschuining;
- DXF-import;
- kookplaat;
- spoelbak;
- kraan;
- opbouw;
- vlakinbouw;
- onderbouw spoelbak;
- exacte maatpositionering;
- live 2D en 3D;
- materiaal en dikte;
- validatie;
- één machineprofiel;
- layer mapping;
- machine-DXF;
- klant-PDF;
- audit;
- native C++ exportengine;
- WebAssembly-preview.

## Niet in eerste MVP

- volledige natuursteensuite;
- photorealistische marketingrenders;
- directe G-code;
- tientallen machinepostprocessors;
- complete leveranciersportal;
- AI-autoverificatie;
- geavanceerde bookmatch;
- mobiele editor;
- keukenmeubels;
- kastindelingen.

---

# 30. Kritieke productrisico’s

## 30.1 Te brede materiaalscope

Oplossing: begin met één materiaal- en productiecluster.

## 30.2 Onbetrouwbare componentdata

Oplossing: provenance, verificatiestatus, revisies, fail-closed export.

## 30.3 Verschil tussen preview en productie

Oplossing: één C++-core en één canonical model.

## 30.4 Slechte DXF-compatibiliteit

Oplossing: machineprofielen, acceptance tests, golden files.

## 30.5 Nestingresultaat voelt willekeurig

Oplossing: uitlegbare doelen, meerdere varianten, vaste seeds.

## 30.6 UX wordt alsnog CAD

Oplossing: vormlogica, constraints, contextpanelen, beperkte expertmodus.

## 30.7 Scope drift naar keukenplanning

Oplossing: harde productgrens: alleen werkbladobjecten en productiereferenties.

---

# 31. Productbeloften

Worktop OS mag beloven:

- slimme werkbladopbouw;
- live 2D/3D;
- exacte productiemaatvoering;
- traceerbare componentdata;
- gecontroleerde installatiemethoden;
- C++-gebaseerde geometrie en nesting;
- configureerbare machine-DXF;
- productietechnische validatie;
- uitlegbare nesting;
- reproduceerbare export.

Worktop OS mag niet zonder bewijs beloven:

- nul fouten;
- iedere order in drie minuten;
- ondersteuning voor iedere machine;
- automatische waarheid uit fabrikant-PDF’s;
- universele directe machinecode;
- volledige maakbaarheid zonder tenantacceptatie;
- ieder componentmodel vanaf dag één.

---

# 32. Definitieve UX-kernregels

1. De gebruiker bouwt een werkblad, geen tekening.  
2. Iedere visuele handeling eindigt in een expliciete maat of constraint.  
3. Drag-and-drop is voor snelheid; maatrelaties zijn voor productie.  
4. De 3D-viewer toont echte bewerkingsvolumes.  
5. Een componentoptie verschijnt alleen wanneer die aantoonbaar ondersteund is.  
6. Kookplaat: opbouw of vlakinbouw binnen de normale scope.  
7. Spoelbak: opbouw, vlakinbouw of onderbouw wanneer ondersteund.  
8. Geen kast- of keukenplanning.  
9. Iedere zijde heeft productietechnische betekenis.  
10. De gebruiker ziet altijd waarop een maat betrekking heeft.  
11. Geen stille geometrische reparaties.  
12. Geen export bij ontbrekende kritieke waarheid.  
13. Geen fallback buiten de C++-core.  
14. Geen schijnbare readinessscore; status volgt uit harde regels.  
15. Iedere productie-export is reproduceerbaar.

---

# 33. Definitie van “production ready”

Een project is pas productieklaar wanneer:

- alle werkbladcontouren geldig zijn;
- alle componenten exact zijn geïdentificeerd;
- de gebruikte componentrevisies geldig zijn;
- installatiemethoden ondersteund zijn;
- alle kritieke geometrie geverifieerd is;
- alle componentposities exact zijn vastgelegd;
- materiaalregels geslaagd zijn;
- alle dieptes en resterende diktes geldig zijn;
- alle blokkades opgelost zijn;
- machineprofiel geaccepteerd is;
- layer mapping compleet is;
- nesting gekozen en gevalideerd is;
- projectrevisie vaststaat;
- bevoegde gebruiker heeft vrijgegeven;
- exportmanifest en checksums zijn gegenereerd.

---

# 34. Eindvisie

Worktop OS moet uitgroeien tot het centrale digitale productiesysteem tussen inmeten, werkvoorbereiding en CNC-productie.

De gebruiker ervaart:

- visuele eenvoud;
- snelle invoer;
- slimme componentkeuze;
- directe 3D-feedback;
- duidelijke productiewaarschuwingen;
- transparante optimalisatie;
- betrouwbare export.

De fabrikant krijgt:

- minder repetitief tekenwerk;
- minder interpretatieverschillen;
- herbruikbare productiekennis;
- versiebeheer;
- audit;
- machineprofielen;
- materiaalbesparing;
- traceerbare componentdata;
- een schaalbare SaaS-omgeving.

De structurele voorsprong zit niet in één losse functie, maar in de combinatie van:

1. parametrisch werkbladontwerp;  
2. geverifieerde componentintelligentie;  
3. exacte relationele positionering;  
4. live autoritatieve 2D/3D;  
5. productieregels per materiaal;  
6. C++-gebaseerde validatie en nesting;  
7. configureerbare machine-output;  
8. volledige traceerbaarheid van ontwerp tot export.  

Dat maakt Worktop OS geen simpele DXF-tekenaar, maar een gespecialiseerd **Worktop Manufacturing Operating System**.
