# Roadmap

## v0.1 — Foundation

- modular Next.js workspace;
- definitive UX shell;
- baseline 2D/3D editor;
- native C++ geometry core.

## v0.2 — AI Component Ingestion Foundation

- product photo and official PDF upload;
- OpenAI Structured Outputs;
- extractor + verifier passes;
- source provenance and conflicts;
- PostgreSQL candidate storage;
- native C++ review-DXF generation from complete candidate geometry;
- secure VPS key management;
- fail-closed candidate review UI.

## v0.3 — Source & Geometry Review

- side-by-side PDF viewer;
- page-level source highlighting;
- field-level accept/reject;
- vector-PDF extraction;
- native C++ DXF parsing;
- contour classification;
- overlay comparison;
- geometry diagnostics;
- tenant verifier workflow.

## v0.4 — Product Library Publication

- publish tenant-verified components;
- rights-aware real product photos;
- revision management;
- capability-aware install modes;
- search indexing;
- drag-and-drop from real database records.

## v0.5 — Reliable Worktop Shape Builder

- parametric segments;
- scalable arcs and round shapes;
- exact placement constraints;
- C++/WASM shared geometry;
- command history and undo/redo.

## Later

- DXF compiler profiles;
- material rules;
- C++ nesting;
- grain continuity;
- slab photography;
- production release and ERP integrations.
