# UX Source of Truth

De vastgezette Worktop OS-richting is bindend voor nieuwe schermen:

- donkere linker navigatie;
- donkere vaste bovenbalk;
- lichte witte/lichtgrijze werkruimte;
- blauwe primaire acties;
- ruime premium kaarten;
- desktop-only productieworkflow;
- dezelfde stijl voor dashboard, library, 2D, 3D, nesting en export;
- geen nieuwe designrichting zonder expliciete productbeslissing.

## Implementatieregel

Visuele componenten worden centraal hergebruikt. Featurepagina's mogen geen afwijkend zelfstandig design system introduceren.
