# AI Component Ingestion Studio

## Doel

Van echte productfoto’s en officiële fabrikantdocumentatie naar een traceerbare, gestructureerde componentkandidaat.

## Veiligheidscontract

De AI mag:

- merk, model, artikelnummer en revisie extraheren;
- expliciet gedocumenteerde installatiemethoden herkennen;
- benoemde maten, radii, dieptes en voorwaarden structureren;
- bronverwijzingen koppelen;
- conflicten en ontbrekende data signaleren.

De AI mag niet:

- maten uit een productfoto afleiden;
- onbekende waarden schatten;
- een sponning genereren door zelf een offset te verzinnen;
- meerdere modelvarianten stil samenvoegen;
- een component verifiëren;
- een definitieve DXF publiceren.

## Analyseflow

1. Bestandsvalidatie en SHA-256.
2. Persistente opslag onder `WORKTOP_DATA_DIR`.
3. Databasejob met status `AI_ANALYZING`.
4. Eerste OpenAI-extractiepass.
5. Tweede onafhankelijke verificatiepass, tenzij expliciet uitgeschakeld.
6. Zod-validatie van Structured Output.
7. Opslag als `component_candidates`.
8. Native C++ kandidaat-DXF per volledig gedocumenteerde installatiemethode.
9. Status `GEOMETRY_REVIEW_REQUIRED` of `BLOCKED`.

## Brontypen

- Productfoto: identiteit en visuele herkenning.
- Officiële PDF/TXT: AI-analyse met bronverwijzingen.
- DXF/DWG: opslaan als vectorbron; de inhoud wordt niet door AI geïnterpreteerd en wordt later door de C++ vectorimporter verwerkt.
- AI-parameters: alleen wanneer schaal, datumoffset en vorm compleet zijn kan de native C++ kandidaatcompiler een review-DXF genereren.

## Database

Migratie: `packages/data/migrations/001_ai_ingestion.sql`.

Hoofdtabel:

- `ai_ingestion_jobs`
- `ai_ingestion_sources`
- `component_candidates`

## Omgevingsvariabelen

```text
OPENAI_API_KEY
OPENAI_INGESTION_MODEL=gpt-5.6
OPENAI_INGESTION_VERIFIER=true
DATABASE_URL
WORKTOP_DATA_DIR
```

## Volgende technische fase

- side-by-side PDF/bronviewer;
- vector-PDF en officiële DXF C++-extractie;
- geometrie-overlay;
- veldniveau menselijke acceptatie;
- `TENANT_VERIFIED`-workflow;
- publicatie naar de echte Product Library.
