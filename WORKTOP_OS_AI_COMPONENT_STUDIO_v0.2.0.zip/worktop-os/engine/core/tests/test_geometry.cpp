#include "worktop/geometry.hpp"

#include <cassert>
#include <cmath>
#include <iostream>

namespace {

[[nodiscard]] bool approximately_equal(const double left, const double right) {
  return std::abs(left - right) < 0.001;
}

}  // namespace

int main() {
  const auto rectangle = worktop::make_rectangle("test", 2'800'000, 900'000);
  const auto result = worktop::validate_polygon(rectangle);

  assert(result.valid);
  assert(approximately_equal(result.area_square_mm, 2'520'000.0));
  assert(approximately_equal(result.perimeter_mm, 7'400.0));
  assert(result.issues.empty());

  worktop::Polygon invalid {
    .id = "invalid",
    .points = {
      {.x_microns = 0, .y_microns = 0},
      {.x_microns = 0, .y_microns = 0},
      {.x_microns = 1000, .y_microns = 1000},
    },
  };
  const auto invalid_result = worktop::validate_polygon(invalid);
  assert(!invalid_result.valid);
  assert(!invalid_result.issues.empty());

  std::cout << "Alle worktop-core tests zijn geslaagd.\n";
  return 0;
}
