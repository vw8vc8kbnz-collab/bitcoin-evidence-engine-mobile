#include "worktop/component_dxf.hpp"

#include <cassert>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <string>
#include <vector>

int main() {
  const auto output = std::filesystem::temp_directory_path() / "worktop-component-candidate-test.dxf";
  const std::vector<worktop::CandidateOperation> operations {
    worktop::CandidateOperation {
      .operation_type = "THROUGH_CUT",
      .shape_kind = worktop::CandidateShapeKind::rounded_rectangle,
      .layer_name = "AI_THROUGH_CUT",
      .width_microns = 750000,
      .height_microns = 490000,
      .radius_microns = 5000,
    },
    worktop::CandidateOperation {
      .operation_type = "DRILL",
      .shape_kind = worktop::CandidateShapeKind::circle,
      .layer_name = "AI_DRILL",
      .diameter_microns = 35000,
      .offset_x_microns = 100000,
    },
  };

  const auto result = worktop::write_candidate_dxf(operations, output);
  assert(result.valid);
  assert(result.entity_count == 2U);

  std::ifstream input(output);
  const std::string contents((std::istreambuf_iterator<char>(input)), std::istreambuf_iterator<char>());
  assert(contents.find("LWPOLYLINE") != std::string::npos);
  assert(contents.find("CIRCLE") != std::string::npos);
  assert(contents.find("WORKTOP_OS_AI_CANDIDATE_NOT_VERIFIED") != std::string::npos);
  std::filesystem::remove(output);
  return 0;
}
