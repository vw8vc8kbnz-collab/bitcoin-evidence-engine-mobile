#pragma once

#include "worktop/geometry.hpp"

#include <filesystem>
#include <string>
#include <vector>

namespace worktop {

enum class CandidateShapeKind {
  rectangle,
  rounded_rectangle,
  circle,
  polyline,
};

struct CandidateOperation {
  std::string operation_type;
  CandidateShapeKind shape_kind {};
  std::string layer_name;
  Coordinate width_microns {};
  Coordinate height_microns {};
  Coordinate diameter_microns {};
  Coordinate radius_microns {};
  Coordinate offset_x_microns {};
  Coordinate offset_y_microns {};
  Coordinate depth_microns {};
  std::vector<Point> points;
};

struct CandidateDxfResult {
  bool valid {};
  std::size_t entity_count {};
  std::vector<ValidationIssue> issues;
};

[[nodiscard]] std::vector<CandidateOperation> read_candidate_manifest(
  const std::filesystem::path& manifest_path
);

[[nodiscard]] CandidateDxfResult write_candidate_dxf(
  const std::vector<CandidateOperation>& operations,
  const std::filesystem::path& output_path
);

}  // namespace worktop
