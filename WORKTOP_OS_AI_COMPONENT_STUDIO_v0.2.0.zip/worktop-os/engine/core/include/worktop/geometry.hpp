#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace worktop {

using Coordinate = std::int64_t;

struct Point {
  Coordinate x_microns {};
  Coordinate y_microns {};

  [[nodiscard]] bool operator==(const Point& other) const = default;
};

struct Polygon {
  std::string id;
  std::vector<Point> points;
};

struct ValidationIssue {
  std::string code;
  std::string message;
  bool blocking {};
};

struct GeometryResult {
  bool valid {};
  double area_square_mm {};
  double perimeter_mm {};
  std::vector<ValidationIssue> issues;
};

[[nodiscard]] Polygon make_rectangle(
  std::string id,
  Coordinate width_microns,
  Coordinate height_microns
);

[[nodiscard]] GeometryResult validate_polygon(const Polygon& polygon);

}  // namespace worktop
