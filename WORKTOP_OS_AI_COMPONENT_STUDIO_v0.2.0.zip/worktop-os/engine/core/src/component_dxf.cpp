#include "worktop/component_dxf.hpp"

#include <algorithm>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string_view>

namespace worktop {
namespace {

constexpr double microns_per_mm = 1000.0;
constexpr double quarter_circle_bulge = 0.4142135623730950;

[[nodiscard]] double mm(const Coordinate value) {
  return static_cast<double>(value) / microns_per_mm;
}

[[nodiscard]] std::vector<std::string> split(const std::string& value, const char delimiter) {
  std::vector<std::string> parts;
  std::stringstream stream(value);
  std::string part;
  while (std::getline(stream, part, delimiter)) parts.push_back(part);
  return parts;
}

[[nodiscard]] Coordinate coordinate(const std::string& value) {
  if (value.empty()) return 0;
  return static_cast<Coordinate>(std::stoll(value));
}

[[nodiscard]] CandidateShapeKind shape_kind(const std::string& value) {
  if (value == "RECTANGLE") return CandidateShapeKind::rectangle;
  if (value == "ROUNDED_RECTANGLE") return CandidateShapeKind::rounded_rectangle;
  if (value == "CIRCLE") return CandidateShapeKind::circle;
  if (value == "POLYLINE") return CandidateShapeKind::polyline;
  throw std::runtime_error("Niet-ondersteunde kandidaatvorm: " + value);
}

[[nodiscard]] std::vector<Point> parse_points(const std::string& value) {
  std::vector<Point> points;
  if (value.empty() || value == "-") return points;
  for (const auto& item : split(value, ';')) {
    const auto coordinates = split(item, ',');
    if (coordinates.size() != 2U) throw std::runtime_error("Ongeldig punt in manifest.");
    points.push_back(Point {
      .x_microns = coordinate(coordinates[0]),
      .y_microns = coordinate(coordinates[1]),
    });
  }
  return points;
}

void pair(std::ostream& output, const int code, const std::string_view value) {
  output << code << '\n' << value << '\n';
}

void pair(std::ostream& output, const int code, const double value) {
  output << code << '\n' << std::fixed << std::setprecision(6) << value << '\n';
}

void pair(std::ostream& output, const int code, const int value) {
  output << code << '\n' << value << '\n';
}

struct Vertex {
  double x {};
  double y {};
  double bulge {};
};

void write_polyline(std::ostream& output, const CandidateOperation& operation, const std::vector<Vertex>& vertices) {
  pair(output, 0, "LWPOLYLINE");
  pair(output, 8, operation.layer_name);
  pair(output, 90, static_cast<int>(vertices.size()));
  pair(output, 70, 1);
  for (const auto& vertex : vertices) {
    pair(output, 10, vertex.x);
    pair(output, 20, vertex.y);
    if (std::abs(vertex.bulge) > 0.0000001) pair(output, 42, vertex.bulge);
  }
}

[[nodiscard]] std::vector<Vertex> rectangle_vertices(const CandidateOperation& operation) {
  const auto x = mm(operation.offset_x_microns);
  const auto y = mm(operation.offset_y_microns);
  const auto width = mm(operation.width_microns);
  const auto height = mm(operation.height_microns);
  const auto left = x - width / 2.0;
  const auto right = x + width / 2.0;
  const auto bottom = y - height / 2.0;
  const auto top = y + height / 2.0;
  return {{left, bottom, 0}, {right, bottom, 0}, {right, top, 0}, {left, top, 0}};
}

[[nodiscard]] std::vector<Vertex> rounded_rectangle_vertices(const CandidateOperation& operation) {
  const auto x = mm(operation.offset_x_microns);
  const auto y = mm(operation.offset_y_microns);
  const auto width = mm(operation.width_microns);
  const auto height = mm(operation.height_microns);
  const auto radius = mm(operation.radius_microns);
  const auto left = x - width / 2.0;
  const auto right = x + width / 2.0;
  const auto bottom = y - height / 2.0;
  const auto top = y + height / 2.0;
  return {
    {left + radius, bottom, 0},
    {right - radius, bottom, quarter_circle_bulge},
    {right, bottom + radius, 0},
    {right, top - radius, quarter_circle_bulge},
    {right - radius, top, 0},
    {left + radius, top, quarter_circle_bulge},
    {left, top - radius, 0},
    {left, bottom + radius, quarter_circle_bulge},
  };
}

bool validate_operation(const CandidateOperation& operation, std::vector<ValidationIssue>& issues) {
  const auto add = [&issues](std::string code, std::string message) {
    issues.push_back({.code = std::move(code), .message = std::move(message), .blocking = true});
  };
  if (operation.layer_name.empty()) add("EMPTY_LAYER", "Een kandidaatbewerking mist een DXF-laag.");
  if (operation.shape_kind == CandidateShapeKind::circle) {
    if (operation.diameter_microns <= 0) add("INVALID_DIAMETER", "Een cirkel vereist een positieve diameter.");
  } else if (operation.shape_kind == CandidateShapeKind::polyline) {
    if (operation.points.size() < 3U) {
      add("INVALID_POLYLINE", "Een polyline vereist minimaal drie punten.");
    } else {
      const auto polygon_result = validate_polygon(Polygon {.id = operation.operation_type, .points = operation.points});
      for (const auto& issue : polygon_result.issues) issues.push_back(issue);
      if (!polygon_result.valid && polygon_result.issues.empty()) {
        add("INVALID_POLYLINE", "De polyline vormt geen geldige contour.");
      }
    }
  } else {
    if (operation.width_microns <= 0 || operation.height_microns <= 0) {
      add("INVALID_SIZE", "Een rechthoekige vorm vereist positieve breedte en hoogte.");
    }
    if (operation.shape_kind == CandidateShapeKind::rounded_rectangle) {
      const auto maximum = std::min(operation.width_microns, operation.height_microns) / 2;
      if (operation.radius_microns <= 0 || operation.radius_microns > maximum) {
        add("INVALID_RADIUS", "De hoekradius past niet binnen de rechthoek.");
      }
    }
  }
  return issues.empty();
}

}  // namespace

std::vector<CandidateOperation> read_candidate_manifest(const std::filesystem::path& manifest_path) {
  std::ifstream input(manifest_path);
  if (!input) throw std::runtime_error("Kan kandidaatmanifest niet openen.");
  std::string line;
  if (!std::getline(input, line) || line != "WORKTOP_COMPONENT_DXF_V1") {
    throw std::runtime_error("Onbekende kandidaatmanifestversie.");
  }
  std::vector<CandidateOperation> operations;
  while (std::getline(input, line)) {
    if (line.empty() || line.starts_with('#')) continue;
    const auto values = split(line, '\t');
    if (values.size() != 12U || values[0] != "OP") {
      throw std::runtime_error("Ongeldige regel in kandidaatmanifest.");
    }
    operations.push_back(CandidateOperation {
      .operation_type = values[1],
      .shape_kind = shape_kind(values[2]),
      .layer_name = values[3],
      .width_microns = coordinate(values[4]),
      .height_microns = coordinate(values[5]),
      .diameter_microns = coordinate(values[6]),
      .radius_microns = coordinate(values[7]),
      .offset_x_microns = coordinate(values[8]),
      .offset_y_microns = coordinate(values[9]),
      .depth_microns = coordinate(values[10]),
      .points = parse_points(values[11]),
    });
  }
  return operations;
}

CandidateDxfResult write_candidate_dxf(
  const std::vector<CandidateOperation>& operations,
  const std::filesystem::path& output_path
) {
  CandidateDxfResult result;
  if (operations.empty()) {
    result.issues.push_back({.code = "NO_OPERATIONS", .message = "Geen ondersteunde bewerkingen gevonden.", .blocking = true});
    return result;
  }
  for (const auto& operation : operations) validate_operation(operation, result.issues);
  if (!result.issues.empty()) return result;

  std::filesystem::create_directories(output_path.parent_path());
  std::ofstream output(output_path, std::ios::trunc);
  if (!output) {
    result.issues.push_back({.code = "OUTPUT_FAILED", .message = "Kan kandidaat-DXF niet schrijven.", .blocking = true});
    return result;
  }

  pair(output, 0, "SECTION"); pair(output, 2, "HEADER");
  pair(output, 9, "$ACADVER"); pair(output, 1, "AC1015");
  pair(output, 9, "$INSUNITS"); pair(output, 70, 4);
  pair(output, 0, "ENDSEC");

  std::set<std::string> layers;
  for (const auto& operation : operations) layers.insert(operation.layer_name);
  pair(output, 0, "SECTION"); pair(output, 2, "TABLES");
  pair(output, 0, "TABLE"); pair(output, 2, "LAYER"); pair(output, 70, static_cast<int>(layers.size()));
  for (const auto& layer : layers) {
    pair(output, 0, "LAYER"); pair(output, 2, layer); pair(output, 70, 0); pair(output, 62, 7); pair(output, 6, "CONTINUOUS");
  }
  pair(output, 0, "ENDTAB"); pair(output, 0, "ENDSEC");

  pair(output, 0, "SECTION"); pair(output, 2, "ENTITIES");

  for (const auto& operation : operations) {
    pair(output, 999, "WORKTOP_OS_AI_CANDIDATE_NOT_VERIFIED");
    pair(output, 999, operation.operation_type + " DEPTH_UM=" + std::to_string(operation.depth_microns));
    if (operation.shape_kind == CandidateShapeKind::rectangle) {
      write_polyline(output, operation, rectangle_vertices(operation));
    } else if (operation.shape_kind == CandidateShapeKind::rounded_rectangle) {
      write_polyline(output, operation, rounded_rectangle_vertices(operation));
    } else if (operation.shape_kind == CandidateShapeKind::circle) {
      pair(output, 0, "CIRCLE"); pair(output, 8, operation.layer_name);
      pair(output, 10, mm(operation.offset_x_microns));
      pair(output, 20, mm(operation.offset_y_microns));
      pair(output, 40, mm(operation.diameter_microns) / 2.0);
    } else {
      std::vector<Vertex> vertices;
      vertices.reserve(operation.points.size());
      for (const auto& point : operation.points) {
        vertices.push_back({
          mm(point.x_microns + operation.offset_x_microns),
          mm(point.y_microns + operation.offset_y_microns),
          0,
        });
      }
      write_polyline(output, operation, vertices);
    }
    ++result.entity_count;
  }

  pair(output, 0, "ENDSEC"); pair(output, 0, "EOF");
  result.valid = output.good();
  if (!result.valid) {
    result.issues.push_back({.code = "WRITE_INCOMPLETE", .message = "Kandidaat-DXF is niet volledig geschreven.", .blocking = true});
  }
  return result;
}

}  // namespace worktop
