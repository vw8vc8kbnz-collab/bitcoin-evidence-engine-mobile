#include "worktop/component_dxf.hpp"
#include "worktop/geometry.hpp"

#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <string>

namespace {

[[nodiscard]] worktop::Coordinate parse_mm(const char* value) {
  return static_cast<worktop::Coordinate>(std::stod(value) * 1000.0);
}

int rectangle_command(const char* width, const char* height) {
  const auto polygon = worktop::make_rectangle(
    "cli-rectangle",
    parse_mm(width),
    parse_mm(height)
  );
  const auto result = worktop::validate_polygon(polygon);
  std::cout << std::fixed << std::setprecision(3)
            << "{\n"
            << "  \"engineVersion\": \"0.2.0\",\n"
            << "  \"valid\": " << (result.valid ? "true" : "false") << ",\n"
            << "  \"areaSquareMm\": " << result.area_square_mm << ",\n"
            << "  \"perimeterMm\": " << result.perimeter_mm << ",\n"
            << "  \"issueCount\": " << result.issues.size() << "\n"
            << "}\n";
  return result.valid ? EXIT_SUCCESS : EXIT_FAILURE;
}

int component_dxf_command(const char* manifest, const char* output) {
  try {
    const auto operations = worktop::read_candidate_manifest(manifest);
    const auto result = worktop::write_candidate_dxf(operations, output);
    std::cout << "{\n"
              << "  \"engineVersion\": \"0.2.0\",\n"
              << "  \"valid\": " << (result.valid ? "true" : "false") << ",\n"
              << "  \"entityCount\": " << result.entity_count << ",\n"
              << "  \"issueCount\": " << result.issues.size() << "\n"
              << "}\n";
    for (const auto& issue : result.issues) {
      std::cerr << issue.code << ": " << issue.message << '\n';
    }
    return result.valid ? EXIT_SUCCESS : EXIT_FAILURE;
  } catch (const std::exception& error) {
    std::cerr << "COMPONENT_DXF_FAILED: " << error.what() << '\n';
    return EXIT_FAILURE;
  }
}

}  // namespace

int main(int argc, char** argv) {
  if (argc == 4 && std::string(argv[1]) == "component-dxf") {
    return component_dxf_command(argv[2], argv[3]);
  }
  if (argc == 3) return rectangle_command(argv[1], argv[2]);

  std::cerr
    << "Gebruik:\n"
    << "  worktop-engine-cli <breedte-mm> <hoogte-mm>\n"
    << "  worktop-engine-cli component-dxf <manifest.tsv> <output.dxf>\n";
  return EXIT_FAILURE;
}
