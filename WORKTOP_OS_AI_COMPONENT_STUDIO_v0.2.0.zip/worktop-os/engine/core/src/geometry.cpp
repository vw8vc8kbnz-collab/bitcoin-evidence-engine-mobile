#include "worktop/geometry.hpp"

#include <cmath>
#include <utility>

namespace worktop {
namespace {

constexpr double microns_per_mm = 1000.0;

[[nodiscard]] double distance_mm(const Point& a, const Point& b) {
  const auto dx = static_cast<double>(b.x_microns - a.x_microns) / microns_per_mm;
  const auto dy = static_cast<double>(b.y_microns - a.y_microns) / microns_per_mm;
  return std::hypot(dx, dy);
}

}  // namespace

Polygon make_rectangle(
  std::string id,
  const Coordinate width_microns,
  const Coordinate height_microns
) {
  return Polygon {
    .id = std::move(id),
    .points = {
      Point {.x_microns = 0, .y_microns = 0},
      Point {.x_microns = width_microns, .y_microns = 0},
      Point {.x_microns = width_microns, .y_microns = height_microns},
      Point {.x_microns = 0, .y_microns = height_microns},
    },
  };
}

GeometryResult validate_polygon(const Polygon& polygon) {
  GeometryResult result;

  if (polygon.points.size() < 3U) {
    result.issues.push_back({
      .code = "POLYGON_TOO_SMALL",
      .message = "Een contour heeft minimaal drie unieke punten nodig.",
      .blocking = true,
    });
    return result;
  }

  long double twice_area_microns = 0.0L;
  double perimeter = 0.0;

  for (std::size_t index = 0; index < polygon.points.size(); ++index) {
    const auto& current = polygon.points[index];
    const auto& next = polygon.points[(index + 1U) % polygon.points.size()];

    if (current == next) {
      result.issues.push_back({
        .code = "ZERO_LENGTH_EDGE",
        .message = "De contour bevat een segment met lengte nul.",
        .blocking = true,
      });
    }

    twice_area_microns +=
      static_cast<long double>(current.x_microns) * static_cast<long double>(next.y_microns)
      - static_cast<long double>(next.x_microns) * static_cast<long double>(current.y_microns);

    perimeter += distance_mm(current, next);
  }

  result.area_square_mm =
    std::abs(static_cast<double>(twice_area_microns)) / 2.0 / (microns_per_mm * microns_per_mm);
  result.perimeter_mm = perimeter;
  result.valid = result.area_square_mm > 0.0
    && result.issues.empty();

  if (result.area_square_mm <= 0.0) {
    result.issues.push_back({
      .code = "ZERO_AREA",
      .message = "De contour heeft geen bruikbaar oppervlak.",
      .blocking = true,
    });
    result.valid = false;
  }

  return result;
}

}  // namespace worktop
