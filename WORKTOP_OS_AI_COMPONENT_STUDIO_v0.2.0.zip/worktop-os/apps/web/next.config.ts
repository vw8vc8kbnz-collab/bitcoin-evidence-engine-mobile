import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  reactStrictMode: true,
  transpilePackages: [
    "@worktop/domain",
    "@worktop/contracts",
    "@worktop/ai-ingestion",
    "@worktop/data",
  ],
  serverExternalPackages: ["pg"],
  experimental: { cpus: 4 },
};

export default nextConfig;
