import { PageHeader } from "@/components/PageHeader";
import { AiIngestionWorkspace } from "@/features/ai-ingestion/AiIngestionWorkspace";

export default function AiIngestionPage() {
  return (
    <>
      <PageHeader title="AI Component Ingestion" description="Van officiële productdocumentatie naar een traceerbare componentkandidaat voor menselijke verificatie." />
      <AiIngestionWorkspace />
    </>
  );
}
