import { Bot, Plus, Upload } from "lucide-react";
import Link from "next/link";
import { Button } from "@/components/Buttons";
import { PageHeader } from "@/components/PageHeader";
import { ProductLibraryGrid } from "@/features/library/ProductLibraryGrid";

export default function LibraryPage() {
  return (
    <>
      <PageHeader
        title="Product Library"
        description="Vind geverifieerde componenten en sleep ze direct naar een werkblad."
        actions={
          <div className="flex gap-3">
            <Link href="/library/ai-ingestion" className="inline-flex items-center gap-2 rounded-lg border border-blue-600 bg-blue-600 px-4 py-2.5 text-sm font-medium text-white shadow-sm transition hover:bg-blue-700">
              <Bot size={17} /> AI Component Studio
            </Link>
            <Button><Upload size={17} /> Catalogus importeren</Button>
            <Button variant="primary"><Plus size={17} /> Product toevoegen</Button>
          </div>
        }
      />
      <ProductLibraryGrid />
    </>
  );
}
