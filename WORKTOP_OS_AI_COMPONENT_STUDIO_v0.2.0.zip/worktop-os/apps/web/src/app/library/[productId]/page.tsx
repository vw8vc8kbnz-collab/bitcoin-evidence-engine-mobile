import { notFound } from "next/navigation";
import { products } from "@/data/demo";
import { ProductDetail } from "@/features/library/ProductDetail";

export default async function ProductDetailPage({ params }: { params: Promise<{ productId: string }> }) {
  const { productId } = await params;
  const product = products.find((item) => item.id === productId);
  if (!product) notFound();
  return <ProductDetail product={product} />;
}
