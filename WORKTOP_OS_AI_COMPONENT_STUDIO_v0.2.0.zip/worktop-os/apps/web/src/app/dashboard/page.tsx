import { PageHeader } from "@/components/PageHeader";
import { DashboardMetrics } from "@/features/dashboard/DashboardMetrics";
import { RecentProjectsTable } from "@/features/dashboard/RecentProjectsTable";
import { DashboardSidePanels } from "@/features/dashboard/DashboardSidePanels";

export default function DashboardPage() {
  return (
    <>
      <PageHeader title="Dashboard" description="Overzicht van projecten, productie en systeemstatus." />
      <DashboardMetrics />
      <div className="mt-5 grid grid-cols-[minmax(0,1fr)_380px] gap-5">
        <RecentProjectsTable />
        <DashboardSidePanels />
      </div>
    </>
  );
}
