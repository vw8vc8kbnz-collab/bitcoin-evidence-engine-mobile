import { PageHeader } from "@/components/PageHeader";
import { ValidationWorkspace } from "@/features/validation/ValidationWorkspace";

export default function ValidationPage() {
  return (
    <>
      <PageHeader title="Validatie & export" description="Controleer, geef vrij en genereer een reproduceerbaar productiepakket." />
      <ValidationWorkspace />
    </>
  );
}
