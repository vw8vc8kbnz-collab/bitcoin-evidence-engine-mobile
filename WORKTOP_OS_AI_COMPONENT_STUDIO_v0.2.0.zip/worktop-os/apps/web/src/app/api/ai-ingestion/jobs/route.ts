import { NextResponse } from "next/server";
import { listIngestionJobs } from "@worktop/data";

export const runtime = "nodejs";

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const limit = Number(url.searchParams.get("limit") ?? 20);
    const jobs = await listIngestionJobs(Number.isFinite(limit) ? limit : 20);
    return NextResponse.json({ ok: true, jobs });
  } catch (error) {
    return NextResponse.json(
      { ok: false, error: error instanceof Error ? error.message : "Kon analyses niet laden." },
      { status: 500 },
    );
  }
}
