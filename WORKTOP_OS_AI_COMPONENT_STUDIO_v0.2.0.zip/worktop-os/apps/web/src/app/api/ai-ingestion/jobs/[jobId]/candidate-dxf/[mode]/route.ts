import { readFile } from "node:fs/promises";
import path from "node:path";
import { NextResponse } from "next/server";
import { getIngestionJob } from "@worktop/data";

export const runtime = "nodejs";

export async function GET(
  _request: Request,
  context: { params: Promise<{ jobId: string; mode: string }> },
) {
  try {
    const { jobId, mode } = await context.params;
    const job = await getIngestionJob(jobId);
    if (!job) return NextResponse.json({ ok: false, error: "Analyse niet gevonden." }, { status: 404 });
    const asset = job.generatedAssets.assets.find((item) => item.installationMode === mode);
    if (!asset) return NextResponse.json({ ok: false, error: "Kandidaat-DXF niet gevonden." }, { status: 404 });

    const expectedRoot = process.env.WORKTOP_DATA_DIR
      ? path.resolve(process.env.WORKTOP_DATA_DIR, "ai-ingestion", jobId, "generated")
      : path.resolve(process.cwd(), "data", "ai-ingestion", jobId, "generated");
    const resolvedPath = path.resolve(asset.storagePath);
    if (!resolvedPath.startsWith(`${expectedRoot}${path.sep}`)) {
      return NextResponse.json({ ok: false, error: "Ongeldig assetpad." }, { status: 403 });
    }
    const contents = await readFile(resolvedPath);
    return new NextResponse(contents, {
      headers: {
        "Content-Type": "application/dxf",
        "Content-Disposition": `attachment; filename="${path.basename(asset.fileName)}"`,
        "Cache-Control": "private, no-store",
        "X-Worktop-Verification": "AI_CANDIDATE_NOT_VERIFIED",
      },
    });
  } catch (error) {
    return NextResponse.json(
      { ok: false, error: error instanceof Error ? error.message : "Kon kandidaat-DXF niet laden." },
      { status: 500 },
    );
  }
}
