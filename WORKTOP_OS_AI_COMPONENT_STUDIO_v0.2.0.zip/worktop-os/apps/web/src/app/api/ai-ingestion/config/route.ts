import { NextResponse } from "next/server";

export const runtime = "nodejs";

export async function GET() {
  return NextResponse.json({
    configured: Boolean(process.env.OPENAI_API_KEY),
    model: process.env.OPENAI_INGESTION_MODEL ?? "gpt-5.6",
    verifierEnabled: process.env.OPENAI_INGESTION_VERIFIER !== "false",
    databaseConfigured: Boolean(process.env.DATABASE_URL),
  });
}
