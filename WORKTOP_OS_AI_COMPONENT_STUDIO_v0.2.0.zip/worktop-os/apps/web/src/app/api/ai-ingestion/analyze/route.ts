import { randomUUID } from "node:crypto";
import { NextResponse } from "next/server";
import {
  createIngestionJob,
  saveExtractionCandidate,
  saveGeneratedAssets,
  updateIngestionJobStatus,
} from "@worktop/data";
import { analyzeComponentSources } from "@/server/ai-ingestion/openai-analyzer";
import { generateCandidateDxfs } from "@/server/geometry/candidate-dxf-generator";
import { storeIngestionFiles } from "@/server/storage/local-file-storage";

export const runtime = "nodejs";
export const maxDuration = 300;

function optionalText(formData: FormData, key: string): string | undefined {
  const value = formData.get(key);
  if (typeof value !== "string") return undefined;
  const trimmed = value.trim();
  return trimmed || undefined;
}

function errorResponse(error: unknown, jobId?: string) {
  const message = error instanceof Error ? error.message : "Onbekende serverfout.";
  return NextResponse.json({ ok: false, jobId, error: message }, { status: 400 });
}

export async function POST(request: Request) {
  let jobId: string | undefined;
  try {
    if (!process.env.OPENAI_API_KEY) throw new Error("OpenAI API-key is nog niet ingesteld op de server.");
    if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL is nog niet ingesteld op de server.");
    const formData = await request.formData();
    const rightsConfirmed = formData.get("rightsConfirmed") === "true";
    if (!rightsConfirmed) throw new Error("Bevestig eerst dat de bestanden binnen jouw organisatie verwerkt mogen worden.");
    const files = formData.getAll("files").filter((entry): entry is File => entry instanceof File);
    const hasImage = files.some((file) => file.type.startsWith("image/"));
    const hasOfficialDocument = files.some((file) => file.type === "application/pdf" || file.name.toLowerCase().endsWith(".pdf"));
    if (!hasImage) throw new Error("Upload minimaal één echte productfoto.");
    if (!hasOfficialDocument) throw new Error("Upload minimaal één officiële fabrikant-PDF.");

    jobId = randomUUID();
    const manufacturerHint = optionalText(formData, "manufacturerHint");
    const modelHint = optionalText(formData, "modelHint");
    const notes = optionalText(formData, "notes");
    const rightsScope = formData.get("rightsScope") === "PLATFORM_LICENSED"
      ? "PLATFORM_LICENSED"
      : "TENANT_PRIVATE";
    const sources = await storeIngestionFiles({ jobId, files, rightsScope });
    const model = process.env.OPENAI_INGESTION_MODEL ?? "gpt-5.6";

    await createIngestionJob({
      id: jobId,
      status: "AI_ANALYZING",
      manufacturerHint,
      modelHint,
      notes,
      requestedBy: "current-user",
      openaiModel: model,
      sources: sources.map((source) => source.manifest),
    });

    const analyzed = await analyzeComponentSources({
      sources,
      manufacturerHint,
      modelHint,
      notes,
    });
    const candidateId = randomUUID();
    await saveExtractionCandidate(jobId, candidateId, analyzed.result);
    const geometryGeneration = await generateCandidateDxfs(jobId, analyzed.result);
    await saveGeneratedAssets(jobId, geometryGeneration);
    return NextResponse.json({
      ok: true,
      jobId,
      candidateId,
      model: analyzed.model,
      passes: analyzed.passes,
      result: analyzed.result,
      geometryGeneration,
    });
  } catch (error) {
    if (jobId) {
      try {
        await updateIngestionJobStatus(jobId, "FAILED", error instanceof Error ? error.message : "Onbekende fout");
      } catch {
        // The original failure remains the useful error for the client.
      }
    }
    return errorResponse(error, jobId);
  }
}
