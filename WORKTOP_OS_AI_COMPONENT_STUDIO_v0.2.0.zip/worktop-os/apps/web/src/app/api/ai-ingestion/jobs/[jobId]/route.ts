import { NextResponse } from "next/server";
import { getIngestionJob } from "@worktop/data";

export const runtime = "nodejs";

export async function GET(_request: Request, context: { params: Promise<{ jobId: string }> }) {
  try {
    const { jobId } = await context.params;
    const job = await getIngestionJob(jobId);
    if (!job) return NextResponse.json({ ok: false, error: "Analyse niet gevonden." }, { status: 404 });
    return NextResponse.json({ ok: true, job });
  } catch (error) {
    return NextResponse.json(
      { ok: false, error: error instanceof Error ? error.message : "Kon analyse niet laden." },
      { status: 500 },
    );
  }
}
