import { NextResponse } from "next/server";
import { getPool } from "@worktop/data";

export const runtime = "nodejs";

export async function GET() {
  let database = false;
  try {
    await getPool().query("SELECT 1");
    database = true;
  } catch {
    database = false;
  }
  const healthy = database;
  return NextResponse.json(
    {
      ok: healthy,
      version: "0.2.0",
      service: "worktop-os",
      database,
      openaiConfigured: Boolean(process.env.OPENAI_API_KEY),
      ingestionModel: process.env.OPENAI_INGESTION_MODEL ?? "gpt-5.6",
    },
    { status: healthy ? 200 : 503 },
  );
}
