import { PageHeader } from "@/components/PageHeader";
import { NestingWorkspace } from "@/features/nesting/NestingWorkspace";

export default function NestingPage() {
  return (
    <>
      <PageHeader title="Nesting & optimalisatie" description="Vergelijk uitlegbare C++-solverresultaten voor materiaal, tijd en nerf." />
      <NestingWorkspace />
    </>
  );
}
