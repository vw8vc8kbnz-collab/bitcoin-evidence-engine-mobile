import { EmptyFeaturePage } from "@/components/EmptyFeaturePage";

export default function Page() {
  return <EmptyFeaturePage title="Restplaten" />;
}
