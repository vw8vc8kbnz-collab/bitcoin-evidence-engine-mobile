import { PageHeader } from "@/components/PageHeader";
import { MaterialsWorkspace } from "@/features/materials/MaterialsWorkspace";

export default function MaterialsPage() {
  return (
    <>
      <PageHeader title="Materialen & platen" description="Beheer volle platen, reststukken en unieke materiaalbeelden." />
      <MaterialsWorkspace />
    </>
  );
}
