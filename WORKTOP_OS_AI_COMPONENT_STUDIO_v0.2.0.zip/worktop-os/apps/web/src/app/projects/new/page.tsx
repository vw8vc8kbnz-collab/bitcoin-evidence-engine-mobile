import { PageHeader } from "@/components/PageHeader";
import { NewProjectWizard } from "@/features/projects/NewProjectWizard";

export default function NewProjectPage() {
  return (
    <>
      <PageHeader title="Nieuw project" description="Bouw een nieuwe werkbladorder op vanuit één helder contract." />
      <NewProjectWizard />
    </>
  );
}
