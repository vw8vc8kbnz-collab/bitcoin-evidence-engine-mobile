import { Plus, Search } from "lucide-react";
import Link from "next/link";
import { Button } from "@/components/Buttons";
import { PageHeader } from "@/components/PageHeader";
import { ProjectsTable } from "@/features/projects/ProjectsTable";
import { ProjectSummary } from "@/features/projects/ProjectSummary";

export default function ProjectsPage() {
  return (
    <>
      <PageHeader
        title="Projecten"
        description="Beheer alle werkbladorders van ontwerp tot productie."
        actions={<Link href="/projects/new"><Button variant="primary"><Plus size={17} /> Nieuw project</Button></Link>}
      />
      <div className="mb-5 flex gap-3">
        <div className="flex w-[360px] items-center gap-2 rounded-lg border border-slate-200 bg-white px-3">
          <Search size={17} className="text-slate-400" />
          <input className="w-full py-2.5 text-sm outline-none" placeholder="Zoek project, order of klant..." />
        </div>
        {["Status", "Eigenaar", "Materiaal", "Datum"].map((label) => (
          <button key={label} className="rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm text-slate-600">{label} ▾</button>
        ))}
      </div>
      <div className="grid grid-cols-[minmax(0,1fr)_330px] gap-5">
        <ProjectsTable />
        <ProjectSummary />
      </div>
    </>
  );
}
