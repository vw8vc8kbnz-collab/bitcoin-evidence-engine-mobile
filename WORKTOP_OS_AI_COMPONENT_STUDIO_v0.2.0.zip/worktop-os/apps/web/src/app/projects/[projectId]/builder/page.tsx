import { Save, Send } from "lucide-react";
import { Button } from "@/components/Buttons";
import { PageHeader } from "@/components/PageHeader";
import { BuilderWorkspace } from "@/features/builder/BuilderWorkspace";

export default async function BuilderPage({ params }: { params: Promise<{ projectId: string }> }) {
  await params;
  return (
    <>
      <PageHeader
        title="Werkbladeditor"
        description="Horizon Ridge Residence · één canonical model voor 2D en 3D."
        actions={<div className="flex gap-3"><Button><Save size={17} /> Opslaan</Button><Button variant="primary"><Send size={17} /> Publiceer naar productie</Button></div>}
      />
      <BuilderWorkspace />
    </>
  );
}
