import { PageHeader } from "@/components/PageHeader";
import { DxfImportWorkspace } from "@/features/dxf/DxfImportWorkspace";

export default function DxfImportPage() {
  return (
    <>
      <PageHeader title="DXF Import Wizard" description="Analyseer, interpreteer en herstel invoergeometrie gecontroleerd." />
      <DxfImportWorkspace />
    </>
  );
}
