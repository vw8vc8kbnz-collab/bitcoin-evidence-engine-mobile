export const copy = {
  appName: "Worktop OS",
  searchPlaceholder: "Zoek projecten, producten, platen...",
  tenant: "StoneFab Surfaces",
  userName: "Stijn Rutte",
} as const;
