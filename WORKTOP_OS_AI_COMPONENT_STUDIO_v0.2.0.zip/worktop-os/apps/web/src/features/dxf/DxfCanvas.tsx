export function DxfCanvas() {
  return (
    <div className="blueprint-grid relative h-[390px] overflow-hidden rounded-xl border border-slate-700">
      <svg viewBox="0 0 900 460" className="h-full w-full">
        <path d="M90 100 H740 Q790 100 790 150 V330 H620 V380 H430 V330 H90 Z" fill="none" stroke="#f8fafc" strokeWidth="3" />
        <rect x="180" y="150" width="170" height="130" rx="24" fill="none" stroke="#f8fafc" strokeWidth="3" />
        <circle cx="265" cy="215" r="13" fill="none" stroke="#f8fafc" strokeWidth="2" />
        <rect x="540" y="160" width="160" height="140" rx="8" fill="none" stroke="#f8fafc" strokeWidth="3" />
        {[0,1,2,3].map((i) => <circle key={i} cx={585 + (i%2)*65} cy={202 + Math.floor(i/2)*58} r="23" fill="none" stroke="#f8fafc" strokeWidth="2" />)}
        <path d="M430 100 V250" stroke="#f97316" strokeWidth="4" strokeDasharray="8 6" />
        <circle cx="90" cy="330" r="12" fill="none" stroke="#ef4444" strokeWidth="4" />
      </svg>
      <div className="absolute bottom-3 left-3 rounded bg-slate-950/80 px-3 py-2 text-xs text-slate-300">Eenheid: mm · Schaal 1:20</div>
    </div>
  );
}
