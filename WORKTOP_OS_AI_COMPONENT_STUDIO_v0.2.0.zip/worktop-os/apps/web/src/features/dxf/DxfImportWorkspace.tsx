import { AlertCircle, CheckCircle2, FileCode2, Upload } from "lucide-react";
import { Button } from "@/components/Buttons";
import { DxfCanvas } from "./DxfCanvas";

const issues = [
  ["Open contouren", "2", "red"],
  ["Dubbele segmenten", "8", "amber"],
  ["Zelfsnijdingen", "1", "red"],
  ["Microlijnen", "34", "blue"],
];

const layers = [
  ["OUTER_CONTOUR", "Buitencontour", "Profiel"],
  ["SINK_CUTOUT", "Spoelbakuitsparing", "Uitsparing"],
  ["HOB_CUTOUT", "Kookplaatuitsparing", "Uitsparing"],
  ["DRILL_HOLES", "Boorgaten", "Boring"],
  ["TEXT", "Tekst", "Annotatie"],
];

export function DxfImportWorkspace() {
  return (
    <div className="space-y-5">
      <div className="grid grid-cols-[260px_minmax(0,1fr)_330px] gap-5">
        <section className="app-card p-4">
          <h2 className="font-semibold">DXF-bestand</h2>
          <div className="mt-4 rounded-xl border border-dashed border-blue-300 bg-blue-50 p-5 text-center">
            <Upload className="mx-auto text-blue-600" />
            <p className="mt-2 text-sm font-medium">Sleep een DXF hierheen</p>
          </div>
          <div className="mt-4 flex items-center gap-3 rounded-xl border border-slate-200 p-3">
            <FileCode2 className="text-blue-600" />
            <div>
              <p className="text-sm font-medium">Kitchen_Plan.dxf</p>
              <p className="text-xs text-slate-500">2,43 MB · R2018</p>
            </div>
          </div>
          <dl className="mt-5 space-y-2 text-sm">
            <Info label="Eenheden" value="Millimeter" />
            <Info label="Entiteiten" value="4.892" />
            <Info label="Layers" value="18" />
            <Info label="Schaalvertrouwen" value="98%" />
          </dl>
        </section>

        <section className="app-card p-4">
          <h2 className="mb-4 font-semibold">Geometriepreview</h2>
          <DxfCanvas />
        </section>

        <section className="app-card p-4">
          <h2 className="font-semibold">Analyseresultaten</h2>
          <div className="mt-4 space-y-2">
            {issues.map(([label, count, tone]) => (
              <div key={label} className="flex items-center gap-3 rounded-xl border border-slate-200 p-3">
                <AlertCircle size={17} className={tone === "red" ? "text-red-500" : tone === "amber" ? "text-amber-500" : "text-blue-500"} />
                <span className="text-sm">{label}</span>
                <span className="ml-auto text-sm font-semibold">{count}</span>
              </div>
            ))}
            <div className="flex items-center gap-3 rounded-xl border border-emerald-200 bg-emerald-50 p-3">
              <CheckCircle2 size={17} className="text-emerald-500" />
              <span className="text-sm">Schaalstatus geldig</span>
            </div>
          </div>
        </section>
      </div>

      <div className="grid grid-cols-[minmax(0,1fr)_420px] gap-5">
        <section className="app-card p-4">
          <h2 className="font-semibold">Layer mapping</h2>
          <div className="mt-4">
            {layers.map(([layer, description, mapping]) => (
              <div key={layer} className="grid grid-cols-[1fr_1fr_1fr] border-b border-slate-100 py-3 text-sm">
                <span className="font-mono text-xs text-slate-600">{layer}</span>
                <span>{description}</span>
                <span className="text-blue-600">{mapping}</span>
              </div>
            ))}
          </div>
        </section>
        <section className="app-card p-4">
          <h2 className="font-semibold">Importopties</h2>
          <div className="mt-4 space-y-3">
            {["Collineaire segmenten samenvoegen", "Dubbele entiteiten verwijderen", "Kleine gaten herstellen", "Boogradii behouden"].map((label) => (
              <label key={label} className="flex items-center gap-3 text-sm">
                <input type="checkbox" defaultChecked className="h-4 w-4 accent-blue-600" />
                {label}
              </label>
            ))}
          </div>
        </section>
      </div>
      <div className="flex justify-end gap-3">
        <Button>Opslaan en sluiten</Button>
        <Button variant="primary">Volgende: geometrieanalyse</Button>
      </div>
    </div>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return <div className="flex justify-between"><dt className="text-slate-500">{label}</dt><dd className="font-medium">{value}</dd></div>;
}
