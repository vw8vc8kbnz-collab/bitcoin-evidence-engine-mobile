import Image from "next/image";
import { Plus, Search } from "lucide-react";
import { products } from "@/data/demo";

export function ComponentTray() {
  return (
    <aside className="app-card h-full overflow-hidden">
      <div className="border-b border-slate-200 p-4">
        <h2 className="font-semibold">Componenten</h2>
        <div className="mt-3 flex items-center gap-2 rounded-lg border border-slate-200 px-3">
          <Search size={16} className="text-slate-400" />
          <input className="w-full py-2 text-sm outline-none" placeholder="Zoek component..." />
        </div>
      </div>
      <div className="scrollbar-thin h-[700px] overflow-y-auto p-3">
        <p className="px-1 pb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">Kookplaten</p>
        {products.filter((p) => p.category === "COOKTOP").map((product, index) => (
          <TrayCard key={product.id} product={product} active={index === 0} />
        ))}
        <p className="mt-5 px-1 pb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">Spoelbakken</p>
        {products.filter((p) => p.category === "SINK").map((product) => <TrayCard key={product.id} product={product} />)}
        <button className="mt-4 flex w-full items-center justify-center gap-2 rounded-lg border border-slate-200 py-2 text-sm text-slate-600">
          <Plus size={16} /> Eigen component
        </button>
      </div>
    </aside>
  );
}

function TrayCard({ product, active = false }: { product: (typeof products)[number]; active?: boolean }) {
  return (
    <div className={`mb-3 rounded-xl border p-3 ${active ? "border-blue-500 bg-blue-50" : "border-slate-200 bg-white"}`}>
      <div className="flex gap-3">
        <div className="relative h-16 w-20 overflow-hidden rounded-lg bg-slate-100">
          <Image src={product.images[0].src} alt={product.images[0].alt} fill className="object-cover" />
        </div>
        <div>
          <p className="text-sm font-medium">{product.model}</p>
          <p className="text-xs text-slate-500">{product.cutoutLabel}</p>
        </div>
      </div>
    </div>
  );
}
