import { AlertTriangle, CheckCircle2 } from "lucide-react";
import { ComponentTray } from "./ComponentTray";
import { BuilderCanvas2D } from "./BuilderCanvas2D";
import { WorktopPreview3D } from "./WorktopPreview3D";
import { PropertiesPanel } from "./PropertiesPanel";

export function BuilderWorkspace() {
  return (
    <>
      <div className="grid grid-cols-[250px_minmax(0,1fr)_300px] gap-4">
        <ComponentTray />
        <div className="space-y-4">
          <BuilderCanvas2D />
          <WorktopPreview3D />
        </div>
        <PropertiesPanel />
      </div>
      <div className="app-card mt-4 grid grid-cols-5 gap-3 p-3">
        <Check label="Exact gepositioneerd" />
        <Check label="Materiaalregels OK" />
        <Check label="Randafstanden OK" />
        <Warning label="Dicht bij rechterrand" />
        <Check label="Geen conflicten" />
      </div>
    </>
  );
}

function Check({ label }: { label: string }) {
  return <div className="flex items-center gap-2 rounded-lg bg-emerald-50 p-3 text-sm text-emerald-800"><CheckCircle2 size={17} /> {label}</div>;
}
function Warning({ label }: { label: string }) {
  return <div className="flex items-center gap-2 rounded-lg bg-amber-50 p-3 text-sm text-amber-800"><AlertTriangle size={17} /> {label}</div>;
}
