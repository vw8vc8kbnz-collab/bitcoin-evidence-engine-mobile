"use client";

import { Canvas } from "@react-three/fiber";
import { ContactShadows, OrbitControls } from "@react-three/drei";
import { useBuilderStore } from "./builder-store";

export function WorktopPreview3D() {
  const { cooktopX, cooktopY, installationMode } = useBuilderStore();
  const x = ((cooktopX - 50) / 50) * 3.1;
  const z = ((cooktopY - 50) / 50) * 1.15;
  const topY = installationMode === "FLUSH_MOUNT" ? 0.22 : 0.28;

  return (
    <div className="app-card overflow-hidden">
      <div className="flex items-center justify-between border-b border-slate-200 px-4 py-3">
        <h2 className="font-semibold">Live 3D-preview</h2>
        <span className="text-xs text-slate-500">Gekoppeld aan dezelfde editorstate</span>
      </div>
      <div className="h-[330px] bg-gradient-to-b from-slate-50 to-slate-200">
        <Canvas camera={{ position: [6.8, 5.2, 7.2], fov: 38 }}>
          <ambientLight intensity={1.8} />
          <directionalLight position={[5, 8, 4]} intensity={2.4} castShadow />
          <group rotation={[0, -0.08, 0]}>
            <mesh position={[0, 0, 0]} castShadow receiveShadow>
              <boxGeometry args={[8, 0.42, 3]} />
              <meshStandardMaterial color="#e9e2d5" roughness={0.78} />
            </mesh>
            <mesh position={[-2.1, 0.16, 0.1]} castShadow>
              <boxGeometry args={[1.9, 0.2, 1.45]} />
              <meshStandardMaterial color="#525b63" metalness={0.65} roughness={0.3} />
            </mesh>
            <mesh position={[-2.1, 0.28, 0.1]}>
              <boxGeometry args={[1.45, 0.04, 1.05]} />
              <meshStandardMaterial color="#1f2937" />
            </mesh>
            <mesh position={[x, topY, z]} castShadow>
              <boxGeometry args={[1.85, 0.09, 1.24]} />
              <meshStandardMaterial color="#07090d" roughness={0.18} />
            </mesh>
            {[[-0.42,-0.28],[0.42,-0.28],[-0.42,0.28],[0.42,0.28]].map(([dx,dz], i) => (
              <mesh key={i} position={[x + dx, topY + 0.051, z + dz]} rotation={[-Math.PI/2,0,0]}>
                <ringGeometry args={[0.18, 0.28, 40]} />
                <meshStandardMaterial color="#4b5563" />
              </mesh>
            ))}
          </group>
          <ContactShadows opacity={0.26} scale={14} blur={2.5} far={12} />
          <OrbitControls makeDefault minDistance={5} maxDistance={14} />
        </Canvas>
      </div>
    </div>
  );
}
