"use client";

import { useRef, useState } from "react";
import { useBuilderStore } from "./builder-store";

export function BuilderCanvas2D() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [dragging, setDragging] = useState(false);
  const { cooktopX, cooktopY, setCooktopPosition, installationMode, setInstallationMode } = useBuilderStore();

  function handleMove(event: React.PointerEvent<HTMLDivElement>) {
    if (!dragging || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = Math.max(18, Math.min(80, ((event.clientX - rect.left) / rect.width) * 100));
    const y = Math.max(18, Math.min(74, ((event.clientY - rect.top) / rect.height) * 100));
    setCooktopPosition(x, y);
  }

  return (
    <div className="app-card overflow-hidden">
      <div className="flex items-center justify-between border-b border-slate-200 px-4 py-3">
        <div className="flex gap-2">
          <button className="rounded-lg bg-blue-50 px-3 py-2 text-sm font-medium text-blue-700">2D View</button>
          <button className="rounded-lg px-3 py-2 text-sm text-slate-500">3D View</button>
        </div>
        <div className="text-sm text-slate-500">Eenheid: mm · Snap: aan</div>
      </div>
      <div
        ref={containerRef}
        onPointerMove={handleMove}
        onPointerUp={() => setDragging(false)}
        onPointerLeave={() => setDragging(false)}
        className="relative h-[480px] select-none bg-slate-50 p-10"
      >
        <div className="relative h-full overflow-visible rounded-sm border-2 border-slate-400 bg-[url('/demo/slab-calacatta.svg')] bg-cover shadow-xl">
          <div className="absolute -top-8 left-0 right-0 text-center text-sm text-slate-500">3600 mm</div>
          <div className="absolute -left-16 top-1/2 -rotate-90 text-sm text-slate-500">1200 mm</div>

          <div className="absolute left-[18%] top-[28%] h-[42%] w-[23%] rounded-lg border-4 border-slate-500 bg-gradient-to-br from-slate-300 to-slate-600 shadow-inner">
            <div className="absolute inset-3 rounded-md border border-slate-700 bg-slate-800/75" />
            <div className="absolute left-1/2 top-1/2 h-5 w-5 -translate-x-1/2 -translate-y-1/2 rounded-full border-4 border-slate-400" />
          </div>

          <div
            onPointerDown={() => setDragging(true)}
            className="absolute h-[38%] w-[23%] -translate-x-1/2 -translate-y-1/2 cursor-move rounded border-2 border-blue-500 bg-slate-950 shadow-xl ring-4 ring-blue-100"
            style={{ left: `${cooktopX}%`, top: `${cooktopY}%` }}
          >
            <div className="grid h-full grid-cols-2 gap-4 p-6">
              {[0, 1, 2, 3].map((id) => <span key={id} className="rounded-full border border-slate-600" />)}
            </div>
            <span className="absolute -left-20 top-1/2 -translate-y-1/2 text-xs font-medium text-blue-600">450 mm</span>
            <span className="absolute -top-7 left-1/2 -translate-x-1/2 text-xs font-medium text-blue-600">350 mm</span>
          </div>

          <div className="absolute right-4 top-4 w-44 rounded-xl border border-slate-200 bg-white p-2 shadow-xl">
            <p className="px-2 py-1 text-xs font-semibold text-slate-500">Installatiemethode</p>
            {(["TOP_MOUNT", "FLUSH_MOUNT"] as const).map((mode) => (
              <button
                key={mode}
                onClick={() => setInstallationMode(mode)}
                className={`mt-1 w-full rounded-lg px-3 py-2 text-left text-sm ${installationMode === mode ? "bg-blue-50 font-medium text-blue-700" : "hover:bg-slate-50"}`}
              >
                {mode === "TOP_MOUNT" ? "Opbouw" : "Vlakinbouw"}
              </button>
            ))}
            <button disabled className="mt-1 w-full rounded-lg px-3 py-2 text-left text-sm text-slate-300">Onderbouw</button>
          </div>
        </div>
      </div>
    </div>
  );
}
