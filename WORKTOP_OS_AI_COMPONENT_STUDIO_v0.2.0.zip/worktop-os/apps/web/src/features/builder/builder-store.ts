import { create } from "zustand";

interface BuilderState {
  cooktopX: number;
  cooktopY: number;
  installationMode: "TOP_MOUNT" | "FLUSH_MOUNT";
  setCooktopPosition: (x: number, y: number) => void;
  setInstallationMode: (mode: "TOP_MOUNT" | "FLUSH_MOUNT") => void;
}

export const useBuilderStore = create<BuilderState>((set) => ({
  cooktopX: 63,
  cooktopY: 28,
  installationMode: "TOP_MOUNT",
  setCooktopPosition: (cooktopX, cooktopY) => set({ cooktopX, cooktopY }),
  setInstallationMode: (installationMode) => set({ installationMode }),
}));
