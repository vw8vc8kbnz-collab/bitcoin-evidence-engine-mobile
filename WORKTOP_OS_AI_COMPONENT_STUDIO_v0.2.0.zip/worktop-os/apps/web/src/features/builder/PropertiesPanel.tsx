"use client";

import { CheckCircle2 } from "lucide-react";
import { useBuilderStore } from "./builder-store";

export function PropertiesPanel() {
  const { cooktopX, cooktopY, installationMode, setInstallationMode } = useBuilderStore();

  return (
    <aside className="app-card h-full p-4">
      <div className="border-b border-slate-200 pb-3">
        <h2 className="font-semibold">Eigenschappen</h2>
        <p className="text-xs text-slate-500">BORA Pure PUXU · Kookplaat</p>
      </div>
      <Section title="Positie & uitlijning">
        <Field label="Horizontale referentie" value="Linkerzijde uitsparing" />
        <Field label="X-offset" value={`${Math.round(cooktopX * 18)} mm`} />
        <Field label="Verticale referentie" value="Voorzijde werkblad" />
        <Field label="Y-offset" value={`${Math.round(cooktopY * 12)} mm`} />
        <Field label="Rotatie" value="0,0°" />
      </Section>
      <Section title="Installatie">
        <select value={installationMode} onChange={(event) => setInstallationMode(event.target.value as "TOP_MOUNT" | "FLUSH_MOUNT")} className="app-input">
          <option value="TOP_MOUNT">Opbouw</option>
          <option value="FLUSH_MOUNT">Vlakinbouw</option>
        </select>
      </Section>
      <Section title="Productstatus">
        {["Exact gepositioneerd", "Materiaalregels geldig", "Minimale afstanden geldig", "Geen conflicten"].map((item) => (
          <div key={item} className="flex items-center gap-2 py-1.5 text-sm">
            <CheckCircle2 size={16} className="text-emerald-500" /> {item}
          </div>
        ))}
      </Section>
    </aside>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return <section className="border-b border-slate-100 py-4 last:border-0"><h3 className="mb-3 text-sm font-semibold">{title}</h3>{children}</section>;
}

function Field({ label, value }: { label: string; value: string }) {
  return <label className="mb-3 block"><span className="mb-1 block text-xs text-slate-500">{label}</span><input value={value} readOnly className="app-input" /></label>;
}
