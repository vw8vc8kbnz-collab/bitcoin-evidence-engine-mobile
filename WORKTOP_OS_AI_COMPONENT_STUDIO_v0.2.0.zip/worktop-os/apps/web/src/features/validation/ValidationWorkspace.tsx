import { AlertTriangle, CheckCircle2, Download, ShieldX } from "lucide-react";
import { validationChecks } from "@/data/demo";
import { Button } from "@/components/Buttons";
import { StatusBadge } from "@/components/StatusBadge";

const exports = ["Machine-DXF", "Nesting-DXF", "Klant-PDF", "Productieblad", "Componentenlijst", "Manifest", "Previews"];

export function ValidationWorkspace() {
  return (
    <div className="grid grid-cols-[240px_minmax(0,1fr)_350px] gap-5">
      <aside className="space-y-4">
        <section className="app-card p-5">
          <h2 className="font-semibold">Totale status</h2>
          <div className="mt-5 flex justify-center">
            <div className="flex h-32 w-32 items-center justify-center rounded-full border-[14px] border-emerald-400 border-b-amber-400">
              <div className="text-center"><strong className="block text-2xl">86%</strong><span className="text-xs text-slate-500">geslaagd</span></div>
            </div>
          </div>
        </section>
        <section className="app-card p-3">
          {["Geometrie", "Componenten", "Materialen", "Productieregels", "Nesting", "Machineprofiel", "Vrijgave"].map((label, index) => (
            <div key={label} className={`mb-2 flex items-center gap-3 rounded-lg px-3 py-3 text-sm ${index === 0 ? "bg-blue-50 text-blue-700" : ""}`}>
              {index < 3 ? <CheckCircle2 size={17} className="text-emerald-500" /> : index < 5 ? <AlertTriangle size={17} className="text-amber-500" /> : <ShieldX size={17} className="text-slate-400" />}
              {label}
            </div>
          ))}
        </section>
      </aside>

      <section className="app-card overflow-hidden">
        <div className="flex items-center justify-between border-b border-slate-200 p-5">
          <div><h2 className="font-semibold">Geometrievalidatie</h2><p className="text-sm text-slate-500">Controleer productiemaakbaarheid en exportgereedheid.</p></div>
          <Button>Checks opnieuw uitvoeren</Button>
        </div>
        <div className="p-5">
          {validationChecks.map((check) => (
            <div key={check.id} className="flex items-center gap-4 border-b border-slate-100 py-4 last:border-0">
              {check.severity === "PASSED" ? <CheckCircle2 className="text-emerald-500" size={20} /> : check.severity === "WARNING" ? <AlertTriangle className="text-amber-500" size={20} /> : <ShieldX className="text-red-500" size={20} />}
              <div className="flex-1">
                <p className="text-sm font-medium">{check.label}</p>
                <p className="text-xs text-slate-500">{check.detail}</p>
              </div>
              <StatusBadge status={check.severity === "PASSED" ? "PASSED" : check.severity === "WARNING" ? "WARNING" : "BLOCKED"} />
            </div>
          ))}
        </div>
      </section>

      <aside className="space-y-4">
        <section className="app-card p-5">
          <h2 className="font-semibold">Exportpakket</h2>
          <div className="mt-4 space-y-2">
            {exports.map((item) => (
              <label key={item} className="flex items-center gap-3 rounded-xl border border-slate-200 p-3 text-sm">
                <input type="checkbox" defaultChecked className="accent-blue-600" /> {item}
              </label>
            ))}
          </div>
        </section>
        <section className="app-card p-5">
          <h2 className="font-semibold">Pakketdetails</h2>
          <dl className="mt-4 space-y-3 text-sm">
            <Row label="Versie" value="v0.1.0-foundation" />
            <Row label="Engine" value="worktop-core 0.1.0" />
            <Row label="Manifest" value="Geldig" />
            <Row label="Checksum" value="Wordt gegenereerd" />
          </dl>
        </section>
      </aside>

      <div className="col-span-3 grid grid-cols-4 gap-4">
        <Button>Concept opslaan</Button>
        <Button>Review aanvragen</Button>
        <Button variant="success">Vrijgeven voor productie</Button>
        <Button variant="primary"><Download size={17} /> Exportpakket</Button>
      </div>
    </div>
  );
}
function Row({ label, value }: { label: string; value: string }) { return <div className="flex justify-between gap-4"><dt className="text-slate-500">{label}</dt><dd className="text-right font-medium">{value}</dd></div>; }
