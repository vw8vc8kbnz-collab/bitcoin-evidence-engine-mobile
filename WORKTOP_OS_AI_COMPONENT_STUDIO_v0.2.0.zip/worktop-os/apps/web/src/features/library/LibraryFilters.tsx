const sections = [
  ["Categorie", ["Kookplaten", "Spoelbakken", "Kranen", "Zeeppompjes", "Stopcontacten"]],
  ["Merk", ["BORA", "Franke", "Blanco", "Quooker", "Siemens"]],
  ["Installatie", ["Opbouw", "Vlakinbouw", "Onderbouw"]],
  ["Verificatie", ["Platform verified", "Tenant verified", "Kandidaat"]],
];

export function LibraryFilters() {
  return (
    <aside className="app-card p-4">
      <div className="flex items-center justify-between">
        <h2 className="font-semibold">Filters</h2>
        <button className="text-xs text-blue-600">Wis alles</button>
      </div>
      {sections.map(([title, values]) => (
        <div key={title as string} className="mt-5 border-t border-slate-100 pt-4 first:border-0 first:pt-0">
          <h3 className="text-sm font-medium">{title}</h3>
          <div className="mt-3 space-y-2">
            {(values as string[]).map((value, index) => (
              <label key={value} className="flex items-center gap-2 text-sm text-slate-600">
                <input type="checkbox" defaultChecked={title === "Verificatie" && index === 0} className="accent-blue-600" />
                {value}
                <span className="ml-auto text-xs text-slate-400">{128 - index * 17}</span>
              </label>
            ))}
          </div>
        </div>
      ))}
    </aside>
  );
}
