import type { ProductComponent } from "@worktop/domain";
import Image from "next/image";
import Link from "next/link";
import { StatusBadge } from "@/components/StatusBadge";

export function ProductCard({ product, selected = false }: { product: ProductComponent; selected?: boolean }) {
  return (
    <Link
      href={`/library/${product.id}`}
      className={`overflow-hidden rounded-xl border bg-white transition hover:-translate-y-0.5 hover:shadow-lg ${selected ? "border-blue-500 ring-2 ring-blue-100" : "border-slate-200"}`}
    >
      <div className="relative h-48 bg-slate-100">
        <Image src={product.images[0].src} alt={product.images[0].alt} fill className="object-cover" />
        <div className="absolute left-3 top-3"><StatusBadge status={product.verificationStatus} /></div>
      </div>
      <div className="p-4">
        <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">{product.brand}</p>
        <h3 className="mt-1 font-semibold">{product.model}</h3>
        <p className="mt-1 text-sm text-slate-500">{product.dimensionsLabel}</p>
        <p className="mt-3 text-xs text-blue-600">{product.installationModes.length} installatiemethode(n)</p>
      </div>
    </Link>
  );
}
