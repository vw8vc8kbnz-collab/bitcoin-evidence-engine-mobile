import { Search } from "lucide-react";
import { products } from "@/data/demo";
import { LibraryFilters } from "./LibraryFilters";
import { ProductCard } from "./ProductCard";
import { ProductQuickPreview } from "./ProductQuickPreview";

export function ProductLibraryGrid() {
  return (
    <div className="grid grid-cols-[220px_minmax(0,1fr)_340px] gap-5">
      <LibraryFilters />
      <section>
        <div className="mb-4 flex items-center gap-3">
          <div className="flex flex-1 items-center gap-2 rounded-lg border border-slate-200 bg-white px-3">
            <Search size={17} className="text-slate-400" />
            <input className="w-full py-2.5 text-sm outline-none" placeholder="Zoek merk, model, artikelnummer of maat..." />
          </div>
          <button className="rounded-lg border border-slate-200 bg-white px-4 py-2.5 text-sm">Relevantie ▾</button>
        </div>
        <div className="grid grid-cols-3 gap-4">
          {products.concat(products.slice(0, 3)).map((product, index) => (
            <ProductCard key={`${product.id}-${index}`} product={product} selected={index === 1} />
          ))}
        </div>
      </section>
      <ProductQuickPreview product={products[1]} />
    </div>
  );
}
