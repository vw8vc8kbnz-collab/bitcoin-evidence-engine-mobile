import type { ProductComponent } from "@worktop/domain";
import Image from "next/image";
import { CheckCircle2, Download, ExternalLink } from "lucide-react";
import { Button } from "@/components/Buttons";
import { StatusBadge } from "@/components/StatusBadge";
import { formatInstallationMode } from "@worktop/domain";

export function ProductDetail({ product }: { product: ProductComponent }) {
  return (
    <div className="space-y-5">
      <section className="grid grid-cols-[600px_minmax(0,1fr)] gap-5">
        <div className="app-card overflow-hidden">
          <div className="relative h-[390px]">
            <Image src={product.images[0].src} alt={product.images[0].alt} fill className="object-cover" />
          </div>
        </div>
        <div className="app-card p-6">
          <div className="flex items-center gap-3"><StatusBadge status={product.verificationStatus} /></div>
          <h1 className="mt-3 text-3xl font-semibold">{product.brand} {product.model}</h1>
          <p className="mt-2 text-slate-500">Demo productrecord met revisioneerbare productiedata.</p>
          <dl className="mt-6 grid grid-cols-2 gap-5">
            <Info label="Merk" value={product.brand} />
            <Info label="Model" value={product.model} />
            <Info label="Buitenmaat" value={product.dimensionsLabel} />
            <Info label="Uitsparing" value={product.cutoutLabel} />
            <Info label="Revisie" value="Rev. C" />
            <Info label="Bronstatus" value="Demo seeddata" />
          </dl>
          <div className="mt-7 flex gap-3">
            <Button variant="primary">Plaats op werkblad</Button>
            <Button>Toevoegen aan collectie</Button>
          </div>
        </div>
      </section>

      <div className="border-b border-slate-200">
        <nav className="flex gap-8 text-sm">
          {["Overzicht", "Installatie", "Geometrie", "Materialen", "Bronnen", "Revisies", "Audit"].map((tab, index) => (
            <button key={tab} className={`border-b-2 px-1 pb-3 ${index === 1 ? "border-blue-600 font-medium text-blue-600" : "border-transparent text-slate-500"}`}>{tab}</button>
          ))}
        </nav>
      </div>

      <section className="grid grid-cols-3 gap-4">
        {product.installationModes.map((mode) => (
          <div key={mode} className="app-card p-5">
            <div className="flex items-center justify-between">
              <h2 className="font-semibold">{formatInstallationMode(mode)}</h2>
              <CheckCircle2 size={18} className="text-emerald-500" />
            </div>
            <div className="mt-4 h-36 rounded-xl bg-slate-50 p-4">
              <svg viewBox="0 0 300 130" className="h-full w-full">
                <path d="M20 25 H110 V65 Q110 100 150 100 Q190 100 190 65 V25 H280" fill="none" stroke="#344256" strokeWidth="3" />
                <path d="M85 25 H215" stroke="#146ff5" strokeWidth="3" />
                <path d="M110 40 H190" stroke="#94a3b8" strokeDasharray="5 5" />
              </svg>
            </div>
            <dl className="mt-4 space-y-2 text-sm">
              <Info label="Minimumdikte" value={mode === "TOP_MOUNT" ? "12 mm" : "20 mm"} />
              <Info label="Geometry set" value="Beschikbaar" />
            </dl>
          </div>
        ))}
      </section>

      <section className="grid grid-cols-[1.2fr_.8fr] gap-5">
        <div className="app-card p-5">
          <div className="flex items-center justify-between">
            <h2 className="font-semibold">Technische geometriepreview</h2>
            <Button><Download size={16} /> Geometry set</Button>
          </div>
          <div className="mt-4 h-64 rounded-xl bg-slate-50 p-4">
            <svg viewBox="0 0 700 260" className="h-full w-full">
              <rect x="80" y="30" width="260" height="190" rx="18" fill="none" stroke="#334155" strokeWidth="3" />
              <rect x="100" y="50" width="220" height="150" rx="12" fill="none" stroke="#146ff5" strokeWidth="2" />
              <line x1="80" y1="15" x2="340" y2="15" stroke="#64748b" />
              <text x="180" y="12" fill="#475569" fontSize="14">540 mm</text>
              <path d="M440 55 H610 V80 Q610 200 525 200 Q440 200 440 80 Z" fill="none" stroke="#334155" strokeWidth="3" />
            </svg>
          </div>
        </div>
        <div className="app-card p-5">
          <h2 className="font-semibold">Bronnen & revisies</h2>
          <div className="mt-4 space-y-3">
            {["Technisch datablad", "CAD/DXF-tekening", "Installatiehandleiding"].map((source) => (
              <div key={source} className="flex items-center gap-3 rounded-xl border border-slate-200 p-3">
                <ExternalLink size={16} className="text-blue-600" />
                <span className="text-sm">{source}</span>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return <div><dt className="text-xs text-slate-500">{label}</dt><dd className="mt-1 text-sm font-medium">{value}</dd></div>;
}
