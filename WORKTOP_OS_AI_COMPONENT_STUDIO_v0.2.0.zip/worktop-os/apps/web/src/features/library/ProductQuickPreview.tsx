import type { ProductComponent } from "@worktop/domain";
import Image from "next/image";
import { Box, CheckCircle2 } from "lucide-react";
import { StatusBadge } from "@/components/StatusBadge";
import { formatInstallationMode } from "@worktop/domain";

export function ProductQuickPreview({ product }: { product: ProductComponent }) {
  return (
    <aside className="app-card sticky top-20 p-4">
      <div className="relative h-48 overflow-hidden rounded-xl bg-slate-100">
        <Image src={product.images[0].src} alt={product.images[0].alt} fill className="object-cover" />
      </div>
      <p className="mt-4 text-xs uppercase tracking-wide text-slate-500">{product.brand}</p>
      <h2 className="text-xl font-semibold">{product.model}</h2>
      <div className="mt-2"><StatusBadge status={product.verificationStatus} /></div>
      <dl className="mt-5 space-y-3 text-sm">
        <Row label="Buitenmaat" value={product.dimensionsLabel} />
        <Row label="Uitsparing" value={product.cutoutLabel} />
        <Row label="Categorie" value={product.category} />
      </dl>
      <div className="mt-5">
        <p className="text-sm font-medium">Ondersteunde installatie</p>
        <div className="mt-2 flex flex-wrap gap-2">
          {product.installationModes.map((mode) => <span key={mode} className="rounded-md border border-blue-200 bg-blue-50 px-2 py-1 text-xs text-blue-700">{formatInstallationMode(mode)}</span>)}
        </div>
      </div>
      <div className="mt-5 space-y-2 border-t border-slate-100 pt-4">
        {["Afmetingen", "Installatiegegevens", "Productiegeometrie", "Bronverwijzingen"].map((label) => (
          <div key={label} className="flex items-center gap-2 text-sm text-slate-600">
            <CheckCircle2 size={16} className="text-emerald-500" /> {label}
          </div>
        ))}
      </div>
      <button className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl border border-dashed border-blue-400 bg-blue-50 py-4 font-medium text-blue-700">
        <Box size={19} /> Sleep naar werkblad
      </button>
    </aside>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return <div className="flex justify-between gap-4"><dt className="text-slate-500">{label}</dt><dd className="text-right font-medium">{value}</dd></div>;
}
