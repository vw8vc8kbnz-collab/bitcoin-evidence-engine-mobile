"use client";

import { useState } from "react";
import { Cloud, Copy, FileCode2, Grid2X2Plus, PlusSquare } from "lucide-react";
import { Button } from "@/components/Buttons";
import { cn } from "@/lib/cn";

const methods = [
  { id: "empty", label: "Leeg project", detail: "Start met een schoon werkblad.", icon: PlusSquare },
  { id: "template", label: "Slim vormtemplate", detail: "Gebruik parametrische basisvormen.", icon: Grid2X2Plus },
  { id: "dxf", label: "DXF importeren", detail: "Analyseer en herstel bestaande geometrie.", icon: FileCode2 },
  { id: "duplicate", label: "Project dupliceren", detail: "Kopieer instellingen en standaarden.", icon: Copy },
  { id: "api", label: "ERP / API-order", detail: "Ontvang projectdata via een contract.", icon: Cloud },
];

export function NewProjectWizard() {
  const [selected, setSelected] = useState("empty");

  return (
    <div className="app-card p-6">
      <div className="mb-7 grid grid-cols-5 gap-4 border-b border-slate-200 pb-6">
        {["Project", "Input", "Materiaal", "Standaarden", "Controle"].map((step, index) => (
          <div key={step} className="flex items-center gap-3">
            <span className={cn("flex h-9 w-9 items-center justify-center rounded-full border text-sm", index === 0 ? "border-blue-600 text-blue-600" : "border-slate-300 text-slate-400")}>{index + 1}</span>
            <span className="text-sm font-medium">{step}</span>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-[1fr_1fr] gap-7">
        <section>
          <h2 className="text-lg font-semibold">Hoe wil je beginnen?</h2>
          <p className="mt-1 text-sm text-slate-500">Kies een startpunt; dit kan later aangepast worden.</p>
          <div className="mt-5 space-y-3">
            {methods.map(({ id, label, detail, icon: Icon }) => (
              <button
                key={id}
                onClick={() => setSelected(id)}
                className={cn(
                  "flex w-full items-center gap-4 rounded-xl border p-4 text-left transition",
                  selected === id ? "border-blue-500 bg-blue-50/50" : "border-slate-200 hover:border-slate-300",
                )}
              >
                <span className="rounded-xl bg-slate-50 p-3 text-blue-600"><Icon size={22} /></span>
                <span>
                  <span className="block font-medium">{label}</span>
                  <span className="text-sm text-slate-500">{detail}</span>
                </span>
                <span className={cn("ml-auto h-4 w-4 rounded-full border", selected === id && "border-4 border-blue-600")} />
              </button>
            ))}
          </div>
        </section>

        <section className="border-l border-slate-200 pl-7">
          <h2 className="text-lg font-semibold">Projectinstellingen</h2>
          <div className="mt-5 grid grid-cols-2 gap-4">
            <Field label="Projectnaam" placeholder="Horizon Ridge Residence" full />
            <Field label="Ordernummer" placeholder="PRJ-2026-0512" />
            <Field label="Klantreferentie" placeholder="REF-0512" />
            <Field label="Klant" placeholder="Horizon Homes" full />
            <Field label="Materiaalgroep" placeholder="Composiet" />
            <Field label="Dikte" placeholder="20 mm" />
            <Field label="Eenheid" placeholder="Millimeter" />
            <Field label="Machineprofiel" placeholder="Nog te kiezen" />
          </div>
        </section>
      </div>

      <div className="mt-7 flex justify-end gap-3 border-t border-slate-200 pt-5">
        <Button>Concept opslaan</Button>
        <Button variant="primary">Doorgaan</Button>
      </div>
    </div>
  );
}

function Field({ label, placeholder, full = false }: { label: string; placeholder: string; full?: boolean }) {
  return (
    <label className={full ? "col-span-2" : undefined}>
      <span className="mb-1.5 block text-sm font-medium text-slate-700">{label}</span>
      <input className="app-input" placeholder={placeholder} />
    </label>
  );
}
