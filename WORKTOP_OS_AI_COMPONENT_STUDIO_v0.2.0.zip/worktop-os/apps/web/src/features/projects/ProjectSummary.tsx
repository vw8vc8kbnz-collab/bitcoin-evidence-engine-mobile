import { CheckCircle2, Circle } from "lucide-react";
import { StatusBadge } from "@/components/StatusBadge";
import { projects } from "@/data/demo";

export function ProjectSummary() {
  const project = projects[0];
  const steps = ["Projectdata", "Bladvorm", "Componenten", "Materiaal", "Nesting", "Validatie", "Vrijgave"];

  return (
    <aside className="app-card p-5">
      <div className="h-36 rounded-xl bg-[linear-gradient(135deg,#ece4d8,#f8fafc_55%,#dbeafe)]" />
      <h2 className="mt-4 text-xl font-semibold">{project.name}</h2>
      <p className="text-sm text-slate-500">{project.code}</p>
      <div className="mt-3"><StatusBadge status={project.status} /></div>
      <div className="mt-5 h-2 overflow-hidden rounded-full bg-slate-100">
        <div className="h-full w-[86%] rounded-full bg-emerald-500" />
      </div>
      <div className="mt-5 space-y-3">
        {steps.map((step, index) => (
          <div key={step} className="flex items-center gap-3">
            {index < 5 ? <CheckCircle2 size={18} className="text-emerald-500" /> : <Circle size={18} className="text-slate-300" />}
            <span className={index === 5 ? "text-sm font-medium text-blue-600" : "text-sm text-slate-600"}>{step}</span>
          </div>
        ))}
      </div>
    </aside>
  );
}
