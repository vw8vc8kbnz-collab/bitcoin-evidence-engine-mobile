import Link from "next/link";
import { MoreHorizontal } from "lucide-react";
import { projects } from "@/data/demo";
import { StatusBadge } from "@/components/StatusBadge";

export function ProjectsTable() {
  return (
    <div className="app-card overflow-hidden">
      <div className="grid grid-cols-[1.3fr_1fr_1fr_.8fr_.7fr_.3fr] gap-4 border-b border-slate-200 bg-slate-50 px-5 py-3 text-xs font-semibold uppercase tracking-wide text-slate-500">
        <span>Project</span><span>Klant</span><span>Materiaal</span><span>Status</span><span>Bijgewerkt</span><span />
      </div>
      {projects.concat(projects.slice(0, 3)).map((project, index) => (
        <Link
          href={`/projects/${project.id}/builder`}
          key={`${project.id}-${index}`}
          className="grid grid-cols-[1.3fr_1fr_1fr_.8fr_.7fr_.3fr] items-center gap-4 border-b border-slate-100 px-5 py-4 last:border-0 hover:bg-slate-50"
        >
          <div>
            <p className="text-sm font-medium">{project.name}</p>
            <p className="text-xs text-slate-500">{project.code}</p>
          </div>
          <span className="text-sm text-slate-600">{project.customer}</span>
          <span className="text-sm text-slate-600">{project.material}</span>
          <StatusBadge status={project.status} />
          <span className="text-sm text-slate-500">{project.updatedAt}</span>
          <MoreHorizontal size={18} className="justify-self-end text-slate-400" />
        </Link>
      ))}
    </div>
  );
}
