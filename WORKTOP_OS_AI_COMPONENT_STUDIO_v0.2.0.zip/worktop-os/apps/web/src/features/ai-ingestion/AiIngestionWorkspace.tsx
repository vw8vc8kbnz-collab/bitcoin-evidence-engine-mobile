"use client";

import { useEffect, useState } from "react";
import { ExtractionReview } from "./ExtractionReview";
import { IngestionHeader } from "./IngestionHeader";
import { IngestionProgress } from "./IngestionProgress";
import { IngestionUploadForm } from "./IngestionUploadForm";
import type { IngestionConfig, IngestionResponse } from "./types";

export function AiIngestionWorkspace() {
  const [config, setConfig] = useState<IngestionConfig | null>(null);
  const [busy, setBusy] = useState(false);
  const [response, setResponse] = useState<IngestionResponse | null>(null);

  useEffect(() => {
    fetch("/api/ai-ingestion/config", { cache: "no-store" })
      .then((result) => result.json())
      .then(setConfig)
      .catch(() => setConfig({ configured: false, databaseConfigured: false, verifierEnabled: false, model: "onbekend" }));
  }, []);

  async function submit(formData: FormData) {
    setBusy(true);
    setResponse(null);
    try {
      const result = await fetch("/api/ai-ingestion/analyze", { method: "POST", body: formData });
      const payload = await result.json() as IngestionResponse;
      setResponse(payload);
    } catch (error) {
      setResponse({ ok: false, error: error instanceof Error ? error.message : "Netwerkfout tijdens analyse." });
    } finally {
      setBusy(false);
    }
  }

  const disabled = !config?.configured || !config?.databaseConfigured;
  return (
    <>
      <IngestionHeader config={config} />
      {disabled && config && <div className="mb-6 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">Configureer eerst de OpenAI-key en database via de meegeleverde Termius-installatiestappen. De key komt nooit in de frontend of repository.</div>}
      <IngestionUploadForm disabled={disabled} busy={busy} onSubmit={submit} />
      <IngestionProgress active={busy} />
      {response && !response.ok && <div className="mt-6 rounded-xl border border-red-200 bg-red-50 px-4 py-4 text-sm text-red-800"><strong>Analyse mislukt:</strong> {response.error ?? "Onbekende fout."}</div>}
      {response?.ok && response.result && response.jobId && response.model && <ExtractionReview result={response.result} jobId={response.jobId} model={response.model} passes={response.passes ?? 1} geometryGeneration={response.geometryGeneration} />}
    </>
  );
}
