import { AlertTriangle, Cpu, Download, FileCode2 } from "lucide-react";
import type { GeometryGenerationResult } from "@worktop/ai-ingestion";

export function CandidateDxfPanel({
  jobId,
  geometryGeneration,
}: {
  jobId: string;
  geometryGeneration?: GeometryGenerationResult;
}) {
  if (!geometryGeneration) return null;
  const generated = geometryGeneration.assets.length > 0;
  return (
    <div className="app-card p-6">
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="rounded-xl bg-blue-50 p-3 text-blue-600"><Cpu size={22} /></div>
          <div>
            <h3 className="font-semibold">Native C++ kandidaat-DXF</h3>
            <p className="mt-1 text-sm text-slate-500">
              Alleen geometrie met bevestigde schaal, datumoffset en complete parameters wordt gecompileerd.
            </p>
          </div>
        </div>
        <span className={`rounded-full px-3 py-1 text-xs font-semibold ${
          generated ? "bg-blue-50 text-blue-700" : "bg-amber-50 text-amber-700"
        }`}>
          {geometryGeneration.status}
        </span>
      </div>

      {generated && (
        <div className="mt-5 grid grid-cols-3 gap-3">
          {geometryGeneration.assets.map((asset) => (
            <div key={asset.installationMode} className="rounded-xl border border-slate-200 p-4">
              <div className="flex items-center gap-2"><FileCode2 size={18} className="text-blue-600" /><p className="font-semibold">{asset.installationMode}</p></div>
              <p className="mt-2 text-xs text-slate-500">{asset.operationCount} bewerkingen · C++ {asset.engineVersion}</p>
              <a
                href={`/api/ai-ingestion/jobs/${jobId}/candidate-dxf/${asset.installationMode}`}
                className="mt-4 inline-flex items-center gap-2 rounded-lg border border-blue-200 bg-blue-50 px-3 py-2 text-sm font-semibold text-blue-700 hover:bg-blue-100"
              >
                <Download size={16} /> Download kandidaat-DXF
              </a>
            </div>
          ))}
        </div>
      )}

      {geometryGeneration.issues.length > 0 && (
        <div className="mt-5 space-y-2">
          {geometryGeneration.issues.map((issue) => (
            <div key={issue} className="flex gap-2 rounded-xl bg-amber-50 p-3 text-sm text-amber-900">
              <AlertTriangle size={17} className="mt-0.5 shrink-0" />{issue}
            </div>
          ))}
        </div>
      )}
      <p className="mt-4 text-xs leading-5 text-slate-500">
        Iedere file bevat de markering <strong>WORKTOP_OS_AI_CANDIDATE_NOT_VERIFIED</strong> en is niet machinevrijgegeven.
      </p>
    </div>
  );
}
