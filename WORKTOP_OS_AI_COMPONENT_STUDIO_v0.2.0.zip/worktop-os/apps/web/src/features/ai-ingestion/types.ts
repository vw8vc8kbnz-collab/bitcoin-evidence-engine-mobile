import type { AiComponentExtraction, GeometryGenerationResult } from "@worktop/ai-ingestion";

export interface IngestionConfig {
  configured: boolean;
  model: string;
  verifierEnabled: boolean;
  databaseConfigured: boolean;
}

export interface IngestionResponse {
  ok: boolean;
  jobId?: string;
  candidateId?: string;
  model?: string;
  passes?: number;
  result?: AiComponentExtraction;
  geometryGeneration?: GeometryGenerationResult;
  error?: string;
}
