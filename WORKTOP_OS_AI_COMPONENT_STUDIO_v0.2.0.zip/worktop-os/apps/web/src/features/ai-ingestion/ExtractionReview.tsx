import { AlertTriangle, CheckCircle2, FileSearch, LockKeyhole, Ruler, ShieldAlert } from "lucide-react";
import type { AiComponentExtraction, GeometryGenerationResult } from "@worktop/ai-ingestion";
import { CandidateDxfPanel } from "./CandidateDxfPanel";

function DecisionBadge({ decision }: { decision: AiComponentExtraction["automaticDecision"] }) {
  const ready = decision === "CANDIDATE_READY_FOR_REVIEW";
  return <span className={`rounded-full px-3 py-1 text-xs font-semibold ${ready ? "bg-blue-50 text-blue-700" : "bg-red-50 text-red-700"}`}>{ready ? "Kandidaat klaar voor review" : "Automatisch geblokkeerd"}</span>;
}

function Value({ label, value }: { label: string; value: string | number | null }) {
  return <div className="rounded-xl border border-slate-200 bg-slate-50 px-4 py-3"><p className="text-xs font-medium text-slate-500">{label}</p><p className="mt-1 font-semibold text-slate-800">{value ?? "Niet gevonden"}</p></div>;
}

export function ExtractionReview({
  result,
  jobId,
  model,
  passes,
  geometryGeneration,
}: {
  result: AiComponentExtraction;
  jobId: string;
  model: string;
  passes: number;
  geometryGeneration?: GeometryGenerationResult;
}) {
  return (
    <div className="mt-6 space-y-6">
      <div className="app-card p-6">
        <div className="flex items-start justify-between gap-4">
          <div><p className="text-xs font-semibold uppercase tracking-wider text-blue-600">AI_EXTRACTED_CANDIDATE</p><h3 className="mt-1 text-xl font-semibold">{result.identity.manufacturer ?? "Onbekend merk"} · {result.identity.model ?? "Model bevestigen"}</h3><p className="mt-2 max-w-3xl text-sm leading-6 text-slate-500">{result.extractionSummary}</p></div>
          <DecisionBadge decision={result.automaticDecision} />
        </div>
        <div className="mt-5 grid grid-cols-5 gap-3">
          <Value label="Categorie" value={result.identity.category} />
          <Value label="Artikelnummer" value={result.identity.articleNumber} />
          <Value label="Revisie" value={result.identity.revision} />
          <Value label="Model" value={model} />
          <Value label="Analysepasses" value={passes} />
        </div>
        <div className="mt-4 rounded-xl border border-slate-200 bg-white px-4 py-3 text-xs text-slate-500">Job-ID: <span className="font-mono text-slate-700">{jobId}</span></div>
      </div>

      <div className="grid grid-cols-[1.3fr_0.7fr] gap-6">
        <div className="app-card p-6">
          <div className="flex items-center gap-2"><Ruler size={19} className="text-blue-600" /><h3 className="font-semibold">Installatiemethoden en geometriekandidaten</h3></div>
          <div className="mt-4 space-y-4">
            {result.installations.map((installation) => (
              <div key={installation.mode} className="rounded-2xl border border-slate-200 p-5">
                <div className="flex items-center justify-between"><div><p className="font-semibold text-slate-800">{installation.mode}</p><p className="mt-1 text-xs text-slate-500">{installation.supportStatus}</p></div><span className={`rounded-full px-3 py-1 text-xs font-semibold ${installation.documented ? "bg-emerald-50 text-emerald-700" : "bg-slate-100 text-slate-600"}`}>{installation.documented ? "Gedocumenteerd" : "Niet bewezen"}</span></div>
                <div className="mt-4 grid grid-cols-2 gap-3">
                  {installation.operations.map((operation, index) => (
                    <div key={`${operation.operationType}-${index}`} className="rounded-xl bg-slate-50 p-4 text-sm">
                      <div className="flex items-center justify-between"><span className="font-semibold">{operation.operationType}</span><span className="text-xs text-slate-500">{operation.confidence}</span></div>
                      <p className="mt-2 text-slate-600">{operation.shape.kind} · {operation.shape.widthMm ?? "?"} × {operation.shape.heightMm ?? "?"} mm</p>
                      <p className="mt-1 text-xs text-slate-500">Diepte: {operation.depthMm ?? "onbekend"} mm · R: {operation.shape.cornerRadiusMm ?? "onbekend"} mm</p>
                    </div>
                  ))}
                </div>
                {installation.missingCriticalFields.length > 0 && <div className="mt-4 rounded-xl bg-amber-50 px-4 py-3 text-sm text-amber-800"><strong>Ontbreekt:</strong> {installation.missingCriticalFields.join(", ")}</div>}
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-6">
          <div className="app-card p-6">
            <div className="flex items-center gap-2"><FileSearch size={19} className="text-blue-600" /><h3 className="font-semibold">Bronkoppelingen</h3></div>
            <div className="mt-4 space-y-3">{result.sourceEvidence.slice(0, 8).map((evidence) => <div key={evidence.evidenceId} className="rounded-xl border border-slate-200 p-3"><p className="text-sm font-medium">{evidence.fileName}{evidence.pageNumber ? ` · pagina ${evidence.pageNumber}` : ""}</p><p className="mt-1 text-xs leading-5 text-slate-500">{evidence.evidenceSummary}</p></div>)}</div>
          </div>
          <div className="app-card p-6">
            <div className="flex items-center gap-2"><ShieldAlert size={19} className="text-amber-600" /><h3 className="font-semibold">Blokkades en ontbrekende waarheid</h3></div>
            <div className="mt-4 space-y-2">
              {[...result.missingCriticalData, ...result.conflicts.map((conflict) => conflict.description)].map((item) => <div key={item} className="flex gap-2 rounded-xl bg-amber-50 p-3 text-sm text-amber-900"><AlertTriangle size={17} className="mt-0.5 shrink-0" />{item}</div>)}
              {result.missingCriticalData.length === 0 && result.conflicts.length === 0 && <div className="flex gap-2 rounded-xl bg-emerald-50 p-3 text-sm text-emerald-800"><CheckCircle2 size={17} />Geen bronconflicten gevonden; menselijke geometriecontrole blijft verplicht.</div>}
            </div>
          </div>
        </div>
      </div>

      <CandidateDxfPanel jobId={jobId} geometryGeneration={geometryGeneration} />

      <div className="app-card flex items-center justify-between p-5">
        <div className="flex items-center gap-3"><LockKeyhole className="text-blue-600" /><div><p className="font-semibold">Productiepublicatie is bewust vergrendeld</p><p className="text-sm text-slate-500">De volgende fase wordt de side-by-side bron- en C++ Geometry Review.</p></div></div>
        <button disabled className="rounded-lg bg-slate-200 px-4 py-2 text-sm font-semibold text-slate-500">Verifiëren na geometry review</button>
      </div>
    </div>
  );
}
