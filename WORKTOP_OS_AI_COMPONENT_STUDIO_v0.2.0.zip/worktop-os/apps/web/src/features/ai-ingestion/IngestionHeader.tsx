import { Bot, Database, KeyRound, ShieldCheck } from "lucide-react";
import type { IngestionConfig } from "./types";

function StatusPill({ ok, label }: { ok: boolean; label: string }) {
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold ${
      ok ? "bg-emerald-50 text-emerald-700" : "bg-amber-50 text-amber-700"
    }`}>
      <span className={`h-1.5 w-1.5 rounded-full ${ok ? "bg-emerald-500" : "bg-amber-500"}`} />
      {label}
    </span>
  );
}

export function IngestionHeader({ config }: { config: IngestionConfig | null }) {
  return (
    <div className="app-card mb-6 overflow-hidden">
      <div className="grid grid-cols-[1.4fr_1fr]">
        <div className="bg-gradient-to-br from-[#0a2038] to-[#12395e] p-7 text-white">
          <div className="flex items-center gap-3">
            <div className="rounded-xl bg-blue-500/20 p-3"><Bot size={26} /></div>
            <div>
              <p className="text-xs font-semibold uppercase tracking-[0.18em] text-blue-200">Component Intelligence</p>
              <h2 className="mt-1 text-2xl font-semibold">AI Component Ingestion Studio</h2>
            </div>
          </div>
          <p className="mt-5 max-w-2xl text-sm leading-6 text-slate-200">
            Upload een echte productfoto en officiële fabrikantdocumenten. AI structureert de kandidaatdata;
            Worktop OS bewaart bronnen, onzekerheden en conflicten voor verplichte menselijke review.
          </p>
        </div>
        <div className="grid content-center gap-4 bg-white p-6">
          <div className="flex items-center gap-3 text-sm"><KeyRound className="text-blue-600" size={19} /><span className="flex-1">OpenAI serverkey</span><StatusPill ok={Boolean(config?.configured)} label={config?.configured ? "Geconfigureerd" : "Ontbreekt"} /></div>
          <div className="flex items-center gap-3 text-sm"><Database className="text-blue-600" size={19} /><span className="flex-1">PostgreSQL kandidaatdatabase</span><StatusPill ok={Boolean(config?.databaseConfigured)} label={config?.databaseConfigured ? "Beschikbaar" : "Ontbreekt"} /></div>
          <div className="flex items-center gap-3 text-sm"><ShieldCheck className="text-blue-600" size={19} /><span className="flex-1">Onafhankelijke verificatiepass</span><StatusPill ok={Boolean(config?.verifierEnabled)} label={config?.verifierEnabled ? "Actief" : "Uitgeschakeld"} /></div>
          <p className="text-xs text-slate-500">Model: {config?.model ?? "configuratie laden…"}</p>
        </div>
      </div>
    </div>
  );
}
