"use client";

import { FileText, Image as ImageIcon, Sparkles, UploadCloud, X } from "lucide-react";
import { useRef, useState, type FormEvent } from "react";
import { Button } from "@/components/Buttons";

interface Props {
  disabled: boolean;
  busy: boolean;
  onSubmit: (formData: FormData) => Promise<void>;
}

function FileChip({ file, onRemove }: { file: File; onRemove: () => void }) {
  const Icon = file.type.startsWith("image/") ? ImageIcon : FileText;
  return (
    <div className="flex items-center gap-3 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2">
      <Icon size={18} className="text-blue-600" />
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-medium text-slate-800">{file.name}</p>
        <p className="text-xs text-slate-500">{(file.size / 1024 / 1024).toFixed(2)} MB</p>
      </div>
      <button type="button" onClick={onRemove} className="rounded-md p-1 text-slate-400 hover:bg-white hover:text-red-500" aria-label={`${file.name} verwijderen`}><X size={16} /></button>
    </div>
  );
}

export function IngestionUploadForm({ disabled, busy, onSubmit }: Props) {
  const [files, setFiles] = useState<File[]>([]);
  const [rightsConfirmed, setRightsConfirmed] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  function addFiles(next: FileList | null) {
    if (!next) return;
    setFiles((current) => [...current, ...Array.from(next)].slice(0, 12));
  }

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    for (const file of files) form.append("files", file);
    form.set("rightsConfirmed", String(rightsConfirmed));
    await onSubmit(form);
  }

  return (
    <form onSubmit={submit} className="app-card p-6">
      <div className="mb-5 flex items-start justify-between">
        <div><p className="text-xs font-semibold uppercase tracking-wider text-blue-600">Stap 1</p><h3 className="mt-1 text-lg font-semibold">Bronnen uploaden</h3><p className="mt-1 text-sm text-slate-500">Minimaal één productfoto en één officiële PDF. DXF/DWG mag als extra vectorbron mee.</p></div>
        <span className="rounded-full bg-blue-50 px-3 py-1 text-xs font-semibold text-blue-700">Max. 12 bestanden</span>
      </div>

      <button
        type="button"
        disabled={disabled || busy}
        onClick={() => inputRef.current?.click()}
        onDragOver={(event) => event.preventDefault()}
        onDrop={(event) => { event.preventDefault(); addFiles(event.dataTransfer.files); }}
        className="flex min-h-48 w-full flex-col items-center justify-center rounded-2xl border-2 border-dashed border-blue-200 bg-blue-50/40 px-5 text-center transition hover:border-blue-400 hover:bg-blue-50 disabled:cursor-not-allowed disabled:opacity-60"
      >
        <UploadCloud size={34} className="text-blue-600" />
        <span className="mt-3 font-semibold text-slate-800">Sleep productfoto’s en officiële bestanden hierheen</span>
        <span className="mt-1 text-sm text-slate-500">JPG, PNG, WEBP, PDF, TXT, DXF of DWG · maximaal 20 MB per bestand en 50 MB totaal</span>
      </button>
      <input ref={inputRef} className="hidden" type="file" multiple accept=".jpg,.jpeg,.png,.webp,.pdf,.txt,.dxf,.dwg" onChange={(event) => addFiles(event.target.files)} />

      {files.length > 0 && <div className="mt-4 grid grid-cols-2 gap-2">{files.map((file, index) => <FileChip key={`${file.name}-${index}`} file={file} onRemove={() => setFiles((current) => current.filter((_, itemIndex) => itemIndex !== index))} />)}</div>}

      <div className="mt-6 grid grid-cols-2 gap-4">
        <label className="text-sm font-medium text-slate-700">Merkhint<input className="app-input mt-2" name="manufacturerHint" placeholder="Bijv. BORA" /></label>
        <label className="text-sm font-medium text-slate-700">Modelhint<input className="app-input mt-2" name="modelHint" placeholder="Bijv. X Pure" /></label>
      </div>
      <label className="mt-4 block text-sm font-medium text-slate-700">Aanvullende notitie<textarea className="app-input mt-2 min-h-24 resize-y" name="notes" placeholder="Bijvoorbeeld: gebruik alleen de maatvoering voor artikelnummer …" /></label>
      <label className="mt-4 block text-sm font-medium text-slate-700">Rechtenscope<select className="app-input mt-2" name="rightsScope" defaultValue="TENANT_PRIVATE"><option value="TENANT_PRIVATE">Tenant-private — alleen binnen deze organisatie</option><option value="PLATFORM_LICENSED">Platformgelicentieerd — bewijs van toestemming aanwezig</option></select></label>

      <label className="mt-5 flex items-start gap-3 rounded-xl border border-slate-200 bg-slate-50 p-4 text-sm text-slate-600">
        <input type="checkbox" className="mt-0.5 h-4 w-4 accent-blue-600" checked={rightsConfirmed} onChange={(event) => setRightsConfirmed(event.target.checked)} />
        <span>Ik bevestig dat deze foto’s en fabrikantdocumenten binnen de gekozen scope verwerkt en opgeslagen mogen worden. Dit geeft nog geen platformbrede publicatierechten.</span>
      </label>

      <div className="mt-6 flex items-center justify-between border-t border-slate-100 pt-5">
        <p className="max-w-xl text-xs leading-5 text-slate-500">De uitkomst wordt altijd opgeslagen als <strong>AI_EXTRACTED_CANDIDATE</strong>. Productiepublicatie blijft geblokkeerd totdat bron en geometrie door een mens zijn gecontroleerd.</p>
        <Button type="submit" variant="primary" disabled={disabled || busy || files.length < 2 || !rightsConfirmed}><Sparkles size={17} />{busy ? "Documenten analyseren…" : "Analyse starten"}</Button>
      </div>
    </form>
  );
}
