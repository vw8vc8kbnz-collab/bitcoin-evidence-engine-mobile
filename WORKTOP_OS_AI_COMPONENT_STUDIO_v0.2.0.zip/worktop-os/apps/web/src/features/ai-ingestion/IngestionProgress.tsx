"use client";

import { CheckCircle2, CircleDashed, Database, FileSearch, ScanSearch } from "lucide-react";

const steps = [
  { icon: FileSearch, label: "Bronnen veilig opslaan" },
  { icon: ScanSearch, label: "AI-extractie en bronkoppeling" },
  { icon: ScanSearch, label: "Onafhankelijke verificatiepass" },
  { icon: Database, label: "Kandidaat in database opslaan" },
];

export function IngestionProgress({ active }: { active: boolean }) {
  if (!active) return null;
  return (
    <div className="app-card mt-6 p-6">
      <div className="flex items-center gap-3">
        <CircleDashed className="animate-spin text-blue-600" size={22} />
        <div><h3 className="font-semibold">Analyse draait</h3><p className="text-sm text-slate-500">Technische PDF’s kunnen enkele minuten duren. Sluit dit scherm niet.</p></div>
      </div>
      <div className="mt-5 grid grid-cols-4 gap-3">
        {steps.map(({ icon: Icon, label }, index) => (
          <div key={label} className="rounded-xl border border-blue-100 bg-blue-50/40 p-4">
            <div className="flex items-center justify-between"><Icon size={19} className="text-blue-600" /><span className="text-xs font-semibold text-blue-700">0{index + 1}</span></div>
            <p className="mt-3 text-sm font-medium text-slate-700">{label}</p>
          </div>
        ))}
      </div>
      <div className="mt-5 flex items-center gap-2 text-xs text-slate-500"><CheckCircle2 size={15} className="text-emerald-500" />API-key blijft uitsluitend op de server en wordt nooit naar de browser gestuurd.</div>
    </div>
  );
}
