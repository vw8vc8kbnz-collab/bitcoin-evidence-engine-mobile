import { AlertTriangle, ArrowRight, CheckCircle2, Cpu, Cuboid } from "lucide-react";
import { projects } from "@/data/demo";

export function DashboardSidePanels() {
  return (
    <div className="space-y-4">
      <section className="app-card p-5">
        <h2 className="font-semibold">Verder werken</h2>
        <div className="mt-4 space-y-3">
          {projects.slice(0, 3).map((project) => (
            <div key={project.id} className="rounded-xl border border-slate-200 p-3">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">{project.name}</p>
                  <p className="text-xs text-slate-500">{project.progress}% gereed</p>
                </div>
                <ArrowRight size={17} className="text-slate-400" />
              </div>
              <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-slate-100">
                <div className="h-full rounded-full bg-blue-500" style={{ width: `${project.progress}%` }} />
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="app-card p-5">
        <h2 className="font-semibold">Productiemeldingen</h2>
        <div className="mt-4 space-y-3">
          <Alert label="Materiaalvoorraad laag" detail="Calacatta Oro: nog 2 platen" />
          <Alert label="Machineprofiel review" detail="BS-01 acceptatietest verloopt" />
        </div>
      </section>

      <section className="app-card p-5">
        <h2 className="font-semibold">Systeemstatus</h2>
        <div className="mt-4 grid gap-3">
          <Status icon={Cpu} label="C++ Engine" detail="Native core online" />
          <Status icon={Cuboid} label="WASM Preview" detail="Adapter voorbereid" />
        </div>
      </section>
    </div>
  );
}

function Alert({ label, detail }: { label: string; detail: string }) {
  return (
    <div className="flex gap-3 rounded-xl border border-amber-200 bg-amber-50 p-3">
      <AlertTriangle size={18} className="mt-0.5 shrink-0 text-amber-600" />
      <div>
        <p className="text-sm font-medium text-amber-950">{label}</p>
        <p className="text-xs text-amber-700">{detail}</p>
      </div>
    </div>
  );
}

function Status({ icon: Icon, label, detail }: { icon: typeof Cpu; label: string; detail: string }) {
  return (
    <div className="flex items-center gap-3 rounded-xl border border-slate-200 p-3">
      <div className="rounded-lg bg-emerald-50 p-2 text-emerald-600"><Icon size={18} /></div>
      <div>
        <p className="text-sm font-medium">{label}</p>
        <p className="text-xs text-slate-500">{detail}</p>
      </div>
      <CheckCircle2 size={17} className="ml-auto text-emerald-500" />
    </div>
  );
}
