import Link from "next/link";
import { MoreVertical } from "lucide-react";
import { projects } from "@/data/demo";
import { StatusBadge } from "@/components/StatusBadge";

export function RecentProjectsTable() {
  return (
    <section className="app-card overflow-hidden">
      <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4">
        <h2 className="font-semibold">Recente projecten</h2>
        <Link href="/projects" className="text-sm text-blue-600">Bekijk alles</Link>
      </div>
      <div>
        {projects.map((project) => (
          <Link
            href={`/projects/${project.id}/builder`}
            key={project.id}
            className="grid grid-cols-[1.5fr_1fr_1fr_.8fr_.45fr] items-center gap-4 border-b border-slate-100 px-5 py-3 last:border-0 hover:bg-slate-50"
          >
            <div>
              <p className="text-sm font-medium text-slate-900">{project.name}</p>
              <p className="text-xs text-slate-500">{project.code}</p>
            </div>
            <p className="text-sm text-slate-600">{project.customer}</p>
            <div>
              <p className="text-sm text-slate-700">{project.material}</p>
              <p className="text-xs text-slate-400">{project.thicknessMm} mm</p>
            </div>
            <StatusBadge status={project.status} />
            <MoreVertical size={17} className="justify-self-end text-slate-400" />
          </Link>
        ))}
      </div>
    </section>
  );
}
