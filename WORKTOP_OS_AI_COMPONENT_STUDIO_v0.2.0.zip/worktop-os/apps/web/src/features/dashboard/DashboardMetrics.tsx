import { AlertOctagon, CheckCircle2, Clock3, FolderOpen, Upload } from "lucide-react";
import { MetricCard } from "@/components/MetricCard";

export function DashboardMetrics() {
  return (
    <div className="grid grid-cols-5 gap-4">
      <MetricCard label="Open projecten" value={24} change="12% deze week" icon={FolderOpen} tone="blue" />
      <MetricCard label="Review vereist" value={7} change="3 nieuwe" icon={Clock3} tone="amber" />
      <MetricCard label="Geblokkeerd" value={3} change="1 opgelost" icon={AlertOctagon} tone="red" />
      <MetricCard label="Productieklaar" value={11} change="5 meer" icon={CheckCircle2} tone="green" />
      <MetricCard label="Exports deze maand" value={47} change="18% groei" icon={Upload} tone="purple" />
    </div>
  );
}
