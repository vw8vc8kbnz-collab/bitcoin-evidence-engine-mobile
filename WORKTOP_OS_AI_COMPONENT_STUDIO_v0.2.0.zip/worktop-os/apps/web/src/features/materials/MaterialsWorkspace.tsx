import Image from "next/image";
import { Bookmark, Plus, Upload } from "lucide-react";
import { Button } from "@/components/Buttons";
import { slabs } from "@/data/demo";

export function MaterialsWorkspace() {
  return (
    <div className="grid grid-cols-[220px_minmax(0,1fr)_350px] gap-5">
      <aside className="app-card p-4">
        <h2 className="font-semibold">Filters</h2>
        {["Materiaalgroep", "Herkomst", "Afwerking", "Dikte", "Beschikbaarheid"].map((group) => (
          <div key={group} className="mt-5 border-t border-slate-100 pt-4 first:border-0">
            <p className="text-sm font-medium">{group}</p>
            <div className="mt-3 space-y-2">
              {["Alle", "Marmer", "Kwartsiet", "Keramiek"].slice(0, group === "Materiaalgroep" ? 4 : 3).map((label, index) => (
                <label key={label} className="flex items-center gap-2 text-sm text-slate-600">
                  <input type="checkbox" defaultChecked={index === 0} className="accent-blue-600" /> {label}
                </label>
              ))}
            </div>
          </div>
        ))}
      </aside>

      <section>
        <div className="mb-4 flex justify-between">
          <p className="text-sm font-medium">356 platen</p>
          <div className="flex gap-2"><Button><Upload size={16} /> Importeren</Button><Button variant="primary"><Plus size={16} /> Plaat toevoegen</Button></div>
        </div>
        <div className="grid grid-cols-3 gap-4">
          {slabs.concat(slabs.slice(0, 3)).map((slab, index) => (
            <article key={`${slab.id}-${index}`} className={`overflow-hidden rounded-xl border bg-white ${index === 0 ? "border-blue-500 ring-2 ring-blue-100" : "border-slate-200"}`}>
              <div className="relative h-40"><Image src={slab.src} alt={slab.name} fill className="object-cover" /></div>
              <div className="p-4">
                <h3 className="font-semibold">{slab.name}</h3>
                <p className="text-sm text-slate-500">{slab.group} · {slab.thickness}</p>
                <p className="mt-3 text-xs text-slate-500">Voorraad: {slab.stock}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <aside className="app-card sticky top-20 h-fit p-4">
        <div className="flex items-center justify-between"><h2 className="text-xl font-semibold">Calacatta Oro</h2><span className="rounded bg-emerald-50 px-2 py-1 text-xs text-emerald-700">Op voorraad</span></div>
        <div className="relative mt-4 h-56 overflow-hidden rounded-xl"><Image src="/demo/slab-calacatta.svg" alt="Calacatta Oro demo" fill className="object-cover" /></div>
        <dl className="mt-5 space-y-3 text-sm">
          <Row label="Plaat-ID" value="CO-2505-021" />
          <Row label="Dikte" value="20 mm" />
          <Row label="Afmetingen" value="3200 × 1600 mm" />
          <Row label="Herkomst" value="Italië" />
          <Row label="Defectzones" value="2 gemarkeerd" />
        </dl>
        <Button variant="primary" className="mt-5 w-full"><Bookmark size={17} /> Reserveer plaat</Button>
        <Button className="mt-2 w-full">Gebruik in nesting</Button>
      </aside>
    </div>
  );
}
function Row({ label, value }: { label: string; value: string }) { return <div className="flex justify-between"><dt className="text-slate-500">{label}</dt><dd className="font-medium">{value}</dd></div>; }
