const pieces = [
  { x: 5, y: 6, w: 31, h: 24, color: "#f59e0b", label: "A1" },
  { x: 38, y: 6, w: 25, h: 20, color: "#3b82f6", label: "A2" },
  { x: 66, y: 6, w: 29, h: 25, color: "#8b5cf6", label: "A3" },
  { x: 5, y: 34, w: 28, h: 27, color: "#ef4444", label: "A4" },
  { x: 36, y: 30, w: 31, h: 31, color: "#14b8a6", label: "A5" },
  { x: 70, y: 34, w: 25, h: 25, color: "#22c55e", label: "A6" },
  { x: 5, y: 65, w: 22, h: 25, color: "#6366f1", label: "A7" },
  { x: 30, y: 65, w: 22, h: 25, color: "#eab308", label: "A8" },
  { x: 55, y: 65, w: 20, h: 25, color: "#a855f7", label: "A9" },
  { x: 78, y: 65, w: 17, h: 25, color: "#84cc16", label: "A10" },
];

export function NestingCanvas() {
  return (
    <div className="relative aspect-[2/1] overflow-hidden rounded-xl border border-slate-300 bg-[url('/demo/slab-calacatta.svg')] bg-cover">
      {pieces.map((piece) => (
        <div
          key={piece.label}
          className="absolute flex items-start justify-between rounded-lg border-2 bg-white/35 p-2 backdrop-blur-[1px]"
          style={{ left: `${piece.x}%`, top: `${piece.y}%`, width: `${piece.w}%`, height: `${piece.h}%`, borderColor: piece.color }}
        >
          <span className="rounded px-2 py-1 text-xs font-semibold text-white" style={{ backgroundColor: piece.color }}>{piece.label}</span>
          <span className="h-10 w-14 rounded border-2" style={{ borderColor: piece.color }} />
        </div>
      ))}
    </div>
  );
}
