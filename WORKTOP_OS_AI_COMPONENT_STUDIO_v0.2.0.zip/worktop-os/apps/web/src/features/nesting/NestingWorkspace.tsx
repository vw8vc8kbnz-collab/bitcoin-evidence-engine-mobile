"use client";

import { useState } from "react";
import { BarChart3, Download, Sparkles } from "lucide-react";
import { Button } from "@/components/Buttons";
import { NestingCanvas } from "./NestingCanvas";

const modes = ["Quick", "Balanced", "Deep", "Grain First"] as const;

export function NestingWorkspace() {
  const [mode, setMode] = useState<(typeof modes)[number]>("Balanced");

  return (
    <div className="grid grid-cols-[250px_minmax(0,1fr)_300px] gap-5">
      <aside className="space-y-4">
        <section className="app-card p-4">
          <h2 className="font-semibold">1. Plaatselectie</h2>
          <div className="mt-3 rounded-xl border border-slate-200 p-3">
            <p className="text-sm font-medium">Calacatta Oro</p>
            <p className="text-xs text-slate-500">3200 × 1600 × 20 mm</p>
          </div>
        </section>
        <section className="app-card p-4">
          <h2 className="font-semibold">2. Nestingmodus</h2>
          <div className="mt-3 grid grid-cols-2 gap-2">
            {modes.map((item) => (
              <button key={item} onClick={() => setMode(item)} className={`rounded-lg border px-3 py-3 text-sm ${mode === item ? "border-blue-500 bg-blue-50 text-blue-700" : "border-slate-200"}`}>{item}</button>
            ))}
          </div>
        </section>
        <section className="app-card p-4">
          <h2 className="font-semibold">3. Nerfrichting</h2>
          <div className="mt-3 grid grid-cols-4 gap-2">
            {["Auto", "0°", "90°", "Custom"].map((item) => <button key={item} className="rounded-lg border border-slate-200 px-2 py-2 text-xs">{item}</button>)}
          </div>
        </section>
        <section className="app-card p-4">
          <h2 className="font-semibold">4. Afstanden</h2>
          <label className="mt-3 block text-xs text-slate-500">Onderdeelafstand<input className="app-input mt-1" value="10 mm" readOnly /></label>
          <label className="mt-3 block text-xs text-slate-500">Randmarge<input className="app-input mt-1" value="12 mm" readOnly /></label>
        </section>
        <Button variant="primary" className="w-full"><Sparkles size={17} /> Optimaliseren</Button>
      </aside>

      <section className="space-y-4">
        <div className="app-card p-4">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="font-semibold">Plaatpreview & nesting</h2>
            <span className="rounded bg-emerald-50 px-2 py-1 text-xs text-emerald-700">{mode}</span>
          </div>
          <NestingCanvas />
        </div>
        <div className="grid grid-cols-3 gap-4">
          {["A · Balanced", "B · Max yield", "C · Grain first"].map((item, index) => (
            <div key={item} className={`app-card p-3 ${index === 0 ? "ring-2 ring-blue-200" : ""}`}>
              <div className="h-24 rounded-lg bg-[url('/demo/slab-calacatta.svg')] bg-cover opacity-80" />
              <p className="mt-3 text-sm font-medium">{item}</p>
              <p className="text-xs text-slate-500">{[87.4, 89.1, 85.2][index]}% benutting</p>
            </div>
          ))}
        </div>
        <div className="grid grid-cols-4 gap-3">
          <Button><BarChart3 size={16} /> Vergelijk</Button>
          <Button>Preview DXF</Button>
          <Button>Resultaat opslaan</Button>
          <Button variant="primary"><Download size={16} /> Export nesting</Button>
        </div>
      </section>

      <aside className="space-y-4">
        <section className="app-card p-5">
          <h2 className="font-semibold">Resultaat</h2>
          <div className="mt-5 flex items-center justify-center">
            <div className="flex h-32 w-32 items-center justify-center rounded-full border-[14px] border-emerald-400 border-r-blue-400 text-center">
              <span><strong className="block text-2xl">87,4%</strong><small className="text-slate-500">benutting</small></span>
            </div>
          </div>
          <dl className="mt-5 space-y-3 text-sm">
            <Row label="Afval" value="12,6%" />
            <Row label="Machinetijd" value="1u 24m" />
            <Row label="Toolwissels" value="14" />
            <Row label="Nerfcontinuïteit" value="92,6%" />
            <Row label="Solvertijd" value="18,4 sec" />
          </dl>
        </section>
        <section className="app-card p-4">
          <h2 className="font-semibold">Oplossingen</h2>
          <div className="mt-3 space-y-2">
            {["A · Actief", "B · Max yield", "C · Grain first"].map((item, index) => <div key={item} className={`rounded-lg border p-3 text-sm ${index === 0 ? "border-blue-500 bg-blue-50" : "border-slate-200"}`}>{item}</div>)}
          </div>
        </section>
      </aside>
    </div>
  );
}
function Row({ label, value }: { label: string; value: string }) { return <div className="flex justify-between"><dt className="text-slate-500">{label}</dt><dd className="font-medium">{value}</dd></div>; }
