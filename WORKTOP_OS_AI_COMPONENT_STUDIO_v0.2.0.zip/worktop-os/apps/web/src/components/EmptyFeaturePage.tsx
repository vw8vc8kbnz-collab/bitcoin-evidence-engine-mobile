import { Construction } from "lucide-react";
import { PageHeader } from "./PageHeader";

export function EmptyFeaturePage({ title }: { title: string }) {
  return (
    <>
      <PageHeader title={title} description="Deze module is architectonisch voorbereid en wordt in een volgende release ingevuld." />
      <div className="app-card flex min-h-[520px] items-center justify-center">
        <div className="max-w-lg text-center">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-blue-50 text-blue-600">
            <Construction size={30} />
          </div>
          <h2 className="mt-5 text-xl font-semibold">Modulaire placeholder</h2>
          <p className="mt-2 text-sm leading-6 text-slate-500">
            De route, navigatie en layout staan al vast. Functionaliteit wordt toegevoegd zonder bestaande schermen monolithisch te maken.
          </p>
        </div>
      </div>
    </>
  );
}
