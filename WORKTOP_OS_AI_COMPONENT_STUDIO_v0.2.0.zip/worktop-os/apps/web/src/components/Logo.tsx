export function Logo() {
  return (
    <div className="flex items-center gap-3">
      <div className="relative h-8 w-8">
        <span className="absolute left-0 top-1 h-6 w-2 rotate-[-28deg] rounded bg-blue-500" />
        <span className="absolute left-3 top-1 h-6 w-2 rotate-[28deg] rounded bg-blue-400" />
        <span className="absolute right-0 top-1 h-6 w-2 rotate-[-28deg] rounded bg-blue-600" />
      </div>
      <span className="text-xl font-semibold tracking-tight text-white">Worktop OS</span>
    </div>
  );
}
