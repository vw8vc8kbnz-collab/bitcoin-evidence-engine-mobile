import type { LucideIcon } from "lucide-react";

interface MetricCardProps {
  label: string;
  value: string | number;
  change: string;
  icon: LucideIcon;
  tone: "blue" | "amber" | "red" | "green" | "purple";
}

const tones = {
  blue: "bg-blue-50 text-blue-600",
  amber: "bg-amber-50 text-amber-600",
  red: "bg-red-50 text-red-600",
  green: "bg-emerald-50 text-emerald-600",
  purple: "bg-violet-50 text-violet-600",
};

export function MetricCard({ label, value, change, icon: Icon, tone }: MetricCardProps) {
  return (
    <div className="app-card p-5">
      <div className="flex items-start gap-4">
        <div className={`rounded-xl p-3 ${tones[tone]}`}>
          <Icon size={22} />
        </div>
        <div>
          <p className="text-sm text-slate-500">{label}</p>
          <p className="mt-1 text-3xl font-semibold text-slate-950">{value}</p>
        </div>
      </div>
      <p className="mt-4 text-xs text-emerald-600">↑ {change}</p>
    </div>
  );
}
