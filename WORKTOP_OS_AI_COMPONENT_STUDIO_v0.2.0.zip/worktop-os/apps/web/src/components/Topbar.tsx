import { Bell, CircleHelp, Command, Search } from "lucide-react";
import { copy } from "@/lib/copy";

export function Topbar() {
  return (
    <header className="fixed left-[230px] right-0 top-0 z-30 flex h-16 items-center justify-between border-b border-white/10 bg-[var(--topbar)] px-7 text-white">
      <div className="flex items-center gap-4">
        <div className="flex w-[420px] items-center gap-3 rounded-lg border border-white/15 bg-white/5 px-3 py-2 text-sm text-slate-300">
          <Search size={17} />
          <span>{copy.searchPlaceholder}</span>
          <span className="ml-auto flex items-center gap-1 rounded bg-white/8 px-2 py-1 text-xs">
            <Command size={12} /> K
          </span>
        </div>
        <button className="rounded-lg border border-white/15 bg-white/5 px-4 py-2 text-sm">
          {copy.tenant}
        </button>
      </div>

      <div className="flex items-center gap-5">
        <button className="relative text-slate-300 hover:text-white">
          <Bell size={20} />
          <span className="absolute -right-2 -top-2 rounded-full bg-blue-500 px-1.5 text-[10px] text-white">6</span>
        </button>
        <button className="flex items-center gap-2 text-sm text-slate-300 hover:text-white">
          <CircleHelp size={20} />
          Help
        </button>
        <button className="flex items-center gap-3">
          <span className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-amber-100 to-amber-300 font-semibold text-slate-900">
            SR
          </span>
          <span className="text-sm">{copy.userName}</span>
        </button>
      </div>
    </header>
  );
}
