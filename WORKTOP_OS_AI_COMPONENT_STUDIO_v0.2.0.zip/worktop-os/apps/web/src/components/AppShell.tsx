import type { ReactNode } from "react";
import { Sidebar } from "./Sidebar";
import { Topbar } from "./Topbar";

export function AppShell({ children }: { children: ReactNode }) {
  return (
    <>
      <Sidebar />
      <Topbar />
      <main className="min-h-screen bg-[var(--canvas)] pl-[230px] pt-16">
        <div className="mx-auto max-w-[1700px] p-7">{children}</div>
      </main>
      <div className="desktop-only-message fixed inset-0 z-[100] hidden items-center justify-center bg-slate-950 p-8 text-center text-white">
        <div>
          <h2 className="text-2xl font-semibold">Worktop OS is desktop-only</h2>
          <p className="mt-2 max-w-md text-slate-300">
            Gebruik een scherm van minimaal 1180 pixels breed om de productie-editor veilig te bedienen.
          </p>
        </div>
      </div>
    </>
  );
}
