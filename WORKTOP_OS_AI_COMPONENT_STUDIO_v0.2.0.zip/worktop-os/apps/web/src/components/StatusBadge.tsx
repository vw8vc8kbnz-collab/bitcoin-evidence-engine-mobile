import type { ProjectStatus, VerificationStatus } from "@worktop/domain";
import { cn } from "@/lib/cn";

type Status = ProjectStatus | VerificationStatus | "PASSED" | "WARNING" | "BLOCKED";

const labels: Record<Status, string> = {
  CONCEPT: "Concept",
  REVIEW_REQUIRED: "Review vereist",
  BLOCKED: "Geblokkeerd",
  READY_FOR_PRODUCTION: "Productieklaar",
  RELEASED: "Vrijgegeven",
  CANDIDATE: "Kandidaat",
  HUMAN_CHECKED: "Menselijk gecontroleerd",
  TENANT_VERIFIED: "Tenant verified",
  PLATFORM_VERIFIED: "Platform verified",
  SUPERSEDED: "Vervangen",
  PASSED: "Geslaagd",
  WARNING: "Waarschuwing",
};

export function StatusBadge({ status }: { status: Status }) {
  const style =
    status === "READY_FOR_PRODUCTION" || status === "RELEASED" || status === "PLATFORM_VERIFIED" || status === "PASSED"
      ? "bg-emerald-50 text-emerald-700 border-emerald-200"
      : status === "REVIEW_REQUIRED" || status === "WARNING"
        ? "bg-amber-50 text-amber-700 border-amber-200"
        : status === "BLOCKED"
          ? "bg-red-50 text-red-700 border-red-200"
          : "bg-blue-50 text-blue-700 border-blue-200";

  return (
    <span className={cn("inline-flex rounded-md border px-2 py-1 text-xs font-medium", style)}>
      {labels[status]}
    </span>
  );
}
