"use client";

import {
  Bot,
  Boxes,
  Building2,
  ClipboardCheck,
  Cuboid,
  FileClock,
  FolderKanban,
  Gauge,
  Layers3,
  LayoutDashboard,
  PanelLeftClose,
  ScrollText,
  Settings2,
  Users,
} from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Logo } from "./Logo";
import { cn } from "@/lib/cn";

const items = [
  { label: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
  { label: "Projecten", href: "/projects", icon: FolderKanban },
  { label: "Product Library", href: "/library", icon: Cuboid },
  { label: "AI Component Studio", href: "/library/ai-ingestion", icon: Bot },
  { label: "Materialen & platen", href: "/materials", icon: Boxes },
  { label: "Restplaten", href: "/remnants", icon: Layers3 },
  { label: "Machineprofielen", href: "/machine-profiles", icon: Gauge },
  { label: "Layer mapping", href: "/layer-mapping", icon: Settings2 },
  { label: "Productiestandaarden", href: "/production-standards", icon: ClipboardCheck },
  { label: "Exporthistorie", href: "/export-history", icon: FileClock },
  { label: "Team", href: "/team", icon: Users },
  { label: "Organisatie", href: "/organization", icon: Building2 },
  { label: "Auditlog", href: "/audit", icon: ScrollText },
];

export function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="fixed inset-y-0 left-0 z-40 flex w-[230px] flex-col bg-[var(--sidebar)] px-3 py-5 text-slate-300">
      <div className="px-2 pb-7">
        <Logo />
      </div>

      <nav className="space-y-1">
        {items.map(({ label, href, icon: Icon }) => {
          const active = pathname === href || pathname.startsWith(`${href}/`);
          return (
            <Link
              key={href}
              href={href}
              className={cn(
                "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition",
                active
                  ? "bg-blue-600 text-white shadow-lg shadow-blue-950/20"
                  : "hover:bg-white/7 hover:text-white",
              )}
            >
              <Icon size={18} strokeWidth={1.8} />
              {label}
            </Link>
          );
        })}
      </nav>

      <div className="mt-auto border-t border-white/10 pt-4">
        <button className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-left hover:bg-white/7">
          <Building2 size={19} />
          <span>
            <span className="block text-sm font-medium text-white">StoneFab Surfaces</span>
            <span className="text-xs text-slate-400">Enterprise</span>
          </span>
        </button>
        <button className="mt-3 flex items-center gap-3 px-3 py-2 text-sm text-slate-400 hover:text-white">
          <PanelLeftClose size={17} />
          Inklappen
        </button>
      </div>
    </aside>
  );
}
