import { createHash, randomUUID } from "node:crypto";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import type { SourceManifestItem } from "@worktop/ai-ingestion";

const MAX_FILE_BYTES = 20 * 1024 * 1024;
const MAX_TOTAL_BYTES = 50 * 1024 * 1024;
const allowedMimeTypes = new Set([
  "image/jpeg",
  "image/png",
  "image/webp",
  "application/pdf",
  "text/plain",
  "application/dxf",
  "image/vnd.dwg",
  "application/acad",
  "application/octet-stream",
]);

export interface StoredUpload {
  manifest: SourceManifestItem;
  bytes: Buffer;
}

function safeFileName(name: string): string {
  const extension = path.extname(name).toLowerCase();
  const base = path.basename(name, extension).replace(/[^a-zA-Z0-9._-]+/g, "-").slice(0, 90);
  return `${base || "source"}${extension}`;
}

function classifySource(file: File): SourceManifestItem["sourceKind"] {
  if (file.type.startsWith("image/")) return "PRODUCT_IMAGE";
  const extension = path.extname(file.name).toLowerCase();
  if ([".dxf", ".dwg"].includes(extension)) return "VECTOR_SOURCE";
  return "OFFICIAL_DOCUMENT";
}

function validateFile(file: File): void {
  if (file.size <= 0) throw new Error(`${file.name}: leeg bestand.`);
  if (file.size > MAX_FILE_BYTES) throw new Error(`${file.name}: maximaal 20 MB per bestand.`);
  const extension = path.extname(file.name).toLowerCase();
  const extensionAllowed = [".jpg", ".jpeg", ".png", ".webp", ".pdf", ".txt", ".dxf", ".dwg"].includes(extension);
  if (!allowedMimeTypes.has(file.type) && !extensionAllowed) {
    throw new Error(`${file.name}: bestandstype niet toegestaan.`);
  }
}

export async function storeIngestionFiles(input: {
  jobId: string;
  files: File[];
  rightsScope: SourceManifestItem["rightsScope"];
}): Promise<StoredUpload[]> {
  if (input.files.length === 0) throw new Error("Upload minimaal één bronbestand.");
  if (input.files.length > 12) throw new Error("Maximaal 12 bestanden per analyse.");
  for (const file of input.files) validateFile(file);
  const totalBytes = input.files.reduce((sum, file) => sum + file.size, 0);
  if (totalBytes > MAX_TOTAL_BYTES) throw new Error("De totale upload mag maximaal 50 MB zijn.");

  const root = process.env.WORKTOP_DATA_DIR
    ? path.resolve(process.env.WORKTOP_DATA_DIR)
    : path.resolve(process.cwd(), "data");
  const directory = path.join(root, "ai-ingestion", input.jobId);
  await mkdir(directory, { recursive: true });

  const stored: StoredUpload[] = [];
  for (const file of input.files) {
    const bytes = Buffer.from(await file.arrayBuffer());
    const sourceId = randomUUID();
    const storedName = `${sourceId}-${safeFileName(file.name)}`;
    const absolutePath = path.join(directory, storedName);
    await writeFile(absolutePath, bytes, { mode: 0o600 });
    stored.push({
      bytes,
      manifest: {
        id: sourceId,
        originalName: file.name,
        mimeType: file.type || "application/octet-stream",
        sizeBytes: file.size,
        sha256: createHash("sha256").update(bytes).digest("hex"),
        storagePath: absolutePath,
        sourceKind: classifySource(file),
        rightsScope: input.rightsScope,
      },
    });
  }
  return stored;
}
