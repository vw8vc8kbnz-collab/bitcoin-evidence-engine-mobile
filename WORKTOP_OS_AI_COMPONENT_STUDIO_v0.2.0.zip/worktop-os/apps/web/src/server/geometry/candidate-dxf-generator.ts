import { execFile } from "node:child_process";
import { access, mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { promisify } from "node:util";
import {
  geometryGenerationResultSchema,
  type AiComponentExtraction,
  type GeometryGenerationResult,
  type IngestionInstallationMode,
} from "@worktop/ai-ingestion";

const execFileAsync = promisify(execFile);
const supportedShapes = new Set(["RECTANGLE", "ROUNDED_RECTANGLE", "CIRCLE", "POLYLINE"]);

function micron(value: number | null): number {
  return value === null ? 0 : Math.round(value * 1000);
}

function safeLayer(value: string): string {
  return value.toUpperCase().replace(/[^A-Z0-9_-]+/g, "_").slice(0, 120);
}

function serializePoints(points: Array<{ x: number; y: number }>): string {
  if (points.length === 0) return "-";
  return points.map((point) => `${micron(point.x)},${micron(point.y)}`).join(";");
}

function engineCandidates(): string[] {
  if (process.env.WORKTOP_ENGINE_CLI) return [path.resolve(process.env.WORKTOP_ENGINE_CLI)];
  return [
    path.resolve(process.cwd(), "engine/core/build/worktop-engine-cli"),
    path.resolve(process.cwd(), "../../engine/core/build/worktop-engine-cli"),
  ];
}

async function findEngine(): Promise<string> {
  for (const candidate of engineCandidates()) {
    try {
      await access(candidate);
      return candidate;
    } catch {
      // Try the next deterministic location. There is deliberately no JS fallback.
    }
  }
  throw new Error("De native C++ Worktop Engine is niet beschikbaar voor kandidaat-DXF-generatie.");
}

function manifestForInstallation(
  installation: AiComponentExtraction["installations"][number],
): { manifest: string; operationCount: number; issues: string[] } {
  const lines = ["WORKTOP_COMPONENT_DXF_V1"];
  const issues: string[] = [];
  let operationCount = 0;
  for (const operation of installation.operations) {
    const shape = operation.shape;
    if (!supportedShapes.has(shape.kind)) {
      issues.push(`${installation.mode}/${operation.operationType}: vorm ${shape.kind} wordt nog niet door de C++-kandidaatcompiler ondersteund.`);
      continue;
    }
    if (!shape.sourceScaleConfirmed) {
      issues.push(`${installation.mode}/${operation.operationType}: bronschaal is niet bevestigd.`);
      continue;
    }
    if (shape.datumOffsetXmm === null || shape.datumOffsetYmm === null) {
      issues.push(`${installation.mode}/${operation.operationType}: fabrikant-datumoffset ontbreekt.`);
      continue;
    }
    const rectangular = shape.kind === "RECTANGLE" || shape.kind === "ROUNDED_RECTANGLE";
    if (rectangular && (shape.widthMm === null || shape.heightMm === null)) {
      issues.push(`${installation.mode}/${operation.operationType}: breedte of hoogte ontbreekt.`);
      continue;
    }
    if (shape.kind === "ROUNDED_RECTANGLE" && shape.cornerRadiusMm === null) {
      issues.push(`${installation.mode}/${operation.operationType}: hoekradius ontbreekt.`);
      continue;
    }
    if (shape.kind === "CIRCLE" && shape.diameterMm === null) {
      issues.push(`${installation.mode}/${operation.operationType}: diameter ontbreekt.`);
      continue;
    }
    if (shape.kind === "POLYLINE" && shape.pointsMm.length < 3) {
      issues.push(`${installation.mode}/${operation.operationType}: polyline heeft minder dan drie punten.`);
      continue;
    }
    const depthLabel = operation.depthMm === null ? "UNKNOWN" : operation.depthMm.toFixed(3).replace(".", "_");
    const layer = safeLayer(`AI_${installation.mode}_${operation.operationType}_D${depthLabel}`);
    lines.push([
      "OP",
      operation.operationType,
      shape.kind,
      layer,
      micron(shape.widthMm).toString(),
      micron(shape.heightMm).toString(),
      micron(shape.diameterMm).toString(),
      micron(shape.cornerRadiusMm).toString(),
      micron(shape.datumOffsetXmm).toString(),
      micron(shape.datumOffsetYmm).toString(),
      micron(operation.depthMm).toString(),
      serializePoints(shape.pointsMm),
    ].join("\t"));
    operationCount += 1;
  }
  return { manifest: `${lines.join("\n")}\n`, operationCount, issues };
}

async function generateInstallationAsset(input: {
  jobId: string;
  mode: IngestionInstallationMode;
  manifest: string;
  operationCount: number;
  enginePath: string;
}): Promise<GeometryGenerationResult["assets"][number]> {
  const dataRoot = process.env.WORKTOP_DATA_DIR
    ? path.resolve(process.env.WORKTOP_DATA_DIR)
    : path.resolve(process.cwd(), "data");
  const directory = path.join(dataRoot, "ai-ingestion", input.jobId, "generated");
  await mkdir(directory, { recursive: true });
  const manifestPath = path.join(directory, `candidate-${input.mode}.tsv`);
  const fileName = `candidate-${input.mode}.dxf`;
  const outputPath = path.join(directory, fileName);
  await writeFile(manifestPath, input.manifest, { encoding: "utf8", mode: 0o600 });
  const { stdout } = await execFileAsync(input.enginePath, ["component-dxf", manifestPath, outputPath], {
    timeout: 30_000,
    maxBuffer: 1024 * 1024,
  });
  const engineResult = JSON.parse(stdout) as { engineVersion: string; valid: boolean; entityCount: number };
  if (!engineResult.valid || engineResult.entityCount !== input.operationCount) {
    throw new Error(`C++-engine retourneerde geen volledige DXF voor ${input.mode}.`);
  }
  return {
    installationMode: input.mode,
    fileName,
    storagePath: outputPath,
    operationCount: input.operationCount,
    engineVersion: engineResult.engineVersion,
  };
}

export async function generateCandidateDxfs(
  jobId: string,
  result: AiComponentExtraction,
): Promise<GeometryGenerationResult> {
  const assets: GeometryGenerationResult["assets"] = [];
  const issues: string[] = [];
  let enginePath: string;
  try {
    enginePath = await findEngine();
  } catch (error) {
    return geometryGenerationResultSchema.parse({
      status: "FAILED",
      assets,
      issues: [error instanceof Error ? error.message : "C++-engine niet beschikbaar."],
    });
  }

  for (const installation of result.installations) {
    if (!installation.documented || installation.supportStatus !== "DOCUMENTED") continue;
    const candidate = manifestForInstallation(installation);
    issues.push(...candidate.issues);
    if (candidate.operationCount === 0) continue;
    try {
      assets.push(await generateInstallationAsset({
        jobId,
        mode: installation.mode,
        manifest: candidate.manifest,
        operationCount: candidate.operationCount,
        enginePath,
      }));
    } catch (error) {
      issues.push(error instanceof Error ? error.message : `DXF-generatie mislukt voor ${installation.mode}.`);
    }
  }

  const status = assets.length === 0
    ? (issues.length > 0 ? "NOT_GENERATED" : "NOT_GENERATED")
    : (issues.length > 0 ? "PARTIAL" : "GENERATED");
  return geometryGenerationResultSchema.parse({ status, assets, issues });
}
