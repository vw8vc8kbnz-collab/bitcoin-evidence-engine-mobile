import OpenAI from "openai";
import { zodTextFormat } from "openai/helpers/zod";
import {
  AI_COMPONENT_INGESTION_SYSTEM_PROMPT,
  aiComponentExtractionSchema,
  buildIngestionUserPrompt,
  type AiComponentExtraction,
} from "@worktop/ai-ingestion";
import type { StoredUpload } from "@/server/storage/local-file-storage";

const SUPPORTED_IMAGE_MIME = new Set(["image/jpeg", "image/png", "image/webp"]);
const SUPPORTED_DOCUMENT_MIME = new Set([
  "application/pdf",
  "text/plain",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
]);

function dataUrl(mimeType: string, bytes: Buffer): string {
  return `data:${mimeType};base64,${bytes.toString("base64")}`;
}

function createSourceContent(sources: StoredUpload[]): Array<Record<string, unknown>> {
  const content: Array<Record<string, unknown>> = [];
  for (const source of sources) {
    if (source.manifest.sourceKind === "VECTOR_SOURCE") {
      content.push({
        type: "input_text",
        text: `Vector source ${source.manifest.originalName} is securely stored for later C++ parsing. Its geometry is not supplied to this AI pass. Do not claim dimensions from this file.`,
      });
      continue;
    }
    if (SUPPORTED_IMAGE_MIME.has(source.manifest.mimeType)) {
      content.push({
        type: "input_image",
        image_url: dataUrl(source.manifest.mimeType, source.bytes),
        detail: "high",
      });
      continue;
    }
    if (SUPPORTED_DOCUMENT_MIME.has(source.manifest.mimeType)) {
      content.push({
        type: "input_file",
        filename: source.manifest.originalName,
        file_data: dataUrl(source.manifest.mimeType, source.bytes),
      });
    }
  }
  return content;
}

async function runExtractionPass(input: {
  client: OpenAI;
  model: string;
  sources: StoredUpload[];
  userPrompt: string;
  previousCandidate?: AiComponentExtraction;
}): Promise<AiComponentExtraction> {
  const sourceContent = createSourceContent(input.sources);
  const verificationInstruction = input.previousCandidate
    ? `\nThis is a verification pass. Independently re-check all source files against the first candidate below. Correct errors, preserve unresolved uncertainty, and add explicit conflicts.\nFIRST CANDIDATE:\n${JSON.stringify(input.previousCandidate)}`
    : "";
  const response = await input.client.responses.parse({
    model: input.model,
    input: [
      { role: "system", content: AI_COMPONENT_INGESTION_SYSTEM_PROMPT },
      {
        role: "user",
        content: [
          { type: "input_text", text: `${input.userPrompt}${verificationInstruction}` },
          ...sourceContent,
        ] as never,
      },
    ],
    text: {
      format: zodTextFormat(aiComponentExtractionSchema, "worktop_component_candidate"),
    },
  });
  if (!response.output_parsed) {
    throw new Error("OpenAI retourneerde geen geldige gestructureerde componentkandidaat.");
  }
  return aiComponentExtractionSchema.parse(response.output_parsed);
}

export async function analyzeComponentSources(input: {
  sources: StoredUpload[];
  manufacturerHint?: string;
  modelHint?: string;
  notes?: string;
}): Promise<{ result: AiComponentExtraction; model: string; passes: number }> {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) throw new Error("OPENAI_API_KEY ontbreekt op de server.");
  const model = process.env.OPENAI_INGESTION_MODEL ?? "gpt-5.6";
  const client = new OpenAI({ apiKey, timeout: 180_000, maxRetries: 2 });
  const userPrompt = buildIngestionUserPrompt({
    manufacturerHint: input.manufacturerHint,
    modelHint: input.modelHint,
    notes: input.notes,
    fileNames: input.sources.map((source) => source.manifest.originalName),
  });
  const first = await runExtractionPass({ client, model, sources: input.sources, userPrompt });
  const verifierEnabled = process.env.OPENAI_INGESTION_VERIFIER !== "false";
  if (!verifierEnabled) return { result: first, model, passes: 1 };
  const verified = await runExtractionPass({
    client,
    model,
    sources: input.sources,
    userPrompt,
    previousCandidate: first,
  });
  return { result: verified, model, passes: 2 };
}
