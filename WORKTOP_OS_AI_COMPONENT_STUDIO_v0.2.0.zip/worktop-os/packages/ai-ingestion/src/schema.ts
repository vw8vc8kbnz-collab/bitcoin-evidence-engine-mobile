import { z } from "zod";

export const componentCategorySchema = z.enum([
  "COOKTOP",
  "SINK",
  "FAUCET",
  "SOAP_DISPENSER",
  "SOCKET",
  "OTHER",
]);

export const installationModeSchema = z.enum([
  "TOP_MOUNT",
  "FLUSH_MOUNT",
  "UNDER_MOUNT",
  "THROUGH_HOLE",
  "OTHER",
]);

export const sourceEvidenceSchema = z.object({
  evidenceId: z.string(),
  fileName: z.string(),
  pageNumber: z.number().int().nullable(),
  drawingReference: z.string().nullable(),
  sectionTitle: z.string().nullable(),
  evidenceSummary: z.string(),
});

export const extractedValueSchema = z.object({
  label: z.string(),
  value: z.string().nullable(),
  unit: z.string().nullable(),
  evidenceIds: z.array(z.string()),
  confidence: z.enum(["HIGH", "MEDIUM", "LOW", "UNKNOWN"]),
  notes: z.string().nullable(),
});

export const geometryShapeSchema = z.object({
  kind: z.enum([
    "RECTANGLE",
    "ROUNDED_RECTANGLE",
    "CIRCLE",
    "ELLIPSE",
    "POLYLINE",
    "MULTI_CONTOUR",
    "UNKNOWN",
  ]),
  widthMm: z.number().nullable(),
  heightMm: z.number().nullable(),
  diameterMm: z.number().nullable(),
  cornerRadiusMm: z.number().nullable(),
  datumOffsetXmm: z.number().nullable(),
  datumOffsetYmm: z.number().nullable(),
  pointsMm: z.array(z.object({ x: z.number(), y: z.number() })),
  sourceScaleConfirmed: z.boolean(),
});

export const operationCandidateSchema = z.object({
  operationType: z.enum([
    "THROUGH_CUT",
    "REBATE",
    "TOP_POCKET",
    "BOTTOM_POCKET",
    "DRILL",
    "MOUNTING_ZONE",
    "SERVICE_ZONE",
    "REFERENCE_ONLY",
    "UNKNOWN",
  ]),
  shape: geometryShapeSchema,
  depthMm: z.number().nullable(),
  toleranceMm: z.number().nullable(),
  zReference: z.enum(["TOP", "BOTTOM", "THROUGH", "UNKNOWN"]),
  evidenceIds: z.array(z.string()),
  confidence: z.enum(["HIGH", "MEDIUM", "LOW", "UNKNOWN"]),
  requiresHumanConfirmation: z.boolean(),
  notes: z.string().nullable(),
});

export const installationCandidateSchema = z.object({
  mode: installationModeSchema,
  documented: z.boolean(),
  supportStatus: z.enum([
    "DOCUMENTED",
    "NOT_SUPPORTED",
    "AMBIGUOUS",
    "MISSING_DATA",
  ]),
  operations: z.array(operationCandidateSchema),
  minimumWorktopThicknessMm: z.number().nullable(),
  maximumWorktopThicknessMm: z.number().nullable(),
  allowedMaterialGroups: z.array(z.string()),
  prohibitedMaterialGroups: z.array(z.string()),
  evidenceIds: z.array(z.string()),
  missingCriticalFields: z.array(z.string()),
  notes: z.string().nullable(),
});

export const aiComponentExtractionSchema = z.object({
  identity: z.object({
    manufacturer: z.string().nullable(),
    model: z.string().nullable(),
    series: z.string().nullable(),
    articleNumber: z.string().nullable(),
    ean: z.string().nullable(),
    revision: z.string().nullable(),
    marketRegion: z.string().nullable(),
    category: componentCategorySchema,
    identityConfidence: z.enum(["HIGH", "MEDIUM", "LOW", "UNKNOWN"]),
    identityRequiresConfirmation: z.boolean(),
    notes: z.string().nullable(),
  }),
  productDimensions: z.object({
    widthMm: z.number().nullable(),
    depthMm: z.number().nullable(),
    heightMm: z.number().nullable(),
    evidenceIds: z.array(z.string()),
  }),
  installations: z.array(installationCandidateSchema),
  additionalValues: z.array(extractedValueSchema),
  sourceEvidence: z.array(sourceEvidenceSchema),
  conflicts: z.array(
    z.object({
      field: z.string(),
      description: z.string(),
      evidenceIds: z.array(z.string()),
      blocksVerification: z.boolean(),
    }),
  ),
  missingCriticalData: z.array(z.string()),
  safetyWarnings: z.array(z.string()),
  extractionSummary: z.string(),
  automaticDecision: z.enum([
    "CANDIDATE_READY_FOR_REVIEW",
    "BLOCKED_IDENTITY_AMBIGUOUS",
    "BLOCKED_SOURCE_CONFLICT",
    "BLOCKED_INSUFFICIENT_DATA",
  ]),
});

export type AiComponentExtraction = z.infer<typeof aiComponentExtractionSchema>;
export type ComponentCategory = z.infer<typeof componentCategorySchema>;
export type IngestionInstallationMode = z.infer<typeof installationModeSchema>;

export const sourceManifestItemSchema = z.object({
  id: z.string(),
  originalName: z.string(),
  mimeType: z.string(),
  sizeBytes: z.number().int().nonnegative(),
  sha256: z.string(),
  storagePath: z.string(),
  sourceKind: z.enum(["PRODUCT_IMAGE", "OFFICIAL_DOCUMENT", "VECTOR_SOURCE"]),
  rightsScope: z.enum(["TENANT_PRIVATE", "PLATFORM_LICENSED"]),
});

export const ingestionJobStatusSchema = z.enum([
  "UPLOADED",
  "AI_ANALYZING",
  "AI_EXTRACTED_CANDIDATE",
  "GEOMETRY_REVIEW_REQUIRED",
  "BLOCKED",
  "FAILED",
]);

export type SourceManifestItem = z.infer<typeof sourceManifestItemSchema>;
export type IngestionJobStatus = z.infer<typeof ingestionJobStatusSchema>;

export const candidateDxfAssetSchema = z.object({
  installationMode: installationModeSchema,
  fileName: z.string(),
  storagePath: z.string(),
  operationCount: z.number().int().nonnegative(),
  engineVersion: z.string(),
});

export const geometryGenerationResultSchema = z.object({
  status: z.enum(["GENERATED", "PARTIAL", "NOT_GENERATED", "FAILED"]),
  assets: z.array(candidateDxfAssetSchema),
  issues: z.array(z.string()),
});

export type CandidateDxfAsset = z.infer<typeof candidateDxfAssetSchema>;
export type GeometryGenerationResult = z.infer<typeof geometryGenerationResultSchema>;
