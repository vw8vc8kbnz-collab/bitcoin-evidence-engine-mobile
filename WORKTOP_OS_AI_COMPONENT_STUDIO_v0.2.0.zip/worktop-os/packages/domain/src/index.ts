export type ProjectStatus =
  | "CONCEPT"
  | "REVIEW_REQUIRED"
  | "BLOCKED"
  | "READY_FOR_PRODUCTION"
  | "RELEASED";

export type VerificationStatus =
  | "CANDIDATE"
  | "HUMAN_CHECKED"
  | "TENANT_VERIFIED"
  | "PLATFORM_VERIFIED"
  | "SUPERSEDED"
  | "BLOCKED";

export type InstallationMode = "TOP_MOUNT" | "FLUSH_MOUNT" | "UNDER_MOUNT";

export interface WorktopProject {
  id: string;
  code: string;
  name: string;
  customer: string;
  material: string;
  thicknessMm: number;
  status: ProjectStatus;
  progress: number;
  updatedAt: string;
}

export interface ProductImage {
  id: string;
  kind: "HERO" | "GALLERY" | "TECHNICAL";
  src: string;
  alt: string;
  rightsStatus: "DEMO" | "MANUFACTURER_APPROVED" | "TENANT_PROVIDED";
}

export interface ProductComponent {
  id: string;
  brand: string;
  model: string;
  category: "COOKTOP" | "SINK" | "FAUCET" | "SOAP_DISPENSER" | "SOCKET";
  dimensionsLabel: string;
  cutoutLabel: string;
  verificationStatus: VerificationStatus;
  installationModes: InstallationMode[];
  images: ProductImage[];
}

export interface ValidationCheck {
  id: string;
  label: string;
  detail: string;
  severity: "PASSED" | "WARNING" | "BLOCKED" | "INFO";
}

export function deriveProductionReady(checks: ValidationCheck[]): boolean {
  return checks.every((check) => check.severity !== "BLOCKED");
}

export function formatInstallationMode(mode: InstallationMode): string {
  const labels: Record<InstallationMode, string> = {
    TOP_MOUNT: "Opbouw",
    FLUSH_MOUNT: "Vlakinbouw",
    UNDER_MOUNT: "Onderbouw",
  };
  return labels[mode];
}
