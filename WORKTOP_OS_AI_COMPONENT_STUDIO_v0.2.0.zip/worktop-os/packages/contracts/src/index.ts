import { z } from "zod";

export const pointSchema = z.object({
  xMicrons: z.int(),
  yMicrons: z.int(),
});

export const worktopOutlineSchema = z.object({
  id: z.string().min(1),
  points: z.array(pointSchema).min(3),
  closed: z.boolean(),
});

export const geometryRequestSchema = z.object({
  projectRevisionId: z.string().min(1),
  engineMode: z.enum(["INTERACTIVE", "EXACT"]),
  outline: worktopOutlineSchema,
});

export const geometryDiagnosticSchema = z.object({
  code: z.string(),
  severity: z.enum(["INFO", "WARNING", "BLOCKED"]),
  message: z.string(),
});

export const geometryResponseSchema = z.object({
  ok: z.boolean(),
  engineVersion: z.string(),
  inputHash: z.string(),
  diagnostics: z.array(geometryDiagnosticSchema),
});

export type GeometryRequest = z.infer<typeof geometryRequestSchema>;
export type GeometryResponse = z.infer<typeof geometryResponseSchema>;
