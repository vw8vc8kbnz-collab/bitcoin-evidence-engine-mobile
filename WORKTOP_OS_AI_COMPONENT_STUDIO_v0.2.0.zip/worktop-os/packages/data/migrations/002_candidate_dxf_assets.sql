ALTER TABLE ai_ingestion_jobs
  ADD COLUMN IF NOT EXISTS generated_assets JSONB NOT NULL DEFAULT '{"status":"NOT_GENERATED","assets":[],"issues":[]}'::jsonb;

ALTER TABLE component_candidates
  ADD COLUMN IF NOT EXISTS generated_assets JSONB NOT NULL DEFAULT '{"status":"NOT_GENERATED","assets":[],"issues":[]}'::jsonb;
