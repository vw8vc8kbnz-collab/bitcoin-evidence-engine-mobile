CREATE TABLE IF NOT EXISTS schema_migrations (
  id TEXT PRIMARY KEY,
  applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS ai_ingestion_jobs (
  id TEXT PRIMARY KEY,
  status TEXT NOT NULL,
  manufacturer_hint TEXT,
  model_hint TEXT,
  notes TEXT,
  requested_by TEXT,
  openai_model TEXT,
  error_message TEXT,
  result JSONB,
  source_manifest JSONB NOT NULL DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS ai_ingestion_sources (
  id TEXT PRIMARY KEY,
  job_id TEXT NOT NULL REFERENCES ai_ingestion_jobs(id) ON DELETE CASCADE,
  original_name TEXT NOT NULL,
  stored_name TEXT NOT NULL,
  mime_type TEXT NOT NULL,
  size_bytes BIGINT NOT NULL,
  sha256 TEXT NOT NULL,
  storage_path TEXT NOT NULL,
  source_kind TEXT NOT NULL,
  rights_scope TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_ai_ingestion_sources_job_id
  ON ai_ingestion_sources(job_id);

CREATE TABLE IF NOT EXISTS component_candidates (
  id TEXT PRIMARY KEY,
  job_id TEXT UNIQUE NOT NULL REFERENCES ai_ingestion_jobs(id) ON DELETE CASCADE,
  status TEXT NOT NULL,
  manufacturer TEXT,
  model TEXT,
  category TEXT,
  identity JSONB NOT NULL,
  product_dimensions JSONB NOT NULL,
  installations JSONB NOT NULL,
  additional_values JSONB NOT NULL,
  source_evidence JSONB NOT NULL,
  conflicts JSONB NOT NULL,
  missing_critical_data JSONB NOT NULL,
  safety_warnings JSONB NOT NULL,
  extraction_summary TEXT NOT NULL,
  automatic_decision TEXT NOT NULL,
  raw_result JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_component_candidates_status
  ON component_candidates(status);
CREATE INDEX IF NOT EXISTS idx_component_candidates_identity
  ON component_candidates(manufacturer, model);
