import type {
  AiComponentExtraction,
  GeometryGenerationResult,
  IngestionJobStatus,
  SourceManifestItem,
} from "@worktop/ai-ingestion";
import { getPool } from "./pool";

export interface CreateIngestionJobInput {
  id: string;
  status: IngestionJobStatus;
  manufacturerHint?: string;
  modelHint?: string;
  notes?: string;
  requestedBy?: string;
  openaiModel?: string;
  sources: SourceManifestItem[];
}

export interface IngestionJobRecord {
  id: string;
  status: IngestionJobStatus;
  manufacturerHint: string | null;
  modelHint: string | null;
  notes: string | null;
  openaiModel: string | null;
  errorMessage: string | null;
  result: AiComponentExtraction | null;
  sourceManifest: SourceManifestItem[];
  generatedAssets: GeometryGenerationResult;
  createdAt: string;
  updatedAt: string;
}

export async function createIngestionJob(input: CreateIngestionJobInput): Promise<void> {
  const client = await getPool().connect();
  try {
    await client.query("BEGIN");
    await client.query(
      `INSERT INTO ai_ingestion_jobs
       (id, status, manufacturer_hint, model_hint, notes, requested_by, openai_model, source_manifest)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8::jsonb)`,
      [
        input.id,
        input.status,
        input.manufacturerHint ?? null,
        input.modelHint ?? null,
        input.notes ?? null,
        input.requestedBy ?? null,
        input.openaiModel ?? null,
        JSON.stringify(input.sources),
      ],
    );
    for (const source of input.sources) {
      await client.query(
        `INSERT INTO ai_ingestion_sources
         (id, job_id, original_name, stored_name, mime_type, size_bytes, sha256, storage_path, source_kind, rights_scope)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
        [
          source.id,
          input.id,
          source.originalName,
          source.storagePath.split("/").at(-1) ?? source.originalName,
          source.mimeType,
          source.sizeBytes,
          source.sha256,
          source.storagePath,
          source.sourceKind,
          source.rightsScope,
        ],
      );
    }
    await client.query("COMMIT");
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}

export async function updateIngestionJobStatus(
  id: string,
  status: IngestionJobStatus,
  errorMessage?: string,
): Promise<void> {
  await getPool().query(
    `UPDATE ai_ingestion_jobs
     SET status=$2, error_message=$3, updated_at=NOW()
     WHERE id=$1`,
    [id, status, errorMessage ?? null],
  );
}

export async function saveExtractionCandidate(
  jobId: string,
  candidateId: string,
  result: AiComponentExtraction,
): Promise<void> {
  const client = await getPool().connect();
  const status: IngestionJobStatus = result.automaticDecision === "CANDIDATE_READY_FOR_REVIEW"
    ? "GEOMETRY_REVIEW_REQUIRED"
    : "BLOCKED";
  try {
    await client.query("BEGIN");
    await client.query(
      `INSERT INTO component_candidates
       (id, job_id, status, manufacturer, model, category, identity, product_dimensions,
        installations, additional_values, source_evidence, conflicts, missing_critical_data,
        safety_warnings, extraction_summary, automatic_decision, raw_result)
       VALUES ($1,$2,$3,$4,$5,$6,$7::jsonb,$8::jsonb,$9::jsonb,$10::jsonb,$11::jsonb,
        $12::jsonb,$13::jsonb,$14::jsonb,$15,$16,$17::jsonb)
       ON CONFLICT (job_id) DO UPDATE SET
        status=EXCLUDED.status,
        identity=EXCLUDED.identity,
        product_dimensions=EXCLUDED.product_dimensions,
        installations=EXCLUDED.installations,
        additional_values=EXCLUDED.additional_values,
        source_evidence=EXCLUDED.source_evidence,
        conflicts=EXCLUDED.conflicts,
        missing_critical_data=EXCLUDED.missing_critical_data,
        safety_warnings=EXCLUDED.safety_warnings,
        extraction_summary=EXCLUDED.extraction_summary,
        automatic_decision=EXCLUDED.automatic_decision,
        raw_result=EXCLUDED.raw_result,
        updated_at=NOW()`,
      [
        candidateId,
        jobId,
        status,
        result.identity.manufacturer,
        result.identity.model,
        result.identity.category,
        JSON.stringify(result.identity),
        JSON.stringify(result.productDimensions),
        JSON.stringify(result.installations),
        JSON.stringify(result.additionalValues),
        JSON.stringify(result.sourceEvidence),
        JSON.stringify(result.conflicts),
        JSON.stringify(result.missingCriticalData),
        JSON.stringify(result.safetyWarnings),
        result.extractionSummary,
        result.automaticDecision,
        JSON.stringify(result),
      ],
    );
    await client.query(
      `UPDATE ai_ingestion_jobs
       SET status=$2, result=$3::jsonb, error_message=NULL, updated_at=NOW()
       WHERE id=$1`,
      [jobId, status, JSON.stringify(result)],
    );
    await client.query("COMMIT");
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}

export async function saveGeneratedAssets(
  jobId: string,
  generatedAssets: GeometryGenerationResult,
): Promise<void> {
  await getPool().query(
    `UPDATE ai_ingestion_jobs
     SET generated_assets=$2::jsonb, updated_at=NOW()
     WHERE id=$1`,
    [jobId, JSON.stringify(generatedAssets)],
  );
  await getPool().query(
    `UPDATE component_candidates
     SET generated_assets=$2::jsonb, updated_at=NOW()
     WHERE job_id=$1`,
    [jobId, JSON.stringify(generatedAssets)],
  );
}

export async function getIngestionJob(id: string): Promise<IngestionJobRecord | null> {
  const result = await getPool().query(
    `SELECT id, status, manufacturer_hint, model_hint, notes, openai_model,
            error_message, result, source_manifest, generated_assets, created_at, updated_at
     FROM ai_ingestion_jobs WHERE id=$1`,
    [id],
  );
  const row = result.rows[0];
  if (!row) return null;
  return {
    id: row.id,
    status: row.status,
    manufacturerHint: row.manufacturer_hint,
    modelHint: row.model_hint,
    notes: row.notes,
    openaiModel: row.openai_model,
    errorMessage: row.error_message,
    result: row.result,
    sourceManifest: row.source_manifest,
    generatedAssets: row.generated_assets,
    createdAt: new Date(row.created_at).toISOString(),
    updatedAt: new Date(row.updated_at).toISOString(),
  };
}

export async function listIngestionJobs(limit = 20): Promise<IngestionJobRecord[]> {
  const result = await getPool().query(
    `SELECT id, status, manufacturer_hint, model_hint, notes, openai_model,
            error_message, result, source_manifest, generated_assets, created_at, updated_at
     FROM ai_ingestion_jobs ORDER BY created_at DESC LIMIT $1`,
    [Math.min(Math.max(limit, 1), 100)],
  );
  return result.rows.map((row) => ({
    id: row.id,
    status: row.status,
    manufacturerHint: row.manufacturer_hint,
    modelHint: row.model_hint,
    notes: row.notes,
    openaiModel: row.openai_model,
    errorMessage: row.error_message,
    result: row.result,
    sourceManifest: row.source_manifest,
    generatedAssets: row.generated_assets,
    createdAt: new Date(row.created_at).toISOString(),
    updatedAt: new Date(row.updated_at).toISOString(),
  }));
}
