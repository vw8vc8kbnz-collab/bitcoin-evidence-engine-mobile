const fs = require("node:fs");
const path = require("node:path");

function loadEnv(filePath) {
  if (!fs.existsSync(filePath)) return {};
  return Object.fromEntries(
    fs.readFileSync(filePath, "utf8")
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter((line) => line && !line.startsWith("#") && line.includes("="))
      .map((line) => {
        const index = line.indexOf("=");
        return [line.slice(0, index), line.slice(index + 1)];
      }),
  );
}

const env = loadEnv("/etc/worktop-os/worktop-os.env");

module.exports = {
  apps: [
    {
      name: "worktop-os",
      cwd: path.resolve(__dirname),
      script: "npm",
      args: "run start --workspace @worktop/web",
      env: {
        NODE_ENV: "production",
        PORT: "8895",
        HOSTNAME: "0.0.0.0",
        ...env,
      },
      max_memory_restart: "1400M",
      autorestart: true,
      time: true,
    },
  ],
};
