# Worktop OS v0.2.0 — AI Component Ingestion Foundation

Clean, schaalbaar fundament voor de desktop-first Worktop OS SaaS met een eerste volledig server-side **AI Component Ingestion Studio**.

## Wat is nieuw in v0.2.0?

- Nieuwe route `/library/ai-ingestion` in de definitieve Worktop OS UX.
- Upload van echte productfoto’s, officiële fabrikant-PDF’s en optionele DXF/DWG-bronnen.
- OpenAI Responses API uitsluitend server-side; de API-key wordt nooit naar de browser gestuurd.
- Strikt Zod/Structured Outputs-schema voor componentidentiteit, installatiemethoden, geometriekandidaten, bronverwijzingen, conflicten en ontbrekende data.
- Standaard twee analysepasses: extractie plus onafhankelijke verificatie.
- Productfoto’s worden alleen als herkenningsbron gebruikt, nooit als maatbron.
- DXF/DWG wordt veilig opgeslagen voor latere autoritatieve C++-parsing en niet door AI als productiewaarheid geïnterpreteerd.
- PostgreSQL-opslag voor analysejobs, bronnen en `component_candidates`.
- Native C++ kandidaat-DXF-compiler voor expliciet gedocumenteerde rechthoeken, afgeronde rechthoeken, cirkels en polylijnen.
- Een aparte review-DXF per gedocumenteerde installatiemethode, met een harde `AI_CANDIDATE_NOT_VERIFIED` markering.
- Kandidaatstatussen blijven fail-closed: geen automatische tenant- of platformverificatie.
- VPS-deployment met Docker PostgreSQL, PM2, persistente data en een verborgen Termius-keyprompt.

## Architectuur

```text
Browser
  -> Next.js upload route
  -> beveiligde lokale bronopslag
  -> OpenAI Responses API + Structured Outputs
  -> AI_EXTRACTED_CANDIDATE
  -> PostgreSQL
  -> native C++ kandidaat-DXF wanneer alle bronparameters compleet zijn
  -> later: side-by-side human review
  -> later: geverifieerde Geometry Set en machineprofiel-DXF
```

De OpenAI-laag maakt uitsluitend kandidaten. De C++-engine blijft de enige toekomstige bron voor autoritatieve geometrie, validatie en DXF-output.

## Lokaal starten

```bash
npm install
cp .env.example .env.local
# start PostgreSQL en vul DATABASE_URL + OPENAI_API_KEY
npm run db:migrate
npm run dev
```

Open daarna `http://localhost:3000/library/ai-ingestion`.

## Alles verifiëren

```bash
NEXT_TELEMETRY_DISABLED=1 NODE_OPTIONS=--max-old-space-size=2048 npm run verify
```

Deze opdracht controleert:

1. bronstructuur en maximale bestandsgrootte;
2. native C++-build;
3. C++-tests;
4. TypeScript;
5. ESLint;
6. Next.js-productiebuild.

## Serverdeploy

Lees `DEPLOYMENT_TERMIUS_v0.2.0.md`. Secrets staan buiten de repository in:

```text
/etc/worktop-os/worktop-os.env
```

Persistente uploads en PostgreSQL-data staan in:

```text
/var/lib/worktop-os/
```

## Belangrijke grenzen

- Een AI-resultaat is nooit productieklaar.
- Productiefoto’s zijn geen bron voor CNC-maten.
- Vectorbestanden wachten op de C++-importer.
- Productiepublicatie blijft geblokkeerd tot menselijke review en C++-validatie bestaan.
- De meegeleverde productafbeeldingen elders in de foundation zijn demo-assets, geen gelicentieerde fabrikantcatalogus.
