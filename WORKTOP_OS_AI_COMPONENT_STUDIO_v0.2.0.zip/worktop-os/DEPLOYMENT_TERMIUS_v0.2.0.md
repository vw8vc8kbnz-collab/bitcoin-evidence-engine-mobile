# Worktop OS v0.2.0 — GitHub → VPS → Termius

## Verwachte ZIP-naam

```text
WORKTOP_OS_AI_COMPONENT_STUDIO_v0.2.0.zip
```

Upload deze ZIP ongewijzigd naar:

```text
https://github.com/vw8vc8kbnz-collab/bitcoin-evidence-engine-mobile
```

De exacte Raw URL wordt dan:

```text
https://raw.githubusercontent.com/vw8vc8kbnz-collab/bitcoin-evidence-engine-mobile/main/WORKTOP_OS_AI_COMPONENT_STUDIO_v0.2.0.zip
```

## Vereisten op de VPS

- Node.js 22 of nieuwer
- npm
- CMake en een C++20-compiler
- Docker met `docker compose`
- PM2
- curl, unzip en rsync
- Python 3 voor alleen de nette health-output

PM2 eenmalig installeren wanneer nodig:

```bash
sudo npm install -g pm2
```

## Exacte Termius update-opdracht

Deze regel bewaart alle secrets en persistente data buiten de applicatiemap:

```bash
set -euo pipefail; ZIP='WORKTOP_OS_AI_COMPONENT_STUDIO_v0.2.0.zip'; URL="https://raw.githubusercontent.com/vw8vc8kbnz-collab/bitcoin-evidence-engine-mobile/main/$ZIP"; TMP="$(mktemp -d)"; curl -fL "$URL" -o "$TMP/$ZIP"; unzip -q "$TMP/$ZIP" -d "$TMP/release"; sudo mkdir -p /var/www/worktop-os; sudo rsync -a --delete --exclude='.env*' --exclude='data' --exclude='node_modules' --exclude='.next' "$TMP/release/worktop-os/" /var/www/worktop-os/; sudo chown -R "$USER":"$USER" /var/www/worktop-os; cd /var/www/worktop-os; bash scripts/deploy/deploy.sh; rm -rf "$TMP"
```

De deploy doet automatisch:

1. beveiligde omgeving aanmaken of behouden;
2. dedicated PostgreSQL-container starten op `127.0.0.1:55432`;
3. dependencies installeren met `npm ci`;
4. C++ bouwen en testen;
5. TypeScript, ESLint en Next.js-build uitvoeren;
6. database-migraties uitvoeren;
7. Worktop OS via PM2 starten op poort `8895`;
8. healthcheck en PM2-status tonen.

## OpenAI-key veilig invoeren

Na de eerste deploy:

```bash
cd /var/www/worktop-os && bash scripts/deploy/set-openai-key.sh
```

Termius vraagt dan:

```text
Plak de OpenAI API-key (invoer blijft verborgen):
```

De key:

- verschijnt niet op het scherm;
- komt niet in je shell history;
- komt niet in GitHub;
- wordt opgeslagen in `/etc/worktop-os/worktop-os.env`;
- wordt alleen server-side door de API-route gebruikt;
- activeert na invoer automatisch een PM2-restart.

## Health en status controleren

```bash
curl -sS http://127.0.0.1:8895/api/health | python3 -m json.tool && pm2 status worktop-os && pm2 logs worktop-os --lines 80 --nostream && sudo docker ps --filter name=worktop-os-postgres
```

Verwachte kernwaarden:

```json
{
  "ok": true,
  "version": "0.2.0",
  "database": true,
  "openaiConfigured": true
}
```

## AI Component Studio openen

Zonder nginx:

```text
http://VPS-IP:8895/library/ai-ingestion
```

Voor een domein staat een voorbeeld in:

```text
infra/nginx/worktop-os.conf.example
```

Daarna aanpassen naar het eigen domein, activeren en nginx herladen.

## Persistente locaties

```text
/etc/worktop-os/worktop-os.env      secrets en runtime-config
/var/lib/worktop-os/data            uploads en bronbestanden
/var/lib/worktop-os/postgres        PostgreSQL-data
/var/www/worktop-os                 applicatiecode
```

Een volgende ZIP-update verwijdert deze data niet.

## Model of verificatiepass wijzigen

Open het configuratiebestand:

```bash
nano /etc/worktop-os/worktop-os.env
```

Beschikbare regels:

```text
OPENAI_INGESTION_MODEL=gpt-5.6
OPENAI_INGESTION_VERIFIER=true
```

Daarna:

```bash
cd /var/www/worktop-os && pm2 startOrReload ecosystem.config.cjs --update-env && pm2 save
```

## OpenAI-key vervangen

Voer opnieuw uit:

```bash
cd /var/www/worktop-os && bash scripts/deploy/set-openai-key.sh
```

## Belangrijk

Een succesvolle AI-analyse maakt alleen een `AI_EXTRACTED_CANDIDATE`. Deze versie publiceert bewust nog geen definitieve productie-DXF en geeft geen `TENANT_VERIFIED` of `PLATFORM_VERIFIED` status.
