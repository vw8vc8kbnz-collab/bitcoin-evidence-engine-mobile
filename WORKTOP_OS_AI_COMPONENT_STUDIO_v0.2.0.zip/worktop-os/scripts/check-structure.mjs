import fs from "node:fs";
import path from "node:path";

const ROOT = process.cwd();
const SOURCE_ROOTS = [
  "apps/web/src",
  "packages/domain/src",
  "packages/contracts/src",
  "packages/ai-ingestion/src",
  "packages/data/src",
  "engine/core/include",
  "engine/core/src",
];

const ignored = new Set(["node_modules", ".next", "build", "dist"]);
const maxLinesByExtension = new Map([
  [".ts", 320],
  [".tsx", 360],
  [".css", 500],
  [".cpp", 320],
  [".hpp", 260],
]);

const failures = [];

function walk(relativePath) {
  const absolutePath = path.join(ROOT, relativePath);
  if (!fs.existsSync(absolutePath)) return;

  for (const entry of fs.readdirSync(absolutePath, { withFileTypes: true })) {
    if (ignored.has(entry.name)) continue;
    const childRelative = path.join(relativePath, entry.name);
    if (entry.isDirectory()) {
      walk(childRelative);
      continue;
    }

    const extension = path.extname(entry.name);
    const limit = maxLinesByExtension.get(extension);
    if (!limit) continue;

    const lineCount = fs.readFileSync(path.join(ROOT, childRelative), "utf8").split(/\r?\n/).length;
    if (lineCount > limit) {
      failures.push(`${childRelative}: ${lineCount} regels (maximum ${limit})`);
    }
  }
}

for (const sourceRoot of SOURCE_ROOTS) walk(sourceRoot);

if (failures.length > 0) {
  console.error("Structuurcontrole mislukt:\n" + failures.map((item) => `- ${item}`).join("\n"));
  process.exit(1);
}

console.log("Structuurcontrole geslaagd: geen monolithische bronbestanden gevonden.");
