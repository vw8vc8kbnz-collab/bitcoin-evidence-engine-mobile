#!/usr/bin/env bash
set -euo pipefail

APP_DIR=/var/www/worktop-os
ENV_FILE=/etc/worktop-os/worktop-os.env
cd "$APP_DIR"
bash scripts/deploy/bootstrap-env.sh

read -rsp "Plak de OpenAI API-key (invoer blijft verborgen): " API_KEY
echo
if [[ -z "$API_KEY" ]]; then
  echo "Geen key ingevoerd; niets gewijzigd."
  exit 1
fi
if [[ "$API_KEY" != sk-* ]]; then
  echo "Waarschuwing: de ingevoerde waarde heeft niet het gebruikelijke sk-voorvoegsel."
fi

TEMP_FILE="$(mktemp)"
awk -v key="$API_KEY" '
  BEGIN { found=0 }
  /^OPENAI_API_KEY=/ { print "OPENAI_API_KEY=" key; found=1; next }
  { print }
  END { if (!found) print "OPENAI_API_KEY=" key }
' "$ENV_FILE" > "$TEMP_FILE"
cat "$TEMP_FILE" > "$ENV_FILE"
rm -f "$TEMP_FILE"
chmod 600 "$ENV_FILE"
unset API_KEY

echo "OpenAI-key beveiligd opgeslagen in $ENV_FILE."
if command -v pm2 >/dev/null 2>&1 && pm2 describe worktop-os >/dev/null 2>&1; then
  pm2 startOrReload ecosystem.config.cjs --update-env
  pm2 save
  echo "Worktop OS opnieuw gestart met de nieuwe key."
fi
