#!/usr/bin/env bash
set -euo pipefail

ENV_DIR=/etc/worktop-os
ENV_FILE="$ENV_DIR/worktop-os.env"
DATA_DIR=/var/lib/worktop-os
APP_USER="${SUDO_USER:-$USER}"

sudo mkdir -p "$ENV_DIR" "$DATA_DIR/data" "$DATA_DIR/postgres"
sudo chown -R "$APP_USER":"$APP_USER" "$ENV_DIR" "$DATA_DIR"

if [[ ! -f "$ENV_FILE" ]]; then
  DB_PASSWORD="$(openssl rand -hex 24)"
  cat > "$ENV_FILE" <<ENV
NEXT_PUBLIC_APP_NAME=Worktop OS
PORT=8895
HOSTNAME=0.0.0.0
POSTGRES_PASSWORD=$DB_PASSWORD
DATABASE_URL=postgresql://worktop:$DB_PASSWORD@127.0.0.1:55432/worktop
DATABASE_POOL_SIZE=10
WORKTOP_DATA_DIR=/var/lib/worktop-os/data
WORKTOP_ENGINE_CLI=/var/www/worktop-os/engine/core/build/worktop-engine-cli
OPENAI_API_KEY=
OPENAI_INGESTION_MODEL=gpt-5.6
OPENAI_INGESTION_VERIFIER=true
ENV
fi

ensure_var() {
  local key="$1"
  local value="$2"
  if ! grep -q "^${key}=" "$ENV_FILE"; then
    printf '%s=%s
' "$key" "$value" >> "$ENV_FILE"
  fi
}

ensure_var NEXT_PUBLIC_APP_NAME "Worktop OS"
ensure_var PORT "8895"
ensure_var HOSTNAME "0.0.0.0"
ensure_var DATABASE_POOL_SIZE "10"
ensure_var WORKTOP_DATA_DIR "/var/lib/worktop-os/data"
ensure_var WORKTOP_ENGINE_CLI "/var/www/worktop-os/engine/core/build/worktop-engine-cli"
ensure_var OPENAI_API_KEY ""
ensure_var OPENAI_INGESTION_MODEL "gpt-5.6"
ensure_var OPENAI_INGESTION_VERIFIER "true"

chmod 600 "$ENV_FILE"
ln -sfn "$ENV_FILE" .env.production.local
