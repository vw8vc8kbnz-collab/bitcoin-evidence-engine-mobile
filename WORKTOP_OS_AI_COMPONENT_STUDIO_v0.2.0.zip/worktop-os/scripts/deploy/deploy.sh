#!/usr/bin/env bash
set -euo pipefail

APP_DIR=/var/www/worktop-os
ENV_FILE=/etc/worktop-os/worktop-os.env
cd "$APP_DIR"

for command in node npm cmake docker openssl curl python3; do
  if ! command -v "$command" >/dev/null 2>&1; then
    echo "Vereiste opdracht ontbreekt: $command"
    exit 1
  fi
done
if ! command -v pm2 >/dev/null 2>&1; then
  echo "PM2 ontbreekt. Installeer eenmalig met: sudo npm install -g pm2"
  exit 1
fi

bash scripts/deploy/bootstrap-env.sh
set -a
# shellcheck disable=SC1090
source "$ENV_FILE"
set +a

sudo docker compose --env-file "$ENV_FILE" -f infra/docker-compose.production.yml up -d
for attempt in {1..30}; do
  if sudo docker exec worktop-os-postgres pg_isready -U worktop -d worktop >/dev/null 2>&1; then
    break
  fi
  if [[ "$attempt" == 30 ]]; then
    echo "PostgreSQL werd niet tijdig gezond."
    exit 1
  fi
  sleep 2
done

npm ci
npm run verify
npm run db:migrate
pm2 startOrReload ecosystem.config.cjs --update-env
pm2 save

sleep 3
curl -fsS http://127.0.0.1:${PORT:-8895}/api/health | python3 -m json.tool || true
pm2 status worktop-os

echo "Worktop OS v0.2.0 is uitgerold op poort ${PORT:-8895}."
if [[ -z "${OPENAI_API_KEY:-}" ]]; then
  echo "OpenAI-key ontbreekt nog. Voer uit: bash $APP_DIR/scripts/deploy/set-openai-key.sh"
fi
