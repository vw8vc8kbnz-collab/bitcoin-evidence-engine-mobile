#!/usr/bin/env bash
set -u

PORT="${PORT:-8895}"
echo "=== Worktop OS health ==="
curl -sS "http://127.0.0.1:${PORT}/api/health" | python3 -m json.tool || true
echo
echo "=== PM2 ==="
pm2 status worktop-os || true
echo
echo "=== Laatste logs ==="
pm2 logs worktop-os --lines 60 --nostream || true
echo
echo "=== PostgreSQL container ==="
sudo docker ps --filter name=worktop-os-postgres || true
echo
echo "=== Persistente opslag ==="
sudo du -sh /var/lib/worktop-os/data /var/lib/worktop-os/postgres 2>/dev/null || true
