import { rm } from "node:fs/promises";
import path from "node:path";

const target = path.resolve("apps/web/.next");
await rm(target, { recursive: true, force: true });
console.log("Schone Next-buildoutput voorbereid.");
