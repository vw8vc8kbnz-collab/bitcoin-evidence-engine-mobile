import pg from "pg";
import { readdir, readFile } from "node:fs/promises";
import path from "node:path";
import process from "node:process";

const { Client } = pg;
const connectionString = process.env.DATABASE_URL;
if (!connectionString) {
  console.error("DATABASE_URL ontbreekt.");
  process.exit(1);
}

const migrationsDir = path.resolve("packages/data/migrations");
const files = (await readdir(migrationsDir))
  .filter((file) => file.endsWith(".sql"))
  .sort();

const client = new Client({ connectionString });
try {
  await client.connect();
  await client.query(`CREATE TABLE IF NOT EXISTS schema_migrations (
    id TEXT PRIMARY KEY,
    applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  )`);
  for (const file of files) {
    const alreadyApplied = await client.query("SELECT 1 FROM schema_migrations WHERE id=$1", [file]);
    if (alreadyApplied.rowCount) {
      console.log(`Overgeslagen: ${file}`);
      continue;
    }
    const sql = await readFile(path.join(migrationsDir, file), "utf8");
    await client.query("BEGIN");
    try {
      await client.query(sql);
      await client.query("INSERT INTO schema_migrations (id) VALUES ($1)", [file]);
      await client.query("COMMIT");
      console.log(`Toegepast: ${file}`);
    } catch (error) {
      await client.query("ROLLBACK");
      throw error;
    }
  }
  console.log("Database-migraties geslaagd.");
} finally {
  await client.end();
}
