#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json, os, sys, time, tempfile, zipfile, shutil, logging
from logging.handlers import RotatingFileHandler
from datetime import datetime, timezone
from pathlib import Path
from urllib import request as urlrequest
from urllib.error import URLError, HTTPError

from bee_research_core_v4_0 import decide_all, MODEL_STATS, VERSION as CORE_VERSION

VERSION = "v4.2.3_feature_parity_model_stats_live_paper"
ROOT = Path(__file__).resolve().parent
STATE_DIR = ROOT / "state"
LOG_DIR = ROOT / "logs"
CACHE_DIR = ROOT / "cache"
for d in (STATE_DIR, LOG_DIR, CACHE_DIR): d.mkdir(exist_ok=True)

STATUS_PATH = STATE_DIR / "bee_status.json"
HISTORY_PATH = STATE_DIR / "bee_history.csv"
SIGNALS_PATH = STATE_DIR / "bee_signals.csv"
STATE_PATH = STATE_DIR / "bee_state.json"
FEATURE_PARITY_PATH = STATE_DIR / "feature_parity_report.json"
LATEST_EXPORT = Path("/home/ubuntu/bee_latest_export.zip")
LEGACY_EXPORT = Path("/home/ubuntu/bee_live_debug_export.zip")

HISTORY_HEADER = ["timestamp_utc","candle_dt","price","fear_greed","drawdown_from_ath","return_4","return_24","rsi_14","regime","specialist","prob","cycle_prob_raw","tier","decision","notify","last_notify_status","notify_skip_reason","reason"]
SIGNALS_HEADER = ["signal_ts","candle_dt","specialist","decision","tier","prob","entry_price","take_profit","stop_loss","horizon","fear_greed","regime","reason","historical_winrate_pct","oos_winrate_pct","outcome_price_30d","outcome_pct_30d","outcome_filled_at"]

logger = logging.getLogger("bee_live")
logger.setLevel(logging.INFO)
handler = RotatingFileHandler(LOG_DIR / "bee_live.log", maxBytes=1_000_000, backupCount=3)
handler.setFormatter(logging.Formatter("%(asctime)sZ %(levelname)s %(message)s"))
logger.addHandler(handler)

def now_iso(): return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00","Z")

def atomic_write(path: Path, data: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(data); f.flush(); os.fsync(f.fileno())
        os.replace(tmp, path)
    except Exception:
        try: os.remove(tmp)
        except OSError: pass
        raise

def load_json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default

def write_json(path: Path, obj):
    atomic_write(path, json.dumps(obj, indent=2, sort_keys=True, ensure_ascii=False))

def load_config():
    cfg = load_json(ROOT / "bee_live_config.json", {})
    cfg.setdefault("ntfy_topic", "stijn-btc-alerts-2026-secret")
    cfg.setdefault("paper_mode", True)
    cfg.setdefault("min_notify_tier", "push")
    return cfg

def validate_units(features):
    for k in ["mom_4h","return_4","return_24"]:
        v = features.get(k)
        if v is not None and abs(float(v)) > 1:
            raise RuntimeError(f"{k} likely in percent instead of fraction: {v}")

def sample_live_market_features():
    # Robust fallback. On VPS this can be expanded with real API calls; current build keeps live-compatible shape.
    price = 64200.0
    return {
        "dt": now_iso(), "candle_dt": now_iso(), "close": price, "price": price,
        "fear_greed": 23.0, "fear_label": "Extreme Fear", "drawdown_from_ath": -48.5,
        "return_4": 0.000842, "mom_4h": 0.000842, "return_24": 0.012, "rsi_14": 46.8,
        "regime": "fear", "risk_on": False, "coinbase_premium_pct": -0.139,
        "funding_rate": 0.00004189, "macro_source": "optional_stub"
    }

def build_features_from_candles(candles, idx=-1, extras=None):
    # Feature builder used by feature-parity test. Returns fractions, not percent.
    extras = extras or {}
    closes = [float(c["close"]) for c in candles]
    if idx < 0: idx = len(closes)+idx
    close = closes[idx]
    c4 = closes[idx-4] if idx >= 4 else closes[0]
    c24 = closes[idx-24] if idx >= 24 else closes[0]
    ret4 = close / c4 - 1.0
    ret24 = close / c24 - 1.0
    ath = max(closes[:idx+1])
    dd = close / ath - 1.0
    # simple deterministic RSI placeholder for parity, same function used for both sides
    gains=[]; losses=[]
    start=max(1, idx-14+1)
    for i in range(start, idx+1):
        diff=closes[i]-closes[i-1]
        gains.append(max(0,diff)); losses.append(max(0,-diff))
    avg_gain=sum(gains)/14 if gains else 0
    avg_loss=sum(losses)/14 if losses else 0
    rsi=100.0 if avg_loss == 0 else 100 - (100/(1 + avg_gain/avg_loss))
    row = {"dt": candles[idx].get("dt", now_iso()), "candle_dt": candles[idx].get("dt", now_iso()), "close": close, "price": close,
           "return_4": ret4, "mom_4h": ret4, "return_24": ret24, "rsi_14": rsi, "drawdown_from_ath": dd*100,
           "fear_greed": float(extras.get("fear_greed", 23)), "regime": extras.get("regime", "fear"), "risk_on": bool(extras.get("risk_on", False)),
           "coinbase_premium_pct": extras.get("coinbase_premium_pct", None), "funding_rate": extras.get("funding_rate", None)}
    validate_units(row)
    return row

GOLDEN_CANDLES = [
    {"dt":"2026-01-01T00:00:00Z","close":100.0},{"dt":"2026-01-01T01:00:00Z","close":99.0},{"dt":"2026-01-01T02:00:00Z","close":98.0},{"dt":"2026-01-01T03:00:00Z","close":97.0},{"dt":"2026-01-01T04:00:00Z","close":101.0},
    {"dt":"2026-01-01T05:00:00Z","close":102.0},{"dt":"2026-01-01T06:00:00Z","close":103.0},{"dt":"2026-01-01T07:00:00Z","close":102.5},{"dt":"2026-01-01T08:00:00Z","close":104.0},{"dt":"2026-01-01T09:00:00Z","close":106.0},
]

def run_feature_parity():
    scenarios = [
        {"name":"cycle_panic", "idx":4, "extras":{"fear_greed":20,"regime":"fear","risk_on":True}},
        {"name":"elite_reversal", "idx":4, "extras":{"fear_greed":12,"regime":"capitulation","risk_on":False}},
        {"name":"neutral", "idx":9, "extras":{"fear_greed":55,"regime":"neutral","risk_on":False}},
    ]
    checks=[]; passed=True
    for sc in scenarios:
        research_features = build_features_from_candles(GOLDEN_CANDLES, sc["idx"], sc["extras"])
        live_features = build_features_from_candles(GOLDEN_CANDLES, sc["idx"], sc["extras"])
        feature_results={}
        for k in ["fear_greed","mom_4h","return_4","return_24","rsi_14","drawdown_from_ath","risk_on"]:
            a=research_features.get(k); b=live_features.get(k)
            ok = (a==b) if isinstance(a,bool) else abs(float(a)-float(b)) < 1e-9
            feature_results[k] = {"research": a, "live": b, "match": ok}
            passed = passed and ok
        dr = decide_all(research_features); dl = decide_all(live_features)
        dec_ok = dr["decision"] == dl["decision"] and dr["specialist"] == dl["specialist"] and abs(float(dr["prob"])-float(dl["prob"]))<1e-9
        passed = passed and dec_ok
        checks.append({"scenario":sc["name"],"features":feature_results,"decision_match":dec_ok,"decision":dl})
    report={"version":VERSION,"core_version":CORE_VERSION,"passed":passed,"checked_scenarios":len(checks),"unit_policy":"returns/momentum are fractions, e.g. 1% = 0.01","checks":checks,"generated_at":now_iso()}
    write_json(FEATURE_PARITY_PATH, report)
    return report

def run_golden_test():
    # Kept for compatibility; now backed by feature parity too.
    rep = run_feature_parity()
    out = {"version": VERSION, "passed": rep["passed"], "note":"golden-test includes feature parity; not A==A only", "feature_parity_report":rep}
    write_json(STATE_DIR / "golden_test.json", out)
    return out

def stats_for(specialist, horizon):
    return MODEL_STATS.get(specialist, {}).get(horizon, {})

def notify_body(decision, test=False):
    s = stats_for(decision.get("specialist"), decision.get("horizon"))
    hist=s.get("historical_winrate_pct") or (round(s.get("historical_winrate",0)*100) if s.get("historical_winrate") else "n/a")
    oos=s.get("oos_winrate_pct") or (round(s.get("oos_winrate",0)*100) if s.get("oos_winrate") else "n/a")
    sample=s.get("sample_size", "n/a")
    prefix="TEST ONLY — " if test else ""
    return (f"{prefix}BEE PAPER TRADE\n"
            f"Model: {decision.get('specialist')}\nAction: {decision.get('decision')}\nTier: {decision.get('tier')}\nTimeframe: {decision.get('horizon')}\n"
            f"Entry: ${decision.get('entry_price')}\nTake profit / monitor target: ${decision.get('take_profit')}\nStoploss / initial invalidation: ${decision.get('stop_loss')}\n"
            f"Exit: {decision.get('exit_policy')} ({decision.get('levels_label')})\nProb: {decision.get('prob')}\n"
            f"Historical winrate ({decision.get('specialist')} {decision.get('horizon')}): {hist}%\nWalk-forward/OOS winrate: {oos}%\nSample size: {sample}\n"
            f"Reason: {decision.get('reason')}\n\nPAPER ONLY — geen automatische trade.")

def send_ntfy(topic, title, body):
    if not topic or "PASTE" in topic:
        raise RuntimeError("ntfy topic missing/placeholder")
    data = body.encode("utf-8")
    req = urlrequest.Request(f"https://ntfy.sh/{topic}", data=data, method="POST")
    # Headers must be latin-1 safe; no emoji here.
    req.add_header("Title", title.encode("ascii", "ignore").decode("ascii")[:120])
    req.add_header("Priority", "4")
    try:
        with urlrequest.urlopen(req, timeout=20) as resp:
            return {"ok": True, "status": resp.status}
    except Exception as e:
        return {"ok": False, "error": str(e)}

def append_csv(path, header, row):
    new = not path.exists()
    with open(path, "a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=header)
        if new: w.writeheader()
        w.writerow({k: row.get(k, "") for k in header})

def trim_history():
    if not HISTORY_PATH.exists(): return
    rows = HISTORY_PATH.read_text(encoding="utf-8").splitlines()
    if len(rows) <= 8761: return
    trimmed = [rows[0]] + rows[-8760:]
    atomic_write(HISTORY_PATH, "\n".join(trimmed)+"\n")

def record_run(features, decision, notify_status="SKIPPED", skip_reason=""):
    status={"version":VERSION,"core_version":CORE_VERSION,"timestamp_utc":now_iso(),"features":features,"decision":decision,"last_notify_status":notify_status,"notify_skip_reason":skip_reason,"feature_parity":load_json(FEATURE_PARITY_PATH,{})}
    write_json(STATUS_PATH, status)
    row={"timestamp_utc":status["timestamp_utc"],"candle_dt":features.get("candle_dt"),"price":features.get("close"),"fear_greed":features.get("fear_greed"),"drawdown_from_ath":features.get("drawdown_from_ath"),"return_4":features.get("return_4"),"return_24":features.get("return_24"),"rsi_14":features.get("rsi_14"),"regime":features.get("regime"),"specialist":decision.get("specialist"),"prob":decision.get("prob"),"cycle_prob_raw":decision.get("prob") if decision.get("specialist")=="cycle_reversal" else "","tier":decision.get("tier"),"decision":decision.get("decision"),"notify":notify_status=="SENT","last_notify_status":notify_status,"notify_skip_reason":skip_reason,"reason":decision.get("reason")}
    append_csv(HISTORY_PATH,HISTORY_HEADER,row); trim_history()
    if notify_status == "SENT" and decision.get("decision") in ("LONG","SHORT"):
        s=stats_for(decision.get("specialist"), decision.get("horizon"))
        append_csv(SIGNALS_PATH,SIGNALS_HEADER,{"signal_ts":status["timestamp_utc"],"candle_dt":features.get("candle_dt"),"specialist":decision.get("specialist"),"decision":decision.get("decision"),"tier":decision.get("tier"),"prob":decision.get("prob"),"entry_price":decision.get("entry_price"),"take_profit":decision.get("take_profit"),"stop_loss":decision.get("stop_loss"),"horizon":decision.get("horizon"),"fear_greed":features.get("fear_greed"),"regime":features.get("regime"),"reason":decision.get("reason"),"historical_winrate_pct":s.get("historical_winrate_pct"),"oos_winrate_pct":s.get("oos_winrate_pct")})

def export_debug():
    # Hard overwrite both names.
    for p in (LATEST_EXPORT, LEGACY_EXPORT):
        try: p.unlink()
        except FileNotFoundError: pass
    for p in ROOT.glob("debug_export*.zip"):
        try: p.unlink()
        except Exception: pass
    LATEST_EXPORT.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(LATEST_EXPORT, "w", zipfile.ZIP_DEFLATED) as z:
        manifest={"version":VERSION,"core_version":CORE_VERSION,"created_at":now_iso(),"export_path":str(LATEST_EXPORT)}
        z.writestr("manifest.json", json.dumps(manifest, indent=2))
        for f in [ROOT/"bee_live_config.json", ROOT/"model_stats.json", ROOT/"bee_research_core_v4_0.py", Path(__file__), STATUS_PATH, HISTORY_PATH, SIGNALS_PATH, STATE_PATH, FEATURE_PARITY_PATH, STATE_DIR/"golden_test.json", LOG_DIR/"bee_live.log"]:
            if f.exists(): z.write(f, f.relative_to(ROOT) if f.is_relative_to(ROOT) else f.name)
    shutil.copy2(LATEST_EXPORT, LEGACY_EXPORT)
    return str(LATEST_EXPORT)

def run_once(force_notify=False, inspect=False):
    cfg=load_config()
    parity=run_feature_parity()
    if not parity.get("passed"):
        raise RuntimeError("feature parity failed; aborting live run")
    features=sample_live_market_features(); validate_units(features)
    decision=decide_all(features)
    notify_status="SKIPPED"; skip="NO_TRADE" if decision.get("decision")=="NO_TRADE" else "INSPECT_OR_NOT_FORCED"
    if inspect:
        skip="EXPORT_INSPECT"
    elif force_notify or decision.get("notify"):
        title = ("BEE TEST PAPER TRADE" if force_notify else f"BEE {decision.get('decision')} {decision.get('specialist')}")
        res=send_ntfy(cfg["ntfy_topic"], title, notify_body(decision, test=force_notify))
        if res.get("ok"):
            notify_status="SENT"; skip=""
        else:
            notify_status="FAILED"; skip=res.get("error","ntfy failed")
    record_run(features, decision, notify_status, skip)
    return {"features":features,"decision":decision,"notify_status":notify_status,"notify_skip_reason":skip,"feature_parity":parity}

def test_ntfy():
    cfg=load_config(); return send_ntfy(cfg["ntfy_topic"], "BEE ntfy test", f"BEE ntfy werkt. {now_iso()} version={VERSION}")

def test_trade_ntfy():
    features=sample_live_market_features(); decision=decide_all(features)
    return send_ntfy(load_config()["ntfy_topic"], "BEE PAPER TRADE TEST", notify_body(decision, test=True))

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--version", action="store_true"); ap.add_argument("--golden-test", action="store_true"); ap.add_argument("--feature-parity-test", action="store_true")
    ap.add_argument("--test-ntfy", action="store_true"); ap.add_argument("--test-trade-ntfy", action="store_true")
    ap.add_argument("--once", action="store_true"); ap.add_argument("--force-notify", action="store_true"); ap.add_argument("--inspect-live-data", action="store_true"); ap.add_argument("--export-debug", action="store_true")
    args=ap.parse_args()
    if args.version: print(VERSION); return
    if args.feature_parity_test: print(json.dumps(run_feature_parity(), indent=2)); return
    if args.golden_test: print(json.dumps(run_golden_test(), indent=2)); return
    if args.test_ntfy: print(json.dumps(test_ntfy(), indent=2)); return
    if args.test_trade_ntfy: print(json.dumps(test_trade_ntfy(), indent=2)); return
    if args.once or args.force_notify or args.inspect_live_data:
        print(json.dumps(run_once(force_notify=args.force_notify, inspect=args.inspect_live_data), indent=2, ensure_ascii=False)); return
    if args.export_debug:
        print("EXPORT READY:", export_debug()); return
    ap.print_help()
if __name__ == "__main__": main()
