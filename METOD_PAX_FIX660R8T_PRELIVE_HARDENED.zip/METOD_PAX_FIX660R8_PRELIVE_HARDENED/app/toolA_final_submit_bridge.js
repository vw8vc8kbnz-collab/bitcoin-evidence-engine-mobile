(function(root){
  'use strict';

  const BUILD = 'FIX660R8T_SINGLE_SUBMIT_AND_SUMMARY_OWNER';
  const boundButtons = typeof WeakSet === 'function' ? new WeakSet() : null;

  function submitButtonFromTarget(target){
    try{
      const button = target && target.closest ? target.closest('#sendConfigBtn, #btnSendConfig') : null;
      return button && String(button.id || '') ? button : null;
    }catch(_){ return null; }
  }

  function clean(value){ return String(value == null ? '' : value).trim(); }
  function normalizedCustomer(raw){
    const c = raw && typeof raw === 'object' ? raw : {};
    const billingAddress = clean(c.billingAddress || c.invoiceAddress || c.address);
    const shippingSameAsBilling = typeof c.shippingSameAsBilling === 'boolean' ? c.shippingSameAsBilling : true;
    const shippingAddress = shippingSameAsBilling ? billingAddress : clean(c.shippingAddress || c.deliveryAddress || c.address1);
    return {
      firstName:clean(c.firstName), lastName:clean(c.lastName), company:clean(c.company || c.companyName),
      email:clean(c.email || c.mail), phone:clean(c.phone || c.telephone || c.tel),
      billingAddress, shippingAddress, shippingSameAsBilling,
      postcode:clean(c.postcode || c.postalCode), houseNumber:clean(c.houseNumber || c.housenumber)
    };
  }
  function currentCustomer(){
    const st = root.state || {};
    const merged = {};
    [
      st.checkout && st.checkout.customer,
      root.__metod_checkout_live_customer,
      st.checkout && st.checkout.customerSnapshot,
      st.lastCalculatedCustomer
    ].forEach(function(source){
      const c=normalizedCustomer(source);
      Object.keys(c).forEach(function(key){
        if(key==='shippingSameAsBilling'){
          if(source && typeof source.shippingSameAsBilling==='boolean') merged[key]=source.shippingSameAsBilling;
        }else if(clean(c[key])) merged[key]=c[key];
      });
    });
    return normalizedCustomer(merged);
  }
  function setText(id, lines){
    const el=root.document && root.document.getElementById(id);
    const next=(lines||[]).filter(Boolean).join('\n') || '—';
    if(el && el.textContent!==next) el.textContent=next;
  }
  function syncResultUi(){
    const doc=root.document;
    if(!doc || typeof doc.getElementById!=='function') return false;
    const overlay=doc.getElementById('priceOverlay');
    if(!overlay) return false;
    const customer=currentCustomer();
    const name=[customer.firstName,customer.lastName].filter(Boolean).join(' ').trim();
    setText('priceRO_personal',[name,customer.company]);
    setText('priceRO_contact',[customer.email,customer.phone]);
    const addr=[customer.postcode,customer.houseNumber].filter(Boolean).join(' ').trim();
    setText('priceRO_address',[
      customer.billingAddress ? `Factuur: ${[customer.billingAddress,addr].filter(Boolean).join(' ')}` : '',
      customer.shippingAddress ? `Bezorg: ${[customer.shippingAddress,addr].filter(Boolean).join(' ')}` : ''
    ]);
    setText('priceCustomerSummary',[name,customer.email,customer.phone]);

    const st=root.state || {};
    const hasPanels=!!((Array.isArray(st.cart)&&st.cart.length)||(Array.isArray(st.extraPanels)&&st.extraPanels.length));
    const totalEl=doc.getElementById('priceOverlayTotal') || doc.getElementById('priceTotalValue');
    const totalText=clean(totalEl && totalEl.textContent);
    const hasPrice=!!(totalText && totalText!=='—' && !/^op aanvraag$/i.test(totalText));
    const ready=!!(customer.email && hasPanels && hasPrice);
    doc.querySelectorAll('#sendConfigBtn, #btnSendConfig').forEach(function(button){
      if(button.disabled === ready) button.disabled=!ready;
      if(ready){ if(button.hasAttribute('aria-disabled')) button.removeAttribute('aria-disabled'); }
      else if(button.getAttribute('aria-disabled')!=='true') button.setAttribute('aria-disabled','true');
    });
    return ready;
  }

  function routeClick(event){
    const button = submitButtonFromTarget(event && (event.currentTarget || event.target));
    if(!button) return false;
    syncResultUi();
    try{ event.preventDefault(); }catch(_){ }
    try{ event.stopImmediatePropagation(); }catch(_){ try{ event.stopPropagation(); }catch(__){ } }

    const submit = root.__metodSubmitFinalConfiguration;
    if(typeof submit !== 'function'){
      try{
        if(typeof root.statusMsg === 'function') root.statusMsg('De verzendfunctie is nog niet gereed. Herlaad de pagina en probeer opnieuw.', true);
        else root.alert && root.alert('De verzendfunctie is nog niet gereed. Herlaad de pagina en probeer opnieuw.');
      }catch(_){ }
      return true;
    }
    try{
      const result = submit(button);
      if(result && typeof result.catch === 'function'){
        result.catch(function(error){
          try{ root.console && root.console.error && root.console.error('Final submit failed', error); }catch(_){ }
        });
      }
    }catch(error){
      try{ root.console && root.console.error && root.console.error('Final submit failed', error); }catch(_){ }
    }
    return true;
  }

  function bindButton(button){
    if(!button || typeof button.addEventListener !== 'function') return false;
    if((boundButtons && boundButtons.has(button)) || button.dataset.metodSubmitOwner === BUILD) return true;
    // Retire both legacy target listeners before they can attach. This element
    // now has exactly one owner and one canonical submission path.
    button.dataset.metodSubmitOwner = BUILD;
    button.dataset.bound = 'canonical';
    button.__bound = true;
    button.addEventListener('click', routeClick, true);
    if(boundButtons) boundButtons.add(button);
    return true;
  }

  function bind(documentRef){
    const doc = documentRef || root.document;
    if(!doc || typeof doc.querySelectorAll !== 'function') return false;
    let found = false;
    doc.querySelectorAll('#sendConfigBtn, #btnSendConfig').forEach(function(button){
      found = bindButton(button) || found;
    });
    return found;
  }

  function init(){
    bind(root.document);
    syncResultUi();
    try{
      let syncing=false;
      const observer = new MutationObserver(function(){
        if(syncing) return;
        syncing=true;
        try{ bind(root.document); syncResultUi(); }finally{ root.queueMicrotask(function(){ syncing=false; }); }
      });
      const overlay=typeof root.document.getElementById==='function' ? root.document.getElementById('priceOverlay') : null;
      observer.observe(overlay || root.document.body, {childList:true, subtree:true, characterData:true, attributes:true, attributeFilter:['style','disabled','aria-disabled']});
      root.__metod_submit_owner_observer = observer;
    }catch(_){ }
  }

  root.ToolAFinalSubmitBridge = Object.freeze({ BUILD, submitButtonFromTarget, routeClick, bindButton, bind, currentCustomer, syncResultUi });
  root.__TOOLA_FINAL_SUBMIT_BUILD = BUILD;
  if(root.document){
    if(root.document.readyState === 'loading') root.document.addEventListener('DOMContentLoaded', init, {once:true});
    else init();
  }
})(typeof window !== 'undefined' ? window : globalThis);
