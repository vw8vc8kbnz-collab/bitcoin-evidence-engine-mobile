# FIX660R8 release notes

## R8T live browser-reparatie van mandje en checkout

- Een echte mobiele Chromium-doorloop tegen de publieke staging reproduceerde
  zowel het niet-werkende prullenbakje als de lege klantkaart en geblokkeerde CTA.
- Het prullenbakje riep een aanwezige wrapper zonder gekoppelde raw hook aan; de
  module gebruikt nu eerst de werkelijk beschikbare canonieke
  `removeMaterialBatch`-transactie.
- De oude enkel-materiaal-sheet wordt niet meer automatisch over `Jouw
  materialen` geopend en onderschept dus geen eerste tik meer.
- De definitieve submitbrug rendert klantgegevens rechtstreeks uit de bestaande
  live/snapshot-state en maakt de knop alleen actief bij prijs, panelen en e-mail.
  Daardoor is de prijsweergave niet meer afhankelijk van onbereikbare functies
  in een oudere JavaScript-scope.
- De mobiele footertegels zijn in de browsertest exact 50/50 en 58 px hoog; de
  footerrail heeft geen achtergrond, blur, border of schaduw.
- Onveilige live verzending is in de browsertest onderschept; de eindbrug is
  aanvullend getest op exact één verzendaanroep.

## R8S checkout- en verwijderroute daadwerkelijk vrijgemaakt

- Live bewijs toonde dat R8R byte-exact actief was; cache en deployment waren
  daarmee uitgesloten. De resterende verzendfout zat in een oudere
  prijs-overlaywrapper die de correct gevonden eindknop na het tonen alsnog als
  native `disabled` markeerde. iOS levert voor zo'n knop geen klikevent. R8S
  houdt de CTA daarom altijd event-capable; alleen de canonieke submitfunctie
  vergrendelt hem kort tijdens de echte POST.
- Klantdata wordt niet meer als één gedeeltelijk object gekozen. Beschikbare
  live state en berekeningssnapshots worden per veld samengevoegd, waarbij
  niet-lege berekeningswaarden autoritatief blijven. Een oude snapshot met
  bijvoorbeeld alleen e-mail kan naam, telefoon en adres niet meer verbergen.
- Het mobiele prullenbakje gebruikt de bestaande centrale materiaaltransactie.
  De bijbehorende bevestigingsdialoog staat nu aantoonbaar boven de mobiele
  drawer; materiaal en gekoppelde panelen worden daarna exact eenmaal verwijderd.
- Footerrails gebruiken geen achtergrond, blur, outline, pseudo-element of
  buiten-schaduw meer. De twee afgeronde acties blijven zelf zichtbaar.
- Optimizer, nestingstrategie, prijsformules en serverfinalisatie zijn niet
  gewijzigd.

## R8R eerste event-eigenaar voor Safari

- De live R8Q-release en Nginx-assets bleken byte-exact actief, terwijl de drie
  gemelde interacties toch niet veranderden. De resterende oorzaak zat in de
  historische eventvolgorde: oudere document- en targethandlers konden een tik
  verwerken voordat de later geladen R8Q-knopbinding eigenaar werd.
- R8R registreert daarom vóór alle legacy-applicatiescripts één document-capture
  eigenaar. Die resolveert de pas later gemaakte eindknop op het moment van de
  echte tik, stopt alle oudere submitroutes en roept precies één canonieke
  submitfunctie aan. De test voert nadrukkelijk de eerste geregistreerde
  documentlistener uit, niet een los geïsoleerd knopfragment.
- Dezelfde eerste eventlaag legt bij invoer én vóór berekenen alle zichtbare
  klantvelden vast. Daardoor worden ook Safari-autofillvelden zonder events
  meegenomen en kunnen latere verborgen of lege controls de berekeningssnapshot
  niet overschrijven.
- Mobiele prullenbak-, bevestig- en annuleertikken lopen eveneens via deze eerste
  eigenaar naar de ene basketmutatie. Oude listeners krijgen dezelfde fysieke
  tik niet meer en kunnen de actie dus niet stil absorberen.
- De rechthoekige footer-/modalrails zijn mobiel volledig transparant gemaakt;
  ook de beide losse footertegels hebben geen buiten-schaduw meer. Desktop,
  pricing en het nestingalgoritme zijn ongewijzigd.

## R8Q checkout bij de wortel hersteld

- De hoofd-JavaScript werd historisch uitgevoerd voordat de prijsoverlay in de
  HTML bestond. Daardoor bewaarde de verzendfunctie permanent `null` als knop;
  bij een tik werd de interne submitvergrendeling gezet en crashte de functie
  nog vóór `/api/submit_config`. R8Q resolveert de knop pas bij de echte tik en
  geeft één dynamisch aangemaakte knop aan precies één canonieke eigenaar.
- De klantinvoer wordt vóór de berekening als één onveranderlijke snapshot
  vastgelegd en voedt daarna jobinput, prijscontrole en finale submit. Safari-
  autofill zonder `input`-event kan niet meer door nog lege state over de zichtbare
  velden heen worden geschreven. De server bewaart dezelfde volledige snapshot
  in de finalized job en herstelt ontbrekende laatste browservelden daaruit,
  voordat precies één Admin-/salesrequest duurzaam wordt aangemaakt.
- De finale browserrequest bevat bewust alleen `jobId`, `parentJobId`, klant en
  notitie. Panelen, prijs en quote komen uitsluitend uit de reeds verzegelde
  serverjob; concurrerende clientkopieën kunnen Admin daardoor niet vervuilen.
- Het prullenbakje in `Jouw materialen` gebruikt rechtstreeks dezelfde bevestigde
  materiaalmutatie als desktop. Materiaal zonder panelen verdwijnt onmiddellijk;
  bij gekoppelde panelen verschijnt in dezelfde sheet een duidelijke bevestiging.
- De grijze vierkante waas rond mobiele actiegebieden kwam uit een oude globale
  gradient/shadow-regel voor footers en modals. De mobiele materiaal-, klant-,
  overzichts- en previewrails hebben nu een effen witte achtergrond zonder
  backdrop-filter of vierkante buiten-schaduw. Desktop en het nestingalgoritme
  zijn niet gewijzigd.

## R8P compacte mobiele materiaalbalk en één betrouwbare verzendroute

- De mobiele materiaalstap heeft voortaan één lage onderbalk met twee exact even
  brede en hoge tegels: `Jouw materiaal/materialen` en `Volgende stap`. Eerdere
  mobiele CSS die de vervolgknop alsnog over de volle rij liet lopen wordt door
  het R8P-contract expliciet overschreven; desktop behoudt de rechterkolom.
- `Jouw materialen` opent als één rustige bottom sheet met de bestaande centrale
  materiaalstate. Bij verwijderen sluit die sheet eerst volledig en opent daarna
  pas de gedeelde bevestigingsdialoog. Daardoor staat de dialoog op iOS niet meer
  onzichtbaar achter de nog sluitende drawer en bereikt de bevestiging dezelfde
  mutation als de desktopactie.
- De finale knop werd niet door pricing of de server geblokkeerd: een oude
  capture-listener op de knop stopte het event al voordat de canonieke
  verzendhandler het kon ontvangen. R8P vangt één fysieke tik vóór die retired
  listener af en leidt hem precies eenmaal naar één benoemde submitfunctie. Een
  lopende aanvraag wordt zichtbaar vergrendeld, een fout maakt de knop opnieuw
  bruikbaar en een succesvolle aanvraag kan niet dubbel worden verzonden.
- Regressieproeven simuleren de mobiele verwijderactie en de volledige
  document-capture klikroute. Het optimizer-/nestingalgoritme, de berekende prijs
  en de serverfinalisatie zijn niet gewijzigd.

## R8O één mobiel mandje en herstelbare eindcontrole

- Op mobiel werd naast het nieuwe uitschuifbare materialenmandje ook de oude
  single-material onderbalk getoond. R8O onderdrukt die oude balk zodra de
  multi-material basket actief is; het mandje blijft de enige materiaalweergave
  en bevat zelf de actie om naar Panelen te gaan.
- Een geverifieerde eindprijs kon de knop `Akkoord en aanvraag verzenden`
  vervolgens opnieuw uitschakelen wanneer klantgegevens in state nog niet
  compleet leken. Een uitgeschakelde knop kon geen uitleg of herstelpad tonen.
  De CTA blijft bij een definitieve serverprijs nu bedienbaar en stuurt bij
  werkelijk ontbrekende gegevens gericht terug naar Stap 4 met veldvalidatie.
- De prijsweergave leest voortaan uitsluitend de vóór optimalisatie vastgelegde
  klantstate. Verborgen, nog niet gehydrateerde invoervelden kunnen die gegevens
  niet meer tijdens het renderen wissen. Ook een ontbrekende actuele
  nerf-preview ontgrendelt de prijslaag en brengt de klant terug naar de juiste
  herstelstap. Het optimizer-/nestingalgoritme is niet gewijzigd.

## R8N stabiele stapovergang en mobiel materialenmandje

- De asynchrone opstartloader voor ingebouwde DXF-templates zette na afronding
  onvoorwaardelijk opnieuw Stap 1 actief. Wie op mobiel snel een materiaal koos
  en doorging, kon daardoor enkele ogenblikken later onverwacht uit Stap 2 worden
  teruggezet. R8N commit de beginstap vóór het laden en ververst na afloop alleen
  de bediening van de stap die de klant op dat moment daadwerkelijk open heeft.
- De mobiele onderbalk toont naast Verder een compact materialenblok met de echte
  actieve materiaalafbeelding en het aantal gekozen materialen. Een tik opent een
  bottom sheet met alle materialen in het mandje, naam, dikte, plaatafmeting,
  actieve selectie en de bestaande veilige verwijderactie.
- De bottom sheet gebruikt dezelfde `materialBatches`, actieve-materiaalselectie,
  swatchrenderer en verwijderlogica als de desktopkolom. Er ontstaat dus geen
  tweede mobiele state die kan afwijken van prijsberekening of productie-input.
  Escape, backdrop, sluitknop en de greep sluiten de sheet; desktop blijft
  functioneel en visueel ongewijzigd.

## R8M stabiele optimalisatie-start, afronding en multi-klantwachtrij

- Het nesting-/plaatsingsalgoritme is inhoudelijk niet gewijzigd. De exacte
  productieplacements voor de vaste 200- en 250-panelenfixtures zijn nu met een
  semantische SHA-256-fingerprint vergrendeld, zodat iedere toekomstige
  performancewijziging die één positie verandert de releasegate laat falen.
- Tool A animeerde iedere serverprocent met een afzonderlijke JavaScript-wachttijd.
  Een normale sprong kon daardoor circa 1,7 seconde kosten en een direct afgeronde
  job bleef kunstmatig bijna één seconde op 100% staan. De UI verwerkt nu iedere
  serverstand in één update; de bestaande CSS-transitie verzorgt alleen de visuele
  beweging.
- De DONE-status bevatte de definitieve serverprijs al, maar de nog actieve
  busy-marker liet die prijs afwijzen en forceerde een tweede zware statusaanvraag.
  R8M gebruikt de reeds geverifieerde `pricingSummary` direct en haalt alleen bij
  werkelijk ontbrekende prijsdata één herstelresponse op.
- Statuspolling voerde per request herhaald complete SHA-256-familiecontroles uit,
  scande de volledige jobmap en normaliseerde de 597 materiaalrecords meerdere
  keren onder één globale lock. Status leest tijdens verwerking nu alleen de
  actuele fase/progressie, ontdekt subjobs via de vastgelegde links en hergebruikt
  mutation-sensitive materiaal- en artifactcaches. Downloads en de overgang naar
  DONE blijven fail-closed volledig verzegeld.
- Masterinput wordt als één durabilitybatch gepubliceerd, identieke subjobinput
  gebruikt hardlinks en de reeds canonieke compacte DXF-referenties worden niet
  opnieuw per PartId uitgepakt, geëncodeerd en gehasht. Tijdelijke timing- en
  commandodiagnostiek blokkeert de productieresultaten niet meer met afzonderlijke
  `fsync`-barrières. Definitieve DXF's, rapporten, prijs, manifest en finalization
  blijven duurzaam en volledig gehasht.
- Bij de onderdeel-export wijzigde iedere hardlink de ctime van de gedeelde
  broninode. Daardoor werd dezelfde DXF bij 250 PartIds ondanks de cache nog 252
  keer fysiek gehasht. Een hardlink wordt nu via exacte device/inode-identiteit
  bewezen; alleen een echte kopie krijgt de volledige bron/doel-hashvergelijking.
  De complete hardlinkdoelmappen worden vóór publicatie één keer duurzaam geflusht.
- Eén 250-panelenproef daalde vóór de eerste optimizerstart van 30 naar 16
  parent-`fsync`-barrières en over de volledige serverfinalisatie van 56 naar 31.
  De ene extra barrière borgt dat de nieuwe subjobmap zelf een stroomuitval overleeft.
  In dezelfde proef daalden de fysieke hashlezingen van circa 290 naar 41 en werd
  de ene gedeelde DXF nog hoogstens drie keer gelezen in plaats van 252 keer.
  De browserproef eist bij direct DONE exact één statusrequest en nul animatietimers.
- Publieke aanvragen gebruiken een begrensde FIFO: op de huidige kleine VPS blijft
  standaard exact één optimizer actief, terwijl maximaal acht gevalideerde jobs
  ordelijk kunnen wachten. Daardoor starten meerdere klanten niet onbegrensd
  tegelijk en krijgt een toegelaten tweede klant een traceerbare wachtrijstatus in
  plaats van directe 429-afwijzing.
- De eerdere bewezen FIX655/FIX656-contracten blijven intact: de job is een echte
  backendjob die in Admin terugkomt, compacte DXF-bodies blijven gedeeld en een
  versnelling mag nooit extra platen accepteren. R8M wijzigt daarom geen
  plaatsingsstrategie, fast-mode of tijdslimiet; uitsluitend voorbereiding,
  polling, verificatiehergebruik, finalisatie-I/O en scheduling zijn aangepast.

## R8L prijsberekening-submit en zichtbare optimalisatie-overlay

- R8K deelde de DXF-cache tussen de eerste templateweergave en de submitroute,
  maar de cachevariabelen stonden door de historische opbouw van `toolA.html` in
  een andere callbackscope. Bij `Prijs berekenen` stopte de browser daarom vóór
  de job-POST op `_DXF_CLASSIFIED_PAIR_CACHE is not defined`; het overzicht sloot
  al wel en liet een half-afgebouwde stap-5-layout achter.
- De vier DXF-caches hebben nu één expliciete `window`-bridge. De loader en de
  submitpipeline binden daar ieder hun eigen lokale alias aan, zodat hergebruik
  snel blijft zonder een onbereikbare lexical binding.
- De jobstart-ID staat nu buiten het `try`-blok van de submitketen. Daardoor kan
  een vroege validatie-, netwerk- of JavaScriptfout niet langer zelf de
  foutafhandeling laten crashen; de echte reden verschijnt in het foutvenster.
- Safari krijgt direct na het openen van de optimalisatie-overlay één paint-frame
  voordat DXF-voorbereiding verdergaat. Bij een vroege afwijzing verdwijnt die
  overlay eerst en komt de foutmelding er zichtbaar bovenop.
- Een browserachtige DOM-runtimeproef drukt de echte verborgen berekenknop in,
  verwerkt een echte ingebedde METOD-DXF, controleert de compacte job-POST, ziet
  de optimalisatie-overlay en eindigt in de prijsoverlay. Een tweede route dwingt
  een HTTP 400 af en bewijst dat de voortgangslaag sluit en de servermelding
  zichtbaar wordt.

## R8K meerdere nerfgroepen en end-to-end compacte DXF-jobstart

- Op mobiel werd een nieuw aangemaakte lege G02 tijdens het renderen direct weer
  vervangen door de eerste gevulde groep G01. Daardoor bleef G01 geselecteerd en
  vergrendelde de beschikbare panelenlijst zich op de breedte van G01. Een nieuwe
  groep blijft nu expliciet geselecteerd, start zonder breedtefilter en toont alle
  nog beschikbare werkelijke breedtes. Pas het eerste toegevoegde paneel legt de
  exacte breedte van die groep vast. Dezelfde groepsstate en validatie blijven op
  desktop actief.
- R8J valideerde gedeelde DXF-geometrie al één keer aan de publieke grens, maar
  bouwde daarna opnieuw een uitgeklapte interne `dxfParts`-map. De worker telde die
  als legacy-invoer en kon een geldige 250-panelenjob alsnog vóór Tool B weigeren
  als meer dan 12 MB. R8K houdt de canonieke DTO en de input op schijf end-to-end
  compact: één SHA-256-geadresseerde DXF-body plus een PartId-referentiemanifest.
- Voor 250 identieke PartIds ontstaan vóór de optimizer niet langer circa 500
  master-/subjob-DXF-bestandsentries. Er worden twee unieke bodybestanden (master
  en subjob) plus twee kleine referentiemanifesten aangemaakt. Tool B verifieert
  manifest, exacte PartId-set en bodyhash vóór verwerking; 250 paneelidentiteiten,
  placements, labels, StickerTool-items en onderdeeldownloads blijven afzonderlijk.
- De browser deelt nu de al tijdens template-initialisatie geladen DXF-tekstcache
  met de submitroute. Gebruikte templates worden bij Optimaliseren niet opnieuw
  via HTTP opgehaald. De server berekent pre-acceptatiecomplexiteit over unieke
  bodies en serialiseert geen tijdelijk uitgeklapte 25–35 MB payload meer.
- Lokale volledige 250-panelenmeting met één echte METOD-DXF: publieke
  canonicalisatie 25,15 ms, pre-202-complexiteit 3,36 ms, serverjob inclusief
  optimizer en finalisatie 488,53 ms. Tool B zelf mat 224 ms totaal, waarvan
  123 ms nesting. De gate bewijst 250/250 placements, 12 platen, één unieke
  DXF-body in subjobinput en 250 afzonderlijke onderdeel-DXF-exports.

## R8J 200–250-panelen performance- en compact-DXF-correctie

- De compacte browserpayload stuurt één unieke DXF-body plus PartId-verwijzingen.
  De publieke servergrens vouwde dit correct uit, maar parseerde, valideerde en
  telde daarna dezelfde body opnieuw voor ieder PartId. Bij 250 gelijke panelen
  werd de geldige compacte aanvraag daardoor zelfs foutief als meer dan 12 MB
  geweigerd. R8J hash-identificeert unieke bodies en voert de volledige entity-
  en geometrievalidatie exact één keer per unieke body uit; de bbox blijft daarna
  afzonderlijk tegen ieder canoniek paneel gecontroleerd.
- De MaxRects-hot-path beoordeelde in iedere iteratie ieder fysiek exemplaar van
  exact dezelfde paneelgeometrie opnieuw, hoewel score, vrije rechthoeken en de
  uiteindelijke eerste-instantie-tiebreak identiek waren. In een 250-panelenprofiel
  bleken 92.385 pending- en 4.438 anchor-beoordelingen aantoonbaar equivalent.
  R8J slaat uitsluitend zulke bewezen equivalente berekeningen over; iedere
  fysieke instantie blijft afzonderlijk geplaatst, gevalideerd en geëxporteerd.
- Sorteervarianten die dezelfde geometrische itemvolgorde opleveren worden niet
  opnieuw volledig uitgevoerd. Voor homogene rechthoekjobs levert een geldige
  reguliere gridplaatsing bovendien een betere start-upper-bound; MaxRects en de
  bestaande bewijsruns mogen die uitkomst nog steeds verbeteren.
- Gemeten uitkomsten met identieke productie-input:
  - 200 gelijke panelen: 6,303 → 0,214 seconde; 11 → 10 platen;
  - 200 gemengde panelen: 5,898 → 0,667 seconde; 10 platen gebleven;
  - 250 gelijke panelen: 0,631 seconde totale optimizerduur, 12 platen, 250/250
    unieke plaatsingen en slechts één echte DXF-parse in de optimizer. De gekozen
    21-per-plaatindeling gebruikt drie 0°- en twee 90°-kolommen.
- Definitieve productie-DXF's worden nog steeds eenmaal per echte plaat duurzaam
  geschreven en vervolgens volledig op layer, entityaantal, plaatgrens, overlap,
  instance-identiteit en SHA-256 gecontroleerd. De versnelling verwijdert geen
  productiecontrole en verlaagt de nestingkwaliteit niet.

## R8I rand-tot-rand nerfpreview en optimizer-I/O-correctie

- De geopende mobiele nerfpreview begint nu op de werkelijk gemeten onderrand
  van de Grain Studio-bovenbalk. De dubbele mobiele tekstregels en samenvattingsbalk
  zijn uit de drawer verwijderd; het echte canvas gebruikt de volledige beschikbare
  ruimte tot aan de vaste actieknoppen.
- De inklapgreep ligt volledig binnen de drawer, heeft een groter zichtbaar
  handvat en blijft zowel open als gesloten bereikbaar. Een viewport- of
  oriëntatiewijziging meet de bovenrand opnieuw en rendert het canvas opnieuw.
- Desktop gebruikt aantoonbaar dezelfde real-mm renderer, materiaalweergave,
  DXF-boringen en bottom-to-top-productievolgorde. De regressiegate voert nu naast
  de iOS-route ook een aparte desktop-canvasroute uit.
- Tijdens het nesten werden iedere voortgangsstap en het groeiende tussenrapport
  met volledige file- plus directory-`fsync` gepubliceerd. Dat veroorzaakte op
  VPS-opslag veel synchrone diskbarriers. R8I schrijft uitsluitend deze vervangbare
  tussenstanden atomisch zonder `fsync`; definitieve rapporten, manifesten,
  productie-DXF's en finalization-hashes blijven volledig duurzaam geschreven.
- Een representatieve 100-panelenproef daalde lokaal van 2,543 naar 1,252 seconde
  optimizerduur (de herhaalde baseline bleef 2,100 seconde). De plaatindeling en
  het aantal van zes platen bleven exact gelijk. De UI begint bovendien na de
  reeds voltooide serverpreflight eerlijk op 3% in plaats van schijnbaar op 1%.

## R8H zichtbare iPhone-canvascorrectie

- De geopende FIX660-previewdrawer werd nog geraakt door een oude FIX649-regel
  met hogere CSS-specificiteit: zolang `fix649PreviewOpen` ontbrak, kreeg
  `#grainPreview` ondanks de nieuwe drawerstatus `display:none !important`.
  Daardoor waren groep, aantallen en maten zichtbaar, maar bleef de kaart wit.
- De oude FIX649-inline-previewpoort is verwijderd uit de actieve mobiele CSS.
  De geopende FIX660-drawer heeft daarnaast een expliciete ownershipselector
  die ook een eventueel nog door Safari gecachte oude regel overrulet.
- Zowel de oude mobiele stylesheet als alle Grain Studio-assets hebben een
  R8H-cachebuster. Schaal, bottom-to-top-volgorde, materiaalweergave,
  DXF-boringen/arcs en de Apply-readinessgate zijn inhoudelijk ongewijzigd.

## R8G publicatiepoort- en iOS-drawercorrectie

- Admin maakt nu ondubbelzinnig onderscheid tussen `100% voorbereid` en
  `actief gepubliceerd`. De 597 staged beelden blijven bewust onzichtbaar voor
  Tool A totdat de beheerder de complete CSV en beelden samen publiceert.
- Zodra de beeldvoorbereiding volledig geslaagd is, verschijnt direct in het
  voortgangsvak een tweede expliciete knop `Nu catalogus publiceren`; de
  bestaande reviewhash, bevestiging, snapshot en atomische publicatie blijven
  verplicht.
- De mobiele Doorlopende Nerf-preview voltooit een echte iOS-pointertap nu op
  `pointerup`, zodat Safari niet meer afhankelijk is van een `click` die na
  `preventDefault` kan worden onderdrukt. De sleep-transform krijgt dezelfde
  `!important`-prioriteit als de drawer-CSS en volgt daardoor zichtbaar de vinger.
- Een uitvoerende Node-regressietest bewijst openen met één tap, geen dubbele
  toggle en sluiten voorbij de sleepdrempel.

## R8F CSV-preview- en catalogusbeeldcorrectie

- De CSV-preview bevatte per ongeluk een auditblok uit de classificatie-override
  met vier variabelen die binnen preview niet bestaan. Daardoor eindigde iedere
  geldige CSV na het veilig opslaan van de stage alsnog in de generieke foutmelding.
- De afgeleide publieke cataloguscache heeft nu een expliciet schema/buildcontract.
  Een oude cache met beeld-URL's wordt na upgrade niet meer hergebruikt op basis
  van alleen de mtime van `material_library.json`.
- De proces-/HTTP-gate controleert nu ook een echte beveiligde CSV-preview en een
  lokaal gecachte catalogusafbeelding via de publieke API. Tool A vervangt een
  incidenteel niet-laadbaar beeld bovendien door de decorplaceholder.

## R8E live-HTTP-correctie

- De healthhandler gebruikt geen dubbel-underscore moduleconstant meer. De oude
  naam werd binnen `Handler.do_GET` door Python gemangeld naar
  `_Handler__SECURITY_BUILD`, waardoor de poort wel opende maar iedere
  livenessrequest zonder antwoord eindigde.
- De artifactgate start nu het echte serverproces en roept liveness, readiness
  en Tool A via loopback-HTTP aan. Alleen import-, compile- en directe
  handlertests zijn daardoor niet langer voldoende.
- De deploy onderdrukt herhaalde tijdelijke curlmeldingen en toont bij een
  blijvende healthfout automatisch de relevante systemd-journalregels.

## R8D rollback-/baselinecorrectie

- Een `metod-pax-current`-symlink die na rollback exact naar de legacy R7-map
  wijst, wordt nu als R7-baseline gevalideerd en niet meer ten onrechte als een
  immutable checksummanifest-release behandeld.
- Een echte immutable current-link is alleen geldig onder de beheerde
  releases-map en blijft volledig byte-voor-byte geverifieerd.
- `sudo -E` is verwijderd. Alleen de expliciete deployconfiguratie wordt als
  afzonderlijke, niet-uitvoerbare omgevingswaarden naar root doorgegeven.

## R8C installerfix

- Iedere installer- en deploy-Pythonaanroep draait met bytecode uitgeschakeld;
  de state-migratie kan daardoor geen `app/__pycache__` in de immutable release
  meer creëren.
- De immutable release-ID is nu afgeleid van het volledige interne
  checksummanifest. Een eerder geweigerde of vervuilde releasefolder met dezelfde
  backendbron kan daardoor nooit door een gecorrigeerde revisie worden hergebruikt.

## R8B packagingcorrectie

- Het runtimecontract ondersteunt nu expliciet Python `>=3.10,<3.15`.
- Python 3.14.4 is door de volledige preflight op de doel-VPS gevalideerd; de
  eerdere blokkade was uitsluitend de te smalle declaratieve bovengrens.
- De geïsoleerde preflight-state en expliciete `FOUTSAMENVATTING` uit R8A blijven
  actief.

Datum: 13 augustus 2026  
Build: `FIX660R8_PRELIVE_HARDENED`  
Basis: FIX660R7 pre-live audit

## Productie- en prijsintegriteit

- De publieke jobpayload wordt server-side opnieuw opgebouwd uit opaque materiaal-ID, actieve catalogus, live pricing en de ingebedde DXF-library.
- Paneelvelden zijn strict finite; aantallen, kantenbandcodes, nerfposities, dikte en plaatmaat hebben vaste contracten.
- DXF/CSV-bboxafwijking, onbekende machining, overlap, buiten-plaatgeometrie en exportfouten zijn fatal.
- ARC-hoeken roteren correct op 0/90/180/270 graden.
- Nerfpositie 1 is fysiek de onderste positie en ongelijke groepsbreedtes worden geweigerd.
- Clientpricing en clientgekozen productiepolicy hebben geen autoriteit meer.
- Finalisatie bindt input, optimizeroutputs, exacte identities/counts en alle downloadbare artifacts aan SHA-256.
- Status, submit en Admin-download falen gesloten bij ontbrekende of gemanipuleerde finalisatie.

## Security en privacy

- Job- en request-ID's gebruiken een strict allowlistcontract met vaste-root containment.
- Public quote-output is minimaal; productie-, prijs- en materiaalinterne data blijven Admin-only.
- Admin gebruikt in productie individuele accounts, TOTP MFA, HttpOnly sessiecookies, idle/absolute TTL, logout/revocation en server-derived actorlogging.
- Basic auth is in productie uitgeschakeld; login voert dummy PBKDF2/TOTP uit voor onbekende gebruikers.
- CSP gebruikt nonces en statische/DXF-responses gebruiken een beperkte allowlist en `nosniff`.
- Nginx normaliseert client-IP en begrenst jobs, login, SSE, requests en connecties.
- Staging bindt standaard alleen aan loopback; een remote bind vereist een expliciete CIDR-allowlist.
- Clientlogs zijn klein, geratelimit, geredigeerd, roterend en vereisen een jobtoken wanneer een job wordt genoemd.
- Catalogusafbeeldingen valideren DNS één keer en verbinden via het gepinde publieke IP met TLS-SNI/certificaatcontrole op de originele host.

## State, deploy en herstel

- Mutable state staat buiten de immutable release onder `/var/lib/metod-pax`.
- Migratie gebeurt naar een sibling stagingmap en wordt atomisch gepubliceerd na durable markerwrite.
- Releases zijn immutable; de current-symlink wordt atomisch gewisseld.
- Maintenance/drain voorkomt gemengde assets en verlies van deploy-windowdata.
- Rollback wijzigt code/config, nooit live state.
- Backups omvatten de volledige noodzakelijke state, gebruiken een schema-2 manifest met size/SHA-256 per bestand en worden na creatie byte-voor-byte herverifieerd.
- Restore weigert traversal, symlinks, extra/dubbele leden, hashverschillen en bestaande targets; publicatie gebeurt pas na een tweede hashcontrole.
- Kritieke writes gebruiken durable temp-write/replace/fsync; JSONL-logs hebben cross-process locking en rotatie.

## Catalogus en operations

- Cataloguspreview geeft een reviewhash over CSV, warnings, exclusions, errors, samenvatting, taxonomie en genormaliseerde records.
- Publicatie vereist dezelfde reviewhash en maakt een signoff die aan de actieve libraryhash is gebonden.
- Readiness controleert catalogus, signoff, pricing, schrijfbaarheid, vrije bytes/inodes, DXF-library en restore/offsite-evidence in productie.
- Runtimecontract, stdlib-only requirements, CycloneDX-SBOM, reproduceerbare artifactbuilder en CI releasegate zijn toegevoegd.

## Bewuste incompatibiliteiten

- De auth-loze StickerTool-route is 410 Gone.
- Per materiaaljob bestaat nog maar één authoritative `output/stickertool.json`; oude `stickers.json`-spiegels zijn verwijderd.
- Admin kan uitsluitend files downloaden die in een geldige finalization-hashlijst staan. Oude debuglogs en inputbestanden zijn niet meer via outputknoppen bereikbaar.
- Legacy queue-items worden niet opnieuw geoptimaliseerd; onveilig hervatwerk gaat naar handmatige controle.

## Geen productiecertificaat

Deze build is een pre-live candidate. De resterende externe gates staan in `GO_LIVE_GATES_FIX660R8.md` en kunnen niet met alleen broncode worden afgetekend.
