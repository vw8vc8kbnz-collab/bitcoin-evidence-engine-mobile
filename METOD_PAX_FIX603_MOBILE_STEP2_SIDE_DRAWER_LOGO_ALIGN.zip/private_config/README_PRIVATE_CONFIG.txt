PRIVATE CONFIG - NIET PUBLIEK MAKEN

Deze map is alleen bedoeld als voorbeeld/plaats voor lokale of staging configuratie.
Voor echte livegang: zet de echte admin credentials/hash bij voorkeur buiten de publiek bereikbare webroot en wijs ernaar met ADMIN_CREDENTIALS_FILE.

In deze live-audit ZIP zit bewust GEEN admin_credentials.live.json met echte hash.
Maak die op de server zelf aan op basis van admin_credentials.live.example.json.
