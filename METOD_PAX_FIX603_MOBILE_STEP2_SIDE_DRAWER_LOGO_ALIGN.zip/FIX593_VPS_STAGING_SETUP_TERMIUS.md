# METOD/PAX FIX600 - VPS staging setup

Doel: veilige staging op eigen VPS via GitHub ZIP -> Termius -> systemd.

Gebruik deze ZIP als serverpakket. Zet echte secrets nooit in GitHub en nooit in de app-map.

## Tijdelijke test-login

Voor staging mag tijdelijk:

- Gebruiker: `admin`
- Wachtwoord: `Zaagtad123??!!`

Zet dit niet als plaintext in de app. Gebruik hash-only config buiten de app:

```json
{
  "username": "admin",
  "password_hash": "pbkdf2_sha256$260000$fix593_temporary_admin_test_login_rotate_before_live$4d510b50372862f49fbfcaa0c66f6c77feee510d9938c91b5aee5a1520063e38"
}
```

Vervang dit wachtwoord voor publiek live.

## Server-only paden

Aanbevolen:

- App: `/opt/adzaagt/metod-pax`
- Admin credentials: `/etc/adzaagt/metod-pax/admin_credentials.live.json`
- ntfy config: `/etc/adzaagt/metod-pax/config_notify.live.json`
- systemd env: `/etc/adzaagt/metod-pax/metod-pax.env`

## ntfy privacy

FIX600 stuurt standaard alleen:

```text
Nieuwe order ontvangen
Totaal: €...
Request: REQ-...
Open admin voor details.
```

Geen klantnaam, adres, e-mail, telefoon, opmerkingen, paneelregels, materiaalregels, orderinhoud of job-links.

Voorbeeld server-only ntfy config:

```json
{
  "ntfy": {
    "enabled": false,
    "topic_url": "https://ntfy.sh/YOUR_PRIVATE_TOPIC",
    "token": "YOUR_NTFY_ACCESS_TOKEN_OR_BEARER_TOKEN",
    "title": "AD Zaagt Configurator",
    "include_customer_details": false,
    "include_price_breakdown": false,
    "minimal_order_notice": true
  }
}
```

Gebruik voor echte live liever een eigen/private ntfy setup of minimaal een nieuw geheim topic met token. De oude topicnaam nooit hergebruiken.

## Kleine VPS defaults

Voor 4 GB RAM / 40 GB storage:

- `PUBLIC_JOB_MAX_CONCURRENT=1`
- `PUBLIC_JOB_MAX_CONCURRENT_PER_IP=1`
- `OPTIMIZER_TIMEOUT_SECONDS=300`
- `PUBLIC_JSON_MAX_BYTES=4194304`
- `SUBMIT_MAX_BYTES=8388608`

Dit is bewust voorzichtig voor staging.

## Live gates

Niet publiek live voordat dit is afgevinkt:

- HTTPS actief.
- Nginx stuurt `X-Forwarded-For`, `X-Real-IP` en `X-Forwarded-Proto`.
- `TRUSTED_PROXY_IPS=127.0.0.1,::1` klopt voor lokale nginx.
- `ALLOWED_ORIGINS` en `ALLOWED_ADMIN_ORIGINS` staan exact op het staging/live domein.
- App draait als systemd service.
- Worker draait als aparte systemd service als `/api/submit_config` gebruikt wordt.
- Admin credentials staan buiten app/GitHub.
- ntfy config staat buiten app/GitHub.
- Logrotatie en disk alerts zijn ingesteld.
- Private folders zijn via browser niet bereikbaar.

## FIX594 belangrijke VPS-poorten / Admin-koppeling

Deze server had al andere tools draaien:

- `8787` was bezet door Docker/AlgoRoute.
- `8791` was bezet door de stock/Bitcoin uvicorn app.
- METOD/PAX moet daarom intern op `127.0.0.1:8792` draaien.
- Nginx blijft publiek luisteren op `51.195.102.180:8790` en proxiet naar `127.0.0.1:8792`.

Gebruik dus in `/etc/adzaagt/metod-pax/metod-pax.env`:

```env
METOD_PORT=8792
ADMIN_STAGING_OPEN=1
```

`ADMIN_STAGING_OPEN=1` is alleen voor staging/test. Daarmee kan de admin HTML ook de admin API lezen, zodat Tool A orders direct zichtbaar worden in Admin. Voor echte live moet dit uit en moet HTTPS/session-login netjes aan.

Nginx moet bevatten:

```nginx
proxy_pass http://127.0.0.1:8792;
```

FIX594 bevat ook deze codefixes:

- `/admin` en `/admin/` openen dezelfde admin HTML.
- Geen foutieve `self._serve_admin()` route; die functie bestaat niet.
- Admin API fetches gebruiken expliciet `credentials:'same-origin'`.
- Als Tool A een directe optimalisatie-job maakt in `app/jobs/<jobid>/`, maar er geen request-mailboxregel bestaat, toont `/api/admin/requests` die job alsnog als admin-aanvraag.
- Daardoor is de live koppeling Tool A → job-map → Admin zichtbaar.
