@echo off
setlocal EnableExtensions
cd /d "%~dp0"
py -3 tools\make_admin_hash.py
echo.
pause
endlocal
