@echo off
setlocal EnableExtensions
set "PYTHONDONTWRITEBYTECODE=1"
cd /d "%~dp0"
title METOD Root Starter

if not exist "%~dp0app\START_METOD_APP.bat" (
  echo [METOD] ERROR: app\START_METOD_APP.bat not found.
  pause
  exit /b 1
)

echo [METOD] Starting METOD Launcher...
start "METOD Launcher" /D "%~dp0app" cmd /k "%~dp0app\START_METOD_APP.bat"
endlocal
