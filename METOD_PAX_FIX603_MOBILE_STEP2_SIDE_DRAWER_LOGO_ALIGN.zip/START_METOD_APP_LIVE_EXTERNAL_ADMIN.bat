@echo off
setlocal EnableExtensions
cd /d "%~dp0"

REM ============================================================
REM METOD/PAX - STAGING/LIVE STARTER (EDIT ME VOOR SERVER)
REM ============================================================
REM Deze live-audit ZIP bevat bewust GEEN echte admin credentials.
REM Maak op de server zelf een hash-only JSON bestand aan en wijs
REM ADMIN_CREDENTIALS_FILE hieronder naar dat bestand.
REM
REM Voorbeeld inhoud credentials JSON:
REM {
REM   "username": "admin",
REM   "password_hash": "pbkdf2_sha256$260000$..."
REM }
REM
REM Maak een hash met: MAKE_ADMIN_HASH.bat
REM ============================================================

set "PYTHONDONTWRITEBYTECODE=1"
set "APP_ENV=production"
set "PRODUCTION_HARDENING=1"

REM Reverse proxy / nginx: alleen deze proxies mogen X-Forwarded-For/X-Forwarded-Proto aanleveren.
REM Bij lokale nginx op dezelfde VPS is dit meestal goed:
set "TRUSTED_PROXY_IPS=127.0.0.1,::1"

REM Veiligere standaardlimieten voor publieke payloads en optimizer runtime.
set "PUBLIC_JSON_MAX_BYTES=4194304"
set "SUBMIT_MAX_BYTES=8388608"
set "OPTIMIZER_TIMEOUT_SECONDS=300"

REM Optioneel: server-only ntfy config buiten de app-map. Niet in de ZIP zetten.
REM set "NOTIFY_CONFIG_FILE=C:\veilig\pad\config_notify.live.json"


REM PAS DIT AAN VOOR STAGING/LIVE.
REM Beste praktijk: zet dit buiten de publieke webroot.
REM Voor staging mag dit desnoods naar %~dp0private_config\admin_credentials.live.json,
REM maar dat bestand moet je zelf op de server aanmaken en niet publiek delen.
set "ADMIN_CREDENTIALS_FILE=%~dp0private_config\admin_credentials.live.json"

REM PAS DIT AAN NAAR JE ECHTE STAGING/LIVE URL(S).
REM Voorbeelden:
REM set "ALLOWED_ORIGINS=https://staging.jouwdomein.nl"
REM set "ALLOWED_ADMIN_ORIGINS=https://staging.jouwdomein.nl"
set "ALLOWED_ORIGINS="
set "ALLOWED_ADMIN_ORIGINS="

if "%ALLOWED_ORIGINS%"=="" (
  echo [METOD] ERROR: ALLOWED_ORIGINS is nog leeg.
  echo Vul in dit bestand eerst de echte staging/live URL in.
  pause
  exit /b 1
)

if "%ALLOWED_ADMIN_ORIGINS%"=="" (
  echo [METOD] ERROR: ALLOWED_ADMIN_ORIGINS is nog leeg.
  echo Vul in dit bestand eerst de echte admin/staging/live URL in.
  pause
  exit /b 1
)

if not exist "%ADMIN_CREDENTIALS_FILE%" (
  echo [METOD] ERROR: %ADMIN_CREDENTIALS_FILE% bestaat nog niet.
  echo Maak eerst een hash-only admin credentials JSON aan op de server.
  echo Gebruik private_config\admin_credentials.live.example.json als voorbeeld.
  pause
  exit /b 1
)

call "%~dp0app\START_METOD_APP.bat"
endlocal
