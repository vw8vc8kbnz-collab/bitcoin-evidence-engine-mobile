Stijn-Tradifi-2026 Stock Gem Engine v0.2.0

Nieuwe functies:
- 24/7 auto scanner via dezelfde systemd-service
- standaard elk uur automatische scan
- handmatige scans blijven werken via dashboardknop
- ntfy-alert alleen bij nieuwe gem boven drempel, geen spam bij dezelfde ticker
- market cap zichtbaar in dashboard en ntfy melding
- broker/platform indicatie voor Nederland: DEGIRO, Interactive Brokers, Saxo
- scan history + alert history API

URL na install: http://SERVER-IP:8791
Service: stock-gem.service
Logs: /home/ubuntu/stock-gem-engine/logs/app.log

Let op: broker-koopbaarheid is indicatief. Controleer altijd zelf in je broker.
Dit is research-software, geen financieel advies.
