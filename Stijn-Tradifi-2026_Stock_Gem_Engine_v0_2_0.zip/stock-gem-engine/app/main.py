import os, json, sqlite3, time, math, random, threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Any, List, Optional
import requests
from fastapi import FastAPI
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data'
LOGS = ROOT / 'logs'
DATA.mkdir(exist_ok=True)
LOGS.mkdir(exist_ok=True)
load_dotenv(ROOT / '.env')
DB = DATA / 'stock_gems.sqlite3'

APP_VERSION = '0.2.0-hourly-ntfy-mcap-brokers'
NTFY_TOPIC = os.getenv('NTFY_TOPIC','Stijn-Tradifi-2026')
NTFY_SERVER = os.getenv('NTFY_SERVER','https://ntfy.sh').rstrip('/')
ALERT_THRESHOLD = float(os.getenv('GEM_ALERT_THRESHOLD','82'))
HYPE_RISK_MAX = float(os.getenv('HYPE_RISK_MAX_FOR_ALERT','55'))
MAX_SYMBOLS = int(os.getenv('MAX_SYMBOLS_PER_RUN','80'))
AUTO_SCAN_ENABLED = os.getenv('AUTO_SCAN_ENABLED','true').lower() in ('1','true','yes','on')
SCAN_INTERVAL_MINUTES = int(os.getenv('SCAN_INTERVAL_MINUTES','60'))
SEND_STARTUP_NTFY = os.getenv('SEND_STARTUP_NTFY','false').lower() in ('1','true','yes','on')

app = FastAPI(title='Stock Gem Evidence Engine', version=APP_VERSION)
app.mount('/static', StaticFiles(directory=str(ROOT/'app'/'static')), name='static')

SCAN_LOCK = threading.Lock()
SCHEDULER_STARTED = False
SCHEDULER_THREAD: Optional[threading.Thread] = None
LAST_SCAN = {'running': False, 'last_started': None, 'last_finished': None, 'last_count': 0, 'last_new_alerts': 0, 'last_error': None}

UNIVERSE = [
    {'symbol':'KULR','name':'KULR Technology Group','market':'US','exchange':'NYSE American','sector':'Energy storage / thermal'},
    {'symbol':'MVST','name':'Microvast','market':'US','exchange':'NASDAQ','sector':'Battery tech'},
    {'symbol':'AISP','name':'Airship AI','market':'US','exchange':'NASDAQ','sector':'AI / defense'},
    {'symbol':'BBAI','name':'BigBear.ai','market':'US','exchange':'NYSE','sector':'AI / defense'},
    {'symbol':'SOUN','name':'SoundHound AI','market':'US','exchange':'NASDAQ','sector':'Voice AI'},
    {'symbol':'QSI','name':'Quantum-Si','market':'US','exchange':'NASDAQ','sector':'Life science tools'},
    {'symbol':'QBTS','name':'D-Wave Quantum','market':'US','exchange':'NYSE','sector':'Quantum computing'},
    {'symbol':'RGTI','name':'Rigetti Computing','market':'US','exchange':'NASDAQ','sector':'Quantum computing'},
    {'symbol':'IONQ','name':'IonQ','market':'US','exchange':'NYSE','sector':'Quantum computing'},
    {'symbol':'PLUG','name':'Plug Power','market':'US','exchange':'NASDAQ','sector':'Hydrogen'},
    {'symbol':'BLDP','name':'Ballard Power','market':'CA/US','exchange':'NASDAQ/TSX','sector':'Hydrogen'},
    {'symbol':'REKR','name':'Rekor Systems','market':'US','exchange':'NASDAQ','sector':'AI traffic / public safety'},
    {'symbol':'OPTT','name':'Ocean Power Technologies','market':'US','exchange':'NYSE American','sector':'Ocean energy'},
    {'symbol':'LUNR','name':'Intuitive Machines','market':'US','exchange':'NASDAQ','sector':'Space'},
    {'symbol':'RKLB','name':'Rocket Lab','market':'US','exchange':'NASDAQ','sector':'Space'},
    {'symbol':'ASTS','name':'AST SpaceMobile','market':'US','exchange':'NASDAQ','sector':'Space telecom'},
    {'symbol':'NNDM','name':'Nano Dimension','market':'US','exchange':'NASDAQ','sector':'3D electronics'},
    {'symbol':'VUZI','name':'Vuzix','market':'US','exchange':'NASDAQ','sector':'AR glasses'},
    {'symbol':'HUMA','name':'Humacyte','market':'US','exchange':'NASDAQ','sector':'Biotech'},
    {'symbol':'DNA','name':'Ginkgo Bioworks','market':'US','exchange':'NYSE','sector':'Synthetic biology'},
    {'symbol':'EDIT','name':'Editas Medicine','market':'US','exchange':'NASDAQ','sector':'Gene editing'},
    {'symbol':'BEAM','name':'Beam Therapeutics','market':'US','exchange':'NASDAQ','sector':'Gene editing'},
    {'symbol':'CRBU','name':'Caribou Biosciences','market':'US','exchange':'NASDAQ','sector':'Gene editing'},
    {'symbol':'ARQQ','name':'Arqit Quantum','market':'UK/US','exchange':'NASDAQ','sector':'Cyber / quantum security'},
]

def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    con.execute('CREATE TABLE IF NOT EXISTS scans(id INTEGER PRIMARY KEY, ts TEXT, version TEXT, universe_count INTEGER, new_alerts INTEGER DEFAULT 0, mode TEXT, notes TEXT)')
    con.execute('''CREATE TABLE IF NOT EXISTS stocks(symbol TEXT PRIMARY KEY, name TEXT, market TEXT, exchange TEXT, sector TEXT, price REAL, change_pct REAL, market_cap REAL, gem_score REAL, early_signal REAL, hype_risk REAL, risk_score REAL, verdict TEXT, broker_info TEXT, explanation TEXT, updated_at TEXT, payload TEXT)''')
    con.execute('''CREATE TABLE IF NOT EXISTS alerts(symbol TEXT PRIMARY KEY, first_alerted_at TEXT, last_alerted_at TEXT, alert_count INTEGER, last_gem_score REAL, last_market_cap REAL, payload TEXT)''')
    return con

def log(msg):
    line = f"{datetime.now(timezone.utc).isoformat()} {msg}\n"
    with open(LOGS/'app.log','a',encoding='utf-8') as f: f.write(line)

def fmt_cap(x):
    if not x: return 'onbekend'
    try:
        x=float(x)
        if x >= 1_000_000_000: return f"${x/1_000_000_000:.2f}B"
        return f"${x/1_000_000:.1f}M"
    except Exception:
        return 'onbekend'

def broker_layer(item: Dict[str, Any]) -> Dict[str, Any]:
    market = (item.get('market') or '').upper()
    exchange = (item.get('exchange') or '').upper()
    symbol = item.get('symbol') or ''
    otc_like = 'OTC' in exchange or symbol.endswith('F') or symbol.endswith('Y')
    ibkr = 'Hoogste kans' if not otc_like else 'Mogelijk, maar OTC/permissions controleren'
    degiro = 'Waarschijnlijk' if any(x in exchange for x in ['NASDAQ','NYSE','TSX','XETRA','EURONEXT','LSE']) and not otc_like else 'Onzeker / vaak niet bij microcap-OTC'
    saxo = 'Mogelijk' if not otc_like else 'Onzeker'
    note = 'Controleer altijd zelf op ticker + beurs in je broker. Koopbaarheid kan per land, producttype, liquiditeit en broker-permissions verschillen.'
    return {'DEGIRO': degiro, 'Interactive Brokers': ibkr, 'Saxo': saxo, 'otc_risk': 'hoog' if otc_like else 'laag/middel', 'note': note}

def yahoo_quote(symbol: str) -> Dict[str, Any]:
    url = 'https://query1.finance.yahoo.com/v7/finance/quote'
    try:
        r = requests.get(url, params={'symbols': symbol}, timeout=10, headers={'User-Agent':'Mozilla/5.0'})
        j = r.json()
        res = (j.get('quoteResponse') or {}).get('result') or []
        return res[0] if res else {}
    except Exception as e:
        log(f'yahoo_quote_error {symbol}: {e}')
        return {}

def yahoo_news(symbol: str) -> List[Dict[str, Any]]:
    try:
        url = f'https://query1.finance.yahoo.com/v1/finance/search'
        r = requests.get(url, params={'q': symbol, 'newsCount': 5, 'quotesCount': 0}, timeout=10, headers={'User-Agent':'Mozilla/5.0'})
        return (r.json().get('news') or [])[:5]
    except Exception as e:
        log(f'yahoo_news_error {symbol}: {e}')
        return []

def safe_num(x, default=None):
    try:
        if x is None: return default
        if isinstance(x, float) and math.isnan(x): return default
        return float(x)
    except Exception:
        return default

def score_stock(base: Dict[str, str], q: Dict[str, Any], news: List[Dict[str, Any]]) -> Dict[str, Any]:
    price = safe_num(q.get('regularMarketPrice'), random.uniform(0.5, 8.0))
    prev = safe_num(q.get('regularMarketPreviousClose'), price)
    change_pct = ((price-prev)/prev*100) if prev and price else 0
    market_cap = safe_num(q.get('marketCap'), None)
    volume = safe_num(q.get('regularMarketVolume'), 0) or 0
    avg_volume = safe_num(q.get('averageDailyVolume3Month'), volume or 1) or 1
    vol_ratio = volume / max(avg_volume, 1)

    cap_score = 50
    if market_cap:
        if market_cap < 50_000_000: cap_score = 95
        elif market_cap < 150_000_000: cap_score = 88
        elif market_cap < 500_000_000: cap_score = 76
        elif market_cap < 1_500_000_000: cap_score = 55
        else: cap_score = 30

    news_score = min(100, 35 + len(news)*10)
    catalyst_words = 'contract partnership fda approval patent launch defense ai quantum battery uranium space revenue order grant trial customer acquisition breakthrough'
    titles = ' '.join([(n.get('title') or '') for n in news]).lower()
    catalyst_hits = sum(1 for w in catalyst_words.split() if w in titles)
    catalyst_score = min(100, 35 + catalyst_hits*12 + len(news)*4)
    hype_risk = min(100, max(5, abs(change_pct)*2.2 + max(0, vol_ratio-1)*18 + (20 if change_pct>25 else 0)))
    dilution_risk = 55
    sector_boost = 8 if any(x in base['sector'].lower() for x in ['quantum','ai','space','battery','biotech','gene','hydrogen','defense']) else 0
    early_signal = min(100, catalyst_score*0.55 + news_score*0.25 + min(100, vol_ratio*25)*0.20)
    risk_score = min(100, dilution_risk + (18 if price and price < 1 else 0) + (12 if hype_risk>70 else 0))
    gem_score = max(0, min(100, cap_score*0.35 + early_signal*0.34 + (100-hype_risk)*0.18 + sector_boost + (100-risk_score)*0.05))

    if hype_risk > 75: verdict='Already hot / wait'
    elif gem_score >= 82 and hype_risk <= HYPE_RISK_MAX: verdict='Strong early gem candidate'
    elif gem_score >= 68: verdict='Watchlist'
    elif risk_score >= 80: verdict='High risk / avoid for now'
    else: verdict='Too early'

    item = {
        'symbol': base['symbol'], 'name': base['name'], 'market': base['market'], 'exchange': base.get('exchange',''), 'sector': base['sector'],
        'price': price, 'change_pct': change_pct, 'market_cap': market_cap,
        'volume': volume, 'avg_volume': avg_volume, 'vol_ratio': vol_ratio,
        'gem_score': round(gem_score,1), 'early_signal': round(early_signal,1), 'hype_risk': round(hype_risk,1), 'risk_score': round(risk_score,1),
        'verdict': verdict, 'news': news, 'mcap_label': fmt_cap(market_cap)
    }
    item['broker_info'] = broker_layer(item)
    simple = []
    simple.append(f"{base['name']} zit in {base['sector']}. De tool ziet dit als een vroege kandidaat omdat de waardering/omvang relatief klein kan zijn en er nieuwe signalen rond nieuws of sector ontstaan.")
    simple.append(f"Market cap indicatief: {item['mcap_label']}.")
    simple.append(f"Early Signal {early_signal:.0f}/100, Hype Risk {hype_risk:.0f}/100. Ideaal is hoog early signal maar lage hype risk: dan is het mogelijk nog niet gepumpt.")
    if catalyst_hits: simple.append("Nieuws bevat mogelijke catalyst-woorden zoals contract, partnership, FDA, patent, AI, quantum of space.")
    simple.append("Let op: microcaps hebben vaak dilution-, liquiditeits- en pump/dump-risico. Deze score is research, geen koopadvies.")
    item['explanation'] = ' '.join(simple)
    item['deepseek_prompt'] = f"Analyseer {base['symbol']} ({base['name']}) als vroege smallcap gem in simpele taal. Data: price={price}, market_cap={market_cap}, sector={base['sector']}, news_titles={[n.get('title') for n in news]}"
    return item

def save_result(item):
    con = db()
    con.execute('''INSERT OR REPLACE INTO stocks(symbol,name,market,exchange,sector,price,change_pct,market_cap,gem_score,early_signal,hype_risk,risk_score,verdict,broker_info,explanation,updated_at,payload) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
        (item['symbol'],item['name'],item['market'],item.get('exchange',''),item['sector'],item['price'],item['change_pct'],item['market_cap'],item['gem_score'],item['early_signal'],item['hype_risk'],item['risk_score'],item['verdict'],json.dumps(item['broker_info']),item['explanation'],datetime.now(timezone.utc).isoformat(),json.dumps(item)))
    con.commit(); con.close()

def was_already_alerted(symbol: str) -> bool:
    con = db(); row = con.execute('SELECT symbol FROM alerts WHERE symbol=?',(symbol,)).fetchone(); con.close()
    return row is not None

def mark_alerted(item):
    now = datetime.now(timezone.utc).isoformat()
    con = db()
    row = con.execute('SELECT alert_count FROM alerts WHERE symbol=?',(item['symbol'],)).fetchone()
    if row:
        con.execute('UPDATE alerts SET last_alerted_at=?, alert_count=?, last_gem_score=?, last_market_cap=?, payload=? WHERE symbol=?', (now, int(row['alert_count'])+1, item['gem_score'], item['market_cap'], json.dumps(item), item['symbol']))
    else:
        con.execute('INSERT INTO alerts(symbol, first_alerted_at, last_alerted_at, alert_count, last_gem_score, last_market_cap, payload) VALUES(?,?,?,?,?,?,?)', (item['symbol'], now, now, 1, item['gem_score'], item['market_cap'], json.dumps(item)))
    con.commit(); con.close()

def send_ntfy(item, is_new=True):
    try:
        title = f"💎 Nieuwe gem: {item['symbol']} · {item['gem_score']}/100 · {item['mcap_label']}"
        brokers = item.get('broker_info') or {}
        body = (
            f"{item['name']} ({item['exchange']})\n"
            f"Market cap: {item['mcap_label']}\n"
            f"Verdict: {item['verdict']}\n"
            f"Gem {item['gem_score']} | Early {item['early_signal']} | Hype {item['hype_risk']} | Risk {item['risk_score']}\n\n"
            f"Waarom: {item['explanation'][:650]}\n\n"
            f"Koopbaarheid NL: DEGIRO={brokers.get('DEGIRO','?')}, IBKR={brokers.get('Interactive Brokers','?')}, Saxo={brokers.get('Saxo','?')}\n"
            f"Dashboard: http://51.195.102.180:8791"
        )
        requests.post(f'{NTFY_SERVER}/{NTFY_TOPIC}', data=body.encode('utf-8'), headers={'Title':title,'Priority':'4','Tags':'chart_with_upwards_trend,gem'}, timeout=10)
        mark_alerted(item)
        log(f"ntfy_sent {item['symbol']} new={is_new} score={item['gem_score']} mcap={item.get('market_cap')}")
        return True
    except Exception as e:
        log(f'ntfy_error {item["symbol"]}: {e}')
        return False

def run_scan(mode='manual'):
    if not SCAN_LOCK.acquire(blocking=False):
        return {'ok': False, 'running': True, 'message': 'Scan draait al'}
    LAST_SCAN.update({'running': True, 'last_started': datetime.now(timezone.utc).isoformat(), 'last_error': None})
    results=[]; new_alerts=0
    try:
        log(f'scan_start mode={mode} version={APP_VERSION}')
        for base in UNIVERSE[:MAX_SYMBOLS]:
            q = yahoo_quote(base['symbol'])
            n = yahoo_news(base['symbol'])
            item = score_stock(base,q,n)
            save_result(item)
            results.append(item)
            should_alert = item['gem_score'] >= ALERT_THRESHOLD and item['hype_risk'] <= HYPE_RISK_MAX
            if should_alert and not was_already_alerted(item['symbol']):
                if send_ntfy(item, is_new=True):
                    new_alerts += 1
            time.sleep(0.15)
        con=db(); con.execute('INSERT INTO scans(ts,version,universe_count,new_alerts,mode,notes) VALUES(?,?,?,?,?,?)',(datetime.now(timezone.utc).isoformat(),APP_VERSION,len(results),new_alerts,mode,'hourly/manual scan')); con.commit(); con.close()
        LAST_SCAN.update({'running': False, 'last_finished': datetime.now(timezone.utc).isoformat(), 'last_count': len(results), 'last_new_alerts': new_alerts})
        log(f'scan_done mode={mode} count={len(results)} new_alerts={new_alerts}')
        return {'ok': True, 'count': len(results), 'new_alerts': new_alerts, 'top': sorted(results, key=lambda x: x['gem_score'], reverse=True)[:10]}
    except Exception as e:
        LAST_SCAN.update({'running': False, 'last_error': str(e), 'last_finished': datetime.now(timezone.utc).isoformat()})
        log(f'scan_error mode={mode}: {e}')
        return {'ok': False, 'error': str(e)}
    finally:
        SCAN_LOCK.release()

def scheduler_loop():
    log(f'scheduler_started enabled={AUTO_SCAN_ENABLED} interval_min={SCAN_INTERVAL_MINUTES}')
    if SEND_STARTUP_NTFY:
        try: requests.post(f'{NTFY_SERVER}/{NTFY_TOPIC}', data=f'Stock Gem Engine {APP_VERSION} draait 24/7 ✅'.encode('utf-8'), headers={'Title':'Stijn-Tradifi-2026 online','Priority':'2'}, timeout=10)
        except Exception as e: log(f'startup_ntfy_error {e}')
    # first run shortly after startup
    time.sleep(8)
    while True:
        if AUTO_SCAN_ENABLED:
            run_scan(mode='auto-hourly')
        time.sleep(max(5, SCAN_INTERVAL_MINUTES * 60))

@app.on_event('startup')
def startup_event():
    global SCHEDULER_STARTED, SCHEDULER_THREAD
    db().close()
    if not SCHEDULER_STARTED:
        SCHEDULER_STARTED = True
        SCHEDULER_THREAD = threading.Thread(target=scheduler_loop, name='stock-gem-hourly-scheduler', daemon=True)
        SCHEDULER_THREAD.start()

@app.get('/', response_class=HTMLResponse)
def index():
    return (ROOT/'app'/'static'/'index.html').read_text(encoding='utf-8')

@app.get('/api/status')
def status():
    return {'ok': True, 'version': APP_VERSION, 'ntfy_topic': NTFY_TOPIC, 'db': str(DB), 'time': datetime.now(timezone.utc).isoformat(), 'auto_scan_enabled': AUTO_SCAN_ENABLED, 'scan_interval_minutes': SCAN_INTERVAL_MINUTES, 'alert_threshold': ALERT_THRESHOLD, 'hype_risk_max': HYPE_RISK_MAX, 'last_scan': LAST_SCAN}

@app.post('/api/scan')
def scan():
    return run_scan(mode='manual')

@app.get('/api/gems')
def gems():
    con=db()
    rows=con.execute('SELECT payload FROM stocks ORDER BY gem_score DESC, early_signal DESC LIMIT 200').fetchall()
    con.close()
    return {'items':[json.loads(r['payload']) for r in rows]}

@app.get('/api/scans')
def scans():
    con=db(); rows=con.execute('SELECT * FROM scans ORDER BY id DESC LIMIT 25').fetchall(); con.close()
    return {'items':[dict(r) for r in rows]}

@app.get('/api/alerts')
def alerts():
    con=db(); rows=con.execute('SELECT * FROM alerts ORDER BY first_alerted_at DESC LIMIT 100').fetchall(); con.close()
    return {'items':[dict(r) for r in rows]}

@app.post('/api/test-ntfy')
def test_ntfy():
    requests.post(f'{NTFY_SERVER}/{NTFY_TOPIC}', data=f'Stock Gem Evidence Engine testmelding werkt ✅\nVersie: {APP_VERSION}\nMarket cap komt vanaf v0.2.0 mee in gem-alerts.'.encode('utf-8'), headers={'Title':'Stijn-Tradifi-2026 test','Priority':'3'}, timeout=10)
    return {'ok': True, 'topic': NTFY_TOPIC}

@app.post('/api/force-alert/{symbol}')
def force_alert(symbol: str):
    con=db(); row=con.execute('SELECT payload FROM stocks WHERE symbol=?',(symbol.upper(),)).fetchone(); con.close()
    if not row: return {'ok': False, 'error': 'Ticker niet gevonden. Draai eerst een scan.'}
    item=json.loads(row['payload'])
    ok=send_ntfy(item, is_new=False)
    return {'ok': ok, 'symbol': symbol.upper()}

@app.get('/api/export')
def export():
    con=db(); rows=con.execute('SELECT payload FROM stocks ORDER BY gem_score DESC').fetchall(); con.close()
    path=DATA/'latest_gems_export.json'
    path.write_text(json.dumps([json.loads(r['payload']) for r in rows], indent=2), encoding='utf-8')
    return JSONResponse({'ok': True, 'path': str(path), 'count': len(rows)})
