#!/usr/bin/env python3
import os, sys, json, math, time, zipfile, csv
from pathlib import Path
from datetime import datetime, timezone
import requests
import pandas as pd
import numpy as np
from dotenv import load_dotenv

VERSION='v1.8.3'
BASE=Path(__file__).resolve().parent
OUT=BASE/'output'; OUT.mkdir(exist_ok=True)
load_dotenv(BASE/'.env')

DEFAULT_UNIVERSE = "BB,PLTR,IONQ,SOUN,NVDA,AMD,TSLA,AI,BBAI,RKLB,SMR,ACHR,JOBY,UPST,HOOD,COIN,MARA,RIOT,LCID,RIVN,RGTI,QBTS,OKLO,ASTS,LUNR,OUST,PATH,SOFI,AFRM,ROKU,SHOP,NET,CRWD,DDOG,SNOW,ARM,MU,AVGO,TSM,SMCI,APP,MRVL,INTC,ORCL,MSFT,GOOGL,META,AMZN,CRSP,BEAM,EDIT,NTLA,PLUG,ENPH,FSLR,CCJ,UEC,UUUU,ACHR,EVGO,CHPT,QS,LAZR,OPEN,DKNG,TDOC,SPCE,ENVX,STEM,SERV,TER,ISRG,IRDM,KTOS,AVAV,HIMS,NU,SE,GRAB,TOST,U,LMND,ROOT,CVNA"
THEME_MAP={
 'AI':['SOUN','BBAI','AI','PLTR','NVDA','AMD','SMCI','ARM','AVGO','MRVL','ORCL','MSFT','GOOGL','META'],
 'QUANTUM':['IONQ','RGTI','QBTS'], 'SPACE':['RKLB','LUNR','ASTS','SPCE','IRDM'],
 'NUCLEAR':['SMR','OKLO','CCJ','UEC','UUUU'], 'CRYPTO':['COIN','MARA','RIOT'],
 'EV_ROBOTICS':['ACHR','JOBY','LCID','RIVN','TSLA','OUST','LAZR','SERV'],
 'FINTECH':['HOOD','SOFI','AFRM','NU','TOST'], 'CYBER_CLOUD':['CRWD','NET','DDOG','SNOW','PATH'],
 'BIOTECH':['CRSP','BEAM','EDIT','NTLA'], 'DEFENSE':['KTOS','AVAV','PLTR']
}
SPECIAL={t:theme for theme,arr in THEME_MAP.items() for t in arr}

def env_float(k,d):
    try: return float(os.getenv(k,d))
    except: return d

def env_int(k,d):
    try: return int(os.getenv(k,d))
    except: return d

def fetch_hist(tickers, period='2y'):
    import yfinance as yf
    data={}
    for t in tickers:
        try:
            df=yf.download(t, period=period, interval='1d', auto_adjust=True, progress=False, threads=False)
            if df is None or df.empty: continue
            if isinstance(df.columns, pd.MultiIndex): df.columns=[c[0] for c in df.columns]
            df=df.dropna().copy(); data[t]=df
        except Exception as e:
            print(f'[WARN] {t} download failed: {e}')
    return data

def metrics_for(df, bench=None):
    close=df['Close']; vol=df['Volume']
    ret1=(close.iloc[-1]/close.iloc[-2]-1)*100 if len(close)>2 else 0
    ret3=(close.iloc[-1]/close.iloc[-4]-1)*100 if len(close)>4 else ret1
    ret20=(close.iloc[-1]/close.iloc[-21]-1)*100 if len(close)>21 else ret3
    ma20=close.rolling(20).mean().iloc[-1]; ma50=close.rolling(50).mean().iloc[-1]
    rv=float(vol.iloc[-1]/max(1,vol.rolling(20).mean().iloc[-1])) if len(vol)>20 else 1
    high52=float(close.tail(252).max()) if len(close)>20 else float(close.max())
    pos52=float(close.iloc[-1]/high52*100) if high52 else 0
    rs=0
    if bench is not None and len(bench)>21:
        b=bench['Close']; br=(b.iloc[-1]/b.iloc[-21]-1)*100
        rs=ret20-br
    score=max(0,min(100, 45 + ret20*1.8 + (rv-1)*8 + rs*1.2 + (5 if close.iloc[-1]>ma50 else -5)))
    return dict(price=float(close.iloc[-1]),ret1=ret1,ret3=ret3,ret20=ret20,relative_volume=rv,position_52w=pos52,rs_vs_bench=rs,technical_score=score,above_ma50=bool(close.iloc[-1]>ma50),above_ma20=bool(close.iloc[-1]>ma20))

def setup_rows(ticker, df, m):
    holds=[3,5,10,20]
    rows=[]; trades=[]
    close=df['Close']; vol=df['Volume']; ma20=close.rolling(20).mean(); ma50=close.rolling(50).mean(); avgvol=vol.rolling(20).mean()
    engines=['momentum_continuation_legacy','relative_strength_leader','momentum_rs_continuation','theme_momentum_leader','catalyst_momentum_proxy','price_reaction_confirmed']
    for eng in engines:
        dates=[]
        for i in range(60,len(df)-21):
            r20=(close.iloc[i]/close.iloc[i-20]-1)*100; rv=vol.iloc[i]/max(1,avgvol.iloc[i])
            cond=False
            if eng=='momentum_continuation_legacy': cond=r20>8 and rv>1.1 and close.iloc[i]>ma50.iloc[i]
            elif eng=='relative_strength_leader': cond=r20>12 and close.iloc[i]>ma20.iloc[i]
            elif eng=='momentum_rs_continuation': cond=r20>10 and rv>1.25
            elif eng=='theme_momentum_leader': cond=ticker in SPECIAL and r20>8
            elif eng=='catalyst_momentum_proxy': cond=ticker in SPECIAL and r20>5 and rv>1.2
            elif eng=='price_reaction_confirmed': cond=(close.iloc[i]/close.iloc[i-3]-1)*100>5 and rv>1.5
            if cond: dates.append(i)
        for h in holds:
            rets=[]
            for i in dates:
                if i+h < len(df):
                    r=(close.iloc[i+h]/close.iloc[i]-1)*100-0.20
                    rets.append(r); trades.append(dict(ticker=ticker,setup=eng,hold_days=h,entry_date=str(df.index[i].date()),exit_date=str(df.index[i+h].date()),return_pct=r))
            n=len(rets); avg=float(np.mean(rets)) if n else 0; win=float(np.mean([x>0 for x in rets])*100) if n else 0
            fake=1 if n<15 else 0
            evidence=avg*3 + (win-50)*0.8 + min(n,60)*0.8 + m['technical_score']*0.15
            if ticker in SPECIAL: evidence += 8
            elite = n>=25 and avg>3.5 and win>=55 and evidence>=82
            good = n>=18 and avg>2 and win>=52 and evidence>=55
            usable = n>=15 and avg>0
            rows.append(dict(ticker=ticker,theme=SPECIAL.get(ticker,'GENERAL'),setup=eng,hold_days=h,trades=n,avg_return_pct=round(avg,3),winrate_pct=round(win,2),evidence_score=round(evidence,2),fake_alpha_warning=fake,usable=int(usable),good_candidate=int(good),elite=int(elite),price=round(m['price'],3),ret3=round(m['ret3'],2),ret20=round(m['ret20'],2),relative_volume=round(m['relative_volume'],2),rs_vs_bench=round(m['rs_vs_bench'],2),position_52w=round(m['position_52w'],1),technical_score=round(m['technical_score'],1)))
    return rows,trades

def get_news(ticker, maxn=20):
    import yfinance as yf
    items=[]
    try:
        news=yf.Ticker(ticker).news or []
        for n in news[:maxn]:
            title=n.get('title') or n.get('content',{}).get('title') or ''
            pub=n.get('publisher') or n.get('content',{}).get('provider',{}).get('displayName') or ''
            link=n.get('link') or n.get('content',{}).get('canonicalUrl',{}).get('url') or ''
            ts=n.get('providerPublishTime') or n.get('content',{}).get('pubDate') or ''
            items.append(dict(ticker=ticker,title=title,publisher=pub,link=link,published=ts))
    except Exception as e:
        pass
    return [x for x in items if x['title']]

def local_event_score(ticker, news, m):
    text=' '.join([x['title'] for x in news]).lower()
    bull=['partnership','contract','deal','upgrade','beats','beat','guidance','approval','launch','merger','acquisition','ai','nvidia','government','billion']
    bear=['offering','dilution','downgrade','lawsuit','misses','miss','bankruptcy','investigation']
    b=sum(text.count(w) for w in bull); r=sum(text.count(w) for w in bear)
    catalyst=max(0,min(100,45+b*7-r*12 + (10 if ticker in SPECIAL else 0)))
    reaction=max(0,min(100,45+m['ret3']*2+(m['relative_volume']-1)*10+m['rs_vs_bench']*1.5))
    return catalyst,reaction

def deepseek_analyze(ticker, theme, news, m, cost_rows):
    key=os.getenv('DEEPSEEK_API_KEY','').strip(); use=os.getenv('USE_DEEPSEEK','1')=='1'
    if not key or not use:
        return None
    prompt_path=BASE/'deepseek_prompt.md'
    system=prompt_path.read_text() if prompt_path.exists() else 'Return JSON only.'
    headlines=[n['title'] for n in news[:env_int('DEEPSEEK_MAX_HEADLINES',35)]]
    payload={"ticker":ticker,"theme":theme,"market_data":m,"headlines":headlines,"instruction":"Link news to market data. Be strict. Return JSON only."}
    try:
        res=requests.post('https://api.deepseek.com/chat/completions',headers={'Authorization':f'Bearer {key}','Content-Type':'application/json'},json={
            'model':os.getenv('DEEPSEEK_MODEL','deepseek-chat'),
            'messages':[{'role':'system','content':system},{'role':'user','content':json.dumps(payload)[:24000]}],
            'temperature':0.15,'max_tokens':env_int('DEEPSEEK_MAX_OUTPUT_TOKENS',3000),'response_format':{'type':'json_object'}
        },timeout=45)
        data=res.json(); content=data['choices'][0]['message']['content']; out=json.loads(content)
        usage=data.get('usage',{}); inp=usage.get('prompt_tokens',0); opt=usage.get('completion_tokens',0)
        cost=inp/1_000_000*env_float('DEEPSEEK_INPUT_USD_PER_M',0.14)+opt/1_000_000*env_float('DEEPSEEK_OUTPUT_USD_PER_M',0.28)
        cost_rows.append(dict(timestamp=datetime.now(timezone.utc).isoformat(),ticker=ticker,input_tokens=inp,output_tokens=opt,estimated_cost_usd=round(cost,6),provider='deepseek'))
        out['provider']='deepseek'; return out
    except Exception as e:
        cost_rows.append(dict(timestamp=datetime.now(timezone.utc).isoformat(),ticker=ticker,input_tokens=0,output_tokens=0,estimated_cost_usd=0,provider='local_fallback_after_error',error=str(e)[:160]))
        return None

def run(tickers, period):
    import yfinance as yf
    bench=fetch_hist(['QQQ'],period).get('QQQ')
    data=fetch_hist(tickers,period)
    summary=[]; trades=[]; news_items=[]; ai_rows=[]; reaction_rows=[]; consensus_rows=[]; analog_rows=[]; cost_rows=[]
    metrics={}
    for t,df in data.items(): metrics[t]=metrics_for(df,bench)
    # local shortlist by technical score / movement / theme
    shortlist=sorted(metrics.keys(), key=lambda t: metrics[t]['technical_score'] + abs(metrics[t]['ret3'])*1.5 + (12 if t in SPECIAL else 0), reverse=True)[:env_int('DEEPSEEK_MAX_TICKERS',24)]
    for t,df in data.items():
        rows,tr=setup_rows(t,df,metrics[t]); summary+=rows; trades+=tr
    for t in shortlist:
        news=get_news(t, env_int('DEEPSEEK_MAX_HEADLINES',35)); news_items += news
        cat,react=local_event_score(t,news,metrics[t])
        consensus_rows.append(dict(ticker=t,headline_count=len(news),consensus_score=cat,theme=SPECIAL.get(t,'GENERAL')))
        reaction_rows.append(dict(ticker=t,price_reaction_score=react,ret3=metrics[t]['ret3'],ret20=metrics[t]['ret20'],relative_volume=metrics[t]['relative_volume'],rs_vs_bench=metrics[t]['rs_vs_bench']))
        analog_rows.append(dict(ticker=t,closest_analog_theme=SPECIAL.get(t,'GENERAL'),analog_quality=round((cat+react)/2,2),expected_3d=round((cat+react)/22,2),expected_10d=round((cat+react)/14,2)))
        ai=deepseek_analyze(t,SPECIAL.get(t,'GENERAL'),news,metrics[t],cost_rows)
        if not ai:
            fs=round(cat*.45+react*.45+metrics[t]['technical_score']*.10,2); conv='EXTREME' if fs>=92 else 'ELITE' if fs>=82 else 'HIGH' if fs>=70 else 'GOOD' if fs>=55 else 'WATCH'
            ai=dict(ticker=t,event_type='local_catalyst',event_quality=conv,materiality=cat,market_confirmation=react,continuation_3d=min(95,fs),continuation_10d=max(0,min(95,fs-7)),final_score=fs,conviction=conv,reasoning='Local fallback: catalyst proxy linked with price reaction and relative strength.',provider='local_fallback')
        ai['ticker']=t; ai['theme']=SPECIAL.get(t,'GENERAL'); ai_rows.append(ai)
    # enrich summary with AI bonus per ticker
    ai_map={r['ticker']:r for r in ai_rows}
    for r in summary:
        ai=ai_map.get(r['ticker'],{})
        bonus=float(ai.get('final_score',0))*0.25 if ai else 0
        r['ai_final_score']=round(float(ai.get('final_score',0)),2) if ai else 0
        r['ai_conviction']=ai.get('conviction','') if ai else ''
        r['combined_score']=round(r['evidence_score']+bonus,2)
        r['elite']=1 if r['combined_score']>=82 and r['trades']>=18 and r['avg_return_pct']>1.5 else r['elite']
        r['good_candidate']=1 if r['combined_score']>=55 and r['trades']>=15 and r['avg_return_pct']>0 else r['good_candidate']
    write_outputs(summary,trades,news_items,ai_rows,reaction_rows,consensus_rows,analog_rows,cost_rows)
    send_ntfy(ai_rows)
    print(f'Done. trades={len(trades)} summary_rows={len(summary)} elite={sum(int(r.get("elite",0)) for r in summary)} good={sum(int(r.get("good_candidate",0)) for r in summary)} deepseek_rows={len(ai_rows)}')

def write_csv(name, rows):
    p=OUT/name
    if not rows:
        p.write_text('empty\n'); return
    keys=sorted(set().union(*[r.keys() for r in rows]))
    with p.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=keys); w.writeheader(); w.writerows(rows)

def write_outputs(summary,trades,news,ai,reaction,consensus,analog,cost):
    write_csv(f'see_summary_{VERSION}.csv',summary); write_csv(f'see_trades_{VERSION}.csv',trades)
    write_csv(f'see_elite_{VERSION}.csv',[r for r in summary if int(r.get('elite',0))])
    write_csv(f'see_usable_{VERSION}.csv',[r for r in summary if int(r.get('usable',0)) or int(r.get('good_candidate',0))])
    by_setup=[]
    for s,g in pd.DataFrame(summary).groupby('setup'):
        by_setup.append(dict(setup=s,rows=len(g),trades=int(g['trades'].sum()),elite=int(g['elite'].sum()),avg_expectancy=round(g['avg_return_pct'].mean(),3),avg_combined_score=round(g['combined_score'].mean(),2)))
    by_ticker=[]
    for s,g in pd.DataFrame(summary).groupby('ticker'):
        by_ticker.append(dict(ticker=s,theme=SPECIAL.get(s,'GENERAL'),rows=len(g),trades=int(g['trades'].sum()),elite=int(g['elite'].sum()),avg_expectancy=round(g['avg_return_pct'].mean(),3),avg_combined_score=round(g['combined_score'].mean(),2)))
    write_csv(f'see_by_setup_{VERSION}.csv',by_setup); write_csv(f'see_by_ticker_{VERSION}.csv',by_ticker)
    write_csv(f'see_news_items_{VERSION}.csv',news); write_csv(f'see_ai_analyst_{VERSION}.csv',ai)
    write_csv(f'see_price_reaction_{VERSION}.csv',reaction); write_csv(f'see_news_consensus_{VERSION}.csv',consensus); write_csv(f'see_historical_analog_memory_{VERSION}.csv',analog); write_csv(f'see_deepseek_costs_{VERSION}.csv',cost)
    total_cost=sum(float(r.get('estimated_cost_usd',0) or 0) for r in cost); scans=env_int('DEEPSEEK_SCANS_PER_DAY',4)
    monitor=[dict(version=VERSION,run_cost_usd=round(total_cost,6),monthly_estimate_usd=round(total_cost*scans*30,4),budget_usd=env_float('DEEPSEEK_MONTHLY_BUDGET_USD',5),deepseek_rows=len(ai),generated_at=datetime.now(timezone.utc).isoformat())]
    write_csv(f'see_cost_monitor_{VERSION}.csv',monitor)
    with zipfile.ZipFile(OUT/'all.zip','w',zipfile.ZIP_DEFLATED) as z:
        for f in OUT.glob(f'*{VERSION}*.csv'): z.write(f,f.name)

def send_ntfy(ai_rows):
    if os.getenv('NTFY_ENABLED','0')!='1': return
    topic=os.getenv('NTFY_TOPIC','stock-signals-Stijn-2026'); minp=env_float('NTFY_MIN_PROB',82); maxn=env_int('NTFY_MAX_ALERTS',5)
    rows=sorted(ai_rows,key=lambda r: float(r.get('final_score',0) or 0), reverse=True)
    sent=0
    for r in rows:
        score=float(r.get('final_score',0) or 0); conv=str(r.get('conviction',''))
        if score<minp and conv not in ('ELITE','EXTREME'): continue
        title=f"{'🚨' if score>=92 else '🟢'} {conv} STOCK SIGNAL {r.get('ticker')}"
        msg=f"Score {score:.1f} | 3D {r.get('continuation_3d','?')} | 10D {r.get('continuation_10d','?')}\nEvent: {r.get('event_type')}\n{r.get('reasoning','')}"
        try: requests.post(f'https://ntfy.sh/{topic}',data=msg.encode('utf-8'),headers={'Title':title,'Tags':'chart_with_upwards_trend'},timeout=8)
        except: pass
        sent+=1
        if sent>=maxn: break

if __name__=='__main__':
    tickers=(sys.argv[1] if len(sys.argv)>1 else DEFAULT_UNIVERSE).replace(' ','').split(',')
    period=sys.argv[2] if len(sys.argv)>2 else '2y'
    run([t for t in tickers if t], period)
