# v1.8.3
- Larger tiered universe and stronger DeepSeek analyst context.
- News linked to market data: ret3, ret20, relative volume, RS vs QQQ, 52w position.
- Price reaction / consensus / analog memory exports.
- Stricter AI conviction fields and ntfy gating.
- Preserves v1.1+ deployment baseline.
