# Stock Evidence Engine v1.8.3

AI Catalyst + Market Reaction release.

- DeepSeek receives richer news + market-data context.
- Larger universe support; local scan shortlists top candidates.
- NTFY alerts only for high-probability AI signals.
- Monthly cost monitor stays budget-aware.
- Stable stdlib `server.py` dashboard on port 8798.
