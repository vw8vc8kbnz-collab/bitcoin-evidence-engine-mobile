import os, json, math, re, csv, io, subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional, Any, Dict
from difflib import SequenceMatcher
import httpx
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

APP_VERSION = "2.0.5_MULTI_DAY_AGENDA"
STORE_DIR = Path(os.getenv("ALGOROUTE_STORE", "/app/store"))
STORE_DIR.mkdir(parents=True, exist_ok=True)
OSRM_URL = os.getenv("OSRM_URL", "http://host.docker.internal:5000").rstrip("/")
OPTIMIZER_CORE_BIN = os.getenv("OPTIMIZER_CORE_BIN", "/app/algoroute_core")

app = FastAPI(title="AlgoRoute API", version=APP_VERSION)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

# ----------------------------
# Persistence helpers
# ----------------------------
def load_json(name: str, default: Any):
    path = STORE_DIR / name
    if not path.exists():
        path.write_text(json.dumps(default, indent=2, ensure_ascii=False), encoding="utf-8")
    return json.loads(path.read_text(encoding="utf-8"))

def save_json(name: str, data: Any):
    (STORE_DIR / name).write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

def default_settings() -> Dict[str, Any]:
    return {
        "max_route_hours": 8,
        "default_service_time_minutes": 15,
        "load_safety_margin_percent": 12,
        "default_depot": [4.9041, 52.3676],
        "depot_name": "Hoofddepot",
        "depot_address": "",
        "depot_postal_code": "",
        "depot_city": "",
        "return_to_depot": True,
        "route_strategy": "minimize_routes_then_time"
    }

def load_settings() -> Dict[str, Any]:
    settings = load_json("settings.json", default_settings())
    base = default_settings()
    base.update(settings or {})
    return base

def vehicle_load_profile(v: Dict[str, Any]) -> Dict[str, Any]:
    # RDW is used as an identity/start source. The operational loading truth is the user-owned load profile.
    max_ep = int(parse_number(v.get("europallet_capacity", v.get("pallet_capacity", 0)), 0))
    max_rc = int(parse_number(v.get("roll_container_capacity", 0), 0))
    length_cm = parse_number(v.get("load_length_cm", v.get("cargo_length_cm", 0)), 0)
    width_cm = parse_number(v.get("load_width_cm", v.get("cargo_width_cm", 0)), 0)
    floor_m2 = parse_number(v.get("floor_capacity_m2", 0), 0)
    if not floor_m2 and length_cm and width_cm:
        floor_m2 = round((length_cm * width_cm) / 10000, 3)
    # If only max EP/RC is known, derive conservative floor area. Do not add EP and RC together.
    derived_from_ep = max_ep * 0.96 if max_ep else 0
    derived_from_rc = max_rc * 0.56 if max_rc else 0
    if not floor_m2:
        floor_m2 = max(derived_from_ep, derived_from_rc)
    margin = parse_number(v.get("load_safety_margin_percent", load_settings().get("load_safety_margin_percent", 12)), 12) / 100
    usable_floor_m2 = max(0, floor_m2 * (1 - margin)) if floor_m2 else 0
    max_route_min = parse_number(v.get("max_route_minutes", 0), 0) or parse_number(v.get("max_route_hours", 0), 0) * 60 or load_settings().get("max_route_hours", 8) * 60
    return {
        "floor_capacity_m2": round(floor_m2, 3),
        "usable_floor_m2": round(usable_floor_m2, 3),
        "max_route_minutes": int(max_route_min),
        "load_safety_margin_percent": round(margin * 100, 1),
        "max_europallets": max_ep,
        "max_roll_containers": max_rc,
        "note": "Pallets en rolcontainers delen dezelfde vloer. Max EP en max RC worden niet bij elkaar opgeteld."
    }

def order_floor_m2(o: Dict[str, Any]) -> float:
    ep = parse_number(o.get("europallets", 0), 0)
    rc = parse_number(o.get("roll_containers", 0), 0)
    # v1.2 floor-space approximation: EP=120x80, RC≈80x70. Full 3D comes later.
    return round(ep * 0.96 + rc * 0.56, 3)

# ----------------------------
# Full universal import field catalog
# ----------------------------
FIELD_CATALOG: List[Dict[str, Any]] = [
    # Order
    {"id":"order_number","label":"Ordernummer","category":"Order","required":True,"type":"text","aliases":["order","ordernr","order nr","order nummer","ordernummer","order_number","order no","bon","bonnummer","referentie","reference","ref","documentnr","documentnummer","webshop order","webshop_order"]},
    {"id":"order_line_number","label":"Orderregelnummer","category":"Order","type":"text","aliases":["regel","regelnummer","line","line number","orderline","order regel","orderregel","itemline"]},
    {"id":"external_reference","label":"Externe referentie","category":"Order","type":"text","aliases":["external reference","extern referentie","klant referentie","client reference","purchase order","po","po number","inkoopnummer"]},
    {"id":"order_status","label":"Orderstatus","category":"Order","type":"text","aliases":["status","order status","orderstatus","release status","vrijgave"]},
    {"id":"source_system","label":"Bron systeem","category":"Order","type":"text","aliases":["source","bron","system","systeem","erp","webshop","platform"]},

    # Customer
    {"id":"customer_name","label":"Klantnaam","category":"Klant","required":True,"type":"text","aliases":["klant","klantnaam","naam klant","customer","customer name","customer_name","client","client name","debiteur","debiteurnaam","aflevernaam","naam","bedrijf","company","company name","organisatie","organisatie naam"]},
    {"id":"customer_number","label":"Klantnummer","category":"Klant","type":"text","aliases":["klantnummer","customer number","customer no","customer_id","debiteur nr","debiteurnummer","client id","klant id"]},
    {"id":"contact_name","label":"Contactpersoon","category":"Klant","type":"text","aliases":["contact","contactpersoon","contact name","attn","tav","ter attentie van","attention"]},
    {"id":"contact_email","label":"E-mail","category":"Klant","type":"email","aliases":["email","e-mail","mail","email address","e-mailadres","contact email"]},
    {"id":"contact_phone","label":"Telefoon","category":"Klant","type":"phone","aliases":["telefoon","phone","tel","mobiel","mobile","gsm","telephone","contact phone"]},

    # Address
    {"id":"delivery_address_full","label":"Volledig afleveradres","category":"Adres","type":"address","aliases":["adres","address","delivery address","afleveradres","ship to address","straat + huisnummer","adresregel","address line","volledig adres"]},
    {"id":"street","label":"Straat","category":"Adres","type":"text","aliases":["straat","street","road","straatnaam","address street"]},
    {"id":"house_number","label":"Huisnummer","category":"Adres","type":"text","aliases":["huisnummer","huisnr","house number","nr","number","building number"]},
    {"id":"house_number_suffix","label":"Huisnummer toevoeging","category":"Adres","type":"text","aliases":["toevoeging","huisnummer toevoeging","suffix","addition","bus","unit"]},
    {"id":"postal_code","label":"Postcode","category":"Adres","type":"postcode_nl","aliases":["postcode","post code","postal code","zip","zipcode","zip code","pc","postcode nl"]},
    {"id":"city","label":"Plaats","category":"Adres","type":"city","aliases":["plaats","woonplaats","city","stad","town","gemeente","locality"]},
    {"id":"country","label":"Land","category":"Adres","type":"country","aliases":["land","country","landcode","country code","iso country"]},
    {"id":"province","label":"Provincie","category":"Adres","type":"text","aliases":["provincie","province","regio","state","deelstaat","prov","district","gebied"]},
    {"id":"latitude","label":"Latitude","category":"Adres","type":"number","aliases":["latitude","lat","breedtegraad","gps lat","gps_lat"]},
    {"id":"longitude","label":"Longitude","category":"Adres","type":"number","aliases":["longitude","lon","lng","lengtegraad","gps lon","gps_lng","gps long"]},

    # Delivery/date/time windows
    {"id":"delivery_date","label":"Leverdatum","category":"Tijdvenster","required":True,"type":"date","aliases":["leverdatum","delivery date","date","datum","afleverdatum","scheduled date","planning date","planned date","ritdatum","bezorgdatum"]},
    {"id":"time_window_start","label":"Tijdvenster start","category":"Tijdvenster","type":"time","aliases":["tijd start","starttijd","window start","time window start","delivery window start","van","vanaf","not before","niet voor","from","start"]},
    {"id":"time_window_end","label":"Tijdvenster eind","category":"Tijdvenster","type":"time","aliases":["tijd eind","eindtijd","window end","time window end","delivery window end","tot","tot en met","not after","niet na","until","end"]},
    {"id":"time_window_combined","label":"Tijdslot gecombineerd","category":"Tijdvenster","type":"time_window","aliases":["tijdslot","tijd venster","tijdvenster","window","time window","delivery window","slot","timeslot","tijd","delivery slot","levervenster"]},
    {"id":"appointment_required","label":"Afspraak verplicht","category":"Tijdvenster","type":"boolean","aliases":["afspraak","appointment","appointment required","afspraak verplicht","bel afspraak","op afspraak"]},
    {"id":"max_delay_minutes","label":"Max vertraging toegestaan","category":"Tijdvenster","type":"integer","aliases":["max vertraging","max delay","delay allowed","max late","max_late_minutes","customer promise","promise guard"]},

    # Load and products
    {"id":"product_sku","label":"SKU / artikelnummer","category":"Producten","type":"text","aliases":["sku","artikel","artikelnummer","productcode","product code","item","item code","article","article number"]},
    {"id":"product_name","label":"Productnaam","category":"Producten","type":"text","aliases":["product","productnaam","omschrijving","description","item description","artikel omschrijving","product name"]},
    {"id":"quantity","label":"Aantal","category":"Producten","type":"integer","aliases":["aantal","qty","quantity","hoeveelheid","stuks","pcs","pieces","colli"]},
    {"id":"weight_kg","label":"Gewicht kg","category":"Gewicht & Volume","type":"number","aliases":["gewicht","kg","weight","weight kg","gewicht kg","totaalgewicht","gross weight","bruto gewicht"]},
    {"id":"weight_g","label":"Gewicht gram","category":"Gewicht & Volume","type":"integer","aliases":["gewicht gram","weight g","grams","gram","gewicht_g"]},
    {"id":"volume_m3","label":"Volume m³","category":"Gewicht & Volume","type":"number","aliases":["volume","m3","m³","cbm","cubic","kuub","kubieke meter"]},
    {"id":"length_mm","label":"Lengte mm","category":"Gewicht & Volume","type":"integer","aliases":["lengte","length","len","l","lengte mm","length mm"]},
    {"id":"width_mm","label":"Breedte mm","category":"Gewicht & Volume","type":"integer","aliases":["breedte","width","w","breedte mm","width mm"]},
    {"id":"height_mm","label":"Hoogte mm","category":"Gewicht & Volume","type":"integer","aliases":["hoogte mm","height mm","h mm","hoogte_mm","height_mm"]},
    {"id":"length_cm","label":"Lengte cm","category":"Gewicht & Volume","type":"integer","aliases":["lengte cm","lengte_cm","length cm","length_cm","lengte in cm","length in cm","maat lengte cm","afmeting lengte cm","dim l cm","l cm","pakket lengte cm","colli lengte cm","product lengte cm","lengteh","lenghte cm","lenght cm","lenght_cm","lengte c m","lengt cm","lengtecm","lenghtcm"]},
    {"id":"width_cm","label":"Breedte cm","category":"Gewicht & Volume","type":"integer","aliases":["breedte cm","breedte_cm","width cm","width_cm","breedte in cm","width in cm","maat breedte cm","afmeting breedte cm","dim b cm","w cm","b cm","pakket breedte cm","colli breedte cm","product breedte cm","breete cm","breedtte cm","breete_cm","widht cm","widht_cm","breedtecm","widthcm"]},
    {"id":"height_cm","label":"Hoogte cm","category":"Gewicht & Volume","type":"integer","aliases":["hoogte cm","hoogte_cm","height cm","height_cm","hoogte in cm","height in cm","maat hoogte cm","afmeting hoogte cm","dim h cm","h cm","pakket hoogte cm","colli hoogte cm","product hoogte cm","hoogteh","hhoogte cm","heigth cm","heigth_cm","hoogtecm","heightcm"]},
    {"id":"europallets","label":"Europallets","category":"Pallets & Rolcontainers","type":"integer","aliases":["pallet","pallets","europallet","europallets","epal","ep","aantal pallets","pallet qty","pallet_count"]},
    {"id":"block_pallets","label":"Blokpallets","category":"Pallets & Rolcontainers","type":"integer","aliases":["blokpallet","blokpallets","block pallet","block pallets"]},
    {"id":"roll_containers","label":"Rolcontainers","category":"Pallets & Rolcontainers","type":"integer","aliases":["rolcontainer","rolcontainers","rc","rollcontainer","roll container","roll containers","rolco","roll cage"]},
    {"id":"loading_meters","label":"Laadmeters","category":"Pallets & Rolcontainers","type":"number","aliases":["laadmeter","laadmeters","ldm","loading meter","loading meters","load meters"]},
    {"id":"stackable","label":"Stapelbaar","category":"Load regels","type":"boolean","aliases":["stapelbaar","stackable","mag stapelen","stacking","can stack"]},
    {"id":"fragile","label":"Breekbaar","category":"Load regels","type":"boolean","aliases":["breekbaar","fragile","glas","kwetsbaar","delicate"]},
    {"id":"tiltable","label":"Kantelbaar","category":"Load regels","type":"boolean","aliases":["kantelbaar","tiltable","niet kantelen","do not tilt","upright","rechtop"]},
    {"id":"hazard_tags","label":"Hazard tags","category":"Load regels","type":"list","aliases":["hazard","dangerous goods","adr","gevaarlijke stoffen","chemical","chemisch","food","frozen","tags"]},
    {"id":"temperature_zone","label":"Temperatuurzone","category":"Load regels","type":"text","aliases":["temperature","temp zone","temperatuur","koel","gekoeld","frozen","ambient","chilled","frozen"]},

    # Planning/service
    {"id":"service_time_minutes","label":"Service/lostijd minuten","category":"Service","type":"integer","aliases":["lostijd","los tijd","service time","service minutes","handling time","handling_time","minuten lossen","delivery duration","install time","montagetijd"]},
    {"id":"priority","label":"Prioriteit","category":"Planning","type":"integer","aliases":["prioriteit","priority","urgent","spoed","rush","importance","urgency"]},
    {"id":"driver_notes","label":"Chauffeursinstructies","category":"Instructies","type":"text","aliases":["instructies","instructions","driver notes","chauffeur instructies","instructies chauffeur","opmerking chauffeur","delivery notes","notities"]},
    {"id":"access_notes","label":"Toegang/lift/verdieping","category":"Service","type":"text","aliases":["lift","verdieping","floor","access","toegang","parking","parkeerinfo","etage"]},
    {"id":"installation_required","label":"Montage/installatie vereist","category":"Service","type":"boolean","aliases":["montage","installatie","installatie vereist","install required","install","installation","installation required","assembly","plaatsen","monteren"]},
    {"id":"two_person_delivery","label":"Twee personen nodig","category":"Service","type":"boolean","aliases":["2 man","twee man","two person","2 persons","two_person","extra man","bijrijder"]},
    {"id":"return_pickup","label":"Retour/ophalen","category":"Service","type":"boolean","aliases":["retour","return","pickup","ophalen","retourname","take back"]},

    # Tracking/finance/custom
    {"id":"tracking_email_allowed","label":"Klant e-mail tracking toegestaan","category":"Tracking","type":"boolean","aliases":["tracking email","mail tracking","notify email","email notificatie"]},
    {"id":"tracking_sms_allowed","label":"Klant SMS tracking toegestaan","category":"Tracking","type":"boolean","aliases":["sms","sms tracking","notify sms","sms notificatie"]},
    {"id":"invoice_number","label":"Factuurnummer","category":"Finance","type":"text","aliases":["factuur","factuurnummer","invoice","invoice number","invoice no"]},
    {"id":"cod_amount","label":"Remboers / te innen bedrag","category":"Finance","type":"number","aliases":["rembours","cod","cash on delivery","te innen","collect amount","bedrag innen"]},
    {"id":"custom_1","label":"Custom veld 1","category":"Custom","type":"text","aliases":["custom1","extra1","vrij veld 1"]},
    {"id":"custom_2","label":"Custom veld 2","category":"Custom","type":"text","aliases":["custom2","extra2","vrij veld 2"]},
]

REQUIRED_FIELDS = ["order_number", "customer_name", "delivery_date"]
ADDRESS_REQUIRED_GROUP = {"delivery_address_full", "street", "house_number", "postal_code", "city", "latitude", "longitude"}

# ----------------------------
# Mapping detection helpers
# ----------------------------
def norm(s: Any) -> str:
    s = str(s or "").lower().strip()
    s = re.sub(r"[_\-./]+", " ", s)
    s = re.sub(r"[^a-z0-9áàäéèëíìïóòöúùüñç\s]", "", s)
    return re.sub(r"\s+", " ", s).strip()


# Exact header mapping has absolute priority over fuzzy/value detection.
# This prevents numeric columns like Huisnummer, Service/lostijd or Niet leveren voor
# from being hijacked by generic volume/weight/length fields.
DIRECT_HEADER_MAP = {
    "ordernummer": "order_number",
    "order nummer": "order_number",
    "orderregel": "order_line_number",
    "orderregelnummer": "order_line_number",
    "externe referentie": "external_reference",
    "klantnaam": "customer_name",
    "klantnummer": "customer_number",
    "contactpersoon": "contact_name",
    "telefoon": "contact_phone",
    "e mail": "contact_email",
    "email": "contact_email",
    "volledig afleveradres": "delivery_address_full",
    "afleveradres": "delivery_address_full",
    "straat": "street",
    "huisnummer": "house_number",
    "huisnr": "house_number",
    "huisnummer toevoeging": "house_number_suffix",
    "postcode": "postal_code",
    "plaats": "city",
    "woonplaats": "city",
    "land": "country",
    "provincie": "province",
    "province": "province",
    "regio": "province",
    "state": "province",
    "prov": "province",
    "gebied": "province",
    "aflever plaats": "city",
    "afleverplaats": "city",
    "leverplaats": "city",
    "adresregel 1": "delivery_address_full",
    "address1": "delivery_address_full",
    "straat huisnummer": "delivery_address_full",
    "lostijd": "service_time_minutes",
    "service tijd": "service_time_minutes",
    "servicetijd": "service_time_minutes",
    "stopduur": "service_time_minutes",
    "montage tijd": "service_time_minutes",
    "montagetijd": "service_time_minutes",
    "deelstaat": "province",
    "latitude": "latitude",
    "lat": "latitude",
    "longitude": "longitude",
    "lng": "longitude",
    "lon": "longitude",
    "leverdatum": "delivery_date",
    "tijdvenster start": "time_window_start",
    "tijdvenster starttijd": "time_window_start",
    "tijdvenster eind": "time_window_end",
    "tijdvenster eindtijd": "time_window_end",
    "tijdslot gecombineerd": "time_window_combined",
    "tijdslot": "time_window_combined",
    "niet leveren voor": "time_window_start",
    "niet leveren vóór": "time_window_start",
    "niet leveren na": "time_window_end",
    "service lostijd minuten": "service_time_minutes",
    "service lostijd min": "service_time_minutes",
    "lostijd": "service_time_minutes",
    "prioriteit": "priority",
    "europallets": "europallets",
    "ep": "europallets",
    "rolcontainers": "roll_containers",
    "rc": "roll_containers",
    "gewicht kg": "weight_kg",
    "gewicht": "weight_kg",
    "volume m3": "volume_m3",
    "volume m": "volume_m3",
    "productnaam": "product_name",
    "product omschrijving": "product_name",
    "aantal": "quantity",
    "afspraak verplicht": "appointment_required",
    "max vertraging toegestaan": "max_delay_minutes",
    "instructies chauffeur": "driver_instructions",
    "installatie vereist": "installation_required",
}


# v2.0 ultra smart mapping: broad synonym/typo map for logistics CSVs.
# These are deliberately explicit so bad ERP column names still feel AI-recognised.
DIRECT_HEADER_MAP.update({
    # dimensions cm/mm + common typos
    "lengte cm":"length_cm", "lengtecm":"length_cm", "lengte c m":"length_cm", "lengte_cm":"length_cm", "lengte in cm":"length_cm", "l cm":"length_cm", "l_cm":"length_cm", "maat l":"length_cm", "maat lengte":"length_cm", "afm l":"length_cm", "afmeting l":"length_cm", "dim l":"length_cm", "dim length":"length_cm", "pakket lengte":"length_cm", "colli lengte":"length_cm", "product lengte":"length_cm", "lenght":"length_cm", "lenght cm":"length_cm", "lenght_cm":"length_cm", "lengteh":"length_cm", "lengt":"length_cm", "len":"length_cm",
    "breedte cm":"width_cm", "breedtecm":"width_cm", "breedte_cm":"width_cm", "breedte in cm":"width_cm", "b cm":"width_cm", "b_cm":"width_cm", "w cm":"width_cm", "w_cm":"width_cm", "maat b":"width_cm", "maat breedte":"width_cm", "afm b":"width_cm", "afmeting b":"width_cm", "dim b":"width_cm", "dim width":"width_cm", "pakket breedte":"width_cm", "colli breedte":"width_cm", "product breedte":"width_cm", "breete":"width_cm", "breete cm":"width_cm", "breedtte":"width_cm", "widht":"width_cm", "widht cm":"width_cm",
    "hoogte cm":"height_cm", "hoogtecm":"height_cm", "hoogte_cm":"height_cm", "hoogte in cm":"height_cm", "h cm":"height_cm", "h_cm":"height_cm", "maat h":"height_cm", "maat hoogte":"height_cm", "afm h":"height_cm", "afmeting h":"height_cm", "dim h":"height_cm", "dim height":"height_cm", "pakket hoogte":"height_cm", "colli hoogte":"height_cm", "product hoogte":"height_cm", "hoogteh":"height_cm", "heigth":"height_cm", "heigth cm":"height_cm",
    "lengte mm":"length_mm", "lengte_mm":"length_mm", "l mm":"length_mm", "l_mm":"length_mm", "breedte mm":"width_mm", "breedte_mm":"width_mm", "b mm":"width_mm", "w mm":"width_mm", "hoogte mm":"height_mm", "hoogte_mm":"height_mm", "h mm":"height_mm",
    # service/time common messy variants
    "service min":"service_time_minutes", "servicemin":"service_time_minutes", "service minuten":"service_time_minutes", "service_minutes":"service_time_minutes", "service tijd min":"service_time_minutes", "servce time":"service_time_minutes", "servcie time":"service_time_minutes", "handelingstijd":"service_time_minutes", "handling min":"service_time_minutes", "lostijd min":"service_time_minutes", "lostijd minuten":"service_time_minutes", "losminuten":"service_time_minutes", "stop tijd":"service_time_minutes", "stop minuten":"service_time_minutes", "montage minuten":"service_time_minutes", "montage_min":"service_time_minutes",
    # load units
    "euro pallets":"europallets", "euro pallet":"europallets", "euro_pallets":"europallets", "aantal ep":"europallets", "aantal europallets":"europallets", "pallet aantal":"europallets", "pallets aantal":"europallets", "palets":"europallets", "pallette":"europallets",
    "rol container":"roll_containers", "rol_container":"roll_containers", "rolcontainers aantal":"roll_containers", "aantal rolcontainers":"roll_containers", "rol cont":"roll_containers", "rolcont":"roll_containers", "roll cont":"roll_containers", "rollcontainers":"roll_containers", "rolko":"roll_containers",
    # address typos/ERP names
    "post code":"postal_code", "postkode":"postal_code", "postcode nl":"postal_code", "pc4":"postal_code", "zip code":"postal_code", "aflever postcode":"postal_code", "delivery postcode":"postal_code",
    "straatnaam":"street", "aflever straat":"street", "delivery street":"street", "straat naam":"street", "strat":"street", "straaat":"street",
    "huis nr":"house_number", "huis no":"house_number", "huisnummernr":"house_number", "hnr":"house_number", "h nr":"house_number", "nummer":"house_number",
    "plaatsnaam":"city", "aflever plaats":"city", "afleverplaats":"city", "delivery city":"city", "stad":"city", "city name":"city", "woonplaatsnaam":"city",
    "klant naam":"customer_name", "customername":"customer_name", "debiteur naam":"customer_name", "aflever naam":"customer_name", "ontvanger":"customer_name", "receiver":"customer_name", "ship to name":"customer_name",
    "order nr":"order_number", "ordernr":"order_number", "order no":"order_number", "orderid":"order_number", "order id":"order_number", "bon nr":"order_number", "bonnr":"order_number", "referentie nr":"order_number",
})

def direct_header_field(header: str):
    h = norm(header)
    if h in DIRECT_HEADER_MAP:
        return DIRECT_HEADER_MAP[h]
    # token rescue for names like lengte-cm-1, breedte_cm_item, etc.
    toks = header_tokens(header) if 'header_tokens' in globals() else set(h.split())
    if ("lengte" in toks or "length" in toks or "lenght" in toks or h in ["l"]) and ("cm" in toks or h.endswith("cm")):
        return "length_cm"
    if ("breedte" in toks or "width" in toks or "widht" in toks or "breete" in toks or h in ["b","w"]) and ("cm" in toks or h.endswith("cm")):
        return "width_cm"
    if ("hoogte" in toks or "height" in toks or "heigth" in toks or h in ["h"]) and ("cm" in toks or h.endswith("cm")):
        return "height_cm"
    if ("lengte" in toks or "length" in toks or h in ["l"]) and ("mm" in toks or h.endswith("mm")):
        return "length_mm"
    if ("breedte" in toks or "width" in toks or h in ["b","w"]) and ("mm" in toks or h.endswith("mm")):
        return "width_mm"
    if ("hoogte" in toks or "height" in toks or h in ["h"]) and ("mm" in toks or h.endswith("mm")):
        return "height_mm"
    return None

def ratio(a: str, b: str) -> float:
    if not a or not b:
        return 0.0
    if a == b:
        return 1.0
    if a in b or b in a:
        return 0.88
    return SequenceMatcher(None, a, b).ratio()

postcode_re = re.compile(r"^[1-9][0-9]{3}\s?[A-Z]{2}$", re.I)
time_re = re.compile(r"\b([01]?\d|2[0-3])[:.][0-5]\d\b")
time_window_re = re.compile(r"([01]?\d|2[0-3])[:.][0-5]\d\s*[-–]\s*([01]?\d|2[0-3])[:.][0-5]\d")
email_re = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
phone_re = re.compile(r"^(\+31|0031|0)[0-9\s\-]{8,}$")

def value_signal(values: List[Any], field: Dict[str, Any]) -> float:
    vals = [str(v).strip() for v in values if str(v).strip()][:25]
    if not vals:
        return 0.0
    t = field.get("type")
    hits = 0
    for v in vals:
        if t == "postcode_nl" and postcode_re.match(v): hits += 1
        elif t == "email" and email_re.match(v): hits += 1
        elif t == "phone" and phone_re.match(v): hits += 1
        elif t == "time" and time_re.search(v): hits += 1
        elif t == "time_window" and time_window_re.search(v): hits += 1
        elif t in ("integer","number"):
            x = v.lower().replace("kg","").replace("m3","").replace("m³","").replace(",",".").strip()
            try: float(re.sub(r"[^0-9.\-]", "", x)); hits += 1
            except Exception: pass
        elif t == "date":
            if re.search(r"\b\d{1,2}[-/]\d{1,2}[-/]\d{2,4}\b", v) or re.search(r"\b\d{4}-\d{1,2}-\d{1,2}\b", v): hits += 1
        elif t == "boolean" and norm(v) in ["ja","nee","yes","no","true","false","1","0","y","n"]: hits += 1
    return min(1.0, hits / max(1, len(vals)))

def score_field(header: str, samples: List[Any], field: Dict[str, Any]) -> float:
    h = norm(header)
    direct = direct_header_field(header)
    if direct:
        return 1.0 if field.get("id") == direct else 0.0
    aliases = [field["label"], field["id"]] + field.get("aliases", [])
    alias_norms = [norm(a) for a in aliases]
    header_score = max(ratio(h, a) for a in alias_norms)
    value_score = value_signal(samples, field)

    # 1) Header is king. If the CSV column literally says "Klantnaam", "Postcode",
    # "Leverdatum" etc., it must auto-map even if the value type is generic text.
    if h in alias_norms:
        return 1.0
    if header_score >= 0.86:
        return round(max(0.92, header_score), 4)

    # 2) For known-ish headers, let value patterns help a little, but never let a
    # generic numeric value hijack columns like Huisnummer -> Volume/Hoogte.
    if header_score >= 0.62:
        return round((header_score * 0.9) + (value_score * 0.1), 4)

    # 3) Only use value-pattern rescue for distinctive fields such as postcode, email,
    # phone, time/date/time-window. Numeric-only columns are too ambiguous.
    distinctive = field.get("type") in ["postcode_nl", "email", "phone", "time", "time_window", "date", "boolean"]
    if distinctive and value_score > 0.85 and header_score > 0.28:
        return 0.86

    return round((header_score * 0.82) + (value_score * 0.18), 4)

def header_tokens(s: str) -> set:
    return set(x for x in re.split(r"[^a-z0-9]+", norm(s)) if x)

AI_FIELD_HINTS = {
    "delivery_address_full": ["adres", "aflever", "ship", "straat", "address", "locatie"],
    "street": ["straat", "street", "road"],
    "house_number": ["huis", "nummer", "nr", "house", "number"],
    "postal_code": ["postcode", "post", "zip", "pc"],
    "city": ["plaats", "stad", "city", "woonplaats", "gemeente"],
    "province": ["provincie", "province", "regio", "state", "gebied"],
    "delivery_date": ["lever", "delivery", "datum", "date", "planning", "bezorg"],
    "time_window_start": ["start", "vanaf", "van", "from"],
    "time_window_end": ["eind", "tot", "until", "end"],
    "service_time_minutes": ["service", "lostijd", "stop", "montage", "handling", "kostijd"],
    "europallets": ["pallet", "ep", "epal"],
    "roll_containers": ["rol", "container", "rc", "roll"],
    "weight_kg": ["gewicht", "weight", "kg"],
    "volume_m3": ["volume", "m3", "kuub", "cbm"],
    "length_cm": ["lengte", "length", "lenght", "len", "maat", "afmeting", "dim", "pakket", "colli", "cm"],
    "width_cm": ["breedte", "width", "widht", "breete", "maat", "afmeting", "dim", "pakket", "colli", "cm"],
    "height_cm": ["hoogte", "height", "heigth", "maat", "afmeting", "dim", "pakket", "colli", "cm"],
    "length_mm": ["lengte", "length", "len", "mm"],
    "width_mm": ["breedte", "width", "mm"],
    "height_mm": ["hoogte", "height", "mm"],
}

def semantic_bonus(header: str, field: Dict[str, Any], samples: List[Any]) -> float:
    h = norm(header)
    toks = header_tokens(header)
    fid = field.get("id")
    bonus = 0.0
    for hint in AI_FIELD_HINTS.get(fid, []):
        nh = norm(hint)
        if nh in h or nh in toks:
            bonus += 0.08
    vals = [str(v).strip() for v in samples if str(v).strip()][:20]
    joined = " ".join(vals).lower()
    if fid == "province" and any(p.lower() in joined for p in ["noord-holland","zuid-holland","utrecht","gelderland","noord-brabant","limburg","zeeland","overijssel","flevoland","groningen","friesland","drenthe"]):
        bonus += 0.28
    if fid == "city" and any(c.lower() in joined for c in ["amsterdam","rotterdam","den haag","utrecht","eindhoven","groningen","tilburg","almere","breda","nijmegen","arnhem"]):
        bonus += 0.16
    if fid == "delivery_address_full" and any(re.search(r"\b\d{1,4}\s?[a-z]?\b", v, re.I) and len(v.split()) >= 2 for v in vals):
        bonus += 0.18
    if fid == "house_number" and vals and sum(bool(re.match(r"^\d{1,5}[a-zA-Z]?$", v)) for v in vals) / max(1,len(vals)) > .65:
        bonus += 0.22
    if fid == "service_time_minutes" and vals:
        nums=[]
        for v in vals:
            try: nums.append(float(re.sub(r"[^0-9.,]", "", v).replace(",",".")))
            except: pass
        if nums and max(nums) <= 240 and sum(1 for n in nums if 1 <= n <= 180)/len(nums) > .65:
            bonus += 0.12
    if fid in ["length_cm","width_cm","height_cm"] and vals:
        nums=[]
        for v in vals:
            try: nums.append(float(re.sub(r"[^0-9.,]", "", v).replace(",",".")))
            except: pass
        # Logistics dimensions in cm are usually 1-400 and often appear as a length/width/height trio.
        if nums and sum(1 for n in nums if 1 <= n <= 400) / max(1,len(nums)) > .75:
            bonus += 0.18
        if "cm" in h or h.endswith("cm"):
            bonus += 0.16
    if fid in ["length_mm","width_mm","height_mm"] and vals:
        nums=[]
        for v in vals:
            try: nums.append(float(re.sub(r"[^0-9.,]", "", v).replace(",",".")))
            except: pass
        if nums and sum(1 for n in nums if 10 <= n <= 4000) / max(1,len(nums)) > .75:
            bonus += 0.12
        if "mm" in h or h.endswith("mm"):
            bonus += 0.16
    return min(0.45, bonus)

def detect_mapping(headers: List[str], rows: List[Dict[str, Any]]):
    """AI-like Smart Detect: combines exact header rules, fuzzy aliases, semantic hints,
    sample-value recognition, conflict resolution, and reason text for the UI.
    """
    raw = []
    for header in headers:
        samples = [r.get(header, "") for r in rows[:50]]
        candidates = []
        for f in FIELD_CATALOG:
            base = score_field(header, samples, f)
            s = min(1.0, base + semantic_bonus(header, f, samples))
            if s > 0.25:
                reasons=[]
                if direct_header_field(header)==f["id"]: reasons.append("exacte kolomnaam")
                if base >= .86: reasons.append("sterke naam-match")
                if value_signal(samples, f) > .65: reasons.append("waarden lijken passend")
                if semantic_bonus(header, f, samples) > .08: reasons.append("semantische context")
                candidates.append({"field_id": f["id"], "label": f["label"], "category": f["category"], "score": int(round(s*100)), "type": f.get("type"), "reasons": reasons or ["waarschijnlijk op basis van patroon"]})
        candidates.sort(key=lambda x: x["score"], reverse=True)
        raw.append({"column": header, "samples": samples[:5], "candidates": candidates[:8]})

    # Resolve duplicate fields: only the highest score gets automatic ownership.
    winners = {}
    for item in raw:
        best = item["candidates"][0] if item["candidates"] else None
        if best:
            fid=best["field_id"]
            if fid not in winners or best["score"] > winners[fid]["score"]:
                winners[fid] = {"column": item["column"], "score": best["score"]}

    results=[]
    for item in raw:
        best = item["candidates"][0] if item["candidates"] else None
        if best and winners.get(best["field_id"],{}).get("column") != item["column"]:
            # duplicate: demote to review and surface next best if available
            best = next((c for c in item["candidates"][1:] if winners.get(c["field_id"],{}).get("column") == item["column"] or c["field_id"] not in winners), best)
        if best and best["score"] >= 86:
            status="auto"
        elif best and best["score"] >= 62:
            status="review"
        else:
            status="unmapped"
        confidence_label = "zeker" if best and best["score"]>=92 else "sterk" if best and best["score"]>=86 else "check" if best and best["score"]>=62 else "geen match"
        results.append({"column": item["column"], "samples": item["samples"], "best": best, "status": status, "confidence_label": confidence_label, "candidates": item["candidates"][:6]})
    return results

# ----------------------------
# API models
# ----------------------------
class RouteRequest(BaseModel):
    coordinates: List[List[float]]

class MatrixRequest(BaseModel):
    coordinates: List[List[float]]

class DetectMappingRequest(BaseModel):
    headers: List[str]
    rows: List[Dict[str, Any]] = []

class CommitImportRequest(BaseModel):
    rows: List[Dict[str, Any]]
    mapping: Dict[str, str]
    template_name: Optional[str] = None


# ----------------------------
# PDOK/BAG geocoding helpers
# ----------------------------
class GeocodeAddressRequest(BaseModel):
    query: Optional[str] = None
    street: Optional[str] = None
    house_number: Optional[str] = None
    postal_code: Optional[str] = None
    city: Optional[str] = None

class GeocodeQueueRequest(BaseModel):
    limit: int = 250
    overwrite: bool = False


def has_gps(order: Dict[str, Any]) -> bool:
    return order.get("latitude") not in [None, ""] and order.get("longitude") not in [None, ""]

def has_address_for_geocode(order: Dict[str, Any]) -> bool:
    q = build_address_query(order)
    city = str(order.get("city") or "").strip()
    # Full address, street+city/postcode, or existing GPS is enough to proceed.
    return has_gps(order) or (len(q) >= 4 and bool(city or order.get("postal_code") or order.get("delivery_address")))

def refresh_order_status(order: Dict[str, Any]) -> Dict[str, Any]:
    """Single source of truth for Planning Queue readiness.

    Important: a Dutch address may be ready for routing after PDOK/BAG has resolved
    latitude/longitude even when the original CSV did not contain a postcode. PDOK
    sometimes returns postal_code as null too, so postal_code must not keep a
    geocoded order stuck as incomplete.
    """
    missing = []
    for f in ["order_number", "customer_name", "delivery_date"]:
        if not order.get(f):
            missing.append(f)
    # Address can be complete in several ways: CSV full address, street+city/postcode,
    # or already geocoded GPS. Missing postcode alone must never block geocoding.
    if not has_gps(order) and not has_address_for_geocode(order):
        missing.append("address_for_geocode")
    if not has_gps(order):
        missing.append("gps")
    order["missing"] = missing
    order["status"] = "ready" if not missing else "incomplete"
    return order

def build_address_query(order_or_req: Dict[str, Any]) -> str:
    direct = str(order_or_req.get("query") or order_or_req.get("delivery_address") or "").strip()
    street = str(order_or_req.get("street") or "").strip()
    house = str(order_or_req.get("house_number") or "").strip()
    postal = str(order_or_req.get("postal_code") or "").strip()
    city = str(order_or_req.get("city") or "").strip()
    if direct and (postal or city):
        return f"{direct}, {postal} {city}".strip()
    if direct:
        return direct
    return " ".join(x for x in [street, house, postal, city] if x).strip()

def parse_pdok_point(centroide: str):
    # PDOK returns strings like POINT(4.9041 52.3676) = lon lat
    if not centroide:
        return None
    m = re.search(r"POINT\(([-0-9.]+)\s+([-0-9.]+)\)", centroide)
    if not m:
        return None
    return float(m.group(1)), float(m.group(2))

def pdok_confidence(doc: Dict[str, Any], query: str) -> int:
    score = 72
    q = norm(query)
    label = norm(doc.get("weergavenaam") or doc.get("straatnaam") or "")
    if q and label:
        score = max(score, int(ratio(q, label) * 100))
    if doc.get("postcode") and str(doc.get("postcode")).replace(" ", "").upper() in query.replace(" ", "").upper():
        score += 8
    if doc.get("huisnummer") and str(doc.get("huisnummer")) in query:
        score += 6
    if doc.get("type") in ["adres", "nummeraanduiding", "verblijfsobject"]:
        score += 4
    return min(99, max(35, score))

async def geocode_pdok(query: str):
    if not query or len(query.strip()) < 4:
        return {"matched": False, "query": query, "error": "Te weinig adresinformatie"}
    url = "https://api.pdok.nl/bzk/locatieserver/search/v3_1/free"
    params = {"q": query, "rows": 5, "fq": "type:(adres OR nummeraanduiding OR verblijfsobject OR weg)", "fl": "id,weergavenaam,straatnaam,huisnummer,postcode,woonplaatsnaam,gemeentenaam,type,centroide_ll"}
    try:
        async with httpx.AsyncClient(timeout=12.0) as client:
            r = await client.get(url, params=params)
            r.raise_for_status()
            docs = r.json().get("response", {}).get("docs", [])
    except Exception as e:
        return {"matched": False, "query": query, "error": f"PDOK/BAG niet bereikbaar: {e}"}
    candidates = []
    for d in docs:
        pt = parse_pdok_point(d.get("centroide_ll", ""))
        if not pt:
            continue
        candidates.append({
            "label": d.get("weergavenaam") or "",
            "street": d.get("straatnaam"),
            "house_number": d.get("huisnummer"),
            "postal_code": d.get("postcode"),
            "city": d.get("woonplaatsnaam"),
            "municipality": d.get("gemeentenaam"),
            "type": d.get("type"),
            "longitude": pt[0],
            "latitude": pt[1],
            "confidence": pdok_confidence(d, query),
        })
    candidates.sort(key=lambda x: x["confidence"], reverse=True)
    if not candidates:
        return {"matched": False, "query": query, "candidates": [], "error": "Geen PDOK-match gevonden"}
    best = candidates[0]
    return {"matched": best["confidence"] >= 70, "query": query, "best": best, "candidates": candidates[:5]}

# ----------------------------
# OSRM
# ----------------------------
@app.get("/api/health")
def health():
    return {"ok": True, "app": "AlgoRoute", "version": APP_VERSION, "time": datetime.now(timezone.utc).isoformat()}

async def osrm_probe():
    try:
        async with httpx.AsyncClient(timeout=2.5) as client:
            r = await client.get(f"{OSRM_URL}/route/v1/driving/5.2913,52.1326;5.2920,52.1330", params={"overview":"false"})
            return r.status_code == 200, None if r.status_code == 200 else f"OSRM HTTP {r.status_code}"
    except Exception as e:
        return False, str(e)

@app.get("/api/routing/status")
async def routing_status():
    ok, err = await osrm_probe()
    return {"available": ok, "url": OSRM_URL, "message": "OSRM Nederland is actief" if ok else f"OSRM nog niet actief: {err}. Run scripts/setup_osrm_nl.sh op de VPS."}

@app.post("/api/routing/route")
async def routing_route(req: RouteRequest):
    if len(req.coordinates) < 2:
        raise HTTPException(400, "Minimaal twee coördinaten nodig")
    coord_str = ";".join([f"{c[0]},{c[1]}" for c in req.coordinates])
    try:
        async with httpx.AsyncClient(timeout=25) as client:
            r = await client.get(f"{OSRM_URL}/route/v1/driving/{coord_str}", params={"overview":"full","geometries":"geojson","steps":"false"})
            if r.status_code != 200:
                raise HTTPException(503, f"OSRM route error {r.status_code}: {r.text[:180]}")
            data = r.json(); route = data["routes"][0]
            return {"ok": True, "distance_m": route["distance"], "duration_s": route["duration"], "geometry": route["geometry"]}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(503, f"OSRM niet bereikbaar: {e}")

@app.post("/api/routing/matrix")
async def routing_matrix(req: MatrixRequest):
    if len(req.coordinates) < 2:
        raise HTTPException(400, "Minimaal twee coördinaten nodig")
    coord_str = ";".join([f"{c[0]},{c[1]}" for c in req.coordinates])
    try:
        async with httpx.AsyncClient(timeout=35) as client:
            r = await client.get(f"{OSRM_URL}/table/v1/driving/{coord_str}", params={"annotations":"duration,distance"})
            if r.status_code != 200:
                raise HTTPException(503, f"OSRM matrix error {r.status_code}: {r.text[:180]}")
            data = r.json()
            return {"ok": True, "durations": data.get("durations"), "distances": data.get("distances")}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(503, f"OSRM niet bereikbaar: {e}")


# ----------------------------
# PDOK/BAG geocoding endpoints
# ----------------------------
@app.get("/api/geocode/status")
def geocode_status():
    return {"provider": "PDOK/BAG Locatieserver", "country": "NL", "status": "configured", "note": "Gebruikt live PDOK/BAG Locatieserver voor Nederlandse adressen zodra de VPS internettoegang heeft."}

@app.post("/api/geocode/address")
async def geocode_address(req: GeocodeAddressRequest):
    payload = req.model_dump()
    q = build_address_query(payload)
    return await geocode_pdok(q)

async def geocode_orders_in_memory(orders: List[Dict[str, Any]], limit: int = 500, overwrite: bool = False) -> Dict[str, Any]:
    """Geocode queue orders in memory and update readiness. Used by both the
    PDOK button and Optimize safety-net, so users cannot get stuck between
    Mapping -> Queue -> Optimize.
    """
    results = []
    updated = 0
    unresolved = 0
    checked = 0
    for order in orders[:max(1, limit)]:
        refresh_order_status(order)
        already = has_gps(order)
        if already and not overwrite:
            results.append({"order_id": order.get("id"), "order_number": order.get("order_number"), "skipped": True, "reason": "Heeft al GPS", "status": order.get("status"), "missing": order.get("missing", [])})
            continue
        if not has_address_for_geocode(order):
            unresolved += 1
            refresh_order_status(order)
            results.append({"order_id": order.get("id"), "order_number": order.get("order_number"), "skipped": True, "reason": "Te weinig adresinformatie", "status": order.get("status"), "missing": order.get("missing", [])})
            continue
        q = build_address_query(order)
        checked += 1
        res = await geocode_pdok(q)
        if res.get("matched") and res.get("best"):
            best = res["best"]
            order["latitude"] = best["latitude"]
            order["longitude"] = best["longitude"]
            order["geocode"] = {"provider": "PDOK/BAG", "confidence": best["confidence"], "label": best["label"], "city": best.get("city"), "postal_code": best.get("postal_code"), "query": q}
            if not order.get("postal_code") and best.get("postal_code"):
                order["postal_code"] = best.get("postal_code")
            if not order.get("city") and best.get("city"):
                order["city"] = best.get("city")
            refresh_order_status(order)
            updated += 1
        else:
            order["geocode"] = {"provider": "PDOK/BAG", "confidence": 0, "error": res.get("error"), "query": q}
            refresh_order_status(order)
            unresolved += 1
        results.append({"order_id": order.get("id"), "order_number": order.get("order_number"), "query": q, "result": res, "status": order.get("status"), "missing": order.get("missing", [])})
    return {"updated": updated, "unresolved": unresolved, "checked": checked, "total_checked": len(results), "results": results[:50]}

@app.post("/api/geocode/queue")
async def geocode_queue(req: GeocodeQueueRequest):
    orders = load_json("orders.json", [])
    summary = await geocode_orders_in_memory(orders, limit=req.limit, overwrite=req.overwrite)
    save_json("orders.json", orders)
    ready = len([o for o in orders if refresh_order_status(o).get("status") == "ready"])
    return {"ok": True, **summary, "ready": ready, "incomplete": len(orders)-ready}

# ----------------------------
# Core data
# ----------------------------
@app.get("/api/map/state")
def map_state():
    return {"center": [5.2913, 52.1326], "zoom": 6.9, "vehicles": load_json("vehicles.json", []), "routes": load_json("routes.json", []), "events": load_json("events.json", []), "traffic_segments": load_json("traffic_segments.json", []), "message": "Geen dummydata. Kaart vult zodra routes/voertuigen bestaan."}


@app.get("/api/rdw/lookup")
async def rdw_lookup(kenteken: str):
    plate = re.sub(r"[^A-Za-z0-9]", "", kenteken or "").upper()
    if not plate:
        raise HTTPException(400, "Kenteken ontbreekt")
    url = "https://opendata.rdw.nl/resource/m9d7-ebf2.json"
    try:
        async with httpx.AsyncClient(timeout=8.0) as client:
            resp = await client.get(url, params={"kenteken": plate})
            resp.raise_for_status()
            data = resp.json()
    except Exception as exc:
        return {"ok": False, "found": False, "error": "RDW lookup tijdelijk niet beschikbaar", "detail": str(exc)[:180]}
    if not data:
        return {"ok": True, "found": False, "kenteken": plate}
    v = data[0]
    return {
        "ok": True,
        "found": True,
        "kenteken": v.get("kenteken", plate),
        "brand": v.get("merk"),
        "model": v.get("handelsbenaming"),
        "vehicle_type": v.get("voertuigsoort") or v.get("inrichting"),
        "inrichting": v.get("inrichting"),
        "massa_ledig_voertuig": v.get("massa_ledig_voertuig"),
        "massa_rijklaar": v.get("massa_rijklaar"),
        "toegestane_maximum_massa_voertuig": v.get("toegestane_maximum_massa_voertuig"),
        "lengte_voertuig": v.get("lengte"),
        "breedte_voertuig": v.get("breedte"),
        "hoogte_voertuig": v.get("hoogte_voertuig"),
        "laadruimte_note": "RDW geeft meestal geen betrouwbare laadruimte-afmetingen. Gebruik RDW als startpunt en vul het AlgoRoute laadprofiel aan.",
        "source": "RDW Open Data m9d7-ebf2"
    }

@app.get("/api/vehicles")
def vehicles(): return load_json("vehicles.json", [])

@app.post("/api/vehicles")
def create_vehicle(payload: dict):
    vehicles = load_json("vehicles.json", [])
    payload.setdefault("id", f"vehicle_{len(vehicles)+1}")
    payload["load_profile"] = vehicle_load_profile(payload)
    vehicles.append(payload); save_json("vehicles.json", vehicles)
    return {"ok": True, "vehicle": payload}

@app.get("/api/settings")
def get_settings():
    return load_settings()

@app.post("/api/settings")
def update_settings(payload: dict):
    settings = load_settings()
    for key in ["max_route_hours", "default_service_time_minutes", "load_safety_margin_percent", "route_strategy", "default_depot", "depot_name", "depot_address", "depot_postal_code", "depot_city", "return_to_depot"]:
        if key in payload:
            settings[key] = payload[key]
    save_json("settings.json", settings)
    return {"ok": True, "settings": settings}


@app.put("/api/vehicles/{vehicle_id}")
def update_vehicle(vehicle_id: str, payload: dict):
    vehicles = load_json("vehicles.json", [])
    for i, v in enumerate(vehicles):
        if str(v.get("id")) == vehicle_id:
            payload["id"] = vehicle_id
            merged = {**v, **payload}
            merged["load_profile"] = vehicle_load_profile(merged)
            vehicles[i] = merged
            save_json("vehicles.json", vehicles)
            return {"ok": True, "vehicle": vehicles[i]}
    raise HTTPException(404, "Voertuig niet gevonden")

@app.delete("/api/vehicles/{vehicle_id}")
def delete_vehicle(vehicle_id: str):
    vehicles = load_json("vehicles.json", [])
    new = [v for v in vehicles if str(v.get("id")) != vehicle_id]
    save_json("vehicles.json", new)
    return {"ok": True, "deleted": len(vehicles) - len(new)}

@app.get("/api/drivers")
def drivers(): return load_json("drivers.json", [])

@app.post("/api/drivers")
def create_driver(payload: dict):
    drivers = load_json("drivers.json", [])
    payload.setdefault("id", f"driver_{len(drivers)+1}")
    payload.setdefault("status", "available")
    drivers.append(payload); save_json("drivers.json", drivers)
    return {"ok": True, "driver": payload}

@app.put("/api/drivers/{driver_id}")
def update_driver(driver_id: str, payload: dict):
    drivers = load_json("drivers.json", [])
    for i, d in enumerate(drivers):
        if str(d.get("id")) == driver_id:
            payload["id"] = driver_id
            drivers[i] = {**d, **payload}
            save_json("drivers.json", drivers)
            return {"ok": True, "driver": drivers[i]}
    raise HTTPException(404, "Chauffeur niet gevonden")

@app.delete("/api/drivers/{driver_id}")
def delete_driver(driver_id: str):
    drivers = load_json("drivers.json", [])
    new = [d for d in drivers if str(d.get("id")) != driver_id]
    save_json("drivers.json", new)
    return {"ok": True, "deleted": len(drivers) - len(new)}

@app.post("/api/testdata/fleet")
def load_test_fleet():
    vehicles = [
        {"id":"veh_001","name":"Bus 01","license_plate":"V-123-AB","brand":"Mercedes-Benz","model":"Sprinter 319","vehicle_type":"bakwagen","status":"available","fuel_type":"diesel","europallet_capacity":8,"roll_container_capacity":10,"max_weight_kg":1250,"max_volume_m3":15},
        {"id":"veh_002","name":"Bus 02","license_plate":"V-456-CD","brand":"Volkswagen","model":"Crafter L4H3","vehicle_type":"bestelbus","status":"available","fuel_type":"diesel","europallet_capacity":6,"roll_container_capacity":8,"max_weight_kg":1100,"max_volume_m3":13},
        {"id":"veh_003","name":"EV 03","license_plate":"V-789-EF","brand":"Ford","model":"E-Transit","vehicle_type":"ev bestelbus","status":"available","fuel_type":"electric","europallet_capacity":5,"roll_container_capacity":7,"max_weight_kg":950,"max_volume_m3":11,"battery_capacity_kwh":68,"range_empty_km":260,"range_loaded_km":185,"current_soc_percent":92,"min_soc_percent":15},
        {"id":"veh_004","name":"Bakwagen 04","license_plate":"V-321-GH","brand":"Iveco","model":"Daily 35C18","vehicle_type":"bakwagen laadklep","status":"maintenance","maintenance_until":"2026-07-05","fuel_type":"diesel","europallet_capacity":10,"roll_container_capacity":12,"max_weight_kg":1600,"max_volume_m3":18},
        {"id":"veh_005","name":"EV 05","license_plate":"V-654-JK","brand":"Mercedes-Benz","model":"eSprinter","vehicle_type":"ev bestelbus","status":"available","fuel_type":"electric","europallet_capacity":4,"roll_container_capacity":6,"max_weight_kg":850,"max_volume_m3":10,"battery_capacity_kwh":81,"range_empty_km":300,"range_loaded_km":210,"current_soc_percent":76,"min_soc_percent":18}
    ]
    drivers = [
        {"id":"drv_001","name":"Milan de Vries","phone":"+31610000001","email":"milan@example.nl","status":"available","license_type":"B","assigned_vehicle_id":"veh_001","app_access":"active"},
        {"id":"drv_002","name":"Jan de Groot","phone":"+31610000002","email":"jan@example.nl","status":"available","license_type":"B","assigned_vehicle_id":"veh_002","app_access":"active"},
        {"id":"drv_003","name":"Pieter Smit","phone":"+31610000003","email":"pieter@example.nl","status":"available","license_type":"B","assigned_vehicle_id":"veh_003","app_access":"active"},
        {"id":"drv_004","name":"Marco Jansen","phone":"+31610000004","email":"marco@example.nl","status":"unavailable","license_type":"C1","assigned_vehicle_id":"veh_004","app_access":"invited"},
        {"id":"drv_005","name":"Tom Bakker","phone":"+31610000005","email":"tom@example.nl","status":"available","license_type":"B","assigned_vehicle_id":"veh_005","app_access":"active"}
    ]
    save_json("vehicles.json", vehicles)
    save_json("drivers.json", drivers)
    return {"ok": True, "vehicles": len(vehicles), "drivers": len(drivers), "note": "Test-vloot geladen. Dit gebeurt alleen handmatig via deze knop/API."}

@app.get("/api/routes")
def routes(): return load_json("routes.json", [])

@app.get("/api/planning/queue")
def planning_queue():
    orders = load_json("orders.json", [])
    changed = False
    for o in orders:
        before = (o.get("status"), tuple(o.get("missing", [])))
        refresh_order_status(o)
        if before != (o.get("status"), tuple(o.get("missing", []))):
            changed = True
    if changed:
        save_json("orders.json", orders)
    gps = len([o for o in orders if has_gps(o)])
    ready = len([o for o in orders if o.get("status") == "ready"])
    return {"version": APP_VERSION, "orders": orders, "summary": {"count": len(orders), "ready": ready, "incomplete": len(orders)-ready, "gps": gps, "needs_geocode": len(orders)-gps}}

@app.get("/api/planning/agenda")
def planning_agenda():
    orders = load_json("orders.json", [])
    routes = load_json("routes.json", [])
    days = {}
    for o in orders:
        d = str(o.get("delivery_date") or "zonder datum")
        days.setdefault(d, {"delivery_date": d, "orders": 0, "ready": 0, "gps": 0, "routes": 0, "stops_planned": 0, "unplanned": 0})
        days[d]["orders"] += 1
        refresh_order_status(o)
        if o.get("status") == "ready": days[d]["ready"] += 1
        if has_gps(o): days[d]["gps"] += 1
    planned_ids = set()
    for r in routes:
        d = str(r.get("delivery_date") or r.get("date_label") or "zonder datum")
        days.setdefault(d, {"delivery_date": d, "orders": 0, "ready": 0, "gps": 0, "routes": 0, "stops_planned": 0, "unplanned": 0})
        days[d]["routes"] += 1
        days[d]["stops_planned"] += len(r.get("stops", []))
        for s in r.get("stops", []): planned_ids.add(str(s.get("id") or s.get("order_id")))
    for o in orders:
        d = str(o.get("delivery_date") or "zonder datum")
        if str(o.get("id")) not in planned_ids:
            days[d]["unplanned"] += 1
    def key(x):
        try: return datetime.fromisoformat(x["delivery_date"]).date().isoformat()
        except Exception: return "9999-99-99" + x["delivery_date"]
    return {"ok": True, "days": sorted(days.values(), key=key)}

@app.post("/api/planning/board/move-order-date")
def move_order_date(payload: dict):
    order_id = str(payload.get("order_id") or "")
    new_date = str(payload.get("delivery_date") or "").strip()
    if not order_id or not new_date:
        return {"ok": False, "reason": "order_id en delivery_date zijn verplicht"}
    orders = load_json("orders.json", [])
    changed = False
    for o in orders:
        if str(o.get("id")) == order_id:
            o["delivery_date"] = new_date
            o["status_note"] = "Leverdatum handmatig aangepast in Planning Agenda"
            refresh_order_status(o)
            changed = True
    save_json("orders.json", orders)
    return {"ok": changed, "delivery_date": new_date}

# ----------------------------
# Full import/mapping endpoints
# ----------------------------
@app.get("/api/import/fields")
def import_fields():
    cats = []
    for cat in sorted(set(f["category"] for f in FIELD_CATALOG)):
        cats.append({"category": cat, "fields": [f for f in FIELD_CATALOG if f["category"] == cat]})
    return {"version": APP_VERSION, "required_fields": REQUIRED_FIELDS, "address_rule": "delivery_address_full OR street+city OR street+postal_code OR latitude+longitude", "categories": cats, "fields": FIELD_CATALOG}

@app.post("/api/import/detect")
def import_detect(req: DetectMappingRequest):
    return {"ok": True, "detections": detect_mapping(req.headers, req.rows), "required_fields": REQUIRED_FIELDS, "address_rule": "delivery_address_full OR street+city OR street+postal_code OR latitude+longitude"}

@app.get("/api/import/templates")
def get_templates():
    return {"templates": load_json("mapping_templates.json", [])}

@app.post("/api/import/templates")
def save_template(payload: dict):
    templates = load_json("mapping_templates.json", [])
    payload.setdefault("id", f"template_{len(templates)+1}")
    payload["updated_at"] = datetime.now(timezone.utc).isoformat()
    templates = [t for t in templates if t.get("id") != payload["id"] and t.get("name") != payload.get("name")]
    templates.append(payload)
    save_json("mapping_templates.json", templates)
    return {"ok": True, "template": payload}

def parse_bool(v):
    s = norm(v)
    if s in ["ja","yes","true","1","y","waar"]: return True
    if s in ["nee","no","false","0","n","onwaar"]: return False
    return None

def parse_number(v, default=0):
    if v is None: return default
    s = str(v).replace(",", ".")
    s = re.sub(r"[^0-9.\-]", "", s)
    try: return float(s) if s not in ["", ".", "-"] else default
    except Exception: return default

def normalize_order(row: Dict[str, Any], mapping: Dict[str, str], idx: int):
    out = {"id": f"order_{int(datetime.now().timestamp())}_{idx}", "status": "ready", "raw": row}
    reverse = {field: col for col, field in mapping.items() if field}
    def val(fid, default=""):
        col = reverse.get(fid)
        return row.get(col, default) if col is not None else default
    out["order_number"] = str(val("order_number", f"IMPORT-{idx+1}")).strip() or f"IMPORT-{idx+1}"
    out["customer_name"] = str(val("customer_name", "")).strip()
    out["delivery_address"] = str(val("delivery_address_full", "")).strip()
    street = str(val("street", "")).strip(); house = str(val("house_number", "")).strip()
    if not out["delivery_address"] and (street or house): out["delivery_address"] = f"{street} {house}".strip()
    out["postal_code"] = str(val("postal_code", "")).strip().upper()
    out["city"] = str(val("city", "")).strip()
    out["province"] = str(val("province", "")).strip()
    out["delivery_date"] = str(val("delivery_date", "")).strip()
    tw = str(val("time_window_combined", "")).strip()
    out["time_window_start"] = str(val("time_window_start", "")).strip()
    out["time_window_end"] = str(val("time_window_end", "")).strip()
    m = time_window_re.search(tw)
    if m and not out["time_window_start"] and not out["time_window_end"]:
        parts = re.findall(r"([01]?\d|2[0-3])[:.][0-5]\d", tw)
        if len(parts) >= 2:
            times = re.findall(r"\b(?:[01]?\d|2[0-3])[:.][0-5]\d\b", tw.replace('.',':'))
            out["time_window_start"], out["time_window_end"] = times[0], times[1]
    out["service_time_minutes"] = int(parse_number(val("service_time_minutes", 15), 15))
    out["weight_kg"] = parse_number(val("weight_kg", 0), 0) or (parse_number(val("weight_g", 0), 0) / 1000)
    out["volume_m3"] = parse_number(val("volume_m3", 0), 0)
    out["length_cm"] = parse_number(val("length_cm", 0), 0)
    out["width_cm"] = parse_number(val("width_cm", 0), 0)
    out["height_cm"] = parse_number(val("height_cm", 0), 0)
    if not out["length_cm"] and parse_number(val("length_mm", 0), 0): out["length_cm"] = parse_number(val("length_mm", 0), 0) / 10
    if not out["width_cm"] and parse_number(val("width_mm", 0), 0): out["width_cm"] = parse_number(val("width_mm", 0), 0) / 10
    if not out["height_cm"] and parse_number(val("height_mm", 0), 0): out["height_cm"] = parse_number(val("height_mm", 0), 0) / 10
    if not out["volume_m3"] and out["length_cm"] and out["width_cm"] and out["height_cm"]:
        out["volume_m3"] = round((out["length_cm"] * out["width_cm"] * out["height_cm"]) / 1000000, 4)
    out["europallets"] = int(parse_number(val("europallets", 0), 0))
    out["roll_containers"] = int(parse_number(val("roll_containers", 0), 0))
    out["priority"] = int(parse_number(val("priority", 0), 0))
    lat, lng = parse_number(val("latitude", None), None), parse_number(val("longitude", None), None)
    if lat is not None and lng is not None:
        out["latitude"], out["longitude"] = lat, lng
    refresh_order_status(out)
    return out

@app.post("/api/import/commit")
async def import_commit(req: CommitImportRequest):
    # Safety net: if the frontend mapping is empty/incomplete, auto-map server-side.
    mapping = dict(req.mapping or {})
    if req.rows:
        headers = list(req.rows[0].keys())
        # Exact known headers always override fuzzy/frontend mapping. This is deliberate:
        # a bad dropdown selection from the browser must not create IMPORT-1 incomplete orders.
        for col in headers:
            direct = direct_header_field(col)
            if direct:
                mapping[col] = direct
        detections = detect_mapping(headers, req.rows[:50])
        for d in detections:
            best = d.get("best") or {}
            if best.get("score", 0) >= 75 and not mapping.get(d["column"]):
                mapping[d["column"]] = best.get("field_id")

    normalized = [normalize_order(row, mapping, i) for i, row in enumerate(req.rows)]
    # Simpler user flow: import immediately tries PDOK/BAG once so Queue is not a dead-end.
    auto_geocode = await geocode_orders_in_memory(normalized, limit=min(750, len(normalized)), overwrite=False)
    for o in normalized:
        refresh_order_status(o)
    existing = load_json("orders.json", [])
    existing.extend(normalized)
    save_json("orders.json", existing)
    if req.template_name:
        save_template({"name": req.template_name, "mapping": mapping})
    ready = len([o for o in normalized if o.get("status") == "ready"])
    return {"ok": True, "orders_created": len(normalized), "ready": ready, "incomplete": len(normalized)-ready, "mapping_used": mapping, "auto_geocode": auto_geocode, "orders": normalized[:10]}

@app.delete("/api/planning/queue")
def clear_planning_queue():
    save_json("orders.json", [])
    save_json("routes.json", [])
    return {"ok": True, "message": "Planning Queue en routes geleegd."}

# ----------------------------
# C++ Optimizer Core bridge
# ----------------------------
def distance_km(a, b):
    lon1, lat1 = math.radians(a[0]), math.radians(a[1]); lon2, lat2 = math.radians(b[0]), math.radians(b[1])
    dlon, dlat = lon2-lon1, lat2-lat1
    h = math.sin(dlat/2)**2 + math.cos(lat1)*math.cos(lat2)*math.sin(dlon/2)**2
    return 6371 * 2 * math.asin(math.sqrt(h))

def core_safe(v: Any) -> str:
    return str(v or "").replace("\t", " ").replace("\n", " ").replace("\r", " ").strip()

def build_core_input(orders: List[dict], vehicles: List[dict], depot: List[float]) -> str:
    settings = load_settings()
    lines = [f"DEPOT\t{float(depot[0])}\t{float(depot[1])}", f"SETTINGS\t{settings.get('max_route_hours', 8)}\t{settings.get('load_safety_margin_percent', 12)}"]
    available = [v for v in vehicles if str(v.get("status", "available")).lower() in ["available", "beschikbaar", "active", "actief"]]
    if not available:
        available = vehicles
    for v in available:
        prof = vehicle_load_profile(v)
        lines.append("\t".join([
            "VEH",
            core_safe(v.get("id", "")),
            core_safe(v.get("name") or v.get("license_plate") or v.get("id") or "Voertuig"),
            str(parse_number(v.get("max_weight_kg", 999999), 999999)),
            str(parse_number(v.get("max_volume_m3", v.get("volume_capacity_m3", 999999)), 999999)),
            str(int(parse_number(v.get("europallet_capacity", v.get("pallet_capacity", 999999)), 999999))),
            str(int(parse_number(v.get("roll_container_capacity", 999999), 999999))),
            str(prof.get("usable_floor_m2", 0)),
            str(prof.get("max_route_minutes", 480)),
            core_safe(v.get("status", "available")),
            "v2"
        ]))
    for o in orders:
        lines.append("\t".join([
            "ORD",
            core_safe(o.get("id", "")),
            core_safe(o.get("order_number", "")),
            core_safe(o.get("customer_name", "")),
            str(float(o.get("longitude"))),
            str(float(o.get("latitude"))),
            core_safe(o.get("delivery_date", "")),
            core_safe(o.get("time_window_start", "")),
            core_safe(o.get("time_window_end", "")),
            str(parse_number(o.get("service_time_minutes", 15), 15)),
            str(parse_number(o.get("weight_kg", 0), 0)),
            str(parse_number(o.get("volume_m3", 0), 0)),
            str(int(parse_number(o.get("europallets", 0), 0))),
            str(int(parse_number(o.get("roll_containers", 0), 0))),
            str(int(parse_number(o.get("priority", 0), 0))),
            str(order_floor_m2(o)),
            "o2"
        ]))
    return "\n".join(lines) + "\n"

def run_cpp_optimizer(orders: List[dict], vehicles: List[dict], depot: List[float]) -> Dict[str, Any]:
    if not Path(OPTIMIZER_CORE_BIN).exists():
        raise RuntimeError(f"C++ optimizer-core binary ontbreekt: {OPTIMIZER_CORE_BIN}")
    proc = subprocess.run(
        [OPTIMIZER_CORE_BIN],
        input=build_core_input(orders, vehicles, depot),
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=25,
        check=False,
    )
    if proc.returncode != 0:
        raise RuntimeError(f"C++ optimizer-core foutcode {proc.returncode}: {proc.stderr[-800:]}")
    try:
        return json.loads(proc.stdout)
    except Exception as exc:
        raise RuntimeError(f"C++ optimizer-core gaf ongeldige JSON terug: {exc}; stdout={proc.stdout[:1200]}")

@app.get("/api/optimizer/status")
def optimizer_status():
    return {"version": APP_VERSION, "core_mode": "c++", "binary": OPTIMIZER_CORE_BIN, "available": Path(OPTIMIZER_CORE_BIN).exists(), "scope": "route_optimization v1.4: multi-day agenda, hard capacity validation, depot settings, multi-trip splitting, floor-space pallet/rolcontainer mix; geen 3D loading"}


def vehicle_capacity_check(stops: List[dict], vehicle: Dict[str, Any], settings: Dict[str, Any], depot: List[float]) -> Dict[str, Any]:
    prof = vehicle_load_profile(vehicle)
    max_weight = parse_number(vehicle.get("max_weight_kg", vehicle.get("payload_kg", 0)), 0)
    max_volume = parse_number(vehicle.get("max_volume_m3", vehicle.get("volume_capacity_m3", 0)), 0)
    max_ep = int(parse_number(vehicle.get("europallet_capacity", vehicle.get("pallet_capacity", 0)), 0))
    max_rc = int(parse_number(vehicle.get("roll_container_capacity", 0), 0))
    max_floor = parse_number(prof.get("usable_floor_m2", 0), 0)
    max_route_minutes = int(prof.get("max_route_minutes") or (settings.get("max_route_hours", 8) * 60))
    weight = sum(parse_number(s.get("weight_kg", 0), 0) for s in stops)
    volume = sum(parse_number(s.get("volume_m3", 0), 0) for s in stops)
    ep = int(sum(parse_number(s.get("europallets", 0), 0) for s in stops))
    rc = int(sum(parse_number(s.get("roll_containers", 0), 0) for s in stops))
    floor = sum(order_floor_m2(s) for s in stops)
    service = sum(parse_number(s.get("service_time_minutes", settings.get("default_service_time_minutes", 15)), settings.get("default_service_time_minutes", 15)) for s in stops)
    # approximate time for hard split: haversine at same speed as C++ core; OSRM refines display afterwards.
    drive = 0.0
    if stops:
        points = [depot] + [[float(s.get("longitude")), float(s.get("latitude"))] for s in stops if has_gps(s)] + [depot]
        for a,b in zip(points, points[1:]):
            drive += distance_km(a,b) / 62.0 * 60.0
    total = drive + service
    reasons=[]
    if max_weight and weight > max_weight + 1e-9: reasons.append(f"gewicht {round(weight)}kg > max {round(max_weight)}kg")
    if max_volume and volume > max_volume + 1e-9: reasons.append(f"volume {round(volume,2)}m³ > max {round(max_volume,2)}m³")
    if max_ep and ep > max_ep: reasons.append(f"{ep} EP > max {max_ep} EP")
    if max_rc and rc > max_rc: reasons.append(f"{rc} RC > max {max_rc} RC")
    if max_floor and floor > max_floor + 1e-9: reasons.append(f"vloer {round(floor,2)}m² > max {round(max_floor,2)}m²")
    if max_route_minutes and total > max_route_minutes + 1e-9: reasons.append(f"ritduur {round(total)}min > max {round(max_route_minutes)}min")
    return {"ok": not reasons, "reasons": reasons, "load": {"weight_kg": round(weight,2), "volume_m3": round(volume,3), "europallets": ep, "roll_containers": rc, "floor_m2": round(floor,3), "floor_capacity_m2": max_floor, "floor_utilization": round((floor/max_floor) if max_floor else 0, 4), "utilization": round(max((weight/max_weight) if max_weight else 0,(volume/max_volume) if max_volume else 0,(floor/max_floor) if max_floor else 0,(ep/max_ep) if max_ep else 0,(rc/max_rc) if max_rc else 0),4)}, "duration_minutes_est": round(total,1), "drive_minutes_est": round(drive,1), "service_minutes": round(service,1), "max_route_minutes": max_route_minutes}

def split_stops_by_hard_capacity(stops: List[dict], vehicle: Dict[str, Any], settings: Dict[str, Any], depot: List[float]) -> Dict[str, Any]:
    """Post-core guard: no saved route may exceed vehicle weight/volume/floor/EP/RC/max route duration.
    If needed, create multiple trips with the same vehicle. This is the safety net around the C++ core.
    """
    trips=[]; current=[]; unplanned=[]; explanations=[]
    for stop in stops:
        single = vehicle_capacity_check([stop], vehicle, settings, depot)
        if not single["ok"]:
            unplanned.append({"order_id": stop.get("id"), "order_number": stop.get("order_number"), "reason": "order_past_niet_in_voertuig", "details": single["reasons"]})
            continue
        cand = current + [stop]
        chk = vehicle_capacity_check(cand, vehicle, settings, depot)
        if chk["ok"]:
            current = cand
        else:
            if current:
                trips.append(current)
                explanations.append("Nieuwe rit aangemaakt omdat " + "; ".join(chk["reasons"]))
            current=[stop]
    if current: trips.append(current)
    return {"trips": trips, "unplanned": unplanned, "explanations": explanations}

@app.post("/api/planning/optimize")
async def optimize(payload: dict):
    orders = load_json("orders.json", [])
    vehicles = load_json("vehicles.json", [])
    selected_date = payload.get("delivery_date")
    multi_day = payload.get("multi_day", True) is not False and not selected_date
    for o in orders:
        refresh_order_status(o)

    if not vehicles:
        return {"ok": False, "code": "NO_FLEET", "reason": "Geen voertuigen beschikbaar. Voeg eerst minimaal één voertuig toe aan Wagenpark of laad bewust een test-vloot.", "next_action": "open_fleet"}
    available_vehicles = [v for v in vehicles if str(v.get("status", "available")).lower() in ["available", "beschikbaar", "active", "actief"]]
    if not available_vehicles:
        return {"ok": False, "code": "NO_AVAILABLE_VEHICLES", "reason": "Er zijn voertuigen, maar geen beschikbaar voertuig voor deze planning.", "next_action": "open_fleet"}

    scoped = [o for o in orders if (not selected_date or o.get("delivery_date") == selected_date)]
    gps_before = len([o for o in scoped if has_gps(o)])
    if scoped and gps_before < len(scoped):
        auto_geo = await geocode_orders_in_memory(scoped, limit=int(payload.get("geocode_limit", 1500)), overwrite=False)
        save_json("orders.json", orders)
    else:
        auto_geo = {"updated": 0, "unresolved": 0, "checked": 0, "total_checked": 0}

    candidates = [o for o in scoped if refresh_order_status(o).get("status") == "ready"]
    if not candidates:
        save_json("orders.json", orders)
        return {"ok": False, "reason": "Geen optimaliseerbare orders. Adressen konden niet automatisch via PDOK/BAG worden gekoppeld of verplichte ordervelden ontbreken.", "auto_geocode": auto_geo}
    geocoded = [o for o in candidates if has_gps(o)]
    not_geocoded = [o for o in scoped if o not in geocoded]
    if not geocoded:
        save_json("orders.json", orders)
        return {"ok": False, "reason": "Orders zijn nog niet gegeocodeerd. Controleer adresvelden of PDOK/BAG bereikbaarheid.", "auto_geocode": auto_geo}

    settings = load_settings()
    depot = payload.get("depot") or settings.get("default_depot") or [4.9041, 52.3676]
    order_by_id_all = {str(o.get("id")): o for o in geocoded}
    vehicle_by_id = {str(v.get("id")): v for v in vehicles}

    def group_key(o):
        return str(o.get("delivery_date") or "zonder datum")
    date_groups: Dict[str, List[dict]] = {}
    if multi_day:
        for o in geocoded:
            date_groups.setdefault(group_key(o), []).append(o)
    else:
        label = selected_date or (geocoded[0].get("delivery_date") or "planning")
        date_groups[label] = geocoded

    def date_sort_key(k: str):
        try:
            return datetime.fromisoformat(k).date().isoformat()
        except Exception:
            return "9999-99-99" if k == "zonder datum" else k

    routes_out = []
    capacity_explanations = []
    repair_unplanned = []
    route_no = 1
    per_day_summary = []

    for date_label in sorted(date_groups.keys(), key=date_sort_key):
        group_orders = date_groups[date_label]
        core = run_cpp_optimizer(group_orders, vehicles, depot)
        order_by_id = {str(o.get("id")): o for o in group_orders}
        day_route_count_before = len(routes_out)
        for i, r in enumerate(core.get("routes", [])):
            original_stops = []
            for j, s in enumerate(r.get("stops", [])):
                base = dict(order_by_id.get(str(s.get("order_id")), {}))
                base["sequence"] = j + 1
                base["eta"] = s.get("eta")
                base["leg_distance_m"] = s.get("leg_distance_m")
                base["optimizer_warning"] = s.get("warning")
                base["delivery_date"] = base.get("delivery_date") or date_label
                original_stops.append(base)
            v = vehicle_by_id.get(str(r.get("vehicle_id")), {})
            split = split_stops_by_hard_capacity(original_stops, v, settings, depot)
            repair_unplanned.extend([{**u, "delivery_date": date_label} for u in split.get("unplanned", [])])
            capacity_explanations.extend([f"{date_label}: {x}" for x in split.get("explanations", [])])
            trip_count = len(split.get("trips", []))
            for ti, stops in enumerate(split.get("trips", [])):
                for j, stop in enumerate(stops):
                    stop["sequence"] = j + 1
                    stop["delivery_date"] = stop.get("delivery_date") or date_label
                coords = [depot] + [[float(o["longitude"]), float(o["latitude"])] for o in stops if o.get("longitude") not in [None, ""] and o.get("latitude") not in [None, ""]] + [depot]
                geometry = coords
                distance_m = 0; drive_s = 0; osrm_used = False
                try:
                    rr = await routing_route(RouteRequest(coordinates=coords))
                    geometry = rr["geometry"]["coordinates"]; distance_m = int(rr["distance_m"]); drive_s = int(rr["duration_s"]); osrm_used = True
                except Exception:
                    dist_km = 0.0
                    for a,b in zip(coords, coords[1:]):
                        dist_km += distance_km(a,b)
                    distance_m = int(dist_km*1000); drive_s = int((dist_km/62.0)*3600)
                cap = vehicle_capacity_check(stops, v, settings, depot)
                service_s = int(cap["service_minutes"] * 60)
                total_s = drive_s + service_s
                name = f"Route {route_no}"
                if multi_day and date_label not in ["planning", "zonder datum"]:
                    name = f"Route {route_no} · {date_label}"
                if trip_count > 1:
                    name = f"{name} · rit {ti+1}"
                routes_out.append({
                    "id": f"route_{route_no}",
                    "name": name,
                    "delivery_date": date_label,
                    "date_label": date_label,
                    "trip_index": ti+1,
                    "trip_count_for_vehicle": trip_count,
                    "vehicle_id": r.get("vehicle_id"),
                    "vehicle_name": r.get("vehicle_name") or v.get("name") or v.get("license_plate") or f"Voertuig {route_no}",
                    "stops": stops,
                    "geometry": geometry,
                    "distance_m": distance_m,
                    "duration_s": drive_s,
                    "drive_s": drive_s,
                    "service_s": service_s,
                    "total_duration_s": total_s,
                    "load": cap.get("load", {}),
                    "capacity_ok": cap.get("ok", False),
                    "capacity_reasons": cap.get("reasons", []),
                    "load_intelligence": {"vehicle_profile": vehicle_load_profile(v), "max_route_hours": settings.get("max_route_hours", 8), "hard_constraints": ["gewicht","volume","vloeroppervlak","EP/RC mix","max ritduur"]},
                    "explanation": "Extra rit met hetzelfde voertuig" if trip_count > 1 else "Binnen alle harde capaciteit- en ritduurregels",
                    "warnings": r.get("warnings", 0),
                    "osrm_used": osrm_used,
                    "optimizer_core": core.get("core_version"),
                    "color": "#147CFF"
                })
                route_no += 1
        per_day_summary.append({"delivery_date": date_label, "orders": len(group_orders), "routes": len(routes_out)-day_route_count_before, "unplanned": len(core.get("unplanned", []))})
        repair_unplanned.extend([{**u, "delivery_date": date_label} for u in core.get("unplanned", [])])

    unplanned = repair_unplanned
    for o in not_geocoded:
        unplanned.append({"order_id": o.get("id"), "order_number": o.get("order_number"), "reason": "geen_gps_geocode", "delivery_date": o.get("delivery_date")})
    save_json("orders.json", orders)
    save_json("routes.json", routes_out)
    return {"ok": True, "core_mode": "c++", "core_version": "cpp-core-v1.4-multi-day", "routes_created": len(routes_out), "unplanned_orders": len(unplanned), "routes": routes_out, "unplanned": unplanned, "per_day": per_day_summary, "summary": {"dates": len(per_day_summary), "planned_stops": sum(len(r.get("stops", [])) for r in routes_out)}, "auto_geocode": auto_geo, "note": "Multi-day agenda: alle leverdatums worden automatisch gepland; ongepland betekent alleen: echte constraint/GPS/fleet-blocker.", "capacity_explanations": capacity_explanations}


def route_load_from_stops(stops: List[dict]) -> Dict[str, Any]:
    return {
        "weight_kg": round(sum(parse_number(s.get("weight_kg", 0), 0) for s in stops), 2),
        "volume_m3": round(sum(parse_number(s.get("volume_m3", 0), 0) for s in stops), 3),
        "europallets": int(sum(parse_number(s.get("europallets", 0), 0) for s in stops)),
        "roll_containers": int(sum(parse_number(s.get("roll_containers", 0), 0) for s in stops)),
    }

def best_insert_position(stops: List[dict], order: dict, depot: List[float]) -> int:
    if not stops: return 0
    p=[float(order.get("longitude")), float(order.get("latitude"))]
    pts=[depot]+[[float(s.get("longitude")), float(s.get("latitude"))] for s in stops if has_gps(s)]+[depot]
    best_i, best_extra = 0, 10**9
    for i in range(len(stops)+1):
        a=pts[i] if i < len(pts) else depot
        b=pts[i+1] if i+1 < len(pts) else depot
        extra=distance_km(a,p)+distance_km(p,b)-distance_km(a,b)
        if extra < best_extra:
            best_extra=extra; best_i=i
    return best_i

async def refresh_route_geometry(route: Dict[str, Any], depot: List[float]) -> Dict[str, Any]:
    stops=route.get("stops", [])
    for i,s in enumerate(stops): s["sequence"] = i+1
    coords=[depot]+[[float(s["longitude"]), float(s["latitude"])] for s in stops if has_gps(s)]+[depot]
    route["geometry"] = coords
    route["load"] = route_load_from_stops(stops)
    route["duration_s"] = int(sum(parse_number(s.get("service_time_minutes", 15), 15) for s in stops) * 60)
    route["distance_m"] = 0
    try:
        rr = await routing_route(RouteRequest(coordinates=coords))
        route["geometry"] = rr["geometry"]["coordinates"]
        route["distance_m"] = int(rr["distance_m"])
        route["duration_s"] = int(rr["duration_s"])
        route["osrm_used"] = True
    except Exception:
        dist=0
        for a,b in zip(coords, coords[1:]): dist += distance_km(a,b)
        route["distance_m"] = int(dist*1000)
        route["osrm_used"] = False
    return route

@app.post("/api/planning/board/move-order")
async def planning_board_move_order(payload: dict):
    routes = load_json("routes.json", [])
    orders = load_json("orders.json", [])
    target_route_id = str(payload.get("target_route_id") or "")
    order_id = str(payload.get("order_id") or "")
    depot = payload.get("depot") or [4.9041, 52.3676]
    if not order_id or not target_route_id:
        return {"ok": False, "reason": "order_id en target_route_id zijn verplicht"}
    moved = None
    for r in routes:
        rest=[]
        for s in r.get("stops", []):
            if str(s.get("id")) == order_id or str(s.get("order_id")) == order_id:
                moved = s
            else:
                rest.append(s)
        r["stops"] = rest
    if moved is None:
        moved = next((o for o in orders if str(o.get("id")) == order_id), None)
    if moved is None:
        return {"ok": False, "reason": "Order niet gevonden"}
    target = next((r for r in routes if str(r.get("id")) == target_route_id), None)
    if target is None:
        return {"ok": False, "reason": "Doelroute niet gevonden"}
    stops = target.setdefault("stops", [])
    insert_at = best_insert_position(stops, moved, depot)
    stops.insert(insert_at, moved)
    for r in routes:
        await refresh_route_geometry(r, depot)
    save_json("routes.json", routes)
    return {"ok": True, "message": "Order verplaatst en route opnieuw ingevoegd op beste positie.", "routes": routes, "target_route_id": target_route_id, "insert_at": insert_at}

@app.post("/api/planning/board/lock-route")
def planning_board_lock_route(payload: dict):
    routes=load_json("routes.json", [])
    rid=str(payload.get("route_id") or "")
    locked=bool(payload.get("locked", True))
    for r in routes:
        if str(r.get("id")) == rid:
            r["locked"] = locked
    save_json("routes.json", routes)
    return {"ok": True, "route_id": rid, "locked": locked}

@app.post("/api/planning/board/split-route")
async def planning_board_split_route(payload: dict):
    routes=load_json("routes.json", [])
    rid=str(payload.get("route_id") or "")
    index=int(payload.get("index", 0))
    depot=payload.get("depot") or [4.9041, 52.3676]
    r=next((x for x in routes if str(x.get("id"))==rid), None)
    if not r or index <= 0 or index >= len(r.get("stops", [])):
        return {"ok": False, "reason": "Splitpositie ongeldig"}
    new_stops = r["stops"][index:]
    r["stops"] = r["stops"][:index]
    nr = dict(r)
    nr["id"] = f"route_{len(routes)+1}"
    nr["name"] = f"Route {len(routes)+1}"
    nr["stops"] = new_stops
    nr["locked"] = False
    routes.append(nr)
    for x in routes: await refresh_route_geometry(x, depot)
    save_json("routes.json", routes)
    return {"ok": True, "routes": routes}

@app.get("/api/integrations/catalog")
def integrations_catalog():
    return {"connectors": [
        {"id":"csv_excel", "name":"CSV / Excel", "status":"active"},
        {"id":"custom_api", "name":"Custom API / Webhooks", "status":"foundation"},
        {"id":"sftp", "name":"SFTP import", "status":"planned"},
        {"id":"odoo", "name":"Odoo", "status":"planned"},
        {"id":"exact", "name":"Exact Online", "status":"planned"},
        {"id":"afas", "name":"AFAS", "status":"planned"},
        {"id":"woocommerce", "name":"WooCommerce", "status":"planned"},
        {"id":"shopify", "name":"Shopify", "status":"planned"}
    ]}
