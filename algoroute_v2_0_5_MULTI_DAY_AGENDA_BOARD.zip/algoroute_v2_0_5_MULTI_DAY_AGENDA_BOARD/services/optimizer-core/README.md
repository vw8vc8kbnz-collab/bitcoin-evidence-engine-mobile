# AlgoRoute Optimizer Core

C++ optimizer-core v1 for route optimization + non-3D load optimization.

Scope v1:
- Assign geocoded orders to available vehicles.
- Respect vehicle capacities: kg, m3, europallets, roll containers.
- Build route order using nearest/constraint scoring.
- Include time-window warning logic and service minutes.
- Return planned routes, load utilization, ETA and unplanned orders.

Out of scope for this first core:
- Full 3D bin packing.
- EV charging intelligence.
- Live recalculation.

The FastAPI service invokes this binary through a stable tab-separated line protocol. Python prepares normalized input; C++ performs optimization and returns JSON.
