# AlgoRoute v2.0.5 — Multi-Day Agenda Board

Nieuwe build met multi-day planning agenda:
- CSV-orders worden automatisch per leverdatum gepland.
- Alle stops worden gepland; ongepland betekent alleen echte blocker zoals GPS/capaciteit/voertuig.
- Planning Board heeft een agenda-rail per dag.
- Stops kunnen naar een andere datum worden gezet vanuit de routekaart.
- Auto Plan draait multi-day over alle leverdatums.
- Live Kaart routebalk is rustiger en schaalbaarder bij meerdere routes.
- Geen Termius update-bestand in de ZIP.
