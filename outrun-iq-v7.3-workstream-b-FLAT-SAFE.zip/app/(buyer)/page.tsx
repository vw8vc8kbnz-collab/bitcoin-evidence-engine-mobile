import Link from "next/link";
import type { Listing } from "@/lib/types";
import { getActiveListings, eur, unreadCount, getSaved, getMyOrders } from "@/lib/data";
import { getUser } from "@/lib/auth";
import { Img } from "@/components/Img";
import { Mark, Check, Score } from "@/components/icons";
import { EvidenceStrip } from "@/components/EvidenceStrip";
import { Empty } from "@/components/Empty";
import { HeroSlider } from "@/components/HeroSlider";

export const dynamic = "force-dynamic";
const disc = (p: number, n: number) => Math.round((1 - p / n) * 100);

export default async function Home() {
  const all = await getActiveListings();
  const user = await getUser();
  const unread = user ? await unreadCount(user.id) : 0;

  // "Voor jou": categorieën uit bewaard + orders wegen mee; anders korting + nieuwste
  let prefCats = new Set<string>();
  if (user) {
    const [saved, myOrders] = await Promise.all([getSaved(user.id), getMyOrders(user.id)]);
    const savedCats = saved.map(x => all.find(l => l.id === x.item.listingId)?.category);
    const orderCats = myOrders.map(o => all.find(l => l.id === o.listingId)?.category);
    prefCats = new Set([...savedCats, ...orderCats].filter((c): c is Listing["category"] => !!c));
  }
  const scored = [...all].sort((a, b) => {
    const sc = (l: typeof a) =>
      (prefCats.has(l.category) ? 3 : 0) +
      (1 - l.price / l.newPrice) * 2 +
      Math.max(0, 1 - (Date.now() - +new Date(l.createdAt)) / (14 * 864e5));
    return sc(b) - sc(a);
  });
  const heroItems = scored.slice(0, 5);
  const feat = heroItems[0];
  const heroIds = new Set(heroItems.map(l => l.id));
  const rail = all.filter(l => !heroIds.has(l.id)).slice(0, 6);
  const near = rail[0] ?? all[0];

  return (
    <main className="page">
      <header className="hd">
        <Link href="/" className="lock"><Mark />OUTRUN <b>IQ</b></Link>
        <span className="sp" />
        <Link href="/meldingen" className="icbtn" aria-label="Meldingen">
          <svg viewBox="0 0 24 24"><path d="M6 10a6 6 0 1112 0c0 4 1.5 5.5 1.5 5.5h-15S6 14 6 10z" /><path d="M10.5 19a1.8 1.8 0 003 0" /></svg>
          {unread > 0 && <span className="bub">{unread > 9 ? "9+" : unread}</span>}
        </Link>
        <Link href="/zoeken" className="icbtn" aria-label="Zoeken">
          <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="6.5" /><path d="M20 20l-4.2-4.2" /></svg>
        </Link>
      </header>

      {!feat && (
        <Empty
          title="De marketplace is nog leeg"
          text="Outrun IQ staat klaar. Plaats als geverifieerde partner de eerste listing — de AI bepaalt direct een prijsadvies."
          cta="Plaats eerste listing" href="/partner/nieuw"
        />
      )}

      {feat && (
        <>
          <HeroSlider items={heroItems} personalized={prefCats.size > 0} />

          <section className="homeTrust" aria-label="Outrun IQ koperbescherming">
            <div><b>Veilig betalen</b><span>geld blijft in escrow tot levering</span></div>
            <div><b>Zakelijke partners</b><span>KvK-geverifieerde outletvoorraad</span></div>
            <div><b>AI-prijsbewijs</b><span>korting en marktwaarde transparant</span></div>
          </section>

          <div className="cats">
            <Link href="/zoeken?q=witgoed" className="cat c1"><i><svg viewBox="0 0 24 24"><rect x="7" y="3" width="10" height="18" rx="2" /><circle cx="12" cy="13" r="3.4" /></svg></i>Witgoed</Link>
            <Link href="/zoeken?q=meubels" className="cat c2"><i><svg viewBox="0 0 24 24"><path d="M4 12V9a2 2 0 012-2h12a2 2 0 012 2v3M4 12a2 2 0 00-2 2v3h20v-3a2 2 0 00-2-2M4 12h16" /></svg></i>Meubels</Link>
            <Link href="/zoeken?q=keukens" className="cat c3"><i><svg viewBox="0 0 24 24"><path d="M3 9h18v11H3zM3 9l2-5h14l2 5" /></svg></i>Keukens</Link>
            <Link href="/zoeken?q=tuin" className="cat c4"><i><svg viewBox="0 0 24 24"><path d="M12 3v4M5 14c0-4 3-7 7-7s7 3 7 7zM4 18h16" /></svg></i>Tuin</Link>
          </div>

          {rail.length > 0 && (
            <>
              <div className="sec"><h2>Net toegevoegd</h2><Link href="/zoeken">ALLES →</Link></div>
              <div className="rail">
                {rail.map(l => (
                  <Link key={l.id} href={`/listing/${l.id}`} className="rc">
                    <Img src={l.photos[0]} fallback={l.fallback}><Score v={l.confidence} /></Img>
                    <span className="tx">
                      <span className="t">{l.title}</span>
                      <span className="p"><b>{eur(l.price)}{l.perUnit && "/st"}</b><span>−{disc(l.price, l.newPrice)}%</span></span>
                    </span>
                  </Link>
                ))}
              </div>
            </>
          )}

          <div className="sec"><h2>Uitgelicht</h2><span className="mono">{all.length} LIVE</span></div>
          <Link href={`/listing/${near.id}`} className="tick">
            <span className="top">
              <Img src={near.photos[0]} fallback={near.fallback} />
              <span>
                <span className="t">{near.title}</span>
                <span className="c">{near.condition || `Conditie ${near.conditionScore}/10`}</span>
                <span className="s"><Check />{near.pickupCity}</span>
              </span>
            </span>
            <span className="perf" />
            <span className="bot">
              <span className="pr">{eur(near.price)}<s>nieuw {eur(near.newPrice)}</s></span>
              <span className="d">−{disc(near.price, near.newPrice)}%</span>
              <span className="bars">{[9,16,6,19,11,15,7,18,10].map((h,i)=><i key={i} style={{height:h}} />)}</span>
            </span>
          </Link>
          <section className="pilotPromise">
            <span className="eyebrow">OUTRUN IQ BELOFTE</span>
            <h2>Outletdeals zonder Marktplaats-gedoe.</h2>
            <p>Je koopt van een gecontroleerd bedrijf, ziet direct waarom de prijs klopt en je betaling blijft beschermd tot de levering is afgerond.</p>
            <Link href="/zoeken" className="btn pri">Bekijk alle deals</Link>
          </section>
        </>
      )}
    </main>
  );
}
