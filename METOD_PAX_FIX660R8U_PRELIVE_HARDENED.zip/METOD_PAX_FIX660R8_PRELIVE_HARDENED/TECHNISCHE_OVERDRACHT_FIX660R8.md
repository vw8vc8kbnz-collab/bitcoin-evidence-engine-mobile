# Technische overdracht FIX660R8

## R8U finale submit-state-machine

De volgorde is bindend: `visible grain preview attestation → /api/jobs DONE →
/api/submit_config 200 + requestId → requests/status.json → Admin mailbox →
showSubmissionThankYou`. De frontend mag vóór een niet-lege `requestId` nooit
`__metod_submit_done=true` zetten. De attestation is gekoppeld aan parent-job én aan
de exacte nerfgroepsignature; viewport/drawer-lifecycle is geen productiemutatie.

Build: `FIX660R8_PRELIVE_HARDENED`  

R8T is gebaseerd op een echte mobiele browserdoorloop van materiaalkeuze tot
prijsresultaat. Daarbij zijn twee live eigenaarschapsfouten aangetoond en
hersteld: een lege verwijder-wrapper en een prijs-overlay die door JavaScript-
scope-isolatie de klant-renderer niet kon bereiken. De submitbrug is nu de enige
eigenaar van resultaat-samenvatting, knopgereedheid en de definitieve klikroute.
Datum: 13 augustus 2026

R8S verwijdert de laatste concurrerende UI-state uit de checkout: de legacy
prijswrapper kan de submit-CTA niet meer native uitschakelen, de klantprojectie
merge't niet-lege waarden veldgewijs en mobiel verwijderen gebruikt de centrale
transactie met een dialoog boven de drawer. Dit is op de echte live bevinding
gebaseerd dat R8R volledig actief en ongecached werd geserveerd.

R8R maakt de checkoutketen onafhankelijk van de historische listener-volgorde:
één document-capture eigenaar wordt vóór de oude applicatiescripts geregistreerd
en routeert Safari-submit, klantcapture en mobiele verwijdering exclusief naar de
canonieke functies. R8Q maakt de dataketen één geheel: Tool A legt de volledige klant één keer
vast vóór optimalisatie, gebruikt een live gebonden eindknop en verstuurt alleen
de finalized joblink, klant en notitie. De server herstelt ontbrekende laatste
browservelden uit de verzegelde jobinput en schrijft dezelfde velden naar het
enige idempotente Admin-/salesrequest. Het mobiele mandje muteert via dezelfde
bevestigde materiaalactie als desktop en de oude grijze footer-/modalgradients
zijn mobiel verwijderd. Serverpricing, jobfinalisatie en het nesting-/
plaatsingsalgoritme zijn ongewijzigd.

## Architectuurcontract

| Onderdeel | Pad/contract |
|---|---|
| Immutable releases | `/opt/adzaagt/metod-pax-releases/<release-id>` |
| Actieve codepointer | `/opt/adzaagt/metod-pax-current` |
| Mutable state | `/var/lib/metod-pax` |
| Runtimeconfig | `/etc/adzaagt/metod-pax/metod-pax.env` |
| Admin credentials | `/etc/adzaagt/metod-pax/admin_credentials.live.json`, mode 0600 |
| Service | `metod-pax.service`, user/group `metod-pax` |
| Backend | loopback `127.0.0.1:8792` |
| Edge | staging standaard loopback HTTP/tunnel; productie uitsluitend domein/TLS |

De releaseboom bevat alleen code, lege CSV-only catalogusseed, ingebedde DXF-seed en documentatie. Jobs, requests, index/idempotency, queue, archive, logs, backups, pricingconfig, catalogus, media en DXF-runtimecopy horen bij externe state.

## Jobdataflow

1. Tool A stuurt publieke opaque materiaal-ID, panelintentie en gebruikte ingebedde DXF-bytes.
2. De server valideert strict JSON/limits, resolveert materiaal tegen de actieve catalogus en vergelijkt de DXF exact met de serverlibrary.
3. `panel_contract.py` bouwt een canonieke productie-CSV. Clientpricing en clientpolicy verdwijnen.
4. De optimizer valideert geometrie, maakt placements/sheets/quote/report en schrijft een optimizer-manifest met input/outputhashes.
5. De serverfinalizer controleert exacte paneelinstances, sheetcount, reportevidence, partkopieën, labels en StickerTool-identities.
6. Alleen daarna schrijft hij `output/finalization.json` met SHA-256 voor ieder production artifact.
7. De creator verifieert de complete jobfamilie vóór de duurzame DONE-overgang.
   Statuspolling vertrouwt uitsluitend die terminale state en mutation-sensitive
   artifactsignatures; submit en filehandlers blijven sealed artifacts volledig
   controleren. Tijdens PROCESSING worden groeiende outputs nooit als productie
   vrijgegeven of iedere 350 ms opnieuw gehasht.
   Gedeelde DXF-onderdeellinks worden per unieke bron geverifieerd, via inode-
   identiteit aan hun reeds gehashte bron gebonden en per doelmap als één duurzame
   batch gepubliceerd. Zo groeit hashing noch directory-`fsync` mee met het aantal
   identieke paneelregels.
8. Finale submit reserveert exclusief een duurzame idempotencyclaim en maakt precies één salesrequest.

Een corrupt artifact mag worden bewaard voor forensics, maar maakt `_finalization_complete` false en wordt niet geserveerd. Admin GET-routes genereren of repareren nooit output.

## Belangrijke bestanden

| Bestand | Functie |
|---|---|
| `app/panel_contract.py` | strict paneel- en GrainGroupcontract |
| `app/dxf_geometry.py` | onafhankelijke DXF-parse/bbox/transformatievalidatie |
| `app/dxf_nesting_optimizer.py` | fail-closed nesting/export + optimizer evidence |
| `app/safety_contracts.py` | strict JSON, durable writes, veilige paden, hashes, JSONL locking/rotatie |
| `app/server_py.py` | API, auth, catalogus, jobstate, finalisatie, backup/readiness |
| `tools/final_preflight.py` | bron-, artifact- en optionele runtimegate |
| `tools/restore_system_backup.py` | verify/restore naar nieuwe stagingmap |
| `tools/build_release_artifact.py` | deterministische ZIP + externe SHA-sidecar |

## Deployvolgorde

`INSTALL_FIX660R8_FROM_STAGE.sh`:

1. verifieert interne checksums en volledige preflight;
2. verifieert de huidige immutable release of exacte R7-bestandhashes;
3. kopieert code naar een nieuwe immutable releasefolder;
4. back-upt de te wijzigen systemd/Nginx/env-config;
5. zet de edge in maintenance en stopt de service;
6. migreert legacy mutable state via een sibling stage en atomische rename;
7. controleert een niet-lege actieve catalogus;
8. wisselt de releasepointer atomisch;
9. roept `DEPLOY_FIX660.sh` aan voor config, runtimepreflight, service- en edgecommit.

`DEPLOY_FIX660.sh` maakt een non-root systemd-unit, bounded Nginx-profiel en runtime-env. Production valideert domein, HTTPS-origin, certificaatduur, hostname en cert/key-paar. De edge wordt pas na liveness/readiness herladen.

## Rollback en incident

Vóór de definitieve Nginx-reload kan de installer de vorige releasepointer en config terugzetten. Externe state blijft altijd voorwaarts behouden. Na edge-reopen wordt automatisch rollback bewust uitgeschakeld, omdat nieuwe requests kunnen bestaan.

Bij incident na livecommit:

1. zet de edge gepland in maintenance;
2. bewaar logs, runtime states en verdachte artifacts;
3. kies een eerder geverifieerde immutable release;
4. controleer dat die release het huidige state-schema kan lezen;
5. wissel alleen de pointer/config en voer runtimepreflight uit;
6. herstel state alleen via een afzonderlijk goedgekeurd disaster-recoveryplan, nooit als automatische coderollback.

## Backup en restore

De applicatiebackup draineert POST-mutaties, actieve jobs, queuewerk en catalogusimagesync. Hij archiveert alle state behalve de backupfolder zelf en tijdelijke exports. `BACKUP_MANIFEST.json` bevat schema, tijd, actor, build en size/SHA-256 per lid. De gemaakte ZIP wordt opnieuw gelezen en volledig gehasht.

Restore accepteert geen symlink, directorylid, absolute/backslash/traversal/dubbel/extra pad, hashverschil of bestaand target. State wordt naar een sibling stage geschreven, gefsynct, opnieuw gehasht en daarna atomisch hernoemd. Een proof mag pas na een echte restore worden geschreven.

## Health en operationele controle

- `/health/live`: proces/build leeft.
- `/health/ready`: catalogus, signoff (productie), pricing, statewrite, vrije bytes/inodes, DXF en production evidence.
- `tools/final_preflight.py --runtime`: dezelfde kerncontracten plus credentials, catalogusvelden, restorebewijs en volledige bron-/lifecycle-regressie.

Production defaults: één actieve optimizerworker, een FIFO met maximaal acht
wachtende gevalideerde jobs en maximaal twee toegelaten jobs per IP. De optimizer-
workerlimiet blijft op de huidige kleine VPS exact één; verhoog die uitsluitend na
CPU/I-O-loadbewijs. HTTP/SSE blijft begrensd, evenals de catalogusminimumcount,
vrije statebytes en inodes.

## Admin en catalogus

Production vereist `users[]` met unieke username, exact PBKDF2-SHA256/260.000, TOTP en rol `admin`. De browser krijgt alleen een HttpOnly-cookie; actor komt uit de serversessie. Kritieke catalogus-, pricing-, DXF- en statusmutaties loggen die actor.

Cataloguspublicatie is tweestaps: preview/reviewhash, daarna publish met exact dezelfde hash. De resulterende signoff bindt `materialLibrarySha256` aan actor/tijd. Iedere librarywijziging maakt readiness false totdat opnieuw geldig is gepubliceerd.

## Bekende resterende grenzen

- Geen in dit pakket opgenomen bewijs van echte VPS-, TLS-, firewall-, monitoring- of off-host-providerconfig.
- Geen echte iPhone/Safari-acceptatie.
- Geen onafhankelijke CAM/CNC-import of fysieke proefsnede.
- Geen representatieve load/chaos/disk-full/inode-full-resultaten.
- Verdere opsplitsing van `server_py.py`/`toolA.html`, verwijdering van resterende best-effort legacyhelpers en uitbreiding met coverage/SAST/secrets/CVE-attestatie blijven onderhoudsbacklog.

Deze grenzen staan als harde externe gates in `GO_LIVE_GATES_FIX660R8.md`; ze mogen niet door een groene bronpreflight worden vervangen.
