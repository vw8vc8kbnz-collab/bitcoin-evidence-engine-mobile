from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

from app.core.config import settings
from app.core.time_utils import utc_now


def _safe(value: Any) -> Any:
    try:
        if value is None or isinstance(value, (str, int, float, bool)):
            return value
        if isinstance(value, dict):
            return {str(k): _safe(v) for k, v in value.items()}
        if isinstance(value, (list, tuple)):
            return [_safe(v) for v in value]
        if hasattr(value, 'isoformat'):
            return value.isoformat()
    except Exception:
        pass
    return str(value)


class SessionLogService:
    """Append-only session/run diagnostic log.

    The goal is not pretty logging; it is auditability for Stijn. Every important
    frontend/backend transition can be appended here and later exported as a TXT
    file so we can see where Random1000 felt slow: frontend reload, API polling,
    native core, adaptive rebuild, ZIP creation, or chart/status refresh.
    """

    ROOT = settings.data_dir / 'session_logs'

    def __init__(self) -> None:
        self.root = self.ROOT
        self.root.mkdir(parents=True, exist_ok=True)
        self.path = self.root / 'current_session_log.jsonl'
        self.txt_path = self.root / 'current_session_log.txt'

    def append(self, event: str, payload: dict | None = None) -> None:
        payload = payload or {}
        row = {
            'ts': utc_now().isoformat(),
            'epoch_ms': int(time.time() * 1000),
            'engine_version': settings.engine_version,
            'event': str(event)[:160],
            'payload': _safe(payload),
        }
        try:
            with self.path.open('a', encoding='utf-8') as fh:
                fh.write(json.dumps(row, ensure_ascii=False, default=str) + '\n')
            summary = self._format_line(row)
            with self.txt_path.open('a', encoding='utf-8') as fh:
                fh.write(summary + '\n')
        except Exception:
            pass

    def _format_line(self, row: dict) -> str:
        p = row.get('payload') or {}
        parts = [f"[{row.get('ts')}]", str(row.get('event'))]
        if isinstance(p, dict):
            for k in ('job_id','batch_id','count','phase','status','progress_pct','tests_written','snapshots_written','duration_ms','elapsed_ms','url','method','ok','error'):
                if k in p and p.get(k) is not None:
                    parts.append(f"{k}={p.get(k)}")
        try:
            extra = json.dumps(p, ensure_ascii=False, default=str)
            if len(extra) < 700:
                parts.append(extra)
        except Exception:
            pass
        return ' | '.join(parts)

    def text(self, tail_lines: int | None = None) -> str:
        if not self.txt_path.exists():
            return 'Geen sessielog gevonden.\n'
        try:
            lines = self.txt_path.read_text(encoding='utf-8', errors='replace').splitlines()
            if tail_lines and len(lines) > tail_lines:
                lines = lines[-tail_lines:]
            header = [
                'Bitcoin Evidence Engine - Session Export Log',
                f'engine_version={settings.engine_version}',
                f'data_dir={settings.data_dir}',
                f'generated_at={utc_now().isoformat()}',
                '',
            ]
            return '\n'.join(header + lines) + '\n'
        except Exception as exc:
            return f'Sessielog kon niet gelezen worden: {exc}\n'

    def reset(self) -> None:
        try:
            self.path.unlink(missing_ok=True)
            self.txt_path.unlink(missing_ok=True)
        except Exception:
            pass
