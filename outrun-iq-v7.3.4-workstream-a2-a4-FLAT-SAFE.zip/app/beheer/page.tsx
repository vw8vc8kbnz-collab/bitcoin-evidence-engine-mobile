import Link from "next/link";
import { read } from "@/lib/store";
import { getUser } from "@/lib/auth";
import { AdminApprove } from "@/components/AdminApprove";
import { AdminResolve } from "@/components/AdminResolve";
import { AdminReturn } from "@/components/AdminReturn";
import { AdminTrust } from "@/components/AdminTrust";
import { sweepOrders, RELEASE_DAYS, RELEASE_DAYS_NEW } from "@/lib/data";
import { flushTraffic, liveNow } from "@/lib/traffic";
import { Mark } from "@/components/icons";
import { eur } from "@/lib/types";

export const dynamic = "force-dynamic";

const day = (offset: number) => new Date(Date.now() - offset * 864e5).toISOString().slice(0, 10);

export default async function Beheer({ searchParams }:{ searchParams: Promise<{ pin?: string }> }) {
  const { pin } = await searchParams;
  const me = await getUser();
  const viaPin = !!process.env.ADMIN_PIN && pin === process.env.ADMIN_PIN;
  if (me?.role !== "admin" && !viaPin) {
    return (
      <div className="app dark"><main className="page narrow">
        <h1 className="h1big" style={{ marginTop: 26 }}>Beheer</h1>
        <p className="note">Log in met het beheerdersaccount (ADMIN_EMAIL in .env) of open /beheer?pin=ADMIN_PIN.</p>
      </main></div>
    );
  }
  await sweepOrders();
  await flushTraffic();
  const db = await read();

  // ---- kerncijfers ----
  const consumers = db.users.filter(u => !u.partnerProfile && u.role !== "admin");
  const pending = db.users.filter(u => u.partnerProfile?.status === "pending");
  const partners = db.users.filter(u => u.partnerProfile?.status === "approved");
  const live = db.listings.filter(l => l.status === "active");
  const openStatuses = ["paid", "confirmed", "delivery_planned", "delivered"];
  const openOrders = db.orders.filter(o => openStatuses.includes(o.status));
  const escrowVast = openOrders.reduce((s, o) => s + o.totalPaid, 0);
  const paidOut = db.orders.filter(o => o.status === "paid_out");
  const gmv = db.orders.filter(o => o.status !== "cancelled").reduce((s, o) => s + o.totalPaid, 0);
  const commissie = paidOut.reduce((s, o) => s + o.commission, 0);
  const disputes = db.orders.filter(o => o.status === "disputed");
  const escReturns = db.orders.filter(o => o.returnRequest?.status === "escalated");
  const openBids = db.bids.filter(b => ["open", "countered"].includes(b.status));
  const t0 = db.traffic[day(0)] ?? { views: 0, visitors: 0 };
  const t7 = Array.from({ length: 7 }, (_, i) => db.traffic[day(i)] ?? { views: 0, visitors: 0 })
    .reduce((a, b) => ({ views: a.views + b.views, visitors: a.visitors + b.visitors }), { views: 0, visitors: 0 });

  const stats: { k: string; v: string; sub?: string; hot?: boolean }[] = [
    { k: "LIVE NU", v: String(liveNow()), sub: "bezoekers < 5 min", hot: liveNow() > 0 },
    { k: "VANDAAG", v: String(t0.visitors), sub: `${t0.views} weergaven` },
    { k: "7 DAGEN", v: String(t7.visitors), sub: `${t7.views} weergaven` },
    { k: "CONSUMENTEN", v: String(consumers.length) },
    { k: "PARTNERS", v: String(partners.length), sub: pending.length ? `+${pending.length} in aanvraag` : undefined, hot: pending.length > 0 },
    { k: "LIVE LISTINGS", v: String(live.length), sub: `${db.listings.length} totaal` },
    { k: "OPEN ORDERS", v: String(openOrders.length), sub: `${db.orders.length} totaal` },
    { k: "IN ESCROW", v: eur(escrowVast), sub: `termijn ${RELEASE_DAYS}/${RELEASE_DAYS_NEW} dgn` },
    { k: "GMV (TEST)", v: eur(gmv) },
    { k: "COMMISSIE", v: eur(commissie), sub: "gerealiseerd (test)" },
    { k: "BIEDINGEN", v: String(openBids.length), sub: "open/tegenbod" },
    { k: "ISSUES", v: String(disputes.length + escReturns.length), sub: `${disputes.length} dispute · ${escReturns.length} retour`, hot: disputes.length + escReturns.length > 0 },
  ];

  const recent = [...db.orders].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 8);
  const auditRecent = [...(db.auditLog ?? [])].sort((a, b) => b.at.localeCompare(a.at)).slice(0, 10);
  const auditSuffix = viaPin && me?.role !== "admin" ? `?pin=${pin}` : "";
  const auditCsv = `/api/admin/audit/export${auditSuffix}${auditSuffix ? "&" : "?"}format=csv`;
  const auditJsonl = `/api/admin/audit/export${auditSuffix}${auditSuffix ? "&" : "?"}format=jsonl`;

  return (
    <div className="app dark">
      <main className="page adm">
        <div className="hd" style={{ display: "flex" }}>
          <span className="lock" style={{ color: "#fff" }}><Mark glow />BEHEER · OUTRUN <b>IQ</b></span>
          <span className="sp" />
          <span className="mini" style={{ color: "#5F6873" }}>{new Date().toLocaleDateString("nl-NL", { weekday: "long", day: "numeric", month: "long" })}</span>
        </div>

        <h1 className="h1big">Missiecontrole</h1>
        <div className="admgrid">
          {stats.map(s => (
            <div key={s.k} className={`admstat${s.hot ? " hot" : ""}`}>
              <span className="k">{s.k}</span>
              <b>{s.v}</b>
              {s.sub && <span className="sub">{s.sub}</span>}
            </div>
          ))}
        </div>

        {pending.length > 0 && (
          <>
            <div className="dsec" style={{ marginTop: 26 }}><h2>Partneraanvragen</h2><span>{pending.length} NIEUW</span></div>
            {pending.map(u => (
              <AdminApprove key={u.id} userId={u.id} label={`${u.partnerProfile!.companyName} · KvK ${u.partnerProfile!.kvk} · ${u.partnerProfile!.city} · ${u.email}`} />
            ))}
          </>
        )}
        {disputes.length > 0 && (
          <>
            <div className="dsec" style={{ marginTop: 22 }}><h2>Disputes</h2><span>{disputes.length} OPEN</span></div>
            {disputes.map(o => (
              <AdminResolve key={o.id} orderId={o.id}
                label={`${o.id} · ${o.itemTitle} · ${o.dispute?.category ?? ""} — "${(o.dispute?.text ?? "").slice(0, 90)}" · koper betaalde €${o.totalPaid}`} />
            ))}
          </>
        )}
        {escReturns.length > 0 && (
          <>
            <div className="dsec" style={{ marginTop: 22 }}><h2>Geëscaleerde retouren</h2><span>{escReturns.length}</span></div>
            {escReturns.map(o => (
              <AdminReturn key={o.id} orderId={o.id}
                label={`${o.id} · ${o.itemTitle} — "${o.returnRequest!.reason.slice(0, 90)}" · partner reageerde niet binnen de termijn`} />
            ))}
          </>
        )}

        <div className="dsec" style={{ marginTop: 26 }}><h2>Partners</h2><span>{partners.length}</span></div>
        {partners.length === 0 && <p className="note">Nog geen goedgekeurde partners.</p>}
        {partners.map(u => {
          const sl = db.sellers.find(x => x.slug === u.partnerSlug);
          const pl = db.listings.filter(l => l.sellerSlug === u.partnerSlug);
          const po = db.orders.filter(o => o.sellerSlug === u.partnerSlug);
          const issues = po.filter(o => o.status === "disputed" || ["requested", "escalated"].includes(o.returnRequest?.status ?? "")).length;
          return (
            <div key={u.id} className="orow" style={{ flexWrap: "wrap", gap: 8 }}>
              <span><b>{u.partnerProfile!.companyName}{issues > 0 ? ` · ⚠ ${issues}` : ""}</b>
                <span>{pl.filter(l => l.status === "active").length} LIVE · {po.length} ORDERS · ESCROW {sl?.trusted ? "7" : "14"} DGN · {u.email}</span></span>
              {sl && <AdminTrust slug={sl.slug} trusted={sl.trusted} />}
              <Link href={`/beheer/partner/${u.partnerSlug}${viaPin && me?.role !== "admin" ? `?pin=${pin}` : ""}`} className="go" style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--petrol-glow)" }}>INZAGE →</Link>
            </div>
          );
        })}

        <div className="dsec" style={{ marginTop: 26 }}><h2>Audit log</h2><span>{auditRecent.length} RECENT</span></div>
        <div className="orow" style={{ gap: 10, flexWrap: "wrap" }}>
          <span><b>Download beheerlog</b><span>JSONL voor technische audit · CSV voor Excel/boekhouding</span></span>
          <Link href={auditJsonl} className="go" style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--petrol-glow)" }}>JSONL ↓</Link>
          <Link href={auditCsv} className="go" style={{ fontFamily: "var(--mono)", fontSize: 10, color: "var(--petrol-glow)" }}>CSV ↓</Link>
        </div>
        {auditRecent.map(a => (
          <div key={a.id} className="orow">
            <span><b>{a.action} · {a.entityId ?? a.entity}</b>
              <span>{new Date(a.at).toLocaleString("nl-NL", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })} · {a.actorType.toUpperCase()} · {a.actorLabel ?? a.actorId ?? "systeem"} · {a.summary}</span></span>
          </div>
        ))}

        <div className="dsec" style={{ marginTop: 26 }}><h2>Laatste orders</h2><span>{recent.length}</span></div>
        {recent.map(o => (
          <div key={o.id} className="orow">
            <span><b>{o.itemTitle} · {eur(o.totalPaid)}</b>
              <span>{o.id} · {o.status.replaceAll("_", " ").toUpperCase()} · {o.sellerSlug.toUpperCase()} · {new Date(o.createdAt).toLocaleString("nl-NL", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}</span></span>
          </div>
        ))}
      </main>
    </div>
  );
}
