// App.jsx — hoofdcomponent. Houdt bij: actieve tab + welke overlay open is.
import React, { useState, useEffect } from 'react';
import { createRoot } from 'react-dom/client';
import { AnimatePresence } from 'framer-motion';

import { useAuth } from './hooks/useAuth';
import { Splash, Auth } from './components/Auth';
import { BottomNav } from './components/Layout';
import { Feed } from './components/Feed';
import { Discover } from './components/Discover';
import { Studio } from './components/Studio';
import { Saves, Profile } from './components/SavesProfile';
import { RoomPage } from './components/RoomPage';
import { HomeProfile } from './components/HomeProfile';
import './style.css';

function App() {
  const auth = useAuth();
  const [splash, setSplash] = useState(true);
  const [tab, setTab] = useState('feed');
  const [room, setRoom] = useState(null);     // open room id
  const [homeSlug, setHomeSlug] = useState(null); // open home slug
  const [studioKey, setStudioKey] = useState(0);  // forceer studio reset bij create-knop

  useEffect(() => { const t = setTimeout(() => setSplash(false), 1500); return () => clearTimeout(t); }, []);

  if (!auth.ready) return <Splash />;
  if (!auth.token) {
    return (<><Auth auth={auth} /><AnimatePresence>{splash && <Splash />}</AnimatePresence></>);
  }

  const openRoom = (id) => { setHomeSlug(null); setRoom(id); };
  const openHome = (slug) => setHomeSlug(slug);
  const onCreate = () => { setStudioKey((k) => k + 1); setTab('studio'); };

  return (
    <div className="app-shell">
      <AnimatePresence>{splash && <Splash />}</AnimatePresence>

      {tab === 'feed' && <Feed auth={auth} onOpenRoom={openRoom} />}
      {tab === 'discover' && <Discover auth={auth} openHome={openHome} openRoom={openRoom} />}
      {tab === 'studio' && <Studio key={studioKey} auth={auth} onPosted={() => setTab('feed')} />}
      {tab === 'saves' && <Saves auth={auth} openRoom={openRoom} />}
      {tab === 'profile' && <Profile auth={auth} openRoom={openRoom} openHome={openHome} />}

      <AnimatePresence>
        {homeSlug && <HomeProfile key={homeSlug} slug={homeSlug} auth={auth} onClose={() => setHomeSlug(null)} openRoom={openRoom} />}
      </AnimatePresence>
      <AnimatePresence>
        {room && <RoomPage key={room} roomId={room} auth={auth} onClose={() => setRoom(null)} />}
      </AnimatePresence>

      <BottomNav active={tab} onTab={setTab} onCreate={onCreate} />
    </div>
  );
}

createRoot(document.getElementById('root')).render(<App />);
