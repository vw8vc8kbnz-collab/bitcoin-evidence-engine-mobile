// data/fallback.js — neutrale fallbacks zodat de UI nooit leeg/kapot oogt.
export const DEFAULT_COVER = 'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&w=1400&q=85';
export const DEFAULT_ROOM = 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1400&q=85';

export const FALLBACK_FEED = [
  {
    id: 'fb1', media_url: DEFAULT_ROOM, phase_label: 'Gestyled',
    caption: 'De woonkamer is af: warme texturen, zacht licht en rust.',
    created_at: new Date().toISOString(),
    room: { id: 'fr1', name: 'Woonkamer', cover_url: DEFAULT_ROOM },
    home: { id: 'fh1', title: 'The Atelier House', slug: 'the-atelier-house', cover_url: DEFAULT_COVER },
    saved: false, liked: false, likes_count: 24, comments_count: 3,
    following_room: false, following_home: false,
  },
];
