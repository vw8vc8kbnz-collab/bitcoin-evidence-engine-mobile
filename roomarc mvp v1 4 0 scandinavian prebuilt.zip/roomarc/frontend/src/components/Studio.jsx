// components/Studio.jsx — creatieve werkplek, geen formulierenmenu.
// Eén dominante actie (kamerupdate), je eigen lopende projecten zichtbaar,
// en daaronder secundaire acties. Composer met live preview.
import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, Camera, Layers, Home as HomeIcon, SplitSquareHorizontal, Send, ImagePlus, Check } from 'lucide-react';
import { TopBar, EmptyState } from './Layout';
import { DEFAULT_COVER, DEFAULT_ROOM } from '../data/fallback';

const PHASES = ['Startpunt', 'Vloer gelegd', 'Muren afgerond', 'Meubels geplaatst', 'Gestyled', 'Voor/na'];
const QUICK = [
  'De basis staat en de ruimte voelt direct rustiger.',
  'Vandaag een mooie nieuwe stap gezet in deze kamer.',
  'De materialen komen nu echt samen.',
  'Kleine details maken het geheel veel warmer.',
];

/* ---------- Studio home ---------- */
function StudioHome({ auth, setMode }) {
  const [mine, setMine] = useState(null);
  useEffect(() => {
    auth.req('/api/me/rooms').then((r) => setMine(Array.isArray(r) ? r : [])).catch(() => setMine([]));
  }, []);

  return (
    <main className="screen">
      <div className="studio-hero">
        <div><h1>Studio</h1><p>Laat je kamers groeien</p></div>
      </div>

      {/* Dominante primaire actie */}
      <motion.button className="studio-primary" onClick={() => setMode('update')} whileTap={{ scale: 0.98 }}>
        <span className="sp-glow" />
        <div className="sp-icon"><Camera size={26} color="#fff" /></div>
        <div className="sp-text"><strong>Kamerupdate plaatsen</strong><span>Foto → kamer → fase → live preview</span></div>
      </motion.button>

      {/* Secundaire acties */}
      <div className="studio-secondary">
        <button className="studio-sec-card" onClick={() => setMode('room')}>
          <i><Layers size={20} /></i><strong>Nieuwe kamer</strong><span>Apart te volgen ruimte</span>
        </button>
        <button className="studio-sec-card" onClick={() => setMode('home')}>
          <i><HomeIcon size={20} /></i><strong>Huisprofiel</strong><span>De basis van je pagina</span>
        </button>
      </div>

      {/* Verder werken aan eigen projecten */}
      <div className="section-head"><h2>Verder werken aan</h2></div>
      {mine === null && <div className="skeleton" style={{ height: 80, marginBottom: 10 }} />}
      {mine && mine.length > 0 && mine.slice(0, 5).map((r) => (
        <button key={r.id} className="project-card" onClick={() => setMode('update')}>
          <div className="pc-img"><img src={r.cover_url || DEFAULT_ROOM} alt={r.name} /></div>
          <div className="pc-text"><strong>{r.name}</strong><span>{r.home?.title} · {r.updates} updates</span></div>
          <span className="pc-phase">{r.latest_phase || 'Nieuw'}</span>
        </button>
      ))}
      {mine && mine.length === 0 && (
        <EmptyState icon={<Camera size={22} />} title="Nog geen projecten" text="Maak een huisprofiel en je eerste kamer om te starten." />
      )}
    </main>
  );
}

/* ---------- Composer header ---------- */
function ComposerHead({ onBack, title, subtitle }) {
  return (
    <div className="composer-head">
      <button className="back" onClick={onBack}><ChevronLeft size={20} /></button>
      <div className="ch-text"><strong>{title}</strong><span>{subtitle}</span></div>
    </div>
  );
}

/* ---------- Update composer ---------- */
function UpdateComposer({ auth, onBack, onPosted }) {
  const [homes, setHomes] = useState([]);
  const [rooms, setRooms] = useState([]);
  const [homeId, setHomeId] = useState('');
  const [roomId, setRoomId] = useState('');
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState('');
  const [phase, setPhase] = useState('');
  const [caption, setCaption] = useState('');
  const [status, setStatus] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    auth.req('/api/homes').then((d) => { const list = d || []; setHomes(list); if (list[0]) setHomeId(list[0].id); }).catch(() => setHomes([]));
  }, []);
  useEffect(() => {
    const h = homes.find((x) => x.id === homeId);
    if (!h) return;
    auth.req(`/api/homes/${h.slug}`).then((d) => { const r = d.rooms || []; setRooms(r); if (r[0]) setRoomId(r[0].id); }).catch(() => setRooms([]));
  }, [homeId, homes.length]);

  const selHome = homes.find((h) => h.id === homeId);
  const selRoom = rooms.find((r) => r.id === roomId);
  const steps = [file, roomId, phase, caption.trim()].filter(Boolean).length;
  const ready = steps === 4;

  function pick(e) {
    const f = e.target.files?.[0]; if (!f) return;
    if (preview) URL.revokeObjectURL(preview);
    setFile(f); setPreview(URL.createObjectURL(f));
  }
  async function submit() {
    if (!ready) { setStatus('Maak de update compleet: foto, kamer, fase en tekst.'); return; }
    setBusy(true);
    try {
      setStatus('Foto uploaden…');
      const form = new FormData(); form.append('file', file);
      const up = await auth.req('/api/media/upload', { method: 'POST', body: form });
      setStatus('Publiceren…');
      await auth.req(`/api/rooms/${roomId}/updates`, { method: 'POST', body: JSON.stringify({ media_url: up.url, caption, phase_label: phase }) });
      setStatus('Geplaatst!');
      setTimeout(() => onPosted?.(), 500);
    } catch (e) { setStatus(`Mislukt: ${e.message}`); } finally { setBusy(false); }
  }

  return (
    <main className="screen">
      <ComposerHead onBack={onBack} title="Kamerupdate" subtitle={`Stap ${steps} van 4`} />
      <div className="progress-track"><div className="progress-fill" style={{ width: `${(steps / 4) * 100}%` }} /></div>

      <label className={`photo-drop ${preview ? 'filled' : ''}`}>
        <input type="file" accept="image/*" onChange={pick} />
        {preview ? <img src={preview} alt="" /> : <div className="pd-empty"><ImagePlus size={34} /><strong>Voeg kamerfoto toe</strong><span>Dit wordt het beeld van je nieuwe fase</span></div>}
      </label>

      <div className="field-row">
        <div className="field"><label>Huis</label><select value={homeId} onChange={(e) => setHomeId(e.target.value)}>{homes.map((h) => <option key={h.id} value={h.id}>{h.title}</option>)}</select></div>
        <div className="field"><label>Kamer</label><select value={roomId} onChange={(e) => setRoomId(e.target.value)}>{rooms.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}</select></div>
      </div>

      <div className="field">
        <label>Fase</label>
        <div className="phase-pills scroll-hide">{PHASES.map((p) => <button key={p} className={phase === p ? 'active' : ''} onClick={() => setPhase(p)} type="button">{p}</button>)}</div>
      </div>

      <div className="field">
        <label>Wat is er veranderd?</label>
        <textarea value={caption} onChange={(e) => setCaption(e.target.value)} placeholder="Bijv. De vloer ligt erin en de kamer voelt direct warmer." />
        <div className="quick-caps">{QUICK.map((t) => <button key={t} type="button" onClick={() => setCaption(t)}>{t}</button>)}</div>
      </div>

      {/* Live preview kaart */}
      <div className="section-head"><h2>Live preview</h2></div>
      <div className="fcard">
        <div className="fcard-media" style={{ aspectRatio: '4/5' }}>
          {preview ? <img src={preview} alt="" /> : <div className="pd-empty" style={{ position: 'absolute', inset: 0 }}><Camera size={28} color="var(--ink-faint)" /></div>}
          <div className="fcard-grad" />
          <div className="fcard-top"><div className="fcard-avatar">{(selHome?.title || 'R')[0]}</div><div className="fcard-id"><strong>{selHome?.title || 'Jouw huis'}</strong><span>{selRoom?.name || 'Kamer'}</span></div></div>
          <div className="phase-chip"><strong>{phase || 'Nieuwe fase'}</strong></div>
        </div>
        <div className="fcard-body"><p className="fcard-caption">{caption || 'Schrijf kort wat er veranderd is.'}</p></div>
      </div>

      {status ? <p className="status-msg">{status}</p> : null}
      <button className="publish-bar" disabled={busy} onClick={submit}><Send size={18} /> {busy ? 'Publiceren…' : ready ? 'Publiceer naar tijdlijn' : 'Maak update compleet'}</button>
    </main>
  );
}

/* ---------- Room composer ---------- */
function RoomComposer({ auth, onBack }) {
  const [homes, setHomes] = useState([]); const [homeId, setHomeId] = useState('');
  const [name, setName] = useState(''); const [type, setType] = useState(''); const [status, setStatus] = useState('');
  useEffect(() => { auth.req('/api/homes').then((d) => { setHomes(d || []); if (d?.[0]) setHomeId(d[0].id); }).catch(() => setHomes([])); }, []);
  async function submit() {
    if (!name.trim()) { setStatus('Geef de kamer een naam.'); return; }
    try { await auth.req(`/api/homes/${homeId}/rooms`, { method: 'POST', body: JSON.stringify({ name, room_type: type, cover_url: DEFAULT_ROOM }) }); setStatus('Kamer aangemaakt! Plaats nu de eerste update.'); setName(''); setType(''); }
    catch (e) { setStatus(`Mislukt: ${e.message}`); }
  }
  return (
    <main className="screen">
      <ComposerHead onBack={onBack} title="Nieuwe kamer" subtitle="Een ruimte die apart te volgen is" />
      <div className="field"><label>Kamernaam</label><input value={name} onChange={(e) => setName(e.target.value)} placeholder="Bijv. Woonkamer" /></div>
      <div className="field"><label>Type</label><input value={type} onChange={(e) => setType(e.target.value)} placeholder="Keuken, slaapkamer, badkamer…" /></div>
      <div className="field"><label>Hoort bij huis</label><select value={homeId} onChange={(e) => setHomeId(e.target.value)}>{homes.map((h) => <option key={h.id} value={h.id}>{h.title}</option>)}</select></div>
      {status ? <p className="status-msg">{status}</p> : null}
      <button className="publish-bar" onClick={submit}><Check size={18} /> Maak kamer</button>
    </main>
  );
}

/* ---------- Home composer ---------- */
function HomeComposer({ auth, onBack }) {
  const [title, setTitle] = useState(''); const [desc, setDesc] = useState(''); const [style, setStyle] = useState(''); const [status, setStatus] = useState('');
  async function submit() {
    if (!title.trim()) { setStatus('Geef je huis een naam.'); return; }
    try { await auth.req('/api/homes', { method: 'POST', body: JSON.stringify({ title, description: desc, style_text: style, cover_url: DEFAULT_COVER }) }); setStatus('Huisprofiel aangemaakt! Voeg nu kamers toe.'); }
    catch (e) { setStatus(`Mislukt: ${e.message}`); }
  }
  return (
    <main className="screen">
      <ComposerHead onBack={onBack} title="Huisprofiel" subtitle="De basis van je interieurpagina" />
      <div className="fcard" style={{ marginBottom: 18 }}>
        <div className="fcard-media" style={{ aspectRatio: '16/10' }}><img src={DEFAULT_COVER} alt="" /><div className="fcard-grad" /><div className="fcard-top"><div className="fcard-id"><strong>{title || 'Jouw huisnaam'}</strong><span>{style || 'Stijlrichting'}</span></div></div></div>
        <div className="fcard-body"><p className="fcard-caption">{desc || 'Korte bio over je interieur of verbouwing.'}</p></div>
      </div>
      <div className="field"><label>Naam</label><input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Bijv. Villa Rutte" /></div>
      <div className="field"><label>Bio</label><textarea value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="Vertel kort over je huis." /></div>
      <div className="field"><label>Stijl</label><input value={style} onChange={(e) => setStyle(e.target.value)} placeholder="Japandi, hotel chique, minimal…" /></div>
      {status ? <p className="status-msg">{status}</p> : null}
      <button className="publish-bar" onClick={submit}><Check size={18} /> Bewaar huisprofiel</button>
    </main>
  );
}

export function Studio({ auth, onPosted, initialMode = 'studioHome' }) {
  const [mode, setMode] = useState(initialMode === 'studioHome' ? 'studioHome' : initialMode);
  if (mode === 'update') return <UpdateComposer auth={auth} onBack={() => setMode('studioHome')} onPosted={onPosted} />;
  if (mode === 'room') return <RoomComposer auth={auth} onBack={() => setMode('studioHome')} />;
  if (mode === 'home') return <HomeComposer auth={auth} onBack={() => setMode('studioHome')} />;
  return <StudioHome auth={auth} setMode={setMode} />;
}
