// components/Feed.jsx — content-first feed. Geen permanente hero; de eerste
// kamerupdate staat bovenaan. Elke kaart toont huis, kamer, fase-voortgang,
// en social-acties. Tik op de foto opent altijd de room-timeline.
import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Heart, MessageCircle, Bookmark, X } from 'lucide-react';
import { TopBar, BrandLogo, EmptyState } from './Layout';
import { FALLBACK_FEED } from '../data/fallback';

const WELCOME_KEY = 'roomarc_welcome_dismissed';

function FeedCard({ item, auth, onOpenRoom, index }) {
  const [liked, setLiked] = useState(item.liked);
  const [likes, setLikes] = useState(item.likes_count || 0);
  const [saved, setSaved] = useState(item.saved);
  const [following, setFollowing] = useState(item.following_room);
  const [pop, setPop] = useState(false);

  async function toggleLike(e) {
    e.stopPropagation();
    setPop(true); setTimeout(() => setPop(false), 350);
    const next = !liked; setLiked(next); setLikes((n) => n + (next ? 1 : -1));
    try { const r = await auth.req(`/api/updates/${item.id}/like`, { method: 'POST' }); if (r) { setLiked(r.liked); setLikes(r.likes_count); } } catch {}
  }
  async function toggleSave(e) {
    e.stopPropagation();
    const next = !saved; setSaved(next);
    try { await auth.req(`/api/updates/${item.id}/save`, { method: next ? 'POST' : 'DELETE' }); } catch { setSaved(!next); }
  }
  async function toggleFollow(e) {
    e.stopPropagation();
    const next = !following; setFollowing(next);
    try { await auth.req(`/api/rooms/${item.room.id}/follow`, { method: next ? 'POST' : 'DELETE' }); } catch { setFollowing(!next); }
  }

  // Fase-voortgang: toon "fase X" met dots als hint dat dit een tijdlijn is.
  const phaseIndex = item._phaseIndex ?? 0;
  const phaseTotal = item._phaseTotal ?? 0;

  return (
    <motion.article className="fcard" style={{ animationDelay: `${index * 0.05}s` }}>
      <div className="fcard-media" onClick={() => onOpenRoom(item.room.id)}>
        <img src={item.media_url} alt={item.phase_label} loading="lazy" />
        <div className="fcard-grad" />
        <div className="fcard-top">
          <div className="fcard-avatar">{(item.home.title || 'R')[0]}</div>
          <div className="fcard-id">
            <strong>{item.home.title}</strong>
            <span>{item.room.name}</span>
          </div>
        </div>
        <div className="phase-chip">
          {phaseTotal > 1 && (
            <span className="dots">
              {Array.from({ length: Math.min(phaseTotal, 6) }).map((_, i) => (
                <span key={i} className={`dot ${i <= phaseIndex ? 'on' : ''}`} />
              ))}
            </span>
          )}
          <strong>{item.phase_label}</strong>
        </div>
      </div>
      <div className="fcard-body">
        <p className="fcard-caption">{item.caption}</p>
        <div className="fcard-actions">
          <button className={`act-btn ${liked ? 'on' : ''}`} onClick={toggleLike}>
            <Heart size={20} fill={liked ? 'currentColor' : 'none'} className={pop ? 'heart-pop' : ''} /> {likes > 0 ? likes : ''}
          </button>
          <button className="act-btn" onClick={() => onOpenRoom(item.room.id)}>
            <MessageCircle size={20} /> {item.comments_count > 0 ? item.comments_count : ''}
          </button>
          <button className={`act-btn save ${saved ? 'on' : ''}`} onClick={toggleSave}>
            <Bookmark size={20} fill={saved ? 'currentColor' : 'none'} />
          </button>
          <span className="act-spacer" />
          <button className={`follow-pill ${following ? 'on' : ''}`} onClick={toggleFollow}>
            {following ? 'Gevolgd' : 'Volg kamer'}
          </button>
        </div>
      </div>
    </motion.article>
  );
}

export function Feed({ auth, onOpenRoom }) {
  const [items, setItems] = useState(null);
  const [error, setError] = useState(false);
  const [showWelcome, setShowWelcome] = useState(!localStorage.getItem(WELCOME_KEY));

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        await auth.req('/api/seed-demo', { method: 'POST' });
        const data = await auth.req('/api/feed/following');
        if (!alive) return;
        const list = Array.isArray(data) && data.length ? data : FALLBACK_FEED;
        // Bereken fase-index per kamer voor de voortgang-hint.
        const perRoom = {};
        list.forEach((u) => { perRoom[u.room.id] = (perRoom[u.room.id] || 0) + 1; });
        const seen = {};
        list.forEach((u) => { seen[u.room.id] = (seen[u.room.id] || 0); u._phaseTotal = perRoom[u.room.id]; u._phaseIndex = seen[u.room.id]; seen[u.room.id] += 1; });
        setItems(list);
      } catch {
        if (alive) { setItems(FALLBACK_FEED); setError(true); }
      }
    })();
    return () => { alive = false; };
  }, []);

  function dismissWelcome() { localStorage.setItem(WELCOME_KEY, '1'); setShowWelcome(false); }

  return (
    <main className="screen">
      <TopBar logo actions={null} />

      {showWelcome && (
        <motion.div className="welcome-strip" initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }}>
          <button className="dismiss" onClick={dismissWelcome}><X size={18} /></button>
          <h3>Welkom bij Roomarc</h3>
          <p>Volg kamers terwijl ze veranderen. Tik op een kamer om de hele tijdlijn te scrubben.</p>
          <div className="ws-row">
            <button className="primary" onClick={dismissWelcome}>Aan de slag</button>
          </div>
        </motion.div>
      )}

      {items === null && (
        <div className="feed-list">
          {[0, 1].map((i) => <div key={i} className="skeleton" style={{ aspectRatio: '4/5' }} />)}
        </div>
      )}

      {items && items.length > 0 && (
        <div className="feed-list">
          {items.map((item, i) => <FeedCard key={item.id} item={item} auth={auth} onOpenRoom={onOpenRoom} index={i} />)}
        </div>
      )}

      {items && items.length === 0 && (
        <EmptyState icon={<Heart size={24} />} title="Je feed is nog leeg" text="Volg een paar kamers in Ontdek en zie ze hier groeien." />
      )}
    </main>
  );
}
