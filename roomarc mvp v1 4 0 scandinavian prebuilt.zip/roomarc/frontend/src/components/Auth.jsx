// components/Auth.jsx — splash + login/registratie in de nieuwe stijl.
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { BrandLogo } from './Layout';
import { DEFAULT_COVER } from '../data/fallback';

export function Splash() {
  return (
    <div className="splash">
      <motion.div className="splash-inner" initial={{ opacity: 0, scale: 0.94 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.6 }}>
        <BrandLogo size="lg" />
        <p className="tagline">Kamers die leven door de tijd</p>
      </motion.div>
    </div>
  );
}

export function Auth({ auth }) {
  const [mode, setMode] = useState('intro'); // intro | login | register
  const [form, setForm] = useState({ email: '', password: '', username: '', display_name: '' });
  const [busy, setBusy] = useState(false);
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    if (mode === 'login') await auth.login(form.email, form.password);
    else await auth.register(form);
    setBusy(false);
  }

  if (mode === 'intro') {
    return (
      <div className="auth-screen">
        <div className="auth-hero">
          <BrandLogo size="lg" />
          <h1>Volg kamers die<br />door de tijd groeien.</h1>
          <p>Geen losse plaatjes. Echte ruimtes, fase voor fase — van leeg tot afgestyled.</p>
          <motion.div className="auth-visual" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15, duration: 0.6 }}>
            <img src={DEFAULT_COVER} alt="" />
          </motion.div>
        </div>
        <div className="auth-actions">
          <button className="btn-primary" onClick={auth.loginDemo}>Bekijk de demo</button>
          <button className="btn-ghost" onClick={() => setMode('register')}>Account aanmaken</button>
          <p className="auth-switch">Al een account? <button onClick={() => setMode('login')}>Inloggen</button></p>
          {auth.error ? <p className="auth-error">{auth.error}</p> : null}
        </div>
      </div>
    );
  }

  return (
    <div className="auth-screen">
      <div className="auth-hero" style={{ flex: 'none', marginBottom: 24 }}>
        <BrandLogo size="lg" />
        <h1 style={{ fontSize: 26, marginTop: 16 }}>{mode === 'login' ? 'Welkom terug' : 'Maak je account'}</h1>
      </div>
      <form className="auth-form" onSubmit={submit}>
        {mode === 'register' && (
          <>
            <input placeholder="Weergavenaam" value={form.display_name} onChange={(e) => set('display_name', e.target.value)} required />
            <input placeholder="Gebruikersnaam" value={form.username} onChange={(e) => set('username', e.target.value)} required />
          </>
        )}
        <input type="email" placeholder="E-mail" value={form.email} onChange={(e) => set('email', e.target.value)} required />
        <input type="password" placeholder="Wachtwoord" value={form.password} onChange={(e) => set('password', e.target.value)} required />
        {auth.error ? <p className="auth-error">{auth.error}</p> : null}
        <button className="btn-primary" type="submit" disabled={busy} style={{ marginTop: 6 }}>
          {busy ? 'Even geduld…' : mode === 'login' ? 'Inloggen' : 'Account aanmaken'}
        </button>
      </form>
      <p className="auth-switch">
        {mode === 'login' ? 'Nog geen account? ' : 'Al een account? '}
        <button onClick={() => setMode(mode === 'login' ? 'register' : 'login')}>{mode === 'login' ? 'Aanmaken' : 'Inloggen'}</button>
        {' · '}<button onClick={() => setMode('intro')}>Terug</button>
      </p>
    </div>
  );
}
