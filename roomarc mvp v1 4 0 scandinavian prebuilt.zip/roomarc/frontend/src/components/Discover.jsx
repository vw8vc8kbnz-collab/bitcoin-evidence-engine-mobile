// components/Discover.jsx — content-first ontdekken. Volledig defensief:
// elke data-tak valt terug op een lege array, nooit een wit scherm.
import React, { useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Compass, TrendingUp } from 'lucide-react';
import { TopBar, EmptyState } from './Layout';

const STYLES = ['Alles', 'Japandi', 'Mediterraan', 'Industrieel', 'Minimal', 'Warm', 'Klein wonen'];

function match(item, style) {
  if (style === 'Alles') return true;
  const hay = `${item.title || ''} ${item.name || ''} ${item.style_text || ''} ${item.room_type || ''}`.toLowerCase();
  return hay.includes(style.toLowerCase().split(' ')[0]);
}

export function Discover({ auth, openHome, openRoom }) {
  const [data, setData] = useState(null);
  const [query, setQuery] = useState('');
  const [style, setStyle] = useState('Alles');

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        await auth.req('/api/seed-demo', { method: 'POST' });
        const res = await auth.req('/api/discover');
        if (alive) setData(res || {});
      } catch { if (alive) setData({}); }
    })();
    return () => { alive = false; };
  }, []);

  const homes = data?.homes ?? [];
  const rooms = data?.rooms ?? [];
  const updates = data?.updates ?? [];
  const q = query.trim().toLowerCase();

  const fHomes = useMemo(() => homes.filter((h) => match(h, style) && `${h.title} ${h.style_text}`.toLowerCase().includes(q)), [homes, style, q]);
  const fRooms = useMemo(() => rooms.filter((r) => match(r, style) && `${r.name} ${r.home_title} ${r.style_text}`.toLowerCase().includes(q)), [rooms, style, q]);

  return (
    <main className="screen">
      <TopBar title="Ontdek" />

      <div className="search-bar">
        <Search size={18} color="var(--ink-faint)" />
        <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Zoek stijl, kamer of huis…" />
      </div>

      <div className="style-chips scroll-hide">
        {STYLES.map((s) => <button key={s} className={`style-chip ${style === s ? 'active' : ''}`} onClick={() => setStyle(s)}>{s}</button>)}
      </div>

      {data === null && (
        <div className="discover-grid">
          {[0, 1, 2, 3].map((i) => <div key={i} className="skeleton" style={{ aspectRatio: '3/4' }} />)}
        </div>
      )}

      {data !== null && (
        <>
          {fHomes.length > 0 && (
            <>
              <div className="section-head"><h2>Populaire huizen</h2><span className="more">{fHomes.length}</span></div>
              <div className="discover-grid">
                {fHomes.slice(0, 6).map((h, i) => (
                  <motion.button key={h.id} className="disc-tile" style={{ animationDelay: `${i * 0.04}s` }} onClick={() => openHome(h.slug)}>
                    <div className="dt-img"><img src={h.cover_url} alt={h.title} loading="lazy" /><div className="dt-overlay" /></div>
                    <div className="dt-badge"><TrendingUp size={11} style={{ display: 'inline', verticalAlign: '-1px' }} /> {h.followers || 0}</div>
                    <div className="dt-cap"><strong>{h.title}</strong><span>{h.style_text}</span></div>
                  </motion.button>
                ))}
              </div>
            </>
          )}

          {fRooms.length > 0 && (
            <>
              <div className="section-head"><h2>Kamer-tijdlijnen</h2><span className="more">Open direct</span></div>
              <div className="discover-grid">
                {fRooms.slice(0, 6).map((r, i) => (
                  <motion.button key={r.id} className="disc-tile" style={{ animationDelay: `${i * 0.04}s` }} onClick={() => openRoom(r.id)}>
                    <div className="dt-img"><img src={r.cover_url} alt={r.name} loading="lazy" /><div className="dt-overlay" /></div>
                    <div className="dt-cap"><strong>{r.name}</strong><span>{r.updates} fases · {r.latest_phase || 'Nieuw'}</span></div>
                  </motion.button>
                ))}
              </div>
            </>
          )}

          {fHomes.length === 0 && fRooms.length === 0 && (
            <EmptyState icon={<Compass size={24} />} title={q || style !== 'Alles' ? 'Niets gevonden' : 'Nog niets te ontdekken'} text={q || style !== 'Alles' ? 'Probeer een andere stijl of zoekterm.' : 'Maak je eerste huisprofiel in de Studio.'} />
          )}
        </>
      )}
    </main>
  );
}
