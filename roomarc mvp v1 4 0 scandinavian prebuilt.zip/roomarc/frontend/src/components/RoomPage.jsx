// components/RoomPage.jsx — het signature-moment. Cinematic dark overlay met
// een tijdlijn-scrub: sleep door de tijd en de foto's cross-faden live mee.
// "Maximaal indrukwekkend": volledig scherm beeld, glas-overlays, progress glow.
import React, { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, Heart, MessageCircle, Bookmark, Send } from 'lucide-react';

export function RoomPage({ roomId, auth, onClose }) {
  const [room, setRoom] = useState(null);
  const [error, setError] = useState(false);
  const [scrub, setScrub] = useState(0);          // kommagetal 0..(n-1)
  const [dragging, setDragging] = useState(false);
  const [showComments, setShowComments] = useState(false);
  const trackRef = useRef(null);

  async function load() {
    try {
      const data = await auth.req(`/api/rooms/${roomId}`);
      setRoom(data);
      setScrub(Math.max(0, (data.updates?.length || 1) - 1));
    } catch { setError(true); }
  }
  useEffect(() => { load(); }, [roomId]);

  if (error) {
    return (
      <motion.div className="room-overlay" initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }}>
        <button className="room-back" onClick={onClose}><ChevronLeft size={22} /></button>
        <div style={{ color: '#fff', textAlign: 'center', paddingTop: '40vh' }}>Kamer kon niet laden.</div>
      </motion.div>
    );
  }
  if (!room) {
    return (
      <motion.div className="room-overlay" initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }}>
        <div className="skeleton" style={{ position: 'absolute', inset: 0, borderRadius: 0 }} />
      </motion.div>
    );
  }

  const updates = room.updates || [];
  const n = updates.length;
  const posFromX = (clientX) => {
    const t = trackRef.current; if (!t || n < 2) return 0;
    const b = t.getBoundingClientRect();
    return Math.min(1, Math.max(0, (clientX - b.left) / b.width)) * (n - 1);
  };
  const onDown = (e) => { setDragging(true); setScrub(posFromX(e.clientX ?? e.touches?.[0]?.clientX)); };
  const onMove = (e) => { if (!dragging) return; const x = e.clientX ?? e.touches?.[0]?.clientX; if (x != null) setScrub(posFromX(x)); };
  const onUp = () => { if (dragging) { setDragging(false); setScrub((p) => Math.round(p)); } };

  const lo = Math.floor(scrub), hi = Math.min(n - 1, lo + 1), mix = scrub - lo;
  const loU = updates[lo] || {}, hiU = updates[hi] || {};
  const active = mix < 0.5 ? loU : hiU;
  const idx = Math.round(scrub);
  const transformPct = n > 1 ? Math.round((idx / (n - 1)) * 100) : 100;

  return (
    <motion.div className="room-overlay" initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }} transition={{ type: 'spring', damping: 30, stiffness: 230 }}>
      {/* Cinematic gelaagde beeldweergave met cross-fade */}
      <div className="room-stage">
        <img className="room-layer" src={loU.media_url || room.cover_url} alt="" draggable={false} />
        {hiU.id && hiU.id !== loU.id && (
          <img className="room-layer top" src={hiU.media_url} style={{ opacity: mix }} alt="" draggable={false} />
        )}
        <div className="room-stage-grad" />
      </div>

      {/* Top bar */}
      <div className="room-top">
        <button className="room-back" onClick={onClose}><ChevronLeft size={22} /></button>
        <div className="room-title">
          <span>{room.home?.title}</span>
          <strong>{room.name}</strong>
        </div>
      </div>

      {/* Onderste glas-paneel met fase-info + scrub */}
      <div className="room-panel">
        <div className="room-progress-row">
          <div className="room-phase-info">
            <span className="eyebrow" style={{ color: 'rgba(255,255,255,0.6)' }}>Fase {idx + 1} van {n}</span>
            <h2>{active.phase_label || 'Tijdlijn'}</h2>
          </div>
          <div className="transform-score">
            <strong>{transformPct}%</strong>
            <span>transformatie</span>
          </div>
        </div>

        <p className="room-caption">{active.caption}</p>

        {/* De scrub-track */}
        <div
          ref={trackRef}
          className={`scrub ${dragging ? 'dragging' : ''}`}
          onMouseDown={onDown} onMouseMove={onMove} onMouseUp={onUp} onMouseLeave={onUp}
          onTouchStart={onDown} onTouchMove={onMove} onTouchEnd={onUp}
          role="slider" aria-valuemin={0} aria-valuemax={n - 1} aria-valuenow={idx}
        >
          <div className="scrub-line" />
          <div className="scrub-fill" style={{ width: `${n > 1 ? (scrub / (n - 1)) * 100 : 100}%` }} />
          {updates.map((u, i) => (
            <div key={u.id} className={`scrub-dot ${i <= idx ? 'past' : ''}`} style={{ left: `${n > 1 ? (i / (n - 1)) * 100 : 0}%` }} />
          ))}
          <div className="scrub-handle" style={{ left: `${n > 1 ? (scrub / (n - 1)) * 100 : 0}%` }}>
            <span className="scrub-glow" />
          </div>
        </div>

        <div className="scrub-labels">
          {updates.map((u, i) => (
            <button key={u.id} className={i === idx ? 'on' : ''} onClick={() => setScrub(i)}>{u.phase_label}</button>
          ))}
        </div>
      </div>
    </motion.div>
  );
}
