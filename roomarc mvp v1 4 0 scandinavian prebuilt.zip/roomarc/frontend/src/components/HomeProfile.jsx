// components/HomeProfile.jsx — een huisprofiel met al zijn kamers.
import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft } from 'lucide-react';

export function HomeProfile({ slug, auth, onClose, openRoom }) {
  const [home, setHome] = useState(null);
  const [following, setFollowing] = useState(false);

  async function load() {
    try { const d = await auth.req(`/api/homes/${slug}`); setHome(d); setFollowing(d.following); } catch { setHome(false); }
  }
  useEffect(() => { load(); }, [slug]);

  async function toggleFollow() {
    const next = !following; setFollowing(next);
    try { await auth.req(`/api/homes/${home.id}/follow`, { method: next ? 'POST' : 'DELETE' }); } catch { setFollowing(!next); }
  }

  if (home === false) {
    return (
      <motion.div className="home-overlay" initial={{ x: '100%' }} animate={{ x: 0 }} exit={{ x: '100%' }}>
        <div className="home-cover"><button className="hc-back" onClick={onClose}><ChevronLeft size={22} /></button></div>
        <p style={{ textAlign: 'center', padding: 40, color: 'var(--ink-soft)' }}>Huis kon niet laden.</p>
      </motion.div>
    );
  }
  if (!home) {
    return <motion.div className="home-overlay" initial={{ x: '100%' }} animate={{ x: 0 }} exit={{ x: '100%' }}><div className="skeleton" style={{ aspectRatio: '16/11', borderRadius: 0 }} /></motion.div>;
  }

  return (
    <motion.div className="home-overlay scroll-hide" initial={{ x: '100%' }} animate={{ x: 0 }} exit={{ x: '100%' }} transition={{ type: 'spring', damping: 30, stiffness: 240 }}>
      <div className="home-cover">
        <img src={home.cover_url} alt={home.title} />
        <div className="hc-grad" />
        <button className="hc-back" onClick={onClose}><ChevronLeft size={22} /></button>
        <div className="hc-info"><h1>{home.title}</h1><p>{home.style_text}</p></div>
      </div>

      <div className="home-meta">
        <button className={`follow-pill ${following ? 'on' : ''}`} onClick={toggleFollow}>{following ? 'Huis gevolgd' : 'Volg huis'}</button>
      </div>

      <div className="home-stat-row">
        <div className="hs"><strong>{home.stats?.rooms || 0}</strong><span>kamers</span></div>
        <div className="hs"><strong>{home.stats?.followers || 0}</strong><span>volgers</span></div>
        <div className="hs"><strong>{home.stats?.updates || 0}</strong><span>updates</span></div>
      </div>

      {home.description ? <p style={{ padding: '8px 20px 0', color: 'var(--ink-soft)', fontSize: 14 }}>{home.description}</p> : null}

      <div className="section-head" style={{ padding: '0 20px', marginBottom: 8 }}><h2>Kamers</h2></div>
      <div className="room-list">
        {(home.rooms || []).map((r) => (
          <button key={r.id} className="room-row" onClick={() => openRoom(r.id)}>
            <div className="rr-img"><img src={r.cover_url} alt={r.name} loading="lazy" /></div>
            <div className="rr-text"><strong>{r.name}</strong><span>{r.updates} fases · {r.followers} volgers</span></div>
            <span className="rr-phase">{r.latest_phase || 'Nieuw'}</span>
          </button>
        ))}
      </div>
    </motion.div>
  );
}
