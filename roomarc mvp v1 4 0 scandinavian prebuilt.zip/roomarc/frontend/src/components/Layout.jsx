// components/Layout.jsx — gedeelde primitieven: logo, topbar, lege staat, bottom nav.
import React from 'react';
import { Home, Compass, Plus, Bookmark, User } from 'lucide-react';

export function BrandLogo({ size = 'md', onDark = false }) {
  return (
    <span className={`brand-logo ${size} ${onDark ? 'on-dark' : ''}`}>
      <span className="room">Room</span><span className="arc">arc</span>
    </span>
  );
}

export function TopBar({ title, actions = null, logo = false }) {
  return (
    <header className="topbar">
      {logo ? <BrandLogo size="md" /> : <h1>{title}</h1>}
      <div className="tb-actions">{actions}</div>
    </header>
  );
}

export function EmptyState({ icon, title, text }) {
  return (
    <div className="empty-state">
      <div className="es-icon">{icon}</div>
      <strong>{title}</strong>
      <p>{text}</p>
    </div>
  );
}

const TABS = [
  ['feed', 'Feed', Home],
  ['discover', 'Ontdek', Compass],
  ['__create__', '', null],
  ['saves', 'Bewaard', Bookmark],
  ['profile', 'Profiel', User],
];

export function BottomNav({ active, onTab, onCreate }) {
  return (
    <nav className="bottom-nav">
      {TABS.map(([key, label, Icon]) => {
        if (key === '__create__') {
          return (
            <div className="nav-create" key="create">
              <button onClick={onCreate} aria-label="Maken"><Plus size={26} /></button>
            </div>
          );
        }
        return (
          <button key={key} className={`nav-item ${active === key ? 'active' : ''}`} onClick={() => onTab(key)}>
            <span className="nav-icon-wrap"><Icon size={23} strokeWidth={active === key ? 2.4 : 2} /><span className="nav-dot" /></span>
            <span>{label}</span>
          </button>
        );
      })}
    </nav>
  );
}
