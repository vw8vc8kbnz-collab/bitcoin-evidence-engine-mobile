// components/SavesProfile.jsx — Profiel als interieurportfolio (Instagram-stijl)
// met je eigen huizen/kamers/updates, plus Bewaard. Settings achter een icoon.
import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Settings, Grid, Home as HomeIcon, Bookmark, Bell, LogOut, X } from 'lucide-react';
import { TopBar, EmptyState } from './Layout';

export function Saves({ auth, openRoom }) {
  const [items, setItems] = useState(null);
  useEffect(() => { auth.req('/api/me/saves').then((d) => setItems(Array.isArray(d) ? d : [])).catch(() => setItems([])); }, []);
  return (
    <main className="screen">
      <TopBar title="Bewaard" />
      {items === null && <div className="portfolio-grid">{[0, 1, 2, 3].map((i) => <div key={i} className="skeleton" style={{ aspectRatio: 1 }} />)}</div>}
      {items && items.length > 0 && (
        <div className="portfolio-grid">
          {items.map((it) => (
            <motion.button key={it.id} className="disc-tile" onClick={() => openRoom(it.room.id)}>
              <div className="dt-img" style={{ aspectRatio: 1 }}><img src={it.media_url} alt={it.phase_label} loading="lazy" /><div className="dt-overlay" /></div>
              <div className="dt-cap"><strong style={{ fontSize: 13 }}>{it.room.name}</strong><span>{it.phase_label}</span></div>
            </motion.button>
          ))}
        </div>
      )}
      {items && items.length === 0 && <EmptyState icon={<Bookmark size={24} />} title="Nog niets bewaard" text="Bewaar updates uit je feed en vind ze hier terug." />}
    </main>
  );
}

function Settings_Sheet({ auth, onClose }) {
  return (
    <motion.div className="settings-sheet" initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }} transition={{ type: 'spring', damping: 30, stiffness: 240 }}>
      <div className="sheet-grip" />
      <div className="sheet-head"><strong>Instellingen</strong><button onClick={onClose}><X size={20} /></button></div>
      <div className="sheet-row"><span>Versie</span><span style={{ color: 'var(--ink-faint)' }}>Roomarc v1.4.0</span></div>
      <button className="sheet-action danger" onClick={auth.logout}><LogOut size={18} /> Uitloggen</button>
    </motion.div>
  );
}

export function Profile({ auth, openRoom, openHome }) {
  const [data, setData] = useState(null);
  const [tab, setTab] = useState('homes');
  const [activity, setActivity] = useState([]);
  const [settings, setSettings] = useState(false);

  useEffect(() => {
    auth.req('/api/me/homes').then((d) => setData(d || {})).catch(() => setData({}));
    auth.req('/api/activity').then((a) => setActivity(Array.isArray(a) ? a : [])).catch(() => setActivity([]));
  }, []);

  const stats = data?.stats ?? { homes: 0, rooms: 0, updates: 0, followers: 0 };
  const homes = data?.homes ?? [];
  const allRooms = homes.flatMap((h) => (h.rooms || []).map((r) => ({ ...r, home: h })));
  const allUpdates = allRooms.filter((r) => r.latest_update).map((r) => r.latest_update);

  return (
    <main className="screen">
      <TopBar title="Profiel" actions={<button className="icon-btn" onClick={() => setSettings(true)}><Settings size={20} /></button>} />

      <div className="profile-head">
        <div className="profile-top">
          <div className="profile-avatar">{(auth.me?.display_name || 'R')[0]}</div>
          <div className="profile-stats">
            <div className="profile-stat"><strong>{stats.homes}</strong><span>Huizen</span></div>
            <div className="profile-stat"><strong>{stats.rooms}</strong><span>Kamers</span></div>
            <div className="profile-stat"><strong>{stats.followers}</strong><span>Volgers</span></div>
          </div>
        </div>
        <div className="profile-name">
          <h2>{auth.me?.display_name || 'Demo Creator'}</h2>
          <span className="handle">@{auth.me?.username || 'demo'}</span>
          {homes[0]?.description ? <p className="bio">{homes[0].description}</p> : <p className="bio">Mijn interieurprojecten, kamer voor kamer.</p>}
          {homes[0]?.style_text ? <span className="style-tag">{homes[0].style_text}</span> : null}
        </div>
      </div>

      <div className="profile-tabs">
        <button className={tab === 'homes' ? 'active' : ''} onClick={() => setTab('homes')}>Huizen</button>
        <button className={tab === 'rooms' ? 'active' : ''} onClick={() => setTab('rooms')}>Kamers</button>
        <button className={tab === 'updates' ? 'active' : ''} onClick={() => setTab('updates')}>Updates</button>
        <button className={tab === 'activity' ? 'active' : ''} onClick={() => setTab('activity')}>Activiteit</button>
      </div>

      {data === null && <div className="discover-grid">{[0, 1].map((i) => <div key={i} className="skeleton" style={{ aspectRatio: '3/4' }} />)}</div>}

      {data !== null && tab === 'homes' && (
        homes.length ? (
          <div className="discover-grid">
            {homes.map((h) => (
              <motion.button key={h.id} className="disc-tile" onClick={() => openHome(h.slug)}>
                <div className="dt-img"><img src={h.cover_url} alt={h.title} loading="lazy" /><div className="dt-overlay" /></div>
                <div className="dt-cap"><strong>{h.title}</strong><span>{h.stats?.rooms || 0} kamers · {h.stats?.updates || 0} updates</span></div>
              </motion.button>
            ))}
          </div>
        ) : <EmptyState icon={<HomeIcon size={24} />} title="Nog geen huizen" text="Maak je eerste huisprofiel in de Studio." />
      )}

      {data !== null && tab === 'rooms' && (
        allRooms.length ? (
          <div className="discover-grid">
            {allRooms.map((r) => (
              <motion.button key={r.id} className="disc-tile" onClick={() => openRoom(r.id)}>
                <div className="dt-img"><img src={r.cover_url} alt={r.name} loading="lazy" /><div className="dt-overlay" /></div>
                <div className="dt-cap"><strong>{r.name}</strong><span>{r.updates} fases · {r.latest_phase || 'Nieuw'}</span></div>
              </motion.button>
            ))}
          </div>
        ) : <EmptyState icon={<Grid size={24} />} title="Nog geen kamers" text="Voeg kamers toe aan een huisprofiel." />
      )}

      {data !== null && tab === 'updates' && (
        allUpdates.length ? (
          <div className="portfolio-grid thirds">
            {allUpdates.map((u) => (
              <button key={u.id} className="disc-tile pg-tile" onClick={() => openRoom(u.room.id)}>
                <div className="dt-img" style={{ aspectRatio: 1 }}><img src={u.media_url} alt={u.phase_label} loading="lazy" /></div>
              </button>
            ))}
          </div>
        ) : <EmptyState icon={<Grid size={24} />} title="Nog geen updates" text="Plaats je eerste kamerupdate in de Studio." />
      )}

      {data !== null && tab === 'activity' && (
        activity.length ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {activity.map((a) => (
              <div key={a.id} className="project-card" style={{ cursor: 'default' }}>
                <div className="pc-img" style={{ display: 'grid', placeItems: 'center', background: 'var(--accent-wash)' }}><Bell size={20} color="var(--accent-deep)" /></div>
                <div className="pc-text"><strong style={{ fontSize: 14 }}>{a.message}</strong><span>{(a.created_at || '').slice(0, 16).replace('T', ' ')}</span></div>
              </div>
            ))}
          </div>
        ) : <EmptyState icon={<Bell size={24} />} title="Nog geen activiteit" text="Likes, reacties en nieuwe volgers verschijnen hier." />
      )}

      {settings && <Settings_Sheet auth={auth} onClose={() => setSettings(false)} />}
    </main>
  );
}
