// hooks/useAuth.js — authenticatiestatus + acties.
import { useState, useEffect, useCallback } from 'react';
import { apiRequest, getToken, setToken } from '../lib/api';

export function useAuth() {
  const [token, setTok] = useState(getToken());
  const [me, setMe] = useState(null);
  const [ready, setReady] = useState(false);
  const [error, setError] = useState('');

  const logout = useCallback(() => { setToken(''); setTok(''); setMe(null); }, []);

  useEffect(() => {
    if (!token) { setReady(true); return; }
    apiRequest('/api/auth/me')
      .then((u) => { setMe(u); setReady(true); })
      .catch(() => { logout(); setReady(true); });
  }, [token, logout]);

  async function loginDemo() {
    setError('');
    try {
      await apiRequest('/api/seed-demo', { method: 'POST' });
      const data = await apiRequest('/api/auth/login', { method: 'POST', body: JSON.stringify({ email: 'demo@roomarc.local', password: 'demo123' }) });
      setToken(data.token); setTok(data.token); setMe(data.user);
    } catch (e) { setError(e.message || 'Demo kon niet starten.'); }
  }

  async function login(email, password) {
    setError('');
    try {
      const data = await apiRequest('/api/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) });
      setToken(data.token); setTok(data.token); setMe(data.user); return true;
    } catch (e) { setError(e.message || 'Inloggen mislukt.'); return false; }
  }

  async function register(payload) {
    setError('');
    try {
      const data = await apiRequest('/api/auth/register', { method: 'POST', body: JSON.stringify(payload) });
      setToken(data.token); setTok(data.token); setMe(data.user); return true;
    } catch (e) { setError(e.message || 'Registreren mislukt.'); return false; }
  }

  return { token, me, ready, error, login, register, loginDemo, logout, req: apiRequest };
}
