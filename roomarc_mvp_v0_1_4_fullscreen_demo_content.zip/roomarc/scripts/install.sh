#!/usr/bin/env bash
set -euo pipefail
APP_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$APP_DIR"

echo "============================================================"
echo "ROOMARC v0.1.4 installer"
echo "============================================================"
echo "App dir: $APP_DIR"

pick_python() {
  if [ -n "${PYTHON_BIN:-}" ] && command -v "$PYTHON_BIN" >/dev/null 2>&1; then echo "$PYTHON_BIN"; return; fi
  for c in python3.12 python3.11 python3.10; do
    if command -v "$c" >/dev/null 2>&1; then echo "$c"; return; fi
  done
  if command -v python3 >/dev/null 2>&1; then echo python3; return; fi
  echo ""
}

PY="$(pick_python)"
if [ -z "$PY" ]; then
  echo "ERROR: no Python found. Install python3.12 + python3.12-venv first." >&2
  exit 1
fi
PY_VER="$($PY - <<'PYV'
import sys
print(f"{sys.version_info.major}.{sys.version_info.minor}")
PYV
)"
echo "Using Python: $PY ($PY_VER)"

if [ "$PY_VER" = "3.13" ]; then
  echo "Python 3.13 detected. This can force pydantic-core/pillow source builds on small VPS servers." >&2
  echo "Trying to install Python 3.12 automatically..." >&2
  if command -v sudo >/dev/null 2>&1; then
    sudo apt-get update || true
    sudo apt-get install -y python3.12 python3.12-venv python3.12-dev build-essential || true
  else
    apt-get update || true
    apt-get install -y python3.12 python3.12-venv python3.12-dev build-essential || true
  fi
  if command -v python3.12 >/dev/null 2>&1; then
    PY=python3.12
    PY_VER="$($PY - <<'PYV'
import sys
print(f"{sys.version_info.major}.{sys.version_info.minor}")
PYV
)"
    echo "Switched to Python: $PY ($PY_VER)"
  else
    echo "ERROR: Could not install/find Python 3.12 automatically." >&2
    echo "Run: sudo apt-get install -y python3.12 python3.12-venv python3.12-dev build-essential" >&2
    exit 1
  fi
fi

if [ ! -f .env ]; then
  cp .env.example .env
  echo "Created .env from .env.example"
fi

rm -rf .venv
"$PY" -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip setuptools wheel

# Prefer binary wheels. This prevents small VPS failures where pydantic-core/pillow try to compile from source.
pip install --only-binary=:all: -r backend/requirements.txt

# Frontend dist is already included in the ZIP. Rebuild only when npm is available and wanted.
if [ "${ROOMARC_REBUILD_FRONTEND:-0}" = "1" ]; then
  if command -v npm >/dev/null 2>&1; then
    echo "Rebuilding frontend..."
    cd frontend
    npm install
    npm run build
    cd "$APP_DIR"
  else
    echo "npm not found; using bundled frontend/dist."
  fi
else
  echo "Using bundled frontend/dist. Set ROOMARC_REBUILD_FRONTEND=1 to rebuild."
fi

echo "Installer done. Run: ./scripts/run_dev.sh"
