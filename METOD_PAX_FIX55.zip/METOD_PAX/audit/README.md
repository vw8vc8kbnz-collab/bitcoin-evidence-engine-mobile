# Actueel auditdossier — FIX55

FIX55 vereenvoudigt catalogus- en prijsafhankelijkheden zonder bedoelde wijzigingen in klantgedrag, prijzen of productie-uitvoer. Dit is een afgebakende eerste vervolgstap in W-04. Het dossier bevat eigen herhaalbare verificatie met AI-ondersteuning, geen onafhankelijke menselijke audit of certificering.

## Concrete wijziging

| Onderdeel | FIX54 | FIX55 |
| --- | ---: | ---: |
| Velden in `CatalogRuntimePorts` | 18 | 9 |
| Velden in `PricingRuntimePorts` | 25 | 20 |
| Centrale cachevariabelen voor deze private cataloguscaches | 4 | 0 |
| Regels in centrale Python-samenstelling | 1.970 | 1.914 |
| Bronbestanden in bestaande mypy-scope | 19 | 21 |

Elf verwijderde callbackvelden stuurden eigen methodeaanroepen via de centrale applicatiemodule terug naar dezelfde eigenaar. De module roept die methoden nu rechtstreeks aan. Drie andere velden leverden alleen private cacheobjecten en een hashlock aan. Die caches en hun levenscyclus horen nu bij `CatalogRuntime`. De centrale module bevat ook niet meer de materiaalnaam-cachelogica.

De bestaande functie-ingangen blijven gebonden aliases voor de andere domeinen. De HTTP-responsecache blijft expliciet gedeeld met de HTTP-handler. Materiaallock, publicatielock, lockvolgorde en catalogustransacties blijven behouden. De padsuppliers worden nog op het moment van gebruik geraadpleegd. Er is geen algemene servicezoeker, dynamische modulelookup of extra productiemodule toegevoegd om koppelingen te verbergen.

Dit is geen claim dat de hele applicatie klein of volledig ontkoppeld is. De centrale samenstelling telt nog 1.914 regels, andere domeinen hebben eigen terugkoppelingen en de frontend heeft nog browserglobals en omvangrijke CSS. W-04 blijft open. Private cacheglobals zijn geen ondersteunde uitbreidingsinterface; tests gebruiken de eigenaar en zijn expliciete dependencies.

## Bewijs van gelijk gedrag

Dezelfde probe is in afzonderlijke processen uitgevoerd tegen de onveranderde FIX54-bron (`f0281ecccc660606d6912928564f928ee2d9d28f`) en FIX55. De volledige JSON-resultaten van acht groepen zijn gelijk:

- Materiaalnaamvoorrang, 30 combinaties van codes/kandidaten, terugval en expliciete invalidatie.
- Cataloguslookup en automatische verversing na atomaire bestandsvervanging.
- Hashcache met een bestandswijziging waarbij grootte en mtime gelijk blijven.
- Echte cataloguspublicatie en rollback, met verversing van naam-, lookup- en HTTP-responsecaches.
- DXF-classificatie, migratie, dubbele bestandsnamen, inhoud en manifest.
- Prijsnormalisatie, opslaan, herladen, audit, ingetrokken goedkeuring, revisieconflict en ongeldige invoer zonder overschrijven.
- Achttien volledige offertes met verschillende aantallen, prijzen en vaste kosten.
- De gezaghebbende catalogus/prijsmomentopname inclusief hash.

Alleen de geïnjecteerde klok en gegenereerde prijsversiefilenamen zijn genormaliseerd. De inhoud van prijsversies, bedragen, fouttypen/-meldingen en bestandsresultaten blijven onderdeel van de vergelijking. De FIX54-fixture is vastgelegd vóór de refactor en is niet aangepast aan de nieuwe implementatie. `runtime-baseline-equivalence.json` bevat de hashes en afbakening.

Tien nieuwe regressietests bewaken deze resultaten, onafhankelijk cache-eigenaarschap, levende padsuppliers en het ontbreken van geïnjecteerde eigen methoden in de twee contracten. Dit verkleint het regressierisico, maar bewijst geen gelijkheid voor iedere mogelijke invoer of elke gelijktijdige uitvoering.

## Volledige verificatie

181 Python/API/regressietests slagen zonder failures, fouten of skips. Tien echte Chromium-browserproeven slagen: bestelling, Admin, bewerken/nerf/fouten, jobannulering en aanvraagannulering, elk op 1440 en 390 pixels. De zeven Node-annuleringstests blijven onderdeel van één Python-wrapper; ze worden niet als zeven extra Python-tests geteld.

De eerdere controles blijven actief: prijsdoorwerking met behoud van historische offertes, DXF-upload en export, geometrische grenzen, autorisatie, privacy, queue/finalisatie, echte nginx, versleuteld lokaal restic-herstel met applicatiestart en deploymentlocks. De FIX54-annuleringsproeven bewaren hun vijftien jobfouten en zestien aanvraagfouten per breedte. De aanvraagproef dient echt in en heropent de bestaande checkout via het foundation-lifecycle-event; dit is een expliciete componenttestopstelling, geen normale bedankknoproute.

Buildreproductie, syntax en Ruff slagen. De typecontrole is uitgebreid met de twee aangepaste domeinimplementaties en slaagt op 21 bronbestanden. Gemengde JSON-resultaten blijven expliciet dynamisch. Ruff controleert de bestaande regels F401/F821/F841; volledige strikte typering of een complete statische securityscan wordt niet geclaimd.

Frontendbron, templates, CSS, Admin en optimizer zijn ongewijzigd; de gegenereerde versieaanduiding en bijbehorende JavaScript-assetnaam veranderen wel. De prijsrekenformules en opslagformaten zijn niet aangepast. Nerf blijft standaard aan.

## Levering en herhalen

`VALIDATION.json` bindt vers bewijs aan de geteste code. `SOURCE_PROVENANCE.json` koppelt FIX55 aan zijn directe FIX54-ouder en de losse Git-bundle. Die bewijst de beschikbare lokale geschiedenis, geen onbekende eerdere upstreamgeschiedenis. De ZIP bevat actuele bron, installatie en bewijs, zonder Git-objecten, node_modules, caches, klantstate, oude auditdossiers of geneste ZIPs.

Volg `docs/TESTEN.md` en `docs/INSTALLATIE.md`. Verifieer de bronbundle met `tools/verify_source_provenance.py --bundle /pad/naar/METOD_PAX_FIX55_SOURCE.bundle` vanuit de schone release. De exacte ZIP krijgt daarnaast de standalone checksum-/installatiepreflight.

## Openstaande externe acceptatie

Er is geen VPS-installatie of externe CI-run uitgevoerd. Staging met de live Admin-workflow, echte iPhone/Safari en Android/Chrome, werkelijke IP/VPN-allowlist, versleutelde live state, extern backupaccount, herstel op een tweede server en onafhankelijke security/toegankelijkheid/productie-CAM-acceptatie blijven open. Chromium op 390 pixels is geen fysieke telefoontest; lokaal restic-herstel is geen extern herstelbewijs.

De bestaande backupgrenzen van 6 GiB budget en 2 GiB vrije reserve blijven gelijk. `productionGo` en `releaseEligible` blijven false totdat het benodigde externe bewijs aanwezig is.
