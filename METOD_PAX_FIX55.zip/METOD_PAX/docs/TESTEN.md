# Tests herhalen

Gebruik een ontwikkelmachine of CI-runner, niet de immutable live-map. De tests gebruiken tijdelijke state en synthetische klanten op `example.invalid`. Ze schrijven niet naar de live VPS.

## Afhankelijkheden en uitvoeren

Installeer Python 3.10 of hoger, Node 18 of hoger en de systeemprogramma's nginx en restic. De uitgevoerde referentietest gebruikte Python 3.12, Playwright 1.56.1 / Chromium 141, nginx 1.24 en restic 0.16.4.

```bash
python3 -m venv ../metod-test-venv
. ../metod-test-venv/bin/activate
pip install -r requirements-dev.txt
npm ci --ignore-scripts
npx playwright install chromium
npm run build:check
ruff check --no-cache app tools tests
python3 -B tools/check_types.py
python3 -B tools/run_tests.py --output ../metod-test-results
```

Kies voor iedere run een nieuwe uitvoermap. Stel `METOD_TEST_RESTIC` en `METOD_TEST_NGINX` in als de binaries niet op PATH staan. Op Linux zijn voor Chromium de gebruikelijke browserbibliotheken nodig; `npx playwright install --with-deps chromium` kan die op een testmachine installeren.

Alle npm/Python/browserpakketten moeten vooraf beschikbaar zijn; die eenmalige installatie kan internet vereisen. De functionele tests zelf hebben geen leverancierswebsite nodig. Catalogusafbeeldingen komen uit een expliciete fixturemap die uitsluitend in ontwikkelmodus mag worden gebruikt.

De geïsoleerde deploylocktests gebruiken echte Linux-bestandsrechten en `flock`. Hiervoor is root of wachtwoordloze `sudo` nodig op de testmachine; alleen tijdelijke testpaden worden gebruikt. De CI-runner ondersteunt dit standaard. Zonder deze mogelijkheid meldt de test een skip en volgt geen volledige PASS.

De runner weigert een volledige PASS als tests worden overgeslagen. `--unit-only` laat expliciet de browsers weg. De complete run voert regressies uit, doorloopt een bestelling op 1440 en 390 pixels en gebruikt die verse bestelling vervolgens in de Admin-browserproeven op beide breedtes, inclusief privacy-export en verwijdering. Daarna doorloopt hij bewerken/nerf/fouten/verwijderen en twee annuleerflows (berekening en ingediende aanvraag) op beide breedtes: tien browserjourneys in totaal.

De bewerkflow forceert tijdelijk een HTTP 503 voor DXF-bestanden. Toevoegen blijft geblokkeerd tot een echte herpoging slaagt.

`tests/browser-cancellation.cjs` controleert via de echte interface 500-JSON, 502-HTML, 503-tekst, lege/ongeldige/HTML-200-antwoorden, misleidende succesvelden, verkeerde referenties, 403, netwerkafbreken en een stagnerende antwoordbody. Statusregel én dialoog moeten veilig zijn; panelen, materiaalbatches, een echte nerfgroep, klantvelden, snapshots en herstelreferenties worden diep vergeleken. De productie-deadlines blijven ongewijzigd: 20 seconden voor jobtransport en 12 seconden voor aanvraagannulering. Daarna volgt een echte serverbevestiging en volledige reset, ook met bevroren klantsnapshots.

De aanvraagvariant dient eerst via de echte UI in. De normale bedankknoppen starten een nieuwe configuratie; daarom opent deze componentproef de bestaande annuleerinterface via het bestaande foundation-lifecycle-event, met de echte ontvangen aanvraagreferentie en capability. Dit is expliciete testopstelling, geen claim dat de normale bedankknop annuleert. Een storing bij jobopruiming ná bevestigde aanvraagannulering mag de succesvolle reset niet tegenhouden. De jobvariant controleert de echte 409 voor een reeds afgeronde berekening.

`test_cancellation.py` voert zeven Node-tests uit op het echte JavaScript-API-object en controleert daarnaast het backendcontract voor fout token, bevestiging en idempotente herhaling. De Node-tests bewaken ook herstelopslag tijdens time-outs vóór headers en tijdens de body; een te laat antwoord mag die opslag niet alsnog wissen. De netwerkfouten zijn uitsluitend geïnjecteerd in geïsoleerde tests.

## Gedragsvergelijking en module-eigenaarschap

`test_runtime_ownership.py` voegt tien regressietests toe. Acht daarvan vergelijken de echte applicatiesamenstelling met de vastgelegde FIX54-uitkomsten in `tests/fixtures/runtime-catalog-pricing-fix54.json`; de twee overige controleren onafhankelijk cache-eigenaarschap, levende padsuppliers en het ontbreken van geïnjecteerde eigen methoden in de twee modulecontracten. De complete suite telt nu 181 tests.

De probe draait met tijdelijke state in een apart proces; hij verandert geen bronbestanden. Hij vergelijkt materiaalnaamvoorrang, verversen na atomaire catalogusvervanging, een hash na wijziging met gelijke grootte en mtime, echte publicatie en rollback, DXF-migratie met dubbele bestandsnamen, prijsopslag/herladen/audit/revisieconflicten, ongeldige invoer, achttien volledige offertes en de prijsautoriteit inclusief hash. De klokport heeft een vaste waarde; willekeurige prijsversiefilenamen worden weggelaten, hun inhoud niet.

Om de vergelijking zelf opnieuw te maken, pak de FIX54-bron in een afzonderlijke map uit en voer dezelfde `tests/runtime_behavior_snapshot.py --release /pad/naar/bron` eenmaal voor FIX54 en eenmaal voor FIX55 uit. Vergelijk de volledige JSON-uitvoer. De opgeslagen fixture wordt niet opnieuw gegenereerd om een afwijking passend te maken.

De mypy-scope telt 21 bronbestanden, inclusief de twee gewijzigde domeinimplementaties. JSON-resultaten blijven deels dynamisch; geslaagde typecontrole betekent niet dat alle code strikt getypeerd is.

## Dekking en grenzen

- Auth-/Origin-grenzen van alle declaratieve API-routes; echte DXF-, prijs-, catalogus-, filter- en aanvraaghandelingen.
- Afronding op halve centen, gemengde materiaalprijzen, exacte kantenbandmeting, uitsluiten van vaste kosten en afwijzen van ongeldige prijzen/aantallen/btw.
- Exacte bruikbare plaatrand, rotatieverbod, grens van de tussenruimte, nerfstapelvolgorde en 60 vaste pseudo-willekeurige nestings: aantallen, identiteit, marges, afstand en rotatie onafhankelijk gecontroleerd.
- Admin-prijswijzigingen werken door in nieuwe berekeningen; oude verzegelde offertes blijven identiek.
- 46 echte DXF-sjablonen en 184 client-exportvarianten, waaronder spiegeling/verlenging; beschadigde geometrie wordt geweigerd.
- Queue, gelijktijdigheid, idempotency, toegangstokens, procesbeëindiging en finalisatie.
- Opmerkingen met leestekens, afzonderlijke factuur-/bezorgadressen, invoergrenzen en btw-presentatie.
- Secure-default, 2FA/replay, credentialrotatie, netwerkrestricties, CSRF, CSP, HEAD-lengte en trage HTTP-verbindingen.
- Formuleprefixen in paneelnamen (ook tab, onzichtbare prefix en Unicodevarianten) via parser en echte job-API; geldige template- en accentnamen blijven werken. Ongeldige staging-allowlists geven één duidelijke opstartmelding en houden Admin dicht; een verkeerde `METOD_HOST` of ongeldige productie-allowlist stopt het serverproces.
- Gedragsvergelijking met het vastgelegde FIX50-broncommit: 40 volledige nestinguitkomsten, 70 catalogusindelingen en 80 aanvraagsamenvattingen. Stickercoördinaten, rotaties, labels en kantenband hebben afzonderlijke controles.
- Klantdownload met bedrijf, factuur-/bezorgadres, opmerkingen en opgeslagen prijzen; interne tokens/paden en gegevens van andere klanten zijn uitgesloten. De interne volledige export vereist een afzonderlijke bevestiging.
- Nederlandse klantexportstatussen en datums, inclusief zomer-/wintertijd en ongeldige historische waarden. JSON en opgeslagen aanvraagbestanden behouden hun originele waarden.
- Echte nginxconfiguratie met 140 gelijktijdige onvolledige verbindingen (meer dan de backendlimiet van 128): gzip en immutable caching voor publieke JS/CSS; HTML en privéresponses blijven ongecomprimeerd.
- Backupvalidatie, veilige extractie, privacyverwijdering/herhaling na crash, versleutelde restic-repository, verkeerde sleutel en herstart van herstelde data.

De restic-test gebruikt een lokale versleutelde repository. Dat bewijst de werking van encryptie en herstel, niet dat jouw externe opslagaccount correct is ingericht. De browsers zijn echte Chromium-processen, maar de mobiele viewport is geen fysieke iPhone. Een onafhankelijke pentest, WCAG-audit, belastingtest onder productievolume en externe integratie-/CAM-acceptatie vallen buiten deze lokale testclaim.

## CI en lokale ontwikkeling

`ci/validate.yml` bevat dezelfde controleketen. Zet deze bij gebruik van de bron als repositoryroot onder `.github/workflows/validate.yml`. Een workflowdefinitie is nog geen geslaagde GitHub-run; die is in het gebruikersaccount niet uitgevoerd.

Voor een eigen lege ontwikkelomgeving maakt `tools/init_local_state.py --target /absoluut/nieuw/pad` de verplichte prijsmomentopname aan. Maak credentials met `tools/bootstrap_admin_credentials.py` via de interactieve invoer of `--password-stdin`; gebruik een afgeschermd bestand voor TOTP. Start uitsluitend lokaal met expliciete `DEV_MODE=1`, een loopbacklistener en de nieuwe state-map. De testsuite bevat een volledige synthetische catalogusfixture.
