#!/usr/bin/env python3
"""Verify the current code snapshot and, optionally, the supplied local Git bundle.

The original upstream author/tag history is not asserted. Three generated files
are outside the code commit to avoid a self-referential commit/hash cycle; their
integrity is covered by the release identity and artifact SHA-256 gates.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import tempfile

EXCLUDED = frozenset(
    {
        "RELEASE_IDENTITY.json",
        "SHA256SUMS.txt",
        "audit/SOURCE_PROVENANCE.json",
    }
)


def verify_snapshot(release: Path, bundle: Path | None = None) -> dict:
    release = release.resolve()
    record = json.loads((release / "audit/SOURCE_PROVENANCE.json").read_text())
    if record.get("schemaVersion") != 1 or record.get("revision") != "R9RC4_FIX55_DOMAIN_OWNERSHIP":
        raise ValueError("Invalid source provenance identity")
    if set(record.get("generatedFilesExcluded", [])) != EXCLUDED:
        raise ValueError("Source provenance exclusion list differs")
    if record.get("originalUpstreamHistoryVerified") is not False:
        raise ValueError("Original upstream history cannot be asserted")
    for key in ("baselineCommit", "codeCommit"):
        if not re.fullmatch(r"[a-f0-9]{40}", str(record.get(key, ""))):
            raise ValueError("Invalid Git commit identity")
    files = record.get("files")
    if not isinstance(files, dict) or not files:
        raise ValueError("Missing source file inventory")
    actual = {
        p.relative_to(release).as_posix(): p for p in release.rglob("*") if p.is_file() or p.is_symlink()
    }
    if set(actual) - EXCLUDED != set(files):
        raise ValueError("Source file inventory differs")
    git_blobs = {}
    for relative, expected in files.items():
        path = actual[relative]
        if (
            PurePosixPath(relative).is_absolute()
            or ".." in PurePosixPath(relative).parts
            or path.is_symlink()
        ):
            raise ValueError("Unsafe source path")
        payload = path.read_bytes()
        if hashlib.sha256(payload).hexdigest() != expected:
            raise ValueError("Source content differs: " + relative)
        git_blobs[relative] = hashlib.sha1(
            b"blob " + str(len(payload)).encode() + b"\0" + payload
        ).hexdigest()
    bundle_verified = False
    if bundle is not None:
        bundle = bundle.resolve(strict=True)
        env = dict(os.environ, GIT_CONFIG_NOSYSTEM="1", GIT_CONFIG_GLOBAL=os.devnull)
        with tempfile.TemporaryDirectory(prefix="metod-provenance-") as temporary:
            repository = Path(temporary) / "repository.git"

            def git(*arguments):
                result = subprocess.run(
                    ["git", "--git-dir=" + str(repository), *arguments],
                    env=env,
                    text=True,
                    capture_output=True,
                    timeout=60,
                    check=True,
                )
                return result.stdout

            git("init", "--bare")
            git("bundle", "verify", str(bundle))
            git("fetch", str(bundle), "refs/heads/main:refs/heads/main")
            tag = "fix55-domain-ownership"
            git("fetch", str(bundle), f"refs/tags/{tag}:refs/tags/{tag}")
            if git("rev-parse", f"refs/tags/{tag}^{{commit}}").strip() != record["codeCommit"]:
                raise ValueError("Bundle tag differs from code commit")
            if git("rev-parse", "refs/heads/main").strip() != record["codeCommit"]:
                raise ValueError("Bundle head differs from code commit")
            if git("rev-parse", record["codeCommit"] + "^").strip() != record["baselineCommit"]:
                raise ValueError("Bundle import boundary differs")
            entries = {}
            for line in git("ls-tree", "-r", "-z", record["codeCommit"]).split("\0"):
                if not line:
                    continue
                metadata, name = line.split("\t", 1)
                mode, kind, digest = metadata.split()
                if name in EXCLUDED:
                    raise ValueError("Generated metadata must remain outside the code commit")
                if kind != "blob" or mode not in ("100644", "100755"):
                    raise ValueError("Unsafe Git tree entry")
                entries[name] = digest
            if entries != git_blobs:
                raise ValueError("Git tree differs from delivered source snapshot")
            bundle_verified = True
    return {
        "status": "PASS",
        "files": len(files),
        "codeCommit": record["codeCommit"],
        "baselineCommit": record["baselineCommit"],
        "bundleVerified": bundle_verified,
        "originalUpstreamHistoryVerified": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--release", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--bundle", type=Path)
    arguments = parser.parse_args()
    print(json.dumps(verify_snapshot(arguments.release, arguments.bundle), indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
