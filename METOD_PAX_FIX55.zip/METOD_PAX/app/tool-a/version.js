// Generated from VERSION.json by tools/build_assets.cjs.
export const REVISION = "R9RC4_FIX55_DOMAIN_OWNERSHIP";
