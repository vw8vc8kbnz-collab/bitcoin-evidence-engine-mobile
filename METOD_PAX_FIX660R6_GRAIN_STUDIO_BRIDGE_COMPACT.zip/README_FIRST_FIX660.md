# METOD/PAX Tool A — FIX660 GRAIN STUDIO

Huidige revisie in dit pakket: **FIX660R6_COMPACT_GRAIN_PREVIEW_BRIDGE**.

Lees eerst `README_FIRST_FIX660R6.md` en `TECHNISCHE_OVERDRACHT_FIX660R6.md`.

Golden functionele scope blijft FIX660 Grain Studio; R6 repareert de mobile/preview-integratie en maakt de editor compacter zonder businesslogica te wijzigen.
