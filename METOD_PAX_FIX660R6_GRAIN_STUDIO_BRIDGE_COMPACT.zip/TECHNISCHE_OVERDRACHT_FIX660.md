# Technische overdracht — FIX660 Grain Studio

Dit pakket bevat revisie **FIX660R6**. De actuele overdracht staat in `TECHNISCHE_OVERDRACHT_FIX660R6.md`.
