# METOD/PAX FIX660R6 — Compact Grain Studio + Preview Bridge

Doel: de mobiele Doorlopende Nerf-flow betrouwbaar en compact maken zonder pricing, optimizer, library/taxonomy, submitflow of infrastructuur te wijzigen.

Belangrijkste fixes:
- Expliciete `ToolAGrainBridge` tussen de closure-scoped Tool A kern en losse Grain Studio modules.
- Preview kan echte paneelrefs, templates/boringen en geselecteerde nerfgroep nu daadwerkelijk lezen.
- Mobile beschikbare panelen = compacte rijen met één `+` actie per paneel.
- Mobile nerfgroep = compacte stack met positie, true-shape miniatuur, drag-handle en verwijderen.
- Autoritatieve volgorde blijft BOTTOM→TOP: eerste toegevoegd = positie 1 onderaan; volgende panelen stapelen erboven.
- Preview drawer start volledig gesloten; alleen grip/chevron is zichtbaar boven de vaste acties.
- Grain Studio assets gebruiken cachebuster `v=660r6`.
- Exacte werkelijke `widthMm` blijft harde groepsregel.

Live infrastructuur blijft ongewijzigd:
- Tool A: http://51.195.102.180:8790/
- Admin: http://51.195.102.180:8790/admin/
- Backend: 127.0.0.1:8792

De installer accepteert alleen de exact gehashte FIX660R5 live baseline of een reeds exact gelijke R6-doelbuild.
