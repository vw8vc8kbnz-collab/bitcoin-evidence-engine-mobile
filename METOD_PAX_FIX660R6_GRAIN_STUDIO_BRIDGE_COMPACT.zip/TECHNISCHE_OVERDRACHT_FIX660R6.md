# Technische overdracht — FIX660R6 Compact Grain Studio

## Baseline
FIX660R6 bouwt uitsluitend verder op FIX660R5. De businesskritische backend/pricing/optimizer/librarybestanden zijn byte-for-byte gelijk gebleven aan FIX660R5.

## Root cause van FIX660R5 preview/UI-probleem
De bestaande Tool A-kern draait grotendeels binnen een `DOMContentLoaded` closure. Grain Studio werd in losse JS-modules gebouwd, maar functies als `getGrainEntryByRef`, `rebuildGrainGroups`, `drawGrainPreview`, `syncGroupOrders` en template-loading waren niet op `window` beschikbaar.

Gevolg:
- de renderer zag `window.state.grain.groups` maar kon groepsrefs niet naar echte paneeldata resolven;
- hierdoor ontstond de valse melding `verschillende werkelijke breedtes`;
- de mobile module kon de closure-scoped `rebuildGrainEligible/rebuildGrainGroups` niet werkelijk overschrijven, waardoor de oude grote tegels met omhoog/omlaag-knoppen zichtbaar bleven;
- alleen de nieuwe CSS werkte, waardoor een hybride oude/nieuwe interface ontstond.

## FIX660R6 architectuur
`toolA.html` exposeert nu één beperkte `window.ToolAGrainBridge` met alleen Grain Studio-operaties/data. De legacy functies blijven intern closure-scoped.

De lokale kernentrypoints delegeren op mobile expliciet naar:
- `ToolAGrainStudioMobile.renderEligible()`
- `ToolAGrainStudioMobile.renderGroups()`
- `ToolAGrainStudioRenderer.render()`

De losse modules gebruiken uitsluitend de bridge voor paneelrefs, geselecteerd materiaal, groepsstate, order-sync, template lookup en gecontroleerde mutaties.

## Volgordecontract
`g.items` is autoritatief BOTTOM→TOP.
- `g.items[0]` = positie 1 = fysiek onderste paneel.
- Nieuw paneel: `g.items.push(ref)` = bovenop de bestaande stapel.
- DOM/canvas tonen TOP→BOTTOM via een presentatie-reverse.
- Drag-to-reorder schrijft de visuele TOP→BOTTOM lijst terug als `reverse()` naar BOTTOM→TOP.
- `grainOrder = index + 1` blijft productieautoriteit.

## Preview
De preview gebruikt:
- echte `widthMm` en paneelhoogte incl. verlengingen;
- één uniforme mm→px schaal voor de groep;
- geselecteerd materiaal via de FIX659 swatchrenderer;
- echte DXF holes/arcs via bridged template lookup;
- scharnier-mirroring;
- adaptieve 1px CNC-contrastkleur;
- collision-safe maatlabelrail.

## Mobile UX
Beschikbare panelen zijn compacte 50px-rijen met naam, maat/hinge, beschikbaarheid en één `+` knop. Iedere tik voegt exact één paneel bovenop de actieve set toe.

De actieve nerf-set gebruikt compacte stackrijen met:
- positiebadge;
- true-shape miniatuur;
- naam + maat;
- zespunts drag-handle;
- verwijderen.

De preview drawer is standaard gesloten. Alleen een kleine grip + chevron blijft zichtbaar. Annuleren/Toepassen blijft onafhankelijk fixed onderaan.

## Niet gewijzigd
Byte-for-byte gelijk aan FIX660R5:
- `server_py.py`
- `server_helpers.py`
- `pricing_helpers.py`
- `dxf_nesting_optimizer.py`
- `catalog_importer.py`
- `catalog_taxonomy.py`
- `decor_library.js`
- `toolA_material_swatch_renderer.js`
- `toolA_view_math_helpers.js`

Dus geen wijziging aan mixed-VAT, CSV-prijswaarheid, taxonomy, optimizer, submit-idempotency, security of URL/poort.
