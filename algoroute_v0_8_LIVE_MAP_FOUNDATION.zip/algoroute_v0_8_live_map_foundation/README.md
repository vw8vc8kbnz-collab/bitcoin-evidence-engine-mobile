# AlgoRoute v0.8 LIVE MAP FOUNDATION

Deze versie bouwt verder op v0.7 Cockpit Refactor en zet de Live Kaart neer als serieuze kernmodule.

## Nieuw in v0.8
- Live Kaart is nu een volwaardige hoofdmodule/pagina.
- Dashboard gebruikt kaart als cockpit-preview; Live Kaart heeft full operations view.
- API levert routes, voertuigen, stops, events en map-layers als echte JSON endpoints.
- Frontend haalt data uit API in plaats van alles hardcoded te tekenen.
- Vehicle detail overlay met stop-progress, ETA, route status en load summary.
- Donkere NL-map visual verder aangescherpt met route-glow, stop-markers en bewegende busjes.
- Basis voor latere MapLibre/OSM integratie voorbereid.

## Bewust nog placeholder
- Nog geen echte MapLibre/OpenStreetMap tiles.
- Nog geen echte GPS tracking.
- Nog geen echte OSRM/OR-Tools optimalisatie.
- Nog geen database; data komt uit JSON seed in API-container.

## Testen
Open http://<VPS-IP>:8787/
- Klik in sidebar op Live Kaart.
- Klik op busjes / routes.
- Check of overlay rechts wisselt.
- Check /api/health, /api/map/state en /api/routes.
