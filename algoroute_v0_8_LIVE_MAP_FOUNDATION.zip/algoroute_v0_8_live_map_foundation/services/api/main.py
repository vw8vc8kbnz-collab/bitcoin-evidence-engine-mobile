from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import os

app = FastAPI(title="AlgoRoute API", version=os.getenv("ALGOROUTE_VERSION", "0.8.0"))
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

VEHICLES = [
    {"id":"veh-01","name":"Bus 01","driver":"Milan","plate":"V-123-AB","status":"on_time","lat":52.3676,"lng":4.9041,"progress":74,"stops_done":13,"stops_total":18,"eta":"16:12","load":"5/6 pallets","battery":82,"speed":62},
    {"id":"veh-02","name":"Bus 02","driver":"Sanne","plate":"V-884-LK","status":"delay","lat":51.9244,"lng":4.4777,"progress":48,"stops_done":8,"stops_total":19,"eta":"17:05","load":"7/9 rolcontainers","battery":56,"speed":41},
    {"id":"veh-03","name":"Bus 03","driver":"Jeroen","plate":"V-447-ZR","status":"loading","lat":52.0907,"lng":5.1214,"progress":20,"stops_done":3,"stops_total":15,"eta":"18:01","load":"4/6 pallets","battery":91,"speed":0},
    {"id":"veh-04","name":"Bus 04","driver":"Nora","plate":"V-209-PT","status":"critical","lat":51.4416,"lng":5.4697,"progress":61,"stops_done":11,"stops_total":18,"eta":"16:44","load":"6/6 pallets","battery":22,"speed":78},
]

ROUTES = [
    {"id":"route-01","vehicle_id":"veh-01","name":"Noord-Holland Premium","color":"#2f8cff","km":184,"duration":"6u 12m","risk":"low","stops":[
        {"seq":1,"city":"Amsterdam","status":"done","eta":"08:42"},{"seq":2,"city":"Haarlem","status":"done","eta":"09:30"},{"seq":3,"city":"Alkmaar","status":"current","eta":"11:15"},{"seq":4,"city":"Hoorn","status":"planned","eta":"12:05"},{"seq":5,"city":"Amsterdam-Zuid","status":"planned","eta":"14:20"}]},
    {"id":"route-02","vehicle_id":"veh-02","name":"Rotterdam / Den Haag","color":"#00d6ff","km":211,"duration":"7u 05m","risk":"medium","stops":[
        {"seq":1,"city":"Delft","status":"done","eta":"08:51"},{"seq":2,"city":"Rotterdam","status":"current","eta":"10:55"},{"seq":3,"city":"Schiedam","status":"planned","eta":"12:30"},{"seq":4,"city":"Den Haag","status":"planned","eta":"15:40"}]},
    {"id":"route-03","vehicle_id":"veh-04","name":"Brabant EV Route","color":"#41f0a8","km":268,"duration":"8u 02m","risk":"high","stops":[
        {"seq":1,"city":"Eindhoven","status":"done","eta":"09:10"},{"seq":2,"city":"Tilburg","status":"done","eta":"10:40"},{"seq":3,"city":"Breda","status":"current","eta":"13:05"},{"seq":4,"city":"Roosendaal","status":"planned","eta":"15:25"}]}
]

EVENTS = [
    {"type":"traffic","title":"A16 vertraging +18 min","route":"Rotterdam / Den Haag","severity":"warning"},
    {"type":"load","title":"Bus 04 volledig beladen","route":"Brabant EV Route","severity":"critical"},
    {"type":"promise","title":"3 stops binnen belofte-window","route":"Noord-Holland Premium","severity":"ok"},
    {"type":"ev","title":"EV-range marge laag: 22% batterij","route":"Brabant EV Route","severity":"critical"}
]

@app.get('/api/health')
def health():
    return {"ok": True, "app": "AlgoRoute", "version": os.getenv("ALGOROUTE_VERSION", "0.8.0")}

@app.get('/api/vehicles')
def vehicles():
    return VEHICLES

@app.get('/api/routes')
def routes():
    return ROUTES

@app.get('/api/events')
def events():
    return EVENTS

@app.get('/api/map/state')
def map_state():
    return {"vehicles": VEHICLES, "routes": ROUTES, "events": EVENTS, "center": {"lat": 52.1, "lng": 5.25}, "mode":"dark_netherlands_foundation"}
