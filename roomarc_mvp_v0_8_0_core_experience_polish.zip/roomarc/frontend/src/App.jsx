import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { AnimatePresence } from 'framer-motion';
import { useAuth } from './hooks/useAuth';
import { Login, Splash } from './components/Auth';
import { BottomNav } from './components/Layout';
import { Feed } from './components/Feed';
import { Discover } from './components/Discover';
import { HomeProfile } from './components/HomeProfile';
import { RoomPage } from './components/RoomPage';
import { Studio } from './components/Studio';
import { Saves, Profile } from './components/SavesProfile';
import './style.css';

function App() {
  const auth = useAuth();
  const [showSplash, setShowSplash] = useState(true);
  const [tab, setTab] = useState('feed');
  const [roomId, setRoomId] = useState(null);
  const [homeSlug, setHomeSlug] = useState(null);
  const [feedVersion, setFeedVersion] = useState(0);

  useEffect(() => {
    const timer = setTimeout(() => setShowSplash(false), 1650);
    return () => clearTimeout(timer);
  }, []);

  if (!auth.token) {
    return (
      <>
        <Login auth={auth} />
        <AnimatePresence>{showSplash ? <Splash /> : null}</AnimatePresence>
      </>
    );
  }

  return (
    <div className="app-shell">
      <AnimatePresence>{showSplash ? <Splash /> : null}</AnimatePresence>
      <AnimatePresence>
        {homeSlug ? <HomeProfile key="home" slug={homeSlug} auth={auth} close={() => setHomeSlug(null)} openRoom={(id) => { setHomeSlug(null); setRoomId(id); }} /> : null}
        {roomId ? <RoomPage key="room" id={roomId} auth={auth} close={() => setRoomId(null)} /> : null}
      </AnimatePresence>

      {tab === 'feed' ? <Feed auth={auth} openRoom={setRoomId} openHome={setHomeSlug} version={feedVersion} setTab={setTab} /> : null}
      {tab === 'discover' ? <Discover auth={auth} openHome={setHomeSlug} /> : null}
      {tab === 'create' ? <Studio auth={auth} onPosted={() => { setFeedVersion((value) => value + 1); setTab('feed'); }} /> : null}
      {tab === 'saves' ? <Saves auth={auth} openRoom={setRoomId} /> : null}
      {tab === 'profile' ? <Profile auth={auth} /> : null}

      <BottomNav active={tab} setActive={setTab} />
    </div>
  );
}

createRoot(document.getElementById('root')).render(<App />);
