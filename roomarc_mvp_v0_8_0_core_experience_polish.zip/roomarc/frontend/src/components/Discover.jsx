import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { EmptyState, TopBar } from './Layout';

export function Discover({ auth, openHome }) {
  const [homes, setHomes] = useState([]);
  const [query, setQuery] = useState('');

  useEffect(() => {
    auth.req('/api/homes').then(setHomes).catch(() => setHomes([]));
  }, []);

  const filtered = homes.filter((home) => `${home.title} ${home.style_text}`.toLowerCase().includes(query.toLowerCase()));

  return (
    <main className="screen">
      <TopBar title="Ontdekken" subtitle="Huizen, kamers en stijlen" />
      <section className="search-card">
        <label>
          Zoek stijl of huis
          <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Japandi, industrieel, keuken..." />
        </label>
      </section>
      <section className="hero-strip">
        <strong>Ontdek echte interieurs</strong>
        <span>Geen losse plaatjes, maar huizen en kamers die door de tijd groeien.</span>
      </section>
      <div className="section-title"><h3>Populaire huisprofielen</h3><span>{filtered.length} homes</span></div>
      <div className="home-grid">
        {filtered.map((home) => (
          <motion.button className="home-tile" whileTap={{ scale: 0.98 }} onClick={() => openHome(home.slug)} key={home.id}>
            <img src={home.cover_url} alt={home.title} />
            <strong>{home.title}</strong>
            <span>{home.rooms} kamers · {home.followers} volgers</span>
          </motion.button>
        ))}
      </div>
      {!filtered.length ? <EmptyState title="Nog niets gevonden" text="Probeer een andere stijl of maak je eerste huisprofiel in Studio." /> : null}
    </main>
  );
}
