import { useEffect, useMemo, useState } from 'react';
import { request, seedDemo } from '../lib/api';

export function useAuth() {
  const [token, setToken] = useState(localStorage.getItem('roomarc_token') || '');
  const [me, setMe] = useState(null);

  const api = useMemo(() => ({
    req: (path, options = {}) => request(path, { token, ...options }),
  }), [token]);

  async function login(email = 'demo@roomarc.local', password = 'demo123') {
    await seedDemo();
    const data = await request('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    localStorage.setItem('roomarc_token', data.token);
    setToken(data.token);
    setMe(data.user);
  }

  function logout() {
    localStorage.removeItem('roomarc_token');
    setToken('');
    setMe(null);
  }

  useEffect(() => {
    if (!token) return;
    request('/api/auth/me', { token })
      .then(setMe)
      .catch(() => logout());
  }, [token]);

  return { token, me, login, logout, req: api.req };
}
