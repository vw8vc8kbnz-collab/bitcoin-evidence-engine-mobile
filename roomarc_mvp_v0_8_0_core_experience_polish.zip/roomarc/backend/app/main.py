import os, uuid, shutil, datetime, jwt
from pathlib import Path
from typing import Optional, List
from fastapi import FastAPI, HTTPException, Depends, UploadFile, File, Form, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from sqlalchemy import create_engine, Column, String, DateTime, ForeignKey, Text, Integer, UniqueConstraint
from sqlalchemy.orm import declarative_base, sessionmaker, relationship, Session
import hashlib, secrets
from pydantic import BaseModel

ROOT = Path(__file__).resolve().parents[2]
DATABASE_URL = os.getenv('DATABASE_URL', 'sqlite:///./roomarc.db')
JWT_SECRET = os.getenv('JWT_SECRET', 'dev-secret')
MEDIA_DIR = Path(os.getenv('MEDIA_DIR', str(ROOT/'storage'/'media')))
FRONTEND_DIST = Path(os.getenv('FRONTEND_DIST', str(ROOT/'frontend'/'dist')))
MEDIA_DIR.mkdir(parents=True, exist_ok=True)
engine = create_engine(DATABASE_URL, connect_args={'check_same_thread': False} if DATABASE_URL.startswith('sqlite') else {})
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()
def hash_password(password: str) -> str:
    salt = secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt.encode('utf-8'), 120000)
    return f'pbkdf2_sha256${salt}${dk.hex()}'

def verify_password(password: str, stored: str) -> bool:
    try:
        algo, salt, digest = stored.split('$', 2)
        if algo != 'pbkdf2_sha256': return False
        dk = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt.encode('utf-8'), 120000)
        return secrets.compare_digest(dk.hex(), digest)
    except Exception:
        return False

class User(Base):
    __tablename__='users'
    id=Column(String, primary_key=True, default=lambda:str(uuid.uuid4()))
    email=Column(String, unique=True, nullable=False)
    username=Column(String, unique=True, nullable=False)
    display_name=Column(String, nullable=False)
    password_hash=Column(String, nullable=False)
    avatar_url=Column(String)
    created_at=Column(DateTime, default=datetime.datetime.utcnow)

class Home(Base):
    __tablename__='homes'
    id=Column(String, primary_key=True, default=lambda:str(uuid.uuid4()))
    owner_user_id=Column(String, ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    title=Column(String, nullable=False)
    slug=Column(String, unique=True, nullable=False)
    description=Column(Text, default='')
    style_text=Column(String, default='')
    cover_url=Column(String, default='')
    created_at=Column(DateTime, default=datetime.datetime.utcnow)
    owner=relationship('User')

class Room(Base):
    __tablename__='rooms'
    id=Column(String, primary_key=True, default=lambda:str(uuid.uuid4()))
    home_id=Column(String, ForeignKey('homes.id', ondelete='CASCADE'), nullable=False)
    name=Column(String, nullable=False)
    room_type=Column(String, default='')
    cover_url=Column(String, default='')
    sort_order=Column(Integer, default=0)
    created_at=Column(DateTime, default=datetime.datetime.utcnow)
    home=relationship('Home')

class RoomUpdate(Base):
    __tablename__='room_updates'
    id=Column(String, primary_key=True, default=lambda:str(uuid.uuid4()))
    room_id=Column(String, ForeignKey('rooms.id', ondelete='CASCADE'), nullable=False)
    media_url=Column(String, nullable=False)
    caption=Column(Text, default='')
    phase_label=Column(String, default='')
    created_at=Column(DateTime, default=datetime.datetime.utcnow)
    room=relationship('Room')

class FollowHome(Base):
    __tablename__='follows_home'
    user_id=Column(String, ForeignKey('users.id', ondelete='CASCADE'), primary_key=True)
    home_id=Column(String, ForeignKey('homes.id', ondelete='CASCADE'), primary_key=True)
    created_at=Column(DateTime, default=datetime.datetime.utcnow)

class FollowRoom(Base):
    __tablename__='follows_room'
    user_id=Column(String, ForeignKey('users.id', ondelete='CASCADE'), primary_key=True)
    room_id=Column(String, ForeignKey('rooms.id', ondelete='CASCADE'), primary_key=True)
    created_at=Column(DateTime, default=datetime.datetime.utcnow)

class Save(Base):
    __tablename__='saves'
    user_id=Column(String, ForeignKey('users.id', ondelete='CASCADE'), primary_key=True)
    update_id=Column(String, ForeignKey('room_updates.id', ondelete='CASCADE'), primary_key=True)
    created_at=Column(DateTime, default=datetime.datetime.utcnow)

Base.metadata.create_all(bind=engine)
app = FastAPI(title='Roomarc API', version='0.8.0')
app.add_middleware(CORSMiddleware, allow_origins=['*'], allow_credentials=True, allow_methods=['*'], allow_headers=['*'])
app.mount('/media', StaticFiles(directory=str(MEDIA_DIR)), name='media')

def db():
    s=SessionLocal()
    try: yield s
    finally: s.close()

def token_for(u):
    return jwt.encode({'sub':u.id,'email':u.email,'exp':datetime.datetime.utcnow()+datetime.timedelta(days=30)}, JWT_SECRET, algorithm='HS256')

def current_user(request: Request, s: Session=Depends(db)):
    auth=request.headers.get('authorization','')
    if not auth.startswith('Bearer '): raise HTTPException(401,'Not authenticated')
    try: data=jwt.decode(auth.split(' ',1)[1], JWT_SECRET, algorithms=['HS256'])
    except Exception: raise HTTPException(401,'Invalid token')
    u=s.get(User, data['sub'])
    if not u: raise HTTPException(401,'User not found')
    return u

class LoginIn(BaseModel): email:str; password:str
class RegisterIn(BaseModel): email:str; password:str; username:str; display_name:str
class HomeIn(BaseModel): title:str; description:str=''; style_text:str=''; cover_url:str=''
class RoomIn(BaseModel): name:str; room_type:str=''; cover_url:str=''
class UpdateIn(BaseModel): media_url:str; caption:str=''; phase_label:str=''

def slugify(v):
    base=''.join(c.lower() if c.isalnum() else '-' for c in v).strip('-') or 'home'
    while '--' in base: base=base.replace('--','-')
    return base[:60]

def counts_home(s, home_id):
    return {'rooms':s.query(Room).filter_by(home_id=home_id).count(),'followers':s.query(FollowHome).filter_by(home_id=home_id).count(),'updates':s.query(RoomUpdate).join(Room).filter(Room.home_id==home_id).count()}

def ser_update(s,u,up):
    r=up.room; h=r.home
    return {'id':up.id,'media_url':up.media_url,'caption':up.caption,'phase_label':up.phase_label,'created_at':up.created_at.isoformat(), 'room':{'id':r.id,'name':r.name,'cover_url':r.cover_url}, 'home':{'id':h.id,'title':h.title,'slug':h.slug,'cover_url':h.cover_url}, 'saved': bool(s.get(Save, {'user_id':u.id,'update_id':up.id})) if u else False, 'following_room': bool(s.get(FollowRoom, {'user_id':u.id,'room_id':r.id})) if u else False, 'following_home': bool(s.get(FollowHome, {'user_id':u.id,'home_id':h.id})) if u else False}

@app.get('/api/health')
def health(): return {'ok':True,'app':'Roomarc','version':'0.8.0','features':['nederlandse-app','home-profile-redesign','roomarc-studio','foundation-refactor','split-components','protected-timeline-scrub','stable-studio','mobile-fullscreen','local-upload-flow']}

@app.post('/api/auth/register')
def register(x:RegisterIn, s:Session=Depends(db)):
    if s.query(User).filter((User.email==x.email)|(User.username==x.username)).first(): raise HTTPException(409,'Email or username already exists')
    u=User(email=x.email, username=x.username, display_name=x.display_name, password_hash=hash_password(x.password))
    s.add(u); s.commit(); s.refresh(u)
    return {'token':token_for(u),'user':{'id':u.id,'email':u.email,'username':u.username,'display_name':u.display_name}}

@app.post('/api/auth/login')
def login(x:LoginIn, s:Session=Depends(db)):
    u=s.query(User).filter_by(email=x.email).first()
    if not u or not verify_password(x.password,u.password_hash): raise HTTPException(401,'Wrong credentials')
    return {'token':token_for(u),'user':{'id':u.id,'email':u.email,'username':u.username,'display_name':u.display_name}}

@app.get('/api/auth/me')
def me(u:User=Depends(current_user)): return {'id':u.id,'email':u.email,'username':u.username,'display_name':u.display_name}

@app.post('/api/seed-demo')
def seed(s:Session=Depends(db)):
    u=s.query(User).filter_by(email='demo@roomarc.local').first()
    if not u:
        u=User(email='demo@roomarc.local', username='demo', display_name='Demo Creator', password_hash=hash_password('demo123'))
        s.add(u); s.commit(); s.refresh(u)

    def ensure_home(title, slug, description, style_text, cover_url, rooms):
        h=s.query(Home).filter_by(slug=slug).first()
        if not h:
            h=Home(owner_user_id=u.id,title=title,slug=slug,description=description,style_text=style_text,cover_url=cover_url)
            s.add(h); s.commit(); s.refresh(h)
        for i,room in enumerate(rooms):
            name, typ, img, phases = room
            r=s.query(Room).filter_by(home_id=h.id, name=name).first()
            if not r:
                r=Room(home_id=h.id,name=name,room_type=typ,cover_url=img,sort_order=i)
                s.add(r); s.commit(); s.refresh(r)
            if s.query(RoomUpdate).filter_by(room_id=r.id).count() < len(phases):
                # clean only demo-room updates for deterministic richer examples
                for old in s.query(RoomUpdate).filter_by(room_id=r.id).all():
                    s.delete(old)
                s.commit()
                for j,(phase, caption, media) in enumerate(phases):
                    when=datetime.datetime.utcnow()-datetime.timedelta(days=(len(phases)-j)*4)
                    up=RoomUpdate(room_id=r.id,media_url=media or img,phase_label=phase,caption=caption,created_at=when)
                    s.add(up)
                s.commit()
        # Follow demo rooms/homes so the feed feels alive immediately.
        if not s.get(FollowHome, {'user_id':u.id,'home_id':h.id}):
            s.add(FollowHome(user_id=u.id, home_id=h.id))
        for r in s.query(Room).filter_by(home_id=h.id).limit(2).all():
            if not s.get(FollowRoom, {'user_id':u.id,'room_id':r.id}):
                s.add(FollowRoom(user_id=u.id, room_id=r.id))
        s.commit()
        return h

    ensure_home('The Atelier House','the-atelier-house','Een rustig stadsappartement dat kamer voor kamer warmer wordt.','Japandi / warm minimal / natuurlijke materialen','https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&w=1400&q=85',[
        ('Woonkamer','living','https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1400&q=85',[
            ('Startpunt','De basis is leeg en rustig gehouden zodat de ruimte stap voor stap kan groeien.','https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=1400&q=85'),
            ('Muren afgerond','De muren zijn warmer geworden en de ruimte voelt meteen zachter.','https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=1400&q=85'),
            ('Meubels geplaatst','De bank, het lage dressoir en zachte texturen brengen de kamer tot leven.','https://images.unsplash.com/photo-1618220179428-22790b461013?auto=format&fit=crop&w=1400&q=85'),
            ('Gestyled','Planten, kunst en warm licht maken de woonkamer af zonder druk te worden.','https://images.unsplash.com/photo-1615873968403-89e068629265?auto=format&fit=crop&w=1400&q=85'),
        ]),
        ('Keuken','kitchen','https://images.unsplash.com/photo-1556911220-bff31c812dba?auto=format&fit=crop&w=1400&q=85',[
            ('Eerste indeling','De keuken is compact, maar de routing klopt al goed.','https://images.unsplash.com/photo-1556911220-bff31c812dba?auto=format&fit=crop&w=1400&q=85'),
            ('Materialen gekozen','Lichte steen, rustige fronten en messing details vormen de nieuwe richting.','https://images.unsplash.com/photo-1600489000022-c2086d79f9d4?auto=format&fit=crop&w=1400&q=85'),
            ('Details toegevoegd','Open planken en zachte verlichting geven de keuken meer persoonlijkheid.','https://images.unsplash.com/photo-1565538810643-b5bdb714032a?auto=format&fit=crop&w=1400&q=85'),
        ]),
    ])
    ensure_home('Casa Verde','casa-verde','Een mediterraan huis met veel groen, terracotta en buitengevoel.','Mediterranean / earthy / plants','https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1400&q=85',[
        ('Eethoek','dining','https://images.unsplash.com/photo-1617104678098-de229db51175?auto=format&fit=crop&w=1400&q=85',[
            ('Ruwe basis','De eethoek heeft veel daglicht maar mist nog warmte.','https://images.unsplash.com/photo-1617104678098-de229db51175?auto=format&fit=crop&w=1400&q=85'),
            ('Terracotta laag','Een aardse wandkleur maakt de ruimte direct zachter.','https://images.unsplash.com/photo-1616046229478-9901c5536a45?auto=format&fit=crop&w=1400&q=85'),
            ('Groen toegevoegd','Grote planten maken de overgang naar buiten veel natuurlijker.','https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=1400&q=85'),
        ]),
        ('Patio','outdoor','https://images.unsplash.com/photo-1600566752355-35792bedcfea?auto=format&fit=crop&w=1400&q=85',[
            ('Leeg terras','Het terras is functioneel, maar nog geen plek waar je lang blijft zitten.','https://images.unsplash.com/photo-1600566752355-35792bedcfea?auto=format&fit=crop&w=1400&q=85'),
            ('Zitplek gemaakt','Lage zitplekken en linnen kussens geven de patio een vakantiegevoel.','https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&w=1400&q=85'),
        ]),
    ])
    ensure_home('Loft Noord','loft-noord','Industrieel loftappartement met staal, hout en zachte contrasten.','Industrial / loft / warm contrast','https://images.unsplash.com/photo-1600607687644-c7171b42498b?auto=format&fit=crop&w=1400&q=85',[
        ('Werkplek','office','https://images.unsplash.com/photo-1593062096033-9a26b09da705?auto=format&fit=crop&w=1400&q=85',[
            ('Lege hoek','De werkhoek was praktisch, maar voelde nog tijdelijk.','https://images.unsplash.com/photo-1593062096033-9a26b09da705?auto=format&fit=crop&w=1400&q=85'),
            ('Op maat bureau','Een lang blad maakt de lijn rustiger en geeft meer werkruimte.','https://images.unsplash.com/photo-1593476550610-87baa860004a?auto=format&fit=crop&w=1400&q=85'),
            ('Lichtplan af','Wandlampen en indirect licht halen de harde kantoorlook eruit.','https://images.unsplash.com/photo-1497366754035-f200968a6e72?auto=format&fit=crop&w=1400&q=85'),
        ]),
        ('Slaapkamer','bedroom','https://images.unsplash.com/photo-1616594039964-ae9021a400a0?auto=format&fit=crop&w=1400&q=85',[
            ('Moodboard gekozen','Donker textiel en warm hout worden de basis.','https://images.unsplash.com/photo-1616594039964-ae9021a400a0?auto=format&fit=crop&w=1400&q=85'),
            ('Textiel geplaatst','De kamer voelt zachter zonder de loft-sfeer te verliezen.','https://images.unsplash.com/photo-1617325247661-675ab4b64ae2?auto=format&fit=crop&w=1400&q=85'),
        ]),
    ])
    ensure_home('Studio Sand','studio-sand','Kleine huurwoning met slimme, budgetvriendelijke updates.','Small space / budget / soft minimal','https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1400&q=85',[
        ('Hal','hall','https://images.unsplash.com/photo-1616486029423-aaa4789e8c9a?auto=format&fit=crop&w=1400&q=85',[
            ('Smal begin','De hal is smal en kaal, maar heeft mooie hoogte.','https://images.unsplash.com/photo-1616486029423-aaa4789e8c9a?auto=format&fit=crop&w=1400&q=85'),
            ('Spiegelwand','Een grote spiegel maakt de ruimte lichter en ruimer.','https://images.unsplash.com/photo-1600573472550-8090b5e0745e?auto=format&fit=crop&w=1400&q=85'),
        ]),
        ('Badkamer','bathroom','https://images.unsplash.com/photo-1600566753151-384129cf4e3e?auto=format&fit=crop&w=1400&q=85',[
            ('Huurwoning basis','De badkamer kon niet verbouwd worden, dus styling moest het verschil maken.','https://images.unsplash.com/photo-1600566753151-384129cf4e3e?auto=format&fit=crop&w=1400&q=85'),
            ('Hotelgevoel','Textiel, manden en warm licht maken het direct luxer.','https://images.unsplash.com/photo-1600607688969-a5bfcd646154?auto=format&fit=crop&w=1400&q=85'),
        ]),
    ])
    return {'ok':True,'demo_login':'demo@roomarc.local / demo123','demo_homes':4}

@app.get('/api/homes')
def homes(s:Session=Depends(db), u:User=Depends(current_user)):
    return [{**{'id':h.id,'title':h.title,'slug':h.slug,'description':h.description,'style_text':h.style_text,'cover_url':h.cover_url}, **counts_home(s,h.id), 'following':bool(s.get(FollowHome,{'user_id':u.id,'home_id':h.id}))} for h in s.query(Home).order_by(Home.created_at.desc()).all()]

@app.post('/api/homes')
def create_home(x:HomeIn, s:Session=Depends(db), u:User=Depends(current_user)):
    base=slugify(x.title); slug=base; n=2
    while s.query(Home).filter_by(slug=slug).first(): slug=f'{base}-{n}'; n+=1
    h=Home(owner_user_id=u.id,title=x.title,slug=slug,description=x.description,style_text=x.style_text,cover_url=x.cover_url)
    s.add(h); s.commit(); s.refresh(h); return {'id':h.id,'slug':h.slug}

@app.get('/api/homes/{slug}')
def get_home(slug:str, s:Session=Depends(db), u:User=Depends(current_user)):
    h=s.query(Home).filter_by(slug=slug).first()
    if not h: raise HTTPException(404,'Home not found')
    rooms=[]
    for r in s.query(Room).filter_by(home_id=h.id).order_by(Room.sort_order).all():
        rooms.append({'id':r.id,'name':r.name,'room_type':r.room_type,'cover_url':r.cover_url,'followers':s.query(FollowRoom).filter_by(room_id=r.id).count(),'updates':s.query(RoomUpdate).filter_by(room_id=r.id).count(),'following':bool(s.get(FollowRoom,{'user_id':u.id,'room_id':r.id}))})
    return {'id':h.id,'title':h.title,'slug':h.slug,'description':h.description,'style_text':h.style_text,'cover_url':h.cover_url,'owner':h.owner.display_name,'stats':counts_home(s,h.id),'following':bool(s.get(FollowHome,{'user_id':u.id,'home_id':h.id})),'rooms':rooms}

@app.post('/api/homes/{home_id}/follow')
def follow_home(home_id:str, s:Session=Depends(db), u:User=Depends(current_user)):
    if not s.get(Home,home_id): raise HTTPException(404,'Home not found')
    if not s.get(FollowHome,{'user_id':u.id,'home_id':home_id}): s.add(FollowHome(user_id=u.id,home_id=home_id)); s.commit()
    return {'following':True}

@app.delete('/api/homes/{home_id}/follow')
def unfollow_home(home_id:str, s:Session=Depends(db), u:User=Depends(current_user)):
    f=s.get(FollowHome,{'user_id':u.id,'home_id':home_id})
    if f: s.delete(f); s.commit()
    return {'following':False}

@app.post('/api/homes/{home_id}/rooms')
def create_room(home_id:str, x:RoomIn, s:Session=Depends(db), u:User=Depends(current_user)):
    h=s.get(Home,home_id)
    if not h or h.owner_user_id!=u.id: raise HTTPException(404,'Home not found')
    r=Room(home_id=home_id,name=x.name,room_type=x.room_type,cover_url=x.cover_url,sort_order=s.query(Room).filter_by(home_id=home_id).count())
    s.add(r); s.commit(); s.refresh(r); return {'id':r.id}

@app.get('/api/rooms/{room_id}')
def get_room(room_id:str, s:Session=Depends(db), u:User=Depends(current_user)):
    r=s.get(Room,room_id)
    if not r: raise HTTPException(404,'Room not found')
    ups=s.query(RoomUpdate).filter_by(room_id=room_id).order_by(RoomUpdate.created_at.asc()).all()
    return {'id':r.id,'name':r.name,'room_type':r.room_type,'cover_url':r.cover_url,'home':{'id':r.home.id,'title':r.home.title,'slug':r.home.slug},'followers':s.query(FollowRoom).filter_by(room_id=r.id).count(),'following':bool(s.get(FollowRoom,{'user_id':u.id,'room_id':r.id})),'updates':[ser_update(s,u,x) for x in ups]}

@app.post('/api/rooms/{room_id}/follow')
def follow_room(room_id:str, s:Session=Depends(db), u:User=Depends(current_user)):
    if not s.get(Room,room_id): raise HTTPException(404,'Room not found')
    if not s.get(FollowRoom,{'user_id':u.id,'room_id':room_id}): s.add(FollowRoom(user_id=u.id,room_id=room_id)); s.commit()
    return {'following':True}

@app.delete('/api/rooms/{room_id}/follow')
def unfollow_room(room_id:str, s:Session=Depends(db), u:User=Depends(current_user)):
    f=s.get(FollowRoom,{'user_id':u.id,'room_id':room_id})
    if f: s.delete(f); s.commit()
    return {'following':False}

@app.post('/api/rooms/{room_id}/updates')
def create_update(room_id:str, x:UpdateIn, s:Session=Depends(db), u:User=Depends(current_user)):
    r=s.get(Room,room_id)
    if not r or r.home.owner_user_id!=u.id: raise HTTPException(404,'Room not found')
    up=RoomUpdate(room_id=room_id,media_url=x.media_url,caption=x.caption,phase_label=x.phase_label)
    s.add(up); s.commit(); s.refresh(up); return {'id':up.id}

@app.get('/api/feed/following')
def feed(s:Session=Depends(db), u:User=Depends(current_user)):
    home_ids=[x.home_id for x in s.query(FollowHome).filter_by(user_id=u.id).all()]
    room_ids=[x.room_id for x in s.query(FollowRoom).filter_by(user_id=u.id).all()]
    q=s.query(RoomUpdate).join(Room)
    if home_ids or room_ids:
        q=q.filter((Room.home_id.in_(home_ids)) | (Room.id.in_(room_ids)))
    ups=q.order_by(RoomUpdate.created_at.desc()).limit(50).all()
    if not ups: ups=s.query(RoomUpdate).order_by(RoomUpdate.created_at.desc()).limit(20).all()
    return [ser_update(s,u,x) for x in ups]

@app.post('/api/updates/{update_id}/save')
def save(update_id:str, s:Session=Depends(db), u:User=Depends(current_user)):
    if not s.get(RoomUpdate,update_id): raise HTTPException(404,'Update not found')
    if not s.get(Save,{'user_id':u.id,'update_id':update_id}): s.add(Save(user_id=u.id,update_id=update_id)); s.commit()
    return {'saved':True}

@app.delete('/api/updates/{update_id}/save')
def unsave(update_id:str, s:Session=Depends(db), u:User=Depends(current_user)):
    sv=s.get(Save,{'user_id':u.id,'update_id':update_id})
    if sv: s.delete(sv); s.commit()
    return {'saved':False}

@app.get('/api/me/saves')
def saves(s:Session=Depends(db), u:User=Depends(current_user)):
    ids=[x.update_id for x in s.query(Save).filter_by(user_id=u.id).all()]
    ups=s.query(RoomUpdate).filter(RoomUpdate.id.in_(ids)).order_by(RoomUpdate.created_at.desc()).all() if ids else []
    return [ser_update(s,u,x) for x in ups]

@app.post('/api/media/upload')
def upload(file:UploadFile=File(...), u:User=Depends(current_user)):
    ext=Path(file.filename or 'upload.jpg').suffix.lower() or '.jpg'
    name=f'{uuid.uuid4()}{ext}'
    path=MEDIA_DIR/name
    with path.open('wb') as f: shutil.copyfileobj(file.file,f)
    return {'url':f'/media/{name}','storage':'local-dev'}

# SPA fallback
if FRONTEND_DIST.exists():
    app.mount('/assets', StaticFiles(directory=str(FRONTEND_DIST/'assets')), name='assets')
    @app.get('/{full_path:path}')
    def spa(full_path:str):
        p=FRONTEND_DIST/full_path
        if p.exists() and p.is_file():
            resp = FileResponse(str(p))
            resp.headers['Cache-Control']='no-store, no-cache, must-revalidate, max-age=0'
            return resp
        resp = FileResponse(str(FRONTEND_DIST/'index.html'))
        resp.headers['Cache-Control']='no-store, no-cache, must-revalidate, max-age=0'
        return resp
