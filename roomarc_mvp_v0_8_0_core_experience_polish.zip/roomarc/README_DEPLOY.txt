ROOMARC MVP v0.8.0

Install/update:
cd ~ && rm -rf roomarc-src roomarc-unpack roomarc && git clone https://github.com/vw8vc8kbnz-collab/bitcoin-evidence-engine-mobile.git roomarc-src && mkdir -p roomarc-unpack && unzip -oq roomarc-src/roomarc_mvp_v0_8_0_core_experience_polish.zip -d roomarc-unpack && bash roomarc-unpack/install_roomarc.sh

Open:
http://SERVER-IP:8899

Demo login:
demo@roomarc.local / demo123

Nieuw in v0.8.0:
- meer voorbeeldhuizen/kamers van anderen
- rijkere feed met huizen-rail
- feedkaart opent nadrukkelijk de kamer-tijdlijn
- timeline-scrub visueel groter en vloeiender
- rijkere demo seed-data
- foundation refactor blijft behouden
