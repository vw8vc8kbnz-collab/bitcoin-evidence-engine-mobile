# AlgoRoute v2.0.1 — CSV Upload Board Hotfix

Fix: CSV upload on Planning Board now gives immediate feedback and opens AI Mapping automatically.
