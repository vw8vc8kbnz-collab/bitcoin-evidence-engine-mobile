BEE Live Forecast V4.1.4 Stable Flat

Nieuwe functies:
- --inspect-live-data
- --simulate-from-cache
- --simulate-scenario panic|neutral
- --golden-row <UTC-hour>
- betere NO_TRADE debug output
- live API cache voor simulatie
- timezone-aware datetime fixes

Upload deze ZIP in GitHub root. Laat oude live forecast ZIPs liefst weg.
