#!/usr/bin/env bash
set -euo pipefail
BASE="${BEE_BASE:-/home/ubuntu/bitcoin-engine-deploy/current}"
cd "$BASE/live_forecast"
if [ -f ".venv/bin/activate" ]; then
  source ".venv/bin/activate"
elif [ -f "$BASE/.venv/bin/activate" ]; then
  source "$BASE/.venv/bin/activate"
fi
rm -f /home/ubuntu/bee_latest_export.zip /home/ubuntu/bee_live_debug_export*.zip || true
python bee_live_forecast_v4_1_paper.py --export-debug
LATEST="$(find "$BASE" /home/ubuntu/bitcoin-engine-deploy/releases -name 'bee_live_debug_export_*.zip' -type f 2>/dev/null | sort | tail -1 || true)"
if [ -n "$LATEST" ] && [ -f "$LATEST" ]; then
  cp "$LATEST" /home/ubuntu/bee_latest_export.zip
  cp "$LATEST" /home/ubuntu/bee_live_debug_export.zip
fi
echo "EXPORT READY: /home/ubuntu/bee_latest_export.zip"
ls -lah /home/ubuntu/bee_latest_export.zip /home/ubuntu/bee_live_debug_export.zip
