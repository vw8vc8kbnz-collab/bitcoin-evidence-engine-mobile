#!/usr/bin/env bash
set -euo pipefail
BASE="${BEE_BASE:-/home/ubuntu/bitcoin-engine-deploy/current}"
HOME_EXPORT="/home/ubuntu/bee_latest_export.zip"
LEGACY_EXPORT="/home/ubuntu/bee_live_debug_export.zip"
cd "$BASE"

echo "============================================================"
echo "BEE Live Forecast V4.1.11 — mobile one-line verify/export"
echo "============================================================"

echo "[0/9] Cleaning old SFTP exports in /home/ubuntu..."
rm -f /home/ubuntu/bee_latest_export.zip /home/ubuntu/bee_live_debug_export*.zip /home/ubuntu/export.zip || true

echo "[1/9] Installing live_forecast dependencies (config preserved)..."
chmod +x scripts/install_live_forecast.sh
./scripts/install_live_forecast.sh

cd "$BASE/live_forecast"
if [ -f ".venv/bin/activate" ]; then
  source ".venv/bin/activate"
elif [ -f "$BASE/.venv/bin/activate" ]; then
  source "$BASE/.venv/bin/activate"
else
  echo "ERROR: no venv found"
  exit 10
fi

echo "[2/9] Checking active script version/options..."
python bee_live_forecast_v4_1_paper.py --help | grep -E "test-trade-ntfy|force-notify|export-debug|inspect-live-data" >/dev/null
python - <<'PY'
import re, pathlib
s=pathlib.Path('bee_live_forecast_v4_1_paper.py').read_text()
m=re.search(r'VERSION\s*=\s*"([^"]+)"', s)
version=m.group(1) if m else 'unknown'
print('ACTIVE_VERSION:', version)
if 'v4.1.11' not in version:
    raise SystemExit('ERROR: active script is not v4.1.11. Wrong ZIP was deployed/unpacked.')
PY

echo "[3/9] Validating config + ntfy topic..."
python - <<'PY'
import json, os, sys, pathlib
cfg_path=pathlib.Path('bee_live_config.json')
if not cfg_path.exists():
    raise SystemExit('ERROR: live_forecast/bee_live_config.json does not exist')
cfg=json.load(open(cfg_path))
topic=(os.environ.get('BEE_NTFY_TOPIC') or cfg.get('ntfy_topic') or '').strip()
server=(cfg.get('ntfy_server') or 'https://ntfy.sh').strip()
if (not topic) or topic == 'PASTE_PRIVATE_NTFY_TOPIC_HERE' or 'PASTE' in topic.upper() or 'PLACEHOLDER' in topic.upper():
    print('ERROR: ntfy_topic is missing or still placeholder in live_forecast/bee_live_config.json')
    print('Open: nano /home/ubuntu/bitcoin-engine-deploy/current/live_forecast/bee_live_config.json')
    print('Set for example: "ntfy_topic": "your-secret-topic"')
    sys.exit(2)
print('CONFIG_OK paper_only=', cfg.get('paper_only'), 'ntfy_server=', server, 'topic_len=', len(topic), 'active=', cfg.get('active_specialists'))
PY

echo "[4/9] Testing live fetch/build..."
python bee_live_forecast_v4_1_paper.py --test-fetch

echo "[5/9] Sending basic ntfy test push..."
python bee_live_forecast_v4_1_paper.py --test-ntfy

echo "[6/9] Sending synthetic PAPER TRADE ntfy push (entry/TP/SL/model stats)..."
python bee_live_forecast_v4_1_paper.py --test-trade-ntfy

echo "[7/9] Running real live once with --force-notify (proves server -> ntfy route for current decision)..."
python bee_live_forecast_v4_1_paper.py --once --force-notify

echo "[8/9] Creating debug export and overwriting fixed SFTP names..."
python bee_live_forecast_v4_1_paper.py --export-debug

# Hard final cleanup/copy. Always make only predictable files in /home/ubuntu.
echo "[9/9] Final mobile export bridge..."
LATEST="$(find "$BASE" /home/ubuntu/bitcoin-engine-deploy/releases -name 'bee_live_debug_export_*.zip' -type f 2>/dev/null | sort | tail -1 || true)"
if [ -z "$LATEST" ] || [ ! -f "$LATEST" ]; then
  echo "ERROR: no timestamped debug export found"
  exit 20
fi
rm -f /home/ubuntu/bee_latest_export.zip /home/ubuntu/bee_live_debug_export*.zip /home/ubuntu/export.zip || true
cp "$LATEST" "$HOME_EXPORT"
cp "$LATEST" "$LEGACY_EXPORT"

echo ""
echo "============================================================"
echo "DONE — CHECK YOUR PHONE NOW"
echo "You should have received TWO ntfy pushes:"
echo "  1) basic BEE test"
echo "  2) paper trade test with entry/TP/SL"
echo "Export ready for Termius SFTP:"
echo "  $HOME_EXPORT"
echo "Go to: Connect via SFTP -> home -> ubuntu -> bee_latest_export.zip"
echo "============================================================"
ls -lah "$HOME_EXPORT" "$LEGACY_EXPORT"
