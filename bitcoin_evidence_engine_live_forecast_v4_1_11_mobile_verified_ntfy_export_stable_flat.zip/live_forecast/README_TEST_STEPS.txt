# BEE Live Forecast V4.1.9 — Data Simulation / Golden Test Mode

Deze versie is bedoeld om live data veilig te controleren voordat je de loop continu laat draaien.

## Belangrijkste testcommando’s

```bash
cd /home/ubuntu/bitcoin-engine-deploy/current/live_forecast
source ../.venv/bin/activate
python bee_live_forecast_v4_1_paper.py --inspect-live-data
python bee_live_forecast_v4_1_paper.py --simulate-from-cache
python bee_live_forecast_v4_1_paper.py --simulate-scenario panic
python bee_live_forecast_v4_1_paper.py --test-ntfy
python bee_live_forecast_v4_1_paper.py --once
```

## Wat doet --inspect-live-data?

Haalt live candles/Fear&Greed/funding/coinbase/macro op, valideert timestamps en gaps, bouwt features, draait de decision-core en toont waarom er wel/geen trade is.

## Wat doet --simulate-from-cache?

Draait dezelfde decision opnieuw met de laatst opgehaalde API-data, zonder nieuwe externe API-calls. Handig voor debugging.

## Wat doet --simulate-scenario panic?

Forceert een synthetisch panic/capitulation scenario op de actuele prijs/features, zodat je kunt testen of de modellen en ntfy trade-plan notificatie logisch reageren zonder te hoeven wachten op een echte crash.

## Golden row optioneel

Als je een historische CSV op de server zet als `live_forecast/bee_golden_rows.csv` of via `BEE_GOLDEN_CSV=/pad/naar/csv`, kun je testen:

```bash
python bee_live_forecast_v4_1_paper.py --golden-row 2025-06-01T12:00:00Z
```

Dit draait de core op een historische row om live/core consistentie te checken.


## V4.1.9 export overwrite fix

`--export-debug` overschrijft nu altijd deze twee bestanden in `/home/ubuntu`:

- `/home/ubuntu/bee_latest_export.zip`
- `/home/ubuntu/bee_live_debug_export.zip`

Oude `bee_live_debug_export*.zip` bestanden in `/home/ubuntu` worden eerst verwijderd, zodat Termius/SFTP niet per ongeluk de oude download toont.
