Zie chat voor updatecommando.
