# AlgoRoute v1.8.5 Route Quality Upgrade

C++ core v1.1 met farthest-seed + cheapest insertion + 2-opt/or-opt local search. Routevolgorde wordt daardoor minder zig-zag en dichter bij industrie-standaard heuristiek.
