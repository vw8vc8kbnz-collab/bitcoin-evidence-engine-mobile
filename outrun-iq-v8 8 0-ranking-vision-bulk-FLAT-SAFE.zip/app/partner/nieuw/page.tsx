import Link from "next/link";
import { NewListingFlow } from "@/components/NewListingFlow";

export default function Nieuw() {
  return (
    <main className="page narrow" style={{ paddingBottom: 170 }}>
      <header className="hd">
        <Link href="/partner" className="back" style={{ color: "#fff" }}>
          <svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7" /></svg>Stop
        </Link>
        <span className="sp" /><span className="mini" style={{ color: "#8B96A0" }}>NIEUW PRODUCT</span>
      </header>
      <div className="choiceHero"><span className="eyebrow">AANBEVOLEN FLOW</span><h1 className="h1big">Outletpartij of los product?</h1><p>Voor meerdere producten is de nieuwe Outlet CRM-flow veiliger: eerst batchreferentie, daarna foto’s groeperen en pas dan AI.</p><Link href="/partner/outlet" className="btn pri">Start Outlet CRM</Link><Link href="/partner/bulk" className="btn ghost" style={{ marginTop: 8 }}>⚡ Foto-dump (AI groepeert zelf)</Link></div>
      <h2 className="h1big" style={{fontSize:28, marginTop:22}}>Los product</h2>
      <NewListingFlow />
    </main>
  );
}
