import Link from "next/link";
import { BulkListingFlow } from "@/components/BulkListingFlow";

export default function BulkPage() {
  return (
    <main className="page narrow" style={{ paddingBottom: 170 }}>
      <header className="hd">
        <Link href="/partner/nieuw" className="back" style={{ color: "#fff" }}>
          <svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7" /></svg>Terug
        </Link>
        <span className="sp" /><span className="mini" style={{ color: "#8B96A0" }}>FOTO-DUMP · AI-BULK</span>
      </header>
      <div className="choiceHero">
        <span className="eyebrow">SNELSTE ROUTE</span>
        <h1 className="h1big">Gooi je foto's erin, wij maken de listings</h1>
        <p>Selecteer alle foto's van meerdere producten tegelijk. De AI groepeert ze per product en stelt concept-listings op — jij keurt ze alleen nog.</p>
      </div>
      <BulkListingFlow />
    </main>
  );
}
