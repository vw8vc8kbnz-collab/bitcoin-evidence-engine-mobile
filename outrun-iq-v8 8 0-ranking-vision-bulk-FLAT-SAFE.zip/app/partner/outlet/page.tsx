import Link from "next/link";
import { getUser } from "@/lib/auth";
import { listOutletBatches } from "@/lib/outlet";
import { Mark } from "@/components/icons";
import { OutletBatchCreator, OutletBatchOverview } from "@/components/OutletBatchStudio";
export const dynamic = "force-dynamic";

export default async function OutletPage() {
  const user = await getUser();
  const batches = user?.partnerSlug ? await listOutletBatches(user.partnerSlug) : [];
  return <main className="page partnerScreen outletScreen">
    <header className="hd"><Link href="/partner" className="lock" style={{ color: "#fff" }}><Mark glow />Outlet CRM</Link><span className="sp" /><Link href="/partner/voorraad" className="mini" style={{ color: "#8B96A0" }}>VOORRAAD</Link></header>
    <OutletBatchCreator />
    {batches.length > 0 && <><div className="dsec"><h2>Partijen</h2><span>{batches.length} batches</span></div><OutletBatchOverview batches={batches} /></>}
  </main>;
}
