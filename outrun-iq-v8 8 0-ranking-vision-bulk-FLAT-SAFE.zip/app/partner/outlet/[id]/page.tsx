import Link from "next/link";
import { notFound } from "next/navigation";
import { getUser } from "@/lib/auth";
import { getOutletBatch } from "@/lib/outlet";
import { Mark } from "@/components/icons";
import { OutletBatchStudio } from "@/components/OutletBatchStudio";
export const dynamic = "force-dynamic";

export default async function OutletBatchPage({ params }: { params: Promise<{ id: string }> }) {
  const p = await params;
  const user = await getUser();
  const batch = user?.partnerSlug ? await getOutletBatch(user.partnerSlug, p.id) : null;
  if (!batch) notFound();
  return <main className="page partnerScreen outletScreen">
    <header className="hd"><Link href="/partner/outlet" className="lock" style={{ color: "#fff" }}><Mark glow />Outlet CRM</Link><span className="sp" /><Link href="/partner" className="mini" style={{ color: "#8B96A0" }}>HUB</Link></header>
    <OutletBatchStudio initialBatch={batch} />
  </main>;
}
