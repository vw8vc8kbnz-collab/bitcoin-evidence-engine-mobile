import { NextResponse, type NextRequest } from "next/server";
import { getUser, isApprovedPartner } from "@/lib/auth";
import { addPhotosToBatch } from "@/lib/outlet";
import { promises as fs } from "fs";
import path from "path";
import { UPLOAD_DIR } from "@/lib/store";
export const runtime = "nodejs";
const OK_TYPES: Record<string, string> = { "image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp", "image/heic": ".heic" };
const MAX = 8 * 1024 * 1024;
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const u = await getUser(); const p = await params;
  if (!isApprovedPartner(u) || !u?.partnerSlug) return NextResponse.json({ error: "Alleen voor partners" }, { status: 403 });
  const form = await req.formData();
  const files = form.getAll("photos").filter((f): f is File => f instanceof File);
  if (!files.length) return NextResponse.json({ error: "Geen bestanden" }, { status: 400 });
  if (files.length > 100) return NextResponse.json({ error: "Upload maximaal 100 foto's per keer" }, { status: 400 });
  await fs.mkdir(UPLOAD_DIR, { recursive: true });
  const saved: { url: string; filename: string; buffer: Buffer }[] = [];
  for (const f of files) {
    const ext = OK_TYPES[f.type];
    if (!ext) return NextResponse.json({ error: `Bestandstype ${f.type} niet toegestaan` }, { status: 415 });
    if (f.size > MAX) return NextResponse.json({ error: "Foto groter dan 8MB" }, { status: 413 });
    const buffer = Buffer.from(await f.arrayBuffer());
    const clean = f.name.replace(/[^a-zA-Z0-9._-]/g, "-").slice(0, 60) || "foto";
    const name = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}-${clean}${clean.toLowerCase().endsWith(ext) ? "" : ext}`;
    await fs.writeFile(path.join(UPLOAD_DIR, name), buffer);
    saved.push({ url: `/uploads/${name}`, filename: f.name, buffer });
  }
  try { return NextResponse.json(await addPhotosToBatch(u.partnerSlug, p.id, saved)); }
  catch (e) { return NextResponse.json({ error: e instanceof Error ? e.message : "Upload mislukt" }, { status: 400 }); }
}
