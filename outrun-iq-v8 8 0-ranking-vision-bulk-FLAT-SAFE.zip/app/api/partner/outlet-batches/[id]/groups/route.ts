import { NextResponse, type NextRequest } from "next/server";
import { getUser, isApprovedPartner } from "@/lib/auth";
import { createPhotoGroupFromSelection } from "@/lib/outlet";
export const runtime = "nodejs";
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const u = await getUser(); const p = await params;
  if (!isApprovedPartner(u) || !u?.partnerSlug) return NextResponse.json({ error: "Alleen voor partners" }, { status: 403 });
  const body = await req.json().catch(() => ({}));
  try { return NextResponse.json(await createPhotoGroupFromSelection(u.partnerSlug, p.id, body)); }
  catch (e) { return NextResponse.json({ error: e instanceof Error ? e.message : "Product maken mislukt" }, { status: 400 }); }
}
