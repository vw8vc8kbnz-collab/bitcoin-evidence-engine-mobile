import { NextResponse, type NextRequest } from "next/server";
import { getUser, isApprovedPartner } from "@/lib/auth";
import { patchGroup, splitGroupIntoPhotoProposals } from "@/lib/outlet";
export const runtime = "nodejs";
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string; groupId: string }> }) {
  const u = await getUser(); const p = await params;
  if (!isApprovedPartner(u) || !u?.partnerSlug) return NextResponse.json({ error: "Alleen voor partners" }, { status: 403 });
  const body = await req.json().catch(() => ({}));
  try { return NextResponse.json(await patchGroup(u.partnerSlug, p.id, p.groupId, body)); }
  catch (e) { return NextResponse.json({ error: e instanceof Error ? e.message : "Opslaan mislukt" }, { status: 400 }); }
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string; groupId: string }> }) {
  const u = await getUser(); const p = await params;
  if (!isApprovedPartner(u) || !u?.partnerSlug) return NextResponse.json({ error: "Alleen voor partners" }, { status: 403 });
  try { return NextResponse.json(await splitGroupIntoPhotoProposals(u.partnerSlug, p.id, p.groupId)); }
  catch (e) { return NextResponse.json({ error: e instanceof Error ? e.message : "Splitsen mislukt" }, { status: 400 }); }
}
