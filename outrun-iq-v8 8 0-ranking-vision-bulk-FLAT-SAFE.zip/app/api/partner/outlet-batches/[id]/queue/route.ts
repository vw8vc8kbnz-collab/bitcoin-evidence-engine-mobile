import { NextResponse, type NextRequest } from "next/server";
import { getUser, isApprovedPartner } from "@/lib/auth";
import { enqueueBatchAi } from "@/lib/outlet";
export const runtime = "nodejs";
export async function POST(_: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const u = await getUser(); const p = await params;
  if (!isApprovedPartner(u) || !u?.partnerSlug) return NextResponse.json({ error: "Alleen voor partners" }, { status: 403 });
  try { return NextResponse.json(await enqueueBatchAi(u.partnerSlug, p.id)); }
  catch (e) { return NextResponse.json({ error: e instanceof Error ? e.message : "Queue mislukt" }, { status: 400 }); }
}
