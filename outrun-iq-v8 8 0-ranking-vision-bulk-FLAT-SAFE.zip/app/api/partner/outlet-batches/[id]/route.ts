import { NextResponse, type NextRequest } from "next/server";
import { getUser, isApprovedPartner } from "@/lib/auth";
import { getOutletBatch, updateOutletBatch } from "@/lib/outlet";
export const runtime = "nodejs";
export async function GET(_: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const u = await getUser(); const p = await params;
  if (!isApprovedPartner(u) || !u?.partnerSlug) return NextResponse.json({ error: "Alleen voor partners" }, { status: 403 });
  const batch = await getOutletBatch(u.partnerSlug, p.id);
  if (!batch) return NextResponse.json({ error: "Niet gevonden" }, { status: 404 });
  return NextResponse.json({ batch });
}
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const u = await getUser(); const p = await params;
  if (!isApprovedPartner(u) || !u?.partnerSlug) return NextResponse.json({ error: "Alleen voor partners" }, { status: 403 });
  const body = await req.json().catch(() => ({}));
  return NextResponse.json({ batch: await updateOutletBatch(u.partnerSlug, p.id, body) });
}
