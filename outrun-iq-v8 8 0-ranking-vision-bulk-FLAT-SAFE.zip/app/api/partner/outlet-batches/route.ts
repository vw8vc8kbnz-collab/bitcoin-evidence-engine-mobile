import { NextResponse, type NextRequest } from "next/server";
import { getUser, isApprovedPartner } from "@/lib/auth";
import { createOutletBatch, listOutletBatches } from "@/lib/outlet";
export const runtime = "nodejs";

export async function GET() {
  const u = await getUser();
  if (!isApprovedPartner(u) || !u?.partnerSlug) return NextResponse.json({ error: "Alleen voor partners" }, { status: 403 });
  return NextResponse.json({ batches: await listOutletBatches(u.partnerSlug) });
}
export async function POST(req: NextRequest) {
  const u = await getUser();
  if (!isApprovedPartner(u) || !u?.partnerSlug) return NextResponse.json({ error: "Alleen voor partners" }, { status: 403 });
  const body = await req.json().catch(() => ({}));
  const batch = await createOutletBatch(u.partnerSlug, body);
  return NextResponse.json({ batch });
}
