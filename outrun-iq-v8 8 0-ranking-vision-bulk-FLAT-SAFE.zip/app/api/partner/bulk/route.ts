import { NextResponse, type NextRequest } from "next/server";
import { promises as fs } from "fs";
import path from "path";
import { getUser, isApprovedPartner, rateLimit } from "@/lib/auth";
import { buildConceptListings } from "@/lib/ai/bulk";
import { UPLOAD_DIR, LEGACY_UPLOAD_DIR } from "@/lib/store";
export const runtime = "nodejs";

const MIME: Record<string, string> = { ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".webp": "image/webp", ".heic": "image/heic" };

async function toDataUrl(photoUrl: string): Promise<string | null> {
  const name = path.basename(String(photoUrl ?? ""));
  const ext = path.extname(name).toLowerCase();
  if (!String(photoUrl ?? "").startsWith("/uploads/") || !MIME[ext]) return null;
  for (const dir of [UPLOAD_DIR, LEGACY_UPLOAD_DIR]) {
    try { const buf = await fs.readFile(path.join(dir, name)); return `data:${MIME[ext]};base64,${buf.toString("base64")}`; }
    catch { /* volgende */ }
  }
  return null;
}

/** Foto-dump → concept-listings. Body: { photoUrls: string[] } (reeds geüpload via /api/partner/upload). */
export async function POST(req: NextRequest) {
  const u = await getUser();
  if (!isApprovedPartner(u)) return NextResponse.json({ error: "Alleen voor goedgekeurde partners" }, { status: 403 });
  // bulk is duurder: strengere limiet (3 dumps per uur)
  if (!rateLimit(`ai-bulk:${u?.id ?? "anon"}`, 3, 60 * 60_000)) {
    return NextResponse.json({ error: "Bulk-AI-limiet bereikt. Probeer het over een uur opnieuw." }, { status: 429 });
  }
  const b = await req.json().catch(() => ({}));
  const urls: string[] = Array.isArray(b?.photoUrls) ? b.photoUrls.slice(0, 40) : [];
  if (urls.length < 2) return NextResponse.json({ error: "Upload minstens 2 foto's voor bulk-herkenning" }, { status: 400 });

  const dataUrls: string[] = [];
  const urlByData: Record<string, string> = {};
  for (const url of urls) {
    const d = await toDataUrl(url);
    if (d) { dataUrls.push(d); urlByData[d] = url; }
  }
  if (!dataUrls.length) return NextResponse.json({ error: "Geen leesbare foto's" }, { status: 400 });

  const concepts = await buildConceptListings(dataUrls);
  // map data-urls terug naar de publieke /uploads-urls zodat de client ze kan tonen/publiceren
  const out = concepts.map(c => ({
    ...c,
    photoUrls: c.photoUrls.map(d => urlByData[d]).filter(Boolean),
  }));
  return NextResponse.json({ concepts: out });
}
