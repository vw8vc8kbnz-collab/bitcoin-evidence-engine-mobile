import { NextResponse, type NextRequest } from "next/server";
import { getUser, isApprovedPartner } from "@/lib/auth";
import { createListing } from "@/lib/data";
export const runtime = "nodejs";

type Concept = {
  title: string; brand?: string; model?: string;
  category: "witgoed" | "meubels" | "keukens" | "tuin" | "overig";
  condition?: string; conditionScore?: number; defect?: string;
  newPrice: number; price: number; fast?: number; premium?: number;
  stock?: number; deliveryPrice?: number; photos: string[];
};

/** Publiceert een reeks goedgekeurde concept-listings in één keer. */
export async function POST(req: NextRequest) {
  const u = await getUser();
  if (!isApprovedPartner(u) || !u?.partnerSlug) {
    return NextResponse.json({ error: "Alleen voor goedgekeurde partners" }, { status: 403 });
  }
  const b = await req.json().catch(() => ({}));
  const items: Concept[] = Array.isArray(b?.items) ? b.items.slice(0, 40) : [];
  if (!items.length) return NextResponse.json({ error: "Geen producten om te publiceren" }, { status: 400 });

  const created: string[] = [];
  const failed: { title: string; error: string }[] = [];
  for (const it of items) {
    try {
      if (!it.title || !it.newPrice || !it.price || it.price <= 0 || it.price >= it.newPrice) {
        failed.push({ title: it.title || "(zonder titel)", error: "titel/prijs ongeldig" }); continue;
      }
      const l = await createListing({
        sellerSlug: u.partnerSlug!,
        title: String(it.title).slice(0, 90),
        brand: it.brand || undefined,
        model: it.model || undefined,
        category: it.category,
        condition: it.condition || "",
        conditionScore: Math.min(10, Math.max(1, Number(it.conditionScore) || 7)),
        defect: it.defect || undefined,
        newPrice: Math.round(it.newPrice),
        price: Math.round(it.price),
        fast: Math.round(it.fast || it.price),
        premium: Math.round(it.premium || it.newPrice),
        stock: Math.max(1, Number(it.stock) || 1),
        perUnit: (Number(it.stock) || 1) > 1,
        delivery: "Bezorging in overleg",
        deliveryPrice: Math.max(0, Number(it.deliveryPrice) || 0),
        pickupCity: "",
        photos: (it.photos || []).slice(0, 5),
        fallback: it.category === "meubels" ? "sofa" : it.category === "witgoed" ? "washer" : "tv" as const,
        confidence: 60, comps: 0, aiSource: "heuristiek",
        expectedDays: 7,
      } as Parameters<typeof createListing>[0]);
      created.push(l.id);
    } catch (e) {
      failed.push({ title: it.title || "(zonder titel)", error: String(e).slice(0, 80) });
    }
  }
  return NextResponse.json({ created: created.length, ids: created, failed });
}
