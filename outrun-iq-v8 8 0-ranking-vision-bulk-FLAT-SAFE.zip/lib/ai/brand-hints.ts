/** Merk-hints als DATA, niet als code.
 *  Dit vervangt de vroegere hardgecodeerde merkencyclopedie in de vision-prompt
 *  én de vier normalize*-functies. Uitbreiden = een regel toevoegen, geen code.
 *
 *  Doel is bescheiden en eerlijk: het model KRIJGT deze hints als context zodat het
 *  bij twijfel de juiste modelseries als kandidaten voorstelt in plaats van een
 *  generieke titel of een gegokt exact model. Het model beslist; wij sturen alleen.
 *
 *  LET OP (audit v8.7.1): dit is een overbruggingslaag. De juiste eindoplossing is
 *  retrieval op je EIGEN verkochte-productendatabase zodra je genoeg orders hebt —
 *  dan komen de kandidaten uit echte marktdata i.p.v. een handmatige lijst. Houd
 *  deze tabel daarom compact; laat hem niet opnieuw uitgroeien tot een encyclopedie. */

export type BrandHint = {
  /** trefwoorden die (in titel/merk/ocr, lowercase) op dit cluster kunnen wijzen */
  match: string[];
  /** korte NL-omschrijving van het type, voor als het exacte model onzeker is */
  fallbackType: string;
  /** modelseries die als kandidaten voorgesteld mogen worden bij twijfel */
  candidates: string[];
  /** wat een extra foto zou helpen om het model hard te maken */
  needPhoto?: string;
};

export const BRAND_HINTS: BrandHint[] = [
  { match: ["sony", "wh-1000", "wh1000", "over-ear", "noise cancelling koptelefoon"],
    fallbackType: "Sony WH-1000X-serie koptelefoon",
    candidates: ["Sony WH-1000XM5", "Sony WH-1000XM4", "Sony WH-1000XM3"],
    needPhoto: "foto van de typecode op de beugel of de doos" },
  { match: ["thrustmaster", "racestuur", "sim racing", "playstation stuur"],
    fallbackType: "Thrustmaster racestuur",
    candidates: ["Thrustmaster T300 RS GT", "Thrustmaster T300 RS", "Thrustmaster T-GT II", "Thrustmaster T248", "Thrustmaster TX"],
    needPhoto: "foto van het typeplaatje onderop de basis" },
  { match: ["samsung wasmachine", "samsung wasautomaat", "ecobubble", "addwash", "quickdrive"],
    fallbackType: "Samsung wasmachine",
    candidates: ["Samsung EcoBubble", "Samsung AddWash", "Samsung QuickDrive", "Samsung Bespoke AI"],
    needPhoto: "foto van de sticker in de deuropening (modelcode)" },
  { match: ["samsung koelkast", "koel-vries", "no frost", "bespoke", "rb-serie"],
    fallbackType: "Samsung koel-vriescombinatie",
    candidates: ["Samsung Bespoke", "Samsung No Frost RB-serie", "Samsung Family Hub"],
    needPhoto: "foto van het typeplaatje binnenin" },
  { match: ["harley", "harley-davidson", "cruiser", "touring motor", "v-twin", "softail", "road king"],
    fallbackType: "Harley-Davidson cruiser/touring motor",
    candidates: ["Harley-Davidson Road King", "Harley-Davidson Heritage Softail Classic", "Harley-Davidson Softail Deluxe"],
    needPhoto: "foto van het tanklogo en het typeplaatje op het frame" },
  { match: ["dyson", "steelstofzuiger", "v-serie stofzuiger"],
    fallbackType: "Dyson steelstofzuiger",
    candidates: ["Dyson V15 Detect", "Dyson V12", "Dyson V11", "Dyson V8"],
    needPhoto: "foto van de modelnaam op de motorunit" },
  { match: ["jura", "espressomachine", "volautomaat koffie"],
    fallbackType: "Jura volautomaat espressomachine",
    candidates: ["Jura E8", "Jura ENA 8", "Jura S8", "Jura Z10"],
    needPhoto: "foto van het typeplaatje aan de achterzijde" },
];

/** Bouwt een compacte hint-tekst voor de prompt: alleen de generieke regel +
 *  de tabel als JSON. Dit is klein en constant, niet honderden woorden proza. */
export function brandHintBlock(): string {
  const table = BRAND_HINTS.map((h) => ({
    type: h.fallbackType, candidates: h.candidates, extraFoto: h.needPhoto ?? "",
  }));
  return (
    `Merk-hints (gebruik alleen als het past bij wat je ZIET; verzin niets): ` +
    JSON.stringify(table)
  );
}

/** Lichte, data-gedreven normalisatie: als het model generiek bleef ("koptelefoon",
 *  "motor") maar de tekst matcht een hint, vul dan fallbackType + kandidaten aan.
 *  Vervangt de vier hardgecodeerde normalize*-functies met één generieke pass. */
export function applyBrandHints<T extends {
  title: string; brand: string; model: string; modelCandidates: string[];
  needsExtraPhotos: string[]; uncertainty: boolean; confidence: number;
}>(out: T): T {
  const hay = `${out.title} ${out.brand} ${out.model}`.toLowerCase();
  const generic = out.title.trim().split(/\s+/).length <= 2 || !out.model;
  for (const h of BRAND_HINTS) {
    if (!h.match.some((m) => hay.includes(m))) continue;
    // alleen aanvullen, nooit een reeds-zeker exact model overschrijven
    if (generic && (!out.title || out.title.toLowerCase() === out.brand.toLowerCase())) {
      out.title = h.fallbackType;
    }
    const have = new Set(out.modelCandidates.map((c) => c.toLowerCase()));
    for (const c of h.candidates) if (!have.has(c.toLowerCase())) out.modelCandidates.push(c);
    out.modelCandidates = out.modelCandidates.slice(0, 6);
    if (generic) {
      out.uncertainty = true;
      if (out.confidence > 88) out.confidence = 80;
      if (h.needPhoto && !out.needsExtraPhotos.includes(h.needPhoto)) {
        out.needsExtraPhotos = [...out.needsExtraPhotos, h.needPhoto].slice(0, 4);
      }
    }
    break; // eerste match wint
  }
  return out;
}
