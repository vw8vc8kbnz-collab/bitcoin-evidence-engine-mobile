/** Foto-dump → concept-listings (audit v8.7.1 "next-level bulk").
 *
 *  Idee: de partner dumpt een berg foto's; de AI groepeert ze zelf per product en
 *  levert per groep een concept-listing die de partner alleen nog hoeft te KEUREN.
 *
 *  Aanpak in twee lagen, pragmatisch (geen zware embeddings nodig voor de pilot):
 *   1) Snelle "vingerafdruk"-pass per foto: één goedkope vision-call per foto die
 *      alleen merk + categorie + kleur + korte typeaanduiding teruggeeft.
 *   2) Clustering op die vingerafdruk (merk+categorie+kleur + tekstsimilariteit),
 *      binnen een korte uploadvenster = waarschijnlijk hetzelfde product.
 *   3) Per cluster de bestaande volledige analyzeProductPhotos → concept-listing.
 *
 *  De partner kan in de review-UI clusters samenvoegen/splitsen, dus perfecte
 *  clustering is NIET nodig — "goed genoeg voorstel dat je bijstuurt". */

import { analyzeProductPhotos, type VisionFields } from "./vision";

export type PhotoPrint = {
  url: string;
  brand: string;
  category: string;
  color: string;
  kind: string;     // korte typeaanduiding, bv. "wasmachine", "eettafel"
  ok: boolean;
};

export type ConceptListing = {
  clusterId: string;
  photoUrls: string[];
  fields: VisionFields | null;   // volledige analyse per cluster (null = handmatig afmaken)
  confidence: number;
};

const norm = (s: unknown) => String(s ?? "").toLowerCase().trim();

/** Stap 1 — goedkope vingerafdruk per foto (kleiner promptbudget dan de volledige analyse). */
export async function fingerprintPhoto(dataUrl: string): Promise<PhotoPrint> {
  const key = process.env.VISION_API_KEY, model = process.env.VISION_MODEL;
  const api = process.env.VISION_BASE_URL || "https://api.openai.com/v1/chat/completions";
  const empty: PhotoPrint = { url: dataUrl, brand: "", category: "overig", color: "", kind: "", ok: false };
  if (!key || !model) return empty;
  const sys = `Je krijgt één productfoto. Antwoord UITSLUITEND met JSON: {"brand":"","category":"","color":"","kind":""}. category = precies één uit witgoed, meubels, keukens, tuin, overig. kind = kort producttype in 1-2 NL woorden (bv. "wasmachine", "eettafel", "koptelefoon"). brand = merk indien zichtbaar, anders "". color = dominante kleur. Verzin niets.`;
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), 20_000);
  try {
    const res = await fetch(api, {
      method: "POST", signal: ctl.signal,
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
      body: JSON.stringify({
        model, temperature: 0.1, response_format: { type: "json_object" },
        messages: [
          { role: "system", content: sys },
          { role: "user", content: [
            { type: "text", text: "Vingerafdruk van dit product:" },
            { type: "image_url", image_url: { url: dataUrl } },
          ] },
        ],
      }),
    });
    if (!res.ok) return empty;
    const j = await res.json();
    const p = JSON.parse(String(j?.choices?.[0]?.message?.content ?? "{}").replace(/```json|```/g, "").trim());
    const cats = ["witgoed", "meubels", "keukens", "tuin", "overig"];
    return {
      url: dataUrl,
      brand: norm(p.brand),
      category: cats.includes(norm(p.category)) ? norm(p.category) : "overig",
      color: norm(p.color),
      kind: norm(p.kind),
      ok: true,
    };
  } catch { return empty; }
  finally { clearTimeout(t); }
}

/** Stap 2 — clustering: foto's met dezelfde vingerafdruk-signatuur horen bij één product. */
export function clusterPrints(prints: PhotoPrint[]): PhotoPrint[][] {
  const clusters: { sig: string; items: PhotoPrint[] }[] = [];
  const sigOf = (p: PhotoPrint) => `${p.category}|${p.brand}|${p.kind}`;
  const close = (a: PhotoPrint, b: PhotoPrint) => {
    if (a.category !== b.category) return false;
    // zelfde merk (of beide leeg) + zelfde type = zelfde product; kleur mag matchen maar hoeft niet (schadefoto's zijn soms anders belicht)
    const brandOk = a.brand === b.brand || !a.brand || !b.brand;
    const kindOk = a.kind === b.kind || (!!a.kind && !!b.kind && (a.kind.includes(b.kind) || b.kind.includes(a.kind)));
    return brandOk && kindOk;
  };
  for (const p of prints) {
    const hit = clusters.find((c) => c.items.some((it) => close(it, p)));
    if (hit) hit.items.push(p);
    else clusters.push({ sig: sigOf(p), items: [p] });
  }
  return clusters.map((c) => c.items);
}

/** Volledige pipeline: vingerafdrukken → clusteren → per cluster volledige analyse. */
export async function buildConceptListings(dataUrls: string[]): Promise<ConceptListing[]> {
  const capped = dataUrls.filter(Boolean).slice(0, 40);   // dagelijkse veiligheidscap
  // stap 1: vingerafdrukken (parallel, maar met een kleine begrenzing)
  const prints: PhotoPrint[] = [];
  const BATCH = 5;
  for (let i = 0; i < capped.length; i += BATCH) {
    const chunk = capped.slice(i, i + BATCH);
    prints.push(...await Promise.all(chunk.map(fingerprintPhoto)));
  }
  // stap 2: clusteren
  const clusters = clusterPrints(prints);
  // stap 3: per cluster de volledige analyse (max 5 foto's per product zoals elders)
  const concepts: ConceptListing[] = [];
  for (let i = 0; i < clusters.length; i++) {
    const urls = clusters[i].map((p) => p.url).slice(0, 5);
    const fields = await analyzeProductPhotos(urls).catch(() => null);
    concepts.push({
      clusterId: `c${i + 1}`,
      photoUrls: urls,
      fields,
      confidence: fields?.confidence ?? 0,
    });
  }
  // laag-vertrouwen bovenaan: die wil de partner als eerste checken
  concepts.sort((a, b) => a.confidence - b.confidence);
  return concepts;
}
