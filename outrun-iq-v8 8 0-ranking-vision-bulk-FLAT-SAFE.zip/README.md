# Outrun IQ v8.7.1 — Desktop Fullscreen UX Rebuild

Outrun IQ is een AI-commerceplatform voor outlet-, retour- en restpartijen.

Deze build bouwt voort op v8.7.0 AI Workbench Safe Photo Flow, maar focust volledig op desktop UX. De mobiele ervaring blijft intact; desktop krijgt eigen fullscreen layoutregels.

## Belangrijkste wijziging

Desktop is niet langer een opgeschaalde mobiele app. Vanaf 1024px gebruikt Outrun:

- fullscreen app-shell;
- ruimere topnavigatie;
- echte desktop grids;
- betere hero/discovery layout;
- checkout in twee kolommen;
- listing/detail met gallery links en content rechts;
- partner/outlet workbench als desktop workspace.

## Deploy

Gebruik de Termius-regel uit de meegeleverde overdracht. De app draait in `/var/www/outrun-iq-v5` en behoudt `.env`, `data`, `runtime_uploads`, `public/uploads`, `node_modules` en `.next` tijdens rsync.
