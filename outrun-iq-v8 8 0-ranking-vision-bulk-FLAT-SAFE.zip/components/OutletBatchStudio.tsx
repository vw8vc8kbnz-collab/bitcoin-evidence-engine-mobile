"use client";
import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import type { OutletBatch } from "@/lib/types";

type BatchWithCounts = OutletBatch & { counts?: { photos: number; groups: number; ready: number; review: number; processing: number } };
const TYPES = ["retouren", "b-stock", "showroom", "restpartij", "faillissement", "overig"] as const;

export function OutletBatchCreator() {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [f, setF] = useState({ reference: "", supplier: "", partyType: "retouren", warehouseLocation: "", estimatedProducts: "", notes: "" });
  async function create() {
    setBusy(true); setErr("");
    const r = await fetch("/api/partner/outlet-batches", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...f, estimatedProducts: Number(f.estimatedProducts) || undefined }) });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (r.ok && j.batch?.id) router.push(`/partner/outlet/${j.batch.id}`);
    else setErr(j.error || "Partij aanmaken mislukt");
  }
  return <section className="outletCreateCard">
    <span className="eyebrow">OUTLET INVENTORY CRM</span>
    <h1>Nieuwe outletpartij</h1>
    <p>Maak eerst een partij met referentie. Daarna upload je alle foto’s en groepeert Outrun ze veilig per product.</p>
    <div className="outletFormGrid">
      <label>Referentie<input value={f.reference} onChange={e => setF({ ...f, reference: e.target.value })} placeholder="bv. MM-RET-2026-0712" /></label>
      <label>Leverancier<input value={f.supplier} onChange={e => setF({ ...f, supplier: e.target.value })} placeholder="optioneel" /></label>
      <label>Type partij<select value={f.partyType} onChange={e => setF({ ...f, partyType: e.target.value })}>{TYPES.map(t => <option key={t} value={t}>{t}</option>)}</select></label>
      <label>Magazijnlocatie<input value={f.warehouseLocation} onChange={e => setF({ ...f, warehouseLocation: e.target.value })} placeholder="bv. Pallet A17" /></label>
      <label>Geschat aantal<input type="number" value={f.estimatedProducts} onChange={e => setF({ ...f, estimatedProducts: e.target.value })} placeholder="bv. 80" /></label>
      <label className="wide">Opmerking<input value={f.notes} onChange={e => setF({ ...f, notes: e.target.value })} placeholder="bv. retourpartij, labels vaak aanwezig" /></label>
    </div>
    {err && <p className="note" style={{ color: "var(--amber)" }}>{err}</p>}
    <button className="btn pri" onClick={create} disabled={busy}>{busy ? "Aanmaken…" : "Start uploadstudio"}</button>
  </section>;
}

export function OutletBatchOverview({ batches }: { batches: BatchWithCounts[] }) {
  return <div className="outletBatchList">
    {batches.map(b => <a className="outletBatchCard" href={`/partner/outlet/${b.id}`} key={b.id}>
      <span><b>{b.reference}</b><small>{b.partyType} · {b.supplier || "geen leverancier"}</small></span>
      <em>{b.counts?.groups || b.groups.length} producten</em>
      <div className="outletBatchBars"><i style={{ width: `${Math.min(100, ((b.counts?.ready || 0) / Math.max(1, b.groups.length)) * 100)}%` }} /></div>
      <small>{b.counts?.photos || b.photos.length} foto’s · {b.counts?.review || 0} controle · {b.status}</small>
    </a>)}
  </div>;
}

export function OutletBatchStudio({ initialBatch }: { initialBatch: OutletBatch }) {
  const router = useRouter();
  const [batch, setBatch] = useState(initialBatch);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [selectedPhotos, setSelectedPhotos] = useState<string[]>([]);
  const [activeGroupId, setActiveGroupId] = useState<string | null>(batch.groups[0]?.id || null);
  const [filter, setFilter] = useState<"all" | "selected" | "review" | "label" | "ready">("all");
  const photosById = useMemo(() => new Map(batch.photos.map(p => [p.id, p])), [batch.photos]);
  const activeGroup = batch.groups.find(g => g.id === activeGroupId) || batch.groups[0];
  const confirmed = batch.groups.filter(g => g.status === "ready_for_ai" || g.status === "ai_processing" || g.status === "ready_to_publish" || g.status === "published").length;
  const review = batch.groups.filter(g => g.status === "needs_review" || g.status === "draft" || g.status === "error").length;
  const visiblePhotos = batch.photos.filter(p => {
    if (filter === "selected") return selectedPhotos.includes(p.id);
    if (filter === "review") return p.needsReview || batch.groups.find(g => g.photoIds.includes(p.id))?.status === "needs_review";
    if (filter === "label") return p.role === "label";
    if (filter === "ready") return batch.groups.find(g => g.photoIds.includes(p.id))?.status === "ready_for_ai";
    return true;
  });
  function togglePhoto(id: string) {
    setSelectedPhotos(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id].slice(0, 5));
  }
  async function refresh() {
    const r = await fetch(`/api/partner/outlet-batches/${batch.id}`, { cache: "no-store" });
    const j = await r.json().catch(() => ({}));
    if (r.ok && j.batch) setBatch(j.batch);
    router.refresh();
  }
  async function upload(files: FileList | null) {
    if (!files?.length) return;
    setBusy(true); setErr("");
    const fd = new FormData();
    Array.from(files).forEach(f => fd.append("photos", f));
    const r = await fetch(`/api/partner/outlet-batches/${batch.id}/photos`, { method: "POST", body: fd });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (r.ok && j.batch) { setBatch(j.batch); setActiveGroupId(j.batch.groups[0]?.id || null); setSelectedPhotos([]); }
    else setErr(j.error || "Upload mislukt");
  }
  async function patchGroup(groupId: string, patch: any) {
    const r = await fetch(`/api/partner/outlet-batches/${batch.id}/groups/${groupId}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(patch) });
    const j = await r.json().catch(() => ({}));
    if (r.ok && j.batch) setBatch(j.batch); else setErr(j.error || "Opslaan mislukt");
  }
  async function makeProduct() {
    setBusy(true); setErr("");
    const r = await fetch(`/api/partner/outlet-batches/${batch.id}/groups`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ photoIds: selectedPhotos }) });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (r.ok && j.batch) { setBatch(j.batch); setActiveGroupId(j.group?.id || null); setSelectedPhotos([]); }
    else setErr(j.error || "Product maken mislukt");
  }
  async function splitGroup(groupId: string) {
    setBusy(true); setErr("");
    const r = await fetch(`/api/partner/outlet-batches/${batch.id}/groups/${groupId}`, { method: "DELETE" });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (r.ok && j.batch) { setBatch(j.batch); setSelectedPhotos([]); setActiveGroupId(j.batch.groups[0]?.id || null); }
    else setErr(j.error || "Splitsen mislukt");
  }
  async function queue() {
    setBusy(true); setErr("");
    const r = await fetch(`/api/partner/outlet-batches/${batch.id}/queue`, { method: "POST" });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (r.ok && j.batch) setBatch(j.batch); else setErr(j.error || "Queue starten mislukt");
  }
  const activePhotos = activeGroup ? activeGroup.photoIds.map(id => photosById.get(id)).filter(Boolean) as OutletBatch["photos"] : [];
  return <section className="outletStudio workbench">
    <div className="outletStepbar"><b>Partij</b><i /><b>Foto’s</b><i /><b>AI Werkbank</b><i /><b>Review</b><i /><b>Publiceren</b></div>
    <div className="outletHero compact">
      <span className="eyebrow">AI WORKBENCH · VEILIGE MODUS</span>
      <h1>{batch.reference}</h1>
      <p>{batch.partyType} · {batch.supplier || "leverancier onbekend"} · {batch.warehouseLocation || "geen magazijnlocatie"}</p>
      <div className="outletStats"><span><b>{batch.photos.length}</b><small>foto’s</small></span><span><b>{batch.groups.length}</b><small>voorstellen</small></span><span><b>{review}</b><small>controle</small></span><span><b>{confirmed}</b><small>bevestigd</small></span></div>
    </div>
    <label className="outletDrop slim">{busy ? "Bezig…" : "Upload foto's van deze outletpartij"}<input type="file" accept="image/*" multiple hidden onChange={e => upload(e.target.files)} /><small>Nieuwe veiligheidsregel: Outrun koppelt foto’s niet automatisch samen. Jij maakt pas een product door foto’s te selecteren en te bevestigen.</small></label>
    {err && <p className="note" style={{ color: "var(--amber)" }}>{err}</p>}
    <div className="workbenchActions">
      <button className="btn pri" onClick={makeProduct} disabled={busy || selectedPhotos.length === 0}>Maak product van selectie ({selectedPhotos.length}/5)</button>
      <button className="btn ghost" onClick={() => setSelectedPhotos([])}>Wis selectie</button>
      <button className="btn ghost" onClick={refresh}>Ververs</button>
      <span>Tip: selecteer alleen foto’s van exact hetzelfde product.</span>
    </div>
    <div className="workbenchGrid">
      <aside className="proposalRail">
        <div className="dsec"><h2>AI voorstellen</h2><span>BEVESTIG EERST</span></div>
        {batch.groups.length === 0 && <p className="note">Nog geen foto's.</p>}
        {batch.groups.map(g => <button key={g.id} className={activeGroup?.id === g.id ? "on" : ""} onClick={() => { setActiveGroupId(g.id); setSelectedPhotos(g.photoIds.slice(0, 5)); }}>
          <b>{g.title || (g.photoIds.length === 1 ? "Losse foto" : "Productvoorstel")}</b>
          <small>{g.photoIds.length} foto · {g.aiConfidence}/100</small>
          <em>{g.status === "ready_for_ai" ? "bevestigd" : "controle"}</em>
        </button>)}
      </aside>
      <main className="photoWorkbench">
        <div className="filterRow">
          {(["all", "selected", "review", "label", "ready"] as const).map(f => <button key={f} onClick={() => setFilter(f)} className={filter === f ? "on" : ""}>{f === "all" ? "Alle foto’s" : f === "selected" ? "Selectie" : f === "review" ? "Controle" : f === "label" ? "Labels/typeplaatjes" : "Bevestigd"}</button>)}
        </div>
        <div className="photoMasonry">
          {visiblePhotos.map(p => {
            const g = batch.groups.find(x => x.photoIds.includes(p.id));
            const on = selectedPhotos.includes(p.id);
            return <article key={p.id} className={`${on ? "sel" : ""} ${p.role === "label" ? "label" : ""}`} onClick={() => togglePhoto(p.id)}>
              {/* eslint-disable-next-line @next/next/no-img-element */}<img src={p.url} alt="" />
              <div><b>{p.role === "label" ? "Typeplaat/label" : g?.title || "Foto"}</b><small>{g?.status === "ready_for_ai" ? "bevestigd" : "nog niet bevestigd"} · {p.publicAllowed ? "openbaar mogelijk" : "privé"}</small></div>
            </article>;
          })}
        </div>
      </main>
    </div>
    <div className="reviewDrawer">
      {activeGroup ? <>
        <div><b>{activeGroup.title || activeGroup.reference}</b><small>{activeGroup.photoIds.length} foto’s · {activeGroup.status}</small></div>
        <div className="miniStrip">{activePhotos.map(p => <img key={p.id} src={p.url} alt="" />)}</div>
        <button className="btn pri" onClick={() => patchGroup(activeGroup.id, { status: "ready_for_ai" })}>Voorstel klopt</button>
        <button className="btn ghost" onClick={() => splitGroup(activeGroup.id)}>Splits naar losse foto's</button>
        <label>Werktitel<input defaultValue={activeGroup.title || ""} placeholder="bv. Tefal pannenset" onBlur={e => patchGroup(activeGroup.id, { title: e.currentTarget.value })} /></label>
      </> : <span>Selecteer een voorstel of foto.</span>}
    </div>
    <div className="outletQueueBar"><button className="btn pri" onClick={queue} disabled={busy || confirmed === 0}>Zet bevestigde producten in AI queue</button><button className="btn ghost" onClick={refresh}>Status</button><span>{batch.jobs.filter(j => j.status === "waiting").length} wachtend · {batch.jobs.filter(j => j.status === "error").length} fout</span></div>
  </section>;
}
