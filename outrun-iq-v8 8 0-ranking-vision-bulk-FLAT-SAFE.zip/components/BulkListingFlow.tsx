"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { eur } from "@/lib/types";

type Cat = "witgoed" | "meubels" | "keukens" | "tuin" | "overig";

type Concept = {
  clusterId: string;
  photoUrls: string[];
  confidence: number;
  fields: {
    title?: string; brand?: string; model?: string; category?: Cat;
    condition?: string; conditionScore?: number; defect?: string;
    newPriceEstimate?: number; modelCandidates?: string[]; uncertainty?: boolean;
    sellingPoints?: string[];
  } | null;
};

/** Bewerkbaar concept zoals de partner het keurt. */
type Draft = {
  clusterId: string;
  photos: string[];
  title: string; brand: string; category: Cat;
  condition: string; conditionScore: number; defect: string;
  newPrice: string; price: string;
  confidence: number; uncertainty: boolean;
  candidates: string[];
  keep: boolean;
};

const CATS: Cat[] = ["witgoed", "meubels", "keukens", "tuin", "overig"];

function toDraft(c: Concept): Draft {
  const f = c.fields ?? {};
  const np = Math.round(f.newPriceEstimate || 0);
  return {
    clusterId: c.clusterId,
    photos: c.photoUrls,
    title: f.title || "",
    brand: f.brand || "",
    category: (f.category as Cat) || "overig",
    condition: f.condition || "",
    conditionScore: f.conditionScore || 7,
    defect: f.defect || "",
    newPrice: np ? String(np) : "",
    price: np ? String(Math.round(np * 0.62 / 5) * 5) : "",   // voorstel outlet ~62% van nieuw
    confidence: c.confidence,
    uncertainty: !!f.uncertainty,
    candidates: f.modelCandidates || [],
    keep: true,
  };
}

export function BulkListingFlow() {
  const router = useRouter();
  const [phase, setPhase] = useState<"upload" | "analyzing" | "review" | "done">("upload");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [uploaded, setUploaded] = useState<string[]>([]);
  const [drafts, setDrafts] = useState<Draft[]>([]);
  const [result, setResult] = useState<{ created: number; failed: number } | null>(null);

  async function uploadBulk(files: FileList | null) {
    if (!files?.length) return;
    setBusy(true); setErr("");
    const fd = new FormData();
    Array.from(files).slice(0, 40).forEach((f) => fd.append("photos", f));
    const r = await fetch("/api/partner/upload?bulk=1", { method: "POST", body: fd });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (r.ok) setUploaded((prev) => [...prev, ...(j.urls || [])].slice(0, 40));
    else setErr(j.error || "Upload mislukt");
  }

  async function analyze() {
    if (uploaded.length < 2) { setErr("Upload minstens 2 foto's."); return; }
    setPhase("analyzing"); setBusy(true); setErr("");
    const r = await fetch("/api/partner/bulk", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ photoUrls: uploaded }),
    });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (r.ok && Array.isArray(j.concepts)) {
      setDrafts(j.concepts.map(toDraft));
      setPhase("review");
    } else { setErr(j.error || "AI-herkenning mislukt"); setPhase("upload"); }
  }

  function upd(i: number, patch: Partial<Draft>) {
    setDrafts((d) => d.map((x, k) => (k === i ? { ...x, ...patch } : x)));
  }

  /** Twee aangrenzende concepten samenvoegen (clustering zat ernaast). */
  function mergeInto(i: number) {
    if (i <= 0) return;
    setDrafts((d) => {
      const merged = { ...d[i - 1], photos: [...d[i - 1].photos, ...d[i].photos].slice(0, 5) };
      return d.filter((_, k) => k !== i).map((x, k) => (k === i - 1 ? merged : x));
    });
  }

  async function publish() {
    const items = drafts.filter((d) => d.keep).map((d) => ({
      title: d.title, brand: d.brand, category: d.category,
      condition: d.condition, conditionScore: d.conditionScore, defect: d.defect,
      newPrice: Number(d.newPrice), price: Number(d.price),
      fast: Math.round(Number(d.price) * 0.9), premium: Math.round(Number(d.newPrice) * 0.8),
      stock: 1, deliveryPrice: 0, photos: d.photos,
    }));
    if (!items.length) { setErr("Geen producten geselecteerd."); return; }
    setBusy(true); setErr("");
    const r = await fetch("/api/partner/bulk/publish", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ items }),
    });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    if (r.ok) { setResult({ created: j.created || 0, failed: (j.failed || []).length }); setPhase("done"); }
    else setErr(j.error || "Publiceren mislukt");
  }

  const keepCount = drafts.filter((d) => d.keep).length;

  return (
    <>
      {phase === "upload" && (
        <>
          <div className="dsec"><h2>Foto-dump</h2></div>
          <p className="note">Selecteer in één keer alle foto's van meerdere producten — de AI groepeert ze zelf per product en maakt concept-listings die jij alleen nog hoeft te keuren.</p>
          <div className="upl" style={{ marginTop: 12 }}>
            <div className="thumbs">
              {uploaded.map((u) => (
                <span key={u} className="imw dk">{/* eslint-disable-next-line @next/next/no-img-element */}<img src={u} alt="" /></span>
              ))}
              <label className="add" style={{ cursor: "pointer" }}>+
                <input type="file" accept="image/*" multiple hidden onChange={(e) => uploadBulk(e.target.files)} />
              </label>
            </div>
            <p>{uploaded.length === 0 ? "Tot 40 foto's tegelijk" : `${uploaded.length} foto's geüpload`}</p>
          </div>
          {err && <p className="note" style={{ color: "var(--amber)" }}>{err}</p>}
          <div className="foot">
            <button className="btn pri" style={{ width: "100%" }} onClick={analyze} disabled={busy || uploaded.length < 2}>
              {busy ? "Uploaden…" : `AI groepeert ${uploaded.length} foto's → concepten`}
            </button>
          </div>
        </>
      )}

      {phase === "analyzing" && (
        <div className="scan">
          <div className="r">Vingerafdrukken maken <span className="done">{uploaded.length} foto's</span></div>
          <div className="r">Groeperen per product <span>bezig…</span></div>
          <div className="r">Concept-listings opstellen <span>…</span></div>
          <p className="note" style={{ marginTop: 12 }}>Even geduld — dit is de stap die je uren handwerk bespaart.</p>
        </div>
      )}

      {phase === "review" && (
        <>
          <div className="dsec"><h2>{drafts.length} concepten</h2><span>{keepCount} geselecteerd</span></div>
          <p className="note">De AI zette de laagste-zekerheid bovenaan — check die eerst. Klopt een groepering niet? Voeg samen of zet uit.</p>
          {drafts.map((d, i) => (
            <div key={d.clusterId} className="dgroup" style={{ marginTop: 12, opacity: d.keep ? 1 : 0.5 }}>
              <div className="dli" style={{ cursor: "default", alignItems: "center" }}>
                <span style={{ display: "flex", gap: 6, flex: "none" }}>
                  {d.photos.slice(0, 3).map((u) => (
                    <span key={u} className="imw dk" style={{ width: 46, height: 46 }}>{/* eslint-disable-next-line @next/next/no-img-element */}<img src={u} alt="" /></span>
                  ))}
                </span>
                <span style={{ flex: 1, marginLeft: 10 }}>
                  <b style={{ fontSize: 12 }}>
                    {d.confidence < 60 ? "⚠ " : ""}{d.confidence}/100 zekerheid{d.uncertainty ? " · model bevestigen" : ""}
                  </b>
                </span>
                <button className="alink" style={{ color: d.keep ? "var(--amber)" : "var(--petrol-glow)", flex: "none" }} onClick={() => upd(i, { keep: !d.keep })}>
                  {d.keep ? "uitzetten" : "aanzetten"}
                </button>
              </div>
              <Field label="Titel"><input style={inp} value={d.title} onChange={(e) => upd(i, { title: e.target.value })} placeholder="Bosch wasmachine 9kg" /></Field>
              {d.candidates.length > 0 && (
                <div className="dli" style={{ cursor: "default" }}>
                  <b style={{ flex: "none", width: 108, fontSize: 11 }}>Kandidaten</b>
                  <span style={{ flex: 1, display: "flex", flexWrap: "wrap", gap: 6 }}>
                    {d.candidates.map((c) => (
                      <button key={c} className="chip" onClick={() => upd(i, { title: c })} style={chip}>{c}</button>
                    ))}
                  </span>
                </div>
              )}
              <Field label="Categorie">
                <select style={{ ...inp, appearance: "none" }} value={d.category} onChange={(e) => upd(i, { category: e.target.value as Cat })}>
                  {CATS.map((c) => <option key={c} value={c} style={{ color: "#000" }}>{c}</option>)}
                </select>
              </Field>
              <Field label="Conditie"><input style={inp} value={d.condition} onChange={(e) => upd(i, { condition: e.target.value })} placeholder="Retour · doos beschadigd" /></Field>
              <Field label="Nieuwprijs €"><input style={inp} type="number" value={d.newPrice} onChange={(e) => upd(i, { newPrice: e.target.value })} placeholder="899" /></Field>
              <Field label="Jouw prijs €"><input style={inp} type="number" value={d.price} onChange={(e) => upd(i, { price: e.target.value })} placeholder="559" /></Field>
              {i > 0 && (
                <div className="dli" style={{ cursor: "default" }}>
                  <span style={{ flex: 1 }} />
                  <button className="alink" style={{ color: "var(--petrol-glow)" }} onClick={() => mergeInto(i)}>↑ voeg samen met vorige</button>
                </div>
              )}
            </div>
          ))}
          {err && <p className="note" style={{ color: "var(--amber)" }}>{err}</p>}
          <div className="foot">
            <button className="btn pri" style={{ width: "100%" }} onClick={publish} disabled={busy || keepCount === 0}>
              {busy ? "Publiceren…" : `Publiceer ${keepCount} product${keepCount === 1 ? "" : "en"}`}
            </button>
          </div>
        </>
      )}

      {phase === "done" && result && (
        <div className="scan">
          <div className="r">Gepubliceerd <span className="done">{result.created} listings</span></div>
          {result.failed > 0 && <div className="r">Overgeslagen <span style={{ color: "var(--amber)" }}>{result.failed} (titel/prijs)</span></div>}
          <div className="foot" style={{ marginTop: 14 }}>
            <button className="btn pri" style={{ width: "100%" }} onClick={() => { router.push("/partner/voorraad"); router.refresh(); }}>
              Naar je voorraad
            </button>
          </div>
        </div>
      )}
    </>
  );
}

const inp: React.CSSProperties = { border: 0, background: "none", font: "inherit", width: "100%", outline: "none", color: "#fff" };
const chip: React.CSSProperties = { fontFamily: "var(--mono)", fontSize: 10, background: "none", border: "1px solid #2A3540", borderRadius: 8, padding: "4px 8px", color: "var(--petrol-glow)", cursor: "pointer" };

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="dli" style={{ cursor: "default" }}>
      <b style={{ flex: "none", width: 108, fontSize: 11 }}>{label}</b>
      <span style={{ flex: 1 }}>{children}</span>
    </div>
  );
}
