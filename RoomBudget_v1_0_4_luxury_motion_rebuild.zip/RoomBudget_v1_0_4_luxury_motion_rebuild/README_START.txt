RoomBudget v1.0.4 luxury motion rebuild

- Full frontend rebuild based on the approved premium dark/gold mockup direction
- Floating glass navigation, animated wizard, budget orbit, cinematic render screen
- Existing backend, AI safety and mock AI provider preserved
- Default port: 8904
- Service: roombudget.service
- Managed folder: /opt/roombudget
