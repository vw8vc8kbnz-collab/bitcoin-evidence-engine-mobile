# v8.8.2 — Stabilisatie + Foto Werkbank zonder AI-bulk

Datum: 2026-07-07

Deze versie is bewust geen feature-sprint maar een stabilisatiebuild. De onveilige AI bulk/foto-dump flow uit v8.8.1 is volledig uit de UI en routes gehaald. De veilige Outlet CRM Foto Werkbank is weer leidend: foto’s blijven eerst los, Outrun maakt geen automatische productclusters, en pas na menselijke selectie/bevestiging ontstaat een product.

## Verwijderd
- `/partner/bulk` route verwijderd.
- `/api/partner/bulk` en `/api/partner/bulk/publish` verwijderd.
- `components/BulkListingFlow.tsx` verwijderd.
- `lib/ai/bulk.ts` verwijderd.
- `?bulk=1` upload-pad verwijderd; losse product-upload blijft max 5 foto's.

## Gefixt
- `VERSION.txt` staat nu op v8.8.2.
- `package.json` staat nu op 8.8.2.
- `package-lock.json` verwijst niet meer naar interne OpenAI/CaaS registry URLs maar naar `registry.npmjs.org`, zodat VPS `npm install` niet meer naar een interne registry probeert te verbinden.
- Partner nieuw-product scherm verwijst niet meer naar AI bulk, maar naar de veilige Foto Werkbank.

## Huidige veilige uploadrichting
- Nieuwe partij aanmaken met referentie.
- Foto’s uploaden naar Foto Werkbank.
- Elke foto start als losse fotokaart.
- Partner selecteert zelf 1–5 foto’s van exact hetzelfde product.
- Pas daarna wordt een product aangemaakt en mag AI listing/pricing draaien.
- Typeplaatjes/labels blijven standaard privé.

# Changelog

## v8.7.1 — Desktop Fullscreen UX Rebuild

Deze versie corrigeert de desktopervaring zonder de mobiele flow te slopen.

### Desktop full screen
- App-container is op desktop niet meer telefoonbreed.
- Buyer- en partnerpagina's gebruiken nu de volledige browserbreedte.
- Desktop krijgt eigen schaalregels vanaf 1024px.
- Horizontale overflow en afgesneden rails/carousels zijn teruggedrongen.

### Buyer homepage
- Discovery/hero-carousels worden desktopwaardig als brede editorial layout weergegeven.
- AI Picks en rails worden echte grids in plaats van half-afgesneden horizontale mobiele sliders.
- Collecties, partner spotlight en AI Finder CTA krijgen aparte desktopposities.

### Productdetail / listing modal
- Desktop listing gebruikt grote sticky gallery links en content rechts.
- Modal is breder en rustiger geschaald.
- Mobiele sheet-look wordt op desktop vervangen door desktop modalregels.

### Checkout
- Checkout krijgt twee kolommen.
- Formulier/levering/betaling links.
- Product en orderoverzicht rechts sticky.

### Categorieën / zoeken
- Categorieoverzicht gebruikt bredere cards en full-width grid.
- Filters worden compacte desktop-sidebar.
- Resultaten worden 2- of 3-koloms desktopgrid.

### Partner / Outlet Workbench
- Partneromgeving blijft donker, maar wordt fullscreen desktop workspace.
- Sidebar breder en werkruimte groter.
- Fotowerkbank krijgt grotere gridtegels op desktop.
- Mobiele dock blijft verborgen op desktop.

# v8.8.0 — Ranking-fundamenten + vision ontkoppeld + foto-dump bulk
De drie langlopende auditpunten opgelost, de vision-merkencyclopedie omgezet naar data,
en de next-level bulk-flow gebouwd.

## Ranking-fundamenten (eindelijk)
- REVIEW-GEKOPPELDE TRUST: sellerTrust() gebruikt nu echte reviewdata met een
  Bayesiaanse demping i.p.v. de binaire 94/68-vlag. Basis 55 (nieuw) / 78 (trusted),
  reviews duwen richting 100 met gewicht dat groeit met het aantal reviews (max 0.7 bij
  >=12). Verdiende reputatie telt nu mee in de home-ranking.
- REPRODUCEERBARE HOME: Math.random() in de ranking vervangen door stableJitter() —
  een deterministische hash op (userId + dag + listingId). De home varieert per dag
  maar is stabiel bij refresh en debugbaar.
- FUZZY ZOEKEN: searchListings() is niet langer substring-only. Nieuwe engine met
  diacriet-normalisatie, token-scoring en Levenshtein-typo-tolerantie ("wasmachien"
  vindt nu wasmachines). Exacte match wint, typefouten vinden alsnog resultaten.

## Vision ontkoppeld van hardcode
- Nieuwe lib/ai/brand-hints.ts: merkkennis (Sony/Thrustmaster/Samsung/Harley/Dyson/Jura)
  als DATA-tabel i.p.v. 178 regels hardgecodeerde prompt + normalize-functies.
- Vision-prompt teruggebracht van ~541 naar ~240 woorden (sterke generieke instructie
  + compact hint-blok). De vier normalizeX-functies vervangen door één generieke
  applyBrandHints()-pass. Uitbreiden = een regel in de tabel, geen code.

## Foto-dump bulk (next-level, audit-advies)
- lib/ai/bulk.ts: fingerprintPhoto() (goedkope vision-pass per foto) → clusterPrints()
  (groepeert foto's per product op merk+categorie+type) → buildConceptListings()
  (volledige analyse per cluster, laag-vertrouwen bovenaan).
- POST /api/partner/bulk (analyse, rate-limit 3/uur) en POST /api/partner/bulk/publish
  (concepten → listings via createListing). Upload-route heeft ?bulk=1 (tot 40 foto's).
- components/BulkListingFlow.tsx: upload → AI groepeert → concept-kaarten die de partner
  keurt (titel/prijs bewerken, kandidaat-chips, samenvoegen, uit/aan) → bulk publiceren.
  Bereikbaar via /partner/bulk (naast de bestaande handmatige Outlet CRM).

# v8.8.1 — Desktop buyer UX-herbouw
De koperkant op desktop was een verticale mobiele kolom in een zee van witruimte.
Volledig herbouwd tot een echte editorial commerce-layout (partnerkant was al goed).
- HOME: "Ontdek vandaag" is nu een hero-grid (grote kaart links, panelen rechts) i.p.v.
  een halve carousel; rails ("Nieuw binnen", "AI Picks", "Laatste stuks") zijn nu
  volle-breedte grids i.p.v. horizontale scroll met witruimte ernaast; deal-van-de-dag,
  spotlight, collecties (4-koloms) en AI Vinder CTA vullen de breedte met hover-leven.
- ZOEKEN/CATEGORIEËN: categorie-hub en resultaten botsten niet meer in dezelfde
  gridcel; resultaten netjes onder de hub.
- AI VINDER: gecentreerde kolom i.p.v. links-plakkend, resultaten als 2-koloms grid.
- Alles schaalt door naar 1440px+ (rails tot 6 kolommen). Fix: l.model uit fuzzy-search
  (bestond niet als los veld op Listing).
