import Link from "next/link";
import { NewListingFlow } from "@/components/NewListingFlow";

export default function Nieuw() {
  return (
    <main className="page narrow" style={{ paddingBottom: 170 }}>
      <header className="hd">
        <Link href="/partner" className="back" style={{ color: "#fff" }}>
          <svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7" /></svg>Stop
        </Link>
        <span className="sp" /><span className="mini" style={{ color: "#8B96A0" }}>NIEUW PRODUCT</span>
      </header>
      <div className="choiceHero"><span className="eyebrow">AANBEVOLEN FLOW</span><h1 className="h1big">Outletpartij of los product?</h1><p>Voor meerdere producten is de Outlet CRM Foto Werkbank de veilige route: eerst batchreferentie, daarna foto’s als losse thumbnails, en pas na jouw bevestiging wordt iets een product.</p><Link href="/partner/outlet" className="btn pri">Start Foto Werkbank</Link><p className="note">AI bulk-groepering is tijdelijk uitgezet. Outrun koppelt geen verschillende producten meer automatisch aan elkaar.</p></div>
      <h2 className="h1big" style={{fontSize:28, marginTop:22}}>Los product</h2>
      <NewListingFlow />
    </main>
  );
}
