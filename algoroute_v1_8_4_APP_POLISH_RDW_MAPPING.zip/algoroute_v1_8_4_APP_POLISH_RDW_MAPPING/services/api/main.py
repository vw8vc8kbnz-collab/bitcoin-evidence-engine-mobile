import os, json, math, re, csv, io, subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional, Any, Dict
from difflib import SequenceMatcher
import httpx
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

APP_VERSION = "1.8.4_APP_POLISH_RDW_MAPPING"
STORE_DIR = Path(os.getenv("ALGOROUTE_STORE", "/app/store"))
STORE_DIR.mkdir(parents=True, exist_ok=True)
OSRM_URL = os.getenv("OSRM_URL", "http://host.docker.internal:5000").rstrip("/")
OPTIMIZER_CORE_BIN = os.getenv("OPTIMIZER_CORE_BIN", "/app/algoroute_core")

app = FastAPI(title="AlgoRoute API", version=APP_VERSION)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

# ----------------------------
# Persistence helpers
# ----------------------------
def load_json(name: str, default: Any):
    path = STORE_DIR / name
    if not path.exists():
        path.write_text(json.dumps(default, indent=2, ensure_ascii=False), encoding="utf-8")
    return json.loads(path.read_text(encoding="utf-8"))

def save_json(name: str, data: Any):
    (STORE_DIR / name).write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

# ----------------------------
# Full universal import field catalog
# ----------------------------
FIELD_CATALOG: List[Dict[str, Any]] = [
    # Order
    {"id":"order_number","label":"Ordernummer","category":"Order","required":True,"type":"text","aliases":["order","ordernr","order nr","order nummer","ordernummer","order_number","order no","bon","bonnummer","referentie","reference","ref","documentnr","documentnummer","webshop order","webshop_order"]},
    {"id":"order_line_number","label":"Orderregelnummer","category":"Order","type":"text","aliases":["regel","regelnummer","line","line number","orderline","order regel","orderregel","itemline"]},
    {"id":"external_reference","label":"Externe referentie","category":"Order","type":"text","aliases":["external reference","extern referentie","klant referentie","client reference","purchase order","po","po number","inkoopnummer"]},
    {"id":"order_status","label":"Orderstatus","category":"Order","type":"text","aliases":["status","order status","orderstatus","release status","vrijgave"]},
    {"id":"source_system","label":"Bron systeem","category":"Order","type":"text","aliases":["source","bron","system","systeem","erp","webshop","platform"]},

    # Customer
    {"id":"customer_name","label":"Klantnaam","category":"Klant","required":True,"type":"text","aliases":["klant","klantnaam","naam klant","customer","customer name","customer_name","client","client name","debiteur","debiteurnaam","aflevernaam","naam","bedrijf","company","company name","organisatie","organisatie naam"]},
    {"id":"customer_number","label":"Klantnummer","category":"Klant","type":"text","aliases":["klantnummer","customer number","customer no","customer_id","debiteur nr","debiteurnummer","client id","klant id"]},
    {"id":"contact_name","label":"Contactpersoon","category":"Klant","type":"text","aliases":["contact","contactpersoon","contact name","attn","tav","ter attentie van","attention"]},
    {"id":"contact_email","label":"E-mail","category":"Klant","type":"email","aliases":["email","e-mail","mail","email address","e-mailadres","contact email"]},
    {"id":"contact_phone","label":"Telefoon","category":"Klant","type":"phone","aliases":["telefoon","phone","tel","mobiel","mobile","gsm","telephone","contact phone"]},

    # Address
    {"id":"delivery_address_full","label":"Volledig afleveradres","category":"Adres","required":True,"type":"address","aliases":["adres","address","delivery address","afleveradres","ship to address","straat + huisnummer","adresregel","address line","volledig adres"]},
    {"id":"street","label":"Straat","category":"Adres","type":"text","aliases":["straat","street","road","straatnaam","address street"]},
    {"id":"house_number","label":"Huisnummer","category":"Adres","type":"text","aliases":["huisnummer","huisnr","house number","nr","number","building number"]},
    {"id":"house_number_suffix","label":"Huisnummer toevoeging","category":"Adres","type":"text","aliases":["toevoeging","huisnummer toevoeging","suffix","addition","bus","unit"]},
    {"id":"postal_code","label":"Postcode","category":"Adres","required":True,"type":"postcode_nl","aliases":["postcode","post code","postal code","zip","zipcode","zip code","pc","postcode nl"]},
    {"id":"city","label":"Plaats","category":"Adres","required":True,"type":"city","aliases":["plaats","woonplaats","city","stad","town","gemeente","locality"]},
    {"id":"country","label":"Land","category":"Adres","type":"country","aliases":["land","country","landcode","country code","iso country"]},
    {"id":"latitude","label":"Latitude","category":"Adres","type":"number","aliases":["latitude","lat","breedtegraad","gps lat","gps_lat"]},
    {"id":"longitude","label":"Longitude","category":"Adres","type":"number","aliases":["longitude","lon","lng","lengtegraad","gps lon","gps_lng","gps long"]},

    # Delivery/date/time windows
    {"id":"delivery_date","label":"Leverdatum","category":"Tijdvenster","required":True,"type":"date","aliases":["leverdatum","delivery date","date","datum","afleverdatum","scheduled date","planning date","planned date","ritdatum","bezorgdatum"]},
    {"id":"time_window_start","label":"Tijdvenster start","category":"Tijdvenster","type":"time","aliases":["tijd start","starttijd","window start","time window start","delivery window start","van","vanaf","not before","niet voor","from","start"]},
    {"id":"time_window_end","label":"Tijdvenster eind","category":"Tijdvenster","type":"time","aliases":["tijd eind","eindtijd","window end","time window end","delivery window end","tot","tot en met","not after","niet na","until","end"]},
    {"id":"time_window_combined","label":"Tijdslot gecombineerd","category":"Tijdvenster","type":"time_window","aliases":["tijdslot","tijd venster","tijdvenster","window","time window","delivery window","slot","timeslot","tijd","delivery slot","levervenster"]},
    {"id":"appointment_required","label":"Afspraak verplicht","category":"Tijdvenster","type":"boolean","aliases":["afspraak","appointment","appointment required","afspraak verplicht","bel afspraak","op afspraak"]},
    {"id":"max_delay_minutes","label":"Max vertraging toegestaan","category":"Tijdvenster","type":"integer","aliases":["max vertraging","max delay","delay allowed","max late","max_late_minutes","customer promise","promise guard"]},

    # Load and products
    {"id":"product_sku","label":"SKU / artikelnummer","category":"Producten","type":"text","aliases":["sku","artikel","artikelnummer","productcode","product code","item","item code","article","article number"]},
    {"id":"product_name","label":"Productnaam","category":"Producten","type":"text","aliases":["product","productnaam","omschrijving","description","item description","artikel omschrijving","product name"]},
    {"id":"quantity","label":"Aantal","category":"Producten","type":"integer","aliases":["aantal","qty","quantity","hoeveelheid","stuks","pcs","pieces","colli"]},
    {"id":"weight_kg","label":"Gewicht kg","category":"Gewicht & Volume","type":"number","aliases":["gewicht","kg","weight","weight kg","gewicht kg","totaalgewicht","gross weight","bruto gewicht"]},
    {"id":"weight_g","label":"Gewicht gram","category":"Gewicht & Volume","type":"integer","aliases":["gewicht gram","weight g","grams","gram","gewicht_g"]},
    {"id":"volume_m3","label":"Volume m³","category":"Gewicht & Volume","type":"number","aliases":["volume","m3","m³","cbm","cubic","kuub","kubieke meter"]},
    {"id":"length_mm","label":"Lengte mm","category":"Gewicht & Volume","type":"integer","aliases":["lengte","length","len","l","lengte mm","length mm"]},
    {"id":"width_mm","label":"Breedte mm","category":"Gewicht & Volume","type":"integer","aliases":["breedte","width","w","breedte mm","width mm"]},
    {"id":"height_mm","label":"Hoogte mm","category":"Gewicht & Volume","type":"integer","aliases":["hoogte","height","h","hoogte mm","height mm"]},
    {"id":"europallets","label":"Europallets","category":"Pallets & Rolcontainers","type":"integer","aliases":["pallet","pallets","europallet","europallets","epal","ep","aantal pallets","pallet qty","pallet_count"]},
    {"id":"block_pallets","label":"Blokpallets","category":"Pallets & Rolcontainers","type":"integer","aliases":["blokpallet","blokpallets","block pallet","block pallets"]},
    {"id":"roll_containers","label":"Rolcontainers","category":"Pallets & Rolcontainers","type":"integer","aliases":["rolcontainer","rolcontainers","rc","rollcontainer","roll container","roll containers","rolco","roll cage"]},
    {"id":"loading_meters","label":"Laadmeters","category":"Pallets & Rolcontainers","type":"number","aliases":["laadmeter","laadmeters","ldm","loading meter","loading meters","load meters"]},
    {"id":"stackable","label":"Stapelbaar","category":"Load regels","type":"boolean","aliases":["stapelbaar","stackable","mag stapelen","stacking","can stack"]},
    {"id":"fragile","label":"Breekbaar","category":"Load regels","type":"boolean","aliases":["breekbaar","fragile","glas","kwetsbaar","delicate"]},
    {"id":"tiltable","label":"Kantelbaar","category":"Load regels","type":"boolean","aliases":["kantelbaar","tiltable","niet kantelen","do not tilt","upright","rechtop"]},
    {"id":"hazard_tags","label":"Hazard tags","category":"Load regels","type":"list","aliases":["hazard","dangerous goods","adr","gevaarlijke stoffen","chemical","chemisch","food","frozen","tags"]},
    {"id":"temperature_zone","label":"Temperatuurzone","category":"Load regels","type":"text","aliases":["temperature","temp zone","temperatuur","koel","gekoeld","frozen","ambient","chilled","frozen"]},

    # Planning/service
    {"id":"service_time_minutes","label":"Service/lostijd minuten","category":"Service","type":"integer","aliases":["lostijd","los tijd","service time","service minutes","handling time","handling_time","minuten lossen","delivery duration","install time","montagetijd"]},
    {"id":"priority","label":"Prioriteit","category":"Planning","type":"integer","aliases":["prioriteit","priority","urgent","spoed","rush","importance","urgency"]},
    {"id":"driver_notes","label":"Chauffeursinstructies","category":"Instructies","type":"text","aliases":["instructies","instructions","driver notes","chauffeur instructies","instructies chauffeur","opmerking chauffeur","delivery notes","notities"]},
    {"id":"access_notes","label":"Toegang/lift/verdieping","category":"Service","type":"text","aliases":["lift","verdieping","floor","access","toegang","parking","parkeerinfo","etage"]},
    {"id":"installation_required","label":"Montage/installatie vereist","category":"Service","type":"boolean","aliases":["montage","installatie","installatie vereist","install required","install","installation","installation required","assembly","plaatsen","monteren"]},
    {"id":"two_person_delivery","label":"Twee personen nodig","category":"Service","type":"boolean","aliases":["2 man","twee man","two person","2 persons","two_person","extra man","bijrijder"]},
    {"id":"return_pickup","label":"Retour/ophalen","category":"Service","type":"boolean","aliases":["retour","return","pickup","ophalen","retourname","take back"]},

    # Tracking/finance/custom
    {"id":"tracking_email_allowed","label":"Klant e-mail tracking toegestaan","category":"Tracking","type":"boolean","aliases":["tracking email","mail tracking","notify email","email notificatie"]},
    {"id":"tracking_sms_allowed","label":"Klant SMS tracking toegestaan","category":"Tracking","type":"boolean","aliases":["sms","sms tracking","notify sms","sms notificatie"]},
    {"id":"invoice_number","label":"Factuurnummer","category":"Finance","type":"text","aliases":["factuur","factuurnummer","invoice","invoice number","invoice no"]},
    {"id":"cod_amount","label":"Remboers / te innen bedrag","category":"Finance","type":"number","aliases":["rembours","cod","cash on delivery","te innen","collect amount","bedrag innen"]},
    {"id":"custom_1","label":"Custom veld 1","category":"Custom","type":"text","aliases":["custom1","extra1","vrij veld 1"]},
    {"id":"custom_2","label":"Custom veld 2","category":"Custom","type":"text","aliases":["custom2","extra2","vrij veld 2"]},
]

REQUIRED_FIELDS = [f["id"] for f in FIELD_CATALOG if f.get("required")]

# ----------------------------
# Mapping detection helpers
# ----------------------------
def norm(s: Any) -> str:
    s = str(s or "").lower().strip()
    s = re.sub(r"[_\-./]+", " ", s)
    s = re.sub(r"[^a-z0-9áàäéèëíìïóòöúùüñç\s]", "", s)
    return re.sub(r"\s+", " ", s).strip()


# Exact header mapping has absolute priority over fuzzy/value detection.
# This prevents numeric columns like Huisnummer, Service/lostijd or Niet leveren voor
# from being hijacked by generic volume/weight/length fields.
DIRECT_HEADER_MAP = {
    "ordernummer": "order_number",
    "order nummer": "order_number",
    "orderregel": "order_line_number",
    "orderregelnummer": "order_line_number",
    "externe referentie": "external_reference",
    "klantnaam": "customer_name",
    "klantnummer": "customer_number",
    "contactpersoon": "contact_name",
    "telefoon": "contact_phone",
    "e mail": "contact_email",
    "email": "contact_email",
    "volledig afleveradres": "delivery_address_full",
    "afleveradres": "delivery_address_full",
    "straat": "street",
    "huisnummer": "house_number",
    "huisnr": "house_number",
    "huisnummer toevoeging": "house_number_suffix",
    "postcode": "postal_code",
    "plaats": "city",
    "woonplaats": "city",
    "land": "country",
    "latitude": "latitude",
    "lat": "latitude",
    "longitude": "longitude",
    "lng": "longitude",
    "lon": "longitude",
    "leverdatum": "delivery_date",
    "tijdvenster start": "time_window_start",
    "tijdvenster starttijd": "time_window_start",
    "tijdvenster eind": "time_window_end",
    "tijdvenster eindtijd": "time_window_end",
    "tijdslot gecombineerd": "time_window_combined",
    "tijdslot": "time_window_combined",
    "niet leveren voor": "time_window_start",
    "niet leveren vóór": "time_window_start",
    "niet leveren na": "time_window_end",
    "service lostijd minuten": "service_time_minutes",
    "service lostijd min": "service_time_minutes",
    "lostijd": "service_time_minutes",
    "prioriteit": "priority",
    "europallets": "europallets",
    "ep": "europallets",
    "rolcontainers": "roll_containers",
    "rc": "roll_containers",
    "gewicht kg": "weight_kg",
    "gewicht": "weight_kg",
    "volume m3": "volume_m3",
    "volume m": "volume_m3",
    "productnaam": "product_name",
    "product omschrijving": "product_name",
    "aantal": "quantity",
    "afspraak verplicht": "appointment_required",
    "max vertraging toegestaan": "max_delay_minutes",
    "instructies chauffeur": "driver_instructions",
    "installatie vereist": "installation_required",
}

def direct_header_field(header: str):
    return DIRECT_HEADER_MAP.get(norm(header))

def ratio(a: str, b: str) -> float:
    if not a or not b:
        return 0.0
    if a == b:
        return 1.0
    if a in b or b in a:
        return 0.88
    return SequenceMatcher(None, a, b).ratio()

postcode_re = re.compile(r"^[1-9][0-9]{3}\s?[A-Z]{2}$", re.I)
time_re = re.compile(r"\b([01]?\d|2[0-3])[:.][0-5]\d\b")
time_window_re = re.compile(r"([01]?\d|2[0-3])[:.][0-5]\d\s*[-–]\s*([01]?\d|2[0-3])[:.][0-5]\d")
email_re = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
phone_re = re.compile(r"^(\+31|0031|0)[0-9\s\-]{8,}$")

def value_signal(values: List[Any], field: Dict[str, Any]) -> float:
    vals = [str(v).strip() for v in values if str(v).strip()][:25]
    if not vals:
        return 0.0
    t = field.get("type")
    hits = 0
    for v in vals:
        if t == "postcode_nl" and postcode_re.match(v): hits += 1
        elif t == "email" and email_re.match(v): hits += 1
        elif t == "phone" and phone_re.match(v): hits += 1
        elif t == "time" and time_re.search(v): hits += 1
        elif t == "time_window" and time_window_re.search(v): hits += 1
        elif t in ("integer","number"):
            x = v.lower().replace("kg","").replace("m3","").replace("m³","").replace(",",".").strip()
            try: float(re.sub(r"[^0-9.\-]", "", x)); hits += 1
            except Exception: pass
        elif t == "date":
            if re.search(r"\b\d{1,2}[-/]\d{1,2}[-/]\d{2,4}\b", v) or re.search(r"\b\d{4}-\d{1,2}-\d{1,2}\b", v): hits += 1
        elif t == "boolean" and norm(v) in ["ja","nee","yes","no","true","false","1","0","y","n"]: hits += 1
    return min(1.0, hits / max(1, len(vals)))

def score_field(header: str, samples: List[Any], field: Dict[str, Any]) -> float:
    h = norm(header)
    direct = direct_header_field(header)
    if direct:
        return 1.0 if field.get("id") == direct else 0.0
    aliases = [field["label"], field["id"]] + field.get("aliases", [])
    alias_norms = [norm(a) for a in aliases]
    header_score = max(ratio(h, a) for a in alias_norms)
    value_score = value_signal(samples, field)

    # 1) Header is king. If the CSV column literally says "Klantnaam", "Postcode",
    # "Leverdatum" etc., it must auto-map even if the value type is generic text.
    if h in alias_norms:
        return 1.0
    if header_score >= 0.86:
        return round(max(0.92, header_score), 4)

    # 2) For known-ish headers, let value patterns help a little, but never let a
    # generic numeric value hijack columns like Huisnummer -> Volume/Hoogte.
    if header_score >= 0.62:
        return round((header_score * 0.9) + (value_score * 0.1), 4)

    # 3) Only use value-pattern rescue for distinctive fields such as postcode, email,
    # phone, time/date/time-window. Numeric-only columns are too ambiguous.
    distinctive = field.get("type") in ["postcode_nl", "email", "phone", "time", "time_window", "date", "boolean"]
    if distinctive and value_score > 0.85 and header_score > 0.28:
        return 0.86

    return round((header_score * 0.82) + (value_score * 0.18), 4)

def detect_mapping(headers: List[str], rows: List[Dict[str, Any]]):
    results = []
    used = set()
    for header in headers:
        samples = [r.get(header, "") for r in rows[:30]]
        candidates = []
        for f in FIELD_CATALOG:
            s = score_field(header, samples, f)
            if s > 0.25:
                candidates.append({"field_id": f["id"], "label": f["label"], "category": f["category"], "score": int(round(s*100)), "type": f.get("type")})
        candidates.sort(key=lambda x: x["score"], reverse=True)
        best = candidates[0] if candidates else None
        if best and best["score"] >= 58 and best["field_id"] not in used:
            used.add(best["field_id"])
            status = "auto" if best["score"] >= 82 else "review"
        elif best:
            status = "review"
        else:
            status = "unmapped"
        results.append({"column": header, "samples": samples[:5], "best": best, "status": status, "candidates": candidates[:6]})
    return results

# ----------------------------
# API models
# ----------------------------
class RouteRequest(BaseModel):
    coordinates: List[List[float]]

class MatrixRequest(BaseModel):
    coordinates: List[List[float]]

class DetectMappingRequest(BaseModel):
    headers: List[str]
    rows: List[Dict[str, Any]] = []

class CommitImportRequest(BaseModel):
    rows: List[Dict[str, Any]]
    mapping: Dict[str, str]
    template_name: Optional[str] = None


# ----------------------------
# PDOK/BAG geocoding helpers
# ----------------------------
class GeocodeAddressRequest(BaseModel):
    query: Optional[str] = None
    street: Optional[str] = None
    house_number: Optional[str] = None
    postal_code: Optional[str] = None
    city: Optional[str] = None

class GeocodeQueueRequest(BaseModel):
    limit: int = 250
    overwrite: bool = False


def has_gps(order: Dict[str, Any]) -> bool:
    return order.get("latitude") not in [None, ""] and order.get("longitude") not in [None, ""]

def refresh_order_status(order: Dict[str, Any]) -> Dict[str, Any]:
    """Single source of truth for Planning Queue readiness.

    Important: a Dutch address may be ready for routing after PDOK/BAG has resolved
    latitude/longitude even when the original CSV did not contain a postcode. PDOK
    sometimes returns postal_code as null too, so postal_code must not keep a
    geocoded order stuck as incomplete.
    """
    missing = []
    for f in ["order_number", "customer_name", "city", "delivery_date"]:
        if not order.get(f):
            missing.append(f)
    if not order.get("postal_code") and not has_gps(order):
        missing.append("postal_code_or_gps")
    if not has_gps(order):
        missing.append("gps")
    order["missing"] = missing
    order["status"] = "ready" if not missing else "incomplete"
    return order

def build_address_query(order_or_req: Dict[str, Any]) -> str:
    direct = str(order_or_req.get("query") or order_or_req.get("delivery_address") or "").strip()
    street = str(order_or_req.get("street") or "").strip()
    house = str(order_or_req.get("house_number") or "").strip()
    postal = str(order_or_req.get("postal_code") or "").strip()
    city = str(order_or_req.get("city") or "").strip()
    if direct and (postal or city):
        return f"{direct}, {postal} {city}".strip()
    if direct:
        return direct
    return " ".join(x for x in [street, house, postal, city] if x).strip()

def parse_pdok_point(centroide: str):
    # PDOK returns strings like POINT(4.9041 52.3676) = lon lat
    if not centroide:
        return None
    m = re.search(r"POINT\(([-0-9.]+)\s+([-0-9.]+)\)", centroide)
    if not m:
        return None
    return float(m.group(1)), float(m.group(2))

def pdok_confidence(doc: Dict[str, Any], query: str) -> int:
    score = 72
    q = norm(query)
    label = norm(doc.get("weergavenaam") or doc.get("straatnaam") or "")
    if q and label:
        score = max(score, int(ratio(q, label) * 100))
    if doc.get("postcode") and str(doc.get("postcode")).replace(" ", "").upper() in query.replace(" ", "").upper():
        score += 8
    if doc.get("huisnummer") and str(doc.get("huisnummer")) in query:
        score += 6
    if doc.get("type") in ["adres", "nummeraanduiding", "verblijfsobject"]:
        score += 4
    return min(99, max(35, score))

async def geocode_pdok(query: str):
    if not query or len(query.strip()) < 4:
        return {"matched": False, "query": query, "error": "Te weinig adresinformatie"}
    url = "https://api.pdok.nl/bzk/locatieserver/search/v3_1/free"
    params = {"q": query, "rows": 5, "fq": "type:(adres OR nummeraanduiding OR verblijfsobject OR weg)", "fl": "id,weergavenaam,straatnaam,huisnummer,postcode,woonplaatsnaam,gemeentenaam,type,centroide_ll"}
    try:
        async with httpx.AsyncClient(timeout=12.0) as client:
            r = await client.get(url, params=params)
            r.raise_for_status()
            docs = r.json().get("response", {}).get("docs", [])
    except Exception as e:
        return {"matched": False, "query": query, "error": f"PDOK/BAG niet bereikbaar: {e}"}
    candidates = []
    for d in docs:
        pt = parse_pdok_point(d.get("centroide_ll", ""))
        if not pt:
            continue
        candidates.append({
            "label": d.get("weergavenaam") or "",
            "street": d.get("straatnaam"),
            "house_number": d.get("huisnummer"),
            "postal_code": d.get("postcode"),
            "city": d.get("woonplaatsnaam"),
            "municipality": d.get("gemeentenaam"),
            "type": d.get("type"),
            "longitude": pt[0],
            "latitude": pt[1],
            "confidence": pdok_confidence(d, query),
        })
    candidates.sort(key=lambda x: x["confidence"], reverse=True)
    if not candidates:
        return {"matched": False, "query": query, "candidates": [], "error": "Geen PDOK-match gevonden"}
    best = candidates[0]
    return {"matched": best["confidence"] >= 70, "query": query, "best": best, "candidates": candidates[:5]}

# ----------------------------
# OSRM
# ----------------------------
@app.get("/api/health")
def health():
    return {"ok": True, "app": "AlgoRoute", "version": APP_VERSION, "time": datetime.now(timezone.utc).isoformat()}

async def osrm_probe():
    try:
        async with httpx.AsyncClient(timeout=2.5) as client:
            r = await client.get(f"{OSRM_URL}/route/v1/driving/5.2913,52.1326;5.2920,52.1330", params={"overview":"false"})
            return r.status_code == 200, None if r.status_code == 200 else f"OSRM HTTP {r.status_code}"
    except Exception as e:
        return False, str(e)

@app.get("/api/routing/status")
async def routing_status():
    ok, err = await osrm_probe()
    return {"available": ok, "url": OSRM_URL, "message": "OSRM Nederland is actief" if ok else f"OSRM nog niet actief: {err}. Run scripts/setup_osrm_nl.sh op de VPS."}

@app.post("/api/routing/route")
async def routing_route(req: RouteRequest):
    if len(req.coordinates) < 2:
        raise HTTPException(400, "Minimaal twee coördinaten nodig")
    coord_str = ";".join([f"{c[0]},{c[1]}" for c in req.coordinates])
    try:
        async with httpx.AsyncClient(timeout=25) as client:
            r = await client.get(f"{OSRM_URL}/route/v1/driving/{coord_str}", params={"overview":"full","geometries":"geojson","steps":"false"})
            if r.status_code != 200:
                raise HTTPException(503, f"OSRM route error {r.status_code}: {r.text[:180]}")
            data = r.json(); route = data["routes"][0]
            return {"ok": True, "distance_m": route["distance"], "duration_s": route["duration"], "geometry": route["geometry"]}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(503, f"OSRM niet bereikbaar: {e}")

@app.post("/api/routing/matrix")
async def routing_matrix(req: MatrixRequest):
    if len(req.coordinates) < 2:
        raise HTTPException(400, "Minimaal twee coördinaten nodig")
    coord_str = ";".join([f"{c[0]},{c[1]}" for c in req.coordinates])
    try:
        async with httpx.AsyncClient(timeout=35) as client:
            r = await client.get(f"{OSRM_URL}/table/v1/driving/{coord_str}", params={"annotations":"duration,distance"})
            if r.status_code != 200:
                raise HTTPException(503, f"OSRM matrix error {r.status_code}: {r.text[:180]}")
            data = r.json()
            return {"ok": True, "durations": data.get("durations"), "distances": data.get("distances")}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(503, f"OSRM niet bereikbaar: {e}")


# ----------------------------
# PDOK/BAG geocoding endpoints
# ----------------------------
@app.get("/api/geocode/status")
def geocode_status():
    return {"provider": "PDOK/BAG Locatieserver", "country": "NL", "status": "configured", "note": "Gebruikt live PDOK/BAG Locatieserver voor Nederlandse adressen zodra de VPS internettoegang heeft."}

@app.post("/api/geocode/address")
async def geocode_address(req: GeocodeAddressRequest):
    payload = req.model_dump()
    q = build_address_query(payload)
    return await geocode_pdok(q)

@app.post("/api/geocode/queue")
async def geocode_queue(req: GeocodeQueueRequest):
    orders = load_json("orders.json", [])
    results = []
    updated = 0
    unresolved = 0
    for order in orders[:max(1, req.limit)]:
        already = order.get("latitude") and order.get("longitude")
        if already and not req.overwrite:
            refresh_order_status(order)
            results.append({"order_id": order.get("id"), "order_number": order.get("order_number"), "skipped": True, "reason": "Heeft al GPS", "status": order.get("status"), "missing": order.get("missing", [])})
            continue
        q = build_address_query(order)
        res = await geocode_pdok(q)
        if res.get("matched") and res.get("best"):
            best = res["best"]
            order["latitude"] = best["latitude"]
            order["longitude"] = best["longitude"]
            order["geocode"] = {"provider": "PDOK/BAG", "confidence": best["confidence"], "label": best["label"], "city": best.get("city"), "postal_code": best.get("postal_code")}
            if not order.get("postal_code") and best.get("postal_code"):
                order["postal_code"] = best.get("postal_code")
            if not order.get("city") and best.get("city"):
                order["city"] = best.get("city")
            refresh_order_status(order)
            updated += 1
        else:
            order["geocode"] = {"provider": "PDOK/BAG", "confidence": 0, "error": res.get("error"), "query": q}
            unresolved += 1
        results.append({"order_id": order.get("id"), "order_number": order.get("order_number"), "query": q, "result": res})
    save_json("orders.json", orders)
    return {"ok": True, "updated": updated, "unresolved": unresolved, "total_checked": len(results), "results": results[:50]}

# ----------------------------
# Core data
# ----------------------------
@app.get("/api/map/state")
def map_state():
    return {"center": [5.2913, 52.1326], "zoom": 6.9, "vehicles": load_json("vehicles.json", []), "routes": load_json("routes.json", []), "events": load_json("events.json", []), "traffic_segments": load_json("traffic_segments.json", []), "message": "Geen dummydata. Kaart vult zodra routes/voertuigen bestaan."}


@app.get("/api/rdw/lookup")
async def rdw_lookup(kenteken: str):
    plate = re.sub(r"[^A-Za-z0-9]", "", kenteken or "").upper()
    if not plate:
        raise HTTPException(400, "Kenteken ontbreekt")
    url = "https://opendata.rdw.nl/resource/m9d7-ebf2.json"
    try:
        async with httpx.AsyncClient(timeout=8.0) as client:
            resp = await client.get(url, params={"kenteken": plate})
            resp.raise_for_status()
            data = resp.json()
    except Exception as exc:
        return {"ok": False, "found": False, "error": "RDW lookup tijdelijk niet beschikbaar", "detail": str(exc)[:180]}
    if not data:
        return {"ok": True, "found": False, "kenteken": plate}
    v = data[0]
    return {
        "ok": True,
        "found": True,
        "kenteken": v.get("kenteken", plate),
        "brand": v.get("merk"),
        "model": v.get("handelsbenaming"),
        "vehicle_type": v.get("voertuigsoort") or v.get("inrichting"),
        "inrichting": v.get("inrichting"),
        "massa_ledig_voertuig": v.get("massa_ledig_voertuig"),
        "massa_rijklaar": v.get("massa_rijklaar"),
        "toegestane_maximum_massa_voertuig": v.get("toegestane_maximum_massa_voertuig"),
        "source": "RDW Open Data m9d7-ebf2"
    }

@app.get("/api/vehicles")
def vehicles(): return load_json("vehicles.json", [])

@app.post("/api/vehicles")
def create_vehicle(payload: dict):
    vehicles = load_json("vehicles.json", [])
    payload.setdefault("id", f"vehicle_{len(vehicles)+1}")
    vehicles.append(payload); save_json("vehicles.json", vehicles)
    return {"ok": True, "vehicle": payload}


@app.put("/api/vehicles/{vehicle_id}")
def update_vehicle(vehicle_id: str, payload: dict):
    vehicles = load_json("vehicles.json", [])
    for i, v in enumerate(vehicles):
        if str(v.get("id")) == vehicle_id:
            payload["id"] = vehicle_id
            vehicles[i] = {**v, **payload}
            save_json("vehicles.json", vehicles)
            return {"ok": True, "vehicle": vehicles[i]}
    raise HTTPException(404, "Voertuig niet gevonden")

@app.delete("/api/vehicles/{vehicle_id}")
def delete_vehicle(vehicle_id: str):
    vehicles = load_json("vehicles.json", [])
    new = [v for v in vehicles if str(v.get("id")) != vehicle_id]
    save_json("vehicles.json", new)
    return {"ok": True, "deleted": len(vehicles) - len(new)}

@app.get("/api/drivers")
def drivers(): return load_json("drivers.json", [])

@app.post("/api/drivers")
def create_driver(payload: dict):
    drivers = load_json("drivers.json", [])
    payload.setdefault("id", f"driver_{len(drivers)+1}")
    payload.setdefault("status", "available")
    drivers.append(payload); save_json("drivers.json", drivers)
    return {"ok": True, "driver": payload}

@app.put("/api/drivers/{driver_id}")
def update_driver(driver_id: str, payload: dict):
    drivers = load_json("drivers.json", [])
    for i, d in enumerate(drivers):
        if str(d.get("id")) == driver_id:
            payload["id"] = driver_id
            drivers[i] = {**d, **payload}
            save_json("drivers.json", drivers)
            return {"ok": True, "driver": drivers[i]}
    raise HTTPException(404, "Chauffeur niet gevonden")

@app.delete("/api/drivers/{driver_id}")
def delete_driver(driver_id: str):
    drivers = load_json("drivers.json", [])
    new = [d for d in drivers if str(d.get("id")) != driver_id]
    save_json("drivers.json", new)
    return {"ok": True, "deleted": len(drivers) - len(new)}

@app.post("/api/testdata/fleet")
def load_test_fleet():
    vehicles = [
        {"id":"veh_001","name":"Bus 01","license_plate":"V-123-AB","brand":"Mercedes-Benz","model":"Sprinter 319","vehicle_type":"bakwagen","status":"available","fuel_type":"diesel","europallet_capacity":8,"roll_container_capacity":10,"max_weight_kg":1250,"max_volume_m3":15},
        {"id":"veh_002","name":"Bus 02","license_plate":"V-456-CD","brand":"Volkswagen","model":"Crafter L4H3","vehicle_type":"bestelbus","status":"available","fuel_type":"diesel","europallet_capacity":6,"roll_container_capacity":8,"max_weight_kg":1100,"max_volume_m3":13},
        {"id":"veh_003","name":"EV 03","license_plate":"V-789-EF","brand":"Ford","model":"E-Transit","vehicle_type":"ev bestelbus","status":"available","fuel_type":"electric","europallet_capacity":5,"roll_container_capacity":7,"max_weight_kg":950,"max_volume_m3":11,"battery_capacity_kwh":68,"range_empty_km":260,"range_loaded_km":185,"current_soc_percent":92,"min_soc_percent":15},
        {"id":"veh_004","name":"Bakwagen 04","license_plate":"V-321-GH","brand":"Iveco","model":"Daily 35C18","vehicle_type":"bakwagen laadklep","status":"maintenance","maintenance_until":"2026-07-05","fuel_type":"diesel","europallet_capacity":10,"roll_container_capacity":12,"max_weight_kg":1600,"max_volume_m3":18},
        {"id":"veh_005","name":"EV 05","license_plate":"V-654-JK","brand":"Mercedes-Benz","model":"eSprinter","vehicle_type":"ev bestelbus","status":"available","fuel_type":"electric","europallet_capacity":4,"roll_container_capacity":6,"max_weight_kg":850,"max_volume_m3":10,"battery_capacity_kwh":81,"range_empty_km":300,"range_loaded_km":210,"current_soc_percent":76,"min_soc_percent":18}
    ]
    drivers = [
        {"id":"drv_001","name":"Milan de Vries","phone":"+31610000001","email":"milan@example.nl","status":"available","license_type":"B","assigned_vehicle_id":"veh_001","app_access":"active"},
        {"id":"drv_002","name":"Jan de Groot","phone":"+31610000002","email":"jan@example.nl","status":"available","license_type":"B","assigned_vehicle_id":"veh_002","app_access":"active"},
        {"id":"drv_003","name":"Pieter Smit","phone":"+31610000003","email":"pieter@example.nl","status":"available","license_type":"B","assigned_vehicle_id":"veh_003","app_access":"active"},
        {"id":"drv_004","name":"Marco Jansen","phone":"+31610000004","email":"marco@example.nl","status":"unavailable","license_type":"C1","assigned_vehicle_id":"veh_004","app_access":"invited"},
        {"id":"drv_005","name":"Tom Bakker","phone":"+31610000005","email":"tom@example.nl","status":"available","license_type":"B","assigned_vehicle_id":"veh_005","app_access":"active"}
    ]
    save_json("vehicles.json", vehicles)
    save_json("drivers.json", drivers)
    return {"ok": True, "vehicles": len(vehicles), "drivers": len(drivers), "note": "Test-vloot geladen. Dit gebeurt alleen handmatig via deze knop/API."}

@app.get("/api/routes")
def routes(): return load_json("routes.json", [])

@app.get("/api/planning/queue")
def planning_queue():
    orders = load_json("orders.json", [])
    return {"version": APP_VERSION, "orders": orders, "summary": {"count": len(orders), "ready": len([o for o in orders if o.get("status") == "ready"]), "incomplete": len([o for o in orders if o.get("status") != "ready"])}}

# ----------------------------
# Full import/mapping endpoints
# ----------------------------
@app.get("/api/import/fields")
def import_fields():
    cats = []
    for cat in sorted(set(f["category"] for f in FIELD_CATALOG)):
        cats.append({"category": cat, "fields": [f for f in FIELD_CATALOG if f["category"] == cat]})
    return {"version": APP_VERSION, "required_fields": REQUIRED_FIELDS, "categories": cats, "fields": FIELD_CATALOG}

@app.post("/api/import/detect")
def import_detect(req: DetectMappingRequest):
    return {"ok": True, "detections": detect_mapping(req.headers, req.rows), "required_fields": REQUIRED_FIELDS}

@app.get("/api/import/templates")
def get_templates():
    return {"templates": load_json("mapping_templates.json", [])}

@app.post("/api/import/templates")
def save_template(payload: dict):
    templates = load_json("mapping_templates.json", [])
    payload.setdefault("id", f"template_{len(templates)+1}")
    payload["updated_at"] = datetime.now(timezone.utc).isoformat()
    templates = [t for t in templates if t.get("id") != payload["id"] and t.get("name") != payload.get("name")]
    templates.append(payload)
    save_json("mapping_templates.json", templates)
    return {"ok": True, "template": payload}

def parse_bool(v):
    s = norm(v)
    if s in ["ja","yes","true","1","y","waar"]: return True
    if s in ["nee","no","false","0","n","onwaar"]: return False
    return None

def parse_number(v, default=0):
    if v is None: return default
    s = str(v).replace(",", ".")
    s = re.sub(r"[^0-9.\-]", "", s)
    try: return float(s) if s not in ["", ".", "-"] else default
    except Exception: return default

def normalize_order(row: Dict[str, Any], mapping: Dict[str, str], idx: int):
    out = {"id": f"order_{int(datetime.now().timestamp())}_{idx}", "status": "ready", "raw": row}
    reverse = {field: col for col, field in mapping.items() if field}
    def val(fid, default=""):
        col = reverse.get(fid)
        return row.get(col, default) if col is not None else default
    out["order_number"] = str(val("order_number", f"IMPORT-{idx+1}")).strip() or f"IMPORT-{idx+1}"
    out["customer_name"] = str(val("customer_name", "")).strip()
    out["delivery_address"] = str(val("delivery_address_full", "")).strip()
    street = str(val("street", "")).strip(); house = str(val("house_number", "")).strip()
    if not out["delivery_address"] and (street or house): out["delivery_address"] = f"{street} {house}".strip()
    out["postal_code"] = str(val("postal_code", "")).strip().upper()
    out["city"] = str(val("city", "")).strip()
    out["delivery_date"] = str(val("delivery_date", "")).strip()
    tw = str(val("time_window_combined", "")).strip()
    out["time_window_start"] = str(val("time_window_start", "")).strip()
    out["time_window_end"] = str(val("time_window_end", "")).strip()
    m = time_window_re.search(tw)
    if m and not out["time_window_start"] and not out["time_window_end"]:
        parts = re.findall(r"([01]?\d|2[0-3])[:.][0-5]\d", tw)
        if len(parts) >= 2:
            times = re.findall(r"\b(?:[01]?\d|2[0-3])[:.][0-5]\d\b", tw.replace('.',':'))
            out["time_window_start"], out["time_window_end"] = times[0], times[1]
    out["service_time_minutes"] = int(parse_number(val("service_time_minutes", 15), 15))
    out["weight_kg"] = parse_number(val("weight_kg", 0), 0) or (parse_number(val("weight_g", 0), 0) / 1000)
    out["volume_m3"] = parse_number(val("volume_m3", 0), 0)
    out["europallets"] = int(parse_number(val("europallets", 0), 0))
    out["roll_containers"] = int(parse_number(val("roll_containers", 0), 0))
    out["priority"] = int(parse_number(val("priority", 0), 0))
    lat, lng = parse_number(val("latitude", None), None), parse_number(val("longitude", None), None)
    if lat is not None and lng is not None:
        out["latitude"], out["longitude"] = lat, lng
    refresh_order_status(out)
    return out

@app.post("/api/import/commit")
def import_commit(req: CommitImportRequest):
    # Safety net: if the frontend mapping is empty/incomplete, auto-map server-side.
    mapping = dict(req.mapping or {})
    if req.rows:
        headers = list(req.rows[0].keys())
        # Exact known headers always override fuzzy/frontend mapping. This is deliberate:
        # a bad dropdown selection from the browser must not create IMPORT-1 incomplete orders.
        for col in headers:
            direct = direct_header_field(col)
            if direct:
                mapping[col] = direct
        detections = detect_mapping(headers, req.rows[:50])
        for d in detections:
            best = d.get("best") or {}
            if best.get("score", 0) >= 75 and not mapping.get(d["column"]):
                mapping[d["column"]] = best.get("field_id")

    normalized = [normalize_order(row, mapping, i) for i, row in enumerate(req.rows)]
    existing = load_json("orders.json", [])
    existing.extend(normalized)
    save_json("orders.json", existing)
    if req.template_name:
        save_template({"name": req.template_name, "mapping": mapping})
    return {"ok": True, "orders_created": len(normalized), "ready": len([o for o in normalized if o.get("status") == "ready"]), "incomplete": len([o for o in normalized if o.get("status") != "ready"]), "mapping_used": mapping, "orders": normalized[:10]}

@app.delete("/api/planning/queue")
def clear_planning_queue():
    save_json("orders.json", [])
    save_json("routes.json", [])
    return {"ok": True, "message": "Planning Queue en routes geleegd."}

# ----------------------------
# C++ Optimizer Core bridge
# ----------------------------
def distance_km(a, b):
    lon1, lat1 = math.radians(a[0]), math.radians(a[1]); lon2, lat2 = math.radians(b[0]), math.radians(b[1])
    dlon, dlat = lon2-lon1, lat2-lat1
    h = math.sin(dlat/2)**2 + math.cos(lat1)*math.cos(lat2)*math.sin(dlon/2)**2
    return 6371 * 2 * math.asin(math.sqrt(h))

def core_safe(v: Any) -> str:
    return str(v or "").replace("\t", " ").replace("\n", " ").replace("\r", " ").strip()

def build_core_input(orders: List[dict], vehicles: List[dict], depot: List[float]) -> str:
    lines = [f"DEPOT\t{float(depot[0])}\t{float(depot[1])}"]
    available = [v for v in vehicles if str(v.get("status", "available")).lower() in ["available", "beschikbaar", "active", "actief"]]
    if not available:
        available = vehicles
    for v in available:
        lines.append("\t".join([
            "VEH",
            core_safe(v.get("id", "")),
            core_safe(v.get("name") or v.get("license_plate") or v.get("id") or "Voertuig"),
            str(parse_number(v.get("max_weight_kg", 999999), 999999)),
            str(parse_number(v.get("max_volume_m3", v.get("volume_capacity_m3", 999999)), 999999)),
            str(int(parse_number(v.get("europallet_capacity", v.get("pallet_capacity", 999999)), 999999))),
            str(int(parse_number(v.get("roll_container_capacity", 999999), 999999))),
            core_safe(v.get("status", "available")),
            "v1"
        ]))
    for o in orders:
        lines.append("\t".join([
            "ORD",
            core_safe(o.get("id", "")),
            core_safe(o.get("order_number", "")),
            core_safe(o.get("customer_name", "")),
            str(float(o.get("longitude"))),
            str(float(o.get("latitude"))),
            core_safe(o.get("delivery_date", "")),
            core_safe(o.get("time_window_start", "")),
            core_safe(o.get("time_window_end", "")),
            str(parse_number(o.get("service_time_minutes", 15), 15)),
            str(parse_number(o.get("weight_kg", 0), 0)),
            str(parse_number(o.get("volume_m3", 0), 0)),
            str(int(parse_number(o.get("europallets", 0), 0))),
            str(int(parse_number(o.get("roll_containers", 0), 0))),
            str(int(parse_number(o.get("priority", 0), 0))),
            "o1"
        ]))
    return "\n".join(lines) + "\n"

def run_cpp_optimizer(orders: List[dict], vehicles: List[dict], depot: List[float]) -> Dict[str, Any]:
    if not Path(OPTIMIZER_CORE_BIN).exists():
        raise RuntimeError(f"C++ optimizer-core binary ontbreekt: {OPTIMIZER_CORE_BIN}")
    proc = subprocess.run(
        [OPTIMIZER_CORE_BIN],
        input=build_core_input(orders, vehicles, depot),
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=25,
        check=False,
    )
    if proc.returncode != 0:
        raise RuntimeError(f"C++ optimizer-core foutcode {proc.returncode}: {proc.stderr[-800:]}")
    try:
        return json.loads(proc.stdout)
    except Exception as exc:
        raise RuntimeError(f"C++ optimizer-core gaf ongeldige JSON terug: {exc}; stdout={proc.stdout[:1200]}")

@app.get("/api/optimizer/status")
def optimizer_status():
    return {"version": APP_VERSION, "core_mode": "c++", "binary": OPTIMIZER_CORE_BIN, "available": Path(OPTIMIZER_CORE_BIN).exists(), "scope": "route_optimization + pallet/rolcontainer load optimization; geen 3D loading"}

@app.post("/api/planning/optimize")
async def optimize(payload: dict):
    orders = load_json("orders.json", [])
    vehicles = load_json("vehicles.json", [])
    selected_date = payload.get("delivery_date")
    candidates = [o for o in orders if o.get("status") == "ready" and (not selected_date or o.get("delivery_date") == selected_date)]
    if not candidates:
        return {"ok": False, "reason": "Geen ready orders in de Planning Queue. Importeer en map eerst orders."}
    if not vehicles:
        return {"ok": False, "reason": "Geen voertuigen beschikbaar. Voeg voertuigen toe in Wagenpark."}
    geocoded = [o for o in candidates if o.get("longitude") not in [None, ""] and o.get("latitude") not in [None, ""]]
    not_geocoded = [o for o in candidates if o not in geocoded]
    if not geocoded:
        return {"ok": False, "reason": "Orders zijn nog niet gegeocodeerd. Voeg latitude/longitude toe of gebruik PDOK/BAG geocoding."}
    depot = payload.get("depot") or [4.9041, 52.3676]

    core = run_cpp_optimizer(geocoded, vehicles, depot)
    order_by_id = {str(o.get("id")): o for o in geocoded}
    vehicle_by_id = {str(v.get("id")): v for v in vehicles}
    routes_out = []
    for i, r in enumerate(core.get("routes", [])):
        stops = []
        for j, s in enumerate(r.get("stops", [])):
            base = dict(order_by_id.get(str(s.get("order_id")), {}))
            base["sequence"] = j + 1
            base["eta"] = s.get("eta")
            base["leg_distance_m"] = s.get("leg_distance_m")
            base["optimizer_warning"] = s.get("warning")
            stops.append(base)
        coords = [depot] + [[float(o["longitude"]), float(o["latitude"])] for o in stops if o.get("longitude") not in [None, ""] and o.get("latitude") not in [None, ""]] + [depot]
        geometry = coords
        distance_m = int(r.get("distance_m", 0)); duration_s = int(r.get("duration_s", 0)); osrm_used = False
        try:
            # C++ decides assignment and stop order; OSRM only replaces geometry/distance with road-real values.
            rr = await routing_route(RouteRequest(coordinates=coords))
            geometry = rr["geometry"]["coordinates"]; distance_m = int(rr["distance_m"]); duration_s = int(rr["duration_s"]); osrm_used = True
        except Exception:
            pass
        v = vehicle_by_id.get(str(r.get("vehicle_id")), {})
        routes_out.append({
            "id": f"route_{i+1}",
            "name": f"Route {i+1}",
            "vehicle_id": r.get("vehicle_id"),
            "vehicle_name": r.get("vehicle_name") or v.get("name") or v.get("license_plate") or f"Voertuig {i+1}",
            "stops": stops,
            "geometry": geometry,
            "distance_m": distance_m,
            "duration_s": duration_s,
            "load": r.get("load", {}),
            "warnings": r.get("warnings", 0),
            "osrm_used": osrm_used,
            "optimizer_core": core.get("core_version"),
            "color": "#147CFF"
        })
    unplanned = list(core.get("unplanned", []))
    for o in not_geocoded:
        unplanned.append({"order_id": o.get("id"), "order_number": o.get("order_number"), "reason": "geen_gps_geocode"})
    save_json("routes.json", routes_out)
    return {"ok": True, "core_mode": "c++", "core_version": core.get("core_version"), "routes_created": len(routes_out), "unplanned_orders": len(unplanned), "routes": routes_out, "unplanned": unplanned, "summary": core.get("summary", {}), "note": "C++ Optimizer Core v1 plant routes en bewaakt load-capaciteit voor kg, m³, pallets en rolcontainers. 3D loading is bewust nog buiten scope."}

@app.get("/api/integrations/catalog")
def integrations_catalog():
    return {"connectors": [
        {"id":"csv_excel", "name":"CSV / Excel", "status":"active"},
        {"id":"custom_api", "name":"Custom API / Webhooks", "status":"foundation"},
        {"id":"sftp", "name":"SFTP import", "status":"planned"},
        {"id":"odoo", "name":"Odoo", "status":"planned"},
        {"id":"exact", "name":"Exact Online", "status":"planned"},
        {"id":"afas", "name":"AFAS", "status":"planned"},
        {"id":"woocommerce", "name":"WooCommerce", "status":"planned"},
        {"id":"shopify", "name":"Shopify", "status":"planned"}
    ]}
