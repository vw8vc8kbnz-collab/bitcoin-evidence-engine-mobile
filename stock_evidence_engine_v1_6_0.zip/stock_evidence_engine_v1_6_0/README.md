# Stock Evidence Engine v1.6.0

DeepSeek Analyst Brain release.

## Key features
- DeepSeek API integration for news + market-context analysis
- Local fallback if no API key is configured
- Token and estimated cost monitoring
- Dashboard cost metrics
- Audit ZIP export at `/exports/all.zip`
- Prompt stored in `deepseek_prompt.md`

## Configure DeepSeek
Create `.env` in `/home/ubuntu/stock_evidence_latest`:

```env
DEEPSEEK_API_KEY=...
DEEPSEEK_MODEL=deepseek-chat
DEEPSEEK_MAX_TICKERS=12
DEEPSEEK_INPUT_USD_PER_M=0.14
DEEPSEEK_OUTPUT_USD_PER_M=0.28
```

## Important
DeepSeek does not fetch market data. Yahoo/yfinance and local engines do that. DeepSeek only analyzes catalyst context.
