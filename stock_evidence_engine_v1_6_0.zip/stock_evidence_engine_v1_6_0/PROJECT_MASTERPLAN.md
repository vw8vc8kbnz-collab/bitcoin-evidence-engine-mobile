# SEE v1.6.0 Masterplan

DeepSeek is used as a narrow analyst layer after deterministic SEE filters. Market data stays local/Yahoo. DeepSeek receives ticker context and recent headlines and returns structured JSON only. The deterministic SEE engine remains responsible for final ranking and alerts.
