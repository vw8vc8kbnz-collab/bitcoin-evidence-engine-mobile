#!/usr/bin/env bash
set -euo pipefail
APP=/home/ubuntu/stock_evidence_latest
cd "$APP"
sudo chown -R ubuntu:ubuntu "$APP" || true
python3 -m venv venv
./venv/bin/python -m pip install --upgrade pip
./venv/bin/python -m pip install -r requirements.txt
chmod +x run_backtest.sh selftest.sh engine.py server.py
sudo tee /etc/systemd/system/stock-evidence-dashboard.service >/dev/null <<EOF
[Unit]
Description=Stock Evidence Engine Dashboard
After=network.target
[Service]
Type=simple
User=ubuntu
WorkingDirectory=$APP
ExecStart=/usr/bin/python3 $APP/server.py
Restart=always
RestartSec=5
[Install]
WantedBy=multi-user.target
EOF
sudo systemctl daemon-reload
sudo systemctl enable stock-evidence-dashboard.service
sudo systemctl restart stock-evidence-dashboard.service
