#!/usr/bin/env python3
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
import json, html, os
VERSION='v1.6.0'; ROOT=Path(__file__).resolve().parent; EXPORTS=ROOT/'exports'; PORT=8798
class H(BaseHTTPRequestHandler):
    def do_HEAD(self): self._send(200,b'', 'text/html')
    def do_GET(self):
        if self.path=='/health': return self._json({'ok':True,'version':VERSION})
        if self.path=='/exports/all.zip':
            p=EXPORTS/'all.zip'
            if not p.exists(): return self._send(404,b'no export yet','text/plain')
            data=p.read_bytes(); return self._send(200,data,'application/zip',{'Content-Disposition':'attachment; filename="see_audit_export_v1_6_0.zip"'})
        return self._send(200,self.page().encode(),'text/html')
    def _json(self,obj): self._send(200,json.dumps(obj).encode(),'application/json')
    def _send(self,code,data,ctype,headers=None):
        self.send_response(code); self.send_header('Content-Type',ctype); self.send_header('Content-Length',str(len(data)))
        for k,v in (headers or {}).items(): self.send_header(k,v)
        self.end_headers();
        if data: self.wfile.write(data)
    def page(self):
        cost={}
        p=EXPORTS/'ai_cost_summary.json'
        if p.exists():
            try: cost=json.loads(p.read_text())
            except Exception: cost={}
        rows=[]
        csv=EXPORTS/f'see_deepseek_news_analysis_{VERSION}.csv'
        if csv.exists():
            import csv as C
            with csv.open(encoding='utf-8') as f:
                rows=list(C.DictReader(f))[:40]
        cards=''.join(f"<tr><td>{html.escape(r.get('ticker',''))}</td><td>{html.escape(r.get('_provider',''))}</td><td>{html.escape(str(r.get('event_type','')))}</td><td>{html.escape(str(r.get('materiality_score','')))}</td><td>{html.escape(str(r.get('continuation_probability_3d','')))}</td><td>{html.escape((r.get('reason','') or '')[:110])}</td></tr>" for r in rows)
        return f'''<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>SEE {VERSION}</title><style>body{{font-family:-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;background:#f6f7fb;margin:0;color:#111827}}.wrap{{padding:18px;max-width:1180px;margin:auto}}.card{{background:#fff;border-radius:22px;padding:18px;margin:12px 0;box-shadow:0 10px 25px #0001}}.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px}}.metric{{background:#f8fafc;border-radius:16px;padding:14px}}.big{{font-size:28px;font-weight:800}}table{{width:100%;border-collapse:collapse;font-size:13px}}td,th{{padding:10px;border-bottom:1px solid #e5e7eb;text-align:left}}.badge{{display:inline-block;background:#111827;color:white;border-radius:999px;padding:7px 12px;font-weight:700}}a.btn{{display:inline-block;background:#2563eb;color:white;text-decoration:none;padding:11px 14px;border-radius:14px;font-weight:700}}</style></head><body><div class="wrap"><div class="card"><span class="badge">Stock Evidence Engine {VERSION}</span><h1>DeepSeek Analyst Brain</h1><p>Nieuws + marktcontext analyse met kostenmonitoring. Marktdata blijft lokaal/Yahoo; DeepSeek is alleen de analyst layer.</p><a class="btn" href="/exports/all.zip">Download audit ZIP</a></div><div class="grid"><div class="metric"><div class="big">{cost.get('tickers','-')}</div><small>Tickers analysed</small></div><div class="metric"><div class="big">{cost.get('total_input_tokens','-')}</div><small>Input tokens</small></div><div class="metric"><div class="big">{cost.get('total_output_tokens','-')}</div><small>Output tokens</small></div><div class="metric"><div class="big">${cost.get('estimated_cost_usd','-')}</div><small>Estimated run cost</small></div></div><div class="card"><h2>AI Analyst rows</h2><table><tr><th>Ticker</th><th>Provider</th><th>Event</th><th>Materiality</th><th>3d prob</th><th>Reason</th></tr>{cards}</table></div></div></body></html>'''
HTTPServer(('0.0.0.0',PORT),H).serve_forever()
