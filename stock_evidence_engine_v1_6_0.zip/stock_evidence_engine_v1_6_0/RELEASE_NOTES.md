# v1.6.0

- Added DeepSeek Analyst Brain.
- Added strict JSON prompt.
- Added token/cost monitoring.
- Added local fallback classifier.
- Added dashboard AI cost metrics.
