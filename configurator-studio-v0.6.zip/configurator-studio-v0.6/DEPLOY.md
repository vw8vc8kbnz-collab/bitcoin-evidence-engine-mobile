# DEPLOY v0.6

## Snelle deploy via nginx op poort 9999
Gebruik op de VPS:

```bash
cd ~/apps/bitcoin-evidence-engine-mobile && git pull && rm -rf configurator-studio-v0.6 && unzip -o configurator-studio-v0.6.zip && cd configurator-studio-v0.6 && bash deploy/deploy-9999.sh && curl -I http://127.0.0.1:9999/ && echo "KLAAR — http://51.195.102.180:9999/"
```
