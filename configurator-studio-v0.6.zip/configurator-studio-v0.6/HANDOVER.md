# HANDOVER — Configurator Studio v0.6

## Doel van v0.6
v0.6 is volledig gericht op de UX-richting die de gebruiker heeft gekozen:
- niet drie losse formulieren;
- wel één **slimme AI Product Studio**;
- vergelijkbaar in gevoel met ChatGPT/Claude;
- met attachments via een plus-knop;
- en een AI-intake die meerdere gerichte vragen stelt voordat een 3D-provider start.

## Belangrijkste keuzes
- Alles in één `index.html` ingebouwd om eerdere deploy-problemen met ontbrekende assets te voorkomen.
- Geen externe fonts of losse JS/CSS-bestanden nodig.
- De intakevragen zijn bewust meerkeuze + vrije tekst zodat de flow slim maar snel blijft.
- De refined prompt en providerkeuze zijn zichtbaar gemaakt als product-/UX-demonstratie.

## Volgende echte bouwstap
1. Backend toevoegen (Next.js/Supabase of minimal API backend).
2. ChatGPT API koppelen voor intake + refined prompt JSON.
3. Tripo / Rodin adapterlaag toevoegen.
4. Async job status / polling implementeren.
5. Echte review-editor met parts/material zones bouwen.
