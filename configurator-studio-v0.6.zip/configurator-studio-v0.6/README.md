# Configurator Studio v0.6

v0.6 draait de UX om naar één **AI Product Studio** met een ChatGPT/Claude-achtige composer.

## Wat nieuw is
- Één centrale composer voor **prompt + foto’s + 3D-model**.
- Compacte, premium SaaS-stijl met nette sans-serif typography.
- ChatGPT-achtige intakeflow: **meerdere gerichte tegenvragen** voordat de 3D-job start.
- Providerlogica in de UX: ChatGPT verfijnt de prompt; **Tripo 3D / Rodin AI** worden pas daarna gekozen.
- Geen zichtbare demo-tafel-hoofdflow meer; de hoofdervaring is echt AI-first.
- Alles is **self-contained in één HTML-bestand** voor maximale deploy-betrouwbaarheid.

## Hoofdflow
1. Gebruiker beschrijft product en voegt optioneel foto’s/GLB toe.
2. AI stelt meerdere verduidelijkende vragen.
3. AI maakt een refined generation prompt.
4. Providerselectie wordt getoond.
5. Mock generatiejob loopt.
6. Reviewscherm toont configuratie-intentie en vervolgstappen.

## Let op
Dit is nog steeds een prototype/mockflow. Echte integratie met ChatGPT, Tripo of Rodin vereist server-side jobs, API keys, polling/webhooks en asset-opslag.
