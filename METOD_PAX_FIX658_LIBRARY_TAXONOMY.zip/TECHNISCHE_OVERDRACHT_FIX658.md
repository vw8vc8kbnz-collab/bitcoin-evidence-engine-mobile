# Technische overdracht — METOD/PAX Tool A FIX658_LIBRARY_TAXONOMY

## Status

FIX658 is de kandidaat-release die uitsluitend de Material Library metadata/taxonomylaag uitbreidt bovenop FIX657R4. FIX657R4 blijft de rollback/golden bron totdat FIX658 daadwerkelijk live is bevestigd.

## Niet veranderen zonder aparte release

- Publieke Tool A: `http://51.195.102.180:8790/`
- Admin: `http://51.195.102.180:8790/admin/`
- Nginx publiek op `:8790`, Python loopback `127.0.0.1:8792`.
- `APP_ENV=production`, `PRODUCTION_HARDENING=1`, `ADMIN_HASH_ONLY=1`.
- CSV gross sheet price incl. VAT + other costs ex-VAT contract.
- `/api/jobs` is enige optimizerroute; final submit hergebruikt finalized parent-job.
- Bearer-only job token en sessionStorage.
- SSE public allowlist alleen `dxf_changed`/`dxfVersion`.

## Nieuwe module: `app/catalog_taxonomy.py`

### Kernvelden

- `primaryVisualFamily`
- `substrateType`
- `substrateLabel`
- `manufacturerCode` (private)
- `collection`
- `taxonomyStatus`
- `taxonomySource` (private)
- `taxonomyConfidence` (private)
- `taxonomyRulesetVersion`
- `classificationFingerprint`

Public families:
`Hout`, `Uni`, `Steen & beton`, `Metaal`, `Textiel & leer`, `Grafisch`, `Fantasie`.

`Onbekend` mag alleen in staging/review bestaan en mag niet stilzwijgend als actief public product worden gepubliceerd.

### Registry

Private bestand:
`app/system/catalog_taxonomy_registry.json`

De key is het interne artikelnummer. Dit is backend-only. De registry is supplementary state en kan geen product activeren.

Reuse-contract:
- `VERIFIED` (Admin override) + zelfde fingerprint => hergebruiken, ook na rulesetupgrade.
- `AUTO_VERIFIED` + zelfde fingerprint + zelfde rulesetversie => hergebruiken.
- `AUTO_VERIFIED` met oude ruleset => opnieuw classificeren.
- prijs- of plaatmaatwijziging => fingerprint blijft gelijk.
- productidentiteitswijziging => fingerprint wijzigt.

## CSV-importflow

`_api_admin_catalog_preview()`:
1. parseert CSV;
2. verrijkt records via private registry + classifier;
3. maakt diff tegen actieve CATALOG_IMPORT records;
4. reserveert bestaande/nieuwe opaque public IDs;
5. staged images blijven bestaande gecontroleerde flow;
6. retourneert taxonomy summary + alleen REVIEW_REQUIRED items;
7. publicatie is geblokkeerd zolang reviewRequired > 0.

Nieuwe endpoint:
`POST /api/admin/materials/catalog_taxonomy_override`

Vereist bestaande Admin-auth/origin-security. Payload bevat staged `importId`, intern artikelnummer, `primaryVisualFamily` en `substrateType`. Dit endpoint mutereert alleen de private staging-import, niet de actieve catalogus.

`_api_admin_catalog_publish()` rekent de taxonomy summary opnieuw uit en weigert publicatie wanneer nog een reviewitem bestaat. `_merge_catalog_stage()` maakt vervolgens exact de staged geldige CSV-records actief, bewaart stable opaque IDs en schrijft geverifieerde taxonomy in de private registry.

## Current-live backfill

`tools/fix658_backfill_taxonomy.py` verrijkt tijdens deploy de bestaande live FIX657R4 CSV-catalogus, zodat de gebruiker de huidige CSV niet opnieuw hoeft te uploaden.

Het script beschermt expliciet de commerciële/autoritatieve velden. Onder andere publicMaterialId, interne article key, productName, plaatmaten, dikte, prijs, image source, active/published/sourceKind mogen niet veranderen. Bij iedere afwijking faalt deploy vóór service restart.

## Publieke contractwijziging

`_material_record_to_toola_catalog()` voegt nuttige niet-gevoelige metadata toe:
- primaryVisualFamily / visualFamily;
- substrateType / substrateLabel;
- collection;
- thicknessMm;
- sheetSizeMm.

Niet publiek:
- articleNo/articleNumber/materialCode;
- manufacturerCode;
- taxonomySource;
- taxonomyConfidence;
- prijzen.

## Tool A UI

`app/decor_library.js`:
- `familyOf()` gebruikt primaryVisualFamily als waarheid.
- `typeBucket()` is exact one-to-one mapping naar één hoofdfilter.
- `filteredCatalog()` gebruikt voor hoofdknoppen alleen `x.bucket===UI.filter`.
- `visualTags`/searchTags mogen alleen zoeken ondersteunen.
- cards en selected views tonen substrate + thickness + `sheetLen × sheetWid`.

## Schema

Actieve/public library schema vanaf FIX658: `decorLibrarySchemaVersion = 4`.

## Huidige dataset

Aangeleverde CSV SHA-256:
`053026e2883908bed7bfd05c8c39543d91ef611ff24e40b2546003e6e3127950`

- 606 read
- 597 eligible
- 9 excluded thickness
- 0 blocking errors
- 597 taxonomy verified/resolved
- 0 review required

Zie `FIX658_TAXONOMY_AUDIT_CURRENT_LIBRARY.md` voor volledige audit.

## Future products

De runtime doet bewust geen website-scraping. Bekende veilige fabrikantfamilies/codes worden deterministisch geclassificeerd. Nieuwe ambiguïteit wordt zichtbaar als REVIEW_REQUIRED en blokkeert publicatie. Daarmee is “exact of review” het contract; nooit “waarschijnlijk en toch publiceren”.

## Regression gates

`tools/fix658_regression.py` bewaakt:
- echte huidige CSV;
- duplicate names/sizes;
- taxonomy counts/resolution;
- future CSV unchanged/reuse;
- added/changed/removed diff;
- safe new item automatic classification;
- unknown item REVIEW_REQUIRED;
- admin override;
- strict one-primary UI filtering;
- public privacy;
- live backfill protected fields;
- mixed-VAT v2;
- Bearer/SSE/security;
- no queue optimizer;
- idempotent final submit;
- R4 tempfile smokecheck rule.

## Deployment lessons blijven hard

1. Root-only Admin credentials `0600` nooit versoepelen; privileged preflight via sudo/root.
2. Nooit `curl ... | grep -q ...` als finale smoke onder `set -o pipefail`; eerst volledige response naar tempfile, daarna grep.
3. Preflight/tests vóór live switch.
4. Volledige state-preserving backup vóór live wijziging.
5. Automatische rollback bij echte post-switch failure.
