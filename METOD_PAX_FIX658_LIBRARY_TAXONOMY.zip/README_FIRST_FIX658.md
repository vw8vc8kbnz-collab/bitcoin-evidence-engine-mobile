# METOD/PAX FIX658 — README FIRST

FIX658 is een **Library Taxonomy & Material Metadata** release bovenop de live/golden FIX657R4 baseline.

## Wat deze release oplost

1. Plaatmaat is zichtbaar op material cards en bij het geselecteerde materiaal.
2. Drager is zichtbaar als MDF, Spaanplaat of Multiplex.
3. Hoofdfilters gebruiken exact één geverifieerde `primaryVisualFamily`; secondary tags kunnen geen steen meer in Hout laten lekken.
4. De huidige 597 geldige CSV-records zijn deterministisch geclassificeerd.
5. Iedere volgende CSV-import hergebruikt bekende metadata, classificeert veilige nieuwe producten automatisch en blokkeert twijfelgevallen met een Admin-review in plaats van te gokken.
6. De private taxonomy-registry kan nooit cataloguslidmaatschap, plaatmaat, dikte, afbeelding of prijs overschrijven.

## Belangrijk

- Golden basis: `FIX657R4_HTTP8790_STABLE_VAT_TRUTH`.
- Tool A blijft `http://51.195.102.180:8790/`.
- Admin blijft `http://51.195.102.180:8790/admin/`.
- De CSV-prijs blijft exact **incl. BTW**; mixed-VAT v2 is niet veranderd.
- Optimizer/jobflow/submitflow zijn niet functioneel gewijzigd.
- Geen live website-scraping in de klantflow.

## Deploy

Gebruik uitsluitend `INSTALL_FIX658_FROM_STAGE.sh` via de gecontroleerde Termius one-shot. De installer valideert release-integriteit en regressies vóór de live switch, maakt backups, bewaart runtime-state en rolt automatisch terug bij een echte post-switch failure.

Zie `FIX658_TAXONOMY_AUDIT_CURRENT_LIBRARY.md` en `TECHNISCHE_OVERDRACHT_FIX658.md` voor het volledige contract.
