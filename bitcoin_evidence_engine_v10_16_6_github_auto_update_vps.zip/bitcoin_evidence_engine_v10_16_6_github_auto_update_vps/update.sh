#!/usr/bin/env bash
set -euo pipefail

# Bitcoin Evidence Engine - vaste VPS updater
# Gebruik voortaan op de VPS:
#   cd ~/bitcoin-engine-deploy
#   bash update.sh
#
# Wat hij doet:
# - haalt GitHub main opnieuw op
# - zoekt automatisch de nieuwste bitcoin_evidence_engine*.zip
# - pakt die uit naar releases/
# - zet current -> nieuwste release
# - maakt/gebruikt .venv
# - installeert packages met binary wheels
# - stopt oude uvicorn
# - start nieuwe versie op poort 8787
# - doet health-check

REPO_URL="${REPO_URL:-https://github.com/vw8vc8kbnz-collab/bitcoin-evidence-engine-mobile.git}"
BASE_DIR="${BASE_DIR:-$HOME/bitcoin-engine-deploy}"
REPO_DIR="$BASE_DIR/github_latest"
RELEASES_DIR="$BASE_DIR/releases"
CURRENT_LINK="$BASE_DIR/current"
LOGS_DIR="$BASE_DIR/logs"
PORT="${PORT:-8787}"
APP_URL="http://51.195.102.180:${PORT}"

mkdir -p "$BASE_DIR" "$RELEASES_DIR" "$LOGS_DIR" "$HOME/bitcoin_evidence_data"
cd "$BASE_DIR"

echo "=============================================="
echo "Bitcoin Evidence Engine auto-update"
echo "Repo: $REPO_URL"
echo "Base: $BASE_DIR"
echo "=============================================="

if ! command -v git >/dev/null 2>&1 || ! command -v unzip >/dev/null 2>&1; then
  echo "Benodigde systeemtools installeren..."
  sudo apt-get update
  sudo apt-get install -y git unzip curl python3 python3-venv python3-pip build-essential golang-go procps
fi

if [ ! -d "$REPO_DIR/.git" ]; then
  rm -rf "$REPO_DIR"
  echo "GitHub repo clonen..."
  git clone "$REPO_URL" "$REPO_DIR"
else
  echo "GitHub repo bijwerken..."
  git -C "$REPO_DIR" fetch --all --prune
  git -C "$REPO_DIR" reset --hard origin/main
fi

# Zoek nieuwste ZIP in repo. Dit ondersteunt jouw workflow: gewoon nieuwe ZIP uploaden naar GitHub.
ZIP_FILE="$(find "$REPO_DIR" -maxdepth 2 -type f \( -iname 'bitcoin_evidence_engine*.zip' -o -iname 'engine*.zip' \) -printf '%T@ %p\n' | sort -nr | head -1 | cut -d' ' -f2-)"

STAMP="$(date +%Y%m%d_%H%M%S)"
if [ -n "${ZIP_FILE:-}" ] && [ -f "$ZIP_FILE" ]; then
  NAME="$(basename "$ZIP_FILE" .zip)"
  DEST="$RELEASES_DIR/${STAMP}_${NAME}"
  TMP="$BASE_DIR/.tmp_unpack_$STAMP"
  rm -rf "$TMP" "$DEST"
  mkdir -p "$TMP"
  echo "Nieuwste ZIP gevonden: $(basename "$ZIP_FILE")"
  unzip -q "$ZIP_FILE" -d "$TMP"
  # Pak folder met app/main.py of START_HIER.sh
  APP_DIR="$(find "$TMP" -type f \( -path '*/app/main.py' -o -name 'START_HIER.sh' \) -printf '%h\n' | sort | head -1)"
  if [ -z "${APP_DIR:-}" ]; then
    echo "❌ Geen app/main.py of START_HIER.sh gevonden in ZIP."
    find "$TMP" -maxdepth 3 -type f | head -80
    exit 1
  fi
  mv "$APP_DIR" "$DEST"
  rm -rf "$TMP"
else
  # Ondersteunt ook repo waar app direct uitgepakt in GitHub staat.
  if [ -f "$REPO_DIR/app/main.py" ]; then
    DEST="$RELEASES_DIR/${STAMP}_repo_direct"
    rm -rf "$DEST"
    mkdir -p "$DEST"
    rsync -a --exclude='.git' "$REPO_DIR/" "$DEST/"
  else
    echo "❌ Geen ZIP en geen directe app gevonden in GitHub repo."
    echo "Zet je nieuwe bitcoin_evidence_engine*.zip in GitHub root en draai opnieuw: bash update.sh"
    exit 1
  fi
fi

ln -sfn "$DEST" "$CURRENT_LINK"
cd "$CURRENT_LINK"

echo "Actieve release: $DEST"

if [ ! -f requirements.txt ]; then
  echo "❌ requirements.txt ontbreekt in release. Inhoud:"
  ls -la
  exit 1
fi

# Stop oude server.
echo "Oude server stoppen..."
pkill -f "uvicorn app.main:app" >/dev/null 2>&1 || true
sleep 1

# Venv maken en dependencies installeren zonder PEP668/globale Python gedoe.
if [ ! -d .venv ]; then
  echo "Virtualenv maken..."
  python3 -m venv .venv
fi
. .venv/bin/activate
python -m pip install --upgrade pip wheel setuptools

echo "Dependencies installeren met binary wheels..."
python -m pip install --only-binary=:all: -r requirements.txt

if [ -f build_native_core_linux.sh ]; then
  echo "Native core bouwen/controleren..."
  bash build_native_core_linux.sh || echo "Native build waarschuwing; ga door als bestaande binary aanwezig is."
fi

mkdir -p logs "$HOME/bitcoin_evidence_data"

echo "Nieuwe server starten..."
nohup .venv/bin/python -m uvicorn app.main:app --host 0.0.0.0 --port "$PORT" --proxy-headers > "$LOGS_DIR/server.log" 2>&1 &

# Health check
ok=0
for i in $(seq 1 20); do
  if curl -fsS "http://127.0.0.1:${PORT}/api/health" >/dev/null 2>&1; then
    ok=1
    break
  fi
  sleep 1
done

if [ "$ok" = "1" ]; then
  echo ""
  echo "✅ UPDATE KLAAR"
  echo "Open: $APP_URL"
  echo "Log: $LOGS_DIR/server.log"
  echo "Voortaan alleen dit draaien:"
  echo "  cd $BASE_DIR && bash update.sh"
else
  echo ""
  echo "❌ Server startte niet goed. Laatste logregels:"
  tail -100 "$LOGS_DIR/server.log" || true
  exit 1
fi
