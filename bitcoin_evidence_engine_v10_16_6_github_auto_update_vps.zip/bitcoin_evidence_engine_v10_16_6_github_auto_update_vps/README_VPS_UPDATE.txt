Vaste simpele VPS workflow vanaf v10.16.6

Eenmalig:
1. Zet deze ZIP in GitHub zoals normaal.
2. Op de VPS:
   cd ~/bitcoin-engine-deploy
   git clone https://github.com/vw8vc8kbnz-collab/bitcoin-evidence-engine-mobile.git github_latest 2>/dev/null || true
   cd github_latest
   unzip bitcoin_evidence_engine_v10_16_6_github_auto_update_vps.zip
   cd bitcoin_evidence_engine_v10_16_6_github_auto_update_vps
   bash INSTALL_UPDATE_SCRIPT_ON_VPS.sh
   cd ~/bitcoin-engine-deploy
   bash update.sh

Daarna bij elke nieuwe versie:
1. Nieuwe ZIP in GitHub zetten.
2. Op de VPS alleen:
   cd ~/bitcoin-engine-deploy
   bash update.sh

De updater doet automatisch: GitHub pull, ZIP uitpakken, oude server stoppen, venv/dependencies regelen, nieuwe server starten en health-check.
