#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

echo "=============================================="
echo "Bitcoin Evidence Engine v10.16.6"
echo "Eenvoudige VPS start/herstart"
echo "=============================================="

# Stop oude server op poort 8787 / uvicorn app.main:app
pkill -f "uvicorn app.main:app" >/dev/null 2>&1 || true
sleep 1

# Altijd eigen virtualenv gebruiken; geen globale Python packages nodig.
if [ ! -d .venv ]; then
  echo "Virtualenv maken..."
  python3 -m venv .venv
fi

. .venv/bin/activate
python -m pip install --upgrade pip wheel setuptools

echo "Python packages installeren vanuit requirements.txt..."
# Forceer wheels zodat pandas/duckdb niet eindeloos vanaf source gaan bouwen.
python -m pip install --only-binary=:all: -r requirements.txt

if [ -f build_native_core_linux.sh ]; then
  echo "Native core bouwen/controleren..."
  bash build_native_core_linux.sh || echo "Native build gaf waarschuwing; app start alsnog als binary al aanwezig is."
fi

mkdir -p "$HOME/bitcoin_evidence_data" logs

echo "Server starten op poort 8787..."
nohup .venv/bin/python -m uvicorn app.main:app --host 0.0.0.0 --port 8787 --proxy-headers > server.log 2>&1 &

sleep 3
if curl -fsS http://127.0.0.1:8787/api/health >/dev/null 2>&1; then
  echo ""
  echo "✅ ONLINE: http://51.195.102.180:8787"
  echo "Log: $(pwd)/server.log"
else
  echo ""
  echo "❌ Server startte niet goed. Laatste logregels:"
  tail -80 server.log || true
  exit 1
fi
