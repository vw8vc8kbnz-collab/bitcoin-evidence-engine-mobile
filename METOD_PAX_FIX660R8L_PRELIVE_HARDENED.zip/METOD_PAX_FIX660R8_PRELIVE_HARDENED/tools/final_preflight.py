#!/usr/bin/env python3
from __future__ import annotations

"""Outcome-based release and runtime preflight for METOD/PAX FIX660R8.

The source preflight executes the real safety, lifecycle and regression suites in
isolated processes. ``--runtime`` additionally validates the external state and
the deployed staging/production profile. It never creates a real customer job;
the lifecycle job always lives in an automatically removed temporary directory.
"""

import argparse
import ast
import base64
import hashlib
import json
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import urlparse


BUILD = "FIX660R8_PRELIVE_HARDENED"
EXPECTED_SEED_SOURCE = "CSV_CATALOG_ONLY"
MAX_PUBLIC_JSON = 16 * 1024 * 1024
MAX_SUBMIT_JSON = 8 * 1024 * 1024
MAX_DXF_BLOB = 2 * 1024 * 1024


class Preflight:
    def __init__(self) -> None:
        self.failures: list[str] = []
        self.warnings: list[str] = []

    def ok(self, message: str) -> None:
        print(f"OK:   {message}")

    def fail(self, message: str) -> None:
        self.failures.append(message)
        print(f"FAIL: {message}")

    def warn(self, message: str) -> None:
        self.warnings.append(message)
        print(f"WARN: {message}")

    def require(self, condition: bool, message: str) -> bool:
        if condition:
            self.ok(message)
            return True
        self.fail(message)
        return False


def strict_json(path: Path):
    def reject_constant(value: str):
        raise ValueError(f"non-finite JSON constant {value}")

    value = json.loads(path.read_text(encoding="utf-8", errors="strict"), parse_constant=reject_constant)

    def walk(item):
        if isinstance(item, float) and not math.isfinite(item):
            raise ValueError("non-finite JSON number")
        if isinstance(item, dict):
            for key, child in item.items():
                if not isinstance(key, str):
                    raise ValueError("JSON object key is not text")
                walk(child)
        elif isinstance(item, list):
            for child in item:
                walk(child)

    walk(value)
    return value


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_env(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.is_file():
        return values
    for line in path.read_text(encoding="utf-8", errors="strict").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            continue
        key, value = stripped.split("=", 1)
        values[key.strip()] = value.strip().strip('"').strip("'")
    return values


def truthy(value: str | None) -> bool:
    return str(value or "").strip().lower() in {"1", "true", "yes", "on"}


def exact_origin(value: str, *, scheme: str | None = None) -> bool:
    try:
        parsed = urlparse(str(value or "").strip())
        return bool(
            parsed.hostname
            and not parsed.username
            and not parsed.password
            and not parsed.query
            and not parsed.fragment
            and parsed.path in {"", "/"}
            and "*" not in str(value)
            and (scheme is None or parsed.scheme.lower() == scheme)
        )
    except Exception:
        return False


def run_check(checks: Preflight, label: str, command: list[str], *, cwd: Path, env: dict[str, str]) -> None:
    result = subprocess.run(
        command,
        cwd=str(cwd),
        env=env,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=180,
        check=False,
    )
    if result.returncode == 0:
        checks.ok(label)
        summary = [line for line in result.stdout.splitlines() if line.strip()][-3:]
        for line in summary:
            print(f"      {line[:500]}")
        return
    checks.fail(f"{label} (exit {result.returncode})")
    for line in result.stdout.splitlines()[-80:]:
        print(f"      {line[:1000]}")


def validate_checksum_manifest(checks: Preflight, release: Path, *, verify: bool) -> None:
    manifest = release / "SHA256SUMS.txt"
    if not checks.require(manifest.is_file(), "SHA256SUMS.txt aanwezig"):
        return
    listed: dict[str, str] = {}
    try:
        for number, line in enumerate(manifest.read_text(encoding="utf-8", errors="strict").splitlines(), 1):
            if not line.strip():
                continue
            match = re.fullmatch(r"([a-f0-9]{64})  \./([^\r\n]+)", line)
            if not match:
                raise ValueError(f"ongeldige regel {number}")
            relative = match.group(2)
            if relative.startswith("/") or ".." in Path(relative).parts or relative in listed:
                raise ValueError(f"onveilig/dubbel pad op regel {number}")
            listed[relative] = match.group(1)
    except Exception as exc:
        checks.fail(f"checksummanifest ongeldig: {exc}")
        return

    excluded_names = {"SHA256SUMS.txt"}
    actual = {
        path.relative_to(release).as_posix()
        for path in release.rglob("*")
        if path.is_file()
        and path.name not in excluded_names
        and "__pycache__" not in path.parts
        and path.suffix.lower() not in {".pyc", ".bak"}
    }
    checks.require(set(listed) == actual, "checksummanifest dekt exact alle releasebestanden")
    if not verify:
        checks.warn("checksumbytes niet opnieuw berekend (gebruik --verify-checksums voor artifactgate)")
        return
    mismatches = [relative for relative, expected in sorted(listed.items()) if sha256_file(release / relative) != expected]
    checks.require(not mismatches, "alle interne releasechecksums kloppen")
    if mismatches:
        for relative in mismatches[:20]:
            print(f"      mismatch: {relative}")


def validate_release_tree(checks: Preflight, release: Path, *, verify_checksums: bool) -> None:
    required = [
        "INSTALL_FIX660R8_FROM_STAGE.sh",
        "DEPLOY_FIX660.sh",
        "RUNTIME_CONTRACT.json",
        "SBOM.cdx.json",
        "requirements.txt",
        "README_FIRST_FIX660R8.md",
        "FIX660R8_RELEASE_NOTES.md",
        "FIX660R8_TEST_REPORT.md",
        "FIX660R8_REMEDIATION_MATRIX.md",
        "GO_LIVE_GATES_FIX660R8.md",
        "TECHNISCHE_OVERDRACHT_FIX660R8.md",
        ".github/workflows/release-gate.yml",
        "app/server_py.py",
        "app/dxf_nesting_optimizer.py",
        "app/dxf_geometry.py",
        "app/panel_contract.py",
        "app/safety_contracts.py",
        "app/toolA.html",
        "app/toolA_grain_studio_renderer.js",
        "tools/fix660r8_safety_tests.py",
        "tools/fix660r8_server_lifecycle_tests.py",
        "tools/fix660r8_http_smoke_tests.py",
        "tools/fix660r8_restore_tests.py",
        "tools/restore_system_backup.py",
        "tools/fix660_regression.py",
    ]
    for relative in required:
        checks.require((release / relative).is_file(), f"aanwezig: {relative}")

    dirty = [
        path.relative_to(release).as_posix()
        for path in release.rglob("*")
        if path.is_file() and ("__pycache__" in path.parts or path.suffix.lower() in {".pyc", ".bak"})
    ]
    checks.require(not dirty, "releaseboom bevat geen pycache/pyc/bak")

    try:
        seed = strict_json(release / "app/material_library.json")
        checks.require(
            isinstance(seed, dict)
            and seed.get("source") == EXPECTED_SEED_SOURCE
            and seed.get("records") == [],
            "immutable catalogus-seed is bewust leeg en CSV-only",
        )
    except Exception as exc:
        checks.fail(f"catalogus-seed ongeldig: {exc}")

    try:
        contract = strict_json(release / "RUNTIME_CONTRACT.json")
        python_contract = contract.get("python") if isinstance(contract, dict) else None
        if not isinstance(python_contract, dict) or contract.get("build") != BUILD:
            raise ValueError("build/Python contract ontbreekt")
        minimum = tuple(int(x) for x in str(python_contract.get("minimum") or "").split("."))
        maximum = tuple(int(x) for x in str(python_contract.get("maximumExclusive") or "").split("."))
        current = tuple(sys.version_info[:3])
        checks.require(minimum <= current < maximum, f"Python {current} valt binnen vastgelegd runtimebereik")
        checks.require(python_contract.get("mandatoryThirdPartyPackages") == [], "production runtime heeft geen verplichte third-party Pythonpackages")
        requirement_lines = [
            line.strip()
            for line in (release / "requirements.txt").read_text(encoding="utf-8").splitlines()
            if line.strip() and not line.lstrip().startswith("#")
        ]
        checks.require(requirement_lines == [], "requirements.txt bevestigt stdlib-only productiepad")
        sbom = strict_json(release / "SBOM.cdx.json")
        checks.require(
            isinstance(sbom, dict)
            and sbom.get("bomFormat") == "CycloneDX"
            and ((sbom.get("metadata") or {}).get("component") or {}).get("version") == BUILD,
            "CycloneDX SBOM hoort bij deze build",
        )
        internal_modules = {path.stem for path in (release / "app").glob("*.py")} | {
            path.stem for path in (release / "tools").glob("*.py")
        }
        third_party: set[str] = set()
        optional = {"PIL"}
        stdlib = set(getattr(sys, "stdlib_module_names", set()))
        for path in list((release / "app").glob("*.py")) + list((release / "tools").glob("*.py")):
            tree = ast.parse(path.read_text(encoding="utf-8", errors="strict"), filename=str(path))
            for node in ast.walk(tree):
                module = ""
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        module = alias.name.split(".", 1)[0]
                        if module not in stdlib | internal_modules | optional:
                            third_party.add(module)
                elif isinstance(node, ast.ImportFrom) and node.level == 0:
                    module = str(node.module or "").split(".", 1)[0]
                    if module and module not in stdlib | internal_modules | optional:
                        third_party.add(module)
        checks.require(not third_party, f"geen onvermelde third-party imports ({sorted(third_party)})")
    except Exception as exc:
        checks.fail(f"runtimecontract/SBOM ongeldig: {exc}")

    for path in sorted((release / "app").glob("*.py")) + sorted((release / "tools").glob("*.py")):
        try:
            compile(path.read_text(encoding="utf-8", errors="strict"), str(path), "exec")
        except Exception as exc:
            checks.fail(f"Python compile faalt voor {path.relative_to(release)}: {exc}")
            break
    else:
        checks.ok("alle Python-bronnen compileren in-memory")

    base_env = dict(os.environ)
    base_env["PYTHONDONTWRITEBYTECODE"] = "1"
    # Every source test must use an explicitly isolated state root.  Without
    # this, importing server_py from an unpacked release creates a root-owned
    # sibling ``metod-pax-state`` when the installer runs preflight via sudo.
    # Apart from violating test isolation, that prevents the invoking SSH user
    # from cleaning its private extraction directory after a failed install.
    with tempfile.TemporaryDirectory(prefix="fix660r8_preflight_state_") as test_temp:
        test_env = dict(base_env)
        test_env["METOD_STATE_ROOT"] = str(Path(test_temp) / "state")
        run_check(
            checks,
            "adversarial + golden optimizerproeven",
            [sys.executable, "tools/fix660r8_safety_tests.py"],
            cwd=release,
            env=test_env,
        )
        run_check(
            checks,
            "publieke DTO → echte optimizer → hashfinalisatie lifecycle",
            [sys.executable, "tools/fix660r8_server_lifecycle_tests.py"],
            cwd=release,
            env=test_env,
        )
        run_check(
            checks,
            "echt serverproces → liveness/readiness/Tool A via HTTP",
            [sys.executable, "tools/fix660r8_http_smoke_tests.py"],
            cwd=release,
            env=test_env,
        )
        run_check(
            checks,
            "backupmanifest → hashverificatie → atomische stagingrestore",
            [sys.executable, "tools/fix660r8_restore_tests.py"],
            cwd=release,
            env=test_env,
        )
        run_check(
            checks,
            "volledige functionele regressiesuite",
            [sys.executable, "tools/fix660_regression.py"],
            cwd=release,
            env=test_env,
        )

    for script in ("INSTALL_FIX660R8_FROM_STAGE.sh", "DEPLOY_FIX660.sh"):
        run_check(checks, f"Bash syntax: {script}", ["bash", "-n", script], cwd=release, env=base_env)

    node = shutil.which("node")
    if node:
        for path in sorted((release / "app").glob("*.js")):
            run_check(
                checks,
                f"JavaScript syntax: {path.name}",
                [node, "--check", str(path)],
                cwd=release,
                env=base_env,
            )
        try:
            source_tree = ast.parse((release / "app/server_py.py").read_text(encoding="utf-8", errors="strict"))
            admin_html = ""
            for statement in source_tree.body:
                if isinstance(statement, ast.Assign) and any(
                    isinstance(target, ast.Name) and target.id == "ADMIN_HTML"
                    for target in statement.targets
                ):
                    admin_html = ast.literal_eval(statement.value)
                    break
            html_sources = {
                "admin": admin_html,
                "toolA": (release / "app/toolA.html").read_text(encoding="utf-8", errors="strict"),
            }
            with tempfile.TemporaryDirectory(prefix="fix660r8_inline_js_") as temp_dir:
                for label, html in html_sources.items():
                    scripts = []
                    for attrs, source in re.findall(r"<script\b([^>]*)>(.*?)</script>", html, flags=re.I | re.S):
                        attrs_lower = attrs.lower()
                        if "src=" in attrs_lower or "application/json" in attrs_lower or not source.strip():
                            continue
                        scripts.append(source)
                    checks.require(bool(scripts), f"inline JavaScript gevonden in {label}")
                    for index, source in enumerate(scripts, 1):
                        path = Path(temp_dir) / f"{label}_{index}.js"
                        path.write_text(source, encoding="utf-8")
                        run_check(
                            checks,
                            f"inline JavaScript syntax: {label} #{index}",
                            [node, "--check", str(path)],
                            cwd=release,
                            env=base_env,
                        )
        except Exception as exc:
            checks.fail(f"inline JavaScript kon niet worden gevalideerd: {exc}")
    else:
        checks.warn("Node ontbreekt; JavaScript syntaxcheck moet door CI/artifactbuilder zijn uitgevoerd")

    validate_checksum_manifest(checks, release, verify=verify_checksums)


def active_catalog_records(library: object) -> list[dict]:
    records = library.get("records") if isinstance(library, dict) else None
    if not isinstance(records, list):
        raise ValueError("material_library.json mist records[]")
    active = []
    for record in records:
        if not isinstance(record, dict):
            continue
        if (
            str(record.get("sourceKind") or "").upper() == "CATALOG_IMPORT"
            and record.get("active") is not False
            and record.get("archived") is not True
            and record.get("published") is True
            and record.get("catalogMissing") is not True
            and record.get("catalogExcluded") is not True
        ):
            active.append(record)
    return active


def validate_admin_credentials(checks: Preflight, path: Path, *, production: bool) -> None:
    try:
        credentials = strict_json(path)
        mode = path.stat().st_mode & 0o777
        checks.require(mode in {0o400, 0o600}, "Admin credentials mode is 0400/0600")
        if not production:
            users = credentials.get("users") if isinstance(credentials, dict) else None
            legacy = isinstance(credentials, dict) and credentials.get("username") and credentials.get("password_hash")
            checks.require(bool(users) or bool(legacy), "staging Admin credentials zijn bruikbaar")
            return
        users = credentials.get("users") if isinstance(credentials, dict) else None
        if not isinstance(users, list) or not users:
            raise ValueError("production vereist users[]")
        seen: set[str] = set()
        active_count = 0
        for user in users:
            if not isinstance(user, dict) or user.get("active") is False:
                continue
            active_count += 1
            username = str(user.get("username") or "")
            if not re.fullmatch(r"[A-Za-z0-9_.@-]{3,80}", username) or username in seen:
                raise ValueError("ongeldige/dubbele individuele Admin username")
            seen.add(username)
            password_hash = str(user.get("password_hash") or "")
            if not re.fullmatch(r"pbkdf2_sha256\$260000\$[A-Za-z0-9._-]{16,128}\$[a-f0-9]{64}", password_hash):
                raise ValueError(f"{username}: PBKDF2-hash moet exact het 260000-iteratiecontract volgen")
            if str(user.get("password") or "").strip():
                raise ValueError(f"{username}: plaintext password verboden")
            secret = re.sub(r"\s+", "", str(user.get("totp_secret") or "")).upper()
            if not re.fullmatch(r"[A-Z2-7]{16,128}", secret):
                raise ValueError(f"{username}: ongeldig TOTP-secretcontract")
            if len(base64.b32decode(secret + "=" * ((8 - len(secret) % 8) % 8), casefold=True)) < 10:
                raise ValueError(f"{username}: TOTP-secret is te kort")
            if "admin" not in set(user.get("roles") or []):
                raise ValueError(f"{username}: adminrol ontbreekt")
        checks.require(active_count > 0, "production gebruikt individuele Admins met MFA en adminrol")
    except Exception as exc:
        checks.fail(f"Admin credentials ongeldig: {exc}")


def validate_runtime(checks: Preflight, release: Path, env_path: Path, state_override: str | None) -> None:
    env = read_env(env_path)
    checks.require(env_path.is_file(), f"runtime env aanwezig: {env_path}")
    mode = str(env.get("APP_ENV") or "").strip().lower()
    production = mode in {"prod", "production"}
    staging = mode == "staging"
    checks.require(production or staging, "APP_ENV is staging of production")

    state_root = Path(state_override or env.get("METOD_STATE_ROOT") or "").expanduser()
    try:
        state_resolved = state_root.resolve(strict=True)
        release_resolved = release.resolve(strict=True)
        outside = state_resolved != release_resolved and release_resolved not in state_resolved.parents
        checks.require(outside, "mutable state staat buiten immutable release")
    except Exception as exc:
        checks.fail(f"state root ongeldig: {exc}")
        return

    origin = str(env.get("METOD_PUBLIC_BASE_URL") or "").strip()
    if production:
        checks.require(exact_origin(origin, scheme="https"), "production public base URL is exact HTTPS")
        checks.require(truthy(env.get("PRODUCTION_HARDENING")), "PRODUCTION_HARDENING=1")
        checks.require(truthy(env.get("ADMIN_HASH_ONLY")), "ADMIN_HASH_ONLY=1")
        checks.require(not truthy(env.get("ADMIN_STAGING_OPEN")), "ADMIN_STAGING_OPEN=0")
        checks.require(not truthy(env.get("LEGACY_HTTP_COMPAT")) and not env.get("LEGACY_HTTP_ORIGIN"), "legacy HTTP is uit")
    else:
        checks.require(exact_origin(origin, scheme="http"), "staging public base URL is exact HTTP en expliciet niet live")

    for name in ("ALLOWED_ORIGINS", "ALLOWED_ADMIN_ORIGINS"):
        origins = [item.strip() for item in str(env.get(name) or "").split(",") if item.strip()]
        scheme = "https" if production else "http"
        checks.require(bool(origins) and all(exact_origin(item, scheme=scheme) for item in origins), f"{name} bevat alleen exacte {scheme.upper()} origins")

    limits = {
        "PUBLIC_JSON_MAX_BYTES": MAX_PUBLIC_JSON,
        "SUBMIT_MAX_BYTES": MAX_SUBMIT_JSON,
        "PUBLIC_DXF_BLOB_MAX_BYTES": MAX_DXF_BLOB,
    }
    for name, maximum in limits.items():
        try:
            value = int(env.get(name) or 0)
        except Exception:
            value = 0
        checks.require(0 < value <= maximum, f"{name} valt binnen hard maximum")
    try:
        dxf_count = int(env.get("PUBLIC_DXF_MAX_COUNT") or 0)
    except Exception:
        dxf_count = 0
    checks.require(0 < dxf_count <= 500, "PUBLIC_DXF_MAX_COUNT valt binnen hard maximum")
    for name in ("PUBLIC_JOB_MAX_CONCURRENT", "PUBLIC_JOB_MAX_CONCURRENT_PER_IP"):
        checks.require(str(env.get(name) or "") == "1", f"{name}=1 op huidige kleine-serverbaseline")

    library_path = state_resolved / "material_library.json"
    try:
        library = strict_json(library_path)
        active = active_catalog_records(library)
        minimum = max(1, int(env.get("PRODUCTION_MIN_CATALOG_RECORDS") or 1))
        checks.require(len(active) >= minimum, f"actieve gepubliceerde catalogus bevat {len(active)} records (minimum {minimum})")
        for record in active:
            if float(record.get("sellPriceInclVatPerSheet") or 0) <= 0:
                raise ValueError("actief materiaal zonder verkoopprijs incl. btw")
            if float(record.get("thicknessMm") or 0) not in {18.0, 19.0, 20.0}:
                raise ValueError("actief materiaal met verboden dikte")
            if float(record.get("sheetWid") or 0) <= 0 or float(record.get("sheetLen") or 0) <= 0:
                raise ValueError("actief materiaal zonder plaatmaat")
        checks.ok("actieve catalogusrecords hebben prijs/dikte/plaatmaat")
    except Exception as exc:
        checks.fail(f"runtime catalogus ongeldig: {exc}")

    pricing_path = state_resolved / "config/pricing_active.json"
    try:
        pricing = strict_json(pricing_path)
        sell = pricing.get("sellPricing") if isinstance(pricing, dict) else None
        if not isinstance(sell, dict) or "sheetPriceFactor" in sell:
            raise ValueError("ongeldig mixed-VAT pricingmodel")
        for key in ("edgeBandPricePerM", "cncCostPerSheet", "drawingCostFixed", "transportCostFixed"):
            value = float(sell[key])
            if not math.isfinite(value) or value < 0:
                raise ValueError(f"ongeldige {key}")
        checks.ok("runtime pricing is finite, non-negatief en zonder algemene materiaalfactor")
    except Exception as exc:
        checks.fail(f"runtime pricing ongeldig: {exc}")

    credential_value = env.get("ADMIN_CREDENTIALS_FILE") or os.environ.get("ADMIN_CREDENTIALS_FILE")
    credential_path = Path(credential_value or "/etc/adzaagt/metod-pax/admin_credentials.live.json").expanduser()
    validate_admin_credentials(checks, credential_path, production=production)

    probe = state_resolved / f".preflight-write-{os.getpid()}"
    try:
        with probe.open("x", encoding="utf-8") as handle:
            handle.write("ok\n")
            handle.flush()
            os.fsync(handle.fileno())
        checks.ok("service-identiteit kan externe state duurzaam schrijven")
    except Exception as exc:
        checks.fail(f"externe state niet schrijfbaar: {exc}")
    finally:
        probe.unlink(missing_ok=True)

    usage = shutil.disk_usage(state_resolved)
    minimum_free = max(64 * 1024 * 1024, int(env.get("MIN_FREE_STATE_BYTES") or 1024 * 1024 * 1024))
    checks.require(usage.free >= minimum_free, f"vrije state-opslag >= {minimum_free} bytes")
    if hasattr(os, "statvfs"):
        stat = os.statvfs(state_resolved)
        minimum_inodes = max(100, int(env.get("MIN_FREE_STATE_INODES") or 10_000))
        checks.require(stat.f_favail >= minimum_inodes, f"vrije state-inodes >= {minimum_inodes}")

    if production:
        signoff_path = Path(env.get("CATALOG_SIGNOFF_FILE") or state_resolved / "system/catalog_signoff.json")
        try:
            signoff = strict_json(signoff_path)
            valid = bool(
                isinstance(signoff, dict)
                and signoff.get("approved") is True
                and str(signoff.get("approvedBy") or "").strip()
                and str(signoff.get("approvedAt") or "").strip()
                and str(signoff.get("materialLibrarySha256") or "") == sha256_file(library_path)
            )
            checks.require(valid, "business-signoff is hashgebonden aan actieve catalogus")
        except Exception as exc:
            checks.fail(f"catalogussignoff ongeldig: {exc}")

        checks.require(truthy(env.get("OFFSITE_BACKUP_VERIFIED")), "encrypted off-host backup is expliciet geverifieerd")
        checks.require(bool(str(env.get("OFFSITE_BACKUP_PROVIDER") or "").strip()), "off-host backupprovider is vastgelegd")
        proof_path = Path(env.get("RESTORE_TEST_PROOF_FILE") or state_resolved / "system/restore_test_proof.json")
        try:
            proof = strict_json(proof_path)
            verified_at = datetime.fromisoformat(str(proof.get("verifiedAt") or "").replace("Z", "+00:00"))
            if verified_at.tzinfo is None:
                verified_at = verified_at.replace(tzinfo=timezone.utc)
            age = datetime.now(timezone.utc) - verified_at.astimezone(timezone.utc)
            max_age = max(1, int(env.get("RESTORE_TEST_MAX_AGE_DAYS") or 90))
            valid = bool(
                proof.get("ok") is True
                and timedelta(0) <= age <= timedelta(days=max_age)
                and re.fullmatch(r"[a-f0-9]{64}", str(proof.get("backupSha256") or ""))
            )
            checks.require(valid, "recente volledige restoreproef heeft geldig bewijs")
        except Exception as exc:
            checks.fail(f"restore-testbewijs ongeldig: {exc}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--release", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--verify-checksums", action="store_true")
    parser.add_argument("--runtime", action="store_true")
    parser.add_argument("--env-file", type=Path, default=Path("/etc/adzaagt/metod-pax/metod-pax.env"))
    parser.add_argument("--state-root")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    checks = Preflight()
    try:
        release = args.release.expanduser().resolve(strict=True)
    except Exception as exc:
        checks.fail(f"releasepad ongeldig: {exc}")
        release = args.release
    print(f"METOD/PAX {BUILD} preflight")
    print(f"Release: {release}")
    validate_release_tree(checks, release, verify_checksums=args.verify_checksums)
    if args.runtime:
        print("\nRuntimeprofiel")
        validate_runtime(checks, release, args.env_file.expanduser(), args.state_root)

    print("\nRESULTAAT:", "PASS" if not checks.failures else f"FAIL ({len(checks.failures)} fout(en))")
    if checks.failures:
        print("FOUTSAMENVATTING:")
        for index, failure in enumerate(checks.failures, 1):
            print(f"  {index}. {failure}")
    if checks.warnings:
        print(f"WAARSCHUWINGEN: {len(checks.warnings)}")
        for index, warning in enumerate(checks.warnings, 1):
            print(f"  {index}. {warning}")
    return 0 if not checks.failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
