#!/usr/bin/env python3
from __future__ import annotations

"""Outcome-based API-to-production lifecycle checks for FIX660R8.

This suite uses a temporary external state tree and one real METOD DXF. It proves
that public intent is canonicalized against the live catalog, the real optimizer
runs, finalization hashes are enforced, and common boundary tampering fails closed.
No persistent application or customer state is touched.
"""

import importlib
import importlib.util
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock


RELEASE_ROOT = Path(__file__).resolve().parents[1]
APP_ROOT = RELEASE_ROOT / "app"
PUBLIC_ID = "decor_0123456789abcdefabcd"
INTERNAL_CODE = "LIFECYCLE_MAT_18"
HEADER = (
    "PartId;PanelName;Qty;LengthMm;WidthMm;ThicknessMm;MaterialCode;"
    "GrainGroup;RotationAllowed;H1;H2;W1;W2\n"
)


class ServerLifecycleTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls._temp = tempfile.TemporaryDirectory(prefix="fix660r8_server_lifecycle_")
        cls.state_root = Path(cls._temp.name) / "state"
        cls._old_state_env = os.environ.get("METOD_STATE_ROOT")
        os.environ["METOD_STATE_ROOT"] = str(cls.state_root)
        sys.path.insert(0, str(APP_ROOT))
        cls.server = importlib.import_module("server_py")
        cls.server._initialize_external_state()

        library = {
            "source": "CSV_CATALOG_ONLY",
            "pricingModel": "catalog_sell_price_incl_vat_v2",
            "decorLibrarySchemaVersion": 4,
            "records": [
                {
                    "articleNo": INTERNAL_CODE,
                    "publicMaterialId": PUBLIC_ID,
                    "productName": "Lifecycle testmateriaal",
                    "sourceKind": "CATALOG_IMPORT",
                    "active": True,
                    "published": True,
                    "archived": False,
                    "catalogMissing": False,
                    "catalogExcluded": False,
                    "thicknessMm": 18,
                    "sheetWid": 2070,
                    "sheetLen": 2800,
                    "sellPriceInclVatPerSheet": 121.00,
                    "priceSource": "CSV_SALE_PRICE_INCL_VAT",
                    "hasGrain": True,
                    "grainDefaultOn": True,
                    "visualFamily": "Hout",
                    "visualTags": ["Hout"],
                    "colorGroup": "Bruin",
                    "searchTags": ["lifecycle"],
                }
            ],
        }
        cls.server.durable_write_json(cls.server.MATERIAL_LIBRARY_PATH, library)
        cls.handler = object.__new__(cls.server.Handler)
        cls.dxf_text = (
            APP_ROOT / "embedded_dxfs" / "Deuren METOD" / "Metod deur 60x40.dxf"
        ).read_text(encoding="utf-8", errors="strict")

    @classmethod
    def tearDownClass(cls) -> None:
        if cls._old_state_env is None:
            os.environ.pop("METOD_STATE_ROOT", None)
        else:
            os.environ["METOD_STATE_ROOT"] = cls._old_state_env
        try:
            sys.path.remove(str(APP_ROOT))
        except ValueError:
            pass
        cls._temp.cleanup()

    def _public_payload(
        self,
        *,
        material: str = PUBLIC_ID,
        thickness: str = "18",
        dxf_text: str | None = None,
        extra_dxf: bool = False,
    ) -> dict:
        dxf_parts = {"PANEL_A": dxf_text if dxf_text is not None else self.dxf_text}
        if extra_dxf:
            dxf_parts["UNUSED"] = self.dxf_text
        return {
            "panelsCsv": (
                HEADER
                + f"PANEL_A;Testdeur;1;397;597;{thickness};{material};;true;1;0;0;0\n"
            ),
            "dxfParts": dxf_parts,
            "jobJson": {
                "customer": {"name": " Test Klant ", "email": "test@example.invalid"},
                "rest_material": {"carry_out": True},
                "note": " lifecycle ",
                "grainEnabled": True,
                "sheetMarginMm": -999,
            },
            # Deliberately hostile browser pricing must disappear from the canonical DTO.
            "pricing": {
                "currency": "FREE",
                "edgeBanding": {"defaultLossPercent": -200},
            },
        }

    def test_01_public_boundary_fails_closed(self) -> None:
        with self.assertRaises(self.server.SafetyContractError):
            self.handler._canonicalize_public_job_payload(
                self._public_payload(material=INTERNAL_CODE)
            )
        with self.assertRaises(self.server.SafetyContractError):
            self.handler._canonicalize_public_job_payload(
                self._public_payload(thickness="19")
            )
        with self.assertRaises(self.server.SafetyContractError):
            self.handler._canonicalize_public_job_payload(
                self._public_payload(extra_dxf=True)
            )

        wrong_dxf = (
            APP_ROOT / "embedded_dxfs" / "Ladefront METOD" / "Metod lade 80x40.dxf"
        ).read_text(encoding="utf-8", errors="strict")
        with self.assertRaises(self.server.SafetyContractError):
            self.handler._canonicalize_public_job_payload(
                self._public_payload(dxf_text=wrong_dxf)
            )

    def test_01b_duplicate_dxf_bodies_are_parsed_once_at_public_boundary(self) -> None:
        payload = self._public_payload()
        payload["panelsCsv"] = (
            HEADER
            + f"PANEL_A;Testdeur A;1;397;597;18;{PUBLIC_ID};;true;1;0;0;0\n"
            + f"PANEL_B;Testdeur B;1;397;597;18;{PUBLIC_ID};;true;1;0;0;0\n"
        )
        payload["dxfParts"] = {"PANEL_A": self.dxf_text, "PANEL_B": self.dxf_text}
        with mock.patch.object(
            self.server,
            "_strict_dxf_parse_pairs",
            wraps=self.server._strict_dxf_parse_pairs,
        ) as parse_pairs:
            canonical = self.handler._canonicalize_public_job_payload(payload)
        self.assertEqual(parse_pairs.call_count, 1)
        self.assertIn("PANEL_A", canonical["panelsCsv"])
        self.assertIn("PANEL_B", canonical["panelsCsv"])

    def test_01c_250_compact_refs_stay_compact_through_optimizer_start(self) -> None:
        payload = self._public_payload()
        part_ids = [f"PANEL_{index:03d}" for index in range(250)]
        payload["panelsCsv"] = HEADER + "".join(
            f"{part_id};Bulk {index};1;397;597;18;{PUBLIC_ID};;true;1;0;0;0\n"
            for index, part_id in enumerate(part_ids)
        )
        payload.pop("dxfParts", None)
        payload["dxfBlobs"] = {"g0001": self.dxf_text}
        payload["dxfPartRefs"] = {part_id: "g0001" for part_id in part_ids}

        canonical = self.handler._canonicalize_public_job_payload(payload)
        self.assertNotIn("dxfParts", canonical)
        self.assertEqual(len(canonical["dxfBlobs"]), 1)
        self.assertEqual(len(canonical["dxfPartRefs"]), 250)

        master_id = "LIFECYCLE_BULK_250"
        result = self.server._create_job_from_payload(
            canonical,
            master_job_id=master_id,
            public_access_token="bulk-test-token",
        )
        self.assertEqual(result["jobId"], master_id)
        subjob_root = self.server.resolve_identifier_child(
            self.server.JOBS, result["subjobs"][0]["subjobId"]
        )
        self.assertEqual(len(list((subjob_root / "input" / "dxf_blobs").glob("*.dxf"))), 1)
        refs = json.loads((subjob_root / "input" / "dxf_part_refs.json").read_text(encoding="utf-8"))
        self.assertEqual(len(refs["partRefs"]), 250)
        report = json.loads((subjob_root / "output" / "report.json").read_text(encoding="utf-8"))
        self.assertEqual(report["dxfInput"]["storageMode"], "content_addressed_refs_v1")
        self.assertEqual(report["dxfInput"]["logicalParts"], 250)
        self.assertEqual(report["dxfInput"]["uniqueBodies"], 1)
        finalization = json.loads((subjob_root / "output" / "finalization.json").read_text(encoding="utf-8"))
        self.assertEqual(finalization["counts"]["instances"], 250)
        self.assertEqual(finalization["counts"]["placements"], 250)
        self.assertEqual(finalization["counts"]["partDxfs"], 250)

    def test_02_real_job_finalization_and_tamper_detection(self) -> None:
        canonical = self.handler._canonicalize_public_job_payload(self._public_payload())
        self.assertEqual(canonical["payloadSchema"], "FIX660R8_SERVER_CANONICAL_V1")
        self.assertNotIn("pricing", canonical)
        self.assertNotIn("sheetMarginMm", canonical["jobJson"])
        self.assertFalse(canonical["jobJson"]["grainEnabled"])
        self.assertIn(INTERNAL_CODE, canonical["panelsCsv"])
        self.assertNotIn(PUBLIC_ID, canonical["panelsCsv"])

        master_id = "LIFECYCLE_JOB_001"
        result = self.server._create_job_from_payload(
            canonical,
            master_job_id=master_id,
            public_access_token="test-token-never-persisted-outside-temp-state",
        )
        self.assertEqual(result["jobId"], master_id)
        self.assertEqual(len(result["subjobs"]), 1)
        subjob_id = result["subjobs"][0]["subjobId"]
        master_root = self.server.resolve_identifier_child(self.server.JOBS, master_id)
        subjob_root = self.server.resolve_identifier_child(self.server.JOBS, subjob_id)
        self.assertTrue(self.server._finalization_complete(subjob_root))
        self.assertTrue(self.server._finalization_complete(master_root))

        finalization = json.loads(
            (subjob_root / "output" / "finalization.json").read_text(encoding="utf-8")
        )
        self.assertEqual(finalization["schemaVersion"], 2)
        self.assertEqual(finalization["state"], "COMPLETE")
        self.assertEqual(finalization["counts"]["instances"], 1)
        self.assertEqual(finalization["counts"]["placements"], 1)
        self.assertEqual(finalization["counts"]["sheetDxfs"], 1)

        quote_path = subjob_root / "output" / "quote.json"
        original_quote = quote_path.read_bytes()
        quote_path.write_bytes(original_quote + b"\n")
        self.assertFalse(self.server._finalization_complete(subjob_root))
        self.assertFalse(self.server._finalization_complete(master_root))
        quote_path.write_bytes(original_quote)
        self.assertTrue(self.server._finalization_complete(subjob_root))
        self.assertTrue(self.server._finalization_complete(master_root))

        with self.assertRaises(self.server.SafetyContractError):
            self.server.resolve_identifier_child(self.server.JOBS, "../../victim")
        with self.assertRaises(self.server.SafetyContractError):
            self.server.resolve_relative_file(subjob_root, "output/../../secrets")

    def test_03_admin_manifest_is_read_only_and_cancel_fails_closed(self) -> None:
        master_id = "LIFECYCLE_JOB_001"
        master_root = self.server.resolve_identifier_child(self.server.JOBS, master_id)
        links = self.server.strict_json_load(master_root / "output" / "links.json")
        subjob_id = links["subjobs"][0]["subjobId"]
        subjob_root = self.server.resolve_identifier_child(self.server.JOBS, subjob_id)
        summary_path = subjob_root / "output" / "calculation_summary.txt"
        summary_before = summary_path.read_bytes()
        finalization_before = (
            subjob_root / "output" / "finalization.json"
        ).read_bytes()

        request_id = "REQ_LIFECYCLE_001"
        self.server._ensure_request_dirs()
        self.server._save_status(
            request_id,
            {
                "requestId": request_id,
                "job": {
                    "parentJobId": master_id,
                    "subjobs": [{"subjobId": subjob_id}],
                },
            },
        )
        manifest = self.server._build_request_file_manifest(request_id)
        self.assertTrue(manifest["allFiles"])
        unsealed = subjob_root / "output" / "diagnostic-unsealed.txt"
        unsealed.write_text("must never be downloadable\n", encoding="utf-8")
        manifest_with_unsealed_file = self.server._build_request_file_manifest(request_id)
        self.assertNotIn(
            "output/diagnostic-unsealed.txt",
            {str(item.get("rel") or "") for item in manifest_with_unsealed_file["allFiles"]},
        )
        jobs_handler = object.__new__(self.server.Handler)
        jobs_handler._send_json = lambda obj, code=200: (obj, code)
        admin_jobs, admin_code = self.server.api_admin_jobs(jobs_handler)
        self.assertEqual(admin_code, 200)
        subjob_row = next(row for row in admin_jobs["jobs"] if row["jobId"] == subjob_id)
        sealed_relations = {str(item.get("rel") or "") for item in subjob_row["sealedFiles"]}
        self.assertNotIn("output/diagnostic-unsealed.txt", sealed_relations)
        self.assertNotIn("output/toolb_stdout.txt", sealed_relations)
        self.assertEqual(summary_path.read_bytes(), summary_before)
        self.assertEqual(
            (subjob_root / "output" / "finalization.json").read_bytes(),
            finalization_before,
        )
        self.assertTrue(self.server._finalization_complete(subjob_root))
        self.assertTrue(self.server._finalization_complete(master_root))

        self.server._save_job_runtime_state(master_id, "CANCELLED", reason="test")
        self.assertFalse(self.server._finalization_complete(subjob_root))
        self.assertFalse(self.server._finalization_complete(master_root))
        self.assertIsNone(self.server._find_or_generate_stickertool_file(subjob_id))
        self.server._save_job_runtime_state(master_id, "DONE", reason="test-cleanup")
        self.assertTrue(self.server._finalization_complete(master_root))

    def test_04_capacity_and_catalog_review_hash_fail_closed(self) -> None:
        with mock.patch.object(
            self.server.shutil,
            "disk_usage",
            return_value=SimpleNamespace(total=1024, used=1023, free=1),
        ):
            with self.assertRaises(self.server.SafetyContractError):
                self.server._enforce_state_capacity(1)

        stage = {
            "csvSha256": "a" * 64,
            "warnings": [{"row": 2, "message": "review"}],
            "excluded": [],
            "errors": [],
            "summary": {"accepted": 1},
            "taxonomySummary": {"reviewRequired": 0},
            "records": [{"articleNo": "A", "sellPriceInclVatPerSheet": 121.0}],
        }
        signed = self.server._catalog_review_sha256(stage)
        stage["warnings"].append({"row": 3, "message": "changed"})
        self.assertNotEqual(self.server._catalog_review_sha256(stage), signed)

        valid_hash = self.server._pbkdf2_hash_password("test-password")
        self.assertTrue(self.server._verify_password_against_stored("test-password", valid_hash))
        self.assertFalse(
            self.server._verify_password_against_stored(
                "test-password", valid_hash.replace("$260000$", "$260001$", 1)
            )
        )

    def test_05_public_status_never_surfaces_tampered_quote(self) -> None:
        master_id = "LIFECYCLE_JOB_001"
        master_root = self.server.resolve_identifier_child(self.server.JOBS, master_id)
        links = self.server.strict_json_load(master_root / "output" / "links.json")
        subjob_id = links["subjobs"][0]["subjobId"]
        subjob_root = self.server.resolve_identifier_child(self.server.JOBS, subjob_id)
        quote_path = subjob_root / "output" / "quote.json"
        original = quote_path.read_bytes()

        status_handler = object.__new__(self.server.Handler)
        status_handler._require_job_access = lambda *args, **kwargs: True
        status_handler._send_json = lambda obj, code=200: (obj, code)
        valid_body, valid_code = status_handler._api_status(master_id)
        self.assertEqual(valid_code, 200)
        self.assertEqual(valid_body["meta"]["status"], "done")
        self.assertIsNotNone(valid_body["quote"])

        quote_path.write_bytes(original + b"\n")
        blocked_body, blocked_code = status_handler._api_status(master_id)
        self.assertEqual(blocked_code, 409)
        self.assertIsNone(blocked_body["quote"])
        self.assertEqual(blocked_body["pricingSummary"], {})
        admin_manifest = self.server._build_request_file_manifest("REQ_LIFECYCLE_001")
        self.assertEqual(admin_manifest["allFiles"], [])
        self.assertEqual(admin_manifest["pricingSummary"], {})
        quote_path.write_bytes(original)

    def test_06_real_backup_restore_roundtrip(self) -> None:
        marker = self.server.SUBMISSION_IDEMPOTENCY_DIR / "roundtrip-marker.json"
        self.server.durable_write_json(
            marker,
            {"schemaVersion": 1, "parentJobId": "LIFECYCLE_JOB_001", "requestId": "REQ_LIFECYCLE_001"},
        )
        created = self.server._create_system_backup(actor="lifecycle-test", backup_kind="manual")
        backup = self.server.BACKUPS_DIR / created["file"]
        self.assertTrue(backup.is_file())

        restore_path = RELEASE_ROOT / "tools" / "restore_system_backup.py"
        spec = importlib.util.spec_from_file_location("fix660r8_restore_runtime", restore_path)
        self.assertIsNotNone(spec)
        self.assertIsNotNone(spec.loader)
        restore_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(restore_module)

        verified = restore_module.verify_backup(backup)
        self.assertGreater(verified["stateFileCount"], 0)
        target = Path(self._temp.name) / "restored-state"
        result = restore_module.restore_backup(backup, target)
        self.assertTrue(result["ok"])
        self.assertEqual((target / marker.relative_to(self.state_root)).read_bytes(), marker.read_bytes())
        self.assertEqual(
            (target / "material_library.json").read_bytes(),
            self.server.MATERIAL_LIBRARY_PATH.read_bytes(),
        )
        self.assertFalse((target / "backups").exists())


if __name__ == "__main__":
    unittest.main(verbosity=2)
