#!/usr/bin/env python3
from __future__ import annotations

"""METOD Tool B — DXF nesting optimizer (V1.4, dependency‑free)

Inputs (in input folder)
- panels.csv (semicolon separated)
- pricing.json
- dxf_blobs/<sha256>.dxf + dxf_part_refs.json (production compact format)
- dxf_parts/<PartId>.dxf (legacy/test compatibility)

Outputs (in output folder)
- sheets/*.dxf
- placements.json
- report.json
- quote.json

Contract notes
- Units are mm
- margin forced to 6.5 mm for this build
- gap forced to 13.0 mm for this build
- GrainGroup non-empty => rotation forced to 0
- RotationAllowed controls whether 90° is allowed (unless grain forces 0)
- Placements use origin bottom-left, y axis up
- placement.x_mm / y_mm represent bbox-min after rotation

This implementation avoids third‑party dependencies (no `pip install`).
It uses a simple DXF text parser and transforms the supported coordinate group codes.
"""

import argparse
import csv
import itertools
import json
import math
import os
import time

import re

from dxf_geometry import (
    ContractError as DxfContractError,
    entities_bbox as strict_entities_bbox,
    entities_section as strict_entities_section,
    entity_bbox as strict_entity_bbox,
    entity_layer as strict_entity_layer,
    entity_type as strict_entity_type,
    geometry_sha256,
    pairs_to_text as strict_pairs_to_text,
    parse_pairs as strict_parse_pairs,
    set_entity_layer,
    split_entities as strict_split_entities,
    transform_entities as strict_transform_entities,
)
from panel_contract import parse_panels_csv as parse_panels_csv_contract
from safety_contracts import (
    ContractError,
    durable_copy_file,
    durable_write_json,
    durable_write_text,
    finite_number,
    sha256_file,
    strict_json_load,
    strict_json_dumps,
)


def safe_slug(s: str) -> str:
    """Make a filesystem-safe slug for filenames."""
    s = str(s or '').strip()
    s = re.sub(r"\s+", "_", s)
    s = re.sub(r"[^A-Za-z0-9_\-.]+", "_", s)
    s = re.sub(r"_+", "_", s)
    s = s.strip("._-")
    return s or "NA"
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from contextlib import contextmanager
from collections import defaultdict

_OPTIMIZER_PROFILER = None

class OptimizerProfiler:
    """Detailed runtime profiler for Tool B performance audits.

    FIX467 safety repair: keep the audit useful, but make trace writing lightweight
    enough that heavy optimizer runs do not stall on per-event disk flushing.
    """
    _FLUSH_EVERY_EVENTS = 250
    _FLUSH_EVERY_SECONDS = 0.75
    _MAX_TRACE_EVENTS = 12000

    def __init__(self, output_dir: Path):
        self.output_dir = Path(output_dir)
        self.trace_path = self.output_dir / 'optimizer_perf_trace.jsonl'
        self.summary_path = self.output_dir / 'optimizer_perf_summary.json'
        self.started = time.perf_counter()
        self._trace_fh = None
        self._buffer: List[str] = []
        self._events_written = 0
        self._events_dropped = 0
        self._last_flush_at = self.started
        self.counters = defaultdict(float)
        self.meta = {}
        try:
            ensure_dir(self.output_dir)
            self._trace_fh = open(self.trace_path, 'w', encoding='utf-8')
        except Exception:
            self._trace_fh = None

    def _flush_trace(self, force: bool = False) -> None:
        if not self._trace_fh or not self._buffer:
            return
        now = time.perf_counter()
        if not force:
            if len(self._buffer) < self._FLUSH_EVERY_EVENTS and (now - self._last_flush_at) < self._FLUSH_EVERY_SECONDS:
                return
        try:
            self._trace_fh.write(''.join(self._buffer))
            self._trace_fh.flush()
            self._buffer.clear()
            self._last_flush_at = now
        except Exception:
            pass

    def close(self):
        try:
            self._flush_trace(force=True)
            if self._trace_fh:
                self._trace_fh.close()
        except Exception:
            pass
        self._trace_fh = None

    def _write_event(self, payload: Dict[str, Any]) -> None:
        if not self._trace_fh:
            return
        if self._events_written >= self._MAX_TRACE_EVENTS:
            self._events_dropped += 1
            return
        try:
            self._buffer.append(strict_json_dumps(payload) + '\n')
            self._events_written += 1
            self._flush_trace(force=False)
        except Exception:
            pass

    def event(self, name: str, **data: Any) -> None:
        payload = {
            't': round(time.perf_counter() - self.started, 6),
            'event': name,
        }
        if data:
            payload.update(data)
        self._write_event(payload)

    @contextmanager
    def section(self, name: str, **data: Any):
        t0 = time.perf_counter()
        self.event(name + ':start', **data)
        exc = None
        try:
            yield
        except Exception as e:
            exc = e
            raise
        finally:
            dt = time.perf_counter() - t0
            self.counters[f'section_seconds.{name}'] += dt
            self.counters[f'section_calls.{name}'] += 1
            end_payload = dict(data)
            end_payload['seconds'] = round(dt, 6)
            end_payload['ok'] = exc is None
            self.event(name + ':end', **end_payload)

    def add(self, key: str, value: float = 1.0) -> None:
        self.counters[key] += value

    def set_meta(self, **data: Any) -> None:
        self.meta.update(data)

    def write_summary(self) -> None:
        self.counters['trace.events_written'] += float(self._events_written)
        self.counters['trace.events_dropped'] += float(self._events_dropped)
        self._flush_trace(force=True)
        payload = {
            'generatedAt': now_iso(),
            'elapsedSeconds': round(time.perf_counter() - self.started, 6),
            'meta': self.meta,
            'counters': {k: (round(v, 6) if isinstance(v, float) else v) for k, v in sorted(self.counters.items())},
        }
        try:
            durable_write_json(self.summary_path, payload)
        except Exception:
            pass

def _profiler() -> Optional[OptimizerProfiler]:
    return _OPTIMIZER_PROFILER


# ------------------------------
# Utilities
# ------------------------------

def now_iso() -> str:
    return time.strftime('%Y-%m-%dT%H:%M:%S')


def ensure_dir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)


def round01(x: float) -> float:
    return round(float(x), 1)


def fatal(report: Dict[str, Any], msg: str) -> None:
    report.setdefault('errors', []).append(msg)
    raise RuntimeError(msg)


def warn(report: Dict[str, Any], msg: str) -> None:
    report.setdefault('warnings', []).append(msg)


# ------------------------------
# Panels CSV
# ------------------------------

@dataclass
class PanelRow:
    PartId: str
    PanelName: str
    Qty: int
    LengthMm: float
    WidthMm: float
    ThicknessMm: float
    MaterialCode: str
    GrainGroup: str
    RotationAllowed: bool
    H1: int
    H2: int
    W1: int
    W2: int


def read_panels_csv(
    path: Path,
    report: Dict[str, Any],
    *,
    allowed_thicknesses: Set[float],
    allowed_edge_codes: Set[int],
) -> List[PanelRow]:
    if not path.exists():
        fatal(report, f"Missing panels.csv: {path}")
    try:
        canonical = parse_panels_csv_contract(
            path.read_text(encoding='utf-8', errors='strict'),
            allowed_thicknesses=allowed_thicknesses,
            allowed_edge_codes=allowed_edge_codes,
            max_rows=int(os.environ.get('OPTIMIZER_MAX_PANEL_ROWS', '500')),
            max_total_qty=int(os.environ.get('OPTIMIZER_MAX_TOTAL_QTY', '250')),
        )
    except Exception as exc:
        fatal(report, f"Invalid panels.csv: {exc}")
    return [PanelRow(**row.as_dict()) for row in canonical]


# ------------------------------
# DXF parsing + transform
# ------------------------------

def dxf_pairs(text: str) -> List[Tuple[int, str]]:
    return strict_parse_pairs(text)


def pairs_to_dxf(pairs: List[Tuple[int,str]]) -> str:
    return strict_pairs_to_text(pairs)


def _extract_entities_pairs(all_pairs: List[Tuple[int,str]]) -> List[Tuple[int,str]]:
    return strict_entities_section(all_pairs)


def _float(v: str) -> Optional[float]:
    try:
        return float(v)
    except Exception:
        return None


def compute_bbox_from_pairs(pairs: List[Any], report: Dict[str,Any]) -> Tuple[float,float,float,float]:
    bbox = strict_entities_bbox(strict_split_entities(pairs))
    return (bbox.min_x, bbox.min_y, bbox.max_x, bbox.max_y)


def shift_pairs_xy(pairs: List[Tuple[int,str]], dx: float, dy: float) -> List[Tuple[int,str]]:
    entities = strict_transform_entities(
        strict_split_entities(pairs),
        rotation_deg=0,
        translate_x=float(dx),
        translate_y=float(dy),
        source_width=0.0,
        source_height=0.0,
    )
    return [pair for entity in entities for pair in entity]


def set_layer_for_pairs(ent: List[Tuple[int,str]], layer: str) -> List[Tuple[int,str]]:
    """Ensure the entity is on a predictable layer.

    Some viewers/CAM setups rely on layers. We use:
    - CUT: outer contour rectangles
    - DRILL: circles/arcs for machining
    """
    entities = [set_entity_layer(entity, layer) for entity in strict_split_entities(ent)]
    return [pair for entity in entities for pair in entity]


def rotate_translate_pairs(pairs: List[Tuple[int,str]], rot_deg: int, tx: float, ty: float, w0: float, h0: float) -> List[Tuple[int,str]]:
    entities = strict_split_entities(pairs)
    transformed = strict_transform_entities(
        entities,
        rotation_deg=int(rot_deg),
        translate_x=float(tx),
        translate_y=float(ty),
        source_width=float(w0),
        source_height=float(h0),
    )
    return [pair for entity in transformed for pair in entity]


@dataclass
class PartData:
    part_id: str
    bbox: Tuple[float,float,float,float]
    w: float
    h: float
    # Only machining geometry to place (we draw the outer contour as a clean
    # rectangle, so we never export texture lines/dimensions from the source).
    drill_pairs: List[Tuple[int,str]]
    drill_entity_count: int
    drill_geometry_sha256: str


def load_part(part_path: Path, report: Dict[str,Any]) -> PartData:
    txt = part_path.read_text(encoding='utf-8', errors='strict')
    allp = dxf_pairs(txt)

    # Parse BLOCKS section so we can "explode" INSERTs that contain drill circles/arcs.
    # Some METOD templates store one (or more) hole(s) as INSERTed block geometry.
    def _extract_blocks_pairs(all_pairs: List[Tuple[int,str]]) -> Dict[str, List[Tuple[int,str]]]:
        blocks: Dict[str, List[Tuple[int,str]]] = {}
        in_blocks = False
        i = 0
        cur_name: Optional[str] = None
        cur_pairs: List[Tuple[int,str]] = []
        while i < len(all_pairs) - 1:
            c, v = all_pairs[i]
            if c == 0 and v == 'SECTION' and i+1 < len(all_pairs) and all_pairs[i+1] == (2,'BLOCKS'):
                in_blocks = True
                i += 2
                continue
            if in_blocks and c == 0 and v == 'ENDSEC':
                # flush last
                if cur_name and cur_pairs:
                    blocks[cur_name] = cur_pairs
                break
            if in_blocks:
                # Start of a BLOCK entity
                if c == 0 and v == 'BLOCK':
                    # flush previous block
                    if cur_name and cur_pairs:
                        blocks[cur_name] = cur_pairs
                    cur_name = None
                    cur_pairs = [(c, v)]
                else:
                    cur_pairs.append((c, v))
                    if c == 2 and cur_name is None:
                        # code 2 in BLOCK header = block name
                        cur_name = str(v).strip()
            i += 1
        return blocks

    blocks = _extract_blocks_pairs(allp)

    ents = _extract_entities_pairs(allp)
    source_entities = strict_split_entities(ents)
    source_types = {strict_entity_type(entity) for entity in source_entities}
    unsupported_types = sorted(source_types - {'LINE', 'CIRCLE', 'ARC', 'LWPOLYLINE'})
    if unsupported_types:
        fatal(report, f"{part_path.name}: unsupported production DXF entities: {unsupported_types}")
    for entity in source_entities:
        if strict_entity_type(entity) == 'LWPOLYLINE' and strict_entity_layer(entity).upper() != 'OUTLINE':
            fatal(report, f"{part_path.name}: only an OUTLINE LWPOLYLINE is accepted")
    bbox = compute_bbox_from_pairs(ents, report)
    minx, miny, maxx, maxy = bbox
    w = maxx - minx
    h = maxy - miny
    if not all(math.isfinite(value) for value in (minx, miny, maxx, maxy, w, h)) or w <= 0 or h <= 0:
        fatal(report, f"{part_path.name}: DXF has no valid finite panel bbox")

    # Normalize so bbox min at 0,0
    ents_norm_pairs = shift_pairs_xy(ents, dx=-minx, dy=-miny)

    # --- IMPORTANT ---
    # Source DXFs can contain lots of "preview" geometry (wood texture lines,
    # dimensions, helpers). For the nesting output we only want machining
    # geometry (holes). The outer contour is always a clean rectangle based on
    # the measured bbox.
    #
    # NOTE: `ents_norm_pairs` is a *flat* list of (groupcode,value) pairs.
    # We must first split it into per-entity chunks before we can inspect
    # entity types (CIRCLE/ARC/etc). A previous version treated a single
    # (code,value) tuple as an entity and crashed with:
    #   "cannot unpack non-iterable int object"
    # when doing `for c, v in pairs:`.

    def split_entities(flat_pairs: List[Tuple[int,str]]) -> List[List[Tuple[int,str]]]:
        entities: List[List[Tuple[int,str]]] = []
        cur: List[Tuple[int,str]] = []
        for item in flat_pairs:
            if not (isinstance(item, (list, tuple)) and len(item) == 2):
                continue
            c, v = item
            if c == 0 and cur:
                entities.append(cur)
                cur = [(c, v)]
            else:
                cur.append((c, v))
        if cur:
            entities.append(cur)
        return entities

    def entity_type(ent: List[Tuple[int,str]]) -> str:
        for c, v in ent:
            if c == 0:
                return str(v).strip().upper()
        return ""

    drill_entities: List[List[Tuple[int,str]]] = []
    insert_entities: List[List[Tuple[int,str]]] = []

    # Some libraries export tiny drill centers as DXF POINT entities.
    # Many viewers/CAM setups won't display/use POINT for machining,
    # so we convert them to very small circles.
    # If you want a different value, set pricing.defaults.pointDrillDiameterMm.
    def _point_to_circle(ent: List[Tuple[int,str]], diameter_mm: float) -> List[Tuple[int,str]]:
        cx = cy = None
        for c, v in ent:
            if c == 10:
                try: cx = float(v)
                except: cx = None
            elif c == 20:
                try: cy = float(v)
                except: cy = None
        if cx is None or cy is None:
            return ent
        r = max(0.1, float(diameter_mm) / 2.0)
        # Minimal CIRCLE entity
        return [(0,'CIRCLE'), (10,str(cx)), (20,str(cy)), (40,str(r))]

    # Some METOD DXFs (and similar furniture templates) mark a tiny pilot hole
    # using a filled SOLID/TRACE entity instead of a CIRCLE/POINT.
    # Viewers show this as a small dot, but if we don't convert it, it will
    # disappear in the nested DXF output. We convert it to a small CIRCLE.
    def _solid_to_circle(ent: List[Tuple[int,str]], diameter_mm: float) -> List[Tuple[int,str]]:
        xs: List[float] = []
        ys: List[float] = []
        for c, v in ent:
            if c in (10, 11, 12, 13):
                try: xs.append(float(v))
                except: pass
            elif c in (20, 21, 22, 23):
                try: ys.append(float(v))
                except: pass
        if not xs or not ys:
            return ent
        cx = (min(xs) + max(xs)) / 2.0
        cy = (min(ys) + max(ys)) / 2.0
        r = max(0.1, float(diameter_mm) / 2.0)
        return [(0,'CIRCLE'), (10,str(cx)), (20,str(cy)), (40,str(r))]

    # Some METOD source DXFs encode certain "holes" not as circles, but as small
    # closed polylines / ellipses / points (and sometimes those shapes live inside blocks).
    # We treat any *small feature* geometry as machining geometry too, otherwise holes
    # appear to disappear after nesting.
    def _entity_bbox(ent: List[Tuple[int,str]]) -> Optional[Tuple[float,float,float,float]]:
        et = entity_type(ent)
        xs: List[float] = []
        ys: List[float] = []
        r: Optional[float] = None
        # collect common coordinate codes
        for c, v in ent:
            if c in (10, 11, 12, 13, 14, 15, 16, 17):  # x-like
                try: xs.append(float(v))
                except: pass
            elif c in (20, 21, 22, 23, 24, 25, 26, 27):  # y-like
                try: ys.append(float(v))
                except: pass
            elif c == 40 and et == 'CIRCLE':
                try: r = float(v)
                except: pass
        if et == 'CIRCLE' and len(xs) >= 1 and len(ys) >= 1 and r is not None:
            cx, cy = xs[0], ys[0]
            return (cx - r, cy - r, cx + r, cy + r)
        if not xs or not ys:
            return None
        return (min(xs), min(ys), max(xs), max(ys))

    def _is_small_feature(ent: List[Tuple[int,str]]) -> bool:
        # POINT entities are often used in the METOD library to indicate
        # a tiny pilot hole / drill center. They have a degenerate bbox
        # (dx=dy=0), so a pure bbox heuristic would incorrectly drop them.
        if entity_type(ent) == 'POINT':
            # Keep if it contains at least one coordinate pair.
            has_x = any(c in (10, 11, 12, 13, 14, 15, 16, 17) for c, _ in ent)
            has_y = any(c in (20, 21, 22, 23, 24, 25, 26, 27) for c, _ in ent)
            return has_x and has_y
        bb = _entity_bbox(ent)
        if bb is None:
            return False
        minx_, miny_, maxx_, maxy_ = bb
        dx_ = maxx_ - minx_
        dy_ = maxy_ - miny_
        maxdim = max(dx_, dy_)
        # absolute + relative guards (templates are mm)
        if maxdim <= 0:
            return False
        if maxdim <= 120.0:
            return True
        # relative to part size (in case units differ)
        return maxdim <= min(w, h) * 0.35

    # default diameter for tiny-marker -> CIRCLE conversion
    point_diam = 2.0
    try:
        # pricing isn't available here; but users can override via env var if needed
        point_diam = float(os.environ.get('METOD_POINT_DRILL_DIAMETER_MM', point_diam))
    except Exception:
        pass

    solid_diam = point_diam
    try:
        solid_diam = float(os.environ.get('METOD_SOLID_DRILL_DIAMETER_MM', solid_diam))
    except Exception:
        pass

    for ent in split_entities(ents_norm_pairs):
        et = entity_type(ent)
        if et in ('CIRCLE', 'ARC'):
            drill_entities.append(ent)
        elif et == 'LWPOLYLINE' and strict_entity_layer(ent).upper() == 'OUTLINE':
            continue
        elif et in ('POLYLINE', 'ELLIPSE', 'SPLINE', 'POINT', 'SOLID', 'TRACE'):
            if _is_small_feature(ent):
                if et == 'POINT':
                    drill_entities.append(_point_to_circle(ent, point_diam))
                elif et in ('SOLID','TRACE'):
                    drill_entities.append(_solid_to_circle(ent, solid_diam))
                else:
                    drill_entities.append(ent)
        elif et == 'INSERT':
            insert_entities.append(ent)

    # Explode INSERT blocks if they contain CIRCLE/ARC drills
    def _get(ent: List[Tuple[int,str]], code_int: int) -> Optional[str]:
        for c, v in ent:
            if c == code_int:
                return str(v).strip()
        return None

    def _explode_insert(insert_ent: List[Tuple[int,str]]) -> List[List[Tuple[int,str]]]:
        name = _get(insert_ent, 2)  # block name
        if not name or name not in blocks:
            return []
        # Insert transform (defaults)
        ix = _float(_get(insert_ent, 10) or '0') or 0.0
        iy = _float(_get(insert_ent, 20) or '0') or 0.0
        rot = _float(_get(insert_ent, 50) or '0') or 0.0
        sx = _float(_get(insert_ent, 41) or '1') or 1.0
        sy = _float(_get(insert_ent, 42) or '1') or 1.0

        # Extract entities within this block: between 0 ENDBLK, skip header codes until first 0-entity
        blk_pairs = blocks[name]
        # find first entity after BLOCK header: look for 0 (not BLOCK) after header
        # We'll reuse split_entities on the block's ENTITIES-like stream by taking pairs after the first 0 that is not BLOCK.
        # Simpler: collect pairs from the first 0 that is not BLOCK/ENDBLK.
        inner: List[Tuple[int,str]] = []
        started = False
        for c, v in blk_pairs:
            if c == 0 and str(v).strip().upper() in ('BLOCK','ENDBLK'):
                continue
            if c == 0 and not started:
                started = True
            if started:
                inner.append((c, v))

        exploded: List[List[Tuple[int,str]]] = []
        for ent in split_entities(inner):
            et = entity_type(ent)

            # Allow more "hole" representations inside blocks too.
            allowed = {'CIRCLE','ARC','LWPOLYLINE','POLYLINE','ELLIPSE','SPLINE','POINT','SOLID','TRACE'}
            if et not in allowed:
                continue

            # If it's not a circle/arc, only keep it if it looks like a small feature.
            if et not in ('CIRCLE','ARC') and not _is_small_feature(ent):
                continue

            # Convert POINT to a small CIRCLE so it's preserved reliably downstream.
            if et == 'POINT':
                ent = _point_to_circle(ent, point_diam)
                et = entity_type(ent)
            # Convert SOLID/TRACE marker dots to a small CIRCLE.
            if et in ('SOLID','TRACE'):
                ent = _solid_to_circle(ent, solid_diam)
                et = entity_type(ent)

            # Apply INSERT transform: scale -> rotate -> translate.
            ang = math.radians(rot)
            xmap = {10:20, 11:21, 12:22, 13:23, 14:24, 15:25, 16:26, 17:27}

            out_ent: List[Tuple[int,str]] = []
            pending_x = {}  # code->float
            for c, v in ent:
                if c in xmap:
                    fx = _float(v)
                    if fx is None:
                        out_ent.append((c, v))
                        continue
                    pending_x[c] = fx
                    # We postpone writing until we see the matching y code,
                    # so we can rotate (x,y) as a pair.
                    continue

                # matching y codes
                inv = {yv: xv for xv, yv in xmap.items()}
                if c in inv:
                    xv = inv[c]
                    fy = _float(v)
                    fx = pending_x.pop(xv, None)
                    if fy is None or fx is None:
                        out_ent.append((c, v))
                        continue
                    # scale
                    fx *= sx; fy *= sy
                    # rotate
                    rx = fx*math.cos(ang) - fy*math.sin(ang)
                    ry = fx*math.sin(ang) + fy*math.cos(ang)
                    # translate
                    rx += ix; ry += iy
                    out_ent.append((xv, f"{rx}"))
                    out_ent.append((c, f"{ry}"))
                    continue

                if c == 40 and et == 'CIRCLE':
                    r = _float(v)
                    if r is None:
                        out_ent.append((c, v))
                    else:
                        # use average scale
                        s = (abs(sx) + abs(sy)) / 2.0
                        out_ent.append((c, f"{r*s}"))
                    continue

                # default passthrough
                out_ent.append((c, v))

            # flush any pending x without y
            for xv, fx in pending_x.items():
                out_ent.append((xv, str(fx)))

            exploded.append(out_ent)
        return exploded

    for ins in insert_entities:
        drill_entities.extend(_explode_insert(ins))

    # IMPORTANT: downstream transform/export code expects a *flat* list of
    # (groupcode,value) pairs, not a list-of-entities. Flatten here while
    # keeping the entity separators (0-group codes) intact.
    drill_flat: List[Tuple[int,str]] = [pair for ent in drill_entities for pair in ent]

    strict_drill_entities = strict_split_entities(drill_flat) if drill_flat else []
    return PartData(
        part_id=part_path.stem,
        bbox=(0.0, 0.0, w, h),
        w=w,
        h=h,
        drill_pairs=drill_flat,
        drill_entity_count=len(strict_drill_entities),
        drill_geometry_sha256=geometry_sha256(strict_drill_entities),
    )

def validate_part_bbox(part_id: str, expected_w: float, expected_h: float, pdata: PartData, report: Dict[str,Any]) -> None:
    # expected_w is WidthMm, expected_h is LengthMm
    tol = float(os.environ.get('DXF_BBOX_TOLERANCE_MM', '0.1'))
    if abs(pdata.w - expected_w) > tol or abs(pdata.h - expected_h) > tol:
        fatal(report, f"{part_id}: DXF bbox {pdata.w:.3f}x{pdata.h:.3f} differs from CSV {expected_w:.3f}x{expected_h:.3f} (tolerance {tol}mm)")


# ------------------------------
# Packing (simple shelves)
# ------------------------------

@dataclass
class Instance:
    row: PanelRow
    idx: int
    w: float
    h: float
    rot_allowed: bool


@dataclass
class Placement:
    partId: str
    instanceIndex: int
    sheetIndex: int
    x: float
    y: float
    rotationDeg: int
    widthMm: float
    lengthMm: float
    materialCode: str
    thicknessMm: float
    edge: Dict[str,int]



def _sort_key_variant(inst: Instance, variant: str) -> Tuple[float,float,float,str,int]:
    """Deterministic sort keys for multi-pass heuristics."""
    # For consistent orientation, w/h here are original (unrotated) bbox dims.
    w = float(inst.w)
    h = float(inst.h)
    area = w*h
    mx = max(w,h)
    mn = min(w,h)
    gg = str(inst.row.GrainGroup or '').strip()
    # Make grain-group items slightly earlier to reduce fragmentation when enabled.
    gg_flag = 0 if gg else 1
    if variant == 'area_desc':
        return (-area, -mx, -mn, inst.row.PartId, inst.idx)
    if variant == 'max_side_desc':
        return (-mx, -mn, -area, inst.row.PartId, inst.idx)
    if variant == 'height_desc':
        return (-h, -w, -area, inst.row.PartId, inst.idx)
    if variant == 'width_desc':
        return (-w, -h, -area, inst.row.PartId, inst.idx)
    # default
    return (gg_flag, -mx, -mn, -area, inst.row.PartId, inst.idx)


def _item_sort_key(it: dict, variant: str) -> tuple:
    """Return a fully comparable deterministic sort key for both single items and GrainGroup stacks.

    IMPORTANT: All returned tuples have identical length and type layout to avoid
    TypeError during sorting (e.g. float vs str comparisons).
    Layout:
      (kind_flag:int, a:float, b:float, c:float, d:float, group:str, partId:str, idx:int)
    kind_flag: 0=single, 1=group
    """
    if it.get('kind') == 'single':
        inst = it['members'][0]
        w = float(it.get('w', 0.0))
        h = float(it.get('h', 0.0))
        area = w * h
        mn = min(w, h)
        mx = max(w, h)
        tail_part = str(inst.row.PartId)
        tail_idx = int(inst.idx)

        if variant == 'density_first':
            # Step 13: selective small-parts deferral. Keep genuinely tiny fillers and
            # short strips later in the order so medium/large parts can first define
            # the main mass of the sheet. Grain groups are handled separately earlier
            # when grain is enabled, so this only affects ordinary singles.
            micro_flag = 1 if (area <= 120000.0 or mn <= 120.0 or (mx >= 320.0 and mn <= 160.0)) else 0
            slender_flag = 1 if (mn <= 180.0 and mx >= 2.4 * max(1.0, mn)) else 0
            return (0, float(micro_flag), float(slender_flag), -area, -mx, '', tail_part, tail_idx)

        sk = _sort_key_variant(inst, variant)
        # _sort_key_variant may return length 5 or 6 depending on variant/default. Normalize.
        # Extract numeric terms from the front and fill missing with 0.0
        nums = []
        # Collect numeric prefix (int/float) until we hit a non-numeric (PartId)
        for x in sk:
            if isinstance(x, (int, float)):
                nums.append(float(x))
            else:
                break
        while len(nums) < 4:
            nums.append(0.0)
        a,b,c,d = nums[0], nums[1], nums[2], nums[3]
        return (0, a, b, c, d, '', tail_part, tail_idx)
    else:
        # GrainGroup stack
        h = float(it.get('h', 0.0))
        w = float(it.get('w', 0.0))
        group = str(it.get('group',''))
        inst = it['members'][0]
        part = str(inst.row.PartId)
        idx = int(inst.idx)
        if variant == 'density_first':
            # Groups remain early; preserve their stack integrity while still sorting
            # by dominant size so they help shape the main occupied mass first.
            return (1, 0.0, 0.0, -(w * h), -max(w, h), group, part, idx)
        # Use height/width as primary numeric drivers, leave remaining numeric slots as 0.0
        return (1, -h, -w, 0.0, 0.0, group, part, idx)

@dataclass
class _FreeRect:
    x: float
    y: float
    w: float
    h: float

@dataclass
class _PlaceChoice:
    sheet_idx: int
    x: float
    y: float
    w: float
    h: float
    rot: int
    score: Tuple[float, ...]

def _rect_contains(a: _FreeRect, b: _FreeRect) -> bool:
    return (b.x >= a.x and b.y >= a.y and (b.x + b.w) <= (a.x + a.w) and (b.y + b.h) <= (a.y + a.h))

def _split_free_rect(f: _FreeRect, px: float, py: float, pw: float, ph: float) -> List[_FreeRect]:
    """Split a free rect by removing the placed rect area; returns up to 4 rects."""
    out: List[_FreeRect] = []
    fx, fy, fw, fh = f.x, f.y, f.w, f.h
    # No intersection
    if (px >= fx+fw) or (px+pw <= fx) or (py >= fy+fh) or (py+ph <= fy):
        return [f]
    # Left
    if px > fx:
        out.append(_FreeRect(fx, fy, px-fx, fh))
    # Right
    if px+pw < fx+fw:
        out.append(_FreeRect(px+pw, fy, (fx+fw)-(px+pw), fh))
    # Bottom
    if py > fy:
        out.append(_FreeRect(fx, fy, fw, py-fy))
    # Top
    if py+ph < fy+fh:
        out.append(_FreeRect(fx, py+ph, fw, (fy+fh)-(py+ph)))
    # Filter non-positive
    out2 = [r for r in out if r.w > 0.0001 and r.h > 0.0001]
    return out2

def _prune_free_rects(free: List[_FreeRect]) -> List[_FreeRect]:
    """Remove contained rectangles. Deterministic: stable by area desc then x/y."""
    free = sorted(free, key=lambda r: (-(r.w*r.h), r.y, r.x, r.w, r.h))
    kept: List[_FreeRect] = []
    for r in free:
        contained = False
        for k in kept:
            if _rect_contains(k, r):
                contained = True
                break
        if not contained:
            kept.append(r)
    # Deterministic order for placement search
    kept = sorted(kept, key=lambda r: (r.y, r.x, r.w, r.h))
    return kept

def _band_clustering_penalty(existing: List[Tuple[float,float,float,float]], x: float, y: float, w: float, h: float) -> int:
    """Mild deterministic penalty for scattering slim / filler-like parts.

    Prefer when skinny parts form compact bands by sharing an edge and having
    broadly similar span. This nudges small fillers into cleaner zones without
    rewriting the packing algorithm.
    """
    if not existing:
        return 1
    eps = 1e-6
    is_slim = min(w, h) <= 180.0 or max(w, h) / max(1.0, min(w, h)) >= 3.0
    if not is_slim:
        return 0
    aligned_contacts = 0
    near_band = 0
    for ex, ey, ew, eh in existing:
        if abs((x + w) - ex) <= eps or abs((ex + ew) - x) <= eps:
            overlap_h = max(0.0, min(y + h, ey + eh) - max(y, ey))
            if overlap_h >= min(h, eh) * 0.6:
                aligned_contacts += 1
            elif overlap_h >= min(h, eh) * 0.3:
                near_band += 1
        if abs((y + h) - ey) <= eps or abs((ey + eh) - y) <= eps:
            overlap_w = max(0.0, min(x + w, ex + ew) - max(x, ex))
            if overlap_w >= min(w, ew) * 0.6:
                aligned_contacts += 1
            elif overlap_w >= min(w, ew) * 0.3:
                near_band += 1
    if aligned_contacts >= 1:
        return 0
    if near_band >= 1:
        return 1
    return 2

def _edge_cleanup_penalty(fr: _FreeRect, w: float, h: float, usable_w: float, usable_h: float) -> int:
    """Prefer filler-like parts to clean up bottom/right edges, but avoid
    consuming the floor of a tall narrow column when that strands a large empty
    cavity above.
    """
    eps = 1e-6
    is_filler = (w * h) <= 180000.0 or min(w, h) <= 180.0 or max(w, h) / max(1.0, min(w, h)) >= 3.0
    if not is_filler:
        return 0
    leftover_w = max(0.0, fr.w - w)
    leftover_h = max(0.0, fr.h - h)
    touches_bottom = fr.y <= eps
    touches_right = abs((fr.x + fr.w) - usable_w) <= eps and leftover_w <= eps
    penalty = 1
    if touches_bottom or touches_right:
        penalty = 0
    if leftover_w <= eps and leftover_h > max(220.0, 2.5 * h):
        penalty += 2
        if leftover_h > max(420.0, 4.0 * h):
            penalty += 1
    if not touches_bottom and not touches_right and leftover_h > 120.0 and leftover_w > 120.0:
        penalty += 1
    return penalty



def _internal_void_compaction_penalty(existing: List[Tuple[float,float,float,float]], fr: _FreeRect, x: float, y: float, w: float, h: float, usable_w: float, usable_h: float) -> int:
    """Prefer placements that tighten the overall mass and reduce interior air.

    This is a small deterministic nudge, not a rewrite of the packer:
    - reward candidates that sit clearly against existing neighbours
    - discourage isolated placements that leave a floating interior cavity
    - keep the effect modest so earlier exact-fit / sliver / edge heuristics stay dominant
    """
    if not existing:
        return 0
    eps = 1e-6
    # In this packer the reserved cut rectangle enforces a panel gap. A candidate can
    # therefore still be a true neighbour while the raw part edges are roughly one gap
    # apart instead of mathematically touching.
    near_gap = 14.5
    strong_contacts = 0
    weak_contacts = 0
    shared_span_max = 0.0
    for ex, ey, ew, eh in existing:
        # left/right adjacency
        dx = min(abs((x + w) - ex), abs((ex + ew) - x))
        overlap_h = max(0.0, min(y + h, ey + eh) - max(y, ey))
        min_h = max(1.0, min(h, eh))
        if dx <= near_gap:
            if overlap_h >= 0.55 * min_h:
                strong_contacts += 1
                shared_span_max = max(shared_span_max, overlap_h)
            elif overlap_h >= 0.25 * min_h:
                weak_contacts += 1
                shared_span_max = max(shared_span_max, overlap_h)

        # top/bottom adjacency
        dy = min(abs((y + h) - ey), abs((ey + eh) - y))
        overlap_w = max(0.0, min(x + w, ex + ew) - max(x, ex))
        min_w = max(1.0, min(w, ew))
        if dy <= near_gap:
            if overlap_w >= 0.55 * min_w:
                strong_contacts += 1
                shared_span_max = max(shared_span_max, overlap_w)
            elif overlap_w >= 0.25 * min_w:
                weak_contacts += 1
                shared_span_max = max(shared_span_max, overlap_w)

    leftover_w = max(0.0, fr.w - w)
    leftover_h = max(0.0, fr.h - h)
    leaves_2d_cavity = leftover_w > 90.0 and leftover_h > 90.0
    interior_float = (
        x > 80.0 and y > 80.0 and
        (x + w) < (usable_w - 80.0) and
        (y + h) < (usable_h - 80.0)
    )

    penalty = 0
    if strong_contacts >= 2:
        penalty -= 2
    elif strong_contacts >= 1:
        penalty -= 1
    elif weak_contacts >= 2:
        penalty -= 1

    if strong_contacts == 0 and weak_contacts == 0:
        penalty += 2
    elif strong_contacts == 0 and weak_contacts == 1:
        penalty += 1

    if leaves_2d_cavity and strong_contacts == 0:
        penalty += 1
    if interior_float and strong_contacts == 0 and weak_contacts == 0:
        penalty += 1
    if shared_span_max >= 260.0:
        penalty -= 1
    return penalty

def _item_orientation_options(it: Dict[str, Any]) -> List[Tuple[float, float]]:
    w = float(it['w'])
    h = float(it['h'])
    if not bool(it.get('rot_allowed')) or abs(w - h) <= 1e-9:
        return [(w, h)]
    return [(w, h), (h, w)]


def _pair_can_share_sheet(item_a: Dict[str, Any], item_b: Dict[str, Any], usable_w: float, usable_h: float) -> bool:
    """Return True when two items can fit together on one sheet in at least one legal orientation pair.

    For two axis-aligned rectangles inside a bounding rectangle, a feasible non-overlapping packing
    exists iff one can be placed left/right of the other or above/below the other. This makes the
    simple side-by-side / stacked checks exact for a pair.
    """
    for aw, ah in _item_orientation_options(item_a):
        for bw, bh in _item_orientation_options(item_b):
            if max(ah, bh) <= usable_h + 1e-9 and (aw + bw) <= usable_w + 1e-9:
                return True
            if max(aw, bw) <= usable_w + 1e-9 and (ah + bh) <= usable_h + 1e-9:
                return True
    return False


def _greedy_incompatibility_clique_bound(items: List[Dict[str, Any]], usable_w: float, usable_h: float) -> int:
    """Cheap deterministic lower bound from a pairwise incompatibility clique.

    Any set of items that are pairwise unable to share a sheet forms a clique in the
    incompatibility graph and therefore requires at least that many sheets. The greedy
    clique search here is heuristic, but every clique found is a sound lower bound.
    """
    n = len(items)
    if n <= 1:
        return n

    adj: List[Set[int]] = [set() for _ in range(n)]
    degrees = [0] * n
    item_meta = [(float(it['area']), float(it['mx']), float(it['mn'])) for it in items]
    for i in range(n):
        ai = items[i]
        for j in range(i + 1, n):
            if not _pair_can_share_sheet(ai, items[j], usable_w, usable_h):
                adj[i].add(j)
                adj[j].add(i)
                degrees[i] += 1
                degrees[j] += 1

    if max(degrees, default=0) == 0:
        return 1

    def _vertex_sort_key(idx: int) -> Tuple[float, float, float, int]:
        area, mx, mn = item_meta[idx]
        return (-degrees[idx], -area, -mx, idx)

    def _candidate_sort_key(idx: int, candidate_pool: Set[int]) -> Tuple[float, float, float, int]:
        area, mx, mn = item_meta[idx]
        local_degree = sum(1 for other in adj[idx] if other in candidate_pool)
        return (-local_degree, -degrees[idx], -area, idx)

    best = 1
    seeds = sorted(range(n), key=_vertex_sort_key)
    for seed in seeds:
        if degrees[seed] + 1 <= best:
            continue
        clique_size = 1
        candidates = set(adj[seed])
        while candidates:
            nxt = min(candidates, key=lambda idx, pool=candidates: _candidate_sort_key(idx, pool))
            clique_size += 1
            if clique_size > best:
                best = clique_size
            candidates &= adj[nxt]
            if clique_size + len(candidates) <= best:
                break
    return max(1, best)


def _best_choice_for_item(free: List[_FreeRect], iw: float, ih: float, rot_allowed: bool, existing: Optional[List[Tuple[float,float,float,float]]] = None, usable_w: Optional[float] = None, usable_h: Optional[float] = None) -> Optional[Tuple[float,float,int,Tuple[float,float,float,float,float,float,float,float,float,float]]]:
    """Pick best placement in a single sheet's free rect set.

    Heuristic note:
    - still deterministic bottom-left MaxRects
    - gently prefers placements that consume the full width OR full height
      of a free rectangle, because that tends to reduce fragmentation and avoids
      isolated top-right/sliver pockets.
    - also nudges slim filler-like pieces to form compact bands instead of being
      scattered as isolated small islands.
    - for genuinely small filler parts, prefers using a tighter existing gap
      over consuming a very large open zone when both are possible.
    Returns (x,y,rot,score).
    """
    prof = _profiler()
    __t0 = time.perf_counter() if prof else 0.0
    if prof:
        prof.add('best_choice.calls', 1)

    eps = 1e-6
    existing = existing or []
    usable_w_eff_global = usable_w
    usable_h_eff_global = usable_h
    edge_cleanup_fn = _edge_cleanup_penalty
    band_penalty_fn = _band_clustering_penalty
    compaction_penalty_fn = _internal_void_compaction_penalty

    part_area = iw * ih
    min_side_const = iw if iw < ih else ih
    max_side_const = ih if ih > iw else iw
    is_micro_const = (part_area <= 90000.0 or min_side_const <= 120.0)
    is_tall_anchor_const = (max_side_const >= 900.0 or part_area >= 350000.0)
    if not rot_allowed or abs(iw - ih) <= eps:
        rot_variants = ((0, iw, ih),)
    else:
        rot_variants = ((0, iw, ih), (90, ih, iw))

    candidates = []
    best_micro_waste = None
    best_micro_rect_area = None
    best_right_anchor = None

    for fr in free:
        fr_x = fr.x
        fr_y = fr.y
        fr_w = fr.w
        fr_h = fr.h
        fr_area = fr_w * fr_h
        usable_w_eff = usable_w_eff_global if usable_w_eff_global is not None else (fr_x + fr_w)
        usable_h_eff = usable_h_eff_global if usable_h_eff_global is not None else (fr_y + fr_h)

        for rot, w, h in rot_variants:
            if w > fr_w + eps or h > fr_h + eps:
                continue

            leftover_w = fr_w - w
            if leftover_w < 0.0:
                leftover_w = 0.0
            leftover_h = fr_h - h
            if leftover_h < 0.0:
                leftover_h = 0.0
            short_side = leftover_w if leftover_w < leftover_h else leftover_h
            long_side = leftover_h if leftover_h > leftover_w else leftover_w
            split_penalty = int(leftover_w > eps) + int(leftover_h > eps)
            exact_axis_penalty = 0 if (leftover_w <= eps or leftover_h <= eps) else 1

            sliver_penalty = 0
            if leftover_w > eps and leftover_h > eps:
                sliver_ratio = short_side / max(1.0, long_side)
                if short_side < 60.0:
                    sliver_penalty += 2
                elif short_side < 120.0:
                    sliver_penalty += 1
                if sliver_ratio < 0.12:
                    sliver_penalty += 2
                elif sliver_ratio < 0.20:
                    sliver_penalty += 1

            edge_cleanup_penalty = edge_cleanup_fn(fr, w, h, usable_w_eff, usable_h_eff)
            band_penalty = band_penalty_fn(existing, fr_x, fr_y, w, h)
            waste_area = fr_area - part_area
            if waste_area < 0.0:
                waste_area = 0.0
            right_gap_eff = usable_w_eff - (fr_x + w)
            if right_gap_eff < 0.0:
                right_gap_eff = 0.0
            top_gap_eff = usable_h_eff - (fr_y + h)
            if top_gap_eff < 0.0:
                top_gap_eff = 0.0
            touches_right_eff = right_gap_eff <= eps
            touches_top_eff = top_gap_eff <= eps
            fill_ratio_eff = part_area / max(1.0, fr_area)
            area_delta_eff = 0.0
            near_exact_hole_eff = False
            if is_micro_const and best_micro_rect_area is not None:
                area_delta_eff = fr_area - best_micro_rect_area
                near_exact_hole_eff = (short_side <= 26.0) or (exact_axis_penalty == 0)

            candidates.append((
                fr, fr_x, fr_y, rot, w, h,
                split_penalty, exact_axis_penalty, sliver_penalty,
                edge_cleanup_penalty, band_penalty,
                short_side, long_side,
                waste_area, fr_area, usable_w_eff, usable_h_eff,
                right_gap_eff, top_gap_eff, touches_right_eff, touches_top_eff,
                fill_ratio_eff, area_delta_eff, near_exact_hole_eff,
            ))

            if is_micro_const:
                if best_micro_waste is None or waste_area < best_micro_waste:
                    best_micro_waste = waste_area
                if best_micro_rect_area is None or fr_area < best_micro_rect_area:
                    best_micro_rect_area = fr_area
            if is_tall_anchor_const:
                right_gap_anchor = usable_w_eff - (fr_x + w)
                if right_gap_anchor < 0.0:
                    right_gap_anchor = -right_gap_anchor
                right_anchor = (right_gap_anchor, fr_y, short_side, long_side)
                if best_right_anchor is None or right_anchor < best_right_anchor:
                    best_right_anchor = right_anchor

    if not candidates:
        return None

    best = None
    usable_w_is_not_none = usable_w is not None

    for fr, fr_x, fr_y, rot, w, h, split_penalty, exact_axis_penalty, sliver_penalty, edge_cleanup_penalty, band_penalty, short_side, long_side, waste_area, fr_area, usable_w_eff, usable_h_eff, right_gap_eff, top_gap_eff, touches_right_eff, touches_top_eff, fill_ratio_eff, area_delta_eff, near_exact_hole_eff in candidates:
        micro_gap_penalty = 0
        if is_micro_const and best_micro_waste is not None:
            fill_ratio = fill_ratio_eff
            waste_delta = waste_area - best_micro_waste
            if waste_delta > 180000.0:
                micro_gap_penalty += 2
            elif waste_delta > 60000.0:
                micro_gap_penalty += 1
            if fill_ratio < 0.45:
                micro_gap_penalty += 1
            if fill_ratio < 0.25:
                micro_gap_penalty += 1

            if best_micro_rect_area is not None:
                area_delta = area_delta_eff
                near_exact_hole = near_exact_hole_eff
                if area_delta > 180000.0:
                    micro_gap_penalty += 4
                elif area_delta > 90000.0:
                    micro_gap_penalty += 3
                elif area_delta > 30000.0:
                    micro_gap_penalty += 2
                elif area_delta > 10000.0:
                    micro_gap_penalty += 1
                if not near_exact_hole and fill_ratio < 0.60:
                    micro_gap_penalty += 1
                if not near_exact_hole and fill_ratio < 0.40:
                    micro_gap_penalty += 1
                if near_exact_hole and area_delta <= 30000.0:
                    micro_gap_penalty = max(0, micro_gap_penalty - 2)

        right_anchor_penalty = 0
        if is_tall_anchor_const and usable_w_is_not_none and best_right_anchor is not None:
            right_gap = right_gap_eff
            touches_right = touches_right_eff
            touches_bottom = fr_y <= 1e-6
            if not touches_right:
                if right_gap > 220.0:
                    right_anchor_penalty += 2
                elif right_gap > 80.0:
                    right_anchor_penalty += 1
            if not touches_bottom and fr_y > 220.0:
                right_anchor_penalty += 1
            best_gap, best_y, _, _ = best_right_anchor
            if right_gap - best_gap > 120.0:
                right_anchor_penalty += 1
            if fr_y - best_y > 180.0:
                right_anchor_penalty += 1
            if touches_right:
                right_anchor_penalty = max(0, right_anchor_penalty - 2)
            if touches_right and touches_bottom:
                right_anchor_penalty = max(0, right_anchor_penalty - 1)

        topband_penalty = 0
        right_gap = right_gap_eff
        top_gap = top_gap_eff
        touches_right = touches_right_eff
        touches_top = touches_top_eff
        is_horizontal_strip = (
            w >= max(320.0, 1.8 * h)
            and h <= 220.0
            and part_area <= 260000.0
        )
        if is_horizontal_strip and top_gap <= max(140.0, 1.35 * h):
            topband_penalty += 1
            if top_gap <= max(60.0, 0.75 * h):
                topband_penalty += 1
            if right_gap > 120.0:
                topband_penalty += 1
            if fr_x < (0.72 * usable_w_eff):
                topband_penalty += 1
            if exact_axis_penalty != 0 and short_side > 18.0:
                topband_penalty += 1
            if touches_right and touches_top:
                topband_penalty = max(0, topband_penalty - 3)
            elif touches_right and right_gap <= 40.0:
                topband_penalty = max(0, topband_penalty - 2)
            elif exact_axis_penalty == 0 and right_gap <= 80.0:
                topband_penalty = max(0, topband_penalty - 1)

        compaction_penalty = compaction_penalty_fn(existing, fr, fr_x, fr_y, w, h, usable_w_eff, usable_h_eff)
        score = (
            split_penalty,
            exact_axis_penalty,
            sliver_penalty,
            edge_cleanup_penalty,
            band_penalty,
            micro_gap_penalty,
            right_anchor_penalty,
            topband_penalty,
            compaction_penalty,
            short_side,
            long_side,
            fr_y,
            fr_x,
        )
        cand = (fr_x, fr_y, rot, score)
        if best is None or cand[3] < best[3]:
            best = cand

    if prof:
        prof.add('best_choice.candidates_considered', len(candidates))
        prof.add('best_choice.seconds_total', max(0.0, time.perf_counter() - __t0))
    return best
def _packing_equivalence_key(item: Dict[str,Any]) -> Tuple[Any,...]:
    """Return the complete geometry/scoring identity of one pending pack item."""
    return (
        str(item.get('kind') or ''),
        float(item.get('w') or 0.0),
        float(item.get('h') or 0.0),
        bool(item.get('rot_allowed')),
        float(item.get('area') or 0.0),
        float(item.get('mn') or 0.0),
        float(item.get('mx') or 0.0),
        int(item.get('micro_flag') or 0),
    )


def _homogeneous_grid_candidate(items: List[Dict[str,Any]], sheet_w: float, sheet_h: float, margin: float, gap: float) -> Optional[Tuple[List[Placement],int,int,Dict[str,Any]]]:
    """Build a deterministic compact grid for equal single panels.

    MaxRects is still allowed to improve this upper bound. This candidate fixes the
    common 100–250 identical-front case where scoring could create an unnecessary
    spill sheet despite a simple legal regular grid being available.
    """
    if not items or not all(str(it.get('kind') or '') == 'single' for it in items):
        return None
    first_key = _packing_equivalence_key(items[0])
    if not all(_packing_equivalence_key(it) == first_key for it in items):
        return None
    usable_w = float(sheet_w) - 2.0 * float(margin)
    usable_h = float(sheet_h) - 2.0 * float(margin)
    w0 = float(items[0]['w'])
    h0 = float(items[0]['h'])
    orientations = [(w0, h0, 0)]
    if bool(items[0].get('rot_allowed')) and abs(w0 - h0) > 1e-9:
        orientations.append((h0, w0, 90))
    pattern_choices: List[Tuple[int,int,Tuple[int,...],List[Tuple[float,float,int]]]] = []

    # Vertical bands: each band is one panel wide and packs as many panels as
    # possible over sheet height. Enumerating both orientation counts also captures
    # productive mixed layouts such as 3 normal + 2 rotated columns.
    max_vertical = [int(math.floor((usable_w + gap + 1e-9) / (ow + gap))) for ow, _oh, _rot in orientations]
    vertical_ranges = [range(value + 1) for value in max_vertical]
    for counts in itertools.product(*vertical_ranges):
        band_count = sum(counts)
        if band_count <= 0:
            continue
        used_w = sum(count * orientations[index][0] for index, count in enumerate(counts)) + gap * (band_count - 1)
        if used_w > usable_w + 1e-9:
            continue
        slots: List[Tuple[float,float,int]] = []
        x_cursor = 0.0
        for index, count in enumerate(counts):
            placed_w, placed_h, rotation = orientations[index]
            rows = int(math.floor((usable_h + gap + 1e-9) / (placed_h + gap)))
            for _column in range(count):
                for row in range(rows):
                    slots.append((x_cursor, row * (placed_h + gap), rotation))
                x_cursor += placed_w + gap
        pattern_choices.append((len(slots), 1, tuple(int(x) for x in counts), slots))

    # Horizontal bands are the transposed counterpart and can win on other sheet
    # aspect ratios. The same deterministic tie-break keeps output byte-stable.
    max_horizontal = [int(math.floor((usable_h + gap + 1e-9) / (oh + gap))) for _ow, oh, _rot in orientations]
    horizontal_ranges = [range(value + 1) for value in max_horizontal]
    for counts in itertools.product(*horizontal_ranges):
        band_count = sum(counts)
        if band_count <= 0:
            continue
        used_h = sum(count * orientations[index][1] for index, count in enumerate(counts)) + gap * (band_count - 1)
        if used_h > usable_h + 1e-9:
            continue
        slots = []
        y_cursor = 0.0
        for index, count in enumerate(counts):
            placed_w, placed_h, rotation = orientations[index]
            cols = int(math.floor((usable_w + gap + 1e-9) / (placed_w + gap)))
            for _row in range(count):
                for col in range(cols):
                    slots.append((col * (placed_w + gap), y_cursor, rotation))
                y_cursor += placed_h + gap
        pattern_choices.append((len(slots), 0, tuple(int(x) for x in counts), slots))

    if not pattern_choices:
        return None
    capacity, axis_tie, counts, slots = max(pattern_choices, key=lambda row: (row[0], row[1], tuple(-x for x in row[2])))
    if capacity <= 0:
        return None
    placements: List[Placement] = []
    for index, item in enumerate(items):
        sheet_index = index // capacity + 1
        slot = index % capacity
        slot_x, slot_y, rotation = slots[slot]
        inst: Instance = item['members'][0]
        placements.append(Placement(
            partId=inst.row.PartId,
            instanceIndex=inst.idx,
            sheetIndex=sheet_index,
            x=round01(float(margin) + slot_x),
            y=round01(float(margin) + slot_y),
            rotationDeg=int(rotation),
            widthMm=float(inst.row.WidthMm),
            lengthMm=float(inst.row.LengthMm),
            materialCode=inst.row.MaterialCode,
            thicknessMm=float(inst.row.ThicknessMm),
            edge={'H1':inst.row.H1,'H2':inst.row.H2,'W1':inst.row.W1,'W2':inst.row.W2},
        ))
    sheets_used = max((p.sheetIndex for p in placements), default=1)
    return placements, int(sheets_used), int(capacity), {
        'axis': 'vertical' if axis_tie == 1 else 'horizontal',
        'orientationCounts': list(counts),
        'rotationsUsed': sorted({int(slot[2]) for slot in slots}),
    }


def _maxrects_pack_k(items: List[Dict[str,Any]], sheet_w: float, sheet_h: float, margin: float, gap: float, k: int, report: Dict[str,Any], progress_cb=None) -> Optional[List[Placement]]:
    """Attempt to pack all items into at most k sheets using MaxRects (deterministic greedy).

    Step 14 (safe version): exhaust the current / earlier sheets as much as possible
    before spilling into a new one. Unlike the failed earlier rewrite, this keeps the
    proven MaxRects mechanics intact and only adds a controlled pending-pool selection
    layer around them.
    """
    usable_w = sheet_w - 2*margin
    usable_h = sheet_h - 2*margin
    if usable_w <= 0 or usable_h <= 0:
        fatal(report, 'Sheet usable area is non-positive; check margin/sheet size.')
    sheets_free: List[List[_FreeRect]] = [[_FreeRect(0.0, 0.0, usable_w, usable_h)]]
    sheet_existing: List[List[Tuple[float,float,float,float]]] = [[]]
    sheet_used_area: List[float] = [0.0]
    placements: List[Placement] = []
    pending: List[Dict[str,Any]] = list(items)
    prof = _profiler()
    if prof:
        prof.event('pack_k.start', itemCount=len(items), k=int(k), sheetW=sheet_w, sheetH=sheet_h)
    total_items = max(1, len(pending))
    report_stride = max(1, total_items // 80)
    last_report_done = -1
    sheet_area = max(1.0, usable_w * usable_h)

    def _emit_attempt_progress(message: str = 'Nestings berekenen…', force: bool = False) -> None:
        nonlocal last_report_done
        if not callable(progress_cb):
            return
        done = total_items - len(pending)
        if (not force) and done != total_items and done > 0 and done - last_report_done < report_stride:
            return
        if done == last_report_done and not force:
            return
        try:
            frac = max(0.0, min(1.0, float(done) / float(total_items)))
            progress_cb(frac, message)
            last_report_done = done
        except Exception:
            pass

    def _density_bucket(sheet_idx: int) -> int:
        used_ratio = sheet_used_area[sheet_idx] / sheet_area
        bucket = 0
        if used_ratio < 0.90:
            bucket += 1
        if used_ratio < 0.75:
            bucket += 1
        if used_ratio < 0.55:
            bucket += 1
        if used_ratio < 0.35:
            bucket += 1
        return bucket

    def _commit(item: Dict[str,Any], choice: _PlaceChoice) -> None:
        cut_x1 = max(0.0, choice.x - gap)
        cut_y1 = max(0.0, choice.y - gap)
        cut_x2 = min(usable_w, choice.x + choice.w + gap)
        cut_y2 = min(usable_h, choice.y + choice.h + gap)
        cut_w = max(0.0, cut_x2 - cut_x1)
        cut_h = max(0.0, cut_y2 - cut_y1)

        free = sheets_free[choice.sheet_idx - 1]
        new_free: List[_FreeRect] = []
        for fr in free:
            new_free.extend(_split_free_rect(fr, cut_x1, cut_y1, cut_w, cut_h))
        sheets_free[choice.sheet_idx - 1] = _prune_free_rects(new_free)

        base_x = round01(margin + choice.x)
        base_y = round01(margin + choice.y)

        if item['kind'] == 'single':
            inst: Instance = item['members'][0]
            placements.append(Placement(
                partId=inst.row.PartId,
                instanceIndex=inst.idx,
                sheetIndex=choice.sheet_idx,
                x=base_x,
                y=base_y,
                rotationDeg=int(choice.rot),
                widthMm=float(inst.row.WidthMm),
                lengthMm=float(inst.row.LengthMm),
                materialCode=inst.row.MaterialCode,
                thicknessMm=float(inst.row.ThicknessMm),
                edge={'H1':inst.row.H1,'H2':inst.row.H2,'W1':inst.row.W1,'W2':inst.row.W2},
            ))
            sheet_existing[choice.sheet_idx - 1].append((choice.x, choice.y, choice.w, choice.h))
            sheet_used_area[choice.sheet_idx - 1] += choice.w * choice.h
        else:
            # Canonical production contract: GrainGroup position 1 is the physical
            # bottom panel.  Therefore the first semantic member starts at the lowest
            # Y and subsequent positions increase upward.
            y_cursor = 0.0
            for mi, inst in enumerate(item['members']):
                px = base_x
                py = round01(margin + choice.y + y_cursor)
                placements.append(Placement(
                    partId=inst.row.PartId,
                    instanceIndex=inst.idx,
                    sheetIndex=choice.sheet_idx,
                    x=px,
                    y=py,
                    rotationDeg=0,
                    widthMm=float(inst.row.WidthMm),
                    lengthMm=float(inst.row.LengthMm),
                    materialCode=inst.row.MaterialCode,
                    thicknessMm=float(inst.row.ThicknessMm),
                    edge={'H1':inst.row.H1,'H2':inst.row.H2,'W1':inst.row.W1,'W2':inst.row.W2},
                ))
                if mi == 0:
                    sheet_existing[choice.sheet_idx - 1].append((choice.x, choice.y, choice.w, choice.h))
                y_cursor += float(inst.h)
                if mi < len(item['members'])-1:
                    y_cursor += gap
            sheet_used_area[choice.sheet_idx - 1] += choice.w * choice.h

    _emit_attempt_progress('Nestings berekenen…', force=True)

    iteration = 0
    while pending:
        iteration += 1
        __iter_t0 = time.perf_counter() if prof else 0.0
        if prof and (iteration <= 5 or iteration % 25 == 0 or len(pending) <= 5):
            prof.event('pack_k.iteration', iteration=iteration, pending=len(pending), openSheets=len(sheets_free), placed=(total_items-len(pending)))
        best_pending_idx: Optional[int] = None
        best_choice: Optional[_PlaceChoice] = None
        best_composite: Optional[Tuple[float, ...]] = None

        # First, try to fit ANY remaining item on the already-open sheets.
        evaluated_keys: Set[Tuple[Any,...]] = set()
        for pi, item in enumerate(pending):
            item_key = _packing_equivalence_key(item)
            if item_key in evaluated_keys:
                if prof:
                    prof.add('pack_k.equivalent_pending_evaluations_skipped', 1)
                continue
            evaluated_keys.add(item_key)
            if prof:
                prof.add('pack_k.pending_items_scanned', 1)
            iw = item['w']
            ih = item['h']
            rot_allowed = item['rot_allowed']
            item_area = item['area']
            item_mn = item['mn']
            item_mx = item['mx']
            micro_flag = item['micro_flag']
            for si, free in enumerate(sheets_free, start=1):
                if prof:
                    prof.add('pack_k.sheet_choice_checks', 1)
                choice = _best_choice_for_item(free, iw, ih, rot_allowed, sheet_existing[si-1], usable_w, usable_h)
                if choice is None:
                    continue
                x, y, rot, score = choice
                placed_w = (iw if rot==0 else ih)
                placed_h = (ih if rot==0 else iw)
                pc = _PlaceChoice(sheet_idx=si, x=x, y=y, w=placed_w, h=placed_h, rot=rot, score=score)
                # Step 15: on spill sheets (sheet 2+), prefer long/tall anchor parts to
                # keep building from the right edge as well, so the follow-on sheets do
                # not start with a loose central block while the right contour stays open.
                spill_right_anchor_penalty = 0
                if si > 1 and (max(placed_w, placed_h) >= 900.0 or (placed_w * placed_h) >= 350000.0):
                    right_gap = abs((x + placed_w) - usable_w)
                    touches_right = right_gap <= 1e-6
                    touches_bottom = y <= 1e-6
                    if not touches_right:
                        if right_gap > 220.0:
                            spill_right_anchor_penalty += 3
                        elif right_gap > 100.0:
                            spill_right_anchor_penalty += 2
                        elif right_gap > 40.0:
                            spill_right_anchor_penalty += 1
                    if not touches_bottom and y > 220.0:
                        spill_right_anchor_penalty += 1
                    if touches_right:
                        spill_right_anchor_penalty = max(0, spill_right_anchor_penalty - 2)
                    if touches_right and touches_bottom:
                        spill_right_anchor_penalty = max(0, spill_right_anchor_penalty - 1)
                # Step 17: last-sheet cleanup. Keep the early sheets exactly as they are,
                # but make the currently last-open spill sheet (which often becomes the
                # final sheet) build in a calmer, more right/bottom-anchored way.
                #
                # This is intentionally soft: it nudges long parts toward the right/bottom
                # edge on the active last sheet, and delays tiny crumbs there a little,
                # without changing the strong 'fill earlier sheets first' behavior.
                last_sheet_cleanup_penalty = 0
                if si > 1 and si == len(sheets_free):
                    right_gap = abs((x + placed_w) - usable_w)
                    touches_right = right_gap <= 1e-6
                    touches_bottom = y <= 1e-6
                    long_anchor_flag = (item_mx >= 700.0 or item_area >= 260000.0)

                    if long_anchor_flag:
                        if not touches_right:
                            if right_gap > 260.0:
                                last_sheet_cleanup_penalty += 4
                            elif right_gap > 140.0:
                                last_sheet_cleanup_penalty += 3
                            elif right_gap > 60.0:
                                last_sheet_cleanup_penalty += 2
                            elif right_gap > 20.0:
                                last_sheet_cleanup_penalty += 1
                        if not touches_bottom and y > 220.0:
                            last_sheet_cleanup_penalty += 1
                        if touches_right:
                            last_sheet_cleanup_penalty = max(0, last_sheet_cleanup_penalty - 2)
                        if touches_right and touches_bottom:
                            last_sheet_cleanup_penalty = max(0, last_sheet_cleanup_penalty - 1)
                    else:
                        # Delay tiny crumb placement on the active last sheet a bit so
                        # larger anchor parts can set the structure first.
                        if micro_flag:
                            last_sheet_cleanup_penalty += 2
                        elif item_area < 220000.0 and item_mx < 650.0:
                            last_sheet_cleanup_penalty += 1
                composite = (
                    si - 1,
                    _density_bucket(si - 1),
                    spill_right_anchor_penalty,
                    last_sheet_cleanup_penalty,
                    micro_flag,
                    -item_area,
                    -item_mx,
                    -item_mn,
                ) + pc.score + (float(pi),)
                if best_composite is None or composite < best_composite:
                    best_composite = composite
                    best_pending_idx = pi
                    best_choice = pc

        if best_pending_idx is not None and best_choice is not None:
            item = pending.pop(best_pending_idx)
            _commit(item, best_choice)
            _emit_attempt_progress('Nestings berekenen…')
            continue

        # Nothing else fits on the already-open sheets, so only now may we open a new one.
        if len(sheets_free) >= k:
            return None
        sheets_free.append([_FreeRect(0.0, 0.0, usable_w, usable_h)])
        sheet_existing.append([])
        sheet_used_area.append(0.0)

        new_sheet_idx = len(sheets_free)
        anchor_idx: Optional[int] = None
        anchor_choice: Optional[_PlaceChoice] = None
        anchor_composite: Optional[Tuple[float, ...]] = None
        evaluated_anchor_keys: Set[Tuple[Any,...]] = set()
        for pi, item in enumerate(pending):
            item_key = _packing_equivalence_key(item)
            if item_key in evaluated_anchor_keys:
                if prof:
                    prof.add('pack_k.equivalent_anchor_evaluations_skipped', 1)
                continue
            evaluated_anchor_keys.add(item_key)
            iw = item['w']
            ih = item['h']
            rot_allowed = item['rot_allowed']
            choice = _best_choice_for_item(sheets_free[-1], iw, ih, rot_allowed, sheet_existing[-1], usable_w, usable_h)
            if choice is None:
                continue
            x, y, rot, score = choice
            placed_w = (iw if rot == 0 else ih)
            placed_h = (ih if rot == 0 else iw)
            area = item['area']
            mn = item['mn']
            mx = item['mx']
            micro_flag = item['micro_flag']
            anchor_penalty = 0
            right_gap = abs((x + placed_w) - usable_w)
            touches_right = right_gap <= 1e-6
            touches_bottom = y <= 1e-6
            if not touches_right:
                if right_gap > 220.0:
                    anchor_penalty += 3
                elif right_gap > 100.0:
                    anchor_penalty += 2
                elif right_gap > 40.0:
                    anchor_penalty += 1
            if not touches_bottom and y > 180.0:
                anchor_penalty += 1
            if touches_right:
                anchor_penalty = max(0, anchor_penalty - 2)
            if touches_right and touches_bottom:
                anchor_penalty = max(0, anchor_penalty - 1)
            # Step 17: when a spill sheet is opened, start it with a calmer
            # right/bottom anchor if possible, especially for long parts.
            startup_cleanup_penalty = 0
            if new_sheet_idx > 1:
                if not touches_right:
                    if right_gap > 260.0:
                        startup_cleanup_penalty += 3
                    elif right_gap > 120.0:
                        startup_cleanup_penalty += 2
                    elif right_gap > 40.0:
                        startup_cleanup_penalty += 1
                if not touches_bottom and y > 220.0:
                    startup_cleanup_penalty += 1
                if micro_flag:
                    startup_cleanup_penalty += 2
                if touches_right:
                    startup_cleanup_penalty = max(0, startup_cleanup_penalty - 2)
                if touches_right and touches_bottom:
                    startup_cleanup_penalty = max(0, startup_cleanup_penalty - 1)
            composite = (
                micro_flag,
                anchor_penalty,
                startup_cleanup_penalty,
                -area,
                -mx,
            ) + score + (float(pi),)
            if anchor_composite is None or composite < anchor_composite:
                anchor_composite = composite
                anchor_idx = pi
                anchor_choice = _PlaceChoice(sheet_idx=new_sheet_idx, x=x, y=y, w=placed_w, h=placed_h, rot=rot, score=composite)

        if anchor_idx is None or anchor_choice is None:
            return None
        item = pending.pop(anchor_idx)
        _commit(item, anchor_choice)
        _emit_attempt_progress('Nestings berekenen…')

    _emit_attempt_progress('Nestings berekenen…', force=True)
    return placements



def _placement_bbox_usable(p: Placement, margin: float) -> Tuple[float,float,float,float]:
    """Return placement bbox in usable-sheet coordinates (margin removed)."""
    if int(p.rotationDeg) == 90:
        w = float(p.lengthMm)
        h = float(p.widthMm)
    else:
        w = float(p.widthMm)
        h = float(p.lengthMm)
    return (float(p.x) - margin, float(p.y) - margin, w, h)


def _rebuild_free_rects_for_sheet(sheet_placements: List[Placement], sheet_w: float, sheet_h: float, margin: float, gap: float, exclude_local_index: Optional[int] = None) -> Tuple[List[_FreeRect], List[Tuple[float,float,float,float]]]:
    usable_w = sheet_w - 2*margin
    usable_h = sheet_h - 2*margin
    free: List[_FreeRect] = [_FreeRect(0.0, 0.0, usable_w, usable_h)]
    existing: List[Tuple[float,float,float,float]] = []
    for li, p in enumerate(sheet_placements):
        if exclude_local_index is not None and li == exclude_local_index:
            continue
        x, y, w, h = _placement_bbox_usable(p, margin)
        existing.append((x, y, w, h))
        cut_x1 = max(0.0, x - gap)
        cut_y1 = max(0.0, y - gap)
        cut_x2 = min(usable_w, x + w + gap)
        cut_y2 = min(usable_h, y + h + gap)
        cut_w = max(0.0, cut_x2 - cut_x1)
        cut_h = max(0.0, cut_y2 - cut_y1)
        new_free: List[_FreeRect] = []
        for fr in free:
            new_free.extend(_split_free_rect(fr, cut_x1, cut_y1, cut_w, cut_h))
        free = _prune_free_rects(new_free)
    return free, existing


def _postpass_repack_micro_fillers(placements: List[Placement], sheet_w: float, sheet_h: float, margin: float, gap: float) -> None:
    """Local same-sheet tidy-up for genuinely small filler parts.

    After the main greedy packing, very small parts may still sit in larger open
    zones while tiny fitted holes exist elsewhere. This post-pass removes one
    micro part at a time, rebuilds sheet free-rects against the fixed remainder,
    and asks the existing scorer for the best same-orientation spot. Only actual
    moves are applied, so the main algorithm remains intact and deterministic.
    """
    by_sheet: Dict[int, List[int]] = {}
    for gi, p in enumerate(placements):
        by_sheet.setdefault(int(p.sheetIndex), []).append(gi)

    for sheet_idx, global_indices in by_sheet.items():
        if len(global_indices) < 2:
            continue
        local_pls = [placements[gi] for gi in global_indices]

        def _is_micro_candidate(p: Placement) -> bool:
            x, y, w, h = _placement_bbox_usable(p, margin)
            area = w * h
            mn = min(w, h)
            mx = max(w, h)
            # Step 8: slightly broaden the local tidy-up pool so small strips,
            # narrow drawer parts and other filler-like pieces get another chance
            # to move into tighter holes instead of remaining clustered in a loose
            # secondary zone.
            return area <= 120000.0 or mn <= 140.0 or (mn <= 180.0 and mx <= 500.0)

        candidate_order = [li for li, p in enumerate(local_pls) if _is_micro_candidate(p)]
        candidate_order.sort(key=lambda li: (_placement_bbox_usable(local_pls[li], margin)[2] * _placement_bbox_usable(local_pls[li], margin)[3], local_pls[li].y, local_pls[li].x))

        for _pass in range(4):
            moved_any = False
            for li in candidate_order:
                p = local_pls[li]
                x0, y0, w, h = _placement_bbox_usable(p, margin)
                free, existing = _rebuild_free_rects_for_sheet(local_pls, sheet_w, sheet_h, margin, gap, exclude_local_index=li)
                choice = _best_choice_for_item(free, w, h, False, existing, sheet_w - 2*margin, sheet_h - 2*margin)
                if choice is None:
                    continue
                nx, ny, rot, score = choice
                if abs(nx - x0) <= 1e-6 and abs(ny - y0) <= 1e-6:
                    continue
                # Additional guard: only move if the chosen free rect is materially
                # tighter than the current host zone, or if it cleans to an edge.
                current_free, _ = _rebuild_free_rects_for_sheet(local_pls, sheet_w, sheet_h, margin, gap, exclude_local_index=li)
                # Estimate best current host rect by containment after removal.
                current_host_area = None
                for fr in current_free:
                    if x0 >= fr.x - 1e-6 and y0 >= fr.y - 1e-6 and x0 + w <= fr.x + fr.w + 1e-6 and y0 + h <= fr.y + fr.h + 1e-6:
                        a = fr.w * fr.h
                        if current_host_area is None or a < current_host_area:
                            current_host_area = a
                target_host_area = None
                for fr in free:
                    if nx >= fr.x - 1e-6 and ny >= fr.y - 1e-6 and nx + w <= fr.x + fr.w + 1e-6 and ny + h <= fr.y + fr.h + 1e-6:
                        a = fr.w * fr.h
                        if target_host_area is None or a < target_host_area:
                            target_host_area = a
                improves_tightness = (current_host_area is not None and target_host_area is not None and target_host_area + 5000.0 < current_host_area)
                touches_edge = ny <= 1e-6 or abs((nx + w) - (sheet_w - 2*margin)) <= 1e-6
                current_fill_ratio = None
                target_fill_ratio = None
                part_area = w * h
                if current_host_area and current_host_area > 0:
                    current_fill_ratio = part_area / current_host_area
                if target_host_area and target_host_area > 0:
                    target_fill_ratio = part_area / target_host_area
                improves_fill_ratio = (
                    current_fill_ratio is not None and target_fill_ratio is not None and
                    target_fill_ratio > current_fill_ratio + 0.12
                )
                strongly_better_hole = (
                    target_host_area is not None and current_host_area is not None and
                    target_host_area <= part_area * 2.6 and current_host_area >= part_area * 4.0
                )
                if not improves_tightness and not improves_fill_ratio and not strongly_better_hole and not touches_edge:
                    continue
                p.x = round01(margin + nx)
                p.y = round01(margin + ny)
                moved_any = True
            if not moved_any:
                break

def pack_maxrects_optimal(insts: List[Instance], sheet_w: float, sheet_h: float, margin: float, gap: float, grain_enabled: bool, report: Dict[str,Any], progress_cb=None) -> Tuple[List[Placement], int]:
    """Deterministic multi-pass MaxRects packing with explicit primary objective: minimize sheet count."""
    usable_w = sheet_w - 2*margin
    usable_h = sheet_h - 2*margin
    if usable_w <= 0 or usable_h <= 0:
        fatal(report, 'Sheet usable area is non-positive; check margin/sheet size.')

    prof = _profiler()
    if prof:
        prof.event('pack_optimal.start', instances=len(insts), sheetW=sheet_w, sheetH=sheet_h, grainEnabled=bool(grain_enabled))
    # Build items: singles or GrainGroup composites (when grain enabled)
    items: List[Dict[str,Any]] = []
    if grain_enabled:
        # groups map: group_id -> list of (pos_index, seq_index, Instance)
        groups: Dict[str, List[Tuple[Optional[int], int, Instance]]] = {}
        singles: List[Instance] = []
        seq = 0
        for inst in insts:
            seq += 1
            gg_raw = str(inst.row.GrainGroup or '').strip()
            if gg_raw:
                # Tool A may encode order as "G01:1" where ":<n>" is the member order in the UI.
                # Contract: group membership is determined by the group id; member order must follow the UI order.
                gg_id = gg_raw
                pos_idx: Optional[int] = None
                if ':' in gg_raw:
                    gg_id, tail = gg_raw.split(':', 1)
                    gg_id = gg_id.strip()
                    tail = tail.strip()
                    if tail.isdigit():
                        pos_idx = int(tail)
                groups.setdefault(gg_id, []).append((pos_idx, seq, inst))
            else:
                singles.append(inst)
        # IMPORTANT (contract): preserve EXACT member order as provided by Tool A.
        # If Tool A provided explicit member indices (":<n>"), use them; otherwise preserve CSV order.
        for gg in sorted(groups.keys()):
            triples = groups[gg]
            # If every member has an explicit pos_idx, sort by it; otherwise keep insertion order (seq).
            if all(t[0] is not None for t in triples):
                triples_sorted = sorted(triples, key=lambda t: (t[0], t[1]))
            else:
                triples_sorted = sorted(triples, key=lambda t: t[1])
            members = [t[2] for t in triples_sorted]
            widths = {round(float(m.w), 1) for m in members}
            if len(widths) != 1:
                fatal(report, f"GrainGroup '{gg}' contains mixed WidthMm values: {sorted(widths)}")
            gw = float(members[0].w)
            gh = sum(float(m.h) for m in members) + gap*max(0, len(members)-1)
            if gh > usable_h + 1e-6 or gw > usable_w + 1e-6:
                fatal(report, f"GrainGroup '{gg}' does not fit on sheet usable area (w={gw}, h={gh}).")
            items.append({'kind':'group','group':gg,'members':members,'w':gw,'h':gh,'rot_allowed':False,'area':gw*gh,'mn':min(gw,gh),'mx':max(gw,gh),'micro_flag':1 if (gw*gh <= 120000.0 or min(gw,gh) <= 120.0 or (max(gw,gh) >= 320.0 and min(gw,gh) <= 160.0)) else 0})
        for inst in singles:
            items.append({'kind':'single','members':[inst],'w':float(inst.w),'h':float(inst.h),'rot_allowed':bool(inst.rot_allowed),'area':float(inst.w)*float(inst.h),'mn':min(float(inst.w), float(inst.h)),'mx':max(float(inst.w), float(inst.h)),'micro_flag':1 if ((float(inst.w)*float(inst.h)) <= 120000.0 or min(float(inst.w), float(inst.h)) <= 120.0 or (max(float(inst.w), float(inst.h)) >= 320.0 and min(float(inst.w), float(inst.h)) <= 160.0)) else 0})
    else:
        # grain disabled: ignore GrainGroup entirely, all are singles
        for inst in insts:
            items.append({'kind':'single','members':[inst],'w':float(inst.w),'h':float(inst.h),'rot_allowed':bool(inst.rot_allowed),'area':float(inst.w)*float(inst.h),'mn':min(float(inst.w), float(inst.h)),'mx':max(float(inst.w), float(inst.h)),'micro_flag':1 if ((float(inst.w)*float(inst.h)) <= 120000.0 or min(float(inst.w), float(inst.h)) <= 120.0 or (max(float(inst.w), float(inst.h)) >= 320.0 and min(float(inst.w), float(inst.h)) <= 160.0)) else 0})

    total_area = sum(float(it['w'])*float(it['h']) for it in items)
    if prof:
        prof.set_meta(instanceCount=len(insts), itemCount=len(items), grainEnabled=bool(grain_enabled))
        prof.event('pack_optimal.items_built', itemCount=len(items), lowerBound=None)
    usable_area = usable_w*usable_h
    area_lb = max(1, int(math.ceil(total_area/usable_area - 1e-12)))
    clique_lb = _greedy_incompatibility_clique_bound(items, usable_w, usable_h)
    # FIX656: exact lower bound for the very common production case of many equal,
    # non-rotatable fronts. For identical axis-aligned rectangles the maximum count per
    # sheet is the regular grid capacity; adding one gap to both container/item pitch is
    # equivalent to the required inter-part gap without charging a border gap.
    fixed_grid_lb = 1
    fixed_grid_capacity = None
    try:
        if items and all(it.get('kind') == 'single' and not bool(it.get('rot_allowed')) for it in items):
            w0 = float(items[0]['w']); h0 = float(items[0]['h'])
            if all(abs(float(it['w'])-w0) <= 1e-9 and abs(float(it['h'])-h0) <= 1e-9 for it in items):
                cols = int(math.floor((usable_w + gap + 1e-9) / (w0 + gap))) if (w0 + gap) > 0 else 0
                rows_cap = int(math.floor((usable_h + gap + 1e-9) / (h0 + gap))) if (h0 + gap) > 0 else 0
                fixed_grid_capacity = max(0, cols * rows_cap)
                if fixed_grid_capacity > 0:
                    fixed_grid_lb = max(1, int(math.ceil(len(items) / float(fixed_grid_capacity))))
    except Exception:
        fixed_grid_lb = 1
        fixed_grid_capacity = None
    lb = max(area_lb, clique_lb, fixed_grid_lb)
    if prof:
        prof.event('pack_optimal.bounds', lowerBound=int(lb), areaLowerBound=int(area_lb), cliqueLowerBound=int(clique_lb), fixedGridLowerBound=int(fixed_grid_lb), fixedGridCapacity=fixed_grid_capacity, usableArea=usable_area, totalArea=total_area)

    sort_variants = ['density_first','area_desc','max_side_desc','height_desc','width_desc']
    proof_variant_limit_env = str(os.getenv('METOD_PROOF_VARIANT_LIMIT', '2') or '2').strip()
    try:
        proof_variant_limit = max(1, int(proof_variant_limit_env))
    except Exception:
        proof_variant_limit = 2
    proof_variant_limit = min(len(sort_variants), proof_variant_limit)
    homogeneous_grid = _homogeneous_grid_candidate(items, sheet_w, sheet_h, margin, gap)
    best: Optional[Tuple[int, float, List[Placement]]] = None  # (sheets, waste, placements)
    if homogeneous_grid is not None:
        grid_placements, grid_sheets, _grid_capacity, _grid_rotation = homogeneous_grid
        best = (int(grid_sheets), int(grid_sheets) * usable_area - total_area, grid_placements)
    attempt_audit: Dict[str, Any] = {
        'lowerBound': int(lb),
        'areaLowerBound': int(area_lb),
        'cliqueLowerBound': int(clique_lb),
        'fixedGridLowerBound': int(fixed_grid_lb),
        'fixedGridCapacity': fixed_grid_capacity,
        'sortVariants': list(sort_variants),
        'proofVariantLimit': int(proof_variant_limit),
        'greedy': [],
        'proof': [],
        'proofVariantsConsidered': [],
        'proofVariantsSkipped': [],
        'homogeneousGrid': ({
            'sheetsUsed': int(homogeneous_grid[1]),
            'capacityPerSheet': int(homogeneous_grid[2]),
            'pattern': dict(homogeneous_grid[3]),
        } if homogeneous_grid is not None else None),
    }

    def _emit_pack_progress(done_steps: int, total_steps: int, message: str = '') -> None:
        if not callable(progress_cb):
            return
        try:
            frac = 0.0 if total_steps <= 0 else max(0.0, min(1.0, float(done_steps) / float(total_steps)))
            progress_cb(frac, message)
        except Exception:
            pass

    def _emit_pack_progress_fraction(frac: float, message: str = '') -> None:
        if not callable(progress_cb):
            return
        try:
            progress_cb(max(0.0, min(1.0, float(frac))), message)
        except Exception:
            pass

    # Precompute deterministic item orderings once so greedy/proof can reuse them verbatim.
    if grain_enabled:
        group_items = [it for it in items if it.get('kind') == 'group']
        single_items = [it for it in items if it.get('kind') != 'group']
        items_by_variant = {
            variant: group_items + sorted(single_items, key=lambda it, variant=variant: _item_sort_key(it, variant))
            for variant in sort_variants
        }
    else:
        items_by_variant = {
            variant: sorted(items, key=lambda it, variant=variant: _item_sort_key(it, variant))
            for variant in sort_variants
        }

    # Several named strategies can produce byte-for-byte equivalent geometry orders,
    # especially when a job contains many equal fronts. Running those variants again
    # cannot change a single MaxRects decision or the final tie-breaker.
    greedy_variants: List[str] = []
    equivalent_variant_of: Dict[str,str] = {}
    seen_variant_orders: Dict[Tuple[Tuple[Any,...],...],str] = {}
    for variant in sort_variants:
        order_key = tuple(_packing_equivalence_key(item) for item in items_by_variant[variant])
        canonical_variant = seen_variant_orders.get(order_key)
        if canonical_variant is not None:
            equivalent_variant_of[variant] = canonical_variant
            continue
        seen_variant_orders[order_key] = variant
        greedy_variants.append(variant)
    attempt_audit['greedyVariantsExecuted'] = list(greedy_variants)
    attempt_audit['greedyVariantsSkippedEquivalent'] = dict(equivalent_variant_of)

    # First compute an upper bound from the best greedy run across variants (no k limit).
    ub = int(best[0]) if best is not None else None
    greedy_attempts = len(greedy_variants)
    done_steps = 0
    greedy_results: List[Dict[str, Any]] = []
    _emit_pack_progress(done_steps, greedy_attempts, 'Nestings berekenen…')
    for variant in greedy_variants:
        __attempt_started = time.perf_counter()
        if prof:
            prof.event('pack_optimal.greedy_attempt_start', variant=variant)
        its = items_by_variant[variant]
        # greedy with k = len(items) (effectively unlimited)
        attempt_index = done_steps
        pls = _maxrects_pack_k(its, sheet_w, sheet_h, margin, gap, k=len(items), report=report,
                               progress_cb=(lambda inner_frac, msg='', attempt_index=attempt_index, total_steps=greedy_attempts:
                                            _emit_pack_progress_fraction((attempt_index + max(0.0, min(1.0, float(inner_frac)))) / float(max(1, total_steps)), msg or 'Nestings berekenen…')))
        done_steps += 1
        _emit_pack_progress(done_steps, greedy_attempts, f'Nestings berekenen… ({done_steps}/{greedy_attempts})')
        __attempt_seconds = round(time.perf_counter()-__attempt_started,6)
        __attempt_sheets = int(max((p.sheetIndex for p in pls), default=1)) if pls is not None else None
        if prof:
            prof.event('pack_optimal.greedy_attempt_end', variant=variant, seconds=__attempt_seconds, success=pls is not None)
        greedy_entry = {
            'variant': variant,
            'seconds': __attempt_seconds,
            'success': bool(pls is not None),
            'sheetsUsed': __attempt_sheets,
        }
        attempt_audit['greedy'].append(greedy_entry)
        greedy_results.append(dict(greedy_entry))
        if pls is None:
            continue
        sheets_used = max((p.sheetIndex for p in pls), default=1)
        waste = sheets_used*usable_area - total_area
        cand = (sheets_used, waste, pls)
        if best is None or (cand[0], cand[1]) < (best[0], best[1]):
            best = cand
            ub = sheets_used
        # FIX656 safe early exit: lb is a rigorous lower bound. Once a valid packing hits
        # it, no later greedy/proof attempt can use fewer sheets, so extra attempts are pure
        # latency and cannot improve the primary production objective.
        if int(sheets_used) == int(lb):
            attempt_audit['upperBoundGreedy'] = int(sheets_used)
            attempt_audit['proofVariantsConsidered'] = []
            attempt_audit['proofVariantsSkipped'] = list(sort_variants)
            attempt_audit['proofRange'] = {'from': int(lb), 'toInclusive': int(lb) - 1}
            attempt_audit['greedyAttemptCount'] = len(attempt_audit.get('greedy') or [])
            attempt_audit['proofAttemptCount'] = 0
            attempt_audit['totalAttemptCount'] = int(attempt_audit['greedyAttemptCount'])
            attempt_audit['finalSheetsUsed'] = int(sheets_used)
            attempt_audit['earlyOptimalLowerBound'] = True
            try:
                report['_lastPackAttemptAudit'] = attempt_audit
            except Exception:
                pass
            _emit_pack_progress_fraction(1.0, 'Optimale plaatindeling bewezen…')
            if prof:
                prof.event('pack_optimal.early_lower_bound', sheetsUsed=int(sheets_used), lowerBound=int(lb), greedyAttempts=len(attempt_audit.get('greedy') or []))
                prof.event('pack_optimal.end', sheetsUsed=int(sheets_used), totalSteps=len(attempt_audit.get('greedy') or []))
            return pls, sheets_used

    if best is None:
        fatal(report, "Packing failed unexpectedly (no strategy could place items).")

    # Rank proof variants using the actual greedy outcomes: same minimal sheet count first, then faster variants.
    proof_variants_ranked = [
        row['variant'] for row in sorted(
            [row for row in greedy_results if row.get('success')],
            key=lambda row: (
                int(row.get('sheetsUsed') if row.get('sheetsUsed') is not None else 10**9),
                float(row.get('seconds') if row.get('seconds') is not None else 10**9),
                sort_variants.index(row['variant']) if row.get('variant') in sort_variants else 10**9,
            )
        )
    ]
    if not proof_variants_ranked:
        proof_variants_ranked = list(sort_variants)
    proof_variants = proof_variants_ranked[:proof_variant_limit]
    skipped_variants = [variant for variant in sort_variants if variant not in proof_variants]
    attempt_audit['proofVariantsConsidered'] = list(proof_variants)
    attempt_audit['proofVariantsSkipped'] = list(skipped_variants)

    # Try to prove fewer sheets possible by attempting k from lb..ub-1.
    # Deterministic: ascending k, proof variants in greedy-ranked order.
    attempt_audit['upperBoundGreedy'] = int(ub) if ub is not None else None
    proof_attempts = max(0, int(ub) - int(lb)) * len(proof_variants)
    total_steps = greedy_attempts + proof_attempts
    _emit_pack_progress(done_steps, total_steps, 'Nestings berekenen…')
    for k in range(lb, int(ub)):
        found = None
        for variant in proof_variants:
            __attempt_started = time.perf_counter()
            if prof:
                prof.event('pack_optimal.proof_attempt_start', k=int(k), variant=variant)
            its = items_by_variant[variant]
            attempt_index = done_steps
            pls = _maxrects_pack_k(its, sheet_w, sheet_h, margin, gap, k=k, report=report,
                                   progress_cb=(lambda inner_frac, msg='', attempt_index=attempt_index, total_steps=total_steps:
                                                _emit_pack_progress_fraction((attempt_index + max(0.0, min(1.0, float(inner_frac)))) / float(max(1, total_steps)), msg or 'Nestings berekenen…')))
            done_steps += 1
            _emit_pack_progress(done_steps, total_steps, f'Nestings berekenen… ({done_steps}/{total_steps})')
            __attempt_seconds = round(time.perf_counter()-__attempt_started,6)
            __attempt_sheets = int(max((p.sheetIndex for p in pls), default=1)) if pls is not None else None
            if prof:
                prof.event('pack_optimal.proof_attempt_end', k=int(k), variant=variant, seconds=__attempt_seconds, success=pls is not None)
            attempt_audit['proof'].append({
                'k': int(k),
                'variant': variant,
                'seconds': __attempt_seconds,
                'success': bool(pls is not None),
                'sheetsUsed': __attempt_sheets,
            })
            if pls is not None:
                waste = k*usable_area - total_area
                found = (k, waste, pls)
                break
        if found is not None:
            best = found
            break

    _emit_pack_progress(total_steps, total_steps, 'Nestings berekenen afgerond…')
    sheets_used = best[0]
    attempt_audit['proofRange'] = {'from': int(lb), 'toInclusive': int(ub) - 1 if ub is not None else None}
    attempt_audit['greedyAttemptCount'] = len(attempt_audit.get('greedy') or [])
    attempt_audit['proofAttemptCount'] = len(attempt_audit.get('proof') or [])
    attempt_audit['totalAttemptCount'] = int(attempt_audit['greedyAttemptCount']) + int(attempt_audit['proofAttemptCount'])
    attempt_audit['finalSheetsUsed'] = int(sheets_used)
    try:
        report['_lastPackAttemptAudit'] = attempt_audit
    except Exception:
        pass
    if prof:
        prof.event('pack_optimal.end', sheetsUsed=int(sheets_used), totalSteps=int(total_steps))
    return best[2], sheets_used


def build_quote(job_id: str, rows: List[PanelRow], placements: List[Placement], pricing: Dict[str,Any]) -> Dict[str,Any]:
    defaults = pricing.get('defaults', {})
    if not isinstance(defaults, dict):
        raise ContractError('pricing.defaults must be an object')
    currency = str(pricing.get('currency') or '').strip().upper()
    if not re.fullmatch(r'[A-Z]{3}', currency):
        raise ContractError('pricing.currency must be an ISO-style three-letter code')
    # sheet counts per material
    sheet_counts: Dict[Tuple[str,float], int] = {}
    for p in placements:
        k = (p.materialCode, float(p.thicknessMm))
        sheet_counts[k] = max(sheet_counts.get(k, 0), p.sheetIndex)

    mats = {(m.get('materialCode'), float(m.get('thicknessMm',0))): m for m in pricing.get('materials', [])}

    materials_out: List[Dict[str,Any]] = []
    sheet_cost_total = 0.0
    for (code, th), cnt in sorted(sheet_counts.items()):
        mat = mats.get((code, th))
        if mat is None:
            raise ContractError(f'No exact authoritative pricing record for {code}/{th:g}mm')
        unit = finite_number(mat.get('purchasePricePerSheet'), field=f'{code}.purchasePricePerSheet', minimum=0.0, maximum=1000000.0)
        cost = unit * cnt
        sheet_cost_total += cost
        sell_ex = None
        if mat.get('sellPriceExVatPerSheet') is not None:
            sell_ex = finite_number(mat.get('sellPriceExVatPerSheet'), field=f'{code}.sellPriceExVatPerSheet', minimum=0.0, maximum=1000000.0)
        sell_inc = None
        if mat.get('sellPriceInclVatPerSheet') is not None:
            sell_inc = finite_number(mat.get('sellPriceInclVatPerSheet'), field=f'{code}.sellPriceInclVatPerSheet', minimum=0.0, maximum=1000000.0)
        materials_out.append({
            'materialCode': code,
            'thicknessMm': th,
            'sheetSizeMm': mat.get('sheetSizeMm', {}),
            'sheetCount': cnt,
            'sheetUnitCost': unit,  # legacy Tool B ex-VAT compatibility value
            'sheetCostTotal': round(cost, 2),
            'sellPriceExVatPerSheet': round(sell_ex, 2) if sell_ex is not None else None,
            'sellPriceInclVatPerSheet': round(sell_inc, 2) if sell_inc is not None else None,
            'materialPriceBasis': mat.get('materialPriceBasis') or 'CSV_SELL_PRICE_INCL_VAT',
        })

    edge_cfg = pricing.get('edgeBanding', {})
    if not isinstance(edge_cfg, dict):
        raise ContractError('edgeBanding must be an object')
    loss_percent = finite_number(edge_cfg.get('defaultLossPercent'), field='edgeBanding.defaultLossPercent', minimum=0.0, maximum=100.0)
    edge_price: Dict[int,float] = {}
    for c in edge_cfg.get('codes', []) or []:
        if not isinstance(c, dict):
            raise ContractError('edgeBanding.codes entries must be objects')
        code = int(finite_number(c.get('code'), field='edgeBanding code', minimum=1.0, maximum=999.0))
        if float(code) != finite_number(c.get('code'), field='edgeBanding code', minimum=1.0, maximum=999.0):
            raise ContractError('edgeBanding code must be an integer')
        if code in edge_price:
            raise ContractError(f'duplicate edgeBanding code {code}')
        edge_price[code] = finite_number(c.get('purchasePricePerUnit'), field=f'edgeBanding code {code} price', minimum=0.0, maximum=100000.0)

    meters: Dict[int,float] = {}
    for r in rows:
        qty = r.Qty
        for code, m in (
            (r.H1, (r.LengthMm/1000.0)*qty),
            (r.H2, (r.LengthMm/1000.0)*qty),
            (r.W1, (r.WidthMm/1000.0)*qty),
            (r.W2, (r.WidthMm/1000.0)*qty),
        ):
            if code == 0:
                continue
            if code not in edge_price:
                raise ContractError(f'Unknown edgeBanding code {code}')
            meters[code] = meters.get(code, 0.0) + m

    meters_loss = {k: v*(1.0 + loss_percent/100.0) for k,v in meters.items()}
    by_code_cost: Dict[str,float] = {}
    edge_cost_total = 0.0
    for code, m in meters_loss.items():
        unit = edge_price.get(code, 0.0)
        cost = m * unit
        by_code_cost[str(code)] = round(cost, 2)
        edge_cost_total += cost

    return {
        'jobId': job_id,
        'currency': currency,
        'settings': {
            'units': 'mm',
            'sheetMarginMm': finite_number(defaults.get('sheetMarginMm'), field='defaults.sheetMarginMm', minimum=0.0, maximum=100.0),
            'nestingGapMm': finite_number(defaults.get('nestingGapMm'), field='defaults.nestingGapMm', minimum=0.0, maximum=100.0),
            'kerfMm': finite_number(defaults.get('kerfMm'), field='defaults.kerfMm', minimum=0.0, maximum=100.0),
        },
        'materials': materials_out,
        'edgeBanding': {
            'defaultLossPercent': loss_percent,
            'byCodeMeters': {str(k): round(v, 3) for k,v in meters.items()},
            'byCodeMetersWithLoss': {str(k): round(v, 3) for k,v in meters_loss.items()},
            'byCodeCost': by_code_cost,
            'edgeCostTotal': round(edge_cost_total, 2),
        },
        'totals': {
            'sheetCostTotal': round(sheet_cost_total, 2),
            'edgeCostTotal': round(edge_cost_total, 2),
            'grandTotal': round(sheet_cost_total + edge_cost_total, 2),
        },
        'outputs': {'sheetsDxfFolder': 'output/sheets/'},
    }



def compose_sheet_dxf(sheet_w: float, sheet_h: float, sheet_index: int, sheet_placements: List[Placement], part_cache: Dict[str,PartData], out_path: Path, report: Dict[str,Any]) -> None:
    pairs: List[Tuple[int,str]] = []
    # minimal header
    pairs += [(0,'SECTION'), (2,'ENTITIES')]
    # sheet outline (layer SHEET)
    def add_lwpoly_rect(x0: float, y0: float, w: float, h: float, layer: str) -> None:
        pairs.extend([
            (0,'LWPOLYLINE'), (8,layer), (90,'4'), (70,'1'),
            (10,str(x0)), (20,str(y0)),
            (10,str(x0+w)), (20,str(y0)),
            (10,str(x0+w)), (20,str(y0+h)),
            (10,str(x0)), (20,str(y0+h)),
        ])

    # CNC origin is the physical lower-right corner: X runs from -sheet_w to 0.
    add_lwpoly_rect(-sheet_w,0,sheet_w,sheet_h,'SHEET')
    # Note: no debug/origin marker geometry is added to production DXF output.


    expected_drill_entities = 0
    geometry_tolerance = float(os.environ.get('DXF_ENTITY_BOUNDS_TOLERANCE_MM', '0.1'))
    for p in sheet_placements:
        pdata = part_cache.get(p.partId)
        if pdata is None:
            fatal(report, f"Missing part cache for {p.partId} while composing sheet")
        # choose w0/h0 (original normalized bbox)
        w0 = pdata.w
        h0 = pdata.h

        # 1) Clean outer contour as a rectangle on CUT layer
        if int(p.rotationDeg) % 180 == 90:
            ow, oh = h0, w0
        else:
            ow, oh = w0, h0
        x_place = -(float(p.x) + float(ow))
        y_place = float(p.y)
        add_lwpoly_rect(x_place, y_place, ow, oh, 'CUT')

        # 2) Only drill geometry (circles/arcs) from the source DXF
        if pdata.drill_pairs:
            transformed_drill = rotate_translate_pairs(pdata.drill_pairs, p.rotationDeg, x_place, y_place, w0=w0, h0=h0)
            # Put drill on its own layer so CAM can filter easily
            transformed_drill = set_layer_for_pairs(transformed_drill, 'DRILL')
            transformed_entities = strict_split_entities(transformed_drill)
            if len(transformed_entities) != pdata.drill_entity_count:
                fatal(report, f"{p.partId}: machining entity count changed during transform")
            for entity in transformed_entities:
                bbox = strict_entity_bbox(entity)
                if bbox is None:
                    fatal(report, f"{p.partId}: machining entity has no finite bbox")
                if (
                    bbox.min_x < x_place - geometry_tolerance
                    or bbox.max_x > x_place + ow + geometry_tolerance
                    or bbox.min_y < y_place - geometry_tolerance
                    or bbox.max_y > y_place + oh + geometry_tolerance
                ):
                    fatal(report, f"{p.partId}: transformed machining escapes its placement bbox")
            expected_drill_entities += len(transformed_entities)
            pairs.extend(transformed_drill)

    pairs += [(0,'ENDSEC'), (0,'EOF')]
    output_text = pairs_to_dxf(pairs)
    output_entities = strict_split_entities(strict_entities_section(strict_parse_pairs(output_text)))
    layer_counts: Dict[str, int] = defaultdict(int)
    for entity in output_entities:
        layer = strict_entity_layer(entity)
        if layer not in {'SHEET', 'CUT', 'DRILL'}:
            fatal(report, f"Sheet {sheet_index}: unexpected production layer {layer!r}")
        layer_counts[layer] += 1
        bbox = strict_entity_bbox(entity)
        if bbox is None:
            fatal(report, f"Sheet {sheet_index}: entity on {layer} has no finite bbox")
        if (
            bbox.min_x < -float(sheet_w) - geometry_tolerance
            or bbox.max_x > geometry_tolerance
            or bbox.min_y < -geometry_tolerance
            or bbox.max_y > float(sheet_h) + geometry_tolerance
        ):
            fatal(report, f"Sheet {sheet_index}: {layer} entity escapes sheet bounds")
    if layer_counts.get('SHEET', 0) != 1:
        fatal(report, f"Sheet {sheet_index}: expected exactly one SHEET outline")
    if layer_counts.get('CUT', 0) != len(sheet_placements):
        fatal(report, f"Sheet {sheet_index}: CUT count does not match placements")
    if layer_counts.get('DRILL', 0) != expected_drill_entities:
        fatal(report, f"Sheet {sheet_index}: machining count does not match source geometry")
    durable_write_text(out_path, output_text)
    report.setdefault('sheetValidation', []).append({
        'sheetIndex': int(sheet_index),
        'placements': len(sheet_placements),
        'sheetOutlines': layer_counts.get('SHEET', 0),
        'cutEntities': layer_counts.get('CUT', 0),
        'machiningEntities': layer_counts.get('DRILL', 0),
        'geometrySha256': geometry_sha256(output_entities),
    })


# ------------------------------
# Main
# ------------------------------


def _atomic_progress_write_json(path: Path, payload: Dict[str,Any]) -> None:
    """Atomically publish transient progress without forcing storage flushes.

    Progress and the in-flight report are replaceable UI snapshots. Fsyncing both
    files on every packer callback caused hundreds of synchronous disk barriers on
    VPS storage. Final report/manifests/production DXFs still use durable_write_json
    or durable_write_text and remain covered by the finalization hashes.
    """
    path=Path(path)
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name(f'.{path.name}.progress.{os.getpid()}')
    try:
        tmp.write_text(strict_json_dumps(payload,indent=2)+'\n',encoding='utf-8')
        os.replace(tmp,path)
    finally:
        try:
            tmp.unlink(missing_ok=True)
        except Exception:
            pass


def _write_progress_snapshot(output_dir: Path, payload: Dict[str,Any]) -> None:
    try:
        _atomic_progress_write_json(output_dir/'progress.json',payload)
    except Exception:
        pass



def write_progress_report(output_dir: Path, report: Dict[str,Any], percent: float, phase: str, message: str = '') -> None:
    try:
        ensure_dir(output_dir)
        progress_payload = {
            'percent': max(0, min(100, int(round(float(percent))))),
            'phase': str(phase or '').strip(),
            'message': str(message or phase or '').strip(),
            'updatedAt': now_iso(),
        }
        report['progress'] = progress_payload
        _write_progress_snapshot(output_dir, progress_payload)
        _atomic_progress_write_json(output_dir/'report.json',report)
    except Exception:
        pass


def validate_final_placements(
    rows: List[PanelRow],
    placements: List[Placement],
    material_map: Dict[str, Dict[str, Any]],
    report: Dict[str, Any],
) -> Dict[str, Any]:
    """Prove that the packer produced each requested instance exactly once and safely."""

    expected = {(row.PartId, index) for row in rows for index in range(1, row.Qty + 1)}
    observed = [(placement.partId, int(placement.instanceIndex)) for placement in placements]
    if len(observed) != len(set(observed)):
        fatal(report, 'Duplicate placement identity in final output')
    if set(observed) != expected:
        missing = sorted(expected - set(observed))[:10]
        extra = sorted(set(observed) - expected)[:10]
        fatal(report, f'Placement identity mismatch; missing={missing}, extra={extra}')

    by_sheet: Dict[Tuple[str, float, int], List[Tuple[Placement, float, float]]] = defaultdict(list)
    tolerance = 1e-7
    for placement in placements:
        values = (
            placement.x,
            placement.y,
            placement.widthMm,
            placement.lengthMm,
            placement.thicknessMm,
        )
        if not all(math.isfinite(float(value)) for value in values):
            fatal(report, f'{placement.partId}: non-finite placement geometry')
        if int(placement.rotationDeg) not in {0, 90, 180, 270}:
            fatal(report, f'{placement.partId}: unsupported placement rotation')
        actual_w = float(placement.widthMm if int(placement.rotationDeg) % 180 == 0 else placement.lengthMm)
        actual_h = float(placement.lengthMm if int(placement.rotationDeg) % 180 == 0 else placement.widthMm)
        material = material_map.get(placement.materialCode)
        if material is None or abs(float(material['thicknessMm']) - float(placement.thicknessMm)) > tolerance:
            fatal(report, f'{placement.partId}: placement material/thickness is not authoritative')
        sheet_w = float(material['sheetSizeMm']['width'])
        sheet_h = float(material['sheetSizeMm']['height'])
        if (
            placement.x < -tolerance
            or placement.y < -tolerance
            or placement.x + actual_w > sheet_w + tolerance
            or placement.y + actual_h > sheet_h + tolerance
        ):
            fatal(report, f'{placement.partId}: placement escapes authoritative sheet bounds')
        by_sheet[(placement.materialCode, float(placement.thicknessMm), int(placement.sheetIndex))].append(
            (placement, actual_w, actual_h)
        )

    collision_checks = 0
    for _sheet_key, members in by_sheet.items():
        for index, (left, left_w, left_h) in enumerate(members):
            for right, right_w, right_h in members[index + 1 :]:
                collision_checks += 1
                separated = (
                    left.x + left_w <= right.x + tolerance
                    or right.x + right_w <= left.x + tolerance
                    or left.y + left_h <= right.y + tolerance
                    or right.y + right_h <= left.y + tolerance
                )
                if not separated:
                    fatal(report, f'Placement collision: {left.partId} and {right.partId}')

    row_by_id = {row.PartId: row for row in rows}
    grain_groups: Dict[str, List[Tuple[int, Placement]]] = defaultdict(list)
    for placement in placements:
        row = row_by_id[placement.partId]
        if row.GrainGroup:
            group_id, position = row.GrainGroup.split(':', 1)
            grain_groups[group_id].append((int(position), placement))
    for group_id, members in grain_groups.items():
        ordered = sorted(members, key=lambda item: item[0])
        sheet_keys = {(item.materialCode, item.thicknessMm, item.sheetIndex) for _, item in ordered}
        if len(sheet_keys) != 1:
            fatal(report, f'GrainGroup {group_id} was split across sheets')
        if any(int(item.rotationDeg) != 0 for _, item in ordered):
            fatal(report, f'GrainGroup {group_id} contains a rotated panel')
        x_values = {round(float(item.x), 7) for _, item in ordered}
        if len(x_values) != 1:
            fatal(report, f'GrainGroup {group_id} is not vertically aligned')
        y_values = [float(item.y) for _, item in ordered]
        if any(y_values[index] >= y_values[index + 1] for index in range(len(y_values) - 1)):
            fatal(report, f'GrainGroup {group_id}: position 1 must be the lowest physical Y')

    return {
        'expectedInstances': len(expected),
        'observedPlacements': len(observed),
        'sheetPartitions': len(by_sheet),
        'collisionChecks': collision_checks,
        'grainGroups': len(grain_groups),
        'grainPositionOneIsLowestY': True,
    }


def resolve_dxf_part_sources(
    input_dir: Path,
    rows: List[PanelRow],
    report: Dict[str, Any],
) -> Tuple[Dict[str, Path], List[Path], str]:
    """Resolve legacy PartId files or compact content-addressed DXF input."""
    expected_ids = {row.PartId for row in rows}
    refs_path = input_dir / 'dxf_part_refs.json'
    blobs_dir = input_dir / 'dxf_blobs'
    if refs_path.exists():
        try:
            manifest = strict_json_load(refs_path)
        except Exception as exc:
            fatal(report, f'Invalid dxf_part_refs.json: {exc}')
        if not isinstance(manifest, dict) or int(manifest.get('schemaVersion') or 0) != 1:
            fatal(report, 'dxf_part_refs.json has an unsupported schema')
        if str(manifest.get('algorithm') or '').lower() != 'sha256':
            fatal(report, 'dxf_part_refs.json must use sha256 content addresses')
        refs = manifest.get('partRefs')
        if not isinstance(refs, dict) or set(refs) != expected_ids:
            fatal(report, 'DXF reference set does not exactly match panels.csv')
        if not blobs_dir.is_dir() or blobs_dir.is_symlink():
            fatal(report, 'Missing or unsafe dxf_blobs directory')

        source_by_part: Dict[str, Path] = {}
        source_by_blob: Dict[str, Path] = {}
        referenced_blob_ids: Set[str] = set()
        for part_id in sorted(expected_ids):
            blob_id = str(refs.get(part_id) or '').strip().lower()
            if not re.fullmatch(r'[0-9a-f]{64}', blob_id):
                fatal(report, f'{part_id}: invalid DXF sha256 reference')
            referenced_blob_ids.add(blob_id)
            path = blobs_dir / f'{blob_id}.dxf'
            if not path.is_file() or path.is_symlink():
                fatal(report, f'{part_id}: referenced DXF body is missing or unsafe')
            if blob_id not in source_by_blob:
                if sha256_file(path) != blob_id:
                    fatal(report, f'{part_id}: referenced DXF body hash mismatch')
                source_by_blob[blob_id] = path
            source_by_part[part_id] = source_by_blob[blob_id]
        actual_blob_ids = {path.stem.lower() for path in blobs_dir.glob('*.dxf') if path.is_file()}
        if actual_blob_ids != referenced_blob_ids:
            fatal(report, 'dxf_blobs contains missing or unreferenced bodies')
        evidence = [refs_path] + [source_by_blob[key] for key in sorted(source_by_blob)]
        return source_by_part, evidence, 'content_addressed_refs_v1'

    parts_dir = input_dir / 'dxf_parts'
    source_by_part = {row.PartId: parts_dir / f'{row.PartId}.dxf' for row in rows}
    missing = [part_id for part_id, path in source_by_part.items() if not path.is_file()]
    if missing:
        fatal(report, f'Missing DXF files for PartId(s): {missing}')
    return source_by_part, list(source_by_part.values()), 'legacy_part_files'


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--input', required=True)
    ap.add_argument('--output', required=True)
    args = ap.parse_args()

    input_dir = Path(args.input)
    output_dir = Path(args.output)
    report: Dict[str,Any] = {
        'version': 'FIX660R8',
        'startedAt': now_iso(),
        'inputDir': str(input_dir),
        'outputDir': str(output_dir),
    }
    timing_profile: Dict[str,Any] = {
        'version': 'FIX660R8',
        'startedAt': now_iso(),
        'stages': []
    }
    perf_started = time.perf_counter()

    ensure_dir(output_dir)
    global _OPTIMIZER_PROFILER
    profiler_enabled = str(os.environ.get('METOD_OPTIMIZER_PROFILER', '')).strip().lower() in {'1', 'true', 'yes', 'on'}
    _OPTIMIZER_PROFILER = OptimizerProfiler(output_dir) if profiler_enabled else None
    prof = _profiler()
    if prof:
        prof.set_meta(inputDir=str(input_dir), outputDir=str(output_dir))
        prof.event('main.start')
    write_progress_report(output_dir, report, 1, 'start', 'Optimalisatie gestart…')

    try:
        job_path = input_dir / 'job.json'
        if not job_path.exists():
            fatal(report, f"Missing job.json: {job_path}")
        job = strict_json_load(job_path)
        if not isinstance(job, dict):
            fatal(report, 'job.json must be a JSON object')
        if 'grainEnabled' not in job:
            fatal(report, 'job.json missing required key: grainEnabled')
        grain_enabled = job.get('grainEnabled')
        if not isinstance(grain_enabled, bool):
            fatal(report, f"job.json grainEnabled must be boolean, got {type(grain_enabled).__name__}")
        pricing = strict_json_load(input_dir/'pricing.json')
        if not isinstance(pricing, dict):
            fatal(report, 'pricing.json must be a JSON object')
        pricing_defaults = pricing.get('defaults') if isinstance(pricing.get('defaults'), dict) else {}
        # Respect the active pricing config for technical layout settings so Admin
        # changes (plaatmarge / nesting gap / kerf) apply directly to new plaatindelingen.
        try:
            gap = finite_number(pricing_defaults.get('nestingGapMm'), field='pricing.defaults.nestingGapMm', minimum=0.0, maximum=100.0)
            margin = finite_number(pricing_defaults.get('sheetMarginMm'), field='pricing.defaults.sheetMarginMm', minimum=0.0, maximum=100.0)
        except Exception as exc:
            fatal(report, f'Invalid production layout settings: {exc}')
        report['layoutSettings'] = {
            'sheetMarginMm': round(float(margin), 3),
            'nestingGapMm': round(float(gap), 3),
            'source': 'pricing.defaults',
        }
        if not isinstance(pricing.get('materials'), list) or not pricing.get('materials'):
            fatal(report, 'pricing.json must contain authoritative materials[]')

        material_map: Dict[str, dict] = {}
        allowed_thicknesses: Set[float] = set()
        for index, material in enumerate(pricing.get('materials') or []):
            if not isinstance(material, dict):
                fatal(report, f'pricing.json materials[{index}] must be an object')
            code = str(material.get('materialCode') or '').strip()
            if not code or code in material_map:
                fatal(report, f'pricing.json contains missing/duplicate materialCode {code!r}')
            try:
                thickness = finite_number(material.get('thicknessMm'), field=f'materials[{index}].thicknessMm', minimum=0.1, maximum=100.0)
                sheet_size = material.get('sheetSizeMm') if isinstance(material.get('sheetSizeMm'), dict) else {}
                sheet_width = finite_number(sheet_size.get('width'), field=f'materials[{index}].sheetSizeMm.width', minimum=1.0, maximum=10000.0)
                sheet_height = finite_number(sheet_size.get('height'), field=f'materials[{index}].sheetSizeMm.height', minimum=1.0, maximum=10000.0)
                purchase_price = finite_number(material.get('purchasePricePerSheet'), field=f'materials[{index}].purchasePricePerSheet', minimum=0.0, maximum=1000000.0)
            except Exception as exc:
                fatal(report, f'Invalid authoritative material {code}: {exc}')
            material_map[code] = {
                **material,
                'materialCode': code,
                'thicknessMm': thickness,
                'sheetSizeMm': {'width': sheet_width, 'height': sheet_height},
                'purchasePricePerSheet': purchase_price,
            }
            allowed_thicknesses.add(round(thickness, 3))

        edge_cfg = pricing.get('edgeBanding')
        if not isinstance(edge_cfg, dict):
            fatal(report, 'pricing.json edgeBanding must be an object')
        try:
            finite_number(edge_cfg.get('defaultLossPercent'), field='edgeBanding.defaultLossPercent', minimum=0.0, maximum=100.0)
        except Exception as exc:
            fatal(report, f'Invalid authoritative edge loss: {exc}')
        allowed_edge_codes: Set[int] = {0}
        for index, item in enumerate(edge_cfg.get('codes') or []):
            if not isinstance(item, dict):
                fatal(report, f'edgeBanding.codes[{index}] must be an object')
            try:
                raw_code = finite_number(item.get('code'), field=f'edgeBanding.codes[{index}].code', minimum=1.0, maximum=999.0)
                if not raw_code.is_integer():
                    raise ContractError('edge code must be an integer')
                edge_code = int(raw_code)
                if edge_code in allowed_edge_codes:
                    raise ContractError(f'duplicate edge code {edge_code}')
                finite_number(item.get('purchasePricePerUnit'), field=f'edgeBanding.codes[{index}].purchasePricePerUnit', minimum=0.0, maximum=100000.0)
            except Exception as exc:
                fatal(report, f'Invalid authoritative edge code: {exc}')
            allowed_edge_codes.add(edge_code)

        rows = read_panels_csv(
            input_dir/'panels.csv',
            report,
            allowed_thicknesses=allowed_thicknesses,
            allowed_edge_codes=allowed_edge_codes,
        )
        if not grain_enabled and any(str(row.GrainGroup or '').strip() for row in rows):
            fatal(report, 'job.json grainEnabled=false conflicts with GrainGroup rows')
        timing_profile['stages'].append({'name':'read_input', 'seconds': round(max(0.0, time.perf_counter() - perf_started), 3)})
        write_progress_report(output_dir, report, 3, 'read_input', 'Invoer lezen…')

        for r in rows:
            material = material_map.get(r.MaterialCode)
            if material is None:
                fatal(report, f"Unknown MaterialCode '{r.MaterialCode}' for PartId {r.PartId}")
            if abs(float(material.get('thicknessMm')) - float(r.ThicknessMm)) > 1e-9:
                fatal(report, f"{r.PartId}: ThicknessMm does not match authoritative material {r.MaterialCode}")

        # Load parts. Compact R8K input resolves one content-addressed body to any
        # number of logical PartIds, while legacy per-PartId files remain supported.
        part_cache: Dict[str,PartData] = {}
        source_by_part, dxf_input_evidence, dxf_storage_mode = resolve_dxf_part_sources(input_dir, rows, report)
        geometry_cache: Dict[str, PartData] = {}
        geometry_parse_count = 0
        geometry_reuse_count = 0
        for r in rows:
            p = source_by_part[r.PartId]
            if dxf_storage_mode == 'content_addressed_refs_v1':
                cache_key = p.stem.lower()
            else:
                try:
                    st = p.stat()
                    cache_key = f'inode:{int(st.st_dev)}:{int(st.st_ino)}:{int(st.st_size)}'
                except Exception:
                    cache_key = f'path:{p.as_posix()}'
            pdata = geometry_cache.get(cache_key)
            if pdata is None:
                pdata = load_part(p, report)
                geometry_parse_count += 1
                geometry_cache[cache_key] = pdata
            else:
                geometry_reuse_count += 1
            part_cache[r.PartId] = pdata
            validate_part_bbox(r.PartId, r.WidthMm, r.LengthMm, pdata, report)
        report['dxfInput'] = {
            'storageMode': dxf_storage_mode,
            'logicalParts': len(source_by_part),
            'uniqueBodies': len(geometry_cache),
        }
        if prof:
            prof.set_meta(dxfGeometryParses=int(geometry_parse_count), dxfGeometryReuses=int(geometry_reuse_count))
            prof.event('load_parts.deduplicated', parsed=int(geometry_parse_count), reused=int(geometry_reuse_count))
        write_progress_report(output_dir, report, 5, 'load_parts', 'Onderdelen laden…')

        # build instances grouped by material/thickness
        by_mat: Dict[Tuple[str,float], List[Instance]] = {}
        for r in rows:
            forced_rot0 = bool(r.GrainGroup.strip())
            rot_allowed = bool(r.RotationAllowed) and (not forced_rot0)
            insts = by_mat.setdefault((r.MaterialCode, float(r.ThicknessMm)), [])
            for i in range(1, r.Qty+1):
                insts.append(Instance(row=r, idx=i, w=float(r.WidthMm), h=float(r.LengthMm), rot_allowed=rot_allowed))

        # margin/gap come from job.json by contract

        ensure_dir(output_dir)
        sheets_dir = output_dir / 'sheets'
        ensure_dir(sheets_dir)
        zaag_dir = output_dir / 'DXF_Zaagplaten'
        ensure_dir(zaag_dir)
        if any(sheets_dir.iterdir()) or any(zaag_dir.iterdir()):
            fatal(report, 'Production output directories must be empty before optimization')
        write_progress_report(output_dir, report, 7, 'prepare_output', 'Platen voorbereiden…')

        placements_all: List[Placement] = []
        sheet_meta: List[Dict[str,Any]] = []
        production_sheet_paths: List[Path] = []
        mirrored_sheet_paths: List[Path] = []
        optimizer_attempt_audit: Dict[str, Any] = {}

        for (mat_code, th), insts in sorted(by_mat.items()):
            mat = material_map[mat_code]
            sheet_w = float(mat['sheetSizeMm']['width'])
            sheet_h = float(mat['sheetSizeMm']['height'])

            pack_started = time.perf_counter()
            write_progress_report(output_dir, report, 8, 'packing', 'Nestings berekenen…')
            _pack_progress_state = {'pct': None, 'ts': 0.0}
            def _packing_progress(frac: float, msg: str = '') -> None:
                try:
                    frac = max(0.0, min(1.0, float(frac)))
                except Exception:
                    frac = 0.0
                pct = 8 + int(round(frac * 86.0))
                now_ts = time.perf_counter()
                prev_pct = _pack_progress_state.get('pct')
                prev_ts = float(_pack_progress_state.get('ts') or 0.0)
                if prev_pct is not None:
                    pct = max(int(prev_pct), int(pct))
                    if pct == prev_pct and (now_ts - prev_ts) < 0.15 and pct < 94:
                        return
                _pack_progress_state['pct'] = pct
                _pack_progress_state['ts'] = now_ts
                write_progress_report(output_dir, report, pct, 'packing', msg or 'Nestings berekenen…')
            runtime_margin = float(margin)
            runtime_gap = float(gap)
            pls, sheets_used = pack_maxrects_optimal(insts, sheet_w, sheet_h, runtime_margin, runtime_gap, grain_enabled, report, progress_cb=_packing_progress)
            if sheets_used < 1 or not pls:
                fatal(report, f'{mat_code}: packer returned no production placements')
            _attempt_audit = report.pop('_lastPackAttemptAudit', None)
            if isinstance(_attempt_audit, dict):
                _attempt_audit['materialCode'] = mat_code
                _attempt_audit['thicknessMm'] = float(th)
                _attempt_audit['instanceCount'] = int(len(insts))
                optimizer_attempt_audit[mat_code] = _attempt_audit
            pack_done = time.perf_counter()
            timing_profile['stages'].append({'name': f'packing:{mat_code}', 'seconds': round(max(0.0, pack_done - pack_started), 3), 'sheetsUsed': int(sheets_used)})
            placements_all.extend(pls)
            write_progress_report(output_dir, report, 94, 'dxf_setup', f'DXF-platen voorbereiden ({sheets_used} platen)…')
            dxf_started = time.perf_counter()
            if prof:
                prof.event('stage.dxf_write.start', materialCode=mat_code, sheetsUsed=int(sheets_used))

            for si in range(1, sheets_used+1):
                sheet_pls = [p for p in pls if p.sheetIndex == si]
                progress_pct = 94 + int(round((si / float(max(1, sheets_used))) * 2.0))
                write_progress_report(output_dir, report, progress_pct, 'write_sheets', f'Plaat {si} van {sheets_used} genereren…')
                name = f"Sheet_{si:03d}.dxf" if len(by_mat)==1 else f"{mat_code}_Sheet_{si:03d}.dxf"
                out_dxf = sheets_dir / name
                if not sheet_pls:
                    fatal(report, f'{mat_code}: sheet {si} has no placements')
                compose_sheet_dxf(sheet_w, sheet_h, si, sheet_pls, part_cache, out_dxf, report)
                if not out_dxf.is_file() or out_dxf.stat().st_size <= 0:
                    fatal(report, f'{mat_code}: sheet {si} was not durably produced')
                production_sheet_paths.append(out_dxf)

                # Admin uses a second canonical directory. The mirror is verified byte-for-byte.
                mirror_name = f"S{si:03d}.dxf" if len(by_mat) == 1 else f"M{len(mirrored_sheet_paths) + 1:03d}_S{si:03d}.dxf"
                mirror = zaag_dir / mirror_name
                durable_copy_file(out_dxf, mirror)
                if sha256_file(out_dxf) != sha256_file(mirror):
                    fatal(report, f'{mat_code}: sheet {si} mirror hash mismatch')
                mirrored_sheet_paths.append(mirror)

            material_sheet_files = [path for path in production_sheet_paths if path.name.startswith(f'{mat_code}_Sheet_')]
            if len(by_mat) == 1:
                material_sheet_files = list(production_sheet_paths)
            if len(material_sheet_files) != sheets_used:
                fatal(report, f'{mat_code}: exact sheet output count mismatch')


            dxf_done = time.perf_counter()
            timing_profile['stages'].append({'name': f'dxf_write:{mat_code}', 'seconds': round(max(0.0, dxf_done - dxf_started), 3), 'sheetsUsed': int(sheets_used)})
            if prof:
                prof.event('stage.dxf_write.end', materialCode=mat_code, seconds=round(max(0.0, dxf_done - dxf_started), 6), sheetsUsed=int(sheets_used))

            sheet_meta.append({
                'materialCode': mat_code,
                'thicknessMm': th,
                'sheetSizeMm': {'width': sheet_w, 'height': sheet_h},
                'sheetsUsed': sheets_used,
            })

        write_progress_report(output_dir, report, 97, 'finalize_placements', 'Placeringen opslaan…')

        placement_validation = validate_final_placements(rows, placements_all, material_map, report)
        expected_sheet_count = sum(int(item['sheetsUsed']) for item in sheet_meta)
        if len(production_sheet_paths) != expected_sheet_count:
            fatal(report, 'Final production sheet count does not match packer result')
        if len(mirrored_sheet_paths) != expected_sheet_count:
            fatal(report, 'Final mirrored sheet count does not match packer result')
        if len(report.get('sheetValidation') or []) != expected_sheet_count:
            fatal(report, 'Final sheet geometry validation count mismatch')
        report['placementValidation'] = placement_validation

        placements_json = {
            'jobId': (input_dir.parent.name if input_dir.name=='input' else input_dir.name),
            'units': 'mm',
            'origin': 'bottom-left',
            'y_axis': 'up',
            'rotation_deg_cw': False,
            'rotation_origin': 'panel_bbox_min_normalized',
            'rounding': {'xyMm': 0.1},
            'sheets': sheet_meta,
            'placements': [
                {
                    'partId': p.partId,
                    'instanceIndex': p.instanceIndex,
                    'sheetIndex': p.sheetIndex,
                    'x_mm': p.x,
                    'y_mm': p.y,
                    'rotation_deg': p.rotationDeg,
                    'bbox_mm': {'w_mm': (p.widthMm if p.rotationDeg in (0,180) else p.lengthMm),
                               'h_mm': (p.lengthMm if p.rotationDeg in (0,180) else p.widthMm)},
                    'part_mm': {'width_mm': p.widthMm, 'length_mm': p.lengthMm},
                    'materialCode': p.materialCode,
                    'thicknessMm': p.thicknessMm,
                    'edges': {'H1': p.edge['H1'], 'H2': p.edge['H2'], 'W1': p.edge['W1'], 'W2': p.edge['W2']},
                }
                for p in placements_all
            ],
        }

        placements_started = time.perf_counter()
        if prof:
            prof.event('stage.write_placements.start')
        durable_write_json(output_dir/'placements.json', placements_json)
        placements_done = time.perf_counter()
        timing_profile['stages'].append({'name': 'write_placements', 'seconds': round(max(0.0, placements_done - placements_started), 3)})
        if prof:
            prof.event('stage.write_placements.end', seconds=round(max(0.0, placements_done - placements_started), 6))

        write_progress_report(output_dir, report, 98, 'finalize_quote', 'Prijs en plaattotalen opbouwen…')
        quote_started = time.perf_counter()
        if prof:
            prof.event('stage.build_quote.start')
        quote = build_quote(placements_json['jobId'], rows, placements_all, pricing)
        durable_write_json(output_dir/'quote.json', quote)
        quote_done = time.perf_counter()
        timing_profile['stages'].append({'name': 'build_quote', 'seconds': round(max(0.0, quote_done - quote_started), 3)})
        if prof:
            prof.event('stage.build_quote.end', seconds=round(max(0.0, quote_done - quote_started), 6))

        write_progress_report(output_dir, report, 99, 'finalize_report', 'Resultaten afronden…')
        input_files = [job_path, input_dir/'pricing.json', input_dir/'panels.csv'] + dxf_input_evidence
        output_files = production_sheet_paths + mirrored_sheet_paths + [
            output_dir/'placements.json',
            output_dir/'quote.json',
        ]
        optimizer_manifest = {
            'schemaVersion': 1,
            'release': 'FIX660R8',
            'createdAt': now_iso(),
            'contract': {
                'units': 'mm',
                'grainPositionOne': 'lowest-physical-y',
                'cncOrigin': 'lower-right',
                'unknownDxfEntities': 'reject',
                'composeFailure': 'reject',
            },
            'counts': {
                'panelRows': len(rows),
                'requestedInstances': sum(row.Qty for row in rows),
                'placements': len(placements_all),
                'productionSheets': len(production_sheet_paths),
                'mirroredSheets': len(mirrored_sheet_paths),
                'sheetGeometryValidations': len(report.get('sheetValidation') or []),
            },
            'placementValidation': placement_validation,
            'inputsSha256': {
                path.relative_to(input_dir).as_posix(): sha256_file(path)
                for path in sorted(set(input_files), key=lambda item: item.as_posix())
            },
            'outputsSha256': {
                path.relative_to(output_dir).as_posix(): sha256_file(path)
                for path in sorted(set(output_files), key=lambda item: item.as_posix())
            },
            'sheetGeometry': report.get('sheetValidation') or [],
        }
        durable_write_json(output_dir/'optimizer_manifest.json', optimizer_manifest)
        report['optimizerManifestSha256'] = sha256_file(output_dir/'optimizer_manifest.json')
        report['finishedAt'] = now_iso()
        report['ok'] = True
        report['sheets'] = sheet_meta
        report['progress'] = {'percent': 99, 'phase': 'server_followup', 'message': 'Server verwerkt resultaten…', 'updatedAt': now_iso()}
        _write_progress_snapshot(output_dir, report['progress'])
        report_started = time.perf_counter()
        if prof:
            prof.event('stage.write_report.start')
        durable_write_json(output_dir/'report.json', report)
        report_done = time.perf_counter()
        timing_profile['stages'].append({'name': 'write_report', 'seconds': round(max(0.0, report_done - report_started), 3)})
        if prof:
            prof.event('stage.write_report.end', seconds=round(max(0.0, report_done - report_started), 6))
        timing_profile['totalSeconds'] = round(max(0.0, time.perf_counter() - perf_started), 3)
        timing_profile['finishedAt'] = now_iso()
        durable_write_json(output_dir/'timing_profile.json', timing_profile)
        if optimizer_attempt_audit:
            durable_write_json(output_dir/'optimizer_attempt_summary.json', {
                'generatedAt': now_iso(),
                'materials': optimizer_attempt_audit,
            })
        if prof:
            prof.write_summary()
            prof.close()

        report['progress'] = {'percent': 100, 'phase': 'done', 'message': 'Optimalisatie afgerond', 'updatedAt': now_iso()}
        _write_progress_snapshot(output_dir, report['progress'])
        durable_write_json(output_dir/'report.json', report)

        return 0

    except Exception as e:
        prof = _profiler()
        if prof:
            prof.event('main.exception', error=str(e))
            prof.write_summary()
            prof.close()
        report['finishedAt'] = now_iso()
        report['ok'] = False
        report['exception'] = str(e)
        try:
            ensure_dir(output_dir)
            timing_profile['totalSeconds'] = round(max(0.0, time.perf_counter() - perf_started), 3)
            timing_profile['finishedAt'] = now_iso()
            durable_write_json(output_dir/'timing_profile.json', timing_profile)
            durable_write_json(output_dir/'report.json', report)
        except Exception:
            pass
        sys.stderr.write(str(e) + '\n')
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
