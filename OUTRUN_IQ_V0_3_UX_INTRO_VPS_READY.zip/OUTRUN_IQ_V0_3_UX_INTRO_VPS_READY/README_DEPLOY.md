# Outrun IQ v0.3 UX Intro — VPS ready

Nieuwe build:
- Nieuwe hogere-kwaliteit intro video's ingebouwd
- Desktop gebruikt landscape video
- Mobile gebruikt portrait video
- Smooth fade naar platform
- UX Constitution verwerkt: buyer UI NL, bewijsdichtheid, Price Evidence Strip, full-page checkout, order tracking, bied-flow, dispute wizard, seller dashboard dark UI, AI upload wow-flow
- Server luistert standaard op HOST=0.0.0.0 PORT=8795

## Start lokaal/VPS
```bash
cd /opt/outrun-iq/app/OUTRUN_IQ_V0_3_UX_INTRO_VPS_READY
HOST=0.0.0.0 PORT=8795 python3 server.py
```

## Health
```bash
curl -s http://127.0.0.1:8795/api/health
```
