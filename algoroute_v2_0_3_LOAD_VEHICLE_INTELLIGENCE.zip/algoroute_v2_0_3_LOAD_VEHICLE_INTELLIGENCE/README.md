# AlgoRoute v2.0.3 — Load & Vehicle Intelligence

Deze build maakt het laad- en wagenparkmodel strenger en realistischer:

- Geen automatisch aangemaakt wagenpark meer bij Auto Plan.
- Duidelijke foutmelding wanneer er geen voertuigen beschikbaar zijn.
- Instelbare max ritduur, standaard 8 uur.
- C++ optimizer core v1.2 minimaliseert eerst het aantal routes, daarna afstand/tijd.
- Pallets en rolcontainers concurreren om dezelfde vloeroppervlakte.
- Voertuigen krijgen een laadprofiel met laadruimte L/B/H, bruikbare vloer m², veiligheidsmarge, max EP, max RC en max route hours.
- RDW lookup blijft voor merk/model/basisdata, maar laadruimte moet in AlgoRoute gecontroleerd/aangevuld worden.
- Optimizer-output bevat drive time, service time, total time, floor utilization en mix-rule.

3D loading is bewust nog niet actief; deze build doet 2D floor-space load intelligence als robuuste tussenstap.
