# Outrun IQ V0.9 Fixed Complete VPS Ready

Deze versie herstelt de foutieve 14KB ZIP. Bevat:
- volledige Claude v5 HTML basis
- dummy route/inlogscherm
- schakelen tussen koper en seller account
- lokale intro-video assets
- logo pack meegeleverd
- FastAPI server

Start:
```bash
HOST=0.0.0.0 PORT=8795 python3 server.py
```

Health:
```bash
curl -s http://127.0.0.1:8795/api/health
```
