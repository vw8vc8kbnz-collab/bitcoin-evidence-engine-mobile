#!/usr/bin/env python3
import os
from pathlib import Path
from fastapi import FastAPI
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
import uvicorn

BASE = Path(__file__).resolve().parent
STATIC = BASE / "static"
app = FastAPI(title="Outrun IQ", version="0.9-fixed-complete")
app.mount("/assets", StaticFiles(directory=str(STATIC / "assets")), name="assets")
app.mount("/static", StaticFiles(directory=str(STATIC)), name="static")

@app.get("/api/health")
def health():
    return JSONResponse({"ok": True, "app": "Outrun IQ", "version": "0.9-fixed-complete"})

@app.get("/{path:path}")
def index(path: str = ""):
    return FileResponse(str(STATIC / "index.html"))

if __name__ == "__main__":
    host = os.environ.get("HOST", "0.0.0.0")
    port = int(os.environ.get("PORT", "8795"))
    uvicorn.run(app, host=host, port=port)
