# Releaseverslag — Configurator Studio v2.0.0

**Releasedatum:** 10 juli 2026  
**Baseline:** configurator-studio-v1.6  
**Releasekarakter:** volledige kernrebuild, geen patchrelease

## Resultaat

Configurator Studio v2.0.0 is een startbare en deploybare single-workspace applicatie met:

- professionele no-code builder;
- Product Architect;
- Truth Graph v2;
- geïntegreerde 3D/CAD-routering;
- project-, job- en assetpersistentie;
- review en publish gates;
- publieke immutable runtime;
- loginbeveiliging;
- veilige update-/rollbackflow.

## AI- en CAD-routes

| Route | Invoer | Uitvoer | Verplichte gate |
|---|---|---|---|
| Upload | GLB | geïnspecteerd candidate asset | menselijke review |
| Exact | bevestigde maten + template | FreeCAD/Blender GLB | technische inspectie + review |
| Gebalanceerd | 1–4 foto's | Meshy PBR GLB | review |
| Snel | 1–4 foto's | Tripo P1 GLB | review |
| Premium | foto's + beschrijving | Rodin PBR GLB | review |
| Material Lab | accepted GLB + tekst/stijlbeeld | retextured PBR GLB | nieuwe review |

## Validatie

### Automatisch

- 31 JavaScript-modules syntaxcontrole;
- 2 Python-bestanden syntaxcontrole;
- 5 shellscripts syntaxcontrole;
- 3 JSON-bestanden validatie;
- 20/20 Node testcases geslaagd.

Testdekking omvat:

- AI-measurements blijven inferred;
- conflict gate;
- pricing met geverifieerde maten;
- routekeuze;
- FreeCAD-beschikbaarheid;
- publish gate;
- deep immutable runtime;
- GLB mesh-inventaris;
- Product Architect-plan sanitization;
- Meshy single/multi-image payload;
- Meshy text/image retexture payload;
- Tripo P1 contract;
- Rodin all-subjob polling;
- FreeCAD dimension minima en ontbrekende maten;
- HTTP publish/upload/review/generation/material flow;
- projectmanager zonder browser prompt;
- mobile rail autoclose;
- auth/cookie/logout.

### Visueel

Headless Chromium audits op:

- 1440×1000 desktop;
- 390×844 mobile;
- Studio overzicht;
- projectmanager;
- login;
- publieke runtime;
- AI Material Lab.

Resultaat:

- geen horizontale overflow;
- geen page errors;
- geen console errors in de audited flows;
- mobile rail sluit na navigatie;
- Material Lab en referentiebeeldbediening blijven bereikbaar binnen de scrollbare inspector.

De buildomgeving leverde geen WebGL-context. Daarom is de layout geaudit met de ingebouwde 2D-fallback. Het echte demo-GLB is afzonderlijk structureel geïnspecteerd en de viewer lifecycle/syntax is getest.

## Niet live uitgevoerd

Geen externe betaalde providercall is uitgevoerd omdat de buildomgeving geen OpenAI-, Meshy-, Tripo- of Hyper3D-sleutels bevatte.

FreeCAD en Blender waren niet geïnstalleerd in de buildomgeving. De Python-worker, veiligheidsvalidatie en providercontracten zijn getest; voor een echte VPS-generatie is `deploy/install-cad-tools.sh` meegeleverd.

## Deployment safety

- release wordt eerst in tijdelijke map uitgepakt;
- tests draaien vóór swap;
- `.env` en runtimepaden worden gekopieerd;
- oude release wordt rollbackmap;
- systemd wordt herstart;
- healthcheck moet slagen;
- bij fout wordt oude release teruggezet.

## Go/no-go

**Go voor:** demo, interne productontwikkeling, single-workspace staging en live providercontracttests.  
**Nog no-go voor:** openbare multi-tenant SaaS-verkoop zonder tenant-auth, billing, credits, storage en distributed jobinfra.
