# ULTRA TECHNISCHE OVERDRACHT — CONFIGURATOR STUDIO v2.0.0

## 0. Doel van dit document

Dit document draagt de volledige v2.0.0-productkern over. Het beschrijft wat is gebouwd, welke architectuurregels vaststaan, hoe de code werkt, hoe de providers samenwerken, hoe de VPS-deploy verloopt, wat aantoonbaar getest is en welke commerciële SaaS-laag nog bewust ontbreekt.

**Release:** `configurator-studio-v2.0.0`  
**Serverpad:** `/var/www/configurator-studio`  
**Standaardpoort:** `9999`  
**GitHub-repository voor ZIP-release:** `vw8vc8kbnz-collab/bitcoin-evidence-engine-mobile`  
**Node:** 20+  
**Service:** `configurator-studio.service`

De eerdere v1.6-overdracht en roadmap zijn inhoudelijk verwerkt. v2.0.0 is geen oppervlakkige visuele patch maar een volledige kernrebuild.

---

# 1. Definitieve productrichting

Configurator Studio wordt een no-code platform waarmee webshops en merken betrouwbare 3D-productconfigurators bouwen.

De kernbelofte is:

> Een klant bouwt een echte verkoopbare configurator op basis van gecontroleerde productdata, een bruikbaar 3D/CAD-asset, duidelijke onderdelen, klantkeuzes, prijzen, regels en orderoutput.

Niet beloven:

> Eén willekeurige foto wordt automatisch een exact productiegeschikt 3D-model.

AI-reconstructie kan zeer bruikbare volledige 3D-drafts maken, maar verborgen geometrie, schaal, maatvoering, partstructuur en productexactheid blijven reviewpunten.

## Vastgezette principes

1. AI bevestigt nooit feiten.
2. Waarde en provenance blijven apart.
3. Measurements uit AI kunnen nooit stilzwijgend pricing/CAD-authoritative zijn.
4. Publicatie gebruikt boolean/per-field gates.
5. Iedere assetbron vereist menselijke review: upload, CAD, AI en retexture.
6. Productscope en partscope blijven expliciet gescheiden.
7. Acties zijn capability-aware.
8. Pricing heeft één engine.
9. Rules sturen gedrag, niet een tweede prijsberekening.
10. Providermerken blijven uit de klant-UI.
11. Provider-URL’s worden niet als permanente runtimebron gebruikt.
12. Gepubliceerde runtimes zijn immutable snapshots.
13. Geen commerciële SaaS-feature als “af” claimen zolang hij niet echt bestaat.

---

# 2. Wat v2.0.0 bevat

## Studio UX

- premium light interface;
- desktop- en mobile-responsive;
- vaste live klantpreview;
- Product/Part scope switch;
- desktop/mobile preview toggle;
- projectmanager;
- nieuw project aanmaken;
- Product Architect drawer;
- productdata;
- onderdelen;
- opties/materialen;
- prijzen;
- regels;
- orderoutput;
- engine diagnostics;
- publish modal;
- assetreview.

## 3D-viewer

- lokaal gebundelde Three.js r160;
- geen runtime-CDN;
- GLB load;
- camera fit/reset;
- orbit controls;
- mesh clickselectie;
- part highlight;
- materiaaltoepassing;
- desktop/mobile resize;
- orientation-safe resize;
- cleanup van geometry/materials/textures/listeners/RAF/observer/context;
- 2D fallback bij ontbrekende WebGL.

## Product Intelligence

- OpenAI vision/text intake;
- strict JSON schema;
- kandidaatfeiten;
- vragen;
- onderdelenplan;
- option-group plan;
- routeadvies;
- risk notes;
- plan blijft bewerkbare draft.

## 3D/CAD providers

- Meshy single-image reconstruction;
- Meshy multi-image reconstruction;
- Meshy PBR retexture via tekst;
- Meshy PBR retexture via materiaalreferentiebeeld;
- Tripo P1 fast route;
- Rodin Gen-2/PBR premium route;
- FreeCAD exact geometry;
- Blender GLB conversion;
- demo fallback via hetzelfde contract.

## Reliable Core

- Truth Graph v2;
- conflicts;
- explicit verification;
- pricing guard;
- route engine;
- capability model;
- mesh inventory;
- configurability gate;
- pricing engine;
- rules validation;
- order output;
- publish gates;
- immutable runtime compiler;
- audit log.

## Operations

- JSON-store met atomic writes;
- async jobs;
- single-workspace auth;
- systemd hardening;
- safe deploy;
- rollback;
- first-login generation;
- CAD installer;
- healthcheck;
- GitHub updater.

---

# 3. Repositorystructuur

```text
configurator-studio-v2.0.0/
├── package.json
├── server.mjs
├── .env.example
├── README.md
├── HANDOVER_CONFIGURATOR_STUDIO_v2.0.0.md
├── public/
│   ├── index.html
│   ├── app.css
│   ├── login.html
│   ├── runtime.html
│   ├── runtime.css
│   ├── js/
│   │   ├── app.js
│   │   └── viewer.js
│   ├── assets/
│   │   ├── demo-table.glb
│   │   ├── demo-table-preview.png
│   │   └── demo-table-manifest.json
│   └── vendor/three/
├── src/
│   ├── core/
│   │   ├── truthGraph.mjs
│   │   ├── routeEngine.mjs
│   │   ├── pricing.mjs
│   │   ├── rules.mjs
│   │   ├── gates.mjs
│   │   ├── runtimeCompiler.mjs
│   │   ├── blueprint.mjs
│   │   ├── architectPlan.mjs
│   │   └── ids.mjs
│   ├── providers/
│   │   ├── common.mjs
│   │   ├── openaiProductArchitect.mjs
│   │   ├── meshy.mjs
│   │   ├── tripo.mjs
│   │   ├── rodin.mjs
│   │   └── freecad.mjs
│   └── server/
│       ├── config.mjs
│       ├── auth.mjs
│       ├── store.mjs
│       ├── jobRunner.mjs
│       └── glbInspector.mjs
├── server/
│   ├── freecad_worker/worker.py
│   ├── asset_pipeline/convert_to_glb.py
│   └── scripts/
├── deploy/
│   ├── install-release.sh
│   ├── deploy-v2.sh
│   ├── update-from-github.sh
│   ├── install-cad-tools.sh
│   ├── configurator-studio.service
│   └── nginx-configurator-studio.conf
├── tests/
└── docs/
```

---

# 4. Request- en serverarchitectuur

`server.mjs` gebruikt alleen Node coremodules. Er is geen Express-dependency.

## Publieke routes

- `/api/health`
- `/api/auth/status`
- `/api/auth/login`
- `/api/auth/logout`
- `/api/runtime/:id`
- `/runtime/:id`
- statische runtime-assets

## Private routes

Alle Studio management endpoints vereisen een geldige sessie wanneer auth is ingeschakeld.

- `/api/studio`
- `/api/projects`
- `/api/project/update`
- `/api/architect/analyze`
- `/api/architect/apply-plan`
- `/api/facts/confirm`
- `/api/assets/upload`
- `/api/generation/start`
- `/api/material/retexture`
- `/api/jobs/:id`
- `/api/assets/:id/map`
- `/api/assets/:id/review`
- `/api/blueprint/update`
- `/api/price/calculate`
- `/api/publish/gate`
- `/api/publish`

## Requestlimieten

- totale JSON-request standaard 50 MB;
- GLB-upload standaard 30 MB;
- beelden worden als data URI aangeleverd;
- Architect gebruikt maximaal vijf beelden;
- reconstructieroutes gebruiken providerafhankelijk maximaal vier/vijf beelden;
- browser-UI limiteert standaard tot vier productbeelden en 10 MB per beeld.

---

# 5. Persistente datastructuur

`src/server/store.mjs` gebruikt `data/store.json`.

## Atomic write

```text
serialize
→ write store.json.tmp
→ rename naar store.json
```

Daarmee wordt een halfgeschreven hoofdbestand vermeden.

## Project

Belangrijke velden:

```json
{
  "project_id": "proj_...",
  "workspace_id": "ws_...",
  "name": "...",
  "status": "draft|published",
  "runtime_version": 0,
  "published_runtime_id": null,
  "active_asset_id": "asset_...",
  "candidate_asset_id": null,
  "intake": {},
  "required_fact_keys": [],
  "facts": [],
  "clarification_questions": [],
  "candidate_blueprint": null,
  "route_decision": null
}
```

## Asset

```json
{
  "asset_id": "asset_...",
  "source_type": "uploaded_asset|verified_upload|parametric_cad|ai_generated|ai_retextured",
  "provider": "internal-only",
  "technical_status": "succeeded",
  "quality_status": "pending_review|accepted|rejected",
  "public_url": "/generated/...glb",
  "metrics": {},
  "mesh_inventory": [],
  "provenance": {
    "candidate_only": true
  }
}
```

## Job

Jobs zijn persistent en worden door `JobRunner` asynchroon uitgevoerd.

Gevoelige input wordt in API-responses gesanitized:

- foto data URI’s worden `image_count`;
- materiaalstijlbeeld wordt alleen `style_image: true/false`;
- base64 wordt niet in jobstatus teruggegeven.

## Runtime

Een runtime bevat alleen publieke configuratiedata en is recursief gefreezed voordat hij wordt opgeslagen.

---

# 6. Truth Graph v2

`truthGraph.mjs` is de kern van betrouwbaarheid.

Een fact bevat:

- `key`
- `label`
- `value`
- `unit`
- `value_type`
- `critical`
- `candidates[]`
- `verified`
- `conflict`
- `status`
- `pricing_allowed`

## AI-uitvoer

AI-uitvoer wordt genormaliseerd tot candidate. Zelfs wanneer confidence hoog is, blijft status inferred.

## Bevestiging

Alleen expliciete methodes zoals:

- `user_confirmed`
- `admin_confirmed`
- `measured`
- `imported_verified`

mogen kritieke data autoriseren.

## Conflict

Wanneer kandidaten inhoudelijk verschillen, wordt een open conflict gemaakt. Publish gate faalt zolang dat conflict open is.

## Pricing

Area/perimeter pricing haalt uitsluitend facts op waarvoor `pricing_allowed=true` geldt.

Niet wijzigen:

- geen confidence threshold die AI auto-confirmed maakt;
- geen “AI zag 1800 mm dus pricing mag rekenen”;
- geen verified-status in een provideradapter hardcoden.

---

# 7. Product Architect

## Frontendflow

```text
beschrijving + 0–4 beelden
→ analyze
→ kandidaatfeiten en vragen
→ kritieke facts handmatig bevestigen
→ voorgesteld builderplan toepassen
→ generatie starten
```

## OpenAI-contract

De Responses API levert exact:

- summary;
- category;
- candidate_facts;
- clarification_questions;
- configuration_plan;
- risk_notes.

Strict schema voorkomt vrije, moeilijk parsebare tekst.

## Veiligheid

- OpenAI geeft geen `confirmed` terug.
- `architectPlan.mjs` whitelist capabilities.
- onbekende capabilities worden verwijderd.
- parts krijgen geen verzonnen mesh targets.
- het plan is draft en kan worden gewijzigd.

---

# 8. Route-engine

`chooseProductRoute` ontvangt:

- intake;
- facts;
- assets;
- requested profile;
- provider availability.

## Prioriteit

1. bestaand 3D/CAD-asset;
2. exact parametrisch wanneer categorie + drie confirmed hoofdmaten + tooling beschikbaar zijn;
3. foto’s via gevraagd kwaliteitsprofiel;
4. clarification.

## Profiles

- `auto`
- `exact`
- `fast`
- `balanced`
- `premium`

## Provider override

Backend ondersteunt een interne override, maar de normale klant-UI presenteert geen providerknoppen.

## Materiaalroute

`material_studio` wordt nooit automatisch gekozen op basis van een texture prompt. Hij wordt alleen via `/api/material/retexture` gestart en vereist een accepted asset.

---

# 9. Meshy integratie

## Volledige reconstructie

Meshy is een volwaardige 3D-route in deze release.

### Single image

```text
1 image
→ image-to-3d
→ textured/PBR/remeshed GLB
```

### Multi image

```text
2–4 images
→ multi-image-to-3d
→ textured/PBR/remeshed GLB
```

Payload bevat onder andere:

- latest model;
- texture;
- PBR;
- HD texture;
- remesh;
- target polycount 70k;
- enhancement;
- lighting removal;
- GLB;
- auto size;
- bottom origin;
- alpha/multiview thumbnails.

## Material Lab

De gebruiker kan:

- een materiaalstijl beschrijven;
- een close-up van hout/stof/steen/finish uploaden;
- beide UI-ingangen gebruiken, waarbij de adapter één duidelijke provider-style-control kiest.

De bron-GLB wordt als data URI verstuurd. Output wordt lokaal opgeslagen en opnieuw reviewplichtig.

## Mappingbehoud

Bij retexture probeert de jobrunner part assignment te behouden:

1. actuele blueprint mesh target;
2. worker assignment;
3. bronasset mesh-id;
4. bronasset mesh-index.

Een gewijzigde meshstructuur wordt niet stil als betrouwbaar aangenomen; review blijft nodig.

---

# 10. Tripo integratie

Tripo is de snelle route.

## Upload

Iedere data URI wordt naar Tripo geüpload om een file token te verkrijgen. MIME/extension blijft correct bewaard.

## P1

Standaardmodel: `P1-20260311`.

Multiview gebruikt exact:

```text
front, left, back, right
```

Ontbrekende slots blijven lege objecten zonder file token. Dit voorkomt verkeerde viewverschuiving.

P1 krijgt geen H-series-only velden zoals `generate_parts` of `smart_low_poly`.

---

# 11. Rodin integratie

Rodin is de premium route.

## Creatie

- multipart images;
- optionele prompt;
- Gen-2;
- Raw mesh;
- PBR;
- GLB.

## Polling

- creatierespons geeft subscription key en task UUID;
- status gebruikt subscription key;
- success pas wanneer alle subjobs Done zijn;
- failure wanneer een subjob faalt/cancelt/expireert;
- download gebruikt task UUID.

Deze specifieke contractscheiding is getest om verouderde voorbeeldcode te voorkomen.

---

# 12. FreeCAD + Blender

## Invoer

Alleen confirmed facts worden naar `factParams` doorgegeven.

Benodigde hoofdvelden:

- `dimensions.length_mm`
- `dimensions.width_mm`
- `dimensions.height_mm`

Ontbrekende velden veroorzaken een fout. Er zijn geen voorbeeldmaten als fallback.

## Safety minima

- cabinet: 200×100×200 mm;
- panel/door: 50×50×3 mm;
- table/desk: 600×400×350 mm.

## Worker

De Python-worker:

- importeert FreeCAD;
- maakt named objects;
- exporteert STEP en OBJ;
- schrijft manifest/result JSON;
- gebruikt `App` expliciet in helpers;
- valideert template en dimensies vóór geometrie.

## Blender

Blender draait headless en converteert OBJ naar GLB. Mesh/objectnamen blijven waar mogelijk bruikbaar voor mapping.

## Tooling installeren

```bash
sudo bash /var/www/configurator-studio/deploy/install-cad-tools.sh
```

---

# 13. GLB-inspectie en configurability

`glbInspector.mjs` leest GLB zonder browser:

- header;
- JSON chunk;
- nodes/meshes/materials/accessors;
- mesh inventory;
- triangle estimate;
- file size;
- mobile readiness.

## Configurability gate

Blokkerend:

- geen mesh inventory;
- één samengevoegde mesh terwijl meerdere configureerbare parts gewenst zijn;
- configureerbaar part zonder mesh target.

Waarschuwing:

- meer dan 250.000 triangles.

Geen providerclaim overschrijft deze gate.

---

# 14. Buildermodel

## Productscope

- naam en beschrijving;
- facts/maten;
- basisprijs;
- globale rules;
- order output;
- publicatie.

## Partscope

- geselecteerd onderdeel;
- mesh targets;
- material/finish;
- visibility;
- part pricing;
- rules/order wanneer capability aanwezig is.

## Capability whitelist

Een part kan bijvoorbeeld hebben:

- `material`
- `finish`
- `visibility`
- `pricing`
- `rules`
- `order_output`

De inspector mag geen actie tonen die ontbreekt.

## Mobile gedrag

- rail opent via hamburger;
- kiezen van een sectie sluit de rail;
- inspector schuift rechts in;
- footer blijft vast;
- content is afzonderlijk scrollbaar;
- Material Lab blijft bereikbaar;
- geen horizontale overflow bij 390 px.

---

# 15. Pricing en rules

## Pricing

Blueprint:

```json
{
  "currency": "EUR",
  "base_price": {"amount": 799},
  "rules": []
}
```

Option deltas worden op geselecteerde option ids toegepast. Quantity wordt als laatste vermenigvuldigd.

Area-based pricing vereist confirmed length en width.

## Rules

Rules hebben een validatiecontract. Een ongeldige rule blokkeert publicatie.

Niet doen:

- prijs in frontend als waarheid opslaan;
- AI-output direct als prijsregel activeren;
- rules engine parallel laten rekenen.

---

# 16. Review en publish

## Review

Alle nieuwe assets starten als `pending_review` en `candidate_only=true`.

Accept:

- quality status accepted;
- provenance candidate false;
- reviewed timestamp/by;
- project active asset wordt dit asset;
- candidate asset wordt gewist.

Reject:

- quality status rejected;
- actieve asset blijft intact.

## Publish gate

Controleert negen soorten voorwaarden, afhankelijk van required facts:

- kritieke facts;
- configurability;
- basisprijs;
- rules;
- order output;
- conflicts;
- human review.

## Runtime

Runtime bevat geen interne providernaam, prompt, confidence of candidate fact. Iedere publish verhoogt de version en zet projectstatus published.

---

# 17. Authenticatie

## Config

```dotenv
ADMIN_USERNAME=stijn
ADMIN_PASSWORD=
SESSION_SECRET=
SESSION_TTL_SECONDS=43200
COOKIE_SECURE=false
```

De eerste productiedeploy vult lege password/secret automatisch in en toont het password eenmaal in Termius.

## Cookie

- HttpOnly;
- SameSite=Strict;
- Max-Age;
- Secure wanneer `COOKIE_SECURE=true`;
- HMAC signature;
- exp/iat/nonce.

Zet na HTTPS:

```dotenv
COOKIE_SECURE=true
PUBLIC_BASE_URL=https://jouwdomein.nl
```

## Scope

Dit is single-workspace auth, geen multi-tenant identity provider.

---

# 18. Deployment

## Eerste release vanaf GitHub ZIP

De definitieve release ZIP moet exact heten:

```text
configurator-studio-v2.0.0.zip
```

De installer verwacht binnen de ZIP:

```text
configurator-studio-v2.0.0/
```

## Install-release flow

1. bronversie controleren;
2. volledige test suite draaien;
3. release naar nieuwe map kopiëren;
4. bestaande `.env` behouden;
5. data/uploads/assets/outputs behouden;
6. oude app naar rollbackmap verplaatsen;
7. nieuwe app activeren;
8. permissions instellen;
9. systemd installeren/herstarten;
10. healthcheck;
11. bij fout automatisch rollback.

## Service hardening

- user/group `www-data`;
- root-owned source;
- alleen runtimepaden writable;
- `ProtectSystem=strict`;
- `PrivateTmp`;
- `PrivateDevices`;
- `NoNewPrivileges`;
- kernel/control group/home protection;
- restart always.

## Na deploy controleren

```bash
curl -fsS http://127.0.0.1:9999/api/health | python3 -m json.tool
sudo systemctl --no-pager --full status configurator-studio.service
sudo journalctl -u configurator-studio.service -n 100 --no-pager
```

---

# 19. Teststatus

Definitieve automatische status:

```text
31 JavaScript syntax OK
2 Python syntax OK
5 shell syntax OK
3 JSON valid
20/20 tests passed
```

Getest:

- Truth Graph;
- conflict;
- measurement pricing lock;
- pricing;
- route selection;
- FreeCAD unavailable behavior;
- publish gate;
- deep freeze;
- GLB inspection;
- Product Architect plan sanitization;
- Tripo P1 payload;
- Rodin status logic;
- Meshy reconstruction payload;
- Meshy retexture payload;
- FreeCAD worker contract;
- publish status;
- upload candidate/review;
- material retexture demo job;
- project creation;
- generation job;
- project UI/no prompt;
- mobile rail close;
- auth/login/cookie/logout.

## Visual audit

Desktop 1440×1000 en mobile 390×844:

- Studio;
- runtime;
- projectmanager;
- login;
- Material Lab.

Resultaat: geen horizontale overflow en geen page/console errors in de geaudite flows.

WebGL was niet beschikbaar in de sandbox; layout gebruikte de 2D fallback. Het GLB zelf en de viewercode zijn wel structureel/technisch getest.

---

# 20. Eerlijke beperkingen

## Niet live getest

- echte OpenAI-call;
- echte Meshy-call;
- echte Tripo-call;
- echte Rodin-call;
- echte FreeCAD/Blender generatie.

Reden: geen API-keys en geen CAD-binaries in de buildomgeving.

Wat wel is gedaan:

- actuele providercontracten verwerkt;
- payloadbuilders getest;
- pollingregels getest;
- jobflow in demo end-to-end getest;
- CAD safety en Python worker getest;
- installscript meegeleverd.

## Niet inbegrepen in v2.0.0

- multi-tenant auth;
- billing;
- credits;
- paywall;
- Stripe;
- Shopify Billing;
- Shopify app/theme extension;
- WooCommerce plugin;
- object storage/CDN;
- Postgres/Supabase;
- Redis/distributed queue;
- analytics;
- usage metering;
- provider budget caps;
- enterprise white-label.

---

# 21. Verplichte volgende productiefase

## Stap 1 — VPS deploy en smoke test

- installeer v2.0.0;
- login;
- projectflow;
- upload GLB;
- review;
- publish;
- runtime openen;
- mobile iPhone test.

## Stap 2 — CAD tooling

- draai CAD installer;
- controleer binaries;
- voer één tafeljob uit;
- controleer named meshes;
- review/publish.

## Stap 3 — Provider staging

Per provider:

- test key;
- single-image;
- multi-image;
- timeout;
- failure;
- quota;
- review;
- publish.

Pas daarna `DEMO_MODE=false`.

## Stap 4 — Productie-infra

- Postgres repository;
- object storage;
- real queue;
- background workers;
- webhooks/idempotency;
- cost ledger;
- observability.

## Stap 5 — Commercial SaaS

- tenant auth/roles;
- Starter/Growth/Scale;
- credit reservation/capture/refund;
- brandingregels;
- usage limits;
- Shopify/WooCommerce connectors.

---

# 22. Zaken die een volgende chat absoluut niet mag doen

- v2 terugbrengen naar één groot HTML-bestand;
- AI confirmed laten zetten;
- confidence als bewijs gebruiken;
- foto-afmetingen voor pricing gebruiken;
- provideroutput direct activeren;
- uploads automatisch vertrouwen;
- material retexture automatisch productopties laten herschrijven;
- FreeCAD voorbeeldmaten als fallback gebruiken;
- providermerken in klantcopy tonen;
- product/part scope weer mengen;
- onmogelijke contextacties tonen;
- private Studio API publiek maken;
- runtime mutable maken;
- `.env` of data bij update overschrijven;
- deploy zonder tests/healthcheck/rollback;
- multi-tenant/billing/Shopify claimen zonder echte implementatie.

---

# 23. Definition of done voor deze release

v2.0.0 is done wanneer:

- ZIP exact is verpakt;
- `npm run check` groen is;
- checksum is geleverd;
- documentatie klopt met code;
- desktop/mobile audit groen is;
- deploycommand exact naar dezelfde ZIP verwijst;
- beperkingen eerlijk zijn beschreven.

Aan die voorwaarden voldoet de opgeleverde release.
