import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { id, nowIso } from '../core/ids.mjs';
import { chooseProductRoute, ROUTES } from '../core/routeEngine.mjs';
import { MeshyProvider } from '../providers/meshy.mjs';
import { TripoProvider } from '../providers/tripo.mjs';
import { RodinProvider } from '../providers/rodin.mjs';
import { FreeCADProvider } from '../providers/freecad.mjs';
import { inspectGlb } from './glbInspector.mjs';

export class JobRunner {
  constructor({ config, store }) {
    this.config = config; this.store = store;
    this.meshy = new MeshyProvider(config.meshy);
    this.tripo = new TripoProvider(config.tripo);
    this.rodin = new RodinProvider(config.rodin);
    this.freecad = new FreeCADProvider(config.cad);
    this.running = new Set();
  }

  availability() {
    return { openai:Boolean(this.config.openai.apiKey), meshy:this.meshy.available, tripo:this.tripo.available, rodin:this.rodin.available, freecad:commandAvailable(this.config.cad.freecadCmd) && commandAvailable(this.config.cad.blenderCmd), demo_mode:this.config.demoMode };
  }

  async create({ projectId, images = [], requestedProfile = 'auto', providerOverride = null, prompt = '' }) {
    const project = this.store.getProject(projectId);
    if (!project) throw new Error('Project niet gevonden.');
    const sourceAssets = images.map((image,index) => ({kind:'image',extension:mimeExtension(image.type || image.data_url),index}));
    const liveAvailability = this.availability();
    const routeAvailability = this.config.demoMode
      ? {...liveAvailability, meshy:true, tripo:true, rodin:true, freecad:true}
      : liveAvailability;
    let decision = chooseProductRoute({
      intake:{...project.intake,prompt:prompt || project.intake.prompt}, facts:project.facts, assets:sourceAssets,
      requested_profile:requestedProfile, providerAvailability:routeAvailability
    });
    if (providerOverride) decision = overrideDecision(providerOverride, images.length, decision);
    const job = {
      job_id:id('job'), project_id:projectId, type:'asset_generation', status:'queued', progress:0,
      message:'Taak staat klaar.', requested_profile:requestedProfile, provider_override:providerOverride,
      route_decision:decision, input:{images,prompt}, result:null, error:null, created_at:nowIso(), updated_at:nowIso()
    };
    await this.store.addJob(job);
    setImmediate(() => this.#run(job.job_id).catch(error => console.error('Job runner fatal:', error)));
    return sanitizeJob(job);
  }


  async createRetexture({ projectId, assetId = null, prompt = '', styleImage = null }) {
    const project=this.store.getProject(projectId);
    if(!project) throw new Error('Project niet gevonden.');
    const sourceAsset=this.store.getAsset(assetId || project.active_asset_id);
    if(!sourceAsset || sourceAsset.quality_status!=='accepted') throw new Error('Accepteer eerst een actief 3D-model voordat je een materiaaldraft maakt.');
    if(!String(prompt).trim() && !styleImage) throw new Error('Beschrijf het gewenste materiaal of voeg een stijlbeeld toe.');
    const job={job_id:id('job'),project_id:projectId,type:'material_retexture',status:'queued',progress:0,message:'Materiaaldraft staat klaar.',requested_profile:'material',provider_override:'meshy',route_decision:{route:ROUTES.MATERIAL,reason:'PBR-retexture van het gecontroleerde actieve model.',missing:[],pipeline:['meshy_retexture','human_review'],provider_output_is_candidate_only:true,automatic_publish_allowed:false},input:{prompt:String(prompt).slice(0,600),style_image:styleImage,source_asset_id:sourceAsset.asset_id},result:null,error:null,created_at:nowIso(),updated_at:nowIso()};
    await this.store.addJob(job);
    setImmediate(()=>this.#run(job.job_id).catch(error=>console.error('Material job fatal:',error)));
    return sanitizeJob(job);
  }

  async #run(jobId) {
    if (this.running.has(jobId)) return;
    this.running.add(jobId);
    try {
      const job = this.store.getJob(jobId);
      await this.#progress(jobId, 3, 'Productroute controleren…', 'running');
      const project = this.store.getProject(job.project_id);
      const blueprint = this.store.getBlueprint(job.project_id);
      const { route } = job.route_decision;
      if (route === ROUTES.CLARIFY) throw new Error(job.route_decision.reason);
      const materialJob=job.type==='material_retexture';
      const sourceAsset=materialJob?this.store.getAsset(job.input.source_asset_id):null;
      let result;
      const onProgress = update => this.#progress(jobId, Math.min(94, update.progress ?? 20), update.message || '3D-model verwerken…', 'running', update.provider_task_id);
      if (materialJob && this.config.demoMode && !this.#routeAvailable(route)) {
        result=await this.#demoMaterialResult({jobId,sourceAsset,onProgress});
      } else if (this.config.demoMode && !this.#routeAvailable(route)) {
        result = await this.#demoResult({jobId, route, onProgress});
      } else if (route === ROUTES.PARAMETRIC) {
        result = await this.freecad.generate({ template:project.intake.category || 'table', params:factParams(project.facts), outputDir:this.config.outputDir, jobId, root:this.config.root, onProgress });
      } else if (route === ROUTES.PHOTO_FAST) {
        result = await this.tripo.generate({images:job.input.images,outputDir:this.config.outputDir,jobId,onProgress});
      } else if (route === ROUTES.PHOTO_PREMIUM) {
        result = await this.rodin.generate({images:job.input.images,prompt:job.input.prompt,outputDir:this.config.outputDir,jobId,onProgress});
      } else if (route === ROUTES.MATERIAL) {
        const modelDataUri=await assetDataUri(sourceAsset,this.config);
        result=await this.meshy.retexture({modelDataUri,prompt:job.input.prompt,styleImage:job.input.style_image,outputDir:this.config.outputDir,jobId,onProgress});
      } else if (route === ROUTES.PHOTO_BALANCED) {
        result = await this.meshy.generate({images:job.input.images,prompt:job.input.prompt,outputDir:this.config.outputDir,jobId,onProgress});
      } else {
        result = await this.#demoResult({jobId, route, onProgress});
      }
      await this.#progress(jobId, 96, 'Kwaliteitscontrole en mesh-inventaris opbouwen…', 'running');
      const inspection = await inspectGlb(path.join(this.config.outputDir,result.file_name));
      const sourceType = materialJob ? 'ai_retextured' : result.provider === 'freecad' ? 'parametric_cad' : 'ai_generated';
      const assignments = new Map((blueprint.parts || []).flatMap(part => (part.mesh_targets || []).map(name => [name,part.part_id])));
      const workerAssignments = new Map((result.mesh_inventory || []).map(item => [item.mesh_id,item.assigned_part_id]));
      const sourceAssignments=new Map((sourceAsset?.mesh_inventory||[]).map(item=>[item.mesh_id,item.assigned_part_id]));
      const inventory = inspection.mesh_inventory.map((item,index) => ({...item,assigned_part_id:assignments.get(item.mesh_id) || workerAssignments.get(item.mesh_id) || sourceAssignments.get(item.mesh_id) || sourceAsset?.mesh_inventory?.[index]?.assigned_part_id || null}));
      const asset = {
        asset_id:id('asset'), project_id:job.project_id, source_type:sourceType, provider:result.provider,
        provider_task_id:result.provider_task_id || null, file_name:result.file_name, extension:'glb',
        public_url:`/generated/${result.file_name}`, poster_url:result.poster_url || '/assets/demo-table-preview.png',
        provider_previews:result.provider_previews || {}, technical_status:'succeeded',
        quality_status:'pending_review',
        metrics:{...inspection.metrics,...(result.metrics || {})}, mesh_inventory:inventory,
        provenance:{route,provider:result.provider,generated_at:nowIso(),candidate_only:true,parent_asset_id:sourceAsset?.asset_id||null},
        created_at:nowIso()
      };
      await this.store.addAsset(asset);
      await this.store.updateProject(job.project_id, p => ({...p,candidate_asset_id:asset.asset_id,route_decision:job.route_decision}));
      await this.store.updateJob(jobId, current => ({...current,status:'succeeded',progress:100,message:materialJob?'Materiaaldraft klaar voor review.':'3D-draft klaar voor review.',result:{asset_id:asset.asset_id,public_url:asset.public_url,quality_status:asset.quality_status},input:{image_count:current.input.images?.length||0,prompt:current.input.prompt,source_asset_id:current.input.source_asset_id||null}}));
      await this.store.addAudit({project_id:job.project_id,action:'asset_generated',details:{job_id:jobId,asset_id:asset.asset_id,route,provider:result.provider}});
    } catch (error) {
      await this.store.updateJob(jobId, current => ({...current,status:'failed',message:'Generatie mislukt.',error:{message:error.message,code:error.code || null},input:{image_count:current.input?.images?.length || 0,prompt:current.input?.prompt || ''}}));
    } finally { this.running.delete(jobId); }
  }

  #routeAvailable(route) {
    if (route === ROUTES.PHOTO_BALANCED || route === ROUTES.MATERIAL) return this.meshy.available;
    if (route === ROUTES.PHOTO_FAST) return this.tripo.available;
    if (route === ROUTES.PHOTO_PREMIUM) return this.rodin.available;
    if (route === ROUTES.PARAMETRIC) return commandAvailable(this.config.cad.freecadCmd) && commandAvailable(this.config.cad.blenderCmd);
    return true;
  }

  async #demoResult({jobId, route, onProgress}) {
    for (const [progress,message] of [[18,'Bronmateriaal analyseren…'],[38,'Geometrie opbouwen…'],[61,'Onderdelen en materialen structureren…'],[82,'Mobiele GLB optimaliseren…']]) {
      await delay(260); await onProgress({progress,message});
    }
    const filename = `${jobId}-demo-draft.glb`;
    await fs.promises.copyFile(path.join(this.config.root,'public/assets/demo-table.glb'),path.join(this.config.outputDir,filename));
    return {provider:'demo',provider_task_id:`demo-${jobId}`,file_name:filename,poster_url:'/assets/demo-table-preview.png',metrics:{triangles:360,meshes:10,materials:3,mobile_ready:true,demo:true},mesh_inventory:inferMeshInventory(this.store.getBlueprint(this.store.getJob(jobId).project_id))};
  }


  async #demoMaterialResult({jobId,sourceAsset,onProgress}) {
    if(!sourceAsset) throw new Error('Actief bronmodel ontbreekt.');
    for(const [progress,message] of [[24,'Materiaalreferentie analyseren…'],[56,'PBR-oppervlak voorbereiden…'],[84,'Reviewmodel optimaliseren…']]){await delay(220);await onProgress({progress,message});}
    const sourcePath=assetFilePath(sourceAsset,this.config);
    const filename=`${jobId}-demo-material.glb`;
    await fs.promises.copyFile(sourcePath,path.join(this.config.outputDir,filename));
    return {provider:'demo_material',provider_task_id:`demo-material-${jobId}`,file_name:filename,poster_url:sourceAsset.poster_url||'/assets/demo-table-preview.png',metrics:{...(sourceAsset.metrics||{}),pbr:true,retextured:true,demo:true},mesh_inventory:sourceAsset.mesh_inventory||[]};
  }

  async #progress(jobId, progress, message, status='running', providerTaskId=null) {
    return this.store.updateJob(jobId, current => ({...current,status,progress:Math.round(progress),message,provider_task_id:providerTaskId || current.provider_task_id || null}));
  }
}

function factParams(facts) { return Object.fromEntries(facts.filter(f=>f.status==='confirmed').map(f=>[f.key,f.value])); }
function mimeExtension(value='') { return String(value).includes('png') ? 'png' : String(value).includes('webp') ? 'webp' : 'jpg'; }
function commandAvailable(command) {
  if (!command) return false;
  if (path.isAbsolute(command)) return fs.existsSync(command);
  return spawnSync('sh',['-lc',`command -v ${shellQuote(command)}`],{stdio:'ignore'}).status === 0;
}
function shellQuote(value) { return `'${String(value).replaceAll(`'`,`'\''`)}'`; }
function assetFilePath(asset,config){
  const publicUrl=String(asset?.public_url||'');
  if(publicUrl.startsWith('/assets/')) return path.join(config.root,'public',publicUrl);
  if(publicUrl.startsWith('/generated/')) return path.join(config.outputDir,path.basename(publicUrl));
  const outputCandidate=path.join(config.outputDir,path.basename(asset?.file_name||''));
  if(fs.existsSync(outputCandidate)) return outputCandidate;
  const publicCandidate=path.join(config.root,'public/assets',path.basename(asset?.file_name||''));
  if(fs.existsSync(publicCandidate)) return publicCandidate;
  throw new Error('Lokaal bronmodel voor retexture niet gevonden.');
}
async function assetDataUri(asset,config){const file=assetFilePath(asset,config);const data=await fs.promises.readFile(file);return `data:application/octet-stream;base64,${data.toString('base64')}`;}
function delay(ms) { return new Promise(r=>setTimeout(r,ms)); }
function inferMeshInventory(blueprint={}) { return (blueprint.parts || []).flatMap(part => (part.mesh_targets || []).map(mesh_id => ({mesh_id,label:part.label,visible:true,assigned_part_id:part.part_id}))); }
function overrideDecision(provider, imageCount, current) {
  if (provider === 'meshy') return {...current,route:ROUTES.PHOTO_BALANCED,reason:imageCount>1?'Multi-image reconstructie handmatig gekozen.':'Meshy reconstructie handmatig gekozen.',pipeline:['meshy_generation','human_review']};
  if (provider === 'tripo') return {...current,route:ROUTES.PHOTO_FAST,reason:'Snelle reconstructie handmatig gekozen.',pipeline:['tripo_generation','human_review']};
  if (provider === 'rodin') return {...current,route:ROUTES.PHOTO_PREMIUM,reason:'Premium reconstructie handmatig gekozen.',pipeline:['rodin_generation','human_review']};
  if (provider === 'freecad') return {...current,route:ROUTES.PARAMETRIC,reason:'Exact parametrisch model handmatig gekozen.',pipeline:['freecad_generation','configurability_gate']};
  return current;
}
function sanitizeJob(job) {
  const copy=structuredClone(job);
  if(copy.type==='material_retexture') {
    copy.input={
      prompt:copy.input?.prompt || '',
      style_image:Boolean(copy.input?.style_image),
      source_asset_id:copy.input?.source_asset_id || null
    };
  } else if(copy.input?.images) {
    copy.input={image_count:copy.input.images.length,prompt:copy.input.prompt || ''};
  }
  return copy;
}
