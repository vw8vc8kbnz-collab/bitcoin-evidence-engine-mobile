import fs from 'node:fs';
import path from 'node:path';
import { id, nowIso } from '../core/ids.mjs';
import { createDemoBlueprint } from '../core/blueprint.mjs';

export class JsonStore {
  constructor(dataDir) {
    this.file = path.join(dataDir, 'store.json');
    this.writeChain = Promise.resolve();
    this.data = this.#load();
  }

  #load() {
    if (fs.existsSync(this.file)) {
      try { return JSON.parse(fs.readFileSync(this.file, 'utf8')); }
      catch (error) { console.error('Store parse failed, starting from seed:', error.message); }
    }
    return seedStore();
  }

  async save() {
    const payload = JSON.stringify(this.data, null, 2);
    this.writeChain = this.writeChain.then(async () => {
      const temp = `${this.file}.tmp`;
      await fs.promises.writeFile(temp, payload, 'utf8');
      await fs.promises.rename(temp, this.file);
    });
    return this.writeChain;
  }

  getProject(projectId = 'proj_demo_table') { return this.data.projects.find(p => p.project_id === projectId); }
  listProjects() { return [...this.data.projects].sort((a,b) => b.updated_at.localeCompare(a.updated_at)); }
  getBlueprint(projectId = 'proj_demo_table') { return this.data.blueprints[projectId]; }
  getAsset(assetId) { return this.data.assets.find(a => a.asset_id === assetId); }
  listAssets(projectId) { return this.data.assets.filter(a => !projectId || a.project_id === projectId).sort((a,b) => b.created_at.localeCompare(a.created_at)); }
  listJobs(projectId) { return this.data.jobs.filter(j => !projectId || j.project_id === projectId).sort((a,b) => b.created_at.localeCompare(a.created_at)); }
  getJob(jobId) { return this.data.jobs.find(j => j.job_id === jobId); }
  getRuntime(runtimeId) { return this.data.runtimes.find(r => r.runtime_config_id === runtimeId); }

  async addProject(project, blueprint) {
    this.data.projects.push(project);
    this.data.blueprints[project.project_id] = blueprint;
    await this.save();
    return project;
  }

  async updateProject(projectId, updater) {
    const index = this.data.projects.findIndex(p => p.project_id === projectId);
    if (index < 0) throw new Error('Project not found');
    const next = updater(structuredClone(this.data.projects[index]));
    next.updated_at = nowIso();
    this.data.projects[index] = next;
    await this.save();
    return next;
  }

  async setBlueprint(projectId, blueprint) {
    this.data.blueprints[projectId] = { ...structuredClone(blueprint), updated_at: nowIso() };
    await this.save();
    return this.data.blueprints[projectId];
  }

  async addAsset(asset) {
    this.data.assets.push(asset);
    await this.save();
    return asset;
  }

  async addJob(job) {
    this.data.jobs.push(job);
    await this.save();
    return job;
  }

  async updateJob(jobId, patchOrUpdater) {
    const index = this.data.jobs.findIndex(j => j.job_id === jobId);
    if (index < 0) throw new Error('Job not found');
    const current = structuredClone(this.data.jobs[index]);
    const next = typeof patchOrUpdater === 'function' ? patchOrUpdater(current) : { ...current, ...patchOrUpdater };
    next.updated_at = nowIso();
    this.data.jobs[index] = next;
    await this.save();
    return next;
  }

  async addAudit(entry) {
    this.data.audit_log.push({ audit_id: id('audit'), created_at: nowIso(), ...entry });
    if (this.data.audit_log.length > 1000) this.data.audit_log = this.data.audit_log.slice(-1000);
    await this.save();
  }

  async addRuntime(runtime) {
    this.data.runtimes.push(runtime);
    await this.updateProject(runtime.project_id, project => ({ ...project, status:'published', runtime_version: runtime.version, published_runtime_id: runtime.runtime_config_id }));
    await this.save();
    return runtime;
  }
}

function seedStore() {
  const created = nowIso();
  return {
    schema_version: '2.0.0',
    workspaces: [{ workspace_id: 'ws_demo', name: 'Demo Workspace', created_at: created }],
    projects: [{
      project_id: 'proj_demo_table', workspace_id: 'ws_demo', name: 'Nordic Table Configurator', description: 'Premium configureerbare tafel als volledig werkende demo.',
      status: 'draft', created_at: created, updated_at: created, runtime_version: 0, published_runtime_id: null,
      active_asset_id: 'asset_demo_table',
      intake: { prompt: 'Een premium rechthoekige eettafel met verwisselbaar blad en framekleur.', category: 'table', requested_profile: 'auto' },
      required_fact_keys: ['dimensions.length_mm','dimensions.width_mm','dimensions.height_mm'],
      facts: [
        confirmedFact('dimensions.length_mm','Lengte',1800,'mm'),
        confirmedFact('dimensions.width_mm','Breedte',900,'mm'),
        confirmedFact('dimensions.height_mm','Hoogte',760,'mm'),
        confirmedFact('product.category','Productcategorie','table',null,'text')
      ],
      clarification_questions: [], candidate_blueprint: null, route_decision: null
    }],
    blueprints: { proj_demo_table: createDemoBlueprint() },
    assets: [{
      asset_id: 'asset_demo_table', project_id: 'proj_demo_table', source_type: 'verified_upload', provider: null,
      file_name: 'demo-table.glb', extension: 'glb', public_url: '/assets/demo-table.glb', poster_url: '/assets/demo-table-preview.png',
      quality_status: 'accepted', technical_status: 'succeeded', created_at: created,
      metrics: { triangles: 360, meshes: 10, materials: 3, mobile_ready: true },
      mesh_inventory: [
        { mesh_id: 'tabletop_main', label: 'Tafelblad', visible: true, assigned_part_id: 'part_tabletop' },
        { mesh_id: 'tabletop_inlay', label: 'Accentstrip', visible: true, assigned_part_id: 'part_inlay' },
        { mesh_id: 'apron_left', label: 'Frame links', visible: true, assigned_part_id: 'part_frame' },
        { mesh_id: 'apron_right', label: 'Frame rechts', visible: true, assigned_part_id: 'part_frame' },
        { mesh_id: 'apron_front', label: 'Frame voor', visible: true, assigned_part_id: 'part_frame' },
        { mesh_id: 'apron_back', label: 'Frame achter', visible: true, assigned_part_id: 'part_frame' },
        { mesh_id: 'leg_front_left', label: 'Poot linksvoor', visible: true, assigned_part_id: 'part_frame' },
        { mesh_id: 'leg_front_right', label: 'Poot rechtsvoor', visible: true, assigned_part_id: 'part_frame' },
        { mesh_id: 'leg_back_left', label: 'Poot linksachter', visible: true, assigned_part_id: 'part_frame' },
        { mesh_id: 'leg_back_right', label: 'Poot rechtsachter', visible: true, assigned_part_id: 'part_frame' }
      ]
    }],
    jobs: [], runtimes: [], audit_log: []
  };
}

function confirmedFact(key, label, value, unit, valueType = 'measurement') {
  return {
    fact_id: id('fact'), key, label, value, unit, value_type: valueType, critical: key.startsWith('dimensions.'), candidates: [],
    verified: { by: 'seed_admin', method: 'imported_verified', at: nowIso() }, conflict: null, status: 'confirmed', pricing_allowed: true, updated_at: nowIso()
  };
}
