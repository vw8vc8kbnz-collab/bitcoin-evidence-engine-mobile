import { id, nowIso } from './ids.mjs';

export function createDemoBlueprint() {
  return {
    schema_version: '2.0.0',
    blueprint_id: id('blueprint'),
    updated_at: nowIso(),
    parts: [
      { part_id: 'part_tabletop', label: 'Tafelblad', scope: 'part', type: 'surface', mesh_targets: ['tabletop_main'], configurable: true, capabilities: ['material','finish','pricing','order_output'] },
      { part_id: 'part_inlay', label: 'Accentstrip', scope: 'material_zone', type: 'surface', mesh_targets: ['tabletop_inlay'], configurable: true, capabilities: ['material','finish','pricing'] },
      { part_id: 'part_frame', label: 'Frame en poten', scope: 'part', type: 'frame', mesh_targets: ['apron_left','apron_right','apron_front','apron_back','leg_front_left','leg_front_right','leg_back_left','leg_back_right'], configurable: true, capabilities: ['material','visibility','pricing','rules','order_output'] }
    ],
    option_groups: [
      {
        option_group_id: 'group_tabletop_material', label: 'Bladmateriaal', target_scope: 'part', target_id: 'part_tabletop', control_type: 'swatches', effect_type: 'material', required: true,
        options: [
          { option_id: 'oak_natural', label: 'Naturel eiken', value: '#b88758', material: { color: '#b88758', roughness: 0.55 } },
          { option_id: 'walnut', label: 'Walnoot', value: '#6d442d', material: { color: '#6d442d', roughness: 0.5 } },
          { option_id: 'black_oak', label: 'Zwart eiken', value: '#292723', material: { color: '#292723', roughness: 0.62 } }
        ]
      },
      {
        option_group_id: 'group_frame_color', label: 'Framekleur', target_scope: 'part', target_id: 'part_frame', control_type: 'swatches', effect_type: 'material', required: true,
        options: [
          { option_id: 'frame_black', label: 'Mat zwart', value: '#171717', material: { color: '#171717', metalness: 0.65, roughness: 0.35 } },
          { option_id: 'frame_sand', label: 'Zand', value: '#b9aa92', material: { color: '#b9aa92', metalness: 0.45, roughness: 0.45 } }
        ]
      }
    ],
    pricing: {
      currency: 'EUR',
      base_price: { amount: 799, label: 'Basisprijs' },
      rules: [
        { rule_id: 'price_walnut', label: 'Walnoot blad', type: 'fixed_delta', option_id: 'walnut', amount: 120, enabled: true },
        { rule_id: 'price_black_oak', label: 'Zwart eiken', type: 'fixed_delta', option_id: 'black_oak', amount: 65, enabled: true },
        { rule_id: 'price_sand_frame', label: 'Zandkleurig frame', type: 'fixed_delta', option_id: 'frame_sand', amount: 45, enabled: true }
      ]
    },
    rules: [],
    order_output: {
      fields: [
        { field_id: 'configuration_id', label: 'Configuratie-ID', source: 'system.configuration_id', required: true },
        { field_id: 'tabletop_material', label: 'Bladmateriaal', source: 'selection.group_tabletop_material', required: true },
        { field_id: 'frame_color', label: 'Framekleur', source: 'selection.group_frame_color', required: true },
        { field_id: 'preview_image', label: 'Voorbeeldafbeelding', source: 'system.preview_url', required: false }
      ]
    }
  };
}
