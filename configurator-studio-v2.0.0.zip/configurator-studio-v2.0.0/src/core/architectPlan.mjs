import { id, nowIso } from './ids.mjs';

const ALLOWED_CAPABILITIES=new Set(['material','finish','visibility','pricing','rules','order_output','dimensions','geometry_variant']);
const COLORS=['#b88758','#292723','#b9aa92','#6d442d','#62756a','#d8d2c7'];

export function applyArchitectPlan(existing,plan={}) {
  const blueprint=structuredClone(existing||{});
  const used=new Set();
  const parts=(plan.parts||[]).map((raw,index)=>{
    const partId=uniqueId(`part_${slug(raw.label||`onderdeel_${index+1}`)}`,used);
    const capabilities=(raw.capabilities||[]).filter(x=>ALLOWED_CAPABILITIES.has(x));
    return {part_id:partId,label:raw.label||`Onderdeel ${index+1}`,scope:'part',type:'surface',mesh_targets:[],configurable:true,capabilities:capabilities.length?capabilities:['material','pricing']};
  });
  const partByLabel=new Map(parts.map(p=>[p.label.toLowerCase(),p]));
  const optionGroups=(plan.option_groups||[]).map((raw,index)=>{
    const target=partByLabel.get(String(raw.target_part||'').toLowerCase())||parts[index%Math.max(parts.length,1)]||null;
    const groupId=uniqueId(`group_${slug(raw.label||`opties_${index+1}`)}`,used);
    const examples=(raw.option_examples||[]).slice(0,8);
    return {option_group_id:groupId,label:raw.label||`Opties ${index+1}`,target_scope:'part',target_id:target?.part_id||null,control_type:'swatches',effect_type:'material',required:false,options:(examples.length?examples:['Standaard']).map((label,i)=>({option_id:uniqueId(`${groupId}_${slug(label)}`,used),label,value:COLORS[i%COLORS.length],material:{color:COLORS[i%COLORS.length],roughness:.5}}))};
  });
  blueprint.schema_version='2.0.0'; blueprint.blueprint_id=blueprint.blueprint_id||id('blueprint'); blueprint.updated_at=nowIso();
  blueprint.parts=parts; blueprint.option_groups=optionGroups;
  blueprint.pricing=blueprint.pricing||{currency:'EUR',base_price:{amount:0,label:'Basisprijs'},rules:[]};
  blueprint.rules=[];
  blueprint.order_output={fields:[{field_id:'configuration_id',label:'Configuratie-ID',source:'system.configuration_id',required:true},...optionGroups.map(g=>({field_id:g.option_group_id,label:g.label,source:`selection.${g.option_group_id}`,required:Boolean(g.required)}))]};
  return blueprint;
}
function slug(value){return String(value||'item').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,'_').replace(/^_+|_+$/g,'').slice(0,45)||'item'}
function uniqueId(base,used){let value=base,n=2;while(used.has(value))value=`${base}_${n++}`;used.add(value);return value}
