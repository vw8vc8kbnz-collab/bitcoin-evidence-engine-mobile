import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

export class ProductViewer {
  constructor(container,{onSelect=()=>{},onReady=()=>{},onError=()=>{}}={}) {
    this.container=container; this.onSelect=onSelect; this.onReady=onReady; this.onError=onError;
    this.abort=new AbortController(); this.meshes=[]; this.materialBackups=new Map(); this.model=null; this.animation=null;
    this.scene=new THREE.Scene(); this.scene.background=new THREE.Color(0xf2ede5);
    this.camera=new THREE.PerspectiveCamera(38,1,.01,200);
    this.renderer=new THREE.WebGLRenderer({antialias:true,alpha:false,powerPreference:'high-performance'});
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,2)); this.renderer.outputColorSpace=THREE.SRGBColorSpace; this.renderer.toneMapping=THREE.ACESFilmicToneMapping; this.renderer.toneMappingExposure=1.08;
    this.renderer.shadowMap.enabled=true; this.renderer.shadowMap.type=THREE.PCFSoftShadowMap;
    container.replaceChildren(this.renderer.domElement);
    this.controls=new OrbitControls(this.camera,this.renderer.domElement); this.controls.enableDamping=true; this.controls.dampingFactor=.06; this.controls.enablePan=false; this.controls.minDistance=.35; this.controls.maxDistance=12;
    this.scene.add(new THREE.HemisphereLight(0xfffdf8,0x8e8273,2.4));
    const key=new THREE.DirectionalLight(0xffffff,3.2); key.position.set(3.5,5,4); key.castShadow=true; this.scene.add(key);
    const fill=new THREE.DirectionalLight(0xc8d8d1,1.3); fill.position.set(-4,2,-2); this.scene.add(fill);
    const rim=new THREE.DirectionalLight(0xffdfbd,1.2); rim.position.set(0,3,-5); this.scene.add(rim);
    this.raycaster=new THREE.Raycaster(); this.pointer=new THREE.Vector2();
    this.renderer.domElement.addEventListener('pointerdown',e=>this.#pick(e),{signal:this.abort.signal,passive:true});
    this.resizeObserver=new ResizeObserver(()=>this.resize()); this.resizeObserver.observe(container);
    this.resize(); this.#animate();
  }
  async load(url) {
    this.#clearModel();
    try {
      const loader=new GLTFLoader();
      const gltf=await loader.loadAsync(`${url}${url.includes('?')?'&':'?'}v=${Date.now()}`);
      this.model=gltf.scene; this.meshes=[];
      this.model.traverse(object=>{
        if(!object.isMesh)return;
        object.castShadow=true; object.receiveShadow=true;
        if(Array.isArray(object.material)) object.material=object.material.map(m=>m.clone()); else object.material=(object.material||new THREE.MeshStandardMaterial({color:0xb98b60,roughness:.55})).clone();
        const mats=Array.isArray(object.material)?object.material:[object.material]; mats.forEach(m=>{m.side=THREE.DoubleSide;m.needsUpdate=true});
        this.meshes.push(object); this.materialBackups.set(object.uuid,mats.map(m=>({emissive:m.emissive?.clone(),emissiveIntensity:m.emissiveIntensity||0})));
      });
      this.scene.add(this.model); this.fit(); this.onReady({meshes:this.meshes.map(m=>m.name)}); return true;
    } catch(error){this.onError(error);return false;}
  }
  fit() {
    if(!this.model)return;
    const box=new THREE.Box3().setFromObject(this.model); const sphere=box.getBoundingSphere(new THREE.Sphere()); const size=Math.max(sphere.radius,0.1);
    this.controls.target.copy(sphere.center); this.camera.near=Math.max(size/100,.01); this.camera.far=Math.max(size*100,100); this.camera.updateProjectionMatrix();
    this.camera.position.copy(sphere.center).add(new THREE.Vector3(size*1.55,size*1.15,size*1.75)); this.controls.minDistance=size*.55; this.controls.maxDistance=size*8; this.controls.update();
  }
  reset(){this.fit()}
  highlight(targetNames=[]) {
    const names=new Set(Array.isArray(targetNames)?targetNames:[targetNames]);
    for(const mesh of this.meshes){
      const selected=names.has(mesh.name); const materials=Array.isArray(mesh.material)?mesh.material:[mesh.material]; const backups=this.materialBackups.get(mesh.uuid)||[];
      materials.forEach((m,i)=>{if(!m.emissive)return;m.emissive.copy(selected?new THREE.Color(0x4d8b6c):(backups[i]?.emissive||new THREE.Color(0)));m.emissiveIntensity=selected?.22:(backups[i]?.emissiveIntensity||0)});
    }
  }
  applyMaterial(targetNames,material={}) {
    const names=new Set(targetNames||[]); for(const mesh of this.meshes){if(!names.has(mesh.name))continue;const mats=Array.isArray(mesh.material)?mesh.material:[mesh.material];for(const m of mats){if(material.color)m.color.set(material.color);if(Number.isFinite(Number(material.roughness)))m.roughness=Number(material.roughness);if(Number.isFinite(Number(material.metalness)))m.metalness=Number(material.metalness);m.needsUpdate=true}}
  }
  resize(){const w=Math.max(1,this.container.clientWidth),h=Math.max(1,this.container.clientHeight);this.camera.aspect=w/h;this.camera.updateProjectionMatrix();this.renderer.setSize(w,h,false)}
  async fullscreen(){if(!document.fullscreenElement)await this.container.parentElement.requestFullscreen?.();else await document.exitFullscreen?.()}
  dispose(){this.abort.abort();this.resizeObserver?.disconnect();cancelAnimationFrame(this.animation);this.#clearModel();this.controls?.dispose();this.renderer?.dispose();this.renderer?.forceContextLoss();this.container.replaceChildren()}
  #clearModel(){if(!this.model)return;this.scene.remove(this.model);this.model.traverse(o=>{o.geometry?.dispose?.();const mats=Array.isArray(o.material)?o.material:[o.material];mats.filter(Boolean).forEach(m=>{for(const key of Object.keys(m)){if(m[key]?.isTexture)m[key].dispose()}m.dispose?.()})});this.model=null;this.meshes=[];this.materialBackups.clear()}
  #pick(event){if(!this.meshes.length)return;const rect=this.renderer.domElement.getBoundingClientRect();this.pointer.x=((event.clientX-rect.left)/rect.width)*2-1;this.pointer.y=-((event.clientY-rect.top)/rect.height)*2+1;this.raycaster.setFromCamera(this.pointer,this.camera);const hit=this.raycaster.intersectObjects(this.meshes,true)[0];if(hit)this.onSelect(hit.object.name)}
  #animate(){this.controls.update();this.renderer.render(this.scene,this.camera);this.animation=requestAnimationFrame(()=>this.#animate())}
}
