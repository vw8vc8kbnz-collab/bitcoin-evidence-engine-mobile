import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { config } from './src/server/config.mjs';
import { JsonStore } from './src/server/store.mjs';
import { JobRunner } from './src/server/jobRunner.mjs';
import { OpenAIProductArchitect } from './src/providers/openaiProductArchitect.mjs';
import { mergeCandidateFacts, confirmFact } from './src/core/truthGraph.mjs';
import { calculatePrice } from './src/core/pricing.mjs';
import { runPublishGate, inspectConfigurability } from './src/core/gates.mjs';
import { compileRuntime } from './src/core/runtimeCompiler.mjs';
import { applyArchitectPlan } from './src/core/architectPlan.mjs';
import { inspectGlb } from './src/server/glbInspector.mjs';
import { id, nowIso } from './src/core/ids.mjs';
import { createDemoBlueprint } from './src/core/blueprint.mjs';
import { parseDataUri } from './src/providers/common.mjs';
import { SessionAuth } from './src/server/auth.mjs';

const store = new JsonStore(config.dataDir);
await store.save();
const runner = new JobRunner({config,store});
const architect = new OpenAIProductArchitect(config.openai);
const startedAt = new Date().toISOString();
const auth = new SessionAuth(config.auth);
const loginAttempts = new Map();

const server = http.createServer(async (req,res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    if (url.pathname.startsWith('/api/')) return await api(req,res,url);
    if (url.pathname.startsWith('/generated/')) return serveFile(res,path.join(config.outputDir,path.basename(url.pathname)),false);
    if (url.pathname.startsWith('/runtime/')) return serveFile(res,path.join(config.root,'public/runtime.html'),false);
    if ((url.pathname === '/' || url.pathname === '/index.html') && auth.enabled && !auth.verifyRequest(req)) return serveFile(res,path.join(config.root,'public/login.html'),true);
    if (url.pathname === '/login.html' && auth.enabled && auth.verifyRequest(req)) return redirect(res,'/');
    return serveStatic(res,url.pathname);
  } catch (error) {
    console.error(error);
    return json(res,error.status || 500,{ok:false,error:error.message,code:error.code || null,gate:error.gate || undefined});
  }
});

async function api(req,res,url) {
  if (req.method === 'GET' && url.pathname === '/api/health') return json(res,200,{ok:true,service:'configurator-studio',version:'2.0.0',started_at:startedAt,uptime_seconds:Math.round(process.uptime()),demo_mode:config.demoMode,auth_enabled:auth.enabled,providers:runner.availability()});
  if (req.method === 'GET' && url.pathname === '/api/auth/status') return json(res,200,{ok:true,enabled:auth.enabled,authenticated:auth.verifyRequest(req)});
  if (req.method === 'POST' && url.pathname === '/api/auth/login') {
    if (!auth.enabled) return json(res,200,{ok:true,enabled:false});
    const ip=req.socket.remoteAddress || 'unknown'; const attempt=loginAttempts.get(ip) || {count:0,blocked_until:0}; const now=Date.now();
    if (attempt.blocked_until > now) return json(res,429,{ok:false,error:'Te veel mislukte pogingen. Probeer het over enkele minuten opnieuw.'},{'Retry-After':String(Math.ceil((attempt.blocked_until-now)/1000))});
    const body=await readJson(req);
    if (!auth.credentialsValid(body.username,body.password)) {
      const count=attempt.count+1; loginAttempts.set(ip,{count:count>=5?0:count,blocked_until:count>=5?now+15*60*1000:0});
      return json(res,401,{ok:false,error:'Gebruikersnaam of wachtwoord is onjuist.'});
    }
    loginAttempts.delete(ip); const token=auth.createSession();
    return json(res,200,{ok:true,authenticated:true},{'Set-Cookie':auth.sessionCookie(token)});
  }
  if (req.method === 'POST' && url.pathname === '/api/auth/logout') return json(res,200,{ok:true},{'Set-Cookie':auth.clearCookie()});
  if (req.method === 'GET' && url.pathname.startsWith('/api/runtime/')) { const runtime=store.getRuntime(pathnameId(url.pathname)); return runtime?json(res,200,{ok:true,runtime}):json(res,404,{ok:false,error:'Runtime niet gevonden.'}); }
  if (auth.enabled && !auth.verifyRequest(req)) return json(res,401,{ok:false,error:'Je sessie is verlopen. Log opnieuw in.',code:'AUTH_REQUIRED'});
  if (req.method === 'GET' && url.pathname === '/api/studio') return studioState(res,url.searchParams.get('project_id') || 'proj_demo_table');
  if (req.method === 'GET' && url.pathname === '/api/projects') return json(res,200,{ok:true,projects:store.listProjects().map(p=>({project_id:p.project_id,name:p.name,status:p.status,updated_at:p.updated_at,active_asset_id:p.active_asset_id}))});
  if (req.method === 'POST' && url.pathname === '/api/projects') {
    const body=await readJson(req); const projectId=id('proj'); const created=nowIso(); const category=String(body.category||'').trim();
    const project={project_id:projectId,workspace_id:'ws_demo',name:String(body.name||'Nieuw configuratorproject').slice(0,120),description:String(body.description||''),status:'draft',created_at:created,updated_at:created,runtime_version:0,published_runtime_id:null,active_asset_id:null,candidate_asset_id:null,intake:{prompt:String(body.description||''),category,requested_profile:'auto'},required_fact_keys:['dimensions.length_mm','dimensions.width_mm','dimensions.height_mm'],facts:[newMissingFact('dimensions.length_mm','Lengte','mm'),newMissingFact('dimensions.width_mm','Breedte','mm'),newMissingFact('dimensions.height_mm','Hoogte','mm'),...(category?[confirmedTextFact('product.category','Productcategorie',category)]:[])],clarification_questions:[],candidate_blueprint:null,route_decision:null};
    const blueprint=createDemoBlueprint(); blueprint.parts=[]; blueprint.option_groups=[]; blueprint.pricing={currency:'EUR',base_price:{amount:0,label:'Basisprijs'},rules:[]}; blueprint.rules=[]; blueprint.order_output={fields:[{field_id:'configuration_id',label:'Configuratie-ID',source:'system.configuration_id',required:true}]};
    await store.addProject(project,blueprint); await store.addAudit({project_id:projectId,action:'project_created',details:{category}}); return json(res,201,{ok:true,project});
  }
  if (req.method === 'POST' && url.pathname === '/api/project/update') {
    const body=await readJson(req); const project=mustProject(body.project_id || 'proj_demo_table'); const allowed={}; for(const key of ['name','description'])if(body[key]!==undefined)allowed[key]=String(body[key]).slice(0,key==='name'?120:2000); const updated=await store.updateProject(project.project_id,p=>({...p,...allowed})); return json(res,200,{ok:true,project:updated});
  }
  if (req.method === 'GET' && url.pathname.startsWith('/api/jobs/')) {
    const job=store.getJob(pathnameId(url.pathname)); if(!job) return json(res,404,{ok:false,error:'Taak niet gevonden.'}); return json(res,200,{ok:true,job:sanitizeJob(job)});
  }
  if (req.method === 'POST' && url.pathname === '/api/architect/analyze') {
    const body=await readJson(req); const projectId=body.project_id || 'proj_demo_table'; const project=mustProject(projectId);
    const result=await architect.analyze({prompt:body.prompt || project.intake.prompt,images:body.images || []});
    const facts=mergeCandidateFacts(project.facts || [],result.candidate_facts || []);
    const updated=await store.updateProject(projectId,p=>({...p,intake:{...p.intake,prompt:body.prompt || p.intake.prompt,category:result.category || p.intake.category,requested_profile:body.requested_profile || p.intake.requested_profile},facts,clarification_questions:result.clarification_questions || [],candidate_blueprint:result.configuration_plan,architect_summary:result.summary,risk_notes:result.risk_notes || []}));
    await store.addAudit({project_id:projectId,action:'architect_analysis',details:{live:architect.available,image_count:(body.images||[]).length}});
    return json(res,200,{ok:true,analysis:result,project:updated});
  }
  if (req.method === 'POST' && url.pathname === '/api/architect/apply-plan') {
    const body=await readJson(req); const project=mustProject(body.project_id || 'proj_demo_table'); if(!project.candidate_blueprint)return json(res,409,{ok:false,error:'Er is nog geen Product Architect-voorstel.'}); const blueprint=applyArchitectPlan(store.getBlueprint(project.project_id),project.candidate_blueprint); await store.setBlueprint(project.project_id,blueprint); await store.addAudit({project_id:project.project_id,action:'architect_plan_applied',details:{parts:blueprint.parts.length,option_groups:blueprint.option_groups.length}}); return json(res,200,{ok:true,blueprint});
  }
  if (req.method === 'POST' && url.pathname === '/api/facts/confirm') {
    const body=await readJson(req); const project=mustProject(body.project_id || 'proj_demo_table'); const index=project.facts.findIndex(f=>f.key===body.key);
    if(index<0) return json(res,404,{ok:false,error:'Gegeven niet gevonden.'});
    const next=confirmFact(project.facts[index],{value:body.value,unit:body.unit,by:'studio_user',method:'user_confirmed'});
    const updated=await store.updateProject(project.project_id,p=>{p.facts[index]=next; return p;});
    await store.addAudit({project_id:project.project_id,action:'fact_confirmed',details:{key:body.key}});
    return json(res,200,{ok:true,project:updated});
  }
  if (req.method === 'POST' && url.pathname === '/api/assets/upload') {
    const body=await readJson(req); const project=mustProject(body.project_id || 'proj_demo_table'); const name=String(body.name||'model.glb'); if(!name.toLowerCase().endsWith('.glb'))return json(res,400,{ok:false,error:'Alleen .glb-upload wordt in deze release direct ondersteund.'}); const {buffer}=parseDataUri(body.data_url); if(buffer.length>config.limits.uploadBytes)return json(res,413,{ok:false,error:'GLB is groter dan de ingestelde uploadlimiet.'}); const fileName=`${id('upload')}.glb`; const filePath=path.join(config.outputDir,fileName); await fs.promises.writeFile(filePath,buffer); const inspection=await inspectGlb(filePath); const blueprint=store.getBlueprint(project.project_id); const assignmentMap=new Map((blueprint.parts||[]).flatMap(part=>(part.mesh_targets||[]).map(mesh=>[mesh,part.part_id]))); const asset={asset_id:id('asset'),project_id:project.project_id,source_type:'uploaded_asset',provider:null,file_name:fileName,original_file_name:name,extension:'glb',public_url:`/generated/${fileName}`,poster_url:'/assets/demo-table-preview.png',technical_status:'succeeded',quality_status:'pending_review',metrics:inspection.metrics,mesh_inventory:inspection.mesh_inventory.map(item=>({...item,assigned_part_id:assignmentMap.get(item.mesh_id)||null})),provenance:{uploaded_by:'studio_user',uploaded_at:nowIso(),candidate_only:true},created_at:nowIso()}; await store.addAsset(asset); await store.updateProject(project.project_id,p=>({...p,candidate_asset_id:asset.asset_id,route_decision:{route:'uploaded_asset',reason:'Bestaand GLB-bestand aangeleverd.',automatic_publish_allowed:false}})); await store.addAudit({project_id:project.project_id,action:'glb_uploaded',details:{asset_id:asset.asset_id,file_bytes:inspection.metrics.file_bytes}}); return json(res,201,{ok:true,asset});
  }
  if (req.method === 'POST' && url.pathname === '/api/generation/start') {
    const body=await readJson(req); const images=validateImages(body.images || []);
    const job=await runner.create({projectId:body.project_id || 'proj_demo_table',images,requestedProfile:body.requested_profile || 'auto',providerOverride:body.provider || null,prompt:body.prompt || ''});
    return json(res,202,{ok:true,job});
  }
  if (req.method === 'POST' && url.pathname === '/api/material/retexture') {
    const body=await readJson(req); const project=mustProject(body.project_id || 'proj_demo_table');
    const prompt=String(body.prompt||'').trim(); const styleImage=body.style_image?validateImages([body.style_image])[0]:null;
    const job=await runner.createRetexture({projectId:project.project_id,assetId:body.asset_id||project.active_asset_id,prompt,styleImage});
    return json(res,202,{ok:true,job});
  }
  if (req.method === 'POST' && /^\/api\/assets\/[^/]+\/map$/.test(url.pathname)) {
    const assetId=url.pathname.split('/')[3]; const body=await readJson(req); const asset=store.getAsset(assetId); if(!asset)return json(res,404,{ok:false,error:'Asset niet gevonden.'}); const blueprint=store.getBlueprint(asset.project_id); const assignments=body.assignments||{}; for(const mesh of asset.mesh_inventory||[])mesh.assigned_part_id=assignments[mesh.mesh_id]??mesh.assigned_part_id??null; for(const part of blueprint.parts||[])part.mesh_targets=(asset.mesh_inventory||[]).filter(m=>m.assigned_part_id===part.part_id).map(m=>m.mesh_id); await store.setBlueprint(asset.project_id,blueprint); await store.save(); await store.addAudit({project_id:asset.project_id,action:'mesh_mapping_updated',details:{asset_id:asset.asset_id,assigned:(asset.mesh_inventory||[]).filter(m=>m.assigned_part_id).length}}); return json(res,200,{ok:true,asset,blueprint});
  }
  if (req.method === 'POST' && /^\/api\/assets\/[^/]+\/review$/.test(url.pathname)) {
    const assetId=url.pathname.split('/')[3]; const body=await readJson(req); const asset=store.getAsset(assetId); if(!asset)return json(res,404,{ok:false,error:'Asset niet gevonden.'});
    asset.quality_status=body.accepted ? 'accepted' : 'rejected'; asset.review={by:'studio_user',at:new Date().toISOString(),notes:body.notes || ''}; asset.provenance={...(asset.provenance||{}),candidate_only:!body.accepted,reviewed_at:asset.review.at,reviewed_by:asset.review.by}; await store.save();
    if(body.accepted) await store.updateProject(asset.project_id,p=>({...p,active_asset_id:asset.asset_id,candidate_asset_id:null}));
    await store.addAudit({project_id:asset.project_id,action:body.accepted?'asset_accepted':'asset_rejected',details:{asset_id:asset.asset_id}});
    return json(res,200,{ok:true,asset});
  }
  if (req.method === 'POST' && url.pathname === '/api/blueprint/update') {
    const body=await readJson(req); mustProject(body.project_id || 'proj_demo_table'); const blueprint=await store.setBlueprint(body.project_id || 'proj_demo_table',body.blueprint); return json(res,200,{ok:true,blueprint});
  }
  if (req.method === 'POST' && url.pathname === '/api/price/calculate') {
    const body=await readJson(req); const project=mustProject(body.project_id || 'proj_demo_table'); const blueprint=store.getBlueprint(project.project_id);
    return json(res,200,{ok:true,price:calculatePrice({pricing:blueprint.pricing,selected_option_ids:body.selected_option_ids || [],facts:project.facts,quantity:body.quantity || 1})});
  }
  if (req.method === 'GET' && url.pathname === '/api/publish/gate') {
    const project=mustProject(url.searchParams.get('project_id') || 'proj_demo_table'); const blueprint=store.getBlueprint(project.project_id); const asset=store.getAsset(project.active_asset_id); return json(res,200,{ok:true,gate:runPublishGate({project,blueprint,asset}),configurability:inspectConfigurability(asset,blueprint)});
  }
  if (req.method === 'POST' && url.pathname === '/api/publish') {
    const body=await readJson(req); const project=mustProject(body.project_id || 'proj_demo_table'); const blueprint=store.getBlueprint(project.project_id); const asset=store.getAsset(project.active_asset_id); const runtime=compileRuntime({project,blueprint,asset}); await store.addRuntime(runtime); await store.addAudit({project_id:project.project_id,action:'runtime_published',details:{runtime_id:runtime.runtime_config_id,version:runtime.version}}); return json(res,201,{ok:true,runtime,public_url:`/runtime/${runtime.runtime_config_id}`});
  }
  return json(res,404,{ok:false,error:'API-route niet gevonden.'});
}

function studioState(res,projectId) {
  const project=mustProject(projectId); const blueprint=store.getBlueprint(projectId); const assets=store.listAssets(projectId); const active=store.getAsset(project.active_asset_id); const candidate=project.candidate_asset_id?store.getAsset(project.candidate_asset_id):null;
  return json(res,200,{ok:true,version:'2.0.0',project,blueprint,assets:assets.map(sanitizeAsset),active_asset:sanitizeAsset(active),candidate_asset:sanitizeAsset(candidate),jobs:store.listJobs(projectId).slice(0,12).map(sanitizeJob),providers:runner.availability(),publish_gate:runPublishGate({project,blueprint,asset:active}),configurability:inspectConfigurability(active,blueprint),runtime:project.published_runtime_id?store.getRuntime(project.published_runtime_id):null});
}
function mustProject(id){const p=store.getProject(id);if(!p){const e=new Error('Project niet gevonden.');e.status=404;throw e;}return p;}
function pathnameId(pathname){return decodeURIComponent(pathname.split('/').filter(Boolean).at(-1));}
function sanitizeJob(job){if(!job)return null;const c=structuredClone(job);if(c.input?.images)c.input={image_count:c.input.images.length,prompt:c.input.prompt};return c;}
function sanitizeAsset(asset){if(!asset)return null;return structuredClone(asset);}
function validateImages(images){if(images.length>5)throw new Error('Maximaal vijf beelden per analyse; 3D-providers gebruiken maximaal vier of vijf volgens hun route.');return images.map((img,i)=>{if(!String(img.data_url||'').startsWith('data:image/'))throw new Error(`Afbeelding ${i+1} is ongeldig.`);return {name:String(img.name||`image-${i+1}.jpg`).slice(0,120),type:String(img.type||'image/jpeg'),data_url:img.data_url};});}
async function readJson(req){let size=0;const chunks=[];for await(const chunk of req){size+=chunk.length;if(size>config.limits.requestBytes){const e=new Error('Aanvraag is te groot.');e.status=413;throw e;}chunks.push(chunk);}if(!chunks.length)return{};try{return JSON.parse(Buffer.concat(chunks).toString('utf8'));}catch{const e=new Error('Ongeldige JSON.');e.status=400;throw e;}}
function json(res,status,payload,headers={}){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff',...headers});res.end(JSON.stringify(payload));}
function redirect(res,location){res.writeHead(302,{Location:location,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end()}
function serveStatic(res,pathname){const rel=pathname==='/'?'index.html':decodeURIComponent(pathname).replace(/^\/+/, '');const file=path.resolve(config.root,'public',rel);const base=path.resolve(config.root,'public');if(file!==base&&!file.startsWith(base+path.sep))return json(res,403,{ok:false,error:'Verboden pad.'});return serveFile(res,file,rel==='index.html');}
function serveFile(res,file,noCache=false){if(!fs.existsSync(file)||!fs.statSync(file).isFile())return json(res,404,{ok:false,error:'Bestand niet gevonden.'});const ext=path.extname(file).toLowerCase();const type=({'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp','.svg':'image/svg+xml','.glb':'model/gltf-binary','.ico':'image/x-icon'})[ext]||'application/octet-stream';const headers={'Content-Type':type,'Content-Length':fs.statSync(file).size,'Cache-Control':noCache?'no-store':'public, max-age=3600','X-Content-Type-Options':'nosniff','Referrer-Policy':'same-origin'};if(path.basename(file)==='login.html')headers['X-Frame-Options']='DENY';res.writeHead(200,headers);fs.createReadStream(file).pipe(res);}

function newMissingFact(key,label,unit){return {fact_id:id('fact'),key,label,value:null,unit,value_type:'measurement',critical:true,candidates:[],verified:{by:null,method:'none',at:null},conflict:null,status:'missing',pricing_allowed:false,updated_at:nowIso()};}
function confirmedTextFact(key,label,value){return {fact_id:id('fact'),key,label,value,unit:null,value_type:'text',critical:false,candidates:[],verified:{by:'studio_user',method:'user_confirmed',at:nowIso()},conflict:null,status:'confirmed',pricing_allowed:true,updated_at:nowIso()};}

server.listen(config.port,config.host,()=>console.log(`Configurator Studio v2.0.0 listening on http://${config.host}:${config.port}`));
