#!/usr/bin/env bash
set -euo pipefail

APP_DIR="${APP_DIR:-/var/www/configurator-studio}"
SERVICE="configurator-studio.service"

[ "$(id -u)" -eq 0 ] || { echo "Voer dit script uit met sudo/root." >&2; exit 1; }
cd "$APP_DIR"
command -v node >/dev/null || { echo "Node.js 20+ ontbreekt" >&2; exit 1; }
NODE_MAJOR="$(node -p 'process.versions.node.split(`.`)[0]')"
[ "$NODE_MAJOR" -ge 20 ] || { echo "Node.js 20+ vereist; gevonden $(node -v)" >&2; exit 1; }
command -v curl >/dev/null || { echo "curl ontbreekt" >&2; exit 1; }
command -v python3 >/dev/null || { echo "python3 ontbreekt" >&2; exit 1; }

[ -f .env ] || cp .env.example .env
mkdir -p data runtime_uploads runtime_assets runtime_outputs

# Maak bij de eerste installatie unieke login- en sessiegeheimen; bestaande waarden blijven intact.
GENERATED_LOGIN="$(node - "$APP_DIR/.env" <<'NODE'
const fs=require('node:fs');const crypto=require('node:crypto');const file=process.argv[2];const lines=fs.readFileSync(file,'utf8').split(/\r?\n/);const values={};
for(const line of lines){if(line.includes('=')&&!line.trimStart().startsWith('#')){const i=line.indexOf('=');values[line.slice(0,i).trim()]=line.slice(i+1).trim()}}
const username=values.ADMIN_USERNAME||'stijn';let generated=false;
if(!values.ADMIN_PASSWORD){values.ADMIN_PASSWORD=crypto.randomBytes(18).toString('base64url');generated=true}
if(!values.SESSION_SECRET)values.SESSION_SECRET=crypto.randomBytes(48).toString('base64url');
values.ADMIN_USERNAME=username;if(!values.SESSION_TTL_SECONDS)values.SESSION_TTL_SECONDS='43200';if(!values.COOKIE_SECURE)values.COOKIE_SECURE='false';
const seen=new Set();const out=lines.map(line=>{if(line.includes('=')&&!line.trimStart().startsWith('#')){const key=line.slice(0,line.indexOf('=')).trim();if(Object.hasOwn(values,key)){seen.add(key);return `${key}=${values[key]}`}}return line});
for(const key of ['ADMIN_USERNAME','ADMIN_PASSWORD','SESSION_SECRET','SESSION_TTL_SECONDS','COOKIE_SECURE'])if(!seen.has(key))out.push(`${key}=${values[key]}`);
fs.writeFileSync(file,out.join('\n').replace(/\n+$/,'')+'\n');if(generated)process.stdout.write(`${username}\t${values.ADMIN_PASSWORD}`);
NODE
)"

# Broncode blijft alleen door root wijzigbaar; uitsluitend runtimepaden zijn schrijfbaar voor de service.
chown -R root:root "$APP_DIR"
find "$APP_DIR" -type d -exec chmod 0755 {} +
find "$APP_DIR" -type f -exec chmod 0644 {} +
chmod 0755 deploy/*.sh server/scripts/*.sh server/scripts/*.mjs server/freecad_worker/*.py server/asset_pipeline/*.py 2>/dev/null || true
chown root:www-data .env
chmod 0640 .env
for dir in data runtime_uploads runtime_assets runtime_outputs; do
  chown -R www-data:www-data "$dir"
  chmod 0750 "$dir"
done

install -m 0644 deploy/configurator-studio.service "/etc/systemd/system/$SERVICE"
systemctl daemon-reload
systemctl enable "$SERVICE" >/dev/null
systemctl restart "$SERVICE"

for _ in {1..20}; do
  if curl -fsS http://127.0.0.1:9999/api/health >/tmp/configurator-studio-health.json 2>/dev/null; then
    python3 -m json.tool </tmp/configurator-studio-health.json
    systemctl --no-pager --full status "$SERVICE" | sed -n '1,22p'
    if [ -n "$GENERATED_LOGIN" ]; then
      USERNAME="${GENERATED_LOGIN%%$'\t'*}"
      PASSWORD="${GENERATED_LOGIN#*$'\t'}"
      printf '\nEerste Studio-login (bewaar deze veilig):\n  gebruikersnaam: %s\n  wachtwoord: %s\n' "$USERNAME" "$PASSWORD"
    fi
    exit 0
  fi
  sleep 1
done

echo "Healthcheck is niet op tijd geslaagd." >&2
journalctl -u "$SERVICE" -n 80 --no-pager >&2 || true
exit 1
