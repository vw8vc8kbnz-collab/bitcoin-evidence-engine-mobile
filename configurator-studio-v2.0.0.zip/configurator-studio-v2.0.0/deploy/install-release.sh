#!/usr/bin/env bash
set -euo pipefail

SOURCE_DIR="${1:-}"
APP_DIR="${2:-/var/www/configurator-studio}"
STAMP="$(date +%Y%m%d-%H%M%S)"
NEW_DIR="${APP_DIR}.release-${STAMP}"
ROLLBACK_DIR="${APP_DIR}.rollback"
SWAPPED=0

[ "$(id -u)" -eq 0 ] || { echo "Voer dit script uit met sudo/root." >&2; exit 1; }
[ -n "$SOURCE_DIR" ] && [ -f "$SOURCE_DIR/package.json" ] || { echo "Ongeldige releasebron: $SOURCE_DIR" >&2; exit 1; }
[ -f "$SOURCE_DIR/server.mjs" ] || { echo "server.mjs ontbreekt in release." >&2; exit 1; }

cleanup() { rm -rf "$NEW_DIR"; }
rollback() {
  local code=$?
  if [ "$SWAPPED" -eq 1 ]; then
    echo "Deploy mislukt; vorige release wordt hersteld." >&2
    systemctl stop configurator-studio.service 2>/dev/null || true
    rm -rf "$APP_DIR"
    if [ -d "$ROLLBACK_DIR" ]; then mv "$ROLLBACK_DIR" "$APP_DIR"; fi
    systemctl daemon-reload 2>/dev/null || true
    systemctl restart configurator-studio.service 2>/dev/null || true
  fi
  cleanup
  exit "$code"
}
trap rollback ERR INT TERM

cd "$SOURCE_DIR"
node -e 'const p=require("./package.json"); if(p.version!=="2.0.0") throw new Error(`Onverwachte releaseversie: ${p.version}`)'
npm run check

rm -rf "$NEW_DIR" "$ROLLBACK_DIR"
mkdir -p "$NEW_DIR"
cp -a "$SOURCE_DIR/." "$NEW_DIR/"

# Configuratie en runtimegegevens blijven behouden bij iedere update.
if [ -d "$APP_DIR" ]; then
  [ -f "$APP_DIR/.env" ] && cp -a "$APP_DIR/.env" "$NEW_DIR/.env"
  for dir in data runtime_uploads runtime_assets runtime_outputs; do
    mkdir -p "$NEW_DIR/$dir"
    if [ -d "$APP_DIR/$dir" ]; then cp -a "$APP_DIR/$dir/." "$NEW_DIR/$dir/"; fi
  done
  mv "$APP_DIR" "$ROLLBACK_DIR"
fi
mv "$NEW_DIR" "$APP_DIR"
SWAPPED=1

APP_DIR="$APP_DIR" bash "$APP_DIR/deploy/deploy-v2.sh"

SWAPPED=0
rm -rf "$ROLLBACK_DIR"
trap - ERR INT TERM
cleanup
echo "Configurator Studio v2.0.0 is veilig geïnstalleerd in $APP_DIR"
