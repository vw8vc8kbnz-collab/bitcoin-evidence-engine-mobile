#!/usr/bin/env bash
set -euo pipefail

ZIP_NAME="${1:-configurator-studio-v2.0.0.zip}"
RAW_URL="https://raw.githubusercontent.com/vw8vc8kbnz-collab/bitcoin-evidence-engine-mobile/main/${ZIP_NAME}"
TMP_DIR="$(mktemp -d /tmp/configurator-studio-update.XXXXXX)"
ZIP_PATH="$TMP_DIR/$ZIP_NAME"
trap 'rm -rf "$TMP_DIR"' EXIT

command -v curl >/dev/null || { echo "curl ontbreekt" >&2; exit 1; }
command -v unzip >/dev/null || { echo "unzip ontbreekt" >&2; exit 1; }

curl --fail --location --retry 3 --connect-timeout 15 "$RAW_URL" --output "$ZIP_PATH"
unzip -q "$ZIP_PATH" -d "$TMP_DIR/unpacked"
SOURCE_DIR="$TMP_DIR/unpacked/configurator-studio-v2.0.0"
[ -f "$SOURCE_DIR/deploy/install-release.sh" ] || { echo "Release-inhoud is ongeldig." >&2; exit 1; }
sudo bash "$SOURCE_DIR/deploy/install-release.sh" "$SOURCE_DIR" /var/www/configurator-studio
