import test from 'node:test';
import assert from 'node:assert/strict';
import { normalizeCandidateFact, confirmFact, deriveFactStatus, pricingAllowed, mergeCandidateFacts, criticalFactGate } from '../src/core/truthGraph.mjs';
import { calculatePrice } from '../src/core/pricing.mjs';
import { chooseProductRoute, ROUTES } from '../src/core/routeEngine.mjs';
import { createDemoBlueprint } from '../src/core/blueprint.mjs';
import { runPublishGate } from '../src/core/gates.mjs';
import { compileRuntime } from '../src/core/runtimeCompiler.mjs';

test('AI measurement stays inferred and cannot price until explicit confirmation', () => {
  const inferred=normalizeCandidateFact({key:'dimensions.length_mm',label:'Lengte',value:1800,unit:'mm',value_type:'measurement',critical:true,confidence:.7});
  assert.equal(deriveFactStatus(inferred),'inferred'); assert.equal(pricingAllowed(inferred),false);
  const confirmed=confirmFact(inferred,{value:1810,unit:'mm',by:'tester',method:'measured'});
  assert.equal(confirmed.status,'confirmed'); assert.equal(confirmed.pricing_allowed,true); assert.equal(confirmed.value,1810);
});

test('conflicting candidates open a conflict and fail the critical gate', () => {
  const first=normalizeCandidateFact({key:'dimensions.width_mm',label:'Breedte',value:800,unit:'mm',critical:true});
  const merged=mergeCandidateFacts([first],[{key:'dimensions.width_mm',label:'Breedte',value:900,unit:'mm',critical:true}]);
  assert.equal(merged[0].status,'conflicting'); assert.equal(criticalFactGate(merged,['dimensions.width_mm']).passed,false);
});

test('pricing engine calculates selected fixed deltas', () => {
  const blueprint=createDemoBlueprint();
  const result=calculatePrice({pricing:blueprint.pricing,selected_option_ids:['walnut','frame_sand'],facts:[],quantity:2});
  assert.equal(result.unit_total,964); assert.equal(result.total,1928); assert.equal(result.breakdown.length,3);
});

test('area pricing rejects unverified measurement', () => {
  assert.throws(()=>calculatePrice({pricing:{base_price:{amount:0},rules:[{rule_id:'area',type:'area_based',rate_per_m2:100}]},facts:[normalizeCandidateFact({key:'dimensions.length_mm',value:1000,unit:'mm'}),normalizeCandidateFact({key:'dimensions.width_mm',value:1000,unit:'mm'})]}),/niet bevestigd/);
});

test('route engine prefers parametric CAD for confirmed dimensions and supported category', () => {
  const facts=['length','width','height'].map((name,i)=>({key:`dimensions.${name}_mm`,status:'confirmed',value:[1800,900,760][i]}));
  const route=chooseProductRoute({intake:{category:'table'},facts,assets:[],requested_profile:'auto',providerAvailability:{meshy:true,freecad:true}});
  assert.equal(route.route,ROUTES.PARAMETRIC);
});

test('route engine uses Meshy-balanced multi-image path when exact route is unavailable', () => {
  const route=chooseProductRoute({intake:{category:'sofa'},facts:[],assets:[{kind:'image',extension:'jpg'},{kind:'image',extension:'jpg'}],requested_profile:'auto',providerAvailability:{meshy:true,tripo:true,rodin:true}});
  assert.equal(route.route,ROUTES.PHOTO_BALANCED); assert.match(route.reason,/Meerdere aanzichten/);
});

test('publish gate and immutable compiler require a complete reviewed product', () => {
  const blueprint=createDemoBlueprint();
  const project={project_id:'p',workspace_id:'w',name:'Tafel',description:'',runtime_version:0,required_fact_keys:['dimensions.length_mm'],facts:[{key:'dimensions.length_mm',label:'Lengte',status:'confirmed',conflict:null}]};
  const asset={asset_id:'a',source_type:'verified_upload',public_url:'/a.glb',poster_url:'/a.png',quality_status:'accepted',mesh_inventory:[{mesh_id:'one'},{mesh_id:'two'}],metrics:{triangles:100}};
  const gate=runPublishGate({project,blueprint,asset}); assert.equal(gate.passed,true);
  const runtime=compileRuntime({project,blueprint,asset}); assert.equal(runtime.immutable,true); assert.equal(runtime.safety.provider_metadata_included,false); assert.ok(Object.isFrozen(runtime)); assert.ok(Object.isFrozen(runtime.asset)); assert.ok(Object.isFrozen(runtime.parts)); assert.ok(Object.isFrozen(runtime.parts[0]));
});


test('exact route refuses to pretend FreeCAD is available when tooling is absent', () => {
  const facts=['length','width','height'].map((name,i)=>({key:`dimensions.${name}_mm`,status:'confirmed',value:[1800,900,760][i]}));
  const route=chooseProductRoute({intake:{category:'table'},facts,assets:[],requested_profile:'exact',providerAvailability:{freecad:false}});
  assert.equal(route.route,ROUTES.CLARIFY); assert.ok(route.missing.includes('FreeCAD + Blender installatie'));
});

test('publish gate blocks every unreviewed model source, including uploads and CAD output', () => {
  const blueprint=createDemoBlueprint();
  const project={project_id:'p',required_fact_keys:[],facts:[]};
  for(const source_type of ['uploaded_asset','parametric_cad','ai_generated']){
    const asset={source_type,quality_status:'pending_review',mesh_inventory:[{mesh_id:'one'},{mesh_id:'two'}],metrics:{}};
    const gate=runPublishGate({project,blueprint,asset});
    assert.equal(gate.checks.find(c=>c.id==='human_review').passed,false);
  }
});

import { applyArchitectPlan } from '../src/core/architectPlan.mjs';
import { inspectGlb } from '../src/server/glbInspector.mjs';
import path from 'node:path';


test('architect plan becomes an editable draft without inventing mesh mappings', () => {
  const draft=applyArchitectPlan(createDemoBlueprint(),{parts:[{label:'Zitting',capabilities:['material','pricing','dimensions','not_allowed']}],option_groups:[{label:'Stof',target_part:'Zitting',option_examples:['Beige','Groen']}]});
  assert.equal(draft.parts.length,1); assert.deepEqual(draft.parts[0].mesh_targets,[]); assert.equal(draft.parts[0].capabilities.includes('not_allowed'),false); assert.equal(draft.option_groups[0].options.length,2);
});

test('GLB inspector reads real mesh inventory and mobile metrics', async () => {
  const result=await inspectGlb(path.resolve('public/assets/demo-table.glb'));
  assert.equal(result.metrics.meshes,10); assert.equal(result.mesh_inventory[0].mesh_id,'tabletop_main'); assert.equal(result.metrics.mobile_ready,true);
});

import { buildTripoGenerationPayload } from '../src/providers/tripo.mjs';
import { buildMeshyReconstructionPayload, buildMeshyRetexturePayload } from '../src/providers/meshy.mjs';
import { rodinStatusDone, rodinStatusFailed } from '../src/providers/rodin.mjs';

test('Tripo P1 payload preserves image types and uses exactly four multiview slots', () => {
  const payload=buildTripoGenerationPayload([{token:'front-token',type:'jpg'},{token:'left-token',type:'png'}],'P1-20260311');
  assert.equal(payload.model_version,'P1-20260311');
  assert.equal(payload.files.length,4);
  assert.deepEqual(payload.files[0],{type:'jpg',file_token:'front-token'});
  assert.deepEqual(payload.files[1],{type:'png',file_token:'left-token'});
  assert.equal('file_token' in payload.files[2],false);
  assert.equal(payload.compress,'geometry');
  assert.equal('generate_parts' in payload,false);
});

test('Rodin waits for all subjobs and fails when any subjob fails', () => {
  assert.equal(rodinStatusDone({jobs:[{status:'Done'},{status:'Processing'}]}),false);
  assert.equal(rodinStatusDone({jobs:[{status:'Done'},{status:'Done'}]}),true);
  assert.equal(rodinStatusFailed({jobs:[{status:'Done'},{status:'Failed'}]}),true);
});


test('material prompt never hijacks product reconstruction routing', () => {
  const route=chooseProductRoute({intake:{texture_prompt:'walnut',target_zone_id:'top'},facts:[],assets:[],requested_profile:'auto',providerAvailability:{meshy:true}});
  assert.equal(route.route,ROUTES.CLARIFY);
});


test('Meshy reconstruction payload supports full single and multi-image GLB/PBR generation', () => {
  const single=buildMeshyReconstructionPayload([{data_url:'data:image/png;base64,AAA'}],'warm walnut');
  assert.equal(single.image_url,'data:image/png;base64,AAA');
  assert.equal(single.enable_pbr,true); assert.equal(single.hd_texture,true);
  assert.equal(single.auto_size,true); assert.equal(single.origin_at,'bottom');
  assert.deepEqual(single.target_formats,['glb']); assert.equal(single.texture_prompt,'warm walnut');
  const multi=buildMeshyReconstructionPayload(Array.from({length:6},(_,i)=>({public_url:`https://example.test/${i}.jpg`})));
  assert.equal(multi.image_urls.length,4); assert.equal('image_url' in multi,false);
  assert.equal(multi.multi_view_thumbnails,true);
});

test('Meshy retexture payload keeps the verified model and never mixes text and image style controls', () => {
  const text=buildMeshyRetexturePayload({modelDataUri:'data:application/octet-stream;base64,AAA',prompt:'matte oak'});
  assert.equal(text.model_url,'data:application/octet-stream;base64,AAA');
  assert.equal(text.text_style_prompt,'matte oak'); assert.equal('image_style_url' in text,false);
  assert.equal(text.enable_original_uv,true); assert.deepEqual(text.target_formats,['glb']);
  const image=buildMeshyRetexturePayload({modelDataUri:'model',prompt:'ignored',styleImage:{data_url:'data:image/png;base64,BBB'}});
  assert.equal(image.image_style_url,'data:image/png;base64,BBB'); assert.equal('text_style_prompt' in image,false);
});
