import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const root=path.resolve(new URL('..',import.meta.url).pathname);

test('server exposes health, studio state and demo generation workflow', {timeout:20000}, async t => {
  const temp=fs.mkdtempSync(path.join(os.tmpdir(),'cfgstudio-'));
  const port=11991+Math.floor(Math.random()*400);
  const child=spawn(process.execPath,['server.mjs'],{cwd:root,env:{...process.env,PORT:String(port),DATA_DIR:path.join(temp,'data'),UPLOAD_DIR:path.join(temp,'uploads'),ASSET_DIR:path.join(temp,'assets'),OUTPUT_DIR:path.join(temp,'outputs'),DEMO_MODE:'true'},stdio:['ignore','pipe','pipe']});
  let stderr=''; child.stderr.on('data',d=>stderr+=d);
  t.after(()=>{child.kill('SIGTERM');fs.rmSync(temp,{recursive:true,force:true})});
  await waitFor(`http://127.0.0.1:${port}/api/health`);
  const health=await get(`http://127.0.0.1:${port}/api/health`); assert.equal(health.version,'2.0.0');
  const studio=await get(`http://127.0.0.1:${port}/api/studio`); assert.equal(studio.ok,true); assert.equal(studio.publish_gate.passed,true);
  const projects=await get(`http://127.0.0.1:${port}/api/projects`); assert.ok(projects.projects.some(p=>p.project_id==='proj_demo_table'));
  const published=await post(`http://127.0.0.1:${port}/api/publish`,{project_id:'proj_demo_table'}); assert.equal(published.ok,true); assert.ok(Object.isFrozen(published.runtime)===false);
  const afterPublish=await get(`http://127.0.0.1:${port}/api/studio`); assert.equal(afterPublish.project.status,'published'); assert.equal(afterPublish.project.runtime_version,1);
  const glb=fs.readFileSync(path.join(root,'public/assets/demo-table.glb')).toString('base64');
  const uploaded=await post(`http://127.0.0.1:${port}/api/assets/upload`,{project_id:'proj_demo_table',name:'review-test.glb',data_url:`data:model/gltf-binary;base64,${glb}`}); assert.equal(uploaded.ok,true); assert.equal(uploaded.asset.provenance.candidate_only,true);
  const reviewed=await post(`http://127.0.0.1:${port}/api/assets/${uploaded.asset.asset_id}/review`,{accepted:true,notes:'Contracttest'}); assert.equal(reviewed.ok,true); assert.equal(reviewed.asset.quality_status,'accepted'); assert.equal(reviewed.asset.provenance.candidate_only,false);
  const stylePng=fs.readFileSync(path.join(root,'public/assets/demo-table-preview.png')).toString('base64');
  const materialStarted=await post(`http://127.0.0.1:${port}/api/material/retexture`,{project_id:'proj_demo_table',asset_id:reviewed.asset.asset_id,prompt:'mat licht eiken met subtiele nerf',style_image:{name:'oak-reference.png',type:'image/png',data_url:`data:image/png;base64,${stylePng}`}}); assert.equal(materialStarted.ok,true); assert.equal(materialStarted.job.route_decision.route,'material_studio'); assert.equal(materialStarted.job.input.style_image,true); assert.equal(JSON.stringify(materialStarted.job).includes('data:image/'),false);
  let materialJob; for(let i=0;i<30;i++){await new Promise(r=>setTimeout(r,220));materialJob=(await get(`http://127.0.0.1:${port}/api/jobs/${materialStarted.job.job_id}`)).job;if(['succeeded','failed'].includes(materialJob.status))break}
  assert.equal(materialJob.status,'succeeded',stderr||materialJob.error?.message); assert.equal(materialJob.progress,100);
  const materialStudio=await get(`http://127.0.0.1:${port}/api/studio`); assert.equal(materialStudio.candidate_asset.source_type,'ai_retextured'); assert.equal(materialStudio.candidate_asset.quality_status,'pending_review'); assert.equal(materialStudio.candidate_asset.provenance.parent_asset_id,reviewed.asset.asset_id);
  const created=await post(`http://127.0.0.1:${port}/api/projects`,{name:'API testproduct',category:'cabinet',description:'Configureerbare testkast'}); assert.equal(created.ok,true);
  const createdStudio=await get(`http://127.0.0.1:${port}/api/studio?project_id=${created.project.project_id}`); assert.equal(createdStudio.project.name,'API testproduct'); assert.equal(createdStudio.blueprint.parts.length,0);
  const started=await post(`http://127.0.0.1:${port}/api/generation/start`,{project_id:'proj_demo_table',requested_profile:'exact',images:[]}); assert.equal(started.ok,true);
  let job; for(let i=0;i<30;i++){await new Promise(r=>setTimeout(r,250));job=(await get(`http://127.0.0.1:${port}/api/jobs/${started.job.job_id}`)).job;if(['succeeded','failed'].includes(job.status))break}
  assert.equal(job.status,'succeeded',stderr||job.error?.message); assert.equal(job.progress,100);
});

async function waitFor(url){for(let i=0;i<40;i++){try{const r=await fetch(url);if(r.ok)return}catch{}await new Promise(r=>setTimeout(r,100))}throw new Error('server did not start')}
async function get(url){return (await fetch(url)).json()}
async function post(url,body){return (await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)})).json()}


test('builder contains professional project management and no browser prompt flow', () => {
  const index=fs.readFileSync(path.join(root,'public/index.html'),'utf8');
  const app=fs.readFileSync(path.join(root,'public/js/app.js'),'utf8');
  assert.match(index,/id="projectModal"/);
  assert.match(index,/id="newProjectForm"/);
  assert.doesNotMatch(app,/\bprompt\s*\(/);
  assert.match(app,/\$\('#rail'\)\.classList\.remove\('open'\)/);
  assert.match(app,/materialStyleImageInput/); assert.match(app,/style_image:state\.materialStyleImage/);
  assert.doesNotMatch(app,/Meshy retextureert/);
});

test('single-workspace authentication protects private APIs and leaves health public', {timeout:15000}, async t => {
  const temp=fs.mkdtempSync(path.join(os.tmpdir(),'cfgstudio-auth-'));
  const port=12450+Math.floor(Math.random()*300);
  const child=spawn(process.execPath,['server.mjs'],{cwd:root,env:{...process.env,PORT:String(port),DATA_DIR:path.join(temp,'data'),UPLOAD_DIR:path.join(temp,'uploads'),ASSET_DIR:path.join(temp,'assets'),OUTPUT_DIR:path.join(temp,'outputs'),DEMO_MODE:'true',ADMIN_USERNAME:'stijn',ADMIN_PASSWORD:'strong-test-password',SESSION_SECRET:'test-session-secret-that-is-long-and-unique'},stdio:['ignore','pipe','pipe']});
  let stderr=''; child.stderr.on('data',d=>stderr+=d);
  t.after(()=>{child.kill('SIGTERM');fs.rmSync(temp,{recursive:true,force:true})});
  await waitFor(`http://127.0.0.1:${port}/api/health`);
  const healthResponse=await fetch(`http://127.0.0.1:${port}/api/health`); assert.equal(healthResponse.status,200); assert.equal((await healthResponse.json()).auth_enabled,true);
  const rootResponse=await fetch(`http://127.0.0.1:${port}/`); assert.match(await rootResponse.text(),/Beveiligde workspace/);
  const denied=await fetch(`http://127.0.0.1:${port}/api/projects`); assert.equal(denied.status,401);
  const wrong=await fetch(`http://127.0.0.1:${port}/api/auth/login`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:'stijn',password:'wrong'})}); assert.equal(wrong.status,401);
  const login=await fetch(`http://127.0.0.1:${port}/api/auth/login`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:'stijn',password:'strong-test-password'})}); assert.equal(login.status,200,stderr); const cookie=login.headers.get('set-cookie'); assert.match(cookie,/HttpOnly/); assert.match(cookie,/SameSite=Strict/);
  const allowed=await fetch(`http://127.0.0.1:${port}/api/projects`,{headers:{Cookie:cookie}}); assert.equal(allowed.status,200); assert.equal((await allowed.json()).ok,true);
  const logout=await fetch(`http://127.0.0.1:${port}/api/auth/logout`,{method:'POST',headers:{Cookie:cookie}}); assert.equal(logout.status,200); assert.match(logout.headers.get('set-cookie'),/Max-Age=0/);
});
