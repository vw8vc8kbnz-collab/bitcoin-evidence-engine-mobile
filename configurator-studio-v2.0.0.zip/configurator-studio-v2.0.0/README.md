# Configurator Studio v2.0.0

Configurator Studio is een deploybare no-code productkern voor betrouwbare 3D-configurators. De release vervangt de statische v1.6-prototypepagina door een modulaire Studio-app met een server, persistente projecten, een Product Architect, geïntegreerde 3D/CAD-routering, een capability-aware builder en gecontroleerde runtimepublicatie.

## Wat deze release daadwerkelijk levert

- Premium responsive Studio voor desktop en mobiel, met permanente live klantpreview.
- Projectwisselaar en nieuw-projectflow zonder browser-prompts.
- Expliciete **Productmodus** en **Onderdeelmodus**.
- Contextacties die alleen verschijnen wanneer het geselecteerde onderdeel de benodigde capability bezit.
- Lokale Three.js-viewer met GLB-loading, meshselectie, materiaalwissels, camera reset, resize en volledige cleanup.
- Product Architect met tekst, vision-input en strict structured output.
- Truth Graph v2: AI-uitvoer blijft kandidaat; alleen expliciete verificatie kan een fact bevestigen.
- Kritieke boolean gates per veld, zonder misleidende readiness-score.
- Gescheiden Pricing Engine en Rules Engine.
- Upload- en inspectieflow voor GLB met mesh-inventaris en review.
- Async jobflow voor Meshy, Tripo, Rodin en FreeCAD/Blender.
- AI Material Lab voor PBR-retexture van een geaccepteerd model, via tekst of materiaalreferentiebeeld.
- Menselijke review voor uploads, CAD-output en AI-output.
- Immutable runtime compiler met klantveilige data en zonder provider-/promptmetadata.
- Single-workspace login met HMAC-sessiecookie, HttpOnly, SameSite=Strict en login-rate-limit.
- Veilige systemd-deploy met behoud van `.env` en runtimegegevens, healthcheck en rollback.
- Volledig testbare demo-fallback zonder externe sleutels.

## Geïntegreerde engine

De klant ziet één Studio Engine. Intern kiest de orchestrator de technisch passende route:

1. **Bestaand GLB-model** — inspectie, mapping en review.
2. **Exact parametrisch** — bevestigde maten → FreeCAD → Blender → GLB → review.
3. **Gebalanceerde fotoreconstructie** — Meshy single-image of multi-image → PBR GLB → review.
4. **Snelle fotoreconstructie** — Tripo P1 single/multiview → GLB → review.
5. **Premium fotoreconstructie** — Hyper3D Rodin Gen-2/PBR → GLB → review.
6. **Materiaalroute** — geaccepteerd model → Meshy retexture via tekst of stijlbeeld → nieuwe review.
7. **Product Architect** — OpenAI vision/structured output voor intake, kandidaatfeiten, vragen en builderplan.

Geen provider mag een fact bevestigen, een prijs bepalen of een runtime publiceren.

## Lokaal starten

Node.js 20 of nieuwer is vereist. Er zijn geen npm-runtime-dependencies.

```bash
cp .env.example .env
node server.mjs
```

Open daarna `http://localhost:9999`.

Zonder ingevulde loginvelden en met `DEMO_MODE=true` opent de lokale demo direct. De productiedeploy genereert automatisch een unieke eerste login als die nog ontbreekt.

## Live integraties

Vul uitsluitend server-side in `.env` in:

```dotenv
OPENAI_API_KEY=
OPENAI_MODEL=gpt-5.6
MESHY_API_KEY=
TRIPO_API_KEY=
TRIPO_MODEL_VERSION=P1-20260311
HYPER3D_API_KEY=
RODIN_TIER=Gen-2
FREECAD_CMD=freecadcmd
BLENDER_CMD=blender
```

`DEMO_MODE=true` gebruikt een live provider zodra diens sleutel/tooling beschikbaar is en valt alleen voor ontbrekende routes terug op de demo. Zet productie na live contractvalidatie op `DEMO_MODE=false`, zodat ontbrekende integraties hard falen in plaats van stil terug te vallen.

## Testen

```bash
npm run check
```

De release bevat 20 regressie- en contracttests voor onder andere Truth Graph, pricing, routes, publish gates, immutable runtime, GLB-inspectie, Meshy payloads/retexture, Tripo P1, Rodin polling, FreeCAD-validatie, mobiele navigatie, authenticatie en echte HTTP-jobflows.

## Productiedeploy

De veilige installer:

```bash
sudo bash deploy/install-release.sh /pad/naar/configurator-studio-v2.0.0 /var/www/configurator-studio
```

De installer:

- voert eerst `npm run check` uit;
- bewaart `.env`, `data`, uploads, assets en outputs;
- wisselt releases atomisch;
- rolt terug wanneer deploy/healthcheck faalt;
- installeert de geharde systemd-service;
- toont bij de eerste installatie de gegenereerde login.

CAD-tooling installeer je daarna éénmalig op Debian/Ubuntu:

```bash
sudo bash /var/www/configurator-studio/deploy/install-cad-tools.sh
```

## Belangrijkste mappen

- `public/` — Studio, login, viewer en publieke runtime.
- `src/core/` — Truth Graph, routes, pricing, rules, gates en runtime compiler.
- `src/providers/` — OpenAI, Meshy, Tripo, Rodin en FreeCAD adapters.
- `src/server/` — auth, config, store, GLB-inspector en jobrunner.
- `server/freecad_worker/` — parametrische CAD-worker.
- `server/asset_pipeline/` — Blender-conversie naar GLB.
- `deploy/` — release-installer, updater, systemd, nginx en CAD-installatie.
- `docs/` — architectuur, providercontracten, migratieaudit en releaseverslag.

## Eerlijke productgrens

v2.0.0 is een professionele, deploybare **single-workspace Reliable Configurator Core**. Niet inbegrepen en dus ook niet als “af” geclaimd: multi-tenant accounts, abonnementen/credits, Stripe/Shopify Billing, object storage/CDN, Redis/queue workers, analytics en concrete Shopify/WooCommerce-apps. De runtime-, order- en providergrenzen zijn zo opgezet dat die commerciële SaaS-laag later kan worden toegevoegd zonder de kernregels opnieuw te ontwerpen.
