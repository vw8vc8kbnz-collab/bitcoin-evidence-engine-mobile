RoomBudget v1.0.3 dark premium rebuild

Installs as separate VPS service:
- service: roombudget.service
- folder: /opt/roombudget
- default port: 8903 unless ROOMBUDGET_PORT is passed
- mock AI provider by default, no real AI costs
- does not stop or modify other tools/services

Use GitHub raw download + Termius command block from chat.
