(function(){
  document.querySelectorAll('[data-compare]').forEach(function(c){
    var range=c.querySelector('input[type="range"]');
    var after=c.querySelector('.after-wrap');
    function set(v){ after.style.clipPath='polygon(0 0,'+v+'% 0,'+v+'% 100%,0 100%)'; }
    set(range.value);
    range.addEventListener('input',function(){set(this.value)});
  });
  var btn=document.getElementById('generateBtn');
  if(btn){btn.closest('form').addEventListener('submit',function(){btn.disabled=true;btn.textContent='GENEREREN...';});}
})();
