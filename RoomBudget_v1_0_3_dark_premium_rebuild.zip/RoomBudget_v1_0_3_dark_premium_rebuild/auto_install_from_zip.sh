#!/usr/bin/env bash
set -euo pipefail
PORT="${ROOMBUDGET_PORT:-8903}"
ZIP="${1:-}"
if [ -z "$ZIP" ]; then
  ZIP="$(ls -t /home/ubuntu/RoomBudget*.zip 2>/dev/null | head -1 || true)"
fi
if [ -z "$ZIP" ] || [ ! -f "$ZIP" ]; then
  echo "ERROR: RoomBudget zip not found in /home/ubuntu. Upload it first or pass path as first argument."
  exit 1
fi
TMP="/tmp/roombudget_auto_install"
rm -rf "$TMP"
mkdir -p "$TMP"
unzip -q -o "$ZIP" -d "$TMP"
INSTALL_DIR="$(find "$TMP" -maxdepth 3 -type f -name install.sh -printf '%h\n' | head -1)"
if [ -z "$INSTALL_DIR" ]; then echo "ERROR: install.sh not found inside $ZIP"; exit 1; fi
cd "$INSTALL_DIR"
chmod +x install.sh
ROOMBUDGET_PORT="$PORT" ./install.sh
