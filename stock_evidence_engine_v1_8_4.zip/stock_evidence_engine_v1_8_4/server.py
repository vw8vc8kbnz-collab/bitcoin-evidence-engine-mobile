#!/usr/bin/env python3
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
import json, csv, zipfile, html
VERSION='v1.8.3'; BASE=Path(__file__).resolve().parent; OUT=BASE/'output'; PORT=8798

def read_csv(name):
    files=list(OUT.glob(name))
    if not files: return []
    try:
        with files[0].open(encoding='utf-8') as f: return list(csv.DictReader(f))
    except Exception: return []

def latest(pattern):
    fs=sorted(OUT.glob(pattern), key=lambda p:p.stat().st_mtime, reverse=True); return fs[0] if fs else None

def card(r):
    t=html.escape(r.get('ticker','?')); conv=html.escape(str(r.get('conviction') or r.get('ai_conviction') or ''))
    score=r.get('final_score') or r.get('ai_final_score') or r.get('combined_score') or '0'
    ev=html.escape(str(r.get('event_type') or r.get('setup') or ''))
    reason=html.escape(str(r.get('reasoning') or ''))[:260]
    return f"""<div class='card'><div class='top'><b>{t}</b><span>{conv}</span></div><div class='score'>{score}</div><div class='muted'>{ev}</div><p>{reason}</p></div>"""

def dashboard():
    ai=read_csv(f'see_ai_analyst_{VERSION}.csv')
    elite=read_csv(f'see_elite_{VERSION}.csv')[:25]
    cost=read_csv(f'see_cost_monitor_{VERSION}.csv')
    cm=cost[0] if cost else {}
    ai_sorted=sorted(ai,key=lambda r: float(r.get('final_score') or 0), reverse=True)[:30]
    cards=''.join(card(r) for r in ai_sorted) or '<div class="card">Nog geen AI data. Run backtest.</div>'
    ecards=''.join(card(r) for r in elite[:20]) or '<div class="card">Geen elite rows.</div>'
    return f"""<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>SEE {VERSION}</title><style>
body{{margin:0;background:#f4f6fb;color:#111827;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif}}.wrap{{padding:16px;max-width:980px;margin:auto}}.hero{{background:linear-gradient(135deg,#111827,#334155);color:white;border-radius:26px;padding:22px;margin:10px 0 16px;box-shadow:0 18px 40px #0002}}h1{{margin:4px 0;font-size:30px}}.pill{{display:inline-block;background:#ffffff22;border:1px solid #ffffff33;padding:7px 11px;border-radius:999px;font-size:13px}}.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px}}.metric,.card{{background:white;border-radius:22px;padding:16px;box-shadow:0 10px 26px #0f172a12;border:1px solid #e5e7eb}}.metric b{{font-size:24px}}.section{{font-size:21px;margin:22px 2px 10px}}.top{{display:flex;justify-content:space-between;gap:10px;align-items:center}}.top b{{font-size:22px}}.top span{{background:#dcfce7;color:#166534;padding:6px 10px;border-radius:999px;font-weight:700;font-size:12px}}.score{{font-size:34px;font-weight:900;margin:8px 0;color:#0f172a}}.muted{{color:#64748b;font-size:13px}}p{{line-height:1.35}}a.btn{{display:inline-block;text-decoration:none;background:#111827;color:white;padding:12px 14px;border-radius:14px;font-weight:800;margin-top:8px}}@media(max-width:560px){{.wrap{{padding:10px}}.hero{{padding:18px;border-radius:22px}}.card{{padding:14px}}}}
</style></head><body><div class='wrap'><div class='hero'><span class='pill'>Stock Evidence Engine {VERSION}</span><h1>AI Catalyst + Market Reaction</h1><div>DeepSeek koppelt nieuws aan prijsactie, volume, RS, theme en regime.</div><a class='btn' href='/exports/all.zip'>Download audit ZIP</a></div><div class='grid'><div class='metric'><b>{len(ai)}</b><br><span class='muted'>AI analyst rows</span></div><div class='metric'><b>{len(elite)}</b><br><span class='muted'>Elite rows</span></div><div class='metric'><b>${cm.get('run_cost_usd','0')}</b><br><span class='muted'>Run cost</span></div><div class='metric'><b>${cm.get('monthly_estimate_usd','0')}</b><br><span class='muted'>Monthly est.</span></div></div><h2 class='section'>AI Analyst Signals</h2>{cards}<h2 class='section'>Elite Research Rows</h2>{ecards}</div></body></html>"""
class H(BaseHTTPRequestHandler):
    def do_HEAD(self): self.send_response(200); self.end_headers()
    def do_GET(self):
        if self.path.startswith('/health'):
            b=json.dumps({'ok':True,'version':VERSION}).encode(); self.send_response(200); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b); return
        if self.path.startswith('/exports/all.zip'):
            p=OUT/'all.zip'
            if not p.exists(): self.send_error(404); return
            b=p.read_bytes(); self.send_response(200); self.send_header('Content-Type','application/zip'); self.send_header('Content-Disposition','attachment; filename="see_audit_export_v1_8_3.zip"'); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b); return
        b=dashboard().encode('utf-8'); self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b)
if __name__=='__main__': ThreadingHTTPServer(('0.0.0.0',PORT),H).serve_forever()
