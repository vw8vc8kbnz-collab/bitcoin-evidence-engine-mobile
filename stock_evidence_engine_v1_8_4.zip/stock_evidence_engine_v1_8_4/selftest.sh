#!/usr/bin/env bash
set -euo pipefail
for f in server.py engine.py install.sh run_backtest.sh requirements.txt deepseek_prompt.md VERSION; do test -f "$f" || { echo "missing $f"; exit 1; }; done
python3 -m py_compile server.py engine.py
echo '[SEE selftest] OK'
