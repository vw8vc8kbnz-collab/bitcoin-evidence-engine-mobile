Stock Evidence Engine v1.8.4

- Bad ticker skip/retry/auto-blacklist.
- LAZR removed from default universe.
- AI-confirmed elite gating: old quant winners are QUANT_ELITE, alerts use AI_ELITE/AI_EXTREME.
- Ticker health export and failure logs.
- Stronger DeepSeek settings ready via .env.
