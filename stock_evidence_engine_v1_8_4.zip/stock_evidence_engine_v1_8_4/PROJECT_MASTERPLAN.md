v1.8.4 locks robust ticker ingestion and separates QUANT_ELITE from AI-confirmed ELITE.
