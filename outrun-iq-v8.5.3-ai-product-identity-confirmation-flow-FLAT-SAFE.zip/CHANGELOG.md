# Outrun IQ v8.5.3 — AI Product Identity & Confirmation Flow

## Hoofddoel
Deze versie maakt de AI-productherkenning betrouwbaarder zonder de invoerflow ingewikkeld te maken. Outrun mag partnerproducten snel voorbereiden, maar merk/model worden bij twijfel compact bevestigd voordat de listing definitief doorgaat.

## Wijzigingen
- Compacte bevestigingsflow toegevoegd na vision-analyse: “AI-herkenning · controleer even” met één-tik suggesties.
- Partner kan direct kiezen uit AI-suggestie, modelkandidaten of “ik vul zelf aan”. Geen zware wizard of extra verplichte stap.
- Bij onzekerheid wordt merk/model niet als harde waarheid behandeld; bevestigde keuze wordt zichtbaar verwerkt in titel en merk.
- Vision guard aangescherpt: Yamaha/Honda/Suzuki/Kawasaki cruiser-modellen worden niet meer hard ingevuld zonder zichtbaar logo/typeplaatje/OCR-bewijs.
- Harley-Davidson wordt explicieter als eerste kandidaat behandeld bij klassieke cruiser/touring-signalen zoals grote V-twin, zijkoffers, floorboards/treeplanken, whitewalls en touringlijn.
- Publicatie bewaart of de AI-identiteit door de partner bevestigd is; artikelnummer/OCR-foto’s blijven intern waar nodig.
- Flow blijft simpel: upload foto’s → AI vult voor → tik eventueel juiste suggestie → prijsanalyse.

## Test
- `npm install` uitgevoerd.
- `npx tsc --noEmit` OK.
- `npm run build` compile OK; timeout daarna op bekende Next `Collecting page data`.
