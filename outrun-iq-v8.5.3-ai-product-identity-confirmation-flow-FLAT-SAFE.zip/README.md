# Outrun IQ v8.5.3 — AI Product Identity & Confirmation Flow

Flat SAFE deployment build voor Outrun IQ. Gebaseerd op v8.5.2.

Deze release voegt een simpele bevestigingslaag toe aan de AI-productherkenning. De partner krijgt na foto-analyse maximaal enkele duidelijke suggesties en hoeft alleen de juiste te tikken of zelf aan te vullen. Zo blijft de invoer snel, maar worden foutieve harde merk/model-gokken minder waarschijnlijk.

Belangrijk:
- Maximaal 5 productfoto’s per listing.
- Label-/artikelnummer-/serienummerfoto’s kunnen intern blijven en hoeven niet openbaar in de buyer-galerij.
- Vision gebruikt alleen een echte multimodale provider wanneer `VISION_API_KEY` en `VISION_MODEL` ingesteld zijn.
- Zonder genoeg zekerheid vraagt AI om extra foto’s zoals tanklogo, typeplaatje of modelcode in plaats van een model te verzinnen.
