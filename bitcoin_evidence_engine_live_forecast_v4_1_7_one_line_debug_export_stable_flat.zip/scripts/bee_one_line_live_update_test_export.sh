#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="${BEE_ROOT_DIR:-/home/ubuntu/bitcoin-engine-deploy/current}"
LIVE_DIR="$ROOT_DIR/live_forecast"
HOME_EXPORT="/home/ubuntu/bee_live_debug_export.zip"
PYTHON_BIN="${PYTHON_BIN:-python3}"

cd "$ROOT_DIR"

echo "============================================================"
echo "BEE Live Forecast one-line install/test/export v4.1.7"
echo "Root: $ROOT_DIR"
echo "============================================================"

if [ ! -d "$LIVE_DIR" ]; then
  echo "ERROR: live_forecast/ ontbreekt. Heeft update.sh de ZIP wel uitgepakt?"
  echo "Aanwezige bestanden:"
  ls -lah
  exit 1
fi

# Install dependencies and create/preserve config.
chmod +x "$ROOT_DIR/scripts/install_live_forecast.sh" || true
"$ROOT_DIR/scripts/install_live_forecast.sh"

cd "$LIVE_DIR"

if [ -d ".venv" ]; then
  # shellcheck source=/dev/null
  source .venv/bin/activate
elif [ -d "$ROOT_DIR/.venv" ]; then
  # fallback for older deployments
  # shellcheck source=/dev/null
  source "$ROOT_DIR/.venv/bin/activate"
else
  "$PYTHON_BIN" -m venv .venv
  # shellcheck source=/dev/null
  source .venv/bin/activate
fi

mkdir -p state debug_exports

echo ""
echo "[1/5] Versie/help check"
python bee_live_forecast_v4_1_paper.py --help | grep -E "inspect-live-data|simulate-scenario|export-debug|golden-row" || true

echo ""
echo "[2/5] Live data inspectie"
set +e
python bee_live_forecast_v4_1_paper.py --inspect-live-data > state/last_inspect_live_data.txt 2>&1
INSPECT_RC=$?
set -e
cat state/last_inspect_live_data.txt | tail -80 || true
if [ "$INSPECT_RC" -ne 0 ]; then
  echo "WAARSCHUWING: inspect-live-data gaf exit code $INSPECT_RC, maar we maken alsnog debug export."
fi

echo ""
echo "[3/5] Panic simulatie"
set +e
python bee_live_forecast_v4_1_paper.py --simulate-scenario panic > state/last_simulate_panic.txt 2>&1
PANIC_RC=$?
set -e
cat state/last_simulate_panic.txt | tail -80 || true
if [ "$PANIC_RC" -ne 0 ]; then
  echo "WAARSCHUWING: simulate-scenario panic gaf exit code $PANIC_RC, maar we maken alsnog debug export."
fi

echo ""
echo "[4/5] Debug export ZIP maken"
EXPORT_OUTPUT="$(python bee_live_forecast_v4_1_paper.py --export-debug 2>&1 | tee state/last_export_debug_output.txt)"
EXPORT_PATH="$(printf '%s\n' "$EXPORT_OUTPUT" | grep -Eo '/[^ ]+bee_live_debug_export_[0-9T]+Z\.zip' | tail -1 || true)"
if [ -z "$EXPORT_PATH" ]; then
  EXPORT_PATH="$(ls -t debug_exports/bee_live_debug_export_*.zip 2>/dev/null | head -1 || true)"
fi
if [ -z "$EXPORT_PATH" ]; then
  echo "ERROR: Kon debug export ZIP niet vinden. Output was:"
  printf '%s\n' "$EXPORT_OUTPUT"
  exit 1
fi
if [[ "$EXPORT_PATH" != /* ]]; then
  EXPORT_PATH="$LIVE_DIR/$EXPORT_PATH"
fi

cp -f "$EXPORT_PATH" "$HOME_EXPORT"
chmod 644 "$HOME_EXPORT" || true

echo ""
echo "[5/5] Klaar"
echo "============================================================"
echo "✅ DEBUG ZIP STAAT KLAAR VOOR TERMIUS SFTP"
echo "Pad: $HOME_EXPORT"
ls -lh "$HOME_EXPORT"
echo ""
echo "Open Termius > Connect via SFTP > home > ubuntu"
echo "Download: bee_live_debug_export.zip"
echo "============================================================"
