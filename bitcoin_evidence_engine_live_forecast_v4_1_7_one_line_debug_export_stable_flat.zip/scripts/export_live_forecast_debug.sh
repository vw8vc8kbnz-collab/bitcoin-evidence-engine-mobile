#!/usr/bin/env bash
set -euo pipefail
BASE="/home/ubuntu/bitcoin-engine-deploy/current"
cd "$BASE/live_forecast"
source "$BASE/.venv/bin/activate"
python bee_live_forecast_v4_1_paper.py --export-debug
