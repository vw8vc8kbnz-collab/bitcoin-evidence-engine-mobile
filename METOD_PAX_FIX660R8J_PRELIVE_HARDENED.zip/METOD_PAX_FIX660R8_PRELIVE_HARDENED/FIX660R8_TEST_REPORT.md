# FIX660R8 test report

Datum: 12 augustus 2026  
Build: `FIX660R8_PRELIVE_HARDENED`  
Resultaat bron-/artifactgate: PASS wanneer `tools/final_preflight.py --verify-checksums` zonder fouten eindigt.

## Uitgevoerde suites

| Gate | Bewijs | Verwacht |
|---|---|---|
| Python compile | alle `app/*.py` en `tools/*.py` in-memory | PASS |
| Bash syntax | deploy- en installerscript | PASS |
| JavaScript syntax | alle losse JS-assets plus inline Tool A/Admin scripts | PASS |
| Safety/golden | `tools/fix660r8_safety_tests.py` — 13 tests | PASS |
| Server lifecycle | `tools/fix660r8_server_lifecycle_tests.py` — 7 tests | PASS |
| Echt HTTP-proces | `tools/fix660r8_http_smoke_tests.py` — liveness/readiness/Tool A/CSV-preview/catalogusbeeld | PASS |
| Restore adversarial | `tools/fix660r8_restore_tests.py` — 3 tests | PASS |
| Functionele regressie | `tools/fix660_regression.py` | `FIX660 REGRESSION: PASS` |
| Releaseboom | exact intern SHA-256-manifest; geen symlink/pycache/pyc/bak | PASS |
| Runtimecontract/SBOM | Pythonbereik, imports, requirements en CycloneDX | PASS |

De volledige artifactpreflight is daarnaast op de doel-VPS onder Python 3.14.4
uitgevoerd. Alle inhoudelijke gates waren daar groen; de oorspronkelijke R8/R8A
stopte uitsluitend omdat het declaratieve runtimecontract nog `<3.14` vermeldde.
De gecorrigeerde revisie ondersteunt daarom expliciet Python `>=3.10,<3.15`.

R8C simuleert aanvullend de installer-state-markerimport rechtstreeks vanuit
een read-only uitgepakte immutable release. Na die import blijft de releaseboom
vrij van `__pycache__` en `.pyc`; een tweede volledige build moet byte-identiek
zijn.

R8E start aanvullend `app/server_py.py` als werkelijk subprocess op een vrije
loopbackpoort. De gate eist een exact buildantwoord van `/health/live`, een
gestructureerd antwoord van `/health/ready` en een HTTP 200 voor Tool A. Deze
test is lokaal expliciet onder CPython 3.14.4 uitgevoerd.

R8F breidt diezelfde procesgate uit met een geauthenticeerde CSV-preview over
HTTP en een publieke materiaalcatalogus waarvan het lokale beeld daadwerkelijk
als `image/jpeg` wordt opgehaald. Een bewust aangelegde oude afgeleide
cataloguscache moet daarbij automatisch worden verworpen en opnieuw opgebouwd.

R8G voert aanvullend de mobiele preview-drawer in een gesimuleerde iOS-pointerketen
uit. De gate eist dat de drawer standaard gesloten is, met exact één tap opent,
een door Safari afgeleide click niet dubbel verwerkt, tijdens slepen een zichtbare
`important`-transform heeft en na de drempel weer sluit. De Admin-bron wordt ook
statisch gecontroleerd op de expliciete staging-versus-publicatiepoort.

R8H controleert aanvullend dat de retired FIX649-selector het actieve canvas
niet meer met `display:none !important` kan verbergen en dat de geopende
FIX660-drawer met een specifiekere ownershipselector zelfstandig een zichtbaar,
donker en vast bemeten previewvlak afdwingt. De bestaande uitvoerende canvasgate
blijft bovendien echte panelen in uniforme millimeterschaal tekenen.

R8I voert dezelfde canvasrenderer daarnaast met een desktop-mediaquery uit en
eist daar een zichtbaar, correct bemeten canvas plus een groene productie-readiness.
Voor mobiel wordt de drawerbovenkant tegen de gemeten headeronderrand gebonden,
zijn dubbele intro-/samenvattingsregels afwezig en blijft de inklapgreep binnen
de geopende drawer. De optimizer-hot-pathtest weigert iedere duurzame schrijfactie
van tijdelijke voortgangssnapshots. Een 100-panelenbenchmark met identieke input
en zes identieke outputplaten mat 2,543 seconde op R8 en 1,252 seconde op R8I;
een tweede R8-baselinerun mat 2,100 seconde.

R8J voegt twee zware optimizerproeven toe: 250 identieke echte METOD-panelen en
200 gemengde echte METOD-panelen. De gates eisen respectievelijk 250/250 en
200/200 unieke plaatsingen, 12 en 10 productieplaten, geldige sheetgeometrie,
volledige outputhashes, geen equivalente meervoudige strategieruns en behoud van
de gemeten plaatkwaliteit. De publieke lifecycle bewijst aanvullend met een
uitvoerende mock-teller dat twee PartIds met één gedeelde compacte DXF-body maar
één volledige DXF-parse uitvoeren.

## Kritieke uitkomsten die werkelijk worden getest

- positie 1/2/3 heeft de overeengekomen fysieke bottom-to-top volgorde;
- ARC-geometrie roteert in alle kwadranten;
- bboxmismatch publiceert nul sheet-DXF's;
- nonfinite en adversarial paneelvelden worden geweigerd;
- path traversal wordt geweigerd;
- machining-droppende fallback bestaat niet;
- de echte optimizer produceert één complete jobfamilie vanuit de publieke canonieke DTO;
- iedere finalization-hash wordt opnieuw gecontroleerd;
- een gemanipuleerde quote verdwijnt uit publieke status en maakt de jobfamilie ongeldig;
- Admin-manifestopbouw verandert geen byte en toont geen niet-verzegeld bestand;
- cancellation maakt bestaande artifacts niet downloadbaar;
- catalogusreviewhash verandert bij een gewijzigde warning;
- catalogusimage DNS wordt gepind en private IP's falen gesloten;
- imagecache-tampering wordt gedetecteerd;
- JSONL-rotatie behoudt het nieuwe event;
- tijdelijke optimizerprogressie blijft atomisch maar forceert geen file- of directory-fsync;
- 200–250 panelen veroorzaken geen herhaalde beoordeling van equivalente pending-items;
- compacte gedeelde DXF-bodies worden één keer geparsed en blijven per PartId afzonderlijk op bbox gecontroleerd;
- desktop en mobiel renderen dezelfde nerfgroep in dezelfde echte millimeterschaal;
- een echte applicatiebackup wordt gemaakt, volledig geverifieerd en naar een nieuwe stateboom hersteld, inclusief idempotencymarker en catalogus;
- restore weigert hashmanipulatie, traversal, extra leden en een bestaand target;
- prijs-, material-, auth-, privacy-, Grain Studio-, mobiele UI-, catalogus- en installerregressies blijven groen.

## Testisolatie

Lifecycle- en restoretests gebruiken tijdelijke externe state en verwijderen die na afloop. Ze schrijven niet naar echte klant-, VPS- of Library-state. De lifecycle gebruikt wel een echte ingebedde METOD-DXF en de echte optimizer/finalizer.

## Niet door de artifactgate bewezen

De volgende evidence moet buiten dit pakket worden geleverd:

- volledige VPS-installatie onder de gegenereerde systemd/Nginx-config;
- extern TLS-/HTTP-redirect- en firewallbewijs;
- load-, slow-client-, disk-full-, inode-full- en deploychaostest op representatieve hardware;
- versleutelde off-host overdracht en restore vanuit uitsluitend die kopie;
- acceptatie van de actuele live CSV-waarschuwingen door de materiaaleigenaar;
- echte iPhone/Safari-video en logs;
- onafhankelijke CAM-import, werkplaatscontrole en fysieke proefsnede.

Daarom is een groene artifactgate noodzakelijk, maar niet voldoende voor publiek productie-GO.
