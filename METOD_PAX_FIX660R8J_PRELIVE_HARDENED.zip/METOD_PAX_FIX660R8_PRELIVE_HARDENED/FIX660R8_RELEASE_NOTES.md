# FIX660R8 release notes

## R8J 200–250-panelen performance- en compact-DXF-correctie

- De compacte browserpayload stuurt één unieke DXF-body plus PartId-verwijzingen.
  De publieke servergrens vouwde dit correct uit, maar parseerde, valideerde en
  telde daarna dezelfde body opnieuw voor ieder PartId. Bij 250 gelijke panelen
  werd de geldige compacte aanvraag daardoor zelfs foutief als meer dan 12 MB
  geweigerd. R8J hash-identificeert unieke bodies en voert de volledige entity-
  en geometrievalidatie exact één keer per unieke body uit; de bbox blijft daarna
  afzonderlijk tegen ieder canoniek paneel gecontroleerd.
- De MaxRects-hot-path beoordeelde in iedere iteratie ieder fysiek exemplaar van
  exact dezelfde paneelgeometrie opnieuw, hoewel score, vrije rechthoeken en de
  uiteindelijke eerste-instantie-tiebreak identiek waren. In een 250-panelenprofiel
  bleken 92.385 pending- en 4.438 anchor-beoordelingen aantoonbaar equivalent.
  R8J slaat uitsluitend zulke bewezen equivalente berekeningen over; iedere
  fysieke instantie blijft afzonderlijk geplaatst, gevalideerd en geëxporteerd.
- Sorteervarianten die dezelfde geometrische itemvolgorde opleveren worden niet
  opnieuw volledig uitgevoerd. Voor homogene rechthoekjobs levert een geldige
  reguliere gridplaatsing bovendien een betere start-upper-bound; MaxRects en de
  bestaande bewijsruns mogen die uitkomst nog steeds verbeteren.
- Gemeten uitkomsten met identieke productie-input:
  - 200 gelijke panelen: 6,303 → 0,214 seconde; 11 → 10 platen;
  - 200 gemengde panelen: 5,898 → 0,667 seconde; 10 platen gebleven;
  - 250 gelijke panelen: 0,631 seconde totale optimizerduur, 12 platen, 250/250
    unieke plaatsingen en slechts één echte DXF-parse in de optimizer. De gekozen
    21-per-plaatindeling gebruikt drie 0°- en twee 90°-kolommen.
- Definitieve productie-DXF's worden nog steeds eenmaal per echte plaat duurzaam
  geschreven en vervolgens volledig op layer, entityaantal, plaatgrens, overlap,
  instance-identiteit en SHA-256 gecontroleerd. De versnelling verwijdert geen
  productiecontrole en verlaagt de nestingkwaliteit niet.

## R8I rand-tot-rand nerfpreview en optimizer-I/O-correctie

- De geopende mobiele nerfpreview begint nu op de werkelijk gemeten onderrand
  van de Grain Studio-bovenbalk. De dubbele mobiele tekstregels en samenvattingsbalk
  zijn uit de drawer verwijderd; het echte canvas gebruikt de volledige beschikbare
  ruimte tot aan de vaste actieknoppen.
- De inklapgreep ligt volledig binnen de drawer, heeft een groter zichtbaar
  handvat en blijft zowel open als gesloten bereikbaar. Een viewport- of
  oriëntatiewijziging meet de bovenrand opnieuw en rendert het canvas opnieuw.
- Desktop gebruikt aantoonbaar dezelfde real-mm renderer, materiaalweergave,
  DXF-boringen en bottom-to-top-productievolgorde. De regressiegate voert nu naast
  de iOS-route ook een aparte desktop-canvasroute uit.
- Tijdens het nesten werden iedere voortgangsstap en het groeiende tussenrapport
  met volledige file- plus directory-`fsync` gepubliceerd. Dat veroorzaakte op
  VPS-opslag veel synchrone diskbarriers. R8I schrijft uitsluitend deze vervangbare
  tussenstanden atomisch zonder `fsync`; definitieve rapporten, manifesten,
  productie-DXF's en finalization-hashes blijven volledig duurzaam geschreven.
- Een representatieve 100-panelenproef daalde lokaal van 2,543 naar 1,252 seconde
  optimizerduur (de herhaalde baseline bleef 2,100 seconde). De plaatindeling en
  het aantal van zes platen bleven exact gelijk. De UI begint bovendien na de
  reeds voltooide serverpreflight eerlijk op 3% in plaats van schijnbaar op 1%.

## R8H zichtbare iPhone-canvascorrectie

- De geopende FIX660-previewdrawer werd nog geraakt door een oude FIX649-regel
  met hogere CSS-specificiteit: zolang `fix649PreviewOpen` ontbrak, kreeg
  `#grainPreview` ondanks de nieuwe drawerstatus `display:none !important`.
  Daardoor waren groep, aantallen en maten zichtbaar, maar bleef de kaart wit.
- De oude FIX649-inline-previewpoort is verwijderd uit de actieve mobiele CSS.
  De geopende FIX660-drawer heeft daarnaast een expliciete ownershipselector
  die ook een eventueel nog door Safari gecachte oude regel overrulet.
- Zowel de oude mobiele stylesheet als alle Grain Studio-assets hebben een
  R8H-cachebuster. Schaal, bottom-to-top-volgorde, materiaalweergave,
  DXF-boringen/arcs en de Apply-readinessgate zijn inhoudelijk ongewijzigd.

## R8G publicatiepoort- en iOS-drawercorrectie

- Admin maakt nu ondubbelzinnig onderscheid tussen `100% voorbereid` en
  `actief gepubliceerd`. De 597 staged beelden blijven bewust onzichtbaar voor
  Tool A totdat de beheerder de complete CSV en beelden samen publiceert.
- Zodra de beeldvoorbereiding volledig geslaagd is, verschijnt direct in het
  voortgangsvak een tweede expliciete knop `Nu catalogus publiceren`; de
  bestaande reviewhash, bevestiging, snapshot en atomische publicatie blijven
  verplicht.
- De mobiele Doorlopende Nerf-preview voltooit een echte iOS-pointertap nu op
  `pointerup`, zodat Safari niet meer afhankelijk is van een `click` die na
  `preventDefault` kan worden onderdrukt. De sleep-transform krijgt dezelfde
  `!important`-prioriteit als de drawer-CSS en volgt daardoor zichtbaar de vinger.
- Een uitvoerende Node-regressietest bewijst openen met één tap, geen dubbele
  toggle en sluiten voorbij de sleepdrempel.

## R8F CSV-preview- en catalogusbeeldcorrectie

- De CSV-preview bevatte per ongeluk een auditblok uit de classificatie-override
  met vier variabelen die binnen preview niet bestaan. Daardoor eindigde iedere
  geldige CSV na het veilig opslaan van de stage alsnog in de generieke foutmelding.
- De afgeleide publieke cataloguscache heeft nu een expliciet schema/buildcontract.
  Een oude cache met beeld-URL's wordt na upgrade niet meer hergebruikt op basis
  van alleen de mtime van `material_library.json`.
- De proces-/HTTP-gate controleert nu ook een echte beveiligde CSV-preview en een
  lokaal gecachte catalogusafbeelding via de publieke API. Tool A vervangt een
  incidenteel niet-laadbaar beeld bovendien door de decorplaceholder.

## R8E live-HTTP-correctie

- De healthhandler gebruikt geen dubbel-underscore moduleconstant meer. De oude
  naam werd binnen `Handler.do_GET` door Python gemangeld naar
  `_Handler__SECURITY_BUILD`, waardoor de poort wel opende maar iedere
  livenessrequest zonder antwoord eindigde.
- De artifactgate start nu het echte serverproces en roept liveness, readiness
  en Tool A via loopback-HTTP aan. Alleen import-, compile- en directe
  handlertests zijn daardoor niet langer voldoende.
- De deploy onderdrukt herhaalde tijdelijke curlmeldingen en toont bij een
  blijvende healthfout automatisch de relevante systemd-journalregels.

## R8D rollback-/baselinecorrectie

- Een `metod-pax-current`-symlink die na rollback exact naar de legacy R7-map
  wijst, wordt nu als R7-baseline gevalideerd en niet meer ten onrechte als een
  immutable checksummanifest-release behandeld.
- Een echte immutable current-link is alleen geldig onder de beheerde
  releases-map en blijft volledig byte-voor-byte geverifieerd.
- `sudo -E` is verwijderd. Alleen de expliciete deployconfiguratie wordt als
  afzonderlijke, niet-uitvoerbare omgevingswaarden naar root doorgegeven.

## R8C installerfix

- Iedere installer- en deploy-Pythonaanroep draait met bytecode uitgeschakeld;
  de state-migratie kan daardoor geen `app/__pycache__` in de immutable release
  meer creëren.
- De immutable release-ID is nu afgeleid van het volledige interne
  checksummanifest. Een eerder geweigerde of vervuilde releasefolder met dezelfde
  backendbron kan daardoor nooit door een gecorrigeerde revisie worden hergebruikt.

## R8B packagingcorrectie

- Het runtimecontract ondersteunt nu expliciet Python `>=3.10,<3.15`.
- Python 3.14.4 is door de volledige preflight op de doel-VPS gevalideerd; de
  eerdere blokkade was uitsluitend de te smalle declaratieve bovengrens.
- De geïsoleerde preflight-state en expliciete `FOUTSAMENVATTING` uit R8A blijven
  actief.

Datum: 12 augustus 2026  
Build: `FIX660R8_PRELIVE_HARDENED`  
Basis: FIX660R7 pre-live audit

## Productie- en prijsintegriteit

- De publieke jobpayload wordt server-side opnieuw opgebouwd uit opaque materiaal-ID, actieve catalogus, live pricing en de ingebedde DXF-library.
- Paneelvelden zijn strict finite; aantallen, kantenbandcodes, nerfposities, dikte en plaatmaat hebben vaste contracten.
- DXF/CSV-bboxafwijking, onbekende machining, overlap, buiten-plaatgeometrie en exportfouten zijn fatal.
- ARC-hoeken roteren correct op 0/90/180/270 graden.
- Nerfpositie 1 is fysiek de onderste positie en ongelijke groepsbreedtes worden geweigerd.
- Clientpricing en clientgekozen productiepolicy hebben geen autoriteit meer.
- Finalisatie bindt input, optimizeroutputs, exacte identities/counts en alle downloadbare artifacts aan SHA-256.
- Status, submit en Admin-download falen gesloten bij ontbrekende of gemanipuleerde finalisatie.

## Security en privacy

- Job- en request-ID's gebruiken een strict allowlistcontract met vaste-root containment.
- Public quote-output is minimaal; productie-, prijs- en materiaalinterne data blijven Admin-only.
- Admin gebruikt in productie individuele accounts, TOTP MFA, HttpOnly sessiecookies, idle/absolute TTL, logout/revocation en server-derived actorlogging.
- Basic auth is in productie uitgeschakeld; login voert dummy PBKDF2/TOTP uit voor onbekende gebruikers.
- CSP gebruikt nonces en statische/DXF-responses gebruiken een beperkte allowlist en `nosniff`.
- Nginx normaliseert client-IP en begrenst jobs, login, SSE, requests en connecties.
- Staging bindt standaard alleen aan loopback; een remote bind vereist een expliciete CIDR-allowlist.
- Clientlogs zijn klein, geratelimit, geredigeerd, roterend en vereisen een jobtoken wanneer een job wordt genoemd.
- Catalogusafbeeldingen valideren DNS één keer en verbinden via het gepinde publieke IP met TLS-SNI/certificaatcontrole op de originele host.

## State, deploy en herstel

- Mutable state staat buiten de immutable release onder `/var/lib/metod-pax`.
- Migratie gebeurt naar een sibling stagingmap en wordt atomisch gepubliceerd na durable markerwrite.
- Releases zijn immutable; de current-symlink wordt atomisch gewisseld.
- Maintenance/drain voorkomt gemengde assets en verlies van deploy-windowdata.
- Rollback wijzigt code/config, nooit live state.
- Backups omvatten de volledige noodzakelijke state, gebruiken een schema-2 manifest met size/SHA-256 per bestand en worden na creatie byte-voor-byte herverifieerd.
- Restore weigert traversal, symlinks, extra/dubbele leden, hashverschillen en bestaande targets; publicatie gebeurt pas na een tweede hashcontrole.
- Kritieke writes gebruiken durable temp-write/replace/fsync; JSONL-logs hebben cross-process locking en rotatie.

## Catalogus en operations

- Cataloguspreview geeft een reviewhash over CSV, warnings, exclusions, errors, samenvatting, taxonomie en genormaliseerde records.
- Publicatie vereist dezelfde reviewhash en maakt een signoff die aan de actieve libraryhash is gebonden.
- Readiness controleert catalogus, signoff, pricing, schrijfbaarheid, vrije bytes/inodes, DXF-library en restore/offsite-evidence in productie.
- Runtimecontract, stdlib-only requirements, CycloneDX-SBOM, reproduceerbare artifactbuilder en CI releasegate zijn toegevoegd.

## Bewuste incompatibiliteiten

- De auth-loze StickerTool-route is 410 Gone.
- Per materiaaljob bestaat nog maar één authoritative `output/stickertool.json`; oude `stickers.json`-spiegels zijn verwijderd.
- Admin kan uitsluitend files downloaden die in een geldige finalization-hashlijst staan. Oude debuglogs en inputbestanden zijn niet meer via outputknoppen bereikbaar.
- Legacy queue-items worden niet opnieuw geoptimaliseerd; onveilig hervatwerk gaat naar handmatige controle.

## Geen productiecertificaat

Deze build is een pre-live candidate. De resterende externe gates staan in `GO_LIVE_GATES_FIX660R8.md` en kunnen niet met alleen broncode worden afgetekend.
