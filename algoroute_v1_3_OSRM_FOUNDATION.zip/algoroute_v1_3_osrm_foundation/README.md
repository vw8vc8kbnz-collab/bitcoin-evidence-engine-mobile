# AlgoRoute v1.3 OSRM Foundation

This build removes dummy route/vehicle/order data from the running application and introduces the real OSRM routing foundation.

## New
- Real MapLibre Netherlands map remains active.
- OSRM status endpoint.
- OSRM route endpoint: `/api/routing/route`.
- OSRM matrix endpoint: `/api/routing/matrix`.
- Empty persistent store files for orders, vehicles, routes, events and traffic segments.
- No demo vehicles/routes/orders inserted.
- Official green AlgoRoute logo/app icon assets included.
- OSRM Netherlands setup script included: `scripts/setup_osrm_nl.sh`.

## Not yet
- No C++ optimizer route assignment yet.
- No PDOK/BAG geocoding yet.
- No live traffic provider yet.
- No EV charge planner yet.
