SEE v1.7.0 keeps the v1.1+ deployment baseline and adds user-facing AI signal delivery: DeepSeek analyst cards + ntfy alerts under a strict cost monitor.
