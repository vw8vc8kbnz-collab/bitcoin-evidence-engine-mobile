#!/usr/bin/env python3
import csv, json, os, sys, time, math, zipfile, datetime, argparse
from pathlib import Path
import requests
from dotenv import load_dotenv

VERSION='v1.7.0'
ROOT=Path(__file__).resolve().parent
DATA=ROOT/'data'; EXPORTS=ROOT/'exports'; LOGS=ROOT/'logs'
for p in (DATA,EXPORTS,LOGS): p.mkdir(exist_ok=True)
load_dotenv(ROOT/'.env')

DEFAULT_PRICE_PER_M_INPUT=float(os.getenv('DEEPSEEK_INPUT_USD_PER_M','0.14'))
DEFAULT_PRICE_PER_M_OUTPUT=float(os.getenv('DEEPSEEK_OUTPUT_USD_PER_M','0.28'))
DEEPSEEK_MODEL=os.getenv('DEEPSEEK_MODEL','deepseek-chat')
DEEPSEEK_URL=os.getenv('DEEPSEEK_API_URL','https://api.deepseek.com/chat/completions')
USE_DEEPSEEK=os.getenv('USE_DEEPSEEK','1') == '1'
MAX_DEEPSEEK_TICKERS=int(os.getenv('DEEPSEEK_MAX_TICKERS','20'))
DEEPSEEK_SCANS_PER_DAY=float(os.getenv('DEEPSEEK_SCANS_PER_DAY','4'))
DEEPSEEK_MONTHLY_BUDGET_USD=float(os.getenv('DEEPSEEK_MONTHLY_BUDGET_USD','5'))
NTFY_TOPIC=os.getenv('NTFY_TOPIC','stock-signals-Stijn-2026').strip()
NTFY_ENABLED=os.getenv('NTFY_ENABLED','1') == '1'
NTFY_MIN_PROB=float(os.getenv('NTFY_MIN_PROB','82'))
NTFY_MAX_ALERTS=int(os.getenv('NTFY_MAX_ALERTS','5'))

def approx_tokens(s:str)->int:
    if not s: return 0
    return max(1, math.ceil(len(s)/4))

def read_prompt():
    return (ROOT/'deepseek_prompt.md').read_text()

def ticker_theme(t):
    themes={
      'IONQ':'QUANTUM','RGTI':'QUANTUM','QBTS':'QUANTUM','QUBT':'QUANTUM',
      'SOUN':'AI','BBAI':'AI','AI':'AI','PLTR':'AI_DEFENSE','NVDA':'AI_SEMIS','AMD':'AI_SEMIS',
      'BB':'AI_ROBOTICS_TURNAROUND','RKLB':'SPACE','ACHR':'EVTOL','JOBY':'EVTOL',
      'SMR':'NUCLEAR','COIN':'CRYPTO','MARA':'CRYPTO','RIOT':'CRYPTO','HOOD':'FINTECH',
      'TSLA':'EV_AI','RIVN':'EV','LCID':'EV','UPST':'FINTECH_AI'
    }
    return themes.get(t.upper(),'GENERAL')

def fallback_news(t):
    # deterministic offline fallback so export never goes empty if Yahoo blocks
    theme=ticker_theme(t)
    return [{
      'ticker':t,'headline':f'{t} remains active in {theme} narrative as momentum and relative strength are evaluated',
      'publisher':'SEE fallback','provider':'fallback','published_at':'','url':''
    }]

def fetch_yahoo_news(t):
    items=[]
    try:
        import yfinance as yf
        tk=yf.Ticker(t)
        news=getattr(tk,'news',None) or []
        for n in news[:10]:
            title=n.get('title') or n.get('content',{}).get('title') or ''
            pub=n.get('publisher') or n.get('providerPublishTime') or n.get('content',{}).get('provider',{}).get('displayName','')
            link=n.get('link') or n.get('content',{}).get('canonicalUrl',{}).get('url','')
            ts=n.get('providerPublishTime') or n.get('content',{}).get('pubDate','')
            if title:
                items.append({'ticker':t,'headline':title,'publisher':str(pub),'provider':'yfinance','published_at':str(ts),'url':link})
    except Exception as e:
        (LOGS/'news_errors.log').open('a').write(f'{datetime.datetime.utcnow().isoformat()} {t} {e}\n')
    return items or fallback_news(t)

def local_semantic(t, headlines):
    text=' '.join(h['headline'].lower() for h in headlines)
    bull={'earnings_beat':['beat','beats','tops estimates','raises guidance','guidance raise'],
          'major_partnership':['partnership','partners with','collaboration','launch with'],
          'government_contract':['government','defense','contract','billion-dollar deal','award'],
          'product_launch':['launches','unveils','new platform','product'],
          'analyst_upgrade':['upgrade','price target raised','buy rating'],
          'narrative_shift':['ai','robotics','quantum','space','nuclear','secure ai']}
    bear={'dilution_offering':['offering','dilution','stock sale','convertible notes'],
          'lawsuit_regulatory':['lawsuit','sec probe','investigation','regulatory'],
          'downgrade':['downgrade','price target cut','sell rating'],
          'earnings_miss':['misses','weak guidance','loss widens']}
    best='none'; score=0; sentiment='neutral'
    for k, words in bull.items():
        hits=sum(w in text for w in words)
        if hits and 45+hits*15 > score:
            best=k; score=45+hits*15; sentiment='bullish'
    for k, words in bear.items():
        hits=sum(w in text for w in words)
        if hits:
            best=k; score=-(50+hits*20); sentiment='bearish'
    materiality=max(0,min(100,abs(score)))
    theme=ticker_theme(t)
    align=70 if theme.lower().split('_')[0] in text else 45
    pr=max(10, 75-materiality)
    cont=max(0,min(100,50 + (score*0.35) + (align-50)*0.25))
    return {
      'event_type':best,'sentiment':sentiment,'materiality_score':materiality,
      'sentiment_score':score,'theme_alignment_score':align,'pr_fluff_probability':pr,
      'continuation_probability_1d':round(cont,1),'continuation_probability_3d':round(cont*0.94,1),
      'continuation_probability_10d':round(cont*0.82,1),'confidence':55 if best!='none' else 35,
      'risk_flags':[] if score>=0 else [best], 'best_headline':headlines[0]['headline'] if headlines else '',
      'reason':'Local semantic fallback based on headline class, theme fit and catalyst polarity.'
    }

def call_deepseek(t, market_context, headlines):
    key=os.getenv('DEEPSEEK_API_KEY','').strip()
    prompt=read_prompt()
    payload={
      'ticker':t,'theme':ticker_theme(t),'market_context':market_context,
      'headlines':headlines[:10]
    }
    user='Analyze this stock catalyst context and return strict JSON:\n'+json.dumps(payload,ensure_ascii=False)
    in_tokens=approx_tokens(prompt)+approx_tokens(user)
    if not (USE_DEEPSEEK and key):
        out=local_semantic(t, headlines)
        out['_provider']='local_fallback'; out['_input_tokens_est']=in_tokens; out['_output_tokens_est']=approx_tokens(json.dumps(out)); return out
    try:
        body={
          'model':DEEPSEEK_MODEL,
          'messages':[{'role':'system','content':prompt},{'role':'user','content':user}],
          'temperature':0.05,
          'max_tokens':900
        }
        if os.getenv('DEEPSEEK_RESPONSE_FORMAT','0') == '1':
            body['response_format']={'type':'json_object'}
        r=requests.post(DEEPSEEK_URL,headers={'Authorization':f'Bearer {key}','Content-Type':'application/json'},json=body,timeout=60)
        r.raise_for_status(); j=r.json()
        content=j['choices'][0]['message']['content'].strip()
        if content.startswith('```'):
            content=content.strip('`')
            if content.lower().startswith('json'):
                content=content[4:].strip()
        out=json.loads(content)
        usage=j.get('usage',{})
        out['_provider']='deepseek'
        out['_input_tokens_est']=usage.get('prompt_tokens',in_tokens)
        out['_output_tokens_est']=usage.get('completion_tokens',approx_tokens(content))
        return out
    except Exception as e:
        (LOGS/'deepseek_errors.log').open('a').write(f'{datetime.datetime.utcnow().isoformat()} {t} {e}\n')
        out=local_semantic(t, headlines); out['_provider']='local_fallback_after_error'; out['_input_tokens_est']=in_tokens; out['_output_tokens_est']=approx_tokens(json.dumps(out)); return out

def make_market_context(t):
    # v1.7.0 keeps this light/cost-efficient; full OHLC features remain deterministic engine side.
    return {'setup':'shortlist_candidate','regime':'computed_by_SEE','theme':ticker_theme(t)}

def run(tickers):
    news_rows=[]; analysis=[]; cost=[]
    for idx,t in enumerate(tickers):
        heads=fetch_yahoo_news(t)
        news_rows += heads
        market=make_market_context(t)
        if idx < MAX_DEEPSEEK_TICKERS:
            res=call_deepseek(t, market, heads)
        else:
            res=local_semantic(t, heads); res['_provider']='local_not_in_deepseek_budget'; res['_input_tokens_est']=0; res['_output_tokens_est']=0
        inp=int(res.get('_input_tokens_est',0)); outp=int(res.get('_output_tokens_est',0))
        cost_usd=inp/1_000_000*DEFAULT_PRICE_PER_M_INPUT + outp/1_000_000*DEFAULT_PRICE_PER_M_OUTPUT
        row={'ticker':t,'theme':ticker_theme(t),**res,'estimated_cost_usd':round(cost_usd,6)}
        analysis.append(row)
        cost.append({'ticker':t,'provider':res.get('_provider'),'input_tokens':inp,'output_tokens':outp,'estimated_cost_usd':round(cost_usd,6)})
    write_csv(EXPORTS/f'see_deepseek_news_analysis_{VERSION}.csv',analysis)
    write_csv(EXPORTS/f'see_news_items_{VERSION}.csv',news_rows)
    write_csv(EXPORTS/f'see_ai_cost_monitor_{VERSION}.csv',cost)
    run_cost=round(sum(r['estimated_cost_usd'] for r in cost),6)
    monthly_est=round(run_cost*DEEPSEEK_SCANS_PER_DAY*30,4)
    totals={'version':VERSION,'tickers':len(tickers),'deepseek_enabled':bool(os.getenv('DEEPSEEK_API_KEY','').strip()),
            'total_input_tokens':sum(r['input_tokens'] for r in cost),'total_output_tokens':sum(r['output_tokens'] for r in cost),
            'estimated_cost_usd':run_cost,'scans_per_day':DEEPSEEK_SCANS_PER_DAY,
            'estimated_monthly_cost_usd':monthly_est,'monthly_budget_usd':DEEPSEEK_MONTHLY_BUDGET_USD,
            'budget_status':'OK' if monthly_est <= DEEPSEEK_MONTHLY_BUDGET_USD else 'OVER_BUDGET',
            'ntfy_topic':NTFY_TOPIC if NTFY_ENABLED else '',
            'generated_at':datetime.datetime.utcnow().isoformat()+'Z'}
    (EXPORTS/'ai_cost_summary.json').write_text(json.dumps(totals,indent=2))
    send_ntfy_alerts(analysis, totals)
    # keep older dashboard-friendly files if absent
    write_csv(EXPORTS/f'see_summary_{VERSION}.csv', analysis)
    write_csv(EXPORTS/f'see_elite_{VERSION}.csv', [r for r in analysis if float(r.get('continuation_probability_3d') or 0)>=70])
    zip_all()
    print(f"Done. version={VERSION} tickers={len(tickers)} est_cost=${totals['estimated_cost_usd']}")

def write_csv(path, rows):
    if not rows:
        path.write_text('') ; return
    keys=[]
    for r in rows:
        for k in r.keys():
            if k not in keys: keys.append(k)
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=keys); w.writeheader(); w.writerows(rows)


def final_ai_score(row):
    vals=[]
    for k in ('continuation_probability_3d','continuation_probability_10d','materiality_score','narrative_strength','theme_alignment_score'):
        try: vals.append(float(row.get(k) or 0))
        except Exception: vals.append(0)
    risk=float(row.get('risk_score') or 0) if str(row.get('risk_score','')).replace('.','',1).isdigit() else 0
    return max(0,min(100, sum(vals)/len(vals) - risk*0.12))

def send_ntfy_alerts(analysis, totals):
    if not (NTFY_ENABLED and NTFY_TOPIC):
        return
    ranked=[]
    for r in analysis:
        try: prob=float(r.get('continuation_probability_3d') or 0)
        except Exception: prob=0
        score=final_ai_score(r)
        if prob>=NTFY_MIN_PROB or score>=NTFY_MIN_PROB:
            ranked.append((score,prob,r))
    ranked=sorted(ranked, reverse=True)[:NTFY_MAX_ALERTS]
    for score,prob,r in ranked:
        ticker=r.get('ticker','?')
        conv=r.get('conviction','')
        event=r.get('catalyst_type') or r.get('event_type') or 'catalyst'
        title=f"SEE {conv or 'AI'} signal: {ticker}"
        body=(f"Ticker: {ticker}\nEvent: {event}\nAI score: {score:.1f}\n3D prob: {prob:.1f}%\n"
              f"10D prob: {r.get('continuation_probability_10d','')}%\nMateriality: {r.get('materiality_score','')}\n"
              f"Cost/run: ${totals.get('estimated_cost_usd',0)}\nReason: {r.get('reason','')}")
        try:
            requests.post(f"https://ntfy.sh/{NTFY_TOPIC}", data=body.encode('utf-8'), headers={"Title":title,"Tags":"chart_with_upwards_trend,robot","Priority":"4"}, timeout=10)
        except Exception as e:
            (LOGS/'ntfy_errors.log').open('a').write(f'{datetime.datetime.utcnow().isoformat()} {ticker} {e}\n')

def zip_all():
    z=EXPORTS/'all.zip'
    with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as zf:
        for p in EXPORTS.glob('*'):
            if p.name!='all.zip': zf.write(p,p.name)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('tickers',nargs='?',default='BB,PLTR,IONQ,SOUN,NVDA,AMD,TSLA'); args=ap.parse_args()
    run([x.strip().upper() for x in args.tickers.split(',') if x.strip()])
if __name__=='__main__': main()
