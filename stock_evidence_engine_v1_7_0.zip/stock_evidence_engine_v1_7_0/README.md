# Stock Evidence Engine v1.7.0

DeepSeek Analyst Brain with mobile signal cards, ntfy alerts, cost guard and 4x/day timer.

- Dashboard: `server.py` on port 8798
- Backtest/scan uses fixed `venv/bin/python`
- ntfy topic default: `stock-signals-Stijn-2026`
- Monthly budget guard shown in dashboard
- Timer scans 4x/day by default. Disable with `SEE_ENABLE_TIMER=0` before `./install.sh`.
