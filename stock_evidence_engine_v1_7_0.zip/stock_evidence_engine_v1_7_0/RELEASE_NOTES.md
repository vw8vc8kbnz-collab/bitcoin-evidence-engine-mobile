v1.7.0: Mobile card dashboard, ntfy alerts, stronger DeepSeek prompt, budget monitor, 4x/day scan timer.
