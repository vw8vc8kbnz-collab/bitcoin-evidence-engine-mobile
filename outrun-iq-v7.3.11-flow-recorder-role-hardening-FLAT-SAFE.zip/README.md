Outrun IQ v7.3.11 Flow Recorder + Role Hardening

Flat root ZIP. package.json staat direct in ZIP-root.

Flow Recorder exports zijn gemaskeerd; ?pin=, e-mails en tokens horen niet leesbaar in replay/JSONL te staan.

Outrun IQ v7.3.10 Flow Recorder

Flat root ZIP: package.json staat direct in de ZIP-root.
Belangrijk: data/, .env, runtime_uploads/ en public/uploads/ niet overschrijven bij deploy.

Gebruik /beheer om een Flow Recorder testsessie te starten en daarna JSONL of Replay HTML te downloaden.


### v7.3.11 notes
Flow Recorder exports zijn gemaskeerd; `?pin=` en e-mails horen niet meer leesbaar in replay/JSONL te staan.
