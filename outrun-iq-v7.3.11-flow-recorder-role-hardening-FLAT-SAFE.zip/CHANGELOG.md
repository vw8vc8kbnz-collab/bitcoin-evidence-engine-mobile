# v7.3.11 — Flow Recorder + Role Hardening

- Runtime-role scheiding aangescherpt: admin/consument-flags worden effectief geïsoleerd van partnerflags.
- Login-keuze verder dichtgezet: zakelijk kiest alleen partner, persoonlijk eerst consument en admin alleen via ADMIN_EMAIL.
- Beheerstatistieken/partnerlijst tellen alleen echte partnerrollen.
- Flow Recorder maskt admin-pin, e-mails, tokens, postcodes en gevoelige waarden harder in events, snapshots en exports.
- REC-badge staat nu linksboven onder safe-area zodat hij zichtbaar is in PWA/iPhone.
- Click-events krijgen betere labels; API-calls loggen methode, status en duur.

# v7.3.10 — Flow Recorder build hotfix

- Fix TypeScript build error in `lib/auth.ts`: personal buyer role is `consument`, not `buyer`.
- Preserves v7.3.9 Flow Recorder features.

# v7.3.10 — Flow Recorder

- Nieuwe Flow Recorder in Beheer.
- Start/stop testsessie vanuit `/beheer`.
- Floating `FLOW REC` indicator tijdens test.
- Registreert routes, clicks, submits, errors, zichtbaarheid en snapshots.
- Server-side opslag in `db.flowEvents` met max 20.000 events.
- Download vanuit Beheer als JSONL en Replay HTML.
- Lokale JSON-download vanuit beheer voor snelle mobiele test.
- Privacy masking voor wachtwoorden, pins, tokens, adressen/postcodes en gevoelige inputvelden.
- Service-worker cacheversie verhoogd naar v7.3.10.


## v7.3.11 — Flow Recorder + Role Hardening
- Runtime-role scheiding aangescherpt: admin/consument-flags worden effectief geïsoleerd van partnerflags.
- Login-keuze verder dichtgezet: zakelijk kiest alleen partner, persoonlijk eerst consument en admin alleen via ADMIN_EMAIL.
- Beheerstatistieken/partnerlijst tellen alleen echte partnerrollen.
- Flow Recorder maskt nu admin-pin, e-mails, tokens, postcodes en gevoelige waarden harder in events, snapshots en exports.
- REC-badge verplaatst naar linksboven onder safe-area zodat hij zichtbaar is in PWA/iPhone.
- Click-events krijgen betere labels uit data-track/aria/href/text.
- Fetch/API-calls worden gelogd met methode, statuscode en duur.
- Replay HTML toont API-events en gemaskeerde exports.
