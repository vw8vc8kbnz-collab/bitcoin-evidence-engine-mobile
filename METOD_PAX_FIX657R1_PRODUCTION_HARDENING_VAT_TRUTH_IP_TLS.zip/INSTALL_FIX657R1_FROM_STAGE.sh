#!/usr/bin/env bash
set -Eeuo pipefail

VERSION="FIX657R1"
STAGE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="${METOD_PAX_APP_DIR:-/opt/adzaagt/metod-pax}"
PUBLIC_IP="${PUBLIC_IP:-51.195.102.180}"
PUBLIC_ORIGIN="${PUBLIC_ORIGIN:-https://${PUBLIC_IP}}"
ADMIN_ORIGIN="${ADMIN_ORIGIN:-${PUBLIC_ORIGIN}}"
TLS_CERT_FILE="${TLS_CERT_FILE:-/etc/letsencrypt/live/${PUBLIC_IP}/fullchain.pem}"
TLS_KEY_FILE="${TLS_KEY_FILE:-/etc/letsencrypt/live/${PUBLIC_IP}/privkey.pem}"
CREDS_FILE="${ADMIN_CREDENTIALS_FILE:-/etc/adzaagt/metod-pax/admin_credentials.live.json}"
TS="$(date +%Y%m%d_%H%M%S)"
LOG="/tmp/METOD_PAX_FIX657R1_DEPLOY_${TS}.log"
APP_BACKUP="${APP_DIR}_backup_before_FIX657R1_${TS}"
CONFIG_TAR="/var/backups/metod-pax/FIX657R1_outer_config_${TS}.tar"
HAD_APP=0
LIVE_TOUCHED=0
SUCCESS=0

info(){ echo "[$VERSION] $*"; }
fail(){ echo "[$VERSION] FOUT: $*" >&2; exit 1; }

rollback(){
  local rc=$?
  if [[ "$SUCCESS" -eq 1 ]]; then
    info "Deploy succesvol. Log: $LOG"
    return 0
  fi
  echo "[$VERSION] INSTALLATIE MISLUKT (code $rc). Log: $LOG" >&2
  echo "[$VERSION] Staging blijft voor diagnose: $STAGE" >&2
  if [[ "$LIVE_TOUCHED" -eq 1 ]]; then
    echo "[$VERSION] Automatische app/config-rollback wordt uitgevoerd..." >&2
    set +e
    if [[ "$HAD_APP" -eq 1 && -d "$APP_BACKUP" ]]; then
      sudo rm -rf "$APP_DIR"
      sudo cp -a "$APP_BACKUP" "$APP_DIR"
    elif [[ "$HAD_APP" -eq 0 ]]; then
      sudo rm -rf "$APP_DIR"
    fi
    if [[ -f "$CONFIG_TAR" ]]; then
      sudo rm -rf /etc/adzaagt/metod-pax
      sudo rm -f /etc/systemd/system/metod-pax.service
      sudo rm -f /etc/nginx/sites-available/metod-pax-https /etc/nginx/sites-enabled/metod-pax-https
      sudo rm -f /etc/nginx/sites-available/metod-pax-8790 /etc/nginx/sites-enabled/metod-pax-8790
      sudo rm -f /etc/nginx/sites-available/metod-pax-acme-ip /etc/nginx/sites-enabled/metod-pax-acme-ip
      sudo tar -xpf "$CONFIG_TAR" -C /
    fi
    sudo systemctl daemon-reload || true
    if sudo nginx -t; then sudo systemctl reload nginx || true; fi
    if [[ -f /etc/systemd/system/metod-pax.service ]]; then sudo systemctl restart metod-pax.service || true; fi
    echo "[$VERSION] Rollbackpoging afgerond. TLS-cert/renewal mag veilig blijven bestaan." >&2
    set -e
  fi
  return "$rc"
}
trap rollback EXIT
exec > >(tee -a "$LOG") 2>&1

[[ "$PUBLIC_ORIGIN" == "https://${PUBLIC_IP}" ]] || fail "PUBLIC_ORIGIN moet voor deze IP-release exact https://${PUBLIC_IP} zijn"
[[ -f "$CREDS_FILE" ]] || fail "Bestaande externe Admin credentials ontbreken: $CREDS_FILE"
for cmd in rsync python3 sha256sum grep tar openssl curl nginx systemctl; do command -v "$cmd" >/dev/null || fail "Ontbrekend commando: $cmd"; done
sudo -v

# Extracted release integrity and clean-tree contracts.
(cd "$STAGE" && sha256sum -c SHA256SUMS.txt >/dev/null)
python3 - "$STAGE" <<'PY'
from pathlib import Path
import json,sys
root=Path(sys.argv[1])
bad=[str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and ('__pycache__' in p.parts or p.suffix.lower() in {'.pyc','.bak','.csv'})]
if bad: raise SystemExit(f'Onschone staged release: {bad[:20]}')
lib=json.loads((root/'app/material_library.json').read_text(encoding='utf-8'))
assert lib.get('source')=='CSV_CATALOG_ONLY' and lib.get('records')==[]
assert lib.get('pricingModel')=='catalog_sell_price_incl_vat_v2'
print('Release integrity/CSV-only seed/pricing-v2: OK')
PY

# All application regressions run before the app itself is touched.
python3 -m py_compile "$STAGE"/app/*.py "$STAGE"/tools/*.py
bash -n "$STAGE/DEPLOY_FIX657.sh"
bash -n "$STAGE/BOOTSTRAP_IP_TLS_FIX657R1.sh"
if command -v node >/dev/null; then for f in "$STAGE"/app/*.js; do node --check "$f" >/dev/null; done; fi
python3 "$STAGE/tools/fix657_regression.py"

# First establish trusted TLS for the already verified production IP. This does not
# touch the application and uses a staging ACME issuance before production issuance.
info "TLS bootstrap/controle voor $PUBLIC_IP..."
sudo env PUBLIC_IP="$PUBLIC_IP" bash "$STAGE/BOOTSTRAP_IP_TLS_FIX657R1.sh"
[[ -f "$TLS_CERT_FILE" && -f "$TLS_KEY_FILE" ]] || fail "TLS-bestanden ontbreken na bootstrap"
sudo openssl x509 -in "$TLS_CERT_FILE" -noout -text | grep -Fq "IP Address:$PUBLIC_IP" || fail "TLS SAN bevat $PUBLIC_IP niet"

PREFLIGHT_ENV="$STAGE/.production-preflight.env"
cat > "$PREFLIGHT_ENV" <<EOF2
APP_ENV=production
PRODUCTION_HARDENING=1
ADMIN_HASH_ONLY=1
ADMIN_STAGING_OPEN=0
ADMIN_CREDENTIALS_FILE=$CREDS_FILE
ALLOWED_ORIGINS=$PUBLIC_ORIGIN
ALLOWED_ADMIN_ORIGINS=$ADMIN_ORIGIN
PUBLIC_JSON_MAX_BYTES=16777216
SUBMIT_MAX_BYTES=8388608
PUBLIC_DXF_BLOB_MAX_BYTES=2097152
PUBLIC_JOB_MAX_CONCURRENT=1
PUBLIC_JOB_MAX_CONCURRENT_PER_IP=1
EOF2
APP_DIR="$STAGE" METOD_ENV_FILE="$PREFLIGHT_ENV" python3 "$STAGE/tools/final_preflight.py"
rm -f "$PREFLIGHT_ENV"
info "Production preflight groen. Nu pas live backup/switch."

if [[ -d "$APP_DIR/app" ]]; then
  HAD_APP=1
  sudo cp -a "$APP_DIR" "$APP_BACKUP"
  info "Volledige appbackup: $APP_BACKUP"
fi
sudo mkdir -p "$(dirname "$CONFIG_TAR")"
TAR_INPUTS=()
for f in /etc/adzaagt/metod-pax /etc/systemd/system/metod-pax.service \
         /etc/nginx/sites-available/metod-pax-8790 /etc/nginx/sites-enabled/metod-pax-8790 \
         /etc/nginx/sites-available/metod-pax-https /etc/nginx/sites-enabled/metod-pax-https \
         /etc/nginx/sites-available/metod-pax-acme-ip /etc/nginx/sites-enabled/metod-pax-acme-ip; do
  [[ -e "$f" || -L "$f" ]] && TAR_INPUTS+=("${f#/}")
done
if ((${#TAR_INPUTS[@]})); then
  sudo tar -cpf "$CONFIG_TAR" -C / "${TAR_INPUTS[@]}"
else
  sudo tar -cpf "$CONFIG_TAR" --files-from /dev/null
fi
info "Externe configbackup: $CONFIG_TAR"
LIVE_TOUCHED=1

sudo mkdir -p "$APP_DIR/app/jobs" "$APP_DIR/app/requests" "$APP_DIR/app/queue" "$APP_DIR/app/archive" \
  "$APP_DIR/app/backups" "$APP_DIR/app/drafts" "$APP_DIR/app/system" "$APP_DIR/app/decor_media" "$APP_DIR/app/config"

# Existing live state always wins; release seeds are only for a truly fresh install.
if [[ ! -f "$APP_DIR/app/material_library.json" ]]; then sudo install -m 0640 "$STAGE/app/material_library.json" "$APP_DIR/app/material_library.json"; fi
if [[ ! -f "$APP_DIR/app/config/pricing_active.json" ]]; then sudo install -m 0640 "$STAGE/app/config/pricing_active.json" "$APP_DIR/app/config/pricing_active.json"; fi
if [[ ! -d "$APP_DIR/app/embedded_dxfs" && -d "$STAGE/app/embedded_dxfs" ]]; then sudo cp -a "$STAGE/app/embedded_dxfs" "$APP_DIR/app/embedded_dxfs"; fi
if [[ ! -f "$APP_DIR/app/embedded_dxfs_manifest.json" && -f "$STAGE/app/embedded_dxfs_manifest.json" ]]; then sudo cp -a "$STAGE/app/embedded_dxfs_manifest.json" "$APP_DIR/app/embedded_dxfs_manifest.json"; fi

sudo rsync -a --delete "$STAGE/" "$APP_DIR/" \
  --exclude 'app/jobs/' \
  --exclude 'app/requests/' \
  --exclude 'app/queue/' \
  --exclude 'app/archive/' \
  --exclude 'app/backups/' \
  --exclude 'app/drafts/' \
  --exclude 'app/system/' \
  --exclude 'app/decor_media/' \
  --exclude 'app/material_library.json' \
  --exclude 'app/config/pricing_active.json' \
  --exclude 'app/config/pricing_versions/' \
  --exclude 'app/config/pricing_audit.jsonl' \
  --exclude 'app/embedded_dxfs/' \
  --exclude 'app/embedded_dxfs_manifest.json'

sudo chmod +x "$APP_DIR/DEPLOY_FIX657.sh" "$APP_DIR/BOOTSTRAP_IP_TLS_FIX657R1.sh" "$APP_DIR/INSTALL_FIX657R1_FROM_STAGE.sh" "$APP_DIR"/tools/*.py
sudo env \
  PUBLIC_ORIGIN="$PUBLIC_ORIGIN" \
  ADMIN_ORIGIN="$ADMIN_ORIGIN" \
  TLS_CERT_FILE="$TLS_CERT_FILE" \
  TLS_KEY_FILE="$TLS_KEY_FILE" \
  ADMIN_CREDENTIALS_FILE="$CREDS_FILE" \
  METOD_PAX_APP_DIR="$APP_DIR" \
  bash "$APP_DIR/DEPLOY_FIX657.sh"

curl -fsS "http://127.0.0.1:8792/toolA.html?v=657" | grep -Fq 'FIX657_PRODUCTION_HARDENING_VAT_TRUTH'
sudo systemctl is-active --quiet metod-pax.service
sudo nginx -t
sudo systemctl is-active --quiet metod-pax-certbot-renew.timer || fail "Certbot renewal timer is niet actief"

# Prove the final nginx config still exposes the ACME webroot after the bootstrap
# vhost has been retired, so six-day IP certificate renewal remains autonomous.
PROBE="fix657r1-post-${TS}"
sudo mkdir -p /var/www/letsencrypt/.well-known/acme-challenge
printf '%s\n' "$PROBE" | sudo tee "/var/www/letsencrypt/.well-known/acme-challenge/$PROBE" >/dev/null
curl -fsS -H "Host: $PUBLIC_IP" "http://127.0.0.1/.well-known/acme-challenge/$PROBE" | grep -Fxq "$PROBE" || fail "Final nginx ACME-renewal route faalt"
sudo rm -f "/var/www/letsencrypt/.well-known/acme-challenge/$PROBE"

SUCCESS=1
info "FIX657R1 ACTIEF en production checks groen."
info "Tool A: https://${PUBLIC_IP}/toolA.html?v=657"
info "Admin:  https://${PUBLIC_IP}/admin/?v=657"
info "TLS renewal timer actief; appbackup: $APP_BACKUP"
info "Configbackup: $CONFIG_TAR"
