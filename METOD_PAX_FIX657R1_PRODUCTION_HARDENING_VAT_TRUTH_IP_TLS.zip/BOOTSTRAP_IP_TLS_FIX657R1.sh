#!/usr/bin/env bash
set -Eeuo pipefail

VERSION="FIX657R1-TLS"
PUBLIC_IP="${PUBLIC_IP:-51.195.102.180}"
WEBROOT="${ACME_WEBROOT:-/var/www/letsencrypt}"
CERTBOT_VENV="${CERTBOT_VENV:-/opt/certbot}"
CERTBOT_BIN="${CERTBOT_BIN:-/usr/local/bin/certbot}"
CERT_DIR="/etc/letsencrypt/live/${PUBLIC_IP}"
CERT_FILE="${CERT_DIR}/fullchain.pem"
KEY_FILE="${CERT_DIR}/privkey.pem"
ACME_SITE="/etc/nginx/sites-available/metod-pax-acme-ip"
ACME_LINK="/etc/nginx/sites-enabled/metod-pax-acme-ip"
BACKUP_ROOT="/var/backups/metod-pax"
TS="$(date +%Y%m%d_%H%M%S)"
BACKUP_DIR="$BACKUP_ROOT/${VERSION}_${TS}"

info(){ echo "[$VERSION] $*"; }
fail(){ echo "[$VERSION] FOUT: $*" >&2; exit 1; }

[[ "$EUID" -eq 0 ]] || fail "Voer dit script met sudo/root uit."
for cmd in python3 nginx systemctl curl openssl; do command -v "$cmd" >/dev/null || fail "Ontbrekend commando: $cmd"; done
python3 - "$PUBLIC_IP" <<'PY'
import ipaddress,sys
ip=ipaddress.ip_address(sys.argv[1])
if ip.version != 4 or not ip.is_global:
    raise SystemExit(f'PUBLIC_IP moet een publiek IPv4-adres zijn: {ip}')
print(f'Publiek IPv4 gevalideerd: {ip}')
PY

mkdir -p "$BACKUP_DIR"
for f in /etc/nginx/sites-available/default /etc/nginx/sites-enabled/default \
         /etc/nginx/sites-available/configurator-studio /etc/nginx/sites-enabled/configurator-studio \
         /etc/nginx/sites-available/metod-pax-8790 /etc/nginx/sites-enabled/metod-pax-8790 \
         "$ACME_SITE" "$ACME_LINK"; do
    if [[ -e "$f" || -L "$f" ]]; then cp -a --no-dereference "$f" "$BACKUP_DIR/$(echo "$f" | sed 's#/#__#g')" 2>/dev/null || true; fi
done
info "Nginx-backup: $BACKUP_DIR"

# Only open the two standard web ports when UFW is already active. We do not alter
# any other firewall rules or install/enable a firewall that was not in use.
if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q '^Status: active'; then
    ufw allow 80/tcp >/dev/null
    ufw allow 443/tcp >/dev/null
    info "UFW actief: 80/tcp en 443/tcp toegestaan."
fi

mkdir -p "$WEBROOT/.well-known/acme-challenge"
chmod 0755 "$WEBROOT" "$WEBROOT/.well-known" "$WEBROOT/.well-known/acme-challenge"

# A specific port-80 vhost for the public IP lets Certbot use webroot without
# stopping nginx or disturbing other applications on this VPS.
cat > "$ACME_SITE" <<EOF2
server {
    listen 80;
    listen [::]:80;
    server_name $PUBLIC_IP;

    location ^~ /.well-known/acme-challenge/ {
        root $WEBROOT;
        default_type text/plain;
        try_files \$uri =404;
    }

    location / {
        return 404;
    }
}
EOF2
ln -sfn "$ACME_SITE" "$ACME_LINK"
nginx -t
systemctl reload nginx

PROBE="fix657r1-${TS}"
printf '%s\n' "$PROBE" > "$WEBROOT/.well-known/acme-challenge/$PROBE"
curl -fsS -H "Host: $PUBLIC_IP" "http://127.0.0.1/.well-known/acme-challenge/$PROBE" | grep -Fxq "$PROBE" || fail "Lokale ACME-webroot probe faalde"
rm -f "$WEBROOT/.well-known/acme-challenge/$PROBE"
info "ACME webroot lokaal bereikbaar."

# Certbot >=5.4 is required for webroot-based IP certificates. Use an isolated
# venv so Ubuntu's distro package version cannot silently be too old.
if [[ ! -x "$CERTBOT_VENV/bin/python" ]]; then
    if ! python3 -m venv "$CERTBOT_VENV" >/dev/null 2>&1; then
        export DEBIAN_FRONTEND=noninteractive
        apt-get update -y
        apt-get install -y python3-venv
        python3 -m venv "$CERTBOT_VENV"
    fi
fi
"$CERTBOT_VENV/bin/python" -m pip install --disable-pip-version-check --upgrade pip >/dev/null
"$CERTBOT_VENV/bin/python" -m pip install --disable-pip-version-check --upgrade 'certbot>=5.4' >/dev/null
ln -sfn "$CERTBOT_VENV/bin/certbot" "$CERTBOT_BIN"
CERTBOT_VERSION="$($CERTBOT_BIN --version 2>&1)"
info "$CERTBOT_VERSION"
python3 - "$CERTBOT_BIN" <<'PY'
import re,subprocess,sys
s=subprocess.check_output([sys.argv[1],'--version'],text=True,stderr=subprocess.STDOUT)
m=re.search(r'(\d+)\.(\d+)',s)
if not m or tuple(map(int,m.groups())) < (5,4):
    raise SystemExit(f'Certbot >=5.4 vereist, gevonden: {s.strip()}')
PY

# If a valid matching certificate already exists, keep it; otherwise first prove
# the exact challenge path against Let's Encrypt staging and only then issue prod.
needs_issue=1
if [[ -r "$CERT_FILE" && -r "$KEY_FILE" ]]; then
    if openssl x509 -in "$CERT_FILE" -noout -checkend 172800 >/dev/null 2>&1 && \
       openssl x509 -in "$CERT_FILE" -noout -text | grep -Fq "IP Address:$PUBLIC_IP"; then
        needs_issue=0
        info "Bestaand geldig IP-certificaat hergebruikt."
    fi
fi

if [[ "$needs_issue" -eq 1 ]]; then
    STAGING_NAME="metod-pax-ip-staging-${TS}"
    info "Let's Encrypt staging-validatie voor $PUBLIC_IP..."
    "$CERTBOT_BIN" certonly --staging \
        --preferred-profile shortlived \
        --webroot --webroot-path "$WEBROOT" \
        --ip-address "$PUBLIC_IP" \
        --cert-name "$STAGING_NAME" \
        --non-interactive --agree-tos --register-unsafely-without-email
    "$CERTBOT_BIN" delete --cert-name "$STAGING_NAME" --non-interactive >/dev/null 2>&1 || true

    info "Publiek vertrouwd short-lived IP-certificaat aanvragen..."
    "$CERTBOT_BIN" certonly \
        --preferred-profile shortlived \
        --webroot --webroot-path "$WEBROOT" \
        --ip-address "$PUBLIC_IP" \
        --cert-name "$PUBLIC_IP" \
        --non-interactive --agree-tos --register-unsafely-without-email
fi

[[ -r "$CERT_FILE" && -r "$KEY_FILE" ]] || fail "Certificaatbestanden ontbreken na issuance"
openssl x509 -in "$CERT_FILE" -noout -text | grep -Fq "IP Address:$PUBLIC_IP" || fail "Certificaat SAN bevat $PUBLIC_IP niet"
openssl x509 -in "$CERT_FILE" -noout -checkend 86400 >/dev/null || fail "Certificaat is minder dan 24 uur geldig"

# Automatic renewal is mandatory because Let's Encrypt IP certificates are
# short-lived (~160h). Certbot decides whether renewal is due; the timer only checks.
mkdir -p /etc/letsencrypt/renewal-hooks/deploy
cat > /etc/letsencrypt/renewal-hooks/deploy/10-reload-nginx.sh <<'HOOK'
#!/usr/bin/env bash
set -e
/usr/sbin/nginx -t
/bin/systemctl reload nginx
HOOK
chmod 0755 /etc/letsencrypt/renewal-hooks/deploy/10-reload-nginx.sh

cat > /etc/systemd/system/metod-pax-certbot-renew.service <<EOF2
[Unit]
Description=Renew Let's Encrypt certificates for METOD/PAX
After=network-online.target nginx.service
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=$CERTBOT_BIN renew --quiet
EOF2

cat > /etc/systemd/system/metod-pax-certbot-renew.timer <<'EOF2'
[Unit]
Description=Check METOD/PAX TLS certificate renewal twice daily

[Timer]
OnCalendar=*-*-* 03,15:17:00
RandomizedDelaySec=1800
Persistent=true
Unit=metod-pax-certbot-renew.service

[Install]
WantedBy=timers.target
EOF2

systemctl daemon-reload
systemctl enable --now metod-pax-certbot-renew.timer >/dev/null
systemctl is-enabled --quiet metod-pax-certbot-renew.timer || fail "Renewal timer is niet enabled"
systemctl is-active --quiet metod-pax-certbot-renew.timer || fail "Renewal timer is niet active"

info "TLS bootstrap geslaagd."
info "PUBLIC_ORIGIN=https://$PUBLIC_IP"
info "TLS_CERT_FILE=$CERT_FILE"
info "TLS_KEY_FILE=$KEY_FILE"
openssl x509 -in "$CERT_FILE" -noout -subject -issuer -dates -ext subjectAltName
