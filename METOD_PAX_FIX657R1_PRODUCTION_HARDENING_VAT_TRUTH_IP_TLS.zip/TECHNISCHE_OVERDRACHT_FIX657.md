# METOD/PAX — Technische overdracht FIX657

**Release:** `FIX657_PRODUCTION_HARDENING_VAT_TRUTH`  
**Datum:** 7 augustus 2026  
**Directe basis:** FIX656 Library + Optimizer Speed  
**Status:** build/regression/preflight/temporary production black-box groen; echte VPS/TLS smoke nog uitvoeren tijdens deploy.

---

## 1. Kernbesluit

FIX656 blijft de **functionele golden baseline**. FIX657 is bewust geen grote frontend- of
optimizer-rewrite. Deze release repareert de productiebarrières die in FIX656 nog bewust
open stonden en maakt het prijscontract rond de website-CSV ondubbelzinnig.

De release heeft drie hoofdthema's:

1. productiehardening;
2. prijswaarheid: CSV-plaatprijs is reeds inclusief BTW;
3. één optimalisatie per order + idempotente finale submit.

Alle geaccepteerde FIX654/655/656 productie-output en optimizercontracten moeten behouden
blijven.

---

## 2. Definitieve Decor Library-architectuur

Er is exact **één actieve materiaalwaarheid**: de laatst door Admin gecontroleerde en
gepubliceerde website-CSV.

### Harde regels

- alleen records met `sourceKind=CATALOG_IMPORT` mogen actief zijn;
- alleen diktes 18, 19 en 20 mm zijn toegestaan;
- elke publicatie vervangt de actieve catalogus exact;
- ontbrekende/ongeldige producten verdwijnen uit Tool A;
- vóór de eerste CSV-publicatie mag `material_library.json` leeg zijn;
- legacy/seed/manual materiaaldata mag niet als actieve bron terugkeren;
- legacy data wordt backend-only gearchiveerd bij migratie;
- de private artikelnummer → opaque public-ID registry mag blijven bestaan voor stabiele
  publieke IDs over updates/herintroducties;
- Tool A krijgt uitsluitend publieke opaque `decor_<hex>` IDs en publieke presentatievelden;
- interne artikelnummers en interne prijzen mogen niet uitlekken via publieke library/API/DOM/errors.

### Releasebaseline

`app/material_library.json` is bewust leeg met:

- `source = CSV_CATALOG_ONLY`
- `pricingModel = catalog_sell_price_incl_vat_v2`
- geen actieve records.

Bij een update van een bestaande VPS wordt het live bestand **niet overschreven**.

---

## 3. Definitieve prijs- en BTW-logica

Dit is het belangrijkste functionele FIX657-contract.

De actuele website-CSV bevat de kolom:

> `Prijs per plaat inclusief BTW`

Die kolom is letterlijk de directe verkoopprijs per plaat **inclusief 21% BTW**.

### 3.1 Wat FIX657 daarom doet

Voor elk gebruikt materiaal wordt vanuit het live private catalogusrecord de exacte
`sellPriceInclVatPerSheet` opgehaald. Dat bedrag is autoritatief en wordt op centniveau
behouden.

Voor de oude Tool B/optimizer-rekeninterface bestaan nog compatibiliteitsvelden:

- `purchasePricePerSheet`
- `sellPriceExVatPerSheet`

Deze bevatten uitsluitend het boekhoudkundige netto-equivalent:

`gross_csv_price / 1.21`

Dat netto-equivalent mag **nooit** worden geïnterpreteerd als de commerciële
plaatverkoopprijs.

### 3.2 Overige kosten

De bestaande Admin-instellingen blijven excl. BTW:

- `edgeBandPricePerM`
- `cncCostPerSheet`
- `drawingCostFixed`
- `transportCostFixed`

Daar wordt 21% BTW bovenop berekend.

### 3.3 Finale prijsformule

Laat:

- `M_gross` = som van alle plaatprijzen uit de CSV, al incl. BTW;
- `O_ex` = kantenband + CNC + tekenwerk + transport, excl. BTW.

Dan:

- `otherCostsVat = round(O_ex * 0.21, 2)`
- `totalInclVat = M_gross + O_ex + otherCostsVat`

Voor fiscale rapportage wordt daarnaast afgeleid:

- `M_ex = M_gross / 1.21` (met geldende total/line rounding);
- `materialVatIncluded = M_gross - M_ex`;
- `subtotalExVat = M_ex + O_ex`;
- `vatAmount = materialVatIncluded + otherCostsVat`.

### 3.4 Quotevelden FIX657

De server schrijft nu expliciet:

- `sheetCostTotalExVat`
- `sheetCostTotalInclVat`
- `materialVatIncluded`
- `otherCostsExVat`
- `otherCostsVat`
- `subtotalExVat`
- `vatAmount`
- `totalInclVat`
- `grandTotalInclVat`

De legacy naam `grandTotal` blijft een excl.-BTW compatibiliteitswaarde en mag niet als
zichtbare finale consumentenprijs worden gebruikt.

### 3.5 Tool A prijsweergave

Tool A gebruikt voor de finale zichtbare prijs uitsluitend de server-side
`pricingSummary.totalInclVat` van de volledig afgeronde job. De browser mag de finale
prijs niet zelfstandig reconstrueren uit een gedeeltelijke quote.

### 3.6 Geteste actuele CSV

De door de gebruiker voor FIX657 aangeleverde CSV is tijdens de build rechtstreeks getest.
De CSV zelf zit niet in de release.

SHA-256:

`053026e2883908bed7bfd05c8c39543d91ef611ff24e40b2546003e6e3127950`

Parserresultaat:

- rowsRead: 606
- eligible: 597
- excludedThickness: 9
- blockingErrors: 0
- warnings: 18

Een echte prijs van EUR 69,57 incl. BTW bleef exact EUR 69,57.

---

## 4. Waarom de oude FIX656-prijs verwarrend was

FIX656 las de CSV-prijs goed in, maar converteerde hem vóór Tool B naar een netto-equivalent
en presenteerde/verwerkte materiaalcomponenten vervolgens hoofdzakelijk als ex-BTW
`sellPriceExVatPerSheet` / `sheetCostTotal`.

De finale totaalprijs kon daardoor rekenkundig alsnog op hetzelfde bruto bedrag uitkomen
wanneer daarna 21% over het totaal werd gezet, maar:

- de plaatregel zelf stond semantisch als excl. BTW;
- quote/auditvelden konden de verkeerde businessbetekenis suggereren;
- latere consumers konden `sheetCostTotal` fout interpreteren;
- het contract uit de CSV was niet expliciet genoeg beschermd.

FIX657 maakt daarom de bruto CSV-waarde expliciet en berekent BTW alleen nog bovenop de
andere Admin-kosten.

---

## 5. Production hardening

### 5.1 Fail-closed runtime

`_validate_production_runtime_or_die()` draait vóór de server bindt.

In productie zijn minimaal verplicht:

- `APP_ENV=production`
- `PRODUCTION_HARDENING=1`
- `ADMIN_HASH_ONLY=1`
- `ADMIN_STAGING_OPEN=0`
- expliciete HTTPS `ALLOWED_ORIGINS`
- expliciete HTTPS `ALLOWED_ADMIN_ORIGINS`
- `PUBLIC_JOB_MAX_CONCURRENT=1`
- `PUBLIC_JOB_MAX_CONCURRENT_PER_IP=1`
- publieke JSON/body-limieten binnen de FIX657 maxima;
- externe hash-only Admin credentials;
- mode 0600 op Linux;
- password-reset activation uit.

Bij een fout start de server niet.

### 5.2 Origin/CSRF-contract

In productie is Host-fallback uitgeschakeld voor publieke en Admin-writes.
Een request moet een Origin/Referer hebben die exact in de bijbehorende HTTPS allowlist
staat.

Loopback rescue blijft alleen lokaal beschikbaar; de backend bindt aan `127.0.0.1` en is
niet rechtstreeks publiek routable.

### 5.3 TLS/Nginx

`DEPLOY_FIX657.sh`:

- vereist `PUBLIC_ORIGIN=https://...`;
- vereist een bestaand certificaat + private key;
- zet Nginx op 80 → 443 redirect;
- serveert productie op TLS 1.2/1.3;
- proxyt naar `127.0.0.1:8792`;
- verwijdert de oude enabled Nginx acceptatiesite op poort 8790;
- gebruikt geen development-fallback.

### 5.4 Admin-cookie

De Admin-sessioncookie is:

- `HttpOnly`
- `SameSite=Lax`
- in production ook `Secure`.

### 5.5 Jobtokens

FIX657 accepteert één transport:

`Authorization: Bearer <job-token>`

Niet meer geaccepteerd:

- `X-Job-Token`
- `?token=...`
- body `accessToken`
- body `jobAccessToken`.

Tool A bewaart de jobtoken alleen in `sessionStorage`/memory. Een oude localStorage-token
wordt verwijderd.

### 5.6 Publieke SSE

`/api/events` is publiek, maar `_PUBLIC_SSE_EVENT_ALLOWLIST` bevat alleen:

`dxf_changed`

De publieke payload bevat alleen `dxfVersion`.

Niet publiek uitgezonden:

- request submitted;
- request cancelled;
- request processing;
- request done;
- request failed;
- request IDs;
- error details;
- DXF filename/category metadata.

### 5.7 Requestlimieten

Productiebaseline:

- `PUBLIC_JSON_MAX_BYTES = 16 MiB`
- `SUBMIT_MAX_BYTES = 8 MiB`
- `PUBLIC_DXF_BLOB_MAX_BYTES = 2 MiB`

Dit sluit aan op het compacte FIX655 DXF-wirecontract.

---

## 6. Submit/queue: één optimalisatie per order

### 6.1 Probleem in FIX656

De normale flow was:

1. `/api/jobs` optimaliseert;
2. klant ziet de prijs;
3. `/api/submit_config` maakt request/queue-item;
4. worker riep opnieuw `_create_job_from_payload(payload)` aan.

Daardoor kon dezelfde order dubbel worden genest.

### 6.2 FIX657-model

`/api/jobs` is de enige route die optimalisatie mag starten.

`/api/submit_config`:

1. vereist `parentJobId` / bestaande berekende job;
2. vereist geldige Bearer-jobtoken;
3. vereist `_finalization_complete(parent_root)`;
4. haalt subjobs uitsluitend server-side op;
5. leest de strikte serverprijs uit `calculation_summary.txt`;
6. weigert submit als geen positieve `totalInclVat` bestaat;
7. reserveert atomair één submission claim per parent-job;
8. slaat de aanvraag op als gekoppeld aan de reeds afgeronde job;
9. maakt **geen nieuwe optimizer-queuejob**.

### 6.3 Idempotency

Private markers staan onder:

`app/system/index/submission_idempotency/`

De markernaam is een SHA-256 van de parent-job-ID en bevat private server-side linkage.

Eerste submit claimt atomair met `O_CREAT|O_EXCL`.
Een tweede/dubbele klik:

- krijgt de bestaande request terug wanneer die al persisted is;
- of krijgt tijdelijk 409 zolang de eerste submit tussen claim en status-write zit.

Een crash-marker zonder request mag na vijf minuten worden gereclaimed.

### 6.4 Legacy queue

De worker mag niet meer `_create_job_from_payload` starten.

Veilige reeds-finalized legacy linkage kan worden hersteld.
Een onveilige oude queue-entry faalt closed met:

`LEGACY_QUEUE_ITEM_REQUIRES_REVIEW`

Nooit automatisch opnieuw optimaliseren.

---

## 7. Finalization blijft heilig

`returncode == 0` is niet genoeg.

De finale job moet nog steeds de bestaande FIX654-chain volledig doorlopen. Belangrijke
outputs/contracten:

- placements;
- report;
- quote;
- labels/stickers;
- StickerTool JSON;
- DXF Zaagplaten;
- DXF Onderdelen;
- links/subjobs waar van toepassing;
- `output/finalization.json` met status COMPLETE.

Submit mag pas daarna.

---

## 8. Optimizercontract blijft ongewijzigd

FIX657 verandert de primaire optimizerdoelstelling niet.

Harde objective:

> gebruik zo weinig mogelijk platen.

Performanceverbeteringen mogen nooit een extra plaat accepteren.

De bestaande FIX656-mechanismen blijven aanwezig:

- fixed-grid lower bound;
- early optimal lower-bound exit wanneer optimaliteit bewezen is;
- DXF geometry reuse/cache;
- server-side hardlink/copy deduplicatie van gelijke DXF blobs;
- compact DXF reference transport;
- grain/composite constraints blijven bepalend.

Doorlopende nerf mag nooit stiekem worden geroteerd of losgekoppeld voor snelheid.

---

## 9. Belangrijkste gewijzigde bestanden

### `app/server_py.py`

- FIX657 build marker;
- productie runtimevalidator;
- HTTPS-origin fail-closed checks;
- Secure Admin-cookie;
- SSE allowlist/privacy;
- kleinere productielimieten;
- gross-first materiaalprijscontract;
- mixed-VAT quote/totals;
- aangepaste calculation summary;
- uitgebreide Admin/ntfy prijsparsing;
- final submit linkage + idempotency;
- queue worker mag niet meer optimaliseren;
- safe legacy queue recovery.

### `app/server_helpers.py`

- header-only Bearer tokenextractie;
- strengere productie-originlogica.

### `app/toolA.html`

- FIX657 marker;
- `decor_library.js?v=657`;
- final submit verstuurt Bearer-token;
- jobtoken in `sessionStorage`;
- oude duurzame jobtoken wordt verwijderd;
- geen zichtbare finale prijs uit onbetrouwbare client-side fallback.

### `app/dxf_nesting_optimizer.py`

- quote behoudt expliciet gross/ex VAT materiaalvelden;
- nesting objective/geometrylogica verder ongemoeid.

### `app/pricing_helpers.py`

- parser ondersteunt mixed-VAT componenten.

### `tools/final_preflight.py`

- productiehardeningcontracten;
- gross CSV prijscontract;
- queuecontract;
- session-scoped jobtoken;
- CSV-only library;
- Admin prijsvelden.

### `tools/fix657_regression.py`

Deterministische no-network regressies voor:

- CSV gross-price truth;
- echte aangeleverde CSV optioneel via `--csv`;
- pricing material mapping;
- mixed VAT quote;
- calculation summary parser;
- header-only tokens;
- SSE privacy;
- queue no-optimizer;
- submission idempotency;
- productie runtime guard;
- source contracts.

### `DEPLOY_FIX657.sh`

Production-only deploy/hardening. Vereist echte HTTPS-config.

---

## 10. Live state: absoluut behouden

Bij elke update moeten deze paden van de live VPS leidend blijven en niet uit de release
worden overschreven:

```text
app/jobs/
app/requests/
app/queue/
app/archive/
app/backups/
app/drafts/
app/system/
app/decor_media/
app/material_library.json
app/config/pricing_active.json
app/config/pricing_versions/
app/config/pricing_audit.jsonl
app/embedded_dxfs/
app/embedded_dxfs_manifest.json
```

Waarom:

- orders/jobs zijn productiehistorie;
- requests/queue bevatten aanvraagstate;
- system bevat private registries/importhistorie/idempotency;
- decor_media is live gecachte catalogusmedia;
- `material_library.json` is de laatst gepubliceerde CSV-waarheid;
- pricing_active bevat actuele Admin-kosten;
- embedded DXFs zijn beheerde productieassets.

Op een volledig verse installatie mogen release-seeds worden gebruikt; op een bestaande
VPS nooit blind.

---

## 11. Deploycontract FIX657 / FIX657R1

### 11.1 Voorwaarden

De VPS-inspectie van 2026-08-08 heeft de productie-endpoint vastgesteld op IPv4
`51.195.102.180`. Er was nog geen Certbot-installatie en geen bestaande Let's Encrypt
certificate tree. FIX657R1 lost dit op zonder een fictief domein te introduceren.

De R1 Termius-installer gebruikt daarom standaard:

```bash
PUBLIC_IP=51.195.102.180
PUBLIC_ORIGIN=https://51.195.102.180
ADMIN_ORIGIN=https://51.195.102.180
TLS_CERT_FILE=/etc/letsencrypt/live/51.195.102.180/fullchain.pem
TLS_KEY_FILE=/etc/letsencrypt/live/51.195.102.180/privkey.pem
ADMIN_CREDENTIALS_FILE=/etc/adzaagt/metod-pax/admin_credentials.live.json
```

`BOOTSTRAP_IP_TLS_FIX657R1.sh` installeert geïsoleerd Certbot >=5.4, valideert eerst
tegen Let's Encrypt staging, vraagt daarna het publiek vertrouwde short-lived IP-certificaat
aan en installeert automatische renewal. `DEPLOY_FIX657.sh` blijft zelf fail-closed en
vereist daarna de daadwerkelijk bestaande certificaatbestanden.

### 11.2 Wat deploy doet

- externe configbackup;
- live Admin-prijzen behouden;
- obsolete `sheetPriceFactor` verwijderen;
- pricingModel v2 markeren;
- CSV-only migratie idempotent uitvoeren;
- lokale catalogusmedia voorbereiden;
- productie-env atomair schrijven;
- systemd service schrijven;
- HTTPS Nginx-site schrijven;
- oude :8790 enabled listener verwijderen;
- Python/JS/source preflights;
- FIX657 regressie;
- production final_preflight;
- `nginx -t`;
- service restart;
- loopback smoke;
- public HTTPS smoke via `curl --resolve` zodat hostname/certificaat echt worden gevalideerd.

### 11.3 Niet doen

- geen `PRODUCTION_HARDENING=0`;
- geen HTTP-origin om een fout te omzeilen;
- geen plaintext Admin-password in release of env;
- geen live catalogus vervangen door de lege release-library;
- geen live pricing vervangen door release-defaults;
- geen runtime-orderdirs verwijderen;
- geen worker opnieuw laten optimaliseren bij submit.

---

## 12. Tests die voor deze release zijn uitgevoerd

Zie `FIX657_TEST_REPORT.txt` voor de exacte resultaten.

Samengevat:

- Python compile: PASS;
- standalone JS: PASS;
- 26 inline Tool A JS-blokken: PASS;
- bash syntax: PASS;
- actuele CSV parser: PASS;
- mixed VAT arithmetic: PASS;
- header-only token: PASS;
- SSE privacy: PASS;
- submit idempotency: PASS;
- queue no-optimizer: PASS;
- productie runtime guard: PASS;
- production preflight: PASS;
- tijdelijke production black-box: PASS;
- 20 gerichte FIX654/655/656 golden-contractchecks: PASS.

---

## 13. Productie-black-box bevindingen

Een disposable kopie van FIX657 is in production mode op loopback gestart met tijdelijke
hash-only credentials en een test-HTTPS origin.

Bevestigd:

- publieke catalogus lekt geen intern article/material/price veld;
- productie-write zonder Origin wordt geweigerd;
- vreemde Origin wordt geweigerd;
- query-token wordt geweigerd;
- Bearer-token werkt;
- Admin-login zonder Origin wordt geweigerd;
- lokale loopback rescue bereikt pas hash-auth bij toegestane Origin;
- HSTS verschijnt in trusted HTTPS proxy context;
- CSP aanwezig;
- X-Frame-Options DENY aanwezig.

De echte VPS/TLS smoke moet nog tijdens live deploy gebeuren, omdat de productiehost en
certificaatpaden niet in deze buildomgeving aanwezig zijn.

---

## 14. Rollbackfilosofie

FIX657-deploy moet altijd twee dingen kunnen terugzetten:

1. volledige applicatiedirectory van vóór rsync;
2. externe `/etc`/systemd/Nginx-config van vóór hardening.

De Termius one-shot die bij de release hoort maakt daarom een volledige app-backup en een
config-tar vóór de live switch. Bij een fout wordt code/config teruggezet en worden
systemd/Nginx opnieuw geladen.

Live data blijft sowieso buiten de release-rsync door de expliciete excludes.

---

## 15. Wat een volgende ontwikkelaar niet opnieuw moet ontwerpen

Deze punten zijn beslist:

- CSV is enige actieve Decor Library-bron;
- public IDs zijn opaque;
- interne artikelnummers zijn private;
- CSV-plaatprijs is verkoopprijs incl. BTW;
- geen materiaalmarkupfactor;
- vier overige Admin-kosten blijven excl. BTW;
- Tool A zichtbare finale prijs komt van server-side finalized pricing summary;
- `/api/jobs` optimaliseert;
- `/api/submit_config` linkt;
- submit is idempotent;
- finalization COMPLETE is harde gate;
- optimizer objective is minimale platen;
- FIX654/655/656 output- en UX-contracten blijven golden;
- productie is HTTPS/fail-closed.

---

## 16. Eerstvolgende live acceptatietests na deploy

Na een echte FIX657 VPS-deploy moeten minimaal deze handmatige businesschecks worden gedaan:

1. open Tool A via de definitieve HTTPS-host;
2. controleer dat HTTP automatisch naar HTTPS redirect;
3. laad Decor Library en controleer dat de actuele gepubliceerde CSV-records er nog zijn;
4. kies een materiaal waarvan de CSV-prijs bekend is;
5. maak een order die aantoonbaar één plaat gebruikt;
6. controleer dat de plaatregel exact de CSV-prijs **incl. BTW** toont;
7. controleer dat CNC/kantenband/tekenen/transport als excl. BTW componenten staan;
8. controleer finale `totalInclVat` met handberekening;
9. controleer `calculation_summary.txt`;
10. controleer `quote.json` gross/ex velden;
11. controleer DXF Zaagplaten;
12. controleer DXF Onderdelen;
13. controleer StickerTool/labels;
14. klik finale verzendknop één keer → één request;
15. dubbelklik/snel twee keer → nog steeds één request, geen nieuwe optimalisatie;
16. controleer Admin inbox/pricing breakdown;
17. controleer dat publieke URL met `?token=` geen jobstatus opent;
18. controleer dat gewone workflow met Bearer-token wel blijft werken;
19. controleer server/systemd/nginx logs op fouten;
20. pas daarna FIX657 als live golden markeren.

---

## 17. Conclusie

FIX657 is de production-hardening release bovenop de functioneel geaccepteerde FIX656
baseline. De grootste functionele correctie is dat het CSV-prijscontract nu end-to-end
expliciet klopt: de plaatprijs is al inclusief BTW, terwijl alleen de overige Admin-kosten
nog 21% BTW bovenop krijgen.

De tweede structurele correctie is dat een klantorder niet meer twee keer geoptimaliseerd
kan worden door calculate + submit. De finalized calculation is voortaan één immutable
productiewaarheid waarop de aanvraag wordt gelinkt.

De release is lokaal uitgebreid gevalideerd. De enige nog niet uitvoerbare stap in deze
buildomgeving is de echte VPS/TLS smoke met de definitieve productiehost/certificaten.

## FIX657R1 TLS deployment revision — 2026-08-08

The VPS inspection established that the live host has no existing Let's Encrypt tree and no Certbot installation, while the application is currently proxied from nginx `:8790` to loopback `127.0.0.1:8792`. As of 2026, Let's Encrypt supports publicly trusted IPv4 certificates via the mandatory `shortlived` profile; Certbot 5.4+ supports IP issuance through `webroot`.

FIX657R1 therefore adds `BOOTSTRAP_IP_TLS_FIX657R1.sh`. For the current VPS it issues a certificate for `51.195.102.180`, stores it under `/etc/letsencrypt/live/51.195.102.180/`, and installs a twice-daily systemd renewal check. The final nginx HTTP vhost permanently serves `/.well-known/acme-challenge/` before redirecting all other traffic to HTTPS. This is required because IP certificates are short-lived and renewal must be fully automated without nginx downtime.

Application/business logic is unchanged from FIX657. The CSV price contract remains `catalog_sell_price_incl_vat_v2` and the production/security/idempotency fixes remain unchanged.

### FIX657R1 deployment launcher

`INSTALL_FIX657R1_FROM_STAGE.sh` is part of the release archive. The Termius launcher is intentionally short: it downloads the exact GitHub Raw ZIP, verifies the fixed archive SHA-256, tests/extracts it, verifies `SHA256SUMS.txt`, and invokes this staged installer. The staged installer then performs all regressions, TLS bootstrap, production preflight, backups, state-preserving rsync, service/nginx deployment and final ACME renewal-path verification.
