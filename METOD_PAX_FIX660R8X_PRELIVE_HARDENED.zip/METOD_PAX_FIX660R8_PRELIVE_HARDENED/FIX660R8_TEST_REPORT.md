# FIX660R8 test report

## R8X Admin-DXF-naamregressie

- Een echte finalized lifecyclejob levert in requestmanifest en technische
  joblijst exact `Test Klant__Lifecycle testmateriaal__001.dxf`.
- De losse `output/DXF_Zaagplaten`-route en de legacy `output/sheets`-route
  projecteren dezelfde Content-Disposition-naam; `Sheet_002.dxf` wordt `002`.
- De DXF-ZIP bevat de herkenbare plaatnaam onder een collision-safe
  materiaalmap. Onveilige tekens in klantnamen worden begrensd gesaneerd.
- Na alle downloadprojecties blijft de bestaande finalization-/tampercontrole
  groen: het verzegelde DXF-bestand op schijf is niet gewijzigd.

## R8W regressies

- Uitgevoerde contracttest: twee materiaal-lokale groepen met beide UI-id `G01`
  worden als job-globale productiegroepen `G001` en `G002` geëxporteerd.
- Backendtest met vier panelen bevestigt dat twee geldige groepen op twee
  materialen worden geaccepteerd. De oude export met tweemaal `G001` reproduceert
  exact `spans multiple materials or thicknesses` en bewijst daarmee dat de
  gemelde worteloorzaak wordt afgedekt.
- Uitgevoerde resettest simuleert Safari `pageshow` met vooraf ingevulde
  klantcontrols. Alle tien velden, de checkbox, live klantglobal, checkoutstate,
  snapshots en notitie zijn daarna leeg; de eenmalige resetflag is verwijderd.
- De bestaande plaatsingsfingerprints bewaken dat optimizer/nesting ongewijzigd
  zijn.

## R8V nerfgroep-readinessregressie

- Uitgevoerde frontendtest: G01 met twee panelen van 197×797 mm is geldig vóór
  enige canvasrender en blijft geldig na het tekenen van de preview.
- Negatieve frontendtests: verschillende werkelijke breedtes, één enkel paneel
  en een verwijzing naar een verwijderd paneel blokkeren de route met een
  specifieke structurele fout.
- De definitieve submit herhaalt dezelfde autoritatieve datacontrole; een
  canvas/drawerstatus kan geen geldige, reeds geoptimaliseerde job blokkeren.
- De bestaande 200-/250-paneel-placementfingerprints blijven de ongewijzigde
  optimizer- en nestingalgoritmen bewaken.

## R8U submitroute-regressie

- Uitgevoerde frontendtest: één fysieke CTA-tik doet exact één
  `POST /api/submit_config` met parent-job, onveranderlijke klantensnapshot en notitie.
- Uitgevoerde frontendtest: een matching pre-calculation nerf-attestation blijft geldig
  wanneer iOS de previewdrawer na de berekening loskoppelt.
- Uitgevoerde frontendtest: `requestId` wordt opgeslagen vóór het bedanktscherm opent.
- Server-lifecycletest: de definitieve submit schrijft `requests/<requestId>`, behoudt
  alle klantvelden en dezelfde rij verschijnt via `/api/admin/requests`.
- Negatief contract: zonder nerf-attestation start de optimizer niet; zonder server-
  `requestId` wordt de aanvraag niet als verzonden gemarkeerd.

Datum: 13 augustus 2026  
Build: `FIX660R8_PRELIVE_HARDENED`  

R8T voegt een echte mobiele browserdiagnose toe bovenop de regressies. De publieke
R8S-build leverde 597 decors, een schone 50/50-footer en volledige klantstate,
maar reproduceerde een lege removal-hook en een native uitgeschakelde eindknop.
Na herstel bewijst de DOM-contracttest volledige klantweergave, een klikbare CTA
en exact één canonieke submit-aanroep. De daadwerkelijke submit-POST wordt in de
browsertest onderschept zodat geen synthetische aanvraag in Admin ontstaat.
Resultaat bron-/artifactgate: PASS wanneer `tools/final_preflight.py --verify-checksums` zonder fouten eindigt.

R8S voegt uitvoerende regressies toe voor de resterende live oorzaken: een
prijsrefresh mag de iOS-submitknop nooit native disabled achterlaten, een
gedeeltelijke oude klantensnapshot wordt veldgewijs aangevuld, één prullenbaktik
bereikt exact één centrale verwijdertransactie en de bevestigingsdialoog heeft
een hogere stacking-laag dan de mobiele materialen-drawer.

## Uitgevoerde suites

| Gate | Bewijs | Verwacht |
|---|---|---|
| Python compile | alle `app/*.py` en `tools/*.py` in-memory | PASS |
| Bash syntax | deploy- en installerscript | PASS |
| JavaScript syntax | alle losse JS-assets plus inline Tool A/Admin scripts | PASS |
| Safety/golden | `tools/fix660r8_safety_tests.py` — inclusief 200/250-placementfingerprints en durabilitybatch-faultinjectie | PASS |
| Server lifecycle | `tools/fix660r8_server_lifecycle_tests.py` — 10 tests, inclusief volledige-familygate en checkout→Admin-klantketen | PASS |
| Publieke FIFO/durability | `tools/fix660r8_public_queue_tests.py` — 6 tests voor queuebounds, FIFO, per-IP, annulering, restartreconciliatie en parent-directory-fsync vóór 202/Popen | PASS |
| Performancecontract | `tools/fix660r8_performance_tests.py` — 11 tests voor cache-invalidatie, status-hashbudget, hardlinkbatch-durability, tokenrotatie, quote-sealing en browserpolling | PASS |
| Echt HTTP-proces | `tools/fix660r8_http_smoke_tests.py` — liveness/readiness/Tool A/CSV-preview/catalogusbeeld | PASS |
| Restore adversarial | `tools/fix660r8_restore_tests.py` — 3 tests | PASS |
| Functionele regressie | `tools/fix660_regression.py` | `FIX660 REGRESSION: PASS` |
| Releaseboom | exact intern SHA-256-manifest; geen symlink/pycache/pyc/bak | PASS |
| Runtimecontract/SBOM | Pythonbereik, imports, requirements en CycloneDX | PASS |

De volledige artifactpreflight is daarnaast op de doel-VPS onder Python 3.14.4
uitgevoerd. Alle inhoudelijke gates waren daar groen; de oorspronkelijke R8/R8A
stopte uitsluitend omdat het declaratieve runtimecontract nog `<3.14` vermeldde.
De gecorrigeerde revisie ondersteunt daarom expliciet Python `>=3.10,<3.15`.

R8C simuleert aanvullend de installer-state-markerimport rechtstreeks vanuit
een read-only uitgepakte immutable release. Na die import blijft de releaseboom
vrij van `__pycache__` en `.pyc`; een tweede volledige build moet byte-identiek
zijn.

R8E start aanvullend `app/server_py.py` als werkelijk subprocess op een vrije
loopbackpoort. De gate eist een exact buildantwoord van `/health/live`, een
gestructureerd antwoord van `/health/ready` en een HTTP 200 voor Tool A. Deze
test is lokaal expliciet onder CPython 3.14.4 uitgevoerd.

R8F breidt diezelfde procesgate uit met een geauthenticeerde CSV-preview over
HTTP en een publieke materiaalcatalogus waarvan het lokale beeld daadwerkelijk
als `image/jpeg` wordt opgehaald. Een bewust aangelegde oude afgeleide
cataloguscache moet daarbij automatisch worden verworpen en opnieuw opgebouwd.

R8G voert aanvullend de mobiele preview-drawer in een gesimuleerde iOS-pointerketen
uit. De gate eist dat de drawer standaard gesloten is, met exact één tap opent,
een door Safari afgeleide click niet dubbel verwerkt, tijdens slepen een zichtbare
`important`-transform heeft en na de drempel weer sluit. De Admin-bron wordt ook
statisch gecontroleerd op de expliciete staging-versus-publicatiepoort.

R8H controleert aanvullend dat de retired FIX649-selector het actieve canvas
niet meer met `display:none !important` kan verbergen en dat de geopende
FIX660-drawer met een specifiekere ownershipselector zelfstandig een zichtbaar,
donker en vast bemeten previewvlak afdwingt. De bestaande uitvoerende canvasgate
blijft bovendien echte panelen in uniforme millimeterschaal tekenen.

R8I voert dezelfde canvasrenderer daarnaast met een desktop-mediaquery uit en
eist daar een zichtbaar, correct bemeten canvas plus een groene productie-readiness.
Voor mobiel wordt de drawerbovenkant tegen de gemeten headeronderrand gebonden,
zijn dubbele intro-/samenvattingsregels afwezig en blijft de inklapgreep binnen
de geopende drawer. De optimizer-hot-pathtest weigert iedere duurzame schrijfactie
van tijdelijke voortgangssnapshots. Een 100-panelenbenchmark met identieke input
en zes identieke outputplaten mat 2,543 seconde op R8 en 1,252 seconde op R8I;
een tweede R8-baselinerun mat 2,100 seconde.

R8J voegt twee zware optimizerproeven toe: 250 identieke echte METOD-panelen en
200 gemengde echte METOD-panelen. De gates eisen respectievelijk 250/250 en
200/200 unieke plaatsingen, 12 en 10 productieplaten, geldige sheetgeometrie,
volledige outputhashes, geen equivalente meervoudige strategieruns en behoud van
de gemeten plaatkwaliteit. De publieke lifecycle bewijst aanvullend met een
uitvoerende mock-teller dat twee PartIds met één gedeelde compacte DXF-body maar
één volledige DXF-parse uitvoeren.

R8K voert daarnaast een volledige publieke 250-PartId-lifecycle uit met één
gedeelde echte METOD-DXF. De gate eist dat de servercanonieke DTO compact blijft,
de subjobinput precies één content-addressed body en 250 refs bevat, Tool B de
body één keer laadt, alle 250 placements maakt en de finalizer toch 250 afzonderlijke
onderdeel-DXF's, labels en StickerTool-identiteiten verzegelt. De mobiele Node-gate
bewijst bovendien dat een geselecteerde lege G02 niet meer stil terugvalt naar G01;
statische contractchecks eisen dat een nieuwe groep breedteneutraal begint en de
vorige breedtefilter wist.

R8L voegt een browserachtige DOM-runtimeproef van de echte Tool A-submitketen toe.
De succesroute klikt `Prijs berekenen`, ziet de optimalisatie-overlay, bouwt een
compacte payload met een echte ingebedde METOD-DXF, verstuurt `/api/jobs`, verwerkt
100% status en opent de prijsoverlay. De geforceerde fout-route eist dat de
optimalisatie-overlay verdwijnt en de oorspronkelijke servermelding zichtbaar
wordt. De vaste regressiegate controleert daarnaast de cross-scope cachebridge,
de zichtbaarheid van de jobstartstatus in `catch` en het Safari-paint-frame.

R8N controleert aanvullend dat template-initialisatie vóór het asynchrone laden
plaatsvindt en dat er na de await geen harde navigatie naar Stap 1 meer bestaat.
De mobiele basketmodule wordt in Node uitgevoerd met twee materialen en moet
exact één actieve selectie plus publieke naam, dikte en plaatafmeting opleveren.
Statische contractchecks bewijzen daarnaast de expliciete public allowlist,
mobiele/desktop-scheiding en de toegankelijke sluitpaden van de bottom sheet.

R8O controleert dat de oude single-material sticky bar verdwijnt wanneer het
multi-material mandje actief is. De submitcontractchecks eisen dat een
authoritatieve eindprijs de CTA klikbaar houdt, dat verborgen lege velden geen
vastgelegde klantstate overschrijven en dat ontbrekende klant- of previewdata
naar de juiste herstelstap navigeert. De bestaande optimizerfingerprints blijven
ongewijzigd en bewaken dat deze UI-reparatie geen plaatsingsalgoritme raakt.

R8P controleert aanvullend dat de mobiele footer uit één compacte 50/50-rij met
gelijke hoogtes bestaat, dat verwijderen na het sluiten van de drawer de
autoritatieve materiaalmutatie bereikt en dat één echte tik op de definitieve
verzendknop precies één canonieke submitfunctie aanroept. De Node-harnas bewijst
daarbij dat de document-capture bridge de oude target-listeners onderdrukt zonder
een tweede request te starten.

R8Q voert de werkelijke laat in de DOM gemaakte verzendknop uit in Node. Eén
fysieke tik moet precies één POST naar `/api/submit_config` opleveren, terwijl de
knop tijdens transport is vergrendeld en de wire-payload uitsluitend joblinks,
de volledige vastgelegde klant en notitie bevat. Een afzonderlijke stateproef
maakt alle verborgen formuliercontrols leeg en bewijst dat naam, bedrijf, e-mail,
telefoon, factuur-/bezorgadres, postcode en huisnummer toch intact uit de
berekeningssnapshot komen. De serverlifecycle verzendt vervolgens expres een lege
laatste browserklant, herstelt hem uit de verzegelde finalized job en vergelijkt
ieder veld met de echte Admin-requestlijst. De mobiele Node-proef controleert
zowel directe verwijdering zonder panelen als zichtbare bevestiging met panelen,
ieder met exact één autoritatieve materiaalmutatie.

R8R test niet alleen de uiteindelijke knopbinding maar extraheert en voert de
vóór alle legacycode geplaatste document-capture eigenaar uit. De eerste fysieke
submit-tik moet één canonieke functie bereiken, propagation direct beëindigen en
kan daardoor geen oudere listener meer raken. In dezelfde uitvoerende proef legt
de berekenknop alle live klantvelden inclusief adres/huisnummer en notitie vast;
één mobiele prullenbaktik bereikt precies één basketactie. Statische CSS-gates
eisen transparante actierails en schaduwloze footertegels.

R8M vergrendelt de semantische productieplacements van de bestaande zware
200- en 250-panelenfixtures met respectievelijk
`ed60059734db859fd4588f226c8bdcb96d65863a38b2eaeed80f0228af8c1ec2` en
`30145ef74df9aef1d4385549ae9a67e8dcb6c19f0b2e98dff63e974c059ff998`.
Een afzonderlijke performancecontractsuite bewijst dat een warme catalogus niet
opnieuw wordt geparsed, een bestand met dezelfde grootte en herstelde mtime toch
door ctime-invalidatie wordt herhasht, een DONE-status ieder fysiek artifact
hoogstens één keer hasht en een identieke vervolgpoll nul fysieke hashes uitvoert.
De 250-PartId-proef met één gedeelde DXF begrenst de bronhashing op O(unieke
bodies): hoogstens drie fysieke blobhashes in plaats van 252. Dezelfde proef controleert
dat `input`, `input/dxf_blobs` en `output/DXF_Onderdelen` elk eenmaal als complete
hardlinkbatch duurzaam zijn gepubliceerd vóór de terminale DONE-overgang.
De Node-route bewijst direct DONE met één statusfetch en nul animatietimers; een
processing→DONE-route gebruikt alleen de ene echte pollingtimer. De durability-
faultinjectie bewijst bovendien dat een batch bij een fout tijdens voorbereiding
geen gedeeltelijke doelbestanden publiceert.

## Kritieke uitkomsten die werkelijk worden getest

- positie 1/2/3 heeft de overeengekomen fysieke bottom-to-top volgorde;
- ARC-geometrie roteert in alle kwadranten;
- bboxmismatch publiceert nul sheet-DXF's;
- nonfinite en adversarial paneelvelden worden geweigerd;
- path traversal wordt geweigerd;
- machining-droppende fallback bestaat niet;
- de echte optimizer produceert één complete jobfamilie vanuit de publieke canonieke DTO;
- iedere finalization-hash wordt opnieuw gecontroleerd;
- een gemanipuleerde quote verdwijnt uit publieke status en maakt de jobfamilie ongeldig;
- Admin-manifestopbouw verandert geen byte en toont geen niet-verzegeld bestand;
- cancellation maakt bestaande artifacts niet downloadbaar;
- catalogusreviewhash verandert bij een gewijzigde warning;
- catalogusimage DNS wordt gepind en private IP's falen gesloten;
- imagecache-tampering wordt gedetecteerd;
- JSONL-rotatie behoudt het nieuwe event;
- tijdelijke optimizerprogressie blijft atomisch maar forceert geen file- of directory-fsync;
- 200–250 panelen veroorzaken geen herhaalde beoordeling van equivalente pending-items;
- compacte gedeelde DXF-bodies worden één keer geparsed en blijven per PartId afzonderlijk op bbox gecontroleerd;
- compacte DXF-bodies blijven ook ná publieke validatie compact op master- en subjobschijf;
- een nieuwe lege nerfgroep blijft geselecteerd en toont opnieuw alle vrije breedtes;
- `Prijs berekenen` bereikt na DXF-cachehergebruik aantoonbaar de job-POST en toont vanaf de eerste voorbereidingsfase de optimalisatie-overlay;
- een vroege submitfout verbergt de optimalisatie-overlay en toont de echte fout in plaats van een half-afgebouwde stap 5;
- een directe DONE-response gebruikt de definitieve prijs zonder tweede statusfetch of procent-voor-procentwachttimers;
- statuspolling hergebruikt verzegelde hashresultaten en een mutation-sensitive catalogussnapshot zonder integriteitscontrole bij downloads te versoepelen;
- de 200- en 250-paneelplacements blijven byte-semantisch gelijk aan de vastgelegde algoritmefingerprints;
- desktop en mobiel renderen dezelfde nerfgroep in dezelfde echte millimeterschaal;
- een echte applicatiebackup wordt gemaakt, volledig geverifieerd en naar een nieuwe stateboom hersteld, inclusief idempotencymarker en catalogus;
- restore weigert hashmanipulatie, traversal, extra leden en een bestaand target;
- prijs-, material-, auth-, privacy-, Grain Studio-, mobiele UI-, catalogus- en installerregressies blijven groen.

## Testisolatie

Lifecycle- en restoretests gebruiken tijdelijke externe state en verwijderen die na afloop. Ze schrijven niet naar echte klant-, VPS- of Library-state. De lifecycle gebruikt wel een echte ingebedde METOD-DXF en de echte optimizer/finalizer.

## Niet door de artifactgate bewezen

De volgende evidence moet buiten dit pakket worden geleverd:

- volledige VPS-installatie onder de gegenereerde systemd/Nginx-config;
- extern TLS-/HTTP-redirect- en firewallbewijs;
- load-, slow-client-, disk-full-, inode-full- en deploychaostest op representatieve hardware;
- versleutelde off-host overdracht en restore vanuit uitsluitend die kopie;
- acceptatie van de actuele live CSV-waarschuwingen door de materiaaleigenaar;
- echte iPhone/Safari-video en logs;
- onafhankelijke CAM-import, werkplaatscontrole en fysieke proefsnede.

Daarom is een groene artifactgate noodzakelijk, maar niet voldoende voor publiek productie-GO.
