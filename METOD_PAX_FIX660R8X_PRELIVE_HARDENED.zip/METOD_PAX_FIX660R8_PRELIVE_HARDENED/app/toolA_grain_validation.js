(function(){
  window.__TOOLA_GRAIN_VALIDATION_BUILD='FIX660R8W_JOB_GLOBAL_GROUP_CODES';

  function num(v){
    const n = Number(v||0);
    return Number.isFinite(n) ? n : 0;
  }

  function noGrainMessage(){
    return 'Dit paneel heeft geen doorlopende houtnerf.';
  }

  function incompatibleWidthMessage(groupWidthMm, itemWidthMm){
    return `Kan niet: alleen panelen met exact dezelfde werkelijke breedte kunnen in één nerf-set. Deze set is ${num(groupWidthMm)} mm breed en dit paneel is ${num(itemWidthMm)} mm breed.`;
  }

  function getDropValidation(input){
    const cfg = input && typeof input === 'object' ? input : {};
    if(!cfg.isGrainCapable){
      return { ok:false, code:'not_grain_capable', message:noGrainMessage() };
    }
    const groupWidthMm = num(cfg.groupWidthMm != null ? cfg.groupWidthMm : (num(cfg.groupWidthCm)*10));
    const itemWidthMm = num(cfg.itemWidthMm != null ? cfg.itemWidthMm : (num(cfg.itemWidthCm)*10));
    if(groupWidthMm && Math.abs(groupWidthMm-itemWidthMm) > 0.001){
      return { ok:false, code:'width_mismatch', message:incompatibleWidthMessage(groupWidthMm, itemWidthMm) };
    }
    return { ok:true, code:'ok', message:'' };
  }

  function panelTooLargeMessage(input){
    const cfg = input && typeof input === 'object' ? input : {};
    const label = String(cfg.label || 'paneel');
    return `Paneel '${label}' past niet op de plaat (${Math.round(num(cfg.panelWidthMm))}×${Math.round(num(cfg.panelHeightMm))}mm > ${Math.round(num(cfg.usableWidthMm))}×${Math.round(num(cfg.usableHeightMm))}mm bruikbaar, marge ${num(cfg.marginMm)}mm).`;
  }

  function mixedWidthsMessage(groupId){
    return `Doorlopende nerf groep ${String(groupId||'')} bevat panelen met verschillende breedtes. Alleen panelen met dezelfde breedte kunnen een nerf-set vormen.`;
  }

  function totalTooLongMessage(groupId, totalHeightMm, usableHeightMm, marginMm){
    return `Doorlopende nerf groep ${String(groupId||'')} is te lang voor de plaathoogte (${Math.round(num(totalHeightMm))}mm > ${Math.round(num(usableHeightMm))}mm bruikbaar, marge ${num(marginMm)}mm).`;
  }

  function groupTooWideMessage(groupId, maxWidthMm, usableWidthMm, marginMm){
    return `Doorlopende nerf groep ${String(groupId||'')} is te breed voor de plaatbreedte (${Math.round(num(maxWidthMm))}mm > ${Math.round(num(usableWidthMm))}mm bruikbaar, marge ${num(marginMm)}mm).`;
  }

  function getGroupValidation(input){
    const cfg = input && typeof input === 'object' ? input : {};
    if(cfg.panelWidthMm != null && cfg.panelHeightMm != null){
      if(num(cfg.panelWidthMm) > num(cfg.usableWidthMm) + 0.01 || num(cfg.panelHeightMm) > num(cfg.usableHeightMm) + 0.01){
        return { ok:false, code:'panel_too_large', message:panelTooLargeMessage(cfg) };
      }
    }
    const uniqueWidths = Array.isArray(cfg.uniqueWidths) ? Array.from(new Set(cfg.uniqueWidths.map(num))) : [];
    if(uniqueWidths.length > 1){
      return { ok:false, code:'mixed_widths', message:mixedWidthsMessage(cfg.groupId) };
    }
    if(cfg.totalHeightMm != null && num(cfg.totalHeightMm) > num(cfg.usableHeightMm) + 0.01){
      return { ok:false, code:'too_long', message:totalTooLongMessage(cfg.groupId, cfg.totalHeightMm, cfg.usableHeightMm, cfg.marginMm) };
    }
    if(cfg.maxWidthMm != null && num(cfg.maxWidthMm) > num(cfg.usableWidthMm) + 0.01){
      return { ok:false, code:'too_wide', message:groupTooWideMessage(cfg.groupId, cfg.maxWidthMm, cfg.usableWidthMm, cfg.marginMm) };
    }
    return { ok:true, code:'ok', message:'' };
  }

  function getIncompleteSetAlert(){
    return {
      title: 'Nerf-set nog niet compleet',
      body: 'Sleep minimaal 2 panelen in een nerf-set.',
      details: 'Sleep nog een paneel met dezelfde breedte naar deze set.'
    };
  }

  function productionGroupKey(materialKey, groupId){
    return `${String(materialKey||'').trim()}\u001f${String(groupId||'').trim()}`;
  }

  function buildProductionGroupCodeMap(groups){
    const map=Object.create(null);
    let productionIndex=0;
    for(const group of (Array.isArray(groups)?groups:[])){
      if(!group || !Array.isArray(group.items) || !group.items.length) continue;
      const materialKey=String(group.materialKey||'').trim();
      const groupId=String(group.id||'').trim();
      if(!materialKey || !groupId) throw new Error('Een nerfgroep mist materiaal- of groepsidentiteit.');
      const key=productionGroupKey(materialKey,groupId);
      if(Object.prototype.hasOwnProperty.call(map,key)){
        throw new Error(`Dubbele nerfgroep ${groupId} voor hetzelfde materiaal.`);
      }
      productionIndex+=1;
      map[key]=`G${String(productionIndex).padStart(3,'0')}`;
    }
    return map;
  }

  function productionGroupCode(codeMap, materialKey, groupId){
    const code=codeMap&&codeMap[productionGroupKey(materialKey,groupId)];
    return String(code||'');
  }

  window.ToolAGrainValidation = {
    noGrainMessage,
    incompatibleWidthMessage,
    getDropValidation,
    panelTooLargeMessage,
    mixedWidthsMessage,
    totalTooLongMessage,
    groupTooWideMessage,
    getGroupValidation,
    getIncompleteSetAlert,
    productionGroupKey,
    buildProductionGroupCodeMap,
    productionGroupCode
  };
})();
