# FIX660R8 harde go-livegates

Beslisregel: productie-GO vereist een groene artifactgate én alle onderstaande live evidence. Een buildmarker, bronfragment of “bestand bestaat” is geen bewijs.

## 1. Artifact

- [ ] Externe ZIP-SHA-256 klopt.
- [ ] Intern `SHA256SUMS.txt` dekt exact alle bestanden en verifieert groen.
- [ ] `tools/final_preflight.py --verify-checksums` eindigt PASS.
- [ ] Artifact is onveranderlijk opgeslagen en de gebruikte hash staat in het change record.

## 2. Staging en deploy

- [ ] Exacte R7-baseline of bestaande immutable release is vóór migratie bevestigd.
- [ ] Voor/na state-inventaris bewijst behoud van jobs, requests, idempotency, catalogus, notifyconfig en logs.
- [ ] Service draait als `metod-pax`, zonder capabilities, met alle unit-hardening actief.
- [ ] Nginx-configtest, liveness en readiness zijn groen.
- [ ] Geforceerde fout vóór edge-reopen zet release/config terug zonder stateverlies.
- [ ] Chaosdeploy met testrequests toont geen gemengde assets of verloren/gedupliceerde request.

## 3. Productie en werkplaats

- [ ] Onafhankelijke CAM-parser accepteert de golden outputs.
- [ ] Hoekkast-ARC is op 0/90/180/270 visueel gecontroleerd.
- [ ] Drie asymmetrische nerfpanelen tonen positie 1 fysiek onderaan.
- [ ] Labels en StickerTool-identities horen exact bij de fysieke placements.
- [ ] Losse Admin-DXF en DXF-ZIP tonen per materiaal `klant__decor__001.dxf`,
      met een unieke oplopende plaatindex en zonder wijziging van DXF-inhoud.
- [ ] Werkplaats heeft een fysieke proefsnede afgetekend: contour, gaten, ARC, kanten, materiaal, dikte en nerf.
- [ ] Er is een benoemde eigenaar voor handmatige factuur/Odoo-opvolging en de twee-werkdagbelofte.

## 4. Security en privacy

- [ ] Publiek DNS en geldig TLS-certificaat zijn extern gecontroleerd; HTTP redirect en firewallbeleid zijn bevestigd.
- [ ] Admin-cookie is Secure/HttpOnly/SameSite en Basic auth werkt niet in productie.
- [ ] Iedere Admin heeft een eigen account, TOTP, juiste rol en bekende eigenaar.
- [ ] Logout/revoke, idle timeout en absolute timeout zijn op de echte omgeving getest.
- [ ] Traversal/double-encoding/cross-job-tokenmatrix geeft uitsluitend 400/403/404 zonder fileaccess.
- [ ] CSP, securityheaders en publieke DTO zijn met browser/networkinspectie gecontroleerd.
- [ ] Privacy-/retentie-eigenaar heeft actieve state, archive, logs en backupretentie geaccepteerd.

## 5. Catalogus en prijs

- [ ] Actieve live cataloguscount voldoet aan het change record (verwacht minimum standaard 597).
- [ ] Alle warnings/exclusions/reviewitems zijn door een materiaaleigenaar beoordeeld.
- [ ] `catalog_signoff.json` is door publicatie aangemaakt en de library-SHA klopt nog steeds.
- [ ] Steekproef van artikel, decor, dikte, plaatmaat en verkoopprijs incl. btw klopt met de bron-CSV.
- [ ] Testorderprijs klopt handmatig voor materiaal incl. btw plus overige kosten excl./incl. btw.
- [ ] Een wijziging van catalogus of pricing maakt oude signoff/readiness aantoonbaar ongeldig.

## 6. Operations en herstel

- [ ] Versleutelde backup staat aantoonbaar off-host bij de vastgelegde provider.
- [ ] Een schone restore is uitsluitend vanaf die off-host kopie uitgevoerd en functioneel getest.
- [ ] `restore_test_proof.json` verwijst naar de werkelijk herstelde backuphash en is niet ouder dan de afgesproken grens.
- [ ] Diskbytes, inodes, service, HTTP-errors, jobduur/-fouten, queue en backupstatus worden gemonitord.
- [ ] Externe synthetic calculate→price→submit controle en alerts bereiken de benoemde wachtdienst/eigenaar.
- [ ] Loadtest met login, SSE, grote geldige job en slow clients haalt vastgelegde CPU/RAM/latency/error-SLO.
- [ ] Loadtest met meerdere gelijktijdige klanten bevestigt FIFO-volgorde, maximaal één actieve optimizer op deze VPS, correcte wachtrijcapaciteit en geen polling-geïnduceerde vertraging.
- [ ] Restart en cancel in PREPARING, PROCESSING en FINALIZING eindigen deterministisch in DONE, FAILED of CANCELLED.
- [ ] Incident-, rollback-, restore- en contactrunbook is beschikbaar voor de uitvoerder.

## 7. Mobiele acceptatie

- [ ] Gemeld iPhone/Safari-model toont een niet-lege Grain Studio-preview bij open, rotate, drag, keyboard en close/reopen.
- [ ] Minstens één extra ondersteunde iOS/Safari-versie is getest.
- [ ] Video/screenshot, browser/networklog en zichtbare canvasmetingen zijn bij het change record gevoegd.
- [ ] Een geldige actuele nerfgroep kan optimaliseren met de previewdrawer open én ingeklapt; een onvolledige groep, ontbrekende paneelref of ongelijke werkelijke breedte blijft geblokkeerd.
- [ ] Twee materialen met ieder een geldige eerste nerfgroep optimaliseren samen zonder `spans multiple materials or thicknesses`; Admin/output behoudt twee afzonderlijke groepen.
- [ ] Na `Nieuwe configuratie starten` zijn alle klantvelden leeg, ook na Safari back/forward cache of formulierherstel; een gewone onbedoelde navigatie wist een lopende configuratie niet.
- [ ] `Jouw materialen` verwijdert een leeg materiaal direct en vraagt bij gekoppelde panelen zichtbaar om bevestiging; ieder pad muteert exact eenmaal.
- [ ] Eén tik op `Akkoord en aanvraag verzenden` maakt exact één Admin-request met naam, bedrijf, contact-, factuur- en bezorggegevens uit dezelfde berekening.
- [ ] De mobiele actie- en modalrails zijn effen, zonder vierkante gradientwaas of buitenliggende backdrop-schaduw.

## Productiebesluit

| Rol | Naam | Datum | Besluit/bewijslink |
|---|---|---|---|
| Productowner |  |  |  |
| Werkplaats/CAM |  |  |  |
| Materiaal/pricing |  |  |  |
| Security/privacy |  |  |  |
| Operations |  |  |  |

Zolang een verplicht vak open is, luidt het besluit: NO-GO voor publiek productie.
