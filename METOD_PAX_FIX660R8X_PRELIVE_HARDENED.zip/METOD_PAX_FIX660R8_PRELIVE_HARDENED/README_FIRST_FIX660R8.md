# METOD/PAX FIX660R8 — eerst lezen

R8X geeft iedere DXF-zaagplaat in Admin één herkenbare downloadnaam:
`klantnaam__decornaam__001.dxf`, `002.dxf`, enzovoort. Dezelfde naam wordt
gebruikt in de orderdetails, technische joblijst, losse download en ZIP-export.
De fysieke optimizerbestanden en hun verzegelde hashes worden niet hernoemd,
waardoor dit ook veilig werkt voor bestaande afgeronde jobs.

R8W maakt nerfgroepcodes uniek over de volledige job. Twee materialen mogen dus
ieder hun eigen eerste groep hebben zonder dat beide als dezelfde servergroep
`G001` worden samengevoegd. Een echte materiaal-/diktemenging binnen één groep
blijft geblokkeerd. `Nieuwe configuratie starten` wist bovendien alle zichtbare
én verborgen klantgegevens, ook wanneer Safari formulierwaarden probeert te
herstellen.

Build: `FIX660R8_PRELIVE_HARDENED`  
Status: pre-live releasecandidate voor gecontroleerde staging. Dit pakket is geen zelfstandig productie-GO.

## Wat R8 oplost

R8 vervangt de onveilige FIX660R7-baseline door een fail-closed productiepad voor paneelinput, DXF-geometrie, prijsberekening, jobidentiteit, finalisatie, downloads, cataloguspublicatie, deploy en backup/restore. De volledige koppeling met de bevindingen staat in `FIX660R8_REMEDIATION_MATRIX.md`.

Revisie R8N voorkomt dat een laat afgeronde template-loader Stap 2 onverwacht
terugzet naar Stap 1 en voegt op mobiel een uitschuifbaar materialenmandje toe
aan de onderbalk. De drawer hergebruikt exact dezelfde materiaalstate en
verwijderacties als de desktopkolom.

Revisie R8O maakt dat mandje de enige mobiele materiaalbalk. De definitieve
verzendknop blijft na een snelle optimalisatie klikbaar en verzendt met de vóór
optimalisatie vastgelegde klantgegevens. Ontbrekende gegevens of een ontbrekende
nerf-preview geven een zichtbaar herstelpad naar de juiste stap in plaats van
een knop die niets doet.

Revisie R8P maakt de mobiele onderbalk één compacte 50/50-rij en laat
`Jouw materialen` als één bottom sheet openen. Verwijderen wacht totdat die sheet
gesloten is voordat de gedeelde bevestiging verschijnt. De definitieve
verzendknop gebruikt één document-capture route naar één canonieke submitfunctie,
zodat een oude listener de tik niet meer kan onderscheppen en een aanvraag nooit
door twee concurrerende frontendpaden wordt verzonden.

Revisie R8Q herstelt de checkoutketen bij de bron: de pas later in de DOM
aangemaakte eindknop wordt bij de echte tik opgezocht, de vóór optimalisatie
vastgelegde volledige klantgegevens volgen één minimale serverroute en worden zo
nodig uit de finalized job hersteld voordat ze in Admin verschijnen. Het mobiele
prullenbakje gebruikt rechtstreeks de canonieke materiaalmutatie. Oude grijze
gradient-/shadowvlakken rond mobiele actiegebieden zijn verwijderd.

Revisie R8R maakt de oplossing onafhankelijk van historische handler-volgorde.
Eén document-capture eigenaar wordt vóór alle oude Tool A-scripts geregistreerd
en bezit de fysieke Safari-tik voor verzenden en mobiel verwijderen. Diezelfde
vroege laag legt alle zichtbare klantvelden vast vóór berekening of navigatie.
Rechthoekige mobiele actieachtergronden zijn transparant en beide footertegels
zijn schaduwloos.

Revisie R8S corrigeert de resterende live oorzaken nadat byte-exact was bewezen
dat R8R werkelijk draaide. Een oude prijswrapper mag de eindknop niet meer native
uitschakelen, klantvelden worden per veld uit live state en snapshot samengevoegd,
en de centrale verwijderbevestiging staat boven de mobiele materialen-drawer.
Footerrails hebben geen achtergrond-, blur-, pseudo- of schaduwlaag meer.

Revisie R8T is met een echte mobiele Chromium-doorloop tegen de publieke staging
gediagnosticeerd. Het prullenbakje gebruikt nu de daadwerkelijk beschikbare
canonieke verwijderfunctie; de oude enkel-materiaal-sheet opent niet meer over het
nieuwe mandje. Eén eindbrug rendert de vastgelegde klantgegevens in het prijsblok,
verwijdert de native `disabled`-status zodra prijs/panelen/e-mail aanwezig zijn en
bezit exact één verzendklik. Een losse resize-handler kan de wizard niet meer met
een `ReferenceError` verstoren.

Revisie R8M verwijdert specifiek de wachttijd vóór de eerste zichtbare
optimalisatieprogressie en na 100%: geen procent-voor-procent JavaScriptwachtrij,
geen redundante eindstatusfetch, geen herhaalde volledige hashcontrole tijdens
polling en veel minder afzonderlijke filesystembarrières. De nestingresultaten
zijn met vaste 200/250-panelenfingerprints beschermd. Meerdere klanten worden
begrensd FIFO toegelaten; op de kleine VPS blijft één optimizer tegelijk actief.

## Artifact controleren

Gebruik altijd de meegeleverde externe `.zip.sha256` naast de ZIP. Pak daarna uit in een lege map en controleer de interne manifesthashes:

```bash
sha256sum -c METOD_PAX_FIX660R8_PRELIVE_HARDENED.zip.sha256
unzip -tq METOD_PAX_FIX660R8_PRELIVE_HARDENED.zip
STAGE="$(mktemp -d /tmp/metod_fix660r8_XXXXXX)"
unzip -q METOD_PAX_FIX660R8_PRELIVE_HARDENED.zip -d "$STAGE"
cd "$STAGE/METOD_PAX_FIX660R8_PRELIVE_HARDENED"
sha256sum -c SHA256SUMS.txt
PYTHONDONTWRITEBYTECODE=1 python3 tools/final_preflight.py --release . --verify-checksums
```

De preflight voert echte optimizer-, lifecycle-, backup/restore- en regressieproeven uit. Een checksum- of testfout is een harde stop.

## Gecontroleerde staginginstallatie

De installer accepteert alleen de exacte FIX660R7-baseline of een reeds geverifieerde immutable release. Hij zet verkeer eerst in maintenance, migreert mutable state naar `/var/lib/metod-pax`, publiceert code via een atomische release-symlink en opent Nginx pas na runtimepreflight en healthchecks.

```bash
sudo -E bash INSTALL_FIX660R8_FROM_STAGE.sh
```

Staging is standaard HTTP op alleen `127.0.0.1:8790` en draagt bewust de header `X-METOD-Environment: staging`. Test op afstand via een SSH-tunnel, bijvoorbeeld `ssh -L 8790:127.0.0.1:8790 <server>`, en open lokaal `http://127.0.0.1:8790`. Een remote bind vereist expliciet `STAGING_BIND_ADDRESS` plus een geldig `STAGING_ALLOWED_CIDR`; staging is nooit een publiek liveprofiel.

## Productie

Productie vereist minimaal:

- een publiek DNS-domein en een passend TLS-certificaat/key die nog minstens zeven dagen geldig zijn;
- individuele Admin-accounts met PBKDF2-SHA256 (exact 260.000 iteraties), TOTP en de rol `admin`;
- de actieve CSV-catalogus met hashgebonden business-signoff;
- een versleutelde off-host backupbestemming en een recente echte restoreproef;
- afgetekende externe gates uit `GO_LIVE_GATES_FIX660R8.md`.

Voorbeeld van de vereiste expliciete productie-instellingen:

```bash
export METOD_DEPLOY_MODE=production
export METOD_DOMAIN=configurator.example.nl
export PUBLIC_ORIGIN=https://configurator.example.nl
export TLS_CERT_FILE=/etc/letsencrypt/live/configurator.example.nl/fullchain.pem
export TLS_KEY_FILE=/etc/letsencrypt/live/configurator.example.nl/privkey.pem
export OFFSITE_BACKUP_VERIFIED=1
export OFFSITE_BACKUP_PROVIDER='versleutelde-provider/locatie'
sudo -E bash INSTALL_FIX660R8_FROM_STAGE.sh
```

Ontbrekend bewijs laat de production runtimepreflight falen. Zet flags nooit op `1` zonder het bijbehorende bewijsbestand en een echte operationele controle.

## Backup herstellen

Herstel nooit over live state heen. De restoretool accepteert alleen een nieuwe, nog niet bestaande stagingmap:

```bash
python3 tools/restore_system_backup.py /pad/backup.zip --verify-only
python3 tools/restore_system_backup.py /pad/backup.zip \
  --target /var/lib/metod-pax-restore-test-20260812 \
  --proof /var/lib/metod-pax/system/restore_test_proof.json
```

Controleer de herstelde applicatiestate functioneel voordat een afzonderlijk, gepland herstel naar productie plaatsvindt.

## Rollback

Rollback zet alleen de immutable releasepointer en infrastructuurconfig terug. Externe live state wordt bewust nooit automatisch teruggedraaid. Dat voorkomt verlies van requests die na de switch zijn ontvangen. Zie `TECHNISCHE_OVERDRACHT_FIX660R8.md` voor het incidentpad.

## Nog verplicht vóór publiek live

De bron- en artifactgates zijn niet hetzelfde als een live-acceptatie. Echte iPhone/Safari-acceptatie, onafhankelijke CAM/CNC-validatie en fysieke proefsnede, load/chaostest, TLS-/systemd-/Nginx-inspectie, off-host herstelproef, monitoring/alerts en businesssignoff blijven expliciete productiegates.
