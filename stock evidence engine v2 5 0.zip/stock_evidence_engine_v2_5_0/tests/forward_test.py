"""Forward-tracking test for SEE v2.1.0.
Scan 1: ticker with an active validated signal on the last bar -> must be logged, returns empty.
Scan 2: same series + 10 extra bars -> ret_1/3/5/10 must be filled with exact, cost-adjusted values.
"""
import sys, os, tempfile
from pathlib import Path
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import engine as E

tmp=Path(tempfile.mkdtemp())
E.FORWARD_LOG=tmp/'forward_log.csv'

def mkdf(n):
    close=100*np.cumprod(1+np.full(n,0.01))          # deterministic +1%/day
    idx=pd.bdate_range('2026-01-05', periods=n)
    df=pd.DataFrame(index=idx)
    df['Close']=close
    df['Open']=df['Close'].shift(1).fillna(close[0])  # open = prior close
    df['High']=df['Close']*1.001; df['Low']=df['Open']*0.999
    df['Volume']=1_000_000
    return df

df1=mkdf(120); bench1=mkdf(120)
summary=[dict(ticker='SYN',theme='TEST',setup='relative_strength_leader',hold_days=5,
              signal_active_today=1,validated_edge=1,final_extreme=0,hybrid_watchlist=0,
              live_extreme=0,live_elite=0,ai_high=0,live_attention_score=40,
              validation_score=80,ai_final_score=0,excess_vs_drift=2.0,n_eff=15,
              hybrid_signal_score=0)]

rows,perf,_res,_open=E.update_forward_tracking(summary,{'SYN':df1},bench1)
assert len(rows)==1 and rows[0]['tier']=='VALIDATED_ACTIVE', rows
assert str(rows[0]['ret_5d']).strip()=='' , 'returns must be empty on day 0'

# scan 2: same signal already logged (dedupe) + 10 new bars -> fill
df2=mkdf(130); bench2=mkdf(130)
rows,perf,_res,_open=E.update_forward_tracking(summary,{'SYN':df2},bench2)
# dedupe check: signal_date of the logged row is bar 119; today's active signal (bar 129) is NEW -> 2 rows
assert len(rows)==2, f'expected 2 rows (old + new active), got {len(rows)}'
old=[r for r in rows if r['signal_date']==str(df1.index[-1].date())][0]
# exact expectation: entry=Open[i+1]=Close[i] ; exit=Close[i+h] -> (1.01^h -1)*100 - cost
for h in (1,3,5,10):
    exp=round((1.01**h-1)*100 - E.TRADE_COST_PCT,3)
    got=float(old[f'ret_{h}d'])
    assert abs(got-exp)<0.02, (h,got,exp)
    # benchmark identical series -> excess ~ cost difference only (bench has no cost)
    exq=float(old[f'exs_qqq_{h}d'])
    assert abs(exq-(-E.TRADE_COST_PCT))<0.02, (h,exq)
allrec=[p for p in perf if p['tier']=='ALL'][0]
assert allrec['n_5d']==1 and abs(float(allrec['avg_5d'])-round((1.01**5-1)*100-E.TRADE_COST_PCT,3))<0.02
print('FORWARD TRACKING: PASS (log, dedupe, exact fill, QQQ-excess, perf-agg)')

# ---- v2.3.1: plan-simulatie (SL moet echt tellen) ----
import tempfile as _tf
E.FORWARD_LOG=Path(_tf.mkdtemp())/'fl2.csv'
n=130
cl=np.full(n,100.0)
cl[121]=88.0   # dag na entry: crash door SL
cl[122:]=120.0 # daarna vol herstel boven TP
idx2=pd.bdate_range('2026-01-05',periods=n)
d2=pd.DataFrame({'Close':cl},index=idx2)
d2['Open']=d2['Close'].shift(1).fillna(100.0)
d2['High']=d2[['Open','Close']].max(axis=1); d2['Low']=d2[['Open','Close']].min(axis=1); d2['Volume']=1e6
s2=[dict(ticker='SLX',theme='T',setup='x',hold_days=10,signal_active_today=1,validated_edge=1,final_extreme=0,
        hybrid_watchlist=0,live_extreme=0,live_elite=0,ai_high=0,live_attention_score=40,validation_score=80,
        ai_final_score=0,excess_vs_drift=2,n_eff=15,hybrid_signal_score=0,avg_nonoverlap=8.0,
        winrate_nonoverlap=60,ci90_low=1,ci90_high=15,price=100.0)]
rows,perf,_res,_open=E.update_forward_tracking(s2,{'SLX':d2.iloc[:121]},None)  # log op bar 120
rows,perf,_res,_open=E.update_forward_tracking(s2,{'SLX':d2}, None)            # vul in met volledige reeks
row=[r for r in rows if r['signal_date']==str(d2.index[120].date())][0]
assert str(row['plan_exit']).startswith('SL'), row['plan_exit']
assert float(row['plan_ret'])<0, row['plan_ret']
# kale 10d-meting is juist dik positief (herstel) -> bewijst het verschil setup vs plan
assert float(row['ret_5d'])>0
print('PLAN SIM: PASS (SL geraakt telt als verlies; kale meting apart)')

# ---- v2.5.0: episode-regel ----
E.FORWARD_LOG=Path(_tf.mkdtemp())/'fl3.csv'
d3=mkdf(126)
s3=[dict(ticker='EP1',theme='T',setup='x',hold_days=10,signal_active_today=1,validated_edge=1,final_extreme=0,
        hybrid_watchlist=0,live_extreme=0,live_elite=0,ai_high=0,live_attention_score=40,validation_score=80,
        ai_final_score=0,excess_vs_drift=2,n_eff=15,hybrid_signal_score=0,avg_nonoverlap=8.0,
        winrate_nonoverlap=60,ci90_low=1,ci90_high=15,price=100.0)]
r1,_,_,op1=E.update_forward_tracking(s3,{'EP1':d3.iloc[:120]},None)   # dag 0: episode opent
r2,_,_,op2=E.update_forward_tracking(s3,{'EP1':d3.iloc[:121]},None)   # dag 1: zelfde signaal
r3,_,_,_  =E.update_forward_tracking(s3,{'EP1':d3.iloc[:122]},None)   # dag 2: zelfde signaal
assert len(r1)==1 and len(r2)==1 and len(r3)==1, (len(r1),len(r2),len(r3))
assert 'EP1' in op2, 'open episode moet alerts onderdrukken'
print('EPISODE: PASS (1 trade = 1 entry, herhaalsignalen geblokkeerd, alert-suppressie actief)')
