BEE Live Forecast v4.1.12
- Hardwired ntfy topic by user request: stijn-btc-alerts-2026-secret
- One-line mobile workflow sends ntfy tests, force-notify, and exports to /home/ubuntu/bee_latest_export.zip
