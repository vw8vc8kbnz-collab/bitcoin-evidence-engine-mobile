#!/usr/bin/env python3
"""Bitcoin Evidence Engine live paper forecast
v4.1.13: server-safe live logging + fixed export bridge.

Important: this version keeps the mobile live infrastructure stable and adds the
persistent paper logging layer requested for live validation:
- bee_status.json: latest rich run, atomic overwrite
- bee_history.csv: compact timeline, append + daily trim to 8760 rows
- bee_signals.csv: real paper signals only, append-only track record
- bee_evaluate.py companion: fills 30d outcomes later

The actual live decision is explicitly labelled as a research-core bridge. Force-test
notifications are marked TEST and are never written to bee_signals.csv.
"""
import argparse, csv, json, os, sys, time, zipfile, platform, math, shutil, tempfile, logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
from datetime import datetime, timezone, timedelta
from typing import Any, Dict, List, Optional

VERSION = "v4.1.13_live_logging_status_research_core_bridge"
DEFAULT_TOPIC = "stijn-btc-alerts-2026-secret"
ROOT = Path(__file__).resolve().parent
STATE_DIR = ROOT / "state"
EXPORT_DIR = ROOT / "debug_exports"
CONFIG_PATH = ROOT / "bee_live_config.json"
HOME_EXPORT = Path("/home/ubuntu/bee_latest_export.zip")
HOME_EXPORT_COMPAT = Path("/home/ubuntu/bee_live_debug_export.zip")
STATUS_PATH = ROOT / "bee_status.json"
HISTORY_PATH = ROOT / "bee_history.csv"
SIGNALS_PATH = ROOT / "bee_signals.csv"
LOOP_LOG_PATH = ROOT / "bee_live_loop.log"
MAX_HISTORY_ROWS = 8760
DISK_GUARD_MIN_BYTES = 500 * 1024 * 1024

HISTORY_FIELDS = [
    "timestamp_utc","candle_dt","price","fear_greed","drawdown_from_ath","return_4","return_24","rsi_14","regime",
    "specialist","prob","cycle_prob_raw","tier","decision","notify","reason"
]
SIGNAL_FIELDS = [
    "signal_ts","candle_dt","specialist","decision","tier","prob","entry_price","take_profit","stop_loss","horizon",
    "fear_greed","regime","reason","outcome_price_30d","outcome_pct_30d","outcome_filled_at"
]

try:
    import requests
except Exception:
    requests = None

LOGGER = logging.getLogger("bee_live_forecast")
LOGGER.setLevel(logging.INFO)
ROOT.mkdir(parents=True, exist_ok=True)
_handler = RotatingFileHandler(LOOP_LOG_PATH, maxBytes=1_000_000, backupCount=3, encoding="utf-8")
_handler.setFormatter(logging.Formatter("%(asctime)sZ %(levelname)s %(message)s"))
LOGGER.addHandler(_handler)


def now_iso():
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace('+00:00','Z')


def atomic_write(path: Path, data_str: str):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(data_str)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    except Exception:
        try: os.remove(tmp)
        except OSError: pass
        raise


def load_json(path: Path, default: Any):
    try:
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
    except Exception as e:
        LOGGER.warning("load_json failed path=%s err=%s", path, e)
    return default


def save_json(path: Path, obj: Any):
    atomic_write(path, json.dumps(obj, indent=2, sort_keys=True, ensure_ascii=False))


def load_config():
    cfg = load_json(CONFIG_PATH, {})
    if not cfg:
        cfg = {"ntfy_topic": DEFAULT_TOPIC, "paper_mode": True, "active_models": ["cycle_reversal","elite_reversal","reversal"], "min_notify_tier": "push", "check_interval_hours": 24}
        save_json(CONFIG_PATH, cfg)
    topic = str(cfg.get("ntfy_topic") or "").strip()
    if not topic or "PASTE_PRIVATE" in topic or topic == "your-secret-topic":
        cfg["ntfy_topic"] = DEFAULT_TOPIC
        save_json(CONFIG_PATH, cfg)
    return cfg


def validate_topic(cfg):
    topic = str(cfg.get("ntfy_topic") or "").strip()
    if not topic or "PASTE_PRIVATE" in topic or topic == "your-secret-topic":
        raise RuntimeError("ntfy_topic is missing/placeholder")
    return topic


def http_get_json(url, timeout=15, headers=None):
    if requests is None:
        raise RuntimeError("requests not installed")
    r = requests.get(url, timeout=timeout, headers=headers or {})
    r.raise_for_status()
    return r.json()


def fetch_binance_candles(interval="1h", limit=999):
    url = f"https://api.binance.com/api/v3/klines?symbol=BTCUSDT&interval={interval}&limit={limit}"
    rows = http_get_json(url)
    out = []
    for k in rows:
        out.append({
            "dt": datetime.fromtimestamp(int(k[0])/1000, timezone.utc).replace(microsecond=0).isoformat().replace('+00:00','Z'),
            "open": float(k[1]), "high": float(k[2]), "low": float(k[3]), "close": float(k[4]), "volume": float(k[5]),
            "close_time": int(k[6])
        })
    return out


def fetch_fear_greed():
    data = http_get_json("https://api.alternative.me/fng/?limit=2")
    item = data.get("data", [{}])[0]
    return {"value": float(item.get("value")), "label": item.get("value_classification"), "cached": False, "timestamp": item.get("timestamp")}


def fetch_funding():
    try:
        data = http_get_json("https://fapi.binance.com/fapi/v1/fundingRate?symbol=BTCUSDT&limit=1")
        if data:
            return {"funding_rate": float(data[-1].get("fundingRate")), "source": "binance_futures"}
    except Exception as e:
        return {"funding_rate": None, "source": "missing", "error": str(e)}
    return {"funding_rate": None, "source": "missing"}


def fetch_coinbase_premium(binance_price: float):
    try:
        data = http_get_json("https://api.exchange.coinbase.com/products/BTC-USD/ticker", headers={"User-Agent":"BEE-live-forecast"})
        cb = float(data.get("price"))
        return {"coinbase_price": cb, "coinbase_premium_pct": (cb / binance_price - 1.0) * 100.0, "source": "coinbase_ticker", "missing": False}
    except Exception as e:
        return {"coinbase_price": None, "coinbase_premium_pct": None, "source": "missing", "missing": True, "error": str(e)}


def fetch_macro_spy_weekly():
    # Keep current minimal bridge safe. Reversal phase does not depend on macro.
    return {"source": "disabled_for_reversal_phase", "safe": True, "spx_ret_1w_calc": None, "missing": True}


def sma(vals, n):
    if len(vals) < n: return None
    return sum(vals[-n:]) / n


def rsi(vals, n=14):
    if len(vals) < n+1: return None
    gains=[]; losses=[]
    for a,b in zip(vals[-n-1:-1], vals[-n:]):
        d=b-a
        gains.append(max(d,0)); losses.append(max(-d,0))
    ag=sum(gains)/n; al=sum(losses)/n
    if al == 0: return 100.0
    return 100 - 100/(1 + ag/al)


def pct(a,b):
    if b in (0,None) or a is None: return None
    return (a/b - 1.0) * 100.0


def classify_regime(fg, dd, rsi14, ret24):
    if fg is None: return "unknown"
    if fg < 18 and dd is not None and dd < -35 and (rsi14 or 100) < 42 and (ret24 or 0) < -1.5:
        return "capitulation"
    if fg < 30 and dd is not None and dd < -30 and (ret24 or 0) >= -1.5:
        return "fear_recovery"
    if fg < 35: return "fear"
    if fg > 75: return "euphoria"
    return "neutral"


def build_features(candles, fg, funding, premium, macro=None):
    closes=[c["close"] for c in candles]
    highs=[c["high"] for c in candles]
    close=closes[-1]
    ath=max(highs) if highs else close
    ma50=sma(closes,50); ma200=sma(closes,200); rsi14=rsi(closes,14)
    ret1=pct(closes[-1],closes[-2]) if len(closes)>1 else None
    ret4=pct(closes[-1],closes[-5]) if len(closes)>5 else None
    ret24=pct(closes[-1],closes[-25]) if len(closes)>25 else None
    ret7d=pct(closes[-1],closes[-169]) if len(closes)>169 else None
    dd=pct(close, ath)
    regime=classify_regime(fg.get("value"), dd, rsi14, ret24)
    return {"dt": candles[-1]["dt"], "close": close, "ma_50": ma50, "ma_200": ma200, "rsi_14": rsi14, "return_1": ret1, "return_4": ret4, "return_24": ret24, "past_ret_7d": ret7d, "drawdown_from_ath": dd, "fear_greed": fg.get("value"), "fear_greed_label": fg.get("label"), "funding_rate": funding.get("funding_rate"), "coinbase_premium_pct": premium.get("coinbase_premium_pct"), "regime": regime, "macro_spx_ret_1w": (macro or {}).get("spx_ret_1w_calc")}


def research_core_cycle_reversal_bridge(row: Dict[str, Any]) -> Dict[str, Any]:
    """Research-core bridge for live phase.

    This intentionally uses the previously validated conceptual CycleReversal gating:
    fear_greed < 25 AND positive 4h momentum. It avoids the old ad-hoc score threshold.
    A proper full core import/golden-row equivalence remains visible via diagnostics.
    """
    fg = row.get("fear_greed")
    mom4 = row.get("return_4")
    dd = row.get("drawdown_from_ath")
    r = row.get("rsi_14")
    applies = (fg is not None and fg < 25 and mom4 is not None and mom4 > 0)
    # Probability is transparent and never artificially lifted. Conservative bridge.
    prob = None
    if fg is not None and dd is not None and mom4 is not None:
        fg_component = max(0.0, min(1.0, (25 - fg) / 25.0)) * 0.30
        dd_component = max(0.0, min(1.0, (abs(dd) - 15.0) / 50.0)) * 0.30
        mom_component = max(0.0, min(1.0, mom4 / 3.0)) * 0.20
        rsi_component = max(0.0, min(1.0, (55.0 - (r or 55.0)) / 35.0)) * 0.10
        regime_component = 0.10 if row.get("regime") in ("fear", "fear_recovery", "capitulation") else 0.0
        prob = max(0.0, min(0.95, fg_component + dd_component + mom_component + rsi_component + regime_component))
    reason = []
    if not (fg is not None and fg < 25): reason.append(f"fear_greed_not_extreme={fg}")
    if not (mom4 is not None and mom4 > 0): reason.append(f"mom4_not_positive={mom4}")
    if applies: reason.append("cycle_reversal_core_gate: fear_greed<25 AND return_4>0")
    return {"applies": applies, "prob": prob, "reason": "; ".join(reason) or "OK"}


def decide(row, force=False):
    # No force probability manipulation. Test messages are marked test and never treated as genuine signals.
    cycle = research_core_cycle_reversal_bridge(row)
    action="NO_TRADE"; specialist="none"; tier="none"; prob=None; horizon=None; reasons=[]
    if force:
        action="LONG"; specialist="cycle_reversal"; tier="TEST_ONLY"; prob=cycle.get("prob"); horizon="30d"
        reasons.append("TEST_ONLY forced ntfy pipeline verification — not a real signal and not written to bee_signals.csv")
    elif cycle["applies"]:
        action="LONG"; specialist="cycle_reversal"; tier="push"; prob=cycle.get("prob"); horizon="30d"
        reasons.append("CycleReversal live bridge fired: fear_greed<25 and 4h momentum positive")
    else:
        reasons.append("NO_TRADE " + cycle["reason"])
    entry=row.get("close") or 0
    # These are paper monitoring levels. Exit policy remains wide trailing; not automatic orders.
    tp=entry*1.18 if entry else None
    sl=entry*0.90 if entry else None
    return {"action": action, "specialist": specialist, "tier": tier, "prob": prob, "horizon": horizon, "price": entry, "entry": entry, "take_profit": tp, "stop_loss": sl, "exit_policy": "wide_trailing_paper", "historical_winrate_model_timeframe": "CycleReversal 30d OOS approx 61% / historical approx 65%", "reasons": reasons, "diagnostics": {"cycle_prob_raw": cycle.get("prob"), "cycle_applies": cycle.get("applies"), "cycle_reason": cycle.get("reason"), "core_bridge": "cycle_reversal_v4_0_gate_bridge_no_proxy_threshold"}}


def send_ntfy(cfg, title, message, priority="default", tags="chart_with_upwards_trend"):
    topic = validate_topic(cfg)
    if requests is None:
        raise RuntimeError("requests not installed")
    url=f"https://ntfy.sh/{topic}"
    r=requests.post(url, data=message.encode("utf-8"), headers={"Title": title, "Priority": priority, "Tags": tags}, timeout=15)
    r.raise_for_status()
    return {"ok": True, "status_code": r.status_code, "topic": topic}


def format_money(x):
    return "n/a" if x is None else f"${x:,.2f}"


def format_trade(decision, row, test=False):
    prefix = "TEST — GEEN ECHT SIGNAAL" if test else "LIVE PAPER SIGNAL"
    return f"""BEE PAPER TRADE {prefix}\nModel: {decision['specialist']}\nAction: {decision['action']}\nTier: {decision['tier']}\nTimeframe: {decision.get('horizon')}\nEntry: {format_money(decision.get('entry'))}\nTake profit / monitor target: {format_money(decision.get('take_profit'))}\nStoploss / initial invalidation: {format_money(decision.get('stop_loss'))}\nExit: {decision.get('exit_policy')}\nModel winrate: {decision.get('historical_winrate_model_timeframe')}\nProbability shown: {decision.get('prob')}\nRaw probability: {decision.get('diagnostics',{}).get('cycle_prob_raw')}\nFear & Greed: {row.get('fear_greed')} ({row.get('fear_greed_label')})\nRegime: {row.get('regime')}\nReason: {'; '.join(decision.get('reasons', []))}\n\nPAPER ONLY — geen automatische trade."""


def fetch_all():
    c1h=fetch_binance_candles("1h",999)
    c1d=fetch_binance_candles("1d",999)
    fg=fetch_fear_greed()
    funding=fetch_funding()
    premium=fetch_coinbase_premium(c1h[-1]["close"])
    macro=fetch_macro_spy_weekly()
    features=build_features(c1h, fg, funding, premium, macro)
    return {"candles_1h": c1h, "candles_1d": c1d, "fear_greed": fg, "funding": funding, "coinbase": premium, "macro": macro, "features": features}


def disk_guard():
    usage = shutil.disk_usage(str(ROOT))
    ok = usage.free >= DISK_GUARD_MIN_BYTES
    return {"ok": ok, "free_bytes": usage.free, "total_bytes": usage.total, "threshold_bytes": DISK_GUARD_MIN_BYTES}


def ensure_csv_header(path: Path, fields: List[str]):
    if not path.exists() or path.stat().st_size == 0:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("w", newline="", encoding="utf-8") as f:
            csv.DictWriter(f, fieldnames=fields).writeheader()


def append_csv_row(path: Path, fields: List[str], row: Dict[str, Any]):
    ensure_csv_header(path, fields)
    with path.open("a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writerow({k: row.get(k, "") for k in fields})
        f.flush(); os.fsync(f.fileno())


def trim_history_if_needed():
    state = load_json(STATE_DIR / "maintenance_state.json", {})
    today = datetime.now(timezone.utc).date().isoformat()
    if state.get("history_trim_date") == today:
        return False
    if not HISTORY_PATH.exists():
        state["history_trim_date"] = today; save_json(STATE_DIR / "maintenance_state.json", state); return False
    lines = HISTORY_PATH.read_text(encoding="utf-8").splitlines()
    if len(lines) > MAX_HISTORY_ROWS + 1:
        header, rows = lines[0], lines[1:]
        keep = rows[-MAX_HISTORY_ROWS:]
        atomic_write(HISTORY_PATH, "\n".join([header] + keep) + "\n")
    state["history_trim_date"] = today
    save_json(STATE_DIR / "maintenance_state.json", state)
    return True


def record_run(data: Dict[str,Any], decision: Dict[str,Any], notify: bool, notify_result: Any, force: bool):
    row = data["features"]
    ts = now_iso()
    reason = "; ".join(decision.get("reasons", []))
    status = {"version": VERSION, "timestamp_utc": ts, "force_test": force, "features": row, "decision": decision, "notify": notify, "notify_result": notify_result, "sources": {"fear_greed": data.get("fear_greed"), "funding": data.get("funding"), "coinbase": data.get("coinbase"), "macro": data.get("macro")}, "disk": disk_guard()}
    save_json(STATUS_PATH, status)
    save_json(STATE_DIR / "last_status.json", status)
    append_csv_row(HISTORY_PATH, HISTORY_FIELDS, {
        "timestamp_utc": ts,
        "candle_dt": row.get("dt"),
        "price": row.get("close"),
        "fear_greed": row.get("fear_greed"),
        "drawdown_from_ath": row.get("drawdown_from_ath"),
        "return_4": row.get("return_4"),
        "return_24": row.get("return_24"),
        "rsi_14": row.get("rsi_14"),
        "regime": row.get("regime"),
        "specialist": decision.get("specialist"),
        "prob": decision.get("prob"),
        "cycle_prob_raw": decision.get("diagnostics", {}).get("cycle_prob_raw"),
        "tier": decision.get("tier"),
        "decision": decision.get("action"),
        "notify": bool(notify),
        "reason": reason[:500]
    })
    if notify and not force and decision.get("action") in ("LONG", "SHORT"):
        append_csv_row(SIGNALS_PATH, SIGNAL_FIELDS, {
            "signal_ts": ts,
            "candle_dt": row.get("dt"),
            "specialist": decision.get("specialist"),
            "decision": decision.get("action"),
            "tier": decision.get("tier"),
            "prob": decision.get("prob"),
            "entry_price": decision.get("entry"),
            "take_profit": decision.get("take_profit"),
            "stop_loss": decision.get("stop_loss"),
            "horizon": decision.get("horizon"),
            "fear_greed": row.get("fear_greed"),
            "regime": row.get("regime"),
            "reason": reason[:500],
            "outcome_price_30d": "", "outcome_pct_30d": "", "outcome_filled_at": ""
        })
    trim_history_if_needed()


def run_once(force_notify=False, notify=True):
    cfg=load_config(); data=fetch_all(); row=data["features"]; decision=decide(row, force=force_notify)
    state=load_json(STATE_DIR/"live_state.json", {})
    state["last_run_at"]=now_iso(); state["last_decision"]=decision; state["last_features"]=row; state["version"]=VERSION
    notified=False; notify_result=None
    if notify and (force_notify or decision.get("action") != "NO_TRADE"):
        msg=format_trade(decision,row,test=force_notify)
        notify_result=send_ntfy(cfg, "BEE PAPER TRADE TEST" if force_notify else "BEE PAPER SIGNAL", msg, priority="high" if force_notify or decision.get("tier") in ("elite","push") else "default")
        notified=True
        state.setdefault("last_notified", {})[decision.get("specialist") or "test"]={"ts":now_iso(),"decision":decision,"notify_result":notify_result,"force_test":force_notify}
    save_json(STATE_DIR/"live_state.json", state)
    save_json(STATE_DIR/"last_fetch_snapshot.json", data)
    record_run(data, decision, notified, notify_result, force_notify)
    out={"version": VERSION, "decision": decision, "features": row, "notified": notified, "notify_result": notify_result, "status_file": str(STATUS_PATH), "history_file": str(HISTORY_PATH), "signals_file": str(SIGNALS_PATH)}
    print(json.dumps(out, indent=2, sort_keys=True))
    return {"data": data, "decision": decision, "notified": notified, "notify_result": notify_result}


def inspect_live_data():
    data=fetch_all(); row=data["features"]; decision=decide(row)
    gaps=0; prev=None
    for c in data["candles_1h"]:
        ts=datetime.fromisoformat(c["dt"].replace("Z","+00:00"))
        if prev and (ts-prev).total_seconds() != 3600: gaps+=1
        prev=ts
    out={"ok": True, "version": VERSION, "btc_1h": {"count": len(data["candles_1h"]), "last": data["candles_1h"][-1], "gaps": gaps}, "fear_greed": data["fear_greed"], "funding": data["funding"], "coinbase": data["coinbase"], "macro": data["macro"], "features": row, "raw_decision": decision, "log_files": {"status": str(STATUS_PATH), "history": str(HISTORY_PATH), "signals": str(SIGNALS_PATH)}}
    print(json.dumps(out, indent=2, sort_keys=True))
    save_json(STATE_DIR / "last_inspect.json", out)
    return out


def test_ntfy(trade=False):
    cfg=load_config(); validate_topic(cfg)
    if trade:
        data=fetch_all(); row=data["features"]; decision=decide(row, force=True)
        msg=format_trade(decision,row,test=True)
        res=send_ntfy(cfg,"BEE PAPER TRADE TEST — TEST ONLY", msg, priority="high", tags="warning,chart_with_upwards_trend")
    else:
        res=send_ntfy(cfg,"BEE ntfy test", f"BEE ntfy werkt. {now_iso()} version={VERSION}", priority="default", tags="white_check_mark")
    print(json.dumps({"ok": True, "result": res}, indent=2))
    return res


def export_debug():
    cfg=load_config()
    payload={"version": VERSION, "created_at": now_iso(), "platform": platform.platform(), "python": sys.version, "config_redacted": {**cfg, "ntfy_topic": "***REDACTED***"}}
    try: payload["inspect"] = inspect_live_data()
    except Exception as e: payload["inspect_error"] = str(e)
    state=load_json(STATE_DIR/"live_state.json", {})
    # Remove old home exports and write fixed names directly.
    for old in Path("/home/ubuntu").glob("bee_live_debug_export*.zip"):
        try: old.unlink()
        except Exception: pass
    for old in Path("/home/ubuntu").glob("bee_latest_export.zip"):
        try: old.unlink()
        except Exception: pass
    EXPORT_DIR.mkdir(parents=True, exist_ok=True)
    internal = EXPORT_DIR / "bee_live_debug_export_latest_internal.zip"
    for zpath in (internal, HOME_EXPORT, HOME_EXPORT_COMPAT):
        zpath.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(zpath,"w",zipfile.ZIP_DEFLATED) as z:
            z.writestr("manifest.json", json.dumps(payload, indent=2, sort_keys=True))
            z.writestr("state/live_state.json", json.dumps(state, indent=2, sort_keys=True))
            for p in [STATUS_PATH, HISTORY_PATH, SIGNALS_PATH, LOOP_LOG_PATH, CONFIG_PATH]:
                if p.exists():
                    arc = p.name if p != CONFIG_PATH else "config/bee_live_config_redacted_NOTE_TOPIC_REMOVED.json"
                    if p == CONFIG_PATH:
                        cfg_red = load_json(CONFIG_PATH,{})
                        cfg_red["ntfy_topic"] = "***REDACTED***"
                        z.writestr(arc, json.dumps(cfg_red, indent=2, sort_keys=True))
                    else:
                        z.write(p, arc)
            for p in STATE_DIR.glob("*.json"):
                z.write(p, f"state/{p.name}")
            z.write(Path(__file__), "code/bee_live_forecast_v4_1_paper.py")
    print(f"EXPORT_READY={HOME_EXPORT}")
    print(f"EXPORT_COMPAT={HOME_EXPORT_COMPAT}")
    return HOME_EXPORT


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--test-fetch", action="store_true")
    ap.add_argument("--inspect-live-data", action="store_true")
    ap.add_argument("--test-ntfy", action="store_true")
    ap.add_argument("--test-trade-ntfy", action="store_true")
    ap.add_argument("--force-notify", action="store_true")
    ap.add_argument("--once", action="store_true")
    ap.add_argument("--loop", action="store_true")
    ap.add_argument("--daemon", action="store_true")
    ap.add_argument("--export-debug", action="store_true")
    ap.add_argument("--show-log-files", action="store_true")
    args=ap.parse_args()
    if args.show_log_files:
        print(json.dumps({"status": str(STATUS_PATH), "history": str(HISTORY_PATH), "signals": str(SIGNALS_PATH), "loop_log": str(LOOP_LOG_PATH), "export": str(HOME_EXPORT)}, indent=2)); return
    if args.test_fetch or args.inspect_live_data: inspect_live_data(); return
    if args.test_ntfy: test_ntfy(False); return
    if args.test_trade_ntfy: test_ntfy(True); return
    if args.once: run_once(False, True); return
    if args.force_notify: run_once(True, True); return
    if args.export_debug: export_debug(); return
    if args.loop or args.daemon:
        while True:
            try:
                dg = disk_guard()
                if not dg["ok"]:
                    LOGGER.error("DISK_GUARD_LOW_SPACE %s", dg)
                run_once(False, True)
            except Exception as e:
                LOGGER.exception("LOOP_ERROR: %s", e)
                print(f"LOOP_ERROR: {e}", file=sys.stderr)
            time.sleep(int(load_config().get("check_interval_hours",24))*3600)
        return
    ap.print_help()
if __name__ == "__main__": main()
