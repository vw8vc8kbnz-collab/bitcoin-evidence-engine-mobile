#!/usr/bin/env python3
import csv, json, os, sys
from pathlib import Path
from datetime import datetime, timezone, timedelta
try:
    import requests
except Exception:
    requests = None
ROOT = Path(__file__).resolve().parent
SIGNALS = ROOT / "bee_signals.csv"
FIELDS = ["signal_ts","candle_dt","specialist","decision","tier","prob","entry_price","take_profit","stop_loss","horizon","fear_greed","regime","reason","outcome_price_30d","outcome_pct_30d","outcome_filled_at"]

def now_iso(): return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace('+00:00','Z')
def fetch_price():
    if requests is None: raise RuntimeError("requests not installed")
    r=requests.get("https://api.binance.com/api/v3/ticker/price?symbol=BTCUSDT", timeout=15); r.raise_for_status()
    return float(r.json()["price"])
def parse_ts(s): return datetime.fromisoformat(s.replace("Z","+00:00"))
def main():
    if not SIGNALS.exists():
        print(json.dumps({"ok": True, "message":"no bee_signals.csv yet", "evaluated":0}, indent=2)); return
    rows=list(csv.DictReader(SIGNALS.open(newline='', encoding='utf-8')))
    price=fetch_price(); changed=0
    for row in rows:
        if row.get("outcome_filled_at"): continue
        horizon=row.get("horizon") or "30d"
        days=30 if "30" in horizon else 30
        try: age=datetime.now(timezone.utc)-parse_ts(row["signal_ts"])
        except Exception: continue
        if age < timedelta(days=days): continue
        entry=float(row.get("entry_price") or 0)
        if not entry: continue
        pct=(price/entry-1.0)*100.0
        row["outcome_price_30d"]=f"{price:.2f}"; row["outcome_pct_30d"]=f"{pct:.4f}"; row["outcome_filled_at"]=now_iso(); changed+=1
    if changed:
        tmp=SIGNALS.with_suffix('.csv.tmp')
        with tmp.open('w', newline='', encoding='utf-8') as f:
            w=csv.DictWriter(f, fieldnames=FIELDS); w.writeheader(); w.writerows(rows)
        os.replace(tmp, SIGNALS)
    evaluated=[r for r in rows if r.get("outcome_filled_at")]
    wins=[float(r["outcome_pct_30d"])>0 for r in evaluated if r.get("outcome_pct_30d")]
    print(json.dumps({"ok": True, "price_now": price, "newly_evaluated": changed, "total_evaluated": len(evaluated), "live_winrate": (sum(wins)/len(wins)*100 if wins else None), "backtest_reference":"CycleReversal 30d OOS approx 61%"}, indent=2))
if __name__ == "__main__": main()
