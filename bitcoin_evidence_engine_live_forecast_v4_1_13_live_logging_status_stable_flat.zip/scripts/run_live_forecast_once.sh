#!/usr/bin/env bash
set -euo pipefail
ROOT="/home/ubuntu/bitcoin-engine-deploy/current"
cd "$ROOT/live_forecast"
. "$ROOT/.venv/bin/activate"
python bee_live_forecast_v4_1_paper.py --once
