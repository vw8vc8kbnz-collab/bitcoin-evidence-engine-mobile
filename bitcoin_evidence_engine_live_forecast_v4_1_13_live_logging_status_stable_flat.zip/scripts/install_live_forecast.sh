#!/usr/bin/env bash
set -euo pipefail
ROOT="/home/ubuntu/bitcoin-engine-deploy/current"
cd "$ROOT"
python3 -m venv .venv
. .venv/bin/activate
pip install -r live_forecast/requirements.txt
# Force correct topic for this user, by explicit request
python - <<'PY'
import json
from pathlib import Path
p=Path('/home/ubuntu/bitcoin-engine-deploy/current/live_forecast/bee_live_config.json')
cfg=json.loads(p.read_text()) if p.exists() else {}
cfg['ntfy_topic']='stijn-btc-alerts-2026-secret'
cfg['paper_mode']=True
cfg.setdefault('active_models',['cycle_reversal','elite_reversal','reversal'])
cfg.setdefault('min_notify_tier','push')
p.write_text(json.dumps(cfg, indent=2, sort_keys=True))
PY
echo "✅ Live forecast install OK. Topic set to stijn-btc-alerts-2026-secret"
