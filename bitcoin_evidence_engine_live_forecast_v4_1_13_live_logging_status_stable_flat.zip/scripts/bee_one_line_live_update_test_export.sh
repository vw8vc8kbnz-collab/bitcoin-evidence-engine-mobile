#!/usr/bin/env bash
set -euo pipefail
BASE="/home/ubuntu/bitcoin-engine-deploy/current"
cd "$BASE"
echo "[1/8] Installing live forecast..."
chmod +x scripts/install_live_forecast.sh
./scripts/install_live_forecast.sh
cd "$BASE/live_forecast"
source ../.venv/bin/activate
echo "[2/8] Active version/options..."
python bee_live_forecast_v4_1_paper.py --show-log-files
echo "[3/8] Testing live fetch / data inspection..."
python bee_live_forecast_v4_1_paper.py --inspect-live-data >/tmp/bee_inspect_latest.txt
tail -40 /tmp/bee_inspect_latest.txt || true
echo "[4/8] Sending basic ntfy test..."
python bee_live_forecast_v4_1_paper.py --test-ntfy
echo "[5/8] Sending TEST ONLY paper trade ntfy..."
python bee_live_forecast_v4_1_paper.py --test-trade-ntfy
echo "[6/8] Running real once-run..."
python bee_live_forecast_v4_1_paper.py --once || true
echo "[7/8] Exporting fixed debug ZIP..."
python bee_live_forecast_v4_1_paper.py --export-debug
echo "[8/8] Done. Download this file via Termius SFTP:"
ls -lah /home/ubuntu/bee_latest_export.zip
