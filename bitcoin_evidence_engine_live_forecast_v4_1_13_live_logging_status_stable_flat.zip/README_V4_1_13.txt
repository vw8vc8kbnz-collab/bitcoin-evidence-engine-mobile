BEE Live Forecast v4.1.13

Nieuw:
- server-safe live logging: bee_status.json, bee_history.csv, bee_signals.csv
- atomic writes, history trim, rotating log, disk guard
- bee_evaluate.py voor 30d outcome evaluatie
- exports schrijven vast naar /home/ubuntu/bee_latest_export.zip
- force ntfy is duidelijk TEST ONLY en wordt niet in bee_signals.csv gezet

Termius one-line na upload naar GitHub root:
cd /home/ubuntu/bitcoin-engine-deploy/current && rm -rf github_latest && git clone https://github.com/vw8vc8kbnz-collab/bitcoin-evidence-engine-mobile.git github_latest && unzip -o github_latest/bitcoin_evidence_engine_live_forecast_v4_1_13_live_logging_status_stable_flat.zip && chmod +x scripts/bee_one_line_live_update_test_export.sh && ./scripts/bee_one_line_live_update_test_export.sh
