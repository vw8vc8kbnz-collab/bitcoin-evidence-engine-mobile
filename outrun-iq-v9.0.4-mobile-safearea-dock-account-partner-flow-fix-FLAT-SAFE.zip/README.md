# Outrun IQ v9.0.4

Mobile Safe Area, Dock & Partner Flow Fix.

Deze release bouwt door op v9.0.3 en corrigeert de gemelde mobiele regressies:

- witte safe-area/statusbalk-strip zoveel mogelijk weggewerkt;
- bottom navigation lager/strakker gezet;
- buyer accountpagina leesbaar gemaakt;
- zakelijke omgeving blijft darkmode;
- partner dashboardkop opgeschoond;
- product toevoegen heeft weer zichtbare vervolgknoppen boven de dock.
