# v9.0.4 — Mobile Safe Area, Dock & Partner Flow Fix

- Verwijdert de zichtbare witte safe-area/statusbalk-strip op buyer en partner/PWA-surfaces zo ver mogelijk via theme/background overrides.
- Zet de mobiele bottom navigation lager en compacter, zonder dubbele safe-area marge.
- Maakt vaste vervolgknoppen in de product-toevoegflow weer zichtbaar boven de dock.
- Herstelt buyer accountpagina: lichte kaartstijl met donkere leesbare tekst.
- Houdt zakelijke kant volledig in darkmode.
- Vervangt de vier onduidelijke ronde dashboardknoppen rechtsboven door twee duidelijke acties: Orders en Account.
- Scope blijft bewust klein: geen nieuwe features, alleen herstel van de gemelde UX-regressies.
