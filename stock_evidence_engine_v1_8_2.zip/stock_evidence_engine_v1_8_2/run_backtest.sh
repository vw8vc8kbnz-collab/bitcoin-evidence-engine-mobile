#!/usr/bin/env bash
set -euo pipefail
APP=/home/ubuntu/stock_evidence_latest
TICKERS="${1:-BB,PLTR,IONQ,SOUN,NVDA,AMD,TSLA}"
cd "$APP"
if [ ! -x "$APP/venv/bin/python" ]; then
  echo "[SEE run] ERROR: venv missing. Run ./install.sh first."
  exit 2
fi
"$APP/venv/bin/python" "$APP/engine.py" "$TICKERS"
