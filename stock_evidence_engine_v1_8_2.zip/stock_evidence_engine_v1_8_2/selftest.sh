#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
for f in VERSION requirements.txt install.sh run_backtest.sh selftest.sh engine.py server.py deepseek_prompt.md; do
  test -f "$f" || { echo "[SEE selftest] missing $f"; exit 1; }
done
python3 -m py_compile engine.py server.py
if grep -R "v1.8.0\|v1.8.1" -n engine.py server.py VERSION README.md RELEASE_NOTES.md PROJECT_MASTERPLAN.md >/tmp/see_selftest_grep 2>/dev/null; then
  cat /tmp/see_selftest_grep
  echo "[SEE selftest] old version reference found"
  exit 1
fi
echo "[SEE selftest] OK v1.8.2"
