# SEE masterplan

Stable baseline: `/home/ubuntu/stock_evidence_latest`, stdlib `server.py`, port 8798, fixed venv, 4 scans/day, ntfy topic `stock-signals-Stijn-2026`, DeepSeek as analyst layer only.
