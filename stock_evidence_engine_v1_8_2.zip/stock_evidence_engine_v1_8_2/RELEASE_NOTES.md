# v1.8.2

- Fixed installer: no copy into itself and no nested-root deploy.
- Fixed Safari mojibake with UTF-8 charset.
- Stronger DeepSeek mode: 20 headlines and 1600 output tokens per ticker.
- Keeps 4 scans/day and $5/month budget guard.
- Update command preserves `.env` when possible.
