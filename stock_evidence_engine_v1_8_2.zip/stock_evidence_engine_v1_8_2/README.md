# Stock Evidence Engine v1.8.2

Fix release: clean ZIP root, safe installer, stronger DeepSeek analyst context, compact mobile dashboard, ntfy alerts and cost guard.

Runtime: `/usr/bin/python3 /home/ubuntu/stock_evidence_latest/server.py` on port 8798. Backtest always uses fixed venv.
