#!/usr/bin/env python3
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
import json, html, csv
VERSION='v1.8.2'; ROOT=Path(__file__).resolve().parent; EXPORTS=ROOT/'exports'; PORT=8798

def safe_float(x):
    try: return float(x or 0)
    except Exception: return 0.0

class H(BaseHTTPRequestHandler):
    def do_HEAD(self): self._send(200,b'', 'text/html; charset=utf-8')
    def do_GET(self):
        if self.path=='/health': return self._json({'ok':True,'version':VERSION})
        if self.path=='/exports/all.zip':
            p=EXPORTS/'all.zip'
            if not p.exists(): return self._send(404,b'no export yet','text/plain')
            data=p.read_bytes(); return self._send(200,data,'application/zip',{'Content-Disposition':'attachment; filename="see_audit_export_v1_8_2.zip"'})
        return self._send(200,self.page().encode('utf-8'),'text/html; charset=utf-8')
    def _json(self,obj): self._send(200,json.dumps(obj).encode('utf-8'),'application/json; charset=utf-8')
    def _send(self,code,data,ctype,headers=None):
        self.send_response(code); self.send_header('Content-Type',ctype); self.send_header('Content-Length',str(len(data)))
        for k,v in (headers or {}).items(): self.send_header(k,v)
        self.end_headers();
        if data: self.wfile.write(data)
    def page(self):
        cost={}
        p=EXPORTS/'ai_cost_summary.json'
        if p.exists():
            try: cost=json.loads(p.read_text())
            except Exception: cost={}
        rows=[]
        csvp=EXPORTS/f'see_deepseek_news_analysis_{VERSION}.csv'
        if csvp.exists():
            with csvp.open(encoding='utf-8') as f:
                rows=list(csv.DictReader(f))
        def score(r):
            vals=[safe_float(r.get(k)) for k in ('reaction_adjusted_3d_prob','reaction_adjusted_10d_prob','continuation_probability_3d','continuation_probability_10d','materiality_score','narrative_strength','theme_alignment_score','reaction_score','consensus_score','analog_score')]
            return max(0,min(100,sum(vals)/len(vals)-safe_float(r.get('risk_score'))*.12)) if vals else 0
        rows=sorted(rows, key=score, reverse=True)[:30]
        cards=''.join(self.card(r, score(r)) for r in rows)
        return f'''<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>SEE {VERSION}</title><style>
:root{{--bg:#f4f6fb;--ink:#0b1220;--muted:#667085;--card:#fff;--line:#e7eaf0;--blue:#2563eb;--green:#16a34a;--amber:#d97706;}}
*{{box-sizing:border-box}} body{{font-family:-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;background:var(--bg);margin:0;color:var(--ink)}}
.wrap{{padding:14px;max-width:980px;margin:auto;padding-bottom:96px}} .hero{{background:var(--card);border-radius:26px;padding:20px;margin:10px 0 14px;box-shadow:0 18px 45px #0b12200c}}
.badge{{display:inline-flex;background:#111827;color:white;border-radius:999px;padding:8px 14px;font-weight:800;font-size:14px}} h1{{font-size:36px;line-height:1.02;margin:18px 0 12px;letter-spacing:-1.3px}} p{{color:var(--muted);font-size:16px;line-height:1.33}} .btn{{display:inline-block;background:var(--blue);color:white;text-decoration:none;padding:13px 16px;border-radius:16px;font-weight:800;margin-top:10px}}
.grid{{display:grid;grid-template-columns:repeat(2,1fr);gap:12px}} .metric{{background:rgba(255,255,255,.72);border:1px solid #fff;border-radius:20px;padding:14px;min-height:88px}} .big{{font-size:30px;font-weight:900;letter-spacing:-.8px}} .label{{color:var(--muted);font-size:14px;font-weight:650}}
.section{{margin-top:18px}} .section h2{{font-size:28px;margin:24px 0 12px}} .ai-card{{background:var(--card);border-radius:22px;padding:14px;margin:10px 0;box-shadow:0 10px 28px #0b12200a;border:1px solid var(--line)}} .toprow{{display:flex;align-items:flex-start;justify-content:space-between;gap:10px}} .ticker{{font-size:24px;font-weight:900}} .pill{{border-radius:999px;padding:6px 10px;font-size:12px;font-weight:900;background:#eef2ff;color:#1d4ed8;white-space:nowrap}} .pill.high{{background:#dcfce7;color:#166534}} .pill.extreme{{background:#fee2e2;color:#991b1b}} .meta{{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin:12px 0}} .mini{{background:#f8fafc;border-radius:14px;padding:10px}} .mini b{{font-size:19px}} .reason{{font-size:14px;line-height:1.32;color:#344054;background:#fafafa;border-radius:14px;padding:10px;margin-top:8px;max-height:88px;overflow:hidden}} .head{{font-size:13px;color:#667085;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:8px}}
.costbar{{display:flex;justify-content:space-between;gap:10px;align-items:center;background:#0f172a;color:white;border-radius:18px;padding:14px;margin:14px 0}} .costbar small{{color:#cbd5e1}}
@media(max-width:520px){{.wrap{{padding:14px}} h1{{font-size:38px}} .grid{{grid-template-columns:repeat(2,1fr)}} .big{{font-size:30px}} .meta{{grid-template-columns:repeat(3,1fr)}} .mini{{padding:8px}} .mini b{{font-size:17px}}}}
</style></head><body><div class="wrap"><div class="hero"><span class="badge">Stock Evidence Engine {VERSION}</span><h1>DeepSeek Analyst Brain</h1><p>AI signal cards + price reaction + consensus + analog memory + ntfy budget guard. Marktdata blijft lokaal/Yahoo; DeepSeek analyseert alleen de catalyst + marktcontext.</p><a class="btn" href="/exports/all.zip">Download audit ZIP</a></div>
<div class="grid"><div class="metric"><div class="big">{cost.get('tickers','-')}</div><div class="label">Tickers analysed</div></div><div class="metric"><div class="big">{cost.get('total_input_tokens','-')}</div><div class="label">Input tokens</div></div><div class="metric"><div class="big">{cost.get('total_output_tokens','-')}</div><div class="label">Output tokens</div></div><div class="metric"><div class="big">${cost.get('estimated_cost_usd','-')}</div><div class="label">Cost/run</div></div></div>
<div class="costbar"><div><b>Monthly estimate</b><br><small>{cost.get('scans_per_day','4')} scans/day • budget ${cost.get('monthly_budget_usd','5')}</small></div><div><b>${cost.get('estimated_monthly_cost_usd','-')}</b><br><small>{cost.get('budget_status','')}</small></div></div>
<div class="section"><h2>AI Signal Cards</h2>{cards or '<p>No AI rows yet. Run backtest first.</p>'}</div></div></body></html>'''
    def card(self,r,score):
        ticker=html.escape(r.get('ticker','?'))
        provider=html.escape(r.get('_provider',''))
        conv=html.escape(r.get('conviction') or 'LOCAL')
        cl='extreme' if conv=='EXTREME' else ('high' if conv=='HIGH' else '')
        event=html.escape(r.get('catalyst_type') or r.get('event_type') or 'unknown')
        reason=html.escape((r.get('reason') or '')[:190])
        best=html.escape((r.get('best_headline') or '')[:130])
        return f'''<div class="ai-card"><div class="toprow"><div><div class="ticker">{ticker}</div><div class="head">{provider} • {event}</div></div><span class="pill {cl}">{conv}</span></div><div class="meta"><div class="mini"><div class="label">AI score</div><b>{score:.1f}</b></div><div class="mini"><div class="label">3D prob</div><b>{html.escape(str(r.get('reaction_adjusted_3d_prob') or r.get('continuation_probability_3d','')))}%</b></div><div class="mini"><div class="label">10D prob</div><b>{html.escape(str(r.get('reaction_adjusted_10d_prob') or r.get('continuation_probability_10d','')))}%</b></div></div><div class="meta"><div class="mini"><div class="label">Materiality</div><b>{html.escape(str(r.get('materiality_score','')))}</b></div><div class="mini"><div class="label">Narrative</div><b>{html.escape(str(r.get('narrative_strength','')))}</b></div><div class="mini"><div class="label">Risk</div><b>{html.escape(str(r.get('risk_score','')))}</b></div></div><div class="reason">{reason}</div><div class="head">{best}</div></div>'''

HTTPServer(('0.0.0.0',PORT),H).serve_forever()
