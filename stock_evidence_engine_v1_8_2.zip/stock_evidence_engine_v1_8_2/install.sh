#!/usr/bin/env bash
set -euo pipefail
APP=/home/ubuntu/stock_evidence_latest
cd "$(dirname "$0")"
HERE="$(pwd -P)"
if [ "$HERE" != "$APP" ]; then
  echo "[SEE install] ERROR: run install.sh from $APP only. Current: $HERE"
  echo "[SEE install] Move/unzip the version folder to $APP first; refusing to copy directories into themselves."
  exit 2
fi
sudo chown -R ubuntu:ubuntu "$APP" || true
rm -rf "$APP/venv" "$APP/.venv"
python3 -m venv "$APP/venv"
"$APP/venv/bin/python" -m pip install --upgrade pip
"$APP/venv/bin/python" -m pip install -r "$APP/requirements.txt"
chmod +x "$APP/run_backtest.sh" "$APP/selftest.sh" "$APP/engine.py" "$APP/server.py" || true
"$APP/venv/bin/python" - <<'PYINSTALLCHECK'
import importlib
for m in ['requests','dotenv','yfinance','pandas','numpy']:
    importlib.import_module(m)
print('[SEE install] dependency check OK')
PYINSTALLCHECK
sudo tee /etc/systemd/system/stock-evidence-dashboard.service >/dev/null <<EOT
[Unit]
Description=Stock Evidence Engine Dashboard
After=network.target
[Service]
Type=simple
User=ubuntu
WorkingDirectory=$APP
ExecStart=/usr/bin/python3 $APP/server.py
Restart=always
RestartSec=5
[Install]
WantedBy=multi-user.target
EOT
sudo tee /etc/systemd/system/stock-evidence-scan.service >/dev/null <<EOT
[Unit]
Description=Stock Evidence Engine DeepSeek Scan
After=network-online.target
[Service]
Type=oneshot
User=ubuntu
WorkingDirectory=$APP
ExecStart=/bin/bash -lc '$APP/run_backtest.sh "BB,PLTR,IONQ,SOUN,NVDA,AMD,TSLA,AI,BBAI,RKLB,SMR,ACHR,JOBY,UPST,HOOD,COIN,MARA,RIOT,LCID,RIVN" "2y"'
EOT
sudo tee /etc/systemd/system/stock-evidence-scan.timer >/dev/null <<EOT
[Unit]
Description=Run Stock Evidence Engine scans 4x per day
[Timer]
OnCalendar=*-*-* 13:30:00
OnCalendar=*-*-* 16:00:00
OnCalendar=*-*-* 19:00:00
OnCalendar=*-*-* 22:00:00
Persistent=true
[Install]
WantedBy=timers.target
EOT
sudo systemctl daemon-reload
sudo systemctl enable stock-evidence-dashboard.service
sudo systemctl restart stock-evidence-dashboard.service
if [ "${SEE_ENABLE_TIMER:-1}" = "1" ]; then
  sudo systemctl enable stock-evidence-scan.timer
  sudo systemctl restart stock-evidence-scan.timer
fi
echo "[SEE install] OK"
