export type Listing = {
  id: string; title: string; condition: string;
  price: number; perUnit?: boolean; market: number; fast: number;
  discount: number; score: number; badge: string;
  seller: string; sellerSlug: string; city: string; km: number;
  img: string; fallback: "washer" | "sofa" | "chair" | "tv" | "dryer";
  confidence: number; comps: number; delivery: string; deliveryPrice: number;
  defect?: string;
};

const U = (id: string, w = 640) =>
  `https://images.unsplash.com/${id}?q=80&w=${w}&auto=format&fit=crop`;

export const listings: Listing[] = [
  { id: "bosch-serie-6-9kg", title: "Bosch Serie 6 wasmachine 9kg",
    condition: "Retour, ongebruikt · doos licht beschadigd",
    price: 549, market: 899, fast: 479, discount: 39, score: 92, badge: "FAST MOVER",
    seller: "Expert Outlet Rotterdam", sellerSlug: "expert-outlet-rotterdam", city: "Rotterdam", km: 4,
    img: U("photo-1626806787461-102c1bfaaea1"), fallback: "washer",
    confidence: 92, comps: 214, delivery: "Bezorging morgen 09:00–12:00", deliveryPrice: 35,
    defect: "Gebrek: doos — foto 4/6" },
  { id: "hoekbank-modena-velvet", title: "Design hoekbank Modena velvet",
    condition: "Showroommodel · lichte gebruikssporen",
    price: 1249, market: 2199, fast: 1090, discount: 43, score: 88, badge: "SHOWROOM",
    seller: "Woonstudio Outlet", sellerSlug: "woonstudio-outlet", city: "Amersfoort", km: 52,
    img: U("photo-1555041469-a586c61ea9bc"), fallback: "sofa",
    confidence: 87, comps: 121, delivery: "Brenger levering do", deliveryPrice: 49,
    defect: "Gebrek: kras zijkant — foto 3/8" },
  { id: "bureaustoel-24x", title: "Ergonomische bureaustoel — 24 stuks",
    condition: "Eindserie · nieuw in doos",
    price: 139, perUnit: true, market: 329, fast: 119, discount: 58, score: 94, badge: "PARTIJ",
    seller: "OfficeFlow Projectinrichting", sellerSlug: "officeflow", city: "Breda", km: 38,
    img: U("photo-1580480055273-228ff5388ef8"), fallback: "chair",
    confidence: 95, comps: 167, delivery: "Pallet-verzending", deliveryPrice: 65 },
  { id: "samsung-55-qled", title: "Samsung 55\" QLED — doosschade",
    condition: "Retour · doos beschadigd, toestel nieuw",
    price: 479, market: 749, fast: 429, discount: 36, score: 86, badge: "RETOUR",
    seller: "Expert Outlet Rotterdam", sellerSlug: "expert-outlet-rotterdam", city: "Rotterdam", km: 4,
    img: U("photo-1593359677879-a4bb92f829d1"), fallback: "tv",
    confidence: 90, comps: 188, delivery: "Ophalen of PostNL XL", deliveryPrice: 19 },
];

export const stores = [
  { slug: "expert-outlet-rotterdam", name: "Expert Outlet Rotterdam", trust: 96, orders: 842,
    meta: "142 listings · witgoed", img: U("photo-1556911220-bff31c812dba") },
  { slug: "woonstudio-outlet", name: "Woonstudio Outlet", trust: 93, orders: 311,
    meta: "84 listings · meubels", img: U("photo-1555041469-a586c61ea9bc") },
  { slug: "officeflow", name: "OfficeFlow Projectinrichting", trust: 91, orders: 128,
    meta: "37 listings · kantoor", img: U("photo-1580480055273-228ff5388ef8") },
];

export const byId = (id: string) => listings.find(l => l.id === id);
export const eur = (n: number) => "€" + n.toLocaleString("nl-NL");
