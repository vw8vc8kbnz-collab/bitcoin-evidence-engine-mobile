# Outrun IQ — app v5

Next.js 15 / React 19. Volledige v5-app: kopersflow (licht) + Seller Hub (donker).
Demo-data in `lib/data.ts`; foto's zijn Unsplash-hotlinks met SVG-fallback.

## Routes

| Koper | Seller |
|---|---|
| `/` home (feature · rail · ticket) | `/seller` dashboard |
| `/zoeken?q=` lijstrijen | `/seller/voorraad` AI-vlaggen |
| `/listing/[id]` (tik vanaf grid = overlay-sheet mét URL) | `/seller/nieuw` AI-flow |
| `/checkout/[id]` → `/order/[id]` escrow-stepper | `/seller/orders` actie-eerst |
| `/bewaard` · `/account` (Kopen/Verkopen-switch) | `/seller/geld` · `/seller/storefront` |
| `/store/[slug]` | |

## Lokaal

```bash
npm install
npm run dev        # http://localhost:3000
```

## Workflow: zip → GitHub → VPS → Termius

**1. Eenmalig — repo op GitHub zetten (lokaal, na uitpakken zip):**
```bash
cd outrun-iq-v5
git init -b main && git add -A && git commit -m "v5: volledige app"
git remote add origin git@github.com:JOUW-GEBRUIKER/outrun-iq.git
git push -u origin main
```

**2. Eenmalig — VPS (Ubuntu):** pas eerst `REPO=` aan in `deploy.sh`, kopieer hem mee of plak hem op de server, en draai:
```bash
bash deploy.sh
```
De app draait daarna onder pm2 op **poort 8795** en overleeft reboots via `pm2 save`
(+ eenmalig `pm2 startup` volgen als dat nog niet gedaan is).

**3. Elke update — één regel voor Termius:**
```bash
cd /var/www/outrun-iq && git pull && npm ci && npm run build && pm2 restart outrun-iq
```

## Status / eerlijke noten
- UI compleet, ongetest gebouwd (geen npm in de bouwomgeving) — kleine buildfixes mogelijk.
- Geen backend: knoppen als "Bied", filters en "Betaal" zijn dummy of navigatie-only.
- Unsplash-foto's vervangen door eigen fotografie vóór livegang.
- Draai achter een domein + reverse proxy met TLS (nginx/Caddy) i.p.v. kaal IP:poort.
