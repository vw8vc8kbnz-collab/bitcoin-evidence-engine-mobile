"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";

const I = {
  home: <path d="M4 11l8-7 8 7v9h-6v-6h-4v6H4z" />,
  search: <><circle cx="11" cy="11" r="6.5" /><path d="M20 20l-4.2-4.2" /></>,
  saved: <path d="M6 3h12v18l-6-4-6 4z" />,
  user: <><circle cx="12" cy="8.5" r="3.5" /><path d="M5 19c1.2-3 4-4.5 7-4.5s5.8 1.5 7 4.5" /></>,
  grid: <><rect x="4" y="4" width="7" height="7" rx="1.5" /><rect x="13" y="4" width="7" height="7" rx="1.5" /><rect x="4" y="13" width="7" height="7" rx="1.5" /><rect x="13" y="13" width="7" height="7" rx="1.5" /></>,
  list: <path d="M4 6h16M4 12h16M4 18h10" />,
  orders: <path d="M5 4h14v16l-3-2-2 2-2-2-2 2-2-2-3 2z" />,
  money: <><path d="M4 17l5-5 4 3 7-8" /><path d="M15 7h5v5" /></>,
};

function Tab({ href, icon, label, exact = false }:{
  href: string; icon: keyof typeof I; label: string; exact?: boolean;
}) {
  const path = usePathname();
  const on = exact ? path === href : path.startsWith(href);
  return (
    <Link href={href} className={`t${on ? " on" : ""}`}>
      <svg viewBox="0 0 24 24">{I[icon]}</svg>{label}
    </Link>
  );
}

export function BuyerDock() {
  return (
    <nav className="dock" aria-label="Navigatie">
      <Tab href="/" icon="home" label="ONTDEK" exact />
      <Tab href="/zoeken" icon="search" label="ZOEKEN" />
      <Link href="/seller/nieuw" className="plus" aria-label="Verkopen">
        <svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14" /></svg>
      </Link>
      <Tab href="/bewaard" icon="saved" label="BEWAARD" />
      <Tab href="/account" icon="user" label="ACCOUNT" />
    </nav>
  );
}

export function SellerDock() {
  return (
    <nav className="dock dk" aria-label="Seller-navigatie">
      <Tab href="/seller" icon="grid" label="DASH" exact />
      <Tab href="/seller/voorraad" icon="list" label="VOORRAAD" />
      <Link href="/seller/nieuw" className="plus" aria-label="Nieuw product">
        <svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14" /></svg>
      </Link>
      <Tab href="/seller/orders" icon="orders" label="ORDERS" />
      <Tab href="/seller/geld" icon="money" label="GELD" />
    </nav>
  );
}
