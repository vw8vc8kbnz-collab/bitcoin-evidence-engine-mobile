export type IlluKind = "washer" | "sofa" | "chair" | "tv" | "dryer";

export const Mark = ({ size = 26, glow = false }: { size?: number; glow?: boolean }) => (
  <svg width={size} height={size} viewBox="0 0 190 190" aria-hidden>
    <path d="M147,103 A60,60 0 1 1 95,50" fill="none" stroke={glow ? "#35A9AC" : "#0E5A5E"}
      strokeWidth="22" strokeLinecap="round" transform="rotate(8 88 110)" />
    <circle cx="154" cy="44" r="17" fill="#E9A13B" />
  </svg>
);

export const Check = () => (
  <svg className="vch" viewBox="0 0 14 14" aria-hidden>
    <circle cx="7" cy="7" r="7" fill="#0E5A5E" />
    <path d="M4 7l2 2 4-4" stroke="#fff" strokeWidth="1.6" fill="none" strokeLinecap="round" />
  </svg>
);

export const Chev = () => (
  <span className="chev"><svg viewBox="0 0 7 12"><path d="M1 1l5 5-5 5" /></svg></span>
);

export function Illu({ kind }: { kind: IlluKind }) {
  const p: Record<IlluKind, React.ReactNode> = {
    washer: <><rect x="34" y="8" width="52" height="74" rx="6"/><circle cx="60" cy="50" r="15"/><circle cx="60" cy="50" r="9"/><path d="M34 22h52"/></>,
    dryer: <><rect x="30" y="10" width="60" height="70" rx="5"/><circle cx="60" cy="45" r="13"/></>,
    sofa: <><path d="M14 56V38c0-5 4-9 9-9h74c5 0 9 4 9 9v18"/><path d="M14 56c-4 0-7 3-7 7v6c0 4 3 7 7 7h92c4 0 7-3 7-7v-6c0-4-3-7-7-7"/><path d="M14 56h92"/></>,
    chair: <><path d="M45 10h30v26a6 6 0 01-6 6H51a6 6 0 01-6-6V10z"/><path d="M60 42v14M42 56h36M44 82l8-14M76 82l-8-14"/></>,
    tv: <><rect x="20" y="14" width="80" height="50" rx="4"/><path d="M40 74h40M60 64v10"/></>,
  };
  return <svg viewBox="0 0 120 90">{p[kind]}</svg>;
}

export const Score = ({ v, className = "sc" }: { v: number; className?: string }) => (
  <span className={`ovl ${className}`}>{v}</span>
);
