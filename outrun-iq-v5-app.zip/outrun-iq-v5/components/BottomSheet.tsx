"use client";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";

/**
 * Overlay-sheet met drie snap-points: peek (28%), half (62%), full (92%).
 * Sluiten = router.back() -> URL en scrollpositie van het grid blijven intact.
 */
const SNAPS = [0.28, 0.62, 0.92];

export function BottomSheet({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const [snap, setSnap] = useState(1);
  const [drag, setDrag] = useState<null | { startY: number; startT: number }>(null);
  const [t, setT] = useState(0); // extra translate tijdens drag
  const [mounted, setMounted] = useState(false);
  const sheetRef = useRef<HTMLDivElement>(null);
  useEffect(() => { const id = requestAnimationFrame(() => setMounted(true)); return () => cancelAnimationFrame(id); }, []);

  const close = useCallback(() => router.back(), [router]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && close();
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => { document.removeEventListener("keydown", onKey); document.body.style.overflow = ""; };
  }, [close]);

  const baseY = () => (1 - SNAPS[snap]) * window.innerHeight;

  const onPointerDown = (e: React.PointerEvent) => {
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
    setDrag({ startY: e.clientY, startT: 0 });
  };
  const onPointerMove = (e: React.PointerEvent) => {
    if (!drag) return;
    setT(e.clientY - drag.startY);
  };
  const onPointerUp = () => {
    if (!drag) return;
    const y = baseY() + t;
    const h = window.innerHeight;
    const pos = 1 - y / h;
    let best = 0, bd = Infinity;
    SNAPS.forEach((s, i) => { const d = Math.abs(s - pos); if (d < bd) { bd = d; best = i; } });
    if (pos < SNAPS[0] - 0.09) { close(); return; }
    setSnap(best); setDrag(null); setT(0);
  };

  const transform = !mounted || typeof window === "undefined"
    ? "translateY(100%)"
    : `translateY(${Math.max(0, (1 - SNAPS[snap]) * window.innerHeight + (drag ? t : 0))}px)`;

  return (
    <>
      <div className="scrim" onClick={close} aria-hidden />
      <div
        ref={sheetRef}
        className={`sheet${drag ? " dragging" : ""}`}
        style={{ transform }}
        role="dialog" aria-modal="true"
      >
        <div className="sgrab"
          onPointerDown={onPointerDown} onPointerMove={onPointerMove}
          onPointerUp={onPointerUp} onPointerCancel={onPointerUp}>
          <i />
        </div>
        <div className="sbody">{children}</div>
      </div>
    </>
  );
}
