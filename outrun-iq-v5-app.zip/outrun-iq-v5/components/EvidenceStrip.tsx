import type { Listing } from "@/lib/data";

export function EvidenceStrip({ l, light = false, labels = true }:{
  l: Listing; light?: boolean; labels?: boolean;
}) {
  const p = Math.round((l.price / l.market) * 100);
  return (
    <div aria-label={`Prijspositie: fast €${l.fast}, outlet €${l.price}, markt €${l.market}`}>
      <div className={`ev ${light ? "lt" : ""}`} style={{ ["--p" as string]: `${p}%` }} role="img"><i /><u /></div>
      {labels && <div className="evl"><span>FAST €{l.fast}</span><span>OUTLET</span><span>MARKT €{l.market}</span></div>}
    </div>
  );
}
