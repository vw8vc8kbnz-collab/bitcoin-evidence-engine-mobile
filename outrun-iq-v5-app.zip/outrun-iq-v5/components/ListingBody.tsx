import Link from "next/link";
import type { Listing } from "@/lib/data";
import { eur } from "@/lib/data";
import { EvidenceStrip } from "./EvidenceStrip";

/** Gedeeld tussen volledige pagina en overlay-sheet. */
export function ListingBody({ l }: { l: Listing }) {
  return (
    <div className="lsheet">
      <div className="grab" />
      <h1>{l.title}</h1>
      <div className="selrow">
        <span className="av">{l.seller.slice(0, 2).toUpperCase()}</span>
        <span><b>{l.seller} ✓</b><span>trust 96/100 · reactie &lt; 4u · {l.city}</span></span>
        <Link href={`/store/${l.sellerSlug}`} className="go">STORE →</Link>
      </div>
      <div className="pricecard">
        <h4>✦ AI-PRIJSBEWIJS · {l.comps} PRIJSPUNTEN · CONFIDENCE {l.confidence}</h4>
        <div className="l1"><b>{eur(l.price)}{l.perUnit && "/st"}</b><s>markt {eur(l.market)}</s><span className="d">−{l.discount}%</span></div>
        <EvidenceStrip l={l} labels={false} />
        <div className="lg"><span>FAST {eur(l.fast)}</span><span>OUTLET</span><span>MARKT {eur(l.market)}</span></div>
        <p className="src">{l.condition} · vergelijkbare items weg binnen 6 dagen</p>
      </div>
      <div className="cta2">
        <Link href={`/checkout/${l.id}`} className="btn pri">Koop nu — {eur(l.price)}</Link>
        <button className="btn sec">Bied</button>
      </div>
    </div>
  );
}
