#!/usr/bin/env bash
# OUTRUN IQ v5 — eerste deployment op de VPS (eenmalig draaien)
# Vereist: Node 20+, git, pm2 (npm i -g pm2)
set -euo pipefail

APP_DIR=/var/www/outrun-iq
REPO=git@github.com:JOUW-GEBRUIKER/outrun-iq.git   # <-- aanpassen

if [ ! -d "$APP_DIR" ]; then
  sudo mkdir -p "$APP_DIR" && sudo chown "$USER":"$USER" "$APP_DIR"
  git clone "$REPO" "$APP_DIR"
fi
cd "$APP_DIR"
npm ci
npm run build
pm2 delete outrun-iq 2>/dev/null || true
pm2 start npm --name outrun-iq -- start      # draait op poort 8795 (package.json)
pm2 save
echo "Live op http://$(hostname -I | awk '{print $1}'):8795"
