import Link from "next/link";
import { Mark } from "@/components/icons";

const rows = [
  { t: "Bosch Serie 6 · OIQ-0042", s: "UITBETALING NA LEVERING (MORGEN)", flag: "IN ESCROW", hot: true, a: "€494" },
  { t: "Samsung QLED · OIQ-0039", s: "GELEVERD DI · UITBETAALD WO", flag: "BETAALD", hot: false, a: "€431" },
  { t: "AEG vaatwasser · OIQ-0035", s: "OPGEHAALD MA · UITBETAALD DI", flag: "BETAALD", hot: false, a: "€287" },
  { t: "Miele WCA 030 · OIQ-0031", s: "GELEVERD VR · UITBETAALD MA", flag: "BETAALD", hot: false, a: "€719" },
];

export default function Geld() {
  return (
    <main className="page">
      <header className="hd">
        <Link href="/seller" className="lock" style={{ color: "#fff" }}><Mark glow />Geld</Link>
        <span className="sp" />
      </header>
      <div className="big"><label>ONDERWEG NAAR JE REKENING</label><b>€2.340</b></div>
      <div className="dkchips">
        <span className="dkc"><label>UITBETAALD 30D</label><b>€43.8K</b></span>
        <span className="dkc"><label>COMMISSIE 30D</label><b>€4.8K</b></span>
      </div>
      <div className="dsec"><h2>Deze week</h2><span>NA 10% COMMISSIE</span></div>
      {rows.map(r => (
        <div key={r.t} className="pay">
          <b>{r.t}<small>{r.s}</small></b>
          <span className={`flag ${r.hot ? "hot" : "ok3"}`}>{r.flag}</span>
          <span className="amt2">{r.a}</span>
        </div>
      ))}
      <p className="note">Uitbetaling volgt automatisch zodra de koper levering bevestigt.</p>
      <div className="slabel">MEER</div>
      <div className="dgroup">
        <Link href="/seller/storefront" className="dli"><span className="icb"><svg viewBox="0 0 24 24"><rect x="4" y="4" width="16" height="16" rx="3" /><path d="M4 10h16M10 10v10" /></svg></span><b>Mijn storefront<small>preview &amp; instellingen</small></b><span className="chev"><svg viewBox="0 0 7 12"><path d="M1 1l5 5-5 5" /></svg></span></Link>
      </div>
    </main>
  );
}
