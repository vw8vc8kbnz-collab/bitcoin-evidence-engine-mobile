import { SellerDock } from "@/components/Dock";

export default function SellerLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="app dark">
      {children}
      <SellerDock />
    </div>
  );
}
