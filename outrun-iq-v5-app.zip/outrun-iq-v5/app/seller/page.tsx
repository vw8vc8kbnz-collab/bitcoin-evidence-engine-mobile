import Link from "next/link";
import { Mark } from "@/components/icons";
import { Img } from "@/components/Img";
import { listings, eur } from "@/lib/data";

export default function SellerDash() {
  const a = listings[0], b = listings[3];
  return (
    <main className="page">
      <header className="hd">
        <Link href="/seller" className="lock" style={{ color: "#fff" }}><Mark glow />SELLER <b>HUB</b></Link>
        <span className="sp" />
        <Link href="/account" className="icbtn" aria-label="Naar kopersaccount">
          <svg viewBox="0 0 24 24"><circle cx="12" cy="8.5" r="3.5" /><path d="M5 19c1.2-3 4-4.5 7-4.5s5.8 1.5 7 4.5" /></svg>
        </Link>
      </header>
      <div className="big"><label>OMZET · LAATSTE 30 DAGEN</label><b>€48.240 <span className="up">▲ 18%</span></b></div>
      <svg className="spark" height="44" viewBox="0 0 280 44" preserveAspectRatio="none" aria-hidden>
        <defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#35A9AC" stopOpacity=".35" /><stop offset="1" stopColor="#35A9AC" stopOpacity="0" />
        </linearGradient></defs>
        <path d="M0,36 C25,32 40,38 60,30 S95,17 120,21 150,28 175,19 215,8 245,11 270,6 280,8 L280,44 L0,44 Z" fill="url(#g)" />
        <path d="M0,36 C25,32 40,38 60,30 S95,17 120,21 150,28 175,19 215,8 245,11 270,6 280,8" fill="none" stroke="#35A9AC" strokeWidth="2" />
        <circle cx="280" cy="8" r="3.4" fill="#E9A13B" />
      </svg>
      <div className="dkchips">
        <span className="dkc"><label>LISTINGS</label><b>142</b></span>
        <span className="dkc"><label>SELL-THR.</label><b>18.7%</b></span>
        <span className="dkc"><label>IN ESCROW</label><b>€2.3K</b></span>
      </div>
      <Link href="/seller/voorraad" className="act">
        <span className="n2">3</span>
        <span><b>Prijsadviezen klaar</b><span>3 listings boven AI-outletprijs · +18% verwacht</span></span>
        <span className="go">FIX →</span>
      </Link>
      <div className="dsec"><h2>Vandaag</h2><span>2 ORDERS</span></div>
      <div className="orow">
        <Img src={a.img} fallback={a.fallback} dark />
        <span><b>Bosch Serie 6 · OIQ-0042</b><span>BEZORGING MORGEN 09–12</span></span>
        <span className="amt">€494<i className="esc">IN ESCROW</i></span>
      </div>
      <div className="orow">
        <Img src={b.img} fallback={b.fallback} dark />
        <span><b>Samsung QLED · OIQ-0043</b><span>OPHALEN VANDAAG 16:00</span></span>
        <span className="amt">€431<i className="esc">IN ESCROW</i></span>
      </div>
    </main>
  );
}
