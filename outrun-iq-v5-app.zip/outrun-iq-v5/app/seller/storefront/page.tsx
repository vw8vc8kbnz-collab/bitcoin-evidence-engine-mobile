import Link from "next/link";
import { stores } from "@/lib/data";

export default function Storefront() {
  const s = stores[0];
  return (
    <main className="page">
      <header className="hd">
        <Link href="/seller" className="back" style={{ color: "#fff" }}>
          <svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7" /></svg>Dash
        </Link>
        <span className="sp" /><span className="mini" style={{ color: "#8B96A0" }}>STOREFRONT</span>
      </header>
      <h1 className="h1big">Jouw outlet store</h1>
      <div className="sfprev">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={s.img} alt="" />
        <span className="sh2" />
        <span className="in">
          <span className="av">EX</span>
          <span><b>{s.name} ✓</b><span>TRUST {s.trust}/100 · 142 LISTINGS · {s.orders} ORDERS</span></span>
        </span>
      </div>
      <div className="slabel">INSTELLINGEN</div>
      <div className="dgroup">
        <button className="dli"><span className="icb"><svg viewBox="0 0 24 24"><path d="M4 7l8-4 8 4v10l-8 4-8-4z" /></svg></span><b>Bedrijfsprofiel<small>logo · banner · over ons</small></b><span className="chev"><svg viewBox="0 0 7 12"><path d="M1 1l5 5-5 5" /></svg></span></button>
        <button className="dli"><span className="icb"><svg viewBox="0 0 24 24"><path d="M3 12h4l3-8 4 16 3-8h4" /></svg></span><b>Levering &amp; ophalen<small>Brenger actief · ophalen R&apos;dam</small></b><span className="chev"><svg viewBox="0 0 7 12"><path d="M1 1l5 5-5 5" /></svg></span></button>
        <button className="dli"><span className="icb"><svg viewBox="0 0 24 24"><rect x="4" y="4" width="16" height="16" rx="3" /><path d="M9 12l2 2 4-4" /></svg></span><b>Verificatie<small>KvK 87654321 · DSA-conform</small></b><span className="val" style={{ color: "#4CBE8B" }}>✓ OK</span></button>
        <button className="dli"><span className="icb"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.7 1.7 0 00.3 1.9l.1.1a2 2 0 11-2.8 2.8l-.1-.1a1.7 1.7 0 00-1.9-.3 1.7 1.7 0 00-1 1.5V21a2 2 0 11-4 0v-.1a1.7 1.7 0 00-1-1.6 1.7 1.7 0 00-1.9.3l-.1.1a2 2 0 11-2.8-2.8l.1-.1a1.7 1.7 0 00.3-1.9 1.7 1.7 0 00-1.5-1H3a2 2 0 110-4h.1a1.7 1.7 0 001.6-1 1.7 1.7 0 00-.3-1.9l-.1-.1a2 2 0 112.8-2.8l.1.1a1.7 1.7 0 001.9.3h0a1.7 1.7 0 001-1.5V3a2 2 0 114 0v.1a1.7 1.7 0 001 1.5h0a1.7 1.7 0 001.9-.3l.1-.1a2 2 0 112.8 2.8l-.1.1a1.7 1.7 0 00-.3 1.9v0a1.7 1.7 0 001.5 1H21a2 2 0 110 4h-.1a1.7 1.7 0 00-1.5 1z" /></svg></span><b>Team &amp; toegang<small>2FA verplicht</small></b><span className="chev"><svg viewBox="0 0 7 12"><path d="M1 1l5 5-5 5" /></svg></span></button>
      </div>
      <Link href={`/store/${s.slug}`} className="act" style={{ marginTop: 12 }}>
        <span className="n2">↗</span>
        <span><b>Bekijk je store als koper</b><span>outruniq.nl/store/{s.slug}</span></span>
        <span className="go">OPEN →</span>
      </Link>
    </main>
  );
}
