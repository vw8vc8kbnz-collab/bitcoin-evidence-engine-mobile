import Link from "next/link";
import { Mark } from "@/components/icons";
import { Img } from "@/components/Img";
import { listings } from "@/lib/data";

const rows = [
  { l: listings[0], views: "18 VIEWS/DAG · 3 BEWAARD", price: "€549", flag: "OP AI-PRIJS", hot: false },
  { l: listings[1], views: "6 VIEWS/DAG · −40% KLIKS", price: "€1.249", flag: "−5% ADVIES", hot: true },
  { l: listings[3], views: "31 VIEWS/DAG · HOGE INTERESSE", price: "€479", flag: "FAST MOVER", hot: false },
  { l: listings[2], views: "2 VIEWS/DAG · 34 DGN LIVE", price: "€139/st", flag: "−8% ADVIES", hot: true },
];

export default function Voorraad() {
  return (
    <main className="page">
      <header className="hd">
        <Link href="/seller" className="lock" style={{ color: "#fff" }}><Mark glow />Voorraad</Link>
        <span className="sp" /><span className="mini" style={{ color: "#8B96A0" }}>142 · CSV ↑</span>
      </header>
      <div className="dkchips" style={{ marginTop: 2 }}>
        <span className="dkc" style={{ borderColor: "rgba(233,161,59,.4)" }}><label>ACTIE NODIG</label><b className="amb">3</b></span>
        <span className="dkc"><label>FAST MOVERS</label><b>11</b></span>
        <span className="dkc"><label>&gt; 30 DGN LIVE</label><b>7</b></span>
      </div>
      <div className="dsec"><h2>Listings</h2><span>SORTEER: AI-ADVIES</span></div>
      {rows.map(({ l, views, price, flag, hot }) => (
        <div key={l.id} className="orow">
          <Img src={l.img} fallback={l.fallback} dark />
          <span><b>{l.title}</b><span>{views}</span></span>
          <span className="amt">{price}<i><span className={`flag ${hot ? "hot" : "ok3"}`}>{flag}</span></i></span>
        </div>
      ))}
      <p className="note">De AI vergelijkt elke listing dagelijks met de actuele outletprijs en markeert wat aandacht nodig heeft.</p>
    </main>
  );
}
