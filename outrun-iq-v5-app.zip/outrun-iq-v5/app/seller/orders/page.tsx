import Link from "next/link";
import { Mark } from "@/components/icons";
import { Img } from "@/components/Img";
import { listings } from "@/lib/data";

export default function Orders() {
  return (
    <main className="page">
      <header className="hd">
        <Link href="/seller" className="lock" style={{ color: "#fff" }}><Mark glow />Orders</Link>
        <span className="sp" /><span className="mini" style={{ color: "#8B96A0" }}>8 OPEN</span>
      </header>
      <div className="dkchips" style={{ marginTop: 2 }}>
        <span className="dkc" style={{ borderColor: "rgba(233,161,59,.4)" }}><label>ACTIE NODIG</label><b className="amb">2</b></span>
        <span className="dkc"><label>ONDERWEG</label><b>4</b></span>
        <span className="dkc"><label>AFGEROND 30D</label><b>96</b></span>
      </div>
      <div className="dsec"><h2>Actie nodig</h2></div>
      <div className="orow">
        <Img src={listings[0].img} fallback="washer" dark />
        <span><b>Bevestig bezorgmoment</b><span>OIQ-0042 · KOPER KOOS MORGEN 09–12</span></span>
        <span className="amt" style={{ color: "var(--amber)" }}>→</span>
      </div>
      <div className="orow">
        <Img src={listings[2].img} fallback="chair" dark />
        <span><b>Nieuw bod: €125/st (24×)</b><span>AI: BINNEN ACCEPTATIEBEREIK (61%)</span></span>
        <span className="amt" style={{ color: "var(--amber)" }}>→</span>
      </div>
      <div className="dsec"><h2>Onderweg</h2></div>
      <div className="orow">
        <Img src={listings[3].img} fallback="tv" dark />
        <span><b>Samsung QLED · OIQ-0043</b><span>OPHALEN VANDAAG 16:00</span></span>
        <span className="amt">€431<i className="esc">IN ESCROW</i></span>
      </div>
      <div className="orow">
        <Img src={listings[1].img} fallback="sofa" dark />
        <span><b>Hoekbank Modena · OIQ-0040</b><span>BRENGER GEPLAND DO</span></span>
        <span className="amt">€1.124<i className="esc">IN ESCROW</i></span>
      </div>
    </main>
  );
}
