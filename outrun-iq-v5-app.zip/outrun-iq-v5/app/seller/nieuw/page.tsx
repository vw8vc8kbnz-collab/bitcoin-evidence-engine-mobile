import Link from "next/link";
import { Img } from "@/components/Img";
import { listings, eur } from "@/lib/data";

export default function Nieuw() {
  const l = listings[0];
  return (
    <main className="page" style={{ paddingBottom: 170 }}>
      <header className="hd">
        <Link href="/seller" className="back" style={{ color: "#fff" }}>
          <svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7" /></svg>Stop
        </Link>
        <span className="sp" /><span className="mini" style={{ color: "#8B96A0" }}>STAP 3 / 4</span>
      </header>
      <h1 className="h1big">AI bepaalt je prijs</h1>
      <div className="dots"><i className="on" /><i className="on" /><i className="on" /><i /></div>
      <div className="upl">
        <div className="thumbs">
          <Img src={l.img} fallback={l.fallback} dark />
          <Img src={l.img + "&flip=h"} fallback={l.fallback} dark />
          <Img src={listings[3].img} fallback={listings[3].fallback} dark />
          <span className="add">+</span>
        </div>
        <p>5 foto&apos;s · incl. schade close-up ✓</p>
      </div>
      <div className="scan">
        <div className="r">Productherkenning <span className="done">Bosch Serie 6</span></div>
        <div className="r">Conditieanalyse <span className="done">9.1/10 · doosschade</span></div>
        <div className="r">Marktscan <span className="done">{l.comps} prijspunten</span></div>
        <div className="r">Confidence <span className="done">{l.confidence}/100</span></div>
      </div>
      <div className="dsec"><h2>Kies je strategie</h2></div>
      <div className="pk3">
        <button className="pk"><label>FAST</label><b>{eur(l.fast)}</b><span>± 3 dagen</span></button>
        <button className="pk on"><label>OUTLET</label><b>{eur(l.price)}</b><span>± 6 dagen</span></button>
        <button className="pk"><label>PREMIUM</label><b>€599</b><span>± 14 dagen</span></button>
      </div>
      <p className="note">Kopers zien het prijsbewijs (fast → outlet → markt) bij je listing. Eerlijkheid verkoopt.</p>
      <div className="foot"><Link href="/seller/voorraad" className="btn pri">Publiceer listing — {eur(l.price)}</Link></div>
    </main>
  );
}
