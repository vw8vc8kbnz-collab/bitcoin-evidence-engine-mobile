import Link from "next/link";
import { notFound } from "next/navigation";
import { byId, eur } from "@/lib/data";
import { Img } from "@/components/Img";
import { Chev } from "@/components/icons";

export default async function Order({ params }:{ params: Promise<{ id: string }> }) {
  const { id } = await params;
  const l = byId(id);
  if (!l) notFound();
  const done = (
    <svg viewBox="0 0 12 12"><path d="M2.5 6l2.5 2.5L9.5 3.5" /></svg>
  );
  return (
    <main className="page">
      <header className="hd">
        <Link href="/account" className="back">
          <svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7" /></svg>Bestellingen
        </Link>
        <span className="sp" /><span className="mini">OIQ-2026-0042</span>
      </header>
      <h1 className="h1big">Je bestelling</h1>
      <div style={{ height: 8 }} />
      <div className="oprod">
        <Img src={l.img} fallback={l.fallback} />
        <span><b>{l.title}</b><span>{l.seller} ✓</span></span>
        <span className="pr">{eur(l.price + l.deliveryPrice)}</span>
      </div>
      <div className="slabel">STATUS · GELD VEILIG IN ESCROW</div>
      <div className="stepper">
        <div className="st done"><span className="rl"><i>{done}</i><u /></span><span className="tx2"><b>Betaald</b><span>Gisteren 14:32 · geld staat veilig bij Outrun IQ</span></span></div>
        <div className="st done"><span className="rl"><i>{done}</i><u /></span><span className="tx2"><b>Seller heeft bevestigd</b><span>Gisteren 16:05</span></span></div>
        <div className="st now"><span className="rl"><i /><u /></span><span className="tx2"><b>Bezorging gepland</b><span>Morgen 09:00–12:00</span></span></div>
        <div className="st todo"><span className="rl"><i /></span><span className="tx2"><b>Uitbetaling aan seller</b><span>Na jouw bevestiging van levering</span></span></div>
      </div>
      <div className="slabel">ACTIES</div>
      <div className="group">
        <button className="li"><span className="icb"><svg viewBox="0 0 24 24"><path d="M21 11a8 8 0 10-3.3 6.5L21 19z" /></svg></span><b>Bericht aan seller<small>reageert gemiddeld &lt; 4 uur</small></b><Chev /></button>
        <button className="li"><span className="icb am"><svg viewBox="0 0 24 24"><path d="M12 8v5M12 16.5v.5M12 3l9 16H3z" /></svg></span><b>Probleem melden<small>wij bemiddelen binnen 48 uur</small></b><Chev /></button>
      </div>
    </main>
  );
}
