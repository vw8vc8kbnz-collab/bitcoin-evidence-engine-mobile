import Link from "next/link";
import { listings, eur } from "@/lib/data";
import { Img } from "@/components/Img";
import { Mark, Check, Score } from "@/components/icons";
import { EvidenceStrip } from "@/components/EvidenceStrip";

export default function Home() {
  const feat = listings[0];
  const rail = listings.slice(1);
  const near = listings[0];
  return (
    <main className="page">
      <header className="hd">
        <Link href="/" className="lock"><Mark />OUTRUN <b>IQ</b></Link>
        <span className="sp" />
        <Link href="/zoeken" className="icbtn" aria-label="Zoeken">
          <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="6.5" /><path d="M20 20l-4.2-4.2" /></svg>
        </Link>
        <button className="icbtn" aria-label="Meldingen">
          <svg viewBox="0 0 24 24"><path d="M12 4a5 5 0 015 5v3l2 3H5l2-3V9a5 5 0 015-5zM10 19a2 2 0 004 0" /></svg>
          <span className="bub">3</span>
        </button>
      </header>

      <Link href={`/listing/${feat.id}`} className="feat">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={feat.img} alt="" />
        <span className="shade" />
        <span className="tag">DEAL VAN VANDAAG · AI-GEVERIFIEERD</span>
        <span className="save"><svg viewBox="0 0 24 24"><path d="M6 3h12v18l-6-4-6 4z" /></svg></span>
        <h3>{feat.title}</h3>
        <span className="stick">SLECHTS 1 STUK</span>
        <div className="strip">
          <div className="l1"><b>{eur(feat.price)}</b><s>{eur(feat.market)}</s><span className="d">−{feat.discount}%</span></div>
          <EvidenceStrip l={feat} labels={false} />
        </div>
      </Link>

      <div className="cats">
        <Link href="/zoeken?q=witgoed" className="cat c1"><i><svg viewBox="0 0 24 24"><rect x="7" y="3" width="10" height="18" rx="2" /><circle cx="12" cy="13" r="3.4" /></svg></i>Witgoed</Link>
        <Link href="/zoeken?q=meubels" className="cat c2"><i><svg viewBox="0 0 24 24"><path d="M4 12V9a2 2 0 012-2h12a2 2 0 012 2v3M4 12a2 2 0 00-2 2v3h20v-3a2 2 0 00-2-2M4 12h16" /></svg></i>Meubels</Link>
        <Link href="/zoeken?q=keukens" className="cat c3"><i><svg viewBox="0 0 24 24"><path d="M3 9h18v11H3zM3 9l2-5h14l2 5" /></svg></i>Keukens</Link>
        <Link href="/zoeken?q=tuin" className="cat c4"><i><svg viewBox="0 0 24 24"><path d="M12 3v4M5 14c0-4 3-7 7-7s7 3 7 7zM4 18h16" /></svg></i>Tuin</Link>
      </div>

      <div className="sec"><h2>Fast movers</h2><Link href="/zoeken">ALLES →</Link></div>
      <div className="rail">
        {rail.map(l => (
          <Link key={l.id} href={`/listing/${l.id}`} className="rc">
            <Img src={l.img} fallback={l.fallback}><Score v={l.score} /></Img>
            <span className="tx">
              <span className="t">{l.title}</span>
              <span className="p"><b>{eur(l.price)}{l.perUnit && "/st"}</b><span>−{l.discount}%</span></span>
            </span>
          </Link>
        ))}
      </div>

      <div className="sec"><h2>Dicht bij jou</h2><span className="mono">ROTTERDAM</span></div>
      <Link href={`/listing/${near.id}`} className="tick">
        <span className="top">
          <Img src={near.img} fallback={near.fallback} />
          <span>
            <span className="t">{near.title}</span>
            <span className="c">{near.condition}</span>
            <span className="s"><Check />{near.seller} · {near.km} km</span>
          </span>
        </span>
        <span className="perf" />
        <span className="bot">
          <span className="pr">{eur(near.price)}<s>markt {eur(near.market)}</s></span>
          <span className="d">−{near.discount}%</span>
          <span className="bars">{[9,16,6,19,11,15,7,18,10].map((h,i)=><i key={i} style={{height:h}} />)}</span>
        </span>
      </Link>
      <p className="note">Elke listing komt van een KvK-geverifieerd bedrijf. Je betaling staat in escrow tot je de levering bevestigt.</p>
    </main>
  );
}
