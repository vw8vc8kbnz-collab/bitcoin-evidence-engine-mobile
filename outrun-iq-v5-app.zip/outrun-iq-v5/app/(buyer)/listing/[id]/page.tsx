import Link from "next/link";
import { notFound } from "next/navigation";
import { byId, listings } from "@/lib/data";
import { ListingBody } from "@/components/ListingBody";

export function generateStaticParams() { return listings.map(l => ({ id: l.id })); }

export default async function ListingPage({ params }:{ params: Promise<{ id: string }> }) {
  const { id } = await params;
  const l = byId(id);
  if (!l) notFound();
  return (
    <main className="page" style={{ paddingBottom: 0 }}>
      <div className="media">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={l.img} alt={l.title} />
        <Link href="/" className="back2" aria-label="Terug">
          <svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7" /></svg>
        </Link>
        {l.defect && <span className="gebrek"><i />{l.defect}</span>}
        <span className="cnt">1 / 6</span>
      </div>
      <ListingBody l={l} />
    </main>
  );
}
