import Link from "next/link";
import { notFound } from "next/navigation";
import { byId, eur } from "@/lib/data";
import { Img } from "@/components/Img";

export default async function Checkout({ params }:{ params: Promise<{ id: string }> }) {
  const { id } = await params;
  const l = byId(id);
  if (!l) notFound();
  const total = l.price + l.deliveryPrice;
  return (
    <main className="page" style={{ paddingBottom: 170 }}>
      <header className="hd">
        <Link href={`/listing/${l.id}`} className="back">
          <svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7" /></svg>Terug
        </Link>
        <span className="sp" /><span className="mini">STAP 1 / 2</span>
      </header>
      <h1 className="h1big">Afrekenen</h1>
      <div style={{ height: 8 }} />
      <div className="oprod">
        <Img src={l.img} fallback={l.fallback} />
        <span><b>{l.title}</b><span>{l.seller} ✓</span></span>
        <span className="pr">{eur(l.price)}</span>
      </div>
      <div className="slabel">LEVERING</div>
      <div className="radios">
        <button className="rad on"><span className="o" /><span><b>{l.delivery}</b><span>via seller-partner</span></span><span className="p2">{l.deliveryPrice ? eur(l.deliveryPrice) : "Gratis"}</span></button>
        <button className="rad"><span className="o" /><span><b>Ophalen in {l.city}</b><span>vandaag mogelijk</span></span><span className="p2">Gratis</span></button>
      </div>
      <div className="slabel">BETALING</div>
      <div className="radios">
        <button className="rad on"><span className="o" /><span><b>iDEAL</b></span></button>
        <button className="rad"><span className="o" /><span><b>Apple Pay</b></span></button>
      </div>
      <div className="slabel">TOTAAL · GELD IN ESCROW TOT LEVERING</div>
      <div className="group"><div className="li"><b className="mono" style={{ fontSize: 19 }}>{eur(total)}</b><span className="val">incl. {eur(l.deliveryPrice)} levering</span></div></div>
      <p className="note">Je betaalt aan Outrun IQ, niet direct aan de seller. Wij betalen de seller pas uit nadat jij de levering bevestigt.</p>
      <div className="foot"><Link href={`/order/${l.id}`} className="btn pri">Betaal {eur(total)} — beschermd</Link></div>
    </main>
  );
}
