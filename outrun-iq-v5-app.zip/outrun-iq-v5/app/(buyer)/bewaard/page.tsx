import Link from "next/link";
import { listings, eur } from "@/lib/data";
import { Img } from "@/components/Img";
import { Mark, Check, Score } from "@/components/icons";

export default function Bewaard() {
  const saved = listings.slice(0, 3);
  return (
    <main className="page">
      <header className="hd">
        <Link href="/" className="lock"><Mark />OUTRUN <b>IQ</b></Link>
        <span className="sp" />
      </header>
      <h1 className="h1big">Bewaard</h1>
      <div className="count" style={{ marginTop: 4 }}>{saved.length} ITEMS · 1 PRIJSDALING</div>
      <div className="rows">
        {saved.map((l, i) => (
          <Link key={l.id} href={`/listing/${l.id}`} className="rowc">
            <Img src={l.img} fallback={l.fallback}><Score v={l.score} /></Img>
            <span className="tx">
              <span className="t">{l.title}</span>
              <span className="c">{l.condition}</span>
              <span className="s"><Check />{l.seller}</span>
              <span className="bot">
                <b>{eur(l.price)}{l.perUnit && "/st"}</b>
                {i === 0
                  ? <span className="d" style={{ background: "var(--ok-soft)", color: "var(--ok)" }}>↓ €50 SINDS BEWAARD</span>
                  : <span className="d">−{l.discount}%</span>}
              </span>
            </span>
          </Link>
        ))}
      </div>
      <p className="note">We houden de AI-prijs in de gaten: daalt een bewaard item, dan krijg je direct een melding.</p>
    </main>
  );
}
