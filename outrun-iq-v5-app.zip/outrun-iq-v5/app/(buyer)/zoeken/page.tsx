import Link from "next/link";
import { listings, eur } from "@/lib/data";
import { Img } from "@/components/Img";
import { Check, Score } from "@/components/icons";

export default async function Zoeken({ searchParams }:{
  searchParams: Promise<{ q?: string }>;
}) {
  const { q = "" } = await searchParams;
  const res = q
    ? listings.filter(l => (l.title + l.seller + l.condition).toLowerCase().includes(q.toLowerCase()))
    : listings;
  return (
    <main className="page">
      <header className="hd">
        <Link href="/" className="back" aria-label="Terug">
          <svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7" /></svg>
        </Link>
        <form action="/zoeken" className="srchbar">
          <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="6.5" /><path d="M20 20l-4.2-4.2" /></svg>
          <input name="q" defaultValue={q} placeholder="Zoek producten, merken of stores" autoComplete="off" />
        </form>
      </header>
      <div className="fbar">
        <span className="f on">Filters · 2</span><span className="f">Prijs ↓</span>
        <span className="f">&lt; 25 km</span><span className="f">Conditie 8+</span>
      </div>
      <div className="count">{res.length} RESULTATEN · SLIM GESORTEERD</div>
      <div className="rows">
        {res.map(l => (
          <Link key={l.id} href={`/listing/${l.id}`} className="rowc">
            <Img src={l.img} fallback={l.fallback}><Score v={l.score} /></Img>
            <span className="tx">
              <span className="t">{l.title}</span>
              <span className="c">{l.condition}</span>
              <span className="s"><Check />{l.seller}</span>
              <span className="bot"><b>{eur(l.price)}{l.perUnit && "/st"}</b><span className="d">−{l.discount}%</span><span className="km">{l.km} KM</span></span>
            </span>
          </Link>
        ))}
      </div>
    </main>
  );
}
