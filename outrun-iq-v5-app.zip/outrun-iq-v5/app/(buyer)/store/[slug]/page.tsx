import Link from "next/link";
import { notFound } from "next/navigation";
import { listings, stores, eur } from "@/lib/data";
import { Img } from "@/components/Img";
import { Check, Score } from "@/components/icons";

export default async function Store({ params }:{ params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const s = stores.find(x => x.slug === slug);
  if (!s) notFound();
  const items = listings.filter(l => l.sellerSlug === slug);
  return (
    <main className="page">
      <header className="hd">
        <Link href="/" className="back">
          <svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7" /></svg>Terug
        </Link>
      </header>
      <div className="sfprev" style={{ margin: "4px 16px 0" }}>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={s.img} alt="" />
        <span className="sh2" />
        <span className="in">
          <span className="av">{s.name.slice(0, 2).toUpperCase()}</span>
          <span><b>{s.name} ✓</b><span>TRUST {s.trust}/100 · {s.orders} ORDERS · {s.meta.toUpperCase()}</span></span>
        </span>
      </div>
      <div className="sec"><h2>Aanbod</h2><span className="mono">{items.length} LIVE</span></div>
      <div className="rows">
        {items.map(l => (
          <Link key={l.id} href={`/listing/${l.id}`} className="rowc">
            <Img src={l.img} fallback={l.fallback}><Score v={l.score} /></Img>
            <span className="tx">
              <span className="t">{l.title}</span>
              <span className="c">{l.condition}</span>
              <span className="s"><Check />{l.seller}</span>
              <span className="bot"><b>{eur(l.price)}{l.perUnit && "/st"}</b><span className="d">−{l.discount}%</span><span className="km">{l.km} KM</span></span>
            </span>
          </Link>
        ))}
      </div>
    </main>
  );
}
