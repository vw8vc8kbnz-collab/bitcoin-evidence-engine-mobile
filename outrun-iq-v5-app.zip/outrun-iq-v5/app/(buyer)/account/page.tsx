import Link from "next/link";
import { Mark, Chev } from "@/components/icons";

export default function Account() {
  return (
    <main className="page">
      <header className="hd">
        <Link href="/" className="lock"><Mark />OUTRUN <b>IQ</b></Link>
        <span className="sp" />
      </header>
      <h1 className="h1big">Account</h1>
      <div className="seg">
        <Link href="/account" className="on">Kopen</Link>
        <Link href="/seller">Verkopen</Link>
      </div>
      <div className="prof">
        <span className="av">SV</span>
        <span><b>Stijn</b><span>lid sinds 2026</span></span>
        <span className="badge">✓ GEVERIFIEERD</span>
      </div>
      <div className="slabel">ACTIEF</div>
      <div className="group">
        <Link href="/order/bosch-serie-6-9kg" className="li"><span className="icb"><svg viewBox="0 0 24 24"><path d="M5 4h14v16l-3-2-2 2-2-2-2 2-2-2-3 2zM9 9h6M9 13h6" /></svg></span><b>Bestellingen</b><span className="nbadge">2</span><Chev /></Link>
        <button className="li"><span className="icb am"><svg viewBox="0 0 24 24"><path d="M12 3v18M7 8l5-5 5 5M5 21h14" /></svg></span><b>Biedingen<small>1 wacht op reactie seller</small></b><span className="nbadge am">1</span><Chev /></button>
        <Link href="/bewaard" className="li"><span className="icb"><svg viewBox="0 0 24 24"><path d="M6 3h12v18l-6-4-6 4z" /></svg></span><b>Bewaard</b><span className="val">3</span><Chev /></Link>
        <button className="li"><span className="icb"><svg viewBox="0 0 24 24"><path d="M12 4a5 5 0 015 5v3l2 3H5l2-3V9a5 5 0 015-5zM10 19a2 2 0 004 0" /></svg></span><b>Zoek-alerts<small>wasmachine &lt; €600 · hoekbank</small></b><span className="val">3</span><Chev /></button>
      </div>
      <div className="slabel">GEGEVENS</div>
      <div className="group">
        <button className="li"><span className="icb"><svg viewBox="0 0 24 24"><circle cx="12" cy="8.5" r="3.5" /><path d="M5 19c1.2-3 4-4.5 7-4.5s5.8 1.5 7 4.5" /></svg></span><b>Persoonlijk &amp; adressen</b><Chev /></button>
        <button className="li"><span className="icb"><svg viewBox="0 0 24 24"><rect x="3" y="6" width="18" height="13" rx="2" /><path d="M3 10h18" /></svg></span><b>Betaalmethoden<small>iDEAL · Apple Pay</small></b><Chev /></button>
        <button className="li"><span className="icb"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8" /><path d="M12 8v4l3 2" /></svg></span><b>Notificaties</b><span className="val" style={{ color: "var(--ok)", fontWeight: 600 }}>Aan</span><Chev /></button>
      </div>
    </main>
  );
}
