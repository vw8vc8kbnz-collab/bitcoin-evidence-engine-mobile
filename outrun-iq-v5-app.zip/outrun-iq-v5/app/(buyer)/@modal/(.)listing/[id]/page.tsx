import { notFound } from "next/navigation";
import { byId } from "@/lib/data";
import { BottomSheet } from "@/components/BottomSheet";
import { ListingBody } from "@/components/ListingBody";

/** Intercepting route: listing opent als overlay-sheet óver het grid, mét eigen URL. */
export default async function ListingModal({ params }:{ params: Promise<{ id: string }> }) {
  const { id } = await params;
  const l = byId(id);
  if (!l) notFound();
  return (
    <BottomSheet>
      <div className="media" style={{ height: 210 }}>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={l.img} alt={l.title} />
        {l.defect && <span className="gebrek"><i />{l.defect}</span>}
        <span className="cnt">1 / 6</span>
      </div>
      <ListingBody l={l} />
    </BottomSheet>
  );
}
