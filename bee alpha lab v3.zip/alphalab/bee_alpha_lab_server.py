#!/usr/bin/env python3
"""
BEE Alpha Lab — backend webserver.

Draait op de VPS naast de daemon. Serveert de HTML-frontend en rekent ECHTE
walk-forward validaties op de gestapelde CSV. Pure stdlib + pandas/numpy
(geen Flask/FastAPI nodig — minder dependencies, makkelijker te installeren).

Beveiliging: simpel token in de URL (?key=...). Niet bankwaardig, maar genoeg
om te voorkomen dat willekeurige mensen je CPU gebruiken. De data is publiek
(marktdata), er staat geen geld of geheim in.

Start: python bee_alpha_lab_server.py
Open:  http://<vps-ip>:8000/?key=<token>
"""
import json
import os
import http.server
import socketserver
from urllib.parse import urlparse, parse_qs

import pandas as pd
import numpy as np

# ---- Config ----
PORT = int(os.environ.get("ALPHA_LAB_PORT", "8000"))
ACCESS_KEY = os.environ.get("ALPHA_LAB_KEY", "bee-change-me")
CSV_PATH = os.environ.get(
    "ALPHA_LAB_CSV",
    "/home/ubuntu/bitcoin-engine-deploy/current/data/BTC_alle_lagen_gecombineerd.csv",
)
FEE_ROUNDTRIP_PCT = 0.10
HTML_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "bee_alpha_lab.html")

# ---- Data eenmalig laden ----
_DF = None
def load_data():
    global _DF
    if _DF is not None:
        return _DF
    path = CSV_PATH
    if not os.path.exists(path) and os.path.exists(path + ".gz"):
        path = path + ".gz"
    df = pd.read_csv(path)
    # robuuste dt-parsing + chronologisch sorteren (de les van de sorteerbug!)
    df["dt"] = pd.to_datetime(df["dt"], utc=True, errors="coerce")
    df = df.sort_values("dt").reset_index(drop=True)
    df["year"] = df["dt"].dt.year
    _DF = df
    return df

# ---- Signaal-definities (de techniek-database, server-kant) ----
def build_daily(df):
    d = df[df["dt"].dt.hour == 0].copy().sort_values("dt").reset_index(drop=True)
    d["ma24"] = d["close"].rolling(24).mean() if "close" in d else None
    return d

def col(df, *names):
    for n in names:
        if n in df.columns:
            return n
    return None

def compute_signal(d, technique, direction, filters):
    """Retourneert boolean Series: wanneer vuurt de setup."""
    close = col(d, "close", "close_raw")
    low = col(d, "low")
    high = col(d, "high")
    fg = col(d, "fear_greed")
    funding = col(d, "funding_rate")
    prem = col(d, "coinbase_premium_pct")
    rsi = col(d, "rsi_14")

    c = d[close]
    sig = pd.Series(False, index=d.index)

    if technique == "capitulation_sweep":
        prior_low = d[low].rolling(10).min().shift(1) if low else c.rolling(10).min().shift(1)
        sig = (d[low] < prior_low) if low else (c < prior_low)
    elif technique == "mean_rev_ma24":
        ma = c.rolling(24).mean()
        dev = (c / ma - 1) * 100
        sig = dev < -5
    elif technique == "cb_premium":
        sig = d[prem] > 0.1 if prem else sig
    elif technique == "fear_dip_buy":
        ret1 = c.pct_change() * 100
        sig = (ret1 < -3) & (d[fg] < 25) if fg else sig
    elif technique == "cycle_reversal":
        sig = (d[fg] < 30) if fg else sig
    elif technique == "euphoria_short":
        ma = c.rolling(50).mean()
        ext = (c / ma - 1) * 100
        sig = (d[fg] > 75) & (ext > 10) if fg else sig
    elif technique == "rsi_oversold":
        sig = (d[rsi] < 30) if rsi else sig
    else:
        sig = (d[fg] < 35) if fg else sig

    # confluence-filters
    if "neg_funding" in filters and funding:
        sig = sig & (d[funding] < 0)
    if "fear_ctx" in filters and fg:
        sig = sig & (d[fg] < 45)
    if "cb_premium" in filters and prem:
        sig = sig & (d[prem] > 0.0)
    if "ema200" in filters:
        ma200 = c.rolling(200).mean()
        sig = sig & (c > ma200)
    if "rsi_div" in filters and rsi:
        sig = sig & (d[rsi] < 40)
    return sig.fillna(False)

def fwd_return(d, horizon):
    close = col(d, "close", "close_raw")
    steps = {"4h": None, "8h": None, "1d": 1, "7d": 7, "14d": 14, "30d": 30}.get(horizon, 7)
    if steps is None:
        steps = 1
    return (d[close].shift(-steps) / d[close] - 1) * 100

def dedup(sub, col_name, gap_days):
    ot = col(sub, "open_time")
    sub = sub.dropna(subset=[col_name]).sort_values("dt")
    if ot is None:
        return sub[col_name].reset_index(drop=True)
    last = -1e18
    kept = []
    for _, r in sub.iterrows():
        if r[ot] - last >= gap_days * 86400 * 1000:
            kept.append(r[col_name])
            last = r[ot]
    return pd.Series(kept)

def run_validation(technique, direction, tf, horizon, filters):
    df = load_data()
    d = df[df["dt"].dt.hour == 0].copy().sort_values("dt").reset_index(drop=True)
    sig = compute_signal(d, technique, direction, filters)
    d = d.assign(_sig=sig)
    d["_fwd"] = fwd_return(d, horizon)

    gap = {"1d": 5, "7d": 7, "14d": 14, "30d": 30}.get(horizon, 7)

    # SHORT: win = return < 0; pnl = -return
    is_short = direction == "short"

    # walk-forward per testjaar
    wf = []
    per_year = {}
    years = sorted([y for y in d["year"].dropna().unique() if y >= 2019])
    for ty in years:
        if ty < 2020:
            continue
        train = d[d["year"] < ty]
        if train["_sig"].sum() < 3:
            continue
        test = d[d["_sig"] & (d["year"] == ty)]
        kept = dedup(test, "_fwd", gap)
        if len(kept) >= 1:
            pnl = (-kept if is_short else kept) - FEE_ROUNDTRIP_PCT
            wf.extend(pnl.tolist())
            per_year[int(ty)] = {
                "n": int(len(kept)),
                "net_avg": round(float(pnl.mean()), 2),
                "win": round(float((pnl > 0).mean() * 100), 1),
            }

    # overlap-gecorrigeerd totaal
    allsig = d[d["_sig"]]
    keptall = dedup(allsig, "_fwd", gap)
    base = d.dropna(subset=["_fwd"])["_fwd"]
    base_mean = float((-base if is_short else base).mean())
    result = {"per_year": per_year}
    if len(keptall) > 0:
        pnl_all = (-keptall if is_short else keptall) - FEE_ROUNDTRIP_PCT
        result["overall"] = {
            "n_independent": int(len(keptall)),
            "net_avg": round(float(pnl_all.mean()), 2),
            "win": round(float((pnl_all > 0).mean() * 100), 1),
            "baseline": round(base_mean, 2),
            "edge": round(float(pnl_all.mean() - base_mean), 2),
        }
    else:
        result["overall"] = {"n_independent": 0, "net_avg": 0, "win": 0, "baseline": round(base_mean,2), "edge": 0}
    if wf:
        wfs = pd.Series(wf)
        result["walk_forward"] = {
            "n": int(len(wfs)),
            "net_avg": round(float(wfs.mean()), 2),
            "win": round(float((wfs > 0).mean() * 100), 1),
        }
    else:
        result["walk_forward"] = {"n": 0, "net_avg": 0, "win": 0}

    # eerlijk verdict
    ov = result["overall"]
    wfr = result["walk_forward"]
    verdict, reason = "AFGEKEURD", ""
    if wfr["n"] < 10:
        verdict, reason = "TE WEINIG DATA", f"Slechts {wfr['n']} onafhankelijke OOS-trades. Te klein om te vertrouwen."
    elif wfr["net_avg"] <= 0:
        verdict, reason = "AFGEKEURD", "Geen positieve edge na fees in de echte walk-forward."
    elif ov["edge"] <= 0:
        verdict, reason = "AFGEKEURD", "Verslaat de baseline niet."
    elif wfr["win"] < 52:
        verdict, reason = "ZWAK", f"Winrate {wfr['win']}% nauwelijks boven coinflip."
    else:
        verdict, reason = "ECHTE EDGE", f"Walk-forward OOS: {wfr['net_avg']}% per trade na fees, {wfr['win']}% win over {wfr['n']} trades."
    result["verdict"] = verdict
    result["reason"] = reason
    return result

def robustness_score(per_year, walk_forward, overall, n_filters):
    """Rangschikt NIET op hoogste rendement, maar op betrouwbaarheid.
       De winnaar is een edge die overal ongeveer hetzelfde doet, niet eentje
       die op een paar toevallige trades in een goudjaar drijft."""
    years = [v for v in per_year.values() if v.get("n", 0) >= 1]
    if not years:
        return {"score": 0, "verdict": "GEEN DATA", "flags": ["geen signalen"],
                "frac_years_positive": 0, "max_year_contribution": 0, "year_spread_std": 0}
    flags = []
    pos_years = sum(1 for y in years if y["net_avg"] > 0)
    frac_pos = pos_years / len(years)
    thin_years = sum(1 for y in years if y["n"] < 4)
    frac_thin = thin_years / len(years)
    avgs = [y["net_avg"] for y in years]
    total_pos = sum(a for a in avgs if a > 0) or 1e-9
    max_contrib = max((a for a in avgs if a > 0), default=0) / total_pos
    mean_a = sum(avgs) / len(avgs)
    std_a = (sum((a - mean_a) ** 2 for a in avgs) / len(avgs)) ** 0.5
    n_oos = walk_forward.get("n", 0)
    score = 0
    score += frac_pos * 35
    score += min(n_oos, 40) / 40 * 25
    score += (1 - frac_thin) * 15
    score += (1 - min(max_contrib, 1)) * 15
    score += max(0, 1 - std_a / 10) * 10
    score -= n_filters * 4
    score = max(0, min(100, round(score, 1)))
    if frac_pos < 0.7: flags.append("niet elk jaar positief")
    if frac_thin > 0.4: flags.append(f"{thin_years} jaar met <4 trades (dun)")
    if max_contrib > 0.5: flags.append("winst geconcentreerd in een jaar")
    if n_oos < 15: flags.append(f"kleine totale sample (n={n_oos})")
    if n_filters >= 3: flags.append(f"{n_filters} filters gestapeld (overfit-risico)")
    if score >= 65 and not flags:
        verdict = "ROBUUST"
    elif score >= 65:
        verdict = "ROBUUST (met kanttekening)"
    elif score >= 45:
        verdict = "WANKEL"
    else:
        verdict = "FRAGIEL / TOEVAL"
    return {"score": score, "verdict": verdict, "flags": flags,
            "frac_years_positive": round(frac_pos, 2),
            "max_year_contribution": round(max_contrib, 2),
            "year_spread_std": round(std_a, 2)}


def rank_all_combinations(min_trades=10, min_win=0, min_robust=0, max_filters=3):
    """Doorzoekt de combinatie-ruimte met INSTELBARE drempels en rangschikt op
       ROBUUSTHEID (niet op hoogste rendement). De drempels (min_trades, min_win)
       zijn een bescherming: alleen combinaties met genoeg sample en winrate
       komen door. Resultaat blijft op betrouwbaarheid gesorteerd."""
    import itertools
    techniques = ["capitulation_sweep", "mean_rev_ma24", "cb_premium",
                  "fear_dip_buy", "cycle_reversal", "rsi_oversold"]
    horizons = ["1d", "7d", "14d", "30d"]
    all_filters = ["neg_funding", "fear_ctx", "cb_premium", "ema200", "rsi_div"]
    # alle filtercombinaties tot max_filters
    filtersets = []
    for k in range(0, max_filters + 1):
        for combo in itertools.combinations(all_filters, k):
            filtersets.append(list(combo))

    results = []
    for tech in techniques:
        for hor in horizons:
            for fs in filtersets:
                try:
                    r = run_validation(tech, "long", "1d", hor, fs)
                    wf = r.get("walk_forward", {})
                    n = wf.get("n", 0)
                    win = wf.get("win", 0)
                    # DREMPELS toepassen (de filter die de gebruiker instelt)
                    if n < min_trades:
                        continue
                    if win < min_win:
                        continue
                    rob = robustness_score(r.get("per_year", {}), wf,
                                           r.get("overall", {}), len(fs))
                    if rob["score"] < min_robust:
                        continue
                    results.append({
                        "technique": tech, "horizon": hor, "filters": fs,
                        "robustness": rob["score"], "rob_verdict": rob["verdict"],
                        "flags": rob["flags"],
                        "wf_win": win, "wf_net": wf.get("net_avg", 0), "wf_n": n,
                        "edge": r.get("overall", {}).get("edge", 0),
                    })
                except Exception:
                    continue
    # sorteer op ROBUUSTHEID, niet op rendement
    results.sort(key=lambda x: x["robustness"], reverse=True)
    return results




class Handler(http.server.BaseHTTPRequestHandler):
    def _auth_ok(self, qs):
        return qs.get("key", [""])[0] == ACCESS_KEY

    def do_GET(self):
        parsed = urlparse(self.path)
        qs = parse_qs(parsed.query)

        if parsed.path == "/" or parsed.path == "/index.html":
            if not self._auth_ok(qs):
                self.send_response(401)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.end_headers()
                self.wfile.write(b"<h2>Toegang geweigerd</h2><p>Voeg ?key=JOUW_TOKEN toe aan de URL.</p>")
                return
            try:
                with open(HTML_PATH, "rb") as f:
                    body = f.read()
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.end_headers()
                self.wfile.write(body)
            except FileNotFoundError:
                self.send_response(500); self.end_headers()
                self.wfile.write(b"frontend html niet gevonden")
            return

        if parsed.path == "/api/validate":
            if not self._auth_ok(qs):
                self.send_response(401); self.end_headers(); return
            try:
                technique = qs.get("technique", ["capitulation_sweep"])[0]
                direction = qs.get("direction", ["long"])[0]
                tf = qs.get("tf", ["1d"])[0]
                horizon = qs.get("horizon", ["7d"])[0]
                filters = qs.get("filters", [""])[0].split(",") if qs.get("filters", [""])[0] else []
                result = run_validation(technique, direction, tf, horizon, filters)
                body = json.dumps(result).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(body)
            except Exception as e:
                self.send_response(500)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps({"error": str(e)}).encode())
            return

        if parsed.path == "/api/rank":
            if not self._auth_ok(qs):
                self.send_response(401); self.end_headers(); return
            try:
                min_trades = int(qs.get("min_trades", ["25"])[0])
                min_win = float(qs.get("min_win", ["0"])[0])
                min_robust = float(qs.get("min_robust", ["0"])[0])
                max_filters = int(qs.get("max_filters", ["3"])[0])
                ranked = rank_all_combinations(min_trades, min_win, min_robust, max_filters)
                body = json.dumps({
                    "ranked": ranked,
                    "n_passed": len(ranked),
                    "thresholds": {"min_trades": min_trades, "min_win": min_win,
                                   "min_robust": min_robust, "max_filters": max_filters},
                }).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(body)
            except Exception as e:
                self.send_response(500)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps({"error": str(e)}).encode())
            return

        self.send_response(404); self.end_headers()

    def log_message(self, *a):
        pass  # stil


if __name__ == "__main__":
    print(f"Loading data from {CSV_PATH} ...")
    try:
        n = len(load_data())
        print(f"Loaded {n} rows.")
    except Exception as e:
        print(f"WAARSCHUWING: data laden faalde: {e}")
    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer(("0.0.0.0", PORT), Handler) as httpd:
        print(f"Alpha Lab server op poort {PORT}. Open http://<vps-ip>:{PORT}/?key={ACCESS_KEY}")
        httpd.serve_forever()
