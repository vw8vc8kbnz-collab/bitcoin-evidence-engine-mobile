# Outrun IQ v8.4.9

Flat SAFE deployment build.

Deze versie corrigeert de resterende buyer UX-punten uit v8.4.8:
producttegels, image lightbox teruggedrag, productmodal bottom spacing en navigatiebar-polish.
