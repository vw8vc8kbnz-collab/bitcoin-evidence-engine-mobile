# Outrun IQ v8.4.9 — Image, Navigation & Bottom Sheet Polish

Correctiebuild bovenop v8.4.8.

## Gefixt
- Home compact producttegels: tekst valt niet meer onder score/media-overlay.
- Compacte railcards hebben nu vaste card-hoogte en een stabiele grid-layout.
- Productfoto's blijven gecentreerd en `contain`, maar zonder dat titels onder de foto verdwijnen.
- Productfoto-lightbox gebruikt nu een eigen history-state: browser-terug sluit eerst de foto en laat het product open.
- Productmodal heeft extra bottom padding zodat koop-/bodknoppen niet onder de bottom navigation of Safari chrome verdwijnen.
- Sticky buy bar in productmodal staat hoger boven de buyer dock.
- Buyer dock/AI Vinder knop visueel beter gecentreerd en duidelijker geplaatst.

## Niet veranderd
- Finance/wallet hardening blijft intact.
- Buyer AI Brain en discovery-ranking blijven intact.
- Geen wijziging aan payment-live gedrag; test/preview blijft veilig.
