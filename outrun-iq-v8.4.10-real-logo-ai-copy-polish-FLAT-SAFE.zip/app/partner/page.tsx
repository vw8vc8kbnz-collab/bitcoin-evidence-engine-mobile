import Link from "next/link";
import { read } from "@/lib/store";
import { getUser } from "@/lib/auth";
import { sweepOrders } from "@/lib/data";
import { getSellerStats, eur, unreadCount } from "@/lib/data";
import { Mark } from "@/components/icons";
import { Img } from "@/components/Img";
import { Empty } from "@/components/Empty";

export const dynamic = "force-dynamic";


function partnerDealScore(l: any) {
  const discount = l.newPrice > 0 ? Math.max(0, Math.min(45, ((l.newPrice - l.price) / l.newPrice) * 100)) : 12;
  const stockBoost = Math.min(12, (l.stock || 0) * 3);
  const viewBoost = l.views < 25 ? 14 : l.views < 80 ? 7 : 0;
  return Math.max(38, Math.min(97, Math.round(40 + discount * 0.66 + (l.conditionScore || 6) * 2.2 + stockBoost + viewBoost)));
}

function partnerNextAction(l: any) {
  const score = partnerDealScore(l);
  if (l.views < 25 && score > 72) return { label: "Promoten", text: "Goede deal maar nog weinig bereik. Start met €10–€25 per dag.", href: "/partner/promoten" };
  if (score < 68) return { label: "Verbeter prijs", text: "AI ziet ruimte om prijs, titel of foto te verbeteren vóór promotie.", href: `/partner/voorraad` };
  if ((l.stock || 0) <= 1) return { label: "Laatste stuk", text: "Zet schaarste sterker in en houd promotie klein.", href: "/partner/promoten" };
  return { label: "Monitoren", text: "Organisch bereik lijkt voldoende. Laat AI eerst doormeten.", href: "/partner/voorraad" };
}

function sparkPath(daily: number[]): string {
  const max = Math.max(...daily, 1);
  const pts = daily.map((v, i) => [i * (280 / 29), 40 - (v / max) * 34] as const);
  return "M" + pts.map(([x, y]) => `${x.toFixed(1)},${y.toFixed(1)}`).join(" L");
}

export default async function SellerDash() {
  await sweepOrders();
  const db = await read();
  const user = await getUser();
  const seller = db.sellers.find(x => x.slug === user?.partnerSlug);
  const unread = user ? await unreadCount(user.id) : 0;
  const stats = seller ? await getSellerStats(seller.slug) : null;
  const openOrders = (stats?.orders ?? []).filter(o => !["paid_out", "cancelled"].includes(o.status));
  const activeListings = db.listings.filter(l => l.sellerSlug === seller?.slug && l.status === "active");
  const coachItems = activeListings.map(l => ({ listing: l, score: partnerDealScore(l), action: partnerNextAction(l) })).sort((a, b) => (b.action.label === "Promoten" ? 20 : 0) + b.score - ((a.action.label === "Promoten" ? 20 : 0) + a.score)).slice(0, 3);
  const topCoach = coachItems[0];

  return (
    <main className="page partnerScreen partnerDash">
      <header className="hd">
        <Link href="/partner" className="lock" style={{ color: "#fff" }}><Mark glow />PARTNER <b>HUB</b></Link>
        <span className="sp" />
        <Link href="/meldingen" className="icbtn" aria-label="Meldingen">
          <svg viewBox="0 0 24 24"><path d="M6 10a6 6 0 1112 0c0 4 1.5 5.5 1.5 5.5h-15S6 14 6 10z" /><path d="M10.5 19a1.8 1.8 0 003 0" /></svg>
          {unread > 0 && <span className="bub">{unread > 9 ? "9+" : unread}</span>}
        </Link>
        <Link href="/partner/storefront" className="icbtn" aria-label="Storefront en instellingen">
          <svg viewBox="0 0 24 24"><rect x="4" y="4" width="16" height="16" rx="3" /><path d="M4 10h16M10 10v10" /></svg>
        </Link>
        <Link href="/partner/orders" className="icbtn" aria-label="Orders">
          <svg viewBox="0 0 24 24"><path d="M5 4h14v16l-3-2-2 2-2-2-2 2-2-2-3 2z" /></svg>
        </Link>
      </header>

      {!seller && (
        <>
          <Empty
            title="Welkom in de Partner Hub"
            text="Je partneraccount is actief. Plaats je eerste listing — de AI doet het prijswerk."
          />
          <div className="foot"><Link href="/partner/nieuw" className="btn pri">+ Eerste listing plaatsen</Link></div>
        </>
      )}

      {seller && stats && (
        <>
          <section className="aiPartnerCoachHero">
            <span className="eyebrow">AI PARTNER COACH</span>
            <h1>{topCoach ? "Eerstvolgende beste actie" : "AI staat klaar voor je eerste listing"}</h1>
            <p>{topCoach ? `${topCoach.listing.title}: ${topCoach.action.text}` : "Plaats je eerste product. Outrun berekent daarna deal-score, prijsadvies, promotiekans en cashflow-impact."}</p>
            <div className="coachHeroRow">
              <span><b>{topCoach?.score ?? 0}</b><small>Deal score</small></span>
              <span><b>{coachItems.filter(x => x.action.label === "Promoten").length}</b><small>Promote kansen</small></span>
              <span><b>{openOrders.length}</b><small>Actie nodig</small></span>
            </div>
            <div className="coachHeroActions">
              <Link href={topCoach?.action.href ?? "/partner/nieuw"} className="btn pri">{topCoach?.action.label ?? "+ Listing plaatsen"}</Link>
              <Link href="/partner/promoten" className="btn ghost">Open Promoten</Link>
            </div>
          </section>

          {coachItems.length > 0 && (
            <section className="coachActionStack">
              <div className="dsec"><h2>Producten die aandacht nodig hebben</h2><span>AI PRIORITEIT</span></div>
              {coachItems.map(({ listing, score, action }) => (
                <Link key={listing.id} href={action.href} className="coachActionCard">
                  <span className="coachScore">{score}</span>
                  <span><b>{listing.title}</b><small>{action.text}</small></span>
                  <em>{action.label} →</em>
                </Link>
              ))}
            </section>
          )}

          <section className="partnerHero"><div className="big"><label>UITBETAALD · LAATSTE 30 DAGEN</label>
            <b>{eur(stats.rev30)}</b></div>
          <svg className="spark" height="44" viewBox="0 0 280 44" preserveAspectRatio="none" aria-hidden>
            <path d={sparkPath(stats.daily)} fill="none" stroke="#35A9AC" strokeWidth="2" />
            <circle cx="280" cy={40 - (stats.daily[29] / Math.max(...stats.daily, 1)) * 34} r="3.4" fill="#E9A13B" />
          </svg></section>
          <div className="dkchips partnerMetricGrid">
            <span className="dkc"><label>LIVE LISTINGS</label><b>{stats.activeCount}</b></span>
            <span className="dkc"><label>SELL-THROUGH</label><b>{stats.sellThrough}%</b></span>
            <span className="dkc"><label>IN ESCROW</label><b>{eur(stats.inEscrowSum)}</b></span>
          </div>
          {(!seller.support?.email || !seller.logo) && (
            <Link href="/partner/storefront" className="act actionCard">
              <span className="n2">!</span>
              <span><b>Maak je storefront af</b><span>{!seller.support?.email ? "klantenservicegegevens verplicht vóór publiceren" : "voeg je logo toe — bouwt vertrouwen"}</span></span>
              <span className="go">OPEN →</span>
            </Link>
          )}
          {openOrders.length > 0 && (
            <Link href="/partner/orders" className="act actionCard">
              <span className="n2">{openOrders.length}</span>
              <span><b>{openOrders.length === 1 ? "Order wacht op actie" : "Orders wachten op actie"}</b><span>bevestig of plan de levering</span></span>
              <span className="go">OPEN →</span>
            </Link>
          )}
          <div className="dsec"><h2>Laatste orders</h2><span>{stats.orders.length} TOTAAL</span></div>
          {stats.orders.length === 0 && (
            <p className="note">Nog geen orders. Zodra een koper een testorder plaatst, verschijnt hij hier.</p>
          )}
          {[...stats.orders].reverse().slice(0, 4).map(o => {
            const l = db.listings.find(x => x.id === o.listingId);
            return (
              <div key={o.id} className="orow orderCard">
                <Img src={l?.photos[0]} fallback={l?.fallback ?? "tv"} dark />
                <span><b>{o.itemTitle}</b><span>{o.id} · {o.status.replaceAll("_", " ").toUpperCase()}</span></span>
                <span className="amt">{eur(o.sellerNet)}<i className={o.status === "paid_out" ? "esc" : "esc"} style={o.status === "paid_out" ? { color: "#4CBE8B" } : undefined}>{o.status === "paid_out" ? "UITBETAALD" : "IN ESCROW"}</i></span>
              </div>
            );
          })}
        </>
      )}
    </main>
  );
}
