# AlgoRoute v0.6.1 Desktop View Lock

```bash
cd /home/ubuntu

rm -rf algoroute_latest
rm -f algoroute_v0_6_1_DESKTOP_VIEW.zip

wget -O /home/ubuntu/algoroute_v0_6_1_DESKTOP_VIEW.zip \
"https://raw.githubusercontent.com/vw8vc8kbnz-collab/bitcoin-evidence-engine-mobile/main/algoroute_v0_6_1_DESKTOP_VIEW.zip"

mkdir -p /home/ubuntu/algoroute_latest
unzip -o /home/ubuntu/algoroute_v0_6_1_DESKTOP_VIEW.zip -d /home/ubuntu/algoroute_latest

cd /home/ubuntu/algoroute_latest/algoroute_v0_6_1_desktop_view 2>/dev/null || cd /home/ubuntu/algoroute_latest

chmod +x scripts/install.sh
sudo ./scripts/install.sh

sudo ufw allow 8787/tcp || true
sudo docker compose down --remove-orphans || true
sudo docker rm -f algoroute-api algoroute-web algoroute-nginx 2>/dev/null || true
sudo docker compose up -d --build --force-recreate

sudo docker compose ps
curl -I http://localhost:8787/
curl http://localhost:8787/api/health
```

Open: http://51.195.102.180:8787/
