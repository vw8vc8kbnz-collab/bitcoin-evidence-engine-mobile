# AlgoRoute v0.6.1 Desktop View Lock

Deze versie behoudt de volledige desktop cockpit op iPhone/iPad. De responsive mobile layout is uitgezet voor de planner-cockpit zodat je horizontaal kunt schuiven en exact de desktop-indeling ziet.

Bevat v0.6 Vehicle Core + desktop canvas fix.
