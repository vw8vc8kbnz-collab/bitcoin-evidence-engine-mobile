Bitcoin Evidence Engine v10.16.21 - Stable UI + Evidence Status

Belangrijkste fixes:
- Mobile Home/Machine gebruiken nu eerst /api/mobile/status-fast en vallen terug op /api/health.
- Data/evidence-status wordt apart geladen zodat trage externe backfill de app niet meer rood zet.
- Status-kaarten blijven gekoppeld aan de echte persistente DuckDB-tabellen in /home/ubuntu/bitcoin_evidence_data.
- Time Machine export bevat evidence_data_status.csv/json zodat altijd zichtbaar is welke data echt actief is.
- Proxy/afgeleide modellen blijven auditable; externe data telt alleen als actief als er echte rijen in raw_metric_points/features staan.

Te testen na update:
1. Open Home: 70.000+ candles moet direct uit /api/health zichtbaar zijn.
2. Machine: Reset TM -> Random1000.
3. Tests moeten 7000 worden; snapshots/signals mogen kort later oplopen.
4. Download ZIP en stuur hem voor audit.

Volgende inhoudelijke stap blijft: echte lange historische futures/OI/funding/liquidation/cross-exchange/on-chain backfill verder vullen.
