const $ = (id)=>document.getElementById(id);
// V10.16.23: fast mobile boot. First paint is instant; quick heartbeat loads first; heavy evidence/chart load later.
function authHeaders(){ return {}; }
const fmtUsd = (v)=> v==null || isNaN(v) ? '—' : '$' + Number(v).toLocaleString('nl-NL',{maximumFractionDigits:0});
const fmtPct = (v)=> v==null || isNaN(v) ? '—' : (Number(v)*100).toFixed(1)+'%';
const fmtTs = (ms)=> ms ? new Date(Number(ms)).toLocaleDateString('nl-NL',{day:'2-digit',month:'2-digit',year:'2-digit'}) : '—';
let installPrompt=null;
window.addEventListener('beforeinstallprompt', (e)=>{ e.preventDefault(); installPrompt=e; $('installBtn').hidden=false; });
function toast(msg){ const t=$('toast'); if(!t) return; t.textContent=msg; t.hidden=false; clearTimeout(window.__toastTimer); window.__toastTimer=setTimeout(()=>t.hidden=true,3600); }
function hideBoot(){ const b=document.getElementById('bootSplash'); if(b){ b.classList.add('hide'); setTimeout(()=>{ try{b.remove()}catch(e){} },350); } }
function safeSet(id, value){ const el=$(id); if(el) el.textContent=value; }
function applyQuick(data){
  if(!data) return;
  setApi(data.sync_busy?'loading':'ok', data.sync_busy?'bezig':'online');
  safeSet('versionLabel', data.engine_version||'v10.16.23-fast-boot-mobile-ui');
  safeSet('priceLabel', fmtUsd(data.btc_price));
  const rows=Number(data.raw_candles || (data.candle_range&&data.candle_range.rows) || 0); const target=Number(data.target_rows||70000);
  const pct=Math.min(100, target?rows/target*100:0);
  safeSet('historyPct', pct.toFixed(1)+'%'); safeSet('historyRows', `${rows.toLocaleString('nl-NL')} / ${target.toLocaleString('nl-NL')} candles`); if($('historyBar')) $('historyBar').style.width=pct+'%';
  safeSet('nativeState', (data.native_available||data.native_core_available)?'Actief':'Check'); safeSet('nativeDetail', (data.native_available||data.native_core_available)?'C++ cloud core OK':'C++ check loopt');
  const tm=data.learning||{}; safeSet('tmTests', Number(tm.time_machine_tests||data.time_machine_tests||0).toLocaleString('nl-NL')); safeSet('tmSnapshots', Number(tm.feature_snapshots||data.time_machine_feature_snapshots||0).toLocaleString('nl-NL')); safeSet('tmSignals', Number(tm.signal_events||data.time_machine_signal_scores||0).toLocaleString('nl-NL'));
  safeSet('dataRows', rows.toLocaleString('nl-NL'));
  if(data.raw_candles_min_ms || data.raw_candles_max_ms){ safeSet('dataRange', `${fmtTs(data.raw_candles_min_ms)} → ${fmtTs(data.raw_candles_max_ms)}`); }
  hideBoot();
}

async function api(path, opts={}){
  const attempts=opts.attempts||1; let lastErr=null;
  for(let a=0;a<attempts;a++){
    const useTimeout=opts.timeout!==0; const ctrl=useTimeout?new AbortController():null; const to=useTimeout?setTimeout(()=>ctrl.abort(), opts.timeout||45000):null;
    try{
      const clean={...opts}; delete clean.timeout; delete clean.attempts;
      const r=await fetch(path,{...clean, signal:ctrl?ctrl.signal:undefined, headers:{'Content-Type':'application/json',...authHeaders(),...(opts.headers||{})}, cache:'no-store'});
      if(!r.ok) throw new Error('HTTP '+r.status);
      return await r.json();
    }catch(e){ lastErr=e; if(a<attempts-1) await new Promise(r=>setTimeout(r, 1200*(a+1))); }
    finally{ if(to) clearTimeout(to); }
  }
  throw lastErr || new Error('request failed');
}
function setApi(state,msg){ const dot=$('apiDot'); dot.className='status-dot '+state; $('apiLabel').textContent=msg; }
function drawChart(points){ const c=$('priceChart'); if(!c) return; const dpr=window.devicePixelRatio||1; const rect=c.getBoundingClientRect(); c.width=Math.max(300,Math.floor(rect.width*dpr)); c.height=Math.floor(190*dpr); const ctx=c.getContext('2d'); ctx.scale(dpr,dpr); ctx.clearRect(0,0,rect.width,190); const arr=(points||[]).map(p=>({x:p.time||p.timestamp_ms||p.t, y:Number(p.close ?? p.c ?? p.value)})).filter(p=>isFinite(p.y)); if(arr.length<2){ ctx.fillStyle='rgba(220,235,255,.55)'; ctx.font='13px -apple-system'; ctx.fillText('Chart wordt geladen…',14,28); return; } const ys=arr.map(p=>p.y); const min=Math.min(...ys), max=Math.max(...ys); const pad=12, w=rect.width-pad*2, h=166; const sx=(i)=>pad+(i/(arr.length-1))*w; const sy=(y)=>pad+(1-(y-min)/(max-min||1))*h; const grad=ctx.createLinearGradient(0,0,0,190); grad.addColorStop(0,'rgba(24,210,255,.25)'); grad.addColorStop(1,'rgba(24,210,255,0)'); ctx.beginPath(); arr.forEach((p,i)=>{ const x=sx(i), y=sy(p.y); i?ctx.lineTo(x,y):ctx.moveTo(x,y); }); ctx.lineTo(pad+w,188); ctx.lineTo(pad,188); ctx.closePath(); ctx.fillStyle=grad; ctx.fill(); ctx.beginPath(); arr.forEach((p,i)=>{ const x=sx(i), y=sy(p.y); i?ctx.lineTo(x,y):ctx.moveTo(x,y); }); ctx.lineWidth=2; ctx.strokeStyle='#18d2ff'; ctx.stroke(); ctx.fillStyle='rgba(237,245,255,.72)'; ctx.font='11px -apple-system'; ctx.fillText(fmtUsd(max), pad, 16); ctx.fillText(fmtUsd(min), pad, 184); }
function forecastCard(item){ const bull=Number(item.bullish_probability ?? 0); const bear=Number(item.bearish_probability ?? 0); const dir=bull>=bear?'UP bias':'DOWN bias'; const move=Number(item.expected_move_pct ?? 0); const cls=bull>=bear?'good':'danger'; return `<div class="forecast-row"><div class="h">${item.horizon||'—'}</div><div><div class="dir ${cls}">${dir} · ${(move*100).toFixed(2)}%</div><div class="sub">Target ${fmtUsd(item.expected_price)} · invalidatie ${fmtUsd(item.invalidation_price)}</div></div><div class="conf">${Math.round(Number(item.confidence||0)*100)}%</div></div>`; }
function accuracyRow(row){ const hit = row.hitrate==null ? '—' : (Number(row.hitrate)*100).toFixed(1)+'%'; return `<div class="accuracy-row"><div><b>${row.horizon}</b><br><span>${row.total||0} samples · score ${row.avg_score==null?'—':Number(row.avg_score).toFixed(1)}</span></div><b>${hit}</b></div>`; }
function syncStateLabel(states){ if(!Array.isArray(states)||!states.length) return '—'; const preferred=['historical_memory','sync_phase','startup_sync_status','manual_sync_status','external_evidence_backfill']; for(const k of preferred){ const hit=states.find(s=>s.key===k); if(hit) return `${hit.key}: ${hit.value}`; } return `${states[0].key}: ${states[0].value}`; }

function dataStatusLabel(s){ return s==='active'?'actief':(s==='partial'?'deels':'mist'); }
function renderExternalData(ed){
  const box=$('externalDataList'); if(!box) return;
  const rows=(ed&&ed.rows)||[];
  const sum=(ed&&ed.summary)||{};
  const f=(ed&&ed.features)||{};
  $('externalDataSummary') && ($('externalDataSummary').textContent=`${sum.active||0} actief · ${sum.partial||0} deels · ${sum.missing||0} mist`);
  box.innerHTML = rows.map(r=>`<div><span>${r.label}</span><b>${Number(r.rows||0).toLocaleString('nl-NL')} · ${dataStatusLabel(r.status)}</b></div>`).join('') || '<p class="hint">Nog geen externe datasources gemeten.</p>';
  const fb=$('featureEvidenceSummary'); if(fb){ fb.innerHTML = `<div><span>Feature rows</span><b>${Number(f.feature_rows||0).toLocaleString('nl-NL')}</b></div><div><span>Funding/OI rows</span><b>${Number(f.funding_rate_rows||0).toLocaleString('nl-NL')} / ${Number(f.open_interest_rows||0).toLocaleString('nl-NL')}</b></div><div><span>Orderflow rows</span><b>${Number(f.taker_rows||0).toLocaleString('nl-NL')}</b></div><div><span>Sentiment/on-chain</span><b>${Number(f.fear_greed_rows||0).toLocaleString('nl-NL')} / ${Number(f.mvrv_rows||0).toLocaleString('nl-NL')}</b></div>`; }
}

function healthToMobile(data){
  return {
    ok: !!data.ok, engine_version: data.engine_version, api_status:'ok', sync_busy:false,
    btc_price:null, history:data.history||{}, native:data.native_core||data.native||{},
    learning:{time_machine_tests:data.time_machine_tests||0,time_machine_batches:data.time_machine_batches||0,feature_snapshots:data.time_machine_feature_snapshots||0,signal_events:data.time_machine_signal_scores||0},
    candle_range:{from_ms:data.raw_candles_min_ms,to_ms:data.raw_candles_max_ms,rows:data.raw_candles||0},
    latest_items:[], accuracy:[], sync_state:[]
  };
}
async function loadEvidenceStatus(){
  try{ const e=await api('/api/mobile/evidence-status',{timeout:12000,attempts:1}); if(e&&e.ok) renderExternalData(e.external_data); }catch(_){ /* evidence status is optional */ }
}
async function loadSummary(){
  try{
    let data;
    try{ data=await api('/api/mobile/status-fast',{timeout:8000,attempts:1}); }
    catch(_){
      try{ data=await api('/api/health',{timeout:5000,attempts:1}); data=healthToMobile(data); }
      catch(__){ data=await api('/api/mobile/summary',{timeout:12000,attempts:1}); }
    }
    if(!data.ok) throw new Error(data.error||'summary error');
    setApi(data.sync_busy?'loading':'ok', data.sync_busy?'bezig':'online');
    $('versionLabel').textContent=data.engine_version||'Cloud Mobile App';
    $('priceLabel').textContent=fmtUsd(data.btc_price);
    const hist=data.history||{}; const cr=data.candle_range||{};
    const rows=Number(hist.stored_rows ?? hist.rows ?? cr.rows ?? 0); const target=Number(hist.target_rows ?? 70000);
    const pct=Math.min(100, target? rows/target*100:0);
    $('historyPct').textContent=pct.toFixed(1)+'%'; $('historyRows').textContent=`${rows.toLocaleString('nl-NL')} / ${target.toLocaleString('nl-NL')} candles`; $('historyBar').style.width=pct+'%';
    $('nativeState').textContent=(data.native&&data.native.available)?'Actief':'Mist'; $('nativeDetail').textContent=(data.native&&data.native.available)?'C++ cloud core OK':'C++ core ontbreekt';
    const items=data.latest_items||[];
    if($('forecastCount')) $('forecastCount').textContent=items.length?`${items.length} items`:'geen run';
    if($('forecastCards')) $('forecastCards').innerHTML=items.slice(0,4).map(forecastCard).join('') || '<p class="hint">Nog geen forecast. Tik Sync + Forecast.</p>';
    if($('forecastFull')) $('forecastFull').innerHTML=items.map(forecastCard).join('') || '<p class="hint">Forecast wordt via stabiele status niet zwaar geladen; tik Sync + Forecast of ververs later.</p>';
    const learn=data.learning||{};
    $('tmTests').textContent=(learn.time_machine_tests||0).toLocaleString('nl-NL'); $('tmSnapshots').textContent=(learn.feature_snapshots||0).toLocaleString('nl-NL'); $('tmSignals').textContent=(learn.signal_events||0).toLocaleString('nl-NL');
    if($('accuracyList')) $('accuracyList').innerHTML=(data.accuracy||[]).map(accuracyRow).join('') || '<p class="hint">Nog geen accuracy samples.</p>';
    $('dataRows').textContent=((data.candle_range||{}).rows||0).toLocaleString('nl-NL'); $('dataRange').textContent=`${fmtTs((data.candle_range||{}).from_ms)} → ${fmtTs((data.candle_range||{}).to_ms)}`; $('syncStateLabel').textContent=syncStateLabel(data.sync_state);
    renderExternalData(data.external_data);
    window.__summaryErrorShown=false;
  }catch(err){
    // Quiet retry: the server may be doing external backfill or Random1000. Do not spam the UI red every 6 seconds.
    setApi('loading','herladen');
    if(!window.__summaryErrorShown){ toast('Status wordt op de achtergrond bijgewerkt; ik probeer automatisch opnieuw.'); window.__summaryErrorShown=true; }
  }
}
async function loadChart(){ try{ const data=await api('/api/mobile/chart?limit=240',{timeout:8000,attempts:1}); drawChart(data.points || data.items || data.candles || []); }catch(err){ drawChart([]); } }
async function postAction(path,label){ toast(label+' gestart…'); try{ const res=await api(path,{method:'POST',body:'{}',timeout:30000}); toast(res.message || res.reason || label+' OK'); await loadSummary(); }catch(err){ toast(label+' fout: '+err.message); } }
document.querySelectorAll('.bottom-tabs button').forEach(btn=>btn.addEventListener('click',()=>{ document.querySelectorAll('.bottom-tabs button').forEach(b=>b.classList.remove('active')); btn.classList.add('active'); const target=btn.dataset.target; document.querySelectorAll('.mobile-page').forEach(p=>p.classList.toggle('active',p.dataset.page===target)); window.scrollTo({top:0,behavior:'smooth'}); }));
$('installBtn').addEventListener('click', async()=>{ if(installPrompt){ installPrompt.prompt(); await installPrompt.userChoice; installPrompt=null; } else { toast('iPhone: open Delen → Zet op beginscherm.'); } });
$('syncBtn').addEventListener('click',()=>postAction('/api/sync','Sync + Forecast'));
$('historyBtn').addEventListener('click',()=>postAction('/api/historical-memory/backfill?mode=daemon','History check'));
async function runRandomBatch(n){
  toast('Random'+n+' gestart. Laat deze pagina open; status blijft doorlopen.');
  let batchId=null;
  let beforeTests=0;
  try{ const s=await api('/api/mobile/summary',{timeout:20000}); beforeTests=Number(((s.learning||{}).time_machine_tests)||0); }catch(_){ }
  try{
    const res=await api('/api/time-machine/random-tests',{method:'POST',body:JSON.stringify({count:n}),timeout:0});
    batchId=res.batch_id||null;
    toast(res.reason || ('Random'+n+' klaar'));
  }catch(err){
    toast('Random'+n+' draait mogelijk nog; ik blijf status controleren…');
  }
  for(let i=0;i<90;i++){
    await new Promise(r=>setTimeout(r,4000));
    try{
      await loadSummary();
      const current=Number(($('tmTests').textContent||'0').replace(/\D/g,''));
      const snapshots=Number(($('tmSnapshots').textContent||'0').replace(/\D/g,''));
      const expected=beforeTests + n*7;
      if(current>=expected && snapshots>=n*7){ toast('Random'+n+' volledig opgeslagen: tests + snapshots klaar.'); return; }
      if(current>=expected && i>3){ toast('Random'+n+' tests klaar; snapshots/signals worden op de achtergrond afgerond…'); return; }
      if(current>=expected){ toast('Random'+n+' tests klaar; snapshots/signals worden afgerond…'); }
    }catch(_){ }
  }
  toast('Random'+n+' statuscheck gestopt; refresh eventueel de pagina.');
}
$('random100Btn').addEventListener('click',()=>runRandomBatch(100));
$('random1000Btn').addEventListener('click',()=>runRandomBatch(1000));
$('tmExportBtn')?.addEventListener('click',()=>{ window.open('/api/time-machine/export/download','_blank'); });
$('tmResetBtn')?.addEventListener('click',async()=>{ if(!confirm('Time Machine warehouse wissen? Dit wist tests/snapshots/signals, maar NIET de 70.000 candles.')) return; toast('Time Machine reset…'); try{ const res=await api('/api/time-machine/reset',{method:'POST',body:JSON.stringify({delete_exports:false}),timeout:60000}); toast(res.ok?'Time Machine warehouse geleegd':'Reset fout'); await loadSummary(); }catch(err){ toast('Reset fout: '+err.message); }});
$('seedExportBtn').addEventListener('click',async()=>{ $('seedMsg').textContent='Export wordt gemaakt…'; try{ const res=await api('/api/seed-export/create',{method:'POST',body:'{}',timeout:60000}); $('seedMsg').textContent=res.path ? 'Seed ZIP klaar: '+res.path : (res.error||'klaar'); }catch(err){ $('seedMsg').textContent='Export fout: '+err.message; }});
async function loadQuick(){
  try{ const q=await api('/api/mobile/quick',{timeout:3500,attempts:1}); if(q&&q.ok) applyQuick(q); }
  catch(e){
    try{ const h=await api('/api/health',{timeout:4500,attempts:1}); applyQuick({ok:true, engine_version:h.engine_version, raw_candles:h.raw_candles, raw_candles_min_ms:h.raw_candles_min_ms, raw_candles_max_ms:h.raw_candles_max_ms, time_machine_tests:h.time_machine_tests, time_machine_feature_snapshots:h.time_machine_feature_snapshots, time_machine_signal_scores:h.time_machine_signal_scores, native_available:h.native_core&&h.native_core.available}); }
    catch(_){ setApi('loading','opstarten'); hideBoot(); }
  }
}
async function tick(){ await loadSummary(); }
loadQuick(); setTimeout(loadSummary, 250); setTimeout(loadChart, 1200); setTimeout(loadEvidenceStatus, 2600);
setInterval(tick,15000); setInterval(loadChart,90000); setInterval(loadEvidenceStatus,180000); window.addEventListener('resize',()=>setTimeout(loadChart,250));
if('serviceWorker' in navigator){ navigator.serviceWorker.register('/service-worker.js?v=10_16_21_stable').catch(()=>{}); }
