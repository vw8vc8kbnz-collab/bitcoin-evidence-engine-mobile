// Amsterdam anno 1599 — naar de vogelvluchtkaart van Pieter Bast.
// Grid: 512×512, tegel ≈ 5 m, noord (het IJ) boven.
//
// De stad zoals Bast haar tekende:
//   · dichte bebouwing binnen de wallen, doorsneden door de waaier van
//     burgwallen die naar de Dam toelopen
//   · het brede Damrak als havenmond, de Amstel breed de stad uit
//   · de oostelijke uitbreiding (Tweede Uitleg 1593) met de eilanden
//     Uilenburg, Valkenburg en Rapenburg en de Oudeschans
//   · aarden omwalling met puntbastions, dubbel paalwerk in het IJ
//
// Alles hieronder is data: verschuif een punt, refresh, klaar.

export default {
  name: 'Amsterdam 1599 (naar Pieter Bast)',

  // Zuidoever van het IJ: loopt schuin op, west hoger dan oost
  ijShore: { x0: 0, y0: 58, x1: 511, y1: 102 },

  // De stad als polygon, met de klok mee vanaf de Haarlemmerpoort-hoek.
  cityBounds: [
    [130, 74],
    [200, 80], [260, 86], [320, 92], [370, 98], [404, 102],   // IJ-front
    [410, 118],                                                // Montelbaanstoren-hoek
    [382, 136], [352, 154], [328, 168],                        // Oudeschans binnenzijde
    [320, 186], [316, 216], [306, 246], [292, 268],            // Kloveniersburgwal
    [284, 284],                                                // Regulierspoort (Amstel uit)
    [258, 294], [228, 290], [196, 274], [168, 248],            // zuidelijke Singel
    [146, 214], [130, 172], [124, 126],                        // westelijke Singel
  ],

  harbor: { x0: 130, x1: 404 },

  // Havenhoofden: korte pieren het IJ in
  piers: [
    { x: 208, len: 7 }, { x: 238, len: 9 }, { x: 254, len: 9 },
    { x: 296, len: 7 }, { x: 336, len: 6 },
  ],

  // Dubbel paalwerk in het IJ, met openingen voor de schepen
  palisade: [
    { yOffset: -9,  x0: 150, x1: 396, dash: 15, gap: 6 },
    { yOffset: -16, x0: 180, x1: 370, dash: 19, gap: 8 },
  ],

  // Waterlopen: [punten, breedte in tegels]  (1 tegel ≈ 5 m)
  canals: [
    { pts: [[245, 80], [241, 116], [244, 148], [249, 176]], w: 9, name: 'Damrak' },
    { pts: [[252, 196], [258, 222], [266, 248], [273, 268]], w: 7, name: 'Rokin' },
    { pts: [[273, 268], [263, 302], [273, 352], [289, 410], [281, 468], [285, 511]], w: 14, name: 'Amstel' },
    { pts: [[131, 72], [125, 128], [131, 174], [148, 216], [170, 250], [198, 276], [230, 292], [258, 296], [280, 288]], w: 8, name: 'Singel' },
    { pts: [[314, 84], [312, 116], [311, 146]], w: 8, name: 'Geldersekade' },
    { pts: [[311, 154], [317, 198], [312, 240], [296, 268], [285, 280]], w: 8, name: 'Kloveniersburgwal' },
    { pts: [[322, 162], [352, 148], [384, 128], [404, 108]], w: 8, name: 'Oudeschans' },
    { pts: [[314, 130], [346, 114], [378, 98]], w: 5, name: 'Uilenburgergracht' },
    { pts: [[318, 146], [354, 130], [392, 112]], w: 5, name: 'Valkenburgergracht' },
    { pts: [[276, 86], [272, 130], [266, 178], [260, 218], [264, 244]], w: 4, name: 'OZ Voorburgwal' },
    { pts: [[292, 90], [288, 138], [280, 186], [270, 226], [272, 248]], w: 4, name: 'OZ Achterburgwal' },
    { pts: [[224, 82], [220, 130], [226, 186], [238, 228], [250, 254]], w: 4, name: 'NZ Voorburgwal' },
    { pts: [[200, 86], [196, 142], [208, 202], [226, 248], [242, 270]], w: 4, name: 'NZ Achterburgwal' },
    // Grimburgwal / Oudezijds-zuidpunt: dwarsgrachtje bij het gasthuis
    { pts: [[254, 240], [270, 236]], w: 3, name: 'Grimburgwal' },
  ],

  // De omwalling: aarden wal met puntbastions, net binnen de stadsgracht
  wall: {
    pts: [
      [136, 78], [130, 128], [136, 172], [152, 212], [173, 245],
      [200, 270], [230, 286], [257, 290], [278, 283],
      [289, 266], [305, 240], [311, 214], [314, 190], [316, 166],
      [326, 158], [354, 143], [384, 123], [402, 106],
    ],
    bastionEvery: 3,
    bastionR: 5,
  },

  // Straten. Breedtes: hoofdstraat 3, straat 2.5, steeg 1.6
  streets: [
    // — de oude kern, oostzijde (Oudezijds)
    { pts: [[262, 88], [259, 128], [260, 162], [261, 180]], w: 3, name: 'Warmoesstraat' },
    { pts: [[282, 86], [297, 102], [308, 122], [312, 142]], w: 3, name: 'Zeedijk' },
    { pts: [[258, 196], [262, 220], [268, 244]], w: 2.5, name: 'Nes' },
    { pts: [[276, 196], [278, 222], [272, 244]], w: 2, name: 'OZ Achterburgwal-straatje' },
    // — de oude kern, westzijde (Nieuwezijds)
    { pts: [[232, 88], [228, 124], [232, 160], [239, 180]], w: 3, name: 'Nieuwendijk' },
    { pts: [[246, 196], [240, 226], [236, 254], [243, 272]], w: 3, name: 'Kalverstraat' },
    { pts: [[210, 92], [206, 140], [214, 196], [228, 240]], w: 2, name: 'Spuistraat-zijde' },
    // — de as Dam → Nieuwmarkt → uitbreiding
    { pts: [[262, 190], [284, 194], [304, 188], [314, 172]], w: 2.5, name: 'Damstraat–Hoogstraten' },
    { pts: [[326, 166], [346, 158], [366, 146]], w: 3, name: 'Sint Antoniesbreestraat' },
    // — dwarsstegen oost (tussen Warmoesstraat en de burgwallen)
    { pts: [[252, 112], [300, 108]], w: 1.6, name: 'Oudebrugsteeg' },
    { pts: [[254, 136], [302, 132]], w: 1.6, name: 'Sint Annenstraat' },
    { pts: [[256, 158], [304, 154]], w: 1.6, name: 'Lange Niezel' },
    { pts: [[258, 214], [316, 208]], w: 1.6, name: 'Oude Doelenstraat–Rusland' },
    { pts: [[262, 236], [312, 232]], w: 1.6, name: 'Grimburgwal-steeg' },
    // — dwarsstegen west
    { pts: [[204, 116], [242, 112]], w: 1.6, name: 'Dirk van Hasseltssteeg' },
    { pts: [[202, 156], [244, 152]], w: 1.6, name: 'Molsteeg' },
    { pts: [[208, 176], [246, 174]], w: 1.6, name: 'Gasthuissteeg' },
    { pts: [[214, 216], [250, 216]], w: 1.6, name: 'Rosmarijnsteeg' },
    { pts: [[224, 246], [252, 248]], w: 1.6, name: 'Heiligeweg' },
    { pts: [[232, 268], [256, 270]], w: 1.6, name: 'Reguliersteeg' },
    // — de uitbreiding en de eilanden
    { pts: [[330, 152], [358, 136], [386, 118]], w: 2, name: 'Ridderstraat (Lastage)' },
    { pts: [[318, 138], [350, 122], [382, 104]], w: 1.6, name: 'Uilenburg-spine' },
    { pts: [[324, 154], [358, 138], [394, 116]], w: 1.6, name: 'Valkenburg-spine' },
    // — havenfront-verbindingen
    { pts: [[190, 84], [190, 96]], w: 1.6, name: 'Martelaarsgracht-steeg' },
    { pts: [[300, 92], [300, 104]], w: 1.6, name: 'Schreierstoren-steeg' },
  ],

  // Pleinen: [x0, y0, x1, y1]
  plazas: [
    { rect: [244, 182, 262, 194], name: 'de Dam' },
    { rect: [306, 150, 320, 162], name: 'Nieuwmarkt' },
    { rect: [263, 114, 275, 124], name: 'Oudekerksplein' },
    { rect: [234, 176, 244, 184], name: 'Nieuwe Kerk-erf' },
  ],
};
