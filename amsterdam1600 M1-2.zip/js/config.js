// Amsterdam 1600 — configuratie
// Alle sim-relevante constanten op één plek. Geen magic numbers elders.

export const GRID = 512;          // 512×512 tegels, tegel ≈ 5×5 m echt
export const TILE_W = 64;
export const TILE_H = 32;
export const HALF_W = TILE_W / 2;
export const HALF_H = TILE_H / 2;

export const MIN_ZOOM = 0.06;     // hele kaart past op een telefoonscherm
export const MAX_ZOOM = 3.0;
export const START_ZOOM = 0.7;

// Onder deze zoom schakelt de renderer naar de vooraf gerenderde
// overzichtskaart (1 drawImage i.p.v. tienduizenden).
export const OVERVIEW_CUTOFF = 0.4;
export const OVERVIEW_SCALE = 1 / 8;

export const SEED = 1600;

// Tegeltypes (Uint8 in de wereld-array)
export const T = Object.freeze({
  IJ: 0,        // open water van het IJ
  CANAL: 1,     // gracht / rivier / sloot
  GRASS: 2,     // grasland / hof / tuin
  MARSH: 3,     // veenmoeras (toekomstige bouwgrond, eerst heien!)
  DIRT: 4,      // open bouwgrond / erf
  STREET: 5,    // straat of plein
  QUAY: 6,      // kade langs gracht of IJ
  WALL: 7,      // stadswal, bastion of paalwerk
  BLOCK: 8,     // bebouwing (huizenblokken, daken)
});

export const TYPE_NAMES = Object.freeze({
  [T.IJ]: 'IJ-water',
  [T.CANAL]: 'Grachtwater',
  [T.GRASS]: 'Hof of tuin',
  [T.MARSH]: 'Veenmoeras',
  [T.DIRT]: 'Erf',
  [T.STREET]: 'Straat',
  [T.QUAY]: 'Kade',
  [T.WALL]: 'Stadswal',
  [T.BLOCK]: 'Bebouwing',
});

export const WATER_FRAMES = 3;
export const WATER_FRAME_MS = 450;
export const VARIANTS = 3; // visuele variatie per landtype
