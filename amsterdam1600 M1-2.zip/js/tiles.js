// Sprites worden éénmalig voorgerenderd naar offscreen canvases.
// In de render-loop is elke tegel dan één drawImage-call.
// Ontwerp: zachte kleurvlakken, nauwelijks gridlijn, drie tinten per
// landtype — de kaart moet lezen als een geschilderde vogelvlucht,
// niet als een raster.
import { TILE_W, TILE_H, T, WATER_FRAMES, VARIANTS } from './config.js';
import { mulberry32 } from './rng.js';

const SS = 2; // supersample: scherp op retina-schermen

// Drie tinten per landtype; water heeft drie animatieframes
const PALETTE = {
  [T.IJ]:     ['#2c4b51', '#2e4f55', '#2a474c'],
  [T.CANAL]:  ['#3a635d', '#3d6862', '#375e58'],
  [T.GRASS]:  ['#7d9358', '#758b50', '#849a5e'],
  [T.MARSH]:  ['#63714a', '#5c6a43', '#6a7850'],
  [T.DIRT]:   ['#a5906a', '#9c8862', '#ad9871'],
  [T.STREET]: ['#8d877b', '#868074', '#948e82'],
  [T.QUAY]:   ['#ac9e7f', '#a49677', '#b3a586'],
  [T.WALL]:   ['#6e6353', '#675c4d', '#75695a'],
  [T.BLOCK]:  ['#96583c', '#8d5238', '#9f5f41'],  // terracotta daken
};

function diamondPath(ctx, cx, cy, hw, hh) {
  ctx.beginPath();
  ctx.moveTo(cx, cy - hh);
  ctx.lineTo(cx + hw, cy);
  ctx.lineTo(cx, cy + hh);
  ctx.lineTo(cx - hw, cy);
  ctx.closePath();
}

function makeSprite(draw) {
  const c = document.createElement('canvas');
  c.width = TILE_W * SS;
  c.height = TILE_H * SS;
  const ctx = c.getContext('2d');
  ctx.scale(SS, SS);
  draw(ctx, TILE_W / 2, TILE_H / 2, TILE_W / 2, TILE_H / 2);
  return c;
}

function speckle(ctx, cx, cy, hw, hh, seed, count, colors, r) {
  const rnd = mulberry32(seed);
  diamondPath(ctx, cx, cy, hw, hh);
  ctx.save();
  ctx.clip();
  for (let i = 0; i < count; i++) {
    const u = rnd() * 2 - 1, v = rnd() * 2 - 1;
    if (Math.abs(u) + Math.abs(v) > 0.92) continue;
    ctx.fillStyle = colors[(rnd() * colors.length) | 0];
    ctx.beginPath();
    ctx.arc(cx + u * hw, cy + v * hh, r * (0.6 + rnd() * 0.8), 0, 7);
    ctx.fill();
  }
  ctx.restore();
}

// Basisruit. Water krijgt géén gridlijn; land een nauwelijks zichtbare.
function base(ctx, cx, cy, hw, hh, fill, isWater) {
  diamondPath(ctx, cx, cy, hw, hh);
  ctx.fillStyle = fill;
  ctx.fill();
  if (!isWater) {
    ctx.strokeStyle = 'rgba(0,0,0,0.05)';
    ctx.lineWidth = 0.5;
    ctx.stroke();
  }
}

export function buildSprites() {
  const sprites = {};

  // Water: 3 animatieframes met heel subtiele lichtstreepjes
  for (const type of [T.IJ, T.CANAL]) {
    sprites[type] = [];
    for (let f = 0; f < WATER_FRAMES; f++) {
      sprites[type].push(makeSprite((ctx, cx, cy, hw, hh) => {
        base(ctx, cx, cy, hw, hh, PALETTE[type][f], true);
        diamondPath(ctx, cx, cy, hw, hh);
        ctx.save();
        ctx.clip();
        ctx.strokeStyle = 'rgba(215, 232, 226, 0.10)';
        ctx.lineWidth = 1;
        const rnd = mulberry32(1600 + type * 10 + f);
        for (let i = 0; i < 2; i++) {
          const ly = cy - hh * 0.4 + (i + rnd()) * (hh * 0.55) + f * 1.6;
          const lx = cx - hw * 0.5 + rnd() * hw * 0.4;
          ctx.beginPath();
          ctx.moveTo(lx, ly);
          ctx.lineTo(lx + hw * (0.3 + rnd() * 0.3), ly);
          ctx.stroke();
        }
        ctx.restore();
      }));
    }
  }

  // Landtypes: 3 tintvarianten met eigen detailkarakter
  const landDetail = {
    [T.GRASS]:  { colors: ['rgba(58,76,32,0.35)', 'rgba(150,170,106,0.35)'], count: 14, r: 0.7 },
    [T.MARSH]:  { colors: ['rgba(45,76,82,0.30)', 'rgba(40,52,26,0.35)'],    count: 18, r: 0.8 },
    [T.DIRT]:   { colors: ['rgba(76,62,40,0.28)', 'rgba(198,180,142,0.30)'], count: 10, r: 0.7 },
    [T.STREET]: { colors: ['rgba(52,50,46,0.30)', 'rgba(182,176,166,0.28)'], count: 18, r: 0.8 },
    [T.QUAY]:   { colors: ['rgba(74,64,46,0.28)', 'rgba(208,196,168,0.30)'], count: 12, r: 0.8 },
    [T.WALL]:   { colors: ['rgba(32,28,22,0.40)', 'rgba(152,140,118,0.30)'], count: 12, r: 0.9 },
    [T.BLOCK]:  { colors: ['rgba(58,30,20,0.35)', 'rgba(190,120,88,0.30)'],  count: 16, r: 0.8 },
  };

  for (const type of [T.GRASS, T.MARSH, T.DIRT, T.STREET, T.QUAY, T.WALL, T.BLOCK]) {
    sprites[type] = [];
    for (let v = 0; v < VARIANTS; v++) {
      sprites[type].push(makeSprite((ctx, cx, cy, hw, hh) => {
        base(ctx, cx, cy, hw, hh, PALETTE[type][v], false);
        const d = landDetail[type];
        speckle(ctx, cx, cy, hw, hh, type * 100 + v, d.count, d.colors, d.r);
        // Bebouwing: daklijntjes evenwijdig aan de ruit voor pandjes-textuur
        if (type === T.BLOCK) {
          diamondPath(ctx, cx, cy, hw, hh);
          ctx.save();
          ctx.clip();
          ctx.strokeStyle = 'rgba(50, 24, 16, 0.30)';
          ctx.lineWidth = 0.8;
          const rnd = mulberry32(900 + v);
          for (let i = 0; i < 3; i++) {
            const off = -hh * 0.5 + i * hh * 0.5 + rnd() * 2;
            ctx.beginPath();
            ctx.moveTo(cx - hw * 0.7, cy + off * 0.6);
            ctx.lineTo(cx + hw * 0.1, cy + off * 0.6 + hh * 0.4);
            ctx.stroke();
          }
          ctx.restore();
        }
      }));
    }
  }

  // Selectie-highlight (messing ruit-outline)
  const selection = makeSprite((ctx, cx, cy, hw, hh) => {
    diamondPath(ctx, cx, cy, hw - 1, hh - 0.5);
    ctx.strokeStyle = '#c9a45c';
    ctx.lineWidth = 1.6;
    ctx.stroke();
    diamondPath(ctx, cx, cy, hw - 1, hh - 0.5);
    ctx.fillStyle = 'rgba(201, 164, 92, 0.14)';
    ctx.fill();
  });

  return { sprites, selection };
}
