# Outrun IQ v8.4.7 — Premium UX & Performance

## Hoofddoel
Deze versie is een kwaliteitsupdate bovenop v8.4.6. Er zijn bewust geen grote nieuwe business-features toegevoegd; de focus ligt op productfoto's, premium gevoel en directere navigatie.

## Nieuw / aangepast
- Centrale productfoto-logica aangescherpt: productafbeeldingen worden standaard gecentreerd en met `contain` getoond zodat producten niet meer rommelig worden afgesneden.
- Productdetail-galerij uitgebreid met fullscreen lightbox.
- Productdetail ondersteunt nu een vergrootweergave via dubbel tikken/klikken in de fullscreen galerij.
- Productdetail toont thumbnails en vorige/volgende bediening in de fullscreen galerij.
- Buyer bottom navigation kreeg prefetch en tap-hardening zodat tabwissels sneller en betrouwbaarder reageren.
- Algemene tap feedback toegevoegd voor productkaarten, navigatieknoppen en dock-items.
- CSS pointer/touch hardening toegevoegd tegen dubbele taps, 300ms-achtige vertragingen en overlay-interceptie.
- Productlijsten, compacte cards en zoekresultaten gebruiken rustigere beeldcontainers met consistente achtergrond.

## Belangrijk
- v8.4.6 Buyer AI Brain blijft inhoudelijk de baseline.
- v8.4.7 verandert vooral UX, image handling en interactiegevoel.
- Geen wijziging aan live payment-safety: test/preview blijft de veilige standaard totdat live payments expliciet veilig vrijgegeven zijn.
