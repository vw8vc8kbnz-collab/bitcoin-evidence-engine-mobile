"use client";
import { useRef, useState } from "react";
import { Illu, type IlluKind } from "./icons";

export function Gallery({ photos, fallback, defect, title }:{
  photos: string[]; fallback: IlluKind; defect?: string; title: string;
}) {
  const [i, setI] = useState(0);
  const [open, setOpen] = useState(false);
  const [zoom, setZoom] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  function onScroll() {
    const el = ref.current;
    if (el) setI(Math.round(el.scrollLeft / el.clientWidth));
  }
  function jump(idx: number) {
    setI(idx);
    ref.current?.scrollTo({ left: idx * ref.current.clientWidth, behavior: "smooth" });
  }
  if (photos.length === 0) {
    return (
      <>
        <button type="button" className="galleryOpen empty" aria-label="Open productfoto" onClick={() => setOpen(true)}>
          <span style={{ width: 130 }}><Illu kind={fallback} /></span>
        </button>
        {defect && <span className="gebrek"><i />{defect}</span>}
      </>
    );
  }
  return (
    <>
      <button type="button" className="galleryOpen" aria-label="Open productfoto fullscreen" onClick={() => setOpen(true)}>
        <span>Tik om te vergroten</span>
      </button>
      <div className="gal" ref={ref} onScroll={onScroll}>
        {photos.map((u, idx) => (
          /* eslint-disable-next-line @next/next/no-img-element */
          <img key={u} src={u} alt={`${title} foto ${idx + 1}`} loading={idx === 0 ? "eager" : "lazy"} />
        ))}
      </div>
      {defect && <span className="gebrek"><i />{defect}</span>}
      <span className="cnt">{Math.min(i + 1, photos.length)} / {photos.length}</span>
      {photos.length > 1 && <span className="galleryDots" aria-hidden="true">{photos.map((_, idx)=><i key={idx} className={idx === i ? "on" : ""} />)}</span>}
      {open && (
        <div className="photoLightbox" role="dialog" aria-modal="true" aria-label="Productfoto galerij">
          <button type="button" className="photoClose" onClick={() => { setOpen(false); setZoom(false); }} aria-label="Sluit galerij">×</button>
          <div className="photoStage" onDoubleClick={() => setZoom(z => !z)}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={photos[i]} alt={`${title} foto ${i + 1}`} className={zoom ? "zoom" : ""} />
          </div>
          <div className="photoTools">
            <button type="button" onClick={() => jump(Math.max(0, i - 1))} disabled={i === 0}>Vorige</button>
            <span>{i + 1} / {photos.length}</span>
            <button type="button" onClick={() => jump(Math.min(photos.length - 1, i + 1))} disabled={i === photos.length - 1}>Volgende</button>
          </div>
          <div className="photoThumbs">
            {photos.map((u, idx) => (
              <button key={u} type="button" className={idx === i ? "on" : ""} onClick={() => setI(idx)} aria-label={`Foto ${idx + 1}`}>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={u} alt="" />
              </button>
            ))}
          </div>
        </div>
      )}
    </>
  );
}
