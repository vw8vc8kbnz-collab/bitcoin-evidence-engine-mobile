# Outrun IQ v8.4.7

Premium UX & Performance build bovenop v8.4.6 Buyer AI Brain.

Belangrijkste verbeteringen:
- betere productfoto-schaling in lijsten en detailpagina;
- fullscreen productgalerij met thumbnails;
- snellere en betrouwbaardere tabnavigatie;
- tap-feedback en touch-hardening door de app;
- geen live-payment wijziging.

Installatie op VPS blijft via de vaste Termius update-regel.
