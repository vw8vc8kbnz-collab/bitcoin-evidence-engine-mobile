# Configurator Studio v1.5.2.2 — Reliable Configurator Core

v1.1 combineert de UX-cleanup met de eerste echte Engine Foundation.

## Wat is nieuw

### UX
- Paywall-overlay volledig verwijderd.
- Plus/foto/3D-knoppen openen geen plannen-overlay meer.
- Sandbox-kliks tonen alleen een subtiele toast en scrollen naar pricing.
- Customer-facing UI noemt geen interne AI/provider/architectuur.
- Nieuwe Builder Foundation:
  - klikbaar 3D-model
  - smooth context action menu
  - koppel onderdeel
  - voeg materiaal/textuur toe
  - voeg maatoptie toe
  - voeg variant/zichtbaarheid toe
  - voeg prijsregel toe
  - voeg regel/waarschuwing toe
  - koppel orderdata
  - simuleer niet-configureerbaar model

### Engine Foundation
- Truth Graph v2
- AI-candidates zijn nooit confirmed facts.
- Confirmed betekent user/admin/measured/import verified.
- Boolean critical-field gates, geen pseudo readiness score als beslissing.
- Conflict resolution contract.
- Mesh inventory + Segmentation/Configurability Gate.
- Pricing Engine als enige prijsbron.
- Rule Engine mag pricing rules enable/disable, maar geen directe prijs toevoegen.
- Job + credit ledger schemas met failure taxonomy.
- Immutable runtime snapshot schema.
- Publish gate schema.
- Engine smoke tests.

## Belangrijke strategie

v1.1 is bewust GLB/configurator-core first. Echte foto-naar-3D generatie zit niet in deze versie. Dat voorkomt dat gegenereerde modellen als exact/configureerbaar worden behandeld voordat de betrouwbare kern staat.


## v1.1.1 mobile fix

- Builder modal gebruikt nu een flex layout met echte `100dvh` mobiele scroll.
- `.builder-shell` is de enige mobiele scrollcontainer met `-webkit-overflow-scrolling: touch`.
- 3D-preview is compacter op iPhone.
- Productblokken, inspector en publish checks staan onder elkaar en blijven bereikbaar.
- Contextmenu gedraagt zich op mobiel als bottom sheet.
- Paywall-overlay blijft verwijderd.


## v1.2 Builder State Engine

- Contextmenu-acties bouwen nu live de no-code blueprint-state op.
- Link part, material, dimension, variant, pricing, rule en orderdata hebben zichtbare effecten.
- Tabs Parts / Options / Pricing / Rules schakelen nu echt tussen builder-state.
- Pricing breakdown wordt dynamisch opgebouwd uit pricing rules.
- Publish checklist reageert op blueprint-state.
- Inspector heeft label-input, blok toevoegen en JSON-preview.
- Nieuwe engine helper: `createBuilderDraft`.
- Engine smoke-test uitgebreid met builder draft validatie.


## v1.3 Customer-Friendly Builder

- “Productblokken” is verduidelijkt naar klantlogische onderdelen en klantkeuzes.
- Builder-tabs zijn nu: Onderdelen, Klantkeuzes, Prijzen, Regels, Order.
- Pricing start niet meer met verzonnen bedragen.
- Basisprijs staat als “nog instellen” totdat de gebruiker een bedrag invoert.
- Prijsregels gebruiken de inspector-invoer: prijssoort + bedrag.
- Publish checklist blokkeert nu duidelijk op ontbrekende basisprijs.
- Link tussen onderdeel → keuze → prijs → order is klantvriendelijker uitgelegd.
- Nieuwe engine helper: `customerBuilder.js`.


## v1.4 Capability-Aware Builder Modes

- Builder heeft nu duidelijke scopes/modes:
  - Productniveau
  - Losse onderdelen
  - Materiaalzones
  - Eerst voorbereiden / één geheel
- Productniveau bevat nu ook kleur, materiaal en textuur voor het hele product.
- Contextmenu toont niet langer alle acties overal.
- Materiaalzones tonen alleen logische acties zoals kleur/materiaal/textuur/afwerking en meerprijs voor keuze.
- Maatopties staan op productniveau of expliciete dimension-driven onderdelen, niet op willekeurige vlakken.
- Varianten/zichtbaarheid staan alleen bij losse onderdelen.
- Single-mesh/één-geheel-modus behandelt het model als één product met materiaal, maat, prijs en orderdata.
- Nieuwe engine helper: `selectionCapabilities.js`.


## v1.5 Test Table GLB Integrated

- Echte testtafel GLB toegevoegd: `assets/test_table_configurator.glb`.
- Manifest toegevoegd: `assets/test_table_configurator_manifest.json`.
- Builder gebruikt nu testtafel-onderdelen:
  - Tafelblad
  - Accentstrip
  - Metalen frame en poten
- GLB viewer probeert het echte bestand te laden via de browser.
- Bij klikken op een onderdeel wordt het geselecteerde mesh/object visueel gehighlight.
- Als de 3D-library niet laadt, blijft de bestaande fallback-preview actief.
- Nieuwe engine helper: `engine/core/testTableManifest.js`.


## v1.5.1 Real GLB Only

- Fallback nepviewer is volledig uit de builder-viewer verwijderd.
- De viewer toont alleen nog de echte `assets/test_table_configurator.glb`.
- Three.js laadt via import-map zodat GLTFLoader/OrbitControls correct resolven.
- Als GLB laden faalt, verschijnt een echte foutmelding in plaats van fallback.
- Geselecteerde onderdelen lichten op via materiaal-highlight + BoxHelper.
- Selectie vanuit mesh-lijst probeert ook het echte 3D-onderdeel te highlighten.


## v1.5.2 Stable Real GLB Builder

- Mobiele vastloper/audit opgelost.
- Topbar heeft nu Model / Builder / Sluit.
- Viewer heeft stabiele mobiele hoogte.
- Alleen echte GLB-laag, geen fake fallback.
- Selectieknoppen en reset camera toegevoegd.
- Extra auditbestand: `docs/V1_5_2_STABILITY_AUDIT.md`.
