# TECHNISCHE OVERDRACHT — CONFIGURATOR STUDIO v2.1.0

## 0. Samenvatting

Configurator Studio v2.1.0 corrigeert de producthiërarchie van de vorige build. De applicatie is voortaan een begeleide webapp waarin klanten configurators bouwen. De uiteindelijke configurator is een aparte runtime-output.

Deze release bevat daarnaast een echte Arc Chair-demo met twee onafhankelijk configureerbare materiaalzones. De oude demotafel is volledig verwijderd.

**Release:** `configurator-studio-v2.1.0`  
**Serverpad:** `/var/www/configurator-studio`  
**Publieke poort:** nginx `9999`  
**Interne Node-poort:** `127.0.0.1:10000`  
**Service:** `configurator-studio.service`

## 1. Vaste productrichting

De kernstructuur is:

```text
Workspace
└── Projectdashboard
    └── Configuratorproject
        ├── 1 Productbrief
        ├── 2 Bronmateriaal
        ├── 3 Studio Engine-route
        ├── 4 3D-model
        ├── 5 Modelcontrole
        ├── 6 Onderdelen
        ├── 7 Klantkeuzes
        ├── 8 Prijzen
        ├── 9 Regels
        ├── 10 Webshop & order
        ├── 11 Vormgeving
        └── 12 Testen & live
            └── immutable klant-runtime
```

De builder mag nooit opnieuw worden ontworpen als één configurator met technische panelen eromheen.

## 2. Arc Chair-asset

Bestand:

```text
public/assets/demo-chair.glb
```

Technische eigenschappen:

```text
file_bytes: 896732
triangles: 39851
meshes: 2
materials: 2
textures: 0
images: 0
mobile_ready: true
```

Meshes:

```text
seat_and_back
legs_and_footrest
```

Het model is afgeleid van het door de gebruiker aangeleverde GLB. De oorspronkelijke vorm en verhoudingen zijn behouden onder vereenvoudiging. Het model is niet opnieuw als generieke AI-vorm bedacht; de echte brongeometrie is gebruikt.

## 3. Blueprint

Bronbestand:

```text
src/core/blueprint.mjs
```

Onderdelen:

```text
part_seat → seat_and_back
part_legs → legs_and_footrest
```

Optiegroepen:

```text
group_seat_color
- seat_beige
- seat_terracotta
- seat_sage
- seat_charcoal

group_leg_finish
- legs_black
- legs_walnut
- legs_white
- legs_steel
```

De optiegroepen hebben ieder een eigen `target_id`. `applySelections()` zoekt het onderdeel en geeft uitsluitend diens `mesh_targets` aan `ProductViewer.applyMaterial()` door.

## 4. Gedeelde configuratie-engine

Bestand:

```text
public/js/configEngine.js
```

Functies:

- `createInitialSelections()`;
- `evaluateConfiguration()`;
- `calculateConfigurationPrice()`;
- `buildOrderPayload()`.

Zowel `public/js/app.js` als `public/runtime.html` importeren deze engine. Hierdoor blijft builder/runtime parity behouden.

Voorbeeldcontract:

```text
Terracotta zitting + poederwit onderstel
429 + 20 + 15 = 464 EUR
```

Payloadvelden:

```text
seat_color = Terracotta
leg_finish = Poederwit
product_reference = ARC-CHAIR
total_price = 464
```

## 5. Viewer

Bestand:

```text
public/js/viewer.js
```

Belangrijkste gedrag:

1. GLB laden.
2. Iedere mesh krijgt een eigen materiaalclone.
3. Asset bounding box bepalen.
4. Asset horizontaal centreren.
5. Onderzijde exact op een studiovloer plaatsen.
6. Camerafstand berekenen uit hoogte, breedte, diepte en aspectratio.
7. Driekwart-startpositie instellen.
8. Meshselectie via raycasting.
9. Per mesh materiaal toepassen.
10. Geometry, materials, textures, RAF, controls en WebGL-context opruimen bij dispose.

De camerafix is specifiek belangrijk voor hoge meubels zoals de stoel. De oude tafelgeoriënteerde framing is verwijderd.

## 6. Builderfrontend

Belangrijkste bestanden:

```text
public/index.html
public/app.css
public/js/app.js
public/js/studioSteps.js
```

`app.js` beheert:

- projectdashboard;
- project openen/aanmaken;
- stapnavigatie;
- step-specific rendering;
- viewer lifecycle;
- opties en kleuren;
- pricing;
- orderpayload;
- klantpreview;
- autosave van blueprintwijzigingen;
- publicatie.

Nieuwe projecten krijgen vanuit `server.mjs` een leeg blueprint. Het stoelblueprint wordt alleen gebruikt voor `proj_demo_chair`.

## 7. Publieke runtime

Bestanden:

```text
public/runtime.html
public/runtime.css
src/core/runtimeCompiler.mjs
```

De runtime wordt geladen met:

```text
/runtime/<runtime_config_id>
```

De runtime bevat geen providerprompts of providercredentials. Hij bevat alleen het gecompileerde asset, product, parts, option groups, pricing, rules, orderoutput, commerce, branding en bevestigde facts.

## 8. Truth Graph en review

De bestaande regels blijven verplicht:

- AI-output is kandidaat;
- AI bevestigt geen facts;
- afmetingen mogen pricing/CAD pas sturen na expliciete verificatie;
- uploads, CAD-output, AI-output en retexture-output vereisen menselijke modelreview;
- publicatie verloopt via boolean gates;
- runtime snapshots zijn immutable.

## 9. AI/CAD-routes

Provideradapters:

```text
src/providers/openaiProductArchitect.mjs
src/providers/meshy.mjs
src/providers/tripo.mjs
src/providers/rodin.mjs
src/providers/freecad.mjs
```

De providerlaag blijft los van de builder. De klant-UI presenteert resultaatprofielen; technische adapterdetails blijven backendtraceerbaar.

## 10. Persistentie en migratie

Store:

```text
data/store.json
src/server/store.mjs
```

Migratie:

```text
server/scripts/migrate-v2.1.mjs
```

De migratie vervangt alleen het vaste demoproject/asset/blueprint. Andere projecten worden niet verwijderd.

## 11. Deployment

Correcte architectuur:

```text
browser → nginx:9999 → Node:127.0.0.1:10000
```

Bestanden:

```text
deploy/configurator-studio.service
deploy/nginx-configurator-studio.conf
deploy/deploy-v2.sh
deploy/install-release.sh
deploy/update-from-github.sh
```

De installer:

1. valideert versie 2.1.0;
2. draait 23 tests;
3. kopieert de release naar een nieuwe map;
4. bewaart `.env` en runtimegegevens;
5. maakt rollback;
6. draait v2.1-migratie;
7. zet permissies;
8. installeert systemd/nginx;
9. test intern poort 10000;
10. test publiek poort 9999;
11. herstelt de vorige release bij fouten.

## 12. Tests

Uitvoeren:

```bash
npm run check
```

Huidige stand:

```text
23 passed
0 failed
```

Belangrijke nieuwe tests:

- twee echte meshzones in het GLB;
- 39.851 triangles en mobiele metric;
- afzonderlijke targets voor zitting en poten;
- runtimecompiler neemt commerce/branding/facts mee;
- builder/runtime selectie-, prijs- en orderpariteit;
- projectdashboard en twaalfstappenbuilder aanwezig.

## 13. Bekende grenzen

Deze release is nog single-workspace. Nog niet aanwezig:

- organisaties/tenants/rollen;
- subscriptions, billing en credits;
- object storage/CDN;
- distributed jobqueue/recovery;
- volwaardige commerce-apps;
- analytics.

Ook is de assistent in de huidige UI contextueel en regelgebaseerd; de OpenAI Product Architect is via de backend aanwezig, maar nog niet overal als conversationele copilot in iedere stap aangesloten.

## 14. Eerstvolgende ontwikkelprioriteiten

1. Step 2 uitbreiden met multi-file bronbeheer en uploadprogress.
2. Product Architect rechtstreeks in stap 1–3 integreren.
3. Echte segmentatie/split/merge-editor in stap 6.
4. Volwaardige optiegroepeditor in plaats van alleen de demo-opties.
5. Visuele rule builder en combinatietester.
6. Commerce-adapters echt implementeren.
7. PostgreSQL/Supabase + object storage.
8. Persistente jobqueue.
9. Multi-tenant auth/billing.

De productrichting blijft daarbij altijd: **Studio als configuratorfabriek, runtime als output.**
