"""Blender background conversion and browser optimization.
Usage: blender --background --python convert_to_glb.py -- input.obj output.glb
"""
import bpy, os, sys
from pathlib import Path

args = sys.argv[sys.argv.index("--") + 1:]
if len(args) != 2:
    raise SystemExit("input and output paths required")
source, target = map(lambda p: str(Path(p).resolve()), args)
bpy.ops.wm.read_factory_settings(use_empty=True)
ext = Path(source).suffix.lower()
if ext == ".obj":
    if hasattr(bpy.ops.wm, "obj_import"): bpy.ops.wm.obj_import(filepath=source)
    else: bpy.ops.import_scene.obj(filepath=source)
elif ext in (".glb", ".gltf"): bpy.ops.import_scene.gltf(filepath=source)
elif ext == ".fbx": bpy.ops.import_scene.fbx(filepath=source)
else: raise SystemExit(f"unsupported input format: {ext}")
for obj in bpy.context.scene.objects:
    if obj.type != "MESH": continue
    obj.data.name = obj.name
    for poly in obj.data.polygons: poly.use_smooth = False
    if not obj.data.materials:
        mat=bpy.data.materials.new(f"{obj.name}_material"); mat.diffuse_color=(0.55,0.42,0.30,1); mat.use_nodes=True; obj.data.materials.append(mat)
# Keep names/material zones intact. Compression can be added in a provider-independent post-process later.
bpy.ops.export_scene.gltf(filepath=target, export_format="GLB", export_apply=True, export_yup=True, export_materials="EXPORT", export_cameras=False, export_lights=False)
print(f"wrote {target} ({os.path.getsize(target)} bytes)")
