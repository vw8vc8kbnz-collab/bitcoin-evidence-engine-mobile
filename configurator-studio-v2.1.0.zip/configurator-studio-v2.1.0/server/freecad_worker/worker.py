#!/usr/bin/env python3
"""Configurator Studio FreeCAD worker.
Run with: freecadcmd worker.py /path/to/request.json
The worker never guesses dimensions. It only consumes confirmed parameters from the orchestrator.
"""
from __future__ import annotations
import json, os, sys, traceback
from pathlib import Path


def main() -> int:
    if len(sys.argv) < 2:
        raise SystemExit("request json path required")
    request_path = Path(sys.argv[-1]).resolve()
    request = json.loads(request_path.read_text(encoding="utf-8"))
    output_dir = Path(request["output_dir"]).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    result_path = Path(request["result_path"]).resolve()
    try:
        import FreeCAD as App
        import Part
        import Mesh
        template = str(request.get("template") or "table").lower()
        params = request.get("params") or {}
        dimensions = dimensions_from_params(params)
        validate_template_dimensions(template, dimensions)
        doc = App.newDocument(f"Configurator_{request['job_id']}")
        if any(word in template for word in ("cabinet", "kast", "wardrobe")):
            objects, inventory = build_cabinet(doc, App, Part, dimensions)
        elif any(word in template for word in ("panel", "paneel", "door", "deur")):
            objects, inventory = build_panel(doc, App, Part, dimensions)
        else:
            objects, inventory = build_table(doc, App, Part, dimensions)
        doc.recompute()
        step_name = f"{request['job_id']}-freecad.step"
        obj_name = f"{request['job_id']}-freecad.obj"
        step_path, obj_path = output_dir / step_name, output_dir / obj_name
        Part.export(objects, str(step_path))
        Mesh.export(objects, str(obj_path))
        result = {
            "ok": True,
            "step_file": step_name,
            "obj_file": obj_name,
            "files": [step_name, obj_name],
            "mesh_inventory": inventory,
            "metrics": {"parametric": True, "template": template, **dimensions}
        }
    except Exception as exc:
        result = {"ok": False, "error": str(exc), "traceback": traceback.format_exc()}
    result_path.write_text(json.dumps(result, indent=2), encoding="utf-8")
    return 0 if result.get("ok") else 1


def dimensions_from_params(params):
    def read(key):
        if key not in params or params[key] is None:
            raise ValueError(f"Confirmed dimension {key} is required")
        value = float(params[key])
        if value <= 0:
            raise ValueError(f"Confirmed dimension {key} must be positive")
        return value
    return {
        "length_mm": read("dimensions.length_mm"),
        "width_mm": read("dimensions.width_mm"),
        "height_mm": read("dimensions.height_mm"),
    }


def validate_template_dimensions(template, dimensions):
    L, W, H = dimensions["length_mm"], dimensions["width_mm"], dimensions["height_mm"]
    if any(word in template for word in ("cabinet", "kast", "wardrobe")):
        if L < 200 or W < 100 or H < 200:
            raise ValueError("Cabinet dimensions are below safe template minima (200 x 100 x 200 mm)")
    elif any(word in template for word in ("panel", "paneel", "door", "deur")):
        if L < 50 or W < 50 or H < 3:
            raise ValueError("Panel dimensions are below safe template minima (50 x 50 x 3 mm)")
    else:
        if L < 600 or W < 400 or H < 350:
            raise ValueError("Table dimensions are below safe template minima (600 x 400 x 350 mm)")
    return dimensions


def add_box(doc, App, Part, name, label, length, width, height, x=0, y=0, z=0, color=(0.72, 0.50, 0.30)):
    obj = doc.addObject("Part::Feature", name)
    obj.Label = label
    obj.Shape = Part.makeBox(length, width, height, App.Vector(x, y, z))
    obj.addProperty("App::PropertyString", "ConfiguratorPartId").ConfiguratorPartId = name
    obj.ViewObject.ShapeColor = color
    return obj


def build_table(doc, App, Part, d):
    L, W, H = d["length_mm"], d["width_mm"], d["height_mm"]
    top_t, leg, inset = 38.0, 65.0, 105.0
    top = add_box(doc, App, Part, "tabletop_main", "Tafelblad", L, W, top_t, 0, 0, H-top_t)
    inlay = add_box(doc, App, Part, "tabletop_inlay", "Accentstrip", L-180, 18, 4, 90, W/2-9, H+0.2, (0.30,0.22,0.16))
    apron_h, apron_t = 90.0, 25.0
    apron_front = add_box(doc, App, Part, "apron_front", "Frame voor", L-2*inset, apron_t, apron_h, inset, inset, H-top_t-apron_h, (0.09,0.09,0.09))
    apron_back = add_box(doc, App, Part, "apron_back", "Frame achter", L-2*inset, apron_t, apron_h, inset, W-inset-apron_t, H-top_t-apron_h, (0.09,0.09,0.09))
    apron_left = add_box(doc, App, Part, "apron_left", "Frame links", apron_t, W-2*inset, apron_h, inset, inset, H-top_t-apron_h, (0.09,0.09,0.09))
    apron_right = add_box(doc, App, Part, "apron_right", "Frame rechts", apron_t, W-2*inset, apron_h, L-inset-apron_t, inset, H-top_t-apron_h, (0.09,0.09,0.09))
    legs=[]
    for name,x,y in [("leg_front_left",inset,inset),("leg_front_right",L-inset-leg,inset),("leg_back_left",inset,W-inset-leg),("leg_back_right",L-inset-leg,W-inset-leg)]:
        legs.append(add_box(doc, App, Part, name, name.replace('_',' ').title(), leg, leg, H-top_t, x,y,0,(0.08,0.08,0.08)))
    objects=[top,inlay,apron_front,apron_back,apron_left,apron_right,*legs]
    inventory=[{"mesh_id":o.Name,"label":o.Label,"visible":True,"assigned_part_id":"part_tabletop" if o.Name=="tabletop_main" else "part_inlay" if o.Name=="tabletop_inlay" else "part_frame"} for o in objects]
    return objects, inventory


def build_panel(doc, App, Part, d):
    panel=add_box(doc,App,Part,"panel_main","Paneel",d["length_mm"],d["width_mm"],max(12,min(d["height_mm"],80)))
    return [panel],[{"mesh_id":"panel_main","label":"Paneel","visible":True,"assigned_part_id":"part_panel"}]


def build_cabinet(doc, App, Part, d):
    W,D,H=d["length_mm"],d["width_mm"],d["height_mm"]
    t=18.0
    objects=[
        add_box(doc,App,Part,"cabinet_left","Zijde links",t,D,H),
        add_box(doc,App,Part,"cabinet_right","Zijde rechts",t,D,H,W-t,0,0),
        add_box(doc,App,Part,"cabinet_top","Bovenblad",W-2*t,D,t,t,0,H-t),
        add_box(doc,App,Part,"cabinet_bottom","Onderblad",W-2*t,D,t,t,0,0),
        add_box(doc,App,Part,"cabinet_back","Achterwand",W-2*t,6,H-2*t,t,D-6,t),
        add_box(doc,App,Part,"door_left","Deur links",W/2-3,20,H-8,2,-20,4,(0.75,0.72,0.66)),
        add_box(doc,App,Part,"door_right","Deur rechts",W/2-3,20,H-8,W/2+1,-20,4,(0.75,0.72,0.66)),
    ]
    inventory=[{"mesh_id":o.Name,"label":o.Label,"visible":True,"assigned_part_id":"part_doors" if o.Name.startswith("door_") else "part_carcass"} for o in objects]
    return objects, inventory


if __name__ == "__main__":
    raise SystemExit(main())
