import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

const root=process.cwd();
const jsFiles=[], pythonFiles=[], shellFiles=[], jsonFiles=[];
walk(root);

for(const file of jsFiles) run(process.execPath,['--check',file],`JavaScript syntax: ${file}`);
for(const file of pythonFiles) run('python3',['-c','import ast,sys; ast.parse(open(sys.argv[1],encoding="utf-8").read(), filename=sys.argv[1])',file],`Python syntax: ${file}`);
for(const file of shellFiles) run('bash',['-n',file],`Shell syntax: ${file}`);
for(const file of jsonFiles){try{JSON.parse(fs.readFileSync(file,'utf8'))}catch(error){console.error(`JSON syntax: ${file}: ${error.message}`);process.exit(1)}}

console.log(`Syntax OK: ${jsFiles.length} JavaScript, ${pythonFiles.length} Python, ${shellFiles.length} shell en ${jsonFiles.length} JSON bestanden`);

function run(command,args,label){const result=spawnSync(command,args,{encoding:'utf8'});if(result.status!==0){process.stderr.write(`${label}\n${result.stderr||result.stdout}`);process.exit(result.status||1)}}
function walk(dir){for(const entry of fs.readdirSync(dir,{withFileTypes:true})){if(['node_modules','.git','__pycache__'].includes(entry.name))continue;const full=path.join(dir,entry.name);if(entry.isDirectory())walk(full);else if(/\.(mjs|js)$/.test(entry.name))jsFiles.push(full);else if(entry.name.endsWith('.py'))pythonFiles.push(full);else if(entry.name.endsWith('.sh'))shellFiles.push(full);else if(entry.name.endsWith('.json'))jsonFiles.push(full)}}
