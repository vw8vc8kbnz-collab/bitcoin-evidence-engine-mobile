import fs from 'node:fs';
import path from 'node:path';
import { createDemoBlueprint } from '../../src/core/blueprint.mjs';

const root = process.argv[2] || process.cwd();
const file = path.join(root, 'data', 'store.json');
if (!fs.existsSync(file)) process.exit(0);
const data = JSON.parse(fs.readFileSync(file, 'utf8'));
data.schema_version = '2.1.0';
const now = new Date().toISOString();
let project = (data.projects || []).find(item => item.project_id === 'proj_demo_chair');
if (!project) {
  project = {
    project_id:'proj_demo_chair',workspace_id:'ws_demo',name:'Arc Chair Configurator',description:'Bouw en test een stoelconfigurator met onafhankelijk instelbare zitting en poten.',status:'draft',created_at:now,updated_at:now,runtime_version:0,published_runtime_id:null,active_asset_id:'asset_demo_chair',candidate_asset_id:null,
    builder_state:{current_step:'options',completed_intro:true},intake:{prompt:'Een premium stoel waarbij de klant de kleur van de zitting en het onderstel los kan kiezen.',category:'chair',requested_profile:'uploaded_asset'},route_decision:{route:'uploaded_asset',reason:'Geoptimaliseerd demo-GLB met twee configureerbare zones.',automatic_publish_allowed:false},required_fact_keys:['dimensions.width_mm','dimensions.depth_mm','dimensions.height_mm'],facts:[],clarification_questions:[],candidate_blueprint:null
  };
  data.projects.push(project);
}
project.name = 'Arc Chair Configurator';
project.description = 'Bouw en test een stoelconfigurator met onafhankelijk instelbare zitting en poten.';
project.status = 'draft';
project.updated_at = now;
project.active_asset_id = 'asset_demo_chair';
project.candidate_asset_id = null;
project.builder_state = { ...(project.builder_state || {}), current_step:'options', completed_intro:true };
project.intake = { ...(project.intake || {}), prompt:'Een premium stoel waarbij de klant de kleur van de zitting en het onderstel los kan kiezen.', category:'chair', requested_profile:'uploaded_asset' };
project.route_decision = { route:'uploaded_asset', reason:'Geoptimaliseerd demo-GLB met twee configureerbare zones.', automatic_publish_allowed:false };
project.required_fact_keys = ['dimensions.width_mm','dimensions.depth_mm','dimensions.height_mm'];
const facts = new Map((project.facts || []).map(fact => [fact.key, fact]));
for (const [key,label,value,unit,type='measurement'] of [
  ['dimensions.width_mm','Breedte',453,'mm'],['dimensions.depth_mm','Diepte',540,'mm'],['dimensions.height_mm','Hoogte',999,'mm'],['product.category','Productcategorie','chair',null,'text']
]) {
  facts.set(key,{...(facts.get(key)||{}),fact_id:facts.get(key)?.fact_id||`fact_migrated_${key.replace(/\W/g,'_')}`,key,label,value,unit,value_type:type,critical:key.startsWith('dimensions.'),candidates:[],verified:{by:'studio_migration',method:'imported_verified',at:now},conflict:null,status:'confirmed',pricing_allowed:true,updated_at:now});
}
project.facts = [...facts.values()];
data.blueprints ||= {};
data.blueprints.proj_demo_chair = createDemoBlueprint();
data.assets ||= [];
let asset = data.assets.find(item => item.asset_id === 'asset_demo_chair');
if (!asset) { asset = { asset_id:'asset_demo_chair', project_id:'proj_demo_chair', created_at:now }; data.assets.push(asset); }
Object.assign(asset,{
  project_id:'proj_demo_chair',source_type:'verified_upload',provider:null,file_name:'demo-chair.glb',extension:'glb',public_url:'/assets/demo-chair.glb',poster_url:'/assets/demo-chair-preview.png',quality_status:'accepted',technical_status:'succeeded',
  metrics:{file_bytes:896732,glb_version:2,triangles:39851,meshes:2,nodes:3,primitives:2,materials:2,textures:0,images:0,mobile_ready:true},
  mesh_inventory:[{mesh_id:'seat_and_back',label:'Zitting en rug',visible:true,assigned_part_id:'part_seat',triangles:30000,primitive_count:1},{mesh_id:'legs_and_footrest',label:'Poten en voetensteun',visible:true,assigned_part_id:'part_legs',triangles:9851,primitive_count:1}],
  provenance:{uploaded_by:'studio_seed',source:'user_supplied_glb_simplified',candidate_only:false,optimized_for_web:true,source_triangles:280838,optimization_note:'silhouette_preserving_decimation_and_two_zone_split'}
});
fs.writeFileSync(file, JSON.stringify(data,null,2)+'\n');
console.log('v2.1 migration: demo chair, two material zones and blueprint installed.');
