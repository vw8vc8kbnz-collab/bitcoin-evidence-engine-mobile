#!/usr/bin/env bash
set -euo pipefail
BASE="${1:-http://127.0.0.1:9999}"
APP_DIR="${APP_DIR:-/var/www/configurator-studio}"
COOKIE_JAR="$(mktemp)"
trap 'rm -f "$COOKIE_JAR"' EXIT

echo "== service =="
systemctl --no-pager --full status configurator-studio.service 2>/dev/null | sed -n '1,18p' || true
echo "== health =="
curl -fsS "$BASE/api/health" | python3 -m json.tool

if [ -f "$APP_DIR/.env" ]; then
  USERNAME="$(sed -n 's/^ADMIN_USERNAME=//p' "$APP_DIR/.env" | tail -1)"
  PASSWORD="$(sed -n 's/^ADMIN_PASSWORD=//p' "$APP_DIR/.env" | tail -1)"
else
  USERNAME="${ADMIN_USERNAME:-}"
  PASSWORD="${ADMIN_PASSWORD:-}"
fi

if [ -n "$USERNAME" ] && [ -n "$PASSWORD" ]; then
  LOGIN_JSON="$(python3 -c 'import json,sys; print(json.dumps({"username":sys.argv[1],"password":sys.argv[2]}))' "$USERNAME" "$PASSWORD")"
  curl -fsS -c "$COOKIE_JAR" -H 'Content-Type: application/json' -d "$LOGIN_JSON" "$BASE/api/auth/login" >/dev/null
  echo "== authenticated studio =="
  curl -fsS -b "$COOKIE_JAR" "$BASE/api/studio" | python3 -c 'import json,sys; d=json.load(sys.stdin); print({"ok":d["ok"],"version":d["version"],"project":d["project"]["name"],"gate":d["publish_gate"]["passed"],"assets":len(d["assets"])})'
else
  echo "== auth =="
  curl -fsS "$BASE/api/auth/status" | python3 -m json.tool
fi

echo "== logs =="
journalctl -u configurator-studio.service -n 40 --no-pager 2>/dev/null || true
