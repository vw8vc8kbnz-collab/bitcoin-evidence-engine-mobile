import { validateRules } from './rules.mjs';

export function inspectConfigurability(asset = {}, blueprint = {}) {
  const meshes = asset.mesh_inventory || [];
  const intended = blueprint.parts || [];
  const issues = [];
  if (!meshes.length) issues.push(issue('mesh_inventory_missing', 'blocking', 'Het model heeft nog geen gecontroleerde mesh-inventaris.'));
  if (meshes.filter(m => m.visible !== false).length <= 1 && intended.length > 1) {
    issues.push(issue('merged_mesh', 'blocking', 'Meerdere configureerbare onderdelen zijn gewenst, maar het model lijkt één geheel.'));
  }
  for (const part of intended) {
    const targets = part.mesh_targets || [];
    if (part.configurable !== false && !targets.length) issues.push(issue('part_unmapped', 'blocking', `${part.label || part.part_id} is niet aan geometrie gekoppeld.`, [part.part_id]));
  }
  if (asset.metrics?.triangles > 250000) issues.push(issue('mobile_polycount_high', 'warning', 'Het model is zwaar voor mobiele browsers; optimalisatie aanbevolen.'));
  return { passed: !issues.some(i => i.severity === 'blocking'), status: issues.length ? 'needs_attention' : 'ready', issues };
}

export function runPublishGate({ project, blueprint, asset }) {
  const checks = [];
  const critical = (project.required_fact_keys || []).map(key => {
    const fact = project.facts.find(f => f.key === key);
    return { id: `fact:${key}`, label: fact?.label || key, passed: fact?.status === 'confirmed' && fact?.conflict?.status !== 'open', detail: fact?.status || 'missing' };
  });
  checks.push(...critical);
  const configGate = inspectConfigurability(asset || {}, blueprint || {});
  checks.push({ id: 'configurability', label: 'Model configureerbaar', passed: configGate.passed, detail: configGate.status });
  const basePrice = Number(blueprint?.pricing?.base_price?.amount);
  checks.push({ id: 'base_price', label: 'Basisprijs ingesteld', passed: Number.isFinite(basePrice) && basePrice >= 0, detail: Number.isFinite(basePrice) ? `${basePrice}` : 'missing' });
  const ruleValidation = validateRules(blueprint?.rules || []);
  checks.push({ id: 'rules', label: 'Regels geldig', passed: ruleValidation.valid, detail: ruleValidation.errors.length ? `${ruleValidation.errors.length} fout(en)` : 'valid' });
  checks.push({ id: 'order_output', label: 'Orderuitvoer ingesteld', passed: Boolean((blueprint?.order_output?.fields || []).length), detail: `${blueprint?.order_output?.fields?.length || 0} velden` });
  const unresolved = (project.facts || []).filter(f => f.conflict?.status === 'open');
  checks.push({ id: 'conflicts', label: 'Geen open conflicten', passed: unresolved.length === 0, detail: `${unresolved.length} open` });
  const reviewAccepted = asset?.quality_status === 'accepted';
  checks.push({ id: 'human_review', label: 'Modelreview afgerond', passed: reviewAccepted, detail: asset?.quality_status || 'missing' });
  return { passed: checks.every(c => c.passed), checks, blocking: checks.filter(c => !c.passed) };
}

function issue(code, severity, message, target_ids = []) { return { code, severity, message, target_ids }; }
