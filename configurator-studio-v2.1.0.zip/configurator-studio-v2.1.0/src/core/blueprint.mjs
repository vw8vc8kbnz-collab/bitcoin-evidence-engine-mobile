import { id, nowIso } from './ids.mjs';

export function createDemoBlueprint() {
  return {
    schema_version: '2.1.0',
    blueprint_id: id('blueprint'),
    updated_at: nowIso(),
    parts: [
      {
        part_id: 'part_seat',
        label: 'Zitting en rug',
        scope: 'part',
        type: 'upholstery_shell',
        mesh_targets: ['seat_and_back'],
        configurable: true,
        capabilities: ['material', 'finish', 'pricing', 'rules', 'order_output']
      },
      {
        part_id: 'part_legs',
        label: 'Poten en voetensteun',
        scope: 'part',
        type: 'support_frame',
        mesh_targets: ['legs_and_footrest'],
        configurable: true,
        capabilities: ['material', 'finish', 'pricing', 'rules', 'order_output']
      }
    ],
    option_groups: [
      {
        option_group_id: 'group_seat_color',
        label: 'Kleur zitting',
        target_scope: 'part',
        target_id: 'part_seat',
        control_type: 'swatches',
        effect_type: 'material',
        required: true,
        default_option_id: 'seat_beige',
        options: [
          { option_id: 'seat_beige', label: 'Warm beige', value: '#b9aa99', material: { color: '#b9aa99', roughness: 0.72, metalness: 0.0 } },
          { option_id: 'seat_terracotta', label: 'Terracotta', value: '#a65f42', material: { color: '#a65f42', roughness: 0.70, metalness: 0.0 } },
          { option_id: 'seat_sage', label: 'Saliegroen', value: '#8f9b83', material: { color: '#8f9b83', roughness: 0.74, metalness: 0.0 } },
          { option_id: 'seat_charcoal', label: 'Antraciet', value: '#343638', material: { color: '#343638', roughness: 0.64, metalness: 0.0 } }
        ]
      },
      {
        option_group_id: 'group_leg_finish',
        label: 'Kleur onderstel',
        target_scope: 'part',
        target_id: 'part_legs',
        control_type: 'swatches',
        effect_type: 'material',
        required: true,
        default_option_id: 'legs_black',
        options: [
          { option_id: 'legs_black', label: 'Mat zwart', value: '#222426', material: { color: '#222426', roughness: 0.34, metalness: 0.68 } },
          { option_id: 'legs_walnut', label: 'Walnootbruin', value: '#68452f', material: { color: '#68452f', roughness: 0.58, metalness: 0.05 } },
          { option_id: 'legs_white', label: 'Poederwit', value: '#ecebe7', material: { color: '#ecebe7', roughness: 0.42, metalness: 0.25 } },
          { option_id: 'legs_steel', label: 'Geborsteld staal', value: '#8f9291', material: { color: '#8f9291', roughness: 0.28, metalness: 0.88 } }
        ]
      }
    ],
    pricing: {
      currency: 'EUR',
      base_price: { amount: 429, label: 'Basisprijs' },
      rules: [
        { rule_id: 'price_seat_terracotta', label: 'Terracotta bekleding', type: 'fixed_delta', option_id: 'seat_terracotta', amount: 20, enabled: true },
        { rule_id: 'price_seat_sage', label: 'Saliegroene bekleding', type: 'fixed_delta', option_id: 'seat_sage', amount: 15, enabled: true },
        { rule_id: 'price_seat_charcoal', label: 'Antraciet bekleding', type: 'fixed_delta', option_id: 'seat_charcoal', amount: 30, enabled: true },
        { rule_id: 'price_legs_walnut', label: 'Walnootkleurig onderstel', type: 'fixed_delta', option_id: 'legs_walnut', amount: 35, enabled: true },
        { rule_id: 'price_legs_white', label: 'Poederwit onderstel', type: 'fixed_delta', option_id: 'legs_white', amount: 15, enabled: true },
        { rule_id: 'price_legs_steel', label: 'Geborsteld stalen onderstel', type: 'fixed_delta', option_id: 'legs_steel', amount: 60, enabled: true }
      ]
    },
    rules: [],
    workflow_ack: { rules_reviewed: true },
    commerce: {
      adapter: 'generic_embed',
      cart_action: 'post_message',
      allowed_origins: ['*']
    },
    branding: {
      theme: 'atelier',
      accent_color: '#305c49',
      layout: 'side_panel',
      show_price: true
    },
    order_output: {
      fields: [
        { field_id: 'configuration_id', label: 'Configuratie-ID', source: 'system.configuration_id', required: true },
        { field_id: 'seat_color', label: 'Kleur zitting', source: 'selection_label.group_seat_color', required: true },
        { field_id: 'leg_finish', label: 'Kleur onderstel', source: 'selection_label.group_leg_finish', required: true },
        { field_id: 'product_reference', label: 'Productreferentie', source: 'static.ARC-CHAIR', required: true },
        { field_id: 'total_price', label: 'Verkoopprijs', source: 'product.price', required: true },
        { field_id: 'preview_image', label: 'Voorbeeldafbeelding', source: 'system.preview_url', required: false }
      ]
    }
  };
}
