const ALLOWED_ACTIONS = new Set([
  'show_option','hide_option','disable_option','require_option','set_default',
  'show_warning','set_order_field','enable_pricing_rule','disable_pricing_rule',
  'add_lead_time','limit_dimension','switch_mesh','switch_material'
]);

function compare(actual, operator, expected) {
  switch (operator) {
    case 'eq': return actual === expected;
    case 'neq': return actual !== expected;
    case 'in': return Array.isArray(expected) && expected.includes(actual);
    case 'gt': return Number(actual) > Number(expected);
    case 'gte': return Number(actual) >= Number(expected);
    case 'lt': return Number(actual) < Number(expected);
    case 'lte': return Number(actual) <= Number(expected);
    case 'contains': return Array.isArray(actual) ? actual.includes(expected) : String(actual || '').includes(String(expected));
    default: return false;
  }
}

export function validateRules(rules = []) {
  const errors = [];
  for (const rule of rules) {
    for (const effect of rule.then || []) {
      if (!ALLOWED_ACTIONS.has(effect.action)) errors.push({ rule_id: rule.rule_id, message: `Actie ${effect.action} is niet toegestaan.` });
    }
  }
  return { valid: errors.length === 0, errors };
}

export function evaluateRules({ rules = [], configuration = {}, facts = [] }) {
  const factValues = Object.fromEntries(facts.map(f => [f.key, f.value]));
  const state = {
    hidden_options: [], disabled_options: [], required_options: [], warnings: [],
    enabled_pricing_rules: [], disabled_pricing_rules: [], order_fields: {}, lead_time_days: 0,
    invalid: false, conflicts: []
  };

  for (const rule of rules.filter(r => r.enabled !== false)) {
    const met = (rule.if || []).every(condition => {
      const source = condition.source === 'fact' ? factValues : configuration;
      return compare(source[condition.field], condition.operator || 'eq', condition.value);
    });
    if (!met) continue;
    for (const effect of rule.then || []) {
      if (!ALLOWED_ACTIONS.has(effect.action)) continue;
      const value = effect.value ?? effect.option_id ?? effect.rule_id;
      if (effect.action === 'hide_option') state.hidden_options.push(value);
      if (effect.action === 'disable_option') state.disabled_options.push(value);
      if (effect.action === 'require_option') state.required_options.push(value);
      if (effect.action === 'show_warning') state.warnings.push(effect.message || String(value));
      if (effect.action === 'enable_pricing_rule') state.enabled_pricing_rules.push(value);
      if (effect.action === 'disable_pricing_rule') state.disabled_pricing_rules.push(value);
      if (effect.action === 'set_order_field') state.order_fields[effect.field] = effect.value;
      if (effect.action === 'add_lead_time') state.lead_time_days += Number(effect.days || effect.value || 0);
    }
  }

  const hidden = new Set(state.hidden_options);
  const disabled = new Set(state.disabled_options);
  const required = new Set(state.required_options);
  for (const option of required) {
    if (hidden.has(option) || disabled.has(option)) {
      state.invalid = true;
      state.conflicts.push({ option_id: option, message: 'Een verplichte keuze is tegelijk verborgen of uitgeschakeld.' });
    }
  }
  return state;
}
