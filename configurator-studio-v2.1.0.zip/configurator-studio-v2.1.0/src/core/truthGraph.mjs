import { id, nowIso } from './ids.mjs';

const AUTHORITATIVE_METHODS = new Set([
  'user_confirmed', 'admin_confirmed', 'measured', 'imported_verified'
]);

export function deriveFactStatus(fact = {}) {
  if (fact.conflict?.status === 'open') return 'conflicting';
  if (fact.verified?.by && fact.verified?.method && fact.verified.method !== 'none') return 'confirmed';
  if (Array.isArray(fact.candidates) && fact.candidates.length) return 'inferred';
  return 'missing';
}

export function pricingAllowed(fact = {}) {
  if (deriveFactStatus(fact) !== 'confirmed') return false;
  if (fact.value_type === 'measurement') return AUTHORITATIVE_METHODS.has(fact.verified?.method);
  return true;
}

export function normalizeCandidateFact(candidate, source = 'openai_product_architect') {
  const value = candidate?.value ?? null;
  const valueType = candidate?.value_type || (candidate?.unit ? 'measurement' : 'text');
  const fact = {
    fact_id: candidate?.fact_id || id('fact'),
    key: String(candidate?.key || 'unknown'),
    label: candidate?.label || String(candidate?.key || 'Onbekend gegeven'),
    value: null,
    unit: candidate?.unit || null,
    value_type: valueType,
    critical: Boolean(candidate?.critical),
    candidates: value === null ? [] : [{
      candidate_id: id('cand'),
      value,
      unit: candidate?.unit || null,
      provenance: candidate?.provenance || 'ai_inferred',
      source,
      confidence: Number.isFinite(Number(candidate?.confidence)) ? Number(candidate.confidence) : null,
      created_at: nowIso()
    }],
    verified: { by: null, method: 'none', at: null },
    conflict: null,
    status: value === null ? 'missing' : 'inferred',
    pricing_allowed: false,
    updated_at: nowIso()
  };
  return fact;
}

export function mergeCandidateFacts(existing = [], incoming = []) {
  const map = new Map(existing.map(f => [f.key, structuredClone(f)]));
  for (const raw of incoming) {
    const next = normalizeCandidateFact(raw);
    const current = map.get(next.key);
    if (!current) {
      map.set(next.key, next);
      continue;
    }
    for (const candidate of next.candidates) {
      const duplicate = (current.candidates || []).some(c => JSON.stringify(c.value) === JSON.stringify(candidate.value));
      if (!duplicate) current.candidates = [...(current.candidates || []), candidate];
    }
    current.critical = current.critical || next.critical;
    current.label = current.label || next.label;
    const distinct = new Set((current.candidates || []).map(c => JSON.stringify(c.value)));
    if (distinct.size > 1 && !current.verified?.by) {
      current.conflict = {
        conflict_id: id('conflict'),
        status: 'open',
        values: [...distinct].map(v => JSON.parse(v)),
        opened_at: nowIso()
      };
    }
    current.status = deriveFactStatus(current);
    current.pricing_allowed = pricingAllowed(current);
    current.updated_at = nowIso();
    map.set(current.key, current);
  }
  return [...map.values()];
}

export function confirmFact(fact, { value, unit = null, by = 'user', method = 'user_confirmed' }) {
  if (!AUTHORITATIVE_METHODS.has(method)) throw new Error(`Verification method not allowed: ${method}`);
  const updated = structuredClone(fact);
  updated.value = value;
  updated.unit = unit ?? updated.unit ?? null;
  updated.verified = { by, method, at: nowIso() };
  updated.conflict = updated.conflict ? { ...updated.conflict, status: 'resolved', resolved_value: value, resolved_at: nowIso(), resolved_by: by } : null;
  updated.status = deriveFactStatus(updated);
  updated.pricing_allowed = pricingAllowed(updated);
  updated.updated_at = nowIso();
  return updated;
}

export function factMap(facts = []) {
  return new Map(facts.map(f => [f.key, f]));
}

export function criticalFactGate(facts = [], requiredKeys = []) {
  const byKey = factMap(facts);
  const fields = requiredKeys.map(key => {
    const fact = byKey.get(key);
    const passed = Boolean(fact && deriveFactStatus(fact) === 'confirmed' && fact.conflict?.status !== 'open');
    return { key, passed, status: fact ? deriveFactStatus(fact) : 'missing' };
  });
  return { passed: fields.every(f => f.passed), fields };
}
