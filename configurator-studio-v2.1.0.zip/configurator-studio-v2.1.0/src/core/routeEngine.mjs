export const ROUTES = Object.freeze({
  UPLOADED: 'uploaded_asset',
  PARAMETRIC: 'parametric_cad',
  PHOTO_BALANCED: 'photo_reconstruction_balanced',
  PHOTO_FAST: 'photo_reconstruction_fast',
  PHOTO_PREMIUM: 'photo_reconstruction_premium',
  MATERIAL: 'material_studio',
  CLARIFY: 'clarification_required'
});

const PARAMETRIC_CATEGORIES = new Set([
  'table', 'cabinet', 'shelf', 'door', 'panel', 'frame', 'wardrobe', 'desk',
  'tafel', 'kast', 'plank', 'deur', 'paneel', 'bureau'
]);

function confirmed(facts, key) {
  const fact = facts.find(f => f.key === key);
  return Boolean(fact?.status === 'confirmed' && fact?.value !== null && fact?.value !== undefined);
}

export function chooseProductRoute({ intake = {}, facts = [], assets = [], requested_profile = 'auto', providerAvailability = {} }) {
  const uploaded3d = assets.find(a => ['glb','gltf','obj','fbx','step','stp'].includes(String(a.extension || '').toLowerCase()));
  if (uploaded3d) {
    return decision(ROUTES.UPLOADED, 'Er is al een bruikbaar 3D/CAD-bestand aangeleverd.', [], ['asset_inspection','configurability_gate']);
  }

  const category = String(intake.category || intake.product_category || '').toLowerCase();
  const dimensionsConfirmed = ['dimensions.length_mm','dimensions.width_mm','dimensions.height_mm'].every(k => confirmed(facts, k));
  const templateCapable = [...PARAMETRIC_CATEGORIES].some(v => category.includes(v));
  if ((requested_profile === 'exact' || requested_profile === 'auto') && templateCapable && dimensionsConfirmed && providerAvailability.freecad) {
    return decision(ROUTES.PARAMETRIC, 'Het product is parametrisch op te bouwen en de hoofdmaatvoering is bevestigd.', [], ['freecad_generation','asset_optimization','configurability_gate']);
  }

  const images = assets.filter(a => a.kind === 'image');
  if (images.length) {
    if (requested_profile === 'fast' && providerAvailability.tripo) {
      return decision(ROUTES.PHOTO_FAST, 'Snelle reconstructieroute gekozen voor een eerste configureerbare draft.', [], ['tripo_generation','optional_segmentation','human_review']);
    }
    if (requested_profile === 'premium' && providerAvailability.rodin) {
      return decision(ROUTES.PHOTO_PREMIUM, 'Detailroute gekozen voor een hoogwaardige PBR-draft.', [], ['rodin_generation','optional_segmentation','human_review']);
    }
    if (providerAvailability.meshy) {
      return decision(ROUTES.PHOTO_BALANCED, images.length > 1
        ? 'Meerdere aanzichten beschikbaar; multi-image reconstructie is de sterkste gebalanceerde route.'
        : 'Eén productfoto beschikbaar; de engine maakt een volledige reconstructiedraft en markeert onzichtbare zijden als onzeker.',
      [], ['meshy_generation','remesh_if_needed','human_review']);
    }
    if (providerAvailability.tripo) return decision(ROUTES.PHOTO_FAST, 'Fotoreconstructie via de beschikbare snelle route.', [], ['tripo_generation','human_review']);
    if (providerAvailability.rodin) return decision(ROUTES.PHOTO_PREMIUM, 'Fotoreconstructie via de beschikbare detailroute.', [], ['rodin_generation','human_review']);
    return decision(ROUTES.CLARIFY, 'Er zijn foto’s, maar geen live 3D-provider is geconfigureerd.', ['Configureer minimaal één 3D-provider API-sleutel.'], []);
  }

  const missing = [];
  if ((requested_profile === 'exact' || requested_profile === 'auto') && templateCapable && dimensionsConfirmed && !providerAvailability.freecad) missing.push('FreeCAD + Blender installatie');
  if (!category) missing.push('productcategorie');
  if (!assets.length) missing.push('foto’s of bestaand 3D-model');
  return decision(ROUTES.CLARIFY, 'Er is nog onvoldoende bronmateriaal om verantwoord een modelroute te starten.', missing, []);
}

function decision(route, reason, missing, pipeline) {
  return { route, reason, missing, pipeline, provider_output_is_candidate_only: true, automatic_publish_allowed: false };
}
