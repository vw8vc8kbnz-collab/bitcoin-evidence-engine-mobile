import { id, nowIso } from './ids.mjs';
import { runPublishGate } from './gates.mjs';

export function compileRuntime({ project, blueprint, asset }) {
  const gate = runPublishGate({ project, blueprint, asset });
  if (!gate.passed) {
    const error = new Error('Publicatie geblokkeerd door onvoltooide controles.');
    error.code = 'PUBLISH_GATE_BLOCKED';
    error.gate = gate;
    throw error;
  }
  const runtime = {
    schema_version: '2.1.0',
    runtime_config_id: id('runtime'),
    project_id: project.project_id,
    workspace_id: project.workspace_id,
    version: Number(project.runtime_version || 0) + 1,
    immutable: true,
    published_at: nowIso(),
    asset: {
      asset_id: asset.asset_id,
      glb_url: asset.public_url,
      poster_url: asset.poster_url || '/assets/demo-chair-preview.png'
    },
    product: {
      name: project.name,
      description: project.description || '',
      currency: blueprint.pricing?.currency || 'EUR'
    },
    parts: (blueprint.parts || []).map(({ internal_notes, ...part }) => part),
    option_groups: blueprint.option_groups || [],
    pricing: blueprint.pricing || {},
    rules: blueprint.rules || [],
    order_output: blueprint.order_output || { fields: [] },
    commerce: blueprint.commerce || { adapter: 'generic_embed', cart_action: 'post_message', allowed_origins: ['*'] },
    branding: { powered_by_visible: true, label: 'Made with Configurator Studio', ...(blueprint.branding || {}) },
    facts: (project.facts || []).filter(fact => fact.status === 'confirmed').map(({ candidates, conflict, ...fact }) => fact),
    safety: { unresolved_ai_facts_included: false, provider_metadata_included: false }
  };
  return deepFreeze(runtime);
}

function deepFreeze(value) {
  if (!value || typeof value !== 'object' || Object.isFrozen(value)) return value;
  for (const child of Object.values(value)) deepFreeze(child);
  return Object.freeze(value);
}
