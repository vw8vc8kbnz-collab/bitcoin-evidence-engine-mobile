function amount(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) throw new Error('Prijsbedrag is ongeldig.');
  return n;
}

function authoritative(facts, key) {
  const fact = facts.find(f => f.key === key);
  if (!fact?.pricing_allowed) throw new Error(`Prijsregel geblokkeerd: ${key} is niet bevestigd.`);
  return amount(fact.value);
}

export function calculatePrice({ pricing = {}, selected_option_ids = [], facts = [], quantity = 1 }) {
  const base = amount(pricing.base_price?.amount ?? 0);
  let running = base;
  const breakdown = [{ id: 'base', label: pricing.base_price?.label || 'Basisprijs', amount: base }];

  for (const rule of pricing.rules || []) {
    if (rule.enabled === false) continue;
    if (rule.option_id && !selected_option_ids.includes(rule.option_id)) continue;
    let delta = 0;
    switch (rule.type) {
      case 'fixed_delta': delta = amount(rule.amount || 0); break;
      case 'percentage_delta': delta = running * amount(rule.percent || 0) / 100; break;
      case 'area_based': {
        const length = authoritative(facts, rule.length_key || 'dimensions.length_mm');
        const width = authoritative(facts, rule.width_key || 'dimensions.width_mm');
        delta = (length / 1000) * (width / 1000) * amount(rule.rate_per_m2 || 0);
        break;
      }
      case 'perimeter_based': {
        const length = authoritative(facts, rule.length_key || 'dimensions.length_mm');
        const width = authoritative(facts, rule.width_key || 'dimensions.width_mm');
        delta = ((length + width) * 2 / 1000) * amount(rule.rate_per_meter || 0);
        break;
      }
      case 'quantity_tier': {
        const tiers = [...(rule.tiers || [])].sort((a,b) => Number(a.min) - Number(b.min));
        const tier = tiers.filter(t => quantity >= Number(t.min)).at(-1);
        delta = tier ? amount(tier.amount || 0) : 0;
        break;
      }
      default: throw new Error(`Onbekend prijsregeltype: ${rule.type}`);
    }
    delta = Math.round(delta * 100) / 100;
    running += delta;
    breakdown.push({ id: rule.rule_id, label: rule.label || 'Meerprijs', amount: delta });
  }

  const unitTotal = Math.round(running * 100) / 100;
  return { currency: pricing.currency || 'EUR', unit_total: unitTotal, quantity, total: Math.round(unitTotal * quantity * 100) / 100, breakdown };
}
