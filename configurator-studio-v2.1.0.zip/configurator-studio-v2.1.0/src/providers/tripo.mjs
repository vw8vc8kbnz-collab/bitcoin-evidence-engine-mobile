import path from 'node:path';
import { apiFetch, pollTask, downloadFile, parseDataUri } from './common.mjs';

const VIEW_ORDER = ['front', 'left', 'back', 'right'];

function extensionFromMime(mime = '') {
  const normalized = String(mime).toLowerCase();
  if (normalized.includes('jpeg') || normalized.includes('jpg')) return 'jpg';
  if (normalized.includes('webp')) return 'webp';
  return 'png';
}

export function buildTripoGenerationPayload(uploadedImages, modelVersion = 'P1-20260311') {
  if (!Array.isArray(uploadedImages) || uploadedImages.length === 0) throw new Error('Minimaal één Tripo-afbeelding vereist.');
  const p1 = String(modelVersion).startsWith('P1-');
  const multi = uploadedImages.length > 1;
  const sourceFiles = uploadedImages.slice(0, 4).map(image => ({ type:image.type, file_token:image.token }));

  const payload = {
    type: multi ? 'multiview_to_model' : 'image_to_model',
    model_version:modelVersion,
    texture:true,
    pbr:true,
    texture_quality:'detailed'
  };

  if (multi) {
    if (p1) {
      // P1 requires exactly [front, left, back, right]. Missing views keep their slot
      // but intentionally omit file_token; front plus at least one other view is required.
      payload.files = VIEW_ORDER.map((_, index) => sourceFiles[index] || { type:'png' });
    } else {
      payload.files = sourceFiles.map((file, index) => ({ ...file, view:VIEW_ORDER[index] }));
    }
  } else {
    payload.file = sourceFiles[0];
  }

  if (p1) {
    payload.face_limit = 20000;
    payload.auto_size = true;
    payload.compress = 'geometry';
    payload.texture_alignment = 'geometry';
    payload.orientation = 'align_image';
  } else {
    // These richer generation controls are supported by H-series models, not P1.
    payload.geometry_quality = 'detailed';
    payload.generate_parts = true;
    payload.smart_low_poly = true;
    payload.autofix = true;
  }
  return payload;
}

export class TripoProvider {
  constructor(config) { this.config = config; }
  get available() { return Boolean(this.config.apiKey); }

  async uploadImage(image) {
    if (image.file_token) return { token:image.file_token, type:image.file_type || 'png' };
    const { mime, buffer } = parseDataUri(image.data_url);
    const type = extensionFromMime(mime);
    const fallbackName = `reference.${type === 'jpg' ? 'jpg' : type}`;
    const form = new FormData();
    form.append('file', new Blob([buffer], { type:mime }), image.name || fallbackName);
    const result = await apiFetch(`${this.config.baseUrl}/upload`, {
      method:'POST', headers:{ Authorization:`Bearer ${this.config.apiKey}` }, body:form
    }, 'Tripo upload');
    const token = result?.data?.image_token || result?.data?.file_token || result?.image_token || result?.file_token;
    return { token, type };
  }

  async generate({ images, outputDir, jobId, onProgress = () => {} }) {
    if (!this.available) throw new Error('Tripo API-sleutel ontbreekt.');
    if (!images?.length) throw new Error('Tripo vereist minimaal één afbeelding.');
    await onProgress({progress:8,message:'Referentiebeelden veilig uploaden…'});
    const uploaded = [];
    for (const image of images.slice(0,4)) {
      const result = await this.uploadImage(image);
      if (!result.token) throw new Error('Tripo upload leverde geen image token op.');
      uploaded.push(result);
    }
    const payload = buildTripoGenerationPayload(uploaded, this.config.modelVersion || 'P1-20260311');
    const created = await apiFetch(`${this.config.baseUrl}/task`, {
      method:'POST', headers:{ Authorization:`Bearer ${this.config.apiKey}`, 'Content-Type':'application/json' }, body:JSON.stringify(payload)
    }, 'Tripo');
    const taskId = created?.data?.task_id || created?.task_id;
    if (!taskId) throw new Error('Tripo leverde geen task-id op.');
    const final = await pollTask({
      read: () => apiFetch(`${this.config.baseUrl}/task/${taskId}`, { headers:{ Authorization:`Bearer ${this.config.apiKey}` } }, 'Tripo'),
      isDone: x => ['success','succeeded'].includes(String(x?.data?.status || x?.status).toLowerCase()),
      isFailed: x => ['failed','cancelled','canceled','banned','expired'].includes(String(x?.data?.status || x?.status).toLowerCase()),
      onProgress: x => onProgress({progress:Math.max(12, Number(x?.data?.progress || x?.progress || 0)),message:'Tripo maakt een snelle configureerbare draft…',provider_task_id:taskId})
    });
    const output = final?.data?.output || final?.output || {};
    const glbUrl = output?.pbr_model || output?.model || output?.base_model || output?.glb;
    if (!glbUrl) throw new Error('Tripo leverde geen downloadbare GLB op.');
    const filename = `${jobId}-tripo.glb`;
    await downloadFile(glbUrl, path.join(outputDir, filename));
    return {
      provider:'tripo', provider_task_id:taskId, file_name:filename,
      poster_url:output?.rendered_image || output?.thumbnail || null,
      provider_previews:{},
      metrics:{pbr:true,model_version:payload.model_version,parts_requested:Boolean(payload.generate_parts)},
      raw_summary:{status:final?.data?.status || final?.status}
    };
  }
}
