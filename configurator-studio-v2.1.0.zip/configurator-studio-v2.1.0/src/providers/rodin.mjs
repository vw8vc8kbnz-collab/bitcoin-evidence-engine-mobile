import path from 'node:path';
import { apiFetch, pollTask, downloadFile, parseDataUri } from './common.mjs';

const DONE = new Set(['done','completed','succeeded','success']);
const FAILED = new Set(['failed','error','canceled','cancelled']);
const normalize = value => String(value || '').toLowerCase();

export function rodinJobs(payload) {
  if (Array.isArray(payload?.jobs)) return payload.jobs;
  return payload?.status ? [payload] : [];
}

export function rodinStatusDone(payload) {
  const jobs = rodinJobs(payload);
  return jobs.length > 0 && jobs.every(job => DONE.has(normalize(job?.status)));
}

export function rodinStatusFailed(payload) {
  return rodinJobs(payload).some(job => FAILED.has(normalize(job?.status)));
}

export class RodinProvider {
  constructor(config) { this.config = config; }
  get available() { return Boolean(this.config.apiKey); }

  async generate({ images, prompt = '', outputDir, jobId, onProgress = () => {} }) {
    if (!this.available) throw new Error('Hyper3D/Rodin API-sleutel ontbreekt.');
    if (!images?.length) throw new Error('Rodin vereist minimaal één afbeelding.');
    const form = new FormData();
    for (const image of images.slice(0,5)) {
      const { mime, buffer } = parseDataUri(image.data_url);
      form.append('images', new Blob([buffer], {type:mime}), image.name || 'reference.png');
    }
    form.append('tier', this.config.tier || 'Gen-2');
    form.append('mesh_mode','Raw');
    form.append('quality_override','500000');
    form.append('material','PBR');
    form.append('geometry_file_format','glb');
    if (prompt) form.append('prompt', prompt.slice(0, 800));
    const created = await apiFetch(`${this.config.baseUrl}/rodin`, {
      method:'POST', headers:{ Authorization:`Bearer ${this.config.apiKey}` }, body:form
    }, 'Rodin');
    const subscriptionKey = created?.jobs?.subscription_key || created?.subscription_key;
    const taskUuid = created?.uuid || created?.task_uuid || created?.jobs?.uuid;
    if (!subscriptionKey || !taskUuid) throw new Error('Rodin leverde geen complete taakreferentie op.');
    const final = await pollTask({
      read: () => apiFetch(`${this.config.baseUrl}/status`, {
        method:'POST', headers:{ Authorization:`Bearer ${this.config.apiKey}`, 'Content-Type':'application/json' },
        body:JSON.stringify({subscription_key:subscriptionKey})
      }, 'Rodin status'),
      isDone:rodinStatusDone,
      isFailed:rodinStatusFailed,
      onProgress: x => {
        const jobs = rodinJobs(x);
        const values = jobs.map(job => Number(job?.progress || 0)).filter(Number.isFinite);
        const progress = values.length ? values.reduce((a,b) => a + b, 0) / values.length : 0;
        return onProgress({progress:Math.max(10, progress),message:'Rodin bouwt de premium PBR-draft…',provider_task_id:taskUuid});
      }
    });
    const download = await apiFetch(`${this.config.baseUrl}/download`, {
      method:'POST', headers:{ Authorization:`Bearer ${this.config.apiKey}`, 'Content-Type':'application/json' },
      body:JSON.stringify({task_uuid:taskUuid})
    }, 'Rodin download');
    const list = download?.list || download?.files || [];
    const glb = list.find(x => String(x?.name || x?.url || '').toLowerCase().includes('.glb')) || list[0];
    const glbUrl = glb?.url || glb?.download_url || download?.url;
    if (!glbUrl) throw new Error('Rodin leverde geen GLB-download op.');
    const filename = `${jobId}-rodin.glb`;
    await downloadFile(glbUrl, path.join(outputDir, filename));
    return {
      provider:'rodin', provider_task_id:taskUuid, file_name:filename, poster_url:null,
      provider_previews:{}, metrics:{pbr:true,premium:true,tier:this.config.tier || 'Gen-2'},
      raw_summary:{status:rodinJobs(final).map(job => job.status)}
    };
  }
}
