import path from 'node:path';
import fs from 'node:fs';
import { spawn } from 'node:child_process';

export class FreeCADProvider {
  constructor(config) { this.config = config; }
  async generate({ template = 'table', params, outputDir, jobId, root, onProgress = () => {} }) {
    const requestPath = path.join(outputDir, `${jobId}-cad-request.json`);
    const resultPath = path.join(outputDir, `${jobId}-cad-result.json`);
    await fs.promises.writeFile(requestPath, JSON.stringify({job_id:jobId,template,params,output_dir:outputDir,result_path:resultPath}, null, 2));
    await onProgress({progress:15,message:'Exact parametrisch model voorbereiden…'});
    await run(this.config.freecadCmd, [path.join(root,'server/freecad_worker/worker.py'), requestPath], 8 * 60 * 1000);
    const result = JSON.parse(await fs.promises.readFile(resultPath, 'utf8'));
    if (!result.ok) throw new Error(result.error || 'FreeCAD worker failed.');
    let glbName = result.glb_file || null;
    if (!glbName && result.obj_file) {
      await onProgress({progress:72,message:'CAD-model optimaliseren voor de browser…'});
      const blenderScript = path.join(root,'server/asset_pipeline/convert_to_glb.py');
      const glbPath = path.join(outputDir, `${jobId}-freecad.glb`);
      await run(this.config.blenderCmd, ['--background','--python',blenderScript,'--',path.join(outputDir,result.obj_file),glbPath], 8 * 60 * 1000);
      glbName = path.basename(glbPath);
    }
    if (!glbName) throw new Error('FreeCAD-route kon geen GLB maken; installeer ook Blender voor webconversie.');
    return { provider:'freecad', provider_task_id:jobId, file_name:glbName, poster_url:null, provider_previews:{}, metrics:result.metrics || {}, mesh_inventory:result.mesh_inventory || [], raw_summary:{template,result_files:result.files || []} };
  }
}

function run(command, args, timeoutMs) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, {stdio:['ignore','pipe','pipe']});
    let stdout='', stderr='';
    child.stdout.on('data',d => stdout += d);
    child.stderr.on('data',d => stderr += d);
    const timer = setTimeout(() => { child.kill('SIGKILL'); reject(new Error(`${command} timeout`)); }, timeoutMs);
    child.on('error', error => { clearTimeout(timer); reject(new Error(`${command} kon niet starten: ${error.message}`)); });
    child.on('close', code => { clearTimeout(timer); code === 0 ? resolve({stdout,stderr}) : reject(new Error(`${command} stopte met code ${code}: ${stderr || stdout}`)); });
  });
}
