import fs from 'node:fs';
import path from 'node:path';

export const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

export async function apiFetch(url, options = {}, label = 'provider') {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), options.timeoutMs || 120000);
  try {
    const response = await fetch(url, { ...options, signal: controller.signal });
    const text = await response.text();
    let payload;
    try { payload = text ? JSON.parse(text) : {}; } catch { payload = { raw: text }; }
    if (!response.ok) {
      const message = payload?.message || payload?.error?.message || payload?.detail || payload?.raw || `${response.status} ${response.statusText}`;
      const error = new Error(`${label}: ${message}`);
      error.status = response.status;
      error.payload = payload;
      throw error;
    }
    return payload;
  } finally {
    clearTimeout(timeout);
  }
}

export async function pollTask({ read, isDone, isFailed, intervalMs = 5000, timeoutMs = 20 * 60 * 1000, onProgress = () => {} }) {
  const started = Date.now();
  let last;
  while (Date.now() - started < timeoutMs) {
    last = await read();
    await onProgress(last);
    if (isDone(last)) return last;
    if (isFailed(last)) {
      const message = last?.task_error?.message || last?.error?.message || last?.error || 'Provider task failed';
      throw new Error(String(message));
    }
    await sleep(intervalMs);
  }
  const error = new Error('Provider task timed out.');
  error.lastState = last;
  throw error;
}

export function parseDataUri(dataUri) {
  const match = /^data:([^;,]+);base64,(.+)$/s.exec(String(dataUri || ''));
  if (!match) throw new Error('Ongeldige data-URI.');
  return { mime: match[1], buffer: Buffer.from(match[2], 'base64') };
}

export async function saveDataUri(dataUri, targetPath) {
  const { buffer } = parseDataUri(dataUri);
  await fs.promises.mkdir(path.dirname(targetPath), { recursive: true });
  await fs.promises.writeFile(targetPath, buffer);
  return targetPath;
}

export async function downloadFile(url, targetPath, headers = {}) {
  const response = await fetch(url, { headers });
  if (!response.ok) throw new Error(`Download mislukt: HTTP ${response.status}`);
  const arrayBuffer = await response.arrayBuffer();
  await fs.promises.mkdir(path.dirname(targetPath), { recursive: true });
  await fs.promises.writeFile(targetPath, Buffer.from(arrayBuffer));
  return targetPath;
}

export function extractOpenAIText(response) {
  if (typeof response?.output_text === 'string') return response.output_text;
  const chunks = [];
  for (const item of response?.output || []) {
    for (const content of item?.content || []) {
      if (typeof content?.text === 'string') chunks.push(content.text);
      if (typeof content?.output_text === 'string') chunks.push(content.output_text);
    }
  }
  return chunks.join('\n');
}

export function safeJson(text) {
  try { return JSON.parse(text); }
  catch (error) { throw new Error(`Provider gaf geen geldige JSON terug: ${error.message}`); }
}
