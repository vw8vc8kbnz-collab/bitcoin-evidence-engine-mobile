import { apiFetch, extractOpenAIText, safeJson } from './common.mjs';

const schema = {
  type: 'object', additionalProperties: false,
  required: ['summary','category','candidate_facts','clarification_questions','configuration_plan','risk_notes'],
  properties: {
    summary: { type: 'string' },
    category: { type: 'string' },
    candidate_facts: {
      type: 'array', items: {
        type: 'object', additionalProperties: false,
        required: ['key','label','value','unit','value_type','critical','confidence','provenance'],
        properties: {
          key: { type: 'string' }, label: { type: 'string' },
          value: { anyOf: [{type:'string'},{type:'number'},{type:'boolean'},{type:'null'}] },
          unit: { anyOf: [{type:'string'},{type:'null'}] },
          value_type: { enum: ['measurement','text','number','boolean','enum'] },
          critical: { type: 'boolean' }, confidence: { anyOf: [{type:'number'},{type:'null'}] },
          provenance: { type: 'string' }
        }
      }
    },
    clarification_questions: { type: 'array', items: { type: 'string' } },
    configuration_plan: {
      type: 'object', additionalProperties: false,
      required: ['parts','option_groups','recommended_route_profile'],
      properties: {
        parts: { type: 'array', items: { type: 'object', additionalProperties: false, required:['label','capabilities'], properties: { label:{type:'string'}, capabilities:{type:'array',items:{type:'string'}} } } },
        option_groups: { type: 'array', items: { type: 'object', additionalProperties: false, required:['label','target_part','option_examples'], properties: { label:{type:'string'}, target_part:{type:'string'}, option_examples:{type:'array',items:{type:'string'}} } } },
        recommended_route_profile: { enum: ['auto','exact','fast','balanced','premium'] }
      }
    },
    risk_notes: { type: 'array', items: { type: 'string' } }
  }
};

export class OpenAIProductArchitect {
  constructor(config) { this.config = config; }
  get available() { return Boolean(this.config.apiKey); }

  async analyze({ prompt = '', images = [] }) {
    if (!this.available) return demoAnalysis(prompt, images.length);
    const content = [{ type: 'input_text', text: systemPrompt(prompt, images.length) }];
    for (const image of images.slice(0, 5)) content.push({ type: 'input_image', image_url: image.data_url || image.public_url, detail: 'high' });
    const response = await apiFetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: { Authorization: `Bearer ${this.config.apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: this.config.model,
        input: [{ role: 'user', content }],
        text: { format: { type: 'json_schema', name: 'product_architect_result', strict: true, schema } }
      })
    }, 'OpenAI Product Architect');
    return safeJson(extractOpenAIText(response));
  }
}

function systemPrompt(prompt, imageCount) {
  return `Je bent de Product Architect van een no-code 3D-configuratorplatform. Analyseer het product en ontwerp een configureerbare structuur.\n\nBELANGRIJKE REGELS:\n- Noem zichtbare observaties kandidaten, nooit feiten.\n- Schat afmetingen alleen als onzekere measurement candidates; deze mogen nooit automatisch prijsbepalend zijn.\n- Vraag expliciet om ontbrekende kritieke maatvoering.\n- Adviseer alleen capabilities die logisch zijn voor het geselecteerde onderdeel.\n- Een foto is geen bewijs van verborgen geometrie.\n- Lever compacte Nederlandse labels.\n\nKlantbeschrijving: ${prompt || 'Geen beschrijving'}\nAantal beelden: ${imageCount}`;
}

function demoAnalysis(prompt, imageCount) {
  const lower = String(prompt).toLowerCase();
  const category = lower.includes('kast') ? 'cabinet' : lower.includes('deur') ? 'door' : lower.includes('bank') ? 'sofa' : 'table';
  return {
    summary: prompt || 'Configureerbaar productconcept', category,
    candidate_facts: [
      { key:'product.category', label:'Productcategorie', value:category, unit:null, value_type:'text', critical:false, confidence:0.82, provenance:'ai_inferred_demo' },
      { key:'dimensions.length_mm', label:'Lengte', value:null, unit:'mm', value_type:'measurement', critical:true, confidence:null, provenance:'missing_user_input' },
      { key:'dimensions.width_mm', label:'Breedte', value:null, unit:'mm', value_type:'measurement', critical:true, confidence:null, provenance:'missing_user_input' },
      { key:'dimensions.height_mm', label:'Hoogte', value:null, unit:'mm', value_type:'measurement', critical:true, confidence:null, provenance:'missing_user_input' }
    ],
    clarification_questions: ['Wat zijn de exacte lengte, breedte en hoogte in millimeters?', ...(imageCount ? [] : ['Upload één tot vier duidelijke productfoto’s of een bestaand 3D-bestand.'])],
    configuration_plan: {
      parts: [{label:'Hoofdoppervlak',capabilities:['material','finish','pricing']},{label:'Onderstel of behuizing',capabilities:['material','visibility','pricing']}],
      option_groups: [{label:'Materiaal',target_part:'Hoofdoppervlak',option_examples:['Naturel','Donker','Zwart']}],
      recommended_route_profile: 'auto'
    },
    risk_notes: ['Demo-analyse actief: configureer OPENAI_API_KEY voor live vision-analyse.']
  };
}
