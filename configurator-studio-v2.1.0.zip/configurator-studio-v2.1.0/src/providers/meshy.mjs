import path from 'node:path';
import { apiFetch, pollTask, downloadFile } from './common.mjs';

export function buildMeshyReconstructionPayload(images, prompt = '') {
  if (!images?.length) throw new Error('Meshy vereist minimaal één afbeelding.');
  const multi = images.length > 1;
  const imageValues = images.slice(0, 4).map(i => i.data_url || i.public_url);
  return {
    ai_model:'latest', should_texture:true, enable_pbr:true, hd_texture:true,
    should_remesh:true, topology:'triangle', target_polycount:70000,
    image_enhancement:true, remove_lighting:true, moderation:true,
    target_formats:['glb'], auto_size:true, origin_at:'bottom',
    alpha_thumbnail:true, multi_view_thumbnails:true,
    ...(prompt ? {texture_prompt:prompt.slice(0,600)} : {}),
    ...(multi ? {image_urls:imageValues} : {image_url:imageValues[0]})
  };
}

export function buildMeshyRetexturePayload({modelDataUri, prompt = '', styleImage = null}) {
  if (!modelDataUri) throw new Error('Een bestaand 3D-model is vereist voor retexture.');
  if (!prompt && !styleImage) throw new Error('Geef een materiaalomschrijving of referentiebeeld op.');
  return {
    model_url:modelDataUri, ai_model:'latest', enable_original_uv:true, enable_pbr:true,
    hd_texture:true, remove_lighting:true, target_formats:['glb'], alpha_thumbnail:true,
    ...(styleImage ? {image_style_url:styleImage.data_url || styleImage.public_url} : {text_style_prompt:prompt.slice(0,600)})
  };
}

export class MeshyProvider {
  constructor(config) { this.config = config; }
  get available() { return Boolean(this.config.apiKey); }

  async generate({ images, prompt = '', outputDir, jobId, onProgress = () => {} }) {
    if (!this.available) throw new Error('Meshy API-sleutel ontbreekt.');
    if (!images?.length) throw new Error('Meshy vereist minimaal één afbeelding.');
    const multi = images.length > 1;
    const endpoint = multi ? '/v1/multi-image-to-3d' : '/v1/image-to-3d';
    const body = buildMeshyReconstructionPayload(images, prompt);
    const created = await apiFetch(`${this.config.baseUrl}${endpoint}`, {
      method:'POST', headers:{ Authorization:`Bearer ${this.config.apiKey}`, 'Content-Type':'application/json' }, body:JSON.stringify(body)
    }, 'Meshy');
    const taskId = created.result;
    const final = await pollTask({
      read: () => apiFetch(`${this.config.baseUrl}${endpoint}/${taskId}`, { headers:{ Authorization:`Bearer ${this.config.apiKey}` } }, 'Meshy'),
      isDone: x => String(x.status).toUpperCase() === 'SUCCEEDED',
      isFailed: x => ['FAILED','CANCELED','EXPIRED'].includes(String(x.status).toUpperCase()),
      onProgress: x => onProgress({ progress: Math.max(10, Number(x.progress || 0)), message:'Meshy bouwt de 3D-draft…', provider_task_id:taskId })
    });
    const glbUrl = final.model_urls?.glb;
    if (!glbUrl) throw new Error('Meshy leverde geen GLB op.');
    const filename = `${jobId}-meshy.glb`;
    await downloadFile(glbUrl, path.join(outputDir, filename));
    return {
      provider:'meshy', provider_task_id:taskId, file_name:filename,
      poster_url: final.alpha_thumbnail_url || final.thumbnail_url || null,
      provider_previews: final.thumbnail_urls || {},
      metrics: { triangles:null, pbr:Boolean(final.texture_urls?.length), consumed_credits:final.consumed_credits ?? null },
      raw_summary: { status:final.status, type:final.type, model_urls:Object.keys(final.model_urls || {}) }
    };
  }

  async retexture({ modelDataUri, prompt = '', styleImage = null, outputDir, jobId, onProgress = () => {} }) {
    if (!this.available) throw new Error('Meshy API-sleutel ontbreekt.');
    const body = buildMeshyRetexturePayload({modelDataUri,prompt,styleImage});
    const endpoint='/v1/retexture';
    const created=await apiFetch(`${this.config.baseUrl}${endpoint}`,{
      method:'POST',headers:{Authorization:`Bearer ${this.config.apiKey}`,'Content-Type':'application/json'},body:JSON.stringify(body)
    },'Meshy retexture');
    const taskId=created.result;
    if(!taskId) throw new Error('Meshy retexture leverde geen task-id op.');
    const final=await pollTask({
      read:()=>apiFetch(`${this.config.baseUrl}${endpoint}/${taskId}`,{headers:{Authorization:`Bearer ${this.config.apiKey}`}},'Meshy retexture'),
      isDone:x=>String(x.status).toUpperCase()==='SUCCEEDED',
      isFailed:x=>['FAILED','CANCELED','EXPIRED'].includes(String(x.status).toUpperCase()),
      onProgress:x=>onProgress({progress:Math.max(10,Number(x.progress||0)),message:'Meshy bouwt de PBR-materiaaldraft…',provider_task_id:taskId})
    });
    const glbUrl=final.model_urls?.glb;
    if(!glbUrl) throw new Error('Meshy retexture leverde geen GLB op.');
    const filename=`${jobId}-meshy-material.glb`;
    await downloadFile(glbUrl,path.join(outputDir,filename));
    return {provider:'meshy',provider_task_id:taskId,file_name:filename,poster_url:final.alpha_thumbnail_url||final.thumbnail_url||null,provider_previews:{},metrics:{pbr:true,retextured:true,consumed_credits:final.consumed_credits??null},raw_summary:{status:final.status,type:final.type}};
  }

}
