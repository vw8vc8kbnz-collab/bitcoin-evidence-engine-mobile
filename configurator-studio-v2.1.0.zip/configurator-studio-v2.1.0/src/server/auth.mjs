import crypto from 'node:crypto';

const COOKIE_NAME='cfgstudio_session';

export class SessionAuth {
  constructor(config={}){
    this.username=String(config.username||'');
    this.password=String(config.password||'');
    this.secret=String(config.sessionSecret||'');
    this.secure=Boolean(config.secureCookies);
    this.ttlSeconds=Math.max(900,Number(config.sessionTtlSeconds||43200));
    this.enabled=Boolean(this.username&&this.password&&this.secret);
  }

  credentialsValid(username,password){
    if(!this.enabled)return false;
    return safeEqual(String(username||''),this.username)&&safeEqual(String(password||''),this.password);
  }

  createSession(){
    if(!this.enabled)throw new Error('Studio-authenticatie is niet geconfigureerd.');
    const now=Math.floor(Date.now()/1000);
    const payload=base64url(JSON.stringify({sub:this.username,iat:now,exp:now+this.ttlSeconds,nonce:crypto.randomBytes(12).toString('hex')}));
    return `${payload}.${sign(payload,this.secret)}`;
  }

  verifyRequest(req){
    if(!this.enabled)return true;
    const token=parseCookies(req.headers.cookie||'')[COOKIE_NAME];
    return this.verifyToken(token);
  }

  verifyToken(token){
    if(!this.enabled)return true;
    const [payload,signature,extra]=String(token||'').split('.');
    if(!payload||!signature||extra)return false;
    if(!safeEqual(signature,sign(payload,this.secret)))return false;
    try{
      const parsed=JSON.parse(Buffer.from(payload,'base64url').toString('utf8'));
      const now=Math.floor(Date.now()/1000);
      return parsed.sub===this.username&&Number(parsed.iat)<=now+60&&Number(parsed.exp)>now;
    }catch{return false}
  }

  sessionCookie(token){
    return `${COOKIE_NAME}=${token}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${this.ttlSeconds}${this.secure?'; Secure':''}`;
  }

  clearCookie(){return `${COOKIE_NAME}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0${this.secure?'; Secure':''}`}
}

function sign(payload,secret){return crypto.createHmac('sha256',secret).update(payload).digest('base64url')}
function base64url(value){return Buffer.from(value).toString('base64url')}
function parseCookies(header){const out={};for(const item of String(header).split(';')){const index=item.indexOf('=');if(index<1)continue;const key=item.slice(0,index).trim();const value=item.slice(index+1).trim();try{out[key]=decodeURIComponent(value)}catch{out[key]=value}}return out}
function safeEqual(a,b){const left=Buffer.from(String(a));const right=Buffer.from(String(b));return left.length===right.length&&crypto.timingSafeEqual(left,right)}
