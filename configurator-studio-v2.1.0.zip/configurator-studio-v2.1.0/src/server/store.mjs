import fs from 'node:fs';
import path from 'node:path';
import { id, nowIso } from '../core/ids.mjs';
import { createDemoBlueprint } from '../core/blueprint.mjs';

export class JsonStore {
  constructor(dataDir) {
    this.file = path.join(dataDir, 'store.json');
    this.writeChain = Promise.resolve();
    this.data = this.#load();
  }

  #load() {
    if (fs.existsSync(this.file)) {
      try { return JSON.parse(fs.readFileSync(this.file, 'utf8')); }
      catch (error) { console.error('Store parse failed, starting from seed:', error.message); }
    }
    return seedStore();
  }

  async save() {
    const payload = JSON.stringify(this.data, null, 2);
    this.writeChain = this.writeChain.then(async () => {
      const temp = `${this.file}.tmp`;
      await fs.promises.writeFile(temp, payload, 'utf8');
      await fs.promises.rename(temp, this.file);
    });
    return this.writeChain;
  }

  getProject(projectId = 'proj_demo_chair') { return this.data.projects.find(p => p.project_id === projectId); }
  listProjects() { return [...this.data.projects].sort((a,b) => b.updated_at.localeCompare(a.updated_at)); }
  getBlueprint(projectId = 'proj_demo_chair') { return this.data.blueprints[projectId]; }
  getAsset(assetId) { return this.data.assets.find(a => a.asset_id === assetId); }
  listAssets(projectId) { return this.data.assets.filter(a => !projectId || a.project_id === projectId).sort((a,b) => b.created_at.localeCompare(a.created_at)); }
  listJobs(projectId) { return this.data.jobs.filter(j => !projectId || j.project_id === projectId).sort((a,b) => b.created_at.localeCompare(a.created_at)); }
  getJob(jobId) { return this.data.jobs.find(j => j.job_id === jobId); }
  getRuntime(runtimeId) { return this.data.runtimes.find(r => r.runtime_config_id === runtimeId); }

  async addProject(project, blueprint) {
    this.data.projects.push(project);
    this.data.blueprints[project.project_id] = blueprint;
    await this.save();
    return project;
  }

  async updateProject(projectId, updater) {
    const index = this.data.projects.findIndex(p => p.project_id === projectId);
    if (index < 0) throw new Error('Project not found');
    const next = updater(structuredClone(this.data.projects[index]));
    next.updated_at = nowIso();
    this.data.projects[index] = next;
    await this.save();
    return next;
  }

  async setBlueprint(projectId, blueprint) {
    this.data.blueprints[projectId] = { ...structuredClone(blueprint), updated_at: nowIso() };
    await this.save();
    return this.data.blueprints[projectId];
  }

  async addAsset(asset) {
    this.data.assets.push(asset);
    await this.save();
    return asset;
  }

  async addJob(job) {
    this.data.jobs.push(job);
    await this.save();
    return job;
  }

  async updateJob(jobId, patchOrUpdater) {
    const index = this.data.jobs.findIndex(j => j.job_id === jobId);
    if (index < 0) throw new Error('Job not found');
    const current = structuredClone(this.data.jobs[index]);
    const next = typeof patchOrUpdater === 'function' ? patchOrUpdater(current) : { ...current, ...patchOrUpdater };
    next.updated_at = nowIso();
    this.data.jobs[index] = next;
    await this.save();
    return next;
  }

  async addAudit(entry) {
    this.data.audit_log.push({ audit_id: id('audit'), created_at: nowIso(), ...entry });
    if (this.data.audit_log.length > 1000) this.data.audit_log = this.data.audit_log.slice(-1000);
    await this.save();
  }

  async addRuntime(runtime) {
    this.data.runtimes.push(runtime);
    await this.updateProject(runtime.project_id, project => ({ ...project, status:'published', runtime_version: runtime.version, published_runtime_id: runtime.runtime_config_id }));
    await this.save();
    return runtime;
  }
}

function seedStore() {
  const created = nowIso();
  return {
    schema_version: '2.1.0',
    workspaces: [{ workspace_id: 'ws_demo', name: 'Demo Workspace', created_at: created }],
    projects: [{
      project_id: 'proj_demo_chair', workspace_id: 'ws_demo', name: 'Arc Chair Configurator',
      description: 'Bouw en test een stoelconfigurator met onafhankelijk instelbare zitting en poten.',
      status: 'draft', created_at: created, updated_at: created, runtime_version: 0, published_runtime_id: null,
      active_asset_id: 'asset_demo_chair', candidate_asset_id: null,
      builder_state: { current_step: 'options', completed_intro: true },
      intake: { prompt: 'Een premium stoel waarbij de klant de kleur van de zitting en het onderstel los kan kiezen.', category: 'chair', requested_profile: 'uploaded_asset' },
      route_decision: { route: 'uploaded_asset', reason: 'Geoptimaliseerd demo-GLB met twee configureerbare zones.', automatic_publish_allowed: false },
      required_fact_keys: ['dimensions.width_mm','dimensions.depth_mm','dimensions.height_mm'],
      facts: [
        confirmedFact('dimensions.width_mm','Breedte',453,'mm'),
        confirmedFact('dimensions.depth_mm','Diepte',540,'mm'),
        confirmedFact('dimensions.height_mm','Hoogte',999,'mm'),
        confirmedFact('product.category','Productcategorie','chair',null,'text')
      ],
      clarification_questions: [], candidate_blueprint: null
    }],
    blueprints: { proj_demo_chair: createDemoBlueprint() },
    assets: [{
      asset_id: 'asset_demo_chair', project_id: 'proj_demo_chair', source_type: 'verified_upload', provider: null,
      file_name: 'demo-chair.glb', extension: 'glb', public_url: '/assets/demo-chair.glb', poster_url: '/assets/demo-chair-preview.png',
      quality_status: 'accepted', technical_status: 'succeeded', created_at: created,
      metrics: { file_bytes: 896732, glb_version: 2, triangles: 39851, meshes: 2, nodes: 3, primitives: 2, materials: 2, textures: 0, images: 0, mobile_ready: true },
      mesh_inventory: [
        { mesh_id: 'seat_and_back', label: 'Zitting en rug', visible: true, assigned_part_id: 'part_seat', triangles: 30000, primitive_count: 1 },
        { mesh_id: 'legs_and_footrest', label: 'Poten en voetensteun', visible: true, assigned_part_id: 'part_legs', triangles: 9851, primitive_count: 1 }
      ],
      provenance: { uploaded_by: 'studio_seed', source: 'user_supplied_glb_simplified', candidate_only: false, optimized_for_web: true, source_triangles: 280838, optimization_note: 'silhouette_preserving_decimation_and_two_zone_split' }
    }],
    jobs: [], runtimes: [], audit_log: []
  };
}

function confirmedFact(key, label, value, unit, valueType = 'measurement') {
  return {
    fact_id: id('fact'), key, label, value, unit, value_type: valueType, critical: key.startsWith('dimensions.'), candidates: [],
    verified: { by: 'seed_admin', method: 'imported_verified', at: nowIso() }, conflict: null, status: 'confirmed', pricing_allowed: true, updated_at: nowIso()
  };
}
