import fs from 'node:fs';
import path from 'node:path';

function parseEnvFile(filePath) {
  if (!fs.existsSync(filePath)) return {};
  const result = {};
  for (const line of fs.readFileSync(filePath, 'utf8').split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const index = trimmed.indexOf('=');
    if (index < 1) continue;
    const key = trimmed.slice(0, index).trim();
    let value = trimmed.slice(index + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
    result[key] = value;
  }
  return result;
}

const root = process.cwd();
const fileEnv = parseEnvFile(path.join(root, '.env'));
const env = { ...fileEnv, ...process.env };
const resolveDir = (value, fallback) => path.resolve(root, value || fallback);
const bool = (value, fallback = false) => value === undefined ? fallback : ['1','true','yes','on'].includes(String(value).toLowerCase());

export const config = Object.freeze({
  root,
  host: env.HOST || '0.0.0.0',
  port: Number(env.PORT || 9999),
  publicBaseUrl: (env.PUBLIC_BASE_URL || `http://localhost:${env.PORT || 9999}`).replace(/\/$/, ''),
  dataDir: resolveDir(env.DATA_DIR, './data'),
  uploadDir: resolveDir(env.UPLOAD_DIR, './runtime_uploads'),
  assetDir: resolveDir(env.ASSET_DIR, './runtime_assets'),
  outputDir: resolveDir(env.OUTPUT_DIR, './runtime_outputs'),
  demoMode: bool(env.DEMO_MODE, true),
  auth: {
    username: env.ADMIN_USERNAME || '',
    password: env.ADMIN_PASSWORD || '',
    sessionSecret: env.SESSION_SECRET || '',
    secureCookies: bool(env.COOKIE_SECURE, false),
    sessionTtlSeconds: Number(env.SESSION_TTL_SECONDS || 43200)
  },
  openai: { apiKey: env.OPENAI_API_KEY || '', model: env.OPENAI_MODEL || 'gpt-5.6' },
  meshy: { apiKey: env.MESHY_API_KEY || '', baseUrl: 'https://api.meshy.ai/openapi' },
  tripo: { apiKey: env.TRIPO_API_KEY || '', baseUrl: 'https://api.tripo3d.ai/v2/openapi', modelVersion: env.TRIPO_MODEL_VERSION || 'P1-20260311' },
  rodin: { apiKey: env.HYPER3D_API_KEY || '', baseUrl: 'https://api.hyper3d.com/api/v2', tier: env.RODIN_TIER || 'Gen-2' },
  cad: { freecadCmd: env.FREECAD_CMD || 'freecadcmd', blenderCmd: env.BLENDER_CMD || 'blender' },
  limits: { requestBytes: Number(env.MAX_REQUEST_BYTES || 50 * 1024 * 1024), uploadBytes: Number(env.MAX_UPLOAD_BYTES || 30 * 1024 * 1024) }
});

if (!config.demoMode && !(config.auth.username && config.auth.password && config.auth.sessionSecret)) throw new Error('Productiemodus vereist ADMIN_USERNAME, ADMIN_PASSWORD en SESSION_SECRET.');

for (const dir of [config.dataDir, config.uploadDir, config.assetDir, config.outputDir]) fs.mkdirSync(dir, { recursive: true });
