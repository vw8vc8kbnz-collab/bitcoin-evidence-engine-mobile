import fs from 'node:fs';

const JSON_CHUNK = 0x4E4F534A;

export async function inspectGlb(filePath) {
  const buffer = await fs.promises.readFile(filePath);
  if (buffer.length < 20 || buffer.toString('ascii',0,4) !== 'glTF') throw new Error('Bestand is geen geldige binary GLB.');
  const version = buffer.readUInt32LE(4), declaredLength = buffer.readUInt32LE(8);
  if (version !== 2) throw new Error(`Alleen glTF 2.0 wordt ondersteund; gevonden versie ${version}.`);
  if (declaredLength > buffer.length) throw new Error('GLB is afgekapt of beschadigd.');
  let offset=12, jsonDoc=null;
  while(offset+8<=declaredLength){const len=buffer.readUInt32LE(offset),type=buffer.readUInt32LE(offset+4);offset+=8;if(offset+len>buffer.length)throw new Error('GLB chunk valt buiten het bestand.');if(type===JSON_CHUNK)jsonDoc=JSON.parse(buffer.subarray(offset,offset+len).toString('utf8').replace(/\u0000+$/,''));offset+=len}
  if(!jsonDoc)throw new Error('GLB bevat geen JSON scene chunk.');
  const accessors=jsonDoc.accessors||[], meshes=jsonDoc.meshes||[], nodes=jsonDoc.nodes||[];
  const nodeNamesByMesh=new Map();
  nodes.forEach((node,index)=>{if(Number.isInteger(node.mesh)&&!nodeNamesByMesh.has(node.mesh))nodeNamesByMesh.set(node.mesh,node.name||`node_${index}`)});
  let triangles=0, primitives=0;
  const inventory=meshes.map((mesh,index)=>{
    let meshTriangles=0;
    for(const primitive of mesh.primitives||[]){primitives++;if(Number.isInteger(primitive.indices)){const count=Number(accessors[primitive.indices]?.count||0);meshTriangles+=Math.floor(count/3)}else if(Number.isInteger(primitive.attributes?.POSITION)){const count=Number(accessors[primitive.attributes.POSITION]?.count||0);meshTriangles+=Math.floor(count/3)}}
    triangles+=meshTriangles;
    const meshId=String(mesh.name||nodeNamesByMesh.get(index)||`mesh_${index}`).trim();
    return {mesh_id:meshId,label:humanize(meshId),visible:true,assigned_part_id:null,triangles:meshTriangles,primitive_count:(mesh.primitives||[]).length};
  });
  const textures=(jsonDoc.textures||[]).length, images=(jsonDoc.images||[]).length, materials=(jsonDoc.materials||[]).length;
  return {metrics:{file_bytes:buffer.length,glb_version:version,meshes:meshes.length,nodes:nodes.length,primitives,triangles,materials,textures,images,mobile_ready:triangles<=250000&&buffer.length<=25*1024*1024},mesh_inventory:inventory,extensions_used:jsonDoc.extensionsUsed||[]};
}

function humanize(value){return String(value).replace(/[_-]+/g,' ').replace(/\b\w/g,c=>c.toUpperCase())}
